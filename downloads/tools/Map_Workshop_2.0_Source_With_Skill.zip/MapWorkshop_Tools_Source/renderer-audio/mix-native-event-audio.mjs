import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {NATIVE_EFFECTS, MUSIC_EVENTS, MUSIC_ASSETS, MAPPING_NOTES} from './native-effects.mjs';

export {NATIVE_EFFECTS};
export const LIMITS = Object.freeze({
  durationSeconds: 600, eventCount: 100000, soundEventCount: 20000,
  uniqueAssets: 64, assetSeconds: 30, assetBytes: 16 * 1024 * 1024,
  pcmBytes: 256 * 1024 * 1024, cachedClipBytes: 64 * 1024 * 1024,
  mixedInterleavedValues: 64 * 1024 * 1024, processTimeoutMs: 60000
});
export const sha256 = bytes => createHash('sha256').update(bytes).digest('hex');
const RATE = 48000, CHANNELS = 2;

function command(binary, args, maxBuffer = 1024 * 1024) {
  const result = spawnSync(binary, args, {
    encoding: null, maxBuffer, timeout: LIMITS.processTimeoutMs,
    windowsHide: true
  });
  if (result.error) throw result.error;
  assert.equal(result.status, 0, `${binary} failed: ${result.stderr?.toString().slice(-4000)}`);
  return result.stdout;
}

function floatSamples(bytes) {
  assert(bytes.length > 0 && bytes.length % (CHANNELS * 4) === 0, 'Invalid stereo f32le byte length');
  assert.equal(new Uint8Array(new Uint16Array([1]).buffer)[0], 1, 'This helper requires a little-endian host');
  const copy = new Uint8Array(bytes.length); copy.set(bytes);
  return new Float32Array(copy.buffer);
}

function validateOptions({events, fps, duration, mapping, gain}) {
  assert(Array.isArray(events) && events.length <= LIMITS.eventCount, 'events exceeds bounded array size');
  assert(Number.isFinite(fps) && fps >= 1 && fps <= 240, 'fps must be between 1 and 240');
  assert(Number.isFinite(duration) && duration > 0 && duration <= LIMITS.durationSeconds, 'duration must be >0 and <=600 seconds');
  assert(Number.isFinite(gain) && gain >= 0 && gain <= 1, 'gain must be between 0 and 1');
  assert(mapping && typeof mapping === 'object' && !Array.isArray(mapping), 'mapping must be an object');
  const sampleFrames = Math.round(duration * RATE);
  assert(sampleFrames > 0 && sampleFrames * CHANNELS * 4 <= LIMITS.pcmBytes, 'PCM allocation exceeds limit');
  let soundCount = 0;
  for (const event of events) {
    assert(event && typeof event === 'object', 'Each event must be an object');
    if (event.type !== 'sound') continue;
    soundCount++;
    assert(Number.isSafeInteger(event.frame) && event.frame >= 0, 'Sound frame must be a nonnegative zero-based integer');
    assert(typeof event.event === 'string' && event.event.length > 0 && event.event.length <= 100, 'Invalid sound event name');
  }
  assert(soundCount <= LIMITS.soundEventCount, 'Too many sound events');
  const files = [...new Set(Object.values(mapping))];
  assert(files.length <= LIMITS.uniqueAssets, 'Too many mapped assets');
  for (const filename of files) {
    assert(typeof filename === 'string' && /^[A-Za-z0-9][A-Za-z0-9_.-]*\.(?:mp3|wav|ogg|m4a)$/i.test(filename), 'Asset mappings must be local audio basenames');
  }
  return {sampleFrames, soundCount};
}

/**
 * Pure mixer. clips is a Map of mapped filenames to interleaved 48kHz stereo
 * Float32Array samples. Event frame 0 starts at sample-frame 0; there is no +1.
 * Public timestamps always distinguish sample frames from interleaved values.
 */
export function mixEventPCM({events, fps, duration, clips, mapping = NATIVE_EFFECTS, gain = .65}) {
  const {sampleFrames, soundCount} = validateOptions({events, fps, duration, mapping, gain});
  assert(clips instanceof Map, 'clips must be a Map');
  const checked = new Set(); let cachedBytes = 0, mixedValues = 0;
  const pcm = new Float32Array(sampleFrames * CHANNELS);
  const timeline = [], used = [], unmapped = [], excludedMusic = [], unavailable = [], outsideDuration = [];
  for (let sourceEventIndex = 0; sourceEventIndex < events.length; sourceEventIndex++) {
    const event = events[sourceEventIndex];
    if (event.type !== 'sound') continue;
    const sampleFrameOffset = Math.round(event.frame / fps * RATE);
    const base = {sourceEventIndex, event: event.event, frame: event.frame,
      timeSeconds: event.frame / fps, sampleFrameOffset,
      interleavedSampleOffset: sampleFrameOffset * CHANNELS,
      roundingErrorSeconds: sampleFrameOffset / RATE - event.frame / fps};
    let reason = null;
    if (MUSIC_EVENTS.has(event.event) || MUSIC_ASSETS.has(mapping[event.event])) reason = 'background-music-excluded';
    else if (!Object.hasOwn(mapping, event.event)) reason = 'unmapped-event';
    else if (!clips.has(mapping[event.event])) reason = 'mapped-asset-unavailable';
    else if (sampleFrameOffset >= sampleFrames) reason = 'outside-duration';
    if (reason) {
      const item = {...base, status: reason, asset: mapping[event.event] || null};
      timeline.push(item);
      ({'background-music-excluded': excludedMusic, 'unmapped-event': unmapped,
        'mapped-asset-unavailable': unavailable, 'outside-duration': outsideDuration})[reason].push(item);
      continue;
    }
    const asset = mapping[event.event], clip = clips.get(asset);
    if (!checked.has(asset)) {
      assert(clip instanceof Float32Array && clip.length > 0 && clip.length % CHANNELS === 0, `Invalid PCM clip: ${asset}`);
      assert(clip.length / CHANNELS <= LIMITS.assetSeconds * RATE, `Asset too long: ${asset}`);
      cachedBytes += clip.byteLength;
      assert(cachedBytes <= LIMITS.cachedClipBytes, 'Aggregate decoded asset cache exceeds limit');
      for (const sample of clip) assert(Number.isFinite(sample) && Math.abs(sample) <= 32, `Nonfinite/extreme asset PCM: ${asset}`);
      checked.add(asset);
    }
    const start = sampleFrameOffset * CHANNELS;
    const valuesMixed = Math.min(clip.length, pcm.length - start);
    mixedValues += valuesMixed;
    assert(mixedValues <= LIMITS.mixedInterleavedValues, 'Aggregate mixing work exceeds limit');
    for (let i = 0; i < valuesMixed; i++) pcm[start + i] += clip[i] * gain;
    const item = {...base, status: 'mixed', asset, sourceSampleFrames: clip.length / CHANNELS,
      mixedSampleFrames: valuesMixed / CHANNELS,
      truncatedSampleFrames: (clip.length - valuesMixed) / CHANNELS,
      mappingNote: mapping[event.event] === NATIVE_EFFECTS[event.event] ? (MAPPING_NOTES[event.event] || null) : null};
    timeline.push(item); used.push(item);
  }
  let squared = 0, peakBeforeClamp = 0, peak = 0, clippedValues = 0;
  for (let i = 0; i < pcm.length; i++) {
    assert(Number.isFinite(pcm[i]), 'Nonfinite mixed PCM');
    peakBeforeClamp = Math.max(peakBeforeClamp, Math.abs(pcm[i]));
    if (Math.abs(pcm[i]) > 1) clippedValues++;
    pcm[i] = Math.max(-1, Math.min(1, pcm[i]));
    peak = Math.max(peak, Math.abs(pcm[i])); squared += pcm[i] ** 2;
  }
  return {pcm, report: {
    sampleRate: RATE, channels: CHANNELS, fps, requestedDurationSeconds: duration,
    sampleFrames, pcmDurationSeconds: sampleFrames / RATE, gain,
    sourceEventCount: events.length, ignoredNonSoundEvents: events.length - soundCount,
    soundEventCount: soundCount, mixedEventCount: used.length,
    timeline, events: used, unmappedEvents: unmapped, excludedMusicEvents: excludedMusic,
    unavailableEvents: unavailable, outsideDurationEvents: outsideDuration,
    truncatedEvents: used.filter(event => event.truncatedSampleFrames > 0),
    finitePCM: true, peakBeforeClamp, peak, clippedInterleavedValues: clippedValues,
    clippedFraction: clippedValues / pcm.length, rms: Math.sqrt(squared / pcm.length),
    eventInsertionTiming: 'round(zeroBasedFrame / fps * 48000), in sample frames; no +1 frame offset',
    maximumTimingRoundingErrorSeconds: used.reduce((v, event) => Math.max(v, Math.abs(event.roundingErrorSeconds)), 0),
    pcmSha256: sha256(new Uint8Array(pcm.buffer)),
    mixedInterleavedValues: mixedValues, cachedClipBytes: cachedBytes,
    knownBackgroundMusicIncluded: false,
    backgroundMusicPolicy: 'Known background event keys and asset basenames are excluded; arbitrary supplied asset contents are not classified.',
    originalSMM2AudioPolicy: 'No original walkthrough audio is fetched or extracted; supplied asset origin must be explicitly labelled.'
  }};
}

async function loadClips(events, mapping, assetDirectory) {
  const root = await fs.realpath(assetDirectory), clips = new Map(), assets = [], errors = [], sourceInodes = new Set();
  let cacheBytes = 0;
  const names = [...new Set(events.filter(e => e.type === 'sound' && !MUSIC_EVENTS.has(e.event) && Object.hasOwn(mapping, e.event) && !MUSIC_ASSETS.has(mapping[e.event])).map(e => mapping[e.event]))];
  for (const name of names) {
    let filename;
    try { filename = await fs.realpath(path.join(root, name)); }
    catch (error) {
      if (error.code !== 'ENOENT') throw error;
      errors.push({asset: name, reason: 'missing-file'}); continue;
    }
    assert.equal(path.dirname(filename), root, `Asset escapes supplied directory: ${name}`);
    const info = await fs.stat(filename);
    assert(info.isFile() && info.size > 0 && info.size <= LIMITS.assetBytes, `Asset file exceeds bounds: ${name}`);
    sourceInodes.add(`${info.dev}:${info.ino}`);
    const before = await fs.readFile(filename), sourceSha256 = sha256(before);
    const bytes = command('ffmpeg', ['-nostdin', '-hide_banner', '-loglevel', 'error', '-i', filename,
      '-vn', '-t', String(LIMITS.assetSeconds + 1 / RATE), '-f', 'f32le', '-ar', String(RATE), '-ac', String(CHANNELS), 'pipe:1'],
      (LIMITS.assetSeconds + 1) * RATE * CHANNELS * 4);
    const samples = floatSamples(bytes);
    cacheBytes += samples.byteLength;
    assert(cacheBytes <= LIMITS.cachedClipBytes, 'Aggregate decoded asset cache exceeds limit');
    assert(samples.length / CHANNELS <= LIMITS.assetSeconds * RATE, `Decoded asset exceeds 30 seconds: ${name}`);
    for (const sample of samples) assert(Number.isFinite(sample) && Math.abs(sample) <= 32, `Invalid asset audio: ${name}`);
    assert(samples.some(sample => Math.abs(sample) > .00001), `Empty/silent effect asset: ${name}`);
    assert.equal(sha256(await fs.readFile(filename)), sourceSha256, `Asset changed during decode: ${name}`);
    clips.set(name, samples);
    assets.push({asset: name, resolvedPath: filename, sourceSha256, sourceBytes: before.length,
      decodedSampleFrames: samples.length / CHANNELS, decodedDurationSeconds: samples.length / CHANNELS / RATE,
      decodedPcmSha256: sha256(bytes)});
  }
  return {root, clips, assets, errors, sourceInodes};
}

function correlation(a, b, start, length, shift = 0) {
  let aa = 0, bb = 0, ab = 0, absoluteError = 0;
  for (let i = start; i < start + length; i++) {
    const x = a[i], y = b[i + shift] || 0;
    aa += x * x; bb += y * y; ab += x * y; absoluteError += Math.abs(x - y);
  }
  return {correlation: aa && bb ? ab / Math.sqrt(aa * bb) : (aa === bb ? 1 : 0),
    meanAbsoluteError: absoluteError / length, sourceRms: Math.sqrt(aa / length)};
}

/** Full AAC decode plus timestamp-aligned PCM comparison. AAC is lossy and may
 * retain up to one 1024-sample trailing packet. Expected timeline is never shifted.
 */
export function verifyEncodedAudio(outputPath, pcm, mixReport) {
  const probe = JSON.parse(command('ffprobe', ['-v', 'error', '-show_streams', '-show_format', '-of', 'json', outputPath]).toString());
  assert.equal(probe.streams.length, 1, 'Audio helper must produce exactly one audio stream');
  const stream = probe.streams[0];
  assert.equal(stream.codec_type, 'audio'); assert.equal(stream.codec_name, 'aac');
  assert.equal(Number(stream.sample_rate), RATE); assert.equal(stream.channels, CHANNELS);
  const [timeNumerator, timeDenominator] = stream.time_base.split('/').map(Number);
  const declaredDuration = Number(stream.duration_ts) * timeNumerator / timeDenominator;
  // MP4 muxers sometimes express the final duration in milliseconds. The PCM
  // timeline remains exact; disclose the small stream/container rounding.
  assert(Math.abs(declaredDuration - mixReport.pcmDurationSeconds) <= .0011, 'AAC track duration differs by more than muxer rounding');
  command('ffmpeg', ['-nostdin', '-v', 'error', '-i', outputPath, '-f', 'null', '-']);
  const decodedBytes = command('ffmpeg', ['-nostdin', '-v', 'error', '-i', outputPath,
    '-f', 'f32le', '-ar', String(RATE), '-ac', String(CHANNELS), 'pipe:1'], pcm.byteLength + 8192 + 1024 * 1024);
  const decoded = floatSamples(decodedBytes), decodedSampleFrames = decoded.length / CHANNELS;
  assert(decodedSampleFrames >= mixReport.sampleFrames && decodedSampleFrames - mixReport.sampleFrames <= 1024,
    'Unexpected AAC decoder truncation/padding');
  let peak = 0, square = 0;
  for (const sample of decoded) { assert(Number.isFinite(sample), 'Nonfinite AAC decoded PCM'); peak = Math.max(peak, Math.abs(sample)); square += sample ** 2; }
  const aligned = correlation(pcm, decoded, 0, pcm.length);
  assert(aligned.correlation >= .90 && aligned.meanAbsoluteError <= .05, 'AAC decode is not aligned with scheduled native-event PCM');
  const timingChecks = [];
  // Use the first isolated effect, if available. Compare the intended window to
  // neighbouring sample shifts; no claim is made about exact acoustic onset in
  // compressed source recordings or AAC pre-echo.
  const chronological = [...mixReport.events].sort((a, b) => a.sampleFrameOffset - b.sampleFrameOffset || a.sourceEventIndex - b.sourceEventIndex);
  let previousMaximumEnd = 0;
  for (let index = 0; index < chronological.length; index++) {
    const event = chronological[index], next = chronological[index + 1];
    const overlappedByPrevious = previousMaximumEnd > event.sampleFrameOffset;
    previousMaximumEnd = Math.max(previousMaximumEnd, event.sampleFrameOffset + event.mixedSampleFrames);
    if (overlappedByPrevious) continue;
    if (next && next.sampleFrameOffset < event.sampleFrameOffset + event.mixedSampleFrames) continue;
    const start = event.interleavedSampleOffset + 64, length = Math.min(event.mixedSampleFrames * CHANNELS - 128, RATE / 2);
    if (length <= 0 || start + length + 32 >= pcm.length) continue;
    const zero = correlation(pcm, decoded, start, length);
    if (zero.sourceRms < .00001) continue;
    let best = {...zero, shiftSampleFrames: 0};
    const shifts = Array.from({length: 16}, (_, i) => i + 1).flatMap(i => [-i, i]);
    for (const shift of shifts) {
      const test = correlation(pcm, decoded, start, length, shift * CHANNELS);
      if (test.correlation > best.correlation + 1e-10) best = {...test, shiftSampleFrames: shift};
    }
    timingChecks.push({frame: event.frame, event: event.event, expectedSampleFrameOffset: event.sampleFrameOffset,
      check: 'Local lossy-codec waveform alignment, not proof of acoustic onset or encoder priming.', ...best});
    if (timingChecks.length === 3) break;
  }
  return {fullDecode: true, codec: stream.codec_name, sampleRate: RATE, channels: CHANNELS,
    streamDurationSeconds: declaredDuration, containerDurationSeconds: Number(probe.format.duration),
    durationRoundingErrorSeconds: declaredDuration - mixReport.pcmDurationSeconds,
    decodedSampleFrames, trailingDecoderPaddingSampleFrames: decodedSampleFrames - mixReport.sampleFrames,
    finiteDecodedPCM: true, decodedPeak: peak, decodedRms: Math.sqrt(square / decoded.length),
    zeroShiftCorrelation: aligned.correlation, meanAbsoluteError: aligned.meanAbsoluteError,
    isolatedEventTimingChecks: timingChecks, aacPacketSha256: sha256(command('ffmpeg', ['-nostdin', '-v', 'error', '-i', outputPath, '-map', '0:a:0', '-c', 'copy', '-f', 'data', 'pipe:1'], 32 * 1024 * 1024))};
}

/** Bounded standalone integration entry point. Writes AAC in an audio-only M4A
 * and a .report.json sidecar. No runtime/video/source edits or network access.
 */
export async function mixNativeEventAudio({events, fps, duration, assetDirectory, outputPath,
  mapping = NATIVE_EFFECTS, gain = .65, assetProvenance = 'Existing native game effect recordings; authorship not independently established.',
  retainPCM = false, overwrite = false}) {
  validateOptions({events, fps, duration, mapping, gain});
  assert(typeof assetDirectory === 'string' && typeof outputPath === 'string', 'assetDirectory and outputPath are required');
  assert(typeof assetProvenance === 'string' && assetProvenance.length > 0 && assetProvenance.length <= 2000, 'Explicit bounded asset provenance required');
  const output = path.resolve(outputPath), reportFile = output + '.report.json', pcmFile = output + '.f32le';
  assert.equal(path.extname(output).toLowerCase(), '.m4a', 'outputPath must end in .m4a');
  await fs.mkdir(path.dirname(output), {recursive: true});
  if (!overwrite) for (const file of [output, reportFile, ...(retainPCM ? [pcmFile] : [])]) {
    try { await fs.lstat(file); throw new Error(`Output already exists: ${file}`); }
    catch (error) { if (error.code !== 'ENOENT') throw error; }
  }
  const loaded = await loadClips(events, mapping, assetDirectory);
  const sourcePaths = new Set(loaded.assets.map(asset => asset.resolvedPath));
  for (const destination of [output, reportFile, pcmFile]) {
    let resolved;
    try { resolved = await fs.realpath(destination); }
    catch (error) {
      if (error.code !== 'ENOENT') throw error;
      resolved = path.join(await fs.realpath(path.dirname(destination)), path.basename(destination));
    }
    assert(!sourcePaths.has(resolved), `Output aliases an input audio asset: ${destination}`);
    try {
      const info = await fs.stat(destination);
      assert(!loaded.sourceInodes.has(`${info.dev}:${info.ino}`), `Output hard-links an input audio asset: ${destination}`);
    } catch (error) { if (error.code !== 'ENOENT') throw error; }
  }
  const {pcm, report: mixReport} = mixEventPCM({events, fps, duration, clips: loaded.clips, mapping, gain});
  const temp = await fs.mkdtemp(path.join(path.dirname(output), '.native-audio-'));
  try {
    const tempPCM = path.join(temp, 'mix.f32le'), tempAAC = path.join(temp, 'events.m4a');
    await fs.writeFile(tempPCM, new Uint8Array(pcm.buffer));
    command('ffmpeg', ['-nostdin', '-hide_banner', '-loglevel', 'error', '-y', '-f', 'f32le',
      '-ar', String(RATE), '-ac', String(CHANNELS), '-i', tempPCM, '-c:a', 'aac', '-b:a', '160k',
      '-t', String(mixReport.pcmDurationSeconds), '-movflags', '+faststart', tempAAC]);
    const verification = verifyEncodedAudio(tempAAC, pcm, mixReport);
    for (const asset of loaded.assets) assert.equal(sha256(await fs.readFile(path.join(loaded.root, asset.asset))), asset.sourceSha256, `Asset changed during mix: ${asset.asset}`);
    const bytes = await fs.readFile(tempAAC), report = {
      format: 'native-event-audio-mix-v1', ...mixReport, assetDirectory: loaded.root,
      assetProvenance, mapping, mappingSha256: sha256(JSON.stringify(mapping)),
      eventInputSha256: sha256(JSON.stringify(events)), assets: loaded.assets, assetErrors: loaded.errors,
      outputPath: output, outputBytes: bytes.length, outputSha256: sha256(bytes),
      reportPath: reportFile, pcmRetained: retainPCM, pcmPath: retainPCM ? pcmFile : null,
      verification, limits: LIMITS,
      limitations: [
        'Timing verifies provided native event insertion, not original SMM2 audiovisual fidelity or a new gameplay replay.',
        'Existing recordings may contain leading silence. AAC is lossy and may add pre-echo or trailing packet padding.',
        'One-shot flag/clear jingles are effect events; background tracks are excluded.',
        'Unmapped, unavailable and out-of-duration events are reported without invented replacement sounds.',
        'Overlapping effects are summed at gain 0.65 by default, then hard-clamped; reported clipping may be audible.',
        'This helper does not prove asset ownership, licensing, original SMM2 audio or browser playback.'
      ]
    };
    if (overwrite) await fs.rename(tempAAC, output);
    else await fs.copyFile(tempAAC, output, fs.constants.COPYFILE_EXCL);
    if (retainPCM) await fs.copyFile(tempPCM, pcmFile, overwrite ? 0 : fs.constants.COPYFILE_EXCL);
    await fs.writeFile(reportFile, JSON.stringify(report, null, 2) + '\n', {flag: overwrite ? 'w' : 'wx'});
    return report;
  } finally { await fs.rm(temp, {recursive: true, force: true}); }
}

/** Read-only re-verification of an existing track and its sidecar. Rebuilds the
 * expected PCM in memory, then fully decodes AAC. Does not encode or write.
 */
export async function verifyNativeEventAudio({events, fps, duration, assetDirectory, outputPath,
  mapping = NATIVE_EFFECTS, gain = .65}) {
  validateOptions({events, fps, duration, mapping, gain});
  const output = path.resolve(outputPath);
  assert.equal(path.extname(output).toLowerCase(), '.m4a', 'outputPath must end in .m4a');
  const recorded = JSON.parse(await fs.readFile(output + '.report.json', 'utf8'));
  assert.equal(recorded.format, 'native-event-audio-mix-v1');
  const before = sha256(await fs.readFile(output));
  assert.equal(before, recorded.outputSha256, 'Existing AAC file differs from its report');
  assert.equal(sha256(JSON.stringify(events)), recorded.eventInputSha256, 'Event inputs differ');
  assert.equal(sha256(JSON.stringify(mapping)), recorded.mappingSha256, 'Effect mapping differs');
  const loaded = await loadClips(events, mapping, assetDirectory);
  const {pcm, report} = mixEventPCM({events, fps, duration, mapping, clips: loaded.clips, gain});
  assert.equal(report.pcmSha256, recorded.pcmSha256, 'Expected PCM differs from original verified mix');
  assert.deepEqual(report.timeline, recorded.timeline, 'Event timing/classification differs');
  assert.deepEqual(loaded.assets, recorded.assets, 'Input assets differ from original mix');
  const verification = verifyEncodedAudio(output, pcm, report);
  assert.equal(sha256(await fs.readFile(output)), before, 'AAC file changed during verification');
  for (const asset of loaded.assets) assert.equal(sha256(await fs.readFile(asset.resolvedPath)), asset.sourceSha256, `Asset changed during verification: ${asset.asset}`);
  return {...recorded, verification, readOnlyReverified: true};
}

async function main() {
  const args = Object.fromEntries(process.argv.slice(2).map(arg => { const at = arg.indexOf('='); return at < 0 ? [arg.replace(/^--/, ''), true] : [arg.slice(0, at).replace(/^--/, ''), arg.slice(at + 1)]; }));
  assert(args.events && args.fps && args.duration && args.assets && args.out,
    'Usage: node mix-native-event-audio.mjs --events=events-or-route.json --fps=60 --duration=123.416666667 --assets=/native/assets --out=events.m4a [--mapping=mapping.json] [--retain-pcm]');
  const source = JSON.parse(await fs.readFile(path.resolve(args.events), 'utf8'));
  const mapping = args.mapping ? JSON.parse(await fs.readFile(path.resolve(args.mapping), 'utf8')) : NATIVE_EFFECTS;
  const report = await mixNativeEventAudio({events: Array.isArray(source) ? source : source.events,
    fps: Number(args.fps), duration: Number(args.duration), assetDirectory: path.resolve(args.assets),
    outputPath: path.resolve(args.out), mapping, retainPCM: !!args['retain-pcm'], overwrite: !!args.overwrite,
    ...(args.provenance ? {assetProvenance: args.provenance} : {})});
  console.log(JSON.stringify({outputPath: report.outputPath, reportPath: report.reportPath,
    duration: report.pcmDurationSeconds, soundEvents: report.soundEventCount, mixedEvents: report.mixedEventCount,
    unmapped: report.unmappedEvents.length, unavailable: report.unavailableEvents.length,
    excludedMusic: report.excludedMusicEvents.length, clippedFraction: report.clippedFraction,
    sha256: report.outputSha256, verification: report.verification}, null, 2));
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  main().catch(error => { console.error(error.stack); process.exitCode = 1; });
}
