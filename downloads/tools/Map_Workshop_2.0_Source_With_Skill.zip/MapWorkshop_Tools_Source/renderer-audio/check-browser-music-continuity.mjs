// Real Chromium HTMLAudioElement decoding and Web Audio signal checks. This is
// a neutral audio fixture, not a gameplay replay or personal-listening test.
import fs from 'node:fs/promises';
import path from 'node:path';
import http from 'node:http';
import {spawn, spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import assert from 'node:assert/strict';
import os from 'node:os';

const root = fileURLToPath(new URL('../', import.meta.url));
const pause = ms => new Promise(resolve => setTimeout(resolve, ms));
const server = http.createServer(async (req, res) => {
  try {
    const pathname = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
    if (pathname === '/') { res.setHeader('Content-Type', 'text/html'); res.end('<title>Native music continuity fixture</title>'); return; }
    const filename = path.resolve(root, '.' + pathname);
    assert(filename.startsWith(root));
    const bytes = await fs.readFile(filename);
    res.setHeader('Content-Type', {'.mjs': 'text/javascript', '.wav': 'audio/wav', '.mp3': 'audio/mpeg'}[path.extname(filename)] || 'application/octet-stream');
    res.end(bytes);
  } catch { res.writeHead(404); res.end(); }
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const fixtureURL = 'http://127.0.0.1:' + server.address().port;
const temporary = await fs.mkdtemp(path.join(os.tmpdir(), 'workshop-native-audio-'));
const browser = spawn('chromium', ['--headless', '--no-sandbox', '--disable-dev-shm-usage', '--mute-audio',
  '--autoplay-policy=no-user-gesture-required', '--remote-debugging-port=0', '--user-data-dir=' + temporary, 'about:blank'], {stdio: 'ignore'});
let socket;
try {
  let port;
  for (let i = 0; i < 100; i++) {
    try { port = Number((await fs.readFile(path.join(temporary, 'DevToolsActivePort'), 'utf8')).split('\n')[0]); break; }
    catch { assert(browser.exitCode === null, 'Chromium exited before debugging became available'); await pause(50); }
  }
  assert(port, 'Chromium debugging unavailable');
  const target = await (await fetch('http://127.0.0.1:' + port + '/json/new?' + encodeURIComponent(fixtureURL), {method: 'PUT'})).json();
  socket = new WebSocket(target.webSocketDebuggerUrl);
  await new Promise((resolve, reject) => { socket.addEventListener('open', resolve, {once: true}); socket.addEventListener('error', reject, {once: true}); });
  let nextId = 0;
  const requests = new Map();
  socket.addEventListener('message', message => { const result = JSON.parse(message.data); const request = requests.get(result.id); if (!request) return;
    requests.delete(result.id); if (result.error) request.reject(new Error(JSON.stringify(result.error))); else request.resolve(result.result); });
  const call = (method, params) => new Promise((resolve, reject) => { const id = ++nextId; requests.set(id, {resolve, reject}); socket.send(JSON.stringify({id, method, params})); });
  const expression = `(async () => {
    const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
    const {createSound} = await import('/atlas/editor-audio.mjs');
    const NativeAudio = window.Audio, elements = [];
    window.Audio = function(src) { const element = new NativeAudio(src); elements.push(element); return element; };
    const sound = createSound();
    const first = sound.resumeMusic('castle', true), music = elements[0];
    music.pause(); await first;
    const interrupted = sound.snapshot();
    const context = new AudioContext({sampleRate: 48000}); await context.resume();
    const bgm = context.createAnalyser(), mix = context.createAnalyser(); bgm.fftSize = mix.fftSize = 2048;
    const musicSource = context.createMediaElementSource(music); musicSource.connect(bgm); bgm.connect(mix); mix.connect(context.destination);
    const connected = new Set([music]), effectNodes = [], samples = [], effects = [];
    await sound.background('castle');
    const recovered = sound.snapshot(), started = performance.now();
    const effectAt = [[2000,'bowser_fire'],[7000,'stomp'],[12000,'stomp'],[16500,'bowser_fire'],[23000,'stomp'],[23600,'pickup']];
    const values = new Float32Array(2048), mixed = new Float32Array(2048);
    const energy = analyser => { analyser.getFloatTimeDomainData(values); let square = 0; for(const v of values) square += v*v; return Math.sqrt(square/values.length); };
    let effectIndex = 0;
    while (performance.now() - started < 24600) {
      const elapsed = performance.now() - started;
      while(effectIndex < effectAt.length && elapsed >= effectAt[effectIndex][0]) {
        const [at,key] = effectAt[effectIndex++]; sound.effect(key);
        for (const element of elements) if (!connected.has(element)) { const node = context.createMediaElementSource(element); node.connect(mix); connected.add(element); effectNodes.push(node); }
        effects.push({elapsedMilliseconds: elapsed, key, musicCursor: music.currentTime, musicPaused: music.paused});
      }
      sound.background('castle');
      if(elapsed > 250) samples.push({elapsedMilliseconds: elapsed, cursor: music.currentTime, paused: music.paused, bgmRms: energy(bgm), mixedRms: energy(mix)});
      await wait(25);
    }
    const loops = samples.slice(1).filter((sample,index) => sample.cursor + .1 < samples[index].cursor);
    const beforePause = music.currentTime; sound.pauseMusic(); await wait(150); const afterPause = music.currentTime;
    await sound.resumeMusic('castle', true); const afterResume = sound.snapshot();
    sound.toggle(); const muted = sound.snapshot(); await wait(100); sound.toggle(); await wait(150); const unmuted = sound.snapshot();
    await sound.background('overworld'); await wait(250); const roomChange = sound.snapshot();
    sound.stopMusic(); await wait(100); const stopped = sound.snapshot();
    await context.close(); window.Audio = NativeAudio;
    return {interrupted,recovered,loopCount:loops.length,loopCursorObservations:loops,effects,sampleCount:samples.length,
      minimumBgmRms:Math.min(...samples.map(s=>s.bgmRms)), minimumMixedRms:Math.min(...samples.map(s=>s.mixedRms)),
      quietBgmSamples:samples.filter(s=>s.bgmRms<.00001), pausedSamples:samples.filter(s=>s.paused),
      pause:{beforePause,afterPause}, afterResume,muted,unmuted,roomChange,stopped,
      backgroundElementCount:elements.filter(a=>a.loop).length,musicGain:music.volume,effectGains:elements.filter(a=>!a.loop).map(a=>a.volume),
      contextSampleRate:context.sampleRate,allSamples:samples};
  })()`;
  const evaluated = await call('Runtime.evaluate', {expression, awaitPromise: true, returnByValue: true});
  assert(!evaluated.exceptionDetails, JSON.stringify(evaluated.exceptionDetails));
  const result = evaluated.result.value;
  assert.equal(result.interrupted.lastError, 'AbortError', 'A native pending play was genuinely interrupted');
  assert.equal(result.interrupted.blocked, false);
  assert.equal(result.recovered.playing, true);
  assert(result.loopCount >= 3, 'Observe three real decoded loop wraps');
  assert(result.minimumBgmRms > .01);
  assert.equal(result.quietBgmSamples.length, 0);
  assert.equal(result.pausedSamples.length, 0);
  assert(Math.abs(result.pause.afterPause - result.pause.beforePause) < .03);
  assert(result.afterResume.playing && !result.muted.playing && result.unmuted.playing);
  assert.equal(result.roomChange.track, 'overworld'); assert(result.roomChange.playing);
  assert.equal(result.stopped.track, ''); assert(!result.stopped.playing);
  assert.equal(result.backgroundElementCount, 1); assert.equal(result.musicGain, .35);
  const report = {format: 'real-chromium-music-continuity-v1', createdUtc: new Date().toISOString(),
    browser: spawnSync('chromium', ['--version'], {encoding: 'utf8'}).stdout.trim(),
    scope: 'Actual native HTMLAudioElement AbortError, source decoding, three loop wraps and Web Audio BGM/mix analyser samples; neutral audio fixture on local HTTP',
    autoplayPolicy: 'no-user-gesture-required for this controlled fixture',
    limitations: ['No personal listening or physical audio-device test', 'No full gameplay replay', '25ms analyser polls use a 2048-sample window and do not prove sub-window acoustic continuity'],
    passed: true, result};
  const output = process.argv[2];
  if (output) { await fs.mkdir(path.dirname(path.resolve(output)), {recursive: true}); await fs.writeFile(output, JSON.stringify(report, null, 2) + '\n'); }
  const {allSamples, ...summary} = result; console.log(JSON.stringify({...report, result: summary}, null, 2));
} finally {
  socket?.close(); browser.kill('SIGTERM'); await new Promise(resolve => server.close(resolve));
  await pause(100); await fs.rm(temporary, {recursive: true, force: true});
}
