// Snapshot of effect mappings already present in atlas/editor-audio.mjs.
// These are existing game recordings, not newly authored audio or original
// Stone Citadel / SMM2 walkthrough audio. Only files inside the supplied asset
// directory are eligible. NATIVE_EFFECTS contains only one-shot feedback;
// MUSIC_EVENTS and MUSIC_ASSETS separately declare eligible background tracks.
export const NATIVE_EFFECTS = Object.freeze({
  checkpoint: 'smm2-smb1-smb3-checkpoint.wav', cannon: 'bowser_fire.mp3', pause: 'pause.mp3',
  flag: 'flag.mp3', world_clear: 'world_clear.mp3', bowser_fall: 'bowser_fall.mp3',
  bowser_fire: 'bowser_fire.mp3', jump_super: 'jump_super.mp3',
  gameover: 'gameover.mp3', life: 'oneup.mp3', fire: 'fire.mp3', bump: 'bump.mp3',
  break: 'break.mp3', appear: 'appear.mp3', powerup: 'powerup.mp3',
  kick: 'kick.mp3', jump: 'jump_small.mp3', pickup: 'coin.mp3', death: 'death.mp3',
  hurt: 'hurt.mp3', portal: 'pipe.mp3', complete: 'clear.mp3', stomp: 'stomp.wav'
});

export const MUSIC_EVENTS = Object.freeze(new Set([
  'bill_theme', 'ghost_house_night', 'castle', 'underwater', 'hurry_castle', 'hurry_underwater',
  'hurry_overworld', 'hurry_underworld', 'hurry_star', 'hurry', 'star',
  'overworld', 'underworld'
]));
export const MUSIC_ASSETS = Object.freeze(new Set([
  'contra-jungle-nes.ogg', 'ghost-house-night-loop.wav', 'castle.mp3', 'underwater.mp3', 'hurry_castle.mp3',
  'hurry_underwater.mp3', 'hurry_overworld.mp3', 'hurry_underworld.mp3',
  'hurry_star.mp3', 'hurry.mp3', 'star.mp3', 'overworld.mp3', 'underworld.mp3'
]));

export const MAPPING_NOTES = Object.freeze({
  checkpoint: 'Shared SMM/SMM2 SMB1+SMB3 checkpoint sample decoded without PCM changes; see CHECKPOINT_AUDIO_PROVENANCE.json.',
  cannon: 'The existing game reuses bowser_fire.mp3 for cannon feedback; local approximation.',
  flag: 'One-shot native effect/jingle. No background music is mixed.',
  complete: 'One-shot native clear jingle. No background music is mixed.'
});
