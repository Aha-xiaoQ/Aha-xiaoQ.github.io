import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {mixEventPCM, verifyEncodedAudio, sha256, LIMITS as EFFECT_LIMITS, NATIVE_EFFECTS} from './mix-native-event-audio.mjs';
import {MUSIC_EVENTS, MUSIC_ASSETS} from './native-effects.mjs';
import {audioFiles as RUNTIME_AUDIO_FILES} from '../atlas/editor-audio.mjs';

const RATE = 48000, CHANNELS = 2;
const BASENAME = /^[A-Za-z0-9][A-Za-z0-9_.-]*\.(?:mp3|wav|ogg|m4a)$/i;
export const SCENE_AUDIO_LIMITS = Object.freeze({...EFFECT_LIMITS,
  musicIntervalCount: 20000, audioMappingCount: 128, musicAssetSeconds: 120,
  assetBytes: 32 * 1024 * 1024, cachedClipBytes: 96 * 1024 * 1024,
  mixedInterleavedValues: 128 * 1024 * 1024, reportBytes: 32 * 1024 * 1024,
  encodedBytes: 32 * 1024 * 1024});
export const SCENE_SOURCE_PROVENANCE = 'Existing private native game BGM/effect recordings, reused as separately licensed third-party material. Active native room/theme segments select their existing local files. No original walkthrough audio is fetched, extracted, sampled, or mixed.';

function command(binary, args, maxBuffer = 1024 * 1024) {
  const result = spawnSync(binary, args, {encoding: null, maxBuffer,
    timeout: SCENE_AUDIO_LIMITS.processTimeoutMs, windowsHide: true});
  if (result.error) throw result.error;
  assert.equal(result.status, 0, `${binary} failed: ${result.stderr?.toString().slice(-4000)}`);
  return result.stdout;
}

function floats(bytes) {
  assert(bytes.length > 0 && bytes.length % (CHANNELS * 4) === 0, 'Invalid stereo f32le byte length');
  assert.equal(new Uint8Array(new Uint16Array([1]).buffer)[0], 1, 'A little-endian host is required');
  const copy = new Uint8Array(bytes.length); copy.set(bytes);
  return new Float32Array(copy.buffer);
}

function validate({events, fps, duration, musicIntervals, audioFiles, musicGain, effectGain}) {
  assert(Array.isArray(events) && events.length <= EFFECT_LIMITS.eventCount, 'events exceeds bounded array size');
  let soundCount = 0;
  for (const event of events) {
    assert(event && typeof event === 'object' && !Array.isArray(event), 'Each event must be an object');
    if (event.type !== 'sound') continue;
    soundCount++;
    assert(Number.isSafeInteger(event.frame) && event.frame >= 0, 'Sound frame must be a nonnegative zero-based integer');
    assert(typeof event.event === 'string' && event.event.length > 0 && event.event.length <= 100, 'Invalid sound event name');
  }
  assert(soundCount <= EFFECT_LIMITS.soundEventCount, 'Too many sound events');
  assert(Number.isFinite(fps) && fps >= 1 && fps <= 240, 'fps must be between 1 and 240');
  assert(Number.isFinite(duration) && duration > 0 && duration <= EFFECT_LIMITS.durationSeconds, 'duration must be >0 and <=600 seconds');
  for (const [name, gain] of [['musicGain', musicGain], ['effectGain', effectGain]])
    assert(Number.isFinite(gain) && gain >= 0 && gain <= 1, `${name} must be between 0 and 1`);
  const sampleFrames = Math.round(duration * RATE);
  assert(sampleFrames > 0 && sampleFrames * CHANNELS * 4 <= EFFECT_LIMITS.pcmBytes, 'PCM allocation exceeds limit');
  assert(audioFiles && typeof audioFiles === 'object' && !Array.isArray(audioFiles), 'audioFiles must be an object');
  assert(Object.keys(audioFiles).length <= SCENE_AUDIO_LIMITS.audioMappingCount, 'Too many audioFiles mappings');
  for (const [key, value] of Object.entries(audioFiles)) {
    assert(key.length > 0 && key.length <= 100 && typeof value === 'string' && value.length <= 256, 'Invalid audioFiles entry');
  }
  const musicAssets = new Set([...MUSIC_ASSETS, 'castle-loop.wav']);
  for (const key of MUSIC_EVENTS) if (Object.hasOwn(audioFiles, key)) musicAssets.add(audioFiles[key]);
  const mapping = {};
  // Runtime also contains character-specific assets outside classic-audio. Only
  // the established native-effect keys and explicitly active music are eligible.
  for (const key of Object.keys(NATIVE_EFFECTS)) if (Object.hasOwn(audioFiles, key)) {
    assert(BASENAME.test(audioFiles[key]), 'Effect assets must be contained local audio basenames');
    assert(!musicAssets.has(audioFiles[key]), `Effect key cannot map to a background asset: ${key}`);
    mapping[key] = audioFiles[key];
  }
  assert(Array.isArray(musicIntervals) && musicIntervals.length <= SCENE_AUDIO_LIMITS.musicIntervalCount, 'musicIntervals exceeds bounded array size');
  let previousEnd = 0;
  const normalized = musicIntervals.map((interval, index) => {
    assert(interval && typeof interval === 'object' && !Array.isArray(interval), 'Music interval must be an object');
    const {startFrame, endFrame, key} = interval;
    assert(Number.isSafeInteger(startFrame) && Number.isSafeInteger(endFrame) && startFrame >= 0 && endFrame > startFrame,
      'Music ranges must use nonnegative integer frames and a greater endExclusive frame');
    assert(startFrame >= previousEnd, 'Music ranges must be sorted and nonoverlapping');
    assert(endFrame <= duration * fps + 1e-7, 'Music range exceeds duration');
    assert(key === null || (typeof key === 'string' && MUSIC_EVENTS.has(key)), 'Unknown music key; use null for explicit silence');
    if (key !== null) {
      assert(Object.hasOwn(audioFiles, key), `Missing audioFiles mapping for music key: ${key}`);
      assert(BASENAME.test(audioFiles[key]), 'Music assets must be contained local audio basenames');
    }
    previousEnd = endFrame;
    const startSampleFrame = Math.round(startFrame / fps * RATE), endSampleFrame = Math.round(endFrame / fps * RATE);
    assert(endSampleFrame <= sampleFrames, 'Music sample boundary exceeds duration');
    return {sourceIntervalIndex: index, startFrame, endFrame, key,
      startSampleFrame, endSampleFrame, sampleFrames: endSampleFrame - startSampleFrame,
      asset: key === null ? null : audioFiles[key]};
  });
  return {sampleFrames, mapping, normalized};
}

function checkClip(clip, name, maxSeconds) {
  assert(clip instanceof Float32Array && clip.length > 0 && clip.length % CHANNELS === 0, `Invalid PCM clip: ${name}`);
  assert(clip.length / CHANNELS <= maxSeconds * RATE, `Decoded asset exceeds bounds: ${name}`);
  for (const sample of clip) assert(Number.isFinite(sample) && Math.abs(sample) <= 32, `Nonfinite/extreme asset PCM: ${name}`);
}

function statistics(pcm, clamp = false) {
  let square = 0, peak = 0, peakBeforeClamp = 0, clippedInterleavedValues = 0;
  for (let i = 0; i < pcm.length; i++) {
    assert(Number.isFinite(pcm[i]), 'Nonfinite mixed PCM');
    peakBeforeClamp = Math.max(peakBeforeClamp, Math.abs(pcm[i]));
    if (Math.abs(pcm[i]) > 1) clippedInterleavedValues++;
    if (clamp) pcm[i] = Math.max(-1, Math.min(1, pcm[i]));
    peak = Math.max(peak, Math.abs(pcm[i])); square += pcm[i] ** 2;
  }
  return {finitePCM: true, peakBeforeClamp, peak, clippedInterleavedValues,
    clippedFraction: clippedInterleavedValues / pcm.length, rms: Math.sqrt(square / pcm.length)};
}

/** Pure scene mixer. clips contains decoded 48kHz stereo Float32 assets.
 * Every interval is an independent active playback segment and resets its cursor
 * to zero, including adjacent same-key segments. Omitted and null gaps are silent.
 * Effects use the sibling helper's unchanged event classification and timing.
 */
export function mixScenePCM({events, fps, duration, clips, musicIntervals,
  audioFiles = RUNTIME_AUDIO_FILES, musicGain = .35, effectGain = .65}) {
  const {sampleFrames, mapping, normalized} = validate({events, fps, duration, musicIntervals, audioFiles, musicGain, effectGain});
  assert(clips instanceof Map, 'clips must be a Map');
  // Gain zero supplies the authoritative effects schedule and its bounded empty
  // output buffer. Sum source clips below so there is only one final hard clamp.
  const {pcm, report: effectSchedule} = mixEventPCM({events, fps, duration, clips, mapping, gain: 0});
  const usedNames = new Set(effectSchedule.events.map(event => event.asset));
  for (const interval of normalized) if (interval.asset) usedNames.add(interval.asset);
  assert(usedNames.size <= EFFECT_LIMITS.uniqueAssets, 'Too many active scene assets');
  let cachedClipBytes = 0;
  for (const name of usedNames) {
    assert(clips.has(name), `Active music asset unavailable: ${name}`);
    checkClip(clips.get(name), name, normalized.some(interval => interval.asset === name) ? SCENE_AUDIO_LIMITS.musicAssetSeconds : EFFECT_LIMITS.assetSeconds);
    cachedClipBytes += clips.get(name).byteLength;
    assert(cachedClipBytes <= SCENE_AUDIO_LIMITS.cachedClipBytes, 'Aggregate decoded asset cache exceeds limit');
  }
  let mixedInterleavedValues = 0;
  for (const event of effectSchedule.events) {
    const clip = clips.get(event.asset), length = event.mixedSampleFrames * CHANNELS;
    mixedInterleavedValues += length;
    assert(mixedInterleavedValues <= SCENE_AUDIO_LIMITS.mixedInterleavedValues, 'Aggregate mixing work exceeds limit');
    for (let i = 0; i < length; i++) pcm[event.interleavedSampleOffset + i] += clip[i] * effectGain;
  }
  const effectStatistics = statistics(pcm);
  const musicTimeline = [], musicSilentSampleSpans = [], musicSourceQuietSampleSpans = [];
  let previousSampleEnd = 0, musicSquare = 0, musicPeak = 0, musicActiveSampleFrames = 0;
  for (const interval of normalized) {
    if (interval.startSampleFrame > previousSampleEnd) musicSilentSampleSpans.push({startSampleFrame: previousSampleEnd,
      endSampleFrame: interval.startSampleFrame, reason: 'no-active-native-music'});
    previousSampleEnd = interval.endSampleFrame;
    if (interval.key === null) {
      musicTimeline.push({...interval, status: 'explicit-silence', sourceCursorStartSampleFrame: null});
      musicSilentSampleSpans.push({startSampleFrame: interval.startSampleFrame,
        endSampleFrame: interval.endSampleFrame, reason: 'explicit-null-interval'});
      continue;
    }
    const clip = clips.get(interval.asset), sourceSampleFrames = clip.length / CHANNELS;
    mixedInterleavedValues += interval.sampleFrames * CHANNELS;
    assert(mixedInterleavedValues <= SCENE_AUDIO_LIMITS.mixedInterleavedValues, 'Aggregate mixing work exceeds limit');
    musicActiveSampleFrames += interval.sampleFrames;
    const startValue = interval.startSampleFrame * CHANNELS, endValue = interval.endSampleFrame * CHANNELS;
    // Measure the BGM contribution before effects are added. Overall mixed RMS
    // alone cannot reveal a missing song when frequent one-shots fill the gap.
    const windowSampleFrames = 480, quietRmsThreshold = .00001;
    let windowSquare = 0, windowValues = 0, windowStart = interval.startSampleFrame,
      minimumWindowRms = Infinity, maximumWindowRms = 0, measuredWindows = 0, quietSampleFrames = 0, quietSpan = null;
    for (let value = startValue, cursor = 0; value < endValue; value++, cursor++) {
      const sample = clip[cursor % clip.length] * musicGain;
      pcm[value] += sample; musicSquare += sample ** 2; musicPeak = Math.max(musicPeak, Math.abs(sample));
      windowSquare += sample ** 2; windowValues++;
      if (windowValues === windowSampleFrames * CHANNELS || value === endValue - 1) {
        const rms = Math.sqrt(windowSquare / windowValues), windowEnd = windowStart + windowValues / CHANNELS;
        minimumWindowRms = Math.min(minimumWindowRms, rms); maximumWindowRms = Math.max(maximumWindowRms, rms); measuredWindows++;
        if (rms < quietRmsThreshold) {
          quietSampleFrames += windowValues / CHANNELS;
          if (quietSpan?.endSampleFrame === windowStart) quietSpan.endSampleFrame = windowEnd;
          else { quietSpan = {sourceIntervalIndex: interval.sourceIntervalIndex, key: interval.key,
            startSampleFrame: windowStart, endSampleFrame: windowEnd, reason: 'bgm-contribution-below-rms-threshold'};
            musicSourceQuietSampleSpans.push(quietSpan); }
        } else quietSpan = null;
        windowStart = windowEnd; windowSquare = 0; windowValues = 0;
      }
    }
    musicTimeline.push({...interval, status: 'looped', sourceCursorStartSampleFrame: 0,
      sourceSampleFrames, sourceDurationSeconds: sourceSampleFrames / RATE,
      completeLoopCount: Math.floor(interval.sampleFrames / sourceSampleFrames),
      sourceCursorEndSampleFrame: interval.sampleFrames % sourceSampleFrames,
      musicEnergy: {windowSampleFrames, windowSeconds: windowSampleFrames / RATE, quietRmsThreshold,
        measuredWindows, minimumWindowRms, maximumWindowRms, quietSampleFrames,
        scope: 'Scaled BGM contribution only; independent of one-shot effects; final partial window included'},
      seamMaximumChannelStep: Math.max(...Array.from({length: CHANNELS}, (_, channel) => Math.abs(clip[channel] - clip[clip.length - CHANNELS + channel])))});
  }
  if (previousSampleEnd < sampleFrames) musicSilentSampleSpans.push({startSampleFrame: previousSampleEnd,
    endSampleFrame: sampleFrames, reason: 'no-active-native-music'});
  const finalStatistics = statistics(pcm, true);
  return {pcm, report: {...effectSchedule, ...finalStatistics, gain: effectGain, effectGain, musicGain,
    format: 'native-scene-audio-mix-v1', effectStatistics, effectPCMClampedBeforeSceneSum: false,
    knownBackgroundMusicIncluded: musicActiveSampleFrames > 0 && musicGain > 0,
    musicTimeline, musicSilentSampleSpans, musicSourceQuietSampleSpans, musicActiveSampleFrames,
    musicRmsAcrossDuration: Math.sqrt(musicSquare / pcm.length), musicPeak,
    musicInsertionTiming: 'round(zeroBasedFrame / fps * 48000); endExclusive; cursor resets to zero at every supplied segment',
    musicLoopPolicy: 'Repeat decoded 48kHz stereo asset verbatim without extra seam edits or fades; null and unlisted gaps have zero BGM',
    mixPolicy: 'Sum raw native effect clips * effectGain and active looping music * musicGain, then hard-clamp once',
    backgroundMusicPolicy: 'Only native active frame intervals select BGM; event keys never invent a music interval',
    pcmSha256: sha256(new Uint8Array(pcm.buffer)), cachedClipBytes, mixedInterleavedValues,
    originalWalkthroughAudioUsed: false, sourceProvenance: SCENE_SOURCE_PROVENANCE,
    originalSMM2AudioPolicy: 'No waveform from the reference walkthrough video is fetched, extracted, or mixed.'}};
}

async function loadAssets(options) {
  const {mapping, normalized} = validate(options), root = await fs.realpath(options.assetDirectory);
  const names = new Map();
  for (const event of options.events) if (event.type === 'sound' && Object.hasOwn(mapping, event.event)) names.set(mapping[event.event], 'effect');
  for (const interval of normalized) if (interval.asset) names.set(interval.asset, 'music');
  assert(names.size <= EFFECT_LIMITS.uniqueAssets, 'Too many active scene assets');
  const clips = new Map(), assets = [], errors = [], sourceInodes = new Set();
  let cachedBytes = 0;
  for (const [name, role] of names) {
    let filename;
    try { filename = await fs.realpath(path.join(root, name)); }
    catch (error) {
      if (error.code !== 'ENOENT') throw error;
      assert(role !== 'music', `Active music asset unavailable: ${name}`);
      errors.push({asset: name, reason: 'missing-file'}); continue;
    }
    assert.equal(path.dirname(filename), root, `Asset escapes supplied directory: ${name}`);
    const info = await fs.stat(filename);
    assert(info.isFile() && info.size > 0 && info.size <= SCENE_AUDIO_LIMITS.assetBytes, `Asset file exceeds bounds: ${name}`);
    sourceInodes.add(`${info.dev}:${info.ino}`);
    const before = await fs.readFile(filename), sourceSha256 = sha256(before);
    const seconds = role === 'music' ? SCENE_AUDIO_LIMITS.musicAssetSeconds : EFFECT_LIMITS.assetSeconds;
    const bytes = command('ffmpeg', ['-nostdin', '-hide_banner', '-loglevel', 'error', '-i', filename,
      '-vn', '-t', String(seconds + 1 / RATE), '-f', 'f32le', '-ar', String(RATE), '-ac', String(CHANNELS), 'pipe:1'],
      (seconds + 1) * RATE * CHANNELS * 4);
    const clip = floats(bytes); checkClip(clip, name, seconds);
    cachedBytes += clip.byteLength;
    assert(cachedBytes <= SCENE_AUDIO_LIMITS.cachedClipBytes, 'Aggregate decoded asset cache exceeds limit');
    assert(clip.some(value => Math.abs(value) > .00001), `Empty/silent scene asset: ${name}`);
    assert.equal(sha256(await fs.readFile(filename)), sourceSha256, `Asset changed during decode: ${name}`);
    clips.set(name, clip);
    assets.push({asset: name, role, resolvedPath: filename, sourceSha256, sourceBytes: before.length,
      decodedSampleRate: RATE, decodedChannels: CHANNELS, decodedSampleFrames: clip.length / CHANNELS,
      decodedDurationSeconds: clip.length / CHANNELS / RATE, decodedPcmSha256: sha256(bytes),
      ...(role === 'music' ? {sourceProvenance: name === 'castle-loop.wav' ? SCENE_SOURCE_PROVENANCE : 'Existing native game background recording; separately licensed third-party private material.'} : {})});
  }
  return {root, clips, assets, errors, sourceInodes};
}

function defaults(options) {
  const result = {audioFiles: RUNTIME_AUDIO_FILES, musicGain: .35, effectGain: .65, overwrite: false, ...options};
  // Public async calls own a stable snapshot across source decode/verification.
  // Callers can continue their replay without changing the promised mix inputs.
  result.events = structuredClone(result.events);
  result.musicIntervals = structuredClone(result.musicIntervals);
  result.audioFiles = structuredClone(result.audioFiles);
  return result;
}

async function assertDestinations(output, loaded, overwrite) {
  const sourcePaths = new Set(loaded.assets.map(asset => asset.resolvedPath));
  for (const destination of [output, output + '.report.json']) {
    const resolved = path.join(await fs.realpath(path.dirname(destination)), path.basename(destination));
    assert(!sourcePaths.has(resolved), `Output aliases an input audio asset: ${destination}`);
    try {
      const info = await fs.lstat(destination);
      assert(!info.isSymbolicLink(), `Output destination must not be a symbolic link: ${destination}`);
      assert(!loaded.sourceInodes.has(`${info.dev}:${info.ino}`), `Output hard-links an input audio asset: ${destination}`);
      assert(overwrite, `Output already exists: ${destination}`);
    } catch (error) { if (error.code !== 'ENOENT') throw error; }
  }
}

function verifySceneAAC(output, pcm, report) {
  // Continuous BGM means effects are not acoustically isolated. Verify the
  // complete combined waveform; keep effect timeline metadata in the report.
  const verification = verifyEncodedAudio(output, pcm, {...report, events: report.musicActiveSampleFrames ? [] : report.events});
  return {...verification, expectedPCM: 'Complete combined scene music and native-effect timeline',
    eventTimingComparedInCombinedPCM: true};
}

/** Encode one audio-only AAC M4A plus .report.json. Never reads video audio. */
export async function mixNativeSceneAudio(rawOptions) {
  const options = defaults(rawOptions); validate(options);
  assert(typeof options.assetDirectory === 'string' && typeof options.outputPath === 'string', 'assetDirectory and outputPath are required');
  assert(typeof options.overwrite === 'boolean', 'overwrite must be boolean');
  const output = path.resolve(options.outputPath), reportPath = output + '.report.json';
  assert.equal(path.extname(output).toLowerCase(), '.m4a', 'outputPath must end in .m4a');
  await fs.mkdir(path.dirname(output), {recursive: true});
  const loaded = await loadAssets(options); await assertDestinations(output, loaded, options.overwrite);
  const {pcm, report: mixReport} = mixScenePCM({...options, clips: loaded.clips});
  const temp = await fs.mkdtemp(path.join(path.dirname(output), '.native-scene-audio-'));
  try {
    const tempPCM = path.join(temp, 'scene.f32le'), tempAAC = path.join(temp, 'scene.m4a'), tempReport = path.join(temp, 'report.json');
    await fs.writeFile(tempPCM, new Uint8Array(pcm.buffer));
    command('ffmpeg', ['-nostdin', '-hide_banner', '-loglevel', 'error', '-y', '-f', 'f32le',
      '-ar', String(RATE), '-ac', String(CHANNELS), '-i', tempPCM, '-c:a', 'aac', '-b:a', '160k',
      '-t', String(mixReport.pcmDurationSeconds), '-movflags', '+faststart', tempAAC]);
    const verification = verifySceneAAC(tempAAC, pcm, mixReport);
    for (const asset of loaded.assets) assert.equal(sha256(await fs.readFile(asset.resolvedPath)), asset.sourceSha256, `Asset changed during mix: ${asset.asset}`);
    const bytes = await fs.readFile(tempAAC);
    assert(bytes.length <= SCENE_AUDIO_LIMITS.encodedBytes, 'Encoded audio exceeds limit');
    const report = {...mixReport, assetDirectory: loaded.root, audioFiles: options.audioFiles,
      audioFilesSha256: sha256(JSON.stringify(options.audioFiles)), eventInputSha256: sha256(JSON.stringify(options.events)),
      musicIntervals: options.musicIntervals, musicIntervalsSha256: sha256(JSON.stringify(options.musicIntervals)),
      assets: loaded.assets, assetErrors: loaded.errors, outputPath: output, reportPath,
      outputBytes: bytes.length, outputSha256: sha256(bytes), verification, limits: SCENE_AUDIO_LIMITS,
      limitations: [
        'BGM timing comes only from the supplied active native frame intervals; correctness of the replay must be verified separately.',
        'AAC is lossy and may add pre-echo and trailing packet padding. Missing effects are reported; missing active music is an error.',
        'Repeated assets retain their existing loop boundary; this helper adds no edits, fades, or invented replacement audio.',
        'This verifies a private workshop scene track, not original SMM2 audio fidelity, asset rights, or audible browser playback.'
      ]};
    const reportJSON = JSON.stringify(report, null, 2) + '\n';
    assert(Buffer.byteLength(reportJSON) <= SCENE_AUDIO_LIMITS.reportBytes, 'Report exceeds limit');
    await fs.writeFile(tempReport, reportJSON);
    await assertDestinations(output, loaded, options.overwrite);
    if (options.overwrite) { await fs.rename(tempAAC, output); await fs.rename(tempReport, reportPath); }
    else { await fs.copyFile(tempAAC, output, fs.constants.COPYFILE_EXCL); await fs.copyFile(tempReport, reportPath, fs.constants.COPYFILE_EXCL); }
    return report;
  } finally { await fs.rm(temp, {recursive: true, force: true}); }
}

/** Read-only: rebuild expected PCM, verify inputs, fully decode the existing AAC,
 * and return its packet hash for checking against the muxed movie audio. */
export async function verifyNativeSceneAudio(rawOptions) {
  const options = defaults(rawOptions); validate(options);
  assert(typeof options.assetDirectory === 'string' && typeof options.outputPath === 'string', 'assetDirectory and outputPath are required');
  const output = path.resolve(options.outputPath);
  assert.equal(path.extname(output).toLowerCase(), '.m4a', 'outputPath must end in .m4a');
  const reportInfo = await fs.stat(output + '.report.json'), encodedInfo = await fs.stat(output);
  assert(reportInfo.size <= SCENE_AUDIO_LIMITS.reportBytes && encodedInfo.size <= SCENE_AUDIO_LIMITS.encodedBytes, 'Existing scene output exceeds bounds');
  const recorded = JSON.parse(await fs.readFile(output + '.report.json', 'utf8'));
  assert.equal(recorded.format, 'native-scene-audio-mix-v1');
  assert.equal(recorded.fps, options.fps, 'fps differs');
  assert.equal(recorded.requestedDurationSeconds, options.duration, 'duration differs');
  assert.equal(recorded.musicGain, options.musicGain, 'music gain differs');
  assert.equal(recorded.effectGain, options.effectGain, 'effect gain differs');
  assert.equal(recorded.eventInputSha256, sha256(JSON.stringify(options.events)), 'Event inputs differ');
  assert.equal(recorded.musicIntervalsSha256, sha256(JSON.stringify(options.musicIntervals)), 'Music intervals differ');
  assert.equal(recorded.audioFilesSha256, sha256(JSON.stringify(options.audioFiles)), 'Runtime audioFiles mapping differs');
  const before = sha256(await fs.readFile(output));
  assert.equal(before, recorded.outputSha256, 'Existing AAC file differs from its report');
  const loaded = await loadAssets(options), {pcm, report} = mixScenePCM({...options, clips: loaded.clips});
  assert.equal(loaded.root, recorded.assetDirectory, 'Asset directory differs');
  assert.equal(report.pcmSha256, recorded.pcmSha256, 'Expected scene PCM differs from the original mix');
  assert.deepEqual(report.timeline, recorded.timeline, 'Native effect schedule differs');
  assert.deepEqual(report.musicTimeline, recorded.musicTimeline, 'Native music schedule differs');
  for (const key of ['musicSilentSampleSpans', 'musicSourceQuietSampleSpans', 'knownBackgroundMusicIncluded', 'musicActiveSampleFrames',
    'musicRmsAcrossDuration', 'musicPeak', 'effectStatistics', 'peakBeforeClamp', 'peak',
    'clippedInterleavedValues', 'clippedFraction', 'rms', 'sampleFrames', 'cachedClipBytes', 'mixedInterleavedValues'])
    assert.deepEqual(report[key], recorded[key], `Scene report field differs: ${key}`);
  assert.deepEqual(loaded.assets, recorded.assets, 'Source asset hashes or decode differ');
  assert.deepEqual(loaded.errors, recorded.assetErrors, 'Unavailable effects differ');
  const verification = verifySceneAAC(output, pcm, report);
  assert.equal(verification.aacPacketSha256, recorded.verification.aacPacketSha256, 'AAC packet hash differs');
  assert.equal(sha256(await fs.readFile(output)), before, 'AAC changed during verification');
  for (const asset of loaded.assets) assert.equal(sha256(await fs.readFile(asset.resolvedPath)), asset.sourceSha256, `Asset changed during verification: ${asset.asset}`);
  return {...recorded, verification, readOnlyReverified: true};
}
