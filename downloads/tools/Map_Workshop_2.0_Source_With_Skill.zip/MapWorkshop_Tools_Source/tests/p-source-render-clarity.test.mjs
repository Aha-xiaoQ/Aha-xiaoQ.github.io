import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createCanvas} from '@napi-rs/canvas';
import {drawObject,drawTile} from '../atlas/editor-art.mjs';
import {drawContraptionsActor,drawContraptionsTile,drawPSwitch} from '../atlas/editor-contraptions-art.mjs';
import {drawSmm2PSwitch} from '../atlas/editor-smm2-p-switch-art.mjs';

const room={setting:'Overworld',map:{width:64,height:64,geometry:[],objects:[]},contraptions:{version:1,pSources:[{id:'neutral-source',pipeId:'neutral-pipe'}]},smm2Mechanics:{version:1,art:{palette:'smb1-overworld-source'}}};
const actor={id:'p-source-neutral-source-0',kind:'p-switch',pSource:'neutral-source',x:16,y:16,w:16,h:16};
const canvas=()=>createCanvas(64,64);
const pixels=c=>c.getContext('2d').getImageData(0,0,64,64).data;
const bounds=c=>{const d=pixels(c),xs=[],ys=[];for(let y=0;y<64;y++)for(let x=0;x<64;x++)if(d[(y*64+x)*4+3]){xs.push(x);ys.push(y);}return xs.length?{x:Math.min(...xs),y:Math.min(...ys),w:Math.max(...xs)-Math.min(...xs)+1,h:Math.max(...ys)-Math.min(...ys)+1}:null;};

test('a pipe-supplied P in a source SMB1 room renders a readable upright P before contact',()=>{
 const actual=canvas(),source=canvas(),legacy=canvas();
 assert(drawContraptionsActor(actual.getContext('2d'),actor,0,room));
 drawSmm2PSwitch(source.getContext('2d'),actor);drawPSwitch(legacy.getContext('2d'),actor);
 assert.deepEqual(pixels(actual),pixels(source));assert.deepEqual(pixels(legacy),pixels(source));
 assert.deepEqual(bounds(actual),{x:16,y:16,w:16,h:16});
 assert.deepEqual([...actual.getContext('2d').getImageData(21,20,1,1).data],[255,255,255,255],'the bounded source P glyph is high-contrast white');
 const shared=canvas();drawObject(shared.getContext('2d'),actor,0,room);assert.deepEqual(pixels(shared),pixels(source),'the editor/player actor dispatch reaches the same source pixels');
});

test('P support bodies remain collision-only in non-desert rooms and never become a visible horizontal platform',()=>{
 const actual=canvas(),body={id:'p-body-'+actor.id,x:16,y:16,w:16,h:16,collision:'oneway',contraptionDevice:true,pBody:true};
 assert(drawContraptionsTile(actual.getContext('2d'),body,room));drawTile(actual.getContext('2d'),body,room);
 assert.equal(bounds(actual),null);assert.equal(body.collision,'oneway');assert.equal(body.h,16);
});

test('the pressed source strip is four pixels at the same base for a live shrunk body or full editor body',()=>{
 const full=canvas(),shrunk=canvas(),shared=canvas();
 const pressed={...actor,pressed:true};drawPSwitch(full.getContext('2d'),pressed);
 drawPSwitch(shrunk.getContext('2d'),{...pressed,y:28,h:4});
 drawObject(shared.getContext('2d'),{...pressed,y:28,h:4},0,room);
 assert.deepEqual(bounds(full),{x:16,y:28,w:16,h:4});
 assert.deepEqual(pixels(full),pixels(shrunk));assert.deepEqual(pixels(shared),pixels(full));
 assert.equal(pressed.y,16);assert.equal(pressed.h,16,'rendering does not mutate collision geometry');
});

test('dead, hidden and removed pipe P actors are consumed by dispatch without drawing a replacement',()=>{
 for(const patch of [{dead:true},{removed:true},{hidden:true},{visible:false}]){const actual=canvas();drawObject(actual.getContext('2d'),{...actor,...patch},0,room);assert.equal(bounds(actual),null);}
});

test('an authored inverted pressed P keeps its strip at the ceiling-facing base',()=>{
 const full=canvas(),shrunk=canvas();
 drawSmm2PSwitch(full.getContext('2d'),{...actor,smm2PSwitch:{phase:'pressed',orientation:'down'}});
 drawSmm2PSwitch(shrunk.getContext('2d'),{...actor,h:4,smm2PSwitch:{phase:'pressed',orientation:'down'}});
 assert.deepEqual(bounds(full),{x:16,y:16,w:16,h:4});assert.deepEqual(pixels(full),pixels(shrunk));
});
