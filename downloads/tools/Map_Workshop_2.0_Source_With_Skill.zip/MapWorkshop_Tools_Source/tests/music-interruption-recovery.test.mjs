import test from 'node:test';
import assert from 'node:assert/strict';
import {createSound} from '../atlas/editor-audio.mjs';
import {installSimulatedAudio} from './fixtures/simulated-audio.mjs';

const flush = async () => { await Promise.resolve(); await Promise.resolve(); };
const abort = () => Object.assign(new Error('Interrupted media playback'), {name: 'AbortError'});

test('interrupted current BGM recovers on an ordinary update with its existing cursor', async () => {
  const audio = installSimulatedAudio();
  try {
    const sound = createSound();
    audio.deferNext(); sound.resumeMusic('castle', true);
    const music = audio.music()[0]; music.currentTime = 5.25;
    audio.pending.shift().reject(abort()); await flush();
    assert.equal(sound.snapshot().lastError, 'AbortError');
    assert.equal(sound.snapshot().blocked, false);
    assert.equal(sound.snapshot().playing, false);
    sound.background('castle'); await flush();
    assert.equal(sound.snapshot().playing, true);
    assert.equal(sound.snapshot().lastError, '');
    assert.equal(music.currentTime, 5.25);
    assert.equal(music.playCalls, 2);
    assert.equal(audio.music().length, 1);
    sound.stop();
  } finally { audio.restore(); }
});

test('repeated AbortError is bounded and a later explicit gesture can recover', async () => {
  const audio = installSimulatedAudio();
  try {
    const sound = createSound();
    for (let i = 0; i < 3; i++) {
      audio.deferNext();
      if (i === 0) sound.resumeMusic('castle', true); else sound.background('castle');
      audio.pending.shift().reject(abort()); await flush();
    }
    for (let i = 0; i < 120; i++) sound.background('castle');
    assert.equal(sound.snapshot().blocked, true);
    assert.equal(audio.music()[0].playCalls, 3);
    sound.resumeMusic('castle', true); await flush();
    assert.equal(sound.snapshot().playing, true);
    sound.stop();
  } finally { audio.restore(); }
});

test('actual autoplay-policy denial still waits for a new gesture', async () => {
  const audio = installSimulatedAudio({requireGesture: true});
  try {
    const sound = createSound(); sound.resumeMusic('castle'); await flush();
    for (let i = 0; i < 120; i++) sound.background('castle');
    assert.equal(sound.snapshot().blocked, true);
    assert.equal(sound.snapshot().lastError, 'NotAllowedError');
    assert.equal(audio.music()[0].playCalls, 1);
    audio.gesture(() => sound.resumeMusic('castle', true)); await flush();
    assert.equal(sound.snapshot().playing, true);
    sound.stop();
  } finally { audio.restore(); }
});

test('pause, mute, stop and newer track suppress interrupted pending playback', async () => {
  const audio = installSimulatedAudio();
  try {
    for (const action of ['pause', 'mute', 'stop', 'newer-track']) {
      const sound = createSound(); audio.deferNext(); sound.resumeMusic('castle', true);
      if (action === 'pause') sound.pauseMusic();
      if (action === 'mute') sound.toggle();
      if (action === 'stop') sound.stopMusic();
      if (action === 'newer-track') sound.background('underworld');
      audio.pending.shift().reject(abort()); await flush();
      if (action === 'newer-track') {
        assert.equal(sound.snapshot().track, 'underworld');
        assert.equal(sound.snapshot().playing, true);
        assert.equal(sound.snapshot().blocked, false);
      } else {
        assert.equal(sound.snapshot().playing, false);
        assert.equal(sound.snapshot().blocked, false);
        assert.equal(sound.snapshot().lastError, '');
      }
      sound.stop();
    }
  } finally { audio.restore(); }
});

test('Boss firing, repeated hit and defeat effects do not pause or reset looping BGM', async () => {
  const audio = installSimulatedAudio();
  try {
    const sound = createSound(); sound.resumeMusic('castle', true); await flush();
    const music = audio.music()[0]; music.currentTime = 7.95;
    for (const key of ['bowser_fire', 'stomp', 'stomp', 'stomp', 'bowser_fall', 'pickup', 'portal']) {
      sound.effect(key); await flush(); sound.background('castle');
      assert.equal(sound.snapshot().playing, true);
      assert.equal(music.currentTime, 7.95);
    }
    music.end();
    assert.equal(music.currentTime, 0);
    assert.equal(sound.snapshot().playing, true);
    assert.equal(music.playCalls, 1);
    assert.equal(music.volume, .35);
    sound.background('overworld'); await flush();
    assert.equal(audio.music()[0], music);
    assert.equal(sound.snapshot().track, 'overworld');
    assert.equal(sound.snapshot().playing, true);
    sound.stop();
  } finally { audio.restore(); }
});
