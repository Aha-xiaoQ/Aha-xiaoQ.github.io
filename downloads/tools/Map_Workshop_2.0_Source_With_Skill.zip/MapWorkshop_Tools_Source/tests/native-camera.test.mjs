import {test} from 'node:test';
import assert from 'node:assert/strict';
import {nativeCamera} from '../atlas/editor-camera.mjs';

test('shared camera preserves the native preview at flat, tall, top and bottom poses',()=>{
 for(const [worldHeight,viewportHeight,y,expected] of [[240,240,194,0],[224,224,194,0],[448,224,400,224],[448,224,280,180],[448,224,80,0],[448,224,-20,0],[448,224,600,224],[160,224,100,0]]){
  const view={height:worldHeight,viewportWidth:384,viewportHeight,cam:128,p:{y}};
  assert.deepEqual(nativeCamera(view),{x:128,y:expected,width:384,height:viewportHeight});
 }
 assert.deepEqual(nativeCamera({height:480,cam:0,p:{y:220}}),{x:0,y:120,width:256,height:240});
});
