import test from 'node:test';
import assert from 'node:assert/strict';
import {createCanvas,loadImage} from '@napi-rs/canvas';
import {fileURLToPath} from 'node:url';
import {blank,parseProject} from '../atlas/editor-model.mjs';
import {drawSmm2Tile,drawSmm2Background} from '../atlas/editor-smm2-art.mjs';
import {setSmm2ArtProfile} from '../atlas/editor-smm2-course-tools.mjs';

function room(){const r=blank('source tile test',512,432).rooms[0];r.smm2Mechanics={version:1,art:{palette:'smb1-underground-source',tileOriginY:8}};return r;}
const bytes=c=>Buffer.from(c.getContext('2d').getImageData(0,0,c.width,c.height).data);
const canvas=()=>createCanvas(64,64);
test('SMB1 Underground opt-in reproduces the actual original PNG bytes at native size',async()=>{
 const im=await loadImage(fileURLToPath(new URL('../atlas/assets/smm2-private/smm1-smb1-underground-ground.original.png',import.meta.url))),expected=canvas(),actual=canvas(),r=room();
 expected.getContext('2d').drawImage(im,0,8);const q={id:'ground',x:0,y:8,w:16,h:16,material:'ground'},before=JSON.stringify({q,r});
 assert.equal(drawSmm2Tile(actual.getContext('2d'),q,r),true);assert.deepEqual(bytes(actual),bytes(expected));assert.equal(JSON.stringify({q,r}),before);
});
test('adjacent source-ground subdivisions keep identical tile phase and clipped pixel bounds',()=>{
 const whole=canvas(),split=canvas(),r=room(),q={id:'wall',x:3,y:5,w:54,h:52,material:'ground'};
 drawSmm2Tile(whole.getContext('2d'),q,r);for(const [x,w]of [[3,18],[21,11],[32,25]])for(const [y,h]of [[5,20],[25,32]])drawSmm2Tile(split.getContext('2d'),{...q,x,w,y,h},r);
 assert.deepEqual(bytes(split),bytes(whole));assert.equal(whole.getContext('2d').getImageData(2,5,1,1).data[3],0);assert.equal(whole.getContext('2d').getImageData(57,10,1,1).data[3],0);
});
test('source art profile persists through real authoring and import while legacy palettes stay untouched',()=>{
 const doc=blank('art round trip',512,432),r=doc.rooms[0];setSmm2ArtProfile(r,'smb1-underground-source',{tileOriginX:0,tileOriginY:8});
 assert.deepEqual(parseProject(JSON.stringify(doc)).rooms[0].smm2Mechanics.art,r.smm2Mechanics.art);
 for(const patch of [{tileOriginY:1.5},{tileOriginX:32769},{tileOriginX:NaN},{unrecognized:true}])assert.throws(()=>setSmm2ArtProfile(r,'smb1-underground-source',patch));
 const q={id:'ground',x:0,y:8,w:16,h:16,material:'ground'};assert.equal(drawSmm2Tile(canvas().getContext('2d'),q,{...r,smm2Mechanics:undefined}),false);
 const bg=canvas();assert.equal(drawSmm2Background(bg.getContext('2d'),r,64,64),true);assert.deepEqual(Array.from(bg.getContext('2d').getImageData(63,63,1,1).data),[0,0,0,255]);
});
