import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {blank} from '../atlas/editor-model.mjs';
import {projectPack} from '../atlas/editor-runtime.mjs';
import {offlineFile} from '../atlas/editor-offline.mjs';
import {play} from '../atlas/editor-play.mjs';
import {audioFiles} from '../atlas/editor-audio.mjs';
import {NATIVE_EFFECTS,MAPPING_NOTES} from '../renderer-audio/native-effects.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';
import {installSimulatedAudio} from './fixtures/simulated-audio.mjs';

const character=JSON.parse(fs.readFileSync(new URL('../atlas/runtime/character.json',import.meta.url)));
const asset=name=>fs.readFileSync(new URL('../atlas/assets/classic-audio/'+name,import.meta.url));
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const meta=JSON.parse(asset('CHECKPOINT_AUDIO_PROVENANCE.json'));
const flush=async()=>{await Promise.resolve();await Promise.resolve();};
function fixture(hidden=false){
 const d=blank('Checkpoint original audio isolation',320,256),r=d.rooms[0];
 r.map.geometry=[{id:'floor',x:0,y:224,w:320,h:32,collision:'solid',material:'ground'}];
 r.map.objects=[{id:'start',kind:'spawn',x:16,y:210,w:10,h:14},{id:'after',kind:'spawn',x:48,y:210,w:10,h:14},{id:'flag',kind:'checkpoint',x:64,y:176,w:16,h:48,targetSpawn:'after'},{id:'danger',kind:'hazard',x:144,y:208,w:32,h:16}];
 r.checkpointVisuals={flag:{version:1,...(hidden?{hidden:true}:{base:true})}};
 return d;
}

test('checkpoint owns a non-silent dedicated WAV with documented source and exact original PCM hash',()=>{
 assert.equal(audioFiles.checkpoint,meta.derivative.file);
 assert.equal(audioFiles.powerup,'powerup.mp3');
 assert.notEqual(audioFiles.checkpoint,audioFiles.powerup);
 const original=asset(meta.source.file),wav=asset(audioFiles.checkpoint);
 assert.equal(hash(original),meta.source.sha256);
 assert.equal(original.toString('ascii',0,4),'OggS');
 assert.equal(hash(wav),meta.derivative.sha256);
 assert.equal(wav.toString('ascii',0,4),'RIFF');assert.equal(wav.toString('ascii',8,12),'WAVE');
 assert.equal(wav.readUInt32LE(4)+8,wav.length);
 assert.equal(wav.toString('ascii',12,16),'fmt ');assert.equal(wav.readUInt16LE(20),1);
 assert.equal(wav.readUInt16LE(22),1);assert.equal(wav.readUInt32LE(24),32000);assert.equal(wav.readUInt16LE(34),16);
 assert.equal(wav.toString('ascii',36,40),'data');assert.equal(wav.readUInt32LE(40),51760);
 const pcm=wav.subarray(44);assert.equal(hash(pcm),meta.derivative.pcm_sha256);
 const frames=pcm.length/2;assert.equal(frames,25880);assert.equal(frames/32000,.80875);
 let square=0,peak=0,nonzero=0;
 for(let i=0;i<pcm.length;i+=2){const raw=pcm.readInt16LE(i),n=raw/32768;square+=n*n;peak=Math.max(peak,Math.abs(n));if(raw)nonzero++;}
 assert.equal(nonzero,meta.derivative.nonzero_sample_frames);assert.equal(nonzero,25878);
 assert(Math.abs(Math.sqrt(square/frames)-meta.derivative.rms)<1e-12);
 assert.equal(peak,meta.derivative.peak);assert(peak>.1&&peak<1);
 assert(meta.identity_evidence.entry_links_to_source_file_page);
 assert(meta.identity_evidence.source_file_page_lists_smm2_usage);
});

test('offline HTML embeds the actual checkpoint WAV bytes and the same runtime mapping',async()=>{
 const d=fixture(),pack=projectPack(d,'main',character,'checkpoint-audio-offline');
 const html=await offlineFile(pack,d.rooms,p=>fs.readFileSync(new URL('../atlas/'+p,import.meta.url),'utf8'),asset);
 const match=html.match(/"checkpoint":"data:audio\/wav;base64,([^"\s]+)"/);
 assert(match,'checkpoint must have an embedded WAV media response');
 assert.deepEqual(Buffer.from(match[1],'base64'),asset(audioFiles.checkpoint));
 const imports=JSON.parse(html.match(/<script type="importmap">([^]*?)<\/script>/)[1]).imports;
 const source=decodeURIComponent(imports['workshop/editor-audio.mjs'].split(',').slice(1).join(','));
 assert(source.includes("checkpoint:'"+audioFiles.checkpoint+"'"));
 assert(!source.includes("checkpoint:'powerup.mp3'"));
 // The source URL belongs in the visible rights/provenance notice. Check the
 // executable audio module and embedded media response, not the whole page.
 assert(!source.includes(meta.source.download_url),'runtime audio does not request the source website');
 assert(html.includes(meta.source.download_url),'offline rights notice retains the original source attribution');
});

test('actual play wiring creates one checkpoint Audio element and does not repeat on dwell or death/respawn',async()=>{
 const dom=installSimulatedPlayDom(),audio=installSimulatedAudio();let session;
 try{
  const d=fixture(),pack=projectPack(d,'main',character,'checkpoint-audio-play');
  const media={checkpoint:'data:audio/wav;base64,'+asset(audioFiles.checkpoint).toString('base64')};
  session=await play(pack,d.rooms,media,{developerMode:false});
  const read=()=>session.screen.querySelector('canvas[aria-label]').workshopRead();
  const flag=()=>read().objects.find(o=>o.id==='flag');
  const calls=()=>audio.calls.filter(c=>c.audio.effectKey==='checkpoint');
  dom.key('ArrowRight');for(let i=0;i<100&&!flag().activated;i++)dom.frames();dom.release('ArrowRight');
  await flush();assert(flag().activated);assert.equal(calls().length,1);
  const a=calls()[0].audio;assert.equal(a.src,media.checkpoint);assert.equal(a.loop,false);assert.equal(a.volume,.65);assert.equal(a.playCalls,1);
  dom.frames(24);await flush();assert.equal(calls().length,1);assert.equal(read().lives,3);
  dom.key('ArrowRight');for(let i=0;i<160&&!read().p.dying;i++)dom.frames();dom.release('ArrowRight');
  assert(read().p.dying);dom.frames(110);assert.equal(read().lives,2);assert.equal(read().checkpoint.spawnId,'after');assert(flag().activated);
  dom.key('ArrowRight');dom.frames(30);dom.release('ArrowRight');await flush();assert.equal(calls().length,1);
  assert.equal(audio.calls.filter(c=>c.audio.effectKey==='powerup').length,0);
 }finally{session?.close();audio.restore();dom.restore();}
});

test('hidden checkpoint keeps its existing silent activation behavior',async()=>{
 const dom=installSimulatedPlayDom(),audio=installSimulatedAudio();let session;
 try{
  const d=fixture(true),pack=projectPack(d,'main',character,'checkpoint-hidden-audio');session=await play(pack,d.rooms,{}, {developerMode:false});
  const read=()=>session.screen.querySelector('canvas[aria-label]').workshopRead();
  dom.key('ArrowRight');for(let i=0;i<100&&read().checkpoint.spawnId!=='after';i++)dom.frames();dom.release('ArrowRight');await flush();
  assert.equal(read().checkpoint.spawnId,'after');assert.equal(audio.calls.filter(c=>c.audio.effectKey==='checkpoint').length,0);
 }finally{session?.close();audio.restore();dom.restore();}
});

test('video event mixer checkpoint mapping agrees with browser audio and no longer claims a power-up approximation',()=>{
 assert.equal(NATIVE_EFFECTS.checkpoint,audioFiles.checkpoint);
 assert(!/powerup|approximation/i.test(MAPPING_NOTES.checkpoint));
 assert(/CHECKPOINT_AUDIO_PROVENANCE/.test(MAPPING_NOTES.checkpoint));
});
