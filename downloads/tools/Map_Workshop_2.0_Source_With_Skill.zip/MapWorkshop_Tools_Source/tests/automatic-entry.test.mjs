import fs from 'node:fs';
import assert from 'node:assert/strict';
import {test} from 'node:test';
import {blank,History,parseProject} from '../atlas/editor-model.mjs';
import {projectPack} from '../atlas/editor-runtime.mjs';
import {createStageCatalog} from '../atlas/runtime/stage-catalog.mjs';
import {createPlatformStage} from '../atlas/editor-mario-stage.mjs';
import {createPlatformMotor} from '../atlas/editor-mario-motor.mjs';
import {setClassicEntryWalk,setClassicFireReward,mountClassicMotionTools} from '../atlas/editor-classic-motion-tools.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';
const character=JSON.parse(fs.readFileSync(new URL('../atlas/runtime/character.json',import.meta.url)));
function fixture(blocked=false){const d=blank('Automatic native pipe fixture',640,240),r=d.rooms[0];r.map.geometry=[{id:'floor',x:0,y:224,w:640,h:16,collision:'solid',material:'ground'},{id:'side',x:320,y:192,w:32,h:32,collision:'solid',material:'pipe-side'},{id:'upright',x:352,y:176,w:32,h:48,collision:'solid',material:'pipe'}];r.map.objects=[{id:'start',kind:'spawn',x:40,y:210,w:10,h:14},{id:'portal',kind:'portal',x:308,y:192,w:16,h:32,targetRoom:'target',targetSpawn:'arrival'}];if(blocked)r.map.geometry.push({id:'obstacle',x:112,y:192,w:16,h:32,collision:'solid',material:'stone'});const target=structuredClone(blank('Destination',640,240).rooms[0]);target.roomId='target';target.map.geometry=[{id:'floor',x:0,y:224,w:640,h:16,collision:'solid',material:'ground'}];target.map.objects=[{id:'arrival',kind:'spawn',x:32,y:210,w:10,h:14}];d.rooms.push(target);setClassicEntryWalk(r,'start','portal');return d;}
function native(d){const events=[],pack=projectPack(d,'main',character,'entry-walk-fixture'),plan=createStageCatalog(pack).plan(pack.stages[0].id,pack.characters[0].id,{allowDraft:true}),stage=createPlatformStage({plan,motor:createPlatformMotor(),visualRooms:d.rooms,manualDeath:false,autoContinue:false,allowWarp:false,emit:(type,data)=>events.push({type,...data})});return {stage,events};}
test('automatic entry really walks/collides into its pipe, then returns control in the destination',()=>{
 const s=native(fixture());let lastX=s.stage.view().p.x,piped=false;
 for(let i=0;i<400&&s.stage.view().roomId==='main';i++){s.stage.step({x:-1,jump:true});const v=s.stage.view();assert.equal(v.lives,3);piped||=!!v.transition;if(v.roomId==='main'&&!v.transition)assert(v.p.x>=lastX);lastX=v.p.x;}
 assert(piped);assert.equal(s.stage.view().roomId,'target');assert(s.events.some(e=>e.event==='entry-walk-start'));const x=s.stage.view().p.x;for(let i=0;i<12;i++)s.stage.step({x:-1});assert(s.stage.view().p.x<x);assert(!s.events.some(e=>e.event==='death'));
});
test('a newly blocked author path releases control after a visible physical stall, rather than softlocking or teleporting',()=>{
 const d=fixture(true),before=structuredClone(d.rooms[0].map.geometry),s=native(d);for(let i=0;i<160&&!s.events.some(e=>e.event==='entry-walk-blocked');i++)s.stage.step({});assert(s.events.some(e=>e.event==='entry-walk-blocked'));assert.equal(s.stage.view().p.x,102);assert.equal(s.stage.view().roomId,'main');assert.deepEqual(d.rooms[0].map.geometry,before);
 s.stage.step({});for(let i=0;i<70;i++)s.stage.step({x:1,jump:true});assert(s.stage.view().p.x>128,'ordinary input now jumps over the actual obstacle');assert.equal(s.stage.view().lives,3);
});
test('the mounted entry controls preserve stable links through undo/reimport and reject missing targets',()=>{
 const ui=installSimulatedPlayDom();try{const d=fixture();delete d.rooms[0].marioModules;const h=new History(d),parent=ui.document.createElement('aside'),room=()=>h.doc.rooms[0],reports=[],t=mountClassicMotionTools({parent,room,change:fn=>h.change(fn),report:s=>reports.push(s)}),get=id=>parent.querySelector('[data-classic-control="'+id+'"]');get('entry-walk-apply').click();assert.deepEqual(room().marioModules.entryWalkToPortal,{spawnId:'start',portalId:'portal'});h.undo();t.refresh();assert.equal(room().marioModules,undefined);h.redo();t.refresh();assert.deepEqual(parseProject(JSON.stringify(h.doc)).rooms[0].marioModules,room().marioModules);const before=JSON.stringify(h.doc);get('entry-portal').value='missing';get('entry-walk-apply').click();assert.equal(JSON.stringify(h.doc),before);assert.equal(reports.length,1);get('entry-walk-remove').click();assert.equal(room().marioModules.entryWalkToPortal,undefined);}finally{ui.restore();}
});
test('the ordinary-enemy fire reward remains an authored optional room rule through UI, undo and import',()=>{
 const ui=installSimulatedPlayDom();try{
  const d=fixture(),h=new History(d),parent=ui.document.createElement('aside'),room=()=>h.doc.rooms[0],reports=[];
  const t=mountClassicMotionTools({parent,room,change:fn=>h.change(fn),report:s=>reports.push(s)}),get=id=>parent.querySelector('[data-classic-control="'+id+'"]');
  get('fire-points').value='200';get('fire-reward-apply').click();assert.equal(room().marioModules.fireKillPoints,200);
  assert.equal(parseProject(JSON.stringify(h.doc)).rooms[0].marioModules.fireKillPoints,200);
  h.undo();t.refresh();assert.equal(room().marioModules.fireKillPoints,undefined);h.redo();t.refresh();
  const before=JSON.stringify(h.doc);get('fire-points').value='-1';get('fire-reward-apply').click();assert.equal(JSON.stringify(h.doc),before);assert.equal(reports.length,1);
  get('fire-reward-remove').click();assert.equal(room().marioModules.fireKillPoints,undefined);setClassicFireReward(room(),200);assert.equal(room().marioModules.fireKillPoints,200);
 }finally{ui.restore();}
});
