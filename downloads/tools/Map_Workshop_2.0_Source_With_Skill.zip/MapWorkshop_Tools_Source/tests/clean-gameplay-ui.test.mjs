import assert from 'node:assert/strict';
import {test} from 'node:test';
import {readFileSync} from 'node:fs';
import {blank} from '../atlas/editor-model.mjs';
import {projectPack} from '../atlas/editor-runtime.mjs';
import {play} from '../atlas/editor-play.mjs';
import {offlineFile} from '../atlas/editor-offline.mjs';
import {createGamepadInput,gamepadLabels} from '../atlas/editor-gamepad.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';

const read=path=>readFileSync(new URL('../atlas/'+path.replace(/^\.\//,''),import.meta.url),'utf8');
const character=JSON.parse(read('./runtime/character.json'));
function fixture({smm2=true}={}){
 const d=blank('Neutral compact UI fixture',640,240),r=d.rooms[0];
 r.map.geometry=[{id:'floor',x:0,y:224,w:640,h:16,collision:'solid',material:'ground'}];
 r.map.objects=[{id:'start',kind:'spawn',x:24,y:210,w:10,h:14}];
 r.playRules={version:1,timeLimit:400,timerFrames:60,viewportWidth:384,viewportHeight:216,cameraAnchor:160};
 if(smm2)r.smm2Mechanics={version:1,art:{palette:'smb1-overworld-source'}};
 return {d,pack:projectPack(d,r.roomId,character,'compact-ui-fixture')};
}

test('opt-in compact UI keeps touch input, menu pause, fullscreen, controller resume, replay and return reachable',async()=>{
 // This fixture exercises the visible mobile pad. Desktop defaults have their own coverage.
 const ui=installSimulatedPlayDom({pointer:'coarse',hover:false,width:390,height:844,maxTouchPoints:5});let session;
 try{
  ui.document.fullscreenEnabled=true;
  const {d,pack}=fixture();session=await play(pack,d.rooms,{},{cleanUi:true,developerMode:false,initialState:{lives:5,coins:12}});
  const screen=session.screen,canvas=screen.querySelector('canvas'),view=()=>canvas.workshopRead(),menu=screen.querySelector('.play-pause-menu'),toggle=screen.querySelector('h2 button'),pad=screen.querySelector('.play-gamepad'),action=id=>screen.querySelector('[data-menu-action="'+id+'"]');
  assert(screen.classList.contains('play-clean-ui'));assert.equal(toggle.textContent,'菜单');assert.equal(screen.querySelector('h2 a').hidden,true);assert.equal(screen.querySelector('.play-controls .row').hidden,true);assert.equal(screen.querySelector('.play-fullscreen-toggle').parentNode,screen.querySelector('h2'),'fullscreen stays directly visible outside the hidden tools row');assert.equal(screen.querySelector('.play-session-help').parentNode,menu);assert.equal(pad.hidden,false);assert.equal(view().lives,5);assert.equal(view().coins,12);
  const right=screen.querySelector('[data-control=right]');right.dispatchEvent({type:'pointerdown',pointerId:1});ui.frames(20);right.dispatchEvent({type:'pointerup',pointerId:1});assert(view().p.x>24,'visible touch controls still drive the actual stage');
  toggle.click();assert.equal(menu.hidden,false);assert.equal(toggle.getAttribute('aria-expanded'),'true');const frozen=view().tick;ui.frames(30);assert.equal(view().tick,frozen,'compact menu actually pauses simulation');
  for(const id of ['restart','close','fullscreen','touch','sound'])assert.equal(action(id).hidden,false,id+' stays reachable');
  screen.requestFullscreen=async()=>{ui.document.fullscreenElement=screen;ui.document.dispatchEvent({type:'fullscreenchange'});};
  ui.document.exitFullscreen=async()=>{ui.document.fullscreenElement=null;ui.document.dispatchEvent({type:'fullscreenchange'});};
  action('fullscreen').click();await Promise.resolve();assert.equal(ui.document.fullscreenElement,screen);assert.equal(pad.hidden,false,'fullscreen never hides essential touch input by default');assert.equal(action('fullscreen').textContent,'退出全屏');
  action('touch').click();assert.equal(pad.hidden,true);assert.equal(action('touch').textContent,'显示触屏手柄');action('touch').click();assert.equal(pad.hidden,false);
  const audio=view().audio.enabled;action('sound').click();ui.frames(2);assert.equal(view().audio.enabled,!audio);
  const controller={id:'Xbox Wireless Controller',index:0,connected:true,mapping:'standard',axes:[0,0],buttons:Array.from({length:16},()=>({pressed:false,value:0}))};ui.pads.push(controller);ui.frames(2);controller.buttons[9].pressed=true;ui.frames(2);controller.buttons[9].pressed=false;ui.frames(2);assert.equal(menu.hidden,true,'Start resumes from compact menu');assert.equal(toggle.getAttribute('aria-expanded'),'false');
  toggle.click();action('restart').click();assert.equal(menu.hidden,true);assert.equal(view().p.x,24);assert.equal(view().lives,5);assert.equal(view().coins,12);
  await session.load(pack,d.rooms,{developerMode:false});assert.equal(screen.classList.contains('play-clean-ui'),false);assert.equal(screen.querySelector('h2 a').hidden,false);assert.equal(screen.querySelector('.play-controls .row').hidden,false);assert.equal(screen.querySelector('.play-session-help').parentNode,screen);assert.equal(action('fullscreen').hidden,true,'legacy menus keep their prior visible actions');
  await session.load(pack,d.rooms,{cleanUi:true,developerMode:false});assert.equal(pad.hidden,false);toggle.click();action('close').click();assert.equal(ui.document.querySelector('dialog[open]'),null);
 }finally{session?.close();ui.restore();}
});

test('default play chrome keeps its prior non-pausing panel toggle and SMM2 alone suppresses the in-canvas brand',async()=>{
 const ui=installSimulatedPlayDom();let session;
 try{
  const texts=[],create=ui.document.createElement;ui.document.createElement=tag=>{const node=create(tag);if(tag==='canvas'){const ctx=node.getContext('2d');ctx.fillText=text=>texts.push(text);node.getContext=()=>ctx;}return node;};
  const {d,pack}=fixture({smm2:false});session=await play(pack,d.rooms,{},{});ui.frames(3);assert(texts.includes('在下小Q · 非官方同人'));texts.length=0;
  const toggle=session.screen.querySelector('h2 button'),menu=session.screen.querySelector('.play-pause-menu');toggle.click();assert.equal(menu.hidden,true);assert.equal(session.screen.classList.contains('play-ui-hidden'),true);ui.frames(3);assert(texts.includes('在下小Q · 非官方同人'));
  const native=fixture();await session.load(native.pack,native.d.rooms,{});texts.length=0;ui.frames(3);assert(!texts.includes('在下小Q · 非官方同人'));assert.equal(session.screen.classList.contains('play-clean-ui'),false);
 }finally{session?.close();ui.restore();}
});

test('single-course offline builder defaults to legacy UI and preserves opt-in through replay',async()=>{
 const ui=installSimulatedPlayDom();try{
  const {d,pack}=fixture();
  for(const cleanUi of [false,true]){
   const html=await offlineFile(pack,d.rooms,read,async()=>new Uint8Array([1,2,3]),()=>{},cleanUi?{cleanUi:true}:{});
   ui.document.body.innerHTML=html.match(/<main>([\s\S]*?)<\/main>/)[1];
   const script=html.match(/<script type="module">([\s\S]*?)<\/script>/)[1].replace(/import[^;]+;/g,'');let received,credits,replayed;
   new Function('play','createGamepadInput','gamepadLabels','showCredits','mountStartingLives',script)(async(_pack,_rooms,_media,opts)=>{received=opts;},createGamepadInput,gamepadLabels,(_session,opts)=>{credits=opts;},()=>()=>5);
   await ui.document.getElementById('start').onclick();assert.equal(received.cleanUi,cleanUi);assert.equal(received.initialState.lives,5);
   received.onComplete({}, {load:(_pack,_rooms,opts)=>{replayed=opts;}});credits.replay();assert.equal(replayed.cleanUi,cleanUi);assert.equal(replayed,received,'replay receives the same reviewed play options');
  }
 }finally{ui.restore();}
});

