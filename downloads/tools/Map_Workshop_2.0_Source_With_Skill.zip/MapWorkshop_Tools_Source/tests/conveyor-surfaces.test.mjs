import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createConveyorSurfaces, validateConveyorsRoom, CONVEYOR_CONTACT_MODE, CONVEYOR_PARAMETER_STATUS, CONVEYOR_COORDINATE_LIMIT} from '../atlas/editor-conveyor-surfaces.mjs';

const near = (a, b, epsilon = 1e-6) => assert(Math.abs(a - b) <= epsilon, `${a} is not near ${b}`);
const unblocked = (body, delta) => ({...delta});
const horizontal = (overrides = {}) => ({
  id: 'neutral-belt', topEndpoints: [{x: 0, y: 100}, {x: 128, y: 100}],
  visual: {kind: 'rect', rect: {x: 0, y: 100, w: 128, h: 16}, rollerCenters: [{x: 8, y: 108}, {x: 120, y: 108}], rollerRadiusPx: 8},
  speedPxPerSecond: 60, visualTreadSpeedPxPerSecond: 120,
  directionOn: 1, contactMode: CONVEYOR_CONTACT_MODE, parameterStatus: CONVEYOR_PARAMETER_STATUS,
  ...overrides
});
const slope = (overrides = {}) => ({
  id: 'neutral-incline', topEndpoints: [{x: 48, y: 96}, {x: 96, y: 64}],
  visual: {kind: 'line', rect: {x: 40, y: 64, w: 64, h: 48}, rollerCenters: [{x: 48, y: 104}, {x: 96, y: 72}], rollerRadiusPx: 8},
  speedPxPerSecond: 60, directionOn: -1,
  contactMode: CONVEYOR_CONTACT_MODE, parameterStatus: CONVEYOR_PARAMETER_STATUS,
  ...overrides
});
const actor = (overrides = {}) => ({id: 'actual-npc', x: 40, y: 84, w: 12, h: 16, vx: -1, vy: 0, facing: -1, grounded: true, support: 'neutral-belt', ...overrides});
const overlap = (a, b) => a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
/** Caller-owned actual solid collision, independent of conveyor geometry. */
function collisionResolver(solids) {
  return (body, {dx, dy}) => {
    // Sweep small intervals, then bisect the first collision. A thin obstacle
    // must still stop a long carry instead of relying on endpoint overlap.
    const count = Math.max(1, Math.ceil(Math.max(Math.abs(dx), Math.abs(dy)) / .25));
    let safe = 0;
    for (let n = 1; n <= count; n++) {
      const fraction = n / count, candidate = {...body, x: body.x + dx * fraction, y: body.y + dy * fraction};
      if (!solids.some(solid => overlap(candidate, solid))) {safe = fraction; continue;}
      let lo = safe, hi = fraction;
      for (let i = 0; i < 30; i++) {
        const mid = (lo + hi) / 2, pose = {...body, x: body.x + dx * mid, y: body.y + dy * mid};
        if (solids.some(solid => overlap(pose, solid))) hi = mid; else lo = mid;
      }
      return {fraction: lo, blocked: true};
    }
    return {fraction: 1};
  };
}

test('strict detached specs retain stable IDs, authored speeds, real roller geometry and explicit proof limits', () => {
  const specs = [horizontal(), slope()];
  const validated = validateConveyorsRoom(specs, {width: 256, height: 160});
  assert.deepEqual(validated, specs);
  validated[0].visual.rollerCenters[0].x = 999;
  assert.equal(specs[0].visual.rollerCenters[0].x, 8);
  assert.deepEqual(validateConveyorsRoom([], {x: -10, y: -10, w: 20, h: 20}), []);
  const bad = [
    q => q.id = '', q => q.id = '__proto__', q => q.speedPxPerSecond = 0,
    q => q.speedPxPerSecond = Infinity, q => q.speedPxPerSecond = NaN,
    q => q.directionOn = 0, q => q.contactMode = 'four-sided-solid',
    q => q.parameterStatus = 'original-calibrated', q => delete q.parameterStatus,
    q => q.motion = {axis: 'x'}, q => q.topEndpoints[0].extra = true,
    q => q.topEndpoints[1].x = q.topEndpoints[0].x,
    q => q.visual.rollerCenters[0].x = -1,
    q => q.visual.rollerRadiusPx = -1, q => q.visualTreadSpeedPxPerSecond = 0,
    q => q.visual.rect.w = 40, q => q.visual.kind = 'falling-platform',
    q => q.topEndpoints[0].x = CONVEYOR_COORDINATE_LIMIT + 1
  ];
  for (const edit of bad) {
    const q = horizontal(); edit(q);
    assert.throws(() => validateConveyorsRoom([q]));
  }
  assert.throws(() => validateConveyorsRoom([horizontal(), horizontal()]), /Duplicate/);
  assert.throws(() => validateConveyorsRoom([horizontal()], {width: 100, height: 120}), /room bounds/);
  const wrongAngle = slope(); wrongAngle.topEndpoints[1].y = 80;
  assert.throws(() => validateConveyorsRoom([wrongAngle]), /actual visual roller centerline/);
});

test('ON/OFF reverses upper tread, lower loop and roller phase while every endpoint stays fixed', () => {
  let on = true;
  const controller = createConveyorSurfaces([horizontal(), slope()], {isOn: () => on});
  const initial = controller.view();
  const right = controller.frame({tick: 0, deltaSeconds: .1});
  near(right.surfaces[0].treadDistancePx, 12);
  assert.equal(right.surfaces[0].colorState, 'red');
  assert.deepEqual(right.surfaces[0].topTreadDirection, {x: 1, y: 0});
  assert.deepEqual(right.surfaces[0].bottomTreadDirection, {x: -1, y: -0});
  assert(right.surfaces[1].topTreadDirection.x < 0 && right.surfaces[1].topTreadDirection.y > 0);
  on = false;
  const left = controller.frame({tick: 1, deltaSeconds: .1});
  near(left.surfaces[0].treadDistancePx, 0);
  assert.equal(left.surfaces[0].colorState, 'blue');
  assert.equal(left.surfaces[0].topTreadDirection.x, -1);
  assert(left.surfaces[1].topTreadDirection.x > 0 && left.surfaces[1].topTreadDirection.y < 0);
  for (const state of [right, left]) state.surfaces.forEach((surface, n) => {
    assert.equal(surface.dx, 0); assert.equal(surface.dy, 0);
    assert.deepEqual(surface.topEndpoints, initial.surfaces[n].topEndpoints);
    assert.deepEqual(surface.visual, initial.surfaces[n].visual);
    surface.rollers.forEach((roller, index) => {
      near(roller.x, initial.surfaces[n].rollers[index].x); near(roller.y, initial.surfaces[n].rollers[index].y);
    });
  });
  assert.notEqual(right.surfaces[0].rollers[0].phaseRadians, initial.surfaces[0].rollers[0].phaseRadians);
  assert.deepEqual(controller.frame({tick: 1, deltaSeconds: .1}), left);
});

test('same body API counterbalances intrinsic left walking in ON, then carries left in OFF without changing facing or vx', () => {
  let on = true;
  const controller = createConveyorSurfaces([horizontal()], {isOn: () => on}), npc = actor();
  const step = tick => {
    const previous = {...npc}; npc.x += npc.vx; npc.vy = .25; npc.y += npc.vy;
    return controller.carryActor(npc, {tick, previous, resolveDisplacement: unblocked});
  };
  for (let tick = 0; tick < 12; tick++) {
    const carried = step(tick);
    assert(carried.supported); near(npc.x, 40); near(npc.y + npc.h, 100);
    assert.equal(npc.vx, -1); assert.equal(npc.facing, -1); assert.equal(npc.support, 'neutral-belt');
  }
  on = false;
  for (let tick = 12; tick < 24; tick++) step(tick);
  near(npc.x, 16); assert.equal(npc.vx, -1); assert.equal(npc.facing, -1);
  const player = actor({id: 'actual-player', x: 64, vx: 0, facing: 1});
  const carried = controller.carryActor(player, {tick: 24, resolveDisplacement: unblocked});
  near(carried.dx, -1); near(player.x, 63); assert.equal(player.vx, 0); assert.equal(player.facing, 1);
});

test('a descending actor lands on the actual top and receives transport only for the remainder of its tick', () => {
  const controller = createConveyorSurfaces([horizontal()]);
  const before = actor({y: 80, vy: 8, grounded: false, support: null});
  const body = {...before, y: 88};
  const hit = controller.contact(body, {previous: before});
  assert.equal(hit.reason, 'descending-top-crossing'); near(hit.fraction, .5);
  const carried = controller.carryActor(body, {tick: 0, previous: before, resolveDisplacement: unblocked});
  near(carried.dx, .5); near(body.x, 40.5); near(body.y + body.h, 100);
  assert.equal(body.vy, 0); assert.equal(body.grounded, true);
});

test('air, rising jump, underside overlap and entering a side below the top never acquire support or belt flow', () => {
  const controller = createConveyorSurfaces([horizontal()]);
  const cases = [
    [actor({y: 60, grounded: false, support: null}), actor({y: 60, grounded: false, support: null})],
    [actor({y: 100, vy: -2, grounded: false, support: null}), actor({y: 102, vy: -2, grounded: false, support: null})],
    [actor({y: 84, vy: -2, grounded: false, support: null}), actor({y: 86, vy: -2, grounded: false, support: null})],
    [actor({x: 1, y: 88, vy: 0, grounded: false, support: null}), actor({x: -20, y: 88, vy: 0, grounded: false, support: null})]
  ];
  for (let tick = 0; tick < cases.length; tick++) {
    const [body, previous] = cases[tick], start = {...body};
    assert.equal(controller.contact(body, {previous}), null);
    const result = controller.carryActor(body, {tick, previous, resolveDisplacement: () => assert.fail('non-contact must never call transport resolver')});
    assert.equal(result.carried, false); assert.deepEqual(body, start);
  }
});

test('descending side entry above the top can land, but an already submerged side entry cannot snap upward', () => {
  const controller = createConveyorSurfaces([horizontal()]);
  const before = actor({x: -24, y: 80, vy: 8, grounded: false, support: null});
  const after = {...before, x: 10, y: 88};
  const hit = controller.contact(after, {previous: before});
  assert.equal(hit.reason, 'descending-top-crossing'); near(hit.fraction, .5, 1e-5);
  const submerged = actor({x: -24, y: 90, vy: 1, grounded: false, support: null});
  assert.equal(controller.contact({...submerged, x: 10, y: 91}, {previous: submerged}), null);
});

test('stacked tops choose the first real descending impact rather than the lowest overlapping rectangle', () => {
  const second = horizontal({id: 'lower-belt', topEndpoints: [{x: 0, y: 140}, {x: 128, y: 140}], visual: {kind: 'rect', rect: {x: 0, y: 140, w: 128, h: 16}, rollerCenters: [{x: 8, y: 148}, {x: 120, y: 148}], rollerRadiusPx: 8}});
  const controller = createConveyorSurfaces([second, horizontal()]);
  const before = actor({y: 74, vy: 70, grounded: false, support: null});
  const body = {...before, y: 144};
  const hit = controller.contact(body, {previous: before});
  assert.equal(hit.surfaceId, 'neutral-belt'); near(hit.fraction, 10 / 70);
});

test('inclined support uses the measured non-45-degree line and conservative actual footprint; visual-only caps do not attract', () => {
  const controller = createConveyorSurfaces([slope()]);
  near(controller.surfaceAtX('neutral-incline', 72).y, 80);
  assert.equal(controller.surfaceAtX('neutral-incline', 40), null);
  const sample = controller.bodySupport(actor({x: 50, w: 32, y: 0}), 'neutral-incline');
  near(sample.x, 82); near(sample.y, 96 - 34 * 2 / 3);
  assert.equal(sample.footprintRule, 'highest-overlapped-analytic-point');
  const cap = actor({x: 40, w: 6, y: 88, support: null, grounded: false});
  assert.equal(controller.bodySupport(cap), null); assert.equal(controller.contact(cap), null);
  const narrowed = actor({x: 48, w: 1, y: 0});
  near(controller.bodySupport(narrowed).y, 96 - 2 / 3);
});

test('OFF carries a genuinely supported body continuously uphill; reversal carries downhill with identical actor velocities', () => {
  let on = false;
  const controller = createConveyorSurfaces([slope()], {isOn: () => on});
  const body = actor({x: 56, vx: 0, support: 'neutral-incline'});
  body.y = controller.bodySupport(body).y - body.h;
  const start = {...body};
  for (let tick = 0; tick < 8; tick++) {
    const previous = {...body}; body.vy = .25; body.y += .25;
    const carried = controller.carryActor(body, {tick, previous, resolveDisplacement: unblocked});
    assert(carried.supported); near(body.y + body.h, controller.bodySupport(body).y);
    assert.equal(body.vx, 0); assert.equal(body.facing, -1);
  }
  assert(body.x > start.x && body.y < start.y);
  const crestward = {...body}; on = true;
  for (let tick = 8; tick < 16; tick++) {
    const previous = {...body}; body.vy = .25; body.y += .25;
    assert(controller.carryActor(body, {tick, previous, resolveDisplacement: unblocked}).supported);
  }
  assert(body.x < crestward.x && body.y > crestward.y);
  near(body.x, start.x); near(body.y, start.y);
});

test('intrinsic uphill walking follows preceding real support, whereas a fabricated stale support cannot lift from below', () => {
  const controller = createConveyorSurfaces([slope()], {isOn: false});
  const body = actor({x: 56, vx: 1, support: 'neutral-incline'});
  body.y = controller.bodySupport(body).y - body.h;
  const previous = {...body}; body.x += body.vx; body.vy = .25; body.y += .25;
  const hit = controller.contact(body, {previous});
  assert.equal(hit.reason, 'following-previous-top');
  assert(controller.carryActor(body, {tick: 0, previous, resolveDisplacement: unblocked}).supported);
  near(body.y + body.h, controller.bodySupport(body).y); assert.equal(body.vx, 1);
  const below = actor({x: 56, y: 104, support: 'neutral-incline'}), fakePrevious = {...below};
  const before = {...below};
  assert.equal(controller.contact(below, {previous: fakePrevious}), null);
  controller.carryActor(below, {tick: 1, previous: fakePrevious, resolveDisplacement: () => assert.fail('stale support cannot transport')});
  near(below.x, before.x); near(below.y, before.y); assert.equal(below.grounded, false); assert.equal(below.support, null);
});

test('actual caller collision sweep stops long transport at a thin wall and preserves intrinsic walk direction', () => {
  const controller = createConveyorSurfaces([horizontal({speedPxPerSecond: 6000})]);
  const body = actor({x: 20, vx: -1});
  const wall = {x: 34, y: 0, w: 2, h: 100};
  const carried = controller.carryActor(body, {tick: 0, resolveDisplacement: collisionResolver([wall])});
  assert(carried.blocked); near(body.x, 22); assert(!overlap(body, wall));
  assert.equal(body.vx, -1); assert.equal(body.facing, -1); assert.equal(body.grounded, true);
  near(carried.requested.dx, 100); near(carried.dx, 2);
});

test('genuine flat support transfers directly to an equal-height inclined junction bridged by the actual footprint', () => {
  const flat = horizontal({id: 'junction-flat', topEndpoints: [{x: 0, y: 96}, {x: 40, y: 96}], visual: {kind: 'rect', rect: {x: 0, y: 96, w: 40, h: 16}, rollerCenters: [{x: 8, y: 104}, {x: 32, y: 104}], rollerRadiusPx: 8}});
  const controller = createConveyorSurfaces([flat, slope()], {isOn: false});
  const previous = actor({x: 31, y: 80, w: 16, vx: 2, support: 'junction-flat'});
  const body = {...previous, x: 33, y: 80.25, vy: .25};
  const hit = controller.contact(body, {previous});
  assert.equal(hit.surfaceId, 'neutral-incline'); assert.equal(hit.reason, 'following-connected-top');
  assert.equal(hit.previousSurfaceId, 'junction-flat');
  const result = controller.carryActor(body, {tick: 0, previous, resolveDisplacement: unblocked});
  assert(result.supported); assert.equal(body.support, 'neutral-incline'); assert.equal(body.vx, 2);
  near(body.y + body.h, controller.bodySupport(body, 'neutral-incline').y);
  for (let tick = 1; tick < 16; tick++) {
    const before = {...body}; body.x += 2; body.y += .25; body.vy = .25;
    assert(controller.carryActor(body, {tick, previous: before, resolveDisplacement: unblocked}).supported);
    near(body.y + body.h, controller.bodySupport(body, 'neutral-incline').y);
  }
});

test('connected-top transfer rejects airborne or fabricated old contact, height mismatch, unbridged gaps and unswept upward corrections', () => {
  const makeFlat = (end = 40, y = 96) => horizontal({id: 'junction-flat', topEndpoints: [{x: 0, y}, {x: end, y}], visual: {kind: 'rect', rect: {x: 0, y, w: end, h: 16}, rollerCenters: [{x: 8, y: y + 8}, {x: end - 8, y: y + 8}], rollerRadiusPx: 8}});
  const previous = actor({x: 31, y: 80, w: 16, vx: 2, support: 'junction-flat'}), next = {...previous, x: 33, y: 80.25, vy: .25};
  const controller = createConveyorSurfaces([makeFlat(), slope()], {isOn: false});
  for (const fake of [{...previous, grounded: false}, {...previous, y: 84}, {...previous, support: null}]) {
    const hit = controller.contact({...next, grounded: false, support: null}, {previous: fake});
    assert(!hit || hit.surfaceId !== 'neutral-incline', 'no nearby top grants unsupported uphill attraction');
  }
  const differentHeight = createConveyorSurfaces([makeFlat(40, 100), slope()], {isOn: false});
  const mismatchBefore = {...previous, y: 84}, mismatchAfter = {...next, y: 84.25};
  assert.notEqual(differentHeight.contact(mismatchAfter, {previous: mismatchBefore})?.surfaceId, 'neutral-incline');
  const largeGap = createConveyorSurfaces([makeFlat(24), slope()], {isOn: false});
  const gapBefore = {...previous, x: 20}, gapAfter = {...next, x: 33};
  assert.notEqual(largeGap.contact(gapAfter, {previous: gapBefore})?.surfaceId, 'neutral-incline');
  const blocked = {...next}, before = {...blocked};
  const result = controller.carryActor(blocked, {tick: 0, previous, resolveDisplacement: () => ({dx: 0, dy: 0, blocked: true})});
  assert(result.blocked); assert.equal(result.supported, false); near(blocked.y, before.y);
  assert.equal(blocked.grounded, false); assert.equal(blocked.support, null);
});

test('additive belt flow itself reaches the connected incline in the same tick with zero or opposite intrinsic walking', () => {
  const flat = horizontal({id: 'junction-flat', topEndpoints: [{x: 0, y: 96}, {x: 40, y: 96}], visual: {kind: 'rect', rect: {x: 0, y: 96, w: 40, h: 16}, rollerCenters: [{x: 8, y: 104}, {x: 32, y: 104}], rollerRadiusPx: 8}, directionOn: -1, speedPxPerSecond: 120});
  for (const intrinsicVx of [0, -.5]) {
    const controller = createConveyorSurfaces([flat, slope()], {isOn: false});
    const body = actor({x: 31, y: 80, w: 16, vx: intrinsicVx, support: 'junction-flat'}), before = {...body};
    body.x += intrinsicVx; body.y += .25; body.vy = .25;
    const result = controller.carryActor(body, {tick: 0, previous: before, resolveDisplacement: unblocked});
    assert(result.supported); assert.equal(body.support, 'neutral-incline');
    assert.equal(result.transportSourceId, 'junction-flat'); assert.equal(body.vx, intrinsicVx);
    near(body.y + body.h, controller.bodySupport(body, 'neutral-incline').y);
    assert(body.x > before.x && body.y < before.y);
  }
});

test('obstructed slope transport releases support unless its actual final feet still meet the analytic top', () => {
  const controller = createConveyorSurfaces([slope({speedPxPerSecond: 600})], {isOn: false});
  const body = actor({x: 56, vx: 0, support: 'neutral-incline'});
  body.y = controller.bodySupport(body).y - body.h;
  const before = {...body};
  const carried = controller.carryActor(body, {tick: 0, resolveDisplacement: (pose, delta) => ({dx: delta.dx / 2, dy: 0, blocked: true})});
  assert(carried.blocked); assert.equal(carried.supported, false);
  assert.equal(body.grounded, false); assert.equal(body.support, null);
  near(body.y, before.y); assert.equal(body.vx, 0);
});

test('leaving a conveyor end releases its own support and ordinary ground support is preserved on a miss', () => {
  const controller = createConveyorSurfaces([horizontal({speedPxPerSecond: 1200})]);
  const body = actor({x: 126, vx: 0});
  const result = controller.carryActor(body, {tick: 0, resolveDisplacement: unblocked});
  assert.equal(result.supported, false); assert.equal(body.grounded, false); assert.equal(body.support, null);
  near(body.x, 146); near(body.y, 84);
  const ordinary = actor({id: 'ordinary-ground-actor', y: 150, support: 'ordinary-ground'}), before = {...ordinary};
  controller.carryActor(ordinary, {tick: 0}); assert.deepEqual(ordinary, before);
});

test('per-actor per-tick deduplication prevents repeated carry across both identity and stable actor-ID copies', () => {
  const controller = createConveyorSurfaces([horizontal()]), body = actor();
  controller.carryActor(body, {tick: 0, resolveDisplacement: unblocked});
  const carried = {...body};
  assert.equal(controller.carryActor(body, {tick: 0, resolveDisplacement: unblocked}).reason, 'already-carried-this-tick');
  assert.deepEqual(body, carried);
  const reloaded = {...body};
  assert.equal(controller.carryActor(reloaded, {tick: 0, resolveDisplacement: unblocked}).reason, 'already-carried-this-tick');
  assert.deepEqual(reloaded, carried);
  controller.carryActor(body, {tick: 1, resolveDisplacement: unblocked}); near(body.x, carried.x + 1);
  const anonymous = actor(); delete anonymous.id;
  controller.carryActor(anonymous, {tick: 1, resolveDisplacement: unblocked}); const x = anonymous.x;
  controller.carryActor(anonymous, {tick: 1, resolveDisplacement: unblocked}); near(anonymous.x, x);
});

test('required collision port and invalid responses fail before moving or marking the actor carried', () => {
  const controller = createConveyorSurfaces([horizontal()]), body = actor(), before = {...body};
  assert.throws(() => controller.carryActor(body, {tick: 0}), /resolveDisplacement/);
  for (const resolveDisplacement of [() => null, () => ({fraction: -1}), () => ({fraction: 2}), () => ({dx: 2, dy: 0}), () => ({dx: -1, dy: 0}), () => ({dx: NaN, dy: 0})]) {
    assert.throws(() => controller.carryActor(body, {tick: 0, resolveDisplacement})); assert.deepEqual(body, before);
  }
  controller.carryActor(body, {tick: 0, resolveDisplacement: (detached, delta) => {detached.vx = 999; detached.facing = 1; detached.x = 999; return delta;}});
  assert.equal(body.vx, before.vx); assert.equal(body.facing, before.facing); near(body.x, before.x + 1);
});

test('pause freezes tread and transport; resume, detached views and reset retain fixed authored geometry', () => {
  const controller = createConveyorSurfaces([horizontal()]), initial = controller.view();
  controller.frame(0); const advanced = controller.view().surfaces[0].treadDistancePx;
  controller.setPaused(true); const paused = controller.frame(1);
  near(paused.surfaces[0].treadDistancePx, advanced); near(paused.surfaces[0].surfaceFlow.x, 0);
  const body = actor(), before = {...body};
  assert.equal(controller.carryActor(body, {tick: 1, resolveDisplacement: unblocked}).reason, 'paused'); assert.deepEqual(body, before);
  controller.setPaused(false); controller.frame(2);
  assert(controller.view().surfaces[0].treadDistancePx > advanced);
  const detached = controller.view(); detached.surfaces[0].topEndpoints[0].x = 999;
  assert.equal(controller.view().surfaces[0].topEndpoints[0].x, 0);
  assert.deepEqual(controller.reset(), initial);
  assert.throws(() => controller.setPaused('yes'));
  assert.throws(() => controller.frame({tick: 0, deltaSeconds: -1}));
  assert.throws(() => controller.frame({tick: NaN}));
  controller.frame(2); assert.throws(() => controller.frame(1), /backward/);
});

test('save/restore matches exact authored definitions and switch state, retains same-tick dedupe and rejects invalid state atomically', () => {
  let on = false;
  const a = createConveyorSurfaces([horizontal(), slope()], {isOn: () => on}), body = actor();
  a.carryActor(body, {tick: 20, resolveDisplacement: unblocked});
  const serialized = a.serialize(), b = createConveyorSurfaces([horizontal(), slope()], {isOn: () => on});
  assert.deepEqual(b.restore(serialized), a.view());
  const actorReloaded = {...body}, before = {...actorReloaded};
  assert.equal(b.carryActor(actorReloaded, {tick: 20, resolveDisplacement: unblocked}).reason, 'already-carried-this-tick'); assert.deepEqual(actorReloaded, before);
  assert.deepEqual(a.frame(21), b.frame(21));
  const stable = b.serialize();
  for (const edit of [s => s.version = 2, s => s.specSignature = 'other', s => s.phases[1].id = s.phases[0].id, s => s.phases[0].treadDistancePx = NaN, s => s.carriedActorIds = ['duplicate', 'duplicate'], s => s.tick = -1, s => s.unknown = true]) {
    const state = b.saveState(); edit(state); assert.throws(() => b.restore(state)); assert.equal(b.serialize(), stable);
  }
  on = true; assert.throws(() => b.restore(stable), /owning switch state/); on = false;
  assert.equal(b.serialize(), stable);
  const differentlyAuthored = createConveyorSurfaces([horizontal({speedPxPerSecond: 61}), slope()], {isOn: false});
  assert.throws(() => differentlyAuthored.restore(stable), /exact authored definitions/);
});

test('switch events report reversal once and carry events expose actual transport independently of visual stripe speed', () => {
  let on = true; const events = [];
  const controller = createConveyorSurfaces([horizontal()], {isOn: () => on, emit: (type, data) => events.push({type, data})});
  const body = actor(); controller.carryActor(body, {tick: 0, resolveDisplacement: unblocked});
  const carry = events.find(event => event.type === 'conveyor-carry'); near(carry.data.dx, 1);
  near(controller.view().surfaces[0].treadDistancePx, 2);
  on = false; controller.view(); controller.view(); controller.frame(1);
  assert.equal(events.filter(event => event.type === 'conveyor-direction').length, 1);
  assert.equal(events.find(event => event.type === 'conveyor-direction').data.on, false);
});
