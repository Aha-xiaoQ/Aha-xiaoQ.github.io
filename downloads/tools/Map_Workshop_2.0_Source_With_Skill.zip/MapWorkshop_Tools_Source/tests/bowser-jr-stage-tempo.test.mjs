import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
import {createCanvas} from '@napi-rs/canvas';
import {blank,parseProject,History,updateSmm2BowserJr,cloneSmm2BowserJr,addSmm2BowserJr,bindSmm2BowserJr} from '../atlas/editor-model.mjs';
import {BOWSER_JR_AUTHORING_DEFAULTS,BOWSER_JR_TEMPO_FIELDS,createBowserJrStageTempo,validateBowserJrRule,createBowserJuniors,bowserJrTempoForHp,bowserJrView,bowserJrVisibleFrame} from '../atlas/editor-bowser-jr.mjs';
import {mountBowserJrTools,clearSmm2BowserJrStageTempo} from '../atlas/editor-bowser-jr-tools.mjs';
import {captureSmm2ActorLeaves,appendCopiedSmm2ActorLeaves} from '../atlas/editor-smm2-tools.mjs';
import {offlineFile} from '../atlas/editor-offline.mjs';
import {createCollection,addLevel,buildCollection,validateCollection} from '../atlas/editor-collection.mjs';
import {drawObject} from '../atlas/editor-art.mjs';
import {addContraptionDoorPair} from '../atlas/editor-contraptions-tools.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';
import {nativeSession,character} from './fixtures/shell-coin-native.mjs';
import {bowserJrProject,displayedJrHeadTarget,threeNativeJrStomps} from './fixtures/bowser-jr-native.mjs';
import {authoredJrStageTempo,bowserJrTempoProject} from './fixtures/bowser-jr-tempo.mjs';

const hash=q=>createHash('sha256').update(JSON.stringify(q)).digest('hex');
const ruleOf=d=>d.rooms[0].smm2Mechanics.bowserJuniors.actors[0];
const baseline=JSON.parse(fs.readFileSync(new URL('./fixtures/bowser-jr-tempo-baseline.json',import.meta.url)));
function headContact(c,a,tick){const head=displayedJrHeadTarget(a),p={x:head.x-5,y:head.y-13,w:10,h:14,vy:2};return c.playerContact(a,p,{...p,y:p.y-2},{tick,beforeActor:structuredClone(a)});}

test('missing tempo preserves complete frozen 1.10.27 native traces, events and imported document bytes',()=>{
 for(const expected of baseline.cases){
  const d=bowserJrProject(),q=ruleOf(d);if(expected.name==='missing-hit'){delete q.hitTransitionFrames;delete q.hitHopSpeed;}if(expected.name==='hit-15'){q.hitTransitionFrames=15;q.hitHopSpeed=3.5;}
  const saved=JSON.stringify(d);assert.equal(JSON.stringify(parseProject(saved)),saved);const s=nativeSession(d);threeNativeJrStomps(s);
  assert.equal(s.inputs.length,expected.ticks);assert.equal(hash(s.trace),expected.traceSha256);assert.equal(hash(s.events),expected.eventsSha256);assert.equal(JSON.stringify(d),saved);assert(!Object.hasOwn(ruleOf(s.doc),'stageTempo'));
  const seeded=structuredClone(d);ruleOf(seeded).stageTempo=createBowserJrStageTempo(q);const equivalent=nativeSession(seeded);threeNativeJrStomps(equivalent);
  assert.equal(hash(equivalent.trace),expected.traceSha256);assert.equal(hash(equivalent.events),expected.eventsSha256,'neutral editor seed changes no lifecycle or cadence');
 }
});

test('stage tempo is closed, explicit and finite; rejects null, unknown fields, missing/duplicate/reordered HP and new attacks',()=>{
 const good={...BOWSER_JR_AUTHORING_DEFAULTS,stageTempo:authoredJrStageTempo()};assert(validateBowserJrRule(good));
 const mutations=[q=>q.stageTempo=null,q=>q.stageTempo=undefined,q=>q.stageTempo.version=2,q=>q.stageTempo.sourceParameterStatus='original-calibrated',q=>delete q.stageTempo.sourceParameterStatus,q=>q.stageTempo.extra=true,q=>q.stageTempo.stages.pop(),q=>q.stageTempo.stages.push({...q.stageTempo.stages[2]}),q=>q.stageTempo.stages.reverse(),q=>q.stageTempo.stages[1].hp=3,q=>q.stageTempo.stages[0]=null];
 for(const key of ['hp','shellFrames','revealFrames','recoveryHopSpeed','hitTransitionFrames','hitHopSpeed','invulnerable','projectileType','jumpSpeed','maxHp'])if(key!=='hp')mutations.push(q=>q.stageTempo.stages[1][key]=1);
 for(const key of BOWSER_JR_TEMPO_FIELDS){mutations.push(q=>delete q.stageTempo.stages[1][key],q=>q.stageTempo.stages[1][key]=null,q=>q.stageTempo.stages[1][key]=NaN,q=>q.stageTempo.stages[1][key]=Infinity,q=>q.stageTempo.stages[1][key]=0);}
 mutations.push(q=>q.stageTempo.stages[1].fireWindupFrames=q.stageTempo.stages[1].fireIntervalFrames,q=>q.stageTempo.stages[1].recoveryFireDelayFrames=1.5,q=>q.stageTempo.stages[1].shellSpeed=8.01,q=>q.stageTempo.stages[1].shellAcceleration=1.01);
 for(const mutate of mutations){const bad=structuredClone(good);mutate(bad);assert.throws(()=>validateBowserJrRule(bad));}
});

test('current real HP chooses shell speed and acceleration immediately, plus actual initial/recovery/interval shots',()=>{
 const d=bowserJrTempoProject(),r=d.rooms[0],q=ruleOf(d),events=[],c=createBowserJuniors(r,{emit:(_type,e)=>events.push(e)}),a=c.decorateActor({...r.map.objects[1],dead:false}),player={x:30,y:200,w:10,h:14};let tick=0;
 const step=()=>{tick++;return c.stepActor(a,{tick,player,geometry:r.map.geometry});};
 const until=fn=>{for(let n=0;n<800;n++){const result=step();if(fn(result))return result;}throw Error('Unit controller condition timed out');};
 assert.equal(a.hp,3);assert.equal(Math.abs(a.vx),.5);assert.equal(a.smm2BowserJr.fireRemaining,60);const initialShot=until(result=>result?.projectile);assert(Math.abs(Math.hypot(initialShot.projectile.vx,initialShot.projectile.vy)-1.7)<1e-7);let shot=events.find(e=>e.event==='fireball');assert.equal(shot.tick,78);
 let emitted=c.stepActor(a,{tick,player,geometry:r.map.geometry});assert.equal(emitted,true);assert.equal(events.filter(e=>e.event==='fireball').length,1,'duplicate tick emits no second projectile');
 for(const hp of [2,1]){
  const hit=headContact(c,a,++tick);assert(hit.bounce);assert.equal(a.hp,hp);assert.equal(a.smm2BowserJr.phase,'hit-transition');const stage=q.stageTempo.stages[3-hp];
  until(()=>a.smm2BowserJr.phase==='shell');assert.equal(Math.abs(a.vx),stage.shellSpeed);assert.equal(a.smm2BowserJr.phaseAge,0);
  const previous=a.vx;player.x=a.x+(previous>0?-200:200);step();assert(Math.abs((a.vx-previous)+Math.sign(previous)*stage.shellAcceleration)<1e-7,'turn acceleration uses current remaining HP');
  until(()=>a.smm2BowserJr.phase==='normal');const recovered=tick;assert.equal(a.smm2BowserJr.fireRemaining,stage.recoveryFireDelayFrames);assert.equal(Math.abs(a.vx),stage.walkSpeed);
  emitted=until(result=>result?.projectile);assert.equal(tick-recovered,stage.recoveryFireDelayFrames+stage.fireWindupFrames);assert(Math.abs(Math.hypot(emitted.projectile.vx,emitted.projectile.vy)-stage.fireSpeed)<1e-7);assert.deepEqual(emitted.projectile.bowserJrAim,{x:player.x+5,y:player.y+7});const firstShot=tick;
  emitted=until(result=>result?.projectile);assert.equal(tick-firstShot,stage.fireIntervalFrames+stage.fireWindupFrames);assert(Math.abs(Math.hypot(emitted.projectile.vx,emitted.projectile.vy)-stage.fireSpeed)<1e-7);
 }
 assert(headContact(c,a,++tick).defeated);assert.equal(a.hp,0);assert.equal(a.smm2BowserJr.phase,'defeated');assert.equal(events.filter(e=>e.event==='head-stomp').length,2);assert.equal(events.filter(e=>e.event==='defeated').length,1);
});

test('authored pressure stays beatable with genuine Small inputs and emits native aimed fire after both recoveries',()=>{
 const d=bowserJrTempoProject(),saved=JSON.stringify(d),s=nativeSession(d);threeNativeJrStomps(s);
 assert.equal(s.view().lives,5);assert.equal(s.view().score,4000);assert(s.trace.every(v=>!v.p.dying&&v.p.power===0&&v.p.invulnerable===0&&v.lives===5));assert(s.inputs.every(i=>Object.keys(i).every(k=>['x','run','jump'].includes(k))));assert.equal(JSON.stringify(d),saved);
 const events=s.events.filter(e=>e.type==='smm2-bowser-jr');assert.deepEqual(events.filter(e=>e.event==='head-stomp').map(e=>e.hp),[2,1]);assert.equal(events.filter(e=>e.event==='defeated').length,1);assert.equal(s.events.filter(e=>e.event==='enemy-key-released').length,1);
 for(const hp of [2,1]){const q=ruleOf(d).stageTempo.stages[3-hp],start=events.find(e=>e.event==='shell-pursuit-start'&&e.hp===hp),hop=events.find(e=>e.event==='recovery-hop'&&e.hp===hp),recovery=events.find(e=>e.event==='recovered'&&e.hp===hp),fire=events.find(e=>e.event==='fireball'&&e.hp===hp);assert.equal(hop.tick-start.tick,260);assert.equal(fire.tick-recovery.tick,q.recoveryFireDelayFrames+q.fireWindupFrames);const actual=s.trace[fire.frame-1].enemies.find(e=>e.id===fire.projectileId);assert(actual);assert(Math.abs(Math.hypot(actual.vx,actual.vy)-q.fireSpeed)<1e-7);assert.deepEqual(actual.bowserJrAim,fire.aim);}
});

test('tempo pose/render/pure metric reads and paused ticks are immutable; death freezes and continue resets HP3 tempo',()=>{
 const s=nativeSession(bowserJrTempoProject());s.until(v=>v.enemies[0]?.hp===2,{},80);s.stage.pause();const first=s.view(),ctx=createCanvas(640,320).getContext('2d');
 for(let n=0;n<25;n++){const a=s.view().enemies[0],q=ruleOf(s.doc);bowserJrView(a);bowserJrVisibleFrame(a);drawObject(ctx,a,first.tick,s.doc.rooms[0]);const metric=bowserJrTempoForHp(q,a.hp);assert.equal(metric.shellSpeed,2.9);metric.shellSpeed=8;assert.equal(q.stageTempo.stages[1].shellSpeed,2.9);assert.deepEqual(s.view(),first);}
 s.stage.resume();const advanced=s.step({jump:true});assert.equal(advanced.tick,first.tick+1);assert.equal(advanced.enemies[0].smm2BowserJr.phaseAge,1);
 s.until(v=>v.p.dying,{x:-1},150);const frozen=s.view().enemies[0];s.frames(110);assert.deepEqual(s.view().enemies[0],frozen);assert(s.stage.continueFromCurrent());const fresh=s.view().enemies[0];assert.equal(fresh.hp,3);assert.equal(Math.abs(fresh.vx),.5);assert.equal(fresh.smm2BowserJr.fireRemaining,60);assert.equal(fresh.smm2BowserJr.phase,'normal');assert.equal(s.view().lives,4);assert.deepEqual(ruleOf(s.doc).stageTempo,authoredJrStageTempo());
});

test('same native actor JSON snapshot resumes current HP tempo without resetting its shell clock',()=>{
 const d=bowserJrTempoProject(),r=d.rooms[0],events=[],c=createBowserJuniors(r,{emit:(type,e)=>events.push({type,...e})}),a=c.decorateActor({...r.map.objects[1],dead:false}),player={x:500,y:180,w:10,h:14};assert(headContact(c,a,1).bounce);
 for(let tick=2;tick<=71;tick++)c.stepActor(a,{tick,player,geometry:r.map.geometry});assert.equal(a.hp,2);assert.equal(a.smm2BowserJr.phase,'shell');const saved=JSON.stringify(a),restoredEvents=[],fresh=createBowserJuniors(r,{emit:(type,e)=>restoredEvents.push({type,...e})}),restored=fresh.decorateActor(JSON.parse(saved));assert.equal(JSON.stringify(restored),saved);const eventStart=events.length;
 for(let tick=72;tick<=450;tick++){c.stepActor(a,{tick,player,geometry:r.map.geometry});fresh.stepActor(restored,{tick,player,geometry:r.map.geometry});assert.deepEqual(restored,a);}
 assert.deepEqual(restoredEvents,events.slice(eventStart));assert.equal(restored.hp,2);assert(restoredEvents.some(e=>e.event==='fireball'));
});

test('real door leave/re-entry resets the optional-tempo actor to fresh HP3 and preserves authored configuration',()=>{
 const d=bowserJrTempoProject(),hub=blank('Neutral tempo reset hub',640,320).rooms[0];hub.roomId='hub';hub.map.id='neutral-jr-tempo-reset-hub';hub.map.geometry=[{id:'hub-floor',x:0,y:288,w:640,h:32,collision:'solid',material:'ground'}];hub.map.objects=[{id:'hub-start',kind:'spawn',x:36,y:274,w:10,h:14}];d.rooms.push(hub);addContraptionDoorPair(d,'main','hub',{source:{x:224,y:198},target:{x:32,y:256},style:'plain'});
 const s=nativeSession(d);s.until(v=>v.enemies[0]?.hp===2,{},80);s.until(v=>v.p.grounded&&v.p.support==='left-perch',v=>({x:v.p.x>230?-1:0,run:true,jump:!v.p.grounded}),120);s.until(v=>v.p.grounded&&v.p.x<239,{x:-1},30);s.step({up:true});s.until(v=>v.roomId==='hub',{},30);s.frames(35);s.step({up:true});s.until(v=>v.roomId==='main',{},30);const a=s.view().enemies.find(e=>e.id==='junior');assert.equal(a.hp,3);assert.equal(Math.abs(a.vx),.5);assert.equal(a.smm2BowserJr.fireRemaining,60);assert.equal(a.smm2BowserJr.phase,'normal');assert.equal(a.smm2BowserJr.phaseAge,0);assert.equal(s.events.filter(e=>e.event==='enemy-key-released').length,0);assert.deepEqual(ruleOf(s.doc).stageTempo,authoredJrStageTempo());
});

test('author APIs preserve independent nested tempo through atomic History, clone, native clipboard and lossless JSON',()=>{
 const h=new History(bowserJrProject()),room=()=>h.doc.rooms[0],tempo=authoredJrStageTempo();h.change(()=>updateSmm2BowserJr(room(),'junior',{stageTempo:tempo}));tempo.stages[0].walkSpeed=7;assert.equal(ruleOf(h.doc).stageTempo.stages[0].walkSpeed,.5);const saved=JSON.stringify(h.doc);
 for(const bad of [null,{...authoredJrStageTempo(),unknown:true}]){assert.throws(()=>h.change(()=>updateSmm2BowserJr(room(),'junior',{stageTempo:bad})));assert.equal(JSON.stringify(h.doc),saved);}
 h.undo();assert(!Object.hasOwn(ruleOf(h.doc),'stageTempo'));h.redo();h.change(()=>cloneSmm2BowserJr(room(),'junior',{id:'tempo-copy',dx:40}));const snapshot=captureSmm2ActorLeaves(room(),new Set(['tempo-copy']));h.change(()=>{const body=structuredClone(room().map.objects.find(a=>a.id==='tempo-copy'));body.id='tempo-paste';body.x+=40;room().map.objects.push(body);appendCopiedSmm2ActorLeaves(room(),snapshot,new Map([['tempo-copy','tempo-paste']]));});
 for(const q of room().smm2Mechanics.bowserJuniors.actors)assert.deepEqual(q.stageTempo,authoredJrStageTempo());assert.notEqual(room().smm2Mechanics.bowserJuniors.actors[0].stageTempo,room().smm2Mechanics.bowserJuniors.actors[1].stageTempo);
 assert.deepEqual(parseProject(JSON.stringify(h.doc)),h.doc);h.change(()=>clearSmm2BowserJrStageTempo(room(),'tempo-copy'));assert(!Object.hasOwn(room().smm2Mechanics.bowserJuniors.actors[1],'stageTempo'));h.undo();assert.deepEqual(room().smm2Mechanics.bowserJuniors.actors[1].stageTempo,authoredJrStageTempo());
 h.change(()=>addSmm2BowserJr(room(),{id:'new-tempo',x:420,y:264,stageTempo:authoredJrStageTempo()}));assert.deepEqual(room().smm2Mechanics.bowserJuniors.actors.at(-1).stageTempo,authoredJrStageTempo());
 h.change(()=>{room().map.objects.push({id:'bound-tempo',kind:'walker',x:480,y:264,w:16,h:24});bindSmm2BowserJr(room(),'bound-tempo',{stageTempo:authoredJrStageTempo()});});assert.deepEqual(room().smm2Mechanics.bowserJuniors.actors.at(-1).stageTempo,authoredJrStageTempo());assert.deepEqual(parseProject(JSON.stringify(h.doc)),h.doc);
});

test('sidebar places and edits all 24 stage numbers, rolls back bad edits, toggles leaf and respects History',()=>{
 const ui=installSimulatedPlayDom();try{const h=new History(bowserJrProject()),room=()=>h.doc.rooms[0],parent=ui.document.createElement('aside'),reports=[];ui.document.body.append(parent);const panel=mountBowserJrTools({parent,room,change:fn=>h.change(fn),report:s=>reports.push(s)}),get=k=>parent.querySelector('[data-bowser-jr-control="'+k+'"]');
  assert.equal(get('stageTempo').checked,false);for(const hp of [3,2,1])for(const key of BOWSER_JR_TEMPO_FIELDS)assert.equal(get('hp'+hp+'-'+key).disabled,true);
  get('stageTempo').checked=true;get('stageTempo').onchange();for(const stage of authoredJrStageTempo().stages)for(const key of BOWSER_JR_TEMPO_FIELDS){assert.equal(get('hp'+stage.hp+'-'+key).disabled,false);get('hp'+stage.hp+'-'+key).value=String(stage[key]);}get('apply').click();assert.deepEqual(ruleOf(h.doc).stageTempo,authoredJrStageTempo());
  const saved=JSON.stringify(h.doc);get('hp1-fireWindupFrames').value='';get('apply').click();assert.equal(JSON.stringify(h.doc),saved);get('hp1-fireWindupFrames').value='88';get('apply').click();assert.equal(JSON.stringify(h.doc),saved);assert.equal(reports.length,2);
  get('stageTempo').checked=false;get('stageTempo').onchange();get('apply').click();assert(!Object.hasOwn(ruleOf(h.doc),'stageTempo'));h.undo();panel.refresh();assert.equal(get('stageTempo').checked,true);assert.equal(get('hp1-fireWindupFrames').value,'12');
  get('x').value='420';get('y').value='264';get('add').click();assert.equal(room().smm2Mechanics.bowserJuniors.actors.length,2);assert.deepEqual(room().smm2Mechanics.bowserJuniors.actors[1].stageTempo,authoredJrStageTempo());assert.deepEqual(parseProject(JSON.stringify(h.doc)),h.doc);
 }finally{ui.restore();}
});

test('collection compilation retains every stage field without inventing an original skill capability',()=>{
 const d=bowserJrTempoProject(),c=addLevel(createCollection('Neutral authored Jr tempo'),d,{id:'tempo-fixture'}),v=validateCollection(c),built=buildCollection(v,character,{includePending:true});assert.deepEqual(ruleOf(v.levels[0].project).stageTempo,ruleOf(d).stageTempo);assert(built.requiredCapabilities.includes('bowser-jr-ground-v1'));assert(!built.requiredCapabilities.some(s=>/extra-attack|skill-unlock/.test(s)));const parsed=parseProject(JSON.stringify(v.levels[0].project));assert.deepEqual(ruleOf(parsed).stageTempo,authoredJrStageTempo());
});

for(const collection of [false,true])test('actual standalone '+(collection?'collection':'single')+' preserves stage tempo, real three-stomp/fire/runtime/art parity without network',async()=>{
 const d=bowserJrTempoProject(),s=nativeSession(d),root=new URL('../atlas/',import.meta.url),built=collection?buildCollection(addLevel(createCollection('Neutral authored Jr tempo closure'),d,{id:'tempo-fixture'}),character,{includePending:true}):null,html=await offlineFile(s.pack,s.doc.rooms,p=>fs.promises.readFile(new URL(p,root),'utf8'),p=>fs.promises.readFile(new URL('assets/classic-audio/'+p,root)),()=>{},collection?{collection:built}:{}),dir=fs.mkdtempSync(path.join(os.tmpdir(),'Jr Tempo Offline With Spaces '));
 try{const htmlPath=path.join(dir,'Jr tempo player.html'),projectPath=path.join(dir,'Jr tempo.qmap.json');fs.writeFileSync(htmlPath,html);fs.writeFileSync(projectPath,JSON.stringify(d));const result=spawnSync(process.execPath,['--experimental-vm-modules',fileURLToPath(new URL('../scripts/check-bowser-jr-offline.mjs',import.meta.url)),htmlPath,projectPath,...(collection?['collection']:[])],{encoding:'utf8',timeout:45000,maxBuffer:1024*1024});assert.equal(result.status,0,result.stderr||result.stdout||String(result.error));const report=JSON.parse(result.stdout);assert.equal(report.stateAndEventsMatchEveryTick,true);assert.equal(report.networkRequests,0);assert.equal(report.headStomps,3);assert.equal(report.realKeyRewards,1);assert.equal(report.score,4000);assert(report.rasterScenes>=8);assert.equal(report.collection,collection);
 }finally{fs.rmSync(dir,{recursive:true,force:true});}
});
