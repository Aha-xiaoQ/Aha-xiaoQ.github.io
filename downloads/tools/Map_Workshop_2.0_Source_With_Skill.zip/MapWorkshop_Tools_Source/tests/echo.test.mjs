import fs from 'node:fs';
import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createEchoRecorder,pressureContact} from '../atlas/editor-echo.mjs';
import {validate,parseProject,History,clone} from '../atlas/editor-model.mjs';
import {projectPack} from '../atlas/editor-runtime.mjs';
import {createStageCatalog} from '../atlas/runtime/stage-catalog.mjs';
import {createPlatformMotor} from '../atlas/editor-mario-motor.mjs';
import {createPlatformStage} from '../atlas/editor-mario-stage.mjs';
import {createPlatformStage as originalStage} from './native-baseline/editor-mario-stage.mjs';
const character=JSON.parse(fs.readFileSync(new URL('../atlas/runtime/character.json',import.meta.url)));
function document(){return {format:'xiaoq-map-project',version:1,id:'echo-test-project',title:'Echo tests',rooms:[{roomId:'main',setting:'Overworld',map:{id:'test-map',title:'Test',width:256,height:240,tileSize:16,geometry:[{id:'floor',x:0,y:224,w:256,h:16,collision:'solid',material:'ground'}],objects:[{id:'start',kind:'spawn',x:24,y:210,w:10,h:14}],provenance:{kind:'original',source:'Echo unit tests',review:'pending',note:'Deterministic test fixture'}},markers:[],decorations:[],mechanics:{type:'echo-cooperation',version:1,maxFrames:360,anchorSpawn:'start'},devices:[{id:'plate-a',kind:'plate',actor:'ghost',label:'A',x:160,y:224,w:32,h:4},{id:'plate-c',kind:'plate',actor:'live',label:'C',x:80,y:224,w:24,h:4},{id:'gate-a',kind:'gate',label:'A',x:208,y:64,w:16,h:160,requires:['plate-a']},{id:'bridge-c',kind:'bridge',label:'C',x:96,y:160,w:64,h:8,requires:['plate-c']}]}]};}
function stage(doc=document(),driver=createPlatformStage,extra={}){const pack=projectPack(doc,'main',character,'echo-test'),plan=createStageCatalog(pack).plan(pack.stages[0].id,pack.characters[0].id,{allowDraft:true});return driver({plan,motor:createPlatformMotor(),visualRooms:doc.rooms,emit(){},...extra});}
function rawPose(p){return Object.fromEntries(['x','y','w','h','vx','vy','facing','grounded','power','anim','crouch','swimming','swimStroke','onVine','springId'].filter(k=>p[k]!==undefined).map(k=>[k,p[k]]));}
const settle=s=>{for(let i=0;i<4;i++)s.step({});};
test('qmap validate, parse and history preserve extension identity and links',()=>{
 const d=document(),id=d.id;validate(d);const parsed=parseProject(JSON.stringify(d));assert.equal(parsed.id,id);assert.deepEqual(parsed.rooms[0].devices,d.rooms[0].devices);assert.deepEqual(parsed.rooms[0].mechanics,d.rooms[0].mechanics);
 const history=new History(d);history.change(doc=>doc.rooms[0].devices[0].x+=8);assert.equal(history.doc.rooms[0].devices[0].x,168);history.undo();assert.equal(history.doc.rooms[0].devices[0].x,160);history.redo();assert.equal(history.doc.id,id);
});
test('invalid versions, coordinates, references, actor channels and duplicate device IDs fail',()=>{
 const mutations=[d=>d.rooms[0].mechanics.version=2,d=>d.rooms[0].devices[0].x=250,d=>d.rooms[0].devices[2].requires=['missing'],d=>d.rooms[0].devices[0].actor='either',d=>d.rooms[0].devices[0].id='floor',d=>delete d.rooms[0].mechanics];
 for(const mutate of mutations){const d=document();mutate(d);assert.throws(()=>validate(d));}
});
test('only grounded feet pressure a pad, and actor channels remain separate',()=>{
 const room=document().rooms[0],echo=createEchoRecorder(room),atA={x:168,y:210,w:10,h:14,grounded:true},atC={...atA,x:86};
 assert.ok(pressureContact(atA,room.devices[0]));assert.equal(pressureContact({...atA,grounded:false},room.devices[0]),false);assert.equal(pressureContact({...atA,y:200},room.devices[0]),false);
 echo.apply([],atA);assert.equal(echo.view().devices.find(d=>d.id==='plate-a').active,false);echo.start(atA);echo.afterFrame(atA);echo.commit();echo.apply([],atC);const v=echo.view();assert.equal(v.devices.find(d=>d.id==='plate-a').active,true);assert.equal(v.devices.find(d=>d.id==='plate-c').active,true);assert.equal(v.devices.find(d=>d.id==='gate-a').solid,false);assert.equal(v.devices.find(d=>d.id==='bridge-c').solid,true);
});
test('AND links latch only on simultaneous ghost/live contact and reset locally',()=>{
 const room=document().rooms[0];room.devices.push({id:'final',kind:'gate',label:'B+C',x:224,y:64,w:16,h:160,requires:['plate-a','plate-c'],latch:true});const echo=createEchoRecorder(room),a={x:168,y:210,w:10,h:14,grounded:true},c={...a,x:86};
 echo.start(a);echo.afterFrame(a);echo.commit();echo.apply([],a);assert.equal(echo.view().devices.find(d=>d.id==='final').latched,false);echo.apply([],c);assert.equal(echo.view().devices.find(d=>d.id==='final').latched,true);echo.apply([],{...c,x:30});assert.equal(echo.view().devices.find(d=>d.id==='final').solid,false);echo.reset();echo.apply([],{...c,x:30});assert.equal(echo.view().devices.find(d=>d.id==='final').solid,true);
});
test('R starts from room anchor, records native poses, rewinds, plays once, holds final pose',()=>{
 const s=stage();s.step({x:1,run:true});s.step({echo:true});assert.equal(s.view().p.x,24);assert.equal(s.view().echo.phase,'recording');assert.equal(s.view().echo.frames,0);
 const poses=[];for(let i=0;i<70;i++){s.step({x:1,run:true,jump:i>=20&&i<38});poses.push(rawPose(s.view().p));}
 const old=s.view();s.step({echo:true});assert.equal(s.view().p.x,24);assert.equal(s.view().p.y,210);assert.equal(s.view().tick,0);assert.equal(s.view().echo.phase,'playing');assert.equal(s.view().echo.frames,70);assert.ok(old.p.x>24);
 for(let i=0;i<70;i++){s.step({});assert.deepEqual(rawPose(s.view().echo.ghost),poses[i]);}
 assert.equal(s.view().echo.phase,'holding');const last=clone(s.view().echo.ghost);for(let i=0;i<100;i++)s.step({});assert.deepEqual(s.view().echo.ghost,last);assert.equal(s.view().echo.cursor,70);
});
test('held R cannot repeatedly reset recording; fresh edge commits',()=>{
 const s=stage();s.step({echo:true});for(let i=0;i<5;i++)s.step({echo:true,x:1});assert.equal(s.view().echo.phase,'recording');assert.equal(s.view().echo.frames,5);s.step({});s.step({echo:true});assert.equal(s.view().echo.phase,'playing');
});
test('six seconds automatically commits and rewinds after exactly 360 physics frames',()=>{
 const s=stage();s.step({echo:true});for(let i=0;i<359;i++)s.step({});assert.equal(s.view().echo.phase,'recording');assert.equal(s.view().echo.frames,359);s.step({});assert.equal(s.view().echo.phase,'playing');assert.equal(s.view().echo.frames,360);assert.equal(s.view().p.x,24);assert.equal(s.view().tick,0);
});
test('ghost never collects coins or affects enemies; rewound state is genuine',()=>{
 const d=document();d.rooms[0].map.objects.push({id:'coin',kind:'coin',x:100,y:206,w:10,h:14},{id:'enemy',kind:'walker',x:236,y:208,w:16,h:16});
 const s=stage(d);s.step({echo:true});for(let i=0;i<70;i++)s.step({x:1,run:true});assert.ok(s.view().coins>0);s.step({echo:true});assert.equal(s.view().coins,0);assert.ok(s.view().objects.some(o=>o.id==='coin'));
 const baseline=stage(clone(d));
 for(let i=0;i<100;i++){s.step({});baseline.step({});assert.deepEqual(s.view().enemies,baseline.view().enemies);assert.equal(s.view().coins,baseline.view().coins);}
 assert.ok(s.view().objects.some(o=>o.id==='coin'));assert.ok(!s.view().geometry.some(g=>g.id.includes('ghost')));
});
test('gates and bridges are real native motor collision geometry',()=>{
 const d=document();d.rooms[0].devices[2].x=80;const s=stage(d);for(let i=0;i<80;i++)s.step({x:1,run:true});assert.equal(s.view().p.x,70);assert.equal(s.view().p.vx,0);
 const echo=createEchoRecorder(document().rooms[0]),p={x:86,y:210,w:10,h:14,grounded:true};const solids=echo.apply([],p);assert.ok(solids.some(g=>g.id==='bridge-c'&&g.collision==='solid'));assert.ok(solids.some(g=>g.id==='gate-a'&&g.collision==='solid'));
});
test('death clears tape and R preserves the life cost instead of refunding it',()=>{
 const d=document();d.rooms[0].map.objects.push({id:'hazard',kind:'hazard',x:72,y:210,w:16,h:14});const s=stage(d);s.step({echo:true});for(let i=0;i<55&&!s.view().p.dying;i++)s.step({x:1,run:true});assert.ok(s.view().p.dying);assert.equal(s.view().lives,2);assert.equal(s.view().echo.phase,'idle');assert.equal(s.view().echo.ghost,null);s.step({echo:true});assert.equal(s.view().lives,2);assert.equal(s.view().p.x,24);assert.equal(s.view().echo.phase,'recording');
});
test('echo opt-out matches original stage behavior and exact state for natural inputs',()=>{
 const d=document();delete d.rooms[0].mechanics;delete d.rooms[0].devices;const modified=stage(d),original=stage(d,originalStage);
 for(let i=0;i<300;i++){const input={x:i<80?1:i<145?-1:0,run:i<140,jump:i>=35&&i<60||i>=110&&i<125,echo:i===150};modified.step(input);original.step(input);assert.deepEqual(modified.view(),original.view());}
});
test('offline module list closes over the new echo extension and R is edge-only',()=>{
 const offline=fs.readFileSync(new URL('../atlas/editor-offline.mjs',import.meta.url),'utf8'),play=fs.readFileSync(new URL('../atlas/editor-play.mjs',import.meta.url),'utf8');assert.match(offline,/'editor-echo\.mjs'/);assert.match(play,/if\(!e.repeat\).*?KeyR.*?pending.echo=true/);assert.match(play,/echo:!!pending.echo/);assert.match(play,/drawEchoWorld\(c,v.echo,room\)/);assert.match(play,/drawEchoHud\(c,v.echo\)/);
});
test('selected starting lives and powered body remain correct after a recording rewind',()=>{
 const s=stage(document(),createPlatformStage,{initialState:{lives:6,power:1,coins:9,score:1200}});const anchor=s.view();s.step({echo:true});for(let i=0;i<45;i++)s.step({x:1,run:true});s.step({echo:true});const v=s.view();assert.equal(v.lives,6);assert.equal(v.coins,9);assert.equal(v.score,1200);assert.equal(v.p.power,1);assert.equal(v.p.h,28);assert.equal(v.p.y,anchor.p.y);
});
test('a rewound 100th coin cannot duplicate an extra life',()=>{
 const d=document();d.rooms[0].map.objects.push({id:'hundredth',kind:'coin',x:60,y:206,w:10,h:14});const s=stage(d,createPlatformStage,{initialState:{lives:3,coins:99}});s.step({echo:true});for(let i=0;i<45;i++)s.step({x:1,run:true});assert.equal(s.view().lives,4);s.step({echo:true});assert.equal(s.view().lives,3);assert.equal(s.view().coins,99);assert.ok(s.view().objects.some(o=>o.id==='hundredth'));
});
test('a closing gate defers its solid body while the live player occupies the doorway',()=>{
 const room=document().rooms[0],echo=createEchoRecorder(room),p={x:212,y:210,w:10,h:14,grounded:true};echo.apply([],p);assert.equal(echo.view().devices.find(d=>d.id==='gate-a').deferred,true);assert.equal(echo.view().devices.find(d=>d.id==='gate-a').solid,false);echo.apply([],{...p,x:240});assert.equal(echo.view().devices.find(d=>d.id==='gate-a').solid,true);
});
test('entering an echo room sets and rewinds its own checkpoint anchor',()=>{
 const d=document(),a=d.rooms[0],b=clone(a);b.roomId='second';b.map.id='second-map';a.map.objects.push({id:'next',kind:'portal',x:20,y:200,w:24,h:24,targetRoom:'second',targetSpawn:'start'});d.rooms.push(b);const s=stage(d);for(let i=0;i<25;i++)s.step({});s.step({interact:true});assert.equal(s.view().roomId,'second');assert.deepEqual(s.view().checkpoint,{roomId:'second',spawnId:'start'});s.step({echo:true});s.step({});s.step({echo:true});assert.deepEqual(s.view().checkpoint,{roomId:'second',spawnId:'start'});
});
test('single-screen echo exit finishes at its reachable boundary and completes',()=>{
 const d=document();d.rooms[0].devices=[];d.rooms[0].map.objects.push({id:'finish',kind:'exit',x:232,y:192,w:16,h:32});const s=stage(d);for(let i=0;i<700&&!s.view().completed;i++)s.step({x:1,run:true});assert.equal(s.view().completed,true);assert.equal(s.view().lives,3);assert.equal(s.view().finish.phase,'score');
});
test('ordinary echo death respawns with healthy current-room baseline before another R retry',()=>{
 const d=document();d.rooms[0].map.objects.push({id:'hazard',kind:'hazard',x:72,y:210,w:16,h:14});const s=stage(d);for(let i=0;i<60&&!s.view().p.dying;i++)s.step({x:1,run:true});assert.ok(s.view().p.dying);for(let i=0;i<110;i++)s.step({});assert.equal(s.view().health,1);assert.equal(s.view().lives,2);s.step({echo:true});assert.equal(s.view().health,1);assert.equal(s.view().lives,2);assert.equal(s.view().p.x,24);
});
test('experimental editor prevents sidecar-stripping developer/campaign exports',()=>{
 const editor=fs.readFileSync(new URL('../atlas/editor.mjs',import.meta.url),'utf8');assert.match(editor,/pack-export'\)\.onclick=async\(\)=>\{if\(history.doc.rooms.some\(r=>echoEnabled\(r\)\|\|r.switchStudy\|\|r.marioModules/);assert.doesNotMatch(editor,/buildCampaign|generated\/levels\//);assert.match(editor,/exportCustomCollection/);
});
