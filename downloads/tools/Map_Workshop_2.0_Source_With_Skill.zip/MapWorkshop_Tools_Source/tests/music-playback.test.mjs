import test from 'node:test';
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {blank} from '../atlas/editor-model.mjs';
import {projectPack} from '../atlas/editor-runtime.mjs';
import {play} from '../atlas/editor-play.mjs';
import {audioFiles,createSound,themeFor} from '../atlas/editor-audio.mjs';
import {offlineFile} from '../atlas/editor-offline.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';
import {installSimulatedAudio} from './fixtures/simulated-audio.mjs';
const character=JSON.parse(fs.readFileSync(new URL('../atlas/runtime/character.json',import.meta.url)));
const flush=async()=>{await Promise.resolve();await Promise.resolve();};
async function start({brief=true,requireGesture=true,hazard=false,timeLimit=400,portal=false,media={}}={}){
 const dom=installSimulatedPlayDom(),audio=installSimulatedAudio({requireGesture}),d=blank('Castle audio fixture',384,240),room=d.rooms[0];
 room.setting='Castle';room.map.geometry=[{id:'floor',x:0,y:224,w:384,h:16,collision:'solid',material:'ground'}];Object.assign(room.map.objects[0],{x:40,y:210,w:10,h:14});
 room.playRules={version:1,timeLimit,timerFrames:24,viewportWidth:256,viewportHeight:240,cameraAnchor:100};
 if(hazard)room.map.objects.push({id:'hazard',kind:'hazard',x:68,y:208,w:16,h:16});
 if(portal){room.map.objects.push({id:'exit',kind:'portal',x:40,y:200,w:24,h:24,targetRoom:'water',targetSpawn:'arrival'});const next=structuredClone(room);next.roomId='water';next.setting='Underwater';next.map.id='water-map';next.map.objects=[{id:'arrival',kind:'spawn',x:40,y:210,w:10,h:14}];d.rooms.push(next);}
 if(brief)room.missionBrief={version:1,number:13,title:'Castle music',description:'Audio lifecycle fixture',client:'Fixture',difficulty:1,rewardCoins:0};
 const pack=projectPack(d,'main',character,'castle-audio-fixture'),session=await audio.gesture(()=>play(pack,d.rooms,media, {developerMode:false}));
 const canvas=session.screen.querySelector('canvas[aria-label]');
 return {dom,audio,d,pack,session,read:()=>canvas.workshopRead(),confirm(){audio.gesture(()=>session.screen.querySelector('.mission-start').click());},close(){session.close();audio.restore();dom.restore();}};
}
test('mission confirmation starts looping Castle BGM inside the gesture, before RAF',async()=>{
 const q=await start();try{q.confirm();await flush();assert.equal(q.read().audio.playing,true);assert.equal(q.read().audio.track,'castle');assert(q.audio.calls.some(c=>c.loop&&c.gesture));assert.equal(q.read().tick,0);}finally{q.close();}
});
test('a rejected RAF start retries on the next gameplay keyboard gesture',async()=>{
 const dom=installSimulatedPlayDom(),audio=installSimulatedAudio({requireGesture:true});let session;
 try{const d=blank('Retry BGM',384,240),r=d.rooms[0];r.setting='Castle';r.map.geometry=[{id:'floor',x:0,y:224,w:384,h:16,collision:'solid',material:'ground'}];Object.assign(r.map.objects[0],{x:40,y:210,w:10,h:14});session=await play(projectPack(d,'main',character,'retry-music-fixture'),d.rooms,{}, {developerMode:false});dom.frames(2);await flush();const read=()=>session.screen.querySelector('canvas[aria-label]').workshopRead();assert.equal(read().audio.blocked,true);audio.gesture(()=>dom.key('Space'));await flush();assert.equal(read().audio.playing,true);assert.equal(read().audio.blocked,false);}finally{session?.close();audio.restore();dom.restore();}
});
test('direct legacy launch calls looping BGM play before asynchronous preparation',async()=>{
 const q=await start({brief:false});try{await flush();assert(q.audio.calls[0].loop);assert(q.audio.calls[0].gesture);q.dom.frames(3);await flush();assert.equal(q.read().audio.track,'castle');assert.equal(q.read().audio.playing,true);assert.equal(q.audio.music().length,1);}finally{q.close();}
});
test('keyboard mission confirmation and touch retry stay inside their input gestures',async()=>{
 const q=await start();try{q.audio.gesture(()=>q.dom.key('Enter'));await flush();assert.equal(q.read().audio.playing,true);}finally{q.close();}
 const dom=installSimulatedPlayDom(),audio=installSimulatedAudio({requireGesture:true});let session;
 try{const d=blank('Touch BGM',384,240),r=d.rooms[0];r.setting='Castle';r.map.geometry=[{id:'floor',x:0,y:224,w:384,h:16,collision:'solid',material:'ground'}];session=await play(projectPack(d,'main',character,'touch-music-fixture'),d.rooms,{},{});dom.frames(2);await flush();audio.gesture(()=>session.screen.querySelector('[data-control="right"]').dispatchEvent({type:'pointerdown',pointerId:1}));await flush();assert.equal(session.screen.querySelector('canvas[aria-label]').workshopRead().audio.playing,true);}finally{session?.close();audio.restore();dom.restore();}
});
test('mute/unmute preserves music position and starts immediately without RAF',async()=>{
 const q=await start();try{q.confirm();await flush();const a=q.audio.music()[0],mute=q.session.screen.querySelector('button[aria-label="声音开关"]');a.currentTime=12.5;q.audio.gesture(()=>mute.click());assert.equal(q.read().audio.enabled,false);assert(a.paused);assert.equal(a.currentTime,12.5);q.dom.frames(4);q.audio.gesture(()=>mute.click());await flush();assert.equal(q.read().audio.playing,true);assert.equal(a.currentTime,12.5);assert.equal(q.audio.music().length,1);}finally{q.close();}
});
test('pause/resume and mission revisit keep the same background cursor',async()=>{
 const q=await start();try{q.confirm();await flush();const a=q.audio.music()[0];a.currentTime=8.25;q.audio.gesture(()=>q.dom.key('KeyP'));q.dom.release('KeyP');assert(a.paused);const tick=q.read().tick;q.dom.frames(40);assert.equal(q.read().tick,tick);assert.equal(a.currentTime,8.25);q.audio.gesture(()=>q.dom.key('KeyP'));q.dom.release('KeyP');await flush();assert.equal(q.read().audio.playing,true);assert.equal(a.currentTime,8.25);q.audio.gesture(()=>q.session.screen.querySelector('button[aria-label="重看关前委托"]').click());assert(a.paused);q.audio.gesture(()=>q.dom.key('Escape'));await flush();assert.equal(q.read().audio.playing,true);assert.equal(a.currentTime,8.25);}finally{q.close();}
});
test('visibility loss silences music and restoration waits for resume',async()=>{
 const q=await start();try{q.confirm();await flush();q.audio.music()[0].currentTime=15;q.dom.document.hidden=true;q.dom.document.dispatchEvent({type:'visibilitychange'});assert.equal(q.read().audio.playing,false);const tick=q.read().tick;q.dom.frames(40);assert.equal(q.read().tick,tick);q.dom.document.hidden=false;q.dom.document.dispatchEvent({type:'visibilitychange'});q.dom.frames(5);assert.equal(q.read().audio.playing,false);q.audio.gesture(()=>q.dom.key('KeyP'));await flush();assert.equal(q.read().audio.playing,true);assert.equal(q.audio.music()[0].currentTime,15);}finally{q.close();}
});
test('real stage death stops BGM, then restart begins one Castle track at zero',async()=>{
 const q=await start({hazard:true});try{q.confirm();await flush();const a=q.audio.music()[0];a.currentTime=20;q.audio.gesture(()=>q.dom.key('ArrowRight'));for(let i=0;i<60&&!q.read().p.dying;i++)q.dom.frames();q.dom.release('ArrowRight');assert(q.read().p.dying);assert.equal(q.read().audio.playing,false);assert.equal(q.read().audio.track,'');q.audio.gesture(()=>[...q.session.screen.querySelectorAll('button')].find(b=>b.textContent==='重新开始').click());await flush();assert.equal(q.read().audio.playing,true);assert.equal(q.read().audio.track,'castle');assert.equal(a.currentTime,0);assert.equal(q.audio.music().length,1);q.session.close();assert(a.paused);}finally{q.close();}
});
test('room portal and native hurry threshold switch themes on one element',async()=>{
 const q=await start({portal:true,timeLimit:101});try{q.confirm();await flush();const a=q.audio.music()[0];q.audio.gesture(()=>q.dom.key('ArrowDown'));for(let i=0;i<180&&q.read().roomId!=='water';i++)q.dom.frames();q.dom.release('ArrowDown');await flush();assert.equal(q.read().roomId,'water');assert.equal(q.read().audio.track,q.read().timeLeft<=100?'hurry_underwater':'underwater');q.dom.frames(30);await flush();assert.equal(q.read().audio.track,'hurry_underwater');assert.equal(q.audio.music().length,1);assert.equal(q.audio.music()[0],a);assert(a.src.endsWith('/hurry_underwater.mp3'));}finally{q.close();}
});
test('Castle hurry and star theme selection retain the native variants',()=>{
 assert.equal(themeFor('Castle',false,101),'castle');assert.equal(themeFor('Castle',false,100),'hurry_castle');assert.equal(themeFor('Underwater',false,400),'underwater');assert.equal(themeFor('Underwater',true,99),'hurry_star');
});
test('background loops independently, keeps original gains and avoids duplicate RAF play calls',async()=>{
 const audio=installSimulatedAudio();try{const sound=createSound();sound.resumeMusic('castle',true);for(let i=0;i<100;i++)sound.background('castle');await flush();const a=audio.music()[0];assert.equal(a.playCalls,1);assert.equal(a.loop,true);assert.equal(a.volume,.35);a.currentTime=40;a.end();assert.equal(a.currentTime,0);assert.equal(sound.snapshot().playing,true);sound.effect('jump');sound.effect('bill_N');await flush();assert.equal(audio.instances.find(q=>q.effectKey==='jump').volume,.65);assert.equal(audio.instances.find(q=>q.effectKey==='bill_N').volume,.12);sound.pause();sound.toggle();sound.toggle();assert(a.paused);sound.resumeMusic('castle',true);await flush();assert.equal(sound.snapshot().playing,true);sound.background('underwater');sound.background('hurry_castle');await flush();assert.equal(audio.music().length,1);assert.equal(sound.snapshot().track,'hurry_castle');assert.equal(sound.snapshot().playing,true);sound.stop();}finally{audio.restore();}
});
test('gamepad mission, pause and mute routes control BGM under an allowed autoplay policy',async()=>{
 const q=await start({requireGesture:false});try{const gp={index:0,id:'Simulated Xbox audio',mapping:'standard',connected:true,axes:[0,0],buttons:Array.from({length:18},()=>({pressed:false,value:0}))};q.dom.pads[0]=gp;q.dom.frames(2);const press=async index=>{gp.buttons[index]={pressed:true,value:1};q.dom.frames(2);gp.buttons[index]={pressed:false,value:0};q.dom.frames(2);await flush();};await press(0);assert.equal(q.read().audio.playing,true);await press(9);assert.equal(q.read().audio.playing,false);await press(9);assert.equal(q.read().audio.playing,true);await press(8);assert.equal(q.read().audio.enabled,false);await press(8);assert.equal(q.read().audio.playing,true);assert.equal(q.audio.music().length,1);}finally{q.close();}
});
test('embedded offline Castle bytes are the BGM source during actual mission playback',async()=>{
 const bytes=fs.readFileSync(new URL('../atlas/assets/classic-audio/castle.mp3',import.meta.url)),src='data:audio/mpeg;base64,'+bytes.toString('base64'),q=await start({media:{castle:src}});try{q.confirm();await flush();assert.equal(q.audio.music()[0].src,src);assert.equal(q.read().audio.track,'castle');assert.equal(q.read().audio.playing,true);}finally{q.close();}
});
test('late rejected play promises cannot block a newer room track or restart music after close',async()=>{
 const audio=installSimulatedAudio();try{const sound=createSound();audio.deferNext();sound.resumeMusic('castle',true);assert.equal(sound.snapshot().pending,true);sound.background('underwater');await flush();audio.pending.shift().reject(Object.assign(new Error('stale'),{name:'AbortError'}));await flush();assert.equal(sound.snapshot().track,'underwater');assert.equal(sound.snapshot().blocked,false);assert.equal(sound.snapshot().playing,true);audio.deferNext();sound.background('hurry_castle');sound.stop();audio.pending.shift().resolve();await flush();assert.equal(sound.snapshot().playing,false);assert.equal(sound.snapshot().track,'');assert.equal(audio.music().length,1);}finally{audio.restore();}
});
test('derived Castle WAV is non-silent, has the documented full cycle and provenance hashes',()=>{
 const root=new URL('../atlas/assets/classic-audio/',import.meta.url),meta=JSON.parse(fs.readFileSync(new URL('AUDIO_LOOP_PROVENANCE.json',root))),source=fs.readFileSync(new URL(meta.source.file,root)),wav=fs.readFileSync(new URL(meta.derivative.file,root)),hash=b=>createHash('sha256').update(b).digest('hex');
 assert.equal(audioFiles.castle,'castle-loop.wav');assert.equal(hash(source),meta.source.sha256);assert.equal(hash(wav),meta.derivative.sha256);assert.equal(wav.toString('ascii',0,4),'RIFF');assert.equal(wav.toString('ascii',8,12),'WAVE');assert.equal(wav.readUInt16LE(22),2);assert.equal(wav.readUInt32LE(24),44100);assert.equal(wav.readUInt16LE(34),16);assert.equal(wav.readUInt32LE(40),352256*4);assert.equal(meta.derivative.crop_end_frame_exclusive-meta.derivative.crop_start_frame_inclusive,352256);assert(meta.derivative.decoded.rms>.05);const data=wav.subarray(44);for(let channel=0;channel<2;channel++)assert(Math.abs(data.readInt16LE(channel*2)-data.readInt16LE(data.length-4+channel*2))/32767<.01);
});
test('offline export embeds the actual derived Castle WAV and unchanged hurry recording',async()=>{
 const q=await start();try{const html=await offlineFile(q.pack,q.d.rooms,async path=>fs.readFileSync(new URL('../atlas/'+path.replace(/^\.\//,''),import.meta.url),'utf8'),async name=>new Uint8Array(fs.readFileSync(new URL('../atlas/assets/classic-audio/'+name,import.meta.url))));const get=key=>html.match(new RegExp('"'+key+'":"data:audio/([^;]+);base64,([^"\\s]+)"'));const castle=get('castle'),hurry=get('hurry_castle');assert.equal(castle[1],'wav');assert.deepEqual(Buffer.from(castle[2],'base64'),fs.readFileSync(new URL('../atlas/assets/classic-audio/castle-loop.wav',import.meta.url)));assert.equal(hurry[1],'mpeg');assert.deepEqual(Buffer.from(hurry[2],'base64'),fs.readFileSync(new URL('../atlas/assets/classic-audio/hurry_castle.mp3',import.meta.url)));}finally{q.close();}
});
test('muted room changes and replay retain mute until explicit unmute',async()=>{
 const q=await start({portal:true});try{q.confirm();await flush();const mute=q.session.screen.querySelector('button[aria-label="声音开关"]');q.audio.gesture(()=>mute.click());q.audio.gesture(()=>q.dom.key('ArrowDown'));for(let i=0;i<180&&q.read().roomId!=='water';i++)q.dom.frames();q.dom.release('ArrowDown');assert.equal(q.read().roomId,'water');assert.equal(q.read().audio.enabled,false);assert.equal(q.read().audio.playing,false);q.audio.gesture(()=>mute.click());await flush();assert.equal(q.read().audio.track,'underwater');assert.equal(q.read().audio.playing,true);q.audio.gesture(()=>mute.click());await q.session.load(q.pack,q.d.rooms,{developerMode:false});q.dom.frames(3);await flush();assert.equal(q.read().audio.enabled,false);assert.equal(q.read().audio.playing,false);q.audio.gesture(()=>mute.click());await flush();assert.equal(q.read().audio.track,'castle');assert.equal(q.read().audio.playing,true);assert.equal(q.audio.music().length,1);}finally{q.close();}
});

test('unavailable SMB3 Desert music stops the previous room theme and keeps actual SFX',async()=>{
 assert.equal(themeFor('SMB3 Desert',false,500),'smb3_overworld');assert.equal(audioFiles.smb3_overworld,null);
 const audio=installSimulatedAudio();try{
  const sound=createSound();sound.resumeMusic('castle',true);await flush();assert.equal(sound.snapshot().playing,true);
  sound.resumeMusic('smb3_overworld',true);await flush();assert.equal(sound.snapshot().track,'');assert.equal(sound.snapshot().playing,false);assert.equal(audio.music().length,1);
  sound.effect('jump');await flush();assert(audio.instances.some(q=>q.effectKey==='jump'));
 }finally{audio.restore();}
});
