import test from 'node:test';
import assert from 'node:assert/strict';
import {createCanvas} from '@napi-rs/canvas';
import {blank,validate,parseProject,History,addSmm2BowserJr,updateSmm2BowserJr,cloneSmm2BowserJr,moveSelection,deleteSelection} from '../atlas/editor-model.mjs';
import {createBowserJuniors,BOWSER_JR_AUTHORING_DEFAULTS,validateBowserJrRule,bowserJrView} from '../atlas/editor-bowser-jr.mjs';
import {captureSmm2ActorLeaves,appendCopiedSmm2ActorLeaves,pruneSmm2DeletedReferences} from '../atlas/editor-smm2-tools.mjs';
import {mountBowserJrTools} from '../atlas/editor-bowser-jr-tools.mjs';
import {drawObject} from '../atlas/editor-art.mjs';
import {BOWSER_JR_PIXELS} from '../atlas/editor-bowser-jr-pixels.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';
import {addContraptionDoorPair} from '../atlas/editor-contraptions-tools.mjs';
import {nativeSession} from './fixtures/shell-coin-native.mjs';
import {bowserJrProject,threeNativeJrStomps} from './fixtures/bowser-jr-native.mjs';

test('strict opt-in source contract round-trips and rejects unsupported forms and conflicting owners',()=>{
 const d=bowserJrProject();assert.deepEqual(parseProject(JSON.stringify(d)),d);const v=nativeSession(d);assert.equal(v.view().enemies[0].id,'junior');assert.equal(v.view().enemies[0].hp,3);assert.equal(v.view().enemies[0].type,'bowser-jr');
 for(const change of [q=>q.size='giant',q=>q.wings=true,q=>q.kind='bowser',q=>q.shellFrames=0,q=>q.fireSpeed=NaN,q=>q.sourceParameterStatus='original-calibrated']){const bad={...BOWSER_JR_AUTHORING_DEFAULTS};change(bad);assert.throws(()=>validateBowserJrRule(bad));}
 for(const change of [r=>r.map.objects[1].h=22,r=>r.enemySkins={junior:'bowser'},r=>r.setting='SMW Overworld',r=>r.smm2Mechanics.bowserJuniors.actors.push(structuredClone(r.smm2Mechanics.bowserJuniors.actors[0])),r=>r.marioModules={version:1,enemyVariants:{junior:{kind:'walking-koopa'}}}]){const bad=structuredClone(d);change(bad.rooms[0]);assert.throws(()=>validate(bad));}
});

test('genuine Small inputs perform two protected shell pursuits/recoveries and third-hit 4000 plus one physical key',()=>{
 const s=nativeSession(bowserJrProject());threeNativeJrStomps(s);assert.equal(s.view().p.power,0);assert(!s.view().p.dying);assert.equal(s.view().score,4000);assert.equal(s.view().enemies.filter(e=>e.id==='junior').length,0);
 const events=s.events.filter(e=>e.type==='smm2-bowser-jr');assert.deepEqual(events.filter(e=>e.event==='head-stomp').map(e=>e.hp),[2,1]);assert.equal(events.filter(e=>e.event==='recovery-hop').length,2);assert.equal(events.filter(e=>e.event==='head-revealed').length,2);assert.equal(events.filter(e=>e.event==='defeated').length,1);
 assert.equal(s.events.filter(e=>e.event==='enemy-key-released').length,1);const key=s.view().items.find(i=>i.kind==='key'),fall=s.view().items.find(i=>i.kind==='enemy-death'&&i.id==='junior');assert(key&&!key.dead);assert.equal(fall.smm2DefeatOrientation,'upside-down');assert.equal(fall.flat,false);assert.equal(fall.vy,-3);assert.equal(fall.vx,0);
 s.until(v=>v.contraptions.keys===1,{},180);assert.equal(s.view().contraptions.keyFollowers.length,1);s.frames(30);assert.equal(s.events.filter(e=>e.event==='enemy-key-released').length,1);
});

test('shell changes pursuit direction while its head cannot take another hit',()=>{
 const r=bowserJrProject().rooms[0],c=createBowserJuniors(r),a=c.decorateActor({...r.map.objects[1],dead:false}),before={x:306,y:246,w:10,h:14},p={...before,y:256,vy:2};
 assert.equal(c.playerContact(a,p,before,{tick:1,beforeActor:{...a}}).bounce,true);assert.equal(a.hp,2);assert.equal(a.h,16);assert.equal(bowserJrView(a).exposed,false);
 const shellHit=c.playerContact(a,{x:a.x+2,y:a.y-8,w:10,h:14},{x:a.x+2,y:a.y-20,w:10,h:14},{tick:2,beforeActor:{...a}});assert.equal(shellHit.harmful,true);assert.equal(shellHit.bounce,false);assert.equal(a.hp,2);
 let right=false,left=false;for(let tick=2;tick<40;tick++){c.stepActor(a,{tick,player:{x:tick<20?500:20,y:274,w:10,h:14},geometry:r.map.geometry});if(tick<20&&a.vx>0)right=true;if(tick>20&&a.vx<0)left=true;}assert(right&&left);assert.equal(a.hp,2);assert.equal(a.smm2BowserJr.phase,'shell');
});

test('displayed opaque-pixel contact leaves transparent normal and shell margins harmless',()=>{
 const r=bowserJrProject().rooms[0],c=createBowserJuniors(r),a=c.decorateActor({...r.map.objects[1],dead:false});const corner={x:a.x+.05,y:a.y+.05,w:.5,h:.5,vy:1};const result=c.playerContact(a,corner,{...corner,y:corner.y-1},{tick:1,beforeActor:{...a}});assert.equal(result.handled,true);assert.equal(result.harmful,false);assert.equal(result.bounce,false);assert.equal(a.hp,3);
 const before={x:a.x+6,y:a.y-18,w:10,h:14},p={...before,y:a.y-8,vy:2};assert(c.playerContact(a,p,before,{tick:2,beforeActor:{...a}}).bounce);assert.equal(a.w,18);assert.equal(a.h,16);const margin={x:a.x+.05,y:a.y+2,w:.5,h:8,vy:1};assert.equal(c.playerContact(a,margin,{...margin,y:margin.y-1},{tick:3,beforeActor:{...a}}).harmful,false);assert.equal(a.hp,2);
});

test('normal side contact and a genuine attempted shell stomp cause native damage, without generic boss HP loss',()=>{
 const normal=nativeSession(bowserJrProject({perches:false,spawn:{x:286,y:274}}));normal.until(v=>v.p.dying,{},80);assert.equal(normal.view().enemies[0].hp,3);assert.equal(normal.view().lives,4);
 const shell=nativeSession(bowserJrProject());shell.until(v=>v.enemies[0]?.hp===2,{},80);shell.until(v=>v.p.dying,{x:-1},100);assert.equal(shell.view().enemies[0].hp,2);assert.equal(shell.events.filter(e=>e.event==='head-stomp').length,1);
});

test('small aimed projectile travels straight toward its sampled target, without player-fireball bounce or retarget',()=>{
 const d=bowserJrProject({fireDelay:2,spawn:{x:60,y:120}}),r=d.rooms[0],rule=r.smm2Mechanics.bowserJuniors.actors[0];rule.fireWindupFrames=2;rule.fireIntervalFrames=12;
 const s=nativeSession(d);s.until(v=>v.enemies.some(e=>e.type==='bowser-jr-fireball'),{},20);const shot=s.view().enemies.find(e=>e.type==='bowser-jr-fireball'),initial=structuredClone(shot);assert.equal(shot.w,8);assert.equal(shot.h,8);assert(shot.vy<0);assert.equal(s.events.filter(e=>e.event==='fireball').length,1);
 for(let n=1;n<=5;n++){const live=s.step({x:1,run:true}).enemies.find(e=>e.id===initial.id);assert(live);assert.equal(live.vx,initial.vx);assert.equal(live.vy,initial.vy);assert.deepEqual(live.bowserJrAim,initial.bowserJrAim);assert(Math.abs(live.x-(initial.x+initial.vx*n))<1e-7);assert(Math.abs(live.y-(initial.y+initial.vy*n))<1e-7);}
 assert(s.events.some(e=>e.type==='sound'&&e.event==='bowser_fire'));
});

test('state clocks do not advance on view/pause or death freeze, and native continue seeds all three HP again',()=>{
 const s=nativeSession(bowserJrProject());s.until(v=>v.enemies[0]?.hp===2,{},80);s.stage.pause();const paused=s.view().enemies[0];for(let n=0;n<20;n++)assert.deepEqual(s.view().enemies[0],paused);s.stage.resume();s.until(v=>v.p.dying,{x:-1},100);const frozen=s.view().enemies[0];s.frames(110);assert.deepEqual(s.view().enemies[0],frozen);assert(s.stage.continueFromCurrent());assert.equal(s.view().enemies[0].hp,3);assert.equal(s.view().enemies[0].smm2BowserJr.phase,'normal');assert.equal(s.view().lives,4);
});

test('native door leave and re-entry reset only the real room actor, with fresh three-HP lifecycle',()=>{
 const d=bowserJrProject(),hub=blank('Neutral reset hub',640,320).rooms[0];hub.roomId='hub';hub.map.id='neutral-jr-reset-hub';hub.map.geometry=[{id:'hub-floor',x:0,y:288,w:640,h:32,collision:'solid',material:'ground'}];hub.map.objects=[{id:'hub-start',kind:'spawn',x:36,y:274,w:10,h:14}];d.rooms.push(hub);addContraptionDoorPair(d,'main','hub',{source:{x:224,y:198},target:{x:32,y:256},style:'plain'});
 const s=nativeSession(d);s.until(v=>v.enemies[0]?.hp===2,{},80);s.until(v=>v.p.grounded&&v.p.support==='left-perch',v=>({x:v.p.x>230?-1:0,run:true,jump:!v.p.grounded}),120);s.until(v=>v.p.grounded&&v.p.x<239,{x:-1},30);s.step({up:true});s.until(v=>v.roomId==='hub',{},30);s.frames(35);s.step({up:true});s.until(v=>v.roomId==='main',{},30);const a=s.view().enemies.find(e=>e.id==='junior');assert.equal(a.hp,3);assert.equal(a.h,24);assert.equal(a.smm2BowserJr.phase,'normal');assert.equal(a.smm2BowserJr.phaseAge,0);assert.equal(s.events.filter(e=>e.event==='enemy-key-released').length,0);
});

test('real author API and clipboard preserve stable body identity, clone config, reject edits atomically and support History',()=>{
 const h=new History(bowserJrProject()),room=()=>h.doc.rooms[0];h.change(()=>updateSmm2BowserJr(room(),'junior',{shellFrames:280,walkSpeed:.6}));assert.equal(room().smm2Mechanics.bowserJuniors.actors[0].shellFrames,280);const saved=JSON.stringify(h.doc);assert.throws(()=>h.change(()=>updateSmm2BowserJr(room(),'junior',{size:'giant'})));assert.equal(JSON.stringify(h.doc),saved);
 h.change(()=>cloneSmm2BowserJr(room(),'junior',{id:'junior-copy',dx:40}));assert.equal(room().smm2Mechanics.bowserJuniors.actors.length,2);assert.equal(room().smm2Mechanics.enemyRewards.find(q=>q.id==='junior-copy').reward,'key');h.undo();assert.equal(room().smm2Mechanics.bowserJuniors.actors.length,1);h.redo();
 const snapshot=captureSmm2ActorLeaves(room(),new Set(['junior-copy']));h.change(()=>{const a=structuredClone(room().map.objects.find(q=>q.id==='junior-copy'));a.id='pasted-junior';a.x+=40;room().map.objects.push(a);appendCopiedSmm2ActorLeaves(room(),snapshot,new Map([['junior-copy','pasted-junior']]));});assert.equal(room().smm2Mechanics.bowserJuniors.actors.find(q=>q.id==='pasted-junior').shellFrames,280);
 h.change(()=>moveSelection(room(),'objects',new Set(['pasted-junior']),16,0));assert.equal(room().map.objects.find(q=>q.id==='pasted-junior').x,396);
 h.change(()=>{const before=structuredClone(room());deleteSelection(room(),'objects',new Set(['pasted-junior']));pruneSmm2DeletedReferences(room(),before);});assert(!room().smm2Mechanics.bowserJuniors.actors.some(q=>q.id==='pasted-junior'));assert.deepEqual(parseProject(JSON.stringify(h.doc)),h.doc);
});

test('actual sidebar exposes and saves Jr tuning with History, and new static objects render distinct source-derived states',()=>{
 const ui=installSimulatedPlayDom();try{const h=new History(bowserJrProject()),room=()=>h.doc.rooms[0],parent=ui.document.createElement('aside'),reports=[];ui.document.body.append(parent);const panel=mountBowserJrTools({parent,room,change:fn=>h.change(fn),report:s=>reports.push(s)}),get=k=>parent.querySelector('[data-bowser-jr-control="'+k+'"]');get('shellFrames').value='300';get('apply').click();assert.equal(room().smm2Mechanics.bowserJuniors.actors[0].shellFrames,300);get('shellFrames').value='0';get('apply').click();assert.equal(room().smm2Mechanics.bowserJuniors.actors[0].shellFrames,300);assert(reports.length);h.undo();panel.refresh();assert.equal(get('shellFrames').value,'260');
 const native={...room().map.objects[1],x:8,y:8},normal=createCanvas(48,48),shell=createCanvas(48,48),firing=createCanvas(48,48),c=createBowserJuniors(room()),live=c.decorateActor({...native});drawObject(normal.getContext('2d'),native,0,room());drawObject(shell.getContext('2d'),{...live,w:18,h:16,shell:true,smm2BowserJr:{...live.smm2BowserJr,phase:'shell'}},0,room());drawObject(firing.getContext('2d'),{...live,smm2BowserJr:{...live.smm2BowserJr,phase:'firing'}},0,room());const pixels=c=>c.getContext('2d').getImageData(0,0,48,48).data;assert(pixels(normal).some(v=>v));assert.notDeepEqual(pixels(normal),pixels(shell));assert.notDeepEqual(pixels(normal),pixels(firing));assert.notDeepEqual(BOWSER_JR_PIXELS.normal1.rows,BOWSER_JR_PIXELS.normal2.rows);assert.notDeepEqual(BOWSER_JR_PIXELS.shell1.rows,BOWSER_JR_PIXELS.shell2.rows);
 }finally{ui.restore();}
});
