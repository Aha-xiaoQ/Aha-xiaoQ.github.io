import assert from 'node:assert/strict';
import {test} from 'node:test';
import {createHash} from 'node:crypto';
import {createRailClaws,validateRailClaws,RAIL_CLAW_DEFAULTS,RAIL_PLAYER_SWING_DEFAULTS} from '../atlas/editor-rail-claws.mjs';
const copy=structuredClone;
const close=(a,b,tolerance=1e-6)=>assert(Math.abs(a-b)<=tolerance,`${a} differs from ${b}`);
const actor=(id,x,y,extras={})=>({id,type:'goomba',x,y,w:16,h:16,vx:-.5,vy:0,hp:2,dead:false,...extras});
const player=(x=220,y=180)=>({x,y,w:10,h:14,vx:0,vy:0,grounded:false,power:0,keys:0});
function room(claw={},track={}){
 return {roomId:'test-room',map:{width:256,height:240,geometry:[],objects:[]},contraptions:{version:1,tracks:[{id:'rail-a',start:[64,20],segments:[{kind:'line',to:[128,20]}],mode:'bounce',...track}],claws:[{id:'claw-a',trackId:'rail-a',speed:1,swingDegrees:0,...claw}]}};
}
const clawView=c=>c.view().claws[0];

test('omitted rails are inert; the shared leaf tolerates sibling modules and has explicit defaults',()=>{
 const r=room();delete r.contraptions;assert.equal(createRailClaws(r),null);assert.doesNotThrow(()=>validateRailClaws(r));
 r.contraptions={version:1,noteBlocks:[{id:'sibling-note'}]};assert.equal(createRailClaws(r),null);assert.doesNotThrow(()=>validateRailClaws(r));
 r.contraptions={tracks:[],claws:[]};assert.equal(createRailClaws(r),null);
 const minimal=room();minimal.contraptions.claws=[{id:'claw-a',trackId:'rail-a'}];delete minimal.contraptions.tracks[0].mode;
 const c=createRailClaws(minimal);for(const [key,value]of Object.entries(RAIL_CLAW_DEFAULTS))assert.equal(clawView(c)[key],value);assert.equal(c.view().tracks[0].mode,'bounce');
});

test('leaf validation rejects malformed, unsafe, duplicate and out-of-room path/physics data without mutation',()=>{
 const mutations=[
  r=>r.contraptions=null,r=>r.contraptions.tracks={},r=>r.contraptions.claws={},r=>r.map.width=Infinity,
  r=>r.contraptions.tracks[0].extra=true,r=>r.contraptions.tracks[0].id='__proto__',r=>r.map.objects.push({id:'rail-a'}),
  r=>r.contraptions.tracks.push(copy(r.contraptions.tracks[0])),r=>r.contraptions.tracks[0].segments=[],
  r=>r.contraptions.tracks[0].start=[-1,20],r=>r.contraptions.tracks[0].start=[64,20,0],
  r=>r.contraptions.tracks[0].segments[0].kind='spline',r=>r.contraptions.tracks[0].segments[0].to=[300,20],
  r=>r.contraptions.tracks[0].segments[0].to=[64,20],r=>r.contraptions.tracks[0].segments[0].control=[100,100],
  r=>r.contraptions.tracks[0].segments=[{kind:'quadratic',to:[128,20]}],
  r=>r.contraptions.tracks[0].segments=[{kind:'quadratic',control:[300,20],to:[128,20]}],
  r=>r.contraptions.tracks[0].mode='loop',r=>r.contraptions.tracks[0].mode='once',
  r=>r.contraptions.claws[0].trackId='missing',r=>r.contraptions.claws[0].id='rail-a',
  r=>r.contraptions.claws[0].extra=true,r=>r.contraptions.claws[0].speed=NaN,r=>r.contraptions.claws[0].position=65,
  r=>r.contraptions.claws[0].direction=0,r=>r.contraptions.claws[0].ropeLength=0,r=>r.contraptions.claws[0].swingDegrees=90,
  r=>r.contraptions.claws[0].swingPeriodFrames=2.5,r=>r.contraptions.claws[0].catchRadius=-1,
  r=>r.contraptions.claws[0].releaseBelowHeight=Infinity,r=>r.contraptions.claws[0].regrabFrames=.5,r=>r.contraptions.claws[0].playerJumpSpeed=-1,
 ];
 for(const mutate of mutations){const r=room();mutate(r);const before=copy(r);assert.throws(()=>validateRailClaws(r));assert.deepEqual(r,before);}
 const external=room(),spec=copy(external.contraptions);delete external.contraptions;assert.doesNotThrow(()=>validateRailClaws(external,spec));
});

test('quadratic arc-length sampling evaluates the real curve and visible tangent',()=>{
 const r=room({speed:0,ropeLength:8},{start:[16,32],segments:[{kind:'quadratic',control:[80,32],to:[80,96]}]}),initial=createRailClaws(r),length=initial.view().tracks[0].length;
 assert(length>distance([16,32],[80,96]));r.contraptions.claws[0].position=length/2;const c=createRailClaws(r),q=clawView(c);
 close(q.anchor.x,64,.001);close(q.anchor.y,48,.001);close(q.grip.x,64,.001);close(q.grip.y,56,.001);close(q.tangent.x,Math.SQRT1_2,.001);close(q.tangent.y,Math.SQRT1_2,.001);
 assert(q.anchor.x!==48,'the control polygon/chord is not the traveled path');assert(c.view().tracks[0].points.length>3);
});
const distance=(a,b)=>Math.hypot(a[0]-b[0],a[1]-b[1]);

test('bounce retains overshoot through multiple endpoints and reverses correctly on a curved rail',()=>{
 const r=room({speed:0,ropeLength:8},{start:[20,20],segments:[{kind:'quadratic',control:[32,20],to:[32,32]}]}),length=createRailClaws(r).view().tracks[0].length;
 Object.assign(r.contraptions.claws[0],{position:length-2,speed:2*length+3});const c=createRailClaws(r);c.step({tick:1});const q=clawView(c);close(q.position,length-1,1e-7);assert.equal(q.direction,-1);assert(q.tangent.x<0&&q.tangent.y<0);
 const straight=createRailClaws(room({position:6,speed:27,ropeLength:8},{start:[20,20],segments:[{kind:'line',to:[28,20]}]}));straight.step({tick:1});close(clawView(straight).position,1);assert.equal(clawView(straight).direction,1);
 const backwards=createRailClaws(room({position:6,speed:3,direction:-1}));backwards.step({tick:1});assert.equal(clawView(backwards).position,3);assert.equal(clawView(backwards).direction,-1);
});

test('closed loop wraps along continuous authored geometry without an open-end teleport',()=>{
 const c=createRailClaws(room({speed:5,position:158,ropeLength:8},{start:[20,20],mode:'loop',segments:[{kind:'line',to:[60,20]},{kind:'line',to:[60,60]},{kind:'line',to:[20,60]},{kind:'line',to:[20,20]}]}));
 close(clawView(c).anchor.x,20);close(clawView(c).anchor.y,22);c.step({tick:1});close(clawView(c).position,3);close(clawView(c).anchor.x,23);close(clawView(c).anchor.y,20);
});

test('capture requires live circle/AABB contact and follows the actual moving grip',()=>{
 const events=[],c=createRailClaws(room({catchRadius:0}),{emit:(type,event)=>events.push({type,...event})}),e=actor('near',60,58),far=actor('far',190,60),dead=actor('dead',60,60,{dead:true}),p=player();
 c.step({tick:1,player:p,enemies:[e,far,dead]});assert(c.held(e));assert(!c.held(far));assert(!c.held(dead));assert(!c.playerHeld());close(e.x,65-8);close(e.y,62);assert.equal(e.vx,1);assert.equal(e.vy,0);assert.equal(e.grounded,false);assert.equal(e.support,null);
 c.step({tick:2,player:p,enemies:[e,far,dead]});close(e.x,66-8);close(e.y,62);assert.equal(far.x,190);assert.equal(dead.x,60);
 assert.equal(events.length,1);assert.equal(events[0].type,'rail-claw');assert.equal(events[0].event,'capture');assert.equal(events[0].actorId,'near');assert.deepEqual(events[0].grip,{x:65,y:62});
});

test('above Mario and out-of-sensor Mario cannot release cargo; below Mario releases at its real grip pose',()=>{
 const events=[],c=createRailClaws(room({regrabFrames:3,releaseHalfWidth:12,releaseBelowHeight:90}),{emit:(type,event)=>events.push(event)}),e=actor('cargo',60,58),p=player();
 c.step({tick:1,player:p,enemies:[e]});Object.assign(p,{x:61,y:30});c.step({tick:2,player:p,enemies:[e]});assert(c.held(e),'Mario above the grip does not release');
 Object.assign(p,{x:110,y:100});c.step({tick:3,player:p,enemies:[e]});assert(c.held(e),'outside horizontal sensor');
 Object.assign(p,{x:61,y:200});c.step({tick:4,player:p,enemies:[e]});assert(c.held(e),'outside vertical sensor');
 Object.assign(p,{x:61,y:120});c.step({tick:5,player:p,enemies:[e]});assert(!c.held(e));close(e.x,69-8);close(e.y,62);assert.equal(e.vx,1);assert.equal(e.vy,0);
 const released=events.find(q=>q.event==='release');assert.equal(released.reason,'player-below');assert.deepEqual(released.position,{x:61,y:62});assert.deepEqual(released.velocity,{x:1,y:0});
 Object.assign(p,{x:220,y:180});for(const tick of [6,7]){c.step({tick,player:p,enemies:[e]});assert(!c.held(e),'same claw respects its actor cooldown');}
 c.step({tick:8,player:p,enemies:[e]});assert(c.held(e),'same source may catch later when still physically overlapping');
});

test('two-claw relay is physical, permits another source next frame, and has no authored capture order',()=>{
 function fixture(reverse=false){const r=room();r.contraptions.tracks=[{id:'rail-a',start:[40,20],segments:[{kind:'line',to:[80,20]}],mode:'bounce'},{id:'rail-b',start:[55,20],segments:[{kind:'line',to:[56,20]}],mode:'bounce'}];r.contraptions.claws=[{id:'claw-a',trackId:'rail-a',ropeLength:32,speed:1,swingDegrees:0,catchRadius:0,regrabFrames:16},{id:'claw-b',trackId:'rail-b',ropeLength:32,speed:0,swingDegrees:0,catchRadius:5,regrabFrames:16}];if(reverse)r.contraptions.claws.reverse();return r;}
 const results=[];
 for(const reverse of [false,true]){const events=[],c=createRailClaws(fixture(reverse),{emit:(type,event)=>events.push(event)}),e=actor('relay-cargo',32,50),p=player();c.step({tick:1,player:p,enemies:[e]});assert.equal(c.view().claws.find(q=>q.heldId===e.id).id,'claw-a');
  Object.assign(p,{x:38,y:140});c.step({tick:2,player:p,enemies:[e]});assert(!c.held(e),'no transfer in the release frame');close(e.x+e.w,50);assert.equal(c.view().claws.find(q=>q.id==='claw-b').grip.x,55,'only a five-pixel circle overlap permits the next capture');
  c.step({tick:3,player:p,enemies:[e]});assert(c.held(e));assert.equal(c.view().claws.find(q=>q.heldId===e.id).id,'claw-b');assert.equal(e.y,52);assert.equal(e.dead,false);assert.equal(e.hp,2);
  Object.assign(p,{x:220,y:180});c.step({tick:4,player:p,enemies:[e]});assert(c.held(e));results.push(events.map(q=>[q.event,q.clawId,q.actorId]));
 }
 assert.deepEqual(results[0],results[1]);assert.deepEqual(results[0],[['capture','claw-a','relay-cargo'],['release','claw-a','relay-cargo'],['capture','claw-b','relay-cargo']]);
});

test('nearest simultaneous overlap wins deterministically instead of object or claw array order',()=>{
 const r=room({speed:0,catchRadius:20});r.contraptions.claws.push({...r.contraptions.claws[0],id:'claw-b',position:10});r.contraptions.claws.reverse();const c=createRailClaws(r),far=actor('far',82,60),near=actor('near',56,60);c.step({tick:1,enemies:[far,near]});assert.equal(c.view().claws.find(q=>q.id==='claw-a').heldId,'near');assert.equal(c.view().claws.find(q=>q.id==='claw-b').heldId,'far');
});

test('keys, P switches, anonymous native items and player are constraint-compatible; carried/emerging actors are excluded',()=>{
 for(const kind of ['key','p-switch','pswitch','mushroom']){const c=createRailClaws(room({speed:0})),item={kind,x:60,y:60,w:14,h:14,vx:0,vy:0};c.step({tick:1,items:[item]});assert(c.held(item));assert.equal(clawView(c).heldKind,'item');assert.match(clawView(c).heldId,/^rail-claw-item-/);assert.equal(item.kind,kind);}
 for(const extras of [{carried:true},{carriedBy:'player'},{emerge:32},{clawCatchable:false},{vehicleId:'cup'},{clownCarId:'cup'}]){const c=createRailClaws(room()),item={kind:'key',x:60,y:60,w:14,h:14,...extras};c.step({tick:1,items:[item]});assert(!c.held(item));}
});

test('held enemies remain real live actors even over nonsolid hazards and tick gaps advance one active frame',()=>{
 const c=createRailClaws(room({speed:0,swingDegrees:20,swingPeriodFrames:40})),e=actor('live',60,60,{keys:1,reward:'key'}),p=player(),geometry=[{id:'hazard',x:0,y:0,w:256,h:240,collision:'hazard',material:'spike'}];
 c.step({tick:1,player:p,enemies:[e],geometry});assert(c.held(e));const first=copy(e),frame=c.view().frame;c.step({tick:10000,player:p,enemies:[e],geometry});assert.equal(c.view().frame,frame+1);assert.notEqual(e.x,first.x);assert.notEqual(e.vy,0);assert.equal(e.dead,false);assert.equal(e.hp,2);assert.equal(e.keys,1);assert.equal(e.reward,'key');assert.equal(p.keys,0);
 e.dead=true;const atDeath=copy(e);c.step({tick:10001,player:p,enemies:[e],geometry});assert(!c.held(e));assert.deepEqual(e,atDeath,'availability cleanup neither changes a corpse nor grants rewards');assert.equal(p.keys,0);
});

test('Mario swings with actual grip velocity; a Jump edge releases with authored impulse and a held button does not',()=>{
 const r=room({speed:0,swingDegrees:20,swingPeriodFrames:40,playerJumpSpeed:5}),c=createRailClaws(r),p=player(60,60);c.releasePlayer({jump:false});c.step({tick:1,player:p});assert(c.playerHeld());c.step({tick:2,player:p});const grip=clawView(c);close(p.x,grip.grip.x-p.w/2);close(p.y,grip.grip.y);close(p.vx,grip.vx);close(p.vy,grip.vy);
 assert(c.releasePlayer({jump:true,jumpPressed:true}));assert(!c.playerHeld());close(p.vx,grip.vx);close(p.vy,grip.vy-5);assert(!c.releasePlayer({jump:true,jumpPressed:true}));c.step({tick:3,player:p});assert(!c.playerHeld());
 const raw=createRailClaws(room({speed:0,regrabFrames:0})),p2=player(60,60);assert(!raw.releasePlayer({jump:true}));raw.step({tick:1,player:p2});assert(raw.playerHeld());assert(!raw.releasePlayer({jump:true}),'raw held jump has no second edge');assert(!raw.releasePlayer({jump:false}));assert(raw.releasePlayer({jump:true}));raw.step({tick:2,player:p2});assert(!raw.playerHeld(),'release before native step cannot be recaptured immediately');
});

test('repeat and stale ticks are idempotent, view is detached, and reset restores deterministic constraints and identity',()=>{
 const r=room({swingDegrees:10}),before=copy(r),events=[],c=createRailClaws(r,{emit:(type,event)=>events.push(event)}),e=actor('repeat',60,60),p=player();assert.equal(c.step({tick:10,player:p,enemies:[e]}),true);const snapshot=copy(c.view()),bodySnapshot=copy(e);assert.equal(c.step({tick:10,player:p,enemies:[e]}),false);assert.equal(c.step({tick:9,player:p,enemies:[e]}),false);assert.deepEqual(c.view(),snapshot);assert.deepEqual(e,bodySnapshot);assert.equal(events.length,1);assert.deepEqual(r,before);
 const view=c.view();view.claws[0].grip.x=999;view.tracks[0].start[0]=999;assert.deepEqual(c.view(),snapshot);assert.throws(()=>c.step({tick:NaN}),/tick/);
 c.reset();assert(!c.held(e));assert.equal(c.view().frame,0);assert.equal(c.view().tick,0);const fresh=actor('repeat',60,60);c.step({tick:10,player:p,enemies:[fresh]});assert.deepEqual(c.view(),snapshot);assert.deepEqual(fresh,bodySnapshot);assert.equal(events.length,2);
});

test('capture cannot snap a real body into or through a visible solid; hidden and absent bricks permit it',()=>{
 const brick={id:'cage-floor',x:40,y:76,w:60,h:4,collision:'solid',material:'brick'};
 for(const geometry of [[brick],[{...brick,hidden:true}],[{...brick,visible:false}],[]]){
  const c=createRailClaws(room({speed:0})),e=actor('caged',56,58),before=copy(e);c.step({tick:1,enemies:[e],geometry});
  if(geometry.length&&!geometry[0].hidden&&geometry[0].visible!==false){assert(!c.held(e));assert.deepEqual(e,before);}else{assert(c.held(e));assert.equal(e.y,62);}
 }
 // The final box is clear, but snapping top-center to grip would cross the
 // thin cage roof. Catch-radius contact alone cannot extract the actor.
 const c=createRailClaws(room({speed:0,catchRadius:32})),e=actor('below-roof',56,90),roof={id:'roof',x:40,y:84,w:60,h:1,collision:'solid',material:'brick'},before=copy(e);
 c.step({tick:1,enemies:[e],geometry:[roof]});assert(!c.held(e));assert.deepEqual(e,before);
});

test('closed brick cage blocks held cargo at its previous safe position while P removal permits real transport',()=>{
 const wall={id:'cage-wall',x:88,y:48,w:4,h:40,collision:'solid',material:'brick'},r=room({speed:4,catchRadius:0}),events=[],c=createRailClaws(r,{emit:(type,event)=>events.push(event)}),e=actor('caged-goomba',60,60,{keys:1}),p=player();
 for(let tick=1;tick<=4;tick++){c.step({tick,player:p,enemies:[e],geometry:[wall]});assert(c.held(e));assert(e.x+e.w<=wall.x);}
 const safe=copy(e);c.step({tick:5,player:p,enemies:[e],geometry:[wall]});assert(!c.held(e));assert.equal(e.x,safe.x);assert.equal(e.y,safe.y);assert.equal(e.vx,4);assert.equal(e.vy,0);assert.equal(e.dead,false);assert.equal(e.hp,2);assert.equal(e.keys,1);assert.equal(p.keys,0);assert.equal(clawView(c).grip.x,84,'claw itself continues on its rail');
 const released=events.find(q=>q.event==='release');assert.equal(released.reason,'terrain-blocked');assert.equal(released.blockerId,'cage-wall');assert.deepEqual(released.position,{x:safe.x,y:safe.y});assert.deepEqual(released.velocity,{x:4,y:0});
 c.step({tick:6,player:p,enemies:[e],geometry:[]});assert(!c.held(e),'P removal does not cancel the source cooldown');assert.equal(e.x,safe.x);
 const open=createRailClaws(r),transport=actor('freed-goomba',60,60,{keys:1});
 for(let tick=1;tick<=12;tick++){open.step({tick,player:p,enemies:[transport],geometry:tick<=4?[wall]:[]});assert(open.held(transport));}
 assert(transport.x>wall.x+wall.w,'removing the real P-converted cage collider permits transport');assert.equal(transport.dead,false);assert.equal(transport.keys,1);assert.equal(p.keys,0);
});

test('fast held cargo and Mario cannot tunnel through a thin wall even when both endpoint bodies are clear',()=>{
 const r=room({speed:40,catchRadius:0},{start:[24,20],segments:[{kind:'line',to:[224,20]}]}),wall={id:'thin-wall',x:84,y:40,w:.125,h:60,collision:'solid',material:'stone'};
 for(const kind of ['enemy','player']){
  const c=createRailClaws(r),e=kind==='enemy'?actor('fast',56,60):player(60,60),inputs=kind==='enemy'?{enemies:[e]}:{player:e};
  c.step({tick:1,...inputs,geometry:[wall]});assert(c.held(e));const old=copy(e);assert(old.x+old.w<wall.x);c.step({tick:2,...inputs,geometry:[wall]});
  assert(clawView(c).grip.x-e.w/2>wall.x+wall.w,'attempted final pose has fully crossed the wall');assert(!c.held(e));assert.equal(e.x,old.x);assert.equal(e.y,old.y);assert.equal(e.vx,40);assert.equal(e.vy,0);assert.equal(e.dead??false,false);assert.equal(c.playerHeld(),false);
 }
});

test('ordinary one-way platform blocks held descent from above, permits upward crossing and ignores horizontal underside motion',()=>{
 const platform={id:'one-way',x:40,y:56,w:48,h:2,collision:'oneway',material:'platform'},down=createRailClaws(room({speed:4,ropeLength:20,catchRadius:0},{start:[64,10],segments:[{kind:'line',to:[64,110]}]})),e=actor('descending',56,32);
 down.step({tick:1,enemies:[e],geometry:[platform]});assert(down.held(e));down.step({tick:2,enemies:[e],geometry:[platform]});assert(down.held(e));const safe=copy(e);down.step({tick:3,enemies:[e],geometry:[platform]});assert(!down.held(e));assert.equal(e.y,safe.y);assert(e.y+e.h<platform.y);assert.equal(e.vy,4);
 const up=createRailClaws(room({speed:20,position:60,direction:-1,ropeLength:20,catchRadius:0},{start:[64,10],segments:[{kind:'line',to:[64,110]}]})),rising=actor('rising',56,68);
 up.step({tick:1,enemies:[rising],geometry:[platform]});assert(up.held(rising));assert(rising.y>platform.y+platform.h);up.step({tick:2,enemies:[rising],geometry:[platform]});assert(up.held(rising));assert(rising.y<platform.y&&rising.y+rising.h>platform.y);up.step({tick:3,enemies:[rising],geometry:[platform]});assert(up.held(rising));assert(rising.y+rising.h<platform.y);
 const across=createRailClaws(room({speed:8,ropeLength:42,catchRadius:0})),under=actor('underneath',64,60);across.step({tick:1,enemies:[under],geometry:[platform]});assert(across.held(under));across.step({tick:2,enemies:[under],geometry:[platform]});assert(across.held(under));
});

const drivenRoom=(rule={},claw={})=>room({speed:0,swingDegrees:0,playerSwing:rule,...claw});
function drivenPlayer(rule={},claw={}){const c=createRailClaws(drivenRoom(rule,claw)),p=player(60,60);c.step({tick:1,player:p,input:{x:1}});assert(c.playerHeld());return {c,p};}
function drive(s,x,from=2,to=21){for(let tick=from;tick<=to;tick++)s.c.step({tick,player:s.p,input:{x}});return clawView(s.c);}

test('playerSwing is strictly opt-in with validated authored local parameters and no added legacy default fields',()=>{
 assert(!Object.hasOwn(RAIL_CLAW_DEFAULTS,'playerSwing'));const old=createRailClaws(room());assert(!Object.hasOwn(clawView(old),'playerSwing'));assert(!Object.hasOwn(clawView(old),'playerSwingState'));
 const c=createRailClaws(drivenRoom());assert.deepEqual(clawView(c).playerSwing,{});assert.equal(clawView(c).playerSwingState.active,false);assert.equal(clawView(c).playerSwingState.angularVelocityDegreesPerFrame,0);assert.equal(clawView(c).playerSwingState.approximation,true);
 assert.deepEqual(Object.keys(RAIL_PLAYER_SWING_DEFAULTS),['driveDegreesPerFrameSquared','restoringDegreesPerFrameSquared','damping','maxAngleDegrees','maxAngularVelocityDegreesPerFrame']);
 const invalid=[null,[],{unknown:true},{driveDegreesPerFrameSquared:-1},{driveDegreesPerFrameSquared:Infinity},{restoringDegreesPerFrameSquared:0},{damping:1.1},{damping:NaN},{maxAngleDegrees:90},{maxAngularVelocityDegreesPerFrame:0}];
 for(const rule of invalid){const r=drivenRoom(rule),before=copy(r);assert.throws(()=>validateRailClaws(r),/player swing/i);assert.deepEqual(r,before);}
 assert.throws(()=>validateRailClaws(drivenRoom({maxAngleDegrees:10},{swingDegrees:20})),/passive motion/);
 assert.throws(()=>validateRailClaws(drivenRoom({maxAngularVelocityDegreesPerFrame:.1},{swingDegrees:20,swingPeriodFrames:40})),/passive motion/);
});

test('real held Mario can pump either direction; letting go preserves inertia and restoring/damping return toward center',()=>{
 const right=drivenPlayer(),left=drivenPlayer();close(clawView(right.c).angleRadians,0);close(clawView(left.c).angleRadians,0);
 const a=drive(right,1),b=drive(left,-1);assert(a.angleRadians>0&&b.angleRadians<0);close(a.angleRadians,-b.angleRadians);assert(a.grip.x>a.anchor.x&&b.grip.x<b.anchor.x);assert(a.playerSwingState.angularVelocityDegreesPerFrame>0);assert(b.playerSwingState.angularVelocityDegreesPerFrame<0);
 const startAngle=a.angleRadians;right.c.step({tick:22,player:right.p,input:{x:0}});const releasedInput=clawView(right.c);assert(releasedInput.angleRadians>startAngle,'zero input retains positive angular momentum');assert(releasedInput.playerSwingState.angularVelocityDegreesPerFrame>0);
 const restoring=RAIL_PLAYER_SWING_DEFAULTS.restoringDegreesPerFrameSquared*Math.PI/180,energy=q=>.5*(q.playerSwingState.angularVelocityDegreesPerFrame*Math.PI/180)**2+restoring*(1-Math.cos(q.angleRadians)),initialEnergy=energy(releasedInput);let crossedCenter=false;
 for(let tick=23;tick<=422;tick++){right.c.step({tick,player:right.p,input:{x:0}});crossedCenter||=clawView(right.c).angleRadians<0;}
 assert(crossedCenter,'restoring torque returns the displaced pendulum through center');assert(energy(clawView(right.c))<initialEnergy*.1,'damping dissipates angular energy without erasing inertia immediately');assert(right.c.playerHeld());
});

test('opposite input physically brakes angular velocity before reversing it',()=>{
 const braking=drivenPlayer(),coasting=drivenPlayer();drive(braking,1);drive(coasting,1);const before=clawView(braking.c);
 braking.c.step({tick:22,player:braking.p,input:{x:-1}});coasting.c.step({tick:22,player:coasting.p,input:{x:0}});const slowed=clawView(braking.c);
 assert(slowed.playerSwingState.angularVelocityDegreesPerFrame>0,'reverse pressure does not instantaneously reverse motion');assert(slowed.playerSwingState.angularVelocityDegreesPerFrame<clawView(coasting.c).playerSwingState.angularVelocityDegreesPerFrame);assert(slowed.angleRadians>before.angleRadians);
 drive(braking,-1,23,36);assert(clawView(braking.c).playerSwingState.angularVelocityDegreesPerFrame<0);assert(braking.c.playerHeld());
});

test('authored driven angle/velocity limits are honored and passive capture enters continuously',()=>{
 const s=drivenPlayer({driveDegreesPerFrameSquared:2,restoringDegreesPerFrameSquared:.001,damping:1,maxAngleDegrees:12,maxAngularVelocityDegreesPerFrame:1});
 for(let tick=2;tick<=30;tick++){s.c.step({tick,player:s.p,input:{x:1}});const q=clawView(s.c);assert(Math.abs(q.playerSwingState.angleDegrees)<=12+1e-9);assert(Math.abs(q.playerSwingState.angularVelocityDegreesPerFrame)<=1+1e-9);}
 close(clawView(s.c).playerSwingState.angleDegrees,12);close(clawView(s.c).playerSwingState.angularVelocityDegreesPerFrame,0);s.c.step({tick:31,player:s.p,input:{x:-1}});assert(clawView(s.c).playerSwingState.angleDegrees<12);
 const r=drivenRoom({}, {speed:.75,swingDegrees:18,swingPhaseDegrees:30}),configured=createRailClaws(r),legacyRoom=copy(r);delete legacyRoom.contraptions.claws[0].playerSwing;const passive=createRailClaws(legacyRoom),a=player(60,60),b=copy(a),previous=clawView(passive).angleRadians;
 configured.step({tick:1,player:a,input:{x:1}});passive.step({tick:1,player:b});assert(configured.playerHeld());assert.deepEqual(a,b);close(clawView(configured).angleRadians,clawView(passive).angleRadians);close(clawView(configured).playerSwingState.angularVelocityDegreesPerFrame,(clawView(passive).angleRadians-previous)*180/Math.PI);
});

test('before first player capture, input cannot drive an empty claw or NPC and configured transport stays exactly passive',()=>{
 const configured=createRailClaws(drivenRoom({}, {speed:1,swingDegrees:18})),legacy=createRailClaws(room({speed:1,swingDegrees:18})),a=actor('passive',60,60),b=copy(a);
 for(let tick=1;tick<=40;tick++){
  configured.step({tick,enemies:[a],input:{x:tick%2?1:-1}});legacy.step({tick,enemies:[b],input:{x:0}});assert.deepEqual(a,b);
  const q=clawView(configured);assert.equal(q.playerSwingState.active,false);assert.equal(q.playerSwingState.angularVelocityDegreesPerFrame,0);delete q.playerSwing;delete q.playerSwingState;assert.deepEqual(q,clawView(legacy));
 }
 const empty=createRailClaws(drivenRoom());for(let tick=1;tick<=20;tick++)empty.step({tick,input:{x:1}});close(clawView(empty).angleRadians,0);assert.equal(clawView(empty).playerSwingState.angularVelocityDegreesPerFrame,0);
});

test('Jump inherits real grip momentum and the empty claw continues without angle or position teleport',()=>{
 const s=drivenPlayer({}, {speed:.75,playerJumpSpeed:5});drive(s,1,2,20);const previous=clawView(s.c).grip;s.c.step({tick:21,player:s.p,input:{x:1}});const q=clawView(s.c);close(s.p.vx,q.grip.x-previous.x);close(s.p.vy,q.grip.y-previous.y);assert(s.p.vx>.75,'release momentum includes the driven tangent and rail motion');
 assert(s.c.releasePlayer({jump:true,jumpPressed:true}));close(s.p.vx,q.vx);close(s.p.vy,q.vy-5);assert(!s.c.playerHeld());assert.deepEqual(clawView(s.c).grip,q.grip);assert.equal(clawView(s.c).angleRadians,q.angleRadians);assert.deepEqual(clawView(s.c).playerSwingState,q.playerSwingState,'release does not erase the physical state');
 s.c.step({tick:22,player:s.p,input:{x:-1}});const next=clawView(s.c),angleDelta=next.angleRadians-q.angleRadians,gripDelta=distance([next.grip.x,next.grip.y],[q.grip.x,q.grip.y]);
 assert(angleDelta>0,'empty claw continues positive inertia despite unheld left input');assert(angleDelta<=RAIL_PLAYER_SWING_DEFAULTS.maxAngularVelocityDegreesPerFrame*Math.PI/180+1e-9);assert(gripDelta<=.75+q.ropeLength*RAIL_PLAYER_SWING_DEFAULTS.maxAngularVelocityDegreesPerFrame*Math.PI/180+1e-9,'next-frame movement is physically bounded, never a return-to-sine jump');close(next.vx,next.grip.x-q.grip.x);close(next.vy,next.grip.y-q.grip.y);assert.equal(next.playerSwingState.active,true);assert(next.playerSwingState.angularVelocityDegreesPerFrame>0);
});

test('NPC recapture uses the continuous physical grip and coasts under zero drive with real inherited velocity',()=>{
 const s=drivenPlayer({}, {speed:.75}),coasting=drivenPlayer({}, {speed:.75});drive(s,1);drive(coasting,1);s.c.releasePlayer({jumpPressed:true});coasting.c.releasePlayer({jumpPressed:true});coasting.c.step({tick:22,input:{x:0}});const next=clawView(coasting.c),npc=actor('after-player',next.grip.x-8,next.grip.y);
 s.c.step({tick:22,player:s.p,enemies:[npc],input:{x:-1}});assert(s.c.held(npc));assert.equal(clawView(s.c).heldKind,'enemy');assert.deepEqual(clawView(s.c).grip,next.grip);assert.deepEqual(clawView(s.c).playerSwingState,next.playerSwingState);close(npc.vx,next.vx);close(npc.vy,next.vy);assert(npc.vx>.75,'NPC receives real ongoing angular momentum, not a passive reset substitute');
 Object.assign(s.p,{x:230,y:180});for(let tick=23;tick<=32;tick++){s.c.step({tick,player:s.p,enemies:[npc],input:{x:-1}});coasting.c.step({tick,input:{x:1}});const q=clawView(s.c),control=clawView(coasting.c);assert(s.c.held(npc));assert.deepEqual(q.grip,control.grip);assert.deepEqual(q.playerSwingState,control.playerSwingState);close(npc.x,q.grip.x-npc.w/2);close(npc.y,q.grip.y);}
});

test('post-player NPC recapture cannot sweep its body through a thin wall even when both endpoints are clear',()=>{
 const s=drivenPlayer({}, {catchRadius:32}),coasting=drivenPlayer({}, {catchRadius:32});drive(s,1);drive(coasting,1);s.c.releasePlayer({jumpPressed:true});coasting.c.releasePlayer({jumpPressed:true});coasting.c.step({tick:22});const q=clawView(coasting.c),npc=actor('across-thin-wall',q.grip.x+12,q.grip.y),before=copy(npc),wall={id:'recapture-wall',x:q.grip.x+10,y:q.grip.y-8,w:.25,h:48,collision:'solid'};
 assert(npc.x>wall.x+wall.w);assert(q.grip.x+npc.w/2<wall.x,'desired constrained body is fully on the other side');s.c.step({tick:22,player:s.p,enemies:[npc],geometry:[wall],input:{x:1}});assert(!s.c.held(npc));assert.deepEqual(npc,before);assert.deepEqual(clawView(s.c).grip,q.grip,'empty claw itself keeps its continuous trajectory');assert.deepEqual(clawView(s.c).playerSwingState,q.playerSwingState);assert.equal(s.p.keys,0);
});

test('later real player capture preserves the established physical angle and angular momentum',()=>{
 const s=drivenPlayer(),coasting=drivenPlayer();drive(s,1);drive(coasting,1);s.c.releasePlayer({jumpPressed:true});coasting.c.releasePlayer({jumpPressed:true});s.c.step({tick:22});coasting.c.step({tick:22});coasting.c.step({tick:23});const q=clawView(coasting.c),nextPlayer={...player(q.grip.x-5,q.grip.y),id:'player-again'};
 s.c.step({tick:23,player:nextPlayer,input:{x:-1}});assert(s.c.playerHeld());assert.equal(clawView(s.c).heldId,'player-again');assert.deepEqual(clawView(s.c).grip,q.grip);assert.deepEqual(clawView(s.c).playerSwingState,q.playerSwingState);assert(clawView(s.c).playerSwingState.angularVelocityDegreesPerFrame>0,'a later capture cannot reset ongoing angular momentum');
});

test('driven held Mario still collides with real terrain and releases at the previous safe body pose',()=>{
 const events=[],r=drivenRoom(),c=createRailClaws(r,{emit:(type,event)=>events.push(event)}),p=player(60,60),wall={id:'driven-wall',x:75,y:20,w:.25,h:100,collision:'solid'};c.step({tick:1,player:p,geometry:[wall],input:{x:1}});assert(c.playerHeld());let prior=copy(p),blocked=false;
 for(let tick=2;tick<100;tick++){
  c.step({tick,player:p,geometry:[wall],input:{x:1}});if(!c.playerHeld()){blocked=true;assert.equal(p.x,prior.x);assert.equal(p.y,prior.y);assert(p.x+p.w<=wall.x);assert(clawView(c).playerSwingState.angularVelocityDegreesPerFrame>0);assert.equal(clawView(c).playerSwingState.active,true);break;}prior=copy(p);
 }
 assert(blocked);const event=events.find(q=>q.event==='release');assert.equal(event.reason,'terrain-blocked');assert.equal(event.blockerId,'driven-wall');assert(event.velocity.x>0);assert.equal(p.keys,0);assert.equal(p.dead??false,false);
});

test('physical angular state is idempotent, coasts after player disappearance/death, and only reset clears it',()=>{
 for(const disappearance of ['missing','dead']){const s=drivenPlayer(),neutral=drivenPlayer();drive(s,1);drive(neutral,1);assert(clawView(s.c).playerSwingState.angularVelocityDegreesPerFrame>0);if(disappearance==='dead')s.p.dead=true;const old=copy(s.p);s.c.step({tick:22,player:disappearance==='missing'?undefined:s.p,input:{x:1}});neutral.c.step({tick:22,input:{x:0}});assert(!s.c.playerHeld());assert.equal(clawView(s.c).playerSwingState.active,true);assert(clawView(s.c).playerSwingState.angularVelocityDegreesPerFrame>0);assert.deepEqual(clawView(s.c).playerSwingState,clawView(neutral.c).playerSwingState);assert.deepEqual(clawView(s.c).grip,clawView(neutral.c).grip);assert.deepEqual(s.p,old);}
 const s=drivenPlayer(),initial=createRailClaws(drivenRoom()).view();drive(s,1);const view=copy(s.c.view()),p=copy(s.p);assert.equal(s.c.step({tick:21,player:s.p,input:{x:-1}}),false);assert.deepEqual(s.c.view(),view);assert.deepEqual(s.p,p);s.c.reset();assert.deepEqual(s.c.view(),initial);const fresh=player(60,60);s.c.step({tick:1,player:fresh});const freshState=clawView(s.c);close(freshState.angleRadians,0);close(freshState.playerSwingState.angularVelocityDegreesPerFrame,0);
});

function legacyTrace(factory){
 const events=[],r=room({speed:.75,swingDegrees:18,swingPeriodFrames:160,swingPhaseDegrees:15}),c=factory(r,{emit:(type,event)=>events.push({type,...event})}),trace=[],wall={id:'legacy-wall',x:120,y:48,w:2,h:100,collision:'solid',material:'brick'};let p=player(60,60),e=actor('legacy-goomba',80,58);
 for(let tick=1;tick<=80;tick++){
  if(tick===35){const grip=clawView(c).grip;Object.assign(e,{x:grip.x-e.w/2,y:grip.y});}
  if(tick===55)e.dead=true;
  if(tick===60){c.reset();p=player(60,60);e=actor('legacy-goomba',80,58);}
  c.releasePlayer({jumpPressed:tick===20,jump:tick===20});c.step({tick,player:p,enemies:[e],geometry:[wall],input:{x:tick%7<3?-1:1}});
  trace.push({view:c.view(),p:copy(p),e:copy(e),events:copy(events)});
  if(tick===20)Object.assign(p,{x:230,y:180});
 }
 return trace;
}
test('undeclared playerSwing retains the exact pre-change actor, event and view snapshot sequence',()=>{
 const digest=createHash('sha256').update(JSON.stringify(legacyTrace(createRailClaws))).digest('hex');
 assert.equal(digest,'e4762a9ab881fe839674c855b07779b2d2c6430b58225deb145349955bd7f2ee','baseline captured from the module before adding playerSwing');
});
