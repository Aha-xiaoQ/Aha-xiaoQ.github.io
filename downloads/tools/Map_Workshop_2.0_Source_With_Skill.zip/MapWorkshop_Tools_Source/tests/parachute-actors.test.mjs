import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createParachuteActors,validateParachuteActors} from '../atlas/editor-parachute-actors.mjs';

// Neutral author tuning exercises the controller; these are not original
// game constants. Source-study fall fits are supplied by a course author.
const tuning=(id,variant='goomba',activation='frame-in-view')=>({id,variant,fallSpeed:.4,oscillation:{amplitude:16,periodFrames:120,phaseFrames:0},activation:{kind:activation}});
function room(){return {roomId:'neutral-parachutes',map:{width:512,height:288,geometry:[{id:'floor',x:0,y:240,w:512,h:48,collision:'solid'}],objects:[{id:'enemy',kind:'walker',x:100,y:40,w:16,h:16},{id:'item',kind:'walker',x:300,y:40,w:16,h:16},{id:'plain-enemy',kind:'walker',x:420,y:40,w:16,h:16}]},enemySkins:{enemy:'enemy-goomba','plain-enemy':'goomba'},smm2Mechanics:{version:1,placedItems:[{id:'item',kind:'mushroom',gravity:.22,maxFallSpeed:4.25,points:1000}],parachuteActors:{version:1,actors:[tuning('enemy'),tuning('item','super-mushroom')]}}};}
function fixture(r=room()){
 const controller=createParachuteActors(r),enemy=controller.decorateActor({...r.map.objects[0],type:r.enemySkins.enemy,vx:-.5,vy:0,hp:2,grounded:false,support:null,dead:false}),item=controller.decorateActor({...r.map.objects[1],kind:'mushroom',vx:.8,vy:0,grounded:false,support:null,dead:false,actualitem:'mushroom',smm2PlacedItem:{version:1,id:'item',phase:'live'}});
 return {r,c:controller,enemy,item};
}
// The host consumes the override once. A controller has no displacement or
// collision pass of its own; this tiny port exposes accidental double motion.
function integrate(c,actor,tick,active=true){
 const frame=c.preStep(actor,{tick,active});
 if(frame.advance){actor.x+=actor.vx;actor.vy=Math.min(frame.motion?.maxFallSpeed??5,actor.vy+(frame.motion?.gravity??.3));actor.y+=actor.vy;}
 return frame;
}

test('opt-out and strict version-1 leaf are immutable and sibling-independent',()=>{
 const r=room(),original=structuredClone(r);assert.doesNotThrow(()=>validateParachuteActors(r));assert.deepEqual(r,original);
 delete r.smm2Mechanics.parachuteActors;assert.doesNotThrow(()=>validateParachuteActors(r));assert.equal(createParachuteActors(r),null);
 const sibling=room();sibling.smm2Mechanics.futureSibling={version:44};assert.doesNotThrow(()=>validateParachuteActors(sibling));
 const c=createParachuteActors(original);original.smm2Mechanics.parachuteActors.actors[0].fallSpeed=60;assert.equal(c.view().actors[0].tuning.fallSpeed,.4);
});

test('every author fall, oscillator, phase and activation field is required',()=>{
 for(const path of [
  ['version'],['actors'],...['id','variant','fallSpeed','oscillation','activation'].map(k=>['actors',0,k]),
  ...['amplitude','periodFrames','phaseFrames'].map(k=>['actors',0,'oscillation',k]),['actors',0,'activation','kind'],
 ]){
  const r=room();let leaf=r.smm2Mechanics.parachuteActors;for(const key of path.slice(0,-1))leaf=leaf[key];delete leaf[path.at(-1)];assert.throws(()=>validateParachuteActors(r),path.join('.'));
 }
});

test('unknown fields, unsafe IDs, nonfinite tuning and unsupported variants reject',()=>{
 const mutations=[
  s=>s.version=2,s=>s.script='spawn',s=>s.actors.push(tuning('enemy')),s=>s.actors[0].id='constructor',s=>s.actors[0].variant='giant-goomba',s=>s.actors[0].variant='star',
  s=>s.actors[0].fallSpeed=NaN,s=>s.actors[0].fallSpeed=0,s=>s.actors[0].fallSpeed=65,s=>s.actors[0].armor=true,
  s=>s.actors[0].oscillation.amplitude=-1,s=>s.actors[0].oscillation.amplitude=257,s=>s.actors[0].oscillation.periodFrames=3,s=>s.actors[0].oscillation.periodFrames=120.5,
  s=>s.actors[0].oscillation.phaseFrames=120,s=>s.actors[0].oscillation.phaseFrames=-.1,s=>s.actors[0].oscillation.phaseFrames=Infinity,s=>s.actors[0].oscillation.algorithm='original',
  s=>s.actors[0].activation.kind='video-time',s=>s.actors[0].activation.atSeconds=1550,
 ];
 for(const mutate of mutations){const r=room();mutate(r.smm2Mechanics.parachuteActors);assert.throws(()=>validateParachuteActors(r));}
 const unsafe=room();unsafe.smm2Mechanics.parachuteActors.actors[0]=JSON.parse('{"__proto__":{},"id":"enemy"}');assert.throws(()=>validateParachuteActors(unsafe));
 const long=room();long.smm2Mechanics.parachuteActors.actors=Array.from({length:257},(_,i)=>tuning('actor-'+i));assert.throws(()=>validateParachuteActors(long),/list/);
});

test('each parachute refers to exactly one ordinary bounded native body',()=>{
 for(const mutate of [
  r=>r.map.width=Infinity,r=>r.map.height=5000,r=>r.map.objects[0].kind='coin',r=>r.map.objects[0].w=32,r=>r.map.objects[0].h=32,
  r=>r.map.objects[0].x=-.1,r=>r.map.objects[0].y=280,r=>r.map.objects.shift(),r=>r.map.objects.push({...r.map.objects[0]}),
  r=>r.map.geometry.push({id:'enemy',x:0,y:0,w:16,h:16,collision:'solid'}),r=>r.markers=[{id:'enemy',kind:'enemy-goomba'}],
  r=>r.enemySkins.enemy='spiny',r=>r.marioModules={enemyVariants:{enemy:{type:'goomba'}}},
  r=>r.smm2Mechanics.portableStones={stones:[{id:'enemy'}]},r=>r.smm2Mechanics.localUpdrafts={twisters:[{id:'enemy'}]},r=>r.smm2Mechanics.thwomps=[{id:'enemy'}],
 ]){const r=room();mutate(r);assert.throws(()=>validateParachuteActors(r));}
 for(const skin of ['goomba','enemy-goomba','marker-goomba']){const r=room();r.enemySkins.enemy=skin;assert.doesNotThrow(()=>validateParachuteActors(r));}
});

test('Super Mushroom extends its actual placed item ID instead of a second pickup actor',()=>{
 for(const mutate of [r=>delete r.smm2Mechanics.placedItems,r=>r.smm2Mechanics.placedItems[0].kind='life',r=>r.smm2Mechanics.placedItems.push({...r.smm2Mechanics.placedItems[0]}),r=>r.smm2Mechanics.placedItems[0].rail={trackId:'rail'},r=>r.smm2Mechanics.placedItems.push({id:'enemy',kind:'mushroom'})]){
  const r=room();mutate(r);assert.throws(()=>validateParachuteActors(r));
 }
 const f=fixture();assert.equal(f.item.kind,'mushroom');assert.equal(f.item.actualitem,'mushroom');assert.equal(f.item.smm2PlacedItem.id,'item');
 integrate(f.c,f.item,1);integrate(f.c,f.item,2);assert.equal(f.item.kind,'mushroom');assert.equal(f.item.smm2PlacedItem.phase,'live');assert.equal(f.r.smm2Mechanics.placedItems[0].points,1000);
 assert.throws(()=>f.c.decorateActor({...f.r.map.objects[1],vx:0,vy:0}),/actual decorated placed item/);
});

test('decorateActor and view are pure and do not register, activate, or advance actors',()=>{
 const r=room(),before=structuredClone(r),c=createParachuteActors(r),input={...r.map.objects[0],vx:-.5,vy:0,hp:2,type:'walker'};
 const inputBefore=structuredClone(input),stateBefore=c.view();
 const a=c.decorateActor(input),b=c.decorateActor(input);assert.notEqual(a,input);assert.notEqual(a,b);assert.deepEqual(a,b);assert.equal(a.type,'goomba');assert.equal(a.hp,2);assert.deepEqual(input,inputBefore);assert.deepEqual(c.view(),stateBefore);assert.deepEqual(r,before);
 for(let i=0;i<20;i++){c.decorateActor(a);c.view();}assert.deepEqual(c.view(),stateBefore);
 const projection=c.view();projection.actors[0].body.x=999;projection.actors[0].state.active=true;projection.actors[0].tuning.oscillation.phaseFrames=44;assert.deepEqual(c.view(),stateBefore);
 // Decoration did not bind either a or b, so b may be the single physical one.
 c.preStep(b,{tick:1,active:true});assert.throws(()=>c.preStep(a,{tick:2,active:true}),/one actor instance/);
});

test('one actual live actor per stable ID keeps native metadata and rejects aliases',()=>{
 const f=fixture();assert.equal(f.c.ownsActor('enemy'),true);assert.equal(f.c.ownsActor(f.item),true);assert.equal(f.c.ownsActor('plain-enemy'),false);
 const ordinary={id:'plain-enemy',kind:'walker'};assert.equal(f.c.decorateActor(ordinary),ordinary);assert.equal(f.c.preStep(ordinary).handled,false);
 f.c.preStep(f.enemy,{tick:1,active:true});assert.throws(()=>f.c.preStep({...f.enemy},{tick:2,active:true}),/one actor instance/);assert.throws(()=>f.c.landed({...f.enemy},{support:'floor'}),/one actor instance/);
 assert.equal(f.enemy.hp,2);assert.equal(f.enemy.type,'enemy-goomba');assert.equal(f.r.map.objects.length,3);assert.equal(f.c.view().actors.length,2);
});

test('frame-in-view preserves the authored first visible pose and never catches up hidden time',()=>{
 const f=fixture(),source={x:f.enemy.x,y:f.enemy.y};
 for(let tick=1;tick<100;tick++){const frame=integrate(f.c,f.enemy,tick,false);assert.equal(frame.waiting,true);assert.equal(frame.advance,false);assert.equal(frame.active,false);}
 assert.deepEqual({x:f.enemy.x,y:f.enemy.y},source);assert.equal(f.c.view().actors[0].state.elapsedFrames,0);
 const first=integrate(f.c,f.enemy,100,true);assert.equal(first.activationHold,true);assert.equal(first.advance,false);assert.equal(first.active,true);assert.deepEqual({x:f.enemy.x,y:f.enemy.y},source);
 const second=integrate(f.c,f.enemy,101,false);assert.equal(second.advance,true);assert.equal(second.active,true);assert.equal(f.enemy.y,source.y+.4);assert.ok(f.enemy.x>source.x);assert.equal(f.enemy.parachuteActor.activationTick,100);
});

test('room-entry activation is explicit and still holds the initial authored pose',()=>{
 const r=room();r.smm2Mechanics.parachuteActors.actors[0].activation.kind='room-entry';const f=fixture(r),x=f.enemy.x,y=f.enemy.y;
 assert.equal(integrate(f.c,f.enemy,4,false).activationHold,true);assert.equal(f.enemy.x,x);assert.equal(f.enemy.y,y);
 assert.equal(integrate(f.c,f.enemy,5,false).advance,true);assert.equal(f.enemy.y,y+.4);
});

test('oscillation reverses deterministically, stays anchored, and fall is capped before host integration',()=>{
 const a=fixture(),b=fixture(),start={x:a.enemy.x,y:a.enemy.y};integrate(a.c,a.enemy,1);integrate(b.c,b.enemy,1);
 let negative=false,positive=false;
 for(let tick=2;tick<=121;tick++){
  a.enemy.vy=50;b.enemy.vy=50;
  const af=integrate(a.c,a.enemy,tick),bf=integrate(b.c,b.enemy,tick);assert.deepEqual(af,bf);assert.deepEqual(a.enemy,b.enemy);assert.equal(a.enemy.vy,.4);assert.equal(af.motion.gravity,0);assert.equal(af.motion.maxFallSpeed,.4);
  positive ||= a.enemy.vx>0;negative ||= a.enemy.vx<0;assert.ok(Math.abs(a.enemy.x-start.x)<=16+1e-9);
 }
 assert.ok(negative&&positive);assert.ok(Math.abs(a.enemy.x-start.x)<1e-9);assert.ok(Math.abs(a.enemy.y-start.y-48)<1e-9);
});

test('phase is authored and preStep changes velocities without applying displacement',()=>{
 const r=room();r.smm2Mechanics.parachuteActors.actors[0].oscillation.phaseFrames=30.5;const f=fixture(r),before={x:f.enemy.x,y:f.enemy.y};
 f.c.preStep(f.enemy,{tick:1,active:true});const prepared=f.c.preStep(f.enemy,{tick:2,active:true});
 assert.equal(prepared.advance,true);assert.ok(f.enemy.vx<0);assert.equal(f.enemy.vy,.4);assert.deepEqual({x:f.enemy.x,y:f.enemy.y},before);
 assert.equal(f.enemy.parachuteActor.elapsedFrames,1);const snapshot=structuredClone(f.enemy);
 for(const tick of [2,1,0]){assert.equal(f.c.preStep(f.enemy,{tick,active:true}).advance,false);assert.deepEqual(f.enemy,snapshot);}
 // A skipped host tick does not fabricate unobserved catch-up displacement.
 f.c.preStep(f.enemy,{tick:900,active:true});assert.equal(f.enemy.parachuteActor.elapsedFrames,2);assert.deepEqual({x:f.enemy.x,y:f.enemy.y},before);
});

test('only real live grounded support closes once and returns to native ordinary motion',()=>{
 const f=fixture();f.c.preStep(f.enemy,{tick:1,active:true});f.c.preStep(f.enemy,{tick:2,active:true});
 assert.equal(f.c.landed(f.enemy,{support:'floor'}).changed,false);
 Object.assign(f.enemy,{grounded:true,support:'elsewhere',vy:0});assert.equal(f.c.landed(f.enemy,{support:'floor'}).changed,false);
 Object.assign(f.enemy,{support:'floor',vy:-1});assert.equal(f.c.landed(f.enemy,{support:'floor'}).changed,false);
 Object.assign(f.enemy,{vy:0});assert.deepEqual(f.c.landed(f.enemy,{support:'floor'}),{handled:true,changed:true,open:false});assert.equal(f.enemy.vx,-.5);assert.equal(f.enemy.hp,2);assert.equal(f.enemy.grounded,true);assert.equal(f.enemy.support,'floor');
 f.enemy.vx=.5;assert.equal(f.c.landed(f.enemy,{support:'floor'}).changed,false);assert.equal(f.enemy.vx,.5);
 const frame=f.c.preStep(f.enemy,{tick:3,active:false});assert.equal(frame.advance,true);assert.equal(frame.open,false);assert.equal(frame.motion,null);assert.equal(f.enemy.vx,.5);assert.equal(f.enemy.vy,0);
 const snapshot=structuredClone(f.enemy);assert.equal(f.c.preStep(f.enemy,{tick:3,active:true}).advance,false);assert.deepEqual(f.enemy,snapshot);
 // Losing support or a later genuine Note launch does not reopen the canopy.
 Object.assign(f.enemy,{grounded:false,support:null,vy:-4});f.c.preStep(f.enemy,{tick:4,active:true});assert.equal(f.enemy.parachuteActor.open,false);assert.equal(f.enemy.vy,-4);
});

test('mushroom landing preserves the same collectible instance, and taken/dead actors never move',()=>{
 const f=fixture();integrate(f.c,f.item,1);integrate(f.c,f.item,2);Object.assign(f.item,{grounded:true,support:'floor',vy:0});
 assert.equal(f.c.landed(f.item,{support:'floor'}).changed,true);assert.equal(f.item.vx,.8);assert.equal(f.item.actualitem,'mushroom');assert.equal(f.item.kind,'mushroom');assert.equal(f.item.smm2PlacedItem.phase,'live');
 f.item.dead=true;const before=structuredClone(f.item);assert.equal(integrate(f.c,f.item,3).advance,false);assert.deepEqual(f.item,before);assert.equal(f.c.view().actors[1].dead,true);
 const g=fixture();g.enemy.taken=true;assert.equal(integrate(g.c,g.enemy,1).advance,false);assert.equal(g.enemy.parachuteActor.active,false);
});

test('invalid host frames and live shapes fail before binding or changing a pose',()=>{
 const f=fixture(),before=structuredClone(f.enemy);
 for(const args of [{tick:-1,active:true},{tick:.5,active:true},{tick:1},{tick:1,active:1}])assert.throws(()=>f.c.preStep(f.enemy,args),/tick and explicit active boolean/);
 assert.deepEqual(f.enemy,before);
 for(const mutate of [a=>a.w=32,a=>a.vx=NaN,a=>a.y=Infinity,a=>a.type='koopa']){const q=fixture();mutate(q.enemy);assert.throws(()=>q.c.preStep(q.enemy,{tick:1,active:true}));}
 assert.throws(()=>f.c.landed(f.enemy,{support:null}),/actual stable support ID/);
});
