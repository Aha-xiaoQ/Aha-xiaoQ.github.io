import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {History,parseProject,moveSelection,deleteSelection,clone,uid,linked} from '../atlas/editor-model.mjs';
import {addChainChompGuard,updateChainChompGuard,cloneChainChompGuard,removeChainChompGuard,captureChainChompGuardBindings,appendCopiedChainChompGuardBindings,mountChainChompGuardTools} from '../atlas/editor-chain-chomp-guard-tools.mjs';
import {requiredCollectionCapabilities} from '../atlas/editor-collection.mjs';
import {captureSmm2LightingBindings,appendCopiedSmm2LightingBindings,pruneSmm2LightingReferences} from '../atlas/editor-smm2-lighting-tools.mjs';
import {captureSmm2ActorLeaves,appendCopiedSmm2ActorLeaves,pruneSmm2DeletedReferences} from '../atlas/editor-smm2-tools.mjs';
import {captureSmm2GeometryBindings,appendSmm2GeometryBindings} from '../atlas/editor-smm2-course-tools.mjs';
import {captureSmm2BoneBindings,appendCopiedSmm2BoneBindings} from '../atlas/editor-smm2-bone-tools.mjs';
import {captureMarioEmptyShellSources,appendCopiedMarioEmptyShellSources} from '../atlas/editor-mario-modules-editor.mjs';
import {enableCopiedSpikeTraps} from '../atlas/editor-contraptions-tools.mjs';
import {guardProject,guardRule} from './fixtures/chain-chomp-neutral.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';
const r=h=>h.doc.rooms[0],q=h=>guardRule(h.doc);

test('new guard owns one native body and independent stake; authoring, save/load and History preserve strict values',()=>{
 const d=guardProject({guard:false});d.rooms[0].map.objects=d.rooms[0].map.objects.filter(o=>o.kind!=='walker');d.rooms[0].smm2Mechanics.lighting.sources=[];const h=new History(d);let id;h.change(()=>{id=addChainChompGuard(r(h));});assert.equal(r(h).contraptions.chainChompGuards[0].actorId,id);assert(r(h).map.objects.some(o=>o.id===id&&o.w===32&&o.h===32));h.change(()=>updateChainChompGuard(r(h),id,{phase:{...q(h).phase,windupFrames:36}}));assert.equal(q(h).phase.windupFrames,36);assert.deepEqual(parseProject(JSON.stringify(h.doc)),h.doc);h.undo();assert.equal(q(h).phase.windupFrames,30);h.redo();assert.equal(q(h).phase.windupFrames,36);h.change(()=>removeChainChompGuard(r(h),id));assert(!r(h).contraptions.chainChompGuards);assert(!r(h).map.objects.some(o=>o.id===id));h.undo();assert.equal(q(h).actorId,id);
});

test('illegal tuning and unsupported vertical movement roll back both body and tether atomically',()=>{
 const h=new History(guardProject()),saved=JSON.stringify(h.doc);for(const values of [{leashLength:NaN},{phase:{...q(h).phase,windupFrames:23}},{motion:{...q(h).motion,lungeHeight:49}},{speedThreshold:2},{post:{...q(h).post,y:360}}]){assert.throws(()=>h.change(()=>updateChainChompGuard(r(h),'guard-head',values)));assert.equal(JSON.stringify(h.doc),saved);}
 assert.throws(()=>moveSelection(r(h),'objects',new Set(['guard-head']),0,16));assert.equal(JSON.stringify(h.doc),saved);assert.throws(()=>h.change(()=>cloneChainChompGuard(r(h),'guard-head',{dx:Infinity})));assert.equal(JSON.stringify(h.doc),saved);
});

test('generic native movement carries the same stake and generic deletion prunes leaf/light through History',()=>{
 const h=new History(guardProject());h.change(()=>moveSelection(r(h),'objects',new Set(['guard-head']),16,0));assert.equal(q(h).post.x,88);assert.equal(q(h).rest.x,120);assert.equal(r(h).map.objects.find(o=>o.id==='guard-head').x,104);h.undo();assert.equal(q(h).post.x,72);h.redo();assert.equal(q(h).post.x,88);
 h.change(()=>deleteSelection(r(h),'objects',new Set(['guard-head'])));assert(!r(h).contraptions.chainChompGuards);assert(!r(h).smm2Mechanics.lighting.sources.some(l=>l.targetId==='guard-head'));h.undo();assert.equal(q(h).postId,'guard-post');assert(r(h).smm2Mechanics.lighting.sources.some(l=>l.targetId==='guard-head'));assert.deepEqual(parseProject(JSON.stringify(h.doc)),h.doc);
});

test('component and native clipboard copies remap actor/post independently and keep the entire linked graph',()=>{
 const h=new History(guardProject());let second;h.change(()=>{second=cloneChainChompGuard(r(h),'guard-head',{dx:160});});const [first,other]=r(h).contraptions.chainChompGuards;assert.notEqual(other.actorId,first.actorId);assert.notEqual(other.postId,first.postId);assert.equal(other.rest.x,first.rest.x+160);assert(r(h).smm2Mechanics.lighting.sources.some(l=>l.targetId===second));assert.deepEqual(parseProject(JSON.stringify(h.doc)),h.doc);
 const source=guardProject().rooms[0],dest=guardProject({guard:false}).rooms[0];dest.map.objects=dest.map.objects.filter(o=>o.kind!=='walker');dest.smm2Mechanics.lighting.sources=[];const body={...source.map.objects.find(o=>o.id==='guard-head'),id:'copied-head',x:248},map=new Map([['guard-head','copied-head']]);dest.map.objects.push(body);appendCopiedChainChompGuardBindings(dest,captureChainChompGuardBindings(source,new Set(['guard-head'])),map,{dx:160,dy:0});assert.equal(dest.contraptions.chainChompGuards[0].actorId,'copied-head');assert.equal(dest.contraptions.chainChompGuards[0].post.x,232);assert.notEqual(dest.contraptions.chainChompGuards[0].postId,'guard-post');
});

test('actual sidebar creates, edits, rejects unreadable cue duration, copies and removes through History',()=>{
 const ui=installSimulatedPlayDom();try{const d=guardProject({guard:false});d.rooms[0].map.objects=d.rooms[0].map.objects.filter(o=>o.kind!=='walker');d.rooms[0].smm2Mechanics.lighting.sources=[];const h=new History(d),parent=ui.document.createElement('aside'),errors=[],panel=mountChainChompGuardTools({parent,room:()=>r(h),change:fn=>h.change(fn),report:e=>errors.push(e)}),click=text=>{const b=parent.querySelectorAll('button').find(b=>b.textContent===text);assert(b);b.click();};click('+ 放置拴链大狗');assert.equal(r(h).contraptions.chainChompGuards.length,1);parent.querySelector('[data-chain-chomp-guard-control="phase.windupFrames"]').value='36';parent.querySelector('form').dispatchEvent({type:'submit'});assert.equal(q(h).phase.windupFrames,36);const saved=JSON.stringify(h.doc);parent.querySelector('[data-chain-chomp-guard-control="phase.windupFrames"]').value='2';parent.querySelector('form').dispatchEvent({type:'submit'});assert.equal(JSON.stringify(h.doc),saved);assert(errors.length);click('复制狗头和木桩');assert.equal(r(h).contraptions.chainChompGuards.length,2);click('删除狗头和木桩');assert.equal(r(h).contraptions.chainChompGuards.length,1);h.undo();panel.refresh();assert.equal(r(h).contraptions.chainChompGuards.length,2);}finally{ui.restore();}
});

test('actual native copy/paste/delete handler carries guard configuration and light, without new-helper calls on old documents',()=>{
 const ui=installSimulatedPlayDom();try{const h=new History(guardProject()),source=fs.readFileSync(new URL('../atlas/editor.mjs',import.meta.url),'utf8'),start=source.indexOf("$('copy').onclick="),end=source.indexOf("$('map-export').onclick=",start),buttons=Object.fromEntries(['copy','paste','delete'].map(id=>[id,ui.document.createElement('button')])),errors=[],host={camera:{x:224,y:336},selected:new Set(['guard-head']),$:id=>buttons[id],room:()=>r(h),layer:()=> 'objects',items:()=>r(h).map.objects,run:fn=>{try{fn();}catch(e){errors.push(e.message);}},say:()=>{},refresh:()=>{},transaction:fn=>h.change(()=>{const before=clone(h.doc);fn();pruneSmm2DeletedReferences(r(h),before.rooms[0]);pruneSmm2LightingReferences(r(h),before.rooms[0]);}),clone,uid,linked,moveSelection,deleteSelection,captureSmm2LightingBindings,appendCopiedSmm2LightingBindings,captureSmm2ActorLeaves,appendCopiedSmm2ActorLeaves,captureSmm2GeometryBindings,appendSmm2GeometryBindings,captureSmm2BoneBindings,appendCopiedSmm2BoneBindings,captureMarioEmptyShellSources,appendCopiedMarioEmptyShellSources,enableCopiedSpikeTraps,captureChainChompGuardBindings,appendCopiedChainChompGuardBindings};
 const api=new Function('host','const {'+Object.keys(host).filter(k=>!['camera','selected'].includes(k)).join(',')+'}=host;let selected=host.selected,clipboard=null;const camera=host.camera;'+source.slice(start,end)+';return {selected(){return selected;}};')(host);buttons.copy.click();buttons.paste.click();assert.deepEqual(errors,[]);assert.equal(r(h).contraptions.chainChompGuards.length,2);const newId=[...api.selected()][0],copied=r(h).contraptions.chainChompGuards.find(q=>q.actorId===newId);assert(copied);assert.equal(copied.post.x,224);assert(r(h).smm2Mechanics.lighting.sources.some(l=>l.targetId===newId));buttons.delete.click();assert.equal(r(h).contraptions.chainChompGuards.length,1);assert(!r(h).smm2Mechanics.lighting.sources.some(l=>l.targetId===newId));h.undo();assert.equal(r(h).contraptions.chainChompGuards.length,2);assert.deepEqual(parseProject(JSON.stringify(h.doc)),h.doc);
 }finally{ui.restore();}
});

test('collection declares the authored guard capability only when a nonempty leaf is present',()=>{
 assert(requiredCollectionCapabilities(guardProject()).includes('authored-chain-chomp-guard-v1'));assert(!requiredCollectionCapabilities(guardProject({guard:false})).includes('authored-chain-chomp-guard-v1'));const d=guardProject({guard:false});d.rooms[0].contraptions.chainChompGuards=[];assert(!requiredCollectionCapabilities(d).includes('authored-chain-chomp-guard-v1'));
});
