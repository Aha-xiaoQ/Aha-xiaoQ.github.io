import test from 'node:test';
import assert from 'node:assert/strict';
import {createCanvas} from '@napi-rs/canvas';
import {createSkyShooter,validateSkyShooterRoom} from '../atlas/editor-sky-shooter.mjs';
import {drawSkyShooter} from '../atlas/editor-sky-shooter-art.mjs';
import {History,parseProject,deleteSelection} from '../atlas/editor-model.mjs';
import {setSkyShooter,removeSkyShooter,captureSkyShooterBindings,appendCopiedSkyShooterBindings,mountSkyShooterTools} from '../atlas/editor-sky-shooter-tools.mjs';
import {createCollection,addLevel,buildCollection,requiredCollectionCapabilities,parseCollection,serializeCollection} from '../atlas/editor-collection.mjs';
import {skyShooterProject,skyShooterBodies} from './fixtures/sky-shooter.mjs';
import {neutralLoopProject} from './fixtures/sky-shooter-loop.mjs';
import {enemyFireProject as project} from './fixtures/sky-shooter-enemy-fire.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';
import {character,nativeSession} from './fixtures/shell-coin-native.mjs';

// These tests exercise a reusable native contract, never a private level factory.
const fields=['version','downwardActorIds','diverActorIds','firstDownwardShotFrames','downwardIntervalFrames','telegraphFrames','shotSpeed','shotLifeFrames','maxShots','diverAttackY','minAimDistance'];
const epsilon=1e-6;
const near=(actual,expected,label)=>assert(Math.abs(actual-expected)<=epsilon,label??`${actual} != ${expected}`);
const point=q=>({x:q.x,y:q.y});
const rule=d=>d.rooms[0].smm2Mechanics.skyShooter;
function session(d=project()){
 const r=d.rooms[0],enemies=skyShooterBodies(r),events=[],hits=[],hurt=[],geometry=structuredClone(r.map.geometry),p={x:180,y:280,w:10,h:14,vx:0,vy:0,lakituCloudId:'ride',dead:false,power:0};let tick=0;
 const c=createSkyShooter(r,{emit:(type,data)=>events.push({type,...data}),defeatEnemy:(actor,hit)=>{hits.push(hit);actor.dead=true;return true;},hurtPlayer:hit=>hurt.push(hit)});
 const s={d,r,c,enemies,events,hits,hurt,geometry,p,get tick(){return tick;},step(input={}){return c.step({tick:++tick,player:p,input,enemies,geometry});},until(predicate,limit=2400){for(let n=0;n<limit;n++){s.step();if(predicate(c.view()))return c.view();}throw Error('Enemy-fire contract timed out at '+tick);}};
 return s;
}
function downwardSession(){const d=project();rule(d).attack.firstAttackFrames=600;rule(d).attack.intervalFrames=1200;return session(d);}
function aimedSession(){const d=project();rule(d).enemyFire.firstDownwardShotFrames=600;rule(d).attack.firstAttackFrames=36;rule(d).attack.intervalFrames=1200;rule(d).attack.diveTurnFrames=24;return session(d);}
const warning=(s,kind)=>s.c.view().warnings.find(q=>q.kind===kind);
const launches=(s,kind)=>s.events.filter(q=>q.event==='enemy-shot-launch'&&(!kind||q.kind===kind));

test('enemy fire is a complete strict optional leaf with finite bounded tuning and existing disjoint native IDs',()=>{
 assert(validateSkyShooterRoom(project().rooms[0]));
 const changes=[
  s=>s.enemyFire=null,s=>s.enemyFire=false,s=>s.enemyFire.version=2,s=>s.enemyFire.extra=1,
  s=>s.enemyFire.downwardActorIds=[],s=>s.enemyFire.diverActorIds=[],s=>s.enemyFire.downwardActorIds=['drone-b','drone-b'],s=>s.enemyFire.diverActorIds=['drone-a','drone-a'],
  s=>s.enemyFire.downwardActorIds=['missing'],s=>s.enemyFire.diverActorIds=['missing'],s=>s.enemyFire.downwardActorIds=['reward-pink'],s=>s.enemyFire.downwardActorIds=['drone-a'],
  s=>s.enemyFire.diverActorIds=['drone-b'],s=>s.loopingDivers.actorIds=['drone-a','drone-c'],s=>delete s.loopingDivers,s=>s.drones[2].wave=2,
  s=>s.enemyFire.firstDownwardShotFrames=35,s=>s.enemyFire.firstDownwardShotFrames=601,s=>s.enemyFire.firstDownwardShotFrames=90.5,
  s=>s.enemyFire.telegraphFrames=35,s=>s.enemyFire.telegraphFrames=181,s=>s.enemyFire.telegraphFrames=36.5,
  s=>s.enemyFire.downwardIntervalFrames=59,s=>s.enemyFire.downwardIntervalFrames=1201,s=>s.enemyFire.downwardIntervalFrames=84.5,
  s=>s.enemyFire.shotSpeed=.49,s=>s.enemyFire.shotSpeed=3.01,s=>s.enemyFire.shotSpeed=Infinity,s=>s.enemyFire.shotSpeed=NaN,
  s=>s.enemyFire.shotLifeFrames=23,s=>s.enemyFire.shotLifeFrames=301,s=>s.enemyFire.shotLifeFrames=240.5,
  s=>s.enemyFire.maxShots=0,s=>s.enemyFire.maxShots=7,s=>s.enemyFire.maxShots=4.5,
  s=>s.enemyFire.diverAttackY=136,s=>s.enemyFire.diverAttackY=320,s=>s.enemyFire.diverAttackY=Infinity,
  s=>s.enemyFire.minAimDistance=23.99,s=>s.enemyFire.minAimDistance=128.01,s=>s.enemyFire.minAimDistance=NaN,
  s=>s.enemyFire[Symbol('alias')]=1,s=>Object.defineProperty(s.enemyFire,'__proto__',{value:{},enumerable:true}),
  s=>s.enemyFire=Object.assign(Object.create({alias:true}),s.enemyFire),
 ];
 for(const change of changes){const d=project();change(rule(d));assert.throws(()=>validateSkyShooterRoom(d.rooms[0]));}
 for(const key of ['downwardActorIds','diverActorIds'])for(const [name,change]of [
  ['sparse first entry',a=>delete a[0]],['sparse trailing entry',a=>a.length++],['extra string key',a=>a.extra=1],['noncanonical index00',a=>a['00']='drone-b'],['noncanonical index01',a=>a['01']='drone-b'],['Symbol key',a=>a[Symbol('alias')]=1],
  ['nonenumerable extra key',a=>Object.defineProperty(a,'hidden-alias',{value:1})],['own __proto__ key',a=>Object.defineProperty(a,'__proto__',{value:{},enumerable:true})],
  ['null array prototype',a=>Object.setPrototypeOf(a,null)],['custom array prototype',a=>Object.setPrototypeOf(a,Object.create(Array.prototype))],
 ]){const d=project();change(rule(d).enemyFire[key]);assert.throws(()=>validateSkyShooterRoom(d.rooms[0]),key+' rejects '+name);}
 for(const key of fields){const d=project();delete rule(d).enemyFire[key];assert.throws(()=>validateSkyShooterRoom(d.rooms[0]),/Missing/);}
 const amplitude=project();rule(amplitude).formation.amplitudeY=8;rule(amplitude).enemyFire.diverAttackY=144;assert.throws(()=>validateSkyShooterRoom(amplitude.rooms[0]));
});

test('enemy-fire numeric endpoints are inclusive while its attack plane stays strictly between formation body and exit',()=>{
 for(const [key,values]of Object.entries({firstDownwardShotFrames:[36,600],telegraphFrames:[36,180],downwardIntervalFrames:[60,1200],shotSpeed:[.5,3],shotLifeFrames:[24,300],maxShots:[1,6],diverAttackY:[136.001,319.999],minAimDistance:[24,128]})){
  for(const value of values){const d=project(),e=rule(d).enemyFire;e[key]=value;if(key==='telegraphFrames')e.downwardIntervalFrames=value+24;assert(validateSkyShooterRoom(d.rooms[0]),key+' '+value);}
 }
});

test('enemy-fire roles support at most24 existing downward bodies plus six exact existing looping divers',()=>{
 const d=project(),r=d.rooms[0],s=rule(d);s.drones=[];r.map.objects=r.map.objects.filter(q=>q.kind!=='walker');
 for(let n=0;n<30;n++){const id='neutral-body-'+n,x=200+(n%10)*28,y=128+Math.floor(n/10)*24;r.map.objects.push({id,kind:'walker',x,y,w:16,h:16});s.drones.push({id,wave:1,x,y,phaseFrames:0});}
 s.loopingDivers.actorIds=s.drones.slice(0,6).map(q=>q.id);s.enemyFire.diverActorIds=[...s.loopingDivers.actorIds];s.enemyFire.downwardActorIds=s.drones.slice(6).map(q=>q.id);assert(validateSkyShooterRoom(r));
 s.enemyFire.downwardActorIds.push(s.drones[0].id);assert.throws(()=>validateSkyShooterRoom(r));s.enemyFire.downwardActorIds.pop();s.enemyFire.diverActorIds.push(s.drones[6].id);assert.throws(()=>validateSkyShooterRoom(r));
});

test('leaves without enemyFire retain the exact legacy view shape and old looping warning kind',()=>{
 const base=createSkyShooter(skyShooterProject().rooms[0]).view(),loop=createSkyShooter(neutralLoopProject().rooms[0]).view();
 assert.deepEqual(Object.keys(base).sort(),['version','originalComposition','parameterStatus','cloudId','started','cleared','wave','waveCount','defeated','total','nextWaveTick','gateIds','rewardId','weapon','shots','missiles','warnings','drones'].sort());
 assert.deepEqual(Object.keys(loop).sort(),[...Object.keys(base),'loopingDivers'].sort());assert(!Object.hasOwn(base,'enemyFire'));assert(!Object.hasOwn(loop,'enemyFire'));
 const s=session(neutralLoopProject());s.until(v=>v.warnings.length>0);assert.equal(s.c.view().warnings[0].kind,'dive');assert.equal(s.c.view().warnings[0].remainingFrames,48);
 const enabled=createSkyShooter(project().rooms[0]).view().enemyFire;assert.deepEqual(enabled,{version:1,downwardActorIds:['drone-b','drone-c'],diverActorIds:['drone-a'],maxShots:4,shots:[]});
});

test('downward schedules warn at first+interval, freeze the same body and muzzle for36 full ticks, then launch straight down',()=>{
 const d=project();rule(d).attack.firstAttackFrames=600;rule(d).formation.amplitudeX=24;rule(d).formation.amplitudeY=8;const s=session(d);s.step();
 while(s.tick<90){s.step();assert(!warning(s,'downward'));assert.equal(launches(s).length,0);}
 s.step();const w=warning(s,'downward'),actor=s.enemies.find(q=>q.id===w.actorId),bodyStart=point(actor);assert(w);assert.equal(w.actorId,'drone-b');assert.equal(w.startedTick,91);assert.equal(w.readyTick,127);assert.equal(w.remainingFrames,36);assert.deepEqual(w.source,{x:actor.x+8,y:actor.y+16});
 s.p.x=430;s.p.y=220;
 for(let n=1;n<36;n++){s.step();assert.deepEqual(point(actor),bodyStart);assert.deepEqual(warning(s,'downward').source,w.source);assert.deepEqual(warning(s,'downward').target,w.target);assert.equal(warning(s,'downward').remainingFrames,36-n);assert.equal(launches(s).length,0);}
 s.step();const launched=launches(s,'downward')[0],shot=s.c.view().enemyFire.shots.find(q=>q.id===launched.shotId);assert.equal(launched.tick,127);assert.equal(launched.actorId,actor.id);assert.deepEqual(launched.origin,w.source);assert.deepEqual(launched.target,w.target);assert(shot);assert.equal(shot.vx,0);assert.equal(shot.vy,1.8);near(shot.x,w.source.x-2);near(shot.y,w.source.y+shot.age*1.8);assert.deepEqual(point(actor),bodyStart);assert.equal(s.hurt.length,0);assert.equal(s.c.view().missiles.length,0);
 let old=point(actor),steps=0;while(s.c.view().drones.find(q=>q.id===actor.id).state!=='formation'&&steps++<80){s.step();assert(Math.hypot(actor.x-old.x,actor.y-old.y)<=rule(s.d).loopingDivers.returnSpeed+epsilon);old=point(actor);
  const sameTick=s.c.view(),sameBodies=structuredClone(s.enemies);s.c.step({tick:s.tick,player:s.p,input:{run:true},enemies:s.enemies,geometry:s.geometry});assert.deepEqual(s.c.view(),sameTick);assert.deepEqual(s.enemies,sameBodies);
 }
 assert(steps<80,'same downward body returns continuously to its moving formation slot');assert.equal(s.c.view().defeated,0);
});

test('downward attacks rotate stable native IDs at84tick spacing and enabled leaves suppress all legacy homing missiles',()=>{
 const s=downwardSession();s.until(()=>s.events.filter(q=>q.event==='attack-warning'&&q.kind==='downward').length>=3,400);
 const warnings=s.events.filter(q=>q.event==='attack-warning'&&q.kind==='downward').slice(0,3);assert.deepEqual(warnings.map(q=>q.actorId),['drone-b','drone-c','drone-b']);assert.deepEqual(warnings.map(q=>q.tick),[91,175,259]);
 for(let n=0;n<1900;n++){s.step();assert.equal(s.c.view().missiles.length,0);assert(s.c.view().enemyFire.shots.length<=4);}
 assert(!s.events.some(q=>q.event==='missile-launch'));assert.equal(s.c.view().defeated,0);assert(!s.geometry.find(q=>q.id==='reward-gate').hidden);
});

test('a selected diver reaches exact body-top280 continuously despite a24tick legacy cutoff, then locks one36tick aim snapshot',()=>{
 const s=aimedSession(),actor=s.enemies[0],original=actor;s.p.x=350;s.p.y=220;let old=point(actor),sawDive=false;
 while(!warning(s,'aimed')&&s.tick<400){s.step();assert.strictEqual(s.enemies[0],original);assert(Math.hypot(actor.x-old.x,actor.y-old.y)<=2.300001);old=point(actor);if(s.c.view().drones.find(q=>q.id===actor.id)?.state==='dive')sawDive=true;}
 const w=warning(s,'aimed');assert(w);assert(sawDive);assert.equal(w.actorId,'drone-a');near(actor.y,280);assert(w.startedTick>rule(s.d).attack.firstAttackFrames+rule(s.d).attack.diveTurnFrames);assert.equal(w.remainingFrames,36);assert.deepEqual(w.source,{x:actor.x+8,y:296});assert.deepEqual(w.target,{x:s.p.x+5,y:s.p.y+7});const bodyStart=point(actor),expectedTarget=structuredClone(w.target);
 s.p.x=450;s.p.y=200;
 for(let n=1;n<36;n++){s.step();assert.deepEqual(point(actor),bodyStart);assert.deepEqual(warning(s,'aimed').target,expectedTarget);assert.deepEqual(warning(s,'aimed').source,w.source);assert.equal(launches(s,'aimed').length,0);}
 s.step();const launch=launches(s,'aimed')[0],shot=s.c.view().enemyFire.shots.find(q=>q.id===launch.shotId);assert(launch);assert.equal(launch.tick,w.startedTick+36);assert.deepEqual(launch.origin,w.source);assert.deepEqual(launch.target,expectedTarget);assert(shot);const dx=expectedTarget.x-w.source.x,dy=expectedTarget.y-w.source.y,d=Math.hypot(dx,dy);near(shot.vx,dx/d*1.8);near(shot.vy,dy/d*1.8);
 const velocity={x:shot.vx,y:shot.vy};s.p.x=180;s.p.y=120;s.step();const moved=s.c.view().enemyFire.shots.find(q=>q.id===shot.id);assert(moved);near(moved.vx,velocity.x);near(moved.vy,velocity.y);assert.equal(s.c.view().missiles.length,0);
});

test('an aimed target within40px skips the projectile and follows the same living native exit/top-return path',()=>{
 const s=aimedSession(),actor=s.enemies[0];s.p.x=actor.x+3;s.p.y=289;s.until(()=>!!warning(s,'aimed'),400);const w=warning(s,'aimed');assert(Math.hypot(w.target.x-w.source.x,w.target.y-w.source.y)<40);
 for(let n=0;n<36;n++)s.step();assert.equal(launches(s,'aimed').length,0);assert(s.events.some(q=>q.event==='enemy-shot-skipped'&&q.actorId===actor.id&&q.reason==='too-close'));assert.equal(s.c.view().enemyFire.shots.length,0);
 let old=point(actor);while((s.c.view().loopingDivers.cycles[0].returns<1)&&s.tick<1300){s.step();assert.strictEqual(s.enemies[0],actor);assert(Math.hypot(actor.x-old.x,actor.y-old.y)<=2.300001);old=point(actor);assert(!actor.dead);}
 assert.equal(s.c.view().loopingDivers.cycles[0].returns,1);for(const name of ['diver-exit-start','diver-exit','diver-top-reentry','diver-slot-approach','diver-formation-return'])assert(s.events.some(q=>q.event===name&&q.actorId===actor.id),name);assert.equal(s.c.view().defeated,0);assert.equal(s.hits.length,0);assert(!s.geometry.find(q=>q.id==='reward-gate').hidden);
});

test('the min-distance rule skips strictly below40px and permits an exact40px real aimed projectile',()=>{
 for(const distance of [39.999,40]){const s=aimedSession();s.p.x=211;s.p.y=289+distance;s.until(()=>!!warning(s,'aimed'),400);const w=warning(s,'aimed');near(Math.hypot(w.target.x-w.source.x,w.target.y-w.source.y),distance);for(let n=0;n<36;n++)s.step();
  if(distance<40){assert.equal(launches(s,'aimed').length,0);assert(s.events.some(q=>q.event==='enemy-shot-skipped'&&q.reason==='too-close'));}
  else{assert.equal(launches(s,'aimed').length,1);const shot=s.c.view().enemyFire.shots[0];assert(shot);near(shot.vx,0);near(shot.vy,1.8);assert(!s.events.some(q=>q.event==='enemy-shot-skipped'&&q.reason==='too-close'));}
 }
});

test('a diver that fires returns as the same native body, then one physical player shot defeats that ID only once',()=>{
 const s=aimedSession(),actor=s.enemies[0];s.p.x=350;s.p.y=220;s.until(()=>launches(s,'aimed').length===1,400);s.p.x=180;s.p.y=200;let old=point(actor);
 while(s.c.view().loopingDivers.cycles[0].returns<1&&s.tick<1300){s.step();assert.strictEqual(s.enemies[0],actor);assert(Math.hypot(actor.x-old.x,actor.y-old.y)<=2.300001);old=point(actor);assert(!actor.dead);assert.equal(s.c.view().defeated,0);}
 assert.equal(s.c.view().loopingDivers.cycles[0].returns,1);s.p.x=actor.x-3;s.p.y=200;for(let n=0;n<40&&!actor.dead;n++)s.step({run:true});assert(actor.dead);assert.equal(s.hits.length,1);assert.equal(s.hits[0].kind,'sky-shot');assert.equal(s.c.view().defeated,1);assert(!s.c.defeatedActor(actor));
 for(let n=0;n<800;n++)s.step();assert.strictEqual(s.enemies[0],actor);assert(actor.dead);assert(!s.c.view().drones.some(q=>q.id===actor.id));assert.equal(s.c.view().defeated,1);assert.equal(s.events.filter(q=>q.event==='native-defeat-confirmed'&&q.actorId===actor.id).length,1);assert(!s.geometry.find(q=>q.id==='reward-gate').hidden);
});

test('real downward projectiles hit runtime solid terrain before players and report the contacted stable IDs',()=>{
 const s=downwardSession();s.p.x=307;s.p.y=230;s.geometry.push({id:'runtime-shield',x:296,y:176,w:32,h:8,collision:'solid'});s.until(()=>launches(s,'downward').length===1,200);const shotId=launches(s,'downward')[0].shotId;
 assert.equal(s.hurt.length,0);s.until(()=>s.events.some(q=>q.event==='enemy-shot-blocked'&&q.shotId===shotId),100);assert(s.events.some(q=>q.event==='enemy-shot-blocked'&&q.shotId===shotId&&q.solidId==='runtime-shield'));assert(!s.c.view().enemyFire.shots.some(q=>q.id===shotId));assert.equal(s.hurt.length,0);assert.equal(s.c.view().defeated,0);
});

test('travelling enemy shots call the real host hurtPlayer once with sky-enemy-shot and never mutate passenger state themselves',()=>{
 const s=downwardSession();s.p.x=307;s.p.y=230;const before=structuredClone(s.p);s.until(()=>launches(s,'downward').length===1,200);const shotId=launches(s,'downward')[0].shotId;assert.equal(s.hurt.length,0);
 s.until(()=>s.hurt.length>0,100);assert.equal(s.hurt.length,1);assert.equal(s.hurt[0].kind,'sky-enemy-shot');assert.equal(s.hurt[0].shotId,shotId);assert(s.events.some(q=>q.event==='enemy-shot-contact'&&q.shotId===shotId));assert.deepEqual(s.p,before);assert(!s.c.view().enemyFire.shots.some(q=>q.id===shotId));assert.equal(s.c.view().defeated,0);
});

test('enemy projectile lifetime and capacity are real bounds even when authored attacks would fill the arena',()=>{
 const d=project(),r=d.rooms[0],e=rule(d).enemyFire;r.map.height=1024;r.map.geometry.find(q=>q.id==='floor').y=992;e.firstDownwardShotFrames=36;e.downwardIntervalFrames=60;e.shotSpeed=.5;e.maxShots=1;e.shotLifeFrames=300;rule(d).attack.firstAttackFrames=600;const s=session(d);let first=null;
 for(let n=0;n<390;n++){s.step();assert(s.c.view().enemyFire.shots.length<=1);for(const shot of s.c.view().enemyFire.shots)assert(shot.age<300);first??=launches(s,'downward')[0];}
 assert(first);assert(s.events.some(q=>q.event==='enemy-shot-skipped'&&q.reason==='capacity'));assert(!s.c.view().enemyFire.shots.some(q=>q.id===first.shotId));assert.equal(s.c.view().defeated,0);
 const short=project();rule(short).enemyFire.shotLifeFrames=24;rule(short).attack.firstAttackFrames=600;const t=session(short);t.until(()=>launches(t,'downward').length>0,200);const id=launches(t,'downward')[0].shotId;t.until(()=>!t.c.view().enemyFire.shots.some(q=>q.id===id),30);assert(!t.events.some(q=>q.shotId===id&&['enemy-shot-contact','enemy-shot-blocked'].includes(q.event)));
});

test('native death cancels a locked warning, never revives the same ID and counts only the original real body once',()=>{
 const s=downwardSession();s.until(()=>!!warning(s,'downward'),200);const w=warning(s,'downward'),actor=s.enemies.find(q=>q.id===w.actorId);assert(!s.c.defeatedActor({...actor,dead:true}));actor.dead=true;assert(s.c.defeatedActor(actor));assert(!s.c.defeatedActor(actor));assert(!s.c.view().warnings.some(q=>q.actorId===actor.id));
 for(let n=0;n<900;n++){s.step();assert.strictEqual(s.enemies.find(q=>q.id===actor.id),actor);assert(actor.dead);assert(!s.c.view().drones.some(q=>q.id===actor.id));}
 assert.equal(s.c.view().defeated,1);assert.equal(s.events.filter(q=>q.event==='native-defeat-confirmed'&&q.actorId===actor.id).length,1);assert(!launches(s).some(q=>q.actorId===actor.id));assert(!s.geometry.find(q=>q.id==='reward-gate').hidden);
});

test('enabled views are detached, duplicate ticks are inert and reset returns exact initial enemy-fire state',()=>{
 const s=downwardSession(),initial=s.c.view();s.until(()=>launches(s).length>0,200);const snapshot=s.c.view(),bodyState=structuredClone(s.enemies),geometry=structuredClone(s.geometry),player=structuredClone(s.p);snapshot.enemyFire.shots[0].x=-999;snapshot.enemyFire.downwardActorIds.length=0;const actual=s.c.view();
 s.c.step({tick:s.tick,player:s.p,input:{run:true},enemies:s.enemies,geometry:s.geometry});assert.deepEqual(s.c.view(),actual);assert.deepEqual(s.enemies,bodyState);s.c.reset();assert.deepEqual(s.c.view(),initial);assert.deepEqual(s.p,player);assert.deepEqual(s.geometry,geometry);
});

test('qmap, History and the real author panel preserve complete enemy tuning and reject invalid edits atomically',()=>{
 const h=new History(project()),r=()=>h.doc.rooms[0],original=structuredClone(rule(h.doc)),restore=installSimulatedPlayDom();assert.deepEqual(parseProject(JSON.stringify(h.doc)),h.doc);
 try{const reports=[],ui=mountSkyShooterTools({parent:document.createElement('div'),room:r,change:fn=>h.change(fn),report:q=>reports.push(q)}),config=ui.panel.querySelector('[data-sky-shooter="config"]'),next=JSON.parse(config.value);next.enemyFire.shotSpeed=1.4;next.enemyFire.minAimDistance=48;config.value=JSON.stringify(next);ui.panel.querySelector('[data-sky-shooter="apply"]').onclick();assert.equal(rule(h.doc).enemyFire.shotSpeed,1.4);assert.equal(rule(h.doc).enemyFire.minAimDistance,48);assert.deepEqual(parseProject(JSON.stringify(h.doc)),h.doc);h.undo();assert.deepEqual(rule(h.doc),original);h.redo();assert.equal(rule(h.doc).enemyFire.shotSpeed,1.4);
  const invalid=structuredClone(rule(h.doc));invalid.enemyFire.diverActorIds=['drone-b'];const before=JSON.stringify(h.doc),depth=h.undoStack.length;assert.throws(()=>h.change(()=>setSkyShooter(r(),invalid)));assert.equal(JSON.stringify(h.doc),before);assert.equal(h.undoStack.length,depth);config.value=JSON.stringify(invalid);ui.panel.querySelector('[data-sky-shooter="apply"]').onclick();assert.equal(reports.length,1);assert.equal(JSON.stringify(h.doc),before);
  h.change(()=>deleteSelection(r(),'objects',new Set(['drone-a'])));assert.equal(rule(h.doc),undefined);assert(r().map.objects.some(q=>q.id==='reward-pink'));h.undo();assert(rule(h.doc).enemyFire);assert.deepEqual(parseProject(JSON.stringify(h.doc)),h.doc);
 }finally{restore.restore();}
});

test('full binding capture/remap translates diverAttackY and both stable role lists without changing projectile tuning',()=>{
 const r=project().rooms[0],s=r.smm2Mechanics.skyShooter,ids=new Set([s.cloudId,s.rewardId,...s.gateIds,...s.drones.map(q=>q.id)]);assert.equal(captureSkyShooterBindings(r,new Set(['drone-a'])),null);const snapshot=captureSkyShooterBindings(r,ids),target=structuredClone(r),idMap=new Map([...ids].map(k=>[k,k+'-copy'])),dx=8,dy=8;removeSkyShooter(target);target.map.height+=dy;target.map.width+=dx;
 for(const q of [...target.map.objects,...target.map.geometry]){q.x+=dx;q.y+=dy;if(idMap.has(q.id))q.id=idMap.get(q.id);}target.smm2Mechanics.lakituClouds.clouds[0].id=idMap.get(s.cloudId);target.smm2Mechanics.pinkCoins[0].id=idMap.get(s.rewardId);
 appendCopiedSkyShooterBindings(target,snapshot,idMap,{dx,dy});const e=target.smm2Mechanics.skyShooter.enemyFire;assert.deepEqual(e.downwardActorIds,['drone-b-copy','drone-c-copy']);assert.deepEqual(e.diverActorIds,['drone-a-copy']);assert.equal(e.diverAttackY,288);for(const key of fields.filter(q=>!['downwardActorIds','diverActorIds','diverAttackY'].includes(q)))assert.deepEqual(e[key],s.enemyFire[key]);assert(validateSkyShooterRoom(target));assert.deepEqual(snapshot,s);
});

test('strict qcollection and real compiler retain enemy-fire bindings and advertise its separate capability',()=>{
 const d=project(),cap='authored-armed-cloud-enemy-fire-v1';assert(requiredCollectionCapabilities(d).includes(cap));assert(!requiredCollectionCapabilities(neutralLoopProject()).includes(cap));assert(!requiredCollectionCapabilities(skyShooterProject()).includes(cap));
 const collection=addLevel(createCollection('Neutral explicit enemy fire'),d,{id:'enemy-fire-fixture'});assert.deepEqual(parseCollection(serializeCollection(collection)),collection);const built=buildCollection(collection,character,{includePending:true});assert(built.requiredCapabilities.includes(cap));assert.deepEqual(built.levels[0].rooms[0].smm2Mechanics.skyShooter.enemyFire,rule(d).enemyFire);
});

test('native Canvas draws real enemy projectiles and locked warnings without changing native collision bodies',()=>{
 const s=downwardSession();s.until(()=>!!warning(s,'downward'),200);const before=structuredClone(s.enemies),render=v=>{const canvas=createCanvas(576,384);assert(drawSkyShooter(canvas.getContext('2d'),{...s.r,skyShooterView:v},s.tick));return canvas.toBuffer('image/png');},v=s.c.view(),withoutWarning=structuredClone(v);withoutWarning.warnings=[];assert.notDeepEqual(render(v),render(withoutWarning));assert.deepEqual(s.enemies,before);
 s.until(()=>launches(s,'downward').length>0,100);const shotView=s.c.view(),withoutShots=structuredClone(shotView);assert(shotView.enemyFire.shots.length);withoutShots.enemyFire.shots=[];assert.notDeepEqual(render(shotView),render(withoutShots));assert.deepEqual(s.enemies,before);
});

const walkAxis=(p,x)=>{const d=x-p.x;return Math.abs(d)<1?(Math.abs(p.vx)<.08?0:-Math.sign(p.vx)):Math.sign(d)*p.vx>0&&Math.abs(d)<p.vx*p.vx/(2*.1015625)+1?-Math.sign(p.vx):Math.sign(d);};
const flyAxis=(d,v)=>Math.abs(d)<1.5?(Math.abs(v)<.2?0:-Math.sign(v)):Math.sign(d)*v>0&&Math.abs(d)<v*v/(2*.16)+1?-Math.sign(d):Math.sign(d);
function board(s){s.until(v=>v.p.grounded,{},60);s.until(v=>Math.abs(v.p.x-97)<2&&Math.abs(v.p.vx)<.1&&v.p.grounded,v=>({x:walkAxis(v.p,97),run:true}),160);s.step({});s.until(v=>v.p.grounded&&v.p.support==='boarding-pad',v=>({x:walkAxis(v.p,97),jump:true,run:true}),160);s.step({});s.until(v=>v.p.lakituCloudId==='ride',v=>({x:walkAxis(v.p,117),jump:true,run:true}),160);}
function fly(s,x,y){return s.until(v=>Math.abs(v.p.x-x)<2&&Math.abs(v.p.y-y)<2&&Math.abs(v.p.vx)<.2&&Math.abs(v.p.vy)<.2,v=>{const dy=flyAxis(y-v.p.y,v.p.vy);return{x:flyAxis(x-v.p.x,v.p.vx),up:dy<0,down:dy>0};},400);}
test('actual neutral Stage projectile contact uses native Small damage, cloud disembark and real life loss',()=>{
 const d=project();rule(d).attack.firstAttackFrames=600;rule(d).attack.intervalFrames=1200;const s=nativeSession(d);board(s);fly(s,307,230);const before=s.view().lives;s.until(v=>v.lives<before,{},1200);const v=s.view();assert.equal(v.lives,before-1);assert(v.p.dying);assert.equal(v.p.lakituCloudId,undefined);assert(s.events.some(q=>q.type==='sky-shooter'&&q.event==='enemy-shot-contact'));assert.equal(v.smm2Mechanics.skyShooter.defeated,0);assert.equal(v.smm2Mechanics.pinkCoins.taken,0);assert(!v.geometry.find(q=>q.id==='reward-gate').hidden);
});
