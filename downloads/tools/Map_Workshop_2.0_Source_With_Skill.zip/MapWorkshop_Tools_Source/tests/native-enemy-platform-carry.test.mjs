import {test} from 'node:test';
import assert from 'node:assert/strict';
import {carryNativePlatformEnemy} from '../atlas/editor-mario-modules.mjs';
import {plantPlatformProject,rollingPlatformProject,idleShellPlatformProject,nativeSession,activate} from './fixtures/npc-platform-native.mjs';
import {checkPhysicalPickups,shellPickups,overlaps} from './fixtures/shell-coin-native.mjs';
const actor=v=>v.enemies.find(e=>e.id==='plant'),lift=v=>v.geometry.find(q=>q.id==='lift');
test('real Stage first-contact floor plant rides down, up and reversals with unchanged native body and velocity',()=>{
 const s=nativeSession(plantPlatformProject());let up=false,down=false,reversals=0,lastSign=0;
 for(let n=0;n<220;n++){const v=s.step(),e=actor(v),q=lift(v),sign=Math.sign(q.dy);assert(e);assert.equal(e.y+e.h,q.y);assert.equal(e.grounded,true);assert.equal(e.support,q.id);assert.equal(e.vx,0);assert.equal(e.vy,0);assert.equal(e.w,16);assert.equal(e.h,24);up||=sign<0;down||=sign>0;if(sign&&lastSign&&sign!==lastSign)reversals++;if(sign)lastSign=sign;}
 assert(up&&down&&reversals>=2);assert.equal(s.view().lives,3);assert.equal(s.view().score,0);
});
test('native generator liftSpeed decks carry actual first-contact plants in both vertical directions',()=>{
 for(const direction of [-1,1]){const d=plantPlatformProject(),r=d.rooms[0];r.map.geometry=r.map.geometry.filter(q=>q.id!=='lift');r.markers.push({id:'generator',kind:'platform-generator',x:160,y:144,source:{width:48,direction}});r.map.objects.find(q=>q.id==='plant').y=direction<0?120:136;const s=nativeSession(d);
  for(let n=0;n<50;n++){const v=s.step(),e=actor(v),q=v.geometry.find(q=>q.id==='generator-lift-1');assert.equal(e.support,q.id);assert.equal(e.y+e.h,q.y);assert.equal(q.dy,direction*.84);assert.equal(e.vy,0);}
 }
});
test('genuine kicked shell lands, rolls across a moving lift, walks off, and retains player coin ownership',()=>{
 const s=nativeSession(rollingPlatformProject());activate(s);let supported=0,landed=false,left=false;
 for(let n=0;n<200&&s.view().coins<2;n++){const v=s.step(),e=v.enemies.find(e=>e.id==='shell-body'),q=lift(v);assert(e);assert.equal(e.shell,true);assert.equal(e.vx,3.2);if(e.support==='lift'){landed=true;supported++;assert.equal(e.y+e.h,q.y);assert(e.x+e.w>q.x&&e.x<q.x+q.w);}if(landed&&e.x>=q.x+q.w){left=true;assert.notEqual(e.support,'lift');}}
 assert(landed&&supported>15&&left);assert.equal(s.view().coins,2);assert.equal(s.events.filter(e=>e.event==='player-kick').length,1);assert.equal(shellPickups(s).length,2);checkPhysicalPickups(s);assert.equal(s.view().lives,3);
});
test('winged floor plant jumps away using its own gravity and reacquires actual support on landing',()=>{
 const s=nativeSession(plantPlatformProject({winged:true}));let airborne=false,reacquired=false;
 for(let n=0;n<100;n++){const v=s.step(),e=actor(v),q=lift(v);if(e.vy<0){airborne=true;assert.equal(e.grounded,false);assert.equal(e.support,null);assert(e.y+e.h<q.y);}if(airborne&&e.support==='lift')reacquired=true;}
 assert(airborne&&reacquired);
});
test('true pipe-emitted idle Buzzy shell falls, lands, and rides a live lift without activation or body changes',()=>{
 const s=nativeSession(idleShellPlatformProject());s.until(v=>v.enemies.some(e=>e.grounded&&e.support==='lift'));const id=s.view().enemies[0].id;let up=false,down=false;
 for(const frame of s.trace)for(const e of frame.enemies)if(e.moduleEmergence){assert.equal(e.grounded,false);assert.equal(e.support,null);}
 for(let n=0;n<150;n++){const v=s.step(),e=v.enemies.find(e=>e.id===id),q=lift(v);assert(e&&e.emptyShell&&e.shell);assert.equal(e.vx,0);assert.equal(e.vy,0);assert.equal(e.w,16);assert.equal(e.h,16);assert.equal(e.support,'lift');assert.equal(e.y+e.h,q.y);up||=q.dy<0;down||=q.dy>0;}
 assert(up&&down);assert.equal(s.events.filter(e=>e.event==='player-kick').length,0);assert.equal(s.view().coins,0);assert.equal(s.view().score,0);
});
test('a genuinely emitted falling shell lands when the upward native top crosses it during the same frame',()=>{
 const d=idleShellPlatformProject(),r=d.rooms[0];Object.assign(r.map.geometry.find(q=>q.id==='lift'),{y:144,motion:{axis:'y',min:100,max:144,speed:2}});r.marioModules.enemySources[0].emergenceFrames=1;const s=nativeSession(d),v=s.until(v=>v.enemies.some(e=>e.support==='lift'),{},35),e=v.enemies.find(e=>e.support==='lift'),q=lift(v);
 assert(q.dy<0);assert.equal(e.y+e.h,q.y);assert.equal(e.vy,0);assert.equal(e.emptyShell,true);assert.equal(s.events.filter(e=>e.event==='enemy-source').length,1);assert.equal(s.events.filter(e=>e.event==='player-kick').length,0);
});
for(const rule of [false,null])test('opt-out '+rule+' preserves legacy downward plant falling/reacquisition',()=>{
 const s=nativeSession(plantPlatformProject({rule})),v=s.step();assert.equal(actor(v).y,120.3);assert.equal(actor(v).support,null);assert.equal(lift(v).y,145.25);assert(actor(v).y+actor(v).h<lift(v).y);
});
test('actual up-moving top never carries an airborne plant without prior top contact',()=>{
 const s=nativeSession(plantPlatformProject({initialY:192,plantY:80}));let fell=false;
 for(let n=0;n<5;n++){const v=s.step(),e=actor(v);assert.equal(e.support,null);fell||=e.vy>0;assert(e.y+e.h<lift(v).y);}
 assert(fell);
});
test('real Stage overhead and side solids stop carry at their swept face',()=>{
 for(const axis of ['y','x']){const d=plantPlatformProject({axis,speed:2,initialY:axis==='y'?192:144,plantY:axis==='y'?168:120}),r=d.rooms[0];if(axis==='y')r.map.geometry.push({id:'blocker',x:176,y:160,w:48,h:8,collision:'solid',material:'stone'});else r.map.geometry.push({id:'blocker',x:208,y:112,w:8,h:32,collision:'solid',material:'stone'});const s=nativeSession(d);let blocked=false;
  for(let n=0;n<8;n++){const v=s.step(),e=actor(v),q=v.geometry.find(g=>g.id==='blocker');assert(!overlaps(e,q),axis);if(axis==='y'&&e.y===q.y+q.h||axis==='x'&&e.x+e.w===q.x)blocked=true;}
  assert(blocked,axis);
 }
});
test('carry proof rejects stale support, missing overlap, upward flight, constraints and discontinuous lift wrap',()=>{
 const previous={id:'lift',x:160,y:144,w:96,h:8,collision:'oneway',motion:{axis:'y',min:112,max:192,speed:1}},q={...previous,y:146,dx:0,dy:2},original={id:'plant',type:'study-piranha',x:184,y:120,w:16,h:24,vx:0,vy:0,grounded:true,support:'lift',age:10},prior=new Map([[q.id,previous]]);
 for(const changes of [{y:100},{x:256},{vy:-1},{grounded:false},{support:'other'},{clawHeld:true},{vehicleId:'car'},{moduleEmergence:{}},{emerge:true}]){const before={...original,...changes},e={...before};assert.equal(carryNativePlatformEnemy(e,before,[q],prior),null);assert.equal(e.y,before.y);}
 const wrapped={...q,y:0,dy:0};assert.equal(carryNativePlatformEnemy({...original},original,[wrapped],prior),null);
 const e={...original};assert.equal(carryNativePlatformEnemy(e,original,[q],prior).dy,2);assert.equal(e.vx,0);assert.equal(e.vy,0);
});
test('continuous carry sweep stops at a thin solid instead of skipping through it',()=>{
 const before={id:'shell',type:'beetle',shell:true,x:0,y:0,w:16,h:16,vx:3.2,vy:0,grounded:true,support:'lift',age:10},prior={id:'lift',x:0,y:16,w:80,h:8,collision:'oneway',motion:{axis:'x',min:0,max:100,speed:1}},q={...prior,x:50,dx:50,dy:0},wall={id:'thin-wall',x:30,y:0,w:.25,h:16,collision:'solid'},e={...before};const result=carryNativePlatformEnemy(e,before,[q,wall],new Map([['lift',prior]]));
 assert(Math.abs(e.x-14)<1e-7);assert.equal(e.x+e.w,wall.x);assert.equal(result.fraction,14/50);assert.equal(e.vx,3.2);assert.equal(e.vy,0);assert.equal(e.support,null);assert(!overlaps(e,wall));
});
test('a genuine rolling shell defeats a live supported floor plant by actual body contact on the lift',()=>{
 const d=rollingPlatformProject(),r=d.rooms[0];r.map.objects.push({id:'plant',kind:'walker',x:256,y:200,w:16,h:24});r.marioModules.enemyVariants.plant={kind:'floor-piranha',size:'normal',winged:false};const s=nativeSession(d);activate(s);s.until(()=>s.events.some(e=>e.event==='enemy-hit'&&e.victimId==='plant'));
 const hit=s.events.find(e=>e.event==='enemy-hit'),v=s.trace[hit.frame-1],previous=s.trace[hit.frame-2],shell=v.enemies.find(e=>e.id===hit.actorId),prior=previous.enemies.find(e=>e.id==='plant');assert(prior&&prior.support==='lift');assert(shell&&shell.shell&&shell.vx===3.2);assert.equal(s.view().enemies.some(e=>e.id==='plant'),false);assert.equal(s.events.filter(e=>e.event==='enemy-hit'&&e.victimId==='plant').length,1);assert.equal(v.score-previous.score,200);
});
