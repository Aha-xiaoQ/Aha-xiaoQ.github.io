import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
import {offlineFile} from '../atlas/editor-offline.mjs';
import {createCollection,addLevel,buildCollection} from '../atlas/editor-collection.mjs';
import {bowserJrProject} from './fixtures/bowser-jr-native.mjs';
import {nativeSession,character} from './fixtures/shell-coin-native.mjs';
for(const collection of [false,true])test(`actual standalone ${collection?'collection':'single'} runs three native Jr stomps, real key and shared state/art without network`,async()=>{
 const project=bowserJrProject(),s=nativeSession(project),root=new URL('../atlas/',import.meta.url),built=collection?buildCollection(addLevel(createCollection('Neutral Jr closure'),project,{id:'jr-fixture'}),character,{includePending:true}):null;if(built)assert(built.requiredCapabilities.includes('bowser-jr-ground-v1'));
 const html=await offlineFile(s.pack,s.doc.rooms,p=>fs.promises.readFile(new URL(p,root),'utf8'),p=>fs.promises.readFile(new URL('assets/classic-audio/'+p,root)),()=>{},collection?{collection:built}:{}),dir=fs.mkdtempSync(path.join(os.tmpdir(),'Bowser Jr Offline With Spaces '));
 try{const htmlPath=path.join(dir,'Jr player.html'),projectPath=path.join(dir,'Jr source.qmap.json');fs.writeFileSync(htmlPath,html);fs.writeFileSync(projectPath,JSON.stringify(project));const result=spawnSync(process.execPath,['--experimental-vm-modules',fileURLToPath(new URL('../scripts/check-bowser-jr-offline.mjs',import.meta.url)),htmlPath,projectPath,...(collection?['collection']:[])],{encoding:'utf8',timeout:45000,maxBuffer:1024*1024});assert.equal(result.status,0,result.stderr||result.stdout||String(result.error));const report=JSON.parse(result.stdout);for(const key of ['actualEmbeddedStageExecuted','actualEmbeddedMotorExecuted','actualEmbeddedJrArtExecuted','stateAndEventsMatchEveryTick'])assert.equal(report[key],true,key);assert.equal(report.networkRequests,0);assert.equal(report.headStomps,3);assert.equal(report.realKeyRewards,1);assert.equal(report.score,4000);assert(report.rasterScenes>=7);assert.equal(report.collection,collection);
 }finally{fs.rmSync(dir,{recursive:true,force:true});}
});
