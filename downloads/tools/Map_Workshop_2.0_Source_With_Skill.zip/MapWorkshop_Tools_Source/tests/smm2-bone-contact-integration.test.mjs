import test from 'node:test';
import assert from 'node:assert/strict';
import {blank,validate} from '../atlas/editor-model.mjs';
import {createPlatformStage} from '../atlas/editor-mario-stage.mjs';
import {createPlatformMotor} from '../atlas/editor-mario-motor.mjs';
import {smm2PipeDirection,drawSmm2Pipe} from '../atlas/editor-smm2-art.mjs';

const character={capabilities:['jump'],motion:{width:10,height:14,maxHealth:1}};
const body=q=>({x:q.x,y:q.y,w:q.w,h:q.h});
const overlaps=(a,b)=>a.x+a.w>b.x&&a.x<b.x+b.w&&a.y+a.h>b.y&&a.y<b.y+b.h;

function fixture({size='normal',bonesX=208,withBones=true}={}){
 const d=blank('Native Bone Shell contact regression',640,240),r=d.rooms[0];
 r.setting='Castle';
 r.map.geometry=[{id:'floor',x:0,y:176,w:640,h:64,collision:'solid',material:'castle'}];
 r.map.objects=[{id:'start',kind:'spawn',x:99,y:100,w:10,h:14},{id:'boat',kind:'walker',x:96,y:160,w:16,h:16}];
 r.smm2Mechanics={version:1,startingLives:3,boneShells:[{id:'boat',playingDead:{durationFrames:12,maxFrames:24,dropThroughIds:[]}}]};
 if(withBones){
  const shape=size==='giant'?{w:32,h:32}:{w:16,h:24};
  r.map.objects.push({id:'bones',kind:'walker',x:bonesX,y:176-shape.h,...shape});
  r.marioModules={version:1,itemSources:[],noteBlocks:[],oneWayWalls:[],enemyVariants:{bones:{kind:'dry-bones',size,speed:.01,direction:-1,collapsedHeight:size==='giant'?8:6,collapseFrames:180,recoverFrames:24,bounceSpeed:4.1333,...(size==='giant'?{giantStompResponse:'bounce'}:{})}}};
 }
 validate(d);
 const events=[],s=createPlatformStage({plan:{stage:{entryRoom:r.roomId,entrySpawn:'start',title:d.title},character,rooms:{[r.roomId]:r.map}},motor:createPlatformMotor(),visualRooms:d.rooms,initialState:{lives:3,power:0},autoContinue:false,allowWarp:false,emit:(type,data)=>events.push({type,...data})});
 const step=(frames,input={})=>{for(let f=0;f<frames;f++)s.step(input);return s.view();};
 // The player falls onto the authored shell. No live pose or lifecycle writes.
 for(let f=0;f<100&&!s.view().p.shoeId;f++)step(1);
 assert.equal(s.view().p.shoeId,'boat','ordinary descending contact must board the real shell');
 return {s,events,step};
}

function jumpApproach(h,{brakeAfter=Infinity}={}){
 h.step(30,{x:1,run:true});
 for(let f=0;f<120;f++){
  const before=h.s.view();
  h.step(1,{x:f<brakeAfter?1:-1,run:true,jump:f<20});
  if(h.events.some(e=>e.event==='dry-bones-collapse')||h.events.some(e=>e.event==='hurt'))return before;
 }
 assert.fail('bounded ordinary jump must reach the authored contact');
}

test('playing-dead view uses the same low shell rectangle as the mounted motor',()=>{
 const h=fixture({withBones:false}),before=h.s.view(),x=before.p.x;
 assert.equal(before.p.smm2Shoe.contactBody.h,30);
 for(let f=0;f<6;f++){
  const v=h.step(1,{down:true,x:1,run:true}),q=v.p.smm2Shoe;
  assert.equal(q.playingDead,true);
  assert.equal(q.h,4);
  assert.deepEqual(q.contactBody,body(q),'the hidden rider must not expand the public contact rectangle');
  assert.equal(q.exposedBody.h,0);
  assert.equal(q.y+q.h,176);
  assert.equal(v.p.x,x,'playing dead ignores ordinary walking input');
 }
 const recovered=h.step(1,{jump:true});
 assert.equal(recovered.p.smm2Shoe.playingDead,false);
 assert.equal(recovered.p.shoeId,'boat');
 assert(recovered.p.vy<0);
 assert.equal(recovered.p.vy,recovered.p.smm2Shoe.vy);
});

for(const size of ['normal','giant'])test(`genuine shell sole landing collapses ${size} Dry Bones and keeps motor bounce synchronized`,()=>{
 const h=fixture({size}),before=jumpApproach(h),v=h.s.view(),enemy=v.enemies.find(e=>e.id==='bones'),q=v.p.smm2Shoe;
 assert(before.p.smm2Shoe.y+before.p.smm2Shoe.h<=before.enemies.find(e=>e.id==='bones').y+1.01);
 assert.equal(enemy.dead,false);
 assert.equal(enemy.smm2DryBones.phase,'collapsed');
 assert.equal(enemy.w,size==='giant'?32:16);
 assert.equal(enemy.h,size==='giant'?8:6);
 assert.equal(enemy.y+enemy.h,176);
 assert.equal(q.occupancy,'player');
 assert(v.p.vy<0);
 assert.equal(q.vy,v.p.vy);
 assert.equal(q.y+q.h,before.enemies.find(e=>e.id==='bones').y);
 assert.equal(v.lives,3);
 assert.equal(v.score,0);
 assert.equal(h.events.filter(e=>e.event==='dry-bones-collapse').length,1);
 assert.equal(h.events.find(e=>e.event==='dry-bones-collapse').attack,'bone-shell-stomp');
 assert.equal(h.events.filter(e=>e.event==='enemy-stomp-request').length,1);
 const next=h.step(1,{x:1,run:true});
 assert(next.p.vy<0,'the next frame must retain the actual shell bounce');
 assert.equal(next.p.vy,next.p.smm2Shoe.vy);
});

test('descending shell side contact cannot become a bare-Mario Dry Bones stomp',()=>{
 const h=fixture({bonesX:232}),before=jumpApproach(h),v=h.s.view(),enemy=before.enemies.find(e=>e.id==='bones'),q=before.p.smm2Shoe;
 assert(before.p.vy>0,'the counterexample must enter while descending');
 assert(q.x+q.w<=enemy.x,'the preceding frame is outside the enemy horizontally');
 assert(q.y+q.h>enemy.y+1.01,'the physical sole already lies below the enemy top');
 assert(before.p.y+before.p.h<=enemy.y+7,'the old bare-player test would falsely classify this as a stomp');
 assert.equal(v.enemies.find(e=>e.id==='bones').smm2DryBones.phase,'walking');
 assert.equal(h.events.filter(e=>e.event==='dry-bones-collapse'||e.event==='enemy-stomp-request').length,0);
 assert.equal(h.events.filter(e=>e.event==='hurt').length,1);
 assert.equal(v.p.shoeId,undefined);
 assert.equal(v.lives,3);
});

test('a second genuine descent through a collapsed Dry Bones pile adds no bounce',()=>{
 const h=fixture();
 jumpApproach(h,{brakeAfter:20});
 assert.equal(h.s.view().enemies.find(e=>e.id==='bones').smm2DryBones.phase,'collapsed');
 let crossedPile=0,overlapFrames=0;
 for(let f=0;f<120;f++){
  const before=h.s.view(),enemy=before.enemies.find(e=>e.id==='bones'),shoe=before.p.smm2Shoe;
  const target=enemy.x+(enemy.w-before.p.w)/2;
  // Normal directional input brakes before overshooting the pile on return.
  const v=h.step(1,{x:Math.sign(target-(before.p.x+before.p.vx*10))}),q=v.p.smm2Shoe;
  assert.equal(q?.occupancy,'player');
  assert.equal(v.enemies.find(e=>e.id==='bones').smm2DryBones.phase,'collapsed');
  if(overlaps(q,enemy))overlapFrames++;
  if(shoe.y+shoe.h<=enemy.y+1.01&&q.y+q.h>=enemy.y&&q.x+q.w>enemy.x&&q.x<enemy.x+enemy.w){
   crossedPile++;
   assert(q.vy>=0,'a harmless pile must not initiate another shell bounce');
   assert.equal(v.p.vy,q.vy);
  }
 }
 assert(crossedPile>0,'the ordinary return must cross the real pile top');
 assert(overlapFrames>0,'the shell must genuinely overlap the harmless body');
 assert.equal(h.events.filter(e=>e.event==='enemy-stomp-request').length,1);
 assert.equal(h.events.filter(e=>e.event==='dry-bones-collapse').length,1);
 assert.equal(h.events.filter(e=>e.type==='sound'&&e.event==='stomp').length,1);
 assert.equal(h.events.filter(e=>e.event==='hurt').length,0);
 assert.equal(h.s.view().lives,3);
});

test('a static final hanging pipe renders its measured downward semantic without a fabricated source',()=>{
 const q={id:'final-hanging-pipe',x:3456,y:216,w:32,h:32,collision:'solid',material:'pipe'};
 const r={setting:'Castle',map:{width:3840,height:432,geometry:[q],objects:[]},smm2Mechanics:{version:1},semantics:[{id:q.id,kind:'Pipe',source:{direction:'down'}}],marioModules:{itemSources:[],enemySources:[]}};
 const before=structuredClone({q,r}),translates=[],scales=[];let pixels=0;
 const ctx={save(){},restore(){},beginPath(){},rect(){},clip(){},translate(x,y){translates.push([x,y]);},scale(x,y){scales.push([x,y]);},fillRect(){pixels++;}};
 assert.equal(smm2PipeDirection(q,r),'down');
 assert.equal(drawSmm2Pipe(ctx,q,r),true);
 assert.deepEqual(translates[0],[q.x,q.y+q.h]);
 assert.deepEqual(scales,[[1,-1]],'the mouth must be at the lower end of the hanging body');
 assert(pixels>0,'the measured static pipe must draw real native pixels');
 assert.deepEqual({q,r},before);
 assert.equal(smm2PipeDirection({...q,id:'copy',sourceId:q.id},r),'down');
});
