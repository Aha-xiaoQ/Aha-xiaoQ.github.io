import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {createCanvas} from '@napi-rs/canvas';
import {makeDoorFeatureIcon,drawDoorFeatureIcon,doorFeatureKind,validateDoorFeatureIcons,DOOR_FEATURE_KINDS} from '../atlas/editor-door-feature-art.mjs';
import {completionMarksProject} from './fixtures/completion-marks.mjs';
import {parseProject,validate,History} from '../atlas/editor-model.mjs';
import {drawTile} from '../atlas/editor-art.mjs';
import {requiredCollectionCapabilities} from '../atlas/editor-collection.mjs';
const copy=q=>structuredClone(q),request=feature=>({id:'feature-'+feature,portalId:'entry-portal',feature});
const withIcon=feature=>{const d=completionMarksProject(),r=d.rooms[0];r.decorations.push(makeDoorFeatureIcon(r,request(feature)));return d;};
const pixels=c=>c.getContext('2d').getImageData(0,0,c.width,c.height).data;
test('all five door pictograms use distinct native24px rasters entirely inside their saved frame',()=>{
 const unique=new Set();for(const feature of DOOR_FEATURE_KINDS){const d=withIcon(feature),q=d.rooms[0].decorations.at(-1),c=createCanvas(320,240);assert.equal(doorFeatureKind(q),feature);drawDoorFeatureIcon(c.getContext('2d'),q);const p=pixels(c);let opaque=0;for(let y=0;y<240;y++)for(let x=0;x<320;x++)if(p[(y*320+x)*4+3]){opaque++;assert(x>=q.x&&x<q.x+24&&y>=q.y&&y<q.y+24);}assert(opaque>300);unique.add(Buffer.from(p).toString('base64'));}assert.equal(unique.size,5);
});
test('feature signs are centered above a real door and separated from its actual completion indicator',()=>{
 const d=withIcon('crane'),r=d.rooms[0],q=r.decorations.at(-1),p=r.map.objects.find(q=>q.id==='entry-portal');assert.equal(q.x+12,p.x+p.w/2);assert.equal(q.y+q.h,p.y-26);assert.equal(p.y-18-(q.y+q.h),8);assert(!q.collision&&!q.motion&&!q.nativeScenery);validate(d);
});
test('unknown styles, physical behavior and arbitrary resize fail full author import before rendering',()=>{
 for(const mutate of [q=>q.smm2Art='authored-door-feature-missing',q=>q.material='ground',q=>q.w=32,q=>q.h=16,q=>q.x=-1,q=>q.y=225,q=>q.collision='solid',q=>q.motion={axis:'x',min:0,max:100,speed:1}]){const d=withIcon('snake');mutate(d.rooms[0].decorations.at(-1));assert.throws(()=>validate(d));assert.throws(()=>parseProject(JSON.stringify(d)));}
 const unrelated=completionMarksProject();unrelated.rooms[0].decorations=[{id:'other',x:16,y:120,w:32,h:16,material:'decoration',smm2Art:'unrelated-background'}];assert(validateDoorFeatureIcons(unrelated.rooms[0]));
});
test('author helper needs a real portal, rejects unsafe or extra request shapes and mutates nothing',()=>{
 const d=completionMarksProject(),before=copy(d),r=d.rooms[0];for(const q of [{...request('jr'),portalId:'start'},{...request('jr'),feature:'missing'},{...request('jr'),id:'constructor'},{...request('jr'),extra:true},Object.assign(Object.create({}),request('jr'))])assert.throws(()=>makeDoorFeatureIcon(r,q));const q=request('jr');q[Symbol('hidden')]=1;assert.throws(()=>makeDoorFeatureIcon(r,q));assert.deepEqual(d,before);
});
test('actual native History roundtrip and undo/redo preserve art without modifying Pink progress or portal behavior',()=>{
 const h=new History(completionMarksProject()),before=copy(h.doc);h.change(d=>d.rooms[0].decorations.push(makeDoorFeatureIcon(d.rooms[0],request('shell'))));assert.deepEqual(parseProject(JSON.stringify(h.doc)),h.doc);assert.deepEqual(h.doc.rooms[0].smm2Mechanics.completionMarks,before.rooms[0].smm2Mechanics.completionMarks);assert.deepEqual(h.doc.rooms[0].map.objects,before.rooms[0].map.objects);h.undo();assert.deepEqual(h.doc,before);h.redo();assert.equal(h.doc.rooms[0].decorations.length,1);
 const saved=JSON.stringify(h.doc),stack=h.undoStack.length;assert.throws(()=>h.change(d=>d.rooms[0].decorations[0].w=32));assert.equal(JSON.stringify(h.doc),saved);assert.equal(h.undoStack.length,stack);
});
test('shared world painter equals the native icon pixels and restores drawing state',()=>{
 const d=withIcon('shooter'),q=d.rooms[0].decorations.at(-1),before=copy(d),a=createCanvas(320,240),b=createCanvas(320,240),c=a.getContext('2d');c.globalAlpha=.75;const priorAlpha=c.globalAlpha;c.fillStyle='#ff00ff';drawTile(c,q,d.rooms[0]);const r=b.getContext('2d');r.globalAlpha=.75;drawDoorFeatureIcon(r,q);assert.deepEqual(pixels(a),pixels(b));assert.equal(c.globalAlpha,priorAlpha);c.fillRect(0,0,1,1);assert.deepEqual([...c.getImageData(0,0,1,1).data],[255,0,255,191]);assert.deepEqual(d,before);assert.equal(drawDoorFeatureIcon(c,{...q,smm2Art:'unrelated'}),false);assert(drawDoorFeatureIcon(c,{...q,hidden:true}));
});
test('updated helper coordinates follow a moved door while the saved old pictogram remains explicit author data',()=>{
 const d=withIcon('jr'),r=d.rooms[0],old=copy(r.decorations[0]);r.map.objects.find(q=>q.id==='entry-portal').x+=64;const moved=makeDoorFeatureIcon(r,request('jr'));assert.equal(moved.x-old.x,64);assert.deepEqual(r.decorations[0],old);r.decorations[0]=moved;assert.deepEqual(parseProject(JSON.stringify(d)),d);
});
test('collection declares display capability and offline exporter contains the same icon renderer dependency',async()=>{
 const d=withIcon('crane');assert(requiredCollectionCapabilities(d).includes('authored-door-feature-signs-v1'));assert(!requiredCollectionCapabilities(completionMarksProject()).includes('authored-door-feature-signs-v1'));const source=await fs.readFile(new URL('../atlas/editor-offline.mjs',import.meta.url),'utf8');assert(source.includes("'editor-door-feature-art.mjs'"));
});
