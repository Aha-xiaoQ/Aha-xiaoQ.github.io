import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createPlatformMotor} from '../atlas/editor-mario-motor.mjs';
import {createPlatformStage} from '../atlas/editor-mario-stage.mjs';
import {createSMM2Terrain,withSMM2TerrainContact} from '../atlas/editor-smm2-terrain.mjs';
import {createPlatformMotor as createBaselineMotor} from './native-baseline/editor-mario-motor.mjs';

const character={capabilities:['jump'],motion:{width:10,height:14,maxHealth:1}};
const donut={id:'falling-donut',x:96,y:120.35,w:32,h:16,delayFrames:2,gravity:.73,maxFallSpeed:4.2,triggerPolicy:'player',resetPolicy:'leave-before-drop',collision:'oneway'};
const lowerFloor=collision=>({id:'lower-floor',x:72,y:157.91,w:192,h:16,collision,material:'stone'});
const close=(a,b)=>assert.ok(Math.abs(a-b)<1e-7,`${a} != ${b}`);
function room(solids=[]){return {roomId:'donut-transfer-fixture',setting:'Overworld',markers:[],decorations:[],map:{width:384,height:288,tileSize:16,geometry:solids,objects:[{id:'start',kind:'spawn',x:100,y:donut.y-14,w:10,h:14}]},smm2Mechanics:{version:1,donuts:[{...donut}]}};}
function harness({big=false,solids=[],donutCollision='oneway'}={}){
 const r=room(solids);r.smm2Mechanics.donuts[0].collision=donutCollision;
 const terrain=createSMM2Terrain(r),native=createPlatformMotor(),p={...native.create(character,{x:100,y:donut.y-(big?28:14)}),id:'player',kind:'player',h:big?28:14,power:big?1:0,grounded:true,support:donut.id};
 let calls=0,tick=0;
 const motor=withSMM2TerrainContact({...native,step(...args){calls++;return native.step(...args);}},terrain);
 const h={r,terrain,native,p,begin(){terrain.beginFrame({tick:++tick,actors:[p]});},move(input={}){const events=motor.step(p,input,character,{width:r.map.width,solids});terrain.finishFrame({tick,actors:[p]});assert.equal(calls,tick,'exactly one native motor call per frame');return events;},step(input={}){h.begin();return h.move(input);},get tick(){return tick;}};
 return h;
}

for(const big of [false,true])for(const collision of ['solid','oneway'])test(`${big?'Big 28px':'Small 14px'} falling Donut rider transfers to nonaligned ${collision} floor and stands/walks normally`,()=>{
 const floor=lowerFloor(collision),h=harness({big,solids:[floor]}),author=JSON.stringify(h.r);let crossing=false;
 for(let n=0;n<60&&h.p.support!==floor.id;n++){
  h.begin();const live=h.terrain.geometry([])[0],projected=h.terrain.motorGeometry([floor],h.p).find(q=>q.id===donut.id);
  if(projected.dy<live.dy-1e-7){crossing=true;close(projected.dy,floor.y-h.p.y-h.p.h);assert(live.y>floor.y);close(h.terrain.actorGeometry([floor],h.p).find(q=>q.id===donut.id).dy,live.dy);}
  h.move();assert(h.p.y+h.p.h<=floor.y+1e-7,'carrier cannot tunnel the rider through the floor');
 }
 assert(crossing,'last carrier displacement is only partially consumed');assert.equal(h.p.support,floor.id);assert(h.p.grounded);close(h.p.y+h.p.h,floor.y);assert.equal(h.p.vy,0);assert.equal(h.p.h,big?28:14);
 const landedDonut=h.terrain.view().donuts[0].y;
 for(let n=0;n<20;n++){h.step();assert.equal(h.p.support,floor.id);close(h.p.y+h.p.h,floor.y);}
 const startX=h.p.x;for(let n=0;n<45;n++){h.step({x:1});assert.equal(h.p.support,floor.id);close(h.p.y+h.p.h,floor.y);}
 assert(h.p.x>startX+30);assert.equal(h.p.vx,1.5);assert(h.terrain.view().donuts[0].y>landedDonut);assert.equal(h.terrain.view().donuts[0].phase,'removed','Donut falls independently through and out of the room');assert.equal(JSON.stringify(h.r),author,'neither floor nor authored Donut is changed');
});

for(const big of [false,true])for(const collision of ['solid','oneway'])test(`${big?'Big':'Small'} native jump on the Donut/floor crossing preserves events, buffering and acceleration (${collision})`,()=>{
 const floor=lowerFloor(collision),h=harness({big,solids:[floor]});let jumped=false;
 for(let n=0;n<60&&!jumped;n++){
  h.begin();const live=h.terrain.geometry([])[0],projected=h.terrain.motorGeometry([floor],h.p).find(q=>q.id===donut.id);
  if(projected.dy<live.dy-1e-7){
   const expected={...h.p,y:floor.y-h.p.h,support:floor.id},input={x:1,run:true,jumpPressed:true,jump:true},events=h.native.step(expected,input,character,{width:h.r.map.width,solids:h.terrain.actorGeometry([floor],h.p)});
   assert.deepEqual(h.move(input),events);assert.deepEqual(events,['jump']);assert.deepEqual(h.p,expected);assert.equal(h.p.grounded,false);assert.equal(h.p.support,null);assert(h.p.vy<0);jumped=true;
  }else h.move();
 }
 assert(jumped);
});

test('no floor preserves the full native falling Donut carry and eventual unsupported fall',()=>{
 const h=harness();let removed=false;
 for(let n=0;n<80;n++){
  h.begin();const expected={...h.p},solids=h.terrain.actorGeometry([],h.p),events=h.native.step(expected,{},character,{width:h.r.map.width,solids});assert.deepEqual(h.move(),events);assert.deepEqual(h.p,expected);
  const q=h.terrain.view().donuts[0];if(q.phase==='falling')close(h.p.y+h.p.h,q.y);if(q.phase==='removed')removed=true;
 }
 assert(removed);assert.equal(h.p.support,null);assert.equal(h.p.grounded,false);assert(h.p.y>h.r.map.height);
});

test('the carry sweep picks the first actual static floor and excludes hidden, moving, off-span and embedded faces',()=>{
 const floor=lowerFloor('solid'),h=harness({solids:[floor]});let pending=false;
 for(let n=0;n<60&&!pending;n++){h.begin();const live=h.terrain.geometry([])[0];pending=h.terrain.motorGeometry([floor],h.p).find(q=>q.id===donut.id).dy<live.dy-1e-7;if(!pending)h.move();}
 assert(pending);const bottom=h.p.y+h.p.h,live=h.terrain.geometry([])[0],candidates=[
  {...floor,id:'hidden',y:bottom+.1,hidden:true},
  {...floor,id:'moving',y:bottom+.2,dy:.1},
  {...floor,id:'standable',y:bottom+.3,smm2StandableActor:true},
  {...floor,id:'off-span',x:h.p.x+h.p.w,y:bottom+.4},
  {...floor,id:'embedded',y:bottom-.1},
  {...floor,id:'background',y:bottom+.5,collision:'none'},
  {...floor,id:'later-floor',y:floor.y+.1},floor
 ];
 const before={...h.p},projected=h.terrain.motorGeometry(candidates,h.p).find(q=>q.id===donut.id);close(projected.dy,floor.y-bottom);assert.deepEqual(h.p,before);close(h.terrain.geometry([])[0].dy,live.dy);
 const excluded=candidates.slice(0,6);close(h.terrain.motorGeometry(excluded,h.p).find(q=>q.id===donut.id).dy,live.dy);h.move();assert.equal(h.p.support,floor.id);
});

test('empty/absent terrain preserves the frozen native motor through ordinary walk, run and held/buffered jump',()=>{
 const solids=[{id:'floor',x:0,y:224,w:384,h:64,collision:'solid'},{id:'wall',x:300,y:160,w:16,h:64,collision:'solid'}],world={width:384,solids};
 for(const mechanics of [undefined,{version:1,donuts:[],slopes:[],seesaws:[]}]){
  const r=room(solids);r.smm2Mechanics=mechanics;const native=createPlatformMotor(),motor=withSMM2TerrainContact(native,createSMM2Terrain(r)),baseline=createBaselineMotor(),actual=native.create(character,{x:100,y:210}),expected=baseline.create(character,{x:100,y:210});assert.equal(motor,native);
  for(let n=0;n<180;n++){const input={x:n<100?1:-1,run:n>40,jump:n>=30&&n<47||n>=95&&n<116,jumpPressed:n===30||n===95};assert.deepEqual(motor.step(actual,input,character,world),baseline.step(expected,input,character,world));assert.deepEqual(actual,expected);}
 }
});

for(const branch of ['side','underside','ascending','unrelated-support'])test(`falling Donut boundary leaves the native ${branch} branch unchanged`,()=>{
 const floor=lowerFloor('solid'),solids=['ascending','unrelated-support'].includes(branch)?[floor]:[],h=harness({solids,donutCollision:'solid'});let pending=false;
 if(branch==='ascending')for(let n=0;n<60&&!pending;n++){
  h.begin();const live=h.terrain.geometry([])[0],projected=h.terrain.motorGeometry(solids,h.p).find(q=>q.id===donut.id);pending=projected.dy<live.dy-1e-7;if(!pending)h.move();
 }else for(let n=0;n<10;n++)h.step();
 const q=h.terrain.view().donuts[0];
 if(branch==='side')Object.assign(h.p,{x:86,y:q.y+5,vy:0,vx:1.5,grounded:false,support:null});
 if(branch==='underside')Object.assign(h.p,{x:100,y:q.y+q.h+6,vy:-4,grounded:false,support:null});
 if(branch==='ascending'){assert(pending);Object.assign(h.p,{vy:-4});}
 if(branch==='unrelated-support')Object.assign(h.p,{y:floor.y-14,vy:0,grounded:true,support:floor.id});
 if(!pending)h.begin();const actual=h.terrain.actorGeometry(solids,h.p);assert.deepEqual(h.terrain.motorGeometry(solids,h.p),actual);
 const expected={...h.p},input={x:1,jump:true},events=h.native.step(expected,input,character,{width:h.r.map.width,solids:actual});assert.deepEqual(h.move(input),events);assert.deepEqual(h.p,expected);
 if(branch==='side'){assert.equal(h.p.x,86);assert.equal(h.p.vx,0);}
 if(branch==='underside'){assert.equal(h.p.headHit,donut.id);assert.equal(h.p.vy,.5);}
});

for(const big of [false,true])test(`actual Stage landing and death retry reset falling Donuts after ${big?'Big':'Small'} traversal`,()=>{
 const floor=lowerFloor('solid'),r=room([floor]);r.contraptions={version:1,doors:[]};const events=[],stage=createPlatformStage({plan:{stage:{entryRoom:r.roomId,entrySpawn:'start',title:'Neutral falling Donut transfer'},character,rooms:{[r.roomId]:r.map}},visualRooms:[r],motor:createPlatformMotor(),initialState:{lives:3,power:big?1:0},autoContinue:false,manualDeath:true,allowWarp:false,emit:(type,data)=>events.push({type,...data})});
 let view=stage.view();for(let n=0;n<80&&view.p.support!==floor.id;n++){stage.step({});view=stage.view();}
 assert.equal(view.p.support,floor.id);close(view.p.y+view.p.h,floor.y);assert.equal(view.p.h,big?28:14);assert.equal(view.lives,3);
 for(let n=0;n<240&&!view.p.dying;n++){stage.step({x:1});view=stage.view();}
 assert(view.p.dying,'walk naturally off the finite real floor into the pit');assert.equal(view.lives,2);assert.equal(events.filter(e=>e.type==='sound'&&e.event==='death').length,1);
 assert(stage.continueFromCurrent());view=stage.view();assert.equal(view.lives,2);assert.equal(view.p.dying,undefined);assert.equal(view.smm2Mechanics.donuts[0].phase,'idle');close(view.smm2Mechanics.donuts[0].y,donut.y);assert.equal(view.smm2Mechanics.donuts[0].dy,0);
 for(let n=0;n<80&&view.p.support!==floor.id;n++){stage.step({});view=stage.view();}
 assert.equal(view.p.support,floor.id);close(view.p.y+view.p.h,floor.y);assert.equal(view.lives,2);assert.equal(events.filter(e=>e.event==='donut-drop').length,2);
});
