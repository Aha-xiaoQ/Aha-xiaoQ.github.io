import assert from 'node:assert/strict';
import {test} from 'node:test';
import {blank,History,parseProject} from '../atlas/editor-model.mjs';
import {createAquaticController,validateAquaticRoom,AQUATIC_PHYSICS_DEFAULTS} from '../atlas/editor-aquatic.mjs';
import {mountAquaticTools,upsertAquaticCurrent,upsertAquaticFishSource,setAquaticBlooper,aquaticCurrentOverlays} from '../atlas/editor-aquatic-tools.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';
const copy=value=>JSON.parse(JSON.stringify(value));
function fixture(){const d=blank('Aquatic reusable fixture',640,240),r=d.rooms[0];r.setting='Underwater';r.underwater=true;r.map.geometry=[{id:'floor',x:0,y:208,w:640,h:32,collision:'solid',material:'ground'},{id:'wall',x:288,y:32,w:32,h:176,collision:'solid',material:'stone'}];r.map.objects=[{id:'start',kind:'spawn',x:32,y:64,w:10,h:14},{id:'blooper-a',kind:'walker',x:352,y:120,w:16,h:16}];r.aquatic={version:1};return d;}
const player=(x=100,y=100)=>({x,y,w:10,h:14,vx:0,vy:0,grounded:false});
const source=(extras={})=>({id:'fish-source',startX:0,endX:640,intervalFrames:1,...extras});
const body=(r,c)=>c.decorateEnemy({...copy(r.map.objects.find(q=>q.id==='blooper-a')),homeX:352,homeY:120,age:0,dead:false});

test('omitted aquatic spec preserves the native path and opt-in requires the water setting',()=>{
 const r=fixture().rooms[0];delete r.aquatic;assert.equal(createAquaticController(r),null);assert.doesNotThrow(()=>validateAquaticRoom(r));r.aquatic={version:1};r.setting='Overworld';assert.throws(()=>validateAquaticRoom(r),/Underwater/);r.setting='Underwater';r.underwater=false;assert.throws(()=>validateAquaticRoom(r),/Underwater/);delete r.underwater;assert.doesNotThrow(()=>validateAquaticRoom(r));
});

test('strict extension validation rejects unknowns, malformed data, unsafe IDs and bad targets atomically',()=>{
 const valid=fixture().rooms[0];
 const mutations=[r=>r.aquatic.version=2,r=>r.aquatic.extra=1,r=>r.aquatic.physics={gravity:NaN},r=>r.aquatic.physics={groundCap:3},r=>r.aquatic.physics={strokeFrames:1.5},r=>r.aquatic.currents=[{id:'bad',x:600,y:144,w:64,h:96,centerX:632}],r=>r.aquatic.currents=[{id:'floor',x:64,y:144,w:64,h:96,centerX:96}],r=>r.aquatic.currents=[{id:'bad',x:64,y:144,w:64,h:96,centerX:32}],r=>r.aquatic.fishSources=[source({maxAlive:4})],r=>r.aquatic.fishSources=[source({yCandidates:[230]})],r=>r.aquatic.fishSources=[source({seed:-1})],r=>r.aquatic.fishSources=[source({grayWeight:0,redWeight:0})],r=>r.aquatic.fishSources=[source({startX:640,endX:600})],r=>r.aquatic.fishSources=[source({unknown:1})],r=>r.aquatic.enemyProfiles={absent:{kind:'blooper'}},r=>r.aquatic.enemyProfiles={start:{kind:'blooper'}},r=>r.aquatic.enemyProfiles={'blooper-a':{kind:'sine'}},r=>r.aquatic.enemyProfiles={'blooper-a':{kind:'blooper',top:130}},r=>r.aquatic.enemyProfiles=JSON.parse('{"__proto__":{"kind":"blooper"}}'),r=>{r.aquatic.enemyProfiles={'blooper-a':{kind:'blooper'}};r.marioModules={enemyVariants:{'blooper-a':{kind:'vertical-koopa'}}};}];
 for(const mutate of mutations){const r=copy(valid);mutate(r);const before=JSON.stringify(r);assert.throws(()=>validateAquaticRoom(r));assert.equal(JSON.stringify(r),before);}
 const r=copy(valid),before=JSON.stringify(r);assert.throws(()=>upsertAquaticCurrent(r,null,{x:600,y:144,w:64,h:96,centerX:632}));assert.equal(JSON.stringify(r),before);
});

test('flow sampling is pure, pulls toward the center, adds downforce and weakens only the stroke',()=>{
 const r=fixture().rooms[0];r.aquatic.currents=[{id:'pit-a',x:64,y:144,w:112,h:96,centerX:120,pull:.02,down:.03,strokeMultiplier:.7},{id:'pit-b',x:96,y:144,w:64,h:96,centerX:128,pull:.01,down:.02,strokeMultiplier:.8}];const c=createAquaticController(r),p=player(100,176),before=copy(p),initial=copy(c.view());
 const a=c.waterContext(p,{tick:20,input:{jump:true}}),b=c.waterContext(p,{tick:20,input:{jump:false}});assert.deepEqual(a,b);assert.deepEqual(p,before);assert.deepEqual(c.view(),initial);assert.equal(a.flowX,.03);assert.equal(a.flowY,.05);assert.equal(a.strokeSpeed,1.75);assert.equal(a.horizontalCap,1.5);assert.equal(a.groundCap,.75);assert.deepEqual(a.currentIds,['pit-a','pit-b']);
 assert(c.waterContext(player(150,176)).flowX<0);const center=c.waterContext(player(115,200));assert.equal(center.flowX,.01);const outside=c.waterContext(player(100,64));assert.equal(outside.flowX,0);assert.equal(outside.flowY,0);assert.equal(outside.strokeSpeed,AQUATIC_PHYSICS_DEFAULTS.strokeSpeed);
});

test('source activates by camera-left region, spawns actual offscreen bodies and stops at the exclusive end',()=>{
 const r=fixture().rooms[0];r.aquatic.fishSources=[source({startX:100,endX:200})];const c=createAquaticController(r),p=player(600),enemies=[];
 assert.deepEqual(c.spawnEnemies({player:p,cam:99,enemies,tick:1}),[]);const emitted=c.spawnEnemies({player:p,cam:100,viewportWidth:256,enemies,tick:2});assert.equal(emitted.length,1);const e=emitted[0];assert.equal(e.kind,'walker');assert.equal(e.type,'cheepcheep');assert.equal(e.x,388);assert(e.x>100+256);assert.equal(e.w,16);assert.equal(e.h,16);assert.equal(e.aquaticSource,'fish-source');assert.equal(e.hp,1);assert.equal(e.dead,false);assert.deepEqual(c.spawnEnemies({player:p,cam:100,enemies,tick:2}),[]);
 assert.deepEqual(c.spawnEnemies({player:p,cam:200,enemies,tick:3}),[]);assert.equal(c.view().fishSources[0].active,false);
});

test('global and per-source caps count real living entries; kills replenish with new ordinals',()=>{
 const r=fixture().rooms[0];r.aquatic.maxFishAlive=3;r.aquatic.fishSources=[source({maxAlive:2}),source({id:'fish-other',maxAlive:2,seed:5})];const c=createAquaticController(r),p=player(),enemies=[];
 for(let tick=1;tick<=4;tick++)enemies.push(...c.spawnEnemies({player:p,cam:0,enemies,tick}));assert.equal(enemies.length,3);assert.equal(enemies.filter(e=>e.aquaticSource==='fish-source').length,2);const rng=copy(c.view().fishSources);assert.deepEqual(c.spawnEnemies({player:p,cam:0,enemies,tick:5}),[]);assert.deepEqual(c.view().fishSources.map(s=>s.rng),rng.map(s=>s.rng));
 const victim=enemies.find(e=>e.aquaticSource==='fish-source');victim.dead=true;const next=c.spawnEnemies({player:p,cam:0,enemies,tick:6});assert.equal(next.length,1);assert.equal(next[0].aquaticSource,'fish-source');assert.notEqual(next[0].id,victim.id);enemies.push(...next);assert.equal(enemies.filter(e=>!e.dead).length,3);
 const ownCapRoom=fixture().rooms[0];ownCapRoom.aquatic.fishSources=[source({maxAlive:1})];const ownCap=createAquaticController(ownCapRoom),live=ownCap.spawnEnemies({player:p,tick:1});assert.equal(ownCap.spawnEnemies({player:p,enemies:live,tick:2}).length,0);
});

test('fish palette weights use native source variants and default gray/red speeds differ',()=>{
 for(const [grayWeight,redWeight,variant,speed]of [[1,0,'gray',.25],[0,1,'red',.5]]){const r=fixture().rooms[0];r.aquatic.fishSources=[source({grayWeight,redWeight})];const c=createAquaticController(r),e=c.spawnEnemies({player:player(),tick:1})[0];assert.equal(e.source.aquaticVariant,variant);assert.equal(e.source.gray,variant==='gray');assert.equal(e.source.red,variant==='red');assert.equal(e.vx,-speed);const x=e.x;c.stepEnemy(e,{player:player(),tick:1,geometry:r.map.geometry});assert.equal(e.x,x-speed);}
 const r=fixture().rooms[0];r.aquatic.fishSources=[source({seed:8})];const c=createAquaticController(r),seen=new Set();for(let tick=1;tick<=32;tick++){const emitted=c.spawnEnemies({player:player(),tick});seen.add(emitted[0].source.aquaticVariant);}assert.deepEqual([...seen].sort(),['gray','red']);
});

test('finite source budgets, delays and tick gaps advance one active call and reset reproducibly',()=>{
 const r=fixture().rooms[0];r.aquatic.fishSources=[source({seed:1234,initialDelayFrames:2,intervalFrames:2,maxEmissions:2})];const c=createAquaticController(r),p=player();
 assert.equal(c.spawnEnemies({player:p,tick:1}).length,0);assert.equal(c.spawnEnemies({player:p,tick:1}).length,0);assert.equal(c.view().fishSources[0].clock,1);assert.equal(c.spawnEnemies({player:p,tick:999}).length,0);assert.equal(c.view().fishSources[0].clock,0);const first=c.spawnEnemies({player:p,tick:1000})[0];assert.equal(c.spawnEnemies({player:p,tick:1001}).length,0);const second=c.spawnEnemies({player:p,tick:1002})[0];assert.notEqual(first.id,second.id);for(let n=1003;n<1020;n++)assert.equal(c.spawnEnemies({player:p,tick:n}).length,0);
 c.reset();assert.equal(c.view().fishSources[0].emitted,0);assert.equal(c.view().fishSources[0].rng,1234);c.spawnEnemies({player:p,tick:1});c.spawnEnemies({player:p,tick:999});assert.deepEqual(c.spawnEnemies({player:p,tick:1000})[0],first);
});

test('fish body moves through actual terrain, only selected slot drifts, and repeated steps are idempotent',()=>{
 const r=fixture().rooms[0];r.aquatic.fishSources=[source({yCandidates:[96],grayWeight:1,redWeight:0,driftRange:2,driftSpeed:.25})];const c=createAquaticController(r),p=player(),enemies=[];for(let tick=1;tick<=3;tick++)enemies.push(...c.spawnEnemies({player:p,cam:0,enemies,tick}));
 for(const e of enemies){const x=e.x;c.stepEnemy(e,{player:p,cam:0,tick:10,geometry:r.map.geometry});assert.equal(e.x,x-.25);assert(e.x+e.w>288&&e.x<320,'fish overlaps the real wall and continues through it');const snapshot=copy(e);c.stepEnemy(e,{player:p,cam:0,tick:10,geometry:r.map.geometry});assert.deepEqual(e,snapshot);}
 assert.equal(enemies[0].y,96);assert.equal(enemies[1].y,96);assert.notEqual(enemies[2].y,96);for(let tick=11;tick<150;tick++){c.stepEnemy(enemies[2],{player:p,cam:0,tick});assert(enemies[2].y>=94&&enemies[2].y<=98);}
 const e=enemies[0];for(let tick=11;tick<=1000;tick++)c.stepEnemy(e,{player:p,cam:0,tick});assert.equal(e.dead,false,'no lifetime removal');for(let tick=1001;!e.dead&&tick<1500;tick++)c.stepEnemy(e,{player:p,cam:0,tick});assert.equal(e.dead,true);assert(e.x+e.w<-32,'departure happens only after the actual left passage');
});

test('Blooper near-view activation, diagonal pursuit, deceleration and floating are real body phases',()=>{
 const r=fixture().rooms[0];r.aquatic.enemyProfiles={'blooper-a':{kind:'blooper',pulseFrames:3,decelFrames:2,floatFrames:2,pulseX:1,pulseY:1,deceleration:.5,floatSpeed:1,top:32,bottom:200}};const events=[],c=createAquaticController(r,{emit:(type,data)=>events.push({type,...data})}),e=body(r,c),left=player(100,10);
 c.stepEnemy(e,{player:left,cam:0,viewportWidth:256,tick:1,geometry:r.map.geometry});assert.equal(e.x,352);assert.equal(e.y,120);assert.equal(e.aquaticActive,false);
 c.stepEnemy(e,{player:left,cam:80,viewportWidth:256,tick:2,geometry:r.map.geometry});assert.equal(e.x,351);assert.equal(e.y,119);assert.equal(e.aquaticPhase,'pulse');const once=copy(e);c.stepEnemy(e,{player:left,cam:80,tick:2});assert.deepEqual(e,once);
 c.stepEnemy(e,{player:left,cam:80,tick:1000});assert.equal(e.x,350,'tick gap advances one frame');c.stepEnemy(e,{player:left,cam:80,tick:1001});assert.equal(e.aquaticPhase,'decelerate');const upward=e.vy;c.stepEnemy(e,{player:left,cam:80,tick:1002});assert(e.vy>upward);assert(e.vy<=0);c.stepEnemy(e,{player:left,cam:80,tick:1003});assert.equal(e.aquaticPhase,'float');
 const right=player(500,10),floatY=e.y;let tick=1004;while(e.aquaticPhase==='float'&&tick<1040)c.stepEnemy(e,{player:right,cam:80,tick:tick++});assert(e.y>floatY);assert.equal(e.aquaticPhase,'pulse');assert(e.vx>0,'a later pulse tracks the new player side');assert.equal(events.filter(q=>q.event==='blooper-activated').length,1);assert.equal(events.filter(q=>q.event==='blooper-pulse').length,2);
});

test('Blooper ignores solid/coral terrain and honors authored body-top bounds',()=>{
 const r=fixture().rooms[0];r.map.objects.find(q=>q.id==='blooper-a').x=304;r.aquatic.enemyProfiles={'blooper-a':{kind:'blooper',top:112,bottom:132,pulseFrames:20,decelFrames:8,floatFrames:4}};const c=createAquaticController(r),e=c.decorateEnemy({...copy(r.map.objects[1]),homeX:304,homeY:120,dead:false});let wentUp=false,wentDown=false,lastY=e.y;
 for(let tick=1;tick<=300;tick++){c.stepEnemy(e,{player:player(280,180),cam:80,tick,geometry:r.map.geometry});assert(e.y>=112&&e.y<=132);wentUp||=e.y<lastY;wentDown||=e.y>lastY;lastY=e.y;assert.equal(e.grounded,false);assert.equal(e.support,null);}assert(wentUp&&wentDown);assert(e.x<304,'an overlapped solid does not block its horizontal pursuit');
});

test('authored six Blooper IDs remain native actors; room policy forbids all ordinary stomps and gives aquatic fire points',()=>{
 const r=fixture().rooms[0];r.map.width=3072;const positions=[[352,184],[736,152],[880,168],[1328,136],[1504,56],[1680,184]];r.map.objects=r.map.objects.filter(q=>q.kind!=='walker');r.aquatic.enemyProfiles={};for(let i=0;i<positions.length;i++){const [x,y]=positions[i],id='blooper-'+i;r.map.objects.push({id,kind:'walker',x,y,w:16,h:16});r.aquatic.enemyProfiles[id]={kind:'blooper',bottom:208};}const c=createAquaticController(r),enemies=r.map.objects.filter(q=>q.kind==='walker').map(q=>c.decorateEnemy(copy(q)));assert.equal(enemies.length,6);assert.equal(enemies.filter(e=>e.type==='blooper').length,6);assert(enemies.every(e=>c.disallowStomp(e)&&c.firePoints(e)===200));assert.equal(c.disallowStomp({id:'land-goomba',type:'goomba',kind:'walker'}),true);assert.equal(c.firePoints({id:'land-goomba',type:'goomba'}),undefined);assert.equal(c.stepEnemy({id:'unknown',type:'walker'},{tick:1}),false);assert.equal(c.disallowStomp(null),false);
 const e=enemies[0];c.stepEnemy(e,{player:player(),cam:200,tick:1});c.reset();assert.equal(c.view().enemies.length,0);const fresh=c.decorateEnemy(copy(r.map.objects.find(q=>q.id===e.id)));c.stepEnemy(fresh,{player:player(),cam:200,tick:1});assert.equal(fresh.aquaticPhase,'pulse');assert.equal(fresh.x,e.x);assert.equal(fresh.y,e.y);
});

test('actual aquatic controls add/edit/remove all modules with History, failed-edit rollback, refresh and import',()=>{
 const ui=installSimulatedPlayDom();try{
  const d=fixture();delete d.rooms[0].aquatic;d.rooms[0].setting='Overworld';d.rooms[0].underwater=false;const h=new History(d),parent=ui.document.createElement('aside'),reports=[],room=()=>h.doc.rooms[0],tools=mountAquaticTools({parent,room,change:fn=>h.change(fn),report:s=>reports.push(s)}),get=id=>parent.querySelector('[data-aquatic-control="'+id+'"]');
  get('physics-groundCap').value='.5';get('physics-apply').click();assert.equal(room().aquatic.physics.groundCap,.5);assert.equal(room().setting,'Underwater');assert.equal(room().underwater,true);h.undo();tools.refresh();assert.equal(room().setting,'Overworld');assert.equal(room().aquatic,undefined);h.redo();tools.refresh();assert.equal(get('physics-groundCap').value,.5);
  get('current-x').value='64';get('current-y').value='144';get('current-w').value='112';get('current-h').value='96';get('current-centerX').value='120';get('current-id').value='custom-current';get('current-add').click();assert.equal(room().aquatic.currents[0].id,'custom-current');assert.equal(tools.currentOverlays()[0].editorOnly,true);assert.deepEqual(tools.currentOverlays(),aquaticCurrentOverlays(room()));
  get('current-id').value='renamed-current';get('current-pull').value='.03';get('current-apply').click();assert.equal(room().aquatic.currents[0].id,'renamed-current');assert.equal(room().aquatic.currents[0].pull,.03);
  const before=JSON.stringify(h.doc);get('current-centerX').value='900';get('current-apply').click();assert.equal(JSON.stringify(h.doc),before);assert.equal(reports.length,1);assert.equal(get('current-centerX').value,120);
  get('source-id').value='custom-fish';get('source-startX').value='96';get('source-endX').value='480';get('source-seed').value='22';get('source-maxEmissions').value='7';get('source-yCandidates').value='48,96,144';get('source-redWeight').value='3';get('source-add').click();assert.equal(room().aquatic.fishSources[0].id,'custom-fish');assert.deepEqual(room().aquatic.fishSources[0].yCandidates,[48,96,144]);
  get('source-id').value='renamed-fish';get('source-maxEmissions').value='';get('source-driftRange').value='8';get('source-apply').click();assert.equal(room().aquatic.fishSources[0].id,'renamed-fish');assert.equal(room().aquatic.fishSources[0].maxEmissions,null);assert.equal(room().aquatic.fishSources[0].driftRange,8);
  get('blooper-pulseFrames').value='36';get('blooper-bottom').value='192';get('blooper-apply').click();assert.equal(room().aquatic.enemyProfiles['blooper-a'].pulseFrames,36);assert.equal(room().aquatic.enemyProfiles['blooper-a'].bottom,192);
  const imported=parseProject(JSON.stringify(h.doc));assert.deepEqual(imported.rooms[0].aquatic,room().aquatic);assert.equal(createAquaticController(imported.rooms[0]).view().fishSources[0].rng,22);
  get('source-remove').click();assert.equal(room().aquatic.fishSources.length,0);h.undo();tools.refresh();assert.equal(get('source-id').value,'renamed-fish');get('current-remove').click();assert.equal(room().aquatic.currents.length,0);h.undo();tools.refresh();assert.equal(get('current-id').value,'renamed-current');get('blooper-remove').click();assert.equal(room().aquatic.enemyProfiles['blooper-a'],undefined);h.undo();tools.refresh();assert.equal(get('blooper-pulseFrames').value,36);
  room().aquatic.physics.gravity=.09;tools.refresh();assert.equal(get('physics-gravity').value,.09);get('aquatic-remove').click();assert.equal(room().aquatic,undefined);assert.equal(room().setting,'Underwater');assert.equal(room().underwater,true);h.undo();tools.refresh();assert(room().aquatic);validateAquaticRoom(room());
 }finally{ui.restore();}
});
