import test from 'node:test';
import {fileURLToPath} from 'node:url';
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {parseProject} from '../atlas/editor-model.mjs';
import {projectPack} from '../atlas/editor-runtime.mjs';
import {createStageCatalog} from '../atlas/runtime/stage-catalog.mjs';
import {createPlatformMotor} from '../atlas/editor-mario-motor.mjs';
import {createPlatformStage} from '../atlas/editor-mario-stage.mjs';
import {coinCraneProject} from './fixtures/coin-crane-native.mjs';
import {addSmm2Component} from '../atlas/editor-smm2-authoring.mjs';
const walkingAxis=(p,x)=>{const d=x-p.x;return Math.abs(d)<1?(Math.abs(p.vx)<.08?0:-Math.sign(p.vx)):Math.sign(d)*p.vx>0&&Math.abs(d)<p.vx*p.vx/(2*.1015625)+1?-Math.sign(p.vx):Math.sign(d);};
const character=JSON.parse(fs.readFileSync(new URL('../atlas/runtime/character.json',import.meta.url)));
export const sha256=q=>createHash('sha256').update(typeof q==='string'||ArrayBuffer.isView(q)?q:JSON.stringify(q)).digest('hex');
const plain=q=>JSON.parse(JSON.stringify(q));
const inputNames=new Set(['x','jump','run','down','up','attack','interact','dismount']);
export function session(doc,{initialState=null,manualDeath=true,Stage=createPlatformStage}={}){
 const d=parseProject(JSON.stringify(doc)),pack=projectPack(d,d.rooms[0].roomId,character,'arcade-abuse-test'),plan=createStageCatalog(pack).plan(pack.stages[0].id,pack.characters[0].id,{allowDraft:true});
 // Immutable input records and complete native view hashes; no actor, wallet,
 // inventory, switch, collision, or progress mutation after Stage creation.
 const inputs=[],actions=[],events=[],viewHashes=[],marks=[];let frame=0;
 const stage=Stage({plan,motor:createPlatformMotor(),visualRooms:d.rooms,initialState,manualDeath,autoContinue:false,allowWarp:false,emit:(type,data)=>events.push({inputFrame:frame,type,data:structuredClone(data)})});
 const capture=()=>{const v=plain(stage.view());viewHashes.push(sha256(v));return v;};const initialView=capture();
 const s={doc:d,pack,plan,stage,inputs,actions,events,viewHashes,marks,initialView,options:{initialState,manualDeath},view:()=>stage.view(),step(raw={}){assert(Object.keys(raw).every(k=>inputNames.has(k)),'ordinary inputs only');frame++;stage.step(raw);inputs.push({...raw});actions.push({type:'step',input:{...raw}});return capture();},frames(n,raw={}){for(let i=0;i<n;i++)s.step(typeof raw==='function'?raw(s.view(),i):raw);return s.view();},until(fn,raw={},limit=1200){for(let i=0;i<limit;i++){const v=s.step(typeof raw==='function'?raw(s.view(),i):raw);if(fn(v))return v;}throw Error('Audit input timed out '+JSON.stringify({frame,roomId:s.view().roomId,p:s.view().p,crane:crane(s)}));},mark(label){const v=s.view();marks.push({label,inputFrame:frame,tick:v.tick,roomId:v.roomId,coins:v.coins,lives:v.lives,pink:v.smm2Mechanics?.pinkCoins,keys:v.contraptions?.keys,crane:crane(s)});},pause(){stage.pause();actions.push({type:'pause'});capture();},resume(){stage.resume();actions.push({type:'resume'});capture();},continue(){const accepted=stage.continueFromCurrent();actions.push({type:'continue',accepted});capture();return accepted;}};
 return s;
}
export const crane=s=>s.view().contraptions?.coinCranes?.[0];
export const eventCount=(s,type,name)=>s.events.filter(e=>e.type===type&&e.data.event===name).length;
export function walk(s,x,limit=300){return s.until(v=>Math.abs(v.p.x-x)<1.5&&Math.abs(v.p.vx)<.1&&v.p.grounded,v=>({x:walkingAxis(v.p,x),run:true}),limit);}
export function paidFixture({doors=false,initialX=246,speed=.75,grabY=160,payloads=[],hazard=false,five=false,ordinary=false}={}){
 const d=coinCraneProject({doors,initialX,speed}),r=d.rooms[0],q=r.contraptions.coinCranes[0];d.id='neutral-paid-arcade-abuse-fixture';
 r.map.geometry=r.map.geometry.filter(g=>!g.id.startsWith('roof-'));q.payment={price:1,entryBonus:10,slotId:'slot',slot:{x:88,y:176,w:16,h:16}};q.grabY=grabY;r.map.objects.find(o=>o.id===q.coinId).y=grabY-7;
 q.payloads=payloads.map(({body,...p})=>p);r.map.objects.push(...payloads.map(p=>p.body));
 if(hazard)r.map.objects.push({id:'thorn',kind:'hazard',x:16,y:192,w:16,h:16});
 if(ordinary)r.map.objects.push({id:'outside-wallet-coin',kind:'coin',x:112,y:194,w:8,h:14});
 if(five)for(const [i,x]of [96,112,144,160].entries()){const id='extra-pink-'+i;r.map.objects.push({id,kind:'coin',x,y:194,w:8,h:14});r.smm2Mechanics.pinkCoins.push({id});}
 return d;
}
export function pay(s,input='up'){s.step({});s.step({[input]:true});assert.equal(crane(s).paid,true);s.step({});}
export function press(s){s.until(v=>v.p.grounded,{},90);s.step({});s.until(v=>crane(s).phase==='lower',{jump:true},40);s.step({});}
export function nextPrimaryTry(s){s.until(v=>crane(s).phase==='scan',{},700);walk(s,67);pay(s);s.until(v=>crane(s).direction===1&&crane(s).grip.x>=250&&crane(s).grip.x<=252,{},500);press(s);}
export function collectReleased(s,pinkBefore=0){s.until(v=>crane(s).released,{},800);const coins=s.view().coins;assert.equal(s.view().smm2Mechanics.pinkCoins.taken,pinkBefore);walk(s,128);s.until(v=>v.smm2Mechanics.pinkCoins.taken===pinkBefore+1,{},100);assert.equal(s.view().coins,coins,'paid Pink contributes progress, no wallet coin');}
export function outAndBack(s){walk(s,35);s.step({});s.frames(2);s.until(v=>v.roomId==='other'&&!v.transition,{up:true},90);s.frames(35);s.step({});s.until(v=>v.roomId==='main'&&!v.transition,{up:true},90);s.frames(35);}
export function dieAndContinue(s){s.until(v=>v.p.dying,{x:-1,run:true},300);s.mark('actual-hazard-death');s.frames(110);assert.equal(s.continue(),true);s.frames(3);}
export const scenarios={
 'native entry grants once after initial state and repeated views remain pure':()=>{
  const sessions=[];for(const initialState of [null,{coins:0,lives:5},{coins:95,lives:5}]){const s=session(paidFixture({doors:true}),{initialState});sessions.push(s);assert.equal(s.view().coins,(initialState?.coins??0)+10);assert.equal(eventCount(s,'coin-wallet','entry-grant'),1);assert.equal(s.events.find(e=>e.type==='coin-wallet').inputFrame,0);const before=JSON.stringify(s.view());for(let n=0;n<20;n++)assert.equal(JSON.stringify(s.view()),before);outAndBack(s);assert.equal(s.view().coins,(initialState?.coins??0)+10);assert.equal(eventCount(s,'coin-wallet','entry-grant'),1);s.mark('reentry-did-not-regrant');}return sessions;
 },
 'held Up and interact share one payment edge across pause and busy attempts':()=>{
  const s=session(paidFixture({initialX:192,speed:.05}));s.frames(3);s.step({up:true});assert.equal(s.view().coins,9);s.frames(40,{up:true,interact:true});assert.equal(eventCount(s,'coin-wallet','spent'),1);s.pause();const frozen=JSON.stringify(crane(s));s.frames(20,{up:true,interact:true,jump:true});assert.equal(JSON.stringify(crane(s)),frozen);s.resume();s.frames(20,{interact:true});assert.equal(s.view().coins,9);assert.equal(eventCount(s,'coin-wallet','spent'),1);s.step({});press(s);assert.equal(crane(s).paid,false);s.frames(30,{up:true,jump:true});assert.equal(s.view().coins,9);assert.equal(eventCount(s,'coin-wallet','spent'),1);assert.equal(eventCount(s,'coin-crane','button-press'),1);assert(eventCount(s,'coin-crane','payment-ignored')>0);s.mark('one-debit-held-pause-busy');return [s];
 },
 'distant held payment cannot pay merely by approaching the real slot':()=>{
  const d=paidFixture();d.rooms[0].map.objects.find(o=>o.id==='start').x=35;const s=session(d);s.frames(3);s.step({up:true});walkHeld(s,67);assert.equal(s.view().coins,10);assert.equal(crane(s).paid,false);s.step({});s.step({interact:true});assert.equal(s.view().coins,9);assert.equal(crane(s).paid,true);assert.equal(eventCount(s,'coin-wallet','spent'),1);return [s];
 },
 'zero wallet rejects held payment and physical head spam without creating credit':()=>{
  const d=paidFixture({initialX:192,speed:.05}),q=d.rooms[0].contraptions.coinCranes[0];q.dropSpeed=8;q.liftSpeed=8;const s=session(d);s.frames(3);
  for(let i=0;i<10;i++){pay(s);press(s);s.until(v=>crane(s).phase==='scan',{},100);assert.equal(s.view().coins,9-i);assert.equal(crane(s).paid,false);assert.equal(s.view().smm2Mechanics.pinkCoins.taken,0);}
  assert.equal(s.view().coins,0);const rejected=eventCount(s,'coin-crane','payment-rejected');s.step({up:true});s.frames(120,{up:true,jump:true});assert.equal(s.view().coins,0);assert.equal(crane(s).paid,false);assert.equal(crane(s).needMoney,true);assert.equal(crane(s).phase,'scan');assert.equal(eventCount(s,'coin-crane','payment-rejected'),rejected+1);assert.equal(eventCount(s,'coin-crane','button-press'),10);assert.equal(eventCount(s,'coin-wallet','spent'),10);s.mark('zero-wallet-rejection');return [s];
 },
 'unused paid credit and wallet survive real door rebuild and death':()=>{
  const s=session(paidFixture({doors:true,hazard:true}));s.frames(3);pay(s);outAndBack(s);assert.equal(crane(s).paid,true);assert.equal(s.view().coins,9);dieAndContinue(s);assert.equal(crane(s).paid,true);assert.equal(s.view().coins,9);assert.equal(eventCount(s,'coin-wallet','entry-grant'),1);assert.equal(eventCount(s,'coin-wallet','spent'),1);assert.equal(s.view().lives,4);s.mark('unused-credit-survives-door-death');return [s];
 },
 'consumed paid credit receives no refund on unfinished try door rebuild or death':()=>{
  const sessions=[];for(const reset of ['door','death']){const s=session(paidFixture({doors:true,hazard:true,initialX:192,speed:.05}));sessions.push(s);s.frames(3);pay(s);press(s);assert.equal(crane(s).paid,false);if(reset==='door')outAndBack(s);else dieAndContinue(s);assert.equal(crane(s).paid,false);assert.equal(s.view().coins,9);assert.equal(eventCount(s,'coin-wallet','spent'),1);assert.equal(eventCount(s,'coin-wallet','entry-grant'),1);s.mark('consumed-no-refund-'+reset);}return sessions;
 },
 'ordinary pickups stay spent across door and death while paid wallet exceeds 100 without 1UP':()=>{
  const s=session(paidFixture({doors:true,hazard:true,ordinary:true}),{initialState:{coins:99,lives:5}});assert.equal(s.view().coins,109);walk(s,116);assert.equal(s.view().coins,110);assert.equal(s.view().lives,5);outAndBack(s);walk(s,116);assert.equal(s.view().coins,110);assert(!s.view().objects.some(o=>o.id==='outside-wallet-coin'));dieAndContinue(s);walk(s,116);assert.equal(s.view().coins,110);assert.equal(s.view().lives,4);assert(!s.view().objects.some(o=>o.id==='outside-wallet-coin'));assert.equal(eventCount(s,'sound','life'),0);s.mark('ordinary-ledger-no-door-death-farming');return [s];
 },
 'paid wallet converted brick can physically clear again after genuine death without minting twice while ordinary coin stays spent':()=>{
  const d=paidFixture({hazard:true}),r=d.rooms[0];r.map.objects.find(o=>o.id==='start').x=112;r.map.objects.find(o=>o.id==='start').y=32;r.map.objects.push({id:'persistent-world-coin',kind:'coin',x:112,y:32,w:8,h:14});r.map.geometry.push({id:'wallet-passage-brick',x:160,y:192,w:16,h:16,material:'brick',collision:'solid'});addSmm2Component(r,'pSwitch',{id:'repeat-after-life-p',x:112,y:192,orientation:'up',gravity:0});
  const s=session(d,{manualDeath:false});assert.equal(s.view().coins,10);s.step({});assert.equal(s.view().coins,11);assert(!s.view().objects.some(o=>o.id==='persistent-world-coin'));s.until(v=>v.contraptions.pFrames>0,{},100);assert.equal(eventCount(s,'contraption','p-pressed'),1);const converted=s.view().objects.find(o=>o.sourceBrickId==='wallet-passage-brick');assert(converted);assert.equal(s.view().geometry.find(g=>g.id==='wallet-passage-brick').collision,'none');
  s.until(v=>v.contraptions.removedBricks.includes('main\nwallet-passage-brick'),{x:1,run:true},120);assert.equal(s.view().coins,12);assert.equal(eventCount(s,'contraption','p-brick-collected'),1);assert(!s.view().geometry.some(g=>g.id==='wallet-passage-brick'));s.mark('first-real-converted-passage-pickup-banked-once');
  s.until(v=>v.p.dying,{x:-1,run:true},220);s.until(v=>!v.p.dying,{},150);assert.equal(s.view().coins,12);assert.equal(s.view().lives,4);assert.equal(s.view().contraptions.pFrames,0);assert.equal(s.view().geometry.find(g=>g.id==='wallet-passage-brick').collision,'solid');assert(!s.view().objects.some(o=>o.id==='persistent-world-coin'));s.mark('actual-life-reset-restores-brick-not-ordinary-coin');
  s.until(v=>v.contraptions.pFrames>0,{},100);assert.equal(eventCount(s,'contraption','p-pressed'),2);assert(s.view().objects.some(o=>o.sourceBrickId==='wallet-passage-brick'),'restored converted passage coin remains physically collectible');s.until(v=>v.contraptions.removedBricks.includes('main\nwallet-passage-brick'),{x:1,run:true},120);assert.equal(s.view().coins,12);assert.equal(eventCount(s,'coin-wallet','converted-passage-recollected'),1);assert.equal(eventCount(s,'contraption','p-brick-collected'),2);assert(!s.view().geometry.some(g=>g.id==='wallet-passage-brick'));assert(!s.view().objects.some(o=>o.sourceBrickId==='wallet-passage-brick'));assert(!s.view().objects.some(o=>o.id==='persistent-world-coin'));s.until(v=>v.p.x>=165,{x:1,run:true},30);assert.equal(s.view().coins,12);assert.equal(eventCount(s,'coin-wallet','entry-grant'),1);s.mark('second-real-P-reclear-opens-passage-no-wallet-farming');return [s];
 },
 'unpaid legacy crane keeps ordinary 100 coin to 1UP rules':()=>{
  const s=session(coinCraneProject(),{initialState:{coins:99,lives:5}});s.frames(3);press(s);s.until(v=>crane(s).released,{},800);walk(s,128);s.until(v=>v.smm2Mechanics.pinkCoins.taken===1,{},100);assert.equal(s.view().coins,0);assert.equal(s.view().lives,6);assert.equal(eventCount(s,'sound','life'),1);return [s];
 },
 'ordinary physical coin prize pays only at pickup and remains spent on room and death rebuilds':()=>{
  const payload={id:'ordinary-prize',kind:'coin',body:{id:'ordinary-prize',kind:'coin',x:246,y:153,w:8,h:14}},s=session(paidFixture({doors:true,hazard:true,initialX:236,payloads:[payload]}));s.frames(3);pay(s);press(s);s.until(v=>crane(s).heldId===payload.id,{},160);s.until(v=>crane(s).released,{},700);assert.equal(s.view().coins,9);assert.equal(s.view().smm2Mechanics.pinkCoins.taken,0);walk(s,128);s.until(v=>v.coins===10,{},80);assert.equal(s.view().smm2Mechanics.pinkCoins.taken,0);outAndBack(s);assert(!s.view().objects.some(o=>o.id===payload.id));dieAndContinue(s);assert(!s.view().objects.some(o=>o.id===payload.id));assert.equal(s.view().coins,10);assert.equal(crane(s).phase,'scan');return [s];
 },
 'inert Goomba and Spiny wrong prizes fail visibly then permit a native Pink win':()=>{
  const sessions=[];for(const kind of ['goomba','spiny']){const payload={id:'wrong-prize',kind,body:{id:'wrong-prize',kind:'crate',x:192,y:152,w:16,h:16}},s=session(paidFixture({initialX:192,payloads:[payload]}));sessions.push(s);s.frames(3);pay(s);press(s);s.until(v=>crane(s).heldId===payload.id,{},160);s.until(v=>crane(s).phase==='reject-lower',{},120);assert.equal(s.view().coins,9);assert.equal(s.view().lives,5);s.until(v=>crane(s).phase==='scan',{},260);assert.equal(crane(s).failedKind,'wrong-prize');assert.equal(eventCount(s,'coin-crane','release'),0);assert.equal(s.view().smm2Mechanics.pinkCoins.taken,0);nextPrimaryTry(s);collectReleased(s);assert.equal(s.view().coins,8);assert.equal(s.view().lives,5);assert.equal(s.view().contraptions.keys,1);s.mark(kind+'-failed-then-physical-pink-win');}return sessions;
 },
 'moving bomb drops held Pink onto floor and later real input recaptures its one pixel shifted centre':()=>{
  const payload={id:'moving-bomb',kind:'bomb',motion:{minX:192,maxX:320,y:80,speed:2,phase:48},body:{id:'moving-bomb',kind:'crate',x:200,y:72,w:16,h:16}},s=session(paidFixture({grabY:200,payloads:[payload]}));s.frames(3);pay(s);press(s);s.until(v=>crane(s).heldId==='physical-pink',{},180);s.until(v=>crane(s).failedKind==='bomb',{},180);assert(s.events.some(e=>e.type==='coin-crane'&&e.data.event==='bomb-contact'&&e.data.phase==='raise'));assert.equal(s.view().coins,9);assert.equal(crane(s).paid,false);assert.equal(s.view().smm2Mechanics.pinkCoins.taken,0);s.until(v=>crane(s).phase==='scan',{},200);const dropped=s.view().objects.find(o=>o.id==='physical-pink');assert.equal(dropped.y+dropped.h,208);assert.equal(dropped.y+dropped.h/2,201);s.mark('bomb-dropped-real-body-one-pixel-below-grab');
  pay(s);s.until(v=>crane(s).direction===-1&&crane(s).grip.x>=267&&crane(s).grip.x<=269,{},500);press(s);s.until(v=>crane(s).heldId==='physical-pink',{},180);collectReleased(s);
  assert.equal(s.view().smm2Mechanics.pinkCoins.taken,1);assert.equal(s.view().coins,8);assert.equal(s.view().lives,5);assert.equal(s.view().contraptions.keys,1);assert.equal(eventCount(s,'coin-crane','capture'),2);assert.equal(s.events.filter(e=>/damage|explosion/.test(e.type+' '+e.data.event)).length,0);s.mark('floor-pink-recaptured-and-won');return [s];
 },
 'five physical Pink progress releases one key and genuine death resets progress and key but keeps wallet':()=>{
  const s=session(paidFixture({five:true,hazard:true,doors:true}));s.frames(3);pay(s);press(s);s.until(v=>crane(s).released,{},800);assert.equal(s.view().coins,9);walk(s,163);s.until(v=>v.smm2Mechanics.pinkCoins.taken===5&&v.contraptions.keys===1,{},120);assert.equal(s.view().coins,9);assert.equal(eventCount(s,'smm2-item','pink-key-release'),1);assert.equal(eventCount(s,'smm2-item','pink-coin-collected'),5);s.mark('all-five-real-pinks-one-key');outAndBack(s);assert.equal(s.view().smm2Mechanics.pinkCoins.taken,5);assert.equal(s.view().contraptions.keys,1);dieAndContinue(s);assert.deepEqual(s.view().smm2Mechanics.pinkCoins,{taken:0,total:5,keyReleased:false});assert.equal(s.view().contraptions.keys,0);assert.equal(s.view().contraptions.keyFollowers.length,0);assert.equal(s.view().coins,9);assert.equal(eventCount(s,'coin-wallet','entry-grant'),1);s.mark('genuine-death-progress-and-key-reset-wallet-kept');return [s];
 },
 'miss bomb and plush failures each preserve five Pink key door and native finish reachability in compiled neutral fixtures':()=>{
  const sessions=[];for(const mode of ['miss','bomb','plush']){
   const payloads=mode==='bomb'?[{id:'moving-bomb',kind:'bomb',motion:{minX:192,maxX:320,y:80,speed:2,phase:48},body:{id:'moving-bomb',kind:'crate',x:200,y:72,w:16,h:16}}]:mode==='plush'?[{id:'wrong-prize',kind:'goomba',body:{id:'wrong-prize',kind:'crate',x:192,y:152,w:16,h:16}}]:[];
   const d=paidFixture({five:true,doors:true,initialX:mode==='bomb'?246:192,grabY:mode==='bomb'?200:160,payloads});d.rooms[0].contraptions.doors[0].style='key';d.rooms[1].map.objects.push({id:'fixture-goal',kind:'exit',x:160,y:128,w:16,h:80});const s=session(d);sessions.push(s);s.frames(3);pay(s);press(s);s.until(v=>crane(s).phase==='scan',{},750);assert.equal(s.view().smm2Mechanics.pinkCoins.taken,0);assert.equal(s.view().coins,9);assert.equal(s.view().contraptions.keys,0);
   if(mode==='miss')assert.equal(eventCount(s,'coin-crane','miss'),1);else assert.equal(crane(s).failedKind,mode==='plush'?'wrong-prize':'bomb');s.mark(mode+'-failed-no-progress');
   if(mode==='bomb'){pay(s);s.until(v=>crane(s).direction===-1&&crane(s).grip.x>=267&&crane(s).grip.x<=269,{},500);press(s);}else nextPrimaryTry(s);
   s.until(v=>crane(s).released,{},900);assert.equal(s.view().coins,8);walk(s,163);s.until(v=>v.smm2Mechanics.pinkCoins.taken===5&&v.contraptions.keys===1,{},120);assert.equal(eventCount(s,'smm2-item','pink-key-release'),1);assert.equal(s.view().coins,8);s.mark('five-physical-Pinks-following-key-after-'+mode);
   walk(s,35);s.frames(2);s.step({});s.until(v=>v.roomId==='other'&&!v.transition,{up:true},90);assert.equal(s.view().contraptions.keys,0);assert.equal(eventCount(s,'contraption','door-unlocked'),1);s.frames(35);s.until(v=>!!v.finish,{x:1,run:true},180);s.until(v=>v.completed,{x:1,run:true},700);assert.equal(s.view().coins,8);assert.equal(s.view().lives,5);s.mark('native-key-door-and-goal-completed-after-'+mode);
  }return sessions;
 },
 'dying ON OFF scene geometry crane and audio freeze until automatic native respawn despite input spam':()=>{
  const sessions=[];for(const dyingOn of [true,false]){const d=paidFixture({hazard:true}),r=d.rooms[0];r.switchStudy={version:1,initialOn:!dyingOn,allowBacktracking:true,devices:[{id:'life-switch',kind:'switch',x:112,y:144,w:16,h:16},{id:'red-frozen',kind:'block',color:'red',x:384,y:176,w:16,h:16},{id:'blue-frozen',kind:'block',color:'blue',x:416,y:176,w:16,h:16}]};const s=session(d,{manualDeath:false});sessions.push(s);s.frames(3);pay(s);walk(s,115);s.step({});s.until(v=>v.switchStudy.on===dyingOn,{jump:true},50);s.until(v=>v.p.grounded,{},80);s.until(v=>v.p.dying,{x:-1,run:true},160);assert.equal(s.view().switchStudy.on,dyingOn);const dead=plain(s.view()),sounds=s.events.filter(e=>e.type==='sound').length,switches=eventCount(s,'switch-study','toggle');s.mark((dyingOn?'ON':'OFF')+'-dying-scene-before-input-spam');
  for(let i=0;i<103;i++){s.step(i%2?{}:{jump:true,up:true,interact:true,attack:true});assert.deepEqual(s.view().switchStudy,dead.switchStudy);assert.deepEqual(s.view().geometry,dead.geometry);assert.deepEqual(crane(s),dead.contraptions.coinCranes[0]);assert.equal(eventCount(s,'switch-study','toggle'),switches);assert.equal(s.events.filter(e=>e.type==='sound').length,sounds);}
  s.step({jump:true,up:true});assert.equal(s.view().p.dying,undefined);assert.equal(s.view().switchStudy.on,!dyingOn);assert.equal(s.view().switchStudy.toggles,0);assert.equal(s.view().coins,9);assert.equal(crane(s).paid,true);assert.equal(s.view().lives,4);s.mark('105-frame-respawn-resets-switch-retains-credit');}return sessions;
 },

};
function walkHeld(s,x){return s.until(v=>Math.abs(v.p.x-x)<1.5&&Math.abs(v.p.vx)<.1&&v.p.grounded,v=>({x:walkingAxis(v.p,x),run:true,up:true}),300);}
export function record(s){return {format:'arcade-native-abuse-input-proof',version:1,fixture:s.doc.id!=='original-five-mechanism-hub',wholeCourseClaim:false,project:s.doc,projectSha256:sha256(s.doc),packSha256:sha256(s.pack),options:s.options,initialView:s.initialView,inputs:s.inputs,actions:s.actions,viewHashes:s.viewHashes,events:s.events,marks:s.marks,finalView:plain(s.view())};}
export function replay(record){const s=session(record.project,record.options);assert.deepEqual(s.initialView,record.initialView);assert.equal(s.viewHashes[0],record.viewHashes[0]);let index=1;for(const action of record.actions){if(action.type==='step')s.step(action.input);else if(action.type==='pause')s.pause();else if(action.type==='resume')s.resume();else if(action.type==='continue')assert.equal(s.continue(),action.accepted);assert.equal(s.viewHashes[index],record.viewHashes[index],'complete Stage view replay action '+index);index++;}assert.equal(index,record.viewHashes.length);assert.deepEqual(s.events,record.events);assert.deepEqual(plain(s.view()),record.finalView);return s;}

if(process.argv[1]===fileURLToPath(import.meta.url))for(const [name,run] of Object.entries(scenarios))test(name,()=>{for(const s of run())replay(record(s));});
