import test from 'node:test';
import assert from 'node:assert/strict';
import {createCanvas} from '@napi-rs/canvas';
import {drawMinecraftTile,drawMinecraftBackground,drawMinecraftScenery,drawMinecraftWorld,drawMinecraftHud} from '../atlas/editor-minecraft-art.mjs';
import {rendererRoom} from '../atlas/editor-renderer.mjs';
const room=()=>({minecraft:{version:1,biome:'forest',scenery:[],labels:[],destructibleIds:[]},map:{width:512,height:320,geometry:[]},renderBounds:{x:0,y:0,w:512,h:320},tick:20});
const canvas=(w=512,h=320)=>createCanvas(w,h),pixels=c=>c.getContext('2d').getImageData(0,0,c.width,c.height).data;
const freeze=q=>{if(q&&typeof q==='object'){Object.values(q).forEach(freeze);Object.freeze(q);}return q;};
test('Minecraft art is explicit opt-in and leaves ordinary room untouched',()=>{
 const c=canvas(),ctx=c.getContext('2d');assert.equal(drawMinecraftBackground(ctx,{},512,320),false);assert.equal(drawMinecraftScenery(ctx,{}),false);assert.equal(drawMinecraftWorld(ctx,{}),false);assert.equal(drawMinecraftTile(ctx,{id:'mc-grass-test',x:0,y:0,w:16,h:16},{}),false);assert.equal(drawMinecraftHud(ctx,{},{}),false);assert(pixels(c).every(x=>x===0));
});
test('Minecraft tile raster is deterministic, cropped and respects live source-ID position',()=>{
 const r=freeze(room()),q=freeze({id:'runtime-sand',sourceId:'mc-sand-a',x:48,y:112,w:16,h:16});const a=canvas(),b=canvas();drawMinecraftTile(a.getContext('2d'),q,r);drawMinecraftTile(b.getContext('2d'),q,r);assert.deepEqual(pixels(a),pixels(b));const raw=pixels(a);for(let y=0;y<a.height;y++)for(let x=0;x<a.width;x++){const alpha=raw[(y*a.width+x)*4+3];assert.equal(alpha,x>=48&&x<64&&y>=112&&y<128?255:0);}assert.equal(q.y,112);
});
test('Emerald ore, cracked support, grass, sand and obsidian have distinct original pixels',()=>{
 const r=room(),digests=[];for(const kind of ['ore-emerald','stone','stone-cracked','grass','sand','obsidian']){const c=canvas(16,16),id='mc-'+kind;r.minecraft.destructibleIds=[id==='mc-stone-cracked'?id:'unused'];drawMinecraftTile(c.getContext('2d'),{id,x:0,y:0,w:16,h:16},r);digests.push(Buffer.from(pixels(c)).toString('base64'));}assert.equal(new Set(digests).size,digests.length);
});
test('Scenery is pure and restores context while all biomes render distinct dense palettes',()=>{
 const rasters=[];for(const biome of ['forest','cave','nether']){const r=room();r.minecraft.biome=biome;r.minecraft.scenery=[{kind:'oak',x:16,y:272},{kind:'birch',x:80,y:272},{kind:'village',x:140,y:272},{kind:'pig',x:250,y:272},{kind:'portal',x:350,y:272,w:48,h:80},{kind:'torch',x:300,y:220}];const before=JSON.stringify(r);freeze(r);const c=canvas(),ctx=c.getContext('2d');ctx.fillStyle='#abcdef';ctx.globalAlpha=.8;const m=ctx.getTransform().toJSON();drawMinecraftBackground(ctx,r,c.width,c.height);ctx.fillStyle='#abcdef';drawMinecraftScenery(ctx,r);assert.equal(ctx.fillStyle,'#abcdef');assert.equal(ctx.globalAlpha,.8);assert.deepEqual(ctx.getTransform().toJSON(),m);assert.equal(JSON.stringify(r),before);const colors=new Set();const raw=pixels(c);for(let i=0;i<raw.length;i+=4)colors.add(Array.from(raw.slice(i,i+4)).join(','));assert(colors.size>40);rasters.push(Buffer.from(raw).toString('base64'));}assert.equal(new Set(rasters).size,3);
});
test('Live creeper fuse and effects are read-only; dead creepers stay gone',()=>{
 const r=room(),v=freeze({creepers:[{id:'c',x:20,y:60,w:16,h:28,state:'fuse',fuse:45,fuseTicks:90,flash:false}],effects:[{kind:'explosion',x:96,y:60,w:0,h:0,age:10,life:30}]});const before=JSON.stringify(v),a=canvas(),b=canvas();drawMinecraftWorld(a.getContext('2d'),r,v);drawMinecraftWorld(b.getContext('2d'),r,v);assert.deepEqual(pixels(a),pixels(b));assert.equal(JSON.stringify(v),before);const gone=canvas();drawMinecraftWorld(gone.getContext('2d'),r,{creepers:[{...v.creepers[0],dead:true}],effects:[]});assert(pixels(gone).every(x=>x===0));
});
test('Shared render projection carries live Minecraft controller unchanged',()=>{const a=room(),minecraft=freeze({version:1,creepers:[],sand:[],effects:[]}),r=rendererRoom(a,{minecraft,tick:12},{x:8,y:0,w:512,h:320});assert.equal(r.minecraftView,minecraft);assert.equal(r.minecraft,a.minecraft);assert.equal(r.tick,12);});
test('Offscreen texture cache is pixel-identical to no-DOM paint and sand texture travels intact',()=>{
 const prior=globalThis.document;delete globalThis.document;
 const r=room(),cases=['stone','sand','grass','obsidian','ore-emerald','nether','planks'],expected=[];
 for(const kind of cases){const a=canvas(32,32);drawMinecraftTile(a.getContext('2d'),{id:'mc-'+kind+'-cache-check',x:0,y:0,w:32,h:32},r);expected.push(pixels(a));}
 globalThis.document={createElement:()=>createCanvas(1,1)};
 try{for(const [i,kind]of cases.entries()){const b=canvas(32,32);drawMinecraftTile(b.getContext('2d'),{id:'mc-'+kind+'-cache-check',x:0,y:0,w:32,h:32},r);assert.deepEqual(pixels(b),expected[i]);}
 const a=canvas(48,64),b=canvas(48,64),q={id:'mc-sand-falling',x:0,y:0,w:16,h:16};drawMinecraftTile(a.getContext('2d'),q,r);drawMinecraftTile(b.getContext('2d'),{...q,x:16,y:32},r);assert.deepEqual(a.getContext('2d').getImageData(0,0,16,16).data,b.getContext('2d').getImageData(16,32,16,16).data);
 }finally{if(prior===undefined)delete globalThis.document;else globalThis.document=prior;}
});
