import {test} from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs/promises';import path from 'node:path';import {createHash} from 'node:crypto';import {createRequire} from 'node:module';import {fileURLToPath} from 'node:url';
import {SMM2_SOURCE_PIXELS,drawSmm2SourcePixels} from '../atlas/editor-smm2-source-assets.mjs';import {drawSmm2SourceFirebar} from '../atlas/editor-smm2-bone-art.mjs';import {castleFirebarNodes} from '../atlas/editor-castle.mjs';
let canvasLib;try{canvasLib=createRequire(import.meta.url)('@napi-rs/canvas');}catch{}
const root=path.dirname(fileURLToPath(import.meta.url)),assets=path.resolve(root,'../atlas/assets/smm2-private');
const rgba=c=>c.getContext('2d').getImageData(0,0,c.width,c.height).data;
// Catalogue PNGs can carry gamma/profile metadata. Compare stored sprite
// palette/alpha values without the raster library's display-profile transform;
// original files and SHA remain unmodified.
function rawPalettePng(bytes){if(bytes.toString('hex',0,8)!=='89504e470d0a1a0a')return bytes;const parts=[bytes.subarray(0,8)];for(let offset=8;offset<bytes.length;){const length=bytes.readUInt32BE(offset),end=offset+12+length,type=bytes.toString('ascii',offset+4,offset+8);if(['IHDR','PLTE','tRNS','IDAT','IEND'].includes(type))parts.push(bytes.subarray(offset,end));offset=end;}return Buffer.concat(parts);}

test('every original runtime sprite retains the catalogue PNG dimensions, hash and exact transparent pixels',{skip:!canvasLib},async()=>{
 const m=JSON.parse(await fs.readFile(path.join(assets,'SOURCE_ASSETS.json')));assert(m.privateOnly);
 for(const [name,entry] of Object.entries(m.assets)){
  const raw=await fs.readFile(path.join(assets,entry.file));assert.equal(createHash('sha256').update(raw).digest('hex'),entry.sha256);const im=await canvasLib.loadImage(rawPalettePng(raw)),a=canvasLib.createCanvas(im.width,im.height),b=canvasLib.createCanvas(im.width,im.height);a.getContext('2d').drawImage(im,0,0);assert(drawSmm2SourcePixels(b.getContext('2d'),name,{x:0,y:0}));assert.deepEqual(rgba(b),rgba(a),name);assert.equal(SMM2_SOURCE_PIXELS[name].w,im.width);assert.equal(SMM2_SOURCE_PIXELS[name].h,im.height);assert.match(entry.copyright,/Nintendo/);
 }
});
test('source image paint restores canvas transforms and cannot mutate actor/collision objects',{skip:!canvasLib},()=>{
 const c=canvasLib.createCanvas(128,128),ctx=c.getContext('2d'),q={x:24,y:24,scale:2,mirror:true},before=JSON.stringify(q);ctx.translate(3,4);ctx.imageSmoothingEnabled=true;const transform=ctx.getTransform();assert(drawSmm2SourcePixels(ctx,'boneShell',q));assert.deepEqual(ctx.getTransform(),transform);assert.equal(ctx.imageSmoothingEnabled,true);assert.equal(JSON.stringify(q),before);for(const bad of [{x:NaN,y:1},{x:1,y:1,scale:0}])assert.equal(drawSmm2SourcePixels(ctx,'boneShell',bad),false);
});
test('firebar art follows actual collision nodes while fixed mount stays fixed through rotation',{skip:!canvasLib},()=>{
 const marker={id:'bar',kind:'rotating-firebar',x:48,y:48},rule={ballCount:6,direction:'cw',periodFrames:300,phaseDegrees:0},room={smm2Mechanics:{version:1,art:{palette:'smb1-castle-stone'}},castle:{firebars:{bar:rule}}},before=JSON.stringify({marker,room});
 const snaps=[];for(const age of [0,75]){const nodes=castleFirebarNodes(marker,rule,age),c=canvasLib.createCanvas(128,128);drawSmm2SourceFirebar(c.getContext('2d'),marker,{...room,castleView:{firebars:[{id:'bar',nodes}]}});for(const node of nodes){const a=c.getContext('2d').getImageData(Math.round(node.x),Math.round(node.y),8,8).data;assert(a.some((v,i)=>i%4===0&&v===247),'source orange orb is painted at actual native node');}snaps.push(c);}
 for(const [x,y]of [[49,49],[50,50],[61,50]])assert.deepEqual(snaps[0].getContext('2d').getImageData(x,y,1,1).data,snaps[1].getContext('2d').getImageData(x,y,1,1).data,'gray mount never turns with orb chain');assert.equal(JSON.stringify({marker,room}),before);
});
