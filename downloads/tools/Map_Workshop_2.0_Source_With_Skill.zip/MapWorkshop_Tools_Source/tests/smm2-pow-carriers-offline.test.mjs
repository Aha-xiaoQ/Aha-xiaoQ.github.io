import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
import {offlineFile} from '../atlas/editor-offline.mjs';
import {createCollection,addLevel,approveLevel,buildCollection} from '../atlas/editor-collection.mjs';
import {character,nativeSession} from './fixtures/shell-coin-native.mjs';
import {powCarrierProject} from './fixtures/pow-carriers-native.mjs';

for(const collection of [false,true])test(`standalone ${collection?'collection':'single map'} embeds and executes actual POW support/motion/light tracking without network`,async()=>{
 const project=powCarrierProject(),s=nativeSession(project),root=new URL('../atlas/',import.meta.url),built=collection?buildCollection(approveLevel(addLevel(createCollection('Neutral POW support export'),project,{id:'pow-support'}),'pow-support','Synthetic neutral fixture approval for automated QA only'),character):null;
 const html=await offlineFile(s.pack,s.doc.rooms,p=>fs.promises.readFile(new URL(p,root),'utf8'),p=>fs.promises.readFile(new URL('assets/classic-audio/'+p,root)),()=>{},collection?{collection:built}:{});assert(html.includes('"carrierItems"'));
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'POW Support Offline QA ')),htmlPath=path.join(dir,'fixture.html'),projectPath=path.join(dir,'fixture.qmap.json');
 try{fs.writeFileSync(htmlPath,html);fs.writeFileSync(projectPath,JSON.stringify(project));const result=spawnSync(process.execPath,['--experimental-vm-modules',fileURLToPath(new URL('../scripts/check-pow-carriers-offline.mjs',import.meta.url)),htmlPath,projectPath,...(collection?['collection']:[])],{encoding:'utf8',timeout:30000,maxBuffer:1024*1024});assert.equal(result.status,0,result.stderr||result.stdout||String(result.error));const report=JSON.parse(result.stdout);for(const key of ['actualEmbeddedStageExecuted','actualEmbeddedCarriersExecuted','actualEmbeddedItemsExecuted','actualEmbeddedThwompsExecuted','liveLightsTracked','detached','caught','returned'])assert.equal(report[key],true,key);assert.equal(report.networkRequests,0);assert.equal(report.collection,collection);assert.deepEqual(report.livePowIds,['pow-left','pow-right']);}finally{fs.rmSync(dir,{recursive:true,force:true});}
});
