import {test} from 'node:test';
import assert from 'node:assert/strict';
import {suppliedEmptyShellHeadContact} from '../atlas/editor-mario-modules.mjs';
import {createSmm2Items} from '../atlas/editor-smm2-items.mjs';
import {createSmm2Thwomps} from '../atlas/editor-smm2-thwomps.mjs';
import {emptyShellProject,nativeSession,sideKickEmptyShell} from './fixtures/empty-shell-native.mjs';
import {overlaps,shellPickups} from './fixtures/shell-coin-native.mjs';

// Synthetic contact cases exercise the runtime contract, not original course
// geometry or a claim that Nintendo's frame timing has been reproduced.
const mario=(extra={})=>({id:'player',x:100,y:100,w:10,h:14,power:0,...extra});
const emptyShell=(extra={})=>({id:'supplied-buzzy',kind:'walker',type:'beetle',shell:true,emptyShell:true,x:96,y:60,w:16,h:16,vx:0,vy:0,dead:false,...extra});
const near=(actual,expected,message)=>assert(Math.abs(actual-expected)<1e-9,message||`${actual} differs from ${expected}`);
function contact(beforePlayer,player,beforeShell,shell){return suppliedEmptyShellHeadContact(player,beforePlayer,shell,beforeShell);}
function checkHeadContact(hit,beforePlayer,player,beforeShell,shell,fraction){
 assert.ok(hit,'the descending shell actually crosses Mario’s head');near(hit.fraction,fraction);assert.deepEqual(hit.normal,{x:0,y:1});
 const px=beforePlayer.x+(player.x-beforePlayer.x)*fraction,sx=beforeShell.x+(shell.x-beforeShell.x)*fraction;
 near(hit.point.y,beforePlayer.y+(player.y-beforePlayer.y)*fraction);
 assert(hit.point.x>=Math.max(px,sx)&&hit.point.x<=Math.min(px+player.w,sx+shell.w),'world contact lies in the actual horizontal overlap');
}

test('fast descending supplied shell finds the swept head crossing even with no final body overlap',()=>{
 const beforePlayer=mario(),player=mario(),beforeShell=emptyShell({y:0}),shell=emptyShell({y:180,vy:180}),snapshot=structuredClone({beforePlayer,player,beforeShell,shell});
 assert.equal(overlaps(player,shell),false);checkHeadContact(contact(beforePlayer,player,beforeShell,shell),beforePlayer,player,beforeShell,shell,7/15);
 assert.deepEqual({beforePlayer,player,beforeShell,shell},snapshot,'contact query cannot equip, kill or otherwise mutate either actor');
});

test('relative head crossing follows a descending player while the shell closes faster',()=>{
 const beforePlayer=mario(),player=mario({y:120,vy:20}),beforeShell=emptyShell(),shell=emptyShell({y:116,vy:56});
 checkHeadContact(contact(beforePlayer,player,beforeShell,shell),beforePlayer,player,beforeShell,shell,2/3);
});

test('a descending shell can meet a rising Mario head at their actual intermediate position',()=>{
 const beforePlayer=mario(),player=mario({y:80,vy:-20}),beforeShell=emptyShell(),shell=emptyShell({y:90,vy:30});
 checkHeadContact(contact(beforePlayer,player,beforeShell,shell),beforePlayer,player,beforeShell,shell,12/25);
});

test('shell overlap is sampled at the head-crossing fraction rather than either endpoint',()=>{
 const beforePlayer=mario(),player=mario(),beforeShell=emptyShell({x:20,y:44}),shell=emptyShell({x:180,y:124,vy:80});
 assert.equal(overlaps(beforePlayer,beforeShell),false);assert.equal(overlaps(player,shell),false);
 checkHeadContact(contact(beforePlayer,player,beforeShell,shell),beforePlayer,player,beforeShell,shell,.5);
 const lateBefore=emptyShell({x:0,y:44}),lateShell=emptyShell({x:100,y:100,vy:56});
 assert(overlaps(player,lateShell));assert.equal(contact(beforePlayer,player,lateBefore,lateShell),null,'a later side overlap cannot invent horizontal overlap at the earlier head crossing');
});

test('moving Mario horizontal overlap uses his interpolated head pose as well as the shell pose',()=>{
 const beforePlayer=mario({x:0}),player=mario({x:200}),beforeShell=emptyShell({x:100,y:44}),shell=emptyShell({x:100,y:124,vy:80});
 checkHeadContact(contact(beforePlayer,player,beforeShell,shell),beforePlayer,player,beforeShell,shell,.5);
 const latePlayer=mario({x:100});assert.equal(contact(beforePlayer,latePlayer,beforeShell,shell),null);
});

test('touching shell/head sweep endpoints count, but an exact horizontal edge graze does not',()=>{
 const beforePlayer=mario(),player=mario();
 for(const [startY,endY,fraction]of [[84,90,0],[64,84,1]]){
  const beforeShell=emptyShell({y:startY}),shell=emptyShell({y:endY,vy:endY-startY});checkHeadContact(contact(beforePlayer,player,beforeShell,shell),beforePlayer,player,beforeShell,shell,fraction);
 }
 const beforeShell=emptyShell({x:110}),shell=emptyShell({x:110,y:100,vy:40});assert.equal(contact(beforePlayer,player,beforeShell,shell),null,'shared horizontal edge has no head overlap');
 assert.ok(contact(beforePlayer,player,{...beforeShell,x:109.75},{...shell,x:109.75}),'a genuine narrow horizontal overlap still equips');
});

test('upward or stationary shells cannot equip just because a rising player closes the gap',()=>{
 const beforePlayer=mario(),player=mario({y:60,vy:-40});
 for(const [startY,endY]of [[60,60],[60,50]])assert.equal(contact(beforePlayer,player,emptyShell({y:startY}),emptyShell({y:endY,vy:endY-startY})),null);
 const stationaryPlayer=mario();assert.equal(contact(stationaryPlayer,stationaryPlayer,emptyShell({y:100}),emptyShell({x:100,y:100,vx:4})),null,'horizontal side motion is not a falling head contact');
});

test('actual shell descent controls contact even when the recorded vertical velocity disagrees',()=>{
 const beforePlayer=mario(),player=mario(),beforeShell=emptyShell(),shell=emptyShell({y:100,vy:0,grounded:true});
 checkHeadContact(contact(beforePlayer,player,beforeShell,shell),beforePlayer,player,beforeShell,shell,3/5);
 assert.equal(contact(beforePlayer,mario({y:60,vy:-40}),emptyShell({y:60,vy:8}),emptyShell({y:50,vy:8})),null,'a positive stored velocity does not make an actually upward shell descend');
});

test('body overlap, descending Mario from above, an unclosed gap and receding motion never equip',()=>{
 const examples=[
  [mario(),mario(),emptyShell({y:88}),emptyShell({y:96,vy:8}),'shell already started below the head'],
  [mario({y:32}),mario({y:56,vy:24}),emptyShell({y:70}),emptyShell({y:72,vy:2}),'Mario descends from above onto the shell'],
  [mario(),mario(),emptyShell({y:60}),emptyShell({y:80,vy:20}),'shell bottom still falls short of the head'],
  [mario(),mario({y:130,vy:30}),emptyShell({y:60}),emptyShell({y:70,vy:10}),'player falls faster and the gap widens']
 ];
 for(const [bp,p,bs,s,label]of examples)assert.equal(contact(bp,p,bs,s),null,label);
});

test('only a live visible free typed empty Buzzy shell participates in a head crossing',()=>{
 const beforePlayer=mario(),player=mario();
 const invalid=[{type:'koopa'},{shell:false},{emptyShell:false},{dead:true},{removed:true},{hidden:true},{clawHeld:true},{vehicleId:'clown-car'},{moduleEmergence:{remainingFrames:1}},{emerge:1}];
 for(const patch of invalid)assert.equal(contact(beforePlayer,player,emptyShell(patch),emptyShell({...patch,y:100,vy:40})),null,JSON.stringify(patch));
 for(const patch of [{dead:true},{dying:true},{hidden:true},{removed:true},{helmet:'buzzy'}])assert.equal(contact(mario(patch),mario(patch),emptyShell(),emptyShell({y:100,vy:40})),null,JSON.stringify(patch));
});

test('release or emergence in the same sweep cannot equip from a previously constrained shell pose',()=>{
 const beforePlayer=mario(),player=mario(),shell=emptyShell({y:100,vy:40});
 for(const patch of [{moduleEmergence:{remainingFrames:1}},{emerge:1},{clawHeld:true},{vehicleId:'clown-car'},{hidden:true},{dead:true},{removed:true},{taken:true}])assert.equal(contact(beforePlayer,player,emptyShell(patch),shell),null,JSON.stringify(patch));
});

test('head crossing uses Mario’s actual current body height for small, Super and Fire forms',()=>{
 for(const [power,h]of [[0,14],[1,28],[2,28]]){
  const beforePlayer=mario({power,h,y:224-h}),player={...beforePlayer},beforeShell=emptyShell({y:160}),shell=emptyShell({y:220,vy:60});
  checkHeadContact(contact(beforePlayer,player,beforeShell,shell),beforePlayer,player,beforeShell,shell,(224-h-176)/60);
 }
});

for(const power of [0,1,2])test(`natural down-pipe supply equips ordinary ${['small','Super','Fire'][power]} Mario with no Down input or defeat reward`,()=>{
 const d=emptyShellProject({coins:[]});d.rooms[0].map.objects[0].x=107;
 const s=nativeSession(d,{initialState:{lives:3,power,score:1234}}),start=s.view().p;
 s.until(v=>v.p.helmet==='buzzy',{},80);const v=s.view(),worn=s.events.filter(e=>e.type==='smm2-item'&&e.event==='helmet-worn');
 assert.equal(worn.length,1);assert.equal(worn[0].source,'empty-beetle-shell');assert.equal(worn[0].actorId,'module-enemy-empty-supply-0');assert.equal(worn[0].helmet,'buzzy');
 assert(worn[0].contact.fraction>=0&&worn[0].contact.fraction<=1);near(worn[0].contact.point.y,start.y);
 const preceding=s.trace[worn[0].frame-2].enemies.find(e=>e.id===worn[0].actorId);assert(preceding&&!preceding.moduleEmergence);assert(preceding.y+preceding.h<=start.y);
 assert.equal(v.enemies.length,0);assert.equal(v.p.power,power);assert.equal(v.p.h,start.h);assert.equal(v.p.y,start.y);assert.equal(v.p.crouch,false);
 assert.equal(v.score,1234);assert.equal(v.lives,3);assert.equal(v.health,1);assert.equal(v.coins,0);assert.equal(v.items.filter(a=>['enemy-death','score-pop'].includes(a.kind)).length,0);
 assert.equal(s.events.filter(e=>e.type==='sound'&&e.event==='powerup').length,1);assert.equal(s.events.filter(e=>['player-kick','stomp','kick','hurt','death','enemy-key-released'].includes(e.event)).length,0);
 assert(s.inputs.every(input=>!input.down),'ordinary idle input never requests Down');s.frames(80);
 assert.equal(s.events.filter(e=>e.event==='helmet-worn').length,1);assert.equal(s.events.filter(e=>e.type==='sound'&&e.event==='powerup').length,1);assert.equal(s.view().p.helmet,'buzzy');assert.equal(s.view().score,1234);
});

test('wearing one supplied shell is idempotent and a second supply remains a live unconsumed shell',()=>{
 const d=emptyShellProject({coins:[],maxAlive:1,maxEmissions:2});d.rooms[0].map.objects[0].x=107;
 const s=nativeSession(d);s.until(v=>v.p.helmet==='buzzy',{},80);assert.equal(s.view().enemies.length,0);
 s.until(v=>v.marioModules.enemySources[0].emitted===2&&v.enemies.some(e=>!e.moduleEmergence&&e.y+e.h>v.p.y),{},80);
 const v=s.view(),second=v.enemies.find(e=>e.id==='module-enemy-empty-supply-1');assert.ok(second);assert.equal(second.dead,false);assert.equal(second.emptyShell,true);assert.equal(second.shell,true);assert.equal(v.p.helmet,'buzzy');
 assert.equal(s.events.filter(e=>e.event==='helmet-worn').length,1);assert.equal(s.events.filter(e=>e.type==='sound'&&e.event==='powerup').length,1);assert.equal(v.items.filter(a=>a.kind==='enemy-death').length,0);
});

test('Mario descending from above a supplied shell takes the normal stomp-kick path',()=>{
 const d=emptyShellProject({direction:'right',coins:[]});Object.assign(d.rooms[0].map.objects[0],{x:131,y:32});const s=nativeSession(d);
 s.until(()=>s.events.some(e=>e.event==='player-kick'),{},120);const v=s.view(),kick=s.events.find(e=>e.event==='player-kick');assert.equal(kick.source,'stomp-kick');assert.equal(v.p.helmet,undefined);assert(v.p.vy<0,'ordinary stomp bounces Mario');
 assert.equal(v.enemies[0].emptyShell,true);assert.equal(Math.abs(v.enemies[0].vx),3.2);assert.equal(s.events.filter(e=>e.event==='helmet-worn').length,0);assert.equal(s.events.filter(e=>e.type==='sound'&&e.event==='powerup').length,0);assert.equal(v.lives,3);
});

test('ordinary side kick of a settled supplied shell still activates physical coin collection',()=>{
 const s=nativeSession(emptyShellProject({coins:[160]}));sideKickEmptyShell(s);s.until(v=>v.coins===1,{x:-1},120);
 assert.equal(s.events.find(e=>e.event==='player-kick').source,'side-kick');assert.equal(s.view().p.helmet,undefined);assert.equal(s.events.filter(e=>e.event==='helmet-worn').length,0);assert.equal(shellPickups(s).length,1);
 const pickup=shellPickups(s)[0],frame=s.trace[pickup.frame-1],coin=s.doc.rooms[0].map.objects.find(o=>o.id===pickup.coinId),shell=frame.enemies.find(e=>e.id===pickup.actorId);assert(overlaps(shell,coin));assert.equal(overlaps(frame.p,coin),false);
});

test('automatic source motion crossing a coin never acquires player collection ownership',()=>{
 const d=emptyShellProject({coins:[160],vx:2}),coin=d.rooms[0].map.objects.find(o=>o.kind==='coin'),s=nativeSession(d);s.frames(75);
 const crossings=s.trace.filter(v=>v.enemies.some(e=>!e.moduleEmergence&&e.emptyShell&&Math.abs(e.vx)>1&&overlaps(e,coin)));assert(crossings.length>0,'a real supplied shell physically crosses the coin');assert(crossings.every(v=>!overlaps(v.p,coin)));
 assert.equal(s.view().coins,0);assert.equal(s.view().smm2Mechanics.pinkCoins.taken,0);assert.equal(s.view().objects.some(o=>o.id===coin.id),true);assert.equal(shellPickups(s).length,0);assert.equal(s.events.filter(e=>e.event==='player-kick').length,0);assert.equal(s.events.filter(e=>e.event==='helmet-worn').length,0);assert.equal(s.view().p.helmet,undefined);
});

test('pipe-only acquired helmet retains genuine Thwomp head protection without fabricating a placed item',()=>{
 const d=emptyShellProject({coins:[]}),r=d.rooms[0];r.map.objects[0].x=107;const s=nativeSession(d);s.until(v=>v.p.helmet==='buzzy',{},80);
 const player=s.view().p,items=createSmm2Items(r),supplied=s.trace.at(-2).enemies[0];assert.ok(items,'the helmet contact controller exists even with no preplaced item leaves');
 assert.equal(items.ownsActor(supplied),false);assert.equal(items.ownsActor(r.map.objects[0]),false);assert.deepEqual(items.view([supplied,...r.map.objects]).actors,[]);assert.equal(s.view().items.length,0);
 const sourceSnapshot=structuredClone(supplied);assert.equal(items.decorateActor(supplied),supplied);assert.deepEqual(supplied,sourceSnapshot,'the source remains an ordinary enemy actor');
 const thwompRoom=structuredClone(r),thwomp={id:'head-test-thwomp',kind:'walker',x:104,y:176,w:16,h:24,vx:0,vy:0,dead:false};
 thwompRoom.map.objects.push({...thwomp});thwompRoom.smm2Mechanics.thwomps=[{id:thwomp.id,direction:'down',triggerRange:160,transverseTolerance:0,leadReference:'near-edge',windupFrames:0,chargeAcceleration:8,chargeSpeedCap:64,impactWaitFrames:30,returnSpeed:2,breakMaterials:[]}];
 const thwomps=createSmm2Thwomps(thwompRoom);let protection=null,contactTick=null;
 for(let tick=1;tick<=4;tick++){
  const hazardBefore={...thwomp};items.beginFrame({tick,actors:[],player});thwomps.stepEnemy(thwomp,{tick,player,geometry:thwompRoom.map.geometry});
  const result=items.helmetContact(player,{...player},thwomp,{tick,hazardBefore});if(result.protected){protection=result;contactTick=tick;assert(hazardBefore.y+hazardBefore.h<=player.y);assert(thwomp.y+thwomp.h>=player.y);break;}
 }
 assert.ok(protection,'real authored Thwomp charge crosses the acquired helmet’s head');assert.equal(thwomp.type,'smm2-thwomp');assert.equal(protection.action,'request-return');assert.equal(protection.consumeHelmet,false);near(protection.contact.point.y,player.y);
 assert.equal(thwomps.requestReturn(thwomp,{tick:contactTick,contact:protection.contact}),true);assert.equal(thwomp.smm2Thwomp.phase,'return');assert.equal(thwomp.dead,false);assert.equal(player.helmet,'buzzy');assert.deepEqual(items.view().actors,[]);
});
