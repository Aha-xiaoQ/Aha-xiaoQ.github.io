import test from 'node:test';
import assert from 'node:assert/strict';
import {nativeSession} from './fixtures/shell-coin-native.mjs';
import {completionMarksProject} from './fixtures/completion-marks.mjs';
const mark=s=>s.view().smm2Mechanics.completionMarks[0];
const axis=(p,x)=>{const d=x-p.x;return Math.abs(d)<1?(Math.abs(p.vx)<.08?0:-Math.sign(p.vx)):Math.sign(d)*p.vx>0&&Math.abs(d)<p.vx*p.vx/(2*.1015625)+1?-Math.sign(p.vx):Math.sign(d);};
const moveTo=(s,x)=>s.until(v=>Math.abs(v.p.x-x)<2&&Math.abs(v.p.vx)<.15&&v.p.grounded,v=>({x:axis(v.p,x)}),180);
function useDoor(s,roomId){s.frames(35);s.step({});s.until(v=>v.roomId===roomId&&!v.transition,{up:true},100);s.until(v=>v.p.grounded,{},60);}

test('neutral actual Stage marks only true Pink pickup, survives door reentry, and clears with native death respawn and fresh restart',()=>{
 const doc=completionMarksProject({hazard:true}),s=nativeSession(doc);s.until(v=>v.p.grounded,{},60);assert.equal(mark(s).completed,false);useDoor(s,'reward-sandbox');moveTo(s,35);useDoor(s,'entry-lobby');assert.equal(mark(s).completed,false,'merely visiting the reward room does not mark the door');assert.equal(s.view().smm2Mechanics.pinkCoins.taken,0);
 useDoor(s,'reward-sandbox');moveTo(s,80);assert.equal(s.view().smm2Mechanics.pinkCoins.taken,1);moveTo(s,35);useDoor(s,'entry-lobby');assert.equal(mark(s).completed,true);assert.equal(s.view().contraptions.keys,1);
 useDoor(s,'reward-sandbox');assert(!s.view().objects.some(q=>q.id==='reward-pink'));moveTo(s,35);useDoor(s,'entry-lobby');assert.equal(mark(s).completed,true);
 const oldLives=s.view().lives;s.until(v=>v.p.dying,{x:1},200);assert.equal(s.view().lives,oldLives-1);assert.equal(mark(s).completed,true,'death animation follows the still-live native identity until respawn');s.frames(110);assert(s.stage.continueFromCurrent());assert.equal(s.view().roomId,'entry-lobby');assert.equal(s.view().smm2Mechanics.pinkCoins.taken,0);assert.equal(mark(s).completed,false);assert.equal(s.view().contraptions.keys,0);
 useDoor(s,'reward-sandbox');assert(s.view().objects.some(q=>q.id==='reward-pink'));moveTo(s,80);moveTo(s,35);useDoor(s,'entry-lobby');assert.equal(mark(s).completed,true);const fresh=nativeSession(doc);assert.equal(mark(fresh).completed,false);assert.equal(fresh.view().smm2Mechanics.pinkCoins.taken,0);
});

test('neutral native Stage without the optional leaf adds no completion mark view field',()=>{
 const s=nativeSession(completionMarksProject({marks:false}));assert.equal(Object.hasOwn(s.view().smm2Mechanics,'completionMarks'),false);s.frames(30);assert.equal(Object.hasOwn(s.view().smm2Mechanics,'completionMarks'),false);
});
