import test from 'node:test';
import assert from 'node:assert/strict';
import {blank} from '../atlas/editor-model.mjs';
import {createPlatformStage} from '../atlas/editor-mario-stage.mjs';
import {nativeSession,shellProject} from './fixtures/shell-coin-native.mjs';

// Neutral authored fixtures exercise native Stage inputs. No actor, source
// clock, room registry, inventory, or player state is changed during a run.
const variant=()=>({kind:'walking-koopa',color:'red',size:'normal',walkSpeed:.5,direction:1,flippedRecoveryFrames:550,shellRecoveryFrames:600,stompPoints:200,kickPoints:200,bumpPoints:200,sourceParameterStatus:'authored-not-calibrated'});
const supplier=(extra={})=>({id:'koopa-source',pipeId:'pipe',enemy:'koopa',smart:true,direction:'right',intervalFrames:150,initialDelayFrames:0,maxAlive:1,maxEmissions:null,activationDistance:0,vx:.5,vy:0,emergenceFrames:24,actorVariant:variant(),...extra});
const modules=source=>({version:1,itemSources:[],enemySources:[source],noteBlocks:[],oneWayWalls:[],enemyVariants:{}});
const axis=(p,x)=>{const d=x-p.x;return Math.abs(d)<1?(Math.abs(p.vx)<.08?0:-Math.sign(p.vx)):Math.sign(d)*p.vx>0&&Math.abs(d)<p.vx*p.vx/(2*.1015625)+1?-Math.sign(p.vx):Math.sign(d);};
const walk=(s,x,limit=400)=>s.until(v=>Math.abs(v.p.x-x)<2&&Math.abs(v.p.vx)<.15&&v.p.grounded,v=>({x:axis(v.p,x),run:true}),limit);
const source=s=>s.view().marioModules.enemySources[0];
const actor=s=>s.view().enemies.find(e=>e.moduleSource==='koopa-source');
const emissions=s=>s.events.filter(e=>e.type==='mario-module'&&e.event==='enemy-source'&&e.sourceId==='koopa-source');
const cap=s=>{for(const v of s.trace)assert(v.enemies.filter(e=>e.moduleSource==='koopa-source'&&!e.dead).length<=1,'one live source actor at frame '+v.frame);};
function paired({initialOn=true,activationDistance=0,hazard=false}={}){
 const d=blank('Neutral paired source retry',768,432),hub=d.rooms[0],r=structuredClone(blank('Neutral source chamber',768,432).rooms[0]);r.roomId='source-room';
 for(const q of [hub,r]){q.map.geometry=[{id:'floor',x:0,y:392,w:768,h:40,collision:'solid',material:'ground'}];q.map.objects=[{id:'arrival',kind:'spawn',x:35,y:378,w:10,h:14}];q.playRules={version:1,timeLimit:600,timerFrames:60,viewportWidth:384,viewportHeight:216,cameraAnchor:208};q.switchStudy={version:1,initialOn,allowBacktracking:true,devices:[]};q.contraptions={version:1,doors:[]};}
 hub.map.objects.push({id:'entry',kind:'portal',x:32,y:360,w:16,h:32,targetRoom:r.roomId,targetSpawn:'arrival'});hub.contraptions.doors.push({id:'entry',pairId:'paired-source',style:'plain'});hub.switchStudy.devices.push({id:'hub-switch',kind:'switch',x:64,y:352,w:16,h:16});
 r.map.objects.push({id:'return',kind:'portal',x:32,y:360,w:16,h:32,targetRoom:hub.roomId,targetSpawn:'arrival'});r.contraptions.doors.push({id:'return',pairId:'paired-source',style:'plain'});r.map.geometry.push({id:'pipe',x:80,y:288,w:32,h:32,collision:'solid',material:'pipe-side'},{id:'supply-ledge',x:112,y:320,w:224,h:16,collision:'solid',material:'ground'});r.marioModules=modules(supplier({activationDistance}));
 if(hazard)r.map.objects.push({id:'death-hazard',kind:'hazard',x:100,y:378,w:16,h:14});d.rooms.push(r);return d;
}
function session(d){return nativeSession(d,{Stage:args=>createPlatformStage({...args,manualDeath:false})});}
function door(s,target){s.frames(32);return s.until(v=>v.roomId===target&&!v.transition,()=>({up:s.inputs.length%2===0}),150);}
function checkEmergence(s,afterFrame=0){const emitted=emissions(s).filter(e=>e.frame>afterFrame).at(-1);assert(emitted);const first=s.trace[emitted.frame-1].enemies.find(e=>e.id===emitted.actorId);assert(first?.moduleEmergence?.remainingFrames>0);assert.equal(first.moduleEmergence.totalFrames,24);assert.equal(first.moduleEmergence.targetX,112);assert.equal(first.moduleEmergence.targetY,296);assert.equal(first.moduleSource,'koopa-source');assert.equal(first.smm2WalkingKoopa.phase,'walking');return emitted;}

for(const initialOn of [true,false])test('native paired reentry clears supplier and preserves inherited '+(initialOn?'OFF':'ON')+' global state',()=>{
 const s=session(paired({initialOn}));try{
  door(s,'source-room');s.frames(320);assert.equal(source(s).emitted,0);assert.equal(source(s).active,false);
  walk(s,84);walk(s,67);s.frames(30);const first=checkEmergence(s);assert.equal(source(s).emitted,1);
  walk(s,35);door(s,'main');walk(s,67);s.frames(2);s.until(v=>v.switchStudy.on!==initialOn,{jump:true},50);s.until(v=>v.p.grounded,{},100);walk(s,35);const before=s.inputs.length;door(s,'source-room');assert.equal(s.view().switchStudy.on,!initialOn);assert.equal(source(s).emitted,0);assert.equal(source(s).active,false);
  s.frames(320);assert.equal(source(s).emitted,0);walk(s,84);walk(s,67);s.frames(30);const fresh=checkEmergence(s,before);assert(fresh.frame>first.frame);assert.equal(source(s).emitted,1);assert.equal(emissions(s).length,2);assert(!s.view().p.dying);cap(s);
 }finally{s.stage.dispose();}
});

test('authored activation range supplies a real fresh emerging actor at each native door entry',()=>{
 const s=session(paired({activationDistance:45}));try{
  door(s,'source-room');s.step({});const first=checkEmergence(s);assert.equal(source(s).emitted,1);s.frames(180);assert.equal(source(s).emitted,1);
  door(s,'main');const before=s.inputs.length;door(s,'source-room');s.step({});const fresh=checkEmergence(s,before);assert.equal(fresh.actorId,first.actorId,'serial reuse after a genuine reset is valid');assert.equal(source(s).emitted,1);s.frames(180);assert.equal(source(s).emitted,1);cap(s);
 }finally{s.stage.dispose();}
});

function lifecycleFixture({width=640,wall=true,fall=false}={}){
 const d=shellProject({coins:[],wall}),r=d.rooms[0];r.map.width=width;r.map.objects=r.map.objects.filter(q=>q.kind==='spawn');r.markers=[];Object.assign(r.map.objects[0],{x:96,y:210});r.map.geometry[0].w=width;
 r.map.geometry.push({id:'pipe',x:192,y:128,w:32,h:32,collision:'solid',material:'pipe-side'});const q=supplier({direction:'left',activationDistance:320,vx:-.5});q.actorVariant.direction=-1;r.marioModules=modules(q);
 if(fall){r.map.geometry=r.map.geometry.filter(g=>g.id!=='floor'&&g.id!=='wall');r.map.geometry.push({id:'player-floor',x:0,y:224,w:112,h:64,collision:'solid',material:'ground'},{id:'enemy-ledge',x:144,y:224,w:96,h:16,collision:'solid',material:'ground'});q.actorVariant.avoidLedges=false;}
 return d;
}

test('native supplied Koopa stomp, kick, rebound, descending stop and recovery stay in maxAlive',()=>{
 const s=session(lifecycleFixture());try{
  s.frames(45);walk(s,120);s.until(v=>actor(s).x-v.p.x<25,{},200);s.step({jump:true});let n=0;s.until(()=>actor(s)?.shell,()=>({jump:n++<30}),100);const id=actor(s).id;assert.equal(actor(s).vx,0);assert.equal(source(s).emitted,1);
  s.until(v=>v.p.grounded,{x:-1},100);s.until(()=>actor(s).vx>1,{x:1,run:true},150);s.until(v=>v.p.grounded&&v.p.x<80,{x:-1,run:true},100);walk(s,70);s.until(v=>actor(s).vx<0&&actor(s).x-v.p.x<=140,{},500);s.step({jump:true});n=0;s.until(()=>Math.abs(actor(s)?.vx??1)<.1&&actor(s)?.shell,()=>({jump:n++<30}),100);
  assert(s.events.some(e=>e.type==='smm2-koopa'&&e.event==='walking-koopa-shell-stopped'));const stopTick=s.view().tick;s.until(v=>v.p.grounded,{x:1,run:true},150);s.until(()=>actor(s)?.smm2WalkingKoopa.phase==='walking',{},650);assert(s.view().tick-stopTick>=600);assert.equal(actor(s).id,id);assert.equal(source(s).emitted,1);assert.equal(emissions(s).length,1);assert(!s.view().p.dying);cap(s);
 }finally{s.stage.dispose();}
});

test('a real fall retires the actor and permits timed replacement without runtime edits',()=>{
 const s=session(lifecycleFixture({wall:false,fall:true}));try{
  s.frames(1);const first=actor(s).id;let fell=false,gone=false;for(let n=0;n<650&&source(s).emitted<3;n++){const v=s.step({}),e=v.enemies.find(e=>e.id===first);fell||=!!e&&e.y>288;gone||=!e;}
  assert(fell);assert(gone);assert.equal(source(s).emitted,3);assert.notEqual(actor(s).id,first);const e=emissions(s);assert(e[1].frame-e[0].frame>=150);assert(e[2].frame-e[1].frame>=150);assert(!s.view().p.dying);cap(s);
 }finally{s.stage.dispose();}
});

test('native offscreen pruning releases the source slot while preserving the 150 frame interval',()=>{
 const d=lifecycleFixture({width:1280,wall:false});d.rooms[0].map.objects[0].x=240;const s=session(d);try{
  s.step({});const first=actor(s).id;s.until(v=>v.p.x>760,{x:1,run:true},350);assert(!s.view().enemies.some(e=>e.id===first));s.until(()=>source(s).emitted>=3,{},350);const e=emissions(s);for(let n=1;n<e.length;n++)assert(e[n].frame-e[n-1].frame>=150);assert(!s.view().p.dying);cap(s);
 }finally{s.stage.dispose();}
});

test('real native life loss resets source and a subsequent paired entry actually emits again',()=>{
 const s=session(paired({activationDistance:45,hazard:true}));try{
  door(s,'source-room');s.step({});checkEmergence(s);s.until(v=>!!v.p.dying,{x:1,run:true},100);assert.equal(s.view().lives,2);const death=s.inputs.length;s.until(v=>v.roomId==='main'&&!v.p.dying,{},180);door(s,'source-room');s.step({});checkEmergence(s,death);assert.equal(source(s).emitted,1);assert.equal(s.view().lives,2);assert.equal(emissions(s).length,2);cap(s);
 }finally{s.stage.dispose();}
});
