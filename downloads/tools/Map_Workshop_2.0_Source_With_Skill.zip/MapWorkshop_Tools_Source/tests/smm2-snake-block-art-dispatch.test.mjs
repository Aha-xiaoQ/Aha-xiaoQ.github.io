import test from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createCanvas} from '@napi-rs/canvas';
import {drawTile} from '../atlas/editor-art.mjs';
import {drawSmm2SnakeBlockTile,drawSmwUnderwaterSnakeWorld} from '../atlas/editor-smw-underwater-art.mjs';
import {initialSmm2SnakeBlockGeometry} from '../atlas/editor-snake-block-placement.mjs';
const bytes=c=>c.getContext('2d').getImageData(0,0,c.width,c.height).data;
const sha=c=>createHash('sha256').update(bytes(c)).digest('hex');
const sourceHashes={green:'03daeb6fa6247bc0a9c262e9f9913177d9ff9dd94076a04a23ee88d8b4eae60d',blue:'b560ee4156791089892e002544d6acd8acff4e0abbb5962e2c196bfbadcf5634'};
const room=palette=>({roomId:'main',setting:'Overworld',map:{width:384,height:216,geometry:[],objects:[]},smm2Mechanics:{version:1,art:{palette}}});
for(const color of ['green','blue'])test('formal '+color+' Snake uses exact existing source pixels across authored palettes',()=>{
 for(const palette of ['smb1-overworld-source','smb1-castle-stone','smb3-desert','smw-underwater-source']){
  const c=createCanvas(16,16),r=room(palette),q={x:0,y:0,w:16,h:16,material:'snake-block',smm2SnakeBlock:{version:1,color,phase:'occupied',darkened:false}},before=JSON.stringify({r,q});drawTile(c.getContext('2d'),q,r);assert.equal(sha(c),sourceHashes[color]);assert.equal(JSON.stringify({r,q}),before);
 }
});
test('cross-style endpoint darkening preserves source alpha and shades only visible RGB',()=>{
 for(const color of ['green','blue']){const bright=createCanvas(16,16),dark=createCanvas(16,16),q={x:0,y:0,w:16,h:16,smm2SnakeBlock:{version:1,color,phase:'occupied',darkened:false}};drawTile(bright.getContext('2d'),q,room('smb1-overworld-source'));drawTile(dark.getContext('2d'),{...q,smm2SnakeBlock:{...q.smm2SnakeBlock,phase:'falling',darkened:true}},room('smb1-overworld-source'));const a=bytes(bright),b=bytes(dark);for(let i=0;i<a.length;i+=4){assert.equal(b[i+3],a[i+3]);if(a[i+3])for(let k=0;k<3;k++)assert.equal(b[i+k],Math.round(a[i+k]*.43));}}
});
test('removed Snake and ordinary unbound terrain cannot acquire the source Snake raster',()=>{
 const c=createCanvas(16,16),ctx=c.getContext('2d');assert.equal(drawSmm2SnakeBlockTile(ctx,{x:0,y:0,w:16,h:16,material:'stone'}),false);assert.equal(drawSmm2SnakeBlockTile(ctx,{x:0,y:0,w:16,h:16,smm2SnakeBlock:{color:'blue',phase:'removed'}}),true);assert(bytes(c).every(q=>q===0));
});
test('non-underwater native editor effect preview matches formal initial occupied cells without advancing author state',()=>{
 const r=room('smb1-overworld-source');r.smm2Mechanics.snakeBlocks={version:1,trains:[{id:'neutral-snake',color:'green',origin:{x:16,y:32},path:[{id:'start',x:0,y:0},{id:'turn',x:64,y:0},{id:'finish',x:64,y:-32}],lengthCells:4,speedPxPerTick:1,initialHeadDistancePx:48,activation:'player-top',endpointHoldFrames:0,collapseIntervalFrames:5,collapseGravity:.25,collapseFallCap:5,collapseOrder:'tail-to-head'}]};
 const a=createCanvas(128,80),b=createCanvas(128,80),before=JSON.stringify(r);assert.equal(drawSmwUnderwaterSnakeWorld(a.getContext('2d'),r),true);for(const q of initialSmm2SnakeBlockGeometry(r))drawTile(b.getContext('2d'),q,r);assert.deepEqual(bytes(a),bytes(b));assert.equal(JSON.stringify(r),before);
});
