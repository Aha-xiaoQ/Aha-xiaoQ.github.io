import test from 'node:test';
import assert from 'node:assert/strict';
import {guardProject} from './fixtures/chain-chomp-neutral.mjs';
import {nativeSession} from './fixtures/shell-coin-native.mjs';
import {resolveSmm2LightSources} from '../atlas/editor-smm2-lighting.mjs';
const dog=s=>s.view().enemies.find(e=>e.id==='guard-head');
const runJump=(tick,start)=>({x:tick>=start?1:0,run:true,jump:tick>=start&&tick<start+64});

test('native Small can read the cue and cross using a nineteen-frame ordinary-input jump window',()=>{
 for(let start=48;start<=66;start++){
  const s=nativeSession(guardProject()),saved=JSON.stringify(s.doc);for(let tick=1;tick<=180&&s.view().p.x<195;tick++){const v=s.step(runJump(tick,start));assert(!v.p.dying,'ordinary crossing start '+start+' tick '+tick);assert.equal(v.p.power,0);assert.equal(v.lives,5);assert.equal(v.p.invulnerable,0);const a=dog(s);assert(a);assert(Math.hypot(a.x+16-80,a.y+16-376)<=72+1e-7);const light=resolveSmm2LightSources(s.doc.rooms[0],v).find(q=>q.targetId==='guard-head');assert.deepEqual({x:light.x,y:light.y},{x:a.x+16,y:a.y+16});}
  assert(s.view().p.x>=195);assert.equal(s.events.filter(e=>e.event==='head-contact').length,0);assert.equal(JSON.stringify(s.doc),saved);s.stage.dispose();
 }
});

test('native full successful route physically collects the coin and completes the legal exit walk',()=>{
 const s=nativeSession(guardProject());s.until(v=>v.completed,(_v)=>runJump(s.inputs.length+1,52),650);assert.equal(s.view().coins,1);assert.equal(s.view().lives,5);assert(!s.view().p.dying);assert(s.inputs.every(i=>Object.keys(i).every(k=>['x','run','jump'].includes(k))));assert.equal(s.events.filter(e=>e.type==='complete').length,1);assert(dog(s));s.stage.dispose();
});

test('native flat rush and prolonged waiting die on real head contact; generic stomping never kills the guard',()=>{
 const rush=nativeSession(guardProject());rush.until(v=>v.p.dying,{x:1,run:true},90);assert.equal(rush.inputs.length,39);assert.equal(rush.view().lives,4);assert(dog(rush));assert.equal(rush.events.filter(e=>e.event==='head-contact').length,1);assert.equal(rush.events.filter(e=>e.event==='death').length,1);assert.equal(rush.view().score,0);
 const wait=nativeSession(guardProject());wait.until(v=>v.p.dying,{},180);assert(wait.inputs.length>=78&&wait.inputs.length<=96);assert(dog(wait));assert(wait.events.some(e=>e.event==='head-contact'&&e.phase==='lunge'));
 const fall=nativeSession(guardProject({spawnX:99,spawnY:280}));fall.until(v=>v.p.dying,{},100);assert(dog(fall));assert.equal(fall.view().score,0);assert(!fall.events.some(e=>e.event==='stomp'));for(const s of [rush,wait,fall])s.stage.dispose();
});

test('native pause, pure reads and real death/continue leave one resettable guard actor',()=>{
 const s=nativeSession(guardProject());s.frames(56);const reading=JSON.stringify(s.view());for(let i=0;i<10;i++)assert.equal(JSON.stringify(s.view()),reading);s.stage.pause();const paused=JSON.stringify(dog(s));s.frames(20);assert.equal(JSON.stringify(dog(s)),paused);s.stage.resume();s.step({});assert.equal(dog(s).chainChompGuard.phaseFrame,9);
 s.until(v=>v.p.dying,{},100);const dead=JSON.stringify(dog(s));s.frames(110);assert.equal(JSON.stringify(dog(s)),dead);assert(s.stage.continueFromCurrent());const fresh=dog(s);assert.equal(fresh.chainChompGuard.phase,'idle');assert.equal(fresh.chainChompGuard.phaseFrame,0);assert.equal(fresh.chainChompGuard.cycle,0);assert.equal(fresh.x,88);assert.equal(fresh.y,360);assert.equal(s.view().lives,4);assert.equal(s.view().enemies.filter(e=>e.id==='guard-head').length,1);s.stage.dispose();
});
