import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {isSmb3ArtRoom,drawSmb3Background,drawSmb3Tile,drawSmb3Slope,drawSmb3Actor,drawSmb3Player,drawSmb3Spring,drawSmb3BluePlatform,drawSmb3OneWayWall,drawSmb3Checkpoint,drawSmb3Goal,drawSmb3Scenery,drawSmb3World} from '../atlas/editor-smb3-art.mjs';
import {drawSmm2Background,drawSmm2Tile,drawSmm2Actor,drawSmm2World} from '../atlas/editor-smm2-art.mjs';
import {drawPlayer,drawObject,drawScenery} from '../atlas/editor-art.mjs';
import {drawContraptionsScene} from '../atlas/editor-contraptions-art.mjs';
import {sourcePixels} from '../atlas/source-art.mjs';
const require=createRequire(import.meta.url);let createCanvas;try{({createCanvas}=require('@napi-rs/canvas'));}catch{}
const raster=(name,fn)=>test(name,{skip:!createCanvas},fn);
const room=()=>({smm2Mechanics:{version:1,art:{palette:'smb3-underground'}},map:{width:384,height:240,geometry:[],objects:[]}});
const canvas=(w=192,h=144)=>createCanvas(w,h),data=c=>c.getContext('2d').getImageData(0,0,c.width,c.height).data;
const pixel=(c,x,y)=>[...c.getContext('2d').getImageData(x,y,1,1).data];
const count=c=>{let n=0;const bytes=data(c);for(let i=3;i<bytes.length;i+=4)if(bytes[i])n++;return n;};
const draw=(fn,q,r=room(),tick=0)=>{const c=canvas();assert.equal(fn(c.getContext('2d'),q,tick,r),true);return c;};
function opaque(c){const bytes=data(c);for(let i=3;i<bytes.length;i+=4)assert.ok(bytes[i]===0||bytes[i]===255,'all source pixels lie on the integer grid');}
function inside(c,q){const bytes=data(c);for(let y=0;y<c.height;y++)for(let x=0;x<c.width;x++)if(bytes[(y*c.width+x)*4+3])assert.ok(x>=q.x&&x<q.x+q.w&&y>=q.y&&y<q.y+q.h,'primitive respects the supplied rectangle');}

test('SMB3 profile requires explicit version and palette',()=>{
 assert.equal(isSmb3ArtRoom(room()),true);
 for(const r of [{},{smm2Mechanics:{version:2,art:{palette:'smb3-underground'}}},{smm2Mechanics:{version:1,art:{palette:'smb1-shoe-underworld'}}}])assert.equal(isSmb3ArtRoom(r),false);
});
raster('all dispatch paths leave ordinary native rooms untouched',()=>{
 const c=canvas(),ctx=c.getContext('2d'),q={x:32,y:32,w:16,h:16,material:'ground',kind:'mushroom'};
 for(const r of [{},{smm2Mechanics:{version:1,art:{palette:'smb1-castle-stone'}}}]){
  assert.equal(drawSmb3Background(ctx,r,192,144),false);assert.equal(drawSmb3Tile(ctx,q,r),false);assert.equal(drawSmb3Actor(ctx,q,0,r),false);assert.equal(drawSmb3Player(ctx,{...q,power:0},0,r),false);assert.equal(drawSmb3Scenery(ctx,{...q,smm2Art:'smb3-outline-hill'},r),false);assert.equal(drawSmb3World(ctx,r,{smm2Mechanics:{version:1}}),false);
 }assert.equal(count(c),0);
});
raster('diagonal ground remains continuous across independently authored rectangles',()=>{
 const r=room(),whole=canvas(),split=canvas(),ctx=split.getContext('2d');
 assert.equal(drawSmb3Tile(whole.getContext('2d'),{x:19,y:23,w:73,h:41,material:'ground'},r),true);
 for(const q of [{x:19,y:23,w:25,h:41},{x:44,y:23,w:48,h:41}])assert.equal(drawSmb3Tile(ctx,{...q,material:'ground'},r),true);
 assert.deepEqual(data(whole),data(split));assert.equal(count(whole),73*41);opaque(whole);inside(whole,{x:19,y:23,w:73,h:41});
});
raster('live upper and lower slope polygons retain their real transparent sides',()=>{
 for(const orientation of ['rise-left','rise-right','ceiling-rise-left','ceiling-rise-right']){
  const c=canvas(),q={x:16,y:16,w:64,h:48,orientation};assert.equal(drawSmb3Slope(c.getContext('2d'),q),true);assert.equal(count(c),64*48/2);opaque(c);inside(c,q);
  assert.equal(pixel(c,48,18)[3],orientation.startsWith('ceiling-')?255:0);assert.equal(pixel(c,48,61)[3],orientation.startsWith('ceiling-')?0:255);
 }
 const c=canvas(),q={kind:'slope',spec:{x:16,y:16,w:64,h:48,orientation:'rise-right'},polygon:[{x:16,y:16},{x:80,y:16},{x:16,y:64}],solidAbove:true};
 assert.equal(drawSmb3World(c.getContext('2d'),room(),{smm2Mechanics:{version:1,surfaces:[q]}}),true);assert.equal(pixel(c,48,18)[3],255);assert.equal(pixel(c,48,61)[3],0);
});
raster('upright and horizontal green springs preserve open coils and actual compression bounds',()=>{
 for(const q of [{x:16,y:16,w:16,h:24},{x:48,y:16,w:16,h:10,springAge:6},{x:80,y:16,w:24,h:16,springOrientation:'horizontal'}]){
  const c=canvas(),before=JSON.stringify(q);assert.equal(drawSmb3Spring(c.getContext('2d'),q),true);inside(c,q);opaque(c);assert.equal(JSON.stringify(q),before);assert(count(c)<q.w*q.h);
 }
});
raster('blue fall lift, orange directional wall, checkpoint and four real card states are original bounded primitives',()=>{
 const q={x:32,y:32,w:32,h:32};
 for(const fn of [drawSmb3BluePlatform,drawSmb3OneWayWall,drawSmb3Checkpoint]){const c=canvas();assert.equal(fn(c.getContext('2d'),q),true);inside(c,q);opaque(c);}
 const hashes=[];
 for(const cardState of ['mushroom','flower','star','life']){
  const c=canvas();assert.equal(drawSmb3Goal(c.getContext('2d'),{...q,cardState}),true);inside(c,q);opaque(c);assert.equal(pixel(c,32,32)[3],255);assert.equal(pixel(c,35,35)[3],255);hashes.push(Buffer.from(data(c)).toString('base64'));
 }assert.equal(new Set(hashes).size,4);
});
raster('same-ID card dispatch freezes the supplied controller result and consumes hidden actors',()=>{
 const r=room(),q={id:'card',kind:'exit',x:32,y:32,w:32,h:32};r.smm2Mechanics.goalCard={id:'card',framesPerCard:8,cycle:['mushroom','flower','star','life']};
 r.finish={card:true,result:'life',phase:'card-reveal'};const before=JSON.stringify({r,q}),early=draw(drawSmb3Actor,q,r,0),late=draw(drawSmb3Actor,q,r,99);assert.deepEqual(data(early),data(late));assert.equal(JSON.stringify({r,q}),before);
 const off=canvas();assert.equal(drawSmb3Actor(off.getContext('2d'),{...q,hidden:true},0,r),true);assert.equal(count(off),0);
 const unknown=canvas();assert.equal(drawSmb3Actor(unknown.getContext('2d'),{...q,id:'other'},0,r),false);assert.equal(count(unknown),0);
});
raster('Small, Big, run, jump, claw hold, hurt, star and death use real player flags without mutation',()=>{
 const r=room(),base={x:40,y:32,w:10,h:14,power:0,facing:1,grounded:true,vx:0},hashes=[];
 for(const patch of [{},{power:1,h:28},{power:1,h:28,vx:2,anim:0},{power:1,h:28,vx:2,anim:12},{grounded:false},{power:1,h:28,grounded:false,clawHeld:true},{star:30},{power:1,h:28,invulnerable:16},{dying:20,grounded:false}]){
  const q={...base,...patch},before=JSON.stringify(q),c=draw(drawSmb3Player,q,r,8);opaque(c);assert(count(c)>0);hashes.push(Buffer.from(data(c)).toString('base64'));assert.equal(JSON.stringify(q),before);
 }assert(new Set(hashes).size>=7);
 const hidden=canvas();assert.equal(drawSmb3Player(hidden.getContext('2d'),{...base,invulnerable:16},4,r),true);assert.equal(count(hidden),0);
 const normal=draw(drawSmb3Player,base,r,0),mirror=draw(drawSmb3Player,{...base,facing:-1},r,0);for(let y=30;y<46;y++)for(let x=37;x<53;x++)assert.deepEqual(pixel(normal,x,y),pixel(mirror,89-x,y));
});
raster('finish hills are outlines with transparent interiors',()=>{
 const r=room(),c=canvas(),q={x:32,y:16,w:40,h:80,smm2Art:'smb3-outline-hill'};assert.equal(drawSmb3Scenery(c.getContext('2d'),q,r),true);inside(c,q);opaque(c);assert.equal(pixel(c,32,50)[3],255);assert.equal(pixel(c,52,50)[3],0);assert(count(c)<200);
});
raster('source-scale facets repeat every eight native pixels and scenery never paints a fallback body',()=>{
 const r=room(),c=canvas();drawSmm2Tile(c.getContext('2d'),{x:32,y:32,w:32,h:32,material:'ground'},r);
 for(let y=32;y<48;y++)for(let x=32;x<48;x++)assert.deepEqual(pixel(c,x,y),pixel(c,x+8,y+8));
 const outline={x:32,y:16,w:40,h:80,material:'decoration',smm2Art:'smb3-outline-hill'},off=canvas();assert.equal(drawSmm2Tile(off.getContext('2d'),outline,r),true);assert.equal(count(off),0,'scenery pass owns the outline; tile pass remains empty');
 const posts=canvas();assert.equal(drawSmm2Tile(posts.getContext('2d'),{x:32,y:32,w:64,h:56,material:'decoration',smm2Art:'smb3-semisolid-posts'},r),true);assert.equal(pixel(posts,42,32)[3],0,'post-only body has no second cap');assert.equal(pixel(posts,38,32)[3],255,'posts begin at their actual declared top');
});
raster('live sixteen-pixel Koopa contact bodies keep tall foot-anchored art and checkpoint poles stay thirty-two pixels high',()=>{
 const r=room(),q={kind:'walker',type:'koopa',x:32,y:48,w:16,h:16},c=draw(drawSmb3Actor,q,r);assert.equal(pixel(c,42,42)[3],255,'live head remains above the narrow contact body');
 const shell=draw(drawSmb3Actor,{...q,shell:true},r);assert.equal(pixel(shell,42,42)[3],0,'only an actual shell omits the tall head');
 const cp=canvas();drawSmb3Checkpoint(cp.getContext('2d'),{x:32,y:16,w:16,h:48});assert.equal(pixel(cp,40,16)[3],0);assert.equal(pixel(cp,40,32)[3],255);assert.equal(pixel(cp,40,63)[3],255);
});
raster('blue falling platform uses right chevrons and only real wing flags add Koopa wings',()=>{
 const q={x:32,y:32,w:48,h:8},lift=canvas();drawSmb3BluePlatform(lift.getContext('2d'),q);assert.notDeepEqual(pixel(lift,34,35),pixel(lift,36,35),'rightward chevrons have a distinct tip');opaque(lift);
 const r=room(),actor={x:64,y:48,w:16,h:16,kind:'walker',type:'koopa'},plain=draw(drawSmb3Actor,actor,r);
 for(const patch of [{source:{winged:true}},{source:{floating:true}},{verticalFlight:true}]){
  const live={...actor,...patch},before=JSON.stringify(live),c=draw(drawSmb3Actor,live,r);assert(count(c)>count(plain));assert.equal(pixel(c,61,50)[3],255,'white wing extends beyond the unchanged contact body');assert.equal(JSON.stringify(live),before);opaque(c);
  const inShell=draw(drawSmb3Actor,{...live,shell:true},r);assert.equal(pixel(inShell,61,50)[3],0,'actual shell state removes wings');
 }
 assert.deepEqual(data(draw(drawSmb3Actor,{...actor,source:{winged:'true'}},r)),data(plain),'truthy labels cannot infer winged state');
});
raster('public renderer entry points route SMB3 before legacy body and world art',()=>{
 const r=room(),q={x:32,y:32,w:32,h:32,material:'ground'},a=canvas(),b=canvas();
 assert.equal(drawSmm2Tile(a.getContext('2d'),q,r),true);assert.equal(drawSmb3Tile(b.getContext('2d'),q,r),true);assert.deepEqual(data(a),data(b));
 const p={x:40,y:32,w:10,h:28,power:1,facing:1,grounded:false,clawHeld:true},pa=canvas(),pb=draw(drawSmb3Player,p,r,8);drawPlayer(pa.getContext('2d'),p,8,undefined,r);assert.deepEqual(data(pa),data(pb));
 const actor={id:'mushroom',kind:'mushroom',x:40,y:48,w:16,h:16},aa=canvas(),ab=draw(drawSmb3Actor,actor,r,8);drawObject(aa.getContext('2d'),actor,8,r);assert.deepEqual(data(aa),data(ab));
 const slope={kind:'slope',spec:{x:32,y:32,w:64,h:48,orientation:'rise-left'}},wa=canvas(),wb=canvas();assert.equal(drawSmm2World(wa.getContext('2d'),r,{smm2Mechanics:{version:1,surfaces:[slope]}},0),true);drawSmb3Slope(wb.getContext('2d'),slope);assert.deepEqual(data(wa),data(wb));
 const ba=canvas(),bb=canvas();drawSmm2Background(ba.getContext('2d'),r,192,144);drawSmb3Background(bb.getContext('2d'),r,192,144);assert.deepEqual(data(ba),data(bb));
 r.decorations=[{x:32,y:16,w:40,h:80,smm2Art:'smb3-outline-hill'}];const sa=canvas(),sb=canvas();drawScenery(sa.getContext('2d'),r);drawSmb3Scenery(sb.getContext('2d'),r.decorations[0],r);assert.deepEqual(data(sa),data(sb));
});
raster('SMB3 claw scenes omit desert backdrop and placed-item previews keep same-ID ownership',()=>{
 const r=room(),c=canvas();r.contraptions={version:1,tracks:[],claws:[]};assert.equal(drawContraptionsScene(c.getContext('2d'),r),true);assert.equal(count(c),0);
 for(const kind of ['life','mushroom','star']){
  const actor={id:'supply-'+kind,kind:'walker',x:32,y:32,w:16,h:16};r.smm2Mechanics.placedItems=[{id:actor.id,kind}];const a=canvas(),b=canvas();assert.equal(drawSmm2Actor(a.getContext('2d'),actor,0,r),true);assert.equal(drawSmb3Actor(b.getContext('2d'),{...actor,kind},0,r),true);assert.deepEqual(data(a),data(b));
  const off=canvas();assert.equal(drawSmm2Actor(off.getContext('2d'),{...actor,hidden:true},0,r),true);assert.equal(count(off),0);
 }
});
raster('new placed-item preview kinds preserve original native atlas pixels in SMB1 rooms',()=>{
 const r={smm2Mechanics:{version:1,art:{palette:'smb1-castle-stone'}},map:{geometry:[]}};
 for(const [kind,type]of [['life','Mushroom1Up'],['mushroom','Mushroom'],['star','Star']]){
  const actor={id:'supply-'+kind,kind:'walker',x:32,y:32,w:16,h:16};r.smm2Mechanics.placedItems=[{id:actor.id,kind}];const c=canvas(),native=sourcePixels('src|Character|'+type+'||');assert.equal(drawSmm2Actor(c.getContext('2d'),actor,0,r),true);
  for(let y=0;y<native.h;y++)for(let x=0;x<native.w;x++)assert.deepEqual(pixel(c,32+x,32+16-native.h+y),native.pixels[y*native.w+x]);
 }
});
