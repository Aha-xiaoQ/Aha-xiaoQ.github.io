import {test} from 'node:test';
import assert from 'node:assert/strict';
import {History,parseProject,deleteSelection,moveSelection} from '../atlas/editor-model.mjs';
import {bindSmm2PowSupport,unbindSmm2PowSupport,captureSmm2ActorLeaves,appendCopiedSmm2ActorLeaves,pruneSmm2DeletedReferences,cloneSmm2Component} from '../atlas/editor-smm2-authoring.mjs';
import {mountSmm2Tools} from '../atlas/editor-smm2-tools.mjs';
import {createSmm2Carriers,validateSmm2CarriersRoom} from '../atlas/editor-smm2-carriers.mjs';
import {createSmm2Items} from '../atlas/editor-smm2-items.mjs';
import {createSmm2Thwomps} from '../atlas/editor-smm2-thwomps.mjs';
import {createPlatformMotor} from '../atlas/editor-mario-motor.mjs';
import {createPlatformStage} from '../atlas/editor-mario-stage.mjs';
import {createCollection,addLevel,parseCollection,serializeCollection,buildCollection} from '../atlas/editor-collection.mjs';
import {resolveSmm2LightSources} from '../atlas/editor-smm2-lighting.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';
import {character,nativeSession} from './fixtures/shell-coin-native.mjs';
import {powCarrierProject,assertNativePowCarrierMotion} from './fixtures/pow-carriers-native.mjs';

function harness(r=powCarrierProject().rooms[0],{isHeld=()=>false}={}){
 const actors=r.map.objects.filter(q=>q.kind==='walker').map(q=>({...q,vx:0,vy:0})),pows=actors.filter(q=>q.id.startsWith('pow-')),enemy=actors.find(q=>q.id==='thwomp'),carriers=createSmm2Carriers(r),items=createSmm2Items(r,{isHeld}),thwomps=createSmm2Thwomps(r);pows.forEach(items.decorateActor);thwomps.decorateEnemy(enemy);let geometry=structuredClone(r.map.geometry);
 return {actors,pows,enemy,items,carriers,r,frame(tick,{player={x:88,y:290,w:10,h:14},moveParent=true}={}){items.beginFrame({tick,actors:pows,player});geometry=items.geometry(geometry,pows);if(moveParent)thwomps.stepEnemy(enemy,{tick,player,geometry:carriers.geometryForActor(geometry,enemy)});geometry=carriers.apply(geometry,actors,{tick});for(const a of pows)items.stepItem(a,{tick,geometry,support:carriers,actors});geometry=items.geometry(geometry,pows);return geometry;}};
}

test('strict opt-in POW supports validate actual initial top and reject rails, non-POWs, unknown or ambiguous bodies',()=>{
 const d=powCarrierProject(),before=JSON.stringify(d);assert.deepEqual(parseProject(before),d);assert.equal(JSON.stringify(d),before);
 for(const change of [r=>r.smm2Mechanics.carrierItems[0].code='move',r=>r.smm2Mechanics.carrierItems.push(r.smm2Mechanics.carrierItems[0]),r=>r.smm2Mechanics.carrierItems[0].carrierId='missing',r=>r.smm2Mechanics.carrierItems[0].carrierId='pow-left',r=>r.smm2Mechanics.carrierItems[0].id='start',r=>r.map.objects.find(q=>q.id==='pow-left').y--,r=>r.map.objects.find(q=>q.id==='pow-left').x=300,r=>r.smm2Mechanics.thwomps=[],r=>r.smm2Mechanics.powBlocks[0].rail={},r=>r.map.objects.push({...r.map.objects[2]})]){const x=powCarrierProject().rooms[0];change(x);assert.throws(()=>validateSmm2CarriersRoom(x));}
 const old=powCarrierProject().rooms[0];delete old.smm2Mechanics.carrierItems;assert.equal(createSmm2Carriers(old),null);
});

test('real native stage twin 16px POWs detach from a fast charge and are picked up by the actual return with live stable lights',()=>{assertNativePowCarrierMotion(powCarrierProject(),{resolve:resolveSmm2LightSources});});

test('POW author support bind/unbind is atomic with History and source data remains a native actor',()=>{
 const d=powCarrierProject();delete d.rooms[0].smm2Mechanics.carrierItems;const h=new History(d),r=()=>h.doc.rooms[0],native=JSON.stringify(r().map);
 h.change(()=>bindSmm2PowSupport(r(),'pow-left','thwomp'));assert.deepEqual(r().smm2Mechanics.carrierItems,[{id:'pow-left',carrierId:'thwomp'}]);h.undo();assert.equal(r().smm2Mechanics.carrierItems,undefined);h.redo();
 const before=JSON.stringify(h.doc);assert.throws(()=>h.change(()=>bindSmm2PowSupport(r(),'pow-left','floor')));assert.equal(JSON.stringify(h.doc),before);h.change(()=>unbindSmm2PowSupport(r(),'pow-left'));assert.deepEqual(r().smm2Mechanics.carrierItems,[]);assert.equal(JSON.stringify(r().map),native);assert.deepEqual(parseProject(JSON.stringify(h.doc)),h.doc);
});

test('native actor group copy remaps both POW support ends; child-only copy and clone stay independent',()=>{
 const h=new History(powCarrierProject()),r=()=>h.doc.rooms[0],ids=new Set(['pow-left','pow-right','thwomp']),snap=captureSmm2ActorLeaves(r(),ids),idMap=new Map([...ids].map(id=>[id,id+'-copy']));
 h.change(()=>{for(const [id,next] of idMap){const q=r().map.objects.find(q=>q.id===id);r().map.objects.push({...q,id:next,x:q.x+160});}appendCopiedSmm2ActorLeaves(r(),snap,idMap);});assert.deepEqual(r().smm2Mechanics.carrierItems.slice(2),[{id:'pow-left-copy',carrierId:'thwomp-copy'},{id:'pow-right-copy',carrierId:'thwomp-copy'}]);assert.deepEqual(parseProject(JSON.stringify(h.doc)),h.doc);
 assert.deepEqual(captureSmm2ActorLeaves(r(),new Set(['pow-left'])).carrierItems,[]);h.change(()=>cloneSmm2Component(r(),'pow-left',{id:'independent-pow',dx:32}));assert(!r().smm2Mechanics.carrierItems.some(q=>q.id==='independent-pow'));
 h.change(()=>moveSelection(r(),'objects',new Set(idMap.values()),16,0));assert.deepEqual(parseProject(JSON.stringify(h.doc)),h.doc);
 h.change(()=>{const before=structuredClone(r());deleteSelection(r(),'objects',new Set(['thwomp-copy']));pruneSmm2DeletedReferences(r(),before);});assert.equal(r().smm2Mechanics.carrierItems.length,2);assert(r().map.objects.some(q=>q.id==='pow-left-copy'));h.undo();assert.equal(r().smm2Mechanics.carrierItems.length,4);h.redo();assert.equal(r().smm2Mechanics.carrierItems.length,2);
});

test('native POW support inspector uses selected actor and restores linkage on undo',()=>{
 const ui=installSimulatedPlayDom();try{const d=powCarrierProject();delete d.rooms[0].smm2Mechanics.carrierItems;const h=new History(d),r=()=>h.doc.rooms[0],parent=ui.document.createElement('aside'),reports=[],panel=mountSmm2Tools({parent,room:r,selected:()=>new Set(['pow-left']),change:fn=>h.change(fn),report:q=>reports.push(q)}),get=id=>parent.querySelector('[data-smm2-control="'+id+'"]');assert.equal(get('carrier-pow').value,'pow-left');get('carrier-pow-parent').value='thwomp';get('carrier-pow-bind').click();assert.equal(reports.length,0,reports.join(';'));assert.equal(r().smm2Mechanics.carrierItems[0].carrierId,'thwomp');get('carrier-pow-unbind').click();assert.equal(r().smm2Mechanics.carrierItems.length,0);h.undo();panel.refresh();assert.equal(get('carrier-pow-unbind').disabled,false);assert.equal(get('carrier-pow-parent').value,'thwomp');}finally{ui.restore();}
});

test('real horizontal top carry respects a wall, loses support and never snaps back to its source offset',()=>{
 const r=powCarrierProject().rooms[0];r.map.geometry.push({id:'lift',x:120,y:80,w:48,h:8,collision:'oneway',material:'platform',motion:{axis:'x',min:120,max:220,speed:1}},{id:'wall',x:160,y:60,w:16,h:20,collision:'solid',material:'stone'});r.map.objects=r.map.objects.filter(q=>q.id!=='pow-right');r.smm2Mechanics.powBlocks=r.smm2Mechanics.powBlocks.slice(0,1);r.smm2Mechanics.carrierItems=[{id:'pow-left',carrierId:'lift'}];r.smm2Mechanics.lighting.sources=r.smm2Mechanics.lighting.sources.slice(0,1);
 const h=harness(r),lift=r.map.geometry.find(q=>q.id==='lift');let geometry=structuredClone(r.map.geometry),blocked=false,lost=false;
 for(let tick=1;tick<=100;tick++){const live=geometry.find(q=>q.id==='lift');live.x+=1;live.dx=1;live.dy=0;h.items.beginFrame({tick,actors:h.pows});geometry=h.carriers.apply(geometry,h.actors,{tick});h.items.stepItem(h.pows[0],{tick,geometry,support:h.carriers,actors:h.actors});const a=h.pows[0],s=h.carriers.view().carrierItems[0];if(s.blocked?.normal.x)blocked=true;if(s.phase==='airborne')lost=true;assert(a.x+a.w<=160+1e-6);if(tick>80)assert(a.y>64);}
 assert(blocked);assert(lost);assert.equal(lift.x,120);
});

test('removing the live parent leaves actual gravity and recontact with ground; reset restores both actor/controller source state',()=>{
 const h=harness();h.frame(1);h.enemy.dead=true;let landed=false;for(let tick=2;tick<=100;tick++){h.frame(tick);const a=h.pows[0],s=h.carriers.view().carrierItems[0];assert(a.vy<=4.25);assert.equal(s.carrierUnavailable,true);if(a.grounded){assert.equal(a.support,'floor');assert.equal(a.y+a.h,304);landed=true;break;}}assert(landed);h.carriers.reset();h.items.reset(h.pows);Object.assign(h.enemy,{...h.r.map.objects.find(q=>q.id==='thwomp'),dead:false,vx:0,vy:0});h.thwomps?.reset?.();h.frame(1,{moveParent:false});assert.equal(h.pows[0].y,64);assert.equal(h.pows[0].support,'thwomp');
});

test('a real Mario underside head hit consumes supported POW once, removes collider/light and cannot revive on later support frames',()=>{
 const h=harness();h.frame(1,{moveParent:false});const a=h.pows[0],motor=createPlatformMotor(),p=motor.create(character,{x:a.x+2,y:a.y+a.h+2});Object.assign(p,{vx:0,vy:-4});const before={...p},g=h.items.geometry(h.r.map.geometry,h.pows);motor.step(p,{},character,{width:512,solids:g});const hit=h.items.afterPlayer(p,before,{tick:1,actors:h.pows,geometry:g,targets:[h.enemy]});assert.deepEqual(hit.activated,['pow-left']);assert.equal(a.dead,true);assert.equal(a.smm2Pow.phase,'spent');assert(!h.items.geometry(g,h.pows).some(q=>q.id===a.id));assert(!resolveSmm2LightSources(h.r,{p,items:h.pows,enemies:[h.enemy],objects:[],geometry:[]}).some(q=>q.targetId===a.id));
 for(let tick=2;tick<20;tick++){h.frame(tick,{moveParent:false});assert.equal(a.dead,true);assert.equal(a.smm2Pow.phase,'spent');assert(!h.items.geometry([],h.pows).some(q=>q.id===a.id));}assert.equal(h.carriers.view().carrierItems[0].phase,'removed');h.carriers.reset();h.items.reset(h.pows);h.frame(1,{moveParent:false});assert.equal(a.dead,false);assert.equal(a.y,64);assert.equal(a.smm2Pow.phase,'live');
});

test('held POW lets the claw own pose and release velocity, then re-enters gravity rather than a source mount',()=>{
 let held=true;const h=harness(undefined,{isHeld:()=>held}),a=h.pows[0];Object.assign(a,{x:200,y:40,vx:1.5,vy:-2});h.frame(1);assert.equal(a.x,200);assert.equal(a.y,40);assert.equal(a.vy,-2);held=false;h.frame(2);assert.equal(a.x,201.5);assert.equal(a.y,38.3);assert.equal(a.vy,-1.7);assert.equal(a.support,null);assert.equal(h.carriers.view().carrierItems[0].phase,'airborne');
});

test('a different actual downward Thwomp charge still activates a supported POW and removes it once',()=>{
 const r=powCarrierProject().rooms[0];r.map.objects.push({id:'striker',kind:'walker',x:124,y:24,w:16,h:24});r.smm2Mechanics.thwomps.push({...r.smm2Mechanics.thwomps[0],id:'striker',chargeAcceleration:16,chargeSpeedCap:64});const h=harness(r),striker=h.actors.find(q=>q.id==='striker');let activated=false;
 for(let tick=1;tick<=10;tick++){let g=h.frame(tick,{moveParent:false});const result=createStrike(tick,g);if(result.impact){const effect=h.items.afterThwompImpact(striker,{tick,contact:result.impact,actors:h.pows,targets:[striker,h.enemy],geometry:g});assert.deepEqual(effect.activated,['pow-left']);assert.equal(h.pows[0].dead,true);assert.deepEqual(h.items.afterThwompImpact(striker,{tick,contact:result.impact,actors:h.pows,geometry:g}).activated,[]);activated=true;break;}}
 function createStrike(tick,geometry){const thwomps=h.strike??=createSmm2Thwomps(r);thwomps.decorateEnemy(striker);return thwomps.stepEnemy(striker,{tick,player:{x:124,y:180,w:10,h:14},geometry:h.carriers.geometryForActor(geometry,striker)});}
 assert(activated);assert.equal(h.enemy.dead,undefined);h.frame(11,{moveParent:false});assert(!h.items.geometry([],h.pows).some(q=>q.id==='pow-left'));
});

test('bare Thwomp top remains harmful; normal death rebuild resets carried POW contact history and source positions',()=>{
 const d=powCarrierProject(),spawn=d.rooms[0].map.objects.find(q=>q.id==='start');Object.assign(spawn,{x:158,y:50});const s=nativeSession(d,{Stage:options=>createPlatformStage({...options,manualDeath:false})});let dead=null;for(let n=0;n<40;n++){const v=s.step();assert.notEqual(v.p.support,'thwomp');if(v.p.dying){dead=v;break;}}assert(dead);assert.equal(dead.lives,2);
 let rebuilt=null;for(let n=0;n<120;n++){const v=s.step();if(!v.p.dying){rebuilt=v;break;}}assert(rebuilt);assert.equal(rebuilt.p.x,158);assert.equal(rebuilt.p.y,50);assert.equal(rebuilt.smm2Mechanics.carriers.tick,null);for(const q of rebuilt.smm2Mechanics.carriers.carrierItems){assert.equal(q.previousCollider,null);assert.equal(q.currentCollider,null);assert.equal(q.supportId,'thwomp');assert.equal(q.y,64);}assert.deepEqual(rebuilt.items.filter(q=>q.kind==='pow').map(q=>[q.id,q.y,q.smm2Pow.phase]),[['pow-left',64,'live'],['pow-right',64,'live']]);
});

test('same-tick and paused item calls stay inert; spoofed live Thwomp motion cannot carry a POW',()=>{
 const h=harness();h.frame(1);const before={...h.pows[0]};assert.equal(h.items.stepItem(h.pows[0],{tick:1,support:h.carriers,actors:h.actors}).advanced,false);assert.equal(h.pows[0].y,before.y);h.items.beginFrame({tick:2,actors:h.pows,paused:true});assert.equal(h.items.stepItem(h.pows[0],{tick:2,support:h.carriers,actors:h.actors}).advanced,false);assert.equal(h.pows[0].y,before.y);h.enemy.y+=5;assert.throws(()=>h.carriers.stepItem(h.pows[0],{tick:3,geometry:h.r.map.geometry,actors:h.actors}),/lastMotion/);
});

test('zero-gravity POW rests only on real touching tops and separates as soon as the parent descends',()=>{
 const r=powCarrierProject().rooms[0];for(const q of r.smm2Mechanics.powBlocks)q.gravity=0;const h=harness(r);h.frame(1,{moveParent:false});assert.equal(h.pows[0].support,'thwomp');assert.equal(h.pows[0].y,64);h.frame(2);h.frame(3);assert.equal(h.pows[0].support,null);assert.equal(h.pows[0].y,64);assert.equal(h.carriers.view().carrierItems[0].phase,'airborne');
});

test('an actual rising supported POW top separates newly launched Mario without sideways shove or overwriting velocity',()=>{
 const r=powCarrierProject().rooms[0];r.map.geometry.push({id:'lift',x:120,y:80,w:48,h:8,material:'platform',collision:'oneway',motion:{axis:'y',min:40,max:80,speed:10}});for(const q of r.smm2Mechanics.carrierItems)q.carrierId='lift';const h=harness(r),geometry=structuredClone(r.map.geometry),lift=geometry.find(q=>q.id==='lift');lift.y=70;lift.dx=0;lift.dy=-10;h.items.beginFrame({tick:1,actors:h.pows});h.carriers.apply(geometry,h.actors,{tick:1});for(const a of h.pows)h.items.stepItem(a,{tick:1,geometry,support:h.carriers,actors:h.actors});const world=h.items.geometry(geometry,h.pows),p={id:'player',x:126,y:48,w:10,h:14,vx:1.5,vy:-5,grounded:false,support:null},result=h.carriers.beforeActor(p,{tick:1,geometry:world});assert(result);assert.equal(result.kind,'moving-carried-item-top');assert.equal(result.dy,-8);assert.equal(p.x,126);assert.equal(p.y,40);assert.equal(p.vx,1.5);assert.equal(p.vy,-5);assert.equal(p.grounded,false);assert.equal(p.support,null);assert(!world.some(q=>q.id==='thwomp'));
});

test('deleted-reference cleanup removes genuine owners but leaves a freshly introduced invalid carrier for importer rejection',()=>{
 const d=powCarrierProject(),r=d.rooms[0],before=structuredClone(r);deleteSelection(r,'objects',new Set(['pow-right']));r.smm2Mechanics.carrierItems.push({id:'pow-left',carrierId:'never-existed'});pruneSmm2DeletedReferences(r,before);assert(!r.smm2Mechanics.carrierItems.some(q=>q.id==='pow-right'));assert(r.smm2Mechanics.carrierItems.some(q=>q.carrierId==='never-existed'));assert.throws(()=>parseProject(JSON.stringify(d)));
});

test('qcollection namespace compilation keeps both carrier stable IDs and strict export/import unchanged',()=>{
 const d=powCarrierProject(),c=addLevel(createCollection('Neutral POW support closure'),d,{id:'pow-top'}),again=parseCollection(serializeCollection(c)),built=buildCollection(again,character,{includePending:true});assert.deepEqual(again.levels[0].project.rooms[0].smm2Mechanics.carrierItems,d.rooms[0].smm2Mechanics.carrierItems);assert.deepEqual(built.levels[0].rooms[0].smm2Mechanics.carrierItems,d.rooms[0].smm2Mechanics.carrierItems);assert(built.requiredCapabilities.includes('pow-top-support-v1'));assertNativePowCarrierMotion(again.levels[0].project);
});
