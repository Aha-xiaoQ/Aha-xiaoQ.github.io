import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createPlatformStage} from '../atlas/editor-mario-stage.mjs';
import {createPlatformMotor} from '../atlas/editor-mario-motor.mjs';
import {validate,parseProject} from '../atlas/editor-model.mjs';
const character={capabilities:['jump'],motion:{width:10,height:14,maxHealth:1}};
function session(room,initialState=null){const events=[],stage=createPlatformStage({plan:{stage:{entryRoom:'main',entrySpawn:'start',title:'Carrier integration'},character,rooms:{main:room.map}},motor:createPlatformMotor(),visualRooms:[room],initialState,manualDeath:false,autoContinue:false,allowWarp:false,emit:(type,data)=>events.push({type,...data})});return {stage,events,step(input={}){stage.step(input);return stage.view();}};}
function fixture(){return {roomId:'main',setting:'Overworld',markers:[],decorations:[],map:{id:'carrier-fixture',title:'Carrier fixture',width:320,height:224,tileSize:16,geometry:[{id:'floor',x:0,y:208,w:320,h:16,material:'ground',collision:'solid'},{id:'moving',x:48,y:120,w:48,h:8,material:'platform',collision:'oneway',motion:{axis:'x',min:48,max:112,speed:.7}},{id:'spring',x:64,y:104,w:16,h:16,material:'spring',collision:'solid'}],objects:[{id:'start',kind:'spawn',x:66,y:90,w:10,h:14}]},smm2Mechanics:{version:1,carrierGeometry:[{id:'spring',carrierId:'moving'}]}};}
test('host carries a native Spring rider with the real horizontal platform and keeps ordinary boosted launch',()=>{
 const h=session(fixture());let carried=false,launched=false,minY=Infinity;for(let i=0;i<100;i++){const v=h.step({jump:i>=7});const spring=v.geometry.find(q=>q.id==='spring');if(v.p.springId==='spring'&&Math.abs(spring.dx)>.1)carried=true;if(v.p.vy<=-8.9)launched=true;minY=Math.min(minY,v.p.y);assert.equal(v.lives,3);assert(!v.p.dying);}assert(carried,'Native compression rider must see live collider displacement');assert(launched,'Native -9 Spring launch must survive carrier adapter');assert(minY<80);assert.equal(h.events.filter(q=>q.type==='sound'&&q.event==='jump').length,1);
});
test('native importer preserves explicit live Spring support pairs and rejects a dangling binding',()=>{
 const room=fixture(),doc={format:'xiaoq-map-project',version:1,id:'carrier-fixture',title:'Carrier fixture',rooms:[room]};validate(doc);assert.deepEqual(parseProject(JSON.stringify(doc)),doc);room.smm2Mechanics.carrierGeometry[0].carrierId='missing';assert.throws(()=>validate(doc),/carrier|support/i);
});

for(const big of [false,true])for(const held of [false,true])test(`native Stage ${big?'Big':'Small'} ${held?'high':'normal'} moving-Spring launch keeps vx/vy on the next upward-carrier frame`,()=>{
 const r=fixture();r.map.geometry[1].motion={axis:'y',min:40,max:120,speed:1};const h=session(r,big?{power:1,lives:3}:null);let launch=null;
 for(let n=0;n<30;n++){const v=h.step({x:1,jump:held});if(v.p.vy<-5.5){launch=v;break;}}
 assert.ok(launch);assert.equal(launch.p.vx,1.5);assert.equal(launch.p.vy,held?-9:-6);assert.equal(launch.p.h,big?28:14);assert.equal(launch.p.grounded,false);assert.equal(launch.p.support,null);assert.equal(launch.lives,3);
 const next=h.step({x:1,jump:held}),rise=next.geometry.find(q=>q.id==='spring').y-launch.geometry.find(q=>q.id==='spring').y;assert.equal(rise,-1);assert.equal(next.p.x,launch.p.x+1.5,'the solid Spring top cannot shove the launching actor sideways');assert.equal(next.p.vx,1.5);assert.equal(next.p.vy,launch.p.vy+(held?.22:.32));assert.equal(next.p.y,launch.p.y-1+next.p.vy);assert.equal(next.p.grounded,false);assert.equal(next.p.support,null);assert.equal(next.lives,3);assert.equal(h.events.filter(e=>e.type==='sound'&&['jump','jump_super'].includes(e.event)).length,1);
});

test('carrier opt-out preserves ordinary native Spring launch snapshots',()=>{
 const r=fixture();delete r.smm2Mechanics.carrierGeometry;r.map.geometry[1].motion={axis:'y',min:40,max:120,speed:1};const plain=structuredClone(r);delete plain.smm2Mechanics;const a=session(r),b=session(plain);
 for(let tick=1;tick<=60;tick++){const input={x:tick>15?1:0,jump:tick>6};const av=a.step(input),bv=b.step(input),{smm2Player,...physicalPlayer}=av.p;assert.deepEqual(physicalPlayer,bv.p);assert.deepEqual(av.geometry,bv.geometry);assert.equal(av.lives,bv.lives);assert.equal(av.smm2Mechanics.carriers,undefined);}
});

test('bare Thwomp contact stays dangerous and death rebuild discards Spring contact history',()=>{
 const r=fixture();r.map.geometry=r.map.geometry.filter(q=>q.id==='floor');r.map.geometry.push({id:'spring',x:124,y:64,w:16,h:16,material:'spring',collision:'solid'});r.map.objects=[{id:'start',kind:'spawn',x:112,y:50,w:10,h:14},{id:'thwomp',kind:'walker',x:120,y:80,w:24,h:32}];r.smm2Mechanics={version:1,thwomps:[{id:'thwomp',direction:'down',triggerRange:200,transverseTolerance:16,leadReference:'near-edge',windupFrames:0,chargeAcceleration:.32,chargeSpeedCap:6,impactWaitFrames:8,returnSpeed:1,breakMaterials:[]}],carrierGeometry:[{id:'spring',carrierId:'thwomp'}]};const h=session(r);let dead=null;
 for(let n=0;n<30;n++){const v=h.step();assert.notEqual(v.p.support,'spring');if(v.p.dying){dead=v;break;}}
 assert.ok(dead);assert.equal(dead.lives,2);const oldCarrier=dead.smm2Mechanics.carriers;
 let rebuilt=null;for(let n=0;n<110;n++){const v=h.step();if(!v.p.dying){rebuilt=v;break;}}
 assert.ok(rebuilt);assert.equal(rebuilt.lives,2);assert.equal(rebuilt.p.x,112);assert.equal(rebuilt.p.y,50);assert.equal(rebuilt.smm2Mechanics.carriers.tick,null);assert.equal(rebuilt.smm2Mechanics.carriers.carrierGeometry[0].previousCollider,null);assert.equal(rebuilt.smm2Mechanics.carriers.carrierGeometry[0].currentCollider,null);assert.notDeepEqual(rebuilt.smm2Mechanics.carriers,oldCarrier);
});
