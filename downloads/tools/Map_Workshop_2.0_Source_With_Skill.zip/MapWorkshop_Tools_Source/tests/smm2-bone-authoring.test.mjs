import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {blank,History,parseProject,validate,runtimeMap,moveSelection,deleteSelection,materials} from '../atlas/editor-model.mjs';
import {
 addSmm2BoneShell,bindSmm2BoneShell,updateSmm2BoneShell,removeSmm2BoneShell,
 addSmm2DryBones,bindSmm2DryBones,updateSmm2DryBones,removeSmm2DryBones,
 addSmm2ManagedLiquid,bindSmm2ManagedLiquid,updateSmm2ManagedLiquid,removeSmm2ManagedLiquid,
 addSmm2BoneSupply,bindSmm2BoneSupply,updateSmm2BoneSupply,removeSmm2BoneSupply,
 pruneSmm2BoneReferences,captureSmm2BoneBindings,appendCopiedSmm2BoneBindings,mountSmm2BoneTools,
} from '../atlas/editor-smm2-bone-tools.mjs';
import {removeMarioModuleRecord,setMarioModulesEnabled,mountMarioModulesEditor} from '../atlas/editor-mario-modules-editor.mjs';
import {createSmm2Liquid} from '../atlas/editor-smm2-liquid.mjs';
import {createSmm2Shoes} from '../atlas/editor-smm2-shoes.mjs';
import {createMarioModules} from '../atlas/editor-mario-modules.mjs';
import {projectPack} from '../atlas/editor-runtime.mjs';
import {createStageCatalog} from '../atlas/runtime/stage-catalog.mjs';
import {pruneSmm2DeletedReferences} from '../atlas/editor-smm2-authoring.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';

function project(){
 const doc=blank('Bone authoring fixture',640,384),r=doc.rooms[0];r.setting='Castle';
 r.map.geometry=[
  {id:'floor',x:0,y:352,w:640,h:32,material:'ground',collision:'solid'},
  {id:'ledge',x:208,y:192,w:64,h:8,material:'platform',collision:'oneway'},
  {id:'pipe',x:480,y:48,w:32,h:64,material:'pipe',collision:'solid'},
  {id:'other-pipe',x:544,y:48,w:32,h:64,material:'pipe',collision:'solid'},
 ];
 r.map.objects=[
  {id:'start',kind:'spawn',x:16,y:338,w:10,h:14},
  {id:'custom-shell',kind:'walker',x:128,y:80,w:21,h:20},
  {id:'custom-dry',kind:'walker',x:288,y:224,w:19,h:31},
  {id:'plain-walker',kind:'walker',x:400,y:256,w:16,h:16},
  {id:'actor-oneway',kind:'walker',x:336,y:112,w:16,h:16,collision:'oneway'},
 ];
 r.markers=[{id:'unmanaged-lava',kind:'lava-region',x:32,y:320,w:416,h:64},{id:'marker-oneway',kind:'reference',x:80,y:80,w:16,h:16,collision:'oneway'}];
 return doc;
}
const actor=(r,id)=>r.map.objects.find(q=>q.id===id);
const shell=(r,id)=>r.smm2Mechanics.boneShells.find(q=>q.id===id);
const source=(r,id)=>r.marioModules.enemySources.find(q=>q.id===id);
const roundtrip=doc=>assert.deepEqual(parseProject(JSON.stringify(doc)),doc);
function atomic(room,actions){for(const [label,run]of actions){const before=structuredClone(room);assert.throws(run,undefined,label);assert.deepEqual(room,before,label+' leaves the complete room intact');}}

test('Bone Shell and Dry Bones bind native custom bodies and merge typed tuning without resizing',()=>{
 const doc=project(),r=doc.rooms[0],shellBody=structuredClone(actor(r,'custom-shell')),dryBody=structuredClone(actor(r,'custom-dry'));
 bindSmm2BoneShell(r,'custom-shell',{tuning:{gravity:.3},playingDead:{durationFrames:24,maxFrames:90,dropThroughIds:['ledge']}});
 bindSmm2DryBones(r,'custom-dry',{size:'giant',speed:.7,collapsedHeight:10,giantStompResponse:'hurt'});
 assert.deepEqual(actor(r,'custom-shell'),shellBody);assert.deepEqual(actor(r,'custom-dry'),dryBody);
 updateSmm2BoneShell(r,'custom-shell',{x:144,tuning:{maxFallSpeed:3},playingDead:{durationFrames:30}});
 assert.equal(shell(r,'custom-shell').tuning.gravity,.3);assert.equal(shell(r,'custom-shell').tuning.maxFallSpeed,3);
 assert.deepEqual(shell(r,'custom-shell').playingDead,{durationFrames:30,maxFrames:90,dropThroughIds:['ledge']});
 updateSmm2DryBones(r,'custom-dry',{speed:.8,recoverFrames:12});assert.equal(r.marioModules.enemyVariants['custom-dry'].collapsedHeight,10);assert.equal(r.marioModules.enemyVariants['custom-dry'].giantStompResponse,'hurt');
 updateSmm2DryBones(r,'custom-dry',{size:'normal'});assert.equal('giantStompResponse'in r.marioModules.enemyVariants['custom-dry'],false);assert.deepEqual([actor(r,'custom-dry').w,actor(r,'custom-dry').h],[19,31]);
 roundtrip(doc);removeSmm2BoneShell(r,'custom-shell',{removeNativeBody:false});removeSmm2DryBones(r,'custom-dry',{removeNativeBody:false});
 assert(actor(r,'custom-shell'));assert(actor(r,'custom-dry'));assert.deepEqual(r.smm2Mechanics.boneShells,[]);assert.equal(r.marioModules.enemyVariants['custom-dry'],undefined);roundtrip(doc);
});

test('pure creation and removal keep the native ABI and normal/giant authored defaults through export',()=>{
 const doc=project(),r=doc.rooms[0];delete actor(r,'actor-oneway').collision;const bone=addSmm2BoneShell(r,{id:'new-shell'}),normal=addSmm2DryBones(r,{id:'normal-bones'}),giant=addSmm2DryBones(r,{id:'giant-bones',size:'giant',giantStompResponse:'harmless'});
 assert.deepEqual([actor(r,bone).w,actor(r,bone).h],[16,16]);assert.deepEqual([actor(r,normal).w,actor(r,normal).h],[16,24]);assert.deepEqual([actor(r,giant).w,actor(r,giant).h],[32,48]);
 assert.equal(r.marioModules.enemyVariants[giant].giantStompResponse,'harmless');
 for(const id of [bone,normal,giant])assert.deepEqual(Object.keys(actor(r,id)).sort(),['h','id','kind','w','x','y']);
 const character=JSON.parse(fs.readFileSync(new URL('../atlas/runtime/character.json',import.meta.url))),pack=projectPack(parseProject(JSON.stringify(doc)),r.roomId,character,'bone-authoring');
 createStageCatalog(pack);assert.equal(pack.maps[0].smm2Mechanics,undefined);assert(pack.maps[0].objects.filter(q=>[bone,normal,giant].includes(q.id)).every(q=>q.kind==='walker'));
 removeSmm2BoneShell(r,bone);removeSmm2DryBones(r,normal);removeSmm2DryBones(r,giant);for(const id of [bone,normal,giant])assert.equal(actor(r,id),undefined);roundtrip(doc);
});

test('pure authoring rejects malformed values, conflicting owners and non-geometry drop targets atomically',()=>{
 const doc=project(),r=doc.rooms[0];bindSmm2BoneShell(r,'custom-shell',{playingDead:{dropThroughIds:['ledge']}});bindSmm2DryBones(r,'custom-dry',{});
 atomic(r,[
  ['unknown actor field',()=>addSmm2BoneShell(r,{execute:'script'})],['duplicate body ID',()=>addSmm2BoneShell(r,{id:'custom-shell'})],['null actor options',()=>addSmm2BoneShell(r,null)],['undefined explicit field',()=>addSmm2BoneShell(r,{x:undefined})],
  ['non-walker binding',()=>bindSmm2BoneShell(r,'start',{})],['foreign binding',()=>bindSmm2BoneShell(r,'foreign-shell',{})],['cross-owner binding',()=>bindSmm2DryBones(r,'custom-shell',{})],
  ['bound geometry replacement',()=>bindSmm2DryBones(r,'plain-walker',{w:32})],['invalid normal giant response',()=>updateSmm2DryBones(r,'custom-dry',{giantStompResponse:'unexpected'})],
  ['solid geometry drop target',()=>updateSmm2BoneShell(r,'custom-shell',{playingDead:{dropThroughIds:['floor']}})],
  ['oneway actor drop target',()=>updateSmm2BoneShell(r,'custom-shell',{playingDead:{dropThroughIds:['actor-oneway']}})],
  ['oneway marker drop target',()=>updateSmm2BoneShell(r,'custom-shell',{playingDead:{dropThroughIds:['marker-oneway']}})],
  ['missing drop target',()=>updateSmm2BoneShell(r,'custom-shell',{playingDead:{dropThroughIds:['missing']}})],
  ['duplicate drop target',()=>updateSmm2BoneShell(r,'custom-shell',{playingDead:{dropThroughIds:['ledge','ledge']}})],
  ['invalid duration range',()=>updateSmm2BoneShell(r,'custom-shell',{playingDead:{durationFrames:200,maxFrames:100}})],
  ['unknown nested tuning',()=>updateSmm2BoneShell(r,'custom-shell',{tuning:{npcSpeed:1}})],['null tuning',()=>updateSmm2BoneShell(r,'custom-shell',{tuning:null})],
  ['null collapse',()=>updateSmm2BoneShell(r,'custom-shell',{playingDead:null})],['unknown collapse field',()=>updateSmm2BoneShell(r,'custom-shell',{playingDead:{teleport:true}})],['NaN collapse duration',()=>updateSmm2BoneShell(r,'custom-shell',{playingDead:{durationFrames:NaN}})],['NaN body',()=>addSmm2BoneShell(r,{x:NaN})],['null body',()=>addSmm2BoneShell(r,{x:null})],
  ['NaN tuning',()=>updateSmm2BoneShell(r,'custom-shell',{tuning:{gravity:NaN}})],['null tuning value',()=>updateSmm2BoneShell(r,'custom-shell',{tuning:{gravity:null}})],
  ['unbound template-only flag',()=>updateSmm2BoneShell(r,'custom-shell',{templateOnly:true})],
  ['null Dry Bones size',()=>addSmm2DryBones(r,{size:null})],['NaN Dry Bones speed',()=>updateSmm2DryBones(r,'custom-dry',{speed:NaN})],['null Dry Bones speed',()=>updateSmm2DryBones(r,'custom-dry',{speed:null})],
 ]);roundtrip(doc);
});

test('managed liquid authors one actual hazard marker and its boat surface stays actor scoped',()=>{
 const doc=project(),r=doc.rooms[0],geometry=structuredClone(r.map.geometry);bindSmm2BoneShell(r,'custom-shell',{});setMarioModulesEnabled(r,true);
 bindSmm2ManagedLiquid(r,'unmanaged-lava',{minY:288,maxY:320,initialY:312,speed:1,waitMinFrames:2,waitMaxFrames:3});
 assert.equal(r.markers.find(q=>q.id==='unmanaged-lava').y,312);assert.equal(r.markers.find(q=>q.id==='unmanaged-lava').h,72);
 updateSmm2ManagedLiquid(r,{x:48,w:384,initialY:304,speed:.5});assert.equal(r.markers.find(q=>q.id==='unmanaged-lava').y,304);assert.equal(r.smm2Mechanics.liquid.waitMaxFrames,3);roundtrip(doc);
 const liquid=createSmm2Liquid(r),shoes=createSmm2Shoes(r,{liquid}),body={...actor(r,'custom-shell'),vx:0,vy:0},bare={id:'bare',kind:'player',x:48,y:280,w:10,h:14},native=r.map.geometry;
 shoes.decorateActor(body);liquid.step({tick:1});assert.equal(shoes.geometry(native,[],{actor:bare}),native);assert(shoes.geometry(native,[],{actor:body}).some(q=>q.smm2LiquidSupport&&q.y===303.5));
 assert(!createMarioModules(r).geometry(native).some(q=>q.smm2LiquidSupport));assert.deepEqual(r.map.geometry,geometry);assert(!runtimeMap(r).geometry.some(q=>q.id==='unmanaged-lava-boat-surface'));assert.equal('geometry'in liquid,false);
 atomic(r,[['second managed surface',()=>addSmm2ManagedLiquid(r,{})],['wrong marker kind',()=>bindSmm2ManagedLiquid(r,'marker-oneway',{})],['foreign marker',()=>bindSmm2ManagedLiquid(r,'foreign-marker',{})],['invalid range',()=>updateSmm2ManagedLiquid(r,{minY:321})],['NaN liquid speed',()=>updateSmm2ManagedLiquid(r,{speed:NaN})],['null liquid speed',()=>updateSmm2ManagedLiquid(r,{speed:null})],['unknown liquid field',()=>updateSmm2ManagedLiquid(r,{safeForMario:true})]]);
 removeSmm2ManagedLiquid(r,{removeMarker:false});assert(r.markers.some(q=>q.id==='unmanaged-lava'));const id=addSmm2ManagedLiquid(r,{markerId:'created-lava',x:16,w:448,minY:280,maxY:320,initialY:320,speed:1});assert.equal(id,'created-lava');removeSmm2ManagedLiquid(r);assert(!r.markers.some(q=>q.id===id));assert.deepEqual(r.map.geometry,geometry);roundtrip(doc);
});

test('typed Bone pipe supplies retain a real foot and clear template-only status only after the last supply',()=>{
 const doc=project(),r=doc.rooms[0];bindSmm2BoneShell(r,'custom-shell',{});const second=addSmm2BoneShell(r,{id:'second-template'});
 const id=bindSmm2BoneSupply(r,'pipe','custom-shell',{id:'bone-source',templateOnly:true,foot:{w:23,h:22},tuning:{gravity:.25},playingDead:{durationFrames:40,maxFrames:120,dropThroughIds:['ledge']},direction:'down',emergenceFrames:36});
 assert.equal(id,'bone-source');assert.equal(source(r,id).enemy,'bone-shell');assert.equal(source(r,id).smart,false);assert.equal(source(r,id).maxEmissions,null);assert.deepEqual([actor(r,'custom-shell').w,actor(r,'custom-shell').h],[23,22]);assert.equal(shell(r,'custom-shell').templateOnly,true);assert.equal(shell(r,'custom-shell').tuning.gravity,.25);
 assert.equal('foot'in source(r,id),false);assert.equal('templateOnly'in source(r,id),false);
 updateSmm2BoneSupply(r,id,{intervalFrames:180,maxEmissions:5,vx:.25,initialDelayFrames:10});assert.equal(source(r,id).emergenceFrames,36);assert.equal(source(r,id).intervalFrames,180);assert.deepEqual(shell(r,'custom-shell').playingDead.dropThroughIds,['ledge']);
 addSmm2BoneSupply(r,{id:'bone-source-two',pipeId:'other-pipe',shoeTemplateId:'custom-shell'});removeSmm2BoneSupply(r,id);assert.equal(shell(r,'custom-shell').templateOnly,true);
 updateSmm2BoneSupply(r,'bone-source-two',{shoeTemplateId:second,templateOnly:true});assert.equal(shell(r,'custom-shell').templateOnly,false);assert.equal(shell(r,second).templateOnly,true);
 atomic(r,[['missing pipe',()=>updateSmm2BoneSupply(r,'bone-source-two',{pipeId:'missing'})],['non-pipe geometry',()=>updateSmm2BoneSupply(r,'bone-source-two',{pipeId:'ledge'})],['untyped foot',()=>updateSmm2BoneSupply(r,'bone-source-two',{shoeTemplateId:'plain-walker'})],['foreign template',()=>addSmm2BoneSupply(r,{pipeId:'pipe',shoeTemplateId:'missing'})],['smart Bone source',()=>updateSmm2BoneSupply(r,'bone-source-two',{smart:true})],['null source interval',()=>updateSmm2BoneSupply(r,'bone-source-two',{intervalFrames:null})],['NaN source velocity',()=>updateSmm2BoneSupply(r,'bone-source-two',{vx:NaN})],['null foot',()=>updateSmm2BoneSupply(r,'bone-source-two',{foot:null})]]);
 removeSmm2BoneSupply(r,'bone-source-two');assert.equal(shell(r,second).templateOnly,false);assert(actor(r,second));roundtrip(doc);
});

test('generic module source removal and disabling modules release typed Bone templates with History undo',()=>{
 const h=new History(project()),r=()=>h.doc.rooms[0];h.change(()=>{bindSmm2BoneShell(r(),'custom-shell',{});addSmm2BoneSupply(r(),{id:'cleanup-source',pipeId:'pipe',shoeTemplateId:'custom-shell',templateOnly:true});});
 const complete=structuredClone(h.doc);h.change(()=>removeMarioModuleRecord(r(),'enemySources','cleanup-source'));assert.equal(shell(r(),'custom-shell').templateOnly,false);assert.deepEqual(r().marioModules.enemySources,[]);h.undo();assert.deepEqual(h.doc,complete);h.redo();roundtrip(h.doc);h.undo();
 h.change(()=>setMarioModulesEnabled(r(),false));assert.equal(r().marioModules,undefined);assert.equal(shell(r(),'custom-shell').templateOnly,false);assert(actor(r(),'custom-shell'));roundtrip(h.doc);h.undo();assert.deepEqual(h.doc,complete);h.redo();roundtrip(h.doc);
});

test('native clipboard helper copies owners and typed supplies then deletion prunes their exact dependencies',()=>{
 const h=new History(project()),r=()=>h.doc.rooms[0];h.change(()=>{bindSmm2BoneShell(r(),'custom-shell',{playingDead:{dropThroughIds:['ledge']}});bindSmm2DryBones(r(),'custom-dry',{size:'giant',giantStompResponse:'hurt'});addSmm2BoneSupply(r(),{id:'copy-source',pipeId:'pipe',shoeTemplateId:'custom-shell',templateOnly:true});});
 const snapshot=captureSmm2BoneBindings(r(),new Set(['custom-shell','custom-dry'])),idMap=new Map([['custom-shell','shell-copy'],['custom-dry','dry-copy'],['ledge','ledge-copy']]);assert.equal(snapshot.enemySources.length,1);
 h.change(()=>{r().map.geometry.push({...r().map.geometry.find(q=>q.id==='ledge'),id:'ledge-copy',x:304});for(const id of ['custom-shell','custom-dry'])r().map.objects.push({...actor(r(),id),id:idMap.get(id),x:actor(r(),id).x+32});appendCopiedSmm2BoneBindings(r(),snapshot,idMap);});
 assert.deepEqual(shell(r(),'shell-copy').playingDead.dropThroughIds,['ledge-copy']);assert.equal(shell(r(),'shell-copy').templateOnly,true);assert.equal(r().marioModules.enemyVariants['dry-copy'].giantStompResponse,'hurt');assert(r().marioModules.enemySources.some(q=>q.shoeTemplateId==='shell-copy'&&q.pipeId==='pipe'&&q.id!=='copy-source'));roundtrip(h.doc);
 const copied=structuredClone(h.doc);h.change(()=>{const before=structuredClone(r());deleteSelection(r(),'objects',new Set(['shell-copy','dry-copy']));pruneSmm2BoneReferences(r(),before);});assert.equal(r().smm2Mechanics.boneShells.length,1);assert.equal(r().marioModules.enemyVariants['dry-copy'],undefined);assert.equal(r().marioModules.enemySources.length,1);h.undo();assert.deepEqual(h.doc,copied);h.redo();roundtrip(h.doc);
 h.change(()=>{const before=structuredClone(r());deleteSelection(r(),'geometry',new Set(['pipe','ledge']));pruneSmm2BoneReferences(r(),before);});assert.deepEqual(r().marioModules.enemySources,[]);assert.equal(shell(r(),'custom-shell').templateOnly,false);assert.deepEqual(shell(r(),'custom-shell').playingDead.dropThroughIds,[]);h.undo();assert.equal(shell(r(),'custom-shell').templateOnly,true);h.redo();roundtrip(h.doc);
 const before=structuredClone(r());assert.throws(()=>h.change(()=>appendCopiedSmm2BoneBindings(r(),snapshot,new Map())));assert.deepEqual(r(),before);
});

test('geometry clipboard copies real linked liquid markers across rooms and native movement shifts its full range',()=>{
 const doc=project(),r=doc.rooms[0];r.map.geometry.push({id:'lava-bed',x:32,y:336,w:416,h:16,material:'stone',collision:'solid'});addSmm2ManagedLiquid(r,{markerId:'lava-bed-region',x:32,w:416,minY:288,maxY:320,initialY:312,speed:1});
 const snapshot=captureSmm2BoneBindings(r,new Set(['lava-bed']),{layer:'geometry'});assert.equal(snapshot.liquid.markerId,'lava-bed-region');assert.equal(captureSmm2BoneBindings(r,new Set(['lava-bed']),{layer:'objects'}).liquid,null);
 const other=project().rooms[0];other.roomId='other';other.map.geometry.push({...r.map.geometry.find(q=>q.id==='lava-bed'),id:'copied-bed',x:48,y:320});other.markers.push({...r.markers.find(q=>q.id==='lava-bed-region'),id:'copied-bed-region',x:48,y:296});
 appendCopiedSmm2BoneBindings(other,snapshot,new Map([['lava-bed','copied-bed'],['lava-bed-region','copied-bed-region']]));assert.deepEqual([other.smm2Mechanics.liquid.minY,other.smm2Mechanics.liquid.maxY,other.smm2Mechanics.liquid.initialY],[272,304,296]);
 doc.rooms.push(other);roundtrip(doc);const before=structuredClone(r);moveSelection(r,'geometry',new Set(['lava-bed']),16,-16);pruneSmm2BoneReferences(r,before);assert.deepEqual([r.smm2Mechanics.liquid.minY,r.smm2Mechanics.liquid.maxY,r.smm2Mechanics.liquid.initialY],[272,304,296]);
 const now=structuredClone(r);deleteSelection(r,'geometry',new Set(['lava-bed']));pruneSmm2BoneReferences(r,now);assert.equal(r.smm2Mechanics.liquid,undefined);assert(!r.markers.some(q=>q.id==='lava-bed-region'));roundtrip(doc);
 atomic(other,[['second copied managed lava',()=>appendCopiedSmm2BoneBindings(other,snapshot,new Map([['lava-bed-region','copied-bed-region']]))]]);
});

test('deletion cleanup preserves new malformed references so strict reimport rejects them',()=>{
 const doc=project(),r=doc.rooms[0];bindSmm2BoneShell(r,'custom-shell',{playingDead:{dropThroughIds:['ledge']}});bindSmm2DryBones(r,'custom-dry',{});addSmm2BoneSupply(r,{id:'valid-source',pipeId:'pipe',shoeTemplateId:'custom-shell'});bindSmm2ManagedLiquid(r,'unmanaged-lava',{});
 for(const mutate of [
  q=>q.smm2Mechanics.boneShells.push({...structuredClone(shell(q,'custom-shell')),id:'missing-new-shell'}),
  q=>shell(q,'custom-shell').playingDead.dropThroughIds.push('missing-new-platform'),
  q=>q.marioModules.enemyVariants['missing-new-bones']=structuredClone(q.marioModules.enemyVariants['custom-dry']),
  q=>q.marioModules.enemySources.push({...structuredClone(source(q,'valid-source')),id:'new-bad-source',pipeId:'missing-new-pipe'}),
  q=>q.marioModules.enemySources[0].shoeTemplateId='missing-new-template',
  q=>q.smm2Mechanics.liquid.markerId='missing-new-marker',
 ]){const invalid=structuredClone(r);mutate(invalid);const malformed=structuredClone(invalid);pruneSmm2BoneReferences(invalid,r);assert.deepEqual(invalid,malformed);assert.throws(()=>parseProject(JSON.stringify({...doc,rooms:[invalid]})));}
 roundtrip(doc);
});

test('the complete native deletion cleanup rejects a newly introduced malformed Bone supply',()=>{
 const h=new History(project()),r=()=>h.doc.rooms[0];h.change(()=>bindSmm2BoneShell(r(),'custom-shell',{}));const valid=structuredClone(h.doc),undos=h.undoStack.length;
 assert.throws(()=>h.change(()=>{const before=structuredClone(r());r().marioModules={version:1,itemSources:[],noteBlocks:[],oneWayWalls:[],enemyVariants:{},enemySources:[{id:'new-dangling-source',enemy:'bone-shell',smart:false,pipeId:'pipe',shoeTemplateId:'custom-shell',direction:'down',intervalFrames:120,initialDelayFrames:0,maxAlive:1,maxEmissions:null,activationDistance:320,vx:0,vy:0,emergenceFrames:24}]};deleteSelection(r(),'objects',new Set(['custom-shell']));pruneSmm2DeletedReferences(r(),before);pruneSmm2BoneReferences(r(),before);}));
 assert.deepEqual(h.doc,valid);assert.equal(h.undoStack.length,undos);roundtrip(h.doc);
});

test('actual Bone sidebar creates, binds, updates and removes every actor with atomic History errors',()=>{
 const ui=installSimulatedPlayDom();try{
  const h=new History(project()),r=()=>h.doc.rooms[0],parent=ui.document.createElement('aside'),reports=[];let picked=new Set(['custom-shell']);const panel=mountSmm2BoneTools({parent,room:r,selected:()=>picked,change:fn=>h.change(fn),report:s=>reports.push(s)}),get=id=>parent.querySelector('[data-bone-control="'+id+'"]');
  assert.equal(get('actor').value,'custom-shell');assert.deepEqual(get('dropThroughIds').children.map(q=>q.value),['ledge']);const body=structuredClone(actor(r(),'custom-shell'));get('durationFrames').value='30';get('maxFrames').value='120';get('dropThroughIds').children[0].selected=true;get('tuning.gravity').value='.3';get('actor-bind').click();assert.deepEqual(actor(r(),'custom-shell'),body,reports.join(';'));assert.deepEqual(shell(r(),'custom-shell').playingDead.dropThroughIds,['ledge']);
  get('x').value='144';get('durationFrames').value='45';get('actor-apply').click();assert.equal(actor(r(),'custom-shell').x,144);assert.equal(shell(r(),'custom-shell').playingDead.durationFrames,45);const valid=structuredClone(h.doc),undoCount=h.undoStack.length;get('tuning.gravity').value='';get('actor-apply').click();assert.deepEqual(h.doc,valid);assert.equal(h.undoStack.length,undoCount);assert(reports.length);
  h.undo();panel.refresh();assert.equal(get('x').value,'128');h.redo();panel.refresh();assert.equal(get('x').value,'144');
  get('actor-unbind').click();assert(actor(r(),'custom-shell'));assert.deepEqual(r().smm2Mechanics.boneShells,[]);h.undo();panel.refresh();assert.equal(shell(r(),'custom-shell').tuning.gravity,.3);
  picked=new Set(['custom-dry']);panel.refresh();get('type').value='giant';get('type').dispatchEvent({type:'change'});assert.equal(get('actor-bind').disabled,false,'choosing a type retains access to Bind for the selected native body');get('collapsedHeight').value='10';get('giantStompResponse').value='hurt';get('actor-bind').click();assert.deepEqual([actor(r(),'custom-dry').w,actor(r(),'custom-dry').h],[19,31]);assert.equal(r().marioModules.enemyVariants['custom-dry'].size,'giant');get('actor-unbind').click();assert(actor(r(),'custom-dry'));assert.equal(r().marioModules.enemyVariants['custom-dry'],undefined);h.undo();panel.refresh();assert.equal(r().marioModules.enemyVariants['custom-dry'].giantStompResponse,'hurt');
  for(const type of ['bone-shell','normal','giant']){picked=new Set();panel.refresh();get('type').value=type;get('type').dispatchEvent({type:'change'});assert.deepEqual([Number(get('w').value),Number(get('h').value)],type==='bone-shell'?[16,16]:type==='normal'?[16,24]:[32,48]);get('actor-add').click();const id=get('actor').value;assert(actor(r(),id),reports.join(';'));get('x').value='160';if(type==='bone-shell')get('durationFrames').value='60';else get('speed').value='.75';get('actor-apply').click();assert.equal(actor(r(),id).x,160);if(type==='bone-shell')assert.equal(shell(r(),id).playingDead.durationFrames,60);else assert.equal(r().marioModules.enemyVariants[id].speed,.75);get('actor-remove').click();assert.equal(actor(r(),id),undefined);h.undo();panel.refresh();assert(actor(r(),id));h.redo();panel.refresh();roundtrip(h.doc);}
 }finally{ui.restore();}
});

test('actual liquid and Bone supply controls edit real dependencies while generic inspectors exclude typed actors',()=>{
 const ui=installSimulatedPlayDom();try{
  const h=new History(project()),r=()=>h.doc.rooms[0];h.change(()=>{bindSmm2BoneShell(r(),'custom-shell',{});bindSmm2DryBones(r(),'custom-dry',{});});const parent=ui.document.createElement('aside'),reports=[],panel=mountSmm2BoneTools({parent,room:r,change:fn=>h.change(fn),report:s=>reports.push(s)}),get=id=>parent.querySelector('[data-bone-control="'+id+'"]');
  assert.deepEqual(get('supply-pipe').children.map(q=>q.value),['pipe','other-pipe']);assert.deepEqual(get('supply-foot').children.map(q=>q.value),['custom-shell']);get('templateOnly').checked=true;get('supply-direction').value='right';get('supply-emergenceFrames').value='32';get('supply-add').click();const supplyId=get('supply').value;assert.equal(source(r(),supplyId).enemy,'bone-shell',reports.join(';'));assert.equal(shell(r(),'custom-shell').templateOnly,true);
  assert.deepEqual(['x','y','w','h'].map(k=>Number(get('supply-foot-'+k).value)),[128,80,21,20]);get('supply-intervalFrames').value='180';get('supply-maxEmissions').value='4';get('supply-foot-w').value='24';get('supply-foot-h').value='22';get('supply-apply').click();assert.equal(source(r(),supplyId).intervalFrames,180);assert.equal(source(r(),supplyId).direction,'right');assert.equal(source(r(),supplyId).emergenceFrames,32);assert.equal(source(r(),supplyId).maxEmissions,4);assert.deepEqual([actor(r(),'custom-shell').w,actor(r(),'custom-shell').h],[24,22]);
  const supplyValid=structuredClone(h.doc),supplyUndos=h.undoStack.length;get('supply-foot-w').value='0';get('supply-intervalFrames').value='190';get('supply-apply').click();assert.deepEqual(h.doc,supplyValid,'invalid template body also rolls back source edits');assert.equal(h.undoStack.length,supplyUndos);h.undo();panel.refresh();assert.deepEqual(['w','h'].map(k=>Number(get('supply-foot-'+k).value)),[21,20]);h.redo();panel.refresh();assert.deepEqual(['w','h'].map(k=>Number(get('supply-foot-'+k).value)),[24,22]);
  const genericParent=ui.document.createElement('aside'),generic=mountMarioModulesEditor({parent:genericParent,room:r,change:fn=>h.change(fn),report:s=>reports.push(s)}),moduleGet=id=>genericParent.querySelector('[data-module-control="'+id+'"]');assert(!moduleGet('source-select').children.some(q=>q.value.endsWith(supplyId)),'generic source editing cannot turn a Bone supply into another actor');assert(!moduleGet('actor-select').children.some(q=>['custom-shell','custom-dry'].includes(q.value)),'generic plant inspector excludes already typed Bone bodies');
  get('liquid-marker').value='unmanaged-lava';get('liquid-marker').dispatchEvent({type:'change'});get('liquid-minY').value='288';get('liquid-maxY').value='320';get('liquid-initialY').value='312';get('liquid-speed').value='1';get('liquid-waitMinFrames').value='2';get('liquid-bind').click();assert.equal(r().smm2Mechanics.liquid.markerId,'unmanaged-lava',reports.join(';'));assert.equal(r().markers.find(q=>q.id==='unmanaged-lava').y,312);
  get('liquid-initialY').value='304';get('liquid-apply').click();assert.equal(r().smm2Mechanics.liquid.initialY,304);const valid=structuredClone(h.doc),undos=h.undoStack.length;get('liquid-speed').value='';get('liquid-apply').click();assert.deepEqual(h.doc,valid);assert.equal(h.undoStack.length,undos);
  get('liquid-remove').click();assert.equal(r().smm2Mechanics.liquid,undefined);assert(!r().markers.some(q=>q.id==='unmanaged-lava'));h.undo();panel.refresh();assert.equal(get('liquid-initialY').value,'304');h.redo();panel.refresh();get('liquid-add').click();const markerId=r().smm2Mechanics.liquid.markerId;assert(r().markers.some(q=>q.id===markerId));
  get('supply-remove').click();assert.equal(shell(r(),'custom-shell').templateOnly,false);h.undo();panel.refresh();assert.equal(shell(r(),'custom-shell').templateOnly,true);h.redo();panel.refresh();generic.refresh();roundtrip(h.doc);
 }finally{ui.restore();}
});

test('real editor native copy, delete, eraser and undo retain Bone ownership and the ordinary palette',async()=>{
 const ui=installSimulatedPlayDom(),savedGlobals=new Map(),install=(key,value)=>{savedGlobals.set(key,Object.getOwnPropertyDescriptor(globalThis,key));Object.defineProperty(globalThis,key,{value,writable:true,configurable:true});};
 try{
  const initial=project(),r=initial.rooms[0];bindSmm2BoneShell(r,'custom-shell',{playingDead:{dropThroughIds:['ledge']}});bindSmm2DryBones(r,'custom-dry',{size:'giant',giantStompResponse:'hurt'});addSmm2BoneSupply(r,{id:'editor-bone-source',pipeId:'pipe',shoeTemplateId:'custom-shell',templateOnly:true});bindSmm2ManagedLiquid(r,'unmanaged-lava',{minY:288,maxY:320,initialY:320,speed:1});const values=new Map([['xiaoq-map-workshop-tools-v1',JSON.stringify(initial)]]);
  install('localStorage',{getItem:key=>values.get(key)||null,setItem:(key,value)=>values.set(key,value)});install('devicePixelRatio',1);install('ResizeObserver',class{observe(){}});install('setTimeout',()=>1);install('clearTimeout',()=>{});
  ui.Element.prototype.closest=function(selector){for(let n=this;n;n=n.parentNode)if(selector.split(',').some(q=>q===n.tag||q==='.'+n.className||q==='#'+n.id))return n;return null;};ui.Element.prototype.removeAttribute=function(key){delete this.attributes[key];};ui.Element.prototype.after=function(node){const parent=this.parentNode,index=parent.children.indexOf(this);node.parentNode=parent;parent.children.splice(index+1,0,node);};
  const html=fs.readFileSync(new URL('../atlas/editor.html',import.meta.url),'utf8');ui.document.body.innerHTML=html.match(/<body[^>]*>([\s\S]*?)<\/body>/)[1];for(const n of ui.document.body.querySelectorAll('input')){n.value=n.getAttribute('value')||'';n.checked=n.getAttribute('checked')!==undefined;}for(const n of ui.document.body.querySelectorAll('select')){const options=n.querySelectorAll('option'),chosen=options.find(q=>q.getAttribute('selected')!==undefined)||options[0];n.value=chosen?.getAttribute('value')||'';}
  const get=id=>ui.document.getElementById(id),canvas=get('canvas'),viewport=get('viewport');viewport.clientWidth=640;viewport.clientHeight=384;canvas.getBoundingClientRect=()=>({left:0,top:0});get('zoom').value='1';
  await import('../atlas/editor.mjs?bone-authoring-dom');assert(ui.document.querySelector('#smm2-bone-tools'),'real editor mounts the Bone authoring panel');
  const saved=()=>{get('save').click();return JSON.parse(values.get('xiaoq-map-workshop-tools-v1'));},pointer=(type,x,y)=>canvas.dispatchEvent({type,button:0,pointerId:1,clientX:x,clientY:y}),tool=text=>get('tools').children.find(q=>q.textContent===text).click(),pick=(layer,x,y)=>{get('layer').value=layer;get('layer').dispatchEvent({type:'change'});tool('框选 V');pointer('pointerdown',x,y);pointer('pointerup',x,y);};
  assert.deepEqual(get('materials').children.map(q=>q.textContent),Object.values(materials),'Bone tools leave the normal terrain palette intact');
  pick('objects',128,80);const palette=get('materials').children.map(q=>q.textContent);assert(palette.includes('栗宝宝'));assert(!palette.some(q=>/骨壳|枯骨|熔岩/.test(q)));
  get('copy').click();get('paste').click();let doc=saved(),copy=doc.rooms[0].smm2Mechanics.boneShells.find(q=>q.id!=='custom-shell');assert(copy,'real native paste copies the same-ID Bone sidecar');assert.deepEqual([actor(doc.rooms[0],copy.id).x,actor(doc.rooms[0],copy.id).y],[16,16]);assert.deepEqual(copy.playingDead.dropThroughIds,['ledge']);assert(doc.rooms[0].marioModules.enemySources.some(q=>q.shoeTemplateId===copy.id));
  get('delete').click();assert.equal(saved().rooms[0].smm2Mechanics.boneShells.length,1);assert.equal(saved().rooms[0].marioModules.enemySources.length,1);get('undo').click();assert.equal(saved().rooms[0].smm2Mechanics.boneShells.length,2);get('redo').click();assert.equal(saved().rooms[0].smm2Mechanics.boneShells.length,1);
  pick('objects',288,224);get('copy').click();get('paste').click();doc=saved();const dryCopy=Object.keys(doc.rooms[0].marioModules.enemyVariants).find(id=>id!=='custom-dry');assert.equal(doc.rooms[0].marioModules.enemyVariants[dryCopy].giantStompResponse,'hurt');get('delete').click();assert.deepEqual(Object.keys(saved().rooms[0].marioModules.enemyVariants),['custom-dry']);get('undo').click();assert.equal(Object.keys(saved().rooms[0].marioModules.enemyVariants).length,2);get('redo').click();
  pick('geometry',208,192);get('delete').click();assert.deepEqual(saved().rooms[0].smm2Mechanics.boneShells[0].playingDead.dropThroughIds,[]);get('undo').click();assert.deepEqual(saved().rooms[0].smm2Mechanics.boneShells[0].playingDead.dropThroughIds,['ledge']);
  pick('geometry',480,48);get('delete').click();doc=saved();assert.deepEqual(doc.rooms[0].marioModules.enemySources,[]);assert.equal(shell(doc.rooms[0],'custom-shell').templateOnly,false);get('undo').click();assert.equal(shell(saved().rooms[0],'custom-shell').templateOnly,true);
  get('layer').value='objects';get('layer').dispatchEvent({type:'change'});tool('橡皮 E');pointer('pointerdown',288,224);pointer('pointerup',288,224);assert.equal(saved().rooms[0].marioModules.enemyVariants['custom-dry'],undefined);get('undo').click();assert.equal(saved().rooms[0].marioModules.enemyVariants['custom-dry'].kind,'dry-bones');roundtrip(saved());
 }finally{for(const [key,descriptor]of savedGlobals){if(descriptor)Object.defineProperty(globalThis,key,descriptor);else delete globalThis[key];}ui.restore();}
});
