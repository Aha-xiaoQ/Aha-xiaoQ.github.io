import test from 'node:test';
import assert from 'node:assert/strict';
import {createCanvas} from '@napi-rs/canvas';
import {createNeutralGalleryRoom} from './fixtures/authored-gallery-neutral.mjs';
import {drawAuthoredSceneAccent,drawAuthoredSceneAccents,jrGalleryFlagDecorations,hubSceneAccentDecorations} from '../atlas/editor-authored-scene-accents.mjs';

test('flags end on real arch tops and remain clear of all seated spectators',()=>{
  const room=createNeutralGalleryRoom(),flags=jrGalleryFlagDecorations(room);
  assert.equal(flags.length,2);
  for(const [index,q] of flags.entries()){
    const pillar=room.map.geometry.find(g=>g.id===`boss-${index?'right':'left'}-inner-arch`);
    assert.equal(q.y+q.h,pillar.y);
    assert.equal(q.h,14);
    assert(room.smm2Mechanics.arenaAudience.seats.every(a=>q.x+q.w<=a.x||q.x>=a.x+a.w||q.y+q.h<=a.y||q.y>=a.y+a.h));
    const canvas=createCanvas(576,432),c=canvas.getContext('2d');
    assert(drawAuthoredSceneAccent(c,q,room,0));
    const alpha=c.getImageData(pillar.x,pillar.y-1,pillar.w,1).data;
    assert(alpha.some((v,n)=>n%4===3&&v===255),'Connected pole base touches real top surface');
    const frame=c.getImageData(0,0,576,432).data;
    for(let y=0;y<432;y++)for(let x=0;x<576;x++)if(frame[(y*576+x)*4+3])assert(x>=q.x&&x<q.x+q.w&&y>=q.y&&y<q.y+q.h,'Declared native-grid bounds contain every flag pixel');
  }
});

test('tagged accent draw preserves the room and canvas state, with quiet Hub alpha and no untagged fallback',()=>{
  const room={decorations:hubSceneAccentDecorations()},before=JSON.stringify(room),canvas=createCanvas(448,432),c=canvas.getContext('2d');
  c.globalAlpha=.75;c.fillStyle='#f00';const color=c.fillStyle,priorAlpha=c.globalAlpha;
  assert(drawAuthoredSceneAccents(c,room,24));assert.equal(c.globalAlpha,priorAlpha);assert.equal(c.fillStyle,color);assert.equal(JSON.stringify(room),before);
  const alpha=[...c.getImageData(0,0,448,432).data].filter((_,i)=>i%4===3);
  assert(alpha.reduce((max,value)=>Math.max(max,value),0)<=43,'Background references remain below .22 alpha');
  assert.equal(room.decorations.length,3);
  assert(room.decorations.every(q=>q.y>=280&&q.y+q.h<=322),'Clear of HUD and door/cleared badges');
  assert.equal(drawAuthoredSceneAccent(c,{material:'decoration',smm2Art:'source-scenery-cloud',x:0,y:0,w:16,h:16}),false);
  assert.equal(drawAuthoredSceneAccent(c,{...room.decorations[0],hidden:true}),false);
});
