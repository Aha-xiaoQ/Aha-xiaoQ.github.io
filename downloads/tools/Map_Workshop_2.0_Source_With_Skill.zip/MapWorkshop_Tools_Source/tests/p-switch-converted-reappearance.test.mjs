import {test} from 'node:test';
import {assertConvertedPickup,assertExpiryBoundary,assertDoorPersistence,assertLifeBoundary} from './fixtures/p-switch-converted-contact.mjs';
for(const direction of ['below','above','left','right'])test(`ordinary ${direction} pickup of P-converted empty brick has no original collision, bump or timeout return`,()=>assertConvertedPickup(direction));
for(const collectOnLastFrame of [true,false])test(`P expiry boundary ${collectOnLastFrame?'last active frame remains collectible':'first expired frame restores real brick collision'}`,()=>assertExpiryBoundary({collectOnLastFrame}));
test('eaten P-converted brick remains absent through paired-door room rebuild and expiry',()=>assertDoorPersistence());
test('default native death preserves existing one-life P reset and restores authored brick and switch',()=>assertLifeBoundary());
import {assertRealHiddenBlock,assertSplitBrick} from './fixtures/p-switch-converted-contact.mjs';
test('genuine authored hidden block retains ordinary upward discovery during P',()=>assertRealHiddenBlock());
test('compiled wide brick collects only the contacted native tile and restores its uneaten neighbor',()=>assertSplitBrick());
