import {assertNativeMotorCompatibility} from './fixtures/native-motor-compatibility.mjs';
import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import {validateSmm2CarriersRoom,createSmm2Carriers} from '../atlas/editor-smm2-carriers.mjs';
import {createSmm2Thwomps} from '../atlas/editor-smm2-thwomps.mjs';
import {createPlatformMotor} from '../atlas/editor-mario-motor.mjs';
import {createPlatformStage} from '../atlas/editor-mario-stage.mjs';
import {createSMM2Terrain} from '../atlas/editor-smm2-terrain.mjs';

const character={capabilities:['jump'],motion:{width:10,height:14,maxHealth:1}};
const spring=(id='spring',x=124,y=64)=>({id,x,y,w:16,h:16,material:'spring',collision:'solid'});
const thwomp={id:'thwomp',kind:'walker',x:120,y:80,w:24,h:32};
const thwompSpec=extra=>({id:'thwomp',direction:'down',triggerRange:200,transverseTolerance:16,leadReference:'near-edge',windupFrames:0,chargeAcceleration:.32,chargeSpeedCap:6,impactWaitFrames:8,returnSpeed:1,breakMaterials:[],...extra});
const room=(extra={})=>({roomId:'carrier-room',map:{width:512,height:384,geometry:[spring(),{id:'floor',x:0,y:240,w:512,h:16,collision:'solid'}],objects:[{...thwomp}]},smm2Mechanics:{version:1,thwomps:[thwompSpec()],carrierGeometry:[{id:'spring',carrierId:'thwomp'}]},...extra});
const geometryRoom=()=>({roomId:'carrier-room',map:{width:512,height:384,geometry:[spring('spring',124,144),{id:'lift',x:112,y:160,w:48,h:8,collision:'oneway',motion:{axis:'y',min:80,max:200,speed:1}},{id:'floor',x:0,y:272,w:512,h:16,collision:'solid'}],objects:[]},smm2Mechanics:{version:1,carrierGeometry:[{id:'spring',carrierId:'lift'}]}});
const near=(a,b)=>assert.ok(Math.abs(a-b)<1e-6,`${a} != ${b}`);
function actorHarness(r=room(),options={}){
 const carriers=createSmm2Carriers(r,options),controller=createSmm2Thwomps(r),actor={...thwomp,vx:0,vy:0},sensor={x:124,y:208,w:10,h:14},geometry=structuredClone(r.map.geometry);let tick=0,current=geometry;
 return {carriers,controller,actor,sensor,r,get geometry(){return current;},step(){tick++;const world=()=>carriers.geometryForActor(current,actor),result=controller.stepEnemy(actor,{tick,player:sensor,geometry:world(),getGeometry:world});current=carriers.apply(current,[actor],{tick});return {tick,result,spring:current.find(q=>q.id==='spring'),view:carriers.view().carrierGeometry[0]};}};
}

 test('carriers are optional and leave legacy rooms/motors untouched',async()=>{
 assert.equal(createSmm2Carriers({map:{}}),null);assert.equal(createSmm2Carriers({...room(),smm2Mechanics:{version:1}}),null);const r=room();r.smm2Mechanics.carrierGeometry=[];assert.equal(createSmm2Carriers(r),null);
 const hash=path=>crypto.createHash('sha256').update(fs.readFileSync(new URL(path,import.meta.url))).digest('hex');await assertNativeMotorCompatibility();assert.equal(hash('../atlas/runtime/platform-motor.mjs'),'033334164563b53ff456c0684b7441b81074160908d55f1245db0fe119d66f02');
 });

 test('source validation requires a unique real same-room Springboard resting on a declared top',()=>{
 const r=room(),before=JSON.stringify(r);validateSmm2CarriersRoom(r);createSmm2Carriers(r);assert.equal(JSON.stringify(r),before);validateSmm2CarriersRoom(geometryRoom());
 const bad=[r=>r.smm2Mechanics.carrierGeometry.push({id:'spring',carrierId:'thwomp'}),r=>r.smm2Mechanics.carrierGeometry[0].code='actor.y=0',r=>r.smm2Mechanics.carrierGeometry[0].carrierId='spring',r=>r.smm2Mechanics.carrierGeometry[0].carrierId='missing',r=>r.smm2Mechanics.thwomps=[],r=>r.map.geometry[0].material='stone',r=>r.map.geometry[0].collision='oneway',r=>r.map.geometry[0].y=63,r=>r.map.geometry[0].x=160,r=>r.map.geometry[0].w=Infinity,r=>r.map.geometry[0].x=-1,r=>r.map.geometry.push({...r.map.geometry[0]}),r=>r.smm2Mechanics.carrierGeometry=Array.from({length:257},()=>({id:'spring',carrierId:'thwomp'})),r=>r.map.width=NaN,r=>r.smm2Mechanics.carrierGeometry[0].id='__proto__',r=>r.smm2Mechanics.version=2];
 for(const change of bad){const input=room();change(input);assert.throws(()=>validateSmm2CarriersRoom(input));}
 const stationary=geometryRoom();delete stationary.map.geometry[1].motion;assert.throws(()=>validateSmm2CarriersRoom(stationary),/moving/);
 assert.throws(()=>createSmm2Carriers(room(),{gravity:0}),/gravity/);assert.throws(()=>createSmm2Carriers(room(),{maxFallSpeed:NaN}),/gravity/);
 });

 test('same-tick calls and collider rebuilds preserve one physical advance and native Springboard state',()=>{
 const h=actorHarness();h.step();const first=h.step(),q=first.spring;q.springAge=5;q.boost=true;q.launchVx=1.5;q.y=q.restY+4;q.h=q.restH-4;
 const before=JSON.stringify(h.carriers.view()),again=h.carriers.apply(h.geometry,[h.actor],{tick:first.tick});assert.equal(JSON.stringify(h.carriers.view()),before);assert.equal(again.find(q=>q.id==='spring').springAge,5);
 const rebuilt=h.carriers.apply(structuredClone(h.r.map.geometry),[h.actor],{tick:first.tick}),s=rebuilt.find(q=>q.id==='spring');near(s.restY,q.restY);near(s.y,q.restY+4);assert.equal(s.h,12);assert.equal(s.springAge,5);assert.equal(s.boost,true);assert.equal(s.launchVx,1.5);assert.equal(s.dx,q.dx);assert.equal(s.dy,q.dy);
 assert.equal(h.carriers.parentActorIds()[0],'thwomp');const own=h.carriers.geometryForActor(rebuilt,h.actor);assert.ok(!own.some(q=>q.id==='spring'));assert.ok(own.some(q=>q.id==='floor'));assert.equal(h.carriers.geometryForActor(rebuilt,{id:'mario'}),rebuilt);
 });

 test('real accelerating downcharge can outrun Spring gravity; landing and return recontact use actual top motion',()=>{
 const h=actorHarness();let lost=false,caught=false,returnCarried=false,last;
 for(let n=0;n<220;n++){
  const v=h.step(),q=v.spring,s=v.view;if(!q)break;if(s.phase==='airborne'&&h.actor.y>80){lost=true;assert.ok(q.restY+q.restH<h.actor.y,'falling spring remains above the outrunning carrier');}
  if(lost&&s.phase==='supported'){caught=true;near(q.restY+q.restH,h.actor.y);}
  if(caught&&h.actor.smm2Thwomp.phase==='return'&&q.dy<0){returnCarried=true;near(q.restY+q.restH,h.actor.y);}
  if(last){near(q.dx,q.x-last.x);near(q.dy,q.restY-last.y);}last={x:q.x,y:q.restY};if(returnCarried&&h.actor.smm2Thwomp.phase==='idle')break;
 }
 assert.ok(lost);assert.ok(caught);assert.ok(returnCarried);assert.equal(h.actor.y,80,'own Springboard never blocks its Thwomp return');
 });

 test('native horizontal platform transports only true support and a side wall prevents an offset snap',()=>{
 const r=geometryRoom();r.map.geometry[1].motion={axis:'x',min:112,max:200,speed:1};r.map.geometry.push({id:'wall',x:144,y:140,w:16,h:20,collision:'solid'});const c=createSmm2Carriers(r),g=structuredClone(r.map.geometry),lift=g.find(q=>q.id==='lift');let current=g,blocked=false,lost=false;
 for(let tick=1;tick<=60;tick++){lift.x+=1;lift.dx=1;lift.dy=0;current=c.apply(current,[],{tick});const q=current.find(q=>q.id==='spring'),s=c.view().carrierGeometry[0];if(s.blocked?.normal.x){blocked=true;assert.ok(q.x+q.w<=144+1e-6);}if(s.phase==='airborne')lost=true;if(tick>=40)assert.ok(q.x<=128+1e-6,'blocked spring cannot recover its source offset by snapping to the carrier');}
 assert.ok(blocked);assert.ok(lost);assert.ok(c.view().carrierGeometry[0].y>144);
 });

 test('native upward platform catches an airborne spring at a real crossing and a ceiling blocks its transport',()=>{
 const r=geometryRoom();r.map.geometry.push({id:'ceiling',x:112,y:120,w:48,h:8,collision:'solid'});const c=createSmm2Carriers(r),g=structuredClone(r.map.geometry),lift=g.find(q=>q.id==='lift');let current=g,blocked=false;
 for(let tick=1;tick<=25;tick++){lift.y-=1;lift.dx=0;lift.dy=-1;current=c.apply(current,[],{tick});const q=current.find(q=>q.id==='spring'),s=c.view().carrierGeometry[0];assert.ok(q.y>=128-1e-6);if(s.blocked?.solidId==='ceiling'){blocked=true;if(s.blocked.fraction<1-1e-7)assert.notEqual(s.supportId,'lift');}}
 assert.ok(blocked);
 });

 test('parent death or disappearance leaves a physical capped falling Springboard; reset restores source support',()=>{
 for(const absent of [false,true]){
  const h=actorHarness();h.step();h.actor.dead=true;const actors=absent?[]:[h.actor];let geometry=h.geometry,landed=false;
  for(let tick=2;tick<=100;tick++){geometry=h.carriers.apply(geometry,actors,{tick});const q=geometry.find(q=>q.id==='spring'),s=h.carriers.view().carrierGeometry[0];assert.ok(s.vy<=4.25);assert.equal(s.carrierUnavailable,true);if(s.phase==='resting'){near(q.restY+q.restH,240);assert.equal(s.supportId,'floor');landed=true;break;}}
  assert.ok(landed);h.carriers.reset();const sourceActor={...thwomp,vx:0,vy:0},sourceGeometry=h.carriers.apply(structuredClone(h.r.map.geometry),[sourceActor],{tick:1}),q=sourceGeometry.find(q=>q.id==='spring');near(q.y,64);near(q.h,16);assert.equal(h.carriers.view().carrierGeometry[0].supportId,'thwomp');assert.equal(h.carriers.view().carrierGeometry[0].carrierUnavailable,false);
 }
 });

 test('a missing carrier never leaves a floating or invisible support; off-room fall removes the collider',()=>{
 const r=room();r.map.geometry=r.map.geometry.filter(q=>q.id==='spring');const c=createSmm2Carriers(r);let g=structuredClone(r.map.geometry);for(let tick=1;tick<=140;tick++)g=c.apply(g,[],{tick});assert.ok(!g.some(q=>q.id==='spring'));assert.equal(c.view().carrierGeometry[0].phase,'removed');
 });

 test('live parent movement must match actual native displacement and source body dimensions',()=>{
 const r=room(),c=createSmm2Carriers(r),a={...thwomp,x:121};assert.throws(()=>c.apply(structuredClone(r.map.geometry),[a],{tick:1}),/lastMotion/);
 const forged={...thwomp,w:25};assert.throws(()=>createSmm2Carriers(r).apply(structuredClone(r.map.geometry),[forged],{tick:1}),/body bounds/);
 const duplicate=[{...thwomp},{...thwomp}];assert.throws(()=>createSmm2Carriers(r).apply(structuredClone(r.map.geometry),duplicate,{tick:1}),/Duplicate/);
 const native=geometryRoom(),ng=structuredClone(native.map.geometry);ng[1].y=100;ng[1].dy=0;ng[1].dx=0;const nc=createSmm2Carriers(native);const spring=nc.apply(ng,[],{tick:1}).find(q=>q.id==='spring');near(spring.y,144.3);assert.equal(nc.view().carrierGeometry[0].carrierUnavailable,true,'native rebase/wrap is loss of support rather than a player-carrying teleport');
 });

 test('dropped Springboard lands on an exact slope through the existing engine shape port',()=>{
 const r=room();r.map.geometry=r.map.geometry.filter(q=>q.id==='spring');r.smm2Mechanics.slopes=[{id:'slope',x:96,y:176,w:80,h:40,orientation:'rise-right',collision:'solid'}];const terrain=createSMM2Terrain(r),carriers=createSmm2Carriers(r,{terrain});let geometry=structuredClone(r.map.geometry),landed=false;
 for(let tick=1;tick<=100;tick++){terrain.beginFrame({tick});geometry=carriers.apply(geometry,[],{tick});const s=carriers.view().carrierGeometry[0];if(s.supportId==='slope'){const q=geometry.find(q=>q.id==='spring');near(q.y+q.h,194);landed=true;break;}}
 assert.ok(landed);
 });

 for(const held of [false,true])test(`a real supported Springboard reuses the native ${held?'high':'normal'} bounce without force changes`,()=>{
 const r=geometryRoom();r.map.objects=[{id:'start',kind:'spawn',x:126,y:130,w:10,h:14}];const carriers=createSmm2Carriers(r),geometry=carriers.apply(structuredClone(r.map.geometry),[],{tick:1}),visual={...r,map:{...r.map,geometry},smm2Mechanics:{version:1}},events=[],stage=createPlatformStage({plan:{stage:{entryRoom:r.roomId,entrySpawn:'start',title:'Native supported Springboard'},character,rooms:{[r.roomId]:visual.map}},visualRooms:[visual],motor:createPlatformMotor(),emit:(type,data)=>events.push({type,...data})});let compressed=false,launch=null;
 for(let n=0;n<30;n++){stage.step({jump:held});const v=stage.view(),q=v.geometry.find(q=>q.id==='spring');compressed||=q.h<16;if(v.p.vy<-5.5){launch=v.p;break;}}
 assert.ok(compressed);assert.ok(launch);assert.equal(launch.vy,held?-9:-6);assert.equal(launch.jumpG,.22);assert.equal(launch.fallG,.32);assert.ok(events.some(e=>e.event==='jump'));
 });

for(const big of [false,true])test(`fresh native ${big?'Big':'Small'} rider follows measured Springboard displacement and retains native jump controls`,()=>{
 const r=geometryRoom(),carriers=createSmm2Carriers(r),motor=createPlatformMotor(),p={...motor.create(character,{x:126,y:big?116:130}),...(big?{power:1,h:28}:{})};let geometry=structuredClone(r.map.geometry),lift=geometry.find(q=>q.id==='lift');
 for(let tick=1;tick<=20;tick++){lift.y-=1;lift.dx=0;lift.dy=-1;geometry=carriers.apply(geometry,[],{tick});const q=geometry.find(q=>q.id==='spring');motor.step(p,{},character,{width:512,solids:geometry});assert.equal(p.support,'spring');assert.equal(p.grounded,true);assert.equal(p.h,big?28:14);near(p.y+p.h,q.y);near(q.dy,-1);assert.equal(q.h,16);}
 const before={...p},baseline={...p,support:'baseline'},input={x:1,jumpPressed:true,jump:true},flat={id:'baseline',x:0,y:p.y+p.h,w:512,h:16,collision:'solid'},expected=motor.step(baseline,input,character,{width:512,solids:[flat]});lift.y-=1;lift.dy=-1;geometry=carriers.apply(geometry,[],{tick:21});assert.deepEqual(motor.step(p,input,character,{width:512,solids:geometry}),expected);assert.equal(p.vy,baseline.vy);assert.equal(p.vx,baseline.vx);near(p.y,baseline.y-1);assert.equal(p.support,null);assert.equal(p.grounded,false);assert.ok(p.y<before.y);
});

test('an upward returning native top catches a genuinely separated falling spring by positive-time crossing',()=>{
 const r=geometryRoom();r.map.geometry[1].motion.speed=2;const carriers=createSmm2Carriers(r);let geometry=structuredClone(r.map.geometry),lift=geometry.find(q=>q.id==='lift');for(let tick=1;tick<=8;tick++){lift.y+=2;lift.dx=0;lift.dy=2;geometry=carriers.apply(geometry,[],{tick});assert.equal(carriers.view().carrierGeometry[0].phase,'airborne');}
 const separated=carriers.view().carrierGeometry[0];assert.ok(separated.y+separated.h<lift.y);let caught=null;
 for(let tick=9;tick<=14;tick++){lift.y-=2;lift.dy=-2;geometry=carriers.apply(geometry,[],{tick});const s=carriers.view().carrierGeometry[0];if(s.phase==='supported'){caught=s;break;}}
 assert.ok(caught?.contact.parentTop);assert.ok(caught.contact.fraction>0&&caught.contact.fraction<1);near(caught.y+caught.h,lift.y);near(caught.contact.body.y+caught.h,caught.contact.point.y);
});

test('current source twin Springs validate over their real narrowed native Thwomp bodies',()=>{
 const r=room();r.map.geometry=[spring('spring-left',1296,64),spring('spring-right',1312,64)];r.map.width=2048;r.map.objects=[{...thwomp,x:1300}];r.smm2Mechanics.carrierGeometry=[{id:'spring-left',carrierId:'thwomp'},{id:'spring-right',carrierId:'thwomp'}];validateSmm2CarriersRoom(r);const c=createSmm2Carriers(r),geometry=c.apply(structuredClone(r.map.geometry),[{...r.map.objects[0]}],{tick:1});assert.deepEqual(c.parentActorIds(),['thwomp']);for(const q of geometry){near(q.y,64);near(q.y+q.h,80);assert.equal(q.smm2CarrierGeometry.supportId,'thwomp');}assert.ok(!c.geometryForActor(geometry,{id:'thwomp'}).length);
});

function upwardContact({dy=-1,dx=0,compression=0,extra=[],terrain=null}={}){
 const r=geometryRoom();r.map.geometry.push(...extra);const c=createSmm2Carriers(r,{terrain});let g=structuredClone(r.map.geometry),lift=g.find(q=>q.id==='lift');g=c.apply(g,[],{tick:1});const q=g.find(q=>q.id==='spring');q.y+=compression;q.h-=compression;q.springAge=compression?11:0;
 const previous=structuredClone(q);lift.y+=dy;lift.x+=dx;lift.dy=dy;lift.dx=dx;g=c.apply(g,[],{tick:2});return {r,c,g,previous,current:g.find(q=>q.id==='spring')};
}

for(const big of [false,true])for(const axis of [-1,1])test(`measured moving Spring top preserves ${big?'Big':'Small'} ${axis<0?'left':'right'} airborne launch velocity and avoids native sideways shove`,()=>{
 const {c,g,previous,current}=upwardContact(),motor=createPlatformMotor(),p={...motor.create(character,{x:126,y:previous.y-(big?28:14)}),...(big?{power:1,h:28}:{}),vx:axis*1.5,vy:-9,jumpG:.22,fallG:.32,support:null,grounded:false},unadapted={...p};
 motor.step(unadapted,{x:axis,jump:true},character,{solids:g,width:512});assert.equal(unadapted.x,axis>0?114:140);assert.equal(unadapted.vx,0,'fixture reproduces horizontal collision with the actual rising Spring');
 const before={...p},contact=c.beforeActor(p,{tick:2,geometry:g});assert.equal(contact.kind,'moving-spring-top');near(contact.requiredDy,-1);near(contact.dy,-1);near(contact.crossings[0].fraction,0);near(p.y+p.h,current.y);assert.equal(p.x,before.x);assert.equal(p.vx,before.vx);assert.equal(p.vy,before.vy);assert.equal(p.grounded,false);assert.equal(p.support,null);assert.equal(g.find(q=>q.id==='spring'),current,'the real Spring collider remains');
 assert.equal(c.beforeActor(p,{tick:2,geometry:g}),null);const after={...p};c.apply(g,[],{tick:2});assert.equal(c.beforeActor(p,{tick:2,geometry:g}),null);assert.deepEqual(p,after);
 motor.step(p,{x:axis,jump:true},character,{solids:g,width:512});near(p.x,126+axis*1.5);near(p.vx,axis*1.5);near(p.vy,-8.78);near(p.y,before.y-1-8.78);assert.equal(p.grounded,false);assert.equal(p.support,null);
});

test('top crossing uses prior actual compression, positive crossing time, and rebuilt current geometry',()=>{
 const {c,g,previous,current}=upwardContact({dy:-4,compression:3});assert.equal(previous.y,147);assert.equal(previous.h,13);assert.equal(current.y,143);assert.equal(current.h,13);
 const p={x:126,y:145-14,w:10,h:14,vx:-.75,vy:-6,grounded:false,support:null};const rebuilt=c.apply(structuredClone(geometryRoom().map.geometry),[],{tick:2});const contact=c.beforeActor(p,{tick:2,geometry:rebuilt});near(contact.crossings[0].fraction,.5);near(contact.dy,-2);near(p.y+p.h,143);assert.equal(p.vx,-.75);assert.equal(p.vy,-6);
});

test('crossing requires both true crossing-time overlap and current overlap, with exact edges rejected',()=>{
 const nowOnly=upwardContact({dy:-4,dx:16});const p={x:145,y:143-14,w:10,h:14,vx:1,vy:-6,grounded:false};assert.equal(nowOnly.c.beforeActor(p,{tick:2,geometry:nowOnly.g}),null,'Spring right=144 at crossing, although current right=156');
 const thenOnly=upwardContact({dy:-4,dx:16});assert.equal(thenOnly.c.beforeActor({...p,x:125},{tick:2,geometry:thenOnly.g}),null,'crossing-time overlap cannot carry an actor after horizontal separation');
 const edge=upwardContact();assert.equal(edge.c.beforeActor({...p,x:140,y:144-14},{tick:2,geometry:edge.g}),null);
 const noCross=upwardContact();for(const change of [{y:142-14},{y:145-14},{vy:0},{vy:1},{grounded:true},{dead:true},{dying:true},{removed:true},{visible:false},{w:0},{w:257},{x:Infinity},{y:NaN},{vy:-Infinity}])assert.equal(noCross.c.beforeActor({...p,x:126,y:144-14,...change},{tick:2,geometry:noCross.g}),null);
 const down=upwardContact({dy:1});assert.equal(down.c.beforeActor({...p,x:126,y:144-14},{tick:2,geometry:down.g}),null);const still=upwardContact({dy:0});assert.equal(still.c.beforeActor({...p,x:126,y:144-14},{tick:2,geometry:still.g}),null);
});

for(const big of [false,true])test(`a real ceiling clamps ${big?'Big':'Small'} top separation without velocity, support or reward changes`,()=>{
 const h=big?28:14,bodyTop=142-h,{c,g}=upwardContact({dy:-4,extra:[{id:'roof',x:120,y:bodyTop-16.5,w:32,h:16,collision:'solid'}]}),p={x:126,y:bodyTop,w:10,h,vx:1.5,vy:-9,grounded:false,support:null};const before={...p},contact=c.beforeActor(p,{tick:2,geometry:g});near(contact.requiredDy,-2);near(contact.dy,-.5);assert.equal(contact.blocked.solidId,'roof');near(p.y,bodyTop-.5);assert.equal(p.vx,before.vx);assert.equal(p.vy,before.vy);assert.equal(p.support,null);assert.equal(p.grounded,false);
});

test('solid side corners and exact triangular undersides block the swept correction; one-way undersides stay open',()=>{
 const wall={id:'corner',x:134,y:113,w:16,h:15},h=upwardContact({dy:-4,extra:[{...wall,collision:'solid'}]}),p={x:126,y:129,w:10,h:14,vx:1,vy:-6,grounded:false};const hit=h.c.beforeActor(p,{tick:2,geometry:h.g});near(hit.dy,-1);assert.equal(hit.blocked.solidId,'corner');near(p.y,128);
 const open=upwardContact({dy:-4,extra:[{...wall,collision:'oneway'}]}),other={...p,y:129};near(open.c.beforeActor(other,{tick:2,geometry:open.g}).dy,-3);
 const r=geometryRoom();r.smm2Mechanics.slopes=[{id:'ceiling-triangle',x:120,y:111,w:32,h:32,orientation:'ceiling-rise-left',collision:'solid'}];const terrain=createSMM2Terrain(r);terrain.beginFrame({tick:2});const shape=upwardContact({dy:-4,terrain}),actor={x:126,y:129,w:10,h:14,vx:1,vy:-6,grounded:false},result=shape.c.beforeActor(actor,{tick:2,geometry:shape.g});assert.equal(result.blocked.solidId,'ceiling-triangle');near(result.dy,-2);assert.equal(actor.x,126);assert.equal(actor.vx,1);assert.equal(actor.vy,-6);
 const embedded={...actor,y:126.5};const trapped=shape.c.beforeActor(embedded,{tick:2,geometry:shape.g});assert.equal(trapped.dy,0);assert.equal(trapped.blocked.embedded,true);
});

test('native hidden block underside stops correction while hidden side passage stays open',()=>{
 const h=upwardContact({dy:-4,extra:[{id:'hidden-roof',x:120,y:112,w:32,h:16,collision:'solid',hidden:true}]}),p={x:126,y:129,w:10,h:14,vx:1,vy:-6,grounded:false};const contact=h.c.beforeActor(p,{tick:2,geometry:h.g});near(contact.dy,-1);assert.equal(contact.blocked.solidId,'hidden-roof');
 const side=upwardContact({dy:-4,extra:[{id:'hidden-side',x:134,y:129,w:16,h:16,collision:'solid',hidden:true}]}),a={...p,y:129};near(side.c.beforeActor(a,{tick:2,geometry:side.g}).dy,-3);
});

test('adjacent crossed managed Springs clear together while unrelated solid Springs still block',()=>{
 const r=geometryRoom();r.map.geometry.push(spring('spring-two',140,144));r.smm2Mechanics.carrierGeometry.push({id:'spring-two',carrierId:'lift'});const c=createSmm2Carriers(r);let g=c.apply(structuredClone(r.map.geometry),[],{tick:1}),lift=g.find(q=>q.id==='lift');lift.y-=2;lift.dy=-2;lift.dx=0;g=c.apply(g,[],{tick:2});const actor=()=>({x:134,y:130,w:10,h:14,vx:1,vy:-6,grounded:false,support:null});const contact=c.beforeActor(actor(),{tick:2,geometry:g});assert.equal(contact.crossings.length,2);near(contact.dy,-2);assert.equal(contact.blocked,null);assert.equal(g.filter(q=>q.material==='spring').length,2);
 const p=actor(),withOther=[...g,{id:'other-spring',x:138,y:112,w:16,h:17,material:'spring',collision:'solid'}],blocked=c.beforeActor(p,{tick:2,geometry:withOther});assert.equal(blocked.blocked.solidId,'other-spring');near(blocked.dy,-1);assert.equal(p.support,null);
});

test('exact triangle empty half permits correction and its genuine inclined underside blocks without a slide',()=>{
 const r=geometryRoom();r.smm2Mechanics.slopes=[{id:'ceiling-slope',x:120,y:114,w:32,h:16,orientation:'ceiling-rise-right',collision:'solid'}];const terrain=createSMM2Terrain(r);terrain.beginFrame({tick:2});
 for(const [rise,expected]of [[1,-1],[4,-3]]){const h=upwardContact({dy:-rise,terrain}),p={x:126,y:130,w:10,h:14,vx:1.5,vy:-9,grounded:false,support:null},contact=h.c.beforeActor(p,{tick:2,geometry:h.g});near(contact.dy,expected);near(p.y,130+expected);assert.equal(p.x,126);assert.equal(p.vx,1.5);assert.equal(p.vy,-9);assert.equal(p.support,null);if(rise===1)assert.equal(contact.blocked,null);else{assert.equal(contact.blocked.solidId,'ceiling-slope');near(contact.blocked.fraction,.75);}}
});

test('current contact history rejects tampered colliders, invalid frames, stale ticks, and clears on reset/death',()=>{
 const h=upwardContact(),p=()=>({x:126,y:130,w:10,h:14,vx:1.5,vy:-9,grounded:false,support:null});const forged=structuredClone(h.g);forged.find(q=>q.id==='spring').y-=10;assert.equal(h.c.beforeActor(p(),{tick:2,geometry:forged}),null);assert.equal(h.c.beforeActor(p(),{tick:2,geometry:h.g.filter(q=>q.id!=='spring')}),null);assert.equal(h.c.beforeActor(p(),{tick:1,geometry:h.g}),null);assert.throws(()=>h.c.beforeActor(p(),{tick:2,geometry:[...h.g,h.g[0]]}),/Duplicate/);assert.throws(()=>h.c.beforeActor(p(),{tick:Infinity,geometry:h.g}),/frame/);
 const sameActor=p();assert.ok(h.c.beforeActor(sameActor,{tick:2,geometry:h.g}));h.c.reset();assert.equal(h.c.beforeActor(p(),{tick:2,geometry:h.g}),null);const rebuilt=h.c.apply(structuredClone(h.r.map.geometry),[],{tick:2});sameActor.y=130;assert.equal(h.c.beforeActor(sameActor,{tick:2,geometry:rebuilt}),null,'reset has no historical upward displacement');
 const dead=upwardContact();dead.c.apply(dead.g,[],{tick:3});const removed=dead.c.apply(dead.g,[],{tick:4});assert.equal(dead.c.beforeActor({...p(),dead:true},{tick:4,geometry:removed}),null);
 const badHistory=upwardContact();badHistory.current.x+=1;assert.throws(()=>badHistory.c.apply(badHistory.g,[],{tick:3}),/actual owned body/);
});
