import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {blank,History,parseProject,validate,deleteSelection} from '../atlas/editor-model.mjs';
import {
 BEETLE_SHELL_SOURCE_AUTHORING_DEFAULTS,setMarioModulesEnabled,setMarioSource,
 updateMarioModuleRecord,removeMarioModuleRecord,mountMarioModulesEditor,
 captureMarioEmptyShellSources,appendCopiedMarioEmptyShellSources,pruneMarioEmptyShellReferences,
} from '../atlas/editor-mario-modules-editor.mjs';
import {projectPack} from '../atlas/editor-runtime.mjs';
import {createStageCatalog} from '../atlas/runtime/stage-catalog.mjs';
import {createCollection,addLevel,parseCollection,serializeCollection,buildCollection} from '../atlas/editor-collection.mjs';
import {createMarioModules} from '../atlas/editor-mario-modules.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';

const character=JSON.parse(fs.readFileSync(new URL('../atlas/runtime/character.json',import.meta.url)));
function project(){
 const doc=blank('Empty shell authoring fixture',640,384),r=doc.rooms[0];
 r.map.geometry=[{id:'floor',x:0,y:352,w:640,h:32,material:'ground',collision:'solid'},{id:'pipe',x:480,y:64,w:32,h:64,material:'pipe',collision:'solid'},{id:'other-pipe',x:560,y:64,w:32,h:64,material:'pipe',collision:'solid'}];
 r.map.objects=[{id:'start',kind:'spawn',x:16,y:338,w:10,h:14},{id:'plain-walker',kind:'walker',x:208,y:336,w:16,h:16}];
 return doc;
}
const values=(extra={})=>({pipeId:'pipe',...BEETLE_SHELL_SOURCE_AUTHORING_DEFAULTS,...extra});
const supplies=r=>r.marioModules.enemySources||[];
const roundtrip=doc=>assert.deepEqual(parseProject(JSON.stringify(doc)),doc);
function author(doc=project()){const r=doc.rooms[0];setMarioModulesEnabled(r,true);const key=setMarioSource(r,null,null,'beetle-shell',values());return{doc,key};}

test('empty Buzzy Beetle shell API adds, updates, converts and removes a stable source without a placed item or template',()=>{
 const h=new History(project()),r=()=>h.doc.rooms[0];h.change(()=>setMarioModulesEnabled(r(),true));let key;
 h.change(()=>{key=setMarioSource(r(),null,null,'beetle-shell',values());});const source=supplies(r())[0];
 assert.equal(key.collection,'enemySources');assert.deepEqual(source,{...values(),id:key.id,enemy:'beetle-shell'});assert.equal(r().map.objects.length,2);assert.equal(r().smm2Mechanics,undefined);roundtrip(h.doc);
 h.change(()=>setMarioSource(r(),key.collection,key.id,'beetle-shell',values({direction:'up',intervalFrames:300,initialDelayFrames:60,maxAlive:3,maxEmissions:5,activationDistance:128,vx:.25,vy:-.5,emergenceFrames:48})));
 assert.equal(supplies(r())[0].id,key.id);assert.equal(supplies(r())[0].emergenceFrames,48);const edited=structuredClone(h.doc);h.undo();assert.equal(supplies(r())[0].emergenceFrames,24);h.redo();assert.deepEqual(h.doc,edited);
 h.change(()=>{key=setMarioSource(r(),key.collection,key.id,'goomba',values({emergenceFrames:12}));});assert.equal(supplies(r())[0].enemy,'goomba');
 h.change(()=>{key=setMarioSource(r(),key.collection,key.id,'beetle-shell',values());});assert.equal(supplies(r())[0].enemy,'beetle-shell');
 const {emergenceFrames,smart,...item}=values();h.change(()=>{key=setMarioSource(r(),key.collection,key.id,'life',item);});assert.equal(key.collection,'itemSources');assert.equal(supplies(r()).length,0);assert.equal(r().marioModules.itemSources[0].id,source.id);
 h.change(()=>{key=setMarioSource(r(),key.collection,key.id,'beetle-shell',values());});assert.equal(r().marioModules.itemSources.length,0);assert.equal(supplies(r())[0].id,source.id);
 createStageCatalog(projectPack(parseProject(JSON.stringify(h.doc)),r().roomId,character,'empty-shell-authoring'));
 h.change(()=>removeMarioModuleRecord(r(),key.collection,key.id));assert.deepEqual(supplies(r()),[]);h.undo();assert.equal(supplies(r())[0].id,source.id);h.redo();roundtrip(h.doc);
});

test('empty-shell authoring and importer reject missing duration, template ownership, runtime flags and bounded-field violations atomically',()=>{
 const {doc,key}=author(),r=doc.rooms[0],before=structuredClone(r);
 const badValues=[{pipeId:'floor'},{pipeId:'missing'},{direction:'diagonal'},{intervalFrames:0},{initialDelayFrames:-1},{maxAlive:0},{maxAlive:33},{maxEmissions:0},{maxEmissions:1001},{activationDistance:-1},{vx:9},{vy:13},{smart:true},{smart:null},{smart:'false'},{emergenceFrames:0},{emergenceFrames:241},{emergenceFrames:1.5},{emergenceFrames:null},{shoeTemplateId:'plain-walker'},{shell:true},{emptyShell:true},{type:'beetle'},{moduleSource:'forged-source'}];
 for(const bad of badValues){assert.throws(()=>setMarioSource(r,key.collection,key.id,'beetle-shell',values(bad)),undefined,JSON.stringify(bad));assert.deepEqual(r,before);}
 const missing=values();delete missing.emergenceFrames;assert.throws(()=>setMarioSource(r,key.collection,key.id,'beetle-shell',missing));assert.deepEqual(r,before);
 for(const mutate of [q=>q.smart=true,q=>delete q.emergenceFrames,q=>q.shoeTemplateId='plain-walker',q=>q.emptyShell=true,q=>q.enemy='shellmet']){const invalid=structuredClone(doc);mutate(supplies(invalid.rooms[0])[0]);assert.throws(()=>parseProject(JSON.stringify(invalid)));}
 assert.throws(()=>updateMarioModuleRecord(r,'enemySources',key.id,{...supplies(r)[0],smart:true}));assert.deepEqual(r,before);
 for(const emergenceFrames of [1,240]){setMarioSource(r,key.collection,key.id,'beetle-shell',values({emergenceFrames}));assert.equal(supplies(r)[0].emergenceFrames,emergenceFrames);}
});

test('actual pipe sidebar exposes separate empty-shell supply, editable stationary defaults and atomic conversion/history',()=>{
 const ui=installSimulatedPlayDom();try{
  const h=new History(project()),r=()=>h.doc.rooms[0],parent=ui.document.createElement('aside'),reports=[];
  const panel=mountMarioModulesEditor({parent,room:r,change:fn=>h.change(fn),report:s=>reports.push(s)}),get=id=>parent.querySelector('[data-module-control="'+id+'"]'),change=id=>get(id).dispatchEvent({type:'change'}),apply=()=>get('source-apply').parentNode.dispatchEvent({type:'submit'});
  get('enabled').checked=true;change('enabled');const choice=get('source-kind').children.find(q=>q.value==='beetle-shell');assert(choice);assert.match(choice.textContent,/空 Buzzy Beetle 壳/);assert.match(parent.textContent,/预放 Shellmet 是戴在头上的道具/);assert.match(parent.textContent,/未校准 Nintendo 原作时序/);
  get('source-kind').value='beetle-shell';change('source-kind');get('source-add').click();assert.equal(supplies(r()).length,1,reports.join(';'));const id=supplies(r())[0].id;
  assert.deepEqual(supplies(r())[0],{...values(),id,enemy:'beetle-shell'});assert.equal(get('source-direction').value,'down');assert.equal(Number(get('source-vx').value),0);assert.equal(Number(get('source-vy').value),0);assert.equal(Number(get('source-emergenceFrames').value),24);assert.equal(get('source-emergenceFrames').required,true);assert.equal(get('source-emergenceFrames').disabled,false);assert.equal(get('source-smart').disabled,true);assert.equal(get('source-smart').checked,false);assert.equal(get('source-shoe-template').disabled,true);assert.match(get('source-select').children[0].textContent,/空 Buzzy Beetle 壳/);
  get('source-direction').value='right';get('source-vx').value='.5';get('source-vy').value='-.25';get('source-emergenceFrames').value='60';get('source-intervalFrames').value='240';get('source-maxAlive').value='2';get('source-maxEmissions').value='4';apply();assert.equal(supplies(r())[0].vx,.5);assert.equal(supplies(r())[0].emergenceFrames,60);assert.equal(supplies(r())[0].maxAlive,2);assert.equal(supplies(r())[0].maxEmissions,4);assert.equal(supplies(r())[0].id,id);
  const valid=structuredClone(h.doc),undos=h.undoStack.length;get('source-emergenceFrames').value='';apply();assert.deepEqual(h.doc,valid);assert.equal(h.undoStack.length,undos);assert(reports.length);h.undo();panel.refresh();assert.equal(Number(get('source-emergenceFrames').value),24);h.redo();panel.refresh();assert.equal(Number(get('source-emergenceFrames').value),60);
  get('source-kind').value='star';change('source-kind');apply();assert.equal(r().marioModules.itemSources[0].id,id);assert.deepEqual(supplies(r()),[]);assert.equal(get('source-emergenceFrames').disabled,true);
  get('source-kind').value='beetle-shell';change('source-kind');assert.equal(Number(get('source-emergenceFrames').value),24);apply();assert.equal(supplies(r())[0].id,id);assert.equal(supplies(r())[0].smart,false);assert.equal(Object.hasOwn(supplies(r())[0],'shoeTemplateId'),false);
  get('source-remove').click();assert.deepEqual(supplies(r()),[]);h.undo();panel.refresh();assert.equal(get('source-kind').value,'beetle-shell');h.redo();panel.refresh();roundtrip(h.doc);
 }finally{ui.restore();}
});

test('pipe clipboard copies only attached empty-shell sources with fresh IDs and deletion/undo preserves their authored values',()=>{
 const {doc,key}=author(),h=new History(doc),r=()=>h.doc.rooms[0];h.change(()=>setMarioSource(r(),null,null,'beetle-shell',values({pipeId:'other-pipe',emergenceFrames:36})));
 const original=structuredClone(supplies(r()).find(q=>q.id===key.id)),snapshot=captureMarioEmptyShellSources(r(),new Set(['pipe']));assert.deepEqual(snapshot.enemySources,[original]);assert.deepEqual(captureMarioEmptyShellSources(r(),new Set(['plain-walker'])).enemySources,[]);
 const idMap=new Map([['pipe','copied-pipe']]);h.change(()=>{r().map.geometry.push({...r().map.geometry.find(q=>q.id==='pipe'),id:'copied-pipe',x:320});appendCopiedMarioEmptyShellSources(r(),snapshot,idMap);});
 const copy=supplies(r()).find(q=>q.pipeId==='copied-pipe');assert(copy);assert.notEqual(copy.id,key.id);assert.deepEqual(copy,{...original,id:copy.id,pipeId:'copied-pipe'});assert.equal(new Set(supplies(r()).map(q=>q.id)).size,3);roundtrip(h.doc);
 const copied=structuredClone(h.doc);h.change(()=>{const before=structuredClone(r());deleteSelection(r(),'geometry',new Set(['copied-pipe']));pruneMarioEmptyShellReferences(r(),before);});assert.equal(supplies(r()).length,2);assert(supplies(r()).some(q=>q.id===key.id));h.undo();assert.deepEqual(h.doc,copied);h.redo();roundtrip(h.doc);
 const before=structuredClone(r());assert.throws(()=>h.change(()=>appendCopiedMarioEmptyShellSources(r(),snapshot,new Map())));assert.deepEqual(r(),before);
 const target=project().rooms[0];target.roomId='other';target.map.geometry.push({...target.map.geometry.find(q=>q.id==='pipe'),id:'target-pipe',x:320});appendCopiedMarioEmptyShellSources(target,snapshot,new Map([['pipe','target-pipe']]));assert.equal(supplies(target)[0].pipeId,'target-pipe');assert.notEqual(supplies(target)[0].id,key.id);validate({...project(),rooms:[target]});
});

test('deleted-pipe cleanup preserves newly malformed empty-shell references for strict validation',()=>{
 const {doc,key}=author(),r=doc.rooms[0],before=structuredClone(r);deleteSelection(r,'geometry',new Set(['pipe']));
 supplies(r).push({...supplies(before)[0],id:'new-dangling-source'});pruneMarioEmptyShellReferences(r,before);assert.deepEqual(supplies(r).map(q=>q.id),['new-dangling-source']);assert.throws(()=>parseProject(JSON.stringify(doc)));
 const valid=author().doc,original=structuredClone(valid.rooms[0]);supplies(valid.rooms[0])[0].pipeId='missing-new-pipe';const malformed=structuredClone(valid.rooms[0]);pruneMarioEmptyShellReferences(valid.rooms[0],original);assert.deepEqual(valid.rooms[0],malformed);assert.throws(()=>parseProject(JSON.stringify(valid)));assert.equal(key.collection,'enemySources');
});

test('qcollection serialization and matching native compilation retain empty-shell author values and runtime typing',()=>{
 const {doc,key}=author(),collection=addLevel(createCollection('Empty shell neutral collection'),doc,{id:'empty-shell-neutral'}),imported=parseCollection(serializeCollection(collection));
 assert.deepEqual(imported.levels[0].project.rooms[0].marioModules,doc.rooms[0].marioModules);const compiled=buildCollection(imported,character,{includePending:true}),level=compiled.levels[0],r=level.rooms[0];
 assert.deepEqual(supplies(r)[0],supplies(doc.rooms[0])[0]);assert.equal(supplies(r)[0].id,key.id);assert.equal(level.pack.maps[0].marioModules,undefined);assert.equal(level.pack.maps[0].smm2Mechanics,undefined);createStageCatalog(level.pack);
 const m=createMarioModules(r),actor=m.spawnEnemies({player:{x:480},tick:1,geometry:r.map.geometry})[0];assert(actor);assert.deepEqual([actor.type,actor.w,actor.h,actor.shell,actor.emptyShell],['beetle',16,16,true,true]);assert.equal(actor.moduleSource,key.id);assert.equal(actor.moduleEmergence.totalFrames,24);
});

test('real editor native pipe copy/delete/eraser, history and qmap file export/import retain empty-shell supply IDs',async()=>{
 const ui=installSimulatedPlayDom(),globals=new Map(),install=(key,value)=>{globals.set(key,Object.getOwnPropertyDescriptor(globalThis,key));Object.defineProperty(globalThis,key,{value,writable:true,configurable:true});};
 try{
  const {doc:initial,key}=author(),stored=new Map([['xiaoq-map-workshop-tools-v1',JSON.stringify(initial)]]),exports=[];
  install('localStorage',{getItem:key=>stored.get(key)||null,setItem:(key,value)=>stored.set(key,value)});install('devicePixelRatio',1);install('ResizeObserver',class{observe(){}});install('setTimeout',()=>1);install('clearTimeout',()=>{});install('confirm',()=>true);
  const OriginalURL=globalThis.URL;install('URL',class extends OriginalURL{static createObjectURL(blob){exports.push(blob);return 'blob:neutral-empty-shell-export';}static revokeObjectURL(){}});
  ui.Element.prototype.closest=function(selector){for(let n=this;n;n=n.parentNode)if(selector.split(',').some(q=>q===n.tag||q==='.'+n.className||q==='#'+n.id))return n;return null;};ui.Element.prototype.removeAttribute=function(key){delete this.attributes[key];};ui.Element.prototype.after=function(node){const p=this.parentNode,i=p.children.indexOf(this);node.parentNode=p;p.children.splice(i+1,0,node);};
  const html=fs.readFileSync(new URL('../atlas/editor.html',import.meta.url),'utf8');ui.document.body.innerHTML=html.match(/<body[^>]*>([\s\S]*?)<\/body>/)[1];for(const n of ui.document.body.querySelectorAll('input')){n.value=n.getAttribute('value')||'';n.checked=n.getAttribute('checked')!==undefined;}for(const n of ui.document.body.querySelectorAll('select')){const options=n.querySelectorAll('option'),chosen=options.find(q=>q.getAttribute('selected')!==undefined)||options[0];n.value=chosen?.getAttribute('value')||'';}
  const get=id=>ui.document.getElementById(id),canvas=get('canvas'),viewport=get('viewport');viewport.clientWidth=640;viewport.clientHeight=384;canvas.getBoundingClientRect=()=>({left:0,top:0});get('zoom').value='1';
  await import('../atlas/editor.mjs?empty-shell-authoring-dom');assert(ui.document.querySelector('#mario-modules-editor'));
  const saved=()=>{get('save').click();return JSON.parse(stored.get('xiaoq-map-workshop-tools-v1'));},pointer=(type,x,y)=>canvas.dispatchEvent({type,button:0,pointerId:1,clientX:x,clientY:y}),tool=text=>get('tools').children.find(q=>q.textContent===text).click();
  get('layer').value='geometry';get('layer').dispatchEvent({type:'change'});tool('框选 V');pointer('pointerdown',480,64);pointer('pointerup',480,64);get('copy').click();get('paste').click();let doc=saved(),r=doc.rooms[0],copy=supplies(r).find(q=>q.id!==key.id);assert(copy,get('message').textContent);assert.notEqual(copy.pipeId,'pipe');assert.equal(r.map.geometry.find(q=>q.id===copy.pipeId).x,16);assert.deepEqual(copy,{...supplies(initial.rooms[0])[0],id:copy.id,pipeId:copy.pipeId});
  const copiedId=copy.id;get('delete').click();assert.deepEqual(supplies(saved().rooms[0]).map(q=>q.id),[key.id]);get('undo').click();assert(supplies(saved().rooms[0]).some(q=>q.id===copiedId));get('redo').click();assert.deepEqual(supplies(saved().rooms[0]).map(q=>q.id),[key.id]);
  tool('橡皮 E');pointer('pointerdown',480,64);pointer('pointerup',480,64);assert.deepEqual(supplies(saved().rooms[0]),[]);get('undo').click();assert.equal(supplies(saved().rooms[0])[0].id,key.id);
  get('export').click();assert.equal(exports.length,1);const text=await exports[0].text(),exported=parseProject(text);assert.equal(supplies(exported.rooms[0])[0].id,key.id);ui.document.querySelector('[data-module-control="source-remove"]').click();assert.deepEqual(supplies(saved().rooms[0]),[]);
  get('file').files=[{size:Buffer.byteLength(text),text:async()=>text}];await get('file').onchange();doc=saved();assert.deepEqual(supplies(doc.rooms[0]),supplies(exported.rooms[0]));assert.equal(supplies(doc.rooms[0])[0].id,key.id);roundtrip(doc);
 }finally{for(const [key,descriptor]of globals){if(descriptor)Object.defineProperty(globalThis,key,descriptor);else delete globalThis[key];}ui.restore();}
});
