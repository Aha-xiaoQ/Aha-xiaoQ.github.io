import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {createCanvas,loadImage} from '@napi-rs/canvas';
import {drawObject,drawHud} from '../atlas/editor-art.mjs';
import {drawKey,drawKeyHud,drawDoor,drawContraptionsActor} from '../atlas/editor-contraptions-art.mjs';
import {nativeWorld} from '../render-lantern-course-native-canvas.mjs';
import {SMM1_SMB1_KEY_DOOR_SOURCE_PIXELS as sources} from '../atlas/editor-smm1-key-door-source-pixels.mjs';
import {SMM2_SOURCE_PIXELS,drawSmm2SourcePixels} from '../atlas/editor-smm2-source-assets.mjs';
import {parseProject,runtimeMap} from '../atlas/editor-model.mjs';
import {nativeSession} from './fixtures/shell-coin-native.mjs';
import {smb1KeyDoorArtProject,runKeyDoorArtFixture} from './fixtures/smb1-key-door-art.mjs';

const bytes=c=>c.getContext('2d').getImageData(0,0,c.width,c.height).data;
const sha=b=>createHash('sha256').update(b).digest('hex');
const fallback={smm2Mechanics:{version:1,art:{palette:'unverified-style'}}};
const room={contraptions:{version:1,scene:'desert'}};
const freeze=q=>{if(q&&typeof q==='object'){for(const v of Object.values(q))freeze(v);Object.freeze(q);}return q;};
const original=name=>loadImage(fs.readFileSync(new URL('../atlas/assets/smm1-key-door-private/'+(name==='smb1Key'?'SMM-SMB-Key':'SMM-SMB-Unlocked-Door')+'.original.png',import.meta.url)));

test('both preserved SMM1 PNGs, native RGBA, hashes and shared registry have exact static source pixels',async()=>{
 const base=new URL('../atlas/assets/smm1-key-door-private/',import.meta.url),ledger=JSON.parse(fs.readFileSync(new URL('SOURCE_ASSETS.json',base))),common=JSON.parse(fs.readFileSync(new URL('../atlas/assets/smm2-private/SOURCE_ASSETS.json',import.meta.url)));
 assert.equal(ledger.game,'Super Mario Maker (2015)');assert.equal(ledger.originalAnimationCalibrated,false);assert.equal(Object.keys(ledger.assets).length,2);
 for(const [name,entry]of Object.entries(ledger.assets)){
  const src=sources[name],raw=fs.readFileSync(new URL(entry.file,base)),image=await loadImage(raw),expected=createCanvas(image.width,image.height),actual=createCanvas(image.width,image.height);expected.getContext('2d').drawImage(image,0,0);
  assert.equal(raw.length,entry.bytes);assert.equal(sha(raw),entry.sha256);assert.equal(sha(bytes(expected)),entry.rgbaSha256);assert.deepEqual([src.w,src.h],[entry.width,entry.height]);assert.equal(src.sourceSha256,entry.sha256);assert.equal(src.rgbaSha256,entry.rgbaSha256);assert.match(entry.sourceVersion,/SMM1/);assert.match(entry.copyright,/Nintendo/);assert.equal(common.assets[name].sha256,entry.sha256);
  assert.equal(SMM2_SOURCE_PIXELS[name],src);assert(drawSmm2SourcePixels(actual.getContext('2d'),name,{x:0,y:0}));assert.deepEqual(bytes(actual),bytes(expected));assert(Object.isFrozen(src)&&Object.isFrozen(src.rows)&&Object.isFrozen(src.palette)&&Object.isFrozen(src.cellOffset));
 }
});

test('native key keeps 14×16 right-tooth pixels and its bottom/centre anchor independently of the actor collider',async()=>{
 const image=await original('smb1Key');
 for(const shape of [{w:16,h:16},{w:14,h:14},{w:12,h:12}])for(const xy of [{x:16,y:20},{x:16.2,y:20.4}]){
  const actor=freeze({kind:'key',...shape,...xy}),before=JSON.stringify(actor),actual=createCanvas(64,64),expected=createCanvas(64,64),x=Math.round(actor.x+(actor.w-14)/2),y=Math.round(actor.y+actor.h-16);expected.getContext('2d').drawImage(image,x,y);drawKey(actual.getContext('2d'),actor);assert.deepEqual(bytes(actual),bytes(expected));assert.equal(JSON.stringify(actor),before);
  let count=0;const d=bytes(actual);for(let n=3;n<d.length;n+=4)if(d[n])count++;assert.equal(count,150);
  assert.equal(actual.getContext('2d').getImageData(x+11,y+12,1,1).data[3],255,'right-side tooth is present');
  assert.equal(actual.getContext('2d').getImageData(x+2,y+12,1,1).data[3],0,'legacy left-side tooth is absent');
 }
 for(const tick of [0,1,12,99,1000]){const c=createCanvas(48,48),expected=createCanvas(48,48);drawObject(c.getContext('2d'),{kind:'key',x:16,y:16,w:14,h:14},tick,room);expected.getContext('2d').drawImage(image,16,14);assert.deepEqual(bytes(c),bytes(expected));}
 const ctx=createCanvas(48,48).getContext('2d');ctx.translate(3,4);ctx.fillStyle='#123456';ctx.imageSmoothingEnabled=true;const transform=ctx.getTransform();drawKey(ctx,{x:16,y:16,w:14,h:14});assert.deepEqual(ctx.getTransform(),transform);assert.equal(ctx.imageSmoothingEnabled,true);ctx.fillRect(0,0,1,1);assert.deepEqual([...ctx.getImageData(3,4,1,1).data],[18,52,86,255]);
});

test('only explicit native SMB1 unlocked true uses the green source door, including every existing plain/key flag combination',async()=>{
 const image=await original('smb1UnlockedDoor');
 for(const flags of [{},{style:'key'},{style:'plain'},{locked:true},{locked:false},{color:'green'},{style:'plain',locked:true},{style:'key',locked:false,color:'green'}]){
  const actor=freeze({x:16,y:16,w:16,h:32,...flags,unlocked:true}),actual=createCanvas(48,64),expected=createCanvas(48,64),before=JSON.stringify(actor);drawDoor(actual.getContext('2d'),actor);expected.getContext('2d').drawImage(image,16,16);assert.deepEqual(bytes(actual),bytes(expected));assert.equal(JSON.stringify(actor),before);
  for(const value of [undefined,false,1,'true']){const a=createCanvas(48,64),b=createCanvas(48,64),q={...actor,unlocked:value};drawDoor(a.getContext('2d'),q);drawDoor(b.getContext('2d'),q,fallback);assert.deepEqual(bytes(a),bytes(b),'authored plain/locked keeps legacy unless explicit true');}
 }
 const portal={kind:'portal',id:'door',x:16,y:16,w:16,h:32},live={...room,contraptionsView:{doors:[{...portal,style:'plain',unlocked:true}]}},a=createCanvas(48,64),b=createCanvas(48,64);assert(drawContraptionsActor(a.getContext('2d'),portal,0,live));b.getContext('2d').drawImage(image,16,16);assert.deepEqual(bytes(a),bytes(b));
});

test('HUD uses a distinct uniform nearest-neighbour thumbnail and its explicit room keeps unsupported style fallback',async()=>{
 const image=await original('smb1Key'),actual=createCanvas(40,48),expected=createCanvas(40,48);drawKeyHud(actual.getContext('2d'),{x:8,y:32,w:12,h:12});expected.getContext('2d').imageSmoothingEnabled=false;const source=createCanvas(14,16);source.getContext('2d').drawImage(image,0,0);expected.getContext('2d').drawImage(source,8.75,32,10.5,12);assert.deepEqual(bytes(actual),bytes(expected));for(let i=3,d=bytes(actual);i<d.length;i+=4)assert([0,255].includes(d[i]));
 const view={contraptions:{keys:1},coins:0,score:0,timeLeft:400},a=createCanvas(384,48),b=createCanvas(384,48);drawHud(a.getContext('2d'),view,'--',fallback);drawKey(b.getContext('2d'),{x:8,y:32,w:12,h:12},fallback);assert.deepEqual(a.getContext('2d').getImageData(8,32,12,12).data,b.getContext('2d').getImageData(8,32,12,12).data,'explicit room fallback also works when the view omits art');
});

test('explicit author rectangle sizes preserve uniform nearest-neighbour source adaptation and centre/bottom anchoring',async()=>{
 const image=await original('smb1Key');for(const [w,h]of [[32,32],[48,48],[48,24],[20,32],[8,8]]){const o=freeze({x:16,y:20,w,h}),actual=createCanvas(96,96),expected=createCanvas(96,96),scale=Math.min(w/16,h/16),ctx=expected.getContext('2d');ctx.imageSmoothingEnabled=false;ctx.drawImage(image,Math.round(o.x+(w-14*scale)/2),Math.round(o.y+h-16*scale),14*scale,16*scale);drawKey(actual.getContext('2d'),o);assert.deepEqual(bytes(actual),bytes(expected));assert.deepEqual([o.w,o.h],[w,h]);}
});

test('nondesert existing native released key uses exact source pixels through shared actor and video entry points',async()=>{
 const doc=smb1KeyDoorArtProject();for(const r of doc.rooms)delete r.contraptions.scene;const image=await original('smb1Key'),s=nativeSession(doc);let contacts=0;
 runKeyDoorArtFixture({session:s,onFrame(view){for(const key of view.items.filter(q=>q.kind==='key')){
  const room={...doc.rooms.find(r=>r.roomId===view.roomId),contraptionsView:view.contraptions},actual=createCanvas(384,240),expected=createCanvas(384,240),x=Math.round(key.x+(key.w-14)/2),y=Math.round(key.y+key.h-16);drawObject(actual.getContext('2d'),key,view.tick,room);expected.getContext('2d').drawImage(image,x,y);assert.deepEqual(bytes(actual),bytes(expected));
  const camera={x:0,y:0,w:384,h:240},world=nativeWorld(view,doc,{camera,showPlayer:false,scale:1}).canvas,without=nativeWorld({...view,items:view.items.filter(q=>q!==key)},doc,{camera,showPlayer:false,scale:1}).canvas;without.getContext('2d').drawImage(image,x,y);assert.deepEqual(bytes(world),bytes(without));assert.deepEqual([key.w,key.h],[14,14]);contacts++;
 }}});assert.equal(contacts,13);assert.equal(s.view().contraptions.keys,0);
});

test('SMB3/other style fallbacks, locked and authored plain door pixels retain their exact prior artwork and unsupported actor dispatch',()=>{
 const expected={key:'0a26ceefde391376cb37a2b3d6f8e310e558aba64d0fac838123a78131e37e75',locked:'5129afe0f301c67e11fe25e7a531027b5241c40e11eee4d97f17f9f6d5d59a5d',plain:'91444d28631be5eb074e4fa269b709d7b2bbea89de75cfae5b3936f1436f8180',unlocked:'c1cd05f7121246d2e5724a5c286308f6bc82f8ab8ff1078ef0aabb8b1923923a'};
 for(const palette of ['smb3-underground','smw-overworld','nsmbu-overworld','unverified-style'])for(const [name,draw,flags]of [['key',drawKey,{}],['locked',drawDoor,{locked:true}],['plain',drawDoor,{style:'plain'}],['unlocked',drawDoor,{locked:true,unlocked:true}]]){const c=createCanvas(16,32);draw(c.getContext('2d'),{x:0,y:0,w:16,h:name==='key'?16:32,...flags},{smm2Mechanics:{version:1,art:{palette}}});assert.equal(sha(bytes(c)),expected[name]);}
 for(const [name,flags]of [['locked',{locked:true}],['plain',{style:'plain'}]]){const c=createCanvas(16,32);drawDoor(c.getContext('2d'),{x:0,y:0,w:16,h:32,...flags});assert.equal(sha(bytes(c)),expected[name]);}
 for(const r of [{smm2Mechanics:{version:1,art:{palette:'smw-overworld'}}}, {contraptions:{version:1},smm2Mechanics:{version:1,art:{palette:'nsmbu-overworld'}}}, {...room,smm2Mechanics:{version:1,art:{palette:'smb3-underground'}}}]){const c=createCanvas(48,48);assert.equal(drawContraptionsActor(c.getContext('2d'),{kind:'key',x:16,y:16,w:16,h:16},0,r),false);assert(bytes(c).every(n=>n===0),'unsupported style actor dispatch stays unchanged');}
});

test('ordinary native key acquisition, pair unlock, events, score/audio and project/runtime format remain unchanged by drawing',()=>{
 const doc=smb1KeyDoorArtProject();assert.deepEqual(parseProject(JSON.stringify(doc)),doc);for(const r of doc.rooms)assert.deepEqual(runtimeMap(parseProject(JSON.stringify(doc)).rooms.find(q=>q.roomId===r.roomId)),runtimeMap(r));
 const drawn=nativeSession(doc),control=nativeSession(doc);let seenLoose=false,seenUnlocked=false;
 runKeyDoorArtFixture({session:drawn,onFrame(view){const other=control.step(drawn.inputs.at(-1));const before=JSON.stringify(view),c=createCanvas(384,240),r={...drawn.doc.rooms.find(q=>q.roomId===view.roomId),contraptionsView:view.contraptions};for(const actor of view.items){drawObject(c.getContext('2d'),freeze(actor),view.tick,r);if(actor.kind==='key'){seenLoose=true;assert.deepEqual([actor.w,actor.h],[14,14]);}}for(const door of view.contraptions.doors){drawDoor(c.getContext('2d'),freeze(door),r);seenUnlocked||=door.unlocked===true;}drawHud(c.getContext('2d'),view,'--',r);assert.equal(JSON.stringify(view),before);assert.deepEqual(view,other);assert.deepEqual(drawn.events,control.events);}});
 assert(seenLoose&&seenUnlocked);assert.equal(drawn.view().score,control.view().score);assert.deepEqual(drawn.doc,doc);
});

test('actual editor, standalone embedded native runtime/play and video raster execute the same source art with a closed offline graph',()=>{
 const result=spawnSync(process.execPath,['--experimental-vm-modules',fileURLToPath(new URL('../scripts/check-key-door-source-art-offline.mjs',import.meta.url))],{encoding:'utf8',timeout:45000,maxBuffer:1024*1024});assert.equal(result.status,0,result.stderr||result.stdout||String(result.error));const report=JSON.parse(result.stdout);for(const key of ['actualEditorPreviewExecuted','embeddedArtExecuted','actualEmbeddedStageExecuted','actualEmbeddedMotorExecuted','actualEmbeddedPlayExecuted','actualEmbeddedBootstrapExecuted','nativeVideoRendererExecuted','stateUnchanged'])assert.equal(report[key],true,key);assert(report.moduleCount>=60);assert.equal(report.moduleCount,report.reachableModuleCount);assert.equal(report.networkRequests,0);assert.equal(report.originalAnimationCalibrated,false);assert.equal(report.nativeKeyCollections,1);assert.equal(report.nativeDoorUnlocks,1);assert(report.rasterScenes>=20);
});
