import {test} from 'node:test';
import assert from 'node:assert/strict';
import {blank,validate,parseProject,History} from '../atlas/editor-model.mjs';
import {validateSmm2CourseComponents,horizontalCameraBarrierRight} from '../atlas/editor-smm2-course-components.mjs';
import {NATIVE_PLAY_RULES} from '../atlas/editor-play-rules.mjs';

// The four measured R5 hard blocks occupy columns22–23, rows9–10. The
// unscrolled view spans0..384px; the final observed view spans400..784px.
// The camera policy is an authored fit, not an inferred original algorithm.
const hardIds=['hard-left-top','hard-left-bottom','hard-right-top','hard-right-bottom'];
function project(){
 const d=blank('Horizontal camera barrier contract',784,224),r=d.rooms[0];
 r.playRules={...NATIVE_PLAY_RULES,viewportWidth:384,viewportHeight:216,cameraAnchor:160};
 r.map.geometry=[
  {id:'floor',x:0,y:176,w:512,h:32,material:'ground',collision:'solid'},
  {id:'goal-floor',x:576,y:176,w:208,h:32,material:'ground',collision:'solid'},
  {id:'overhead-wall',x:352,y:0,w:32,h:144,material:'ground',collision:'solid'},
  ...hardIds.map((id,n)=>({id,x:352+Math.floor(n/2)*16,y:144+(n%2)*16,w:16,h:16,material:'stone',collision:'solid',smm2BlockKind:'hard-block'}))
 ];
 r.map.objects=[{id:'start',kind:'spawn',x:32,y:162,w:10,h:14},{id:'goal',kind:'exit',x:624,y:160,w:16,h:16}];
 r.smm2Mechanics={version:1,camera:{baseY:0,minY:0,riseTop:0,horizontalBarrier:{right:384,releaseWhenRemovedGeometryIds:[...hardIds]}}};
 return d;
}
const camera=d=>d.rooms[0].smm2Mechanics.camera;

test('strict horizontal barrier roundtrips through the real project reader and History',()=>{
 const d=project();assert.doesNotThrow(()=>validate(d));assert.deepEqual(parseProject(JSON.stringify(d)),d);
 const history=new History(d);history.change(()=>{camera(history.doc).horizontalBarrier.right=400;});assert.equal(camera(history.doc).horizontalBarrier.right,400);
 const saved=JSON.stringify(history.doc),undos=history.undoStack.length;assert.throws(()=>history.change(()=>{camera(history.doc).horizontalBarrier.releaseWhenRemovedGeometryIds.push('start');}),/native solid/);assert.equal(JSON.stringify(history.doc),saved);assert.equal(history.undoStack.length,undos);
 history.undo();assert.deepEqual(history.doc,d);history.redo();assert.deepEqual(parseProject(JSON.stringify(history.doc)),history.doc);
 const old=project();delete camera(old).horizontalBarrier;assert.doesNotThrow(()=>validate(old));assert.deepEqual(parseProject(JSON.stringify(old)),old);assert.equal(horizontalCameraBarrierRight(old.rooms[0]),null);
});

test('barrier requires finite right within the actual room viewport/world interval',()=>{
 for(const right of [383,785,Infinity,NaN,'384',null,-1]){const d=project();camera(d).horizontalBarrier.right=right;assert.throws(()=>validateSmm2CourseComponents(d.rooms[0]),/bounds/);}
 for(const right of [384,400.5,784]){const d=project();camera(d).horizontalBarrier.right=right;assert.doesNotThrow(()=>validate(d));}
 const native=project();delete native.rooms[0].playRules;camera(native).horizontalBarrier.right=256;assert.doesNotThrow(()=>validate(native));camera(native).horizontalBarrier.right=255;assert.throws(()=>validate(native),/bounds/);
 const wider=project();wider.rooms[0].playRules={...NATIVE_PLAY_RULES,viewportWidth:512,cameraAnchor:160};assert.throws(()=>validate(wider),/bounds/);camera(wider).horizontalBarrier.right=512;assert.doesNotThrow(()=>validate(wider));
});

test('barrier rejects unknown fields, empty/duplicate/unsafe IDs and non-native/non-solid/object references',()=>{
 for(const ids of [[],null,'hard-left-top',[hardIds[0],hardIds[0]],['missing'],['start'],['goal'],['__proto__'],['constructor'],['bad id'],Array(257).fill(hardIds[0])]){const d=project();camera(d).horizontalBarrier.releaseWhenRemovedGeometryIds=ids;assert.throws(()=>validateSmm2CourseComponents(d.rooms[0]));}
 for(const barrier of [null,[],false,{right:384},{releaseWhenRemovedGeometryIds:hardIds},{right:384,releaseWhenRemovedGeometryIds:hardIds,onTimer:10},{right:384,releaseWhenRemovedGeometryIds:hardIds,worldRight:384}]){const d=project();camera(d).horizontalBarrier=barrier;assert.throws(()=>validateSmm2CourseComponents(d.rooms[0]));}
 for(const collision of ['oneway','none']){const d=project();d.rooms[0].map.geometry.find(g=>g.id===hardIds[0]).collision=collision;assert.throws(()=>validateSmm2CourseComponents(d.rooms[0]),/native solid/);}
 const synthetic=project();synthetic.rooms[0].smm2Mechanics.donuts=[{id:'synthetic-terrain'}];camera(synthetic).horizontalBarrier.releaseWhenRemovedGeometryIds=['synthetic-terrain'];assert.throws(()=>validateSmm2CourseComponents(synthetic.rooms[0]),/native solid/);
 const duplicate=project();duplicate.rooms[0].map.geometry.push({...duplicate.rooms[0].map.geometry.find(g=>g.id===hardIds[0])});assert.throws(()=>validateSmm2CourseComponents(duplicate.rooms[0]),/unique existing/);
 const objectCollision=project();objectCollision.rooms[0].map.objects.push({id:hardIds[0],kind:'coin',x:64,y:150,w:8,h:8});assert.throws(()=>validateSmm2CourseComponents(objectCollision.rooms[0]),/native solid/);
 for(const id of ['constructor','prototype']){const unsafe=project();unsafe.rooms[0].map.geometry.find(g=>g.id===hardIds[0]).id=id;camera(unsafe).horizontalBarrier.releaseWhenRemovedGeometryIds=[id];assert.throws(()=>validateSmm2CourseComponents(unsafe.rooms[0]),/native solid/);}
 const inherited=project();camera(inherited).horizontalBarrier=Object.assign(Object.create({hiddenPolicy:true}),{right:384,releaseWhenRemovedGeometryIds:hardIds});assert.throws(()=>validateSmm2CourseComponents(inherited.rooms[0]),/fields/);
});

test('pure release policy stays capped through partial removal and releases only after every real hard body disappears',()=>{
 const r=project().rooms[0],original=JSON.stringify(r),g=r.map.geometry.map(q=>Object.freeze({...q}));Object.freeze(g);
 assert.equal(horizontalCameraBarrierRight(r,g),384);assert.equal(horizontalCameraBarrierRight(r,g.filter(q=>q.id!=='overhead-wall')),384);
 for(let count=1;count<hardIds.length;count++){const removed=new Set(hardIds.slice(0,count));assert.equal(horizontalCameraBarrierRight(r,g.filter(q=>!removed.has(q.id))),384);}
 assert.equal(horizontalCameraBarrierRight(r,g.filter(q=>!hardIds.includes(q.id))),null);assert.equal(horizontalCameraBarrierRight(r,[]),null);assert.equal(JSON.stringify(r),original);
 // This policy returns framing limits only; no player coordinate, geometry
 // coordinate or room dimension is modified by evaluating it.
 assert.equal(r.map.width,784);assert.equal(r.map.objects[0].x,32);
});

test('native solid subdivision retains the barrier until its last sourceId piece is actually removed',()=>{
 const r=project().rooms[0],unrelated=r.map.geometry.filter(q=>!hardIds.includes(q.id)),piece={id:'hard-left-top@352,144',sourceId:hardIds[0],x:352,y:144,w:8,h:16,material:'stone',collision:'solid'};
 assert.equal(horizontalCameraBarrierRight(r,[...unrelated,piece]),384);assert.equal(horizontalCameraBarrierRight(r,unrelated),null);
});
