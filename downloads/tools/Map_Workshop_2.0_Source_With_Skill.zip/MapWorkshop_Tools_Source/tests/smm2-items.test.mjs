import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createSmm2Items,validateSmm2ItemsRoom,smm2PowTargets} from '../atlas/editor-smm2-items.mjs';
import {createPlatformMotor} from '../atlas/editor-mario-motor.mjs';
import {createSMM2Terrain,withSMM2TerrainContact,sampleSMM2Surface} from '../atlas/editor-smm2-terrain.mjs';
import {createSmm2Thwomps} from '../atlas/editor-smm2-thwomps.mjs';
import {createRailClaws} from '../atlas/editor-rail-claws.mjs';

const character={capabilities:['jump'],motion:{width:10,height:14,maxHealth:1}};
const native=({id='pow',kind='walker',x=120,y=100,w=16,h=16,...extra}={})=>({id,kind,x,y,w,h,...extra});
const pow=extra=>({id:'pow',gravity:.4375,maxFallSpeed:4.25,blastRadius:64,supportedScreenEffect:false,...extra});
const helmet=extra=>({id:'helmet',gravity:.4375,maxFallSpeed:4.25,...extra});
const placed=extra=>({id:'placed-life',kind:'life',gravity:.4375,maxFallSpeed:4.25,...extra});
const skewer=extra=>({id:'skewer',direction:'right',travel:96,extendSpeed:16,retractSpeed:8,waitFrames:3,holdFrames:2,loadDistance:80,phaseOffsetFrames:0,...extra});
const room=(mechanics={},objects=[native()])=>({roomId:'live-items-fixture',map:{width:512,height:384,geometry:[],objects},smm2Mechanics:{version:1,...mechanics}});
const player=(x=124,y=116,extra={})=>({...createPlatformMotor().create(character,{x,y}),id:'player',kind:'player',...extra});
const live=q=>({...q,vx:0,vy:0,grounded:false,support:null});
const floor={id:'floor',x:0,y:184,w:512,h:16,collision:'solid'};
function harness(r,{solids=[],p=player(),terrain=null}={}){
 const actors=r.map.objects.map(live),events=[],items=createSmm2Items(r,{terrain,emit:(kind,data)=>events.push({kind,...data})}),motor=withSMM2TerrainContact(createPlatformMotor(),terrain);let tick=0;
 actors.forEach(items.decorateActor);
 return {actors,items,motor,p,events,step(input={},targets=[],screen){const now=++tick;terrain?.beginFrame({tick:now,actors:[p,...actors]});items.beginFrame({tick:now,actors,player:p});let geometry=terrain?.geometry(solids)||solids;for(const a of actors)items.stepItem(a,{tick:now,geometry:items.geometry(geometry,actors,{exclude:a})});geometry=items.geometry(geometry,actors);const before={...p};motor.step(p,input,character,{width:r.map.width,solids:geometry});const contact=items.afterPlayer(p,before,{tick:now,input,actors,targets,screen,geometry});terrain?.finishFrame({tick:now,actors:[p,...actors]});return {before,contact,geometry,tick:now};}};
}

test('optional leaves are inert and source validation preserves closed native ABI',()=>{
 assert.equal(createSmm2Items({map:{width:512,height:384,objects:[]}}),null);
 assert.equal(createSmm2Items(room({powBlocks:[],helmets:[],skewers:[]},[])),null);
 const r=room({powBlocks:[pow()],helmets:[helmet()],skewers:[skewer()]},[native(),native({id:'helmet'}),native({id:'skewer',kind:'hazard'})]);
 const original=JSON.stringify(r);validateSmm2ItemsRoom(r);createSmm2Items(r);assert.equal(JSON.stringify(r),original);
 assert.throws(()=>validateSmm2ItemsRoom(room({powBlocks:[pow()]},[native({kind:'pow'})])),/native walker/);
 validateSmm2ItemsRoom(room({powBlocks:[pow()],thwomps:[{unknownSiblingField:true}]}));
});

test('leaf schema rejects unknown keys, scripts, duplicates, hostile IDs, nonfinite and unbounded values',()=>{
 const examples=[{powBlocks:[pow({activateOn:'timer'})]},{powBlocks:[pow({gravity:NaN})]},{powBlocks:[pow({maxFallSpeed:257})]},{powBlocks:[pow({blastRadius:-1})]},{powBlocks:[pow({supportedScreenEffect:'yes'})]},{powBlocks:[pow(),pow()]},{powBlocks:[pow({id:'constructor'})]},{helmets:[helmet({kind:'spiny'})]},{helmets:[helmet({gravity:-1})]},{skewers:[skewer({direction:'target-player'})]},{skewers:[skewer({extendSpeed:0})]},{skewers:[skewer({loadDistance:Infinity})]},{skewers:[skewer({waitFrames:1.5})]},{skewers:[skewer({travel:500})]},{skewers:[skewer({phaseOffsetFrames:23})]},{powBlocks:Array.from({length:257},(_,i)=>pow({id:'pow-'+i}))}];
 for(const m of examples)assert.throws(()=>validateSmm2ItemsRoom(room(m,[native(),native({id:'helmet'}),native({id:'skewer',kind:'hazard'})])));
 assert.throws(()=>validateSmm2ItemsRoom(room({powBlocks:[pow()]},[native(),native()])),/native walker/);
 assert.throws(()=>validateSmm2ItemsRoom(room({powBlocks:[pow()]},[native({x:500})])),/inside/);
 assert.throws(()=>validateSmm2ItemsRoom({...room(),smm2Mechanics:JSON.parse('{"version":1,"__proto__":{}}')}),/unsafe/);
 assert.throws(()=>validateSmm2ItemsRoom({...room(),smm2Mechanics:{version:2}}),/version/);
});

test('a live POW falls, lands and stands inert under genuine native Mario support',()=>{
 const h=harness(room({powBlocks:[pow()]},[native({x:120,y:144})]),{solids:[floor],p:player(123,110)}),a=h.actors[0];
 for(let i=0;i<60;i++)h.step();
 assert.equal(a.y+a.h,floor.y);assert.equal(a.grounded,true);assert.equal(a.support,floor.id);assert.equal(a.standable,true);assert.equal(a.kind,'pow');
 assert.equal(h.p.support,a.id);assert.equal(h.p.y+h.p.h,a.y);assert.equal(a.smm2Pow.phase,'live');assert.equal(a.dead,undefined);assert.equal(h.events.filter(e=>e.event==='pow-activate').length,0);
 const x=a.x,y=a.y;h.step({jump:true,jumpPressed:true});assert.equal(a.x,x);assert.equal(a.y,y);assert.equal(a.smm2Pow.phase,'live');assert.equal(h.p.grounded,false);
});

test('real native underside head-hit activates POW once, removes collider and emits actual world contact',()=>{
 const r=room({powBlocks:[pow({gravity:0})]}),h=harness(r,{p:player(124,118,{vy:-4})});
 const q=h.step({jump:true});assert.deepEqual(q.contact.activated,['pow']);assert.equal(q.contact.effects[0].position.x,128);assert.equal(q.contact.effects[0].position.y,108);assert.equal(q.contact.effects[0].contact.nativeHeadHit,true);
 assert.equal(h.actors[0].dead,true);assert.equal(h.actors[0].standable,false);assert.equal(h.items.geometry([],h.actors).length,0);assert.equal(h.p.headHit,null);
 h.items.afterPlayer(h.p,q.before,{tick:q.tick,actors:h.actors});h.step();assert.equal(h.events.filter(e=>e.event==='pow-activate').length,1);
});

test('remote headHit labels, body/side overlaps and standing never synthesize a POW head strike',()=>{
 const a=live(native()),items=createSmm2Items(room({powBlocks:[pow({gravity:0})]}));items.decorateActor(a);items.beginFrame({tick:1,actors:[a],player:player()});
 const cases=[[player(300,116,{headHit:'pow'}),player(300,120,{vy:-4})],[player(114,101),player(108,101,{vx:6})],[player(124,86,{grounded:true,support:'pow'}),player(124,86,{grounded:true,support:'pow'})]];
 for(const [p,b]of cases)assert.deepEqual(items.afterPlayer(p,b,{tick:1,actors:[a]}).activated,[]);
 assert.equal(a.smm2Pow.phase,'live');
});

test('POW effect eligibility uses real radius or explicit grounded supported-screen policy',()=>{
 const effect={position:{x:100,y:100},blastRadius:20,supportedScreenEffect:false,touchingSolid:false,screen:{x:0,y:0,w:256,h:224}},target=(id,x,y,extra={})=>({id,x,y,w:10,h:10,type:'smm2-thwomp',...extra});
 const targets=[target('local',120,96),target('outside',120.001,96),target('screen-ground',200,100,{grounded:true}),target('screen-air',200,100,{grounded:false}),target('offscreen',400,100,{grounded:true}),target('ineligible',100,100,{type:'unverified-boss'}),target('dead',100,100,{dead:true})];
 assert.deepEqual(smm2PowTargets(effect,targets).map(q=>[q.id,q.reason]),[['local','local']]);
 assert.deepEqual(smm2PowTargets({...effect,supportedScreenEffect:true},targets).map(q=>q.id),['screen-ground']);
 assert.deepEqual(smm2PowTargets({...effect,supportedScreenEffect:true,touchingSolid:true},targets).map(q=>[q.id,q.reason]),[['screen-ground','supported-screen']]);
 assert.equal(targets[0].dead,undefined);assert.equal(targets[2].dead,undefined);
 assert.deepEqual(smm2PowTargets(effect,[target('custom',100,100,{type:'other'})],{isEligible:()=>true}).map(q=>q.id),['custom']);
});

test('blue POW screen effect requires grounded targets, independent of POW solid touch',()=>{
 const p=player(124,118,{vy:-4}),support={id:'touching-wall',x:136,y:100,w:16,h:16,collision:'solid'},target={id:'far-screen',x:300,y:100,w:16,h:24,type:'smm2-thwomp',grounded:true};
 const h=harness(room({powBlocks:[pow({gravity:0,blastRadius:0,supportedScreenEffect:true})]}),{p,solids:[support]});
 const q=h.step({jump:true},[target],{x:0,y:0,w:384,h:224});assert.equal(q.contact.effects[0].touchingSolid,true);assert.equal(q.contact.effects[0].targets[0].id,target.id);assert.equal(target.dead,undefined);
});

test('blue POW keeps solid-touch diagnostics while detached and seesaw support do not restrict grounded screen targets',()=>{
 const slope={id:'solid-ceiling-side',x:136,y:100,w:64,h:32,orientation:'ceiling-rise-left',collision:'solid'},r=room({powBlocks:[pow({gravity:0,blastRadius:0,supportedScreenEffect:true})],slopes:[slope]}),terrain=createSMM2Terrain(r),p=player(124,118,{vy:-4});
 const h=harness(r,{p,terrain}),target={id:'far-screen',x:300,y:100,w:16,h:24,type:'smm2-thwomp',grounded:true};const q=h.step({jump:true},[target],{x:0,y:0,w:384,h:224});assert.equal(q.contact.effects[0].touchingSolid,true);assert.equal(q.contact.effects[0].targets[0].id,target.id);
 const saw={id:'one-way-seesaw',pivotX:128,pivotY:120,length:64,thickness:8,initialAngleDegrees:0,maxAngleDegrees:30,weightAcceleration:0,maxAngularSpeedDegrees:2,damping:.9,impactSpeedThreshold:2,impactGain:.7,maxLaunchSpeed:20,impactMinLeverFraction:.1,impactPolicy:'thwomp'},sawRoom=room({powBlocks:[pow({gravity:0,blastRadius:0,supportedScreenEffect:true})],seesaws:[saw]}),sawTerrain=createSMM2Terrain(sawRoom),sawHarness=harness(sawRoom,{p:player(124,118,{vy:-4}),terrain:sawTerrain});const actual=sawHarness.step({jump:true},[target],{x:0,y:0,w:384,h:224});assert.equal(actual.contact.effects[0].touchingSolid,false);assert.deepEqual(actual.contact.effects[0].targets.map(q=>q.id),[target.id]);
});

test('declared rail POW follows real track samples, bounded displacement and carries a native rider',()=>{
 const r=room({powBlocks:[pow({gravity:0,rail:{trackId:'pow-track',speed:2,position:0,direction:1}})]});
 r.contraptions={version:1,tracks:[{id:'pow-track',start:[128,108],segments:[{kind:'line',to:[192,108]}],mode:'bounce'}]};
 const h=harness(r,{p:player(123,86,{grounded:true,support:'pow'})}),a=h.actors[0];
 for(let i=0;i<40;i++){const x=a.x,px=h.p.x;h.step();assert.ok(Math.abs(a.x-x)<=2+1e-7);assert.equal(h.p.x-px,a.smm2Pow.dx);assert.equal(h.p.y+h.p.h,a.y);assert.equal(a.smm2Pow.phase,'live');}
 assert.equal(a.x,168);assert.equal(a.smm2Pow.rail.direction,-1);assert.equal(a.dead,undefined);
 const shifted=structuredClone(r);shifted.map.objects[0].x++;assert.throws(()=>validateSmm2ItemsRoom(shifted),/source centre/);
 const absent=structuredClone(r);absent.smm2Mechanics.powBlocks[0].rail.trackId='absent';assert.throws(()=>validateSmm2ItemsRoom(absent),/attachment/);
});

test('quadratic attached rail motion follows the curve, remains live, and does not teleport through a real wall',()=>{
 const r=room({powBlocks:[pow({gravity:0,rail:{trackId:'pow-track',speed:2,position:0,direction:1}})]});r.contraptions={version:1,tracks:[{id:'pow-track',start:[128,108],segments:[{kind:'quadratic',control:[160,68],to:[192,108]}],mode:'bounce'}]};
 const h=harness(r,{p:player(400,200)}),a=h.actors[0];for(let i=0;i<15;i++){const b={...a};h.step();assert.ok(Math.hypot(a.x-b.x,a.y-b.y)<=2.01);}assert.ok(a.y<90);assert.ok(a.x>140);assert.equal(a.smm2Pow.phase,'live');
 const wall={id:'rail-wall',x:140,y:0,w:2,h:384,collision:'solid'},blocked=harness(r,{solids:[wall],p:player(400,200)});for(let i=0;i<20;i++)blocked.step();assert.ok(blocked.actors[0].x+16<=140+1e-6);assert.ok(blocked.actors[0].x<140);assert.equal(blocked.actors[0].smm2Pow.phase,'live');
});

test('an actual seesaw landing launches the live POW/rider and item gravity continues without activation',()=>{
 const saw={id:'seesaw',pivotX:240,pivotY:160,length:128,thickness:8,initialAngleDegrees:0,maxAngleDegrees:30,weightAcceleration:0,maxAngularSpeedDegrees:2,damping:.9,impactSpeedThreshold:2,impactGain:.7,maxLaunchSpeed:20,impactMinLeverFraction:.1,impactPolicy:'thwomp'};
 const r=room({powBlocks:[pow()],seesaws:[saw]},[native({x:281,y:140})]),terrain=createSMM2Terrain(r),items=createSmm2Items(r,{terrain}),a=live(r.map.objects[0]);items.decorateActor(a);Object.assign(a,{grounded:true,support:'seesaw'});
 const p=player(284,126,{grounded:true,support:'pow'}),thwomp=player(181,126,{id:'thwomp',type:'smm2-thwomp',w:24,h:24,smm2Mass:3,vy:4}),actors=[a,p,thwomp],motor=withSMM2TerrainContact(createPlatformMotor(),terrain);
 let launched=false;
 for(let tick=1;tick<=6&&!launched;tick++){terrain.beginFrame({tick,actors});items.beginFrame({tick,actors:[a],player:p});items.stepItem(a,{tick,geometry:terrain.geometry([])});for(const body of [p,thwomp])motor.step(body,{},character,{width:512,solids:items.geometry([],[a],{exclude:body})});terrain.finishFrame({tick,actors});launched=terrain.view().events.some(e=>e.event==='seesaw-impact-launch');}
 assert.equal(launched,true);assert.ok(a.vy<-3);assert.ok(p.vy<-3);assert.equal(a.smm2Pow.phase,'live');assert.equal(a.dead,undefined);assert.equal(a.standable,true);
 const vy=a.vy,y=a.y;terrain.beginFrame({tick:7,actors});items.beginFrame({tick:7,actors:[a],player:p});items.stepItem(a,{tick:7,geometry:[]});assert.ok(a.y<y);assert.ok(a.vy>vy);assert.equal(a.smm2Pow.phase,'live');
});

test('loose preplaced Buzzy shell has real gravity/support and wears on genuine underside approach preserving Fire/body',()=>{
 const platform={id:'pillar-top',x:96,y:120,w:96,h:8,collision:'oneway'},r=room({helmets:[helmet()]},[native({id:'helmet',y:104})]),p=player(124,126,{power:2,h:28,vy:-4});
 const h=harness(r,{p,solids:[platform]});let worn=false;for(let i=0;i<8&&!worn;i++)worn=h.step({jump:true}).contact.worn.length>0;
 assert.equal(worn,true);assert.equal(p.helmet,'buzzy');assert.equal(p.power,2);assert.equal(p.h,28);assert.equal(h.actors[0].dead,true);assert.equal(h.actors[0].smm2Helmet.phase,'worn');
 for(let i=0;i<4;i++)h.step();assert.equal(h.events.filter(e=>e.event==='helmet-worn').length,1);
});

test('Buzzy shell does not wear from side/body/remote contact or unsupported SMB1 duck gesture',()=>{
 const r=room({helmets:[helmet({gravity:0})]},[native({id:'helmet'})]),a=live(r.map.objects[0]),items=createSmm2Items(r);items.decorateActor(a);items.beginFrame({tick:1,actors:[a],player:player()});
 for(const [p,b,input]of [[player(114,102),player(108,102),{}],[player(124,86,{grounded:true}),player(124,86,{grounded:true}),{down:true}],[player(124,110),player(124,110),{down:true}],[player(300,116,{headHit:'helmet'}),player(300,124,{vy:-4}),{}]]){assert.deepEqual(items.afterPlayer(p,b,{tick:1,actors:[a],input}).worn,[]);assert.equal(p.helmet,undefined);}
 assert.equal(a.smm2Helmet.phase,'loose');
});

test('an already worn Buzzy helmet never consumes a second loose shell from repeated head contact',()=>{
 const r=room({helmets:[helmet({gravity:0})]},[native({id:'helmet'})]),a=live(r.map.objects[0]),items=createSmm2Items(r);items.decorateActor(a);items.beginFrame({tick:1,actors:[a],player:player()});
 const p=player(124,110,{helmet:'buzzy',power:2,h:28}),b=player(124,124,{vy:-4,power:2,h:28});assert.deepEqual(items.afterPlayer(p,b,{tick:1,actors:[a]}).worn,[]);assert.equal(a.dead,undefined);assert.equal(p.power,2);
});

test('Buzzy/Thwomp head-bonk decision requests real return; side/body and Skewer remain unprotected',()=>{
 const items=createSmm2Items(room({powBlocks:[pow()]}));items.beginFrame({tick:1,actors:[],player:player()});const t={id:'thwomp',type:'smm2-thwomp',x:120,y:100,w:24,h:24},p=player(124,118,{helmet:'buzzy'}),before=player(124,130,{vy:-4,helmet:'buzzy'});
 const response=items.helmetContact(p,before,t,{tick:1});assert.equal(response.protected,true);assert.equal(response.action,'request-return');assert.equal(response.approximation,true);assert.equal(t.dead,undefined);assert.equal(t.y,100);assert.equal(p.helmet,'buzzy');
 const side=items.helmetContact(player(114,104,{helmet:'buzzy',power:2,h:28}),player(108,104,{helmet:'buzzy',power:2,h:28}),t,{tick:1});assert.equal(side.protected,false);assert.equal(side.consumeHelmet,true);
 assert.equal(items.helmetContact(p,before,{...t,type:'smm2-skewer'},{tick:1}).protected,false);
 const falling={...t,y:120};assert.equal(items.helmetContact(player(124,144,{helmet:'buzzy'}),player(124,144,{helmet:'buzzy'}),falling,{tick:1,hazardBefore:t}).protected,true);
});

test('Skewer loads locally, keeps its own fixed cycle, exposes actual base/shaft/tip and never tracks Mario',()=>{
 const r=room({skewers:[skewer()]},[native({id:'skewer',kind:'hazard',x:40,y:80,w:32,h:24})]),a=live(r.map.objects[0]),items=createSmm2Items(r);items.decorateActor(a);
 for(let tick=1;tick<=5;tick++){items.beginFrame({tick,actors:[a],player:player(400,200)});assert.equal(a.smm2Skewer.phase,'unloaded');assert.equal(a.smm2Skewer.extension,0);}
 items.beginFrame({tick:6,actors:[a],player:player(90,80)});assert.equal(a.smm2Skewer.phase,'wait');
 for(let tick=7;tick<=9;tick++)items.beginFrame({tick,actors:[a],player:player(400,200)});
 assert.equal(a.smm2Skewer.phase,'extend');assert.equal(a.smm2Skewer.extension,16);assert.deepEqual(a.smm2Skewer.base,{x:40,y:80,w:32,h:24});assert.deepEqual(a.smm2Skewer.shaft,{x:72,y:80,w:16,h:24});assert.deepEqual(a.smm2Skewer.tip,{x:72,y:80,w:16,h:24});
 for(let tick=10;tick<=14;tick++)items.beginFrame({tick,actors:[a],player:player(400,200)});assert.equal(a.smm2Skewer.extension,96);assert.equal(a.smm2Skewer.shaft.x,72);
 items.beginFrame({tick:15,actors:[a],player:player(400,200)});assert.equal(a.smm2Skewer.phase,'hold');items.beginFrame({tick:16,actors:[a],player:player(400,200)});items.beginFrame({tick:17,actors:[a],player:player(400,200)});assert.equal(a.smm2Skewer.phase,'retract');assert.equal(a.smm2Skewer.extension,88);
 for(let tick=18;tick<=28;tick++)items.beginFrame({tick,actors:[a],player:player(400,200)});assert.equal(a.smm2Skewer.extension,0);items.beginFrame({tick:29,actors:[a],player:player(400,200)});assert.equal(a.smm2Skewer.phase,'wait');assert.equal(items.geometry([],[a]).length,0);
});

for(const direction of ['down','up','left','right'])test(`Skewer ${direction} footprint is its real extension with a correct leading tip`,()=>{
 const r=room({skewers:[skewer({direction,waitFrames:0,travel:64})]},[native({id:'skewer',kind:'hazard',x:160,y:160,w:32,h:24})]),a=live(r.map.objects[0]),items=createSmm2Items(r);items.beginFrame({tick:1,actors:[a],player:player(160,200)});
 const st=a.smm2Skewer;assert.equal(st.extension,16);assert.equal(st.shaft.w,direction==='down'||direction==='up'?32:16);assert.equal(st.shaft.h,direction==='down'||direction==='up'?16:24);
 assert.equal(st.shaft.x,direction==='left'?144:direction==='right'?192:160);assert.equal(st.shaft.y,direction==='up'?144:direction==='down'?184:160);assert.equal(st.tip.x,st.shaft.x);assert.equal(st.tip.y,st.shaft.y);
});

test('Skewer continuous player/extension sweeps detect genuine hits without solids, helmet immunity or automatic NPC kills',()=>{
 const r=room({skewers:[skewer({waitFrames:0,extendSpeed:32})]},[native({id:'skewer',kind:'hazard',x:40,y:80,w:32,h:24})]),a=live(r.map.objects[0]),items=createSmm2Items(r),p=player(90,82,{helmet:'buzzy'}),npc={id:'npc',type:'smm2-thwomp',x:80,y:80,w:24,h:24};
 items.beginFrame({tick:1,actors:[a,npc],player:p});const hits=items.playerHazardContact(p,{...p},{tick:1,actors:[a,npc]});assert.ok(hits.some(q=>q.part==='shaft'));assert.equal(hits[0].solid,false);assert.equal(hits[0].helmetProtected,false);assert.equal(npc.dead,undefined);assert.equal(p.x,90);
 const fast=player(80,82),start=player(130,82);assert.ok(items.playerHazardContact(fast,start,{tick:1}).some(q=>q.part==='shaft'));
 assert.deepEqual(items.playerHazardContact(player(90,60),player(90,60),{tick:1}),[]);
 // The original motor passes through because this hazard has no solid body;
 // host invulnerability can ignore repeated damage while Mario keeps moving.
 const motor=createPlatformMotor(),boosted=player(74,82,{vx:2.5,power:2,h:28});for(let tick=2;tick<30;tick++){items.beginFrame({tick,actors:[a],player:boosted});const before={...boosted};motor.step(boosted,{x:1,run:true},character,{width:512,solids:items.geometry([],[a])});items.playerHazardContact(boosted,before,{tick});}assert.ok(boosted.x>110);assert.equal(boosted.power,2);assert.equal(a.dead,undefined);assert.equal(npc.dead,undefined);
});

test('continuous changing-rectangle contact avoids a union-footprint false positive',()=>{
 const r=room({skewers:[skewer({waitFrames:0,extendSpeed:16})]},[native({id:'skewer',kind:'hazard',x:40,y:80,w:32,h:24})]),a=live(r.map.objects[0]),items=createSmm2Items(r);items.beginFrame({tick:1,actors:[a],player:player(120,80)});
 // Player leaves the vertical band before the tip reaches their x coordinate.
 const before=player(86,96),after=player(86,126);assert.deepEqual(items.playerHazardContact(after,before,{tick:1}).filter(q=>q.part==='shaft'),[]);
});

test('an explicit seeded Skewer phase retains finite motion on first loading',()=>{
 const q=skewer({phaseOffsetFrames:7}),r=room({skewers:[q]},[native({id:'skewer',kind:'hazard',x:40,y:80,w:32,h:24})]),a=live(r.map.objects[0]),items=createSmm2Items(r);items.decorateActor(a);assert.equal(a.smm2Skewer.extension,64);
 items.beginFrame({tick:1,actors:[a],player:player(90,80)});assert.equal(a.smm2Skewer.extension,80);assert.equal(a.smm2Skewer.previous.shaft.w,64);items.beginFrame({tick:2,actors:[a],player:player(400,200)});assert.equal(a.smm2Skewer.extension,96);
});

test('a short closed rail checks its real intermediate motion even when one tick ends back at its source',()=>{
 const r=room({powBlocks:[pow({gravity:0,rail:{trackId:'pow-loop',speed:128,position:0,direction:1}})]});r.contraptions={version:1,tracks:[{id:'pow-loop',start:[128,108],segments:[{kind:'line',to:[160,108]},{kind:'line',to:[128,108]}],mode:'loop'}]};
 const wall={id:'loop-wall',x:145,y:0,w:2,h:384,collision:'solid'},h=harness(r,{solids:[wall],p:player(400,200)});h.step();assert.equal(h.actors[0].x,129);assert.equal(h.actors[0].x+16,wall.x);assert.equal(h.actors[0].smm2Pow.phase,'live');
});

test('duplicate/stale/paused ticks do not advance clocks; reset/rebuild restores all source poses and spend state',()=>{
 const r=room({powBlocks:[pow()],helmets:[helmet()],skewers:[skewer({waitFrames:0})]},[native(),native({id:'helmet',x:200}),native({id:'skewer',kind:'hazard',x:40,y:80,w:32,h:24})]),actors=r.map.objects.map(live),items=createSmm2Items(r),p=player(80,80);
 items.beginFrame({tick:1,actors,player:p});items.stepItem(actors[0],{tick:1});const y=actors[0].y,clock=actors[2].smm2Skewer.clock,extension=actors[2].smm2Skewer.extension;
 assert.equal(items.beginFrame({tick:1,actors,player:p}),false);assert.equal(items.stepItem(actors[0],{tick:1}).advanced,false);assert.equal(actors[0].y,y);assert.equal(actors[2].smm2Skewer.clock,clock);
 assert.equal(items.beginFrame({tick:0,actors,player:p}),false);assert.equal(items.view(actors).tick,1);
 assert.equal(items.beginFrame({tick:2,actors,player:p,paused:true}),false);assert.equal(items.stepItem(actors[0],{tick:2}).advanced,false);assert.equal(actors[2].smm2Skewer.extension,extension);
 items.beginFrame({tick:2,actors,player:p});assert.equal(actors[2].smm2Skewer.clock,clock+1);
 actors[0].dead=true;actors[0].smm2Pow.phase='spent';actors[1].dead=true;actors[1].smm2Helmet.phase='worn';items.reset(actors);assert.equal(items.view(actors).tick,null);
 for(let i=0;i<actors.length;i++){assert.equal(actors[i].x,r.map.objects[i].x);assert.equal(actors[i].y,r.map.objects[i].y);assert.equal(actors[i].dead,false);}
 assert.equal(actors[0].smm2Pow.phase,'live');assert.equal(actors[1].smm2Helmet.phase,'loose');assert.equal(actors[2].smm2Skewer.phase,'unloaded');assert.equal(actors[2].smm2Skewer.extension,0);
 const rebuilt=createSmm2Items(r),fresh=r.map.objects.map(live);rebuilt.beginFrame({tick:0,actors:fresh,player:player(400,200)});assert.equal(fresh[0].smm2Pow.phase,'live');assert.equal(fresh[2].smm2Skewer.phase,'unloaded');assert.equal(fresh[2].smm2Skewer.clock,0);
});

test('placed 1UP validates a native walker source and shares strict item ID/rail validation',()=>{
 const r=room({placedItems:[placed()]},[native({id:'placed-life'})]),original=JSON.stringify(r);validateSmm2ItemsRoom(r);const items=createSmm2Items(r);assert.equal(JSON.stringify(r),original);assert.equal(items.ownsActor(r.map.objects[0]),true);
 const cases=[{placedItems:[placed({kind:'flower'})]},{placedItems:[placed({reward:'life'})]},{placedItems:[placed(),placed()]},{placedItems:[placed({gravity:Infinity})]},{placedItems:[placed({rail:{trackId:'absent',speed:1,position:0,direction:1}})]},{placedItems:[placed({id:'pow'})],powBlocks:[pow()]}];for(const m of cases)assert.throws(()=>validateSmm2ItemsRoom(room(m,[native(),native({id:'placed-life'})])));
 assert.throws(()=>validateSmm2ItemsRoom(room({placedItems:[placed()]},[native({id:'placed-life',kind:'hazard'})])),/native walker/);
});

test('free placed 1UP uses real gravity/support with no solid collider or standable body',()=>{
 const h=harness(room({placedItems:[placed()]},[native({id:'placed-life',x:120,y:144})]),{solids:[floor],p:player(400,100)}),a=h.actors[0];for(let i=0;i<20;i++)h.step();assert.equal(a.y+a.h,floor.y);assert.equal(a.support,floor.id);assert.equal(a.kind,'life');assert.equal(a.standable,false);assert.equal(a.smm2PlacedItem.phase,'live');assert.equal(h.items.geometry([],[a]).length,0);assert.equal(a.dead,undefined);
});

test('placed 1UP contact never automatically rewards, spends, wears or changes Mario power',()=>{
 const r=room({placedItems:[placed({gravity:0})]},[native({id:'placed-life'})]),a=live(r.map.objects[0]),events=[],items=createSmm2Items(r,{emit:(kind,event)=>events.push({kind,...event})}),p=player(124,102,{power:2,h:28,lives:3});items.decorateActor(a);items.beginFrame({tick:1,actors:[a],player:p});
 assert.deepEqual(items.afterPlayer(p,{...p},{tick:1,actors:[a]}),{handled:true,activated:[],worn:[],effects:[]});const head=player(124,110,{power:2,h:28}),before=player(124,124,{power:2,h:28,vy:-4});assert.deepEqual(items.afterPlayer(head,before,{tick:1,actors:[a]}).worn,[]);assert.equal(a.dead,undefined);assert.equal(p.lives,3);assert.equal(p.power,2);assert.equal(p.helmet,undefined);assert.equal(events.length,0);
 // Host collection owns the reward and marks the actual item unavailable.
 a.dead=true;assert.equal(items.stepItem(a,{tick:1}).advanced,false);items.reset([a]);assert.equal(a.dead,false);assert.equal(a.smm2PlacedItem.phase,'live');assert.equal(a.standable,false);
});

test('placed rail 1UP follows a real declared path without POW geometry or automatic reward',()=>{
 const r=room({placedItems:[placed({gravity:0,rail:{trackId:'life-track',speed:2,position:0,direction:1}})]},[native({id:'placed-life'})]);r.contraptions={version:1,tracks:[{id:'life-track',start:[128,108],segments:[{kind:'line',to:[160,108]}],mode:'bounce'}]};const h=harness(r,{p:player(400,100)}),a=h.actors[0];for(let i=0;i<20;i++){const x=a.x;h.step();assert.ok(Math.abs(a.x-x)<=2+1e-7);assert.equal(h.items.geometry([],[a]).length,0);}assert.equal(a.x,144);assert.equal(a.smm2PlacedItem.rail.direction,-1);assert.equal(a.dead,undefined);assert.equal(a.standable,false);assert.equal(h.events.length,0);
 const moved=structuredClone(r);moved.map.objects[0].x++;assert.throws(()=>validateSmm2ItemsRoom(moved),/source centre/);
 const bad=structuredClone(r);bad.smm2Mechanics.placedItems[0].rail.direction=0;assert.throws(()=>validateSmm2ItemsRoom(bad),/attachment/);
});

test('declared life, Mushroom and Star kinds survive decoration, view and reset without a reward inferred from actor metadata',()=>{
 const kinds=['life','mushroom','star'],r=room({placedItems:kinds.map(kind=>placed({id:kind,kind}))},kinds.map(id=>native({id}))),original=JSON.stringify(r),actors=r.map.objects.map(q=>live({...q,kind:'flower'})),items=createSmm2Items(r);validateSmm2ItemsRoom(r);
 for(let n=0;n<actors.length;n++){items.decorateActor(actors[n]);assert.equal(actors[n].kind,kinds[n]);assert.equal(actors[n].smm2PlacedItem.phase,'live');assert.equal(actors[n].standable,false);assert.equal(actors[n].smm2Skewer,undefined);}
 assert.deepEqual(items.view(actors).actors.map(q=>q.kind),kinds);assert.equal(items.geometry([],actors).length,0);assert.equal(JSON.stringify(r),original);
 for(const a of actors){a.kind='flower';a.dead=true;a.taken=true;a.smm2PlacedItem.phase='collected';}items.reset(actors);assert.deepEqual(actors.map(a=>a.kind),kinds);assert(actors.every(a=>!a.dead&&!a.taken&&a.smm2PlacedItem.phase==='live'));
});

test('claw-held placed items keep the host pose and release velocity, suppress gravity and authored rail motion, then resume next tick',()=>{
 for(const rail of [undefined,{trackId:'held-track',speed:2,position:0,direction:1}]){
  const r=room({placedItems:[placed({kind:'mushroom',...(rail?{rail}:{})})]},[native({id:'placed-life'})]);if(rail)r.contraptions={version:1,tracks:[{id:'held-track',start:[128,108],segments:[{kind:'line',to:[160,108]}],mode:'bounce'}]};let held=true;const a=live(r.map.objects[0]),items=createSmm2Items(r,{isHeld:actor=>actor===a&&held}),p=player(400,100);items.decorateActor(a);
  Object.assign(a,{x:150,y:80,vx:1.5,vy:-2});items.beginFrame({tick:1,actors:[a],player:p});const before={...a},result=items.stepItem(a,{tick:1,geometry:[floor]});assert.deepEqual(result,{handled:true,advanced:false,held:true,phase:'live'});for(const key of ['x','y','vx','vy'])assert.equal(a[key],before[key]);assert.equal(a.smm2PlacedItem.rail?.position,rail?.position);assert.equal(a.smm2PlacedItem.dx,0);assert.equal(a.smm2PlacedItem.dy,0);
  held=false;assert.equal(items.stepItem(a,{tick:1}).advanced,false,'the same held tick cannot be stepped twice after release');items.beginFrame({tick:2,actors:[a],player:p});assert.equal(items.stepItem(a,{tick:2}).advanced,true);if(rail)assert.equal(a.smm2PlacedItem.rail.position,2);else{assert.equal(a.x,before.x+before.vx);assert.equal(a.y,before.y+before.vy+.4375);assert.equal(a.vy,before.vy+.4375);}
 }
 const r=room({placedItems:[placed()]},[native({id:'placed-life'})]);assert.throws(()=>createSmm2Items(r,{isHeld:true}),/callbacks/);const a=live(r.map.objects[0]),items=createSmm2Items(r,{isHeld:()=>Promise.resolve(true)});items.beginFrame({tick:1,actors:[a]});assert.throws(()=>items.stepItem(a,{tick:1}),/synchronous boolean/);
});

test('owned placed-item collection requires live unheld overlap and returns the declared reward exactly once for the host',()=>{
 for(const kind of ['life','mushroom','star']){
  const r=room({placedItems:[placed({kind})],powBlocks:[pow()]},[native({id:'placed-life'}),native()]),a=live(r.map.objects[0]),powActor=live(r.map.objects[1]),events=[];let held=true;const items=createSmm2Items(r,{isHeld:()=>held,emit:(event,data)=>events.push({event,...data})}),p=player(124,102,{power:0,lives:3,star:0});items.beginFrame({tick:1,actors:[a,powActor],player:p});
  assert.deepEqual(items.ownedItemContact({id:'unknown'},p,{tick:1}),{handled:false,collect:null});assert.deepEqual(items.ownedItemContact(powActor,p,{tick:1}),{handled:true,collect:null});assert.equal(items.ownedItemContact(a,p,{tick:1}).collect,null,'held cargo cannot be collected');held=false;assert.equal(items.ownedItemContact(a,player(400,100),{tick:1}).collect,null);assert.equal(items.ownedItemContact(a,player(124,102,{dead:true}),{tick:1}).collect,null);assert.equal(items.ownedItemContact(a,p,{tick:0}).collect,null);
  a.kind='flower';const result=items.ownedItemContact(a,p,{tick:1});assert.deepEqual(result.collect,{actorId:a.id,kind,points:0,tick:1,position:{x:128,y:108}});assert.equal(a.dead,true);assert.equal(a.taken,true);assert.equal(a.smm2PlacedItem.phase,'collected');assert.equal(items.ownedItemContact(a,p,{tick:1}).collect,null);assert.equal(items.stepItem(a,{tick:1}).advanced,false);assert.equal(events.length,1);assert.equal(p.power,0);assert.equal(p.lives,3);assert.equal(p.star,0,'host alone applies power, life and Star rewards');
  items.reset([a,powActor]);assert.equal(a.dead,false);assert.equal(a.taken,false);items.beginFrame({tick:1,actors:[a,powActor],player:p,paused:true});assert.equal(items.ownedItemContact(a,p,{tick:1}).collect,null);items.beginFrame({tick:1,actors:[a,powActor],player:p});assert.equal(items.ownedItemContact(a,p,{tick:1}).collect.kind,kind);
 }
});

test('a real fixed claw captures true Mushroom cargo, suppresses its gravity, drops for below Mario and allows one real pickup',()=>{
 const r=room({placedItems:[placed({kind:'mushroom',points:1000})]},[native({id:'placed-life'})]);r.contraptions={version:1,claws:[{id:'mushroom-claw',anchor:[128,66],ropeLength:42,swingDegrees:0}]};const railEvents=[],rail=createRailClaws(r,{emit:(event,data)=>railEvents.push({event,...data})}),a=live(r.map.objects[0]),p=player(400,100,{clawCatchable:false,power:0}),items=createSmm2Items(r,{isHeld:actor=>rail.held(actor)});
 const frame=tick=>{items.beginFrame({tick,actors:[a],player:p});const motion=items.stepItem(a,{tick});rail.step({tick,player:p,items:[a]});return motion;};assert.equal(frame(1).advanced,true);assert.equal(rail.held(a),true);assert.equal(rail.view().claws[0].heldId,a.id);assert.equal(a.kind,'mushroom');assert.equal(a.y,108);assert.equal(a.smm2PlacedItem.phase,'live');
 for(let tick=2;tick<12;tick++){const before=poseForTest(a);assert.equal(frame(tick).advanced,false);assert.deepEqual(poseForTest(a),before);assert.equal(rail.held(a),true);assert.equal(items.ownedItemContact(a,p,{tick}).collect,null);}
 Object.assign(p,{x:124,y:109});assert.equal(frame(12).advanced,false,'the claw still owns cargo motion before its physical release');assert.equal(rail.held(a),false);const contact=items.ownedItemContact(a,p,{tick:12});assert.equal(contact.collect.kind,'mushroom');assert.equal(contact.collect.points,1000);assert.equal(contact.collect.actorId,a.id);assert.equal(a.dead,true);assert.equal(p.power,0);assert.equal(items.ownedItemContact(a,p,{tick:12}).collect,null);assert.deepEqual(railEvents.map(q=>[q.event,q.actorId,q.reason]),[['capture',a.id,undefined],['release',a.id,'player-below']]);
 items.reset([a]);rail.reset();Object.assign(p,{x:400,y:100});frame(1);assert.equal(rail.held(a),true);assert.equal(a.dead,false);assert.equal(a.kind,'mushroom');
});
function poseForTest(a){return Object.fromEntries(['x','y','w','h','vx','vy'].map(key=>[key,a[key]]));}

test('placed-item score is optional and bounded, with legacy zero and only declared points returned once to the host',()=>{
 for(const points of [-1,.5,100001,Infinity,NaN,'1000',null,true])assert.throws(()=>validateSmm2ItemsRoom(room({placedItems:[placed({points})]},[native({id:'placed-life'})])),/placed item score/);
 for(const points of [undefined,0,1000,100000]){
  const r=room({placedItems:[placed({kind:'mushroom',...(points===undefined?{}:{points})})]},[native({id:'placed-life'})]),a=live({...r.map.objects[0],points:999}),items=createSmm2Items(r),p=player(124,102,{score:17});items.beginFrame({tick:1,actors:[a],player:p});const result=items.ownedItemContact(a,p,{tick:1});assert.equal(result.collect.points,points??0);assert.equal(items.ownedItemContact(a,p,{tick:1}).collect,null);assert.equal(p.score,17,'the host alone awards declared points');
 }
});

const strikingThwomp=extra=>({id:'striker',direction:'down',triggerRange:256,transverseTolerance:0,leadReference:'near-edge',windupFrames:0,chargeAcceleration:16,chargeSpeedCap:64,impactWaitFrames:3,returnSpeed:8,breakMaterials:[],...extra});
function thwompPowFixture({definition={},powDefinition={},enemyBody={},powBody={},geometry=[]}={}){
 const r=room({powBlocks:[pow({gravity:0,...powDefinition})],thwomps:[strikingThwomp(definition)]},[native({x:120,y:100,...powBody}),native({id:'striker',x:120,y:20,w:24,h:24,...enemyBody})]);r.map.geometry=geometry;
 const a=live(r.map.objects[0]),enemy={...live(r.map.objects[1]),dead:false},events=[],items=createSmm2Items(r,{emit:(type,event)=>events.push({type,...event})}),thwomps=createSmm2Thwomps(r);items.decorateActor(a);thwomps.decorateEnemy(enemy);
 return {r,a,enemy,events,items,thwomps,step(tick,playerBody=player(128,180)){items.beginFrame({tick,actors:[a],player:playerBody});items.stepItem(a,{tick,geometry:r.map.geometry});const geometry=items.geometry(r.map.geometry,[a]);const result=thwomps.stepEnemy(enemy,{tick,player:playerBody,geometry});return {result,geometry,tick};}};
}
function actualPowImpact(f,playerBody=player(128,180)){
 for(let tick=1;tick<=30;tick++){const frame=f.step(tick,playerBody);if(frame.result.impact)return frame;}assert.fail('genuine native Thwomp never hit the actual POW');
}

test('actual downward Thwomp charge activates a live POW once and reports itself/nearby eligible bodies to the host',()=>{
 const f=thwompPowFixture(),frame=actualPowImpact(f),nearby={id:'airborne-neighbor',type:'smm2-thwomp',x:158,y:92,w:24,h:24,grounded:false},remote={id:'unrelated',type:'smm2-thwomp',x:400,y:80,w:24,h:24,grounded:true};
 assert.equal(f.enemy.smm2Thwomp.phase,'impact');assert.equal(frame.result.impact.solidId,'pow');assert.equal(f.enemy.y+f.enemy.h,f.a.y);
 const result=f.items.afterThwompImpact(f.enemy,{tick:frame.tick,contact:frame.result.impact,actors:[f.a],targets:[f.enemy,nearby,remote],geometry:frame.geometry,screen:{x:0,y:0,w:384,h:224}});
 assert.deepEqual(result.activated,['pow']);assert.equal(result.effects[0].approximation,true);assert.deepEqual(result.effects[0].trigger,{kind:'thwomp-impact',actorId:'striker'});assert.deepEqual(result.effects[0].position,{x:128,y:108});assert.deepEqual(result.effects[0].targets.map(q=>q.id),['striker','airborne-neighbor']);assert.equal(f.a.dead,true);assert.equal(f.a.standable,false);assert.equal(f.items.geometry(frame.geometry,[f.a]).some(q=>q.id==='pow'),false);
 assert.equal(f.enemy.dead,false);assert.equal(nearby.dead,undefined);assert.equal(remote.dead,undefined);assert.equal(f.items.afterThwompImpact(f.enemy,{tick:frame.tick,contact:frame.result.impact,actors:[f.a],targets:[f.enemy],geometry:frame.geometry}).activated.length,0);assert.equal(f.events.filter(q=>q.event==='pow-activate').length,1);
});

test('Thwomp POW impact shares the exact local/supported-screen target policy used by player activation',()=>{
 const support={id:'actual-floor',x:0,y:116,w:512,h:16,collision:'solid'},f=thwompPowFixture({powDefinition:{supportedScreenEffect:true,blastRadius:16},geometry:[support]}),frame=actualPowImpact(f),ground={id:'screen-ground',type:'smm2-thwomp',x:300,y:92,w:24,h:24,grounded:true},air={...ground,id:'screen-air',y:80,grounded:false},offscreen={...ground,id:'offscreen',x:450};
 const result=f.items.afterThwompImpact(f.enemy,{tick:frame.tick,contact:frame.result.impact,actors:[f.a],targets:[f.enemy,ground,air,offscreen],geometry:frame.geometry,screen:{x:0,y:0,w:384,h:224}});assert.equal(result.effects[0].touchingSolid,true);assert.deepEqual(result.effects[0].targets.map(q=>[q.id,q.reason]),[['striker','direct-charge'],['screen-ground','supported-screen']]);assert.equal(f.enemy.dead,false);assert.equal(ground.dead,undefined);
});

test('Thwomp POW impact rejects remote IDs/poses, embedded/side/up contacts, mismatched native records and inactive states',()=>{
 const cases=[
  (f,c)=>c.solidId='remote-pow',
  (f,c)=>f.enemy.x=300,
  (f,c)=>c.embedded=true,
  (f,c)=>c.normal={x:-1,y:0},
  (f,c)=>c.incomingVelocity.y=-1,
  (f,c)=>c.incomingVelocity.y=0,
  (f,c)=>c.point.y++,
  (f,c)=>c.body.y++,
  (f,c)=>c.fraction=NaN,
  (f,c)=>f.enemy.smm2Thwomp.phase='idle',
  (f,c)=>f.enemy.smm2Thwomp.phase='return',
  (f,c)=>f.enemy.type='goomba',
  (f,c)=>f.enemy.dead=true,
  (f,c)=>f.enemy.smm2Thwomp.contact=null,
  (f,c)=>f.enemy.smm2Thwomp.lastMotion=null,
  (f,c)=>f.enemy.support='other-solid',
  (f,c)=>f.a.x+=100,
  (f,c)=>f.a.smm2Pow.phase='spent',
 ];
 for(const mutate of cases){const f=thwompPowFixture(),frame=actualPowImpact(f),contact=structuredClone(frame.result.impact);mutate(f,contact);const result=f.items.afterThwompImpact(f.enemy,{tick:frame.tick,contact,actors:[f.a],targets:[f.enemy],geometry:frame.geometry});assert.deepEqual(result.activated,[]);assert.equal(f.events.filter(q=>q.event==='pow-activate').length,0);}
 const f=thwompPowFixture(),frame=actualPowImpact(f);assert.deepEqual(f.items.afterThwompImpact(f.enemy,{tick:frame.tick-1,contact:frame.result.impact,actors:[f.a],geometry:frame.geometry}).activated,[]);assert.deepEqual(f.items.afterThwompImpact(f.enemy,{tick:frame.tick,contact:frame.result.impact,actors:[f.a],geometry:[]}).activated,[]);f.items.beginFrame({tick:frame.tick+1,actors:[f.a],paused:true});assert.deepEqual(f.items.afterThwompImpact(f.enemy,{tick:frame.tick+1,contact:frame.result.impact,actors:[f.a],geometry:frame.geometry}).activated,[]);
});

test('an actual horizontal Thwomp/POW collision remains outside the verified downward trigger scope',()=>{
 const f=thwompPowFixture({definition:{direction:'right'},enemyBody:{x:40,y:100}}),frame=actualPowImpact(f,player(200,100));assert.equal(frame.result.impact.normal.x,-1);assert.equal(frame.result.impact.solidId,'pow');assert.deepEqual(f.items.afterThwompImpact(f.enemy,{tick:frame.tick,contact:frame.result.impact,actors:[f.a],geometry:frame.geometry}).activated,[]);assert.equal(f.a.smm2Pow.phase,'live');assert.equal(f.a.dead,undefined);
});

test('a genuine zero-distance first charge can hit a touching POW; subsequent resting impact support cannot',()=>{
 const first=thwompPowFixture({enemyBody:{y:76}}),frame=actualPowImpact(first);assert.equal(frame.result.impact.fraction,0);assert.deepEqual(first.items.afterThwompImpact(first.enemy,{tick:frame.tick,contact:frame.result.impact,actors:[first.a],geometry:frame.geometry}).activated,['pow']);
 const resting=thwompPowFixture(),initial=actualPowImpact(resting),later=resting.step(initial.tick+1);assert.equal(later.result.impact,undefined);assert.equal(resting.enemy.smm2Thwomp.phase,'impact');assert.deepEqual(resting.items.afterThwompImpact(resting.enemy,{tick:later.tick,contact:resting.enemy.smm2Thwomp.contact,actors:[resting.a],geometry:later.geometry}).activated,[]);assert.equal(resting.a.smm2Pow.phase,'live');
});

test('ordinary falling POW crossing an idle Thwomp body cannot synthesize an impact activation',()=>{
 const f=thwompPowFixture({powDefinition:{gravity:.4375},powBody:{y:40},enemyBody:{y:100}});let overlapped=false;for(let tick=1;tick<=30;tick++){const frame=f.step(tick,player(400,300));overlapped||=f.a.y<f.enemy.y+f.enemy.h&&f.a.y+f.a.h>f.enemy.y;assert.equal(f.enemy.smm2Thwomp.phase,'idle');assert.deepEqual(f.items.afterThwompImpact(f.enemy,{tick,contact:frame.result.impact,actors:[f.a],geometry:frame.geometry}).activated,[]);}assert.equal(overlapped,true);assert.equal(f.a.smm2Pow.phase,'live');assert.equal(f.a.dead,undefined);assert.equal(f.events.filter(q=>q.event==='pow-activate').length,0);
});

test('actual Thwomp/seesaw impact launches a real POW/rider without turning it into a POW strike',()=>{
 const saw={id:'impact-seesaw',pivotX:240,pivotY:160,length:128,thickness:8,initialAngleDegrees:0,maxAngleDegrees:30,weightAcceleration:0,maxAngularSpeedDegrees:2,damping:.9,impactSpeedThreshold:2,impactGain:.7,maxLaunchSpeed:20,impactMinLeverFraction:.1,impactPolicy:'thwomp'},r=room({powBlocks:[pow()],thwomps:[strikingThwomp()],seesaws:[saw]},[native({x:281,y:140}),native({id:'striker',x:181,y:100,w:24,h:24})]),a=live(r.map.objects[0]),enemy=live(r.map.objects[1]),rider=player(284,126,{grounded:true,support:'pow'}),terrain=createSMM2Terrain(r),events=[],items=createSmm2Items(r,{terrain,emit:(type,e)=>events.push(e)}),thwomps=createSmm2Thwomps(r,{terrain}),actors=[a,enemy,rider];items.decorateActor(a);thwomps.decorateEnemy(enemy);let hit=false;
 for(let tick=1;tick<=6&&!hit;tick++){terrain.beginFrame({tick,actors});items.beginFrame({tick,actors:[a],player:player(184,180)});items.stepItem(a,{tick,geometry:terrain.geometry([])});const geometry=items.geometry(terrain.geometry([]),[a]),result=thwomps.stepEnemy(enemy,{tick,player:player(184,180),geometry});if(result.impact){hit=true;assert.equal(result.impact.solidId,saw.id);assert.deepEqual(items.afterThwompImpact(enemy,{tick,contact:result.impact,actors:[a],targets:[enemy],geometry}).activated,[]);}terrain.finishFrame({tick,actors});}
 assert.equal(hit,true);assert.ok(a.vy<0);assert.ok(rider.vy<0);assert.equal(a.smm2Pow.phase,'live');assert.equal(a.dead,undefined);assert.equal(events.filter(q=>q.event==='pow-activate').length,0);
});
