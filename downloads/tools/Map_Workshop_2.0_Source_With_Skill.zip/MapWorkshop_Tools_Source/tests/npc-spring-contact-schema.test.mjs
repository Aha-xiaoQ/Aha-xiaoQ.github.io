import {test} from 'node:test';
import assert from 'node:assert/strict';
import {blank,validate,parseProject,History} from '../atlas/editor-model.mjs';
import {validateSmm2CourseComponents} from '../atlas/editor-smm2-course-components.mjs';
import {setSmm2Spring,captureSmm2GeometryBindings,appendSmm2GeometryBindings} from '../atlas/editor-smm2-course-tools.mjs';
import {weightedSpringProject} from './fixtures/weighted-spring-seesaw.mjs';

// Actual measured R3 Spring17,7 and adjacent separator/right-wall/floor bounds.
// This fixture checks the reusable project leaf, not another delivered course.
function project({npcContact=true}={}){
 const d=blank('Static NPC Spring contact contract',384,224),r=d.rooms[0];r.setting='Overworld';
 r.map.geometry=[
  {id:'floor',x:0,y:176,w:384,h:32,material:'ground',collision:'solid'},
  {id:'separator',x:96,y:128,w:288,h:16,material:'ground',collision:'solid'},
  {id:'right-wall',x:288,y:0,w:96,h:128,material:'ground',collision:'solid'},
  {id:'spring',x:272,y:112,w:16,h:16,material:'spring',collision:'solid',springOrientation:'vertical'}
 ];
 r.map.objects=[{id:'start',kind:'spawn',x:32,y:162,w:10,h:14},{id:'exit',kind:'exit',x:352,y:144,w:16,h:32}];
 r.smm2Mechanics={version:1,springs:[{id:'spring',orientation:'vertical',launchSpeed:6,compressionFrames:12,cooldownFrames:12,...(npcContact?{npcContact:{compressionFrames:6,launchSpeed:6.75,compressionDepth:7.2}}:{})}]};
 return d;
}
const rule=d=>d.rooms[0].smm2Mechanics.springs[0];

test('optional NPC Spring leaf is strict and requires its own finite duration and launch speed',()=>{
 const d=project();assert.doesNotThrow(()=>validate(d));
 const invalid=[null,false,[],{}, {compressionFrames:6}, {launchSpeed:6.75},
  {compressionFrames:0,launchSpeed:6.75},{compressionFrames:1.5,launchSpeed:6.75},
  {compressionFrames:6,launchSpeed:Infinity},{compressionFrames:6,launchSpeed:0},
  {compressionFrames:6,launchSpeed:6.75,compressionDepth:0},
  {compressionFrames:6,launchSpeed:6.75,compressionDepth:16},
  {compressionFrames:6,launchSpeed:6.75,id:'other-spring'},
  {compressionFrames:6,launchSpeed:6.75,actorId:'course-koopa'},
  {compressionFrames:6,launchSpeed:6.75,jumpKey:'auto'},
  {compressionFrames:6,launchSpeed:6.75,undersideBounce:true},
  {compressionFrames:6,launchSpeed:6.75,horizontalLaunch:true},
  {compressionFrames:6,launchSpeed:6.75,carrierId:'seesaw'}];
 for(const leaf of invalid){const bad=project();rule(bad).npcContact=leaf;assert.throws(()=>validateSmm2CourseComponents(bad.rooms[0]),JSON.stringify(leaf));assert.throws(()=>validate(bad));}
 const inherited=project();rule(inherited).npcContact=Object.assign(Object.create({unseen:true}),{compressionFrames:6,launchSpeed:6.75});assert.throws(()=>validateSmm2CourseComponents(inherited.rooms[0]),/fields/);
 const optional=project();delete rule(optional).npcContact.compressionDepth;assert.doesNotThrow(()=>validate(optional));
});

test('NPC contact rejects horizontal or moving Springs while legacy spring configurations retain their scope',()=>{
 for(const mutate of [
  d=>rule(d).orientation='horizontal',
  d=>d.rooms[0].map.geometry.find(q=>q.id==='spring').springOrientation='horizontal',
  d=>d.rooms[0].map.geometry.find(q=>q.id==='spring').material='stone',
  d=>d.rooms[0].map.geometry.find(q=>q.id==='spring').hidden=true,
  d=>d.rooms[0].map.geometry.find(q=>q.id==='spring').motion={axis:'x',min:272,max:280,speed:1},
  d=>d.rooms[0].map.geometry.find(q=>q.id==='spring').liftSpeed=1,
  d=>d.rooms[0].smm2Mechanics.carrierGeometry=[{id:'spring',carrierId:'floor'}],
  d=>d.rooms[0].marioModules={contactPlatforms:{spring:{speed:1}}}
 ]){const bad=project();mutate(bad);assert.throws(()=>validateSmm2CourseComponents(bad.rooms[0]),/static vertical/);}
 const legacy=project({npcContact:false});legacy.rooms[0].map.geometry.find(q=>q.id==='spring').material='stone';assert.doesNotThrow(()=>validateSmm2CourseComponents(legacy.rooms[0]));
 const moving=weightedSpringProject({impact:false});assert.doesNotThrow(()=>validate(moving));const r=moving.rooms[0];r.smm2Mechanics.springs=[{id:'spring',orientation:'vertical',launchSpeed:6,compressionFrames:12,cooldownFrames:12,npcContact:{compressionFrames:6,launchSpeed:6.75}}];assert.throws(()=>validate(moving),/static vertical/);
});

test('actual project import/export keeps NPC tuning separate and History rejects invalid edits atomically',()=>{
 const d=project(),saved=JSON.stringify(d),parsed=parseProject(saved);assert.deepEqual(parsed,d);
 assert.equal(rule(parsed).compressionFrames,12);assert.equal(rule(parsed).launchSpeed,6);assert.deepEqual(rule(parsed).npcContact,{compressionFrames:6,launchSpeed:6.75,compressionDepth:7.2});
 const history=new History(parsed);history.change(()=>{rule(history.doc).npcContact.launchSpeed=6.5;});assert.equal(rule(history.doc).launchSpeed,6);assert.equal(rule(history.doc).npcContact.launchSpeed,6.5);
 const before=JSON.stringify(history.doc),undos=history.undoStack.length;assert.throws(()=>history.change(()=>{rule(history.doc).npcContact.secretActor='course-id';}));assert.equal(JSON.stringify(history.doc),before);assert.equal(history.undoStack.length,undos);
 history.undo();assert.deepEqual(history.doc,d);history.redo();assert.equal(rule(history.doc).npcContact.launchSpeed,6.5);assert.deepEqual(parseProject(JSON.stringify(history.doc)),history.doc);
 const old=project({npcContact:false});assert.deepEqual(parseProject(JSON.stringify(old)),old);assert.equal(rule(old).npcContact,undefined);
});

test('existing author setter and geometry clipboard retain the strict NPC leaf while rebinding only Spring IDs',()=>{
 const d=project({npcContact:false}),r=d.rooms[0],npcContact={compressionFrames:6,launchSpeed:6.75,compressionDepth:7.2};
 setSmm2Spring(r,'spring',{npcContact});assert.deepEqual(rule(d).npcContact,npcContact);setSmm2Spring(r,'spring',{compressionFrames:15});assert.equal(rule(d).compressionFrames,15);assert.deepEqual(rule(d).npcContact,npcContact);
 const snapshot=captureSmm2GeometryBindings(r,new Set(['spring'])),idMap=new Map([['spring','spring-copy']]);r.map.geometry.push({...r.map.geometry.find(q=>q.id==='spring'),id:'spring-copy',x:240});appendSmm2GeometryBindings(r,snapshot,idMap);
 const copied=r.smm2Mechanics.springs.find(q=>q.id==='spring-copy');assert.deepEqual(copied.npcContact,npcContact);assert.equal(copied.compressionFrames,15);assert.deepEqual(parseProject(JSON.stringify(d)),d);
 copied.npcContact.launchSpeed=6.5;assert.equal(rule(d).npcContact.launchSpeed,6.75,'copied tuning has no shared mutable nested reference');
});
