import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createEchoRecorder,drawEchoWorld,drawEchoHud} from '../atlas/editor-echo.mjs';
import {createPlatformMotor} from '../atlas/editor-mario-motor.mjs';
import {createPlatformStage} from '../atlas/editor-mario-stage.mjs';

const character={capabilities:['jump'],motion:{width:10,height:14,maxHealth:1}};
const clone=x=>structuredClone(x);
function room(id='main'){
 return {roomId:id,setting:'Overworld',map:{id:id+'-map',width:512,height:240,geometry:[{id:'floor',x:0,y:224,w:512,h:16,collision:'solid',material:'ground'}],objects:[{id:'start',kind:'spawn',x:24,y:210,w:10,h:14}]},markers:[],mechanics:{type:'echo-cooperation',version:1,maxFrames:360,anchorSpawn:'start'},devices:[{id:'plate-a',kind:'plate',actor:'ghost',label:'A',x:16,y:224,w:32,h:4},{id:'plate-c',kind:'plate',actor:'live',label:'C',x:80,y:224,w:32,h:4},{id:'gate-ac',kind:'gate',label:'A+C',x:400,y:32,w:16,h:192,requires:['plate-a','plate-c'],latch:true}]};
}
function stage(rooms=[room()],extra={}){
 const plan={character,stage:{entryRoom:rooms[0].roomId,entrySpawn:'start',title:'Retry fixture'},rooms:Object.fromEntries(rooms.map(r=>[r.roomId,r.map]))};
 return createPlatformStage({plan,motor:createPlatformMotor(),visualRooms:rooms,emit(){},...extra});
}
const pose=p=>Object.fromEntries(['x','y','w','h','vx','vy','facing','grounded','power','anim','crouch','swimming','swimStroke','onVine','springId'].filter(k=>p[k]!==undefined).map(k=>[k,p[k]]));
function record(s,frames=12,input=()=>({})){
 s.step({echo:true});for(let i=0;i<frames;i++)s.step(input(i));s.step({echo:true});assert.equal(s.view().echo.phase,'playing');
}
function release(s){s.step({});}
const device=(s,id='gate-ac')=>s.view().echo.devices.find(d=>d.id===id);
const waitDeath=s=>{for(let i=0;i<150&&!s.view().p.dying;i++)s.step({x:1,run:true});assert.equal(s.view().p.dying,true);};

test('committed recorder serialization and SHA-256 remain identical across drafts, retries and cancel',()=>{
 const recorder=createEchoRecorder(room()),native=stage();recorder.start(native.view().p);
 for(let i=0;i<40;i++){native.step({x:1,run:true,jump:i>=12&&i<22});recorder.afterFrame(native.view().p);}
 recorder.commit();const serialized=recorder.serializeTape(),sha=createHash('sha256').update(serialized).digest('hex'),digest=recorder.view().tapeDigest;
 for(let n=0;n<5;n++){
  recorder.start(native.view().p);native.step({x:-1});recorder.afterFrame(native.view().p);
  assert.equal(recorder.view().hasSavedTape,true);assert.equal(recorder.view().savedFrames,40);
  assert.equal(recorder.retry(),true);for(let i=0;i<45;i++)recorder.beforeFrame();recorder.cancel();
  assert.equal(recorder.serializeTape(),serialized);assert.equal(createHash('sha256').update(recorder.serializeTape()).digest('hex'),sha);assert.equal(recorder.view().tapeDigest,digest);
 }
 recorder.reset();assert.equal(recorder.serializeTape(),null);assert.equal(recorder.view().hasSavedTape,false);assert.equal(recorder.retry(),false);
});

test('T replays the exact same native ghost sequence from t0 in PLAY and HOLD',()=>{
 const r=room();r.devices=[];const s=stage([r]),anchor=pose(s.view().p),sequence=[];
 s.step({echo:true});for(let i=0;i<70;i++){s.step({x:1,run:true,jump:i>=20&&i<38});sequence.push(pose(s.view().p));}s.step({echo:true});
 const digest=s.view().echo.tapeDigest;assert.deepEqual(pose(s.view().echo.ghost),anchor);
 for(let n=0;n<4;n++){
  if(n){s.step({echoRetry:true,x:1,run:true,jump:true});assert.equal(s.view().tick,0);assert.equal(s.view().echo.cursor,0);assert.deepEqual(pose(s.view().p),anchor);assert.deepEqual(pose(s.view().echo.ghost),anchor);}
  for(let i=0;i<70;i++){s.step({});assert.deepEqual(pose(s.view().echo.ghost),sequence[i]);assert.equal(s.view().echo.tapeDigest,digest);}
  assert.equal(s.view().echo.phase,'holding');assert.equal(s.view().echo.savedFrames,70);assert.equal(s.view().echo.hasSavedTape,true);
 }
 s.step({echoRetry:true});for(let i=0;i<7;i++)s.step({});assert.equal(s.view().echo.cursor,7);s.step({echoRetry:true});assert.equal(s.view().echo.cursor,0);assert.equal(s.view().echo.tapeDigest,digest);
});

test('T rewinds live body, coins, timer, moving world and latches to recorded room start',()=>{
 const r=room();r.map.objects.push({id:'coin',kind:'coin',x:64,y:206,w:10,h:14});r.map.geometry.push({id:'moving',x:256,y:160,w:48,h:8,collision:'oneway',material:'platform',motion:{axis:'x',min:240,max:320,speed:1}});
 const s=stage([r]),anchor=s.view();record(s);
 for(let i=0;i<65;i++)s.step({x:1,run:true});assert.equal(s.view().coins,1);assert.equal(device(s).latched,true);assert.ok(s.view().timeLeft<anchor.timeLeft);assert.notEqual(s.view().geometry.find(g=>g.id==='moving').x,anchor.geometry.find(g=>g.id==='moving').x);
 s.step({echoRetry:true,x:1,jump:true,run:true});const v=s.view();assert.deepEqual(pose(v.p),pose(anchor.p));assert.equal(v.tick,anchor.tick);assert.equal(v.timeLeft,anchor.timeLeft);assert.equal(v.coins,anchor.coins);assert.equal(v.score,anchor.score);assert.ok(v.objects.some(o=>o.id==='coin'));assert.equal(device(s).latched,false);assert.deepEqual(v.geometry.find(g=>g.id==='moving'),anchor.geometry.find(g=>g.id==='moving'));
});

test('new R draft preserves the saved good tape; T cancels draft and restores it',()=>{
 const s=stage();record(s,14);const good=s.view().echo.tapeDigest;release(s);s.step({echo:true});
 for(let i=0;i<8;i++)s.step({x:1,jump:i<3});assert.equal(s.view().echo.phase,'recording');assert.equal(s.view().echo.frames,8);assert.equal(s.view().echo.savedFrames,14);assert.equal(s.view().echo.tapeDigest,good);assert.equal(s.view().echo.canRetry,true);
 s.step({echoRetry:true});assert.equal(s.view().echo.phase,'playing');assert.equal(s.view().echo.cursor,0);assert.equal(s.view().echo.frames,14);assert.equal(s.view().echo.tapeDigest,good);assert.equal(s.view().p.x,24);
 release(s);s.step({echo:true});for(let i=0;i<8;i++)s.step({x:1});s.step({echo:true});assert.equal(s.view().echo.savedFrames,8);assert.notEqual(s.view().echo.tapeDigest,good);
});

test('held T and C are one action, and command frames do not move or record',()=>{
 const s=stage();record(s,20);for(let i=0;i<5;i++)s.step({});s.step({echoRetry:true,x:1,jump:true,run:true});assert.equal(s.view().p.x,24);assert.equal(s.view().tick,0);
 for(let i=0;i<6;i++)s.step({echoRetry:true});assert.equal(s.view().echo.cursor,6);assert.equal(s.view().tick,6);
 s.pause();s.resume();s.step({echoRetry:true});assert.equal(s.view().echo.cursor,7);
 s.step({echoClear:true,x:1,run:true,jump:true});assert.equal(s.view().p.x,24);assert.equal(s.view().tick,0);assert.equal(s.view().echo.phase,'idle');assert.equal(s.view().echo.hasSavedTape,false);
 for(let i=0;i<4;i++)s.step({echoClear:true});assert.equal(s.view().tick,4);assert.equal(s.view().echo.phase,'idle');
});

test('simultaneous commands prioritize C, then T, then R with no lower command leaking',()=>{
 const s=stage();record(s);release(s);s.step({echo:true,echoRetry:true,echoClear:true,x:1});assert.equal(s.view().echo.phase,'idle');assert.equal(s.view().echo.hasSavedTape,false);assert.equal(s.view().tick,0);
 release(s);record(s);release(s);s.step({echo:true,echoRetry:true,x:1});assert.equal(s.view().echo.phase,'playing');assert.equal(s.view().echo.cursor,0);assert.equal(s.view().tick,0);
 for(let i=0;i<3;i++)s.step({echo:true,echoRetry:true});assert.equal(s.view().echo.cursor,3);assert.equal(s.view().echo.phase,'playing');
});

test('C explicitly removes saved and draft, returns anchor idle, and disables retry',()=>{
 const s=stage();record(s);release(s);s.step({echo:true});for(let i=0;i<5;i++)s.step({x:1});s.step({echoClear:true});const v=s.view();
 assert.equal(v.p.x,24);assert.equal(v.echo.phase,'idle');assert.equal(v.echo.frames,0);assert.equal(v.echo.ghost,null);assert.equal(v.echo.hasSavedTape,false);assert.equal(v.echo.savedFrames,0);assert.equal(v.echo.tapeDigest,null);assert.equal(v.echo.canRetry,false);
 s.step({echoRetry:true,x:1,run:true});assert.equal(s.view().p.x,24);assert.equal(s.view().tick,0);assert.equal(s.view().echo.phase,'idle');release(s);s.step({echo:true});assert.equal(s.view().echo.phase,'recording');
});

for(const afterRespawn of [false,true])test(`ordinary death retains committed tape and spent life for retry ${afterRespawn?'after respawn':'during death'}`,()=>{
 const r=room();r.map.objects.push({id:'hazard',kind:'hazard',x:72,y:210,w:16,h:14});const s=stage([r]);record(s);const digest=s.view().echo.tapeDigest;waitDeath(s);
 assert.equal(s.view().lives,2);assert.equal(s.view().echo.phase,'idle');assert.equal(s.view().echo.ghost,null);assert.equal(s.view().echo.hasSavedTape,true);assert.equal(s.view().echo.tapeDigest,digest);assert.equal(device(s).latched,false);
 if(afterRespawn){for(let i=0;i<110;i++)s.step({});assert.equal(!!s.view().p.dying,false);assert.equal(s.view().echo.hasSavedTape,true);assert.equal(s.view().echo.tapeDigest,digest);}
 s.step({echoRetry:true});assert.equal(s.view().lives,2);assert.equal(s.view().health,1);assert.equal(s.view().p.dying,undefined);assert.equal(s.view().p.x,24);assert.equal(s.view().echo.cursor,0);assert.equal(s.view().echo.phase,'playing');assert.equal(s.view().echo.tapeDigest,digest);
 release(s);s.step({echoClear:true});assert.equal(s.view().lives,2);release(s);s.step({echo:true});assert.equal(s.view().lives,2);
});

test('timer expiration cancels active playback but keeps exact tape for T without refunding death',()=>{
 const s=stage();record(s,6);const digest=s.view().echo.tapeDigest;
 for(let i=0;i<9600&&!s.view().p.dying;i++)s.step({});assert.equal(s.view().p.dying,true);assert.equal(s.view().lives,2);assert.equal(s.view().echo.hasSavedTape,true);assert.equal(s.view().echo.phase,'idle');assert.equal(s.view().echo.tapeDigest,digest);
 s.step({echoRetry:true});assert.equal(s.view().timeLeft,400);assert.equal(s.view().tick,0);assert.equal(s.view().lives,2);assert.equal(s.view().echo.phase,'playing');assert.equal(s.view().echo.tapeDigest,digest);
});

test('selected starting lives, powered body and original coin/score baseline survive R/T/C',()=>{
 const s=stage([room()],{initialState:{lives:6,power:1,coins:9,score:1200}}),anchor=s.view();record(s,30,i=>({x:1,run:true,jump:i<12}));
 for(const command of ['echoRetry','echoClear']){release(s);s.step({[command]:true});const v=s.view();assert.equal(v.lives,6);assert.equal(v.coins,9);assert.equal(v.score,1200);assert.equal(v.p.power,1);assert.equal(v.p.h,28);assert.equal(v.p.y,anchor.p.y);}
});

test('repeated T undoes attempt-local 100th coin rewards and cannot farm extra lives',()=>{
 const r=room();r.devices=[];r.map.objects.push({id:'hundredth',kind:'coin',x:64,y:206,w:10,h:14});const s=stage([r],{initialState:{lives:3,coins:99}});record(s,6);
 for(let n=0;n<4;n++){for(let i=0;i<60;i++)s.step({x:1,run:true});assert.equal(s.view().lives,4);assert.equal(s.view().coins,0);s.step({echoRetry:true});assert.equal(s.view().lives,3);assert.equal(s.view().coins,99);assert.ok(s.view().objects.some(o=>o.id==='hundredth'));}
});

test('a rewound native 1UP block and emerging item cannot accumulate extra lives across retries',()=>{
 const r=room();r.devices=[];r.map.geometry.push({id:'wall',x:80,y:128,w:32,h:96,collision:'solid',material:'pipe'});r.markers.push({id:'secret',kind:'hidden-block',x:24,y:160,source:{contents:'life'}});const s=stage([r]);record(s,6);
 for(let n=0;n<3;n++){
  for(let i=0;i<15;i++)s.step({jump:true});for(let i=0;i<260&&s.view().lives===3;i++)s.step({});assert.equal(s.view().lives,4);assert.equal(s.view().geometry.find(g=>g.id==='secret').hidden,false);
  s.step({echoRetry:true});assert.equal(s.view().lives,3);assert.equal(s.view().geometry.find(g=>g.id==='secret').hidden,true);assert.equal(s.view().items.length,0);
 }
});

test('room transition never reuses the previous room tape and fresh restart clears all cache',()=>{
 const a=room(),b=room('second');a.devices=b.devices=[];a.map.objects.push({id:'next',kind:'portal',x:20,y:200,w:24,h:24,targetRoom:'second',targetSpawn:'start'});const s=stage([a,b]);record(s,6);assert.equal(s.view().echo.hasSavedTape,true);
 for(let i=0;i<25;i++)s.step({});s.step({interact:true});assert.equal(s.view().roomId,'second');assert.equal(s.view().echo.phase,'idle');assert.equal(s.view().echo.hasSavedTape,false);assert.equal(s.view().echo.tapeDigest,null);
 s.step({echoRetry:true});assert.equal(s.view().roomId,'second');assert.equal(s.view().echo.phase,'idle');release(s);record(s,6);assert.equal(s.view().echo.hasSavedTape,true);s.dispose();const fresh=stage([a,b]);assert.equal(fresh.view().roomId,'main');assert.equal(fresh.view().echo.hasSavedTape,false);assert.equal(fresh.view().echo.canRetry,false);
});

for(const autoContinue of [false,true])test(`zero lives cannot be revived by T/R/C or echo continue (autoContinue=${autoContinue})`,()=>{
 const r=room();r.map.objects.push({id:'hazard',kind:'hazard',x:72,y:210,w:16,h:14});const s=stage([r],{initialState:{lives:1},autoContinue});record(s);waitDeath(s);assert.equal(s.view().lives,0);assert.equal(s.view().echo.canRetry,false);
 for(const command of ['echoRetry','echo','echoClear']){s.step({[command]:true});assert.equal(s.view().lives,0);assert.equal(s.view().p.dying,true);assert.notEqual(s.view().echo.phase,'playing');assert.notEqual(s.view().echo.phase,'recording');}
 assert.equal(s.continueFromCurrent(),false);for(let i=0;i<110;i++)s.step({});assert.equal(s.view().completed,true);assert.equal(s.view().lives,0);s.step({echoRetry:true,echo:true,echoClear:true});assert.equal(s.view().completed,true);assert.equal(s.view().lives,0);
});


test('a failed new draft still retains the previous committed recording',()=>{
 const r=room();r.map.objects.push({id:'hazard',kind:'hazard',x:144,y:210,w:16,h:14},{id:'coin',kind:'coin',x:64,y:206,w:10,h:14});const s=stage([r]);record(s,12);const digest=s.view().echo.tapeDigest;
 release(s);s.step({echo:true});waitDeath(s);assert.equal(s.view().echo.phase,'idle');assert.equal(s.view().echo.hasSavedTape,true);assert.equal(s.view().echo.savedFrames,12);assert.equal(s.view().echo.tapeDigest,digest);assert.ok(s.view().objects.some(o=>o.id==='coin'));assert.equal(device(s).latched,false);
 s.step({echoRetry:true});assert.equal(s.view().echo.phase,'playing');assert.equal(s.view().echo.tapeDigest,digest);assert.equal(s.view().coins,0);assert.equal(s.view().lives,2);
});

test('death costs accumulate across multiple ordinary respawns and cannot be reset by retry',()=>{
 const r=room();r.map.objects.push({id:'hazard',kind:'hazard',x:72,y:210,w:16,h:14});const s=stage([r]);record(s);const digest=s.view().echo.tapeDigest;
 for(const remaining of [2,1]){waitDeath(s);assert.equal(s.view().lives,remaining);for(let i=0;i<110;i++)s.step({});s.step({echoRetry:true});assert.equal(s.view().lives,remaining);assert.equal(s.view().echo.tapeDigest,digest);}
 waitDeath(s);assert.equal(s.view().lives,0);assert.equal(s.view().echo.canRetry,false);s.step({echoRetry:true});assert.equal(s.view().lives,0);assert.equal(s.view().p.dying,true);assert.equal(s.view().echo.hasSavedTape,true);assert.equal(s.view().echo.phase,'idle');
});

test('gate text sits below HUD and shared HUD distinguishes new record, saved replay and clear',()=>{
 const recorder=createEchoRecorder(room());recorder.apply([],stage().view().p);const labels=[],texts=[];
 const ctx=new Proxy({fillText:(text,x,y)=>{labels.push({text,x,y});texts.push(text);}}, {get:(target,key)=>target[key]??(()=>{}),set:(target,key,value)=>{target[key]=value;return true;}});
 drawEchoWorld(ctx,recorder.view(),room());assert.ok(labels.find(q=>q.text==='A+C').y>=78);drawEchoHud(ctx,recorder.view());assert.ok(texts.includes('R 从锚点新录制'));assert.ok(texts.includes('T 重试上次 · C 清空'));assert.ok(texts.includes('尚无缓存'));
 drawEchoHud(ctx,{...recorder.view(),inputLabels:{mode:'controller',record:'X',retry:'Y',clear:'LB',interact:'↓'}});assert.ok(texts.includes('X 从锚点新录制'));assert.ok(texts.includes('Y 重试上次 · LB 长按清空'));
});
