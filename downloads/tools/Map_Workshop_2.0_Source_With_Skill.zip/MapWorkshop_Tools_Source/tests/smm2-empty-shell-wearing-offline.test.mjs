import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
import {offlineFile} from '../atlas/editor-offline.mjs';
import {emptyShellProject,nativeSession} from './fixtures/empty-shell-native.mjs';

test('offline embedded runtime equips a genuinely pipe-falling shell once without Down, score or ownership',async()=>{
 const project=emptyShellProject({coins:[]});project.rooms[0].map.objects[0].x=107;const s=nativeSession(project),root=new URL('../atlas/',import.meta.url),html=await offlineFile(s.pack,s.doc.rooms,p=>fs.promises.readFile(new URL(p,root),'utf8'),p=>fs.promises.readFile(new URL('assets/classic-audio/'+p,root)));
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'Empty Shell Wearing Offline QA ')),htmlPath=path.join(dir,'fixture.html'),projectPath=path.join(dir,'fixture.qmap.json');
 try{fs.writeFileSync(htmlPath,html);fs.writeFileSync(projectPath,JSON.stringify(s.doc));const result=spawnSync(process.execPath,['--experimental-vm-modules',fileURLToPath(new URL('../scripts/check-empty-shell-wearing-offline.mjs',import.meta.url)),htmlPath,projectPath],{encoding:'utf8',timeout:30000,maxBuffer:1024*1024});assert.equal(result.status,0,result.stderr||result.stdout||String(result.error));const report=JSON.parse(result.stdout);assert.equal(report.actualEmbeddedStageExecuted,true);assert.equal(report.networkRequests,0);assert.equal(report.helmetEvents,1);assert.equal(report.downInputFrames,0);assert.equal(report.enemyDeathEffects,0);assert.equal(report.playerKickEvents,0);
 if(process.env.EMPTY_SHELL_WEARING_EVIDENCE_DIR){const out=process.env.EMPTY_SHELL_WEARING_EVIDENCE_DIR;fs.mkdirSync(out,{recursive:true});fs.writeFileSync(path.join(out,'empty-shell-wearing-fixture.html'),html);fs.writeFileSync(path.join(out,'empty-shell-wearing-fixture.qmap.json'),JSON.stringify(s.doc,null,2)+'\n');const {inputEvidence,...summary}=report;fs.writeFileSync(path.join(out,'EMPTY_SHELL_WEARING_OFFLINE_EVIDENCE.json'),JSON.stringify(summary,null,2)+'\n');fs.writeFileSync(path.join(out,'EMPTY_SHELL_WEARING_INPUT_RLE.json'),JSON.stringify(inputEvidence,null,2)+'\n');}
 }finally{fs.rmSync(dir,{recursive:true,force:true});}
});
