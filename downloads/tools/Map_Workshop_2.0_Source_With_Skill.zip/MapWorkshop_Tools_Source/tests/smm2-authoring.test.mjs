import fs from 'node:fs';
import assert from 'node:assert/strict';
import {test} from 'node:test';
import {createRequire} from 'node:module';
import {blank,History,parseProject,runtimeMap,moveSelection,deleteSelection,validate} from '../atlas/editor-model.mjs';
import {projectPack} from '../atlas/editor-runtime.mjs';
import {createStageCatalog} from '../atlas/runtime/stage-catalog.mjs';
import {offlineFile} from '../atlas/editor-offline.mjs';
import {createSMM2Terrain} from '../atlas/editor-smm2-terrain.mjs';
import {drawSmm2World,drawSmm2Actor} from '../atlas/editor-smm2-art.mjs';
import {drawReference} from '../atlas/editor-art.mjs';
import {classicSprite} from '../atlas/classic-art.mjs';
import {smm2ComponentTypes,addSmm2Component,setSmm2CheckpointReward,setSmm2GoalEnemyReward,setSmm2FlagScore,updateSmm2Component,removeSmm2Component,cloneSmm2Component,listSmm2Components,mountSmm2Tools,pruneSmm2DeletedReferences,captureSmm2ActorLeaves,appendCopiedSmm2ActorLeaves,drawSmm2EditorTerrain} from '../atlas/editor-smm2-tools.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';

const character=JSON.parse(fs.readFileSync(new URL('../atlas/runtime/character.json',import.meta.url)));
function project(){const d=blank('SMM2 authoring fixture',640,384),r=d.rooms[0];r.setting='Castle';r.map.geometry=[{id:'floor',x:0,y:352,w:640,h:32,collision:'solid',material:'ground'},{id:'ledge',x:208,y:192,w:64,h:8,collision:'oneway',material:'platform'}];r.map.objects=[{id:'start',kind:'spawn',x:16,y:338,w:10,h:14}];return d;}
const types=Object.keys(smm2ComponentTypes);
let createCanvas;try{({createCanvas}=createRequire(import.meta.url)('@napi-rs/canvas'));}catch{}
// classic-art caches its canvas sprites. Seed the vine with a real raster
// canvas before DOM-only inspector tests use the simulated canvas surface.
if(createCanvas){const ui=installSimulatedPlayDom();try{const create=ui.document.createElement;ui.document.createElement=tag=>tag==='canvas'?createCanvas(16,16):create(tag);classicSprite('src|Character|Vine||middle');}finally{ui.restore();}}

test('actual sidebar handlers create, edit, clone and delete every SMM2 component with undo/redo/reimport',()=>{
 const ui=installSimulatedPlayDom();try{
  const h=new History(project()),room=()=>h.doc.rooms[0],parent=ui.document.createElement('aside'),reports=[],panel=mountSmm2Tools({parent,room,change:fn=>h.change(fn),report:s=>reports.push(s)}),get=id=>parent.querySelector('[data-smm2-control="'+id+'"]');
  for(const type of types){
   get('type').value=type;get('type').dispatchEvent({type:'change'});assert.equal(get('apply').disabled,true);get('add').click();let q=listSmm2Components(room()).at(-1);assert.equal(q.type,type,reports.join('; '));const id=q.id;
   const field=type==='seesaw'?'pivotX':'x';get(field).value='160';get('apply').click();q=listSmm2Components(room()).find(q=>q.id===id);assert.equal((q.actor||q.spec)[field],160,reports.join('; '));
   const saved=JSON.stringify(h.doc),undos=h.undoStack.length;get(field).value='';get('apply').click();assert.equal(JSON.stringify(h.doc),saved);assert.equal(h.undoStack.length,undos,'invalid form creates no undo entry');get(field).value='-1';get('apply').click();assert.equal(JSON.stringify(h.doc),saved,'out-of-bounds edits roll back');
   h.undo();panel.refresh();assert.notEqual((listSmm2Components(room()).find(q=>q.id===id).actor||listSmm2Components(room()).find(q=>q.id===id).spec)[field],160);h.redo();panel.refresh();assert.equal(Number(get(field).value),160);
   get('clone').click();const copyId=get('select').value;assert.notEqual(copyId,id);q=listSmm2Components(room()).find(q=>q.id===copyId);assert.equal((q.actor||q.spec)[field],176);get('remove').click();assert(!listSmm2Components(room()).some(q=>q.id===copyId));h.undo();panel.refresh();assert(listSmm2Components(room()).some(q=>q.id===copyId));h.redo();panel.refresh();
  }
  assert.equal(listSmm2Components(room()).length,types.length);assert(reports.length>=types.length*2);assert.deepEqual(parseProject(JSON.stringify(h.doc)),h.doc);
  assert.deepEqual(room().map.objects.filter(q=>q.id!=='start').map(q=>q.kind),types.filter(type=>smm2ComponentTypes[type].native).map(type=>smm2ComponentTypes[type].native));
  assert(room().map.objects.every(q=>Object.keys(q).every(k=>['id','kind','x','y','w','h'].includes(k))),'new physical actors keep native ABI');
  assert.equal(room().map.geometry.length,2,'terrain never becomes fake native rectangles');
  assert.equal(room().smm2Mechanics.enemyRewards,undefined,'authoring does not invent a boss key rule');
  const pack=projectPack(h.doc,room().roomId,character,'smm2-authoring');createStageCatalog(pack).plan(pack.stages[0].id,pack.characters[0].id,{allowDraft:true});
 }finally{ui.restore();}
});

test('pure transactions reject unknown fields, duplicate IDs, cross-leaf actor reuse and invalid mechanics atomically',()=>{
 const d=project(),r=d.rooms[0],id=addSmm2Component(r,'thwomp',{id:'test-thwomp',oneWaySupportIds:['ledge']}),before=JSON.stringify(r);
 for(const run of [()=>updateSmm2Component(r,id,{script:'activate'}),()=>updateSmm2Component(r,id,{chargeAcceleration:0}),()=>updateSmm2Component(r,id,{oneWaySupportIds:['absent']}),()=>updateSmm2Component(r,id,{id:'changed'}),()=>addSmm2Component(r,'pow',{id}),()=>addSmm2Component(r,'slope',{id:'floor'}),()=>addSmm2Component(r,'vine',{w:33}),()=>addSmm2Component(r,'skewer',{travel:1000}),()=>cloneSmm2Component(r,id,{dx:Infinity})]){assert.throws(run);assert.equal(JSON.stringify(r),before);}
 for(const orientation of ['rise-left','rise-right','ceiling-rise-left','ceiling-rise-right'])addSmm2Component(r,'slope',{orientation});
 updateSmm2Component(r,id,{direction:'left',breakMaterials:[],winged:true,mass:4});assert.equal(r.smm2Mechanics.thwomps[0].winged,true);assert.deepEqual(r.smm2Mechanics.thwomps[0].breakMaterials,[]);validate(d);
 const incompatible=project().rooms[0];incompatible.playHero='bill';const snapshot=JSON.stringify(incompatible);assert.throws(()=>addSmm2Component(incompatible,'pow'));assert.equal(JSON.stringify(incompatible),snapshot);
});

test('native body movement and deletion preserve or prune only owned sidecars, named supports and key rewards',()=>{
 const h=new History(project()),room=()=>h.doc.rooms[0],donut=addSmm2Component(room(),'donut',{collision:'oneway'}),thwomp=addSmm2Component(room(),'thwomp',{oneWaySupportIds:['ledge',donut]}),pow=addSmm2Component(room(),'pow'),coin=addSmm2Component(room(),'pinkCoin');room().smm2Mechanics.enemyRewards=[{id:thwomp,reward:'key'}];validate(h.doc);
 const rule=structuredClone(room().smm2Mechanics.thwomps[0]);h.change(()=>moveSelection(room(),'objects',new Set([thwomp,pow,coin]),16,0));assert.equal(room().map.objects.find(q=>q.id===thwomp).x,144);assert.deepEqual(room().smm2Mechanics.thwomps[0],rule);
 h.change(()=>removeSmm2Component(room(),donut));assert.deepEqual(room().smm2Mechanics.thwomps[0].oneWaySupportIds,['ledge']);h.undo();assert.deepEqual(room().smm2Mechanics.thwomps[0].oneWaySupportIds,['ledge',donut]);
 h.change(()=>{const old=structuredClone(room());deleteSelection(room(),'objects',new Set([thwomp,pow,coin]));pruneSmm2DeletedReferences(room(),old);});assert.deepEqual(room().smm2Mechanics.thwomps,[]);assert.deepEqual(room().smm2Mechanics.powBlocks,[]);assert.deepEqual(room().smm2Mechanics.pinkCoins,[]);assert.deepEqual(room().smm2Mechanics.enemyRewards,[]);h.undo();assert.equal(room().smm2Mechanics.thwomps.length,1);h.redo();assert.equal(room().smm2Mechanics.thwomps.length,0);
 h.undo();h.change(()=>{const old=structuredClone(room());deleteSelection(room(),'geometry',new Set(['ledge']));pruneSmm2DeletedReferences(room(),old);});assert.deepEqual(room().smm2Mechanics.thwomps[0].oneWaySupportIds,[donut]);
 const invalid=structuredClone(room()),before=structuredClone(room());invalid.smm2Mechanics.pinkCoins.push({id:'nonexistent-new-coin'});pruneSmm2DeletedReferences(invalid,before);assert.throws(()=>validate({...h.doc,rooms:[invalid]}),/Pink coin/,'cleanup never masks new invalid references');
});

test('native clipboard copies same-ID actor mechanics and preserves strict importer and rail rollback',()=>{
 const h=new History(project()),room=()=>h.doc.rooms[0],ids=types.filter(type=>smm2ComponentTypes[type].native).map(type=>addSmm2Component(room(),type,{id:'copy-'+type.toLowerCase()})),snapshot=captureSmm2ActorLeaves(room(),new Set(ids)),idMap=new Map(ids.map(id=>[id,id+'-clone']));
 h.change(()=>{for(const id of ids){const actor=room().map.objects.find(q=>q.id===id);room().map.objects.push({...actor,id:idMap.get(id),x:actor.x+32});}appendCopiedSmm2ActorLeaves(room(),snapshot,idMap);});
 for(const [key,list]of Object.entries(snapshot))for(const q of list)assert.deepEqual(room().smm2Mechanics[key].find(c=>c.id===idMap.get(q.id)),{...q,id:idMap.get(q.id)});assert.deepEqual(parseProject(JSON.stringify(h.doc)),h.doc);h.undo();assert.equal(room().map.objects.length,ids.length+1);h.redo();assert.equal(room().map.objects.length,ids.length*2+1);
 const railRoom=project().rooms[0];railRoom.contraptions={version:1,tracks:[{id:'item-track',start:[136,88],segments:[{kind:'line',to:[200,88]}],mode:'bounce'}]};const pow=addSmm2Component(railRoom,'pow',{id:'rail-pow',rail:{trackId:'item-track',speed:1,position:0,direction:1}});const saved=JSON.stringify(railRoom);assert.throws(()=>cloneSmm2Component(railRoom,pow),/轨道/);assert.equal(JSON.stringify(railRoom),saved);updateSmm2Component(railRoom,pow,{blastRadius:64});assert.equal(railRoom.smm2Mechanics.powBlocks[0].rail.trackId,'item-track');
 const railHistory=new History({...project(),rooms:[railRoom]}),current=()=>railHistory.doc.rooms[0],before=JSON.stringify(railHistory.doc);assert.throws(()=>railHistory.change(()=>{current().map.objects.push({...current().map.objects.find(q=>q.id===pow),id:'rail-pow-copy',x:160});appendCopiedSmm2ActorLeaves(current(),captureSmm2ActorLeaves(current(),new Set([pow])),new Map([[pow,'rail-pow-copy']]));}),/轨道/);assert.equal(JSON.stringify(railHistory.doc),before);
});

test('ordinary project imports and native map/offline exports keep their existing format',async()=>{
 const d=project(),r=d.rooms[0],nativeBefore=runtimeMap(r);assert.deepEqual(parseProject(JSON.stringify(d)),d);assert.equal(drawSmm2EditorTerrain({},r),false);assert.deepEqual(runtimeMap(r),nativeBefore);
 for(const type of types)addSmm2Component(r,type);const imported=parseProject(JSON.stringify(d)),pack=projectPack(imported,r.roomId,character,'smm2-authoring-offline');createStageCatalog(pack);assert(pack.maps[0].objects.every(q=>['spawn','walker','hazard','coin'].includes(q.kind)));assert(!pack.maps[0].smm2Mechanics);
 const html=await offlineFile(pack,imported.rooms,path=>Promise.resolve(fs.readFileSync(new URL('../atlas/'+path.replace(/^\.\//,''),import.meta.url),'utf8')),async()=>new Uint8Array());
 assert(html.includes('workshop/editor-smm2-terrain.mjs'));assert(html.includes('workshop/editor-smm2-art.mjs'));assert(html.includes('"smm2Mechanics"'));assert(!html.includes('workshop/editor-smm2-tools.mjs'),'creator UI is not loaded into standalone play');
});

test('leaf-only preview matches live initialized slopes, Donuts, angled seesaw and static native vine pixels',{skip:!createCanvas},()=>{
 const ui=installSimulatedPlayDom();try{
  const originalCreate=ui.document.createElement;ui.document.createElement=tag=>tag==='canvas'?createCanvas(16,16):originalCreate(tag);
  const r=project().rooms[0];addSmm2Component(r,'donut',{x:16,y:16,w:32});for(const [i,orientation]of ['rise-left','rise-right','ceiling-rise-left','ceiling-rise-right'].entries())addSmm2Component(r,'slope',{x:80+i*80,y:32,w:48,h:24,orientation});addSmm2Component(r,'seesaw',{pivotX:192,pivotY:144,length:96,initialAngleDegrees:18});addSmm2Component(r,'vine',{x:32,y:128,h:96});const before=JSON.stringify(r),actual=createCanvas(640,384),expected=createCanvas(640,384);
  drawSmm2EditorTerrain(actual.getContext('2d'),r);drawSmm2World(expected.getContext('2d'),r,createSMM2Terrain(r).view());for(const q of r.smm2Mechanics.vines)drawReference(expected.getContext('2d'),{...q,kind:'active-vine'},r);
  const pixels=canvas=>canvas.getContext('2d').getImageData(0,0,640,384).data;assert.deepEqual(pixels(actual),pixels(expected));assert(pixels(actual).some((v,i)=>i%4===3&&v>0));assert.equal(JSON.stringify(r),before);
  const structural=createCanvas(640,384);drawSmm2EditorTerrain(structural.getContext('2d'),r,{effect:false});assert.equal(structural.getContext('2d').getImageData(81,40,1,1).data[3],255);assert.equal(structural.getContext('2d').getImageData(127,32,1,1).data[3],0,'floor slope remains triangular in structure view');
  for(const type of types.filter(type=>smm2ComponentTypes[type].native)){const id=addSmm2Component(r,type,{x:480,y:64});const actor=r.map.objects.find(q=>q.id===id),c=createCanvas(640,384);assert.equal(drawSmm2Actor(c.getContext('2d'),actor,0,r),true,'raw '+type+' sidecar remains visible');}
 }finally{ui.restore();}
});

test('sidebar follows new canvas selections without overriding explicit inspector selection or new component type',()=>{
 const ui=installSimulatedPlayDom();try{const h=new History(project()),room=()=>h.doc.rooms[0],a=addSmm2Component(room(),'thwomp'),b=addSmm2Component(room(),'pow'),parent=ui.document.createElement('aside');let selected=new Set([a]);const panel=mountSmm2Tools({parent,room,selected:()=>selected,change:fn=>h.change(fn)}),get=id=>parent.querySelector('[data-smm2-control="'+id+'"]');assert.equal(get('select').value,a);get('select').value=b;get('select').dispatchEvent({type:'change'});assert.equal(get('select').value,b);get('type').value='slope';get('type').dispatchEvent({type:'change'});get('add').click();assert.equal(listSmm2Components(room()).find(q=>q.id===get('select').value).type,'slope');selected=new Set([b]);panel.refresh();assert.equal(get('select').value,b);}finally{ui.restore();}
});

test('real editor DOM native paste, delete, eraser and local save retain SMM2 ownership through undo/redo',async()=>{
 const ui=installSimulatedPlayDom(),savedGlobals=new Map(),install=(key,value)=>{savedGlobals.set(key,Object.getOwnPropertyDescriptor(globalThis,key));Object.defineProperty(globalThis,key,{value,writable:true,configurable:true});};
 try{
  const initial=project(),r=initial.rooms[0],id=addSmm2Component(r,'thwomp',{id:'native-editor-thwomp',x:128,y:80,oneWaySupportIds:['ledge']}),coin=addSmm2Component(r,'pinkCoin',{id:'native-editor-pink',x:304,y:80}),shoe=addSmm2Component(r,'shoe',{id:'native-editor-shoe',x:352,y:240,kind:'stiletto',size:'small',winged:true,occupant:'empty'});r.map.objects.push({id:'native-editor-flag',kind:'checkpoint',x:432,y:304,w:16,h:48,targetSpawn:'start'});setSmm2CheckpointReward(r,'native-editor-flag',{reward:'mushroom',points:2000});setSmm2GoalEnemyReward(r,id,{points:1000});setSmm2FlagScore(r,false);const values=new Map([['xiaoq-map-workshop-tools-v1',JSON.stringify(initial)]]);
  install('localStorage',{getItem:key=>values.get(key)||null,setItem:(key,value)=>values.set(key,value)});install('devicePixelRatio',1);install('ResizeObserver',class{observe(){}});install('setTimeout',()=>1);install('clearTimeout',()=>{});
  ui.Element.prototype.closest=function(selector){for(let n=this;n;n=n.parentNode)if(selector.split(',').some(q=>q===n.tag||q==='.'+n.className||q==='#'+n.id))return n;return null;};ui.Element.prototype.removeAttribute=function(key){delete this.attributes[key];};
  ui.Element.prototype.after=function(node){const parent=this.parentNode,index=parent.children.indexOf(this);node.parentNode=parent;parent.children.splice(index+1,0,node);};
  const html=fs.readFileSync(new URL('../atlas/editor.html',import.meta.url),'utf8');ui.document.body.innerHTML=html.match(/<body[^>]*>([\s\S]*?)<\/body>/)[1];
  for(const n of ui.document.body.querySelectorAll('input')){n.value=n.getAttribute('value')||'';n.checked=n.getAttribute('checked')!==undefined;}
  for(const n of ui.document.body.querySelectorAll('select')){const options=n.querySelectorAll('option'),chosen=options.find(q=>q.getAttribute('selected')!==undefined)||options[0];n.value=chosen?.getAttribute('value')||'';}
  const get=id=>ui.document.getElementById(id),canvas=get('canvas'),viewport=get('viewport');viewport.clientWidth=480;viewport.clientHeight=384;canvas.getBoundingClientRect=()=>({left:0,top:0});get('zoom').value='1';
  await import('../atlas/editor.mjs?smm2-authoring-dom');assert(ui.document.querySelector('#smm2-tools'),'real editor mounts component tools in its existing properties sidebar');
  const saved=()=>{get('save').click();return JSON.parse(values.get('xiaoq-map-workshop-tools-v1'));},pointer=(type,x,y)=>canvas.dispatchEvent({type,button:0,pointerId:1,clientX:x,clientY:y}),tool=text=>get('tools').children.find(q=>q.textContent===text).click();
  get('layer').value='objects';get('layer').dispatchEvent({type:'change'});tool('框选 V');pointer('pointerdown',128,80);pointer('pointerup',128,80);assert(get('selection-info').textContent.includes('1 个元素'));
  get('copy').click();get('paste').click();let doc=saved(),leaf=doc.rooms[0].smm2Mechanics.thwomps.find(q=>q.id!==id);assert(leaf,'native paste carries its strict Thwomp sidecar');const pasted=doc.rooms[0].map.objects.find(q=>q.id===leaf.id);assert.deepEqual([pasted.x,pasted.y],[16,16]);assert.deepEqual(leaf.oneWaySupportIds,['ledge']);assert.deepEqual(doc.rooms[0].smm2Mechanics.goalEnemyRewards.find(q=>q.id===leaf.id),{id:leaf.id,points:1000});assert.equal(doc.rooms[0].smm2Mechanics.flagScore,false);
  get('delete').click();doc=saved();assert.equal(doc.rooms[0].smm2Mechanics.thwomps.length,1);assert.equal(doc.rooms[0].smm2Mechanics.goalEnemyRewards.length,1);get('undo').click();assert.equal(saved().rooms[0].smm2Mechanics.thwomps.length,2);assert.equal(saved().rooms[0].smm2Mechanics.goalEnemyRewards.length,2);get('redo').click();assert.equal(saved().rooms[0].smm2Mechanics.thwomps.length,1);assert.equal(saved().rooms[0].smm2Mechanics.goalEnemyRewards.length,1);
  tool('橡皮 E');pointer('pointerdown',304,80);pointer('pointerup',304,80);doc=saved();assert(!doc.rooms[0].map.objects.some(q=>q.id===coin));assert.deepEqual(doc.rooms[0].smm2Mechanics.pinkCoins,[]);get('undo').click();assert.equal(saved().rooms[0].smm2Mechanics.pinkCoins.length,1);
  get('layer').value='geometry';get('layer').dispatchEvent({type:'change'});tool('框选 V');pointer('pointerdown',208,192);pointer('pointerup',208,192);get('delete').click();doc=saved();assert.deepEqual(doc.rooms[0].smm2Mechanics.thwomps[0].oneWaySupportIds,[]);get('undo').click();doc=saved();assert.deepEqual(doc.rooms[0].smm2Mechanics.thwomps[0].oneWaySupportIds,['ledge']);assert.deepEqual(parseProject(JSON.stringify(doc)),doc);
  get('layer').value='objects';get('layer').dispatchEvent({type:'change'});tool('框选 V');pointer('pointerdown',352,240);pointer('pointerup',352,240);get('copy').click();get('paste').click();doc=saved();const shoeCopy=doc.rooms[0].smm2Mechanics.shoes.find(q=>q.id!==shoe);assert.equal(shoeCopy.kind,'stiletto');assert.equal(shoeCopy.winged,true);assert.equal(shoeCopy.occupant,'empty');assert(doc.rooms[0].map.objects.some(q=>q.id===shoeCopy.id));get('delete').click();assert.equal(saved().rooms[0].smm2Mechanics.shoes.length,1);get('undo').click();assert.equal(saved().rooms[0].smm2Mechanics.shoes.length,2);get('redo').click();assert.equal(saved().rooms[0].smm2Mechanics.shoes.length,1);
  tool('框选 V');pointer('pointerdown',432,304);pointer('pointerup',432,304);get('copy').click();get('paste').click();doc=saved();const rewardCopy=doc.rooms[0].smm2Mechanics.checkpointRewards.find(q=>q.id!=='native-editor-flag');assert.deepEqual(rewardCopy,{id:rewardCopy.id,reward:'mushroom',points:2000});assert(doc.rooms[0].map.objects.some(q=>q.id===rewardCopy.id&&q.kind==='checkpoint'&&q.targetSpawn==='start'));get('delete').click();assert.equal(saved().rooms[0].smm2Mechanics.checkpointRewards.length,1);get('undo').click();assert.equal(saved().rooms[0].smm2Mechanics.checkpointRewards.length,2);get('redo').click();assert.equal(saved().rooms[0].smm2Mechanics.checkpointRewards.length,1);assert.deepEqual(parseProject(JSON.stringify(saved())),saved());
 }finally{for(const [key,descriptor]of savedGlobals){if(descriptor)Object.defineProperty(globalThis,key,descriptor);else delete globalThis[key];}ui.restore();}
});


test('live vine reference without an ID renders safely in a room without liquid',{skip:!createCanvas},()=>{
 const ui=installSimulatedPlayDom();try{
  const create=ui.document.createElement;ui.document.createElement=tag=>tag==='canvas'?createCanvas(16,16):create(tag);
  const r=project().rooms[0],vine={kind:'active-vine',x:32,y:128,w:14,h:96},canvas=createCanvas(640,384),before=JSON.stringify({r,vine});
  assert.equal(drawReference(canvas.getContext('2d'),vine,r),true);
  assert(canvas.getContext('2d').getImageData(32,128,14,96).data.some((v,i)=>i%4===3&&v>0));
  assert.equal(JSON.stringify({r,vine}),before);
 }finally{ui.restore();}
});
