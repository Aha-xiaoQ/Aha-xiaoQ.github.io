import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {blank, History, parseProject, validate, paint, moveSelection} from '../atlas/editor-model.mjs';
import {createSmm2SnakeBlocks} from '../atlas/editor-snake-blocks.mjs';
import {setSmm2SnakeBlockTrain, cloneSmm2SnakeBlockTrain, removeSmm2SnakeBlockTrain, moveSmm2SnakeBlockTrains, moveSmm2SnakeBlockSelection, captureSmm2SnakeBlockTrains, appendCopiedSmm2SnakeBlockTrains, mountSmm2SnakeBlockTools} from '../atlas/editor-snake-block-tools.mjs';
import {initialSmm2SnakeBlockGeometry, validateSmm2SnakeBlockPlacement, smm2SnakeBlockPlacementIssues} from '../atlas/editor-snake-block-placement.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';
import {createCollection, addLevel, serializeCollection, parseCollection, buildCollection} from '../atlas/editor-collection.mjs';

// Explicit neutral author fits, unrelated to any private reference course.
function config(extra = {}) {
  return {color: 'green', origin: {x: 32, y: 128}, path: [{id: 'snake-start', x: 0, y: 0}, {id: 'snake-finish', x: 256, y: 0}], lengthCells: 6, speedPxPerTick: 2, initialHeadDistancePx: 80, activation: 'player-top', endpointHoldFrames: 3, collapseIntervalFrames: 9, collapseGravity: .35, collapseFallCap: 6, collapseOrder: 'tail-to-head', ...extra};
}
function fixture({bound = false} = {}) {
  const d = blank('Neutral formal Snake Block authoring', 640, 384), r = d.rooms[0];
  r.map.geometry = [{id: 'floor', x: 0, y: 352, w: 640, h: 32, collision: 'solid', material: 'ground'}];
  r.map.objects = [{id: 'start', kind: 'spawn', x: 16, y: 338, w: 10, h: 14}, {id: 'finish', kind: 'exit', x: 608, y: 320, w: 16, h: 32}];
  if (bound) setSmm2SnakeBlockTrain(r, 'snake', config());
  return d;
}
function leafRoom(definitions = [{id: 'snake', ...config()}]) {
  const r = fixture().rooms[0]; r.smm2Mechanics = {version: 1, snakeBlocks: {version: 1, trains: definitions}}; return r;
}
const roundtrip = h => assert.deepEqual(parseProject(JSON.stringify(h.doc)), h.doc);

test('formal native train add, full edit, remapped clone and delete stay atomic through real History and strict qmap roundtrip', () => {
  const h = new History(fixture()), r = () => h.doc.rooms[0], native = structuredClone(r().map), authored = config();
  h.change(() => setSmm2SnakeBlockTrain(r(), 'snake', authored)); authored.origin.x = 512; authored.path[1].x = 32;
  assert.equal(r().smm2Mechanics.snakeBlocks.trains[0].origin.x, 32); assert.equal(r().smm2Mechanics.snakeBlocks.trains[0].path[1].x, 256);
  assert.deepEqual(r().map, native); roundtrip(h);
  h.change(() => setSmm2SnakeBlockTrain(r(), 'snake', config({color: 'blue', speedPxPerTick: .75, endpointHoldFrames: 0, collapseOrder: 'head-to-tail'})));
  assert.equal(r().smm2Mechanics.snakeBlocks.trains.length, 1);
  h.change(() => cloneSmm2SnakeBlockTrain(r(), 'snake', 'snake-copy', {x: 336, y: 128}));
  const [source, copy] = r().smm2Mechanics.snakeBlocks.trains;
  assert.deepEqual({...copy, id: source.id, origin: source.origin, path: copy.path.map((p, i) => ({...p, id: source.path[i].id}))}, source);
  assert(copy.path.every(p => !source.path.some(a => a.id === p.id))); assert.equal(new Set(copy.path.map(p => p.id)).size, copy.path.length);
  assert.deepEqual(copy.origin, {x: 336, y: 128}); assert.deepEqual(r().map, native); roundtrip(h);
  h.undo(); assert.equal(r().smm2Mechanics.snakeBlocks.trains.length, 1); h.redo(); assert.equal(r().smm2Mechanics.snakeBlocks.trains.length, 2);
  h.change(() => removeSmm2SnakeBlockTrain(r(), 'snake')); assert.equal(r().smm2Mechanics.snakeBlocks.trains[0].id, 'snake-copy'); h.undo(); assert.equal(r().smm2Mechanics.snakeBlocks.trains.length, 2); h.redo();
  h.change(() => removeSmm2SnakeBlockTrain(r(), 'snake-copy')); assert.equal(r().smm2Mechanics.snakeBlocks, undefined); assert.deepEqual(r().map, native); roundtrip(h);
  const count = h.undoStack.length; h.change(() => removeSmm2SnakeBlockTrain(r(), 'missing')); assert.equal(h.undoStack.length, count);
});

test('strict full configurations reject missing, hidden and invalid values without changing room or History stacks', () => {
  const h = new History(fixture({bound: true})), r = () => h.doc.rooms[0];
  h.change(() => setSmm2SnakeBlockTrain(r(), 'snake', config({speedPxPerTick: .5}))); h.undo();
  const before = JSON.stringify(h.doc), undos = h.undoStack.length, redos = h.redoStack.length, bad = [];
  for (const key of Object.keys(config())) {const q = config(); delete q[key]; bad.push(() => setSmm2SnakeBlockTrain(r(), 'snake', q));}
  for (const patch of [
    {color: 'red'}, {activation: 'nearby'}, {collapseOrder: 'together'}, {speedPxPerTick: 0}, {speedPxPerTick: Infinity}, {lengthCells: 2.5}, {initialHeadDistancePx: 79},
    {initialHeadDistancePx: 257}, {endpointHoldFrames: -1}, {endpointHoldFrames: 1.5}, {collapseIntervalFrames: 0}, {collapseGravity: NaN}, {collapseFallCap: 0},
    {origin: {x: -1, y: 128}}, {origin: {x: 32, y: 128, center: true}}, {path: [{id: 'a', x: 16, y: 0}, {id: 'b', x: 256, y: 0}]},
    {path: [{id: 'a', x: 0, y: 0}, {id: 'b', x: 256, y: 16}]}, {path: [{id: 'a', x: 0, y: 0}, {id: 'a', x: 256, y: 0}]},
    {path: [{id: 'a', x: 0, y: 0}, {id: 'b', x: 256, y: 0, player: true}]}, {script: 'move-player'}, {id: 'other'}
  ]) bad.push(() => setSmm2SnakeBlockTrain(r(), 'snake', {...config(), ...patch}));
  const symbolic = config(); symbolic[Symbol('unrecognized')] = 1; bad.push(() => setSmm2SnakeBlockTrain(r(), 'snake', symbolic));
  const nestedSymbol = config(); nestedSymbol.path[1][Symbol('unrecognized')] = 1; bad.push(() => setSmm2SnakeBlockTrain(r(), 'snake', nestedSymbol));
  const extraPathField = config(); extraPathField.path.hiddenInstruction = 'move-player'; bad.push(() => setSmm2SnakeBlockTrain(r(), 'snake', extraPathField));
  const sparsePath = config(); delete sparsePath.path[0]; bad.push(() => setSmm2SnakeBlockTrain(r(), 'snake', sparsePath));
  const inherited = Object.assign(Object.create({speedPxPerTick: 2}), config()); bad.push(() => setSmm2SnakeBlockTrain(r(), 'snake', inherited));
  bad.push(() => setSmm2SnakeBlockTrain(r(), 'start', config()));
  bad.push(() => cloneSmm2SnakeBlockTrain(r(), 'snake', 'snake', {x: 336, y: 128}));
  bad.push(() => cloneSmm2SnakeBlockTrain(r(), 'snake', 'snake-finish', {x: 336, y: 128}));
  bad.push(() => cloneSmm2SnakeBlockTrain(r(), 'snake', 'copy', {x: 336, y: 128, teleport: true}));
  for (const operation of bad) {assert.throws(() => h.change(operation)); assert.equal(JSON.stringify(h.doc), before); assert.equal(h.undoStack.length, undos); assert.equal(h.redoStack.length, redos);}
  const standalone = leafRoom(), saved = structuredClone(standalone); assert.throws(() => setSmm2SnakeBlockTrain(standalone, 'snake', config({origin: {x: 600, y: 128}}))); assert.deepEqual(standalone, saved);
  const hostile = leafRoom(); hostile.smm2Mechanics.snakeBlocks.trains[0].path[0][Symbol('hidden-field')] = 1;
  assert.throws(() => cloneSmm2SnakeBlockTrain(hostile, 'snake', 'copy', {x: 336, y: 128}), /Unknown/); assert.throws(() => captureSmm2SnakeBlockTrains(hostile, new Set(['snake'])), /Unknown/); assert.throws(() => removeSmm2SnakeBlockTrain(hostile, 'snake'), /Unknown/);
});

test('detached clipboard and cross-room paste remap every identifier and preserve relative path and saved fits in one transaction', () => {
  const source = leafRoom(), snapshot = captureSmm2SnakeBlockTrains(source, new Set(['snake'])), h = new History(fixture()), r = () => h.doc.rooms[0];
  const mapping = new Map();
  h.change(() => {for (const [a, b] of appendCopiedSmm2SnakeBlockTrains(r(), snapshot, {dx: 80, dy: 32})) mapping.set(a, b);});
  const copy = r().smm2Mechanics.snakeBlocks.trains[0]; assert.equal(mapping.get('snake'), copy.id); assert.notEqual(copy.id, 'snake'); assert.deepEqual(copy.origin, {x: 112, y: 160});
  assert(copy.path.every(p => !snapshot[0].path.some(q => q.id === p.id))); assert.deepEqual(copy.path.map(({id, ...p}) => p), snapshot[0].path.map(({id, ...p}) => p)); assert.equal(copy.speedPxPerTick, 2); roundtrip(h);
  snapshot[0].origin.x = 999; assert.equal(source.smm2Mechanics.snakeBlocks.trains[0].origin.x, 32);
  h.undo(); assert.equal(r().smm2Mechanics, undefined); h.redo(); assert.equal(r().smm2Mechanics.snakeBlocks.trains[0].id, copy.id); roundtrip(h);
});

test('strict collection save/reload and native compilation preserve the authored leaf without baking dynamic initial cells into permanent map geometry', () => {
  const source = fixture({bound: true}), collection = addLevel(createCollection('Neutral Snake authoring collection'), source, {id: 'snake-authoring'}), reloaded = parseCollection(serializeCollection(collection));
  const character = JSON.parse(fs.readFileSync(new URL('../atlas/runtime/character.json', import.meta.url), 'utf8')), built = buildCollection(reloaded, character, {includePending: true}), room = built.levels[0].rooms[0];
  assert.deepEqual(reloaded.levels[0].project.rooms[0].smm2Mechanics.snakeBlocks, source.rooms[0].smm2Mechanics.snakeBlocks);
  assert.deepEqual(room.smm2Mechanics.snakeBlocks, source.rooms[0].smm2Mechanics.snakeBlocks); assert.deepEqual(initialSmm2SnakeBlockGeometry(room), initialSmm2SnakeBlockGeometry(source.rooms[0]));
  assert(!built.levels[0].pack.maps[0].geometry.some(q => q.id.startsWith('smm2-snake-block:')));
});

test('malformed clipboard, duplicate sources and out-of-room translated path roll back the complete History operation', () => {
  const h = new History(fixture()), r = () => h.doc.rooms[0], snapshot = captureSmm2SnakeBlockTrains(leafRoom(), new Set(['snake']));
  const invalid = structuredClone(snapshot); invalid[0].path[1].x = 257;
  const duplicateWaypoint = structuredClone(snapshot); duplicateWaypoint[0].path[1].id = duplicateWaypoint[0].path[0].id;
  const invalidIdentifier = structuredClone(snapshot); invalidIdentifier[0].id = 'INVALID ID';
  for (const operation of [() => appendCopiedSmm2SnakeBlockTrains(r(), invalid, {dx: 0, dy: 0}), () => appendCopiedSmm2SnakeBlockTrains(r(), duplicateWaypoint, {dx: 0, dy: 0}), () => appendCopiedSmm2SnakeBlockTrains(r(), invalidIdentifier, {dx: 0, dy: 0}), () => appendCopiedSmm2SnakeBlockTrains(r(), [snapshot[0], snapshot[0]], {dx: 0, dy: 0}), () => appendCopiedSmm2SnakeBlockTrains(r(), snapshot, {dx: 600, dy: 0}), () => appendCopiedSmm2SnakeBlockTrains(r(), snapshot, {dx: 0, dy: 0, player: true})]) {
    const before = JSON.stringify(h.doc); assert.throws(() => h.change(() => {r().map.objects.push({id: 'temporary', kind: 'coin', x: 400, y: 64, w: 16, h: 16}); operation();})); assert.equal(JSON.stringify(h.doc), before); assert.equal(h.undoStack.length, 0);
  }
  assert.throws(() => captureSmm2SnakeBlockTrains(r(), ['snake']));
});

test('moving independent train origins keeps relative paths and rolls back invalid body or route coordinates', () => {
  const h = new History(fixture({bound: true})), r = () => h.doc.rooms[0], path = structuredClone(r().smm2Mechanics.snakeBlocks.trains[0].path);
  h.change(() => moveSmm2SnakeBlockTrains(r(), new Set(['snake']), 48, -32)); assert.deepEqual(r().smm2Mechanics.snakeBlocks.trains[0].origin, {x: 80, y: 96}); assert.deepEqual(r().smm2Mechanics.snakeBlocks.trains[0].path, path); roundtrip(h);
  h.undo(); assert.equal(r().smm2Mechanics.snakeBlocks.trains[0].origin.x, 32); h.redo();
  const before = JSON.stringify(h.doc), undos = h.undoStack.length;
  for (const [dx, dy] of [[600, 0], [0, -128], [NaN, 0]]) {assert.throws(() => h.change(() => moveSmm2SnakeBlockTrains(r(), new Set(['snake']), dx, dy))); assert.equal(JSON.stringify(h.doc), before); assert.equal(h.undoStack.length, undos);}
});

test('mixed native and train movement validates the final group, preserves train order and rolls back both bodies', () => {
  const d = fixture({bound: true}), r0 = d.rooms[0];
  r0.map.geometry.push({id: 'adjacent', x: 16, y: 128, w: 16, h: 16, collision: 'solid', material: 'stone'});
  setSmm2SnakeBlockTrain(r0, 'other', config({origin: {x: 336, y: 192}, path: [{id: 'other-start', x: 0, y: 0}, {id: 'other-end', x: 256, y: 0}]}));
  const h = new History(d), r = () => h.doc.rooms[0], originalPath = structuredClone(r().smm2Mechanics.snakeBlocks.trains[0].path), ids = new Set(['snake', 'adjacent']);
  h.change(() => moveSmm2SnakeBlockSelection(r(), 'geometry', ids, 16, 0));
  assert.deepEqual(r().smm2Mechanics.snakeBlocks.trains.map(q => q.id), ['snake', 'other']);
  assert.deepEqual(r().smm2Mechanics.snakeBlocks.trains[0].origin, {x: 48, y: 128});
  assert.deepEqual(r().smm2Mechanics.snakeBlocks.trains[0].path, originalPath);
  assert.equal(r().map.geometry.find(q => q.id === 'adjacent').x, 32, 'native block can enter the selected train’s vacated cell');
  const before = JSON.stringify(h.doc), undos = h.undoStack.length;
  assert.throws(() => h.change(() => moveSmm2SnakeBlockSelection(r(), 'geometry', ids, 0, 224)), /permanent solid/);
  assert.equal(JSON.stringify(h.doc), before); assert.equal(h.undoStack.length, undos);
  h.undo(); assert.equal(r().map.geometry.find(q => q.id === 'adjacent').x, 16); assert.equal(r().smm2Mechanics.snakeBlocks.trains[0].origin.x, 32);
  h.redo(); roundtrip(h);
});

test('initial layout uses exact full 16px controller collision and stays detached, including a fractional initial occupied window', () => {
  const r = leafRoom(), before = structuredClone(r), geometry = initialSmm2SnakeBlockGeometry(r);
  assert.deepEqual(geometry, createSmm2SnakeBlocks(r).geometry()); assert.equal(geometry.length, 6); assert(geometry.every(q => q.w === 16 && q.h === 16 && q.collision === 'solid'));
  geometry[0].x = 900; assert.deepEqual(r, before); assert.equal(initialSmm2SnakeBlockGeometry(r)[0].x, 32);
  const fractional = leafRoom([{id: 'fractional', ...config({initialHeadDistancePx: 80.5})}]); assert.equal(initialSmm2SnakeBlockGeometry(fractional).length, 7); assert.doesNotThrow(() => validateSmm2SnakeBlockPlacement(fractional));
  assert.deepEqual(initialSmm2SnakeBlockGeometry(fixture().rooms[0]), []);
});

test('permanent initial overlap is rejected at every solid face, with pure actionable issues and atomic standalone authoring', () => {
  for (const solid of [
    {id: 'initial-solid', x: 32, y: 128, w: 16, h: 16}, {id: 'lower-body', x: 32, y: 139, w: 16, h: 4}, {id: 'side-body', x: 45, y: 128, w: 4, h: 16}
  ]) {
    const r = leafRoom(); r.map.geometry.push({...solid, collision: 'solid', material: 'stone'}); const before = structuredClone(r);
    const issues = smm2SnakeBlockPlacementIssues(r); assert.equal(issues.length, 1); assert.equal(issues[0].code, 'SNAKE_INITIAL_SOLID_OVERLAP'); assert.deepEqual(issues[0].ids, ['snake', solid.id]); assert.throws(() => validateSmm2SnakeBlockPlacement(r), /permanent solid/); assert.deepEqual(r, before);
    const empty = fixture().rooms[0]; empty.map.geometry.push({...solid, collision: 'solid', material: 'stone'}); const saved = structuredClone(empty); assert.throws(() => setSmm2SnakeBlockTrain(empty, 'snake', config()), /permanent solid/); assert.deepEqual(empty, saved);
  }
});

test('edge-seated coins, doors and spawn remain legal, while independent objects inside the actual initial collision are rejected', () => {
  const r = leafRoom(); r.map.objects.push({id: 'above-coin', kind: 'coin', x: 32, y: 112, w: 16, h: 16}, {id: 'aboard-spawn', kind: 'spawn', x: 51, y: 114, w: 10, h: 14}, {id: 'seated-door', kind: 'portal', x: 80, y: 96, w: 16, h: 32, targetRoom: 'main', targetSpawn: 'start'});
  assert.doesNotThrow(() => validateSmm2SnakeBlockPlacement(r)); assert.doesNotThrow(() => validate({...fixture(), rooms: [r]}));
  for (const kind of ['coin', 'spawn', 'portal', 'exit', 'checkpoint', 'key']) {const q = leafRoom(); q.map.objects.push({id: 'embedded-' + kind, kind, x: 35, y: 139, w: 8, h: 8}); assert.throws(() => validateSmm2SnakeBlockPlacement(q), /independent native/);}
  const item = leafRoom(); item.map.objects.push({id: 'placed-item', kind: 'walker', x: 32, y: 128, w: 16, h: 16}); item.smm2Mechanics.placedItems = [{id: 'placed-item', kind: 'mushroom', gravity: .3, maxFallSpeed: 4}]; assert.throws(() => validateSmm2SnakeBlockPlacement(item), /native mushroom/);
});

test('dynamic-only overlaps, one-way crossings and future-route interactions stay authorable; legal block contents do not become independent coins', () => {
  for (const terrain of [
    {id: 'moving', collision: 'solid', motion: {axis: 'x', min: 0, max: 64, speed: 1}}, {id: 'hidden', collision: 'solid', hidden: true}, {id: 'crossing', collision: 'oneway'}
  ]) {const r = leafRoom(); r.map.geometry.push({x: 32, y: 128, w: 16, h: 16, material: 'stone', ...terrain}); assert.doesNotThrow(() => validateSmm2SnakeBlockPlacement(r));}
  const r = leafRoom(); r.map.geometry.push({id: 'future-solid', x: 240, y: 128, w: 16, h: 16, collision: 'solid', material: 'brick', content: 'coin'}); r.map.objects.push({id: 'future-coin', kind: 'coin', x: 272, y: 128, w: 16, h: 16}, {id: 'dynamic-enemy', kind: 'walker', x: 32, y: 128, w: 16, h: 16}, {id: 'dynamic-hazard', kind: 'hazard', x: 48, y: 128, w: 16, h: 16});
  assert.doesNotThrow(() => validateSmm2SnakeBlockPlacement(r)); assert.doesNotThrow(() => validate({...fixture(), rooms: [r]}));
  const crossing = leafRoom([{id: 'east-train', ...config()}, {id: 'south-train', ...config({origin: {x: 240, y: 32}, path: [{id: 'south-start', x: 0, y: 0}, {id: 'south-end', x: 0, y: 256}]})}]);
  assert.doesNotThrow(() => validateSmm2SnakeBlockPlacement(crossing), 'interactions between future occupied windows are authored dynamics, not an initial overlap'); assert.doesNotThrow(() => validate({...fixture(), rooms: [crossing]}));
});

test('initial Snake placement follows exact triangle and finite-strip slope polygons, preserving legal empty bounding-box space', () => {
  const triangle = {id: 'triangle', x: 80, y: 64, w: 80, h: 80, orientation: 'rise-right', collision: 'solid'};
  const empty = leafRoom([{id: 'snake', ...config({origin: {x: 80, y: 64}, lengthCells: 2, initialHeadDistancePx: 16})}]); empty.smm2Mechanics.slopes = [triangle]; assert.doesNotThrow(() => validateSmm2SnakeBlockPlacement(empty));
  const inside = leafRoom([{id: 'snake', ...config({origin: {x: 136, y: 96}, lengthCells: 2, initialHeadDistancePx: 16})}]); inside.smm2Mechanics.slopes = [triangle]; assert.throws(() => validateSmm2SnakeBlockPlacement(inside), /permanent slope/);
  const strip = leafRoom([{id: 'snake', ...config({origin: {x: 112, y: 128}, lengthCells: 2, initialHeadDistancePx: 16})}]); strip.smm2Mechanics.slopes = [{...triangle, thickness: 4}]; assert.doesNotThrow(() => validateSmm2SnakeBlockPlacement(strip), 'the space below a finite diagonal strip is not a solid triangle');
  strip.smm2Mechanics.snakeBlocks.trains[0].origin.y = 96; assert.throws(() => validateSmm2SnakeBlockPlacement(strip), /permanent slope/);
});

test('another train and actual Cloud native seat reject initial overlap while the cloud visual overhang remains legal', () => {
  const trains = leafRoom([{id: 'snake', ...config()}, {id: 'snake-two', ...config({origin: {x: 96, y: 128}})}]); assert.throws(() => validateSmm2SnakeBlockPlacement(trains), /another train/);
  trains.smm2Mechanics.snakeBlocks.trains[1].origin.y = 144; assert.doesNotThrow(() => validateSmm2SnakeBlockPlacement(trains));
  const cloud = {id: 'cloud', x: 28, y: 132, w: 20, h: 16, acceleration: .16, maxSpeed: 2, drag: .125, seatOffsetY: -4, boardTolerance: 2, hoverAmplitude: 0, hoverPeriodFrames: 120}, r = leafRoom(); r.smm2Mechanics.lakituClouds = {version: 1, clouds: [cloud]}; assert.throws(() => validateSmm2SnakeBlockPlacement(r), /native passenger seat/);
  cloud.x = 13; assert.doesNotThrow(() => validateSmm2SnakeBlockPlacement(r), 'visible right overhang enters the Snake cell but the passenger ends at x=28');
});

test('global import and native terrain/object placement use the same initial Snake-body gate and roll back conflicting edits', () => {
  const h = new History(fixture({bound: true})), r = () => h.doc.rooms[0], before = JSON.stringify(h.doc), undos = h.undoStack.length;
  assert.throws(() => h.change(() => paint(r(), {x: 32, y: 128, w: 16, h: 16}, 'stone')), /Snake Block initial collision/); assert.equal(JSON.stringify(h.doc), before); assert.equal(h.undoStack.length, undos);
  const malformed = structuredClone(h.doc); malformed.rooms[0].map.objects.push({id: 'embedded-coin', kind: 'coin', x: 48, y: 139, w: 8, h: 4}); assert.throws(() => parseProject(JSON.stringify(malformed)), /Snake Block initial collision/);
  h.change(() => r().map.objects.push({id: 'nearby-coin', kind: 'coin', x: 48, y: 112, w: 8, h: 16})); const seated = JSON.stringify(h.doc), count = h.undoStack.length;
  assert.throws(() => h.change(() => moveSelection(r(), 'objects', new Set(['nearby-coin']), 0, 2)), /Snake Block initial collision/); assert.equal(JSON.stringify(h.doc), seated); assert.equal(h.undoStack.length, count); roundtrip(h);
});

test('actual shared panel edits all saved fits and waypoint JSON, clones saved configuration, and follows delete, undo, redo and selection', () => {
  const ui = installSimulatedPlayDom();
  try {
    const h = new History(fixture()), r = () => h.doc.rooms[0], parent = ui.document.createElement('aside'), reports = []; let selected = new Set();
    const panel = mountSmm2SnakeBlockTools({parent, room: r, selected: () => selected, select: ids => {selected = ids;}, change: fn => h.change(fn), report: q => reports.push(q)}), get = key => parent.querySelector('[data-snake-block-tool="' + key + '"]');
    assert.match(parent.textContent, /显式作者配置/); assert.match(parent.textContent, /第一路径格左上角/);
    get('id').value = 'snake-ui'; get('color').value = 'blue'; get('origin-x').value = '112'; get('origin-y').value = '128'; get('lengthCells').value = '5'; get('speedPxPerTick').value = '.5'; get('initialHeadDistancePx').value = '64'; get('endpointHoldFrames').value = '0'; get('collapseIntervalFrames').value = '4'; get('collapseGravity').value = '.4'; get('collapseFallCap').value = '5'; get('collapseOrder').value = 'head-to-tail';
    const path = [{id: 'ui-start', x: 0, y: 0}, {id: 'ui-rise', x: 128, y: 0}, {id: 'ui-finish', x: 128, y: -64}]; get('path').value = JSON.stringify(path); panel.refresh(); assert.equal(get('speedPxPerTick').value, '.5', 'refresh preserves unsaved visible form edits'); get('apply').click();
    let source = r().smm2Mechanics.snakeBlocks.trains[0]; assert.equal(source.id, 'snake-ui'); assert.deepEqual(source.path, path); assert.deepEqual(source.origin, {x: 112, y: 128}); assert.equal(source.speedPxPerTick, .5); assert.equal(source.lengthCells, 5); assert.equal(source.endpointHoldFrames, 0); assert.equal(source.collapseIntervalFrames, 4); assert.equal(source.collapseGravity, .4); assert.equal(source.collapseFallCap, 5); assert.equal(source.collapseOrder, 'head-to-tail'); assert.deepEqual([...selected], ['snake-ui']); assert.equal(get('id').readOnly, true); roundtrip(h);
    get('speedPxPerTick').value = '.75'; get('apply').click(); source = structuredClone(r().smm2Mechanics.snakeBlocks.trains[0]);
    get('speedPxPerTick').value = '7'; get('clone-id').value = 'snake-ui-copy'; get('clone-x').value = '336'; get('clone-y').value = '192'; get('clone').click();
    const copy = r().smm2Mechanics.snakeBlocks.trains[1]; assert.equal(copy.speedPxPerTick, .75, 'clone reads saved controller fits'); assert.equal(copy.id, 'snake-ui-copy'); assert(copy.path.every(p => !source.path.some(q => p.id === q.id))); assert.equal(get('train').value, copy.id); assert.deepEqual([...selected], [copy.id]);
    const saved = JSON.stringify(h.doc), undos = h.undoStack.length; get('collapseGravity').value = ''; get('apply').click(); assert.equal(JSON.stringify(h.doc), saved); assert.equal(h.undoStack.length, undos); assert.match(reports.at(-1), /请填写/); assert.equal(get('collapseGravity').value, '0.4');
    get('path').value = '[broken'; get('apply').click(); assert.equal(JSON.stringify(h.doc), saved); assert.equal(h.undoStack.length, undos); assert.equal(get('path').value, JSON.stringify(copy.path, null, 2));
    get('remove').click(); assert.equal(r().smm2Mechanics.snakeBlocks.trains.length, 1); h.undo(); panel.refresh(); assert.equal(r().smm2Mechanics.snakeBlocks.trains.length, 2); h.redo(); panel.refresh(); assert.equal(r().smm2Mechanics.snakeBlocks.trains.length, 1);
    selected = new Set(['snake-ui']); panel.refresh(); assert.equal(get('train').value, 'snake-ui'); assert.equal(get('speedPxPerTick').value, '0.75'); get('new').click(); assert.equal(get('id').readOnly, false); assert.equal(get('remove').disabled, true); assert.equal(get('activation').value, 'player-top'); roundtrip(h);
  } finally {ui.restore();}
});

test('full editor mounts formal Snake tools and saves, exports and reloads the exact native leaf through real document handlers', async () => {
  const ui = installSimulatedPlayDom(), globals = new Map();
  const install = (key, value) => {globals.set(key, Object.getOwnPropertyDescriptor(globalThis, key)); Object.defineProperty(globalThis, key, {value, writable: true, configurable: true});};
  try {
    const initial = fixture({bound: true}); initial.rooms[0].map.geometry.push({id: 'mixed-selection-block', x: 192, y: 128, w: 16, h: 16, collision: 'solid', material: 'stone'});
    const storage = new Map([['xiaoq-map-workshop-tools-v1', JSON.stringify(initial)]]), exports = [];
    install('localStorage', {getItem: key => storage.get(key) || null, setItem: (key, value) => storage.set(key, value)}); install('devicePixelRatio', 1); install('ResizeObserver', class {observe() {}}); install('setTimeout', () => 1); install('clearTimeout', () => {}); install('confirm', () => true);
    const nativeURL = globalThis.URL; install('URL', class extends nativeURL {static createObjectURL(blob) {exports.push(blob); return 'blob:verified-snake-export';} static revokeObjectURL() {}});
    ui.Element.prototype.closest = function (selector) {for (let node = this; node; node = node.parentNode) if (selector.split(',').some(q => q === node.tag || q === '.' + node.className || q === '#' + node.id)) return node; return null;};
    ui.Element.prototype.removeAttribute = function (key) {delete this.attributes[key];}; ui.Element.prototype.after = function (node) {const parent = this.parentNode; node.parentNode = parent; parent.children.splice(parent.children.indexOf(this) + 1, 0, node);};
    const html = fs.readFileSync(new URL('../atlas/editor.html', import.meta.url), 'utf8'); ui.document.body.innerHTML = html.match(/<body[^>]*>([\s\S]*?)<\/body>/)[1];
    for (const node of ui.document.body.querySelectorAll('input')) {node.value = node.getAttribute('value') || ''; node.checked = node.getAttribute('checked') !== undefined;}
    for (const node of ui.document.body.querySelectorAll('select')) {const options = node.querySelectorAll('option'), choice = options.find(q => q.getAttribute('selected') !== undefined) || options[0]; node.value = choice?.getAttribute('value') || '';}
    const get = id => ui.document.getElementById(id); get('viewport').clientWidth = 640; get('viewport').clientHeight = 384; get('canvas').getBoundingClientRect = () => ({left: 0, top: 0}); get('zoom').value = '1';
    await import('../atlas/editor.mjs?formal-snake-native-authoring-entry');
    const control = key => ui.document.querySelector('[data-snake-block-tool="' + key + '"]'), saved = () => {get('save').click(); return JSON.parse(storage.get('xiaoq-map-workshop-tools-v1'));};
    assert(control('apply'), 'formal Snake tool panel is mounted by the native editor'); assert.equal(control('train').value, 'snake'); assert.equal(control('speedPxPerTick').value, '2');
    control('speedPxPerTick').value = '.5'; control('endpointHoldFrames').value = '7'; control('apply').click(); control('clone-id').value = 'native-snake-copy'; control('clone-x').value = '336'; control('clone-y').value = '128'; control('clone').click();
    let document = saved(), definitions = document.rooms[0].smm2Mechanics.snakeBlocks.trains; assert.equal(definitions.length, 2); assert.equal(definitions[0].speedPxPerTick, .5); assert.equal(definitions[1].speedPxPerTick, .5); assert.equal(definitions[1].endpointHoldFrames, 7); assert(definitions[1].path.every(p => !definitions[0].path.some(q => q.id === p.id))); assert.equal(document.rooms[0].map.objects.length, 2);
    control('remove').click(); assert.equal(saved().rooms[0].smm2Mechanics.snakeBlocks.trains.length, 1); get('undo').click(); assert.equal(saved().rooms[0].smm2Mechanics.snakeBlocks.trains.length, 2); get('redo').click(); assert.equal(saved().rooms[0].smm2Mechanics.snakeBlocks.trains.length, 1); get('undo').click();
    get('layer').value = 'geometry'; get('layer').dispatchEvent({type: 'change'}); get('tools').children.find(q => q.textContent === '框选 V').click();
    const point = (type, x, y) => get('canvas').dispatchEvent({type, button: 0, pointerId: 1, clientX: x, clientY: y}); point('pointerdown', 36, 132); point('pointerup', 36, 132); get('copy').click(); get('paste').click();
    document = saved(); definitions = document.rooms[0].smm2Mechanics.snakeBlocks.trains; assert.equal(definitions.length, 3, 'real canvas selection and native copy/paste copy the independent train leaf');
    let pasted = definitions.find(q => !['snake', 'native-snake-copy'].includes(q.id)); assert(pasted); assert.deepEqual(pasted.origin, {x: 16, y: 16}); assert.equal(pasted.speedPxPerTick, .5); assert(pasted.path.every(p => !definitions[0].path.some(q => q.id === p.id))); assert.equal(control('train').value, pasted.id, 'native paste keeps the copied train selected through refresh');
    get('x').value = '32'; get('y').value = '48'; get('position').dispatchEvent({type: 'submit'}); document = saved(); pasted = document.rooms[0].smm2Mechanics.snakeBlocks.trains.find(q => q.id === pasted.id); assert.deepEqual(pasted.origin, {x: 32, y: 48}, 'native position form moves the saved origin');
    ui.document.dispatchEvent({type: 'keydown', key: 'ArrowRight', code: 'ArrowRight', target: ui.document.body}); assert.deepEqual(saved().rooms[0].smm2Mechanics.snakeBlocks.trains.find(q => q.id === pasted.id).origin, {x: 48, y: 48}, 'native keyboard arrows translate the train leaf'); get('undo').click();
    point('pointerdown', 36, 52); point('pointermove', 52, 68); point('pointerup', 52, 68); document = saved(); pasted = document.rooms[0].smm2Mechanics.snakeBlocks.trains.find(q => q.id === pasted.id); assert.deepEqual(pasted.origin, {x: 48, y: 64}, 'native drag translates the train without changing relative waypoints');
    const beforeRejectedMove = document;
    get('x').value = '48'; get('y').value = '352'; get('position').dispatchEvent({type: 'submit'}); assert.deepEqual(saved(), beforeRejectedMove); assert.match(get('message').textContent, /permanent solid/);
    point('pointerdown', 52, 68); point('pointermove', 52, 356); point('pointerup', 52, 356); assert.deepEqual(saved(), beforeRejectedMove); assert.match(get('message').textContent, /permanent solid/);
    get('undo').click(); assert.deepEqual(saved().rooms[0].smm2Mechanics.snakeBlocks.trains.find(q => q.id === pasted.id).origin, {x: 32, y: 48}, 'rejected gestures add no History entries'); get('redo').click();
    get('delete').click(); assert.equal(saved().rooms[0].smm2Mechanics.snakeBlocks.trains.length, 2); get('undo').click(); assert.equal(saved().rooms[0].smm2Mechanics.snakeBlocks.trains.length, 3); get('redo').click(); document = saved(); assert.equal(document.rooms[0].smm2Mechanics.snakeBlocks.trains.length, 2);
    point('pointerdown', 36, 132); point('pointermove', 204, 140); point('pointerup', 204, 140); get('copy').click(); get('paste').click(); document = saved();
    assert.equal(document.rooms[0].smm2Mechanics.snakeBlocks.trains.length, 3, 'mixed native terrain and independent train selection copies both');
    const mixedTrain = document.rooms[0].smm2Mechanics.snakeBlocks.trains.find(q => !['snake', 'native-snake-copy'].includes(q.id)), mixedBlock = document.rooms[0].map.geometry.find(q => !['floor', 'mixed-selection-block'].includes(q.id));
    assert(mixedTrain && mixedBlock); assert.deepEqual(mixedTrain.origin, {x: 16, y: 16}); assert.deepEqual({x: mixedBlock.x, y: mixedBlock.y}, {x: 176, y: 16}, 'native geometry and train share the same paste translation');
    const beforeRejectedPaste = document; get('viewport').dispatchEvent({type: 'wheel', deltaX: 608, deltaY: 0}); get('paste').click(); assert.deepEqual(saved(), beforeRejectedPaste, 'out-of-room mixed paste rolls back both the native array and train leaf'); get('viewport').dispatchEvent({type: 'wheel', deltaX: -608, deltaY: 0});
    get('delete').click(); assert.equal(saved().rooms[0].smm2Mechanics.snakeBlocks.trains.length, 2); assert.equal(saved().rooms[0].map.geometry.length, 2); get('undo').click(); assert.equal(saved().rooms[0].smm2Mechanics.snakeBlocks.trains.length, 3); assert.equal(saved().rooms[0].map.geometry.length, 3); get('redo').click(); document = saved();
    get('export').click(); assert.equal(exports.length, 1); const text = await exports[0].text(); assert.deepEqual(parseProject(text), document);
    control('train').value = 'snake'; control('train').dispatchEvent({type: 'change'}); control('speedPxPerTick').value = '1'; control('apply').click(); assert.equal(saved().rooms[0].smm2Mechanics.snakeBlocks.trains[0].speedPxPerTick, 1);
    get('file').files = [{size: new Blob([text]).size, text: async () => text}]; await get('file').onchange(); assert.deepEqual(saved(), document); assert.equal(Number(control('speedPxPerTick').value), .5); assert.equal(control('path').value, JSON.stringify(document.rooms[0].smm2Mechanics.snakeBlocks.trains[0].path, null, 2));
    const invalidImport = structuredClone(document); invalidImport.rooms[0].smm2Mechanics.snakeBlocks.trains[0].path[1].y = 16; const invalidText = JSON.stringify(invalidImport); get('file').files = [{size: new Blob([invalidText]).size, text: async () => invalidText}]; await get('file').onchange(); assert.deepEqual(saved(), document, 'invalid imported paths leave the native document unchanged');
    const leftward = fixture(); setSmm2SnakeBlockTrain(leftward.rooms[0], 'leftward', config({origin: {x: 112, y: 128}, path: [{id: 'leftward-start', x: 0, y: 0}, {id: 'leftward-end', x: -64, y: 0}], lengthCells: 4, initialHeadDistancePx: 64})); leftward.rooms[0].map.geometry.push({id: 'leftward-block', x: 192, y: 128, w: 16, h: 16, collision: 'solid', material: 'stone'});
    const leftwardText = JSON.stringify(leftward); get('file').files = [{size: new Blob([leftwardText]).size, text: async () => leftwardText}]; await get('file').onchange();
    point('pointerdown', 52, 132); point('pointermove', 204, 140); point('pointerup', 204, 140); get('copy').click(); get('paste').click();
    const bounded = saved().rooms[0], boundedTrain = bounded.smm2Mechanics.snakeBlocks.trains.find(q => q.id !== 'leftward'), boundedBlock = bounded.map.geometry.find(q => !['floor', 'leftward-block'].includes(q.id));
    assert.deepEqual(boundedTrain.origin, {x: 80, y: 16}, 'paste anchor follows actual occupied cells rather than an unoccupied train origin'); assert.deepEqual({x: boundedBlock.x, y: boundedBlock.y}, {x: 160, y: 16});
    const underwater = fixture(), waterRoom = underwater.rooms[0]; waterRoom.setting = 'Underwater'; waterRoom.underwater = true; waterRoom.aquatic = {version: 1, contactBodies: 'smm2-solid-actors'}; waterRoom.smm2Mechanics = {version: 1, art: {palette: 'smw-underwater-source'}};
    Object.assign(waterRoom.map.objects.find(q => q.kind === 'exit'), {x: 400, y: 48, w: 48, h: 144}); waterRoom.map.objects.push({id: 'fish', kind: 'walker', x: 128, y: 128, w: 16, h: 16});
    waterRoom.map.geometry.push({id: 'cannon', x: 240, y: 128, w: 16, h: 32, collision: 'solid', material: 'cannon'});
    const underwaterText = JSON.stringify(underwater); get('file').files = [{size: new Blob([underwaterText]).size, text: async () => underwaterText}]; await get('file').onchange();
    const goal = key => ui.document.querySelector('[data-smw-goal="' + key + '"]'), actor = key => ui.document.querySelector('[data-underwater-actor="' + key + '"]');
    assert(goal('apply') && actor('apply'), 'native editor mounts Goal Tape and underwater actor panels'); goal('apply').click(); assert.equal(saved().rooms[0].smm2Mechanics.goalTape.id, 'finish');
    actor('kind').value = 'fish-bone'; actor('kind').dispatchEvent({type: 'change'});
    const fishMotion = {cruiseVx: -.5, alertRadius: 64, alertFrames: 3, aimSample: 'alert-start', chargeInitialSpeed: .4, chargeAcceleration: .2, chargeMaxSpeed: 8, blueContactPolicy: 'reverse'};
    for (const [key, value] of Object.entries(fishMotion)) actor('fish-bone-' + key).value = String(value); actor('apply').click();
    assert.deepEqual(saved().rooms[0].smm2Mechanics.underwaterActors.profiles, [{id: 'fish', kind: 'fish-bone', motion: fishMotion}]);
    get('undo').click(); assert.equal(saved().rooms[0].smm2Mechanics.underwaterActors, undefined); get('redo').click(); assert.deepEqual(saved().rooms[0].smm2Mechanics.underwaterActors.profiles[0].motion, fishMotion);
    get('layer').value = 'objects'; get('layer').dispatchEvent({type: 'change'}); point('pointerdown', 132, 132); point('pointerup', 132, 132); get('copy').click(); get('paste').click();
    const copiedFish = saved().rooms[0].smm2Mechanics.underwaterActors.profiles.find(q => q.id !== 'fish'); assert(copiedFish); assert.deepEqual(copiedFish.motion, fishMotion); assert(saved().rooms[0].map.objects.some(q => q.id === copiedFish.id));
    get('delete').click(); assert.equal(saved().rooms[0].smm2Mechanics.underwaterActors.profiles.length, 1); get('undo').click(); assert.equal(saved().rooms[0].smm2Mechanics.underwaterActors.profiles.length, 2); get('redo').click();
    point('pointerdown', 132, 132); point('pointerup', 132, 132); get('delete').click(); assert.equal(saved().rooms[0].smm2Mechanics.underwaterActors, undefined); get('undo').click(); assert.equal(saved().rooms[0].smm2Mechanics.underwaterActors.profiles[0].id, 'fish'); get('redo').click();
    actor('launcher-id').value = 'cannon-shells'; actor('launcher-cannon').value = 'cannon'; actor('launcher-direction').value = 'right';
    for (const [key, value] of Object.entries({'muzzle-x': 16, 'muzzle-y': 16, intervalFrames: 120, initialDelayFrames: 0, maxAlive: 1, maxEmissions: 2, activationDistance: 320, vx: .5, vy: 0, emergenceFrames: 8})) actor('launcher-' + key).value = String(value); actor('launcher-apply').click();
    assert.equal(saved().rooms[0].marioModules.enemySources[0].launcherId, 'cannon'); actor('target').value = 'sourceId:cannon-shells'; actor('target').dispatchEvent({type: 'change'}); actor('kind').value = 'beetle-shell'; actor('kind').dispatchEvent({type: 'change'});
    const shellMotion = {initialVx: .5, initialVy: 0, gravity: .01, maxFallSpeed: 3, horizontalRestitution: 1}; for (const [key, value] of Object.entries(shellMotion)) actor('beetle-shell-' + key).value = String(value); actor('apply').click();
    get('layer').value = 'geometry'; get('layer').dispatchEvent({type: 'change'}); point('pointerdown', 244, 132); point('pointerup', 244, 132); get('copy').click(); get('paste').click();
    const copiedWater = saved().rooms[0], copiedCannon = copiedWater.map.geometry.find(q => !['floor', 'cannon'].includes(q.id)), copiedSource = copiedWater.marioModules.enemySources.find(q => q.id !== 'cannon-shells'); assert(copiedCannon && copiedSource); assert.equal(copiedSource.launcherId, copiedCannon.id); assert.deepEqual(copiedWater.smm2Mechanics.underwaterActors.profiles.find(q => q.sourceId === copiedSource.id).motion, shellMotion);
    get('delete').click(); assert.equal(saved().rooms[0].marioModules.enemySources.length, 1); assert.equal(saved().rooms[0].smm2Mechanics.underwaterActors.profiles.length, 1); get('undo').click(); assert.equal(saved().rooms[0].marioModules.enemySources.length, 2); get('redo').click();
    get('layer').value = 'objects'; get('layer').dispatchEvent({type: 'change'});
    point('pointerdown', 404, 52); point('pointerup', 404, 52); get('delete').click(); assert.equal(saved().rooms[0].smm2Mechanics.goalTape, undefined); get('undo').click(); assert.equal(saved().rooms[0].smm2Mechanics.goalTape.id, 'finish'); get('redo').click(); assert.equal(saved().rooms[0].smm2Mechanics.goalTape, undefined);
  } finally {
    for (const [key, descriptor] of globals) {if (descriptor) Object.defineProperty(globalThis, key, descriptor); else delete globalThis[key];}
    ui.restore();
  }
});
