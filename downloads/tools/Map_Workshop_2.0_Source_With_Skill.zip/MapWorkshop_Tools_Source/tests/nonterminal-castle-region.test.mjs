import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
import {blank,History,parseProject,validate,runtimeMap} from '../atlas/editor-model.mjs';
import {createCastleController,castleFirebarNodes,validateCastleRoom} from '../atlas/editor-castle.mjs';
import {mountCastleTools,castleFirebarPreviews} from '../atlas/editor-castle-tools.mjs';
import {mountContraptionsEditor} from '../atlas/editor-contraptions-editor.mjs';
import {addContraptionDoorPair} from '../atlas/editor-contraptions-tools.mjs';
import {addSmm2BoneShell,addSmm2ManagedLiquid} from '../atlas/editor-smm2-bone-tools.mjs';
import {addSmm2Component} from '../atlas/editor-smm2-tools.mjs';
import {offlineFile} from '../atlas/editor-offline.mjs';
import {createCollection,addLevel,parseCollection,serializeCollection,buildCollection} from '../atlas/editor-collection.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';
import {character,nonterminalCastleProject,castleSession,runCastleReturn} from './fixtures/nonterminal-castle-native.mjs';

test('existing omitted finish roundtrips without an invented mode or derived exit and keeps configured firebars',()=>{
 const d=nonterminalCastleProject(),r=d.rooms[0],before=structuredClone(d);validate(d);assert.deepEqual(d,before);assert.deepEqual(parseProject(JSON.stringify(d)),d);
 assert.equal(Object.hasOwn(r.castle,'finish'),false);assert.equal(runtimeMap(r).objects.some(q=>q.kind==='exit'),false);
 const collection=addLevel(createCollection({id:'nonterminal-castle',title:'Neutral compatibility'}),d,{id:'return-region'}),saved=serializeCollection(collection);assert.deepEqual(parseCollection(saved),collection);const built=buildCollection(collection,character,{includePending:true});assert.equal(built.levels[0].pack.maps.length,2);assert.deepEqual(built.levels[0].rooms,d.rooms);assert(built.requiredCapabilities.includes('castle-components-v1'));assert(built.requiredCapabilities.includes('contraptions-v1'));assert.equal(serializeCollection(collection),saved);
 const c=createCastleController(r);assert.equal(c.finishView(),null);assert.equal(c.triggerFinish({player:{x:320,y:64,w:10,h:14,vy:0}}),null);assert.equal(c.stepFinish({tick:1}),null);
 assert.deepEqual(c.firebarNodes('bar'),castleFirebarPreviews(r)[0].nodes);c.stepFirebars({tick:1,cam:256});assert.deepEqual(c.firebarNodes('bar'),castleFirebarNodes(r.markers[1],r.castle.firebars.bar,1));assert.equal(c.finishView(),null);
});

test('nonterminal compatibility leaves all native ownership, body, layout and pair checks active',()=>{
 const mutations=[
  r=>r.smm2Mechanics.powBlocks=[],r=>r.smm2Mechanics.flagScore=true,r=>r.smm2Mechanics.shoes=[],r=>r.smm2Mechanics.pinkCoins.push({id:'pink'}),
  r=>r.smm2Mechanics.art.palette='smb1-snow',r=>r.setting='Overworld',r=>r.castle.boss={actorId:'boat'},r=>r.castle.flameSources=[],r=>r.castle.finish={variant:'none'},
  r=>r.markers.push({id:'axe',kind:'bridge-axe-finish',x:32,y:32}),r=>delete r.castle.firebars.bar,r=>r.castle.firebars.bar.periodFrames=0,
  r=>r.smm2Mechanics.boneShells[0].id='pink',r=>r.smm2Mechanics.boneShells[0].playingDead.dropThroughIds=['right-bank'],r=>r.smm2Mechanics.liquid.markerId='bar',r=>r.smm2Mechanics.pinkCoins[0].id='boat',
  r=>Object.assign(r.map.objects.find(q=>q.id==='pink'),{x:540,y:180}),r=>r.map.objects.push({id:'exit',kind:'exit',x:560,y:144,w:16,h:32}),
  r=>r.contraptions.notes=[],r=>r.contraptions.scene='desert',r=>r.contraptions.doors[0].style='key',r=>r.map.objects.find(q=>q.kind==='portal').w=32,
  r=>r.contraptions.doors[0].pairId='missing',r=>r.map.objects.find(q=>q.kind==='portal').targetSpawn='missing',r=>r.mechanics={},r=>r.aquatic={version:1},r=>r.playHero='bill',
 ];
 for(const [index,mutate]of mutations.entries()){const d=nonterminalCastleProject();mutate(d.rooms[0]);const before=structuredClone(d);assert.throws(()=>validate(d),undefined,'invalid combination '+index);assert.deepEqual(d,before);}
 const room=nonterminalCastleProject().rooms[0];room.contraptions.doors[0].style='key';assert.throws(()=>validateCastleRoom(room));
});

test('actual Castle controls and ordinary-door button author the supported room with History and strict reimport',()=>{
 const ui=installSimulatedPlayDom();try{
  const d=blank('Editable nonterminal Castle',384,224),r=d.rooms[0];r.setting='Castle';r.map.geometry=[{id:'floor',x:0,y:208,w:384,h:16,material:'castle',collision:'solid'}];r.smm2Mechanics={version:1,art:{palette:'smb1-castle-stone'}};r.castle={version:1};const hub=structuredClone(r);hub.roomId='hub';hub.map.id='hub';hub.setting='Overworld';delete hub.castle;hub.smm2Mechanics.art.palette='smb1-overworld-source';d.rooms.push(hub);
  const h=new History(d),room=()=>h.doc.rooms[0],parent=ui.document.createElement('aside'),reports=[];ui.document.body.append(parent);
  const tools=mountCastleTools({parent,room,change:fn=>h.change(fn),report:message=>reports.push(message)}),doors=mountContraptionsEditor({parent,room,getProject:()=>h.doc,change:fn=>h.change(fn),report:message=>reports.push(message)}),get=id=>parent.querySelector('[data-castle-control="'+id+'"]');
  get('firebar-id').value='new-bar';get('firebar-x').value='128';get('firebar-y').value='64';get('firebar-direction').value='cw';get('firebar-add').click();assert.equal(room().castle.firebars['new-bar'].direction,'cw');assert.equal(room().castle.finish,undefined);
  const target=parent.querySelectorAll('select').find(s=>s.children.some(o=>o.value==='hub'));assert(target);target.value='hub';const add=parent.querySelectorAll('button').find(b=>b.textContent==='+ 成对普通门');assert(add);add.click();assert.deepEqual(reports,[]);assert.equal(room().contraptions.doors[0].style,'plain');assert.deepEqual(Object.keys(room().contraptions).sort(),['doors','version']);assert(h.doc.rooms[1].contraptions.doors[0].style==='plain');assert.deepEqual(parseProject(JSON.stringify(h.doc)),h.doc);
  const done=structuredClone(h.doc);h.undo();tools.refresh();doors.refresh();assert.equal(room().contraptions,undefined);h.redo();assert.deepEqual(h.doc,done);
  const before=structuredClone(h.doc);assert.throws(()=>h.change(()=>addContraptionDoorPair(h.doc,'main','hub')));assert.deepEqual(h.doc,before,'default key pair remains rejected in a nonterminal Castle');
 }finally{ui.restore();}
});

test('native ordinary input rides rising lava, collects a physical pink, dismounts and returns without resetting global collection',()=>{
 const s=castleSession(),report=runCastleReturn(s);assert(report.liveSurfaceSamples>40);assert(s.events.some(e=>e.type==='smm2-liquid'&&e.event==='surface-limit'));assert(s.events.some(e=>e.type==='smm2-shoe'&&e.event==='board-empty'));assert.equal(s.view().castle.finish,null);
});

test('existing Bone, managed liquid and pink authoring APIs compose in the guarded Castle and reject a second token atomically',()=>{
 const d=nonterminalCastleProject({doors:false}),r=d.rooms[0];r.map.objects=r.map.objects.filter(q=>q.kind==='spawn');r.markers=r.markers.filter(q=>q.id!=='pool');delete r.smm2Mechanics.boneShells;delete r.smm2Mechanics.liquid;delete r.smm2Mechanics.pinkCoins;
 addSmm2BoneShell(r,{id:'created-boat',x:96,y:160});addSmm2ManagedLiquid(r,{markerId:'created-pool',x:128,w:384,minY:176,maxY:192,initialY:192,speed:.5});addSmm2Component(r,'pinkCoin',{id:'created-pink',x:400,y:150});
 addContraptionDoorPair(d,'main','hub',{source:{x:592,y:144},target:{x:32,y:144},style:'plain'});assert.deepEqual(parseProject(JSON.stringify(d)),d);assert.equal(d.rooms[0].castle.finish,undefined);
 const before=structuredClone(d.rooms[0]);assert.throws(()=>addSmm2Component(d.rooms[0],'pinkCoin',{x:440,y:150}));assert.deepEqual(d.rooms[0],before);
});

test('standalone embedded source repeats the complete native return route with identical state and events and no network',async()=>{
 const s=castleSession(),root=new URL('../atlas/',import.meta.url),html=await offlineFile(s.pack,s.doc.rooms,p=>fs.promises.readFile(new URL(p,root),'utf8'),p=>fs.promises.readFile(new URL('assets/classic-audio/'+p,root))),dir=fs.mkdtempSync(path.join(os.tmpdir(),'Nonterminal Castle Offline ')),htmlPath=path.join(dir,'fixture.html');
 try{
  fs.writeFileSync(htmlPath,html);const checkPath=fileURLToPath(new URL('../scripts/check-offline-html.mjs',import.meta.url)),fixturePath=fileURLToPath(new URL('./fixtures/nonterminal-castle-native.mjs',import.meta.url));
  const script=`
   import fs from 'node:fs';import assert from 'node:assert/strict';import {createContext,SourceTextModule,runInContext} from 'node:vm';
   import {inspectOfflineHtml} from ${JSON.stringify(checkPath)};import {castleSession,runCastleReturn} from ${JSON.stringify(fixturePath)};
   const checked=inspectOfflineHtml(fs.readFileSync(process.argv[1],'utf8'));let networkRequests=0;
   const context=createContext({console,URL,TextEncoder,TextDecoder,Uint8Array,structuredClone,crypto:globalThis.crypto,fetch(){networkRequests++;throw Error('Offline network access');}}),modules=new Map();
   for(const [id,source]of checked.modules)modules.set(id,new SourceTextModule(source,{context,identifier:id}));
   const stage=modules.get('workshop/editor-mario-stage.mjs'),motor=modules.get('workshop/editor-mario-motor.mjs'),link=id=>{assert(modules.has(id),id);return modules.get(id)};await stage.link(link);if(motor.status==='unlinked')await motor.link(link);await stage.evaluate();await motor.evaluate();
   const Stage=options=>{context.stageData=JSON.stringify({...options,motor:undefined,emit:undefined});return stage.namespace.createPlatformStage({...runInContext('JSON.parse(stageData)',context),motor:options.motor,emit:options.emit})};
   const native=castleSession(),embedded=castleSession(native.doc,{Stage,Motor:motor.namespace.createPlatformMotor}),normalize=q=>JSON.parse(JSON.stringify(q));
   const report=runCastleReturn(native,{onStep(input,v){assert.deepEqual(normalize(embedded.step(input)),normalize(v));}});assert.deepEqual(normalize(embedded.events),normalize(native.events));assert.equal(networkRequests,0);
   console.log(JSON.stringify({...report,actualEmbeddedStageExecuted:true,moduleCount:checked.moduleCount,networkRequests}));
  `;
  const result=spawnSync(process.execPath,['--experimental-vm-modules','--input-type=module','-e',script,htmlPath],{encoding:'utf8',timeout:30000,maxBuffer:1024*1024});assert.equal(result.status,0,result.stderr||result.stdout||String(result.error));const report=JSON.parse(result.stdout);assert.equal(report.actualEmbeddedStageExecuted,true);assert.equal(report.networkRequests,0);assert(report.liveSurfaceSamples>40);
 }finally{fs.rmSync(dir,{recursive:true,force:true});}
});
