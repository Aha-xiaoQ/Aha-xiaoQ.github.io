import assert from 'node:assert/strict';
import {test} from 'node:test';
import {blank} from '../atlas/editor-model.mjs';
import {addSmm2Component} from '../atlas/editor-smm2-authoring.mjs';
import {addContraptionDoorPair} from '../atlas/editor-contraptions-tools.mjs';
import {createPlatformStage} from '../atlas/editor-mario-stage.mjs';
import {pSwitchProject} from './fixtures/p-switch-native.mjs';
import {nativeSession,overlaps} from './fixtures/shell-coin-native.mjs';

const body = ({x,y,w,h}) => ({x,y,w,h});
const pinkProgress = s => s.view().smm2Mechanics.pinkCoins;
const pinkEvents = s => s.events.filter(e => e.event === 'pink-coin-collected');
const releaseEvents = s => s.events.filter(e => e.event === 'pink-key-release');

function observedSession(doc,options) {
  const s = nativeSession(doc,options), step = s.step, observations = [];
  // Store the returned public views, without touching Stage or motor state.
  s.step = input => {
    const v = step(input);
    observations.push(v);
    return v;
  };
  return Object.assign(s,{observations});
}

function pinkPProject({pit = false} = {}) {
  const doc = pSwitchProject(), room = doc.rooms[0];
  doc.title = 'Neutral typed Pink / ordinary P conversion boundary';
  // Keep the uncollected ordinary coin and both bricks above the walking route.
  room.map.objects.find(o => o.id === 'coin').y = 96;
  addSmm2Component(room,'pinkCoin',{id:'pink-a',x:144,y:208});
  addSmm2Component(room,'pinkCoin',{id:'pink-b',x:176,y:208});
  if (pit) room.map.geometry.find(g => g.id === 'floor').w = 320;
  return doc;
}

function activateP(s) {
  const v = s.until(v => v.contraptions.pFrames > 0,{},100);
  assert.equal(v.contraptions.pFrames,600);
  const press = s.events.find(e => e.event === 'p-pressed');
  assert.equal(press.itemId,'stable-p');
  assert.equal(press.contact.kind,'foot');
  assert.equal(v.items.find(i => i.id === 'stable-p').h,4);
  return v;
}

function collectMainPinks(s) {
  s.until(v => v.smm2Mechanics.pinkCoins.taken === 2,{x:1},100);
  for (const e of pinkEvents(s).slice(-2)) {
    const v = s.observations[e.frame - 1];
    const coin = s.doc.rooms.find(r => r.roomId === e.roomId)
      .map.objects.find(o => o.id === e.actorId);
    assert(overlaps(v.p,coin),'Pink collection requires native player contact');
    assert(v.contraptions?.pFrames > 0,'Pink was collected while P was active');
    assert(!v.geometry.some(g => g.sourceCoinId === e.actorId),
      'an explicitly typed Pink has no P brick collision body');
  }
  return s.view();
}

function catchReleasedKey(s,expectedReleases = 1) {
  const released = s.view();
  assert.equal(releaseEvents(s).length,expectedReleases);
  assert.equal(released.contraptions.keys,0,'release alone does not grant inventory');
  const key = released.items.find(i => i.id === 'pink-coins-key' && i.kind === 'key');
  assert(key,'last Pink releases an actual collectible key item');
  assert(overlaps(released.p,key),'the released key is at the physical last-Pink contact');
  const v = s.until(v => v.contraptions.keys === 1,{},30);
  assert(v.contraptions.pFrames > 0);
  assert(!v.items.some(i => i.id === key.id),'caught world key leaves the item list');
  assert.equal(v.contraptions.keyFollowers.length,1);
  assert.equal(v.contraptions.keyFollowers[0].sourceItemId,key.id);
  assert.equal(s.events.filter(e => e.event === 'key-collected' && e.itemId === key.id).length,expectedReleases);
  return v;
}

test('native P converts only ordinary coins and empty bricks, preserving Pink bodies and the 600-frame timer',() => {
  const s = observedSession(pinkPProject()), room = s.doc.rooms[0];
  const ordinary = room.map.objects.find(o => o.id === 'coin');
  const brick = room.map.geometry.find(g => g.id === 'empty-brick');
  const pinks = room.map.objects.filter(o => room.smm2Mechanics.pinkCoins.some(p => p.id === o.id));
  const initial = s.view();
  assert.deepEqual(body(initial.objects.find(o => o.id === ordinary.id)),body(ordinary));
  assert(!initial.geometry.find(g => g.id === brick.id).hidden);

  const active = activateP(s);
  const solidCoin = active.geometry.find(g => g.sourceCoinId === ordinary.id);
  assert(solidCoin?.pCoin);
  assert.equal(solidCoin.collision,'solid');
  assert.equal(solidCoin.material,'brick');
  assert.deepEqual(body(solidCoin),body(ordinary));
  assert(!active.objects.some(o => o.id === ordinary.id));
  assert(active.geometry.find(g => g.id === brick.id).hidden);
  const brickCoin = active.objects.find(o => o.sourceBrickId === brick.id);
  assert.equal(brickCoin.kind,'coin');
  assert.deepEqual(body(brickCoin),body(brick));
  assert(!room.smm2Mechanics.pinkCoins.some(p => p.id === brickCoin.id),
    'an empty-brick-derived coin remains ordinary');
  assert(!active.geometry.find(g => g.id === 'content-brick').hidden);
  for (const pink of pinks) {
    assert.deepEqual(body(active.objects.find(o => o.id === pink.id)),body(pink));
    assert(!active.geometry.some(g => g.sourceCoinId === pink.id));
  }

  const penultimate = s.frames(599);
  assert.equal(penultimate.contraptions.pFrames,1);
  assert(penultimate.geometry.some(g => g.sourceCoinId === ordinary.id));
  const expired = s.step();
  assert.equal(expired.contraptions.pFrames,0);
  assert(!expired.items.some(i => i.id === 'stable-p'));
  assert(!expired.geometry.some(g => g.pCoin));
  assert(!expired.geometry.find(g => g.id === brick.id).hidden);
  assert.deepEqual(body(expired.objects.find(o => o.id === ordinary.id)),body(ordinary));
  assert(!expired.objects.some(o => o.sourceBrickId === brick.id));
  for (const pink of pinks) {
    assert.deepEqual(body(expired.objects.find(o => o.id === pink.id)),body(pink));
  }
  assert.deepEqual(pinkProgress(s),{taken:0,total:2,keyReleased:false});
  assert.equal(s.events.filter(e => e.event === 'p-pressed').length,1);
  assert.equal(s.events.filter(e => e.event === 'p-expired').length,1);
});

test('real player collects typed Pinks during P, and the actual last Pink releases one physically caught key',() => {
  const s = observedSession(pinkPProject());
  activateP(s);
  s.until(v => v.smm2Mechanics.pinkCoins.taken === 1,{x:1},100);
  assert.deepEqual(pinkProgress(s),{taken:1,total:2,keyReleased:false});
  assert.equal(releaseEvents(s).length,0);
  assert.equal(s.view().contraptions.keys,0);
  assert(s.view().objects.some(o => o.id === 'pink-b'));
  collectMainPinks(s);
  assert.deepEqual(pinkProgress(s),{taken:2,total:2,keyReleased:true});
  assert.equal(s.view().coins,2);
  assert.equal(pinkEvents(s).length,2);
  catchReleasedKey(s);
  s.frames(30);
  assert.equal(releaseEvents(s).length,1);
  assert.equal(s.view().contraptions.keys,1);
  assert(!s.view().objects.some(o => o.id === 'pink-a' || o.id === 'pink-b'));
});

test('P brick-derived coin is physically collectible as an ordinary coin and stays consumed after expiry',() => {
  const doc = pinkPProject(), room = doc.rooms[0];
  room.map.geometry.find(g => g.id === 'empty-brick').y = 208;
  const s = observedSession(doc);
  activateP(s);
  collectMainPinks(s);
  catchReleasedKey(s);
  const convertedCoin = s.view().objects.find(o => o.sourceBrickId === 'empty-brick');
  assert.equal(convertedCoin.kind,'coin');
  const collected = s.until(v => v.coins === 3,{x:1},100);
  assert(overlaps(collected.p,convertedCoin));
  assert.equal(collected.contraptions.pFrames > 0,true);
  assert.deepEqual(pinkProgress(s),{taken:2,total:2,keyReleased:true});
  assert.equal(pinkEvents(s).length,2);
  assert.equal(releaseEvents(s).length,1);
  assert.equal(s.events.filter(e => e.event === 'p-brick-collected' && e.deviceId === 'empty-brick').length,1);
  s.frames(collected.contraptions.pFrames);
  assert.equal(s.view().contraptions.pFrames,0);
  assert(!s.view().geometry.some(g => g.id === 'empty-brick'));
  assert(!s.view().objects.some(o => o.sourceBrickId === 'empty-brick'));
  assert(s.view().objects.some(o => o.id === 'coin'));
  assert.equal(s.view().contraptions.keys,1);
});

for (const afterExpiry of [false,true]) test(`native death with collected Pinks and a caught key ${afterExpiry ? 'after P expiry' : 'during P'} resets Pink, key, ordinary conversion and the P source`,() => {
  const s = observedSession(pinkPProject({pit:true}),{
    Stage:options => createPlatformStage({...options,manualDeath:false})
  });
  activateP(s);
  collectMainPinks(s);
  catchReleasedKey(s);
  if (afterExpiry) {
    s.frames(s.view().contraptions.pFrames);
    assert.equal(s.view().contraptions.pFrames,0);
    assert.equal(s.view().contraptions.keys,1);
    assert.deepEqual(pinkProgress(s),{taken:2,total:2,keyReleased:true});
  }
  const death = s.until(v => v.p.dying,{x:1,run:true},300);
  if (afterExpiry) assert.equal(death.contraptions.pFrames,0);
  else assert(death.contraptions.pFrames > 0);
  assert.equal(death.lives,2);
  const respawned = s.until(v => !v.p.dying,{},150);
  assert.deepEqual(pinkProgress(s),{taken:0,total:2,keyReleased:false});
  assert.equal(respawned.contraptions.keys,0);
  assert.equal(respawned.contraptions.pFrames,0);
  assert.equal(respawned.contraptions.keyFollowers.length,0);
  assert(!respawned.items.some(i => i.kind === 'key'));
  assert(respawned.items.some(i => i.id === 'stable-p' && !i.pressed && !i.dead));
  assert(respawned.objects.some(o => o.id === 'coin'));
  assert(!respawned.geometry.some(g => g.pCoin));
  assert(!respawned.geometry.find(g => g.id === 'empty-brick').hidden);
  for (const id of ['pink-a','pink-b']) assert(respawned.objects.some(o => o.id === id));
  activateP(s);
  collectMainPinks(s);
  catchReleasedKey(s,2);
  assert.equal(pinkEvents(s).length,4,'each Pink can be collected once again in the new life');
  assert.equal(releaseEvents(s).length,2,'one genuine key release per life');
  assert.equal(s.view().lives,2);
});

test('real paired-door return during P preserves collected Pinks and the global ordinary conversion in both rooms',() => {
  const doc = pinkPProject(), second = blank('Neutral P door return',640,288).rooms[0];
  second.roomId = 'other';
  second.map.id = 'neutral-p-other';
  second.map.geometry = [
    {id:'floor',x:0,y:224,w:640,h:64,collision:'solid',material:'ground'},
    {id:'empty-brick',x:144,y:144,w:16,h:16,collision:'solid',material:'brick'}
  ];
  second.map.objects = [
    {id:'start',kind:'spawn',x:35,y:210,w:10,h:14},
    {id:'coin',kind:'coin',x:80,y:96,w:16,h:16}
  ];
  addSmm2Component(second,'pinkCoin',{id:'pink-a',x:160,y:208});
  doc.rooms.push(second);
  addContraptionDoorPair(doc,'main','other',{
    source:{x:224,y:192},target:{x:32,y:192},style:'plain'
  });
  const s = observedSession(doc);
  activateP(s);
  collectMainPinks(s);
  assert.deepEqual(pinkProgress(s),{taken:2,total:3,keyReleased:false});
  assert.equal(releaseEvents(s).length,0);
  s.until(v => v.p.x >= 224 && v.p.grounded,{x:1},100);
  s.frames(8);
  s.step({up:true});
  const away = s.until(v => v.roomId === 'other',{},30);
  assert(away.contraptions.pFrames > 0);
  assert(away.geometry.some(g => g.sourceCoinId === 'coin' && g.collision === 'solid'));
  assert(away.geometry.find(g => g.id === 'empty-brick').hidden);
  assert(away.objects.some(o => o.sourceBrickId === 'empty-brick' && o.kind === 'coin'));
  assert(!away.objects.some(o => o.id === 'coin'));
  assert(away.objects.some(o => o.id === 'pink-a'));
  assert(!away.geometry.some(g => g.sourceCoinId === 'pink-a'));
  assert.deepEqual(pinkProgress(s),{taken:2,total:3,keyReleased:false});
  s.frames(35);
  s.step({up:true});
  const returned = s.until(v => v.roomId === 'main',{},30);
  assert(returned.contraptions.pFrames > 0);
  assert(!returned.items.some(i => i.id === 'stable-p'),'pressed authored P is consumed across re-entry');
  assert(!returned.objects.some(o => o.id === 'pink-a' || o.id === 'pink-b'));
  assert(returned.geometry.some(g => g.sourceCoinId === 'coin' && g.collision === 'solid'));
  assert(returned.geometry.find(g => g.id === 'empty-brick').hidden);
  assert.deepEqual(pinkProgress(s),{taken:2,total:3,keyReleased:false});

  // Cross the collected bodies again through the motor, then return for the final Pink.
  s.until(v => v.p.x < 136,{x:-1},100);
  s.frames(8);
  assert.equal(s.view().coins,2);
  assert.equal(pinkEvents(s).length,2);
  s.until(v => v.p.x >= 224 && v.p.grounded,{x:1},100);
  s.frames(8);
  s.step({up:true});
  s.until(v => v.roomId === 'other',{},30);
  s.until(v => v.smm2Mechanics.pinkCoins.taken === 3,{x:1},100);
  assert(s.view().contraptions.pFrames > 0);
  const last = pinkEvents(s).at(-1);
  assert.equal(last.roomId,'other');
  assert.equal(last.actorId,'pink-a','same native ID belongs to the other room namespace');
  const contact = s.observations[last.frame - 1];
  const coin = s.doc.rooms[1].map.objects.find(o => o.id === 'pink-a');
  assert(overlaps(contact.p,coin));
  assert.deepEqual(pinkProgress(s),{taken:3,total:3,keyReleased:true});
  catchReleasedKey(s);
  assert.equal(s.view().coins,3);
  assert.equal(pinkEvents(s).length,3);
  assert.equal(s.events.filter(e => e.event === 'door-enter').length,3);
  assert.equal(s.events.filter(e => e.event === 'p-pressed').length,1);
});
