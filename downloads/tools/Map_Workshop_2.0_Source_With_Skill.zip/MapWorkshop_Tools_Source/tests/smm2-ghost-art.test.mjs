import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import test from 'node:test';
import assert from 'node:assert/strict';
import {createCanvas,loadImage} from '@napi-rs/canvas';
import {fileURLToPath} from 'node:url';
import {blank,parseProject} from '../atlas/editor-model.mjs';
import {drawSmm2GhostActor,drawSmm2GhostTile,drawSmm2GhostScenery} from '../atlas/editor-smm2-ghost-art.mjs';
import {drawSmm2Actor,drawSmm2Tile} from '../atlas/editor-smm2-art.mjs';
import {drawScenery,drawTile} from '../atlas/editor-art.mjs';
const canvas=()=>createCanvas(384,432),bytes=c=>Buffer.from(c.getContext('2d').getImageData(0,0,c.width,c.height).data),hash=c=>createHash('sha256').update(bytes(c)).digest('hex');
function room(){const r=blank('neutral ghost',384,432).rooms[0];r.smm2Mechanics={version:1,art:{palette:'smb1-ghost-source',tileOriginY:8}};r.nativeSceneryMode='authored';return r;}
// Test raw encoded palette pixels, independent of image-decoder gamma conversion.
// Original response bytes remain untouched in assets; runtime uses those RGBA indices.
function rawPngPalette(buffer){const chunks=[buffer.subarray(0,8)];for(let i=8;i<buffer.length;){const n=buffer.readUInt32BE(i),kind=buffer.toString('ascii',i+4,i+8);if(!['gAMA','cHRM','iCCP','sRGB'].includes(kind))chunks.push(buffer.subarray(i,i+n+12));i+=n+12;}return Buffer.concat(chunks);}
const original=async name=>loadImage(rawPngPalette(readFileSync(fileURLToPath(new URL('../atlas/assets/smm2-ghost-private/'+name,import.meta.url)))));
test('ghost enemy and POW shared renders retain exact original pixels and enemy aspect ratio',async()=>{
 const r=room();for(const [file,a]of [['SMM-SMB-Thwomp.png',{type:'smm2-thwomp',smm2Thwomp:{phase:'charge'},x:32,y:32,w:64,h:64}],['SMM-SMB-Spiny.png',{type:'spiny',x:32,y:32,w:32,h:32}],['SMM-SMB-POW.png',{kind:'pow',x:32,y:32,w:16,h:16}]]){
  const im=await original(file),actual=canvas(),expected=canvas(),scale=a.type==='smm2-thwomp'?2:a.type==='spiny'?2:1,before=JSON.stringify(a);expected.getContext('2d').imageSmoothingEnabled=false;expected.getContext('2d').drawImage(im,a.x+(a.w-im.width*scale)/2,a.y+a.h-im.height*scale,im.width*scale,im.height*scale);assert(drawSmm2Actor(actual.getContext('2d'),a,0,r));assert.equal(hash(actual),hash(expected),file);assert.equal(JSON.stringify(a),before);
 }
});
test('ghost ground uses the original native rim motif at authored bounds with a stable grid',async()=>{
 const r=room(),q={id:'rim',x:16,y:24,w:48,h:16,material:'ground',collision:'solid'};r.map.geometry=[q];const actual=canvas(),expected=canvas(),im=await original('SMM_ground_SMB_Ghost_House.png');for(let x=16;x<64;x+=16)expected.getContext('2d').drawImage(im,48,16,16,16,x,24,16,16);assert(drawSmm2Tile(actual.getContext('2d'),q,r));assert.equal(hash(actual),hash(expected),'native rim crop');assert.equal(actual.getContext('2d').getImageData(15,24,1,1).data[3],0);
});
test('split native ground geometry has the same rim and interior pixels as an unsplit body',()=>{
 const r=room(),q={id:'mass',x:16,y:24,w:96,h:64,material:'ground',collision:'solid'};r.map.geometry=[q];const a=canvas(),b=canvas();drawSmm2GhostTile(a.getContext('2d'),q,r);r.map.geometry=[{...q,id:'left',w:48},{...q,id:'right',x:64,w:48}];for(const p of r.map.geometry)drawSmm2GhostTile(b.getContext('2d'),p,r);assert.equal(hash(a),hash(b));
});
test('timber background is a noncolliding one-pass shared decoration preserved by import',()=>{
 const r=room(),q={id:'wood',x:16,y:24,w:96,h:112,material:'decoration',smm2Art:'ghost-timber-backdrop'};r.decorations=[q];const before=JSON.stringify(r),a=canvas(),b=canvas();assert(drawSmm2GhostScenery(a.getContext('2d'),q,r));drawScenery(b.getContext('2d'),r);assert.equal(hash(a),hash(b));for(const p of r.decorations)drawTile(b.getContext('2d'),p,r,{sceneryDrawn:true});assert.equal(hash(a),hash(b));assert.equal(JSON.stringify(r),before);assert.equal(r.map.geometry.length,0);const d=blank('import ghost',384,432);d.rooms=[r];assert.deepEqual(parseProject(JSON.stringify(d)).rooms[0].decorations,[q]);
});
test('hidden or spent source actors cannot reappear and ordinary theme dispatch stays intact',()=>{
 const r=room(),c=canvas(),q={kind:'pow',x:16,y:16,w:16,h:16,smm2Pow:{phase:'spent'}};assert(drawSmm2GhostActor(c.getContext('2d'),q,0,r));assert(bytes(c).every(x=>x===0));assert.equal(drawSmm2GhostActor(c.getContext('2d'),{...q,smm2Pow:{phase:'live'}},0,{...r,smm2Mechanics:undefined}),false);assert.equal(drawSmm2GhostTile(c.getContext('2d'),{x:0,y:0,w:16,h:16,material:'ground'},{}),false);
});
