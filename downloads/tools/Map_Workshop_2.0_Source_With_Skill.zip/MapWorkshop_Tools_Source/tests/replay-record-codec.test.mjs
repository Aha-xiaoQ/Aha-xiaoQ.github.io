import assert from 'node:assert/strict';
import {test} from 'node:test';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {gzipSync,gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {encodeReplayRecordBytes,decodeReplayRecordStorage,decodeReplayRecordEnvelope,
 readReplayRecordSync,readReplayRecord,readReplayRecordBytesSync,readReplayRecordBytes,
 resolveReplayRecordPath} from '../scripts/replay-record-codec.mjs';

const bytes=value=>Buffer.from(JSON.stringify(value,null,2)+'\n');
const fixture=()=>JSON.parse('{"rle":[{"frames":2,"input":{"x":1}}],"events":[{"frame":2,"event":"done"}],"trace":[{"geometry":[{"id":"floor","x":0}],"objects":[{"id":"checkpoint","activationAge":1},{"id":"coin","x":8}]},{"geometry":[{"id":"floor","x":0}],"objects":[{"id":"checkpoint","activationAge":2},{"id":"coin","x":8}]}],"final":{"completed":true,"literal":["ref",0],"__proto__":{"safe":true}}}');

test('dedup retains every dynamic value, literal reference-shaped array and independent containers',()=>{
 const original=fixture(),storage=encodeReplayRecordBytes(bytes(original)),decoded=decodeReplayRecordStorage(storage),table=JSON.parse(gunzipSync(storage));
 assert.deepEqual(decoded.record,original);assert.deepEqual(decoded.bytes,bytes(original));
 const floor=table.nodes.filter(node=>JSON.stringify(node).includes('"id","floor"'));
 assert.equal(floor.length,1,'repeated individual geometry object is interned only once');
 assert.equal(decoded.record.trace[0].objects[0].activationAge,1);assert.equal(decoded.record.trace[1].objects[0].activationAge,2);
 assert.notStrictEqual(decoded.record.trace[0].geometry,decoded.record.trace[1].geometry);
 assert.notStrictEqual(decoded.record.trace[0].geometry[0],decoded.record.trace[1].geometry[0]);
 decoded.record.trace[0].geometry[0].x=17;assert.equal(decoded.record.trace[1].geometry[0].x,0);
 assert(Object.hasOwn(decoded.record.final,'__proto__'));assert.equal({}.safe,undefined);
 assert.deepEqual(storage,encodeReplayRecordBytes(bytes(original)),'storage is deterministic');
});

test('sync and async loaders read legacy JSON and explicit gzip; CLI restores exact original bytes',async()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'Frozen Replay Codec ')),old=path.join(dir,'route.json'),compressed=old+'.gz',restored=path.join(dir,'restored.json');
 try{
  const original=fixture(),raw=bytes(original);fs.writeFileSync(old,raw);fs.writeFileSync(compressed,encodeReplayRecordBytes(raw));
  for(const file of [old,compressed,new URL('file://'+compressed)]){
   assert.deepEqual(readReplayRecordSync(file),original);assert.deepEqual(await readReplayRecord(file),original);
   assert.deepEqual(readReplayRecordBytesSync(file),raw);assert.deepEqual(await readReplayRecordBytes(file),raw);
  }
  assert.equal(resolveReplayRecordPath(old),old);fs.unlinkSync(old);assert.equal(resolveReplayRecordPath(old),compressed);assert.deepEqual(readReplayRecordSync(old),original);
  const cli=fileURLToPath(new URL('../scripts/replay-record-codec.mjs',import.meta.url));
  const result=spawnSync(process.execPath,[cli,'decompress',compressed,restored],{encoding:'utf8'});
  assert.equal(result.status,0,result.stderr);assert.deepEqual(fs.readFileSync(restored),raw);
  fs.writeFileSync(old,'{"legacy":true}');assert.deepEqual(readReplayRecordBytesSync(old),Buffer.from('{"legacy":true}'));assert.deepEqual(readReplayRecordSync(old),{legacy:true});
 }finally{fs.rmSync(dir,{recursive:true,force:true});}
});

test('malformed references, nodes, metadata, payload and gzip fail explicitly',()=>{
 const envelope=()=>JSON.parse(gunzipSync(encodeReplayRecordBytes(bytes(fixture()))));
 const invalid=[
  d=>{d.version=99;},d=>{d.extra=true;},d=>{d.original.sha256='invalid';},
  d=>{d.root=['ref',d.nodes.length];},d=>{d.root=['ref',-1];},d=>{d.root=['ref',0.5];},
  d=>{d.nodes[0]=[0,[['ref',0]]];},d=>{d.nodes[0]=[2,[]];},
  d=>{d.nodes[0]=[1,[['same',1],['same',2]]];},d=>{d.nodes.push([0,[]]);},
  d=>{d.original.bytes++;},d=>{d.nodes[0][1][0][1]='tampered';}
 ];
 for(const mutate of invalid){const d=envelope();mutate(d);assert.throws(()=>decodeReplayRecordEnvelope(d),/Frozen replay codec:/);assert.throws(()=>decodeReplayRecordStorage(gzipSync(Buffer.from(JSON.stringify(d)))),/Frozen replay codec:/);}
 const damaged=encodeReplayRecordBytes(bytes(fixture()));damaged[damaged.length-8]^=1;assert.throws(()=>decodeReplayRecordStorage(damaged),/invalid gzip/);
 assert.throws(()=>encodeReplayRecordBytes(Buffer.from('{"compact":true}')),/canonical JSON/);
 assert.throws(()=>encodeReplayRecordBytes(bytes([])),/JSON object/);
});
