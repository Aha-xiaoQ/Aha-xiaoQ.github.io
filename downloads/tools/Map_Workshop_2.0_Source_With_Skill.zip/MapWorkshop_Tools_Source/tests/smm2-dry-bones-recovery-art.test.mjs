import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
import {createCanvas} from '@napi-rs/canvas';
import {drawObject} from '../atlas/editor-art.mjs';
import {drawSmm2DryBones,drawSmm2BoneShell} from '../atlas/editor-smm2-bone-art.mjs';
import {SMM2_SOURCE_PIXELS} from '../atlas/editor-smm2-source-assets.mjs';
import {offlineFile} from '../atlas/editor-offline.mjs';

const canvas=()=>createCanvas(192,160);
const bytes=c=>c.getContext('2d').getImageData(0,0,c.width,c.height).data;
const freeze=q=>{if(q&&typeof q==='object'){for(const value of Object.values(q))freeze(value);Object.freeze(q);}return q;};
const actor=(scale=1,facing=-1,phase='recovering')=>({id:'bones',kind:'walker',type:'dry-bones',x:64.25,y:128-8*scale,w:16*scale,h:8*scale,vx:0,facing,grounded:true,smm2DryBones:{phase,size:scale===2?'giant':'normal',remainingFrames:0}});
// Paint the unchanged original rows independently, including the existing
// rounded origin and mirror. No recovery helper is used for expected pixels.
function original(c,q,name,dx=0){
 const im=SMM2_SOURCE_PIXELS[name],scale=q.w/16,ctx=c.getContext('2d');
 const left=Math.round(q.x+(q.w-im.w*scale)/2+dx*scale),top=Math.round(q.y+q.h-im.h*scale);
 for(let y=0;y<im.h;y++)for(let x=0;x<im.w;x++){
  const color=im.palette[parseInt(im.rows[y][x],36)];if(color.endsWith('00'))continue;
  ctx.fillStyle=color;ctx.fillRect(left+(q.facing>0?im.w-1-x:x)*scale,top+y*scale,scale,scale);
 }
}

test('standing, collapsed and tick-zero recovery retain every original source pixel, size and foot anchor',()=>{
 assert.deepEqual([SMM2_SOURCE_PIXELS.dryBonesStanding.w,SMM2_SOURCE_PIXELS.dryBonesStanding.h],[16,23]);
 assert.deepEqual([SMM2_SOURCE_PIXELS.dryBonesPile.w,SMM2_SOURCE_PIXELS.dryBonesPile.h],[21,8]);
 for(const scale of [1,2])for(const facing of [-1,1])for(const phase of ['walking','collapsed','recovering',undefined]){
  const q=actor(scale,facing,phase);if(phase===undefined)delete q.smm2DryBones;
  freeze(q);const before=JSON.stringify(q),pile=['collapsed','recovering'].includes(phase);
  for(const tick of phase==='recovering'?[0,1,2,3,16]:[0,4,8,12,1024]){
   const actual=canvas(),expected=canvas();assert(drawSmm2DryBones(actual.getContext('2d'),q,{tick}));
   original(expected,q,pile?'dryBonesPile':'dryBonesStanding');assert.deepEqual(bytes(actual),bytes(expected));
  }
  assert.equal(JSON.stringify(q),before);
 }
});

test('actual recovering piles translate whole original pixels by 0,+1,0,-1 source pixels every four ticks',()=>{
 for(const scale of [1,2])for(const facing of [-1,1]){
  const q=freeze(actor(scale,facing)),before=JSON.stringify(q);
  for(let tick=0;tick<32;tick++){
   const dx=[0,1,0,-1][Math.floor(tick/4)%4],actual=canvas(),expected=canvas();
   drawSmm2DryBones(actual.getContext('2d'),q,{tick});original(expected,q,'dryBonesPile',dx);
   assert.deepEqual(bytes(actual),bytes(expected),`tick ${tick}, scale ${scale}, facing ${facing}`);
  }
  assert.equal(JSON.stringify(q),before,'painting cannot change the waiting clock, body, velocity or phase');
 }
});

test('editor sidecars, generic recovering labels and Bone Shell recovery cannot borrow the enemy warning',()=>{
 const room=freeze({smm2Mechanics:{version:1},marioModules:{enemyVariants:{bones:{kind:'dry-bones',size:'normal'}}}});
 const placed=freeze({id:'bones',kind:'walker',x:64,y:104,w:16,h:24,frame:'recovering',phase:'recovering'});
 const a=canvas(),b=canvas();drawObject(a.getContext('2d'),placed,0,room);drawObject(b.getContext('2d'),placed,12,room);
 assert.deepEqual(bytes(a),bytes(b),'the editor obtains a temporary walking descriptor, not live recovery state');
 const label=freeze({...actor(),smm2DryBones:undefined,frame:'recovering',phase:'recovering'}),plain=canvas(),later=canvas();
 drawSmm2DryBones(plain.getContext('2d'),label,{tick:0});drawSmm2DryBones(later.getContext('2d'),label,{tick:4});assert.deepEqual(bytes(plain),bytes(later));
 const shoe=freeze({id:'shoe',type:'smm2-shoe',kind:'walker',x:64,y:120,w:16,h:8,smm2Shoe:{kind:'bone-shell',phase:'recovering',playingDead:false,occupancy:'player'}}),body=canvas(),bodyLater=canvas();
 drawSmm2BoneShell(body.getContext('2d'),shoe,{tick:0,rider:true});drawSmm2BoneShell(bodyLater.getContext('2d'),shoe,{tick:12,rider:true});assert.deepEqual(bytes(body),bytes(bodyLater));
 for(const patch of [{type:'walker'},{hidden:true},{dead:true},{removed:true},{visible:false}]){
  const absent=canvas();assert.equal(drawSmm2DryBones(absent.getContext('2d'),freeze({...actor(),...patch}),{tick:4}),false);assert(bytes(absent).every(v=>v===0));
 }
});

test('recovery painting is deterministic under repeated, out-of-order and invalid draw ticks and restores Canvas state',()=>{
 const q=freeze(actor(2,1)),before=JSON.stringify(q);
 for(const tick of [12,4,12,0,8,4,Infinity,NaN]){
  const c=canvas(),ctx=c.getContext('2d'),expected=canvas();ctx.translate(3,4);ctx.imageSmoothingEnabled=true;ctx.fillStyle='#123456';
  const matrix=ctx.getTransform();drawSmm2DryBones(ctx,q,{tick});
  assert.deepEqual(ctx.getTransform(),matrix);assert.equal(ctx.imageSmoothingEnabled,true);
  expected.getContext('2d').translate(3,4);original(expected,q,'dryBonesPile',Number.isFinite(tick)?[0,1,0,-1][Math.floor(tick/4)%4]:0);
  // The native Canvas getter caches the last assigned color across restore;
  // test the actual restored paint by drawing a sentinel pixel instead.
  ctx.fillRect(10,10,1,1);expected.getContext('2d').fillStyle='#123456';expected.getContext('2d').fillRect(10,10,1,1);
  assert.deepEqual(bytes(c),bytes(expected));assert.equal(JSON.stringify(q),before);
 }
});

test('exported HTML and actual native video renderer share exact recovering enemy rasters without network or state writes',async()=>{
 const root=new URL('../atlas/',import.meta.url),html=await offlineFile({stages:[{title:'Neutral recovery art probe'}]},[{roomId:'main',smm2Mechanics:{version:1}}],p=>fs.readFile(new URL(p,root),'utf8'),p=>fs.readFile(new URL('assets/classic-audio/'+p,root)));
 const dir=await fs.mkdtemp(path.join(os.tmpdir(),'Dry Bones Recovery Art QA '));
 try{
  const file=path.join(dir,'fixture.html');await fs.writeFile(file,html);
  const result=spawnSync(process.execPath,['--experimental-vm-modules',fileURLToPath(new URL('../scripts/check-dry-bones-recovery-art-offline.mjs',import.meta.url)),file],{encoding:'utf8',timeout:30000,maxBuffer:1024*1024});
  assert.equal(result.status,0,result.stderr||result.stdout||String(result.error));const report=JSON.parse(result.stdout);
  assert.equal(report.embeddedArtExecuted,true);assert.equal(report.nativeVideoRendererExecuted,true);assert.equal(report.authoredStateUnchanged,true);assert.equal(report.rasterScenes,48);assert.equal(report.networkRequests,0);
 }finally{await fs.rm(dir,{recursive:true,force:true});}
});
