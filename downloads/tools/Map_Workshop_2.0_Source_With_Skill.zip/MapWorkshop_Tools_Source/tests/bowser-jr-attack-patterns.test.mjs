import test from 'node:test';
import assert from 'node:assert/strict';
import {blank,parseProject,History,updateSmm2BowserJr,cloneSmm2BowserJr} from '../atlas/editor-model.mjs';
import {BOWSER_JR_AUTHORING_DEFAULTS,BOWSER_JR_ATTACK_PATTERN_FIELDS,createBowserJrAttackPatterns,validateBowserJrRule,createBowserJuniors,bowserJrAttackPatternForHp} from '../atlas/editor-bowser-jr.mjs';
import {addSmm2BowserJr,mountBowserJrTools,clearSmm2BowserJrAttackPatterns,captureBowserJrBindings,appendCopiedBowserJrBindings} from '../atlas/editor-bowser-jr-tools.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';
import {displayedJrHeadTarget} from './fixtures/bowser-jr-native.mjs';
import {createCollection,addLevel,validateCollection} from '../atlas/editor-collection.mjs';

const patterns=()=>({version:1,sourceParameterStatus:'authored-not-calibrated',stages:[3,2,1].map((hp,i)=>({hp,shotsPerBurst:i+1,burstSpacingFrames:18-i*3}))});
function fixture(){const d=blank('Neutral authored existing-fire bursts',640,320),r=d.rooms[0];r.map.geometry=[{id:'floor',x:0,y:288,w:640,h:32,collision:'solid',material:'ground'}];r.map.objects=[{id:'start',kind:'spawn',x:50,y:274,w:10,h:14}];addSmm2BowserJr(r,{id:'junior',x:300,y:264,initialFireDelayFrames:10,fireWindupFrames:12,fireIntervalFrames:60,attackPatterns:patterns()});return d;}
const ruleOf=d=>d.rooms[0].smm2Mechanics.bowserJuniors.actors[0];
function stomp(c,a,tick){const head=displayedJrHeadTarget(a),p={x:head.x-5,y:head.y-13,w:10,h:14,vy:2};return c.playerContact(a,p,{...p,y:p.y-2},{tick,beforeActor:structuredClone(a)});}

test('optional authored fire patterns reject malformed/extra attacks and retain exact closed stages',()=>{
 const good={...BOWSER_JR_AUTHORING_DEFAULTS,attackPatterns:patterns()};assert(validateBowserJrRule(good));
 const invalid=[q=>q.attackPatterns=null,q=>q.attackPatterns=undefined,q=>q.attackPatterns.version=2,q=>q.attackPatterns.sourceParameterStatus='original',q=>q.attackPatterns.stages.reverse(),q=>q.attackPatterns.stages.pop(),q=>q.attackPatterns.stages[1].hp=3,q=>q.attackPatterns.stages[1].projectileType='shockwave',q=>q.attackPatterns.extra=true];
 for(const key of BOWSER_JR_ATTACK_PATTERN_FIELDS)invalid.push(q=>delete q.attackPatterns.stages[1][key],q=>q.attackPatterns.stages[1][key]=null,q=>q.attackPatterns.stages[1][key]=NaN,q=>q.attackPatterns.stages[1][key]=1.5);
 invalid.push(q=>q.attackPatterns.stages[0].shotsPerBurst=0,q=>q.attackPatterns.stages[0].shotsPerBurst=4,q=>q.attackPatterns.stages[0].burstSpacingFrames=5,q=>q.attackPatterns.stages[0].burstSpacingFrames=121);
 for(const mutate of invalid){const q=structuredClone(good);mutate(q);assert.throws(()=>validateBowserJrRule(q));}
 assert.deepEqual(createBowserJrAttackPatterns().stages.map(s=>s.shotsPerBurst),[1,1,1]);const snapshot=bowserJrAttackPatternForHp(good,1);snapshot.shotsPerBurst=1;assert.equal(good.attackPatterns.stages[2].shotsPerBurst,3);
});

test('real HP emits 1/2/3 separately aimed straight native fireballs; snapshot resumes an unfinished burst',()=>{
 const d=fixture(),r=d.rooms[0],events=[],c=createBowserJuniors(r,{emit:(_type,e)=>events.push(e)}),a=c.decorateActor({...r.map.objects.find(o=>o.id==='junior'),dead:false}),player={x:40,y:210,w:10,h:14};let tick=0;
 const step=()=>c.stepActor(a,{tick:++tick,player,geometry:r.map.geometry});
 const until=fn=>{for(let n=0;n<1000;n++){const q=step();if(fn(q))return q;}throw Error('controller condition');};
 for(const hp of [3,2,1]){
  if(hp<3){assert(stomp(c,a,++tick).bounce);assert.equal(a.hp,hp);until(()=>a.smm2BowserJr.phase==='normal');}
  const actual=[],start=events.length;until(q=>{if(q?.projectile){actual.push(q.projectile);player.x+=37;player.y+=8;}return actual.length===4-hp;});
  const shots=events.slice(start).filter(e=>e.event==='fireball');assert.equal(shots.length,4-hp);assert.deepEqual(shots.map(q=>q.burstIndex),Array.from({length:4-hp},(_,i)=>i+1));
  for(let i=0;i<shots.length;i++){assert.equal(shots[i].burstCount,4-hp);assert.deepEqual(actual[i].bowserJrAim,shots[i].aim);assert.equal(actual[i].type,'bowser-jr-fireball');assert(Math.abs(Math.hypot(actual[i].vx,actual[i].vy)-1.6)<1e-7);if(i)assert.equal(shots[i].tick-shots[i-1].tick,patterns().stages[3-hp].burstSpacingFrames);}
  if(hp===2){const resumedEvents=[],fresh=createBowserJuniors(r,{emit:(_type,e)=>resumedEvents.push(e)});until(q=>q?.projectile);assert.equal(a.smm2BowserJr.burstIndex,1);const saved=JSON.stringify(a),restored=fresh.decorateActor(JSON.parse(saved));assert.equal(JSON.stringify(restored),saved);const eventStart=events.length;for(let n=0;n<40;n++){step();fresh.stepActor(restored,{tick,player,geometry:r.map.geometry});assert.deepEqual(restored,a);}assert.deepEqual(resumedEvents,events.slice(eventStart));}
 }
 assert(stomp(c,a,++tick).defeated);assert.equal(a.hp,0);
});

test('genuine exposed-head contact interrupts an unfinished authored burst without extra health or automatic fire',()=>{
 const d=fixture(),r=d.rooms[0],events=[],c=createBowserJuniors(r,{emit:(_type,e)=>events.push(e)}),a=c.decorateActor({...r.map.objects.find(o=>o.id==='junior'),dead:false}),player={x:30,y:260,w:10,h:14};let tick=0;
 assert(stomp(c,a,++tick).bounce);for(let n=0;n<1000;n++){const q=c.stepActor(a,{tick:++tick,player,geometry:r.map.geometry});if(q?.projectile)break;}
 assert.equal(a.smm2BowserJr.burstIndex,1);assert.equal(a.smm2BowserJr.phase,'firing');assert(stomp(c,a,++tick).bounce);assert.equal(a.hp,1);assert(!Object.hasOwn(a.smm2BowserJr,'burstIndex'));const shots=events.filter(e=>e.event==='fireball').length;for(let n=0;n<30;n++)c.stepActor(a,{tick:++tick,player,geometry:r.map.geometry});assert.equal(events.filter(e=>e.event==='fireball').length,shots);assert.equal(a.smm2BowserJr.phase,'shell');
});

test('editor APIs, History, native clipboard, JSON and collection keep independent attack-pattern configuration',()=>{
 const h=new History(fixture()),room=()=>h.doc.rooms[0],input=patterns();h.change(()=>updateSmm2BowserJr(room(),'junior',{attackPatterns:input}));input.stages[2].shotsPerBurst=1;assert.equal(ruleOf(h.doc).attackPatterns.stages[2].shotsPerBurst,3);const saved=JSON.stringify(h.doc);assert.throws(()=>h.change(()=>updateSmm2BowserJr(room(),'junior',{attackPatterns:null})));assert.equal(JSON.stringify(h.doc),saved);
 h.change(()=>cloneSmm2BowserJr(room(),'junior',{id:'copy',dx:48}));const leaves=captureBowserJrBindings(room(),new Set(['copy']));h.change(()=>{const body=structuredClone(room().map.objects.find(a=>a.id==='copy'));body.id='paste';body.x+=48;room().map.objects.push(body);appendCopiedBowserJrBindings(room(),leaves,new Map([['copy','paste']]));});for(const q of room().smm2Mechanics.bowserJuniors.actors)assert.deepEqual(q.attackPatterns,patterns());assert.notEqual(ruleOf(h.doc).attackPatterns,room().smm2Mechanics.bowserJuniors.actors[1].attackPatterns);
 assert.deepEqual(parseProject(JSON.stringify(h.doc)),h.doc);const collection=validateCollection(addLevel(createCollection('Existing fire author patterns'),h.doc,{id:'burst-fixture'}));assert.deepEqual(ruleOf(collection.levels[0].project).attackPatterns,patterns());h.change(()=>clearSmm2BowserJrAttackPatterns(room(),'junior'));assert(!Object.hasOwn(ruleOf(h.doc),'attackPatterns'));h.undo();assert.deepEqual(ruleOf(h.doc).attackPatterns,patterns());
});

test('actual sidebar edits all six pattern numbers, rolls back invalid edits, and removes the optional leaf',()=>{
 const ui=installSimulatedPlayDom();try{const h=new History(fixture()),parent=ui.document.createElement('aside'),reports=[],panel=mountBowserJrTools({parent,room:()=>h.doc.rooms[0],change:fn=>h.change(fn),report:s=>reports.push(s)}),get=k=>parent.querySelector('[data-bowser-jr-control="'+k+'"]');assert.equal(get('attackPatterns').checked,true);for(const stage of patterns().stages)for(const key of BOWSER_JR_ATTACK_PATTERN_FIELDS){assert.equal(get('hp'+stage.hp+'-'+key).disabled,false);assert.equal(Number(get('hp'+stage.hp+'-'+key).value),stage[key]);}
  const saved=JSON.stringify(h.doc);get('hp1-shotsPerBurst').value='4';get('apply').click();assert.equal(JSON.stringify(h.doc),saved);assert.equal(reports.length,1);get('hp1-shotsPerBurst').value='2';get('apply').click();assert.equal(ruleOf(h.doc).attackPatterns.stages[2].shotsPerBurst,2);h.undo();panel.refresh();assert.equal(get('hp1-shotsPerBurst').value,'3');get('attackPatterns').checked=false;get('attackPatterns').onchange();get('apply').click();assert(!Object.hasOwn(ruleOf(h.doc),'attackPatterns'));h.undo();panel.refresh();assert.equal(get('attackPatterns').checked,true);
 }finally{ui.restore();}
});

test('optional pursuit pause waits for visible physical landing and accelerates from rest without instant retarget reversals',()=>{
 const d=fixture(),r=d.rooms[0],rule=ruleOf(d);Object.assign(rule,{hitTransitionFrames:16,hitHopSpeed:2.5,pursuitWindupFrames:48,pursuitAimIntervalFrames:24,shellSpeed:2,shellAcceleration:.1});
 const events=[],c=createBowserJuniors(r,{emit:(_type,e)=>events.push(e)}),a=c.decorateActor({...r.map.objects.find(o=>o.id==='junior'),dead:false}),player={x:500,y:274,w:10,h:14};let tick=1;assert(stomp(c,a,tick).bounce);const center=a.x+a.w/2;
 for(let n=1;n<=64;n++){c.stepActor(a,{tick:++tick,player,geometry:r.map.geometry});assert(Math.abs(a.x+a.w/2-center)<1e-7);assert.equal(a.vx,0);if(n===16)assert.equal(a.smm2BowserJr.phase,'shell-windup');}
 assert.equal(a.smm2BowserJr.phase,'shell');assert(a.grounded);assert.equal(events.find(e=>e.event==='shell-pursuit-start').tick,65);
 const velocities=[];for(let n=0;n<20;n++){player.x=n%2?a.x-100:a.x+100;const before=a.vx;c.stepActor(a,{tick:++tick,player,geometry:r.map.geometry});assert(Math.abs(a.vx-before)<=.10000001);velocities.push(a.vx);assert(a.vx>0,'fast player side changes do not flip the shell every tick');}
 assert(Math.abs(a.vx-2)<1e-7);player.x=a.x-100;let sawNearStop=false,sawReverse=false;
 for(let n=0;n<55;n++){const before=a.vx;c.stepActor(a,{tick:++tick,player,geometry:r.map.geometry});assert(Math.abs(a.vx-before)<=.10000001);if(Math.abs(a.vx)<1e-7)sawNearStop=true;if(a.vx<-.09)sawReverse=true;}
 assert(sawNearStop);assert(sawReverse);assert(Math.abs(a.vx+2)<1e-7);
 for(const key of ['pursuitWindupFrames','pursuitAimIntervalFrames'])for(const bad of [null,NaN,Infinity,-1,1.5,121]){const q={...BOWSER_JR_AUTHORING_DEFAULTS,[key]:bad};assert.throws(()=>validateBowserJrRule(q));}
});
