import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createPortableStones,validatePortableStones} from '../atlas/editor-portable-stones.mjs';
import {createPlatformMotor} from '../atlas/editor-mario-motor.mjs';
import {createMarioModules} from '../atlas/editor-mario-modules.mjs';

// Explicit neutral fixture tuning, not measured original-game constants.
const tuning=id=>({id,gravity:.25,maxFallSpeed:4,throwSpeedX:3,throwSpeedY:-2,releaseSafeFrames:2,heldOffsetX:0,heldBottomOffset:-4,carryMotion:{walkCap:.6,runCap:.8,airCap:.8,jumpSpeed:2,jumpGravity:.1,fallGravity:.3},points:200});
function room(){return {roomId:'stone-fixture',map:{width:256,height:288,geometry:[{id:'floor',x:0,y:224,w:256,h:64,collision:'solid'}],objects:[{id:'stone',kind:'walker',x:64,y:208,w:16,h:16,visual:{sprite:'neutral-stone',w:20,h:20}},{id:'goal',kind:'exit',x:220,y:176,w:16,h:48}]},smm2Mechanics:{version:1,portableStones:{version:1,stones:[tuning('stone')],clearCondition:{kind:'carry-stone',goalId:'goal'}}}};}
const player=(extra={})=>({id:'mario',x:54,y:210,w:10,h:14,vx:0,vy:0,facing:1,grounded:true,support:'floor',...extra});
const fixture=(r=room())=>{const events=[],controller=createPortableStones(r,{emit:(name,event)=>events.push({name,event})});return {r,events,c:controller,item:controller.seedItems()[0]};};
function interact(c,p,input,tick,geometry=[]){const before=c.beforePlayer(p,input,tick,geometry),after=c.afterPlayer(p,input,tick,geometry);return {...after,actions:[...before.actions,...after.actions]};}
function pickup(f,p=player(),tick=1){const result=interact(f.c,p,{run:true},tick,f.c.geometry(f.r.map.geometry));assert.equal(result.actions[0]?.action,'pickup');return p;}
const opponent=(extra={})=>({id:'goomba',kind:'walker',type:'goomba',x:82,y:202,w:16,h:16,hp:1,dead:false,...extra});
const neutralCharacter={capabilities:['jump'],motion:{width:10,height:14,maxHealth:1}};

test('opt-out, immutable source bodies and unique seeded live identities',()=>{
 const empty=room();delete empty.smm2Mechanics.portableStones;
 assert.equal(createPortableStones(empty),null);assert.doesNotThrow(()=>validatePortableStones(empty));
 const r=room(),original=structuredClone(r),{c,item}=fixture(r);
 assert.deepEqual(r,original);assert.equal(item.kind,'portable-stone');assert.equal(item.w,16);assert.equal(item.h,16);
 assert.deepEqual(item.visual,{sprite:'neutral-stone',w:20,h:20});
 assert.equal(c.seedItems()[0],item);assert.notEqual(item,r.map.objects[0]);
 assert.equal(c.ownsActor('stone'),true);assert.equal(c.ownsActor(item),true);assert.equal(c.ownsActor('goomba'),false);
 assert.throws(()=>c.stepItem({...item},{tick:1}),/one actor instance/);
});

test('strict leaf validation requires every physical and carry tuning value',()=>{
 const r=room();validatePortableStones(r);
 for(const key of Object.keys(tuning('stone')).filter(key=>key!=='points')){
  const q=structuredClone(r);delete q.smm2Mechanics.portableStones.stones[0][key];assert.throws(()=>validatePortableStones(q),key);
 }
 for(const key of Object.keys(tuning('stone').carryMotion)){
  const q=structuredClone(r);delete q.smm2Mechanics.portableStones.stones[0].carryMotion[key];assert.throws(()=>validatePortableStones(q),key);
 }
 const mutations=[
  q=>q.smm2Mechanics.portableStones.version=2,
  q=>q.smm2Mechanics.portableStones.script='advance',
  q=>q.smm2Mechanics.portableStones.stones[0].rewardAtX=128,
  q=>q.smm2Mechanics.portableStones.stones[0].carryMotion.teleport=true,
  q=>q.smm2Mechanics.portableStones.stones[0].gravity=NaN,
  q=>q.smm2Mechanics.portableStones.stones[0].throwSpeedY=1,
  q=>q.smm2Mechanics.portableStones.stones[0].releaseSafeFrames=.5,
  q=>q.smm2Mechanics.portableStones.stones[0].points=-1,
  q=>q.smm2Mechanics.portableStones.clearCondition.kind='touch-anywhere',
  q=>q.smm2Mechanics.portableStones.clearCondition.script='clear',
  q=>q.smm2Mechanics.portableStones.stones.push(tuning('stone')),
 ];
 for(const mutate of mutations){const q=structuredClone(r);mutate(q);assert.throws(()=>validatePortableStones(q));}
 const unsafe=structuredClone(r);unsafe.smm2Mechanics.portableStones.stones[0]=JSON.parse('{"__proto__":{}}');assert.throws(()=>validatePortableStones(unsafe));
 const leafOnly=structuredClone(r);leafOnly.smm2Mechanics.unrelatedSibling={futureVersion:88};assert.doesNotThrow(()=>validatePortableStones(leafOnly));
 assert.deepEqual(r,room());
});

test('only one bounded native walker of exactly 16 by 16 can supply each stone',()=>{
 for(const mutate of [
  q=>q.map.objects[0].kind='coin',q=>q.map.objects[0].w=32,q=>q.map.objects[0].h=32,
  q=>q.map.objects[0].x=-1,q=>q.map.objects[0].y=280,q=>q.map.objects.shift(),
  q=>q.map.geometry.push({id:'stone',x:0,y:0,w:16,h:16,collision:'solid'}),
  q=>q.markers=[{id:'stone',kind:'unrelated'}],
  q=>q.map.objects[1].kind='spawn',q=>q.map.objects[1].x=250,
 ]){const r=room();mutate(r);assert.throws(()=>validatePortableStones(r));}
 for(const change of [item=>item.w=32,item=>item.vx=NaN,item=>item.y=Infinity]){
  const f=fixture();change(f.item);assert.throws(()=>f.c.stepItem(f.item,{tick:1,geometry:[]}),/contact body or velocity/);
 }
});

test('pickup requires held Run and real side contact, excluding top and embedded starts',()=>{
 for(const [input,extra]of [[{},{}],[{run:true},{x:8}],[{run:true},{x:66,y:194,support:'stone'}],[{run:true},{x:68,y:209}]]){
  const f=fixture(),p=player(extra),before={...p};assert.deepEqual(interact(f.c,p,input,1).actions,[]);assert.deepEqual(p,before);assert.equal(f.c.heldMotion(p),null);
 }
 const f=fixture(),p=player({x:50});f.c.beforePlayer(p,{run:true},1);p.x=54;
 const result=f.c.afterPlayer(p,{run:true},1);assert.equal(result.actions[0].action,'pickup');assert.equal(f.item.portableStone.held,true);
 assert.equal(f.events.filter(q=>q.event.event==='pickup').length,1);
 assert.deepEqual(f.c.afterPlayer(p,{run:true},1).actions,[]);
});

test('a swept side pickup catches a rebounding stone without allowing a top pickup',()=>{
 const f=fixture();Object.assign(f.item,{x:66,y:194,vx:-8,vy:-1});const p=player({x:50,y:198,grounded:false,support:null});
 f.c.beforePlayer(p,{run:true},1);f.c.stepItem(f.item,{tick:1,geometry:[]});
 assert.equal(f.c.afterPlayer(p,{run:true},1).actions[0]?.action,'pickup');
 assert.equal(f.item.vx,0);assert.equal(f.item.vy,0);
});

test('one contact selects one stone and held pose follows without changing Mario',()=>{
 const r=room();r.map.objects.push({...structuredClone(r.map.objects[0]),id:'other-stone'});r.smm2Mechanics.portableStones.stones.push(tuning('other-stone'));
 const {c}=fixture(r),p=player(),before={...p};const result=interact(c,p,{run:true},1);
 assert.equal(result.actions.length,1);assert.equal(c.view().stones.filter(q=>q.state.held).length,1);assert.deepEqual(p,before);
 const heldItem=c.seedItems().find(q=>q.portableStone.held),motion=c.heldMotion(p);
 assert.deepEqual(motion,tuning('stone').carryMotion);motion.runCap=999;assert.equal(c.heldMotion(p).runCap,.8);
 c.beforePlayer(p,{run:true},2);p.x+=12;p.y-=7;p.facing=-1;const motorPose={...p};c.afterPlayer(p,{run:true},2);
 assert.deepEqual(p,motorPose);assert.equal(heldItem.x,p.x-heldItem.w);assert.equal(heldItem.y+heldItem.h,p.y+p.h-4);
 assert.equal(c.geometry(r.map.geometry).filter(q=>q.portableStoneSolid).length,1);
});

test('a Run release edge throws once; Up does not become an unsupported up-throw control',()=>{
 const f=fixture(),p=pickup(f);interact(f.c,p,{run:false,up:true},2,f.r.map.geometry);
 assert.equal(f.item.vx,3);assert.equal(f.item.vy,-2);assert.equal(f.item.portableStone.thrown,true);
 assert.equal(f.c.heldMotion(p),null);assert.equal(f.events.filter(q=>q.event.event==='throw').length,1);
 assert.equal(f.c.stepItem(f.item,{tick:2,geometry:f.r.map.geometry}).advanced,false);
 for(let tick=3;tick<=5;tick++)interact(f.c,p,{run:false,up:true},tick,f.r.map.geometry);
 assert.equal(f.events.filter(q=>q.event.event==='throw').length,1);
});

test('Down on Run release puts a stationary stone at Mario feet and respects authored pickup cooldown',()=>{
 const f=fixture(),p=pickup(f);interact(f.c,p,{run:false,down:true},2,f.r.map.geometry);
 assert.equal(f.item.y+f.item.h,p.y+p.h);assert.equal(f.item.vx,0);assert.equal(f.item.vy,0);assert.equal(f.item.portableStone.thrown,false);
 assert.equal(f.events.filter(q=>q.event.event==='put-down').length,1);
 for(const tick of [3,4])assert.deepEqual(interact(f.c,p,{run:true},tick,f.r.map.geometry).actions,[]);
 assert.equal(interact(f.c,p,{run:true},5,f.r.map.geometry).actions[0]?.action,'pickup');
 assert.equal(f.events.filter(q=>q.event.event==='pickup').length,2);
});

test('a blocked release never inserts the stone inside a wall or repeats on held input',()=>{
 const f=fixture(),p=pickup(f),wall={id:'wall',x:72,y:180,w:16,h:44,collision:'solid'};
 const result=interact(f.c,p,{run:false},2,[...f.r.map.geometry,wall]);assert.equal(result.actions[0].action,'blocked');
 assert.equal(f.item.portableStone.held,true);assert.equal(f.item.vx,0);
 interact(f.c,p,{run:false},3,[wall]);assert.equal(f.events.filter(q=>q.event.event==='release-blocked').length,1);
 interact(f.c,p,{run:true},4,[]);interact(f.c,p,{run:false},5,[]);assert.equal(f.item.portableStone.thrown,true);
});

test('fast free stones sweep real walls, ceilings and floors without tunneling',()=>{
 for(const [start,solid,expected]of [
  [{x:16,y:160,vx:96,vy:0},{id:'wall',x:64,y:140,w:16,h:84,collision:'solid'},{x:48,vx:0}],
  [{x:64,y:170,vx:0,vy:-40},{id:'ceiling',x:32,y:140,w:96,h:16,collision:'solid'},{y:156,vy:0}],
  [{x:64,y:180,vx:0,vy:64},{id:'floor',x:0,y:224,w:256,h:64,collision:'solid'},{y:208,vy:0,grounded:true,support:'floor'}],
 ]){
  const r=room();r.smm2Mechanics.portableStones.stones[0].maxFallSpeed=128;const f=fixture(r);Object.assign(f.item,start);
  f.c.stepItem(f.item,{tick:1,geometry:[solid]});for(const [key,value]of Object.entries(expected))assert.equal(f.item[key],value,key);
 }
});

test('one-way floors let stones rise through and catch a genuine downward crossing',()=>{
 const f=fixture(),bridge={id:'bridge',x:0,y:160,w:256,h:8,collision:'oneway'};
 Object.assign(f.item,{x:64,y:170,vx:0,vy:-20});f.c.stepItem(f.item,{tick:1,geometry:[bridge]});assert.ok(f.item.y<160);
 Object.assign(f.item,{y:140,vy:12});f.c.stepItem(f.item,{tick:2,geometry:[bridge]});assert.equal(f.item.y,144);assert.equal(f.item.support,'bridge');
});

test('room sides are bounded walls while a pit removes the stone without a fabricated floor',()=>{
 const f=fixture();Object.assign(f.item,{x:234,y:280,vx:32,vy:8});f.c.stepItem(f.item,{tick:1,geometry:[]});
 assert.equal(f.item.x,240);assert.equal(f.item.vx,0);assert.equal(f.item.dead,false);
 f.c.stepItem(f.item,{tick:2,geometry:[]});assert.equal(f.item.dead,true);assert.equal(f.c.geometry([]).length,0);
 assert.equal(f.events.filter(q=>q.event.event==='left-room').length,1);
});

test('projected free stones are actual native motor supports, and an ordinary jump leaves them',()=>{
 const f=fixture(),motor=createPlatformMotor(),p=motor.create(neutralCharacter,{x:67,y:168});let landed=false;
 for(let tick=1;tick<=30;tick++){
  f.c.stepItem(f.item,{tick,geometry:f.r.map.geometry});const geometry=f.c.geometry(f.r.map.geometry);
  motor.step(p,{},neutralCharacter,{width:256,solids:geometry});if(p.support==='stone'){landed=true;break;}
 }
 assert.ok(landed);assert.equal(p.y+p.h,f.item.y);assert.equal(p.grounded,true);
 const y=p.y;motor.step(p,{jump:true,jumpPressed:true},neutralCharacter,{width:256,solids:f.c.geometry(f.r.map.geometry)});
 assert.ok(p.y<y);assert.equal(p.grounded,false);assert.equal(p.support,null);
 assert.equal(f.c.geometry(f.r.map.geometry,[f.item],{excludeActor:f.item}).some(q=>q.id==='stone'),false);
});

test('native motor alone consumes a supported stone displacement exactly once',()=>{
 const f=fixture(),motor=createPlatformMotor(),p=motor.create(neutralCharacter,{x:67,y:194});
 Object.assign(p,{grounded:true,support:'stone',vx:0,vy:0});Object.assign(f.item,{grounded:true,support:'floor'});
 const movingFloor={...f.r.map.geometry[0],y:225,dx:2,dy:1};f.c.stepItem(f.item,{tick:1,geometry:[movingFloor]});
 const geometry=f.c.geometry([movingFloor]),stone=geometry.find(q=>q.id==='stone');assert.equal(stone.dx,2);assert.equal(stone.dy,1);
 const before={...p};f.c.beforePlayer(p,{},1,geometry);assert.deepEqual(p,before);
 motor.step(p,{},neutralCharacter,{width:256,solids:geometry});const nativePose={...p};f.c.afterPlayer(p,{},1,geometry);
 assert.deepEqual(p,nativePose);assert.equal(p.x,before.x+2);assert.equal(p.y,before.y+1);assert.equal(p.support,'stone');
 assert.deepEqual(f.c.geometry([movingFloor]),geometry);assert.equal(f.c.stepItem(f.item,{tick:1,geometry:[movingFloor]}).advanced,false);
});

test('actual Note module contact launches a free stone and it can be caught again',()=>{
 const r=room();r.map.geometry=[{id:'left-floor',x:0,y:224,w:64,h:64,collision:'solid'},{id:'right-floor',x:80,y:224,w:176,h:64,collision:'solid'}];
 r.marioModules={version:1,itemSources:[],noteBlocks:[{id:'note',x:64,y:224,w:16,h:16,playerBounceSpeed:4.8,heldBounceSpeed:6,itemBounceSpeed:6}],oneWayWalls:[],enemyVariants:{}};
 const f=fixture(r),notes=createMarioModules(r),geometry=notes.geometry(r.map.geometry);Object.assign(f.item,{y:184,vy:4});let tick=0;
 for(tick=1;tick<=12;tick++){
  f.c.stepItem(f.item,{tick,geometry,afterActor:(...args)=>notes.afterActor(...args)});if(f.item.vy<0)break;
 }
 assert.ok(tick<=12);assert.equal(f.item.y,208);assert.equal(f.item.vy,-6);assert.equal(f.item.grounded,false);assert.equal(f.item.support,null);
 const y=f.item.y;f.c.stepItem(f.item,{tick:++tick,geometry,afterActor:(...args)=>notes.afterActor(...args)});assert.ok(f.item.y<y);
 const p=player({y:f.item.y+1,grounded:false,support:null});assert.equal(interact(f.c,p,{run:true},tick,geometry).actions[0]?.action,'pickup');
 assert.equal(f.c.stepItem(f.item,{tick,geometry,afterActor:(...args)=>notes.afterActor(...args)}).advanced,false);assert.equal(f.item.portableStone.held,true);
});

test('terrain resolution precedes the Note callback and both run once per item tick',()=>{
 const f=fixture(),calls=[],terrain={sweep(){calls.push('sweep');return null;},afterActor(item,before,context){calls.push('terrain');assert.equal(context.tick,1);assert.equal(before.y,208);}};
 const afterActor=(item,before,context)=>{calls.push('note');assert.equal(context.kind,'item');assert.equal(context.tick,1);};
 f.c.stepItem(f.item,{tick:1,geometry:f.r.map.geometry,terrain,afterActor});assert.deepEqual(calls,['sweep','terrain','note']);
 f.c.stepItem(f.item,{tick:1,geometry:f.r.map.geometry,terrain,afterActor});assert.deepEqual(calls,['sweep','terrain','note']);
});

test('real falling top contact qualifies one Goomba defeat and leaves killing/reward to host',()=>{
 const f=fixture();Object.assign(f.item,{y:205,vy:3});f.c.stepItem(f.item,{tick:1,geometry:[]});const goomba=opponent({x:64,y:224});
 const result=f.c.opponentContact(goomba,f.item);assert.equal(result.eligible,true);assert.equal(result.cause,'stone-fall');assert.equal(result.points,200);
 assert.equal(result.contact.normal.y,-1);assert.equal(goomba.dead,false);assert.equal(goomba.hp,1);
 assert.equal(f.c.opponentContact(goomba,f.item).eligible,false);
});

test('an active player throw sweeps a Goomba side once without damaging while held',()=>{
 const f=fixture(),p=pickup(f),goomba=opponent();assert.equal(f.c.opponentContact(goomba,f.item).eligible,false);
 interact(f.c,p,{run:false},2,[]);f.c.stepItem(f.item,{tick:3,geometry:[]});const result=f.c.opponentContact(goomba,f.item,{actorBefore:{...goomba}});
 assert.equal(result.eligible,true);assert.equal(result.cause,'stone-throw');assert.equal(result.contact.normal.x,-1);assert.equal(goomba.dead,false);
 assert.equal(f.c.opponentContact(goomba,f.item).eligible,false);
});

test('a wall blocks the throw attack path instead of awarding a hit through the wall',()=>{
 const f=fixture(),p=pickup(f),wall={id:'wall',x:80,y:170,w:16,h:54,collision:'solid'};
 interact(f.c,p,{run:false},2,[wall]);f.c.stepItem(f.item,{tick:3,geometry:[wall]});
 assert.equal(f.item.x,64);assert.equal(f.item.vx,0);assert.equal(f.c.opponentContact(opponent({x:96}),f.item).eligible,false);
});

test('resting side contact, an unthrown upward stone and unobserved enemy types do not qualify',()=>{
 const resting=fixture();resting.c.stepItem(resting.item,{tick:1,geometry:resting.r.map.geometry});
 assert.equal(resting.c.opponentContact(opponent({x:64,y:208}),resting.item,{actorBefore:opponent({x:90,y:208})}).eligible,false);
 const rising=fixture();Object.assign(rising.item,{y:180,vy:-12});rising.c.stepItem(rising.item,{tick:1,geometry:[]});
 assert.equal(rising.c.opponentContact(opponent({x:64,y:158}),rising.item).eligible,false);
 const falling=fixture();Object.assign(falling.item,{y:205,vy:3});falling.c.stepItem(falling.item,{tick:1,geometry:[]});
 assert.equal(falling.c.opponentContact(opponent({type:'koopa',x:64,y:224}),falling.item).eligible,false);
});

test('an actively thrown rising Stone top supports Goomba instead of defeating it',()=>{
 const f=fixture(),p=pickup(f);interact(f.c,p,{run:false},2,[]);
 Object.assign(f.item,{x:64,y:180,vx:0,vy:-12});const g=opponent({x:64,y:158});
 f.c.stepItem(f.item,{tick:3,geometry:[]});
 assert.equal(f.c.opponentContact(g,f.item,{actorBefore:{...g}}).eligible,false);
 assert.equal(f.c.geometry([])[0].previousTop,180);
});

test('a live Goomba rider receives the Stone displacement once and genuine walls limit it',()=>{
 const f=fixture();Object.assign(f.item,{x:64,y:180,vx:2,vy:-4});
 const g=opponent({x:64,y:164,grounded:true,support:'stone'}),before={...g};
 f.c.stepItem(f.item,{tick:1,geometry:[]});const moved=f.c.carryOpponent(g,{tick:1,previous:before});
 assert.equal(moved.carried,true);assert.equal(g.x,66);assert.equal(g.y,160.25);
 assert.equal(f.c.carryOpponent(g,{tick:1,previous:before}).carried,false);
 const snapshot={...g};f.c.view();f.c.geometry([]);assert.deepEqual(g,snapshot);
 const next={...g};f.c.stepItem(f.item,{tick:2,geometry:[]});
 f.c.carryOpponent(g,{tick:2,previous:next,resolveDisplacement:()=>({dx:0,dy:0,blocked:true})});
 assert.equal(g.grounded,false);assert.equal(g.support,null);assert.equal(g.x,next.x);
 assert.equal(f.c.carryOpponent(opponent({type:'koopa',grounded:true,support:'stone'}),{tick:2}).carried,false);
});

test('carry goal qualification is pure, and hurting/death retry releases and restores identities',()=>{
 const f=fixture(),p=player();assert.equal(f.c.readyForGoal('goal',p),false);assert.equal(f.c.readyForGoal('unrelated-goal',p),true);
 pickup(f,p);assert.equal(f.c.readyForGoal('goal',p),true);const snapshot=f.c.view();
 for(let i=0;i<10;i++){f.c.readyForGoal('goal',p);f.c.heldMotion(p);f.c.geometry(f.r.map.geometry);f.c.view();}assert.deepEqual(f.c.view(),snapshot);
 p.dying=true;assert.equal(f.c.readyForGoal('goal',p),false);assert.equal(f.c.onHurt(p,{tick:2}).action,'hurt-release');
 assert.equal(f.item.portableStone.held,false);assert.equal(f.item.vx,0);assert.equal(f.item.vy,0);assert.equal(f.c.heldMotion(p),null);
 f.item.dead=true;f.c.reset();assert.equal(f.c.seedItems()[0],f.item);assert.equal(f.item.x,64);assert.equal(f.item.y,208);assert.equal(f.item.dead,false);assert.equal(f.item.kind,'portable-stone');
 const retry=player();pickup(f,retry,1);assert.equal(f.c.readyForGoal('goal',retry),true);
});

test('pause freezes inputs, hold state and motion, and pure views cannot cause drift',()=>{
 const f=fixture(),p=pickup(f);f.c.pause(true);const start=structuredClone(f.item),snapshot=f.c.view();
 for(let tick=2;tick<=10;tick++){
  assert.equal(f.c.beforePlayer(p,{run:false},tick).advanced,false);assert.equal(f.c.afterPlayer(p,{run:false},tick).advanced,false);
  assert.equal(f.c.stepItem(f.item,{tick,geometry:f.r.map.geometry}).advanced,false);assert.equal(f.c.onHurt(p,{tick}),null);f.c.view();f.c.geometry(f.r.map.geometry);
 }
 assert.deepEqual(f.item,start);assert.deepEqual(f.c.view(),snapshot);assert.equal(f.events.filter(q=>q.event.event==='throw').length,0);
 f.c.pause(false);interact(f.c,p,{run:false},11,[]);assert.equal(f.events.filter(q=>q.event.event==='throw').length,0);
 interact(f.c,p,{run:true},12,[]);interact(f.c,p,{run:false},13,[]);assert.equal(f.events.filter(q=>q.event.event==='throw').length,1);
});

test('duplicate and stale item ticks do not double-step gravity or leak displacement during pause',()=>{
 const f=fixture();Object.assign(f.item,{y:180,vx:2,vy:1});f.c.stepItem(f.item,{tick:10,geometry:[]});const snapshot=structuredClone(f.item);
 for(const tick of [10,9,8])assert.equal(f.c.stepItem(f.item,{tick,geometry:[]}).advanced,false);
 assert.deepEqual(f.item,snapshot);const solid=f.c.geometry([])[0];assert.equal(solid.dx,2);assert.equal(solid.dy,1.25);
 f.c.pause(true);assert.equal(f.c.geometry([])[0].dx,0);assert.equal(f.c.geometry([])[0].dy,0);
 assert.throws(()=>f.c.stepItem(f.item,{tick:1.5}),/Invalid/);f.c.pause(false);assert.throws(()=>f.c.afterPlayer(player(),{},11),/matching beforePlayer/);
});
