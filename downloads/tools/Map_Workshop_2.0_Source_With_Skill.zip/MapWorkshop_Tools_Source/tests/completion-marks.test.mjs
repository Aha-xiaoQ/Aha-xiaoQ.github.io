import test from 'node:test';
import assert from 'node:assert/strict';
import {createCanvas} from '@napi-rs/canvas';
import {History,parseProject,deleteSelection,validate} from '../atlas/editor-model.mjs';
import {setSmm2FlagScore} from '../atlas/editor-smm2-tools.mjs';
import {setSmm2ArtProfile} from '../atlas/editor-smm2-course-tools.mjs';
import {setSmm2CameraFrame} from '../atlas/editor-camera-tools.mjs';
import {addClassicCloud} from '../atlas/editor-classic-motion-tools.mjs';
import {setNativeSceneryMode} from '../atlas/editor-native-scenery-tools.mjs';
import {setSmm2Lighting} from '../atlas/editor-smm2-lighting-tools.mjs';
import {addSmm2BoneShell} from '../atlas/editor-smm2-bone-tools.mjs';
import {addSmm2BowserJr} from '../atlas/editor-bowser-jr-tools.mjs';
import {removeContraptionDoorPair} from '../atlas/editor-contraptions-tools.mjs';
import {rendererRoom} from '../atlas/editor-renderer.mjs';
import {drawSmm2World} from '../atlas/editor-smm2-art.mjs';
import {completionMarksView,completionMarkBounds,drawCompletionMarks,validateCompletionMarksRoom,validateCompletionMarksRooms,COMPLETION_MARK_ART_PROVENANCE} from '../atlas/editor-completion-marks.mjs';
import {setCompletionMarks,removeCompletionMarks,pruneCompletionMarksReferences,pruneCompletionMarksRoomReferences,captureCompletionMarkBindings,appendCopiedCompletionMarkBindings,mountCompletionMarksTools} from '../atlas/editor-completion-marks-tools.mjs';
import {completionMarksProject} from './fixtures/completion-marks.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';
const clone=q=>structuredClone(q),mark=doc=>doc.rooms[0].smm2Mechanics.completionMarks[0],roundtrip=h=>assert.deepEqual(parseProject(JSON.stringify(h.doc)),h.doc);

test('completion marks are opt-in and missing leaves preserve the legacy view shape',()=>{
 const d=completionMarksProject({marks:false}),r=d.rooms[0],before=clone(d);assert.equal(validateCompletionMarksRoom(r,d.rooms),undefined);assert.equal(completionMarksView(r),undefined);
 const old={version:1,pinkCoins:{taken:0,total:1}},projection=completionMarksView(r);assert.deepEqual({...old,...(projection!==undefined?{completionMarks:projection}:{})},old);assert.deepEqual(d,before);
 const c=createCanvas(320,240),ctx=c.getContext('2d');assert.equal(drawCompletionMarks(ctx,r),false);assert(c.toBuffer('image/png'));assert.equal(COMPLETION_MARK_ART_PROVENANCE.kind,'original-display-only');
});

test('strict configuration rejects bounds, missing/unknown fields, prototypes, symbols and duplicate identities',()=>{
 const invalid=[(r,m)=>delete m.id,(r,m)=>m.completed=true,(r,m)=>m.coinId='',(r,m)=>m.rewardRoomId='other\nroom',(r,m)=>m.portalId='absent',(r,m)=>m.portalId='start',(r,m)=>m.id='x'.repeat(101),(r,m)=>r.map.objects.find(q=>q.id===m.portalId).y=10,(r,m)=>r.map.objects.find(q=>q.id===m.portalId).x=-20,(r,m)=>r.smm2Mechanics.version=2,(r,m)=>Object.setPrototypeOf(m,{inherited:1}),(r,m)=>m[Symbol('completed')]=true];
 for(const edit of invalid){const d=completionMarksProject();edit(d.rooms[0],mark(d));assert.throws(()=>validateCompletionMarksRooms(d.rooms));}
 for(const field of ['id','portalId','coinId']){const d=completionMarksProject(),q=clone(mark(d));q.id='other-mark';q.portalId='other-portal';q.coinId='other-pink';q[field]=mark(d)[field];d.rooms[0].map.objects.push({...clone(d.rooms[0].map.objects.find(q=>q.kind==='portal')),id:'other-portal',x:128});d.rooms[1].map.objects.push({...clone(d.rooms[1].map.objects.find(q=>q.id==='reward-pink')),id:'other-pink',x:128});d.rooms[1].smm2Mechanics.pinkCoins.push({id:'other-pink'});d.rooms[0].smm2Mechanics.completionMarks.push(q);assert.throws(()=>validateCompletionMarksRooms(d.rooms),/Duplicate/);}
 for(const value of [null,{},Array(33).fill(mark(completionMarksProject()))]){const d=completionMarksProject();d.rooms[0].smm2Mechanics.completionMarks=value;assert.throws(()=>validateCompletionMarksRooms(d.rooms));}
 const d=completionMarksProject();d.rooms[0].smm2Mechanics.completionMarks.extra=true;assert.throws(()=>validateCompletionMarksRooms(d.rooms));
 d.rooms[0].smm2Mechanics.completionMarks=[];validateCompletionMarksRooms(d.rooms);
});

test('cross-room bindings resolve a real typed Pink rather than an ordinary coin or portal destination guess',()=>{
 const d=completionMarksProject();validateCompletionMarksRooms(d.rooms);d.rooms[0].map.objects.find(q=>q.kind==='portal').targetRoom='a-different-intermediate-room';validateCompletionMarksRooms(d.rooms);
 mark(d).coinId='ordinary-coin';assert.throws(()=>validateCompletionMarksRooms(d.rooms),/typed Pink/);mark(d).coinId='reward-pink';d.rooms[1].smm2Mechanics.pinkCoins=[];assert.throws(()=>validateCompletionMarksRooms(d.rooms),/typed Pink/);
 const missing=completionMarksProject();mark(missing).rewardRoomId='missing-room';assert.throws(()=>validateCompletionMarksRooms(missing.rooms),/room is missing/);validateCompletionMarksRoom(missing.rooms[0]);validateCompletionMarksRoom(missing.rooms[0],[missing.rooms[0]],{allowMissingRewardRooms:true});
 const duplicate=completionMarksProject();duplicate.rooms.push(clone(duplicate.rooms[1]));assert.throws(()=>validateCompletionMarksRooms(duplicate.rooms),/ambiguous/);
});

test('only exact native Set identities complete marks; counts, room visits and duck types never substitute',()=>{
 const d=completionMarksProject(),r=d.rooms[0],taken=new Set(['reward-pink','entry-lobby\nreward-pink','reward-sandbox\nordinary-coin','reward-sandbox']);assert.equal(completionMarksView(r,taken,d.rooms)[0].completed,false);
 for(const fake of [null,[],{taken:1,total:1},{has:()=>true},Object.create(Set.prototype)])assert.throws(()=>completionMarksView(r,fake,d.rooms),/native Pink Set/);
 taken.add('reward-sandbox\nreward-pink');assert.equal(completionMarksView(r,taken,d.rooms)[0].completed,true);
 const overridden=new Set();overridden.has=()=>true;assert.equal(completionMarksView(r,overridden,d.rooms)[0].completed,false);
});

test('fresh projections follow cleared/death/restored and restart Sets without caching or mutating inputs',()=>{
 const d=completionMarksProject(),r=d.rooms[0],before=clone(d),taken=new Set(['reward-sandbox\nreward-pink']),completed=completionMarksView(r,taken,d.rooms);assert(completed[0].completed);
 taken.clear();assert.equal(completionMarksView(r,taken,d.rooms)[0].completed,false);assert.equal(taken.size,0);assert.equal(completed[0].completed,true,'old snapshot remains a snapshot');
 const restart=new Set();assert.equal(completionMarksView(r,restart,d.rooms)[0].completed,false);restart.add('reward-sandbox\nreward-pink');const restored=completionMarksView(r,restart,d.rooms);restored[0].completed=false;restored[0].x=-999;assert(completionMarksView(r,restart,d.rooms)[0].completed);assert.equal(restart.size,1);assert.deepEqual(d,before);
});

test('mark placement follows actual portal movement rather than a saved decorative coordinate',()=>{
 const d=completionMarksProject(),r=d.rooms[0],p=r.map.objects.find(q=>q.kind==='portal'),initial=completionMarksView(r,new Set(),d.rooms)[0];p.x+=48;p.y-=32;const next=completionMarksView(r,new Set(),d.rooms)[0];assert.equal(next.x,initial.x+48);assert.equal(next.y,initial.y-32);assert.deepEqual(completionMarkBounds(p),{x:next.x,y:next.y,w:12,h:12});assert.equal(p.y-(next.y+next.h),6);assert.equal(next.collision,undefined);
});

test('actual native Canvas shows a hollow outline and a distinct green/white check without touching door or HUD space',()=>{
 const d=completionMarksProject(),r=d.rooms[0],before=clone(d),canvas=createCanvas(320,240),c=canvas.getContext('2d');c.fillStyle='#5c94fc';c.fillRect(0,0,320,240);const background=c.getImageData(0,0,320,240).data.slice();
 c.fillStyle='#ff00ff';c.globalAlpha=.8;assert(drawCompletionMarks(c,r));assert.equal(c.globalAlpha,.8);const outlined=c.getImageData(0,0,320,240).data.slice();c.globalAlpha=1;c.fillRect(319,239,1,1);assert.deepEqual([...c.getImageData(319,239,1,1).data],[255,0,255,255],'actual drawing state restores even when native Canvas fillStyle getter caches its last assignment');
 c.fillStyle='#5c94fc';c.fillRect(0,0,320,240);assert(drawCompletionMarks(c,{...r,completionMarksView:completionMarksView(r,new Set(['reward-sandbox\nreward-pink']),d.rooms)}));const complete=c.getImageData(0,0,320,240).data.slice(),b=completionMarkBounds(r.map.objects.find(q=>q.kind==='portal'));
 let green=0,white=0,changed=0;for(let y=0;y<240;y++)for(let x=0;x<320;x++){const i=(y*320+x)*4,inside=x>=b.x&&x<b.x+b.w&&y>=b.y&&y<b.y+b.h;if(!inside){assert.deepEqual(complete.subarray(i,i+4),background.subarray(i,i+4));assert.deepEqual(outlined.subarray(i,i+4),background.subarray(i,i+4));}else{if(complete[i]===22&&complete[i+1]===122&&complete[i+2]===67)green++;if(complete[i]===255&&complete[i+1]===255&&complete[i+2]===255)white++;if(complete[i]!==outlined[i]||complete[i+1]!==outlined[i+1]||complete[i+2]!==outlined[i+2])changed++;}}
 assert(green>10);assert(white>10);assert(changed>30);assert.deepEqual(d,before);
 c.clearRect(0,0,320,240);assert.equal(drawCompletionMarks(c,{...r,renderBounds:{x:128,y:0,w:192,h:240}}),false);
});

test('shared renderer passes native mark projections and draws the same green check with no legacy view field',()=>{
 const d=completionMarksProject(),r=d.rooms[0],marks=completionMarksView(r,new Set(['reward-sandbox\nreward-pink']),d.rooms),view={smm2Mechanics:{version:1,completionMarks:marks}},shared=rendererRoom(r,view),a=createCanvas(320,240),b=createCanvas(320,240);assert.equal(shared.completionMarksView,marks);drawCompletionMarks(a.getContext('2d'),shared);drawSmm2World(b.getContext('2d'),shared,view,0);assert.deepEqual(a.toBuffer('image/png'),b.toBuffer('image/png'));
 const legacy=completionMarksProject({marks:false}).rooms[0];assert.equal(Object.hasOwn(rendererRoom(legacy,{smm2Mechanics:{version:1}}),'completionMarksView'),false);
});

test('atomic edits and native History preserve strict root-version-1 JSON roundtrip and undo/redo',()=>{
 const d=completionMarksProject({marks:false}),h=new History(d),r=()=>h.doc.rooms[0],spec=completionMarksProject().rooms[0].smm2Mechanics.completionMarks,before=JSON.stringify(h.doc);
 h.change(()=>setCompletionMarks(r(),spec,h.doc.rooms));roundtrip(h);assert.equal(h.doc.version,1);assert.equal(r().smm2Mechanics.completionMarks[0].completed,undefined);h.undo();assert.equal(JSON.stringify(h.doc),before);h.redo();roundtrip(h);assert.deepEqual(r().smm2Mechanics.completionMarks,spec);
 const saved=JSON.stringify(h.doc),n=h.undoStack.length;for(const edit of [q=>q.coinId='ordinary-coin',q=>q.completed=true,q=>q.rewardRoomId='missing-room']){const proposed=clone(spec);edit(proposed[0]);assert.throws(()=>h.change(()=>setCompletionMarks(r(),proposed,h.doc.rooms)));assert.equal(JSON.stringify(h.doc),saved);assert.equal(h.undoStack.length,n);}
 const proposal=clone(spec);proposal[0][Symbol('alias')]=true;assert.throws(()=>setCompletionMarks(r(),proposal,h.doc.rooms));assert.throws(()=>setCompletionMarks(r(),undefined,h.doc.rooms));assert.equal(JSON.stringify(h.doc),saved);
 h.change(()=>removeCompletionMarks(r()));roundtrip(h);assert.equal(r().smm2Mechanics.completionMarks,undefined);h.undo();assert.deepEqual(r().smm2Mechanics.completionMarks,spec);
});

test('global deletion pruning removes stale local portals, cross-room Pink and deleted reward rooms',()=>{
 for(const kind of ['portal','Pink','typed-list','room']){const d=completionMarksProject(),before=clone(d);if(kind==='portal')d.rooms[0].map.objects=d.rooms[0].map.objects.filter(q=>q.id!=='entry-portal');if(kind==='Pink')d.rooms[1].map.objects=d.rooms[1].map.objects.filter(q=>q.id!=='reward-pink');if(kind==='typed-list')delete d.rooms[1].smm2Mechanics.pinkCoins;if(kind==='room')d.rooms.splice(1,1);assert.equal(pruneCompletionMarksReferences(d.rooms,before.rooms),1);assert.equal(d.rooms[0].smm2Mechanics.completionMarks,undefined);assert.equal(pruneCompletionMarksReferences(d.rooms,before.rooms),0);assert(before.rooms[0].smm2Mechanics.completionMarks);}
 const local=completionMarksProject(),old=clone(local.rooms[0]);local.rooms[0].map.objects=local.rooms[0].map.objects.filter(q=>q.id!=='entry-portal');assert.equal(pruneCompletionMarksRoomReferences(local.rooms[0],old),1);
 const invalid=completionMarksProject(),before=clone(invalid);mark(invalid).coinId='newly-invalid';assert.equal(pruneCompletionMarksReferences(invalid.rooms,before.rooms),0);assert.throws(()=>validateCompletionMarksRooms(invalid.rooms));
});

test('native target deletion and global pruning stay inside one History undo/redo transaction',()=>{
 const h=new History(completionMarksProject());h.change(doc=>{const before=clone(doc),r=doc.rooms[1];deleteSelection(r,'objects',new Set(['reward-pink']));r.smm2Mechanics.pinkCoins=[];pruneCompletionMarksReferences(doc.rooms,before.rooms);});assert.equal(h.doc.rooms[0].smm2Mechanics.completionMarks,undefined);roundtrip(h);h.undo();assert(h.doc.rooms[0].smm2Mechanics.completionMarks);assert(h.doc.rooms[1].map.objects.some(q=>q.id==='reward-pink'));h.redo();assert.equal(h.doc.rooms[0].smm2Mechanics.completionMarks,undefined);roundtrip(h);
});

test('native full-project door-pair removal prunes completion bindings before its internal strict validation',()=>{
 const h=new History(completionMarksProject()),before=clone(h.doc);h.change(doc=>removeContraptionDoorPair(doc,'sandbox-link'));assert.equal(h.doc.rooms[0].smm2Mechanics.completionMarks,undefined);assert(!h.doc.rooms[0].map.objects.some(q=>q.id==='entry-portal'));assert(h.doc.rooms[1].map.objects.some(q=>q.id==='reward-pink'));roundtrip(h);h.undo();assert.deepEqual(h.doc,before);h.redo();roundtrip(h);
});

test('full strict import rejects missing targets while unrelated single-room author helpers remain usable',()=>{
 const missing=completionMarksProject();missing.rooms.pop();assert.throws(()=>parseProject(JSON.stringify(missing)),/reward room is missing/);assert.throws(()=>new History(missing),/reward room is missing/);validate(clone(missing),{allowIncompleteCompletionMarks:true});
 const invalid=clone(missing);invalid.rooms[0].smm2Mechanics.completionMarks[0].portalId='missing-portal';assert.throws(()=>validate(invalid,{allowIncompleteCompletionMarks:true}),/actual local portal/);
 const actions=[
  ['native SMM2 flags',r=>setSmm2FlagScore(r,false)],
  ['art profile',r=>setSmm2ArtProfile(r,'smb1-overworld-source')],
  ['camera framing',r=>setSmm2CameraFrame(r,{baseY:0,minY:0,riseTop:100})],
  ['classic decorations',r=>addClassicCloud(r,{x:160,y:64})],
  ['native scenery',r=>setNativeSceneryMode(r,'authored')],
  ['lighting',r=>setSmm2Lighting(r,{darkness:.5,playerRadius:56,softness:.25,sources:[]})],
  ['Bone Shell actor',r=>addSmm2BoneShell(r,{id:'authored-bone',x:144,y:128})],
  ['Bowser Jr actor',r=>addSmm2BowserJr(r,{id:'authored-junior',x:144,y:128})]
 ];
 for(const [name,action]of actions){const h=new History(completionMarksProject()),original=clone(mark(h.doc));assert.doesNotThrow(()=>h.change(doc=>action(doc.rooms[0])),name);assert.deepEqual(mark(h.doc),original,name+' retains cross-room binding');roundtrip(h);h.undo();assert.deepEqual(mark(h.doc),original);}
});

test('explicit full graph copy remaps portal, reward room, typed Pink and mark identities; partial selections carry no rule',()=>{
 const source=completionMarksProject(),r=source.rooms[0],selection=new Map([[r.roomId,new Set(['entry-portal'])]]);assert.equal(captureCompletionMarkBindings(r,selection,source.rooms),null);selection.set('reward-sandbox',new Set(['reward-pink']));const snapshot=captureCompletionMarkBindings(r,selection,source.rooms),target=completionMarksProject({marks:false});target.rooms[0].roomId='copied-lobby';target.rooms[1].roomId='copied-reward';target.rooms[0].map.objects.find(q=>q.kind==='portal').id='copied-portal';target.rooms[1].map.objects.find(q=>q.id==='reward-pink').id='copied-pink';target.rooms[1].smm2Mechanics.pinkCoins=[{id:'copied-pink'}];
 const maps={roomIds:new Map([['entry-lobby','copied-lobby'],['reward-sandbox','copied-reward']]),objectIds:new Map([['entry-lobby\nentry-portal','copied-portal'],['reward-sandbox\nreward-pink','copied-pink']]),markIds:new Map([['sandbox-mark','copied-mark']])};appendCopiedCompletionMarkBindings(target.rooms[0],snapshot,maps,target.rooms);assert.deepEqual(target.rooms[0].smm2Mechanics.completionMarks,[{id:'copied-mark',portalId:'copied-portal',rewardRoomId:'copied-reward',coinId:'copied-pink'}]);assert.deepEqual(snapshot.marks,source.rooms[0].smm2Mechanics.completionMarks);
 const before=JSON.stringify(target);assert.throws(()=>appendCopiedCompletionMarkBindings(target.rooms[0],snapshot,maps,target.rooms));assert.equal(JSON.stringify(target),before);maps.objectIds.delete('reward-sandbox\nreward-pink');assert.throws(()=>appendCopiedCompletionMarkBindings(target.rooms[0],snapshot,maps,target.rooms),/fresh Pink/);assert.equal(JSON.stringify(target),before);
});

test('actual JSON author panel uses native History, refreshes undo and atomically rejects a fake completed value',()=>{
 const dom=installSimulatedPlayDom();try{const h=new History(completionMarksProject()),parent=document.createElement('div'),reports=[],ui=mountCompletionMarksTools({parent,room:()=>h.doc.rooms[0],getRooms:()=>h.doc.rooms,change:fn=>h.change(fn),report:q=>reports.push(q)}),config=ui.panel.querySelector('[data-completion-marks="config"]'),apply=ui.panel.querySelector('[data-completion-marks="apply"]'),remove=ui.panel.querySelector('[data-completion-marks="remove"]');
 const proposal=JSON.parse(config.value);proposal[0].id='updated-mark';config.value=JSON.stringify(proposal);apply.onclick();assert.equal(mark(h.doc).id,'updated-mark');roundtrip(h);h.undo();ui.refresh();assert.equal(JSON.parse(config.value)[0].id,'sandbox-mark');h.redo();ui.refresh();assert.equal(JSON.parse(config.value)[0].id,'updated-mark');const old=JSON.stringify(h.doc);proposal[0].completed=true;config.value=JSON.stringify(proposal);apply.onclick();assert.equal(JSON.stringify(h.doc),old);assert.equal(reports.length,1);assert(config.value.includes('completed'),'failed draft remains reviewable');remove.onclick();assert.equal(h.doc.rooms[0].smm2Mechanics.completionMarks,undefined);h.undo();ui.refresh();assert.equal(JSON.parse(config.value)[0].id,'updated-mark');
 }finally{dom.restore();}
});
