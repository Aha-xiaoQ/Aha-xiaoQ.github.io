import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createCanvas,loadImage} from '@napi-rs/canvas';
import {fileURLToPath} from 'node:url';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {HEAVY_STONE_SOURCE_PIXELS as S} from '../atlas/editor-heavy-stone-source-pixels.mjs';
import {drawHeavyStoneSource,drawHeavyStoneSlope,drawHeavyStoneWorld} from '../atlas/editor-heavy-stone-art.mjs';
import {isSmb3ArtRoom,drawSmb3Background,drawSmb3Tile,drawSmb3Player,drawSmb3Actor,drawSmb3Scenery,drawSmb3World} from '../atlas/editor-smb3-art.mjs';
import {drawSmm2Tile,drawSmm2Actor,drawSmm2World} from '../atlas/editor-smm2-art.mjs';
import {background,drawTile,drawObject,drawPlayer,drawScenery} from '../atlas/editor-art.mjs';
const room=()=>({smm2Mechanics:{version:1,art:{palette:'smb3-desert',tileOriginY:208}},map:{width:4096,height:512,geometry:[],objects:[]},decorations:[]});
const canvas=(w=256,h=256)=>createCanvas(w,h),pix=(c,x,y)=>[...c.getContext('2d').getImageData(x,y,1,1).data],bytes=c=>c.getContext('2d').getImageData(0,0,c.width,c.height).data;
const source=(key,x,y)=>{const a=S[key],i=a.alphabet.indexOf(a.rows[y][x]);return a.palette[i][3]?[...a.palette[i]]:[0,0,0,0];};
const render=(fn,q,r=room(),tick=0)=>{const c=canvas();assert.equal(fn(c.getContext('2d'),q,tick,r),true);return c;};
function assertOpaque(c){const a=bytes(c);for(let n=3;n<a.length;n+=4)assert(a[n]===0||a[n]===255);}

test('all finite source rows retain original PNG identity and decoder RGBA without DOM',async()=>{
 const identities=JSON.parse(readFileSync(new URL('../assets/heavy-stone-source/SOURCE_PIXEL_IDENTITIES.json',import.meta.url)));
 for(const [key,a]of Object.entries(S)){const path=new URL('../assets/heavy-stone-source/'+a.file,import.meta.url),id=identities[a.file],file=readFileSync(path);assert.equal(createHash('sha256').update(file).digest('hex'),id.originalFileSha256,key);const rgba=Buffer.from(a.rows.flatMap(row=>[...row].flatMap(ch=>a.palette[a.alphabet.indexOf(ch)])));assert.equal(createHash('sha256').update(rgba).digest('hex'),id.decodedRgbaSha256,key);const image=await loadImage(fileURLToPath(path)),original=canvas(a.w,a.h),decoded=canvas(a.w,a.h);original.getContext('2d').drawImage(image,0,0);assert.equal(drawHeavyStoneSource(decoded.getContext('2d'),key),true);const mask=bytes(original),data=bytes(decoded);for(let n=0;n<data.length;n+=4){assert.equal(data[n+3],mask[n+3],key+' alpha');const expected=rgba[n+3]?[...rgba.subarray(n,n+4)]:[0,0,0,0];assert.deepEqual([...data.subarray(n,n+4)],expected,key+' decoded visible RGBA');}assert(Object.isFrozen(a.rows));assert(Object.isFrozen(a.palette));}
});

test('desert is explicit and ordinary desert rooms have no hard-coded goal curtain',()=>{
 const r=room();assert.equal(isSmb3ArtRoom(r),true);const c=canvas(384,216);drawSmb3Background(c.getContext('2d'),r,384,216);assert.deepEqual(pix(c,380,80),[247,195,176,255]);const off=canvas();assert.equal(drawSmb3Tile(off.getContext('2d'),{x:16,y:16,w:32,h:32,material:'desert-ground'},{}),false);assert.equal(drawSmb3Player(off.getContext('2d'),{x:32,y:32,w:10,h:14},0,{}),false);
});
test('background respects actual camera and native viewport at both Canvas scales',()=>{
 const r=room();r.renderBounds={x:194,y:208,w:384,h:216};r.smm2Mechanics.art.goalBackdropX=200;const a=canvas(384,216),b=canvas(768,432);background(a.getContext('2d'),r,384,216);background(b.getContext('2d'),r,768,432);for(let y=0;y<216;y+=7)for(let x=0;x<384;x+=7)assert.deepEqual(pix(a,x,y),pix(b,x*2,y*2));assert.deepEqual(pix(a,32,64),[0,0,0,255]);assert.notDeepEqual(pix(a,0,64),[0,0,0,255]);r.renderBounds.y=200;const moved=canvas(384,216);background(moved.getContext('2d'),r,384,216);assert.notDeepEqual(bytes(a),bytes(moved));
});
test('sand terrain retains original source top and repeating interior palette',()=>{
 const r=room(),q={id:'floor',x:16,y:40,w:96,h:64,material:'desert-ground'};r.map.geometry=[q];const c=canvas();drawSmb3Tile(c.getContext('2d'),q,r);for(let y=0;y<16;y++)for(let x=32;x<64;x++)assert.deepEqual(pix(c,q.x+x,q.y+y),source('ground',32+(q.x+x)%16,64+y));for(let y=24;y<48;y++)for(let x=32;x<64;x++)assert.deepEqual(pix(c,q.x+x,q.y+y),source('ground',32+(q.x+x)%16,80+((q.y+y-216)%16+16)%16));assertOpaque(c);
});
test('each semisolid preserves sixteen-pixel corners and all four source screws',()=>{
 for(const v of [1,2])for(const [w,h]of [[96,48],[48,96],[64,64]]){const q={x:16,y:16,w,h,smm2Art:'smb3-desert-semisolid-'+v},c=canvas();drawSmb3Tile(c.getContext('2d'),q,room());for(const [tx,ty,sx,sy]of [[0,0,0,0],[w-16,0,48,0],[0,h-16,0,48],[w-16,h-16,48,48]])for(let y=0;y<16;y++)for(let x=0;x<16;x++)assert.deepEqual(pix(c,16+tx+x,16+ty+y),source('semisolid'+v,sx+x,sy+y));assertOpaque(c);}
});
test('Mushroom cap left-middle-right pixels repeat without squeezing and stems remain separate',()=>{
 const r=room(),q={x:16,y:16,w:96,h:16,smm2Art:'smb3-desert-mushroom-red'},c=canvas();drawSmb3Tile(c.getContext('2d'),q,r);for(let y=0;y<16;y++)for(let x=0;x<96;x++)assert.deepEqual(pix(c,16+x,16+y),source('mushroomRed',x<16?x:x>=80?48-(96-x):16+(x-16)%16,y));assert.equal(pix(c,64,40)[3],0);const stem={x:56,y:32,w:16,h:80,smm2Art:q.smm2Art+'-stem'};drawSmb3Scenery(c.getContext('2d'),stem,r);for(let y=0;y<80;y++)for(let x=0;x<16;x++)assert.deepEqual(pix(c,56+x,32+y),source('mushroomRed',16+x,16+y%32));
 for(const color of ['orange','green']){const a=canvas();drawSmb3Tile(a.getContext('2d'),{...q,smm2Art:'smb3-desert-mushroom-'+color},r);assert.notDeepEqual(bytes(a),bytes(c));assertOpaque(a);const st=canvas();drawSmb3Scenery(st.getContext('2d'),{...stem,smm2Art:'smb3-desert-mushroom-'+color+'-stem'},r);assert.deepEqual(pix(st,stem.x+8,stem.y+1),source('mushroomRed',24,17),'both adapted stems retain the sand palette');}
});
test('bridge keeps native fifteen rows and eight-pixel transparent period above physical top',()=>{
 const q={x:16,y:48,w:80,h:8,smm2Art:'smb3-desert-bridge'},c=canvas();drawSmb3Tile(c.getContext('2d'),q,room());for(let y=0;y<15;y++)for(let x=0;x<80;x++)assert.deepEqual(pix(c,16+x,40+y),source('bridge',x%8,y));assert.equal(pix(c,20,55)[3],0);assertOpaque(c);
});
test('Stone keeps real sixteen-pixel bottom anchor through small physical bodies and held state',()=>{
 for(const q of [{id:'rock',kind:'portable-stone',x:48,y:48,w:16,h:16},{id:'rock',type:'stone',x:48,y:48,w:10,h:12,portableStone:{held:true}}]){const before=JSON.stringify(q),c=render(drawSmb3Actor,q),x=Math.round(q.x+(q.w-16)/2),y=q.y+q.h-16;for(let yy=0;yy<16;yy++)for(let xx=0;xx<16;xx++)assert.deepEqual(pix(c,x+xx,y+yy),source('stone',xx,yy));assert.equal(JSON.stringify(q),before);}
});
test('Twister verified editor icon reduces to thirteen by twelve with source transparency and bottom anchor',()=>{
 const q={x:48,y:48,w:16,h:16,kind:'walker',type:'local-twister',localUpdraft:true},c=render(drawSmb3Actor,q),left=Math.round(48+1.5);for(let y=0;y<12;y++)for(let x=0;x<13;x++)assert.deepEqual(pix(c,left+x,52+y),source('twisterIcon',25+x*6,20+y*6));assert.equal(pix(c,48,48)[3],0);assertOpaque(c);
});
test('compressed Note consumes one real y/h rectangle with no resting second layer',()=>{
 const r=room(),q={id:'note',x:32,y:40,w:16,h:8,resty:32,resth:16,material:'study-note',marioModuleDevice:true},a=canvas(),b=canvas();assert.equal(drawSmm2Tile(a.getContext('2d'),q,r),true);drawTile(b.getContext('2d'),q,r);assert.deepEqual(bytes(a),bytes(b));for(let y=32;y<40;y++)for(let x=32;x<48;x++)assert.equal(pix(a,x,y)[3],0);for(let y=48;y<56;y++)for(let x=32;x<48;x++)assert.equal(pix(a,x,y)[3],0);assertOpaque(a);
});
test('Small idle and jump preserve native source proportions, bottom anchoring and mirroring',()=>{
 for(const [key,grounded]of [['smallIdle',true],['smallJump',false]]){const r=room(),q={x:48,y:48,w:10,h:14,power:0,facing:1,grounded,vx:0},a=render(drawSmb3Player,q,r),b=render(drawSmb3Player,{...q,facing:-1},r),src=S[key],left=Math.round(q.x+(q.w-src.w)/2),top=q.y+q.h-src.h;for(let y=0;y<src.h;y++)for(let x=0;x<src.w;x++){assert.deepEqual(pix(a,left+x,top+y),source(key,x,y));assert.deepEqual(pix(b,left+src.w-1-x,top+y),source(key,x,y));}assertOpaque(a);}
});
test('real held Stone selects NES carry pixels with Maker palette and visible condition marker',()=>{
 const q={x:64,y:64,w:10,h:14,power:0,grounded:true,vx:0,facing:1,carriedStoneId:'rock'},c=render(drawSmb3Player,q),a=S.smallCarry,left=Math.round(q.x+(q.w-a.w)/2),top=q.y+q.h-a.h,map={'0,0,0,255':[31,31,31,255],'181,49,32,255':[247,57,16,255],'255,204,197,255':[255,217,178,255]};for(let y=0;y<16;y++)for(let x=0;x<16;x++){const p=source('smallCarry',x,y);assert.deepEqual(pix(c,left+x,top+y),map[p.join(',')]??p);}assert.equal(pix(c,47,46)[3],255);const idle=render(drawSmb3Player,{...q,carriedStoneId:undefined});assert.equal(pix(idle,47,46)[3],0);const hidden=render(drawSmb3Player,{...q,hidden:true});assert(bytes(hidden).every(n=>n===0));
});
test('additional run and Big proportion frames are read-only adaptations with source heads',()=>{
 const r=room(),base={x:64,y:64,w:10,h:28,power:1,grounded:true,vx:2,facing:1},a=render(drawSmb3Player,{...base,anim:0},r),b=render(drawSmb3Player,{...base,anim:12},r);assert.notDeepEqual(bytes(a),bytes(b));assertOpaque(a);for(let y=65;y<80;y++)for(let x=60;x<78;x++)assert.deepEqual(pix(a,x,y),pix(b,x,y));assert.equal(pix(a,68,65)[3],255,'Big adapted body starts at native twenty-seven-pixel bottom anchor');
});
test('desert slopes obey actual live polygon and clip source sand without cyan terrain',()=>{
 const q={kind:'slope',spec:{x:32,y:32,w:64,h:32,orientation:'rise-right'},polygon:[{x:32,y:64},{x:96,y:32},{x:96,y:64}]},r=room(),c=canvas();assert.equal(drawSmm2World(c.getContext('2d'),r,{smm2Mechanics:{surfaces:[q]}},0),true);assert.equal(pix(c,48,34)[3],0);assert.equal(pix(c,80,62)[3],255);const allowed=new Set(['0,0,0,255','255,217,178,255','255,170,71,255']);for(let y=0;y<c.height;y++)for(let x=0;x<c.width;x++){const p=pix(c,x,y);if(p[3])assert(allowed.has(p.join(',')));}assertOpaque(c);
});
test('Twister wind rings use field cone and moving actor, while World never paints a duplicate body',()=>{
 const r=room(),q={id:'wind',x:96,y:160,w:16,h:16,type:'local-twister',active:true,field:{windHeight:96,bottomHalfWidth:5,topHalfWidth:24}},v={smm2Mechanics:{localUpdrafts:{twisters:[q]}}},before=JSON.stringify(v),a=canvas(),b=canvas();assert.equal(drawSmb3World(a.getContext('2d'),r,v,0),true);assert.equal(drawHeavyStoneWorld(b.getContext('2d'),r,v,10),true);assert.notDeepEqual(bytes(a),bytes(b));assert.equal(JSON.stringify(v),before);for(let y=172;y<176;y++)for(let x=96;x<112;x++)assert.equal(pix(a,x,y)[3],0);const empty=canvas();drawHeavyStoneWorld(empty.getContext('2d'),r,{smm2Mechanics:{localUpdrafts:{twisters:[{...q,active:false}]}}},0);assert(bytes(empty).every(n=>n===0));assertOpaque(a);
});
test('pink parachute follows live flag and disappears after landing',()=>{
 const q={x:96,y:96,w:16,h:16,kind:'walker',type:'goomba',sourceParachute:true},r=room(),air=render(drawSmb3Actor,q,r),ground=render(drawSmb3Actor,{...q,sourceParachute:false},r);assert.equal(pix(air,104,80)[3],255);assert.equal(pix(ground,104,80)[3],0);for(let y=96;y<112;y++)for(let x=96;x<112;x++)assert.deepEqual(pix(air,x,y),pix(ground,x,y));
});
test('scenery uses world coordinates, actual bottom-contact signs and open outline hills',()=>{
 const r=room(),hill={x:32,y:16,w:32,h:80,smm2Art:'smb3-desert-outline-hill'},c=canvas();assert.equal(drawSmb3Scenery(c.getContext('2d'),hill,r),true);assert.equal(pix(c,48,50)[3],0);assert.equal(pix(c,32,70)[3],255);const sign=canvas();drawSmb3Scenery(sign.getContext('2d'),{x:96,y:32,w:40,h:64,smm2Art:'smb3-desert-sign'},r);assert.equal(pix(sign,112,95)[3],255);const floating=canvas();drawSmb3Scenery(floating.getContext('2d'),{x:96,y:32,w:40,h:64,smm2Art:'smb3-desert-sign',floating:true},r);assert.equal(pix(floating,112,95)[3],0);assertOpaque(c);
});
test('public editor and actor entry points share the same desert function and no source mutation',()=>{
 const r=room(),q={id:'rock',kind:'portable-stone',x:32,y:32,w:16,h:16},a=canvas(),b=canvas();drawObject(a.getContext('2d'),q,0,r);drawSmm2Actor(b.getContext('2d'),q,0,r);assert.deepEqual(bytes(a),bytes(b));const p={x:64,y:64,w:10,h:14,power:0,grounded:true,carriedStoneId:'rock'},pa=canvas(),pb=render(drawSmb3Player,p,r);drawPlayer(pa.getContext('2d'),p,0,undefined,r);assert.deepEqual(bytes(pa),bytes(pb));r.decorations=[{x:32,y:32,w:32,h:112,smm2Art:'smb3-desert-palm'}];const sa=canvas(),sb=canvas();drawScenery(sa.getContext('2d'),r);drawSmb3Scenery(sb.getContext('2d'),r.decorations[0],r);assert.deepEqual(bytes(sa),bytes(sb));
});

test('unknown-height semisolid top-strip preserves only source top screws and decoration ownership',()=>{
 const r=room(),body={id:'strip',x:32,y:32,w:96,h:1,smm2Art:'smb3-desert-semisolid-2-top-strip'},off=canvas();assert.equal(drawSmb3Tile(off.getContext('2d'),body,r),true);assert(bytes(off).every(n=>n===0));const q={...body,h:16},c=canvas();assert.equal(drawSmb3Scenery(c.getContext('2d'),q,r),true);for(let y=0;y<16;y++)for(let x=0;x<96;x++)assert.deepEqual(pix(c,32+x,32+y),source('semisolid2',x<16?x:x>=80?64-(96-x):16+(x-16)%32,y));assert.equal(pix(c,32,48)[3],0);
});
test('explicit shadow is a native three-pixel visual effect without source or actor mutation',()=>{
 const r=room(),q={id:'rock',kind:'portable-stone',x:48,y:48,w:16,h:16},before=JSON.stringify({r,q}),plain=render(drawSmb3Actor,q,r);r.smm2Mechanics.art.dropShadows=true;const b=JSON.stringify({r,q}),shadow=render(drawSmb3Actor,q,r);assert.equal(JSON.stringify({r,q}),b);assert.notDeepEqual(bytes(plain),bytes(shadow));const p=pix(shadow,65,64);assert(p[3]>0&&p[3]<255);for(let y=0;y<16;y++)for(let x=0;x<16;x++)if(source('stone',x,y)[3])assert.deepEqual(pix(shadow,48+x,48+y),source('stone',x,y));delete r.smm2Mechanics.art.dropShadows;assert.equal(JSON.stringify({r,q}),before);assert.deepEqual(bytes(render(drawSmb3Actor,q,r)),bytes(plain));
});
test('airborne carry keeps acquired carry head and combines acquired jump legs as an adaptation',()=>{
 const q={x:64,y:64,w:10,h:14,power:0,grounded:false,vx:2,facing:1,carriedStoneId:'rock'},c=render(drawSmb3Player,q),left=Math.round(q.x+(q.w-16)/2),top=q.y+q.h-16,map={'0,0,0,255':[31,31,31,255],'181,49,32,255':[247,57,16,255],'255,204,197,255':[255,217,178,255]};for(let y=0;y<16;y++)for(let x=0;x<16;x++){const p=source(y<11?'smallCarry':'smallJump',x,y);assert.deepEqual(pix(c,left+x,top+y),y<11?(map[p.join(',')]??p):p);}
});
test('visual wind height is independent from the explicitly fitted force field height',()=>{
 const r=room(),q={id:'wind',x:96,y:160,w:16,h:16,active:true,field:{windHeight:48,visualHeight:128,bottomHalfWidth:5,topHalfWidth:24}},c=canvas();drawHeavyStoneWorld(c.getContext('2d'),r,{smm2Mechanics:{localUpdrafts:{twisters:[q]}}},0);let upper=false;for(let y=40;y<120;y++)for(let x=70;x<134;x++)if(pix(c,x,y)[3])upper=true;assert(upper,'rings continue above the physical wind top');
});
test('source parachute also follows mushroom supply and goal card states freeze actual controller result',()=>{
 const r=room(),q={kind:'mushroom',x:96,y:96,w:16,h:16,sourceParachute:true},air=render(drawSmb3Actor,q,r),ground=render(drawSmb3Actor,{...q,sourceParachute:false},r);assert.equal(pix(air,104,80)[3],255);assert.equal(pix(ground,104,80)[3],0);r.smm2Mechanics.goalCard={id:'goal',cycle:['mushroom','flower','star','life'],framesPerCard:8};const hashes=[];for(const result of r.smm2Mechanics.goalCard.cycle){r.finish={card:true,result};const goal={id:'goal',kind:'exit',x:96,y:64,w:24,h:24},a=render(drawSmb3Actor,goal,r,0),b=render(drawSmb3Actor,goal,r,99);assert.deepEqual(bytes(a),bytes(b));hashes.push(Buffer.from(bytes(a)).toString('base64'));assert.deepEqual(pix(a,96,64),[255,255,255,255]);}assert.equal(new Set(hashes).size,4);
});

test('static room parachute binding previews canopy while runtime closed state remains authoritative',()=>{
 const r=room(),base={id:'bound-goomba',x:96,y:96,w:16,h:16,kind:'walker',type:'goomba'};r.smm2Mechanics.parachuteActors={version:1,actors:[{id:base.id,variant:'goomba'}]};const before=JSON.stringify({r,base}),preview=render(drawSmb3Actor,base,r);assert.equal(pix(preview,104,80)[3],255);assert.equal(JSON.stringify({r,base}),before);const closed=render(drawSmb3Actor,{...base,sourceParachute:true,parachuteActor:{open:false,phase:'closed'}},r);assert.equal(pix(closed,104,80)[3],0);const live=render(drawSmb3Actor,{...base,sourceParachute:false,parachuteActor:{open:true,phase:'open'}},r);assert.equal(pix(live,104,80)[3],255);r.smm2Mechanics.placedItems=[{id:'bound-mushroom',kind:'mushroom'}];r.smm2Mechanics.parachuteActors.actors.push({id:'bound-mushroom',variant:'super-mushroom'});const supply=render(drawSmb3Actor,{...base,id:'bound-mushroom',type:undefined},r);assert.equal(pix(supply,104,80)[3],255);
});
test('source unclassified purple band style aliases visual-only magenta artwork',()=>{
 const r=room(),q={id:'band',x:16,y:32,w:96,h:8,material:'decoration',collision:null,smm2Art:'smb3-desert-unclassified-purple-band'},before=JSON.stringify(q),a=canvas(),b=canvas();assert.equal(drawSmb3Tile(a.getContext('2d'),q,r),true);assert.equal(drawSmb3Tile(b.getContext('2d'),{...q,smm2Art:'smb3-desert-purple-strip'},r),true);assert.deepEqual(bytes(a),bytes(b));assert.deepEqual(pix(a,24,35),[170,31,190,255]);assert.equal(JSON.stringify(q),before);assert.equal(q.collision,null);
});
