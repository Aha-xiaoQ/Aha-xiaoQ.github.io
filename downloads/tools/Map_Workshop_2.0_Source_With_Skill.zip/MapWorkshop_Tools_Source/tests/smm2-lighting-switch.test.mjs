import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createCanvas} from '@napi-rs/canvas';
import {History,parseProject,clone,moveSelection} from '../atlas/editor-model.mjs';
import {validateSmm2LightingRoom,parseSmm2Lighting,resolveSmm2LightSources,drawSmm2LightingMask} from '../atlas/editor-smm2-lighting.mjs';
import {setSmm2Lighting,setSmm2LightingOffRadiusScale,clearSmm2LightingOffRadiusScale,clearSmm2Lighting,cloneSmm2Component} from '../atlas/editor-smm2-authoring.mjs';
import {mountSmm2LightingTools} from '../atlas/editor-smm2-lighting-tools.mjs';
import {createCollection,addLevel,parseCollection,serializeCollection,buildCollection} from '../atlas/editor-collection.mjs';
import {lightingProject} from './fixtures/lighting-native.mjs';
import {lightingSwitchProject,assertSwitchLightingStage,assertSwitchLightView} from './fixtures/lighting-switch-native.mjs';
import {nativeSession,character} from './fixtures/shell-coin-native.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';

test('OFF scale is an optional finite leaf requiring the existing version 1 ON/OFF component',()=>{
 const original=lightingProject(),before=JSON.stringify(original),r=original.rooms[0];validateSmm2LightingRoom(r);assert(!Object.hasOwn(parseSmm2Lighting(r),'offRadiusScale'));assert.equal(JSON.stringify(original),before);
 for(const scale of [undefined,null,'0.5',NaN,Infinity,-Infinity,.049,1.001]){const d=lightingSwitchProject();d.rooms[0].smm2Mechanics.lighting.offRadiusScale=scale;assert.throws(()=>validateSmm2LightingRoom(d.rooms[0]),/OFF radius scale/);}
 for(const scale of [.05,1]){const d=lightingSwitchProject({scale});assert.equal(parseProject(JSON.stringify(d)).rooms[0].smm2Mechanics.lighting.offRadiusScale,scale);}
 for(const switchStudy of [undefined,{version:2}]){const d=lightingSwitchProject();d.rooms[0].switchStudy=switchStudy;assert.throws(()=>validateSmm2LightingRoom(d.rooms[0]),/switchStudy version 1/);}
 const d=lightingSwitchProject();d.rooms[0].smm2Mechanics.lighting.sources.push({targetId:'on-off',radius:32});assert.throws(()=>validateSmm2LightingRoom(d.rooms[0]),/stable preplaced target/);
});

test('runtime never impersonates live ON/OFF with initialOn; preview explicitly uses only the initial state',()=>{
 const d=lightingSwitchProject({initialOn:false,scale:.4}),r=d.rooms[0],v=nativeSession(d).view(),before=JSON.stringify({r,v});
 const off=resolveSmm2LightSources(r,v),on=resolveSmm2LightSources(r,{...v,switchStudy:{version:1,on:true}});assert(off.length>3);assert.deepEqual(off.map(q=>q.radius),on.map(q=>q.radius*.4));
 assert.deepEqual(resolveSmm2LightSources(r,{...v,switchStudy:{version:1,on:true}},{preview:true}),resolveSmm2LightSources(r,null,{preview:true}));
 assert.equal(resolveSmm2LightSources(r,null,{preview:true})[0].radius,r.smm2Mechanics.lighting.playerRadius*.4);
 for(const switchStudy of [undefined,null,{version:1,initialOn:false},{version:2,on:false},{version:1,on:'false'}])assert.deepEqual(resolveSmm2LightSources(r,{...v,switchStudy}),[]);
 assert.deepEqual(resolveSmm2LightSources(r,{...v,roomId:'wrong'}),[]);assert.deepEqual(resolveSmm2LightSources(r,null),[]);assert.equal(JSON.stringify({r,v}),before);
 const legacy=clone(r);delete legacy.smm2Mechanics.lighting.offRadiusScale;assert.equal(resolveSmm2LightSources(legacy,{...v,switchStudy:undefined})[0].radius,legacy.smm2Mechanics.lighting.playerRadius);
});

test('genuine native underside input changes every existing light with global Stage state and leaves physics identical',()=>{
 const d=lightingSwitchProject(),report=assertSwitchLightingStage(d,{resolve:resolveSmm2LightSources});assert.equal(report.naturalHeadHits,2);assert.equal(report.offShrinksAll,true);
 const plain=clone(d);delete plain.rooms[0].smm2Mechanics.lighting.offRadiusScale;const a=nativeSession(d),b=nativeSession(plain);
 for(let i=0;i<100;i++){const input=i>=3&&i<48||i>=50?{jump:true}:{};assert.deepEqual(a.step(input),b.step(input));assertSwitchLightView(a.doc.rooms[0],a.view(),resolveSmm2LightSources);}
});

test('global OFF persists into another room and spent POW emits no reduced ghost light',()=>{
 const d=lightingSwitchProject(),r=d.rooms[0],other=clone(r);other.roomId='second';other.map.id='second-map';r.map.objects.push({id:'portal',kind:'portal',x:48,y:200,w:16,h:24,targetRoom:'second',targetSpawn:'start'});d.rooms.push(other);
 const s=nativeSession(d);s.frames(3);s.until(v=>v.switchStudy.toggles===1,{jump:true},30);s.frames(40);s.step({interact:true});assert.equal(s.view().roomId,'second');assert.equal(s.view().switchStudy.on,false);assertSwitchLightView(s.doc.rooms[1],s.view(),resolveSmm2LightSources);
 const powDoc=lightingSwitchProject({initialOn:false}),powRoom=powDoc.rooms[0];powRoom.map.objects=powRoom.map.objects.filter(q=>['start','falling-pow'].includes(q.id));Object.assign(powRoom.map.objects[0],{x:336,y:210});powRoom.map.objects[1].y=180;powRoom.smm2Mechanics.powBlocks[0].gravity=0;delete powRoom.smm2Mechanics.pSwitches;powRoom.smm2Mechanics.lighting.sources=[{targetId:'falling-pow',radius:24}];
 const p=nativeSession(powDoc);p.frames(3);assert.equal(resolveSmm2LightSources(powRoom,p.view()).find(q=>q.targetId==='falling-pow').radius,12);const v=p.until(v=>!v.items.some(q=>q.id==='falling-pow'),{jump:true},30);assert(p.events.some(q=>q.event==='pow-activate'&&q.contact.nativeHeadHit));assert(!resolveSmm2LightSources(powRoom,v).some(q=>q.targetId==='falling-pow'));assert.equal(v.switchStudy.on,false);
});

test('real Canvas mask shrinks Mario and explicit target circles for OFF and keeps source positions unchanged',()=>{
 const r=lightingSwitchProject().rooms[0];r.smm2Mechanics.lighting={darkness:1,playerRadius:40,softness:0,offRadiusScale:.5,sources:[{targetId:'stable-p',radius:40}]};
 const v={roomId:r.roomId,p:{x:59,y:57,w:10,h:14},items:[{id:'stable-p',x:192,y:56,w:16,h:16}],switchStudy:{version:1,on:true}};
 const render=on=>{const canvas=createCanvas(256,128),ctx=canvas.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,256,128);drawSmm2LightingMask(ctx,r,{...v,switchStudy:{version:1,on}},{camera:{x:0,y:0,width:256,height:128},createCanvas});return ctx;};
 for(const x of [64,200]){assert.equal(render(true).getImageData(x+30,64,1,1).data[0],255);assert.equal(render(false).getImageData(x+30,64,1,1).data[0],0);assert.equal(render(false).getImageData(x,64,1,1).data[0],255);}
});

test('set/clear APIs, History, component clone/move, qmap and collection preserve the optional scale',()=>{
 const h=new History(lightingSwitchProject()),r=()=>h.doc.rooms[0],switchBefore=JSON.stringify(r().switchStudy),physics=JSON.stringify(r().map);
 h.change(()=>clearSmm2LightingOffRadiusScale(r()));assert(!Object.hasOwn(r().smm2Mechanics.lighting,'offRadiusScale'));h.undo();assert.equal(r().smm2Mechanics.lighting.offRadiusScale,.5);h.redo();h.change(()=>setSmm2LightingOffRadiusScale(r(),.3));assert.equal(JSON.stringify(r().map),physics);assert.equal(JSON.stringify(r().switchStudy),switchBefore);
 const before=JSON.stringify(h.doc);assert.throws(()=>h.change(()=>setSmm2LightingOffRadiusScale(r(),2)));assert.equal(JSON.stringify(h.doc),before);
 h.change(()=>cloneSmm2Component(r(),'stable-p',{id:'p-copy',dx:32}));assert.equal(r().smm2Mechanics.lighting.offRadiusScale,.3);assert(r().smm2Mechanics.lighting.sources.some(q=>q.targetId==='p-copy'));h.change(()=>moveSelection(r(),'objects',new Set(['p-copy']),16,0));assert.equal(r().smm2Mechanics.lighting.offRadiusScale,.3);assert.deepEqual(parseProject(JSON.stringify(h.doc)),h.doc);assert.equal(clone(r()).smm2Mechanics.lighting.offRadiusScale,.3);
 const c=addLevel(createCollection('Neutral switch light collection'),h.doc,{id:'switch-lights'}),again=parseCollection(serializeCollection(c)),built=buildCollection(again,character,{includePending:true});assert.equal(again.levels[0].project.rooms[0].smm2Mechanics.lighting.offRadiusScale,.3);assert.equal(built.levels[0].rooms[0].smm2Mechanics.lighting.offRadiusScale,.3);assert(built.requiredCapabilities.includes('switch-linked-night-lighting-v1'));assert(built.levels[0].requiredCapabilities.includes('switch-linked-night-lighting-v1'));assert(!Object.hasOwn(built.levels[0].pack.maps[0],'smm2Mechanics'));
 h.change(()=>clearSmm2Lighting(r()));assert.equal(parseSmm2Lighting(r()),null);h.undo();assert.equal(r().smm2Mechanics.lighting.offRadiusScale,.3);
 const noSwitch=lightingProject().rooms[0];assert.throws(()=>setSmm2LightingOffRadiusScale(noSwitch,.5),/switchStudy/);const noLighting=lightingSwitchProject().rooms[0];clearSmm2Lighting(noLighting);assert.throws(()=>setSmm2LightingOffRadiusScale(noLighting,.5),/Enable lighting/);assert.equal(clearSmm2LightingOffRadiusScale(noLighting),undefined);
});

test('actual sidebar checkbox and scale work through History and ordinary apply never injects the leaf',()=>{
 const ui=installSimulatedPlayDom();try{
  const d=lightingSwitchProject();delete d.rooms[0].smm2Mechanics.lighting.offRadiusScale;const h=new History(d),r=()=>h.doc.rooms[0],parent=ui.document.createElement('aside'),reports=[],panel=mountSmm2LightingTools({parent,room:r,change:fn=>h.change(fn),report:q=>reports.push(q)}),get=id=>parent.querySelector('[data-lighting="'+id+'"]');
  assert.equal(get('offLinked').disabled,false);assert.equal(get('offLinked').checked,false);assert.equal(get('offRadiusScale').disabled,true);get('apply').click();assert(!Object.hasOwn(r().smm2Mechanics.lighting,'offRadiusScale'));
  get('offRadiusScale').value='.4';get('offLinked').checked=true;get('offLinked').dispatchEvent({type:'change'});assert.equal(r().smm2Mechanics.lighting.offRadiusScale,.4);assert.equal(get('offRadiusScale').disabled,false);
  get('offRadiusScale').value='.25';get('darkness').value='.85';get('apply').click();assert.equal(r().smm2Mechanics.lighting.offRadiusScale,.25);assert.equal(r().smm2Mechanics.lighting.darkness,.85);h.undo();panel.refresh();assert.equal(Number(get('offRadiusScale').value),.4);h.redo();panel.refresh();assert.equal(Number(get('offRadiusScale').value),.25);
  const before=JSON.stringify(h.doc),undos=h.undoStack.length;get('offRadiusScale').value='0';get('apply').click();assert.equal(JSON.stringify(h.doc),before);assert.equal(h.undoStack.length,undos);assert(reports.length);get('offLinked').checked=false;get('offLinked').dispatchEvent({type:'change'});assert(!Object.hasOwn(r().smm2Mechanics.lighting,'offRadiusScale'));h.undo();panel.refresh();assert.equal(get('offLinked').checked,true);
  const plain=new History(lightingProject()),plainParent=ui.document.createElement('aside');mountSmm2LightingTools({parent:plainParent,room:()=>plain.doc.rooms[0],change:fn=>plain.change(fn),report:q=>reports.push(q)});assert.equal(plainParent.querySelector('[data-lighting="offLinked"]').disabled,true);assert.equal(plainParent.querySelector('[data-lighting="offRadiusScale"]').disabled,true);plainParent.querySelector('[data-lighting="apply"]').click();assert(!Object.hasOwn(plain.doc.rooms[0].smm2Mechanics.lighting,'offRadiusScale'));
 }finally{ui.restore();}
});
