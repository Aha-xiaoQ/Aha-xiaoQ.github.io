import {test} from 'node:test';
import assert from 'node:assert/strict';
import {blank,History,parseProject,validate} from '../atlas/editor-model.mjs';
import {addSmm2Conveyor,updateSmm2Conveyor,removeSmm2Conveyor,cloneSmm2Conveyor,listSmm2Conveyors,conveyorAuthoringIssues,setSmm2NpcSpringContact,clearSmm2NpcSpringContact,mountSmm2Tools,defaultSmm2Conveyor,captureSmm2ActorLeaves,appendCopiedSmm2ActorLeaves} from '../atlas/editor-smm2-tools.mjs';
import {CONVEYOR_CONTACT_MODE,CONVEYOR_PARAMETER_STATUS} from '../atlas/editor-conveyor-surfaces.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';

function project(){const doc=blank('Neutral conveyor authoring',640,384),room=doc.rooms[0];room.map.geometry=[{id:'floor',x:0,y:352,w:640,h:32,material:'ground',collision:'solid'},{id:'fixed-spring',x:480,y:320,w:16,h:16,material:'spring',collision:'solid',springOrientation:'vertical'}];Object.assign(room.map.objects[0],{x:16,y:338,w:10,h:14});room.smm2Mechanics={version:1,springs:[{id:'fixed-spring',orientation:'vertical',launchSpeed:7,compressionFrames:9,cooldownFrames:11}]};return doc;}
function panelSession(doc=project(),picked=new Set()){const ui=installSimulatedPlayDom(),history=new History(doc),room=()=>history.doc.rooms[0],parent=ui.document.createElement('aside'),reports=[];const panel=mountSmm2Tools({parent,room,selected:()=>picked,change:fn=>history.change(fn),report:value=>reports.push(value)});return {ui,history,room,reports,panel,get:id=>parent.querySelector('[data-smm2-control="'+id+'"]')};}
const slopeSpec=()=>({id:'authored-incline',topEndpoints:[{x:224,y:96},{x:272,y:64}],visual:{kind:'line',rect:{x:216,y:64,w:64,h:48},rollerCenters:[{x:224,y:104},{x:272,y:72}],rollerRadiusPx:8},speedPxPerSecond:48,directionOn:-1,contactMode:CONVEYOR_CONTACT_MODE,parameterStatus:CONVEYOR_PARAMETER_STATUS});

test('real conveyor add/update/clone/remove transactions roundtrip and undo while geometry stays outside native collider ABI',()=>{
 const history=new History(project()),room=()=>history.doc.rooms[0],native=JSON.stringify(room().map),base=JSON.stringify(history.doc);let id,copy;
 history.change(()=>{id=addSmm2Conveyor(room(),{id:'authored-flat'});});
 assert.equal(JSON.stringify(room().map),native);assert.equal(listSmm2Conveyors(room())[0].id,id);
 history.change(()=>updateSmm2Conveyor(room(),id,{speedPxPerSecond:90,directionOn:-1}));
 const original=structuredClone(room().smm2Mechanics.conveyors[0]);
 history.change(()=>{copy=cloneSmm2Conveyor(room(),id,{id:'independent-copy',dx:160,dy:32});});
 const cloned=room().smm2Mechanics.conveyors.find(q=>q.id===copy);assert.equal(cloned.speedPxPerSecond,90);assert.equal(cloned.directionOn,-1);assert.equal(cloned.topEndpoints[0].x,original.topEndpoints[0].x+160);assert.equal(cloned.visual.rollerCenters[0].y,original.visual.rollerCenters[0].y+32);
 history.change(()=>removeSmm2Conveyor(room(),copy));assert.equal(room().smm2Mechanics.conveyors.length,1);history.undo();assert.equal(room().smm2Mechanics.conveyors.length,2);history.redo();
 assert.deepEqual(parseProject(JSON.stringify(history.doc)),history.doc);assert.equal(JSON.stringify(room().map),native);
 while(history.undoStack.length)history.undo();assert.equal(JSON.stringify(history.doc),base);
});

test('illegal fields, IDs, bounds, proof claims, stale geometry and forbidden duplicate tops reject atomically',()=>{
 const room=project().rooms[0],id=addSmm2Conveyor(room,{id:'authored-flat'}),before=JSON.stringify(room);
 for(const action of [()=>updateSmm2Conveyor(room,id,{script:'carry'}),()=>updateSmm2Conveyor(room,id,{id:'changed'}),()=>updateSmm2Conveyor(room,id,{speedPxPerSecond:0}),()=>updateSmm2Conveyor(room,id,{parameterStatus:'original-calibrated'}),()=>updateSmm2Conveyor(room,id,{topEndpoints:[{x:128,y:80},{x:256,y:70}]}),()=>cloneSmm2Conveyor(room,id,{dx:0,dy:0}),()=>cloneSmm2Conveyor(room,id,{dx:1000}),()=>cloneSmm2Conveyor(room,id,{dx:16,dy:32,script:true}),()=>addSmm2Conveyor(room,{id:'floor'}),()=>removeSmm2Conveyor(room,'missing')]){assert.throws(action);assert.equal(JSON.stringify(room),before);}
 for(const badId of ['',null,0]){assert.throws(()=>addSmm2Conveyor(room,{id:badId}));assert.throws(()=>cloneSmm2Conveyor(room,id,{id:badId}));assert.equal(JSON.stringify(room),before);}
 assert.deepEqual(conveyorAuthoringIssues(room),[]);
});

test('actual top placement rejects buried solids and pickups but permits source-like empty slope bounding space and aligned support edges',()=>{
 const solid=project().rooms[0];solid.map.geometry.push({id:'wall',x:144,y:64,w:16,h:32,material:'stone',collision:'solid'});const solidBefore=JSON.stringify(solid);assert.throws(()=>addSmm2Conveyor(solid),/CONVEYOR_TOP_SOLID_OVERLAP/);assert.equal(JSON.stringify(solid),solidBefore);
 const pickup=project().rooms[0];pickup.map.objects.push({id:'independent-coin',kind:'coin',x:150,y:74,w:8,h:14});const pickupBefore=JSON.stringify(pickup);assert.throws(()=>addSmm2Conveyor(pickup),/CONVEYOR_TOP_PICKUP_OVERLAP/);assert.equal(JSON.stringify(pickup),pickupBefore);
 const legal=project().rooms[0];legal.map.geometry.push({id:'stair-under-empty-box',x:256,y:96,w:16,h:16,material:'ground',collision:'solid'},{id:'left-bottom-support',x:216,y:112,w:64,h:16,material:'ground',collision:'solid'});addSmm2Conveyor(legal,slopeSpec());assert.deepEqual(conveyorAuthoringIssues(legal),[]);validate({format:'xiaoq-map-project',version:1,id:'legal-shape',title:'Legal shape',rooms:[legal]});
 const above=project().rooms[0];above.map.geometry.push({id:'touching-base',x:128,y:96,w:128,h:16,material:'ground',collision:'solid'});above.map.objects.push({id:'standing-coin',kind:'coin',x:150,y:66,w:8,h:14});addSmm2Conveyor(above);assert.deepEqual(conveyorAuthoringIssues(above),[]);
 // No underside contract is invented to reject a below-top visual overlap.
 const below=project().rooms[0];below.map.objects.push({id:'below-unverified-face',kind:'coin',x:150,y:82,w:8,h:8});addSmm2Conveyor(below);assert.deepEqual(conveyorAuthoringIssues(below),[]);
});

test('actual slope polygon intersection is checked rather than skipped or replaced with a filled bounding rectangle',()=>{
 const room=project().rooms[0];room.smm2Mechanics.slopes=[{id:'real-triangle',x:128,y:64,w:128,h:64,orientation:'rise-left',collision:'solid'}];const before=JSON.stringify(room);assert.throws(()=>addSmm2Conveyor(room),/CONVEYOR_TOP_SOLID_OVERLAP.*real-triangle/);assert.equal(JSON.stringify(room),before);
 const empty=project().rooms[0];empty.smm2Mechanics.slopes=[{id:'empty-half',x:128,y:64,w:128,h:64,orientation:'rise-right',collision:'solid'}];const spec=defaultSmm2Conveyor();spec.topEndpoints=[{x:128,y:64},{x:176,y:64}];spec.visual={kind:'rect',rect:{x:128,y:64,w:48,h:16},rollerCenters:[{x:136,y:72},{x:168,y:72}],rollerRadiusPx:8};addSmm2Conveyor(empty,spec);assert.deepEqual(conveyorAuthoringIssues(empty),[]);
});

test('real conveyor panel edits exact endpoints, speed and ON direction, previews native art, and rejects blank edits without undo entries',()=>{
 const s=panelSession();try{
  const {get,history,room,reports}=s;assert(get('conveyor-contact-mode').readOnly);assert.equal(get('conveyor-contact-mode').value,CONVEYOR_CONTACT_MODE);assert.equal(get('conveyor-parameter-status').value,CONVEYOR_PARAMETER_STATUS);
  get('conveyor-kind').value='line';get('conveyor-start-x').value='128';get('conveyor-start-y').value='96';get('conveyor-end-x').value='176';get('conveyor-end-y').value='64';get('conveyor-direction').value='-1';get('conveyor-speed').value='48';get('conveyor-fit-visual').click();get('conveyor-add').click();
  const first=room().smm2Mechanics.conveyors[0];assert(first,reports.join('; '));assert.deepEqual(first.topEndpoints,[{x:128,y:96},{x:176,y:64}]);assert.deepEqual(first.visual.rollerCenters,[{x:128,y:104},{x:176,y:72}]);assert.equal(first.directionOn,-1);assert.equal(first.speedPxPerSecond,48);assert.equal(get('conveyor-select').value,first.id);
  const saved=JSON.stringify(history.doc),undos=history.undoStack.length;get('conveyor-speed').value='';get('conveyor-apply').click();assert.equal(JSON.stringify(history.doc),saved);assert.equal(history.undoStack.length,undos);
  get('conveyor-speed').value='72';get('conveyor-apply').click();assert.equal(room().smm2Mechanics.conveyors[0].speedPxPerSecond,72);history.undo();s.panel.refresh();assert.equal(Number(get('conveyor-speed').value),48);history.redo();s.panel.refresh();
  get('conveyor-preview-state').value='off';get('conveyor-preview-state').dispatchEvent({type:'change'});assert.equal(get('conveyor-preview-state').value,'off');
  get('conveyor-clone').click();assert.equal(room().smm2Mechanics.conveyors.length,2,reports.join('; '));const copied=get('conveyor-select').value;assert.notEqual(copied,first.id);get('conveyor-remove').click();assert.equal(room().smm2Mechanics.conveyors.length,1);assert.deepEqual(parseProject(JSON.stringify(history.doc)),history.doc);
 }finally{s.ui.restore();}
});

test('NPC Spring authoring preserves independent player tuning, validates static vertical proof scope and survives real panel toggle/undo',()=>{
 const doc=project(),room=doc.rooms[0],playerRule=structuredClone(room.smm2Mechanics.springs[0]);setSmm2NpcSpringContact(room,'fixed-spring',{compressionFrames:8,launchSpeed:10,compressionDepth:6});const enabled=room.smm2Mechanics.springs[0];assert.deepEqual({...enabled,npcContact:undefined},{...playerRule,npcContact:undefined});
 const before=JSON.stringify(room);for(const options of [{compressionFrames:0,launchSpeed:10},{compressionFrames:8,launchSpeed:0},{compressionFrames:8,launchSpeed:10,compressionDepth:16},{compressionFrames:8,launchSpeed:10,script:true}]){assert.throws(()=>setSmm2NpcSpringContact(room,'fixed-spring',options));assert.equal(JSON.stringify(room),before);}
 const moving=project().rooms[0];moving.map.geometry.find(q=>q.id==='fixed-spring').motion={axis:'x',min:400,max:500,speed:1};assert.throws(()=>setSmm2NpcSpringContact(moving,'fixed-spring',{compressionFrames:8,launchSpeed:10}),/static vertical/);
 clearSmm2NpcSpringContact(room,'fixed-spring');assert.deepEqual(room.smm2Mechanics.springs[0],playerRule);
 const s=panelSession(doc,new Set(['fixed-spring']));try{const {get,history,room,reports}=s;assert.equal(get('npc-spring-select').value,'fixed-spring');get('npc-spring-enabled').checked=true;get('npc-spring-frames').value='7';get('npc-spring-speed').value='9';get('npc-spring-depth').value='5';get('npc-spring-apply').click();assert.deepEqual(room().smm2Mechanics.springs[0].npcContact,{compressionFrames:7,launchSpeed:9,compressionDepth:5},reports.join('; '));assert.equal(room().smm2Mechanics.springs[0].launchSpeed,7);get('npc-spring-enabled').checked=false;get('npc-spring-apply').click();assert.equal(room().smm2Mechanics.springs[0].npcContact,undefined);history.undo();s.panel.refresh();assert.equal(get('npc-spring-enabled').checked,true);assert.deepEqual(parseProject(JSON.stringify(history.doc)),history.doc);}finally{s.ui.restore();}
});

test('existing native actor clipboard retains its ABI and leaves independently authored conveyor IDs and geometry untouched',()=>{
 const room=project().rooms[0];addSmm2Conveyor(room,{id:'independent-surface'});const conveyors=JSON.stringify(room.smm2Mechanics.conveyors),snapshot=captureSmm2ActorLeaves(room,new Set(['start']));appendCopiedSmm2ActorLeaves(room,snapshot,new Map([['start','start-copy']]));assert.equal(JSON.stringify(room.smm2Mechanics.conveyors),conveyors);assert.equal(room.map.geometry.length,2);assert.equal(room.map.objects.length,1);
});
