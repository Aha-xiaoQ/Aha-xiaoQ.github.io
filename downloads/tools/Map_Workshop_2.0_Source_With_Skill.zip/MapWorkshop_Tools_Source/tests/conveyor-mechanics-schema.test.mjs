import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {blank, validate, parseProject, History} from '../atlas/editor-model.mjs';
import {validateSmm2MechanicsRoom} from '../atlas/editor-smm2-mechanics.mjs';
import {CONVEYOR_CONTACT_MODE, CONVEYOR_PARAMETER_STATUS, conveyorPlacementIssues} from '../atlas/editor-conveyor-surfaces.mjs';
import {projectPack} from '../atlas/editor-runtime.mjs';

const belt = (overrides = {}) => ({
  id: 'schema-belt', topEndpoints: [{x: 64, y: 96}, {x: 192, y: 96}],
  visual: {kind: 'rect', rect: {x: 64, y: 96, w: 128, h: 16}, rollerCenters: [{x: 72, y: 104}, {x: 184, y: 104}], rollerRadiusPx: 8},
  speedPxPerSecond: 48, visualTreadSpeedPxPerSecond: 120,
  directionOn: -1, contactMode: CONVEYOR_CONTACT_MODE, parameterStatus: CONVEYOR_PARAMETER_STATUS,
  ...overrides
});
const incline = () => ({
  id: 'schema-incline', topEndpoints: [{x: 208, y: 96}, {x: 256, y: 64}],
  visual: {kind: 'line', rect: {x: 200, y: 64, w: 64, h: 48}, rollerCenters: [{x: 208, y: 104}, {x: 256, y: 72}], rollerRadiusPx: 8},
  speedPxPerSecond: 36, directionOn: -1,
  contactMode: CONVEYOR_CONTACT_MODE, parameterStatus: CONVEYOR_PARAMETER_STATUS
});
function project(mechanics = {version: 1}) {
  const doc = blank('Neutral conveyor schema probe', 384, 224), room = doc.rooms[0];
  room.map.geometry = [{id: 'floor', x: 0, y: 208, w: 384, h: 16, material: 'ground', collision: 'solid'}];
  Object.assign(room.map.objects[0], {x: 32, y: 194, w: 10, h: 14});
  room.smm2Mechanics = structuredClone(mechanics); return doc;
}

test('central qmap import/reimport preserves every conveyor value and authored reward configuration without mutating inputs', () => {
  const doc = project({version: 1, conveyors: [belt(), incline()], goalCoins: 1, goalCoinPoints: 0, scoreProfile: {coinPoints: 0, keyPoints: 1000}});
  const original = JSON.stringify(doc); validate(doc);
  assert.equal(JSON.stringify(doc), original);
  const imported = parseProject(original), reimported = parseProject(JSON.stringify(imported));
  assert.deepEqual(imported, doc); assert.deepEqual(reimported, imported);
  assert.equal(imported.version, 1); assert.equal(imported.rooms[0].smm2Mechanics.version, 1);
  imported.rooms[0].smm2Mechanics.conveyors[0].speedPxPerSecond = 24;
  assert.equal(doc.rooms[0].smm2Mechanics.conveyors[0].speedPxPerSecond, 48);
});

test('real History changes, undo, redo and import retain conveyor geometry, stable IDs and explicit zero rewards', () => {
  const history = new History(project()), base = JSON.stringify(history.doc);
  history.change(doc => {
    doc.rooms[0].smm2Mechanics.conveyors = [belt(), incline()];
    doc.rooms[0].smm2Mechanics.goalCoins = 0;
    doc.rooms[0].smm2Mechanics.scoreProfile = {coinPoints: 0, keyPoints: 0};
  });
  const authored = JSON.stringify(history.doc);
  assert.deepEqual(parseProject(authored), history.doc);
  history.undo(); assert.equal(JSON.stringify(history.doc), base);
  history.redo(); assert.equal(JSON.stringify(history.doc), authored);
  history.change(doc => {
    const spec = doc.rooms[0].smm2Mechanics.conveyors[0];
    spec.directionOn = 1; spec.speedPxPerSecond = 96;
  });
  assert.equal(history.doc.rooms[0].smm2Mechanics.conveyors[0].id, 'schema-belt');
  history.undo(); assert.equal(JSON.stringify(history.doc), authored);
  history.redo(); assert.deepEqual(parseProject(JSON.stringify(history.doc)), history.doc);
});

test('the central schema rejects missing proof status, unswept geometry inventions and unknown fields within conveyor definitions', () => {
  for (const edit of [
    q => delete q.contactMode, q => q.contactMode = 'full-original-solid',
    q => delete q.parameterStatus, q => q.parameterStatus = 'original-calibrated',
    q => q.speedPxPerSecond = 0, q => q.speedPxPerSecond = NaN,
    q => q.directionOn = 2, q => q.visual.extra = true,
    q => q.visual.rect.w = 500, q => q.topEndpoints[0].x = 65,
    q => q.motion = {axis: 'x', min: 0, max: 100, speed: 1}
  ]) {
    const spec = belt(); edit(spec);
    assert.throws(() => validate(project({version: 1, conveyors: [spec]})));
  }
  assert.throws(() => validate(project({version: 1, conveyors: {}})), /bounded array/);
  assert.throws(() => validate(project({version: 1, conveyors: [belt(), belt()]})), /Duplicate/);
  assert.throws(() => parseProject(JSON.stringify(project({version: 1, conveyor: [belt()]}))), /Unknown SMM2 mechanics field/);
});

test('conveyor IDs cannot alias real native actors, geometry, markers, terrain or vines', () => {
  for (const id of ['start', 'floor']) assert.throws(() => validate(project({version: 1, conveyors: [belt({id})]})), /Duplicate SMM2 conveyor/);
  const marker = project({version: 1, conveyors: [belt()]});
  marker.rooms[0].markers.push({id: 'schema-belt', x: 16, y: 16});
  assert.throws(() => validate(marker), /Duplicate SMM2 conveyor/);
  const terrain = project({version: 1, conveyors: [belt()], slopes: [{id: 'schema-belt', x: 240, y: 128, w: 64, h: 32, orientation: 'rise-right', collision: 'solid'}]});
  assert.throws(() => validate(terrain), /Duplicate SMM2 conveyor/);
  const vine = project({version: 1, conveyors: [belt()], vines: [{id: 'schema-belt', x: 280, y: 96, w: 16, h: 112, climbSpeed: 1}]});
  assert.throws(() => validate(vine), /Duplicate static vine/);
});

test('goalCoins is an optional closed integer range including zero and one hundred', () => {
  for (const goalCoins of [0, 1, 100]) {
    const doc = project({version: 1, goalCoins});
    assert.equal(parseProject(JSON.stringify(doc)).rooms[0].smm2Mechanics.goalCoins, goalCoins);
  }
  for (const goalCoins of [-1, 101, .5, NaN, Infinity, '1', false, null]) assert.throws(() => validate(project({version: 1, goalCoins})), /goal coin count/);
});

test('scoreProfile requires both bounded integer fields and rejects executable or unknown fields', () => {
  for (const scoreProfile of [{coinPoints: 0, keyPoints: 0}, {coinPoints: 100000, keyPoints: 100000}, {coinPoints: 200, keyPoints: 1000}]) {
    const doc = project({version: 1, scoreProfile});
    assert.deepEqual(parseProject(JSON.stringify(doc)).rooms[0].smm2Mechanics.scoreProfile, scoreProfile);
  }
  for (const scoreProfile of [null, [], {}, {coinPoints: 0}, {keyPoints: 0}, {coinPoints: -1, keyPoints: 0}, {coinPoints: 0, keyPoints: 100001}, {coinPoints: .5, keyPoints: 0}, {coinPoints: NaN, keyPoints: 0}, {coinPoints: 0, keyPoints: '200'}, {coinPoints: false, keyPoints: 0}, {coinPoints: 0, keyPoints: 0, onCoin: 'score+=100'}]) {
    assert.throws(() => validate(project({version: 1, scoreProfile})));
  }
  const inherited = project();
  inherited.rooms[0].smm2Mechanics.scoreProfile = Object.create({coinPoints: 1, keyPoints: 2});
  assert.throws(() => validateSmm2MechanicsRoom(inherited.rooms[0]), /score profile/);
  const unsafe = JSON.stringify(project({version: 1, scoreProfile: {coinPoints: 1, keyPoints: 2}})).replace('"coinPoints":1', '"__proto__":{},"coinPoints":1');
  assert.throws(() => parseProject(unsafe), /不安全/);
});

test('goalCoinPoints independently configures goal reward score, including zero, without creating physical coin defaults', () => {
  for (const goalCoinPoints of [0, 1, 100000]) {
    const doc = project({version: 1, goalCoins: 1, goalCoinPoints, scoreProfile: {coinPoints: 200, keyPoints: 1000}});
    const imported = parseProject(JSON.stringify(doc));
    assert.equal(imported.rooms[0].smm2Mechanics.goalCoinPoints, goalCoinPoints);
    assert.equal(imported.rooms[0].smm2Mechanics.scoreProfile.coinPoints, 200);
  }
  for (const goalCoinPoints of [-1, 100001, .5, NaN, Infinity, '0', false, null]) assert.throws(() => validate(project({version: 1, goalCoinPoints})), /goal coin points/);
  const independent = project({version: 1, goalCoinPoints: 0});
  assert.equal(parseProject(JSON.stringify(independent)).rooms[0].smm2Mechanics.goalCoins, undefined);
});

test('legacy mechanics are unchanged and optional leaves never silently materialize defaults', () => {
  for (const mechanics of [{version: 1}, {version: 1, flagScore: true, goalTopLife: false, startingLives: 3}, {version: 1, conveyors: []}]) {
    const doc = project(mechanics), serialized = JSON.stringify(doc);
    assert.deepEqual(parseProject(serialized).rooms[0].smm2Mechanics, mechanics);
    validate(doc); assert.equal(JSON.stringify(doc), serialized);
    assert.equal(doc.rooms[0].smm2Mechanics.goalCoins, undefined);
    assert.equal(doc.rooms[0].smm2Mechanics.goalCoinPoints, undefined);
    assert.equal(doc.rooms[0].smm2Mechanics.scoreProfile, undefined);
  }
  const doc = project(); delete doc.rooms[0].smm2Mechanics;
  assert.deepEqual(parseProject(JSON.stringify(doc)), doc);
});

test('central import and export reject the same real-top solid, pickup, polygon and duplicate-surface placement errors', () => {
  const character=JSON.parse(fs.readFileSync(new URL('../atlas/runtime/character.json',import.meta.url),'utf8'));
  const cases=[
    ['CONVEYOR_TOP_SOLID_OVERLAP',room=>room.map.geometry.push({id:'buried-wall',x:96,y:80,w:16,h:32,material:'stone',collision:'solid'})],
    ['CONVEYOR_TOP_PICKUP_OVERLAP',room=>room.map.objects.push({id:'buried-coin',kind:'coin',x:100,y:90,w:8,h:14})],
    ['CONVEYOR_TOP_SOLID_OVERLAP',room=>room.smm2Mechanics.slopes=[{id:'actual-triangle',x:64,y:80,w:128,h:64,orientation:'rise-left',collision:'solid'}]],
    ['CONVEYOR_TOP_SURFACE_OVERLAP',room=>room.smm2Mechanics.conveyors.push(belt({id:'duplicated-top'}))]
  ];
  for(const [code,edit]of cases){
    const doc=project({version:1,conveyors:[belt()]});edit(doc.rooms[0]);
    const before=JSON.stringify(doc),beforeCharacter=JSON.stringify(character),issues=conveyorPlacementIssues(doc.rooms[0]);
    assert(issues.some(q=>q.code===code));
    assert.throws(()=>parseProject(before),error=>error.message.includes(code)&&JSON.stringify(error.issues)===JSON.stringify(issues));
    assert.throws(()=>validateSmm2MechanicsRoom(doc.rooms[0]),new RegExp(code));
    assert.throws(()=>projectPack(doc,'main',character,'placement-reject'),new RegExp(code));
    assert.equal(JSON.stringify(doc),before,'failed export never mutates source document');
    assert.equal(JSON.stringify(character),beforeCharacter,'failed export never mutates character');
  }
});

test('central History rejects forbidden top edits before an undo entry while preserving the last legal export', () => {
  const doc=project({version:1,conveyors:[belt()]});
  doc.rooms[0].map.objects.push({id:'goal',kind:'exit',x:352,y:176,w:16,h:32});
  const history=new History(doc),before=JSON.stringify(history.doc),character=JSON.parse(fs.readFileSync(new URL('../atlas/runtime/character.json',import.meta.url),'utf8'));
  const packBefore=projectPack(history.doc,'main',character,'placement-stable');
  assert.throws(()=>history.change(next=>next.rooms[0].map.geometry.push({id:'buried-wall',x:96,y:80,w:16,h:32,material:'stone',collision:'solid'})),/CONVEYOR_TOP_SOLID_OVERLAP/);
  assert.equal(JSON.stringify(history.doc),before);assert.equal(history.undoStack.length,0);
  assert.deepEqual(projectPack(history.doc,'main',character,'placement-stable'),packBefore);
});

test('central import/export retains actual incline empty space, aligned edge support and ON/OFF state overlays', () => {
  const doc=project({version:1,conveyors:[incline()]});
  const room=doc.rooms[0];
  room.map.geometry.push({id:'stair-in-empty-bounds',x:240,y:96,w:16,h:16,material:'ground',collision:'solid'},{id:'touching-bottom-support',x:200,y:112,w:64,h:16,material:'ground',collision:'solid'});
  room.map.objects.push({id:'goal',kind:'exit',x:352,y:176,w:16,h:32});
  room.switchStudy={version:1,initialOn:true,allowBacktracking:true,devices:[{id:'state-overlay',kind:'block',color:'red',x:224,y:64,w:16,h:32}]};
  const before=JSON.stringify(doc),character=JSON.parse(fs.readFileSync(new URL('../atlas/runtime/character.json',import.meta.url),'utf8'));
  assert.deepEqual(conveyorPlacementIssues(room),[]);assert.deepEqual(parseProject(before),doc);
  assert.equal(projectPack(doc,'main',character,'legal-conveyor').maps.length,1);assert.equal(JSON.stringify(doc),before);
});
