import fs from 'node:fs';
import {test} from 'node:test';
import assert from 'node:assert/strict';
import {blank,History,parseProject} from '../atlas/editor-model.mjs';
import {projectPack} from '../atlas/editor-runtime.mjs';
import {createStageCatalog} from '../atlas/runtime/stage-catalog.mjs';
import {createMarioModules,validateMarioModulesRoom} from '../atlas/editor-mario-modules.mjs';
import {createPlatformMotor} from '../atlas/editor-mario-motor.mjs';
import {createPlatformStage} from '../atlas/editor-mario-stage.mjs';
import {createPortableStones} from '../atlas/editor-portable-stones.mjs';
import {mountMarioModulesEditor} from '../atlas/editor-mario-modules-editor.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';

const nativeCharacter=JSON.parse(fs.readFileSync(new URL('../atlas/runtime/character.json',import.meta.url)));
const character={capabilities:['jump'],motion:{width:10,height:14,maxHealth:1}};
// These are synthetic author settings. Tests establish contact integration and
// preservation, not Nintendo force constants or a source-video calibration.
const tuning={playerBounceSpeed:4.8,heldBounceSpeed:5.8,itemBounceSpeed:5.68,compressionFrames:8,compressionDepth:12,playerRiseGravity:.15625,playerFallGravity:.4375};
const enemyTuning={enemyBounceSpeed:5.25,enemyRiseGravity:.15625,enemyFallGravity:.15625};
const carryMotion={walkCap:1.1,runCap:1.8,airCap:1.5,jumpSpeed:3.2,jumpGravity:.3,fallGravity:.5};
function document(){
 const d=blank('Synthetic compressed Note contacts',256,288),r=d.rooms[0];
 r.map.geometry=[{id:'floor',x:0,y:272,w:256,h:16,collision:'solid',material:'ground'}];
 r.map.objects=[{id:'start',kind:'spawn',x:42,y:164,w:10,h:14},{id:'stone',kind:'walker',x:104,y:169,w:16,h:16}];
 r.marioModules={version:1,itemSources:[],noteBlocks:[{id:'player-note',x:40,y:192,w:16,h:16,...tuning},{id:'stone-note',x:104,y:192,w:16,h:16,...tuning}],oneWayWalls:[],enemyVariants:{}};
 r.smm2Mechanics={version:1,portableStones:{version:1,stones:[{id:'stone',gravity:.22,maxFallSpeed:4.25,throwSpeedX:2,throwSpeedY:-2,releaseSafeFrames:8,heldOffsetX:0,heldBottomOffset:0,carryMotion}]}};
 return d;
}
function rig(){
 const d=document(),r=d.rooms[0],events=[],m=createMarioModules(r,{emit:(kind,data)=>events.push({kind,...data})}),stones=createPortableStones(r),[stone]=stones.seedItems(),motor=createPlatformMotor(),p=motor.create(character,{x:42,y:164});
 p.id='player';let tick=-1;
 const note=id=>m.geometry(r.map.geometry).find(q=>q.id===id);
 function step(input={}){
  tick++;m.frameNotes({tick,actors:[p,stone],input});let geometry=m.geometry(r.map.geometry);
  stones.stepItem(stone,{tick,geometry,afterActor:m.afterActor});geometry=stones.geometry(geometry,[stone]);
  stones.beforePlayer(p,input,tick,geometry);const before={...p};
  const motorInput=m.ownsNoteCompression(p)?{...input,jumpPressed:false}:input;
  motor.step(p,motorInput,character,{solids:geometry,width:r.map.width,carryMotion:stones.heldMotion(p)});
  m.afterActor(p,before,{kind:'player',input,tick,geometry});stones.afterPlayer(p,input,tick,geometry);
  return {tick,geometry,before};
 }
 return {d,r,events,m,stones,stone,motor,p,note,step,get tick(){return tick;}};
}
const bounces=(q,id)=>q.events.filter(e=>e.kind==='mario-module'&&e.event==='note-bounce'&&e.deviceId===id);
const close=(a,b)=>assert.ok(Math.abs(a-b)<1e-8,`${a} != ${b}`);

function enemyRig({optIn=true,type='goomba'}={}){
 const d=document(),r=d.rooms[0],note=r.marioModules.noteBlocks[0];if(optIn)Object.assign(note,enemyTuning);
 const events=[],m=createMarioModules(r,{emit:(kind,data)=>events.push({kind,...data})}),actor={id:'plain-goomba',kind:'walker',type,x:42,y:178,w:10,h:14,vx:-.5,vy:0,grounded:true,support:note.id},before={...actor,y:176,vy:1.5,grounded:false,support:null};
 m.frameNotes({tick:0,actors:[actor]});return {d,r,note,events,m,actor,before};
}


test('explicit compression settings survive editor history, qmap and native pack; incomplete or unsafe settings are rejected',()=>{
 const h=new History(document()),note=h.doc.rooms[0].marioModules.noteBlocks[0];
 h.change(()=>{h.doc.rooms[0].marioModules.noteBlocks[0].compressionDepth=10;});h.undo();assert.equal(h.doc.rooms[0].marioModules.noteBlocks[0].compressionDepth,12);h.redo();assert.equal(h.doc.rooms[0].marioModules.noteBlocks[0].compressionDepth,10);
 const d=parseProject(JSON.stringify(h.doc));createStageCatalog(projectPack(d,d.rooms[0].roomId,nativeCharacter,'compressed-notes'));
 assert.deepEqual(d.rooms[0].marioModules.noteBlocks,h.doc.rooms[0].marioModules.noteBlocks);assert.equal(note.compressionFrames,8);
 for(const change of [q=>delete q.compressionDepth,q=>delete q.compressionFrames,q=>q.compressionFrames=1,q=>q.compressionFrames=8.5,q=>q.compressionFrames=241,q=>q.compressionDepth=16,q=>q.compressionDepth=0,q=>q.playerRiseGravity=0,q=>q.playerFallGravity=Infinity,q=>q.formula='native']){
  const r=structuredClone(d.rooms[0]);change(r.marioModules.noteBlocks[0]);assert.throws(()=>validateMarioModulesRoom(r));
 }
 const r=structuredClone(d.rooms[0]);for(const q of r.marioModules.noteBlocks){delete q.playerRiseGravity;delete q.playerFallGravity;}assert.doesNotThrow(()=>validateMarioModulesRoom(r));
});

test('actual author panel enables, edits and removes compression atomically without inserting defaults into old Notes',()=>{
 const ui=installSimulatedPlayDom();try{
  const h=new History(document()),r=()=>h.doc.rooms[0],parent=ui.document.createElement('aside'),reports=[];ui.document.body.append(parent);
  mountMarioModulesEditor({parent,room:r,change:fn=>h.change(fn),report:q=>reports.push(q)});
  const get=id=>parent.querySelector('[data-module-control="'+id+'"]'),submit=()=>get('note-apply').parentNode.dispatchEvent({type:'submit'});
  get('note-add').click();let q=r().marioModules.noteBlocks.at(-1);assert.equal(q.compressionFrames,undefined);assert.equal(get('note-compression').checked,false);
  get('note-compression').checked=true;get('note-compression').dispatchEvent({type:'change'});assert.equal(get('note-compressionFrames').required,true);
  get('note-compressionFrames').value='8';get('note-compressionDepth').value='12';get('note-playerRiseGravity').value='.15625';get('note-playerFallGravity').value='.4375';submit();q=r().marioModules.noteBlocks.at(-1);assert.equal(q.compressionFrames,8);assert.equal(q.compressionDepth,12);assert.equal(q.playerRiseGravity,.15625);
  const before=JSON.stringify(h.doc);get('note-compressionDepth').value='16';submit();assert.equal(JSON.stringify(h.doc),before);assert.equal(reports.length,1);
  get('note-compression').checked=false;get('note-compression').dispatchEvent({type:'change'});submit();q=r().marioModules.noteBlocks.at(-1);for(const k of ['compressionFrames','compressionDepth','playerRiseGravity','playerFallGravity'])assert.equal(q[k],undefined);
  h.undo();assert.equal(r().marioModules.noteBlocks.at(-1).compressionDepth,12);assert.deepEqual(parseProject(JSON.stringify(h.doc)).rooms[0].marioModules,r().marioModules);
 }finally{ui.restore();}
});

test('native player motor and PortableStone follow the same real eight-frame top compression exactly once before release',()=>{
 const q=rig(),contact={};
 for(let n=0;n<30&&Object.keys(contact).length<2;n++){
  q.step({jump:true});for(const [id,actor]of [['player-note',q.p],['stone-note',q.stone]])if(q.m.ownsCompression(actor)&&contact[id]===undefined)contact[id]=q.tick;
 }
 assert.equal(Object.keys(contact).length,2);assert.equal(contact['player-note'],contact['stone-note']);
 assert.equal(q.p.vy,0);assert.equal(q.stone.vy,0);
 for(let elapsed=1;elapsed<=8;elapsed++){
  const previousPlayer=q.p.y,previousStone=q.stone.y;const {geometry}=q.step({jump:true,jumpPressed:true});
  for(const [id,actor,old]of [['player-note',q.p,previousPlayer],['stone-note',q.stone,previousStone]]){
   const note=geometry.find(g=>g.id===id),view=q.m.view().noteBlocks.find(g=>g.id===id);close(note.y+note.h,208);close(note.y,view.currenty);close(note.h,view.h);close(actor.y-old,note.dy);close(actor.y+actor.h,note.y);
   assert.equal(note.resty,192);assert.equal(note.bump,0);assert.equal(view.compressionParameterStatus,'explicit-author-configuration');
   if(elapsed<8){assert.equal(actor.vy,0);assert.equal(actor.support,id);assert.equal(bounces(q,id).length,0);assert.equal(q.m.ownsNoteCompression(actor),true);}
   else{assert.equal(actor.grounded,false);assert.equal(actor.support,null);assert.equal(bounces(q,id).length,1);assert.equal(q.m.ownsCompression(actor),false);}
  }
  if(elapsed===6){assert.equal(q.note('player-note').y,204);assert.equal(q.note('player-note').h,4);}
  const state=JSON.stringify(q.m.view());q.m.geometry(q.r.map.geometry);q.m.view();q.m.frameNotes({tick:q.tick,actors:[q.p,q.stone],input:{jump:true}});assert.equal(JSON.stringify(q.m.view()),state);
 }
 assert.equal(q.p.vy,-5.8);assert.equal(q.stone.vy,-5.68);assert.equal(q.p.jumpG,.15625);assert.equal(q.p.fallG,.4375);
 const pBefore={...q.p},stoneBefore={...q.stone};q.m.afterActor(q.p,pBefore,{kind:'player',input:{jump:true},tick:q.tick});q.m.afterActor(q.stone,stoneBefore,{kind:'item',tick:q.tick});assert.equal(bounces(q,'player-note').length,1);assert.equal(bounces(q,'stone-note').length,1);
 q.step({jump:true});assert.ok(q.p.y<pBefore.y);assert.ok(q.stone.y<stoneBefore.y);assert.equal(q.note('player-note').compressionPhase,'idle');
});

test('the actual native Stage rebuilds Note geometry before both actor passes and suppresses ordinary jump only during owned compression',()=>{
 const d=document(),r=d.rooms[0],c={...nativeCharacter,motion:{...nativeCharacter.motion,width:10,height:14}},pack=projectPack(d,r.roomId,c,'stage-compressed-notes'),plan=createStageCatalog(pack).plan(pack.stages[0].id,pack.characters[0].id,{allowDraft:true}),events=[];
 const stage=createPlatformStage({plan,motor:createPlatformMotor(),visualRooms:[r],emit:(kind,data)=>events.push({kind,...data})});
 const contacts={};let released=false;
 for(let n=0;n<45;n++){
  stage.step({jump:true});const view=stage.view(),stone=view.items.find(q=>q.id==='stone');
  for(const [id,actor]of [['player-note',view.p],['stone-note',stone]]){
   const note=view.marioModules.noteBlocks.find(q=>q.id===id),geometry=view.geometry.find(q=>q.id===id);close(note.y,geometry.y);close(note.h,geometry.h);close(geometry.y+geometry.h,208);
   if(note.compressionPhase==='compressing'&&contacts[id]===undefined)contacts[id]=view.tick;
   if(note.compressionPhase==='compressing'){close(actor.y+actor.h,note.y);assert.equal(actor.vy,0);assert.equal(actor.support,id);}
   if(note.compressionPhase==='release'){assert.equal(view.tick-contacts[id],8);close(actor.y+actor.h,192);assert.equal(actor.support,null);assert.equal(actor.vy,id==='player-note'?-5.8:-5.68);}
  }
  if(events.filter(q=>q.event==='note-bounce').length===2){released=true;const y=view.p.y;stage.step({jump:true});assert.ok(stage.view().p.y<y);assert.equal(stage.view().p.jumpG,.15625);break;}
 }
 assert.ok(released);assert.equal(events.filter(q=>q.event==='note-compress').length,2);assert.equal(events.filter(q=>q.event==='note-bounce').length,2);
});

test('held/plain release selection reads the current input and optional gravity fields preserve the existing native values',()=>{
 for(const finalHeld of [false,true]){
  const q=rig();for(const note of q.r.marioModules.noteBlocks){delete note.playerRiseGravity;delete note.playerFallGravity;}
  const m=createMarioModules(q.r),p=q.motor.create(character,{x:42,y:164});p.jumpG=.2;p.fallG=.6;let contact;
  for(let tick=0;tick<40;tick++){
   const input={jump:contact===undefined?!finalHeld:finalHeld};m.frameNotes({tick,actors:[p],input});const before={...p};q.motor.step(p,input,character,{solids:m.geometry(q.r.map.geometry),width:256});m.afterActor(p,before,{kind:'player',input,tick});
   if(m.ownsCompression(p)&&contact===undefined)contact=tick;
   if(contact!==undefined&&tick===contact+8){assert.equal(p.vy,finalHeld?-5.8:-4.8);assert.equal(p.jumpG,.2);assert.equal(p.fallG,.6);break;}
  }
  assert.ok(contact!==undefined);
 }
});

test('held Stone uses native carry motion but the real Note release can explicitly replace player ascent and fall gravity',()=>{
 const q=rig();Object.assign(q.p,{x:94,y:155,grounded:false,support:null});Object.assign(q.stone,{x:104,y:153});
 const geometry=q.m.geometry(q.r.map.geometry);q.stones.beforePlayer(q.p,{run:true},0,geometry);const picked=q.stones.afterPlayer(q.p,{run:true},0,geometry);assert.equal(picked.actions[0]?.action,'pickup');assert.deepEqual(q.stones.heldMotion(q.p),carryMotion);
 Object.assign(q.p,{x:42,y:164,vy:0});let contact;
 for(let n=0;n<35;n++){q.step({run:true,jump:true,jumpPressed:true});if(q.m.ownsCompression(q.p)&&contact===undefined)contact=q.tick;if(bounces(q,'player-note').length)break;}
 assert.equal(q.tick-contact,8);assert.equal(q.p.vy,-5.8);assert.equal(q.p.jumpG,.15625);assert.equal(q.p.fallG,.4375);assert.equal(q.stone.portableStone.held,true);assert.equal(bounces(q,'stone-note').length,0);
 const y=q.p.y;q.step({run:true,jump:true});close(q.p.vy,-5.8+.15625);assert.ok(q.p.y<y);close(q.stone.y+q.stone.h,q.p.y+q.p.h);
});

test('walking away during compression keeps normal horizontal input and never fires a remote delayed player impulse',()=>{
 const q=rig();for(let n=0;n<30&&!q.m.ownsCompression(q.p);n++)q.step({});
 const contact=q.tick;assert.ok(q.m.ownsCompression(q.p));q.p.vx=1.5;
 for(let n=0;n<12;n++)q.step({x:1,run:true});assert.ok(q.p.x>=56);assert.ok(q.tick>contact+8);assert.equal(bounces(q,'player-note').length,0);assert.equal(q.m.ownsCompression(q.p),false);assert.equal(q.note('player-note').y,192);
});

test('a Stone picked up while its Note is compressing leaves that contact and receives no later free-item launch',()=>{
 const q=rig();for(let n=0;n<30&&!q.m.ownsCompression(q.stone);n++)q.step({});assert.ok(q.m.ownsCompression(q.stone));
 Object.assign(q.p,{x:q.stone.x-q.p.w,y:q.stone.y+q.stone.h-q.p.h,grounded:false,support:null,vy:0});
 const geometry=q.m.geometry(q.r.map.geometry),tick=q.tick+1;q.stones.beforePlayer(q.p,{run:true},tick,geometry);q.stones.afterPlayer(q.p,{run:true},tick,geometry);assert.equal(q.stone.portableStone.held,true);
 for(let n=0;n<12;n++)q.step({run:true});assert.equal(bounces(q,'stone-note').length,0);assert.equal(q.m.ownsCompression(q.stone),false);
});

test('paused and duplicate ticks do not advance compression; omitted, dead and unsupported actors cannot launch; reset clears all phases',()=>{
 for(const departure of ['omitted','dead','unsupported']){
  const q=rig();for(let n=0;n<30&&!q.m.ownsCompression(q.p);n++)q.step({});q.step({});const pose={...q.p},state=JSON.stringify(q.m.view());
  for(let tick=q.tick+1;tick<q.tick+50;tick++)q.m.frameNotes({tick,actors:[q.p,q.stone],paused:true});assert.deepEqual(q.p,pose);assert.equal(JSON.stringify(q.m.view()),state);
  q.step({});assert.equal(q.note('player-note').compressionFrame,2);
  if(departure==='dead')q.p.dead=true;if(departure==='unsupported'){q.p.grounded=false;q.p.support=null;}
  for(let tick=q.tick+1;tick<q.tick+12;tick++)q.m.frameNotes({tick,actors:departure==='omitted'?[q.stone]:[q.p,q.stone]});assert.equal(bounces(q,'player-note').length,0);assert.equal(q.m.ownsCompression(q.p),false);
  q.m.reset();const note=q.note('player-note');assert.equal(note.y,192);assert.equal(note.h,16);assert.equal(note.dy,0);assert.equal(note.compressionPhase,'idle');assert.equal(note.compressionFrame,0);assert.equal(q.m.ownsCompression(q.stone),false);assert.equal(q.m.frameNotes({tick:0,actors:[]}).advanced,true);
 }
});

test('ordinary NPCs, underside hits and stale support IDs do not opt into the observed player/free-item compression path',()=>{
 const r=document().rooms[0],m=createMarioModules(r),note=r.marioModules.noteBlocks[0],enemy={id:'npc',x:42,y:178,w:10,h:14,vy:0,grounded:true,support:note.id};
 m.frameNotes({tick:0,actors:[enemy]});m.afterActor(enemy,{...enemy,vy:1},{kind:'enemy',tick:0});assert.equal(m.ownsCompression(enemy),false);assert.equal(m.view().noteBlocks[0].compressionPhase,'idle');
 const player={...enemy,id:'p',y:210};m.afterActor(player,{...player,y:211,vy:-1},{kind:'player',tick:0});assert.equal(m.ownsCompression(player),false);
 player.y=178;player.x=80;m.afterActor(player,{...player,vy:1},{kind:'player',tick:0});assert.equal(m.ownsCompression(player),false);m.bumpNote(note.id,[enemy]);assert.equal(enemy.vy,0);assert.equal(m.view().noteBlocks[0].compressionPhase,'idle');
});

test('legacy Note keeps its immediate held/plain launch, sound count and original gravity without any new settings',()=>{
 for(const held of [false,true]){
  const q=rig();for(const note of q.r.marioModules.noteBlocks)for(const k of ['compressionFrames','compressionDepth','playerRiseGravity','playerFallGravity'])delete note[k];
  const events=[],m=createMarioModules(q.r,{emit:(kind,data)=>events.push({kind,...data})}),p=q.motor.create(character,{x:42,y:164});let launched=false;
  for(let tick=0;tick<30;tick++){m.frameNotes({tick,actors:[p],input:{jump:held}});const before={...p};q.motor.step(p,{jump:held},character,{solids:m.geometry(q.r.map.geometry),width:256});m.afterActor(p,before,{kind:'player',input:{jump:held},tick});if(p.vy<0){assert.equal(p.vy,held?-5.8:-4.8);assert.equal(p.jumpG,.125);assert.equal(p.fallG,.4375);assert.equal(m.ownsCompression(p),false);m.afterActor(p,before,{kind:'player',input:{jump:held},tick});launched=true;break;}}
  assert.ok(launched);assert.equal(events.filter(e=>e.event==='note-bounce').length,1);assert.equal(events.filter(e=>e.kind==='sound').length,1);assert.equal(m.view().noteBlocks[0].resty,undefined);assert.equal(m.view().noteBlocks[0].compressionPhase,undefined);assert.equal(m.geometry(q.r.map.geometry).find(n=>n.id==='player-note').h,16);
 }
});

test('Goomba Note author profile survives strict schema, History, qmap and native pack without changing old opt-out records',()=>{
 const q=enemyRig(),h=new History(q.d);assert.deepEqual(q.m.noteRule(q.note.id),q.note);assert.equal(q.m.noteRule('missing'),null);q.m.noteRule(q.note.id).enemyBounceSpeed=12;assert.equal(q.m.noteRule(q.note.id).enemyBounceSpeed,5.25);h.change(()=>{h.doc.rooms[0].marioModules.noteBlocks[0].enemyBounceSpeed=5;});h.undo();assert.equal(h.doc.rooms[0].marioModules.noteBlocks[0].enemyBounceSpeed,5.25);h.redo();assert.equal(h.doc.rooms[0].marioModules.noteBlocks[0].enemyBounceSpeed,5);
 const parsed=parseProject(JSON.stringify(h.doc));createStageCatalog(projectPack(parsed,parsed.rooms[0].roomId,nativeCharacter,'goomba-note-contacts'));assert.deepEqual(parsed.rooms[0].marioModules.noteBlocks,h.doc.rooms[0].marioModules.noteBlocks);
 for(const change of [n=>delete n.enemyBounceSpeed,n=>delete n.enemyRiseGravity,n=>delete n.enemyFallGravity,n=>delete n.compressionFrames,n=>delete n.compressionDepth,n=>n.enemyBounceSpeed=0,n=>n.enemyBounceSpeed=12.01,n=>n.enemyRiseGravity=0,n=>n.enemyFallGravity=Infinity,n=>n.enemyFallGravity=4.01,n=>n.enemyBounceFormula='native']){const r=structuredClone(q.r);change(r.marioModules.noteBlocks[0]);assert.throws(()=>validateMarioModulesRoom(r));}
 const old=document();assert.doesNotThrow(()=>validateMarioModulesRoom(old.rooms[0]));assert.equal(parseProject(JSON.stringify(old)).rooms[0].marioModules.noteBlocks[0].enemyBounceSpeed,undefined);
});

test('real Note author panel enables the Goomba profile atomically and removes it without altering player settings',()=>{
 const ui=installSimulatedPlayDom();try{
  const h=new History(document()),r=()=>h.doc.rooms[0],parent=ui.document.createElement('aside'),reports=[];ui.document.body.append(parent);mountMarioModulesEditor({parent,room:r,change:fn=>h.change(fn),report:q=>reports.push(q)});
  const get=id=>parent.querySelector('[data-module-control="'+id+'"]'),submit=()=>get('note-apply').parentNode.dispatchEvent({type:'submit'});
  assert.equal(get('note-enemyBounce').checked,false);assert.equal(get('note-enemyBounceSpeed').disabled,true);get('note-enemyBounce').checked=true;get('note-enemyBounce').dispatchEvent({type:'change'});
  for(const [k,value]of Object.entries(enemyTuning)){assert.equal(get('note-'+k).required,true);get('note-'+k).value=String(value);}submit();assert.deepEqual(Object.fromEntries(Object.keys(enemyTuning).map(k=>[k,r().marioModules.noteBlocks[0][k]])),enemyTuning);
  const before=JSON.stringify(h.doc);get('note-enemyFallGravity').value='';submit();assert.equal(JSON.stringify(h.doc),before);assert.equal(reports.length,1);get('note-enemyFallGravity').value='.15625';
  get('note-enemyBounce').checked=false;get('note-enemyBounce').dispatchEvent({type:'change'});submit();for(const k of Object.keys(enemyTuning))assert.equal(r().marioModules.noteBlocks[0][k],undefined);assert.equal(r().marioModules.noteBlocks[0].playerRiseGravity,.15625);assert.equal(r().marioModules.noteBlocks[0].compressionFrames,8);
  h.undo();assert.equal(r().marioModules.noteBlocks[0].enemyBounceSpeed,5.25);get('note-compression').checked=false;get('note-compression').dispatchEvent({type:'change'});submit();for(const k of [...Object.keys(enemyTuning),'compressionFrames','compressionDepth','playerRiseGravity','playerFallGravity'])assert.equal(r().marioModules.noteBlocks[0][k],undefined);
 }finally{ui.restore();}
});

test('plain Goomba launches on the first real top contact while the physical Note independently completes compression',()=>{
 const q=enemyRig();assert.deepEqual(q.m.afterActor(q.actor,q.before,{kind:'enemy',tick:0}),[q.note.id]);assert.equal(q.actor.vy,-5.25);assert.equal(q.actor.grounded,false);assert.equal(q.actor.support,null);assert.equal(q.m.ownsNoteCompression(q.actor),false);assert.deepEqual(q.actor.noteBounceMotion,{noteId:q.note.id,launchTick:0,riseGravity:.15625,fallGravity:.15625});
 assert.equal(q.m.view().noteBlocks[0].compressionFrame,0);assert.equal(q.m.view().noteBlocks[0].compressionPhase,'compressing');assert.equal(q.m.view().noteBlocks[0].y,192);assert.equal(bounces(q,q.note.id).length,1);
 for(let tick=1;tick<=8;tick++){
  q.m.frameNotes({tick,actors:[]});const note=q.m.geometry(q.r.map.geometry).find(n=>n.id===q.note.id);close(note.y+note.h,208);assert.equal(note.material,'study-note');assert.equal(note.noteCompressionGeometry,true);assert.equal(note.compressionFrame,tick);
  q.actor.vy+=q.actor.vy<0?q.actor.noteBounceMotion.riseGravity:q.actor.noteBounceMotion.fallGravity;q.actor.y+=q.actor.vy;assert.ok(q.actor.y+q.actor.h<192);assert.equal(q.m.ownsNoteCompression(q.actor),false);q.m.afterActor(q.actor,{...q.actor,y:q.actor.y-q.actor.vy},{kind:'enemy',tick});
  if(tick===1){assert.ok(note.y>192);assert.equal(note.dy,2);}if(tick===6){assert.equal(note.y,204);assert.equal(note.h,4);}if(tick===8){assert.equal(note.y,192);assert.equal(note.compressionPhase,'release');}
 }
 q.m.frameNotes({tick:9,actors:[]});assert.equal(q.m.view().noteBlocks[0].compressionPhase,'idle');assert.equal(bounces(q,q.note.id).length,1);assert.equal(q.events.filter(e=>e.kind==='sound').length,1);
});

test('Goomba Note rejects side, embedded, upward, unsupported and unavailable contacts',()=>{
 for(const invalid of [q=>q.actor.x=60,q=>q.actor.y=183,q=>q.before.y=179,q=>q.before.y=NaN,q=>q.before.vy=-.1,q=>q.before.vy=NaN,q=>q.actor.grounded=false,q=>q.actor.support='floor',q=>q.actor.dead=true,q=>q.actor.removed=true,q=>q.actor.emerge=true,q=>q.actor.moduleEmergence={remaining:1}]){
  const q=enemyRig();invalid(q);assert.deepEqual(q.m.afterActor(q.actor,q.before,{kind:'enemy',tick:0}),[]);assert.equal(q.actor.noteBounceMotion,undefined);assert.equal(q.m.view().noteBlocks[0].compressionPhase,'idle');assert.equal(bounces(q,q.note.id).length,0);
 }
});

test('Goomba Note contact excludes unrelated NPCs, unsupported Goomba variants and all opt-out Notes',()=>{
 for(const type of ['walker','koopa','beetle','study-piranha','goomba-impostor']){const q=enemyRig({type});assert.deepEqual(q.m.afterActor(q.actor,q.before,{kind:'enemy',tick:0}),[]);assert.equal(q.actor.noteBounceMotion,undefined);assert.equal(q.m.view().noteBlocks[0].compressionPhase,'idle');}
 for(const change of [a=>a.shell=true,a=>a.smm2Shoe={},a=>a.vehicleId='car',a=>a.clawHeld=true,a=>a.source={winged:true},a=>a.source={floating:true}]){const q=enemyRig();change(q.actor);assert.deepEqual(q.m.afterActor(q.actor,q.before,{kind:'enemy',tick:0}),[]);assert.equal(q.m.view().noteBlocks[0].compressionPhase,'idle');}
 for(const legacy of [false,true]){const q=enemyRig({optIn:false});if(legacy){for(const k of ['compressionFrames','compressionDepth','playerRiseGravity','playerFallGravity'])delete q.note[k];q.m=createMarioModules(q.r);}assert.deepEqual(q.m.afterActor(q.actor,q.before,{kind:'enemy',tick:0}),[]);assert.equal(q.actor.vy,0);assert.equal(q.actor.support,q.note.id);assert.equal(q.actor.noteBounceMotion,undefined);}
 for(const type of ['enemy-goomba','marker-goomba']){const q=enemyRig({type});assert.deepEqual(q.m.afterActor(q.actor,q.before,{kind:'enemy',tick:0}),[q.note.id]);}
});

test('Goomba Note cannot repeat a processed contact, pause or view reads spend no frames, and reset clears independent pulse and motion',()=>{
 const q=enemyRig();q.m.afterActor(q.actor,q.before,{kind:'enemy',tick:0});const motion=q.actor.noteBounceMotion,view=JSON.stringify(q.m.view());
 for(let tick=0;tick<3;tick++)assert.deepEqual(q.m.afterActor(q.actor,q.before,{kind:'enemy',tick}),[]);assert.equal(bounces(q,q.note.id).length,1);
 const stale={...q.actor,grounded:true,support:q.note.id,vy:0};Object.assign(q.actor,stale);assert.deepEqual(q.m.afterActor(q.actor,q.before,{kind:'enemy',tick:0}),[]);assert.equal(bounces(q,q.note.id).length,1);q.actor.grounded=false;q.actor.support=null;
 q.m.view().noteBlocks[0].y=0;q.m.geometry(q.r.map.geometry);assert.equal(JSON.stringify(q.m.view()),view);assert.equal(q.m.frameNotes({tick:0,actors:[]}).advanced,false);assert.equal(q.m.frameNotes({tick:1,actors:[],paused:true}).advanced,false);assert.equal(JSON.stringify(q.m.view()),view);
 // The real host may already clear a profile on landing; reset also removes
 // a still-live profile created by this module, without changing other data.
 q.actor.noteBounceMotion=motion;q.m.reset();assert.equal(q.actor.noteBounceMotion,undefined);assert.equal(q.m.ownsCompression(q.actor),false);const note=q.m.view().noteBlocks[0];assert.equal(note.compressionFrame,0);assert.equal(note.compressionPhase,'idle');assert.equal(note.y,192);assert.equal(note.h,16);assert.equal(note.dy,0);assert.equal(q.m.frameNotes({tick:0,actors:[]}).advanced,true);
});

test('Goomba authored Note gravity remains active through ascent and fall, then clears on actual ground contact',()=>{
 const q=enemyRig();q.m.afterActor(q.actor,q.before,{kind:'enemy',tick:0});const motion=q.actor.noteBounceMotion;q.actor.y=80;q.actor.vy=.1;assert.deepEqual(q.m.afterActor(q.actor,{...q.actor,vy:-.1},{kind:'enemy',tick:40}),[]);assert.equal(q.actor.noteBounceMotion,motion);
 q.actor.y=258;q.actor.vy=0;q.actor.grounded=true;q.actor.support='floor';q.m.afterActor(q.actor,{...q.actor,y:257,vy:1},{kind:'enemy',tick:65});assert.equal(q.actor.noteBounceMotion,undefined);assert.equal(q.actor.vy,0);assert.equal(q.actor.support,'floor');
});

test('actual native Stage launches the authored Goomba immediately, carries the gravity profile through a semisolid and clears it on real landing',()=>{
 const d=blank('Synthetic bounded Goomba Note Stage',256,288),r=d.rooms[0];r.map.geometry=[{id:'floor',x:0,y:272,w:256,h:16,collision:'solid',material:'ground'},{id:'upper-semisolid',x:112,y:144,w:96,h:8,collision:'oneway',material:'platform'}];r.map.objects=[{id:'start',kind:'spawn',x:24,y:258,w:10,h:14},{id:'stage-goomba',kind:'walker',x:172,y:154,w:16,h:16}];r.enemySkins={'stage-goomba':'goomba'};r.marioModules={version:1,itemSources:[],noteBlocks:[{id:'goomba-note',x:168,y:192,w:16,h:16,...tuning,...enemyTuning}],oneWayWalls:[],enemyVariants:{}};
 const c={...nativeCharacter,motion:{...nativeCharacter.motion,width:10,height:14}},pack=projectPack(d,r.roomId,c,'stage-goomba-note'),plan=createStageCatalog(pack).plan(pack.stages[0].id,pack.characters[0].id,{allowDraft:true}),events=[],stage=createPlatformStage({plan,motor:createPlatformMotor(),visualRooms:[r],emit:(kind,data)=>events.push({kind,...data})});
 let launchTick=null,minFoot=Infinity,peakTick=null,crossedFromBelow=false,landed=false;
 for(let n=0;n<100;n++){
  stage.step({});const view=stage.view(),goomba=view.enemies.find(a=>a.id==='stage-goomba'),note=view.marioModules.noteBlocks[0];assert.ok(goomba);close(note.y+note.h,208);
  if(launchTick===null&&events.some(e=>e.event==='note-bounce'&&e.actorId===goomba.id)){launchTick=view.tick;close(goomba.y+goomba.h,192);assert.equal(goomba.vy,-5.25);assert.equal(goomba.grounded,false);assert.equal(goomba.support,null);assert.equal(note.compressionFrame,0);assert.equal(note.compressionPhase,'compressing');}
  if(launchTick!==null){const elapsed=view.tick-launchTick,foot=goomba.y+goomba.h;if(foot<minFoot){minFoot=foot;peakTick=elapsed;}if(foot<144)crossedFromBelow=true;
   if(elapsed===1){close(goomba.vy,-5.25+.15625);close(foot,192-5.25+.15625);assert.ok(note.y>192);}if(elapsed===6){assert.equal(note.y,204);assert.ok(goomba.vy<0);}if(elapsed===8){assert.equal(note.y,192);assert.ok(goomba.vy<0);}
   if(!goomba.grounded){assert.equal(goomba.noteBounceMotion.noteId,'goomba-note');assert.equal(goomba.noteBounceMotion.riseGravity,.15625);assert.equal(goomba.noteBounceMotion.fallGravity,.15625);}
   if(goomba.grounded){close(foot,144);assert.equal(goomba.noteBounceMotion,undefined);landed=true;break;}
  }
 }
 assert.ok(launchTick!==null);assert.ok(crossedFromBelow);assert.ok(landed);assert.ok(peakTick>=32&&peakTick<=35);close(192-minFoot,85.59375);assert.equal(events.filter(e=>e.event==='note-bounce'&&e.actorId==='stage-goomba').length,1);assert.equal(events.filter(e=>e.event==='note-compress'&&e.actorId==='stage-goomba').length,1);
});
