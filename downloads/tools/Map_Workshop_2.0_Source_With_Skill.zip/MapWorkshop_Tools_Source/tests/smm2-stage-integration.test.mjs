import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createPlatformStage} from '../atlas/editor-mario-stage.mjs';
import {createPlatformMotor} from '../atlas/editor-mario-motor.mjs';
import {validate,parseProject} from '../atlas/editor-model.mjs';
const character={capabilities:['jump'],motion:{width:10,height:14,maxHealth:1}};
const thwomp=id=>({id,direction:'down',triggerRange:0,transverseTolerance:0,leadReference:'center',windupFrames:8,chargeAcceleration:.2,chargeSpeedCap:4,impactWaitFrames:30,returnSpeed:.5,breakMaterials:[]});
const actor=(id,x,y,w=16,h=16,kind='walker')=>({id,kind,x,y,w,h});
function room(leaf={},objects=[]){return {roomId:'main',setting:'Castle',markers:[],decorations:[],contraptions:{version:1,doors:[]},map:{id:'fixture',title:'Fixture',width:512,height:224,tileSize:16,geometry:[{id:'floor',x:0,y:208,w:512,h:16,collision:'solid',material:'ground'}],objects:[actor('start',40,194,10,14,'spawn'),...objects]},smm2Mechanics:{version:1,art:{palette:'smb1-castle-stone'},...leaf}};}
function session(r,extra={}){const events=[],stage=createPlatformStage({plan:{stage:{entryRoom:'main',entrySpawn:'start',title:'Fixture'},character,rooms:{main:r.map}},motor:createPlatformMotor(),visualRooms:[r],autoContinue:false,emit:(type,data)=>events.push({type,...data}),...extra});return {stage,events,view:()=>stage.view(),frames(n,input={}){for(let i=0;i<n;i++)stage.step(input);return stage.view();}};}
test('host extracts POW from native walker ABI; true native head-hit removes real collider and defeats eligible nearby Thwomp once',()=>{
 const r=room({powBlocks:[{id:'pow',gravity:0,maxFallSpeed:4,blastRadius:80,supportedScreenEffect:false}],thwomps:[thwomp('thwomp')]},[actor('pow',40,160),actor('thwomp',88,128,32,32)]),h=session(r);
 assert.equal(h.view().enemies.length,1);assert.equal(h.view().items.find(a=>a.id==='pow').kind,'pow');h.frames(5);h.frames(30,{jump:true});h.frames(30);
 assert.equal(h.events.filter(e=>e.event==='pow-activate').length,1);assert.equal(h.view().enemies.length,0);assert.equal(h.view().geometry.some(g=>g.id==='pow'),false);assert.equal(h.view().score,100);assert.equal(h.view().lives,3);
});
test('host keeps genuine POW top support inert through standing and jump-away',()=>{
 const r=room({powBlocks:[{id:'pow',gravity:0,maxFallSpeed:4,blastRadius:80,supportedScreenEffect:false}]},[actor('pow',40,184)]);Object.assign(r.map.objects[0],{y:160});const h=session(r);h.frames(30);assert.equal(h.view().p.support,'pow');assert.equal(h.events.filter(e=>e.event==='pow-activate').length,0);h.frames(20,{jump:true});assert.equal(h.events.filter(e=>e.event==='pow-activate').length,0);assert.equal(h.view().items.find(a=>a.id==='pow').dead,false);
});
test('blue POW really defeats an ordinary grounded native Goomba without a Thwomp sidecar',()=>{
 const r=room({powBlocks:[{id:'pow',gravity:0,maxFallSpeed:4,blastRadius:0,supportedScreenEffect:true}]},[actor('pow',40,160),actor('goomba',88,192)]);r.setting='Overworld';delete r.smm2Mechanics.art;const h=session(r);h.frames(4);h.frames(24,{jump:true});assert.equal(h.view().enemies.length,0);assert.equal(h.view().score,100);assert.equal(h.view().lives,3);assert.deepEqual(h.events.find(e=>e.event==='pow-activate').targets.map(q=>q.id),['goomba']);
});
test('host preplaced Shellmet equips on actual underside jump preserving Fire form',()=>{
 const r=room({helmets:[{id:'helmet',gravity:0,maxFallSpeed:4}]},[actor('helmet',40,160)]),h=session(r,{initialState:{lives:3,power:2}});h.frames(5);h.frames(24,{jump:true});assert.equal(h.view().p.helmet,'buzzy');assert.equal(h.view().p.power,2);assert.equal(h.view().p.h,28);assert.equal(h.events.filter(e=>e.event==='helmet-worn').length,1);assert.equal(h.view().items.some(a=>a.id==='helmet'),false);
});
test('host owns actual placed-life pickup and never puts it in enemy combat',()=>{
 const r=room({placedItems:[{id:'life',kind:'life',gravity:.2,maxFallSpeed:4}]},[actor('life',40,192)]),h=session(r);assert.equal(h.view().enemies.length,0);h.frames(2);assert.equal(h.view().lives,4);h.frames(120);assert.equal(h.view().lives,4);assert.equal(h.events.filter(e=>e.type==='sound'&&e.event==='life').length,1);
});
test('four physical pink coin contacts release one homing key and retain actual collected count',()=>{
 const coins=[40,64,88,112].map((x,i)=>actor('pink-'+i,x,192,16,16,'coin')),r=room({pinkCoins:coins.map(q=>({id:q.id}))},coins),h=session(r);h.frames(80,{x:1});h.frames(60);
 assert.equal(h.view().smm2Mechanics.pinkCoins.taken,4);assert.equal(h.view().smm2Mechanics.pinkCoins.total,4);assert.equal(h.view().contraptions.keys,1);assert.equal(h.events.filter(e=>e.event==='pink-key-release').length,1);assert.equal(h.view().coins,4);
});
test('static vine climbing keeps actual world updating and never creates a room warp at its top',()=>{
 const r=room({vines:[{id:'vine',x:40,y:96,w:16,h:112,climbSpeed:1.5}]},[actor('walker',256,192)]),h=session(r);h.frames(8);const before=h.view();h.frames(100,{up:true});assert.equal(h.view().roomId,'main');assert.equal(h.view().p.onVine,true);assert(h.view().p.y<before.p.y-60);assert(h.view().enemies[0].x<before.enemies[0].x-10);assert.equal(h.view().tick,before.tick+100);
});
test('central importer roundtrips items and pink leaves while rejecting wrong native references',()=>{
 const r=room({powBlocks:[{id:'pow',gravity:0,maxFallSpeed:4,blastRadius:80,supportedScreenEffect:false}],pinkCoins:[{id:'coin'}]},[actor('pow',40,160),actor('coin',64,192,16,16,'coin')]),doc={format:'xiaoq-map-project',version:1,id:'fixture',title:'Fixture',rooms:[r]};validate(doc);assert.deepEqual(parseProject(JSON.stringify(doc)).rooms[0].smm2Mechanics,r.smm2Mechanics);r.smm2Mechanics.pinkCoins[0].id='pow';assert.throws(()=>validate(doc),/Pink coin/);
});
test('host true descending Thwomp contact activates POW and emits only an explicitly bound defeated-enemy key',()=>{
 const def={...thwomp('thwomp'),triggerRange:300,transverseTolerance:24,windupFrames:3,chargeAcceleration:1,chargeSpeedCap:8},r=room({powBlocks:[{id:'pow',gravity:0,maxFallSpeed:4,blastRadius:80,supportedScreenEffect:false}],thwomps:[def],enemyRewards:[{id:'thwomp',reward:'key'}]},[actor('pow',40,160),actor('thwomp',32,80,32,32)]),h=session(r);h.frames(2);assert.equal(h.view().contraptions.keys,0);assert.equal(h.events.filter(e=>e.event==='enemy-key-released').length,0);h.frames(90);assert.equal(h.view().enemies.length,0);assert.equal(h.view().contraptions.keys,1);assert.equal(h.view().score,100);assert.equal(h.events.filter(e=>e.event==='pow-activate'&&e.trigger?.kind==='thwomp-impact').length,1);assert.equal(h.events.filter(e=>e.event==='enemy-key-released').length,1);assert.equal(h.view().lives,3);
});
test('static climbing cannot enter a real solid ceiling or sealed brick pocket',()=>{
 const r=room({vines:[{id:'vine',x:40,y:80,w:16,h:128,climbSpeed:2}]});r.map.geometry.push({id:'ceiling',x:24,y:128,w:64,h:16,collision:'solid',material:'stone'});const h=session(r);h.frames(4);h.frames(120,{up:true});assert(h.view().p.y>=144);assert(!h.view().geometry.some(g=>g.collision==='solid'&&createPlatformMotor().overlap(h.view().p,g)));h.frames(30,{x:-1,jump:true});assert.equal(h.view().lives,3);assert(h.view().p.x<35);
});
test('true Thwomp down and side charge impacts toggle ON/OFF once; impact resting and return do not',()=>{
 for(const direction of ['down','right']){
  const def={...thwomp('thwomp'),direction,triggerRange:400,transverseTolerance:200,windupFrames:3,chargeAcceleration:1,chargeSpeedCap:8,impactWaitFrames:90},r=room({thwomps:[def]},[actor('thwomp',direction==='down'?96:48,80,32,32)]);
  if(direction==='right')r.map.objects[0].x=160;
  r.switchStudy={version:1,initialOn:true,allowBacktracking:true,devices:[{id:'switch',kind:'switch',x:96,y:direction==='down'?144:88,w:16,h:16}]};
  const h=session(r);h.frames(80);assert.equal(h.view().switchStudy.toggles,1,direction);const hits=h.events.filter(e=>e.type==='switch-study');assert.equal(hits.length,1);assert.equal(hits[0].actor,'thwomp');assert.equal(hits[0].actorId,'thwomp');assert.equal(hits[0].deviceId,'switch');
  h.frames(40);assert.equal(h.view().switchStudy.toggles,1,'rest and return must not toggle');assert.equal(h.view().lives,3);
 }
});
