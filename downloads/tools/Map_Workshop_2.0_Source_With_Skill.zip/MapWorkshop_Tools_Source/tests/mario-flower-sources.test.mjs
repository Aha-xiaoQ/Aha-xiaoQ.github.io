import {test} from 'node:test';
import assert from 'node:assert/strict';
import {History,parseProject} from '../atlas/editor-model.mjs';
import {createMarioModules,validateMarioModulesRoom} from '../atlas/editor-mario-modules.mjs';
import {setMarioSource,mountMarioModulesEditor,FLOWER_SOURCE_AUTHORING_DEFAULTS} from '../atlas/editor-mario-modules-editor.mjs';
import {createCollection,addLevel,parseCollection,serializeCollection,buildCollection,requiredCollectionCapabilities} from '../atlas/editor-collection.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';
import {flowerProject,flowerSession,exerciseFlowerRecovery,exerciseFlowerDeathReset,character} from './fixtures/flower-pipe-native.mjs';

test('typed flower supply preserves life/star data and rejects non-native or incomplete sources',()=>{
 for(const item of ['flower','life','star']){
  const doc=flowerProject();doc.rooms[0].marioModules.itemSources[0].item=item;
  const imported=parseProject(JSON.stringify(doc));assert.deepEqual(imported,doc);flowerSession(imported);
  assert.equal(createMarioModules(imported.rooms[0]).view().itemSources[0].item,item);
 }
 for(const mutate of [q=>q.item='fire-flower',q=>q.item='mushroom',q=>q.item='boss-pickup',q=>delete q.vx,q=>q.maxAlive=0,q=>q.intervalFrames=0,q=>q.maxEmissions=0,q=>q.emergenceFrames=24]){
  const r=flowerProject().rooms[0];mutate(r.marioModules.itemSources[0]);assert.throws(()=>validateMarioModulesRoom(r));
 }
});
test('flower mouth obeys real geometry, 180-frame intervals, one-live capacity, unlimited reuse and reset',()=>{
 const r=flowerProject().rooms[0],q=r.marioModules.itemSources[0];q.direction='up';
 const events=[],m=createMarioModules(r,{emit:(type,data)=>events.push({type,...data})}),p={x:80},items=[],geometry=structuredClone(r.map.geometry),pipe=geometry.find(g=>g.id==='pipe');
 Object.assign(pipe,{x:96,y:128});const blocker={id:'mouth-cap',x:105,y:114,w:14,h:14,collision:'solid'};
 assert.equal(m.spawnItems({player:p,items,tick:1,geometry:[...geometry,blocker]}).length,0);assert.equal(m.view().itemSources[0].emitted,0);
 let [first]=m.spawnItems({player:p,items,tick:2,geometry});assert.equal(first.kind,'flower');assert.equal(first.x,105);assert.equal(first.y,114);assert.equal(first.vx,0);assert.equal(first.vy,0);items.push(first);
 for(let tick=3;tick<182;tick++)assert.equal(m.spawnItems({player:p,items,tick,geometry}).length,0);
 assert.equal(m.spawnItems({player:p,items,tick:182,geometry}).length,0,'a live flower still owns the source slot');first.dead=true;
 for(let n=0,tick=183;n<4;n++,tick+=180){const [next]=m.spawnItems({player:p,items,tick,geometry});assert(next);assert(!items.some(i=>i.id===next.id));items.push(next);next.dead=true;for(let frame=tick+1;frame<tick+180;frame++)assert.equal(m.spawnItems({player:p,items,tick:frame,geometry}).length,0);}
 assert.equal(m.view().itemSources[0].emitted,5);assert.equal(events.filter(e=>e.type==='mario-module'&&e.event==='item-source').length,5);
 m.reset();assert.equal(m.view().itemSources[0].emitted,0);assert.equal(m.view().itemSources[0].active,false);
 assert.equal(m.spawnItems({player:p,items:[],tick:1,geometry})[0].kind,'flower');
});
test('ordinary native inputs collect two flowers, lose real firepower, recover it and reset supply at checkpoint death',()=>{
 const s=flowerSession(),recovery=exerciseFlowerRecovery(s),reset=exerciseFlowerDeathReset(s);
 assert(recovery.recoveredFireTick>recovery.hurtTick);assert(reset.retryFireTick>reset.retryTick);assert.equal(s.view().lives,2);
});
test('flower author API retains stable IDs and native map through kind conversion, undo and failed edits',()=>{
 const h=new History(flowerProject()),room=()=>h.doc.rooms[0],map=structuredClone(room().map);let added;
 h.change(()=>{added=setMarioSource(room(),null,null,'flower',{pipeId:'pipe',...FLOWER_SOURCE_AUTHORING_DEFAULTS});});
 assert.equal(added.collection,'itemSources');assert.deepEqual(room().map,map);
 h.change(()=>setMarioSource(room(),added.collection,added.id,'star',{pipeId:'pipe',...FLOWER_SOURCE_AUTHORING_DEFAULTS}));
 assert.equal(room().marioModules.itemSources[1].item,'star');h.undo();assert.equal(room().marioModules.itemSources[1].item,'flower');h.redo();assert.equal(room().marioModules.itemSources[1].item,'star');
 const before=JSON.stringify(room());assert.throws(()=>setMarioSource(room(),added.collection,added.id,'fire-flower',{pipeId:'pipe',...FLOWER_SOURCE_AUTHORING_DEFAULTS}));assert.equal(JSON.stringify(room()),before);
 assert.deepEqual(parseProject(JSON.stringify(h.doc)).rooms[0].marioModules,room().marioModules);
});
test('real source panel adds safe stationary repeatable flowers, edits and removes them through History',()=>{
 const ui=installSimulatedPlayDom();try{
  const doc=flowerProject();doc.rooms[0].marioModules.itemSources=[];const h=new History(doc),room=()=>h.doc.rooms[0],parent=ui.document.createElement('aside'),reports=[];
  const tool=mountMarioModulesEditor({parent,room,change:fn=>h.change(fn),report:s=>reports.push(s)}),get=id=>parent.querySelector('[data-module-control="'+id+'"]'),event=(el,type)=>el.dispatchEvent({type});
  assert(get('source-kind').children.some(q=>q.value==='flower'&&q.textContent==='火焰花'));
  get('source-kind').value='flower';event(get('source-kind'),'change');get('source-add').click();
  const source=room().marioModules.itemSources[0],{id,...values}=source;assert.deepEqual(values,{pipeId:'pipe',...FLOWER_SOURCE_AUTHORING_DEFAULTS,item:'flower'});
  assert(get('source-select').children[0].textContent.startsWith('火焰花'));assert.equal(get('source-smart').disabled,true);
  get('source-direction').value='down';get('source-intervalFrames').value='240';event(get('source-apply').parentNode,'submit');
  assert.equal(room().marioModules.itemSources[0].id,id);assert.equal(room().marioModules.itemSources[0].intervalFrames,240);
  h.undo();tool.refresh();assert.equal(get('source-intervalFrames').value,180);h.redo();tool.refresh();assert.equal(get('source-direction').value,'down');
  get('source-remove').click();assert.equal(room().marioModules.itemSources.length,0);h.undo();tool.refresh();assert.equal(room().marioModules.itemSources[0].item,'flower');assert.equal(reports.length,0);
 }finally{ui.restore();}
});
test('collection import and compiler retain repeatable flowers and require their concrete capability only when present',()=>{
 const doc=flowerProject(),authored=addLevel(createCollection('Neutral flowers'),doc,{id:'flowers'}),imported=parseCollection(serializeCollection(authored)),runtime=buildCollection(imported,character,{includePending:true});
 assert.deepEqual(runtime.levels[0].rooms[0].marioModules,doc.rooms[0].marioModules);assert(runtime.requiredCapabilities.includes('flower-pipe-supply-v1'));assert(runtime.levels[0].requiredCapabilities.includes('flower-pipe-supply-v1'));assert.equal(runtime.levels[0].pack.schemaVersion,1);
 for(const item of ['life','star']){const legacy=flowerProject();legacy.rooms[0].marioModules.itemSources[0].item=item;assert(!requiredCollectionCapabilities(legacy).includes('flower-pipe-supply-v1'));}
});
