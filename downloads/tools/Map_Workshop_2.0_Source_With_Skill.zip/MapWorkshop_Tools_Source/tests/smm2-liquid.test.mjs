import test from 'node:test';
import assert from 'node:assert/strict';
import {validateSmm2LiquidRoom,createSmm2Liquid} from '../atlas/editor-smm2-liquid.mjs';
import {markerParts,managedLiquidMarkerForArt} from '../atlas/map-appearance.mjs';
const room=()=>({roomId:'castle',map:{width:384,height:432,geometry:[],objects:[]},markers:[{id:'pool',kind:'lava-region',x:32,y:400,w:320,h:32}],smm2Mechanics:{version:1,liquid:{markerId:'pool',kind:'lava',minY:396,maxY:400,initialY:400,speed:1,direction:-1,waitMinFrames:2,waitMaxFrames:1}}});
test('managed surface shares one real pose with hazard and actor-scoped support',()=>{
 const r=room(),before=structuredClone(r),c=createSmm2Liquid(r);c.step({tick:1});
 assert.equal(c.view().y,399);assert.equal(c.surfaceForBoat().y,399);assert.equal(c.surfaceForBoat().dy,-1);
 assert.equal(c.contact({x:64,y:385,w:10,h:14}),false);assert.equal(c.contact({x:64,y:386,w:10,h:14}),true);
 assert.equal(c.contact({x:0,y:410,w:16,h:14}),false);assert.deepEqual(r,before);assert.deepEqual(r.map.geometry,[]);
});
test('motion waits and reverses at authored bounds with no duplicate or paused advancement',()=>{
 const c=createSmm2Liquid(room()),ys=[];for(let tick=1;tick<=12;tick++){c.step({tick});ys.push(c.view().y);}
 assert.deepEqual(ys,[399,398,397,396,396,396,397,398,399,400,400,399]);
 const a=c.view();assert.equal(c.step({tick:12}),false);assert.equal(c.step({tick:3}),false);assert.equal(c.step({tick:13,paused:true}),false);assert.deepEqual(c.view(),a);
 c.step({tick:80});assert.equal(c.view().activeFrames,13);assert.equal(c.view().y,398); // active steps, never fast-forward through frozen scenes
 c.reset();assert.equal(c.view().y,400);assert.equal(c.view().activeFrames,0);assert.equal(c.view().tick,null);
});
test('static lava stays a hazard without becoming a common hidden platform',()=>{
 const r=room();Object.assign(r.smm2Mechanics.liquid,{minY:400,maxY:400,speed:0});const c=createSmm2Liquid(r);
 for(let tick=0;tick<10;tick++)c.step({tick});assert.equal(c.view().y,400);assert.equal(c.surfaceForBoat().dy,0);
 assert.equal(c.contact({x:32,y:400,w:14,h:14}),true);assert.deepEqual(r.map.geometry,[]);assert.equal('geometry'in c,false);
});
test('malformed ranges, absent real marker and occupied surface IDs are rejected',()=>{
 for(const mutate of [r=>r.smm2Mechanics.liquid.initialY=395,r=>r.smm2Mechanics.liquid.speed=5,r=>r.smm2Mechanics.liquid.direction=0,r=>r.smm2Mechanics.liquid.waitMinFrames='',r=>r.markers=[],r=>r.smm2Mechanics.liquid.kind='poison',r=>r.smm2Mechanics.liquid.invincible=true,r=>r.map.objects.push({id:'pool-boat-surface'})]){const r=room();mutate(r);assert.throws(()=>validateSmm2LiquidRoom(r));}
});
test('managed liquid world width matches art in previews and live views, legacy macros retain half-size units',()=>{
 const r=room(),m=r.markers[0];m.source={width:m.w};
 assert.equal(markerParts(r,m)[0].w,320);
 r.liquidView={markerId:'pool',x:40,w:288,y:398,bottom:432};
 assert.deepEqual(markerParts(r,m).map(p=>[p.x,p.w]),[[40,288],[40,288]]);
 assert.equal(managedLiquidMarkerForArt(r,m).y,398);
 const legacy={...r,smm2Mechanics:undefined,liquidView:undefined};
 assert.equal(markerParts(legacy,{...m,kind:'lava-volume'})[0].w,640);
 assert.equal(m.source.width,320,'appearance must not mutate authored bytes');
});
