import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createPlatformMotor} from '../atlas/editor-mario-motor.mjs';
import {dryBonesMovingRoofProject,nativeSession} from './fixtures/dry-bones-low-ceiling-native.mjs';
import {overlaps} from './fixtures/shell-coin-native.mjs';

const bones=v=>v.enemies.find(e=>e.id==='bones');
const roof=v=>v.geometry.find(e=>e.id==='roof');

function runMovingRoof({crossPile=false}={}) {
 const identities=new Set(),candidates=new Map(),frames=[];let frame=0;
 const s=nativeSession(dryBonesMovingRoofProject(),{Motor:()=>{
  const motor=createPlatformMotor();
  return {...motor,overlap(a,b){
   // Read-only instrumentation sees the actual host body in native collision.
   if(a.id==='bones'&&a.smm2DryBones)identities.add(a);
   if(a.id==='bones'&&Object.isFrozen(a)&&!a.smm2DryBones){
    if(!candidates.has(frame))candidates.set(frame,new Set());
    candidates.get(frame).add(a);
   }
   return motor.overlap(a,b);
  }};
 }});
 let collapsed=false,walked=false,walking=false;
 for(let n=0;n<265;n++) {
  const v=s.view(),p=v.p,e=bones(v);let input;
  if(!collapsed)input={x:Math.sign(e.x+3-p.x),run:true,jump:n>0&&n<34};
  else if(crossPile&&!walked&&p.grounded&&p.x>456){walking=true;input={x:-1,run:true};}
  else{input={};if(walking)walked=true;}
  frame=n+1;const next=s.step(input);frames.push(next);
  collapsed||=s.events.some(e=>e.event==='dry-bones-collapse');
 }
 return {s,frames,identities,candidates};
}

test('real Stage ordinary stomp preserves identity while a moving solid blocks and releases Dry Bones recovery',()=>{
 const {s,frames,identities,candidates}=runMovingRoof();
 assert.equal(identities.size,1,'one actual live host actor through all phases');
 assert.deepEqual(s.events.filter(e=>e.type==='mario-module').map(e=>[e.event,e.frame]),[
  ['dry-bones-collapse',49],['dry-bones-recovering',199],['dry-bones-recovered',240]
 ]);
 const collapse=frames[48],prior=frames[47],e=bones(collapse);
 assert.equal(bones(prior).h,24);assert.equal(prior.p.vy>0,true);
 assert.equal(e.id,bones(prior).id);assert.equal(e.dead,false);
 assert.equal(e.shell,undefined);assert.equal(e.x,483.75);
 assert.equal(e.y+e.h,400);assert.equal(e.h,8);
 assert.equal(e.smm2DryBones.remainingFrames,150);
 assert.equal(collapse.p.vy,-3.2);assert.equal(collapse.score,0);
 assert.equal(s.events.find(e=>e.event==='dry-bones-collapse').attack,'stomp');
 for(let f=50;f<=198;f++)assert.equal(bones(frames[f-1]).smm2DryBones.remainingFrames,199-f);
 assert.equal(bones(frames[198]).smm2DryBones.remainingFrames,24);
 for(let f=200;f<=222;f++)assert.equal(bones(frames[f-1]).smm2DryBones.remainingFrames,223-f);
 for(let f=223;f<=239;f++){
  const v=frames[f-1],a=bones(v),full={x:a.x,y:a.y+a.h-24,w:16,h:24};
  assert.equal(a.smm2DryBones.phase,'recovering');
  assert.equal(a.smm2DryBones.remainingFrames,0);
  assert.equal(a.h,8);assert.equal(a.x,483.75);assert.equal(a.vx,0);
  assert.equal(a.grounded,true);assert.equal(a.dead,false);
  assert(!overlaps(a,roof(v)));assert(overlaps(full,roof(v)));
  assert.equal(candidates.get(f).size,1,'one stand candidate per distinct tick');
 }
 const clear=frames[239],standing=bones(clear);
 assert(roof(clear).x>=499.75);assert.equal(candidates.get(240).size,1);
 assert.equal(standing.smm2DryBones.phase,'walking');assert.equal(standing.h,24);
 assert.equal(standing.y,376);assert.equal(standing.vx,-.25);
 for(const v of frames){assert.equal(v.lives,3);assert.equal(v.health,1);
  assert.equal(v.score,0);assert.equal(v.p.h,14);assert(!overlaps(bones(v),roof(v)));}
 assert.equal(s.events.filter(e=>e.event==='death').length,0);
});

test('Small Mario walks through the real 16px roof gap and collapsed pile without damage',()=>{
 const {s,frames}=runMovingRoof({crossPile:true});
 const under=frames.filter(v=>v.p.grounded&&v.p.x+v.p.w>roof(v).x&&v.p.x<roof(v).x+roof(v).w);
 assert.equal(under.length,41);
 assert(under.some(v=>overlaps(v.p,bones(v))),'real harmless contact with the collapsed body');
 assert(under.some(v=>v.p.vx<0),'ordinary movement below the ceiling');
 for(const v of under){assert.equal(v.p.support,'floor');assert.equal(v.p.y,386);
  assert.equal(v.p.h,14);assert.equal(roof(v).y+roof(v).h,384);
  assert(!overlaps(v.p,roof(v)));assert.equal(v.lives,3);assert.equal(v.health,1);}
 assert.equal(s.view().lives,3);assert.equal(s.view().health,1);
 assert.equal(bones(s.view()).smm2DryBones.phase,'walking');
 assert.equal(s.events.filter(e=>e.event==='death').length,0);
});
