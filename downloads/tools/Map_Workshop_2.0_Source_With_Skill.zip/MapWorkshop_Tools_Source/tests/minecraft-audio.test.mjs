import test from 'node:test';
import assert from 'node:assert/strict';
import {createSound,themeFor} from '../atlas/editor-audio.mjs';
import {createMinecraftSound,synthesizeMinecraftSound,renderMinecraftAudioPCM,renderMinecraftAudioTape,MINECRAFT_SOUND_DURATIONS} from '../atlas/editor-minecraft-audio.mjs';
import {installSimulatedAudio} from './fixtures/simulated-audio.mjs';

const energy=pcm=>Math.sqrt(pcm.reduce((sum,value)=>sum+value*value,0)/Math.max(1,pcm.length));
function simulatedContext({state='running',resume}={}){
 const sources=[],context={sampleRate:48000,state,destination:{},resumes:0,
  createBuffer(channels,length,rate){const pcm=new Float32Array(length);return{numberOfChannels:channels,length,sampleRate:rate,getChannelData:()=>pcm};},
  createBufferSource(){const source={connect(){},disconnect(){},stopped:false,started:false,start(){this.started=true;},stop(){this.stopped=true;this.onended?.();}};sources.push(source);return source;},
  createGain(){return{gain:{value:1},connect(){},disconnect(){}};},
  createStereoPanner(){return{pan:{value:0},connect(){},disconnect(){}};},
  resume(){this.resumes++;if(resume)return resume(this);this.state='running';return Promise.resolve();}
 };return{context,sources};
}

test('all original adventure clips are deterministic, finite, audible and bounded',()=>{
 for(const [key,duration]of Object.entries(MINECRAFT_SOUND_DURATIONS)){
  const a=synthesizeMinecraftSound(key),b=synthesizeMinecraftSound(key);
  assert.equal(a.pcm.length,Math.ceil(duration*48000),key);assert.deepEqual(a.pcm,b.pcm,key);
  assert(a.pcm.every(Number.isFinite),key);assert(a.pcm.every(v=>Math.abs(v)<=.95001),key);assert(energy(a.pcm)>.001,key);
 }
 assert.notDeepEqual(synthesizeMinecraftSound('mc-sand',{seed:1}).pcm,synthesizeMinecraftSound('mc-sand',{seed:2}).pcm);
 assert.equal(synthesizeMinecraftSound('unrecognized').pcm.length,0);
});

test('ambient loop is sample-continuous and explicit Minecraft themes preserve Mario selection',()=>{
 const {pcm}=synthesizeMinecraftSound('mc-ambience');assert(Math.abs(pcm[0]-pcm.at(-1))<.001);
 assert.equal(themeFor('Minecraft-overworld'),'mc-ambience');assert.equal(themeFor('Minecraft-nether',true,90),'mc-nether-music');
 assert.equal(themeFor('Overworld'),'overworld');assert.equal(themeFor('Castle',false,90),'hurry_castle');
});

test('no AudioContext or sound before a gesture; pause, mute and fuse stop are authoritative',async()=>{
 const {context,sources}=simulatedContext();let factoryCalls=0;
 const sound=createMinecraftSound({contextFactory:()=>{factoryCalls++;return context;}});
 sound.background();sound.effect('mc-explosion');assert.equal(factoryCalls,0);assert.equal(sources.length,0);
 await sound.resumeMusic('mc-ambience',true);assert.equal(factoryCalls,1);assert.equal(sound.snapshot().playing,true);
 sound.effect('mc-fuse');assert.equal(sound.snapshot().activeEffects,1);const fuse=sources.at(-1);
 sound.effect('mc-explosion');assert.equal(fuse.stopped,true);assert.equal(sound.snapshot().activeEffects,1);
 sound.effect('mc-fuse');const fuse2=sources.at(-1);sound.effect('mc-fuse-stop');assert.equal(fuse2.stopped,true);
 sound.pause();assert(sources.every(s=>s.stopped));assert(!sound.snapshot().playing);
 await sound.resumeMusic('mc-ambience',true);sound.setEnabled(false);assert(!sound.snapshot().playing);
 const count=sources.length;sound.effect('mc-explosion');await sound.unlock();assert.equal(sources.length,count);
 sound.setEnabled(true);assert(sound.snapshot().playing);sound.stop();assert.equal(sound.snapshot().track,'');assert.equal(sound.snapshot().activeEffects,0);
});

test('late unlock cannot revive paused or muted sound',async()=>{
 let resolve;const {context,sources}=simulatedContext({state:'suspended',resume:ctx=>new Promise(r=>{resolve=()=>{ctx.state='running';r();};})});
 const sound=createMinecraftSound({contextFactory:()=>context});const pending=sound.resumeMusic('mc-ambience',true);sound.pause();resolve();await pending;
 assert.equal(sources.length,0);assert.equal(sound.snapshot().playing,false);assert.equal(sound.snapshot().pending,false);
});

test('autoplay failure is reported and retried on a later gesture',async()=>{
 let reject=true;const {context}=simulatedContext({state:'suspended',resume:ctx=>{if(reject)return Promise.reject(Object.assign(new Error('gesture'),{name:'NotAllowedError'}));ctx.state='running';return Promise.resolve();}});
 const sound=createMinecraftSound({contextFactory:()=>context});await sound.resumeMusic('mc-ambience',true);assert.equal(sound.blocked,true);assert.equal(sound.snapshot().lastError,'NotAllowedError');
 reject=false;await sound.unlock();assert.equal(sound.blocked,false);assert.equal(sound.snapshot().playing,true);
});

test('shared sound gateway switches families, respects mute, and does not alter Mario sound',async()=>{
 const audio=installSimulatedAudio();const previous=globalThis.AudioContext;const {context,sources}=simulatedContext();globalThis.AudioContext=class{constructor(){return context;}};
 try{
  const sound=createSound();await sound.resumeMusic('overworld',true);const mario=audio.music()[0];sound.effect('jump');assert(audio.instances.some(a=>a.effectKey==='jump'));
  await sound.resumeMusic('mc-ambience',true);assert(mario.paused);assert(sound.snapshot().procedural);sound.effect('jump');assert.equal(sources.at(-1).effectKey,'mc-jump');
  sound.toggle();assert.equal(sound.enabled,false);assert(sources.every(s=>s.stopped));sound.effect('mc-explosion');assert(sources.every(s=>s.stopped));
  await sound.resumeMusic('castle',true);assert(!sound.snapshot().playing);sound.toggle();await Promise.resolve();assert(sound.snapshot().playing);assert.equal(sound.snapshot().track,'castle');assert.equal(audio.music().length,1);sound.stop();
 }finally{audio.restore();if(previous)globalThis.AudioContext=previous;else delete globalThis.AudioContext;}
});

test('native tape has exact event frame offsets, same PCM, cancelled fuse and optional ambience',()=>{
 const source=synthesizeMinecraftSound('mc-sand-settle',{sampleRate:8000});
 const result=renderMinecraftAudioPCM([{type:'sound',event:'mc-sand-settle',frame:30}],{duration:1,fps:60,sampleRate:8000});
 assert(result.pcm.subarray(0,8000).every(v=>v===0));assert.equal(result.pcm[8002],Math.fround(source.pcm[1]*Math.SQRT1_2));assert.equal(result.report.eventCount,1);assert(result.report.rms>0);
 const cancel=renderMinecraftAudioPCM([{event:'mc-fuse',tick:0},{event:'mc-fuse-stop',tick:30}],{duration:2,sampleRate:8000});assert(cancel.pcm.subarray(8000).every(v=>v===0));assert.equal(cancel.report.events[0].end,.5);
 const nested=renderMinecraftAudioPCM([{type:'sound',frame:10,data:{event:'mc-explosion'}}],{duration:2,sampleRate:8000});assert.equal(nested.report.events[0].time,10/60);
 assert.equal(renderMinecraftAudioPCM([],{duration:1,sampleRate:8000}).report.rms,0);
 assert(renderMinecraftAudioPCM([],{duration:5,sampleRate:8000,ambience:true}).report.rms>.001);
});

test('native WAV is decodable PCM with deterministic bytes and correct duration',()=>{
 const tape=[{event:'mc-fuse',tick:0},{event:'mc-explosion',tick:90},{event:'mc-sand',tick:93},{event:'mc-sand-settle',tick:120},{event:'mc-portal',tick:150}],options={duration:4,sampleRate:8000,ambience:true};
 const wav=renderMinecraftAudioTape(tape,options),view=new DataView(wav.buffer);assert.equal(new TextDecoder().decode(wav.subarray(0,4)),'RIFF');assert.equal(view.getUint16(22,true),2);assert.equal(view.getUint32(24,true),8000);assert.equal(view.getUint32(40,true),4*8000*4);assert.deepEqual(wav,renderMinecraftAudioTape(tape,options));
 const result=renderMinecraftAudioPCM(tape,options);assert.equal(result.report.clippedSamples,0);assert(result.report.peak>.2);
});
