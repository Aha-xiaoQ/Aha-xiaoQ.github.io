import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {History,clone,uid,moveSelection,deleteSelection,linked,parseProject} from '../atlas/editor-model.mjs';
import {captureSmm2LightingBindings,appendCopiedSmm2LightingBindings,pruneSmm2LightingReferences} from '../atlas/editor-smm2-lighting-tools.mjs';
import {captureSmm2ActorLeaves,appendCopiedSmm2ActorLeaves,pruneSmm2DeletedReferences} from '../atlas/editor-smm2-tools.mjs';
import {captureSmm2GeometryBindings,appendSmm2GeometryBindings} from '../atlas/editor-smm2-course-tools.mjs';
import {captureSmm2BoneBindings,appendCopiedSmm2BoneBindings} from '../atlas/editor-smm2-bone-tools.mjs';
import {captureMarioEmptyShellSources,appendCopiedMarioEmptyShellSources} from '../atlas/editor-mario-modules-editor.mjs';
import {enableCopiedSpikeTraps} from '../atlas/editor-contraptions-tools.mjs';
import {lightingProject} from './fixtures/lighting-native.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';

// Evaluate the unchanged actual native clipboard/delete handlers in a small
// History/selection host. This covers their real call sequence, not browser
// layout, pointer selection, or a second reimplementation of clipboard logic.
function mountActualClipboard(h,ui){
 const source=fs.readFileSync(new URL('../atlas/editor.mjs',import.meta.url),'utf8'),start=source.indexOf("$('copy').onclick="),end=source.indexOf("$('map-export').onclick=",start);assert(start>=0&&end>start);
 let selectedLayer='geometry';const camera={x:384,y:128},buttons=Object.fromEntries(['copy','paste','delete'].map(id=>[id,ui.document.createElement('button')])),reports=[];
 const host={camera,selected:new Set(),$:id=>buttons[id],room:()=>h.doc.rooms[0],layer:()=>selectedLayer,items:()=>selectedLayer==='geometry'?h.doc.rooms[0].map.geometry:h.doc.rooms[0].map.objects,
  run:fn=>{try{fn();}catch(error){reports.push(error.message);}},say:q=>reports.push(q),refresh:()=>{},transaction:fn=>h.change(()=>{const before=clone(h.doc);fn();pruneSmm2DeletedReferences(h.doc.rooms[0],before.rooms[0]);pruneSmm2LightingReferences(h.doc.rooms[0],before.rooms[0]);}),
  clone,uid,linked,moveSelection,deleteSelection,captureSmm2LightingBindings,appendCopiedSmm2LightingBindings,captureSmm2ActorLeaves,appendCopiedSmm2ActorLeaves,captureSmm2GeometryBindings,appendSmm2GeometryBindings,captureSmm2BoneBindings,appendCopiedSmm2BoneBindings,captureMarioEmptyShellSources,appendCopiedMarioEmptyShellSources,enableCopiedSpikeTraps,
 };
 const api=new Function('host','const {$,room,layer,items,run,say,refresh,transaction,clone,uid,linked,moveSelection,deleteSelection,captureSmm2LightingBindings,appendCopiedSmm2LightingBindings,captureSmm2ActorLeaves,appendCopiedSmm2ActorLeaves,captureSmm2GeometryBindings,appendSmm2GeometryBindings,captureSmm2BoneBindings,appendCopiedSmm2BoneBindings,captureMarioEmptyShellSources,appendCopiedMarioEmptyShellSources,enableCopiedSpikeTraps}=host;let selected=host.selected,clipboard=null;const camera=host.camera;'+source.slice(start,end)+';return {select(ids){selected=ids;},selected(){return selected;}};')(host);
 return {...api,buttons,reports,setLayer:value=>selectedLayer=value,camera};
}

test('actual native editor clipboard handlers copy bound moving geometry and its linked fixed-arrow lights, then delete/undo/redo',()=>{
 const ui=installSimulatedPlayDom();try{
  const d=lightingProject(),r=d.rooms[0];r.markers.find(q=>q.id==='fixed-arrow').id='moving-lift-arrow';r.smm2Mechanics.lighting.sources.find(q=>q.targetId==='fixed-arrow').targetId='moving-lift-arrow';const h=new History(d),native=mountActualClipboard(h,ui),room=()=>h.doc.rooms[0];native.select(new Set(['moving-lift']));native.buttons.copy.click();native.buttons.paste.click();
  const [copy]=native.selected();assert.notEqual(copy,'moving-lift');assert(room().map.geometry.some(q=>q.id===copy));assert(room().markers.some(q=>q.id===copy+'-arrow'));assert.deepEqual(room().smm2Mechanics.lighting.sources.find(q=>q.targetId===copy),{targetId:copy,radius:48});assert.deepEqual(room().smm2Mechanics.lighting.sources.find(q=>q.targetId===copy+'-arrow'),{targetId:copy+'-arrow',radius:24,offsetX:8,offsetY:8});
  native.buttons.delete.click();assert(!room().smm2Mechanics.lighting.sources.some(q=>[copy,copy+'-arrow'].includes(q.targetId)));h.undo();assert(room().smm2Mechanics.lighting.sources.some(q=>q.targetId===copy+'-arrow'));h.redo();assert(!room().map.geometry.some(q=>q.id===copy));assert.deepEqual(parseProject(JSON.stringify(h.doc)),h.doc);
  native.setLayer('objects');native.select(new Set(['falling-pow']));Object.assign(native.camera,{x:320,y:64});native.buttons.copy.click();native.buttons.paste.click();const [pow]=native.selected();assert.notEqual(pow,'falling-pow');assert(room().smm2Mechanics.powBlocks.some(q=>q.id===pow));assert(room().smm2Mechanics.lighting.sources.some(q=>q.targetId===pow));native.buttons.delete.click();assert(!room().smm2Mechanics.lighting.sources.some(q=>q.targetId===pow));assert(!room().smm2Mechanics.powBlocks.some(q=>q.id===pow));assert.deepEqual(parseProject(JSON.stringify(h.doc)),h.doc);
 }finally{ui.restore();}
});
