import assert from 'node:assert/strict';
import {test} from 'node:test';
import {createRailHazards,validateRailHazards} from '../atlas/editor-rail-hazards.mjs';
import {compileRailPath,sampleRailPath} from '../atlas/editor-rail-claws.mjs';
const copy=structuredClone;
const close=(a,b,tolerance=1e-7)=>assert(Math.abs(a-b)<=tolerance,`${a} differs from ${b}`);
const player=(x=99,y=99,w=2,h=2)=>({x,y,w,h,vx:3,vy:-2,power:0,hp:1,coins:7,dead:false});
function room(hazard={},track={},source={}){
 return {roomId:'rail-room',map:{width:320,height:240,geometry:[],objects:[{id:'grinder-a',kind:'hazard',x:76,y:76,w:48,h:48,...source}]},markers:[],contraptions:{version:1,tracks:[{id:'rail-a',start:[100,100],segments:[{kind:'line',to:[200,100]}],mode:'bounce',...track}]},smm2Mechanics:{version:1,railHazards:{version:1,hazards:[{id:'grinder-a',trackId:'rail-a',speed:0,distance:0,direction:1,collisionRadius:22,rotationFrames:60,rotationDirection:1,...hazard}]}}};
}
const hazardView=c=>c.view().hazards[0];

test('omitted or empty typed leaf is inert; sibling mechanics and native data stay untouched',()=>{
 const r=room();delete r.smm2Mechanics.railHazards;r.smm2Mechanics.localUpdrafts={unvalidatedSibling:true};
 assert.doesNotThrow(()=>validateRailHazards(r));assert.equal(createRailHazards(r),null);
 r.smm2Mechanics.railHazards={version:1,hazards:[]};assert.equal(createRailHazards(r),null);
 const explicit=room(),before=copy(explicit);validateRailHazards(explicit);createRailHazards(explicit).step({tick:1});assert.deepEqual(explicit,before);
 const sibling=room();sibling.contraptions.claws=[{unvalidatedSibling:true}];assert.doesNotThrow(()=>validateRailHazards(sibling),'the rail-hazard leaf does not validate a sibling claw mechanic');
});

test('shared path exports sample the existing real quadratic, without altering the authored track',()=>{
 const r=room({}, {segments:[{kind:'quadratic',control:[140,160],to:[200,100]}]}),q=r.contraptions.tracks[0],before=copy(q),path=compileRailPath(q);
 const sampled=sampleRailPath(path,path.length/2);assert(sampled.anchor.y>120);assert(path.points.length>2);assert.deepEqual(q,before);
 close(sampleRailPath(path,0).anchor.x,100);close(sampleRailPath(path,path.length).anchor.x,200);
});

test('native 48px visual has circular center contact and safe overlapping outer corners',()=>{
 const c=createRailHazards(room()),center=player(),corner=player(121,121,3,3),centerBefore=copy(center),cornerBefore=copy(corner);
 assert.equal(c.contact(center),true);assert.equal(c.contact(corner),false);
 const q=c.poseFor('grinder-a');assert.deepEqual(q.center,{x:100,y:100});assert.equal(q.w,48);assert.equal(q.h,48);assert.equal(q.collisionRadius,22);assert.equal(q.collisionShape,'circle');assert.equal(q.x,76);assert.equal(q.y,76);
 assert(corner.x<q.x+q.w&&corner.y<q.y+q.h,'the safe corner still overlaps the full visual square');
 assert.deepEqual(center,centerBefore);assert.deepEqual(corner,cornerBefore);assert.equal(c.poseFor('unowned'),null);
});

test('side and diagonal tangencies are inclusive with EPS, but actual gaps remain safe',()=>{
 const c=createRailHazards(room());assert(c.contact(player(122,99,3,2)));
 const offset=22/Math.SQRT2;assert(c.contact(player(100+offset,100+offset,1,1)));
 assert(!c.contact(player(122+1e-7,99,3,2)));assert(!c.contact(player(100+offset+1e-7,100+offset+1e-7,1,1)));
 assert(c.contact(player(122+1e-12,99,3,2)),'roundoff at a genuine tangent is tolerated');
});

test('continuous hazard travel finds fast and subpixel crossings between clear endpoints',()=>{
 const c=createRailHazards(room({speed:60,collisionRadius:5})),p=player(129,98,2,4),before=copy(p);
 assert(!c.contact(p));assert(c.step({tick:1}));assert.equal(c.poseFor('grinder-a').center.x,160);assert(c.contact(p));assert(c.contact(p,before));assert.deepEqual(p,before);
 const fine=createRailHazards(room({speed:.2,collisionRadius:.05})),tiny=player(100.099,99.99,.002,.02);assert(!fine.contact(tiny));fine.step({tick:1});assert(fine.contact(tiny),'a tiny intermediate crossing is not lost to fixed spatial substeps');
});

test('continuous relative motion handles a fast player and simultaneous opposing movement',()=>{
 const fixed=createRailHazards(room({collisionRadius:5})),from=player(60,98,2,4),to=player(140,98,2,4),a=copy(from),b=copy(to);
 assert(!fixed.contact(from));assert(!fixed.contact(to));assert(fixed.contact(to,from));assert.deepEqual(from,a);assert.deepEqual(to,b);
 const moving=createRailHazards(room({speed:60,collisionRadius:5})),old=player(200,98,2,4),next=player(80,98,2,4);moving.step({tick:1});assert(moving.contact(next,old));
 const parallel=createRailHazards(room({speed:60,collisionRadius:5})),parallelBefore=player(130,98,2,4),parallelAfter=player(190,98,2,4);parallel.step({tick:1});assert(!parallel.contact(parallelAfter,parallelBefore),'matching velocity preserves a clear separation');
});

test('swept circular contact never becomes a square corner hurtbox',()=>{
 const c=createRailHazards(room({speed:2,collisionRadius:5})),p=player(104.5,104.5,1,1);assert(!c.contact(p));c.step({tick:1});assert(!c.contact(p));
 const fast=createRailHazards(room({speed:60,collisionRadius:5}));fast.step({tick:1});assert(!fast.contact(player(128,106,2,2)),'a long horizontal sweep stays clear beyond the real circle radius');
 const diagonalFrom=player(104.5,104.5,1,1),diagonalTo=player(104.6,104.4,1,1);assert(!createRailHazards(room({collisionRadius:5})).contact(diagonalTo,diagonalFrom));
});

test('a full fast rail loop and an out-and-back reversal sweep the travelled path, keeping the center gap safe',()=>{
 const square={start:[100,100],segments:[{kind:'line',to:[150,100]},{kind:'line',to:[150,150]},{kind:'line',to:[100,150]},{kind:'line',to:[100,100]}],mode:'loop'},c=createRailHazards(room({speed:200,collisionRadius:5},square));
 const edge=player(148,123,2,4),gap=player(124,124,2,2);assert(!c.contact(edge));c.step({tick:1});assert.deepEqual(c.poseFor('grinder-a').center,{x:100,y:100});assert(c.contact(edge),'one complete lap is not mistaken for zero motion');assert(!c.contact(gap),'travel on the actual square rail cannot cut diagonally through its center');
 const bounce=createRailHazards(room({speed:200,collisionRadius:5}));bounce.step({tick:1});assert.deepEqual(bounce.poseFor('grinder-a').center,{x:100,y:100});assert(bounce.contact(player(199,99,2,2)),'turnaround contact is not lost when both tick endpoints match');
 const curve={start:[100,100],segments:[{kind:'quadratic',control:[150,180],to:[200,100]}]},curved=createRailHazards(room({speed:100,collisionRadius:2},curve));curved.step({tick:1});assert(curved.contact(player(149,139,2,2)),'fast motion visits the actual quadratic bow');assert(!curved.contact(player(149,110,2,2)),'the endpoint chord is not the actual curved rail');
});

test('swept tangent contact is inclusive and supports a changing native body size',()=>{
 const c=createRailHazards(room({collisionRadius:5})),from=player(60,105,2,2),to=player(140,105,2,2);assert(c.contact(to,from));
 assert(!c.contact({...to,y:105.000001},{...from,y:105.000001}));
 const growingBefore=player(104,104,1,1),growingAfter=player(100,100,8,8);assert(c.contact(growingAfter,growingBefore));
 assert.throws(()=>c.contact(to,{x:60,y:105}),/before-player AABB/);
 for(const flag of ['dead','dying','removed','taken'])assert(!c.contact({...to,x:99,y:99,[flag]:true},from));
 assert(!c.contact({...to,w:0},from));
});

test('motion follows an authored closed curved rail and rotates the same hazard',()=>{
 const oval={start:[120,50],segments:[{kind:'quadratic',control:[160,50],to:[160,90]},{kind:'line',to:[160,150]},{kind:'quadratic',control:[160,190],to:[120,190]},{kind:'quadratic',control:[80,190],to:[80,150]},{kind:'line',to:[80,90]},{kind:'quadratic',control:[80,50],to:[120,50]}],mode:'loop'};
 const r=room({speed:2,rotationFrames:40},oval,{x:96,y:26}),source=copy(r.map.objects[0]),c=createRailHazards(r),initial=c.poseFor('grinder-a');
 for(let tick=1;tick<=35;tick++)c.step({tick});const moved=c.poseFor('grinder-a');assert(moved.center.x>initial.center.x);assert(moved.center.y>initial.center.y);assert.notEqual(moved.angleRadians,initial.angleRadians);close(moved.angleRadians,35*2*Math.PI/40);assert.equal(moved.id,source.id);assert.deepEqual(r.map.objects[0],source);
 const reverse=createRailHazards(room({rotationDirection:-1,rotationFrames:40}));reverse.step({tick:1});close(reverse.poseFor('grinder-a').angleRadians,-2*Math.PI/40);
});

test('explicit loop and bounce boundaries preserve path position and emit useful events only',()=>{
 const events=[],loop={start:[100,100],segments:[{kind:'line',to:[180,100]},{kind:'line',to:[180,180]},{kind:'line',to:[100,180]},{kind:'line',to:[100,100]}],mode:'loop'};
 const c=createRailHazards(room({distance:315,speed:10},loop),{emit:(type,event)=>events.push({type,...event})});c.step({tick:1});assert.equal(hazardView(c).distance,5);assert.deepEqual(c.poseFor('grinder-a').center,{x:105,y:100});assert.equal(hazardView(c).direction,1);assert(events.some(q=>q.event==='track-loop'));
 const reverse=createRailHazards(room({distance:5,speed:10,direction:-1},loop));reverse.step({tick:1});assert.equal(hazardView(reverse).distance,315);assert.deepEqual(reverse.poseFor('grinder-a').center,{x:100,y:105});
 const bounced=createRailHazards(room({distance:95,speed:10}),{emit:(type,event)=>events.push({type,...event})});bounced.step({tick:1});assert.equal(hazardView(bounced).distance,95);assert.equal(hazardView(bounced).direction,-1);bounced.step({tick:2});assert.equal(hazardView(bounced).distance,85);assert(events.some(q=>q.event==='track-reversal'));
 const quiet=[],slow=createRailHazards(room({speed:.1}),{emit:(type,event)=>quiet.push({type,...event})});for(let tick=1;tick<=100;tick++)slow.step({tick});assert.deepEqual(quiet.map(q=>q.event),['motion-start']);assert.equal(quiet[0].type,'rail-hazard');assert.equal(quiet[0].tuningStatus,'explicit-author-configuration');
});

test('explicit ticks dedupe simulation; view and pose projections are copies; reset reproduces the seed',()=>{
 const r=room({speed:2}),authored=copy(r),events=[],c=createRailHazards(r,{emit:(type,event)=>events.push({type,...event})}),initial=copy(c.view());
 const firstPose=c.poseFor('grinder-a');firstPose.center.x=999;firstPose.x=999;assert.deepEqual(c.view(),initial);
 assert(c.step({tick:9}));const advanced=copy(c.view()),eventCount=events.length;assert.equal(c.step({tick:9}),false);assert.equal(c.step({tick:8}),false);assert.deepEqual(c.view(),advanced);assert.equal(events.length,eventCount);
 const exposed=c.view();exposed.hazards[0].center.x=999;exposed.hazards[0].speed=99;exposed.tracks[0].start[0]=999;assert.deepEqual(c.view(),advanced);assert.deepEqual(r,authored);
 for(const tick of [undefined,-1,NaN,Infinity,.5,Number.MAX_SAFE_INTEGER+1])assert.throws(()=>c.step({tick}),/tick/);
 c.reset();assert.deepEqual(c.view(),initial);assert(c.step({tick:9}));assert.deepEqual(c.view(),advanced);assert.equal(events.length,eventCount+1);
 r.smm2Mechanics.railHazards.hazards[0].speed=100;r.map.objects[0].w=80;c.step({tick:10});assert.equal(c.poseFor('grinder-a').center.x,104);assert.equal(c.poseFor('grinder-a').w,48,'live configuration is a captured copy');
});

test('every hazard tuning field is mandatory and aliases or hidden fields are rejected',()=>{
 const keys=Object.keys(room().smm2Mechanics.railHazards.hazards[0]);
 for(const key of keys){const r=room();delete r.smm2Mechanics.railHazards.hazards[0][key];assert.throws(()=>validateRailHazards(r),/Missing rail hazard field/);}
 for(const extra of [{position:0},{radius:22},{anchor:[100,100]},{path:[]},{collisionBox:true},{approximation:true}])assert.throws(()=>validateRailHazards(room(extra)),/Unknown rail hazard field/);
 for(const spec of [null,[],{version:2,hazards:[]},{version:1,hazards:[],extra:true},{hazards:[]}]){const r=room();r.smm2Mechanics.railHazards=spec;assert.throws(()=>validateRailHazards(r),/rail hazards/);}
});

test('native identity, square body and same-room existing track are required',()=>{
 for(const patch of [{kind:'walker'},{w:47},{x:-1},{h:0},{x:Infinity}])assert.throws(()=>validateRailHazards(room({}, {},patch)),/square native hazard/);
 const missing=room();missing.map.objects=[];assert.throws(()=>validateRailHazards(missing),/native hazard/);
 const duplicate=room();duplicate.map.geometry.push({id:'grinder-a',x:0,y:0,w:1,h:1});assert.throws(()=>validateRailHazards(duplicate),/native hazard/);
 const repeated=room();repeated.smm2Mechanics.railHazards.hazards.push(copy(repeated.smm2Mechanics.railHazards.hazards[0]));assert.throws(()=>validateRailHazards(repeated),/Duplicate/);
 assert.throws(()=>validateRailHazards(room({trackId:'missing'})),/existing same-room track/);
 const untracked=room();delete untracked.contraptions;assert.throws(()=>validateRailHazards(untracked),/existing same-room track/);
 assert.throws(()=>validateRailHazards(room({id:'__proto__'})),/invalid rail hazard ID/);
 const foreignPrototype=room();foreignPrototype.smm2Mechanics.railHazards.hazards[0]=Object.assign(Object.create({position:0}),foreignPrototype.smm2Mechanics.railHazards.hazards[0]);assert.throws(()=>validateRailHazards(foreignPrototype),/Invalid rail hazard/);
});

test('strict values reject invalid directions, radius, rotation and distances without mutation',()=>{
 const bad=[{speed:-1},{speed:Infinity},{speed:257},{distance:-1},{distance:101},{direction:0},{direction:'1'},{collisionRadius:0},{collisionRadius:24.1},{collisionRadius:NaN},{rotationFrames:0},{rotationFrames:1},{rotationFrames:2.5},{rotationFrames:36001},{rotationDirection:0}];
 for(const rule of bad){const r=room(rule),before=copy(r);assert.throws(()=>validateRailHazards(r),/explicit rail hazard/);assert.deepEqual(r,before);}
 const tinyLoop={start:[100,100],segments:[{kind:'line',to:[100.00001,100]},{kind:'line',to:[100,100]}],mode:'loop'};assert.throws(()=>validateRailHazards(room({speed:256},tinyLoop)),/bounded work budget/);
});

test('reuse track schema rejects aliases and malformed closure; visual bounds cover whole curves',()=>{
 assert.throws(()=>validateRailHazards(room({}, {path:[[100,100],[200,100]]})),/Unknown track field/);
 assert.throws(()=>validateRailHazards(room({}, {mode:'loop'})),/must close/);
 assert.throws(()=>validateRailHazards(room({}, {segments:[{kind:'quadratic',control:[-1,100],to:[200,100]}]})),/outside room/);
 const leaves=room({}, {start:[30,50],segments:[{kind:'quadratic',control:[0,100],to:[30,150]}]});assert.throws(()=>validateRailHazards(leaves),/visual bounds/);
 const fits=room({}, {start:[30,50],segments:[{kind:'quadratic',control:[20,100],to:[30,150]}]});assert.doesNotThrow(()=>validateRailHazards(fits),'control outside the visual margin does not mean the actual curve leaves it');
 assert.throws(()=>validateRailHazards(room({}, {start:[23,100]})),/visual bounds/);
 const target=24-1e-5,d=30-target,b=-60+2*d,control=(-b-Math.sqrt(b*b-4*(900-61*d)))/2;
 const between=room({}, {start:[30,50],segments:[{kind:'quadratic',control:[control,100],to:[31,150]}]});
 assert(compileRailPath(between.contraptions.tracks[0]).points.every(p=>p[0]>=24),'the narrow extrema violation lies between compiler samples');assert.throws(()=>validateRailHazards(between),/visual bounds/);
});
