import test from 'node:test';
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {mixScenePCM} from '../renderer-audio/mix-native-scene-audio.mjs';

const stereo = frames => new Float32Array(frames * 2);
const mapping = {castle: 'castle-loop.wav', overworld: 'overworld.mp3', stomp: 'stomp.wav', bowser_fire: 'bowser_fire.mp3'};
const bgm = stereo(4800).fill(.1), effect = stereo(4800).fill(.2);
const clips = () => new Map([['castle-loop.wav', bgm], ['overworld.mp3', bgm], ['stomp.wav', effect], ['bowser_fire.mp3', effect]]);

test('scene music remains present across loop seams and Boss hit/defeat one-shots', () => {
  const musicIntervals = [{startFrame: 0, endFrame: 60, key: 'castle'}, {startFrame: 60, endFrame: 90, key: 'overworld'}];
  const events = [6, 24, 42, 59].map(frame => ({frame, type: 'sound', event: 'stomp'}));
  const result = mixScenePCM({events, fps: 60, duration: 1.5, clips: clips(), musicIntervals, audioFiles: mapping});
  assert.deepEqual(result.report.musicSilentSampleSpans, []);
  assert.deepEqual(result.report.musicSourceQuietSampleSpans, []);
  assert.equal(result.report.musicActiveSampleFrames, 72000);
  assert.equal(result.report.musicTimeline[0].completeLoopCount, 10);
  assert(result.pcm.every(value => value > .0349));
  assert.equal(result.report.musicGain, .35);
  assert.equal(result.report.effectGain, .65);
});

test('BGM-only energy diagnostics detect an internal music gap filled by loud effects', () => {
  const source = stereo(4800).fill(.1); source.fill(0, 960, 2880);
  const loud = stereo(4800).fill(.4);
  const result = mixScenePCM({events: [{type: 'sound', event: 'stomp', frame: 0}], fps: 60, duration: .1,
    clips: new Map([['castle-loop.wav', source], ['stomp.wav', loud]]),
    musicIntervals: [{startFrame: 0, endFrame: 6, key: 'castle'}], audioFiles: mapping});
  assert(result.pcm.every(value => value > .25), 'loud effects conceal the missing BGM in combined RMS');
  assert.deepEqual(result.report.musicSilentSampleSpans, [], 'a declared active interval alone is insufficient');
  assert.deepEqual(result.report.musicSourceQuietSampleSpans.map(({startSampleFrame, endSampleFrame}) => [startSampleFrame, endSampleFrame]), [[480, 1440]]);
  assert.equal(result.report.musicTimeline[0].musicEnergy.minimumWindowRms, 0);
  assert.equal(result.report.musicTimeline[0].musicEnergy.quietSampleFrames, 960);
});

test('explicit pause/finish gaps and cursor reset on a new segment remain authoritative', () => {
  const source = stereo(4800); for (let i = 0; i < source.length; i++) source[i] = .1 + i / 100000;
  const result = mixScenePCM({events: [], fps: 60, duration: .5, clips: new Map([['castle-loop.wav', source]]),
    musicIntervals: [{startFrame: 0, endFrame: 6, key: 'castle'}, {startFrame: 6, endFrame: 12, key: null},
      {startFrame: 18, endFrame: 30, key: 'castle'}], audioFiles: mapping});
  assert.deepEqual(result.report.musicSilentSampleSpans.map(({startSampleFrame, endSampleFrame}) => [startSampleFrame, endSampleFrame]), [[4800, 9600], [9600, 14400]]);
  assert.equal(result.pcm[0], result.pcm[14400 * 2]);
  assert(result.pcm.subarray(4800 * 2, 14400 * 2).every(value => value === 0));
});

test('actual restored Castle source remains energetic over three decoded loops at unchanged gain', () => {
  const input = new URL('../atlas/assets/classic-audio/castle-loop.wav', import.meta.url);
  const decoded = spawnSync('ffmpeg', ['-nostdin', '-v', 'error', '-i', fileURLToPath(input), '-ar', '48000', '-ac', '2', '-f', 'f32le', 'pipe:1'], {maxBuffer: 8 * 1024 * 1024});
  assert.equal(decoded.status, 0, decoded.stderr?.toString());
  const bytes = new Uint8Array(decoded.stdout.length); bytes.set(decoded.stdout);
  const source = new Float32Array(bytes.buffer);
  const result = mixScenePCM({events: [], fps: 60, duration: 26.766666666666666,
    clips: new Map([['castle-loop.wav', source]]), musicIntervals: [{startFrame: 0, endFrame: 1606, key: 'castle'}], audioFiles: mapping});
  const timeline = result.report.musicTimeline[0];
  assert.equal(timeline.completeLoopCount, 3);
  assert.equal(timeline.sourceSampleFrames, 383408);
  assert(timeline.musicEnergy.minimumWindowRms > .018);
  assert.equal(timeline.musicEnergy.quietSampleFrames, 0);
  assert.deepEqual(result.report.musicSourceQuietSampleSpans, []);
  assert.equal(result.report.musicGain, .35);
});
