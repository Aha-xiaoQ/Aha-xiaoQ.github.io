import {test} from 'node:test';
import assert from 'node:assert/strict';
import {History,parseProject,validate,clone} from '../atlas/editor-model.mjs';
import {setSmm2ShellCoinCollection,clearSmm2ShellCoinCollection,captureSmm2ActorLeaves,appendCopiedSmm2ActorLeaves} from '../atlas/editor-smm2-authoring.mjs';
import {mountSmm2Tools} from '../atlas/editor-smm2-tools.mjs';
import {createCollection,addLevel,parseCollection,serializeCollection,buildCollection} from '../atlas/editor-collection.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';
import {shellProject,character} from './fixtures/shell-coin-native.mjs';

test('shell collection room flag is atomic, Boolean-only, default-off and import-safe',()=>{
 const h=new History(shellProject({rule:null})),r=()=>h.doc.rooms[0],physical=JSON.stringify(r().map);assert.equal(r().smm2Mechanics.shellCoinCollection,undefined);
 for(const bad of [null,0,1,'true',[],{playerActivated:true}]){const before=JSON.stringify(h.doc);assert.throws(()=>h.change(()=>setSmm2ShellCoinCollection(r(),bad)),/boolean/);assert.equal(JSON.stringify(h.doc),before);const raw=clone(h.doc);raw.rooms[0].smm2Mechanics.shellCoinCollection=bad;assert.throws(()=>parseProject(JSON.stringify(raw)),/shell coin collection/);}
 h.change(()=>setSmm2ShellCoinCollection(r(),true));assert.equal(r().smm2Mechanics.shellCoinCollection,true);assert.equal(JSON.stringify(r().map),physical);assert.deepEqual(parseProject(JSON.stringify(h.doc)),h.doc);
 h.change(()=>clearSmm2ShellCoinCollection(r()));assert.equal(r().smm2Mechanics.shellCoinCollection,undefined);h.undo();assert.equal(r().smm2Mechanics.shellCoinCollection,true);h.redo();assert.equal(r().smm2Mechanics.shellCoinCollection,undefined);
 const hostile=clone(h.doc);hostile.rooms[0].smm2Mechanics=JSON.parse('{"version":1,"shellCoinCollection":true,"__proto__":{"playerActivated":true}}');assert.throws(()=>validate(hostile),/Unknown SMM2 mechanics field/);
});
test('real SMM2 sidebar checkbox changes History and refreshes after undo/redo',()=>{
 const ui=installSimulatedPlayDom();try{const h=new History(shellProject({rule:null})),r=()=>h.doc.rooms[0],parent=ui.document.createElement('aside'),panel=mountSmm2Tools({parent,room:r,selected:()=>new Set(),change:fn=>h.change(fn),report:message=>{throw Error(message);}}),box=parent.querySelector('[data-smm2-control="shell-coin-collection"]');assert(box);assert.equal(box.checked,false);box.checked=true;box.dispatchEvent({type:'change'});assert.equal(r().smm2Mechanics.shellCoinCollection,true);h.undo();panel.refresh();assert.equal(box.checked,false);h.redo();panel.refresh();assert.equal(box.checked,true);box.checked=false;box.dispatchEvent({type:'change'});assert.equal(r().smm2Mechanics.shellCoinCollection,false);}finally{ui.restore();}
});
test('actor duplication remaps pink stable IDs without copying room policy or runtime ownership',()=>{
 const d=shellProject({pink:true}),r=d.rooms[0],copy=clone(r);copy.roomId='copy';assert.equal(copy.smm2Mechanics.shellCoinCollection,true);const snapshot=captureSmm2ActorLeaves(r,new Set(['shell-body','coin-0'])),idMap=new Map([['shell-body','shell-copy'],['coin-0','coin-copy']]);assert(!Object.hasOwn(snapshot,'shellCoinCollection'));for(const [old,id]of idMap){const o=r.map.objects.find(o=>o.id===old);r.map.objects.push({...o,id,x:o.x+16});}appendCopiedSmm2ActorLeaves(r,snapshot,idMap);assert(r.smm2Mechanics.pinkCoins.some(q=>q.id==='coin-copy'));assert.equal(r.smm2Mechanics.shellCoinCollection,true);assert(!JSON.stringify(r).includes('playerActivated'));assert.deepEqual(parseProject(JSON.stringify(d)),d);
});
test('collection import/export and compilation retain the opt-in in matching visual rooms',()=>{
 const d=shellProject({pink:true}),c=addLevel(createCollection('Shell contact fixture'),d,{id:'shell-contact'}),level=c.levels[0],again=parseCollection(serializeCollection(c));assert.equal(again.levels[0].project.rooms[0].smm2Mechanics.shellCoinCollection,true);assert.equal(level.project.rooms[0].smm2Mechanics.shellCoinCollection,true);const built=buildCollection(again,character,{includePending:true});assert.equal(built.levels[0].rooms[0].smm2Mechanics.shellCoinCollection,true);assert(!Object.hasOwn(built.levels[0].pack.maps[0],'smm2Mechanics'));
});
