import test from 'node:test';
import assert from 'node:assert/strict';
import {createSkyShooter,validateSkyShooterRoom,SKY_SHOOTER_LOOP_FIELDS} from '../atlas/editor-sky-shooter.mjs';
import {History,parseProject,deleteSelection} from '../atlas/editor-model.mjs';
import {setSkyShooter,removeSkyShooter,captureSkyShooterBindings,appendCopiedSkyShooterBindings,mountSkyShooterTools} from '../atlas/editor-sky-shooter-tools.mjs';
import {skyShooterProject,skyShooterBodies} from './fixtures/sky-shooter.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';
import {neutralLoopProject as project} from './fixtures/sky-shooter-loop.mjs';
import {createCollection,addLevel,buildCollection,requiredCollectionCapabilities,parseCollection,serializeCollection} from '../atlas/editor-collection.mjs';
import {character} from './fixtures/shell-coin-native.mjs';

// Neutral tool contract. No private map factory, course route or research asset.
function session(){
 const r=project().rooms[0],enemies=skyShooterBodies(r),events=[],hits=[],geometry=structuredClone(r.map.geometry),p={x:180,y:280,w:10,h:14,vx:0,vy:0,lakituCloudId:'ride',dead:false,power:0};let tick=0;
 const c=createSkyShooter(r,{emit:(type,data)=>events.push({type,...data}),defeatEnemy:(e,hit)=>{hits.push(hit);e.dead=true;return true;}});
 return {r,c,enemies,events,hits,geometry,p,step(input={}){return c.step({tick:++tick,player:p,input,enemies,geometry});}};
}
test('looping divers are a strict bounded optional schema and absent legacy leaves retain their exact view shape',()=>{
 assert(validateSkyShooterRoom(project().rooms[0]));
 const changes=[s=>s.loopingDivers=null,s=>s.loopingDivers.version=2,s=>s.loopingDivers.extra=1,s=>s.loopingDivers.actorIds=[],s=>s.loopingDivers.actorIds=['drone-a','drone-a'],s=>s.loopingDivers.actorIds=['missing'],s=>s.loopingDivers.actorIds=['reward-pink'],s=>s.loopingDivers.maxActive=2,s=>s.loopingDivers.maxActive=0,s=>s.loopingDivers.exitSpeed=Infinity,s=>s.loopingDivers.reentrySpeed=.49,s=>s.loopingDivers.returnSpeed=4.01,s=>s.loopingDivers.reentryY=114,s=>s.loopingDivers.sideX=176,s=>s.loopingDivers.exitY=351,s=>s.drones[2].wave=2];
 for(const change of changes){const d=project();change(d.rooms[0].smm2Mechanics.skyShooter);assert.throws(()=>validateSkyShooterRoom(d.rooms[0]));}
 for(const field of SKY_SHOOTER_LOOP_FIELDS){const d=project();delete d.rooms[0].smm2Mechanics.skyShooter.loopingDivers[field];assert.throws(()=>validateSkyShooterRoom(d.rooms[0]),/Missing/);}
 const blocked=project();blocked.rooms[0].map.geometry.push({id:'solid-in-return',x:144,y:240,w:16,h:16,collision:'solid',material:'stone'});assert.throws(()=>validateSkyShooterRoom(blocked.rooms[0]),/crosses native solid/);
 const legacy=createSkyShooter(skyShooterProject().rooms[0]).view();assert(!Object.hasOwn(legacy,'loopingDivers'));assert(legacy.drones.every(q=>!Object.hasOwn(q,'looping')&&!Object.hasOwn(q,'returns')));
});
test('one explicit looping formation allows at most24 base bodies plus six bound divers, and never silently expands legacy24',()=>{
 const d=project(),r=d.rooms[0],s=r.smm2Mechanics.skyShooter;s.drones=[];r.map.objects=r.map.objects.filter(q=>q.kind!=='walker');
 for(let n=0;n<30;n++){const id='neutral-body-'+n,x=200+(n%10)*28,y=128+Math.floor(n/10)*24;r.map.objects.push({id,kind:'walker',x,y,w:16,h:16});s.drones.push({id,wave:1,x,y,phaseFrames:0});}
 s.loopingDivers.actorIds=s.drones.slice(0,6).map(q=>q.id);assert(validateSkyShooterRoom(r));
 s.loopingDivers.actorIds.pop();assert.throws(()=>validateSkyShooterRoom(r),/at most 24 base/);s.loopingDivers.actorIds.push(s.drones[5].id);delete s.loopingDivers;assert.throws(()=>validateSkyShooterRoom(r),/drone list/);
});
test('a missed living diver completes two continuous same-object exit/top-return cycles before one physical shot defeats it once',()=>{
 const s=session(),original=s.enemies[0],pBefore=structuredClone(s.p);let previous={x:original.x,y:original.y},frames=0;
 while(s.c.view().loopingDivers.cycles[0].returns<2&&frames++<2400){s.step();assert.strictEqual(s.enemies[0],original);assert(Math.hypot(original.x-previous.x,original.y-previous.y)<=2.300001);previous={x:original.x,y:original.y};assert.equal(s.c.view().defeated,0);assert(!original.dead);assert(s.c.view().loopingDivers.active<=1);}
 assert.equal(s.c.view().loopingDivers.cycles[0].returns,2);assert.deepEqual(s.p,pBefore);assert.equal(s.hits.length,0);assert(!s.geometry.find(q=>q.id==='reward-gate').hidden);
 for(const event of ['dive-launch','diver-exit-start','diver-exit','diver-top-reentry','diver-slot-approach','diver-formation-return'])assert(s.events.filter(q=>q.event===event&&q.actorId===original.id).length>=2,event);
 const top=s.events.find(q=>q.event==='diver-top-reentry');assert.equal(top.position.x,144);assert.equal(top.position.y,100);assert.deepEqual(top.slot,{x:208,y:120});
 assert(!s.c.isActiveActor({...original}),'same-ID replacement is not the registered native body');
 s.p.x=original.x-3;s.p.y=200;for(let n=0;n<40&&!original.dead;n++)s.step({run:true});assert(original.dead);assert.equal(s.c.view().defeated,1);assert.equal(s.events.filter(q=>q.event==='native-defeat-confirmed'&&q.actorId===original.id).length,1);assert(!s.c.defeatedActor(original));
 for(let n=0;n<600;n++)s.step();assert(!s.c.view().drones.some(q=>q.id===original.id));assert.equal(s.events.filter(q=>q.event==='native-defeat-confirmed'&&q.actorId===original.id).length,1);assert.equal(s.c.view().defeated,1);
});
test('loop attacks keep48 full locked warning ticks and real upper return never grants defeat progress',()=>{
 const s=session();s.step();while(!s.c.view().warnings.length)s.step();const warning=s.c.view().warnings[0];assert.equal(warning.remainingFrames,48);s.p.x=350;
 for(let n=0;n<47;n++)s.step();assert(!s.events.some(q=>q.event==='dive-launch'));s.step();assert.deepEqual(s.events.find(q=>q.event==='dive-launch').target,warning.target);assert.equal(s.c.view().defeated,0);
 const initial=createSkyShooter(s.r).view();s.c.reset();assert.deepEqual(s.c.view(),initial);
});
test('loop configuration round-trips through real History and the JSON author panel, then bound deletion removes the whole group',()=>{
 const h=new History(project()),r=()=>h.doc.rooms[0],original=structuredClone(r().smm2Mechanics.skyShooter),restore=installSimulatedPlayDom();
 try{const ui=mountSkyShooterTools({parent:document.createElement('div'),room:r,change:fn=>h.change(fn)}),field=ui.panel.querySelector('[data-sky-shooter="config"]'),next=JSON.parse(field.value);next.loopingDivers.returnSpeed=1.5;field.value=JSON.stringify(next);ui.panel.querySelector('[data-sky-shooter="apply"]').onclick();assert.equal(r().smm2Mechanics.skyShooter.loopingDivers.returnSpeed,1.5);assert.deepEqual(parseProject(JSON.stringify(h.doc)),h.doc);h.undo();assert.deepEqual(r().smm2Mechanics.skyShooter,original);h.redo();assert.equal(r().smm2Mechanics.skyShooter.loopingDivers.returnSpeed,1.5);
  const invalid=structuredClone(r().smm2Mechanics.skyShooter);invalid.loopingDivers.actorIds=['absent'];const before=JSON.stringify(h.doc);assert.throws(()=>h.change(()=>setSkyShooter(r(),invalid)));assert.equal(JSON.stringify(h.doc),before);
  h.change(()=>deleteSelection(r(),'objects',new Set(['drone-a'])));assert.equal(r().smm2Mechanics.skyShooter,undefined);assert(r().map.objects.some(q=>q.id==='reward-pink'));h.undo();assert(r().smm2Mechanics.skyShooter.loopingDivers);assert.deepEqual(parseProject(JSON.stringify(h.doc)),h.doc);
 }finally{restore.restore();}
});
test('full group copy remaps looping native IDs and all corridor coordinates atomically',()=>{
 const r=project().rooms[0],s=r.smm2Mechanics.skyShooter,ids=new Set([s.cloudId,s.rewardId,...s.gateIds,...s.drones.map(q=>q.id)]),snapshot=captureSkyShooterBindings(r,ids),target=structuredClone(r),idMap=new Map([...ids].map(k=>[k,k+'-copy'])),dx=8,dy=8;
 removeSkyShooter(target);target.map.height+=dy;target.map.width+=dx;for(const q of [...target.map.objects,...target.map.geometry]){q.x+=dx;q.y+=dy;if(idMap.has(q.id))q.id=idMap.get(q.id);}target.smm2Mechanics.lakituClouds.clouds[0].id=idMap.get(s.cloudId);target.smm2Mechanics.pinkCoins[0].id=idMap.get(s.rewardId);
 appendCopiedSkyShooterBindings(target,snapshot,idMap,{dx,dy});const loop=target.smm2Mechanics.skyShooter.loopingDivers;assert.deepEqual(loop.actorIds,['drone-a-copy']);assert.equal(loop.sideX,152);assert.equal(loop.reentryY,108);assert.equal(loop.exitY,328);assert(validateSkyShooterRoom(target));assert.deepEqual(snapshot,s);
});
test('qcollection strict round-trip and real compiler preserve optional return bindings and advertise the separate capability',()=>{
 const d=project(),caps=requiredCollectionCapabilities(d);assert(caps.includes('authored-armed-cloud-arcade-v1'));assert(caps.includes('authored-armed-cloud-looping-divers-v1'));assert(!requiredCollectionCapabilities(skyShooterProject()).includes('authored-armed-cloud-looping-divers-v1'));
 const collection=addLevel(createCollection('Neutral explicit return'),d,{id:'return-fixture'});assert.deepEqual(parseCollection(serializeCollection(collection)),collection);const built=buildCollection(collection,character,{includePending:true});assert(built.requiredCapabilities.includes('authored-armed-cloud-looping-divers-v1'));assert.deepEqual(built.levels[0].rooms[0].smm2Mechanics.skyShooter.loopingDivers,d.rooms[0].smm2Mechanics.skyShooter.loopingDivers);
});
