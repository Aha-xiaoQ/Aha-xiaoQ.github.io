import test from 'node:test';
import assert from 'node:assert/strict';
import {blank,validate,parseProject} from '../atlas/editor-model.mjs';
import {createPlatformStage} from '../atlas/editor-mario-stage.mjs';
import {createPlatformMotor} from '../atlas/editor-mario-motor.mjs';
const character={capabilities:['jump'],motion:{width:10,height:14,maxHealth:1}};
function fixture(){const d=blank('Bone boat fixture',640,240),r=d.rooms[0];r.setting='Castle';r.map.geometry=[{id:'land',x:0,y:176,w:128,h:64,collision:'solid',material:'castle'},{id:'drop-demo',x:64,y:128,w:32,h:8,collision:'oneway',material:'platform'}];r.map.objects=[{id:'start',kind:'spawn',x:48,y:162,w:10,h:14},{id:'boat',kind:'walker',x:96,y:160,w:16,h:16}];r.markers=[{id:'pool',kind:'lava-volume',x:0,y:192,w:640,h:48,source:{width:320}}];r.smm2Mechanics={version:1,startingLives:3,boneShells:[{id:'boat',playingDead:{durationFrames:12,maxFrames:24,dropThroughIds:['drop-demo']}}],liquid:{markerId:'pool',kind:'lava',minY:176,maxY:192,initialY:192,speed:.5,direction:-1,waitMinFrames:0,waitMaxFrames:0}};validate(d);return parseProject(JSON.stringify(d));}
function session(doc=fixture()){const r=doc.rooms[0],events=[],s=createPlatformStage({plan:{stage:{entryRoom:r.roomId,entrySpawn:'start',title:doc.title},character,rooms:{[r.roomId]:r.map}},motor:createPlatformMotor(),visualRooms:doc.rooms,initialState:{lives:3,power:0},autoContinue:false,allowWarp:false,emit:(type,data)=>events.push({type,...data})});return{s,events,step:(n,input={})=>{for(let f=0;f<n;f++)s.step(input);return s.view();}};}
function board(h){for(let f=0;f<220;f++){const v=h.s.view();if(v.p.shoeId==='boat')return v;h.s.step({x:v.p.x<95?1:v.p.x>102?-1:0,jump:f%50<12});}throw Error('ordinary boarding failed '+JSON.stringify(h.s.view().p));}
test('ordinary jump boards a real empty Bone Shell and actual rising/falling lava carries it',()=>{
 const h=session();board(h);h.step(100,{x:1,run:true});let samples=0;
 for(let f=0;f<96;f++){const v=h.step(1),q=v.p.smm2Shoe;assert.equal(v.lives,3);assert.equal(q.kind,'bone-shell');assert.equal(q.occupancy,'player');assert(Math.abs(q.y+q.h-v.smm2Mechanics.liquid.y)<1.01,'boat feet must be on live surface');assert(!v.geometry.some(g=>g.id==='pool-boat-surface'));samples++;}
 assert.equal(samples,96);assert(h.events.some(e=>e.type==='smm2-liquid'&&e.event==='surface-limit'));assert(h.events.some(e=>e.type==='smm2-shoe'&&e.event==='board-empty'));
});
test('bare Mario really falls into lava and spends a life without a hidden water platform',()=>{
 const h=session();for(let f=0;f<180&&!h.s.view().p.dying;f++)h.s.step({x:1,run:true});const v=h.s.view();assert(v.p.dying);assert.equal(v.lives,2);assert(!v.geometry.some(g=>g.id==='pool-boat-surface'));assert.equal(h.events.filter(e=>e.type==='sound'&&e.event==='death').length,1);
});
test('playing dead is a bounded real vehicle state and jump/shoulder exit remain distinct',()=>{
 const h=session();board(h);h.step(1,{down:true});let v=h.s.view();assert(v.p.smm2Shoe.playingDead);assert.equal(v.p.smm2Shoe.h,4);h.step(2,{down:true});v=h.step(1,{jump:true});assert.equal(v.p.smm2Shoe.playingDead,false);assert.equal(v.p.shoeId,'boat');assert(v.p.vy<0);h.step(50);h.step(1,{down:true});h.step(26,{down:true});assert.equal(h.s.view().p.smm2Shoe.playingDead,false);const after=h.step(1,{dismount:true});assert.equal(after.p.shoeId,undefined);assert.equal(after.enemies.find(q=>q.id==='boat').smm2Shoe.occupancy,'empty');assert.equal(after.enemies.find(q=>q.id==='boat').h,16);assert(after.p.vy<0);
});
test('bone project roundtrip rejects opaque collapse/float flags and missing drop targets',()=>{
 const d=fixture();const r=d.rooms[0];r.smm2Mechanics.boneShells[0].playingDead.dropThroughIds=['missing'];assert.throws(()=>validate(d));
 const e=fixture();e.rooms[0].smm2Mechanics.boneShells[0].godMode=true;assert.throws(()=>validate(e));
});
test('rising liquid does not push a mounted body through a real solid ceiling',()=>{
 const d=fixture(),r=d.rooms[0];r.map.geometry.push({id:'roof',x:128,y:96,w:256,h:60,material:'castle',collision:'solid'});const h=session(d);board(h);
 let priorX=h.s.view().p.x;for(let f=0;f<170;f++){const v=h.step(1,{x:1,run:true}),b=v.p.smm2Shoe?.contactBody;if(b&&v.p.x>130&&v.p.x<380)assert(!(b.x<384&&b.x+b.w>128&&b.y<156&&b.y+b.h>96),'boat carrier must respect solid ceiling');assert(Math.abs(v.p.x-priorX)<=3.51,'liquid carry must not eject the rider across the roof');priorX=v.p.x;}
});
test('sideways entry below a high lava surface recovers only the real Bone carrier without a bare-player platform',()=>{
 const d=fixture(),r=d.rooms[0];r.markers[0].x=128;r.markers[0].w=512;r.markers[0].y=160;
 Object.assign(r.smm2Mechanics.liquid,{minY:160,maxY:160,initialY:160,speed:0});
 const h=session(d);board(h);let entered=0;
 for(let f=0;f<140;f++){
  const v=h.step(1,{x:1,run:true}),a=v.p.smm2Shoe;
  assert.equal(v.lives,3);
  if(a&&a.x+a.w>128&&a.x<640){entered++;assert(Math.abs(a.y+a.h-160)<=1.01,'lateral fluid entry cannot settle on a submerged basement');}
  assert(!v.geometry.some(g=>g.id==='pool-boat-surface'));
 }
 assert(entered>40);assert(h.events.some(e=>e.type==='smm2-shoe'&&e.event==='liquid-volume-recovery'));
});
