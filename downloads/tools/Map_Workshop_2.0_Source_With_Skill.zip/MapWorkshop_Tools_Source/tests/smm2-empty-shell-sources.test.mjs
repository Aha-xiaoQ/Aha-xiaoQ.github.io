import {test} from 'node:test';
import assert from 'node:assert/strict';
import {parseProject} from '../atlas/editor-model.mjs';
import {createMarioModules,validateMarioModulesRoom} from '../atlas/editor-mario-modules.mjs';
import {createPlatformStage} from '../atlas/editor-mario-stage.mjs';
import {createSMM2Terrain,sampleSMM2Surface} from '../atlas/editor-smm2-terrain.mjs';
import {emptyShellProject,nativeSession,settleEmptyShell,sideKickEmptyShell} from './fixtures/empty-shell-native.mjs';
import {overlaps,shellPickups,checkPhysicalPickups} from './fixtures/shell-coin-native.mjs';

test('empty Buzzy shell source is explicitly typed and rejects an occupant, templates and unbounded emergence',()=>{
 const d=emptyShellProject();assert.deepEqual(parseProject(JSON.stringify(d)),d);
 for(const values of [{enemy:'beetle'},{smart:true},{shoeTemplateId:'unused'},{emergenceFrames:0},{emergenceFrames:241},{emergenceFrames:1.5},{maxAlive:33},{vx:9},{vy:Infinity},{playerActivatedShell:true}]){const copy=structuredClone(d);Object.assign(copy.rooms[0].marioModules.enemySources[0],values);assert.throws(()=>validateMarioModulesRoom(copy.rooms[0]));}
 const copy=structuredClone(d);delete copy.rooms[0].marioModules.enemySources[0].emergenceFrames;assert.throws(()=>validateMarioModulesRoom(copy.rooms[0]),/explicit emergence/);
});

for(const direction of ['left','right','up','down'])test('genuine 16×16 empty Beetle shell emerges from the '+direction+' pipe mouth',()=>{
 const r=emptyShellProject({direction,vx:1.25,vy:-2}).rooms[0],m=createMarioModules(r),pipe=r.map.geometry[1],source=r.marioModules.enemySources[0];const [e]=m.spawnEnemies({player:{x:32},tick:1,geometry:r.map.geometry});
 assert.ok(e);assert.equal(e.type,'beetle');assert.equal(e.shell,true);assert.equal(e.emptyShell,true);assert.equal(e.w,16);assert.equal(e.h,16);assert.equal(e.smm2Helmet,undefined);assert.equal(e.moduleShoeTemplateId,undefined);
 const target={x:direction==='left'?pipe.x-16:direction==='right'?pipe.x+pipe.w:pipe.x+8,y:direction==='up'?pipe.y-16:direction==='down'?pipe.y+pipe.h:pipe.y+24};
 assert.equal(e.sourceClip.direction,direction);assert.equal(e.moduleEmergence.totalFrames,source.emergenceFrames);assert.equal(e.vx,0);assert.equal(e.vy,0);
 for(let tick=1;tick<=4;tick++){assert.equal(m.stepEnemy(e,{tick}),true);if(tick<4)assert.ok(e.moduleEmergence);}
 assert.deepEqual({x:e.x,y:e.y},target);assert.equal(e.moduleEmergence,undefined);assert.equal(e.sourceClip,undefined);assert.equal(e.vx,1.25);assert.equal(e.vy,-2);assert.equal(e.shell,true);
});

test('repeat supply counts live shells once across actor lists and resupplies only released capacity',()=>{
 const r=emptyShellProject({maxAlive:2,maxEmissions:null}).rooms[0],q=r.marioModules.enemySources[0];q.intervalFrames=1;const m=createMarioModules(r),spawn=(tick,enemies=[],actors=enemies)=>m.spawnEnemies({player:{x:32},tick,enemies,actors,geometry:r.map.geometry});
 const [a]=spawn(1);assert.deepEqual(spawn(1,[a]),[],'same frame cannot duplicate emission');assert.deepEqual(spawn(2,[a]),[],'occupied target mouth prevents an overlapping second shell');
 for(let tick=1;tick<=4;tick++)m.stepEnemy(a,{tick});a.x=200;const [b]=spawn(3,[a],[a]);assert.ok(b);for(let tick=3;tick<=6;tick++)m.stepEnemy(b,{tick});b.x=240;
 assert.deepEqual(spawn(4,[a,b],[a,b]),[],'both native empty shells count, with duplicate lists deduplicated');assert.equal(m.view().enemySources[0].emitted,2);
 a.vx=3.2;assert.deepEqual(spawn(5,[a,b]),[],'kicked shell still uses live capacity');a.dead=true;const [c]=spawn(6,[a,b]);assert.ok(c);assert.notEqual(c.id,a.id);assert.equal(m.view().enemySources[0].emitted,3);
 c.removed=true;assert.equal(spawn(7,[b,c]).length,1);m.reset();assert.equal(m.view().enemySources[0].emitted,0);assert.equal(spawn(1)[0].id,a.id);
});

test('source honors authored delay, activation, total count and a genuinely solid blocked mouth',()=>{
 const r=emptyShellProject().rooms[0],q=r.marioModules.enemySources[0];q.initialDelayFrames=2;q.activationDistance=20;const m=createMarioModules(r),spawn=(tick,x,geometry=r.map.geometry)=>m.spawnEnemies({player:{x},tick,geometry});
 for(let tick=1;tick<=20;tick++)assert.deepEqual(spawn(tick,32),[]);assert.equal(m.view().enemySources[0].active,false);
 assert.deepEqual(spawn(21,96),[]);assert.deepEqual(spawn(22,96),[]);const block={id:'mouth-block',x:104,y:176,w:16,h:16,collision:'solid'};assert.deepEqual(spawn(23,96,[...r.map.geometry,block]),[]);assert.equal(m.view().enemySources[0].emitted,0);
 const [e]=spawn(24,96);assert.ok(e);e.dead=true;for(let tick=25;tick<=35;tick++)assert.deepEqual(m.spawnEnemies({player:{x:96},tick,enemies:[e],geometry:r.map.geometry}),[]);assert.equal(m.view().enemySources[0].emitted,1);
});

test('stationary source falls onto native floor, stays inert through long idle, and never auto-equips',()=>{
 const d=emptyShellProject({coins:[104]}),s=nativeSession(d);settleEmptyShell(s);s.frames(1300);const e=s.view().enemies[0];assert.equal(e.type,'beetle');assert.equal(e.shell,true);assert.equal(e.emptyShell,true);assert.equal(e.h,16);assert.equal(e.y,208);assert.equal(e.vx,0);assert.equal(e.grounded,true);assert.equal(e.frame,'');assert.equal(e.shellAge,0);
 assert(overlaps(e,d.rooms[0].map.objects[1]));assert.equal(s.view().coins,0);assert.equal(s.view().smm2Mechanics.pinkCoins.taken,0);assert.equal(shellPickups(s).length,0);assert.equal(s.events.filter(e=>e.event==='player-kick').length,0);assert.equal(s.view().p.helmet,undefined);assert.equal(s.events.filter(e=>e.event==='helmet-worn').length,0);
});

test('authored moving empty shell crosses pink coins with no player activation',()=>{
 const d=emptyShellProject({vx:2}),s=nativeSession(d);s.frames(75);assert(s.trace.some(v=>v.enemies.some(e=>e.shell&&!e.moduleEmergence&&overlaps(e,d.rooms[0].map.objects[1]))));assert.equal(s.view().coins,0);assert.equal(shellPickups(s).length,0);assert.equal(s.events.filter(e=>e.event==='player-kick').length,0);
});

test('ordinary side kick activates the supplied Beetle shell and physically collects pink coins',()=>{
 const s=nativeSession(emptyShellProject());sideKickEmptyShell(s);const kick=s.events.find(e=>e.event==='player-kick');assert.equal(kick.source,'side-kick');assert.equal(s.events.filter(e=>e.type==='sound'&&e.event==='kick').length,1);assert.equal(s.view().enemies[0].type,'beetle');assert.equal(s.view().enemies[0].shell,true);assert.equal(s.view().p.helmet,undefined);
 s.until(v=>v.smm2Mechanics.pinkCoins.keyReleased);checkPhysicalPickups(s);assert.equal(s.view().coins,3);assert.equal(shellPickups(s).length,3);assert.equal(s.events.filter(e=>e.event==='pink-key-release').length,1);s.until(v=>v.contraptions.keys===1);
});

test('legacy collection flag keeps genuinely kicked source shells from collecting',()=>{
 const s=nativeSession(emptyShellProject({rule:false}));sideKickEmptyShell(s);s.frames(60,{x:-1});assert.equal(s.view().coins,0);assert.equal(shellPickups(s).length,0);assert.equal(s.view().objects.filter(o=>o.kind==='coin').length,3);
});

test('rolling empty shell really rebounds from solids, defeats a ground enemy, and keeps activation',()=>{
 const d=emptyShellProject({coins:[160],wall:true}),r=d.rooms[0];r.map.objects.push({id:'victim',kind:'walker',x:240,y:208,w:16,h:16});r.markers.push({id:'victim',kind:'enemy-goomba',x:240,y:208,source:{thing:'Goomba'}});const s=nativeSession(d);sideKickEmptyShell(s);
 s.until(v=>v.enemies.some(e=>e.type==='beetle'&&e.vx<0),{x:-1});assert.equal(s.view().enemies.filter(e=>e.id==='victim').length,0);assert.equal(s.view().enemies[0].shell,true);assert(s.view().enemies[0].x+16<=320);assert.equal(shellPickups(s).length,1);s.until(v=>v.enemies[0].x<152);assert.equal(shellPickups(s).length,1);assert.equal(s.view().coins,1);
});

test('upward launched empty shell collides with a solid ceiling and then lands under gravity',()=>{
 const d=emptyShellProject({direction:'right',coins:[],vy:-8}),r=d.rooms[0];r.map.geometry.push({id:'ceiling',x:128,y:64,w:64,h:16,collision:'solid',material:'stone'});const s=nativeSession(d);s.until(v=>v.enemies[0]&&!v.enemies[0].moduleEmergence);let ceilingHit=false;
 for(let n=0;n<100;n++){const e=s.step().enemies[0];assert(e.y>=80);if(e.y===80&&e.vy===0)ceilingHit=true;}
 assert(ceilingHit);assert.equal(s.view().enemies[0].y,208);assert.equal(s.view().enemies[0].grounded,true);
});

test('naturally kicked empty shell rolls down the real authored slope and lands on the lower floor',()=>{
 const d=emptyShellProject({coins:[]}),r=d.rooms[0];r.map.geometry=[{id:'upper',x:0,y:160,w:128,h:128,collision:'solid',material:'ground'},{id:'lower',x:256,y:224,w:384,h:64,collision:'solid',material:'ground'},{id:'supply-pipe',x:96,y:80,w:32,h:64,collision:'solid',material:'pipe'}];r.map.objects[0].y=146;r.smm2Mechanics.slopes=[{id:'incline',x:128,y:160,w:128,h:64,orientation:'rise-left',collision:'solid'}];const s=nativeSession(d);sideKickEmptyShell(s);s.until(v=>v.enemies[0].x>=260,{x:-1});
 const samples=s.trace.flatMap(v=>v.enemies.filter(e=>e.support==='incline'&&e.x<256)),shape=createSMM2Terrain(r).surfaces()[0];assert(samples.length>20);for(const e of samples){const surface=sampleSMM2Surface(shape,e.x,e.w);assert(Math.abs(e.y+e.h-surface.y)<1e-6);assert.equal(e.vx,3.2);assert.equal(e.shell,true);}
 assert.equal(s.view().enemies[0].y,208);assert.equal(s.view().enemies[0].grounded,true);assert.equal(s.view().enemies[0].emptyShell,true);assert.equal(s.view().enemies[0].support,'lower');
});

test('actual death restart replaces actors, resets source counters and removes prior kick ownership',()=>{
 const d=emptyShellProject({coins:[160]}),r=d.rooms[0];r.map.objects.push({id:'danger',kind:'hazard',x:360,y:208,w:16,h:16});const s=nativeSession(d,{Stage:options=>createPlatformStage({...options,manualDeath:false})});sideKickEmptyShell(s);s.until(v=>v.coins===1);s.until(v=>v.p.dying,{x:1,run:true},240);assert.equal(s.view().lives,2);s.until(v=>!v.p.dying,{},150);assert.equal(s.view().marioModules.enemySources[0].emitted,0);assert.equal(s.view().enemies.length,0);
 settleEmptyShell(s);const e=s.view().enemies[0];assert.equal(e.id,'module-enemy-empty-supply-0');assert.equal(e.vx,0);assert.equal(e.emptyShell,true);assert.equal(s.view().smm2Mechanics.pinkCoins.taken,0);s.frames(100);assert.equal(s.view().coins,1);assert.equal(shellPickups(s).length,1);assert.equal(s.events.filter(e=>e.event==='player-kick').length,1);
});
