import test from 'node:test';
import assert from 'node:assert/strict';
import {blank,parseProject} from '../atlas/editor-model.mjs';
import {createMarioModules,validateMarioModulesRoom} from '../atlas/editor-mario-modules.mjs';

const rule=(size='normal')=>({kind:'dry-bones',size,speed:.5,direction:-1,collapsedHeight:8,collapseFrames:3,recoverFrames:2,bounceSpeed:4,...(size==='giant'?{giantStompResponse:'bounce'}:{})});
function fixture(size='normal',shape={w:16,h:24}){
 const project=blank('Dry Bones authored lifecycle fixture',640,288),room=project.rooms[0];
 room.map.geometry=[{id:'floor',x:0,y:224,w:640,h:64,collision:'solid',material:'ground'}];
 room.map.objects=[{id:'start',kind:'spawn',x:24,y:210,w:10,h:14},{id:'bones',kind:'walker',x:160,y:224-shape.h,...shape},{id:'ordinary',kind:'walker',x:240,y:200,w:16,h:24}];
 room.marioModules={version:1,itemSources:[],noteBlocks:[],oneWayWalls:[],enemyVariants:{bones:rule(size)}};
 const events=[],modules=createMarioModules(room,{emit:(kind,data)=>events.push({kind,...data})}),actor={...room.map.objects[1],type:'walker',source:{smart:false},vx:-.7,vy:0,grounded:true,support:'floor',dead:false};
 modules.applyEnemyVariant(actor);return{project,room,modules,actor,events};
}
const freeze=x=>{if(x&&typeof x==='object'){Object.freeze(x);for(const y of Object.values(x))freeze(y);}return x;};
const overlap=(a,b)=>a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y;

test('typed variant round trips on real native bodies and giant behavior preserves source dimensions',()=>{
 for(const [size,shape]of [['normal',{w:16,h:24}],['giant',{w:32,h:48}],['giant',{w:18,h:26}]]){
  const {project,room,modules,actor}=fixture(size,shape),input=structuredClone(project);
  assert.deepEqual(parseProject(JSON.stringify(project)),project);assert.equal(modules.enemyVariant('bones').type,'dry-bones');
  assert.equal(actor.w,shape.w);assert.equal(actor.h,shape.h);assert.equal(actor.y+actor.h,224);assert.equal(actor.source.giant,size==='giant');
  assert.equal(actor.type,'dry-bones');assert.equal(actor.smm2EnemyKind,'dry-bones');assert.equal(actor.standable,false);
  const descriptor=modules.enemyVariant('bones');descriptor.size='oops';assert.equal(modules.enemyVariant('bones').size,size);
  assert.deepEqual(project,input);const frozen=createMarioModules(freeze(structuredClone(room)));assert.equal(frozen.enemyVariant('bones').w,shape.w);
 }
});

test('schema rejects invented bodies, magical size fields and incomplete or unbounded tuning',()=>{
 const {room}=fixture();for(const change of [r=>r.marioModules.enemyVariants.bones.type='dry-bones',r=>r.marioModules.enemyVariants.missing=rule(),r=>r.marioModules.enemyVariants.start=rule(),r=>r.marioModules.enemyVariants.bones.size='big',r=>r.marioModules.enemyVariants.bones.scale=2,r=>delete r.marioModules.enemyVariants.bones.collapseFrames,r=>r.marioModules.enemyVariants.bones.recoverFrames=0,r=>r.marioModules.enemyVariants.bones.collapsedHeight=24,r=>r.marioModules.enemyVariants.bones.bounceSpeed=Infinity,r=>r.marioModules.enemyVariants.bones.direction=0,r=>r.marioModules.enemyVariants.bones.giantStompResponse='bounce']){
  const bad=structuredClone(room);change(bad);assert.throws(()=>validateMarioModulesRoom(bad));
 }
 const badBody=fixture().room;badBody.map.objects[1].w=0;assert.throws(()=>validateMarioModulesRoom(badBody));
});

test('normal stomp returns collapse and bounce without kill, shell conversion or points',()=>{
 const {modules:m,actor:a,events}=fixture(),identity=a;
 assert.equal(m.enemyContact(a).fireImmune,true);assert.equal(m.stackSupportEligible(a),true);
 const result=m.stompEnemy(a,{tick:10});assert.equal(result.handled,true);assert.equal(result.action,'collapse');assert.equal(result.bounceSpeed,4);assert.equal(result.points,null);
 assert.equal(a,identity);assert.equal(a.dead,false);assert.equal(a.shell,undefined);assert.equal(a.h,8);assert.equal(a.w,16);assert.equal(a.y+a.h,224);assert.equal(a.vx,0);
 assert.equal(a.smm2DryBones.phase,'collapsed');assert.equal(m.stackSupportEligible(a),false);assert.equal(m.enemyContact(a).handled,true);assert.equal(m.enemyContact(a).harmless,true);assert.equal(m.enemyContact(a).fireImmune,true);
 for(const attack of ['body','stomp','bone-shell-stomp','ground-pound']){const neutral=m.dryBonesContact(a,{tick:11,attack});assert.equal(neutral.handled,true);assert.equal(neutral.harmful,false);assert.equal(neutral.bounce,false);}
 assert.equal(events.filter(e=>e.event==='dry-bones-collapse').length,1);assert.equal(a.smm2DryBones.remainingFrames,3);
});

test('collapse and phase clocks are idempotent with exact authored tick durations',()=>{
 const {modules:m,actor:a,events}=fixture();m.dryBonesContact(a,{tick:100,attack:'stomp'});
 const repeated=m.dryBonesContact(a,{tick:100,attack:'stomp'});assert.equal(repeated.repeated,true);assert.equal(repeated.changed,false);assert.equal(repeated.bounce,false);
 let calls=0;const step=tick=>m.stepEnemy(a,{tick,canStand:()=>{calls++;return true;}});
 assert.equal(step(100),false);assert.equal(a.smm2DryBones.remainingFrames,3);
 step(101);step(101);assert.equal(a.smm2DryBones.remainingFrames,2);step(102);assert.equal(a.smm2DryBones.remainingFrames,1);
 step(103);assert.equal(a.smm2DryBones.phase,'recovering');assert.equal(a.smm2DryBones.remainingFrames,2);assert.equal(m.stackSupportEligible(a),false);
 step(104);assert.equal(a.smm2DryBones.remainingFrames,1);assert.equal(calls,0);
 step(105);step(105);assert.equal(a.smm2DryBones.phase,'walking');assert.equal(a.h,24);assert.equal(a.y+a.h,224);assert.equal(a.vx,-.5);assert.equal(calls,1);assert.equal(m.stackSupportEligible(a),true);
 assert.equal(events.filter(e=>e.event==='dry-bones-collapse').length,1);assert.equal(events.filter(e=>e.event==='dry-bones-recovering').length,1);assert.equal(events.filter(e=>e.event==='dry-bones-recovered').length,1);
});

test('recovery waits for actual full-body headroom and invokes a bounded immutable candidate callback',()=>{
 const {modules:m,actor:a,room}=fixture();m.dryBonesContact(a,{tick:10,attack:'stomp'});
 const ceiling={id:'ceiling',x:144,y:196,w:48,h:12,collision:'solid'},solids=[...room.map.geometry,ceiling];let calls=0;
 const canStand=body=>{calls++;assert(Object.isFrozen(body));assert.equal(body.h,24);assert.equal(body.y+body.h,224);return !solids.some(q=>q.collision==='solid'&&overlap(body,q));};
 for(let tick=11;tick<=30;tick++){m.stepEnemy(a,{tick,canStand});m.stepEnemy(a,{tick,canStand});assert.equal(a.h,8);assert.equal(a.dead,false);assert.equal(a.shell,undefined);}
 assert.equal(a.smm2DryBones.phase,'recovering');assert.equal(a.smm2DryBones.remainingFrames,0);assert.equal(calls,16);
 solids.pop();m.stepEnemy(a,{tick:31,canStand});assert.equal(a.smm2DryBones.phase,'walking');assert.equal(a.y,200);assert.equal(calls,17);
 const second=fixture();second.modules.dryBonesContact(second.actor,{tick:0,attack:'stomp'});for(let tick=1;tick<=12;tick++)second.modules.stepEnemy(second.actor,{tick});assert.equal(second.actor.h,8,'no supplied headroom proof cannot expand the body');
});

test('giant bare stomp remains alive and uncollapsed with required authored response and uncertainty explicit',()=>{
 const {modules:m,actor:a}=fixture('giant',{w:32,h:48}),before={x:a.x,y:a.y,w:a.w,h:a.h};
 const result=m.dryBonesContact(a,{tick:1,attack:'stomp'});assert.equal(result.action,'resisted-stomp');assert.equal(result.collapse,false);assert.equal(result.requiresHostResponse,false);assert.equal(result.harmful,false);assert.equal(result.bounce,true);assert.equal(result.unverified,'giant-ordinary-stomp-player-response');
 assert.deepEqual({x:a.x,y:a.y,w:a.w,h:a.h},before);assert.equal(a.dead,false);assert.equal(a.shell,undefined);assert.equal(a.smm2DryBones.phase,'walking');
 for(const response of ['bounce','hurt','harmless']){const f=fixture('giant');f.room.marioModules.enemyVariants.bones.giantStompResponse=response;const modules=createMarioModules(f.room),actor={...f.room.map.objects[1],vx:0,vy:0};modules.applyEnemyVariant(actor);const r=modules.stompEnemy(actor,{tick:3});assert.equal(r.authoredResponse,response);assert.equal(r.unverified,'giant-ordinary-stomp-player-response');assert.equal(r.requiresHostResponse,false);assert.equal(r.bounce,response==='bounce');assert.equal(r.harmful,response==='hurt');assert.equal(actor.smm2DryBones.phase,'walking');}
 for(const response of [undefined,'unresolved','unknown']){const bad=structuredClone(fixture('giant').room);if(response===undefined)delete bad.marioModules.enemyVariants.bones.giantStompResponse;else bad.marioModules.enemyVariants.bones.giantStompResponse=response;assert.throws(()=>validateMarioModulesRoom(bad));}
});

test('shell-rider stomp and ground-pound collapse either typed size with unchanged identity',()=>{
 for(const size of ['normal','giant'])for(const attack of ['bone-shell-stomp','ground-pound']){const {modules:m,actor:a}=fixture(size,size==='giant'?{w:32,h:48}:{w:16,h:24}),body=a;const result=m.dryBonesContact(a,{tick:1,attack});assert.equal(result.action,'collapse');assert.equal(result.bounce,true);assert.equal(result.points,null);assert.equal(a,body);assert.equal(a.dead,false);assert.equal(a.shell,undefined);assert.equal(a.smm2DryBones.phase,'collapsed');assert.equal(a.w,size==='giant'?32:16);assert.equal(a.y+a.h,224);}
});

test('reset restores the authored actor pose and fresh clocks; views cannot mutate lifecycle state',()=>{
 const {modules:m,actor:a}=fixture(),initial={x:a.x,y:a.y,w:a.w,h:a.h,vx:a.vx,vy:a.vy};m.stompEnemy(a,{tick:4});a.x+=12;a.y+=8;m.stepEnemy(a,{tick:5});
 const view=m.view();view.dryBones[0].phase='walking';view.dryBones[0].remainingFrames=999;view.enemyVariants.bones.collapseFrames=999;assert.equal(a.smm2DryBones.phase,'collapsed');assert.equal(m.view().dryBones[0].remainingFrames,2);
 m.reset();assert.deepEqual({x:a.x,y:a.y,w:a.w,h:a.h,vx:a.vx,vy:a.vy},initial);assert.equal(a.smm2DryBones.phase,'walking');assert.equal(a.smm2DryBones.remainingFrames,0);assert.equal(a.dead,false);assert.equal(a.shell,undefined);
 m.stompEnemy(a,{tick:4});assert.equal(a.smm2DryBones.phase,'collapsed');assert.equal(a.smm2DryBones.remainingFrames,3);
});

test('legacy enemies and authored stack mappings keep their original descriptors and contact behavior',()=>{
 const {room}=fixture();delete room.marioModules.enemyVariants.bones;room.marioModules.enemyStacks={ordinary:'bones'};const m=createMarioModules(room),enemy={id:'ordinary',type:'koopa',x:240,y:200,w:16,h:24,vx:-.5,vy:0,dead:false},before=structuredClone(enemy);
 assert.equal(m.enemyVariant('ordinary'),null);assert.equal(m.enemyContact(enemy),null);assert.equal(m.stompEnemy(enemy),false);assert.equal(m.stepEnemy(enemy,{tick:1}),false);assert.equal(m.stackSupport('ordinary'),'bones');assert.equal(m.stackSupportEligible(enemy),true);assert.equal(m.dryBonesContact(enemy,{tick:1,attack:'stomp'}),null);assert.deepEqual(enemy,before);assert.equal(Object.hasOwn(m.view(),'dryBones'),false);
});
