import {assertNativeMotorCompatibility} from './fixtures/native-motor-compatibility.mjs';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {test} from 'node:test';
import {createRequire} from 'node:module';
import {createCastleController,validateCastleRoom} from '../atlas/editor-castle.mjs';
import {createCastleController as legacyCastle} from './fixtures/castle-ending/legacy-editor-castle.mjs';
import {createPlatformStage} from '../atlas/editor-mario-stage.mjs';
import {createPlatformStage as legacyStage} from './native-baseline/editor-mario-stage.mjs';
import {createPlatformMotor} from '../atlas/editor-mario-motor.mjs';
import {blank,parseProject,runtimeMap,validate} from '../atlas/editor-model.mjs';
import {drawReference,drawSmm2CastleDoor} from '../atlas/editor-art.mjs';
const copy=x=>structuredClone(x);
const character={capabilities:['jump'],motion:{width:10,height:14,maxHealth:1}};
function fixture(){
 const d=blank('SMM2 castle door ending',512,240),r=d.rooms[0];r.setting='Castle';
 r.map.objects=[{id:'start',kind:'spawn',x:300,y:210,w:10,h:14},{id:'boss',kind:'walker',x:224,y:192,w:32,h:32}];
 r.map.geometry=[{id:'left',x:0,y:224,w:192,h:16,material:'stone',collision:'solid'},{id:'bridge',x:192,y:224,w:128,h:16,material:'bridge',collision:'solid'},{id:'right',x:320,y:224,w:192,h:16,material:'stone',collision:'solid'}];
 r.markers=[{id:'axe',kind:'bridge-axe-finish',x:320,y:208},{id:'chain',kind:'marker-CastleChain',x:304,y:208},{id:'last-door',kind:'smm2-castle-door',x:464,y:176}];
 r.enemySkins={boss:'bowser'};r.smm2Mechanics={version:1,art:{palette:'smb1-castle-stone'},startingLives:3};
 r.castle={version:1,lavaMode:'pit',boss:{actorId:'boss',jump:{intervalFrames:600,jitterFrames:0},fire:{initialDelayFrames:600}},finish:{variant:'smm2-door',axeId:'axe',bridgeId:'bridge',chainIds:['chain'],doorId:'last-door',bridgeStepFrames:2,bossFallFrames:12,endingPauseFrames:10}};
 r.playRules={version:1,timeLimit:275,timerFrames:120,viewportWidth:256,viewportHeight:240,cameraAnchor:100};return d;
}
function session(r,extra={},driver=createPlatformStage){const events=[],s=driver({plan:{stage:{entryRoom:'main',entrySpawn:'start',title:'Castle ending'},character,rooms:{main:r.map}},motor:createPlatformMotor(),visualRooms:[r],initialState:{lives:3,power:1,score:3500,coins:19},emit:(type,data)=>events.push({type,...data}),...extra});return {s,events};}
const frames=(s,n,input={})=>{for(let i=0;i<n;i++)s.step(input);return s.view();};

test('explicit door variant roundtrips with a real marker and no derived NPC/flag exit',()=>{
 const d=fixture();assert.doesNotThrow(()=>validate(d));assert.deepEqual(parseProject(JSON.stringify(d)),d);
 assert.equal(runtimeMap(d.rooms[0]).objects.some(q=>q.kind==='exit'),false);
 for(const mutate of [r=>delete r.castle.finish.endingPauseFrames,r=>r.castle.finish.endingPauseFrames=0,r=>r.castle.finish.endingPauseFrames=Infinity,r=>r.castle.finish.doorId='axe',r=>r.markers[2].kind='castle-finish',r=>r.markers[2].y=193,r=>r.castle.finish.messages=['THANK YOU MARIO!'],r=>r.castle.finish.npcId='last-door',r=>r.castle.finish.variant='other',r=>r.markers.push(copy(r.markers[2])),r=>r.smm2Mechanics.shoes=[],r=>r.smm2Mechanics.powBlocks=[],r=>r.smm2Mechanics.goalTopLife=true,r=>r.smm2Mechanics.flagScore=true,r=>r.contraptions={version:1},r=>r.aquatic={version:1},r=>r.playHero='bill']){
  const bad=copy(d);mutate(bad.rooms[0]);assert.throws(()=>validate(bad));
 }
 const ordinary=copy(d);delete ordinary.rooms[0].castle.finish.variant;assert.throws(()=>validate(ordinary),/SMM2|castle-ending/);
});

test('native directional input contacts axe, removes real bridge, falls real Bowser, opens door and completes after authored pause',()=>{
 const r=fixture().rooms[0],{s,events}=session(r);let v=s.view();assert.equal(v.finish,null);
 for(let i=0;i<60&&!v.finish;i++){s.step({x:1});v=s.view();}
 assert(v.finish,'real motor foot reaches axe');assert.equal(v.finish.phase,'bridge');assert.equal(v.finish.variant,'smm2-door');assert.equal(v.finish.doorOpen,false);
 assert(v.p.x+v.p.w/2>=320&&v.p.x+v.p.w/2<336);assert.equal(events.filter(q=>q.event==='axe-trigger').length,1);
 assert.deepEqual(v.hiddenMarkers,['axe','chain']);const heldPose={x:v.p.x,y:v.p.y},bossStart=v.enemies.find(q=>q.id==='boss').y;
 let widths=[];for(let i=0;i<16;i++){s.step({x:1,jump:true,run:true,attack:true});v=s.view();widths.push(v.geometry.find(q=>q.id==='bridge')?.w??0);assert.equal(v.score,3500);assert.equal(v.timeLeft,275);assert.equal(v.finish.messages,undefined);assert.deepEqual({x:v.p.x,y:v.p.y},heldPose);}
 assert.deepEqual(widths,[128,112,112,96,96,80,80,64,64,48,48,32,32,16,16,0]);assert.equal(v.finish.phase,'boss-fall');assert.equal(v.geometry.some(q=>q.id==='bridge'),false);
 v=frames(s,5,{x:1});assert(v.enemies.find(q=>q.id==='boss').y>bossStart);v=frames(s,7);assert.equal(v.enemies.some(q=>q.id==='boss'),false);assert.equal(v.finish.phase,'door-open');assert.equal(v.finish.doorOpen,true);assert.equal(v.castle.finish.doorOpen,true);assert.equal(v.completed,false);
 v=frames(s,9,{x:1,jump:true});assert.equal(v.completed,false);assert.deepEqual({x:v.p.x,y:v.p.y},heldPose);v=frames(s,1);assert.equal(v.completed,true);assert.equal(v.finish.phase,'complete');assert.equal(v.score,3500);assert.equal(v.timeLeft,275);assert.equal(v.coins,19);assert.equal(v.lives,3);
 assert.equal(events.filter(q=>q.type==='complete').length,1);assert.equal(events.filter(q=>q.event==='door-open').length,1);assert(!JSON.stringify({events,finish:v.finish}).match(/THANK YOU|PRINCESS|Toad|message|timer-conversion/));
 const done=JSON.stringify(v);frames(s,100,{x:1,jump:true});assert.equal(JSON.stringify(s.view()),done,'completion emits once and preserves final time/score');
 const fresh=session(r).s;assert.equal(fresh.view().finish,null);assert.equal(fresh.view().geometry.find(q=>q.id==='bridge').w,128);assert.equal(fresh.view().enemies.some(q=>q.id==='boss'),true);
});

test('real native powered head-only overlap and upward axe crossing cannot finish',()=>{
 const r=fixture().rooms[0];r.map.objects[0].x=320;r.markers[0].y=192;const {s}=session(r);
 let v=frames(s,8);assert.equal(v.finish,null);assert(v.p.y<208&&v.p.y+v.p.h>208,'powered head/body overlaps while foot is below axe');
 let crossed=0;for(let i=0;i<8;i++){s.step({jump:true});v=s.view();if(v.p.y+v.p.h>=192&&v.p.y+v.p.h<=208&&v.p.vy<0)crossed++;assert.equal(v.finish,null);}
 assert(crossed>0,'true native upward foot crossing was exercised');
});

test('door controller reset re-closes the door, and dead-Bowser branch needs the same real foot trigger',()=>{
 const r=fixture().rooms[0],c=createCastleController(r),p={x:320,y:210,w:10,h:14,vy:0},e={...r.map.objects[1],dead:true};
 assert.equal(c.triggerFinish({player:{...p,vy:-1},enemies:[e]}),null);const q=c.triggerFinish({player:p,enemies:[e]});assert.equal(q.finish.branch,'dead');assert.equal(q.finish.phase,'door-open');assert(q.commands.some(q=>q.type==='open-castle-door'&&q.id==='last-door'));assert.deepEqual(q.commands.find(q=>q.type==='hide-markers').ids,['axe']);
 c.stepFinish({tick:1,player:p,paused:true});assert.equal(c.finishView().age,0);for(let tick=1;tick<=10;tick++)c.stepFinish({tick,player:p});assert.equal(c.finishView().phase,'complete');c.reset();assert.equal(c.finishView(),null);assert.equal(c.combatEnabled(),true);assert.equal(c.triggerFinish({player:p,enemies:[e]}).finish.age,0);
});

test('legacy castle component yields byte-identical commands, state, events and default NPC messages',()=>{
 for(const live of [true,false]){
  const r=fixture().rooms[0];delete r.smm2Mechanics;r.markers[2]={id:'npc',kind:'castle-finish',x:480,y:184};r.castle.finish={axeId:'axe',bridgeId:'bridge',chainIds:['chain'],npcId:'npc',targetX:480,lockCameraX:0,finalCameraX:256,bridgeStepFrames:2,bossFallFrames:12,messageFrames:4};
  const ae=[],be=[],a=createCastleController(r,{emit:(...q)=>ae.push(q)}),b=legacyCastle(r,{emit:(...q)=>be.push(q)}),p={x:320,y:210,w:10,h:14,vy:0},enemies=[{...r.map.objects[1],hp:5,dead:!live}];
  assert.equal(JSON.stringify(a.triggerFinish({player:p,enemies})),JSON.stringify(b.triggerFinish({player:p,enemies})));
  for(let tick=1;tick<100;tick++){if(tick===35)p.x=480;assert.equal(JSON.stringify(a.stepFinish({tick,player:p})),JSON.stringify(b.stepFinish({tick,player:p})));assert.equal(JSON.stringify(a.view()),JSON.stringify(b.view()));assert.equal(JSON.stringify(ae),JSON.stringify(be));}
 }
});

test('opt-out native stage snapshots stay byte-identical and legacy motor behavior remains unchanged',async()=>{
 const r=fixture().rooms[0];delete r.castle;delete r.smm2Mechanics;delete r.playRules;r.markers=[];r.map.objects=r.map.objects.slice(0,1);const a=session(r,{},createPlatformStage).s,b=session(r,{},legacyStage).s;
 for(let i=0;i<360;i++){const input={x:i<120?1:i<240?-1:0,run:true,jump:i>=35&&i<65};a.step(input);b.step(input);assert.equal(JSON.stringify(a.view()),JSON.stringify(b.view()));}
 await assertNativeMotorCompatibility();
});

const require=createRequire(import.meta.url);let createCanvas;try{({createCanvas}=require('@napi-rs/canvas'));}catch{}
test('actual marker renderer draws red closed door, white open door and never an NPC',{skip:!createCanvas},()=>{
 const r=fixture().rooms[0],door=r.markers[2],canvas=createCanvas(512,240),c=canvas.getContext('2d'),pixel=(x,y)=>[...c.getImageData(x,y,1,1).data];
 assert.equal(drawReference(c,door,r),true);assert.deepEqual(pixel(462,185),[247,57,16,255]);assert.deepEqual(pixel(472,191),[198,42,8,255]);
 const closed=c.getImageData(460,184,24,40).data;r.castleView={finish:{variant:'smm2-door',doorId:'last-door',doorOpen:true}};c.clearRect(0,0,512,240);assert.equal(drawReference(c,door,r),true);assert.deepEqual(pixel(472,191),[255,255,255,255]);assert.notDeepEqual(c.getImageData(460,184,24,40).data,closed);
 assert.deepEqual(pixel(459,184),[0,0,0,0]);assert.equal(drawSmm2CastleDoor(c,door,{...r,castle:undefined}),false);assert.equal(drawSmm2CastleDoor(c,{...door,id:'unrelated'},r),false);
});
