import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createLakituClouds,validateLakituClouds} from '../atlas/editor-lakitu-clouds.mjs';

// All tuning below belongs to these neutral fixtures, not measured Nintendo data.
const spec=overrides=>({id:'cloud',x:96,y:80,w:20,h:16,acceleration:.25,maxSpeed:2,drag:.125,seatOffsetY:-8,boardTolerance:2,hoverAmplitude:0,hoverPeriodFrames:120,...overrides});
const room=(clouds=[spec()])=>({roomId:'fixture',map:{width:400,height:240,geometry:[],objects:[]},smm2Mechanics:{version:1,lakituClouds:{version:1,clouds}}});
const player=overrides=>({x:101,y:54,w:10,h:14,vx:0,vy:0,grounded:false,power:0,facing:1,...overrides});
const fixture=(overrides={})=>{const events=[],r=room([spec(overrides)]),m=createLakituClouds(r,{emit:(type,data)=>events.push({type,...data})});return {m,r,events};};
const cloud=m=>m.view().clouds[0];
function board(m,p=player(),geometry=[]){
 m.sync({tick:0,player:p,geometry});assert.equal(m.ownsPlayer(p),false);
 p.y=68;p.vy=14;m.sync({tick:1,player:p,geometry});assert(m.ownsPlayer(p));return p;
}
const physical=p=>({x:p.x,y:p.y,w:p.w,h:p.h,vx:p.vx,vy:p.vy,grounded:p.grounded,support:p.support});

test('absent and empty leaves preserve native opt-out; the full motion contract is explicit',()=>{
 assert.equal(createLakituClouds({map:{width:400,height:240}}),null);assert.equal(createLakituClouds(room([])),null);
 const r=room(),before=structuredClone(r);validateLakituClouds(r);createLakituClouds(r);assert.deepEqual(r,before);
 for(const key of Object.keys(spec())){const r=room();delete r.smm2Mechanics.lakituClouds.clouds[0][key];assert.throws(()=>validateLakituClouds(r),/Missing/);}
 for(const leaf of [null,[],true,{version:2,clouds:[]},{version:1},{version:1,clouds:[],expiry:600}]){const r=room();r.smm2Mechanics.lakituClouds=leaf;assert.throws(()=>validateLakituClouds(r));}
});

test('unknown fields, unsafe aliases, duplicate identities and unsafe tuning reject',()=>{
 for(const override of [{id:'bad id'},{id:'constructor'},{id:'prototype'},{id:'__proto__'},{x:-1},{x:381},{y:225},{w:32},{h:20},{acceleration:0},{acceleration:Infinity},{maxSpeed:0},{maxSpeed:257},{drag:-1},{seatOffsetY:65},{boardTolerance:9},{hoverAmplitude:9},{hoverPeriodFrames:0},{hoverPeriodFrames:16.5},{npcCapture:true},{lifetime:600},{jumpSpeed:4}])assert.throws(()=>validateLakituClouds(room([spec(override)])));
 const unsafe=room();unsafe.smm2Mechanics.lakituClouds.clouds[0]=JSON.parse(JSON.stringify(spec()).replace('"id":"cloud"','"id":"cloud","__proto__":{}'));assert.throws(()=>validateLakituClouds(unsafe),/Unknown/);
 const aliased=room();aliased.smm2Mechanics.lakituClouds.clouds[0]=Object.assign(Object.create({acceleration:1}),spec());assert.throws(()=>validateLakituClouds(aliased),/Invalid/);
 assert.throws(()=>validateLakituClouds(room([spec(),spec()])));
 for(const add of [r=>r.map.objects.push({id:'cloud'}),r=>r.map.geometry.push({id:'cloud'}),r=>r.markers=[{id:'cloud'}],r=>r.contraptions={tracks:[{id:'cloud'}]},r=>r.smm2Mechanics.donuts=[{id:'cloud'}]]){const r=room();add(r);assert.throws(()=>validateLakituClouds(r),/Duplicate/);}
 const hover=room([spec({y:2,hoverAmplitude:3})]);assert.throws(()=>validateLakituClouds(hover),/hover range/);
 const symbol=room();symbol.smm2Mechanics.lakituClouds.clouds[0][Symbol('alias')]=1;assert.throws(()=>validateLakituClouds(symbol),/Unknown/);
});

test('boarding requires a real recorded descent and keeps the same native player identity',()=>{
 const {m,events}=fixture(),p=player({y:68,vy:14,coins:7,lives:3,score:200});m.sync({tick:0,player:p});assert.equal(m.ownsPlayer(p),false,'velocity does not fabricate a prior pose');
 p.y=54;p.vy=-14;m.sync({tick:1,player:p});assert.equal(m.ownsPlayer(p),false);
 p.y=68;p.vy=14;m.sync({tick:2,player:p});assert(m.ownsPlayer(p));assert.equal(p.lakituCloudId,'cloud');assert.equal(p.vehicleId,'cloud');assert.equal(p.x,101);assert.equal(p.y,72);
 assert.equal(m.ownsPlayer({...p}),false,'a cloned player is never the occupant');assert.equal(m.contactBody({...p}),null);
 m.step({tick:3,player:p,input:{x:1,up:true}});assert(p.x>101);assert(p.y<72);assert.equal(p.coins,7);assert.equal(p.lives,3);assert.equal(p.score,200);
 assert.equal(events.filter(q=>q.event==='board').length,1);assert.equal(events[0].actorId,'player');
});

test('side crossing, upward crossing, below proximity, held actors and a replaced actor never board',()=>{
 const cases=[
  [player({x:70,y:72}),p=>{p.x=101;p.y=73;}],
  [player({y:96}),p=>{p.y=68;p.vy=-28;}],
  [player({y:96}),p=>{p.y=98;p.vy=2;}],
  [player({clawHeldBy:'claw'}),p=>{p.y=68;p.vy=14;}],
  [player({vehicleId:'other'}),p=>{p.y=68;p.vy=14;}]
 ];
 for(const [p,change]of cases){const {m}=fixture();m.sync({tick:0,player:p});change(p);m.sync({tick:1,player:p});assert.equal(m.ownsPlayer(p),false);}
 const {m}=fixture(),p=player();m.sync({tick:0,player:p});const replacement=player({y:68,vy:14});m.sync({tick:1,player:replacement});assert.equal(m.ownsPlayer(replacement),false);
});

test('swept boarding rejects intervening floors, side walls, embedded starts and blocked seats',()=>{
 for(const geometry of [
  [{id:'floor',x:90,y:72,w:40,h:2,collision:'solid'}],
  [{id:'oneway',x:90,y:72,w:40,h:2,collision:'oneway'}],
  [{id:'seat-solid',x:100,y:82,w:20,h:4,collision:'solid'}],
  [{id:'embedded-start',x:100,y:55,w:12,h:4,collision:'solid'}]
 ]){const {m}=fixture(),p=player();m.sync({tick:0,player:p,geometry});p.y=68;p.vy=14;m.sync({tick:1,player:p,geometry});assert.equal(m.ownsPlayer(p),false);assert.equal(p.y,68);}
 const {m}=fixture(),p=player({x:70,y:40}),geometry=[{id:'thin-wall',x:90,y:0,w:1,h:240,collision:'solid'}];
 m.sync({tick:0,player:p,geometry});p.x=101;p.y=68;p.vy=28;m.sync({tick:1,player:p,geometry});assert.equal(m.ownsPlayer(p),false,'diagonal descent cannot teleport through a wall');
 const snap=fixture().m,q=player({x:88}),wall=[{id:'centering-wall',x:99,y:72,w:1,h:14,collision:'solid'}];snap.sync({tick:0,player:q,geometry:wall});q.y=68;q.vy=14;snap.sync({tick:1,player:q,geometry:wall});assert.equal(snap.ownsPlayer(q),false,'centering the rider cannot cross a wall');
});

test('a fast descent boards the earliest crossed cloud without treating a later floor as a barrier',()=>{
 const r=room([spec({id:'first',y:80}),spec({id:'second',y:120})]),m=createLakituClouds(r),p=player({y:10}),geometry=[{id:'later-floor',x:90,y:150,w:40,h:8,collision:'solid'}];
 m.sync({tick:0,player:p,geometry});p.y=140;p.vy=130;m.sync({tick:1,player:p,geometry});assert(m.ownsPlayer(p));assert.equal(p.lakituCloudId,'first');assert.equal(p.y,72);assert.equal(m.view().clouds[1].occupancy,'empty');
});

test('four directions, explicit y and release drag move once per active tick; jump never ejects',()=>{
 const {m}=fixture(),p=board(m);for(let tick=2;tick<=9;tick++)m.step({tick,player:p,input:{x:1,up:true}});
 const a=cloud(m);assert.equal(a.vx,2);assert.equal(a.vy,-2);assert(a.x>96&&a.y<80);
 m.step({tick:10,player:p,input:{x:-1,y:1,up:true}});assert.equal(cloud(m).vx,1.75);assert.equal(cloud(m).vy,-1.75,'explicit y overrides up/down');
 for(let tick=11;tick<=25;tick++)m.step({tick,player:p,input:{x:-1,down:true}});const b=cloud(m);assert.equal(b.vx,-2);assert.equal(b.vy,2);
 m.step({tick:26,player:p,input:{jumpPressed:true}});assert.equal(cloud(m).vx,-1.875);assert.equal(cloud(m).vy,1.875);assert(m.ownsPlayer(p));assert.equal(p.y,cloud(m).y-8);
 for(let tick=27;tick<=41;tick++)m.step({tick,player:p,input:{}});assert.equal(cloud(m).vx,0);assert.equal(cloud(m).vy,0);
});

test('high speed native passenger sweeps stop on thin solids, ceiling and floor',()=>{
 const {m}=fixture({acceleration:64,maxSpeed:64}),p=board(m),geometry=[{id:'wall',x:144,y:0,w:1,h:240,collision:'solid'},{id:'ceiling',x:0,y:32,w:400,h:1,collision:'solid'},{id:'floor',x:0,y:144,w:400,h:1,collision:'solid'}];
 m.step({tick:2,player:p,geometry,input:{x:1,up:true}});assert.equal(p.x+p.w,144);assert.equal(p.y,33);assert.equal(cloud(m).vx,0);assert.equal(cloud(m).vy,0);
 assert.equal(cloud(m).x+cloud(m).w,149,'sprite overhang is not an invented solid cloud face');
 m.step({tick:3,player:p,geometry,input:{down:true}});m.step({tick:4,player:p,geometry,input:{down:true}});assert.equal(p.y+p.h,144);assert.equal(cloud(m).vy,0);
 assert.deepEqual(m.contactBody(p),{x:p.x,y:p.y,w:10,h:14});assert.equal(m.contactBody(p).h,p.h,'no cloud armor is added to host damage');
});

test('native one-way platforms stop downward flight and permit rising and horizontal passage',()=>{
 const {m}=fixture({acceleration:8,maxSpeed:8}),p=board(m),geometry=[{id:'platform',x:80,y:110,w:80,h:4,collision:'oneway'}];
 for(let tick=2;tick<=10;tick++)m.step({tick,player:p,geometry,input:{down:true}});assert.equal(p.y+p.h,110);assert.equal(cloud(m).vy,0);
 for(let tick=11;tick<=17;tick++)m.step({tick,player:p,geometry,input:{up:true}});assert(p.y<72,'one-way underside does not become a ceiling');
 const pass=fixture({acceleration:8,maxSpeed:8}).m,q=board(pass);for(let tick=2;tick<=15;tick++)pass.step({tick,player:q,geometry:[{id:'side-oneway',x:120,y:72,w:8,h:30,collision:'oneway'}],input:{x:1}});assert(q.x>128);
});

test('room boundaries contain the native passenger and the visual cloud without tunneling',()=>{
 const {m}=fixture({acceleration:64,maxSpeed:256}),p=board(m);m.step({tick:2,player:p,input:{x:-1,up:true}});m.step({tick:3,player:p,input:{x:-1,up:true}});assert.equal(cloud(m).x,0);assert.equal(p.y,0);
 for(let tick=4;tick<=10;tick++)m.step({tick,player:p,input:{x:1,down:true}});assert.equal(cloud(m).x+20,400);assert.equal(cloud(m).y+16,240);assert(p.x>=0&&p.x+p.w<=400&&p.y+p.h<=240);
});

test('step and sync deduplicate ticks; frozen views and contact bodies never advance or alias state',()=>{
 const {m,r,events}=fixture({hoverAmplitude:2}),p=player(),source=structuredClone(r);m.step({tick:1,player:p});const first=m.view(),count=events.length;
 for(let i=0;i<10;i++){assert.deepEqual(m.view(),first);assert.equal(m.contactBody(p),null);}
 assert(Object.isFrozen(first)&&Object.isFrozen(first.clouds)&&Object.isFrozen(first.clouds[0]));assert.throws(()=>{first.clouds[0].x=999;});
 m.step({tick:1,player:p,input:{x:1}});m.step({tick:0,player:p});assert.deepEqual(m.view(),first);assert.equal(events.length,count);assert.deepEqual(r,source);
 m.sync({tick:1,player:p});p.y=68;p.vy=14;m.sync({tick:1,player:p});assert.equal(m.ownsPlayer(p),false,'a duplicate sync cannot consume another actor change');
 m.sync({tick:2,player:p});assert(m.ownsPlayer(p));const mounted=m.view(),physicalBefore=physical(p),frozenBody=m.contactBody(p);assert(Object.isFrozen(frozenBody));assert.throws(()=>{frozenBody.y=999;});assert.deepEqual(m.view(),mounted);assert.deepEqual(physical(p),physicalBefore);
 m.sync({tick:2,player:p});assert.deepEqual(m.view(),mounted);
});

test('normal step-before-motor/sync-after-motor boarding works within the same tick',()=>{
 const {m}=fixture(),p=player();m.step({tick:1,player:p,input:{}});assert.equal(m.ownsPlayer(p),false);p.y=68;p.vy=14;m.sync({tick:1,player:p});assert(m.ownsPlayer(p));
 const afterBoard=cloud(m);m.step({tick:1,player:p,input:{x:1}});assert.deepEqual(cloud(m),afterBoard);m.step({tick:2,player:p,input:{x:1}});assert(cloud(m).x>afterBoard.x);
});

test('releases preserve native poses/impulses; goal hides the cloud and hurt/manual leave it visible empty',()=>{
 for(const reason of ['goal','hurt','manual']){
  const {m,events}=fixture(),p=board(m);m.step({tick:2,player:p,input:{x:1,down:true}});p.x+=1;p.y-=2;p.vy=-3.25;p.grounded=true;p.support='native-goal';const nativeBefore=physical(p),before=cloud(m);
  assert.equal(m.disembark(p,{reason}),true);assert.equal(m.ownsPlayer(p),false);assert.equal(p.lakituCloudId,undefined);assert.equal(p.vehicleId,undefined);assert.deepEqual(physical(p),nativeBefore);
  assert.equal(cloud(m).x,before.x);assert.equal(cloud(m).y,before.y);assert.equal(cloud(m).occupancy,'empty');assert.equal(m.contactBody(p),null);assert.equal(m.disembark(p,{reason}),false);assert.equal(events.filter(q=>q.event==='disembark').length,1);assert.equal(events.at(-1).reason,reason);
  assert.equal(cloud(m).spent,reason==='goal');assert.equal(cloud(m).visible,reason!=='goal');
  p.y+=5;m.sync({tick:3,player:p});assert.equal(m.ownsPlayer(p),false,'the released passenger cannot immediately reacquire the same opening');
 }
 const {m}=fixture(),p=board(m);assert.throws(()=>m.disembark(p,{reason:'manual',jump:true}));assert.throws(()=>m.disembark(p,{reason:'teleport'}));assert(m.ownsPlayer(p));
});

test('actual goal release consumes only the mounted cloud immediately, never moves/reboards it, and reset restores it',()=>{
 const r=room([spec({hoverAmplitude:2}),spec({id:'other-cloud',x:220,hoverAmplitude:1})]),events=[],m=createLakituClouds(r,{emit:(type,data)=>events.push({type,...data})}),initial=m.view(),p=board(m,player({coins:7,lives:3,score:200,completed:false}));
 m.step({tick:2,player:p,input:{x:1,down:true}});const mounted=cloud(m),nativeBefore=physical(p);assert.equal(mounted.visible,true);assert.equal(mounted.spent,false);
 assert.equal(m.disembark(p,{reason:'goal'}),true);const spent=cloud(m);assert.equal(spent.id,mounted.id);assert.equal(spent.x,mounted.x);assert.equal(spent.y,mounted.y);assert.equal(spent.spent,true);assert.equal(spent.visible,false);assert.equal(spent.occupant,null);assert.equal(spent.contactBody,null);assert.deepEqual(physical(p),nativeBefore);assert.equal(events.at(-1).spent,true);assert.equal(events.at(-1).visible,false);
 p.y=40;p.vy=-32;m.sync({tick:3,player:p});p.y=90;p.vy=50;m.sync({tick:4,player:p});assert.equal(m.ownsPlayer(p),false,'a spent cloud cannot capture a later descending actor');
 const other=m.view().clouds[1];for(let tick=5;tick<=8;tick++)m.step({tick,player:p,input:{x:1,down:true}});assert.deepEqual(cloud(m),spent,'spent state has no flight or hover travel');assert.notEqual(m.view().clouds[1].y,other.y,'other empty clouds continue their authored hover');assert.equal(p.coins,7);assert.equal(p.lives,3);assert.equal(p.score,200);assert.equal(p.completed,false);
 m.reset();assert.deepEqual(m.view(),initial);assert.equal(cloud(m).visible,true);assert.equal(cloud(m).spent,false);p.x=101;p.y=54;p.vy=0;board(m,p);assert(m.ownsPlayer(p),'reset restores the same authored cloud for a new attempt');
});

test('native death or replacement releases the occupant without teleporting the cloud or actor',()=>{
 for(const reason of ['dead','dying','replacement']){
  const {m,events}=fixture(),p=board(m);m.step({tick:2,player:p,input:{x:1}});const before=cloud(m);p.vy=-5;const nativeBefore=physical(p);if(reason!=='replacement')p[reason]=true;
  m.sync({tick:2,player:reason==='replacement'?player({x:300,y:150}):p});assert.equal(m.ownsPlayer(p),false);assert.deepEqual(physical(p),nativeBefore);assert.equal(cloud(m).x,before.x);assert.equal(cloud(m).y,before.y);assert.equal(cloud(m).occupancy,'empty');assert.equal(p.vehicleId,undefined);assert.equal(events.filter(q=>q.event==='vacancy').length,1);
 }
 const {m}=fixture(),p=board(m);p.dead=true;p.vy=-5;const before=physical(p);assert.equal(m.disembark(p,{reason:'hurt'}),true);assert.deepEqual(physical(p),before);assert.equal(cloud(m).occupancy,'empty');
});

test('manual release permits a later genuine top reentry when the host supplies native movement',()=>{
 const {m}=fixture(),p=board(m);const before=physical(p);m.disembark(p,{reason:'manual'});assert.deepEqual(physical(p),before,'the controller supplies no jump impulse');
 p.y=40;p.vy=-32;m.sync({tick:2,player:p});assert.equal(m.ownsPlayer(p),false);p.y=90;p.vy=50;m.sync({tick:3,player:p});assert(m.ownsPlayer(p),'a recorded above-cloud pose rearms the actual released passenger');
});

test('invalid runtime arguments do not consume ticks and body growth does not fabricate boarding',()=>{
 const {m}=fixture(),p=player();m.sync({tick:0,player:p});p.h=28;m.sync({tick:1,player:p});assert.equal(m.ownsPlayer(p),false);assert.equal(cloud(m).occupancy,'empty');
 const retry=fixture().m,q=board(retry),before=retry.view();for(const bad of [{tick:-1},{tick:2,geometry:{}},{tick:2,input:null},{tick:2,player:{x:0,y:0,w:0,h:14}}])assert.throws(()=>retry.step(bad));assert.deepEqual(retry.view(),before);retry.step({tick:2,player:q,input:{x:1}});assert(q.x>before.clouds[0].occupant.x,'a corrected call still moves in the rejected tick');
});

test('empty hover is bounded, authored source is cloned, and no deadline/NPC/reward behavior appears',()=>{
 const {m,r,events}=fixture({hoverAmplitude:2,hoverPeriodFrames:60}),p=player({x:300,y:180,coins:7,lives:3,score:200,completed:false});r.smm2Mechanics.lakituClouds.clouds[0].hoverAmplitude=8;
 const initial=physical(p);for(let tick=1;tick<=1800;tick++){m.step({tick,player:p,input:{x:1,down:true}});assert.equal(cloud(m).x,96);assert(Math.abs(cloud(m).y-80)<=2+EPS);assert.equal(cloud(m).occupancy,'empty');}
 assert.equal(m.view().clouds.length,1);assert.equal(events.length,0);assert.deepEqual(physical(p),initial);assert.equal(p.coins,7);assert.equal(p.lives,3);assert.equal(p.score,200);assert.equal(p.completed,false);assert.equal(m.contactBody(),null);
});

test('reset restores authored empty state and replay is deterministic with fresh or reused native players',()=>{
 const {m}=fixture({hoverAmplitude:1}),empty=m.view(),p=player();
 const run=actor=>{actor.x=101;actor.y=54;actor.vy=0;actor.dead=false;actor.dying=false;board(m,actor);const states=[];for(let tick=2;tick<=25;tick++)states.push(m.step({tick,player:actor,input:{x:tick<12?1:-1,y:tick<18?-1:1}}));return states;};
 const first=run(p);m.reset();assert.equal(p.vehicleId,undefined);assert.equal(p.lakituCloudId,undefined);assert.deepEqual(m.view(),empty);assert.deepEqual(run(p),first);m.reset();assert.deepEqual(run(player()),first);
});

const EPS=1e-7;
