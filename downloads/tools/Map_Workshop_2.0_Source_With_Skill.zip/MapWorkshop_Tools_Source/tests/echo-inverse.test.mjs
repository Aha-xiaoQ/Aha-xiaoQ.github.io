import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createEchoRecorder,validateEchoRoom,drawEchoWorld,drawEchoHud} from '../atlas/editor-echo.mjs';
import {mountEchoEditor} from '../atlas/editor-echo-editor.mjs';
import {blank,History,parseProject} from '../atlas/editor-model.mjs';
import {createPlatformStage} from '../atlas/editor-mario-stage.mjs';
import {createPlatformMotor} from '../atlas/editor-mario-motor.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';

const actor=x=>({x,y:210,w:10,h:14,vx:0,vy:0,facing:1,grounded:true,power:0,anim:0});
const away=actor(24),atA=actor(104),atC=actor(208);
function room(){return {roomId:'main',setting:'Overworld',map:{id:'inverse-map',width:512,height:240,geometry:[{id:'floor',x:0,y:224,w:512,h:16,collision:'solid',material:'ground'}],objects:[{id:'start',kind:'spawn',x:24,y:210,w:10,h:14}]},markers:[],decorations:[],mechanics:{type:'echo-cooperation',version:1,maxFrames:360,anchorSpawn:'start'},devices:[
 {id:'ghost-a',kind:'plate',actor:'ghost',label:'A',x:96,y:224,w:32,h:4},
 {id:'live-c',kind:'plate',actor:'live',label:'C',x:200,y:224,w:32,h:4},
 {id:'positive-a',kind:'gate',label:'A ON',x:300,y:80,w:16,h:144,requires:['ghost-a'],wireY:104,material:'stone'},
 {id:'inverse-a',kind:'gate',label:'A OFF',x:340,y:80,w:16,h:144,requiresOff:['ghost-a'],wireY:128,material:'stone'},
 {id:'finalgate',kind:'gate',label:'A+C',x:380,y:80,w:16,h:144,requires:['ghost-a','live-c'],latch:true,material:'stone'}
]};}
const device=(echo,id)=>echo.view().devices.find(d=>d.id===id);
function check(echo,live,expected){
 const geometry=echo.apply(room().map.geometry,live),view=echo.view();
 // Native stage invokes apply more than once per frame: it must neither advance
 // the tape nor multiply colliders or change a satisfied latch on repetition.
 assert.deepEqual(echo.apply(geometry,live),geometry);assert.deepEqual(echo.view(),view);
 assert.equal(device(echo,'ghost-a').active,expected.a);
 assert.equal(device(echo,'positive-a').solid,!expected.a);
 assert.equal(device(echo,'inverse-a').solid,expected.a);
 assert.equal(device(echo,'inverse-a').latched,false);
 if(expected.final!==undefined)assert.equal(device(echo,'finalgate').latched,expected.final);
 return view;
}

test('null ghost is OFF in READY and REC, then off→on→off→on drives both gates through PLAY and HOLD',()=>{
 const echo=createEchoRecorder(room());assert.equal(echo.view().phase,'idle');check(echo,atA,{a:false,final:false});
 echo.start(away);assert.equal(echo.view().phase,'recording');check(echo,atA,{a:false,final:false});
 for(const pose of [atA,away,atA]){echo.afterFrame(pose);check(echo,atC,{a:false,final:false});}
 echo.commit();assert.equal(echo.view().phase,'playing');check(echo,atC,{a:false,final:false});
 echo.beforeFrame();assert.equal(echo.view().phase,'playing');check(echo,atC,{a:true,final:true});
 echo.beforeFrame();check(echo,away,{a:false,final:true});
 echo.beforeFrame();assert.equal(echo.view().phase,'holding');check(echo,away,{a:true,final:true});
 const held=echo.view();for(let i=0;i<10;i++){echo.beforeFrame();check(echo,away,{a:true,final:true});}assert.deepEqual(echo.view(),held);
});

test('mixed ON/OFF links are a direct conjunction, and inverse bridges use the same predicate',()=>{
 const r=room();r.devices.push({id:'mixed',kind:'bridge',label:'C-A',x:400,y:160,w:64,h:8,requires:['live-c'],requiresOff:['ghost-a'],material:'bridge'});
 const echo=createEchoRecorder(r);echo.apply([],away);assert.equal(device(echo,'mixed').solid,false);echo.apply([],atC);assert.equal(device(echo,'mixed').solid,true);
 echo.start(atA);echo.afterFrame(atA);echo.commit();echo.apply([],atC);assert.equal(device(echo,'mixed').solid,false);
});

test('pressure timeline derives draft/saved ON and OFF spans solely from grounded native poses',()=>{
 const echo=createEchoRecorder(room());assert.deepEqual(echo.view().pressureTimeline,{plateId:'ghost-a',label:'A',source:'empty',frames:0,spans:[],tailActive:false});
 echo.start(away);for(const p of [away,atA,atA,{...atA,grounded:false},away,atA])echo.afterFrame(p);
 const expected=[{start:0,end:1,active:false},{start:2,end:3,active:true},{start:4,end:5,active:false},{start:6,end:6,active:true}];
 assert.equal(echo.view().pressureTimeline.source,'draft');assert.equal(echo.view().pressureTimeline.frames,6);assert.deepEqual(echo.view().pressureTimeline.spans,expected);assert.equal(echo.view().pressureTimeline.tailActive,true);
 echo.commit();const timeline=echo.view().pressureTimeline,tape=echo.serializeTape();assert.equal(timeline.source,'saved');assert.deepEqual(timeline.spans,expected);
 for(let i=0;i<6;i++)echo.beforeFrame();assert.equal(echo.view().phase,'holding');assert.deepEqual(echo.view().pressureTimeline,timeline);
 echo.start(atA);echo.afterFrame(atA);assert.deepEqual(echo.view().pressureTimeline.spans,[{start:0,end:1,active:true}]);assert.equal(echo.view().hasSavedTape,true);
 echo.retry();assert.deepEqual(echo.view().pressureTimeline,timeline);assert.equal(echo.serializeTape(),tape);
 const detached=echo.view().pressureTimeline;detached.spans[0].active=true;assert.deepEqual(echo.view().pressureTimeline,timeline);
 echo.cancel();assert.deepEqual(echo.view().pressureTimeline,timeline);echo.reset();assert.equal(echo.view().pressureTimeline.source,'empty');
 const noPlate=room();noPlate.devices=[];assert.equal(createEchoRecorder(noPlate).view().pressureTimeline,null);
});

test('HUD pressure timeline uses solid ON plus marks, dotted OFF, a white cursor and explicit held tail',()=>{
 const echo=createEchoRecorder(room());echo.start(away);for(let i=0;i<20;i++)echo.afterFrame(away);for(let i=0;i<20;i++)echo.afterFrame(atA);echo.commit();for(let i=0;i<40;i++)echo.beforeFrame();
 const rectangles=[],texts=[];let color='';const context=new Proxy({fillRect:(x,y,w,h)=>rectangles.push({x,y,w,h,color}),fillText:text=>texts.push(text)}, {get:(target,key)=>target[key]??(()=>{}),set:(target,key,value)=>{if(key==='fillStyle')color=value;target[key]=value;return true;}});
 drawEchoHud(context,echo.view());assert.ok(rectangles.some(r=>r.y===58&&r.h===4&&r.color==='#69dcff'));assert.ok(rectangles.some(r=>r.y===59&&r.h===2&&r.color==='#263744'));assert.ok(rectangles.some(r=>r.y===59&&r.w===3&&r.h===1&&r.color==='#fff'));assert.ok(rectangles.some(r=>r.y===57&&r.w===1&&r.h===6&&r.color==='#fff'&&r.x===33));
 assert.ok(texts.includes('6s'));assert.ok(texts.includes('缓存 40帧'));assert.ok(texts.includes('影子停最后帧 A ON · T 原样重播'));
});

test('A+C latch persists after contact but clears on saved retry, new draft, death cancellation and clear',()=>{
 const echo=createEchoRecorder(room());echo.start(away);echo.afterFrame(atA);echo.afterFrame(atA);echo.commit();const tape=echo.serializeTape(),digest=echo.view().tapeDigest;
 check(echo,atC,{a:false,final:false});echo.beforeFrame();check(echo,atC,{a:true,final:true});check(echo,away,{a:true,final:true});
 assert.equal(echo.retry(),true);check(echo,atC,{a:false,final:false});echo.beforeFrame();check(echo,atC,{a:true,final:true});
 echo.start(atA);check(echo,atC,{a:false,final:false});assert.equal(echo.view().hasSavedTape,true);echo.retry();echo.beforeFrame();check(echo,atC,{a:true,final:true});
 echo.cancel();check(echo,atC,{a:false,final:false});assert.equal(echo.view().phase,'idle');assert.equal(echo.serializeTape(),tape);assert.equal(echo.view().tapeDigest,digest);
 echo.retry();check(echo,atC,{a:false,final:false});echo.reset();check(echo,atC,{a:false,final:false});assert.equal(echo.view().hasSavedTape,false);assert.equal(echo.retry(),false);
});

test('native stage keeps inverse gate geometry consistent in ready, recording, replay, hold and T retry',()=>{
 const r=room();r.devices[0].x=16;
 const plan={character:{capabilities:['jump'],motion:{width:10,height:14,maxHealth:1}},stage:{entryRoom:'main',entrySpawn:'start',title:'Inverse stage'},rooms:{main:r.map}};
 const s=createPlatformStage({plan,motor:createPlatformMotor(),visualRooms:[r],emit(){}}),off=()=>s.view().echo.devices.find(d=>d.id==='inverse-a');
 s.step({});assert.equal(s.view().echo.phase,'idle');assert.equal(off().solid,false);
 s.step({echo:true});assert.equal(s.view().echo.phase,'recording');assert.equal(off().solid,false);
 s.step({});s.step({});s.step({echo:true});assert.equal(s.view().echo.phase,'playing');assert.equal(off().solid,false); // t0 is the native ungrounded spawn pose.
 s.step({});assert.equal(off().solid,true);assert.ok(s.view().geometry.some(g=>g.id==='inverse-a'&&g.material==='stone'&&g.echoDevice));s.step({});assert.equal(s.view().echo.phase,'holding');assert.equal(off().solid,true);
 s.step({echoRetry:true});assert.equal(s.view().echo.phase,'playing');assert.equal(s.view().echo.cursor,0);assert.equal(off().solid,false);s.step({});assert.equal(off().solid,true);
 s.step({echoClear:true});assert.equal(s.view().echo.phase,'idle');assert.equal(off().solid,false);assert.ok(!s.view().geometry.some(g=>g.id==='inverse-a'));
});

test('inverse references reject malformed types, duplicates, overlap, missing plates and nonplate IDs',()=>{
 const mutations=[
  d=>d.requiresOff='ghost-a',d=>d.requiresOff=null,d=>d.requiresOff=[7],d=>d.requiresOff=['ghost-a','ghost-a'],
  d=>d.requiresOff=['missing'],d=>d.requiresOff=['positive-a'],d=>d.requires=['ghost-a'],
  d=>d.requiresOff=[],d=>d.requiresOff=[''],d=>d.requires={},d=>d.wireY=NaN,d=>d.wireY=-1,d=>d.wireY=241
 ];
 for(const mutate of mutations){const r=room();mutate(r.devices[3]);assert.throws(()=>validateEchoRoom(r));}
 const r=room();r.devices[0].requiresOff=['live-c'];assert.throws(()=>validateEchoRoom(r));
 const tooMany=room();tooMany.devices[3].requiresOff=Array.from({length:17},(_,i)=>'plate-'+i);assert.throws(()=>validateEchoRoom(tooMany));
});

test('inverse qmap links and cosmetic routing survive history and JSON identity round trips',()=>{
 const doc=blank('Inverse editable fixture',512,240);doc.rooms[0]={...doc.rooms[0],...room(),map:{...doc.rooms[0].map,...room().map}};
 const history=new History(doc);history.change(d=>{d.rooms[0].devices[3].wireY=136;});history.undo();assert.equal(history.doc.rooms[0].devices[3].wireY,128);history.redo();
 const parsed=parseProject(JSON.stringify(history.doc));assert.equal(parsed.id,doc.id);assert.deepEqual(parsed.rooms[0].devices,history.doc.rooms[0].devices);assert.deepEqual(parsed.rooms[0].devices[3].requiresOff,['ghost-a']);
});

test('renderer shows ON/OFF relation labels, distinct arrow/bar endpoints and live OPEN/SHUT/WAIT states',()=>{
 const r=room();r.map.title='03 · 回声反应堆';const echo=createEchoRecorder(r),texts=[],paths=[],dashes=[];let path=[];
 const context=new Proxy({fillText:(text,x,y)=>texts.push({text,x,y}),beginPath:()=>{path=[];},moveTo:(x,y)=>path.push(['M',x,y]),lineTo:(x,y)=>path.push(['L',x,y]),stroke:()=>paths.push(path),setLineDash:d=>dashes.push(d)}, {get:(target,key)=>target[key]??(()=>{}),set:(target,key,value)=>{target[key]=value;return true;}});
 echo.apply([],away);drawEchoWorld(context,echo.view(),r);
 for(const label of ['A ON','A OFF','OPEN','SHUT'])assert.ok(texts.some(q=>q.text===label));
 assert.ok(texts.some(q=>q.text==='时间工厂'));assert.ok(texts.some(q=>q.text==='03'));
 assert.ok(dashes.some(d=>d.join(',')==='3,2'));assert.ok(paths.some(p=>p.length===3&&p[0][0]==='M'&&p[1][1]===298&&p[1][2]===104));
 assert.ok(paths.some(p=>p.length===2&&p[0][1]===338&&p[1][1]===338&&p[1][2]-p[0][2]===8));
 echo.start(atA);echo.afterFrame(atA);echo.commit();echo.apply([],{...away,x:342});drawEchoWorld(context,{...echo.view(),ghost:null},r);assert.ok(texts.some(q=>q.text==='WAIT'));
});

test('authoring inspector edits OFF-only links, rejects overlap and guards OFF plate deletion',()=>{
 const ui=installSimulatedPlayDom();
 // Add form/index lookups needed by the real inspector to the existing DOM shim.
 const originalQuery=ui.Element.prototype.querySelector;
 ui.Element.prototype.querySelector=function(selector){return selector.startsWith('#')?this.querySelectorAll('[id]').find(el=>el.id===selector.slice(1))||null:originalQuery.call(this,selector);};
 Object.defineProperty(ui.Element.prototype,'elements',{get(){return Object.fromEntries(this.querySelectorAll('[name]').map(el=>{if(Object.getOwnPropertyDescriptor(el,'value')?.value!==undefined){let value=String(el.value);Object.defineProperty(el,'value',{get:()=>value,set:v=>{value=String(v);},configurable:true});}return [el.getAttribute('name'),el];}));},configurable:true});
 try{
  const doc=blank('Inverse inspector fixture',512,240);doc.rooms[0]={...doc.rooms[0],...room(),map:{...doc.rooms[0].map,...room().map}};const history=new History(doc),errors=[];let editor;
  const parent=ui.document.createElement('aside');ui.document.body.append(parent);
  editor=mountEchoEditor({parent,room:()=>history.doc.rooms[0],change:fn=>{history.change(fn);editor.refresh();},report:error=>errors.push(error)});editor.refresh();
  const get=id=>parent.querySelector('#'+id),select=id=>{get('echo-device').value=id;get('echo-device').onchange();};
  select('inverse-a');const form=get('echo-device-form');assert.equal(form.elements.requires.value,'');assert.equal(form.elements.requiresOff.value,'ghost-a');
  form.elements.wireY.value='140';form.onsubmit({preventDefault(){}});assert.equal(history.doc.rooms[0].devices[3].wireY,140);assert.deepEqual(history.doc.rooms[0].devices[3].requiresOff,['ghost-a']);
  form.elements.requires.value='ghost-a';form.onsubmit({preventDefault(){}});assert.ok(errors.at(-1).includes('不重叠'));assert.deepEqual(history.doc.rooms[0].devices[3].requires,[]);
  // Remove every positive reference so this guard can only be the OFF link.
  history.change(d=>{d.rooms[0].devices=d.rooms[0].devices.filter(q=>!['positive-a','finalgate'].includes(q.id));});select('ghost-a');get('echo-remove').onclick();assert.ok(errors.at(-1).includes('仍被'));assert.ok(history.doc.rooms[0].devices.some(q=>q.id==='ghost-a'));
  select('inverse-a');get('echo-remove').onclick();select('ghost-a');get('echo-remove').onclick();assert.ok(!history.doc.rooms[0].devices.some(q=>q.id==='ghost-a'));
 }finally{ui.restore();}
});
