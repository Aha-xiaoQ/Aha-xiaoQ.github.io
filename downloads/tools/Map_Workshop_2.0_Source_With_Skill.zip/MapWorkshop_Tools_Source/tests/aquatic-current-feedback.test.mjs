import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {createCanvas,Image} from '@napi-rs/canvas';
import {drawAquaticCurrents} from '../atlas/editor-aquatic-art.mjs';
import {validateAquaticRoom} from '../atlas/editor-aquatic.mjs';
import {background,drawScenery,drawTile,drawObject} from '../atlas/editor-art.mjs';
import {offlineFile} from '../atlas/editor-offline.mjs';
import {nativeWorld} from '../render-lantern-course-native-canvas.mjs';
import {blank} from '../atlas/editor-model.mjs';
import {projectPack} from '../atlas/editor-runtime.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';

const canvas=()=>createCanvas(384,216);
const pixels=c=>c.getContext('2d').getImageData(0,0,c.width,c.height).data;
const freeze=value=>{if(value&&typeof value==='object'){for(const child of Object.values(value))freeze(child);Object.freeze(value);}return value;};
function room(patch={}){
 const r={roomId:'main',setting:'Underwater',underwater:true,decorations:[],markers:[],nativeSceneryMode:'authored',map:{width:384,height:216,geometry:[],objects:[]},aquatic:{version:1,currents:[{id:'neutral-current',x:48,y:80,w:192,h:96,centerX:144,pull:.018,down:.025}]},...patch};
 validateAquaticRoom(r);return r;
}
function paint(r,tick=0){const c=canvas();drawAquaticCurrents(c.getContext('2d'),r,tick);return c;}
function trace(r,tick){
 const c=canvas(),ctx=c.getContext('2d'),calls=[],fill=ctx.fillRect.bind(ctx);
 ctx.fillRect=(x,y,w,h)=>{calls.push({x,y,w,h,alpha:ctx.globalAlpha});fill(x,y,w,h);};
 drawAquaticCurrents(ctx,r,tick);return {c,calls};
}
const shafts=t=>t.calls.flatMap((q,i)=>q.w===6&&q.h===1?[{shaft:q,fins:t.calls.slice(i+1,i+3),tip:t.calls[i+3]}]:[]);
const drops=t=>t.calls.flatMap((q,i)=>q.w===1&&q.h===6?[{shaft:q,fins:t.calls.slice(i+1,i+3),tip:t.calls[i+3]}]:[]);

test('native pixels and arrowheads point toward the actual centre and downward, and advance in those directions',()=>{
 const r=freeze(room()),t0=trace(r,0),t1=trace(r,3),left=shafts(t0).filter(q=>q.tip.x<144),right=shafts(t0).filter(q=>q.tip.x>144),down=drops(t0);
 assert(left.length>0&&right.length>0&&down.length>0);
 for(const [direction,marks]of [[1,left],[-1,right]])for(const mark of marks){
  assert.equal(mark.shaft.x,direction>0?mark.tip.x-5:mark.tip.x);
  assert.deepEqual(mark.fins.map(q=>[q.x,q.y]),[[mark.tip.x-direction,mark.tip.y-1],[mark.tip.x-direction,mark.tip.y+1]]);
  assert(t0.c.getContext('2d').getImageData(mark.tip.x,mark.tip.y,1,1).data[3]>0,'a real native pixel paints each head');
 }
 for(const mark of down){
  assert.equal(mark.shaft.y,mark.tip.y-5);
  assert.deepEqual(mark.fins.map(q=>[q.x,q.y]),[[mark.tip.x-1,mark.tip.y-1],[mark.tip.x+1,mark.tip.y-1]]);
 }
 const horizontal0=shafts(t0),horizontal1=shafts(t1);
 for(const direction of [1,-1]){
  let advancing=0;
  for(const a of horizontal0.filter(q=>Math.sign(144-q.tip.x)===direction)){
   const b=horizontal1.find(q=>q.tip.y===a.tip.y&&Math.sign(144-q.tip.x)===direction&&Math.abs(q.tip.x-a.tip.x)<4);
   if(b&&b.tip.x!==a.tip.x){assert.equal(Math.sign(b.tip.x-a.tip.x),direction);advancing++;}
  }
  assert(advancing>0,'both horizontal streams visibly advance inward');
 }
 let falling=0;
 for(const a of down){const b=drops(t1).find(q=>q.tip.x===a.tip.x&&Math.abs(q.tip.y-a.tip.y)<4);if(b&&b.tip.y!==a.tip.y){assert(b.tip.y>a.tip.y);falling++;}}
 assert(falling>0,'vertical streaks visibly travel down');
});

test('forces switch each directional channel independently, including defaults and an edge centre',()=>{
 const base=room();
 for(const [pull,down,horizontal,vertical]of [[0,0,false,false],[.018,0,true,false],[0,.025,false,true],[.018,.025,true,true]]){
  const r=room({aquatic:{version:1,currents:[{...base.aquatic.currents[0],pull,down}]}}),t=trace(freeze(r),9);
  assert.equal(shafts(t).length>0,horizontal);assert.equal(drops(t).length>0,vertical);
 }
 const current={...base.aquatic.currents[0]};delete current.pull;delete current.down;
 assert.deepEqual(pixels(paint(room({aquatic:{version:1,currents:[current]}}),12)),pixels(paint(base,12)));
 const edge=trace(room({aquatic:{version:1,currents:[{...current,centerX:48}]}}),3);
 assert(shafts(edge).length>0);for(const mark of shafts(edge))assert.equal(mark.shaft.x,mark.tip.x,'all horizontal marks point left at a left-edge centre');
});

test('the actual current rectangle clips every stroke with no opaque volume fill or out-of-room painting',()=>{
 for(const geometry of [{x:48,y:48,w:192,h:128,centerX:144},{x:0,y:0,w:384,h:216,centerX:192},{x:8.25,y:17.5,w:13.5,h:9.25,centerX:15}]){
  const r=room({aquatic:{version:1,currents:[{id:'clipped-current',...geometry}]}}),before=JSON.stringify(r),c=paint(freeze(r),17),data=pixels(c);let painted=0,empty=0;
  for(let y=0;y<216;y++)for(let x=0;x<384;x++){
   const alpha=data[(y*384+x)*4+3],overlaps=x+1>geometry.x&&x<geometry.x+geometry.w&&y+1>geometry.y&&y<geometry.y+geometry.h;
   if(!overlaps)assert.equal(alpha,0,'no mark escapes the actual volume');
   else if(alpha){painted++;assert(alpha<255,'a current never becomes an opaque box');}else empty++;
  }
  assert(painted>0);assert(empty>painted,'most water remains untouched');assert.equal(JSON.stringify(r),before);
 }
 const absent=room({renderBounds:{x:300,y:0,w:80,h:216}}),c=canvas();assert.equal(drawAquaticCurrents(c.getContext('2d'),absent,8),false);assert(pixels(c).every(q=>q===0));
});

test('frozen inputs, repeated and out-of-order ticks and pause redraws are deterministic, with Canvas state restored',()=>{
 const r=freeze(room()),before=JSON.stringify(r),reference=pixels(paint(r,17));
 for(const tick of [17,0,49,17,3,17]){const data=pixels(paint(r,tick));if(tick===17)assert.deepEqual(data,reference);}
 assert.notDeepEqual(pixels(paint(r,0)),reference);
 for(const tick of [NaN,Infinity,-1,undefined])assert.deepEqual(pixels(paint(r,tick)),pixels(paint(r,0)));
 assert.deepEqual(pixels(paint(r,17.9)),reference);assert.equal(JSON.stringify(r),before);
 const actual=canvas(),expected=canvas(),c=actual.getContext('2d');c.translate(3,4);c.globalAlpha=.7;c.fillStyle='#123456';c.imageSmoothingEnabled=true;const transform=c.getTransform();
 drawAquaticCurrents(c,r,17);assert.deepEqual(c.getTransform(),transform);assert(Math.abs(c.globalAlpha-.7)<1/255,'native Canvas restores its quantized alpha');assert.equal(c.imageSmoothingEnabled,true);
 // Verify restored paint behavior; the native Canvas fillStyle getter caches assignments.
 c.clearRect(-3,-4,384,216);c.fillRect(2,3,1,1);const e=expected.getContext('2d');e.translate(3,4);e.globalAlpha=.7;e.fillStyle='#123456';e.fillRect(2,3,1,1);assert.deepEqual(pixels(actual),pixels(expected));
});

test('omitted, disabled and dry-room data paint nothing and leave Canvas state alone',()=>{
 const valid=room();
 for(const r of [{...valid,aquatic:undefined},{...valid,aquatic:{version:1}},{...valid,aquatic:{version:0,currents:valid.aquatic.currents}},{...valid,underwater:false},{...valid,setting:'Overworld'}]){
  const c=canvas(),ctx=c.getContext('2d');ctx.globalAlpha=.6;assert.equal(drawAquaticCurrents(ctx,freeze(r),12),false);assert(pixels(c).every(q=>q===0));assert.equal(ctx.globalAlpha,.6);
 }
});

test('shared scenery dispatch paints the current exactly once through a synthetic early-return branch, before terrain and actors',()=>{
 // This branch-only regression is not an authorable aquatic+contraptions project.
 const r=freeze({...room(),contraptions:{version:1},tick:12}),actual=canvas(),expected=canvas();drawScenery(actual.getContext('2d'),r);drawAquaticCurrents(expected.getContext('2d'),r,12);assert.deepEqual(pixels(actual),pixels(expected));
 const tile=freeze({id:'cover',x:80,y:80,w:64,h:64,material:'ground',collision:'solid'}),actor=freeze({id:'fish',kind:'walker',type:'cheepcheep',x:144,y:96,w:16,h:16});
 drawTile(actual.getContext('2d'),tile,r);drawObject(actual.getContext('2d'),actor,12,r);
 const foreground=canvas();drawTile(foreground.getContext('2d'),tile,r);drawObject(foreground.getContext('2d'),actor,12,r);
 const a=pixels(actual),b=pixels(foreground);let visibleForeground=0;for(let i=0;i<b.length;i+=4)if(b[i+3]===255){assert.deepEqual(a.slice(i,i+4),b.slice(i,i+4));visibleForeground++;}assert(visibleForeground>0,'real native terrain and actor artwork covers the current');
});

test('actual native video bridge and shared local background/scenery dispatch produce the same current pixels',()=>{
 const r=freeze(room()),view=freeze({roomId:'main',tick:23,p:{x:0,y:0,w:10,h:14},geometry:[],objects:[],enemies:[],items:[],vines:[],coins:0,score:0,timeLeft:300,lives:3}),doc=freeze({rooms:[r]}),before=JSON.stringify({doc,view}),camera={x:0,y:0,w:384,h:216};
 const native=nativeWorld(view,doc,{camera,showPlayer:false,scale:1}).canvas,baseline=nativeWorld(view,{rooms:[{...r,aquatic:undefined}]},{camera,showPlayer:false,scale:1}).canvas;
 const local=canvas(),ctx=local.getContext('2d');background(ctx,r,384,216);drawScenery(ctx,{...r,tick:view.tick});
 const region=c=>c.getContext('2d').getImageData(0,80,384,136).data;
 assert(Buffer.from(region(native)).equals(Buffer.from(region(local))),'every current and surrounding gameplay pixel matches the actual bridge below the separate HUD pass');
 assert.notDeepEqual(pixels(native),pixels(baseline));assert.equal(JSON.stringify({doc,view}),before);
});

test('standalone HTML executes its embedded shared art against native Canvas with zero network',async()=>{
 const root=new URL('../atlas/',import.meta.url),r=freeze(room()),html=await offlineFile({stages:[{title:'Neutral current art probe'}]},[r],p=>fs.readFile(new URL(p,root),'utf8'),p=>fs.readFile(new URL('assets/classic-audio/'+p,root)));
 const dir=await fs.mkdtemp(path.join(os.tmpdir(),'Aquatic Current Feedback QA '));
 try{
  const file=path.join(dir,'fixture.html');await fs.writeFile(file,html);
  const result=spawnSync(process.execPath,['--experimental-vm-modules',fileURLToPath(new URL('./fixtures/aquatic-current-offline-check.mjs',import.meta.url)),file],{encoding:'utf8',timeout:30000,maxBuffer:1024*1024});
  assert.equal(result.status,0,result.stderr||result.stdout||String(result.error));const report=JSON.parse(result.stdout);assert.equal(report.embeddedSharedDispatchExecuted,true);assert.equal(report.nativeVideoBridgeExecuted,true);assert.equal(report.sameTickFrozen,true);assert.equal(report.networkRequests,0);assert.equal(report.rasterScenes,12);
 }finally{await fs.rm(dir,{recursive:true,force:true});}
});

test('actual play draws current pixels through shared scenery and a paused active tick freezes its native raster',async()=>{
 const ui=installSimulatedPlayDom(),create=ui.document.createElement,rasters=new WeakMap();let session;
 // Retain the real UI action surface while replacing every canvas with native pixels.
 ui.document.createElement=tag=>{
  const el=create(tag);if(tag!=='canvas')return el;
  const raster=createCanvas(1,1),ctx=raster.getContext('2d');rasters.set(el,raster);
  for(const dimension of ['width','height'])Object.defineProperty(el,dimension,{get:()=>raster[dimension],set:value=>{raster[dimension]=value;},configurable:true});
  el.getContext=()=>new Proxy(ctx,{get(target,key){if(key==='drawImage')return(source,...args)=>target.drawImage(rasters.get(source)||source,...args);const value=target[key];return typeof value==='function'?value.bind(target):value;},set(target,key,value){target[key]=value;return true;}});
  return el;
 };
 globalThis.Image=Image;
 try{
  const doc=blank('Neutral playable current fixture',384,216),r=doc.rooms[0];r.setting='Underwater';r.underwater=true;r.aquatic=room().aquatic;r.map.geometry=[{id:'floor',x:0,y:192,w:384,h:24,material:'ground',collision:'solid'}];r.map.objects=[{id:'start',kind:'spawn',x:24,y:144,w:10,h:14}];
  const character=JSON.parse(await fs.readFile(new URL('../atlas/runtime/character.json',import.meta.url),'utf8')),{play}=await import('../atlas/editor-play.mjs');
  const brandImage=new Image();brandImage.src=await fs.readFile(new URL('../atlas/assets/q-logo-pixel-core.svg',import.meta.url));await brandImage.decode();const brandRaster=createCanvas(16,16);brandRaster.getContext('2d').drawImage(brandImage,0,0,16,16);const brandCore=brandRaster.toDataURL('image/png');
  session=await play(projectPack(doc,r.roomId,character,'neutral-current-play'),doc.rooms,{brandCore},{developerMode:false});
  const game=session.screen.querySelector('canvas[aria-label]');ui.frames(6);const initialTick=game.workshopRead().tick;assert(initialTick>0);const raster=rasters.get(game),currentRegion=()=>Buffer.from(raster.getContext('2d').getImageData(96,160,384,192).data),first=currentRegion();
  // Mario is outside this world-space volume; only current marks animate here.
  ui.frames(6);assert(game.workshopRead().tick>initialTick);assert(!currentRegion().equals(first),'current pixels change with the actual stage tick');
  ui.key('KeyP');ui.frames(1);const pausedTick=game.workshopRead().tick,paused=Buffer.from(pixels(raster));ui.frames(6);assert.equal(game.workshopRead().tick,pausedTick);assert(Buffer.from(pixels(raster)).equals(paused),'pause redraws preserve identical native pixels');
  const pausedCurrent=currentRegion();ui.key('KeyP');ui.frames(6);assert(game.workshopRead().tick>pausedTick);assert(!currentRegion().equals(pausedCurrent),'resuming advances the real flow animation');
 }finally{ui.document.querySelector('dialog')?.close();ui.restore();}
});
