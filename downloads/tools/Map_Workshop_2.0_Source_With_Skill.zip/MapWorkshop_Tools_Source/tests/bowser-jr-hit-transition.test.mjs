import test from 'node:test';
import assert from 'node:assert/strict';
import {createCanvas} from '@napi-rs/canvas';
import {parseProject,History,updateSmm2BowserJr,cloneSmm2BowserJr} from '../atlas/editor-model.mjs';
import {createBowserJuniors,bowserJrView,bowserJrVisibleFrame,bowserJrFireballVisibleFrame,validateBowserJrRule,BOWSER_JR_AUTHORING_DEFAULTS} from '../atlas/editor-bowser-jr.mjs';
import {captureSmm2ActorLeaves,appendCopiedSmm2ActorLeaves} from '../atlas/editor-smm2-tools.mjs';
import {mountBowserJrTools} from '../atlas/editor-bowser-jr-tools.mjs';
import {drawObject} from '../atlas/editor-art.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';
import {nativeSession} from './fixtures/shell-coin-native.mjs';
import {bowserJrProject,displayedJrHeadTarget,threeNativeJrStomps} from './fixtures/bowser-jr-native.mjs';

function transitionProject(frames=15){
 const d=bowserJrProject();Object.assign(d.rooms[0].smm2Mechanics.bowserJuniors.actors[0],{hitTransitionFrames:frames,hitHopSpeed:3.5});return d;
}
function controller(doc=transitionProject()){
 const r=doc.rooms[0],events=[],c=createBowserJuniors(r,{emit:(type,data)=>events.push({type,...data})});
 return {r,c,events,a:c.decorateActor({...r.map.objects.find(a=>a.id==='junior'),dead:false})};
}
// Unit contact samples cross a real displayed head surface. Native integration
// below supplies only ordinary input and never edits a running actor or player.
function headContact(c,a,tick=1){
 const head=displayedJrHeadTarget(a),p={x:head.x-5,y:head.y-13,w:10,h:14,vy:2};
 return c.playerContact(a,p,{...p,y:p.y-2},{tick,beforeActor:structuredClone(a)});
}

test('missing optional hit fields preserve legacy JSON and the immediate shell lifecycle without mutation',()=>{
 for(const missing of [true,false]){
  const d=bowserJrProject(),q=d.rooms[0].smm2Mechanics.bowserJuniors.actors[0];
  if(missing){delete q.hitTransitionFrames;delete q.hitHopSpeed;}
  const before=JSON.stringify(d),parsed=parseProject(before);assert.deepEqual(parsed,d);
  const {c,a}=controller(parsed),result=headContact(c,a);
  assert(result.bounce);assert.equal(a.hp,2);assert.equal(a.smm2BowserJr.phase,'shell');assert.equal(a.w,18);assert.equal(a.h,16);assert.equal(a.y+a.h,288);
  assert.equal(JSON.stringify(d),before);assert.equal(JSON.stringify(parsed),before);
  assert.equal(Object.hasOwn(parsed.rooms[0].smm2Mechanics.bowserJuniors.actors[0],'hitTransitionFrames'),!missing);
 }
 for(const patch of [{hitTransitionFrames:null,hitHopSpeed:null},{hitTransitionFrames:15,hitHopSpeed:null},{hitTransitionFrames:null,hitHopSpeed:0},{hitTransitionFrames:15},{hitHopSpeed:3.5},{hitTransitionFrames:0,hitHopSpeed:3.5},{hitTransitionFrames:-1,hitHopSpeed:3.5},{hitTransitionFrames:14.5,hitHopSpeed:3.5},{hitTransitionFrames:121,hitHopSpeed:3.5},{hitTransitionFrames:15,hitHopSpeed:13}])assert.throws(()=>validateBowserJrRule({...BOWSER_JR_AUTHORING_DEFAULTS,...patch}));
});

test('authored 14 and 15 tick transitions keep the body and produce a physical short hop before shell pursuit',()=>{
 for(const frames of [14,15]){
  const s=nativeSession(transitionProject(frames));s.until(v=>v.enemies[0]?.hp===2,{},80);
  const first=s.view().enemies[0],startTick=s.view().tick,seen=new Set([bowserJrVisibleFrame(first).key]);
  assert.equal(first.smm2BowserJr.phase,'hit-transition');assert.equal(first.smm2BowserJr.phaseAge,0);assert.equal(first.vy,-3.5);assert.equal(first.vx,0);
  assert.equal(first.w,24);assert.equal(first.h,24);assert.equal(bowserJrView(first).exposed,false);assert.equal(first.shell,false);
  let minimumY=first.y,prior=first;
  for(let age=1;age<frames;age++){
   const v=s.step({jump:true}),a=v.enemies[0];assert(!v.p.dying);
   assert.equal(a.hp,2);assert.equal(a.smm2BowserJr.phase,'hit-transition');assert.equal(a.smm2BowserJr.phaseAge,age);
   assert.equal(a.x,first.x);assert.equal(a.w,24);assert.equal(a.h,24);assert.equal(a.vx,0);
   if(age===1)assert(a.y<first.y,'the native actor moves upward, independently of rendered pose');
   minimumY=Math.min(minimumY,a.y);seen.add(bowserJrVisibleFrame(a).key);prior=a;
  }
  assert(minimumY<first.y-10);assert(seen.has('hurt-flash'));assert(seen.has('hit-air'));
  const v=s.step({jump:true}),shell=v.enemies[0];assert(!v.p.dying);assert.equal(shell.smm2BowserJr.phase,'shell');assert.equal(shell.smm2BowserJr.phaseAge,0);
  assert.equal(shell.w,18);assert.equal(shell.h,16);assert.equal(shell.hp,2);assert.equal(Math.abs(shell.vx),2.6);
  assert(Math.abs((shell.y+shell.h)-(prior.y+prior.h)-shell.vy)<1e-7,'shape changes preserve the physical feet before gravity/movement');
  const start=s.events.filter(e=>e.event==='shell-pursuit-start');assert.equal(start.length,1);assert.equal(start[0].tick-startTick,frames);
 }
});

test('one head contact decrements HP once and transition contacts cannot repeat head damage',()=>{
 const {r,c,a,events}=controller(),hit=headContact(c,a,1);assert(hit.bounce);assert.equal(a.hp,2);
 const snapshot=structuredClone(a);assert.equal(headContact(c,a,1).bounce,false);assert.deepEqual(a,snapshot);
 for(let tick=2;tick<=14;tick++){
  c.stepActor(a,{tick,player:{x:500,y:180,w:10,h:14},geometry:r.map.geometry});
  const stepped=structuredClone(a);c.stepActor(a,{tick,player:{x:20,y:180,w:10,h:14},geometry:r.map.geometry});assert.deepEqual(a,stepped,'duplicate simulation tick is not an extra state clock');
  assert.equal(headContact(c,a,tick).bounce,false);assert.equal(a.hp,2);assert.equal(a.smm2BowserJr.phase,'hit-transition');assert.equal(bowserJrView(a).exposed,false);
 }
 assert.equal(events.filter(e=>e.event==='head-stomp').length,1);assert.equal(events.filter(e=>e.event==='defeated').length,0);
});

test('the rebound separation guard preserves harmful side and descending recontacts and never protects shell contact',()=>{
 const {r,c,a}=controller();assert(headContact(c,a).bounce);
 const descending=headContact(c,a,2);assert.equal(descending.harmful,true);assert.equal(descending.bounce,false);assert.equal(a.hp,2);
 const f=bowserJrVisibleFrame(a);let side=null;
 for(let row=12;row<f.image.h&&!side;row++)for(let col=0;col<f.image.w&&!side;col++)if(parseInt(f.image.rows[row][col],36))side={x:f.x+col+.25,y:f.y+row+.25,w:.5,h:.5,vy:-1};
 assert(side);const sideContact=c.playerContact(a,side,{...side,y:side.y+1},{tick:3,beforeActor:structuredClone(a)});
 assert.equal(sideContact.harmful,true);assert.equal(sideContact.bounce,false);assert.equal(a.hp,2,'upward motion from the side is not a repeat head hit or protected rebound');
 for(let tick=2;tick<=16;tick++)c.stepActor(a,{tick,player:{x:500,y:180,w:10,h:14},geometry:r.map.geometry});
 assert.equal(a.smm2BowserJr.phase,'shell');const crest=displayedJrHeadTarget(a),p={x:crest.x-.25,y:crest.y-.25,w:.5,h:.5,vy:-1};
 const shellContact=c.playerContact(a,p,{...p,y:p.y+1},{tick:17,beforeActor:structuredClone(a)});
 assert.equal(shellContact.harmful,true);assert.equal(shellContact.bounce,false);assert.equal(a.hp,2);
});

test('native ordinary inputs complete the source fitted three-hit lifecycle with one key and unchanged lives',()=>{
 for(const frames of [14,15]){
  const d=transitionProject(frames),saved=JSON.stringify(d),s=nativeSession(d);threeNativeJrStomps(s);
  assert.equal(s.view().lives,5);assert.equal(s.view().p.power,0);assert.equal(s.view().score,4000);assert(!s.view().p.dying);
  assert(s.trace.every(v=>v.lives===5&&!v.p.dying&&v.p.power===0&&v.p.invulnerable===0),'Small survives actual contacts without invulnerability or health injection');
  assert(s.inputs.every(i=>Object.keys(i).every(k=>['x','run','jump'].includes(k))));assert.equal(JSON.stringify(d),saved);
  const jr=s.events.filter(e=>e.type==='smm2-bowser-jr');assert.deepEqual(jr.filter(e=>e.event==='head-stomp').map(e=>e.hp),[2,1]);
  for(const event of ['shell-pursuit-start','recovery-hop','head-revealed'])assert.equal(jr.filter(e=>e.event===event).length,2);
  assert.equal(jr.filter(e=>e.event==='defeated').length,1);assert.equal(s.events.filter(e=>e.event==='enemy-key-released').length,1);
  assert.equal(s.view().items.filter(i=>i.kind==='key').length,1);s.until(v=>v.contraptions.keys===1,{},180);
  assert.equal(s.view().contraptions.keyFollowers.length,1);s.frames(30);assert.equal(s.events.filter(e=>e.event==='enemy-key-released').length,1);
 }
});

test('transition view, render and paused reads are immutable and resume advances exactly one native tick',()=>{
 const s=nativeSession(transitionProject());s.until(v=>v.enemies[0]?.hp===2,{},80);s.stage.pause();
 const first=s.view(),canvas=createCanvas(640,320),ctx=canvas.getContext('2d');
 for(let n=0;n<25;n++){
  const v=s.view(),a=v.enemies[0];bowserJrView(a);bowserJrVisibleFrame(a);drawObject(ctx,a,v.tick,s.doc.rooms[0]);
  assert.deepEqual(a,first.enemies[0]);assert.equal(s.view().tick,first.tick);assert.deepEqual(s.view().enemies[0],first.enemies[0]);
 }
 s.stage.resume();const v=s.step({jump:true});assert.equal(v.tick,first.tick+1);assert.equal(v.enemies[0].smm2BowserJr.phaseAge,1);assert.equal(v.enemies[0].hp,2);
});

test('a released native rebound separates safely, descending recontact can kill, and death freezes the hurt transition',()=>{
 const d=transitionProject(),s=nativeSession(d);s.until(v=>v.enemies[0]?.hp===2,{},80);
 const firstTick=s.view().tick,released=s.step({});assert(!released.p.dying);assert.equal(released.lives,5);assert.equal(released.p.invulnerable,0);assert.equal(released.enemies[0].hp,2);assert.equal(released.enemies[0].smm2BowserJr.phaseAge,1);
 s.until(v=>v.p.dying,{},100);const dead=s.view(),actor=dead.enemies[0];assert.equal(dead.lives,4);assert.equal(actor.hp,2);assert.equal(actor.smm2BowserJr.phase,'hit-transition');assert(dead.tick>firstTick+1);
 assert.equal(s.events.filter(e=>e.event==='head-stomp').length,1,'a descending recontact causes player damage instead of a second HP decrement');
 s.frames(110);assert.deepEqual(s.view().enemies[0],actor);assert.equal(s.view().tick,dead.tick+110,'the death animation runs while the enemy state clock remains frozen');assert.equal(s.view().lives,4);
 assert(s.stage.continueFromCurrent());const fresh=s.view().enemies[0];assert.equal(fresh.hp,3);assert.equal(fresh.smm2BowserJr.phase,'normal');assert.equal(fresh.smm2BowserJr.phaseAge,0);assert.equal(fresh.h,24);assert.equal(fresh.w,24);
 assert.equal(s.view().lives,4);assert.equal(s.doc.rooms[0].smm2Mechanics.bowserJuniors.actors[0].hitTransitionFrames,15);
});

test('physical hit hop stops at a solid ceiling instead of moving only the sprite or passing through terrain',()=>{
 const d=transitionProject(),r=d.rooms[0];r.map.geometry.push({id:'low-roof',x:280,y:240,w:80,h:8,collision:'solid',material:'stone'});
 const {c,a}=controller(d);assert(headContact(c,a).bounce);let touched=false;
 for(let tick=2;tick<=16;tick++){
  c.stepActor(a,{tick,player:{x:500,y:180,w:10,h:14},geometry:r.map.geometry});
  assert(a.y>=248-1e-7,'Jr physical top does not cross the underside at248');
  if(Math.abs(a.y-248)<1e-7){touched=true;assert.equal(a.vy,0);}
 }
 assert(touched);assert.equal(a.hp,2);assert.equal(a.smm2BowserJr.phase,'shell');
});

test('all four native fire textures contact their displayed 12 by12 opaque pixels including outside the 8 by8 motion body',()=>{
 const {c}=controller();let outsideOpaque=0,transparent=0;
 for(let frame=0;frame<4;frame++){
  const shot={id:'junior-fire-unit',type:'bowser-jr-fireball',x:100,y:100,w:8,h:8,vx:1,vy:0,age:frame*6,dead:false},visible=bowserJrFireballVisibleFrame(shot);
  assert.equal(visible.frame,frame);assert.equal(visible.w,12);assert.equal(visible.h,12);assert.equal(visible.x,98);assert.equal(visible.y,98);
  for(let row=0;row<8;row++)for(let col=0;col<8;col++){
   const p={x:visible.x+col*1.5+.5,y:visible.y+row*1.5+.5,w:.25,h:.25,vy:0},result=c.playerContact(shot,p,p,{tick:99}),opaque=parseInt(visible.image.rows[row][col],36)!==0;
   assert.equal(result.handled,true);assert.equal(result.bounce,false);assert.equal(result.harmful,opaque,`displayed fire frame${frame}, cell${col},${row}`);
   if(!opaque)transparent++;else if(p.x+p.w<=shot.x||p.x>=shot.x+shot.w||p.y+p.h<=shot.y||p.y>=shot.y+shot.h)outsideOpaque++;
  }
 }
 assert(outsideOpaque>0,'visible flame protrudes beyond the motion body and still contacts');assert(transparent>0,'transparent margins remain harmless');
});

test('optional tuning remains editable, atomic, undoable and copied by native clipboard and JSON save',()=>{
 const h=new History(bowserJrProject()),room=()=>h.doc.rooms[0];
 h.change(()=>updateSmm2BowserJr(room(),'junior',{hitTransitionFrames:15,hitHopSpeed:3.5}));
 let q=room().smm2Mechanics.bowserJuniors.actors[0];assert.equal(q.hitTransitionFrames,15);assert.equal(q.hitHopSpeed,3.5);
 const saved=JSON.stringify(h.doc);assert.throws(()=>h.change(()=>updateSmm2BowserJr(room(),'junior',{hitTransitionFrames:0})));assert.equal(JSON.stringify(h.doc),saved);
 h.undo();assert.equal(room().smm2Mechanics.bowserJuniors.actors[0].hitTransitionFrames,0);h.redo();
 h.change(()=>cloneSmm2BowserJr(room(),'junior',{id:'jr-copy',dx:40}));const snapshot=captureSmm2ActorLeaves(room(),new Set(['jr-copy']));
 h.change(()=>{const body=structuredClone(room().map.objects.find(a=>a.id==='jr-copy'));body.id='jr-paste';body.x+=40;room().map.objects.push(body);appendCopiedSmm2ActorLeaves(room(),snapshot,new Map([['jr-copy','jr-paste']]));});
 for(const id of ['junior','jr-copy','jr-paste']){q=room().smm2Mechanics.bowserJuniors.actors.find(q=>q.id===id);assert.equal(q.hitTransitionFrames,15);assert.equal(q.hitHopSpeed,3.5);}
 assert.deepEqual(parseProject(JSON.stringify(h.doc)),h.doc);
 const ui=installSimulatedPlayDom();try{
  const parent=ui.document.createElement('aside');ui.document.body.append(parent);const reports=[],panel=mountBowserJrTools({parent,room,change:fn=>h.change(fn),report:s=>reports.push(s)}),get=k=>parent.querySelector('[data-bowser-jr-control="'+k+'"]');
  get('hitTransitionFrames').value='14';get('hitHopSpeed').value='3.25';get('apply').click();q=room().smm2Mechanics.bowserJuniors.actors[0];assert.equal(q.hitTransitionFrames,14);assert.equal(q.hitHopSpeed,3.25);
  get('hitHopSpeed').value='0';get('apply').click();assert.equal(room().smm2Mechanics.bowserJuniors.actors[0].hitHopSpeed,3.25);assert(reports.length);
  h.undo();panel.refresh();assert.equal(get('hitTransitionFrames').value,'15');assert.equal(get('hitHopSpeed').value,'3.5');
 }finally{ui.restore();}
});
