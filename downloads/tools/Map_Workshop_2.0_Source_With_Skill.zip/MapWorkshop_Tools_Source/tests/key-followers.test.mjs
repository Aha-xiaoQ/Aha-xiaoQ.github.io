import test from 'node:test';
import assert from 'node:assert/strict';
import {createKeyFollowers} from '../atlas/editor-key-followers.mjs';
import {createContraptionsCourse} from '../atlas/editor-contraptions.mjs';
const player=(x=100,y=100)=>({x,y,w:10,h:14,facing:1,grounded:true});
const item=(p,id='k')=>({id,x:p.x,y:p.y,w:14,h:14,kind:'key',keyDelay:0,keySpeed:3});
test('single collected key remains visible behind the walking player at the measured temporal lag',()=>{
 const f=createKeyFollowers(),p=player();f.enter('r',p);f.collect('r',item(p),p);
 for(let tick=1;tick<=80;tick++){p.x+=1;f.frame({tick,roomId:'r',player:p});}
 const k=f.view('r')[0];assert.equal(k.kind,'carried-key');assert.equal(k.sourceItemId,'k');assert(Math.abs(p.x+p.w/2-(k.x+k.w/2)-8)<1e-8);assert(k.y+k.h/2>p.y+p.h/2-6&&k.y+k.h/2<p.y+p.h/2-1.5,'small observed vertical floating stays above the body centre');
 const before=f.view('r');f.frame({tick:80,roomId:'r',player:{...p,x:p.x+100}});assert.deepEqual(f.view('r'),before,'duplicate simulation ticks cannot advance presentation');f.view('r')[0].x=-999;assert.deepEqual(f.view('r'),before,'render projection is detached');
});
test('a follower is presentation only and door consumption is bounded before disappearance',()=>{
 const p=player(),f=createKeyFollowers();f.enter('r',p);f.collect('r',item(p),p);for(let tick=1;tick<=20;tick++)f.frame({tick,roomId:'r',player:p});
 const originalPlayer=structuredClone(p),portal={x:140,y:82,w:16,h:32};assert(f.consume(portal));assert.equal(f.view('r')[0].kind,'consuming-key');assert.equal(f.view('r')[0].scale,1.5);
 for(let tick=21;tick<=26;tick++)f.frame({tick,roomId:'r',player:p});const mid=f.view('r')[0];assert(mid.scale>0&&mid.scale<1.5);assert.equal(mid.x,140);assert(mid.y>86);assert.deepEqual(p,originalPlayer,'key cannot displace or protect the player');
 for(let tick=27;tick<=32;tick++)f.frame({tick,roomId:'r',player:p});assert.deepEqual(f.view('r'),[]);assert(!f.consume(portal));
});
test('room entry reseeds only the visual trail and reset removes all presentation',()=>{
 const p=player(),f=createKeyFollowers();f.collect('a',item(p),p);f.enter('b',player(30,40));assert.equal(f.view('a').length,0);assert.equal(f.view('b').length,1);assert.equal(f.view('b')[0].x,27);
 f.reset();assert.deepEqual(f.view('b'),[]);f.frame({tick:1,roomId:'b',player:player()});const q=f.view('b');f.frame({tick:1,roomId:'b',player:player(200)});assert.deepEqual(f.view('b'),q);
});
test('existing actual key pickup and door logic own follower lifecycle without extra inventory rewards',()=>{
 const portal={id:'door',kind:'portal',x:96,y:82,w:16,h:32,targetRoom:'b',targetSpawn:'start'},room={roomId:'a',map:{objects:[portal],geometry:[]},contraptions:{version:1,doors:[{id:'door',pairId:'pair',style:'key'}]}},c=createContraptionsCourse([room]),p=player(),k=item(p);
 c.stepKey('a',k,p);assert(k.dead);assert.equal(c.view('a').keys,1);assert.equal(c.view('a').keyFollowers.length,1);c.stepKey('a',k,p);assert.equal(c.view('a').keys,1);
 assert(c.useDoor('a',portal,p,{upPressed:true}).enter);assert.equal(c.view('a').keys,0);assert.equal(c.view('a').keyFollowers[0].kind,'consuming-key');c.useDoor('a',portal,p,{upPressed:true});assert.equal(c.view('a').keys,0);assert.equal(c.view('a').keyFollowers.length,1);
 c.reset();assert.equal(c.view('a').keys,0);assert.deepEqual(c.view('a').keyFollowers,[]);
});
