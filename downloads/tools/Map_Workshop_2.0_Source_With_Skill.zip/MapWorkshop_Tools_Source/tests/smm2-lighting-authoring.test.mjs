import {test} from 'node:test';
import assert from 'node:assert/strict';
import {blank,History,parseProject,moveSelection,deleteSelection} from '../atlas/editor-model.mjs';
import {setSmm2Lighting,clearSmm2Lighting,setSmm2ObjectLight,clearSmm2ObjectLight,captureSmm2LightingBindings,appendCopiedSmm2LightingBindings,pruneSmm2LightingReferences,cloneSmm2Component,removeSmm2Component} from '../atlas/editor-smm2-authoring.mjs';
import {mountSmm2LightingTools} from '../atlas/editor-smm2-lighting-tools.mjs';
import {createCollection,addLevel,parseCollection,serializeCollection,buildCollection} from '../atlas/editor-collection.mjs';
import {parseSmm2Lighting,resolveSmm2LightSources} from '../atlas/editor-smm2-lighting.mjs';
import {lightingProject} from './fixtures/lighting-native.mjs';
import {character,nativeSession} from './fixtures/shell-coin-native.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';

test('lighting author API uses atomic strict History transactions and import/export leaves map physics intact',()=>{
 const h=new History(lightingProject({enabled:false})),r=()=>h.doc.rooms[0],physical=JSON.stringify(r().map),spec={darkness:.8,playerRadius:48,sources:[]};
 assert.equal(parseSmm2Lighting(r()),null);assert.throws(()=>setSmm2ObjectLight(r(),'moving-enemy',{radius:24}));
 h.change(()=>setSmm2Lighting(r(),spec));assert.equal(r().smm2Mechanics.lighting.playerRadius,48);assert.equal(JSON.stringify(r().map),physical);
 const initial=JSON.stringify(h.doc),undos=h.undoStack.length;
 for(const bad of [undefined,null,{darkness:.9,playerRadius:24},{...spec,darkness:2},{...spec,gravity:0},{...spec,sources:[{targetId:'start',radius:24}]}]){assert.throws(()=>h.change(()=>setSmm2Lighting(r(),bad)));assert.equal(JSON.stringify(h.doc),initial);assert.equal(h.undoStack.length,undos);}
 for(const options of [{radius:24,extra:true},{radius:'24'},{radius:7},{radius:24,offsetX:Infinity}]){assert.throws(()=>h.change(()=>setSmm2ObjectLight(r(),'moving-enemy',options)));assert.equal(JSON.stringify(h.doc),initial);}
 h.change(()=>setSmm2ObjectLight(r(),'moving-enemy',{radius:24}));h.change(()=>setSmm2ObjectLight(r(),'moving-enemy',{radius:32,offsetX:4,offsetY:-4}));assert.equal(r().smm2Mechanics.lighting.sources.length,1);assert.equal(r().smm2Mechanics.lighting.sources[0].radius,32);
 h.undo();assert.equal(r().smm2Mechanics.lighting.sources[0].radius,24);h.redo();assert.equal(r().smm2Mechanics.lighting.sources[0].radius,32);
 h.change(()=>clearSmm2ObjectLight(r(),'moving-enemy'));assert.equal(r().smm2Mechanics.lighting.sources.length,0);h.undo();assert.equal(r().smm2Mechanics.lighting.sources.length,1);
 assert.deepEqual(parseProject(JSON.stringify(h.doc)),h.doc);h.change(()=>clearSmm2Lighting(r()));assert.equal(parseSmm2Lighting(r()),null);h.undo();assert.equal(r().smm2Mechanics.lighting.sources.length,1);h.redo();assert.equal(parseSmm2Lighting(r()),null);
 assert.equal(JSON.stringify(r().map),physical);
});

test('lighting refuses implicit SMM2 mode migration, disables a legacy room panel and keeps an existing empty root/player mode through enable/clear',()=>{
 const ui=installSimulatedPlayDom();try{
  const legacy=new History(blank('Neutral legacy lighting boundary',640,288)),room=()=>legacy.doc.rooms[0],before=JSON.stringify(legacy.doc),spec={darkness:.9,playerRadius:40,sources:[]},legacyPlayer=nativeSession(legacy.doc).view().p;
  assert.equal(legacyPlayer.smm2Player,undefined);assert.throws(()=>legacy.change(()=>setSmm2Lighting(room(),spec)),/existing SMM2/);assert.equal(JSON.stringify(legacy.doc),before);assert.equal(legacy.undoStack.length,0);
  clearSmm2Lighting(room());assert.equal(JSON.stringify(legacy.doc),before);assert.equal(legacy.change(()=>clearSmm2Lighting(room())),false);assert.equal(legacy.undoStack.length,0);assert.equal(nativeSession(legacy.doc).view().p.smm2Player,undefined);
  const parent=ui.document.createElement('aside'),reports=[],panel=mountSmm2LightingTools({parent,room,change:fn=>legacy.change(fn),report:q=>reports.push(q)}),enabled=parent.querySelector('[data-lighting="enabled"]');assert.equal(enabled.disabled,true);assert.equal(enabled.checked,false);assert.match(parent.querySelector('[data-lighting="status"]').textContent,/先应用 SMM2/);
  enabled.checked=true;enabled.dispatchEvent({type:'change'});assert.equal(JSON.stringify(legacy.doc),before);assert.equal(legacy.undoStack.length,0);assert(reports.some(q=>q.includes('existing SMM2')));assert.equal(enabled.checked,false);assert.equal(enabled.disabled,true);
  const doc=blank('Neutral explicit SMM2 lighting boundary',640,288);doc.rooms[0].smm2Mechanics={version:1};const current=new History(doc),r=()=>current.doc.rooms[0],empty=JSON.stringify(current.doc),player=nativeSession(current.doc).view().p;assert.equal(player.smm2Player,true);
  assert.equal(current.change(()=>clearSmm2Lighting(r())),false);assert.equal(JSON.stringify(current.doc),empty);assert.equal(current.undoStack.length,0);current.change(()=>setSmm2Lighting(r(),spec));assert.deepEqual(nativeSession(current.doc).view().p,player);current.change(()=>clearSmm2Lighting(r()));assert.deepEqual(r().smm2Mechanics,{version:1});assert.equal(JSON.stringify(current.doc),empty);assert.deepEqual(nativeSession(current.doc).view().p,player);
  current.undo();assert(r().smm2Mechanics.lighting);assert.equal(nativeSession(current.doc).view().p.smm2Player,true);current.redo();assert.deepEqual(r().smm2Mechanics,{version:1});assert.equal(nativeSession(current.doc).view().p.smm2Player,true);panel.refresh();assert.equal(enabled.disabled,true);
 }finally{ui.restore();}
});

test('native actor/geometry/arrow copying remaps stable lights, moving preserves bindings and delete prunes with undo/redo',()=>{
 const h=new History(lightingProject()),r=()=>h.doc.rooms[0],ids=new Set(['lamp-coin','moving-lift','fixed-arrow']),snapshot=captureSmm2LightingBindings(r(),ids),idMap=new Map([...ids].map(id=>[id,id+'-copy'])),beforeLighting=structuredClone(r().smm2Mechanics.lighting);
 assert.deepEqual(snapshot.sources.map(q=>q.targetId),['lamp-coin','moving-lift','fixed-arrow']);assert(!Object.hasOwn(snapshot,'darkness'));assert(!Object.hasOwn(snapshot,'playerRadius'));
 h.change(()=>{
  for(const old of ids){const collection=r().map.objects.some(q=>q.id===old)?r().map.objects:r().map.geometry.some(q=>q.id===old)?r().map.geometry:r().markers,body=collection.find(q=>q.id===old);collection.push({...structuredClone(body),id:idMap.get(old),x:body.x+16});}
  appendCopiedSmm2LightingBindings(r(),snapshot,idMap);
 });
 const spec=r().smm2Mechanics.lighting;assert.equal(spec.sources.length,beforeLighting.sources.length+3);assert.equal(spec.darkness,beforeLighting.darkness);assert.equal(spec.playerRadius,beforeLighting.playerRadius);assert.deepEqual(spec.sources.find(q=>q.targetId==='fixed-arrow-copy'),{targetId:'fixed-arrow-copy',radius:24,offsetX:8,offsetY:8});
 h.change(()=>moveSelection(r(),'objects',new Set(['lamp-coin-copy']),16,0));assert.equal(r().smm2Mechanics.lighting.sources.find(q=>q.targetId==='lamp-coin-copy').radius,24);const preview=resolveSmm2LightSources(r(),null,{preview:true}).find(q=>q.targetId==='lamp-coin-copy');assert.equal(preview.x,164);
 h.change(()=>{const before=structuredClone(r());deleteSelection(r(),'objects',new Set(['lamp-coin-copy']));deleteSelection(r(),'geometry',new Set(['moving-lift-copy']));r().markers=r().markers.filter(q=>q.id!=='fixed-arrow-copy');pruneSmm2LightingReferences(r(),before);});assert.equal(r().smm2Mechanics.lighting.sources.length,beforeLighting.sources.length);h.undo();assert.equal(r().smm2Mechanics.lighting.sources.length,beforeLighting.sources.length+3);h.redo();assert.equal(r().smm2Mechanics.lighting.sources.length,beforeLighting.sources.length);
 assert.deepEqual(parseProject(JSON.stringify(h.doc)),h.doc);
 const disabled=lightingProject({enabled:false}).rooms[0];assert.throws(()=>appendCopiedSmm2LightingBindings(disabled,snapshot,idMap));assert.equal(parseSmm2Lighting(disabled),null);
 const before=JSON.stringify(r());assert.throws(()=>appendCopiedSmm2LightingBindings(r(),snapshot,new Map()));assert.equal(JSON.stringify(r()),before);
});

test('delete pruning keeps freshly introduced invalid references visible to strict importer',()=>{
 const r=lightingProject().rooms[0],before=structuredClone(r);r.map.objects=r.map.objects.filter(q=>q.id!=='lamp-coin');r.smm2Mechanics.lighting.sources.push({targetId:'never-existed',radius:24});pruneSmm2LightingReferences(r,before);assert(!r.smm2Mechanics.lighting.sources.some(q=>q.targetId==='lamp-coin'));assert(r.smm2Mechanics.lighting.sources.some(q=>q.targetId==='never-existed'));const d=lightingProject();d.rooms[0]=r;assert.throws(()=>parseProject(JSON.stringify(d)));
});

test('existing POW component clone/remove API copies and prunes its native light atomically with History',()=>{
 const h=new History(lightingProject()),r=()=>h.doc.rooms[0];h.change(()=>cloneSmm2Component(r(),'falling-pow',{id:'pow-copy',dx:16}));assert(r().map.objects.some(q=>q.id==='pow-copy'));assert(r().smm2Mechanics.powBlocks.some(q=>q.id==='pow-copy'));assert.deepEqual(r().smm2Mechanics.lighting.sources.find(q=>q.targetId==='pow-copy'),{targetId:'pow-copy',radius:40});
 h.change(()=>removeSmm2Component(r(),'pow-copy'));assert(!r().map.objects.some(q=>q.id==='pow-copy'));assert(!r().smm2Mechanics.lighting.sources.some(q=>q.targetId==='pow-copy'));h.undo();assert(r().smm2Mechanics.lighting.sources.some(q=>q.targetId==='pow-copy'));h.redo();assert(!r().smm2Mechanics.lighting.sources.some(q=>q.targetId==='pow-copy'));assert.deepEqual(parseProject(JSON.stringify(h.doc)),h.doc);
 h.change(()=>deleteSelection(r(),'objects',new Set(['lamp-coin'])));assert(!r().smm2Mechanics.lighting.sources.some(q=>q.targetId==='lamp-coin'));h.undo();assert(r().smm2Mechanics.lighting.sources.some(q=>q.targetId==='lamp-coin'));
});

test('actual night author panel enables, validates, binds, refreshes History and clears without changing physics',()=>{
 const ui=installSimulatedPlayDom();try{
  const h=new History(lightingProject({enabled:false})),r=()=>h.doc.rooms[0],physical=JSON.stringify(r().map),parent=ui.document.createElement('aside'),reports=[],selection=new Set(['moving-enemy']),panel=mountSmm2LightingTools({parent,room:r,selected:()=>selection,change:fn=>h.change(fn),report:q=>reports.push(q)}),get=id=>parent.querySelector('[data-lighting="'+id+'"]');
  assert.equal(get('enabled').checked,false);assert.equal(get('bind').disabled,true);get('enabled').checked=true;get('enabled').dispatchEvent({type:'change'});assert(parseSmm2Lighting(r()));assert.equal(get('target').value,'moving-enemy');
  get('darkness').value='.85';get('playerRadius').value='40';get('softness').value='.2';get('apply').click();assert.equal(r().smm2Mechanics.lighting.darkness,.85);
  get('radius').value='32';get('offsetX').value='5';get('offsetY').value='-3';get('bind').click();assert.deepEqual(r().smm2Mechanics.lighting.sources,[{targetId:'moving-enemy',radius:32,offsetX:5,offsetY:-3}]);
  const enabled=JSON.stringify(r().smm2Mechanics.lighting),enabledUndos=h.undoStack.length;get('enabled').checked=true;get('enabled').dispatchEvent({type:'change'});assert.equal(JSON.stringify(r().smm2Mechanics.lighting),enabled);assert.equal(h.undoStack.length,enabledUndos);
  h.undo();panel.refresh();assert.equal(get('remove').disabled,true);h.redo();panel.refresh();assert.equal(Number(get('radius').value),32);
  const before=JSON.stringify(h.doc),undos=h.undoStack.length;get('radius').value='7';get('bind').click();assert.equal(JSON.stringify(h.doc),before);assert.equal(h.undoStack.length,undos);assert(reports.length);
  selection.clear();selection.add('fixed-arrow');panel.refresh();assert.equal(get('target').value,'fixed-arrow');get('radius').value='24';get('offsetX').value='8';get('offsetY').value='8';get('bind').click();assert(r().smm2Mechanics.lighting.sources.some(q=>q.targetId==='fixed-arrow'));get('remove').click();assert(!r().smm2Mechanics.lighting.sources.some(q=>q.targetId==='fixed-arrow'));
  get('enabled').checked=false;get('enabled').dispatchEvent({type:'change'});assert.equal(parseSmm2Lighting(r()),null);h.undo();panel.refresh();assert.equal(get('enabled').checked,true);h.redo();panel.refresh();assert.equal(get('enabled').checked,false);assert.equal(JSON.stringify(r().map),physical);
 }finally{ui.restore();}
});

test('qcollection import/export and real compiler preserve appearance lighting in matching visual rooms',()=>{
 const d=lightingProject(),c=addLevel(createCollection('Neutral illumination collection'),d,{id:'night-lights'}),again=parseCollection(serializeCollection(c)),built=buildCollection(again,character,{includePending:true});
 assert.deepEqual(again.levels[0].project.rooms[0].smm2Mechanics.lighting,d.rooms[0].smm2Mechanics.lighting);assert.deepEqual(built.levels[0].rooms[0].smm2Mechanics.lighting,d.rooms[0].smm2Mechanics.lighting);assert(!Object.hasOwn(built.levels[0].pack.maps[0],'smm2Mechanics'));
 assert(built.requiredCapabilities.includes('explicit-night-lighting-v1'));assert(built.levels[0].requiredCapabilities.includes('explicit-night-lighting-v1'));
});
