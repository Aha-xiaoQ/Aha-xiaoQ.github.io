import test from 'node:test';
import assert from 'node:assert/strict';
import {createCanvas} from '@napi-rs/canvas';
import {createSkyShooter,validateSkyShooterRoom} from '../atlas/editor-sky-shooter.mjs';
import {drawSkyShooter,drawSkyShooterWeapon,SKY_SHOOTER_ART_PROVENANCE} from '../atlas/editor-sky-shooter-art.mjs';
import {skyShooterProject,skyShooterBodies} from './fixtures/sky-shooter.mjs';
const passenger=(x=198,y=208)=>({x,y,w:10,h:14,vx:0,vy:0,lakituCloudId:'ride',dead:false,power:0});
function setup({accept=true}={}){const r=skyShooterProject().rooms[0],enemies=skyShooterBodies(r),events=[],hits=[],hurt=[],geometry=structuredClone(r.map.geometry);const c=createSkyShooter(r,{emit:(type,data)=>events.push({type,...data}),defeatEnemy:(e,hit)=>{hits.push(hit);if(accept)e.dead=true;return accept;},hurtPlayer:q=>hurt.push(q)});let tick=0;return {r,c,enemies,geometry,events,hits,hurt,step(p,input={}){return c.step({tick:++tick,player:p,input,enemies,geometry});}};}
test('opt-in original leaf rejects unknown versions/fields, missing tuning, invalid references and unbounded projectiles',()=>{
 assert.equal(createSkyShooter({map:{}}),null);assert(validateSkyShooterRoom(skyShooterProject().rooms[0]));
 const invalid=[s=>s.version=2,s=>s.cloudId='absent',s=>s.rewardId='drone-a',s=>s.gateIds=['floor','floor'],s=>s.gateIds=[],s=>s.drones[0].id='start',s=>s.drones[1].id='drone-a',s=>s.drones[2].wave=3,s=>s.drones[0].x=-1,s=>s.drones[0].phaseFrames=.5,s=>s.weapon.maxShots=13,s=>s.weapon.speed=17,s=>s.attack.maxMissiles=7,s=>s.attack.telegraphFrames=35,s=>s.attack.intervalFrames=20,s=>s.formation.periodFrames=59,s=>s.activation.w=10000,s=>s.invulnerable=true];
 for(const change of invalid){const r=skyShooterProject().rooms[0];change(r.smm2Mechanics.skyShooter);assert.throws(()=>validateSkyShooterRoom(r));}
 for(const group of ['weapon','formation','attack','activation'])for(const key of Object.keys(skyShooterProject().rooms[0].smm2Mechanics.skyShooter[group])){const r=skyShooterProject().rooms[0];delete r.smm2Mechanics.skyShooter[group][key];assert.throws(()=>validateSkyShooterRoom(r),/Missing/);}
 const symbol=skyShooterProject().rooms[0];symbol.smm2Mechanics.skyShooter[Symbol('alias')]=1;assert.throws(()=>validateSkyShooterRoom(symbol),/Unknown/);
});
test('boarding identity and a real arena crossing start combat, with no passenger or Cloud physics mutation',()=>{
 const s=setup(),p=passenger(35,338),before=structuredClone(p);for(let n=0;n<100;n++)s.step(p,{run:true});assert(!s.c.view().started);assert.deepEqual(p,before);assert.equal(s.hits.length,0);assert(s.geometry.find(q=>q.id==='reward-gate').hidden!==true);
 delete p.lakituCloudId;p.x=198;p.y=208;for(let n=0;n<30;n++)s.step(p,{attack:true});assert(!s.c.view().started);p.lakituCloudId='ride';s.step(p);assert(s.c.view().started);assert.equal(s.events.filter(q=>q.event==='combat-start').length,1);assert(s.c.ownsActor(s.enemies[2]));assert(!s.c.isActiveActor(s.enemies[2]));
});
test('shots must travel and intersect a real drone before requesting native defeat',()=>{
 const s=setup(),p=passenger();s.step(p,{run:true});assert.equal(s.hits.length,0);assert.equal(s.c.view().shots.length,1);assert(s.c.view().shots[0].y>136);
 for(let n=0;n<15&&s.hits.length===0;n++)s.step(p,{run:true});assert.equal(s.hits.length,1);assert.equal(s.hits[0].kind,'sky-shot');assert.equal(s.c.view().defeated,1);assert(s.enemies[0].dead);assert(!s.enemies[1].dead);assert.equal(p.power,0);assert(!s.c.view().cleared);assert(!s.geometry.find(q=>q.id==='reward-gate').hidden);
 const contact=s.events.find(q=>q.event==='shot-contact');assert(contact.nativeDefeated);assert.equal(contact.actorId,'drone-a');
});
test('a rejected host hit, missing actor or fabricated dead object cannot create defeat progress',()=>{
 const s=setup({accept:false}),p=passenger();for(let n=0;n<30;n++)s.step(p,{run:true});assert(s.hits.length);assert.equal(s.c.view().defeated,0);assert(!s.c.defeatedActor({...s.enemies[1],dead:true}));assert(!s.c.defeatedActor({id:'unbound',dead:true}));assert(!s.c.view().cleared);
});
test('solid terrain stops a travelling shot before a drone behind it and projectile counts stay bounded',()=>{
 const s=setup(),p=passenger();s.geometry.push({id:'shield',x:192,y:176,w:48,h:8,collision:'solid'});for(let n=0;n<45;n++)s.step(p,{run:true});assert.equal(s.hits.length,0);assert(s.events.some(q=>q.event==='shot-blocked'&&q.solidId==='shield'));assert(s.c.view().shots.length<=s.r.smm2Mechanics.skyShooter.weapon.maxShots);
});
test('all required real native defeats, across both waves, open only the gate and never collect or award Pink',()=>{
 const s=setup(),p=passenger();s.step(p);for(const actor of s.enemies.slice(0,2)){actor.dead=true;assert(s.c.defeatedActor(actor));assert(!s.c.defeatedActor(actor));}s.step(p);assert.equal(s.c.view().wave,1);assert(s.c.view().nextWaveTick!==null);assert(!s.c.view().cleared);for(let n=0;n<24;n++)s.step(p);assert.equal(s.c.view().wave,2);assert(s.c.isActiveActor(s.enemies[2]));s.enemies[2].dead=true;s.step(p);assert(s.c.view().cleared);assert(s.geometry.find(q=>q.id==='reward-gate').hidden);assert.equal(s.c.view().defeated,3);assert.equal(s.r.map.objects.find(q=>q.id==='reward-pink').kind,'coin');assert(!Object.hasOwn(p,'coins'));assert.equal(s.events.filter(q=>q.event==='gate-open').length,1);
});
test('waiting, fire held at a wrong lane and elapsed time never defeat actors or open the gate',()=>{
 const s=setup(),p=passenger(180,288);for(let n=0;n<1800;n++)s.step(p,{run:true});assert.equal(s.c.view().defeated,0);assert(!s.c.view().cleared);assert(!s.geometry.find(q=>q.id==='reward-gate').hidden);assert(s.events.some(q=>q.event==='dive-launch'));assert(s.hurt.length>0,'a stationary wrong lane has actual missile contact');assert(s.c.view().missiles.length<=2);
});
test('attacks warn for 48 full authored ticks, latch a visible target, and give movement time before collision',()=>{
 const s=setup(),p=passenger(180,288);s.step(p);let warning;for(let n=0;n<80;n++){s.step(p);if(s.c.view().warnings.length){warning=s.c.view().warnings[0];break;}}assert(warning);assert.equal(warning.kind,'dive');assert.equal(warning.remainingFrames,48);assert.equal(s.events.filter(q=>q.event==='dive-launch').length,0);
 p.x=270;for(let n=0;n<47;n++)s.step(p);assert.equal(s.events.filter(q=>q.event==='dive-launch').length,0);s.step(p);assert.equal(s.events.filter(q=>q.event==='dive-launch').length,1);assert.deepEqual(s.events.find(q=>q.event==='dive-launch').target,warning.target);assert.equal(s.hurt.length,0);
});
test('duplicate ticks and pure views are stable; reset restores an exact initial controller without modifying host state',()=>{
 const s=setup(),initial=s.c.view(),p=passenger();for(let n=0;n<20;n++)s.step(p,{run:true});const saved=s.c.view(),actorState=structuredClone(s.enemies),geometry=structuredClone(s.geometry),pass=structuredClone(p);saved.shots[0].x=-999;const view=s.c.view();s.c.step({tick:20,player:p,input:{run:true},enemies:s.enemies,geometry:s.geometry});assert.deepEqual(s.c.view(),view);assert.deepEqual(s.enemies,actorState);s.c.reset();assert.deepEqual(s.c.view(),initial);assert.deepEqual(p,pass);assert.deepEqual(s.geometry,geometry);
});
test('native source Goomba pixels, authored flight packs and visible hand-gun render without changing collision bodies',()=>{
 const s=setup(),p=passenger();s.step(p,{run:true});const canvas=createCanvas(576,384),ctx=canvas.getContext('2d'),room={...s.r,skyShooterView:s.c.view()},before=structuredClone(s.enemies);assert(drawSkyShooter(ctx,room,1));const pack=canvas.toBuffer('image/png');assert(drawSkyShooterWeapon(ctx,room,1));assert.notDeepEqual(canvas.toBuffer('image/png'),pack);assert.deepEqual(s.enemies,before);assert(SKY_SHOOTER_ART_PROVENANCE.droneBody.includes('unchanged native pixels'));assert.equal(SKY_SHOOTER_ART_PROVENANCE.originalAnimationCalibration,false);
});
