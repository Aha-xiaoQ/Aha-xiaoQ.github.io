import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
import {offlineFile} from '../atlas/editor-offline.mjs';
import {createCollection,addLevel,approveLevel,buildCollection,requiredCollectionCapabilities} from '../atlas/editor-collection.mjs';
import {guardProject} from './fixtures/chain-chomp-neutral.mjs';
import {nativeSession,character} from './fixtures/shell-coin-native.mjs';

for(const collection of [false,true])test(`actual embedded ${collection?'collection':'single'} guard preserves native cue crossing, rush death, pause/reset, shared pixels and moving light without network`,async t=>{
 const project=guardProject(),session=nativeSession(project),root=new URL('../atlas/',import.meta.url);
 assert(requiredCollectionCapabilities(project).includes('authored-chain-chomp-guard-v1'));
 const built=collection?buildCollection(approveLevel(addLevel(createCollection('Neutral authored tethered guard'),project,{id:'chain-guard-fixture'}),'chain-guard-fixture','Neutral fixture approval for this automated offline acceptance only'),character):null;
 if(built)assert(built.requiredCapabilities.includes('authored-chain-chomp-guard-v1'));
 const html=await offlineFile(session.pack,session.doc.rooms,p=>fs.promises.readFile(new URL(p,root),'utf8'),p=>fs.promises.readFile(new URL('assets/classic-audio/'+p,root)),()=>{},built?{collection:built}:{});
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'Chain Chomp Offline With Spaces '));
 try{
  const htmlPath=path.join(dir,'Original guard player.html');fs.writeFileSync(htmlPath,html);
  const result=spawnSync(process.execPath,['--experimental-vm-modules',fileURLToPath(new URL('./fixtures/chain-chomp-offline-check.mjs',import.meta.url)),htmlPath,...(collection?['collection']:[])],{encoding:'utf8',timeout:45000,maxBuffer:1024*1024});
  assert.equal(result.status,0,result.stderr||result.stdout||String(result.error));const report=JSON.parse(result.stdout);
  for(const key of ['actualEmbeddedStageExecuted','actualEmbeddedMotorExecuted','actualEmbeddedSharedArtExecuted','everyNativeTickAndEventMatches','authoredGuardCapability','liveLightFollowsMovingHead','pauseFreeze','deathFreeze','continueReset'])assert.equal(report[key],true,key);
  assert.equal(report.collection,collection);assert.equal(report.deathFrame,39);assert.equal(report.networkRequests,0);assert(report.frames>600);assert(report.rasters>20);assert(report.movingLightFrames>30);
  t.diagnostic(JSON.stringify(report));
 }finally{fs.rmSync(dir,{recursive:true,force:true});}
});
