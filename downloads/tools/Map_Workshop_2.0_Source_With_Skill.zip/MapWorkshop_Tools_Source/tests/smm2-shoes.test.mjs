import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createSmm2Shoes,validateSmm2ShoesRoom,withSmm2Shoes,smm2ShoeBlockKind,SMM2_SHOE_TUNING} from '../atlas/editor-smm2-shoes.mjs';
import {createPlatformMotor} from '../atlas/editor-mario-motor.mjs';
import {createSMM2Terrain} from '../atlas/editor-smm2-terrain.mjs';
import {drawSmm2Shoe} from '../atlas/editor-smm2-shoe-art.mjs';

const character={capabilities:['jump'],motion:{width:10,height:14,maxHealth:1}};
const source=extra=>({id:'shoe',kind:'walker',x:120,y:144,w:16,h:16,...extra});
const spec=extra=>({id:'shoe',kind:'shoe',size:'small',winged:false,occupant:'goomba',...extra});
const room=(q=spec(),a=source())=>({roomId:'shoe-fixture',map:{width:512,height:384,geometry:[],objects:a?[a]:[]},smm2Mechanics:{version:1,shoes:q?[q]:[]}});
const floor={id:'floor',x:0,y:184,w:512,h:16,collision:'solid',material:'ground'};
const player=(extra={})=>({...createPlatformMotor().create(character,{x:123,y:100}),id:'player',kind:'player',...extra});
function harness({q=spec(),a=source(),p=player(),solids=[floor],targets=[],options={}}={}){
 const r=room(q,a),actor={...a,vx:0,vy:0,dead:false,grounded:false,support:null},events=[],shoes=createSmm2Shoes(r,{...options,emit:(kind,data)=>events.push({kind,...data})}),motor=createPlatformMotor();shoes.decorateActor(actor);let tick=0;
 return{r,actor,p,shoes,motor,events,targets,solids,stomp(){shoes.beginFrame({tick:++tick,actors:[actor,...targets],player:p});const before={...p};p.y=actor.y-(actor.smm2Shoe.occupancy==='npc'?(q.tuning?.npcHeadHeight??8):0)-p.h+4;return shoes.afterPlayer(p,before,{tick,actors:[actor],geometry:solids});},acquire(){const first=this.stomp();if(!first.defeated.length)return first;shoes.beginFrame({tick:++tick,actors:[actor,...targets],player:p});const before={...p,y:actor.y-p.h-2};p.y=actor.y-p.h+2;const boarded=shoes.afterPlayer(p,before,{tick,actors:[actor],geometry:solids});return{...boarded,defeated:[...first.defeated,...boarded.defeated]};},step(input={}){shoes.beginFrame({tick:++tick,actors:[actor,...targets],player:p});shoes.stepActor(actor,{tick,geometry:solids,targets});const before={...p},out=shoes.stepPlayer(p,input,character,{width:512,solids},{tick,motor,targets});if(out===null)motor.step(p,input,character,{width:512,solids});const contacts=shoes.afterPlayer(p,before,{tick,actors:[actor],geometry:solids}),effects=shoes.stepEffects({tick,geometry:solids,targets});return{tick,before,out,contacts,effects};},get tick(){return tick;}};
}

test('optional leaf and wrapper preserve exact native object, movement, jump and author data',()=>{
 const motor=createPlatformMotor();assert.equal(createSmm2Shoes({map:{width:512,height:384,objects:[]}}),null);assert.equal(createSmm2Shoes(room(null,null)),null);assert.equal(withSmm2Shoes(motor,null),motor);
 const r=room(),original=JSON.stringify(r),shoes=createSmm2Shoes(r),wrapped=withSmm2Shoes(motor,shoes),a=player({x:40,y:170,grounded:true,support:'floor'}),b={...a};
 for(let tick=1;tick<=80;tick++){const input={x:tick<45?1:-1,run:true,jumpPressed:tick===5,jump:tick<20};shoes.beginFrame({tick,actors:[],player:a});assert.deepEqual(wrapped.step(a,input,character,{width:512,solids:[floor]}),motor.step(b,input,character,{width:512,solids:[floor]}));assert.deepEqual(a,b);}
 assert.equal(JSON.stringify(r),original);
});

test('closed shoe schema rejects scripts, malformed variants, unsafe IDs, aliases and invalid tuning',()=>{
 validateSmm2ShoesRoom(room());validateSmm2ShoesRoom({...room(),smm2Mechanics:{version:1,shoes:[spec()],unknownSibling:true}});
 for(const q of [spec({kind:'clown-car'}),spec({size:'huge'}),spec({winged:1}),spec({occupant:'piranha'}),spec({activateAt:300}),spec({id:'constructor'}),spec({tuning:{npcHopFrames:1.5}}),spec({tuning:{gravity:NaN}}),spec({tuning:{groundPoundSpeed:0}}),spec({tuning:{flutterFrames:-1}}),spec({tuning:{seatInset:17}}),spec({tuning:{script:[]}}),spec({tuning:{blastRange:Infinity}}),spec({tuning:{blastSpeed:0}})])assert.throws(()=>validateSmm2ShoesRoom(room(q)));
 assert.throws(()=>validateSmm2ShoesRoom(room(spec(),source({kind:'hazard'}))),/native walker/);
 assert.throws(()=>validateSmm2ShoesRoom(room(spec(),source({x:500}))),/inside/);
 assert.throws(()=>validateSmm2ShoesRoom({...room(),smm2Mechanics:{version:1,shoes:[spec(),spec()]}}),/Duplicate/);
 assert.throws(()=>validateSmm2ShoesRoom({...room(),map:{...room().map,geometry:[{id:'shoe'}]}}),/native walker/);
 assert.throws(()=>validateSmm2ShoesRoom({...room(),smm2Mechanics:JSON.parse('{"version":1,"__proto__":{},"shoes":[]}')}),/unsafe/);
});

test('descending Goomba-head stomp releases an empty live foot; later descent genuinely boards it',()=>{
 const h=harness(),released=h.stomp();assert.deepEqual(released.boarded,[]);assert.equal(released.defeated[0].action,'defeat-occupant');assert.equal(released.defeated[0].occupantOnly,true);assert.equal(released.defeated[0].actorId,'shoe');assert.equal(h.actor.dead,false);assert.equal(h.actor.smm2Shoe.occupancy,'empty');assert.equal(h.shoes.ownsPlayer(),false);assert.ok(h.p.vy<0);assert.equal(h.p.shoeId,undefined);
 h.shoes.beginFrame({tick:2,actors:[h.actor],player:h.p});const prior={...h.p,y:h.actor.y-h.p.h-2};h.p.y=h.actor.y-h.p.h+2;const result=h.shoes.afterPlayer(h.p,prior,{tick:2,actors:[h.actor]});assert.deepEqual(result.boarded,['shoe']);assert.deepEqual(result.defeated,[]);assert.equal(h.actor.smm2Shoe.occupancy,'player');assert.equal(h.shoes.ownsPlayer(h.p),true);assert.equal(h.p.shoeId,'shoe');assert.equal(h.p.y+h.p.h,h.actor.y+4);
 const before=h.shoes.view(),events=h.events.length;assert.deepEqual(h.shoes.afterPlayer(h.p,h.p,{tick:2,actors:[h.actor]}),{boarded:[],defeated:[],breaks:[]});assert.deepEqual(h.shoes.view(),before);assert.equal(h.events.length,events);
});

test('empty shoe boarding is a real descending contact and awards no Goomba defeat',()=>{
 const h=harness({q:spec({occupant:'empty'})});assert.deepEqual(h.acquire().defeated,[]);assert.equal(h.shoes.ownsPlayer(),true);assert.equal(h.actor.dead,false);
});

test('side, rising, remote, underneath, blocked and other-vehicle contacts cannot acquire shoes',()=>{
 for(const [p,before,geometry]of [[player({x:110,y:142}),player({x:102,y:142}),[]],[player({y:123}),player({y:132}),[]],[player({x:300,y:138}),player({x:300,y:120}),[]],[player({y:154}),player({y:148}),[]],[player({y:132}),player({y:110}),[{id:'intervening',x:96,y:126,w:80,h:4,collision:'oneway'}]],[player({y:132,vehicleId:'other'}),player({y:110}),[]]]){
  const h=harness({p,solids:[]});h.shoes.beginFrame({tick:1,actors:[h.actor],player:p});assert.deepEqual(h.shoes.afterPlayer(p,before,{tick:1,actors:[h.actor],geometry}).boarded,[]);assert.equal(h.actor.smm2Shoe.occupancy,'npc');
 }
});

test('native jump stays mounted, moves real shoe feet, and preserves Fire/body/helmet',()=>{
 const h=harness({p:player({power:2,helmet:'buzzy',h:28}),a:source({y:168})});h.acquire();Object.assign(h.actor,{grounded:true,support:'floor',vy:0});Object.assign(h.p,{grounded:true,support:'floor',vy:0});const y=h.actor.y,x=h.actor.x,q=h.step({x:1,run:true,jumpPressed:true,jump:true});
 assert.deepEqual(q.out,['jump']);assert.equal(h.shoes.ownsPlayer(),true);assert.ok(h.actor.y<y);assert.ok(h.actor.x>x);assert.equal(h.p.power,2);assert.equal(h.p.helmet,'buzzy');assert.equal(h.p.h,28);assert.equal(h.p.w,10);assert.equal(h.p.crouch,false);
 const once=h.shoes.view(),pose={...h.p},events=h.events.length;assert.deepEqual(h.shoes.stepPlayer(h.p,{jumpPressed:true},character,{width:512,solids:[floor]},{tick:q.tick,motor:h.motor}),[]);assert.deepEqual(h.p,pose);assert.deepEqual(h.shoes.view(),once);assert.equal(h.events.length,events);
});

test('R/dismount command detaches once and a short lock prevents immediate accidental remount',()=>{
 const h=harness();h.acquire();const q=h.step({dismountPressed:true});assert.equal(h.shoes.ownsPlayer(),false);assert.equal(h.actor.smm2Shoe.occupancy,'empty');assert.equal(h.p.shoeId,undefined);assert.equal(h.p.vehicleId,undefined);assert.ok(h.p.vy<0);assert.equal(h.actor.dead,false);assert.equal(h.shoes.dismount(h.p),false);
 const before=player({y:100});h.p.y=136;assert.deepEqual(h.shoes.afterPlayer(h.p,before,{tick:q.tick,actors:[h.actor]}).boarded,[]);assert.equal(h.events.filter(e=>e.event==='dismount').length,1);
});

test('NPC foot actor falls, hops from real floor, bounces from a wall, and empty actor stops hopping',()=>{
 const h=harness({p:player({x:400,y:100}),q:spec({tuning:{npcSpeed:1,npcHopFrames:3,npcHopSpeed:2}}),a:source({x:40,y:144})}),wall={id:'wall',x:16,y:0,w:16,h:184,collision:'solid'};h.solids.push(wall);
 let landed=false,hopped=false,turned=false;for(let i=0;i<60;i++){h.step();landed||=h.actor.grounded;hopped||=h.actor.vy<0;turned||=h.actor.vx>0;assert.ok(h.actor.x>=32);assert.ok(h.actor.y+h.actor.h<=184+1e-6);}assert.ok(landed&&hopped&&turned);
 const before=h.shoes.view();h.shoes.stepActor(h.actor,{tick:h.tick,geometry:h.solids});assert.deepEqual(h.shoes.view(),before);
 const empty=harness({q:spec({occupant:'empty',tuning:{npcHopFrames:1}}),a:source({y:168}),p:player({x:400})});for(let i=0;i<10;i++)empty.step();assert.equal(empty.actor.grounded,true);assert.equal(empty.actor.vy,0);assert.equal(empty.actor.smm2Shoe.occupancy,'empty');
});

test('Muncher/spike support exists only inside shoe geometry and leaves native bare Mario unsafe',()=>{
 const m={id:'muncher',type:'muncher',x:96,y:168,w:80,h:16},spikes={id:'spikes',kind:'hazard',x:200,y:168,w:80,h:16,collision:'hazard',spikeTrap:true},h=harness({targets:[m],solids:[spikes,floor]});
 const base=[spikes,floor],bare=player({x:110,y:150});assert.equal(h.shoes.geometry(base,[m],{actor:bare}),base);assert.deepEqual(base,[spikes,floor]);assert.equal(h.shoes.playerEnemyContact(bare,bare,m,{tick:0}).protected,false);
 h.acquire();let landed=false;for(let i=0;i<80;i++){const q=h.step();if(h.p.grounded&&h.p.support===m.id){landed=true;const decision=h.shoes.playerEnemyContact(h.p,q.before,m,{tick:q.tick});assert.equal(decision.protected,true);assert.equal(decision.action,null);break;}}
 assert.ok(landed);assert.equal(m.dead,undefined);assert.equal(h.actor.y+h.actor.h,m.y);assert.equal(h.p.y+h.p.h,h.actor.y+4);
});

test('Small Shoe genuinely approaches a raised Muncher, jumps clear of its side and stands on its top',()=>{
 const m={id:'step-muncher',type:'muncher',x:160,y:152,w:24,h:16},step={id:'raised-ground',x:160,y:168,w:128,h:16,collision:'solid',material:'ground'},h=harness({q:spec({occupant:'empty'}),a:source({x:136,y:168}),p:player({x:139}),targets:[m],solids:[floor,step]});h.acquire();let jumped=false,landed=false;
 for(let n=0;n<110;n++){const q=h.step({x:n<45?1:0,run:true,jumpPressed:n===30,jump:n>=30&&n<70});if(n===29){assert.equal(h.actor.x+h.actor.w,step.x);assert.equal(h.p.support,floor.id);}jumped||=q.out.includes('jump');assert.equal(h.motor.overlap(h.actor,m),false,'the real foot must not enter the Muncher side at frame '+n);assert.equal(h.motor.overlap(h.shoes.exposedBody(h.p),m),false);if(h.p.support===m.id){landed=true;const decision=h.shoes.playerEnemyContact(h.p,q.before,m,{tick:q.tick});assert.equal(decision.protected,true);assert.equal(decision.action,null);}}
 assert.equal(jumped,true);assert.equal(landed,true);assert.equal(h.p.grounded,true);assert.equal(h.p.support,m.id);assert.equal(h.actor.y+h.actor.h,m.y);assert.equal(h.actor.vx,0);assert.equal(h.shoes.ownsPlayer(h.p),true);assert.equal(m.dead,undefined);
 const proxy=h.shoes.geometry(h.solids,[m],{actor:h.p}).find(q=>q.id===m.id);assert.equal(proxy.collision,'solid');assert.deepEqual({x:proxy.x,y:proxy.y,w:proxy.w,h:proxy.h},{x:m.x,y:m.y,w:m.w,h:m.h});assert.equal(h.shoes.geometry(h.solids,[m],{actor:player()}),h.solids);assert.equal(m.collision,undefined);
});

test('Muncher blocking geometry does not turn genuine foot-side or exposed-body overlaps harmless',()=>{
 for(const part of ['foot-side','exposed-body']){const h=harness({q:spec({occupant:'empty'}),a:source({x:145,y:144}),p:player({x:148})});h.acquire();const m=part==='foot-side'?{id:part,type:'muncher',x:160,y:152,w:24,h:16}:{id:part,type:'muncher',x:h.p.x+1,y:h.p.y+1,w:8,h:8};h.shoes.beginFrame({tick:h.tick+1,actors:[h.actor,m],player:h.p});const before={...h.p,x:h.p.x-2};assert.equal(h.motor.overlap(part==='foot-side'?h.actor:h.shoes.exposedBody(h.p),m),true);assert.equal(h.motor.overlap(part==='foot-side'?h.shoes.exposedBody(h.p):h.actor,m),false);const decision=h.shoes.playerEnemyContact(h.p,before,m,{tick:h.tick+1});assert.equal(decision.protected,false);assert.equal(decision.action,null);assert.equal(h.shoes.ownsPlayer(h.p),true);assert.equal(m.dead,undefined);}
});

test('actual spike sole landing is protected; head/side/projectile and generic-hazard contacts are not',()=>{
 const spikes={id:'spikes',kind:'hazard',x:96,y:168,w:96,h:16,collision:'hazard',spikeTrap:true},h=harness({solids:[spikes]});h.acquire();let q;
 for(let i=0;i<70;i++){q=h.step();if(h.p.grounded)break;}assert.equal(h.p.support,'spikes');assert.equal(h.shoes.playerHazardContact(h.p,q.before,spikes,{tick:q.tick}).protected,true);
 const side={...spikes,x:h.actor.x+h.actor.w-2,y:h.p.y,w:8,h:8},projectile={...side,spikeTrap:undefined,type:'fireball'};assert.equal(h.shoes.playerHazardContact(h.p,q.before,side,{tick:q.tick}).protected,false);assert.equal(h.shoes.playerHazardContact(h.p,q.before,projectile,{tick:q.tick}).protected,false);assert.equal(h.shoes.playerHazardContact(h.p,q.before,{...spikes,spikeTrap:false},{tick:q.tick}).protected,false);
});

test('Big Shoe Down pound directly defeats Muncher; ordinary Small down/ordinary Big landing do not',()=>{
 for(const size of ['small','big']){const m={id:'muncher',type:'muncher',x:96,y:200,w:96,h:16},h=harness({q:spec({size}),a:source({y:140,w:size==='big'?32:16,h:size==='big'?32:16}),targets:[m],solids:[]});h.acquire();h.actor.vy=h.p.vy=1;const q=h.step({down:true});assert.equal(h.actor.smm2Shoe.groundPound,size==='big');
  let decision;for(let n=0;n<30;n++){const next=h.step({down:true});decision=h.shoes.playerEnemyContact(h.p,next.before,m,{tick:next.tick});if(decision.protected)break;}assert.equal(decision.protected,true);assert.equal(decision.action,size==='big'?'defeat':null);assert.equal(m.dead,undefined);}
 const m={id:'muncher',type:'muncher',x:96,y:200,w:96,h:16},normal=harness({q:spec({size:'big'}),a:source({y:140,w:32,h:32}),targets:[m],solids:[]});normal.acquire();let decision;for(let i=0;i<60;i++){const q=normal.step();decision=normal.shoes.playerEnemyContact(normal.p,q.before,m,{tick:q.tick});if(decision.protected)break;}assert.equal(decision.action,null);assert.equal(normal.shoes.view().blasts.length,0);
});

test('only an actual Big Stiletto pound requests a typed hard-block break; ground stays intact',()=>{
 for(const [kind,size,material,expected]of [['stiletto','big','hard-block',true],['shoe','big','hard-block',false],['stiletto','small','hard-block',false],['stiletto','big','ground',false],['stiletto','big','stone',false],['shoe','big','brick',true]]){
  const block={id:'block',x:96,y:200,w:96,h:16,collision:'solid',material},h=harness({q:spec({kind,size}),a:source({y:140,w:32,h:32}),solids:[block]});h.acquire();h.actor.vy=h.p.vy=1;let result=[];
  for(let n=0;n<30;n++){const q=h.step({down:true});result.push(...q.contacts.breaks);if(h.p.grounded)break;}assert.equal(result.length,expected?1:0,kind+'/'+size+'/'+material);assert.equal(block.dead,undefined);assert.equal(block.removed,undefined);if(expected)assert.equal(result[0].action,'break-solid');}
 assert.equal(smm2ShoeBlockKind({...floor,smm2BlockKind:'hard-block'}),null);assert.equal(smm2ShoeBlockKind({...floor,material:'block',smm2BlockKind:'hard-block'}),'hard-block');
 const stone={id:'native-stone-hard',x:96,y:200,w:96,h:16,collision:'solid',material:'stone',smm2BlockKind:'hard-block'},tagged=harness({q:spec({kind:'stiletto',size:'big'}),a:source({y:140,w:32,h:32}),solids:[stone]});tagged.acquire();tagged.actor.vy=tagged.p.vy=1;let requested=[];for(let n=0;n<30;n++){const q=tagged.step({down:true});requested.push(...q.contacts.breaks);if(tagged.p.grounded)break;}assert.equal(smm2ShoeBlockKind(stone),'hard-block');assert.equal(requested.length,1);assert.equal(requested[0].solidId,stone.id);assert.equal(stone.removed,undefined);
});

test('Big pound creates live lateral blasts which kill only actually reached Munchers, with walls and tick latches',()=>{
 const near={id:'near',type:'muncher',x:164,y:168,w:16,h:16},behind={id:'behind',type:'muncher',x:216,y:168,w:16,h:16},far={id:'far',type:'muncher',x:380,y:168,w:16,h:16},flower={id:'flower',type:'study-piranha',x:170,y:168,w:16,h:24},wall={id:'wall',x:192,y:168,w:8,h:32,collision:'solid'},h=harness({q:spec({size:'big',tuning:{blastSpeed:4,blastRange:80}}),a:source({x:120,y:130,w:32,h:32}),targets:[near,behind,far,flower],solids:[floor,wall]});h.acquire();h.actor.vy=h.p.vy=1;let requests=[];
 for(let n=0;n<35;n++){const q=h.step({down:true});requests.push(...q.effects);assert.deepEqual(h.shoes.stepEffects({tick:q.tick,geometry:h.solids,targets:h.targets}),[]);}
 assert.deepEqual(requests.map(q=>q.targetId),['near']);assert.equal(requests[0].contact.kind,'landing-blast');assert.equal(requests[0].action,'defeat');assert.equal(near.dead,undefined);assert.equal(far.dead,undefined);assert.equal(flower.dead,undefined);assert.equal(h.events.filter(q=>q.event==='landing-blasts').length,1);assert.equal(h.shoes.view().blasts.length,0);
});

test('conservative combat rejects Piranha/Spiny defaults, while explicit host policy still requires sole contact',()=>{
 const flower={id:'flower',type:'study-piranha',x:112,y:180,w:32,h:24},h=harness({solids:[]});h.acquire();h.actor.vy=h.p.vy=4;h.actor.y=164;h.p.y=154;h.shoes.beginFrame({tick:2,actors:[h.actor],player:h.p});const before={...h.p};h.actor.y=166;h.p.y=156;
 const unsupported=h.shoes.playerEnemyContact(h.p,before,flower,{tick:2});assert.equal(unsupported.protected,false);assert.match(unsupported.unverified,/piranha/);assert.equal(flower.dead,undefined);
 const enabled=harness({solids:[],options:{isStompTarget:a=>a.type==='study-piranha'}});enabled.acquire();enabled.actor.y=164;enabled.p.y=154;enabled.shoes.beginFrame({tick:2,actors:[enabled.actor],player:enabled.p});const old={...enabled.p};enabled.actor.y=166;enabled.p.y=156;const decision=enabled.shoes.playerEnemyContact(enabled.p,old,flower,{tick:2});assert.equal(decision.action,'defeat');assert.equal(decision.protected,true);assert.equal(flower.dead,undefined);const once={...enabled.p};assert.deepEqual(enabled.shoes.playerEnemyContact(enabled.p,old,flower,{tick:2}),decision);assert.deepEqual(enabled.p,once);
 const side={id:'side',type:'study-piranha',x:enabled.p.x+5,y:enabled.p.y,w:16,h:16};assert.equal(enabled.shoes.playerEnemyContact(enabled.p,once,side,{tick:2}).protected,false);
});

test('wing geometry is decorative and optional authored flutter is bounded; ordinary held jump has no extra mode',()=>{
 const h=harness({q:spec({winged:true,tuning:{flutterFrames:3,flutterFallSpeed:.25}}),solids:[]});h.acquire();h.actor.vy=h.p.vy=1;const width=h.actor.w;
 for(let i=0;i<3;i++){h.step({jump:true});assert.ok(h.actor.vy<=.25+1e-6);}assert.equal(h.actor.w,width);assert.equal(h.actor.smm2Shoe.flutterRemaining,0);h.step({jump:true});assert.ok(h.actor.vy>.25);
 const normal=harness({q:spec({winged:true}),solids:[]});normal.acquire();normal.actor.vy=normal.p.vy=1;normal.step({jump:true});assert.ok(normal.actor.vy>1);assert.equal(SMM2_SHOE_TUNING.flutterFrames,0);
});

test('carry round trip is serializable, explicit, collision-safe and preserves source identity/power/helmet',()=>{
 const h=harness({options:{allowCarry:true},p:player({power:2,helmet:'buzzy'})});h.acquire();const snapshot=h.shoes.exportCarry(h.p,{detach:true});assert.deepEqual(JSON.parse(JSON.stringify(snapshot)),snapshot);assert.equal(h.shoes.ownsPlayer(),false);assert.equal(h.actor.smm2Shoe.occupancy,'carried');
 const dest={roomId:'destination',map:{width:512,height:384,geometry:[],objects:[]}},controller=createSmm2Shoes(dest,{allowCarry:true}),p=player({x:200,y:100,power:2,helmet:'buzzy'}),a=controller.importCarry(p,snapshot,{tick:2});assert.equal(controller.ownsPlayer(p),true);assert.equal(a.id,'shoe');assert.equal(p.power,2);assert.equal(p.helmet,'buzzy');assert.equal(controller.exportCarry(p).originRoomId,'shoe-fixture');assert.equal(controller.view().shoes[0].sourceId,'shoe');
 assert.throws(()=>createSmm2Shoes(room()).importCarry(player(),snapshot),/not enabled/);assert.throws(()=>createSmm2Shoes(room(),{allowCarry:true}).importCarry(player(),snapshot),/conflicts/);assert.throws(()=>createSmm2Shoes(dest,{allowCarry:true}).importCarry(player(),{...snapshot,script:[]}),/Unknown/);assert.throws(()=>controller.importCarry(player(),{...snapshot,sourceId:'another'}),/passenger/);
 controller.reset();assert.equal(controller.ownsPlayer(),false);assert.equal(controller.view().shoes.length,0);assert.equal(p.vehicleId,undefined);
});

test('hurt/goal dismount preserve native pose and power; death/reset clean ownership and restore authored NPC',()=>{
 const h=harness({p:player({power:2,helmet:'buzzy'})});h.acquire();const x=h.p.x,y=h.p.y;assert.equal(h.shoes.dismount(h.p,{reason:'hurt',jump:false,consume:true}),true);assert.equal(h.p.x,x);assert.equal(h.p.y,y);assert.equal(h.p.power,2);assert.equal(h.p.helmet,'buzzy');assert.equal(h.actor.dead,true);
 h.shoes.reset();assert.equal(h.actor.dead,false);assert.equal(h.actor.smm2Shoe.occupancy,'npc');assert.equal(h.actor.x,120);assert.equal(h.actor.y,144);assert.equal(h.p.vehicleId,undefined);
 const dead=harness();dead.acquire();dead.p.dead=true;dead.shoes.beginFrame({tick:dead.tick+1,actors:[dead.actor],player:dead.p});assert.equal(dead.shoes.ownsPlayer(),false);assert.equal(dead.p.vehicleId,undefined);assert.equal(dead.actor.smm2Shoe.occupancy,'removed');assert.equal(dead.actor.dead,true);dead.shoes.reset();assert.equal(dead.actor.smm2Shoe.occupancy,'npc');assert.equal(dead.actor.dead,false);
});

test('shoe feet use the existing shaped terrain port without replacing the native motor',()=>{
 const r=room(spec({occupant:'empty'}),source({x:210,y:80}));r.smm2Mechanics.slopes=[{id:'slope',x:192,y:144,w:96,h:48,orientation:'rise-right',collision:'solid'}];const terrain=createSMM2Terrain(r),shoes=createSmm2Shoes(r,{terrain}),a={...r.map.objects[0],vx:0,vy:0},motor=createPlatformMotor(),p=player({x:210,y:30});shoes.decorateActor(a);
 for(let tick=1;tick<=30;tick++){terrain.beginFrame({tick,actors:[a,p]});shoes.beginFrame({tick,actors:[a],player:p});shoes.stepActor(a,{tick,geometry:[]});terrain.finishFrame({tick,actors:[a,p]});}
 assert.equal(a.grounded,true);assert.equal(a.support,'slope');assert.ok(a.y+a.h>=144&&a.y+a.h<=192);assert.equal(typeof motor.step,'function');
});

test('occupied feet trigger a player-only Donut through the existing terrain adapter and detach clears trigger',()=>{
 const r=room(spec({occupant:'empty'}),source({x:120,y:130}));r.smm2Mechanics.donuts=[{id:'donut',x:96,y:184,w:96,h:16,delayFrames:3,gravity:.4375,maxFallSpeed:4.25,triggerPolicy:'player',resetPolicy:'leave-before-drop',collision:'oneway'}];
 const terrain=createSMM2Terrain(r),shoes=createSmm2Shoes(r,{terrain}),a={...r.map.objects[0],vx:0,vy:0},p=player(),motor=createPlatformMotor();shoes.decorateActor(a);terrain.beginFrame({tick:1,actors:[p,a]});shoes.beginFrame({tick:1,actors:[a],player:p});const old={...p};p.y=122;assert.equal(shoes.afterPlayer(p,old,{tick:1,actors:[a]}).boarded.length,1);terrain.finishFrame({tick:1,actors:[p,a]});
 for(let tick=2;tick<=80&&terrain.view().donuts[0].phase!=='falling';tick++){terrain.beginFrame({tick,actors:[p,a]});shoes.beginFrame({tick,actors:[a],player:p});shoes.stepPlayer(p,{},character,{width:512,solids:terrain.geometry([])},{tick,motor});terrain.finishFrame({tick,actors:[p,a]});}
 assert.equal(terrain.view().donuts[0].phase,'falling');assert.equal(a.smm2Player,true);shoes.dismount(p,{jump:false});assert.equal(a.smm2Player,undefined);
});

test('paused and stale frames suppress motion, acquisition and effect advance without mutating the host player',()=>{
 const h=harness();h.acquire();const next=h.tick+1,pose={...h.p},foot={...h.actor},events=h.events.length;assert.equal(h.shoes.beginFrame({tick:next,actors:[h.actor],player:h.p,paused:true}),false);assert.deepEqual(h.shoes.stepPlayer(h.p,{dismountPressed:true},character,{width:512,solids:[floor]},{tick:next,motor:h.motor}),[]);assert.deepEqual(h.shoes.stepEffects({tick:next}),[]);assert.equal(h.shoes.stepActor(h.actor,{tick:next}).advanced,false);assert.deepEqual(h.p,pose);assert.deepEqual(h.actor,foot);assert.equal(h.events.length,events);
 assert.equal(h.shoes.beginFrame({tick:next,actors:[h.actor],player:h.p}),true);assert.equal(h.shoes.beginFrame({tick:1,actors:[h.actor],player:h.p}),false);const resumed={...h.p};assert.deepEqual(h.shoes.stepPlayer(h.p,{dismountPressed:true},character,{width:512,solids:[floor]},{tick:1,motor:h.motor}),[]);assert.deepEqual(h.p,resumed);
 assert.throws(()=>h.shoes.beginFrame({tick:NaN}),/frame/);assert.throws(()=>h.shoes.stepActor(h.actor,{tick:-1}),/step/);assert.throws(()=>h.shoes.stepEffects({tick:1.5}),/frame/);
});

test('occupied movement calls the supplied native motor exactly once and writes only native kinematics',()=>{
 const h=harness({p:player({power:2,helmet:'buzzy',health:3,custom:'preserved'})});h.acquire();let calls=0;const port={step(proxy,input){calls++;proxy.x+=2;proxy.y+=3;proxy.vx=2;proxy.vy=3;proxy.grounded=false;proxy.power=99;proxy.helmet='removed';proxy.custom='changed';return['native-event'];}};
 h.shoes.beginFrame({tick:2,actors:[h.actor],player:h.p});const old=h.shoes.shoeBody(h.p),out=h.shoes.stepPlayer(h.p,{jumpPressed:true},character,{width:512,solids:[]},{tick:2,motor:port});assert.equal(calls,1);assert.deepEqual(out,['native-event']);assert.equal(h.shoes.shoeBody(h.p).x-old.x,2);assert.equal(h.shoes.shoeBody(h.p).y-old.y,3);assert.equal(h.p.power,2);assert.equal(h.p.helmet,'buzzy');assert.equal(h.p.health,3);assert.equal(h.p.custom,'preserved');
});

test('carry back into the origin resets to its authored Goomba rather than retaining imported empty definition',()=>{
 const h=harness({options:{allowCarry:true}});h.acquire();const snapshot=h.shoes.exportCarry(h.p,{detach:true});const p=player({x:240,y:120});const returned=h.shoes.importCarry(p,snapshot,{tick:2});assert.equal(returned,h.actor);assert.equal(h.shoes.ownsPlayer(p),true);h.shoes.beginFrame({tick:2,actors:[h.actor],player:p});assert.equal(h.shoes.view([h.actor]).shoes.length,1);h.shoes.reset();assert.equal(h.shoes.ownsPlayer(),false);assert.equal(h.shoes.view().shoes[0].occupancy,'npc');assert.equal(returned.x,120);assert.equal(returned.y,144);
});

test('genuine source registration keeps actual spawn pose/ID and uses the authored matching Shoe profile',()=>{
 const r=room(spec({kind:'stiletto',size:'big',winged:true,tuning:{npcSpeed:.75}}),source({x:40,y:144,w:32,h:32})),before=JSON.stringify(r),shoes=createSmm2Shoes(r),a={id:'pipe-spawn-1',kind:'walker',roomId:r.roomId,x:320,y:112,w:32,h:32,vx:-1,vy:2,grounded:false},pose={x:a.x,y:a.y,w:a.w,h:a.h,vx:a.vx,vy:a.vy};
 assert.equal(shoes.ownsActor(a),false);assert.equal(shoes.registerActor(a,'shoe'),a);assert.equal(shoes.ownsActor(a),true);for(const key of Object.keys(pose))assert.equal(a[key],pose[key]);assert.equal(a.smm2Shoe.kind,'stiletto');assert.equal(a.smm2Shoe.size,'big');assert.equal(a.smm2Shoe.winged,true);assert.equal(shoes.view().shoes[0].templateId,'shoe');assert.equal(shoes.view().shoes[0].sourceId,'pipe-spawn-1');assert.equal(JSON.stringify(r),before);
 shoes.beginFrame({tick:1,actors:[a]});assert.equal(shoes.stepActor(a,{tick:1,geometry:[floor]}).advanced,true);assert.equal(a.x,319.25);assert.ok(a.y>112);const once=shoes.view();assert.equal(shoes.stepActor(a,{tick:1,geometry:[floor]}).advanced,false);assert.deepEqual(shoes.view(),once);
});

test('dynamic source templates reject unknown/foreign/dynamic templates, duplicate IDs and altered foot profiles',()=>{
 const r=room();r.map.geometry=[floor];const shoes=createSmm2Shoes(r),fresh=(id='spawn')=>({id,kind:'walker',x:240,y:100,w:16,h:16});
 assert.throws(()=>shoes.registerActor(fresh(),'other-room-template'),/authored template/);assert.throws(()=>shoes.registerActor({...fresh(),roomId:'foreign'},'shoe'),/this room/);assert.throws(()=>shoes.registerActor(fresh('shoe'),'shoe'),/ID/);assert.throws(()=>shoes.registerActor(fresh('floor'),'shoe'),/ID/);assert.throws(()=>shoes.registerActor(fresh('constructor'),'shoe'),/ID/);assert.throws(()=>shoes.registerActor(fresh('bad\nID'),'shoe'),/ID/);
 for(const patch of [{w:32},{h:32},{x:510},{y:380},{kind:'hazard'},{dead:true},{vy:Infinity},{smm2Shoe:{}}])assert.throws(()=>shoes.registerActor({...fresh(),...patch},'shoe'),/profile/);
 const a=fresh();shoes.registerActor(a,'shoe');assert.throws(()=>shoes.registerActor(fresh(),'shoe'),/Duplicate/);assert.throws(()=>shoes.registerActor(fresh('spawn-2'),'spawn'),/authored template/);
 const other=createSmm2Shoes(room(spec({id:'foreign-template'}),source({id:'foreign-template'})));assert.throws(()=>other.registerActor(fresh('spawn-3'),'shoe'),/authored template/);
});

test('dynamic NPC release/boarding preserves a real live body; death/reset removes registrations and restores templates',()=>{
 const r=room(),shoes=createSmm2Shoes(r),template={...r.map.objects[0]},a={id:'spawn-1',kind:'walker',x:240,y:144,w:16,h:16,vx:0,vy:0},p=player({x:243,y:100});shoes.decorateActor(template);shoes.registerActor(a,'shoe');shoes.beginFrame({tick:1,actors:[template,a],player:p});const before={...p};p.y=126;const released=shoes.afterPlayer(p,before,{tick:1,actors:[template,a]});assert.equal(released.defeated[0].actorId,'spawn-1');assert.equal(a.smm2Shoe.occupancy,'empty');assert.equal(a.dead,undefined);assert.equal(shoes.view().shoes.filter(q=>!q.dead).length,2);
 shoes.beginFrame({tick:2,actors:[template,a],player:p});const previous={...p,y:128};p.y=132;assert.deepEqual(shoes.afterPlayer(p,previous,{tick:2,actors:[template,a]}).boarded,['spawn-1']);assert.equal(shoes.ownsPlayer(p),true);assert.equal(shoes.view().shoes.filter(q=>!q.dead).length,2);
 p.dead=true;shoes.beginFrame({tick:3,actors:[template,a],player:p});assert.equal(a.dead,true);assert.equal(shoes.ownsPlayer(),false);assert.equal(shoes.stepActor(a,{tick:3}).advanced,false);shoes.reset();assert.equal(shoes.ownsActor(a),false);assert.equal(a.smm2Shoe,undefined);assert.equal(a.dead,true);assert.equal(template.smm2Shoe.occupancy,'npc');assert.equal(template.dead,false);assert.equal(shoes.view().shoes.length,1);
 const next={id:'spawn-1',kind:'walker',x:300,y:100,w:16,h:16};shoes.registerActor(next,'shoe');assert.equal(shoes.ownsActor(next),true);assert.equal(next.x,300);
});

test('grounded Big/Fire Mario crouches inside a normal Shoe while preserving real foot support and power',()=>{
 const h=harness({p:player({power:2,helmet:'buzzy',h:28}),a:source({y:168})});h.acquire();Object.assign(h.actor,{grounded:true,support:'floor',vy:0});Object.assign(h.p,{grounded:true,support:'floor',vy:0});const foot=h.shoes.shoeBody(h.p),q=h.step({down:true,x:1,run:true});assert.equal(h.p.h,16);assert.equal(h.p.crouch,true);assert.equal(h.p.power,2);assert.equal(h.p.helmet,'buzzy');assert.deepEqual(h.shoes.shoeBody(h.p),foot);assert.equal(h.p.support,'floor');assert.equal(h.actor.smm2Shoe.groundPound,false);assert.deepEqual(q.out,[]);
 h.step({});assert.equal(h.p.h,28);assert.equal(h.p.crouch,false);assert.deepEqual(h.shoes.shoeBody(h.p),foot);
});

test('a real low ceiling blocks standing from Shoe crouch; feet/body stay put until headroom is clear',()=>{
 const h=harness({p:player({power:1,h:28}),a:source({y:168})});h.acquire();Object.assign(h.actor,{grounded:true,support:'floor',vy:0});Object.assign(h.p,{grounded:true,support:'floor',vy:0});h.step({down:true});const roof={id:'roof',x:96,y:140,w:96,h:12,collision:'solid'},foot=h.shoes.shoeBody(h.p),pose={x:h.p.x,y:h.p.y};h.solids.push(roof);
 for(let i=0;i<4;i++){h.step({x:1});assert.equal(h.p.h,16);assert.equal(h.p.crouch,true);assert.equal(h.p.x,pose.x);assert.equal(h.p.y,pose.y);assert.deepEqual(h.shoes.shoeBody(h.p),foot);}
 h.solids.pop();h.step({});assert.equal(h.p.h,28);assert.equal(h.p.crouch,false);assert.equal(h.shoes.shoeBody(h.p).y,foot.y);assert.equal(h.p.y+28,foot.y+4);
});

test('actual triangular ceiling headroom prevents standing without an arbitrary roof exemption',()=>{
 const r=room(spec({occupant:'empty'}),source({x:120,y:168}));r.smm2Mechanics.slopes=[{id:'ceiling',x:96,y:128,w:96,h:32,orientation:'ceiling-rise-right',collision:'solid'}];const terrain=createSMM2Terrain(r),shoes=createSmm2Shoes(r,{terrain}),a={...r.map.objects[0],vx:0,vy:0,grounded:true,support:'floor'},p=player({power:2,h:16,crouch:true,y:140}),motor=createPlatformMotor();shoes.decorateActor(a);shoes.beginFrame({tick:1,actors:[a],player:p});const prior={...p};p.y=156;assert.deepEqual(shoes.afterPlayer(p,prior,{tick:1,actors:[a]}).boarded,['shoe']);
 terrain.beginFrame({tick:2,actors:[p,a]});shoes.beginFrame({tick:2,actors:[a],player:p});shoes.stepPlayer(p,{},character,{width:512,solids:[floor]},{tick:2,motor});terrain.finishFrame({tick:2,actors:[p,a]});assert.equal(p.h,16);assert.equal(p.crouch,true);assert.equal(a.y+a.h,184);
});

test('Small Mario and airborne Down do not crouch; an explicit Shoe compatibility opt-out preserves standing bounds',()=>{
 const small=harness({a:source({y:168})});small.acquire();Object.assign(small.actor,{grounded:true,support:'floor',vy:0});Object.assign(small.p,{grounded:true,support:'floor',vy:0});small.step({down:true});assert.equal(small.p.h,14);assert.equal(small.p.crouch,false);
 const disabled=harness({q:spec({crouchCompatible:false}),a:source({y:168}),p:player({power:2,h:28})});disabled.acquire();Object.assign(disabled.actor,{grounded:true,support:'floor',vy:0});Object.assign(disabled.p,{grounded:true,support:'floor',vy:0});disabled.step({down:true});assert.equal(disabled.p.h,28);assert.equal(disabled.p.crouch,false);
 for(const size of ['small','big']){const air=harness({q:spec({size}),p:player({power:2,h:28}),solids:[]});air.acquire();air.step({down:true});assert.equal(air.p.h,28);assert.equal(air.p.crouch,false);assert.equal(air.actor.smm2Shoe.groundPound,size==='big');}
 assert.throws(()=>validateSmm2ShoesRoom(room(spec({crouchCompatible:'yes'}))),/crouch/);
});

test('emerging pipe Shoe remains factory-owned and cannot move, expose a head or be stomped/boarded early',()=>{
 const r=room(),shoes=createSmm2Shoes(r),a={id:'spawn-emerging',kind:'walker',x:240,y:144,w:16,h:16,vx:-.5,vy:0,moduleEmergence:{sourceId:'source',pipeId:'pipe',direction:'up',remainingFrames:2,totalFrames:2,targetX:240,targetY:128,launchVx:-.5,launchVy:0}},p=player({x:243,y:100});shoes.registerActor(a,'shoe');shoes.beginFrame({tick:1,actors:[a],player:p});const pose={x:a.x,y:a.y,vx:a.vx,vy:a.vy};assert.equal(shoes.stepActor(a,{tick:1}).advanced,false);assert.deepEqual({x:a.x,y:a.y,vx:a.vx,vy:a.vy},pose);assert.equal(shoes.contactBody(a),null);const view=shoes.view().shoes[0];assert.equal(view.emerging,true);assert.equal(view.npcBody,undefined);assert.deepEqual(view.moduleEmergence,a.moduleEmergence);
 const old={...p};p.y=126;assert.deepEqual(shoes.afterPlayer(p,old,{tick:1,actors:[a]}),{boarded:[],defeated:[],breaks:[]});assert.equal(a.smm2Shoe.occupancy,'npc');
 const colors=[],ctx={save(){},restore(){},translate(){},fillRect(){colors.push(this.fillStyle);}};assert.equal(drawSmm2Shoe(ctx,view),true);assert.equal(colors.includes('#aa5b1e'),false);
 delete a.moduleEmergence;shoes.beginFrame({tick:2,actors:[a],player:p});const before={...p,y:100};p.y=126;assert.equal(shoes.afterPlayer(p,before,{tick:2,actors:[a]}).defeated.length,1);assert.equal(a.smm2Shoe.occupancy,'empty');assert.equal(shoes.view().shoes[0].emerging,false);
});

test('mounted rendering has the real passenger body, composite envelope and stable mounted ID',()=>{
 const h=harness();h.acquire();const view=h.shoes.view(),a=view.shoes[0];assert.equal(view.mountedId,h.actor.id);assert.deepEqual(a.playerBody,{x:h.p.x,y:h.p.y,w:h.p.w,h:h.p.h});assert.deepEqual(a.contactBody,h.shoes.contactBody(h.p));assert.ok(a.contactBody.y<=h.p.y);assert.equal(a.contactBody.y+a.contactBody.h,h.actor.y+h.actor.h);assert.equal(a.exposedBody.y+a.exposedBody.h,h.actor.y);
 h.shoes.dismount(h.p);assert.equal(h.shoes.view().mountedId,null);assert.equal(h.shoes.view().shoes[0].playerBody,undefined);
});

test('typed Muncher sidecars support actual feet but emerging Munchers cannot grant support/protection',()=>{
 const h=harness(),m={id:'typed-muncher',type:'study-muncher',smm2EnemyKind:'muncher',x:96,y:168,w:80,h:16};h.acquire();const g=h.shoes.geometry([floor],[m],{actor:h.p});assert.ok(g.some(q=>q.id===m.id&&q.smm2ShoeSupport));m.moduleEmergence={remainingFrames:1};assert.equal(h.shoes.geometry([floor],[m],{actor:h.p}).some(q=>q.id===m.id),false);assert.equal(h.shoes.playerEnemyContact(h.p,h.p,m,{tick:h.tick}).protected,false);
});

test('syncTransition follows genuine animated player pose without stepping motion, clocks or contacts',()=>{
 const h=harness({p:player({power:2,h:28,helmet:'buzzy'})});h.acquire();const original=h.shoes.view(),foot=h.shoes.shoeBody(h.p),velocity={vx:h.actor.vx,vy:h.actor.vy,grounded:h.actor.grounded,support:h.actor.support},state=structuredClone(h.actor.smm2Shoe),eventCount=h.events.length;h.p.x+=12;h.p.y+=8;const actualPlayer={...h.p};assert.equal(h.shoes.syncTransition(h.p),h.actor);assert.equal(h.actor.x,foot.x+12);assert.equal(h.actor.y,foot.y+8);assert.deepEqual(h.p,actualPlayer);assert.deepEqual({vx:h.actor.vx,vy:h.actor.vy,grounded:h.actor.grounded,support:h.actor.support},velocity);assert.deepEqual(structuredClone(h.actor.smm2Shoe),state);assert.equal(h.shoes.view().tick,original.tick);assert.deepEqual(h.shoes.view().events,original.events);assert.deepEqual(h.shoes.view().blasts,original.blasts);assert.equal(h.events.length,eventCount);
 const once=h.shoes.shoeBody(h.p);assert.equal(h.shoes.syncTransition(h.p),h.actor);assert.deepEqual(h.shoes.shoeBody(h.p),once);h.p.y+=12;h.p.h=16;h.p.crouch=true;h.shoes.syncTransition(h.p);assert.equal(h.actor.y,once.y);assert.equal(h.p.power,2);assert.equal(h.p.helmet,'buzzy');assert.equal(h.shoes.syncTransition(player()),null);assert.equal(h.events.length,eventCount);
});

test('mounted descending sole stomps a second Shoe Goomba, releases only its occupant and preserves the current mount',()=>{
 const h=harness();h.acquire();h.p.y=70;h.shoes.syncTransition(h.p);const second={id:'second-shoe',kind:'walker',x:120,y:128,w:16,h:16,vx:.5,vy:0},targetPose={x:second.x,y:second.y,vx:second.vx,vy:second.vy};h.shoes.registerActor(second,'shoe');const tick=h.tick+1;h.shoes.beginFrame({tick,actors:[h.actor,second],player:h.p});const before={...h.p};h.p.y+=26;h.shoes.syncTransition(h.p);const result=h.shoes.afterPlayer(h.p,before,{tick,actors:[h.actor,second]});assert.deepEqual(result.boarded,[]);assert.equal(result.defeated.length,1);assert.equal(result.defeated[0].actorId,'second-shoe');assert.equal(result.defeated[0].occupantOnly,true);assert.equal(result.defeated[0].action,'defeat-occupant');assert.equal(result.damage,undefined);assert.equal(second.smm2Shoe.occupancy,'empty');assert.equal(second.dead,undefined);assert.deepEqual({x:second.x,y:second.y,vx:second.vx,vy:second.vy},targetPose);assert.equal(h.shoes.ownsPlayer(h.p),true);assert.equal(h.p.shoeId,'shoe');assert.equal(h.actor.smm2Shoe.occupancy,'player');assert.ok(h.p.vy<0);assert.equal(h.actor.y+h.actor.h,second.y-8);
 const events=h.events.filter(q=>q.event==='mounted-stomp-release').length;assert.equal(events,1);assert.deepEqual(h.shoes.afterPlayer(h.p,before,{tick,actors:[h.actor,second]}),{boarded:[],defeated:[],breaks:[]});h.shoes.playerShoeContact(h.p,before,second,{tick});assert.equal(h.events.filter(q=>q.event==='mounted-stomp-release').length,1);
});

test('mounted exposed-body side contact with a second NPC Shoe requests native hurt without releasing or switching feet',()=>{
 const h=harness();h.acquire();h.p.x=103;h.shoes.syncTransition(h.p);const second={id:'side-shoe',kind:'walker',x:120,y:128,w:16,h:16,vx:0,vy:0};h.shoes.registerActor(second,'shoe');const tick=h.tick+1;h.shoes.beginFrame({tick,actors:[h.actor,second],player:h.p});const before={...h.p};h.p.x+=14;h.shoes.syncTransition(h.p);const result=h.shoes.afterPlayer(h.p,before,{tick,actors:[h.actor,second]});assert.deepEqual(result.defeated,[]);assert.deepEqual(result.boarded,[]);assert.equal(result.damage.length,1);assert.equal(result.damage[0].action,'hurt');assert.equal(result.damage[0].actorId,second.id);assert.equal(result.damage[0].contact.part,'player-body');assert.equal(result.damage[0].protected,false);assert.equal(second.smm2Shoe.occupancy,'npc');assert.equal(second.dead,undefined);assert.equal(h.p.shoeId,'shoe');assert.equal(h.shoes.ownsPlayer(h.p),true);
 assert.deepEqual(h.shoes.afterPlayer(h.p,before,{tick,actors:[h.actor,second]}),{boarded:[],defeated:[],breaks:[]});
});

test('bare Mario NPC Shoe side contact remains harmful, while empty/emerging feet are neutral',()=>{
 const h=harness({p:player({x:100,y:144})});h.shoes.beginFrame({tick:1,actors:[h.actor],player:h.p});const before={...h.p};h.p.x=115;const hit=h.shoes.afterPlayer(h.p,before,{tick:1,actors:[h.actor]});assert.equal(hit.damage[0].action,'hurt');assert.deepEqual(hit.defeated,[]);assert.equal(h.actor.smm2Shoe.occupancy,'npc');
 const mounted=harness({q:spec({occupant:'empty'})});mounted.acquire();const empty={id:'empty-other',kind:'walker',x:mounted.p.x,y:mounted.p.y,w:16,h:16};mounted.shoes.registerActor(empty,'shoe');const tick=mounted.tick+1;mounted.shoes.beginFrame({tick,actors:[mounted.actor,empty],player:mounted.p});assert.deepEqual(mounted.shoes.afterPlayer(mounted.p,{...mounted.p},{tick,actors:[mounted.actor,empty]}),{boarded:[],defeated:[],breaks:[]});assert.equal(mounted.p.shoeId,'shoe');assert.equal(empty.smm2Shoe.occupancy,'empty');
});

test('an intervening real platform prevents a scripted mounted sole crossing from releasing another occupant',()=>{
 const h=harness();h.acquire();h.p.y=70;h.shoes.syncTransition(h.p);const second={id:'blocked-second',kind:'walker',x:120,y:128,w:16,h:16};h.shoes.registerActor(second,'shoe');const tick=h.tick+1;h.shoes.beginFrame({tick,actors:[h.actor,second],player:h.p});const before={...h.p};h.p.y+=26;h.shoes.syncTransition(h.p);const geometry=[{id:'intervening',x:96,y:112,w:96,h:4,collision:'oneway'}],result=h.shoes.afterPlayer(h.p,before,{tick,actors:[h.actor,second],geometry});assert.deepEqual(result.defeated,[]);assert.equal(second.smm2Shoe.occupancy,'npc');assert.equal(h.p.shoeId,'shoe');
});

test('mounted crossing resolves only the nearest NPC Shoe head, regardless of source list order',()=>{
 const h=harness();h.acquire();h.p.y=70;h.shoes.syncTransition(h.p);const far={id:'far-npc',kind:'walker',x:120,y:140,w:16,h:16},near={id:'near-npc',kind:'walker',x:120,y:128,w:16,h:16};h.shoes.registerActor(far,'shoe');h.shoes.registerActor(near,'shoe');const tick=h.tick+1;h.shoes.beginFrame({tick,actors:[h.actor,far,near],player:h.p});const before={...h.p};h.p.y+=44;h.shoes.syncTransition(h.p);const result=h.shoes.afterPlayer(h.p,before,{tick,actors:[h.actor,far,near]});assert.deepEqual(result.defeated.map(q=>q.actorId),['near-npc']);assert.equal(near.smm2Shoe.occupancy,'empty');assert.equal(far.smm2Shoe.occupancy,'npc');assert.equal(h.p.shoeId,'shoe');assert.equal(h.actor.y+h.actor.h,near.y-8);assert.equal(h.events.filter(q=>q.event==='mounted-stomp-release').length,1);
});

test('a real Big Shoe pound on a Muncher top sends surface-touching waves into adjacent same-row Munchers',()=>{
 const center={id:'pounded',type:'muncher',x:120,y:136,w:32,h:16},left={id:'adjacent-left',type:'muncher',x:104,y:136,w:16,h:16},right={id:'adjacent-right',type:'muncher',x:152,y:136,w:16,h:16},behind={id:'behind-wall',type:'muncher',x:184,y:136,w:16,h:16},wall={id:'wall',x:176,y:120,w:8,h:40,collision:'solid'},ground={...floor,y:152},h=harness({q:spec({size:'big',occupant:'empty',tuning:{blastSpeed:4,blastRange:64}}),a:source({x:120,y:84,w:32,h:32}),p:player({y:40}),targets:[center,left,right,behind],solids:[wall,ground]});h.acquire();let landing;
 for(let n=0;n<20;n++){const q=h.step({down:true});if(h.p.grounded){landing=q;break;}}assert.ok(landing);assert.equal(h.p.support,center.id);assert.equal(h.actor.y+h.actor.h,136);assert.equal(h.shoes.playerEnemyContact(h.p,landing.before,center,{tick:landing.tick}).action,'defeat');const waves=h.shoes.view().blasts;assert.equal(waves.length,2);assert.ok(waves.every(b=>b.y+b.h===136));const requests=[];
 for(let n=0;n<25;n++)requests.push(...h.step().effects);assert.deepEqual(requests.map(q=>q.targetId).sort(),['adjacent-left','adjacent-right']);assert.ok(requests.every(q=>q.contact.kind==='landing-blast'));assert.equal(behind.dead,undefined);assert.equal(center.dead,undefined);assert.equal(h.events.filter(q=>q.event==='landing-blasts').length,1);
});

test('surface-touch waves keep real walls blocking and do not bridge even a small vertical gap',()=>{
 const center={id:'pounded',type:'muncher',x:120,y:136,w:32,h:16},left={id:'left',type:'muncher',x:104,y:136,w:16,h:16},blocked={id:'blocked',type:'muncher',x:168,y:136,w:16,h:16},gap={id:'below-surface',type:'muncher',x:88,y:136.001,w:16,h:16},wall={id:'flush-wall',x:152,y:120,w:8,h:40,collision:'solid'},h=harness({q:spec({size:'big',occupant:'empty',tuning:{blastSpeed:4,blastRange:64}}),a:source({x:120,y:84,w:32,h:32}),p:player({y:40}),targets:[center,left,blocked,gap],solids:[wall,{...floor,y:152}]});h.acquire();let landed=false,requests=[];
 for(let n=0;n<30;n++){const q=h.step({down:!landed});landed||=h.p.grounded;requests.push(...q.effects);assert.ok(h.shoes.view().blasts.every(b=>b.y+b.h<=136));}assert.ok(landed);assert.deepEqual(requests.map(q=>q.targetId),['left']);assert.equal(blocked.dead,undefined);assert.equal(gap.dead,undefined);assert.equal(h.events.filter(q=>q.event==='landing-blasts').length,1);
});
