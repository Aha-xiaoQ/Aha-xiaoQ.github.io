import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {offlineFile} from '../atlas/editor-offline.mjs';
import {createCollection,addLevel,approveLevel,buildCollection} from '../atlas/editor-collection.mjs';
import {parseProject} from '../atlas/editor-model.mjs';
import {pSwitchProject} from './fixtures/p-switch-native.mjs';
import {nativeSession,character} from './fixtures/shell-coin-native.mjs';
for(const collection of [false,true])test(`actual embedded ${collection?'collection':'single map'} runs authored inverted P, global conversion, expiry and light removal without network`,async()=>{
 const project=pSwitchProject('down'),s=nativeSession(project),root=new URL('../atlas/',import.meta.url),built=collection?buildCollection(approveLevel(addLevel(createCollection('Neutral P Switch closure'),project,{id:'p-fixture'}),'p-fixture','Synthetic neutral P fixture approval for automated QA only'),character):null;if(built)assert.deepEqual(parseProject(JSON.stringify(built.levels[0].rooms?{...project,rooms:built.levels[0].rooms}:project)),project);
 const html=await offlineFile(s.pack,s.doc.rooms,p=>fs.promises.readFile(new URL(p,root),'utf8'),p=>fs.promises.readFile(new URL('assets/classic-audio/'+p,root)),()=>{},collection?{collection:built}:{}),dir=fs.mkdtempSync(path.join(os.tmpdir(),'Authored P Offline QA '));try{const htmlPath=path.join(dir,'P player.html'),projectPath=path.join(dir,'P source.qmap.json');fs.writeFileSync(htmlPath,html);fs.writeFileSync(projectPath,JSON.stringify(project));const result=spawnSync(process.execPath,['--experimental-vm-modules',fileURLToPath(new URL('../scripts/check-p-switch-offline.mjs',import.meta.url)),htmlPath,projectPath,...(collection?['collection']:[])],{encoding:'utf8',timeout:45000,maxBuffer:1024*1024});assert.equal(result.status,0,result.stderr||result.stdout||String(result.error));const report=JSON.parse(result.stdout);for(const key of ['actualEmbeddedStageExecuted','actualEmbeddedMotorExecuted','actualEmbeddedLightingExecuted','actualEmbeddedPArtExecuted','expiredRemoved','lightExpired','stableId'])assert.equal(report[key],true,key);assert.equal(report.networkRequests,0);assert.equal(report.collection,collection);}finally{fs.rmSync(dir,{recursive:true,force:true});}
});
