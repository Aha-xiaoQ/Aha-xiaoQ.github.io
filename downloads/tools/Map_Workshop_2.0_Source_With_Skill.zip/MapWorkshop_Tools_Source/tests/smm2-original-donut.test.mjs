import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {createCanvas,loadImage} from '@napi-rs/canvas';
import {drawSmm2Donut,drawSmm2World} from '../atlas/editor-smm2-art.mjs';
import {SMM2_SOURCE_PIXELS} from '../atlas/editor-smm2-source-assets.mjs';
import {drawSmm2EditorTerrain} from '../atlas/editor-smm2-tools.mjs';
import {drawSmb3World} from '../atlas/editor-smb3-art.mjs';
import {offlineFile} from '../atlas/editor-offline.mjs';
import {createCollection,addLevel,approveLevel,buildCollection} from '../atlas/editor-collection.mjs';
import {nativeSession,character} from './fixtures/shell-coin-native.mjs';
import {originalDonutProject,rawPalettePng,rgba,assertNativeDonutContact} from './fixtures/original-donut-native.mjs';
const assetUrl=new URL('../atlas/assets/smm2-private/SMM-SMB-DonutBlock.original.png',import.meta.url),raw=fs.readFileSync(assetUrl),image=await loadImage(rawPalettePng(raw));
const canvas=()=>createCanvas(96,80),pixel=(c,x,y)=>[...c.getContext('2d').getImageData(x,y,1,1).data];

test('original Donut response bytes, dimensions, rights and source qualification remain recorded',()=>{
 const catalogue=JSON.parse(fs.readFileSync(new URL('../atlas/assets/smm2-private/SOURCE_ASSETS.json',import.meta.url))),entry=catalogue.assets.donutBlock;
 assert.equal(raw.length,257);assert.equal(createHash('sha256').update(raw).digest('hex'),'a5e7a8b612b98380710d667d407eabee0c744035d9af3cb1311b4e68634bdde7');assert.equal(entry.sha256,createHash('sha256').update(raw).digest('hex'));assert.equal(image.width,16);assert.equal(image.height,16);assert.equal(SMM2_SOURCE_PIXELS.donutBlock.w,16);assert.equal(SMM2_SOURCE_PIXELS.donutBlock.h,16);assert.match(entry.rights,/copyrighted/i);assert.match(entry.sourceVersion,/not independently verified/);assert.match(entry.note,/No original shaking frames/);
});
test('default Donut renderer reproduces every stored native RGBA pixel at 1×, 2× and 3×',()=>{
 for(const scale of [1,2,3]){
  const actual=canvas(),expected=canvas(),ctx=actual.getContext('2d');ctx.scale(scale,scale);ctx.imageSmoothingEnabled=true;const before=ctx.getTransform();
  assert(drawSmm2Donut(ctx,{x:3,y:4,w:16,h:16,phase:'idle'},321));const e=expected.getContext('2d');e.imageSmoothingEnabled=false;e.drawImage(image,3*scale,4*scale,16*scale,16*scale);
  assert.deepEqual(rgba(actual),rgba(expected));assert.deepEqual(ctx.getTransform(),before);assert.equal(ctx.imageSmoothingEnabled,true);
 }
});
test('wider and partial author rectangles repeat native cells and crop edges without stretching',()=>{
 for(const [w,h]of [[48,16],[23,11],[11,23],[32,32]]){
  const actual=canvas(),expected=canvas(),q={x:7,y:9,w,h},e=expected.getContext('2d');drawSmm2Donut(actual.getContext('2d'),q);
  e.save();e.beginPath();e.rect(q.x,q.y,w,h);e.clip();for(let y=0;y<h;y+=16)for(let x=0;x<w;x+=16)e.drawImage(image,q.x+x,q.y+y);e.restore();assert.deepEqual(rgba(actual),rgba(expected));
 }
 const whole=canvas(),split=canvas();drawSmm2Donut(whole.getContext('2d'),{x:8,y:8,w:48,h:16});for(const x of [8,24,40])drawSmm2Donut(split.getContext('2d'),{x,y:8,w:16,h:16});assert.deepEqual(rgba(whole),rgba(split));
});
test('only the actual shaking phase offsets the static body while falling preserves live coordinates',()=>{
 const q={x:16,y:16,w:16,h:16,phase:'idle'},before=JSON.stringify(q),idle=canvas();drawSmm2Donut(idle.getContext('2d'),q,999);
 for(const [phase,contactFrames,tick,x,y]of [['idle',2,999,16,16],['shaking',1,999,15,16],['shaking',2,0,17,16],['shaking',undefined,2,17,16],['falling',2,999,16,43]]){
  const a=canvas(),e=canvas();drawSmm2Donut(a.getContext('2d'),{...q,phase,contactFrames,y:phase==='falling'?43:16},tick);e.getContext('2d').drawImage(image,x,y);assert.deepEqual(rgba(a),rgba(e));
 }
 assert.equal(pixel(idle,22,22)[3],0,'transparent original opening');assert.deepEqual(pixel(idle,21,20),[31,31,31,255],'original dark edge inside the ring');assert.equal(JSON.stringify(q),before);
 for(const patch of [{phase:'removed'},{hidden:true},{visible:false},{w:0}]){const c=canvas();assert.equal(drawSmm2Donut(c.getContext('2d'),{...q,...patch}),false);assert(!rgba(c).some((v,i)=>i%4===3&&v));}
});
test('ordinary Stage contact drives both visible shake offsets and the original cells at genuine falling poses',()=>{assertNativeDonutContact({image,drawWorld:drawSmm2World});});
test('editor effect preview reaches the same original idle cell renderer without changing author data',()=>{
 const project=originalDonutProject(),r=project.rooms[0],before=JSON.stringify(project),actual=createCanvas(384,240),expected=createCanvas(384,240);assert(drawSmm2EditorTerrain(actual.getContext('2d'),r));expected.getContext('2d').drawImage(image,96,144);expected.getContext('2d').drawImage(image,112,144);assert.deepEqual(rgba(actual),rgba(expected));assert.equal(JSON.stringify(project),before);
});
test('explicit SMB3 world dispatch remains separate from the default SMB1 original Donut body',()=>{
 const r=originalDonutProject().rooms[0];r.smm2Mechanics.art={palette:'smb3-underground'};const view={smm2Mechanics:{version:1,donuts:[{x:16,y:16,w:16,h:16}],surfaces:[{kind:'slope',spec:{x:16,y:48,w:48,h:16,orientation:'rise-right'}}]}};
 const actual=canvas(),expected=canvas();assert(drawSmm2World(actual.getContext('2d'),r,view));assert(drawSmb3World(expected.getContext('2d'),r,view));assert.deepEqual(rgba(actual),rgba(expected));assert.equal(pixel(actual,20,20)[3],0,'SMB1 sprite cannot leak into explicit SMB3 path');
});
for(const collection of [false,true])test(`offline ${collection?'collection':'single'} embeds and executes original Donut art with genuine Stage contact and zero network`,async()=>{
 const project=originalDonutProject(),s=nativeSession(project),root=new URL('../atlas/',import.meta.url),built=collection?buildCollection(approveLevel(addLevel(createCollection('Neutral original Donut closure'),project,{id:'donut-fixture'}),'donut-fixture','Synthetic neutral approval for automated QA'),character):null,html=await offlineFile(s.pack,s.doc.rooms,p=>fs.promises.readFile(new URL(p,root),'utf8'),p=>fs.promises.readFile(new URL('assets/classic-audio/'+p,root)),()=>{},collection?{collection:built}:{}),dir=fs.mkdtempSync(path.join(os.tmpdir(),'Original Donut Offline QA '));
 try{const htmlPath=path.join(dir,'fixture.html'),projectPath=path.join(dir,'fixture.qmap.json');fs.writeFileSync(htmlPath,html);fs.writeFileSync(projectPath,JSON.stringify(project));const result=spawnSync(process.execPath,['--experimental-vm-modules',fileURLToPath(new URL('../scripts/check-original-donut-offline.mjs',import.meta.url)),htmlPath,projectPath,...(collection?['collection']:[])],{encoding:'utf8',timeout:30000,maxBuffer:1024*1024});assert.equal(result.status,0,result.stderr||result.stdout||String(result.error));const report=JSON.parse(result.stdout);assert.equal(report.actualEmbeddedArtExecuted,true);assert.equal(report.actualEmbeddedStageExecuted,true);assert.equal(report.originalCellsExact,true);assert.equal(report.actualContact,true);assert.equal(report.networkRequests,0);assert.equal(report.frames,60);assert.equal(report.collection,collection);
 }finally{fs.rmSync(dir,{recursive:true,force:true});}
});
