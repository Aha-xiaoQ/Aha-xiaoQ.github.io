import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createPlatformStage} from '../atlas/editor-mario-stage.mjs';
import {createPlatformMotor} from '../atlas/editor-mario-motor.mjs';
import {validateMarioModulesRoom} from '../atlas/editor-mario-modules.mjs';

// Every fixture is born at a declared native spawn. Tests only submit ordinary
// controller input. There is no test motor, pose setter or midway p mutation.
const character={capabilities:['jump'],motion:{width:10,height:14,maxHealth:1}};
const opposite={up:'down',down:'up',left:'right',right:'left'};
const directions=['up','down','left','right'];
const object=(id,kind,x,y,w=10,h=14,extra={})=>({id,kind,x,y,w,h,...extra});
function pipeFor(direction,id='pipe'){
 return {id,x:128,y:direction==='up'?64:direction==='down'?160:192,w:32,h:direction==='up'||direction==='down'?64:32,collision:'solid',material:direction==='up'||direction==='down'?'pipe':'pipe-side'};
}
function mouthSpawn(direction,pipe){
 return direction==='up'?{x:pipe.x+11,y:pipe.y+pipe.h+18}:direction==='down'?{x:pipe.x+11,y:pipe.y-14}:direction==='left'?{x:pipe.x+pipe.w+6,y:210}:{x:pipe.x-16,y:210};
}
function mouthPortal(direction,pipe,id,targetRoom,targetSpawn){
 const q=direction==='up'?{x:pipe.x,y:pipe.y+pipe.h-4,w:pipe.w,h:36}:direction==='down'?{x:pipe.x,y:pipe.y-28,w:pipe.w,h:32}:direction==='left'?{x:pipe.x+pipe.w-4,y:pipe.y,w:20,h:pipe.h}:{x:pipe.x-16,y:pipe.y,w:20,h:pipe.h};
 return {...q,id,kind:'portal',targetRoom,targetSpawn};
}
function nativeRoom(roomId,into){
 const pipe=pipeFor(into),spawn=mouthSpawn(into,pipe),floorY=into==='up'?160:224;
 return {roomId,setting:'Castle',markers:[],decorations:[],smm2Mechanics:{version:1},map:{id:'pipe-'+roomId,title:'Pipe direction fixture',width:512,height:288,tileSize:16,geometry:[{id:'floor',x:0,y:floorY,w:512,h:288-floorY,collision:'solid',material:'ground'},pipe],objects:[object('start','spawn',spawn.x,spawn.y)]},marioModules:{version:1,itemSources:[],noteBlocks:[],oneWayWalls:[],enemyVariants:{},portalDirections:{},arrivalDirections:{}}};
}
function fixture(into,outward,{initialState=null}={}){
 const a=nativeRoom('main',into),b=nativeRoom('target',opposite[outward]),ap=a.map.geometry[1],bp=b.map.geometry[1],returnSpawn=mouthSpawn(into,ap),targetSpawn=mouthSpawn(opposite[outward],bp);
 a.map.objects.push(object('return-spawn','spawn',returnSpawn.x,returnSpawn.y),mouthPortal(into,ap,'depart','target','arrival'));
 b.map.objects.push(object('arrival','spawn',targetSpawn.x,targetSpawn.y),mouthPortal(opposite[outward],bp,'return','main','return-spawn'));
 a.marioModules.portalDirections.depart={pipeId:'pipe',direction:into};a.marioModules.arrivalDirections['return-spawn']={pipeId:'pipe',direction:opposite[into]};
 b.marioModules.portalDirections.return={pipeId:'pipe',direction:opposite[outward]};b.marioModules.arrivalDirections.arrival={pipeId:'pipe',direction:outward};
 return session([a,b],initialState);
}
function session(rooms,initialState=null){
 rooms.forEach(r=>validateMarioModulesRoom(r));const events=[],trace=[],maps=Object.fromEntries(rooms.map(r=>[r.roomId,r.map])),stage=createPlatformStage({plan:{stage:{entryRoom:'main',entrySpawn:'start',title:'Native directional pipes'},character,rooms:maps},motor:createPlatformMotor(),visualRooms:rooms,initialState,emit:(type,data)=>events.push({type,...data})});
 return {rooms,stage,events,trace,view:()=>stage.view(),step(input={}){trace.push({...input});stage.step(input);return stage.view();},frames(n,input={}){let v=stage.view();for(let i=0;i<n;i++)v=this.step(input);return v;}};
}
const request=direction=>direction==='up'?{up:true,jump:true}:direction==='down'?{down:true}:direction==='left'?{x:-1}:{x:1};
function awaitEntry(h,direction,budget=100){
 for(let n=0;n<budget;n++){const v=h.step(request(direction));if(v.transition?.phase==='enter')return v;}
 const v=h.view();assert.fail('No '+direction+' entry after native input: '+JSON.stringify({p:v.p,roomId:v.roomId,transition:v.transition,trace:h.trace.slice(-budget)}));
}
function finishTransit(h,targetRoom,input={}){
 let exiting=null,prior=null,moving=false;
 for(let n=0;n<240;n++){
  const v=h.step(input);
  if(v.roomId===targetRoom&&v.transition?.phase==='exit'){
   if(!exiting)exiting=v;
   if(prior){const q=v.transition,d=q.smm2Direction,delta=d==='left'||d==='right'?v.p.x-prior.p.x:v.p.y-prior.p.y;if(delta!==0){moving=true;assert.equal(Math.sign(delta),d==='left'||d==='up'?-1:1);assert.ok(Math.abs(delta)<=.5+1e-9);}}
   prior=v;
  }
  if(v.roomId===targetRoom&&!v.transition){assert.ok(exiting,'destination must use a visible exit animation');assert.ok(moving,'destination actor must actually move outward');return {exiting,done:v};}
 }
 assert.fail('No completed '+targetRoom+' exit: '+JSON.stringify({view:h.view(),trace:h.trace.slice(-240)}));
}
function assertOutside(v,pipe,outward){
 const p=v.p;
 if(outward==='up'){assert.equal(p.y+p.h,pipe.y);assert.equal(p.grounded,true);}
 else if(outward==='down'){assert.equal(p.y,pipe.y+pipe.h+2);assert.equal(p.grounded,false);}
 else if(outward==='left'){assert.equal(p.x+p.w,pipe.x-2);assert.equal(p.grounded,false);}
 else{assert.equal(p.x,pipe.x+pipe.w+2);assert.equal(p.grounded,false);}
 if(outward==='up'||outward==='down')assert.equal(p.x+p.w/2,pipe.x+pipe.w/2);else assert.equal(p.y+p.h,pipe.y+pipe.h);
}

for(const into of directions)for(const outward of directions)test(`native ${into} mouth input uses declared ${outward} destination outward animation`,()=>{
 const h=fixture(into,outward,{initialState:{lives:7,coins:9,score:1200}});h.frames(30);const entry=awaitEntry(h,into);assert.equal(entry.transition.smm2Direction,into);assert.equal(entry.transition.targetRoom,'target');const time=entry.timeLeft;
 const {exiting,done}=finishTransit(h,'target');assert.equal(exiting.transition.smm2Direction,outward);assertOutside(done,h.rooms[1].map.geometry[1],outward);assert.equal(done.lives,7);assert.equal(done.coins,9);assert.equal(done.score,1200);assert.equal(done.timeLeft,time);assert.equal(done.p.dying,undefined);assert.equal(h.events.filter(e=>e.type==='room'&&e.roomId==='target').length,1);
});

for(const into of directions)test(`native ${into} pipe returns through the correct opposite mouth without resetting state`,()=>{
 const outward=opposite[into],h=fixture(into,outward,{initialState:{lives:6,power:2,coins:11,score:2300}});h.frames(30);awaitEntry(h,into);const first=finishTransit(h,'target').done;assert.equal(first.p.power,2);assert.equal(first.p.h,28);h.frames(35);const entry=awaitEntry(h,opposite[outward]);const second=finishTransit(h,'main').done;assertOutside(second,h.rooms[0].map.geometry[1],opposite[into]);assert.equal(second.p.power,2);assert.equal(second.p.h,28);assert.equal(second.lives,6);assert.equal(second.coins,11);assert.equal(second.score,2300);assert.equal(second.timeLeft,entry.timeLeft);assert.ok(second.timeLeft<=first.timeLeft);assert.equal(second.p.dying,undefined);
});

for(const into of directions)test(`${into} pipe rejects ordinary input without real mouth registration`,()=>{
 const h=fixture(into,'right'),a=h.rooms[0],pipe=a.map.geometry[1];
 // Build a different native birth fixture before constructing its stage. Its
 // broad portal region overlaps Mario, but the real mouth is not registered.
 const rooms=structuredClone(h.rooms),r=rooms[0],spawn=r.map.objects.find(o=>o.id==='start'),portal=r.map.objects.find(o=>o.id==='depart');spawn.x=40;spawn.y=into==='up'?146:210;Object.assign(portal,{x:0,y:0,w:512,h:256});const q=session(rooms);q.frames(30);
 q.frames(60,request(into));assert.equal(q.view().roomId,'main');assert.equal(q.view().transition,null);assert.equal(q.events.filter(e=>e.type==='room'&&e.roomId==='target').length,0);assert.equal(q.view().lives,3);assert.ok(q.view().p.x+q.view().p.w<pipe.x||into==='left');
});

test('physical Fire/Shellmet/OFF state and spent native timer/lives survive an ordinary side-pipe round trip',()=>{
 const h0=fixture('right','right'),rooms=structuredClone(h0.rooms),a=rooms[0];a.map.objects.find(o=>o.id==='start').x=40;
 a.map.objects.push(object('loose-helmet','walker',40,168,16,16),object('placed-life','walker',40,208,16,16));a.smm2Mechanics.helmets=[{id:'loose-helmet',gravity:0,maxFallSpeed:4}];a.smm2Mechanics.placedItems=[{id:'placed-life',kind:'life',gravity:0,maxFallSpeed:4}];
 for(const r of rooms)r.switchStudy={version:1,initialOn:true,allowBacktracking:true,devices:[{id:'on-off',kind:'switch',x:40,y:144,w:16,h:16},{id:'red',kind:'block',color:'red',x:240,y:160,w:16,h:16},{id:'blue',kind:'block',color:'blue',x:272,y:160,w:16,h:16}]};
 const h=session(rooms,{lives:7,power:2,coins:8,score:1200});h.frames(30);h.frames(24,{jump:true});h.frames(45);const prepared=h.view();assert.equal(prepared.p.helmet,'buzzy');assert.equal(prepared.p.power,2);assert.equal(prepared.switchStudy.on,false);assert.equal(prepared.switchStudy.toggles,1);assert.equal(prepared.lives,8);assert.ok(prepared.timeLeft<400);
 const entry=awaitEntry(h,'right'),first=finishTransit(h,'target').done;assert.equal(first.p.helmet,'buzzy');assert.equal(first.p.power,2);assert.equal(first.p.h,28);assert.equal(first.switchStudy.on,false);assert.equal(first.switchStudy.toggles,1);assert.equal(first.lives,8);assert.equal(first.timeLeft,entry.timeLeft);assert.ok(first.geometry.some(g=>g.id==='blue'));assert.ok(!first.geometry.some(g=>g.id==='red'));
 h.frames(35);const returning=awaitEntry(h,'left'),back=finishTransit(h,'main').done;assert.equal(back.p.helmet,'buzzy');assert.equal(back.p.power,2);assert.equal(back.p.h,28);assert.equal(back.switchStudy.on,false);assert.equal(back.switchStudy.toggles,1);assert.equal(back.lives,8);assert.equal(back.coins,8);assert.equal(back.score,1200);assert.equal(back.timeLeft,returning.timeLeft);assert.equal(h.events.filter(e=>e.type==='sound'&&e.event==='life').length,1);assert.equal(h.events.filter(e=>e.event==='helmet-worn').length,1);assert.equal(h.events.filter(e=>e.type==='room').length,3);
});

for(const into of directions)test(`holding ${into} through one native entrance and opposite exit does not repeatedly swallow Mario`,()=>{
 let h=fixture(into,opposite[into]);
 if(into==='up'){
  // A genuine narrow floor below this downward mouth keeps Mario registered
  // after exit, so held-up re-entry cannot be hidden by falling out of range.
  const rooms=structuredClone(h.rooms),b=rooms[1];b.map.geometry[0].y=144;b.map.geometry[0].h=144;for(const s of b.map.objects.filter(o=>o.kind==='spawn'))s.y=130;h=session(rooms);
 }
 h.frames(30);awaitEntry(h,into);const done=finishTransit(h,'target',request(into)).done;for(let n=0;n<180;n++){const v=h.step(request(into));assert.equal(v.transition?.phase==='enter',false,'held '+into+' restarted enter at tick '+v.tick+' without a release');}assert.equal(h.view().roomId,'target');assert.equal(h.view().transition,null);assert.equal(h.events.filter(e=>e.type==='room').length,2);assert.equal(h.view().lives,done.lives);
 // A deliberate release and new press can start the real return traversal.
 h.frames(2);const entry=awaitEntry(h,into);assert.equal(entry.transition.targetRoom,'main');
});
for(const into of ['left','right'])for(const power of [0,2])test(`side ${into} entry preserves actual ${power?'Fire':'Small'} vertical registration without a pose snap`,()=>{
 const h=fixture(into,'right',{initialState:{lives:3,power}});h.frames(30);const y=h.view().p.y,bottom=y+h.view().p.h,entry=awaitEntry(h,into);assert.equal(entry.p.y,y);assert.equal(entry.p.y+entry.p.h,bottom);const target=finishTransit(h,'target').done,pipe=h.rooms[1].map.geometry[1];assert.equal(target.p.y+target.p.h,pipe.y+pipe.h);
});
