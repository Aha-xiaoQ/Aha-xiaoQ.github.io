// HTMLAudioElement behavior for functional audio lifecycle tests. This models
// restrictive autoplay policies; it does not verify native audio output.
export function installSimulatedAudio({requireGesture=false,rejectFirst=0}={}){
 const original=Object.getOwnPropertyDescriptor(globalThis,'Audio'),instances=[],calls=[];
 let gesture=false,rejections=rejectFirst,defer=0;const pending=[];
 class SimulatedAudio{
  constructor(src=''){this.src=src;this.paused=true;this.currentTime=0;this.loop=false;this.volume=1;this.authorized=false;this.playCalls=0;instances.push(this);}
  play(){this.playCalls++;calls.push({audio:this,src:this.src,loop:this.loop,gesture});
   if(rejections>0){rejections--;return Promise.reject(Object.assign(new Error('Autoplay blocked'),{name:'NotAllowedError'}));}
   if(this.loop&&requireGesture&&!gesture&&!this.authorized)return Promise.reject(Object.assign(new Error('Autoplay blocked'),{name:'NotAllowedError'}));
   if(gesture)this.authorized=true;this.paused=false;if(defer>0){defer--;return new Promise((resolve,reject)=>pending.push({resolve,reject}));}return Promise.resolve();
  }
  pause(){this.paused=true;}
  end(){if(this.loop){this.currentTime=0;return;}this.paused=true;this.onended?.();}
 }
 Object.defineProperty(globalThis,'Audio',{value:SimulatedAudio,writable:true,configurable:true});
 return {instances,calls,pending,deferNext(count=1){defer=count;},gesture(fn){const old=gesture;gesture=true;try{return fn();}finally{gesture=old;}},music:()=>instances.filter(a=>a.loop),restore(){if(original)Object.defineProperty(globalThis,'Audio',original);else delete globalThis.Audio;}};
}
