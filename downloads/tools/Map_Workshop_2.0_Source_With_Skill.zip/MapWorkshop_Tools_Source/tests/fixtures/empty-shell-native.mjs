import {blank} from '../../atlas/editor-model.mjs';
import {nativeSession} from './shell-coin-native.mjs';
export {nativeSession};

// Neutral mechanism fixture, not a course replica or original timing claim.
export function emptyShellProject({coins=[160,192,224],pink=true,vx=0,vy=0,rule=true,wall=false,maxAlive=1,maxEmissions=1,direction='down'}={}){
 const d=blank('Synthetic empty Buzzy shell supply',640,288),r=d.rooms[0];
 r.map.geometry=[{id:'floor',x:0,y:224,w:640,h:64,collision:'solid',material:'ground'},{id:'supply-pipe',x:96,y:112,w:32,h:64,collision:'solid',material:'pipe'}];
 if(wall)r.map.geometry.push({id:'wall',x:320,y:160,w:16,h:64,collision:'solid',material:'stone'});
 r.map.objects=[{id:'start',kind:'spawn',x:32,y:210,w:10,h:14},...coins.map((x,i)=>({id:'coin-'+i,kind:'coin',x,y:208,w:8,h:14}))];
 r.playRules={version:1,timeLimit:600,timerFrames:24,viewportWidth:256,viewportHeight:240,cameraAnchor:100};
 r.smm2Mechanics={version:1,shellCoinCollection:rule,...(pink?{pinkCoins:r.map.objects.filter(q=>q.kind==='coin').map(q=>({id:q.id}))}:{})};
 r.marioModules={version:1,itemSources:[],enemySources:[{id:'empty-supply',pipeId:'supply-pipe',enemy:'beetle-shell',smart:false,direction,emergenceFrames:4,intervalFrames:4,initialDelayFrames:0,maxAlive,maxEmissions,activationDistance:320,vx,vy}],noteBlocks:[],oneWayWalls:[],enemyVariants:{}};
 return d;
}
export function settleEmptyShell(s){return s.until(v=>v.enemies.some(e=>e.moduleSource==='empty-supply'&&!e.moduleEmergence&&e.grounded));}
export function sideKickEmptyShell(s){settleEmptyShell(s);return s.until(v=>v.enemies.some(e=>e.moduleSource==='empty-supply'&&e.vx>1),{x:1,run:true},180);}
