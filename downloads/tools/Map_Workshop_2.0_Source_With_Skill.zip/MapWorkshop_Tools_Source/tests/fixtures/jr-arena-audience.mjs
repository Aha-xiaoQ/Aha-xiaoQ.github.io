import {blank} from '../../atlas/editor-model.mjs';
import {BOWSER_JR_AUTHORING_DEFAULTS,createBowserJrStageTempo} from '../../atlas/editor-bowser-jr.mjs';
import {displayedJrHeadTarget} from './bowser-jr-native.mjs';
/** Neutral tool fixture, independent of any private course generator. */
export function arenaAudienceProject(){
 const d=blank('Neutral solid arena audience',576,432),r=d.rooms[0];r.setting='Castle';
 r.map.geometry=[{id:'floor',x:0,y:392,w:576,h:40,collision:'solid',material:'ground'}];
 const seats=[];
 for(const side of ['left','right'])for(let tier=0;tier<4;tier++){
  const local=tier===0?0:16+tier*16,w=tier===0?32:16,x=side==='left'?local:576-local-w,y=224+tier*24,id=side+'-seat-'+tier;
  r.map.geometry.push({id,x,y,w,h:360-y,collision:'solid',material:'ground'});
  for(let n=0;n<w/16;n++)seats.push({id:side+'-spectator-'+tier+'-'+n,x:x+n*16,y:y-16,w:16,h:16,seatGeometryId:id,facing:side==='left'?1:-1});
 }
 r.map.geometry.push({id:'left-arch',x:80,y:224,w:16,h:136,collision:'solid',material:'ground'},{id:'right-arch',x:480,y:224,w:16,h:136,collision:'solid',material:'ground'});
 r.map.objects=[{id:'start',kind:'spawn',x:35,y:378,w:10,h:14},{id:'junior',kind:'walker',x:288,y:368,w:24,h:24}];
 r.smm2Mechanics={version:1,art:{palette:'smb1-castle-stone'},bowserJuniors:{version:1,actors:[{id:'junior',...BOWSER_JR_AUTHORING_DEFAULTS,initialFireDelayFrames:36000}]},arenaAudience:{version:1,bossId:'junior',sourceParameterStatus:'authored-not-calibrated',seats,exits:[{id:'left-exit',x:52,y:376,direction:1},{id:'right-exit',x:508,y:376,direction:-1}],cheerFrames:96,telegraphFrames:72,waveGapFrames:180,waveCount:3,goombasPerWave:2,maxAlive:3}};
 return d;
}

/** Neutral two-stomp integration isolates actual head contact from fire.
 * The host's real native runners still enter after the second contact. */
export function finalPhaseAudienceProject(){
 const d=arenaAudienceProject(),q=d.rooms[0].smm2Mechanics.bowserJuniors.actors[0];d.rooms[0].smm2Mechanics.enemyRewards=[{id:q.id,reward:'key'}];
 Object.assign(q,{walkSpeed:.4,shellSpeed:2,shellAcceleration:.1,shellFrames:200,revealFrames:24,hitTransitionFrames:16,hitHopSpeed:2.5,pursuitWindupFrames:48,pursuitAimIntervalFrames:24});q.stageTempo=createBowserJrStageTempo(q);q.stageTempo.stages[2].walkSpeed=.45;q.stageTempo.stages[2].shellSpeed=2.25;return d;
}
const axis=(p,target)=>{const d=target-p.x;return Math.abs(d)<1?(Math.abs(p.vx)<.08?0:-Math.sign(p.vx)):Math.sign(d)*p.vx>0&&Math.abs(d)<p.vx*p.vx/(2*.1015625)+1?-Math.sign(p.vx):Math.sign(d);};
/** Only ordinary inputs; every HP change is resolved by the native Stage. */
export function reachNativeAudiencePhase(s,predicate,{budget=1200}={}){
 let hp=3,dir=1,hadJump=false,bounce=true,switched=false,dodgeAge=0,dodge=false,escape=0;
 const rule=s.doc.rooms[0].smm2Mechanics.bowserJuniors.actors[0];
 for(let n=0;n<budget;n++){
  const v=s.view(),p=v.p,e=v.enemies.find(a=>a.id===rule.id);if(predicate(v))return v;if(p.dying||!e)throw Error('Neutral native audience phase ended before target');const st=e.smm2BowserJr,d=e.x+e.w/2-p.x-p.w/2;let input;
  if(st.hp<hp){hp=st.hp;dir=Math.sign(p.vx)||1;bounce=true;switched=false;dodge=false;dodgeAge=0;escape=0;}
  if(st.phase==='shell'&&st.phaseAge>=rule.shellFrames-45){escape ||= p.x+p.w/2<80?1:p.x+p.w/2>496?-1:Math.sign(-d)||dir;input={x:escape,run:true,jump:p.grounded&&!hadJump&&Math.abs(d)<84||!p.grounded&&p.vy<0};}
  else if(['hit-transition','shell-windup'].includes(st.phase))input={x:dir,run:true,jump:!p.grounded&&p.vy<0};
  else if(st.phase==='recovery-shell')input={x:escape||Math.sign(-d)||dir,run:true,jump:!p.grounded&&p.vy<0};
  else if(st.phase==='shell'){
   if(bounce&&!switched){dir=Math.sign(d)||dir;switched=true;}if(p.grounded){bounce=false;dodge=false;dir=Math.sign(d)||dir;}
   const jump=p.grounded&&!hadJump&&Math.abs(d)<48;if(jump){dodge=true;dodgeAge=0;}input={x:dir,run:true,jump:jump||!p.grounded&&p.vy<0&&(!dodge||dodgeAge<30)};
  }else{const target=displayedJrHeadTarget(e).x-p.w/2+e.vx*20,dx=target-p.x,jump=p.grounded&&!hadJump&&Math.abs(dx)<95,finish=p.vy>0&&p.y+p.h>=displayedJrHeadTarget(e).y-16&&Math.abs(dx)<20;input={x:finish?Math.sign(p.vx)||Math.sign(dx):axis(p,target),run:true,jump:jump||!p.grounded};}
  hadJump=!!input.jump;s.step(input);if(dodge)dodgeAge++;
 }
 throw Error('Neutral native audience phase input budget exceeded');
}
