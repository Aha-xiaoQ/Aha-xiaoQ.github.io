/** Minimal synthetic geometry for flag attachment and spectator clearance.
 * No game-level factory or course audience arrangement is imported. */
export function createNeutralGalleryRoom(){
 return {map:{width:576,height:432,geometry:[
  {id:'boss-left-inner-arch',x:96,y:176,w:16,h:48,collision:'solid'},
  {id:'boss-right-inner-arch',x:464,y:176,w:16,h:48,collision:'solid'}
 ]},smm2Mechanics:{arenaAudience:{seats:[
  {id:'seat-a',x:128,y:192,w:16,h:16},
  {id:'seat-b',x:432,y:192,w:16,h:16}
 ]}}};
}
