// Small DOM/action surface for exercising real play module logic without a browser.
// Rendering, native browser layout/fullscreen and physical hardware are not covered.
export function installSimulatedPlayDom({pointer='fine',hover=true,width=1280,height=720,maxTouchPoints=0}={}){
 const originals=new Map(),set=(key,value)=>{originals.set(key,Object.getOwnPropertyDescriptor(globalThis,key));Object.defineProperty(globalThis,key,{value,writable:true,configurable:true});};
 let now=0,rafId=0;const rafs=new Map(),pads=[];
 class Events{listeners=new Map();addEventListener(type,fn){const entries=this.listeners.get(type)||[];entries.push(fn);this.listeners.set(type,entries);}removeEventListener(type,fn){this.listeners.set(type,(this.listeners.get(type)||[]).filter(f=>f!==fn));}dispatchEvent(event){event.target??=this;event.preventDefault??=()=>{};event.stopPropagation??=()=>{};for(const fn of this.listeners.get(event.type)||[])fn(event);this['on'+event.type]?.(event);return true;}}
 function match(el,selector){const attrs=[...selector.matchAll(/\[([^=\]]+)(?:=["']?([^\]"']+)["']?)?\]/g)];selector=selector.replace(/\[[^\]]+\]/g,'');const id=selector.match(/#([\w-]+)/)?.[1];selector=selector.replace(/#[\w-]+/g,'');const tag=selector.match(/^[\w-]+/)?.[0],classes=[...selector.matchAll(/\.([\w-]+)/g)].map(m=>m[1]);if(id&&el.id!==id)return false;if(tag&&el.tag!==tag)return false;if(classes.some(c=>!el.classList.contains(c)))return false;return attrs.every(([,key,value])=>{const actual=key==='open'?el.open:key.startsWith('data-')?el.dataset[key.slice(5).replace(/-([a-z])/g,(_,c)=>c.toUpperCase())]:el.getAttribute(key);return value===undefined?actual!==undefined&&actual!==null&&actual!==false:String(actual)===value;});}
 class Element extends Events{
  constructor(tag){super();this.tag=tag;this.children=[];this.parentNode=null;this.style={cssText:''};this.dataset={};this.attributes={};this.hidden=false;this.disabled=false;this.className='';this._text='';this.value='';this.classList={contains:c=>this.className.split(/\s+/).includes(c),add:c=>{if(!this.classList.contains(c))this.className+=' '+c;},remove:c=>{this.className=this.className.split(/\s+/).filter(q=>q!==c).join(' ');},toggle:(c,force)=>{const yes=force??!this.classList.contains(c);yes?this.classList.add(c):this.classList.remove(c);return yes;}};}
  append(...nodes){for(let node of nodes){if(typeof node==='string')node=Object.assign(new Element('#text'),{_text:node});node.parentNode=this;this.children.push(node);}}
  prepend(...nodes){const old=this.children;this.children=[];this.append(...nodes,...old);}
  replaceChildren(...nodes){this.children=[];this._text='';this.append(...nodes);}
  insertBefore(node,before){const index=this.children.indexOf(before);node.parentNode=this;this.children.splice(index<0?this.children.length:index,0,node);}
  replaceWith(node){if(this.parentNode){const i=this.parentNode.children.indexOf(this);node.parentNode=this.parentNode;this.parentNode.children[i]=node;}}
  get lastChild(){return this.children.at(-1);}
  get textContent(){return this._text+this.children.map(c=>c.textContent).join('');}
  set textContent(text){this._text=String(text);this.children=[];}
  set innerHTML(html){this.children=[];this._text='';const stack=[this];for(const token of html.match(/<[^>]*>|[^<]+/g)||[]){if(token.startsWith('</'))stack.pop();else if(token.startsWith('<')){const tag=token.match(/^<([\w-]+)/)?.[1];if(!tag)continue;const child=new Element(tag);for(const [,name,value]of token.matchAll(/([\w-]+)="([^"]*)"/g))child.setAttribute(name,value);stack.at(-1).append(child);if(!/^(img|br|input)$/.test(tag))stack.push(child);}else stack.at(-1).append(token);}}
  setAttribute(name,value){this.attributes[name]=String(value);if(name==='class')this.className=String(value);if(name==='id')this.id=String(value);if(name.startsWith('data-'))this.dataset[name.slice(5).replace(/-([a-z])/g,(_,c)=>c.toUpperCase())]=String(value);}
  getAttribute(name){return name==='class'?this.className:this.attributes[name];}
  querySelectorAll(selector){const parts=selector.split(/\s+/),all=[];const visit=(node,part)=>{for(const child of node.children){if(match(child,parts[part])){if(part===parts.length-1)all.push(child);else visit(child,part+1);}visit(child,part);}};visit(this,0);return [...new Set(all)];}
  querySelector(selector){return this.querySelectorAll(selector)[0]||null;}
  cloneNode(){const clone=new Element(this.tag);clone.style={...this.style};clone.className=this.className;return clone;}
  add(option){this.append(option);if(!this.value)this.value=option.value;}
  focus(){document.activeElement=this;}
  click(){if(!this.disabled)this.dispatchEvent({type:'click',target:this});}
  setPointerCapture(){}
  showModal(){this.open=true;}
  close(){this.open=false;this.dispatchEvent({type:'close'});}
  remove(){if(this.parentNode)this.parentNode.children=this.parentNode.children.filter(c=>c!==this);}
  getContext(){return new Proxy({createImageData:(w,h)=>({data:new Uint8ClampedArray(w*h*4)}),getImageData:(_x,_y,w,h)=>({data:new Uint8ClampedArray(w*h*4).fill(255)}),measureText:text=>({width:String(text).length*8,actualBoundingBoxLeft:0,actualBoundingBoxAscent:7,actualBoundingBoxDescent:1})},{get:(target,key)=>target[key]??(()=>{})});}
 }
 const document=new Events();document.body=new Element('body');document.head=new Element('head');document.fonts={add(){}};document.hidden=false;document.fullscreenEnabled=false;document.createElement=tag=>new Element(tag);document.createTextNode=text=>Object.assign(new Element('#text'),{_text:text});document.querySelector=selector=>document.body.querySelector(selector)||document.head.querySelector(selector);document.querySelectorAll=selector=>[...document.body.querySelectorAll(selector),...document.head.querySelectorAll(selector)];document.getElementById=id=>[document.body,document.head].flatMap(root=>root.querySelectorAll('[id]')).find(el=>el.id===id)||null;
 const window=new Events(),mediaQueries=[];window.innerWidth=width;window.innerHeight=height;
 const capabilities={pointer,hover,maxTouchPoints};
 const mediaMatches=query=>query.includes('pointer: fine')?capabilities.pointer==='fine':query.includes('pointer: coarse')?capabilities.pointer==='coarse':query.includes('hover: hover')?capabilities.hover:query.includes('hover: none')?!capabilities.hover:query.includes('max-width: 900px')?window.innerWidth<=900:false;
 window.matchMedia=query=>{const media=new Events();media.media=query;Object.defineProperty(media,'matches',{get:()=>mediaMatches(query)});mediaQueries.push(media);return media;};
 const navigator={getGamepads:()=>pads,get maxTouchPoints(){return capabilities.maxTouchPoints;}};
 const setInputCapabilities=next=>{const previous=mediaQueries.map(media=>media.matches);Object.assign(capabilities,next);if(next.width!==undefined)window.innerWidth=next.width;if(next.height!==undefined)window.innerHeight=next.height;mediaQueries.forEach((media,index)=>{if(media.matches!==previous[index])media.dispatchEvent({type:'change',matches:media.matches,media:media.media});});window.dispatchEvent({type:'resize'});};
 set('window',window);set('document',document);set('navigator',navigator);set('performance',{now:()=>now});set('requestAnimationFrame',fn=>{rafs.set(++rafId,fn);return rafId;});set('cancelAnimationFrame',id=>rafs.delete(id));set('FontFace',class{load(){return Promise.resolve(this);}});set('Image',class{async decode(){return this;}});set('Audio',class{paused=true;async play(){this.paused=false;}pause(){this.paused=true;}});set('Option',class extends Element{constructor(label,value){super('option');this.textContent=label;this.value=value;}});
 return {document,window,pads,Element,mediaQueries,setInputCapabilities,frames(count=1){for(let i=0;i<count;i++){now+=1000/60;const active=[...rafs.values()];rafs.clear();for(const fn of active)fn(now);}},key(code,repeat=false){window.dispatchEvent({type:'keydown',code,repeat,target:document.activeElement});},release(code){window.dispatchEvent({type:'keyup',code});},restore(){for(const [key,descriptor]of originals){if(descriptor)Object.defineProperty(globalThis,key,descriptor);else delete globalThis[key];}}};
}
