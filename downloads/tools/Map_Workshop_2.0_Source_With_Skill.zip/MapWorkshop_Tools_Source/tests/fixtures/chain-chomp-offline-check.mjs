/** Execute a synthetic neutral guard HTML's embedded runtime in a VM, using its
 * real pack/rooms and ordinary inputs. This checks module closure, not an
 * real-browser or hardware acceptance claim. Run with --experimental-vm-modules. */
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {createContext,SourceTextModule,runInContext} from 'node:vm';
import {createCanvas} from '@napi-rs/canvas';
import {inspectOfflineHtml} from '../../scripts/check-offline-html.mjs';
import {createStageCatalog} from '../../atlas/runtime/stage-catalog.mjs';
import {createPlatformStage} from '../../atlas/editor-mario-stage.mjs';
import {createPlatformMotor} from '../../atlas/editor-mario-motor.mjs';
import {drawObject} from '../../atlas/editor-art.mjs';
import {resolveSmm2LightSources} from '../../atlas/editor-smm2-lighting.mjs';
import {requiredCollectionCapabilities} from '../../atlas/editor-collection.mjs';

const normalized=value=>JSON.parse(JSON.stringify(value));
const head=view=>view.enemies.find(q=>q.id==='guard-head');
const pixels=canvas=>canvas.getContext('2d').getImageData(0,0,canvas.width,canvas.height).data;

export async function checkChainChompOfflineHtml(html,{collection=false}={}){
 const checked=inspectOfflineHtml(html,{collection});
 let payload;
 if(collection){
  const found=checked.root.match(/const collection=(\{[\s\S]*?\}),media=/);assert(found,'actual collection bootstrap data');
  const built=JSON.parse(found[1]);assert(built.requiredCapabilities.includes('authored-chain-chomp-guard-v1'));
  assert.equal(built.levels.length,1);payload=built.levels[0];
 }else{
  const found=checked.root.match(/const pack=(\{[\s\S]*?\}),rooms=(\[[\s\S]*?\]),media=/);assert(found,'actual single-player bootstrap data');
  payload={pack:JSON.parse(found[1]),rooms:JSON.parse(found[2])};
 }
 assert(requiredCollectionCapabilities({rooms:payload.rooms}).includes('authored-chain-chomp-guard-v1'));
 assert(checked.modules.has('workshop/editor-chain-chomp-guard.mjs'));
 assert(checked.modules.has('workshop/editor-chain-chomp-guard-art.mjs'));
 assert(!checked.modules.has('workshop/editor-chain-chomp-guard-tools.mjs'),'offline runtime excludes editor-only tools');
 let networkRequests=0;
 const context=createContext({console,URL,TextEncoder,TextDecoder,Uint8Array,structuredClone,crypto:globalThis.crypto,
  document:{createElement(tag){assert.equal(tag,'canvas');return createCanvas(1,1);}},
  fetch(){networkRequests++;throw Error('Unexpected offline network request');},
 });
 const modules=new Map([...checked.modules].map(([id,source])=>[id,new SourceTextModule(source,{context,identifier:id})]));
 const link=id=>{assert(modules.has(id),'actual embedded dependency '+id);return modules.get(id);};
 const stage=modules.get('workshop/editor-mario-stage.mjs'),motor=modules.get('workshop/editor-mario-motor.mjs'),art=modules.get('workshop/editor-art.mjs'),light=modules.get('workshop/editor-smm2-lighting.mjs');
 for(const module of [stage,motor,art,light]){if(module.status==='unlinked')await module.link(link);if(module.status==='linked')await module.evaluate();}
 const Stage=options=>{
  context.stageOptions=JSON.stringify({...options,motor:undefined,emit:undefined});
  return stage.namespace.createPlatformStage({...runInContext('JSON.parse(stageOptions)',context),motor:options.motor,emit:options.emit});
 };
 const plan=createStageCatalog(payload.pack).plan(payload.pack.stages[0].id,payload.pack.characters[0].id,{allowDraft:true});
 let frames=0,rasters=0,eventComparisons=0,movingLightFrames=0;
 function session({embedded=false,spawnX}={}){
  const rooms=normalized(payload.rooms),localPlan=normalized(plan);
  if(spawnX!==undefined){
   rooms[0].map.objects.find(q=>q.kind==='spawn').x=spawnX;
   localPlan.rooms[rooms[0].roomId].objects.find(q=>q.kind==='spawn').x=spawnX;
  }
  const events=[];let frame=0;
  const host=(embedded?Stage:createPlatformStage)({plan:localPlan,motor:(embedded?motor.namespace.createPlatformMotor:createPlatformMotor)(),visualRooms:rooms,initialState:{power:0,lives:5},manualDeath:true,autoContinue:false,allowWarp:false,emit:(type,data)=>events.push({frame:frame+1,type,...data})});
  return {stage:host,events,rooms,step(raw={}){host.step(raw);frame++;return host.view();},view:()=>host.view()};
 }
 function pair(options={}){
  const native=session(options),embedded=session({...options,embedded:true});
  context.roomData=JSON.stringify(embedded.rooms[0]);const vmRoom=runInContext('JSON.parse(roomData)',context);
  function compare(){assert.deepEqual(normalized(embedded.view()),normalized(native.view()),'actual embedded Stage/motor view matches native at every tick');assert.deepEqual(normalized(embedded.events),normalized(native.events),'actual embedded emitted events match native at every tick');eventComparisons++;}
  compare();
  return {native,embedded,step(raw={}){
   const a=native.step(raw),b=embedded.step(raw);frames++;compare();
   const actor=head(b);assert(actor,'same stable real head survives runtime ownership');
   const actualSources=light.namespace.resolveSmm2LightSources(vmRoom,b),expectedSources=resolveSmm2LightSources(native.rooms[0],a);
   assert.deepEqual(normalized(actualSources),normalized(expectedSources));
   const moving=actualSources.find(q=>q.targetId==='guard-head');assert(moving,'guard remains a live light target');
   assert.equal(moving.x,actor.x+actor.w/2);assert.equal(moving.y,actor.y+actor.h/2);
   const home=vmRoom.contraptions.chainChompGuards[0].rest;if(Math.abs(moving.x-home.x)>.01||Math.abs(moving.y-home.y)>.01)movingLightFrames++;
   if(frames%16===0){
    const actual=createCanvas(384,216),expected=createCanvas(384,216),ca=actual.getContext('2d'),ce=expected.getContext('2d');
    ca.translate(-Math.round(b.cam),-216);ce.translate(-Math.round(a.cam),-216);
    art.namespace.drawObject(ca,actor,b.tick,{...vmRoom,contraptionsView:b.contraptions});
    drawObject(ce,head(a),a.tick,{...native.rooms[0],contraptionsView:a.contraptions});
    assert.deepEqual(pixels(actual),pixels(expected),'actual embedded shared head/post/chain renderer matches native');
    assert(pixels(actual).some((value,index)=>index%4===3&&value>0),'real shared art produces visible pixels');rasters++;
   }
   return b;
  },compare};
 }
 // Normal Small Mario watches the same public cue, then runs and holds Jump.
 const safe=pair();let safeExitFrame=null,safeCompletedFrame=null;
 for(let frame=0;frame<900;frame++){
  const view=safe.step(frame<52?{}:{x:1,run:true,jump:frame<116});
  assert(!view.p.dying,'watch52/run+jump64 route survives ordinary head contact');
  assert.equal(view.p.power,0);assert.equal(view.p.h,14,'ordinary Small body');
  if(frame===47){assert.equal(head(view).chainChompGuard.phase,'windup');assert.equal(head(view).chainChompGuard.openMouth,true);}
  if(frame===77)assert.equal(head(view).chainChompGuard.phase,'lunge');
  if(frame===95)assert.equal(head(view).chainChompGuard.phase,'retract');
  if(view.finish&&!safeExitFrame){safeExitFrame=frame+1;assert.equal(view.coins,1,'the same real coin is physically collected before exit');}
  if(view.completed){safeCompletedFrame=frame+1;break;}
 }
 assert(safeExitFrame,'ordinary input reaches the real native exit');
 assert(safeCompletedFrame,'legal native ending reaches completed state');
 assert.equal(safe.native.events.filter(q=>q.type==='chain-chomp-guard'&&q.event==='head-contact').length,0);
 assert(safe.native.events.some(q=>q.type==='complete'&&q.result==='cleared'));
 // The same Small, same geometry and damage rule punish an immediate rush.
 const rushed=pair();let deathFrame=null;
 for(let frame=1;frame<=100;frame++){const view=rushed.step({x:1,run:true});if(view.p.dying){deathFrame=frame;break;}}
 assert.equal(deathFrame,39);assert.equal(rushed.embedded.view().lives,4);assert.equal(rushed.embedded.view().coins,0);
 assert.equal(rushed.embedded.events.filter(q=>q.type==='chain-chomp-guard'&&q.event==='head-contact').length,1);
 const frozenDeathHead=normalized(head(rushed.embedded.view()));
 for(let frame=0;frame<110;frame++){const view=rushed.step({});assert.deepEqual(normalized(head(view)),frozenDeathHead,'death animation freezes the real guard');}
 assert.equal(rushed.native.stage.continueFromCurrent(),true);assert.equal(rushed.embedded.stage.continueFromCurrent(),true);rushed.compare();
 const reset=rushed.embedded.view(),resetHead=head(reset),rule=rushed.embedded.rooms[0].contraptions.chainChompGuards[0];
 assert.equal(reset.lives,4);assert.equal(reset.p.power,0);assert.equal(reset.p.dying,undefined);
 assert.deepEqual({x:resetHead.x+16,y:resetHead.y+16},rule.rest);
 assert.equal(resetHead.chainChompGuard.phase,'idle');assert.equal(resetHead.chainChompGuard.phaseFrame,0);assert.equal(resetHead.chainChompGuard.cycle,0);assert.equal(resetHead.chainChompGuard.lastTick,null);
 for(let frame=0;frame<20;frame++)rushed.step({});assert.equal(head(rushed.embedded.view()).chainChompGuard.phaseFrame,20,'continue restarts the same finite guard lifecycle');
 // Pause a visibly moving right lunge while safely beyond its maximum reach.
 const paused=pair({spawnX:195});for(let frame=0;frame<84;frame++)paused.step({});
 assert.equal(head(paused.embedded.view()).chainChompGuard.phase,'lunge');
 const frozenPauseHead=normalized(head(paused.embedded.view()));paused.native.stage.pause();paused.embedded.stage.pause();
 for(let frame=0;frame<12;frame++){const view=paused.step({});assert.deepEqual(normalized(head(view)),frozenPauseHead,'pause freezes the moving real head and its live light');}
 paused.native.stage.resume();paused.embedded.stage.resume();for(let frame=0;frame<3;frame++)paused.step({});
 assert.notDeepEqual(normalized(head(paused.embedded.view())),frozenPauseHead,'resume advances the same real head again');
 assert(movingLightFrames>30,'tested sources actually follow a moving head');assert(rasters>20);assert.equal(networkRequests,0);
 return {collection,actualEmbeddedStageExecuted:true,actualEmbeddedMotorExecuted:true,actualEmbeddedSharedArtExecuted:true,everyNativeTickAndEventMatches:true,authoredGuardCapability:true,liveLightFollowsMovingHead:true,pauseFreeze:true,deathFreeze:true,continueReset:true,safeExitFrame,safeCompletedFrame,deathFrame,frames,rasters,eventComparisons,movingLightFrames,networkRequests,moduleCount:checked.moduleCount};
}

if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const report=await checkChainChompOfflineHtml(fs.readFileSync(process.argv[2],'utf8'),{collection:process.argv[3]==='collection'});
 process.stdout.write(JSON.stringify(report)+'\n');
}
