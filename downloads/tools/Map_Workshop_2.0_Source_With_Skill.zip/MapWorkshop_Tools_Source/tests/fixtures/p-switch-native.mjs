import assert from 'node:assert/strict';
import {blank} from '../../atlas/editor-model.mjs';
import {addSmm2Component} from '../../atlas/editor-smm2-authoring.mjs';
import {nativeSession} from './shell-coin-native.mjs';
import {resolveSmm2LightSources} from '../../atlas/editor-smm2-lighting.mjs';

export function pSwitchProject(orientation='up'){
 const d=blank('Neutral authored P Switch',640,288),r=d.rooms[0];r.map.geometry=[{id:'floor',x:0,y:224,w:640,h:64,collision:'solid',material:'ground'},{id:'empty-brick',x:208,y:144,w:16,h:16,collision:'solid',material:'brick'},{id:'content-brick',x:240,y:144,w:16,h:16,collision:'solid',material:'brick',reward:'star'}];r.map.objects=[{id:'start',kind:'spawn',x:98,y:orientation==='up'?32:210,w:10,h:14},{id:'coin',kind:'coin',x:176,y:208,w:16,h:16}];
 if(orientation==='down')r.map.geometry.push({id:'ceiling',x:64,y:128,w:96,h:16,collision:'solid',material:'stone'});
 addSmm2Component(r,'pSwitch',{id:'stable-p',x:96,y:orientation==='up'?208:144,orientation,gravity:0});r.smm2Mechanics.lighting={darkness:.85,playerRadius:24,sources:[{targetId:'stable-p',radius:48}]};return d;
}
export function assertPStage(doc,{Stage,Motor,resolve=resolveSmm2LightSources}={}){
 const s=nativeSession(doc,{...(Stage?{Stage}:{}),...(Motor?{Motor}: {})}),r=s.doc.rooms[0],orientation=r.smm2Mechanics.pSwitches[0].orientation;
 assert.equal(s.view().enemies.length,0);assert(s.view().items.find(q=>q.id==='stable-p'));assert(resolve(r,s.view()).some(q=>q.targetId==='stable-p'));
 const v=s.until(v=>v.contraptions?.pFrames>0,orientation==='down'?{jump:true}:{},100),item=v.items.find(q=>q.id==='stable-p');assert(item?.pressed);assert.equal(item.h,4);assert.equal(v.contraptions.pFrames,600);assert(v.geometry.find(q=>q.id==='empty-brick').hidden);assert(!v.geometry.find(q=>q.id==='content-brick').hidden);assert(v.geometry.some(q=>q.sourceCoinId==='coin'));assert(resolve(r,v).some(q=>q.targetId==='stable-p'));
 const event=s.events.find(q=>q.event==='p-pressed');assert(event);assert.equal(event.orientation,orientation);assert.equal(event.itemId,'stable-p');assert.equal(event.contact.kind,orientation==='down'?'head':'foot');
 s.frames(599);assert.equal(s.view().contraptions.pFrames,1);assert(s.view().items.some(q=>q.id==='stable-p'));s.step();assert.equal(s.view().contraptions.pFrames,0);assert(!s.view().items.some(q=>q.id==='stable-p'));assert(!resolve(r,s.view()).some(q=>q.targetId==='stable-p'));assert(!s.view().geometry.find(q=>q.id==='empty-brick').hidden);assert(!s.view().geometry.some(q=>q.sourceCoinId==='coin'));assert.equal(s.events.filter(q=>q.event==='p-pressed').length,1);return {orientation,contact:event.contact.kind,frames:s.view().tick,stableId:true,expiredRemoved:true,lightExpired:true,originalTimingCalibrated:false};
}
