// A synthetic DOM around real @napi-rs/canvas pixels. Native browser layout,
// fullscreen, custom image loading and hardware input remain outside this QA.
import {createCanvas} from '@napi-rs/canvas';
import {installSimulatedPlayDom} from './simulated-play-dom.mjs';
import {lightingProject} from './lighting-native.mjs';
import {projectPack} from '../../atlas/editor-runtime.mjs';
import {character} from './shell-coin-native.mjs';

export function installLightingRenderDom(){
 const ui=installSimulatedPlayDom(),original=ui.document.createElement,canvases=[];
 ui.document.createElement=tag=>{
  const element=original(tag);if(tag!=='canvas')return element;
  const actual=createCanvas(300,150),ctx=actual.getContext('2d'),calls=[];
  element.actualCanvas=actual;element.drawCalls=calls;canvases.push(element);
  for(const key of ['width','height'])Object.defineProperty(element,key,{get:()=>actual[key],set:value=>actual[key]=value,configurable:true});
  const context=new Proxy(ctx,{
   get(target,key){
    if(key==='drawImage')return(source,...args)=>{
     const image=source?.actualCanvas??source;
     if(!image||typeof image.getContext!=='function')return; // Synthetic logo Image is intentionally outside pixel evidence.
     calls.push({kind:'image',sourceWidth:image.width,sourceHeight:image.height,args:[...args]});target.drawImage(image,...args);
    };
    if(key==='fillRect')return(x,y,w,h)=>{const t=target.getTransform();calls.push({kind:'rect',fill:target.fillStyle,x:t.a*x+t.c*y+t.e,y:t.b*x+t.d*y+t.f,w:w*t.a,h:h*t.d});target.fillRect(x,y,w,h);};
    const value=Reflect.get(target,key,target);return typeof value==='function'?value.bind(target):value;
   },
   set(target,key,value){Reflect.set(target,key,value,target);return true;},
  });
  element.getContext=()=>context;return element;
 };
 return {...ui,canvases};
}

/** Execute the real native play renderer on identical native tick-60 states. */
export async function renderLightingPlayPair({Play,doc=lightingProject({setting:'Overworld'}),ui:providedUi}={}){
 const ui=providedUi??installLightingRenderDom();let session;
 try{
  const play=Play??(await import('../../atlas/editor-play.mjs')).play;
  const darkDoc=structuredClone(doc);darkDoc.rooms[0].smm2Mechanics.lighting.darkness=1;darkDoc.rooms[0].smm2Mechanics.lighting.playerRadius=24;
  const offDoc=structuredClone(darkDoc);delete offDoc.rooms[0].smm2Mechanics.lighting;
  const capture=async(project,load=false)=>{
   const pack=projectPack(project,project.rooms[0].roomId,character,'lighting-pixel-play');
   if(load)await session.load(pack,project.rooms,{developerMode:false});else session=await play(pack,project.rooms,{}, {developerMode:false});
   const output=session.screen.querySelector('canvas');let frames=0;
   while(output.workshopRead().tick<60){ui.frames();if(++frames>90)throw Error('Native play did not reach tick 60');}
   output.drawCalls.length=0;ui.key('KeyP');ui.frames();ui.release('KeyP');
   const canvas=createCanvas(output.width,output.height);canvas.getContext('2d').drawImage(output.actualCanvas,0,0);
   return {canvas,calls:structuredClone(output.drawCalls),view:output.workshopRead()};
  };
  const dark=await capture(darkDoc),off=await capture(offDoc,true);return {dark,off,customLogoIncluded:false,browserLayoutVerified:false};
 }finally{session?.close();if(!providedUi)ui.restore();}
}
