import {blank} from '../../atlas/editor-model.mjs';
/** Neutral reusable tool fixture. No private course geometry or route import. */
export function skyShooterProject(){
 const d=blank('Neutral original armed-cloud arcade',576,384),r=d.rooms[0];
 r.map.geometry=[{id:'floor',x:0,y:352,w:576,h:32,collision:'solid',material:'ground'},{id:'boarding-pad',x:88,y:320,w:48,h:8,collision:'oneway',material:'stone'},{id:'reward-gate',x:496,y:0,w:16,h:352,collision:'solid',material:'stone'}];
 r.map.objects=[{id:'start',kind:'spawn',x:35,y:338,w:10,h:14},{id:'drone-a',kind:'walker',x:208,y:120,w:16,h:16},{id:'drone-b',kind:'walker',x:304,y:136,w:16,h:16},{id:'drone-c',kind:'walker',x:400,y:120,w:16,h:16},{id:'reward-pink',kind:'coin',x:536,y:328,w:10,h:14}];
 r.smm2Mechanics={version:1,pinkCoins:[{id:'reward-pink'}],lakituClouds:{version:1,clouds:[{id:'ride',x:112,y:288,w:20,h:16,acceleration:.16,maxSpeed:2,drag:.125,seatOffsetY:-4,boardTolerance:2,hoverAmplitude:0,hoverPeriodFrames:120}]},skyShooter:{version:1,cloudId:'ride',activation:{x:176,y:96,w:320,h:240},gateIds:['reward-gate'],rewardId:'reward-pink',drones:[{id:'drone-a',wave:1,x:208,y:120,phaseFrames:0},{id:'drone-b',wave:1,x:304,y:136,phaseFrames:0},{id:'drone-c',wave:2,x:400,y:120,phaseFrames:0}],weapon:{cooldownFrames:12,speed:8,lifeFrames:96,maxShots:8},formation:{amplitudeX:0,amplitudeY:0,periodFrames:240,waveDelayFrames:24},attack:{firstAttackFrames:48,intervalFrames:120,telegraphFrames:48,diveSpeed:2,diveTurnFrames:84,missileSpeed:1.8,missileLifeFrames:240,maxMissiles:2}}};
 return d;
}
export function skyShooterBodies(r=skyShooterProject().rooms[0]){return r.map.objects.filter(q=>q.kind==='walker').map(q=>({...structuredClone(q),type:'goomba',dead:false,vx:0,vy:0,grounded:false}));}
