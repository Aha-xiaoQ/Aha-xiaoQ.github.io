import assert from 'node:assert/strict';
import {coinCraneProject,ordinaryCranePress,craneView} from './coin-crane-native.mjs';

export const liveKoopaRule={kind:'walking-koopa',color:'green',size:'normal',walkSpeed:.5,direction:1,flippedRecoveryFrames:550,shellRecoveryFrames:600,stompPoints:200,kickPoints:200,bumpPoints:200,sourceParameterStatus:'authored-not-calibrated'};
/** Real native bodies and ordinary Stage input. Dimensions/arcade timing are
 * authored workshop choices; existing native NPC walking/contact stays native. */
export function liveCoinCraneProject({kind='large-coin',initialX=246,outsideCoin=true,doors=false,bomb=false}={}){
 const d=coinCraneProject({initialX,doors}),r=d.rooms[0],q=r.contraptions.coinCranes[0];
 r.map.geometry=r.map.geometry.filter(g=>['floor','push'].includes(g.id));
 const pink=r.map.objects.find(o=>o.id===q.coinId);pink.x=304;
 q.payment={price:1,entryBonus:0,trigger:'approach',slotId:'slot',slot:{x:96,y:176,w:16,h:16}};
 q.cabinet={x:176,y:32,w:176,h:176};
 const dimensions=kind==='large-coin'?{x:244,y:136,w:32,h:32}:kind==='live-koopa'?{x:252,y:144,w:16,h:24}:{x:252,y:152,w:16,h:16};
 const prize={id:'live-prize',kind:kind==='large-coin'?'coin':'walker',...dimensions};
 r.map.objects.push(prize);q.payloads=[{id:prize.id,kind}];
 r.marioModules={version:1,itemSources:[],noteBlocks:[],oneWayWalls:[],enemyVariants:{},coinValues:{}};
 if(kind==='large-coin')r.marioModules.coinValues[prize.id]=10;
 if(kind==='live-goomba')r.markers.push({id:prize.id,kind:'enemy-goomba',x:prize.x,y:prize.y,source:{thing:'Goomba'}});
 if(kind==='live-koopa')r.marioModules.enemyVariants[prize.id]={...liveKoopaRule};
 if(outsideCoin){r.map.objects.push({id:'outside-ten',kind:'coin',x:16,y:176,w:32,h:32});r.marioModules.coinValues['outside-ten']=10;}
 if(bomb){r.map.objects.push({id:'live-bomb',kind:'crate',x:288,y:96,w:16,h:16});q.payloads.push({id:'live-bomb',kind:'bomb'});}
 return d;
}
/** A reproducible ordinary-input route. No teleport, direct controller call,
 * artificial reward, inventory spawn or body-coordinate edit is used. */
export function preparePaidLiveCraneCycle(s,{target=260}={}){
 assert.equal(s.view().coins,0,'room entry has no automatic gift');s.frames(3);assert.equal(s.view().coins,0);
 s.until(v=>v.coins===10,{x:-1},120);assert(!s.view().objects.some(o=>o.id==='outside-ten'));assert.equal(s.events.filter(e=>e.type==='coin-wallet'&&e.event==='entry-grant').length,0);
 s.until(v=>v.coins===9,{x:1},120);s.until(v=>v.p.grounded&&Math.abs(v.p.x-67)<1.5,v=>({x:v.p.x>68?-1:v.p.x<66?1:0}),160);s.frames(12);
 assert.equal(s.view().coins,9);assert.equal(s.events.filter(e=>e.type==='coin-crane'&&e.event==='payment-accepted').length,1);
 s.until(v=>v.contraptions.coinCranes[0].direction===1&&v.contraptions.coinCranes[0].grip.x>=target-9.5&&v.contraptions.coinCranes[0].grip.x<=target-8.75,{},600);
 ordinaryCranePress(s);assert.equal(craneView(s).cycle,1);assert.equal(s.view().coins,9);
}
