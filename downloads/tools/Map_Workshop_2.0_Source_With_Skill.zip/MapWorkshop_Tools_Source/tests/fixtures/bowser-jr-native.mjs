import assert from 'node:assert/strict';
import {blank} from '../../atlas/editor-model.mjs';
import {BOWSER_JR_AUTHORING_DEFAULTS,bowserJrVisibleFrame} from '../../atlas/editor-bowser-jr.mjs';
export function bowserJrProject({fireDelay=36000,perches=true,spawn={x:300,y:170}}={}){
 const d=blank('Neutral normal ground Bowser Jr',640,320),r=d.rooms[0];
 r.map.geometry=[{id:'floor',x:0,y:288,w:640,h:32,collision:'solid',material:'ground'}];
 if(perches)r.map.geometry.push({id:'left-perch',x:192,y:230,w:80,h:8,collision:'oneway',material:'platform'},{id:'right-perch',x:368,y:230,w:80,h:8,collision:'oneway',material:'platform'});
 r.map.objects=[{id:'start',kind:'spawn',...spawn,w:10,h:14},{id:'junior',kind:'walker',x:300,y:264,w:24,h:24}];
 r.smm2Mechanics={version:1,startingLives:5,art:{palette:'smb1-overworld-source'},bowserJuniors:{version:1,actors:[{id:'junior',...BOWSER_JR_AUTHORING_DEFAULTS,initialFireDelayFrames:fireDelay}]},enemyRewards:[{id:'junior',reward:'key'}]};return d;
}
/** Read the displayed, mirrored head crest rather than guessing an offset
 * inside the actor box. This is observational steering, not actor mutation. */
export function displayedJrHeadTarget(actor){
 const frame=bowserJrVisibleFrame(actor),im=frame.image;let top=Infinity,columns=[];
 for(let row=0;row<Math.min(12,im.h);row++)for(let col=0;col<Math.min(19,im.w);col++)if(parseInt(im.rows[row][col],36)){
  if(row<top){top=row;columns=[];}
  if(row===top)columns.push(frame.x+(frame.facing>0?im.w-1-col:col)+.5);
 }
 assert(columns.length,'displayed Jr head has opaque pixels');
 return {x:columns.reduce((sum,x)=>sum+x,0)/columns.length,y:frame.y+top};
}
/** Every transition is produced by genuine Small movement and contact. The
 * fixture uses a long authored firing delay to isolate the three-stomp cycle;
 * separate native/embedded checks exercise the aimed circular projectile. */
export function threeNativeJrStomps(s){
 const shellFrames=s.doc.rooms[0].smm2Mechanics.bowserJuniors.actors.find(q=>q.id==='junior').shellFrames;
 for(let n=0;n<1800;n++){
  const v=s.view(),p=v.p,e=v.enemies.find(e=>e.id==='junior');if(!e)return v;assert(!p.dying,'ordinary Small route stays alive');
  const phase=e.smm2BowserJr.phase;let input;
  if(['shell','recovery-shell','hit-transition'].includes(phase)){
   // Bait the pursuit toward the perch edge before the recovery hop. That
   // leaves an ordinary path off the perch for the next falling head contact.
   // Waiting at its center can strand Small behind the native camera boundary.
   const recovering=phase==='recovery-shell'||phase==='shell'&&e.smm2BowserJr.phaseAge>=shellFrames-40;
   const target=p.x<320?(recovering?250:230):(recovering?390:410),dx=target-p.x;
   input={x:Math.abs(dx)>3?Math.sign(dx):0,run:true,jump:!p.grounded||p.y+p.h>240};
  }
  else{const target=displayedJrHeadTarget(e).x-p.w/2,dx=target-p.x;input={x:Math.abs(dx)>1.5?Math.sign(dx):0,run:Math.abs(dx)>16,jump:p.grounded?!s.inputs.at(-1)?.jump:p.vy<0};}
  s.step(input);
 }
 throw Error('Native three-head-stomp route did not finish');
}
