import assert from 'node:assert/strict';
import fs from 'node:fs';
import {blank,parseProject} from '../../atlas/editor-model.mjs';
import {projectPack} from '../../atlas/editor-runtime.mjs';
import {createStageCatalog} from '../../atlas/runtime/stage-catalog.mjs';
import {createPlatformStage} from '../../atlas/editor-mario-stage.mjs';
import {createPlatformMotor} from '../../atlas/editor-mario-motor.mjs';
import {addContraptionDoorPair} from '../../atlas/editor-contraptions-tools.mjs';
export const character=JSON.parse(fs.readFileSync(new URL('../../atlas/runtime/character.json',import.meta.url)));

/** Neutral workshop fixture, independent of any private course or answer route. */
export function nonterminalCastleProject({doors=true}={}){
 const d=blank('Nonterminal Castle return fixture',640,240),r=d.rooms[0];r.setting='Castle';
 r.map.geometry=[{id:'left-bank',x:0,y:176,w:128,h:64,material:'castle',collision:'solid'},{id:'right-bank',x:512,y:176,w:128,h:64,material:'castle',collision:'solid'},{id:'bar-mount',x:320,y:64,w:16,h:16,material:'castle',collision:'solid'}];
 r.map.objects=[{id:'start',kind:'spawn',x:48,y:162,w:10,h:14},{id:'boat',kind:'walker',x:96,y:160,w:16,h:16},{id:'pink',kind:'coin',x:400,y:150,w:8,h:14}];
 r.markers=[{id:'pool',kind:'lava-volume',x:128,y:192,w:384,h:48,source:{width:192}},{id:'bar',kind:'rotating-firebar',x:320,y:64,source:{}}];
 r.smm2Mechanics={version:1,startingLives:3,art:{palette:'smb1-castle-stone'},boneShells:[{id:'boat',playingDead:{durationFrames:12,maxFrames:24,dropThroughIds:[]}}],pinkCoins:[{id:'pink'}],liquid:{markerId:'pool',kind:'lava',minY:176,maxY:192,initialY:192,speed:.5,direction:-1,waitMinFrames:0,waitMaxFrames:0}};
 r.castle={version:1,lavaMode:'pit',firebars:{bar:{direction:'ccw',ballCount:3,periodFrames:120}}};
 const hub=blank('Return room',384,240).rooms[0];hub.roomId='hub';hub.map.id='hub-map';hub.map.geometry=[{id:'hub-floor',x:0,y:176,w:384,h:64,material:'ground',collision:'solid'}];hub.map.objects=[{id:'start',kind:'spawn',x:64,y:162,w:10,h:14},{id:'other-pink',kind:'coin',x:280,y:162,w:8,h:14}];hub.smm2Mechanics={version:1,art:{palette:'smb1-overworld-source'},pinkCoins:[{id:'other-pink'}]};d.rooms.push(hub);
 if(doors)addContraptionDoorPair(d,'main','hub',{source:{x:592,y:144},target:{x:32,y:144},style:'plain'});
 return parseProject(JSON.stringify(d));
}
export function castleSession(doc=nonterminalCastleProject(),{Stage=createPlatformStage,Motor=createPlatformMotor}={}){
 const d=parseProject(JSON.stringify(doc)),pack=projectPack(d,'main',character,'nonterminal-castle-test'),plan=createStageCatalog(pack).plan(pack.stages[0].id,pack.characters[0].id,{allowDraft:true}),events=[];
 const stage=Stage({plan,motor:Motor(),visualRooms:d.rooms,initialState:{lives:3,power:0},manualDeath:true,autoContinue:false,allowWarp:false,emit:(type,data)=>events.push({type,...data})});
 return {doc:d,pack,stage,events,view:()=>stage.view(),step(input={}){stage.step(input);return stage.view();}};
}
export function runCastleReturn(s,{onStep=()=>{}}={}){
 let frames=0;const step=input=>{const v=s.step(input);frames++;onStep(input,v);assert.equal(v.lives,3);assert.equal(v.completed,false);assert.equal(v.finish,null);return v;};
 for(let f=0;f<220&&!s.view().p.shoeId;f++){const p=s.view().p;step({x:p.x<95?1:p.x>102?-1:0,jump:f%50<12});}
 assert.equal(s.view().p.shoeId,'boat','ordinary jump boards the authored empty shell');
 let liveSurfaceSamples=0;
 for(let f=0;f<300&&s.view().p.x<540;f++){const v=step({x:1,run:true});if(v.p.x>160&&v.p.x<480&&v.p.grounded&&v.p.smm2Shoe){assert(Math.abs(v.p.smm2Shoe.y+v.p.smm2Shoe.h-v.smm2Mechanics.liquid.y)<1.01);liveSurfaceSamples++;}}
 assert(liveSurfaceSamples>40);assert.equal(s.view().smm2Mechanics.pinkCoins.taken,1);assert.equal(s.view().p.shoeId,'boat');
 step({x:1,dismount:true});assert.equal(s.view().p.shoeId,undefined,'R/shoulder command leaves the real carrier');
 for(let f=0;f<160&&(s.view().p.x<594||!s.view().p.grounded);f++)step({x:s.view().p.x<594?1:0});
 assert.equal(s.view().p.grounded,true);assert.equal(s.view().p.shoeId,undefined);step({up:true});
 for(let f=0;f<40&&s.view().roomId!=='hub';f++)step({});
 assert.equal(s.view().roomId,'hub');assert.equal(s.view().smm2Mechanics.pinkCoins.taken,1);assert.equal(s.view().smm2Mechanics.pinkCoins.total,2);assert.equal(s.view().p.shoeId,undefined);
 // Return to the Castle and ensure room reconstruction cannot duplicate the token.
 for(let f=0;f<40;f++)step({});step({up:true});for(let f=0;f<40&&s.view().roomId!=='main';f++)step({});
 assert.equal(s.view().roomId,'main');assert.equal(s.view().smm2Mechanics.pinkCoins.taken,1);assert.equal(s.view().objects.some(q=>q.id==='pink'),false);
 assert.equal(s.events.filter(e=>e.event==='pink-coin-collected').length,1);assert.equal(s.events.filter(e=>e.event==='door-enter').length,2);assert.equal(s.events.some(e=>e.event==='axe-trigger'||e.type==='complete'),false);
 return {frames,liveSurfaceSamples};
}
