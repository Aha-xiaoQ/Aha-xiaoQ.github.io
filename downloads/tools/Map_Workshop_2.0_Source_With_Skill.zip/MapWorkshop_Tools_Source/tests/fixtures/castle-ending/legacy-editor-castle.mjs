/** Opt-in castle rules for native markers, native enemy bodies and native motor.
 * Geometry is authored metadata. These local controllers do not emulate a ROM.
 * They never change a player, score, lives, timer or terrain directly. */
const copy=value=>JSON.parse(JSON.stringify(value));
const own=(value,key)=>value&&Object.hasOwn(value,key)?value[key]:undefined;
const unsafe=key=>['__proto__','prototype','constructor'].includes(key);
const finite=(n,min,max)=>Number.isFinite(n)&&n>=min&&n<=max;
const integer=(n,min,max)=>Number.isInteger(n)&&finite(n,min,max);
const fail=text=>{throw Error(text);};
const idOK=id=>typeof id==='string'&&id.length>0&&id.length<=100&&!unsafe(id)&&/^[A-Za-z0-9][A-Za-z0-9_.:@,-]*$/.test(id);
const overlap=(a,b)=>a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y;
const bodyOK=q=>q&&['x','y','w','h'].every(k=>Number.isFinite(q[k]))&&q.w>0&&q.h>0;
function object(value,keys,label){if(!value||typeof value!=='object'||Array.isArray(value)||![Object.prototype,null].includes(Object.getPrototypeOf(value)))fail('Invalid '+label);for(const key of Object.keys(value))if(unsafe(key)||!keys.includes(key))fail('Unknown '+label+' field: '+key);}
function list(value,label,max=128){if(!Array.isArray(value)||value.length>max)fail('Invalid '+label+' list');}
export const CASTLE_FIREBAR_DEFAULTS=Object.freeze({direction:'ccw',ballCount:6,periodFrames:204.8,phaseDegrees:0,activationDistance:32});
export const CASTLE_BOSS_PATROL_DEFAULTS=Object.freeze({speed:.4,activationDistance:32});
export const CASTLE_BOSS_JUMP_DEFAULTS=Object.freeze({intervalFrames:150,jitterFrames:30,velocity:4,seed:1});
export const CASTLE_BOSS_FIRE_DEFAULTS=Object.freeze({intervalFrames:180,initialDelayFrames:60,tellFrames:20,speed:1.25,w:24,h:8,mouthY:8,maxAlive:3});
export const CASTLE_FINISH_DEFAULTS=Object.freeze({bridgeStepFrames:4,bossFallFrames:80,walkSpeed:1.25,messageFrames:180,messages:Object.freeze(['THANK YOU MARIO!','BUT OUR PRINCESS IS IN ANOTHER CASTLE!'])});
export const CASTLE_FLAME_DEFAULTS=Object.freeze({intervalFrames:180,initialDelayFrames:60,speed:1.25,w:24,h:8,maxAlive:3});
export const castleFirebarRule=rule=>({...CASTLE_FIREBAR_DEFAULTS,...rule});
function bossFor(room,spec){if(!spec)return null;const actor=room.map.objects.find(q=>q.id===spec.actorId);return {hp:5,identity:'goomba',fireKillPoints:5000,...spec,patrol:{...CASTLE_BOSS_PATROL_DEFAULTS,minX:Math.max(0,actor.x-48),maxX:Math.min(room.map.width-actor.w,actor.x+48),...spec.patrol},jump:{...CASTLE_BOSS_JUMP_DEFAULTS,...spec.jump},fire:{...CASTLE_BOSS_FIRE_DEFAULTS,...spec.fire}};}
function finishFor(room,spec){if(!spec)return null;const npc=room.markers.find(q=>q.id===spec.npcId),npcX=npc?.x??0;return {...CASTLE_FINISH_DEFAULTS,chainIds:[],targetX:Math.min(room.map.width-16,npcX),lockCameraX:Math.max(0,room.map.width-512),finalCameraX:Math.max(0,room.map.width-256),...spec,messages:[...(spec.messages||CASTLE_FINISH_DEFAULTS.messages)],chainIds:[...(spec.chainIds||[])]};}
const flameFor=rule=>({...CASTLE_FLAME_DEFAULTS,...rule});
export const isCastleBridge=(room,q)=>!!q&&(q.material==='bridge'||(room.semantics||[]).some(s=>s.id===(q.sourceId||q.id)&&['CastleBridge','BridgeBase'].includes(s.kind||s.type)));

/** Validation is pure and an omitted castle extension preserves the legacy path. */
export function validateCastleRoom(room){
 const spec=room?.castle;if(spec===undefined)return;
 object(spec,['version','firebars','lavaMode','boss','finish','flameSources'],'castle');if(spec.version!==1)fail('Unknown castle version');
 if(room.mechanics!==undefined||room.devices?.length)fail('Castle cannot combine with echo before rewind state is supported');
 if(room.aquatic!==undefined||room.underwater===true)fail('Castle modules cannot combine with underwater rules');
 const map=room.map;if(!map||!finite(map.width,256,32768)||!finite(map.height,120,4096)||!Array.isArray(map.objects)||!Array.isArray(map.geometry)||!Array.isArray(room.markers))fail('Castle needs a valid native map');
 if(spec.lavaMode!==undefined&&!['pit','contact'].includes(spec.lavaMode))fail('Invalid castle lava mode');
 const markers=room.markers,marker=(id,kinds)=>idOK(id)&&markers.find(q=>q.id===id&&kinds.includes(q.kind));
 if(spec.firebars!==undefined){object(spec.firebars,Object.keys(spec.firebars),'castle firebars');if(Object.keys(spec.firebars).length>128)fail('Too many castle firebars');}
 for(const [id,rule]of Object.entries(spec.firebars||{})){
  const m=marker(id,['rotating-firebar']);if(!m||!finite(m.x,0,map.width-16)||!finite(m.y,0,map.height-16))fail('Firebar needs an existing native rotating-firebar marker');
  object(rule,Object.keys(CASTLE_FIREBAR_DEFAULTS),'firebar');const q=castleFirebarRule(rule);
  if(!['cw','ccw'].includes(q.direction)||!integer(q.ballCount,1,16)||!finite(q.periodFrames,1,36000)||!finite(q.phaseDegrees,-3600,3600)||!finite(q.activationDistance,0,512))fail('Invalid firebar direction, nodes, period or phase');
 }
 if(spec.boss!==undefined){
  object(spec.boss,['actorId','hp','identity','fireKillPoints','patrol','jump','fire'],'castle boss');const actor=map.objects.find(q=>q.id===spec.boss.actorId&&q.kind==='walker');
  if(!idOK(spec.boss.actorId)||!actor||!bodyOK(actor)||!finite(actor.x,0,map.width-actor.w)||!finite(actor.y,0,map.height-actor.h)||!['bowser','enemy-bowser','marker-Bowser','marker-bowser'].includes(room.enemySkins?.[actor.id]||actor.type||markers.find(m=>m.id===actor.id)?.kind))fail('Castle boss needs an existing native Bowser walker');
  if(room.marioModules?.enemyVariants&&Object.hasOwn(room.marioModules.enemyVariants,actor.id))fail('Castle boss cannot also have an enemy variant');
  if(spec.boss.patrol!==undefined)object(spec.boss.patrol,['minX','maxX',...Object.keys(CASTLE_BOSS_PATROL_DEFAULTS)],'boss patrol');
  if(spec.boss.jump!==undefined)object(spec.boss.jump,Object.keys(CASTLE_BOSS_JUMP_DEFAULTS),'boss jump');
  if(spec.boss.fire!==undefined)object(spec.boss.fire,Object.keys(CASTLE_BOSS_FIRE_DEFAULTS),'boss fire');
  const b=bossFor(room,spec.boss),p=b.patrol,j=b.jump,f=b.fire;
  if(!integer(b.hp,1,100)||b.identity!=='goomba'||!integer(b.fireKillPoints,0,100000)||!finite(p.minX,0,map.width-actor.w)||!finite(p.maxX,p.minX+.01,map.width-actor.w)||actor.x<p.minX||actor.x>p.maxX||!finite(p.speed,.01,4)||!finite(p.activationDistance,0,512)||!integer(j.intervalFrames,1,36000)||!integer(j.jitterFrames,0,Math.min(j.intervalFrames-1,3600))||!finite(j.velocity,.1,8)||!integer(j.seed,0,0xffffffff)||!integer(f.intervalFrames,1,36000)||!integer(f.initialDelayFrames,0,36000)||!integer(f.tellFrames,0,f.intervalFrames)||!finite(f.speed,.01,8)||!finite(f.w,1,64)||!finite(f.h,1,64)||!finite(f.mouthY,-64,64)||!integer(f.maxAlive,1,16))fail('Invalid castle boss health or movement rules');
 }
 if(spec.finish!==undefined){
  object(spec.finish,['axeId','bridgeId','chainIds','npcId','targetX','lockCameraX','finalCameraX',...Object.keys(CASTLE_FINISH_DEFAULTS)],'castle finish');
  const f=finishFor(room,spec.finish),axe=marker(f.axeId,['bridge-axe-finish','marker-CastleAxe']),npc=marker(f.npcId,['castle-finish','marker-Toad','marker-Peach']),bridge=map.geometry.find(q=>q.id===f.bridgeId);
  if(!axe||!npc||!idOK(f.bridgeId)||!bridge||!isCastleBridge(room,bridge)||!bodyOK(bridge)||bridge.w%16!==0||bridge.w>4096||bridge.h>32||bridge.collision!=='solid'||!finite(bridge.x,0,map.width-bridge.w)||!finite(bridge.y,0,map.height-bridge.h)||!finite(axe.x,0,map.width-16)||!finite(axe.y,0,map.height-16)||!finite(npc.x,0,map.width-16)||!finite(npc.y,0,map.height-16))fail('Castle finish needs native axe, whole-tile solid bridge and NPC');
  list(f.chainIds,'castle chain',32);if(new Set(f.chainIds).size!==f.chainIds.length||f.chainIds.some(id=>{const chain=marker(id,['marker-CastleChain']);return !chain||!finite(chain.x,0,map.width-16)||!finite(chain.y,0,map.height-16);}))fail('Castle chain target is invalid');
  if(!integer(f.bridgeStepFrames,1,240)||!integer(f.bossFallFrames,1,600)||!finite(f.targetX,axe.x,map.width-1)||!finite(f.lockCameraX,0,map.width-256)||!finite(f.finalCameraX,f.lockCameraX,map.width-256)||!finite(f.walkSpeed,.01,4)||!integer(f.messageFrames,1,36000))fail('Invalid castle finish timing, target or camera');
  list(f.messages,'castle message',8);if(!f.messages.length||f.messages.some(s=>typeof s!=='string'||!s.trim()||s.length>200))fail('Invalid castle messages');
 }
 const ids=new Set([...map.geometry,...map.objects,...markers,...(room.marioModules?.enemySources||[]),...(room.marioModules?.itemSources||[])].map(q=>q.id));
 if(spec.flameSources!==undefined)list(spec.flameSources,'castle flame source',64);
 for(const rule of spec.flameSources||[]){object(rule,['id','sourceX','startX','endX','y',...Object.keys(CASTLE_FLAME_DEFAULTS)],'castle flame source');const q=flameFor(rule);if(!idOK(q.id)||ids.has(q.id))fail('Duplicate or invalid castle flame ID');ids.add(q.id);if(!finite(q.sourceX,0,map.width)||!finite(q.startX,0,map.width)||!finite(q.endX,q.startX+.01,map.width)||!finite(q.y,0,map.height-q.h)||!integer(q.intervalFrames,1,36000)||!integer(q.initialDelayFrames,0,36000)||!finite(q.speed,.01,8)||!finite(q.w,1,64)||!finite(q.h,1,64)||!integer(q.maxAlive,1,16))fail('Invalid castle flame region, body or cadence');}
}

/** Screen coordinates: phase zero points down, positive phase rotates clockwise.
 * The first ball shares the mount center; six nodes span radii 0,8,..,40 px.
 * Use this exact result for both native artwork and damaging rectangles. */
export function castleFirebarNodes(marker,rule={},age=0){
 const q=castleFirebarRule(rule);if(!marker||!Number.isFinite(marker.x)||!Number.isFinite(marker.y)||!finite(age,0,Number.MAX_SAFE_INTEGER)||!['cw','ccw'].includes(q.direction)||!integer(q.ballCount,1,16)||!finite(q.periodFrames,1,36000)||!finite(q.phaseDegrees,-3600,3600))fail('Invalid firebar geometry');
 const theta=(q.phaseDegrees+(q.direction==='cw'?1:-1)*age*360/q.periodFrames)*Math.PI/180,cx=marker.x+8,cy=marker.y+8;
 return Array.from({length:q.ballCount},(_,index)=>({markerId:marker.id,index,x:cx-Math.sin(theta)*index*8-4,y:cy+Math.cos(theta)*index*8-4,w:8,h:8}));
}

/** Foot sampling prevents a powered player's head from triggering the axe. */
export function castleAxeFootTrigger(player,axe){if(!bodyOK(player)||!axe||!Number.isFinite(axe.x)||!Number.isFinite(axe.y)||!Number.isFinite(player.vy)||player.vy<0||player.dead||player.dying)return false;const footX=player.x+player.w/2,footY=player.y+player.h;return footX>=axe.x&&footX<axe.x+16&&footY>=axe.y&&footY<=axe.y+16;}

export function createCastleController(room,{emit=()=>{}}={}){
 validateCastleRoom(room);if(room.castle===undefined)return null;
 const spec=copy(room.castle),bars=new Map(Object.entries(spec.firebars||{}).map(([id,rule])=>[id,{marker:copy(room.markers.find(m=>m.id===id)),rule:castleFirebarRule(rule)}])),boss=bossFor(room,spec.boss),finishRules=finishFor(room,spec.finish),sources=(spec.flameSources||[]).map(flameFor);
 let barStates,sourceStates,finish=null,lastFinishTick=null,hitShots=new WeakSet(),bossStates=new WeakMap();
 const event=(name,data={})=>emit('castle',{event:name,...data});
 function reset(){barStates=new Map([...bars].map(([id])=>[id,{active:false,activated:false,age:0,lastTick:null}]));sourceStates=new Map(sources.map(q=>[q.id,{active:false,clock:q.initialDelayFrames,emitted:0,lastTick:null}]));finish=null;lastFinishTick=null;hitShots=new WeakSet();bossStates=new WeakMap();}
 reset();
 function stepFirebars({tick=0,cam=0,viewportWidth=256,paused=false}={}){if(paused||finish)return view().firebars;for(const [id,{marker,rule}]of bars){const s=barStates.get(id);s.active=marker.x+16>=cam-rule.activationDistance&&marker.x<=cam+viewportWidth+rule.activationDistance;if(s.lastTick===tick)continue;s.lastTick=tick;if(s.active){s.activated=true;s.age++;}}return view().firebars;}
 function firebarNodes(id){const q=bars.get(id);return q?castleFirebarNodes(q.marker,q.rule,barStates.get(id).age):null;}
 function decorateBoss(enemy){if(!boss||enemy?.id!==boss.actorId)return enemy;enemy.hp=boss.hp;enemy.castleBoss=true;enemy.castleIdentity=boss.identity;enemy.castleBossRules=copy(boss);enemy.homeX??=enemy.x;enemy.homeY??=enemy.y;return enemy;}
 function bossRule(enemy){return boss&&(!enemy||enemy.id===boss.actorId)?copy(boss):null;}
 function hitBoss(enemy,shot){if(!boss||enemy?.id!==boss.actorId)return {handled:false};if(finish||enemy.dead||enemy.castleDefeated||!shot||shot.kind!=='fireball'||shot.dead||hitShots.has(shot)||!bodyOK(shot)||!bodyOK(enemy)||!overlap(shot,enemy))return {handled:true,hit:false,defeated:false};hitShots.add(shot);shot.dead=true;enemy.hp=Math.max(0,(Number.isFinite(enemy.hp)?enemy.hp:boss.hp)-1);const defeated=enemy.hp===0;if(defeated){enemy.castleDefeated=true;enemy.castleIdentity=boss.identity;enemy.type=boss.identity;event('boss-fire-defeat',{actorId:enemy.id,points:boss.fireKillPoints,identity:boss.identity});}else event('boss-fire-hit',{actorId:enemy.id,hp:enemy.hp});return {handled:true,hit:true,defeated,hp:enemy.hp,...(defeated?{points:boss.fireKillPoints,identity:boss.identity}:{})};}
 const flameBody=(id,x,y,q,extra={})=>({id,kind:'walker',type:'bowserfire',x,y,w:q.w,h:q.h,vx:-q.speed,vy:0,homeX:x,homeY:y,age:0,hp:1,dead:false,source:{castle:true},...extra});
 function spawnFlames({tick=0,cam=0,enemies=[],player,paused=false}={}){if(paused||finish||player?.dead||player?.dying)return [];const out=[];for(const q of sources){const s=sourceStates.get(q.id);s.active=cam>=q.startX&&cam<q.endX;if(s.lastTick===tick)continue;s.lastTick=tick;if(!s.active)continue;if(s.clock>0){s.clock--;continue;}if([...enemies,...out].filter(e=>!e.dead&&e.castleFlameSource===q.id).length>=q.maxAlive)continue;out.push(flameBody('castle-flame-'+q.id+'-'+s.emitted,q.sourceX,q.y,q,{castleFlameSource:q.id}));s.emitted++;s.clock=q.intervalFrames-1;event('flame-spawn',{sourceId:q.id,actorId:out.at(-1).id});}return out;}
 /** Motion intent, applied by the existing collision/gravity loop. Cadence and
  * seeded jump jitter are local approximations; this is not a second motor. */
 function bossIntent(enemy,{tick=0,cam=0,viewportWidth=256,player,enemies=[],paused=false}={}){
  if(!boss||enemy?.id!==boss.actorId||enemy.dead||enemy.castleDefeated||finish)return null;
  let s=bossStates.get(enemy);if(!s){s={lastTick:null,age:0,fireClock:boss.fire.initialDelayFrames,jumpClock:boss.jump.intervalFrames,rng:boss.jump.seed>>>0,direction:-1,result:null};bossStates.set(enemy,s);}
  if(paused)return {active:false};if(s.lastTick===tick)return s.result?{...s.result,flame:null,jumpVelocity:null}:null;s.lastTick=tick;
  if(enemy.x>cam+viewportWidth+boss.patrol.activationDistance||enemy.x+enemy.w<cam)return s.result={active:false};
  const facing=player?Math.sign(player.x+player.w/2-enemy.x-enemy.w/2)||-1:-1;
  if(enemy.x<=boss.patrol.minX)s.direction=1;else if(enemy.x>=boss.patrol.maxX)s.direction=-1;
  const vx=Math.max(boss.patrol.minX-enemy.x,Math.min(boss.patrol.maxX-enemy.x,s.direction*boss.patrol.speed));let jumpVelocity=null,flame=null;
  if(--s.jumpClock<=0&&enemy.grounded){jumpVelocity=-boss.jump.velocity;s.rng=(Math.imul(s.rng,1664525)+1013904223)>>>0;s.jumpClock=boss.jump.intervalFrames+Math.floor((s.rng/0x100000000)*(boss.jump.jitterFrames*2+1))-boss.jump.jitterFrames;}
  if(s.fireClock>0)s.fireClock--;else if(enemies.filter(e=>!e.dead&&e.castleBossFlame===boss.actorId).length<boss.fire.maxAlive){flame=flameBody('castle-boss-flame-'+boss.actorId+'-'+s.age,enemy.x-boss.fire.w,enemy.y+boss.fire.mouthY,boss.fire,{castleBossFlame:boss.actorId});s.fireClock=boss.fire.intervalFrames-1;}
  s.age++;return s.result={active:true,vx,facing,jumpVelocity,frame:s.fireClock<=boss.fire.tellFrames?'firing':'',flame};
 }
 function triggerFinish({player,markers=room.markers,enemies=[],geometry=room.map.geometry}={}){
  if(!finishRules||finish)return null;const axe=markers.find(m=>m.id===finishRules.axeId);if(!castleAxeFootTrigger(player,axe))return null;
  const bridge=geometry.find(g=>g.id===finishRules.bridgeId);if(!bridge)return null;const live=boss&&enemies.some(e=>e.id===boss.actorId&&!e.dead&&!e.castleDefeated&&(e.hp??boss.hp)>0);
  finish={castle:true,component:true,phase:live?'bridge':'walk',age:0,bridgeId:bridge.id,target:finishRules.targetX,branch:live?'alive':'dead',messages:[...finishRules.messages],messageIndex:-1,bossId:boss?.actorId||null,bridgeX:bridge.x,bridgeY:bridge.y,bridgeHeight:bridge.h,bridgeTiles:Math.ceil(bridge.w/16),remainingBridgeTiles:Math.ceil(bridge.w/16)};
  const commands=[{type:'hide-markers',ids:[finishRules.axeId,...(live?finishRules.chainIds:[])]},{type:'clear-projectiles'},{type:'freeze-timer'},{type:'sound',event:live?'break':'world_clear'}];event('axe-trigger',{branch:finish.branch,axeId:finishRules.axeId});return {finish,commands};
 }
 function stepFinish({tick=0,player,finish:currentFinish=finish,paused=false}={}){
  if(!currentFinish||!finishRules)return null;if(currentFinish!==finish)finish=currentFinish;const commands=[];if(paused||lastFinishTick===tick||finish.phase==='complete')return {finish,commands};lastFinishTick=tick;finish.age++;
  if(finish.phase==='bridge'){
   if(finish.age%finishRules.bridgeStepFrames===0&&finish.remainingBridgeTiles>0){finish.remainingBridgeTiles--;commands.push({type:'remove-bridge-tile',bridgeId:finish.bridgeId,x:finish.bridgeX+finish.remainingBridgeTiles*16,y:finish.bridgeY,w:16,h:finish.bridgeHeight,remainingWidth:finish.remainingBridgeTiles*16});if(!finish.remainingBridgeTiles){finish.phase='boss-fall';finish.age=0;commands.push({type:'sound',event:'bowser_fall'});}}
  }else if(finish.phase==='boss-fall'){
   commands.push({type:'boss-fall-step',actorId:finish.bossId,gravity:.22});if(finish.age>=finishRules.bossFallFrames){finish.phase='walk';finish.age=0;commands.push({type:'remove-boss',actorId:finish.bossId},{type:'sound',event:'world_clear'});}
  }else if(finish.phase==='walk'){
   commands.push({type:'camera',targetX:finishRules.finalCameraX});if(player&&player.x>=finish.target){finish.phase='message';finish.age=0;finish.messageIndex=0;commands.push({type:'stop-player'},{type:'message',index:0,text:finish.messages[0]});}else commands.push({type:'walk',direction:1,speed:finishRules.walkSpeed,targetX:finish.target});
  }else if(finish.phase==='message'){
   if(finish.age>=finishRules.messageFrames){finish.age=0;finish.messageIndex++;if(finish.messageIndex>=finish.messages.length){finish.phase='complete';commands.push({type:'complete'});event('finish-complete',{branch:finish.branch});}else commands.push({type:'message',index:finish.messageIndex,text:finish.messages[finish.messageIndex]});}
  }
  return {finish,commands};
 }
 function view(){return {version:1,approximation:true,lavaMode:spec.lavaMode??'contact',firebars:[...bars.keys()].map(id=>({id,...barStates.get(id),nodes:firebarNodes(id)})),flameSources:sources.map(q=>({id:q.id,...sourceStates.get(q.id)})),finish:finish?copy(finish):null,boss:boss?copy(boss):null};}
 return Object.freeze({stepFirebars,firebarNodes,decorateBoss,bossRule,bossIntent,hitBoss,spawnFlames,triggerFinish,stepFinish,finishView:()=>finish?copy(finish):null,combatEnabled:()=>!finish,lavaMode:()=>spec.lavaMode??'contact',reset,view});
}
