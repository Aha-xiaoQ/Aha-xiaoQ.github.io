import {neutralLoopProject} from './sky-shooter-loop.mjs';

/** Neutral author fixture: three existing native bodies, one continuous return
 * corridor and explicit enemy-fire tuning. No private course or input route. */
export function enemyFireProject(){
 const d=neutralLoopProject();
 d.rooms[0].smm2Mechanics.skyShooter.enemyFire={
  version:1,downwardActorIds:['drone-b','drone-c'],diverActorIds:['drone-a'],
  firstDownwardShotFrames:90,downwardIntervalFrames:84,telegraphFrames:36,
  shotSpeed:1.8,shotLifeFrames:240,maxShots:4,diverAttackY:280,minAimDistance:40,
 };
 return d;
}
