import assert from 'node:assert/strict';
import {blank} from '../../atlas/editor-model.mjs';
import {createSMM2Terrain,sampleSMM2Surface} from '../../atlas/editor-smm2-terrain.mjs';
import {nativeSession,activate} from './shell-coin-native.mjs';

// Neutral contact fixture. No source course geometry or playthrough is stored.
export function thinSlopeProject({orientation='rise-left',thickness=12}={}){
 const d=blank('Synthetic finite slope contact',640,288),r=d.rooms[0],descending=orientation==='rise-left',startY=descending?128:192,endY=descending?192:128;
 r.map.geometry=[{id:'start-platform',x:0,y:startY,w:128,h:16,collision:'solid',material:'ground'},{id:'end-platform',x:256,y:endY,w:384,h:16,collision:'solid',material:'ground'},{id:'lower-floor',x:0,y:256,w:640,h:32,collision:'solid',material:'ground'}];
 r.map.objects=[{id:'start',kind:'spawn',x:80,y:startY-96,w:10,h:14},{id:'shell-body',kind:'walker',x:80,y:startY-24,w:16,h:24}];
 r.markers=[{id:'shell-body',kind:'enemy-koopa',x:80,y:startY-24,source:{thing:'Koopa',smart:false}}];
 r.playRules={version:1,timeLimit:600,timerFrames:24,viewportWidth:256,viewportHeight:240,cameraAnchor:100};
 r.smm2Mechanics={version:1,shellCoinCollection:true,slopes:[{id:'finite-slope',x:128,y:128,w:128,h:64,thickness,orientation,collision:'solid'}]};
 return d;
}
export function checkLiveShellSlope(project,options={}){
 const s=nativeSession(project,options),r=s.doc.rooms[0],slope=r.smm2Mechanics.slopes[0],shape=createSMM2Terrain(r).surfaces()[0];activate(s);let slopeFrames=0,flatFrames=0,lastY=null;
 s.until(v=>{
  const shell=v.enemies.find(q=>q.id==='shell-body');assert(shell&&!shell.dead&&shell.shell&&shell.vx>1,'the real kicked shell stays live and rolling');
  if(shell.support===slope.id&&shell.x<256){const sample=sampleSMM2Surface(shape,shell.x,shell.w);assert(sample);assert(Math.abs(shell.y+shell.h-sample.y)<1e-6,'finite top contact must follow the real diagonal');assert.equal(shell.grounded,true);assert.equal(shell.vy,0);if(lastY!==null)assert(slope.orientation==='rise-left'?shell.y>=lastY:shell.y<=lastY,'the body follows the authored slope direction');lastY=shell.y;slopeFrames++;}
  if(shell.x>=256&&shell.grounded){assert.equal(shell.y+shell.h,r.map.geometry.find(q=>q.id==='end-platform').y);assert.equal(shell.support,'end-platform');flatFrames++;}
  return shell.x>=288;
 },{},160);
 assert(slopeFrames>25,'rolling shell physically traverses the 1:2 slope');assert(flatFrames>5,'rolling shell reaches real flat geometry');
 return {slopeFrames,flatFrames,naturalInputs:s.inputs.length,liveShell:true,sourceCourseIncluded:false};
}
