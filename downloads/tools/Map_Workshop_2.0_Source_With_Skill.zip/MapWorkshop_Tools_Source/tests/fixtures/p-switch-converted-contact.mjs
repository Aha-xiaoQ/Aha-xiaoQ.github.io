import assert from 'node:assert/strict';
import {blank} from '../../atlas/editor-model.mjs';
import {addSmm2Component} from '../../atlas/editor-smm2-authoring.mjs';
import {createPlatformStage} from '../../atlas/editor-mario-stage.mjs';
import {pSwitchProject} from './p-switch-native.mjs';
import {nativeSession,overlaps} from './shell-coin-native.mjs';

export const walkingAxis=(p,x)=>{const d=x-p.x;return Math.abs(d)<1?(Math.abs(p.vx)<.08?0:-Math.sign(p.vx)):Math.sign(d)*p.vx>0&&Math.abs(d)<p.vx*p.vx/(2*.1015625)+1?-Math.sign(p.vx):Math.sign(d);};
export function walkTo(s,x,budget=300){return s.until(v=>Math.abs(v.p.x-x)<2&&Math.abs(v.p.vx)<.1&&v.p.grounded,v=>({x:walkingAxis(v.p,x),run:true}),budget);}
export function convertedContactProject({direction='below',pit=false,doors=false}={}){
 const doc=pSwitchProject(),room=doc.rooms[0];doc.title='Neutral P converted-brick contact regression';
 const target=room.map.geometry.find(q=>q.id==='empty-brick');target.x=direction==='right'?48:208;target.y=['left','right'].includes(direction)?208:176;
 room.map.geometry.find(q=>q.id==='content-brick').x=600;
 room.map.geometry.push({id:'uneaten-brick',x:320,y:176,w:16,h:16,collision:'solid',material:'brick'});
 room.map.objects.find(q=>q.id==='coin').y=96;
 addSmm2Component(room,'pinkCoin',{id:'typed-pink',x:360,y:208});
 if(pit)room.map.geometry.find(q=>q.id==='floor').w=384;
 if(doors){const other=blank('Neutral converted coin return',640,288).rooms[0];other.roomId='other';other.map.id='p-converted-other';other.map.geometry=[{id:'floor',x:0,y:224,w:640,h:64,collision:'solid',material:'ground'}];other.map.objects=[{id:'start',kind:'spawn',x:35,y:210,w:10,h:14}];room.map.objects.push({id:'main-door',kind:'portal',x:272,y:192,w:16,h:32,targetRoom:'other',targetSpawn:'other-arrival'},{id:'main-arrival',kind:'spawn',x:275,y:210,w:10,h:14});other.map.objects.push({id:'other-door',kind:'portal',x:32,y:192,w:16,h:32,targetRoom:'main',targetSpawn:'main-arrival'},{id:'other-arrival',kind:'spawn',x:35,y:210,w:10,h:14});room.contraptions={version:1,doors:[{id:'main-door',pairId:'neutral-p-return',style:'plain'}]};other.contraptions={version:1,doors:[{id:'other-door',pairId:'neutral-p-return',style:'plain'}]};doc.rooms.push(other);}
 return doc;
}
export function recordedContactSession(doc,options={}){
 const s=nativeSession(doc,options),step=s.step; s.views=[structuredClone(s.view())];s.step=input=>{const view=step(input);s.views.push(structuredClone(view));return view;};return s;
}
export function readyForPickup(direction='below',options={},doc=convertedContactProject({direction})){
 const s=recordedContactSession(doc,options),pressed=s.until(v=>v.contraptions.pFrames>0,{},100);assert.equal(pressed.contraptions.pFrames,600);
 const original=s.doc.rooms[0].map.geometry.find(q=>q.id==='empty-brick'),converted=pressed.geometry.find(q=>q.id===original.id);
 assert.equal(converted.hidden,true);assert.equal(converted.collision,'none');assert.equal(converted.pConverted,true);
 assert.equal(pressed.geometry.find(q=>q.id==='content-brick').hidden,undefined);
 assert(pressed.objects.some(q=>q.id==='typed-pink'));assert(!pressed.geometry.some(q=>q.sourceCoinId==='typed-pink'));
 assert(pressed.geometry.some(q=>q.sourceCoinId==='coin'&&q.pCoin&&q.collision==='solid'));
 const target=direction==='above'?176:direction==='left'?176:direction==='right'?98:211;walkTo(s,target);s.frames(3);
 return s;
}
export const pickupInput=direction=>direction==='above'?{x:1,run:true,jump:true}:direction==='below'?{jump:true}:direction==='left'?{x:1}:{x:-1};
export function assertConvertedPickup(direction='below',options={}){
 const s=readyForPickup(direction,options),coin=structuredClone(s.view().objects.find(q=>q.sourceBrickId==='empty-brick'));let before=s.view(),collected;
 for(let n=0;n<160;n++){const next=s.step(pickupInput(direction));assert.notEqual(next.p.headHit,'empty-brick','converted original never receives a head hit');assert(!next.geometry.some(q=>q.id==='empty-brick'&&!q.hidden),'no transient original brick');if(next.coins===1){collected=next;break;}before=next;}
 assert(collected,'ordinary movement must collect the converted coin');assert(overlaps(collected.p,coin));assert(collected.contraptions.pFrames>0);
 if(direction==='below'){assert(before.p.y>=coin.y+coin.h);assert(collected.p.vy<0,'pickup preserves rising jump');}
 else if(direction==='above'){assert(before.p.y+before.p.h<=coin.y);assert(collected.p.vy>0);}
 else if(direction==='left')assert(before.p.x+before.p.w<=coin.x);
 else assert(before.p.x>=coin.x+coin.w);
 assert.equal(s.events.filter(q=>q.event==='p-brick-collected'&&q.deviceId==='empty-brick').length,1);
 assert(!collected.geometry.some(q=>q.id==='empty-brick'),'same-frame pickup removes the dormant original');
 assert(!collected.objects.some(q=>q.sourceBrickId==='empty-brick'));
 // Stop on safe ground, then use only idle inputs until the genuine timer ends.
 s.until(v=>v.p.grounded,{},120);s.frames(s.view().contraptions.pFrames);
 const expired=s.view();assert.equal(expired.contraptions.pFrames,0);assert(!expired.geometry.some(q=>q.id==='empty-brick'));assert(!expired.objects.some(q=>q.sourceBrickId==='empty-brick'));
 const uneaten=expired.geometry.find(q=>q.id==='uneaten-brick');assert.equal(uneaten.hidden,false);assert.equal(uneaten.collision,'solid');assert.equal(uneaten.pConverted,false);
 assert(expired.objects.some(q=>q.id==='coin'));assert(expired.objects.some(q=>q.id==='typed-pink'));assert(!expired.geometry.some(q=>q.pCoin));
 assert.equal(s.events.filter(q=>q.event==='p-pressed').length,1);assert.equal(s.events.filter(q=>q.event==='p-expired').length,1);
 return {s,coin,before:structuredClone(before),collected:structuredClone(collected),expired:structuredClone(expired)};
}
export function assertExpiryBoundary({collectOnLastFrame=true,options={}}={}){
 const s=readyForPickup('below',options),remaining=collectOnLastFrame?6:5;s.frames(s.view().contraptions.pFrames-remaining);
 for(let n=0;n<5;n++)s.step({jump:true});const contact=s.view();
 if(collectOnLastFrame){assert.equal(contact.contraptions.pFrames,1);assert.equal(contact.coins,1);assert.equal(contact.p.headHit,null);assert(contact.p.vy<0);assert(!contact.geometry.some(q=>q.id==='empty-brick'));s.step({jump:true});assert.equal(s.view().contraptions.pFrames,0);assert(!s.view().geometry.some(q=>q.id==='empty-brick'));}
 else {assert.equal(contact.contraptions.pFrames,0);assert.equal(contact.coins,0);assert.equal(contact.p.headHit,'empty-brick');assert.equal(contact.geometry.find(q=>q.id==='empty-brick').collision,'solid');assert.equal(s.events.filter(q=>q.event==='p-brick-collected').length,0);}
 return {s,contact:structuredClone(contact)};
}
export function assertDoorPersistence(options={}){
 const doc=convertedContactProject({doors:true}),s=readyForPickup('below',options,doc);s.until(v=>v.coins===1,{jump:true},40);s.until(v=>v.p.grounded,{},120);walkTo(s,275);s.frames(3);s.until(v=>v.roomId==='other'&&!v.transition,{up:true},100);assert(s.view().contraptions.pFrames>0);s.frames(35);s.step({});s.until(v=>v.roomId==='main'&&!v.transition,{up:true},100);
 const returned=s.view();assert(returned.contraptions.pFrames>0);assert(!returned.geometry.some(q=>q.id==='empty-brick'));assert(!returned.objects.some(q=>q.sourceBrickId==='empty-brick'));assert(!returned.items.some(q=>q.id==='stable-p'));
 s.frames(returned.contraptions.pFrames);assert(!s.view().geometry.some(q=>q.id==='empty-brick'));assert.equal(s.events.filter(q=>q.event==='p-brick-collected').length,1);return {s,returned:structuredClone(returned)};
}
export function assertLifeBoundary(options={}){
 const BaseStage=options.Stage??createPlatformStage,doc=convertedContactProject({pit:true}),s=readyForPickup('below',{...options,Stage:opts=>BaseStage({...opts,manualDeath:false})},doc);s.until(v=>v.coins===1,{jump:true},40);s.until(v=>v.p.grounded,{},120);s.until(v=>v.p.dying,{x:1,run:true},240);assert.equal(s.view().lives,2);s.until(v=>!v.p.dying,{},150);
 const restored=s.view();assert.equal(restored.contraptions.pFrames,0);assert.equal(restored.contraptions.removedBricks.length,0);assert.equal(restored.geometry.find(q=>q.id==='empty-brick').hidden,undefined);assert.equal(restored.geometry.find(q=>q.id==='empty-brick').collision,'solid');assert(restored.items.some(q=>q.id==='stable-p'));assert(restored.objects.some(q=>q.id==='typed-pink'));return {s,restored:structuredClone(restored)};
}
export function assertRealHiddenBlock(options={}){
 const doc=convertedContactProject();doc.rooms[0].markers.push({id:'real-hidden-block',kind:'hidden-block',x:400,y:176,source:{thing:'Block',contents:'coin'}});const s=recordedContactSession(doc,options);s.until(v=>v.contraptions.pFrames>0,{},100);walkTo(s,403);s.frames(3);
 assert.equal(s.view().geometry.find(q=>q.id==='real-hidden-block').hidden,true);assert.equal(s.view().geometry.find(q=>q.id==='real-hidden-block').collision,'solid');const hit=s.until(v=>v.p.headHit==='real-hidden-block',{jump:true},50);assert.equal(hit.geometry.find(q=>q.id==='real-hidden-block').hidden,false);assert.equal(hit.geometry.find(q=>q.id==='real-hidden-block').used,true);return {s,hit:structuredClone(hit)};
}
export function assertSplitBrick(options={}){
 const doc=convertedContactProject(),room=doc.rooms[0];room.map.geometry.find(q=>q.id==='empty-brick').w=32;const s=recordedContactSession(doc,options);s.until(v=>v.contraptions.pFrames>0,{},100);walkTo(s,211);s.frames(3);const hit=s.until(v=>v.coins===1,{jump:true},40);const id='empty-brick@208,176',neighbor='empty-brick@224,176';assert.equal(hit.p.headHit,null);assert(!hit.geometry.some(q=>q.id===id));assert.equal(hit.geometry.find(q=>q.id===neighbor).collision,'none');s.until(v=>v.p.grounded,{},120);s.frames(s.view().contraptions.pFrames);assert(!s.view().geometry.some(q=>q.id===id));assert.equal(s.view().geometry.find(q=>q.id===neighbor).collision,'solid');assert.equal(s.view().geometry.find(q=>q.id===neighbor).hidden,false);return {s,hit:structuredClone(hit)};
}
