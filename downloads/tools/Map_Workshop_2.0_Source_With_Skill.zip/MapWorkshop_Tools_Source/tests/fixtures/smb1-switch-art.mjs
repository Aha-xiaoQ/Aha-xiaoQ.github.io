import {parseProject} from '../../atlas/editor-model.mjs';

/** Neutral source-art fixture; no Story Job course layout or private inputs. */
export function smb1SwitchArtProject({on=true}={}){
 const doc={format:'xiaoq-map-project',version:1,id:'neutral-smb1-switch-art',title:'Neutral SMB1 switch source art',reference:null,rooms:[{
  roomId:'main',setting:'Overworld',markers:[],decorations:[],
  map:{id:'neutral-smb1-switch-room',title:'Neutral source states',width:384,height:240,tileSize:16,
   geometry:[{id:'floor',x:0,y:224,w:384,h:16,collision:'solid',material:'ground'}],
   objects:[{id:'start',kind:'spawn',x:48,y:210,w:10,h:14}],
   provenance:{kind:'original',source:'Neutral original-source art fixture',review:'pending',note:'Static artwork and ordinary native head-contact verification'}},
  switchStudy:{version:1,initialOn:on,allowBacktracking:true,devices:[
   {id:'on-off',kind:'switch',x:48,y:176,w:16,h:16},
   {id:'red-blocks',kind:'block',color:'red',x:192,y:160,w:48,h:16},
   {id:'blue-blocks',kind:'block',color:'blue',x:256,y:160,w:48,h:16}
  ]}
 }]};
 return parseProject(JSON.stringify(doc));
}
