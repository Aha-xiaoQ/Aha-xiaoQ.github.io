// Neutral synthetic ON/OFF fixture. All lighting numbers and input timing are
// authored examples, not original-game measurements or a Story43 course map.
import assert from 'node:assert/strict';
import {lightingProject,centre} from './lighting-native.mjs';
import {addSmm2Component} from '../../atlas/editor-smm2-authoring.mjs';
import {nativeSession} from './shell-coin-native.mjs';

export function lightingSwitchProject({initialOn=true,scale=.5}={}){
 const doc=lightingProject({setting:'Ghost House Night'}),r=doc.rooms[0];doc.id='neutral-switch-linked-lighting-v1';
 Object.assign(r.map.objects.find(q=>q.kind==='spawn'),{x:48,y:210});
 r.switchStudy={version:1,initialOn,allowBacktracking:true,devices:[{id:'on-off',kind:'switch',x:48,y:176,w:16,h:16},{id:'red',kind:'block',color:'red',x:176,y:160,w:16,h:16},{id:'blue',kind:'block',color:'blue',x:208,y:160,w:16,h:16}]};
 addSmm2Component(r,'pSwitch',{id:'stable-p',x:480,y:208,orientation:'up',gravity:0});
 r.smm2Mechanics.lighting.sources.push({targetId:'stable-p',radius:56});
 if(scale!==undefined)r.smm2Mechanics.lighting.offRadiusScale=scale;
 return doc;
}

export function assertSwitchLightView(room,view,resolve){
 assert.equal(view.switchStudy.version,1);assert.equal(typeof view.switchStudy.on,'boolean');
 const spec=room.smm2Mechanics.lighting,scale=view.switchStudy.on?1:spec.offRadiusScale??1,sources=resolve(room,view),byId=new Map(sources.map(q=>[q.targetId,q]));
 assert.equal(byId.size,sources.length);assert(!byId.has('on-off'),'the switch is not a light source');
 for(const q of sources){const authored=q.targetId==='player'?{radius:spec.playerRadius}:spec.sources.find(s=>s.targetId===q.targetId);assert(authored);assert.equal(q.radius,authored.radius*scale);}
 for(const [id,key]of [['stable-p','items'],['falling-pow','items'],['moving-enemy','enemies'],['moving-lift','geometry']]){
  const body=view[key].find(q=>q.id===id),light=byId.get(id);if(body&&!body.removed&&!body.dead){assert(light);assert.deepEqual({x:light.x,y:light.y},centre(body));}else assert.equal(light,undefined);
 }
 return sources;
}

export function assertSwitchLightingStage(doc,{resolve,Stage,Motor}={}){
 const s=nativeSession(doc,{Stage,Motor}),room=s.doc.rooms[0],authored=JSON.stringify(s.doc),initial=s.view(),check=()=>assertSwitchLightView(room,s.view(),resolve);
 check();s.frames(3);const off=s.until(v=>v.switchStudy.toggles===1,{jump:true},30);check();assert.equal(off.switchStudy.on,false);assert(off.geometry.some(q=>q.id==='blue'));assert(!off.geometry.some(q=>q.id==='red'));
 const enemyX=initial.enemies.find(q=>q.id==='moving-enemy').x,powY=initial.items.find(q=>q.id==='falling-pow').y,liftY=initial.geometry.find(q=>q.id==='moving-lift').y;
 for(let i=0;i<45;i++){s.step({jump:true});check();}assert.equal(s.view().switchStudy.toggles,1);
 assert.notEqual(s.view().enemies.find(q=>q.id==='moving-enemy').x,enemyX);assert(s.view().items.find(q=>q.id==='falling-pow').y>powY);assert.notEqual(s.view().geometry.find(q=>q.id==='moving-lift').y,liftY);
 s.step({jump:false});const on=s.until(v=>v.switchStudy.toggles===2,{jump:true},30);check();assert.equal(on.switchStudy.on,true);assert(on.geometry.some(q=>q.id==='red'));assert(!on.geometry.some(q=>q.id==='blue'));
 assert.equal(s.events.filter(q=>q.type==='switch-study').length,2);assert.equal(s.view().lives,3);assert.equal(JSON.stringify(s.doc),authored);
 return {frames:s.view().tick,naturalHeadHits:2,offShrinksAll:true,onRestoresAuthored:true,enemyMoved:true,powFell:true,liftMoved:true,livePBound:true,switchIsSource:false,authoredStateUnchanged:true,originalTimingCalibrated:false};
}
