/** Synthetic neutral guard contract. These small coordinates define test timing,
 * not a playable private course, reference transcription or user input record. */
import {blank} from '../../atlas/editor-model.mjs';
import {CHAIN_CHOMP_GUARD_DEFAULTS} from '../../atlas/editor-chain-chomp-guard.mjs';
export function guardProject({spawnX=35,spawnY=378,wall=false,guard=true}={}){
 const project=blank('Neutral tethered guard contract',448,432),room=project.rooms[0];
 project.id='neutral-tethered-guard';room.roomId='guard-room';room.setting='Ghost House Night';
 project.fixture={kind:'synthetic-neutral',note:'Mechanism test data only; no private map or input route included'};
 room.map.geometry=[{id:'guard-floor',x:0,y:392,w:448,h:40,collision:'solid',material:'ground'}];
 if(wall)room.map.geometry.push({id:'guard-wall',x:136,y:328,w:16,h:64,collision:'solid',material:'stone'});
 room.map.objects=[{id:'start',kind:'spawn',x:spawnX,y:spawnY,w:10,h:14},{id:'guard-head',kind:'walker',x:88,y:360,w:32,h:32},{id:'safe-coin',kind:'coin',x:198,y:378,w:8,h:14},{id:'safe-exit',kind:'exit',x:400,y:360,w:16,h:32}];
 room.playRules={version:1,timeLimit:500,timerFrames:60,viewportWidth:384,viewportHeight:216,cameraAnchor:208};
 room.smm2Mechanics={version:1,startingLives:5,art:{palette:'smb1-ghost-source',tileOriginX:0,tileOriginY:8},lighting:{darkness:1,playerRadius:52,softness:.08,sources:[{targetId:'guard-head',radius:84}]}};
 room.markers.push({id:'guard-goal',kind:'flagpole-finish',x:400,y:392,source:{poleHeight:32,walkDistance:32}});
 room.contraptions={version:1,...(guard?{chainChompGuards:[{actorId:'guard-head',postId:'guard-post',post:{x:72,y:368,w:16,h:24,anchorX:80,anchorY:376},rest:{x:104,y:376},...structuredClone(CHAIN_CHOMP_GUARD_DEFAULTS)}]}:{})};
 return project;
}
export const guardRule=project=>project.rooms[0].contraptions.chainChompGuards[0];
