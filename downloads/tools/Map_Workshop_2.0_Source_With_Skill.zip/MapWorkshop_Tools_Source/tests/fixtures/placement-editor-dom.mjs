import fs from 'node:fs/promises';
import {createCanvas} from '@napi-rs/canvas';
import {installSimulatedPlayDom} from './simulated-play-dom.mjs';

/** Real editor module and raster canvas in the existing simulated DOM; no browser. */
export async function mountPlacementEditor(project){
 const ui=installSimulatedPlayDom(),prior=new Map(),timers=new Map(),data=new Map([['xiaoq-map-workshop-tools-v1',JSON.stringify(project)]]),blobs=new Map(),downloads=[];
 const set=(key,value)=>{prior.set(key,Object.getOwnPropertyDescriptor(globalThis,key));Object.defineProperty(globalThis,key,{value,writable:true,configurable:true});};
 const originalClick=ui.Element.prototype.click;
 ui.Element.prototype.click=function(){if(this.tag==='a'&&this.download)downloads.push({name:this.download,blob:blobs.get(this.href)});return originalClick.call(this);};
 ui.Element.prototype.closest=function(selector){for(let p=this;p;p=p.parentNode)if(selector.split(',').some(s=>{s=s.trim();return s.startsWith('.')?p.classList.contains(s.slice(1)):p.tag===s;}))return p;return null;};
 ui.Element.prototype.after=function(node){if(!this.parentNode)return;const index=this.parentNode.children.indexOf(this);this.parentNode.children.splice(index+1,0,node);node.parentNode=this.parentNode;};
 ui.Element.prototype.removeAttribute=function(name){delete this.attributes[name];};
 ui.Element.prototype.scrollIntoView=function(){};
 ui.Element.prototype.getBoundingClientRect=function(){return {left:0,top:0,width:this.width||512,height:this.height||256};};
 ui.Element.prototype.getContext=function(){
  const node=this,ensure=()=>{const width=node.width||300,height=node.height||150;if(!node.raster||node.raster.width!==width||node.raster.height!==height)node.raster=createCanvas(width,height);return node.raster.getContext('2d');};
  if(!this.contextProxy)this.contextProxy=new Proxy({}, {get(_target,key){const ctx=ensure(),value=ctx[key];if(typeof value!=='function')return value;return (...args)=>{if(key==='drawImage'){if(args[0]?.tag==='canvas'){args[0].getContext('2d');args[0]=args[0].raster;}else if(args[0] instanceof globalThis.Image)return;}return ensure()[key](...args);};},set(_target,key,value){ensure()[key]=value;return true;}});return this.contextProxy;
 };
 const html=await fs.readFile(new URL('../../atlas/editor.html',import.meta.url),'utf8');ui.document.body.innerHTML=html.slice(html.indexOf('<body>')+6,html.indexOf('<script type="module"'));
 const $=id=>ui.document.getElementById(id);for(const q of ui.document.querySelectorAll('input'))q.value=q.getAttribute('value')||'';
 $('zoom').value='1';$('layer').value='geometry';$('view').value='effect';$('spacing').value='2';$('viewport').clientWidth=512;$('viewport').clientHeight=256;
 set('devicePixelRatio',1);set('ResizeObserver',class{constructor(fn){this.fn=fn;}observe(){this.fn();}});set('localStorage',{getItem:key=>data.get(key)||null,setItem:(key,value)=>data.set(key,value),removeItem:key=>data.delete(key)});set('confirm',()=>true);
 let timerId=0;set('setTimeout',(fn,ms)=>{timers.set(++timerId,{fn,ms});return timerId;});set('clearTimeout',id=>timers.delete(id));
 set('fetch',async input=>{const url=typeof input==='string'?new URL(input,new URL('../../atlas/editor.mjs',import.meta.url)):input,bytes=await fs.readFile(url);return {ok:true,text:async()=>bytes.toString('utf8'),json:async()=>JSON.parse(bytes.toString('utf8')),arrayBuffer:async()=>bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength)};});
 const oldCreate=URL.createObjectURL,oldRevoke=URL.revokeObjectURL;URL.createObjectURL=blob=>{const url='blob:simulated-'+blobs.size;blobs.set(url,blob);return url;};URL.revokeObjectURL=()=>{};
 try{await import('../../atlas/editor.mjs?placement-dom='+Date.now());}catch(error){for(const [key,desc]of prior){if(desc)Object.defineProperty(globalThis,key,desc);else delete globalThis[key];}URL.createObjectURL=oldCreate;URL.revokeObjectURL=oldRevoke;ui.restore();throw error;}
 const pointer=(type,x,y)=>$('canvas').dispatchEvent({type,button:0,pointerId:1,clientX:x,clientY:y});
 return {ui,$,data,downloads,pointer,document:()=>JSON.parse(data.get('xiaoq-map-workshop-tools-v1')),async png(file){await fs.writeFile(file,$('canvas').raster.toBuffer('image/png'));},restore(){URL.createObjectURL=oldCreate;URL.revokeObjectURL=oldRevoke;for(const [key,desc]of prior){if(desc)Object.defineProperty(globalThis,key,desc);else delete globalThis[key];}ui.restore();}};
}
