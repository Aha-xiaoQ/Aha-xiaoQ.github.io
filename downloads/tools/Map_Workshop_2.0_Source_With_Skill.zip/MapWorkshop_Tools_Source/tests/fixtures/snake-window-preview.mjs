import {createSnakeWindowPreview, stepSnakeWindowPreviewPlayer} from '../../atlas/editor-snake-window-preview.mjs';
import {createPlatformMotor} from '../../atlas/editor-mario-motor.mjs';

/** Neutral authoring fixture. Geometry follows the observed turn pattern.
 * Its phase, count and speed are authored fit hypotheses, not game calibration.
 * Last waypoint covers a finite display range; it is not an original endpoint.
 */
export function snakeWindowPreviewDocument(overrides = {}) {
  return {
    format: 'snake-window-preview', version: 1, id: 'neutral-window', tileSize: 16,
    origin: {x: 145.35, y: 159.75},
    path: [
      {id: 'earlier-vertical', x: 0, y: 0},
      {id: 'lower-start', x: 0, y: 16},
      {id: 'lower-bend', x: 64, y: 16},
      {id: 'middle-bend', x: 64, y: 0},
      {id: 'front-up-turn', x: 112, y: 0},
      {id: 'front-left-turn', x: 112, y: -16},
      {id: 'authored-observation-cutoff', x: 48, y: -16}
    ],
    lengthCells: 9, initialHeadDistancePx: 134.9, speedPxPerSecond: 60,
    observationDurationMs: 1334.668, parameterStatus: 'authored-not-calibrated',
    ...overrides
  };
}

/** Existing motor, genuine falling contact, ordinary input only, no teleport. */
export function snakeWindowPreviewMotorSession({document = snakeWindowPreviewDocument(), spawn} = {}) {
  const controller = createSnakeWindowPreview(document), motor = createPlatformMotor();
  const character = {motion: {width: 12, height: 16}};
  const contact = controller.snapshot().fixedContactCells.find(cell => cell.id.endsWith(':80,0'));
  const initialSpawn = spawn || {x: contact.x + 2, y: contact.y - 48};
  const player = motor.create(character, initialSpawn), world = {width: 384, height: 216, solids: []};
  const trace = [];
  function step(input = {}, deltaMs = 1000 / 60) {
    const snapshot = controller.tick(deltaMs);
    const result = stepSnakeWindowPreviewPlayer({motor, player, input, character, world, snapshot});
    const frame = {snapshot, player: {...player}, ...result};
    trace.push(frame);
    return frame;
  }
  return {controller, motor, character, player, world, trace, step};
}
