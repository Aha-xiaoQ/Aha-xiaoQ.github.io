// Neutral synthetic fixture. These authored lighting values do not reproduce or
// calibrate any original course, darkness profile, physics or input timing.
import assert from 'node:assert/strict';
import {blank} from '../../atlas/editor-model.mjs';
import {nativeSession} from './shell-coin-native.mjs';

export function lightingProject({enabled=true,setting='Overworld Night'}={}){
 const doc=blank('Synthetic night lighting workshop',640,288),room=doc.rooms[0];
 doc.id='neutral-night-lighting-v1';
 room.setting=setting;
 room.map.geometry=[
  {id:'floor',x:0,y:224,w:640,h:64,collision:'solid',material:'ground'},
  {id:'moving-lift',x:400,y:144,w:64,h:8,collision:'oneway',material:'stone',motion:{axis:'y',min:112,max:192,speed:1}},
 ];
 room.map.objects=[
  {id:'start',kind:'spawn',x:32,y:80,w:10,h:14},
  {id:'lamp-coin',kind:'coin',x:128,y:210,w:8,h:14},
  {id:'moving-enemy',kind:'walker',x:240,y:208,w:16,h:16},
  {id:'falling-pow',kind:'walker',x:336,y:80,w:16,h:16},
  {id:'unbound-enemy',kind:'walker',x:560,y:208,w:16,h:16},
 ];
 room.markers=[
  {id:'moving-enemy',kind:'enemy-goomba',x:240,y:208,source:{thing:'Goomba'}},
  {id:'unbound-enemy',kind:'enemy-goomba',x:560,y:208,source:{thing:'Goomba'}},
  {id:'fixed-arrow',kind:'source-arrow',x:496,y:144,source:{direction:'right'}},
 ];
 room.playRules={version:1,timeLimit:600,timerFrames:24,viewportWidth:256,viewportHeight:240,cameraAnchor:100};
 room.smm2Mechanics={version:1,powBlocks:[{id:'falling-pow',gravity:.4375,maxFallSpeed:4.25,blastRadius:64,supportedScreenEffect:false}]};
 if(enabled)room.smm2Mechanics.lighting={darkness:.9,playerRadius:40,softness:.25,sources:[
  {targetId:'lamp-coin',radius:24},
  {targetId:'moving-enemy',radius:32},
  {targetId:'falling-pow',radius:40},
  {targetId:'moving-lift',radius:48},
  {targetId:'fixed-arrow',radius:24,offsetX:8,offsetY:8},
 ]};
 return doc;
}

export const centre=body=>({x:body.x+body.w/2,y:body.y+body.h/2});
export function assertNativeLightingMotion(doc,{resolve,Stage,Motor}={}){
 const session=nativeSession(doc,{Stage,Motor}),room=session.doc.rooms[0],initial=session.view();
 const initialEnemy=initial.enemies.find(q=>q.id==='moving-enemy'),initialPow=initial.items.find(q=>q.id==='falling-pow'),initialLift=initial.geometry.find(q=>q.id==='moving-lift');
 assert(initialEnemy&&initialPow&&initialLift,'real preplaced enemy, POW and moving geometry exist');
 let enemyMoved=false,powFell=false,liftMoved=false,coinTaken=false;
 const frames=[];
 for(let frame=1;frame<=150;frame++){
  const view=session.step(frame<=65?{}:viewInput(session.view()));
  const sources=resolve(room,view),byId=new Map(sources.map(q=>[q.targetId,q]));
  assert.equal(byId.size,sources.length);
  for(const [id,key]of [['moving-enemy','enemies'],['falling-pow','items'],['moving-lift','geometry']]){
   const body=view[key].find(q=>q.id===id),light=byId.get(id);
   if(body){assert(light,'live light remains bound to '+id);assert.deepEqual({x:light.x,y:light.y},centre(body));}
   else assert.equal(light,undefined,'removed real body leaves no light: '+id);
  }
  const enemy=view.enemies.find(q=>q.id==='moving-enemy'),pow=view.items.find(q=>q.id==='falling-pow'),lift=view.geometry.find(q=>q.id==='moving-lift');
  enemyMoved||=!!enemy&&enemy.x!==initialEnemy.x;powFell||=!!pow&&pow.y>initialPow.y;liftMoved||=lift.y!==initialLift.y;
  assert(!byId.has('unbound-enemy'),'no automatic NPC light');
  if(view.coins){coinTaken=true;assert(!view.objects.some(q=>q.id==='lamp-coin'));assert(!byId.has('lamp-coin'));}
  frames.push({frame,player:view.p,sources,coins:view.coins});
 }
 assert(enemyMoved&&powFell&&liftMoved&&coinTaken,'genuine native input moves all three bodies and takes the coin');
 assert.equal(session.view().lives,3);
 return {frames:frames.length,naturalInputs:true,enemyMoved,powFell,liftMoved,coinTaken,automaticNpcLight:false,stateMutatedDuringPlay:false,trace:frames};
}
function viewInput(view){return {x:view.p.x<136?1:0};}
