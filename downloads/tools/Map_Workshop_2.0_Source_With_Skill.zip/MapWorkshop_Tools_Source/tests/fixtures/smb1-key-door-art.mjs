import assert from 'node:assert/strict';
import {parseProject} from '../../atlas/editor-model.mjs';
import {nativeSession} from './shell-coin-native.mjs';

/** Synthetic artwork/contact fixture, without private maps or input routes. */
export function smb1KeyDoorArtProject(){
 const room=(roomId)=>({roomId,setting:'Overworld',markers:[],decorations:[],map:{id:'neutral-key-door-'+roomId,title:'Neutral key/door source art',width:384,height:240,tileSize:16,geometry:[{id:'floor',x:0,y:224,w:384,h:16,collision:'solid',material:'ground'}],objects:[{id:'start',kind:'spawn',x:48,y:210,w:10,h:14}],provenance:{kind:'original',source:'Neutral original-source art fixture',review:'pending',note:'Ordinary native key acquisition and paired door appearance'}},contraptions:{version:1,scene:'desert'}});
 const a=room('main'),b=room('return');
 a.map.objects.push({id:'locked',kind:'portal',x:160,y:192,w:16,h:32,targetRoom:'return',targetSpawn:'start'});
 b.map.objects.push({id:'plain',kind:'portal',x:32,y:192,w:16,h:32,targetRoom:'main',targetSpawn:'start'});
 a.contraptions.notes=[{id:'key-note',x:48,y:176,w:16,h:16,reward:'key'}];
 a.contraptions.doors=[{id:'locked',pairId:'neutral-pair',style:'key'}];
 b.contraptions.doors=[{id:'plain',pairId:'neutral-pair',style:'plain'}];
 return parseProject(JSON.stringify({format:'xiaoq-map-project',version:1,id:'neutral-smb1-key-door-art',title:'Neutral SMB1 key/door source art',reference:null,rooms:[a,b]}));
}

export function runKeyDoorArtFixture({session=nativeSession(smb1KeyDoorArtProject()),onFrame=()=>{}}={}){
 const step=raw=>{const view=session.step(raw);onFrame(view,session);return view;};
 for(let n=0;n<64;n++)step({jump:n>=3&&n<23});
 assert.equal(session.view().contraptions.keys,1,'ordinary note head contact delivers one key');
 let n=0;while(session.view().p.x<160){step({x:1});assert(++n<180,'door approach must use ordinary movement');}
 step({up:true});
 n=0;while(session.view().roomId!=='return'){step({});assert(++n<60,'real paired-door transition');}
 assert.equal(session.view().contraptions.keys,0);
 assert(session.view().contraptions.doors.every(q=>q.unlocked===true));
 assert.equal(session.events.filter(q=>q.event==='key-collected').length,1);
 assert.equal(session.events.filter(q=>q.event==='door-unlocked').length,1);
 return session;
}
