import {blank} from '../../atlas/editor-model.mjs';
export {nativeSession} from './npc-platform-native.mjs';

/** Neutral authored room for the live Dry Bones/platform integration probe.
 * The final bank is closer than the full course so a Small Mario landing is
 * independently reachable. No geometry or timing claims reproduce SMM2. */
export function dryBonesLowCeilingProject({bones=true}={}) {
 const d=blank('Neutral collapsed enemy platform probe',896,432),r=d.rooms[0];
 r.map.geometry=[
  {id:'start-floor',x:0,y:400,w:192,h:32,collision:'solid',material:'ground'},
  {id:'lift',x:192,y:400,w:80,h:8,collision:'oneway',material:'platform',motion:{axis:'x',min:192,max:480,speed:.75}},
  {id:'ceiling',x:352,y:352,w:96,h:32,collision:'solid',material:'stone'},
  {id:'end-floor',x:576,y:400,w:320,h:32,collision:'solid',material:'ground'}
 ];
 r.map.objects=[{id:'start',kind:'spawn',x:176,y:386,w:10,h:14},
  ...(bones?[{id:'bones',kind:'walker',x:220,y:376,w:16,h:24}]:[])];
 r.marioModules={version:1,itemSources:[],noteBlocks:[],oneWayWalls:[],
  carryEnemiesOnPlatforms:true,enemyVariants:bones?{
   bones:{kind:'dry-bones',size:'normal',speed:.25,direction:1,collapsedHeight:8,
    collapseFrames:180,recoverFrames:24,bounceSpeed:3.2}
  }:{}};
 return d;
}

/** Fixed floor plus an actual moving solid. Spawn448 clears the initial roof
 * edge440 so the first ordinary jump is possible without a head strike. */
export function dryBonesMovingRoofProject() {
 const d=blank('Neutral moving solid recovery probe',896,432),r=d.rooms[0];
 r.map.geometry=[
  {id:'floor',x:0,y:400,w:896,h:32,collision:'solid',material:'ground'},
  {id:'roof',x:344,y:368,w:96,h:16,collision:'solid',material:'stone',
   motion:{axis:'x',min:344,max:608,speed:.65}}
 ];
 r.map.objects=[{id:'start',kind:'spawn',x:448,y:386,w:10,h:14},
  {id:'bones',kind:'walker',x:496,y:376,w:16,h:24}];
 r.marioModules={version:1,itemSources:[],noteBlocks:[],oneWayWalls:[],
  enemyVariants:{bones:{kind:'dry-bones',size:'normal',speed:.25,direction:-1,
   collapsedHeight:8,collapseFrames:150,recoverFrames:24,bounceSpeed:3.2}}};
 return d;
}
