import fs from 'node:fs';
import assert from 'node:assert/strict';
import {blank,parseProject} from '../../atlas/editor-model.mjs';
import {projectPack} from '../../atlas/editor-runtime.mjs';
import {createStageCatalog} from '../../atlas/runtime/stage-catalog.mjs';
import {createPlatformMotor} from '../../atlas/editor-mario-motor.mjs';
import {createPlatformStage} from '../../atlas/editor-mario-stage.mjs';
export const character=JSON.parse(fs.readFileSync(new URL('../../atlas/runtime/character.json',import.meta.url)));
export const overlaps=(a,b)=>a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y;
export function shellProject({rule=true,type='koopa',pink=false,coins=[160,192,224],wall=false,drop=false}={}){
 const d=blank('Synthetic activated-shell contact',640,288),r=d.rooms[0];
 r.map.geometry=[{id:'floor',x:0,y:224,w:640,h:64,collision:'solid',material:'ground'}];
 if(wall)r.map.geometry.push({id:'wall',x:320,y:160,w:16,h:64,collision:'solid',material:'stone'});
 if(drop)r.map.geometry=[{id:'upper',x:0,y:176,w:128,h:112,collision:'solid',material:'ground'},{id:'lower',x:128,y:224,w:512,h:64,collision:'solid',material:'ground'}];
 r.map.objects=[{id:'start',kind:'spawn',x:96,y:32,w:10,h:14},{id:'shell-body',kind:'walker',x:96,y:drop?152:200,w:16,h:24},...coins.map((x,i)=>({id:'coin-'+i,kind:'coin',x,y:208,w:8,h:14}))];
 r.markers.push({id:'shell-body',kind:'enemy-'+type,x:96,y:drop?152:200,source:{thing:type==='koopa'?'Koopa':'Beetle',smart:false}});
 r.playRules={version:1,timeLimit:600,timerFrames:24,viewportWidth:256,viewportHeight:240,cameraAnchor:100};
 r.smm2Mechanics={version:1,...(rule===null?{}:{shellCoinCollection:rule}),...(pink?{pinkCoins:r.map.objects.filter(q=>q.kind==='coin').map(q=>({id:q.id}))}:{})};
 return d;
}
export function nativeSession(doc,{initialState=null,direct=false,Stage=createPlatformStage,Motor=createPlatformMotor}={}){
 const d=direct?structuredClone(doc):parseProject(JSON.stringify(doc)),r=d.rooms[0],pack=direct?null:projectPack(d,r.roomId,character,'shell-contact-test'),plan=direct?{stage:{entryRoom:r.roomId,entrySpawn:'start',title:d.title},character:{...character,motion:{...character.motion,width:10,height:14,maxHealth:1}},rooms:Object.fromEntries(d.rooms.map(r=>[r.roomId,r.map]))}:createStageCatalog(pack).plan(pack.stages[0].id,pack.characters[0].id,{allowDraft:true}),events=[],inputs=[],trace=[];let frame=0;
 const stage=Stage({plan,motor:Motor(),visualRooms:d.rooms,initialState,manualDeath:true,autoContinue:false,allowWarp:false,emit:(type,data)=>events.push({frame:frame+1,type,...data})});
 const s={doc:d,pack,plan,stage,events,inputs,trace,view:()=>stage.view(),step(raw={}){assert(Object.keys(raw).every(k=>['x','jump','run','down','up','attack','interact'].includes(k)));stage.step(raw);inputs.push({...raw});frame++;const v=stage.view();trace.push({frame,p:v.p,enemies:v.enemies,items:v.items,coins:v.coins,score:v.score,lives:v.lives,pink:v.smm2Mechanics?.pinkCoins,keys:v.contraptions?.keys});return v;},frames(n,raw={}){for(let j=0;j<n;j++)s.step(raw);return s.view();},until(fn,raw={},limit=1000){for(let j=0;j<limit;j++){const v=s.step(typeof raw==='function'?raw(s.view()):raw);if(fn(v))return v;}throw Error('Natural shell input timed out '+JSON.stringify(s.view().p));}};
 return s;
}
export function stompToStationary(s){return s.until(v=>v.enemies[0]?.shell&&v.enemies[0].vx===0,v=>{const dx=v.enemies[0].x+3-v.p.x;return{x:Math.abs(dx)>1?Math.sign(dx):0};},180);}
export function kickRight(s){if(!s.view().p.grounded)s.until(v=>v.p.grounded,{x:-1},120);return s.until(v=>v.enemies[0]?.shell&&v.enemies[0].vx>1,{x:1,run:true},180);}
export function activate(s){stompToStationary(s);return kickRight(s);}
export function shellPickups(s){return s.events.filter(e=>e.type==='smm2-shell'&&e.event==='coin-collected');}
export function checkPhysicalPickups(s){for(const e of shellPickups(s)){const v=s.trace[e.frame-1],coin=s.doc.rooms.find(r=>r.roomId===e.roomId).map.objects.find(o=>o.id===e.coinId),shell=v.enemies.find(a=>a.id===e.actorId);assert(shell&&shell.shell&&Math.abs(shell.vx)>1);assert(overlaps(shell,coin),'real shell contact at '+e.frame);assert(!overlaps(v.p,coin),'player stays away at '+e.frame);}}
