import assert from 'node:assert/strict';
import {blank} from '../../atlas/editor-model.mjs';
import {addSmm2Component,bindSmm2SpringSupport} from '../../atlas/editor-smm2-authoring.mjs';
import {nativeSession} from './shell-coin-native.mjs';

/** Neutral workshop acceptance, not a Nintendo course reconstruction. Every
 * gravity, mass, angle and impulse value is an authored local approximation.
 * The real existing Springboard art and native compression/bounce are reused. */
export function weightedSpringProject({impact=true,playerOnSpring=true,mass=2,gravity=.3,maxFallSpeed=4.25,weightAcceleration=.01,springX=144,springSize=16,pivotY=256,maxAngleDegrees=24,playerX,playerY,cargo=null}={}){
 const d=blank('Weighted Springboard mechanism acceptance',640,384),r=d.rooms[0];d.id='weighted-spring-seesaw-neutral';
 r.map.provenance={kind:'original',source:'Map workshop neutral mechanism acceptance',review:'pending',note:'Neutral mechanism fixture; all numerical tuning is an authored approximation, not a Nintendo course reconstruction.'};
 const springY=pivotY-4-springSize;
 r.map.geometry=[{id:'floor',x:0,y:336,w:640,h:48,material:'ground',collision:'solid'},{id:'spring',x:springX,y:springY,w:springSize,h:springSize,material:'spring',collision:'solid'}];
 r.map.objects=[{id:'start',kind:'spawn',x:playerX??(playerOnSpring?springX+3:280),y:playerY??(playerOnSpring?springY-14:pivotY-18),w:10,h:14}];
 r.playRules={version:1,timeLimit:600,timerFrames:24,viewportWidth:384,viewportHeight:240,cameraAnchor:192};
 addSmm2Component(r,'seesaw',{id:'board',pivotX:224,pivotY,length:192,thickness:8,initialAngleDegrees:0,maxAngleDegrees,weightAcceleration,maxAngularSpeedDegrees:2,damping:.985,impactSpeedThreshold:2,impactGain:2,maxLaunchSpeed:10,impactMinLeverFraction:.12,impactPolicy:'thwomp'});
 bindSmm2SpringSupport(r,'spring','board',{carrierType:'seesaw',mass,gravity,maxFallSpeed});
 if(impact)addSmm2Component(r,'thwomp',{id:'weight',x:288,y:192,w:24,h:32,direction:'down',triggerRange:320,transverseTolerance:192,leadReference:'near-edge',windupFrames:0,chargeAcceleration:.8,chargeSpeedCap:8,impactWaitFrames:30,returnSpeed:1,breakMaterials:[],mass:1});
 if(cargo==='pow')addSmm2Component(r,'pow',{id:'cargo',x:springX+(springSize-16)/2,y:springY-16,w:16,h:16,gravity:.3,maxFallSpeed:4.25,blastRadius:64,supportedScreenEffect:false});
 else if(cargo!==null)throw Error('Unknown neutral cargo fixture');
 return d;
}

export function weightedSpringSession(options={},runtime={}){return nativeSession(weightedSpringProject(options),runtime);}

const namedScene=(d,scene,title)=>{d.id+='-'+scene;d.title=title;d.rooms[0].map.title=title;return d;};
export const weightedSpringLiftProject=()=>namedScene(weightedSpringProject({impact:false,playerOnSpring:false,mass:.5}),'lift','Springboard opposite-weight lift acceptance');
export const weightedSpringDropProject=()=>namedScene(weightedSpringProject({impact:false,playerOnSpring:false,springX:128,pivotY:224,maxAngleDegrees:60,weightAcceleration:.3,gravity:2,maxFallSpeed:8,playerX:64,playerY:322}),'drop','Springboard finite-support drop acceptance');
export const weightedSpringCargoProject=()=>namedScene(weightedSpringProject({impact:false,playerOnSpring:false,springX:200,playerX:267,playerY:238,cargo:'pow'}),'cargo','POW-to-Springboard real support-chain acceptance');

export function assertNaturalSpringLift(s,{frames=24}={}){
 const source=s.doc.rooms[0].map.geometry.find(q=>q.id==='spring');let moved=false;
 for(let n=0;n<frames;n++){
  const v=s.step({}),q=v.geometry.find(q=>q.id==='spring'),b=v.smm2Mechanics.seesaws[0];assert(q);assert.equal(v.lives,3);assert(!v.p.dying);assert.equal(v.p.support,'board');assert.equal(q.support,'board');assert.equal(b.leftMass,.5);assert.equal(b.rightMass,1);assert.equal(q.y+q.h,q.restY+q.restH);if(q.y<source.y-.2)moved=true;
 }
 assert(moved);assert.equal(s.events.filter(e=>e.type==='smm2-terrain'&&e.event==='seesaw-impact-launch').length,0);
 const q=s.view().geometry.find(q=>q.id==='spring');return {frames:s.inputs.length,sourceY:source.y,finalY:q.y,raisedPixels:source.y-q.y,leftMass:.5,rightMass:1};
}

/** Source-only high angle causes the actual finite top to leave a still-x
 * Spring foot. Every runtime action remains an ordinary empty raw input. */
export function assertNaturalSpringDrop(s,{limit=120}={}){
 const source=s.doc.rooms[0].map.geometry.find(q=>q.id==='spring');let detached=false,leftBoard=false,landed=null;
 for(let n=0;n<limit;n++){
  const v=s.step({}),q=v.geometry.find(q=>q.id==='spring');assert(q);assert.equal(q.x,source.x);assert.equal(v.lives,3);assert(!v.p.dying);
  const state=v.smm2Mechanics.carriers.carrierGeometry[0],surface=v.smm2Mechanics.surfaces.find(q=>q.id==='board');
  if(!q.grounded)detached=true;
  if(q.x+q.w<=surface.a.x||q.x>=surface.b.x)leftBoard=true;
  if(leftBoard&&q.support==='floor'){assert.equal(state.phase,'resting');assert.equal(q.y+q.h,336);assert.equal(q.vy,0);landed=v;break;}
 }
 assert(detached);assert(leftBoard);assert(landed,'source angle contraction must let the body fall onto the actual floor');
 return {frames:s.inputs.length,landingTick:landed.tick,sourceX:source.x,finalX:source.x,floorY:336,detached,leftBoard};
}

export function assertNaturalSpringCargo(s,{frames=24}={}){
 for(let n=0;n<frames;n++){
  const v=s.step({}),q=v.geometry.find(q=>q.id==='spring'),cargo=v.items.find(q=>q.id==='cargo'),b=v.smm2Mechanics.seesaws[0];assert(q&&cargo);assert.equal(v.lives,3);assert(!v.p.dying);
  assert.equal(q.support,'board');assert.equal(cargo.support,'spring');assert(cargo.grounded);assert.equal(cargo.y+cargo.h,q.y);assert.equal(cargo.smm2Pow.phase,'live');assert.equal(v.p.support,'board');assert.equal(b.leftMass,3);assert.equal(b.rightMass,1);assert(Math.abs(b.moment)<1e-12);assert(Math.abs(b.angleDegrees)<1e-12);
 }
 assert.equal(s.events.filter(q=>q.event==='pow-activate').length,0);
 return {frames:s.inputs.length,cargoId:'cargo',cargoKind:'pow',actualSupportChain:['cargo','spring','board'],leftMass:3,rightMass:1,moment:0,npcBounceUnified:false};
}

/** Ordinary raw inputs from source spawn; no state injection or teleport. */
export function assertNaturalSpringImpact(s,{limit=60}={}){
 let impact=null,previous=null;
 for(let n=0;n<limit;n++){
  const v=s.step({}),event=s.events.find(e=>e.type==='smm2-terrain'&&e.event==='seesaw-impact-launch');
  assert.equal(v.lives,3);assert(!v.p.dying);
  if(event){impact={view:v,event,previous};break;}previous=v;
 }
 assert(impact,'genuine falling Thwomp must launch the opposite Spring and its actual stander');
 const {view:v,event,previous:before}=impact,spring=v.geometry.find(q=>q.id==='spring');
 assert(event.launchedIds.includes('spring'));assert(event.launchedIds.some(id=>id!=='spring'));
 assert(before.p.grounded&&before.p.support==='spring');assert(before.p.springId==='spring');
 assert(spring.vy<0);assert.equal(v.p.vy,spring.vy);assert.equal(v.p.grounded,false);assert.equal(v.p.support,null);assert.equal(v.p.springId,null);
 assert.equal(spring.grounded,false);assert.equal(spring.support,null);
 assert.equal(v.smm2Mechanics.seesaws[0].leftMass,0,'launched bodies leave no cached board load');
 const next=s.step({}),after=next.geometry.find(q=>q.id==='spring');
 assert(after.y<spring.y,'live launched Spring continues from its real velocity');
 assert(next.p.y<v.p.y,'stander remains airborne after native compression lock is released');
 assert.equal(next.p.grounded,false);assert.equal(next.p.springId,null);
 return {frames:s.inputs.length,impactTick:v.tick,incomingVy:event.incomingVy,launchSpeed:-spring.vy,springId:spring.id,launchedIds:event.launchedIds};
}
