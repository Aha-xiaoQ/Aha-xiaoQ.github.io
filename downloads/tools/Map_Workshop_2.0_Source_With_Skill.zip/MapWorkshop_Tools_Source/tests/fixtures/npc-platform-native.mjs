import {blank} from '../../atlas/editor-model.mjs';
import {nativeSession,shellProject,activate} from './shell-coin-native.mjs';
export {nativeSession,activate};
const modules=()=>({version:1,itemSources:[],noteBlocks:[],oneWayWalls:[],enemyVariants:{},carryEnemiesOnPlatforms:true});
/** Neutral mechanism fixtures; motion bounds/speeds are authored test values. */
export function plantPlatformProject({rule=true,speed=1.25,axis='y',initialY=144,plantY=120,plantX=184,winged=false}={}){
 const d=blank('Neutral enemy platform carry',640,288),r=d.rooms[0];
 r.map.geometry=[{id:'floor',x:0,y:272,w:640,h:16,collision:'solid',material:'ground'},{id:'lift',x:160,y:initialY,w:96,h:8,collision:'oneway',material:'platform',motion:axis==='y'?{axis,min:112,max:192,speed}:{axis,min:160,max:240,speed}}];
 r.map.objects=[{id:'start',kind:'spawn',x:32,y:258,w:10,h:14},{id:'plant',kind:'walker',x:plantX,y:plantY,w:16,h:24}];
 r.marioModules={...modules(),...(rule===null?{}:{carryEnemiesOnPlatforms:rule}),enemyVariants:{plant:{kind:'floor-piranha',size:'normal',winged,...(winged?{hopSpeed:3,hopIntervalFrames:18}:{})}}};
 if(rule===null)delete r.marioModules.carryEnemiesOnPlatforms;
 return d;
}
export function rollingPlatformProject(){
 const d=shellProject({drop:true,coins:[]}),r=d.rooms[0];r.map.width=768;
 r.map.geometry=[{id:'upper',x:0,y:176,w:128,h:112,collision:'solid',material:'ground'},{id:'lift',x:128,y:224,w:224,h:8,collision:'oneway',material:'platform',motion:{axis:'y',min:204,max:236,speed:.75}},{id:'lower',x:352,y:256,w:416,h:32,collision:'solid',material:'ground'}];
 r.map.objects.push({id:'ride-coin',kind:'coin',x:272,y:212,w:8,h:20},{id:'after-coin',kind:'coin',x:400,y:240,w:8,h:14});
 r.marioModules=modules();return d;
}
export function idleShellPlatformProject(){
 const d=plantPlatformProject(),r=d.rooms[0];r.map.objects=r.map.objects.filter(q=>q.kind!=='walker');r.marioModules.enemyVariants={};
 r.map.geometry.push({id:'source-pipe',x:176,y:48,w:32,h:32,collision:'solid',material:'pipe'});
 r.marioModules.enemySources=[{id:'supply',pipeId:'source-pipe',enemy:'beetle-shell',smart:false,direction:'down',intervalFrames:120,initialDelayFrames:0,maxAlive:1,maxEmissions:1,activationDistance:320,vx:0,vy:0,emergenceFrames:4}];
 return d;
}
