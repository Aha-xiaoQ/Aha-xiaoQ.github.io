import assert from 'node:assert/strict';
import {blank} from '../../atlas/editor-model.mjs';
import {nativeSession} from './shell-coin-native.mjs';

export function powCarrierProject(){
 const d=blank('Neutral falling POW supports',512,384),r=d.rooms[0];
 r.map.geometry=[{id:'floor',x:0,y:304,w:512,h:80,material:'ground',collision:'solid'}];
 r.map.objects=[{id:'start',kind:'spawn',x:88,y:290,w:10,h:14},{id:'thwomp',kind:'walker',x:120,y:80,w:48,h:64},{id:'pow-left',kind:'walker',x:124,y:64,w:16,h:16},{id:'pow-right',kind:'walker',x:140,y:64,w:16,h:16}];
 r.smm2Mechanics={version:1,thwomps:[{id:'thwomp',direction:'down',triggerRange:256,transverseTolerance:32,leadReference:'near-edge',windupFrames:0,chargeAcceleration:1,chargeSpeedCap:8,impactWaitFrames:8,returnSpeed:2,breakMaterials:[]}],powBlocks:['pow-left','pow-right'].map(id=>({id,gravity:.3,maxFallSpeed:4.25,blastRadius:64,supportedScreenEffect:false})),carrierItems:['pow-left','pow-right'].map(id=>({id,carrierId:'thwomp'})),lighting:{darkness:.9,playerRadius:32,sources:['pow-left','pow-right'].map(targetId=>({targetId,radius:24}))}};
 return d;
}

export function assertNativePowCarrierMotion(project,{Stage,Motor,resolve}={}){
 const s=nativeSession(project,{...(Stage?{Stage}:{}),...(Motor?{Motor}:{}),initialState:{lives:3}});let detached=false,caught=false,returned=false,previous=null;
 for(let n=0;n<220;n++){
  const v=s.step(),thwomp=v.enemies.find(a=>a.id==='thwomp');assert(thwomp);assert.equal(v.lives,3);assert(!v.p.dying);
  for(const a of v.items.filter(a=>a.kind==='pow')){
   const state=v.smm2Mechanics.carriers.carrierItems.find(q=>q.id===a.id);assert.equal(a.smm2Pow.phase,'live');assert.equal(a.w,16);assert.equal(a.h,16);assert.equal(a.y,state.y);assert.equal(a.vy,state.vy);
   if(state.phase==='airborne'&&thwomp.y>80){detached=true;assert(a.y+a.h<thwomp.y+1e-6);}
   if(detached&&state.phase==='supported'){caught=true;assert(Math.abs(a.y+a.h-thwomp.y)<1e-6);}
   if(caught&&thwomp.smm2Thwomp.phase==='return'&&a.smm2Pow.dy<0){returned=true;assert(Math.abs(a.y+a.h-thwomp.y)<1e-6);}
   if(previous){const old=previous.items.find(q=>q.id===a.id);assert(Math.abs(a.smm2Pow.dy-(a.y-old.y))<1e-6);}
   if(resolve){const light=resolve(s.doc.rooms[0],v).find(q=>q.targetId===a.id);assert(light);assert.equal(light.x,a.x+8);assert.equal(light.y,a.y+8);}
  }
  assert(!v.geometry.some(q=>q.id==='thwomp'),'bare Thwomp top must never become a Mario support');previous=v;
  if(returned&&thwomp.smm2Thwomp.phase==='idle')break;
 }
 assert(detached,'real charge outruns POW gravity');assert(caught,'falling POW really recontacts the moving top');assert(returned,'returning Thwomp physically lifts live POWs');
 assert.equal(s.events.filter(q=>q.event==='pow-activate').length,0);
 return {detached,caught,returned,frames:s.inputs.length,livePowIds:s.view().items.filter(q=>q.kind==='pow').map(q=>q.id)};
}
