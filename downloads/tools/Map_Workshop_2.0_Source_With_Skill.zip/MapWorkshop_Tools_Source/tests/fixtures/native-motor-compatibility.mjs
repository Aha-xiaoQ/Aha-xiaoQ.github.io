import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createPlatformMotor} from '../../atlas/editor-mario-motor.mjs';
let verified;
/** Protect the immutable pre-extension source and compare opt-out execution.
 * Optional carry/updraft modes may extend code; they must not alter old inputs. */
export function assertNativeMotorCompatibility(){
 return verified??=verify();
}
async function verify(){
 const text=fs.readFileSync(new URL('../native-baseline/editor-mario-motor.mjs',import.meta.url),'utf8');
 assert.equal(createHash('sha256').update(text).digest('hex'),'d9c0d6f30a1d540338969891a34f52e2673548e057f7310901057c15cddb5795','frozen original motor must not change');
 const code=text.replace("'./runtime/platform-motor.mjs'",JSON.stringify(new URL('../../atlas/runtime/platform-motor.mjs',import.meta.url).href));
 const {createPlatformMotor:baseline}=await import('data:text/javascript;base64,'+Buffer.from(code).toString('base64'));
 const character={capabilities:['jump'],motion:{width:10,height:14,maxHealth:1}};
 for(const profile of [{power:0},{power:1},{power:2},{power:0,hero:'bill'},{power:1,swimming:true}]){
  const old=baseline(),current=createPlatformMotor(),a=old.create(character,{x:24,y:210}),b=current.create(character,{x:24,y:210});
  Object.assign(a,profile);Object.assign(b,profile);if(profile.power){a.y-=14;b.y-=14;a.h=b.h=28;}
  const solids=[{id:'floor',x:0,y:224,w:256,h:64,collision:'solid'},{id:'wall',x:192,y:144,w:16,h:80,collision:'solid'},{id:'roof',x:64,y:128,w:96,h:16,collision:'solid'},{id:'lift',x:96,y:180,w:48,h:8,collision:'oneway',dy:0}];let priorJump=false;
  for(let tick=0;tick<720;tick++){
   const lift=solids[3],next=180+Math.sin(tick/31)*12;lift.dy=next-lift.y;lift.y=next;
   const jump=tick%89<22,input={x:Math.floor(tick/120)%2?-1:1,run:tick%180<100,down:tick%71>=58,jump,jumpPressed:jump&&!priorJump};priorJump=jump;
   const world={width:256,solids,swimming:!!profile.swimming};
   assert.deepEqual(current.step(b,{...input},character,world),old.step(a,{...input},character,world),'legacy events at tick '+tick);
   assert.deepEqual(b,a,'legacy body at tick '+tick);
  }
 }
 return {profiles:5,ticksPerProfile:720,observedStates:3600};
}
