import {BOWSER_JR_PARAMETER_STATUS} from '../../atlas/editor-bowser-jr.mjs';
import {bowserJrProject} from './bowser-jr-native.mjs';
/** Neutral authored pressure fixture, not measured original game timing. */
export function authoredJrStageTempo(){
 return {version:1,sourceParameterStatus:BOWSER_JR_PARAMETER_STATUS,stages:[3,2,1].map((hp,i)=>({hp,walkSpeed:[.5,.6,.7][i],shellSpeed:[2.6,2.9,3.15][i],shellAcceleration:[.16,.19,.22][i],initialFireDelayFrames:[60,50,40][i],recoveryFireDelayFrames:[32,25,20][i],fireIntervalFrames:[140,112,88][i],fireWindupFrames:[18,15,12][i],fireSpeed:[1.7,1.95,2.2][i]}))};
}
export function bowserJrTempoProject(options={}){
 const d=bowserJrProject(options);Object.assign(d.rooms[0].smm2Mechanics.bowserJuniors.actors[0],{hitTransitionFrames:15,hitHopSpeed:3.5,stageTempo:authoredJrStageTempo()});return d;
}
