// Neutral fixture with authored timing; no original-course or engine calibration.
import assert from 'node:assert/strict';
import {createCanvas} from '@napi-rs/canvas';
import {blank} from '../../atlas/editor-model.mjs';
import {nativeSession} from './shell-coin-native.mjs';

export function originalDonutProject(){
 const doc=blank('Neutral original Donut contact',384,240),r=doc.rooms[0];
 r.setting='Overworld';r.map.geometry=[{id:'floor',x:0,y:224,w:384,h:16,collision:'solid',material:'ground'}];
 r.map.objects=[{id:'start',kind:'spawn',x:100,y:102,w:10,h:14}];r.markers=[];r.decorations=[];
 r.smm2Mechanics={version:1,donuts:[{id:'native-donut',x:96,y:144,w:32,h:16,delayFrames:12,gravity:.5,maxFallSpeed:3,triggerPolicy:'player',resetPolicy:'leave-before-drop',collision:'oneway'}]};
 return doc;
}
export const rgba=c=>c.getContext('2d').getImageData(0,0,c.width,c.height).data;
export function rawPalettePng(bytes){
 const parts=[bytes.subarray(0,8)];for(let offset=8;offset<bytes.length;){const length=bytes.readUInt32BE(offset),end=offset+12+length,type=bytes.toString('ascii',offset+4,offset+8);if(['IHDR','PLTE','tRNS','IDAT','IEND'].includes(type))parts.push(bytes.subarray(offset,end));offset=end;}return Buffer.concat(parts);
}
export function assertNativeDonutContact({project=originalDonutProject(),image,drawWorld,Stage,Motor}={}){
 const s=nativeSession(project,{...(Stage?{Stage}:{}),...(Motor?{Motor}: {})}),r=s.doc.rooms[0],before=JSON.stringify(r),offsets=new Set();let shakingFrames=0,fallingFrames=0,removedFrames=0;
 for(let frame=0;frame<60;frame++){
  const view=s.step({}),q=view.smm2Mechanics.donuts[0],shift=q.phase==='shaking'?(Math.floor(q.contactFrames/2)%2?1:-1):0;
  if(q.phase==='shaking'){assert(q.contactFrames>0);assert.equal(view.p.support,q.id);offsets.add(shift);shakingFrames++;}
  if(q.phase==='falling'&&q.y>144)fallingFrames++;
  assert.equal(q.x,96,'cosmetic shake never translates the physics body');
  const collider=view.geometry.find(g=>g.id===q.id);if(q.phase==='removed'){assert.equal(collider,undefined);removedFrames++;}else{assert(collider);assert.equal(collider.x,q.x);assert.equal(collider.y,q.y);}
  const actual=createCanvas(384,240),expected=createCanvas(384,240),c=expected.getContext('2d');
  assert.equal(drawWorld(actual.getContext('2d'),r,view,999),q.phase!=='removed','actual live world reaches source art only while the Donut exists');
  if(q.phase!=='removed'){c.drawImage(image,Math.round(q.x)+shift,Math.round(q.y));c.drawImage(image,Math.round(q.x)+shift+16,Math.round(q.y));}
  assert.deepEqual(rgba(actual),rgba(expected),'live contact/falling pose preserves the original cells exactly');
 }
 assert(shakingFrames>=4);assert(fallingFrames>=4);assert(removedFrames>0);assert.deepEqual([...offsets].sort(),[-1,1]);assert.equal(JSON.stringify(r),before);
 return {frames:60,shakingFrames,fallingFrames,removedFrames,actualContact:true,originalCellsExact:true,originalTimingCalibrated:false};
}
