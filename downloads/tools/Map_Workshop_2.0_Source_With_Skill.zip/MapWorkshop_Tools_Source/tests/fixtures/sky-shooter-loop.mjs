import {skyShooterProject} from './sky-shooter.mjs';
export function neutralLoopProject(){
 const d=skyShooterProject(),s=d.rooms[0].smm2Mechanics.skyShooter;
 s.drones.forEach(q=>q.wave=1);
 s.loopingDivers={version:1,actorIds:['drone-a'],exitY:320,reentryY:100,sideX:144,exitSpeed:2.3,reentrySpeed:2.3,returnSpeed:2.3,maxActive:1};
 return d;
}

// Only the neutral author fixture is exported. An unused experimental input
// route failed its camera-boundary avoidance and is not a supported example.
