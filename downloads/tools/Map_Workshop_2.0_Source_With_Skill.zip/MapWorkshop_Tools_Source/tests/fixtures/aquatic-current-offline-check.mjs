// Execute the real HTML source closure, using the installed native Canvas backend.
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createContext,SourceTextModule} from 'node:vm';
import {createCanvas} from '@napi-rs/canvas';
import {inspectOfflineHtml} from '../../scripts/check-offline-html.mjs';
import {nativeWorld} from '../../render-lantern-course-native-canvas.mjs';
import {background,drawScenery} from '../../atlas/editor-art.mjs';

const checked=inspectOfflineHtml(fs.readFileSync(process.argv[2],'utf8'));let networkRequests=0,rasterScenes=0;
assert(checked.modules.has('workshop/editor-aquatic-art.mjs'));
const context=createContext({console,URL,TextEncoder,TextDecoder,Uint8Array,Uint8ClampedArray,structuredClone,Image:globalThis.Image,document:globalThis.document,fetch(){networkRequests++;throw Error('Current feedback must remain offline');}}),modules=new Map();
for(const [id,source]of checked.modules)modules.set(id,new SourceTextModule(source,{context,identifier:id}));
const art=modules.get('workshop/editor-art.mjs');await art.link(id=>{assert(modules.has(id),'Missing embedded module '+id);return modules.get(id);});await art.evaluate();
const freeze=value=>{if(value&&typeof value==='object'){for(const child of Object.values(value))freeze(child);Object.freeze(value);}return value;};
const pixels=c=>c.getContext('2d').getImageData(0,0,384,216).data;
const room=freeze({roomId:'main',setting:'Underwater',underwater:true,map:{width:384,height:216,geometry:[],objects:[]},markers:[],decorations:[],aquatic:{version:1,currents:[{id:'neutral-current',x:48,y:80,w:192,h:96,centerX:144,pull:.018,down:.025}]}}),doc=freeze({rooms:[room]}),camera={x:0,y:0,w:384,h:216},before=JSON.stringify(doc);
for(const tick of [0,1,3,6,12,23,47,71,97,144,23,0]){
 const current=freeze({...room,tick}),local=createCanvas(384,216),embedded=createCanvas(384,216);background(local.getContext('2d'),current,384,216);drawScenery(local.getContext('2d'),current);art.namespace.background(embedded.getContext('2d'),current,384,216);art.namespace.drawScenery(embedded.getContext('2d'),current);assert.deepEqual(pixels(embedded),pixels(local));
 const view=freeze({roomId:'main',tick,p:{x:0,y:0,w:10,h:14},geometry:[],objects:[],enemies:[],items:[],vines:[],coins:0,score:0,timeLeft:300,lives:3}),stateBefore=JSON.stringify(view),native=nativeWorld(view,doc,{camera,showPlayer:false,scale:1}).canvas;
 const region=c=>c.getContext('2d').getImageData(0,80,384,136).data;
 assert(Buffer.from(region(native)).equals(Buffer.from(region(embedded))),'embedded shared current pixels match the actual native bridge');
 assert.equal(JSON.stringify(view),stateBefore);assert.equal(JSON.stringify(doc),before);rasterScenes++;
}
assert.equal(networkRequests,0);console.log(JSON.stringify({embeddedSharedDispatchExecuted:true,nativeVideoBridgeExecuted:true,sameTickFrozen:true,authoredStateUnchanged:true,rasterScenes,moduleCount:checked.moduleCount,networkRequests,visualProvenance:'original-procedural-pixel-marks'}));
