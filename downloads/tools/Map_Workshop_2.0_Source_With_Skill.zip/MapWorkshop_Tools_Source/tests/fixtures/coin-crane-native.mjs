import assert from 'node:assert/strict';
import {blank} from '../../atlas/editor-model.mjs';
import {nativeSession} from './shell-coin-native.mjs';
/** Neutral native fixture: an 8px carriage slot admits this 8px coin and
 * rejects the 10px player. Layout/timing are workshop authored, not Nintendo. */
export function coinCraneProject({initialX=246,speed=.75,doors=false}={}){
 const d=blank('Original coin-crane fixture',512,240),r=d.rooms[0];r.setting='Ghost House Night';d.id='neutral-original-coin-crane-v1';
 r.map.geometry=[{id:'floor',x:0,y:208,w:512,h:32,material:'stone',collision:'solid'},{id:'push',x:64,y:144,w:16,h:16,material:'stone',collision:'solid'},{id:'glass-left',x:176,y:96,w:16,h:112,material:'stone',collision:'solid'},{id:'glass-right',x:336,y:96,w:16,h:112,material:'stone',collision:'solid'},{id:'roof-left',x:192,y:96,w:64,h:16,material:'stone',collision:'solid'},{id:'roof-right',x:264,y:96,w:72,h:16,material:'stone',collision:'solid'}];
 r.map.objects=[{id:'start',kind:'spawn',x:67,y:194,w:10,h:14},{id:'physical-pink',kind:'coin',x:256,y:153,w:8,h:14}];
 r.smm2Mechanics={version:1,startingLives:5,pinkCoins:[{id:'physical-pink'}],lighting:{darkness:.86,playerRadius:56,softness:.25,sources:[{targetId:'machine',radius:72},{targetId:'physical-pink',radius:28},{targetId:'push',radius:36}]}};
 r.contraptions={version:1,coinCranes:[{id:'machine',coinId:'physical-pink',buttonId:'push',minX:192,maxX:320,restY:64,grabY:160,deliveryX:128,deliveryY:168,initialX,speed,captureHalfWidth:6,closeFrames:12,openFrames:12}],doors:[]};
 if(doors){const other=blank('Crane return fixture',512,240).rooms[0];other.roomId='other';other.map.id='other-map';other.map.geometry=[{id:'other-floor',x:0,y:208,w:512,h:32,material:'stone',collision:'solid'}];other.map.objects=[{id:'other-start',kind:'spawn',x:35,y:194,w:10,h:14},{id:'other-back',kind:'portal',x:32,y:176,w:16,h:32,targetRoom:'main',targetSpawn:'start'}];other.contraptions={version:1,doors:[{id:'other-back',pairId:'return-pair',style:'plain'}]};d.rooms.push(other);r.map.objects.push({id:'out',kind:'portal',x:32,y:176,w:16,h:32,targetRoom:'other',targetSpawn:'other-start'});r.contraptions.doors.push({id:'out',pairId:'return-pair',style:'plain'});}
 return d;
}
export const craneView=s=>s.view().contraptions.coinCranes[0];
export function ordinaryCranePress(s){s.frames(3);s.until(v=>v.contraptions.coinCranes[0].phase==='lower',{jump:true},40);s.step({});return craneView(s);}
export function ordinaryCranePickup(s){s.until(v=>v.contraptions.coinCranes[0].released,{},500);assert.equal(s.view().coins,0,'release is not an inventory grant');s.until(v=>v.smm2Mechanics.pinkCoins.taken===1,v=>({x:v.p.x<128?1:0}),160);return s.view();}
export function successfulCraneSession(options={}){const s=nativeSession(coinCraneProject(options));ordinaryCranePress(s);ordinaryCranePickup(s);return s;}
