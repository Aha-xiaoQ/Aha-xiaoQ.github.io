import {blank} from '../../atlas/editor-model.mjs';
/** Neutral two-room fixture. No private course IDs, factory or route input. */
export function completionMarksProject({marks=true,hazard=false}={}){
 const doc=blank('Neutral door progress',320,240),entry=doc.rooms[0],reward=blank('Neutral Pink room',320,240).rooms[0];
 entry.roomId='entry-lobby';reward.roomId='reward-sandbox';
 for(const room of [entry,reward]){
  room.map.geometry=[{id:'floor',x:0,y:208,w:320,h:32,collision:'solid',material:'ground'}];
  room.map.objects=[{id:'start',kind:'spawn',x:35,y:194,w:10,h:14}];
  room.playRules={version:1,timeLimit:600,timerFrames:24,viewportWidth:256,viewportHeight:240,cameraAnchor:100};
  room.smm2Mechanics={version:1};
 }
 entry.map.objects.push({id:'entry-portal',kind:'portal',x:32,y:176,w:16,h:32,targetRoom:reward.roomId,targetSpawn:'start'});
 reward.map.objects.push({id:'return-portal',kind:'portal',x:32,y:176,w:16,h:32,targetRoom:entry.roomId,targetSpawn:'start'},{id:'reward-pink',kind:'coin',x:80,y:194,w:8,h:14},{id:'ordinary-coin',kind:'coin',x:112,y:194,w:8,h:14});
 entry.contraptions={version:1,doors:[{id:'entry-portal',pairId:'sandbox-link',style:'plain'}]};
 reward.contraptions={version:1,doors:[{id:'return-portal',pairId:'sandbox-link',style:'plain'}]};
 reward.smm2Mechanics.pinkCoins=[{id:'reward-pink'}];
 if(marks)entry.smm2Mechanics.completionMarks=[{id:'sandbox-mark',portalId:'entry-portal',rewardRoomId:reward.roomId,coinId:'reward-pink'}];
 if(hazard)entry.map.objects.push({id:'native-hazard',kind:'hazard',x:160,y:194,w:16,h:14});
 doc.rooms=[entry,reward];return doc;
}
