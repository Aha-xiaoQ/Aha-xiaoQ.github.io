import fs from 'node:fs';
import assert from 'node:assert/strict';
import {blank,parseProject} from '../../atlas/editor-model.mjs';
import {projectPack} from '../../atlas/editor-runtime.mjs';
import {createStageCatalog} from '../../atlas/runtime/stage-catalog.mjs';
import {createPlatformMotor} from '../../atlas/editor-mario-motor.mjs';
import {createPlatformStage} from '../../atlas/editor-mario-stage.mjs';
import {FLOWER_SOURCE_AUTHORING_DEFAULTS} from '../../atlas/editor-mario-modules-editor.mjs';

export const character=JSON.parse(fs.readFileSync(new URL('../../atlas/runtime/character.json',import.meta.url)));
export function flowerProject(){
 const doc=blank('Neutral flower supply recovery',256,288),room=doc.rooms[0];
 room.map.geometry=[
  {id:'floor',x:0,y:224,w:256,h:64,collision:'solid',material:'ground'},
  {id:'pipe',x:64,y:64,w:32,h:32,collision:'solid',material:'pipe'}
 ];
 room.map.objects=[
  {id:'start',kind:'spawn',x:80,y:210,w:10,h:14},
  {id:'retry',kind:'spawn',x:80,y:210,w:10,h:14},
  {id:'checkpoint',kind:'checkpoint',x:80,y:194,w:12,h:30,targetSpawn:'retry'},
  {id:'hazard',kind:'hazard',x:128,y:208,w:16,h:16},
  {id:'finish',kind:'exit',x:240,y:200,w:16,h:24}
 ];
 room.marioModules={version:1,itemSources:[{id:'flowers',pipeId:'pipe',item:'flower',...FLOWER_SOURCE_AUTHORING_DEFAULTS,direction:'down'}],noteBlocks:[],oneWayWalls:[],enemyVariants:{}};
 return doc;
}
export function flowerSession(doc=flowerProject(),{Stage=createPlatformStage,Motor=createPlatformMotor}={}){
 const d=parseProject(JSON.stringify(doc)),room=d.rooms[0],pack=projectPack(d,room.roomId,character,'flower-supply-test');
 const plan=createStageCatalog(pack).plan(pack.stages[0].id,pack.characters[0].id,{allowDraft:true}),events=[],trace=[];
 const stage=Stage({plan,motor:Motor(),visualRooms:d.rooms,manualDeath:false,autoContinue:false,allowWarp:false,emit:(type,data)=>events.push({type,...data})});
 const s={doc:d,pack,plan,events,trace,view:()=>stage.view(),step(input={}){assert(Object.keys(input).every(k=>['x','jump','run','down','up','attack','interact'].includes(k)));stage.step(input);const v=stage.view();trace.push({input:{...input},tick:v.tick,p:v.p,items:v.items,lives:v.lives,emitted:v.marioModules.itemSources[0].emitted});return v;},until(predicate,input={},limit=600){for(let n=0;n<limit;n++){const v=s.step(typeof input==='function'?input(s.view()):input);if(predicate(v))return v;}throw Error('Flower supply input timed out: '+JSON.stringify(s.view().p));}};
 return s;
}
export function exerciseFlowerRecovery(s){
 const large=s.until(v=>v.p.power===1);
 assert.equal(large.p.growth,24);assert.equal(large.p.h,28);assert.equal(large.p.y+large.p.h,224);assert.equal(large.marioModules.itemSources[0].emitted,1);
 const fire=s.until(v=>v.p.power===2);
 assert.equal(fire.p.fireGrowth,24);assert.equal(fire.marioModules.itemSources[0].emitted,2);
 s.until(v=>v.p.fireGrowth===0);s.step({attack:true});
 assert(s.view().items.some(q=>q.kind==='fireball'));assert(s.events.some(e=>e.type==='sound'&&e.event==='fire'));
 const hurt=s.until(v=>v.p.power===0,{x:1},120);
 assert.equal(hurt.p.h,14);assert.equal(hurt.p.invulnerable,120);assert.equal(hurt.lives,3);assert.equal(hurt.p.dying,undefined);
 assert(hurt.p.x+hurt.p.w>128&&hurt.p.x<144,'real hazard contact caused the loss of firepower');
 const fireSounds=s.events.filter(e=>e.type==='sound'&&e.event==='fire').length;
 s.step({x:-1,attack:true});assert.equal(s.events.filter(e=>e.type==='sound'&&e.event==='fire').length,fireSounds,'small Mario cannot fire');
 // Release Left before the pipe to let native inertia stop Mario under its mouth.
 s.until(v=>v.p.x<=102,{x:-1},120);
 const restoredLarge=s.until(v=>v.p.power===1);
 assert.equal(restoredLarge.marioModules.itemSources[0].emitted,3);
 const restoredFire=s.until(v=>v.p.power===2);
 assert.equal(restoredFire.marioModules.itemSources[0].emitted,4);assert.equal(restoredFire.lives,3);
 assert.equal(s.events.filter(e=>e.type==='sound'&&e.event==='powerup').length,4);
 assert(s.trace.every(v=>v.items.filter(q=>q.kind==='flower').length<=1),'one live flower per source');
 return {firstGrowthTick:large.tick,firstFireTick:fire.tick,hurtTick:hurt.tick,recoveredFireTick:restoredFire.tick};
}
export function exerciseFlowerDeathReset(s){
 s.until(v=>v.p.fireGrowth===0);s.until(v=>v.p.power===0,{x:1},120);
 const dead=s.until(v=>v.p.dying);
 assert.equal(dead.lives,2);assert(dead.marioModules.itemSources[0].emitted>=4);
 const retry=s.until(v=>!v.p.dying,{},120);
 assert.deepEqual({...retry.checkpoint},{roomId:'main',spawnId:'retry'});
 assert.equal(retry.p.x,80);assert.equal(retry.p.power,0);assert.equal(retry.lives,2);
 assert.equal(retry.marioModules.itemSources[0].emitted,0);assert.equal(retry.items.filter(q=>q.kind==='flower').length,0);
 const large=s.until(v=>v.p.power===1);assert.equal(large.marioModules.itemSources[0].emitted,1);
 const fire=s.until(v=>v.p.power===2);assert.equal(fire.marioModules.itemSources[0].emitted,2);assert.equal(fire.lives,2);
 return {deathTick:dead.tick,retryTick:retry.tick,retryFireTick:fire.tick};
}
