import assert from 'node:assert/strict';
import {blank} from '../../atlas/editor-model.mjs';
import {nativeSession} from './shell-coin-native.mjs';

// Neutral stacked-strip fixture; no source course coordinates or input route.
export function initialPlantProject(){
 const d=blank('Neutral initial floor-plant support',320,384),r=d.rooms[0];r.map.geometry=[{id:'floor',x:0,y:256,w:320,h:128,collision:'solid',material:'ground'}];r.map.objects=[{id:'start',kind:'spawn',x:16,y:242,w:10,h:14},{id:'plant',kind:'walker',x:112,y:100,w:16,h:24}];r.markers=[];r.playRules={version:1,timeLimit:600,timerFrames:24,viewportWidth:256,viewportHeight:240,cameraAnchor:100};r.smm2Mechanics={version:1,slopes:[{id:'upper-strip',x:64,y:96,w:128,h:64,thickness:16,orientation:'rise-left',collision:'solid'},{id:'lower-strip',x:96,y:160,w:96,h:48,thickness:16,orientation:'rise-left',collision:'solid'}]};r.marioModules={version:1,itemSources:[],noteBlocks:[],oneWayWalls:[],enemyVariants:{plant:{kind:'floor-piranha',size:'normal',winged:false}}};return d;
}
export function checkInitialPlant(project,options={}){
 const original=JSON.stringify(project),s=nativeSession(project,options),first=s.step(),plant=first.enemies.find(q=>q.id==='plant');assert.equal(plant.type,'study-piranha');assert.equal(plant.support,'upper-strip');assert.equal(plant.grounded,true);assert.equal(plant.y,96);assert.equal(plant.vy,0);assert.equal(plant.x,112);assert.equal(plant.h,24);assert.equal(plant.w,16);
 for(let n=0;n<120;n++){const v=s.step(),p=v.enemies.find(q=>q.id==='plant');assert(p&&!p.dead);assert.equal(p.support,'upper-strip');assert.equal(p.y,96);assert.equal(p.vy,0);assert.equal(v.lives,3);}
 const initialEvents=s.events.filter(q=>q.type==='smm2-terrain'&&q.event==='slope-initial-support');assert.equal(initialEvents.length,1);assert.equal(initialEvents[0].actorId,'plant');assert.equal(initialEvents[0].displacementY,-4);assert.equal(JSON.stringify(project),original,'authored sprite rectangle and actual geometry remain unchanged');
 return {initialSupportSettlements:1,verticalDepenetration:-4,naturalInputs:s.inputs.length,upperStripSupport:true,sourceCourseIncluded:false};
}
