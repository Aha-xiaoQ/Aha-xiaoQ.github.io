import assert from 'node:assert/strict';
import {test} from 'node:test';
import {createRequire} from 'node:module';
import {blank,History,parseProject,validate} from '../atlas/editor-model.mjs';
import {createCastleController,validateCastleRoom,CASTLE_BOSS_BATTLE_PHASE_DEFAULTS} from '../atlas/editor-castle.mjs';
import {mountCastleTools,setCastleBoss} from '../atlas/editor-castle-tools.mjs';
import {createPlatformStage} from '../atlas/editor-mario-stage.mjs';
import {createPlatformMotor} from '../atlas/editor-mario-motor.mjs';
import {drawCastleBattleHud} from '../atlas/editor-art.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';
const copy=structuredClone,character={capabilities:['jump'],motion:{width:10,height:14,maxHealth:1}};
function fixture(){
 const d=blank('Original native battle component',512,240),r=d.rooms[0];r.setting='Castle';
 r.map.objects=[{id:'start',kind:'spawn',x:40,y:210,w:10,h:14},{id:'checkpoint',kind:'checkpoint',x:72,y:210,w:10,h:14,targetSpawn:'retry'},{id:'boss',kind:'walker',x:304,y:192,w:32,h:32},{id:'retry',kind:'spawn',x:72,y:210,w:10,h:14}];
 r.map.geometry=[{id:'floor',x:0,y:224,w:448,h:16,collision:'solid',material:'stone'},{id:'bridge',x:448,y:224,w:64,h:16,collision:'solid',material:'bridge'}];
 r.markers=[{id:'axe',kind:'bridge-axe-finish',x:448,y:208},{id:'door',kind:'smm2-castle-door',x:480,y:176}];r.enemySkins={boss:'bowser'};
 r.smm2Mechanics={version:1,art:{palette:'smb1-castle-stone'},startingLives:3};
 r.castle={version:1,lavaMode:'pit',boss:{actorId:'boss',hp:6,patrol:{minX:224,maxX:352},fire:{w:24,h:8,mouthY:24},battle:{version:1}},finish:{variant:'smm2-door',axeId:'axe',bridgeId:'bridge',doorId:'door',endingPauseFrames:12,requireBossDefeated:true}};
 r.playRules={version:1,timeLimit:400,timerFrames:60,viewportWidth:512,viewportHeight:240,cameraAnchor:160};return d;
}
function session(r,extra={}){const events=[],stage=createPlatformStage({plan:{stage:{entryRoom:'main',entrySpawn:'start',title:'Native battle component'},character,rooms:{main:r.map}},motor:createPlatformMotor(),visualRooms:[r],initialState:{lives:3,power:2},emit:(type,data)=>events.push({type,...data}),...extra});return {stage,events};}
const frames=(s,n,input={})=>{for(let i=0;i<n;i++)s.step(input);return s.view();};
const fireball=e=>({kind:'fireball',x:e.x+4,y:e.y+4,w:5,h:5,dead:false});
function playerInput(v,{shoot=true}={}){
 const wave=v.enemies.find(e=>e.type==='bowserfire'&&e.vx<0&&e.x+e.w>v.p.x&&e.x-v.p.x<20);
 return {x:0,jump:!!wave||(!v.p.grounded&&v.p.vy<0),attack:shoot&&v.p.grounded&&v.castle.battle.exposed&&v.tick%16===0};
}
function runBattle(s,until=()=>false,max=3600){let v=s.view();for(let i=0;i<max&&!until(v);i++){s.step(playerInput(v));v=s.view();}return v;}

test('battle schema is strict, phase fields bounded, and original real Bowser never permits a Goomba reveal',()=>{
 const d=fixture();assert.doesNotThrow(()=>validate(d));assert.deepEqual(parseProject(JSON.stringify(d)),d);
 for(const change of [r=>r.castle.boss.battle.version=2,r=>delete r.castle.boss.battle.version,r=>r.castle.boss.battle.extra=true,r=>r.castle.boss.battle.transitionHp=6,r=>r.castle.boss.battle.hitCooldownFrames=0,r=>r.castle.boss.identity='goomba',r=>r.castle.boss.battle.phases=[{}],r=>r.castle.boss.battle.phases=[{jumpVelocity:1},{}],r=>r.castle.boss.battle.phases=[{recoveryFrames:Infinity},{}],r=>r.castle.boss.battle.phases=[{fireCount:9},{}],r=>r.castle.boss.battle.phases=[{fireTellFrames:0},{}],r=>r.castle.finish.requireBossDefeated=1,r=>delete r.castle.boss]){
  const bad=copy(d.rooms[0]);change(bad);const before=copy(bad);assert.throws(()=>validateCastleRoom(bad));assert.deepEqual(bad,before);
 }
 const r=copy(d.rooms[0]),before=copy(r);assert.throws(()=>setCastleBoss(r,'boss',{hp:6,battle:{version:1,phases:[{},{}],transitionFrames:-1}}));assert.deepEqual(r,before);
 const c=createCastleController(r),e=c.decorateBoss({...r.map.objects[2],type:'bowser',grounded:true});assert.equal(e.hp,6);assert.equal(e.castleIdentity,'bowser');assert.deepEqual(c.bossRule(e).battle.phases,CASTLE_BOSS_BATTLE_PHASE_DEFAULTS);
});

test('native phase one has full tells, low actual wave, genuine jump/landing, and a 120-frame opening',()=>{
 const {stage:s}=session(fixture().rooms[0]);let v=s.view(),states=[],waves=[],airborne=false,landed=false,open=0,prior='';
 for(let i=0;i<390;i++){
  s.step(playerInput(v,{shoot:false}));v=s.view();const b=v.enemies.find(e=>e.id==='boss');assert(b);assert(b.x>=224&&b.x<=352);assert.equal(b.hp,6);
  const state=v.castle.battle.state;if(state!==prior){states.push({state,tick:v.tick});prior=state;}
  for(const e of v.enemies.filter(e=>e.castleBossFlame==='boss'))if(!waves.some(q=>q.id===e.id))waves.push(copy(e));
  if(state==='airborne'&&!b.grounded){airborne=true;assert(b.y<192);assert.equal(v.castle.battle.exposed,false);}
  if(state==='recovery'){assert(airborne);assert.equal(b.grounded,true);assert.equal(b.y,192);landed=true;assert.equal(v.castle.battle.exposed,true);open++;}
  if(landed&&state==='patrol')break;
 }
 assert.deepEqual(states.slice(0,4),[{state:'patrol',tick:1},{state:'fire-tell',tick:61},{state:'fire',tick:97},{state:'fire-wait',tick:98}]);
 assert.equal(states.find(q=>q.state==='jump-tell').tick,122);assert.equal(states.find(q=>q.state==='airborne').tick,146);assert.equal(waves.length,1);assert.equal(waves[0].w,24);assert.equal(waves[0].h,8);assert.equal(waves[0].y,216);assert.equal(waves[0].vx,-1.25);assert.equal(open,120);
});

test('tells lock real target direction, mouth side and velocity; paused/repeated ticks cannot double spawn',()=>{
 const r=fixture().rooms[0],c=createCastleController(r),e=c.decorateBoss({...r.map.objects[2],type:'bowser',grounded:true}),right={x:400,y:210,w:10,h:14},left={...right,x:40};
 for(let tick=1;tick<=61;tick++)c.bossIntent(e,{tick,viewportWidth:512,player:right});const before=copy(c.view());for(let tick=62;tick<100;tick++)c.bossIntent(e,{tick,viewportWidth:512,player:left,paused:true});assert.deepEqual(c.view(),before);
 let out;for(let tick=62;tick<=97;tick++)out=c.bossIntent(e,{tick,viewportWidth:512,player:left});assert(out.flame);assert.equal(out.facing,1);assert.equal(out.flame.x,e.x+e.w);assert.equal(out.flame.vx,1.25);assert.equal(out.flame.y,e.y+24);assert.equal(c.bossIntent(e,{tick:97,viewportWidth:512,player:left}).flame,null);
 assert.equal(c.hitBoss(e,fireball(e)).hit,false);assert.equal(e.hp,6);
});

test('six native player-shot opening hits alone defeat real Bowser, with one 90-frame phase change and paired faster waves',()=>{
 const r=fixture().rooms[0];r.map.objects[0].x=144;const {stage:s,events}=session(r);let v=s.view(),waves=[],transitionTicks=0,openings=0,prior='',lastHp=6,hitOpenings=new Set();
 for(let i=0;i<3600&&v.castle.battle.hp;i++){
  s.step(playerInput(v));v=s.view();const state=v.castle.battle.state;if(state==='recovery'&&prior!=='recovery')openings++;
  if(v.castle.battle.hp<lastHp){assert(!hitOpenings.has(openings),'one hit per actual landed opening');hitOpenings.add(openings);lastHp=v.castle.battle.hp;}
  if(state==='transition')transitionTicks++;
  for(const e of v.enemies.filter(e=>e.castleBossFlame==='boss'))if(!waves.some(q=>q.id===e.id))waves.push({...e,tick:v.tick,phase:v.castle.battle.phase});prior=state;
 }
 assert.equal(v.castle.battle.hp,0,JSON.stringify({battle:v.castle.battle,p:v.p,events}));assert.equal(v.lives,3);assert.equal(v.p.power,2);assert.equal(hitOpenings.size,6);assert.equal(transitionTicks,90);assert.equal(events.filter(q=>q.event==='boss-phase-change').length,1);assert.equal(events.filter(q=>q.event==='boss-fire-hit').length,5);assert.equal(events.filter(q=>q.event==='boss-fire-defeat').length,1);assert.equal(v.score,5000);
 const defeat=events.find(q=>q.event==='boss-fire-defeat');assert.equal(defeat.identity,'bowser');assert(v.items.some(e=>e.kind==='enemy-death'&&e.id==='boss'&&e.type==='bowser'));assert.equal(v.finish,null,'combat win still requires authored axe');
 const phase2=waves.filter(q=>q.phase===2);assert(phase2.length>=6);assert(phase2.every(q=>Math.abs(q.vx)===1.65));for(let i=0;i<phase2.length;i+=2)assert.equal(phase2[i+1].tick-phase2[i].tick,24);
 for(let i=0;i<400&&!v.finish;i++){s.step({x:1});v=s.view();}assert.equal(v.finish?.phase,'door-open');assert.equal(v.finish.branch,'dead');v=frames(s,12);assert.equal(v.completed,true);assert.equal(events.filter(q=>q.type==='complete').length,1);assert.equal(v.score,5000);assert(v.geometry.some(q=>q.id==='bridge'));

});


test('native second phase patrol accelerates, both waves stay 24 frames apart, and grounded recovery lasts 96 frames',()=>{
 const r=fixture().rooms[0];r.map.objects[0].x=144;const {stage:s}=session(r);let v=runBattle(s,v=>v.castle.battle.hp===3);assert.equal(v.castle.battle.phase,2);
 let recovery=0,entered=false,waves=[],patrol=false,jumped=false,priorBoss=v.enemies.find(e=>e.id==='boss');
 for(let i=0;i<500;i++){
  s.step(playerInput(v,{shoot:false}));v=s.view();const b=v.enemies.find(e=>e.id==='boss'),state=v.castle.battle.state;assert(b);assert.equal(b.hp,3);
  if(state==='patrol'&&!entered){patrol=true;if(b.x>224&&b.x<352)assert(Math.abs(Math.abs(b.x-priorBoss.x)-.7)<1e-6);}
  for(const e of v.enemies.filter(e=>e.castleBossFlame==='boss'&&Math.abs(e.vx)===1.65))if(!waves.some(q=>q.id===e.id))waves.push({...e,tick:v.tick});
  if(state==='airborne'&&!jumped){jumped=true;assert.equal(b.vy,-4.7);}
  if(state==='recovery'){entered=true;recovery++;assert.equal(b.grounded,true);assert.equal(v.castle.battle.exposed,true);}
  if(entered&&state==='patrol')break;priorBoss=b;
 }
 assert(patrol);assert(jumped);assert.equal(recovery,96);assert.equal(waves.length,2);assert.equal(waves[1].tick-waves[0].tick,24);assert.equal(v.p.power,2);
});

test('native player fireballs during armor are consumed without triggering the old five-hit path',()=>{
 const r=fixture().rooms[0];r.map.objects[0].x=192;const {stage:s,events}=session(r);let v=s.view();for(let i=0;i<125;i++){s.step({attack:i%12===0});v=s.view();assert.equal(v.castle.battle.hp,6);}
 assert(events.filter(q=>q.event==='fire').length>=5);assert.equal(events.filter(q=>q.event==='boss-fire-hit').length,0);assert.equal(v.enemies.find(e=>e.id==='boss').hp,6);assert(v.items.filter(q=>q.kind==='fireball').length<2);
});

test('wrong-window shots are consumed, accepted hit starts 120-frame protection, and the same shot cannot repeat',()=>{
 const r=fixture().rooms[0],c=createCastleController(r),e=c.decorateBoss({...r.map.objects[2],type:'bowser',grounded:true});const early=fireball(e);assert.equal(c.hitBoss(e,early).hit,false);assert.equal(early.dead,true);assert.equal(e.hp,6);
 for(let tick=1;tick<=146;tick++)c.bossIntent(e,{tick,viewportWidth:512});assert.equal(c.view().battle.state,'airborne');assert.equal(c.view().battle.exposed,false);c.bossIntent(e,{tick:147,viewportWidth:512});assert.equal(c.view().battle.state,'airborne','launch without observed native airborne motion cannot manufacture an opening');
 // This leaf fixture models the native motor observations; the native-stage test above proves real landing.
 e.grounded=false;c.bossIntent(e,{tick:148,viewportWidth:512});e.grounded=true;c.bossIntent(e,{tick:149,viewportWidth:512});const shot=fireball(e);assert.equal(c.hitBoss(e,shot).hit,true);assert.equal(e.hp,5);assert.equal(c.view().battle.hitCooldown,120);assert.equal(c.view().battle.exposed,false);assert.equal(c.hitBoss(e,fireball(e)).hit,false);shot.dead=false;assert.equal(c.hitBoss(e,shot).hit,false);assert.equal(e.hp,5);
 c.reset();const fresh=c.decorateBoss({...r.map.objects[2],type:'bowser',grounded:false});assert.equal(fresh.hp,6);assert.equal(c.view().battle.state,'patrol');assert.equal(c.view().battle.hitCooldown,0);assert.equal(c.view().battle.phase,1);
});

test('living Boss cannot be bypassed by native axe contact, and melee cannot chip battle HP',()=>{
 const r=fixture().rooms[0];r.map.objects[0].x=448;const {stage:s}=session(r);frames(s,25);assert.equal(s.view().finish,null);assert.equal(s.view().castle.battle.hp,6);assert.deepEqual(s.view().hiddenMarkers,[]);
 const melee=fixture().rooms[0];melee.map.objects[0].x=282;const {stage:m}=session(melee,{plan:{stage:{entryRoom:'main',entrySpawn:'start',title:'Melee rejection'},character:{...character,capabilities:['jump','attack']},rooms:{main:melee.map}},initialState:{lives:3,power:0}});m.step({attack:true});assert.equal(m.view().castle.battle.hp,6);assert.equal(m.view().enemies.find(e=>e.id==='boss').hp,6);
});

test('real contact hurts once, protection prevents repeat hurt, death retries the reached checkpoint with full fresh Boss',()=>{
 for(const autoContinue of [false,true]){
  const {stage:s,events}=session(fixture().rooms[0],{autoContinue});let v=s.view();for(let i=0;i<200&&!events.some(q=>q.event==='hurt');i++){s.step({x:1});v=s.view();}
  assert.equal(v.checkpoint.spawnId,'retry');assert.equal(events.filter(q=>q.event==='hurt').length,1);assert.equal(v.p.power,0);assert.equal(v.lives,3);assert(v.invulnerable>0);
  const firstTick=v.tick;for(let i=0;i<15;i++){s.step({x:0});v=s.view();}assert.equal(events.filter(q=>q.event==='hurt').length,1);assert(v.tick>firstTick);
  for(let i=0;i<350&&!v.p.dying;i++){const b=v.enemies.find(e=>e.id==='boss');s.step({x:b?Math.sign(b.x+b.w/2-v.p.x-v.p.w/2):1});v=s.view();}assert.equal(v.p.dying,true);assert.equal(v.lives,2);frames(s,105);v=s.view();assert.equal(!!v.p.dying,false);assert.equal(v.checkpoint.spawnId,'retry');assert(v.p.x>=72&&v.p.x<80);assert.equal(v.castle.battle.hp,6);assert.equal(v.castle.battle.phase,1);assert.equal(v.castle.battle.state,'patrol');assert.equal(v.finish,null);assert(v.invulnerable>0);
 }
});

test('author panel enables/edits original battle and finish gate atomically through History and import',()=>{
 const ui=installSimulatedPlayDom();try{const d=fixture();delete d.rooms[0].castle.boss.battle;delete d.rooms[0].castle.finish.requireBossDefeated;const h=new History(d),room=()=>h.doc.rooms[0],parent=ui.document.createElement('aside'),reports=[],tools=mountCastleTools({parent,room,change:fn=>h.change(fn),report:q=>reports.push(q)}),get=id=>parent.querySelector('[data-castle-control="'+id+'"]');
  get('battle-enabled').value='on';get('battle-phase1-fireCount').value='2';get('boss-apply').click();assert.equal(room().castle.boss.battle.version,1);assert.equal(room().castle.boss.identity,'bowser');assert.equal(room().castle.boss.battle.phases[1].fireCount,2);h.undo();tools.refresh();assert.equal(room().castle.boss.battle,undefined);h.redo();tools.refresh();assert.equal(get('battle-enabled').value,'on');
  const before=copy(h.doc);get('battle-phase0-jumpVelocity').value='4.8';get('boss-apply').click();assert.deepEqual(h.doc,before);assert.equal(reports.length,1);assert.equal(get('battle-phase0-jumpVelocity').value,-4.8);
  get('finish-requireBossDefeated').value='on';get('finish-gate-apply').click();assert.equal(room().castle.finish.requireBossDefeated,true);assert.equal(room().castle.finish.variant,'smm2-door');h.undo();tools.refresh();assert.equal(room().castle.finish.requireBossDefeated,undefined);h.redo();tools.refresh();assert.equal(get('finish-requireBossDefeated').value,'on');assert.deepEqual(parseProject(JSON.stringify(h.doc)),h.doc);
  get('battle-enabled').value='off';get('boss-apply').click();assert.equal(room().castle.boss.battle,undefined);assert.equal(room().castle.boss.identity,'goomba');
 }finally{ui.restore();}
});

const require=createRequire(import.meta.url),{createCanvas}=require('@napi-rs/canvas');
test('actual shared Canvas HUD displays real depleted health and readable warning/open cue pixels',()=>{
 const c=createCanvas(512,240).getContext('2d'),v={viewportWidth:512,castle:{battle:{hp:6,maxHp:6,cue:'FIRE',exposed:false}}};assert.equal(drawCastleBattleHud(c,v),true);const warning=c.getImageData(160,36,190,42).data;c.clearRect(0,0,512,240);v.castle.battle={hp:3,maxHp:6,cue:'OPEN',exposed:true};drawCastleBattleHud(c,v);const open=c.getImageData(160,36,190,42).data;assert.notDeepEqual(open,warning);assert.deepEqual([...c.getImageData(168,52,1,1).data],[131,232,107,255]);assert.deepEqual([...c.getImageData(300,52,1,1).data],[90,37,37,255]);assert.equal(drawCastleBattleHud(c,{castle:{}}),false);
});
