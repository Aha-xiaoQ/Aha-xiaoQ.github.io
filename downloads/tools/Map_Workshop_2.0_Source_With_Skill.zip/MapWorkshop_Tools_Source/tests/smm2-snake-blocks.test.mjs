import test from 'node:test';
import assert from 'node:assert/strict';
import {createSmm2SnakeBlocks, validateSmm2SnakeBlocksRoom, stepSmm2SnakeBlockPlayer} from '../atlas/editor-snake-blocks.mjs';
import {createPlatformMotor} from '../atlas/editor-mario-motor.mjs';
import {withAquaticPhysics} from '../atlas/editor-aquatic-motor.mjs';

const character = {capabilities: ['jump'], motion: {width: 10, height: 14, maxHealth: 1}};
const near = (actual, expected) => assert(Math.abs(actual - expected) < 1e-7, `${actual} != ${expected}`);
function train(overrides = {}) {
  return {id: 'snake', color: 'green', origin: {x: 32, y: 128}, path: [{id: 'start', x: 0, y: 0}, {id: 'finish', x: 256, y: 0}], lengthCells: 6, speedPxPerTick: 2, initialHeadDistancePx: 80, activation: 'player-top', endpointHoldFrames: 3, collapseIntervalFrames: 9, collapseGravity: .35, collapseFallCap: 6, collapseOrder: 'tail-to-head', ...overrides};
}
function room(trains = [train()]) {
  return {roomId: 'main', map: {id: 'snake-fixture', width: 640, height: 320, tileSize: 16, geometry: [], objects: []}, smm2Mechanics: {version: 1, snakeBlocks: {version: 1, trains}}};
}
function supported(controller, role = 'fixed') {
  const q = controller.geometry().find(q => q.role === role);
  return {...createPlatformMotor().create(character, {x: q.x + 3, y: q.y - 14}), grounded: true, support: q.id};
}
function session(definition = train(), spawn = {x: 66, y: 64}, {water = false} = {}) {
  const source = room([definition]), controller = createSmm2SnakeBlocks(source), base = createPlatformMotor(), motor = water ? withAquaticPhysics(base) : base;
  const player = motor.create(character, spawn), world = {width: source.map.width, height: source.map.height, solids: [], swimming: water};
  if (water) world.swimPhysics = {top: 0, horizontalCap: 1.5, groundCap: 1.5, acceleration: .04, deceleration: .05, gravity: .075, maxFall: 1.5, strokeFrames: 24, strokeSpeed: 2.5, flowX: 0, flowY: 0};
  let tick = 0;
  return {source, controller, motor, player, world, step(input = {}) {controller.step({tick: ++tick, player}); return stepSmm2SnakeBlockPlayer({controller, motor, player, input, character, world, tick});}};
}

test('strict optional room contract has no implicit dynamics and detached roundtrip data', () => {
  const r = room(), c = createSmm2SnakeBlocks(r);
  assert.deepEqual(c.getDocument(), JSON.parse(JSON.stringify(r.smm2Mechanics.snakeBlocks)));
  const detached = c.getDocument(); detached.trains[0].origin.x = 1;
  assert.equal(c.getDocument().trains[0].origin.x, 32);
  for (const field of ['speedPxPerTick', 'initialHeadDistancePx', 'endpointHoldFrames', 'collapseIntervalFrames', 'collapseGravity', 'collapseFallCap', 'collapseOrder']) {
    const q = room(); delete q.smm2Mechanics.snakeBlocks.trains[0][field];
    assert.throws(() => validateSmm2SnakeBlocksRoom(q), /Missing/);
  }
  for (const edit of [
    r => r.smm2Mechanics.snakeBlocks.version = 2,
    r => r.smm2Mechanics.snakeBlocks.script = 'move-player',
    r => r.smm2Mechanics.snakeBlocks.trains[0].playerX = 0,
    r => r.smm2Mechanics.snakeBlocks.trains[0].activation = 'nearby',
    r => r.smm2Mechanics.snakeBlocks.trains[0].color = 'red',
    r => r.smm2Mechanics.snakeBlocks.trains[0].collapseOrder = 'all-together',
    r => r.smm2Mechanics.snakeBlocks.trains[0].origin.x = Infinity,
    r => r.smm2Mechanics.snakeBlocks.trains[0].origin.y = -1,
    r => r.smm2Mechanics.snakeBlocks.trains[0].speedPxPerTick = 0,
    r => r.smm2Mechanics.snakeBlocks.trains[0].collapseGravity = NaN,
    r => r.smm2Mechanics.snakeBlocks.trains[0].collapseFallCap = -1,
    r => r.smm2Mechanics.snakeBlocks.trains[0].collapseIntervalFrames = 0,
    r => r.smm2Mechanics.snakeBlocks.trains[0].endpointHoldFrames = 1.5,
    r => r.smm2Mechanics.snakeBlocks.trains[0].initialHeadDistancePx = 79,
    r => r.smm2Mechanics.snakeBlocks.trains[0].initialHeadDistancePx = 257,
    r => r.smm2Mechanics.snakeBlocks.trains[0].path[0].x = 16,
    r => r.smm2Mechanics.snakeBlocks.trains[0].path[1].x = 257,
    r => r.smm2Mechanics.snakeBlocks.trains[0].path[1].y = 16,
    r => r.smm2Mechanics.snakeBlocks.trains[0].path[1].id = 'start',
    r => r.smm2Mechanics.snakeBlocks.trains.push(structuredClone(r.smm2Mechanics.snakeBlocks.trains[0])),
    r => r.map.objects.push({id: 'snake'}),
    r => r.smm2Mechanics.snakeBlocks.trains[0].path[1].x = 624,
  ]) {const q = room(); edit(q); assert.throws(() => validateSmm2SnakeBlocksRoom(q));}
  const revisit = room([train({path: [{id: 'start', x: 0, y: 0}, {id: 'east', x: 128, y: 0}, {id: 'west', x: 0, y: 0}]})]);
  assert.throws(() => validateSmm2SnakeBlocksRoom(revisit), /crossings and revisits/);
});

test('opt-out and empty train lists add no controller or alter native motor results', () => {
  const plain = room(); delete plain.smm2Mechanics;
  const sibling = room(); delete sibling.smm2Mechanics.snakeBlocks;
  assert.equal(createSmm2SnakeBlocks(plain), null);
  assert.equal(createSmm2SnakeBlocks(sibling), null);
  assert.equal(createSmm2SnakeBlocks(room([])), null);
  const a = createPlatformMotor(), b = createPlatformMotor(), pa = a.create(character, {x: 32, y: 16}), pb = b.create(character, {x: 32, y: 16});
  const world = {width: 320, height: 240, solids: [{id: 'floor', x: 0, y: 192, w: 320, h: 48, collision: 'solid'}]};
  for (let tick = 0; tick < 100; tick++) {const input = {x: tick > 35 ? 1 : 0, jumpPressed: tick === 70, jump: tick > 70 && tick < 82}; assert.deepEqual(a.step(pa, input, character, world), b.step(pb, input, character, world)); assert.deepEqual(pa, pb);}
});

test('controller rejects hidden and sparse fields before returning a detached document', () => {
  for (const edit of [
    r => Object.defineProperty(r.smm2Mechanics.snakeBlocks, 'script', {value: 'move-player'}),
    r => r.smm2Mechanics.snakeBlocks.trains[0][Symbol('script')] = true,
    r => Object.defineProperty(r.smm2Mechanics.snakeBlocks.trains[0].origin, 'center', {value: true}),
    r => r.smm2Mechanics.snakeBlocks.trains[0].path[1][Symbol('script')] = true,
    r => r.smm2Mechanics.snakeBlocks.trains.hiddenInstruction = true,
    r => r.smm2Mechanics.snakeBlocks.trains[0].path.hiddenInstruction = true,
    r => delete r.smm2Mechanics.snakeBlocks.trains[0].path[0],
    r => delete r.smm2Mechanics.snakeBlocks.trains[0],
  ]) {const r = room(); edit(r); assert.throws(() => validateSmm2SnakeBlocksRoom(r), /Unknown|Missing/);}
});

test('aggregate path budgets are checked before expanding controller geometry, retaining normal long routes', () => {
  const path = [{id: 'budget-start', x: 0, y: 0}];
  for (let row = 0; row < 7; row++) {path.push({id: 'budget-row-' + row, x: row % 2 ? 0 : 32752, y: row * 16}); if (row < 6) path.push({id: 'budget-turn-' + row, x: row % 2 ? 0 : 32752, y: (row + 1) * 16});}
  const definitions = count => Array.from({length: count}, (_, i) => train({id: 'budget-' + i, origin: {x: 0, y: 0}, path}));
  const bounded = room(definitions(1)); bounded.map.width = 32768; bounded.map.height = 4096;
  assert.doesNotThrow(() => validateSmm2SnakeBlocksRoom(bounded), 'a 14,336-cell cardinal path remains supported');
  const oversized = room(definitions(19)); oversized.map.width = 32768; oversized.map.height = 4096;
  // A deliberate revisit in the first path would fail expansion. The total
  // budget error must precede it, proving that no earlier path was expanded.
  oversized.smm2Mechanics.snakeBlocks.trains[0].path.push({id: 'budget-return', x: 0, y: 96});
  assert.throws(() => validateSmm2SnakeBlocksRoom(oversized), /total expanded paths/);
});

for (const [name, length, color] of [['green-one', 7, 'green'], ['green-two', 6, 'green'], ['green-three', 6, 'green'], ['blue-four', 5, 'blue']]) {
  test(`${name} keeps its observed ${length}-cell initial train as actual 16px solid bodies`, () => {
    const c = createSmm2SnakeBlocks(room([train({id: name, color, lengthCells: length, initialHeadDistancePx: (length - 1) * 16})]));
    const geometry = c.geometry();
    assert.equal(geometry.length, length);
    assert.equal(new Set(geometry.map(q => `${q.x},${q.y}`)).size, length, 'exact-grid endpoints have no duplicate fixed colliders');
    assert(geometry.every(q => q.w === 16 && q.h === 16 && q.collision === 'solid' && q.color === color));
    assert.equal(geometry[0].x, 32, 'origin means top-left');
  });
}

test('only actual player top contact starts a train; proximity, sides, undersides, ascending and NPC-only frames do not', () => {
  const c = createSmm2SnakeBlocks(room()), first = c.geometry()[0], top = supported(c), original = c.view();
  for (const p of [null, {...top, grounded: false, support: null}, {...top, x: first.x - 10}, {...top, y: first.y + 2}, {...top, y: first.y + first.h}, {...top, vy: -1}, {...top, dead: true}]) {
    c.step({tick: (c.view().tick ?? 0) + 1, player: p, actors: [top]});
    assert.equal(c.view().trains[0].phase, 'idle');
    assert.equal(c.view().trains[0].headDistancePx, original.trains[0].headDistancePx);
  }
  const tick = c.view().tick + 1;
  assert.deepEqual(c.observePlayerContact(top, {tick}), ['snake']);
  assert.deepEqual(c.observePlayerContact(top, {tick}), []);
  assert.equal(c.view().trains[0].phase, 'moving');
});

test('descending top crossing is geometric; side motion and crossing from below are rejected', () => {
  for (const valid of [true, false]) {
    const c = createSmm2SnakeBlocks(room()), q = c.geometry()[1];
    const previous = {x: q.x + 2, y: valid ? q.y - 20 : q.y + 2, w: 10, h: 14};
    const player = {...previous, y: previous.y + 8, vy: 8, grounded: false, support: null};
    assert.deepEqual(c.observePlayerContact(player, {tick: 1, previousPlayer: previous}), valid ? ['snake'] : []);
  }
  const c = createSmm2SnakeBlocks(room()), q = c.geometry()[1], before = {x: q.x - 12, y: q.y + 1, w: 10, h: 14};
  assert.deepEqual(c.observePlayerContact({...before, x: q.x + 1, vy: 0}, {tick: 1, previousPlayer: before}), []);
});

test('fixed world nodes survive the right/up/right corner window without whole-body translation', () => {
  const c = createSmm2SnakeBlocks(room([train({path: [{id: 'start', x: 0, y: 0}, {id: 'bend-up', x: 112, y: 0}, {id: 'bend-right', x: 112, y: -64}, {id: 'finish', x: 192, y: -64}]})]));
  c.step({tick: 0, player: supported(c)});
  const seen = new Map(), directions = new Set();
  let appeared = false, departed = false;
  for (let tick = 1; tick <= 85; tick++) {
    c.step({tick});
    appeared ||= c.view().motions.some(m => m.appeared);
    departed ||= c.view().motions.some(m => m.departed);
    for (const q of c.geometry()) {
      if (q.role === 'head') directions.add(`${q.direction.x},${q.direction.y}`);
      if (q.role !== 'fixed') continue;
      if (seen.has(q.id)) assert.deepEqual({x: q.x, y: q.y}, seen.get(q.id));
      seen.set(q.id, {x: q.x, y: q.y});
      assert.equal(q.dx, 0); assert.equal(q.dy, 0);
    }
  }
  assert.deepEqual([...directions].sort(), ['0,-1', '1,0']);
  assert(appeared);
  assert(departed);
});

test('blue right/down/right/up route retains fixed occupied nodes and finishes with head above tail', () => {
  const definition = train({color: 'blue', origin: {x: 32, y: 128}, lengthCells: 5, initialHeadDistancePx: 64,
    path: [{id: 'start', x: 0, y: 0}, {id: 'down-one', x: 96, y: 0}, {id: 'east-two', x: 96, y: 96}, {id: 'up-two', x: 160, y: 96}, {id: 'finish', x: 160, y: -64}]});
  const c = createSmm2SnakeBlocks(room([definition])), seen = new Map(), directions = [];
  c.step({tick: 0, player: supported(c)});
  for (let tick = 1; c.view().trains[0].phase === 'moving'; tick++) {
    c.step({tick});
    const head = c.geometry().find(q => q.role === 'head'), direction = `${head.direction.x},${head.direction.y}`;
    if (directions.at(-1) !== direction) directions.push(direction);
    for (const q of c.geometry().filter(q => q.role === 'fixed')) {
      const position = {x: q.x, y: q.y};
      if (seen.has(q.id)) assert.deepEqual(position, seen.get(q.id));
      seen.set(q.id, position);
      assert.equal(q.dx, 0); assert.equal(q.dy, 0);
    }
  }
  assert.deepEqual(directions, ['1,0', '0,1', '1,0', '0,-1']);
  const final = c.view().trains[0].cells;
  assert.equal(final.length, 5); assert.equal(new Set(final.map(q => q.x)).size, 1);
  assert(final.find(q => q.role === 'head').y < final.find(q => q.role === 'tail').y);
  const endpointTick = c.view().tick;
  for (let n = 1; n <= definition.endpointHoldFrames; n++) c.step({tick: endpointTick + n});
  const dark = c.view().trains[0].cells.filter(q => q.darkened);
  assert.equal(dark.length, 1); assert.equal(dark[0].role, 'tail');
  assert(dark[0].y > Math.max(...c.view().trains[0].cells.filter(q => !q.darkened).map(q => q.y)));
});

for (const water of [false, true]) test(`existing ${water ? 'aquatic' : 'ordinary'} Mario motor actually lands, starts the train, and dismounts while it continues`, () => {
  const h = session(train({speedPxPerTick: .5}), {x: 66, y: 64}, {water});
  let landed = false;
  for (let tick = 0; tick < 140; tick++) {
    const result = h.step();
    if (result.activated.length) {landed = true; assert(h.player.grounded); assert(h.player.support.startsWith('smm2-snake-block:')); break;}
  }
  assert(landed, 'activation follows normal descending motor contact');
  const before = h.controller.view().trains[0].headDistancePx;
  const jump = h.step({jumpPressed: true, jump: true});
  assert(jump.events.includes('jump'));
  assert(h.player.vy < 0); assert.equal(h.player.grounded, false); assert.equal(h.player.support, null);
  for (let tick = 0; tick < 20; tick++) h.step({x: -1, jump: true});
  assert(h.controller.view().trains[0].headDistancePx > before + 8);
});

test('ordinary no-input standing on a middle node stays in world space while the active head and tail move', () => {
  const h = session(train({speedPxPerTick: .25}), {x: 66, y: 64});
  for (let tick = 0; tick < 80 && !h.player.grounded; tick++) h.step();
  assert(h.player.grounded);
  const support = h.player.support, x = h.player.x, y = h.player.y, head = h.controller.view().trains[0].headDistancePx;
  for (let tick = 0; tick < 60; tick++) {
    h.step(); near(h.player.x, x); near(h.player.y, y); assert.equal(h.player.support, support);
  }
  near(h.controller.view().trains[0].headDistancePx, head + 15);
});

test('all solid faces are shared native collision bodies, including moving ends', () => {
  const c = createSmm2SnakeBlocks(room()), motor = createPlatformMotor(), q = c.geometry()[0];
  const p = motor.create(character, {x: q.x - 11, y: q.y + 1}); p.vx = 1.5;
  c.step({tick: 1});
  stepSmm2SnakeBlockPlayer({controller: c, motor, player: p, input: {x: 1}, character, world: {width: 640, height: 320, solids: []}, tick: 1});
  near(p.x, q.x - p.w); assert.equal(p.vx, 0); assert.equal(c.view().trains[0].phase, 'idle');
  const under = motor.create(character, {x: q.x + 2, y: q.y + q.h + 1}); under.vy = -2;
  c.step({tick: 2});
  stepSmm2SnakeBlockPlayer({controller: c, motor, player: under, character, world: {width: 640, height: 320, solids: []}, tick: 2});
  assert.equal(under.headHit, q.id); assert.equal(c.view().trains[0].phase, 'idle');
});

test('exact final L-shaped occupancy freezes before separate tail-to-head darkening and falling', () => {
  const events = [], d = train({path: [{id: 'start', x: 0, y: 0}, {id: 'rise', x: 80, y: 0}, {id: 'turn', x: 80, y: -96}, {id: 'finish', x: 144, y: -96}], speedPxPerTick: 16, endpointHoldFrames: 2, collapseIntervalFrames: 3});
  const c = createSmm2SnakeBlocks(room([d]), {emit: (type, data) => events.push({type, ...data})});
  c.step({tick: 0, player: supported(c)});
  let tick = 0;
  while (c.view().trains[0].phase === 'moving') c.step({tick: ++tick});
  const final = c.view().trains[0], positions = final.cells.map(q => ({id: q.id, x: q.x, y: q.y}));
  assert.equal(final.cells.length, 6); assert.equal(final.phase, 'endpoint');
  assert.equal(final.cells.filter(q => q.y === 32).length, 5);
  assert.equal(final.cells.filter(q => q.x === 112 && q.y === 48).length, 1, 'below-left sixth cell never joins the top row');
  const head = final.cells.find(q => q.role === 'head');
  c.step({tick: ++tick});
  assert.deepEqual(c.view().trains[0].cells.map(q => ({id: q.id, x: q.x, y: q.y})), positions);
  c.step({tick: ++tick});
  let now = c.view().trains[0].cells;
  assert.equal(now.filter(q => q.darkened).length, 1);
  assert.equal(now.find(q => q.darkened).role, 'tail');
  assert(now.find(q => q.role === 'tail').y > 48);
  assert.deepEqual({x: now.find(q => q.role === 'head').x, y: now.find(q => q.role === 'head').y}, {x: head.x, y: head.y});
  for (let n = 0; n < 3; n++) c.step({tick: ++tick});
  now = c.view().trains[0].cells; assert.equal(now.filter(q => q.darkened).length, 2);
  assert(events.filter(e => e.event === 'cell-collapse').every((e, i) => e.collapseIndex === i));
  for (let n = 0; n < 200 && c.view().trains[0].phase !== 'complete'; n++) c.step({tick: ++tick});
  assert.equal(c.view().trains[0].phase, 'complete'); assert.equal(c.geometry().length, 0);
  assert.equal(events.filter(q => q.event === 'complete').length, 1);
});

test('explicit author-selected head-to-tail order is supported without a universal original-game claim', () => {
  const d = train({color: 'blue', lengthCells: 5, initialHeadDistancePx: 64, speedPxPerTick: 16, endpointHoldFrames: 0, collapseIntervalFrames: 4, collapseOrder: 'head-to-tail', path: [{id: 'start', x: 0, y: 0}, {id: 'down', x: 64, y: 0}, {id: 'finish', x: 64, y: 80}]});
  const c = createSmm2SnakeBlocks(room([d])); c.step({tick: 0, player: supported(c)});
  for (let tick = 1; tick <= 5; tick++) c.step({tick});
  const v = c.view().trains[0], dark = v.cells.filter(q => q.darkened);
  assert.equal(dark.length, 1); assert.equal(dark[0].role, 'head');
  assert(dark[0].y > Math.max(...v.cells.filter(q => !q.darkened).map(q => q.y)));
});

test('departing fixed node clears support and jump buffer before the real motor can grant a ghost jump', () => {
  const c = createSmm2SnakeBlocks(room([train({speedPxPerTick: 16})])), motor = createPlatformMotor();
  const player = supported(c), support = player.support;
  c.step({tick: 0, player}); c.step({tick: 1}); c.step({tick: 2});
  assert(!c.geometry().some(q => q.id === support)); player.jumpBuffer = 3;
  const result = stepSmm2SnakeBlockPlayer({controller: c, motor, player, input: {jumpPressed: true, jump: true}, character, world: {width: 640, height: 320, solids: []}, tick: 2});
  assert(result.supportCheck.invalidated); assert(!result.events.includes('jump'));
  assert(player.vy >= 0); assert.equal(player.grounded, false); assert.equal(player.support, null);
});

test('native motor receives falling displacement once; preparation never scripts player coordinates', () => {
  const d = train({initialHeadDistancePx: 80, path: [{id: 'start', x: 0, y: 0}, {id: 'finish', x: 80, y: 0}], endpointHoldFrames: 0, collapseIntervalFrames: 3, collapseGravity: .5});
  const c = createSmm2SnakeBlocks(room([d])), motor = createPlatformMotor(), player = supported(c, 'tail');
  c.step({tick: 0, player}); c.step({tick: 1});
  const before = {...player}, prepared = c.preparePlayer(player, {tick: 1});
  assert.deepEqual(player, before, 'controller does not move or freeze Mario');
  assert.equal(prepared.geometry.find(q => q.id === player.support).dy, .5);
  motor.step(player, {}, character, {width: 640, height: 320, solids: prepared.geometry});
  near(player.y, before.y + .5); assert.equal(player.grounded, true);
  const repeated = c.preparePlayer(player, {tick: 1});
  assert(repeated.geometry.every(q => q.dx === 0 && q.dy === 0));
  motor.step(player, {}, character, {width: 640, height: 320, solids: repeated.geometry});
  near(player.y, before.y + .5);
});

test('views and geometry are pure, duplicate ticks do not advance or emit, reset clears all state', () => {
  const events = [], c = createSmm2SnakeBlocks(room(), {emit: (type, data) => events.push({type, ...data})}), initial = c.view();
  const player = supported(c); c.step({tick: 7, player}); c.step({tick: 8});
  const moved = c.view(), eventCount = events.length;
  assert.deepEqual(c.view(), moved); assert.deepEqual(c.geometry(), moved.geometry);
  const detached = c.view(); detached.trains[0].cells[0].x = 1000; detached.geometry.pop();
  assert.deepEqual(c.view(), moved);
  assert.equal(c.step({tick: 8, player}).advanced, false); assert.equal(c.step({tick: 3}).advanced, false);
  assert.deepEqual(c.view(), moved); assert.equal(events.length, eventCount);
  assert.deepEqual(c.reset(), initial); assert.deepEqual(c.view(), initial);
  assert.equal(c.step({tick: 0, player: supported(c)}).advanced, true);
  assert.throws(() => c.step({tick: 1.2}));
  assert.throws(() => c.preparePlayer(player, {tick: 99}));
});
