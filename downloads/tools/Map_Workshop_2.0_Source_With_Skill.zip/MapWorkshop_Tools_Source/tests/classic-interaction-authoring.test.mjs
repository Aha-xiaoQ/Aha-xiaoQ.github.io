import fs from 'node:fs';
import assert from 'node:assert/strict';
import {test} from 'node:test';
import {blank,History,parseProject} from '../atlas/editor-model.mjs';
import {projectPack} from '../atlas/editor-runtime.mjs';
import {createStageCatalog} from '../atlas/runtime/stage-catalog.mjs';
import {mountClassicMotionTools} from '../atlas/editor-classic-motion-tools.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';
const character=JSON.parse(fs.readFileSync(new URL('../atlas/runtime/character.json',import.meta.url)));
function fixture(){
 const d=blank('Classic interaction authoring',640,240),r=d.rooms[0];
 r.map.geometry=[{id:'floor',x:0,y:208,w:640,h:32,collision:'solid',material:'ground'},{id:'pipe',x:320,y:160,w:32,h:48,collision:'solid',material:'pipe'},{id:'coin-brick',x:160,y:144,w:16,h:16,collision:'solid',material:'brick'},{id:'other-brick',x:192,y:144,w:16,h:16,collision:'solid',material:'brick'}];
 r.map.objects=[{id:'start',kind:'spawn',x:16,y:194,w:10,h:14},{id:'green',kind:'walker',x:240,y:184,w:16,h:24},{id:'plant',kind:'walker',x:328,y:136,w:16,h:24}];
 r.markers=[{id:'goal',kind:'flagpole-finish',x:560,y:208,source:{macro:'EndOutsideCastle',x:280,y:0,walkDistance:60}}];
 return d;
}
test('visible interaction tools author green wings, a real pipe plant, star, coin window and castle feedback with safe rejection and undo/reimport',()=>{
 const ui=installSimulatedPlayDom();try{
  const h=new History(fixture()),parent=ui.document.createElement('aside'),reports=[],room=()=>h.doc.rooms[0];
  const tools=mountClassicMotionTools({parent,room,change:fn=>h.change(fn),report:s=>reports.push(s)}),get=id=>parent.querySelector('[data-classic-control="'+id+'"]');
  get('green-speed').value='.7';get('green-hop').value='4.9';get('green-direction').value='1';get('green-apply').click();
  assert.deepEqual(room().marioModules.enemyVariants.green,{kind:'hopping-koopa',speed:.7,hopSpeed:4.9,direction:1});
  const before=JSON.stringify(h.doc);get('green-hop').value='20';get('green-apply').click();assert.equal(JSON.stringify(h.doc),before);assert(reports.length);
  get('enemy-select').value='plant';get('enemy-select').onchange();get('pipe-hidden').value='45';get('pipe-near').value='24';get('pipe-plant-apply').click();
  assert.equal(room().marioModules.enemyVariants.plant.kind,'pipe-piranha');assert.equal(room().marioModules.enemyVariants.plant.hiddenFrames,45);
  h.undo();tools.refresh();assert(!room().marioModules.enemyVariants.plant);h.redo();tools.refresh();assert.equal(get('pipe-hidden').value,45);
  get('star-frames').value='735';get('star-points').value='200';get('star-rule-apply').click();
  get('reward-window-target').value='coin-brick';get('reward-window-target').onchange();get('reward-window-frames').value='231';get('reward-window-apply').click();assert.equal(room().marioModules.rewardWindows['coin-brick'],231);
  get('reward-window-target').value='other-brick';get('reward-window-target').onchange();get('reward-window-frames').value='180';get('reward-window-apply').click();get('reward-window-target').value='coin-brick';get('reward-window-target').onchange();assert.equal(get('reward-window-frames').value,231);
  get('castle-flag-rise').value='30';get('goal-score-rate').value='1';get('castle-flag-wait').value='126';get('castle-flag-apply').click();assert.equal(room().marioModules.castleFlagRiseFrames,30);assert.equal(room().marioModules.goalScoreUnitsPerFrame,1);assert.equal(room().marioModules.castleFlagWaitFrames,126);
  const imported=parseProject(JSON.stringify(h.doc));assert.deepEqual(imported.rooms[0].marioModules,room().marioModules);const pack=projectPack(imported,room().roomId,character,'interaction-authoring');createStageCatalog(pack).plan(pack.stages[0].id,pack.characters[0].id,{allowDraft:true});
  get('star-rule-remove').click();assert.equal(room().marioModules.starFrames,undefined);h.undo();tools.refresh();assert.equal(get('star-frames').value,735);
  get('castle-flag-remove').click();assert.equal(room().marioModules.castleFlagRiseFrames,undefined);assert.equal(room().marioModules.castleFlagWaitFrames,undefined);
 }finally{ui.restore();}
});
