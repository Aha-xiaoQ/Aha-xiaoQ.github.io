import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {readFileSync} from 'node:fs';
import {sourcePixels} from '../atlas/source-art.mjs';
import {createSMM2Terrain} from '../atlas/editor-smm2-terrain.mjs';
import {SMM2_ART_PALETTE,drawSmm2Background,drawSmm2Tile,drawSmm2Actor,drawSmm2World,drawSmm2PlayerGear,drawSmm2Thwomp,drawSmm2Donut,drawSmm2Seesaw,drawSmm2Slope,drawSmm2Pow,drawSmm2BuzzyShell,drawSmm2Platform,drawSmm2Skewer,drawSmm2PinkCoin,drawSmm2PinkCoinHud,drawSmm2ThwompDeath,drawSmm2PowEffect} from '../atlas/editor-smm2-art.mjs';
const require=createRequire(import.meta.url);
let createCanvas;try{({createCanvas}=require('@napi-rs/canvas'));}catch{}
const rasterTest=(name,fn)=>test(name,{skip:!createCanvas},fn);
const room=()=>({map:{width:384,height:240,geometry:[]},smm2Mechanics:{version:1,art:{palette:'smb1-castle-stone'}}});
const canvas=(w=160,h=144)=>createCanvas(w,h);
const bytes=c=>c.getContext('2d').getImageData(0,0,c.width,c.height).data;
const pixel=(c,x,y)=>[...c.getContext('2d').getImageData(x,y,1,1).data];
function bounds(c){let x0=c.width,y0=c.height,x1=-1,y1=-1,count=0;const d=bytes(c);for(let y=0;y<c.height;y++)for(let x=0;x<c.width;x++)if(d[(y*c.width+x)*4+3]){x0=Math.min(x0,x);y0=Math.min(y0,y);x1=Math.max(x1,x);y1=Math.max(y1,y);count++;}return {x:x0,y:y0,w:x1-x0+1,h:y1-y0+1,count};}
function render(fn,q){const c=canvas();assert.equal(fn(c.getContext('2d'),q),true);return c;}
function opaque(c){for(let n=3,d=bytes(c);n<d.length;n+=4)assert.ok(d[n]===0||d[n]===255,'integer pixel components have no blended edge alpha');}

rasterTest('ordinary rooms and unidentified components leave the native canvas untouched',()=>{
 const c=canvas(),ctx=c.getContext('2d'),ordinary={map:{width:384,height:240}},r=room();
 assert.equal(drawSmm2Background(ctx,ordinary,160,144),false);
 assert.equal(drawSmm2Tile(ctx,{x:16,y:16,w:32,h:32,material:'ground'},ordinary),false);
 assert.equal(drawSmm2Actor(ctx,{type:'smm2-thwomp',x:16,y:16,w:24,h:32,smm2Thwomp:{phase:'charge'}},0,ordinary),false);
 assert.equal(drawSmm2World(ctx,ordinary,{version:1,donuts:[{x:16,y:16,w:16,h:16}]}),false);
 assert.equal(drawSmm2PlayerGear(ctx,{x:16,y:16,w:10,h:14,helmet:'buzzy'},0,ordinary),false);
 for(const material of ['brick','block','pipe','pipe-side','cloud-solid','used'])assert.equal(drawSmm2Tile(ctx,{x:16,y:16,w:16,h:16,material},r),false);
 for(const kind of ['coin','mushroom','walker','blue-flower-box'])assert.equal(drawSmm2Actor(ctx,{kind,x:16,y:16,w:16,h:16},0,r),false);
 assert.equal(bounds(c).count,0);
});

rasterTest('opt-in teal ground respects exact bounds and semisolid pillars keep open gaps',()=>{
 const r=room(),c=canvas(),ctx=c.getContext('2d');assert.equal(drawSmm2Tile(ctx,{x:16,y:16,w:48,h:40,material:'ground'},r),true);
 assert.deepEqual(bounds(c),{x:16,y:16,w:48,h:40,count:48*40});opaque(c);
 assert.equal(pixel(c,18,17)[3],255);
 const semi=canvas();r.map.geometry.push({id:'deck',x:16,y:16,w:64,h:80,material:'platform',smm2Art:'castle-semisolid'});
 assert.equal(drawSmm2Tile(semi.getContext('2d'),{id:'deck',x:16,y:16,w:64,h:80,material:'platform'},r),true);
 assert.equal(pixel(semi,28,18)[3],255,'real top is visible');assert.equal(pixel(semi,20,50)[3],255,'declared pillar is visible');assert.equal(pixel(semi,28,50)[3],0,'pillar gap stays transparent');
});

rasterTest('explicit interior/decorative tags render cyan fill, open pillar bodies, small blue flowers and native shell decoration',()=>{
 const r=room(),body={x:16,y:16,w:16,h:16},fill=canvas();assert.equal(drawSmm2Tile(fill.getContext('2d'),{...body,material:'ground',smm2Art:'castle-ground-fill'},r),true);
 assert.equal(bounds(fill).count,16*16);opaque(fill);
 const colors=new Set();for(let n=0,d=bytes(fill);n<d.length;n+=4)if(d[n+3])colors.add([...d.slice(n,n+3)].join(','));
 assert.equal(colors.size,3,'interior uses only the authored dirt and pebble palette');assert(!colors.has('135,170,168'),'interior cells have no masonry cap');
 const pillars=canvas();assert.equal(drawSmm2Tile(pillars.getContext('2d'),{...body,h:48,material:'decoration',smm2Art:'castle-semisolid-body'},r),true);assert.equal(bounds(pillars).count,5*48);assert.equal(pixel(pillars,18,16)[3],0);assert.equal(pixel(pillars,20,16)[3],255);assert.equal(pixel(pillars,28,16)[3],0,'top has no cap');assert.equal(pixel(pillars,28,40)[3],0,'pillar gaps remain transparent');
 const flower=canvas();assert.equal(drawSmm2Tile(flower.getContext('2d'),{...body,material:'decoration',smm2Art:'flower-center'},r),true);assert(bounds(flower).w<=8&&bounds(flower).h<=8);assert.equal(pixel(flower,16,16)[3],0);
 const shell=canvas(),native=render(drawSmm2BuzzyShell,body);assert.equal(drawSmm2Tile(shell.getContext('2d'),{...body,material:'decoration',smm2Art:'unresolved-rail-shell'},r),true);assert.deepEqual(bytes(shell),bytes(native));
 const original={id:'deco',...body,material:'decoration',smm2Art:'castle-semisolid-body'};r.decorations=[original];const before=JSON.stringify(r);assert.equal(drawSmm2Tile(canvas().getContext('2d'),{id:'deco',...body,material:'decoration'},r),true);assert.equal(JSON.stringify(r),before);
});

rasterTest('World draws only declared source arrows at source placement and respects facing/hidden markers',()=>{
 const r=room();r.markers=[{id:'arrow',kind:'source-arrow',x:16,y:16,source:{facing:'right'}}];r.semantics=[{id:'arrow',source:{bottom_origin:{w:3,h:3}}}];const before=JSON.stringify(r),right=canvas(),left=canvas();
 assert.equal(drawSmm2World(right.getContext('2d'),r,{smm2Mechanics:{version:1}}),true);const b=bounds(right);assert(b.count>0&&b.x>=16&&b.y>=16&&b.x+b.w<=64&&b.y+b.h<=64);opaque(right);
 const opposite={...r,markers:[{...r.markers[0],source:{facing:'left'}}]};assert.equal(drawSmm2World(left.getContext('2d'),opposite,{version:1}),true);assert.notDeepEqual(bytes(left),bytes(right));
 const hidden=canvas();assert.equal(drawSmm2World(hidden.getContext('2d'),r,{smm2Mechanics:{version:1},hiddenMarkers:['arrow']}),false);assert.equal(bounds(hidden).count,0);assert.equal(drawSmm2World(hidden.getContext('2d'),{...r,smm2Mechanics:undefined},{version:1}),false);assert.equal(JSON.stringify(r),before);
});

rasterTest('small and giant Thwomps stay bounded with distinct neutral, angry and directional faces',()=>{
 for(const body of [{x:16,y:16,w:24,h:32},{x:16,y:16,w:48,h:64}]){
  const neutral=render(drawSmm2Thwomp,{...body,smm2Thwomp:{phase:'idle',direction:'down'}}),angry=render(drawSmm2Thwomp,{...body,smm2Thwomp:{phase:'charge',direction:'down'}});
  const b=bounds(neutral);assert.equal(b.x,body.x);assert.equal(b.y,body.y);assert.equal(b.w,body.w);assert.equal(b.h,body.h);assert.notDeepEqual(bytes(neutral),bytes(angry));opaque(neutral);opaque(angry);
  const left=render(drawSmm2Thwomp,{...body,smm2Thwomp:{phase:'windup',direction:'left'}}),right=render(drawSmm2Thwomp,{...body,smm2Thwomp:{phase:'windup',direction:'right'}});assert.notDeepEqual(bytes(left),bytes(right));
 }
});

rasterTest('Thwomp dispatch draws wings only for the actual validated true flag and preserves the actor pose',()=>{
 const r=room(),actor={type:'smm2-thwomp',x:32,y:32,w:24,h:32,smm2Thwomp:{phase:'charge',direction:'down'}},plain=canvas(),unwinged=canvas(),winged=canvas();
 assert.equal(drawSmm2Actor(plain.getContext('2d'),actor,0,r),true);
 assert.equal(drawSmm2Actor(unwinged.getContext('2d'),{...actor,winged:false},0,r),true);assert.deepEqual(bytes(plain),bytes(unwinged));
 const actual={...actor,winged:true},before=JSON.stringify(actual);assert.equal(drawSmm2Actor(winged.getContext('2d'),actual,0,r),true);opaque(winged);
 assert(bounds(winged).x<actor.x);assert(bounds(winged).x+bounds(winged).w>actor.x+actor.w);assert.equal(JSON.stringify(actual),before);
 const inferred=canvas();assert.equal(drawSmm2Actor(inferred.getContext('2d'),{...actor,winged:'true'},0,r),true);assert.deepEqual(bytes(plain),bytes(inferred));
 const invalid=canvas();assert.equal(drawSmm2Actor(invalid.getContext('2d'),{...actual,w:0},0,r),false);assert.equal(bounds(invalid).count,0,'failed body drawing cannot leave unattached wings');
});

rasterTest('actual dead Thwomp effect dispatch keeps its real ballistic body and uses an upside-down authored Thwomp',()=>{
 const effect={kind:'enemy-death',type:'smm2-thwomp',x:32,y:24,w:24,h:32,dead:true,flat:false,vx:.8,vy:-3,life:80,age:0,smm2Thwomp:{phase:'impact',direction:'down'}},before=JSON.stringify(effect),c=canvas(),r=room();
 assert.equal(drawSmm2Actor(c.getContext('2d'),effect,24,r),true);opaque(c);assert.deepEqual({...bounds(c),count:undefined},{x:32,y:24,w:24,h:32,count:undefined});
 const normal=render(drawSmm2Thwomp,{...effect,dead:false});for(let y=0;y<32;y++)for(let x=0;x<24;x++)assert.deepEqual(pixel(c,32+x,24+y),pixel(normal,32+x,24+31-y));
 const next={...effect,x:40,y:52,vy:2,age:12,life:68},moved=canvas();assert.equal(drawSmm2Actor(moved.getContext('2d'),next,99,r),true);assert.equal(bounds(moved).x,40);assert.equal(bounds(moved).y,52);assert.equal(JSON.stringify(effect),before);
 assert.equal(drawSmm2ThwompDeath(canvas().getContext('2d'),effect),true);
 const ordinary=canvas();assert.equal(drawSmm2Actor(ordinary.getContext('2d'),{...effect,type:'goomba'},0,r),false);assert.equal(drawSmm2Actor(ordinary.getContext('2d'),effect,0,{}),false);assert.equal(drawSmm2Actor(ordinary.getContext('2d'),{...effect,kind:'walker'},0,r),false);assert.equal(bounds(ordinary).count,0);
 for(const patch of [{visible:false},{hidden:true},{life:0},{removed:true}]){const absent=canvas();assert.equal(drawSmm2Actor(absent.getContext('2d'),{...effect,...patch},0,r),true);assert.equal(bounds(absent).count,0);}
});

rasterTest('actual flat POW effect expands and flashes within its supplied bounds without resurrecting spent blocks',()=>{
 const effect={kind:'pow-effect',x:32,y:24,w:48,h:48,vx:0,vy:0,flat:true,life:16,age:0},r=room(),before=JSON.stringify(effect),early=canvas(),later=canvas(),flash=canvas();
 for(const [c,q]of [[early,effect],[later,{...effect,age:6,life:10}],[flash,{...effect,age:4,life:12}]]){assert.equal(drawSmm2Actor(c.getContext('2d'),q,999,r),true);const b=bounds(c);assert(b.count>0);assert(b.x>=q.x&&b.y>=q.y&&b.x+b.w<=q.x+q.w&&b.y+b.h<=q.y+q.h);opaque(c);}
 assert(bounds(later).w>bounds(early).w);assert.notDeepEqual(bytes(early),bytes(flash));assert.equal(JSON.stringify(effect),before);
 assert.equal(drawSmm2PowEffect(canvas().getContext('2d'),effect),true);
 const ordinary=canvas();assert.equal(drawSmm2Actor(ordinary.getContext('2d'),effect,0,{}),false);assert.equal(bounds(ordinary).count,0);
 for(const patch of [{visible:false},{life:0},{removed:true}]){const absent=canvas();assert.equal(drawSmm2Actor(absent.getContext('2d'),{...effect,...patch},0,r),true);assert.equal(bounds(absent).count,0);}
 for(const dead of [false,true]){const spent=canvas();assert.equal(drawSmm2Actor(spent.getContext('2d'),{kind:'pow',x:32,y:24,w:16,h:16,dead,smm2Pow:{phase:'spent'}},0,r),true);assert.equal(bounds(spent).count,0);}
});

rasterTest('Donut holes remain open, shake is contact-driven and falling uses actual live position',()=>{
 const q={x:32,y:16,w:32,h:16,phase:'idle'},idle=render(drawSmm2Donut,q);
 assert.equal(pixel(idle,40,23)[3],0);assert.equal(pixel(idle,56,23)[3],0);assert.equal(pixel(idle,35,18)[3],255);opaque(idle);
 const shake=render(drawSmm2Donut,{...q,phase:'shaking',contactFrames:2});assert.equal(bounds(shake).x,bounds(idle).x+1);
 const falling=render(drawSmm2Donut,{...q,y:64,phase:'falling',contactFrames:2});assert.equal(bounds(falling).y,64);assert.equal(bounds(falling).x,32);assert.equal(pixel(falling,40,71)[3],0);
 const removed=canvas();assert.equal(drawSmm2Donut(removed.getContext('2d'),{...q,phase:'removed'}),false);assert.equal(bounds(removed).count,0);
});

rasterTest('the seesaw rotates from its actual pivot and the triangular slope stays empty above its true surface',()=>{
 const q={pivotX:80,pivotY:72,length:96,thickness:8,angleDegrees:0},flat=render(drawSmm2Seesaw,q),tilted=render(drawSmm2Seesaw,{...q,angleDegrees:30});assert.notDeepEqual(bytes(flat),bytes(tilted));
 assert.equal(pixel(flat,35,72)[3],255);assert.equal(pixel(tilted,35,72)[3],0);assert.equal(pixel(tilted,41,49)[3],255);opaque(tilted);
 const slope=render(drawSmm2Slope,{x:16,y:16,w:64,h:48,orientation:'rise-right'});assert.equal(pixel(slope,18,18)[3],0);assert.equal(pixel(slope,77,61)[3],255);assert.equal(pixel(slope,78,18)[3],255);opaque(slope);
});

rasterTest('both ceiling slope orientations fill above the underside and leave the passage below transparent',()=>{
 const body={x:16,y:16,w:64,h:48};
 for(const orientation of ['ceiling-rise-left','ceiling-rise-right']){
  const c=render(drawSmm2Slope,{...body,orientation});opaque(c);
  assert.equal(bounds(c).count,64*48/2,'only the actual upper triangle is drawn');
  assert.equal(pixel(c,48,18)[3],255,'ceiling bulk above the diagonal is solid');
  assert.equal(pixel(c,48,61)[3],0,'passage below the diagonal is open');
  const right=orientation.endsWith('rise-right');
  assert.equal(pixel(c,18,48)[3],right?255:0);assert.equal(pixel(c,77,48)[3],right?0:255);
  const floor=render(drawSmm2Slope,{...body,orientation:right?'rise-right':'rise-left'});assert.notDeepEqual(bytes(c),bytes(floor));
 }
});

rasterTest('World consumes the actual terrain slope polygon, solidAbove and underside without discarding the live shape',()=>{
 const r=room();r.smm2Mechanics.slopes=[
  {id:'ceiling-left',x:16,y:16,w:64,h:48,orientation:'ceiling-rise-left',collision:'solid'},
  {id:'ceiling-right',x:88,y:16,w:64,h:48,orientation:'ceiling-rise-right',collision:'solid'}
 ];
 const terrain=createSMM2Terrain(r),view=terrain.view(),before=JSON.stringify({r,view}),c=canvas();
 assert.equal(view.surfaces.length,2);assert(view.surfaces.every(q=>q.kind==='slope'&&q.solidAbove===true&&q.underside&&q.polygon.length===3));
 assert.equal(drawSmm2World(c.getContext('2d'),r,{smm2Mechanics:view}),true);opaque(c);
 assert.equal(pixel(c,48,18)[3],255);assert.equal(pixel(c,48,61)[3],0);assert.equal(pixel(c,120,18)[3],255);assert.equal(pixel(c,120,61)[3],0);
 assert.equal(JSON.stringify({r,view}),before);
 // A detached live shape retains its actual polygon/underside even when its
 // descriptive spec has a floor orientation. Passing only spec loses this.
 const shape=view.surfaces[1],detached={...shape,orientation:undefined,spec:{...shape.spec,orientation:'rise-right'}},actual=canvas(),expected=canvas();
 assert.equal(drawSmm2World(actual.getContext('2d'),r,{version:1,surfaces:[detached]}),true);
 assert.equal(drawSmm2Slope(expected.getContext('2d'),shape),true);assert.deepEqual(bytes(actual),bytes(expected));
 const undersideShift={...shape,underside:{a:{...shape.underside.a,y:shape.underside.a.y+3},b:{...shape.underside.b,y:shape.underside.b.y+3}}},shifted=render(drawSmm2Slope,undersideShift);
 assert.notDeepEqual(bytes(shifted),bytes(expected),'stone edge shading follows the supplied underside');
});

rasterTest('POW letters, platform openings and live Skewer extension do not erase underlying scenery',()=>{
 const pow=render(drawSmm2Pow,{x:16,y:16,w:16,h:16});assert(bounds(pow).count>100);assert.equal(pixel(pow,19,21).slice(0,3).join(','),'255,251,234');
 const platforms=[];
 for(const platformStyle of ['blue','orange','skull']){
  const c=canvas(),ctx=c.getContext('2d');ctx.fillStyle='#314159';ctx.fillRect(0,0,c.width,c.height);assert.equal(drawSmm2Platform(ctx,{x:16,y:16,w:48,h:16,platformStyle}),true);assert.equal(pixel(c,18,22)[3],255);assert.equal(pixel(c,18,22).slice(0,3).join(','),'49,65,89');platforms.push(bytes(c));
 }
 assert.notDeepEqual(platforms[0],platforms[1]);assert.notDeepEqual(platforms[1],platforms[2]);
 const base={x:16,y:32,w:8,h:32},retracted=render(drawSmm2Skewer,{direction:'right',base,shaft:{x:24,y:32,w:0,h:32}}),extended=render(drawSmm2Skewer,{direction:'right',base,shaft:{x:24,y:32,w:88,h:32}});
 assert.equal(bounds(retracted).w,8);assert(bounds(extended).w>88);assert.equal(pixel(retracted,80,46)[3],0);assert.equal(pixel(extended,80,46)[3],255);assert.equal(pixel(extended,113,46)[3],0);opaque(extended);
});

rasterTest('Buzzy shells reuse the native blue pixels exactly and gear remains an overlay',()=>{
 const native=sourcePixels('src|Character|ShellBeetle|Underworld|'),before=JSON.stringify(native),c=render(drawSmm2BuzzyShell,{x:16,y:16,w:native.w,h:native.h});
 for(let y=0;y<native.h;y++)for(let x=0;x<native.w;x++)assert.deepEqual(pixel(c,x+16,y+16),native.pixels[y*native.w+x]);
 const helmet=canvas(),ctx=helmet.getContext('2d');assert.equal(drawSmm2PlayerGear(ctx,{x:36,y:50,w:10,h:28,power:1,helmet:'buzzy'},0,room()),true);assert.equal(pixel(helmet,40,73)[3],0,'body pixels are left to native Mario');assert.equal(JSON.stringify(native),before);
 assert.equal(drawSmm2PlayerGear(ctx,{x:36,y:50,w:10,h:28,power:1},0,room()),false);
});

rasterTest('only explicitly declared pink coin IDs receive a tint, with exact native geometry and untouched native pixels',()=>{
 const r=room();r.smm2Mechanics.pinkCoins=[{id:'key-coin'}];
 const actor={id:'key-coin',kind:'coin',x:16,y:16,w:16,h:16},native=sourcePixels('src|Character|Coin||'),before=JSON.stringify({native,r,actor}),c=canvas(),ctx=c.getContext('2d');
 assert.equal(drawSmm2Actor(ctx,actor,0,r),true);opaque(c);
 const nativeX=19,nativeY=18,pinkColors=new Set([SMM2_ART_PALETTE.pink,SMM2_ART_PALETTE.pinkDark,SMM2_ART_PALETTE.pinkInk].map(v=>[parseInt(v.slice(1,3),16),parseInt(v.slice(3,5),16),parseInt(v.slice(5,7),16)].join(',')));
 for(let y=0;y<native.h;y++)for(let x=0;x<native.w;x++){
  const actual=pixel(c,nativeX+x,nativeY+y),expected=native.pixels[y*native.w+x];assert.equal(actual[3],expected[3]);if(actual[3])assert(pinkColors.has(actual.slice(0,3).join(',')));
 }
 const blank=canvas(),ordinary={...actor,id:'ordinary-coin'};assert.equal(drawSmm2Actor(blank.getContext('2d'),ordinary,0,r),false);assert.equal(bounds(blank).count,0);
 assert.equal(drawSmm2Actor(blank.getContext('2d'),actor,0,{map:r.map}),false);
 assert.equal(drawSmm2Actor(blank.getContext('2d'),{...actor,taken:true},0,r),false);
 assert.equal(JSON.stringify({native,r,actor}),before);assert.equal(drawSmm2PinkCoin(canvas().getContext('2d'),actor),true);
});

rasterTest('pink coin HUD slots show actual full-course count and leave uncollected interiors open',()=>{
 const view={smm2Mechanics:{version:1,pinkCoins:{taken:2,total:4,keyReleased:false}}},before=JSON.stringify(view),c=canvas();
 assert.equal(drawSmm2PinkCoinHud(c.getContext('2d'),view,{x:16,y:16,spacing:12}),true);opaque(c);
 assert.equal(bounds(c).w,43);assert.equal(bounds(c).h,9);assert.equal(pixel(c,19,20)[3],255);assert.equal(pixel(c,31,20)[3],255);assert.equal(pixel(c,43,20)[3],0);assert.equal(pixel(c,55,20)[3],0);assert.equal(pixel(c,40,20)[3],255);
 const completed=canvas();assert.equal(drawSmm2PinkCoinHud(completed.getContext('2d'),{smm2Mechanics:{version:1,pinkCoins:{taken:4,total:4,keyReleased:true}}},{x:16,y:16}),true);assert.equal(pixel(completed,55,20)[3],255);
 const three=canvas();assert.equal(drawSmm2PinkCoinHud(three.getContext('2d'),{version:1,pinkCoins:{taken:0,total:3}},{x:16,y:16}),true);assert.equal(bounds(three).w,31,'slot total is not hardcoded to four');
 const absent=canvas();for(const progress of [undefined,{taken:1,total:0},{taken:5,total:4},{taken:1.5,total:4}])assert.equal(drawSmm2PinkCoinHud(absent.getContext('2d'),{smm2Mechanics:{version:1,pinkCoins:progress}}),false);assert.equal(bounds(absent).count,0);
 assert.equal(JSON.stringify(view),before);
});

rasterTest('dispatch reads real versioned terrain view and keeps every game input unchanged',()=>{
 const r=room(),q={type:'smm2-thwomp',x:16,y:16,w:24,h:32,smm2Thwomp:{phase:'charge',direction:'left'}},view={smm2Mechanics:{version:1,surfaces:[],donuts:[{id:'donut',x:16,y:64,w:16,h:16,phase:'falling'}],seesaws:[]}},before=JSON.stringify({r,q,view}),c=canvas();
 assert.equal(drawSmm2Actor(c.getContext('2d'),q,12,r),true);assert.equal(drawSmm2World(c.getContext('2d'),r,view,12),true);assert.equal(JSON.stringify({r,q,view}),before);
});

rasterTest('authored placeholders use only explicit same-ID leaves and stay immutable while showing static component poses',()=>{
 const r=room(),base={kind:'walker',x:32,y:32,w:24,h:32},thwomp={...base,id:'authored-thwomp'},pow={...base,id:'authored-pow',w:16,h:16},helmet={...pow,id:'authored-helmet'},life={...pow,id:'authored-life'},skewer={id:'authored-skewer',kind:'hazard',x:32,y:32,w:8,h:32};
 r.map.objects=[thwomp,pow,helmet,life,skewer];Object.assign(r.smm2Mechanics,{thwomps:[{id:thwomp.id,direction:'left',winged:true}],powBlocks:[{id:pow.id}],helmets:[{id:helmet.id}],placedItems:[{id:life.id,kind:'life'}],skewers:[{id:skewer.id,direction:'right',phaseOffsetFrames:100}]});
 const before=JSON.stringify(r);
 for(const actor of r.map.objects){const c=canvas();assert.equal(drawSmm2Actor(c.getContext('2d'),actor,0,r),true);assert(bounds(c).count>0);opaque(c);}
 const staticThwomp=canvas(),idleThwomp=canvas();drawSmm2Actor(staticThwomp.getContext('2d'),thwomp,0,r);drawSmm2Actor(idleThwomp.getContext('2d'),{...thwomp,type:'smm2-thwomp',winged:true,smm2Thwomp:{phase:'idle',direction:'left'}},0,r);assert.deepEqual(bytes(staticThwomp),bytes(idleThwomp));
 const retracted=canvas();drawSmm2Actor(retracted.getContext('2d'),skewer,0,r);assert.deepEqual({...bounds(retracted),count:undefined},{x:32,y:32,w:8,h:32,count:undefined});assert.equal(pixel(retracted,72,46)[3],0,'static unloaded Skewer never invents an extension');
 const nativeLife=sourcePixels('src|Character|Mushroom1Up||'),lifePreview=canvas();drawSmm2Actor(lifePreview.getContext('2d'),life,0,r);for(let y=0;y<nativeLife.h;y++)for(let x=0;x<nativeLife.w;x++)assert.deepEqual(pixel(lifePreview,32+x,32+y),nativeLife.pixels[y*nativeLife.w+x]);
 const blank=canvas();for(const actor of [{...base,id:'ordinary-walker'},{...base,id:'different-id',sourceId:thwomp.id},{...base,id:skewer.id},{...thwomp,kind:'coin'},{...life,kind:'life'}])assert.equal(drawSmm2Actor(blank.getContext('2d'),actor,0,r),false);assert.equal(bounds(blank).count,0);assert.equal(JSON.stringify(r),before);
});

rasterTest('live SMM2 poses win over authored static leaves and spent actors are never repainted',()=>{
 const r=room();r.smm2Mechanics.thwomps=[{id:'thwomp',direction:'left',winged:true}];r.smm2Mechanics.powBlocks=[{id:'pow'}];r.smm2Mechanics.skewers=[{id:'skewer',direction:'right'}];
 const live={id:'thwomp',kind:'walker',type:'smm2-thwomp',x:32,y:52,w:24,h:32,winged:false,smm2Thwomp:{phase:'charge',direction:'right'}},actual=canvas(),expected=render(drawSmm2Thwomp,live);assert.equal(drawSmm2Actor(actual.getContext('2d'),live,0,r),true);assert.deepEqual(bytes(actual),bytes(expected));
 const extended={id:'skewer',kind:'hazard',type:'smm2-skewer',x:32,y:32,w:8,h:32,smm2Skewer:{direction:'right',loaded:true,base:{x:32,y:32,w:8,h:32},shaft:{x:40,y:32,w:56,h:32}}},liveSkewer=canvas();assert.equal(drawSmm2Actor(liveSkewer.getContext('2d'),extended,0,r),true);assert.equal(pixel(liveSkewer,72,46)[3],255);
 for(const dead of [false,true]){const c=canvas();assert.equal(drawSmm2Actor(c.getContext('2d'),{id:'pow',kind:'walker',x:32,y:32,w:16,h:16,dead,smm2Pow:{phase:'spent'}},0,r),true);assert.equal(bounds(c).count,0,'a spent live state is consumed and cannot become an authored POW or fallback walker');}
 const spent=canvas();assert.equal(drawSmm2Actor(spent.getContext('2d'),{id:'pow',kind:'pow',x:32,y:32,w:16,h:16,dead:true,smm2Pow:{phase:'spent'}},0,r),true);assert.equal(bounds(spent).count,0);
});

test('native sprite encodings stay exact and decoder changes only the proven Podoboo width correction',()=>{
 assert.deepEqual(readFileSync(new URL('../atlas/source-sprite-data.mjs',import.meta.url)),readFileSync(new URL('./native-baseline/source-sprite-data.mjs',import.meta.url)));
 assert.equal(readFileSync(new URL('../atlas/source-art.mjs',import.meta.url),'utf8').replace('const widths={Podoboo:14,','const widths={'),readFileSync(new URL('./native-baseline/source-art.mjs',import.meta.url),'utf8'));
 assert(Object.isFrozen(SMM2_ART_PALETTE));
});
