import {test} from 'node:test';
import assert from 'node:assert/strict';
import {renderLightingPlayPair} from './fixtures/lighting-render-dom.mjs';

test('actual native play paints the real lighting mask after world and before bright HUD pixels',async()=>{
 const {dark,off}=await renderLightingPlayPair();assert.equal(dark.view.tick,off.view.tick);assert.equal(dark.view.p.y,off.view.p.y);
 const mask=dark.calls.findLastIndex(q=>q.kind==='image'&&q.sourceWidth===512&&q.sourceHeight===480&&q.args.length===4&&q.args.every((n,i)=>n===[0,0,512,480][i]));assert(mask>=0,'actual full viewport mask was drawn');
 const hud=dark.calls.findIndex((q,i)=>i>mask&&q.kind==='rect'&&['#fff','#ffffff'].includes(q.fill)&&q.y>=20&&q.y<=60);assert(hud>mask,'actual pixel HUD glyphs were drawn after the mask');
 let white=0;const sample=(c,x,y)=>[...c.getContext('2d').getImageData(x,y,1,1).data];
 for(const q of dark.calls.slice(mask+1))if(q.kind==='rect'&&['#fff','#ffffff'].includes(q.fill)&&q.y>=20&&q.y<=60){assert.deepEqual(sample(dark.canvas,q.x,q.y),[255,255,255,255]);assert.deepEqual(sample(off.canvas,q.x,q.y),[255,255,255,255]);white+=q.w*q.h;}
 assert(white>300,'hundreds of actual HUD foreground pixels stay fully bright');
 assert.deepEqual(sample(dark.canvas,450,100),[0,0,0,255]);assert.notDeepEqual(sample(off.canvas,450,100),[0,0,0,255]);
 assert.equal(dark.view.lives,3);assert.equal(dark.view.p.grounded,true);
});
