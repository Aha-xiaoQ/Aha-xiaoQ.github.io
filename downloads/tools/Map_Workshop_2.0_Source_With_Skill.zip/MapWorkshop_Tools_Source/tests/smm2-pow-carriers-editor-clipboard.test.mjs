import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {History,clone,uid,moveSelection,deleteSelection,linked,parseProject} from '../atlas/editor-model.mjs';
import {captureSmm2LightingBindings,appendCopiedSmm2LightingBindings,pruneSmm2LightingReferences} from '../atlas/editor-smm2-lighting-tools.mjs';
import {captureSmm2ActorLeaves,appendCopiedSmm2ActorLeaves,pruneSmm2DeletedReferences} from '../atlas/editor-smm2-tools.mjs';
import {captureSmm2GeometryBindings,appendSmm2GeometryBindings} from '../atlas/editor-smm2-course-tools.mjs';
import {captureSmm2BoneBindings,appendCopiedSmm2BoneBindings} from '../atlas/editor-smm2-bone-tools.mjs';
import {captureMarioEmptyShellSources,appendCopiedMarioEmptyShellSources} from '../atlas/editor-mario-modules-editor.mjs';
import {enableCopiedSpikeTraps} from '../atlas/editor-contraptions-tools.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';
import {powCarrierProject} from './fixtures/pow-carriers-native.mjs';

// Actual existing native clipboard handlers run in a History/selection host.
// This checks call order and stable references, not pointer/layout behavior.
function mountClipboard(h,ui){
 const source=fs.readFileSync(new URL('../atlas/editor.mjs',import.meta.url),'utf8'),start=source.indexOf("$('copy').onclick="),end=source.indexOf("$('map-export').onclick=",start);assert(start>=0&&end>start);
 const camera={x:320,y:80},buttons=Object.fromEntries(['copy','paste','delete'].map(id=>[id,ui.document.createElement('button')])),reports=[];
 const host={camera,selected:new Set(),$:id=>buttons[id],room:()=>h.doc.rooms[0],layer:()=> 'objects',items:()=>h.doc.rooms[0].map.objects,
  run:fn=>{try{fn();}catch(error){reports.push(error.message);}},say:q=>reports.push(q),refresh:()=>{},transaction:fn=>h.change(()=>{const before=clone(h.doc);fn();pruneSmm2DeletedReferences(h.doc.rooms[0],before.rooms[0]);pruneSmm2LightingReferences(h.doc.rooms[0],before.rooms[0]);}),
  clone,uid,linked,moveSelection,deleteSelection,captureSmm2LightingBindings,appendCopiedSmm2LightingBindings,captureSmm2ActorLeaves,appendCopiedSmm2ActorLeaves,captureSmm2GeometryBindings,appendSmm2GeometryBindings,captureSmm2BoneBindings,appendCopiedSmm2BoneBindings,captureMarioEmptyShellSources,appendCopiedMarioEmptyShellSources,enableCopiedSpikeTraps};
 const api=new Function('host','const {$,room,layer,items,run,say,refresh,transaction,clone,uid,linked,moveSelection,deleteSelection,captureSmm2LightingBindings,appendCopiedSmm2LightingBindings,captureSmm2ActorLeaves,appendCopiedSmm2ActorLeaves,captureSmm2GeometryBindings,appendSmm2GeometryBindings,captureSmm2BoneBindings,appendCopiedSmm2BoneBindings,captureMarioEmptyShellSources,appendCopiedMarioEmptyShellSources,enableCopiedSpikeTraps}=host;let selected=host.selected,clipboard=null;const camera=host.camera;'+source.slice(start,end)+';return {select(ids){selected=ids;},selected(){return selected;}};')(host);
 return {...api,buttons,reports};
}

test('actual native editor copy/paste/delete remaps POW/Thwomp support pairs and lights in the same History transaction',()=>{
 const ui=installSimulatedPlayDom();try{
  const h=new History(powCarrierProject()),r=()=>h.doc.rooms[0],native=mountClipboard(h,ui);native.select(new Set(['thwomp','pow-left','pow-right']));native.buttons.copy.click();native.buttons.paste.click();const copies=native.selected();assert.equal(copies.size,3,native.reports.join(';'));
  const parent=r().smm2Mechanics.thwomps.find(q=>copies.has(q.id));assert(parent);const pows=r().smm2Mechanics.powBlocks.filter(q=>copies.has(q.id));assert.equal(pows.length,2);
  for(const pow of pows){assert.deepEqual(r().smm2Mechanics.carrierItems.find(q=>q.id===pow.id),{id:pow.id,carrierId:parent.id});assert(r().smm2Mechanics.lighting.sources.some(q=>q.targetId===pow.id));}
  assert.deepEqual(parseProject(JSON.stringify(h.doc)),h.doc);native.buttons.delete.click();assert.equal(r().smm2Mechanics.carrierItems.length,2);assert(!r().smm2Mechanics.lighting.sources.some(q=>copies.has(q.targetId)));h.undo();assert.equal(r().smm2Mechanics.carrierItems.length,4);h.redo();assert.equal(r().smm2Mechanics.carrierItems.length,2);assert.deepEqual(parseProject(JSON.stringify(h.doc)),h.doc);
 }finally{ui.restore();}
});

test('actual native editor pastes a lone copied POW as independent cargo with its stable light',()=>{
 const ui=installSimulatedPlayDom();try{const h=new History(powCarrierProject()),r=()=>h.doc.rooms[0],native=mountClipboard(h,ui);native.select(new Set(['pow-left']));native.buttons.copy.click();native.buttons.paste.click();const [id]=native.selected();assert.notEqual(id,'pow-left');assert(r().smm2Mechanics.powBlocks.some(q=>q.id===id));assert(!r().smm2Mechanics.carrierItems.some(q=>q.id===id));assert(r().smm2Mechanics.lighting.sources.some(q=>q.targetId===id));assert.deepEqual(parseProject(JSON.stringify(h.doc)),h.doc);}finally{ui.restore();}
});
