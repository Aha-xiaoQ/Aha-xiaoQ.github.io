import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
import {offlineFile} from '../atlas/editor-offline.mjs';
import {createCollection,addLevel,buildCollection} from '../atlas/editor-collection.mjs';
import {plantPlatformProject,rollingPlatformProject,nativeSession} from './fixtures/npc-platform-native.mjs';
import {character} from './fixtures/shell-coin-native.mjs';
for(const mode of ['single','collection'])test(mode+' offline HTML closes the actual Stage graph and executes real plant/shell carry without network',async()=>{
 const plant=plantPlatformProject(),shell=rollingPlatformProject(),session=nativeSession(plant),root=new URL('../atlas/',import.meta.url),collection=mode==='collection'?buildCollection(addLevel(addLevel(createCollection('Neutral carry offline'),plant,{id:'plant-fixture'}),shell,{id:'shell-fixture'}),character,{includePending:true}):null,html=await offlineFile(session.pack,session.doc.rooms,p=>fs.promises.readFile(new URL(p,root),'utf8'),p=>fs.promises.readFile(new URL('assets/classic-audio/'+p,root)),()=>{},collection?{collection}:{});
 assert(html.includes('"carryEnemiesOnPlatforms":true'));if(collection)assert(html.includes('native-enemy-platform-carry-v1'));const dir=fs.mkdtempSync(path.join(os.tmpdir(),'Neutral NPC Platform Offline '));
 try{const htmlPath=path.join(dir,'fixture.html');fs.writeFileSync(htmlPath,html);for(const [kind,project]of [['plant',plant],['shell',shell]]){const projectPath=path.join(dir,kind+'.qmap.json');fs.writeFileSync(projectPath,JSON.stringify(project));const r=spawnSync(process.execPath,['--experimental-vm-modules',fileURLToPath(new URL('../scripts/check-native-enemy-platform-offline.mjs',import.meta.url)),htmlPath,projectPath,kind,mode],{encoding:'utf8',timeout:30000,maxBuffer:1024*1024});assert.equal(r.status,0,r.stderr||r.stdout||String(r.error));const report=JSON.parse(r.stdout);assert.equal(report.actualEmbeddedStageExecuted,true);assert.equal(report.networkRequests,0);assert(report.carriedFrames>15);if(kind==='shell')assert.equal(report.physicalShellPickups,2);}}
 finally{fs.rmSync(dir,{recursive:true,force:true});}
});
