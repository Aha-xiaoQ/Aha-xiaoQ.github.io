import assert from 'node:assert/strict';
import {test} from 'node:test';
import {readFileSync} from 'node:fs';
import {blank} from '../atlas/editor-model.mjs';
import {projectPack} from '../atlas/editor-runtime.mjs';
import {play} from '../atlas/editor-play.mjs';
import {offlineFile} from '../atlas/editor-offline.mjs';
import {inspectOfflineHtml} from '../scripts/check-offline-html.mjs';
import {createCanvasMouseInput,createDirectionalInput} from '../atlas/editor-play-input.mjs';
import {createGamepadInput} from '../atlas/editor-gamepad.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';

// Executes real DOM handlers, navigator.getGamepads polling and the native Stage.
// It does not claim browser layout, OS mouse handling or physical controller QA.
const character=JSON.parse(readFileSync(new URL('../atlas/runtime/character.json',import.meta.url)));
const controller=(id='Xbox Wireless Controller')=>({id,index:0,connected:true,mapping:'standard',axes:[0,0],buttons:Array.from({length:17},()=>({pressed:false,value:0}))});
function fixture({equipped=true,rack=false,shop=false}={}){
 const doc=blank('Minecraft desktop input',1280,320),room=doc.rooms[0];if(rack)room.roomId='end';
 room.map.geometry=[{id:'floor',x:0,y:272,w:1280,h:48,collision:'solid',material:'ground'}];room.map.objects=[{id:'start',kind:'spawn',x:24,y:258,w:10,h:14}];
 room.minecraft={version:1,biome:'forest',hero:{alwaysBig:true,maxHealth:3},creepers:[],sandIds:[],destructibleIds:[],gear:{version:1,loyaltyTrident:equipped,shield:true,stands:rack?[{id:'end-rack',x:128,y:240,loyaltyTrident:true}]:[]}};
 if(shop)room.minecraft.exploration={villagers:[{id:'test-trader',role:'trader',x:42,y:248}]};
 return {doc,pack:projectPack(doc,room.roomId,character,'desktop-input-fixture')};
}
function event(target,type,props={}){const e={type,...props,prevented:false,preventDefault(){this.prevented=true;}};target.dispatchEvent(e);return e;}
function mouse(ui,canvas,type,button=0,props={}){return event(type==='mousedown'||type==='contextmenu'||type==='mouseleave'?canvas:ui.window,type,{button,buttons:type==='mouseup'?0:button===0?1:2,...props});}
async function launch(options){const ui=installSimulatedPlayDom();try{const {doc,pack}=fixture(options),session=await play(pack,doc.rooms,{}, {cleanUi:true,developerMode:false});const canvas=session.screen.querySelector('canvas');ui.frames(3);return {ui,session,canvas,view:()=>canvas.workshopRead(),gear:()=>canvas.workshopRead().minecraft.gear,menu:()=>session.screen.querySelector('.play-pause-menu'),action:id=>session.screen.querySelector('[data-menu-action="'+id+'"]'),dispose(){session.close();ui.restore();}};}catch(e){ui.restore();throw e;}}

test('canvas mouse throw/guard use real mouse down/up and chord events, with one throw per press',async()=>{
 const f=await launch();try{const {ui,canvas,gear}=f;
  assert.equal(mouse(ui,canvas,'mousedown').prevented,true);ui.frames(2);assert(gear().trident);assert.equal(canvas.dataset.inputMode,'mouse');ui.frames(180);assert.equal(gear().trident,null,'a held left button does not auto-fire after Loyalty returns');
  mouse(ui,canvas,'mouseup');ui.frames(2);mouse(ui,canvas,'mousedown',2);ui.frames(2);assert(gear().guard.active);
  mouse(ui,canvas,'mousedown',0,{buttons:3});assert.equal(canvas.dataset.inputMode,'mouse');mouse(ui,canvas,'mouseup',0,{buttons:2});ui.frames(2);assert.equal(gear().guard.reason,'throw','left throw preserves the existing rule that attacking lowers guard');
  mouse(ui,canvas,'mouseup',2);ui.frames(2);assert.equal(gear().guard.active,false);assert.equal(f.view().p.h,28,'input never changes always-big Mario');
 }finally{f.dispose();}
});

test('quick mouse click survives until the next simulation tick; outside release/cancel/leave cannot stick',async()=>{
 const f=await launch();try{const {ui,canvas,gear}=f;
  mouse(ui,canvas,'mousedown');mouse(ui,canvas,'mouseup');ui.frames(2);assert(gear().trident,'a complete click between RAFs is preserved');ui.frames(150);
  for(const release of ['outside-up','mousemove','mouseleave','pointercancel','lostpointercapture']){
   ui.frames(35);mouse(ui,canvas,'mousedown',2);ui.frames(2);assert(gear().guard.active,release+' raises');
   if(release==='outside-up')mouse(ui,canvas,'mouseup',2,{target:ui.document.body});else if(release==='mousemove')event(ui.window,'mousemove',{buttons:0});else event(canvas,release,{pointerType:'mouse',pointerId:1});ui.frames(2);assert.equal(gear().guard.active,false,release+' releases');mouse(ui,canvas,'mouseup',2);
  }
 }finally{f.dispose();}
});

test('mouse gameplay never consumes menus, non-canvas clicks, or context menus outside active play',async()=>{
 const f=await launch();try{const {ui,canvas,gear}=f,button=f.action('sound');
  assert.equal(event(button,'mousedown',{button:0}).prevented,false);button.click();ui.frames(2);assert.equal(gear().trident,null);
  assert.equal(event(ui.document.body,'contextmenu',{button:2}).prevented,false);assert.equal(event(button,'contextmenu',{button:2}).prevented,false);assert.equal(mouse(ui,canvas,'contextmenu',2).prevented,true);
  ui.key('KeyP');ui.release('KeyP');assert.equal(f.menu().hidden,false);assert.equal(mouse(ui,canvas,'mousedown').prevented,false);assert.equal(mouse(ui,canvas,'contextmenu',2).prevented,false);mouse(ui,canvas,'mouseup');f.action('resume').click();ui.frames(3);assert.equal(gear().trident,null,'menu/paused clicks do not queue a shot');
  const input=ui.document.createElement('input');f.session.screen.append(input);input.focus();ui.key('KeyK');ui.frames(2);assert.equal(gear().trident,null,'typing into UI fields does not attack');ui.release('KeyK');
 }finally{f.dispose();}
});

test('keyboard, mouse and controller remain unarmed until the rack grants the real trident entitlement',async()=>{
 const f=await launch({equipped:false,rack:true});try{const {ui,canvas,gear}=f,pad=controller();ui.pads.push(pad);ui.frames(3);
  ui.key('KeyK');mouse(ui,canvas,'mousedown');pad.buttons[2].pressed=true;ui.frames(10);assert.equal(gear().loyaltyTrident,false);assert.equal(gear().primary,null);assert.equal(gear().trident,null);assert.equal(gear().projectiles.length,0);assert.doesNotMatch(f.session.screen.querySelector('.play-input-prompt').textContent,/挥剑|左键\/K|投三叉戟/);
  ui.key('ArrowRight');for(let n=0;n<90&&!gear().loyaltyTrident;n++)ui.frames(1);ui.release('ArrowRight');assert.equal(gear().loyaltyTrident,true,'ordinary movement collected the actual rack');assert.equal(gear().trident,null,'holding throw before collection does not queue an automatic attack');assert.equal(f.view().p.h,28);
  ui.release('KeyK');mouse(ui,canvas,'mouseup');pad.buttons[2].pressed=false;ui.frames(3);mouse(ui,canvas,'mousedown');ui.frames(2);assert(gear().trident);assert.doesNotMatch(f.session.screen.querySelector('.play-input-prompt').textContent,/挥剑（宝箱升级三叉戟）/);
 }finally{f.dispose();}
});

test('standard gamepad combat maps face buttons and analog shoulders without legacy echo/run side effects',()=>{
 const pad=controller();let context='minecraft';const read=createGamepadInput(()=>[pad],()=> 'auto',{context:()=>context});read();
 for(const [index,key]of [[2,'attack'],[5,'attack'],[7,'attack'],[3,'shield'],[4,'shield'],[6,'shield']]){
  pad.buttons[index]={pressed:false,value:.75};let gp=read();assert.equal(gp[key],true,String(index));assert.equal(gp[key+'Pressed'],true);assert.equal(gp.run,false);assert.equal(gp.clearHolding,false);assert.equal(gp.dismount,false);assert.equal(gp.activity,true);gp=read(800);assert.equal(gp[key+'Pressed'],false);assert.equal(gp.activity,false,'held action is not new activity');assert.equal(gp.clearPressed,false);read.suspend();assert.equal(read()[key],false,'suspend suppresses held '+index);pad.buttons[index].value=0;read();
 }
 pad.buttons[4].pressed=true;assert.equal(read().shield,true);context='echo';assert.equal(read(1000).clearHolding,false,'held Minecraft guard cannot clear echo on room change');pad.buttons[4].pressed=false;read(1001);pad.buttons[4].pressed=true;read(1002);assert.equal(read(1602).clearPressed,true);
});

test('standard Gamepad API drives movement, deadzone, jump, run, throw, guard and pause in the actual player',async()=>{
 const f=await launch();try{const {ui,view,gear}=f,pad=controller();ui.pads.push(pad);ui.frames(3);const x=view().p.x;
  pad.axes[0]=.30;ui.frames(12);assert.equal(view().p.x,x,'stick drift stays inside deadzone');pad.axes[0]=.8;pad.buttons[1].pressed=true;ui.frames(32);assert(view().p.x>x+20);assert.equal(gear().trident,null,'run does not throw');pad.buttons[0].pressed=true;ui.frames(2);assert(view().p.vy<0);pad.buttons[0].pressed=false;pad.buttons[1].pressed=false;pad.axes[0]=0;ui.frames(50);
  pad.buttons[7]={pressed:false,value:.9};ui.frames(2);assert(gear().trident);pad.buttons[7].value=0;ui.frames(150);pad.buttons[6].value=.9;ui.frames(2);assert(gear().guard.active);pad.buttons[6].value=0;ui.frames(2);assert.equal(gear().guard.active,false);
  pad.buttons[9].pressed=true;ui.frames(2);assert.equal(f.menu().hidden,false);const tick=view().tick;ui.frames(15);assert.equal(view().tick,tick);pad.buttons[9].pressed=false;ui.frames(2);pad.buttons[9].pressed=true;ui.frames(2);assert.equal(f.menu().hidden,true);pad.buttons[9].pressed=false;
 }finally{f.dispose();}
});

test('mixed inputs use freshest non-neutral direction, fall back when released, and do not steal prompts every frame',async()=>{
 const f=await launch();try{const {ui,canvas,view}=f,pad=controller();ui.pads.push(pad);ui.frames(3);assert.equal(canvas.dataset.inputMode,'keyboard','neutral connect does not steal prompts');
  pad.axes[0]=-.8;ui.frames(2);assert.equal(canvas.dataset.inputMode,'controller');ui.key('KeyD');ui.frames(18);const right=view().p.x;assert(right>24,'new keyboard right overrides held controller left instead of cancelling it');assert.equal(canvas.dataset.inputMode,'keyboard','held pad cannot take mode back');
  mouse(ui,canvas,'mousedown',2);ui.frames(2);assert.equal(canvas.dataset.inputMode,'mouse');mouse(ui,canvas,'mouseup',2);ui.frames(25);assert(view().p.x>right,'mouse activity does not steal keyboard movement');assert.equal(canvas.dataset.inputMode,'mouse');
  ui.release('KeyD');ui.frames(25);assert(view().p.vx<0,'releasing keyboard falls back to still-held controller');assert.equal(canvas.dataset.inputMode,'mouse','release-only events do not flip prompts');pad.axes[0]=0;ui.frames(2);pad.axes[0]=.8;ui.frames(2);assert.equal(canvas.dataset.inputMode,'controller');ui.key('KeyA');ui.frames(18);assert(view().p.vx<0);ui.release('KeyA');
 }finally{f.dispose();}
});

test('pause, blur, hidden tab, restart and disconnect release held input without replaying throw or guard',async()=>{
 const f=await launch();try{const {ui,canvas,gear}=f,pad=controller();ui.pads.push(pad);ui.frames(3);
  for(const reason of ['pause','blur','hidden','disconnect','restart']){
   ui.frames(35);mouse(ui,canvas,'mousedown',2);ui.key('KeyL');pad.buttons[6].pressed=true;ui.frames(2);assert(gear().guard.active,reason+' begins held');
   if(reason==='pause'){ui.key('KeyP');ui.release('KeyP');}else if(reason==='blur')event(ui.window,'blur');else if(reason==='hidden'){ui.document.hidden=true;event(ui.document,'visibilitychange');}else if(reason==='disconnect'){ui.pads.length=0;ui.frames(2);}else f.action('restart').click();
   ui.document.hidden=false;if(!f.menu().hidden)f.action('resume').click();ui.key('KeyL',true);ui.frames(3);assert.equal(gear().guard.active,false,reason+' does not restore held shield');assert.equal(gear().trident,null);mouse(ui,canvas,'mouseup',2);ui.release('KeyL');pad.buttons[6].pressed=false;if(!ui.pads.length)ui.pads.push(pad);ui.frames(3);
  }
  // A click queued before a pause must not become a throw after resume.
  mouse(ui,canvas,'mousedown');ui.key('KeyP');ui.release('KeyP');mouse(ui,canvas,'mouseup');f.action('resume').click();ui.frames(3);assert.equal(gear().trident,null);
  // Reconnected controllers arrive neutral until every held command is released.
  ui.pads.length=0;ui.frames(2);f.action('resume').click();pad.buttons[7].pressed=true;ui.pads.push(pad);ui.frames(3);assert.equal(gear().trident,null);pad.buttons[7].pressed=false;ui.frames(2);pad.buttons[7].pressed=true;ui.frames(2);assert(gear().trident);
 }finally{f.dispose();}
});

test('closed sessions remove mouse listeners and stale clicks cannot affect a later session',async()=>{
 const f=await launch();try{const {ui,canvas}=f;mouse(ui,canvas,'mousedown',2);f.session.close();for(const type of ['pointerdown','mousedown','mouseleave','pointercancel','lostpointercapture','contextmenu'])assert.equal(canvas.listeners.get(type)?.length,0,type);for(const type of ['mouseup','mousemove','blur'])assert.equal(ui.window.listeners.get(type)?.length,0,type);assert.equal(mouse(ui,canvas,'contextmenu',2).prevented,false);}finally{f.dispose();}
});

test('direction arbitration is independent per axis and simultaneous opposites on one source stay neutral',()=>{
 const d=createDirectionalInput();d.update('keyboard',{x:1,y:-1});d.update('controller',{x:-1});assert.deepEqual(d.read(),{x:-1,y:-1});d.update('keyboard',{x:1,y:-1},true);assert.deepEqual(d.read(),{x:1,y:-1});d.update('keyboard',{});assert.deepEqual(d.read(),{x:-1,y:0});d.update('touch',{y:1});assert.deepEqual(d.read(),{x:-1,y:1});d.clear();assert.deepEqual(d.read(),{x:0,y:0});
});


test('mouse adapter preserves the other held button across chord releases',()=>{
 const ui=installSimulatedPlayDom();let input;try{const canvas=ui.document.createElement('canvas');input=createCanvasMouseInput(canvas);mouse(ui,canvas,'mousedown',2);mouse(ui,canvas,'mousedown',0,{buttons:3});assert.deepEqual(input.read(),{attack:true,shield:true});mouse(ui,canvas,'mouseup',0,{buttons:2});input.consume();assert.deepEqual(input.read(),{attack:false,shield:true});mouse(ui,canvas,'mouseup',2);assert.deepEqual(input.read(),{attack:false,shield:false});}finally{input?.destroy();ui.restore();}
});


test('canvas touch/pen compatibility mouse events do not masquerade as gameplay mouse input',()=>{
 const ui=installSimulatedPlayDom();let input;try{const canvas=ui.document.createElement('canvas');input=createCanvasMouseInput(canvas);for(const pointerType of ['touch','pen']){event(canvas,'pointerdown',{pointerType});mouse(ui,canvas,'mousedown');assert.deepEqual(input.read(),{attack:false,shield:false});mouse(ui,canvas,'mouseup');}event(canvas,'pointerdown',{pointerType:'mouse'});mouse(ui,canvas,'mousedown');assert.equal(input.read().attack,true);mouse(ui,canvas,'mouseup');input.consume();mouse(ui,canvas,'mousedown',0,{sourceCapabilities:{firesTouchEvents:true}});assert.equal(input.read().attack,false);}finally{input?.destroy();ui.restore();}
});


test('actual offline export embeds the mouse adapter and all responsive-camera dependencies with matching cover controls',async()=>{
 const {doc,pack}=fixture();const html=await offlineFile(pack,doc.rooms,path=>readFileSync(new URL('../atlas/'+path.replace(/^\.\//,''),import.meta.url),'utf8'),async()=>new Uint8Array([1,2,3]),()=>{},{cleanUi:true});const checked=inspectOfflineHtml(html);assert(checked.modules.has('workshop/editor-play-input.mjs'));assert.match(checked.modules.get('workshop/editor-play.mjs'),/createCanvasMouseInput/);assert.match(checked.modules.get('workshop/editor-camera.mjs'),/minecraftDisplayCamera/);assert.match(html,/实际持有三叉戟后：游戏画面左键 \/ K/);assert.match(html,/实际持有盾牌后：按住游戏画面右键 \/ L/);assert.doesNotMatch(html,/开局挥剑|宝箱自动升级/);assert.match(html,/标准手柄战斗/);assert.doesNotMatch(html,/<dt>加速 \/ 火球<\/dt>/);
});

for(const source of ['keyboard','mouse','gamepad'])test(source+' cannot attack before the chest grants a real trident',async()=>{const f=await launch({equipped:false});try{const {ui,canvas,gear}=f,pad=controller();ui.pads.push(pad);ui.frames(3);ui.key('ShiftLeft');ui.frames(30);ui.release('ShiftLeft');assert.equal(gear().sword,null);const attack=held=>{if(source==='keyboard')held?ui.key('KeyK'):ui.release('KeyK');else if(source==='mouse')mouse(ui,canvas,held?'mousedown':'mouseup');else pad.buttons[7].pressed=held;};attack(true);ui.frames(4);assert.equal(gear().primary,null);assert.equal(gear().sword,null);assert.equal(gear().projectiles.length,0);ui.frames(60);assert.equal(gear().sword,null);attack(false);ui.frames(2);attack(true);ui.frames(4);assert.equal(gear().sword,null);assert.equal(gear().bow,false);assert.equal(gear().arrows,0);attack(false);}finally{f.dispose();}});

test('R11 actual shop DOM keyboard/mouse/gamepad stays modal and opening never buys',async()=>{
 const f=await launch({shop:true});try{const {ui,session,view,canvas}=f,pad=controller();ui.pads.push(pad);ui.frames(3);const before=view();ui.key('KeyE');ui.frames(3);assert.equal(view().minecraft.shop.open,true);assert.equal(view().coins,before.coins);assert.equal(view().minecraft.shop.flash,null);const frozen=view();ui.key('ArrowRight');ui.frames(12);assert.equal(view().p.x,frozen.p.x);assert.equal(view().tick,frozen.tick);assert.equal(mouse(ui,canvas,'mousedown').prevented,false);mouse(ui,canvas,'mouseup');ui.release('KeyE');ui.key('KeyE');ui.frames(2);ui.release('KeyE');assert.equal(view().minecraft.shop.flash,'full');assert.equal(view().coins,before.coins);session.screen.querySelectorAll('.shop-slot')[1].click();ui.frames(2);assert.equal(view().minecraft.shop.selected,1);assert.equal(view().minecraft.shop.flash,'full','slot selection is not a purchase');pad.buttons[0].pressed=true;ui.frames(2);assert.equal(view().minecraft.shop.flash,'poor');pad.buttons[0].pressed=false;ui.frames(2);pad.buttons[1].pressed=true;ui.frames(2);assert.equal(view().minecraft.shop.open,false);assert.equal(view().minecraft.gear.trident,null);ui.frames(12);assert.equal(view().p.x,frozen.p.x,'held direction on closing needs release');ui.release('ArrowRight');
 }finally{f.dispose();}
});
