import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createClownCars,validateClownCars,NPC_SPIKE_PANIC_DEFAULTS} from '../atlas/editor-clown-cars.mjs';

const carSpec=overrides=>({id:'car',x:96,y:80,w:32,h:28,bobPixels:0,...overrides});
const room=(cars=[carSpec()])=>({roomId:'fixture',map:{width:400,height:240,geometry:[],objects:[]},contraptions:{version:1,cars}});
const player=overrides=>({x:160,y:200,w:10,h:14,vx:0,vy:0,grounded:false,power:0,...overrides});
const enemy=overrides=>({id:'goomba',type:'goomba',x:104,y:64,w:16,h:16,vx:0,vy:2,grounded:false,dead:false,...overrides});
const fixture=(overrides={})=>{const events=[],r=room([carSpec(overrides)]),m=createClownCars(r,{emit:(type,data)=>events.push({type,...data})});return {m,r,events};};
const view=m=>m.view().cars[0];
function board(m,p=player({x:107,y:66,vy:2})){m.sync({player:p,enemies:[],geometry:[]});assert(m.ownsPlayer());return p;}

test('absent or empty opt-in leaves native rooms alone; malformed tuning and identity reject',()=>{
 assert.equal(createClownCars({map:{width:400,height:240}}),null);assert.equal(createClownCars(room([])),null);
 for(const q of [{id:'bad id'},{x:-1},{x:390},{y:240},{bobPixels:9},{npcMaxSpeed:0},{drag:2},{boardingTolerance:9},{secretFinish:true}])assert.throws(()=>validateClownCars(room([carSpec(q)])));
 assert.throws(()=>validateClownCars(room([carSpec(),carSpec()])));
 const r=room();r.map.objects.push({id:'car'});assert.throws(()=>validateClownCars(r));
 const shared=room();shared.contraptions.tracks=[{id:'car'}];assert.throws(()=>validateClownCars(shared));
});

test('distant or rising Goomba never enters; actual descending top contact captures a live native enemy',()=>{
 const {m,events}=fixture(),p=player(),far=enemy({x:230});m.step({tick:1,player:p,enemies:[far],geometry:[]});assert.equal(view(m).occupancy,'empty');
 const rising=enemy({vy:-2});m.step({tick:2,player:p,enemies:[rising],geometry:[]});assert.equal(view(m).occupancy,'empty');
 const e=enemy({y:58,vy:3});m.step({tick:3,player:p,enemies:[e],geometry:[]});assert.equal(m.ownsActor(e),false);
 e.y+=6;m.sync({player:p,enemies:[e],geometry:[]});assert.equal(view(m).occupancy,'npc');assert.equal(m.ownsActor(e),true);assert.equal(e.dead,false);assert.equal(e.x,104);assert.equal(e.y,68);assert.equal(e.clownCarId,'car');assert.equal(events.filter(e=>e.event==='capture-NPC').length,1);
 m.sync({player:p,enemies:[e]});assert.equal(events.filter(e=>e.event==='capture-NPC').length,1);
});

test('holding a Goomba above the rim and falling past another platform do not capture it',()=>{
 const {m}=fixture(),held=enemy({clawHeldBy:'claw'});m.sync({player:player(),enemies:[held],geometry:[]});assert.equal(view(m).occupancy,'empty');
 delete held.clawHeldBy;m.sync({enemies:[held],isHeld:actor=>actor===held});assert.equal(view(m).occupancy,'empty');
 m.sync({enemies:[held],isHeld:()=>false});assert.equal(view(m).occupancy,'npc');m.reset();
 const e=enemy({y:20,vy:40});m.step({tick:1,player:player(),enemies:[e],geometry:[]});e.y=64;
 m.sync({enemies:[e],geometry:[{id:'intervening-floor',x:90,y:50,w:50,h:8,collision:'solid'}]});assert.equal(view(m).occupancy,'empty');
});

test('NPC chase stalls on upper solid platform until player leads it to real downward exit',()=>{
 const {m}=fixture({x:96,y:100,npcAcceleration:.1,npcMaxSpeed:1.5}),e=enemy({y:84}),p=player({x:104,y:200});
 const geometry=[{id:'upper',x:0,y:128,w:176,h:16,collision:'solid'},{id:'floor',x:0,y:224,w:400,h:16,collision:'solid'}],oneWayWalls=[{id:'down-left',x:176,y:112,w:32,h:32,direction:'down'},{id:'down-right',x:208,y:112,w:32,h:32,direction:'down'}];
 m.step({tick:1,player:p,enemies:[e],geometry,oneWayWalls});assert.equal(view(m).occupancy,'npc');
 for(let tick=2;tick<=50;tick++)m.step({tick,player:p,enemies:[e],geometry,oneWayWalls});assert.equal(view(m).y,100);assert(view(m).x<176,'player position determines the exit');
 p.x=220;for(let tick=51;tick<=170;tick++)m.step({tick,player:p,enemies:[e],geometry,oneWayWalls});
 assert(view(m).x>=176);assert(view(m).y>144,'car passed physically downward through both DOWN walls');assert(view(m).y+view(m).h<=224);assert.equal(e.y,view(m).y-12);assert.equal(e.dead,false);
});

test('ordinary enemy death vacates without deleting or teleporting its delivered car',()=>{
 const {m,events}=fixture(),p=player({x:220}),e=enemy();m.step({tick:1,player:p,enemies:[e],geometry:[]});
 for(let tick=2;tick<=30;tick++)m.step({tick,player:p,enemies:[e],geometry:[]});const before=view(m);e.dead=true;m.sync({player:p,enemies:[e]});
 assert.equal(view(m).occupancy,'empty');assert.equal(view(m).x,before.x);assert.equal(view(m).y,before.y);assert.equal(m.ownsActor(e),false);assert.equal(e.clownCarId,undefined);assert.equal(e.vehicleId,undefined);assert.equal(m.view().cars.length,1);assert.equal(events.filter(e=>e.event==='vacancy').length,1);
});

test('Mario boards only descending into empty top opening, never proximity below or occupied vehicle',()=>{
 const {m}=fixture(),p=player({x:106,y:100,vy:1});m.step({tick:1,player:p,enemies:[],geometry:[]});assert.equal(m.ownsPlayer(),false);
 p.y=66;p.vy=-1;m.step({tick:2,player:p});assert.equal(m.ownsPlayer(),false);
 p.y=55;p.vy=2;m.step({tick:3,player:p});p.y=66;m.sync({player:p});assert.equal(m.ownsPlayer(),true);assert.equal(p.y,view(m).y-12);
 const other=fixture().m,e=enemy(),q=player({x:106,y:66,vy:2});other.sync({player:q,enemies:[e]});assert.equal(view(other).occupancy,'npc');assert.equal(other.ownsPlayer(),false);
});

test('steering accelerates, releases brake, and ejects at current pose into ordinary jump motion',()=>{
 const {m,events}=fixture(),p=board(m);let tick=1;
 for(;tick<=20;tick++)m.step({tick,player:p,enemies:[],geometry:[],input:{x:1,up:true}});
 const moving=view(m);assert(moving.x>96);assert(moving.y<80);assert(moving.vx>0&&moving.vy<0);assert.equal(p.x,moving.x+(moving.w-p.w)/2);assert.equal(p.y,moving.y-12);
 m.step({tick:tick++,input:{}});assert(view(m).vx<moving.vx);assert(view(m).vy>moving.vy);const seated={x:p.x,y:p.y,vx:p.vx,vy:p.vy};
 m.step({tick:tick++,input:{jumpPressed:true}});assert.equal(m.ownsPlayer(),false);assert.equal(p.x,seated.x);assert.equal(p.y,seated.y);assert.equal(p.vx,seated.vx);assert(p.vy<seated.vy-4);assert.equal(p.grounded,false);assert.equal(p.clownCarId,undefined);assert.equal(events.filter(e=>e.event==='eject').length,1);
});

test('explicit goal, hurt, and manual disembark preserve both real poses and are idempotent',()=>{
 for(const reason of ['goal','hurt','manual']){
  const {m,events}=fixture(),p=board(m);for(let tick=1;tick<=12;tick++)m.step({tick,player:p,input:{x:1,down:true}});
  // A native goal or hurt handler may adjust Mario before it releases ownership.
  p.x+=1;p.y-=2;if(reason==='hurt')p.vy=-3.25;
  const beforePlayer={x:p.x,y:p.y,w:p.w,h:p.h,vx:p.vx,vy:p.vy},beforeCar=view(m),initialEvents=events.length;
  assert.equal(m.disembark(p,{reason,jump:false}),true);assert.equal(m.ownsPlayer(),false);assert.equal(p.vehicleId,undefined);assert.equal(p.clownCarId,undefined);
  assert.deepEqual({x:p.x,y:p.y,w:p.w,h:p.h,vx:p.vx,vy:p.vy},beforePlayer);assert.equal(view(m).x,beforeCar.x);assert.equal(view(m).y,beforeCar.y);assert.equal(view(m).vx,beforeCar.vx);assert.equal(view(m).vy,beforeCar.vy);assert.equal(view(m).occupancy,'empty');
  assert.equal(m.disembark(p,{reason,jump:false}),false);m.sync({player:p});assert.equal(m.ownsPlayer(),false);assert.equal(events.length,initialEvents+1);assert.equal(events.at(-1).reason,reason);
 }
 const {m}=fixture(),p=board(m),before=p.vy;assert.equal(m.disembark(p,{reason:'manual',jump:true}),true);assert(p.vy<before-4);assert.equal(m.disembark(player(),{reason:'manual'}),false);
});

test('swept car and protruding rider collide with ceiling and wall, including high speed',()=>{
 const {m}=fixture({playerAcceleration:1,playerMaxSpeed:8}),p=board(m);
 const geometry=[{id:'wall',x:160,y:0,w:8,h:240,collision:'solid'},{id:'ceiling',x:0,y:32,w:400,h:16,collision:'solid'}];
 for(let tick=1;tick<=30;tick++)m.step({tick,player:p,enemies:[],geometry,input:{x:1,up:true}});
 assert.equal(view(m).x+view(m).w,160);assert.equal(p.y,48);assert.equal(view(m).vx,0);assert.equal(view(m).vy,0);assert.deepEqual(m.contactBody(p),view(m).contactBody);assert.equal(view(m).contactBody.y,48);assert.equal(view(m).contactBody.h,40);
});

test('DOWN wall allows descending flight and blocks return; native one-way platform stops falling but allows rising',()=>{
 const {m}=fixture({x:96,y:60,playerAcceleration:1,playerMaxSpeed:8}),p=board(m,player({x:107,y:46,vy:2})),wall={id:'down-wall',x:80,y:110,w:80,h:16,direction:'down'};
 for(let tick=1;tick<=15;tick++)m.step({tick,player:p,enemies:[],geometry:[],oneWayWalls:[wall],input:{down:true}});assert(view(m).y>126);
 for(let tick=16;tick<=50;tick++)m.step({tick,input:{up:true}});assert.equal(p.y,126,'passenger cannot rise through forbidden side');
 const q=fixture({x:96,y:60,playerAcceleration:1,playerMaxSpeed:8}),rider=board(q.m,player({x:107,y:46,vy:2})),platform={id:'platform',x:80,y:110,w:80,h:8,collision:'oneway'};
 for(let tick=1;tick<=15;tick++)q.m.step({tick,player:rider,enemies:[],geometry:[platform],input:{down:true}});assert.equal(view(q.m).y+28,110);
 for(let tick=16;tick<=30;tick++)q.m.step({tick,input:{up:true}});assert(view(q.m).y<60);
});

test('resize keeps seating, death releases, repeated tick is idempotent, and reset restores authored empty vehicle',()=>{
 const {m,events}=fixture(),p=board(m);p.power=1;p.h=28;m.step({tick:1,player:p,enemies:[],geometry:[],input:{x:1}});assert.equal(p.y,view(m).y-12);const before=m.view();m.step({tick:1,input:{x:-1}});assert.deepEqual(m.view(),before);
 p.dying=true;p.vy=-5.1;m.sync({player:p});assert.equal(m.ownsPlayer(),false);assert.equal(p.vy,-5.1);assert.equal(events.filter(e=>e.event==='vacancy').length,1);
 m.reset();assert.equal(view(m).occupancy,'empty');assert.equal(view(m).x,96);assert.equal(view(m).y,80);assert.equal(view(m).vx,0);assert.equal(p.clownCarId,undefined);
 const fresh=board(m);m.step({tick:1,player:fresh,input:{x:1}});assert(view(m).x>96,'reset clears repeated-tick guard');
});

test('idle bob is local and bounded; leaving or reaching any place never changes rewards or goal',()=>{
 const {m}=fixture({bobPixels:2}),p=player({coins:7,lives:3,score:200,completed:false});
 for(let tick=1;tick<=240;tick++){m.step({tick,player:p,enemies:[],geometry:[]});assert.equal(view(m).x,96);assert(Math.abs(view(m).y-80)<=2+1e-9);}
 assert.equal(p.coins,7);assert.equal(p.lives,3);assert.equal(p.score,200);assert.equal(p.completed,false);assert.equal(m.contactBody(),null);
});

test('NPC spike panic is explicit opt-in with validated local tuning and no old-view expansion',()=>{
 const plain=fixture();assert.equal(Object.hasOwn(view(plain.m),'npcSpikePanic'),false);assert.equal(Object.hasOwn(view(plain.m),'npcPanic'),false);
 const opted=fixture({npcSpikePanic:{}});assert.deepEqual(view(opted.m).npcSpikePanic,NPC_SPIKE_PANIC_DEFAULTS);assert.equal(view(opted.m).npcPanic.active,false);
 for(const npcSpikePanic of [null,true,[],{acceleration:0},{acceleration:3},{maxSpeed:0},{maxSpeed:9},{durationFrames:0},{durationFrames:1.5},{horizontalDrag:-1},{unexpected:true}])assert.throws(()=>validateClownCars(room([carSpec({npcSpikePanic})])));
 const e=enemy(),p=player({x:320});plain.m.step({tick:1,player:p,enemies:[e],geometry:[{id:'spike',x:128,y:40,w:16,h:160,collision:'solid',spikeTrap:true}]});assert(view(plain.m).vy>0);assert.equal(e.dead,false);assert.equal(plain.events.some(q=>q.event.includes('panic')),false);
});

test('NPC cup sweeps into a thin real Spike Trap, accelerates upward alive, and stops on a solid ceiling',()=>{
 const {m,events}=fixture({y:100,npcAcceleration:1,npcMaxSpeed:8,npcSpikePanic:{acceleration:1,maxSpeed:3,durationFrames:90,horizontalDrag:.5}}),p=player({x:320}),e=enemy({y:84});
 const geometry=[{id:'thin-spike',x:132,y:32,w:1,h:180,collision:'solid',spikeTrap:true},{id:'ceiling',x:0,y:16,w:400,h:16,collision:'solid'}];
 let touched=null,ascending=false;
 for(let tick=1;tick<=40;tick++){
  const before=view(m);m.step({tick,player:p,enemies:[e],geometry});const v=view(m);
  if(!touched&&v.npcPanic.active){touched=v;assert.equal(v.x+v.w,132);assert(v.y>=before.y-1,'swept trigger applies acceleration rather than teleporting');}
  if(touched&&v.y<touched.y)ascending=true;
  assert.equal(e.dead,false);assert.equal(v.occupancy,'npc');assert.equal(e.y,v.y-12);assert(v.vy>=-3);
 }
 assert(touched&&ascending);assert.equal(view(m).y,44);assert.equal(view(m).vy,0);assert.equal(e.y,32);assert(view(m).npcPanic.active);assert.equal(events.filter(q=>q.event==='npc-spike-panic-start').length,1);
});

test('panic upward flight is constrained by DOWN one-way wall and exact cup edge contact triggers it',()=>{
 const {m,events}=fixture({y:100,npcSpikePanic:{acceleration:1,maxSpeed:3,durationFrames:40}}),p=player({x:300}),e=enemy({y:84});
 const geometry=[{id:'edge-spike',x:128,y:0,w:16,h:220,collision:'solid',spikeTrap:true}],oneWayWalls=[{id:'down-wall',x:80,y:56,w:80,h:8,direction:'down'}];
 m.step({tick:1,player:p,enemies:[e],geometry,oneWayWalls});assert(view(m).npcPanic.active);assert.equal(view(m).y,99);assert.equal(view(m).vy,-1);
 for(let tick=2;tick<=20;tick++)m.step({tick,player:p,enemies:[e],geometry,oneWayWalls});
 assert.equal(view(m).y,76);assert.equal(e.y,64);assert.equal(view(m).vy,0);assert.equal(e.dead,false);assert.equal(events.filter(q=>q.event==='npc-spike-panic-start').length,1);
});

test('only NPC-loaded cups panic; empty, Mario-driven, generic hazard, hidden trap, and passenger-only contacts do not',()=>{
 const spec={npcSpikePanic:{acceleration:1,maxSpeed:3,durationFrames:10}},trap={id:'spike',x:128,y:40,w:16,h:160,collision:'solid',spikeTrap:true};
 const empty=fixture(spec);empty.m.step({tick:1,player:player(),enemies:[],geometry:[trap]});assert.equal(view(empty.m).npcPanic.active,false);
 const mario=fixture(spec),rider=board(mario.m);mario.m.step({tick:1,player:rider,enemies:[],geometry:[trap],input:{x:1,down:true}});assert.equal(view(mario.m).npcPanic.active,false);assert(view(mario.m).vy>0);assert(mario.m.ownsPlayer());
 for(const geometry of [[{...trap,spikeTrap:undefined}],[{...trap,collision:'hazard'}],[{...trap,hidden:true}],[{...trap,x:110,y:64,w:8,h:12}]]){
  const {m}=fixture(spec),e=enemy();m.step({tick:1,player:player(),enemies:[e],geometry});assert.equal(view(m).npcPanic.active,false);assert.equal(e.dead,false);
 }
 // A cup already touching the trap before it receives an enemy still reacts.
 const {m}=fixture(spec);m.step({tick:1,player:player(),enemies:[],geometry:[trap]});m.step({tick:2,enemies:[enemy()]});assert(view(m).npcPanic.active);
});

test('panic duration, repeated tick, expiry contact latch, enemy vacancy, and reset are bounded and idempotent',()=>{
 const spec={npcSpikePanic:{acceleration:1,maxSpeed:3,durationFrames:3}},trap={id:'spike',x:128,y:0,w:16,h:240,collision:'solid',spikeTrap:true},ceiling={id:'ceiling',x:0,y:60,w:400,h:8,collision:'solid'};
 const {m,events}=fixture(spec),p=player({x:300}),e=enemy();m.step({tick:1,player:p,enemies:[e],geometry:[trap,ceiling]});assert.equal(view(m).npcPanic.remainingFrames,2);const once=m.view(),eventCount=events.length;
 m.step({tick:1});assert.deepEqual(m.view(),once);assert.equal(events.length,eventCount);m.sync();assert.equal(view(m).npcPanic.remainingFrames,2);
 m.step({tick:2});m.step({tick:3});assert.equal(view(m).npcPanic.active,false);assert.equal(events.filter(q=>q.event==='npc-spike-panic-stop').length,1);
 for(let tick=4;tick<=8;tick++)m.step({tick});assert.equal(view(m).npcPanic.active,false);assert.equal(events.filter(q=>q.event==='npc-spike-panic-start').length,1,'continuous spike contact cannot extend or restart the timed episode');assert.equal(e.dead,false);
 m.reset();assert.equal(view(m).npcPanic.active,false);assert.deepEqual(view(m).npcPanic.triggerSpikeIds,[]);assert.equal(view(m).y,80);assert.equal(e.vehicleId,undefined);
 const next=enemy();m.step({tick:1,player:p,enemies:[next],geometry:[trap]});assert(view(m).npcPanic.active);next.dead=true;m.sync({enemies:[next]});assert.equal(view(m).npcPanic.active,false);assert.equal(view(m).occupancy,'empty');assert.equal(events.at(-2).reason,'vacancy');
});
