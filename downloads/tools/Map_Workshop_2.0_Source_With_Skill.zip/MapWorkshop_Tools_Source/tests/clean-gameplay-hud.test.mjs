import assert from 'node:assert/strict';
import {test} from 'node:test';
import {readFileSync} from 'node:fs';
import {createCanvas} from '@napi-rs/canvas';
import {blank} from '../atlas/editor-model.mjs';
import {projectPack} from '../atlas/editor-runtime.mjs';
import {drawCastleBattleHud,drawHud} from '../atlas/editor-art.mjs';
const character=JSON.parse(readFileSync(new URL('../atlas/runtime/character.json',import.meta.url)));
function fixture({smm2=true}={}){
 const d=blank('Neutral HUD fixture',640,240),r=d.rooms[0];
 r.map.geometry=[{id:'floor',x:0,y:224,w:640,h:16,collision:'solid',material:'ground'}];
 r.map.objects=[{id:'start',kind:'spawn',x:24,y:210,w:10,h:14}];
 r.playRules={version:1,timeLimit:400,timerFrames:60,viewportWidth:384,viewportHeight:216,cameraAnchor:160};
 if(smm2)r.smm2Mechanics={version:1,art:{palette:'smb1-overworld-source'}};
 return {d,pack:projectPack(d,r.roomId,character,'hud-fixture')};
}

test('battle HUD keeps real HP and cues on transparent pixels, with actual lives separate from coin, key and timer feedback',()=>{
 const old=globalThis.document;globalThis.document={createElement:()=>createCanvas(1,1)};
 try{
  const render=(width,lives,hp,cue,exposed)=>{const canvas=createCanvas(width,216),c=canvas.getContext('2d');drawHud(c,{viewportWidth:width,p:{},lives,coins:12,score:450,timeLeft:290,contraptions:{keys:1},smm2Mechanics:{version:1,pinkCoins:{taken:2,total:4,keyReleased:false}},castle:{battle:{hp,maxHp:6,cue,exposed}}});return c;};
  for(const width of [256,384,512]){
   const warning=render(width,5,6,'FIRE',false),open=render(width,2,3,'OPEN',true),x=Math.round((width-176)/2);
   assert.deepEqual([...warning.getImageData(x-5,36,1,1).data],[0,0,0,0],'former black backdrop is transparent');
   assert.deepEqual([...open.getImageData(x+8,72,1,1).data],[131,232,107,255]);assert.deepEqual([...open.getImageData(x+140,72,1,1).data],[90,37,37,255]);
   assert.notDeepEqual(open.getImageData(23,11,26,9).data,warning.getImageData(23,11,26,9).data,'life glyphs reflect actual lives');
   for(const [xx,yy,w,h]of [[14,24,36,10],[12,40,40,12],[width-48,11,36,9],[width-55,40,43,9]])assert.deepEqual(open.getImageData(xx,yy,w,h).data,warning.getImageData(xx,yy,w,h).data,'coins, keys, timer and pink progress do not change with lives/health');
   const phase2=render(width,2,3,'PHASE2',false);assert.notDeepEqual(phase2.getImageData(x,82,176,7).data,open.getImageData(x,82,176,7).data);const jump=render(width,2,3,'JUMP',false);assert.notDeepEqual(jump.getImageData(x,82,176,7).data,open.getImageData(x,82,176,7).data);
  }
  assert.equal(drawCastleBattleHud(createCanvas(256,216).getContext('2d'),{castle:{}}),false);
 }finally{globalThis.document=old;}
});

test('native Canvas recording keeps the brand in legacy rooms and removes it from SMM2 rooms',async()=>{
 const priorDocument=globalThis.document,priorImage=globalThis.Image;
 try{
  const {nativeWorld}=await import('../render-lantern-course-native-canvas.mjs'),{createPlatformStage}=await import('../atlas/editor-mario-stage.mjs'),{createPlatformMotor}=await import('../atlas/editor-mario-motor.mjs');
  const probe=createCanvas(1,1).getContext('2d'),prototype=Object.getPrototypeOf(probe),original=prototype.fillText,texts=[];prototype.fillText=function(text,...args){texts.push(text);return original.call(this,text,...args);};
  try{for(const smm2 of [false,true]){
   texts.length=0;const {d,pack}=fixture({smm2}),r=d.rooms[0],stage=createPlatformStage({plan:{stage:pack.stages[0],character,rooms:{main:r.map}},motor:createPlatformMotor(),visualRooms:d.rooms,initialState:{lives:3},emit:()=>{}});
   const rendered=nativeWorld(stage.view(),d);assert.equal(rendered.canvas.width,768);assert.equal(texts.includes('在下小Q · 非官方同人'),!smm2);stage.dispose();
  }}finally{prototype.fillText=original;}
 }finally{globalThis.document=priorDocument;globalThis.Image=priorImage;}
});


test('ordinary SMM2 course HUD shows actual spent lives transparently without changing legacy HUD',()=>{
 const priorDocument=globalThis.document;globalThis.document={createElement:()=>createCanvas(1,1)};
 try {
  const render=(lives,smm2)=>{const c=createCanvas(384,216).getContext('2d');drawHud(c,{viewportWidth:384,p:{},lives,coins:15,score:2000,timeLeft:280,...(smm2?{smm2Mechanics:{version:1}}:{})});return c;};
  const first=render(3,true),retry=render(2,true);assert.notDeepEqual(first.getImageData(23,11,26,9).data,retry.getImageData(23,11,26,9).data);
  assert.deepEqual([...retry.getImageData(62,31,1,1).data],[0,0,0,0]);assert([...retry.getImageData(23,11,26,9).data].some((v,i,a)=>i%4===0&&v===31&&a[i+1]===31&&a[i+2]===31&&a[i+3]===255),'life glyph has a one-pixel dark outline for bright backgrounds');
  for(const rect of [[14,24,36,10],[255,11,118,9]])assert.deepEqual(first.getImageData(...rect).data,retry.getImageData(...rect).data);
  assert.deepEqual(render(3,false).getImageData(23,11,26,9).data,render(2,false).getImageData(23,11,26,9).data);
 }finally{globalThis.document=priorDocument;}
});


test('SMM2 coin score and time counters keep a one-pixel outline on bright ceiling tiles with no panel',()=>{
 const priorDocument=globalThis.document;globalThis.document={createElement:()=>createCanvas(1,1)};
 try{
  const canvas=createCanvas(384,216),c=canvas.getContext('2d');c.fillStyle='#dedede';c.fillRect(0,0,384,216);drawHud(c,{viewportWidth:384,p:{},lives:3,coins:8,score:2600,timeLeft:392,smm2Mechanics:{version:1}});
  for(const r of [[23,25,26,9],[255,11,74,9],[347,11,26,9]]){const pixels=c.getImageData(...r).data;assert([...pixels].some((v,i,a)=>i%4===0&&v===31&&a[i+1]===31&&a[i+2]===31&&a[i+3]===255));assert([...pixels].some((v,i,a)=>i%4===0&&v===255&&a[i+1]===255&&a[i+2]===255&&a[i+3]===255));}
  assert.deepEqual([...c.getImageData(230,11,1,1).data],[222,222,222,255]);
 }finally{globalThis.document=priorDocument;}
});
