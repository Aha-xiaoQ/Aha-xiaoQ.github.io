import fs from 'node:fs';import {test} from 'node:test';import assert from 'node:assert/strict';
import {validateMarioModulesRoom,createMarioModules} from '../atlas/editor-mario-modules.mjs';
import {createPlatformMotor} from '../atlas/editor-mario-motor.mjs';
import {createSwitchStudy,stepStudyEnemy} from '../atlas/editor-switch.mjs';
import {blank,parseProject} from '../atlas/editor-model.mjs';import {projectPack} from '../atlas/editor-runtime.mjs';import {createStageCatalog} from '../atlas/runtime/stage-catalog.mjs';
import {createPlatformStage} from '../atlas/editor-mario-stage.mjs';
const character=JSON.parse(fs.readFileSync(new URL('../atlas/runtime/character.json',import.meta.url)));const motionCharacter={capabilities:['jump'],motion:{width:10,height:14,maxHealth:1}};
function room(){const r=blank('Modules test',256,288).rooms[0];r.map.geometry=[{id:'floor',x:0,y:224,w:256,h:64,collision:'solid',material:'ground'},{id:'pipe',x:192,y:176,w:32,h:32,collision:'solid',material:'pipe-side'}];r.map.objects=[{id:'start',kind:'spawn',x:24,y:210,w:10,h:14}];r.marioModules={version:1,itemSources:[],noteBlocks:[],oneWayWalls:[],enemyVariants:{}};return r;}
const source=(item='life')=>({id:'pipe-source',pipeId:'pipe',item,direction:'left',intervalFrames:4,initialDelayFrames:0,maxAlive:1,maxEmissions:3,activationDistance:320,vx:-.75,vy:0});
const note=()=>({id:'note',x:32,y:224,w:16,h:16,playerBounceSpeed:4.8,heldBounceSpeed:6,itemBounceSpeed:6});
function integratedStage(r,extra={}){const d=blank('Integrated modules',256,288);d.rooms=[r];const pack=projectPack(d,r.roomId,character,'integrated-module'),plan=createStageCatalog(pack).plan(pack.stages[0].id,pack.characters[0].id,{allowDraft:true});return createPlatformStage({plan,motor:createPlatformMotor(),visualRooms:[r],emit(){},...extra});}

// Invoke the actual original native item update verbatim. No alternate item
// movement or reward engine is introduced by these tests or by the module.
const nativeSource=fs.readFileSync(new URL('./native-baseline/editor-mario-stage.mjs',import.meta.url),'utf8'),itemStart=nativeSource.indexOf('    for(const item of r.items){'),itemEnd=nativeSource.indexOf('    if(growth||fireGrowth)return;',itemStart),nativeItemBody=nativeSource.slice(itemStart,itemEnd);
assert.ok(itemStart>0&&itemEnd>itemStart);
const nativeItems=new Function('r','p','motor','emit','state',`const bill=false,map={height:state.height||288},weaponNames={};let lives=state.lives||3,score=0,growth=0,fireGrowth=0,invulnerable=0;${nativeItemBody}return {lives,growth,fireGrowth};`);

test('module schema survives qmap/native pack and rejects unknown or incomplete physical records',()=>{
 const r=room();r.marioModules.itemSources=[source()];r.marioModules.noteBlocks=[note()];r.marioModules.oneWayWalls=[{id:'left-wall',x:128,y:0,w:32,h:224,direction:'left'}];r.map.objects.push({id:'plant',kind:'walker',x:160,y:176,w:32,h:48});r.marioModules.enemyVariants.plant={kind:'floor-piranha',size:'giant',winged:true,hopSpeed:5,hopIntervalFrames:24};validateMarioModulesRoom(r);
 const d=blank('Modules persistence',256,288);d.rooms=[r];const imported=parseProject(JSON.stringify(d));assert.deepEqual(imported.rooms[0].marioModules,r.marioModules);const pack=projectPack(imported,r.roomId,character,'module-fixture');createStageCatalog(pack);
 for(const mutate of [r=>r.marioModules.version=2,r=>r.marioModules.noteBlocks[0].id='floor',r=>delete r.marioModules.itemSources[0].vx,r=>r.marioModules.itemSources[0].pipeId='floor',r=>r.marioModules.oneWayWalls[0].direction='right',r=>r.marioModules.enemyVariants.plant.hopIntervalFrames=0,r=>r.marioModules.noteBlocks[0].w=32,r=>r.marioModules.itemSources[0].script='toggle']){const copy=structuredClone(r);mutate(copy);assert.throws(()=>validateMarioModulesRoom(copy));}
});
test('multi-coin value and authored reward limit map only to real native coin and reward objects',()=>{
 const r=room();r.map.objects.push({id:'large-coin',kind:'coin',x:128,y:160,w:32,h:32});r.map.geometry.push({id:'stopper',x:16,y:160,w:16,h:16,collision:'solid',material:'brick',reward:'coin'});r.marioModules.coinValues={'large-coin':10};r.marioModules.rewardLimits={stopper:1};const m=createMarioModules(r);assert.equal(m.coinValue('large-coin'),10);assert.equal(m.coinValue('ordinary-coin'),1);assert.equal(m.rewardLimit('stopper'),1);assert.equal(m.rewardLimit('unmapped-brick'),undefined);assert.deepEqual(m.view().coinValues,{'large-coin':10});
 for(const mutate of [r=>r.marioModules.coinValues={'start':10},r=>r.marioModules.coinValues={'large-coin':0},r=>r.marioModules.coinValues={'large-coin':101},r=>r.marioModules.rewardLimits={floor:1},r=>r.marioModules.rewardLimits={stopper:1.5},r=>r.mechanics={type:'echo-cooperation',version:1}]){const q=structuredClone(r);mutate(q);assert.throws(()=>validateMarioModulesRoom(q));}
});
test('pipe entry and arrival rules reference exact local native targets and preserve destination data',()=>{
 const r=room();r.map.objects.push({id:'return-portal',kind:'portal',x:176,y:208,w:48,h:32,targetRoom:r.roomId,targetSpawn:'start'});r.marioModules.portalDirections={'return-portal':{pipeId:'pipe',direction:'up'}};r.marioModules.arrivalDirections={start:{pipeId:'pipe',direction:'down'}};const m=createMarioModules(r);assert.deepEqual(m.portalRule('return-portal'),{pipeId:'pipe',direction:'up'});assert.deepEqual(m.arrivalRule('start'),{pipeId:'pipe',direction:'down'});assert.equal(m.portalRule('start'),null);assert.equal(m.arrivalRule('return-portal'),null);const changed=m.portalRule('return-portal');changed.direction='down';assert.equal(m.portalRule('return-portal').direction,'up');assert.equal(r.map.objects.find(q=>q.id==='return-portal').targetSpawn,'start');
 for(const mutate of [r=>r.marioModules.portalDirections.start={pipeId:'pipe',direction:'up'},r=>r.marioModules.portalDirections['return-portal'].pipeId='floor',r=>r.marioModules.portalDirections['return-portal'].direction='down',r=>r.marioModules.arrivalDirections['missing']={pipeId:'pipe',direction:'down'},r=>r.marioModules.arrivalDirections.start.script='teleport']){const q=structuredClone(r);mutate(q);assert.throws(()=>validateMarioModulesRoom(q));}
});
test('actual red mouth barrier prevents pipe emission and OFF releases an ordinary native life item',()=>{
 const r=room();r.switchStudy={version:1,initialOn:true,allowBacktracking:true,devices:[{id:'switch',kind:'switch',x:64,y:160,w:16,h:16},{id:'mouth-red',kind:'block',color:'red',x:176,y:176,w:16,h:32}]};r.marioModules.itemSources=[source()];const events=[],m=createMarioModules(r,{emit:(kind,data)=>events.push({kind,data})}),study=createSwitchStudy([r],r.roomId),p={x:24,y:210,w:10,h:14};
 for(let tick=1;tick<30;tick++)assert.equal(m.spawnItems({player:p,items:[],tick,geometry:study.apply(r.roomId,r.map.geometry)}).length,0);assert.equal(m.view().itemSources[0].emitted,0);
 study.headHit(r.roomId,'switch');const items=m.spawnItems({player:p,items:[],tick:30,geometry:study.apply(r.roomId,r.map.geometry)});assert.equal(items.length,1);assert.equal(items[0].kind,'life');assert.equal(items[0].x,178);assert.equal(items[0].y,185);assert.equal(items[0].emerge,undefined);assert.equal(events.filter(e=>e.kind==='mario-module'&&e.data.event==='item-source').length,1);
 for(let tick=31;tick<50;tick++)assert.equal(m.spawnItems({player:p,items,tick,geometry:r.map.geometry}).length,0);items[0].dead=true;assert.equal(m.spawnItems({player:p,items,tick:50,geometry:r.map.geometry}).length,1);m.reset();assert.equal(m.view().itemSources[0].emitted,0);
});
test('a distant source sleeps through early frames and wakes only at its authored approach boundary',()=>{
 const r=room();r.map.width=1536;r.map.geometry.find(q=>q.id==='pipe').x=1400;r.marioModules.itemSources=[source()];const m=createMarioModules(r);for(let tick=1;tick<100;tick++)assert.equal(m.spawnItems({player:{x:24},items:[],tick,geometry:r.map.geometry}).length,0);assert.equal(m.view().itemSources[0].active,false);assert.equal(m.spawnItems({player:{x:1080},items:[],tick:100,geometry:r.map.geometry}).length,1);assert.equal(m.view().itemSources[0].active,true);
});
test('source mouth follows actual current native pipe geometry',()=>{
 const r=room();r.marioModules.itemSources=[source()];const m=createMarioModules(r),geometry=structuredClone(r.map.geometry);Object.assign(geometry.find(q=>q.id==='pipe'),{x:160,y:128});const [item]=m.spawnItems({player:{x:24},items:[],tick:1,geometry});assert.equal(item.x,146);assert.equal(item.y,137);
});
test('a replenishing down pipe supplies native red Koopas and counts live shells against its maximum',()=>{
 const r=room();r.map.geometry.find(q=>q.id==='pipe').y=96;r.marioModules.enemySources=[{id:'koopa-source',pipeId:'pipe',enemy:'koopa',smart:true,direction:'down',intervalFrames:3,initialDelayFrames:0,maxAlive:1,maxEmissions:null,activationDistance:320,vx:-.5,vy:0}];const m=createMarioModules(r),player={x:24},geometry=r.map.geometry;
 const first=m.spawnEnemies({player,enemies:[],tick:1,geometry});assert.equal(first.length,1);const e=first[0];assert.equal(e.type,'koopa');assert.equal(e.y,128);assert.equal(e.homeY,128);assert.equal(e.w,16);assert.equal(e.h,24);assert.equal(e.source.smart,true);assert.equal(e.source.red,true);assert.equal(e.hp,2);e.shell=true;
 for(let tick=2;tick<100;tick++)assert.equal(m.spawnEnemies({player,enemies:first,tick,geometry}).length,0,'the oscillator shell occupies its pipe limit');e.dead=true;const replacement=m.spawnEnemies({player,enemies:first,tick:100,geometry});assert.equal(replacement.length,1);assert.notEqual(replacement[0].id,e.id);assert.equal(replacement[0].shell,undefined);assert.equal(m.view().enemySources[0].emitted,2);m.reset();assert.equal(m.view().enemySources[0].emitted,0);
 for(const mutate of [r=>r.marioModules.enemySources[0].enemy='bowser',r=>r.marioModules.enemySources[0].smart='yes',r=>r.marioModules.enemySources[0].id='pipe-source',r=>r.marioModules.enemySources[0].maxAlive=0]){const q=structuredClone(r);q.marioModules.itemSources=[source()];mutate(q);assert.throws(()=>validateMarioModulesRoom(q));}
});
test('pipe life falls, crosses the note, rebounds through a native one-way bridge and rewards one native life',()=>{
 const r=room();r.map.geometry=[{id:'floor-left',x:0,y:224,w:32,h:64,collision:'solid'},{id:'floor-right',x:48,y:224,w:208,h:64,collision:'solid'},r.map.geometry[1],{id:'bridge',x:0,y:160,w:256,h:8,collision:'oneway'}];r.marioModules.itemSources=[{...source(),maxEmissions:1}];r.marioModules.noteBlocks=[note()];const events=[],m=createMarioModules(r,{emit:(kind,data)=>events.push({kind,data})}),motor=createPlatformMotor(),p={x:16,y:146,w:10,h:14,power:0},items=[],geometry=m.geometry(r.map.geometry);let state={lives:3},bounced=false;
 for(let tick=1;tick<=360;tick++){items.push(...m.spawnItems({player:p,items,tick,geometry}));const before=new Map(items.map(i=>[i,{...i}]));state=nativeItems({items,geometry,effects:[]},p,motor,()=>{},state);for(const item of items){m.afterActor(item,before.get(item),{kind:'item',tick,geometry});bounced||=item.vy< -5;}if(state.lives===4)break;}
 assert.ok(bounced);assert.equal(state.lives,4);assert.equal(items.length,1);assert.equal(items[0].dead,true);assert.ok(events.some(e=>e.kind==='mario-module'&&e.data.event==='note-bounce'));
});
test('note landing produces a real native player ascent, held boost and one contact event',()=>{
 for(const held of [false,true]){const r=room();r.marioModules.noteBlocks=[note()];const events=[],m=createMarioModules(r,{emit:(kind,data)=>events.push({kind,data})}),motor=createPlatformMotor(),p=motor.create(motionCharacter,{x:35,y:176}),g=m.geometry(r.map.geometry);let tick=0,bounced=false,atContact;
  for(;tick<30;tick++){const before={...p};motor.step(p,{jump:held},motionCharacter,{solids:g,width:256});m.afterActor(p,before,{kind:'player',input:{jump:held},tick});if(p.vy<0){bounced=true;atContact={...p};m.afterActor(p,before,{kind:'player',input:{jump:held},tick});break;}}
  assert.ok(bounced);assert.equal(atContact.vy,held?-6:-4.8);assert.equal(p.grounded,false);assert.equal(p.support,null);assert.equal(events.filter(e=>e.kind==='mario-module'&&e.data.event==='note-bounce').length,1);const before={...p};motor.step(p,{jump:held},motionCharacter,{solids:g,width:256});assert.ok(p.y<before.y);assert.equal(p.headHit,null);
 }
});
test('one-way wall blocks rightward native Mario movement and allows his leftward crossing',()=>{
 const r=room();r.marioModules.oneWayWalls=[{id:'wall',x:128,y:0,w:32,h:224,direction:'left'}];const m=createMarioModules(r),motor=createPlatformMotor();
 for(const [x,dir]of [[24,1],[192,-1]]){const p=motor.create(motionCharacter,{x,y:210});for(let tick=0;tick<130;tick++){const before={...p};motor.step(p,{x:dir},motionCharacter,{solids:r.map.geometry.filter(q=>q.id==='floor'),width:256});m.afterActor(p,before,{kind:'player',tick});}if(dir>0){assert.equal(p.x,118);assert.equal(p.vx,0);}else assert.ok(p.x<128);}
});
test('left-arrow wall passes a native star toward Mario and reverses a right-moving native life',()=>{
 const r=room();r.map.geometry=r.map.geometry.filter(q=>q.id==='floor');r.marioModules.oneWayWalls=[{id:'wall',x:128,y:0,w:32,h:224,direction:'left'}];const m=createMarioModules(r),motor=createPlatformMotor(),p={x:0,y:0,w:10,h:14};
 for(const [kind,x,vx]of [['star',192,-.75],['life',96,.75]]){const item={id:kind,kind,x,y:210,w:14,h:14,vx,vy:0,age:0};for(let tick=0;tick<140;tick++){const before={...item};nativeItems({items:[item],geometry:r.map.geometry,effects:[]},p,motor,()=>{},{lives:3});m.afterActor(item,before,{kind:'item',tick});}if(kind==='star')assert.ok(item.x+item.w<128);else{assert.ok(item.x+item.w<=128);assert.ok(item.vx<0);}}
});
test('one-way wall applies the same real directional contact to a native study enemy',()=>{
 const r=room();r.marioModules.oneWayWalls=[{id:'wall',x:128,y:0,w:32,h:224,direction:'left'}];const m=createMarioModules(r),e={id:'chomp',type:'study-chomp',x:80,y:192,w:32,h:32,vx:.7,vy:0,grounded:true,support:'floor'};for(let tick=0;tick<100;tick++){const before={...e};stepStudyEnemy(e,r.map.geometry.filter(q=>q.id==='floor'),256);m.afterActor(e,before,{kind:'enemy',tick});assert.ok(e.x+e.w<=128);}assert.equal(e.dead,undefined);
});
test('giant winged floor plant keeps its foot anchor and hops into actual native solid ceiling collision',()=>{
 const r=room();r.map.objects.push({id:'plant',kind:'walker',x:80,y:200,w:16,h:24});r.map.geometry=[r.map.geometry[0],{id:'ceiling',x:48,y:128,w:96,h:16,collision:'solid'}];r.marioModules.enemyVariants.plant={kind:'floor-piranha',size:'giant',winged:true,hopSpeed:5,hopIntervalFrames:20};const m=createMarioModules(r),e={id:'plant',type:'walker',x:80,y:200,w:16,h:24,vx:-.5,vy:0,grounded:true,support:'floor',studyActivated:true};m.applyEnemyVariant(e);assert.equal(e.y+e.h,224);assert.equal(e.x+e.w/2,88);assert.equal(e.w,32);assert.equal(e.h,48);assert.equal(e.type,'study-piranha');let hopped=false,hitCeiling=false;
 for(let tick=0;tick<160;tick++){hopped||=m.beforeEnemy(e);stepStudyEnemy(e,r.map.geometry,256);assert.ok(e.y>=144);hitCeiling||=e.y===144&&e.vy===0;}assert.ok(hopped);assert.ok(hitCeiling);assert.equal(e.dead,undefined);assert.ok(e.source.winged&&e.source.giant);
});
test('integrated native stage awards a real source 1UP after its note and bridge route',()=>{
 const r=room();r.map.geometry=[{id:'floor-left',x:0,y:224,w:32,h:64,collision:'solid'},{id:'floor-right',x:48,y:224,w:208,h:64,collision:'solid'},r.map.geometry[1],{id:'bridge',x:0,y:160,w:256,h:8,collision:'oneway'}];Object.assign(r.map.objects[0],{x:16,y:146});r.marioModules.itemSources=[{...source(),maxEmissions:1}];r.marioModules.noteBlocks=[note()];const s=integratedStage(r);let bounce=false;
 for(let i=0;i<360&&s.view().lives===3;i++){s.step();bounce||=s.view().items.some(i=>i.kind==='life'&&i.vy< -5);}assert.ok(bounce);assert.equal(s.view().lives,4);assert.equal(s.view().marioModules.itemSources[0].emitted,1);assert.equal(s.view().p.dying,undefined);
});
test('integrated large ten-coin pickup crosses the native 100-coin life threshold once',()=>{
 const r=room();r.map.objects.push({id:'large',kind:'coin',x:24,y:192,w:32,h:32});r.marioModules.coinValues={large:10};const s=integratedStage(r,{initialState:{coins:95,lives:3}});s.step();assert.equal(s.view().coins,5);assert.equal(s.view().lives,4);assert.equal(s.view().score,2000);for(let i=0;i<10;i++)s.step();assert.equal(s.view().coins,5);assert.equal(s.view().lives,4);
});
test('integrated native star contact kills the first pipe Koopa and permits a real replacement',()=>{
 const r=room();Object.assign(r.map.geometry.find(q=>q.id==='pipe'),{x:64,y:64,w:32,h:32,material:'pipe'});Object.assign(r.map.objects[0],{x:80,y:210});r.marioModules.itemSources=[{...source('star'),id:'star-source',direction:'down',vx:0,maxEmissions:1}];r.marioModules.enemySources=[{id:'koopa-source',pipeId:'pipe',enemy:'koopa',smart:true,direction:'down',intervalFrames:5,initialDelayFrames:0,maxAlive:1,maxEmissions:null,activationDistance:320,vx:-.5,vy:0}];const s=integratedStage(r);for(let i=0;i<60;i++)s.step();assert.ok(s.view().p.star>0);const first=s.view().enemies.find(e=>e.moduleSource==='koopa-source');assert.ok(first);
 for(let i=0;i<180&&s.view().marioModules.enemySources[0].emitted<2;i++){s.step({x:-1,run:true});assert.ok(s.view().enemies.filter(e=>e.moduleSource==='koopa-source').length<=1);}assert.ok(s.view().marioModules.enemySources[0].emitted>=2);assert.equal(s.view().lives,3);assert.ok(!s.view().enemies.some(e=>e.id===first.id));
});
test('real native death resets the module source baseline while spending the life',()=>{
 const r=room();r.marioModules.itemSources=[{...source(),maxEmissions:1}];r.map.objects.push({id:'hazard',kind:'hazard',x:24,y:210,w:16,h:14});const s=integratedStage(r);s.step();assert.equal(s.view().p.dying,true);assert.equal(s.view().marioModules.itemSources[0].emitted,1);assert.equal(s.view().lives,2);for(let i=0;i<120&&s.view().p.dying;i++)s.step();assert.equal(s.view().marioModules.itemSources[0].emitted,0);assert.equal(s.view().lives,2);
});
test('opt-out has no controller and native motor behavior remains the frozen baseline',async()=>{
 const r=room(),m=createMarioModules(r);assert.equal(m.coinValue('constructor'),1);assert.equal(m.rewardLimit('constructor'),undefined);assert.equal(m.enemyVariant('constructor'),null);delete r.marioModules;assert.equal(createMarioModules(r),null);
 const baselineText=fs.readFileSync(new URL('./native-baseline/editor-mario-motor.mjs',import.meta.url),'utf8');
 const source=baselineText.replace("'./runtime/platform-motor.mjs'",JSON.stringify(new URL('../atlas/runtime/platform-motor.mjs',import.meta.url).href));
 const {createPlatformMotor:createBaseline}=await import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'));
 for(const profile of [{power:0},{power:1},{power:2},{power:0,hero:'bill'},{power:1,swimming:true}]){
  const old=createBaseline(),current=createPlatformMotor(),spawn={x:24,y:210};
  const a=old.create(motionCharacter,spawn),b=current.create(motionCharacter,spawn);
  Object.assign(a,profile);Object.assign(b,profile);if(profile.power){a.y-=14;b.y-=14;a.h=b.h=28;}
  const solids=[{id:'floor',x:0,y:224,w:256,h:64,collision:'solid'},{id:'wall',x:192,y:144,w:16,h:80,collision:'solid'},{id:'roof',x:64,y:128,w:96,h:16,collision:'solid'},{id:'lift',x:96,y:180,w:48,h:8,collision:'oneway',dx:0,dy:0}];
  let previousJump=false;
  for(let tick=0;tick<720;tick++){
   const lift=solids[3],next=180+Math.sin(tick/31)*12;lift.dy=next-lift.y;lift.y=next;
   const jump=tick%89<22,input={x:Math.floor(tick/120)%2? -1:1,run:tick%180<100,down:tick%71>=58,jump,jumpPressed:jump&&!previousJump};previousJump=jump;
   const world={width:256,solids,swimming:!!profile.swimming};
   assert.deepEqual(current.step(b,{...input},motionCharacter,world),old.step(a,{...input},motionCharacter,world),'events '+JSON.stringify(profile)+' tick '+tick);
   assert.deepEqual(b,a,'body '+JSON.stringify(profile)+' tick '+tick);
  }
 }
});
