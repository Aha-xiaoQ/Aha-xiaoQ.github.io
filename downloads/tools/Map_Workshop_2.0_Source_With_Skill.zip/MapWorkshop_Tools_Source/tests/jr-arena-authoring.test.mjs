import test from 'node:test';
import assert from 'node:assert/strict';
import {History,clone,parseProject} from '../atlas/editor-model.mjs';
import {setJrArenaAudience,updateJrArenaAudience,clearJrArenaAudience,pruneJrArenaAudienceReferences,mountJrArenaAudienceTools} from '../atlas/editor-jr-arena-tools.mjs';
import {arenaAudienceProject} from './fixtures/jr-arena-audience.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';

test('complete/partial JSON authoring is atomic, strict, cloned and round-trips through History',()=>{
 const h=new History(arenaAudienceProject()),room=()=>h.doc.rooms[0],initial=clone(room().smm2Mechanics.arenaAudience);h.change(()=>clearJrArenaAudience(room()));assert(!room().smm2Mechanics.arenaAudience);h.undo();assert.deepEqual(room().smm2Mechanics.arenaAudience,initial);h.redo();
 h.change(()=>setJrArenaAudience(room(),initial));initial.seats[0].x=999;assert.equal(room().smm2Mechanics.arenaAudience.seats[0].x,0);const patch={telegraphFrames:84};h.change(()=>updateJrArenaAudience(room(),patch));patch.telegraphFrames=999;assert.equal(room().smm2Mechanics.arenaAudience.telegraphFrames,84);assert.deepEqual(parseProject(JSON.stringify(h.doc)),h.doc);
 const saved=JSON.stringify(h.doc);for(const patch of [{maxAlive:4},{unknown:true},{seats:[]},{telegraphFrames:40},{version:2}]){assert.throws(()=>h.change(()=>updateJrArenaAudience(room(),patch)));assert.equal(JSON.stringify(h.doc),saved);}
 h.undo();assert.equal(room().smm2Mechanics.arenaAudience.telegraphFrames,72);h.redo();assert.equal(room().smm2Mechanics.arenaAudience.telegraphFrames,84);
});
test('delete cleanup removes dependent spectators and clears the scene only when seats or Jr disappear',()=>{
 const d=arenaAudienceProject(),r=d.rooms[0],before=clone(r);r.map.geometry=r.map.geometry.filter(q=>q.id!=='left-seat-0');pruneJrArenaAudienceReferences(r,before);assert.equal(r.smm2Mechanics.arenaAudience.seats.length,8);assert.deepEqual(parseProject(JSON.stringify(d)),d);
 const remaining=clone(r);r.map.geometry=r.map.geometry.filter(q=>!q.id.includes('seat-'));pruneJrArenaAudienceReferences(r,remaining);assert(!r.smm2Mechanics.arenaAudience);assert.deepEqual(parseProject(JSON.stringify(d)),d);
 const second=arenaAudienceProject(),room=second.rooms[0],prior=clone(room);room.map.objects=room.map.objects.filter(q=>q.id!=='junior');room.smm2Mechanics.bowserJuniors.actors=[];pruneJrArenaAudienceReferences(room,prior);assert(!room.smm2Mechanics.arenaAudience);assert.deepEqual(parseProject(JSON.stringify(second)),second);
});
test('the mounted JSON panel saves/clears through History and rejects malformed or unsafe leaf edits',()=>{
 const ui=installSimulatedPlayDom();try{
  const h=new History(arenaAudienceProject()),parent=ui.document.createElement('aside'),reports=[],room=()=>h.doc.rooms[0];ui.document.body.append(parent);const panel=mountJrArenaAudienceTools({parent,room,change:fn=>h.change(fn),report:q=>reports.push(q)}),get=key=>parent.querySelector('[data-jr-arena-control="'+key+'"]');
  const json=JSON.parse(get('json').value);json.cheerFrames=120;get('json').value=JSON.stringify(json);get('apply').click();assert.equal(room().smm2Mechanics.arenaAudience.cheerFrames,120);const saved=JSON.stringify(h.doc);
  for(const value of ['{bad',JSON.stringify({...json,maxAlive:9}),JSON.stringify({...json,customDamage:true})]){get('json').value=value;get('apply').click();assert.equal(JSON.stringify(h.doc),saved);}assert.equal(reports.length,3);
  get('clear').click();assert(!room().smm2Mechanics.arenaAudience);assert(get('clear').disabled);h.undo();panel.refresh();assert.equal(JSON.parse(get('json').value).cheerFrames,120);assert(!get('clear').disabled);
 }finally{ui.restore();}
});
