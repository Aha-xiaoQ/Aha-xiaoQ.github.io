import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createRequire} from 'node:module';
import {blank} from '../atlas/editor-model.mjs';
import {projectPack} from '../atlas/editor-runtime.mjs';
import {requiredCollectionCapabilities} from '../atlas/editor-collection.mjs';
import {offlineFile} from '../atlas/editor-offline.mjs';
import {background,drawTile,drawObject,drawPlayer,drawScenery,drawHud} from '../atlas/editor-art.mjs';
import {drawSmm2Tile,drawSmm2Actor,drawSmm2PlayerGear,drawSmm2World,drawSmm2PinkCoinHud} from '../atlas/editor-smm2-art.mjs';
import {SMM2_SOURCE_PIXELS} from '../atlas/editor-smm2-source-assets.mjs';
import {makeNativeScenery,drawNativeScenery} from '../atlas/editor-native-scenery.mjs';
import {nativeCamera} from '../atlas/editor-camera.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';

const require=createRequire(import.meta.url);
let createCanvas;try{({createCanvas}=require('@napi-rs/canvas'));}catch{}
const rasterTest=(name,fn)=>test(name,{skip:!createCanvas},fn);
const read=path=>readFileSync(new URL('../atlas/'+path.replace(/^\.\//,''),import.meta.url),'utf8');
const character=JSON.parse(read('./runtime/character.json'));
const canvas=()=>createCanvas(384,240);
const bytes=c=>c.getContext('2d').getImageData(0,0,c.width,c.height).data;
const count=c=>{const data=bytes(c);let total=0;for(let i=3;i<data.length;i+=4)if(data[i]>0)total++;return total;};
function room(){return {roomId:'main',setting:'Castle',map:{width:640,height:448,geometry:[],objects:[]},decorations:[],markers:[],smm2Mechanics:{version:1,art:{palette:'smb1-castle-stone'}}};}
function nativeCanvasDom(){
 const ui=installSimulatedPlayDom(),create=ui.document.createElement;
 ui.document.createElement=tag=>tag==='canvas'?createCanvas(1,1):create(tag);
 return ui;
}

rasterTest('native dispatch uses SMM2 background, ground and actor art without changing its inputs',()=>{
 const r=room(),tile={id:'floor',x:16,y:160,w:112,h:48,material:'ground'},actor={id:'stone',kind:'walker',type:'smm2-thwomp',x:32,y:48,w:24,h:32,smm2Thwomp:{phase:'charge',direction:'right'}},before=JSON.stringify({r,tile,actor});
 const actual=canvas(),expected=canvas();background(actual.getContext('2d'),r,384,240);
 assert.deepEqual([...actual.getContext('2d').getImageData(0,0,1,1).data],[0,0,0,255]);
 actual.getContext('2d').clearRect(0,0,384,240);drawTile(actual.getContext('2d'),tile,r);drawObject(actual.getContext('2d'),actor,12,r);
 drawSmm2Tile(expected.getContext('2d'),tile,r);drawSmm2Actor(expected.getContext('2d'),actor,12,r);
 assert.deepEqual(bytes(actual),bytes(expected));assert.equal(JSON.stringify({r,tile,actor}),before);
});

rasterTest('physical Donut and POW proxy colliders are drawn only by the live component or actor pass',()=>{
 const c=canvas(),r=room(),ctx=c.getContext('2d');
 drawTile(ctx,{id:'donut',x:16,y:32,w:32,h:16,material:'smm2-donut',smm2Terrain:true},r);
 drawTile(ctx,{id:'pow',x:96,y:64,w:16,h:16,material:'smm2-pow',smm2ItemBody:true},r);
 assert.equal(count(c),0,'no rectangular placeholder can fill the real component openings');
});

rasterTest('live platforms recover authored art by sourceId and draw at their actual moving position',()=>{
 const r=room(),q={id:'moving-copy',sourceId:'rail-platform',x:100,y:96,w:48,h:16,material:'platform'},platform={style:'blue',winged:true};
 r.map.geometry=[{id:'rail-platform',x:0,y:0,w:48,h:16,material:'platform',smm2Platform:platform}];
 const actual=canvas(),expected=canvas(),before=JSON.stringify({r,q});drawTile(actual.getContext('2d'),q,r);drawSmm2Actor(expected.getContext('2d'),{...q,smm2Platform:platform},0,r);
 assert.deepEqual(bytes(actual),bytes(expected));assert(count(actual)>0);assert.equal(JSON.stringify({r,q}),before);
 assert.equal(actual.getContext('2d').getImageData(4,4,1,1).data[3],0,'authored home is not drawn');
});

rasterTest('SMM2 rooms retain native authored scenery through the contraptions branch and honor hidden bounds',()=>{
 const ui=nativeCanvasDom();try{
  const r=room(),fence=makeNativeScenery({id:'fence',type:'Fence',repeat:3,x:32,y:160}),cloud=makeNativeScenery({id:'cloud',type:'Cloud1',x:192,y:64}),hidden=makeNativeScenery({id:'hidden',type:'Fence',x:128,y:160,hidden:true});
  r.contraptions={version:1};r.decorations=[fence,cloud,hidden];r.renderBounds={x:16,y:0,w:128,h:240};
  const actual=canvas(),expected=canvas();drawScenery(actual.getContext('2d'),r);drawNativeScenery(expected.getContext('2d'),fence,r);
  assert.deepEqual(bytes(actual),bytes(expected));assert(count(actual)>0);
  const native=canvas(),ordinary={...r};delete ordinary.smm2Mechanics;drawScenery(native.getContext('2d'),ordinary);assert.equal(count(native),0,'the established opt-out contraptions scenery branch is unchanged');
 }finally{ui.restore();}
});

rasterTest('unknown SMM2 markers cannot turn into visible spawn Mario objects',()=>{
 const ui=nativeCanvasDom();try{
  const r=room(),c=canvas(),q={id:'decorative-description',kind:'stone-study-label',x:32,y:48,w:16,h:16};
  drawObject(c.getContext('2d'),q,0,r);assert.equal(count(c),0);
  drawObject(c.getContext('2d'),{...q,id:'start',kind:'spawn'},0,r);assert(count(c)>0,'real spawn previews remain available');
 }finally{ui.restore();}
});

rasterTest('native reward tiles, pipes and ordinary actors retain identical opt-in and opt-out pixels',()=>{
 const ui=nativeCanvasDom();try{
  const r=room(),ordinary={...r};delete ordinary.smm2Mechanics;
  for(const material of ['brick','block','pipe','pipe-side','cloud-solid','used']){
   const q={id:'native-'+material,x:80,y:96,w:32,h:32,material},actual=canvas(),expected=canvas();drawTile(actual.getContext('2d'),q,r);drawTile(expected.getContext('2d'),q,ordinary);assert.deepEqual(bytes(actual),bytes(expected),material+' stays native');
  }
  for(const kind of ['coin','mushroom','flower','star','life','walker']){
   const q={id:'native-'+kind,kind,x:80,y:96,w:16,h:16},actual=canvas(),expected=canvas();drawObject(actual.getContext('2d'),q,8,r);drawObject(expected.getContext('2d'),q,8,ordinary);assert.deepEqual(bytes(actual),bytes(expected),kind+' stays native');
  }
 }finally{ui.restore();}
});

rasterTest('helmet is a native Mario overlay and opt-out/invulnerability frames retain their previous pixels',()=>{
 const ui=nativeCanvasDom();try{
  const r=room(),p={x:80,y:112,w:10,h:28,power:1,helmet:'buzzy',grounded:true,facing:1,vx:0},before=JSON.stringify(p),actual=canvas(),expected=canvas(),ordinary=canvas();
  drawPlayer(actual.getContext('2d'),p,0,undefined,r);drawPlayer(expected.getContext('2d'),p,0);drawSmm2PlayerGear(expected.getContext('2d'),p,0,r);assert.deepEqual(bytes(actual),bytes(expected));
  drawPlayer(ordinary.getContext('2d'),p,0,undefined,{});const native=canvas();drawPlayer(native.getContext('2d'),{...p,helmet:undefined},0);assert.deepEqual(bytes(ordinary),bytes(native));assert.notDeepEqual(bytes(actual),bytes(native));
  const blink=canvas();drawPlayer(blink.getContext('2d'),{...p,invulnerable:12},4,undefined,r);assert.equal(count(blink),0);assert.equal(JSON.stringify(p),before);
 }finally{ui.restore();}
});

rasterTest('pink native coin dispatch and four HUD slots follow explicit ids and live collection count',()=>{
 const ui=nativeCanvasDom();try{
  const r=room(),coin={id:'pink-a',kind:'coin',x:80,y:112,w:10,h:14},v={coins:0,score:0,timeLeft:500,viewportWidth:384,contraptions:{keys:0},smm2Mechanics:{version:1,pinkCoins:{taken:2,total:4,keyReleased:false}}},before=JSON.stringify({coin,v});r.smm2Mechanics.pinkCoins=[{id:'pink-a'}];
  const actual=canvas(),expected=canvas(),ordinary=canvas();drawObject(actual.getContext('2d'),coin,0,r);drawSmm2Actor(expected.getContext('2d'),coin,0,r);assert.deepEqual(bytes(actual),bytes(expected));
  drawObject(ordinary.getContext('2d'),{...coin,id:'gold-a'},0,r);assert.notDeepEqual(bytes(actual),bytes(ordinary));
  const hud=canvas(),baseline=canvas();drawHud(hud.getContext('2d'),v);drawSmm2PinkCoinHud(baseline.getContext('2d'),v,{x:329,y:40});assert.deepEqual(hud.getContext('2d').getImageData(329,40,43,9).data,baseline.getContext('2d').getImageData(329,40,43,9).data,'pink slots keep their original collection pixels in the separate auxiliary row');const header=hud.getContext('2d').getImageData(255,11,118,9).data;assert([...header].some((v,i,a)=>i%4===0&&v===255&&a[i+1]===255&&a[i+2]===255&&a[i+3]===255),'nine-digit score and clock/time retain white glyph interiors');assert.equal(JSON.stringify({coin,v}),before);
 }finally{ui.restore();}
});

function recordingContext(){
 const calls=[],rects=[],stack=[];let transform=[1,1,0,0];const context={calls,rects,fillStyle:'#000',save(){stack.push({transform:[...transform],fillStyle:this.fillStyle});},restore(){const state=stack.pop();if(state){transform=state.transform;this.fillStyle=state.fillStyle;}},scale(x,y){transform[0]*=x;transform[1]*=y;},translate(x,y){transform[2]+=x*transform[0];transform[3]+=y*transform[1];},fillRect(x,y,w,h){calls.push({color:this.fillStyle,x,y,w,h,transform:[...transform]});},rect(x,y,w,h){rects.push({x,y,w,h,transform:[...transform]});},createImageData:(w,h)=>({data:new Uint8ClampedArray(w*h*4)}),getImageData:(_x,_y,w,h)=>({data:new Uint8ClampedArray(w*h*4).fill(255)}),measureText:text=>({width:String(text).length*8,actualBoundingBoxLeft:0,actualBoundingBoxAscent:7,actualBoundingBoxDescent:1})};
 return new Proxy(context,{get:(t,k)=>t[k]??(()=>{})});
}

test('actual play draws the live world inside the shared camera transform without a proxy rectangle pass',async()=>{
 const ui=installSimulatedPlayDom();try{
  const create=ui.document.createElement,recorders=new Map();ui.document.createElement=tag=>{const element=create(tag);if(tag==='canvas'){const ctx=recordingContext();recorders.set(element,ctx);element.getContext=()=>ctx;}return element;};
  const project=blank('Live camera rendering fixture',640,448),r=project.rooms[0];Object.assign(r,{setting:'Castle',playRules:{version:1,timeLimit:500,timerFrames:60,viewportWidth:384,viewportHeight:224,cameraAnchor:100},smm2Mechanics:{version:1,art:{palette:'smb1-castle-stone'},donuts:[{id:'live-donut',x:240,y:336,w:32,h:16,delayFrames:3,gravity:.5,maxFallSpeed:3,triggerPolicy:'player',resetPolicy:'leave-before-drop',collision:'oneway'}]}});
  r.map.geometry=[{id:'floor',x:0,y:416,w:640,h:32,collision:'solid',material:'ground'}];r.map.objects=[{id:'start',kind:'spawn',x:244,y:322,w:10,h:14}];
  const {play}=await import('../atlas/editor-play.mjs'),session=await play(projectPack(project,r.roomId,character,'camera-rendering-fixture'),project.rooms,{brandCore:'data:image/svg+xml,<svg/>'},{developerMode:false});
  const game=session.screen.querySelector('canvas'),ctx=recorders.get(game);ui.frames(1);const v=game.workshopRead(),cam=nativeCamera(v),donutCalls=ctx.calls.filter(q=>q.color===SMM2_SOURCE_PIXELS.donutBlock.palette[3]);
  assert(donutCalls.length>0,'the actual live terrain view reaches drawSmm2World');
  const expected=recordingContext();expected.scale(2,2);expected.translate(-Math.round(cam.x),-Math.round(cam.y));drawSmm2World(expected,r,v,v.tick);
  assert.deepEqual(donutCalls,expected.calls.filter(q=>q.color===SMM2_SOURCE_PIXELS.donutBlock.palette[3]),'world pixels use the same camera and actual live component pose exactly once');
  assert.equal(cam.y,222);assert(!ctx.calls.some(q=>q.color==='#e251ac'),'no unknown physical proxy reaches native placeholder art');
  ui.frames(11);ctx.calls.length=0;ui.frames(1);const falling=game.workshopRead(),live=falling.smm2Mechanics.donuts[0],movingCam=nativeCamera(falling),movingExpected=recordingContext();
  assert.equal(live.phase,'falling');assert(live.y>r.smm2Mechanics.donuts[0].y,'contact actually moved the live platform from its authored home');
  movingExpected.scale(2,2);movingExpected.translate(-Math.round(movingCam.x),-Math.round(movingCam.y));drawSmm2World(movingExpected,r,falling,falling.tick);
  assert.deepEqual(ctx.calls.filter(q=>q.color===SMM2_SOURCE_PIXELS.donutBlock.palette[3]),movingExpected.calls.filter(q=>q.color===SMM2_SOURCE_PIXELS.donutBlock.palette[3]),'a falling Donut renders its actual live position once');
  session.close();
 }finally{ui.restore();}
});

test('real declared right-mouth entry and emergence clip Mario on the visible right side of the pipe',async()=>{
 const ui=installSimulatedPlayDom();try{
  const create=ui.document.createElement,recorders=new Map();ui.document.createElement=tag=>{const element=create(tag);if(tag==='canvas'){const ctx=recordingContext();recorders.set(element,ctx);element.getContext=()=>ctx;}return element;};
  const project=blank('Declared side pipe clip fixture',384,240),r=project.rooms[0],target=structuredClone(r);target.roomId='destination';project.rooms.push(target);
  for(const q of project.rooms){q.setting='Castle';q.smm2Mechanics={version:1,art:{palette:'smb1-castle-stone'}};q.map.geometry=[{id:'floor',x:0,y:224,w:384,h:16,collision:'solid',material:'ground'}];q.marioModules={version:1,itemSources:[],noteBlocks:[],oneWayWalls:[],enemyVariants:{}};}
  r.map.geometry.push({id:'entry-pipe',x:128,y:192,w:32,h:32,collision:'solid',material:'pipe-side'});r.map.objects=[{id:'start',kind:'spawn',x:160,y:210,w:10,h:14},{id:'side-portal',kind:'portal',x:158,y:192,w:16,h:32,targetRoom:target.roomId,targetSpawn:'arrival'}];r.marioModules.portalDirections={'side-portal':{pipeId:'entry-pipe',direction:'left'}};
  target.map.geometry.push({id:'arrival-pipe',x:64,y:192,w:32,h:32,collision:'solid',material:'pipe-side'});target.map.objects=[{id:'arrival',kind:'spawn',x:98,y:210,w:10,h:14}];target.marioModules.arrivalDirections={arrival:{pipeId:'arrival-pipe',direction:'right'}};
  const {play}=await import('../atlas/editor-play.mjs'),session=await play(projectPack(project,r.roomId,character,'side-pipe-render-fixture'),project.rooms,{brandCore:'data:image/svg+xml,<svg/>'},{developerMode:false}),game=session.screen.querySelector('canvas'),ctx=recorders.get(game);
  ui.key('ArrowLeft');for(let i=0;i<120&&!game.workshopRead().transition;i++)ui.frames(1);let v=game.workshopRead();assert.equal(v.transition?.smm2Direction,'left');assert.equal(v.transition.clipLeft,160);ui.release('ArrowLeft');
  const assertClip=()=>{ctx.rects.length=0;ui.frames(1);const v=game.workshopRead(),cam=nativeCamera(v),left=v.transition.clipLeft;assert(ctx.rects.some(q=>q.x===left&&q.y===cam.y&&q.w===Math.max(0,cam.x+cam.width-left)&&q.h===cam.height&&q.transform[2]===-2*Math.round(cam.x)&&q.transform[3]===-2*Math.round(cam.y)),'clipLeft is applied inside the actual world camera transform');};
  assertClip();for(let i=0;i<120&&game.workshopRead().roomId!==target.roomId;i++)ui.frames(1);v=game.workshopRead();assert.equal(v.roomId,target.roomId);assert.equal(v.transition?.smm2Direction,'right');assert.equal(v.transition.clipLeft,96);assertClip();session.close();
 }finally{ui.restore();}
});

function importsIn(source){return [...source.matchAll(/(?:\bfrom\s*|\bimport\s*(?:\(\s*)?)(['"])([^'"\n]+)\1/g)].map(m=>m[2]);}
function offlineSources(html){const map=JSON.parse(html.match(/<script type="importmap">([\s\S]*?)<\/script>/)[1]).imports;return new Map(Object.entries(map).map(([id,url])=>{assert(url.startsWith('data:text/javascript;charset=utf-8,'));return [id,decodeURIComponent(url.slice(url.indexOf(',')+1))];}));}
for(const collection of [false,true])test(`offline ${collection?'collection':'single course'} import map closes every actual source import and embeds all required assets`,async()=>{
 const r=room();r.smm2Mechanics.startingLives=9;const pack={stages:[{title:'SMM2 offline closure'}]},reads=[],audioNames=[];
 const html=await offlineFile(pack,[r],async path=>{reads.push(path);return read(path);},async name=>{audioNames.push(name);return new Uint8Array([1,2,3]);},()=>{},collection?{collection:{title:'Private closure fixture',levels:[]}}:{}),sources=offlineSources(html);
 for(const name of ['mechanics','thwomps','terrain','items','art'])assert(sources.has('workshop/editor-smm2-'+name+'.mjs'));assert(sources.has('workshop/editor-camera.mjs'));
 for(const [id,embedded]of sources){
  const original=read('./'+id.slice('workshop/'.length)),actualImports=importsIn(original),embeddedImports=importsIn(embedded);assert.equal(embeddedImports.length,actualImports.length,id+' retains its real import statements');
  for(const [index,specifier]of actualImports.entries()){
   assert(specifier.startsWith('.'),id+' has no external JS dependency');const resolved='workshop/'+new URL(specifier,'https://local.invalid/'+id.slice('workshop/'.length)).pathname.slice(1);
   assert(sources.has(resolved),id+' source import resolves: '+specifier);assert.equal(embeddedImports[index],resolved,id+' embedded import points to the included module');
  }
 }
 const entry=html.match(/<script type="module">([\s\S]*?)<\/script>/)[1];for(const dependency of importsIn(entry))assert(sources.has(dependency));
 assert(!/<script\b[^>]*\bsrc\s*=|<link\b[^>]*\brel\s*=\s*["']stylesheet/i.test(html));
 for(const image of html.matchAll(/<img\b[^>]*\bsrc="([^"]+)"/g))assert(image[1].startsWith('data:'),'HTML image is embedded');
 const media=JSON.parse(entry.match(/(?:const collection=[\s\S]*?,media=|\bmedia=)(\{[\s\S]*?\})(?:;const|;mount)/)[1]);
 for(const value of Object.values(media))assert(value.startsWith('data:'),'runtime assets are embedded');assert(Object.keys(media).length>=audioNames.length);
 assert(reads.includes('./assets/q-logo-pixel-core.svg'));assert(reads.includes('./assets/q-logo-pixel-framed.svg'));assert(reads.includes('./assets/xiaoq-avatar-p63a.svg'));
 if(!collection)assert(entry.includes('rooms.find(r=>r.smm2Mechanics?.startingLives)?.smm2Mechanics.startingLives'),'offline starting lives use the room sidecar');
});

test('collection capability reports explicit SMM2 component support only for versioned rooms',()=>{
 const project=blank('Capability fixture',640,448),before=JSON.stringify(project);assert(!requiredCollectionCapabilities(project).includes('smm2-components-v1'));
 project.rooms[0].smm2Mechanics={version:1};assert(requiredCollectionCapabilities(project).includes('smm2-components-v1'));delete project.rooms[0].smm2Mechanics;assert.equal(JSON.stringify(project),before);
});
