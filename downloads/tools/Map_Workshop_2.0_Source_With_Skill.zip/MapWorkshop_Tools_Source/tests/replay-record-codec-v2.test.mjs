import assert from 'node:assert/strict';
import {test} from 'node:test';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
import {createHash,randomBytes} from 'node:crypto';
import {gzipSync,gunzipSync,brotliCompressSync,brotliDecompressSync,constants} from 'node:zlib';
import {REPLAY_RECORD_CODEC_VERSION,REPLAY_RECORD_SUPPORTED_CODEC_VERSIONS,
 encodeReplayRecordBytes,recompressReplayRecordStorage,decodeReplayRecordEnvelope,decodeReplayRecordStorage,
 readReplayRecordSync,readReplayRecord,readReplayRecordBytesSync,readReplayRecordBytes} from '../scripts/replay-record-codec.mjs';

const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const bytes=value=>Buffer.from(JSON.stringify(value,null,2)+'\n');
const fixture=()=>JSON.parse('{"rle":[{"frames":2,"input":{"x":1}}],"events":[{"frame":2,"event":"done"}],"trace":[{"geometry":[{"id":"floor","x":0}],"age":1},{"geometry":[{"id":"floor","x":0}],"age":2}],"final":{"completed":true,"literal":["ref",0],"__proto__":{"safe":true}}}');
const envelope=version=>JSON.parse(gunzipSync(encodeReplayRecordBytes(bytes(fixture()),{version})));
const packageEnvelope=value=>gzipSync(Buffer.from(JSON.stringify(value)));
const replaceInner=(outer,mutate)=>{
 const inner=JSON.parse(brotliDecompressSync(Buffer.from(outer.payload.data,'base64')));mutate(inner);
 const raw=Buffer.from(JSON.stringify(inner));outer.payload.bytes=raw.length;outer.payload.sha256=sha(raw);outer.payload.data=brotliCompressSync(raw).toString('base64');
};

test('v2 retains the exact v1 DAG, full canonical bytes and independent mutable containers',()=>{
 const raw=bytes(fixture()),v1=encodeReplayRecordBytes(raw),v2=recompressReplayRecordStorage(v1),outer=JSON.parse(gunzipSync(v2));
 assert.equal(REPLAY_RECORD_CODEC_VERSION,1);assert.deepEqual(REPLAY_RECORD_SUPPORTED_CODEC_VERSIONS,[1,2]);assert.equal(outer.version,2);
 assert.deepEqual(brotliDecompressSync(Buffer.from(outer.payload.data,'base64')),gunzipSync(v1));
 for(const storage of [v1,v2,encodeReplayRecordBytes(raw,{version:2})]){
  const decoded=decodeReplayRecordStorage(storage);assert.deepEqual(decoded.bytes,raw);assert.deepEqual(decoded.record,fixture());
  assert.notStrictEqual(decoded.record.trace[0].geometry[0],decoded.record.trace[1].geometry[0]);
  decoded.record.trace[0].geometry[0].x=17;assert.equal(decoded.record.trace[1].geometry[0].x,0);
  assert.deepEqual(decoded.record.final.literal,['ref',0]);assert(Object.hasOwn(decoded.record.final,'__proto__'));assert.equal({}.safe,undefined);
 }
 assert.deepEqual(recompressReplayRecordStorage(v2,{version:1}),v1);assert.deepEqual(recompressReplayRecordStorage(v2),v2);
 assert.deepEqual(recompressReplayRecordStorage(raw),v2);assert.deepEqual(encodeReplayRecordBytes(raw),v1);
 assert.throws(()=>encodeReplayRecordBytes(raw,{version:99}),/unsupported encoding version/);
 assert.throws(()=>recompressReplayRecordStorage(v1,{version:99}),/unsupported encoding version/);
});

test('legacy/v1/v2 synchronous and asynchronous readers keep the established JSON.gz paths',async()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'Frozen Replay v2 ')),raw=bytes(fixture());
 try{
  for(const version of [null,1,2]){
   const base=path.join(dir,'route-'+version+'.json'),file=version===null?base:base+'.gz';
   fs.writeFileSync(file,version===null?raw:encodeReplayRecordBytes(raw,{version}));
   for(const input of [file,base,new URL('file://'+file)]){
    assert.deepEqual(readReplayRecordSync(input),fixture());assert.deepEqual(await readReplayRecord(input),fixture());
    assert.deepEqual(readReplayRecordBytesSync(input),raw);assert.deepEqual(await readReplayRecordBytes(input),raw);
   }
  }
 }finally{fs.rmSync(dir,{recursive:true,force:true});}
});

test('CLI default v1 compression and explicit lossless v2 recompression/restore/verify work in spaced paths',()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'Frozen Replay v2 CLI ')),raw=bytes(fixture()),input=path.join(dir,'original route.json'),v1=input+'.gz',v2=path.join(dir,'v2 route.json.gz'),back=path.join(dir,'back.json.gz'),restored=path.join(dir,'restored.json');
 const cli=fileURLToPath(new URL('../scripts/replay-record-codec.mjs',import.meta.url));
 const run=args=>{const r=spawnSync(process.execPath,[cli,...args],{encoding:'utf8'});assert.equal(r.status,0,r.stderr);return JSON.parse(r.stdout);};
 try{
  fs.writeFileSync(input,raw);assert.equal(run(['compress',input,v1]).codecVersion,1);
  assert.equal(run(['compress',input,v2,'--version=2']).codecVersion,2);
  assert.equal(run(['recompress',v1,v2]).codecVersion,2);assert.equal(run(['verify',v2]).originalSha256,sha(raw));
  run(['decompress',v2,restored]);assert.deepEqual(fs.readFileSync(restored),raw);
  assert.equal(run(['recompress',v2,back,'--version=1']).codecVersion,1);assert.deepEqual(fs.readFileSync(back),fs.readFileSync(v1));
  assert.deepEqual(fs.readFileSync(input),raw,'CLI retains the original source');
  for(const args of [['recompress',v1,restored],['compress',input,v2,'--version=99'],['recompress',v1,v2,'--unknown'],['verify',v2,'extra']])assert.notEqual(spawnSync(process.execPath,[cli,...args]).status,0);
 }finally{fs.rmSync(dir,{recursive:true,force:true});}
});

test('strict v2 rejects tampered outer/inner metadata, data, invalid base64, Brotli and nested codecs',()=>{
 const invalid=[
  d=>{d.version=99;},d=>{d.extra=1;},d=>{d.original.bytes++;},d=>{d.original.sha256='0'.repeat(64);},
  d=>{d.payload.compression='gzip';},d=>{d.payload.encoding='hex';},d=>{d.payload.extra=true;},
  d=>{d.payload.bytes++;},d=>{d.payload.bytes--;},d=>{d.payload.sha256='0'.repeat(64);},d=>{d.payload.data='%%%%';},
  d=>{d.payload.data='YQ=';},d=>{d.payload.data='YR==';},d=>{d.payload.data=Buffer.from('bad brotli').toString('base64');},
  d=>{d.payload.data=Buffer.concat([Buffer.from(d.payload.data,'base64'),Buffer.from('trailing')]).toString('base64');},
  d=>{const raw=Buffer.from('null');d.payload.bytes=raw.length;d.payload.sha256=sha(raw);d.payload.data=brotliCompressSync(raw).toString('base64');},
  d=>replaceInner(d,inner=>{inner.version=2;}),d=>replaceInner(d,inner=>{inner.version=99;}),
  d=>replaceInner(d,inner=>{inner.original.sha256='0'.repeat(64);}),d=>replaceInner(d,inner=>{inner.root=['ref',inner.nodes.length];}),
  d=>replaceInner(d,inner=>{inner.nodes.push([0,[]]);})
 ];
 for(const mutate of invalid){const d=envelope(2);mutate(d);assert.throws(()=>decodeReplayRecordEnvelope(d),/Frozen replay codec:/);assert.throws(()=>decodeReplayRecordStorage(packageEnvelope(d)),/Frozen replay codec:/);}
 const damaged=encodeReplayRecordBytes(bytes(fixture()),{version:2});damaged[damaged.length-8]^=1;assert.throws(()=>decodeReplayRecordStorage(damaged),/invalid gzip/);
 assert.throws(()=>decodeReplayRecordStorage(gzipSync(bytes(fixture()))),/unsupported or malformed envelope/,'gzip of raw JSON is not a codec envelope');
 const reordered=envelope(2);reordered.original={serialization:reordered.original.serialization,sha256:reordered.original.sha256,bytes:reordered.original.bytes};assert.deepEqual(decodeReplayRecordEnvelope(reordered).bytes,bytes(fixture()));
});

test('v1/v2 enforce configurable decompression, original-byte, node-table and depth limits before expansion',async()=>{
 const raw=bytes(fixture());
 for(const version of [1,2]){
  const storage=encodeReplayRecordBytes(raw,{version}),d=JSON.parse(gunzipSync(storage));
  assert.throws(()=>decodeReplayRecordStorage(storage,{maxEnvelopeBytes:10}),/decode limit/);
  assert.throws(()=>decodeReplayRecordStorage(storage,{maxOriginalBytes:raw.length-1}),/original-byte decode limit/);
  assert.throws(()=>decodeReplayRecordEnvelope(d,{maxNodes:1}),/node-table decode limit/);
  assert.throws(()=>decodeReplayRecordEnvelope(d,{maxDepth:1}),/depth decode limit/);
  assert.deepEqual(decodeReplayRecordStorage(storage,{maxOriginalBytes:raw.length}).bytes,raw);
 }
 const bomb=envelope(1);bomb.nodes=[[0,['x']]];for(let i=1;i<30;i++)bomb.nodes.push([0,[['ref',i-1],['ref',i-1]]]);bomb.nodes.push([1,[['x',['ref',29]]]]);bomb.root=['ref',30];
 assert.throws(()=>decodeReplayRecordEnvelope(bomb),/expanded-byte decode limit/);
 assert.throws(()=>decodeReplayRecordStorage(raw,{maxOriginalBytes:raw.length-1}),/decode limit/);
 for(const options of [{maxDepth:0},{maxNodes:NaN},{unknown:1}])assert.throws(()=>decodeReplayRecordStorage(raw,options),/invalid decode limit/);
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'Frozen Replay limit ')),file=path.join(dir,'record.json.gz');
 try{fs.writeFileSync(file,encodeReplayRecordBytes(raw,{version:2}));assert.throws(()=>readReplayRecordSync(file,{maxOriginalBytes:1}),/decode limit/);await assert.rejects(readReplayRecord(file,{maxOriginalBytes:1}),/decode limit/);}finally{fs.rmSync(dir,{recursive:true,force:true});}
});


test('valid multi-megabyte v2 base64 payloads decode within the declared limits',()=>{
 const original=bytes({blob:randomBytes(4_000_000).toString('base64')}),dag=gunzipSync(encodeReplayRecordBytes(original)),inner=JSON.parse(dag);
 const compressed=brotliCompressSync(dag,{params:{[constants.BROTLI_PARAM_QUALITY]:0}});
 assert(compressed.length>=4_000_000,'exercise canonical Base64 above the former grouped-regex stack threshold');
 const outer={format:inner.format,version:2,original:inner.original,payload:{compression:'brotli',bytes:dag.length,sha256:sha(dag),encoding:'base64',data:compressed.toString('base64')}};
 assert.deepEqual(decodeReplayRecordEnvelope(outer).bytes,original);assert.deepEqual(decodeReplayRecordStorage(packageEnvelope(outer)).bytes,original);
});
