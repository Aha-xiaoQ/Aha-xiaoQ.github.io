import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {audioFiles} from '../atlas/editor-audio.mjs';
import {embeddedAudioMime,offlineFile} from '../atlas/editor-offline.mjs';
import {createNeutralProject,readCharacterProfile} from '../scripts/neutral-fixtures.mjs';
import {projectPack} from '../atlas/editor-runtime.mjs';

test('embedded audio MIME follows WAV, FLAC, Ogg and MP3 magic even with a different logical extension',()=>{
 const wav=Buffer.from('RIFF\x00\x00\x00\x00WAVE','latin1');
 for(const [bytes,mime]of [[wav,'audio/wav'],[Buffer.from('fLaC'),'audio/flac'],[Buffer.from('OggS'),'audio/ogg'],[Buffer.from('ID3'),'audio/mpeg'],[Buffer.from([0xff,0xfb,0x90,0x64]),'audio/mpeg']]){
  assert.equal(embeddedAudioMime(bytes,'logical.wav'),mime);
  assert.equal(embeddedAudioMime(bytes,'logical.mp3'),mime);
 }
});

test('unknown and truncated containers retain the existing extension fallback',()=>{
 for(const bytes of [new Uint8Array(),Buffer.from('RIFF'),Buffer.from([0xff,0xf1,0x50,0x80]),Buffer.from([0xff,0xfb,0xf0,0])]){
  assert.equal(embeddedAudioMime(bytes,'legacy.wav'),'audio/wav');
  assert.equal(embeddedAudioMime(bytes,'legacy.ogg'),'audio/ogg');
  assert.equal(embeddedAudioMime(bytes,'legacy.mp3'),'audio/mpeg');
 }
});

test('all unchanged packaged WAV and MP3 bytes retain their legacy MIME',async()=>{
 for(const name of new Set(Object.values(audioFiles).filter(name=>typeof name==='string'))){
  const bytes=await fs.readFile(new URL('../atlas/assets/classic-audio/'+name,import.meta.url));
  assert.equal(embeddedAudioMime(bytes,name),name.endsWith('.wav')?'audio/wav':name.endsWith('.ogg')?'audio/ogg':'audio/mpeg',name);
 }
});

test('offline media embeds the returned bytes verbatim while preserving logical audio keys',async()=>{
 const d=createNeutralProject(),character=await readCharacterProfile();
 d.rooms[0].setting='Castle';
 const pack=projectPack(d,'main',character,'neutral-lossless-audio');
 const flac=Buffer.from('fLaC\x80\x00\x00\x04test','latin1');
 const read=p=>fs.readFile(new URL('../atlas/'+p,import.meta.url),'utf8');
 const readAudio=name=>name==='castle-loop.wav'?flac:fs.readFile(new URL('../atlas/assets/classic-audio/'+name,import.meta.url));
 const html=await offlineFile(pack,d.rooms,read,readAudio,()=>{},{essentialAudio:true});
 const media=JSON.parse(html.match(/,media=(\{.*?\});const start=/s)[1]);
 assert.match(media.castle,/^data:audio\/flac;base64,/);
 assert.deepEqual(Buffer.from(media.castle.split(',')[1],'base64'),flac);
 const checkpoint=await fs.readFile(new URL('../atlas/assets/classic-audio/'+audioFiles.checkpoint,import.meta.url));
 assert.equal(media.checkpoint,'data:audio/wav;base64,'+checkpoint.toString('base64'));
 assert.equal(audioFiles.castle,'castle-loop.wav');
 assert.equal(audioFiles.ghost_house_night,'ghost-house-night-loop.wav');
});
