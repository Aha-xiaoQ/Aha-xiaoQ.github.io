import test from 'node:test';
import assert from 'node:assert/strict';
import {createMinecraftController,validateMinecraftRoom} from '../atlas/editor-minecraft.mjs';
import {createPlatformStage} from '../atlas/editor-mario-stage.mjs';
import {createPlatformMotor} from '../atlas/editor-mario-motor.mjs';
import {parseProject,validate} from '../atlas/editor-model.mjs';
const solid=(id,x,y,w,h)=>({id,x,y,w,h,collision:'solid',material:'stone'});
const character={capabilities:['jump'],motion:{width:10,height:14,maxHealth:1}};
function fixture(){return {format:'xiaoq-map-project',version:1,id:'discovery-contract',title:'Discovery contract',rooms:[{roomId:'main',setting:'Overworld',markers:[],decorations:[],map:{id:'main-map',title:'Discoveries',width:640,height:320,tileSize:16,geometry:[solid('floor',0,288,640,32),solid('branch',96,224,32,16),solid('hedge',224,256,32,32),solid('cart',320,256,40,12),solid('ore-0',360,208,16,16),solid('ore-1',392,208,16,16),solid('ore-2',424,208,16,16),solid('seal',544,256,16,32)],objects:[{id:'start',kind:'spawn',x:104,y:274,w:10,h:14},{id:'hidden',kind:'portal',x:228,y:256,w:16,h:32,targetRoom:'main',targetSpawn:'start'},{id:'ore-portal',kind:'portal',x:546,y:256,w:12,h:32,targetRoom:'main',targetSpawn:'start'}]},minecraft:{version:1,biome:'forest',creepers:[],destructibleIds:[],sandIds:[],exploration:{appleTree:{branchId:'branch',x:136,y:220},pig:{id:'friend',x:180,y:266,gateId:'hedge'},cart:{geometryId:'cart',endX:480,speed:1.6},ores:[{id:'ore-0',coins:2},{id:'ore-1',coins:1},{id:'ore-2',coins:3}],oresCompletionGateId:'seal',lockedPortals:[{portalId:'hidden',gateId:'hedge'},{portalId:'ore-portal',gateId:'seal'}],fleePigs:[{id:'warning-pig',x:580,y:266}]}}}]};}
function harness(doc=fixture()){const room=doc.rooms[0],events=[],rewards=[],control=createMinecraftController(room,{emit:(type,data)=>events.push({type,...data}),rewardCoins:n=>rewards.push(n)});let geometry=structuredClone(room.map.geometry),tick=0;return{doc,room,control,events,rewards,get geometry(){return geometry;},get tick(){return tick;},step(player={x:0,y:274,w:10,h:14}){geometry=control.step({tick:++tick,player,geometry}).geometry;return control.view().exploration;},frames(n,p){for(let i=0;i<n;i++)this.step(p);return control.view().exploration;}};}
function stageFor(doc){const room=doc.rooms[0],events=[],stage=createPlatformStage({plan:{stage:{entryRoom:'main',entrySpawn:'start',title:'Discoveries'},character,rooms:Object.fromEntries(doc.rooms.map(r=>[r.roomId,r.map]))},motor:createPlatformMotor(),visualRooms:doc.rooms,emit:(type,data)=>events.push({type,...data})});return{stage,events,room};}

test('R2 discovery schema roundtrips and rejects missing, unsafe, duplicate, conflicting and obstructed geometry',()=>{
 const d=fixture(),before=JSON.stringify(d);validate(d);assert.deepEqual(parseProject(before),d);assert.equal(JSON.stringify(d),before);
 for(const mutate of [e=>e.appleTree.branchId='absent',e=>e.pig.id='floor',e=>e.pig.x=225,e=>e.ores[1].id='ore-0',e=>e.ores[0].coins=-1,e=>e.cart.speed=9,e=>e.cart.endX=600,e=>e.lockedPortals[0].gateId='floor',e=>e.lockedPortals[0].portalId='start',e=>e.oresCompletionGateId='branch',e=>e.fleePigs[0].id='friend',e=>e.fleePigs[0].x=999,e=>e.script='alert(1)']){const r=fixture().rooms[0];mutate(r.minecraft.exploration);assert.throws(()=>validateMinecraftRoom(r));}
 const moving=fixture().rooms[0];moving.map.geometry.find(q=>q.id==='cart').motion={axis:'x',min:0,max:100,speed:1};assert.throws(()=>validateMinecraftRoom(moving));
});

test('elapsed time cannot drop apple, move cart, reward ore, or open a secret',()=>{
 const s=harness();s.frames(480);const e=s.control.view().exploration;assert.equal(e.apple.state,'hanging');assert.equal(e.cart.state,'waiting');assert.equal(e.cart.x,320);assert.equal(e.pig.gateOpen,false);assert.equal(e.mineLights,false);assert.equal(s.rewards.length,0);assert.equal(s.control.allowsObject('hidden'),false);assert.equal(s.control.allowsObject('ore-portal'),false);assert.equal(s.control.allowsObject('start'),true);
});

test('real native head collision shakes branch and drops a falling apple, collected only on contact',()=>{
 const s=harness(),motor=createPlatformMotor(),p=motor.create(character,{x:104,y:274});let hit=false;
 for(let i=0;i<80;i++){s.step(p);motor.step(p,{jump:i>=3&&i<25,jumpPressed:i===3},character,{solids:s.geometry,width:640});if(p.headHit==='branch')hit=true;}
 assert(hit);assert.equal(s.control.view().exploration.apple.state,'resting');assert.equal(s.control.view().exploration.apple.y,278);assert.equal(s.events.filter(e=>e.event==='apple-dropped').length,1);
 p.x=136;s.step(p);assert.equal(s.control.view().exploration.apple.state,'carried');p.x=160;p.facing=-1;s.control.syncPlayer(p);assert.equal(s.control.view().exploration.apple.x,153);assert.equal(s.events.filter(e=>e.event==='apple-collected').length,1);
});

test('apple attracts actual pig, sustained sniff removes real hedge, eats apple, and unlocks portal once',()=>{
 const s=harness(),p={x:104,y:240,w:10,h:14,headHit:'branch',facing:1};s.step(p);p.headHit=null;p.x=136;p.y=274;s.frames(50,p);assert.equal(s.control.view().exploration.apple.state,'carried');
 const start=s.control.view().exploration.pig.x;p.x=80;s.frames(60,p);assert(s.control.view().exploration.pig.x<start);assert.equal(s.control.allowsObject('hidden'),false);
 p.x=210;let v=s.frames(180,p);assert.equal(v.pig.gateOpen,true);assert.equal(v.apple.state,'given');assert.equal(s.geometry.some(g=>g.id==='hedge'),false);assert.equal(s.control.allowsObject('hidden'),true);assert.equal(v.nearPortal.id,'hidden');assert(s.geometry.some(g=>g.id==='seal'));s.frames(100,p);assert.equal(s.events.filter(e=>e.event==='pig-secret-opened').length,1);
});

test('leaving pig mid-sniff interrupts the unlock instead of a proximity timer completing offscreen',()=>{
 const s=harness(),p={x:136,y:274,w:10,h:14,headHit:'branch'};s.frames(40,p);p.headHit=null;p.x=210;s.frames(20,p);assert(s.control.view().exploration.pig.sniffTicks>0);assert(s.control.view().exploration.pig.sniffTicks<45);p.x=0;s.frames(50,p);assert.equal(s.control.view().exploration.pig.gateOpen,false);assert.equal(s.control.allowsObject('hidden'),false);
});

test('minecart native moving solid starts under rider, carries with no slipping, stops exactly, and can be jumped off',()=>{
 const s=harness(),motor=createPlatformMotor(),p=motor.create(character,{x:330,y:242});p.grounded=true;p.support='cart';
 for(let i=0;i<150;i++){s.step(p);motor.step(p,{},character,{solids:s.geometry,width:640});assert.equal(p.support,'cart');assert(Math.abs(p.x-s.control.view().exploration.cart.x-10)<1e-8);}
 const e=s.control.view().exploration;assert.equal(e.cart.x,480);assert.equal(e.cart.state,'arrived');assert.equal(s.geometry.find(q=>q.id==='cart').dx,0);assert.equal(s.events.filter(e=>e.event==='cart-started').length,1);assert.equal(s.events.filter(e=>e.event==='cart-arrived').length,1);assert(s.events.some(e=>e.event==='mc-cart-rattle'));
 s.step(p);motor.step(p,{jump:true,jumpPressed:true},character,{solids:s.geometry,width:640});assert.equal(p.grounded,false);assert(p.vy<0);s.frames(50,p);assert.equal(s.control.view().exploration.cart.x,480);
});

test('ore rewards are one-time true head hits; third unique ore lights the mine and removes its sealed shortcut',()=>{
 const s=harness(),p={x:0,y:274,w:10,h:14};s.frames(5,p);for(const id of ['ore-0','ore-0','ore-1']){p.headHit=id;s.step(p);}assert.deepEqual(s.rewards,[2,1]);assert.equal(s.control.view().exploration.mineLights,false);assert(s.geometry.some(q=>q.id==='seal'));assert.equal(s.control.allowsObject('ore-portal'),false);
 p.headHit='ore-2';s.step(p);assert.deepEqual(s.rewards,[2,1,3]);assert.equal(s.control.view().exploration.mineLights,true);assert.equal(s.geometry.some(q=>q.id==='seal'),false);assert.equal(s.control.allowsObject('ore-portal'),true);assert(s.geometry.filter(q=>q.id.startsWith('ore-')).every(q=>q.mcOreUsed));s.frames(100,p);assert.equal(s.events.filter(e=>e.event==='mine-lights-lit').length,1);assert.deepEqual(s.rewards,[2,1,3]);
});

test('nearby warning pig really flees an armed creeper, raises visible warning and respects a solid wall',()=>{
 const d=fixture(),r=d.rooms[0];r.minecraft.creepers=[{id:'creeper',x:490,y:260,fuseTicks:90,speed:0}];r.minecraft.exploration.fleePigs=[{id:'warning-pig',x:456,y:266}];delete r.minecraft.exploration.cart;r.map.geometry.push(solid('pig-wall',430,256,16,32));const s=harness(d),p={x:488,y:274,w:10,h:14};s.step(p);const start=s.control.view().exploration.fleePigs[0].x;s.frames(12,p);let q=s.control.view().exploration.fleePigs[0];assert.equal(q.state,'flee');assert(q.warning>0);assert(q.x<start);assert(q.facing<0);assert.equal(s.events.filter(e=>e.event==='pig-fled').length,1);assert(q.y+q.h<=288);assert.equal(q.x,446);
});

test('discoveries pause and repeated ticks are inert; reset restores every actor, reward and gate state',()=>{
 const s=harness(),p={x:136,y:274,w:10,h:14,headHit:'branch'};s.frames(35,p);p.headHit='ore-0';s.step(p);const e=JSON.stringify(s.control.view());s.control.step({tick:s.tick,player:p,geometry:s.geometry});assert.equal(JSON.stringify(s.control.view()),e);s.control.pause();s.frames(30,p);assert.equal(JSON.stringify(s.control.view()),e);s.control.pause(false);s.step(p);assert.notEqual(JSON.stringify(s.control.view()),e);s.control.reset();const v=s.control.view().exploration;assert.equal(v.apple.state,'hanging');assert.equal(v.cart.state,'waiting');assert(v.ores.every(q=>!q.used));assert.equal(v.pig.gateOpen,false);assert.equal(v.mineLights,false);assert.equal(s.control.allowsObject('hidden'),false);
});

test('native stage uses ordinary jump and walking to discover apple/pig gate; locked portal stays absent until unlocked',()=>{
 const {stage,events}=stageFor(fixture());assert.equal(stage.view().objects.some(q=>q.id==='hidden'),false);stage.step({});for(let i=0;i<70;i++)stage.step({jump:i<24});assert(events.some(e=>e.event==='apple-dropped'));
 for(let i=0;i<180;i++)stage.step({x:1});const v=stage.view();assert.equal(v.minecraft.exploration.apple.state,'given');assert.equal(v.minecraft.exploration.pig.gateOpen,true);assert(v.objects.some(q=>q.id==='hidden'));assert.equal(v.geometry.some(q=>q.id==='hedge'),false);assert.equal(v.roomId,'main');
});

test('native stage ore callback awards real wallet coins and cannot double-pay when head hit repeats',()=>{
 const d=fixture(),r=d.rooms[0];r.map.objects[0].x=365;r.map.geometry.push(solid('ore-step',352,256,96,32));delete r.minecraft.exploration.cart;const {stage,events}=stageFor(d);for(let i=0;i<50;i++)stage.step({});for(let i=0;i<55;i++)stage.step({jump:i<25});assert.equal(stage.view().coins,2);assert.equal(events.filter(e=>e.event==='ore-discovered').length,1);for(let i=0;i<3;i++){stage.step({});for(let j=0;j<55;j++)stage.step({jump:j<25});}assert.equal(stage.view().coins,2);
});

test('native death reset restores apple, pig, hedge, secret locks and cart to authored state',()=>{
 const d=fixture();d.rooms[0].map.objects.push({id:'reset-hazard',kind:'hazard',x:280,y:256,w:16,h:32});const {stage}=stageFor(d);
 stage.step({});for(let i=0;i<70;i++)stage.step({jump:i<24});for(let i=0;i<250&&!stage.view().minecraft.exploration.pig.gateOpen;i++)stage.step({x:1});assert.equal(stage.view().minecraft.exploration.pig.gateOpen,true);
 for(let i=0;i<100&&!stage.view().p.dying;i++)stage.step({x:1});assert.equal(stage.view().p.dying,true);assert.equal(stage.view().lives,2);
 for(let i=0;i<110;i++)stage.step({});const v=stage.view();assert.equal(!!v.p.dying,false);assert.equal(v.lives,2);assert.equal(v.p.x,104);assert.equal(v.minecraft.exploration.apple.state,'hanging');assert.equal(v.minecraft.exploration.pig.gateOpen,false);assert.equal(v.minecraft.exploration.pig.x,180);assert.equal(v.minecraft.exploration.cart.x,320);assert.equal(v.minecraft.exploration.cart.state,'waiting');assert(v.geometry.some(q=>q.id==='hedge'));assert.equal(v.objects.some(q=>q.id==='hidden'),false);
});

test('an apple can land on a one-pixel shelf without tunneling; pig cannot be lured off an authored ledge',()=>{
 const d=fixture(),r=d.rooms[0];r.map.geometry.push(solid('apple-shelf',130,258,24,1));const s=harness(d),p={x:0,y:274,w:10,h:14,headHit:'branch'};s.frames(100,p);assert.equal(s.control.view().exploration.apple.y,248);assert.equal(s.control.view().exploration.apple.state,'resting');
 const e=fixture();e.rooms[0].map.geometry.find(g=>g.id==='floor').w=204;delete e.rooms[0].minecraft.exploration.cart;const ledge=harness(e),q={x:136,y:274,w:10,h:14,headHit:'branch'};ledge.frames(50,q);q.headHit=null;q.x=320;ledge.frames(400,q);const pig=ledge.control.view().exploration.pig;assert.equal(pig.dead,false);assert(pig.x+pig.w<=204);assert.equal(pig.y,266);
});
