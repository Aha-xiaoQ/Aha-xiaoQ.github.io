import test from 'node:test';
import assert from 'node:assert/strict';
import {createMinecraftController,validateMinecraftRoom} from '../atlas/editor-minecraft.mjs';
import {createPlatformStage} from '../atlas/editor-mario-stage.mjs';
import {createPlatformMotor} from '../atlas/editor-mario-motor.mjs';
import {parseProject,validate} from '../atlas/editor-model.mjs';
import {requiredCollectionCapabilities} from '../atlas/editor-collection.mjs';
const rect=(id,x,y,w,h,extra={})=>({id,x,y,w,h,...extra});
const solid=(id,x,y,w,h)=>rect(id,x,y,w,h,{collision:'solid',material:'stone'});
const character={capabilities:['jump'],motion:{width:10,height:14,maxHealth:1}};
function fixture(){return {format:'xiaoq-map-project',version:1,id:'minecraft-neutral-contract',title:'Neutral voxel physics contract',rooms:[{roomId:'main',setting:'Overworld',markers:[],decorations:[],map:{id:'neutral-voxel',title:'Neutral voxel physics contract',width:384,height:240,tileSize:16,geometry:[solid('floor',0,224,384,16),solid('breakable',176,144,32,80),solid('sand-a',176,128,16,16),solid('sand-b',176,112,16,16),solid('sand-c',192,128,16,16)],objects:[rect('start',48,210,10,14,{kind:'spawn'})]},minecraft:{version:1,biome:'cave',creepers:[{id:'creeper',x:132,y:196,blastRadius:80,fuseTicks:90}],destructibleIds:['breakable'],sandIds:['sand-a','sand-b','sand-c']}}]};}
function controller(doc=fixture()){const room=doc.rooms[0],events=[],damage=[],control=createMinecraftController(room,{emit:(type,data)=>events.push({type,...data}),hurtPlayer:e=>damage.push(e)});let geometry=structuredClone(room.map.geometry),tick=0;return {room,control,events,damage,get geometry(){return geometry;},set geometry(g){geometry=g;},get tick(){return tick;},step(player={x:0,y:0,w:10,h:14}){geometry=control.step({tick:++tick,geometry,player}).geometry;return control.view();},frames(n,p){for(let i=0;i<n;i++)this.step(p);return control.view();}};}

test('Minecraft sidecar is inert when absent; importer roundtrip keeps authored rules and checks actual IDs',()=>{
 const d=fixture(),r=d.rooms[0];const baseline=JSON.stringify(d);validate(d);assert.equal(JSON.stringify(d),baseline);assert.deepEqual(parseProject(baseline),d);assert(requiredCollectionCapabilities(d).includes('authored-minecraft-adventure-v1'));
 delete r.minecraft;assert.equal(createMinecraftController(r),null);assert.doesNotThrow(()=>validateMinecraftRoom(r));
 for(const mutate of [r=>r.minecraft.secretDamage=99,r=>r.minecraft.creepers[0].fuseTicks=0,r=>r.minecraft.creepers[0].speed=Infinity,r=>r.minecraft.creepers[0].id='floor',r=>r.minecraft.destructibleIds=['missing'],r=>r.minecraft.sandIds=['breakable'],r=>r.minecraft.sandIds=['sand-a','sand-a'],r=>r.minecraft.creepers[0].x=180,r=>r.mechanics={type:'echo-cooperation'}]){const q=fixture().rooms[0];mutate(q);assert.throws(()=>validateMinecraftRoom(q));}
});

test('sand remains still while truly supported and no trigger is caused by elapsed time',()=>{
 const s=controller(),initial=s.control.view();s.frames(240,{x:0,y:0,w:10,h:14});assert.deepEqual(s.control.view().sand,initial.sand.map(q=>({...q,support:q.id==='sand-b'?'sand-a':'breakable'})));assert.equal(s.control.view().creepers[0].state,'idle');assert.equal(s.events.some(e=>e.event==='creeper-armed'),false);assert.equal(s.events.some(e=>e.event==='sand-started'),false);
});

test('approach, visible cancellable fuse, one blast, bounded damage and destructible ownership are real',()=>{
 const s=controller(),near={x:104,y:210,w:10,h:14},far={x:44,y:210,w:10,h:14};s.step(near);let v=s.control.view();assert.equal(v.creepers[0].state,'fuse');assert.equal(v.creepers[0].fuse,90);const x=v.creepers[0].x;
 s.frames(89,far);v=s.control.view();assert.equal(v.creepers[0].x,x);assert.equal(v.creepers[0].fuse,1);assert(s.geometry.some(g=>g.id==='breakable'));assert(s.events.some(e=>e.type==='sound'&&e.event==='mc-fuse'));
 s.step(far);assert.equal(s.control.view().creepers[0].state,'exploded');assert.equal(s.geometry.some(g=>g.id==='breakable'),false);assert(s.geometry.some(g=>g.id==='floor'));assert.equal(s.damage.length,0);assert.equal(s.control.view().effects.filter(e=>e.kind==='explosion').length,1);s.frames(300,near);assert.equal(s.events.filter(e=>e.event==='creeper-exploded').length,1);assert.equal(s.damage.length,0);
 const hurt=controller();hurt.frames(91,near);assert.equal(hurt.damage.length,1);assert.equal(hurt.damage[0].kind,'explosion');
});

test('sand starts only after real support removal, sweeps to the floor, stacks without overlap and becomes stable',()=>{
 const s=controller();s.step({x:104,y:210,w:10,h:14});s.frames(90,{x:44,y:210,w:10,h:14});assert(s.control.view().sand.every(q=>q.state==='falling'));assert(s.geometry.filter(q=>q.id.startsWith('sand-')).every(q=>q.dy>0));
 s.frames(80,{x:0,y:210,w:10,h:14});const sand=s.control.view().sand;assert.deepEqual(sand.map(q=>[q.id,q.y,q.state]),[['sand-a',208,'settled'],['sand-b',192,'settled'],['sand-c',208,'settled']]);assert.equal(s.events.filter(e=>e.event==='sand-settled').length,3);assert.equal(s.events.filter(e=>e.event==='sand-started').length,3);
 const saved=JSON.stringify(sand);s.frames(120);assert.equal(JSON.stringify(s.control.view().sand),saved);for(const q of sand){const g=s.geometry.find(g=>g.id===q.id);assert.equal(g.collision,'solid');assert.equal(g.y,q.y);assert.equal(g.dy,0);assert(!s.geometry.some(g=>g.id!==q.id&&q.x<g.x+g.w&&q.x+q.w>g.x&&q.y<g.y+g.h&&q.y+q.h>g.y));}
 const motor=createPlatformMotor(),p=motor.create(character,{x:178,y:160});for(let i=0;i<60;i++)motor.step(p,{},character,{solids:s.geometry,width:384});assert.equal(p.support,'sand-b');assert.equal(p.y,178);assert.equal(p.grounded,true);
});

test('single thin support cannot be tunneled through; the same moving solid carries a native rider',()=>{
 const d=fixture(),r=d.rooms[0];r.minecraft.creepers=[];r.minecraft.destructibleIds=[];r.minecraft.sandIds=['sand-a'];r.map.geometry=[solid('floor',0,224,384,16),solid('shelf',160,200,64,1),solid('sand-a',176,32,16,16)];const s=controller(d),motor=createPlatformMotor(),p=motor.create(character,{x:178,y:18});p.grounded=true;p.support='sand-a';
 for(let i=0;i<100;i++){s.step(p);motor.step(p,{},character,{solids:s.geometry,width:384});}assert.equal(s.control.view().sand[0].y,184);assert.equal(p.support,'sand-a');assert.equal(p.y,170);assert.equal(s.damage.length,0);
});

test('falling sand uses a swept head hit and cannot silently pass through the player',()=>{
 const d=fixture(),r=d.rooms[0];r.minecraft.creepers=[];r.minecraft.destructibleIds=[];r.minecraft.sandIds=['sand-a'];r.map.geometry=[solid('floor',0,224,384,16),solid('sand-a',176,32,16,16)];const s=controller(d),p={x:178,y:160,w:10,h:14};s.frames(40,p);assert(s.damage.some(e=>e.kind==='falling-sand'&&e.actorId==='sand-a'));
});

test('creeper respects ground, walls, occlusion, paused ticks, and idempotent per-tick calls',()=>{
 const d=fixture(),r=d.rooms[0];r.minecraft.sandIds=[];r.minecraft.destructibleIds=[];r.map.geometry=[solid('floor',0,224,384,16),solid('wall',176,144,16,80)];const s=controller(d);s.frames(100,{x:224,y:210,w:10,h:14});assert.equal(s.control.view().creepers[0].state,'idle');assert.equal(s.control.view().creepers[0].x,132);assert.equal(s.control.view().creepers[0].y,196);
 s.step({x:104,y:210,w:10,h:14});const armed=JSON.stringify(s.control.view());s.control.step({tick:s.tick,geometry:s.geometry,player:{x:104,y:210,w:10,h:14}});assert.equal(JSON.stringify(s.control.view()),armed);s.control.pause();s.frames(20,{x:104,y:210,w:10,h:14});assert.equal(JSON.stringify(s.control.view()),armed);s.control.pause(false);s.step({x:104,y:210,w:10,h:14});assert.equal(s.control.view().creepers[0].fuse,89);
});

test('native stage blast death restores exact authored solids and creeper at the reached checkpoint',()=>{
 const d=fixture(),r=d.rooms[0];r.map.objects=[rect('start',104,210,10,14,{kind:'spawn'}),rect('save',48,210,10,14,{kind:'spawn'}),rect('checkpoint',104,192,16,32,{kind:'checkpoint',targetSpawn:'save'})];const events=[];const stage=createPlatformStage({plan:{stage:{entryRoom:'main',entrySpawn:'start',title:'Neutral voxel physics contract'},character,rooms:{main:r.map}},motor:createPlatformMotor(),visualRooms:d.rooms,emit:(type,data)=>events.push({type,...data})});
 stage.step({});assert.equal(stage.view().checkpoint.spawnId,'save');for(let i=0;i<90;i++)stage.step({});let v=stage.view();assert.equal(v.p.dying,true);assert.equal(v.lives,2);assert.equal(v.geometry.some(g=>g.id==='breakable'),false);assert.equal(v.minecraft.creepers[0].dead,true);
 for(let i=0;i<104;i++)stage.step({});v=stage.view();assert.equal(!!v.p.dying,false);assert.equal(v.p.x,48);assert.equal(v.lives,2);assert(v.geometry.some(g=>g.id==='breakable'));assert.equal(v.minecraft.creepers[0].dead,false);assert.equal(v.minecraft.creepers[0].fuse,0);assert.deepEqual(v.minecraft.sand.map(q=>q.y),[128,112,128]);assert(events.some(e=>e.type==='sound'&&e.event==='mc-fuse-stop'));
});


test('R10 creeper cancels on distance/LOS loss, preserves support and cleanly rearms',()=>{
 const s=controller(),near={x:104,y:210,w:10,h:14};s.step(near);s.frames(15,near);s.step({x:0,y:210,w:10,h:14});let q=s.control.view().creepers[0];assert.equal(q.state,'idle');assert.equal(q.fuse,0);assert.equal(q.flash,false);assert(s.geometry.some(g=>g.id==='breakable'));assert(s.events.some(e=>e.event==='creeper-disarmed'&&e.reason==='distance'));assert(s.events.some(e=>e.event==='mc-fuse-stop'));s.step(near);assert.equal(s.control.view().creepers[0].fuse,90);s.geometry.push(solid('temporary-cover',116,180,8,44));s.step(near);assert.equal(s.control.view().creepers[0].state,'idle');assert(s.events.some(e=>e.event==='creeper-disarmed'&&e.reason==='occluded'));assert.equal(s.events.filter(e=>e.event==='creeper-exploded').length,0);s.control.reset();assert.equal(s.control.view().creepers[0].state,'idle');
});
test('R10 cancelling one fuse restarts remaining active fuse audio and target loss cancels',()=>{
 const d=fixture();d.rooms[0].minecraft.creepers.push({id:'second',x:156,y:196,triggerRadius:48,speed:0});const s=controller(d),p={x:116,y:210,w:10,h:14};s.step(p);assert(s.control.view().creepers.every(q=>q.state==='fuse'));s.step({x:46,y:210,w:10,h:14});assert.equal(s.control.view().creepers.filter(q=>q.state==='fuse').length,1);assert.equal(s.events.filter(e=>e.event==='mc-fuse').length,3);s.step({...p,dying:true});assert(s.control.view().creepers.every(q=>q.state==='idle'));
});

test('current-frame directional shield handles creeper blast without protecting terrain or reflecting explosion',()=>{
 for(const [mode,expected] of [['perfect',0],['held',.5],['rear',1]]){const r=fixture().rooms[0];r.minecraft.gear={version:1,shield:true,stands:[]};const events=[],damage=[],c=createMinecraftController(r,{emit:(type,e)=>events.push({type,...e}),hurtPlayer:e=>damage.push(e)}),p={x:104,y:196,w:10,h:28,facing:mode==='rear'?-1:1,vx:0,vy:0,grounded:true};let geometry=structuredClone(r.map.geometry);for(let tick=1;tick<=91;tick++){const shield=mode==='held'?tick>=75:tick===91;geometry=c.step({tick,input:{shield},player:p,geometry}).geometry;}const blast=events.find(e=>e.event==='creeper-exploded');assert(blast);assert.equal(blast.damage,expected);assert.equal(blast.parried,mode==='perfect');assert.equal(damage.length,expected?1:0);assert(!geometry.some(g=>g.id==='breakable'));assert.equal(events.filter(e=>e.event==='creeper-exploded').length,1);assert.equal(c.view().gear.projectiles.length,0);}
});

test('earned trident can defeat demolition creeper, then safe replacement prevents a permanent gate softlock',()=>{const r=fixture().rooms[0];r.minecraft.gear={version:1,shield:true,loyaltyTrident:true,stands:[]};r.minecraft.creepers[0].triggerRadius=16;const events=[],c=createMinecraftController(r,{emit:(type,e)=>events.push({type,...e})}),p={x:104,y:196,w:10,h:28,facing:1,vx:0,vy:0,grounded:true};let geometry=structuredClone(r.map.geometry),tick=0;for(;tick<300&&!c.view().creepers[0].dead;){tick++;geometry=c.step({tick,player:p,input:{attack:tick%23===1},geometry}).geometry;}assert.equal(c.view().creepers[0].state,'defeated');assert(geometry.some(g=>g.id==='breakable'));assert.equal(events.filter(e=>e.event==='creeper-weapon-hit').length,2);p.x=0;for(let n=0;n<181;n++){geometry=c.step({tick:++tick,player:p,input:{},geometry}).geometry;}assert.equal(c.view().creepers[0].dead,false);assert.equal(c.view().creepers[0].hp,2);assert.equal(events.filter(e=>e.event==='creeper-replaced').length,1);assert(geometry.some(g=>g.id==='breakable'));});
