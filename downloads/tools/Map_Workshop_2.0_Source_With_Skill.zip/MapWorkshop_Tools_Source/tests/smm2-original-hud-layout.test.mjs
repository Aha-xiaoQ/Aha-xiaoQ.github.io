import test from 'node:test';
import assert from 'node:assert/strict';
import {createCanvas} from '@napi-rs/canvas';
import {drawHud,drawPixelText} from '../atlas/editor-art.mjs';

const white=data=>Array.from({length:data.length/4},(_,n)=>data[n*4]===255&&data[n*4+1]===255&&data[n*4+2]===255&&data[n*4+3]===255);
function withCanvas(fn){const prior=globalThis.document;globalThis.document={createElement:()=>createCanvas(1,1)};try{return fn();}finally{globalThis.document=prior;}}
function state(width,extra={}){return {viewportWidth:width,p:{},lives:4,coins:23,score:13090,timeLeft:118,smm2Mechanics:{version:1},...extra};}
function draw(v){const c=createCanvas(v.viewportWidth,216).getContext('2d');drawHud(c,v);return c;}
function glyphsAt(c,text,x,y){const expected=createCanvas(text.length*8,7).getContext('2d');drawPixelText(expected,text,0,0);assert.deepEqual(white(c.getImageData(x,y,text.length*8,7).data),white(expected.getImageData(0,0,text.length*8,7).data),text+' appears at its source-like baseline');}

test('real raster aligns Mario/lives and coin rows at left, nine-digit score and clock/time at right for every supported width',()=>withCanvas(()=>{
 for(const width of [256,384,512]){
  const v=state(width),before=JSON.stringify(v),c=draw(v);
  glyphsAt(c,'×04',24,12);glyphsAt(c,'×23',24,26);glyphsAt(c,'000013090',width-128,12);glyphsAt(c,'118',width-36,12);
  assert(c.getImageData(14,8,12,12).data.some((value,n)=>n%4===3&&value),'native Mario thumbnail occupies the first-row icon slot');
  assert(c.getImageData(16,24,8,10).data.some((value,n)=>n%4===3&&value),'coin thumbnail occupies the same aligned icon column');
  assert.equal(c.getImageData(8,8,1,1).data[3],0,'left margin is transparent');
  assert.equal(c.getImageData(width-8,12,1,1).data[3],0,'right margin is transparent');
  assert(c.getImageData(width-48,12,8,7).data.some((value,n)=>n%4===0&&value===255),'the explicit adapted clock glyph is present');
  assert.deepEqual(c.getImageData(64,31,67,9).data,new Uint8ClampedArray(67*9*4),'the misplaced LIFE label is gone');
  assert.equal(JSON.stringify(v),before);
 }
}));

test('actual lives change only the first left row while actual coins change only the second',()=>withCanvas(()=>{
 const a=draw(state(384)),life=draw(state(384,{lives:3})),coin=draw(state(384,{coins:24}));
 assert.notDeepEqual(a.getImageData(23,11,26,9).data,life.getImageData(23,11,26,9).data);
 assert.deepEqual(a.getImageData(12,23,40,12).data,life.getImageData(12,23,40,12).data);
 assert.deepEqual(a.getImageData(12,7,40,14).data,coin.getImageData(12,7,40,14).data);
 assert.notDeepEqual(a.getImageData(23,25,26,9).data,coin.getImageData(23,25,26,9).data);
}));

test('dense pink/P/key feedback and battle HP never alter or cover the two primary HUD rows',()=>withCanvas(()=>{
 for(const width of [256,384,512]){
  const v=state(width,{contraptions:{keys:1,pFrames:600},smm2Mechanics:{version:1,pinkCoins:{total:128,taken:77,keyReleased:false}},castle:{battle:{hp:3,maxHp:6,cue:'OPEN',exposed:true}}}),before=JSON.stringify(v),actual=draw(v),base=draw(state(width));
  assert.deepEqual(actual.getImageData(0,0,width,36).data,base.getImageData(0,0,width,36).data);
  const all=actual.getImageData(0,40,width,176).data;assert(all.some((value,n)=>n%4===0&&value===255&&all[n+1]===128&&all[n+2]===170),'pink progress remains visible');
  assert(all.some((value,n)=>n%4===0&&value===131&&all[n+1]===232&&all[n+2]===107),'actual exposed HP remains visible');
  assert.equal(JSON.stringify(v),before);
 }
}));

test('only an actual world-key follower suppresses the duplicate inventory-key HUD',()=>withCanvas(()=>{
 const oldView=state(384,{contraptions:{keys:1}}),empty=state(384,{contraptions:{keys:1,keyFollowers:[]}}),following=state(384,{contraptions:{keys:1,keyFollowers:[{id:'carried-key',kind:'key',x:150,y:140,w:16,h:16,sourceItemId:'note-key'}]}});
 const a=draw(oldView),b=draw(empty),c=draw(following);
 assert.deepEqual(a.getImageData(0,0,384,216).data,b.getImageData(0,0,384,216).data,'old and empty-array views retain actual key feedback');
 assert(a.getImageData(12,40,40,12).data.some((value,n)=>n%4===3&&value),'the old-view inventory key remains visible');
 assert.deepEqual(c.getImageData(12,40,40,12).data,new Uint8ClampedArray(40*12*4));
 assert.deepEqual(a.getImageData(0,0,384,36).data,c.getImageData(0,0,384,36).data,'life/coin rows never move to make room for a key');
}));
