import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createNpcSpringContacts,validateNpcSpringContactSpec} from '../atlas/editor-npc-spring-contacts.mjs';

// Native room-local rectangles actually measured in the COMPLETE Story Job71
// R3 source. These are contact fixtures, not a substitute/example course. The
// original clip's red regular Koopa compresses the Spring at 1083.600000s and
// is airborne by 1083.700000s; observed sprite rise is about72.45px (4.53tiles).
// Collision size, gravity and launchSpeed below are explicitly authored fits.
const R3_RECTS=[
 ['ceiling',0,-16,384,16,'ground'],['upper-left-wall',0,0,16,32,'ground'],
 ['upper-right-wall',288,0,96,128,'ground'],['upper-left-mass',0,32,128,96,'ground'],
 ['lower-left-wall',0,128,16,48,'ground'],['separator',96,128,288,16,'ground'],
 ['lower-right-wall',368,144,16,32,'ground'],['lower-floor',0,176,384,32,'ground'],
 ['blue-bottom-left',128,112,64,16,'onoff-blue'],['blue-bottom-right',208,112,64,16,'onoff-blue'],
 ['spring',272,112,16,16,'spring']
];
const geometry=()=>R3_RECTS.map(([id,x,y,w,h,material])=>({id,x,y,w,h,material,collision:'solid',dx:0,dy:0}));
const spec=(extra={})=>({id:'spring',compressionFrames:6,launchSpeed:6.75,compressionDepth:7.2,...extra});
const body=(extra={})=>({id:'regular-koopa',type:'koopa',npcSpringEligible:true,x:273,y:88,w:14,h:24,vx:.5,vy:0,grounded:true,support:'spring',direction:1,source:{red:true},...extra});
const near=(a,b,eps=1e-7)=>assert.ok(Math.abs(a-b)<=eps,`${a} != ${b}`);
const overlapX=(a,q)=>a.x+a.w>q.x+1e-7&&a.x<q.x+q.w-1e-7;

// A caller-owned swept collision port. It resolves vertical motion against
// actual solid tops/undersides, so roof clearance is exercised as a movement
// constraint, not a boolean injected into the Spring controller.
function verticalSweep(actor,delta,{geometry:solids}){
 let fraction=1,blocked=null;
 for(const q of solids){
  if(q.hidden||q.collision!=='solid'||!overlapX(actor,q))continue;
  let f=null,normal=null;
  if(delta.y>0&&actor.y+actor.h<=q.y+1e-7&&actor.y+actor.h+delta.y>=q.y){f=(q.y-actor.y-actor.h)/delta.y;normal={x:0,y:-1};}
  if(delta.y<0&&actor.y>=q.y+q.h-1e-7&&actor.y+delta.y<=q.y+q.h){f=(q.y+q.h-actor.y)/delta.y;normal={x:0,y:1};}
  if(f!==null&&f>=0&&f<=fraction){fraction=f;blocked={solidId:q.id,normal,fraction:f};}
 }
 return {body:{x:actor.x+delta.x*fraction,y:actor.y+delta.y*fraction},blocked,reached:fraction===1};
}
function setup(extra={}){
 const events=[],c=createNpcSpringContacts([spec(extra)],{emit:(type,q)=>events.push({type,...q})}),actor=body();let g=geometry(),tick=0;
 const h={c,actor,events,get g(){return g;},get tick(){return tick;},setGeometry(q){g=q;},contact(before={...actor,y:86,vy:1}){const result=c.afterActor(actor,before,{tick,geometry:g});g=c.geometry(g);return result;},step(){tick++;const result=c.frame({tick,actors:[actor],geometry:g,resolveBodyMotion:verticalSweep});g=result.geometry;return result;}};
 return h;
}

test('strict reusable NPC leaf requires explicit authored duration and impulse',()=>{
 assert.equal(validateNpcSpringContactSpec(spec()),true);
 for(const bad of [null,[],{id:'spring',launchSpeed:6.75},{id:'spring',compressionFrames:6},spec({compressionFrames:0}),spec({compressionFrames:1.5}),spec({launchSpeed:Infinity}),spec({launchSpeed:-1}),spec({compressionDepth:0}),spec({autoLaunch:true}),spec({actorId:'regular-koopa'}),Object.assign(Object.create({}),spec())])assert.throws(()=>validateNpcSpringContactSpec(bad));
 assert.throws(()=>createNpcSpringContacts([spec(),spec()]),/Duplicate/);
 const c=createNpcSpringContacts([spec({compressionDepth:16})]);assert.throws(()=>c.afterActor(body(),body(),{tick:0,geometry:geometry()}),/positive body/);
});

test('ordinary caller gravity reaches the real R3 Spring, compresses briefly, then launches with no input',()=>{
 const h=setup(),a=h.actor;Object.assign(a,{y:77,vy:0,grounded:false,support:null});let contactTick=null,launchTick=null,minH=16;
 for(let n=0;n<30;n++){
  const frame=h.step();minH=Math.min(minH,h.g.find(q=>q.id==='spring').h);
  if(frame.launchedActorIds.length){launchTick=h.tick;near(a.vy,-6.75);assert(!a.grounded);assert.equal(a.support,null);break;}
  if(!frame.ownedActorIds.includes(a.id)){
   const before={...a};a.vy=Math.min(5,a.vy+.3);const placed=verticalSweep(a,{x:0,y:a.vy},{geometry:h.g});a.y=placed.body.y;a.grounded=placed.blocked?.normal.y<0;a.support=a.grounded?placed.blocked.solidId:null;if(a.grounded)a.vy=0;
   const contact=h.c.afterActor(a,before,{tick:h.tick,geometry:h.g});if(contact.started)contactTick=h.tick;h.setGeometry(h.c.geometry(h.g));
  }
 }
 assert(contactTick!==null);assert.equal(launchTick-contactTick,6);assert(minH<16);near(h.g.find(q=>q.id==='spring').h,16);near(a.vx,.5);assert.equal(a.direction,1);assert.deepEqual(a.source,{red:true});
 assert.equal(h.events.filter(e=>e.event==='launch').length,1);
 // Continue actual gravity after release. The authored discrete trajectory
 // matches the observed rise, while the controller supplies no gravity itself.
 const releaseY=a.y;let apexY=a.y;
 for(let n=0;n<50;n++){a.vy+=.3;a.y+=a.vy;apexY=Math.min(apexY,a.y);}
 near(releaseY-apexY,72.45,1.6);
});

test('NPC intrinsic leftward direction and velocity survive automatic compression/release',()=>{
 const h=setup();h.actor.vx=-.6;h.actor.direction=-1;h.contact();for(let n=0;n<6;n++)h.step();near(h.actor.vx,-.6);assert.equal(h.actor.direction,-1);near(h.actor.vy,-6.75);
});

test('airborne, side, underside, wrong support and ineligible bodies cannot acquire a bounce',()=>{
 const cases=[
 {current:{grounded:false,support:null,y:87.5},before:{y:85,vy:1}},
 {current:{y:96},before:{y:96,x:250,vx:2}},
 {current:{y:129,vy:-2,grounded:false,support:null},before:{y:131,vy:-2}},
 {current:{support:'blue-bottom-right'},before:{}},
 {current:{vy:-1},before:{vy:-1}},
 {current:{x:288},before:{x:288}},
 {current:{x:271,y:88.8},before:{x:250,y:87.8,vy:2}},
 ...['dead','dying','removed','taken','emerge','emerging','moduleEmergence'].map(k=>({current:{[k]:true},before:{}})),
 {current:{active:false},before:{}},{current:{npcSpringEligible:false},before:{}},{current:{kind:'player'},before:{}}
 ];
 for(const {current,before}of cases){const h=setup();Object.assign(h.actor,current);const old={...h.actor,...before};const contact=h.contact(old);assert.equal(contact.started,false,JSON.stringify(current));assert.equal(h.c.ownsActor(h.actor),false);assert.equal(h.events.length,0);}
});

test('static vertical-only ownership rejects side springs, hidden solids, moved carriers and legacy player compression',()=>{
 for(const change of [{springOrientation:'horizontal'},{orientation:'horizontal'},{hidden:true},{active:false},{dx:.1},{dy:-1},{vy:1},{springAge:1},{material:'stone'},{collision:'oneway'}]){
  const h=setup();Object.assign(h.g.find(q=>q.id==='spring'),change);assert(!h.contact().started,JSON.stringify(change));
 }
});

test('standing/restored top contact can acquire without a new impact, but deep overlap cannot',()=>{
 const h=setup();assert(h.contact({...h.actor}).started);assert(h.c.ownsActor(h.actor));
 const second=setup();second.actor.y+=3;assert(!second.contact({...second.actor}).started);assert(!second.c.ownsActor(second.actor));
});

test('geometry projection preserves immutable source rectangles, legacy clocks and bottom anchoring',()=>{
 const h=setup(),original=geometry().map(q=>Object.freeze({...q,springAge:0}));Object.freeze(original);const saved=structuredClone(original);h.setGeometry(original);h.contact();const compressed=h.step(),q=compressed.geometry.find(q=>q.id==='spring');
 assert.equal(q.npcSpringOwned,true);assert.equal(q.npcSpringActorId,h.actor.id);assert(q.y>112&&q.h<16);near(q.y+q.h,128);assert.equal(q.springAge,0);assert.deepEqual(original,saved);
 for(let n=1;n<6;n++)h.step();const released=h.g.find(q=>q.id==='spring');assert.equal(released.npcSpringOwned,undefined);assert.equal(released.springAge,0);near(released.y,112);near(released.h,16);
 const view=h.c.view();view.springs[0].rest.y=999;assert.equal(h.c.view().springs[0].rest.y,112);
});

test('frame and afterActor share one tick clock, so repeated calls cannot age or launch twice',()=>{
 const h=setup();h.contact();assert.equal(h.contact().started,false);for(let n=0;n<6;n++){
  const result=h.step(),age=h.c.view().springs[0].age,y=h.actor.y;
  const again=h.c.frame({tick:h.tick,actors:[h.actor],geometry:h.g,resolveBodyMotion:()=>{throw Error('duplicate sweep');}});assert.deepEqual(again.ownedActorIds,result.ownedActorIds);assert.equal(h.actor.y,y);assert.equal(h.c.view().springs[0].age,age);
  const before={...h.actor,vy:1};h.c.afterActor(h.actor,before,{tick:h.tick,geometry:h.g});
 }
 assert.equal(h.events.filter(e=>e.event==='launch').length,1);assert.throws(()=>h.c.frame({tick:1,geometry:h.g}),/backwards/);
});

test('afterActor before frame on the same tick cannot advance a new compression',()=>{
 const h=setup();assert(h.contact().started);const result=h.c.frame({tick:0,actors:[h.actor],geometry:h.g,resolveBodyMotion:verticalSweep});assert.deepEqual(result.ownedActorIds,[h.actor.id]);assert.equal(h.c.view().springs[0].age,0);near(h.actor.y,88);
});

test('a real roof blocks return to the rest top; no launch or upward snap crosses it',()=>{
 const h=setup();h.contact();h.step();h.step();h.step();near(h.actor.y,95.2);
 // A newly active ceiling genuinely leaves enough room at full compression,
 // but less than the rest height. Release must obey caller swept clearance.
 h.setGeometry([...h.g,{id:'active-roof',x:272,y:78,w:16,h:16,collision:'solid',material:'onoff-red'}]);
 const result=h.step();assert.deepEqual(result.interruptedActorIds,[h.actor.id]);assert.deepEqual(result.launchedActorIds,[]);near(h.actor.y,94);assert.equal(h.actor.support,null);assert.equal(h.actor.grounded,false);near(h.actor.vy,0);assert(h.actor.y>=94);assert.equal(h.events.at(-1).blocked.solidId,'active-roof');
 for(let n=0;n<5;n++)h.step();assert.equal(h.events.filter(e=>e.event==='launch').length,0);
});

test('caller sweep receives actual geometry without only its owned Spring and can stop a wall obstruction',()=>{
 const h=setup();h.contact();const blocker={id:'contact-wall',x:273,y:89,w:14,h:16,collision:'solid',material:'ground'};h.setGeometry([...h.g,blocker]);
 const result=h.c.frame({tick:1,actors:[h.actor],geometry:h.g,resolveBodyMotion:(a,d,ctx)=>{
  assert(!ctx.geometry.some(q=>q.id==='spring'));assert(ctx.geometry.some(q=>q.id==='upper-right-wall'));assert(ctx.geometry.some(q=>q.id==='contact-wall'));assert.deepEqual(ctx.excludeIds,['spring']);
  return {body:{x:a.x,y:a.y},blocked:{solidId:'contact-wall',normal:{x:-1,y:0}},reached:false};
 }});assert.deepEqual(result.interruptedActorIds,[h.actor.id]);near(h.actor.y,88);assert.equal(h.actor.support,null);assert.equal(h.actor.grounded,false);
});

test('leaving the footprint, dying, or losing the live Spring clears ownership and prevents ghost launch',()=>{
 for(const change of ['walk-away','dead','missing-spring','missing-actor','displaced-spring']){
  const h=setup();h.contact();h.step();let actors=[h.actor];
  if(change==='walk-away')h.actor.x=288;if(change==='dead')h.actor.dead=true;if(change==='missing-spring')h.setGeometry(h.g.filter(q=>q.id!=='spring'));if(change==='missing-actor')actors=[];if(change==='displaced-spring')h.g.find(q=>q.id==='spring').x++;
  const result=h.c.frame({tick:2,actors,geometry:h.g,resolveBodyMotion:verticalSweep});assert(!h.c.ownsActor(h.actor),change);assert.equal(h.actor.grounded,false,change);assert.equal(h.actor.support,null,change);assert.deepEqual(result.launchedActorIds,[]);assert.equal(h.events.filter(e=>e.event==='launch').length,0);
 }
});

test('afterActor immediately notices a body walking off during owned compression',()=>{
 const h=setup();h.contact();h.step();const before={...h.actor};h.actor.x=288;const result=h.c.afterActor(h.actor,before,{tick:1,geometry:h.g});assert(result.interrupted);assert(!result.skipLegacyGravity);assert(!h.actor.grounded);assert.equal(h.actor.support,null);
});

test('pause does not age a compression across skipped ticks; resume uses one caller tick',()=>{
 const h=setup();h.contact();h.step();const y=h.actor.y,age=h.c.view().springs[0].age;h.c.pause();
 for(let tick=2;tick<=20;tick++)h.c.frame({tick,actors:[h.actor],geometry:h.g});near(h.actor.y,y);assert.equal(h.c.view().springs[0].age,age);h.c.pause(false);
 h.c.frame({tick:21,actors:[h.actor],geometry:h.g,resolveBodyMotion:verticalSweep});assert.equal(h.c.view().springs[0].age,age+1);
});

test('stable spring/actor associations support independent contacts and reject duplicate live IDs',()=>{
 const g=geometry(),second={id:'second-spring',x:160,y:88,w:16,h:16,material:'spring',collision:'solid'};g.push(second);
 const a=body(),b=body({id:'second-koopa',x:161,y:64,support:'second-spring',vx:-.5});const c=createNpcSpringContacts([spec(),spec({id:'second-spring',compressionFrames:3,launchSpeed:4})]);
 c.afterActor(a,{...a,y:86,vy:1},{tick:0,geometry:g});c.afterActor(b,{...b,y:62,vy:1},{tick:0,geometry:g});
 const occupied=body({id:'late-koopa'});assert(!c.afterActor(occupied,{...occupied,y:86,vy:1},{tick:0,geometry:g}).started);
 assert.throws(()=>c.frame({tick:1,actors:[a,{...a}],geometry:g,resolveBodyMotion:verticalSweep}),/Duplicate.*actor/);
 let projected=c.geometry(g);for(let tick=1;tick<=3;tick++){const result=c.frame({tick,actors:[a,b],geometry:projected,resolveBodyMotion:verticalSweep});projected=result.geometry;if(tick===3){assert.deepEqual(result.launchedActorIds,[b.id]);assert.deepEqual(result.ownedActorIds,[a.id]);}}
 near(b.vy,-4);near(a.vy,0);assert.equal(a.support,'spring');
});

test('reset clears live support and old clocks, while detached snapshot restores deterministic continuation',()=>{
 const h=setup();h.contact();h.step();h.step();const saved=h.c.snapshot(),g=structuredClone(h.g),a=structuredClone(h.actor),other=createNpcSpringContacts([spec()]);other.restore(saved);
 saved.states[0].rest.y=999;assert.equal(other.view().springs[0].rest.y,112);
 let otherG=g;for(let tick=3;tick<=6;tick++){const first=h.step(),second=other.frame({tick,actors:[a],geometry:otherG,resolveBodyMotion:verticalSweep});otherG=second.geometry;assert.deepEqual(a,h.actor);assert.deepEqual(second,first);}
 const active=setup();active.contact();active.step();active.c.reset();assert(!active.actor.grounded);assert.equal(active.actor.support,null);assert.equal(active.c.view().tick,null);assert(!active.c.ownsActor(active.actor));
 assert.throws(()=>createNpcSpringContacts([spec({launchSpeed:4})]).restore(h.c.snapshot()),/different definitions/);
});

test('a genuine subsequent landing can start a second bounce after release',()=>{
 const h=setup();h.contact();for(let n=0;n<6;n++)h.step();const before={...h.actor,y:86,vy:2};Object.assign(h.actor,{y:88,vy:0,grounded:true,support:'spring'});
 assert.equal(h.c.afterActor(h.actor,before,{tick:6,geometry:h.g}).started,false,'release tick cannot re-acquire');
 assert.equal(h.c.afterActor(h.actor,before,{tick:7,geometry:h.g}).started,true);assert.equal(h.events.filter(e=>e.event==='compression-start').length,2);
});

test('a repeated frame exposes late top acquisition without advancing it',()=>{
 const h=setup();assert.deepEqual(h.c.frame({tick:0,actors:[h.actor],geometry:h.g}).ownedActorIds,[]);h.contact();
 const again=h.c.frame({tick:0,actors:[h.actor],geometry:h.g,resolveBodyMotion:()=>{throw Error('same tick');}});assert.deepEqual(again.ownedActorIds,[h.actor.id]);assert.equal(h.c.view().springs[0].age,0);near(h.actor.y,88);
});

test('an invalid movement port can be corrected within the same tick without consuming compression time',()=>{
 const h=setup();h.contact();assert.throws(()=>h.c.frame({tick:1,actors:[h.actor],geometry:h.g,resolveBodyMotion:()=>null}),/placement result/);
 assert.equal(h.c.view().springs[0].age,0);near(h.actor.y,88);const result=h.c.frame({tick:1,actors:[h.actor],geometry:h.g,resolveBodyMotion:verticalSweep});assert.deepEqual(result.ownedActorIds,[h.actor.id]);assert.equal(h.c.view().springs[0].age,1);
});

test('a partial multi-Spring retry cannot age an already resolved actor twice',()=>{
 const g=[...geometry(),{id:'second-spring',x:160,y:88,w:16,h:16,material:'spring',collision:'solid'}],a=body(),b=body({id:'second-koopa',x:161,y:64,support:'second-spring'}),c=createNpcSpringContacts([spec(),spec({id:'second-spring'})]);
 c.afterActor(a,{...a,y:86,vy:1},{tick:0,geometry:g});c.afterActor(b,{...b,y:62,vy:1},{tick:0,geometry:g});
 assert.throws(()=>c.frame({tick:1,actors:[a,b],geometry:g,resolveBodyMotion:(actor,delta,ctx)=>actor.id===b.id?null:verticalSweep(actor,delta,ctx)}),/placement result/);
 const y=a.y,result=c.frame({tick:1,actors:[a,b],geometry:g,resolveBodyMotion:verticalSweep});near(a.y,y);assert.deepEqual(result.ownedActorIds,[a.id,b.id]);assert.deepEqual(c.view().springs.map(q=>q.age),[1,1]);
});
