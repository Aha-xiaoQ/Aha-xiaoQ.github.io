import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
import {offlineFile} from '../atlas/editor-offline.mjs';
import {shellProject,nativeSession} from './fixtures/shell-coin-native.mjs';

test('standalone HTML embeds the opt-in and executes real activated-shell pink collection without network',async()=>{
 const project=shellProject({pink:true}),s=nativeSession(project),root=new URL('../atlas/',import.meta.url),html=await offlineFile(s.pack,s.doc.rooms,p=>fs.promises.readFile(new URL(p,root),'utf8'),p=>fs.promises.readFile(new URL('assets/classic-audio/'+p,root)));
 assert(html.includes('"shellCoinCollection":true'));
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'Shell Coin Offline QA ')),htmlPath=path.join(dir,'fixture.html'),projectPath=path.join(dir,'fixture.qmap.json');
 try{fs.writeFileSync(htmlPath,html);fs.writeFileSync(projectPath,JSON.stringify(s.doc));const result=spawnSync(process.execPath,['--experimental-vm-modules',fileURLToPath(new URL('../scripts/check-shell-coin-offline.mjs',import.meta.url)),htmlPath,projectPath],{encoding:'utf8',timeout:30000,maxBuffer:1024*1024});assert.equal(result.status,0,result.stderr||result.stdout||String(result.error));const report=JSON.parse(result.stdout);assert.equal(report.actualEmbeddedStageExecuted,true);assert.equal(report.networkRequests,0);assert.equal(report.physicalShellPickups,3);assert.equal(report.keyRewards,1);
 if(process.env.SHELL_COIN_EVIDENCE_DIR){fs.mkdirSync(process.env.SHELL_COIN_EVIDENCE_DIR,{recursive:true});fs.writeFileSync(path.join(process.env.SHELL_COIN_EVIDENCE_DIR,'offline-shell-coin.html'),html);fs.writeFileSync(path.join(process.env.SHELL_COIN_EVIDENCE_DIR,'offline-shell-coin.qmap.json'),JSON.stringify(s.doc,null,2)+'\n');fs.writeFileSync(path.join(process.env.SHELL_COIN_EVIDENCE_DIR,'offline-shell-coin-report.json'),JSON.stringify(report,null,2)+'\n');}
 }finally{fs.rmSync(dir,{recursive:true,force:true});}
});
