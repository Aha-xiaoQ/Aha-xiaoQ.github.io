import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
import {offlineFile} from '../atlas/editor-offline.mjs';
import {createCollection,addLevel,buildCollection} from '../atlas/editor-collection.mjs';
import {flowerProject,flowerSession,character} from './fixtures/flower-pipe-native.mjs';

for(const mode of ['single','collection'])test(mode+' offline HTML executes real flower collection, firepower recovery and checkpoint reset without network',async()=>{
 const project=flowerProject(),session=flowerSession(project),root=new URL('../atlas/',import.meta.url);
 const collection=mode==='collection'?buildCollection(addLevel(createCollection('Neutral flower supply offline'),project,{id:'flower-fixture'}),character,{includePending:true}):null;
 const html=await offlineFile(session.pack,session.doc.rooms,p=>fs.promises.readFile(new URL(p,root),'utf8'),p=>fs.promises.readFile(new URL('assets/classic-audio/'+p,root)),()=>{},collection?{collection}:{});
 assert(html.includes('"item":"flower"'));if(collection)assert(html.includes('flower-pipe-supply-v1'));
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'Neutral Flower Supply Offline '));
 try{
  const htmlPath=path.join(dir,'fixture.html'),projectPath=path.join(dir,'fixture.qmap.json');fs.writeFileSync(htmlPath,html);fs.writeFileSync(projectPath,JSON.stringify(project));
  const result=spawnSync(process.execPath,['--experimental-vm-modules',fileURLToPath(new URL('../scripts/check-flower-supply-offline.mjs',import.meta.url)),htmlPath,projectPath,mode],{encoding:'utf8',timeout:30000,maxBuffer:1024*1024});
  assert.equal(result.status,0,result.stderr||result.stdout||String(result.error));const report=JSON.parse(result.stdout);
  assert.equal(report.actualEmbeddedStageExecuted,true);assert.equal(report.actualEmbeddedMotorExecuted,true);assert.equal(report.networkRequests,0);assert.equal(report.finalPower,2);assert.equal(report.finalLives,2);assert.equal(report.sourceEmittedAfterRetry,2);assert(report.recoveredFireTick>report.hurtTick);assert(report.retryFireTick>report.retryTick);
 }finally{fs.rmSync(dir,{recursive:true,force:true});}
});
