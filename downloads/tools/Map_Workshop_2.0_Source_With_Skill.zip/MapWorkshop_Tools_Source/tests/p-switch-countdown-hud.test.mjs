import assert from 'node:assert/strict';
import {test} from 'node:test';
import {createCanvas} from '@napi-rs/canvas';
import {drawHud} from '../atlas/editor-art.mjs';

test('P HUD reads actual remaining frames with transparent outlined seconds and disappears on expiry',()=>{
 const prior=globalThis.document;globalThis.document={createElement:()=>createCanvas(1,1)};
 try {
  const draw=(frames)=>{const canvas=createCanvas(384,216),c=canvas.getContext('2d'),v={viewportWidth:384,p:{},lives:3,coins:2,score:400,timeLeft:390,smm2Mechanics:{version:1},contraptions:{pFrames:frames,keys:0}};const snapshot=JSON.stringify(v);drawHud(c,v);assert.equal(JSON.stringify(v),snapshot);return c;};
  const get=c=>c.getImageData(207,41,42,9).data;
  assert.deepEqual(get(draw(600)),get(draw(541)),'a partial last second still reads10');
  assert.notDeepEqual(get(draw(540)),get(draw(541)),'crossing into9 changes the real counter');
  assert.notDeepEqual(get(draw(1)),get(draw(0)),'last frame still reads1; expiry has no P countdown');
  assert.deepEqual(get(draw(0)),new Uint8ClampedArray(42*9*4));
  assert.deepEqual([...draw(600).getImageData(205,40,1,1).data],[0,0,0,0],'no panel around P');
  assert.deepEqual(get(draw(600)),get(draw(600)),'frozen game state has stable presentation');
  for(const rect of [[14,24,36,10],[23,11,26,9],[255,11,118,9]])assert.deepEqual(draw(600).getImageData(...rect).data,draw(0).getImageData(...rect).data,'existing feedback remains unchanged');
 }finally{globalThis.document=prior;}
});
