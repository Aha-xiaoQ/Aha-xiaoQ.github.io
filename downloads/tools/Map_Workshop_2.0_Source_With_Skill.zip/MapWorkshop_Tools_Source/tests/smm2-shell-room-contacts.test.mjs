import test from 'node:test';
import assert from 'node:assert/strict';
import {emptyShellProject,nativeSession,sideKickEmptyShell} from './fixtures/empty-shell-native.mjs';

test('real supplied shell resolves exact walls and falls through a sixteen-pixel slot',()=>{
 const d=emptyShellProject({coins:[],pink:false}),r=d.rooms[0];
 r.map.geometry=[{id:'upper',x:0,y:176,w:320,h:16,collision:'solid',material:'ground'},{id:'wall',x:336,y:0,w:16,h:288,collision:'solid',material:'stone'},{id:'lower',x:0,y:256,w:336,h:32,collision:'solid',material:'ground'},{id:'supply-pipe',x:96,y:64,w:32,h:64,collision:'solid',material:'pipe'}];
 r.map.objects[0].y=162;const s=nativeSession(d);sideKickEmptyShell(s);
 s.until(v=>v.enemies.some(e=>e.emptyShell&&e.grounded&&e.support==='lower'),{},250);
 const shell=s.view().enemies.find(e=>e.emptyShell);assert.equal(shell.y+shell.h,256);
 assert(s.trace.some(v=>v.enemies.some(e=>e.emptyShell&&Math.abs(e.x-320)<1e-6&&!e.grounded&&e.y>160&&e.y<192)),'shell occupies the actual slot after impact rather than staying at oldX on the ledge');
 assert(s.trace.every(v=>v.enemies.filter(e=>e.emptyShell).every(e=>e.x+e.w<=336+1e-6)),'wall face bounds are preserved');
 assert.equal(s.events.filter(e=>e.type==='sound'&&e.event==='death').length,0);
});

for(const kind of ['floor-piranha','muncher'])test('real shell contact respects '+kind+' defeat policy independently of walking crowd separation',()=>{
 const d=emptyShellProject({coins:[],pink:false}),r=d.rooms[0],h=kind==='floor-piranha'?24:16;
 r.map.objects.push({id:'stationary-enemy',kind:'walker',x:240,y:224-h,w:16,h});r.marioModules.enemyVariants['stationary-enemy']=kind==='floor-piranha'?{kind,size:'normal',winged:false}:{kind};
 const s=nativeSession(d);sideKickEmptyShell(s);s.frames(80);
 const hits=s.events.filter(e=>e.type==='smm2-shell'&&e.event==='enemy-hit');
 if(kind==='floor-piranha'){assert.equal(s.view().enemies.some(e=>e.id==='stationary-enemy'),false);assert.equal(hits.length,1);assert.equal(hits[0].victimId,'stationary-enemy');assert(s.view().score>0);}
 else{assert(s.view().enemies.some(e=>e.id==='stationary-enemy'));assert.equal(hits.length,0);assert.equal(s.view().score,0);}
 assert.equal(s.view().lives,3);assert.equal(s.events.filter(e=>e.type==='sound'&&e.event==='death').length,0);
});
