import test from 'node:test';
import assert from 'node:assert/strict';
import {createCanvas,loadImage} from '@napi-rs/canvas';
import {fileURLToPath} from 'node:url';
import {blank,parseProject} from '../atlas/editor-model.mjs';
import {drawSmm2SourceScenery,drawSmm2SourceCastle,drawSmm2Tile,drawSmm2Actor,drawSmm2SourceArrow} from '../atlas/editor-smm2-art.mjs';
import {drawScenery,drawTile} from '../atlas/editor-art.mjs';
const canvas=()=>createCanvas(384,432);
const pixels=c=>Buffer.from(c.getContext('2d').getImageData(0,0,c.width,c.height).data);
function room(){const r=blank('source scenery',384,432).rooms[0];r.smm2Mechanics={version:1,art:{palette:'smb1-overworld-source'}};r.nativeSceneryMode='authored';return r;}
test('authored source scenery shares identical editor/runtime pixels and never gains a collision body',()=>{
 const r=room(),q={id:'hill',x:32,y:348,w:144,h:44,material:'decoration',smm2Art:'source-scenery-hill'};r.decorations=[q];const before=JSON.stringify(r),direct=canvas(),editor=canvas(),runtime=canvas();
 assert.equal(drawSmm2SourceScenery(direct.getContext('2d'),q,r),true);assert.equal(drawSmm2Tile(editor.getContext('2d'),q,r),true);drawScenery(runtime.getContext('2d'),r);assert.deepEqual(pixels(editor),pixels(direct));assert.deepEqual(pixels(runtime),pixels(direct));assert.equal(JSON.stringify(r),before);assert.equal(r.map.geometry.length,0);assert.equal(q.collision,undefined);assert.equal(direct.getContext('2d').getImageData(31,391,1,1).data[3],0);
 const d=blank('source scenery import',384,432);d.rooms=[r];assert.deepEqual(parseProject(JSON.stringify(d)).rooms[0].decorations,[q]);
});
test('cloud adaptation is transparent outside its authored dimensions and opt-in only',()=>{
 const r=room(),q={id:'cloud',x:40,y:248,w:64,h:24,material:'decoration',smm2Art:'source-scenery-cloud'},c=canvas();assert(drawSmm2SourceScenery(c.getContext('2d'),q,r));assert(pixels(c).some(n=>n));assert.equal(c.getContext('2d').getImageData(39,248,1,1).data[3],0);assert.equal(c.getContext('2d').getImageData(104,248,1,1).data[3],0);assert.equal(drawSmm2SourceScenery(canvas().getContext('2d'),q,{...r,smm2Mechanics:undefined}),false);
});
test('source-profile empty shell blue/gold tint preserves its native transparent silhouette and leaves other themes untouched',()=>{
 const r=room(),q={id:'shell',kind:'walker',type:'beetle',shell:true,emptyShell:true,x:10,y:10,w:16,h:16},before=JSON.stringify(q),c=canvas();assert(drawSmm2Actor(c.getContext('2d'),q,0,r));assert.deepEqual(Array.from(c.getContext('2d').getImageData(17,10,1,1).data),[22,89,102,255]);assert.equal(c.getContext('2d').getImageData(10,10,1,1).data[3],0);assert.equal(JSON.stringify(q),before);assert.equal(drawSmm2Actor(canvas().getContext('2d'),q,0,{...r,smm2Mechanics:undefined}),false);
});
test('explicit floating board marker preserves its arrow and adds no invented ground post',()=>{
 const r=room(),q={id:'arrow',kind:'source-arrow',x:24,y:24,w:24,h:16,source:{signArt:'smb1-board-only',facing:'left'}},c=canvas();r.map.geometry=[{id:'support',x:16,y:48,w:64,h:16,collision:'solid',material:'ground'}];assert(drawSmm2SourceArrow(c.getContext('2d'),q,r));assert(pixels(c).some(n=>n));for(let y=40;y<48;y++)for(let x=24;x<48;x++)assert.equal(c.getContext('2d').getImageData(x,y,1,1).data[3],0);
});
test('source-profile small castle renders the exact public original PNG at its unchanged floor anchor',async()=>{
 const r=room();r.markers=[{id:'goal',kind:'flagpole-finish',x:144,y:184,source:{castleDistance:40}}];
 const actual=canvas(),expected=canvas(),before=JSON.stringify(r),original=await loadImage(fileURLToPath(new URL('../atlas/assets/smm2-private/smm1-smb1-fortress.original.png',import.meta.url)));
 expected.getContext('2d').drawImage(original,224,104);assert(drawSmm2SourceCastle(actual.getContext('2d'),[],r));
 assert.deepEqual(pixels(actual),pixels(expected));assert.equal(JSON.stringify(r),before);assert.equal(r.map.geometry.length,0);
 assert.equal(drawSmm2SourceCastle(canvas().getContext('2d'),[],{...r,smm2Mechanics:undefined}),false);
});

test('source background decorations are not repainted in front of the castle by the second tile pass',()=>{
 const r=room();r.markers=[{id:'goal',kind:'flagpole-finish',x:144,y:184,source:{castleDistance:40}}];r.decorations=[{id:'edge',x:288,y:124,w:16,h:20,material:'decoration',smm2Art:'source-scenery-hill-edge'}];
 const c=canvas();drawScenery(c.getContext('2d'),r);const expected=pixels(c);for(const q of r.decorations)drawTile(c.getContext('2d'),q,r,{sceneryDrawn:true});assert.deepEqual(pixels(c),expected);
});
