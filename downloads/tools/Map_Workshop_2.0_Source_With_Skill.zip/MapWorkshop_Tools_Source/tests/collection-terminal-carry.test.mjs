import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {blank} from '../atlas/editor-model.mjs';
import {createCollection,addLevel,approveLevel,enablePrivateTestInclusion,recordPassedLevelTests,levelTestTarget,buildCollection,reorderLevels,setCollectionAdmissionPolicy,withdrawLevelAdmission,updateLevel} from '../atlas/editor-collection.mjs';
import {createProgress,reconcileProgress,resumeBoundary,markLevelComplete,parseProgress,serializeProgress,createProgressStore} from '../atlas/editor-collection-progress.mjs';
import {mountCustomCollection} from '../atlas/editor-collection-player.mjs';
import {loadPixelFont} from '../atlas/chill-font.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';

// Every approval and proof below belongs only to synthetic test fixtures.
const character=JSON.parse(fs.readFileSync(new URL('../atlas/runtime/character.json',import.meta.url)));
const initialCarry={lives:3,coins:0,score:0,power:0,hero:'mario',weapon:'N'};
const earnedCarry={lives:7,coins:62,score:48950,power:2,hero:'mario',weapon:'N'};
const storage=()=>{const data=new Map();return {data,getItem:key=>data.get(key)??null,setItem:(key,value)=>data.set(key,value),removeItem:key=>data.delete(key)};};
const copy=value=>structuredClone(value);
const settle=async()=>{for(let i=0;i<20;i++)await Promise.resolve();};
function project(title){const value=blank('SYNTHETIC ONLY · '+title,320,256),room=value.rooms[0];room.map.geometry=[{id:'floor',x:0,y:224,w:320,h:32,collision:'solid',material:'ground'}];room.map.objects=[{id:'start',kind:'spawn',x:16,y:210,w:10,h:14},{id:'finish',kind:'exit',x:272,y:64,w:16,h:160}];return value;}
function approvedFour(){let value=createCollection({id:'synthetic-terminal-family',title:'Synthetic terminal carry fixture'});for(const id of ['first','second','third','fourth']){value=addLevel(value,project(id),{id});value=approveLevel(value,id,'Synthetic test owner decision only');}return value;}
function appendTested(value,id='fifth'){
 value=enablePrivateTestInclusion(value,'Synthetic fixture delegation only');value=addLevel(value,project(id),{id});
 return recordPassedLevelTests(value,id,{...levelTestTarget(value,id),evidence:[{kind:'native-full-clear',artifact:'SYNTHETIC-clear.json',sha256:'a'.repeat(64),frames:60,completed:true,developerMode:false,noStateMutation:true,noGodmode:true,noTeleport:true},{kind:'offline-closure',artifact:'SYNTHETIC-offline.json',sha256:'b'.repeat(64),passed:true}]});
}
function completed(collection,carry=earnedCarry){let value=createProgress(collection);for(const levelId of collection.order)value=markLevelComplete(collection,value,levelId,carry);return value;}
function plain(ids=['first','second','third','fourth']){return {id:'plain-terminal-family',levels:ids.map(id=>({id,revision:1})),order:ids};}
function launcher(dom,collection,savedStorage,{fail=false}={}){
 const host=dom.document.createElement('div'),screen=dom.document.createElement('section');dom.document.body.append(host,screen);
 const log=[];let options;
 const session={screen,media:{},close(){},async load(pack,rooms,next){options=next;log.push({pack,rooms,options:next});}};
 const ui=mountCustomCollection(collection,{}, {host,storage:savedStorage,playLevel:async(pack,rooms,_media,next)=>{options=next;log.push({pack,rooms,options:next});if(fail)throw Error('Synthetic launch failure');return session;}});
 return {host,ui,session,log,get options(){return options;},button:text=>host.querySelectorAll('button').find(button=>button.textContent===text)};
}
function onlyCarryFields(value){
 assert.deepEqual(Object.keys(value),['lives','coins','score','power','hero','weapon']);
 const forbidden=new Set(['x','y','vx','vy','roomId','checkpoint','checkpoints','world','tape','pose','timer']);
 function inspect(node){if(!node||typeof node!=='object')return;for(const [key,child]of Object.entries(node)){assert(!forbidden.has(key),'Unexpected live state '+key);inspect(child);}}
 return inspect;
}

test('a final completion records a versioned six-field cache while completed progress still has no resume',()=>{
 const collection=plain(),live={...earnedCarry,x:274,y:80,vx:1,checkpoint:{x:32},world:{taken:['coin']},roomId:'main',tape:[{x:100}]};
 const progress=completed(collection,live),inspect=onlyCarryFields(progress.terminalCarry.carry);inspect(progress);
 assert.equal(progress.version,1);assert.equal(progress.completed,true);assert.equal(progress.resume,null);
 assert.deepEqual(progress.terminalCarry,{version:1,fromLevelId:'fourth',fromRevision:1,carry:earnedCarry});
 assert.deepEqual(parseProgress(serializeProgress(progress,collection),collection),progress);
 assert.deepEqual(progress.cleared,collection.order.map(levelId=>({levelId,revision:1})));
});

test('append and reorder choose the first real uncleared successor without changing the cached carry',()=>{
 const old=plain(),saved=completed(old),added=plain([...old.order,'fifth','sixth']);added.revision=99;
 let result=reconcileProgress(added,saved);assert.deepEqual(result.resume,{levelId:'fifth',revision:1,carry:earnedCarry});
 added.order=['sixth','first','second','third','fourth','fifth'];result=reconcileProgress(added,result);assert.equal(result.resume.levelId,'fifth','entries before the terminal are independent starts');
 added.order=['first','second','third','fourth','sixth','fifth'];result=reconcileProgress(added,result);assert.equal(result.resume.levelId,'sixth','an unentered derived boundary follows current order');
 result.cleared.push({levelId:'sixth',revision:1});assert.equal(reconcileProgress(added,result).resume.levelId,'fifth','already-cleared successors are skipped');
 const revisedTarget=plain([...old.order,'fifth','sixth']);revisedTarget.levels.find(level=>level.id==='fifth').revision=2;
 const updated=reconcileProgress(revisedTarget,reconcileProgress(plain([...old.order,'fifth','sixth']),saved));assert.equal(updated.resume.revision,2);assert.deepEqual(updated.resume.carry,earnedCarry);
 revisedTarget.levels=revisedTarget.levels.filter(level=>level.id!=='fifth');revisedTarget.order=revisedTarget.order.filter(id=>id!=='fifth');assert.equal(reconcileProgress(revisedTarget,updated).resume.levelId,'sixth','a deleted unentered successor can be skipped');
 const entered=resumeBoundary(added,reconcileProgress(added,result),'fifth',earnedCarry);assert.equal(entered.terminalCarry,undefined);assert.deepEqual(entered.resume.carry,earnedCarry);
 const independent=resumeBoundary(added,saved,'fifth',{lives:3});assert.equal(independent.terminalCarry,undefined);assert.deepEqual(independent.resume.carry,initialCarry);
 assert.equal(saved.resume,null,'reconciliation leaves its input intact');
});

test('terminal source revision, deletion and fingerprint changes discard carry and preserve unrelated clears',()=>{
 const authored=approvedFour(),original=buildCollection(authored,character),saved=completed(original),extended=buildCollection(appendTested(authored),character);
 const resumed=reconcileProgress(extended,saved);assert.equal(resumed.resume.levelId,'fifth');assert.match(saved.terminalCarry.contentFingerprint,/^[a-f0-9]{64}$/);
 for(const change of [value=>value.levels.find(level=>level.id==='fourth').revision++,value=>{value.levels=value.levels.filter(level=>level.id!=='fourth');value.order=value.order.filter(id=>id!=='fourth');},value=>value.levels.find(level=>level.id==='fourth').admission.contentFingerprint='c'.repeat(64)]){
  const current=copy(extended);change(current);const result=reconcileProgress(current,resumed);assert.equal(result.terminalCarry,undefined);assert.equal(result.resume,null);assert(result.cleared.some(level=>level.levelId==='first'));
 }
 const changed=approvedFour(),revisedProject=project('fourth revised');const rebuilt=buildCollection(appendTested(updateLevel(changed,'fourth',revisedProject)),character);
 assert.equal(reconcileProgress(rebuilt,saved).terminalCarry,undefined);assert.equal(reconcileProgress(rebuilt,saved).cleared.length,3);
 assert.throws(()=>reconcileProgress({...original,id:'different-family'},saved),/different collection/);
});

test('single-entry, empty and no-successor collections do not fabricate a resume',()=>{
 const single=plain(['only']),saved=completed(single);assert.equal(saved.completed,true);assert.equal(reconcileProgress(single,saved).resume,null);
 const before=plain(['new','only']);const noNext=reconcileProgress(before,saved);assert.equal(noNext.completed,false);assert.equal(noNext.resume,null);assert.deepEqual(noNext.terminalCarry.carry,earnedCarry);
 const empty=plain([]);assert.deepEqual(createProgress(empty).cleared,[]);assert.equal(createProgress(empty).terminalCarry,undefined);assert.equal(reconcileProgress(empty,saved).terminalCarry,undefined);assert.equal(reconcileProgress(empty,saved).resume,null);
});

test('pending, failed, withdrawn and policy-disabled levels never gain eligibility from terminal progress',()=>{
 const authored=approvedFour(),old=buildCollection(authored,character),saved=completed(old);
 const pending=addLevel(authored,project('fifth pending'),{id:'fifth'}),pendingRuntime=buildCollection(pending,character);
 assert.equal(reconcileProgress(pendingRuntime,saved).resume,null);assert.equal(reconcileProgress(pending,saved).resume,null);
 const admitted=appendTested(authored),admittedRuntime=buildCollection(admitted,character);assert.equal(reconcileProgress(admittedRuntime,saved).resume.levelId,'fifth');
 const failed=copy(admitted);failed.levels.find(level=>level.id==='fifth').testAdmission.contentFingerprint='f'.repeat(64);assert.equal(buildCollection(failed,character).levels.length,4);assert.equal(reconcileProgress(buildCollection(failed,character),saved).resume,null);
 const withdrawn=buildCollection(withdrawLevelAdmission(admitted,'fifth'),character);assert.equal(reconcileProgress(withdrawn,saved).resume,null);
 const testedTerminal=completed(admittedRuntime),disabled=buildCollection(setCollectionAdmissionPolicy(admitted,{version:1,mode:'owner-approved-only'}),character);
 const invalidated=reconcileProgress(disabled,testedTerminal);assert.equal(invalidated.terminalCarry,undefined);assert.equal(invalidated.resume,null);assert.equal(invalidated.cleared.length,4);
 const unfilteredDisabled=copy(admittedRuntime);unfilteredDisabled.admissionPolicy={version:1,mode:'owner-approved-only'};assert.equal(reconcileProgress(unfilteredDisabled,testedTerminal).terminalCarry,undefined,'withdrawal is respected even on an unfiltered descriptor');
 assert.equal(admitted.levels.find(level=>level.id==='fifth').approval.status,'pending','a clear or cache never records owner approval');
});

test('terminal imports keep strict schema, carry bounds and prototype/accessor defenses',()=>{
 const collection=plain(),base=completed(collection),changes=[value=>value.terminalCarry.version=2,value=>value.terminalCarry.fromLevelId='unsafe id',value=>value.terminalCarry.fromRevision=0,value=>value.terminalCarry.contentFingerprint='bad',value=>value.terminalCarry.x=1,value=>value.terminalCarry.carry.world={},value=>value.terminalCarry.carry.lives=0,value=>value.terminalCarry.carry.coins=100,value=>value.terminalCarry.carry.score=-1,value=>value.terminalCarry.carry.power=3,value=>value.terminalCarry.carry.hero='unknown',value=>value.terminalCarry.carry.weapon='Z',value=>delete value.terminalCarry.carry.power,value=>value.terminalCarry=null];
 for(const change of changes){const value=copy(base);change(value);assert.throws(()=>parseProgress(JSON.stringify(value),collection));}
 assert.throws(()=>parseProgress(JSON.stringify(base).replace('"carry":{','"carry":{"__proto__":{},'),collection),/unsafe/);
 let invoked=0;const accessor=copy(base);Object.defineProperty(accessor.terminalCarry,'carry',{get(){invoked++;return earnedCarry;}});assert.throws(()=>serializeProgress(accessor,collection),/accessor/);assert.equal(invoked,0);
 const prototype=copy(base);Object.setPrototypeOf(prototype.terminalCarry,{extra:true});assert.throws(()=>serializeProgress(prototype,collection),/plain object/);
 const missingClear=copy(base);missingClear.cleared=missingClear.cleared.filter(level=>level.levelId!=='fourth');assert.equal(reconcileProgress(collection,missingClear).terminalCarry,undefined);
});

test('legacy version-one completed, empty and ordinary boundary JSON keep their existing behavior',()=>{
 const collection=plain(),legacy=completed(collection);delete legacy.terminalCarry;
 assert.deepEqual(parseProgress(serializeProgress(legacy),collection),legacy);assert.equal(legacy.completed,true);
 const extended=plain([...collection.order,'fifth']);const result=parseProgress(serializeProgress(legacy),extended);assert.equal(result.resume,null);assert.equal(result.terminalCarry,undefined);assert.equal(result.completed,false);assert.equal(result.cleared.length,4);
 const normal=resumeBoundary(collection,createProgress(collection),'third',earnedCarry);assert.equal(normal.terminalCarry,undefined);assert.deepEqual(parseProgress(serializeProgress(normal),collection),normal);
 const empty=createProgress(plain([]));assert.equal(empty.terminalCarry,undefined);assert.deepEqual(parseProgress(serializeProgress(empty),plain([])),empty);
});

test('real simulated launcher captures last completion, serializes, appends a tested fifth and resumes its entry unchanged',async()=>{
 const dom=installSimulatedPlayDom();try{
  const authored=approvedFour(),old=buildCollection(authored,character),savedStorage=storage(),before=launcher(dom,old,savedStorage);
  await before.ui.startLevel('first',{lives:3});
  for(const levelId of old.order){assert.equal(before.ui.readProgress().resume.levelId,levelId);await before.options.onComplete({...earnedCarry,x:280,y:64,roomId:'main',world:{coin:true},tape:[{x:200}]},before.session);}
  assert.equal(before.log.length,4);assert.equal(before.ui.readProgress().completed,true);assert.equal(before.ui.readProgress().resume,null);
  const bytes=savedStorage.data.get('xiaoq-map-collection-progress:'+old.id),exported=serializeProgress(before.ui.readProgress(),old);
  assert.deepEqual(JSON.parse(bytes),JSON.parse(exported));const inspect=onlyCarryFields(JSON.parse(bytes).terminalCarry.carry);inspect(JSON.parse(bytes));
  const appended=appendTested(authored),next=buildCollection(appended,character),after=launcher(dom,next,savedStorage);
  assert.deepEqual(after.ui.readProgress().cleared,before.ui.readProgress().cleared);assert.equal(after.ui.readProgress().resume.levelId,'fifth');assert.deepEqual(after.ui.readProgress().resume.carry,earnedCarry);
  after.button('继续：'+next.levels.find(level=>level.id==='fifth').title+' · 测试通过 / 待你查看').click();await settle();
  assert.equal(after.log.length,1);assert.equal(after.log[0].pack.stages[0].title,next.levels.find(level=>level.id==='fifth').title);assert.deepEqual(after.options.initialState,earnedCarry);assert.equal(after.options.developerMode,false);assert.equal(after.options.onWarp,undefined);assert.equal(after.ui.readProgress().terminalCarry,undefined,'cache is consumed by entering the new boundary');
  assert.equal(appended.levels.find(level=>level.id==='fifth').approval.status,'pending');
  const fifthCarry={...earnedCarry,lives:6,coins:71,score:52950,power:1};await after.options.onComplete(fifthCarry,after.session);assert.equal(after.ui.readProgress().terminalCarry.fromLevelId,'fifth');assert.equal(after.ui.readProgress().completed,true);
  const sixth=buildCollection(appendTested(appended,'sixth'),character),later=launcher(dom,sixth,savedStorage);assert.equal(later.ui.readProgress().resume.levelId,'sixth');assert.deepEqual(later.ui.readProgress().resume.carry,fifthCarry);assert.equal(later.ui.readProgress().cleared.length,5);
  later.button('继续：'+sixth.levels.find(level=>level.id==='sixth').title+' · 测试通过 / 待你查看').click();await settle();assert.deepEqual(later.options.initialState,fifthCarry);assert.equal(later.log.length,1);
 }finally{await loadPixelFont();dom.restore();}
});

test('a legacy completed launcher selects the new fifth and starts it with truthful fresh defaults',async()=>{
 const dom=installSimulatedPlayDom();try{
  const authored=approvedFour(),old=buildCollection(authored,character),legacy=completed(old),savedStorage=storage();delete legacy.terminalCarry;
  savedStorage.setItem('xiaoq-map-collection-progress:'+old.id,serializeProgress(legacy));
  const unchanged=launcher(dom,old,savedStorage);assert.equal(unchanged.ui.readProgress().completed,true);assert.equal(unchanged.ui.readProgress().resume,null);
  const next=buildCollection(appendTested(authored),character),view=launcher(dom,next,savedStorage);
  assert.equal(view.ui.selectedLevel(),'fifth');assert.equal(view.ui.readProgress().resume,null);assert(view.host.textContent.includes('没有可继续的携带状态'));view.button('游玩所选关').click();await settle();
  assert.deepEqual(view.options.initialState,initialCarry);assert.equal(view.ui.readProgress().cleared.length,4);assert.equal(view.ui.readProgress().terminalCarry,undefined);
 }finally{await loadPixelFont();dom.restore();}
});

test('explicit selected play discards cached continuation and failed launches never manufacture a terminal clear',async()=>{
 const dom=installSimulatedPlayDom();try{
  const authored=approvedFour(),old=buildCollection(authored,character),next=buildCollection(appendTested(authored),character),savedStorage=storage();createProgressStore(old,{storage:savedStorage}).save(completed(old));
  const view=launcher(dom,next,savedStorage);view.host.querySelector('#custom-level-select').value='fifth';view.button('游玩所选关').click();await settle();assert.deepEqual(view.options.initialState,initialCarry);assert.equal(view.ui.readProgress().terminalCarry,undefined);
  const failedStorage=storage();createProgressStore(old,{storage:failedStorage}).save(completed(old));const failed=launcher(dom,next,failedStorage,{fail:true});await failed.ui.startLevel('fifth',failed.ui.readProgress().resume.carry);
  assert.deepEqual(failed.options.initialState,earnedCarry);assert.deepEqual(failed.ui.readProgress().resume.carry,earnedCarry);assert.equal(failed.ui.readProgress().cleared.length,4);assert.equal(failed.ui.readProgress().terminalCarry,undefined);assert.equal(failed.ui.readProgress().completed,false);
  const unfinished=launcher(dom,old,storage());await unfinished.ui.startLevel('fourth',{lives:3});assert.equal(unfinished.ui.readProgress().terminalCarry,undefined);assert.equal(unfinished.ui.readProgress().cleared.length,0);assert.equal(unfinished.ui.readProgress().completed,false);
 }finally{await loadPixelFont();dom.restore();}
});
