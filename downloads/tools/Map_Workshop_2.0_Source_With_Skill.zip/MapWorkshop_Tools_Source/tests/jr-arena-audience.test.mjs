import test from 'node:test';
import assert from 'node:assert/strict';
import {createCanvas} from '@napi-rs/canvas';
import {createJrArenaAudience,validateJrArenaAudienceRoom} from '../atlas/editor-jr-arena-audience.mjs';
import {drawJrArenaAudience} from '../atlas/editor-jr-arena-art.mjs';
import {createPlatformMotor} from '../atlas/editor-mario-motor.mjs';
import {arenaAudienceProject} from './fixtures/jr-arena-audience.mjs';
import {nativeSession,character} from './fixtures/shell-coin-native.mjs';

const boss={actorId:'junior',hp:1,phase:'shell'};
const centerPlayer={x:280,y:378,w:10,h:14};
const hit=(hp,tick)=>({roomId:'main',actorId:'junior',event:hp?'head-stomp':'defeated',hp,tick});
test('solid seated scene actors validate independently of native enemies and reject ambiguous geometry',()=>{
 const r=arenaAudienceProject().rooms[0];assert(validateJrArenaAudienceRoom(r));assert.equal(r.map.objects.filter(q=>q.kind==='walker').length,1);assert.equal(r.smm2Mechanics.arenaAudience.seats.length,10);
 for(const change of [q=>q.maxAlive=4,q=>q.waveCount=4,q=>q.telegraphFrames=30,q=>q.seats[0].seatGeometryId='missing',q=>q.seats[0].y++,q=>q.exits[0].y=350,q=>q.seats[0].id='junior',q=>q.customDamage=true]){const bad=structuredClone(r);change(bad.smm2Mechanics.arenaAudience);assert.throws(()=>validateJrArenaAudienceRoom(bad));}
});
test('audience responds only to the actual same-room Jr head-stomp or defeat notification',()=>{
 const r=arenaAudienceProject().rooms[0],events=[],c=createJrArenaAudience(r,{emit:(type,q)=>events.push({type,...q})});const before=c.snapshot();
 for(const event of [{...hit(2,1),actorId:'other'}, {...hit(2,1),roomId:'other'}, {...hit(2,1),event:'sound'}, {...hit(2,1),hp:3}])assert.equal(c.handleBossEvent(event),false);
 assert.deepEqual(c.snapshot(),before);assert(c.handleBossEvent(hit(2,1)));assert(!c.handleBossEvent(hit(2,1)));assert.equal(c.view().cheering,true);assert.deepEqual(new Set(c.view().spectators.map(q=>q.pose)),new Set(['cheer','jump','wave']));assert(c.view().spectators.every(q=>q.harmless&&!q.stompable&&!q.countsAsEnemy));
 const view=c.view();view.spectators[0].x=-999;assert(c.view().spectators[0].x>=0);c.step({tick:97,boss:{hp:2,phase:'normal'}});assert.equal(c.view().cheering,false);assert.equal(events.filter(e=>e.event==='cheer').length,1);
});
test('final phase shows both gallery warnings for72ticks, spawns only native Goombas at exits and respects caps',()=>{
 const r=arenaAudienceProject().rooms[0],enemies=[],events=[],c=createJrArenaAudience(r,{spawn:q=>enemies.push(q),emit:(type,q)=>events.push({type,...q})});c.handleBossEvent(hit(1,10));
 for(let tick=10;tick<82;tick++)c.step({tick,boss,enemies,player:centerPlayer});assert.equal(enemies.length,0);assert.equal(c.view().galleryWarnings.length,2);c.step({tick:82,boss,enemies,player:centerPlayer});assert.equal(enemies.length,2);assert.deepEqual(enemies.map(q=>[q.type,q.x,q.y,q.vx]),[['goomba',52,376,.5],['goomba',508,376,-.5]]);
 for(let tick=83;tick<=334;tick++)c.step({tick,boss,enemies,player:centerPlayer});assert.equal(enemies.length,3);assert.equal(c.view().galleryWarnings.length,1);assert.equal(c.view().totalSpawned,3);
 enemies[0].dead=true;c.step({tick:335,boss,enemies,player:centerPlayer});assert.equal(enemies.length,4);assert.equal(enemies.filter(q=>!q.dead).length,3);
 for(const q of enemies)q.dead=true;for(let tick=336;tick<=587;tick++)c.step({tick,boss,enemies,player:centerPlayer});assert.equal(enemies.length,6);for(const q of enemies)q.dead=true;for(let tick=588;tick<1800;tick++)c.step({tick,boss,enemies,player:centerPlayer});assert.equal(enemies.length,6);assert.equal(c.view().wavesStarted,3);assert.equal(events.filter(e=>e.event==='gallery-warning').length,3);
});
test('an occupied gallery exit waits and victory cancels pending waves without changing seated spectators',()=>{
 const r=arenaAudienceProject().rooms[0],enemies=[],c=createJrArenaAudience(r,{spawn:q=>enemies.push(q)});c.handleBossEvent(hit(1,1));
 for(let tick=1;tick<=73;tick++)c.step({tick,boss,enemies,player:{...centerPlayer,x:52}});assert.equal(enemies.length,1);assert.equal(enemies[0].x,508);assert.equal(c.view().galleryWarnings.length,1);c.handleBossEvent(hit(0,74));c.step({tick:100,boss:{hp:0,phase:'defeated'},enemies,player:centerPlayer});assert.equal(enemies.length,1);assert.equal(c.view().galleryWarnings.length,0);assert.equal(c.view().spectators.length,10);assert(c.view().defeated);
});
test('snapshot/restoration and duplicate ticks preserve exact authored crowd events and pending state',()=>{
 const r=arenaAudienceProject().rooms[0],firstActors=[],secondActors=[],firstEvents=[],secondEvents=[],a=createJrArenaAudience(r,{spawn:q=>firstActors.push(q),emit:(type,q)=>firstEvents.push({type,...q})});a.handleBossEvent(hit(1,1));a.step({tick:1,boss,enemies:firstActors,player:centerPlayer});for(let tick=2;tick<=35;tick++)a.step({tick,boss,enemies:firstActors,player:centerPlayer});const saved=a.snapshot(),b=createJrArenaAudience(r,{spawn:q=>secondActors.push(q),emit:(type,q)=>secondEvents.push({type,...q})});b.restore(saved);const offset=firstEvents.length;
 for(let tick=36;tick<=260;tick++){a.step({tick,boss,enemies:firstActors,player:centerPlayer});b.step({tick,boss,enemies:secondActors,player:centerPlayer});assert.deepEqual(b.view(),a.view());}assert.deepEqual(secondActors,firstActors);assert.deepEqual(secondEvents,firstEvents.slice(offset));const frozen=a.snapshot();a.step({tick:260,boss,enemies:firstActors,player:centerPlayer});a.view();assert.deepEqual(a.snapshot(),frozen);
 const bad=structuredClone(saved);bad.pending[0].readyTick--;assert.throws(()=>b.restore(bad));
});
test('the visible arch remains a real obstacle to full run jumps and high recovery-head rebounds',()=>{
 const r=arenaAudienceProject().rooms[0],motor=createPlatformMotor(),solids=r.map.geometry,world={solids,width:576,swimming:false};
 for(const [side,start,vx]of [['left',130,-2.5],['right',436,2.5]])for(const rebound of [false,true]){
  const p=motor.create(character,{x:start,y:rebound?330:378,w:10,h:14});Object.assign(p,{w:10,h:14,vx,grounded:!rebound,airCap:2.5,...(rebound?{vy:-4.1333333,jumpG:.125,fallG:.4375}:{})});let crossed=false;
  for(let frame=0;frame<150;frame++){motor.step(p,{x:Math.sign(vx),run:true,jump:true,jumpPressed:!rebound&&frame===0},character,world);if(p.y+p.h<=360&&(side==='left'?p.x<80:p.x+p.w>496))crossed=true;assert(!/seat|arch/.test(p.support||''),'no seat or fascia perch reached');}
  assert.equal(crossed,false,'real brick fascia blocks '+side+' '+(rebound?'recovery bounce':'run jump'));
 }
 // The same architecture leaves a real low gallery route, even for Big.
 for(const power of [0,1]){const p=motor.create(character,{x:35,y:power?364:378,w:10,h:power?28:14});Object.assign(p,{w:10,h:power?28:14,power,grounded:true});for(let frame=0;frame<80;frame++)motor.step(p,{x:1,run:true},character,world);assert(p.x>100);assert.equal(p.y+p.h,392);}
});
test('handed-off Goomba uses native motion, real Small stomp, flattened death and normal score',()=>{
 const d=arenaAudienceProject(),r=d.rooms[0],spawned=[],c=createJrArenaAudience(r,{spawn:q=>spawned.push(q)});c.handleBossEvent(hit(1,1));c.step({tick:1,boss,player:centerPlayer});c.step({tick:73,boss,player:centerPlayer});assert.equal(spawned.length,2);
 const runner={...spawned[0],x:200,homeX:200},start=r.map.objects[0];Object.assign(start,{x:204,y:340});r.map.objects=[start,runner];delete r.smm2Mechanics.bowserJuniors;delete r.smm2Mechanics.arenaAudience;const s=nativeSession(d,{direct:true});const first=s.step({});assert.equal(first.enemies[0].x,199.5);s.until(v=>!v.enemies.length,{},80);assert(!s.view().p.dying);assert.equal(s.view().p.power,0);assert.equal(s.view().score,100);assert(s.view().items.some(q=>q.kind==='enemy-death'&&q.flat));
});
test('audience raster reuses exact16px Goomba shape and animated cheering changes visible pixels',()=>{
 const r=arenaAudienceProject().rooms[0],c=createJrArenaAudience(r),canvas=createCanvas(576,432),ctx=canvas.getContext('2d');drawJrArenaAudience(ctx,r);const resting=canvas.toBuffer('image/png');c.handleBossEvent(hit(2,1));c.step({tick:11,boss:{hp:2,phase:'shell'}});ctx.clearRect(0,0,576,432);assert(drawJrArenaAudience(ctx,{...r,arenaAudienceView:c.view()},11));assert.notDeepEqual(canvas.toBuffer('image/png'),resting);assert.equal(c.view().spectators.length,10);
});
