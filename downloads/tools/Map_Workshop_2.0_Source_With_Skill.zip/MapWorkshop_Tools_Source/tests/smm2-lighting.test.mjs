import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createCanvas} from '@napi-rs/canvas';
import {validate,parseProject} from '../atlas/editor-model.mjs';
import {validateSmm2LightingRoom,parseSmm2Lighting,resolveSmm2LightSources,drawSmm2LightingMask} from '../atlas/editor-smm2-lighting.mjs';
import {lightingProject,centre,assertNativeLightingMotion} from './fixtures/lighting-native.mjs';
import {nativeSession} from './fixtures/shell-coin-native.mjs';

const room=()=>lightingProject().rooms[0];
const withSpec=spec=>{const r=room();r.smm2Mechanics.lighting=spec;return r;};
const base=()=>({darkness:.9,playerRadius:40,sources:[]});
const pixel=(canvas,x,y)=>[...canvas.getContext('2d').getImageData(x,y,1,1).data];
function render(r,view,{camera={x:0,y:0,width:256,height:240},width=512,height=480,preview=false,color='#ffffff'}={}){
 const canvas=createCanvas(width,height),ctx=canvas.getContext('2d');ctx.fillStyle=color;ctx.fillRect(0,0,width,height);
 const handled=drawSmm2LightingMask(ctx,r,view,{camera,width,height,preview,createCanvas});return {canvas,ctx,handled};
}

test('night lighting is opt-in, parser is non-mutating and legacy Night rooms have no automatic illumination mask',()=>{
 const doc=lightingProject({enabled:false}),r=doc.rooms[0],before=JSON.stringify(doc);validateSmm2LightingRoom(r);validate(doc);
 assert.equal(parseSmm2Lighting(r),null);assert.deepEqual(resolveSmm2LightSources(r,{p:{x:10,y:10,w:10,h:14}}),[]);
 const {canvas,handled}=render(r,{});assert.equal(handled,false);assert.deepEqual(pixel(canvas,128,128),[255,255,255,255]);assert.equal(JSON.stringify(doc),before);
 const spec=withSpec(base()),source=JSON.stringify(spec);assert.deepEqual(parseSmm2Lighting(spec),{...base(),softness:.25});assert.equal(JSON.stringify(spec),source);
 const parsed=parseSmm2Lighting(room());parsed.sources[0].radius=512;assert.equal(room().smm2Mechanics.lighting.sources[0].radius,24);
});

test('lighting strictly rejects malformed values, unknown fields, hostile IDs and missing/cross-room targets',()=>{
 const malformed=[null,false,0,'night',[],{},{...base(),darkness:-.01},{...base(),darkness:1.01},{...base(),darkness:NaN},{...base(),darkness:'1'},
  {...base(),playerRadius:7.99},{...base(),playerRadius:512.01},{...base(),playerRadius:Infinity},{...base(),playerRadius:null},
  {...base(),softness:-.01},{...base(),softness:1.01},{...base(),softness:'0.25'},{...base(),softness:null},
  {...base(),sources:null},{...base(),sources:{}},{...base(),ambient:1},{...base(),sources:[{targetId:'moving-enemy',radius:32,brightness:1}]},
  {...base(),sources:[{targetId:'moving-enemy',radius:7.99}]},{...base(),sources:[{targetId:'moving-enemy',radius:512.01}]},
  {...base(),sources:[{targetId:'moving-enemy',radius:'32'}]},{...base(),sources:[{targetId:'moving-enemy',radius:NaN}]},
  {...base(),sources:[{targetId:'moving-enemy'}]},{...base(),sources:[null]},{...base(),sources:[{targetId:'start',radius:32}]},
  {...base(),sources:[{targetId:'absent',radius:32}]},{...base(),sources:[{targetId:'player',radius:32}]},
  {...base(),sources:[{targetId:'moving-enemy',radius:32},{targetId:'moving-enemy',radius:48}]},
  {...base(),sources:[{targetId:'moving-enemy',radius:32,offsetX:513}]},{...base(),sources:[{targetId:'moving-enemy',radius:32,offsetY:-513}]},
  {...base(),sources:[{targetId:'moving-enemy',radius:32,offsetX:NaN}]},
 ];
 for(const targetId of ['', '__proto__','prototype','constructor','unsafe\u0000id','x'.repeat(129)])malformed.push({...base(),sources:[{targetId,radius:32}]});
 malformed.push(JSON.parse('{"darkness":0.9,"playerRadius":40,"sources":[],"__proto__":{}}'));
 malformed.push({...base(),sources:[JSON.parse('{"targetId":"moving-enemy","radius":32,"__proto__":{}}')]});
 for(const spec of malformed){const r=withSpec(spec),before=JSON.stringify(r);assert.throws(()=>validateSmm2LightingRoom(r),undefined,JSON.stringify(spec));assert.equal(JSON.stringify(r),before);const d=lightingProject();d.rooms[0]=r;assert.throws(()=>parseProject(JSON.stringify(d)));}
 const duplicate=room();duplicate.map.geometry.push({id:'moving-enemy',x:128,y:128,w:16,h:16,collision:'solid'});assert.throws(()=>validateSmm2LightingRoom(duplicate));
 const remote=lightingProject();remote.rooms[0].smm2Mechanics.lighting.sources=[{targetId:'another-room-object',radius:24}];const other=structuredClone(remote.rooms[0]);other.roomId='other';other.map.id='other-map';other.smm2Mechanics.lighting.sources=[];other.map.objects.push({id:'another-room-object',kind:'coin',x:64,y:210,w:8,h:14});remote.rooms.push(other);assert.throws(()=>parseProject(JSON.stringify(remote)));
 const many=withSpec({...base(),sources:[]});for(let i=0;i<65;i++){many.map.objects.push({id:'light-'+i,kind:'coin',x:i*8,y:16,w:8,h:14});many.smm2Mechanics.lighting.sources.push({targetId:'light-'+i,radius:8});}assert.throws(()=>validateSmm2LightingRoom(many));many.smm2Mechanics.lighting.sources.pop();validateSmm2LightingRoom(many);
 for(const darkness of [0,1])for(const playerRadius of [8,512])for(const softness of [0,1])validateSmm2LightingRoom(withSpec({darkness,playerRadius,softness,sources:[]}));
});

test('only explicit source-arrow markers can have fixed offset lights and hidden markers stop emitting',()=>{
 const r=room();r.smm2Mechanics.lighting.sources=[{targetId:'fixed-arrow',radius:24,offsetX:8,offsetY:-8}];validateSmm2LightingRoom(r);
 const v={p:{x:16,y:32,w:10,h:14},objects:[],geometry:[],enemies:[],items:[],hiddenMarkers:[]},arrow=resolveSmm2LightSources(r,v).find(q=>q.targetId==='fixed-arrow');assert.deepEqual(arrow,{targetId:'fixed-arrow',x:504,y:136,radius:24});
 assert(!resolveSmm2LightSources(r,{...v,hiddenMarkers:['fixed-arrow']}).some(q=>q.targetId==='fixed-arrow'));
 for(const patch of [{offsetX:undefined},{offsetY:undefined},{offsetX:null},{offsetY:'8'}]){const bad=structuredClone(r);Object.assign(bad.smm2Mechanics.lighting.sources[0],patch);assert.throws(()=>validateSmm2LightingRoom(bad));}
 for(const kind of ['enemy-goomba','platform-generator','flagpole-finish','decorative-lamp']){const bad=structuredClone(r);bad.markers.find(q=>q.id==='fixed-arrow').kind=kind;assert.throws(()=>validateSmm2LightingRoom(bad));}
});

test('runtime resolves body centers from live player/enemy/item/geometry/object poses with no stale authored fallback',()=>{
 const r=room(),v={p:{x:24,y:48,w:10,h:14},enemies:[{id:'moving-enemy',x:200,y:192,w:16,h:16},{id:'unbound-enemy',x:210,y:192,w:16,h:16}],items:[{id:'falling-pow',x:350,y:200,w:16,h:16}],geometry:[{id:'falling-pow',x:336,y:80,w:16,h:16},{id:'moving-lift',x:416,y:160,w:64,h:8}],objects:[{id:'lamp-coin',x:144,y:210,w:8,h:14}],hiddenMarkers:[]};
 const before=JSON.stringify({r,v}),sources=resolveSmm2LightSources(r,v),byId=new Map(sources.map(q=>[q.targetId,q]));assert.deepEqual(byId.get('player'),{targetId:'player',...centre(v.p),radius:40});
 for(const [id,key]of [['moving-enemy','enemies'],['falling-pow','items'],['moving-lift','geometry'],['lamp-coin','objects']])assert.deepEqual({x:byId.get(id).x,y:byId.get(id).y},centre(v[key].find(q=>q.id===id)));
 assert(!byId.has('unbound-enemy'));assert.equal(JSON.stringify({r,v}),before);
 const empty={p:v.p,enemies:[],items:[],geometry:[],objects:[],hiddenMarkers:['fixed-arrow']};assert.deepEqual(resolveSmm2LightSources(r,empty).map(q=>q.targetId),['player']);
 const preview=resolveSmm2LightSources(r,empty,{preview:true});assert(preview.some(q=>q.targetId==='moving-enemy'));assert.deepEqual(centre(r.map.objects.find(q=>q.id==='moving-enemy')),{x:preview.find(q=>q.targetId==='moving-enemy').x,y:preview.find(q=>q.targetId==='moving-enemy').y});
 for(const flag of ['dead','dying','removed','taken','hidden']){const bad=structuredClone(v);bad.enemies[0][flag]=true;assert(!resolveSmm2LightSources(r,bad).some(q=>q.targetId==='moving-enemy'));bad.items[0][flag]=true;assert(!resolveSmm2LightSources(r,bad).some(q=>q.targetId==='falling-pow'),'dead POW collider cannot revive its light');}
 const picked={...v,objects:[]};assert(!resolveSmm2LightSources(r,picked).some(q=>q.targetId==='lamp-coin'));
 const darkPlayer={...v,p:{...v.p,dead:true}};assert(!resolveSmm2LightSources(r,darkPlayer).some(q=>q.targetId==='player'));
 const shifted=structuredClone(r);shifted.smm2Mechanics.lighting.sources=[{targetId:'moving-enemy',radius:24,offsetX:5,offsetY:-3}];assert.deepEqual(resolveSmm2LightSources(shifted,v).find(q=>q.targetId==='moving-enemy'),{targetId:'moving-enemy',x:213,y:197,radius:24});
});

for(const scale of [1,2,3])test(`pixel mask translates camera and scales circular world light correctly at ${scale}x`,()=>{
 const r=withSpec({darkness:1,playerRadius:32,softness:0,sources:[]}),v={p:{x:91,y:89,w:10,h:14}},camera={x:32,y:32,width:128,height:128},width=128*scale,height=width;
 const {canvas,ctx,handled}=render(r,v,{camera,width,height});assert.equal(handled,true);const cx=64*scale,cy=64*scale;
 assert.equal(pixel(canvas,cx,cy)[0],255);assert.equal(pixel(canvas,cx+30*scale,cy)[0],255);assert.equal(pixel(canvas,cx,cy+30*scale)[0],255);
 assert.equal(pixel(canvas,cx+34*scale,cy)[0],0);assert.equal(pixel(canvas,cx,cy+34*scale)[0],0);assert.equal(pixel(canvas,2,2)[0],0);
 assert.equal(ctx.globalCompositeOperation,'source-over');assert.equal(ctx.globalAlpha,1);assert.equal(ctx.getTransform().a,1);assert.equal(ctx.getTransform().e,0);
});

test('soft edge yields real intermediate pixels and mask preserves rendering context state',()=>{
 const r=withSpec({darkness:1,playerRadius:40,softness:.5,sources:[]}),v={p:{x:91,y:89,w:10,h:14}},camera={x:32,y:32,width:128,height:128};
 const {canvas}=render(r,v,{camera,width:256,height:256});assert.equal(pixel(canvas,128,128)[0],255);assert.equal(pixel(canvas,220,128)[0],0);const edge=pixel(canvas,188,128)[0];assert(edge>0&&edge<255,`soft penumbra pixel ${edge}`);
 const ctx=createCanvas(256,256).getContext('2d');ctx.fillStyle='#ca2211';ctx.globalAlpha=.7;ctx.globalCompositeOperation='multiply';ctx.translate(5,7);const before=ctx.getTransform(),alpha=ctx.globalAlpha;drawSmm2LightingMask(ctx,r,v,{camera,width:256,height:256,createCanvas});assert.equal(ctx.fillStyle,'#ca2211');assert.equal(ctx.globalAlpha,alpha);assert.equal(ctx.globalCompositeOperation,'multiply');assert.deepEqual(ctx.getTransform(),before);
});

test('genuine native moving enemy, falling POW, moving terrain and picked coin change live light positions',()=>{
 const report=assertNativeLightingMotion(lightingProject(),{resolve:resolveSmm2LightSources});assert.equal(report.frames,150);assert.equal(report.stateMutatedDuringPlay,false);
});

test('a genuine native player underside jump spends the POW and removes its light with its real item/collider',()=>{
 const doc=lightingProject(),r=doc.rooms[0];r.map.objects=r.map.objects.filter(q=>['start','falling-pow'].includes(q.id));Object.assign(r.map.objects[0],{x:336,y:210});r.map.objects[1].y=180;r.smm2Mechanics.powBlocks[0].gravity=0;r.smm2Mechanics.lighting.sources=[{targetId:'falling-pow',radius:24}];
 const s=nativeSession(doc);s.frames(3);assert(resolveSmm2LightSources(r,s.view()).some(q=>q.targetId==='falling-pow'));
 const v=s.until(v=>!v.items.some(q=>q.id==='falling-pow'),{jump:true},30);assert(s.events.some(q=>q.event==='pow-activate'&&q.contact.nativeHeadHit));assert(!v.geometry.some(q=>q.id==='falling-pow'));assert(!resolveSmm2LightSources(r,v).some(q=>q.targetId==='falling-pow'));
});

test('split live geometry uses remaining native pieces, wrong-room views do not leak light and all consumed flags are inert',()=>{
 const r=room();r.smm2Mechanics.lighting.sources=[{targetId:'moving-lift',radius:24}];const view={roomId:r.roomId,p:null,objects:[],items:[],enemies:[],geometry:[{id:'fragment-a',sourceId:'moving-lift',x:400,y:144,w:16,h:8},{id:'fragment-b',sourceId:'moving-lift',x:432,y:160,w:16,h:8}]};
 assert.deepEqual(resolveSmm2LightSources(r,view),[{targetId:'moving-lift',x:424,y:156,radius:24}]);assert.deepEqual(resolveSmm2LightSources(r,{...view,roomId:'other'}),[]);assert.deepEqual(resolveSmm2LightSources(r,{...view,geometry:[]}),[]);
 for(const key of ['dead','dying','removed','taken','collected','hidden']){const bad=structuredClone(view);for(const piece of bad.geometry)piece[key]=true;assert.deepEqual(resolveSmm2LightSources(r,bad),[]);}const hidden=structuredClone(view);hidden.geometry.forEach(q=>q.visible=false);assert.deepEqual(resolveSmm2LightSources(r,hidden),[]);
});

test('night air lighting leaves normal native gravity, collision, jump and inputs exactly unchanged',()=>{
 const dark=nativeSession(lightingProject()),off=nativeSession(lightingProject({enabled:false})),day=nativeSession(lightingProject({enabled:false,setting:'Overworld'}));
 const physical=v=>({p:v.p,enemies:v.enemies,items:v.items,geometry:v.geometry,objects:v.objects,coins:v.coins,score:v.score,lives:v.lives,timeLeft:v.timeLeft,completed:v.completed});
 for(let frame=0;frame<120;frame++){const input=frame===70?{jump:true}:frame>70&&frame<90?{jump:true,x:1}:{};const a=dark.step(input),b=off.step(input),c=day.step(input);assert.deepEqual(physical(a),physical(b));assert.deepEqual(physical(a),physical(c));if(frame<10)assert(a.p.vy>0);}
 assert.equal(dark.view().p.grounded,true);assert.equal(dark.view().p.support,'floor');
});
