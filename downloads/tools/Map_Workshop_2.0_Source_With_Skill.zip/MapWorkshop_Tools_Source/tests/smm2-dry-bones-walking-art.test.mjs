import test from 'node:test';
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {createCanvas} from '@napi-rs/canvas';
import {drawSmm2DryBones,smm2DryBonesVisualPose,SMM2_DRY_BONES_GAIT_ROWS} from '../atlas/editor-smm2-bone-art.mjs';
import {SMM2_SOURCE_PIXELS} from '../atlas/editor-smm2-source-assets.mjs';
import {blank,validate} from '../atlas/editor-model.mjs';
import {createPlatformStage} from '../atlas/editor-mario-stage.mjs';
import {createPlatformMotor} from '../atlas/editor-mario-motor.mjs';

const bytes=c=>c.getContext('2d').getImageData(0,0,c.width,c.height).data;
const frozen=q=>{if(q&&typeof q==='object'){for(const v of Object.values(q))frozen(v);Object.freeze(q);}return q;};
const actor=(frame=0,scale=1,facing=-1)=>({id:'bones',kind:'walker',type:'dry-bones',x:(32+frame*2)*scale,y:64-24*scale,w:16*scale,h:24*scale,vx:-.5,facing,vy:0,grounded:true,smm2DryBones:{phase:'walking',size:scale===2?'giant':'normal'}});
function raster(q,tick=0){const c=createCanvas(64,64),ctx=c.getContext('2d');ctx.translate(16-Math.round(q.x),48-Math.round(q.y+q.h));drawSmm2DryBones(ctx,q,{tick});return c;}
const rgba=(c,x,y)=>[...c.getContext('2d').getImageData(x,y,1,1).data];

test('walking presents four different limb poses with alternating lifted feet and original head/eye/palette',()=>{
 const pictures=[0,1,2,3].map(i=>raster(frozen(actor(i))));
 assert.equal(new Set(pictures.map(c=>Buffer.from(bytes(c)).toString('hex'))).size,4);
 // First passing step lifts the front sole, opposite passing step lifts the rear.
 assert.equal(rgba(pictures[1],17,47)[3],0);assert.equal(rgba(pictures[1],31,47)[3],255);
 assert.equal(rgba(pictures[3],17,47)[3],255);assert.equal(rgba(pictures[3],31,47)[3],0);
 for(const c of pictures){
  let eyes=0;const palette=new Set(SMM2_SOURCE_PIXELS.dryBonesStanding.palette.filter(v=>!v.endsWith('00')).map(v=>v.slice(1,7)));
  const data=bytes(c);for(let i=0;i<data.length;i+=4){const p=data.slice(i,i+4);if(!p[3])continue;assert.equal(p[3],255);assert(palette.has(Buffer.from(p.slice(0,3)).toString('hex')));if(p[0]===41&&p[1]===206&&p[2]===255)eyes++;}
  assert.equal(eyes,3,'cyan eye remains three source pixels');
 }
 // The original source pose stays available unchanged as one stride contact pose.
 assert.deepEqual(SMM2_DRY_BONES_GAIT_ROWS[0],SMM2_SOURCE_PIXELS.dryBonesStanding.rows);
});

test('movement distance drives gait while stopped, preview, airborne and lifecycle poses stay distinct',()=>{
 const q=frozen(actor(1)),same=raster(q,0);for(const tick of [4,8,60,4096,NaN])assert.deepEqual(bytes(raster(q,tick)),bytes(same),'tick alone cannot create steps');
 assert.deepEqual(bytes(raster({...q,x:q.x+.5})),bytes(same),'less than a quarter stride holds the pose');
 assert.notDeepEqual(bytes(raster({...q,x:q.x+2})),bytes(same));
 const stopped=frozen({...q,vx:0}),preview=frozen({...q,vx:undefined,grounded:undefined}),air=frozen({...q,grounded:false,vy:1});
 const standing=raster(actor(0));for(const idle of [stopped,preview])for(const tick of [0,8,99])assert.deepEqual(bytes(raster(idle,tick)),bytes(standing));
 assert.equal(smm2DryBonesVisualPose(air).kind,'airborne');assert.notDeepEqual(bytes(raster(air)),bytes(standing));assert.notDeepEqual(bytes(raster(air)),bytes(same));
 for(const phase of ['collapsed','recovering'])assert.equal(smm2DryBonesVisualPose({...q,smm2DryBones:{phase}}).kind,phase);
 assert.deepEqual(smm2DryBonesVisualPose({...q,x:-2}),{kind:'walking',frame:3});
});

test('all walk and airborne poses mirror exactly, double every pixel for Big and do not mutate bodies or Canvas state',()=>{
 for(const frame of [0,1,2,3,4]){
  const a=frozen({...actor(frame%4),...(frame===4?{grounded:false}:{} )}),b=frozen({...actor(frame%4,2),...(frame===4?{grounded:false}:{} )}),before=JSON.stringify({a,b});
  const normal=raster(a),big=raster(b),right=raster({...a,facing:1});
  for(let y=0;y<24;y++)for(let x=0;x<16;x++){
   const p=rgba(normal,16+x,24+y);assert.deepEqual(rgba(right,31-x,24+y),p);
   for(const [dx,dy] of [[0,0],[1,0],[0,1],[1,1]])assert.deepEqual(rgba(big,16+x*2+dx,y*2+dy),p);
  }
  const c=createCanvas(64,64),ctx=c.getContext('2d');ctx.translate(3,4);ctx.imageSmoothingEnabled=true;const m=ctx.getTransform();drawSmm2DryBones(ctx,a,{tick:3});assert.deepEqual(ctx.getTransform(),m);assert.equal(ctx.imageSmoothingEnabled,true);assert.equal(JSON.stringify({a,b}),before);
 }
});

function nativeFixture(){
 const d=blank('Neutral native Dry Bones walking render',640,240),r=d.rooms[0];r.setting='Castle';
 r.map.geometry=[{id:'floor',x:0,y:176,w:640,h:64,collision:'solid',material:'castle'}];
 r.map.objects=[{id:'start',kind:'spawn',x:32,y:162,w:10,h:14},{id:'bones',kind:'walker',x:208,y:152,w:16,h:24}];
 r.smm2Mechanics={version:1};r.marioModules={version:1,itemSources:[],noteBlocks:[],oneWayWalls:[],enemyVariants:{bones:{kind:'dry-bones',size:'normal',speed:.5,direction:-1,collapsedHeight:8,collapseFrames:12,recoverFrames:4,bounceSpeed:4}}};validate(d);
 const stage=createPlatformStage({plan:{stage:{entryRoom:r.roomId,entrySpawn:'start',title:d.title},character:{capabilities:['jump'],motion:{width:10,height:14,maxHealth:1}},rooms:{[r.roomId]:r.map}},motor:createPlatformMotor(),visualRooms:d.rooms,initialState:{lives:3},allowWarp:false,autoContinue:false,emit:()=>{}});return {d,r,stage};
}

test('actual native walkers animate through ordinary stage stepping, with identical rendered and unrendered physics',()=>{
 const shown=nativeFixture(),control=nativeFixture(),poses=new Set(),pixels=new Set();
 for(let tick=0;tick<80;tick++){
  shown.stage.step({});control.stage.step({});const view=shown.stage.view(),other=control.stage.view(),q=view.enemies.find(e=>e.id==='bones'),before=JSON.stringify(view);
  assert.equal(q.grounded,true);assert.equal(q.vx,-.5);assert.equal(q.w,16);assert.equal(q.h,24);assert.equal(q.y+q.h,176);
  poses.add(smm2DryBonesVisualPose(q).frame);pixels.add(Buffer.from(bytes(raster(q,tick))).toString('hex'));
  assert.equal(JSON.stringify(view),before);assert.deepEqual(view,other,'rendering cannot affect movement, collision, phase or native clock');
 }
 assert.equal(poses.size,4);assert.equal(pixels.size,4);assert.equal(shown.stage.view().enemies[0].x,168);
});

// A subprocess supplies VM modules on every supported Node invocation.
test('actual standalone HTML embeds and executes the same gait module with no network access',async()=>{
 const script=fileURLToPath(new URL('../scripts/check-dry-bones-walking-art-offline.mjs',import.meta.url));
 const result=spawnSync(process.execPath,['--experimental-vm-modules',script],{encoding:'utf8',timeout:30000,maxBuffer:1024*1024});
 assert.equal(result.status,0,result.stderr||result.stdout||String(result.error));const report=JSON.parse(result.stdout);assert.equal(report.networkRequests,0);assert.equal(report.rasterScenes,28);assert.equal(report.nativeVideoRendererExecuted,true);assert.equal(report.stateUnchanged,true);
});
