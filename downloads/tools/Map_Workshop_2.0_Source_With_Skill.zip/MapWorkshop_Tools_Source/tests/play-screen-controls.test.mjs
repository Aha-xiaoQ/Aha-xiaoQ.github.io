import assert from 'node:assert/strict';
import {test} from 'node:test';
import {readFileSync} from 'node:fs';
import {blank,clone} from '../atlas/editor-model.mjs';
import {projectPack} from '../atlas/editor-runtime.mjs';
import {play} from '../atlas/editor-play.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';

// These tests execute real play handlers and Stage. Browser layout and physical
// input hardware need separate browser/device acceptance.
const character=JSON.parse(readFileSync(new URL('../atlas/runtime/character.json',import.meta.url)));
const mobile={pointer:'coarse',hover:false,width:390,height:844,maxTouchPoints:5};
const hybrid={pointer:'fine',hover:true,width:1366,height:768,maxTouchPoints:10};
function fixture({portal=false,mission=false}={}){
 const doc=blank('Neutral screen controls',640,240),room=doc.rooms[0];
 room.map.geometry=[{id:'floor',x:0,y:224,w:640,h:16,collision:'solid',material:'ground'}];
 room.map.objects=[{id:'start',kind:'spawn',x:24,y:210,w:10,h:14}];
 if(portal){const next=clone(room);next.roomId='next';next.map.id='next-map';room.map.objects.push({id:'door',kind:'portal',x:20,y:196,w:24,h:28,targetRoom:'next',targetSpawn:'start'});doc.rooms.push(next);}
 if(mission)room.missionBrief={version:1,number:1,title:'Neutral mission',description:'Enter to start',client:'Fixture',difficulty:1,rewardCoins:0};
 return {doc,pack:projectPack(doc,room.roomId,character,'screen-controls-fixture')};
}
const action=(session,id)=>session.screen.querySelector('[data-menu-action="'+id+'"]');
const direct=session=>session.screen.querySelector('.play-fullscreen-toggle');
const flush=async()=>{for(let i=0;i<5;i++)await Promise.resolve();};
const controller=()=>({id:'Xbox Wireless Controller',index:0,connected:true,mapping:'standard',axes:[0,0],buttons:Array.from({length:16},()=>({pressed:false,value:0}))});
function nativeApi(ui,{request,exit}={}){
 const calls={request:0,exit:0};ui.document.fullscreenEnabled=true;
 ui.Element.prototype.requestFullscreen=function(){calls.request++;if(request)return request(this);ui.document.fullscreenElement=this;ui.document.dispatchEvent({type:'fullscreenchange'});return Promise.resolve();};
 ui.document.exitFullscreen=()=>{calls.exit++;if(exit)return exit();ui.document.fullscreenElement=null;ui.document.dispatchEvent({type:'fullscreenchange'});return Promise.resolve();};
 return calls;
}

test('desktop mouse and hybrid hover hide the pad; coarse/no-hover mobile shows it at any width',async()=>{
 for(const [capabilities,wantVisible]of [[{},false],[{width:390},false],[hybrid,false],[mobile,true],[{...mobile,width:1366},true],[{pointer:'none',hover:false,width:1024},true]]){
  const ui=installSimulatedPlayDom(capabilities);let session;
  try{const {doc,pack}=fixture();session=await play(pack,doc.rooms,{}, {cleanUi:true});assert.equal(session.screen.querySelector('.play-gamepad').hidden,!wantVisible,JSON.stringify(capabilities));assert.equal(action(session,'touch').getAttribute('aria-expanded'),String(wantVisible));assert.equal(direct(session).hidden,false);assert.equal(direct(session).parentNode.hidden,false);ui.frames(2);const pad=controller();ui.pads.push(pad);ui.frames(2);pad.buttons[0].pressed=true;ui.frames(2);assert.equal(session.screen.querySelector('.play-gamepad').hidden,!wantVisible,'hardware gamepad does not choose virtual-pad visibility');}
  finally{session?.close();ui.restore();}
 }
});

test('capability/viewport changes adapt automatically; actual touch reveals a hybrid pad',async()=>{
 const ui=installSimulatedPlayDom(hybrid);let session;
 try{const {doc,pack}=fixture();session=await play(pack,doc.rooms,{}, {cleanUi:true});const pad=session.screen.querySelector('.play-gamepad');assert.equal(pad.hidden,true);session.screen.dispatchEvent({type:'pointerdown',pointerType:'mouse'});assert.equal(pad.hidden,true);ui.setInputCapabilities(mobile);assert.equal(pad.hidden,false);ui.setInputCapabilities(hybrid);assert.equal(pad.hidden,true);session.screen.dispatchEvent({type:'pointerdown',pointerType:'touch'});assert.equal(pad.hidden,false);ui.setInputCapabilities({width:1600});assert.equal(pad.hidden,false,'touch input remains usable after a resize');const right=session.screen.querySelector('[data-control=right]');right.dispatchEvent({type:'pointerdown',pointerId:1,pointerType:'touch'});ui.frames(20);right.dispatchEvent({type:'pointerup',pointerId:1,pointerType:'touch'});assert(session.screen.querySelector('canvas').workshopRead().p.x>24,'revealed pad drives the actual Stage');}
 finally{session?.close();ui.restore();}
});

test('manual pad choices survive touch, capability changes, restart, room transfer and clean/legacy loads',async()=>{
 const ui=installSimulatedPlayDom();let session;
 try{const {doc,pack}=fixture();session=await play(pack,doc.rooms,{}, {cleanUi:true});const pad=session.screen.querySelector('.play-gamepad'),view=()=>session.screen.querySelector('canvas').workshopRead();assert.equal(pad.hidden,true);action(session,'touch').click();assert.equal(pad.hidden,false);assert.equal(action(session,'touch').textContent,'隐藏触屏手柄');action(session,'restart').click();assert.equal(pad.hidden,false);const portal=fixture({portal:true});await session.load(portal.pack,portal.doc.rooms,{cleanUi:true});assert.equal(pad.hidden,false);ui.frames(10);ui.key('ArrowUp');ui.frames(30);ui.release('ArrowUp');assert.equal(view().roomId,'next');assert.equal(pad.hidden,false);action(session,'touch').click();assert.equal(pad.hidden,true);session.screen.dispatchEvent({type:'pointerdown',pointerType:'touch'});ui.setInputCapabilities(mobile);assert.equal(pad.hidden,true,'explicit hide wins over touch and device defaults');action(session,'restart').click();assert.equal(pad.hidden,true);await session.load(pack,doc.rooms,{});assert.equal(pad.hidden,true);assert.equal(direct(session).parentNode.hidden,false);await session.load(pack,doc.rooms,{cleanUi:true});assert.equal(pad.hidden,true);action(session,'touch').click();assert.equal(pad.hidden,false);}
 finally{session?.close();ui.restore();}
});

test('one-click fullscreen and F/Escape sync direct/menu labels without opening the menu or changing pad/chrome',async()=>{
 const ui=installSimulatedPlayDom();let session;
 try{const calls=nativeApi(ui),{doc,pack}=fixture();session=await play(pack,doc.rooms,{}, {cleanUi:true});const button=direct(session),pad=session.screen.querySelector('.play-gamepad'),menu=session.screen.querySelector('.play-pause-menu');ui.frames(3);assert.equal(calls.request,0,'play never enters fullscreen automatically');assert.equal(button.textContent,'全屏');assert.equal(button.parentNode,session.screen.querySelector('h2'));assert.equal(session.screen.querySelector('.play-controls .row').hidden,true);button.click();await flush();assert.equal(calls.request,1);assert.equal(ui.document.fullscreenElement,session.screen);assert.equal(button.textContent,'退出全屏');assert.equal(button.getAttribute('aria-pressed'),'true');assert.equal(action(session,'fullscreen').getAttribute('aria-pressed'),'true');assert.equal(action(session,'fullscreen').textContent,'退出全屏');assert.equal(menu.hidden,true);assert.equal(pad.hidden,true);ui.key('Escape');ui.release('Escape');await flush();assert.equal(calls.exit,1);assert.equal(button.textContent,'全屏');assert.equal(button.getAttribute('aria-pressed'),'false');assert.equal(menu.hidden,true,'Escape exits the display mode without toggling pause');ui.key('KeyF');ui.key('KeyF',true);ui.release('KeyF');await flush();assert.equal(calls.request,2,'held F does not repeatedly request fullscreen');ui.document.fullscreenElement=null;ui.document.dispatchEvent({type:'fullscreenchange'});assert.equal(button.textContent,'全屏','browser/system Escape is reflected immediately');assert.equal(button.getAttribute('aria-pressed'),'false');assert.equal(button.disabled,false);await session.load(pack,doc.rooms,{});assert.equal(calls.request,2,'load never requests fullscreen');session.screen.querySelector('h2 button').click();assert(session.screen.classList.contains('play-ui-hidden'));assert.equal(button.hidden,false);button.click();await flush();assert.equal(ui.document.fullscreenElement,session.screen);assert(session.screen.classList.contains('play-ui-hidden'),'fullscreen preserves the existing panel choice');}
 finally{session?.close();ui.restore();}
});

test('fullscreen rejection, pending repeats, fullscreenerror and later stale rejection all recover',async()=>{
 const ui=installSimulatedPlayDom();let session,rejectFirst;
 try{const calls=nativeApi(ui,{request:()=>new Promise((_resolve,reject)=>rejectFirst=reject)}),{doc,pack}=fixture();session=await play(pack,doc.rooms,{}, {cleanUi:true});const button=direct(session),hint=session.screen.querySelector('.play-fullscreen-hint');button.click();button.click();ui.key('KeyF');ui.release('KeyF');assert.equal(calls.request,1,'a pending native request has only one owner');assert.equal(button.disabled,true);assert.equal(action(session,'fullscreen').disabled,true);ui.document.dispatchEvent({type:'fullscreenerror'});assert.equal(button.disabled,false);assert.equal(action(session,'fullscreen').disabled,false);assert.equal(button.getAttribute('aria-pressed'),'false');assert.equal(hint.hidden,false);assert.match(hint.textContent,/未开启/);session.screen.requestFullscreen=async()=>{calls.request++;ui.document.fullscreenElement=session.screen;ui.document.dispatchEvent({type:'fullscreenchange'});};button.click();await flush();assert.equal(button.textContent,'退出全屏');assert.equal(button.disabled,false);rejectFirst(Error('stale denied request'));await flush();assert.equal(button.textContent,'退出全屏','a stale operation cannot overwrite newer actual state');assert.equal(hint.hidden,true);ui.document.fullscreenElement=null;ui.document.dispatchEvent({type:'fullscreenchange'});session.screen.requestFullscreen=async()=>{throw Error('permission denied');};await button.onclick();assert.equal(button.textContent,'全屏');assert.equal(button.getAttribute('aria-pressed'),'false');assert.equal(button.disabled,false);assert.equal(action(session,'fullscreen').disabled,false);assert.match(hint.textContent,/未开启/);session.screen.requestFullscreen=async()=>{ui.document.fullscreenElement=session.screen;ui.document.dispatchEvent({type:'fullscreenchange'});};await button.onclick();ui.document.exitFullscreen=async()=>{throw Error('exit denied');};await button.onclick();assert.equal(button.textContent,'退出全屏');assert.equal(button.getAttribute('aria-pressed'),'true');assert.equal(button.disabled,false);assert.match(hint.textContent,/退出全屏失败/);ui.document.exitFullscreen=async()=>{ui.document.fullscreenElement=null;ui.document.dispatchEvent({type:'fullscreenchange'});};await button.onclick();assert.equal(button.textContent,'全屏');assert.equal(hint.hidden,true);}
 finally{session?.close();ui.restore();}
});

test('unsupported fullscreen offers honest immersive mode and clears it through button or Escape',async()=>{
 const ui=installSimulatedPlayDom(mobile);let session;
 try{const {doc,pack}=fixture();session=await play(pack,doc.rooms,{}, {cleanUi:true});const button=direct(session),pad=session.screen.querySelector('.play-gamepad'),hint=session.screen.querySelector('.play-fullscreen-hint');assert.equal(button.textContent,'放大画面');assert.equal(button.disabled,false);assert.equal(session.screen.classList.contains('play-immersive'),false,'fallback also needs a gesture');button.click();assert.equal(session.screen.classList.contains('play-immersive'),true);assert.equal(button.textContent,'退出放大');assert.equal(button.getAttribute('aria-pressed'),'true');assert.equal(ui.document.fullscreenElement,undefined);assert.match(hint.textContent,/仅支持放大/);assert.equal(hint.hidden,false);assert.equal(pad.hidden,false);await session.load(pack,doc.rooms,{cleanUi:true});assert.equal(session.screen.classList.contains('play-immersive'),true);assert.equal(button.textContent,'退出放大');ui.key('Escape');ui.release('Escape');assert.equal(session.screen.classList.contains('play-immersive'),false);assert.equal(button.textContent,'放大画面');assert.equal(button.getAttribute('aria-pressed'),'false');assert.equal(hint.hidden,true);assert.equal(session.screen.querySelector('.play-pause-menu').hidden,true);ui.key('KeyF');ui.release('KeyF');button.click();assert.equal(session.screen.classList.contains('play-immersive'),false);session.close();assert.equal(ui.window.listeners.get('resize').length,0);assert(ui.mediaQueries.every(query=>(query.listeners.get('change')||[]).length===0),'closed sessions release media-query listeners');}
 finally{session?.close();ui.restore();}
});

test('mission overlay keeps the fullscreen button visible and uses the same gesture path',async()=>{
 const ui=installSimulatedPlayDom();let session;
 try{const calls=nativeApi(ui),{doc,pack}=fixture({mission:true});session=await play(pack,doc.rooms,{}, {cleanUi:true});assert(session.screen.classList.contains('mission-active'));assert.equal(direct(session).parentNode.hidden,false);assert.equal(direct(session).hidden,false);assert.equal(calls.request,0);direct(session).click();await flush();assert.equal(calls.request,1);assert.equal(direct(session).textContent,'退出全屏');ui.key('Escape');ui.release('Escape');await flush();assert(session.screen.classList.contains('mission-active'),'fullscreen Escape leaves the pending mission available');}
 finally{session?.close();ui.restore();}
});
