import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {background,drawTile,drawObject,drawPlayer,drawReference} from '../atlas/editor-art.mjs';
import {drawSmm2Actor,drawSmm2Tile,drawSmm2PlayerFootwear} from '../atlas/editor-smm2-art.mjs';
import {drawSmm2BoneShell,drawSmm2DryBones,SMM2_BONE_ART_PALETTE} from '../atlas/editor-smm2-bone-art.mjs';
import {SMM2_SOURCE_PIXELS} from '../atlas/editor-smm2-source-assets.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';
const require=createRequire(import.meta.url);
let createCanvas;try{({createCanvas}=require('@napi-rs/canvas'));}catch{}
const rasterTest=(name,fn)=>test(name,{skip:!createCanvas},fn);
const canvas=()=>createCanvas(384,216);
const bytes=c=>c.getContext('2d').getImageData(0,0,c.width,c.height).data;
const pixel=(c,x,y)=>[...c.getContext('2d').getImageData(x,y,1,1).data];
const room=()=>({setting:'Castle',map:{width:384,height:216,geometry:[],objects:[]},markers:[],decorations:[],nativeSceneryMode:'authored',smm2Mechanics:{version:1}});
function stats(c,opaque=true){let left=c.width,top=c.height,right=-1,bottom=-1,count=0;const colors=new Set(),d=bytes(c);for(let y=0;y<c.height;y++)for(let x=0;x<c.width;x++){const n=(y*c.width+x)*4;if(!d[n+3])continue;if(opaque)assert.equal(d[n+3],255,'authored pixel edges stay opaque');left=Math.min(left,x);top=Math.min(top,y);right=Math.max(right,x);bottom=Math.max(bottom,y);count++;colors.add([...d.slice(n,n+3)].join(','));}return {left,top,right,bottom,count,colors};}
function within(c,q){const s=stats(c);assert(s.count>0);assert(s.left>=q.x&&s.right<q.x+q.w&&s.top>=q.y&&s.bottom<q.y+q.h);assert.equal(s.bottom,q.y+q.h-1,'visible bones keep the physical bottom anchor');return s;}
function withNative(fn){const ui=installSimulatedPlayDom(),create=ui.document.createElement;ui.document.createElement=tag=>tag==='canvas'?createCanvas(1,1):create(tag);try{return fn();}finally{ui.restore();}}

rasterTest('Bone and Dry Bones dispatch requires an opt-in component or an explicit same-ID sidecar',()=>{
 const r=room(),shell={id:'shell',kind:'walker',x:32,y:80,w:16,h:18},bones={id:'bones',kind:'walker',x:64,y:72,w:16,h:24},c=canvas();
 assert.equal(drawSmm2Actor(c.getContext('2d'),shell,0,r),false);assert.equal(drawSmm2Actor(c.getContext('2d'),bones,0,r),false);
 assert.equal(drawSmm2Actor(c.getContext('2d'),{...bones,type:'dry-bones',smm2DryBones:{phase:'walking'}},0,{}),false);assert.equal(stats(c).count,0);
 r.smm2Mechanics.boneShells=[{id:'shell'}];r.marioModules={enemyVariants:{bones:{kind:'dry-bones',size:'normal'}}};const before=JSON.stringify({r,shell,bones});
 const shellCanvas=canvas(),bonesCanvas=canvas();assert.equal(drawSmm2Actor(shellCanvas.getContext('2d'),shell,0,r),true);assert.equal(drawSmm2Actor(bonesCanvas.getContext('2d'),bones,0,r),true);
 assert(within(shellCanvas,shell).colors.has('255,255,255'));assert(within(bonesCanvas,bones).colors.has('41,206,255'));assert.equal(JSON.stringify({r,shell,bones}),before,'sidecar lookup does not decorate static editor objects');
 assert.equal(drawSmm2Actor(c.getContext('2d'),{...bones,id:'unlisted'},0,r),false);assert.equal(stats(c).count,0);
});

rasterTest('normal and giant live skeletons use actual authored dimensions, steps, and facing',()=>{
 const normal={type:'dry-bones',x:32,y:56,w:16,h:24,vx:-.5,grounded:true,smm2DryBones:{size:'normal',phase:'walking'}},giant={...normal,x:80,y:32,w:32,h:48,smm2DryBones:{size:'giant',phase:'walking'}},a=canvas(),b=canvas(),before=JSON.stringify({normal,giant});
 drawSmm2DryBones(a.getContext('2d'),normal);drawSmm2DryBones(b.getContext('2d'),giant);const sa=within(a,normal),sb=within(b,giant);assert.equal(sb.count,sa.count*4);
 for(let y=1;y<24;y++)for(let x=0;x<16;x++)for(const [dx,dy]of [[0,0],[1,0],[0,1],[1,1]])assert.deepEqual(pixel(b,giant.x+x*2+dx,giant.y+y*2+dy),pixel(a,normal.x+x,normal.y+y));
 const step=canvas(),right=canvas();drawSmm2DryBones(step.getContext('2d'),{...normal,x:normal.x+2},{tick:8});drawSmm2DryBones(right.getContext('2d'),{...normal,vx:.5});assert.notDeepEqual(bytes(step),bytes(a),'actual movement advances an articulated walking pose');assert.notDeepEqual(bytes(right),bytes(a));
 for(let y=0;y<24;y++)for(let x=0;x<16;x++)assert.deepEqual(pixel(right,normal.x+x,normal.y+y),pixel(a,normal.x+15-x,normal.y+y));assert.equal(JSON.stringify({normal,giant}),before);
});

rasterTest('normal and giant piles remain low, with the original recovery pose at tick zero',()=>{
 for(const scale of [1,2]){
  const foot=128,q={type:'dry-bones',x:48,y:foot-8*scale,w:16*scale,h:8*scale,smm2DryBones:{phase:'collapsed',size:scale===1?'normal':'giant'}},before=JSON.stringify(q),pile=canvas(),recover=canvas(),live=canvas();
  drawSmm2DryBones(pile.getContext('2d'),q);drawSmm2DryBones(recover.getContext('2d'),{...q,smm2DryBones:{...q.smm2DryBones,phase:'recovering'}});drawSmm2DryBones(live.getContext('2d'),{...q,y:foot-24*scale,h:24*scale,smm2DryBones:{...q.smm2DryBones,phase:'walking'}});
  const sp=stats(pile);assert(sp.left>=q.x-5*scale/2&&sp.right<q.x+q.w+5*scale/2,'original 21px pile overhang is visual, not a enlarged collider');assert.equal(sp.bottom,foot-1);assert(!sp.colors.has('41,206,255'),'collapsed piles have hollow sockets rather than the live cyan eye');assert.equal(sp.top>=foot-8*scale,true);assert(stats(live).top<sp.top-8*scale);assert.deepEqual(bytes(pile),bytes(recover),'tick zero retains the exact sourced pile before the authored recovery warning');assert.equal(JSON.stringify(q),before);
 }
});

rasterTest('empty and mounted Bone Shell bodies share pixels and mounted actors never double draw',()=>{
 const r=room(),q={id:'shell',type:'smm2-shoe',kind:'walker',x:80,y:100,w:16,h:18,smm2Shoe:{kind:'bone-shell',occupancy:'empty'}},before=JSON.stringify(q),empty=canvas(),mounted=canvas(),body=canvas();
 assert.equal(drawSmm2Actor(empty.getContext('2d'),q,0,r),true);within(empty,q);
 assert.equal(drawSmm2Actor(mounted.getContext('2d'),{...q,smm2Shoe:{...q.smm2Shoe,occupancy:'player'}},0,r),true);assert.equal(stats(mounted).count,0);
 const p={x:83,y:86,w:10,h:18,smm2Shoe:{...q,kind:'bone-shell',occupancy:'player',smm2Shoe:undefined}};assert.equal(drawSmm2PlayerFootwear(body.getContext('2d'),p,0,r),true);const seated=canvas();drawSmm2BoneShell(seated.getContext('2d'),q,{rider:true});assert.deepEqual(bytes(body),bytes(seated));assert.deepEqual(bytes(body),bytes(empty),'original mounted/empty shell body is identical and never stretched');assert.equal(JSON.stringify(q),before);
 const pile=canvas(),collapsed={...q,y:110,h:8,smm2Shoe:{...q.smm2Shoe,playingDead:true}};drawSmm2BoneShell(pile.getContext('2d'),collapsed);within(pile,collapsed);assert.notDeepEqual(bytes(pile),bytes(empty));
 const compressed={...collapsed,y:114,h:4},low=canvas(),compressedBefore=JSON.stringify(compressed);drawSmm2BoneShell(low.getContext('2d'),compressed);within(low,{...compressed,y:compressed.y+compressed.h-8,h:8});assert.equal(JSON.stringify(compressed),compressedBefore,'the 4px physical pile retains its collision fields while a readable 8px bone silhouette is bottom anchored');
 for(const patch of [{hidden:true},{dead:true},{removed:true},{smm2Shoe:{kind:'bone-shell',occupancy:'removed'}}]){const absent=canvas();assert.equal(drawSmm2Actor(absent.getContext('2d'),{...q,...patch},0,r),true);assert.equal(stats(absent).count,0);}
});

rasterTest('mounted Super Bone Shell exactly matches the public 16 by 27 source composite',()=>withNative(()=>{
 const r=room(),shoe={id:'shell',x:80,y:104,w:16,h:16,kind:'bone-shell',occupancy:'player'},p={x:83,y:90,w:10,h:28,power:1,grounded:true,facing:1,smm2Shoe:shoe},actual=canvas(),expected=canvas(),before=JSON.stringify(p);
 drawPlayer(actual.getContext('2d'),p,0,undefined,r);
 const source=SMM2_SOURCE_PIXELS.mountedSuper;
 for(let y=0;y<source.h;y++)for(let x=0;x<source.w;x++){const color=source.palette[parseInt(source.rows[y][x],36)];if(color.endsWith('00'))continue;expected.getContext('2d').fillStyle=color;expected.getContext('2d').fillRect(shoe.x+x,shoe.y+shoe.h-source.h+y,1,1);}
 assert.deepEqual(bytes(actual),bytes(expected));assert.equal(JSON.stringify(p),before);
}));

rasterTest('playing dead hides the entire rider while the real pile remains visible through Mario blinking',()=>withNative(()=>{
 const r=room(),shoe={x:80,y:112,w:16,h:8,kind:'bone-shell',occupancy:'player',playingDead:true,phase:'collapsed'},p={x:83,y:88,w:10,h:28,power:1,grounded:true,facing:1,smm2Shoe:shoe},pile=canvas();drawSmm2BoneShell(pile.getContext('2d'),shoe);
 for(const patch of [{},{invulnerable:8},{smm2Shoe:{...shoe,playingDead:false,phase:'recovering'}}]){const actual=canvas();drawPlayer(actual.getContext('2d'),{...p,...patch},4,undefined,r);assert.deepEqual(bytes(actual),bytes(pile));assert.equal(pixel(actual,88,90)[3],0);within(actual,shoe);}
 const blink=canvas(),upright={...p,smm2Shoe:{...shoe,y:102,h:18,playingDead:false,phase:'active'},invulnerable:8},body=canvas();drawPlayer(blink.getContext('2d'),upright,4,undefined,r);drawSmm2BoneShell(body.getContext('2d'),upright.smm2Shoe);assert.deepEqual(bytes(blink),bytes(body),'rider blink keeps the independently physical shell visible');
}));

rasterTest('bone-only opt-in leaves native castle masonry, firebars, coins, Goombas and ordinary Mario pixels intact',()=>withNative(()=>{
 const r=room(),native={...r,smm2Mechanics:undefined};
 for(const material of ['ground','stone','brick','block','used','pipe']){const q={id:'native',x:32,y:144,w:32,h:32,material},actual=canvas(),expected=canvas();drawTile(actual.getContext('2d'),q,r);drawTile(expected.getContext('2d'),q,native);assert.deepEqual(bytes(actual),bytes(expected),material);}
 for(const q of [{kind:'coin',x:48,y:96,w:10,h:14},{kind:'walker',x:48,y:96,w:16,h:16}]){const actual=canvas(),expected=canvas();drawObject(actual.getContext('2d'),q,8,r);drawObject(expected.getContext('2d'),q,8,native);assert.deepEqual(bytes(actual),bytes(expected));}
 const firebar={id:'bar',kind:'rotating-firebar',x:96,y:96,source:{thing:'Fireball',width:6,clockwise:true,speed:1}},a=canvas(),b=canvas();drawReference(a.getContext('2d'),firebar,{...r,tick:12});drawReference(b.getContext('2d'),firebar,{...native,tick:12});assert.deepEqual(bytes(a),bytes(b));assert(stats(a,false).count>0,'comparison includes actual native firebar pixels');
 for(const power of [0,1,2])for(const pose of [{grounded:true,vx:0},{grounded:false,vx:1},{grounded:true,vx:-1,crouch:true}]){const p={x:83,y:86,w:10,h:power?30:14,power,facing:1,...pose},actual=canvas(),expected=canvas();drawPlayer(actual.getContext('2d'),p,8,undefined,r);drawPlayer(expected.getContext('2d'),p,8,undefined,native);assert.deepEqual(bytes(actual),bytes(expected));}
 const bg=canvas(),baseline=canvas();background(bg.getContext('2d'),r,384,216);background(baseline.getContext('2d'),native,384,216);assert.deepEqual(bytes(bg),bytes(baseline));assert.deepEqual(pixel(bg,383,215),[0,0,0,255]);assert.equal(r.smm2Mechanics.art,undefined);assert.equal(SMM2_BONE_ART_PALETTE.eye,'#29ceff');
}));

rasterTest('the specific three hanging bones stay decorative and never restyle native platforms',()=>withNative(()=>{
 const r=room(),q={id:'posts',x:48,y:96,w:48,h:64,material:'decoration',smm2Art:'bone-castle-semisolid-posts'},before=JSON.stringify(q),actual=canvas();assert.equal(drawSmm2Tile(actual.getContext('2d'),q,r),true);const s=stats(actual);assert(s.left>=q.x&&s.right<q.x+q.w&&s.top>=q.y&&s.bottom<q.y+q.h);assert.equal(pixel(actual,48+15,128)[3],0);assert.equal(pixel(actual,48+31,128)[3],0,'black gaps separate three actual column shafts');for(const center of [7,23,39])assert.equal(pixel(actual,48+center,128)[3],255);assert.equal(JSON.stringify(q),before);assert.equal(q.standable,undefined);assert.equal(q.oneWay,undefined);
 const platform={id:'native-platform',x:48,y:80,w:48,h:8,material:'platform'},a=canvas(),b=canvas();drawTile(a.getContext('2d'),platform,r);drawTile(b.getContext('2d'),platform,{...r,smm2Mechanics:undefined});assert.deepEqual(bytes(a),bytes(b));assert.equal(drawSmm2Tile(canvas().getContext('2d'),q,{}),false);
}));


rasterTest('seated Bone rider keeps the same native upper-body pose while moving or airborne',()=>withNative(()=>{
 const r=room(),shoe={id:'shell',x:80,y:104,w:16,h:16,kind:'bone-shell',occupancy:'player'},before=JSON.stringify(shoe);
 for(const power of [0,1,2]){const h=power?28:14,p={x:83,y:90,w:10,h,power,grounded:true,facing:1,vx:0,anim:0,smm2Shoe:shoe},a=canvas();drawPlayer(a.getContext('2d'),p,0,undefined,r);
 for(const state of [{vx:2.5,anim:18},{vx:-2,anim:41},{vx:2.5,anim:70,grounded:false,vy:3}]){const b=canvas();drawPlayer(b.getContext('2d'),{...p,...state},8,undefined,r);assert.equal(Buffer.compare(Buffer.from(bytes(a)),Buffer.from(bytes(b))),0,'vehicle motion cannot select a ground-run or jump animation');}
 }assert.equal(JSON.stringify(shoe),before);
}));
