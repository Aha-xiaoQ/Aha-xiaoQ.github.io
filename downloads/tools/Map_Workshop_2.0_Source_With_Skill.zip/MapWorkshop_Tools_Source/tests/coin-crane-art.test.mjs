import test from 'node:test';
import assert from 'node:assert/strict';
import {createCanvas} from '@napi-rs/canvas';
import {drawCoinCraneWorld,drawCoinCraneTile} from '../atlas/editor-coin-crane-art.mjs';
import {coinCraneProject,ordinaryCranePress,craneView} from './fixtures/coin-crane-native.mjs';
import {nativeSession} from './fixtures/shell-coin-native.mjs';
import {rendererRoom} from '../atlas/editor-renderer.mjs';
const pixels=c=>c.getContext('2d').getImageData(0,0,c.width,c.height).data;
test('original button is exactly its solid 16px body with opaque integer pixels and an independent pressed appearance',()=>{
 const r=coinCraneProject().rooms[0],g=r.map.geometry.find(g=>g.id==='push'),a=createCanvas(512,240),b=createCanvas(512,240);assert.equal(drawCoinCraneTile(a.getContext('2d'),g,r),true);assert.equal(drawCoinCraneTile(a.getContext('2d'),r.map.geometry[0],r),false);const d=pixels(a);let n=0;for(let y=0;y<240;y++)for(let x=0;x<512;x++){const alpha=d[(y*512+x)*4+3];if(alpha){n++;assert.equal(alpha,255);assert(x>=64&&x<80&&y>=144&&y<160);}}assert.equal(n,256);drawCoinCraneTile(b.getContext('2d'),g,{...r,contraptionsView:{coinCranes:[{...r.contraptions.coinCranes[0],buttonPressed:true}]}});assert.notDeepEqual(pixels(a),pixels(b));assert.equal(drawCoinCraneWorld(a.getContext('2d'),{}),false);
});
test('shared runtime projection draws actual scanning/lowered/closed/delivery poses and art never changes native state',()=>{
 const s=nativeSession(coinCraneProject()),r=s.doc.rooms[0],render=()=>{const view=s.view(),before=JSON.stringify(view),c=createCanvas(512,240);assert.equal(drawCoinCraneWorld(c.getContext('2d'),rendererRoom(r,view)),true);assert.equal(JSON.stringify(s.view()),before);for(let i=3,d=pixels(c);i<d.length;i+=4)assert(d[i]===0||d[i]===255);return c;};const scan=render();ordinaryCranePress(s);s.frames(40);const lowered=render();assert.notDeepEqual(pixels(scan),pixels(lowered));s.until(v=>v.contraptions.coinCranes[0].heldId,{},100);const closed=render();assert.equal(craneView(s).heldId,'physical-pink');assert.notDeepEqual(pixels(lowered),pixels(closed));s.until(v=>v.contraptions.coinCranes[0].phase==='open',{},450);assert.equal(craneView(s).grip.x,128);assert.notDeepEqual(pixels(scan),pixels(render()));
});
test('authored transparent glass draws only inside each real solid rectangle and leaves its interior open',()=>{
 const room=coinCraneProject().rooms[0];room.contraptions.coinCranes[0].glassIds=['pane'];for(const [w,h]of [[16,144],[4,1]]){const c=createCanvas(80,180),g={id:'pane',x:16,y:16,w,h,collision:'solid'};assert(drawCoinCraneTile(c.getContext('2d'),g,room));const d=pixels(c);let n=0;for(let y=0;y<c.height;y++)for(let x=0;x<c.width;x++){const a=d[(y*c.width+x)*4+3];if(a){assert.equal(a,255);assert(x>=16&&x<16+w&&y>=16&&y<16+h);n++;}}if(w===16)assert(n<w*h/2,'glass is visibly transparent');assert(n>0);}
});
