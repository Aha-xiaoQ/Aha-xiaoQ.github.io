import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {blank,History,parseProject,clone,uid,moveSelection,deleteSelection,linked,validate} from '../atlas/editor-model.mjs';
import {setPortableStone,removePortableStone,setLocalTwister,removeLocalTwister,setParachuteActor,removeParachuteActor,setCarryStoneClearCondition,clearCarryStoneClearCondition,captureHeavyStoneBindings,appendCopiedHeavyStoneBindings,pruneHeavyStoneReferences,mountHeavyStoneTools} from '../atlas/editor-heavy-stone-tools.mjs';
import {captureSmm2ActorLeaves,appendCopiedSmm2ActorLeaves,pruneSmm2DeletedReferences} from '../atlas/editor-smm2-tools.mjs';
import {captureSmm2GeometryBindings,appendSmm2GeometryBindings} from '../atlas/editor-smm2-course-tools.mjs';
import {captureSmm2LightingBindings,appendCopiedSmm2LightingBindings} from '../atlas/editor-smm2-lighting-tools.mjs';
import {captureSmm2BoneBindings,appendCopiedSmm2BoneBindings} from '../atlas/editor-smm2-bone-tools.mjs';
import {captureMarioEmptyShellSources,appendCopiedMarioEmptyShellSources} from '../atlas/editor-mario-modules-editor.mjs';
import {enableCopiedSpikeTraps} from '../atlas/editor-contraptions-tools.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';

// Neutral author choices; these values are not original-game calibration.
const stone=()=>({gravity:.25,maxFallSpeed:4,throwSpeedX:3,throwSpeedY:-2,releaseSafeFrames:2,heldOffsetX:0,heldBottomOffset:-4,carryMotion:{walkCap:.6,runCap:.8,airCap:.8,jumpSpeed:2,jumpGravity:.1,fallGravity:.3},points:200});
const twister=()=>({speed:.5,direction:-1,windHeight:96,visualHeight:128,bottomHalfWidth:8,topHalfWidth:24,riseAcceleration:.4,maxRiseSpeed:4});
function fixture({bound=false,secondRoom=false}={}){
 const d=blank('Stone authoring neutral fixture',640,384),r=d.rooms[0];
 r.map.geometry=[{id:'floor',x:0,y:352,w:640,h:32,collision:'solid',material:'ground'}];
 r.map.objects=[{id:'start',kind:'spawn',x:16,y:338,w:10,h:14},{id:'stone',kind:'walker',x:80,y:336,w:16,h:16},{id:'twister',kind:'walker',x:144,y:336,w:16,h:16},{id:'other',kind:'walker',x:208,y:336,w:16,h:16},{id:'goal',kind:'exit',x:512,y:224,w:16,h:64},{id:'goal-b',kind:'exit',x:560,y:224,w:16,h:64}];
 if(bound){setPortableStone(r,'stone',stone());setLocalTwister(r,'twister',twister());setCarryStoneClearCondition(r,'goal');}
 if(secondRoom){const target=blank('Target',640,384).rooms[0];target.roomId='target';target.map.id='target-map';target.map.geometry=clone(r.map.geometry);d.rooms.push(target);}
 return d;
}
const roundtrip=h=>assert.deepEqual(parseProject(JSON.stringify(h.doc)),h.doc);
const canopy=(variant='goomba')=>({variant,fallSpeed:.4,oscillation:{amplitude:10,periodFrames:120,phaseFrames:30.5},activation:{kind:'frame-in-view'}});
function parachuteFixture({bound=false,secondRoom=false}={}){const d=fixture({secondRoom}),r=d.rooms[0];r.map.objects.push({id:'ordinary-goomba',kind:'walker',x:256,y:64,w:16,h:16},{id:'ordinary-mushroom',kind:'walker',x:320,y:64,w:16,h:16});r.enemySkins={'ordinary-goomba':'enemy-goomba'};r.smm2Mechanics={version:1,placedItems:[{id:'ordinary-mushroom',kind:'mushroom',gravity:.17,maxFallSpeed:6.25,points:1234}]};if(bound){setParachuteActor(r,'ordinary-goomba',canopy());setParachuteActor(r,'ordinary-mushroom',canopy('super-mushroom'));}return d;}

test('complete Stone and local Twister APIs preserve native actors, detach nested tuning, and round-trip with History',()=>{
 const h=new History(fixture()),r=()=>h.doc.rooms[0],native=clone(r().map.objects),s=stone(),t=twister();
 h.change(()=>{setPortableStone(r(),'stone',s);setLocalTwister(r(),'twister',t);setCarryStoneClearCondition(r(),'goal');});
 s.carryMotion.walkCap=99;t.windHeight=300;
 assert.deepEqual(r().map.objects,native);assert.equal(r().smm2Mechanics.portableStones.stones[0].carryMotion.walkCap,.6);assert.equal(r().smm2Mechanics.localUpdrafts.twisters[0].windHeight,96);roundtrip(h);
 h.change(()=>setPortableStone(r(),'stone',{...stone(),gravity:0,points:0}));assert.equal(r().smm2Mechanics.portableStones.stones.length,1);assert.equal(r().smm2Mechanics.portableStones.stones[0].gravity,0);assert.equal(r().smm2Mechanics.portableStones.stones[0].points,0);
 h.undo();assert.equal(r().smm2Mechanics.portableStones.stones[0].gravity,.25);h.redo();assert.equal(r().smm2Mechanics.portableStones.stones[0].gravity,0);
 h.change(()=>removePortableStone(r(),'stone'));assert.equal(r().smm2Mechanics.portableStones,undefined);assert.deepEqual(r().map.objects,native);assert(r().smm2Mechanics.localUpdrafts);
 h.undo();assert.equal(r().smm2Mechanics.portableStones.clearCondition.goalId,'goal');h.change(()=>clearCarryStoneClearCondition(r()));assert.equal(r().smm2Mechanics.portableStones.clearCondition,undefined);assert.equal(r().smm2Mechanics.portableStones.stones.length,1);h.change(()=>removeLocalTwister(r(),'twister'));assert.equal(r().smm2Mechanics.localUpdrafts,undefined);roundtrip(h);
});

test('invalid or incomplete tuning and conflicting native ownership leave room and History unchanged',()=>{
 const h=new History(fixture({bound:true})),r=()=>h.doc.rooms[0],before=JSON.stringify(h.doc),undos=h.undoStack.length;
 const bad=[()=>setPortableStone(r(),'missing',stone()),()=>setPortableStone(r(),'twister',stone()),()=>setLocalTwister(r(),'stone',twister()),()=>setPortableStone(r(),'goal',stone()),()=>setPortableStone(r(),'stone',{...stone(),id:'other'}),()=>setPortableStone(r(),'stone',{...stone(),carryMotion:{...stone().carryMotion,teleport:undefined}}),()=>setPortableStone(r(),'stone',{...stone(),gravity:Infinity}),()=>setPortableStone(r(),'stone',{...stone(),releaseSafeFrames:.5}),()=>setLocalTwister(r(),'twister',{...twister(),direction:0}),()=>setLocalTwister(r(),'twister',{...twister(),topHalfWidth:2}),()=>setCarryStoneClearCondition(r(),'stone')];
 for(const key of Object.keys(stone()).filter(key=>key!=='points')){const value=stone();delete value[key];bad.push(()=>setPortableStone(r(),'stone',value));}
 for(const key of Object.keys(stone().carryMotion)){const value=stone();delete value.carryMotion[key];bad.push(()=>setPortableStone(r(),'stone',value));}
 for(const key of Object.keys(twister()).filter(key=>key!=='visualHeight')){const value=twister();delete value[key];bad.push(()=>setLocalTwister(r(),'twister',value));}
 for(const fn of bad){assert.throws(()=>h.change(fn));assert.equal(JSON.stringify(h.doc),before);assert.equal(h.undoStack.length,undos);}
 const unbound=fixture().rooms[0],original=JSON.stringify(unbound);assert.throws(()=>setCarryStoneClearCondition(unbound,'goal'));assert.equal(JSON.stringify(unbound),original);
 const wrongSize=fixture().rooms[0];wrongSize.map.objects.find(q=>q.id==='other').h=24;const sizeBefore=JSON.stringify(wrongSize);assert.throws(()=>setPortableStone(wrongSize,'other',stone()));assert.equal(JSON.stringify(wrongSize),sizeBefore);
});

test('real inspector reads selected native IDs, requires all authored coefficients, and follows History without fabricated defaults',()=>{
 const ui=installSimulatedPlayDom();try{
  const h=new History(fixture()),r=()=>h.doc.rooms[0],parent=ui.document.createElement('aside'),reports=[];let selection=new Set(['stone']);
  const tools=mountHeavyStoneTools({parent,room:r,selected:()=>selection,change:fn=>h.change(fn),report:q=>reports.push(q)}),get=key=>parent.querySelector('[data-heavy-stone="'+key+'"]');
  assert.equal(get('stone').value,'stone');assert.equal(get('stone-gravity').value,'');get('stone-apply').click();assert.equal(r().smm2Mechanics,undefined);assert.equal(h.undoStack.length,0);assert.match(reports[0],/请填写/);
  for(const [key,value]of Object.entries(stone()))if(key==='carryMotion')for(const [k,n]of Object.entries(value))get('carry-'+k).value=String(n);else get('stone-'+key).value=String(value);
  get('stone-apply').click();assert.equal(r().smm2Mechanics.portableStones.stones[0].id,'stone');assert.equal(r().map.objects.length,6);get('goal-apply').click();assert.equal(r().smm2Mechanics.portableStones.clearCondition.goalId,'goal');
  selection=new Set(['twister']);tools.refresh();assert.equal(get('twister').value,'twister');for(const [key,value]of Object.entries(twister()))get('twister-'+key).value=String(value);get('twister-apply').click();assert.equal(r().smm2Mechanics.localUpdrafts.twisters[0].id,'twister');
  const saved=JSON.stringify(h.doc),undos=h.undoStack.length;get('twister-speed').value='';get('twister-apply').click();assert.equal(JSON.stringify(h.doc),saved);assert.equal(h.undoStack.length,undos);assert.equal(get('twister-speed').value,'0.5');
  get('stone').value='stone';get('stone').dispatchEvent({type:'change'});tools.refresh();assert.equal(get('stone').value,'stone','manual dropdown choice survives unchanged canvas selection');assert.equal(get('carry-runCap').value,'0.8');
  h.undo();tools.refresh();assert.equal(r().smm2Mechanics.localUpdrafts,undefined);assert.equal(get('twister-speed').value,'');h.redo();tools.refresh();assert.equal(get('twister-speed').value,'0.5');selection=new Set(['goal-b']);tools.refresh();assert.equal(get('goal').value,'goal-b');get('goal-apply').click();assert.equal(r().smm2Mechanics.portableStones.clearCondition.goalId,'goal-b');roundtrip(h);
 }finally{ui.restore();}
});

test('separate clipboard snapshots copy real actor IDs and nested coefficients without leaking a carry goal',()=>{
 const h=new History(fixture({bound:true})),r=()=>h.doc.rooms[0],snap=captureHeavyStoneBindings(r(),new Set(['stone','twister'])),original=clone(r().smm2Mechanics.portableStones.stones[0]),ids=new Map([['stone','stone-copy'],['twister','twister-copy']]);
 assert.equal(snap.clearCondition,undefined);assert.equal(captureHeavyStoneBindings(r(),new Set(['goal'])).clearCondition,undefined);
 h.change(()=>{for(const [old,id]of ids)r().map.objects.push({...r().map.objects.find(q=>q.id===old),id,x:old==='stone'?336:400});appendCopiedHeavyStoneBindings(r(),snap,ids);});
 assert.equal(r().map.objects.length,8);assert.equal(r().smm2Mechanics.portableStones.stones.length,2);assert.equal(r().smm2Mechanics.localUpdrafts.twisters.length,2);assert.equal(r().smm2Mechanics.portableStones.clearCondition.goalId,'goal');assert.deepEqual(r().smm2Mechanics.portableStones.stones.find(q=>q.id==='stone-copy'),{...original,id:'stone-copy'});
 snap.stones[0].carryMotion.walkCap=99;snap.twisters[0].windHeight=400;assert.equal(r().smm2Mechanics.portableStones.stones.find(q=>q.id==='stone-copy').carryMotion.walkCap,.6);assert.equal(r().smm2Mechanics.localUpdrafts.twisters.find(q=>q.id==='twister-copy').windHeight,96);roundtrip(h);
 const copied=clone(h.doc);h.change(()=>{const before=clone(r());deleteSelection(r(),'objects',new Set(ids.values()));pruneHeavyStoneReferences(r(),before);});assert.equal(r().smm2Mechanics.portableStones.stones.length,1);assert.equal(r().smm2Mechanics.localUpdrafts.twisters.length,1);h.undo();assert.deepEqual(h.doc,copied);h.redo();roundtrip(h);
});

test('carry condition remaps only with a valid copied goal and stone, and conflicting/missing bodies fail atomically',()=>{
 const d=fixture({bound:true,secondRoom:true}),h=new History(d),source=h.doc.rooms[0],snapshot=captureHeavyStoneBindings(source,new Set(['stone','goal'])),ids=new Map([['stone','copied-stone'],['goal','copied-goal']]);assert.deepEqual(snapshot.clearCondition,{kind:'carry-stone',goalId:'goal'});
 h.change(()=>{const r=h.doc.rooms[1];for(const [old,id]of ids)r.map.objects.push({...source.map.objects.find(q=>q.id===old),id});appendCopiedHeavyStoneBindings(r,snapshot,ids);});
 assert.deepEqual(h.doc.rooms[1].smm2Mechanics.portableStones.clearCondition,{kind:'carry-stone',goalId:'copied-goal'});assert.equal(h.doc.rooms[0].smm2Mechanics.portableStones.clearCondition.goalId,'goal');roundtrip(h);
 const saved=JSON.stringify(h.doc),undos=h.undoStack.length;
 for(const candidate of [new Map([['stone','missing-stone'],['goal','copied-goal']]),new Map([['stone','copied-stone']])]){assert.throws(()=>h.change(()=>appendCopiedHeavyStoneBindings(h.doc.rooms[1],snapshot,candidate)));assert.equal(JSON.stringify(h.doc),saved);assert.equal(h.undoStack.length,undos);}
 assert.throws(()=>h.change(()=>{const r=h.doc.rooms[0];for(const [old,id]of ids)r.map.objects.push({...r.map.objects.find(q=>q.id===old),id,x:old==='stone'?336:448});appendCopiedHeavyStoneBindings(r,snapshot,ids);}),/已有搬运/);assert.equal(JSON.stringify(h.doc),saved);
 h.change(()=>{const r=h.doc.rooms[1],before=clone(r);deleteSelection(r,'objects',new Set(['copied-goal']));pruneHeavyStoneReferences(r,before);});assert.equal(h.doc.rooms[1].smm2Mechanics.portableStones.clearCondition,undefined);assert.equal(h.doc.rooms[1].smm2Mechanics.portableStones.stones.length,1);roundtrip(h);
});

test('delete prunes the last Stone gate and Twister binding while new dangling errors remain errors',()=>{
 const h=new History(fixture({bound:true})),r=()=>h.doc.rooms[0];h.change(()=>{const before=clone(r());deleteSelection(r(),'objects',new Set(['stone','twister']));pruneHeavyStoneReferences(r(),before);});assert.equal(r().smm2Mechanics.portableStones,undefined);assert.equal(r().smm2Mechanics.localUpdrafts,undefined);roundtrip(h);h.undo();assert.equal(r().smm2Mechanics.portableStones.clearCondition.goalId,'goal');h.redo();roundtrip(h);
 const malformed=fixture({bound:true}).rooms[0],before=clone(malformed);malformed.smm2Mechanics.portableStones.stones[0].id='never-existed';malformed.smm2Mechanics.localUpdrafts.twisters[0].id='never-existed';malformed.smm2Mechanics.portableStones.clearCondition.goalId='new-missing-goal';pruneHeavyStoneReferences(malformed,before);assert.equal(malformed.smm2Mechanics.portableStones.stones[0].id,'never-existed');assert.equal(malformed.smm2Mechanics.localUpdrafts.twisters[0].id,'never-existed');assert.equal(malformed.smm2Mechanics.portableStones.clearCondition.goalId,'new-missing-goal');assert.throws(()=>validate({...h.doc,rooms:[malformed]}));
});

// Execute the real native editor handlers, rather than reimplementing copy.
function actualClipboard(h,ui){
 const source=fs.readFileSync(new URL('../atlas/editor.mjs',import.meta.url),'utf8'),start=source.indexOf("$('copy').onclick="),end=source.indexOf("$('map-export').onclick=",start);assert(start>=0&&end>start);
 let index=0;const camera={x:320,y:96},buttons=Object.fromEntries(['copy','paste','delete'].map(id=>[id,ui.document.createElement('button')])),reports=[],room=()=>h.doc.rooms[index];
 const host={camera,selected:new Set(),$:id=>buttons[id],room,layer:()=>'objects',items:()=>room().map.objects,run:fn=>{try{fn();}catch(e){reports.push(e.message);}},say:q=>reports.push(q),refresh:()=>{},transaction:fn=>h.change(()=>{const before=clone(h.doc);fn();for(const r of h.doc.rooms){const old=before.rooms.find(q=>q.roomId===r.roomId);pruneSmm2DeletedReferences(r,old);pruneHeavyStoneReferences(r,old);}}),clone,uid,linked,moveSelection,deleteSelection,captureSmm2LightingBindings,appendCopiedSmm2LightingBindings,captureSmm2ActorLeaves,appendCopiedSmm2ActorLeaves,captureSmm2GeometryBindings,appendSmm2GeometryBindings,captureSmm2BoneBindings,appendCopiedSmm2BoneBindings,captureMarioEmptyShellSources,appendCopiedMarioEmptyShellSources,enableCopiedSpikeTraps,captureHeavyStoneBindings,appendCopiedHeavyStoneBindings};
 const names=Object.keys(host).filter(q=>!['camera','selected'].includes(q)).join(','),api=new Function('host','const {'+names+'}=host;let selected=host.selected,clipboard=null;const camera=host.camera;'+source.slice(start,end)+';return {select(ids){selected=new Set(ids);},selected(){return selected;}};')(host);
 return {...api,buttons,reports,camera,setRoom:i=>{index=i;}};
}

test('actual editor clipboard/delete handlers retain and prune both controller bindings with stable remapped IDs',()=>{
 const ui=installSimulatedPlayDom();try{
  const h=new History(fixture({bound:true})),native=actualClipboard(h,ui),r=()=>h.doc.rooms[0];native.select(['stone','twister']);native.buttons.copy.click();native.buttons.paste.click();const copies=[...native.selected()];assert.equal(copies.length,2);assert(copies.every(q=>!['stone','twister'].includes(q)));const copiedStone=r().smm2Mechanics.portableStones.stones.find(q=>copies.includes(q.id)),copiedTwister=r().smm2Mechanics.localUpdrafts.twisters.find(q=>copies.includes(q.id));assert(copiedStone&&copiedTwister);assert.equal(r().map.objects.filter(q=>copies.includes(q.id)).length,2);assert.equal(r().smm2Mechanics.portableStones.clearCondition.goalId,'goal');roundtrip(h);
  native.buttons.delete.click();assert(!r().smm2Mechanics.portableStones.stones.some(q=>copies.includes(q.id)));assert(!r().smm2Mechanics.localUpdrafts.twisters.some(q=>copies.includes(q.id)));h.undo();assert(r().smm2Mechanics.portableStones.stones.some(q=>q.id===copiedStone.id));h.redo();roundtrip(h);
 }finally{ui.restore();}
});

test('actual editor permits only valid goal+Stone group paste, remaps the gate across rooms, and preserves old gate on conflict',()=>{
 const ui=installSimulatedPlayDom();try{
  const h=new History(fixture({bound:true,secondRoom:true})),native=actualClipboard(h,ui);native.select(['goal']);native.buttons.copy.click();const saved=JSON.stringify(h.doc);native.buttons.paste.click();assert.equal(JSON.stringify(h.doc),saved);assert.match(native.reports.at(-1),/须与有效石材/);
  native.camera.x=0;native.select(['goal','stone']);native.buttons.copy.click();native.buttons.paste.click();assert.equal(JSON.stringify(h.doc),saved);assert.match(native.reports.at(-1),/已有搬运/);native.setRoom(1);native.buttons.paste.click();const r=h.doc.rooms[1],copies=[...native.selected()],goal=r.map.objects.find(q=>copies.includes(q.id)&&q.kind==='exit'),s=r.smm2Mechanics.portableStones.stones[0];assert(goal);assert(copies.includes(s.id));assert.equal(r.smm2Mechanics.portableStones.clearCondition.goalId,goal.id);assert.equal(h.doc.rooms[0].smm2Mechanics.portableStones.clearCondition.goalId,'goal');roundtrip(h);
  native.select([goal.id]);native.buttons.delete.click();assert.equal(h.doc.rooms[1].smm2Mechanics.portableStones.clearCondition,undefined);assert.equal(h.doc.rooms[1].smm2Mechanics.portableStones.stones[0].id,s.id);h.undo();assert.equal(h.doc.rooms[1].smm2Mechanics.portableStones.clearCondition.goalId,goal.id);h.redo();roundtrip(h);
 }finally{ui.restore();}
});

test('full native editor mounts the Stone inspector and its actual deletion transaction removes dangling gates',async()=>{
 const ui=installSimulatedPlayDom(),globals=new Map(),install=(key,value)=>{globals.set(key,Object.getOwnPropertyDescriptor(globalThis,key));Object.defineProperty(globalThis,key,{value,writable:true,configurable:true});};
 try{
  const storage=new Map([['xiaoq-map-workshop-tools-v1',JSON.stringify(fixture({bound:true}))]]);install('localStorage',{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v)});install('devicePixelRatio',1);install('ResizeObserver',class{observe(){}});install('setTimeout',()=>1);install('clearTimeout',()=>{});
  ui.Element.prototype.closest=function(s){for(let n=this;n;n=n.parentNode)if(s.split(',').some(q=>q===n.tag||q==='.'+n.className||q==='#'+n.id))return n;return null;};ui.Element.prototype.removeAttribute=function(key){delete this.attributes[key];};ui.Element.prototype.after=function(node){const p=this.parentNode;node.parentNode=p;p.children.splice(p.children.indexOf(this)+1,0,node);};
  const html=fs.readFileSync(new URL('../atlas/editor.html',import.meta.url),'utf8');ui.document.body.innerHTML=html.match(/<body[^>]*>([\s\S]*?)<\/body>/)[1];for(const n of ui.document.body.querySelectorAll('input')){n.value=n.getAttribute('value')||'';n.checked=n.getAttribute('checked')!==undefined;}for(const n of ui.document.body.querySelectorAll('select')){const rows=n.querySelectorAll('option'),choice=rows.find(q=>q.getAttribute('selected')!==undefined)||rows[0];n.value=choice?.getAttribute('value')||'';}
  const get=id=>ui.document.getElementById(id),canvas=get('canvas');get('viewport').clientWidth=480;get('viewport').clientHeight=384;canvas.getBoundingClientRect=()=>({left:0,top:0});get('zoom').value='1';await import('../atlas/editor.mjs?heavy-stone-authoring-native-entry');
  const inspector=key=>ui.document.querySelector('[data-heavy-stone="'+key+'"]');assert(inspector('stone-apply'));assert.equal(inspector('stone').value,'stone');assert.equal(inspector('stone-gravity').value,'0.25');
  const saved=()=>{get('save').click();return JSON.parse(storage.get('xiaoq-map-workshop-tools-v1'));},point=(type,x,y)=>canvas.dispatchEvent({type,button:0,pointerId:1,clientX:x,clientY:y});get('layer').value='objects';get('layer').dispatchEvent({type:'change'});get('tools').children.find(q=>q.textContent==='框选 V').click();point('pointerdown',84,340);point('pointerup',84,340);get('copy').click();get('paste').click();let d=saved(),copy=d.rooms[0].smm2Mechanics.portableStones.stones.find(q=>q.id!=='stone');assert(copy);assert(d.rooms[0].map.objects.some(q=>q.id===copy.id));get('delete').click();d=saved();assert.equal(d.rooms[0].smm2Mechanics.portableStones.stones.length,1);assert(!d.rooms[0].map.objects.some(q=>q.id===copy.id));
  point('pointerdown',84,340);point('pointerup',84,340);get('delete').click();d=saved();assert.equal(d.rooms[0].smm2Mechanics.portableStones,undefined);assert.equal(d.rooms[0].smm2Mechanics.localUpdrafts.twisters[0].id,'twister');get('undo').click();d=saved();assert.equal(d.rooms[0].smm2Mechanics.portableStones.clearCondition.goalId,'goal');point('pointerdown',84,340);point('pointerup',84,340);assert.equal(inspector('stone-gravity').value,'0.25');get('redo').click();d=saved();assert.equal(d.rooms[0].smm2Mechanics.portableStones,undefined);assert.deepEqual(parseProject(JSON.stringify(d)),d);
 }finally{for(const [key,descriptor]of globals){if(descriptor)Object.defineProperty(globalThis,key,descriptor);else delete globalThis[key];}ui.restore();}
});

test('parachute author APIs round-trip full configuration and retain ordinary Mushroom tuning and Goomba identity',()=>{
 const h=new History(parachuteFixture()),r=()=>h.doc.rooms[0],bodies=clone(r().map.objects),items=clone(r().smm2Mechanics.placedItems),skins=clone(r().enemySkins),g=canopy(),m=canopy('super-mushroom');h.change(()=>{setParachuteActor(r(),'ordinary-goomba',g);setParachuteActor(r(),'ordinary-mushroom',m);});g.oscillation.amplitude=88;m.activation.kind='room-entry';assert.equal(r().smm2Mechanics.parachuteActors.actors[0].oscillation.amplitude,10);assert.equal(r().smm2Mechanics.parachuteActors.actors[1].activation.kind,'frame-in-view');assert.deepEqual(r().map.objects,bodies);assert.deepEqual(r().smm2Mechanics.placedItems,items);assert.deepEqual(r().enemySkins,skins);roundtrip(h);
 h.change(()=>setParachuteActor(r(),'ordinary-mushroom',{...canopy('super-mushroom'),fallSpeed:.55,activation:{kind:'room-entry'}}));assert.equal(r().smm2Mechanics.parachuteActors.actors.length,2);h.undo();assert.equal(r().smm2Mechanics.parachuteActors.actors[1].fallSpeed,.4);h.redo();assert.equal(r().smm2Mechanics.parachuteActors.actors[1].fallSpeed,.55);
 h.change(()=>{removeParachuteActor(r(),'ordinary-goomba');removeParachuteActor(r(),'ordinary-mushroom');});assert.equal(r().smm2Mechanics.parachuteActors,undefined);assert.deepEqual(r().map.objects,bodies);assert.deepEqual(r().smm2Mechanics.placedItems,items);assert.deepEqual(r().enemySkins,skins);h.undo();assert.equal(r().smm2Mechanics.parachuteActors.actors.length,2);roundtrip(h);
});

test('parachute APIs reject omitted fields, non-Goomba identity, missing ordinary Mushroom and conflicting ownership atomically',()=>{
 const h=new History(parachuteFixture({bound:true})),r=()=>h.doc.rooms[0],saved=JSON.stringify(h.doc),undos=h.undoStack.length,bad=[()=>setParachuteActor(r(),'stone',canopy()),()=>setParachuteActor(r(),'ordinary-mushroom',canopy()),()=>setParachuteActor(r(),'ordinary-goomba',canopy('super-mushroom')),()=>setParachuteActor(r(),'ordinary-goomba',{...canopy(),fallSpeed:NaN}),()=>setParachuteActor(r(),'ordinary-goomba',{...canopy(),id:'stone'}),()=>setParachuteActor(r(),'ordinary-goomba',{...canopy(),oscillation:{...canopy().oscillation,script:undefined}}),()=>setParachuteActor(r(),'ordinary-goomba',{...canopy(),oscillation:{...canopy().oscillation,phaseFrames:120}}),()=>setParachuteActor(r(),'ordinary-goomba',{...canopy(),activation:{kind:'video-time'}}),()=>setPortableStone(r(),'ordinary-goomba',stone()),()=>setLocalTwister(r(),'ordinary-goomba',twister())];
 for(const path of [['variant'],['fallSpeed'],['oscillation'],['activation'],['oscillation','amplitude'],['oscillation','periodFrames'],['oscillation','phaseFrames'],['activation','kind']]){const value=canopy();if(path.length===1)delete value[path[0]];else delete value[path[0]][path[1]];bad.push(()=>setParachuteActor(r(),'ordinary-goomba',value));}
 for(const fn of bad){assert.throws(()=>h.change(fn));assert.equal(JSON.stringify(h.doc),saved);assert.equal(h.undoStack.length,undos);}
 const wrong=parachuteFixture().rooms[0];wrong.enemySkins['ordinary-goomba']='enemy-koopa';const before=JSON.stringify(wrong);assert.throws(()=>setParachuteActor(wrong,'ordinary-goomba',canopy()),/已有原生 Goomba/);assert.equal(JSON.stringify(wrong),before);
 const malformed=parachuteFixture({bound:true}).rooms[0],prior=clone(malformed);malformed.smm2Mechanics.parachuteActors.actors[0].id='new-dangling';pruneHeavyStoneReferences(malformed,prior);assert.equal(malformed.smm2Mechanics.parachuteActors.actors[0].id,'new-dangling');assert.throws(()=>validate({...h.doc,rooms:[malformed]}));
});

test('real parachute inspector uses selected native actor IDs and complete numeric parameters with History',()=>{
 const ui=installSimulatedPlayDom();try{
  const h=new History(parachuteFixture()),r=()=>h.doc.rooms[0],parent=ui.document.createElement('aside'),reports=[];let selection=new Set(['ordinary-goomba']);const tools=mountHeavyStoneTools({parent,room:r,selected:()=>selection,change:fn=>h.change(fn),report:q=>reports.push(q)}),get=key=>parent.querySelector('[data-heavy-stone="'+key+'"]');
  assert.equal(get('parachute').value,'ordinary-goomba');assert.equal(get('parachute-fallSpeed').value,'');get('parachute-apply').click();assert.equal(r().smm2Mechanics.parachuteActors,undefined);assert.equal(h.undoStack.length,0);assert.match(reports[0],/请填写/);
  const fill=variant=>{get('parachute-variant').value=variant;get('parachute-fallSpeed').value='.4';get('parachute-amplitude').value='10';get('parachute-periodFrames').value='120';get('parachute-phaseFrames').value='30.5';get('parachute-activation').value='room-entry';};fill('goomba');get('parachute-apply').click();assert.equal(r().smm2Mechanics.parachuteActors.actors[0].activation.kind,'room-entry');selection=new Set(['ordinary-mushroom']);tools.refresh();assert.equal(get('parachute').value,'ordinary-mushroom');fill('super-mushroom');get('parachute-apply').click();assert.equal(r().smm2Mechanics.parachuteActors.actors.length,2);assert.equal(r().smm2Mechanics.placedItems[0].gravity,.17);
  const saved=JSON.stringify(h.doc),undos=h.undoStack.length;get('parachute-periodFrames').value='3';get('parachute-apply').click();assert.equal(JSON.stringify(h.doc),saved);assert.equal(h.undoStack.length,undos);assert.equal(get('parachute-periodFrames').value,'120');get('parachute-remove').click();assert.equal(r().smm2Mechanics.parachuteActors.actors.length,1);assert.equal(r().smm2Mechanics.placedItems[0].points,1234);h.undo();tools.refresh();assert.equal(get('parachute-variant').value,'super-mushroom');assert.equal(get('parachute-phaseFrames').value,'30.5');h.redo();tools.refresh();assert.equal(get('parachute-fallSpeed').value,'');roundtrip(h);
 }finally{ui.restore();}
});

test('actual native clipboard remaps parachute Goomba skin and shared Mushroom sidecars together across rooms',()=>{
 const ui=installSimulatedPlayDom();try{
  const h=new History(parachuteFixture({bound:true,secondRoom:true})),native=actualClipboard(h,ui);native.camera.x=0;native.select(['ordinary-goomba','ordinary-mushroom']);native.buttons.copy.click();native.setRoom(1);native.buttons.paste.click();const r=h.doc.rooms[1],copies=[...native.selected()],leaf=r.smm2Mechanics.parachuteActors;assert.equal(copies.length,2);assert.equal(leaf.actors.length,2);const g=leaf.actors.find(q=>q.variant==='goomba'),m=leaf.actors.find(q=>q.variant==='super-mushroom');assert(g&&m);assert(copies.includes(g.id)&&copies.includes(m.id));assert.equal(r.enemySkins[g.id],'enemy-goomba');assert.deepEqual(r.smm2Mechanics.placedItems[0],{...h.doc.rooms[0].smm2Mechanics.placedItems[0],id:m.id});assert.equal(r.map.objects.filter(q=>copies.includes(q.id)).length,2);assert.equal(r.smm2Mechanics.placedItems.filter(q=>q.id===m.id).length,1);roundtrip(h);
  const copied=clone(h.doc);native.buttons.delete.click();assert.equal(h.doc.rooms[1].smm2Mechanics.parachuteActors,undefined);assert.equal(h.doc.rooms[1].smm2Mechanics.placedItems.length,0);assert.equal(h.doc.rooms[1].enemySkins[g.id],undefined);h.undo();assert.deepEqual(h.doc,copied);h.redo();roundtrip(h);assert.equal(h.doc.rooms[0].smm2Mechanics.parachuteActors.actors.length,2);assert.equal(h.doc.rooms[0].smm2Mechanics.placedItems[0].points,1234);
 }finally{ui.restore();}
});
