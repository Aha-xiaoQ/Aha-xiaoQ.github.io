import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {blank,History,parseProject,clone,uid,moveSelection,deleteSelection,linked,validate} from '../atlas/editor-model.mjs';
import {setLakituCloud,removeLakituCloud,cloneLakituCloud,setGoalCloudRequirement,clearGoalCloudRequirement,setRailHazard,removeRailHazard,pruneLakituReferences,captureRailHazardBindings,appendCopiedRailHazardBindings,mountLakituTools} from '../atlas/editor-lakitu-tools.mjs';
import {validateLakituCloudPlacement} from '../atlas/editor-lakitu-placement.mjs';
import {createLakituClouds} from '../atlas/editor-lakitu-clouds.mjs';
import {createRailHazards} from '../atlas/editor-rail-hazards.mjs';
import {captureSmm2ActorLeaves,appendCopiedSmm2ActorLeaves,pruneSmm2DeletedReferences} from '../atlas/editor-smm2-tools.mjs';
import {captureSmm2GeometryBindings,appendSmm2GeometryBindings} from '../atlas/editor-smm2-course-tools.mjs';
import {captureSmm2LightingBindings,appendCopiedSmm2LightingBindings} from '../atlas/editor-smm2-lighting-tools.mjs';
import {captureSmm2BoneBindings,appendCopiedSmm2BoneBindings} from '../atlas/editor-smm2-bone-tools.mjs';
import {captureMarioEmptyShellSources,appendCopiedMarioEmptyShellSources} from '../atlas/editor-mario-modules-editor.mjs';
import {enableCopiedSpikeTraps} from '../atlas/editor-contraptions-tools.mjs';
import {captureHeavyStoneBindings,appendCopiedHeavyStoneBindings} from '../atlas/editor-heavy-stone-tools.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';

// These are neutral author fits, never claims of recovered original physics.
const cloud=(extra={})=>({x:96,y:80,w:20,h:16,acceleration:.16,maxSpeed:2,drag:.125,seatOffsetY:-4,boardTolerance:2,hoverAmplitude:0,hoverPeriodFrames:120,...extra});
const hazard=(extra={})=>({trackId:'guide',speed:1,distance:0,direction:1,collisionRadius:22,rotationFrames:160,rotationDirection:-1,...extra});
function fixture({bound=false,secondRoom=false}={}){
 const d=blank('Cloud / rail neutral fixture',640,384),r=d.rooms[0];
 r.map.geometry=[{id:'floor',x:0,y:352,w:640,h:32,collision:'solid',material:'ground'}];
 r.map.objects=[{id:'start',kind:'spawn',x:16,y:338,w:10,h:14},{id:'grinder-a',kind:'hazard',x:136,y:136,w:48,h:48},{id:'grinder-b',kind:'hazard',x:240,y:136,w:48,h:48},{id:'other',kind:'walker',x:400,y:64,w:16,h:16},{id:'goal',kind:'exit',x:512,y:224,w:16,h:64},{id:'goal-b',kind:'exit',x:560,y:224,w:16,h:64}];
 r.contraptions={version:1,tracks:[{id:'guide',start:[160,160],segments:[{kind:'quadratic',control:[212,216],to:[264,160]},{kind:'line',to:[160,160]}],mode:'loop'}]};
 if(bound){setLakituCloud(r,'cloud-a',cloud());setRailHazard(r,'grinder-a',hazard());setRailHazard(r,'grinder-b',hazard({distance:40,direction:-1}));setGoalCloudRequirement(r,'goal','cloud-a');}
 if(secondRoom){const target=blank('Target',640,384).rooms[0];target.roomId='target';target.map.id='target-map';target.map.geometry=clone(r.map.geometry);d.rooms.push(target);}
 return d;
}
const roundtrip=h=>assert.deepEqual(parseProject(JSON.stringify(h.doc)),h.doc);

test('standalone Cloud add/edit/clone/delete is atomic, has no native proxy, and round-trips with goal references',()=>{
 const h=new History(fixture()),r=()=>h.doc.rooms[0],native=clone(r().map.objects),config=cloud();
 h.change(()=>{setLakituCloud(r(),'cloud-a',config);setGoalCloudRequirement(r(),'goal','cloud-a');});config.maxSpeed=99;
 assert.deepEqual(r().map.objects,native);assert.equal(r().smm2Mechanics.lakituClouds.clouds[0].maxSpeed,2);roundtrip(h);
 h.change(()=>setLakituCloud(r(),'cloud-a',cloud({x:112,maxSpeed:1.75})));assert.equal(r().smm2Mechanics.lakituClouds.clouds.length,1);
 h.change(()=>cloneLakituCloud(r(),'cloud-a','cloud-copy',{x:336,y:80}));const copy=r().smm2Mechanics.lakituClouds.clouds[1];assert.deepEqual(copy,{...r().smm2Mechanics.lakituClouds.clouds[0],id:'cloud-copy',x:336,y:80});assert.deepEqual(r().smm2Mechanics.goalCloudRequirements,[{exitId:'goal',cloudId:'cloud-a'}]);
 h.undo();assert.equal(r().smm2Mechanics.lakituClouds.clouds.length,1);h.redo();assert.equal(r().smm2Mechanics.lakituClouds.clouds.length,2);
 h.change(()=>removeLakituCloud(r(),'cloud-a'));assert.equal(r().smm2Mechanics.goalCloudRequirements,undefined);assert.equal(r().smm2Mechanics.lakituClouds.clouds[0].id,'cloud-copy');assert.deepEqual(r().map.objects,native);h.undo();assert.equal(r().smm2Mechanics.goalCloudRequirements[0].cloudId,'cloud-a');
 h.change(()=>clearGoalCloudRequirement(r(),'goal'));assert.equal(r().smm2Mechanics.goalCloudRequirements,undefined);h.change(()=>{removeLakituCloud(r(),'cloud-a');removeLakituCloud(r(),'cloud-copy');});assert.equal(r().smm2Mechanics.lakituClouds,undefined);roundtrip(h);
});

test('all Cloud and Grinder coefficients are required and invalid edits leave both room and History unchanged',()=>{
 const h=new History(fixture({bound:true})),r=()=>h.doc.rooms[0],before=JSON.stringify(h.doc),undos=h.undoStack.length;
 const bad=[()=>setLakituCloud(r(),'cloud-a',{...cloud(),id:'other'}),()=>setLakituCloud(r(),'grinder-a',cloud()),()=>setLakituCloud(r(),'cloud-a',cloud({maxSpeed:Infinity})),()=>setLakituCloud(r(),'cloud-a',cloud({w:16})),()=>setLakituCloud(r(),'cloud-a',cloud({x:-1})),()=>setLakituCloud(r(),'cloud-a',cloud({y:2})),()=>setLakituCloud(r(),'cloud-a',cloud({hoverPeriodFrames:120.5})),()=>cloneLakituCloud(r(),'cloud-a','cloud-a',{x:64,y:64}),()=>cloneLakituCloud(r(),'cloud-a','new-copy',{x:64,y:64,teleport:true}),()=>setGoalCloudRequirement(r(),'other','cloud-a'),()=>setGoalCloudRequirement(r(),'goal','missing-cloud'),()=>setRailHazard(r(),'other',hazard()),()=>setRailHazard(r(),'grinder-a',hazard({trackId:'missing-guide'})),()=>setRailHazard(r(),'grinder-a',hazard({speed:NaN})),()=>setRailHazard(r(),'grinder-a',hazard({collisionRadius:25})),()=>setRailHazard(r(),'grinder-a',hazard({direction:0})),()=>setRailHazard(r(),'grinder-a',hazard({rotationFrames:2.5})),()=>setRailHazard(r(),'grinder-a',{...hazard(),teleport:true})];
 for(const key of Object.keys(cloud())){const value=cloud();delete value[key];bad.push(()=>setLakituCloud(r(),'cloud-a',value));}
 for(const key of Object.keys(hazard())){const value=hazard();delete value[key];bad.push(()=>setRailHazard(r(),'grinder-a',value));}
 for(const fn of bad){assert.throws(()=>h.change(fn));assert.equal(JSON.stringify(h.doc),before);assert.equal(h.undoStack.length,undos);}
 const wrongSize=fixture().rooms[0];wrongSize.map.objects.find(q=>q.id==='grinder-a').h=16;const saved=JSON.stringify(wrongSize);assert.throws(()=>setRailHazard(wrongSize,'grinder-a',hazard()));assert.equal(JSON.stringify(wrongSize),saved);
});

test('initial Cloud seat follows real permanent terrain rejection while unsupported air, dynamic puzzles and visual overhang remain legal',()=>{
 const r=fixture().rooms[0];r.map.geometry.push({id:'seat-wall',x:101,y:76,w:10,h:14,collision:'solid',material:'stone'});const before=JSON.stringify(r);
 assert.throws(()=>setLakituCloud(r,'cloud-a',cloud()),/seat overlaps permanent/);assert.equal(JSON.stringify(r),before);
 const raw=clone(r);raw.smm2Mechanics={version:1,lakituClouds:{version:1,clouds:[{id:'cloud-a',...cloud()}]}};assert.throws(()=>validateLakituCloudPlacement(raw),/seat overlaps permanent/);
 const controller=createLakituClouds(raw),p={x:101,y:48,w:10,h:14,vx:0,vy:0};controller.sync({tick:0,player:p,geometry:raw.map.geometry});p.y=68;p.vy=20;controller.sync({tick:1,player:p,geometry:raw.map.geometry});assert.equal(controller.ownsPlayer(p),false);
 for(const terrain of [{id:'moving',x:101,y:76,w:10,h:14,collision:'solid',material:'stone',motion:{axis:'x',min:90,max:140,speed:1}},{id:'hidden',x:101,y:76,w:10,h:14,collision:'solid',material:'stone',hidden:true},{id:'oneway',x:101,y:76,w:10,h:14,collision:'oneway',material:'platform'}]){const candidate=fixture().rooms[0];candidate.map.geometry.push(terrain);assert.doesNotThrow(()=>setLakituCloud(candidate,'cloud-a',cloud()),'initial dynamic/state terrain is authorable; runtime still checks boarding');}
 const overhang=fixture().rooms[0];overhang.map.geometry.push({id:'visual-only-wall',x:96,y:80,w:4,h:16,collision:'solid',material:'stone'});assert.doesNotThrow(()=>setLakituCloud(overhang,'cloud-a',cloud()),'the sprite cannot invent solid collision faces');assert.doesNotThrow(()=>setLakituCloud(fixture().rooms[0],'unsupported-air',cloud({x:400,y:32})));
});

test('Grinder bindings retain native IDs and tracks and native deletion prunes profiles before final validation',()=>{
 const h=new History(fixture({bound:true})),r=()=>h.doc.rooms[0],tracks=clone(r().contraptions.tracks),native=clone(r().map.objects);
 h.change(()=>setRailHazard(r(),'grinder-a',hazard({speed:2,distance:12,rotationDirection:1})));assert.deepEqual(r().map.objects,native);assert.deepEqual(r().contraptions.tracks,tracks);assert.equal(r().smm2Mechanics.railHazards.hazards.length,2);roundtrip(h);
 h.change(()=>removeRailHazard(r(),'grinder-a'));assert.deepEqual(r().contraptions.tracks,tracks);assert.deepEqual(r().map.objects,native);h.undo();
 h.change(()=>{const prior=clone(r());deleteSelection(r(),'objects',new Set(['grinder-a','goal']));pruneLakituReferences(r(),prior);});assert.equal(r().smm2Mechanics.railHazards.hazards.length,1);assert.equal(r().smm2Mechanics.railHazards.hazards[0].id,'grinder-b');assert.equal(r().smm2Mechanics.goalCloudRequirements,undefined);assert.deepEqual(r().contraptions.tracks,tracks);roundtrip(h);
 h.undo();assert.equal(r().smm2Mechanics.railHazards.hazards.length,2);assert.equal(r().smm2Mechanics.goalCloudRequirements[0].exitId,'goal');h.redo();roundtrip(h);
 const malformed=fixture({bound:true}).rooms[0],prior=clone(malformed);malformed.smm2Mechanics.railHazards.hazards[0].id='never-existed';malformed.smm2Mechanics.goalCloudRequirements[0].exitId='never-existed';pruneLakituReferences(malformed,prior);assert.equal(malformed.smm2Mechanics.railHazards.hazards[0].id,'never-existed');assert.throws(()=>validate({...h.doc,rooms:[malformed]}));
});

test('real Cloud / Grinder panel places empty components, edits full fits, clones saved controller config and follows History',()=>{
 const ui=installSimulatedPlayDom();try{
  const h=new History(fixture()),r=()=>h.doc.rooms[0],parent=ui.document.createElement('aside'),reports=[];let selection=new Set(['grinder-a']);const tools=mountLakituTools({parent,room:r,selected:()=>selection,change:fn=>h.change(fn),report:q=>reports.push(q)}),get=key=>parent.querySelector('[data-lakitu-tool="'+key+'"]');
  assert.match(parent.textContent,/本地参数需按原动态核对/);assert.equal(get('cloud-maxSpeed').value,'2');assert.equal(get('cloud-acceleration').value,'0.16');get('cloud-id').value='cloud-ui';get('cloud-x').value='112';get('cloud-y').value='64';get('cloud-apply').click();assert.equal(r().smm2Mechanics.lakituClouds.clouds[0].id,'cloud-ui');assert.equal(r().map.objects.length,6);get('cloud-maxSpeed').value='1.25';get('cloud-apply').click();assert.equal(r().smm2Mechanics.lakituClouds.clouds[0].maxSpeed,1.25);
  get('goal-apply').click();assert.deepEqual(r().smm2Mechanics.goalCloudRequirements,[{exitId:'goal',cloudId:'cloud-ui'}]);get('cloud-maxSpeed').value='7';get('clone-id').value='cloud-ui-copy';get('clone-x').value='336';get('clone-y').value='96';get('cloud-clone').click();assert.equal(r().smm2Mechanics.lakituClouds.clouds[1].maxSpeed,1.25,'clone copies the saved configuration');assert.equal(get('cloud').value,'cloud-ui-copy');assert.equal(get('cloud-id').readOnly,true);
  assert.equal(get('hazard').value,'grinder-a');get('hazard-speed').value='1.5';get('hazard-distance').value='12';get('hazard-apply').click();assert.equal(r().smm2Mechanics.railHazards.hazards[0].speed,1.5);selection=new Set(['grinder-b']);tools.refresh();assert.equal(get('hazard').value,'grinder-b');get('hazard-apply').click();assert.equal(r().smm2Mechanics.railHazards.hazards.length,2);
  const saved=JSON.stringify(h.doc),undos=h.undoStack.length;get('hazard-speed').value='';get('hazard-apply').click();assert.equal(JSON.stringify(h.doc),saved);assert.equal(h.undoStack.length,undos);assert.match(reports.at(-1),/请填写/);assert.equal(get('hazard-speed').value,'1');get('hazard-remove').click();assert.equal(r().smm2Mechanics.railHazards.hazards.length,1);h.undo();tools.refresh();assert.equal(get('hazard-speed').value,'1');h.redo();tools.refresh();roundtrip(h);
  get('cloud').value='cloud-ui';get('cloud').dispatchEvent({type:'change'});assert.equal(get('cloud-maxSpeed').value,'1.25');get('cloud-remove').click();assert.equal(r().smm2Mechanics.goalCloudRequirements,undefined);h.undo();tools.refresh();assert.equal(r().smm2Mechanics.goalCloudRequirements[0].cloudId,'cloud-ui');roundtrip(h);
 }finally{ui.restore();}
});

// Execute actual editor native handlers; do not reproduce their copy logic.
function actualClipboard(h,ui){
 const source=fs.readFileSync(new URL('../atlas/editor.mjs',import.meta.url),'utf8'),start=source.indexOf("$('copy').onclick="),end=source.indexOf("$('map-export').onclick=",start);assert(start>=0&&end>start);let index=0;
 const camera={x:320,y:96},buttons=Object.fromEntries(['copy','paste','delete'].map(id=>[id,ui.document.createElement('button')])),reports=[],room=()=>h.doc.rooms[index];
 const host={camera,selected:new Set(),$:id=>buttons[id],room,layer:()=>'objects',items:()=>room().map.objects,run:fn=>{try{fn();}catch(e){reports.push(e.message);}},say:q=>reports.push(q),refresh:()=>{},transaction:fn=>h.change(()=>{const before=clone(h.doc);fn();for(const r of h.doc.rooms){const old=before.rooms.find(q=>q.roomId===r.roomId);pruneSmm2DeletedReferences(r,old);pruneLakituReferences(r,old);}}),clone,uid,linked,moveSelection,deleteSelection,captureSmm2LightingBindings,appendCopiedSmm2LightingBindings,captureSmm2ActorLeaves,appendCopiedSmm2ActorLeaves,captureSmm2GeometryBindings,appendSmm2GeometryBindings,captureSmm2BoneBindings,appendCopiedSmm2BoneBindings,captureMarioEmptyShellSources,appendCopiedMarioEmptyShellSources,enableCopiedSpikeTraps,captureHeavyStoneBindings,appendCopiedHeavyStoneBindings,captureRailHazardBindings,appendCopiedRailHazardBindings};
 const names=Object.keys(host).filter(q=>!['camera','selected'].includes(q)).join(','),api=new Function('host','const {'+names+'}=host;let selected=host.selected,clipboard=null;const camera=host.camera;'+source.slice(start,end)+';return {select(ids){selected=new Set(ids);},selected(){return selected;}};')(host);
 return {...api,buttons,reports,camera,setRoom:i=>{index=i;}};
}

test('actual native hazard clipboard remaps profile IDs and one shared quadratic track across rooms with exact positional translation',()=>{
 const ui=installSimulatedPlayDom();try{
  const h=new History(fixture({bound:true,secondRoom:true})),native=actualClipboard(h,ui),source=clone(h.doc.rooms[0]);native.select(['grinder-a','grinder-b']);native.buttons.copy.click();native.setRoom(1);native.buttons.paste.click();
  const target=h.doc.rooms[1],ids=[...native.selected()],profiles=target.smm2Mechanics.railHazards.hazards,track=target.contraptions.tracks[0],dx=336-136,dy=112-136;assert.equal(ids.length,2);assert.equal(profiles.length,2);assert.equal(target.contraptions.tracks.length,1);assert.equal(profiles[0].trackId,profiles[1].trackId);assert.notEqual(track.id,'guide');assert(profiles.every(q=>ids.includes(q.id)));assert.deepEqual(track.start,source.contraptions.tracks[0].start.map((n,i)=>n+(i?dy:dx)));assert.deepEqual(track.segments[0].control,source.contraptions.tracks[0].segments[0].control.map((n,i)=>n+(i?dy:dx)));assert.deepEqual(track.segments[0].to,source.contraptions.tracks[0].segments[0].to.map((n,i)=>n+(i?dy:dx)));assert.deepEqual(track.segments[1].to,track.start);assert.equal(track.mode,'loop');assert.deepEqual(profiles[1],{...source.smm2Mechanics.railHazards.hazards[1],id:profiles[1].id,trackId:track.id});assert.equal(target.smm2Mechanics.lakituClouds,undefined);assert.equal(target.smm2Mechanics.goalCloudRequirements,undefined);assert.deepEqual(h.doc.rooms[0],source);roundtrip(h);
  const before=createRailHazards(source).poseFor('grinder-a'),after=createRailHazards(target).poseFor(profiles[0].id);assert.equal(after.x,before.x+dx);assert.equal(after.y,before.y+dy);assert.equal(after.collisionRadius,22);
  const copied=clone(h.doc);native.buttons.delete.click();assert.equal(h.doc.rooms[1].smm2Mechanics.railHazards,undefined);assert.equal(h.doc.rooms[1].contraptions.tracks.length,1,'native deletion retains shared guide tracks');h.undo();assert.deepEqual(h.doc,copied);h.redo();roundtrip(h);
 }finally{ui.restore();}
});

test('whole native paste transaction rolls back when a translated curve or visual guide range leaves the map',()=>{
 const ui=installSimulatedPlayDom();try{
  const h=new History(fixture({bound:true})),native=actualClipboard(h,ui),saved=JSON.stringify(h.doc),undos=h.undoStack.length;native.select(['grinder-a','grinder-b']);native.buttons.copy.click();native.camera.x=320;native.camera.y=320;native.buttons.paste.click();assert.equal(JSON.stringify(h.doc),saved);assert.equal(h.undoStack.length,undos);assert.match(native.reports.at(-1),/outside room|leave the room/);assert.deepEqual([...native.selected()],['grinder-a','grinder-b']);
  const snapshot=captureRailHazardBindings(h.doc.rooms[0],new Set(['grinder-a'])),r=()=>h.doc.rooms[0];assert.equal(snapshot.tracks.length,1);snapshot.tracks[0].segments[0].control[0]=Infinity;assert.throws(()=>h.change(()=>{r().map.objects.push({...r().map.objects[1],id:'copy-hazard',x:336,y:112});appendCopiedRailHazardBindings(r(),snapshot,new Map([['grinder-a','copy-hazard']]),{dx:200,dy:-24});}));assert.equal(JSON.stringify(h.doc),saved);assert.equal(h.undoStack.length,undos);
 }finally{ui.restore();}
});

test('real native editor mounts Cloud tools and persists complete add/clone/native-paste/delete/undo flows through qmap save and export',async()=>{
 const ui=installSimulatedPlayDom(),globals=new Map(),install=(key,value)=>{globals.set(key,Object.getOwnPropertyDescriptor(globalThis,key));Object.defineProperty(globalThis,key,{value,writable:true,configurable:true});};
 try{
  const storage=new Map([['xiaoq-map-workshop-tools-v1',JSON.stringify(fixture({bound:true}))]]),exports=[];install('localStorage',{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v)});install('devicePixelRatio',1);install('ResizeObserver',class{observe(){}});install('setTimeout',()=>1);install('clearTimeout',()=>{});
  const nativeURL=globalThis.URL;install('URL',class extends nativeURL{static createObjectURL(blob){exports.push(blob);return 'blob:verified-export';}static revokeObjectURL(){}});
  ui.Element.prototype.closest=function(s){for(let n=this;n;n=n.parentNode)if(s.split(',').some(q=>q===n.tag||q==='.'+n.className||q==='#'+n.id))return n;return null;};ui.Element.prototype.removeAttribute=function(key){delete this.attributes[key];};ui.Element.prototype.after=function(node){const p=this.parentNode;node.parentNode=p;p.children.splice(p.children.indexOf(this)+1,0,node);};
  const html=fs.readFileSync(new URL('../atlas/editor.html',import.meta.url),'utf8');ui.document.body.innerHTML=html.match(/<body[^>]*>([\s\S]*?)<\/body>/)[1];for(const n of ui.document.body.querySelectorAll('input')){n.value=n.getAttribute('value')||'';n.checked=n.getAttribute('checked')!==undefined;}for(const n of ui.document.body.querySelectorAll('select')){const rows=n.querySelectorAll('option'),choice=rows.find(q=>q.getAttribute('selected')!==undefined)||rows[0];n.value=choice?.getAttribute('value')||'';}
  const get=id=>ui.document.getElementById(id),canvas=get('canvas');get('viewport').clientWidth=640;get('viewport').clientHeight=384;canvas.getBoundingClientRect=()=>({left:0,top:0});get('zoom').value='1';await import('../atlas/editor.mjs?lakitu-rail-native-authoring-entry');
  const control=key=>ui.document.querySelector('[data-lakitu-tool="'+key+'"]'),saved=()=>{get('save').click();return JSON.parse(storage.get('xiaoq-map-workshop-tools-v1'));},point=(type,x,y)=>canvas.dispatchEvent({type,button:0,pointerId:1,clientX:x,clientY:y});assert(control('cloud-apply'));assert.equal(control('cloud').value,'cloud-a');assert.equal(control('cloud-maxSpeed').value,'2');assert.equal(get('pack-export').disabled,true);
  control('cloud-maxSpeed').value='1.5';control('cloud-apply').click();control('clone-id').value='cloud-native-copy';control('clone-x').value='336';control('clone-y').value='80';control('cloud-clone').click();let d=saved();assert.equal(d.rooms[0].smm2Mechanics.lakituClouds.clouds.length,2);assert.equal(d.rooms[0].smm2Mechanics.lakituClouds.clouds[1].maxSpeed,1.5);assert.equal(d.rooms[0].map.objects.length,6);assert.equal(d.rooms[0].smm2Mechanics.goalCloudRequirements[0].cloudId,'cloud-a');
  get('layer').value='objects';get('layer').dispatchEvent({type:'change'});get('tools').children.find(q=>q.textContent==='框选 V').click();point('pointerdown',140,140);point('pointerup',140,140);get('copy').click();get('paste').click();d=saved();const copy=d.rooms[0].smm2Mechanics.railHazards.hazards.find(q=>!['grinder-a','grinder-b'].includes(q.id));assert(copy);assert(d.rooms[0].map.objects.some(q=>q.id===copy.id));assert.equal(d.rooms[0].contraptions.tracks.length,2);const guide=d.rooms[0].contraptions.tracks.find(q=>q.id===copy.trackId);assert.deepEqual(guide.start,[40,40]);assert.deepEqual(guide.segments[0].control,[92,96]);
  get('delete').click();d=saved();assert.equal(d.rooms[0].smm2Mechanics.railHazards.hazards.length,2);assert.equal(d.rooms[0].contraptions.tracks.length,2);get('undo').click();d=saved();assert.equal(d.rooms[0].smm2Mechanics.railHazards.hazards.length,3);get('redo').click();d=saved();assert.equal(d.rooms[0].smm2Mechanics.railHazards.hazards.length,2);
  control('cloud').value='cloud-a';control('cloud').dispatchEvent({type:'change'});control('cloud-remove').click();d=saved();assert.equal(d.rooms[0].smm2Mechanics.goalCloudRequirements,undefined);get('undo').click();d=saved();assert.equal(d.rooms[0].smm2Mechanics.goalCloudRequirements[0].cloudId,'cloud-a');get('export').click();assert.equal(exports.length,1);assert.deepEqual(parseProject(await exports[0].text()),d);
 }finally{for(const [key,descriptor]of globals){if(descriptor)Object.defineProperty(globalThis,key,descriptor);else delete globalThis[key];}ui.restore();}
});

test('Cloud author placement follows actual slope polygons, including empty space inside their bounding rectangle',()=>{
 const r=fixture().rooms[0];r.smm2Mechanics={version:1,slopes:[{id:'slope',x:80,y:64,w:80,h:80,orientation:'rise-right',collision:'solid'}]};
 assert.doesNotThrow(()=>setLakituCloud(r,'air-over-slope',cloud({x:80,y:72})));assert.throws(()=>setLakituCloud(r,'inside-slope',cloud({x:136,y:96})),/permanent slope/);assert.equal(r.smm2Mechanics.lakituClouds.clouds.length,1);
});
