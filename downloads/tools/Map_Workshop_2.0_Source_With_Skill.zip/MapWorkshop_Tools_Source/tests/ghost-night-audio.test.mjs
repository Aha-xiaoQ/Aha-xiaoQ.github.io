import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {audioFiles,themeFor,createSound} from '../atlas/editor-audio.mjs';
import {installSimulatedAudio} from './fixtures/simulated-audio.mjs';
import {createNeutralProject,readCharacterProfile} from '../scripts/neutral-fixtures.mjs';
import {projectPack} from '../atlas/editor-runtime.mjs';
import {offlineFile} from '../atlas/editor-offline.mjs';
test('only Ghost House Night selects the specific verified theme family, including the documented missing hurry variant',()=>{
 assert.equal(themeFor('Ghost House Night',false,300),'ghost_house_night');assert.equal(themeFor('GhostHouse Night',false,90),'ghost_house_night');assert.equal(themeFor('Ghost House Night',true,300),'star');assert.equal(themeFor('Castle Night',false,300),'castle');assert.equal(themeFor('Underworld',false,300),'underworld');
});
test('the packaged PCM loop has one complete inferred period and a quiet seam without a tail fade',async()=>{
 const b=await fs.readFile(new URL('../atlas/assets/classic-audio/'+audioFiles.ghost_house_night,import.meta.url));assert.equal(b.toString('ascii',0,4),'RIFF');assert.equal(b.toString('ascii',8,12),'WAVE');assert.equal(b.readUInt16LE(22),2);assert.equal(b.readUInt32LE(24),44100);assert.equal(b.readUInt16LE(34),16);assert.equal((b.length-44)/4,940800);let sum=0,peak=0;for(let i=44;i<b.length;i+=2){const a=b.readInt16LE(i)/32768;sum+=a*a;peak=Math.max(peak,Math.abs(a));}assert(Math.sqrt(sum/((b.length-44)/2))>.001);assert(peak<1);for(let ch=0;ch<2;ch++)assert(Math.abs(b.readInt16LE(44+ch*2)-b.readInt16LE(b.length-4+ch*2))<33,'boundary step below -60dBFS');
});
test('normal game audio uses one gesture-authorized looping element across pause and resume',async()=>{
 const a=installSimulatedAudio({requireGesture:true});try{const sound=createSound({ghost_house_night:'data:audio/wav;base64,AQ=='});await a.gesture(()=>sound.resumeMusic('ghost_house_night',true));const music=a.music()[0];assert(music.loop);assert.equal(music.volume,.35);assert(sound.snapshot().playing);sound.pauseMusic();assert(!sound.snapshot().playing);await sound.resumeMusic();assert(sound.snapshot().playing);assert.equal(a.music().length,1);sound.stopMusic();assert.equal(sound.snapshot().track,'');}finally{a.restore();}
});
test('night offline export embeds the local loop and ordinary course export does not add its sample',async()=>{
 const d=createNeutralProject(),character=await readCharacterProfile(),read=p=>fs.readFile(new URL('../atlas/'+p,import.meta.url),'utf8');d.rooms[0].setting='Ghost House Night';let requests=[];const readAudio=name=>{requests.push(name);return fs.readFile(new URL('../atlas/assets/classic-audio/'+name,import.meta.url));};let pack=projectPack(d,'main',character,'neutral-ghost-audio');const html=await offlineFile(pack,d.rooms,read,readAudio);assert(requests.includes('ghost-house-night-loop.wav'));assert(html.includes('data:audio/wav;base64'));assert(!html.includes('mariowiki.com/images/c/c0'));d.rooms[0].setting='Overworld';requests=[];pack=projectPack(d,'main',character,'neutral-day-audio');await offlineFile(pack,d.rooms,read,readAudio);assert(!requests.includes('ghost-house-night-loop.wav'));
});
