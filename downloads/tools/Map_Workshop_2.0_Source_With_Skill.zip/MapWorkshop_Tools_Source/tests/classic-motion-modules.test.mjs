import fs from 'node:fs';import {test} from 'node:test';import assert from 'node:assert/strict';
import {blank,parseProject} from '../atlas/editor-model.mjs';import {projectPack} from '../atlas/editor-runtime.mjs';import {createStageCatalog} from '../atlas/runtime/stage-catalog.mjs';
import {createPlatformMotor} from '../atlas/editor-mario-motor.mjs';import {createPlatformStage} from '../atlas/editor-mario-stage.mjs';import {createMarioModules} from '../atlas/editor-mario-modules.mjs';import {drawCheckpoint} from '../atlas/editor-study-module-art.mjs';
const character=JSON.parse(fs.readFileSync(new URL('../atlas/runtime/character.json',import.meta.url)));
function fixture(){const doc=blank('Classic contact fixture',384,240),r=doc.rooms[0];r.map.geometry=[{id:'floor',x:0,y:224,w:384,h:16,collision:'solid',material:'ground'},{id:'lift',x:80,y:144,w:112,h:8,collision:'oneway',material:'platform'}];r.map.objects=[{id:'start',kind:'spawn',x:112,y:130,w:10,h:14}];r.marioModules={version:1,itemSources:[],noteBlocks:[],oneWayWalls:[],enemyVariants:{}};return doc;}
function native(doc){const events=[],pack=projectPack(doc,doc.rooms[0].roomId,character,'classic-fixture'),plan=createStageCatalog(pack).plan(pack.stages[0].id,pack.characters[0].id,{allowDraft:true});let frame=0;const stage=createPlatformStage({plan,motor:createPlatformMotor(),visualRooms:doc.rooms,emit:(type,data)=>events.push({frame,type,...data}),manualDeath:false,autoContinue:false,allowWarp:false});return {stage,events,step(raw={}){stage.step(raw);frame++;return stage.view();},until(fn,raw={},limit=1000){for(let n=0;n<limit;n++){const v=this.step(raw);if(fn(v))return v;}throw Error('Fixture input timed out');}};}
const dropRule=()=>({speed:.25,acceleration:.01,maxSpeed:1,continueAfterLeave:false});
const flightRule=()=>({kind:'vertical-koopa',minY:128,maxY:176,speed:.5,direction:1});
test('contact platform carries the real rider, pauses in a jump, then continues on the next actual landing',()=>{
 const doc=fixture();doc.rooms[0].marioModules.contactPlatforms={lift:dropRule()};const s=native(doc),y=()=>s.stage.view().geometry.find(g=>g.id==='lift').y;
 s.until(v=>v.p.support==='lift');const original=y();for(let i=0;i<12;i++)s.step();assert(y()>original);assert.equal(s.stage.view().p.y+s.stage.view().p.h,y());
 s.step({jump:true});const leaving=y();assert.equal(s.stage.view().p.grounded,false);for(let i=0;i<18;i++)s.step({jump:true});assert.equal(y(),leaving,'no off-rider automatic drop');
 s.until(v=>v.p.support==='lift');const landed=y();s.step();assert(y()>landed);assert.equal(s.stage.view().lives,3);assert(s.events.some(e=>e.event==='contact-platform-paused'));
});
test('an unused contact platform does not move; authored continuation and repeated calls have distinct semantics',()=>{
 for(const continued of [false,true]){const r=fixture().rooms[0];r.marioModules.contactPlatforms={lift:{...dropRule(),continueAfterLeave:continued}};const m=createMarioModules(r),geometry=structuredClone(r.map.geometry),lift=geometry.find(g=>g.id==='lift');
  for(let tick=1;tick<=20;tick++)m.updatePlatforms(geometry,{grounded:true,support:'floor'},{tick});assert.equal(lift.y,144);
  m.updatePlatforms(geometry,{grounded:true,support:'lift'},{tick:21});const on=lift.y;m.updatePlatforms(geometry,{grounded:true,support:'lift'},{tick:21});assert.equal(lift.y,on,'idempotent within one native frame');
  m.updatePlatforms(geometry,{grounded:false,support:null},{tick:22});assert.equal(lift.y>on,continued);m.reset();const fresh=structuredClone(r.map.geometry);m.updatePlatforms(fresh,{grounded:false},{tick:22});assert.equal(fresh[1].y,144);
 }
});
test('vertical red Paratroopa uses a bounded live path; a real first stomp removes wings and a later stomp makes a shell',()=>{
 const doc=fixture(),r=doc.rooms[0];r.map.geometry=r.map.geometry.filter(q=>q.id==='floor');r.map.objects=[{id:'start',kind:'spawn',x:160,y:32,w:10,h:14},{id:'para',kind:'walker',x:160,y:144,w:16,h:24}];r.marioModules.enemyVariants.para=flightRule();const s=native(doc);
 s.until(v=>!v.enemies[0].verticalFlight);let e=s.stage.view().enemies[0];assert.equal(e.shell,undefined);assert.equal(e.source.jumping,false);assert.equal(e.source.floating,false);assert(s.events.some(e=>e.event==='koopa-wings-lost'));
 for(let i=0;i<180&&!s.stage.view().enemies[0]?.shell;i++){const v=s.stage.view(),a=v.enemies[0];if(!a)break;const delta=a.x+3-v.p.x;s.step({x:Math.abs(delta)>2?Math.sign(delta):0});}
 e=s.stage.view().enemies[0];assert(e?.shell,'second normal descending contact makes an ordinary shell');assert.equal(e.h,16);assert.equal(s.stage.view().lives,3);assert.equal(s.events.filter(e=>e.event==='koopa-wings-lost').length,1);
});
test('vertical Koopa range reverses without horizontal wandering or gravity and resets after a real timeout death',()=>{
 const doc=fixture(),r=doc.rooms[0];r.map.objects[0]={id:'start',kind:'spawn',x:16,y:210,w:10,h:14};r.map.objects.push({id:'para',kind:'walker',x:160,y:144,w:16,h:24});r.marioModules.enemyVariants.para=flightRule();r.playRules={version:1,timeLimit:30,timerFrames:24,viewportWidth:256,viewportHeight:240,cameraAnchor:100};const s=native(doc);let up=false,down=false;
 for(let i=0;i<250;i++){const e=s.step().enemies[0];assert.equal(e.x,160);assert(e.y>=128&&e.y<=176);up||=e.vy<0;down||=e.vy>0;}assert(up&&down);
 s.until(v=>v.p.dying);assert.equal(s.stage.view().lives,2);s.until(v=>!v.p.dying);const e=s.stage.view().enemies[0];assert.equal(e.y,144);assert.equal(e.verticalFlight,true);assert.equal(s.stage.view().p.power,0);
});
test('hidden camera midpoint does not activate on its drawn author plane; true camera crossing and timeout respawn are silent',()=>{
 const doc=fixture(),r=doc.rooms[0];r.map.width=640;r.map.geometry=[{id:'floor',x:0,y:224,w:640,h:16,collision:'solid',material:'ground'}];r.map.objects=[{id:'start',kind:'spawn',x:16,y:210,w:10,h:14},{id:'mid-spawn',kind:'spawn',x:240,y:210,w:10,h:14},{id:'midpoint',kind:'checkpoint',x:64,y:0,w:16,h:240,targetSpawn:'mid-spawn'}];r.checkpointVisuals={midpoint:{version:1,hidden:true}};r.checkpointRules={midpoint:{version:1,trigger:'camera-x',x:128}};r.playRules={version:1,timeLimit:30,timerFrames:24,viewportWidth:256,viewportHeight:240,cameraAnchor:100};parseProject(JSON.stringify(doc));const s=native(doc);
 s.until(v=>v.p.x>90,{x:1});assert.equal(s.stage.view().checkpoint.spawnId,'start');s.until(v=>v.checkpoint.spawnId==='mid-spawn',{x:1});assert(s.stage.view().cam>=128);assert.equal(s.events.filter(e=>e.type==='checkpoint').length,1);assert.equal(s.events.filter(e=>e.type==='sound'&&e.event==='checkpoint').length,0);
 s.until(v=>v.p.dying);s.until(v=>!v.p.dying);assert.equal(s.stage.view().p.x,240);assert.equal(s.stage.view().p.power,0);assert.equal(s.stage.view().lives,2);s.step();assert.equal(s.events.filter(e=>e.type==='checkpoint').length,1);
 const calls=[];assert.equal(drawCheckpoint(new Proxy({}, {get:(_,k)=>()=>calls.push(k)}),r.map.objects[2],0,{...r,playGeometry:[]}),true);assert.equal(calls.length,0,'hidden midpoint draws no gameplay flag or line');
});
test('bad motion targets and paths reject instead of silently overriding native geometry',()=>{
 const doc=fixture(),r=doc.rooms[0];for(const changes of [r=>r.marioModules.contactPlatforms={missing:dropRule()},r=>{r.map.geometry[1].motion={axis:'x',min:80,max:160,speed:.5};r.marioModules.contactPlatforms={lift:dropRule()};},r=>r.marioModules.contactPlatforms={lift:{...dropRule(),continueAfterLeave:1}},r=>{r.map.objects.push({id:'para',kind:'walker',x:160,y:144,w:16,h:24});r.marioModules.enemyVariants.para={...flightRule(),minY:155};},r=>{r.checkpointRules={missing:{version:1,trigger:'camera-x',x:64}};}]){const d=structuredClone(doc);changes(d.rooms[0]);assert.throws(()=>parseProject(JSON.stringify(d)));}
});

test('smooth native platform follows authored phase, sleeps beyond the viewport, and carries a real rider through reversal',async()=>{
 const {setClassicMotionPlatform}=await import('../atlas/editor-classic-motion-tools.mjs');const doc=fixture(),r=doc.rooms[0];setClassicMotionPlatform(r,'lift',{axis:'x',min:80,max:160,speed:.75},{profile:'smooth',direction:1,activationDistance:0,periodFrames:240,phaseDegrees:0});r.map.objects[0].x=152;
 const controller=createMarioModules(r),q=structuredClone(r.map.geometry.find(q=>q.id==='lift'));controller.stepPlatform(q,{cam:-400,viewportWidth:256,tick:1});assert.equal(q.x,120);controller.stepPlatform(q,{cam:0,viewportWidth:256,tick:2});const moved=q.x;controller.stepPlatform(q,{cam:0,viewportWidth:256,tick:2});assert.equal(q.x,moved);assert(moved>120);
 const s=native(parseProject(JSON.stringify(doc)));s.until(v=>v.p.support==='lift');let right=false,left=false;
 for(let n=0;n<240;n++){const v=s.step(),g=v.geometry.find(q=>q.id==='lift');assert.equal(v.p.support,'lift');assert.equal(v.p.y+v.p.h,g.y);assert(g.x>=80&&g.x<=160);right||=g.dx>0;left||=g.dx<0;assert.equal(v.lives,3);}
 assert(right&&left);assert(s.stage.view().p.x>120);
});

test('authored scale stops empty immediately, continues on a real landing, and both decks freely fall when the rope is exhausted',async()=>{
 const {upsertStudyScale}=await import('../atlas/editor-study-tools.mjs'),{setClassicScaleRule}=await import('../atlas/editor-classic-motion-tools.mjs');const doc=fixture(),r=doc.rooms[0];r.map.geometry=r.map.geometry.filter(g=>g.id==='floor');const id=upsertStudyScale(r,null,{leftX:80,leftY:112,rightX:240,rightY:144,width:64,anchorY:36});setClassicScaleRule(r,id,{acceleration:.04,maxSpeed:1.5,emptyStops:true,fallAcceleration:.125,fallMaxSpeed:4.25});Object.assign(r.map.objects[0],{x:102,y:98});const s=native(doc),pair=()=>s.stage.view().geometry.filter(q=>q.id.startsWith(id+'-'));
 s.until(v=>v.p.support===id+'-left');for(let n=0;n<16;n++)s.step();const before=pair().map(q=>q.y);s.step({jump:true});const off=pair().map(q=>q.y);for(let n=0;n<18;n++)s.step({jump:true});assert.deepEqual(pair().map(q=>q.y),off);assert.equal(pair()[0].scaleSpeed,0);assert.equal(off[0]+off[1],before[0]+before[1]);
 s.until(v=>v.p.support===id+'-left');s.until(v=>v.geometry.find(q=>q.id===id+'-left').scaleBroken,{max:240});const broken=pair().map(q=>q.y);assert(pair().every(q=>q.scaleBroken));s.step({jump:true});for(let n=0;n<6;n++)s.step({jump:true});assert(pair().every((q,i)=>q.y>broken[i]));assert(pair().every(q=>q.dy>0));assert.equal(s.stage.view().lives,3);
});
