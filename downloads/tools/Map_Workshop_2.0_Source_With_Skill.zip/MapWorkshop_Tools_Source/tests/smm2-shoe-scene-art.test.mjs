import {drawSmm2ShoeRider,drawSmm2ShoeFrontRim} from '../atlas/editor-smm2-shoe-art.mjs';
import {classicSprite} from '../atlas/classic-art.mjs';
import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {sourcePixels,sourceKey} from '../atlas/source-art.mjs';
import {background,drawTile,drawObject,drawPlayer,drawScenery} from '../atlas/editor-art.mjs';
import {drawSmm2Background,drawSmm2Tile,drawSmm2Actor,drawSmm2World,drawSmm2Muncher,drawSmm2ShoeSpike,drawSmm2SnowScenery,smm2PipeDirection,drawSmm2Pipe,drawSmm2PlayerFootwear} from '../atlas/editor-smm2-art.mjs';
import {drawSmm2Shoe,drawSmm2ShoeBlast} from '../atlas/editor-smm2-shoe-art.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';
const require=createRequire(import.meta.url);
let createCanvas;try{({createCanvas}=require('@napi-rs/canvas'));}catch{}
const rasterTest=(name,fn)=>test(name,{skip:!createCanvas},fn);
const canvas=(w=384,h=216)=>createCanvas(w,h);
const bytes=c=>c.getContext('2d').getImageData(0,0,c.width,c.height).data;
const pixel=(c,x,y)=>[...c.getContext('2d').getImageData(x,y,1,1).data];
const room=palette=>({roomId:'test',setting:palette==='smb1-snow'?'Overworld':'Underworld',map:{width:384,height:216,geometry:[],objects:[]},markers:[],decorations:[],nativeSceneryMode:'authored',smm2Mechanics:{version:1,art:{palette}}});
function withNative(fn){const ui=installSimulatedPlayDom(),create=ui.document.createElement;ui.document.createElement=tag=>tag==='canvas'?createCanvas(1,1):create(tag);try{return fn();}finally{ui.restore();}}
function count(c){let n=0;for(let i=3,d=bytes(c);i<d.length;i+=4)n+=d[i]>0;return n;}

rasterTest('Snow and underground are opt-in, preserve fixed 384 by 216 viewport and distinct native hard blocks',()=>withNative(()=>{
 for(const palette of ['smb1-snow','smb1-shoe-underworld']){
  const r=room(palette),c=canvas(),before=JSON.stringify(r);background(c.getContext('2d'),r,384,216);assert.equal(count(c),384*216);
  assert.deepEqual(pixel(c,383,215),palette==='smb1-snow'?[120,131,248,255]:[0,0,0,255]);
  const ground={id:'ground',x:16,y:184,w:64,h:32,material:'ground'},tile=canvas();assert.equal(drawSmm2Tile(tile.getContext('2d'),ground,r),true);assert.equal(count(tile),64*32);
  const hard={id:'roof',x:16,y:120,w:16,h:16,material:'stone',smm2BlockKind:'hard-block'},actual=canvas(),native=canvas();assert.equal(drawSmm2Tile(actual.getContext('2d'),hard,r),false);drawTile(actual.getContext('2d'),hard,r);drawTile(native.getContext('2d'),hard,{...r,smm2Mechanics:undefined});assert.deepEqual(bytes(actual),bytes(native));assert.equal(JSON.stringify(r),before);
 }
 const legacy=canvas();assert.equal(drawSmm2Background(legacy.getContext('2d'),{},384,216),false);assert.equal(count(legacy),0);
}));

rasterTest('native reward, coin and ordinary Mario retain original pixels in both new palettes',()=>withNative(()=>{
 for(const palette of ['smb1-snow','smb1-shoe-underworld']){
  const r=room(palette),base={...r,smm2Mechanics:undefined};
  for(const material of ['brick','block','used','pipe','pipe-side']){
   const q={id:'native',x:80,y:96,w:32,h:32,material},actual=canvas(),expected=canvas();drawTile(actual.getContext('2d'),q,r);drawTile(expected.getContext('2d'),q,base);assert.deepEqual(bytes(actual),bytes(expected),material);
  }
  for(const kind of ['coin','walker']){const q={id:'native',kind,x:80,y:96,w:16,h:16},actual=canvas(),expected=canvas();drawObject(actual.getContext('2d'),q,0,r);drawObject(expected.getContext('2d'),q,0,base);assert.deepEqual(bytes(actual),bytes(expected),kind);}
  const p={x:80,y:120,w:10,h:14,grounded:true,facing:1,power:0},actual=canvas(),expected=canvas();drawPlayer(actual.getContext('2d'),p,0,undefined,r);drawPlayer(expected.getContext('2d'),p,0,undefined,base);assert.deepEqual(bytes(actual),bytes(expected));
 }
}));

rasterTest('four pipe mouths follow explicit source and traversal rules using unchanged native pixels',()=>{
 const r=room('smb1-shoe-underworld'),q={id:'pipe',x:32,y:48,w:48,h:32,material:'pipe-side'};r.marioModules={itemSources:[],enemySources:[],arrivalDirections:{},portalDirections:{}};
 for(const direction of ['up','down','left','right']){
  r.marioModules.arrivalDirections={arrival:{pipeId:'pipe',direction}};assert.equal(smm2PipeDirection(q,r),direction);const c=canvas();assert.equal(drawSmm2Pipe(c.getContext('2d'),q,r),true);assert(count(c)>0);
  if(direction==='left'||direction==='right'){
   const key=sourceKey('Solid','PipeHorizontal',r.setting),native=sourcePixels(key);
   for(let y=0;y<32;y++)for(let x=0;x<16;x++)if(native.pixels[y*native.w+x][3])assert.deepEqual(pixel(c,direction==='left'?q.x+x:q.x+q.w-1-x,q.y+y),native.pixels[y*native.w+x]);
  }
 }
 r.marioModules.arrivalDirections={};r.marioModules.portalDirections={depart:{pipeId:'pipe',direction:'right'}};assert.equal(smm2PipeDirection(q,r),'left');
 r.marioModules.enemySources=[{pipeId:'pipe',direction:'right'}];assert.equal(smm2PipeDirection(q,r),null,'conflicting metadata does not invent an orientation');
 assert.equal(smm2PipeDirection(q,{}),null);
});

rasterTest('raw authored Shoes, controller feet and blasts draw once and hidden states do not fall through',()=>{
 const r=room('smb1-shoe-underworld'),q={id:'shoe',kind:'walker',x:32,y:96,w:16,h:16};r.smm2Mechanics.shoes=[{id:'shoe',kind:'shoe',size:'small',winged:true,occupant:'goomba'}];
 const raw=canvas(),live=canvas(),before=JSON.stringify({r,q});assert.equal(drawSmm2Actor(raw.getContext('2d'),q,0,r),true);drawSmm2Shoe(live.getContext('2d'),{...q,smm2Shoe:{...r.smm2Mechanics.shoes[0],occupancy:'npc'}},{tick:0});assert.deepEqual(bytes(raw),bytes(live));assert.equal(JSON.stringify({r,q}),before);
 const occupied={...q,type:'smm2-shoe',smm2Shoe:{kind:'shoe',occupancy:'player'}},hidden=canvas();assert.equal(drawSmm2Actor(hidden.getContext('2d'),occupied,0,r),true);assert.equal(count(hidden),0);
 const blast={id:'blast',x:96,y:80,w:24,h:16,remainingFrames:12},actual=canvas(),expected=canvas();drawSmm2World(actual.getContext('2d'),r,{smm2Mechanics:{version:1,shoes:{shoes:[],blasts:[blast]}}},0);drawSmm2ShoeBlast(expected.getContext('2d'),blast,{tick:0});assert.deepEqual(bytes(actual),bytes(expected));
});

rasterTest('mounted shoe uses the shared source-rider seating and foreground rim, without changing physical pose',()=>withNative(()=>{
 const r=room('smb1-shoe-underworld'),shoe={id:'shoe',x:80,y:128,w:16,h:16,kind:'stiletto',size:'small',winged:true,occupancy:'player'},p={x:83,y:118,w:10,h:14,power:0,grounded:true,facing:1,smm2Shoe:shoe},actual=canvas(),expected=canvas(),before=JSON.stringify(p);
 drawPlayer(actual.getContext('2d'),p,0,undefined,r);drawSmm2PlayerFootwear(expected.getContext('2d'),p,0,r);
 const ctx=expected.getContext('2d');drawSmm2ShoeRider(ctx,p,shoe,classicSprite('small_idle'),{large:false});drawSmm2ShoeFrontRim(ctx,p,shoe,0);assert.deepEqual(bytes(actual),bytes(expected));assert.equal(JSON.stringify(p),before);
 const blink=canvas();drawPlayer(blink.getContext('2d'),{...p,invulnerable:8},4,undefined,r);assert.equal(count(blink),0);
}));

rasterTest('Munchers remain distinct black plants; fire and floor plants use the same native Piranha body',()=>{
 const r=room('smb1-shoe-underworld'),q={id:'plant',kind:'walker',type:'muncher',x:48,y:128,w:16,h:16},c=canvas();assert.equal(drawSmm2Actor(c.getContext('2d'),q,0,r),true);const colors=new Set();for(let i=0,d=bytes(c);i<d.length;i+=4)if(d[i+3])colors.add([...d.slice(i,i+3)].join(','));assert(colors.has('16,23,25'));assert(!colors.has('0,168,0'));
 const normal={...q,type:'study-piranha',h:24,source:{studyFloorPlant:true}},fire={...normal,source:{...normal.source,fire:true}},actual=canvas(),expected=canvas();drawSmm2Actor(actual.getContext('2d'),normal,0,r);drawSmm2Actor(expected.getContext('2d'),fire,0,r);assert.deepEqual(bytes(actual),bytes(expected));
 const native=sourcePixels(sourceKey('Character','Piranha',r.setting));for(let y=0;y<native.h;y++)for(let x=0;x<native.w;x++)assert.deepEqual(pixel(actual,q.x+x,q.y+y),native.pixels[y*native.w+x]);
});

rasterTest('only actual typed spike traps use the observed cyan radial hazard shape',()=>{
 const r=room('smb1-shoe-underworld'),q={id:'spike',kind:'hazard',x:32,y:160,w:16,h:16};r.contraptions={version:1,spikeTraps:[{id:'spike'}]};const actual=canvas(),expected=canvas();assert.equal(drawSmm2Actor(actual.getContext('2d'),q,0,r),true);drawSmm2ShoeSpike(expected.getContext('2d'),q);assert.deepEqual(bytes(actual),bytes(expected));assert.equal(pixel(actual,32,160)[3],0);assert.equal(pixel(actual,39,160)[3],255);assert.equal(pixel(actual,39,167).slice(0,3).join(','),'36,94,99');assert.equal(drawSmm2Actor(canvas().getContext('2d'),{...q,id:'unknown'},0,r),false);assert.equal(drawSmm2Actor(canvas().getContext('2d'),q,0,{...r,smm2Mechanics:undefined}),false);
});

rasterTest('source supplies clip at their actual pipe mouth; Snow scenery and castle use measured footprints',()=>withNative(()=>{
 const r=room('smb1-shoe-underworld'),q={id:'emerging',kind:'walker',type:'smm2-shoe',x:48,y:80,w:16,h:16,moduleEmergence:true,smm2Shoe:{kind:'shoe',occupancy:'npc'},sourceClip:{pipeId:'pipe',direction:'down',mouth:88}},c=canvas();drawObject(c.getContext('2d'),q,0,r);assert.equal(pixel(c,54,83)[3],0);assert.equal(pixel(c,54,91)[3],255);
 const snow=room('smb1-snow'),hill={id:'hill',x:80,y:149,w:80,h:35,material:'decoration',smm2Art:'snow-scenery-hill'},cloud={id:'cloud',x:32,y:24,w:32,h:24,material:'decoration',nativeScenery:{type:'Cloud1',palette:'native'}};snow.decorations=[hill,cloud];snow.markers=[{id:'goal',kind:'flagpole-finish',x:240,y:184,source:{castleDistance:32}}];const actual=canvas(),scenery=canvas();drawScenery(actual.getContext('2d'),snow);drawSmm2SnowScenery(scenery.getContext('2d'),hill,snow);drawSmm2SnowScenery(scenery.getContext('2d'),cloud,snow);assert(count(actual)>count(scenery));assert.equal(pixel(actual,321,104)[3],255,'80-pixel castle top uses its native composed height');assert.equal(pixel(actual,304,103)[3],0,'castle does not gain an invented second story');assert.equal(pixel(actual,383,184)[3],0,'castle stops at its real floor');const before=bytes(actual).slice();for(const q of snow.decorations)drawTile(actual.getContext('2d'),q,snow);assert.deepEqual(bytes(actual),before,'background decorations never fall through to generic green bushes');
}));
