import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {blank,parseProject} from '../atlas/editor-model.mjs';
import {createStageCatalog} from '../atlas/runtime/stage-catalog.mjs';
import {createProgress,markLevelComplete,reconcileProgress} from '../atlas/editor-collection-progress.mjs';
import {createCollection,addLevel,updateLevel,removeLevel,reorderLevels,approveLevel,unapproveLevel,validateCollection,parseCollection,serializeCollection,buildCollection,COLLECTION_LIMITS} from '../atlas/editor-collection.mjs';
const profile=JSON.parse(fs.readFileSync(new URL('../atlas/runtime/character.json',import.meta.url)));
const clone=x=>structuredClone(x);
function project(title='First'){
 const doc=blank(title,384,240),room=doc.rooms[0];
 room.map.geometry=[{id:'floor',x:0,y:224,w:384,h:16,collision:'solid',material:'ground'}];
 room.map.objects=[{id:'start',kind:'spawn',x:32,y:210,w:10,h:14},{id:'finish',kind:'exit',x:352,y:200,w:16,h:24}];
 return doc;
}
function multiroom(){
 const doc=project(),annex=project('Annex').rooms[0];annex.roomId='annex';
 doc.rooms.push(annex);
 for(const [room,target]of [[doc.rooms[0],'annex'],[annex,'main']])room.map.objects.push({id:'portal',kind:'portal',x:96,y:200,w:16,h:24,targetRoom:target,targetSpawn:'start'});
 annex.switchStudy={version:1,initialOn:true,allowBacktracking:true,devices:[{id:'switch',kind:'switch',x:64,y:176,w:16,h:16},{id:'red',kind:'block',color:'red',x:160,y:160,w:32,h:16}]};
 annex.switchStudy.clouds=[{x:16,y:32,type:'Cloud2'}];
 doc.rooms[0].markers.push({id:'warp-marker',kind:'world-transport',x:288,y:224,source:{transport:{map:'4-1'},note:'retain original metadata'}});
 doc.annotation={text:'editable provenance',version:17};annex.annotation={text:'room metadata'};
 return doc;
}
function collection(){let doc=createCollection({id:'test-collection',title:'Private collection'});doc=addLevel(doc,project(),{id:'first'});return addLevel(doc,project('Second'),{id:'second'});}

test('collection round trip preserves full editable projects and safe unknown metadata',()=>{
 const source=multiroom(),doc=addLevel(createCollection({id:'test',title:'Private'}),source,{id:'first',notes:{author:'local'}});
 doc.notes={purpose:'private study',version:23};
 const imported=parseCollection(serializeCollection(doc));
 assert.deepEqual(imported,doc);assert.deepEqual(imported.levels[0].project,source);
 assert.deepEqual(imported.levels[0].project.rooms[1].switchStudy,source.rooms[1].switchStudy);
 assert.throws(()=>parseProject(serializeCollection(doc)),/版本 1/,'public native parser rejects a collection instead of flattening it');
});
test('editing helpers use stable IDs and only bump changed level revisions',()=>{
 const original=collection(),reordered=reorderLevels(original,['second','first']);
 assert.equal(reordered.revision,original.revision+1);assert.deepEqual(reordered.levels.map(level=>level.revision),[1,1]);
 assert.deepEqual(updateLevel(original,'first',clone(original.levels[0].project)),original);
 const edited=clone(original.levels[0].project);edited.title='New title';
 const updated=updateLevel(reordered,'first',edited);
 assert.equal(updated.levels[0].id,'first');assert.equal(updated.levels[0].revision,2);assert.equal(updated.levels[1].revision,1);
 assert.equal(original.levels[0].project.title,'First');
 assert.deepEqual(removeLevel(updated,'first').order,['second']);
 assert.throws(()=>updateLevel(original,'first',edited,{revision:1}),/cannot replace/);
 assert.throws(()=>removeLevel(original,'missing'),/does not exist/);
});
test('build uses explicit order, independent namespaces and native multiroom topology',()=>{
 const source=multiroom();let doc=addLevel(createCollection({id:'native-collection',title:'Authored'}),source,{id:'level-a'});
 doc=addLevel(doc,project('Other'),{id:'level-b'});doc=reorderLevels(doc,['level-b','level-a']);
 const before=serializeCollection(doc),originalFetch=globalThis.fetch;
 globalThis.fetch=()=>{throw Error('template fetching is forbidden');};
 let built;try{built=buildCollection(doc,profile,{includePending:true});}finally{globalThis.fetch=originalFetch;}
 assert.equal(built.format,'xiaoq-map-collection-runtime');assert.deepEqual(built.levels.map(level=>level.id),doc.order);
 const multi=built.levels[1];assert.equal(multi.pack.maps.length,2);assert.equal(multi.rooms.length,2);assert.deepEqual(multi.project,source);
 assert.ok(multi.requiredCapabilities.includes('switch-study-v1'));assert.ok(multi.requiredCapabilities.includes('portals-v1'));
 const plan=createStageCatalog(multi.pack).plan(multi.pack.stages[0].id,multi.pack.characters[0].id,{allowDraft:true});
 assert.equal(plan.rooms.main.objects.find(o=>o.kind==='portal').targetRoom,'annex');
 assert.deepEqual(multi.rooms[1].switchStudy,source.rooms[1].switchStudy);
 assert.equal(multi.rooms[0].markers[0].source.transport,undefined);
 assert.equal(multi.project.rooms[0].markers[0].source.transport.map,'4-1');
 const ids=built.levels.flatMap(level=>[...level.pack.maps,...level.pack.stages,...level.pack.characters,...level.pack.audio].map(item=>item.id));
 assert.equal(new Set(ids).size,ids.length);assert.ok(ids.every(id=>id.startsWith('qmc-')));
 assert.equal(serializeCollection(doc),before);assert.deepEqual(buildCollection(doc,profile,{includePending:true}),built);
});
test('explicit native checkpoint completion validates reachability and survives export',()=>{
 const source=multiroom();source.rooms[1].map.objects.push({id:'excerpt-end',kind:'checkpoint',x:256,y:200,w:16,h:24,targetSpawn:'start'});
 let doc=addLevel(createCollection('Excerpts'),source,{id:'excerpt',completion:{type:'checkpoint',roomId:'annex',checkpointId:'excerpt-end'}});
 assert.deepEqual(buildCollection(doc,profile,{includePending:true}).levels[0].completion,doc.levels[0].completion);
 for(const completion of [{type:'checkpoint',roomId:'main',checkpointId:'excerpt-end'},{type:'checkpoint',roomId:'annex',checkpointId:'finish'},{type:'unknown'},{type:'exit',x:12},{type:'checkpoint',roomId:'annex',checkpointId:'excerpt-end',x:12}]){
  const invalid=clone(doc);invalid.levels[0].completion=completion;assert.throws(()=>validateCollection(invalid));
 }
 const unreachable=clone(doc);unreachable.levels[0].project.rooms[0].map.objects=unreachable.levels[0].project.rooms[0].map.objects.filter(o=>o.kind!=='portal');
 assert.throws(()=>validateCollection(unreachable),/unreachable/);
 doc=updateLevel(doc,'excerpt',source,{completion:{type:'exit'}});assert.equal(doc.levels[0].revision,2);
 assert.deepEqual(buildCollection(addLevel(createCollection('Default'),project(),{id:'level'}),profile,{includePending:true}).levels[0].completion,{type:'exit'});
});
test('invalid collection identities, duplicates and non-bijective order reject',()=>{
 const source=collection();
 const mutations=[d=>d.version=2,d=>d.format='stock-campaign',d=>d.id='',d=>d.title='',d=>d.revision=0,d=>d.revision=1.5,d=>d.levels[1].id='first',d=>d.levels[0].revision=0,d=>d.levels[0].entryRoom='missing',d=>d.order=['first'],d=>d.order=['first','first'],d=>d.order=['first','missing'],d=>d.levels[0].project.format='stock-map'];
 for(const mutate of mutations){const doc=clone(source);mutate(doc);assert.throws(()=>validateCollection(doc));}
 assert.throws(()=>reorderLevels(source,['first','first']));
});
test('unknown and malformed sidecars and executable values reject without losing safe metadata',()=>{
 const source=addLevel(createCollection('Safe'),multiroom(),{id:'level'});
 const mutations=[d=>d.levels[0].project.rooms[1].switchStudy.version=99,d=>d.levels[0].project.rooms[1].mechanics={type:'future',version:1},d=>d.levels[0].project.rooms[0].devices={},d=>d.extensions={future:{version:1}},d=>d.levels[0].project.extensions={foo:{version:7}},d=>d.levels[0].script='alert(1)',d=>d.levels[0].project.annotation.callback=()=>{},d=>d.levels[0].project.annotation.bad=NaN];
 for(const mutate of mutations){const doc=clone(source);mutate(doc);assert.throws(()=>validateCollection(doc));}
 const accessor=clone(source);Object.defineProperty(accessor,'unsafe',{enumerable:true,get(){throw Error('getter executed');}});assert.throws(()=>validateCollection(accessor),/accessor/);
 assert.throws(()=>parseCollection(JSON.stringify(source).replace('"annotation":{','"annotation":{"__proto__":{},')),/unsafe/);
 const cyclic=clone(source);cyclic.notes=cyclic;assert.throws(()=>validateCollection(cyclic),/cyclic/);
});
test('collection limits bound levels, total rooms and JSON file bytes',()=>{
 const source=collection(),tooMany=clone(source);tooMany.levels=Array.from({length:33},(_,n)=>({...clone(source.levels[0]),id:'level-'+n}));tooMany.order=tooMany.levels.map(level=>level.id);
 assert.throws(()=>validateCollection(tooMany),/level count/);
 const rooms=project();rooms.rooms=Array.from({length:128},(_,n)=>({...clone(rooms.rooms[0]),roomId:'room-'+n}));
 let doc=createCollection('Bounded');doc=addLevel(doc,rooms,{id:'a',entryRoom:'room-0'});doc=addLevel(doc,rooms,{id:'b',entryRoom:'room-0'});
 assert.throws(()=>addLevel(doc,project(),{id:'c'}),/256 rooms/);
 assert.throws(()=>parseCollection(' '.repeat(COLLECTION_LIMITS.bytes+1)),/24 MB/);
 assert.throws(()=>buildCollection(createCollection('Draft'),profile),/at least one level/);
});
test('pending courses stay in review JSON but cannot enter a playable collection',()=>{
 const doc=collection();assert.ok(doc.levels.every(level=>level.approval.status==='pending'));
 assert.throws(()=>buildCollection(doc,profile),/no owner-approved levels/);
 const draft=clone(doc);delete draft.levels[0].approval;assert.deepEqual(validateCollection(draft).levels[0].approval,{status:'pending',by:'owner'});
 assert.equal(parseCollection(serializeCollection(doc)).levels.length,2);
 assert.equal(buildCollection(doc,profile,{includePending:true}).levels.length,2,'explicit internal fixture option can compose pending data');
 assert.throws(()=>buildCollection(doc,profile,{includePending:'true'}),/boolean/);
 const attempted=addLevel(doc,project('New'),{id:'new',approval:{status:'approved',by:'owner'}});assert.equal(attempted.levels[2].approval.status,'pending','adding a new course always starts a review');
});
test('explicit owner approval filters levels in authored order and revocation removes a course',()=>{
 const source=collection(),approved=approveLevel(source,'second','Owner explicitly approved this course revision');
 const built=buildCollection(approved,profile);assert.deepEqual(built.order,['second']);assert.deepEqual(built.levels.map(level=>level.id),['second']);
 assert.equal(built.levels[0].approval.by,'owner');assert.equal(approved.levels[1].revision,source.levels[1].revision);assert.equal(approved.revision,source.revision+1);assert.equal(source.levels[1].approval.status,'pending');
 const both=approveLevel(approved,'first'),reordered=reorderLevels(both,['second','first']);assert.deepEqual(buildCollection(reordered,profile).order,['second','first']);
 const removed=unapproveLevel(reordered,'second');assert.deepEqual(buildCollection(removed,profile).order,['first']);assert.equal(removed.levels[1].revision,1);assert.equal(removed.levels[1].approval.status,'pending');
 assert.equal(parseCollection(serializeCollection(removed)).levels.length,2,'unapproved editor projects remain reimportable');
 assert.throws(()=>approveLevel(source,'missing'),/does not exist/);
});
test('changed project, completion, entry room and metadata revoke approval while no-op and reorder preserve it',()=>{
 const source=multiroom();source.rooms[1].map.objects.push({id:'excerpt-end',kind:'checkpoint',x:256,y:200,w:16,h:24,targetSpawn:'start'});
 const base=approveLevel(addLevel(createCollection('Approved fixture'),source,{id:'level'}),'level');
 assert.equal(updateLevel(base,'level',clone(source)).levels[0].approval.status,'approved');
 assert.equal(reorderLevels(base,['level']).levels[0].approval.status,'approved');
 const edited=clone(source);edited.title='New course title';
 const changed=[updateLevel(base,'level',edited),updateLevel(base,'level',source,{entryRoom:'annex'}),updateLevel(base,'level',source,{completion:{type:'checkpoint',roomId:'annex',checkpointId:'excerpt-end'}}),updateLevel(base,'level',source,{notes:'Changed study'})];
 for(const doc of changed){assert.equal(doc.levels[0].revision,2);assert.deepEqual(doc.levels[0].approval,{status:'pending',by:'owner'});assert.throws(()=>buildCollection(doc,profile),/no owner-approved/);}
 assert.throws(()=>updateLevel(base,'level',source,{approval:{status:'approved',by:'owner'}}),/explicit owner approval/);
});
test('approval metadata rejects unknown status, non-owner claims and malformed evidence',()=>{
 const source=collection();
 for(const approval of [null,[],{status:'approved',by:'assistant'},{status:'maybe',by:'owner'},{status:'approved',by:'owner',evidence:''},{status:'approved',by:'owner',evidence:'x'.repeat(501)},{status:'approved',by:'owner',evidence:12},{status:'approved',by:'owner',version:2}]){
  const doc=clone(source);doc.levels[0].approval=approval;assert.throws(()=>validateCollection(doc));
 }
 assert.throws(()=>approveLevel(source,'first',' '.repeat(20)),/evidence/);
});
test('progress invalidates records for courses removed from the approved playable descriptor',()=>{
 const authored=approveLevel(approveLevel(collection(),'first'),'second'),old=buildCollection(authored,profile);
 const progress=markLevelComplete(old,createProgress(old),'first',{lives:2,coins:8,score:600,power:0,hero:'mario',weapon:'N'});
 const withoutFirst=buildCollection(unapproveLevel(authored,'first'),profile),next=reconcileProgress(withoutFirst,progress);
 assert.deepEqual(next.cleared,[]);assert.equal(next.resume.levelId,'second');
 const withoutSecond=buildCollection(unapproveLevel(authored,'second'),profile);assert.equal(reconcileProgress(withoutSecond,progress).resume,null);
});
