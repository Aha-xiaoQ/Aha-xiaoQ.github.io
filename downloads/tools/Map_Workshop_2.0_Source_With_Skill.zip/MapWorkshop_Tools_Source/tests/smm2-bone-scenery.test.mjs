import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {writeFileSync} from 'node:fs';
import {drawSmm2BoneCastleStatue,drawSmm2BoneCastleFacade} from '../atlas/editor-smm2-bone-art.mjs';
import {drawTile} from '../atlas/editor-art.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';

const require=createRequire(import.meta.url);
let createCanvas;try{({createCanvas}=require('@napi-rs/canvas'));}catch{}
const rasterTest=(name,fn)=>test(name,{skip:!createCanvas},fn);
const canvas=()=>createCanvas(384,216);
const bytes=c=>c.getContext('2d').getImageData(0,0,c.width,c.height).data;
const pixel=(c,x,y)=>[...c.getContext('2d').getImageData(x,y,1,1).data];
const room=()=>({setting:'Castle',map:{width:384,height:216,geometry:[],objects:[]},markers:[],decorations:[],nativeSceneryMode:'authored',smm2Mechanics:{version:1}});
function within(c,q){
 let count=0;const data=bytes(c),colors=new Set();
 for(let y=0;y<c.height;y++)for(let x=0;x<c.width;x++){
  const i=(y*c.width+x)*4;if(!data[i+3])continue;count++;
  assert(x>=q.x&&x<q.x+q.w&&y>=q.y&&y<q.y+q.h,'scenery stays within its authored visual rectangle');
  assert.equal(data[i+3],255,'code-authored edges are opaque pixel steps');
  assert.equal(data[i],data[i+1]);assert.equal(data[i+1],data[i+2],'castle scenery is gray');
  colors.add(data[i]);
 }
 assert(count>0);return {count,colors};
}
function withNative(fn){
 const ui=installSimulatedPlayDom(),create=ui.document.createElement;
 ui.document.createElement=tag=>tag==='canvas'?createCanvas(1,1):create(tag);
 try{return fn();}finally{ui.restore();}
}

rasterTest('measured small castle statues remain bounded, dark, and inert at both plinth heights',()=>{
 // Source rectangles: F01, F06, F10 and both F11 statues. Only camera x changes.
 const sourceRects=[[320,72,336,120],[1248,120,1264,152],[2368,88,2384,136],[2624,104,2640,136],[2784,40,2800,72]];
 for(const [left,top,right,bottom]of sourceRects){
  const q=Object.freeze({id:`statue-${left}`,x:32,y:top,w:right-left,h:bottom-top,material:'decoration',smm2Art:'bone-castle-statue'}),before=JSON.stringify(q),c=canvas();
  assert.equal(drawSmm2BoneCastleStatue(c.getContext('2d'),q),true);
  const result=within(c,q);assert(Math.max(...result.colors)<100,'background carving stays darker than native gray terrain');
  assert.equal(JSON.stringify(q),before);assert.equal(q.standable,undefined);assert.equal(q.oneWay,undefined);assert.equal(q.type,undefined);
  assert.equal(pixel(c,q.x,q.y)[3],0,'statue silhouette does not paint a rectangular backing');
  assert.equal(pixel(c,q.x+2,q.y+q.h-1)[3],255,'plinth rests on its measured lower anchor');
 }
 const tall=canvas(),short=canvas();drawSmm2BoneCastleStatue(tall.getContext('2d'),{x:32,y:32,w:16,h:48});drawSmm2BoneCastleStatue(short.getContext('2d'),{x:32,y:32,w:16,h:32});
 assert.deepEqual(tall.getContext('2d').getImageData(32,32,16,27).data,short.getContext('2d').getImageData(32,32,16,27).data,'only the plinth height changes between measured statues');
 assert.equal(pixel(tall,37,61)[3],255);assert.notDeepEqual(pixel(tall,36,64),pixel(tall,37,64),'the sourced plinth keeps its original vertical grooves');
});

rasterTest('terminal facade stays in its 78 by 80 measured backdrop and leaves a native-door recess',()=>{
 const q=Object.freeze({id:'end-facade',x:288,y:104,w:78,h:80,material:'decoration',smm2Art:'bone-castle-facade'}),before=JSON.stringify(q),c=canvas();
 assert.equal(drawSmm2BoneCastleFacade(c.getContext('2d'),q),true);within(c,q);
 assert.equal(JSON.stringify(q),before);assert.equal(q.standable,undefined);assert.equal(q.oneWay,undefined);
 assert.equal(pixel(c,288,104)[3],0);assert.equal(pixel(c,290,106)[3],255);assert.equal(pixel(c,296,106)[3],0,'crenellation gaps remain transparent');
 assert.equal(pixel(c,320,113)[3],0,'recess between battlements and wall remains open');
 assert.deepEqual(pixel(c,288+26,104+40),[16,16,16,255],'measured terminal door has a dark backing');
 assert.notDeepEqual(pixel(c,289,123),pixel(c,299,123),'mortar separates the low-contrast stone courses');
 assert.equal(pixel(c,365,183)[3],255,'right and bottom extent stop at the measured end');
});

rasterTest('scenery helpers restore canvas state and reject invalid or invisible rectangles',()=>{
 for(const draw of [drawSmm2BoneCastleStatue,drawSmm2BoneCastleFacade]){
  for(const patch of [{hidden:true},{visible:false},{dead:true},{removed:true},{w:0},{h:-1},{x:NaN}]){
   const c=canvas();assert.equal(draw(c.getContext('2d'),{x:32,y:40,w:16,h:48,...patch}),false);assert(bytes(c).every(v=>v===0));
  }
  const c=canvas(),ctx=c.getContext('2d');ctx.fillStyle='#123456';ctx.imageSmoothingEnabled=true;ctx.translate(3,4);
  const before=ctx.getTransform();draw(ctx,{x:32,y:40,w:16,h:48});
  assert.deepEqual(ctx.getTransform(),before);assert.equal(ctx.imageSmoothingEnabled,true);
  // The optional raster library's fillStyle getter is stale after restore;
  // verify the actual restored paint through rendered pixels instead.
  ctx.fillRect(0,0,1,1);assert.deepEqual(pixel(c,3,4),[18,52,86,255]);
 }
});

rasterTest('new scenery preserves native Castle Floor, green pipes, bricks and question blocks',()=>withNative(()=>{
 const active=room(),baseline={...active,smm2Mechanics:undefined};
 for(const material of ['ground','stone','pipe','brick','block']){
  const q={id:`native-${material}`,x:32,y:144,w:32,h:32,material,...(material==='ground'?{smm2Art:'native-castle-floor'}:{})},actual=canvas(),expected=canvas();
  drawTile(actual.getContext('2d'),q,active);drawTile(expected.getContext('2d'),q,baseline);
  assert.deepEqual(bytes(actual),bytes(expected),`native ${material} still uses its original art`);
 }
}));

// Optional direct-raster gallery. This test file is also the bounded renderer:
// SMM2_SCENERY_GALLERY=/tmp/smm2-bone-scenery-gallery.png node --test tests/smm2-bone-scenery.test.mjs
rasterTest('optional statue and end-facade raster gallery',()=>{
 const path=process.env.SMM2_SCENERY_GALLERY;if(!path)return;
 const c=createCanvas(384,216),ctx=c.getContext('2d');ctx.fillStyle='#000000';ctx.fillRect(0,0,384,216);
 ctx.fillStyle='#f4f4f4';ctx.font='9px monospace';ctx.fillText('Code-authored approximate background scenery',8,14);
 for(const q of [{x:32,y:72,w:16,h:48},{x:112,y:88,w:16,h:48},{x:176,y:104,w:16,h:32},{x:224,y:40,w:16,h:32}])drawSmm2BoneCastleStatue(ctx,q);
 drawSmm2BoneCastleFacade(ctx,{x:288,y:104,w:78,h:80});
 withNative(()=>{
  for(const q of [{x:16,y:120,w:64,h:16},{x:96,y:136,w:64,h:16},{x:160,y:136,w:48,h:16},{x:208,y:72,w:48,h:16},{x:272,y:184,w:112,h:16}])drawTile(ctx,{...q,material:'ground',smm2Art:'native-castle-floor'},room());
 });
 ctx.fillStyle='#f4f4f4';ctx.fillText('48px plinths',16,162);ctx.fillText('32px plinths',160,162);ctx.fillText('Door art separate',274,210);
 const enlarged=createCanvas(1152,648),out=enlarged.getContext('2d');out.imageSmoothingEnabled=false;out.drawImage(c,0,0,1152,648);writeFileSync(path,enlarged.toBuffer('image/png'));
});
