import test from 'node:test';
import assert from 'node:assert/strict';
import {createCanvas} from '@napi-rs/canvas';
import {createJrArenaAudience,validateJrArenaAudienceRoom} from '../atlas/editor-jr-arena-audience.mjs';
import {drawJrArenaAudience} from '../atlas/editor-jr-arena-art.mjs';
import {History,parseProject} from '../atlas/editor-model.mjs';
import {updateJrArenaAudience,pruneJrArenaAudienceReferences} from '../atlas/editor-jr-arena-tools.mjs';
import {arenaAudienceProject,finalPhaseAudienceProject,reachNativeAudiencePhase} from './fixtures/jr-arena-audience.mjs';
import {nativeSession} from './fixtures/shell-coin-native.mjs';

const player={x:280,y:378,w:10,h:14},boss={hp:1,phase:'shell'};
const hit=(hp,tick)=>({roomId:'main',actorId:'junior',event:hp?'head-stomp':'defeated',hp,tick});
function rowProject(){const d=finalPhaseAudienceProject(),q=d.rooms[0].smm2Mechanics.arenaAudience;Object.assign(q,{formation:'row',rowCount:6,spawnGapFrames:32,exits:[q.exits[1]],waveCount:1,goombasPerWave:1,maxAlive:6});return d;}
const walk=enemies=>{for(const e of enemies)if(!e.dead)e.x+=e.vx;};

test('optional row fields keep old pairs unchanged and strictly bound the single exit and row budget',()=>{
 assert(validateJrArenaAudienceRoom(arenaAudienceProject().rooms[0]));const r=rowProject().rooms[0];assert(validateJrArenaAudienceRoom(r));
 const minimal=structuredClone(r);delete minimal.smm2Mechanics.arenaAudience.rowCount;delete minimal.smm2Mechanics.arenaAudience.spawnGapFrames;assert(validateJrArenaAudienceRoom(minimal));
 for(const change of [q=>q.formation='spiral',q=>q.rowCount=7,q=>q.rowCount=1,q=>q.rowCount=null,q=>q.spawnGapFrames=null,q=>q.spawnGapFrames=31,q=>q.telegraphFrames=71,q=>q.waveCount=3,q=>q.maxAlive=7,q=>q.goombasPerWave=2,q=>q.exits.push({...q.exits[0],id:'another-exit'}),q=>q.extra=true,q=>q.formation='pair']){const bad=structuredClone(r);change(bad.smm2Mechanics.arenaAudience);assert.throws(()=>validateJrArenaAudienceRoom(bad));}
});
test('one72tick warning produces six ordered native Goombas32ticks apart, then ends without infinite waves',()=>{
 const r=rowProject().rooms[0],enemies=[],events=[],c=createJrArenaAudience(r,{spawn:q=>enemies.push(q),emit:(type,q)=>events.push({type,...q})});c.handleBossEvent(hit(1,10));
 for(let tick=10;tick<=400;tick++){walk(enemies);c.step({tick,boss,enemies,player});if(tick===81){assert.equal(enemies.length,0);assert.equal(c.view().galleryWarnings.length,1);assert.equal(c.view().galleryWarnings[0].queuedCount,6);}if(tick===242){assert.equal(enemies.length,6);assert.deepEqual(enemies.map(e=>e.x),[428,444,460,476,492,508]);}}
 assert.deepEqual(events.filter(q=>q.event==='runner-entered').map(q=>q.tick),[82,114,146,178,210,242]);assert.equal(events.filter(q=>q.event==='gallery-warning').length,1);assert.equal(c.view().maxTotal,6);assert.equal(c.view().galleryWarnings.length,0);assert(enemies.every(e=>e.type==='goomba'&&e.kind==='walker'&&e.vx===-.5&&e.arenaRunner.exitId==='right-exit'));
});
test('occupied exits and living caps delay the entire row without catch-up bursts or feet spawns',()=>{
 const r=rowProject().rooms[0];r.smm2Mechanics.arenaAudience.maxAlive=2;const enemies=[],events=[],c=createJrArenaAudience(r,{spawn:q=>enemies.push(q),emit:(type,q)=>events.push({type,...q})});c.handleBossEvent(hit(1,1));
 for(let tick=1;tick<=140;tick++){walk(enemies);c.step({tick,boss,enemies,player:{...player,x:508}});}assert.equal(enemies.length,0);assert.equal(c.view().galleryWarnings[0].queuedCount,6);
 for(let tick=141;tick<=250;tick++){walk(enemies);c.step({tick,boss,enemies,player});}assert.deepEqual(events.filter(q=>q.event==='runner-entered').map(q=>q.tick),[141,173]);assert.equal(enemies.length,2);
 enemies[0].dead=true;c.step({tick:251,boss,enemies,player});assert.equal(enemies.length,3);enemies[1].dead=true;walk(enemies);c.step({tick:252,boss,enemies,player});assert.equal(enemies.length,3);for(let tick=253;tick<=283;tick++){walk(enemies);c.step({tick,boss,enemies,player});}assert.equal(enemies.length,4);assert.equal(enemies.filter(q=>!q.dead).length,2);
});
test('early genuine victory cancels unspawned row members immediately, preserving native survivors and harmless seats',()=>{
 const r=rowProject().rooms[0],enemies=[],c=createJrArenaAudience(r,{spawn:q=>enemies.push(q)});c.handleBossEvent(hit(1,1));for(let tick=1;tick<=90;tick++){walk(enemies);c.step({tick,boss,enemies,player});}assert.equal(enemies.length,1);c.handleBossEvent(hit(0,91));for(let tick=91;tick<=700;tick++){walk(enemies);c.step({tick,boss:{hp:0,phase:'defeated'},enemies,player});}assert.equal(enemies.length,1);assert.equal(c.view().galleryWarnings.length,0);assert(c.view().spectators.every(q=>q.harmless&&!q.stompable&&!q.countsAsEnemy));
});
test('an explicitly configured second row waits for native survivors to clear and never creates a third row',()=>{
 const r=rowProject().rooms[0];r.smm2Mechanics.arenaAudience.waveCount=2;const enemies=[],events=[],c=createJrArenaAudience(r,{spawn:q=>enemies.push(q),emit:(type,q)=>events.push({type,...q})});c.handleBossEvent(hit(1,1));for(let tick=1;tick<=500;tick++){walk(enemies);c.step({tick,boss,enemies,player});}assert.equal(enemies.length,6);assert.equal(events.filter(q=>q.event==='gallery-warning').length,1);for(const e of enemies)e.dead=true;for(let tick=501;tick<=750;tick++){walk(enemies);c.step({tick,boss,enemies,player});}assert.equal(enemies.length,12);assert.equal(enemies.filter(q=>!q.dead).length,6);assert.deepEqual(events.filter(q=>q.event==='gallery-warning').map(q=>q.tick),[1,501]);assert.equal(events.find(q=>q.event==='runner-entered'&&q.wave===2).tick,573);for(const e of enemies)e.dead=true;for(let tick=751;tick<=1800;tick++)c.step({tick,boss,enemies,player});assert.equal(enemies.length,12);assert.equal(c.view().wavesStarted,2);assert.equal(c.view().maxTotal,12);
});
test('delayed row snapshots are JSON safe, deterministic, strict and independent',()=>{
 const r=rowProject().rooms[0],actors=[],a=createJrArenaAudience(r,{spawn:q=>actors.push(q)});a.handleBossEvent(hit(1,1));for(let tick=1;tick<=100;tick++)a.step({tick,boss,enemies:actors,player:{...player,x:508}});a.step({tick:101,boss,enemies:actors,player});const saved=JSON.parse(JSON.stringify(a.snapshot())),other=structuredClone(actors),b=createJrArenaAudience(r,{spawn:q=>other.push(q)});b.restore(saved);
 for(let tick=102;tick<=330;tick++){walk(actors);walk(other);a.step({tick,boss,enemies:actors,player});b.step({tick,boss,enemies:other,player});assert.deepEqual(b.snapshot(),a.snapshot());assert.deepEqual(other,actors);}saved.pending[0].readyTick=0;assert.throws(()=>b.restore(saved));const duplicate=JSON.parse(JSON.stringify(a.snapshot()));duplicate.pending=[{exitId:'right-exit',wave:1,index:0,startedTick:1,readyTick:73},{exitId:'right-exit',wave:1,index:0,startedTick:1,readyTick:105}];assert.throws(()=>b.restore(duplicate));
});
test('row editor History imports, rejects unknown options atomically, and prunes seats and boss references',()=>{
 const h=new History(rowProject()),room=()=>h.doc.rooms[0];h.change(()=>updateJrArenaAudience(room(),{spawnGapFrames:40}));assert.equal(room().smm2Mechanics.arenaAudience.spawnGapFrames,40);h.undo();assert.equal(room().smm2Mechanics.arenaAudience.spawnGapFrames,32);h.redo();assert.deepEqual(parseProject(JSON.stringify(h.doc)),h.doc);const frozen=JSON.stringify(h.doc);for(const patch of [{rowCount:7},{spawnGapFrames:20},{formation:'pair'},{unknown:true}]){assert.throws(()=>h.change(()=>updateJrArenaAudience(room(),patch)));assert.equal(JSON.stringify(h.doc),frozen);}const before=structuredClone(room());room().map.geometry=room().map.geometry.filter(q=>q.id!=='right-seat-0');pruneJrArenaAudienceReferences(room(),before);assert.equal(room().smm2Mechanics.arenaAudience.seats.length,8);assert.deepEqual(parseProject(JSON.stringify(h.doc)),h.doc);
});
test('row warning draws one gallery light and finite queue lamps with no collision-free Goomba row',()=>{
 const r=rowProject().rooms[0],c=createJrArenaAudience(r),canvas=createCanvas(576,432),ctx=canvas.getContext('2d');c.handleBossEvent(hit(1,1));c.step({tick:2,boss,player});drawJrArenaAudience(ctx,{...r,arenaAudienceView:c.view()},2);assert.equal(c.view().galleryWarnings.length,1);assert.equal(c.view().galleryWarnings[0].rowCount,6);for(let x=400;x<507;x++)assert.equal(ctx.getImageData(x,380,1,1).data[3],0,'warning does not fake a body along the gallery floor');assert(ctx.getImageData(507,380,1,1).data[3]>0);
});
test('two actual Small head contacts naturally reach six native row entries and death resets the whole bounded queue',()=>{
 const d=rowProject(),frozen=JSON.stringify(d),s=nativeSession(d);reachNativeAudiencePhase(s,v=>v.smm2Mechanics.arenaAudience.totalSpawned===6);const entries=s.events.filter(q=>q.type==='smm2-arena-audience'&&q.event==='runner-entered'),hits=s.events.filter(q=>q.type==='smm2-bowser-jr'&&q.event==='head-stomp');assert.deepEqual(hits.map(q=>q.hp),[2,1]);assert.equal(entries.length,6);assert(entries.every((q,i)=>q.tick-hits[1].tick===72+i*32));assert.equal(JSON.stringify(d),frozen);assert.equal(s.view().p.power,0);assert(!s.view().p.dying);assert(s.view().enemies.filter(q=>q.arenaRunner).length<=6);s.until(v=>v.p.dying,{x:1,run:true},600);const audience=s.view().smm2Mechanics.arenaAudience;for(let n=0;n<110;n++){s.step({});assert.deepEqual(s.view().smm2Mechanics.arenaAudience,audience);}assert(s.stage.continueFromCurrent());assert.equal(s.view().smm2Mechanics.arenaAudience.totalSpawned,0);assert.equal(s.view().enemies.filter(q=>q.arenaRunner).length,0);assert.equal(s.view().enemies.find(q=>q.id==='junior').hp,3);
});
