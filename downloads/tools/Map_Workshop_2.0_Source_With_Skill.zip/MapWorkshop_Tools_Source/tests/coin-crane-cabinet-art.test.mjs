import test from 'node:test';
import assert from 'node:assert/strict';
import {createCanvas} from '@napi-rs/canvas';
import {drawCoinCraneBackdrop,drawCoinCraneWorld,drawCoinCraneObject,drawCoinCraneTile} from '../atlas/editor-coin-crane-art.mjs';
import {sourcePixels,sourceKey} from '../atlas/source-art.mjs';
import {drawMarioModuleActor} from '../atlas/editor-study-module-art.mjs';
import {coinCraneProject} from './fixtures/coin-crane-native.mjs';
const data=c=>c.getContext('2d').getImageData(0,0,c.width,c.height).data;
const pixel=(c,x,y)=>[...c.getContext('2d').getImageData(x,y,1,1).data];
function scene(){const machine={id:'cabinet',coinId:'pink',buttonId:'push',minX:264,maxX:392,restY:252,grabY:360,deliveryX:208,deliveryY:352,grip:{x:312,y:252},anchor:{x:312,y:220},cabinet:{x:240,y:204,w:176,h:188},payment:{price:1,entryBonus:10,slotId:'slot',slot:{x:144,y:344,w:16,h:16}},wallet:10,paid:true,needMoney:false,payloads:[{id:'coin',kind:'coin'},{id:'goomba',kind:'goomba'},{id:'spiny',kind:'spiny'},{id:'bomb',kind:'bomb'}]};return{roomId:'art',tick:0,map:{width:512,height:432,geometry:[{id:'push',x:184,y:312,w:16,h:16,collision:'solid'}]},contraptions:{version:1,coinCranes:[machine]}};}

test('cabinet is explicitly optional and the preexisting free leaf has no new background or prize variant',()=>{
 const r=coinCraneProject().rooms[0],c=createCanvas(512,240),ctx=c.getContext('2d');assert.equal(drawCoinCraneBackdrop(ctx,r),false);assert(data(c).every(v=>v===0));assert.equal(drawCoinCraneObject(ctx,r.map.objects.find(q=>q.kind==='coin'),r),false);assert(drawCoinCraneWorld(ctx,r));
 const paid=scene();delete paid.contraptions.coinCranes[0].cabinet;const standalone=createCanvas(512,432);assert.equal(drawCoinCraneBackdrop(standalone.getContext('2d'),paid),false);assert(drawCoinCraneWorld(standalone.getContext('2d'),paid));assert.deepEqual(pixel(standalone,145,333).slice(0,3),[255,242,154],'payment console remains visible without optional cabinet');
});

test('original SMB1 Coin, Goomba and Spiny prizes preserve every source pixel and actual body anchor',()=>{
 for(const [kind,type,w,h]of [['coin','Coin',8,14],['goomba','Goomba',16,16],['spiny','Spiny',16,16]]){
  const r=scene(),body={id:kind,kind:kind==='coin'?'coin':'crate',x:20,y:20,w,h},c=createCanvas(64,64),ctx=c.getContext('2d'),before=JSON.stringify({r,body}),source=sourcePixels(sourceKey('Character',type));assert(drawCoinCraneObject(ctx,body,r));
  const x=Math.round(body.x+(w-source.w)/2),y=body.y+h-source.h;for(let yy=0;yy<source.h;yy++)for(let xx=0;xx<source.w;xx++)assert.deepEqual(pixel(c,x+xx,y+yy),source.pixels[yy*source.w+xx]);assert.equal(JSON.stringify({r,body}),before);
 }
 const r=scene();r.contraptions.coinCranes[0].payloads.push({id:'pink',kind:'pink'});assert.equal(drawCoinCraneObject(createCanvas(32,32).getContext('2d'),{id:'pink',x:0,y:0,w:8,h:14},r),false,'typed Pink stays owned by the original renderer');
});

test('bomb has visible round red ring, black body, raised fuse and open transparent corners instead of a generic square',()=>{
 const r=scene(),o={id:'bomb',kind:'crate',x:8,y:8,w:16,h:16},c=createCanvas(32,32),ctx=c.getContext('2d');assert(drawCoinCraneObject(ctx,o,r));assert.equal(pixel(c,8,8)[3],0);assert.equal(pixel(c,23,23)[3],0);assert.deepEqual(pixel(c,15,8).slice(0,3),[255,232,132]);assert.deepEqual(pixel(c,13,12).slice(0,3),[242,59,57]);assert.deepEqual(pixel(c,16,17).slice(0,3),[21,23,33]);let opaque=0;for(let i=3;i<data(c).length;i+=4)if(data(c)[i]){assert.equal(data(c)[i],255);opaque++;}assert(opaque>80&&opaque<200);
 r.contraptions.coinCranes[0].bombFlash=24;const flashing=createCanvas(32,32);drawCoinCraneObject(flashing.getContext('2d'),o,r,0);assert.notDeepEqual(data(c),data(flashing));
});

test('cabinet chamber, rail, three-finger pose and separate yellow coin console use authored coordinates and pure live status',()=>{
 const r=scene(),before=JSON.stringify(r),c=createCanvas(512,432),ctx=c.getContext('2d');assert(drawCoinCraneBackdrop(ctx,r));assert(pixel(c,300,290)[3]);assert.equal(pixel(c,143,340)[3],0,'console is separate from purple glass');assert(drawCoinCraneWorld(ctx,r));assert.deepEqual(pixel(c,145,333).slice(0,3),[255,242,154]);assert.deepEqual(pixel(c,146,361).slice(0,3),[129,229,103]);assert.equal(JSON.stringify(r),before);
 const down=structuredClone(r);down.contraptions.coinCranes[0].grip.y=340;down.contraptions.coinCranes[0].closed=true;down.contraptions.coinCranes[0].paid=false;down.contraptions.coinCranes[0].needMoney=true;const d=createCanvas(512,432);drawCoinCraneBackdrop(d.getContext('2d'),down);drawCoinCraneWorld(d.getContext('2d'),down);assert.notDeepEqual(data(c),data(d));assert.deepEqual(pixel(d,146,361).slice(0,3),[236,84,59]);
 const failed=structuredClone(r);failed.contraptions.coinCranes[0].bombFlash=24;const failedState=JSON.stringify(failed),flash=createCanvas(512,432);drawCoinCraneBackdrop(flash.getContext('2d'),failed);drawCoinCraneWorld(flash.getContext('2d'),failed);assert.notDeepEqual(data(c),data(flash),'local sparks and displayed claw jolt are visible');assert.equal(JSON.stringify(failed),failedState);
 const g={id:'glass',x:240,y:212,w:16,h:180};r.contraptions.coinCranes[0].glassIds=['glass'];const glass=createCanvas(512,432);assert(drawCoinCraneTile(glass.getContext('2d'),g,r));for(let y=0;y<432;y++)for(let x=0;x<512;x++)if(pixel(glass,x,y)[3])assert(x>=240&&x<256&&y>=212&&y<392);
});

test('large ten-coin and live NPC payloads retain their existing native artwork dispatch',()=>{
 const r=scene(),machine=r.contraptions.coinCranes[0];
 const bodies=[{id:'large',kind:'coin',x:16,y:16,w:32,h:32},{id:'live-goomba',kind:'walker',x:16,y:16,w:16,h:16},{id:'live-koopa',kind:'walker',x:16,y:16,w:16,h:24}];
 machine.payloads.push({id:'large',kind:'large-coin'},{id:'live-goomba',kind:'live-goomba'},{id:'live-koopa',kind:'live-koopa'});r.marioModules={coinValues:{large:10}};
 for(const body of bodies){const c=createCanvas(64,64);assert.equal(drawCoinCraneObject(c.getContext('2d'),body,r,8),false);assert(data(c).every(v=>v===0),'crane art must not replace the native live actor');}
 const c=createCanvas(64,64),large=bodies[0];assert(drawMarioModuleActor(c.getContext('2d'),large,8,r));assert.equal(pixel(c,large.x,large.y)[3],0);assert.equal(pixel(c,large.x+16,large.y+16)[3],255);assert.deepEqual(pixel(c,large.x+16,large.y+12).slice(0,3),[139,74,24],'real ten-coin keeps its native 10 glyph');
});

test('gold lamp head button and blue joystick fit their exact bodies and project independent live controls',()=>{
 const r=scene(),q=r.contraptions.coinCranes[0];q.searchlight={buttonId:'lamp-button',initialOn:false};r.map.geometry.push({id:'lamp-button',x:168,y:312,w:16,h:16,collision:'solid'});
 for(const id of ['push','lamp-button']){const g=r.map.geometry.find(g=>g.id===id),c=createCanvas(512,432);assert(drawCoinCraneTile(c.getContext('2d'),g,r));const p=data(c);let opaque=0;for(let y=0;y<432;y++)for(let x=0;x<512;x++)if(p[(y*512+x)*4+3]){opaque++;assert(x>=g.x&&x<g.x+16&&y>=g.y&&y<g.y+16);assert.equal(p[(y*512+x)*4+3],255);}assert.equal(opaque,256);}
 const render=(id,projection)=>{const c=createCanvas(512,432);drawCoinCraneTile(c.getContext('2d'),r.map.geometry.find(g=>g.id===id),projection);return data(c);};
 const on=structuredClone(r);on.contraptionsView={coinCranes:[{...q,lampOn:true,phase:'scan',buttonPressed:false}]};
 assert.notDeepEqual(render('lamp-button',r),render('lamp-button',on));assert.deepEqual(render('push',r),render('push',on),'lamp does not operate the joystick');
 const lower=structuredClone(on);Object.assign(lower.contraptionsView.coinCranes[0],{phase:'lower',buttonPressed:true});assert.notDeepEqual(render('push',on),render('push',lower),'real lowering phase tilts and depresses the lever');assert.deepEqual(render('lamp-button',on),render('lamp-button',lower));
});

test('machine lamp ignores global ON/OFF and insertion animation uses pure accepted-debit projection',()=>{
 const r=scene(),q=r.contraptions.coinCranes[0];q.searchlight={buttonId:'lamp-button',initialOn:false};r.smm2Mechanics={lighting:{sweepingLamps:[{id:'lamp',x:328,y:232,enabledWhenMachine:'cabinet'}]}};r.switchStudyView={on:true};
 const render=room=>{const before=JSON.stringify(room),c=createCanvas(512,432);drawCoinCraneWorld(c.getContext('2d'),room);assert.equal(JSON.stringify(room),before);return c;};
 const off=render(r);assert.deepEqual(pixel(off,328,231).slice(0,3),[118,140,157]);const globalOff=structuredClone(r);globalOff.switchStudyView.on=false;assert.deepEqual(data(off),data(render(globalOff)));
 const on=structuredClone(globalOff);on.contraptionsView={coinCranes:[{...q,lampOn:true}]};assert.deepEqual(pixel(render(on),328,231).slice(0,3),[255,248,202]);
 const insertion=structuredClone(r);Object.assign(insertion.contraptions.coinCranes[0],{paymentFlash:12});const a=render(insertion);assert.notDeepEqual(data(off),data(a));assert.deepEqual(data(a),data(render(insertion)),'repeated and paused draws do not advance insertion');
});

test('compact collection tray stays behind the visible payment price and insertion slit',()=>{
 const r=scene(),q=r.contraptions.coinCranes[0];q.deliveryX=216;q.deliveryY=352;q.payment.slot={x:208,y:360,w:16,h:16};const c=createCanvas(512,432);drawCoinCraneWorld(c.getContext('2d'),r);
 assert.deepEqual(pixel(c,218,356).slice(0,3),[255,243,191],'one-coin price remains in front');assert.deepEqual(pixel(c,215,364).slice(0,3),[230,194,108],'tray floor cannot cover the real insertion slit');
});

test('cabinet omits the redundant wallet total while keeping the price, paid light and accepted-debit animation',()=>{
 const r=scene(),render=room=>{const c=createCanvas(512,432);drawCoinCraneWorld(c.getContext('2d'),room);return c;};
 const before=JSON.stringify(r),base=render(r),changed=structuredClone(r);changed.contraptions.coinCranes[0].wallet=987;
 assert.deepEqual(data(base),data(render(changed)),'cabinet pixels are independent of the still-projected actual wallet');
 assert.equal(JSON.stringify(r),before,'render never removes or changes controller wallet data');
 const missing=structuredClone(r);delete missing.contraptions.coinCranes[0].wallet;assert.deepEqual(data(base),data(render(missing)));
 assert.deepEqual(pixel(base,155,339).slice(0,3),[255,243,191],'one-coin price remains readable');
 assert.deepEqual(pixel(base,146,361).slice(0,3),[129,229,103],'paid-play light remains readable');
 assert.deepEqual(pixel(base,154,370).slice(0,3),[243,201,80],'former wallet glyph area is plain console');
 const inserting=structuredClone(r);inserting.contraptions.coinCranes[0].paymentFlash=12;assert.notDeepEqual(data(base),data(render(inserting)),'actual accepted-debit insertion animation remains');
});
