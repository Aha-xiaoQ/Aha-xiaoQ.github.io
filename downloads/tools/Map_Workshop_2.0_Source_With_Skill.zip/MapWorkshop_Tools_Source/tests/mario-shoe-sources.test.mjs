import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createMarioModules,validateMarioModulesRoom} from '../atlas/editor-mario-modules.mjs';
import {createSmm2Shoes} from '../atlas/editor-smm2-shoes.mjs';
import {stepStudyEnemy} from '../atlas/editor-switch.mjs';
import {blank,parseProject} from '../atlas/editor-model.mjs';

function fixture({w=24,h=18,direction='down',occupant='goomba'}={}){
 const r=blank('Source foot fixture',512,384).rooms[0];
 r.map.geometry=[{id:'floor',x:0,y:320,w:512,h:64,collision:'solid',material:'ground'},{id:'pipe',x:240,y:160,w:32,h:64,collision:'solid',material:'pipe'}];
 r.map.objects=[{id:'start',kind:'spawn',x:24,y:306,w:10,h:14},{id:'foot-template',kind:'walker',x:96,y:240,w,h}];
 r.smm2Mechanics={version:1,shoes:[{id:'foot-template',kind:'shoe',size:w>24?'big':'small',winged:false,occupant,tuning:{npcHopFrames:36000}}]};
 r.marioModules={version:1,itemSources:[],noteBlocks:[],oneWayWalls:[],enemyVariants:{},enemySources:[{id:'shoe-supply',pipeId:'pipe',enemy:'goomba',smart:false,shoeTemplateId:'foot-template',emergenceFrames:4,direction,intervalFrames:4,initialDelayFrames:0,maxAlive:1,maxEmissions:null,activationDistance:512,vx:-.5,vy:0}]};
 return r;
}
function first(r,m=createMarioModules(r)){return m.spawnEnemies({player:{x:24},enemies:[],tick:1,geometry:r.map.geometry})[0];}

test('shoe source schema persists foot references and rejects missing, non-shoe and incompatible templates',()=>{
 const r=fixture();validateMarioModulesRoom(r);const d=blank('Source persistence',512,384);d.rooms=[r];assert.equal(parseProject(JSON.stringify(d)).rooms[0].marioModules.enemySources[0].shoeTemplateId,'foot-template');
 for(const mutate of [q=>q.marioModules.enemySources[0].shoeTemplateId='missing',q=>q.smm2Mechanics.shoes=[],q=>q.marioModules.enemySources[0].shoeTemplateId='constructor',q=>q.marioModules.enemySources[0].enemy='koopa',q=>q.marioModules.enemySources[0].emergenceFrames=0,q=>q.marioModules.enemySources[0].emergenceFrames=241,q=>q.map.objects.find(a=>a.id==='foot-template').kind='hazard']){const copy=structuredClone(r);mutate(copy);assert.throws(()=>validateMarioModulesRoom(copy));}
});

test('all four pipe mouths emit real authored feet through bounded clipped emergence, then native Shoe gravity',()=>{
 for(const [w,h]of [[16,16],[24,18],[32,32]])for(const direction of ['left','right','up','down']){
  const r=fixture({w,h,direction}),m=createMarioModules(r),shoes=createSmm2Shoes(r),e=first(r,m),pipe=r.map.geometry.find(q=>q.id==='pipe');
  const target={x:direction==='left'?pipe.x-w:direction==='right'?pipe.x+pipe.w:pipe.x+(pipe.w-w)/2,y:direction==='up'?pipe.y-h:direction==='down'?pipe.y+pipe.h:pipe.y+(pipe.h-h)/2};
  assert.equal(e.w,w);assert.equal(e.h,h);assert.equal(e.moduleSource,'shoe-supply');assert.equal(e.moduleShoeTemplateId,'foot-template');assert.equal(e.moduleEmergence.remainingFrames,4);assert.equal(e.sourceClip.direction,direction);
  const pose={x:e.x,y:e.y,w:e.w,h:e.h};shoes.registerActor(e,'foot-template');assert.deepEqual({x:e.x,y:e.y,w:e.w,h:e.h},pose);assert.equal(shoes.contactBody(e),null);
  for(let tick=1;tick<=4;tick++){shoes.beginFrame({tick,actors:[e]});assert.equal(m.stepEnemy(e,{tick,geometry:r.map.geometry}),true);if(tick<4){const before={...e};assert.equal(shoes.stepActor(e,{tick,geometry:r.map.geometry}).advanced,false);assert.equal(e.x,before.x);assert.equal(e.y,before.y);}assert.ok(e.x>=0&&e.y>=0&&e.x+w<=512&&e.y+h<=384);}
  assert.deepEqual({x:e.x,y:e.y},target);assert.equal(e.moduleEmergence,undefined);assert.equal(e.sourceClip,undefined);assert.equal(e.vx,-.5);assert.notEqual(e.x,96);
  let grounded=false;for(let tick=5;tick<=150;tick++){shoes.beginFrame({tick,actors:[e]});assert.equal(m.stepEnemy(e,{tick,geometry:r.map.geometry}),false);shoes.stepActor(e,{tick,geometry:r.map.geometry});grounded||=e.grounded;assert.equal(e.dead,false);}assert.ok(grounded,'emerged foot must fall and land through actual Shoe movement');
 }
});

test('source limit survives real occupant release and later player boarding, replaces only removed bodies, and resets',()=>{
 const r=fixture(),m=createMarioModules(r),shoes=createSmm2Shoes(r),e=first(r,m);shoes.registerActor(e,'foot-template');
 for(let tick=1;tick<=100;tick++){shoes.beginFrame({tick,actors:[e]});if(!m.stepEnemy(e,{tick,geometry:r.map.geometry}))shoes.stepActor(e,{tick,geometry:r.map.geometry});if(tick>1)assert.deepEqual(m.spawnEnemies({player:{x:24},enemies:[e],actors:[e],tick,geometry:r.map.geometry}),[]);}
 const p={id:'player',kind:'player',x:e.x+4,y:e.y-24,w:10,h:14,vx:0,vy:2,power:0,grounded:false};shoes.beginFrame({tick:101,actors:[e],player:p});const before={...p,y:e.y-8-p.h-2};p.y=e.y-8-p.h+2;const released=shoes.afterPlayer(p,before,{tick:101,actors:[e],geometry:r.map.geometry});assert.equal(released.defeated.length,1);assert.equal(e.smm2Shoe.occupancy,'empty');assert.equal(e.dead,false);
 assert.deepEqual(m.spawnEnemies({player:p,enemies:[],actors:[e],tick:101,geometry:r.map.geometry}),[],'detached empty foot still occupies the source limit');
 shoes.beginFrame({tick:102,actors:[e],player:p});const prior={...p,y:e.y-p.h-2};p.y=e.y-p.h+2;assert.deepEqual(shoes.afterPlayer(p,prior,{tick:102,actors:[e],geometry:r.map.geometry}).boarded,[e.id]);assert.equal(e.smm2Shoe.occupancy,'player');assert.equal(e.moduleSource,'shoe-supply');
 for(let tick=102;tick<160;tick++)assert.deepEqual(m.spawnEnemies({player:p,enemies:[],actors:[e],tick,geometry:r.map.geometry}),[],'ridden foot still occupies the source limit');
 e.dead=true;const replacement=m.spawnEnemies({player:p,enemies:[],actors:[e],tick:160,geometry:r.map.geometry})[0];assert.ok(replacement);assert.notEqual(replacement.id,e.id);assert.equal(m.view().enemySources[0].emitted,2);shoes.registerActor(replacement,'foot-template');
 m.reset();shoes.reset();assert.equal(m.view().enemySources[0].emitted,0);const restarted=first(r,m);assert.equal(restarted.id,e.id);shoes.registerActor(restarted,'foot-template');assert.equal(restarted.smm2Shoe.occupancy,'npc');
});

test('source checks actual mouth obstruction, activation delay and collision-safe runtime IDs',()=>{
 const r=fixture(),q=r.marioModules.enemySources[0];q.initialDelayFrames=2;q.activationDistance=20;r.map.objects.push({id:'module-enemy-shoe-supply-0',kind:'coin',x:24,y:200,w:8,h:8});const m=createMarioModules(r),block={id:'mouth-block',x:240,y:224,w:32,h:32,collision:'solid'};
 for(let tick=1;tick<=20;tick++)assert.deepEqual(m.spawnEnemies({player:{x:24},tick,geometry:r.map.geometry}),[]);assert.equal(m.view().enemySources[0].active,false);
 for(let tick=21;tick<=24;tick++)assert.deepEqual(m.spawnEnemies({player:{x:220},tick,geometry:[...r.map.geometry,block]}),[]);assert.equal(m.view().enemySources[0].emitted,0);
 const spawned=m.spawnEnemies({player:{x:220},tick:25,geometry:r.map.geometry});assert.equal(spawned.length,1);assert.equal(spawned[0].id,'module-enemy-shoe-supply-0-spawn-1');assert.deepEqual(m.spawnEnemies({player:{x:220},tick:25,geometry:r.map.geometry}),[]);
});

test('a supplied foot appearing in multiple host lists consumes only one live-source slot',()=>{
 const r=fixture(),q=r.marioModules.enemySources[0];q.maxAlive=2;q.intervalFrames=1;const m=createMarioModules(r),e=first(r,m);e.smm2Shoe={occupancy:'player'};const [second]=m.spawnEnemies({player:{x:24},enemies:[e],actors:[e],tick:2,geometry:r.map.geometry});assert.ok(second);assert.deepEqual(m.spawnEnemies({player:{x:24},enemies:[e,second],actors:[e,second],tick:3,geometry:r.map.geometry}),[]);second.removed=true;assert.equal(m.spawnEnemies({player:{x:24},enemies:[e,second],actors:[e],tick:4,geometry:r.map.geometry}).length,1);
});

test('Shoe factory waits for an actual template foot overlapping its mouth to walk clear before emitting',()=>{
 const r=fixture({direction:'left'}),template=r.map.objects.find(a=>a.id==='foot-template');Object.assign(template,{x:216,y:183});Object.assign(r.map.geometry[0],{y:201,h:183});r.marioModules.enemySources[0].maxAlive=3;const m=createMarioModules(r),shoes=createSmm2Shoes(r),existing={...template,vx:-.5,vy:0,grounded:true,support:'floor',dead:false};
 assert.deepEqual(m.spawnEnemies({player:{x:24},enemies:[existing],actors:[existing],tick:1,geometry:r.map.geometry}),[],'authored live Shoe feet block their real mouth even before decoration');assert.equal(m.view().enemySources[0].emitted,0);shoes.decorateActor(existing);let output=null;
 for(let tick=1;tick<=48;tick++){shoes.beginFrame({tick,actors:[existing]});shoes.stepActor(existing,{tick,geometry:r.map.geometry});assert.equal(existing.y,183);const spawned=m.spawnEnemies({player:{x:24},enemies:[existing],actors:[existing],tick:tick+1,geometry:r.map.geometry});if(tick<48){assert.deepEqual(spawned,[]);assert.equal(m.view().enemySources[0].emitted,0);}else output=spawned[0];}
 assert.equal(existing.x+existing.w,216);assert.ok(output);assert.equal(output.moduleEmergence.targetX,216);assert.equal(output.moduleEmergence.targetY,183);assert.equal(m.view().enemySources[0].emitted,1);assert.equal(m.view().enemySources[0].clock,3);
});

test('Shoe mouth clearance includes empty and ridden feet, ignores removed feet, and preserves legacy plain Goomba emission',()=>{
 for(const occupancy of ['npc','empty','player']){const r=fixture(),m=createMarioModules(r),blocking={id:'foreign-live-foot',type:'smm2-shoe',smm2Shoe:{occupancy},x:244,y:224,w:24,h:18,dead:false};assert.deepEqual(m.spawnEnemies({player:{x:24},enemies:[],actors:[blocking],tick:1,geometry:r.map.geometry}),[]);assert.equal(m.view().enemySources[0].emitted,0);blocking.smm2Shoe.occupancy='removed';assert.equal(m.spawnEnemies({player:{x:24},enemies:[],actors:[blocking],tick:2,geometry:r.map.geometry}).length,1);}
 const r=fixture();delete r.marioModules.enemySources[0].shoeTemplateId;delete r.marioModules.enemySources[0].emergenceFrames;const m=createMarioModules(r),blocking={id:'live-shoe',type:'smm2-shoe',smm2Shoe:{occupancy:'npc'},x:240,y:224,w:32,h:24,dead:false};const [plain]=m.spawnEnemies({player:{x:24},actors:[blocking],tick:1,geometry:r.map.geometry});assert.ok(plain);assert.equal(plain.type,'goomba');assert.equal(plain.w,16);assert.equal(plain.h,16);assert.equal(plain.moduleEmergence,undefined);
});

test('typed Muncher retains its 24px body, stands stationary on real solids, falls after support changes and stays immune to stomp/fire',()=>{
 const r=fixture();r.marioModules.enemySources=[];r.map.objects.push({id:'muncher',kind:'walker',x:160,y:280,w:24,h:24});r.marioModules.enemyVariants.muncher={kind:'muncher'};const m=createMarioModules(r),e={...r.map.objects.at(-1),type:'walker',vx:2,vy:0,grounded:false};m.applyEnemyVariant(e);assert.equal(e.type,'muncher');assert.equal(e.smm2EnemyKind,'muncher');assert.equal(e.w,24);assert.equal(e.h,24);assert.equal(m.enemyVariant('muncher').w,24);
 const support={id:'red-support',x:144,y:304,w:64,h:16,collision:'solid'},solids=[support,r.map.geometry[0]];for(let tick=1;tick<=20;tick++)m.stepEnemy(e,{tick,geometry:solids});assert.equal(e.x,160);assert.equal(e.y,280);assert.equal(e.support,'red-support');assert.equal(e.vx,0);
 for(let tick=21;tick<=50;tick++)m.stepEnemy(e,{tick,geometry:[r.map.geometry[0]]});assert.equal(e.y,296);assert.equal(e.support,'floor');assert.equal(e.dead,undefined);assert.deepEqual(m.enemyContact(e),{harmful:true,stompable:false,shoeStompable:false,fireImmune:true,shellImmune:true,starImmune:true,solidTop:true});assert.equal(m.stompEnemy(e),false);assert.equal(m.enemyContact({id:'ordinary',type:'goomba'}),null);
 for(const extra of [{fire:true},{speed:.5},{script:'kill'}]){const bad=structuredClone(r);Object.assign(bad.marioModules.enemyVariants.muncher,extra);assert.throws(()=>validateMarioModulesRoom(bad));}
});

test('winged floor Fire Piranha uses genuine gravity and emits directional, bounded moving projectiles; normal Mario and unverified shoe stomps stay harmful',()=>{
 const r=fixture();r.marioModules.enemySources=[];r.map.objects.push({id:'fire-plant',kind:'walker',x:160,y:296,w:16,h:24});r.marioModules.enemyVariants['fire-plant']={kind:'floor-piranha',size:'normal',winged:true,hopSpeed:4,hopIntervalFrames:3,fire:true,fireIntervalFrames:4,fireInitialDelayFrames:2,fireVx:2,fireVy:-.25,fireDirection:'player',fireLifetimeFrames:12};const m=createMarioModules(r),e={...r.map.objects.at(-1),vx:0,vy:0,grounded:true,support:'floor',studyActivated:true};m.applyEnemyVariant(e);const shots=[];let hopped=false;
 for(let tick=1;tick<=11;tick++){hopped||=m.beforeEnemy(e);stepStudyEnemy(e,r.map.geometry,512);shots.push(...m.fireShots(e,{tick,player:{x:24,w:10},projectiles:shots}));assert.deepEqual(m.fireShots(e,{tick,player:{x:24,w:10},projectiles:shots}),[]);}assert.ok(hopped);assert.equal(shots.length,3);assert.ok(shots.every(s=>s.vx===-2&&s.vy===-.25&&s.type==='bowserfire'&&s.moduleProjectile));assert.equal(e.dead,undefined);assert.equal(m.enemyContact(e).stompable,false);assert.equal(m.enemyContact(e).shoeStompable,false);assert.equal(m.enemyContact(e).harmful,true);
 const shot=shots[0],start={x:shot.x,y:shot.y};m.stepEnemy(shot,{tick:20,geometry:[]});assert.equal(shot.x,start.x-2);assert.equal(shot.y,start.y-.25);m.stepEnemy(shot,{tick:20,geometry:[]});assert.equal(shot.x,start.x-2);for(let tick=21;tick<=31;tick++)m.stepEnemy(shot,{tick,geometry:[]});assert.equal(shot.dead,true);
 const moving=shots[1],wall={id:'projectile-wall',x:moving.x-3,y:moving.y-4,w:2,h:16,collision:'solid'};m.stepEnemy(moving,{tick:40,geometry:[wall]});assert.equal(moving.dead,true);assert.equal(m.enemyContact(moving).stompable,false);
 m.reset();assert.deepEqual(m.fireShots(e,{tick:1,player:{x:300,w:10}}),[]);assert.deepEqual(m.fireShots(e,{tick:2,player:{x:300,w:10}}),[]);assert.equal(m.fireShots(e,{tick:3,player:{x:300,w:10}})[0].vx,2);
 for(const mutate of [v=>v.fireIntervalFrames=0,v=>v.fireVx=-2,v=>v.fireLifetimeFrames=0,v=>v.fireDirection='any',v=>delete v.fireVy,v=>v.fire=false]){const bad=structuredClone(r);mutate(bad.marioModules.enemyVariants['fire-plant']);assert.throws(()=>validateMarioModulesRoom(bad));}
});

test('stationary unwinged Fire Piranhas honor explicit direction, sleep before activation and bound live shots',()=>{
 for(const direction of ['left','right']){const r=fixture();r.marioModules.enemySources=[];r.map.objects.push({id:'floor-fire',kind:'walker',x:160,y:296,w:16,h:24});r.marioModules.enemyVariants['floor-fire']={kind:'floor-piranha',size:'normal',winged:false,fire:true,fireIntervalFrames:1,fireInitialDelayFrames:0,fireVx:1.5,fireVy:0,fireDirection:direction,fireLifetimeFrames:120};const m=createMarioModules(r),e={...r.map.objects.at(-1),type:'walker',vx:.5,vy:0,grounded:true,support:'floor',studyActivated:false};m.applyEnemyVariant(e);assert.deepEqual(m.fireShots(e,{tick:1,player:{x:24,w:10}}),[]);e.studyActivated=true;const shots=m.fireShots(e,{tick:2,player:{x:direction==='left'?400:24,w:10}});assert.equal(shots[0].vx,direction==='left'?-1.5:1.5);assert.equal(m.beforeEnemy(e),false);stepStudyEnemy(e,r.map.geometry,512);assert.equal(e.x,160);assert.equal(e.support,'floor');const capped=Array.from({length:32},(_,i)=>({...shots[0],id:'capped-'+i}));assert.deepEqual(m.fireShots(e,{tick:3,projectiles:capped}),[]);capped[0].dead=true;assert.equal(m.fireShots(e,{tick:4,projectiles:capped}).length,1);}
});

function stackedFixture(){const r=blank('Measured two-plant stack',1536,512).rooms[0];r.map.geometry=[{id:'floor',x:0,y:400,w:1536,h:112,collision:'solid',material:'ground'}];r.map.objects=[{id:'start',kind:'spawn',x:24,y:386,w:10,h:14},{id:'lower-plant',kind:'walker',x:1024,y:376,w:16,h:24},{id:'upper-plant',kind:'walker',x:1024,y:352,w:16,h:24},{id:'third-plant',kind:'walker',x:1100,y:376,w:16,h:24}];r.marioModules={version:1,itemSources:[],noteBlocks:[],oneWayWalls:[],enemyVariants:{'lower-plant':{kind:'floor-piranha',size:'normal',winged:true,hopSpeed:4,hopIntervalFrames:120},'upper-plant':{kind:'floor-piranha',size:'normal',winged:true,hopSpeed:4,hopIntervalFrames:120,stackedOn:'lower-plant'}}};return r;}

test('authored plant stack preserves measured x1024 feet400/376 and exposes only a live support reference',()=>{
 const r=stackedFixture(),m=createMarioModules(r),lower={...r.map.objects[1],vy:0,studyActivated:true},upper={...r.map.objects[2],vy:0,studyActivated:true};m.applyEnemyVariant(lower);m.applyEnemyVariant(upper);assert.equal(lower.y+lower.h,400);assert.equal(upper.y+upper.h,376);assert.equal(lower.y,376);assert.equal(upper.y,352);assert.equal(upper.x,1024);assert.equal(upper.source.stackedOn,'lower-plant');assert.equal(m.stackSupport('upper-plant'),'lower-plant');assert.equal(m.stackSupport('lower-plant'),null);assert.equal(m.stackSupport('constructor'),null);
 const original=JSON.stringify(r),d=blank('Stack persistence',1536,512);d.rooms=[r];assert.equal(parseProject(JSON.stringify(d)).rooms[0].marioModules.enemyVariants['upper-plant'].stackedOn,'lower-plant');assert.equal(JSON.stringify(r),original);
 for(let tick=1;tick<=20;tick++){m.beforeEnemy(lower);stepStudyEnemy(lower,r.map.geometry,1536);const parentTop={id:lower.id,x:lower.x,y:lower.y,w:lower.w,h:lower.h,collision:'oneway'};m.beforeEnemy(upper);stepStudyEnemy(upper,[parentTop,...r.map.geometry],1536);assert.equal(upper.y+upper.h,lower.y);assert.equal(upper.support,lower.id);}assert.equal(upper.dead,undefined);
 // Removing a real parent support releases gravity; the data reference itself
 // never relocates, carries or rigidly binds the child.
 lower.dead=true;const oldY=upper.y;for(let tick=21;tick<=50;tick++){m.beforeEnemy(upper);stepStudyEnemy(upper,r.map.geometry,1536);}assert.ok(upper.y>oldY);assert.equal(upper.y+upper.h,400);assert.equal(upper.support,'floor');assert.equal(m.stackSupport('upper-plant'),'lower-plant');m.reset();assert.equal(m.stackSupport('upper-plant'),'lower-plant');
});

test('a genuinely grounded stacked winged plant can hop away from its parent one-way top',()=>{
 const r=stackedFixture();r.marioModules.enemyVariants['upper-plant'].hopIntervalFrames=2;const m=createMarioModules(r),lower={...r.map.objects[1],vy:0},upper={...r.map.objects[2],vy:0,studyActivated:true};m.applyEnemyVariant(lower);m.applyEnemyVariant(upper);const top={...lower,collision:'oneway'},solids=[top,...r.map.geometry];assert.equal(m.beforeEnemy(upper),false);stepStudyEnemy(upper,solids,1536);assert.equal(upper.support,'lower-plant');assert.equal(m.beforeEnemy(upper),true);assert.equal(upper.support,null);stepStudyEnemy(upper,solids,1536);assert.ok(upper.y<352);assert.ok(upper.vy<0);assert.equal(upper.grounded,false);assert.equal(lower.y,376);
});

test('stacked floor plants reject missing, same-body, non-enemy and cyclic support references',()=>{
 const r=stackedFixture();for(const target of ['missing','upper-plant','start','constructor']){const bad=structuredClone(r);bad.marioModules.enemyVariants['upper-plant'].stackedOn=target;assert.throws(()=>validateMarioModulesRoom(bad),/distinct existing/);}
 const two=structuredClone(r);two.marioModules.enemyVariants['lower-plant'].stackedOn='upper-plant';assert.throws(()=>validateMarioModulesRoom(two),/Cyclic/);
 const three=structuredClone(r);three.marioModules.enemyVariants['lower-plant'].stackedOn='third-plant';three.marioModules.enemyVariants['third-plant']={kind:'floor-piranha',size:'normal',winged:false,stackedOn:'upper-plant'};assert.throws(()=>validateMarioModulesRoom(three),/Cyclic/);
 const ordinary=structuredClone(r);delete ordinary.marioModules.enemyVariants['upper-plant'].stackedOn;validateMarioModulesRoom(ordinary);assert.equal(createMarioModules(ordinary).stackSupport('upper-plant'),null);
});
