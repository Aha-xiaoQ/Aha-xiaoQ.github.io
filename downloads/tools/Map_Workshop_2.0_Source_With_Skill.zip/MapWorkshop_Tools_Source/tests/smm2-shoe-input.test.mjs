import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {blank} from '../atlas/editor-model.mjs';
import {projectPack} from '../atlas/editor-runtime.mjs';
import {addSmm2Component} from '../atlas/editor-smm2-authoring.mjs';
import {play} from '../atlas/editor-play.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';
const character=JSON.parse(fs.readFileSync(new URL('../atlas/runtime/character.json',import.meta.url)));
function fixture(){const doc=blank('Mounted Shoe input',256,240),r=doc.rooms[0];r.map.geometry=[{id:'floor',x:0,y:224,w:256,h:16,material:'ground',collision:'solid'}];r.map.objects=[{id:'start',kind:'spawn',x:27,y:172,w:10,h:14}];addSmm2Component(r,'shoe',{id:'shoe',x:24,y:208,occupant:'empty'});return {doc,pack:projectPack(doc,r.roomId,character,'shoe-play-input')};}
function controller(id='Xbox Wireless Controller'){return {id,index:0,connected:true,mapping:'standard',axes:[0,0],buttons:Array.from({length:16},()=>({pressed:false,value:0}))};}
async function session(ui,id){const {doc,pack}=fixture(),pad=controller(id);ui.pads.push(pad);const game=await play(pack,doc.rooms,{}, {developerMode:false}),canvas=game.screen.querySelector('canvas'),view=()=>canvas.workshopRead(),button=(i,on)=>{pad.buttons[i]={pressed:on,value:Number(on)};},tap=i=>{button(i,true);ui.frames(2);button(i,false);ui.frames(2);},restart=()=>{game.screen.querySelectorAll('button').find(b=>b.textContent==='重新开始').click();ui.frames(65);assert.equal(view().p.shoeId,'shoe','real falling contact boards empty Shoe after reset');};ui.frames(65);assert.equal(view().p.shoeId,'shoe');return {game,view,pad,button,tap,restart};}

test('real play keyboard and touch jump stay mounted; R and explicit touch command dismount once',async()=>{
 const ui=installSimulatedPlayDom();let s;try{s=await session(ui);ui.key('Space');ui.frames(2);ui.release('Space');assert.equal(s.view().p.shoeId,'shoe');assert(s.view().p.vy<0);ui.frames(80);assert.equal(s.view().p.shoeId,'shoe');
 ui.key('KeyR');ui.frames(2);assert.equal(s.view().p.shoeId,undefined,'R exits naturally boarded Shoe');ui.frames(70);assert.equal(s.view().p.shoeId,'shoe','held R permits a later real landing/remount');ui.key('KeyR',true);ui.frames(2);assert.equal(s.view().p.shoeId,'shoe','keyboard repeat cannot replay dismount');ui.release('KeyR');ui.frames(2);ui.key('KeyR');ui.frames(2);ui.release('KeyR');assert.equal(s.view().p.shoeId,undefined,'release rearms keyboard edge');
 s.restart();const jump=s.game.screen.querySelector('[data-control="runB"]');jump.dispatchEvent({type:'pointerdown',pointerId:11});ui.frames(2);jump.dispatchEvent({type:'pointerup',pointerId:11});assert.equal(s.view().p.shoeId,'shoe');assert(s.view().p.vy<0);ui.frames(80);const exit=s.game.screen.querySelector('[data-control="dismount"]');assert.equal(exit.parentNode.className,'play-pad-middle');assert(s.game.screen.classList.contains('shoe-controls'),'fullscreen layout reserves room above D-pad for dismount');assert.equal(exit.hidden,false);exit.click();ui.frames(2);assert.equal(s.view().p.shoeId,undefined);assert.equal(s.game.screen.querySelector('.play-pause-menu').hidden,true);
 }finally{s?.game.close();ui.restore();}
});

test('real Nintendo play shoulders dismount while A jumps, and pause/reset safely rearms held commands',async()=>{
 const ui=installSimulatedPlayDom();let s;try{s=await session(ui,'Nintendo Switch Pro Controller');s.button(1,true);ui.frames(2);s.button(1,false);ui.frames(80);assert.equal(s.view().p.shoeId,'shoe','Nintendo right A remains jump');
 for(const index of [4,5,6,7]){s.restart();s.button(index,true);ui.frames(2);assert.equal(s.view().p.shoeId,undefined,'shoulder '+index);s.button(index,false);ui.frames(2);}
 s.restart();s.tap(9);const menu=s.game.screen.querySelector('.play-pause-menu');assert.equal(menu.hidden,false);const frozen=JSON.stringify(s.view());s.button(5,true);ui.key('KeyR');s.game.screen.querySelector('[data-control="dismount"]').click();ui.frames(40);ui.release('KeyR');assert.equal(JSON.stringify(s.view()),frozen,'pause freezes physics while dismount inputs are ignored');s.tap(9);assert.equal(menu.hidden,true);ui.frames(2);assert.equal(s.view().p.shoeId,'shoe','held shoulder after pause must release');s.button(5,false);ui.frames(2);s.button(5,true);ui.frames(2);assert.equal(s.view().p.shoeId,undefined);s.button(5,false);ui.frames(2);
 s.button(6,true);s.restart();assert.equal(s.view().p.shoeId,'shoe','restart suppresses held trigger until release');s.button(6,false);ui.frames(2);s.button(6,true);ui.frames(2);assert.equal(s.view().p.shoeId,undefined);s.button(6,false);ui.frames(2);s.restart();s.restart();assert.equal(s.view().p.shoeId,'shoe','repeated restart remains playable');assert.equal(menu.hidden,true);
 }finally{s?.game.close();ui.restore();}
});
