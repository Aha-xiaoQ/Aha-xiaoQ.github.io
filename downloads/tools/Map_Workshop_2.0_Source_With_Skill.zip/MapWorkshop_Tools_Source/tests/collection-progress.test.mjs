import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createProgress,reconcileProgress,markLevelComplete,resumeBoundary,parseProgress,serializeProgress,createProgressStore,collectionCarry} from '../atlas/editor-collection-progress.mjs';
const collection=()=>({id:'collection-a',title:'Authored',revision:1,levels:[{id:'a',revision:1},{id:'b',revision:1},{id:'c',revision:1}],order:['a','b','c']});
const carry={lives:2,coins:43,score:1200,power:2,hero:'mario',weapon:'N'};
const clone=x=>structuredClone(x);
function memoryStorage(){const data=new Map();return {data,getItem:key=>data.get(key)??null,setItem:(key,value)=>data.set(key,value),removeItem:key=>data.delete(key)};}

test('dependency-free progress matches native carryPlayer and stores only safe boundaries',()=>{
 const source=fs.readFileSync(new URL('../atlas/editor-collection-progress.mjs',import.meta.url),'utf8');assert.equal(/^\s*import\b/m.test(source),false);
 const doc=collection(),initial=createProgress(doc);assert.deepEqual(initial.resume,{levelId:'a',revision:1,carry:{lives:3,coins:0,score:0,power:0,hero:'mario',weapon:'N'}});
 const state=resumeBoundary(doc,initial,'b',{...carry,checkpoint:{x:100},world:{taken:['coin']},tape:[{x:1}],x:128});
 assert.deepEqual(state.resume.carry,carry);assert.deepEqual(Object.keys(state.resume.carry),['lives','coins','score','power','hero','weapon']);
 assert.deepEqual(parseProgress(serializeProgress(state,doc),doc),state);assert.equal(initial.resume.levelId,'a');
});
test('real completion advances in explicit order and carries native counters and forms',()=>{
 const doc=collection();doc.order=['b','a','c'];
 let progress=markLevelComplete(doc,createProgress(doc),'b',carry);
 assert.deepEqual(progress.cleared,[{levelId:'b',revision:1}]);assert.equal(progress.resume.levelId,'a');assert.deepEqual(progress.resume.carry,carry);
 progress=markLevelComplete(doc,progress,'a',{...carry,lives:1});progress=markLevelComplete(doc,progress,'c',{...carry,lives:1});
 assert.equal(progress.completed,true);assert.equal(progress.resume,null);assert.equal(progress.cleared.length,3);
 assert.equal(resumeBoundary(doc,progress,'b',carry).completed,false,'free selection starts a fresh boundary even after every level was cleared');
});
test('unchanged ID+revision clears and carry survive reorder and additions',()=>{
 const old=collection(),progress=markLevelComplete(old,createProgress(old),'a',carry),next=collection();
 next.order=['c','b','a','new'];next.levels.push({id:'new',revision:1});next.revision=10;
 const reconciled=reconcileProgress(next,progress);
 assert.deepEqual(reconciled.cleared,[{levelId:'a',revision:1}]);assert.deepEqual(reconciled.resume,progress.resume);assert.equal(reconciled.completed,false);
});
test('changed and removed IDs/revisions invalidate clears and affected resume only',()=>{
 const old=collection();let progress=markLevelComplete(old,createProgress(old),'a',carry);progress=markLevelComplete(old,progress,'b',carry);
 const revised=collection();revised.levels[0].revision=2;revised.levels[2].revision=2;
 const next=reconcileProgress(revised,progress);assert.deepEqual(next.cleared,[{levelId:'b',revision:1}]);assert.equal(next.resume,null);
 revised.levels=revised.levels.filter(level=>level.id!=='b');revised.order=['a','c'];assert.deepEqual(reconcileProgress(revised,next).cleared,[]);
 assert.throws(()=>reconcileProgress({...old,id:'other'},progress),/different collection/);
});
test('progress never trusts arbitrary checkpoint/world/tape fields or malformed carry',()=>{
 const doc=collection(),base=createProgress(doc);
 const mutations=[p=>p.version=2,p=>p.resume.checkpoint={roomId:'main'},p=>p.resume.carry.x=100,p=>p.world={},p=>p.cleared=[{levelId:'a',revision:1},{levelId:'a',revision:1}],p=>p.resume.carry.lives=0,p=>p.resume.carry.coins=100,p=>p.resume.carry.score=-1,p=>p.resume.carry.power=3,p=>p.resume.carry.hero='unknown',p=>p.resume.carry.weapon='Z',p=>delete p.resume.carry.power];
 for(const mutate of mutations){const progress=clone(base);mutate(progress);assert.throws(()=>parseProgress(JSON.stringify(progress),doc));}
 assert.throws(()=>parseProgress('{"__proto__":{}}',doc),/unsafe/);
 assert.throws(()=>parseProgress(' '.repeat(128*1024+1),doc),/128 KB/);
 assert.throws(()=>resumeBoundary(doc,base,'missing',carry),/missing/);
 assert.deepEqual(collectionCarry({...carry,hero:'bill',power:0,weapon:'S'}),{...carry,hero:'bill',power:0,weapon:'S'});
});
test('store reads/writes JSON, reconciles revisions and only explicitly clears data',()=>{
 const doc=collection(),storage=memoryStorage(),store=createProgressStore(doc,{storage});
 assert.equal(store.load().reason,'empty');const saved=markLevelComplete(doc,createProgress(doc),'a',carry);
 assert.equal(store.save(saved).ok,true);assert.deepEqual(store.load().progress,saved);
 const next=collection();next.levels[0].revision=2;const revised=createProgressStore(next,{storage});assert.deepEqual(revised.load().progress.cleared,[]);
 const malformed='{"unexpected":"preserve me"}';storage.data.set(store.key,malformed);const result=store.load();assert.equal(result.ok,false);assert.equal(result.reason,'malformed');assert.equal(storage.data.get(store.key),malformed);
 assert.equal(store.clear().ok,true);assert.equal(storage.data.has(store.key),false);
});
test('unavailable, quota and corrupt storage fail gracefully without losing in-memory state',()=>{
 const doc=collection(),progress=resumeBoundary(doc,createProgress(doc),'c',carry);
 assert.equal(createProgressStore(doc,{storage:null}).load().reason,'unavailable');assert.equal(createProgressStore(doc,{storage:null}).save(progress).reason,'unavailable');
 const full={getItem(){return null;},setItem(){const error=new Error('full');error.name='QuotaExceededError';throw error;},removeItem(){throw Error('blocked');}};
 const store=createProgressStore(doc,{storage:full});const result=store.save(progress);assert.equal(result.ok,false);assert.equal(result.reason,'quota');assert.deepEqual(result.progress,progress);assert.equal(store.clear().reason,'unavailable');
 const desc=Object.getOwnPropertyDescriptor(globalThis,'localStorage');Object.defineProperty(globalThis,'localStorage',{configurable:true,get(){throw Error('security blocked');}});
 try{assert.equal(createProgressStore(doc).load().reason,'unavailable');assert.equal(createProgressStore(doc).save(progress).reason,'unavailable');}finally{if(desc)Object.defineProperty(globalThis,'localStorage',desc);else delete globalThis.localStorage;}
 const storage=memoryStorage(),invalid=createProgressStore(doc,{storage});assert.equal(invalid.save({...progress,world:{}}).reason,'malformed');assert.equal(storage.data.size,0);
});
