import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
import {offlineFile} from '../atlas/editor-offline.mjs';
import {createCollection,addLevel,buildCollection} from '../atlas/editor-collection.mjs';
import {lightingSwitchProject} from './fixtures/lighting-switch-native.mjs';
import {nativeSession,character} from './fixtures/shell-coin-native.mjs';
for(const collection of [false,true])test(`embedded ${collection?'collection':'single'} shares sweep/ON mask and source prize pixels with zero network`,async()=>{
 const doc=lightingSwitchProject(),room=doc.rooms[0];room.smm2Mechanics.lighting={darkness:.86,playerRadius:8,softness:0,sources:[],sweepingLamps:[{id:'ceiling-sweep',x:128,y:24,length:184,halfAngle:10,minAngle:-28,maxAngle:28,periodFrames:240,phaseFrames:0,enabledWhenOn:true}]};
 const s=nativeSession(doc),built=collection?buildCollection(addLevel(createCollection('Neutral sweep closure'),doc,{id:'sweep'}),character,{includePending:true}):null,root=new URL('../atlas/',import.meta.url),html=await offlineFile(s.pack,s.doc.rooms,p=>fs.promises.readFile(new URL(p,root),'utf8'),p=>fs.promises.readFile(new URL('assets/classic-audio/'+p,root)),()=>{},collection?{collection:built}:{}),dir=fs.mkdtempSync(path.join(os.tmpdir(),'Sweeping Light Offline With Spaces '));
 try{
  const file=path.join(dir,'Sweep player.html');fs.writeFileSync(file,html);const checker=fileURLToPath(new URL('../scripts/check-offline-html.mjs',import.meta.url));
  const script=`import fs from 'node:fs';import assert from 'node:assert/strict';import {createContext,SourceTextModule,runInContext} from 'node:vm';import {createCanvas} from '@napi-rs/canvas';import {inspectOfflineHtml} from ${JSON.stringify(checker)};
   const inspected=inspectOfflineHtml(fs.readFileSync(process.argv[1],'utf8'),{collection:${collection}});let network=0;const context=createContext({console,fetch(){network++;throw Error('Offline network forbidden');}}),modules=new Map();for(const [id,code]of inspected.modules)modules.set(id,new SourceTextModule(code,{context,identifier:id}));const link=id=>{assert(modules.has(id),id);return modules.get(id);};const light=modules.get('workshop/editor-smm2-lighting.mjs'),art=modules.get('workshop/editor-coin-crane-art.mjs');for(const mod of [light,art]){if(mod.status==='unlinked')await mod.link(link);if(mod.status!=='evaluated')await mod.evaluate();}
   context.input=${JSON.stringify(JSON.stringify({room,view:{roomId:room.roomId,tick:60,p:null,switchStudy:{version:1,on:true}}}))};const local=runInContext('JSON.parse(input)',context);assert.equal(light.namespace.resolveSmm2SweepingLamps(local.room,local.view).length,1);const render=()=>{const c=createCanvas(256,240),ctx=c.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,256,240);light.namespace.drawSmm2LightingMask(ctx,local.room,local.view,{camera:{x:0,y:0,width:256,height:240},createCanvas});return c;};let c=render();assert.equal(c.getContext('2d').getImageData(128,140,1,1).data[0],255);local.view.switchStudy.on=false;c=render();assert.equal(c.getContext('2d').getImageData(128,140,1,1).data[0],36);assert.equal(light.namespace.resolveSmm2SweepingLamps(local.room,local.view).length,0);
   local.view.switchStudy.on=true;local.view.tick=120;assert.equal(light.namespace.resolveSmm2SweepingLamps(local.room,local.view)[0].angle,28);context.artInput=JSON.stringify({room:{contraptions:{coinCranes:[{id:'body-machine',payloads:[{id:'real-goomba',kind:'goomba'}]}]}},body:{id:'real-goomba',kind:'crate',x:0,y:0,w:16,h:16}});const prize=runInContext('JSON.parse(artInput)',context),p=createCanvas(16,16);assert(art.namespace.drawCoinCraneObject(p.getContext('2d'),prize.body,prize.room));assert(p.getContext('2d').getImageData(8,8,1,1).data[3]>0);assert.equal(network,0);console.log(JSON.stringify({network,embeddedSweep:true,embeddedMask:true,embeddedSourcePrize:true}));`;
  const result=spawnSync(process.execPath,['--experimental-vm-modules','--input-type=module','-e',script,file],{encoding:'utf8',timeout:45000,maxBuffer:1024*1024});assert.equal(result.status,0,result.stderr||result.stdout||String(result.error));assert.deepEqual(JSON.parse(result.stdout),{network:0,embeddedSweep:true,embeddedMask:true,embeddedSourcePrize:true});
 }finally{fs.rmSync(dir,{recursive:true,force:true});}
});
