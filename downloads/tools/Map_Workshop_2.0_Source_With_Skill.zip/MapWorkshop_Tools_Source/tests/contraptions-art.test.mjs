import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {test} from 'node:test';
import assert from 'node:assert/strict';
import {CONTRAPTIONS_PALETTE,drawContraptionsBackground,drawContraptionsBackdrop,drawContraptionsTile,drawContraptionsActor,drawContraptionsScene,drawTrack,drawClaw,drawCar,drawDoor,drawPSwitch,drawKey,drawNote,drawOneWayWall} from '../atlas/editor-contraptions-art.mjs';
import {classicDraw} from '../atlas/classic-art.mjs';

const require=createRequire(import.meta.url);
let createCanvas;try{({createCanvas}=require('@napi-rs/canvas'));}catch{}
const renderTest=(name,fn)=>test(name,{skip:!createCanvas},fn);
function canvas(w=384,h=224){const canvas=createCanvas(w,h);canvas.getContext('2d').imageSmoothingEnabled=false;return canvas;}
function data(im){return im.getContext('2d').getImageData(0,0,im.width,im.height).data;}
function bounds(im){const pixels=data(im);let x0=im.width,y0=im.height,x1=-1,y1=-1,count=0;for(let y=0;y<im.height;y++)for(let x=0;x<im.width;x++){const a=pixels[(y*im.width+x)*4+3];if(!a)continue;x0=Math.min(x0,x);x1=Math.max(x1,x);y0=Math.min(y0,y);y1=Math.max(y1,y);count++;}return {x:x0,y:y0,w:x1-x0+1,h:y1-y0+1,count};}
function pixel(im,x,y){return [...im.getContext('2d').getImageData(x,y,1,1).data];}
function rgba(hex){return [parseInt(hex.slice(1,3),16),parseInt(hex.slice(3,5),16),parseInt(hex.slice(5,7),16),255];}
function room(extra={}){return {map:{width:384,height:224,geometry:[]},contraptions:{version:1,scene:'desert',tracks:[],claws:[],...extra}};}
function nativeDocument(){return {createElement(name){assert.equal(name,'canvas');return createCanvas(1,1);}};}
function withNative(fn){const old=globalThis.document;globalThis.document=nativeDocument();try{return fn();}finally{if(old===undefined)delete globalThis.document;else globalThis.document=old;}}
function save(name,im){if(!process.env.CONTRAPTIONS_ART_QA_DIR)return;fs.mkdirSync(process.env.CONTRAPTIONS_ART_QA_DIR,{recursive:true});fs.writeFileSync(path.join(process.env.CONTRAPTIONS_ART_QA_DIR,name+'.png'),im.toBuffer('image/png'));}

renderTest('ordinary rooms retain their native terrain and scenery renderers',()=>{
 const im=canvas(),c=im.getContext('2d'),ordinary={map:{width:384,height:224}};
 for(const result of [drawContraptionsBackground(c,ordinary,384,224),drawContraptionsBackdrop(c,ordinary),drawContraptionsTile(c,{x:0,y:0,w:16,h:16,material:'desert-ground'},ordinary),drawContraptionsScene(c,ordinary)])assert.equal(result,false);
 assert.equal(bounds(im).count,0);
});
renderTest('desert solids fill their exact rectangle with integer opaque pixels',()=>{
 const im=canvas(),c=im.getContext('2d'),r=room();assert.equal(drawContraptionsTile(c,{x:16,y:32,w:48,h:32,material:'desert-ground'},r),true);
 assert.deepEqual(bounds(im),{x:16,y:32,w:48,h:32,count:48*32});
 const colors=new Set();for(let i=0,d=data(im);i<d.length;i+=4)if(d[i+3]){assert.equal(d[i+3],255);colors.add(`${d[i]},${d[i+1]},${d[i+2]}`);}assert.ok(colors.size>=4);
 assert.equal(drawContraptionsTile(c,{x:96,y:32,w:16,h:16,material:'brick'},r),false,'native bricks pass through');
 assert.equal(drawContraptionsTile(c,{x:96,y:32,w:16,h:16,material:'pipe'},r),false,'native pipes pass through');
 assert.equal(drawContraptionsTile(c,{x:96,y:32,w:16,h:16,pBody:true},r),true,'physical P item support has no separate visible tile');assert.equal(pixel(im,96,32)[3],0);
});
renderTest('ghost-house rail machinery renders its actual path without a desert backdrop',()=>{
 const tracks=[{id:'pow-loop',start:[32,96],segments:[{kind:'line',to:[32,32]},{kind:'line',to:[160,32]},{kind:'line',to:[160,96]},{kind:'line',to:[32,96]}],mode:'loop'}];
 const r={setting:'Ghost House Night',map:{width:192,height:128},contraptions:{version:1,tracks,claws:[]}},authored=canvas(192,128),expected=canvas(192,128);
 drawTrack(expected.getContext('2d'),tracks[0]);assert.equal(drawContraptionsScene(authored.getContext('2d'),r),true);assert.deepEqual(data(authored),data(expected),'theme does not hide or replace the authored rail');
 const active=canvas(192,128);r.contraptionsView={tracks,claws:[]};assert.equal(drawContraptionsScene(active.getContext('2d'),r,{backdrop:false}),true);assert.deepEqual(data(active),data(expected),'preview and runtime use the same path');
 assert.equal(pixel(active,96,64)[3],0,'no themed backdrop was painted');
});
renderTest('keys, notes and controls have readable bounded pixel silhouettes',()=>{
 for(const [name,draw,w,h,maxW,maxH]of [['key',drawKey,16,16,16,16],['note',drawNote,16,16,18,18],['P',drawPSwitch,16,16,16,16],['door',drawDoor,16,32,16,32],['car',drawCar,32,32,32,32],['down-wall',drawOneWayWall,32,32,32,32]]){
  const im=canvas(96,80);draw(im.getContext('2d'),{x:16,y:16,w,h,locked:true},0);const b=bounds(im);assert.ok(b.count>25,name);assert.ok(b.x>=16&&b.y>=16&&b.x+b.w<=16+maxW&&b.y+b.h<=16+maxH,name);
  for(let i=3,d=data(im);i<d.length;i+=4)assert.ok(d[i]===0||d[i]===255,name+' must avoid blended pixel edges');
 }
});
renderTest('pressed P shrinks at the base and legacy-style unlocked door removes its keyhole',()=>{
 const p0=canvas(48,48),p1=canvas(48,48);drawPSwitch(p0.getContext('2d'),{x:16,y:16,w:16,h:16});drawPSwitch(p1.getContext('2d'),{x:16,y:16,w:16,h:16,pressed:true});assert.equal(bounds(p0).h,16);assert.equal(bounds(p1).h,4);assert.equal(bounds(p0).y+bounds(p0).h,bounds(p1).y+bounds(p1).h);assert.notDeepEqual(data(p0),data(p1));
 const runtime=canvas(48,48);drawPSwitch(runtime.getContext('2d'),{x:16,y:28,w:16,h:4,pressed:true});assert.deepEqual(data(runtime),data(p1),'runtime shrunk hitbox keeps the full four-pixel pressed shape');
 const d0=canvas(48,64),d1=canvas(48,64),g=canvas(48,64);drawDoor(d0.getContext('2d'),{x:16,y:16,w:16,h:32,locked:true},{smm2Mechanics:{version:1,art:{palette:'unverified-style'}}});drawDoor(d1.getContext('2d'),{x:16,y:16,w:16,h:32,locked:true,unlocked:true},{smm2Mechanics:{version:1,art:{palette:'unverified-style'}}});drawDoor(g.getContext('2d'),{x:16,y:16,w:16,h:32,locked:false},{smm2Mechanics:{version:1,art:{palette:'unverified-style'}}});assert.notDeepEqual(data(d0),data(d1));assert.notDeepEqual(data(d0),data(g));assert.deepEqual(pixel(g,24,22),rgba(CONTRAPTIONS_PALETTE.green));
 const returnDoor=canvas(48,64);drawDoor(returnDoor.getContext('2d'),{x:16,y:16,w:16,h:32,style:'plain',unlocked:true},{smm2Mechanics:{version:1,art:{palette:'unverified-style'}}});assert.deepEqual(data(returnDoor),data(g),'live unlocked plain return stays green');
 save('controls-raised-P',p0);save('controls-pressed-P',p1);save('door-locked',d0);save('door-unlocked',d1);
});
renderTest('curve rails have pixel dashes, end caps and a resolved chain pose',()=>{
 const track={id:'a',start:[32,64],segments:[{kind:'quadratic',control:[32,24],to:[72,24]},{kind:'line',to:[176,24]},{kind:'quadratic',control:[216,24],to:[216,64]}],mode:'bounce'};
 const im=canvas(256,128),c=im.getContext('2d');assert.equal(drawTrack(c,track),true);assert.equal(drawClaw(c,{anchor:{x:112,y:24},grip:{x:124,y:64},heldId:null}),true);assert.deepEqual(pixel(im,112,28),rgba(CONTRAPTIONS_PALETTE.copperDark));
 const b=bounds(im);assert.ok(b.x<=28&&b.x+b.w>=220);assert.ok(b.y<=20&&b.y+b.h>=73);for(let i=3,d=data(im);i<d.length;i+=4)assert.ok(d[i]===0||d[i]===255);
 const closed=canvas(256,128);drawTrack(closed.getContext('2d'),track);drawClaw(closed.getContext('2d'),{anchor:{x:112,y:24},grip:{x:124,y:64},heldId:'goomba',heldKind:'enemy'});assert.notDeepEqual(data(im),data(closed));save('rail-claw-open',im);save('rail-claw-held',closed);
});
renderTest('live claw view overrides authored pose and scene respects backdrop split',()=>{
 const r=room({tracks:[{id:'a',start:[24,24],segments:[{kind:'line',to:[200,24]}]}],claws:[{id:'claw',trackId:'a',position:64,ropeLength:42}]});
 const authored=canvas(),active=canvas();drawContraptionsScene(authored.getContext('2d'),r,{backdrop:false});assert.deepEqual(pixel(authored,88,28),rgba(CONTRAPTIONS_PALETTE.copperDark),'authored position is world-unit arc length');r.contraptionsView={tracks:r.contraptions.tracks,claws:[{id:'claw',trackId:'a',anchor:{x:160,y:24},grip:{x:166,y:65},heldId:'goomba'}]};drawContraptionsScene(active.getContext('2d'),r,{backdrop:false});assert.notDeepEqual(data(authored),data(active));assert.equal(pixel(active,8,200)[3],0,'machinery pass cannot paint over solid terrain');
});
renderTest('foreground copper hazards differ from faint background cactus art',()=>{
 const im=canvas(),c=im.getContext('2d'),r=room({clouds:[],backgroundCacti:[{x:80,y:160,w:10,h:36}]});drawContraptionsBackground(c,r,384,224);drawContraptionsBackdrop(c,r);assert.equal(drawContraptionsActor(c,{kind:'hazard',x:240,y:16,w:16,h:112},0,r),true);const colors=new Set();for(let y=16;y<128;y++)for(let x=240;x<256;x++)colors.add(pixel(im,x,y).join(','));assert.ok(colors.has(rgba(CONTRAPTIONS_PALETTE.copperDark).join(',')));assert.ok(colors.has(rgba(CONTRAPTIONS_PALETTE.copperLight).join(',')));assert.deepEqual(pixel(im,83,166),rgba(CONTRAPTIONS_PALETTE.sandEdge));
});
renderTest('default dune backdrop joins repeated pages without a vertical seam',()=>{
 const im=canvas(768,224),c=im.getContext('2d'),r=room({clouds:[],backgroundCacti:[]});r.map.width=768;drawContraptionsBackground(c,r,768,224);drawContraptionsBackdrop(c,r);for(let y=0;y<224;y++)assert.deepEqual(pixel(im,383,y),pixel(im,384,y));
});
renderTest('authored right-arrow marker renders an original bounded directional sign',()=>{
 const im=canvas(80,64);assert.equal(drawContraptionsActor(im.getContext('2d'),{kind:'contraption-arrow',x:32,y:24},0,room()),true);const b=bounds(im);assert.ok(b.count>100&&b.x===16&&b.x+b.w<=48&&b.y>=16&&b.y+b.h<=32);
 const fromScene=canvas(80,64),r=room();r.markers=[{kind:'contraption-arrow',x:32,y:24}];drawContraptionsScene(fromScene.getContext('2d'),r,{backdrop:false});assert.deepEqual(data(fromScene),data(im),'world scene preserves the authored center-point marker without a shared renderer change');
});
renderTest('native P conversion renders a brick or coin without creating new native pixels',()=>withNative(()=>{
 const solid=canvas(48,48),loose=canvas(48,48),r=room(),q={id:'p-cell',x:16,y:16,w:16,h:16,material:'ps-block',form:'brick'};drawContraptionsTile(solid.getContext('2d'),q,r);drawContraptionsTile(loose.getContext('2d'),{...q,form:'coin'},r);assert.equal(bounds(solid).count,256);assert.ok(bounds(loose).count<256);assert.notDeepEqual(data(solid),data(loose));
}));

// Four original-art composition checks at the measured 16px course grid.
// These are visual fixtures, not a claim that source motion has been measured.
renderTest('render source-comparable room compositions and P-state differences',()=>withNative(()=>{
 const track=(id,points,controls=[])=>({id,start:points[0],segments:points.slice(1).map((to,i)=>controls[i]?{kind:'quadratic',control:controls[i],to}:{kind:'line',to}),mode:'bounce'});
 const common={clouds:[{x:32,y:66,w:64,h:24},{x:160,y:52,w:48,h:24},{x:304,y:70,w:32,h:24}],backgroundCacti:[{x:163,y:180,w:10,h:30}]};
 const t2=track('t2',[[72,56],[104,24],[328,24]],[[72,24]]),t3a=track('t3a',[[56,56],[88,24],[120,24],[152,56]],[[56,24],null,[152,24]]),t3b=track('t3b',[[216,56],[248,24],[344,24]],[[216,24]]),t4a=track('t4a',[[40,24],[104,24]]),t4b=track('t4b',[[168,24],[296,24],[328,56]],[null,[328,24]]);
 const configs=[
  {name:'room2-original-art',tracks:[t2],claws:[{anchor:{x:241,y:24},grip:{x:239,y:67}},{anchor:{x:251,y:24},grip:{x:258,y:67}}],tiles:[[0,0,384,16],[0,0,16,224],[368,0,16,224],[0,112,112,16],[288,112,48,16],[0,208,384,16]],notes:[[192,96],[304,96]],thorns:[[96,96],[288,96],[320,96]],pipes:[[16,16,32,32]],coins:[[144,144],[160,144],[224,144],[240,144]],goombas:[[24,96],[48,96]],door:[352,176]},
  {name:'room3-original-art',tracks:[t3a,t3b],claws:[{anchor:{x:116,y:24},grip:{x:118,y:67}},{anchor:{x:232,y:24},grip:{x:232,y:69}},{anchor:{x:317,y:24},grip:{x:334,y:65}}],tiles:[[0,0,384,16],[0,0,16,224],[368,0,16,224],[0,112,96,16],[112,112,144,16],[304,112,80,16],[336,96,48,16],[0,208,384,16]],notes:[[320,96]],thorns:[[80,96],[112,96],[240,96],[304,96]],pipes:[[16,16,32,48]],coins:[[144,144],[176,144],[208,144]],goombas:[[16,80],[176,96]],door:[352,176]},
  {name:'room4-pre-P-original-art',tracks:[t4a,t4b],claws:[{anchor:{x:101,y:24},grip:{x:109,y:66}},{anchor:{x:221,y:24},grip:{x:221,y:66}}],tiles:[[0,0,384,16],[0,0,16,224],[368,0,16,224],[48,96,32,32],[128,112,240,16],[352,128,32,80],[0,208,384,16]],notes:[[144,96]],thorns:[[128,16,16,96]],pipes:[[16,96,32,80],[320,112,32,96]],coins:Array.from({length:9},(_,i)=>[160+i*16,96]).concat([[208,80],[256,80]]),bricks:[[128,128,32,32],[288,128,32,32],[304,80,64,16],[304,96,16,16],[352,96,16,16]],goombas:[[320,96],[336,96]],door:[304,176],ps:[80,192]},
  {name:'room5-empty-car-original-art',tracks:[track('t5',[[40,24],[136,24]])],claws:[{anchor:{x:126,y:24},grip:{x:140,y:65}}],tiles:[[0,0,384,16],[0,0,16,224],[16,96,16,32],[0,128,176,16],[16,144,16,64],[240,128,16,16],[0,208,336,16]],notes:[],thorns:[[240,16,16,112]],pipes:[[32,96,32,32]],coins:[],goombas:[[24,80]],car:[112,86],walls:[[176,112],[208,112]]}
 ];
 function render(q,postP=false){const im=canvas(),c=im.getContext('2d'),r=room({...common,tracks:q.tracks,claws:q.claws});drawContraptionsBackground(c,r,384,224);drawContraptionsBackdrop(c,r);
  for(const [x,y,w,h]of q.tiles)drawContraptionsTile(c,{x,y,w,h,material:'desert-ground'},r);
  for(const [x,y,w,h]of q.pipes){classicDraw(c,'pipe_top',x,y);for(let yy=y+16;yy<y+h;yy+=16)classicDraw(c,'pipe_body',x,yy);}
  for(const [x,y]of q.notes)drawNote(c,{x,y,w:16,h:16});
  for(const [x,y,w=16,h=16]of q.thorns)drawContraptionsActor(c,{kind:'hazard',x,y,w,h},0,r);
  for(const [x,y,w=16,h=16]of q.bricks||[])for(let yy=y;yy<y+h;yy+=16)for(let xx=x;xx<x+w;xx+=16)classicDraw(c,postP?'coin0':'brick',xx+(postP?3:0),yy);
  for(const [x,y]of q.coins)classicDraw(c,postP?'brick':'coin0',x+(postP?0:3),y);
  if(q.door)drawDoor(c,{x:q.door[0],y:q.door[1],w:16,h:32,locked:true});drawDoor(c,{x:16,y:160,w:16,h:32,locked:false});
  for(const [x,y]of q.walls||[])drawOneWayWall(c,{x,y,w:32,h:32});
  drawContraptionsScene(c,r,{backdrop:false});for(const [x,y]of q.goombas)classicDraw(c,'goomba',x,y);
  if(q.car)drawCar(c,{x:q.car[0],y:q.car[1],w:32,h:28,occupancy:'empty'},0);
  if(q.ps)drawPSwitch(c,{x:q.ps[0],y:q.ps[1],w:16,h:16,pressed:postP});classicDraw(c,'small_idle',64,192);return im;
 }
 for(const q of configs){const im=render(q);assert.equal(bounds(im).count,384*224);save(q.name,im);if(q.ps){const post=render(q,true);assert.notDeepEqual(data(im),data(post));save('room4-post-P-original-art',post);}}
}));
