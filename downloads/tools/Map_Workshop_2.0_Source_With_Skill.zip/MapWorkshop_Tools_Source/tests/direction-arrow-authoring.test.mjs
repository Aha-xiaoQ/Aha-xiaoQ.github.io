import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {createCanvas} from '@napi-rs/canvas';
import {blank, History, parseProject, runtimeMap} from '../atlas/editor-model.mjs';
import {setDirectionArrow, removeDirectionArrow, cloneDirectionArrow, moveDirectionArrows, mountDirectionArrowTools, DIRECTION_ARROW_DIRECTIONS} from '../atlas/editor-direction-arrow-tools.mjs';
import {drawReference} from '../atlas/editor-art.mjs';
import {drawSmm2SourceArrow} from '../atlas/editor-smm2-art.mjs';
import {drawSmwUnderwaterReference} from '../atlas/editor-smw-underwater-art.mjs';
import {createCollection, addLevel, serializeCollection, parseCollection, buildCollection} from '../atlas/editor-collection.mjs';
import {offlineFile} from '../atlas/editor-offline.mjs';
import {inspectOfflineHtml} from '../scripts/check-offline-html.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';
import {mountPlacementEditor} from './fixtures/placement-editor-dom.mjs';
import {nativeSession, character} from './fixtures/shell-coin-native.mjs';

function fixture() {
  const d = blank('Neutral native direction guides', 640, 384), r = d.rooms[0];
  r.setting = 'Underwater'; r.underwater = true; r.aquatic = {version: 1, contactBodies: 'smm2-solid-actors'};
  r.smm2Mechanics = {version: 1, art: {palette: 'smw-underwater-source'}};
  r.map.geometry = [{id: 'floor', x: 0, y: 352, w: 640, h: 32, collision: 'solid', material: 'ground'}, {id: 'pillar', x: 192, y: 128, w: 32, h: 32, collision: 'solid', material: 'stone'}];
  r.map.objects = [{id: 'start', kind: 'spawn', x: 32, y: 96, w: 10, h: 14}, {id: 'finish', kind: 'exit', x: 608, y: 304, w: 16, h: 48}];
  r.markers = [{id: 'unrelated-reference', kind: 'source-note', x: 16, y: 16, source: {note: 'keep'}}];
  return d;
}
const guide = extra => ({x: 96, y: 64, w: 20, h: 20, direction: 'up-right', signArt: 'smw-observed-floating-arrow', ...extra});
const arrow = (r, id) => r.markers.find(q => q.id === id);
const roundtrip = h => assert.deepEqual(parseProject(JSON.stringify(h.doc)), h.doc);

test('native guide add, same-ID update, saved clone, move and removal preserve real History and qmap round trips', () => {
  const h = new History(fixture()), room = () => h.doc.rooms[0], originalMap = structuredClone(room().map), unrelated = structuredClone(room().markers), value = guide();
  h.change(() => setDirectionArrow(room(), 'guide', value)); value.direction = 'left';
  assert.equal(arrow(room(), 'guide').source.direction, 'up-right');
  h.change(() => {arrow(room(), 'guide').source.note = 'provenance'; arrow(room(), 'guide').source.facing = 'right';});
  h.change(() => setDirectionArrow(room(), 'guide', guide({x: 128, w: 24, h: 24, direction: 'down-left'})));
  assert.equal(room().markers.filter(q => q.id === 'guide').length, 1); assert.equal(arrow(room(), 'guide').source.note, 'provenance'); assert.equal(arrow(room(), 'guide').source.facing, 'left');
  h.change(() => cloneDirectionArrow(room(), 'guide', 'guide-copy', {x: 240, y: 80}));
  assert.deepEqual(arrow(room(), 'guide-copy').source, arrow(room(), 'guide').source);
  h.change(() => moveDirectionArrows(room(), new Set(['guide', 'guide-copy']), 16, 32));
  assert.deepEqual([arrow(room(), 'guide').x, arrow(room(), 'guide').y], [144, 96]); assert.deepEqual([arrow(room(), 'guide-copy').x, arrow(room(), 'guide-copy').y], [256, 112]);
  h.change(() => removeDirectionArrow(room(), 'guide')); assert.equal(arrow(room(), 'guide'), undefined); h.undo(); assert(arrow(room(), 'guide')); h.redo(); assert.equal(arrow(room(), 'guide'), undefined);
  assert.deepEqual(room().map, originalMap); assert.deepEqual(room().markers.filter(q => q.kind !== 'source-arrow'), unrelated); roundtrip(h);
  h.undo(); h.undo(); assert.deepEqual([arrow(room(), 'guide').x, arrow(room(), 'guide').y], [128, 64]); h.redo(); roundtrip(h);
});

test('unsupported fields, IDs, directions, art, sign shape and out-of-room edits atomically preserve document and undo/redo', () => {
  const h = new History(fixture()), room = () => h.doc.rooms[0]; h.change(() => setDirectionArrow(room(), 'guide', guide())); h.change(() => setDirectionArrow(room(), 'redo-guide', guide({x: 300}))); h.undo();
  const before = JSON.stringify(h.doc), undos = h.undoStack.length, redos = h.redoStack.length;
  const symbol = guide(); symbol[Symbol('hidden')] = true;
  for (const operation of [
    () => setDirectionArrow(room(), 'start', guide()), () => setDirectionArrow(room(), 'pillar-arrow', guide()), () => setDirectionArrow(room(), 'unrelated-reference', guide()),
    () => setDirectionArrow(room(), 'INVALID ID', guide()), () => setDirectionArrow(room(), 'constructor', guide()),
    () => setDirectionArrow(room(), 'bad', guide({x: -1})), () => setDirectionArrow(room(), 'bad', guide({x: 630})), () => setDirectionArrow(room(), 'bad', guide({y: 380})),
    () => setDirectionArrow(room(), 'bad', guide({w: 0})), () => setDirectionArrow(room(), 'bad', guide({h: 97})), () => setDirectionArrow(room(), 'bad', guide({x: NaN})),
    () => setDirectionArrow(room(), 'bad', guide({direction: 'north'})), () => setDirectionArrow(room(), 'bad', guide({signArt: 'unvalidated-theme'})),
    () => setDirectionArrow(room(), 'bad', guide({teleport: true})), () => setDirectionArrow(room(), 'bad', symbol), () => setDirectionArrow(room(), 'bad', Object.assign(Object.create({hidden: true}), guide())),
    () => setDirectionArrow(room(), 'bad', guide({signArt: 'smw-observed-arrow'})), () => setDirectionArrow(room(), 'bad', guide({signArt: 'smw-observed-arrow', w: 48, h: 48, direction: 'down'})),
    () => cloneDirectionArrow(room(), 'guide', 'guide', {x: 240, y: 64}), () => cloneDirectionArrow(room(), 'guide', 'finish', {x: 240, y: 64}),
    () => cloneDirectionArrow(room(), 'guide', 'bad-copy', {x: 240, y: 64, kind: 'coin'}), () => moveDirectionArrows(room(), new Set(['guide']), Infinity, 0),
    () => moveDirectionArrows(room(), new Set(['guide', 'start']), 16, 0), () => moveDirectionArrows(room(), ['guide'], 16, 0)
  ]) {assert.throws(() => h.change(operation)); assert.equal(JSON.stringify(h.doc), before); assert.equal(h.undoStack.length, undos); assert.equal(h.redoStack.length, redos);}
  const standalone = fixture().rooms[0], original = structuredClone(standalone); assert.throws(() => setDirectionArrow(standalone, 'overflow', guide({y: 380}))); assert.deepEqual(standalone, original);
  const duplicate = fixture().rooms[0]; duplicate.markers.push({id: 'guide', kind: 'source-arrow', ...guide(), source: {direction: 'right'}}, {id: 'guide', kind: 'source-note', x: 0, y: 0});
  const saved = structuredClone(duplicate); assert.throws(() => setDirectionArrow(duplicate, 'guide', guide()), /unused/); assert.deepEqual(duplicate, saved);
});

test('floating guides permit air and visual overlap, while multi-guide translations reject the whole out-of-bounds move', () => {
  const h = new History(fixture()), room = () => h.doc.rooms[0];
  h.change(() => {setDirectionArrow(room(), 'air', guide()); setDirectionArrow(room(), 'over-pillar', guide({x: 192, y: 128})); setDirectionArrow(room(), 'at-edge', guide({x: 620}));});
  const before = JSON.stringify(h.doc), undos = h.undoStack.length;
  assert.throws(() => h.change(() => moveDirectionArrows(room(), new Set(['air', 'at-edge']), 16, 0)), /inside/); assert.equal(JSON.stringify(h.doc), before); assert.equal(h.undoStack.length, undos); roundtrip(h);
  const plain = fixture(), marked = parseProject(JSON.stringify(h.doc)); assert.deepEqual(runtimeMap(marked.rooms[0]), runtimeMap(plain.rooms[0]));
  const a = nativeSession(plain), b = nativeSession(marked); for (let n = 0; n < 90; n++) assert.deepEqual(b.step({x: 1}), a.step({x: 1}));
});

test('legacy floating markers normalize only their authored visual fields and native semantic aliases remain provenance', () => {
  const r = fixture().rooms[0]; r.markers.push({id: 'legacy-arrow', kind: 'source-arrow', x: 96, y: 64, source: {direction: 'up-right', note: 'observed'}}, {id: 'other-style', kind: 'source-arrow', x: 240, y: 64, source: {signArt: 'smb1-large-wood'}});
  r.semantics = [{id: 'legacy-arrow', kind: 'observed-direction-arrow', source: {source_center: [106, 74], direction: 'up-right'}}];
  const semantics = structuredClone(r.semantics), other = structuredClone(arrow(r, 'other-style'));
  moveDirectionArrows(r, new Set(['legacy-arrow']), 16, 16);
  assert.deepEqual(arrow(r, 'legacy-arrow'), {id: 'legacy-arrow', kind: 'source-arrow', x: 112, y: 80, w: 20, h: 20, source: {direction: 'up-right', note: 'observed', signArt: 'smw-observed-floating-arrow'}});
  assert.deepEqual(r.semantics, semantics); assert.deepEqual(arrow(r, 'other-style'), other);
  const invalid = fixture().rooms[0]; delete invalid.smm2Mechanics.art; const before = structuredClone(invalid); assert.throws(() => setDirectionArrow(invalid, 'guide', guide()), /SMW/); assert.deepEqual(invalid, before);
});

test('real guide panel places, configures, copies saved fields, moves and follows History without offering foreign art', () => {
  const ui = installSimulatedPlayDom();
  try {
    const h = new History(fixture()), room = () => h.doc.rooms[0], parent = ui.document.createElement('aside'), reports = [], panel = mountDirectionArrowTools({parent, room, change: fn => h.change(fn), report: q => reports.push(q)}), get = key => parent.querySelector('[data-direction-arrow="' + key + '"]');
    assert.match(parent.textContent, /浮空箭头可放在空中/); assert.deepEqual(get('signArt').children.map(q => q.value || q.getAttribute('value')), ['smw-observed-floating-arrow', 'smw-observed-arrow']);
    get('id').value = 'ui-arrow'; get('direction').value = 'down-right'; get('x').value = '128'; get('y').value = '64'; get('w').value = '24'; get('h').value = '24'; panel.refresh(); assert.equal(get('direction').value, 'down-right'); get('apply').click();
    assert.equal(arrow(room(), 'ui-arrow').source.direction, 'down-right'); assert.equal(get('id').readOnly, true); roundtrip(h);
    get('direction').value = 'left'; get('clone-id').value = 'ui-copy'; get('clone-x').value = '256'; get('clone-y').value = '96'; get('clone').click(); assert.equal(arrow(room(), 'ui-copy').source.direction, 'down-right', 'copy uses saved direction');
    get('move-right').click(); assert.equal(arrow(room(), 'ui-copy').x, 272); get('move-down').click(); assert.equal(arrow(room(), 'ui-copy').y, 112);
    get('signArt').value = 'smw-observed-arrow'; get('signArt').dispatchEvent({type: 'change'}); assert.equal(get('direction').disabled, true); assert.equal(get('direction').value, 'right'); assert.equal(get('w').value, '48'); get('apply').click(); assert.equal(arrow(room(), 'ui-copy').source.signArt, 'smw-observed-arrow');
    const before = JSON.stringify(h.doc), undos = h.undoStack.length; get('x').value = '639'; get('apply').click(); assert.equal(JSON.stringify(h.doc), before); assert.equal(h.undoStack.length, undos); assert.match(reports.at(-1), /inside/);
    get('remove').click(); assert.equal(arrow(room(), 'ui-copy'), undefined); h.undo(); panel.refresh(); assert(arrow(room(), 'ui-copy')); h.redo(); panel.refresh(); assert.equal(arrow(room(), 'ui-copy'), undefined);
    get('new').click(); assert.equal(get('id').readOnly, false); assert.equal(get('remove').disabled, true); assert.equal(get('direction').disabled, false); roundtrip(h);
  } finally {ui.restore();}
});

test('every supported direction uses the shared source-arrow renderer; collection/native/offline preserve the same visual markers', async () => {
  const d = fixture(), r = d.rooms[0];
  for (let i = 0; i < DIRECTION_ARROW_DIRECTIONS.length; i++) setDirectionArrow(r, 'guide-' + i, guide({x: 64 + i * 32, direction: DIRECTION_ARROW_DIRECTIONS[i]}));
  setDirectionArrow(r, 'ground-sign', guide({x: 16, y: 304, w: 48, h: 48, direction: 'right', signArt: 'smw-observed-arrow'}));
  const draw = (fn, q) => {const c = createCanvas(640, 384); assert.equal(fn(c.getContext('2d'), q, r), true); return [...c.getContext('2d').getImageData(0, 0, 640, 384).data];};
  for (const q of r.markers.filter(q => q.kind === 'source-arrow')) {const source = draw(drawSmwUnderwaterReference, q); assert(source.some((v, i) => i % 4 === 3 && v)); assert.deepEqual(draw(drawReference, q), source); assert.deepEqual(draw(drawSmm2SourceArrow, q), source);}
  const collection = parseCollection(serializeCollection(addLevel(createCollection('Neutral direction guides'), d, {id: 'guide-level'}))), built = buildCollection(collection, character, {includePending: true});
  assert.deepEqual(built.levels[0].rooms[0].markers, r.markers); assert.deepEqual(collection.levels[0].project.rooms[0].markers, r.markers);
  const native = nativeSession(d), root = new URL('../atlas/', import.meta.url);
  const html = await offlineFile(native.pack, d.rooms, p => fs.readFile(new URL(p, root), 'utf8'), p => fs.readFile(new URL('assets/classic-audio/' + p, root))), checked = inspectOfflineHtml(html);
  const roomsText = checked.root.match(/,rooms=(\[[\s\S]*?\]),media=/)?.[1]; assert(roomsText); assert.deepEqual(JSON.parse(roomsText)[0].markers, r.markers); assert(checked.modules.has('workshop/editor-smw-underwater-art.mjs')); assert.match(checked.modules.get('workshop/editor-art.mjs'), /drawSmwUnderwaterReference/);
});

test('full native editor renders placed guides and saves, exports, imports, deletes, undoes and redoes through actual handlers', async () => {
  const editor = await mountPlacementEditor(fixture());
  try {
    const {$, ui} = editor, get = key => ui.document.querySelector('[data-direction-arrow="' + key + '"]'), save = () => { $('save').click(); return editor.document(); };
    assert(get('apply')); $('reference').checked = true; $('reference').dispatchEvent({type: 'change'});
    const pixels = () => [...$('canvas').getContext('2d').getImageData(96, 64, 32, 32).data], before = pixels();
    get('id').value = 'native-guide'; get('x').value = '96'; get('y').value = '64'; get('direction').value = 'up-right'; get('apply').click();
    let saved = save(); assert.equal(arrow(saved.rooms[0], 'native-guide').source.direction, 'up-right'); assert.notDeepEqual(pixels(), before, 'actual native editor draws the shared source arrow');
    assert.match($('markers').textContent, /方向指引/); assert.doesNotMatch($('markers').textContent.match(/方向指引[^）]*）/)?.[0] || '', /未接入行为/);
    get('direction').value = 'down'; get('apply').click(); get('clone-id').value = 'native-guide-copy'; get('clone-x').value = '240'; get('clone-y').value = '96'; get('clone').click(); assert.equal(save().rooms[0].markers.filter(q => q.kind === 'source-arrow').length, 2);
    get('remove').click(); assert.equal(save().rooms[0].markers.filter(q => q.kind === 'source-arrow').length, 1); $('undo').click(); assert.equal(save().rooms[0].markers.filter(q => q.kind === 'source-arrow').length, 2); $('redo').click(); assert.equal(save().rooms[0].markers.filter(q => q.kind === 'source-arrow').length, 1); $('undo').click();
    saved = save(); $('export').click(); const download = editor.downloads.at(-1); assert(download); const text = await download.blob.text(); assert.deepEqual(parseProject(text), saved);
    get('remove').click(); assert.equal(save().rooms[0].markers.filter(q => q.kind === 'source-arrow').length, 1);
    $('file').files = [{size: new Blob([text]).size, text: async () => text}]; await $('file').onchange(); assert.deepEqual(save(), saved); assert.equal(get('marker').value, 'native-guide');
    get('marker').value = 'native-guide-copy'; get('marker').dispatchEvent({type: 'change'}); assert.equal(get('direction').value, 'down'); get('move-right').click(); assert.equal(arrow(save().rooms[0], 'native-guide-copy').x, 256);
  } finally {editor.restore();}
});

