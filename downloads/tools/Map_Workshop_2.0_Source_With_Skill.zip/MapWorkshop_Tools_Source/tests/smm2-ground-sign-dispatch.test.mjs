import test from 'node:test';
import assert from 'node:assert/strict';
import {createCanvas} from '@napi-rs/canvas';
import {drawReference} from '../atlas/editor-art.mjs';
import {drawSmm2SourceArrow} from '../atlas/editor-smm2-art.mjs';

const marker=facing=>({id:'grounded-guide',kind:'source-arrow',x:8,y:8,w:40,h:48,source:{facing,signArt:'smb1-large-wood'}});
const room={smm2Mechanics:{version:1},map:{geometry:[{id:'floor',x:0,y:56,w:64,h:8,collision:'solid',material:'ground'}]}};
function render(draw,facing){const c=createCanvas(64,64),ctx=c.getContext('2d');assert.equal(draw(ctx,marker(facing),room),true);return ctx.getImageData(0,0,64,64).data;}
test('the declared left wooden guide preserves the original board and post as an exact reflected sprite',()=>{
 const right=render(drawSmm2SourceArrow,'right'),left=render(drawSmm2SourceArrow,'left');
 assert.notDeepEqual(left,right,'a left guide cannot reuse the right-facing raster');
 for(let y=0;y<48;y++)for(let x=0;x<40;x++)for(let k=0;k<4;k++)assert.equal(left[((y+8)*64+x+8)*4+k],right[((y+8)*64+8+39-x)*4+k]);
 assert(left.some((v,i)=>i%4===3&&v),'guide has visible original artwork');
});
test('the runtime reference pass uses the same configured sign instead of overlaying a legacy right arrow',()=>{
 for(const facing of ['left','right'])assert.deepEqual(render(drawReference,facing),render(drawSmm2SourceArrow,facing));
});
