import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
import {offlineFile} from '../atlas/editor-offline.mjs';
import {createCollection,addLevel,approveLevel,buildCollection} from '../atlas/editor-collection.mjs';
import {lightingProject} from './fixtures/lighting-native.mjs';
import {nativeSession,character} from './fixtures/shell-coin-native.mjs';

for(const collection of [false,true])test(`standalone ${collection?'collection':'single map'} executes genuine embedded native lighting, moving bodies, pickup, circular mask and HUD without network`,async()=>{
 const project=lightingProject(),session=nativeSession(project),root=new URL('../atlas/',import.meta.url),built=collection?buildCollection(approveLevel(addLevel(createCollection('Neutral lighting closure'),project,{id:'light-fixture'}),'light-fixture','Synthetic neutral fixture approval for automated QA only'),character):null,html=await offlineFile(session.pack,session.doc.rooms,p=>fs.promises.readFile(new URL(p,root),'utf8'),p=>fs.promises.readFile(new URL('assets/classic-audio/'+p,root)),()=>{},collection?{collection:built}:{});
 assert(html.includes('editor-smm2-lighting.mjs'));assert(html.includes('"lighting"'));
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'Night Lighting Offline QA ')),htmlPath=path.join(dir,'fixture.html'),projectPath=path.join(dir,'fixture.qmap.json');
 try{
  fs.writeFileSync(htmlPath,html);fs.writeFileSync(projectPath,JSON.stringify(project));const result=spawnSync(process.execPath,['--experimental-vm-modules',fileURLToPath(new URL('../scripts/check-lighting-offline.mjs',import.meta.url)),htmlPath,projectPath,...(collection?['collection']:[])],{encoding:'utf8',timeout:45000,maxBuffer:1024*1024});assert.equal(result.status,0,result.stderr||result.stdout||String(result.error));const report=JSON.parse(result.stdout);
  for(const key of ['actualEmbeddedStageExecuted','actualEmbeddedMotorExecuted','actualEmbeddedLightingExecuted','actualEmbeddedPlayExecuted','enemyMoved','powFell','liftMoved','coinTaken','maskBeforeHud'])assert.equal(report[key],true,key);
  assert.equal(report.actualEmbeddedBootstrapExecuted,true);assert.equal(report.collectionLauncherExecuted,collection);assert.equal(report.bootstrapCoinPickup,true);
  assert.equal(report.collection,collection);assert.equal(report.networkRequests,0);assert.equal(report.frames,150);assert(report.brightHudPixels>300);assert.equal(report.originalTimingCalibrated,false);
 }finally{fs.rmSync(dir,{recursive:true,force:true});}
});
