import test from 'node:test';
import assert from 'node:assert/strict';
import {createChainChompGuards,validateChainChompGuards,sweptChainChompCircle} from '../atlas/editor-chain-chomp-guard.mjs';
import {chainChompGuardOpaqueRects,chainChompGuardHeadFrame,drawChainChompGuard} from '../atlas/editor-chain-chomp-guard-art.mjs';
import {guardProject,guardRule} from './fixtures/chain-chomp-neutral.mjs';
const copy=structuredClone;
const close=(a,b)=>assert(Math.abs(a-b)<1e-6,`${a} differs from ${b}`);
function session(options={}){const d=guardProject(options),r=d.rooms[0],events=[],controller=createChainChompGuards(r,{emit:(type,event)=>events.push({type,...event})}),actor=controller?.decorateActor({...r.map.objects.find(q=>q.kind==='walker')}),player={x:195,y:378,w:10,h:14,vx:0,vy:0,dead:false};let tick=0;return {d,r,events,controller,actor,player,step(p=player){return controller.stepActor(actor,{tick:++tick,player:p,geometry:r.map.geometry});},get tick(){return tick;}};}

test('missing and empty optional list remain inert and preserve authored data',()=>{
 const d=guardProject({guard:false}),r=d.rooms[0],saved=JSON.stringify(d);validateChainChompGuards(r);assert.equal(createChainChompGuards(r),null);assert.equal(JSON.stringify(d),saved);r.contraptions.chainChompGuards=[];assert.equal(createChainChompGuards(r),null);
 assert.equal(drawChainChompGuard({},r.map.objects[1],0,r),false,'old walker renderer retains ownership without the leaf');
});

test('closed explicit schema rejects missing fields, aliases, giant matrices and hidden speed damage',()=>{
 const keys=Object.keys(guardRule(guardProject()));for(const key of keys){const d=guardProject();delete guardRule(d)[key];assert.throws(()=>validateChainChompGuards(d.rooms[0]),/Missing/);}
 for(const extra of [{speedThreshold:2},{giant:true},{hp:5},{postDestruction:true},{originalTiming:true},{id:'alias'}]){const d=guardProject();Object.assign(guardRule(d),extra);assert.throws(()=>validateChainChompGuards(d.rooms[0]),/Unknown/);}
 for(const mutate of [q=>q.leashLength=Infinity,q=>q.leashLength=161,q=>q.phase.windupFrames=23,q=>q.phase.lungeFrames=0,q=>q.phase.retractFrames=23,q=>q.motion.lungeHeight=NaN,q=>q.motion.retractHeight=25,q=>q.post.anchorY++,q=>q.post.w=32,q=>q.rest.x++,q=>q.postId=q.actorId]){const d=guardProject();mutate(guardRule(d));assert.throws(()=>validateChainChompGuards(d.rooms[0]));}
 for(const leaf of [null,{},'guard',new Array(33).fill({})]){const d=guardProject();d.rooms[0].contraptions.chainChompGuards=leaf;assert.throws(()=>validateChainChompGuards(d.rooms[0]));}
});

test('native body, rooted post, rest clearance and exclusive ownership are real requirements',()=>{
 const mutations=[r=>r.map.objects[1].w=64,r=>r.map.objects[1].kind='hazard',r=>r.map.geometry[0].y++,r=>r.map.geometry[0].motion={axis:'x',min:0,max:16,speed:1},r=>r.map.objects.push(copy(r.map.objects[1])),r=>r.smm2Mechanics.portableStones={version:1,stones:[{id:'guard-head'}]},r=>r.marioModules={enemyVariants:{'guard-head':{type:'study-chomp'}}},r=>r.underwater=true,r=>r.map.geometry.push({id:'block',x:96,y:360,w:16,h:32,collision:'solid'})];
 for(const mutate of mutations){const d=guardProject();mutate(d.rooms[0]);assert.throws(()=>validateChainChompGuards(d.rooms[0]));}
 const d=guardProject();d.rooms[0].marioModules={enemyVariants:{}};assert.doesNotThrow(()=>validateChainChompGuards(d.rooms[0]));
});

test('authored readable windup, sampled horizontal aim, lunge and recovery use finite actor states',()=>{
 const s=session(),a=s.actor,q=guardRule(s.d);for(let n=0;n<q.phase.idleFrames;n++)s.step();assert.equal(a.chainChompGuard.phase,'windup');assert.equal(a.chainChompGuard.openMouth,true);assert.equal(a.chainChompGuard.direction,1);
 for(let n=0;n<q.phase.windupFrames;n++)s.step({...s.player,x:0});assert.equal(a.chainChompGuard.phase,'lunge');assert.equal(a.chainChompGuard.direction,1,'aim remains the side sampled at the start of the visible cue');
 for(let n=0;n<q.phase.lungeFrames;n++)s.step();assert.equal(a.chainChompGuard.phase,'retract');close(a.x+16,152);close(a.y+16,376);
 for(let n=0;n<q.phase.retractFrames;n++)s.step();assert.equal(a.chainChompGuard.phase,'recovery');close(a.x+16,104);close(a.y+16,376);
 for(let n=0;n<q.phase.recoveryFrames;n++)s.step();assert.equal(a.chainChompGuard.phase,'idle');assert.equal(a.chainChompGuard.cycle,1);
 assert.deepEqual(s.events.filter(e=>e.event==='phase').map(e=>[e.tick,e.phase]),[[48,'windup'],[78,'lunge'],[96,'retract'],[144,'recovery'],[180,'idle']]);
});

test('every head centre obeys the actual leash and machine x195 remains beyond every right bite',()=>{
 const s=session();let max=0;for(let n=0;n<540;n++){const before=copy(s.actor);s.step();const a=s.actor,st=a.chainChompGuard;assert(Math.hypot(a.x+16-st.anchor.x,a.y+16-st.anchor.y)<=72+1e-7);max=Math.max(max,a.x+a.w);assert.equal(s.controller.playerContact(a,s.player,s.player,{tick:s.tick,beforeActor:before}).hurt,false);}
 close(max,168);
 const left=session();for(let n=0;n<180;n++){left.step({...left.player,x:0});assert(left.actor.x>=0);assert(Math.hypot(left.actor.x+16-80,left.actor.y+16-376)<=72+1e-7);}
});

test('opaque head contact includes teeth and torso but leaves transparent square corners safe',()=>{
 const s=session(),a=s.actor,c=s.controller;
 assert(c.playerContact(a,{x:99,y:372,w:2,h:2}).hurt);
 assert(c.playerContact(a,{x:116,y:380,w:1,h:1}).hurt,'jaw remains physical');
 assert(!c.playerContact(a,{x:88,y:360,w:2,h:2}).hurt,'transparent upper-left bounding-box corner is safe');
 assert(!c.playerContact(a,{x:118,y:360,w:2,h:2}).hurt,'transparent upper-right corner is safe');
 assert(!c.playerContact(a,{x:73,y:370,w:3,h:3}).hurt,'post and chain are visual, not invisible damaging bodies');
 const hit=c.playerContact(a,{x:99,y:372,w:2,h:2});assert.equal(hit.stomp,false);assert.equal(hit.handled,true);assert.equal(hit.kind,'opaque-swept-head');
});

test('continuous relative head contact catches clear-endpoint crossings without any player-speed threshold',()=>{
 const s=session(),c=s.controller,a=s.actor,before={x:40,y:370,w:10,h:14},after={x:150,y:370,w:10,h:14};assert(!c.playerContact(a,before).hurt);assert(!c.playerContact(a,after).hurt);assert(c.playerContact(a,after,before).hurt);
 const staticPlayer={x:142,y:370,w:4,h:14};while(s.tick<78)s.step();const prior=copy(a);s.step();assert(a.x>prior.x);assert(c.playerContact(a,{x:a.x+12,y:a.y+10,w:2,h:2}).hurt);
 const samePosition={x:102,y:370,w:10,h:14,vy:0};for(const vx of [-100,0,.001,100])assert(c.playerContact(a,{...samePosition,x:90,vx},{...samePosition,x:90,vx}).hurt,'contact depends on the same occupied space for every supplied velocity');
 assert(sweptChainChompCircle({x:0,y:0},{x:100,y:0},1,{x:49.999,y:-.01,w:.002,h:.02},{x:49.999,y:-.01,w:.002,h:.02}));
 assert(!sweptChainChompCircle({x:0,y:0},{x:1,y:0},5,{x:4.5,y:4.5,w:1,h:1},{x:4.5,y:4.5,w:1,h:1}));
});

test('actual solid walls stop swept opaque head motion and retract retraces without tunnelling',()=>{
 const s=session({wall:true});let maxRight=0;for(let n=0;n<180;n++){s.step();maxRight=Math.max(maxRight,s.actor.x+32);assert(s.actor.x+32<=136+1e-6);}
 assert(maxRight>135.99);assert(s.events.some(e=>e.event==='blocked'&&e.solidId==='guard-wall'));close(s.actor.x+16,104);
 const hidden=session({wall:true});hidden.r.map.geometry[1].hidden=true;for(let n=0;n<96;n++)hidden.step();close(hidden.actor.x+16,152);
});

test('duplicate/backward ticks, pause, pure views, actor snapshots and reset preserve motion ownership',()=>{
 const s=session(),a=s.actor;for(let n=0;n<84;n++)s.step();const before=copy(a),read=copy(s.controller.view()),events=s.events.length;
 s.controller.stepActor(a,{tick:s.tick,player:s.player,geometry:s.r.map.geometry});s.controller.stepActor(a,{tick:s.tick-1,player:s.player,geometry:s.r.map.geometry});assert.deepEqual(a,before);assert.equal(s.events.length,events);
 const v=s.controller.view();v.guards[0].state.phaseFrame=999;v.guards[0].post.x=999;assert.deepEqual(s.controller.view(),read);
 s.controller.pause();s.step();assert.deepEqual(a,before);s.controller.resume();
 const restored=JSON.parse(JSON.stringify(a)),other=createChainChompGuards(s.r),b=other.decorateActor(restored);for(let n=0;n<90;n++){const tick=s.tick+1;s.step();other.stepActor(b,{tick,player:s.player,geometry:s.r.map.geometry});assert.deepEqual(b,a);}
 s.controller.reset();close(a.x,88);close(a.y,360);assert.equal(a.chainChompGuard.phase,'idle');assert.equal(a.chainChompGuard.phaseFrame,0);assert.equal(a.chainChompGuard.cycle,0);assert.equal(a.chainChompGuard.lastTick,null);
 for(const tick of [undefined,-1,.5,Infinity])assert.throws(()=>s.controller.stepActor(a,{tick,geometry:s.r.map.geometry}),/tick/);
});

test('drawn native head opacity and all phase frames share the controller contact silhouette',()=>{
 const s=session();for(const phase of ['idle','windup','lunge','retract','recovery']){const a=copy(s.actor);a.chainChompGuard.phase=phase;a.chainChompGuard.openMouth=['windup','lunge'].includes(phase);const image=chainChompGuardHeadFrame(a),runs=chainChompGuardOpaqueRects(a);assert.equal(image.w,32);assert.equal(image.h,32);for(let y=0;y<32;y++)for(let x=0;x<32;x++)assert.equal(image.rows[y][x]!=='.',runs.some(r=>r.y===y&&x>=r.x&&x<r.x+r.w));}
});
