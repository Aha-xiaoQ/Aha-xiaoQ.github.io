import fs from 'node:fs';
import assert from 'node:assert/strict';
import {test} from 'node:test';
import {blank} from '../atlas/editor-model.mjs';
import {projectPack} from '../atlas/editor-runtime.mjs';
import {createStageCatalog} from '../atlas/runtime/stage-catalog.mjs';
import {createPlatformStage} from '../atlas/editor-mario-stage.mjs';
import {createPlatformMotor} from '../atlas/editor-mario-motor.mjs';
import {setClassicCheckpoint} from '../atlas/editor-classic-motion-tools.mjs';

const character=JSON.parse(fs.readFileSync(new URL('../atlas/runtime/character.json',import.meta.url)));

// Authored isolation fixture, not an original-ROM experiment or full-course run.
// The starting spawn deliberately sits two pixels before the camera threshold.
// Every later position, stroke, timer decrement and death comes from native input.
function fixture(){
 const doc=blank('Hidden camera midpoint boundary fixture',3072,240),room=doc.rooms[0];
 room.setting='Underwater';room.underwater=true;
 room.map.geometry=[{id:'floor',x:0,y:208,w:3072,h:32,collision:'solid',material:'ground'}];
 room.map.objects=[
  {id:'start',kind:'spawn',x:1378,y:64,w:10,h:14},
  {id:'midpoint-spawn',kind:'spawn',x:1320,y:176,w:10,h:14},
  {id:'midpoint',kind:'checkpoint',x:1280,y:144,w:16,h:48,targetSpawn:'midpoint-spawn'},
 ];
 room.playRules={version:1,timeLimit:400,timerFrames:24,viewportWidth:256,viewportHeight:240,cameraAnchor:100};
 room.aquatic={version:1,physics:{strokeSpeed:1.5,gravity:.05078125,top:20}};
 setClassicCheckpoint(room,'midpoint','hidden-camera',1280);
 const pack=projectPack(doc,room.roomId,character,'midpoint-boundary-fixture');
 const plan=createStageCatalog(pack).plan(pack.stages[0].id,pack.characters[0].id,{allowDraft:true});
 const events=[];
 const stage=createPlatformStage({plan,motor:createPlatformMotor(),visualRooms:doc.rooms,manualDeath:false,autoContinue:false,allowWarp:false,emit:(type,data)=>events.push({type,...data})});
 return {stage,roomId:room.roomId,events};
}

function timeOutAtBoundary(waitFrames,moveFrames){
 const {stage,roomId,events}=fixture();
 // Real press/release strokes hold Mario safely at the authored water surface.
 for(let n=0;n<waitFrames;n++)stage.step({jump:n%2===1});
 for(let n=0;n<moveFrames-1;n++)stage.step({x:1});
 const prior=stage.view();
 assert.equal(prior.timeLeft,1);
 assert.equal(prior.lives,3);
 assert.equal(prior.p.power,0);
 assert(!prior.p.dying);
 stage.step({x:1});
 const death=stage.view();
 assert.equal(death.tick,400*24,'Timeout must spend the full ordinary 400-unit timer');
 assert.equal(death.p.dying,true);
 assert.equal(death.lives,2);
 assert.equal(death.timeLeft,400);
 for(let n=0;n<104;n++)stage.step({});
 const retry=stage.view();
 assert.equal(retry.roomId,roomId);
 assert.equal(retry.lives,2);
 assert.equal(retry.timeLeft,400);
 assert.equal(retry.p.power,0);
 assert(!retry.p.dying);
 return {prior,death,retry,events};
}

test('a true timeout before the hidden camera threshold keeps the initial spawn',()=>{
 const {prior,death,retry,events}=timeOutAtBoundary(9590,10);
 assert(prior.cam<1280);
 assert(death.cam<1280);
 assert.equal(death.checkpoint.spawnId,'start');
 assert.equal(retry.checkpoint.spawnId,'start');
 assert.equal(retry.p.x,1378);
 assert.equal(retry.p.y,64);
 assert.equal(events.filter(e=>e.type==='checkpoint').length,0);
});

test('a true timeout immediately after the camera reaches the hidden midpoint uses that midpoint',()=>{
 const {prior,death,retry,events}=timeOutAtBoundary(9589,11);
 assert(prior.cam>=1280);
 // The last safe frame has already reached the camera threshold.
 assert.equal(death.checkpoint.spawnId,'midpoint-spawn');
 assert.equal(retry.checkpoint.spawnId,'midpoint-spawn');
 assert.equal(retry.p.x,1320);
 assert.equal(retry.p.y,176);
 assert.equal(events.filter(e=>e.type==='checkpoint').length,1);
});
