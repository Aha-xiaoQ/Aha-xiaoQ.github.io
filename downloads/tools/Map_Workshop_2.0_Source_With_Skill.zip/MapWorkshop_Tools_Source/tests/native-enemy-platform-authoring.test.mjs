import {test} from 'node:test';
import assert from 'node:assert/strict';
import {clone,History,parseProject} from '../atlas/editor-model.mjs';
import {createMarioModules} from '../atlas/editor-mario-modules.mjs';
import {setMarioCarryEnemiesOnPlatforms,mountMarioModulesEditor} from '../atlas/editor-mario-modules-editor.mjs';
import {createCollection,addLevel,parseCollection,serializeCollection,buildCollection,requiredCollectionCapabilities} from '../atlas/editor-collection.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';
import {plantPlatformProject,nativeSession} from './fixtures/npc-platform-native.mjs';
import {character} from './fixtures/shell-coin-native.mjs';
test('strict Boolean opt-in survives copy/import/native pack and supports explicit false or omitted legacy',()=>{
 const d=plantPlatformProject();for(const value of [true,false]){d.rooms[0].marioModules.carryEnemiesOnPlatforms=value;const roomCopy=clone(d.rooms[0]);roomCopy.roomId='copied-room';assert.equal(roomCopy.marioModules.carryEnemiesOnPlatforms,value);const imported=parseProject(JSON.stringify(clone(d)));assert.equal(imported.rooms[0].marioModules.carryEnemiesOnPlatforms,value);assert.equal(createMarioModules(imported.rooms[0]).carriesEnemiesOnPlatforms(),value);assert.equal(createMarioModules(imported.rooms[0]).view().carryEnemiesOnPlatforms,value);nativeSession(imported);}
 delete d.rooms[0].marioModules.carryEnemiesOnPlatforms;assert.equal(createMarioModules(d.rooms[0]).carriesEnemiesOnPlatforms(),false);assert(!Object.hasOwn(createMarioModules(d.rooms[0]).view(),'carryEnemiesOnPlatforms'));
 for(const value of ['true',1,0,null,{},[]]){const bad=clone(d);bad.rooms[0].marioModules.carryEnemiesOnPlatforms=value;assert.throws(()=>parseProject(JSON.stringify(bad)),/carryEnemiesOnPlatforms/);const before=JSON.stringify(d.rooms[0]);assert.throws(()=>setMarioCarryEnemiesOnPlatforms(d.rooms[0],value));assert.equal(JSON.stringify(d.rooms[0]),before);}
});
test('actual module checkbox edits through History, refreshes and preserves native geometry/body on undo/redo',()=>{
 const ui=installSimulatedPlayDom();try{const h=new History(plantPlatformProject({rule:null})),room=()=>h.doc.rooms[0],parent=ui.document.createElement('aside'),reports=[],tool=mountMarioModulesEditor({parent,room,change:fn=>h.change(fn),report:s=>reports.push(s)}),box=parent.querySelector('[data-module-control="carry-enemies-on-platforms"]'),original=clone(room().map);assert.equal(box.checked,false);box.checked=true;box.dispatchEvent({type:'change'});assert.equal(room().marioModules.carryEnemiesOnPlatforms,true);assert.deepEqual(room().map,original);h.undo();tool.refresh();assert.equal(box.checked,false);assert.equal(room().marioModules.carryEnemiesOnPlatforms,undefined);h.redo();tool.refresh();assert.equal(box.checked,true);box.checked=false;box.dispatchEvent({type:'change'});assert.equal(room().marioModules.carryEnemiesOnPlatforms,false);assert.deepEqual(room().map,original);assert.equal(reports.length,0);}finally{ui.restore();}
});
test('collection roundtrip and compilation retain the opt-in and expose its concrete capability',()=>{
 const project=plantPlatformProject(),authored=addLevel(createCollection('Neutral carry collection'),project,{id:'carry-fixture'}),imported=parseCollection(serializeCollection(authored)),runtime=buildCollection(imported,character,{includePending:true});assert.equal(imported.levels[0].project.rooms[0].marioModules.carryEnemiesOnPlatforms,true);assert.equal(runtime.levels[0].rooms[0].marioModules.carryEnemiesOnPlatforms,true);assert(runtime.requiredCapabilities.includes('native-enemy-platform-carry-v1'));assert(runtime.levels[0].requiredCapabilities.includes('native-enemy-platform-carry-v1'));assert.equal(runtime.levels[0].pack.schemaVersion,1);
 for(const rule of [false,null])assert(!requiredCollectionCapabilities(plantPlatformProject({rule})).includes('native-enemy-platform-carry-v1'));
});
