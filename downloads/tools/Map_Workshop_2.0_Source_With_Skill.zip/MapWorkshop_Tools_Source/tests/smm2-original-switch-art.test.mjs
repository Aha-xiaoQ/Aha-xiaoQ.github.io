import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {createCanvas,loadImage} from '@napi-rs/canvas';
import {drawTile} from '../atlas/editor-art.mjs';
import {drawStudyTile,drawStudyWorld} from '../atlas/editor-switch-art.mjs';
import {SMM2_SMB1_SWITCH_SOURCE_PIXELS as sources} from '../atlas/editor-smm2-switch-source-pixels.mjs';
import {SMM2_SOURCE_PIXELS,drawSmm2SourcePixels} from '../atlas/editor-smm2-source-assets.mjs';
import {createSwitchStudy} from '../atlas/editor-switch.mjs';
import {nativeSession} from './fixtures/shell-coin-native.mjs';
import {smb1SwitchArtProject} from './fixtures/smb1-switch-art.mjs';

const data=c=>c.getContext('2d').getImageData(0,0,c.width,c.height).data;
const pixel=(c,x,y)=>[...c.getContext('2d').getImageData(x,y,1,1).data];
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const freeze=q=>{if(q&&typeof q==='object'){for(const value of Object.values(q))freeze(value);Object.freeze(q);}return q;};
const nativeRgba=src=>src.rows.flatMap(row=>[...row].flatMap(index=>{const color=src.palette[parseInt(index,36)];return [1,3,5,7].map(offset=>parseInt(color.slice(offset,offset+2),16));}));
function expectedCell(name){const src=sources[name],canvas=createCanvas(16,16),image=canvas.getContext('2d').createImageData(src.w,src.h);image.data.set(nativeRgba(src));canvas.getContext('2d').putImageData(image,...src.cellOffset);return canvas;}
function frameName(d,on,active){return d.kind==='switch'?(on?'smb1SwitchOn':'smb1SwitchOff'):(d.color==='red'?'smb1RedBlock':'smb1BlueBlock')+((active??(d.color==='red')===on)?'Active':'Inactive');}
function assertWithin(c,q){const bytes=data(c);for(let y=0;y<c.height;y++)for(let x=0;x<c.width;x++)if(bytes[(y*c.width+x)*4+3])assert(x>=q.x&&x<q.x+q.w&&y>=q.y&&y<q.y+q.h,'artwork stays inside actual device bounds');}

test('six original PNG hashes, exact native RGBA and static generic registry retain the unchanged source pixels',async()=>{
 const base=new URL('../atlas/assets/smm2-switch-private/',import.meta.url),ledger=JSON.parse(fs.readFileSync(new URL('SOURCE_ASSETS.json',base))),common=JSON.parse(fs.readFileSync(new URL('../atlas/assets/smm2-private/SOURCE_ASSETS.json',import.meta.url)));
 assert.equal(Object.keys(ledger.assets).length,6);assert.equal(ledger.style,'Super Mario Bros.');assert.equal(ledger.sourceStateEvidence.timingCalibrated,false);assert.match(ledger.phaseLimitation,/no blink clock/);
 for(const [name,entry] of Object.entries(ledger.assets)){
  const src=sources[name],raw=fs.readFileSync(new URL(entry.file,base)),im=await loadImage(raw),canvas=createCanvas(im.width,im.height),generic=createCanvas(im.width,im.height);canvas.getContext('2d').drawImage(im,0,0);
  assert.equal(sha(raw),entry.sha256);assert.equal(raw.length,entry.bytes);assert.equal(sha(data(canvas)),entry.rgbaSha256);assert.deepEqual([...data(canvas)],nativeRgba(src));assert.deepEqual([src.w,src.h],[entry.width,entry.height]);assert.equal(src.sourceSha256,entry.sha256);assert.equal(src.rgbaSha256,entry.rgbaSha256);assert.match(entry.copyright,/Nintendo/);
  assert.equal(SMM2_SOURCE_PIXELS[name],src);assert.equal(common.assets[name].sha256,entry.sha256);assert(drawSmm2SourcePixels(generic.getContext('2d'),name,{x:0,y:0}));assert.deepEqual(data(generic),data(canvas));assert(Object.isFrozen(src)&&Object.isFrozen(src.rows)&&Object.isFrozen(src.palette)&&Object.isFrozen(src.cellOffset));
 }
});

test('both global states and same-ID active/inactive tiles render all six exact source cells without an external shadow',()=>{
 for(const on of [true,false]){
  const room=smb1SwitchArtProject({on}).rooms[0],controller=createSwitchStudy([room],'main'),state=controller.view('main'),live={...room,switchStudyView:state};
  for(const d of state.devices){
   const q={...d,x:8,y:8,w:16,h:16,studyDevice:true},r={...live,switchStudyView:{...state,devices:state.devices.map(other=>other.id===d.id?q:other)}};
   const canvas=createCanvas(40,40),before=JSON.stringify({q,r});drawTile(canvas.getContext('2d'),freeze(q),freeze(r));assertWithin(canvas,q);assert.deepEqual(canvas.getContext('2d').getImageData(8,8,16,16).data,data(expectedCell(frameName(d,on,d.active))));assert.equal(JSON.stringify({q,r}),before);
  }
  const world=createCanvas(384,240),expected=createCanvas(384,240);drawStudyWorld(world.getContext('2d'),{switchStudy:state},room);
  for(const d of state.devices)for(let x=0;x<d.w;x+=16)expected.getContext('2d').drawImage(expectedCell(frameName(d,on,d.active)),d.x+x,d.y);
  assert.deepEqual(data(world),data(expected));
 }
});

test('inactive source stays native 14px with a one-pixel inset, hollow center and clipped partial repeated spans',()=>{
 for(const on of [true,false])for(const color of ['red','blue'])for(const shape of [{w:16,h:16},{w:48,h:32},{w:39,h:27}]){
  const d={id:'renamed-block',kind:'block',color,x:8,y:8,...shape},room={switchStudy:{initialOn:on,devices:[d]}},canvas=createCanvas(72,56),expected=createCanvas(72,56),ctx=expected.getContext('2d');
  assert(drawStudyTile(canvas.getContext('2d'),{...d,studyDevice:true},room));ctx.save();ctx.beginPath();ctx.rect(d.x,d.y,d.w,d.h);ctx.clip();for(let y=0;y<d.h;y+=16)for(let x=0;x<d.w;x+=16)ctx.drawImage(expectedCell(frameName(d,on)),d.x+x,d.y+y);ctx.restore();assert.deepEqual(data(canvas),data(expected));assertWithin(canvas,d);
  if((color==='red')!==on){assert.deepEqual(sources[frameName(d,on)].cellOffset,[1,1]);for(const [x,y]of [[0,0],[15,0],[0,15],[15,15],[7,7],[8,8]])assert.equal(pixel(canvas,d.x+x,d.y+y)[3],0);assert.equal(pixel(canvas,d.x+2,d.y+1)[3],255);}
 }
});

test('live active flag wins over inferred state and an initial-state override changes the source glyph without a clock',()=>{
 const room=smb1SwitchArtProject().rooms[0],d={...room.switchStudy.devices[1],x:8,y:8,w:16,h:16,active:false},r={...room,switchStudyView:{on:true,devices:[d]}},canvas=createCanvas(40,40);drawStudyTile(canvas.getContext('2d'),{...d,studyDevice:true},r);assert.deepEqual(canvas.getContext('2d').getImageData(8,8,16,16).data,data(expectedCell('smb1RedBlockInactive')));
 for(const tick of [0,1,12,99,1000]){const q={id:'changed-switch',kind:'switch',x:8,y:8,w:16,h:16},v={...room,tick,switchStudyView:{on:false,devices:[q]}},c=createCanvas(40,40);drawStudyTile(c.getContext('2d'),{...q,studyDevice:true},v);assert.deepEqual(c.getContext('2d').getImageData(8,8,16,16).data,data(expectedCell('smb1SwitchOff')));}
});

test('SMB3 and other explicit style profiles retain the authored legacy fallback rather than SMB1 source pixels',()=>{
 const q={id:'style-switch',kind:'switch',x:8,y:8,w:16,h:16,studyDevice:true};
 for(const palette of ['smb3-underground','smw-overworld','nsmbu-overworld']){
  const room={smm2Mechanics:{version:1,art:{palette}},switchStudy:{initialOn:true,devices:[q]}},c=createCanvas(40,40);assert(drawStudyTile(c.getContext('2d'),q,room));assert.notDeepEqual(c.getContext('2d').getImageData(8,8,16,16).data,data(expectedCell('smb1SwitchOn')));assert.equal(pixel(c,25,25)[3],255,'unchanged legacy outside shadow identifies authored fallback');
 }
});

test('canvas transforms and the existing bump displacement restore correctly, without rendering mutating native state or events',()=>{
 const room=smb1SwitchArtProject().rooms[0],d={...room.switchStudy.devices[0],x:8,y:24},ctx=createCanvas(48,48).getContext('2d');ctx.translate(3,4);ctx.fillStyle='#123456';ctx.imageSmoothingEnabled=true;const before={transform:ctx.getTransform()};drawStudyWorld(ctx,freeze({switchStudy:{on:true,devices:[d]}}),freeze(room));assert.deepEqual(ctx.getTransform(),before.transform);assert.equal(ctx.imageSmoothingEnabled,true);
 // The raster backend's fillStyle getter caches the last assignment even after
 // restore. Verify the restored real paint, not that stale getter value.
 ctx.fillRect(0,0,1,1);assert.deepEqual([...ctx.getImageData(3,4,1,1).data],[18,52,86,255]);
 for(const bump of [0,1,6,11,12]){const c=createCanvas(48,48),state={on:true,devices:[{...d,bump}]};drawStudyWorld(c.getContext('2d'),{switchStudy:state},room);const y=Math.round(d.y-(bump?Math.sin(bump/12*Math.PI)*6:0));assert.deepEqual(c.getContext('2d').getImageData(d.x,y,16,16).data,data(expectedCell('smb1SwitchOn')));assertWithin(c,{...d,y});}
 const shown=nativeSession(smb1SwitchArtProject()),control=nativeSession(smb1SwitchArtProject());let toggles=0;
 for(let n=0;n<80;n++){const view=shown.step({jump:n>=3&&n<23}),other=control.step({jump:n>=3&&n<23}),before=JSON.stringify(view),c=createCanvas(384,240),r={...shown.doc.rooms[0],switchStudyView:view.switchStudy,playGeometry:view.geometry};for(const q of view.geometry)if(q.studyDevice)drawTile(c.getContext('2d'),q,r);drawStudyWorld(c.getContext('2d'),view,r);assert.equal(JSON.stringify(view),before);assert.deepEqual(view,other);assert.deepEqual(shown.events,control.events);toggles=Math.max(toggles,view.switchStudy.toggles);}
 assert.equal(toggles,1,'ordinary native jump must exercise one real switch contact');
});

test('actual editor preview, standalone module closure, runtime states and native-video raster use the same exact source offline',()=>{
 const run=spawnSync(process.execPath,['--experimental-vm-modules',fileURLToPath(new URL('../scripts/check-original-switch-art-offline.mjs',import.meta.url))],{encoding:'utf8',timeout:30000,maxBuffer:1024*1024});assert.equal(run.status,0,run.stderr||run.stdout||String(run.error));const report=JSON.parse(run.stdout);for(const key of ['actualEditorPreviewExecuted','embeddedArtExecuted','genericStaticRegistryExecuted','nativeVideoRendererExecuted','stateUnchanged'])assert.equal(report[key],true);assert.equal(report.networkRequests,0);assert.equal(report.originalAnimationCalibrated,false);assert(report.rasterScenes>=20);assert.equal(report.moduleCount,report.reachableModuleCount);
});
