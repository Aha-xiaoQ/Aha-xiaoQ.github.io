import fs from 'node:fs';import {test} from 'node:test';import assert from 'node:assert/strict';
import {blank,History,parseProject,runtimeMap,moveSelection,paint,validate} from '../atlas/editor-model.mjs';
import {projectPack} from '../atlas/editor-runtime.mjs';
import {addNativeScenery,updateNativeScenery,setNativeSceneryMode,mountNativeSceneryTools} from '../atlas/editor-native-scenery-tools.mjs';
import {makeNativeScenery,nativeSceneryKey,drawNativeScenery} from '../atlas/editor-native-scenery.mjs';
import {sourcePixels} from '../atlas/source-art.mjs';
import {installSimulatedPlayDom} from './fixtures/simulated-play-dom.mjs';
const character=JSON.parse(fs.readFileSync(new URL('../atlas/runtime/character.json',import.meta.url)));
function project(){const d=blank('Native scenery authoring',640,240),r=d.rooms[0];r.setting='Overworld Night';r.map.geometry=[{id:'floor',x:0,y:208,w:640,h:32,material:'ground',collision:'solid'}];r.map.objects=[{id:'start',kind:'spawn',x:40,y:194,w:10,h:14}];return d;}

test('real scenery panel adds, moves, updates and removes complete decorations with undo/reimport and no gameplay changes',()=>{
 const ui=installSimulatedPlayDom();try{
  const h=new History(project()),parent=ui.document.createElement('aside'),reports=[],room=()=>h.doc.rooms[0],map=runtimeMap(room()),pack=projectPack(h.doc,room().roomId,character,'scenery-test');
  const panel=mountNativeSceneryTools({parent,room,change:fn=>h.change(fn),report:s=>reports.push(s)}),get=id=>parent.querySelector('[data-native-scenery-control="'+id+'"]');
  get('mode').value='authored';get('mode-apply').click();assert.equal(room().nativeSceneryMode,'authored');
  get('palette').value='snow';get('x').value='177';get('y').value='178';get('add').click();const treeId=room().decorations.at(-1).id;assert.equal(room().decorations.at(-1).w,14);assert.equal(nativeSceneryKey(room().decorations.at(-1),room()),'src|Scenery|PlantSmall|Alt|');
  get('type').value='Fence';get('palette').value='native';get('x').value='224';get('y').value='192';get('repeat').value='4';get('add').click();const fenceId=room().decorations.at(-1).id;assert.equal(room().decorations.at(-1).w,64);
  get('x').value='240';get('repeat').value='5';get('apply').click();assert.equal(room().decorations.at(-1).w,80);h.undo();panel.refresh();assert.equal(room().decorations.at(-1).x,224);h.redo();panel.refresh();assert.equal(room().decorations.at(-1).x,240);
  h.change(()=>moveSelection(room(),'decoration',new Set([treeId,fenceId]),16,0));panel.refresh();assert.equal(room().decorations.find(q=>q.id===treeId).x,193);h.undo();panel.refresh();assert.equal(room().decorations.find(q=>q.id===treeId).x,177);h.redo();panel.refresh();
  const before=JSON.stringify(h.doc);get('repeat').value='0';get('apply').click();assert.equal(JSON.stringify(h.doc),before);assert(reports.some(s=>/重复/.test(s)));
  get('remove').click();assert.equal(room().decorations.length,1);h.undo();panel.refresh();assert.equal(room().decorations.length,2);h.redo();panel.refresh();assert.equal(room().decorations.length,1);h.undo();panel.refresh();
  const imported=parseProject(JSON.stringify(h.doc));assert.deepEqual(imported,h.doc);assert.deepEqual(runtimeMap(room()),map);assert.deepEqual(projectPack(imported,room().roomId,character,'scenery-test'),pack);
 }finally{ui.restore();}
});

test('scenery validation prevents collision, cropped sprites, bad modes, duplicate IDs and partial brush damage',()=>{
 const d=project(),r=d.rooms[0],id=addNativeScenery(r,{x:177,y:178,type:'PlantSmall',palette:'snow'}),snapshot=JSON.stringify(r);
 assert.throws(()=>updateNativeScenery(r,id,{x:635}),/超出/);assert.equal(JSON.stringify(r),snapshot);
 assert.throws(()=>addNativeScenery(r,{id:'floor',x:0,y:0,type:'Cloud1'}),/标识/);assert.equal(JSON.stringify(r),snapshot);
 assert.throws(()=>setNativeSceneryMode(r,'invalid'),/模式/);assert.equal(JSON.stringify(r),snapshot);
 assert.throws(()=>paint(r,{x:176,y:176,w:16,h:16},'decoration',{layer:'decoration'}),/完整组件/);assert.equal(JSON.stringify(r),snapshot);
 for(const mutation of [q=>q.collision='solid',q=>q.motion={axis:'x'},q=>q.w=16,q=>q.nativeScenery.palette='white',q=>q.nativeScenery.repeat=2,q=>q.nativeScenery.opacity=.5,q=>q.x=.5]){const copy=structuredClone(d);mutation(copy.rooms[0].decorations[0]);assert.throws(()=>validate(copy));}
 paint(r,{x:176,y:176,w:16,h:16},'decoration',{layer:'decoration',erase:true});assert.equal(r.decorations.length,0,'erase removes the entire component');
});

test('snow uses embedded plant Alt pixels while clouds keep white/blue native pixels and fences keep their exact repeat size',()=>{
 const small=makeNativeScenery({id:'small',type:'PlantSmall',palette:'snow',x:0,y:0}),large=makeNativeScenery({id:'large',type:'PlantLarge',palette:'snow',x:0,y:0}),cloud=makeNativeScenery({id:'cloud',type:'Cloud2',palette:'snow',x:0,y:0}),fence=makeNativeScenery({id:'fence',type:'Fence',repeat:4,x:0,y:0});
 assert.deepEqual([small.w,small.h,large.w,large.h,cloud.w,cloud.h,fence.w,fence.h],[14,30,16,46,48,24,64,16]);
 for(const q of [small,large]){const colors=new Set(sourcePixels(nativeSceneryKey(q)).pixels.map(p=>p.join(',')));assert(colors.has('255,255,255,255'));assert(colors.has('188,188,188,255'));assert(!colors.has('128,208,16,255'));}
 const colors=new Set(sourcePixels(nativeSceneryKey(cloud,{setting:'Overworld Night Alt2'})).pixels.map(p=>p.join(',')));assert(colors.has('60,188,252,255'));assert(!colors.has('216,40,0,255'));
});

test('shared scenery renderer draws behind terrain at Night, honors hidden/camera bounds and suppresses inferred auto scenery only when authored',async()=>{
 const ui=installSimulatedPlayDom();try{
  const {drawScenery,drawTile}=await import('../atlas/editor-art.mjs'),r=project().rooms[0],draws=[];r.decorations=[makeNativeScenery({id:'fence',type:'Fence',x:224,y:192,repeat:4}),makeNativeScenery({id:'cloud',type:'Cloud1',x:440,y:32}),makeNativeScenery({id:'tree',type:'PlantSmall',palette:'snow',x:177,y:178})];
  const c=new Proxy({drawImage:(sprite,x,y)=>draws.push({w:sprite.width,h:sprite.height,x,y})},{get:(t,k)=>t[k]??(()=>{})});
  drawScenery(c,r);assert.deepEqual(draws.map(q=>[q.x,q.y]),[[224,192],[240,192],[256,192],[272,192],[440,32],[177,178]]);
  const count=draws.length;for(const q of r.decorations)drawTile(c,q,r);assert.equal(draws.length,count,'tile pass does not draw the authored scene twice');
  draws.length=0;drawScenery(c,{...r,renderBounds:{x:160,y:0,w:64,h:240}});assert.deepEqual(draws.map(q=>[q.x,q.y]),[[177,178]]);
  draws.length=0;drawNativeScenery(c,{...r.decorations[2],hidden:true},r);assert.equal(draws.length,0);
  draws.length=0;drawScenery(c,{...r,setting:'Overworld',nativeSceneryMode:'authored'});assert.equal(draws.length,count);
  draws.length=0;drawScenery(c,{...r,setting:'Overworld'});assert(draws.length>count,'omitted mode retains original auto scenery');
 }finally{ui.restore();}
});
