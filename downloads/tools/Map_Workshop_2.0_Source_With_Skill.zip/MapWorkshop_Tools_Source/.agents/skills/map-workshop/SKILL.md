---
name: map-workshop
description: 用随附地图工坊创建、编辑和验证 qmap/qcollection，配置已实现的机关，导出独立 HTML，并对齐工具源码升级。用于本包编辑器与运行时工程，不替代其它游戏引擎的工作流。
---

# 马里奥地图工坊 2.0

在工具源码根目录工作；入口是 `atlas/editor.html`，配套版本取 `package.json`，格式和行为以当前实际验证器与消费者为准。地图工程与通用工具包分开保存。

1. 先明确产物：可继续编辑的 `.qmap.json`、多关卡 `.qcollection.json`、可玩独立 HTML，或工具源码修改。已有工程先保留副本，再用真实 parser 导入。
2. 新地图从 `blank` 或中性 `examples/neutral-demo.qmap.json` 开始。用 `History.change` 和现成作者 API 编辑稳定 ID／组件引用；不要把参考图、贴图大小或组件名称当作碰撞或原作参数。
3. 用本 skill 的 CLI 检查完整工程，再编译、导出、回读。HTML 不替代 qmap 备份；只导出基础 native pack 不保留所有机关的作者 sidecar。
4. 试玩实际普通输入和关键失败／重开分支。区分 schema、VM/Canvas/模拟 DOM、真实浏览器、实体手柄／触屏和听辨的证据，报告实际执行范围。

常用命令（从源码根目录）：

```sh
npm ci
npm run build
npm run dev
node .agents/skills/map-workshop/scripts/workshop-project.mjs validate examples/neutral-demo.qmap.json
node .agents/skills/map-workshop/scripts/workshop-project.mjs export examples/neutral-demo.qmap.json --output dist/my-map.html
npm test
```

- 编辑、门户、组件与离线交付：读 [references/authoring-and-export.md](references/authoring-and-export.md)
- JSON 格式、合集认可／修订和编译接口：读 [references/formats-and-api.md](references/formats-and-api.md)
- 特定机关和真实支持边界：读 [references/mechanisms.md](references/mechanisms.md)，再打开对应源码／文档
- 接收另一份工坊、合并和打包：读 [references/upgrades-and-packaging.md](references/upgrades-and-packaging.md)

CLI 只验证与导出，不自动认可合集关卡。`--include-pending` 只用于明确选择的本地待审试玩。缺失原动态或未标定数值要写清；原创配置不能标为原版复刻。只把已合入并在配套工具中验证的能力写成当前支持。
