# 格式与 API

权威 schema 是 JavaScript 验证器，不另造缺失的 JSON Schema：`atlas/editor-model.mjs`、`editor-collection.mjs`、`runtime/stage-catalog.mjs` 和组件 validate…Room。

## qmap 与编译

- 根 format 为 xiaoq-map-project，version:1；id/title/rooms 必须存在，1–128 房间，roomId 唯一
- 每图 tileSize:16；宽256–32768，高120–4096，ceil(width/16)×ceil(height/16)≤262144
- geometry/objects 各≤20000，跨两个数组 ID 不重复；数值有限。markers/decorations 也验证数量／坐标
- parseProject 输入≤12MiB；危险 JSON 键拒绝，组件可选叶使用严格闭合字段集
- skyShooter.enemyFire 若存在须完整保存其11个字段，引用同组已绑定原生敌人，并要求显式 loopingDivers；author helper / History / qmap / qcollection 保留全部配置。完整组复制必须同时重映射 downwardActorIds / diverActorIds，diverAttackY 随 dy 平移，其余射击参数不变；对应集合能力 authored-armed-cloud-enemy-fire-v1。缺省不增加视图或修改旧攻击路径，旧严格 reader 须升级后才能读取新叶
- `projectPack(doc,entryRoom,character,namespace='workshop')` 编译可达房间，并验证全图门户、组合配对、放置与引用
- `developerPack(room,character,namespace,allowSwimming=false)` 是单房基础 ABI；不是完整编辑工程
- pack schemaVersion:1；`createStageCatalog(pack)` 检查，再 `catalog.plan(stageId,characterId,{allowDraft:true})`
- 原生 pack ID 只接受安全小写字母／数字／连字符；namespace 最长48。作者数据的 ID 规则不全同原生规则，报错以实际 parser 为准

`createPlatformMotor()` 和 `createPlatformStage({plan,motor,visualRooms,...})` 处理普通输入。完整组件依赖相匹配的 `editor-mario-stage.mjs` 与 visualRooms，不能丢弃 sidecar 后声称原机制仍完整。

## qcollection 与认可

根 format:xiaoq-map-collection，version:1；最多32关、256房、24MiB。level/collection 稳定 ID 为 `[A-Za-z0-9][A-Za-z0-9_-]{0,71}`；revision 为正安全整数。levels 保存完整 qmap；order 恰好包含每个 level ID 一次；entryRoom 必须存在。

`createCollection(options)` → `addLevel(collection,project,{id,entryRoom})` → `serializeCollection`／`parseCollection`。`addLevel`生成显式`approval.status:"pending"`对象，而不是省略approval字段；确认待审状态时读取status。

`updateLevel` 保留稳定 ID，改变内容递增 revision 并失效旧认可／证据。`reorderLevels` 只换 order，不用索引冒充身份。`buildCollection(collection,character)` 默认仅纳入当前 eligible 关卡；无 eligible 会拒绝。`{includePending:true}` 是明确的本地待审试玩选项，不生成认可。不能因为想让导出成功而自动调用 approveLevel。已有合成测试工厂的认可只针对其本身。

实际项目认可用 `approveLevel(collection,levelId,evidence)` 保留明确内容证据。私人测试纳入另由 editor-collection-policy.mjs 校验原生整通、offline closure 等修订指纹，不能写虚构 passed 或拿另一地图的记录替代。

runtime format:xiaoq-map-collection-runtime，version:1，含独立 namespace 的 packs/rooms 和 requiredCapabilities。门图标与返航分别产生 authored-door-feature-signs-v1、authored-armed-cloud-looping-divers-v1；消费者需实际支持这些能力。progress 使用 editor-collection-progress.mjs 的 createProgress、reconcileProgress、markLevelComplete、resumeBoundary、parse/serializeProgress，按 ID／revision／fingerprint 对齐，不序列化房内世界为跨关 checkpoint。

## 离线

`offlineFile(pack,rooms,read,readAudio,onProgress,options)` 返回 HTML；`read` 相对 atlas/ 读取文本模块，`readAudio(name)` 相对 atlas/assets/classic-audio/ 读取 bytes。合集传 `{collection:buildCollection(...)}`。它嵌入可达运行模块、字体、音频和品牌数据；导航外链本身仍需联网。

使用 `scripts/check-offline-html.mjs` 检查真实 importmap、全部嵌入模块依赖、无未解析本地资源与 pack/rooms bootstrap。VM 闭包与模拟控制不能证明真实浏览器布局、实体硬件或音质。
