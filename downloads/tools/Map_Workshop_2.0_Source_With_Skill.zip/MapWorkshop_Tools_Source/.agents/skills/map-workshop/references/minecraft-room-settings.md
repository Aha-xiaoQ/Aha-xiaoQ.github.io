# 1.11.0 可选 MC 房间设置

默认新图没有 minecraft 字段。基础入口为右侧“MC 冒险 · 可选房间设置”，对应 atlas/editor-minecraft-tools.mjs 的 setMinecraftRoomSettings，必须经 History.change 事务应用。它只负责环境、音乐和 hero 基础配置，不能代替高级场景组件编辑器。

- biome：forest/cave/nether/stronghold/end；已有 storm 等配置会约束环境选择，验证失败不可部分提交。
- musicMode：licensed 为包内有署名的 Dark Reaven Music 替代配乐；local 为用户在当前浏览器选取的本地音频。MC 默认 local；普通房间保留既有默认。不要把替代配乐称为 Minecraft 原声。浏览器本地文件不上传、不随 qmap/HTML 分享。
- hero.alwaysBig 与 hero.maxHealth：可选，房间基础上限1–12，默认3；唯一容量奖励额外累加。进入更低上限房间会钳制当前HP，提高上限不自动治疗。旧无hero行为保持原规则。
- 关闭基础环境时，若有高级机关、场景或引用数据，面板应拒绝操作而不是删除它们；改变基础字段不能覆写未知的有效高级字段。

完整模板：examples/minecraft-adventure/blast-trail.qmap.json。下载入口不会替换当前项目；先保存备份再手动打开。高级苦力怕、轨道、交易、红石乐段和Boss仍需编辑模板数据并测试实际引用、碰撞、普通输入与重开分支。

带MC sidecar的地图不能交付通用基础开发包；用qmap、匹配原生离线HTML或合集。CLI示例：

    node .agents/skills/map-workshop/scripts/workshop-project.mjs validate examples/minecraft-adventure/blast-trail.qmap.json
    node .agents/skills/map-workshop/scripts/workshop-project.mjs export examples/minecraft-adventure/blast-trail.qmap.json --output dist/minecraft.html --audio essential

--audio full 为默认，保留旧音频行为；essential 是显式缩减通用音频集合，仍须核对地图实际用到的声音。输出文件大小不是删除必要资源的理由。
