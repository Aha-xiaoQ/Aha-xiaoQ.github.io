# 可复用组件与支持边界

选择字段前读对应真实 validate…Room 与作者 helper；以下是定位索引，不是允许任意组合的清单。SMM2 mechanics 使用闭合 allowlist；水下／城堡／Bill／rewind 组合限制由 editor-smm2-mechanics.mjs 统一验证。

## 地形、道具与搬运

- SMM2 地形／斜坡／跷跷板／Donut：editor-smm2-terrain.mjs、editor-smm2-authoring.mjs；docs/SMM2_CONTACT_TERRAIN.md、SMM2_THIN_SLOPES.md
- 弹簧、POW载荷、原生挂载支撑：editor-smm2-course-components.mjs、editor-smm2-carriers.mjs；SMM2_WEIGHTED_SPRING.md、SMM2_POW_CARRIERS.md
- 道具、typed Pink、敌人钥匙奖励、P Switch、鞋／骨壳：editor-smm2-items.mjs、editor-smm2-tools.mjs、editor-smm2-bone-tools.mjs；SMM2_ITEMS.md、SMM2_P_SWITCHES.md、SMM2_SHOES.md、SMM2_DRY_BONES.md
- 壳收金币是显式 Boolean shellCoinCollection；使用 set/clearSmm2ShellCoinCollection，默认关，不能把房间政策写成 actor 复制数据
- 搬石／局部风／降落伞／骑云：editor-portable-stones.mjs、editor-local-updrafts.mjs、editor-parachute-actors.mjs、editor-lakitu-clouds.mjs，匹配同名 author tools。素材名不推导重力、飞速或原数值
- 管道供给／单向墙／原生敌人变体／空壳源：editor-mario-modules.mjs、editor-mario-modules-editor.mjs；MARIO_FLOWER_PIPE_SUPPLY.md、SMM2_AUTHORING.md、WALKING_KOOPA_BODY_CONTRACT.md

## 机关图与原创组合

- contraptions 支持轨道、轨道或固定吊爪、音符、飞船、P源、单向墙、尖刺及门。用 editor-contraptions-tools.mjs 的 add/update/removeContraption；关联引用、配对和载荷所有权由实际 validator 检查。高级配置读 CONTRAPTION_TOOLS.md、RAIL_CLAWS.md、CLOWN_CARS.md
- Snake 正式组件在 editor-snake-blocks.mjs 与 editor-snake-block-tools.mjs；放置也经 editor-snake-block-placement.mjs 检查。独立 snake-window-preview.html 是另外的有限实验契约，不能拿它当正式运动、完整NPC／item载荷或原机NSMBU支持
- 原创拴链守卫：editor-chain-chomp-guard.mjs / tools / art；绑定32×32原生 walker、可见桩与链，不是已校准Nintendo汪汪。完整测试为 tests/chain-chomp-guard*.test.mjs；工具投影使用独立中性fixture，不导入私有地图
- Bowser Jr：editor-bowser-jr.mjs / tools；原生HP、真实头踩和得分与可选作者 tempo／attackPattern 分开。连发数字为作者规则，不称原作连发时序。docs/bowser-jr.md
- 看台观众：editor-jr-arena-audience.mjs / editor-jr-arena-tools.mjs；观众显示／护栏等各字段效果以 validator 和 runtime 为准。docs/jr-arena-audience.md
- 原创skyShooter：editor-sky-shooter.mjs / tools / art；用 `setSkyShooter(room,config)` 绑定真实骑云、原生Goomba、实际子弹接触和原生死亡／得分，完成仅隐藏指定实际闸门；Pink仍需真实碰触。不能按经过时间、输入数或敌人消失计击败。完整配置与边界见 docs/sky-shooter.md
- 可选 `skyShooter.loopingDivers`：严格完整对象 `{version:1,actorIds,exitY,reentryY,sideX,exitSpeed,reentrySpeed,returnSpeed,maxActive}`。1–6个已有绑定敌人连续从下方退出、沿左柱返航、上方再入并回原槽位；不能造新敌人或按返回次数计分。仅一波，最多24基础体+6返航体，总数≤30；maxActive为1–2且≤所选数，三种速度均0.5–4px/tick。通道要在房内、位于编队上／下／左边且不穿可见solid，validator检查完整扫过矩形；无此叶保留旧≤24规则。小型完整例子为 tests/fixtures/sky-shooter-loop.mjs 的 `neutralLoopProject()`，它明确设置48tick预警和作者通道参数，不是默认原版值。能力标记 authored-armed-cloud-looping-divers-v1
- 可选严格 `skyShooter.enemyFire`：须已有单轮loopingDivers，完整保存11字段。downwardActorIds逐个垂直向下轮射；diverActorIds下降到diverAttackY后暂停，再显示枪口与瞄准线并一次快照瞄准Mario中心。source/target完整预告锁定；minAimDistance过近跳弹，全部真实敌弹共享maxShots与实际扫掠碰撞/寿命。死亡取消待发预告，已发出的弹继续按碰撞/寿命处理；不新增敌人、不复活或重复计分。无此叶保持旧基础导弹与全部旧视图字段。完整字段、范围、组复制与支持边界见docs/sky-shooter.md；示例位于tests/fixtures/sky-shooter-enemy-fire.mjs及tests/smm2-sky-shooter-enemy-fire.test.mjs。作者36/84tick等不称原作校准；能力标记authored-armed-cloud-enemy-fire-v1
- 投币抓奖机：editor-coin-crane.mjs / tools / art；用实际钱包、付费尝试和奖品接触，不能新增库存捷径。docs/coin-crane.md、coin-crane-cabinet-art.md

## 显示与跨房引用

- direction-arrow：editor-direction-arrow-tools.mjs；原标记与原形适配是显示，不扩大碰撞
- lighting：editor-smm2-lighting-tools.mjs，可选目标稳定ID跟随运行态位置；offRadiusScale要求已存在 switchStudy；光源不能读作者初态冒充运行状态。SMM2_LIGHTING.md
- completionMarks：editor-completion-marks-tools.mjs；每项四字段id/portalId/rewardRoomId/coinId；完整rooms检查真实本房portal与跨房typed Pink。completed仅由Stage真实pinkTaken Set的roomId+换行+coinId身份派生。删除／复制用完整graph helpers；普通单层剪贴板尚不能一键复制跨房绑定。docs/completion-marks.md
- authored scene accents：editor-authored-scene-accents.mjs 的显式smm2Art标签；原创旗／背景图仅显示，不含奖励、碰撞或敌人
- 门图标：从 `editor-door-feature-art.mjs` 调用 `makeDoorFeatureIcon(room,{id,portalId,feature})`，feature只接受crane/snake/shell/shooter/jr。helper返回普通24×24 decoration，需在 `History.change(doc=>{...})` 中自行加入 `room.decorations`；不会修改房间或创建progress绑定。位置是实际portal水平中心、门顶以上50px，即图标底在门顶以上26px，与既有完成徽记留8px间隙。移动门后用helper重新生成并替换旧图标；旧坐标不会动态跟随。严格拒绝未知同族标签、resize、collision/motion/nativeScenery。能力标记 authored-door-feature-signs-v1；完整例子和素材边界见 docs/door-feature-icons.md

## 证据限制

原作素材、截图与声音许可分别查看 ASSET_LICENSES.md 和资产原notice。工具中的原sprite、字体和声音不因此获得额外分发授权。没有实际原动态校准的参数保持作者近似；历史攻略或单张图片不能证明原时序。