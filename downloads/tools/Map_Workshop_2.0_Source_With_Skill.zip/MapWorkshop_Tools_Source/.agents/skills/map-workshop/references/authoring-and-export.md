# 创建、编辑与导出

## 入口与局部修改

`npm ci` 按锁文件安装 Node 22+ 依赖；首次需要联网或已填充的正规 npm cache。`npm run dev` 输出本机随机端口，打开它给出的编辑器地址。不能直接以 file:// 打开模块化编辑器；导出的独立 HTML 则可以双击。

工具包的 `npm run build` 只重建中性 qmap、两关合集和单图／合集 HTML 到 dist。游戏工程可能把 build 指向它自己的关卡工厂；先读 package.json，不借用另一工程的默认命令。

先检查 `atlas/editor-model.mjs` 的 blank、parseProject、validate、History。`History.change(fn)` 的 fn 接收当前完整doc；闭包引用房间时要每次从当前doc重新定位，undo/redo可能替换文档对象。`parseProject(text)` 返回验证后的数据，兼容正规化可能修改载入的数据；保留原文件以便比较。`History.change(fn)` 对整份文档事务回滚，undo/redo 保留全部作者字段。作者 ID、portal 引用、component sidecar 必须一起维护。

`geometry` 是碰撞地形；`objects` 是原生对象；`decorations` 是纯显示；`markers` 的语义由实际消费者决定。示意箭头不是物理体。藏物优先用 `editor-block-content.mjs` 的现有 content/reward 作者 API，参阅 docs/MATERIAL_PLACEMENT_AND_CONTENT.md；不要把独立金币或敌人埋进永久实体。

多房门户保存实际 targetRoom/targetSpawn。在完整 doc 中验证连接图；局部房间 helper 允许的未完成引用不能用于提交完整项目。`projectPack` 只编译从 entryRoom 经 portal 可达的房间；若出口不可达、孤立房间或 arrival 配置错误，先修工程，不在 pack 中伪造目标。

## 可重复的小例子

在根目录创建独立文件，例如 author-neutral.mjs：

```js
import {writeFile} from 'node:fs/promises';
import {blank,History,parseProject,paint} from './atlas/editor-model.mjs';
const history=new History(blank('自己的中性测试关',512,240));
history.change(doc=>{
 doc.id='my-neutral-project';
 const room=doc.rooms[0];
 room.map.geometry=[{id:'floor',x:0,y:224,w:512,h:16,collision:'solid',material:'ground'}];
 room.map.objects=[
  {id:'start',kind:'spawn',x:32,y:210,w:10,h:14},
  {id:'coin',kind:'coin',x:96,y:210,w:10,h:14},
  {id:'finish',kind:'exit',x:400,y:192,w:16,h:32}
 ];
 paint(room,{x:176,y:192,w:32,h:16},'brick');
});
const project=parseProject(JSON.stringify(history.doc));
await writeFile('my-neutral.qmap.json',JSON.stringify(project,null,2)+'\n');
```

```sh
node author-neutral.mjs
node .agents/skills/map-workshop/scripts/workshop-project.mjs validate my-neutral.qmap.json
node .agents/skills/map-workshop/scripts/workshop-project.mjs export my-neutral.qmap.json --entry main --namespace my-neutral --output dist/my-neutral.html
node --experimental-vm-modules scripts/check-offline-runtime.mjs dist/my-neutral.html
```

## 导出与证据

本 skill 的 workshop-project.mjs 支持 validate/export，读取配套真实模块，检查 roundtrip 和 pack catalog。qmap 导出传完整 rooms 以保留 sidecar；collection 导出传 compiled runtime collection。导出报告含源文件、HTML SHA 和真实模块闭包，不表示实际玩家已经通关。

交付可编辑项目、匹配 HTML 和实际需要的 source/验证记录。视频若被请求，必须和冻结地图／源码同版本；新增呈现后重新同步或明确差异。公开发布、授权素材使用和外部共享按用户本次范围处理，打包不意味着发布。

## 音频中断范围