#!/usr/bin/env node
/** Read/validate a paired qmap or qcollection; export through the real workshop.
 * No admission mutations, route/state injection, or implicit project writes. */
import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {fileURLToPath,pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';

const usage=`Usage from the paired tool root:
  node .agents/skills/map-workshop/scripts/workshop-project.mjs validate PROJECT [--root TOOL_ROOT] [--entry ROOM] [--namespace NAME] [--include-pending]
  node .agents/skills/map-workshop/scripts/workshop-project.mjs export PROJECT --output HTML [same options]
Validation compiles and roundtrips; export also verifies embedded module closure.
Collection default uses eligible levels only; --include-pending is local pending-review preview, never an approval.`;
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const args=process.argv.slice(2);
if(!args.length||args.includes('--help')){console.log(usage);process.exit(0);}
try{
 const [command,input,...options]=args;
 if(!['validate','export'].includes(command)||!input||input.startsWith('--'))throw Error(usage);
 const values={};let includePending=false;
 for(let i=0;i<options.length;i++){
  const key=options[i];
  if(key==='--include-pending'){if(includePending)throw Error('Duplicate --include-pending');includePending=true;continue;}
  if(!['--root','--entry','--namespace','--output'].includes(key))throw Error('Unknown option '+key);
  if(Object.hasOwn(values,key)||!options[i+1]||options[i+1].startsWith('--'))throw Error('Missing or duplicate '+key);
  values[key]=options[++i];
 }
 if(command==='export'&&!values['--output'])throw Error('Export requires --output HTML');
 if(command==='validate'&&values['--output'])throw Error('Validate does not write files; use export');
 const root=path.resolve(values['--root']||fileURLToPath(new URL('../../../../',import.meta.url)));
 const module=relative=>import(pathToFileURL(path.join(root,relative)).href);
 const [{parseProject},{parseCollection,serializeCollection,buildCollection},{projectPack},{createStageCatalog},{offlineFile},{inspectOfflineHtml}]=await Promise.all([
  module('atlas/editor-model.mjs'),module('atlas/editor-collection.mjs'),module('atlas/editor-runtime.mjs'),module('atlas/runtime/stage-catalog.mjs'),module('atlas/editor-offline.mjs'),module('scripts/check-offline-html.mjs')
 ]);
 const sourcePath=path.resolve(input),sourceBytes=await fs.readFile(sourcePath),raw=sourceBytes.toString('utf8');
 const envelope=JSON.parse(raw),character=JSON.parse(await fs.readFile(path.join(root,'atlas/runtime/character.json'),'utf8'));
 let doc,pack,rooms,compiledCollection;
 if(envelope.format==='xiaoq-map-project'){
  if(includePending)throw Error('--include-pending only applies to qcollection');
  doc=parseProject(raw);assert.deepEqual(parseProject(JSON.stringify(doc)),doc,'qmap roundtrip');
  const entry=values['--entry']||doc.rooms[0].roomId;
  pack=projectPack(doc,entry,character,values['--namespace']||'workshop-cli');rooms=doc.rooms;
 }else if(envelope.format==='xiaoq-map-collection'){
  if(values['--entry']||values['--namespace'])throw Error('qcollection uses each stored entryRoom and stable generated namespace');
  doc=parseCollection(raw);assert.deepEqual(parseCollection(serializeCollection(doc)),doc,'qcollection roundtrip');
  compiledCollection=buildCollection(doc,character,{includePending});
  for(const level of compiledCollection.levels)createStageCatalog(level.pack);
  pack=compiledCollection.levels[0].pack;rooms=compiledCollection.levels.flatMap(level=>level.rooms);
 }else throw Error('Expected qmap or qcollection authoring format; runtime pack is not an editable project');
 createStageCatalog(pack);
 const version=JSON.parse(await fs.readFile(path.join(root,'package.json'),'utf8')).version;
 const report={command,toolVersion:version,format:doc.format,version:doc.version,input:path.relative(process.cwd(),sourcePath)||path.basename(sourcePath),sourceSha256:sha(sourceBytes),roundtrip:true,compiled:true,authoringRooms:compiledCollection?doc.levels.reduce((n,l)=>n+l.project.rooms.length,0):doc.rooms.length,runtimeMaps:compiledCollection?compiledCollection.levels.reduce((n,l)=>n+l.pack.maps.length,0):pack.maps.length};
 if(compiledCollection){report.includedLevels=compiledCollection.order;report.pendingReviewPreview=includePending;report.requiredCapabilities=compiledCollection.requiredCapabilities;}
 else{report.entryRoom=pack.stages[0].entryRoom;report.unreachableRooms=doc.rooms.filter(r=>!Object.hasOwn(pack.stages[0].rooms,r.roomId)).map(r=>r.roomId);}
 if(command==='export'){
  const read=relative=>fs.readFile(path.join(root,'atlas',relative),'utf8');
  const readAudio=name=>fs.readFile(path.join(root,'atlas/assets/classic-audio',name));
  const html=await offlineFile(pack,rooms,read,readAudio,()=>{},compiledCollection?{collection:compiledCollection}:{});
  const checked=inspectOfflineHtml(html,{collection:!!compiledCollection});
  const output=path.resolve(values['--output']);
  if(output===sourcePath)throw Error('HTML output must differ from input authoring file');
  await fs.mkdir(path.dirname(output),{recursive:true});await fs.writeFile(output,html);
  Object.assign(report,{output:path.relative(process.cwd(),output)||path.basename(output),outputBytes:Buffer.byteLength(html),outputSha256:sha(html),embeddedModules:checked.moduleCount,reachableModules:checked.reachableModuleCount,offlineClosure:true});
 }
 console.log(JSON.stringify(report,null,2));
}catch(error){console.error(error.message);process.exitCode=1;}
