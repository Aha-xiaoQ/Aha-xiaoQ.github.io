# 可选 MC 冒险模板

此处 blast-trail.qmap.json 是完整可编辑工程，复制自已验证的 R12 冒险。先保存自己的工程，再在工坊选择“打开工程”。它不会自动安装到默认新地图。

该模板包含森林村庄、黏液/蜂蜜洞、矿轨与铁傀儡、下界、红石音乐与末地战斗；高级配置保存在各房间 minecraft 字段内。1.11.0 基础面板仅覆盖环境、音乐与初始英雄设置，复杂机关仍按作者数据编辑。改变实体 ID 或引用时必须重新验证和试玩。

在工具根目录运行：

    npm run map:validate -- examples/minecraft-adventure/blast-trail.qmap.json
    npm run map:export -- examples/minecraft-adventure/blast-trail.qmap.json --output dist/minecraft-adventure.html --audio essential

标准源码包已包含全部代码、图片与音频，解压后即可使用。离线导出含匹配媒体；用户临时导入的音频不会上传或自动打包。

音乐署名见 ../../docs/MINECRAFT_MUSIC_CREDITS.md。MECHANIC-FIDELITY-R12.md 说明原作依据与跨作品改编。README-R12.md 为原关卡的历史说明；其中历史交付文件名与外部目录不代表本工坊包缺少必要文件。

evidence 中 JSON 是用于原生输入重放/测试的固定证据，不是交互教学。录制默认 1920×1080。旧样例原始输入不等于真实浏览器或实体手柄测试。
