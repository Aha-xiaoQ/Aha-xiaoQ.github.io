# R12 mechanics and adaptation record

## Original rules retained

- Creeper proximity starts a visible fuse; loss of sight or escape beyond a larger distance cancels it. The two authored demolition encounters use a safe distance band beyond the 64 px blast but inside the 96 px cancellation radius. Explosion cover is checked against intact pre-blast geometry.
- Unsupported sand actually falls. A torch breaks falling sand into item entities; it does not melt stationary sand. Items physically reach the hopper, fuel and sand are consumed by a furnace, and glass is produced.
- Redstone pressure plates/repeaters power both note blocks and a separate mechanism branch. Note blocks do not generate the circuit. Dirt, stone, sand and gold under the blocks select distinct sounds; all84 audible onsets match their visible bank pulses exactly.
- Ghast orange fireballs can be returned by actual contact. Slime rebound depends on fall height and crouching suppresses it. Honey slows movement/jumps and permits sticky sliding.
- Enderman direct face gaze provokes a warning; looking away after sustained gaze starts pursuit. Walls block gaze, a genuinely low shelter excludes its tall body, thrown tridents cause evasion.
- Loyalty retrieves the thrown trident. Channeling requires an actual mob hit, Overworld thunderstorm and sky access; no rain or natural lightning occurs in the Nether or End.
- End crystals heal the Dragon; destroying them stops that healing. Dragon flight, charge, purple fireballs, central fountain perch and lingering purple ground clouds are represented. Perched projectiles are rejected; Mario head-stomps remain possible.

## Deliberate crossover adaptations

The original Mario motor and original project Mario art remain unchanged. This is an authored2D crossover, not a port of Java or Bedrock combat values.

- Hero starts big with3 full hearts. Three physical exploration rewards and one finite merchant reward expand this map’s capacity to7, without a hardcoded global six-heart ceiling; half-heart damage and nine lives are different counters. Earned capacity persists across deaths but resets with a new game.
- Directional shield stamina, eight-tick perfect timing, five-frame hitstop, buffered release/repress and the reflected purple projectile are crossover rules. Ordinary front blocking takes half damage; perfect blocking takes none; rear hits and persistent breath are not prevented. Original Minecraft shields can block Creeper explosions; this game uses its unified half-damage/precise-parry rule rather than claiming exact vanilla shield balance.
- Charge parry briefly deflects the airborne Dragon into a96-tick reachable head opening. A single actual critical stomp deals3 HP; ordinary perched stomps deal2. No automatic damage is awarded for parrying. Three encounter phases,12 boss HP are authored balance values.
- Breath clouds last5 seconds with24-tick warning, limited area/capacity and repeat-damage cooldown. These shortened timings keep this compact arena fair; the official entity sample's duration120 is seconds, not120 game frames. Clouds survive ordinary phase/perch transitions and clear only at defeat/reset.
- A defeated required demolition Creeper can reappear after180ticks at its original clear spawn while the wall is intact. Occupied/blocked spawns defer. This explicit puzzle-recovery behavior prevents a weapon-induced softlock; it is not an exact natural mob-spawning simulation.
- Geode coins/heart capacity, gold-trim heart containers, coin-funded villager healing, accelerated furnace time, mechanized glass bridge assembly, Ghast HP and Mario jump fireball returns are adapted interactions. Vanilla villager currency is emeralds, not Mario coins.
- Enderman gaze uses a readable stationary face cone in2D,42-tick dwell, teleport cues and grace. It does not claim exact3D crosshair/edition thresholds.

## Primary references

- Creeper behavior: https://learn.microsoft.com/en-us/minecraft/creator/reference/source/vanillabehaviorpack_snippets/entities/creeper?view=minecraft-bedrock-stable
- Dragon fireball cloud: https://learn.microsoft.com/en-us/minecraft/creator/reference/source/vanillabehaviorpack_snippets/entities/dragon_fireball?view=minecraft-bedrock-stable
- Projectile duration/reapplication units: https://learn.microsoft.com/en-us/minecraft/creator/reference/content/entityreference/examples/entitycomponents/minecraftcomponent_projectile
- Dragon combat: https://www.minecraft.net/en-us/article/ender-dragon
- Shield tutorial text, howtoplay.armor.text.6: https://github.com/Mojang/bedrock-samples/blob/main/resource_pack/texts/en_US.lang
- Torch falling-sand interaction: https://www.minecraft.net/en-us/article/taking-inventory-torch
- Note blocks: https://www.minecraft.net/en-us/article/block-week-note-block
- Enderman: https://www.minecraft.net/it-it/article/enderman
- Trident/Loyalty: https://www.minecraft.net/en-us/article/taking-inventory--trident
- Channeling sky/thunderstorm requirement: https://learn.microsoft.com/en-us/minecraft/creator/scriptapi/minecraft/server/entityprojectilecomponent?view=minecraft-bedrock-stable#lightningstrikeonhit

## Validation boundary

Evidence uses the actual native Stage, original motor, ordinary input tapes, shared playable Canvas art, synthesized game effects and licensed music recordings. Offline HTML modules are executed under a simulated DOM without network. Event timing, PCM generation and decoded audio/video are checked. Real-browser fullscreen/device audio, physical controllers/touch hardware and human playtesting/listening are not claimed.
