import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createContext,SourceTextModule} from 'node:vm';
import {createCanvas} from '@napi-rs/canvas';
import {offlineFile} from '../atlas/editor-offline.mjs';
import {inspectOfflineHtml} from './check-offline-html.mjs';
import {drawTile} from '../atlas/editor-art.mjs';
import {drawStudyWorld} from '../atlas/editor-switch-art.mjs';
import {SMM2_SMB1_SWITCH_SOURCE_PIXELS as sources} from '../atlas/editor-smm2-switch-source-pixels.mjs';
import {SMM2_SOURCE_PIXELS,drawSmm2SourcePixels} from '../atlas/editor-smm2-source-assets.mjs';
import {smb1SwitchArtProject} from '../tests/fixtures/smb1-switch-art.mjs';
import {nativeSession} from '../tests/fixtures/shell-coin-native.mjs';
import {mountPlacementEditor} from '../tests/fixtures/placement-editor-dom.mjs';
import {nativeWorld} from '../render-lantern-course-native-canvas.mjs';

const root=new URL('../atlas/',import.meta.url),doc=smb1SwitchArtProject();
const html=await offlineFile({stages:[{title:'Neutral SMB1 switch source rendering'}]},doc.rooms,p=>fs.readFile(new URL(p,root),'utf8'),p=>fs.readFile(new URL('assets/classic-audio/'+p,root)));
const checked=inspectOfflineHtml(html);let networkRequests=0,rasterScenes=0;
assert.equal(checked.moduleCount,checked.reachableModuleCount);assert(checked.modules.has('workshop/editor-smm2-switch-source-pixels.mjs'));
const context=createContext({console,URL,TextEncoder,TextDecoder,Uint8Array,Uint8ClampedArray,structuredClone,fetch(){networkRequests++;throw Error('Original switch art must remain offline');}}),modules=new Map();
for(const [id,text] of checked.modules)modules.set(id,new SourceTextModule(text,{context,identifier:id}));
const art=modules.get('workshop/editor-art.mjs');await art.link(id=>{assert(modules.has(id),'closed module '+id);return modules.get(id);});await art.evaluate();
const embedded=modules.get('workshop/editor-smm2-switch-source-pixels.mjs').namespace.SMM2_SMB1_SWITCH_SOURCE_PIXELS;
assert.deepEqual(JSON.parse(JSON.stringify(embedded)),sources);
const bytes=c=>c.getContext('2d').getImageData(0,0,c.width,c.height).data;
const generic=modules.get('workshop/editor-smm2-source-assets.mjs').namespace,study=modules.get('workshop/editor-switch-art.mjs').namespace;
for(const [name,source] of Object.entries(sources)){
 const local=createCanvas(source.w,source.h),offline=createCanvas(source.w,source.h);assert.equal(SMM2_SOURCE_PIXELS[name],source);assert.equal(generic.SMM2_SOURCE_PIXELS[name],embedded[name]);
 assert(drawSmm2SourcePixels(local.getContext('2d'),name,{x:0,y:0}));assert(generic.drawSmm2SourcePixels(offline.getContext('2d'),name,{x:0,y:0}));assert.deepEqual(bytes(local),bytes(offline));assert.equal(createHash('sha256').update(bytes(offline)).digest('hex'),source.rgbaSha256);rasterScenes++;
}
const stateNames=new Set();
for(const on of [true,false]){
 const session=nativeSession(smb1SwitchArtProject({on}));
 for(let frame=0;frame<24;frame++){
  const view=session.step({jump:frame>=3&&frame<19}),room={...session.doc.rooms[0],switchStudyView:view.switchStudy,playGeometry:view.geometry},before=JSON.stringify(view),local=createCanvas(384,240),offline=createCanvas(384,240);
  for(const q of view.geometry)if(q.studyDevice){drawTile(local.getContext('2d'),q,room);art.namespace.drawTile(offline.getContext('2d'),q,room);}
  drawStudyWorld(local.getContext('2d'),view,room);study.drawStudyWorld(offline.getContext('2d'),view,room);assert.deepEqual(bytes(local),bytes(offline));
  for(const d of view.switchStudy.devices)stateNames.add(d.kind==='switch'?(view.switchStudy.on?'ON':'OFF'):d.color+'-'+(d.active?'active':'inactive'));
  const camera={x:0,y:0,w:384,h:240},actual=nativeWorld(view,session.doc,{camera,showPlayer:false,scale:2}).canvas,
   without={...view,geometry:view.geometry.filter(q=>!q.studyDevice),switchStudy:{...view.switchStudy,devices:[]}},expected=nativeWorld(without,session.doc,{camera,showPlayer:false,scale:2}).canvas,ctx=expected.getContext('2d');
  ctx.save();ctx.scale(2,2);for(const q of view.geometry)if(q.studyDevice)drawTile(ctx,{...q,y:q.y-(q.bump?Math.sin(q.bump/12*Math.PI)*6:0)},room);drawStudyWorld(ctx,view,room);ctx.restore();
  for(const d of view.switchStudy.devices){const bump=d.bump?Math.sin(d.bump/12*Math.PI)*6:0,x=d.x*2,y=Math.round(d.y-bump)*2,w=d.w*2,h=d.h*2;assert.deepEqual(actual.getContext('2d').getImageData(x,y,w,h).data,expected.getContext('2d').getImageData(x,y,w,h).data,'native video device '+d.id);}
  assert.equal(JSON.stringify(view),before);rasterScenes++;
 }
}
assert.equal(stateNames.size,6,'all six original state identities were rasterized');
// Initialize native classic Canvas caches before the actual simulated editor.
for(const on of [true,false]){
 const project=smb1SwitchArtProject({on}),room=project.rooms[0],editor=await mountPlacementEditor(project);
 try{
  const actual=editor.$('canvas').raster,expected=createCanvas(384,240),ctx=expected.getContext('2d');ctx.fillStyle='#8287fd';ctx.fillRect(0,0,384,240);drawStudyWorld(ctx,{},room);
  for(const d of room.switchStudy.devices)assert.deepEqual(actual.getContext('2d').getImageData(d.x,d.y,d.w,d.h).data,expected.getContext('2d').getImageData(d.x,d.y,d.w,d.h).data,'actual editor state '+d.id);
  assert.deepEqual(editor.document(),project);rasterScenes++;
 }finally{editor.restore();}
}
assert.equal(networkRequests,0);
console.log(JSON.stringify({actualEditorPreviewExecuted:true,embeddedArtExecuted:true,genericStaticRegistryExecuted:true,nativeVideoRendererExecuted:true,stateUnchanged:true,nativeStates:[...stateNames],rasterScenes,moduleCount:checked.moduleCount,reachableModuleCount:checked.reachableModuleCount,networkRequests,originalAnimationCalibrated:false,sourceRgbaSha256:Object.fromEntries(Object.entries(sources).map(([name,source])=>[name,source.rgbaSha256]))}));
