// Neutral native movement evidence. No recorded course or live state edits.
import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {createCanvas} from '@napi-rs/canvas';
import {blank,validate} from '../atlas/editor-model.mjs';
import {createPlatformStage} from '../atlas/editor-mario-stage.mjs';
import {createPlatformMotor} from '../atlas/editor-mario-motor.mjs';
import {drawSmm2DryBones,SMM2_DRY_BONES_GAIT_ROWS,smm2DryBonesVisualPose} from '../atlas/editor-smm2-bone-art.mjs';
import {drawSmm2SourcePixels} from '../atlas/editor-smm2-source-assets.mjs';

const out=path.resolve(process.argv[2]||'validation/dry-bones-walk-art'),assets=new URL('../atlas/assets/smm2-private/',import.meta.url);
await fs.mkdir(path.join(out,'frames'),{recursive:true});
const source=await fs.readFile(new URL('smm1-smb1-dry-bones-standing.png',assets));
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
function canvas(w,h){const c=createCanvas(w,h),ctx=c.getContext('2d');ctx.fillStyle='#202030';ctx.fillRect(0,0,w,h);ctx.imageSmoothingEnabled=false;return c;}
function label(ctx,text,x,y,size=17){ctx.fillStyle='#e0e0ec';ctx.font=`${size}px sans-serif`;ctx.fillText(text,x,y);}
const q=(frame=0,scale=1)=>({type:'dry-bones',x:(32+2*frame)*scale,y:64-24*scale,w:16*scale,h:24*scale,vx:-.5,facing:-1,grounded:true,smm2DryBones:{phase:'walking',size:scale===2?'giant':'normal'}});
function drawCell(ctx,actor,x,bottom,zoom=4,{before=false,tick=0}={}){
 ctx.save();ctx.translate(x-Math.round(actor.x)*zoom,bottom-Math.round(actor.y+actor.h)*zoom);ctx.scale(zoom,zoom);
 if(before)drawSmm2SourcePixels(ctx,'dryBonesStanding',{x:actor.x,y:actor.y+actor.h-23*actor.w/16,scale:actor.w/16,mirror:actor.facing>0});else drawSmm2DryBones(ctx,actor,{tick});ctx.restore();
}
const board=canvas(960,760),b=board.getContext('2d');label(b,'Dry Bones: original family, previous renderer and repaired gait',20,27,21);label(b,'Original walking frames were NOT obtained; new limb poses are an authored adaptation',20,53,16);
for(let i=0;i<4;i++)label(b,'Pose '+i,300+i*155,80);
label(b,'SMM1 source standing',20,120);label(b,'One verified 16 x 23 pose',20,143,14);drawCell(b,q(),310,182,4,{before:true});
label(b,'Before: moving / frozen feet',20,227);for(let i=0;i<4;i++)drawCell(b,q(i),310+i*155,298,4,{before:true});
label(b,'After: actual stride poses',20,343);for(let i=0;i<4;i++)drawCell(b,q(i),310+i*155,414,4);
label(b,'Big: the same pixels at 2x',20,474);for(let i=0;i<4;i++)drawCell(b,q(i,2),310+i*155,587,3);
const states=[['Stopped',{...q(1),vx:0}],['Airborne',{...q(1),grounded:false,vy:1}],['Collapsed',{...q(1),y:56,h:8,vx:0,smm2DryBones:{phase:'collapsed'}}],['Recovering',{...q(1),y:56,h:8,vx:0,smm2DryBones:{phase:'recovering'}}]];
for(let i=0;i<states.length;i++){label(b,states[i][0],300+i*155,622);drawCell(b,states[i][1],310+i*155,736,4,{tick:4});}
await fs.writeFile(path.join(out,'DRY_BONES_WALK_BEFORE_AFTER_BOARD.png'),board.toBuffer('image/png'));
const sheet=createCanvas(64,23),sh=sheet.getContext('2d');for(let i=0;i<4;i++)drawCell(sh,q(i),i*16,23,1);
const sheetFile='dry-bones-authored-walk-4x16x23.png',sheetBytes=sheet.toBuffer('image/png');await fs.writeFile(new URL(sheetFile,assets),sheetBytes);

const d=blank('Neutral native Dry Bones walk art proof',640,240),r=d.rooms[0];r.setting='Castle';r.map.geometry=[{id:'floor',x:0,y:176,w:640,h:64,collision:'solid',material:'castle'}];r.map.objects=[{id:'start',kind:'spawn',x:32,y:162,w:10,h:14},{id:'bones',kind:'walker',x:208,y:152,w:16,h:24}];r.smm2Mechanics={version:1};r.marioModules={version:1,itemSources:[],noteBlocks:[],oneWayWalls:[],enemyVariants:{bones:{kind:'dry-bones',size:'normal',speed:.5,direction:-1,collapsedHeight:8,collapseFrames:12,recoverFrames:4,bounceSpeed:4}}};validate(d);
const stage=createPlatformStage({plan:{stage:{entryRoom:r.roomId,entrySpawn:'start',title:d.title},character:{capabilities:['jump'],motion:{width:10,height:14,maxHealth:1}},rooms:{[r.roomId]:r.map}},motor:createPlatformMotor(),visualRooms:d.rooms,initialState:{lives:3},allowWarp:false,autoContinue:false,emit:()=>{}}),trace=[],poses=new Set();
for(let f=0;f<80;f++){
 stage.step({});const v=stage.view(),a=v.enemies.find(e=>e.id==='bones'),before=JSON.stringify(v),pose=smm2DryBonesVisualPose(a);poses.add(pose.frame);
 const c=canvas(760,340),ctx=c.getContext('2d');label(ctx,'Same native movement, before / after art repair',20,27,21);label(ctx,`tick ${v.tick} / x ${a.x.toFixed(1)} / vx ${a.vx} / grounded ${a.grounded}`,20,52,16);
 label(ctx,'BEFORE',20,114);label(ctx,'AFTER',20,254);ctx.fillStyle='#555568';ctx.fillRect(135,176,590,3);ctx.fillRect(135,316,590,3);
 const x=500+(a.x-208)*4;drawCell(ctx,a,x,176,4,{before:true});drawCell(ctx,a,x,316,4,{tick:v.tick});
 if(JSON.stringify(v)!==before)throw Error('Drawing changed a native view');
 await fs.writeFile(path.join(out,'frames',String(f).padStart(3,'0')+'.png'),c.toBuffer('image/png'));
 trace.push({tick:v.tick,x:a.x,y:a.y,w:a.w,h:a.h,vx:a.vx,vy:a.vy,grounded:a.grounded,phase:a.smm2DryBones.phase,visualPose:pose});
}
if(poses.size!==4)throw Error('Native stepping did not show all four gait poses');
execFileSync('ffmpeg',['-y','-hide_banner','-loglevel','error','-framerate','60','-i',path.join(out,'frames','%03d.png'),'-filter_complex','split[a][b];[a]palettegen[p];[b][p]paletteuse','-loop','0',path.join(out,'DRY_BONES_NATIVE_WALK_BEFORE_AFTER.gif')]);
const provenance={schemaVersion:1,date:'2026-10-05',privateOnly:true,asset:sheetFile,sha256:hash(sheetBytes),width:64,height:23,frameSize:{w:16,h:23},frameCount:4,originalWalkingAnimationObtained:false,source:{file:'smm1-smb1-dry-bones-standing.png',sha256:hash(source),game:'Super Mario Maker (SMB1 family)',filePage:'https://www.mariowiki.com/File:SMM-SMB-DryBones.png',directAsset:'https://mario.wiki.gallery/images/a/a0/SMM-SMB-DryBones.png',verifiedPixelsViewed:true},boundedResearch:[{url:'https://www.mariowiki.com/Gallery:Dry_Bones',result:'Public family supplies standing and pile PNGs; no SMB1 Dry Bones walking sequence in that gallery'},{url:'https://www.mariowiki.com/Gallery:Super_Mario_Maker_2',result:'Shell assets and screenshot references; no walking enemy animation acquired'},{url:'https://www.spriters-resource.com/nintendo_switch/supermariomaker2/',result:'Public page returned 403; this route stopped'}],adaptation:{method:'Source standing contact pose plus three independently adapted limb poses. Alternating soles lift and land; passing poses nod the source face one pixel. Airborne feet tuck separately.',drivingFields:['type','smm2DryBones.phase','grounded','vx','x','w','facing'],quarterStrideSourcePixels:2,cycleSourcePixels:8,clock:'No independent timer; source-space x displacement chooses gait phase. Existing tick is only read for recovery shake.',nearestBigScale:2,bottomAnchor:'All grounded live poses use actor.y + actor.h; no body mutation',limits:'Not a verified Nintendo walking rip. Exact SMM2 frame timing, stride length and phase transitions have not been calibrated.'},rights:'Derived Nintendo game artwork, private learning only; not MIT or an open-content asset. Authored animation adaptation does not expand underlying artwork rights.',evidence:{board:'DRY_BONES_WALK_BEFORE_AFTER_BOARD.png',gif:'DRY_BONES_NATIVE_WALK_BEFORE_AFTER.gif',nativeTicks:80,ordinaryInput:{},nativeDistinctGaitPoses:poses.size,stateMutation:false,trace:'DRY_BONES_NATIVE_WALK_TRACE.json'}};
await fs.writeFile(new URL('dry-bones-authored-walk.provenance.json',assets),JSON.stringify(provenance,null,2)+'\n');await fs.writeFile(path.join(out,'DRY_BONES_NATIVE_WALK_TRACE.json'),JSON.stringify(trace,null,2)+'\n');
console.log(JSON.stringify({out,asset:sheetFile,frames:trace.length,distinctGaitPoses:poses.size,sourceWalkAcquired:false}));
