/** Shared playable art, explicit render-pose specimens; not an input-route proof. */
import fs from 'node:fs';import {createHash} from 'node:crypto';import {createCanvas} from '@napi-rs/canvas';
import {drawMinecraftWorld,drawMinecraftHud,drawMinecraftForeground} from '../atlas/editor-minecraft-art.mjs';
import {drawFinaleWorld} from '../atlas/editor-minecraft-finale-art.mjs';
const out=new URL('../examples/minecraft-adventure/evidence/r10-materials/',import.meta.url);fs.mkdirSync(out,{recursive:true});
const sheet=createCanvas(1152,1080),ctx=sheet.getContext('2d');ctx.fillStyle='#18212c';ctx.fillRect(0,0,sheet.width,sheet.height);ctx.imageSmoothingEnabled=false;ctx.font='17px sans-serif';
const base={minecraft:{version:1,biome:'forest'},map:{width:128,height:80,geometry:[],objects:[]}},times=[0,12,24,36];
for(const [row,tick]of times.entries())for(const [col,mode]of ['outgoing','returning','chest-drop'].entries()){
 const c=createCanvas(128,80),g=c.getContext('2d');g.fillStyle='#23313c';g.fillRect(0,0,128,80);
 if(mode==='chest-drop')drawFinaleWorld(g,{...base,minecraft:{version:1,biome:'nether'},tick},{nether:{bastion:{reward:{x:51,y:52,w:16,h:16,opened:true,openAge:18,item:{x:52,y:24,w:18,h:8,state:'falling',age:tick}}}}});
 else drawMinecraftWorld(g,{...base,tick},{gear:{loyaltyTrident:true,stands:[],effects:[],projectiles:[{kind:'loyalty-trident',x:58,y:38,w:16,h:5,angle:-.37,state:mode==='outgoing'?'flying':'returning',age:tick}]}});
 ctx.fillStyle='#e2dcd0';ctx.fillText(`${mode} | tick ${tick}`,col*384+16,row*270+22);ctx.drawImage(c,col*384,row*270+30,384,240);
}
fs.writeFileSync(new URL('trident-diagonal-glint-poses.png',out),sheet.toBuffer('image/png'));
const hud=createCanvas(1024,720),h=hud.getContext('2d');h.imageSmoothingEnabled=false;h.fillStyle='#18212c';h.fillRect(0,0,1024,720);h.font='18px sans-serif';
for(const [i,cap]of [3,4,5,6].entries()){h.fillStyle='#e9dac2';h.fillText(`${cap} hearts, live capacity / separate dragon status`,24,i*142+24);h.save();h.translate(0,i*142+32);h.scale(4,4);drawMinecraftHud(h,{health:cap-.5,maxHealth:cap,healthUpgradePulse:50,lives:9,coins:8,minecraft:{dragon:{hp:6,maxHp:6,phase:2}}},{...base,minecraft:{version:1,biome:'end',hero:{maxHealth:3},dragon:{}},tick:31},()=>{});h.restore();}
for(const [i,collected]of [false,true].entries()){h.save();h.translate(100+i*320,640);h.scale(4,4);drawMinecraftWorld(h,{...base,tick:31},{capacityRewards:[{kind:'heart-container',x:0,y:0,w:12,h:12,collected,age:10}]});h.restore();}
fs.writeFileSync(new URL('six-heart-capacity-hud.png',out),hud.toBuffer('image/png'));
fs.writeFileSync(new URL('glint-capacity-proof.json',out),JSON.stringify({renderer:'Actual shared playable Canvas art modules, @napi-rs/canvas',source:'Explicit renderer-only pose fixtures. No ordinary-input gameplay claim.',realBrowser:false,sourceHashes:Object.fromEntries(['atlas/editor-minecraft-art.mjs','atlas/editor-minecraft-finale-art.mjs','atlas/editor-minecraft-enchantment-art.mjs'].map(file=>[file,createHash('sha256').update(fs.readFileSync(file)).digest('hex')])),images:['trident-diagonal-glint-poses.png','six-heart-capacity-hud.png'],glint:'Purple diagonal pixel bands clipped to exact shaft, crossbar and three prongs after the same item rotation, with alpha preserved.',hud:'Live maxHealth up to six, half-heart precision; dragon bar starts at x180 after heart panel ends at x171.'},null,2));
// Native ordinary-input starter swing, alongside the explicitly labelled sheets.
{
 const {nativeSession}=await import('../tests/fixtures/shell-coin-native.mjs'),{nativeWorld}=await import('../render-lantern-course-native-canvas.mjs'),doc=JSON.parse(fs.readFileSync(new URL('../examples/minecraft-adventure/blast-trail.qmap.json',import.meta.url))),session=nativeSession(doc),shots=[];session.frames(24);
 for(const [label,frames,input]of [['idle',0,{}],['windup',1,{attack:true}],['swing',4,{}],['recover',5,{}],['empty-hand',15,{}]]){session.frames(frames,input);const view=session.view(),frame=nativeWorld(view,doc,{camera:{x:0,y:0,w:569,h:320},scale:2}),file=`native-starter-sword-${label}.png`;fs.writeFileSync(new URL(file,out),frame.canvas.toBuffer('image/png'));shots.push({file,tick:view.tick,sword:view.minecraft.gear.sword,primary:view.minecraft.gear.primary});}
 fs.writeFileSync(new URL('starter-sword-native-proof.json',out),JSON.stringify({source:'Actual native stage at main spawn, ordinary idle/attack/release inputs, no state injection',realBrowser:false,shots,inputs:session.inputs},null,2));
}
