// Regenerable neutral pixel evidence from shared renderer and native play.
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createCanvas} from '@napi-rs/canvas';
import {lightingProject,assertNativeLightingMotion} from '../tests/fixtures/lighting-native.mjs';
import {renderLightingPlayPair} from '../tests/fixtures/lighting-render-dom.mjs';
import {drawSmm2LightingMask,resolveSmm2LightSources} from '../atlas/editor-smm2-lighting.mjs';
import {offlineFile} from '../atlas/editor-offline.mjs';
import {projectPack} from '../atlas/editor-runtime.mjs';
import {createCollection,addLevel,approveLevel,buildCollection} from '../atlas/editor-collection.mjs';
import {character} from '../tests/fixtures/shell-coin-native.mjs';

const output=path.resolve(process.argv[2]??'provenance/lighting-neutral-evidence');fs.mkdirSync(output,{recursive:true});
const doc=lightingProject({setting:'Overworld'});doc.rooms[0].playRules.viewportWidth=512;doc.rooms[0].playRules.viewportHeight=288;
const pair=await renderLightingPlayPair({doc}),sheet=createCanvas(pair.off.canvas.width*2,pair.off.canvas.height+64),s=sheet.getContext('2d');s.fillStyle='#111827';s.fillRect(0,0,sheet.width,sheet.height);s.fillStyle='#ffffff';s.font='20px sans-serif';s.fillText('NEUTRAL NATIVE PLAY / LIGHTING OFF',24,28);s.fillText('EXPLICIT LIGHTING / HUD AFTER MASK',pair.off.canvas.width+24,28);s.font='14px sans-serif';s.fillText('Authored approximations. Synthetic fixture. No original-course calibration.',24,50);s.drawImage(pair.off.canvas,0,64);s.drawImage(pair.dark.canvas,pair.off.canvas.width,64);
const circles=createCanvas(768,432),c=circles.getContext('2d');c.fillStyle='#111827';c.fillRect(0,0,768,432);c.fillStyle='#fff';c.font='18px sans-serif';c.fillText('Shared output-coordinate mask: camera translation, hard / soft edges',16,28);const samples=[];
for(const [i,softness]of [0,.25,.5].entries()){
 const image=createCanvas(256,256),ctx=image.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,256,256);const room={roomId:'neutral-circle',map:{width:256,height:256,geometry:[],objects:[]},smm2Mechanics:{version:1,lighting:{darkness:1,playerRadius:40,softness,sources:[]}}};drawSmm2LightingMask(ctx,room,{roomId:room.roomId,p:{x:91,y:89,w:10,h:14}},{camera:{x:32,y:32,width:128,height:128},width:256,height:256,createCanvas});c.drawImage(image,i*256,64);c.fillStyle='#fff';c.font='16px sans-serif';c.fillText('softness '+softness,i*256+16,352);samples.push({softness,center:[...ctx.getImageData(128,128,1,1).data],penumbra:[...ctx.getImageData(188,128,1,1).data],outside:[...ctx.getImageData(220,128,1,1).data]});
}
c.fillStyle='#fff';c.font='14px sans-serif';c.fillText('White input pixels; world center (96, 96); camera origin (32, 32); output scale 2x',16,400);
const native=assertNativeLightingMotion(lightingProject(),{resolve:resolveSmm2LightSources});delete native.trace;
const mask=pair.dark.calls.findLastIndex(q=>q.kind==='image'&&q.sourceWidth===pair.dark.canvas.width&&q.sourceHeight===pair.dark.canvas.height&&q.args.length===4),hud=pair.dark.calls.findIndex((q,i)=>i>mask&&q.kind==='rect'&&['#fff','#ffffff'].includes(q.fill)&&q.y>=20&&q.y<=60);
const files=[['neutral-native-lighting.png',sheet.toBuffer('image/png')],['neutral-circle-pixels.png',circles.toBuffer('image/png')],['neutral-lighting.qmap.json',Buffer.from(JSON.stringify(doc,null,2)+'\n')]];
const manifest=[];for(const [name,bytes]of files){fs.writeFileSync(path.join(output,name),bytes);manifest.push({file:name,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')});}
const offline=[],temp=fs.mkdtempSync(path.join(os.tmpdir(),'Neutral Lighting Evidence ')),root=new URL('../atlas/',import.meta.url),pack=projectPack(doc,doc.rooms[0].roomId,character,'neutral-lighting-evidence');
try{
 const projectPath=path.join(temp,'neutral fixture.qmap.json');fs.writeFileSync(projectPath,JSON.stringify(doc));
 for(const collection of [false,true]){
  const built=collection?buildCollection(approveLevel(addLevel(createCollection('Neutral lighting evidence collection'),doc,{id:'lights'}),'lights','Synthetic neutral fixture approval for automated QA only'),character):null,html=await offlineFile(pack,doc.rooms,p=>fs.promises.readFile(new URL(p,root),'utf8'),p=>fs.promises.readFile(new URL('assets/classic-audio/'+p,root)),()=>{},collection?{collection:built}:{}),htmlPath=path.join(temp,collection?'collection.html':'single.html');fs.writeFileSync(htmlPath,html);
  const result=spawnSync(process.execPath,['--experimental-vm-modules',fileURLToPath(new URL('./check-lighting-offline.mjs',import.meta.url)),htmlPath,projectPath,...(collection?['collection']:[])],{encoding:'utf8',timeout:45000,maxBuffer:1024*1024});assert.equal(result.status,0,result.stderr||result.stdout||String(result.error));const report=JSON.parse(result.stdout),name=collection?'offline-collection-report.json':'offline-single-report.json',bytes=Buffer.from(JSON.stringify({...report,htmlSha256:createHash('sha256').update(html).digest('hex')},null,2)+'\n');fs.writeFileSync(path.join(output,name),bytes);manifest.push({file:name,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')});offline.push(report);
 }
}finally{fs.rmSync(temp,{recursive:true,force:true});}
const sourceFiles=['editor-smm2-lighting.mjs','editor-smm2-lighting-tools.mjs','editor-smm2-authoring.mjs','editor-smm2-mechanics.mjs','editor-model.mjs','editor-play.mjs','editor-offline.mjs','editor-collection.mjs','editor-mario-stage.mjs','editor-mario-motor.mjs'].map(name=>{const bytes=fs.readFileSync(new URL(name,root));return {file:'atlas/'+name,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')};});
const report={kind:'synthetic-neutral',parameters:'authored approximations',actualNativePlayRendered:true,maskBeforeHud:mask>=0&&hud>mask,nativePlayTick:pair.dark.view.tick,pixelSamples:samples,nativeMotion:native,offline,originalTimingCalibrated:false,story43Verified:false,customLogoIncluded:pair.customLogoIncluded,browserLayoutVerified:pair.browserLayoutVerified,sourceFiles,files:manifest};fs.writeFileSync(path.join(output,'REPORT.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({output,testsCovered:'synthetic neutral, no original-course calibration',offline,files:manifest}));
