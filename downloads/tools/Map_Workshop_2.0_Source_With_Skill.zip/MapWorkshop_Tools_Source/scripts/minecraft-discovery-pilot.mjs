import{createGrottoPilot}from'./minecraft-grotto-pilot.mjs';
import{createPilot}from'./minecraft-pilot.mjs';
export function createDiscoveryPilot({verbose=false}={}){const base=createPilot(),grotto=createGrottoPilot();let frame=-1;let mode='apple',age=0,jump=0,lastMode='',cartJumped=false,giftJump=false,springJump=false;
const aim=(p,x)=>Math.abs(x-p.x)<1.3&&Math.abs(p.vx)<.15?0:Math.sign(x-p.x-p.vx*7);
const pilot=v=>{const i=++frame;let p=v.p,e=v.minecraft?.exploration||{},input=base(v);if(mode!==lastMode){if(verbose)console.log(i,'MODE',mode,v.roomId,p.x,p.y);lastMode=mode;age=0;}age++;
 if(mode==='apple'&&e.apple?.state==='carried')mode='pig';
 if(mode==='pig'){input={x:aim(p,594)};if(e.pig?.gateOpen)mode='door';}
 if(mode==='door'){input={x:1,interact:true};if(v.roomId==='burrow')mode='grotto';}
 if(mode==='grotto'){input=grotto(v);if(v.roomId==='main')mode='forest';}
 if(mode==='forest'&&v.roomId==='cave')mode='cart-board';
 if(mode==='cart-board'){input={x:aim(p,142)};if(p.x>82&&p.grounded&&jump<=0){jump=40;cartJumped=true;}if(jump-->0)input.jump=true;if(p.support==='mc-wood-minecart')mode='cart-ride';}
 if(mode==='cart-ride'){input={x:0};if(p.x>330){mode='cart-jump';jump=38;}}
 if(mode==='cart-jump'){input={x:1,jump:jump-->0};if(p.support==='mc-wood-cart-bonus'||p.x>420)mode='cart-bonus';}
 if(mode==='cart-bonus'){input={x:1};if(p.x>430)mode='cave';}
 if(mode==='cave'){input=base(v);if(p.x>1280&&v.roomId==='cave')mode='ores';}
 if(mode==='ores'){const q=e.ores?.find(o=>!o.used);if(q){input={x:aim(p,q.x+3)};if(Math.abs(p.x-q.x-3)<3&&p.grounded&&jump<=-8)jump=27;if(jump-->0)input.jump=true;}else mode='bridge';}
 if(mode==='bridge'){input=e.redstone?.progress<1?{x:aim(p,1408)}:base(v);if(p.x>1744)mode='finish-cave';} if(mode==='finish-cave'){input=base(v);if(v.roomId==='nether')mode='end';}
return input;};pilot.mode=()=>mode;return pilot;}
