import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {createCanvas} from '@napi-rs/canvas';
import {nativeSession} from '../tests/fixtures/shell-coin-native.mjs';
import {nativeWorld} from '../render-lantern-course-native-canvas.mjs';
import {drawMinecraftWorld,drawMinecraftForeground,minecraftVillagerArtPlan} from '../atlas/editor-minecraft-art.mjs';
const root=new URL('../examples/minecraft-adventure/',import.meta.url),out=new URL('evidence/',root),doc=JSON.parse(fs.readFileSync(new URL('blast-trail.qmap.json',root))),inputs=JSON.parse(fs.readFileSync(new URL('ranged-inputs.json',out)));
fs.mkdirSync(out,{recursive:true});
const shots=[],voices=[],seen=new Set(),save=(name,s,camera,source)=>{const v=s.view(),frame=nativeWorld(v,doc,{camera,scale:2}),file='r9-villager-'+name+'.png';fs.writeFileSync(new URL(file,out),frame.canvas.toBuffer('image/png'));shots.push({file,room:v.roomId,tick:v.tick,player:v.p,actors:minecraftVillagerArtPlan(doc.rooms.find(r=>r.roomId===v.roomId),v.minecraft),source});frame.canvas.width=1;};
// The established ordinary-input adventure prefix remains useful evidence for
// individual village encounters; this script makes no whole-route finish claim.
{
 const s=nativeSession(doc);let cursor=0;
 for(const input of inputs){s.step(input);const fresh=s.events.slice(cursor);cursor=s.events.length;for(const e of fresh.filter(e=>e.type==='sound'&&/^mc-villager/.test(e.event))){voices.push({...e,source:'ordinary recorded route prefix'});if(e.context==='channeling-rescue')save('home-channeling-rescue',s,{x:0,y:0,w:512,h:320},'Actual full-route home arrival and real Channeling defeat; the resident gives one local relieved response');if(e.actorId&&!seen.has(e.actorId)){seen.add(e.actorId);const v=s.view(),x=e.actorId==='upper-mine-worker'?1136:e.actorId==='village-resident'?800:280;save(e.actorId,s,{x,y:0,w:512,h:320},'Actual native stage, ordinary recorded movement/jump/action input, no state injection');}}if(s.view().p.dead)break;}
}
// A focused native rail ride makes the flower exchange easy to inspect.
{
 const d=structuredClone(doc),i=d.rooms.findIndex(r=>r.roomId==='cave'),[r]=d.rooms.splice(i,1);d.rooms.unshift(r);const s=nativeSession(d);let riding=false,jump=0,offered=false,received=false;
 for(let frame=0;frame<1100;frame++){const p=s.view().p;if(p.support==='mc-wood-minecart')riding=true;const input={};if(!riding){input.x=Math.abs(142-p.x)<1.3&&Math.abs(p.vx)<.15?0:Math.sign(142-p.x-p.vx*7);if(p.x>82&&p.grounded&&jump<=0)jump=40;if(jump-->0)input.jump=true;}s.step(input);const e=s.view().minecraft.exploration;if(e.golem.rose&&!offered){offered=true;save('poppy-offer',s,{x:320,y:32,w:512,h:320},'Actual native room entry, ordinary run/jump onto cart followed by idle riding');}if(e.golem.poppyGiven&&!received){received=true;s.frames(60);save('poppy-received',s,{x:320,y:32,w:512,h:320},'Actual native cart ride, live golem-to-villager transfer, no state injection');}if(received){s.frames(90);break;}}
 assert(offered&&received);voices.push(...s.events.filter(e=>e.type==='sound'&&/^mc-villager/.test(e.event)).map(e=>({...e,source:'ordinary focused cart ride'})));
}
// The home resident is independently exercised with normal walking; no final
// boss success or inherited-inventory claim is implied by this room entry.
{
 const d=structuredClone(doc),i=d.rooms.findIndex(r=>r.roomId==='home'),[r]=d.rooms.splice(i,1);d.rooms.unshift(r);const s=nativeSession(d);let captured=false;
 for(let n=0;n<180;n++){s.step({x:1});const e=s.events.find(e=>e.type==='sound'&&e.actorId==='home-resident');if(e){captured=true;voices.push({...e,source:'ordinary focused home walk'});save('home-resident-nearby',s,{x:0,y:0,w:512,h:320},'Actual native home room entry and ordinary walking, no inherited weapon or boss-result claim');break;}}assert(captured);
}
const sheet=createCanvas(1120,400),ctx=sheet.getContext('2d');ctx.fillStyle='#23343a';ctx.fillRect(0,0,1120,400);ctx.imageSmoothingEnabled=false;
for(const [i,pose]of [{state:'idle',facing:1},{state:'idle',facing:1,speakTicks:24},{state:'react',facing:-1,speakTicks:24},{state:'celebrate',facing:1,poppy:true}].entries()){
 ctx.save();ctx.translate(36+i*190,24);ctx.scale(4,4);drawMinecraftWorld(ctx,{minecraft:{version:1,biome:'forest'},tick:21,map:{width:100,height:100,geometry:[]}},{exploration:{villagers:[{id:'pose',x:16,y:16,w:16,h:24,age:20,...pose}]}});ctx.restore();ctx.fillStyle='#e8e4cf';ctx.font='16px sans-serif';ctx.fillText(['idle','greet / mouth','contact / head shake','poppy received'][i],42+i*190,228);
}
for(const [i,remaining]of [10,1].entries()){ctx.save();ctx.translate(815+i*145,44);ctx.scale(4,4);drawMinecraftForeground(ctx,{minecraft:{version:1,biome:'forest'}},{p:{x:16,y:16,w:14,h:28,facing:1},minecraft:{gear:{loyaltyTrident:true,guard:{active:false},projectiles:[],windup:{total:10,remaining,facing:1,angle:0}}}});ctx.restore();ctx.fillStyle='#e8e4cf';ctx.fillText(remaining===10?'windup start':'windup ready',820+i*145,228);}
ctx.fillStyle='#aab9ac';ctx.font='15px sans-serif';ctx.fillText('Renderer-only pose comparison. Native gameplay evidence is in the separate named screenshots.',36,350);
fs.writeFileSync(new URL('r9-villager-windup-art-states.png',out),sheet.toBuffer('image/png'));
const actors=doc.rooms.flatMap(r=>[r.minecraft?.exploration?.villager,...(r.minecraft?.exploration?.villagers||[])].filter(Boolean).map(q=>({room:r.roomId,...q}))),voiced=new Set(voices.map(v=>v.actorId));assert(actors.every(q=>voiced.has(q.id)),'Every drawn actor must speak in ordinary native input evidence');
const report={source:'R9 isolated source; no published-site or R8 edits',actors,ordinaryInputVoiceCoverage:[...voiced],voices,shots,artSheet:{file:'r9-villager-windup-art-states.png',source:'Renderer-only explicit pose fixtures'},realBrowser:false,rendering:'Native @napi-rs/canvas using actual shared playable art',noGeometryChanges:true,limits:'This focused proof verifies villager encounters and flower interaction. It does not claim full R9-route completion or human listening.',sha256:Object.fromEntries(['editor-minecraft.mjs','editor-minecraft-art.mjs'].map(n=>[n,crypto.createHash('sha256').update(fs.readFileSync(new URL('../atlas/'+n,import.meta.url))).digest('hex')]))};
fs.writeFileSync(new URL('r9-villager-proof-report.json',out),JSON.stringify(report,null,2));console.log(JSON.stringify({actors:actors.length,voiced:[...voiced],shots:shots.map(q=>q.file)},null,2));
