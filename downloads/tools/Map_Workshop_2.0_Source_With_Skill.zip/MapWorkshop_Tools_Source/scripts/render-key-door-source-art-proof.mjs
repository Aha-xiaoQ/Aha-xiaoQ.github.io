import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {createCanvas,loadImage} from '@napi-rs/canvas';
import {drawKey,drawDoor} from '../atlas/editor-contraptions-art.mjs';
import {smb1KeyDoorArtProject,runKeyDoorArtFixture} from '../tests/fixtures/smb1-key-door-art.mjs';
import {mountPlacementEditor} from '../tests/fixtures/placement-editor-dom.mjs';
import {nativeWorld} from '../render-lantern-course-native-canvas.mjs';

const out=path.resolve(process.argv[2]||'validation/key-door-source-art');await fs.mkdir(out,{recursive:true});
const ledger=JSON.parse(await fs.readFile(new URL('../atlas/assets/smm1-key-door-private/SOURCE_ASSETS.json',import.meta.url),'utf8')),sourceDir=new URL('../atlas/assets/smm1-key-door-private/',import.meta.url);
const original={};for(const [name,e]of Object.entries(ledger.assets))original[name]=await loadImage(await fs.readFile(new URL(e.file,sourceDir)));
const fallback={smm2Mechanics:{version:1,art:{palette:'unverified-style'}}};
const board=createCanvas(1000,900),ctx=board.getContext('2d');ctx.imageSmoothingEnabled=false;ctx.fillStyle='#20232c';ctx.fillRect(0,0,1000,900);ctx.fillStyle='#fff';ctx.font='20px StudySans';ctx.fillText('SMB1 key / explicitly unlocked door source artwork',24,32);ctx.font='14px StudySans';for(const [text,x]of [['Unchanged original PNG',280],['Retained legacy artwork',530],['Current native SMB1',780]])ctx.fillText(text,x,64);
const rows=[['Native key 16px cell','smb1Key',drawKey,{w:16,h:16}],['Unlocked key door','smb1UnlockedDoor',drawDoor,{w:16,h:32,style:'key',unlocked:true}],['Live plain return (true)','smb1UnlockedDoor',drawDoor,{w:16,h:32,style:'plain',unlocked:true}],['Authored plain (no flag)',null,drawDoor,{w:16,h:32,style:'plain'}],['Locked red legacy',null,drawDoor,{w:16,h:32,style:'key',locked:true}]];
for(const [index,[label,name,draw,o]]of rows.entries()){
 const y=80+index*144;ctx.fillStyle='#fff';ctx.fillText(label,24,y+38);const tiles=[];
 for(const type of ['source','prior','actual']){const im=createCanvas(20,34),c=im.getContext('2d');if(type==='source'){if(name)c.drawImage(original[name],name==='smb1Key'?1:0,0);}else draw(c,{x:0,y:0,...o},type==='prior'?fallback:{});tiles.push(im);if(type!=='source'||name)await fs.writeFile(path.join(out,`row-${index+1}-${type}.png`),im.toBuffer('image/png'));}
 for(const [i,x]of [280,530,780].entries()){ctx.fillStyle='#12151c';ctx.fillRect(x,y,80,136);if(i===0&&!name){ctx.fillStyle='#aaa';ctx.fillText('Not supplied',x,y+48);}else ctx.drawImage(tiles[i],x,y,80,136);}
}
ctx.fillStyle='#fff';ctx.fillText('Native 14 x 16 right-tooth key; unchanged loose 14 x 14 collider. Source door only for explicit true.',24,820);ctx.fillText('SMM1 SMB1 static PNGs checked against finite SMM2 frames; no SMM2 rip or original dynamics claim.',24,844);ctx.fillText('Authored plain / locked and other styles retain legacy art. No original red PNG or regular panel-door replacement.',24,868);
await fs.writeFile(path.join(out,'SMB1_KEY_DOOR_SOURCE_AND_RENDERER_BOARD.png'),board.toBuffer('image/png'));
const doc=smb1KeyDoorArtProject(),selected=new Set([8,20,21,160,180]),frames=[],trace=[],writes=[];
const session=runKeyDoorArtFixture({onFrame(view,s){trace.push({frame:s.inputs.length,roomId:view.roomId,player:view.p,items:view.items,keys:view.contraptions.keys,doors:view.contraptions.doors,score:view.score,coins:view.coins});if(!selected.has(s.inputs.length))return;const file='NATIVE_KEY_DOOR_FRAME_'+String(s.inputs.length).padStart(3,'0')+'.png',canvas=nativeWorld(view,doc,{camera:{x:0,y:0,w:384,h:240},scale:2}).canvas;frames.push({file,frame:s.inputs.length,roomId:view.roomId,keys:view.contraptions.keys});writes.push(fs.writeFile(path.join(out,file),canvas.toBuffer('image/png')));}});
// Wait for every selected frame before the artifact receipt is constructed.
await Promise.all(writes);
const contacts=createCanvas(1000,840),c=contacts.getContext('2d');c.fillStyle='#20232c';c.fillRect(0,0,1000,840);c.imageSmoothingEnabled=false;c.fillStyle='#fff';c.font='20px StudySans';c.fillText('Actual native Stage / motor: ordinary jump, movement and Up input',24,30);
for(const [i,f]of frames.entries()){const im=await loadImage(await fs.readFile(path.join(out,f.file))),x=24+(i%2)*488,y=62+Math.floor(i/2)*246;c.drawImage(im,x,y,460,230);c.fillStyle='#fff';c.font='14px StudySans';c.fillText(`Frame ${f.frame}: ${f.roomId}, inventory ${f.keys}`,x,y+244);}
await fs.writeFile(path.join(out,'SMB1_KEY_DOOR_NATIVE_CONTACT_BOARD.png'),contacts.toBuffer('image/png'));
doc.activeRoomId='return';const editor=await mountPlacementEditor(doc);try{await fs.writeFile(path.join(out,'SMB1_UNLOCKED_DOOR_ACTUAL_EDITOR.png'),editor.$('canvas').raster.toBuffer('image/png'));}finally{editor.restore();}
await fs.writeFile(path.join(out,'SMB1_KEY_DOOR_NATIVE_TRACE.json'),JSON.stringify({inputs:session.inputs,trace,events:session.events},null,2)+'\n');
const report={generatedAt:new Date().toISOString(),sourceVersion:JSON.parse(await fs.readFile(new URL('../package.json',import.meta.url),'utf8')).version,kind:'original-smm1-smb1-key-door-art-proof',sourceAssets:ledger.assets,ordinaryNativeInputFrames:session.inputs.length,keyCollectedFrame:session.events.find(e=>e.event==='key-collected').frame,doorUnlockedFrame:session.events.find(e=>e.event==='door-unlocked').frame,selectedFrames:frames,physicalColliderChanged:false,newWorldOwnedKeyIcon:false,originalAnimationCalibrated:false,physicalBrowserTested:false,artifactFiles:[]};
for(const name of (await fs.readdir(out)).filter(n=>n.endsWith('.png')||n.endsWith('_TRACE.json'))){const raw=await fs.readFile(path.join(out,name));report.artifactFiles.push({file:name,bytes:raw.length,sha256:createHash('sha256').update(raw).digest('hex')});}
await fs.writeFile(path.join(out,'SMB1_KEY_DOOR_ART_PROOF.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({out,ordinaryNativeInputFrames:session.inputs.length,keyCollectedFrame:report.keyCollectedFrame,doorUnlockedFrame:report.doorUnlockedFrame}));
