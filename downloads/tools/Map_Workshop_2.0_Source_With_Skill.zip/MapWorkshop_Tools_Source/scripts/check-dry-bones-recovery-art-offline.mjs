// Renderer-only neutral acceptance. No course, control input or controller edit.
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createContext,SourceTextModule} from 'node:vm';
import {createCanvas} from '@napi-rs/canvas';
import {inspectOfflineHtml} from './check-offline-html.mjs';
import {nativeWorld} from '../render-lantern-course-native-canvas.mjs';
import {drawObject} from '../atlas/editor-art.mjs';
import {drawSmm2SourcePixels} from '../atlas/editor-smm2-source-assets.mjs';

const checked=inspectOfflineHtml(fs.readFileSync(process.argv[2],'utf8'));let networkRequests=0,rasterScenes=0;
const context=createContext({console,URL,TextEncoder,TextDecoder,Uint8Array,Uint8ClampedArray,structuredClone,Image:globalThis.Image,document:globalThis.document,fetch(){networkRequests++;throw Error('Recovery art must remain offline');}}),modules=new Map();
for(const [id,source]of checked.modules)modules.set(id,new SourceTextModule(source,{context,identifier:id}));
const link=id=>{assert(modules.has(id),'Missing embedded module '+id);return modules.get(id);},art=modules.get('workshop/editor-art.mjs');await art.link(link);await art.evaluate();
const freeze=q=>{if(q&&typeof q==='object'){for(const value of Object.values(q))freeze(value);Object.freeze(q);}return q;};
const bytes=c=>c.getContext('2d').getImageData(0,0,c.width,c.height).data;
const room=freeze({roomId:'main',setting:'Castle',map:{width:384,height:216,geometry:[],objects:[]},markers:[],decorations:[],nativeSceneryMode:'authored',smm2Mechanics:{version:1}}),doc=freeze({rooms:[room]}),camera={x:0,y:0,w:384,h:216};
for(const size of [1,2])for(const facing of [-1,1])for(const tick of [0,3,4,7,8,11,12,15,16,20,24,28]){
 const actor=freeze({id:'bones',kind:'walker',type:'dry-bones',x:96.25,y:160-8*size,w:16*size,h:8*size,vx:0,facing,smm2DryBones:{phase:'recovering',size:size===2?'giant':'normal',remainingFrames:0}}),before=JSON.stringify({actor,doc});
 const local=createCanvas(384,216),embedded=createCanvas(384,216);drawObject(local.getContext('2d'),actor,tick,room);art.namespace.drawObject(embedded.getContext('2d'),actor,tick,room);assert.deepEqual(bytes(embedded),bytes(local),'actual embedded HTML drawObject matches editor art');
 const view=freeze({roomId:'main',tick,p:{x:0,y:0,w:10,h:14},geometry:[],objects:[],enemies:[actor],items:[],vines:[],coins:0,score:0,timeLeft:300,lives:3}),stateBefore=JSON.stringify(view),native=nativeWorld(view,doc,{camera,showPlayer:false,scale:2}).canvas,expected=nativeWorld({...view,enemies:[]},doc,{camera,showPlayer:false,scale:2}).canvas;
 const ctx=expected.getContext('2d');ctx.save();ctx.scale(2,2);drawSmm2SourcePixels(ctx,'dryBonesPile',{x:actor.x-2.5*size+[0,1,0,-1][Math.floor(tick/4)%4]*size,y:actor.y+actor.h-8*size,scale:size,mirror:facing>0});ctx.restore();
 assert.deepEqual(bytes(native),bytes(expected),'actual native video bridge paints exactly one whole pile, with no rider');assert.equal(JSON.stringify(view),stateBefore);assert.equal(JSON.stringify({actor,doc}),before);rasterScenes++;
}
assert.equal(networkRequests,0);console.log(JSON.stringify({embeddedArtExecuted:true,nativeVideoRendererExecuted:true,authoredStateUnchanged:true,rasterScenes,moduleCount:checked.moduleCount,networkRequests,originalRecoveryAnimationObtained:false}));
