import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createContext,SourceTextModule,runInContext} from 'node:vm';
import {createCanvas} from '@napi-rs/canvas';
import {inspectOfflineHtml} from './check-offline-html.mjs';
import {nativeSession} from '../tests/fixtures/shell-coin-native.mjs';
import {bowserJrProject,threeNativeJrStomps} from '../tests/fixtures/bowser-jr-native.mjs';
import {drawObject as localDraw} from '../atlas/editor-art.mjs';
const [htmlFile,projectFile,collectionMode]=process.argv.slice(2);if(!htmlFile||!projectFile)throw Error('Usage: node --experimental-vm-modules scripts/check-bowser-jr-offline.mjs HTML QMAP [collection]');
const checked=inspectOfflineHtml(fs.readFileSync(htmlFile,'utf8'),{collection:collectionMode==='collection'}),project=JSON.parse(fs.readFileSync(projectFile,'utf8'));let networkRequests=0;
const context=createContext({console,URL,TextEncoder,TextDecoder,Uint8Array,Uint8ClampedArray,structuredClone,crypto:globalThis.crypto,atob,btoa,document:{createElement:tag=>{assert.equal(tag,'canvas');return createCanvas(1,1);}},fetch(){networkRequests++;throw Error('Offline Jr cannot use network');}}),modules=new Map();
for(const [id,source]of checked.modules)modules.set(id,new SourceTextModule(source,{context,identifier:id}));
const link=id=>{assert(modules.has(id),'Missing embedded '+id);return modules.get(id);},stage=modules.get('workshop/editor-mario-stage.mjs'),motor=modules.get('workshop/editor-mario-motor.mjs'),art=modules.get('workshop/editor-art.mjs');
for(const root of [stage,motor,art]){if(root.status==='unlinked')await root.link(link);if(root.status!=='evaluated')await root.evaluate();}
const EmbeddedStage=options=>{context.stageData=JSON.stringify({...options,motor:undefined,emit:undefined});return stage.namespace.createPlatformStage({...runInContext('JSON.parse(stageData)',context),motor:options.motor,emit:options.emit});};
const normalize=q=>JSON.parse(JSON.stringify(q));
const route=nativeSession(project);threeNativeJrStomps(route);route.until(v=>v.contraptions.keys===1,{},180);
const native=nativeSession(project),embedded=nativeSession(project,{Stage:EmbeddedStage,Motor:motor.namespace.createPlatformMotor});assert.deepEqual(normalize(embedded.view()),normalize(native.view()));
let rasterScenes=0;
function sameRaster(actor,room){const a=createCanvas(48,48),b=createCanvas(48,48),q={...actor,x:8,y:8};localDraw(a.getContext('2d'),q,0,room);art.namespace.drawObject(b.getContext('2d'),q,0,room);assert.deepEqual(b.getContext('2d').getImageData(0,0,48,48).data,a.getContext('2d').getImageData(0,0,48,48).data);rasterScenes++;}
sameRaster(project.rooms[0].map.objects.find(q=>q.id==='junior'),project.rooms[0]);
const phases=new Set();for(const input of route.inputs){const a=native.step(input),b=embedded.step(input);assert.deepEqual(normalize(b),normalize(a));const jr=a.enemies.find(q=>q.id==='junior');if(jr&&!phases.has(jr.smm2BowserJr.phase)){phases.add(jr.smm2BowserJr.phase);sameRaster(jr,project.rooms[0]);}const death=a.items.find(i=>i.kind==='enemy-death'&&i.id==='junior');if(death&&!phases.has('defeated')){phases.add('defeated');sameRaster(death,project.rooms[0]);}}
assert.deepEqual(normalize(embedded.events),normalize(native.events));assert.equal(embedded.view().score,4000);assert.equal(embedded.view().contraptions.keys,1);
// Exercise the same embedded controller's ordinary early shot in addition to
// the isolated stomp route. This is a separate explicit author fixture.
const firingProject=bowserJrProject({fireDelay:2,spawn:{x:60,y:120}}),rule=firingProject.rooms[0].smm2Mechanics.bowserJuniors.actors[0];rule.fireWindupFrames=2;rule.fireIntervalFrames=12;const firingLocal=nativeSession(firingProject),firingEmbedded=nativeSession(firingProject,{Stage:EmbeddedStage,Motor:motor.namespace.createPlatformMotor});
for(let n=0;n<10;n++){const a=firingLocal.step({}),b=firingEmbedded.step({});assert.deepEqual(normalize(b),normalize(a));const pose=a.enemies.find(e=>e.smm2BowserJr?.phase==='firing');if(pose&&!phases.has('firing')){phases.add('firing');sameRaster(pose,firingProject.rooms[0]);}const fire=a.enemies.find(e=>e.type==='bowser-jr-fireball');if(fire&&!phases.has('fireball')){phases.add('fireball');sameRaster(fire,firingProject.rooms[0]);}}
assert.equal(networkRequests,0);assert.equal(firingEmbedded.events.filter(e=>e.event==='fireball').length,1);
console.log(JSON.stringify({kind:'synthetic-neutral',moduleCount:checked.moduleCount,reachableModuleCount:checked.reachableModuleCount,collection:collectionMode==='collection',actualEmbeddedStageExecuted:true,actualEmbeddedMotorExecuted:true,actualEmbeddedJrArtExecuted:true,stateAndEventsMatchEveryTick:true,ordinarySmallInputFrames:route.inputs.length,headStomps:3,shellRecoveries:2,realKeyRewards:1,keys:1,score:4000,rasterScenes,networkRequests,originalPhysicsCalibrated:false,artSourceRip:false}));
