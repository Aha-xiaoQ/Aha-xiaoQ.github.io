import fs from 'node:fs';
import {createCanvas} from '@napi-rs/canvas';
import {nativeSession} from '../tests/fixtures/shell-coin-native.mjs';
import {nativeWorld} from '../render-lantern-course-native-canvas.mjs';
import {minecraftDisplayCamera} from '../atlas/editor-camera.mjs';
const root=new URL('../examples/minecraft-adventure/',import.meta.url),doc=JSON.parse(fs.readFileSync(new URL('blast-trail.qmap.json',root))),out=new URL('evidence/r10-responsive/',root);fs.mkdirSync(out,{recursive:true});const shots=[];
for(const roomId of ['main','burrow','home'])for(const [name,width,height]of [['16x9',1920,1080],['16x10',1920,1200],['4x3',1024,768],['portrait-field',390,844]]){
 const d=structuredClone(doc),index=d.rooms.findIndex(r=>r.roomId===roomId),[r]=d.rooms.splice(index,1);d.rooms.unshift(r);const s=nativeSession(d);s.frames(24);const v=s.view(),camera=minecraftDisplayCamera(v,{width,height,expanded:true}),frame=nativeWorld({...v,viewportWidth:camera.width,viewportHeight:camera.height},d,{camera:{...camera,w:camera.width,h:camera.height},scale:2});
 const file=roomId+'-'+name+'.png';let result=frame.canvas;if(width>=height){result=createCanvas(width,height);const c=result.getContext('2d'),scale=Math.min(width/frame.canvas.width,height/frame.canvas.height);c.imageSmoothingEnabled=false;c.fillStyle='#101015';c.fillRect(0,0,width,height);c.drawImage(frame.canvas,(width-frame.canvas.width*scale)/2,(height-frame.canvas.height*scale)/2,frame.canvas.width*scale,frame.canvas.height*scale);}
 fs.writeFileSync(new URL(file,out),result.toBuffer('image/png'));shots.push({file,roomId,surface:{width,height},camera,pixels:{width:result.width,height:result.height},ordinaryFrames:24,source:'Actual native Stage idle at authored room spawn; shared gameplay renderer and presentation-camera helper. Portrait shows its retained full landscape playfield, not a fabricated mobile DOM screenshot.'});
}
fs.writeFileSync(new URL('report.json',out),JSON.stringify({realBrowser:false,physicalHardware:false,simulationOrCollisionChanges:false,renderer:'@napi-rs/canvas nativeWorld using shared playable art',shots},null,2));console.log(JSON.stringify({output:out.pathname,shots:shots.map(q=>q.file)}));
