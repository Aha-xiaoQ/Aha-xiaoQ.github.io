import {createJourneyPilot as createPilot} from './minecraft-journey-pilot.mjs';
import fs from 'node:fs';import assert from 'node:assert/strict';
import {nativeSession} from '../tests/fixtures/shell-coin-native.mjs';
import {createPlatformStage} from '../atlas/editor-mario-stage.mjs';
const doc=JSON.parse(fs.readFileSync(new URL('../examples/minecraft-adventure/blast-trail.qmap.json',import.meta.url))),out=new URL('../examples/minecraft-adventure/evidence/',import.meta.url);
export function drive(s,{limit=24000,verbose=false}={}){const pilot=createPilot({verbose});for(let i=0;i<limit&&!s.view().completed&&!s.view().p.dying;i++)s.step(pilot(s.view()));return s.view();}
const s=nativeSession(doc,{Stage:o=>createPlatformStage({...o,manualDeath:false})});const v=drive(s,{verbose:process.argv.includes('--verbose')});
fs.writeFileSync(new URL('route-inputs.json',out),JSON.stringify(s.inputs));fs.writeFileSync(new URL('route-events.json',out),JSON.stringify(s.events,null,2));fs.writeFileSync(new URL('route-report.json',out),JSON.stringify({completed:v.completed,frames:s.inputs.length,seconds:s.inputs.length/60,p:v.p,lives:v.lives,roomId:v.roomId,checkpoints:s.events.filter(e=>e.type==='checkpoint'),minecraft:s.events.filter(e=>e.type==='minecraft'),evidence:'Actual native stage and Mario motor, ordinary x/run/jump input tape; no placement/state injection. Not a real-browser test.'},null,2));console.log(JSON.stringify({completed:v.completed,frames:s.inputs.length,seconds:s.inputs.length/60,p:v.p,roomId:v.roomId,lives:v.lives},null,2));
if(!v.completed)process.exitCode=1;
if(v.completed){
assert.equal(v.lives,9);assert(s.trace.some(t=>String(t.p.support).startsWith('mc-sand-')),'route stands on actual sand');assert.equal(s.events.filter(e=>e.type==='minecraft'&&e.event==='creeper-exploded').length,2);
const replay=nativeSession(doc,{Stage:o=>createPlatformStage({...o,manualDeath:false})});for(const input of s.inputs)replay.step(input);assert.equal(replay.view().completed,true);assert.equal(replay.view().lives,9);
const checks=[];
for(const checkpointId of ['forest-save','after-sand-save']){
 const rec=nativeSession(doc,{Stage:o=>createPlatformStage({...o,manualDeath:false})}),checkpointFrame=s.events.find(e=>e.type==='checkpoint'&&e.checkpointId===checkpointId).frame;for(const input of s.inputs.slice(0,checkpointFrame))rec.step(input);
 let died=false,respawned=false;const recoveryPilot=createPilot();
 for(let i=0;i<1300;i++){const a=rec.view();let input=checkpointId==='forest-save'?{x:-1,run:true,jump:a.p.x>930&&i%45<22}:a.p.x<1540?recoveryPilot(a):{x:1};if(died)input={};rec.step(input);if(rec.view().p.dying)died=true;if(died&&!rec.view().p.dying){respawned=true;break;}}
 assert(died&&respawned,'ordinary death / checkpoint respawn '+checkpointId);const restored=rec.view();assert.equal(restored.lives,8);assert.equal(restored.checkpoint.spawnId,checkpointId==='forest-save'?'forest-save-spawn':'after-sand-spawn');if(checkpointId==='forest-save')assert(restored.geometry.some(g=>g.id==='mc-stone-cracked-entry'),'death restores gate');else assert(restored.geometry.some(g=>g.id==='mc-stone-sand-support'),'death restores sand support');
 const end=drive(rec);assert.equal(end.completed,true,'resume can finish '+checkpointId);assert.equal(end.lives,8);checks.push({checkpointId,respawn:{roomId:restored.roomId,x:restored.p.x,y:restored.p.y,lives:restored.lives},completed:end.completed,frames:rec.inputs.length});fs.writeFileSync(new URL('recovery-'+checkpointId+'-inputs.json',out),JSON.stringify(rec.inputs));
}
fs.writeFileSync(new URL('recovery-report.json',out),JSON.stringify({fullRestartReproduced:true,actualSandSupport:true,ordinaryDeaths:checks,realBrowser:false},null,2));console.log('Full restart, forest fall checkpoint recovery, post-sand fall recovery, and standable sand verified.');
}
