import fs from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {createCanvas} from '@napi-rs/canvas';
import {CLOWN_CAR_SOURCE} from '../atlas/clown-car-source-data.mjs';
import {SMM2_SHOE_SOURCE_SPRITES} from '../atlas/editor-smm2-shoe-source-pixels.mjs';
const root=new URL('../atlas/assets/recovered-source-pixels/',import.meta.url);
await fs.mkdir(root,{recursive:true});
const records=[{name:'clown-car',width:CLOWN_CAR_SOURCE.width,height:CLOWN_CAR_SOURCE.height,palette:CLOWN_CAR_SOURCE.palette,rows:CLOWN_CAR_SOURCE.rows,originalSourceFile:CLOWN_CAR_SOURCE.sourceFile,historicalSourceResponseSha256:CLOWN_CAR_SOURCE.sha256,sourcePage:CLOWN_CAR_SOURCE.sourcePage},...Object.entries(SMM2_SHOE_SOURCE_SPRITES).map(([name,q])=>({name:'shoe-'+name,width:q.width,height:q.height,palette:q.palette,rows:q.rows,originalSourceFile:q.sourceFile,historicalSourceResponseSha256:q.sourceSha256,sourceGame:q.sourceGame}))];
const manifest={schemaVersion:1,kind:'lossless-pixel-copies-reencoded-from-recovered-v3-html-records',copyright:'Nintendo; private learning only; not MIT',originalResponseBytesRecovered:false,files:[]};
for(const q of records){
 const canvas=createCanvas(q.width,q.height),ctx=canvas.getContext('2d');
 for(let y=0;y<q.height;y++)for(let x=0;x<q.width;x++){
  const [r,g,b,a]=q.palette[Number(q.rows[y][x])];
  if(a){ctx.fillStyle=`rgba(${r},${g},${b},${a/255})`;ctx.fillRect(x,y,1,1);}
 }
 const file=q.name+'.pixel-copy.png',bytes=canvas.toBuffer('image/png');await fs.writeFile(new URL(file,root),bytes);
 const {palette,rows,...source}=q;manifest.files.push({...source,file,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex'),encoding:'new PNG; not the original source response'});
}
await fs.writeFile(new URL('RECOVERED_PIXELS.json',root),JSON.stringify(manifest,null,2)+'\n');
console.log('Saved three lossless pixel-copy PNGs and their distinct actual SHA-256 records');
