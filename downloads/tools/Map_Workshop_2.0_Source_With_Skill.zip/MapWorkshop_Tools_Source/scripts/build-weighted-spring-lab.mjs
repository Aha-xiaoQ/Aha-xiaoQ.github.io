// Rebuild an independent neutral mechanism lab, not a replica or a course.
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import {projectPack} from '../atlas/editor-runtime.mjs';
import {offlineFile} from '../atlas/editor-offline.mjs';
import {weightedSpringProject,weightedSpringLiftProject,weightedSpringDropProject,weightedSpringCargoProject} from '../tests/fixtures/weighted-spring-seesaw.mjs';

export const LAB_CASES=[
 {id:'lift',title:'配重抬升',description:'人物站在右端，轻弹簧压住左端。试着移动、跳起，观察两侧重量和板面变化。',make:weightedSpringLiftProject},
 {id:'impact',title:'冲击弹射',description:'咚咚真实下冲，弹簧与站在上面的人一起被弹出。离开支撑后，两者各自按重力运动。',make:weightedSpringProject},
 {id:'drop',title:'脱离支撑',description:'板面旋转后，有限顶面退出弹簧脚下，弹簧会真实落到地面。这里的较大角度用来清楚展示脱离。',make:weightedSpringDropProject},
 {id:'cargo',title:'三级支撑',description:'POW 站在弹簧上，弹簧站在跷板上。三级真实支撑会传递载荷；移动人物会改变平衡。',make:weightedSpringCargoProject}
];
export async function buildWeightedSpringLab(output='dist/weighted-spring-lab'){
 const out=path.resolve(output);await fs.mkdir(out,{recursive:true});
 const atlas=new URL('../atlas/',import.meta.url),character=JSON.parse(await fs.readFile(new URL('runtime/character.json',atlas),'utf8'));
 const cases=LAB_CASES.map(q=>({...q,make:undefined,project:q.make()}));
 for(const q of cases){q.pack=projectPack(q.project,q.project.rooms[0].roomId,character,'weighted-spring-'+q.id);await fs.writeFile(path.join(out,'weighted-spring-'+q.id+'.qmap.json'),JSON.stringify(q.project,null,2)+'\n');}
 const base=await offlineFile(cases[0].pack,cases[0].project.rooms,p=>fs.readFile(new URL(p,atlas),'utf8'),p=>fs.readFile(new URL('assets/classic-audio/'+p,atlas)),()=>{},{cleanUi:true});
 const last=base.lastIndexOf('<script type="module">'),script=base.slice(last),mediaStart=script.indexOf(',media=')+7,mediaEnd=script.indexOf(';const start=',mediaStart);
 assert(last>0&&mediaStart>6&&mediaEnd>mediaStart);const media=JSON.parse(script.slice(mediaStart,mediaEnd));
 const safe=q=>JSON.stringify(q).replace(/</g,'\\u003c');
 const module=`<script type="module">import {play} from "workshop/editor-play.mjs";const cases=${safe(cases)},media=${safe(media)};const status=document.getElementById('status'),start=document.getElementById('start'),select=document.getElementById('lab-case'),hint=document.getElementById('lab-hint'),layout=document.getElementById('cover-controller-layout');function update(){hint.textContent=cases[Number(select.value)].description;}select.onchange=update;update();start.onclick=async()=>{start.disabled=true;status.hidden=true;try{const q=cases[Number(select.value)];await play(q.pack,q.project.rooms,media,{cleanUi:true,gamepadLayout:layout.value,initialState:{lives:3},developerMode:false});const dialog=document.querySelector('dialog');if(dialog){const back=[...dialog.querySelectorAll('button')].find(b=>b.textContent==='返回编辑');if(back)back.textContent='返回实验室';dialog.addEventListener('close',()=>start.focus(),{once:true});}}catch(error){status.hidden=false;status.textContent=String(error.message||error);console.error(error);}finally{start.disabled=false;}};document.getElementById('save-case').onclick=()=>{const q=cases[Number(select.value)],url=URL.createObjectURL(new Blob([JSON.stringify(q.project,null,2)+'\\n'],{type:'application/json'})),a=document.createElement('a');a.href=url;a.download='weighted-spring-'+q.id+'.qmap.json';a.click();URL.revokeObjectURL(url);};</script></body></html>`;
 let html=base.slice(0,last)+module;
 html=html.replace(/<title>[^<]*<\/title>/,'<title>弹簧载荷与支撑链 · 工坊验证实验室</title>')
  .replace(/<h1 id="map-title">[^<]*<\/h1>/,'<h1 id="map-title">弹簧载荷与支撑链</h1>')
  .replace('地图工坊 / 离线试玩','地图工坊 / 可编辑机制实验室')
  .replace('一张地图，一段自己的冒险。打开这份文件就能玩，也可以把它分享给朋友。','四个中性测试场景，验证真实重量、移动支撑和冲击弹射。数值为作者设定；不是原版课程或完整原创关卡。')
  .replace('<div class="actions"><button','<label for="lab-case">选择场景 </label><select id="lab-case">'+cases.map((q,i)=>'<option value="'+i+'">'+q.title+'</option>').join('')+'</select><p id="lab-hint"></p><div class="actions"><button')
  .replace('<span>无需安装 · 游戏和声音已包含在文件内 · A / Start 开始</span>','<button id="save-case">保存所选 qmap</button><span>打开即玩 · 可在完整工坊包中继续编辑</span>')
  .replace(/<label[^>]*><input type="checkbox" id="developer-mode">[^<]*<\/label>/,'')
  .replace('手柄：连接后先松开按键，A / Start 开始','手柄布局沿用工坊；点“开始试玩”进入所选场景')
  .replace('上手只需几步','操作')
  .replace('在随附的地图工坊中打开 qmap 工程，摆放地形、敌人和奖励，边编辑边试玩，再导出属于自己的关卡。','这四个场景没有终点。可自由走跳并从暂停菜单重启；返回实验室可换场景。新绑定支持 16×16 或 32×32 弹簧，32 为作者的两倍适配。')
  .replace('下一张地图，由你来做','编辑与范围')
  .replace('手机可使用试玩画面下方的触屏按钮。网站链接需要联网；离线文件本身可以独立游玩。','质量、重力、角度与冲击参数可编辑。原压缩帧、精确原作物理和 NPC 弹簧弹跳未全部校准；素材来源与边界随工具包提供。');
 const file=path.join(out,'weighted-spring-lab.html');await fs.writeFile(file,html);
 const digest=bytes=>createHash('sha256').update(bytes).digest('hex');
 const report={version:'1.10.14-tools.1',kind:'neutral-workshop-mechanism-lab',cases:cases.map(q=>({id:q.id,title:q.title,projectId:q.project.id,file:'weighted-spring-'+q.id+'.qmap.json',sourceSha256:digest(JSON.stringify(q.project))})),html:{file:path.basename(file),bytes:Buffer.byteLength(html),sha256:digest(html)},originalCourse:false,originalNumericalCalibration:false,originalCompressedSheetObtained:false,noPrivateMapDependency:true};
 await fs.writeFile(path.join(out,'LAB_BUILD.json'),JSON.stringify(report,null,2)+'\n');return report;
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url))console.log(JSON.stringify(await buildWeightedSpringLab(process.argv[2])));
