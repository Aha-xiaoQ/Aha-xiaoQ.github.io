import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {placementAudit,placementOptionsForRooms} from '../atlas/editor-placement.mjs';

/** Read-only qmap scan; never follows symlinks or enters dependency/VCS folders. */
export async function auditMapPlacement({roots,current=path.resolve(fileURLToPath(new URL('../',import.meta.url))),output}={}){
 const groups=new Map(),unreadable=[],skippedSymlinks=[];
 async function walk(dir){
  let entries;try{entries=await fs.readdir(dir,{withFileTypes:true});}catch(error){unreadable.push({path:dir,reason:error.code});return;}
  entries.sort((a,b)=>a.name.localeCompare(b.name));
  for(const entry of entries){if(['node_modules','.git','.codex','.agents','.aws'].includes(entry.name))continue;const name=path.join(dir,entry.name);if(entry.isSymbolicLink()){skippedSymlinks.push(name);continue;}if(entry.isDirectory()){await walk(name);continue;}if(!entry.isFile()||!entry.name.endsWith('.qmap.json'))continue;
   try{const bytes=await fs.readFile(name),sha256=crypto.createHash('sha256').update(bytes).digest('hex');let record=groups.get(sha256);if(!record){const project=JSON.parse(bytes.toString('utf8')),rooms=project.rooms||[],contexts=placementOptionsForRooms(rooms);record={sha256,bytes:bytes.length,projectId:project.id,title:project.title,paths:[],rooms:rooms.map(r=>placementAudit(r,contexts.get(r)))};groups.set(sha256,record);}const neutral=/(?:^|\/)(?:examples|fixtures|provenance|dist)(?:\/|$)/.test(name)||/neutral|fixture/i.test(record.title||''),classification=neutral?'neutral-fixture':name.startsWith(current+path.sep)?'current-branch-course':'historical-frozen';record.paths.push({path:name,classification});}catch(error){unreadable.push({path:name,reason:error.code||error.message});}
  }
 }
 for(const root of roots||[current])await walk(path.resolve(root));
 const maps=[...groups.values()],summary={readableFiles:maps.reduce((n,m)=>n+m.paths.length,0),uniqueSha256:maps.length,duplicateFiles:maps.reduce((n,m)=>n+m.paths.length-1,0),errors:maps.reduce((n,m)=>n+m.rooms.reduce((n,r)=>n+r.issues.filter(i=>i.severity==='error').length,0),0),warnings:maps.reduce((n,m)=>n+m.rooms.reduce((n,r)=>n+r.issues.filter(i=>i.severity==='warning').length,0),0),legalContentRecords:maps.reduce((n,m)=>n+m.rooms.reduce((n,r)=>n+r.contents.length,0),0),typedExemptions:maps.reduce((n,m)=>n+m.rooms.reduce((n,r)=>n+r.exemptions.length,0),0),unreadable:unreadable.length,skippedSymlinks:skippedSymlinks.length};
 const report={schemaVersion:1,generatedAt:new Date().toISOString(),roots:roots||[current],current,scope:'Real readable *.qmap.json files; SHA-256 deduplicated. Read-only; symlinks, dependency, VCS and private runtime folders are skipped.',summary,maps,unreadable,skippedSymlinks};
 if(output)await fs.writeFile(output,JSON.stringify(report,null,2)+'\n');return report;
}
if(process.argv[1]&&pathToFileURL(process.argv[1]).href===import.meta.url){const args=process.argv.slice(2),roots=[],options={roots};for(let n=0;n<args.length;n++){if(args[n]==='--root')roots.push(args[++n]);else if(args[n]==='--current')options.current=path.resolve(args[++n]);else if(args[n]==='--output')options.output=args[++n];else throw Error('Unknown argument: '+args[n]);}if(!roots.length)delete options.roots;const report=await auditMapPlacement(options);console.log(JSON.stringify(report.summary,null,2));if(options.output)console.log('Report: '+path.resolve(options.output));}
