import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {projectPack} from '../atlas/editor-runtime.mjs';
import {offlineFile} from '../atlas/editor-offline.mjs';
import {smb1SwitchArtProject} from '../tests/fixtures/smb1-switch-art.mjs';
import {readCharacterProfile} from './neutral-fixtures.mjs';

const root=new URL('../',import.meta.url),project=smb1SwitchArtProject(),character=await readCharacterProfile();
const pack=projectPack(project,'main',character,'neutral-smb1-switch-art');
const html=await offlineFile(pack,project.rooms,path=>readFile(new URL('atlas/'+path,root),'utf8'),name=>readFile(new URL('atlas/assets/classic-audio/'+name,root)));
const json=value=>JSON.stringify(value,null,2)+'\n';
await mkdir(new URL('dist/',root),{recursive:true});await mkdir(new URL('examples/',root),{recursive:true});
for(const [path,value] of Object.entries({'dist/neutral-smb1-switch-art.qmap.json':json(project),'examples/neutral-smb1-switch-art.qmap.json':json(project),'dist/neutral-smb1-switch-art.pack.json':json(pack),'dist/neutral-smb1-switch-art.html':html})){
 await writeFile(new URL(path,root),value);console.log(fileURLToPath(new URL(path,root)));
}
