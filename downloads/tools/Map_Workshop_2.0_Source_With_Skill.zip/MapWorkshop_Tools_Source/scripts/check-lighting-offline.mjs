// Execute actual embedded native Stage, Motor, lighting mask and play renderer.
// Neutral authored parameters; no claim of original-course timing calibration.
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createContext,SourceTextModule,runInContext} from 'node:vm';
import {createCanvas} from '@napi-rs/canvas';
import {inspectOfflineHtml} from './check-offline-html.mjs';
import {assertNativeLightingMotion} from '../tests/fixtures/lighting-native.mjs';
import {installLightingRenderDom,renderLightingPlayPair} from '../tests/fixtures/lighting-render-dom.mjs';

const [htmlFile,projectFile,mode]=process.argv.slice(2);
if(!htmlFile||!projectFile)throw Error('Usage: node --experimental-vm-modules scripts/check-lighting-offline.mjs HTML QMAP [collection]');
const html=fs.readFileSync(htmlFile,'utf8'),checked=inspectOfflineHtml(html,{collection:mode==='collection'}),project=JSON.parse(fs.readFileSync(projectFile,'utf8')),ui=installLightingRenderDom();let networkRequests=0;
const mediaMatch=checked.root.match(/\bmedia=(\{[\s\S]*?\});/);assert(mediaMatch,'offline bootstrap supplies its actual embedded audio and image media');const offlineMedia=JSON.parse(mediaMatch[1]);
try{
 const forbidNetwork=()=>{networkRequests++;throw Error('Neutral lighting offline execution cannot use network');};
 class EmbeddedImage extends globalThis.Image{set src(value){assert(String(value).startsWith('data:image/'),'runtime Image data must be embedded');this._src=value;}get src(){return this._src;}}
 class EmbeddedAudio extends globalThis.Audio{set src(value){assert(String(value).startsWith('data:audio/'),'runtime Audio data must be embedded');this._src=value;}get src(){return this._src;}}
 const storage=new Map(),context=createContext({console,URL,Blob,atob,btoa,TextEncoder,TextDecoder,ArrayBuffer,Uint8Array,Uint8ClampedArray,structuredClone,crypto:globalThis.crypto,document:globalThis.document,window:globalThis.window,navigator:globalThis.navigator,performance:globalThis.performance,Image:EmbeddedImage,Audio:EmbeddedAudio,Option:globalThis.Option,FontFace:globalThis.FontFace,requestAnimationFrame:globalThis.requestAnimationFrame,cancelAnimationFrame:globalThis.cancelAnimationFrame,setTimeout,clearTimeout,localStorage:{getItem:key=>storage.get(key)??null,setItem:(key,value)=>storage.set(key,value),removeItem:key=>storage.delete(key)},fetch:forbidNetwork,XMLHttpRequest:class{constructor(){forbidNetwork();}},WebSocket:class{constructor(){forbidNetwork();}}}),modules=new Map();
 for(const [id,source]of checked.modules)modules.set(id,new SourceTextModule(source,{context,identifier:id}));
 const link=id=>{assert(modules.has(id),'Missing embedded module '+id);return modules.get(id);},play=modules.get('workshop/editor-play.mjs'),stage=modules.get('workshop/editor-mario-stage.mjs'),motor=modules.get('workshop/editor-mario-motor.mjs'),lighting=modules.get('workshop/editor-smm2-lighting.mjs');
 assert(lighting,'actual lighting module is embedded');await play.link(link);await play.evaluate();
 const local=(key,value)=>{context[key]=JSON.stringify(value);return runInContext('JSON.parse('+key+')',context);};
 const EmbeddedStage=options=>stage.namespace.createPlatformStage({...local('stageInput',{plan:options.plan,visualRooms:options.visualRooms,initialState:options.initialState,manualDeath:options.manualDeath,autoContinue:options.autoContinue,allowWarp:options.allowWarp}),motor:options.motor,emit:options.emit});
 const resolve=(room,view)=>{const data=local('lightInput',{room,view});return JSON.parse(JSON.stringify(lighting.namespace.resolveSmm2LightSources(data.room,data.view)));};
 const report=assertNativeLightingMotion(project,{Stage:EmbeddedStage,Motor:motor.namespace.createPlatformMotor,resolve});delete report.trace;
 const data=local('pixelInput',{room:project.rooms[0],view:{roomId:project.rooms[0].roomId,p:{x:59,y:57,w:10,h:14},enemies:[],items:[],objects:[],geometry:[],hiddenMarkers:['fixed-arrow']}}),canvas=createCanvas(256,240),ctx=canvas.getContext('2d');ctx.fillStyle='#ffffff';ctx.fillRect(0,0,256,240);
 assert(lighting.namespace.drawSmm2LightingMask(ctx,data.room,data.view,{camera:{x:0,y:0,width:256,height:240},width:256,height:240,createCanvas}));assert.equal(ctx.getImageData(64,64,1,1).data[0],255);assert(ctx.getImageData(240,16,1,1).data[0]<64);
 const EmbeddedPlay=async(pack,rooms,media,options)=>{const data=local('playInput',{pack,rooms,media:offlineMedia,options}),session=await play.namespace.play(data.pack,data.rooms,data.media,data.options),load=session.load;session.load=async(pack,rooms,options)=>{const data=local('loadInput',{pack,rooms,options});return load(data.pack,data.rooms,data.options);};return session;};
 const pair=await renderLightingPlayPair({Play:EmbeddedPlay,doc:project,ui}),mask=pair.dark.calls.findLastIndex(q=>q.kind==='image'&&q.sourceWidth===pair.dark.canvas.width&&q.sourceHeight===pair.dark.canvas.height&&q.args.length===4),hud=pair.dark.calls.findIndex((q,i)=>i>mask&&q.kind==='rect'&&['#fff','#ffffff'].includes(q.fill)&&q.y>=20&&q.y<=60);assert(mask>=0&&hud>mask,'embedded play executes mask before HUD');
 const pixels=pair.dark.canvas.getContext('2d').getImageData(0,0,pair.dark.canvas.width,80).data;let brightHudPixels=0;for(let i=0;i<pixels.length;i+=4)if(pixels[i]===255&&pixels[i+1]===255&&pixels[i+2]===255)brightHudPixels++;assert(brightHudPixels>300);
 const body=html.match(/<body>([\s\S]*?)<script type="importmap">/);assert(body,'actual offline body exists');ui.document.body.innerHTML=body[1];const bootstrap=new SourceTextModule(checked.root,{context,identifier:'lighting-offline-bootstrap'});await bootstrap.link(link);await bootstrap.evaluate();
 const start=mode==='collection'?ui.document.querySelectorAll('button').find(q=>q.textContent==='从第一关开始'):ui.document.getElementById('start');assert(start?.onclick,'actual offline launcher exists');await start.onclick();
 const output=ui.document.querySelector('dialog canvas');assert(output?.workshopRead,'actual bootstrap launched the native play module');
 let actualFrames=0;while(output.workshopRead().tick<65){ui.frames();if(++actualFrames>90)throw Error('Offline bootstrap native Stage did not settle');}
 ui.key('ArrowRight');while(output.workshopRead().coins<1){ui.frames();if(++actualFrames>160)throw Error('Offline bootstrap did not take the actual native coin');}ui.release('ArrowRight');const bootstrapView=output.workshopRead();assert.equal(bootstrapView.lives,3);assert(!resolve(project.rooms[0],bootstrapView).some(q=>q.targetId==='lamp-coin'),'actual bootstrap pickup removes the light');assert(bootstrapView.items.find(q=>q.id==='falling-pow')?.y>80);ui.document.querySelector('dialog')?.close();
 assert.equal(networkRequests,0);
 console.log(JSON.stringify({kind:'synthetic-neutral',collection:mode==='collection',moduleCount:checked.moduleCount,actualEmbeddedStageExecuted:true,actualEmbeddedMotorExecuted:true,actualEmbeddedLightingExecuted:true,actualEmbeddedPlayExecuted:true,actualEmbeddedBootstrapExecuted:true,collectionLauncherExecuted:mode==='collection',bootstrapCoinPickup:true,bootstrapNaturalFrames:bootstrapView.tick,maskBeforeHud:true,brightHudPixels,networkRequests,...report,originalTimingCalibrated:false}));
}finally{ui.restore();}
