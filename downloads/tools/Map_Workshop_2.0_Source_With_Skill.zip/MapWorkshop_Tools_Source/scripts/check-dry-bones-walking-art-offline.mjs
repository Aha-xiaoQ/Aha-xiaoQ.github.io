import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {createContext,SourceTextModule} from 'node:vm';
import {createCanvas} from '@napi-rs/canvas';
import {offlineFile} from '../atlas/editor-offline.mjs';
import {inspectOfflineHtml} from './check-offline-html.mjs';
import {drawObject} from '../atlas/editor-art.mjs';
import {nativeWorld} from '../render-lantern-course-native-canvas.mjs';

const root=new URL('../atlas/',import.meta.url),room={roomId:'main',setting:'Castle',map:{width:384,height:216,geometry:[],objects:[]},markers:[],decorations:[],nativeSceneryMode:'authored',smm2Mechanics:{version:1}};
const html=await offlineFile({stages:[{title:'Neutral Dry Bones walk rendering'}]},[room],p=>fs.readFile(new URL(p,root),'utf8'),p=>fs.readFile(new URL('assets/classic-audio/'+p,root)));
const checked=inspectOfflineHtml(html);let networkRequests=0,rasterScenes=0;
const context=createContext({console,URL,TextEncoder,TextDecoder,Uint8Array,Uint8ClampedArray,structuredClone,fetch(){networkRequests++;throw Error('Walk art must remain offline');}}),modules=new Map();
for(const [id,source] of checked.modules)modules.set(id,new SourceTextModule(source,{context,identifier:id}));
const art=modules.get('workshop/editor-art.mjs');await art.link(id=>{assert(modules.has(id));return modules.get(id);});await art.evaluate();
const bytes=c=>c.getContext('2d').getImageData(0,0,c.width,c.height).data,doc={rooms:[room]},camera={x:0,y:0,w:384,h:216};
for(const scale of [1,2])for(const facing of [-1,1])for(const pose of ['walk0','walk1','walk2','walk3','standing','airborne','collapsed']){
 const frame=Number(pose.slice(-1))||0,pile=pose==='collapsed',q={id:'bones',kind:'walker',type:'dry-bones',x:(32+2*frame)*scale,y:160-(pile?8:24)*scale,w:16*scale,h:(pile?8:24)*scale,vx:pose==='standing'?0:-.5,vy:pose==='airborne'?1:0,grounded:pose!=='airborne',facing,smm2DryBones:{phase:pile?'collapsed':'walking',size:scale===2?'giant':'normal'}};
 const before=JSON.stringify(q),local=createCanvas(384,216),embedded=createCanvas(384,216);drawObject(local.getContext('2d'),q,8,room);art.namespace.drawObject(embedded.getContext('2d'),q,8,room);assert.deepEqual(bytes(local),bytes(embedded));
 const view={roomId:'main',tick:8,p:{x:0,y:0,w:10,h:14},geometry:[],objects:[],enemies:[q],items:[],vines:[],coins:0,score:0,timeLeft:300,lives:3},stateBefore=JSON.stringify(view);
 const actual=nativeWorld(view,doc,{camera,showPlayer:false,scale:2}).canvas,expected=nativeWorld({...view,enemies:[]},doc,{camera,showPlayer:false,scale:2}).canvas;
 expected.getContext('2d').save();expected.getContext('2d').scale(2,2);drawObject(expected.getContext('2d'),q,8,room);expected.getContext('2d').restore();assert.deepEqual(bytes(actual),bytes(expected));assert.equal(JSON.stringify(view),stateBefore);assert.equal(JSON.stringify(q),before);rasterScenes++;
}
assert.equal(networkRequests,0);console.log(JSON.stringify({embeddedArtExecuted:true,nativeVideoRendererExecuted:true,stateUnchanged:true,rasterScenes,moduleCount:checked.moduleCount,networkRequests,originalWalkingAnimationObtained:false}));
