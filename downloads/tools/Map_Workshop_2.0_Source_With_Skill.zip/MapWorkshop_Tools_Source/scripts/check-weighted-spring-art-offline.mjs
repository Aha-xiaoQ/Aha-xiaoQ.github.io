import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {createContext,SourceTextModule} from 'node:vm';
import {createCanvas} from '@napi-rs/canvas';
import {offlineFile} from '../atlas/editor-offline.mjs';
import {inspectOfflineHtml} from './check-offline-html.mjs';
import {drawTile} from '../atlas/editor-art.mjs';
import {SMM1_SMB1_SPRINGBOARD_SOURCE as source} from '../atlas/editor-smm2-spring-source-pixels.mjs';
import {smm2WeightedSpringVisualPose} from '../atlas/editor-smm2-spring-art.mjs';
import {weightedSpringProject,weightedSpringSession} from '../tests/fixtures/weighted-spring-seesaw.mjs';
import {nativeSession} from '../tests/fixtures/shell-coin-native.mjs';
import {mountPlacementEditor} from '../tests/fixtures/placement-editor-dom.mjs';
import {nativeWorld} from '../render-lantern-course-native-canvas.mjs';

const root=new URL('../atlas/',import.meta.url),doc=weightedSpringProject({impact:false,playerOnSpring:false}),room=doc.rooms[0];
const html=await offlineFile({stages:[{title:'Neutral weighted Spring source rendering'}]},doc.rooms,p=>fs.readFile(new URL(p,root),'utf8'),p=>fs.readFile(new URL('assets/classic-audio/'+p,root)));
const checked=inspectOfflineHtml(html);let networkRequests=0,rasterScenes=0;const nativeHeightRanges={};
const context=createContext({console,URL,TextEncoder,TextDecoder,Uint8Array,Uint8ClampedArray,structuredClone,fetch(){networkRequests++;throw Error('Spring art must remain offline');}}),modules=new Map();
for(const [id,text] of checked.modules)modules.set(id,new SourceTextModule(text,{context,identifier:id}));
const art=modules.get('workshop/editor-art.mjs');await art.link(id=>{assert(modules.has(id));return modules.get(id);});await art.evaluate();
const embedded=modules.get('workshop/editor-smm2-spring-source-pixels.mjs').namespace.SMM1_SMB1_SPRINGBOARD_SOURCE;assert.equal(embedded.sourceSha256,source.sourceSha256);assert.deepEqual(JSON.parse(JSON.stringify(embedded)),source);
const bytes=c=>c.getContext('2d').getImageData(0,0,c.width,c.height).data;
const generic=modules.get('workshop/editor-smm2-source-assets.mjs').namespace,staticCanvas=createCanvas(16,16),staticExpected=createCanvas(16,16),standing=room.map.geometry.find(g=>g.id==='spring');
assert.equal(generic.SMM2_SOURCE_PIXELS.weightedSpringStanding.rows,embedded.rows);assert(generic.drawSmm2SourcePixels(staticCanvas.getContext('2d'),'weightedSpringStanding',{x:0,y:0}));staticExpected.getContext('2d').translate(-standing.x,-standing.y);drawTile(staticExpected.getContext('2d'),standing,room);assert.deepEqual(bytes(staticCanvas),bytes(staticExpected));
const bigDoc=weightedSpringProject({impact:false}),bigRoom=bigDoc.rooms[0];Object.assign(bigRoom.map.geometry.find(g=>g.id==='spring'),{w:32,h:32,y:220});Object.assign(bigRoom.map.objects.find(g=>g.kind==='spawn'),{x:155,y:206});
for(const {session,jump} of [{session:weightedSpringSession({impact:false}),jump:true},{session:weightedSpringSession({impact:true}),jump:false},{session:nativeSession(bigDoc),jump:true}]){
 for(let frame=0;frame<20;frame++){
  const view=session.step({jump}),q=view.geometry.find(g=>g.id==='spring'),p=smm2WeightedSpringVisualPose(q),r=session.doc.rooms[0],before=JSON.stringify(view),local=createCanvas(640,384),offline=createCanvas(640,384);
  const range=nativeHeightRanges[q.w]??={min:Infinity,max:0,frames:0};range.min=Math.min(range.min,q.h);range.max=Math.max(range.max,q.h);range.frames++;assert.equal(p.y,Math.round(q.y));assert.equal(p.bottom,Math.round(q.y+q.h));assert.equal(p.y+p.h,p.bottom);
  drawTile(local.getContext('2d'),q,r);art.namespace.drawTile(offline.getContext('2d'),q,r);assert.deepEqual(bytes(local),bytes(offline));
  const drawn=bytes(local);for(let y=0;y<local.height;y++)for(let x=0;x<local.width;x++)if(drawn[(y*local.width+x)*4+3])assert(x>=p.x&&x<p.x+p.w&&y>=p.y&&y<p.bottom,'native rendered pixels stay in the real raster body');
  const camera={x:0,y:128,w:384,h:240},actual=nativeWorld(view,session.doc,{camera,showPlayer:false,scale:2}).canvas,without={...view,geometry:view.geometry.filter(g=>g.id!==q.id)},expected=nativeWorld(without,session.doc,{camera,showPlayer:false,scale:2}).canvas;
  const ctx=expected.getContext('2d');ctx.save();ctx.scale(2,2);ctx.translate(0,-128);drawTile(ctx,q,r);ctx.restore();
  // Crop excludes other draw-order details and HUD, while retaining the complete
  // real Spring and its transparent interior over the same native background.
  const x=p.x*2,y=(p.y-128)*2,w=p.w*2,h=p.h*2;assert.deepEqual(actual.getContext('2d').getImageData(x,y,w,h).data,expected.getContext('2d').getImageData(x,y,w,h).data);
  assert.equal(JSON.stringify(view),before);rasterScenes++;
 }
}
// Run the actual editor after native drawing has initialized its classic Canvas
// cache, so the simulated editor element does not leak into the video bridge.
const editor=await mountPlacementEditor(doc);try{
 const q=room.map.geometry.find(q=>q.material==='spring'),actual=editor.$('canvas').raster,expected=createCanvas(16,16),ctx=expected.getContext('2d');ctx.fillStyle='#5c94fc';ctx.fillRect(0,0,16,16);ctx.translate(-q.x,-q.y);drawTile(ctx,q,room);
 assert.deepEqual(actual.getContext('2d').getImageData(q.x,q.y,16,16).data,bytes(expected));assert.deepEqual(editor.document(),doc);
}finally{editor.restore();}
assert.equal(networkRequests,0);assert.equal(nativeHeightRanges[16].min,8);assert.equal(nativeHeightRanges[32].min,20);console.log(JSON.stringify({actualEditorPreviewExecuted:true,embeddedArtExecuted:true,genericStaticRegistryExecuted:true,nativeVideoRendererExecuted:true,stateUnchanged:true,artWithinActualRasterBody:true,nativeHeightRanges,rasterScenes,moduleCount:checked.moduleCount,networkRequests,sourceSha256:source.sourceSha256,sourceRgbaSha256:source.rgbaSha256,originalCompressedGifObtained:false}));
