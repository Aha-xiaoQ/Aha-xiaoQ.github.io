import assert from 'node:assert/strict';

export const RESTORED_OFFLINE_MODULES=Object.freeze([
 'workshop/editor-clown-car-art.mjs',
 'workshop/clown-car-source-data.mjs',
 'workshop/editor-smm2-shoe-source-pixels.mjs',
]);

/** Inspect actual embedded source, not a list copied from the exporter. */
export function inspectOfflineHtml(html,{collection=false}={}){
 const match=html.match(/<script type="importmap">([\s\S]*?)<\/script>/);
 assert.ok(match,'offline HTML contains its import map');
 const {imports}=JSON.parse(match[1]);
 const modules=new Map(Object.entries(imports).map(([id,url])=>{
  assert.match(id,/^workshop\/.+\.mjs$/);
  const prefix='data:text/javascript;charset=utf-8,';
  assert.ok(url.startsWith(prefix),id+' is embedded JavaScript');
  return [id,decodeURIComponent(url.slice(prefix.length))];
 }));
 const roots=[...html.matchAll(/<script type="module">([\s\S]*?)<\/script>/g)].map(entry=>entry[1]);
 assert.equal(roots.length,1,'one self-contained player bootstrap');
 for(const required of RESTORED_OFFLINE_MODULES)assert.ok(modules.has(required),'restored module is bundled: '+required);
 if(collection)assert.ok(modules.has('workshop/editor-collection-player.mjs'));
 const dependencies=source=>[...source.matchAll(/\bfrom\s*['"]([^'"\n]+)['"]|\bimport\s*['"]([^'"\n]+)['"]|\bimport\s*\(\s*['"]([^'"\n]+)['"]/g)].map(entry=>entry[1]||entry[2]||entry[3]);
 const reached=new Set();
 function visit(id){
  assert.ok(modules.has(id),'missing embedded import: '+id);
  if(reached.has(id))return;reached.add(id);
  for(const dependency of dependencies(modules.get(id)))visit(dependency);
 }
 for(const root of roots)for(const dependency of dependencies(root))visit(dependency);
 for(const [id,source] of modules)for(const dependency of dependencies(source))assert.ok(modules.has(dependency),id+' imports unavailable '+dependency);
 assert.ok(reached.has('workshop/editor-play.mjs'));
 for(const required of RESTORED_OFFLINE_MODULES)assert.ok(reached.has(required),'restored module is in the actual player dependency graph: '+required);
 assert.doesNotMatch(html,/<script\b[^>]*\bsrc\s*=|<link\b[^>]*\b(?:href|rel)\s*=/i,'runtime has no external script or stylesheet');
 const images=[...html.matchAll(/<img\b[^>]*\bsrc="([^"]+)"/g)].map(entry=>entry[1]);
 assert.ok(images.length>=2);for(const source of images)assert.ok(source.startsWith('data:image/'),'cover art is embedded');
 assert.doesNotMatch(roots[0],/\bfetch\s*\(/,'bootstrap needs no remote project data');
 assert.match(roots[0],/data:audio\//,'audio is embedded');
 return {modules,root:roots[0],moduleCount:modules.size,reachableModuleCount:reached.size};
}
