// Execute the actual embedded stage/motor graph with normal input and no fetch.
// Synthetic mechanism fixture only; no course clear or Nintendo timing claim.
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createContext,SourceTextModule,runInContext} from 'node:vm';
import {inspectOfflineHtml} from './check-offline-html.mjs';
import {nativeSession,activate,shellPickups,checkPhysicalPickups} from '../tests/fixtures/shell-coin-native.mjs';
const [htmlFile,projectFile]=process.argv.slice(2);
if(!htmlFile||!projectFile)throw Error('Usage: node --experimental-vm-modules scripts/check-shell-coin-offline.mjs HTML QMAP');
const checked=inspectOfflineHtml(fs.readFileSync(htmlFile,'utf8')),project=JSON.parse(fs.readFileSync(projectFile,'utf8'));let networkRequests=0;
const context=createContext({console,URL,TextEncoder,TextDecoder,Uint8Array,Uint8ClampedArray,structuredClone,crypto:globalThis.crypto,fetch(){networkRequests++;throw Error('Offline shell fixture cannot use network');}}),modules=new Map();
for(const [id,source]of checked.modules)modules.set(id,new SourceTextModule(source,{context,identifier:id}));
const link=id=>{assert(modules.has(id),'Missing embedded module '+id);return modules.get(id);};
const stage=modules.get('workshop/editor-mario-stage.mjs'),motor=modules.get('workshop/editor-mario-motor.mjs');
await stage.link(link);if(motor.status==='unlinked')await motor.link(link);await stage.evaluate();await motor.evaluate();
const EmbeddedStage=options=>{context.stageData=JSON.stringify({plan:options.plan,visualRooms:options.visualRooms,initialState:options.initialState,manualDeath:options.manualDeath,autoContinue:options.autoContinue,allowWarp:options.allowWarp});const local=runInContext('JSON.parse(stageData)',context);return stage.namespace.createPlatformStage({...local,motor:options.motor,emit:options.emit});};
const s=nativeSession(project,{Stage:EmbeddedStage,Motor:motor.namespace.createPlatformMotor});activate(s);s.until(v=>v.smm2Mechanics.pinkCoins.keyReleased);s.until(v=>v.contraptions.keys===1);checkPhysicalPickups(s);
assert.equal(shellPickups(s).length,3);assert.equal(s.events.filter(e=>e.event==='pink-key-release').length,1);assert.equal(s.view().coins,3);assert.equal(networkRequests,0);
console.log(JSON.stringify({kind:'synthetic-neutral',moduleCount:checked.moduleCount,actualEmbeddedStageExecuted:true,actualEmbeddedMotorExecuted:true,naturalInputs:s.inputs.length,physicalShellPickups:shellPickups(s).length,pinkTaken:s.view().smm2Mechanics.pinkCoins.taken,keyRewards:s.view().contraptions.keys,networkRequests,originalTimingCalibrated:false}));
