import fs from 'node:fs';
import assert from 'node:assert/strict';
import {nativeSession} from '../tests/fixtures/shell-coin-native.mjs';
import {createDragonPilot} from './minecraft-dragon-pilot.mjs';

const file=new URL('../examples/minecraft-adventure/blast-trail.qmap.json',import.meta.url);
const out=new URL('../examples/minecraft-adventure/evidence/',import.meta.url);
const project=JSON.parse(fs.readFileSync(file));
// Select the authored End entry for this focused encounter test. All poses,
// crystals, HP and portal progress thereafter arise exclusively from real inputs.
const end=project.rooms.find(r=>r.roomId==='end');
assert(end);
project.rooms=[end,...project.rooms.filter(r=>r!==end)];
const session=()=>nativeSession(project);
function finish(s,options={}) {
 const pilot=createDragonPilot(options),metrics={maxProjectiles:{1:0,2:0,3:0},maxClouds:{1:0,2:0,3:0},fountainSupports:new Set()};
 for(let n=0;n<18000&&s.view().roomId==='end'&&!s.view().p.dying;n++){
  const v=s.step(pilot(s.view())),d=v.minecraft?.dragon;
  if(d){metrics.maxProjectiles[d.phase]=Math.max(metrics.maxProjectiles[d.phase],d.projectiles.length);metrics.maxClouds[d.phase]=Math.max(metrics.maxClouds[d.phase],d.pools.length);}
  if(v.p.support?.includes('fountain'))metrics.fountainSupports.add(v.p.support);
 }
 assert.equal(s.view().roomId,'home','real gated portal enters authored celebration room');
 assert.equal(s.view().health,3,'all three phases, charge lanes, projectile fans and purple clouds are avoidable');
 return {...metrics,fountainSupports:[...metrics.fountainSupports]};
}
const s=session(),metrics=finish(s);
assert.equal(s.view().lives,9);
const stomps=s.events.filter(q=>q.event==='dragon-stomp');
const crystals=s.events.filter(q=>q.event==='dragon-crystal-broken');
assert.equal(stomps.length,6);
assert.deepEqual(stomps.map(q=>q.hp),[5,4,3,2,1,0]);
assert.deepEqual(stomps.map(q=>q.phase),[1,1,2,2,3,3]);
assert.equal(crystals.length,3);
assert(stomps.every(q=>q.previousBottom<=q.head.y+1&&q.playerBottom>=q.head.y));
assert(stomps.every(q=>q.head.y===224),'head opening stays above the grounded fountain');
assert(s.events.some(q=>q.event==='dragon-nova'),'third phase emits radial novas');
assert(metrics.fountainSupports.length>0,'ordinary movement physically lands on fountain stepping geometry');
const replay=session();
for(const input of s.inputs)replay.step(input);
assert.equal(replay.view().roomId,'home');
assert.equal(replay.view().health,3);

const death=session(),pilot=createDragonPilot();
for(let n=0;n<1000&&!death.events.some(q=>q.event==='dragon-crystal-broken');n++)death.step(pilot(death.view()));
// Stop dodging in a real attack lane, rather than injecting damage or player poses.
for(let n=0;n<16000&&!death.view().p.dying;n++){
 const p=death.view().p;
 death.step({x:Math.sign(408-p.x-p.vx*12)});
}
assert(death.view().p.dying);
assert.equal(death.view().lives,8);
const frozen=death.view().minecraft.dragon;
death.frames(110);
assert.deepEqual(death.view().minecraft.dragon,frozen);
const deathFrame=death.trace.findIndex(q=>q.p.dying)+1;
assert(death.stage.continueFromCurrent(),'normal retry command succeeds');
const restored=death.view();
assert.equal(restored.checkpoint.spawnId,'end-save-spawn');
assert.equal(restored.p.x,72);
assert.equal(restored.health,3);
assert.equal(restored.minecraft.dragon.hp,6);
assert.equal(restored.minecraft.dragon.phase,1);
assert(restored.minecraft.dragon.crystals.every(q=>q.active));
assert.equal(restored.minecraft.dragon.projectiles.length,0);
assert.equal(restored.minecraft.dragon.pools.length,0);
assert(!restored.objects.some(q=>q.id==='end-exit'));
finish(death);
assert.equal(death.view().lives,8);

const reactionRuns=[];
for(const reactionFrames of [8,18,30]){
 const trial=session();finish(trial,{reactionFrames});
 reactionRuns.push({reactionFrames,delayMs:Math.round(reactionFrames/60*1000),completed:true,frames:trial.inputs.length,health:trial.view().health,lives:trial.view().lives,hits:trial.events.filter(q=>q.event==='dragon-stomp').length});
}
fs.mkdirSync(out,{recursive:true});
fs.writeFileSync(new URL('dragon-inputs.json',out),JSON.stringify(s.inputs));
fs.writeFileSync(new URL('dragon-events.json',out),JSON.stringify(s.events,null,2));
fs.writeFileSync(new URL('dragon-retry-inputs.json',out),JSON.stringify(death.inputs));
const report={
 scope:'Actual generated R5 map, authored End spawn, native Mario stage/motor, ordinary x/jump input plus unlocked portal interact. No player placement, HP edits, direct boss state edits or victory injection. Not a browser test.',
 completed:true,exitRoom:s.view().roomId,frames:s.inputs.length,seconds:s.inputs.length/60,health:s.view().health,lives:s.view().lives,
 crystals:crystals.map(q=>({id:q.crystalId,frame:q.frame,contact:q.contact})),
 stomps:stomps.map(q=>({frame:q.frame,phase:q.phase,hp:q.hp,previousBottom:q.previousBottom,playerBottom:q.playerBottom,headY:q.head.y})),
 phases:[1,2,3].map(phase=>({phase,hits:stomps.filter(q=>q.phase===phase).length,patterns:[...new Set(s.events.filter(q=>q.phase===phase&&q.pattern).map(q=>q.pattern))],charges:s.events.filter(q=>q.phase===phase&&q.event==='dragon-charge-start').map(q=>({altitude:q.altitude,pass:q.pass})),maxProjectiles:metrics.maxProjectiles[phase],maxClouds:metrics.maxClouds[phase]})),
 fountainSupports:metrics.fountainSupports,replay:true,reactionRuns,
 deathRetry:{deathFrame,checkpoint:restored.checkpoint,respawn:{x:restored.p.x,y:restored.p.y},restoredHealth:restored.health,restoredHp:restored.minecraft.dragon.hp,restoredPhase:restored.minecraft.dragon.phase,restoredCrystals:restored.minecraft.dragon.crystals.length,restoredProjectiles:restored.minecraft.dragon.projectiles.length,restoredClouds:restored.minecraft.dragon.pools.length,completed:death.view().roomId==='home',lives:death.view().lives,health:death.view().health}
};
fs.writeFileSync(new URL('dragon-route-report.json',out),JSON.stringify(report,null,2));
console.log(JSON.stringify(report,null,2));
