import {mkdir,writeFile,readFile} from 'node:fs/promises';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {parseProject} from '../atlas/editor-model.mjs';
import {projectPack} from '../atlas/editor-runtime.mjs';
import {parseCollection,serializeCollection,buildCollection} from '../atlas/editor-collection.mjs';
import {offlineFile} from '../atlas/editor-offline.mjs';
import {createNeutralProject,createNeutralCollection,readCharacterProfile} from './neutral-fixtures.mjs';

export const toolsRoot=new URL('../',import.meta.url);
export const distDirectory=new URL('dist/',toolsRoot);
const examplesDirectory=new URL('examples/',toolsRoot);
const readAtlas=path=>readFile(new URL(path,new URL('atlas/',toolsRoot)),'utf8');
const readAudio=name=>readFile(new URL(name,new URL('atlas/assets/classic-audio/',toolsRoot)));
const json=value=>JSON.stringify(value,null,2)+'\n';

/** Regenerates only the declared neutral examples and dist files, from local source. */
export async function buildTools(){
 const character=await readCharacterProfile();
 const project=parseProject(json(createNeutralProject()));
 const collection=parseCollection(serializeCollection(createNeutralCollection()));
 const pack=projectPack(project,'main',character,'neutral-tools-single');
 const runtimeCollection=buildCollection(collection,character);
 if(pack.schemaVersion!==1||runtimeCollection.levels.some(level=>level.pack.schemaVersion!==1))throw Error('Neutral build requires native schemaVersion 1');
 const singleHtml=await offlineFile(pack,project.rooms,readAtlas,readAudio);
 const first=runtimeCollection.levels[0];
 const collectionHtml=await offlineFile(first.pack,runtimeCollection.levels.flatMap(level=>level.rooms),readAtlas,readAudio,()=>{},{collection:runtimeCollection});
 await mkdir(examplesDirectory,{recursive:true});await mkdir(distDirectory,{recursive:true});
 const outputs={
  'neutral-demo.qmap.json':json(project),
  'neutral-demo.qcollection.json':serializeCollection(collection)+'\n',
  'neutral-demo.html':singleHtml,
  'neutral-collection.html':collectionHtml,
 };
 for(const [name,content] of Object.entries(outputs))await writeFile(new URL(name,distDirectory),content);
 for(const name of ['neutral-demo.qmap.json','neutral-demo.qcollection.json'])await writeFile(new URL(name,examplesDirectory),outputs[name]);
 return {project,collection,pack,runtimeCollection,files:Object.keys(outputs).map(name=>fileURLToPath(new URL(name,distDirectory)))};
}

if(process.argv[1]&&pathToFileURL(process.argv[1]).href===import.meta.url){
 const result=await buildTools();
 console.log('Built neutral qmap, two-level qcollection and both self-contained HTML players:');
 for(const file of result.files)console.log(file);
}
