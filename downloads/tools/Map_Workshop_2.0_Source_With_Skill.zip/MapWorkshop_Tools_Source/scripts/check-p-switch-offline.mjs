import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createContext,SourceTextModule,runInContext} from 'node:vm';
import {createCanvas} from '@napi-rs/canvas';
import {inspectOfflineHtml} from './check-offline-html.mjs';
import {assertPStage} from '../tests/fixtures/p-switch-native.mjs';
const [htmlPath,projectPath,mode]=process.argv.slice(2),checked=inspectOfflineHtml(fs.readFileSync(htmlPath,'utf8'),{collection:mode==='collection'}),project=JSON.parse(fs.readFileSync(projectPath,'utf8'));let networkRequests=0;
const context=createContext({console,structuredClone,crypto:globalThis.crypto,fetch:()=>{networkRequests++;throw Error('Offline P Switch fixture cannot use network');}}),modules=new Map();for(const [id,source]of checked.modules)modules.set(id,new SourceTextModule(source,{context,identifier:id}));
const link=id=>{assert(modules.has(id),'Missing actual embedded P dependency '+id);return modules.get(id);},stage=modules.get('workshop/editor-mario-stage.mjs'),motor=modules.get('workshop/editor-mario-motor.mjs'),lighting=modules.get('workshop/editor-smm2-lighting.mjs'),art=modules.get('workshop/editor-smm2-p-switch-art.mjs');
for(const module of [stage,motor,lighting,art]){if(module.status==='unlinked')await module.link(link);if(module.status!=='evaluated')await module.evaluate();}
function local(key,value){context[key]=JSON.stringify(value);return runInContext('JSON.parse('+key+')',context);}
const Stage=options=>stage.namespace.createPlatformStage({...local('stageData',{plan:options.plan,visualRooms:options.visualRooms,initialState:options.initialState,manualDeath:options.manualDeath,autoContinue:options.autoContinue,allowWarp:options.allowWarp}),motor:options.motor,emit:options.emit}),resolve=(room,view)=>{const data=local('lightData',{room,view});return JSON.parse(JSON.stringify(lighting.namespace.resolveSmm2LightSources(data.room,data.view)));};
const report=assertPStage(project,{Stage,Motor:motor.namespace.createPlatformMotor,resolve});const c=createCanvas(16,16).getContext('2d'),a=local('actorData',{x:0,y:0,w:16,h:16,smm2PSwitch:{phase:'live',orientation:'down'}});assert(art.namespace.drawSmm2PSwitch(c,a));assert(c.getImageData(0,0,16,16).data.some(q=>q!==0));assert.equal(networkRequests,0);console.log(JSON.stringify({...report,collection:mode==='collection',actualEmbeddedStageExecuted:true,actualEmbeddedMotorExecuted:true,actualEmbeddedLightingExecuted:true,actualEmbeddedPArtExecuted:true,networkRequests,moduleCount:checked.moduleCount}));
