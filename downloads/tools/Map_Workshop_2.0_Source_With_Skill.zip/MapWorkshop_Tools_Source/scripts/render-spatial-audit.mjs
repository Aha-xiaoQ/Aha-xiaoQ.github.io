import fs from 'node:fs';
import {nativeSession} from '../tests/fixtures/shell-coin-native.mjs';
import {nativeWorld} from '../render-lantern-course-native-canvas.mjs';
const input=process.argv[2]||'../examples/minecraft-adventure/blast-trail.qmap.json';
const out=new URL('../examples/minecraft-adventure/spatial-audit/',import.meta.url);fs.mkdirSync(out,{recursive:true});
const d=JSON.parse(fs.readFileSync(new URL(input,import.meta.url)));for(const r of d.rooms){const doc=structuredClone(d);doc.rooms.sort((a,b)=>(a.roomId===r.roomId?-1:b.roomId===r.roomId?1:0));const s=nativeSession(doc);const v=s.view();const result=nativeWorld(v,doc,{camera:{x:0,y:0,w:r.map.width,h:r.map.height,width:r.map.width,height:r.map.height},scale:2});fs.writeFileSync(new URL(r.roomId+'-whole.png',out),result.canvas.toBuffer('image/png'));result.canvas.width=result.canvas.height=1;console.log(r.roomId,r.map.width,r.map.height);}
