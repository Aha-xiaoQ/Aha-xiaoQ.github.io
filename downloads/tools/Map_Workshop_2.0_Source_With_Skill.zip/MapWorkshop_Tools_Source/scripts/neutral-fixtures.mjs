import {readFile} from 'node:fs/promises';
import {blank,parseProject} from '../atlas/editor-model.mjs';
import {createCollection,addLevel,approveLevel} from '../atlas/editor-collection.mjs';

// These tiny fixtures are newly authored test data. They contain no stock or user maps.
export const NEUTRAL_FIXTURE_NOTE='Synthetic neutral tools verification fixture; not a user-authored course or an original-game transcription.';
export const NEUTRAL_LEVEL_IDS=Object.freeze(['neutral-first','neutral-second']);

function room(title,roomId='main'){
 const result=blank(title,512,240).rooms[0];
 result.roomId=roomId;result.map.id='neutral-'+roomId;
 result.map.geometry=[{id:'floor',x:0,y:224,w:512,h:16,collision:'solid',material:'ground'}];
 result.map.objects=[
  {id:'start',kind:'spawn',x:32,y:210,w:10,h:14},
  {id:'coin',kind:'coin',x:96,y:210,w:10,h:14},
  {id:'finish',kind:'exit',x:352,y:192,w:16,h:32},
 ];
 result.map.provenance={kind:'original',source:'Neutral tools fixture factory',review:'pending',note:NEUTRAL_FIXTURE_NOTE};
 return result;
}

/** Deterministic authoring fixture built through the real blank/import APIs. */
export function createNeutralProject({second=false}={}){
 const title=second?'Neutral portal fixture':'Neutral editor fixture';
 const project=blank(title,512,240);
 project.id=second?'neutral-project-second':'neutral-project-first';
 project.fixture={kind:'synthetic-neutral',note:NEUTRAL_FIXTURE_NOTE};
 project.rooms=[room(title)];
 if(second){
  project.rooms[0].map.objects=project.rooms[0].map.objects.filter(object=>object.kind!=='exit');
  project.rooms[0].map.geometry.push({id:'portal-pipe',x:320,y:192,w:32,h:32,collision:'solid',material:'pipe-side'});
  project.rooms[0].map.objects.push({id:'portal',kind:'portal',x:308,y:192,w:16,h:32,targetRoom:'annex',targetSpawn:'start'});
  project.rooms.push(room('Neutral annex','annex'));
 }
 return parseProject(JSON.stringify(project));
}

/** Approval records apply only to these explicitly synthetic test fixtures. */
export function createNeutralCollection(){
 let collection=createCollection({id:'neutral-tools-collection',title:'Neutral two-level tools fixture',fixture:{kind:'synthetic-neutral',note:NEUTRAL_FIXTURE_NOTE}});
 for(const [index,id] of NEUTRAL_LEVEL_IDS.entries()){
  collection=addLevel(collection,createNeutralProject({second:index===1}),{id,entryRoom:'main'});
  collection=approveLevel(collection,id,'Synthetic neutral fixture owner action only; this is not approval of any user map');
 }
 return collection;
}

export async function readCharacterProfile(){
 return JSON.parse(await readFile(new URL('../atlas/runtime/character.json',import.meta.url),'utf8'));
}
