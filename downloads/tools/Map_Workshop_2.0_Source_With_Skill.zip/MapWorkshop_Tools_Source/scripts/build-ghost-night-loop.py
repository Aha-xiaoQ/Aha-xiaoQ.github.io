"""Reproduce the documented private-study loop from the supplied original sample.
No network access or source-video audio extraction. Requires the installed ffmpeg.
"""
from pathlib import Path
import hashlib, json, math, subprocess, wave
import numpy as np

root = Path(__file__).resolve().parents[1]
source = root / 'atlas/assets/smm2-ghost-private/SMM2_SMB_Ghost_House_Night.oga'
target = root / 'atlas/assets/classic-audio/ghost-house-night-loop.wav'
expected = 'ca38ddc2ab8991183cd0038727b526a27651ec0f8edc6d510b074d100d6fd03b'
assert hashlib.sha256(source.read_bytes()).hexdigest() == expected
raw = subprocess.run(['ffmpeg', '-v', 'error', '-i', str(source), '-f', 'f32le', '-ac', '2', '-ar', '44100', '-'], check=True, capture_output=True).stdout
samples = np.frombuffer(raw, '<f4').reshape(-1, 2)
assert len(samples) == 1323000
start, end = 44982, 985782
cycle = samples[start:end]
assert len(cycle) == 940800 and np.max(np.abs(cycle)) < 1
pcm = np.clip(np.rint(cycle * 32768), -32768, 32767).astype('<i2')
with wave.open(str(target), 'wb') as wav:
    wav.setnchannels(2); wav.setsampwidth(2); wav.setframerate(44100); wav.writeframes(pcm.tobytes())
decoded = pcm.astype(np.float64) / 32768
meta = {
    'version': 1, 'source_file': str(source.relative_to(root)), 'source_sha256': expected,
    'source_page': 'https://www.mariowiki.com/File:SMM2_SMB_Ghost_House_Night.oga',
    'artist': 'Nintendo', 'rights': 'Original game audio, separate from the workshop code licence; private learning scope',
    'output_file': str(target.relative_to(root)), 'output_sha256': hashlib.sha256(target.read_bytes()).hexdigest(),
    'format': 'PCM s16le stereo 44100 Hz', 'crop_start_sample_inclusive': start, 'crop_end_sample_exclusive': end,
    'duration_samples': len(pcm), 'duration_seconds': len(pcm) / 44100,
    'seam_sample_jump': float(np.max(np.abs(decoded[-1] - decoded[0]))),
    'seam_sample_jump_dbfs': 20 * math.log10(float(np.max(np.abs(decoded[-1] - decoded[0])))),
    'rms': float(np.sqrt(np.mean(decoded ** 2))), 'peak': float(np.max(np.abs(decoded))),
    'maximum_quantization_error': float(np.max(np.abs(decoded - cycle))),
    'speed_or_pitch_change': False, 'blend_applied': False, 'runtime_music_volume': .35,
    'evidence': 'A 21⅓s recurring catalogue-sample phrase; matching 200ms neighbourhood correlation 0.99847',
    'limits': ['Derived loop, not original game loop metadata', 'Begins at a quiet phase 1.02s into the sample', 'No auditory seam review was available', 'No verified hurry variant; keep the same theme below 100 seconds']
}
(target.parent / 'GHOST_NIGHT_LOOP_PROVENANCE.json').write_text(json.dumps(meta, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'file': str(target), 'bytes': target.stat().st_size, 'sha256': meta['output_sha256'], 'seam_dbfs': meta['seam_sample_jump_dbfs']}))
