// Real embedded Stage/play plus source RGBA in a synthetic DOM and real Canvas.
// No physical browser, hardware input or original Nintendo timing is claimed.
import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {createContext,SourceTextModule,runInContext} from 'node:vm';
import {createCanvas,loadImage} from '@napi-rs/canvas';
import {offlineFile} from '../atlas/editor-offline.mjs';
import {inspectOfflineHtml} from './check-offline-html.mjs';
import {drawObject} from '../atlas/editor-art.mjs';
import {drawDoor} from '../atlas/editor-contraptions-art.mjs';
import {SMM1_SMB1_KEY_DOOR_SOURCE_PIXELS as sources} from '../atlas/editor-smm1-key-door-source-pixels.mjs';
import {smb1KeyDoorArtProject,runKeyDoorArtFixture} from '../tests/fixtures/smb1-key-door-art.mjs';
import {nativeSession} from '../tests/fixtures/shell-coin-native.mjs';
import {mountPlacementEditor} from '../tests/fixtures/placement-editor-dom.mjs';
import {installLightingRenderDom} from '../tests/fixtures/lighting-render-dom.mjs';
import {nativeWorld} from '../render-lantern-course-native-canvas.mjs';

const root=new URL('../atlas/',import.meta.url),doc=smb1KeyDoorArtProject(),base=nativeSession(doc);
const html=await offlineFile(base.pack,doc.rooms,p=>fs.readFile(new URL(p,root),'utf8'),p=>fs.readFile(new URL('assets/classic-audio/'+p,root))),checked=inspectOfflineHtml(html);
assert(checked.moduleCount>=60);for(const id of ['editor-walking-koopa.mjs','editor-walking-koopa-art.mjs','editor-conveyor-surfaces.mjs','editor-npc-spring-contacts.mjs'])assert(checked.modules.has('workshop/'+id));assert.equal(checked.moduleCount,checked.reachableModuleCount);assert(checked.modules.has('workshop/editor-smm1-key-door-source-pixels.mjs'));
const bytes=c=>c.getContext('2d').getImageData(0,0,c.width,c.height).data;
const originals={};for(const [name,file]of [['smb1Key','SMM-SMB-Key.original.png'],['smb1UnlockedDoor','SMM-SMB-Unlocked-Door.original.png']])originals[name]=await loadImage(await fs.readFile(new URL('assets/smm1-key-door-private/'+file,root)));
let networkRequests=0,rasterScenes=0;
// Initialize local classic and HUD caches with native Canvas before DOM wrappers.
runKeyDoorArtFixture({session:base,onFrame(view){if([1,64].includes(view.tick))nativeWorld(view,doc);}});
const ui=installLightingRenderDom();
try{
 class EmbeddedImage extends globalThis.Image{set src(value){assert(String(value).startsWith('data:image/'));this._src=value;}get src(){return this._src;}}
 class EmbeddedAudio extends globalThis.Audio{set src(value){assert(String(value).startsWith('data:audio/'));this._src=value;}get src(){return this._src;}}
 const context=createContext({console,URL,Blob,atob,btoa,TextEncoder,TextDecoder,ArrayBuffer,Uint8Array,Uint8ClampedArray,structuredClone,crypto:globalThis.crypto,document:globalThis.document,window:globalThis.window,navigator:globalThis.navigator,performance:globalThis.performance,Image:EmbeddedImage,Audio:EmbeddedAudio,Option:globalThis.Option,FontFace:globalThis.FontFace,requestAnimationFrame:globalThis.requestAnimationFrame,cancelAnimationFrame:globalThis.cancelAnimationFrame,setTimeout,clearTimeout,fetch(){networkRequests++;throw Error('Key/door source art must remain offline');}}),modules=new Map();
 for(const [id,source]of checked.modules)modules.set(id,new SourceTextModule(source,{context,identifier:id}));
 const link=id=>{assert(modules.has(id),'closed module '+id);return modules.get(id);},play=modules.get('workshop/editor-play.mjs');await play.link(link);await play.evaluate();
 assert.deepEqual(JSON.parse(JSON.stringify(modules.get('workshop/editor-smm1-key-door-source-pixels.mjs').namespace.SMM1_SMB1_KEY_DOOR_SOURCE_PIXELS)),sources);
 const art=modules.get('workshop/editor-art.mjs').namespace,doors=modules.get('workshop/editor-contraptions-art.mjs').namespace,generic=modules.get('workshop/editor-smm2-source-assets.mjs').namespace;
 for(const [name,src]of Object.entries(sources)){const actual=createCanvas(src.w,src.h),expected=createCanvas(src.w,src.h);generic.drawSmm2SourcePixels(actual.getContext('2d'),name,{x:0,y:0});expected.getContext('2d').drawImage(originals[name],0,0);assert.deepEqual(bytes(actual),bytes(expected));rasterScenes++;}
 const local=(key,value)=>{context[key]=JSON.stringify(value);return runInContext('JSON.parse('+key+')',context);};
 const Stage=options=>modules.get('workshop/editor-mario-stage.mjs').namespace.createPlatformStage({...local('stageInput',{plan:options.plan,visualRooms:options.visualRooms,initialState:options.initialState,manualDeath:options.manualDeath,autoContinue:options.autoContinue,allowWarp:options.allowWarp}),motor:options.motor,emit:options.emit});
 const embedded=nativeSession(doc,{Stage,Motor:modules.get('workshop/editor-mario-motor.mjs').namespace.createPlatformMotor}),control=nativeSession(doc);
 runKeyDoorArtFixture({session:embedded,onFrame(view){
  const other=control.step(embedded.inputs.at(-1));assert.deepEqual(JSON.parse(JSON.stringify(view)),JSON.parse(JSON.stringify(other)));assert.deepEqual(embedded.events,control.events);
  if(!view.items.some(o=>o.kind==='key')&&!view.contraptions.doors.some(o=>o.unlocked===true))return;
  const before=JSON.stringify(view),r={...doc.rooms.find(q=>q.roomId===view.roomId),contraptionsView:view.contraptions},a=createCanvas(384,240),b=createCanvas(384,240);
  for(const actor of view.items){art.drawObject(a.getContext('2d'),actor,view.tick,r);drawObject(b.getContext('2d'),actor,view.tick,r);}
  for(const door of view.contraptions.doors){doors.drawDoor(a.getContext('2d'),door,r);drawDoor(b.getContext('2d'),door,r);}assert.deepEqual(bytes(a),bytes(b));
  const camera={x:0,y:0,w:384,h:240},actual=nativeWorld(view,doc,{camera,showPlayer:false,scale:1}).canvas,without={...view,items:view.items.filter(o=>o.kind!=='key')},expected=nativeWorld(without,doc,{camera,showPlayer:false,scale:1}).canvas;
  for(const actor of view.items.filter(o=>o.kind==='key'))expected.getContext('2d').drawImage(originals.smb1Key,Math.round(actor.x+(actor.w-14)/2),Math.round(actor.y+actor.h-16));assert.deepEqual(bytes(actual),bytes(expected));assert.equal(JSON.stringify(view),before);rasterScenes++;
 }});
 const body=html.match(/<body>([\s\S]*?)<script type="importmap">/);assert(body);ui.document.body.innerHTML=body[1];const bootstrap=new SourceTextModule(checked.root,{context,identifier:'key-door-bootstrap'});await bootstrap.link(link);await bootstrap.evaluate();await ui.document.getElementById('start').onclick();const output=ui.document.querySelector('dialog canvas');assert(output?.workshopRead);
 let frames=0;const advance=until=>{while(!until(output.workshopRead())){ui.frames();assert(++frames<360,'ordinary offline key/door inputs must finish');}};
 advance(v=>v.tick>=3);ui.key('Space');advance(v=>v.contraptions.keys===1);ui.release('Space');advance(v=>v.tick>=64);ui.key('ArrowRight');advance(v=>v.p.x>=160);ui.release('ArrowRight');ui.key('ArrowUp');advance(v=>v.roomId==='return');ui.release('ArrowUp');ui.key('ArrowRight');advance(v=>v.p.x>=80);ui.release('ArrowRight');const returnTick=output.workshopRead().tick;advance(v=>v.tick>=returnTick+30);
 assert.equal(output.workshopRead().contraptions.keys,0);assert(output.workshopRead().contraptions.doors.every(q=>q.unlocked===true));
 const expectedDoor=createCanvas(32,64);expectedDoor.getContext('2d').imageSmoothingEnabled=false;expectedDoor.getContext('2d').drawImage(originals.smb1UnlockedDoor,0,0,32,64);
 const bottom=output.drawCalls.findLast(q=>q.kind==='rect'&&q.fill==='#1f1f1fff'&&q.w===32&&q.h===2);assert(bottom,'actual source door bottom stripe locates the shared camera projection');assert.deepEqual(output.actualCanvas.getContext('2d').getImageData(bottom.x,bottom.y-62,32,64).data,bytes(expectedDoor));rasterScenes++;
 ui.document.querySelector('dialog')?.close();
}finally{ui.restore();}

// Actual editor state overlay: plain controller doors already emit true.
for(const nonDesert of [false,true]){
 const project=smb1KeyDoorArtProject();project.activeRoomId='return';if(nonDesert)for(const r of project.rooms)delete r.contraptions.scene;
 const editor=await mountPlacementEditor(project);
 try{const image=editor.$('canvas').raster,expected=createCanvas(16,32);expected.getContext('2d').drawImage(originals.smb1UnlockedDoor,0,0);assert.deepEqual(image.getContext('2d').getImageData(32,192,16,32).data,bytes(expected));assert.deepEqual(editor.document(),project);rasterScenes++;}finally{editor.restore();}
}
assert.equal(networkRequests,0);
console.log(JSON.stringify({actualEditorPreviewExecuted:true,embeddedArtExecuted:true,actualEmbeddedStageExecuted:true,actualEmbeddedMotorExecuted:true,actualEmbeddedPlayExecuted:true,actualEmbeddedBootstrapExecuted:true,nativeVideoRendererExecuted:true,stateUnchanged:true,moduleCount:checked.moduleCount,reachableModuleCount:checked.reachableModuleCount,networkRequests,rasterScenes,nativeInputFrames:base.inputs.length,nativeKeyCollections:1,nativeDoorUnlocks:1,originalAnimationCalibrated:false}));
