import fs from 'node:fs';
import crypto from 'node:crypto';
import {createCanvas} from '@napi-rs/canvas';
import {nativeSession} from '../tests/fixtures/shell-coin-native.mjs';
import {nativeWorld} from '../render-lantern-course-native-canvas.mjs';
import {drawMinecraftWorld,drawMinecraftForeground,minecraftIronGolemArtPlan,minecraftParryArtPlan} from '../atlas/editor-minecraft-art.mjs';
const root=new URL('../examples/minecraft-adventure/',import.meta.url),doc=JSON.parse(fs.readFileSync(new URL('blast-trail.qmap.json',root))),out=new URL('evidence/',root);
fs.mkdirSync(out,{recursive:true});
const shots=[];
for(const [name,id,x,y] of [['home','home',0,0],['burrow','burrow',0,0],['village','main',720,0],['forest','main',80,0],['mine','cave',176,32],['ore-gallery','cave',1136,0],['nether-fortress','nether',480,32],['stronghold','stronghold',176,64],['end','end',320,64]]){
 const d=structuredClone(doc),index=d.rooms.findIndex(r=>r.roomId===id);if(index<0)continue;const [r]=d.rooms.splice(index,1);d.rooms.unshift(r);
 const s=nativeSession(d);s.frames(24);const v=s.view(),frame=nativeWorld(v,d,{camera:{x,y,w:512,h:320},scale:2}),file=`r8-native-${name}-depth.png`;
 fs.writeFileSync(new URL(file,out),frame.canvas.toBuffer('image/png'));shots.push({file,room:id,camera:{x,y,w:512,h:320},tick:v.tick,source:'Actual native stage initial state, camera-only spatial inspection; no gameplay-route claim'});frame.canvas.width=1;
}
// Actual cart boarding and idle riding drive the guard's canonical uppercut.
{
 const d=structuredClone(doc),index=d.rooms.findIndex(r=>r.roomId==='cave');if(index>=0){const [r]=d.rooms.splice(index,1);d.rooms.unshift(r);const s=nativeSession(d);let jump=0,riding=false,captured=new Set();
  for(let i=0;i<900;i++){const v=s.view(),p=v.p;if(p.support==='mc-wood-minecart')riding=true;let input={};if(!riding){input.x=Math.abs(142-p.x)<1.3&&Math.abs(p.vx)<.15?0:Math.sign(142-p.x-p.vx*7);if(p.x>82&&p.grounded&&jump<=0)jump=40;if(jump-->0)input.jump=true;}s.step(input);const next=s.view(),g=next.minecraft?.exploration?.golem;
   const key=g?.state==='uppercut'&&g.armLift>=.7&&next.minecraft.exploration.railZombie?.age>=4?'uppercut':g?.rose?'poppy':null;if(key&&!captured.has(key)){captured.add(key);const file=`r8-native-golem-${key}.png`,frame=nativeWorld(next,d,{camera:{x:280,y:32,w:512,h:320},scale:2});fs.writeFileSync(new URL(file,out),frame.canvas.toBuffer('image/png'));shots.push({file,room:'cave',tick:next.tick,source:'Native per-room scenario, ordinary movement and jump onto cart then idle; no controller state injection'});frame.canvas.width=1;}
   if(captured.size===2||next.p.dead||next.p.dying)break;
  }
 }
}
// Actual per-room ordinary input starts the pressure-plate sequencer.
{
 const d=structuredClone(doc),index=d.rooms.findIndex(r=>r.roomId==='stronghold');if(index>=0){const [r]=d.rooms.splice(index,1);d.rooms.unshift(r);const s=nativeSession(d);
  try{s.until(v=>v.minecraft?.workshop?.sequence?.started,{x:1},180);s.until(v=>{const q=v.minecraft?.workshop?.sequence;return q?.age>=160&&q.banks.some(b=>b.lanes?.some(l=>l.pulse>=9));},{},240);
   const v=s.view(),frame=nativeWorld(v,d,{camera:{x:336,y:64,w:512,h:320},scale:2}),file='r8-native-sequencer-active.png';fs.writeFileSync(new URL(file,out),frame.canvas.toBuffer('image/png'));shots.push({file,room:'stronghold',tick:v.tick,sequenceAge:v.minecraft.workshop.sequence.age,source:'Native per-room scenario, ordinary movement onto release plate then idle; no controller state injection'});frame.canvas.width=1;
  }catch(error){shots.push({sequenceCaptureError:String(error)});}
 }
}
const c=createCanvas(1024,448),ctx=c.getContext('2d');ctx.fillStyle='#23343a';ctx.fillRect(0,0,c.width,c.height);ctx.imageSmoothingEnabled=false;
for(const [i,state]of ['idle','approach','windup','uppercut','recover','rose'].entries()){
 ctx.save();ctx.translate(40+i*164,40);ctx.scale(3,3);const r={roomId:'cave',minecraft:{version:1,biome:'cave'},map:{width:50,height:100,geometry:[]},tick:24};
 drawMinecraftWorld(ctx,r,{exploration:{golem:{x:9,y:8,w:24,h:48,state,armLift:state==='uppercut'?1:state==='windup'?-.7:state==='recover'?.5:0,rose:state==='rose',facing:1}}});ctx.restore();ctx.fillStyle='#dce8d4';ctx.font='16px sans-serif';ctx.fillText(state,40+i*164,224);
}
for(const [i,facing]of [1,-1].entries()){
 ctx.save();ctx.translate(250+i*360,276);ctx.scale(3,3);const r={minecraft:{version:1,biome:'cave'}};drawMinecraftForeground(ctx,r,{p:{x:15,y:0,w:14,h:28,facing},minecraft:{gear:{shield:true,guard:{active:true,facing,flash:13,flashKind:'parry'}}}});ctx.restore();
}
fs.writeFileSync(new URL('r8-golem-parry-art-states.png',out),c.toBuffer('image/png'));
fs.writeFileSync(new URL('r8-art-proof-report.json',out),JSON.stringify({renderer:'Actual @napi-rs/canvas nativeWorld using the shared playable art modules',artSourceSha256:Object.fromEntries(['editor-minecraft-art.mjs','editor-minecraft-finale-art.mjs'].map(name=>[name,crypto.createHash('sha256').update(fs.readFileSync(new URL('../atlas/'+name,import.meta.url))).digest('hex')])),realBrowser:false,shots,actorSheet:{file:'r8-golem-parry-art-states.png',source:'Explicit renderer-only pose fixtures, not an ordinary-input gameplay proof'},collisionEdits:false,lighting:'Consistent upper-left light, bright top, mid front, shaded right side',walkableEdges:'All voxel relief clipped inside native collision rectangles; rear architecture uses subdued parallax planes'},null,2));
console.log(JSON.stringify({shots:shots.map(s=>s.file),actorSheet:'r8-golem-parry-art-states.png'}));
