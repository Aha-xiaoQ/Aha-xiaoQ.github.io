import fs from 'node:fs';
import {nativeSession} from '../tests/fixtures/shell-coin-native.mjs';
import {nativeWorld,createNativeCameraTracker} from '../render-lantern-course-native-canvas.mjs';
const root=new URL('../examples/minecraft-adventure/',import.meta.url),doc=JSON.parse(fs.readFileSync(new URL('blast-trail.qmap.json',root))),inputs=JSON.parse(fs.readFileSync(new URL('evidence/ranged-inputs.json',root))),s=nativeSession(doc),tracker=createNativeCameraTracker();
for(let i=0;i<inputs.length;i++){s.step(inputs[i]);const v=s.view(),c=tracker.sample(v);if(v.roomId==='end'&&v.impact?.remaining===5){const out=nativeWorld(v,doc,{camera:{...c,w:c.width,h:c.height},scale:2});fs.writeFileSync(new URL('evidence/r8-native-perfect-parry.png',root),out.canvas.toBuffer('image/png'));console.log(JSON.stringify({frame:i,room:v.roomId,impact:v.impact,health:v.health,ordinaryInput:true}));break;}}
