// Execute only new, neutral ON/OFF-linked lighting acceptance from an export.
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createContext,SourceTextModule,runInContext} from 'node:vm';
import {createCanvas} from '@napi-rs/canvas';
import {inspectOfflineHtml} from './check-offline-html.mjs';
import {assertSwitchLightingStage,assertSwitchLightView} from '../tests/fixtures/lighting-switch-native.mjs';
import {installLightingRenderDom} from '../tests/fixtures/lighting-render-dom.mjs';

const [htmlFile,projectFile,mode]=process.argv.slice(2);
if(!htmlFile||!projectFile)throw Error('Usage: node --experimental-vm-modules scripts/check-lighting-switch-offline.mjs HTML QMAP [collection]');
const html=fs.readFileSync(htmlFile,'utf8'),checked=inspectOfflineHtml(html,{collection:mode==='collection'}),project=JSON.parse(fs.readFileSync(projectFile,'utf8')),ui=installLightingRenderDom();let networkRequests=0;
try{
 const forbidNetwork=()=>{networkRequests++;throw Error('ON/OFF lighting export must execute without network');};
 class EmbeddedImage extends globalThis.Image{set src(value){assert(String(value).startsWith('data:image/'));this._src=value;}get src(){return this._src;}}
 class EmbeddedAudio extends globalThis.Audio{set src(value){assert(String(value).startsWith('data:audio/'));this._src=value;}get src(){return this._src;}}
 const storage=new Map(),context=createContext({console,URL,Blob,atob,btoa,TextEncoder,TextDecoder,ArrayBuffer,Uint8Array,Uint8ClampedArray,structuredClone,crypto:globalThis.crypto,document:globalThis.document,window:globalThis.window,navigator:globalThis.navigator,performance:globalThis.performance,Image:EmbeddedImage,Audio:EmbeddedAudio,Option:globalThis.Option,FontFace:globalThis.FontFace,requestAnimationFrame:globalThis.requestAnimationFrame,cancelAnimationFrame:globalThis.cancelAnimationFrame,setTimeout,clearTimeout,localStorage:{getItem:key=>storage.get(key)??null,setItem:(key,value)=>storage.set(key,value),removeItem:key=>storage.delete(key)},fetch:forbidNetwork,XMLHttpRequest:class{constructor(){forbidNetwork();}},WebSocket:class{constructor(){forbidNetwork();}}}),modules=new Map();
 for(const [id,source]of checked.modules)modules.set(id,new SourceTextModule(source,{context,identifier:id}));
 const link=id=>{assert(modules.has(id),'Missing embedded module '+id);return modules.get(id);},play=modules.get('workshop/editor-play.mjs'),stage=modules.get('workshop/editor-mario-stage.mjs'),motor=modules.get('workshop/editor-mario-motor.mjs'),lighting=modules.get('workshop/editor-smm2-lighting.mjs');assert(modules.has('workshop/editor-switch.mjs'));
 await play.link(link);await play.evaluate();
 const local=(key,value)=>{context[key]=JSON.stringify(value);return runInContext('JSON.parse('+key+')',context);};
 const Stage=options=>stage.namespace.createPlatformStage({...local('stageInput',{plan:options.plan,visualRooms:options.visualRooms,initialState:options.initialState,manualDeath:options.manualDeath,autoContinue:options.autoContinue,allowWarp:options.allowWarp}),motor:options.motor,emit:options.emit});
 const resolve=(room,view)=>{const q=local('lightInput',{room,view});return JSON.parse(JSON.stringify(lighting.namespace.resolveSmm2LightSources(q.room,q.view)));};
 const report=assertSwitchLightingStage(project,{Stage,Motor:motor.namespace.createPlatformMotor,resolve});
 const r=structuredClone(project.rooms[0]);r.smm2Mechanics.lighting={darkness:1,playerRadius:40,softness:0,offRadiusScale:.5,sources:[]};
 const pixel=on=>{const q=local('maskInput',{room:r,view:{roomId:r.roomId,p:{x:59,y:57,w:10,h:14},switchStudy:{version:1,on}}}),canvas=createCanvas(128,128),ctx=canvas.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,128,128);assert(lighting.namespace.drawSmm2LightingMask(ctx,q.room,q.view,{camera:{x:0,y:0,width:128,height:128},createCanvas}));return ctx.getImageData(94,64,1,1).data[0];};assert.equal(pixel(true),255);assert.equal(pixel(false),0);
 const body=html.match(/<body>([\s\S]*?)<script type="importmap">/);assert(body);ui.document.body.innerHTML=body[1];const bootstrap=new SourceTextModule(checked.root,{context,identifier:'switch-lighting-offline-bootstrap'});await bootstrap.link(link);await bootstrap.evaluate();
 const start=mode==='collection'?ui.document.querySelectorAll('button').find(q=>q.textContent==='从第一关开始'):ui.document.getElementById('start');assert(start?.onclick);await start.onclick();const output=ui.document.querySelector('dialog canvas');assert(output?.workshopRead);let frames=0;
 const advance=until=>{while(!until(output.workshopRead())){ui.frames();if(++frames>180)throw Error('Native offline ON/OFF input timed out');}};
 advance(v=>v.tick>=3);ui.key('Space');advance(v=>v.switchStudy?.toggles===1);assert.equal(output.workshopRead().switchStudy.on,false);assertSwitchLightView(project.rooms[0],output.workshopRead(),resolve);
 const offTick=output.workshopRead().tick;advance(v=>v.tick>=offTick+45);assert.equal(output.workshopRead().switchStudy.toggles,1);ui.release('Space');ui.frames(2);ui.key('Space');advance(v=>v.switchStudy?.toggles===2);ui.release('Space');assert.equal(output.workshopRead().switchStudy.on,true);assertSwitchLightView(project.rooms[0],output.workshopRead(),resolve);assert.equal(output.workshopRead().lives,3);
 assert(output.drawCalls.some(q=>q.kind==='image'&&q.sourceWidth===output.width&&q.sourceHeight===output.height&&q.args.length===4),'the actual play renderer executes its lighting mask');ui.document.querySelector('dialog')?.close();assert.equal(networkRequests,0);
 console.log(JSON.stringify({collection:mode==='collection',moduleCount:checked.moduleCount,actualEmbeddedStageExecuted:true,actualEmbeddedMotorExecuted:true,actualEmbeddedSwitchExecuted:true,actualEmbeddedLightingExecuted:true,actualEmbeddedPlayExecuted:true,actualEmbeddedBootstrapExecuted:true,collectionLauncherExecuted:mode==='collection',bootstrapOnOffOn:true,bootstrapFrames:frames,maskExecuted:true,networkRequests,...report}));
}finally{ui.restore();}
