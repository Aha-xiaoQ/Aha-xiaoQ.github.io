import fs from 'node:fs';import crypto from 'node:crypto';import assert from 'node:assert/strict';
import {nativeSession} from '../tests/fixtures/shell-coin-native.mjs';
import {nativeWorld,createNativeCameraTracker} from '../render-lantern-course-native-canvas.mjs';
const root=new URL('../examples/minecraft-adventure/',import.meta.url),out=new URL('evidence/',root),doc=JSON.parse(fs.readFileSync(new URL('blast-trail.qmap.json',root))),tape=JSON.parse(fs.readFileSync(new URL('route-inputs.json',out))),captures=[],saved=new Set();
const save=(name,s,camera,extra={})=>{if(saved.has(name))return;saved.add(name);const v=s.view(),frame=nativeWorld(v,doc,camera?{camera:{...camera,w:camera.width,h:camera.height}}:{}),file='r6-'+name+'.png';fs.writeFileSync(new URL(file,out),frame.canvas.toBuffer('image/png'));frame.canvas.width=frame.canvas.height=1;captures.push({file,frame:s.inputs.length,roomId:v.roomId,player:v.p,health:v.health,guard:v.minecraft?.gear?.guard,trident:v.minecraft?.gear?.trident,lightning:v.minecraft?.storm?.lightning,events:s.events.slice(-8),...extra});};
const route=nativeSession(doc),camera=createNativeCameraTracker();let seenHit=false;
for(let i=0;i<Math.min(tape.length,4800);i++){route.step(tape[i]);const v=route.view(),cam=camera.sample(v),g=v.minecraft?.gear,z=v.minecraft?.storm?.zombies?.find(q=>!q.dead),bolt=v.minecraft?.storm?.lightning?.[0];
 if(i===17)save('storm-intro',route,cam);
 if(v.roomId==='main'&&g?.trident?.state==='flying'&&g.trident.targetId==='storm-zombie'&&g.trident.age>6)save('storm-trident-flight',route,cam);
 if(v.roomId==='main'&&bolt?.age===1){seenHit=true;save('channeling-impact',route,cam,{boltContact:{x:bolt.x,y:bolt.y}});}
 if(seenHit&&v.roomId==='main'&&g?.trident?.state==='returning'&&g.trident.age>11)save('loyalty-return',route,cam);
 if(v.roomId==='cave'&&v.p.x>1620&&v.p.x<1665&&g?.stands?.some(q=>q.available))save('healing-table-full',route,cam);
 if(v.roomId==='cave'&&v.p.x>1690&&g?.stands?.some(q=>!q.available))save('healing-table-used',route,cam);
}
assert(seenHit,'actual Channeling target contact occurred in the ordinary route input tape');
for(const mode of ['block','parry']){const s=nativeSession(doc),cam=createNativeCameraTracker();for(let i=0;i<910;i++){s.step({...tape[i],attack:false});cam.sample(s.view());}let captured=false;
 for(let i=0;i<300;i++){let v=s.view(),z=v.minecraft.storm.zombies.find(q=>!q.dead),gap=z.x-v.p.x-v.p.w,shield=gap<(mode==='block'?28:7)||v.minecraft.gear.guard.active;v=s.step({x:1,shield});const c=cam.sample(v);if(mode==='block'&&gap<70&&gap>40)save('zombie-approach',s,c);if(v.minecraft.gear.guard.flash){assert.equal(v.minecraft.gear.guard.flashKind,mode);assert.equal(v.health,mode==='block'?2.5:3);assert.equal(v.p.h,28);save('shield-'+mode,s,c,{ordinaryInputs:true,source:'Fresh actual map session; route prefix without K, then approach zombie and hold L.'});captured=true;break;}}
 assert(captured,'ordinary '+mode+' contact');fs.writeFileSync(new URL('r6-shield-'+mode+'-inputs.json',out),JSON.stringify(s.inputs));fs.writeFileSync(new URL('r6-shield-'+mode+'-events.json',out),JSON.stringify(s.events,null,2));
}
const exhausted=nativeSession(doc);for(let i=0;i<120;i++){exhausted.step({shield:true});if(exhausted.view().minecraft.gear.guard.reason==='exhausted'){save('shield-broken',exhausted,null,{ordinaryInputs:true});break;}}
const sourceHashes={};for(const name of ['atlas/editor-minecraft-art.mjs','atlas/editor-minecraft-finale-art.mjs','atlas/editor-play.mjs','render-lantern-course-native-canvas.mjs'])sourceHashes[name]=crypto.createHash('sha256').update(fs.readFileSync(new URL('../'+name,import.meta.url))).digest('hex');
fs.writeFileSync(new URL('r6-art-proof-report.json',out),JSON.stringify({evidence:'Actual shared native Canvas renderer over unmodified runtime state. All player/mob/weapon/health states reached through ordinary stage inputs. Not a real-browser screenshot or concept image.',mapSha256:crypto.createHash('sha256').update(JSON.stringify(doc)).digest('hex'),sourceHashes,captures},null,2));console.log(JSON.stringify({count:captures.length,files:captures.map(q=>q.file),sourceHashes},null,2));
