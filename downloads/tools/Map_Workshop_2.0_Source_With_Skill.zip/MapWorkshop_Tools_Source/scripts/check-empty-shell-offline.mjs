// Execute the actual embedded stage/motor with ordinary inputs and no network.
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createContext,SourceTextModule,runInContext} from 'node:vm';
import {inspectOfflineHtml} from './check-offline-html.mjs';
import {nativeSession,settleEmptyShell,sideKickEmptyShell} from '../tests/fixtures/empty-shell-native.mjs';
import {shellPickups,checkPhysicalPickups} from '../tests/fixtures/shell-coin-native.mjs';
const [htmlFile,projectFile]=process.argv.slice(2);
if(!htmlFile||!projectFile)throw Error('Usage: node --experimental-vm-modules scripts/check-empty-shell-offline.mjs HTML QMAP');
const checked=inspectOfflineHtml(fs.readFileSync(htmlFile,'utf8')),project=JSON.parse(fs.readFileSync(projectFile,'utf8'));let networkRequests=0;
const context=createContext({console,URL,TextEncoder,TextDecoder,Uint8Array,Uint8ClampedArray,structuredClone,crypto:globalThis.crypto,fetch(){networkRequests++;throw Error('Offline empty-shell fixture cannot use network');}}),modules=new Map();
for(const [id,source]of checked.modules)modules.set(id,new SourceTextModule(source,{context,identifier:id}));
const link=id=>{assert(modules.has(id),'Missing embedded module '+id);return modules.get(id);},stage=modules.get('workshop/editor-mario-stage.mjs'),motor=modules.get('workshop/editor-mario-motor.mjs');
await stage.link(link);if(motor.status==='unlinked')await motor.link(link);await stage.evaluate();await motor.evaluate();
const EmbeddedStage=options=>{context.stageData=JSON.stringify({plan:options.plan,visualRooms:options.visualRooms,initialState:options.initialState,manualDeath:options.manualDeath,autoContinue:options.autoContinue,allowWarp:options.allowWarp});const local=runInContext('JSON.parse(stageData)',context);return stage.namespace.createPlatformStage({...local,motor:options.motor,emit:options.emit});};
const s=nativeSession(project,{Stage:EmbeddedStage,Motor:motor.namespace.createPlatformMotor});settleEmptyShell(s);s.frames(650);const inert=s.view().enemies[0];assert.equal(inert.type,'beetle');assert.equal(inert.shell,true);assert.equal(inert.emptyShell,true);assert.equal(inert.vx,0);assert.equal(inert.h,16);assert.equal(inert.frame,'');assert.equal(s.view().coins,0);assert.equal(s.view().p.helmet,undefined);assert.equal(s.events.filter(e=>e.event==='player-kick').length,0);
sideKickEmptyShell(s);s.until(v=>v.smm2Mechanics.pinkCoins.keyReleased);s.until(v=>v.contraptions.keys===1);checkPhysicalPickups(s);assert.equal(shellPickups(s).length,3);assert.equal(s.events.find(e=>e.event==='player-kick').source,'side-kick');assert.equal(s.events.filter(e=>e.event==='pink-key-release').length,1);assert.equal(s.view().coins,3);assert.equal(networkRequests,0);
const runs=[];for(const input of s.inputs){const last=runs.at(-1);if(last&&JSON.stringify(last.input)===JSON.stringify(input))last.frames++;else runs.push({frames:1,input});}
console.log(JSON.stringify({kind:'synthetic-neutral',moduleCount:checked.moduleCount,actualEmbeddedStageExecuted:true,actualEmbeddedMotorExecuted:true,naturalInputs:s.inputs.length,stationaryEmptyShellAfter650Frames:true,noAutomaticHelmetPickup:true,physicalShellPickups:3,pinkTaken:3,keyRewards:1,networkRequests,originalTimingCalibrated:false,inputEvidence:{version:1,kind:'synthetic-neutral',inputsOnlyDuringPlay:true,frames:s.inputs.length,runs,contacts:shellPickups(s).map(e=>({frame:e.frame,actorId:e.actorId,coinId:e.coinId,contact:e.contact})),expected:{coins:3,pinkTaken:3,pinkTotal:3,keyReleased:true,keys:1,shellPickups:3,keyReleases:1}}}));
