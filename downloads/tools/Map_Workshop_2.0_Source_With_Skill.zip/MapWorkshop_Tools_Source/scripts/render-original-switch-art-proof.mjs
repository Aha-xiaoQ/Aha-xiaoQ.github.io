import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {createCanvas,loadImage} from '@napi-rs/canvas';
import {drawStudyTile} from '../atlas/editor-switch-art.mjs';
import {SMM2_SMB1_SWITCH_SOURCE_PIXELS as sources} from '../atlas/editor-smm2-switch-source-pixels.mjs';
import {smb1SwitchArtProject} from '../tests/fixtures/smb1-switch-art.mjs';
import {nativeSession} from '../tests/fixtures/shell-coin-native.mjs';
import {mountPlacementEditor} from '../tests/fixtures/placement-editor-dom.mjs';
import {nativeWorld} from '../render-lantern-course-native-canvas.mjs';

const out=path.resolve(process.argv[2]||'validation/original-switch-art'),base=new URL('../atlas/assets/smm2-switch-private/',import.meta.url),ledger=JSON.parse(await fs.readFile(new URL('SOURCE_ASSETS.json',base),'utf8'));
await fs.mkdir(out,{recursive:true});
const board=createCanvas(1120,650),c=board.getContext('2d');c.fillStyle='#20232c';c.fillRect(0,0,board.width,board.height);c.imageSmoothingEnabled=false;c.fillStyle='#ffffff';c.font='20px StudySans';c.fillText('SMB1 ON/OFF source pixels and renderer',24,30);c.font='14px StudySans';c.fillText('Unchanged original PNG',255,60);c.fillText('Prior authored fallback',540,60);c.fillText('Current SMB1 source art',830,60);
const records=[];
for(const [index,[name,entry]] of Object.entries(ledger.assets).entries()){
 const y=82+index*80,src=sources[name],on=name!=='smb1SwitchOff',kind=name.includes('Switch')?'switch':'block',color=name.includes('Blue')?'blue':'red',active=name.endsWith('Active'),d={id:'proof-device',kind,...(kind==='block'?{color}:{}),x:0,y:0,w:16,h:16,...(kind==='block'?{active}:{})},room={switchStudy:{initialOn:on,devices:[d]}},original=createCanvas(20,20),prior=createCanvas(20,20),actual=createCanvas(20,20);
 const raw=await fs.readFile(new URL(entry.file,base)),image=await loadImage(raw);original.getContext('2d').drawImage(image,...src.cellOffset);drawStudyTile(prior.getContext('2d'),{...d,studyDevice:true},{...room,smm2Mechanics:{version:1,art:{palette:'unverified-style'}}});drawStudyTile(actual.getContext('2d'),{...d,studyDevice:true},room);
 c.fillStyle='#ffffff';c.fillText(entry.state,24,y+32);
 for(const [tile,x] of [[original,280],[prior,555],[actual,860]]){c.fillStyle='#141720';c.fillRect(x,y,72,72);c.drawImage(tile,x,y,80,80);}
 records.push({name,file:entry.file,sourceSha256:entry.sha256,sourceRgbaSha256:entry.rgbaSha256,nativeSize:[src.w,src.h],cellOffset:src.cellOffset});
}
c.fillStyle='#ffffff';c.font='14px StudySans';c.fillText('16px switch/solid cell; native 14px inactive outline inset (1,1). Exact source RGBA; no outside-cell shadow.',24,586);c.fillText('Static bright ON/highlight source phase. Original dark ON differs; no blink period or timing claimed.',24,610);c.fillText('Prior column is the unchanged authored fallback, not verified SMB3 art. No gameplay, reward or sound changes.',24,634);
await fs.writeFile(path.join(out,'SMB1_SWITCH_SOURCE_AND_RENDERER_BOARD.png'),board.toBuffer('image/png'));
const session=nativeSession(smb1SwitchArtProject()),framesDir=path.join(out,'native-contact-frames');await fs.mkdir(framesDir,{recursive:true});const trace=[];
for(let frame=0;frame<48;frame++){
 const view=session.step({jump:frame>=3&&frame<23}),image=nativeWorld(view,session.doc,{camera:{x:16,y:128,w:320,h:112},scale:3}).canvas;
 const file=path.join(framesDir,String(frame).padStart(3,'0')+'.png');await fs.writeFile(file,image.toBuffer('image/png'));trace.push({frame:frame+1,on:view.switchStudy.on,toggles:view.switchStudy.toggles,player:view.p,devices:view.switchStudy.devices});
}
const gif=spawnSync('ffmpeg',['-hide_banner','-loglevel','error','-y','-framerate','60','-i',path.join(framesDir,'%03d.png'),'-filter_complex','[0:v]split[a][b];[a]palettegen=reserve_transparent=0[p];[b][p]paletteuse=dither=none','-loop','0',path.join(out,'SMB1_SWITCH_NATIVE_CONTACT.gif')],{encoding:'utf8'});if(gif.status!==0)throw Error(gif.stderr||String(gif.error));
for(const on of [true,false]){
 const doc=smb1SwitchArtProject({on}),editor=await mountPlacementEditor(doc);
 try{await fs.writeFile(path.join(out,'SMB1_SWITCH_ACTUAL_EDITOR_'+(on?'ON':'OFF')+'.png'),editor.$('canvas').raster.toBuffer('image/png'));}finally{editor.restore();}
}
const report={generatedAt:new Date().toISOString(),kind:'original-smb1-switch-source-art-proof',releaseVersion:JSON.parse(await fs.readFile(new URL('../package.json',import.meta.url),'utf8')).version,sourceAssets:records,board:'SMB1_SWITCH_SOURCE_AND_RENDERER_BOARD.png',editorImages:['SMB1_SWITCH_ACTUAL_EDITOR_ON.png','SMB1_SWITCH_ACTUAL_EDITOR_OFF.png'],nativeContactGif:'SMB1_SWITCH_NATIVE_CONTACT.gif',nativeInputFrames:48,nativeToggles:session.view().switchStudy.toggles,nativeEvents:session.events,traceFile:'SMB1_SWITCH_NATIVE_CONTACT_TRACE.json',animationSource:'Actual workshop Stage/motor ordinary jump inputs at 60 engine frames per second; not original Nintendo timing evidence',originalAnimationCalibrated:false,sourcePhaseLimitation:ledger.phaseLimitation,physicsOrBehaviorEdits:false,physicalBrowserTested:false};
await fs.writeFile(path.join(out,'SMB1_SWITCH_NATIVE_CONTACT_TRACE.json'),JSON.stringify(trace,null,2)+'\n');
report.artifacts=[];for(const name of [report.board,...report.editorImages,report.nativeContactGif,report.traceFile]){const bytes=await fs.readFile(path.join(out,name));report.artifacts.push({file:name,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')});}
await fs.writeFile(path.join(out,'SMB1_SWITCH_ART_PROOF.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({outputDirectory:out,sourceStates:records.length,nativeInputFrames:48,nativeToggles:session.view().switchStudy.toggles,originalAnimationCalibrated:false}));
