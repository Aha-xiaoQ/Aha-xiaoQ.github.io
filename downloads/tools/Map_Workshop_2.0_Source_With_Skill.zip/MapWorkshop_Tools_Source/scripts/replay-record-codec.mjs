// Node-only lossless storage for frozen replay evidence. Never imported by the game.
import fs from 'node:fs';
import {promises as fsp} from 'node:fs';
import {createHash} from 'node:crypto';
import {gzipSync,gunzipSync,brotliCompressSync,brotliDecompressSync,constants} from 'node:zlib';
import {fileURLToPath} from 'node:url';
import path from 'node:path';

export const REPLAY_RECORD_FORMAT='map-workshop-frozen-replay-dedup';
// The encoder's established default remains v1. v2 is an explicit storage option.
export const REPLAY_RECORD_CODEC_VERSION=1;
export const REPLAY_RECORD_SUPPORTED_CODEC_VERSIONS=Object.freeze([1,2]);
export const REPLAY_RECORD_DECODE_LIMITS=Object.freeze({maxEnvelopeBytes:128*1024*1024,maxOriginalBytes:512*1024*1024,maxNodes:1_000_000,maxDepth:512});
const serialization='JSON.stringify(record, null, 2) + "\\n"';
const sha256=bytes=>createHash('sha256').update(bytes).digest('hex');
const jsonBytes=value=>Buffer.from(JSON.stringify(value,null,2)+'\n','utf8');
const compactBytes=value=>Buffer.from(JSON.stringify(value),'utf8');
const fail=message=>{throw new Error('Frozen replay codec: '+message);};
const plain=value=>value!==null&&typeof value==='object'&&!Array.isArray(value);
const exactKeys=(value,keys)=>plain(value)&&Object.keys(value).length===keys.length&&keys.every(key=>Object.hasOwn(value,key));
const primitive=value=>value===null||typeof value==='string'||typeof value==='boolean'||(typeof value==='number'&&Number.isFinite(value));
const hash=value=>typeof value==='string'&&/^[a-f0-9]{64}$/.test(value);
function limits(options={}){
 const result={...REPLAY_RECORD_DECODE_LIMITS,...options};
 for(const [key,value] of Object.entries(result))if(!Object.hasOwn(REPLAY_RECORD_DECODE_LIMITS,key)||!Number.isSafeInteger(value)||value<1)fail('invalid decode limit '+key);
 return result;
}
function checkOriginal(original,bounds){
 if(!exactKeys(original,['bytes','sha256','serialization'])||!Number.isSafeInteger(original.bytes)||original.bytes<1||!hash(original.sha256)||original.serialization!==serialization)fail('invalid original-byte metadata');
 if(original.bytes>bounds.maxOriginalBytes)fail('original-byte decode limit exceeded');
}
function gzipEnvelope(envelope){return gzipSync(compactBytes(envelope),{level:9});}
function wrapV2(dagBytes,original){
 const compressed=brotliCompressSync(dagBytes,{params:{[constants.BROTLI_PARAM_QUALITY]:11}});
 return gzipEnvelope({format:REPLAY_RECORD_FORMAT,version:2,original:{...original},payload:{compression:'brotli',bytes:dagBytes.length,sha256:sha256(dagBytes),encoding:'base64',data:compressed.toString('base64')}});
}

/** Encode canonical original JSON as a gzip DAG; choose {version:2} explicitly. */
export function encodeReplayRecordBytes(originalBytes,{version=REPLAY_RECORD_CODEC_VERSION}={}){
 if(!REPLAY_RECORD_SUPPORTED_CODEC_VERSIONS.includes(version))fail('unsupported encoding version');
 const bytes=Buffer.from(originalBytes),record=JSON.parse(bytes.toString('utf8'));
 if(!plain(record))fail('record source must be a JSON object');
 if(!jsonBytes(record).equals(bytes))fail('source must use the documented canonical JSON serialization');
 const nodes=[],interned=new Map();
 const encode=value=>{
  if(primitive(value))return value;
  const node=Array.isArray(value)?[0,value.map(encode)]:[1,Object.entries(value).map(([key,child])=>[key,encode(child)])];
  const key=JSON.stringify(node);let index=interned.get(key);
  if(index===undefined){index=nodes.length;nodes.push(node);interned.set(key,index);}
  return ['ref',index];
 };
 const root=encode(record),original={bytes:bytes.length,sha256:sha256(bytes),serialization};
 const envelope={format:REPLAY_RECORD_FORMAT,version:1,original,nodes,root};
 return version===1?gzipEnvelope(envelope):wrapV2(compactBytes(envelope),original);
}

function decodeV1(envelope,bounds){
 if(!exactKeys(envelope,['format','version','original','nodes','root'])||envelope.format!==REPLAY_RECORD_FORMAT||envelope.version!==1)fail('unsupported or malformed envelope');
 const {original,nodes,root}=envelope;checkOriginal(original,bounds);
 if(!Array.isArray(nodes)||!nodes.length)fail('missing node table');
 if(nodes.length>bounds.maxNodes)fail('node-table decode limit exceeded');
 const reference=(value,limit)=>{
  if(primitive(value))return null;
  if(!Array.isArray(value)||value.length!==2||value[0]!=='ref'||!Number.isSafeInteger(value[1])||value[1]<0||value[1]>=limit)fail('invalid or forward node table index');
  return value[1];
 };
 // Canonical pretty JSON length at depth d = base + indent*d. Checking it
 // before materialization prevents small DAGs from expanding exponentially.
 const sizes=[];
 for(let index=0;index<nodes.length;index++){
  const node=nodes[index];
  if(!Array.isArray(node)||node.length!==2||![0,1].includes(node[0])||!Array.isArray(node[1]))fail('invalid node table entry '+index);
  const keys=new Set();let base=node[1].length?2+4*node[1].length:2,indent=node[1].length?2*node[1].length+2:0,depth=1;
  for(const item of node[1]){
   let value=item;
   if(node[0]===1){
    if(!Array.isArray(item)||item.length!==2||typeof item[0]!=='string'||keys.has(item[0]))fail('invalid or duplicate object key at node '+index);
    keys.add(item[0]);base+=Buffer.byteLength(JSON.stringify(item[0]))+2;value=item[1];
   }
   const ref=reference(value,index),child=ref===null?{base:Buffer.byteLength(JSON.stringify(value)),indent:0,depth:0}:sizes[ref];
   base+=child.base+child.indent;indent+=child.indent;depth=Math.max(depth,child.depth+1);
   if(!Number.isSafeInteger(base)||!Number.isSafeInteger(indent)||base>bounds.maxOriginalBytes||indent>bounds.maxOriginalBytes)fail('expanded-byte decode limit exceeded');
  }
  if(depth>bounds.maxDepth)fail('depth decode limit exceeded');
  sizes.push({base,indent,depth});
 }
 const rootIndex=reference(root,nodes.length);
 if(rootIndex===null||nodes[rootIndex][0]!==1)fail('record root must reference an object');
 if(sizes[rootIndex].base+1!==original.bytes)fail('restored original bytes or SHA-256 mismatch');
 const visited=new Set(),visit=[rootIndex];
 while(visit.length){const index=visit.pop();if(visited.has(index))continue;visited.add(index);const node=nodes[index];for(const item of node[1]){const value=node[0]===1?item[1]:item;if(!primitive(value))visit.push(value[1]);}}
 if(visited.size!==nodes.length)fail('unreachable node table entries');
 const decode=value=>{
  if(primitive(value))return value;
  const node=nodes[value[1]];
  // Each occurrence gets its own mutable container, exactly like JSON.parse.
  return node[0]===0?node[1].map(decode):Object.fromEntries(node[1].map(([key,child])=>[key,decode(child)]));
 };
 const record=decode(root),bytes=jsonBytes(record);
 if(bytes.length!==original.bytes||sha256(bytes)!==original.sha256)fail('restored original bytes or SHA-256 mismatch');
 return {record,bytes,original:{...original},nodeCount:nodes.length,codecVersion:1};
}
function unwrapV2(envelope,bounds){
 if(!exactKeys(envelope,['format','version','original','payload'])||envelope.format!==REPLAY_RECORD_FORMAT||envelope.version!==2)fail('unsupported or malformed envelope');
 checkOriginal(envelope.original,bounds);const p=envelope.payload;
 if(!exactKeys(p,['compression','bytes','sha256','encoding','data'])||p.compression!=='brotli'||p.encoding!=='base64'||!Number.isSafeInteger(p.bytes)||p.bytes<1||!hash(p.sha256)||typeof p.data!=='string')fail('invalid v2 payload metadata');
 if(p.bytes>bounds.maxEnvelopeBytes)fail('inner-envelope decode limit exceeded');
 if(p.data.length%4!==0||/[^A-Za-z0-9+/=]/.test(p.data))fail('invalid v2 base64 payload');
 const compressed=Buffer.from(p.data,'base64');if(compressed.toString('base64')!==p.data)fail('noncanonical v2 base64 payload');
 let dagBytes;
 try{const result=brotliDecompressSync(compressed,{maxOutputLength:Math.min(p.bytes,bounds.maxEnvelopeBytes),info:true});dagBytes=result.buffer;if(result.engine.bytesWritten!==compressed.length)fail('trailing Brotli payload bytes');}catch(error){fail('invalid Brotli payload or decode limit: '+error.message);}
 if(dagBytes.length!==p.bytes||sha256(dagBytes)!==p.sha256)fail('inner-envelope bytes or SHA-256 mismatch');
 let inner;try{inner=JSON.parse(dagBytes.toString('utf8'));}catch(error){fail('invalid inner-envelope JSON: '+error.message);}
 if(!plain(inner)||inner.version!==1)fail('v2 payload must contain a v1 DAG envelope');
 if(!exactKeys(inner.original,['bytes','sha256','serialization'])||['bytes','sha256','serialization'].some(key=>inner.original[key]!==envelope.original[key]))fail('v2 original metadata mismatch');
 return {inner,dagBytes};
}

/** Strictly decode v1/v2; reject malformed data, hashes and bounded expansion. */
export function decodeReplayRecordEnvelope(envelope,options={}){
 const bounds=limits(options);
 if(!plain(envelope)||envelope.format!==REPLAY_RECORD_FORMAT)fail('unsupported or malformed envelope');
 if(envelope.version===1)return decodeV1(envelope,bounds);
 if(envelope.version===2){const result=decodeV1(unwrapV2(envelope,bounds).inner,bounds);return {...result,codecVersion:2};}
 fail('unsupported or malformed envelope');
}

/** Parse legacy JSON, or explicitly gzip-compressed v1/v2 codec storage. */
export function decodeReplayRecordStorage(storageBytes,options={}){
 const storage=Buffer.from(storageBytes),bounds=limits(options);
 if(storage[0]!==0x1f||storage[1]!==0x8b){
  if(storage.length>bounds.maxOriginalBytes)fail('original-byte decode limit exceeded');
  return {record:JSON.parse(storage.toString('utf8')),bytes:storage,original:{bytes:storage.length,sha256:sha256(storage)},nodeCount:null,codecVersion:null};
 }
 let envelope;
 try{envelope=JSON.parse(gunzipSync(storage,{maxOutputLength:bounds.maxEnvelopeBytes}).toString('utf8'));}catch(error){fail('invalid gzip or JSON storage or decode limit: '+error.message);}
 return decodeReplayRecordEnvelope(envelope,bounds);
}

/** Change only storage. Validate full original bytes and preserve the v1 DAG. */
export function recompressReplayRecordStorage(storageBytes,{version=2,...options}={}){
 if(!REPLAY_RECORD_SUPPORTED_CODEC_VERSIONS.includes(version))fail('unsupported encoding version');
 const storage=Buffer.from(storageBytes),bounds=limits(options),before=decodeReplayRecordStorage(storage,bounds);
 let output;
 if(before.codecVersion===null)output=encodeReplayRecordBytes(before.bytes,{version});
 else{
  const envelope=JSON.parse(gunzipSync(storage,{maxOutputLength:bounds.maxEnvelopeBytes}).toString('utf8'));
  const dagBytes=before.codecVersion===1?gunzipSync(storage,{maxOutputLength:bounds.maxEnvelopeBytes}):unwrapV2(envelope,bounds).dagBytes;
  output=version===1?gzipSync(dagBytes,{level:9}):wrapV2(dagBytes,before.original);
 }
 const after=decodeReplayRecordStorage(output,bounds);
 if(!after.bytes.equals(before.bytes))fail('recompression original-byte round-trip mismatch');
 return output;
}

/** Accept a legacy JSON path or its explicit .gz replacement. */
export function resolveReplayRecordPath(file){
 const value=file instanceof URL?fileURLToPath(file):file;
 if(fs.existsSync(value)||typeof value!=='string'||value.endsWith('.gz'))return value;
 return fs.existsSync(value+'.gz')?value+'.gz':value;
}
export function readReplayRecordSync(file,options){return decodeReplayRecordStorage(fs.readFileSync(resolveReplayRecordPath(file)),options).record;}
export async function readReplayRecord(file,options){return decodeReplayRecordStorage(await fsp.readFile(resolveReplayRecordPath(file)),options).record;}
export function readReplayRecordBytesSync(file,options){return decodeReplayRecordStorage(fs.readFileSync(resolveReplayRecordPath(file)),options).bytes;}
export async function readReplayRecordBytes(file,options){return decodeReplayRecordStorage(await fsp.readFile(resolveReplayRecordPath(file)),options).bytes;}

if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const [command,input,output,...flags]=process.argv.slice(2),versionFlag=flags.length===1&&/^--version=[12]$/.test(flags[0])?Number(flags[0].at(-1)):null;
 if(!['compress','recompress','decompress','verify'].includes(command)||!input||(command!=='verify'&&!output)||flags.length>1||(flags.length&&(!['compress','recompress'].includes(command)||versionFlag===null))||(command==='verify'&&output)){
  console.error('Usage: node scripts/replay-record-codec.mjs compress INPUT.json OUTPUT.json.gz [--version=1|2]\n       node scripts/replay-record-codec.mjs recompress INPUT.json[.gz] OUTPUT.json.gz [--version=1|2]\n       node scripts/replay-record-codec.mjs decompress INPUT.json.gz OUTPUT.json\n       node scripts/replay-record-codec.mjs verify INPUT.json[.gz]');process.exitCode=1;
 }else{
  const storage=fs.readFileSync(resolveReplayRecordPath(input));
  if(command==='compress'||command==='recompress'){
   if(!output.endsWith('.gz'))fail('compressed output must have an explicit .gz suffix');
   const version=versionFlag??(command==='compress'?REPLAY_RECORD_CODEC_VERSION:2);
   const compressed=command==='compress'?encodeReplayRecordBytes(storage,{version}):recompressReplayRecordStorage(storage,{version});
   const restored=decodeReplayRecordStorage(compressed);
   if(command==='compress'&&!restored.bytes.equals(storage))fail('compression round-trip mismatch');
   fs.writeFileSync(output,compressed);
   console.log(JSON.stringify({output,codecVersion:restored.codecVersion,storageBytes:compressed.length,originalBytes:restored.bytes.length,originalSha256:sha256(restored.bytes)}));
  }else{
   const restored=decodeReplayRecordStorage(storage);
   if(command==='decompress')fs.writeFileSync(output,restored.bytes);
   console.log(JSON.stringify({...(output?{output}:{}),codecVersion:restored.codecVersion,storageBytes:storage.length,originalBytes:restored.bytes.length,originalSha256:sha256(restored.bytes),nodeCount:restored.nodeCount}));
  }
 }
}
