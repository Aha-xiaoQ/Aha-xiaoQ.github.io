import {readdir} from 'node:fs/promises';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
// Raster verification is mandatory for this source package, never a silent skip.
import '@napi-rs/canvas';
import {buildTools,toolsRoot} from './build-tools.mjs';

// Run the tests in this actual standalone package, including neutral end-to-end tests.
await buildTools();
const testsDirectory=new URL('tests/',toolsRoot);
const tests=(await readdir(testsDirectory)).filter(name=>name.endsWith('.test.mjs')).sort();
if(!tests.some(name=>name.startsWith('tools-neutral-')))throw Error('Neutral verification tests are missing');
console.log(`Verifying ${tests.length} packaged test files after a fresh neutral build`);
const child=spawn(process.execPath,['--test','--test-concurrency=2',...tests.map(name=>fileURLToPath(new URL(name,testsDirectory)))],{cwd:fileURLToPath(toolsRoot),stdio:'inherit'});
child.on('error',error=>{console.error(error);process.exitCode=1;});
child.on('exit',(code,signal)=>{process.exitCode=code??1;if(signal)console.error('Verification terminated by '+signal);});
