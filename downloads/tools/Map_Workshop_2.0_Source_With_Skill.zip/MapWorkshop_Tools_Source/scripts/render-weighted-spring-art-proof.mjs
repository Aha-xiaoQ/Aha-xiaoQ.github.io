// Neutral source/renderer comparison. Reads a real native Spring body; no course
// screenshot crop, injected runtime pose, artwork generation or network fetch.
import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {createCanvas,loadImage} from '@napi-rs/canvas';
import {drawTile,drawParts} from '../atlas/editor-art.mjs';
import {terrainParts} from '../atlas/map-appearance.mjs';
import {smm2WeightedSpringVisualPose} from '../atlas/editor-smm2-spring-art.mjs';
import {SMM1_SMB1_SPRINGBOARD_SOURCE as source} from '../atlas/editor-smm2-spring-source-pixels.mjs';
import {weightedSpringProject,weightedSpringSession} from '../tests/fixtures/weighted-spring-seesaw.mjs';

const out=path.resolve(process.argv[2]||'validation/weighted-spring-art');await fs.mkdir(path.join(out,'frames'),{recursive:true});
const hash=b=>createHash('sha256').update(b).digest('hex');
globalThis.document={createElement:()=>createCanvas(1,1)};
const raw=await fs.readFile(new URL('../atlas/assets/smm2-spring-private/smm1-smb1-springboard-standing.original.png',import.meta.url)),original=await loadImage(raw);
assert.equal(hash(raw),source.sourceSha256);assert.deepEqual([original.width,original.height],[16,16]);
const d=weightedSpringProject({impact:false,playerOnSpring:false}),r=d.rooms[0],authored=r.map.geometry.find(q=>q.material==='spring');
function canvas(w,h){const c=createCanvas(w,h),ctx=c.getContext('2d');ctx.fillStyle='#171d28';ctx.fillRect(0,0,w,h);ctx.imageSmoothingEnabled=false;return c;}
function label(ctx,text,x,y,size=16,color='#dbe3ef'){ctx.fillStyle=color;ctx.font=`${size}px sans-serif`;ctx.fillText(text,x,y);}
function grid(ctx,x,y,w,h,z){for(let yy=0;yy<h;yy++)for(let xx=0;xx<w;xx++){ctx.fillStyle=(xx+yy)%2?'#354054':'#283348';ctx.fillRect(x+xx*z,y+yy*z,z,z);}}
function drawCell(ctx,q,x,bottom,z,{legacy=false,room=r}={}){
 ctx.save();ctx.translate(x-Math.round(q.x)*z,bottom-Math.round(q.y+q.h)*z);ctx.scale(z,z);if(legacy)drawParts(ctx,terrainParts(room,q),room);else drawTile(ctx,q,room);ctx.restore();
}
const board=canvas(1120,800),ctx=board.getContext('2d');label(ctx,'Weighted SMB1 Spring: verified source pixels and current shared renderer',24,34,24);label(ctx,'Standing source: SMM1 SMB1 / Compression and author sizing: explicit adaptations',24,61,17);label(ctx,'No original compressed GIF, compressed animation rip or complete SMM2 sheet obtained',24,85,16,'#ffce89');
const cells=[{x:52,title:'Original PNG 16 x 16',kind:'source'},{x:414,title:'Previous classic composite',kind:'legacy'},{x:776,title:'Current typed standing Spring',kind:'current'}];
for(const cell of cells){label(ctx,cell.title,cell.x,123,19);grid(ctx,cell.x+58,148,16,16,9);if(cell.kind==='source')ctx.drawImage(original,cell.x+58,148,144,144);else drawCell(ctx,authored,cell.x+58,292,9,{legacy:cell.kind==='legacy'});}
label(ctx,'Current native compression: complete source caps / coil-row adaptation / real bottom',24,338,19);
const native=weightedSpringSession({impact:false}),chosen=[];
for(let n=0;n<12;n++){const v=native.step({jump:true}),q=v.geometry.find(q=>q.id==='spring');if([0,2,5,8].includes(n))chosen.push({v,q});}
for(let n=0;n<chosen.length;n++){
 const {v,q}=chosen[n],x=50+n*270,p=smm2WeightedSpringVisualPose(q);label(ctx,`tick ${v.tick}, real h ${q.h.toFixed(2)}`,x,371);grid(ctx,x+40,392,16,16,7);drawCell(ctx,q,x+40,504,7);ctx.fillStyle='#79dbc6';ctx.fillRect(x+35,504,122,2);label(ctx,`bottom ${p.physicalBottom.toFixed(2)}`,x,533,15);label(ctx,`source rows ${p.sourceHeight}`,x,554,15);
}
label(ctx,'Supported source bounds: exact 16 x 16 / authored 32 x 32 at uniform 2x',24,601,19);
const big={...authored,w:32,h:32,y:authored.y-16},bigRoom=structuredClone(r);Object.assign(bigRoom.map.geometry.find(g=>g.id===authored.id),big);
drawCell(ctx,big,450,780,3,{room:bigRoom});label(ctx,'32-square / authored 2x',360,653,15);label(ctx,'Non-square and other source sizes: rejected',652,696,17,'#ffce89');label(ctx,'No smaller visible sprite over a wider invisible collider',652,724,15);
await fs.writeFile(path.join(out,'WEIGHTED_SPRING_SOURCE_BEFORE_AFTER.png'),board.toBuffer('image/png'));

const live=weightedSpringSession({impact:false}),control=weightedSpringSession({impact:false}),trace=[];
for(let n=0;n<36;n++){
 const v=live.step({jump:true}),other=control.step({jump:true}),q=v.geometry.find(q=>q.id==='spring'),before=JSON.stringify(v),p=smm2WeightedSpringVisualPose(q),c=canvas(900,420),ctx=c.getContext('2d');assert.deepEqual(v,other);
 label(ctx,'Same real native Spring body, previous / current shared art',24,34,22);label(ctx,`tick ${v.tick}  x ${q.x.toFixed(2)}  y ${q.y.toFixed(2)}  h ${q.h.toFixed(2)}  bottom ${(q.y+q.h).toFixed(2)}`,24,65,16);label(ctx,'GIF display is 5x slower; physics still steps once at native 60 Hz',24,91,15,'#ffce89');
 const y=338+(q.y+q.h-252)*3;for(const [legacy,x,text] of [[true,215,'PREVIOUS CLASSIC'],[false,620,'CURRENT TYPED SOURCE']]){label(ctx,text,x-82,134,17);grid(ctx,x-16,176,20,28,5);drawCell(ctx,q,x,y,5,{legacy});ctx.fillStyle='#79dbc6';ctx.fillRect(x-12,y,104,2);}
 label(ctx,'Compression reads q.y/q.h and keeps the same actual bottom; no physical-state writes',24,398,15);assert.equal(JSON.stringify(v),before);
 await fs.writeFile(path.join(out,'frames',String(n).padStart(3,'0')+'.png'),c.toBuffer('image/png'));
 trace.push({tick:v.tick,body:{id:q.id,x:q.x,y:q.y,w:q.w,h:q.h,restY:q.restY,restH:q.restH,vx:q.vx,vy:q.vy,grounded:q.grounded,support:q.support,smm2CarrierGeometry:q.smm2CarrierGeometry},visual:p,stateUnchanged:true});
}
execFileSync('ffmpeg',['-nostdin','-y','-hide_banner','-loglevel','error','-framerate','12','-i',path.join(out,'frames','%03d.png'),'-filter_complex','split[a][b];[a]palettegen[p];[b][p]paletteuse','-loop','0',path.join(out,'WEIGHTED_SPRING_NATIVE_COMPRESSION_BEFORE_AFTER.gif')]);
await fs.writeFile(path.join(out,'WEIGHTED_SPRING_NATIVE_ART_TRACE.json'),JSON.stringify(trace,null,2)+'\n');
const offline=JSON.parse(execFileSync(process.execPath,['--experimental-vm-modules',new URL('check-weighted-spring-art-offline.mjs',import.meta.url).pathname],{encoding:'utf8',stdio:['ignore','pipe','pipe']}));
const sourceFiles=['atlas/editor-smm2-source-assets.mjs','atlas/editor-mario-stage.mjs','atlas/editor-mario-motor.mjs','atlas/editor-smm2-carriers.mjs','atlas/editor-smm2-terrain.mjs','tests/fixtures/weighted-spring-seesaw.mjs','tests/fixtures/shell-coin-native.mjs','atlas/editor-art.mjs','atlas/editor-offline.mjs','atlas/editor-smm2-spring-art.mjs','atlas/editor-smm2-spring-source-pixels.mjs','atlas/assets/smm2-spring-private/smm1-smb1-springboard-standing.original.png','atlas/assets/smm2-spring-private/SOURCE_ASSETS.json','atlas/assets/smm2-spring-private/NOTICE.txt','atlas/assets/smm2-private/SOURCE_ASSETS.json','atlas/RECOVERED_ASSET_NOTICE.txt','tests/smm2-weighted-spring-art.test.mjs','scripts/check-weighted-spring-art-offline.mjs','scripts/render-weighted-spring-art-proof.mjs'];
const hashes=Object.fromEntries(await Promise.all(sourceFiles.map(async name=>[name,hash(await fs.readFile(new URL('../'+name,import.meta.url)))])));
const outputs=['WEIGHTED_SPRING_SOURCE_BEFORE_AFTER.png','WEIGHTED_SPRING_NATIVE_COMPRESSION_BEFORE_AFTER.gif','WEIGHTED_SPRING_NATIVE_ART_TRACE.json'];
const outputHashes=Object.fromEntries(await Promise.all(outputs.map(async name=>[name,hash(await fs.readFile(path.join(out,name)))])));
const acceptance={schemaVersion:1,date:'2026-10-05',kind:'neutral-weighted-spring-source-art-proof',source:{originalPngBytes:245,originalPngSha256:source.sourceSha256,sourceRgbaSha256:source.rgbaSha256,sourceGame:source.sourceGame,width:16,height:16,originalCompressedGifObtained:false,completeSmm2AnimationSheetObtained:false},rendering:{standingRgbaExact:true,compression:'original 3-row caps plus source-coil row sampling where space permits; defensive shorter bodies sample cap rows within the real body, authored adaptation',bottomAnchor:'real top Math.round(q.y) and bottom Math.round(q.y + q.h), with every visible pixel bounded by these edges',nativeFrames:36,nativeInput:{jump:true},gifPlayback:'12 fps, 5x slower display of native 60 Hz states',stateUnchanged:true,originalPhysicsCalibrated:false},execution:offline,outputs:outputHashes,sourceFiles:hashes,visualReviewRecord:'WEIGHTED_SPRING_ART_VISUAL_REVIEW.json, recorded separately against actual output hashes; this script does not claim human/browser/hardware validation'};
await fs.writeFile(path.join(out,'WEIGHTED_SPRING_ART_ACCEPTANCE.json'),JSON.stringify(acceptance,null,2)+'\n');console.log(JSON.stringify({out,...offline,board:outputs[0],gif:outputs[1],nativeComparisonFrames:36,sourceFiles:hashes}));
