import {createPlatformMotor} from '../atlas/editor-mario-motor.mjs';
const planningMotor=createPlatformMotor();
function canReturn(player,ball,geometry,width){
 const p={...player},character={capabilities:['jump'],motion:{width:p.w,height:p.h}},q={...ball};let previous={...p};
 for(let k=0;k<42;k++){const old={...q};q.x+=q.vx;q.y+=q.vy;const a=previous.y+previous.h-old.y,b=p.y+p.h-q.y;
  if(p.vy>=0&&p.y>=previous.y&&a<=1.5&&b>=0&&b>a){const t=Math.max(0,Math.min(1,-a/(b-a))),px=previous.x+(p.x-previous.x)*t,qx=old.x+(q.x-old.x)*t;if(px+p.w>qx&&px<qx+q.w)return true;}
  if(p.x+p.w>q.x&&p.x<q.x+q.w&&p.y+p.h>q.y&&p.y<q.y+q.h)return false;
  previous={...p};planningMotor.step(p,{jump:k<4,jumpPressed:k===0},character,{solids:geometry||[],width:width||1408});
 }return false;
}
/** Input-only replay helper for the authored R4 Nether. It observes public
 * positions and telegraphs; it never warps, deals damage, or changes state. */
export function createNetherPilot({secret=false,fight=secret}={}){
 let swordAttempted=false;let phase=fight?'approach-reflection':'exit',hold=0,wasDying=false,previousJump=false;
 const aim=(p,x)=>Math.abs(x-p.x)<1.2&&Math.abs(p.vx)<.15?0:Math.sign(x-p.x-p.vx*7);
 return function netherPilot(view){
  const p=view.p,n=view.minecraft?.nether;if(!p||!n)return {};
  if(p.dying||p.dead){wasDying=true;return {};}
  if(wasDying){phase=fight?'approach-reflection':'exit';hold=0;wasDying=false;}
  let x=1,run=true,attack=false,shield=false;
  if(phase==='approach-reflection'){
   x=aim(p,480);run=p.x<410;
   if(p.grounded&&p.x>215&&p.x<256)hold=30;
   if(Math.abs(p.x-480)<1.5&&Math.abs(p.vx)<.16){phase='reflect';x=0;run=false;}
  }else if(phase==='reflect'){
   x=p.x<478?1:p.x>484?-1:p.facing<0?1:0;run=false;
   const ball=n.fireballs.find(q=>q.state==='hostile'&&q.vx<0&&q.x>p.x);const ready=!view.minecraft.gear?.trident&&!view.minecraft.gear?.cooldown;attack=false;shield=!!ball&&ball.x-p.x<18&&ball.x>p.x;if(n.ghasts.every(q=>q.dead)&&n.bastion?.opened){phase=secret?'vault':'exit';}
   else if(p.grounded&&!hold){
    const ball=n.fireballs.find(q=>q.state==='hostile'&&q.vx<-.2&&q.x>p.x);
    if(ball&&canReturn(p,ball,view.geometry,view.width))hold=4;
   }
  }else if(phase==='vault'){
   x=1;run=true;
   if(p.grounded&&p.x>602&&p.x<672)hold=30;
   if(n.bastion?.reward?.opened&&!n.bastion?.reward?.taken){x=aim(p,n.bastion.reward.x+3);run=false;hold=0;}if(n.bastion?.reward?.taken){phase='return-vault';hold=0;}
  }else if(phase==='return-vault'){
   x=-1;run=false;
   if(p.x<659&&p.grounded&&p.y+p.h>=286){phase='exit';x=1;run=true;}
  }
  if(phase==='exit'){
   x=1;run=true;attack=false;
   const cube=n.magmaCubes.find(q=>!q.dead&&q.x>p.x&&q.x-p.x<64);
   if(p.grounded&&(p.x>215&&p.x<256||p.x>805&&p.x<848||cube))hold=30;
   if(p.grounded&&p.x>580&&p.x<608)hold=8;if(p.grounded&&p.x>=620&&p.x<640&&p.y+p.h>310)hold=4;
  }
  if(phase==='reflect'&&!swordAttempted&&view.minecraft.gear?.primary==='sword'&&n.ghasts.every(q=>q.hp===2)){const fire=n.fireballs.find(q=>q.state==='hostile'&&q.x>p.x&&q.x-p.x<36&&q.y+q.h>p.y+4&&q.y<p.y+26);if(fire&&!view.minecraft.gear.cooldown){swordAttempted=true;attack=true;shield=false;hold=0;}}
  let jump=hold>0;if(p.grounded&&previousJump){jump=false;hold=0;}if(hold>0)hold--;previousJump=jump;const portal=phase==='exit'&&(view.objects||[]).some(q=>q.kind==='portal'&&q.x>1200&&Math.abs(q.x-p.x)<28);return {x,run,attack,shield,jump:portal?false:jump,...(portal?{interact:true}:{})};
 };
}
