/** Same-camera, same-live-state R9/R10 art comparison. No simulation state is patched. */
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createCanvas,loadImage} from '@napi-rs/canvas';
import {nativeSession} from '../tests/fixtures/shell-coin-native.mjs';
import {createGrottoPilot} from './minecraft-grotto-pilot.mjs';
import {nativeWorld} from '../render-lantern-course-native-canvas.mjs';
import {drawMinecraftWorld,drawMinecraftTile} from '../atlas/editor-minecraft-art.mjs';
const mode=process.argv[2]||'after',root=path.resolve('examples/minecraft-adventure'),out=path.join(root,'evidence/r10-materials');
fs.mkdirSync(out,{recursive:true});
const saved=path.join(out,'same-state-fixtures.json'),sha=q=>createHash('sha256').update(q).digest('hex');
let fixture;
if(mode==='before'){
 const doc=JSON.parse(fs.readFileSync(path.join(root,'blast-trail.qmap.json'))),shots=[];
 for(const [name,id,x,y] of [['home','home',0,0],['forest','main',80,0],['village','main',720,0],['grotto','burrow',0,0],['mine','cave',176,32],['ore-gallery','cave',1136,0],['nether','nether',480,32]]){
  const d=structuredClone(doc),index=d.rooms.findIndex(r=>r.roomId===id);assert(index>=0);d.rooms.unshift(...d.rooms.splice(index,1));
  const session=nativeSession(d);session.frames(24);shots.push({name,camera:{x,y,w:512,h:320},view:session.view()});
 }
 fixture={doc,shots,source:'Native room-first scenario, 24 ordinary idle frames, no gameplay-state injection. Camera-only inspection, not an end-to-end route proof.'};fs.writeFileSync(saved,JSON.stringify(fixture));
}else fixture=JSON.parse(fs.readFileSync(saved));
const rows=[],report={mode,renderer:'Actual shared nativeWorld playable renderer and @napi-rs/canvas',realBrowser:false,source:fixture.source,unchangedFixtureSha256:sha(fs.readFileSync(saved)),shots:[],sourceHashes:{}};
for(const shot of fixture.shots){
 const original=JSON.stringify(shot.view),frame=nativeWorld(shot.view,fixture.doc,{camera:shot.camera,scale:2}),again=nativeWorld(shot.view,fixture.doc,{camera:shot.camera,scale:2}),png=frame.canvas.toBuffer('image/png');
 assert.deepEqual(png,again.canvas.toBuffer('image/png'),'same state raster deterministic');assert.equal(JSON.stringify(shot.view),original,'render does not mutate live state');
 const file=`${mode}-${shot.name}.png`;fs.writeFileSync(path.join(out,file),png);rows.push({name:shot.name,image:frame.canvas});report.shots.push({file,roomId:shot.view.roomId,tick:shot.view.tick,camera:shot.camera,pngSha256:sha(png),stateSha256:sha(original),deterministic:true,physicsStateUnchanged:true});again.canvas.width=1;
}
for(const f of ['atlas/editor-minecraft-art.mjs','atlas/editor-minecraft-grotto-art.mjs','atlas/editor-minecraft-enchantment-art.mjs','atlas/editor-minecraft-finale-art.mjs','atlas/editor-mario-motor.mjs'])report.sourceHashes[f]=sha(fs.readFileSync(f));
const sheet=createCanvas(1024,rows.length*346),ctx=sheet.getContext('2d');ctx.imageSmoothingEnabled=false;ctx.fillStyle='#162127';ctx.fillRect(0,0,sheet.width,sheet.height);ctx.font='16px sans-serif';
for(let i=0;i<rows.length;i++){const y=i*346;ctx.fillStyle='#d5dfcc';ctx.fillText(`${rows[i].name} | ${mode==='after'?'R9 / R10, identical live state and camera':'R9 baseline'}`,12,y+20);if(mode==='after'){const before=await loadImage(path.join(out,`before-${rows[i].name}.png`));ctx.drawImage(before,0,y+26,512,320);ctx.drawImage(rows[i].image,512,y+26,512,320);}else ctx.drawImage(rows[i].image,0,y+26,512,320);}
fs.writeFileSync(path.join(out,`${mode}-contact-sheet.png`),sheet.toBuffer('image/png'));fs.writeFileSync(path.join(out,`${mode}-report.json`),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));

if(mode==='after'){
 const c=createCanvas(960,560),ctx=c.getContext('2d');ctx.fillStyle='#253b3c';ctx.fillRect(0,0,c.width,c.height);ctx.imageSmoothingEnabled=false;ctx.font='18px sans-serif';
 const r={roomId:'forest',minecraft:{version:1,biome:'forest'},map:{width:320,height:192,geometry:[],objects:[]},tick:31};
 for(const [row,pose]of ['idle','graze','walk'].entries())for(const [col,[kind,w,h]]of [['cow',30,26],['sheep',26,22],['llama',22,38]].entries()){
  const x=col*320+70,y=row*176+144;ctx.fillStyle='#a9b993';ctx.fillText(`${kind} / ${pose}`,col*320+35,row*176+24);ctx.save();ctx.translate(x,y);ctx.scale(3,3);drawMinecraftWorld(ctx,r,{animals:[{id:kind,kind,x:0,y:-h,w,h,facing:1,state:pose,age:9,speakTicks:pose==='idle'?30:0}]});ctx.restore();ctx.fillStyle='#728a68';ctx.fillRect(col*320+35,y+1,190,2);
 }
 fs.writeFileSync(path.join(out,'animal-original-silhouettes.png'),c.toBuffer('image/png'));
 const swatch=createCanvas(800,220),sc=swatch.getContext('2d');sc.imageSmoothingEnabled=false;sc.fillStyle='#162127';sc.fillRect(0,0,800,220);sc.font='14px sans-serif';
 for(const [i,kind]of ['grass','dirt','stone','wood','planks','sand','obsidian','nether'].entries()){sc.fillStyle='#d5dfcc';sc.fillText(kind,i*100+6,20);sc.save();sc.translate(i*100+4,40);sc.scale(3,3);drawMinecraftTile(sc,{id:'mc-'+kind+'-sample',x:0,y:0,w:30,h:48},r);sc.restore();}
 fs.writeFileSync(path.join(out,'original-material-swatch.png'),swatch.toBuffer('image/png'));
 const current=JSON.parse(fs.readFileSync(path.join(root,'blast-trail.qmap.json')));
 for(const [label,id,x,w]of [['village-animals','main',832,569],['home-sheep','home',400,512]]){const d=structuredClone(current),i=d.rooms.findIndex(q=>q.roomId===id);d.rooms.unshift(...d.rooms.splice(i,1));const session=nativeSession(d);session.frames(31);const v=session.view(),frame=nativeWorld(v,d,{camera:{x,y:0,w,h:320},scale:2});fs.writeFileSync(path.join(out,`after-${label}.png`),frame.canvas.toBuffer('image/png'));report.shots.push({file:`after-${label}.png`,tick:v.tick,roomId:id,camera:{x,y:0,w,h:320},source:'Native live room-first scenario, 31 ordinary idle frames, no state injection',animals:v.minecraft.animals});}
 report.extraSheets={animals:{file:'animal-original-silhouettes.png',source:'Explicit renderer-only pose fixtures, not ordinary-input route proof'},materials:{file:'original-material-swatch.png',source:'Original procedural tile renderer swatch'}};fs.writeFileSync(path.join(out,'after-report.json'),JSON.stringify(report,null,2));
}

if(mode==='after'){
 const d=JSON.parse(fs.readFileSync(path.join(root,'blast-trail.qmap.json'))),index=d.rooms.findIndex(q=>q.roomId==='burrow');d.rooms.unshift(...d.rooms.splice(index,1));const session=nativeSession(d),pilot=createGrottoPilot(),seen=new Set(),shots=[];
 for(let n=0;n<1000&&session.view().roomId==='burrow';n++){
  session.step(pilot(session.view()));const v=session.view(),reward=v.minecraft.grotto?.reward,label=reward?.state==='falling'&&reward.age>=8?'falling':reward?.state==='settled'?'settled':reward?.state==='collected'&&reward.age>=5?'collected':null;
  if(label&&!seen.has(label)){seen.add(label);const file=`after-geode-reward-${label}.png`,frame=nativeWorld(v,d,{camera:{x:0,y:0,w:512,h:320},scale:2});fs.writeFileSync(path.join(out,file),frame.canvas.toBuffer('image/png'));shots.push({file,tick:v.tick,reward:structuredClone(reward),player:structuredClone(v.p),coins:v.coins,health:v.health,maxHealth:v.maxHealth,healthUpgradePulse:v.healthUpgradePulse});}
 }
 assert(session.events.some(q=>q.event==='amethyst-reward-collected'),'ordinary route must physically collect the drop');assert.equal(session.view().roomId,'main');assert(seen.has('falling')&&seen.has('collected'));
 fs.writeFileSync(path.join(out,'geode-reward-inputs.json'),JSON.stringify(session.inputs));fs.writeFileSync(path.join(out,'geode-reward-native-proof.json'),JSON.stringify({source:'Actual native room-first stage and ordinary-input grotto pilot; no actor/mechanic state injection',realBrowser:false,frames:session.inputs.length,returnedRoom:session.view().roomId,lives:session.view().lives,events:session.events.filter(q=>/amethyst/.test(q.event)),shots},null,2));
}
