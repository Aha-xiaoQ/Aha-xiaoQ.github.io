// Explicitly neutral mechanism acceptance. No course generator or private route.
import fs from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {weightedSpringProject,assertNaturalSpringImpact} from '../tests/fixtures/weighted-spring-seesaw.mjs';
import {nativeSession} from '../tests/fixtures/shell-coin-native.mjs';
import {parseProject} from '../atlas/editor-model.mjs';
import {projectPack} from '../atlas/editor-runtime.mjs';
import {offlineFile} from '../atlas/editor-offline.mjs';
import {inspectOfflineHtml} from './check-offline-html.mjs';

const root=new URL('../',import.meta.url),dist=new URL('dist/',root),examples=new URL('examples/',root);
const project=weightedSpringProject();
project.id='neutral-weighted-spring-seesaw';
project.fixture={kind:'synthetic-neutral',note:'Workshop capability acceptance, not a Nintendo course reconstruction or a new complete course. Authored local mass/gravity/impulse values.'};
project.rooms[0].map.provenance={kind:'original',source:'Weighted Springboard neutral mechanism fixture',review:'pending',note:project.fixture.note};
const doc=parseProject(JSON.stringify(project)),character=JSON.parse(await fs.readFile(new URL('atlas/runtime/character.json',root),'utf8'));
const pack=projectPack(doc,'main',character,'neutral-weighted-spring'),session=nativeSession(doc);
let native;
try{native=assertNaturalSpringImpact(session);}finally{session.stage?.dispose?.();}
const html=await offlineFile(pack,doc.rooms,p=>fs.readFile(new URL('atlas/'+p,root),'utf8'),p=>fs.readFile(new URL('atlas/assets/classic-audio/'+p,root)));
const closure=inspectOfflineHtml(html),json=value=>JSON.stringify(value,null,2)+'\n',qmap=json(doc),packJson=json(pack);
await fs.mkdir(dist,{recursive:true});await fs.mkdir(examples,{recursive:true});
const outputs={'neutral-weighted-spring-seesaw.qmap.json':qmap,'neutral-weighted-spring-seesaw.runtime-pack.json':packJson,'neutral-weighted-spring-seesaw.html':html};
for(const [name,data]of Object.entries(outputs))await fs.writeFile(new URL(name,dist),data);
await fs.writeFile(new URL('neutral-weighted-spring-seesaw.qmap.json',examples),qmap);
const report={format:'neutral-weighted-spring-mechanism-acceptance',version:1,kind:'synthetic-neutral',
 actualNativeStage:true,ordinaryInputsOnly:true,manualStateChangesDuringPlay:false,originalTimingCalibrated:false,fullCourseClearClaimed:false,
 native,offlineClosure:{moduleCount:closure.moduleCount,reachableModuleCount:closure.reachableModuleCount},
 files:Object.entries(outputs).map(([name,data])=>({path:'dist/'+name,bytes:Buffer.byteLength(data),sha256:createHash('sha256').update(data).digest('hex')}))};
await fs.writeFile(new URL('neutral-weighted-spring-seesaw.acceptance.json',dist),json(report));
console.log(json({...report,outputDirectory:fileURLToPath(dist)}));
