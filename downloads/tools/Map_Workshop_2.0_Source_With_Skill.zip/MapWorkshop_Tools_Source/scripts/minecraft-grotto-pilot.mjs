/** Ordinary-input route: step off rock, accept real slime rebound, cross sticky
 * stored honey, bonk the embedded geode, then walk through the original door. */
export function createGrottoPilot(){let mode='drop',jump=0;const aim=(p,x)=>Math.abs(x-p.x)<1.3&&Math.abs(p.vx)<.15?0:Math.sign(x-p.x-p.vx*7);const drive=v=>{const p=v.p,g=v.minecraft?.grotto||{};let input={x:1};
 if(mode==='drop'&&g.bounceCount>0)mode='bounce';
 if(mode==='bounce'&&p.support==='mc-honey-grotto-stack')mode='honey';
 if(mode==='honey'&&p.x>=338)mode='geode';
 if(mode==='geode'){input={x:aim(p,386)};if(Math.abs(p.x-386)<3&&p.grounded&&jump<=0)jump=30;if(jump>0){input.jump=true;jump--;}if(g.geodeUsed)mode='collect';}
 if(mode==='collect'){input={x:aim(p,(g.reward?.x??410)),jump:false};if(g.reward?.state==='collected')mode='out';}
 if(mode==='out')input={x:1,interact:true};
 // Missing the initial pad is safe: native jumps use the small recovery step.
 if(mode==='drop'&&p.grounded&&p.y>215){input.jump=true;if(p.x>216&&p.y<245)input.jump=false;}
 return input;};drive.mode=()=>mode;return drive;}
