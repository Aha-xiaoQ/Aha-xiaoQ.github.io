import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
const root=new URL('../',import.meta.url);
const child=spawn(process.execPath,[fileURLToPath(new URL('server.mjs',root))],{cwd:fileURLToPath(root),env:{...process.env,PORT:'0'},stdio:['ignore','pipe','pipe']});
try{
 const address=await new Promise((resolve,reject)=>{
  let text='';const timeout=setTimeout(()=>reject(Error('Dev server did not report its address')),10000);
  child.stdout.on('data',bytes=>{text+=bytes;const match=text.match(/http:\/\/127\.0\.0\.1:\d+/);if(match){clearTimeout(timeout);resolve(match[0]);}});
  child.on('error',error=>{clearTimeout(timeout);reject(error);});
  child.on('exit',code=>{clearTimeout(timeout);reject(Error('Dev server exited early: '+code));});
 });
 const paths=['/','/atlas/editor.mjs','/atlas/editor.css','/atlas/editor-clown-car-art.mjs','/atlas/clown-car-source-data.mjs','/atlas/editor-smm2-shoe-source-pixels.mjs','/atlas/runtime/character.json','/examples/neutral-demo.qmap.json','/examples/neutral-demo.qcollection.json'];
 for(const path of paths){const response=await fetch(address+path);if(response.status!==200||(await response.arrayBuffer()).byteLength===0)throw Error('Dev asset unavailable: '+path);}
 console.log('PASS: standalone dev server serves editor, styles, restored source modules, character and neutral authoring examples');
}finally{child.kill('SIGTERM');}
