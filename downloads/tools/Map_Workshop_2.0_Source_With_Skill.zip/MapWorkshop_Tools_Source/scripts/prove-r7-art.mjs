import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {createCanvas,loadImage} from '@napi-rs/canvas';
import {nativeSession} from '../tests/fixtures/shell-coin-native.mjs';
import {nativeWorld,createNativeCameraTracker} from '../render-lantern-course-native-canvas.mjs';
import {drawMinecraftForeground,minecraftThrowArtPlan,minecraftWildEndermanArtPlan} from '../atlas/editor-minecraft-art.mjs';

const root=new URL('../examples/minecraft-adventure/',import.meta.url),out=new URL('evidence/',root);
fs.mkdirSync(out,{recursive:true});
const doc=JSON.parse(fs.readFileSync(new URL('blast-trail.qmap.json',root))),tape=JSON.parse(fs.readFileSync(new URL('ranged-inputs.json',out))),session=nativeSession(doc),camera=createNativeCameraTracker(),captures=[],saved=new Set();
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
function save(name,v,cam){
 if(saved.has(name))return;saved.add(name);
 const frame=nativeWorld(v,doc,{camera:{...cam,w:cam.width,h:cam.height}}),file='r7-'+name+'.png';
 fs.writeFileSync(new URL(file,out),frame.canvas.toBuffer('image/png'));frame.canvas.width=frame.canvas.height=1;
 const foreground=createCanvas(cam.width,cam.height),ctx=foreground.getContext('2d');ctx.translate(-cam.x,-cam.y);drawMinecraftForeground(ctx,frame.room,v);
 const foregroundPixels=[...ctx.getImageData(0,0,cam.width,cam.height).data].filter((value,i)=>i%4===3&&value>0).length;
 captures.push({file,frame:session.inputs.length,roomId:v.roomId,player:v.p,health:v.health,camera:cam,gear:v.minecraft?.gear,wildEnderman:v.minecraft?.wildEnderman,throwPlan:minecraftThrowArtPlan(frame.room,v),wildPlan:minecraftWildEndermanArtPlan(frame.room,v),foregroundPixels,events:session.events.slice(-8)});
}
let sawEndGrant=false,firstThrowId=null;
for(let i=0;i<tape.length;i++){
 session.step(tape[i]);const v=session.view(),cam=camera.sample(v),g=v.minecraft?.gear,w=v.minecraft?.wildEnderman?.actors?.[0],t=g?.trident;
 if(i===17)save('main-empty-hands',v,cam);
 if(v.roomId==='nether'&&g?.stands?.some(q=>q.available)&&v.p.x>115&&v.p.x<140)save('nether-potion-only',v,cam);
 if(v.roomId==='nether'&&g?.guard?.flashKind==='parry'&&g.guard.flash>0)save('nether-parry',v,cam);
 if(v.roomId==='stronghold'&&v.p.x>630&&w?.state==='calm')save('wild-calm',v,cam);
 if(w?.state==='watching'&&w.stareTicks>=22)save('wild-watching',v,cam);
 if(w?.state==='stared'){save('wild-stared',v,cam);if(w.stateAge>=1)save('wild-stared-shake',v,cam);}
 if(w?.state==='teleporting'&&w.stateAge>=8)save('wild-teleport-warning',v,cam);
 if(w?.state==='grace'&&w.teleportFlash>0)save('wild-teleport-arrival',v,cam);
 if(w?.state==='chase'&&w.stateAge>=5)save('wild-angry-chase',v,cam);
 if(v.roomId==='stronghold'&&v.p.x>848&&v.p.x<880&&v.p.y>288)save('wild-low-refuge',v,cam);
 if(v.roomId==='end'&&g?.stands?.some(q=>q.loyaltyTrident&&q.available)&&v.p.x>60&&!cam.fade)save('end-trident-rack-full',v,cam);
 if(v.roomId==='end'&&g?.loyaltyTrident){sawEndGrant=true;if(!t&&!g.guard?.active)save('end-acquired-empty-hands',v,cam);}
 if(v.roomId!=='end'&&!sawEndGrant)assert(!g?.loyaltyTrident,'no pre-End trident ownership in native replay');
 if(v.roomId==='end'&&t){firstThrowId??=t.id;if(t.id===firstThrowId){if(t.state==='flying'&&t.age===2)save('end-throw-follow-through',v,cam);if(t.state==='flying'&&t.age>=7)save('end-trident-outgoing',v,cam);if(t.state==='returning'&&t.age>=3)save('end-loyalty-return',v,cam);}}
 if(v.roomId==='home'&&!v.completed&&v.p.x>220&&!g?.guard?.active&&!t)save('home-empty-hands',v,cam);
}
for(const name of ['main-empty-hands','nether-parry','wild-calm','wild-stared','wild-teleport-warning','wild-teleport-arrival','wild-angry-chase','end-trident-rack-full','end-acquired-empty-hands','end-throw-follow-through','end-trident-outgoing','end-loyalty-return','home-empty-hands'])assert(saved.has(name),'missing ordinary-input capture: '+name);
for(const name of ['main-empty-hands','end-acquired-empty-hands','home-empty-hands'])assert.equal(captures.find(q=>q.file==='r7-'+name+'.png').foregroundPixels,0,name+' has no held weapon overlay');
assert(session.view().completed,'full input replay completes');
const sourceHashes={};for(const name of ['atlas/editor-minecraft-art.mjs','atlas/editor-minecraft-finale-art.mjs','atlas/editor-minecraft-enderman.mjs','atlas/editor-minecraft-gear.mjs','atlas/editor-play.mjs','render-lantern-course-native-canvas.mjs'])sourceHashes[name]=sha(fs.readFileSync(new URL('../'+name,import.meta.url)));
const report={evidence:'Actual shared native Canvas renderer over unmodified live runtime state. Every player, mob, equipment, guard and teleport state was reached by replaying ordinary inputs on the delivered map. These are native-render captures, not real-browser screenshots or concept images.',mapSha256:sha(fs.readFileSync(new URL('blast-trail.qmap.json',root))),inputSha256:sha(fs.readFileSync(new URL('ranged-inputs.json',out))),sourceHashes,completed:session.view().completed,frames:tape.length,captures};
fs.writeFileSync(new URL('r7-art-proof-report.json',out),JSON.stringify(report,null,2));
// A labeled review sheet uses the same exact saved render pixels at 1:1 size.
const selected=['main-empty-hands','wild-calm','wild-stared','wild-teleport-warning','wild-teleport-arrival','wild-angry-chase','end-trident-rack-full','end-acquired-empty-hands','end-throw-follow-through','end-trident-outgoing','end-loyalty-return','home-empty-hands'];
const images=await Promise.all(selected.map(name=>loadImage(fs.readFileSync(new URL('r7-'+name+'.png',out))))),width=images[0].width,height=images[0].height,cols=3,heading=25,sheet=createCanvas(width*cols,(height+heading)*Math.ceil(images.length/cols)),c=sheet.getContext('2d');
c.imageSmoothingEnabled=false;c.fillStyle='#171b23';c.fillRect(0,0,sheet.width,sheet.height);c.font='14px monospace';c.textBaseline='top';
images.forEach((img,i)=>{const x=(i%cols)*width,y=Math.floor(i/cols)*(height+heading);c.fillStyle='#e6ddec';c.fillText(selected[i],x+8,y+5);c.drawImage(img,x,y+heading);});
fs.writeFileSync(new URL('r7-art-review-sheet.png',out),sheet.toBuffer('image/png'));
console.log(JSON.stringify({count:captures.length,files:captures.map(q=>q.file),completed:report.completed,frames:tape.length,sourceHashes},null,2));
