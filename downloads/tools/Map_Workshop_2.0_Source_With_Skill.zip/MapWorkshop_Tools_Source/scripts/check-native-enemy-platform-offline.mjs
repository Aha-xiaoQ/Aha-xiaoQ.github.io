// Execute the actual embedded Stage and motor with neutral fixtures and no fetch.
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createContext,SourceTextModule,runInContext} from 'node:vm';
import {inspectOfflineHtml} from './check-offline-html.mjs';
import {nativeSession,activate} from '../tests/fixtures/npc-platform-native.mjs';
import {checkPhysicalPickups,shellPickups} from '../tests/fixtures/shell-coin-native.mjs';
const [htmlFile,projectFile,kind='plant',mode='single']=process.argv.slice(2),checked=inspectOfflineHtml(fs.readFileSync(htmlFile,'utf8'),{collection:mode==='collection'}),project=JSON.parse(fs.readFileSync(projectFile,'utf8'));let networkRequests=0;
const context=createContext({console,URL,TextEncoder,TextDecoder,Uint8Array,Uint8ClampedArray,structuredClone,crypto:globalThis.crypto,fetch(){networkRequests++;throw Error('Neutral offline carry cannot use network');}}),modules=new Map();
for(const [id,source]of checked.modules)modules.set(id,new SourceTextModule(source,{context,identifier:id}));
const link=id=>{assert(modules.has(id),'Missing embedded module '+id);return modules.get(id);},stage=modules.get('workshop/editor-mario-stage.mjs'),motor=modules.get('workshop/editor-mario-motor.mjs');
await stage.link(link);if(motor.status==='unlinked')await motor.link(link);await stage.evaluate();await motor.evaluate();
const EmbeddedStage=options=>{context.stageData=JSON.stringify({plan:options.plan,visualRooms:options.visualRooms,initialState:options.initialState,manualDeath:options.manualDeath,autoContinue:options.autoContinue,allowWarp:options.allowWarp});return stage.namespace.createPlatformStage({...runInContext('JSON.parse(stageData)',context),motor:options.motor,emit:options.emit});};
const s=nativeSession(project,{Stage:EmbeddedStage,Motor:motor.namespace.createPlatformMotor});let carriedFrames=0;
if(kind==='shell'){activate(s);s.until(v=>{const e=v.enemies.find(e=>e.id==='shell-body');if(e?.support==='lift')carriedFrames++;return v.coins===2;});checkPhysicalPickups(s);assert.equal(shellPickups(s).length,2);assert(carriedFrames>15);}
else{let up=false,down=false;for(let n=0;n<220;n++){const v=s.step(),e=v.enemies.find(e=>e.id==='plant'),q=v.geometry.find(q=>q.id==='lift');assert.equal(e.support,'lift');assert.equal(e.y+e.h,q.y);up||=q.dy<0;down||=q.dy>0;carriedFrames++;}assert(up&&down);}
assert.equal(networkRequests,0);assert.equal(s.view().lives,3);console.log(JSON.stringify({fixtureKind:'synthetic-neutral',mode,kind,actualEmbeddedStageExecuted:true,actualEmbeddedMotorExecuted:true,moduleCount:checked.moduleCount,carriedFrames,physicalShellPickups:shellPickups(s).length,networkRequests,originalTimingCalibrated:false}));
