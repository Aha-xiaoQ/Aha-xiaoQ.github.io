/** State-reactive ordinary-input workshop traversal. */
export function createWorkshopPilot(){let hold=0,mode='release',target=0,cross=0;const aim=(p,x)=>Math.abs(p.x-x)<2&&Math.abs(p.vx)<.2?0:Math.sign(x-p.x-p.vx*5);return v=>{const p=v.p,w=v.minecraft?.workshop;if(!w)return{x:1,run:true};let x=0,run=false;
 if(mode==='release'){x=aim(p,116);if(w.gateOpen)mode='coal';}
 if(mode==='coal'){x=aim(p,217);if(p.grounded&&Math.abs(p.x-217)<5&&!hold)hold=24;if(w.coal.collected){mode='fuel';hold=0;}}
 if(mode==='fuel'){x=aim(p,278);if(w.coal.state==='fuel')mode='notes';}
 if(mode==='notes'&&p.grounded&&p.x>265&&p.x<335&&!hold)hold=30;
 if(mode==='notes'){const missing=w.plates.findIndex(q=>!q.latched);if(missing<0){mode='cross';}else{target=w.plates[missing].x+3;x=aim(p,target);if(w.furnace.glass===0&&p.x>target-25)x=aim(p,target-25);if(w.furnace.glass>0&&w.plates[missing].pressed&&!w.plates[missing].latched){x=-1;}}}
 if(mode==='cross'){x=1;run=true;if(p.grounded&&p.x<448&&w.complete&&!hold)hold=22;}
 if(p.x>640){x=1;run=true;if(p.grounded&&p.x>770&&p.x<850&&!hold)hold=25;}
 const jump=hold>0;if(hold>0)hold--;return{x,run,jump,...(p.x>904?{interact:true}:{})};};}
