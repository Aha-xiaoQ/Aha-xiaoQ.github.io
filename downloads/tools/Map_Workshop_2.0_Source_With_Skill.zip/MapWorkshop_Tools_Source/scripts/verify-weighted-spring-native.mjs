import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {nativeSession} from '../tests/fixtures/shell-coin-native.mjs';
import {weightedSpringProject,weightedSpringLiftProject,weightedSpringDropProject,weightedSpringCargoProject,assertNaturalSpringImpact,assertNaturalSpringLift,assertNaturalSpringDrop,assertNaturalSpringCargo} from '../tests/fixtures/weighted-spring-seesaw.mjs';
const out=path.resolve(process.argv[2]||'validation/weighted-spring');fs.mkdirSync(out,{recursive:true});
const canonical=value=>JSON.parse(JSON.stringify(value)),sha=bytes=>createHash('sha256').update(bytes).digest('hex'),sources={};
for(const file of ['atlas/editor-mario-stage.mjs','atlas/editor-mario-motor.mjs','atlas/editor-smm2-carriers.mjs','atlas/editor-smm2-terrain.mjs','atlas/editor-smm2-items.mjs','atlas/editor-smm2-thwomps.mjs','tests/fixtures/weighted-spring-seesaw.mjs'])sources[file]=sha(fs.readFileSync(new URL('../'+file,import.meta.url)));
const scenes=[];
for(const [id,build,check]of [['impact',weightedSpringProject,assertNaturalSpringImpact],['lift',weightedSpringLiftProject,assertNaturalSpringLift],['drop',weightedSpringDropProject,assertNaturalSpringDrop],['cargo',weightedSpringCargoProject,assertNaturalSpringCargo]]){
 const project=build(),s=nativeSession(project),actualStep=s.step,frames=[];
 s.step=raw=>{const v=actualStep(raw);frames.push(canonical({tick:v.tick,p:v.p,spring:v.geometry.find(q=>q.id==='spring'),cargo:v.items.find(q=>q.id==='cargo'),thwomp:v.enemies.find(q=>q.id==='weight'),terrain:{seesaws:v.smm2Mechanics.seesaws,surfaces:v.smm2Mechanics.surfaces,events:v.smm2Mechanics.events},carrier:v.smm2Mechanics.carriers.carrierGeometry[0],lives:v.lives,roomId:v.roomId}));return v;};
 const result=canonical(check(s)),bytes=Buffer.from(JSON.stringify(project,null,2)+'\n'),filename='weighted-spring-'+id+'.qmap.json';fs.writeFileSync(path.join(out,filename),bytes);
 scenes.push({id,projectFile:filename,projectSha256:sha(bytes),result,ordinaryInputs:s.inputs,runtimeStateInjection:false,events:canonical(s.events),frames});
}
const report={format:'map-workshop-weighted-spring-acceptance',version:1,sourceVersion:JSON.parse(fs.readFileSync(new URL('../package.json',import.meta.url))).version,sourceHashes:sources,nintendoTimingCalibrated:false,npcSpringBounceUnified:false,existingNativeJumpSoundOnly:true,scenes};fs.writeFileSync(path.join(out,'NATIVE_FOUR_SCENES.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({report:path.join(out,'NATIVE_FOUR_SCENES.json'),scenes:scenes.map(({id,result})=>({id,...result})),runtimeStateInjection:false}));
