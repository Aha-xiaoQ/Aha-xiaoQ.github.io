import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {mountPlacementEditor} from '../tests/fixtures/placement-editor-dom.mjs';
import {placementProject} from '../tests/fixtures/placement-neutral.mjs';
import {parseProject,clone} from '../atlas/editor-model.mjs';
import {projectPack} from '../atlas/editor-runtime.mjs';
import {offlineFile} from '../atlas/editor-offline.mjs';
import {play} from '../atlas/editor-play.mjs';
import {createCanvas} from '@napi-rs/canvas';
const root=fileURLToPath(new URL('../',import.meta.url)),out=path.resolve(process.argv[2]||path.join(root,'validation/material-placement-evidence'));
await fs.mkdir(out,{recursive:true});const project=placementProject(),ui=await mountPlacementEditor(project),report={schemaVersion:1,source:'Actual editor.mjs and editor-play.mjs in simulated DOM with @napi-rs/canvas pixels',browserOrCuaUsed:false,hardwareInputVerified:false,syntheticLogoImageExcluded:true,images:[],checks:[]};let session;
try{
 await ui.png(path.join(out,'editor-legal-content.png'));report.images.push('editor-legal-content.png');ui.$('layer').value='objects';ui.$('layer').onchange();ui.pointer('pointerdown',128,160);assert.match(ui.$('message').textContent,/PICKUP_SOLID_OVERLAP/);await ui.png(path.join(out,'editor-rejected-overlap.png'));report.images.push('editor-rejected-overlap.png');report.rejection=ui.$('message').textContent;ui.pointer('pointerup',128,160);ui.$('save').click();assert.equal(ui.document().rooms[0].map.objects.filter(q=>q.kind==='coin').length,1);report.checks.push('Illegal coin brush rejected with stable IDs and coordinates; author document unchanged');
 ui.$('export').click();const exported=JSON.parse(await ui.downloads.at(-1).blob.text());assert.deepEqual(parseProject(JSON.stringify(exported)),ui.document());await fs.writeFile(path.join(out,'legal-content.qmap.json'),JSON.stringify(exported,null,2)+'\n');report.checks.push('Actual editor export blob reimports with content and matching legacy alias');
 const character=JSON.parse(await fs.readFile(path.join(root,'atlas/runtime/character.json'),'utf8')),pack=projectPack(exported,'main',character,'content-visible-probe');session=await play(pack,clone(exported.rooms),{}, {developerMode:false});const canvas=session.screen.querySelector('canvas');
 const capture=async(name)=>{ui.ui.frames();await fs.writeFile(path.join(out,name),canvas.raster.toBuffer('image/png'));report.images.push(name);return clone(canvas.workshopRead());};
 report.before=await capture('play-content-before.png');ui.ui.key('Space');let frames=0;while(!canvas.workshopRead().items.some(q=>q.kind==='mushroom')){ui.ui.frames();if(++frames>50)throw Error('Real Stage did not bump the content brick');}ui.ui.release('Space');report.emerging=await capture('play-content-emerging.png');while(canvas.workshopRead().items.some(q=>q.kind==='mushroom'&&q.emerge)){ui.ui.frames();if(++frames>100)throw Error('Real content did not finish emerging');}report.after=await capture('play-content-after.png');assert(report.after.geometry.find(q=>q.id==='reward-brick').used);assert(report.after.items.some(q=>q.kind==='mushroom')||report.after.p.power===1);report.checks.push('Normal jump bumps the real brick, emits its mushroom and marks the block used');
 const html=await offlineFile(pack,exported.rooms,p=>fs.readFile(path.join(root,'atlas',p),'utf8'),p=>fs.readFile(path.join(root,'atlas/assets/classic-audio',p)));await fs.writeFile(path.join(out,'Legal_Block_Content_Playable.html'),html);report.checks.push('Self-contained native offline HTML exported from the same qmap and source');
 await fs.writeFile(path.join(out,'report.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({output:out,checks:report.checks,images:report.images,browserOrCuaUsed:false},null,2));
}finally{session?.close();ui.restore();}
