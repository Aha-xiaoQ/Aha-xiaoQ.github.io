import {createPlatformMotor} from '../atlas/editor-mario-motor.mjs';
import {dragonProjectileImpact,dragonBreathFootprint} from '../atlas/editor-minecraft-dragon.mjs';
/** Ordinary input pilot: movement, held jump, timed shield and portal interaction. Reads only
 * visible positions/attack warnings. No pose, HP, timers or checkpoint writes. */
const steer=(p,x)=>Math.abs(x-p.x)<1&&Math.abs(p.vx)<.15?0:Math.sign(x-p.x-p.vx*12);
export function dragonTravel(v,previous,target,{jumpAtTarget=false}={}){
 const p=v.p,axis=steer(p,target),direction=Math.sign(target-p.x),distance=Math.abs(target-p.x),ahead={x:direction>0?p.x+p.w:p.x-22,w:22};
 const blocked=(v.geometry||[]).some(q=>q.collision==='solid'&&!q.hidden&&q.x<ahead.x+ahead.w&&q.x+q.w>ahead.x&&q.y<p.y+p.h-2&&q.y+q.h>p.y+2);
 const launch=p.grounded&&!previous.jump&&((blocked&&distance>8)||(jumpAtTarget&&distance<24));return {x:axis,jump:p.grounded?launch:!!previous.jump};
}
export function dragonPilotInput(v,previousInput={}){
 const p=v.p,d=v.minecraft?.dragon||v.dragon;if(!d)return {};
 if(d.defeated){if(d.deathSequence&&d.deathSequence.age<84)return {x:0};const portal=v.objects?.find(q=>q.id==='end-exit')||{x:688,w:24},target=portal.x+(portal.w-p.w)/2;return {...dragonTravel(v,previousInput,target),interact:Math.abs(p.x-target)<15};}
 const crystal=d.crystals.find(q=>q.active);if(crystal){const target=crystal.x+(crystal.w-p.w)/2,result=dragonTravel(v,previousInput,target);if(p.grounded&&Math.abs(p.x-target)<76&&!previousInput.jump)result.jump=true;return result;}
 const landingX=d.perch.x-16;
 if(d.state==='perch'||d.state==='landing')return dragonTravel(v,previousInput,landingX+25,{jumpAtTarget:d.state==='perch'});
 if(d.state==='telegraph-charge'||d.state==='charge'){const result=dragonTravel(v,previousInput,landingX-68);if(d.chargeAltitude==='low'&&d.state==='charge'){const gap=(p.x-d.head.x)*d.facing;if(p.grounded&&!previousInput.jump&&gap<225&&gap>-115)result.jump=true;}if(d.chargeAltitude==='high')result.jump=false;return result;}
 if(d.state==='telegraph-breath'||d.state==='breath'){
  const target=d.telegraph?.target?.x||d.pools?.[0]?.x||landingX-60;return dragonTravel(v,previousInput,target<landingX?landingX+90:landingX-90);
 }
 return dragonTravel(v,previousInput,landingX-68);
}
/** Predict only from the visible player, cloud and projectile poses. Forecast
 * copies are disposable; the real stage receives ordinary inputs exclusively. */
export function createDragonPilot({reactionFrames=0,stagingX=656,lookAheadFrames=50}={}){
 const motor=createPlatformMotor(),overlap=(a,b)=>a.x+a.w>b.x&&a.x<b.x+b.w&&a.y+a.h>b.y&&a.y<b.y+b.h;
 let previous={},state=null,delay=0;
 return view=>{const d=view.minecraft?.dragon||view.dragon,p=view.p;if(!d)return {};if(d.state!==state){state=d.state;delay=reactionFrames;}if(delay>0){delay--;return {...previous};}
  let input=dragonPilotInput(view,previous);const safeStaging=[stagingX,710,400,140].find(x=>!(d.pools||[]).some(q=>q.y+q.h>=304&&x+22>q.x&&x-12<q.x+q.w))??140;if(!d.crystalsRemaining&&['flight','phase-intro','hurt','telegraph-strafe','strafe'].includes(d.state))input=dragonTravel(view,previous,safeStaging);if(['telegraph-breath','breath','parry-recoil'].includes(d.state))input=dragonTravel(view,previous,d.perch.x+9);if(d.defeated){previous=input;return {...input};}
  const guard=view.minecraft?.gear?.guard,ready=guard&&!guard.cooldown&&guard.stamina>=28,geometry=(view.geometry||[]).filter(g=>!g.hidden),horizon=lookAheadFrames,arena={x:96,y:32,w:640,h:288};
  if(d.state==='deflected'){
   const target=d.telegraph||d.head;input=dragonTravel(view,previous,target.x+15,{jumpAtTarget:true});if(!p.grounded&&previous.jump)input.jump=true;previous=input;return {...input};
  }
  if(ready&&['telegraph-charge','charge'].includes(d.state)){
   input=dragonTravel(view,previous,safeStaging);input.jump=!p.grounded&&!!previous.jump;
   if(d.state==='charge'&&d.chargeAltitude==='high'&&p.grounded&&!previous.jump){const gap=(p.x-d.head.x)*d.facing;if(gap<235&&gap>70)input.jump=true;}
  }
  if(ready){
   let source=null;
   if(d.state==='charge'){for(let t=1;t<=6;t++){const vx=d.facing*(arena.w+272)/76,head={...d.head,x:d.head.x+vx*t},body={...d.body,x:d.body.x+vx*t};if(overlap(p,head)||overlap(p,body)){source=d.head.x+20;break;}}}
   if(source===null)for(const q of d.projectiles){if(!q.reflectable||q.reflected)continue;for(let t=0;t<=6;t++){const a={...q,x:q.x+q.vx*t,y:q.y+q.vy*t},b={...a,x:a.x+q.vx,y:a.y+q.vy};if(dragonProjectileImpact(a,b,geometry,p)?.contact==='actor'){source=q.x+q.w/2;break;}}if(source!==null)break;}
   if(source!==null){input={x:Math.sign(source-p.x-p.w/2)||1,shield:true,jump:!p.grounded&&!!previous.jump};previous=input;return {...input};}
  }
  input.run=!['landing','perch'].includes(d.state);

  const future=Array.from({length:horizon},()=>[]),clouds=(d.pools||[]).map(q=>({...q,starts:Math.max(0,q.warning)}));
  for(const shot of d.projectiles||[]){if(shot.reflected)continue;let q={...shot};for(let t=0;t<horizon;t++){const next={...q,x:q.x+q.vx,y:q.y+q.vy},hit=dragonProjectileImpact(q,next,geometry);future[t].push({before:q,after:next});if(hit){const point={x:hit.x+q.w/2,y:hit.normal.y<0?hit.target.y:hit.y+q.h/2},cloud=dragonBreathFootprint(point,geometry,arena,d.crystals.filter(c=>c.active).map(c=>c.id));if(cloud)clouds.push({...cloud,starts:t+24,life:300});break;}q=next;}}
  const choices=[input,...[-1,0,1].flatMap(x=>[false,true].map(jump=>({x,jump,run:input.run})))];let best=input,bestCost=Infinity;
  for(let index=0;index<choices.length;index++){const choice=choices[index],body={...p};let held=previous.jump,cost=index?4:0;for(let t=0;t<horizon;t++){
    const hit=future[t].some(q=>dragonProjectileImpact(q.before,q.after,geometry,body)?.contact==='actor')||clouds.some(q=>q.life>t&&t>=q.starts&&overlap(body,q));if(hit)cost+=10000/(t+1);
    const jump=choice.jump;motor.step(body,{...choice,jump,jumpPressed:!!jump&&!held},{},{solids:geometry,width:832});held=jump;
    if(!ready&&['charge','telegraph-charge'].includes(d.state)){const wait=d.state==='telegraph-charge'?(d.telegraph?.ticks||0):0,elapsed=t-wait;if(elapsed>=0){const vx=d.facing*(arena.w+272)/76,head=d.state==='charge'?{...d.head,x:d.head.x+vx*(t+1)}:{...d.head,x:(d.facing>0?arena.x-136:arena.x+arena.w+96)+vx*elapsed},bossBody={...d.body,x:d.facing>0?head.x-78:head.x+22};if(overlap(body,head)||overlap(body,bossBody))cost+=20000/(t+1);}}
   }
   cost+=Math.abs(body.x-(p.x+(input.x||0)*65))*.7;if(input.jump&&!choice.jump)cost+=32;if(!input.jump&&choice.jump)cost+=8;
   if(cost<bestCost){bestCost=cost;best=choice;}
  }
  previous=best;return {...best};
 };
}
