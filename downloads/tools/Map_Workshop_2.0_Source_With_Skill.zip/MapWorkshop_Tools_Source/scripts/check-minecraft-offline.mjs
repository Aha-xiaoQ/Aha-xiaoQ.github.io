import{createJourneyPilot}from'./minecraft-journey-pilot.mjs';
import {createDiscoveryPilot} from './minecraft-discovery-pilot.mjs';
import {createPilot} from './minecraft-pilot.mjs';
// Run with node --experimental-vm-modules. Executes the HTML's embedded modules
// against the packaged simulated DOM. This is not browser layout/hardware testing.
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createContext,SourceTextModule} from 'node:vm';
import {installSimulatedPlayDom} from '../tests/fixtures/simulated-play-dom.mjs';
import {inspectOfflineHtml} from './check-offline-html.mjs';

const file=process.argv[2],isCollection=false;
if(!file)throw Error('Usage: node --experimental-vm-modules scripts/check-offline-runtime.mjs HTML [collection]');
const html=await readFile(file,'utf8'),checked=inspectOfflineHtml(html,{collection:isCollection});
const dom=installSimulatedPlayDom(),timers=new Map(),storageData=new Map();let timerId=0;
const originalContext=dom.Element.prototype.getContext;dom.Element.prototype.getContext=function(){const c=originalContext.call(this);c.createLinearGradient=c.createRadialGradient=()=>({addColorStop(){}});return c;};
const settle=async()=>{for(let turn=0;turn<60;turn++)await Promise.resolve();};
const imageSources=[];
class EmbeddedImage{
 set src(value){assert.ok(String(value).startsWith('data:image/'),'offline Image source must be embedded');imageSources.push(value);this._src=value;}
 get src(){return this._src;}
 async decode(){return this;}
}
class EmbeddedAudio{
 paused=true;
 constructor(source){if(source)this.src=source;}
 set src(value){assert.ok(String(value).startsWith('data:audio/'),'offline audio source must be embedded');this._src=value;}
 get src(){return this._src;}
 async play(){this.paused=false;}
 pause(){this.paused=true;}
}
let fetches=0;
try{
 const body=html.match(/<body>([\s\S]*?)<script type="importmap">/);assert.ok(body);
 dom.document.body.innerHTML=body[1];
 const sandbox={
  document:dom.document,window:dom.window,navigator:globalThis.navigator,performance:globalThis.performance,
  requestAnimationFrame:globalThis.requestAnimationFrame,cancelAnimationFrame:globalThis.cancelAnimationFrame,
  FontFace:globalThis.FontFace,Option:globalThis.Option,Image:EmbeddedImage,Audio:EmbeddedAudio,
  URL,Blob,TextEncoder,TextDecoder,Uint8Array,Uint8ClampedArray,ArrayBuffer,structuredClone,crypto:globalThis.crypto,atob,btoa,console,
  localStorage:{getItem:key=>storageData.get(key)??null,setItem:(key,value)=>storageData.set(key,value),removeItem:key=>storageData.delete(key)},
  fetch(){fetches++;throw Error('Network use is forbidden in the offline verification');},
  setTimeout(callback,delay){const id=++timerId;timers.set(id,{callback,delay});return id;},
  clearTimeout(id){timers.delete(id);},
 };
 const context=createContext(sandbox),modules=new Map();
 for(const [id,source] of checked.modules)modules.set(id,new SourceTextModule(source,{context,identifier:id,initializeImportMeta(meta){meta.url='data:text/javascript,';}}));
 const root=new SourceTextModule(checked.root,{context,identifier:'offline-bootstrap'});
 const link=specifier=>{assert.ok(modules.has(specifier),'runtime cannot read external module '+specifier);return modules.get(specifier);};
 await root.link(link);
 for(const module of modules.values())if(module.status==='unlinked')await module.link(link);
 await root.evaluate();
 if(isCollection){
  const button=dom.document.querySelectorAll('button').find(node=>node.textContent==='从第一关开始');assert.ok(button);button.click();await settle();
 }else{const button=dom.document.getElementById('start');assert.ok(button);await button.onclick();await settle();}
 let canvas=dom.document.querySelector('dialog canvas');assert.ok(canvas?.workshopRead,'embedded player launched');
 assert.equal(canvas.workshopRead().p.x,64);
 const inputs=[],pilot=createJourneyPilot({discoveries:process.argv.includes('--discoveries'),ranged:process.argv.includes('--ranged')});
 let held=new Set();
 for(let frame=0;frame<24000&&!canvas.workshopRead().completed;frame++){const input=pilot(canvas.workshopRead());inputs.push(input);if(Number.isInteger(input.shopSelect))dom.document.querySelectorAll('.shop-slot')[input.shopSelect]?.click();if(input.shopConfirm)dom.document.querySelector('.shop-buy')?.click();if(input.shopClose)dom.document.querySelector('.shop-close')?.click();const next=new Set([...(input.x>0?['ArrowRight']:input.x<0?['ArrowLeft']:[]),...(input.run?[[ 'ShiftLeft','KeyJ','KeyX' ][Math.floor(frame/120)%3]]:[]),...(input.jump?['Space']:[]),...(input.interact?['KeyE']:[]),...(input.attack?['KeyK']:[]),...(input.shield?['KeyL']:[]),...(input.up?['ArrowUp']:[]),...(input.down?['ArrowDown']:[]),...(input.usePotion?['KeyH']:[])]);for(const key of held)if(!next.has(key))dom.release(key);for(const key of next)if(!held.has(key))dom.key(key);held=next;dom.frames(1);if(!process.argv.includes('--ranged')&&canvas.workshopRead().minecraft?.gear)assert.equal(canvas.workshopRead().minecraft.gear.charge||0,0,'run aliases cannot attack');}
 for(const key of held)dom.release(key);
 // Simulated RAF uses integer clock milliseconds; permit a few idle ticks.
 for(let i=0;i<10&&!canvas.workshopRead().completed;i++)dom.frames(1);
 const cleared=canvas.workshopRead();assert.equal(cleared.completed,true,JSON.stringify(cleared.p));assert.equal(cleared.lives,9);
 assert.equal(fetches,0);assert.ok(imageSources.length>0);
 console.log(JSON.stringify({file,kind:isCollection?'collection':'single',moduleCount:checked.moduleCount,reachableModuleCount:checked.reachableModuleCount,embeddedRuntimeLaunched:true,actualExitCleared:true,ordinaryKeyboardFrames:inputs.length,finalLives:cleared.lives,simulatedDom:true,realBrowser:false,networkRequests:fetches}));
}finally{dom.document.querySelector('dialog')?.close();dom.restore();}
