// Run actual embedded native Stage/Motor code without network, using neutral
// input-only shell activation and real finite polygon traversal in both directions.
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createContext,SourceTextModule,runInContext} from 'node:vm';
import {inspectOfflineHtml} from './check-offline-html.mjs';
import {checkLiveShellSlope} from '../tests/fixtures/thin-slope-native.mjs';
import {checkInitialPlant} from '../tests/fixtures/thin-slope-initial-native.mjs';
const [htmlFile,projectFile,mode]=process.argv.slice(2);if(!htmlFile||!projectFile)throw Error('Usage: node --experimental-vm-modules scripts/check-thin-slope-offline.mjs HTML QMAP');
const checked=inspectOfflineHtml(fs.readFileSync(htmlFile,'utf8')),project=JSON.parse(fs.readFileSync(projectFile,'utf8'));let networkRequests=0;
const context=createContext({console,URL,TextEncoder,TextDecoder,Uint8Array,Uint8ClampedArray,structuredClone,crypto:globalThis.crypto,fetch(){networkRequests++;throw Error('Finite slope offline fixture cannot use network');}}),modules=new Map();
for(const [id,source]of checked.modules)modules.set(id,new SourceTextModule(source,{context,identifier:id}));
const link=id=>{assert(modules.has(id),'Missing embedded module '+id);return modules.get(id);},stage=modules.get('workshop/editor-mario-stage.mjs'),motor=modules.get('workshop/editor-mario-motor.mjs');await stage.link(link);if(motor.status==='unlinked')await motor.link(link);await stage.evaluate();await motor.evaluate();
const EmbeddedStage=options=>{context.stageData=JSON.stringify({plan:options.plan,visualRooms:options.visualRooms,initialState:options.initialState,manualDeath:options.manualDeath,autoContinue:options.autoContinue,allowWarp:options.allowWarp});const local=runInContext('JSON.parse(stageData)',context);return stage.namespace.createPlatformStage({...local,motor:options.motor,emit:options.emit});};
const traversal=(mode==='initial-plant'?checkInitialPlant:checkLiveShellSlope)(project,{Stage:EmbeddedStage,Motor:motor.namespace.createPlatformMotor});assert.equal(networkRequests,0);
console.log(JSON.stringify({kind:'synthetic-neutral',orientation:project.rooms[0].smm2Mechanics.slopes[0].orientation,moduleCount:checked.moduleCount,actualEmbeddedStageExecuted:true,actualEmbeddedMotorExecuted:true,networkRequests,...traversal,originalTimingCalibrated:false}));
