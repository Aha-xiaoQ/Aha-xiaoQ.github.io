// Execute embedded art and native Stage/Motor against a neutral contact fixture.
// Canvas/VM verification, not a browser layout or original timing calibration.
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createContext,SourceTextModule,runInContext} from 'node:vm';
import {loadImage} from '@napi-rs/canvas';
import {inspectOfflineHtml} from './check-offline-html.mjs';
import {rawPalettePng,assertNativeDonutContact} from '../tests/fixtures/original-donut-native.mjs';
const [htmlFile,projectFile,mode]=process.argv.slice(2);if(!htmlFile||!projectFile)throw Error('Usage: node --experimental-vm-modules scripts/check-original-donut-offline.mjs HTML QMAP [collection]');
const checked=inspectOfflineHtml(fs.readFileSync(htmlFile,'utf8'),{collection:mode==='collection'}),project=JSON.parse(fs.readFileSync(projectFile,'utf8'));let networkRequests=0;
const context=createContext({console,URL,TextEncoder,TextDecoder,Uint8Array,Uint8ClampedArray,structuredClone,crypto:globalThis.crypto,fetch(){networkRequests++;throw Error('Original Donut offline check cannot use network');}}),modules=new Map();
for(const [id,source]of checked.modules)modules.set(id,new SourceTextModule(source,{context,identifier:id}));
const link=id=>{assert(modules.has(id),'Missing actual embedded module '+id);return modules.get(id);},stage=modules.get('workshop/editor-mario-stage.mjs'),motor=modules.get('workshop/editor-mario-motor.mjs'),art=modules.get('workshop/editor-smm2-art.mjs');await stage.link(link);await stage.evaluate();if(motor.status==='unlinked')await motor.link(link);await motor.evaluate();if(art.status==='unlinked')await art.link(link);await art.evaluate();
const local=(key,data)=>{context[key]=JSON.stringify(data);return runInContext('JSON.parse('+key+')',context);};
const EmbeddedStage=options=>stage.namespace.createPlatformStage({...local('stageInput',{plan:options.plan,visualRooms:options.visualRooms,initialState:options.initialState,manualDeath:options.manualDeath,autoContinue:options.autoContinue,allowWarp:options.allowWarp}),motor:options.motor,emit:options.emit});
const drawWorld=(ctx,r,view,tick)=>{const data=local('artInput',{room:r,view});return art.namespace.drawSmm2World(ctx,data.room,data.view,tick);};
const image=await loadImage(rawPalettePng(fs.readFileSync(new URL('../atlas/assets/smm2-private/SMM-SMB-DonutBlock.original.png',import.meta.url)))),report=assertNativeDonutContact({project,image,drawWorld,Stage:EmbeddedStage,Motor:motor.namespace.createPlatformMotor});assert.equal(networkRequests,0);
console.log(JSON.stringify({collection:mode==='collection',moduleCount:checked.moduleCount,actualEmbeddedStageExecuted:true,actualEmbeddedMotorExecuted:true,actualEmbeddedArtExecuted:true,networkRequests,...report}));
