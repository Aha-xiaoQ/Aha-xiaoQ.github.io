// Execute actual embedded carrier/item/Thwomp/Stage code from a neutral export.
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createContext,SourceTextModule,runInContext} from 'node:vm';
import {inspectOfflineHtml} from './check-offline-html.mjs';
import {assertNativePowCarrierMotion} from '../tests/fixtures/pow-carriers-native.mjs';

const [htmlFile,projectFile,mode]=process.argv.slice(2);
if(!htmlFile||!projectFile)throw Error('Usage: node --experimental-vm-modules scripts/check-pow-carriers-offline.mjs HTML QMAP [collection]');
const html=fs.readFileSync(htmlFile,'utf8'),checked=inspectOfflineHtml(html,{collection:mode==='collection'}),project=JSON.parse(fs.readFileSync(projectFile,'utf8'));let networkRequests=0;
const forbidNetwork=()=>{networkRequests++;throw Error('POW support closure must run without network');};
const context=createContext({console,URL,Blob,atob,btoa,TextEncoder,TextDecoder,ArrayBuffer,Uint8Array,Uint8ClampedArray,structuredClone,crypto:globalThis.crypto,setTimeout,clearTimeout,fetch:forbidNetwork,XMLHttpRequest:class{constructor(){forbidNetwork();}},WebSocket:class{constructor(){forbidNetwork();}}}),modules=new Map();
for(const [id,source]of checked.modules)modules.set(id,new SourceTextModule(source,{context,identifier:id}));
const link=id=>{assert(modules.has(id),'Missing embedded module '+id);return modules.get(id);},stage=modules.get('workshop/editor-mario-stage.mjs'),motor=modules.get('workshop/editor-mario-motor.mjs'),lighting=modules.get('workshop/editor-smm2-lighting.mjs');
for(const id of ['editor-smm2-carriers.mjs','editor-smm2-items.mjs','editor-smm2-thwomps.mjs'])assert(modules.has('workshop/'+id),'real support dependency '+id);
await stage.link(link);await stage.evaluate();
if(motor.status==='unlinked')await motor.link(link);if(motor.status!=='evaluated')await motor.evaluate();
if(lighting.status==='unlinked')await lighting.link(link);if(lighting.status!=='evaluated')await lighting.evaluate();
const local=(key,value)=>{context[key]=JSON.stringify(value);return runInContext('JSON.parse('+key+')',context);};
const Stage=options=>stage.namespace.createPlatformStage({...local('stageInput',{plan:options.plan,visualRooms:options.visualRooms,initialState:options.initialState,manualDeath:options.manualDeath,autoContinue:options.autoContinue,allowWarp:options.allowWarp}),motor:options.motor,emit:options.emit});
const resolve=(room,view)=>{const q=local('lightInput',{room,view});return JSON.parse(JSON.stringify(lighting.namespace.resolveSmm2LightSources(q.room,q.view)));};
const report=assertNativePowCarrierMotion(project,{Stage,Motor:motor.namespace.createPlatformMotor,resolve});assert.equal(networkRequests,0);
console.log(JSON.stringify({collection:mode==='collection',moduleCount:checked.moduleCount,actualEmbeddedStageExecuted:true,actualEmbeddedCarriersExecuted:true,actualEmbeddedItemsExecuted:true,actualEmbeddedThwompsExecuted:true,liveLightsTracked:true,networkRequests,...report,originalTimingCalibrated:false}));
