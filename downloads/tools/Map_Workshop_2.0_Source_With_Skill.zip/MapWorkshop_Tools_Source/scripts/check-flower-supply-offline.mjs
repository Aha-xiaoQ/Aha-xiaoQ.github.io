// Run the actual HTML-embedded Stage and motor with ordinary inputs only.
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createContext,SourceTextModule,runInContext} from 'node:vm';
import {inspectOfflineHtml} from './check-offline-html.mjs';
import {flowerSession,exerciseFlowerRecovery,exerciseFlowerDeathReset} from '../tests/fixtures/flower-pipe-native.mjs';

const [htmlFile,projectFile,mode='single']=process.argv.slice(2);
if(!htmlFile||!projectFile)throw Error('Usage: node --experimental-vm-modules scripts/check-flower-supply-offline.mjs HTML QMAP [single|collection]');
const checked=inspectOfflineHtml(fs.readFileSync(htmlFile,'utf8'),{collection:mode==='collection'}),project=JSON.parse(fs.readFileSync(projectFile,'utf8'));
let networkRequests=0;
const context=createContext({console,URL,TextEncoder,TextDecoder,Uint8Array,Uint8ClampedArray,structuredClone,crypto:globalThis.crypto,fetch(){networkRequests++;throw Error('Offline flower supply cannot use network');}}),modules=new Map();
for(const [id,source]of checked.modules)modules.set(id,new SourceTextModule(source,{context,identifier:id}));
const link=id=>{assert(modules.has(id),'Missing embedded module '+id);return modules.get(id);};
const stage=modules.get('workshop/editor-mario-stage.mjs'),motor=modules.get('workshop/editor-mario-motor.mjs');
await stage.link(link);if(motor.status==='unlinked')await motor.link(link);await stage.evaluate();await motor.evaluate();
const EmbeddedStage=options=>{
 context.stageData=JSON.stringify({plan:options.plan,visualRooms:options.visualRooms,manualDeath:options.manualDeath,autoContinue:options.autoContinue,allowWarp:options.allowWarp});
 return stage.namespace.createPlatformStage({...runInContext('JSON.parse(stageData)',context),motor:options.motor,emit:options.emit});
};
const session=flowerSession(project,{Stage:EmbeddedStage,Motor:motor.namespace.createPlatformMotor});
const recovery=exerciseFlowerRecovery(session),reset=exerciseFlowerDeathReset(session);
assert.equal(networkRequests,0);
console.log(JSON.stringify({fixtureKind:'synthetic-neutral',mode,actualEmbeddedStageExecuted:true,actualEmbeddedMotorExecuted:true,moduleCount:checked.moduleCount,networkRequests,ordinaryInputFrames:session.trace.length,...recovery,...reset,finalPower:session.view().p.power,finalLives:session.view().lives,sourceEmittedAfterRetry:session.view().marioModules.itemSources[0].emitted,originalTimingCalibrated:false}));
