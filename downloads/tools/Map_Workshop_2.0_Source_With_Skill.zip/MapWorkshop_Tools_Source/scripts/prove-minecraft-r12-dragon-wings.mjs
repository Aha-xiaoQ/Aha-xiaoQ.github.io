import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {createCanvas,loadImage} from '@napi-rs/canvas';
import {nativeSession} from '../tests/fixtures/shell-coin-native.mjs';
import {nativeWorld} from '../render-lantern-course-native-canvas.mjs';
import {drawFinaleWorld,dragonWingArtPlan} from '../atlas/editor-minecraft-finale-art.mjs';

const root=new URL('../examples/minecraft-adventure/',import.meta.url),out=new URL('evidence/',root);
fs.mkdirSync(out,{recursive:true});
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const sourceUrl=new URL('../atlas/editor-minecraft-finale-art.mjs',import.meta.url),source=fs.readFileSync(sourceUrl,'utf8'),baseline=JSON.parse(fs.readFileSync(new URL('../tests/fixtures/minecraft-r12-dragon-before.json',import.meta.url)));
const start=source.indexOf('function dragon(c,q,tick,room={}){'),end=source.indexOf('\nfunction telegraph(',start);assert(start>0&&end>start);
// Use the exact preserved old dragon painter, not a visual approximation.
// All other artwork is shared, including the unchanged membrane palette.
const beforeSource=(source.slice(0,start)+baseline.dragonPainter+source.slice(end)).replace("from './editor-minecraft-enchantment-art.mjs'",`from '${new URL('../atlas/editor-minecraft-enchantment-art.mjs',import.meta.url).href}'`);
const before=await import('data:text/javascript;base64,'+Buffer.from(beforeSource).toString('base64'));
const documentBytes=fs.readFileSync(new URL('blast-trail.qmap.json',root)),inputBytes=fs.readFileSync(new URL('ranged-inputs.json',out)),doc=JSON.parse(documentBytes),inputs=JSON.parse(inputBytes),session=nativeSession(doc),captures=[];
const wanted=[
 ['flight-left',d=>d.state==='flight'&&d.stateAge>=32&&d.facing===-1],
 ['turn-right',d=>d.state==='strafe'&&d.stateAge>=30&&d.facing===1&&d.flightTilt>.05],
 ['dive-charge',d=>d.state==='charge'&&d.stateAge>=37],
 ['landing',d=>d.state==='landing'&&d.stateAge>=30],
 ['perch-folded',d=>d.state==='perch'&&d.stateAge>=8],
 ['death-fracture',d=>d.state==='defeated'&&d.stateAge>=8],
 ['death-dissolve',d=>d.state==='defeated'&&d.stateAge>=27],
];
for(let i=0;i<inputs.length;i++){
 session.step(inputs[i]);const v=session.view(),d=v.minecraft?.dragon;if(!d)continue;
 for(const [name,match] of wanted){if(captures.some(c=>c.name===name)||!match(d))continue;captures.push({name,frame:i+1,tick:v.tick,view:structuredClone(v)});}
}
assert(session.view().completed,'the unchanged ordinary-input route still completes');
for(const [name] of wanted)assert(captures.some(c=>c.name===name),'missing live pose: '+name);
captures.sort((a,b)=>wanted.findIndex(w=>w[0]===a.name)-wanted.findIndex(w=>w[0]===b.name));
const panels=[],reports=[],scale=2,panelW=352,panelH=224;
for(const shot of captures){
 const d=shot.view.minecraft.dragon,cx=d.body.x+d.body.w/2,cy=d.body.y+d.body.h/2,camera={x:Math.round(cx-panelW/2),y:Math.round(cy-145),w:panelW,h:panelH};
 const untouched=JSON.stringify(shot.view),room={roomId:'end',minecraft:{version:1,biome:'end'},map:{width:832,height:384,geometry:[],objects:[]},tick:shot.tick};
 for(const [version,painter] of [['before',before.drawFinaleWorld],['after',drawFinaleWorld]]){
  const canvas=createCanvas(panelW*scale,panelH*scale),ctx=canvas.getContext('2d');ctx.imageSmoothingEnabled=false;ctx.fillStyle='#454657';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.save();ctx.scale(scale,scale);ctx.translate(-camera.x,-camera.y);
  // Isolate the actor using the exact live pose. Environmental effects and
  // healing beams are intentionally omitted only in these labeled art crops.
  painter(ctx,room,{dragon:{...d,crystals:[],projectiles:[],pools:[],effects:[],safeLanes:[],telegraph:null,healingActive:false,shielded:false,egg:null}});ctx.restore();
  const file=`r12-dragon-wing-${shot.name}-${version}.png`;fs.writeFileSync(new URL(file,out),canvas.toBuffer('image/png'));panels.push({name:shot.name,version,file});canvas.width=1;
 }
 assert.equal(JSON.stringify(shot.view),untouched,'rendering does not mutate live snapshots');
 const nativeCamera={x:Math.max(0,Math.min(320,Math.round(cx-256))),y:0,w:512,h:320},native=nativeWorld(shot.view,doc,{camera:nativeCamera,scale:2}),nativeFile=`r12-dragon-wing-${shot.name}-native.png`;
 fs.writeFileSync(new URL(nativeFile,out),native.canvas.toBuffer('image/png'));native.canvas.width=1;
 reports.push({name:shot.name,frame:shot.frame,tick:shot.tick,state:d.state,stateAge:d.stateAge,facing:d.facing,flightTilt:d.flightTilt,body:d.body,head:d.head,wingPlan:dragonWingArtPlan(d,shot.tick),nativeFile,camera:nativeCamera,before:`r12-dragon-wing-${shot.name}-before.png`,after:`r12-dragon-wing-${shot.name}-after.png`});
}
const header=76,labelH=34,tileW=panelW*scale,tileH=panelH*scale,sheet=createCanvas(tileW*2,header+(tileH+labelH)*captures.length),ctx=sheet.getContext('2d');
ctx.imageSmoothingEnabled=false;ctx.fillStyle='#181923';ctx.fillRect(0,0,sheet.width,sheet.height);ctx.fillStyle='#eee9f1';ctx.font='bold 25px sans-serif';ctx.fillText('R12 DRAGON WINGS  /  EXACT SHARED CANVAS PAINTER',18,30);ctx.font='18px sans-serif';ctx.fillText('BEFORE: same-side projection',18,60);ctx.fillText('AFTER: bilateral shoulders + torso occlusion',tileW+18,60);
for(const [i,p] of panels.entries()){
 const x=(i%2)*tileW,y=header+Math.floor(i/2)*(tileH+labelH);ctx.fillStyle='#ddd7e6';ctx.font='18px sans-serif';ctx.fillText(p.name+'  |  '+p.version,x+14,y+24);ctx.drawImage(await loadImage(fs.readFileSync(new URL(p.file,out))),x,y+labelH);
}
const sheetFile='r12-dragon-wings-before-after-contact-sheet.png';fs.writeFileSync(new URL(sheetFile,out),sheet.toBuffer('image/png'));sheet.width=1;
// Separate small native-world sheet: no actor, pose, combat or scenery edits.
const nativeSheet=createCanvas(1024*2,(640+32)*4),nc=nativeSheet.getContext('2d');nc.fillStyle='#181923';nc.fillRect(0,0,nativeSheet.width,nativeSheet.height);nc.imageSmoothingEnabled=false;
for(const [i,r] of reports.entries()){const x=i%2*1024,y=Math.floor(i/2)*672;nc.fillStyle='#eee9f1';nc.font='18px sans-serif';nc.fillText(r.name+' | native frame '+r.frame,x+12,y+23);nc.drawImage(await loadImage(fs.readFileSync(new URL(r.nativeFile,out))),x,y+32);}
const nativeSheetFile='r12-dragon-wings-native-contact-sheet.png';fs.writeFileSync(new URL(nativeSheetFile,out),nativeSheet.toBuffer('image/png'));
const report={evidence:'Actual @napi-rs/canvas drawing by the delivered finale-art module. Pose snapshots come from a completed ordinary-input native replay. Before/after actor crops intentionally suppress environmental overlays and use the same live body/head/state/tick. Native-world screenshots use the full unmodified live snapshots and shared nativeWorld renderer. These are native renders, not browser screenshots.',completed:true,frames:inputs.length,sourceSha256:sha(source),preservedBaselineSha256:baseline.sourceSha256,mapSha256:sha(documentBytes),inputSha256:sha(inputBytes),controllerSha256:sha(fs.readFileSync(new URL('../atlas/editor-minecraft-dragon.mjs',import.meta.url))),paletteChanged:false,collisionChanged:false,controllerChanged:false,sheetFile,nativeSheetFile,captures:reports};
fs.writeFileSync(new URL('r12-dragon-wing-proof.json',out),JSON.stringify(report,null,2));
fs.writeFileSync(new URL('r12-dragon-wing-live-poses.json',out),JSON.stringify(captures,null,2));
console.log(JSON.stringify({completed:report.completed,frames:report.frames,sheetFile,nativeSheetFile,captures:reports.map(r=>({name:r.name,frame:r.frame,state:r.state,facing:r.facing}))},null,2));
