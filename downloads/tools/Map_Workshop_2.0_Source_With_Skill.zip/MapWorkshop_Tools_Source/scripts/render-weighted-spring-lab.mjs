// Capture ordinary native inputs from each neutral source spawn. Slow replay is
// labelled and reads captured states; it never writes to gameplay actors.
import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {gzipSync} from 'node:zlib';
import {spawn,execFileSync} from 'node:child_process';
import {once} from 'node:events';
import {createCanvas} from '@napi-rs/canvas';
import {nativeWorld,nativeCamera} from '../render-lantern-course-native-canvas.mjs';
import {nativeSession} from '../tests/fixtures/shell-coin-native.mjs';
import {LAB_CASES,buildWeightedSpringLab} from './build-weighted-spring-lab.mjs';
import {mixNativeSceneAudio} from '../renderer-audio/mix-native-scene-audio.mjs';
import {audioFiles} from '../atlas/editor-audio.mjs';

const out=path.resolve(process.argv[2]||'dist/weighted-spring-lab');await fs.mkdir(out,{recursive:true});
const built=await buildWeightedSpringLab(out),fps=60,width=1152,height=792,normalFrames=180,holdFrames=60,slowFrames=48,slowRepeat=4;
const digest=q=>createHash('sha256').update(q).digest('hex'),canonical=q=>JSON.parse(JSON.stringify(q));
const silent=path.join(out,'weighted-spring-lab-silent.mp4'),encoder=spawn('ffmpeg',['-nostdin','-y','-hide_banner','-loglevel','error','-f','rawvideo','-pixel_format','rgba','-video_size',width+'x'+height,'-framerate',String(fps),'-i','pipe:0','-an','-c:v','libx264','-preset','fast','-crf','20','-pix_fmt','yuv420p','-movflags','+faststart',silent],{stdio:['pipe','ignore','pipe']});
let stderr='',videoFrames=0;encoder.stderr.on('data',q=>stderr+=q.toString());const exit=once(encoder,'close');
const write=async(bytes,count=1)=>{for(let n=0;n<count;n++){if(!encoder.stdin.write(bytes))await once(encoder.stdin,'drain');videoFrames++;}};
const events=[],scenes=[],snapshots=[];
const videoTitles={lift:'WEIGHTED LIFT',impact:'IMPACT LAUNCH',drop:'LEAVING SUPPORT',cargo:'SUPPORT CHAIN'};
for(let index=0;index<LAB_CASES.length;index++){
 const q=LAB_CASES[index],doc=q.make(),session=nativeSession(doc),duplicate=nativeSession(doc),views=[canonical(session.view())];
 for(let n=0;n<normalFrames;n++){const a=session.step({}),b=duplicate.step({});assert.deepEqual(a,b);assert.equal(a.lives,3);assert(!a.p.dying);views.push(canonical(a));}
 assert.deepEqual(session.events,duplicate.events);
 const sceneStart=videoFrames,normalStart=sceneStart+holdFrames;
 const render=(v,phase)=>{
  const before=JSON.stringify(v),world=nativeWorld(v,doc,{camera:nativeCamera(v),scale:2}).canvas,c=createCanvas(width,height),ctx=c.getContext('2d');ctx.imageSmoothingEnabled=false;ctx.fillStyle='#f6f0de';ctx.fillRect(0,0,width,height);ctx.fillStyle='#4b3420';ctx.font='26px StudySansBold';ctx.fillText((index+1)+' / 4  '+videoTitles[q.id],24,31);ctx.font='16px StudySans';ctx.fillText(phase,24,57);ctx.textAlign='right';ctx.fillText('WORKSHOP LAB / AUTHOR PARAMETERS',width-24,31);ctx.drawImage(world,0,72,width,720);assert.equal(JSON.stringify(v),before);return c;
 };
 const initial=render(views[0],'SOURCE LAYOUT / PAUSED'),raw=c=>Buffer.from(c.getContext('2d').getImageData(0,0,width,height).data);await write(raw(initial),holdFrames);
 for(let n=1;n<=normalFrames;n++){const c=render(views[n],'NORMAL SPEED / REAL 60 Hz / WAIT INPUT');await write(raw(c));if(n===24||n===normalFrames){const file=q.id+'-tick-'+n+'.png';await fs.writeFile(path.join(out,file),c.toBuffer('image/png'));snapshots.push({file,scene:q.id,tick:n});}}
 for(let n=0;n<slowFrames;n++)await write(raw(render(views[n],'4x SLOW REPLAY / SAME FIRST 48 SIMULATION FRAMES')),slowRepeat);
 await write(raw(render(views[normalFrames],'PAUSED / PLAY AND EDIT THE INCLUDED QMAP')),holdFrames);
 for(const event of session.events)if(event.type==='sound')events.push({...event,frame:normalStart+Math.max(0,event.frame-1)});
 scenes.push({id:q.id,projectSha256:built.cases[index].sourceSha256,sourceInputs:session.inputs,ordinaryInputFrames:normalFrames,runtimeStateInjection:false,views,events:session.events,video:{startFrame:sceneStart,normalStartFrame:normalStart,normalEndFrame:normalStart+normalFrames,slowReplaySourceTicks:[0,47],slowRepeat,endFrame:videoFrames}});
}
encoder.stdin.end();const [code]=await exit;assert.equal(code,0,stderr);const duration=videoFrames/fps,audioPath=path.join(out,'weighted-spring-lab-audio.m4a');
const audio=await mixNativeSceneAudio({events,fps,duration,audioFiles:Object.fromEntries(Object.entries(audioFiles).filter(([,file])=>typeof file==='string')),assetDirectory:new URL('../atlas/assets/classic-audio/',import.meta.url).pathname,outputPath:audioPath,overwrite:true,musicIntervals:[{startFrame:0,endFrame:videoFrames,key:'overworld'}],musicGain:.25,effectGain:.55});
const file=path.join(out,'weighted-spring-lab.mp4');execFileSync('ffmpeg',['-nostdin','-y','-hide_banner','-loglevel','error','-i',silent,'-i',audioPath,'-map','0:v:0','-map','1:a:0','-c','copy','-t',String(duration),'-movflags','+faststart',file]);
const traceFile=path.join(out,'LAB_NATIVE_VIDEO_TRACE.json.gz'),trace=Buffer.from(JSON.stringify({kind:'neutral-workshop-capability-demonstration',originalCourse:false,sourceVersion:'1.10.14-mechanism-coverage.1',fps,nativeInputs:'{} at every true simulation step',scenes}));await fs.writeFile(traceFile,gzipSync(trace,{level:9,mtime:0}));
const probe=JSON.parse(execFileSync('ffprobe',['-v','error','-count_frames','-show_streams','-show_format','-of','json',file],{encoding:'utf8'}));assert.equal(Number(probe.streams.find(q=>q.codec_type==='video').nb_read_frames),videoFrames);assert(probe.streams.some(q=>q.codec_type==='audio'));
const bytes=await fs.readFile(file),report={kind:'neutral-weighted-spring-lab-video',htmlSha256:built.html.sha256,video:{file:path.basename(file),bytes:bytes.length,sha256:digest(bytes),width,height,fps,frames:videoFrames,durationSeconds:duration},nativeFrames:scenes.reduce((n,q)=>n+q.ordinaryInputFrames,0),runtimeStateInjection:false,actualNativeCameraUsed:true,originalCourse:false,originalNumericalCalibration:false,slowReplayExplicitlyLabelled:true,physicalBrowserCapture:false,nativeRendererSharedWithGameplay:true,audio:{localGameBgmAndEvents:true,originalWalkthroughAudio:false,effectCount:audio.mixedEventCount,peak:audio.peak,clippedValues:audio.clippedInterleavedValues},snapshots,trace:{file:path.basename(traceFile),bytes:(await fs.stat(traceFile)).size,uncompressedSha256:digest(trace)}};await fs.writeFile(path.join(out,'LAB_VIDEO_ACCEPTANCE.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));
