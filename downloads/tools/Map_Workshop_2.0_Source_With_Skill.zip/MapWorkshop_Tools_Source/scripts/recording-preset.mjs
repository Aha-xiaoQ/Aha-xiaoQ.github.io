import {nativeCamera} from '../atlas/editor-camera.mjs';
/** Presentation-only recording preset. Never changes simulation dimensions. */
export const RECORDING_PRESET=Object.freeze({width:1920,height:1080,fps:30});
export function recordingCamera(view,{width,height}=RECORDING_PRESET){
 if(!(width>0&&height>0))throw Error('Invalid recording size');
 const base=nativeCamera(view),aspect=width/height;
 const h=Math.max(base.height,base.width/aspect),w=h*aspect;
 return {...base,width:w,height:h,w,h,x:Math.max(0,Math.min(Math.max(0,view.width-w),base.x-(w-base.width)/2)),y:Math.max(0,Math.min(Math.max(0,view.height-h),base.y-(h-base.height)/2)),scale:height/h};
}
