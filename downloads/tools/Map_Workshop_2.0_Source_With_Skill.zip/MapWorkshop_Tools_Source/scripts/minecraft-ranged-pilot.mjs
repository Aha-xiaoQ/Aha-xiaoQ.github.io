/** K/L and unchanged Mario movement only. Visible trajectories are used to time
 * the short parry window; outgoing throws and returns remain real projectiles. */
import {dragonPilotInput,dragonTravel} from './minecraft-dragon-pilot.mjs';
function incoming(v,input){const p=v.p,d=v.minecraft?.dragon||v.dragon,g=v.minecraft?.gear||v.gear;let nearest=null;for(const q of d.projectiles){if(q.reflected||!q.reflectable)continue;for(let t=0;t<=7;t++){const x=q.x+q.vx*t,y=q.y+q.vy*t,px=p.x+(input.x||0)*Math.min(2,t*.35);if(x+q.w>px&&x<px+p.w&&y+q.h>p.y&&y<p.y+p.h){if(!nearest||t<nearest.t)nearest={q,t};break;}}}if(nearest&&g.guard&&!g.guard.cooldown&&g.guard.stamina>26)return {x:Math.sign(nearest.q.x+nearest.q.w/2-(p.x+p.w/2))||p.facing||1,shield:true};if(g.guard?.active&&g.guard.parryTicks>0&&d.projectiles.some(q=>!q.reflected&&Math.hypot(q.x-p.x,q.y-p.y)<50))return {x:g.guard.facing,shield:true};return null;}
export function createRangedDragonPilot({stompHits=1,parry=true}={}){
 let previous={},breathEscape=null,lastState=null;
 return v=>{const d=v.minecraft?.dragon||v.dragon,g=v.minecraft?.gear||v.gear,p=v.p;if(!d||!g)return {};let input={};
  if(d.defeated)input=dragonPilotInput(v,previous);
  else if(d.crystalsRemaining){const c=d.crystals.find(q=>q.active),target=c.x-100;input=dragonTravel(v,previous,target);if(Math.abs(p.x-target)<20&&p.grounded&&!g.trident&&!g.cooldown)input={x:1,attack:!previous.attack};}
  else{
   const landing=d.perch.x-16;
   if(d.state==='telegraph-breath'&&lastState!=='telegraph-breath')breathEscape=Math.max(140,(d.telegraph?.target?.x||p.x)-105);
   if(d.state==='telegraph-breath'||d.state==='breath')input=dragonTravel(v,previous,breathEscape??landing-90);
   else if(d.state==='telegraph-charge'||d.state==='charge')input=dragonPilotInput(v,previous);
   else if(d.state==='landing'||d.state==='perch')input=stompHits>0?dragonPilotInput(v,previous):dragonTravel(v,previous,d.state==='perch'&&d.stateAge<72?landing-206:landing-142);
   else input=dragonTravel(v,previous,landing-78);
   const clouds=(d.pools||[]).filter(q=>q.life>0);
   const floorAt=x=>(v.geometry||[]).filter(q=>q.collision==='solid'&&!q.hidden&&x+10>q.x&&x<q.x+q.w&&q.y>=240).sort((a,b)=>a.y-b.y)[0]?.y??320;
   const unsafe=x=>clouds.some(q=>x+18>q.x&&x-8<q.x+q.w&&Math.abs(floorAt(x)-(q.y+q.h))<18);
   if(clouds.length&&((!['landing','perch'].includes(d.state)||stompHits<=0)&&unsafe(landing-78)||clouds.some(q=>p.x+p.w>q.x-12&&p.x<q.x+q.w+12&&p.y+p.h>=q.y-6&&p.y<q.y+q.h))){const targets=[landing-78,landing-142,landing-206,landing+96,landing+160,144,640].filter(x=>x>=96&&x<=680&&!unsafe(x));const preferred=d.state==='perch'&&stompHits<=0?(d.stateAge<72?landing-206:landing-142):p.x;targets.sort((a,b)=>Math.abs(a-preferred)-Math.abs(b-preferred));input=dragonTravel(v,previous,targets[0]??144);}
   const nearCloud=clouds.some(q=>p.x+p.w+24>q.x&&p.x-24<q.x+q.w&&p.y+p.h>=q.y-8&&p.y<q.y+q.h);if(nearCloud&&p.grounded&&!previous.jump)input.jump=true;
   const defense=parry?incoming(v,input):null;
   if(defense)input={...input,...defense};
   else if(d.rangedOpen&&!g.trident&&!g.cooldown&&!previous.attack){const facing=Math.sign(d.head.x+d.head.w/2-p.x-p.w/2)||1;input.attack=true;input.x=facing;}
  }
  lastState=d.state;previous=input;return {...input};
 };
}
