// Build one independent, offline authoring preview. Reference media is opt-in.
import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {validateSnakeWindowPreview,parseSnakeWindowPreview,serializeSnakeWindowPreview} from '../atlas/editor-snake-window-preview.mjs';
import {createNeutralSnakeWindowPreviewDocument,SNAKE_WINDOW_EDITOR_CSS,referenceFrameTimeline} from '../atlas/editor-snake-window-tools.mjs';

export const MAX_SNAKE_PREVIEW_HTML_BYTES=18_000_000;
const digest=bytes=>createHash('sha256').update(bytes).digest('hex');
const safeJson=value=>JSON.stringify(value).replace(/</g,'\\u003c').replace(/\u2028/g,'\\u2028').replace(/\u2029/g,'\\u2029');
const dataUrl=(mime,bytes)=>`data:${mime};base64,${Buffer.from(bytes).toString('base64')}`;
async function readBounded(file,maxBytes){const stat=await fs.stat(file);if(!stat.isFile()||stat.size>maxBytes)throw new RangeError(`${path.basename(file)} is not a regular file below ${maxBytes} bytes`);return fs.readFile(file);}
function moduleImports(source){return [...source.matchAll(/\b(?:import|export)\s+(?:[^'";]*?\s+from\s*)?['"]([^'"]+)['"]/g)].map(match=>match[1]);}

export async function snakeWindowPreviewHtml({document=createNeutralSnakeWindowPreviewDocument(),reference=null}={}){
 const preview=validateSnakeWindowPreview(document),controllerFile=new URL('../atlas/editor-snake-window-preview.mjs',import.meta.url),toolsFile=new URL('../atlas/editor-snake-window-tools.mjs',import.meta.url);
 const [controllerSource,toolsSource]=await Promise.all([fs.readFile(controllerFile,'utf8'),fs.readFile(toolsFile,'utf8')]);
 if(moduleImports(controllerSource).length)throw new Error('Preview controller gained dependencies; update its explicit offline closure');
 const imports=moduleImports(toolsSource);if(imports.length!==1||imports[0]!=='./editor-snake-window-preview.mjs')throw new Error('Preview tools gained dependencies; update their explicit offline closure');
 const toolsBundled=toolsSource.replace("'./editor-snake-window-preview.mjs'","'snake-window/controller'");
 const importsMap={imports:{'snake-window/controller':dataUrl('text/javascript',controllerSource),'snake-window/tools':dataUrl('text/javascript',toolsBundled)}};
 const html=`<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline' data:; style-src 'unsafe-inline'; img-src data: blob:; media-src data: blob:; connect-src 'none'; base-uri 'none'"><title>蛇块 · 有限观察窗口</title><style>html,body{margin:0;background:#f4f7fa}body{padding:22px 12px}${SNAKE_WINDOW_EDITOR_CSS}</style></head>
<body><main id="snake-preview-root"></main><noscript>此预览需要浏览器启用 JavaScript。所有源码、配置及可选媒体均已包含在此文件中。</noscript>
<script type="importmap" id="snake-preview-importmap">${safeJson(importsMap)}</script>
<script type="module" id="snake-preview-entry">import {mountSnakeWindowPreviewEditor} from 'snake-window/tools';
const previewDocument=${safeJson(preview)};
const reference=${safeJson(reference)};
globalThis.snakeWindowPreviewEditor=mountSnakeWindowPreviewEditor({parent:document.getElementById('snake-preview-root'),initialDocument:previewDocument,reference,injectStyle:false});
</script></body></html>\n`;
 if(Buffer.byteLength(html)>=MAX_SNAKE_PREVIEW_HTML_BYTES)throw new RangeError(`Self-contained HTML must be smaller than ${MAX_SNAKE_PREVIEW_HTML_BYTES} bytes`);
 return {html,preview,modules:[{file:'atlas/editor-snake-window-preview.mjs',sha256:digest(controllerSource)},{file:'atlas/editor-snake-window-tools.mjs',sha256:digest(toolsSource)}]};
}

export async function buildSnakeWindowPreview(options={}){
 if(typeof options==='string')options={output:options};
 const output=path.resolve(options.output||'dist/snake-window-preview.html');
 if(path.extname(output).toLowerCase()!=='.html')throw new TypeError('Output must be an .html file');
 const preview=options.input?parseSnakeWindowPreview(await fs.readFile(options.input,'utf8')):validateSnakeWindowPreview(options.document||createNeutralSnakeWindowPreviewDocument());
 let reference=null;const media=[];
 if((options.referencePoster||options.referenceObservations)&&!options.referenceVideo)throw new TypeError('Reference poster/observations require an actual reference video');
 if(options.referenceVideo){
  const ext=path.extname(options.referenceVideo).toLowerCase(),mime={'.mp4':'video/mp4','.webm':'video/webm','.mov':'video/quicktime'}[ext];if(!mime)throw new TypeError('Reference video must be a local .mp4, .webm or .mov');
  const video=await readBounded(options.referenceVideo,13_000_000);reference={videoDataUrl:dataUrl(mime,video),syncByDefault:true};media.push({role:'reference-video',file:path.basename(options.referenceVideo),bytes:video.length,sha256:digest(video)});
  if(options.referencePoster){const poster=await readBounded(options.referencePoster,8_000_000);if(!poster.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])))throw new TypeError('Reference poster must contain actual PNG bytes');reference.posterDataUrl=dataUrl('image/png',poster);media.push({role:'reference-poster',file:path.basename(options.referencePoster),bytes:poster.length,sha256:digest(poster)});}
  if(options.referenceObservations){const bytes=await readBounded(options.referenceObservations,2_000_000),observations=JSON.parse(bytes.toString('utf8'));if(!observations||typeof observations!=='object')throw new TypeError('Reference observations must be a JSON object or array');reference.observations=observations;reference.label=typeof observations.label==='string'?observations.label:undefined;reference.provenance=typeof observations.provenance==='string'?observations.provenance:undefined;const timeline=referenceFrameTimeline(observations);reference.durationSeconds=timeline.at(-1)?.seconds;media.push({role:'reference-observations',file:path.basename(options.referenceObservations),bytes:bytes.length,sha256:digest(bytes),recognizedFrames:timeline.length});}
 }
 const {html,modules}=await snakeWindowPreviewHtml({document:preview,reference}),documentText=serializeSnakeWindowPreview(preview),stem=output.slice(0,-5),documentOutput=stem+'.snake-preview.json',reportOutput=stem+'.build.json';
 const report={format:'snake-window-preview-build',version:1,kind:'finite-occupancy-editor',scope:'preview-experiment-only',parameterStatus:preview.parameterStatus,html:{file:path.basename(output),bytes:Buffer.byteLength(html),sha256:digest(html)},document:{file:path.basename(documentOutput),bytes:Buffer.byteLength(documentText),sha256:digest(documentText)},modules,media,referenceIncluded:!!reference,externalResourceDependencies:[],qmapMutation:false,originalParameterCalibration:false,originalEndpointEvidence:false};
 await fs.mkdir(path.dirname(output),{recursive:true});
 const temporary=output+'.tmp-'+process.pid;await fs.writeFile(temporary,html);await fs.rename(temporary,output);await fs.writeFile(documentOutput,documentText);await fs.writeFile(reportOutput,JSON.stringify(report,null,2)+'\n');
 return {...report,output,documentOutput,reportOutput};
}

export function parseSnakeWindowPreviewBuildArgs(args){
 const options={},names={'--output':'output','--input':'input','--reference-video':'referenceVideo','--reference-observations':'referenceObservations','--reference-poster':'referencePoster'};
 for(let index=0;index<args.length;index++){const arg=args[index];if(names[arg]){const value=args[++index];if(!value||value.startsWith('--'))throw new Error(`Missing value for ${arg}`);if(Object.hasOwn(options,names[arg]))throw new Error(`Duplicate ${arg}`);options[names[arg]]=value;}else if(!arg.startsWith('-')&&!Object.hasOwn(options,'output'))options.output=arg;else throw new Error(`Unknown argument ${arg}`);}
 return options;
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url))console.log(JSON.stringify(await buildSnakeWindowPreview(parseSnakeWindowPreviewBuildArgs(process.argv.slice(2))),null,2));
