/** Recording-only helper for native video capture. OGG assets stay unchanged.
 * ffmpeg decodes their stereo PCM; the shared browser mixer owns all fades. */
import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import {MINECRAFT_LICENSED_MUSIC,minecraftLicensedMusicId,renderMinecraftAudioPCM,renderMinecraftAudioTape} from '../atlas/editor-minecraft-audio.mjs';

export function loadMinecraftLicensedPCM({sampleRate=48000,tracks=Object.keys(MINECRAFT_LICENSED_MUSIC)}={}){
 const musicBuffers={};
 for(const id of new Set(tracks.map(key=>MINECRAFT_LICENSED_MUSIC[key]?key:minecraftLicensedMusicId(key)))){
  const metadata=MINECRAFT_LICENSED_MUSIC[id],file=new URL('../atlas/assets/voxel-music/'+metadata.file,import.meta.url);
  if(!fs.existsSync(file))throw Error('Missing licensed recording: '+metadata.file);
  const result=spawnSync('ffmpeg',['-hide_banner','-loglevel','error','-i',file.pathname,'-vn','-ar',String(sampleRate),'-ac','2','-f','f32le','pipe:1'],{maxBuffer:160*1024*1024});
  if(result.error||result.status!==0)throw Error('Cannot decode licensed recording '+metadata.file+': '+(result.error?.message||result.stderr?.toString()));
  const bytes=result.stdout,pcm=new Float32Array(bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength));
  musicBuffers[id]={pcm,channels:2,sampleRate,title:metadata.title,file:metadata.file,duration:pcm.length/2/sampleRate};
 }
 return musicBuffers;
}

export function minecraftLicensedAudioOptions(options={}){
 const sampleRate=options.sampleRate??48000,tracks=options.musicIntervals?.map(segment=>segment.key);
 return{...options,sampleRate,musicMode:'licensed',musicBuffers:options.musicBuffers??loadMinecraftLicensedPCM({sampleRate,...(tracks?.length?{tracks}:{})})};
}
export const renderMinecraftLicensedAudioPCM=(tape=[],options={})=>renderMinecraftAudioPCM(tape,minecraftLicensedAudioOptions(options));
export const renderMinecraftLicensedAudioTape=(tape=[],options={})=>renderMinecraftAudioTape(tape,minecraftLicensedAudioOptions(options));
