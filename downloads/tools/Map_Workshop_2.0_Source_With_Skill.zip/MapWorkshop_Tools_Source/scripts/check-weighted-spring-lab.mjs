// Execute the actual saved lab's four entry buttons and player loops. Simulated
// DOM verification is separate from physical browser, layout and hardware QA.
import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createContext,SourceTextModule} from 'node:vm';
import {inspectOfflineHtml} from './check-offline-html.mjs';
import {installSimulatedPlayDom} from '../tests/fixtures/simulated-play-dom.mjs';
import {nativeSession} from '../tests/fixtures/shell-coin-native.mjs';

const file=process.argv[2];if(!file)throw Error('Usage: node --experimental-vm-modules scripts/check-weighted-spring-lab.mjs HTML');
const html=await fs.readFile(file,'utf8'),checked=inspectOfflineHtml(html),dom=installSimulatedPlayDom(),timers=new Map(),storage=new Map();let id=0,networkRequests=0,audioPlays=0;
class EmbeddedImage{set src(q){assert(String(q).startsWith('data:image/'));this._src=q;}get src(){return this._src;}async decode(){return this;}}
class EmbeddedAudio{paused=true;constructor(q){if(q)this.src=q;}set src(q){assert(String(q).startsWith('data:audio/'));this._src=q;}get src(){return this._src;}async play(){this.paused=false;audioPlays++;}pause(){this.paused=true;}}
const canonical=q=>JSON.parse(JSON.stringify(q)),settle=async()=>{for(let n=0;n<60;n++)await Promise.resolve();};
try{
 dom.document.body.innerHTML=html.match(/<body>([\s\S]*?)<script type="importmap">/)[1];
 const context=createContext({document:dom.document,window:dom.window,navigator:globalThis.navigator,performance:globalThis.performance,requestAnimationFrame:globalThis.requestAnimationFrame,cancelAnimationFrame:globalThis.cancelAnimationFrame,FontFace:globalThis.FontFace,Option:globalThis.Option,Image:EmbeddedImage,Audio:EmbeddedAudio,URL,Blob,TextEncoder,TextDecoder,Uint8Array,Uint8ClampedArray,ArrayBuffer,structuredClone,crypto:globalThis.crypto,atob,btoa,console,localStorage:{getItem:k=>storage.get(k)??null,setItem:(k,q)=>storage.set(k,q),removeItem:k=>storage.delete(k)},fetch(){networkRequests++;throw Error('Lab must be offline');},setTimeout(callback,delay){timers.set(++id,{callback,delay});return id;},clearTimeout(q){timers.delete(q);}}),modules=new Map();
 for(const [id,source]of checked.modules)modules.set(id,new SourceTextModule(source,{context,identifier:id,initializeImportMeta(meta){meta.url='data:text/javascript,';}}));
 const root=new SourceTextModule(checked.root,{context,identifier:'lab-bootstrap'}),link=id=>{assert(modules.has(id));return modules.get(id);};await root.link(link);for(const m of modules.values())if(m.status==='unlinked')await m.link(link);await root.evaluate();
 const results=[],scenes=['lift','impact','drop','cargo'],counts=[24,11,30,24];
 for(let n=0;n<scenes.length;n++){
  const selection=dom.document.getElementById('lab-case');selection.value=String(n);selection.onchange();await dom.document.getElementById('start').onclick();await settle();
  const canvas=dom.document.querySelector('dialog canvas');assert(canvas?.workshopRead);const qmap=JSON.parse(await fs.readFile(path.join(path.dirname(file),'weighted-spring-'+scenes[n]+'.qmap.json'),'utf8')),native=nativeSession(qmap);
  const first=canvas.workshopRead();assert.equal(first.p.x,qmap.rooms[0].map.objects.find(q=>q.kind==='spawn').x);
  let rafs=0;while(canvas.workshopRead().tick<counts[n]&&rafs++<counts[n]+5){
   dom.frames(1);const actual=canvas.workshopRead();while(native.view().tick<actual.tick)native.step({});const expected=native.view();assert.equal(actual.tick,expected.tick);
   for(const key of ['p','geometry','enemies','items','lives'])assert.deepEqual(canonical(actual[key]),canonical(expected[key]),scenes[n]+' tick '+actual.tick+' '+key);
   assert.deepEqual(canonical(actual.smm2Mechanics.carriers),canonical(expected.smm2Mechanics.carriers));
  }
  assert(canvas.workshopRead().tick>=counts[n]);assert.equal(canvas.workshopRead().lives,3);results.push({scene:scenes[n],ordinaryEmptyInputFrames:native.inputs.length,rafFrames:rafs,actualBootstrapAndPlayerExecuted:true,nativeFrameStateExact:true});
  dom.document.querySelector('dialog').close();await settle();
 }
 assert.equal(networkRequests,0);console.log(JSON.stringify({moduleCount:checked.moduleCount,scenes:results,ordinaryInputFrames:results.reduce((s,q)=>s+q.ordinaryEmptyInputFrames,0),networkRequests,audioPlays,physicalBrowserTested:false,sourceNumericalCalibration:false}));
}finally{dom.document.querySelector('dialog')?.close();dom.restore();}
