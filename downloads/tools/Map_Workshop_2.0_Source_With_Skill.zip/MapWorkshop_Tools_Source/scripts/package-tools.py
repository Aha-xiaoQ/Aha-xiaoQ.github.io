#!/usr/bin/env python3
"""Freeze this standalone projection's byte manifest and deterministic source ZIP.
Run after source freeze and validation. No network, upload, or external mutation.
"""
from pathlib import Path
import hashlib,json,zipfile
root=Path(__file__).resolve().parents[1]
sha=lambda b:hashlib.sha256(b).hexdigest()
version=json.loads((root/'package.json').read_text())['version']
baseline_path=root/'provenance/BASELINE_1.10.2-tools.1_MANIFEST.json'
baseline_bytes=baseline_path.read_bytes()
assert sha(baseline_bytes)=='7c33018e88f92dd85cbab3caa3e5fa053edc80313812b3343fcb5e2a4605bca3'
baseline={f['path']:f for f in json.loads(baseline_bytes)['files']}
exclude={'PACKAGE_MANIFEST.json','PACKAGE_MANIFEST.sha256','UPGRADE_FILES_SHA256.json'}
def selected(p):
 rel=p.relative_to(root)
 return p.is_file() and not p.is_symlink() and not any(q in {'node_modules','dist','.git','__pycache__'} for q in rel.parts) and rel.name not in exclude and not rel.name.endswith('.log')
files=[{'path':p.relative_to(root).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(root.rglob('*')) if selected(p)]
assert not any(f['path'].startswith('course-') or '/five-regions/' in f['path'] or f['path'].endswith(('.mp4','.webm')) for f in files)
current={f['path']:f for f in files}
delta=[]
for p,f in current.items():
 old=baseline.get(p)
 delta.append({**f,'baselineSha256':old['sha256'] if old else None,'status':'unchanged' if old and old['sha256']==f['sha256'] else 'modified' if old else 'added'})
missing=[{'path':p,'baselineSha256':f['sha256'],'status':'absent-from-this-projection'} for p,f in sorted(baseline.items()) if p not in current and p not in exclude]
upgrade={'format':'map-workshop-file-sha-upgrade','version':1,'sourceVersion':version,'commonBaseline':{'version':'1.10.2-tools.1','manifestSha256':sha(baseline_bytes)},'gitCommit':None,'counts':{s:sum(f['status']==s for f in delta) for s in ['added','modified','unchanged']},'files':delta,'absentBaselinePaths':missing,'absenceMeaning':'Projection selection; not a claim that another branch deleted these files'}
(root/'UPGRADE_FILES_SHA256.json').write_text(json.dumps(upgrade,ensure_ascii=False,indent=2)+'\n')
u=root/'UPGRADE_FILES_SHA256.json';files.append({'path':u.name,'bytes':u.stat().st_size,'sha256':sha(u.read_bytes())});files.sort(key=lambda f:f['path'])
manifest={'schemaVersion':1,'package':'map-workshop-tools','version':version,'scope':'Independent neutral tool source plus fully bundled matching map-workshop skill; no private courses or raw reference movies','gitCommit':None,'commonAstraBaselineVersion':'1.10.2-tools.1','commonAstraManifestSha256':sha(baseline_bytes),'excluded':['node_modules','dist','private courses and factories','private full input records','raw reference video','manifest self-reference and checksum'],'files':files}
m=json.dumps(manifest,ensure_ascii=False,indent=2)+'\n';(root/'PACKAGE_MANIFEST.json').write_text(m);(root/'PACKAGE_MANIFEST.sha256').write_text(sha(m.encode())+'  PACKAGE_MANIFEST.json\n')
archive=root.parent/f'Map_Workshop_Tools_{version}_Source_With_Skill.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for rel in [f['path'] for f in files]+['PACKAGE_MANIFEST.json','PACKAGE_MANIFEST.sha256']:
  info=zipfile.ZipInfo('MapWorkshop_Tools_Source/'+rel,date_time=(2026,10,7,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,(root/rel).read_bytes())
assert archive.stat().st_size<20_000_000,archive.stat().st_size
(archive.parent/'SHA256SUMS').write_text(sha(archive.read_bytes())+'  '+archive.name+'\n')
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'manifestSha256':sha(m.encode()),'files':len(files)},indent=2))
