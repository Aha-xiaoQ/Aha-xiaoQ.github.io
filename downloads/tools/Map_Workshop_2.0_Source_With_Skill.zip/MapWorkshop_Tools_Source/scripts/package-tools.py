#!/usr/bin/env python3
"""Freeze complete source+media and a minimal repo-root GitHub update ZIP. No upload."""
from pathlib import Path
import hashlib,json,zipfile,sys
root=Path(__file__).resolve().parents[1]
out=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else root/'dist/releases'
out.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
version=json.loads((root/'package.json').read_text())['version']
exclude={'PACKAGE_MANIFEST.json','PACKAGE_MANIFEST.sha256','UPGRADE_FILES_SHA256.json'}
def selected(p):
 rel=p.relative_to(root)
 return p.is_file() and not p.is_symlink() and not any(v in {'node_modules','dist','.git','__pycache__'} for v in rel.parts) and rel.name not in exclude and not rel.name.endswith(('.log','.mp4','.webm'))
files=[{'path':p.relative_to(root).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(root.rglob('*')) if selected(p)]
bb=(root/'provenance/BASELINE_1.10.34_MANIFEST.json').read_bytes();baseline={f['path']:f for f in json.loads(bb)['files']}
delta=[{**f,'baselineSha256':baseline.get(f['path'],{}).get('sha256'),'status':'added' if f['path'] not in baseline else 'unchanged' if baseline[f['path']]['sha256']==f['sha256'] else 'modified'} for f in files]
p=root/'UPGRADE_FILES_SHA256.json';p.write_text(json.dumps({'version':version,'baselineVersion':'1.10.34','baselineManifestSha256':sha(bb),'files':delta,'absentBaselinePaths':sorted(set(baseline)-{f['path'] for f in files}-exclude)},ensure_ascii=False,indent=2)+'\n');files.append({'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())});files.sort(key=lambda f:f['path'])
m={'schemaVersion':1,'package':'map-workshop-tools','version':version,'distributionName':'地图工坊 2.0','packagingRevision':'standard-github-1','excluded':['node_modules','dist','video recordings','manifest self-reference'],'files':files};p=root/'PACKAGE_MANIFEST.json';p.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n');(root/'PACKAGE_MANIFEST.sha256').write_text(sha(p.read_bytes())+'  PACKAGE_MANIFEST.json\n')
def add(z,name,data):
 info=zipfile.ZipInfo(name,date_time=(2026,10,18,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,data)
inner=out/'Map_Workshop_2.0_Source_With_Skill.zip'
with zipfile.ZipFile(inner,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for rel in [f['path'] for f in files]+['PACKAGE_MANIFEST.json','PACKAGE_MANIFEST.sha256']:add(z,'MapWorkshop_Tools_Source/'+rel,(root/rel).read_bytes())
record={'path':'downloads/tools/'+inner.name,'bytes':inner.stat().st_size,'sha256':sha(inner.read_bytes()),'replacesSha256':'3b1bef9e47c9ef47e12c9d12a9b892e5fd8b886e64108372a9f61c3144b389b9'}
meta={'targetRepository':'Aha-xiaoQ/Aha-xiaoQ.github.io','baselineCommit':'cb682d3baa2592db07163714d61e8aa66251305a','version':version,'published':False,'replacementFiles':[record],'preserve':'All other website files; old online editor is not replaced','sourceManifestSha256':sha((root/'PACKAGE_MANIFEST.json').read_bytes())}
docroot='docs/release-map-workshop-'+version+'/'
outer=out/f'Aha-xiaoQ.github.io_Map_Workshop_{version}_Update.zip'
with zipfile.ZipFile(outer,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 add(z,record['path'],inner.read_bytes());add(z,docroot+'UPDATE.md',(root/'docs/GITHUB_UPDATE_1.11.0.md').read_bytes());add(z,docroot+'CHECKSUMS.json',(json.dumps(meta,ensure_ascii=False,indent=2)+'\n').encode());add(z,docroot+'RELEASE-CHECK.md',(root/'RELEASE-CHECK-1.11.0.md').read_bytes())
for p in [inner,outer]:
 with zipfile.ZipFile(p) as z:assert z.testzip() is None
result={**meta,'outerArchive':{'file':outer.name,'bytes':outer.stat().st_size,'sha256':sha(outer.read_bytes())},'innerArchive':record,'sourceFiles':len(files)}
(out/'STANDARD_RELEASE.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');(out/'SHA256SUMS').write_text(''.join(sha(p.read_bytes())+'  '+p.name+'\n' for p in [inner,outer]));print(json.dumps(result,ensure_ascii=False,indent=2))
