from pathlib import Path
from PIL import Image, ImageSequence, ImageDraw
from collections import Counter
import hashlib, json
p=Path(__file__).parent
source=p/'smw-original-mario-4.png'
im=Image.open(source).convert('RGBA')
bg={(0,84,84,255),(0,66,66,255),(0,148,148,255),(0,116,116,255),(0,52,52,255)}
rows={
 'small-idle':[(8,33,56,81)],
 'small-walk':[(164+52*i,33,212+52*i,81) for i in range(3)],
 'small-run':[(320+52*i,33,368+52*i,81) for i in range(3)],
 'small-swim':[(528+52*i,97,576+52*i,145) for i in range(3)],
 'super-idle':[(8,577,56,625)],
 'super-walk':[(164+52*i,577,212+52*i,625) for i in range(3)],
 'super-run':[(320+52*i,577,368+52*i,625) for i in range(3)],
 'super-swim':[(528+52*i,647,576+52*i,695) for i in range(3)],
 'small-death':[(528,251,576,299)],
}
items=[]
for name,boxes in rows.items():
 cells=[]
 for box in boxes:
  c=im.crop(box);c.putdata([(0,0,0,0) if px in bg else px for px in c.getdata()]);cells.append(c)
 bboxes=[c.getbbox() for c in cells];union=(min(b[0] for b in bboxes),min(b[1] for b in bboxes),max(b[2] for b in bboxes),max(b[3] for b in bboxes))
 frames=[]
 for i,(box,c,b) in enumerate(zip(boxes,cells,bboxes)):
  tight=c.crop(b);filename=f'smw-{name}-{i}.png';tight.save(p/filename)
  full=c.crop(union);canvasfile=f'smw-{name}-{i}-aligned.png';full.save(p/canvasfile)
  cellfile=f'smw-{name}-{i}-cell.png';c.save(p/cellfile)
  entry=dict(filename=filename,alignedFilename=canvasfile,sourceSheet=source.name,sourceSheetSHA256=hashlib.sha256(source.read_bytes()).hexdigest(),sourceCellRect=list(box),sourceSpriteRect=[b[0]+box[0],b[1]+box[1],b[2]+box[0],b[3]+box[1]],localSpriteRect=list(b),nativeWidth=tight.width,nativeHeight=tight.height,alignedWidth=full.width,alignedHeight=full.height,offsetWithinAligned=[b[0]-union[0],b[1]-union[1]],frameDurationMS=None,sha256=hashlib.sha256((p/filename).read_bytes()).hexdigest(),alignedSHA256=hashlib.sha256((p/canvasfile).read_bytes()).hexdigest(),rgbaSHA256=hashlib.sha256(tight.tobytes()).hexdigest(),opaqueColors=sorted([list(c) for c in set(tight.getdata()) if c[3]]))
  entry.update(format='PNG', temporalFrameCount=1, sourceCellFilename=cellfile, sourceCellWidth=c.width, sourceCellHeight=c.height, visibleBoundsWithinSourceCell=list(b), alignedOriginWithinSourceCell=[union[0],union[1]], sourceCellSHA256=hashlib.sha256((p/cellfile).read_bytes()).hexdigest(), suggestedBodyPivotWithinSourceCell=[24,39 if name.startswith('small-') else 38], pivotStatus='Suggested renderer registration from fixed source-cell layout; not a verified native game collision/body pivot')
  frames.append(entry)
 items.append(dict(animation=name,sourceLabel=name.replace('small-','Small Mario ').replace('super-','Super Mario/Fire Mario '),frameCount=len(frames),distinctRGBAFrames=len({f['rgbaSHA256'] for f in frames}),nativeTimingVerified=False,frames=frames))
# Decode original gallery GIFs with the original frame canvas size and transparency.
gallery=[]
for file in ['Mario_SMW.gif','Navmario.gif']:
 gi=Image.open(p/file)
 for i,frame in enumerate(ImageSequence.Iterator(gi)):
  fi=frame.convert('RGBA');name=f'{file[:-4]}-frame-{i}.png';fi.save(p/name)
  gallery.append(dict(filename=name,sourceGIF=file,frameIndex=i,width=fi.width,height=fi.height,opaqueBounds=list(fi.getbbox()),galleryDurationMS=frame.info.get('duration'),nativeTimingVerified=False,sha256=hashlib.sha256((p/name).read_bytes()).hexdigest()))
manifest=dict(sourcePageURL='https://www.mariouniverse.com/sprites-snes-smw/',sourceAssetURL='https://www.mariouniverse.com/wp-content/img/sprites/snes/smw/mario-4.png',sourceFormat='PNG',sourceSheetWidth=im.width,sourceSheetHeight=im.height,sourceFrameCount=1,sourceProvenance='Original SNES Super Mario World section of Mario Universe; on-sheet footer credits Mister Man for ripping Super Mario World (SNES). The only extracted rows here are Small Mario and Super Mario/Fire Mario labeled native poses. No Custom section material, no invented poses, no resizing, no palette changes.',licenseNotice='Nintendo copyrighted sprite artwork. Hosting page and on-sheet credit do not grant a new distribution license.',extraction='Only source panel background colors made transparent; exact sprite pixels copied. Tight native bounds retained, plus aligned variants keeping source-cell positions with a shared canvas per animation. PNG pose sheets have no temporal frame durations; source native playback timing must be measured independently.',animations=items,galleryFrames=gallery)
manifest['facing']='left'
manifest['baselineIdentity']='Idle silhouettes match current Small14×20 and Super15×28 after horizontal mirror, with no other opaque pixel changes except #f8f8f8 source white versus #ffffff existing gallery white. See BASELINE_PIXEL_IDENTITY.json. Extracted files keep original left-facing pixels and source palette.'
for anim in items:
 anim['sourceColumnOrderIsNativePlaybackOrderVerified']=False
 if anim['animation'] in ('small-walk','small-run'):
  anim['duplicateNote']='The source sheet includes two identical first poses and one other pose. Preserve the two distinct native appearances rather than inventing a third drawing.'
atlas=Image.new('RGBA',(144,48*len(items)),(0,0,0,0))
for j,row in enumerate(items):
 for i,f in enumerate(row['frames']):
  cell=Image.open(p/f['sourceCellFilename']).convert('RGBA');atlas.paste(cell,(i*48,j*48));f['atlasRect']=[i*48,j*48,48,48]
atlas.save(p/'ORIGINAL_SMW_PLAYER_ATLAS.png')
manifest['runtimeAtlas']=dict(filename='ORIGINAL_SMW_PLAYER_ATLAS.png',width=atlas.width,height=atlas.height,frameCellWidth=48,frameCellHeight=48,sha256=hashlib.sha256((p/'ORIGINAL_SMW_PLAYER_ATLAS.png').read_bytes()).hexdigest(),purpose='Compact exact original Small/Super idle, walk, run, swim, and Small death cells only. No labels, guides, other forms, interpolation, resizing or recoloring.')
(p/'EXTRACTED_FRAME_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
# Visual inspection output with native pixels nearest-neighbor enlarged, not a source runtime asset.
cv=Image.new('RGB',(680,30+len(items)*115),(28,32,40));draw=ImageDraw.Draw(cv)
for j,row in enumerate(items):
 y=24+j*115;draw.text((8,y+8),row['animation'],fill='white')
 for i,f in enumerate(row['frames']):
  fi=Image.open(p/f['alignedFilename']);fi=fi.resize((fi.width*3,fi.height*3),Image.Resampling.NEAREST)
  cv.paste(fi,(165+i*155,y),fi);draw.text((165+i*155,y+85),f"{f['nativeWidth']}x{f['nativeHeight']} native",fill='white')
cv.save(p/'ORIGINAL_SMW_FRAME_CONTACT.png')
for row in items: print(row['animation'],row['frameCount'],'poses',row['distinctRGBAFrames'],'distinct',[(f['nativeWidth'],f['nativeHeight']) for f in row['frames']])
