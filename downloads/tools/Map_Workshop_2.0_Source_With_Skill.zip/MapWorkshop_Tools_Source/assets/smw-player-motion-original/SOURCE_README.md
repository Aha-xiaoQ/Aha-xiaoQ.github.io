# Original SMW player animation supplement

Selected source: https://www.mariouniverse.com/sprites-snes-smw/
Actual PNG: https://www.mariouniverse.com/wp-content/img/sprites/snes/smw/mario-4.png

The sheet is listed in the original SNES section, above the separate Custom section. Its footer credits Mister Man for ripping Super Mario World (SNES). Only the labeled Small Mario and Super Mario/Fire Mario sections were extracted. The source is a different game and sheet from the stopped SMM2 TSR119043 route. No stopped sheet or mirror was fetched.

`EXTRACTED_FRAME_MANIFEST.json` records exact original crop rectangles, native bounds, aligned bounds and offsets, opaque colors, hashes and source provenance. Extracted sprites face left. Background removal makes only the teal source panel colors transparent. Art is copied pixel for pixel, with no scaling, stretching, recoloring or invented limb drawing.

Small swim has three distinct poses on an aligned 16×20 canvas; Super swim has three distinct poses on an aligned 20×27 canvas. The top 11 Small / 13 Super pixel rows are unchanged across each swim sequence. Small walk and run each have two distinct appearances; the sheet repeats one appearance across the first two columns. Super walk and run each have three distinct appearances. Death is a native Small Mario 16×24 supplement; course42 footage does not establish it.

The source idle outlines match the current project Small14×20 and Super15×28 exactly after a horizontal mirror. Their only opaque pixel-color difference is source SNES white #f8f8f8 versus existing MarioWiki #ffffff. See `BASELINE_PIXEL_IDENTITY.json`.

The PNG sheet proves sprite art and source labels, not native animation order, stroke/coast assignment, gameplay delays, collisions or physics. These must be checked against the original gameplay clip. No GIF was made from the PNG poses because playback order and native timing are not verified here.

`INITIAL_FRAME_MANIFEST.json` records separate original-SMW Small walking GIF (15×21, two encoded frames at100ms) and Super walking GIF (16×29, three encoded frames at10ms), plus Small death PNG. Those delays are gallery-authored and are not source gameplay timing. Decoded GIF frames keep the native source canvas size.

`ORIGINAL_SMW_FRAME_CONTACT.png` is a labeled review image at nearest-neighbor3× enlargement, not a runtime source sprite.

Nintendo owns the original artwork; the on-sheet rip credit and public hosting do not grant a new distribution license.

For renderer registration use the `-cell.png` files (all48×48) or source cell rectangles directly, not independent tight bounds. Suggested fixed registration: Small(24,39), Super(24,38) within each48×48 cell. These are review/renderer anchors derived from the sheet placement, not verified original-game pivots. `ORIGINAL_SMW_FIXED_CELL_REVIEW.png` shows native positions and the proposed common bottom/body pivot across idle/walk/run/swim. `ALL_ASSET_FORMATS.json` inventories all PNG/GIF bytes, formats, dimensions, temporal frame counts and hashes.

`ORIGINAL_SMW_PLAYER_ATLAS.png` (144×432) packs only these21 pose cells into a compact transparent atlas, with fixed48×48 cells and no review guides. `atlasRect` in the frame manifest uses x/y/width/height. Every atlas cell was byte-compared against its source-cell PNG.

Independent 1.10.34 projection: original full sheet `smw-original-mario-4.png` and `ORIGINAL_SMW_FRAME_CONTACT.png` are historical source/review paths rather than bundled files. The runtime extracts, fixed cells and compact atlas are retained; exact source crop rectangles and original SHA remain in EXTRACTED_FRAME_MANIFEST.json. The original THIRD_PARTY_NOTICE.txt is restored byte-for-byte from the user-supplied 1.10.23-tools.1 upgrade target. Historical excluded path hashes and decisions are recorded in provenance/INCOMING_1.10.23_UPGRADE_TARGET_COMPARISON.json at the project root.
