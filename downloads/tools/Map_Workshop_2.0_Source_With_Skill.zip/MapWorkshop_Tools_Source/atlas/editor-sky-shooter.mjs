/** Original armed-cloud arcade composition. Native Lakitu Cloud physics stays
 * unchanged. This controller owns only explicit drone flight and travelling
 * projectiles; the host owns native enemy defeat, damage, lives and collection.
 * All timings and formation coordinates are author configuration, not original
 * Nintendo or Namco parameters. There is no timer/input-script reward. */
export const SKY_SHOOTER_VERSION=1;
const EPS=1e-7;
const leafFields=['version','cloudId','activation','gateIds','rewardId','drones','weapon','formation','attack'];
export const SKY_SHOOTER_FIELDS=Object.freeze([...leafFields,'loopingDivers','enemyFire']);
export const SKY_SHOOTER_LOOP_FIELDS=Object.freeze(['version','actorIds','exitY','reentryY','sideX','exitSpeed','reentrySpeed','returnSpeed','maxActive']);
export const SKY_SHOOTER_ENEMY_FIRE_FIELDS=Object.freeze(['version','downwardActorIds','diverActorIds','firstDownwardShotFrames','downwardIntervalFrames','telegraphFrames','shotSpeed','shotLifeFrames','maxShots','diverAttackY','minAimDistance']);
const plain=q=>q&&typeof q==='object'&&!Array.isArray(q)&&[Object.prototype,null].includes(Object.getPrototypeOf(q));
const fail=q=>{throw Error(q);};
const finite=(v,a,b)=>Number.isFinite(v)&&v>=a&&v<=b;
const integer=(v,a,b)=>Number.isSafeInteger(v)&&finite(v,a,b);
const id=q=>typeof q==='string'&&q.length<=72&&/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(q)&&!['constructor','prototype','__proto__'].includes(q);
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const body=q=>({x:q.x,y:q.y,w:q.w,h:q.h});
const live=q=>!!q&&!q.dead&&!q.dying&&!q.removed;
const overlap=(a,b)=>a.x+a.w>b.x+EPS&&a.x<b.x+b.w-EPS&&a.y+a.h>b.y+EPS&&a.y<b.y+b.h-EPS;
const copy=q=>structuredClone(q);
function closed(q,fields,label,optional=[]){
 if(!plain(q))fail('Invalid '+label);
 for(const k of Reflect.ownKeys(q))if(typeof k!=='string'||!fields.includes(k)&&!optional.includes(k)||['constructor','prototype','__proto__'].includes(k))fail('Unknown '+label+' field: '+String(k));
 for(const k of fields)if(!Object.hasOwn(q,k))fail('Missing '+label+' field: '+k);
}
function inside(q,w,h){return ['x','y','w','h'].every(k=>Number.isFinite(q[k]))&&q.w>0&&q.h>0&&q.x>=0&&q.y>=0&&q.x+q.w<=w&&q.y+q.h<=h;}
export function validateSkyShooterRoom(room,spec=room?.smm2Mechanics?.skyShooter){
 if(spec===undefined)return true;
 closed(spec,leafFields,'Sky Shooter',['loopingDivers','enemyFire']);if(spec.version!==1)fail('Unknown Sky Shooter version');
 const map=room?.map;if(!map||!finite(map.width,128,32768)||!finite(map.height,128,4096)||!Array.isArray(map.geometry)||!Array.isArray(map.objects))fail('Sky Shooter needs a bounded native room');
 if(!id(spec.cloudId)||!room.smm2Mechanics?.lakituClouds?.clouds.some(q=>q.id===spec.cloudId))fail('Sky Shooter needs an existing Lakitu Cloud');
 closed(spec.activation,['x','y','w','h'],'Sky Shooter activation');if(!inside(spec.activation,map.width,map.height))fail('Sky Shooter activation is outside the room');
 if(!Array.isArray(spec.gateIds)||!spec.gateIds.length||spec.gateIds.length>16||new Set(spec.gateIds).size!==spec.gateIds.length||spec.gateIds.some(k=>!id(k)||!map.geometry.some(q=>q.id===k&&q.collision==='solid'&&!q.hidden)))fail('Sky Shooter needs unique visible native solid gates');
 if(!id(spec.rewardId)||!map.objects.some(q=>q.id===spec.rewardId&&q.kind==='coin')||!room.smm2Mechanics?.pinkCoins?.some(q=>q.id===spec.rewardId))fail('Sky Shooter reward must be an existing typed Pink coin');
 const looping=Object.hasOwn(spec,'loopingDivers');
 if(!Array.isArray(spec.drones)||!spec.drones.length||spec.drones.length>(looping?30:24))fail('Invalid Sky Shooter drone list');
 const used=new Set(),waves=new Set();
 for(const q of spec.drones){
  closed(q,['id','wave','x','y','phaseFrames'],'Sky Shooter drone');
  const actor=map.objects.find(o=>o.id===q.id);
  if(!id(q.id)||used.has(q.id)||!actor||actor.kind!=='walker'||actor.w!==16||actor.h!==16||!integer(q.wave,1,8)||!integer(q.phaseFrames,0,36000))fail('Sky Shooter drone must reference a unique native 16 by 16 walker');
  const sourceMarker=room.markers?.find(o=>o.id===q.id&&o.kind?.startsWith('enemy-'));
  if(sourceMarker&&sourceMarker.kind!=='enemy-goomba'||room.enemySkins?.[q.id]&&!/^(enemy-|marker-)?goomba$/.test(room.enemySkins[q.id]))fail('Sky Shooter flight pack needs a native Goomba identity');
  if(room.marioModules?.enemyVariants?.[q.id]||['bowserJuniors','underwaterActors','parachuteActors'].some(key=>room.smm2Mechanics?.[key]?.actors?.some(o=>o.id===q.id))||room.smm2Mechanics?.portableStones?.stones?.some(o=>o.id===q.id)||room.smm2Mechanics?.localUpdrafts?.twisters?.some(o=>o.id===q.id))fail('Sky Shooter drone cannot also own another enemy motion rule');
  used.add(q.id);waves.add(q.wave);
 }
 for(let wave=1;wave<=waves.size;wave++)if(!waves.has(wave))fail('Sky Shooter waves must be contiguous from 1');
 closed(spec.weapon,['cooldownFrames','speed','lifeFrames','maxShots'],'Sky Shooter weapon');
 const w=spec.weapon;if(!integer(w.cooldownFrames,6,120)||!finite(w.speed,1,16)||!integer(w.lifeFrames,8,240)||!integer(w.maxShots,1,12))fail('Invalid bounded Sky Shooter weapon tuning');
 closed(spec.formation,['amplitudeX','amplitudeY','periodFrames','waveDelayFrames'],'Sky Shooter formation');
 const f=spec.formation;if(!finite(f.amplitudeX,0,64)||!finite(f.amplitudeY,0,32)||!integer(f.periodFrames,60,36000)||!integer(f.waveDelayFrames,24,600))fail('Invalid Sky Shooter formation tuning');
 for(const q of spec.drones)if(!inside({x:q.x-f.amplitudeX,y:q.y-f.amplitudeY,w:16+f.amplitudeX*2,h:16+f.amplitudeY*2},map.width,map.height))fail('Sky Shooter formation range is outside the room');
 closed(spec.attack,['firstAttackFrames','intervalFrames','telegraphFrames','diveSpeed','diveTurnFrames','missileSpeed','missileLifeFrames','maxMissiles'],'Sky Shooter attack');
 const a=spec.attack;if(!integer(a.firstAttackFrames,36,600)||!integer(a.telegraphFrames,36,180)||!integer(a.intervalFrames,a.telegraphFrames+24,1200)||!finite(a.diveSpeed,.5,4)||!integer(a.diveTurnFrames,24,240)||!finite(a.missileSpeed,.5,3)||!integer(a.missileLifeFrames,24,300)||!integer(a.maxMissiles,1,6))fail('Invalid bounded Sky Shooter attack tuning');
 if(looping){
  const l=spec.loopingDivers;closed(l,SKY_SHOOTER_LOOP_FIELDS,'Sky Shooter looping divers');
  if(l.version!==1||!Array.isArray(l.actorIds)||!l.actorIds.length||l.actorIds.length>6||new Set(l.actorIds).size!==l.actorIds.length||l.actorIds.some(k=>!id(k)||!used.has(k)))fail('Looping divers need one to six unique bound native drone IDs');
  if(waves.size!==1||spec.drones.length-l.actorIds.length>24)fail('Looping divers require one formation with at most 24 base bodies');
  if(!integer(l.maxActive,1,2)||l.maxActive>l.actorIds.length||!finite(l.exitSpeed,.5,4)||!finite(l.reentrySpeed,.5,4)||!finite(l.returnSpeed,.5,4))fail('Invalid bounded looping-diver travel tuning');
  if(!finite(l.sideX,0,map.width-16)||!finite(l.reentryY,0,map.height-16)||!finite(l.exitY,l.reentryY+32,map.height-16))fail('Looping-diver corridor is outside the room');
  const selected=spec.drones.filter(q=>l.actorIds.includes(q.id)),top=Math.min(...spec.drones.map(q=>q.y-f.amplitudeY));
  if(l.reentryY+8>top||selected.some(q=>q.y+f.amplitudeY+16>=l.exitY)||l.sideX+16>spec.activation.x||l.sideX+16>Math.min(...spec.drones.map(q=>q.x-f.amplitudeX)))fail('Looping-diver corridor must exit below and re-enter above the intact formation from its left side');
  // This optional path is continuous native-body motion. It never tunnels
  // through a solid ceiling/floor or wraps a body to a newly invented actor.
  const bounds={x:l.sideX,y:l.reentryY,w:Math.max(spec.activation.x+spec.activation.w,...spec.drones.map(q=>q.x+f.amplitudeX+16))-l.sideX,h:l.exitY+16-l.reentryY};
  if(map.geometry.some(q=>!q.hidden&&q.collision==='solid'&&overlap(bounds,q)))fail('Looping-diver corridor crosses native solid geometry');
 }
 if(Object.hasOwn(spec,'enemyFire')){
  const e=spec.enemyFire;closed(e,SKY_SHOOTER_ENEMY_FIRE_FIELDS,'Sky Shooter enemy fire');
  if(e.version!==1||!looping||waves.size!==1)fail('Enemy fire needs version 1 and one explicit looping-diver formation');
  for(const [key,max]of [['downwardActorIds',24],['diverActorIds',6]]){
   const ids=e[key];if(!Array.isArray(ids)||Object.getPrototypeOf(ids)!==Array.prototype||!ids.length||ids.length>max||new Set(ids).size!==ids.length||Array.from(ids).some(k=>!id(k)||!used.has(k))||Reflect.ownKeys(ids).some(k=>k!=='length'&&(typeof k!=='string'||!/^\d+$/.test(k)||String(Number(k))!==k||Number(k)>=ids.length)))fail('Enemy fire needs unique bound '+key);
  }
  if(e.downwardActorIds.some(k=>e.diverActorIds.includes(k))||e.diverActorIds.length!==spec.loopingDivers.actorIds.length||e.diverActorIds.some(k=>!spec.loopingDivers.actorIds.includes(k)))fail('Enemy fire downward bodies and looping-diver IDs must be disjoint and match the explicit return group');
  if(!integer(e.firstDownwardShotFrames,36,600)||!integer(e.telegraphFrames,36,180)||!integer(e.downwardIntervalFrames,e.telegraphFrames+24,1200)||!finite(e.shotSpeed,.5,3)||!integer(e.shotLifeFrames,24,300)||!integer(e.maxShots,1,6)||!finite(e.minAimDistance,24,128))fail('Invalid bounded Sky Shooter enemy-fire tuning');
  const lower=Math.max(...spec.drones.filter(q=>e.diverActorIds.includes(q.id)).map(q=>q.y+f.amplitudeY+16));
  if(!finite(e.diverAttackY,lower+EPS,spec.loopingDivers.exitY-EPS))fail('Enemy-fire attack segment must be below the diver bodies and above their exit');
 }
 return true;
}
/** Continuous rectangle entry. Relative movement also catches a moving drone. */
function sweep(from,dx,dy,to){
 if(overlap(from,to))return 0;let near=-Infinity,far=Infinity;
 for(const [axis,size,d]of [['x','w',dx],['y','h',dy]]){
  if(Math.abs(d)<EPS){if(from[axis]+from[size]<=to[axis]+EPS||from[axis]>=to[axis]+to[size]-EPS)return null;continue;}
  const n=(to[axis]-from[axis]-from[size])/d,f=(to[axis]+to[size]-from[axis])/d;
  near=Math.max(near,Math.min(n,f));far=Math.min(far,Math.max(n,f));if(near>far+EPS)return null;
 }
 return near>=-EPS&&near<=1+EPS&&far>=0?clamp(near,0,1):null;
}
export function createSkyShooter(room,{emit=()=>{},defeatEnemy=()=>false,hurtPlayer=()=>{}}={}){
 validateSkyShooterRoom(room);if(!room?.smm2Mechanics?.skyShooter)return null;
 if([emit,defeatEnemy,hurtPlayer].some(q=>typeof q!=='function'))fail('Invalid Sky Shooter host callbacks');
 const spec=copy(room.smm2Mechanics.skyShooter),roomId=room.roomId,width=room.map.width,height=room.map.height,maxWave=Math.max(...spec.drones.map(q=>q.wave)),bindings=new Map(spec.drones.map(q=>[q.id,q])),loop=spec.loopingDivers,loopIds=new Set(loop?.actorIds||[]),enemyFire=spec.enemyFire;
 let tick=0,lastTick=null,started=false,cleared=false,wave=1,waveStart=0,nextWave=null,nextAttack=null,attackCount=0,shotSerial=0,missileSerial=0,lastShot=-Infinity,shots=[],missiles=[],warning=null,flight=new Map(),defeated=new Set(),actors=new Map(),weapon=null,passenger=null;
 let returnCycles=new Map(),loopSerial=0;
 let enemyWarnings=new Map(),enemyShots=[],enemyShotSerial=0,nextDownward=null,downwardSerial=0;
 const ownsActor=actor=>!!actor&&bindings.has(actor.id);
 const isActiveActor=actor=>ownsActor(actor)&&(!loop||actors.get(actor.id)===actor)&&live(actor)&&started&&!cleared&&!defeated.has(actor.id)&&bindings.get(actor.id).wave===wave&&nextWave===null;
 const event=(name,extra={})=>emit('sky-shooter',{event:name,roomId,tick,wave,...extra});
 const poseFor=q=>{const angle=(tick-waveStart+q.phaseFrames)*Math.PI*2/spec.formation.periodFrames;return {x:q.x+Math.sin(angle)*spec.formation.amplitudeX,y:q.y+Math.sin(angle*2)*spec.formation.amplitudeY};};
 function defeatedActor(actor){
  if(!ownsActor(actor)||actors.get(actor.id)!==actor||actor.dead!==true||!started||bindings.get(actor.id).wave!==wave||defeated.has(actor.id))return false;
  defeated.add(actor.id);flight.delete(actor.id);enemyWarnings.delete(actor.id);if(warning?.actorId===actor.id)warning=null;event('native-defeat-confirmed',{actorId:actor.id,defeated: defeated.size,total:bindings.size});return true;
 }
 function setWave(now){waveStart=now;nextWave=null;nextAttack=now+spec.attack.firstAttackFrames;nextDownward=enemyFire?now+enemyFire.firstDownwardShotFrames:null;warning=null;enemyWarnings.clear();flight.clear();event('wave-start',{count:spec.drones.filter(q=>q.wave===wave).length});}
 function moveTowards(actor,target,speed){const dx=target.x-actor.x,dy=target.y-actor.y,d=Math.hypot(dx,dy),scale=d>speed?speed/d:1;actor.x=clamp(actor.x+dx*scale,0,width-actor.w);actor.y=clamp(actor.y+dy*scale,0,height-actor.h);return d<=speed;}
 function startEnemyWarning(actor,kind){
  const source={x:actor.x+8,y:actor.y+16},target=kind==='downward'?{x:source.x,y:Math.max(source.y+32,height-16)}:{x:passenger.x+passenger.w/2,y:passenger.y+passenger.h/2};
  const w={actorId:actor.id,kind,startedTick:tick,readyTick:tick+enemyFire.telegraphFrames,source,target};enemyWarnings.set(actor.id,w);event('attack-warning',copy(w));
 }
 function finishEnemyWarning(w){
  const actor=actors.get(w.actorId);enemyWarnings.delete(w.actorId);if(!isActiveActor(actor))return;
  const dx=w.target.x-w.source.x,dy=w.target.y-w.source.y,d=Math.hypot(dx,dy);
  if(w.kind==='aimed'&&d<enemyFire.minAimDistance)event('enemy-shot-skipped',{actorId:actor.id,kind:w.kind,reason:'too-close',distance:d,target:copy(w.target)});
  else if(enemyShots.length>=enemyFire.maxShots)event('enemy-shot-skipped',{actorId:actor.id,kind:w.kind,reason:'capacity'});
  else{const shot={id:'sky-enemy-shot-'+(++enemyShotSerial),actorId:actor.id,kind:w.kind,x:w.source.x-2,y:w.source.y,w:4,h:8,vx:w.kind==='downward'?0:dx/Math.max(EPS,d)*enemyFire.shotSpeed,vy:w.kind==='downward'?enemyFire.shotSpeed:dy/Math.max(EPS,d)*enemyFire.shotSpeed,age:0};enemyShots.push(shot);event('enemy-shot-launch',{actorId:actor.id,kind:w.kind,shotId:shot.id,origin:copy(w.source),target:copy(w.target)});}
  if(w.kind==='aimed'){const f=flight.get(actor.id);if(f){f.phase='exit';f.age=0;f.exitLeg=0;f.target={x:actor.x,y:loop.exitY};event('diver-exit-start',{actorId:actor.id});}}
  else flight.set(actor.id,{phase:'downward-return',age:0});
 }
 function stepLoop(actor,q,f){
  if(enemyFire&&f.phase==='aimed-warning')return;
  f.age++;
  const target=f.phase==='return'?poseFor(q):f.target,speed=f.phase==='dive'?spec.attack.diveSpeed:f.phase==='exit'?loop.exitSpeed:f.phase==='return'?loop.returnSpeed:loop.reentrySpeed;
  const reached=moveTowards(actor,target,speed);
  if(!reached&&!(f.phase==='dive'&&!enemyFire&&f.age>=spec.attack.diveTurnFrames))return;
  if(enemyFire&&f.phase==='dive'){f.phase='aimed-warning';f.age=0;startEnemyWarning(actor,'aimed');return;}
  if(f.phase==='dive'){f.phase='exit';f.age=0;f.exitLeg=0;f.target={x:actor.x,y:loop.exitY};event('diver-exit-start',{actorId:actor.id});}
  else if(f.phase==='exit'&&f.exitLeg===0){f.exitLeg=1;f.target={x:loop.sideX,y:loop.exitY};event('diver-exit',{actorId:actor.id,position:body(actor)});}
  else if(f.phase==='exit'){f.phase='outside-return';f.age=0;f.target={x:loop.sideX,y:loop.reentryY};}
  else if(f.phase==='outside-return'){f.phase='top-reentry';f.age=0;f.target={x:poseFor(q).x,y:loop.reentryY};event('diver-top-reentry',{actorId:actor.id,position:body(actor),slot:{x:q.x,y:q.y}});}
  else if(f.phase==='top-reentry'){f.phase='return';f.age=0;event('diver-slot-approach',{actorId:actor.id,position:body(actor)});}
  else{flight.delete(actor.id);const returns=(returnCycles.get(actor.id)||0)+1;returnCycles.set(actor.id,returns);event('diver-formation-return',{actorId:actor.id,returns,position:body(actor),slot:{x:q.x,y:q.y}});}
 }
 function step({tick:now,player,input={},enemies=[],geometry=[],clouds}={}){
  if(!integer(now,0,Number.MAX_SAFE_INTEGER)||!Array.isArray(enemies)||!Array.isArray(geometry)||!plain(input))fail('Invalid Sky Shooter step');
  if(lastTick!==null&&now<=lastTick)return view();tick=now;lastTick=now;passenger=player;
  for(const actor of enemies)if(ownsActor(actor)){if(!actors.has(actor.id))actors.set(actor.id,actor);defeatedActor(actor);}
  const mounted=live(player)&&player.lakituCloudId===spec.cloudId&&(clouds===undefined||clouds.clouds?.some(q=>q.id===spec.cloudId&&q.occupancy==='player'));
  weapon=mounted?{x:player.x+player.w-1,y:player.y+3,w:8,h:12,shooting:tick-lastShot<4}:null;
  if(!started&&mounted&&overlap(player,spec.activation)){started=true;event('combat-start',{cloudId:spec.cloudId});setWave(tick);}
  const before=new Map();
  for(const [actorId,q]of bindings){const actor=actors.get(actorId);if(!actor||!live(actor)||defeated.has(actorId))continue;before.set(actorId,body(actor));
   const f=flight.get(actorId);if(isActiveActor(actor)&&enemyWarnings.has(actorId)){
    // A telegraph owns the exact native body position and muzzle until its
    // shot. It cannot drift with the sinusoidal slot or approach the player.
   }else if(isActiveActor(actor)&&f){
    if(loopIds.has(actorId))stepLoop(actor,q,f);
    else if(enemyFire&&f.phase==='downward-return'){if(moveTowards(actor,poseFor(q),loop.returnSpeed))flight.delete(actorId);}
    else{f.age++;const returning=f.phase==='return';const target=returning?poseFor(q):f.target;
     if(moveTowards(actor,target,spec.attack.diveSpeed)||!returning&&f.age>=spec.attack.diveTurnFrames){if(returning)flight.delete(actorId);else{f.phase='return';f.age=0;}}}
   }else if(isActiveActor(actor)){Object.assign(actor,poseFor(q));}
   else Object.assign(actor,{x:q.x,y:q.y});
   const old=before.get(actorId);actor.vx=actor.x-old.x;actor.vy=actor.y-old.y;actor.grounded=false;actor.support=null;
  }
  if(started&&!cleared&&nextWave!==null&&tick>=nextWave){wave++;setWave(tick);}
  if(started&&!cleared&&nextWave===null){
   const remaining=spec.drones.filter(q=>q.wave===wave&&!defeated.has(q.id));
   if(!remaining.length){warning=null;missiles=[];shots=[];enemyShots=[];enemyWarnings.clear();flight.clear();
    if(wave===maxWave){cleared=true;event('gate-open',{gateIds:[...spec.gateIds],rewardId:spec.rewardId,defeated:defeated.size});}
    else{nextWave=tick+spec.formation.waveDelayFrames;event('wave-cleared',{nextWave:wave+1,readyTick:nextWave});}
   }
  }
  if(cleared)for(const q of geometry)if(spec.gateIds.includes(q.id))q.hidden=true;
  if(started&&!cleared&&nextWave===null&&live(player)){
   if(enemyFire){
    for(const w of [...enemyWarnings.values()])if(tick>=w.readyTick)finishEnemyWarning(w);
    if(tick>=nextDownward&&overlap(player,spec.activation)&&![...enemyWarnings.values()].some(w=>w.kind==='downward')){
     const ids=enemyFire.downwardActorIds;let selected=null;
     for(let n=0;n<ids.length;n++){const index=(downwardSerial+n)%ids.length,actor=actors.get(ids[index]);if(isActiveActor(actor)&&!flight.has(actor.id)&&!enemyWarnings.has(actor.id)){selected=actor;downwardSerial=(index+1)%ids.length;break;}}
     if(selected){startEnemyWarning(selected,'downward');nextDownward=tick+enemyFire.downwardIntervalFrames;}
    }
   }
   if(warning&&tick>=warning.readyTick){const actor=actors.get(warning.actorId);
    if(isActiveActor(actor)){if(warning.kind==='dive'){flight.set(actor.id,{phase:'dive',age:0,target:{x:warning.target.x-8,y:enemyFire?enemyFire.diverAttackY:warning.target.y-8}});event('dive-launch',{actorId:actor.id,target:copy(warning.target)});}
     else if(missiles.length<spec.attack.maxMissiles){const x=actor.x+6,y=actor.y+12,dx=warning.target.x-x,dy=warning.target.y-y,d=Math.max(EPS,Math.hypot(dx,dy));missiles.push({id:'sky-missile-'+(++missileSerial),x,y,w:4,h:8,vx:dx/d*spec.attack.missileSpeed,vy:dy/d*spec.attack.missileSpeed,age:0});event('missile-launch',{actorId:actor.id,target:copy(warning.target)});}}
    warning=null;
   }
   if(!warning&&tick>=nextAttack&&overlap(player,spec.activation)){
    let candidates=enemies.filter(q=>isActiveActor(q)&&!flight.has(q.id)).sort((a,b)=>Math.abs(b.x-player.x)-Math.abs(a.x-player.x)||a.id.localeCompare(b.id)),kind=attackCount%2?'missile':'dive';
    if(enemyFire){kind='dive';const active=[...flight.keys()].filter(k=>loopIds.has(k)).length;candidates=active<loop.maxActive?candidates.filter(q=>enemyFire.diverActorIds.includes(q.id)):[];}
    else if(loop){const divers=candidates.filter(q=>loopIds.has(q.id)),active=[...flight.keys()].filter(k=>loopIds.has(k)).length;
     if(kind==='dive'&&divers.length&&active<loop.maxActive)candidates=divers;
     else{kind='missile';const base=candidates.filter(q=>!loopIds.has(q.id));if(base.length)candidates=base;}
    }
    if(candidates.length){const actor=candidates[(loop&&kind==='dive'?loopSerial++:attackCount)%candidates.length];attackCount++;warning={actorId:actor.id,kind,startedTick:tick,readyTick:tick+spec.attack.telegraphFrames,target:{x:player.x+player.w/2,y:player.y+player.h/2}};nextAttack=tick+spec.attack.intervalFrames;event('attack-warning',copy(warning));}
   }
  }
  if(mounted&&!cleared&&(input.run||input.attack)&&tick-lastShot>=spec.weapon.cooldownFrames&&shots.length<spec.weapon.maxShots){
   lastShot=tick;const shot={id:'sky-shot-'+(++shotSerial),x:weapon.x+2,y:weapon.y-4,w:3,h:7,vx:0,vy:-spec.weapon.speed,age:0};shots.push(shot);weapon.shooting=true;event('shot-fired',{shotId:shot.id,origin:body(shot)});emit('sound',{event:'fire'});
  }
  const solid=geometry.filter(q=>!q.hidden&&q.collision==='solid');
  for(const shot of shots){shot.age++;let contact=null;
   for(const q of solid){const fraction=sweep(shot,shot.vx,shot.vy,q);if(fraction!==null&&(!contact||fraction<contact.fraction))contact={fraction,solidId:q.id};}
   for(const actor of enemies)if(isActiveActor(actor)){const old=before.get(actor.id)||body(actor),fraction=sweep(shot,shot.vx-(actor.x-old.x),shot.vy-(actor.y-old.y),old);if(fraction!==null&&(!contact||fraction<contact.fraction))contact={fraction,actor};}
   const fraction=contact?.fraction??1;shot.x+=shot.vx*fraction;shot.y+=shot.vy*fraction;
   if(contact){shot.dead=true;if(contact.actor){const accepted=defeatEnemy(contact.actor,{roomId,tick,shotId:shot.id,point:{x:shot.x+shot.w/2,y:shot.y+shot.h/2},kind:'sky-shot'});const confirmed=defeatedActor(contact.actor);event('shot-contact',{shotId:shot.id,actorId:contact.actor.id,nativeDefeated:confirmed||defeated.has(contact.actor.id),accepted:accepted===true});}else event('shot-blocked',{shotId:shot.id,solidId:contact.solidId});}
   if(shot.age>=spec.weapon.lifeFrames||shot.y+shot.h<0||shot.x<0||shot.x>width)shot.dead=true;
  }
  shots=shots.filter(q=>!q.dead);
  for(const missile of missiles){missile.age++;let hit=null;for(const q of solid){const fraction=sweep(missile,missile.vx,missile.vy,q);if(fraction!==null&&(!hit||fraction<hit.fraction))hit={fraction,solid:true};}
   if(live(player)){const fraction=sweep(missile,missile.vx,missile.vy,player);if(fraction!==null&&(!hit||fraction<hit.fraction))hit={fraction,player:true};}
   missile.x+=missile.vx*(hit?.fraction??1);missile.y+=missile.vy*(hit?.fraction??1);if(hit){missile.dead=true;if(hit.player){event('missile-contact',{missileId:missile.id,point:{x:missile.x,y:missile.y}});hurtPlayer({roomId,tick,missileId:missile.id,kind:'sky-missile'});}}
   if(missile.age>=spec.attack.missileLifeFrames||missile.x+missile.w<0||missile.x>width||missile.y+missile.h<0||missile.y>height)missile.dead=true;
  }
  missiles=missiles.filter(q=>!q.dead);
  // Enemy fire shares the same actual swept terrain/player contacts as legacy
  // missiles, but uses one separate explicitly bounded projectile pool.
  for(const shot of enemyShots){shot.age++;let hit=null;
   for(const q of solid){const fraction=sweep(shot,shot.vx,shot.vy,q);if(fraction!==null&&(!hit||fraction<hit.fraction))hit={fraction,solidId:q.id};}
   if(live(player)){const fraction=sweep(shot,shot.vx,shot.vy,player);if(fraction!==null&&(!hit||fraction<hit.fraction))hit={fraction,player:true};}
   shot.x+=shot.vx*(hit?.fraction??1);shot.y+=shot.vy*(hit?.fraction??1);
   if(hit){shot.dead=true;if(hit.player){event('enemy-shot-contact',{shotId:shot.id,actorId:shot.actorId,kind:shot.kind,point:{x:shot.x,y:shot.y}});hurtPlayer({roomId,tick,shotId:shot.id,kind:'sky-enemy-shot'});}else event('enemy-shot-blocked',{shotId:shot.id,actorId:shot.actorId,solidId:hit.solidId});}
   if(shot.age>=enemyFire.shotLifeFrames||shot.x+shot.w<0||shot.x>width||shot.y+shot.h<0||shot.y>height)shot.dead=true;
  }
  enemyShots=enemyShots.filter(q=>!q.dead);return view();
 }
 function view(){const heldWeapon=weapon&&live(passenger)&&passenger.lakituCloudId===spec.cloudId?{...weapon,x:passenger.x+passenger.w-1,y:passenger.y+3}:null;const warnings=[...(warning?[warning]:[]),...enemyWarnings.values()].map(w=>({...w,age:tick-w.startedTick,remainingFrames:Math.max(0,w.readyTick-tick)}));return copy({version:1,originalComposition:true,parameterStatus:'explicit-author-configuration',cloudId:spec.cloudId,started,cleared,wave,waveCount:maxWave,defeated:defeated.size,total:bindings.size,nextWaveTick:nextWave,gateIds:spec.gateIds,rewardId:spec.rewardId,weapon:heldWeapon,shots,missiles,warnings,...(enemyFire?{enemyFire:{version:1,downwardActorIds:[...enemyFire.downwardActorIds],diverActorIds:[...enemyFire.diverActorIds],maxShots:enemyFire.maxShots,shots:enemyShots}}:{}),...(loop?{loopingDivers:{version:1,actorIds:[...loopIds],maxActive:loop.maxActive,active:[...flight.keys()].filter(k=>loopIds.has(k)).length,corridor:{exitY:loop.exitY,reentryY:loop.reentryY,sideX:loop.sideX},cycles:[...loopIds].map(id=>({id,returns:returnCycles.get(id)||0}))}}:{}),drones:spec.drones.filter(q=>!defeated.has(q.id)&&q.wave===wave).map(q=>{const actor=actors.get(q.id),f=flight.get(q.id);return {id:q.id,wave:q.wave,x:actor?.x??q.x,y:actor?.y??q.y,w:16,h:16,state:!started?'waiting':nextWave!==null?'waiting':warning?.actorId===q.id||enemyWarnings.has(q.id)?'warning':f?.phase??'formation',facing:actor?.facing??1,...(loopIds.has(q.id)?{looping:true,returns:returnCycles.get(q.id)||0}:{})};})});}
 function reset(){tick=0;lastTick=null;started=cleared=false;wave=1;waveStart=0;nextWave=nextAttack=nextDownward=null;attackCount=shotSerial=missileSerial=loopSerial=enemyShotSerial=downwardSerial=0;lastShot=-Infinity;shots=[];missiles=[];enemyShots=[];warning=weapon=passenger=null;flight=new Map();defeated=new Set();actors=new Map();returnCycles=new Map();enemyWarnings=new Map();}
 return Object.freeze({step,ownsActor,isActiveActor,defeatedActor,view,reset});
}
