import {completionMarksView} from './editor-completion-marks.mjs';
import {createSkyShooter} from './editor-sky-shooter.mjs';
import {createJrArenaAudience} from './editor-jr-arena-audience.mjs';
import {createCoinCranes} from './editor-coin-crane.mjs';
import {createChainChompGuards} from './editor-chain-chomp-guard.mjs';
import {createBowserJuniors} from './editor-bowser-jr.mjs';
import {createConveyorSurfaces} from './editor-conveyor-surfaces.mjs';
import {createNpcSpringContacts} from './editor-npc-spring-contacts.mjs';
import {createPortableStones} from './editor-portable-stones.mjs';
import {createParachuteActors} from './editor-parachute-actors.mjs';
import {createLocalUpdrafts} from './editor-local-updrafts.mjs';
import {koopaView,transitionToKoopaShell,kickWalkingKoopa,stopWalkingKoopaShell,recoverWalkingKoopa,hardBlockBreakEligibility} from './editor-walking-koopa.mjs';
import {blockContent} from './editor-block-content.mjs';
import {createSmm2Liquid} from './editor-smm2-liquid.mjs';
import {createSmm2GoalCard,createSmm2SideSprings,horizontalCameraBarrierRight} from './editor-smm2-course-components.mjs';
import {createSmm2Shoes} from './editor-smm2-shoes.mjs';
import {createSmm2Items} from './editor-smm2-items.mjs';
import {createSmm2Carriers} from './editor-smm2-carriers.mjs';
import {staticVines} from './editor-smm2-mechanics.mjs';
import {createSmm2Thwomps} from './editor-smm2-thwomps.mjs';
import {createSMM2Terrain,withSMM2TerrainContact} from './editor-smm2-terrain.mjs';
import {createContraptionsCourse} from './editor-contraptions.mjs';
import {createRailClaws} from './editor-rail-claws.mjs';
import {createClownCars} from './editor-clown-cars.mjs';
import {createLakituClouds} from './editor-lakitu-clouds.mjs';
import {createRailHazards} from './editor-rail-hazards.mjs';
import {createSmm2SnakeBlocks} from './editor-snake-blocks.mjs';
import {createUnderwaterActors} from './editor-underwater-actors.mjs';
import {createSmwGoalTape} from './editor-smw-goal-tape.mjs';
import {createCastleController} from './editor-castle.mjs';
import {withAquaticPhysics} from './editor-aquatic-motor.mjs';
import {resolvePlayRules} from './editor-play-rules.mjs';
import {createAquaticController} from './editor-aquatic.mjs';
import {createMarioModules,suppliedEmptyShellHeadContact,carryNativePlatformEnemy,nativeMovingPlatformPreviousTop} from './editor-mario-modules.mjs';
import {createEchoRecorder} from './editor-echo.mjs';
import {createSwitchStudy,stepStudyEnemy,resolveStudyOverlap} from './editor-switch.mjs';
import {weaponNames} from './editor-heroes.mjs';
import {billShots,advanceBillShot} from './editor-bill.mjs';
import {sourceType,markerParts,elevatorPlatforms,flagRestY} from './map-appearance.mjs';
// Editor-only Mario contact adaptation; host platform driver stays unchanged.
/** Small playable contract driver, NOT a migration of Terraria combat or inventory.
 * Shared host/audio/input/render ports; maps and character profiles are injected.
 * Supports rooms, checkpoints, one-time coins/rewards, walkers, hazards and exit.
 */
export function createPlatformStage({plan,motor,emit,visualRooms=[],initialState=null,manualDeath=false,autoContinue=false,allowWarp=true}) {
  motor=withAquaticPhysics(motor);
  const copy=x=>JSON.parse(JSON.stringify(x));
  const rules=resolvePlayRules(visualRooms),{viewportWidth,viewportHeight,cameraAnchor}=rules;
  let roomId=plan.stage.entryRoom,p=null,tick=0,health=plan.character.motion.maxHealth,lives=3,coins=0,score=0,timeLeft=rules.timeLimit,timerTicks=0,invulnerable=0,cooldown=0,attackAge=0,portalLock=0,disposed=false,prev={},completed=false,finish=null,transition=null,shrink=0,growth=0,fireGrowth=0,dying=0,cam=0,roomSerial=0,deathSpot=null,warpTarget=null;
  let checkpoint={roomId,spawnId:plan.stage.entrySpawn};const roomStates=new Map(),activatedCheckpoints=new Map(),moduleStates=new Map(),aquaticStates=new Map(),castleStates=new Map(),railStates=new Map(),carStates=new Map();
  let pipeInputLatch=null;const heldPipeInput=(input,direction)=>!!input.interact||(direction==='up'?!!input.up:direction==='down'?!!input.down:direction==='left'?Number(input.x)<0:Number(input.x)>0);
  const skyShooterStates=new Map(),arenaAudienceStates=new Map(),arenaSpawnQueues=new Map(),bowserJuniorControllers=new Map(),coinCraneStates=new Map(),chainChompGuardStates=new Map();
  // Opt-in original arcade currency: the existing global HUD balance is real.
  // Course-session grants and unused paid credits survive rooms and death.
  const arcadeWalletEnabled=visualRooms.some(r=>r.contraptions?.coinCranes?.some(q=>q.payment)),arcadeGrants=new Set(),arcadeCredits=new Map(),arcadeCoinTaken=new Set();let arcadeStageReady=false;
  const craneBank={balance:()=>coins,credit:token=>arcadeCredits.get(token)||0,setCredit(token,n){if(!Number.isInteger(n)||n<0||n>1)throw Error('Invalid paid crane credit');arcadeCredits.set(token,n);},grantOnce(id,amount){if(arcadeGrants.has(id))return false;if(!Number.isInteger(amount)||amount<0||amount>100)throw Error('Invalid arcade entry grant');arcadeGrants.add(id);coins+=amount;emit('coin-wallet',{event:'entry-grant',roomId:id,amount,balance:coins,tick});emit('sound',{event:'pickup'});return true;},spend(amount){if(!Number.isInteger(amount)||amount<1||coins<amount)return false;const before=coins;coins-=amount;emit('coin-wallet',{event:'spent',roomId,amount,before,balance:coins,tick});return true;}};
  function cranesFor(id){const room=visualRooms.find(r=>r.roomId===id);if(!room?.contraptions?.coinCranes?.length)return null;if(!coinCraneStates.has(id))coinCraneStates.set(id,createCoinCranes(room,{emit,bank:craneBank}));return coinCraneStates.get(id);}
  function guardsFor(id){const room=visualRooms.find(r=>r.roomId===id);if(!room?.contraptions?.chainChompGuards?.length)return null;if(!chainChompGuardStates.has(id))chainChompGuardStates.set(id,createChainChompGuards(room,{emit}));return chainChompGuardStates.get(id);}
  function skyFor(id){const room=visualRooms.find(r=>r.roomId===id);if(!room?.smm2Mechanics?.skyShooter)return null;if(!skyShooterStates.has(id))skyShooterStates.set(id,createSkyShooter(room,{emit,defeatEnemy:e=>{const r=stateFor(id);if(e.dead)return false;killEnemy(r,e);if(!e.dead)return false;chainReward(r,e,0,[100]);emit('sound',{event:'kick'});return true;},hurtPlayer:()=>hurt()}));return skyShooterStates.get(id);}
  function craneBodies(r){return [...(r.objects||[]),...r.enemies];}
  function ordinaryEnemyTargets(enemies){const guards=guardsFor(roomId),crane=cranesFor(roomId);return enemies.filter(e=>!guards?.ownsActor(e)&&!crane?.isCaptiveActor?.(e)&&(!skyFor(roomId)?.ownsActor(e)||skyFor(roomId).isActiveActor(e)));}
  function arenaFor(id){const room=visualRooms.find(r=>r.roomId===id);if(!room?.smm2Mechanics?.arenaAudience)return null;if(!arenaAudienceStates.has(id)){arenaSpawnQueues.set(id,[]);arenaAudienceStates.set(id,createJrArenaAudience(room,{emit,spawn:actor=>arenaSpawnQueues.get(id).push(actor)}));}return arenaAudienceStates.get(id);}

  function craneTaken(id,r){return new Set([...r.taken,...[...pinkTaken].filter(t=>t.startsWith(id+"\n")).map(t=>t.slice(id.length+1))]);}
  const terrainStates=new Map(),thwompStates=new Map(),smm2ItemStates=new Map(),carrierStates=new Map(),shoeStates=new Map(),cardStates=new Map(),sideSpringStates=new Map(),liquidStates=new Map(),portableStoneStates=new Map(),updraftStates=new Map(),parachuteStates=new Map(),cloudStates=new Map(),railHazardStates=new Map(),snakeBlockStates=new Map(),underwaterActorStates=new Map(),goalTapeStates=new Map();
  const pinkIds=new Set(visualRooms.flatMap(r=>(r.smm2Mechanics?.pinkCoins||[]).map(q=>r.roomId+"\n"+q.id))),pinkTaken=new Set();let pinkKeyReleased=false;const enemyRewardsSpent=new Set();
  // Runtime actor identity, never an imported property, owns player activation.
  // Only actual player kick branches add an actor. A stop/wake clears it;
  // wall rebounds and ordinary gravity/landing leave ownership intact.
  const playerActivatedShells=new WeakSet(),koopaContactRewards=new Set(),conveyorStates=new Map(),npcSpringStates=new Map();
  const inertConveyors={frame(){},view:()=>null,ownsSupport:()=>false,bodySupport:()=>null,carryActor:()=>({carried:false})},inertNpcSprings={frame:({geometry})=>({geometry,ownedActorIds:[]}),afterActor(){},geometry:g=>g,view:()=>null};
  const keyAdapterRooms=visualRooms.map(r=>!r.contraptions&&(r.smm2Mechanics?.pinkCoins?.length||r.smm2Mechanics?.enemyRewards?.length)?{...r,contraptions:{version:1}}:r);const contraptions=createContraptionsCourse(keyAdapterRooms,{emit});
  const character=plan.character,bill=visualRooms.some(r=>r.playHero==='bill');
  let stompChain=0,dropBag=[],entryWalkPortalId=null,entryWalkLastX=0,entryWalkStall=0;
  let echo=null,echoBaseline=null,echoHeld={record:false,retry:false,clear:false},echoDeaths=0;
  const switchStudy=createSwitchStudy(visualRooms,plan.stage.entryRoom);
  const isStudyEnemy=e=>e.type==='study-piranha'||e.type==='study-chomp';
  function nextWeapon(){if(!dropBag.length)dropBag=['M','S','F','L'].filter(w=>w!==p.weapon);return dropBag.shift();}
  function chainReward(r,e,index,values){const points=values[index];if(points===undefined){lives++;emit('sound',{event:'life'});}else score+=points;r.effects.push({kind:'score-pop',text:points===undefined?'1UP':String(points),x:e.x,y:e.y-8,w:24,h:8,vx:0,vy:-.4,flat:true,life:48,age:0});}

  function cameraWidth(id){const r=visualRooms.find(q=>q.roomId===id),right=horizontalCameraBarrierRight(r,stateFor(id).geometry);return right??plan.rooms[id].width;}
  function conveyorsFor(id){const room=visualRooms.find(r=>r.roomId===id);if(!room?.smm2Mechanics?.conveyors?.length)return inertConveyors;if(!conveyorStates.has(id)){conveyorStates.set(id,createConveyorSurfaces(room?.smm2Mechanics?.conveyors||[],{isOn:()=>switchStudy?.view(id)?.on??true,emit:(name,data)=>emit('smm2-conveyor',{event:name,roomId:id,...data})}));}return conveyorStates.get(id);}
  function npcSpringsFor(id){const room=visualRooms.find(r=>r.roomId===id),spec=(room?.smm2Mechanics?.springs||[]).filter(q=>q.npcContact).map(q=>({id:q.id,...q.npcContact}));if(!spec.length)return inertNpcSprings;if(!npcSpringStates.has(id)){npcSpringStates.set(id,createNpcSpringContacts(spec,{emit:(name,data)=>{emit('smm2-npc-spring',{event:name,roomId:id,...data});if(data.event==='launch')emit('sound',{event:'jump'});}}));}return npcSpringStates.get(id);}
  // Shared additive transport port. A carrier cannot bypass a real wall,
  // ceiling, slope or directional wall, or expand the requested displacement.
  const nativeTerrainBody=actor=>actor?.smm2WalkingKoopa?{...actor,y:actor.y+actor.h-16*(actor.smm2WalkingKoopa.variant.size==='giant'?2:1),h:16*(actor.smm2WalkingKoopa.variant.size==='giant'?2:1)}:actor;
  function resolveActorTransport(actor,delta,{geometry=stateFor(roomId).geometry,excludeIds=[]}={}){
    const start={...actor},body={...actor},excluded=new Set(excludeIds),solids=geometry.filter(q=>!excluded.has(q.id)&&!q.hidden&&q.collision==='solid'),walls=visualRooms.find(q=>q.roomId===roomId)?.contraptions?.oneWayWalls||[],terrain=terrainFor(roomId),steps=Math.max(1,Math.ceil(Math.max(Math.abs(delta.x),Math.abs(delta.y))*2));let blocked=null;
    let stoppedX=false,stoppedY=false;
    for(let i=0;i<steps;i++)for(const axis of ['x','y']){
      if(axis==='x'?stoppedX:stoppedY)continue;
      const amount=delta[axis]/steps;if(!amount)continue;
      const step={x:axis==='x'?amount:0,y:axis==='y'?amount:0},next={...body,x:body.x+step.x,y:body.y+step.y};
      const q=solids.find(q=>q.id!==body.id&&motor.overlap(nativeTerrainBody(next),q));
      const wall=walls.find(q=>q.direction==='down'?step.y<0&&body.y>=q.y+q.h-1e-7&&next.y<q.y+q.h&&next.x+next.w>q.x&&next.x<q.x+q.w:q.direction==='up'?step.y>0&&body.y+body.h<=q.y+1e-7&&next.y+next.h>q.y&&next.x+next.w>q.x&&next.x<q.x+q.w:q.direction==='left'?step.x>0&&body.x+body.w<=q.x+1e-7&&next.x+next.w>q.x&&next.y+next.h>q.y&&next.y<q.y+q.h:step.x<0&&body.x>=q.x+q.w-1e-7&&next.x<q.x+q.w&&next.y+next.h>q.y&&next.y<q.y+q.h);
      const hit=terrain?.sweep(nativeTerrainBody(body),step,{tick,excludeIds});
      if(q||wall||next.x<0||next.x+next.w>plan.rooms[roomId].width){blocked={solidId:q?.id||wall?.id||'room-side',normal:{x:step.x?-Math.sign(step.x):0,y:step.y?-Math.sign(step.y):0}};if(axis==='x')stoppedX=true;else stoppedY=true;continue;}
      if(hit&&hit.fraction<1){body.x+=step.x*hit.fraction;body.y+=step.y*hit.fraction;blocked=hit;if(axis==='x')stoppedX=true;else stoppedY=true;continue;}
      body.x=next.x;body.y=next.y;
    }
    return {body:{x:body.x,y:body.y},dx:body.x-start.x,dy:body.y-start.y,blocked,reached:!blocked&&Math.abs(body.x-start.x-delta.x)<1e-7&&Math.abs(body.y-start.y-delta.y)<1e-7};
  }
  function conveyorCarry(controller,actor,previous,geometry){const before=previous&&previous.w===actor.w&&previous.h===actor.h?previous:previous?{...previous,w:actor.w,h:actor.h,y:previous.y+previous.h-actor.h}:undefined;return controller.carryActor(actor,{tick,previous:before,resolveDisplacement:(body,q)=>{const moved=resolveActorTransport(body,{x:q.dx,y:q.dy},{geometry});return {dx:moved.dx,dy:moved.dy,blocked:!!moved.blocked};}});}
  function commitKoopaContact(r,e,result){if(!result?.handled)return false;if(result.changed)Object.assign(e,result.actor);for(const event of result.events||[]){const rewardToken=roomId+'\n'+event.transitionId;if(koopaContactRewards.has(rewardToken))continue;koopaContactRewards.add(rewardToken);if(event.points){score+=event.points;r.effects.push({kind:'score-pop',text:String(event.points),x:e.x,y:e.y-8,w:24,h:8,vx:0,vy:-.4,flat:true,life:48,age:0});}emit('smm2-koopa',{roomId,...event});}return true;}
  function breakKoopaHardBlock(r,e,q,before){const hit=hardBlockBreakEligibility(e,q,{before,tick,points:10});if(!hit.eligible)return false;r.geometry=r.geometry.filter(a=>a.id!==q.id);contraptions?.destroyBrick(roomId,q.id);for(let i=0;i<4;i++)r.effects.push({kind:'brick-debris',x:q.x+i%2*8,y:q.y+Math.floor(i/2)*8,w:8,h:8,sx:i%2*8,sy:Math.floor(i/2)*8,vx:i%2?1.4:-1.4,vy:i<2?-3.8:-2.5,life:40,age:0});commitKoopaContact(r,e,{handled:true,changed:false,events:hit.events});emit('sound',{event:'break'});return true;}
  function juniorsFor(id){if(!bowserJuniorControllers.has(id))bowserJuniorControllers.set(id,createBowserJuniors(visualRooms.find(r=>r.roomId===id)||{map:plan.rooms[id]},{emit:(type,data)=>{if(type==='smm2-bowser-jr')arenaFor(id)?.handleBossEvent(data);emit(type,data);}}));return bowserJuniorControllers.get(id);}
  function terrainFor(id){if(!terrainStates.has(id))terrainStates.set(id,createSMM2Terrain(visualRooms.find(r=>r.roomId===id)||{map:plan.rooms[id]},{emit}));return terrainStates.get(id);}
  function thwompsFor(id){if(!thwompStates.has(id))thwompStates.set(id,createSmm2Thwomps(visualRooms.find(r=>r.roomId===id)||{map:plan.rooms[id]},{emit,terrain:terrainFor(id)}));return thwompStates.get(id);}
  function smm2ItemsFor(id){if(!smm2ItemStates.has(id))smm2ItemStates.set(id,createSmm2Items(visualRooms.find(r=>r.roomId===id)||{map:plan.rooms[id]},{emit,terrain:terrainFor(id),isHeld:a=>!!railFor(id)?.held(a)}));return smm2ItemStates.get(id);}
  function stonesFor(id){if(!portableStoneStates.has(id))portableStoneStates.set(id,createPortableStones(visualRooms.find(r=>r.roomId===id)||{map:plan.rooms[id]},{emit}));return portableStoneStates.get(id);}
  function parachutesFor(id){if(!parachuteStates.has(id))parachuteStates.set(id,createParachuteActors(visualRooms.find(r=>r.roomId===id)||{map:plan.rooms[id]},{emit}));return parachuteStates.get(id);}
  function updraftsFor(id){if(!updraftStates.has(id))updraftStates.set(id,createLocalUpdrafts(visualRooms.find(r=>r.roomId===id)||{map:plan.rooms[id]},{emit}));return updraftStates.get(id);}
  function cardFor(id){if(!cardStates.has(id))cardStates.set(id,createSmm2GoalCard(visualRooms.find(r=>r.roomId===id)||{map:plan.rooms[id]},{emit}));return cardStates.get(id);}
  function goalTapeFor(id){if(!goalTapeStates.has(id))goalTapeStates.set(id,createSmwGoalTape(visualRooms.find(r=>r.roomId===id)||{map:plan.rooms[id]},{emit}));return goalTapeStates.get(id);}
  function underwaterActorsFor(id){if(!underwaterActorStates.has(id))underwaterActorStates.set(id,createUnderwaterActors(visualRooms.find(r=>r.roomId===id)||{map:plan.rooms[id]},{emit:(name,data)=>{
    emit(name,data);
    if(data.event==='fish-bone-broken'){
      const r=roomStates.get(id);if(!r)return;
      for(let n=0;n<6;n++){const wing=n>=4,size=wing?6:4;r.effects.push({kind:'fish-bone-break',type:'fish-bone',actorId:data.actorId,...(data.sourceId?{sourceId:data.sourceId}:{}),fragment:wing?'wing':'bone',phase:'broken',physicsBody:copy(data.body),contact:copy(data.contact),x:data.body.x+data.body.w*(n%3+1)/4-size/2,y:data.body.y+data.body.h*(n<3?1:2)/3-size/2,w:size,h:size,vx:(n%3-1)*.65+data.velocity.x*.15,vy:-1.2-Math.floor(n/3)*.4,age:0,life:36});}
    }
  }}));return underwaterActorStates.get(id);}
  function sideSpringsFor(id){if(!sideSpringStates.has(id))sideSpringStates.set(id,createSmm2SideSprings(visualRooms.find(r=>r.roomId===id)||{map:plan.rooms[id]},{emit}));return sideSpringStates.get(id);}
  function carriersFor(id){if(!carrierStates.has(id))carrierStates.set(id,createSmm2Carriers(visualRooms.find(r=>r.roomId===id)||{map:plan.rooms[id]},{terrain:terrainFor(id)}));return carrierStates.get(id);}
  function snakeBlocksFor(id){if(!snakeBlockStates.has(id))snakeBlockStates.set(id,createSmm2SnakeBlocks(visualRooms.find(r=>r.roomId===id)||{map:plan.rooms[id]},{emit}));return snakeBlockStates.get(id);}
  function liquidFor(id){if(!liquidStates.has(id))liquidStates.set(id,createSmm2Liquid(visualRooms.find(r=>r.roomId===id)||{map:plan.rooms[id]},{emit}));return liquidStates.get(id);}
  function shoesFor(id){if(!shoeStates.has(id))shoeStates.set(id,createSmm2Shoes(visualRooms.find(r=>r.roomId===id)||{map:plan.rooms[id]},{emit,terrain:terrainFor(id),liquid:liquidFor(id),isStompTarget:(a,q)=>q.kind==='bone-shell'&&a.type==='dry-bones'||/^(walker|goomba|koopa|beetle|hammerbro)$/.test((a.type||a.kind||'').replace(/^(enemy-|marker-)/,'')),allowCarry:visualRooms.some(r=>r.smm2Mechanics?.shoes?.length||r.smm2Mechanics?.boneShells?.length)}));return shoeStates.get(id);}
  function climbStaticVine(vine,input){
    const r=stateFor(roomId),terrain=terrainFor(roomId);p.headHit=null;
    function move(dx,dy){const count=Math.max(1,Math.ceil(Math.max(Math.abs(dx),Math.abs(dy))));for(let n=0;n<count;n++){const delta={x:dx/count,y:dy/count},candidate={...p,x:p.x+delta.x,y:p.y+delta.y},solid=r.geometry.find(q=>q.collision==='solid'&&(!q.hidden||delta.y<0&&p.y>=q.y+q.h-1)&&motor.overlap(candidate,q)),shape=terrain?.sweep(p,delta,{tick});
      if(solid){if(delta.y<0)p.headHit=solid.id;if(delta.y>0){p.grounded=true;p.support=solid.id;p.onVine=false;}return false;}
      if(shape&&shape.fraction<1){p.x+=delta.x*shape.fraction;p.y+=delta.y*shape.fraction;if(delta.y<0&&shape.normal.y>0)p.headHit=shape.solidId;if(delta.y>0&&shape.normal.y<0){p.grounded=true;p.support=shape.solidId;p.onVine=false;}return false;}
      p.x=candidate.x;p.y=candidate.y;
    }return true;}
    p.vx=p.vy=0;p.grounded=false;p.support=null;p.onVine=true;
    if(!move(vine.x+vine.w/2-p.w/2-p.x,0)){p.onVine=false;return;}
    const target=Math.max(vine.y-p.h+4,Math.min(vine.bottom-4,p.y+(input.up?-vine.climbSpeed:input.down?vine.climbSpeed:0)));move(0,target-p.y);
  }
  function modulesFor(id){if(!moduleStates.has(id))moduleStates.set(id,createMarioModules(visualRooms.find(r=>r.roomId===id)||{map:plan.rooms[id]},{emit}));return moduleStates.get(id);}
  function railFor(id){if(!railStates.has(id))railStates.set(id,createRailClaws(visualRooms.find(r=>r.roomId===id)||{map:plan.rooms[id]},{emit}));return railStates.get(id);}
  function carsFor(id){if(!carStates.has(id))carStates.set(id,createClownCars(visualRooms.find(r=>r.roomId===id)||{map:plan.rooms[id]},{emit}));return carStates.get(id);}
  function cloudsFor(id){if(!cloudStates.has(id))cloudStates.set(id,createLakituClouds(visualRooms.find(r=>r.roomId===id)||{map:plan.rooms[id]},{emit}));return cloudStates.get(id);}
  function railHazardsFor(id){if(!railHazardStates.has(id))railHazardStates.set(id,createRailHazards(visualRooms.find(r=>r.roomId===id)||{map:plan.rooms[id]},{emit}));return railHazardStates.get(id);}
  function castleFor(id){if(!castleStates.has(id))castleStates.set(id,createCastleController(visualRooms.find(r=>r.roomId===id)||{map:plan.rooms[id]},{emit}));return castleStates.get(id);}
  function aquaticFor(id){if(!aquaticStates.has(id))aquaticStates.set(id,createAquaticController(visualRooms.find(r=>r.roomId===id)||{map:plan.rooms[id]},{emit}));return aquaticStates.get(id);}
  function geometryFor(id){const room=visualRooms.find(r=>r.roomId===id);let result=[];
   for(const g of copy(plan.rooms[id].geometry)){const original=room?.map.geometry.find(q=>q.id===g.id)||g,type=room?sourceType(room,original):null;
    if((['Brick','Block'].includes(type)||original.smm2BlockKind==='hard-block')&&g.w%16===0&&g.h%16===0){for(let y=g.y;y<g.y+g.h;y+=16)for(let x=g.x;x<g.x+g.w;x+=16)result.push({...g,x,y,w:16,h:16,sourceId:g.id,id:g.w===16&&g.h===16?g.id:g.id+'@'+x+','+y,material:original.smm2BlockKind==='hard-block'?'stone':type==='Brick'?'brick':'block',...(original.smm2BlockKind?{smm2BlockKind:original.smm2BlockKind}:{})});}else result.push({...g,...(original.smm2BlockKind?{smm2BlockKind:original.smm2BlockKind}:{}),...(original.springOrientation?{springOrientation:original.springOrientation}:{}),material:original.material||(type==='Springboard'?'spring':type==='Pipe'?'pipe':type==='PipeHorizontal'?'pipe-side':g.material),...(type==='CastleBridge'?{h:Math.min(16,g.h)}:{})});
   }
   for(const m of room?.markers||[])if(m.kind==='hidden-block'&&!result.some(q=>q.x===m.x&&q.y===m.y&&q.w===16))result.push({id:m.id,sourceId:m.id,x:m.x,y:m.y,w:16,h:16,collision:'solid',material:'block',hidden:true});
   for(const m of room?.markers||[])if(m.kind==='platform-generator')result.push(...elevatorPlatforms(m,plan.rooms[id].height));
   const geometry=modulesFor(id)?.geometry(result.map(q=>({...q,dir:1,dx:0,dy:0})))||result.map(q=>({...q,dir:1,dx:0,dy:0}));const finalGeometry=switchStudy?switchStudy.apply(id,geometry):geometry;const adapted=contraptions?.geometry(id,finalGeometry)||finalGeometry,shared=terrainFor(id)?.geometry(adapted)||adapted,snakes=snakeBlocksFor(id);return snakes?[...shared.filter(q=>!snakes.ownsGeometry(q)),...snakes.geometry()]:shared;
  }
  function stateFor(id){if(!roomStates.has(id))roomStates.set(id,{...(visualRooms.find(r=>r.roomId===id)?.contraptions?.coinCranes?.length?{objects:copy(plan.rooms[id].objects)}:{}),geometry:geometryFor(id),effects:[],shots:[],vines:staticVines(visualRooms.find(r=>r.roomId===id)||{}),items:plan.rooms[id].objects.filter(q=>smm2ItemsFor(id)?.ownsActor(q)).map(q=>{const item=smm2ItemsFor(id).decorateActor({...q,vx:0,vy:0,age:0,dead:false});const liveItem=contraptions?.restoreP(id,item)||item;if(parachutesFor(id)?.ownsActor(liveItem)){liveItem.vx=-.5;return parachutesFor(id).decorateActor(liveItem);}return liveItem;}).concat(stonesFor(id)?.seedItems()||[]),taken:new Set(arcadeWalletEnabled?[...arcadeCoinTaken].filter(t=>t.startsWith(id+'\n')).map(t=>t.slice(id.length+1)).filter(coinId=>plan.rooms[id].objects.some(o=>o.kind==='coin'&&o.id===coinId)):[]),hiddenMarkers:(visualRooms.find(r=>r.roomId===id)?.markers||[]).filter(m=>m.kind==='platform-generator').map(m=>m.id),enemies:plan.rooms[id].objects.filter(q=>q.kind==='walker'&&!smm2ItemsFor(id)?.ownsActor(q)&&!stonesFor(id)?.ownsActor(q)&&!visualRooms.find(r=>r.roomId===id)?.smm2Mechanics?.boneShells?.some(b=>b.id===q.id&&b.templateOnly)).map(q=>{
    const room=visualRooms.find(r=>r.roomId===id);if(guardsFor(id)?.ownsActor(q))return guardsFor(id).decorateActor({...q,vx:0,vy:0,age:0,dead:false,homeX:q.x,homeY:q.y});if(updraftsFor(id)?.ownsActor(q))return updraftsFor(id).decorateActor({...q,homeX:q.x,homeY:q.y,age:0});if(shoesFor(id)?.ownsActor(q)){const direction=room.semantics?.find(a=>a.id===q.id)?.source?.direction??-1,source=room.marioModules?.enemySources?.find(a=>a.shoeTemplateId===q.id);return shoesFor(id).decorateActor({...q,vx:room.smm2Mechanics?.boneShells?.some(b=>b.id===q.id)?0:.5*direction,vy:0,hp:2,age:0,dead:false,homeX:q.x,homeY:q.y,...(source?{moduleSource:source.id}:{})});}if(thwompsFor(id)?.ownsActor(q)){const e={...q,type:'smm2-thwomp',source:{},vx:0,vy:0,hp:2,homeX:q.x,homeY:q.y,dead:false,smm2Mass:1};thwompsFor(id).decorateEnemy(e);return e;}const variant=modulesFor(id)?.enemyVariant(q.id);if(variant){const e={...q,type:variant.type,source:{},vx:0,vy:0,hp:2,homeX:q.x,homeY:q.y,grounded:false,support:null,studyActivated:false,dead:false};modulesFor(id).applyEnemyVariant(e);e.homeX=e.x;e.homeY=e.y;return e;}const marker=room?.markers?.find(m=>m.id===q.id),source=marker?.source||(room?.switchStudy?room.map.objects.find(o=>o.id===q.id)?.source:undefined),rawType=room?.enemySkins?.[q.id]||marker?.kind||(room?.switchStudy?q.type:null)||'walker',type=room?.switchStudy&&source?.studyFloorPlant?'study-piranha':rawType;
    if(room?.switchStudy&&['study-piranha','study-chomp'].includes(type))return {...q,type,source,vx:type==='study-chomp'?-.7:0,vy:0,hp:2,homeX:q.x,homeY:q.y,grounded:false,support:null,falling:false,studyActivated:false,dead:false};
    const pipe=/piranha/i.test(type)?geometryFor(id).filter(g=>{const original=room?.map.geometry.find(a=>a.id===(g.sourceId||g.id))||g;return (g.material==='pipe'||sourceType(room||{},original)==='Pipe')&&q.x+q.w>g.x&&q.x<g.x+g.w&&Math.abs(q.y-g.y)<80;}).sort((a,b)=>Math.abs(a.y-q.y)-Math.abs(b.y-q.y))[0]:null;
    const enemy={...q,...(pipe?{x:pipe.x+(pipe.w-q.w)/2,y:pipe.y,clipTop:pipe.y}:{}),type,source:marker?.source,vx:-.5,vy:0,hp:/bowser/i.test(type)?(bill?20:5):2,homeX:pipe?pipe.x+(pipe.w-q.w)/2:q.x,homeY:pipe?pipe.y-q.h:q.y,dead:false};const decorated=castleFor(id)?.decorateBoss(aquaticFor(id)?.decorateEnemy(enemy)||enemy)||aquaticFor(id)?.decorateEnemy(enemy)||enemy;underwaterActorsFor(id)?.decorateActor(decorated);juniorsFor(id)?.decorateActor(decorated,{tick});return parachutesFor(id)?.ownsActor(decorated)?parachutesFor(id).decorateActor(decorated):decorated;
  })});return roomStates.get(id);}
  function applyStudyStates(resolve=false){if(!switchStudy)return;for(const [id,state]of roomStates){const actors=[...state.enemies.filter(e=>(!isStudyEnemy(e)||e.studyActivated)&&!guardsFor(id)?.ownsActor(e)&&!cranesFor(id)?.isCaptiveActor?.(e)),...state.items,...(id===roomId&&p?[p]:[])],spec=visualRooms.find(r=>r.roomId===id)?.smm2Mechanics,externalSupportIds=[...(spec?.slopes||[]),...(spec?.seesaws||[]),...(spec?.conveyors||[])].map(q=>q.id);state.geometry=switchStudy.apply(id,state.geometry,actors,externalSupportIds);if(resolve)for(const actor of actors)if(!actor.dead&&!actor.emerge&&!actor.moduleEmergence){const crushing=modulesFor(id)?.switchCrushEnabled()&&(actor.type==='study-piranha'||!!koopaView(actor))&&state.geometry.some(g=>g.studyDevice&&g.kind==='block'&&motor.overlap(nativeTerrainBody(actor),g));if(crushing){killEnemy(state,actor);score+=actor.smm2WalkingKoopa?0:100;emit('sound',{event:'kick'});emit('mario-module',{event:'switch-crush',actorId:actor.id,roomId:id});}else{const terrainBody=nativeTerrainBody(actor),inset=terrainBody.y-actor.y;resolveStudyOverlap(terrainBody,state.geometry,plan.rooms[id].width);if(terrainBody!==actor){actor.x=terrainBody.x;actor.y=terrainBody.y-inset;actor.vx=terrainBody.vx;actor.vy=terrainBody.vy;actor.grounded=terrainBody.grounded;actor.support=terrainBody.support;}}}}}
  const contactBox=e=>e.clipTop==null?e:{...e,h:Math.max(0,Math.min(e.h,e.clipTop-e.y))};
  const touches=(a,e)=>{const b=contactBox(e);return b.h>0&&motor.overlap(a,b);};
  function saveEchoBaseline(){
    if(!echo){echoBaseline=null;return;}
    echoBaseline={roomId,p:copy(p),state:structuredClone(stateFor(roomId)),tick,health,lives,coins,score,timeLeft,timerTicks,invulnerable,cooldown,attackAge,portalLock,checkpoint:copy(checkpoint),activatedCheckpoints:[...activatedCheckpoints],dropBag:copy(dropBag),conveyors:conveyorStates.get(roomId)?.saveState(),npcSprings:npcSpringStates.get(roomId)?.snapshot(),koopaContactRewards:[...koopaContactRewards]};
  }
  function restoreEchoBaseline(){
    if(!echoBaseline||echoBaseline.roomId!==roomId)return;
    const b=echoBaseline;roomId=b.roomId;p=copy(b.p);roomStates.set(roomId,structuredClone(b.state));conveyorStates.delete(roomId);npcSpringStates.delete(roomId);if(b.conveyors)conveyorsFor(roomId).restore(b.conveyors);if(b.npcSprings)npcSpringsFor(roomId).restore(b.npcSprings);koopaContactRewards.clear();for(const id of b.koopaContactRewards||[])koopaContactRewards.add(id);
    // Rewinding undoes attempt-local rewards, while every real death stays spent.
    tick=b.tick;health=b.health;lives=b.lives-echoDeaths;coins=b.coins;score=b.score;timeLeft=b.timeLeft;timerTicks=b.timerTicks;invulnerable=b.invulnerable;cooldown=b.cooldown;attackAge=b.attackAge;portalLock=b.portalLock;checkpoint=copy(b.checkpoint);activatedCheckpoints.clear();for(const [key,age]of b.activatedCheckpoints)activatedCheckpoints.set(key,age);dropBag=copy(b.dropBag);
    finish=null;transition=null;shrink=growth=fireGrowth=dying=0;completed=false;deathSpot=null;warpTarget=null;stompChain=0;prev={};cam=Math.max(0,Math.min(Math.max(0,plan.rooms[roomId].width-viewportWidth),p.x-cameraAnchor));roomSerial++;
  }
  function initEcho(){
    echo=createEchoRecorder(visualRooms.find(r=>r.roomId===roomId)||{});echoDeaths=0;
    if(echo){const room=visualRooms.find(r=>r.roomId===roomId),anchor=room.mechanics.anchorSpawn||plan.rooms[roomId].objects.find(o=>o.kind==='spawn')?.id;checkpoint={roomId,spawnId:anchor};
      if(anchor){const spawn=plan.rooms[roomId].objects.find(o=>o.kind==='spawn'&&o.id===anchor);if(spawn){p.x=spawn.x;p.y=spawn.y-(p.h-character.motion.height);p.vx=p.vy=0;p.grounded=false;p.support=null;}}
      const r=stateFor(roomId);r.geometry=echo.apply(r.geometry,p);
    }
    saveEchoBaseline();
  }
  function canEchoRewind(){return !!echoBaseline&&lives>0&&echoBaseline.lives-echoDeaths>0&&!completed;}
  function echoCommand(command){
    if(command==='clear'){
      echo.reset();if(canEchoRewind())restoreEchoBaseline();emit('sound',{event:'checkpoint'});
    }else if(command==='retry'){
      if(!canEchoRewind()||!echo.retry())return;
      restoreEchoBaseline();emit('sound',{event:'portal'});
    }else{
      if(!canEchoRewind())return;
      if(echo.view().phase==='recording'){echo.commit();restoreEchoBaseline();emit('sound',{event:'portal'});}
      else{restoreEchoBaseline();echo.start(p);emit('sound',{event:'checkpoint'});}
    }
    const r=stateFor(roomId);r.geometry=echo.apply(r.geometry,p);
  }
  function enter(id,spawn,preserveEcho=false){const o=plan.rooms[id].objects.find(q=>q.kind==='spawn'&&q.id===spawn);if(!o)throw Error('Spawn missing');
    const carried=p&&roomId!==id?shoesFor(roomId)?.exportCarry(p,{detach:true}):null;
    const keepEcho=preserveEcho&&echo&&echoBaseline?.roomId===id;
    roomId=id;roomSerial++;stompChain=0;stateFor(id);entryWalkPortalId=modulesFor(id)?.entryWalkPortal?.(spawn)||null;if(entryWalkPortalId)emit('mario-module',{event:'entry-walk-start',roomId:id,spawnId:spawn,portalId:entryWalkPortalId});const form=p?{power:bill?0:p.power,star:p.star,weapon:p.weapon,...(p.helmet?{helmet:p.helmet}:{})}:null;p=motor.create(character,o);if(bill){p.hero='bill';p.y-=16;p.h=30;p.weapon=form?.weapon||'N';}if(form){Object.assign(p,form);if(!bill&&p.power){p.y-=14;p.h=28;}}if(carried){p.y-=carried.h-Math.min(carried.tuning.seatInset,p.h);const actor=shoesFor(id).importCarry(p,carried,{tick}),state=stateFor(id);if(!state.enemies.some(e=>e===actor))state.enemies.push(actor);}entryWalkLastX=p.x;entryWalkStall=0;portalLock=24;prev={};cam=Math.max(0,Math.min(Math.max(0,cameraWidth(id)-viewportWidth),p.x-cameraAnchor));if(visualRooms.find(r=>r.roomId===id)?.smm2Mechanics)p.smm2Player=true;emit('room',{roomId});
    contraptions?.enterKeyFollowers(id,p);
    const craneRoom=stateFor(id);cranesFor(id)?.reset({entry:arcadeStageReady,objects:craneBodies(craneRoom),taken:craneTaken(id,craneRoom)});
    if(keepEcho){echo.cancel();const r=stateFor(id);r.geometry=echo.apply(r.geometry,p);}
    else initEcho();
  }
  function pickupItem(r,item){item.dead=true;if(item.kind==='life')lives++;else if(item.kind==='star')p.star=modulesFor(roomId)?.starDuration()??600;else if(bill){p.weapon=item.weapon||'M';score+=1000;invulnerable=Math.max(invulnerable,45);r.effects.push({kind:'score-pop',text:weaponNames[p.weapon],x:p.x-10,y:p.y-8,w:70,h:8,vx:0,vy:-.2,flat:true,life:90,age:0});}else{if(!p.power){p.y-=14;p.h=28;growth=24;}else if(item.kind==='flower'&&p.power===1){fireGrowth=24;}p.power=item.kind==='flower'&&p.power>0?2:Math.max(1,p.power);}emit('sound',{event:item.kind==='life'?'life':'powerup'});}
  function collectCoin(count=1,pointsOverride){coins+=count;score+=(pointsOverride??visualRooms.find(r=>r.roomId===roomId)?.smm2Mechanics?.scoreProfile?.coinPoints??200)*count;emit('sound',{event:'pickup'});if(!arcadeWalletEnabled)while(coins>=100){coins-=100;lives++;emit('sound',{event:'life'});}}
  function kickShell(e,safe,source){if(koopaView(e)){const result=kickWalkingKoopa(e,{direction:p.x<e.x?1:-1,speed:3.2,tick,safeFrames:safe});if(!result.changed)return false;commitKoopaContact(stateFor(roomId),e,result);}else e.vx=(p.x<e.x?1:-1)*3.2;e.safe=safe;playerActivatedShells.add(e);if(visualRooms.find(r=>r.roomId===roomId)?.smm2Mechanics?.shellCoinCollection===true)emit('smm2-shell',{event:'player-kick',roomId,actorId:e.id,source,tick});}
  function shellCoinCollector(e,o,stepped){return stepped.has(e)&&playerActivatedShells.has(e)&&!e.dead&&!e.hidden&&!e.moduleEmergence&&!e.emerge&&!e.clawHeld&&!e.vehicleId&&e.shell===true&&Math.abs(e.vx)>1&&/^(koopa|beetle)$/.test(e.type.replace(/^(enemy-|marker-)/,'').toLowerCase())&&!o.hidden&&!o.dead&&motor.overlap(e,o);}
  function takeWorldCoin(r,o,collector=null){
    const crane=cranesFor(roomId);if(crane?.ownsCoin(o.id)&&(collector||!crane.canCollectCoin(o.id)))return false;
    const pinkToken=roomId+'\n'+o.id,alreadyBanked=arcadeWalletEnabled&&arcadeCoinTaken.has(pinkToken),recollectedConvertedBrick=alreadyBanked&&!!o.sourceBrickId;if(r.taken.has(o.id)||alreadyBanked&&!recollectedConvertedBrick||pinkTaken.has(pinkToken)||o.hidden||o.dead)return false;
    r.taken.add(o.id);if(arcadeWalletEnabled&&!pinkIds.has(pinkToken))arcadeCoinTaken.add(pinkToken);contraptions?.collectCoin(roomId,o);r.geometry=contraptions?.geometry(roomId,r.geometry,r.items)||r.geometry;
    if(pinkIds.has(pinkToken)){pinkTaken.add(pinkToken);if(arcadeWalletEnabled){score+=visualRooms.find(r=>r.roomId===roomId)?.smm2Mechanics?.scoreProfile?.coinPoints??200;emit('sound',{event:'pickup'});}else collectCoin();emit('smm2-item',{event:'pink-coin-collected',roomId,actorId:o.id,taken:pinkTaken.size,total:pinkIds.size});if(pinkTaken.size===pinkIds.size&&!pinkKeyReleased){pinkKeyReleased=true;r.items.push({id:'pink-coins-key',kind:'key',x:o.x,y:o.y,w:12,h:12,vx:0,vy:0,age:0,keyDelay:0,keySpeed:3});emit('smm2-item',{event:'pink-key-release',roomId});}}
    else if(recollectedConvertedBrick){emit('sound',{event:'pickup'});emit('coin-wallet',{event:'converted-passage-recollected',roomId,coinId:o.id,sourceBrickId:o.sourceBrickId,balance:coins,tick});}else collectCoin(modulesFor(roomId)?.coinValue(o.id)||1);
    if(collector)emit('smm2-shell',{event:'coin-collected',roomId,actorId:collector.id,coinId:o.id,pink:pinkIds.has(pinkToken),tick,contact:{x:Math.max(collector.x,o.x),y:Math.max(collector.y,o.y)}});
    return true;
  }
  function activateCheckpoint(id,o){
    const key=id+'\n'+o.id;if(activatedCheckpoints.has(key))return false;
    activatedCheckpoints.set(key,tick);checkpoint={roomId:id,spawnId:o.targetSpawn};const visual=visualRooms.find(r=>r.roomId===id),reward=visual?.smm2Mechanics?.checkpointRewards?.find(q=>q.id===o.id);
    if(reward){const beforePower=p.power||0;score+=reward.points;if(reward.reward==='mushroom'&&!bill&&!p.power){p.y-=14;p.h=28;p.power=1;growth=24;}if(reward.reward==='star')p.star=modulesFor(id)?.starDuration()??600;emit('smm2-checkpoint',{event:'activation-reward',roomId:id,checkpointId:o.id,points:reward.points,reward:reward.reward,beforePower,afterPower:p.power||0});}
    if(!visual?.checkpointVisuals?.[o.id]?.hidden)emit('sound',{event:'checkpoint'});emit('checkpoint',{roomId:id,checkpointId:o.id,spawnId:o.targetSpawn});return true;
  }
  function acquireReachedCameraCheckpoint(){
    const visual=visualRooms.find(r=>r.roomId===roomId),map=plan.rooms[roomId];
    const reached=map.objects.filter(o=>o.kind==='checkpoint'&&visual?.checkpointRules?.[o.id]?.trigger==='camera-x'&&cam>=visual.checkpointRules[o.id].x).sort((a,b)=>visual.checkpointRules[a.id].x-visual.checkpointRules[b.id].x);
    for(const o of reached)activateCheckpoint(roomId,o);
  }
  function respawn(terrain=false){if(dying||completed)return;cloudsFor(roomId)?.disembark(p,{reason:'hurt'});const penalty=visualRooms.find(r=>r.roomId===roomId)?.smm2Mechanics?.deathCoinPenalty??0;if(penalty){const lost=Math.min(coins,penalty);coins-=lost;emit('smm2-course',{event:'death-coins-lost',roomId,amount:lost,tick});for(let n=0;n<lost;n++)stateFor(roomId).effects.push({kind:'coin-pop',coinLossVisual:true,x:p.x+n*4,y:p.y+4,w:10,h:14,vx:(n%2?1:-1)*1.2,vy:-2.5,life:70,age:0});}stonesFor(roomId)?.onHurt(p,{tick});shoesFor(roomId)?.dismount(p,{reason:'death',jump:false,consume:true});acquireReachedCameraCheckpoint();deathSpot={roomId,x:p.x,y:p.y,power:p.power||0,terrain};lives--;if(echo)echoDeaths++;if(bill)p.weapon='N';dying=1;p.dying=true;p.vx=0;p.vy=-5.1;
    // Keep the actual dying scene and global switch stable until respawn.
    if(echo){
      // Keep the exact committed tape; a failed attempt only cancels playback
      // and its draft/latches. The next T restores the recorded room snapshot.
      echo.cancel();if(echoBaseline?.roomId===roomId)roomStates.set(roomId,structuredClone(echoBaseline.state));
      const r=stateFor(roomId);r.geometry=echo.apply(r.geometry,p);
    }
    emit('sound',{event:'death'});
  }
  function killEnemy(r,e,flat=false){if(e.dead||cranesFor(roomId)?.isCaptiveActor?.(e)||guardsFor(roomId)?.ownsActor(e)||castleFor(roomId)?.protectsBoss(e)||juniorsFor(roomId)?.protectsActor(e))return;const reward=visualRooms.find(q=>q.roomId===roomId)?.smm2Mechanics?.enemyRewards?.find(q=>q.id===e.id),rewardToken=roomId+'\n'+e.id;if(reward?.reward==='key'&&!enemyRewardsSpent.has(rewardToken)){enemyRewardsSpent.add(rewardToken);r.items.push({id:'enemy-key-'+e.id,kind:'key',x:e.x+e.w/2-6,y:e.y+e.h/2-6,w:12,h:12,vx:0,vy:0,age:0,keyDelay:0,keySpeed:3});emit('smm2-item',{event:'enemy-key-released',roomId,actorId:e.id,tick});}if(/^(enemy-|marker-)?lakitu$/i.test(e.type)&&!r.lakituStopped)r.lakituRespawn={ticks:960,enemy:copy(e)};e.dead=true;skyFor(roomId)?.defeatedActor(e);const juniorDeath=e.smm2BowserJr?{smm2DefeatOrientation:'upside-down',vx:0,vy:-3}:{};const koopaDeath=e.smm2WalkingKoopa?{type:'koopa',shell:true,y:e.y+e.h-16*(e.smm2WalkingKoopa.variant.size==='giant'?2:1),h:16*(e.smm2WalkingKoopa.variant.size==='giant'?2:1),smm2WalkingKoopa:{...e.smm2WalkingKoopa,phase:'shell'},smm2DefeatOrientation:'upright'}:{};r.effects.push({...e,...koopaDeath,...juniorDeath,kind:'enemy-death',clipTop:undefined,flat:flat&&/goomba|walker/i.test(e.type),vx:flat||e.smm2BowserJr?0:(e.vx||.8),vy:flat?0:-3,life:flat?24:80,age:0});}
  function applySmm2PowEffects(r,contacts){for(const effect of contacts?.effects||[]){for(const target of effect.targets){const enemy=r.enemies.find(e=>e.id===target.id&&!e.dead&&!guardsFor(roomId)?.ownsActor(e));if(enemy){killEnemy(r,enemy);chainReward(r,enemy,0,[100]);}}r.effects.push({kind:'pow-effect',x:effect.position.x-24,y:effect.position.y-24,w:48,h:48,vx:0,vy:0,flat:true,life:16,age:0});emit('sound',{event:'break'});}}
  function advanceSmm2Thwomp(r,e,thwomps,smm2Items,carriers){const result=thwomps.stepEnemy(e,{tick,player:p,geometry:carriers?.geometryForActor(r.geometry,e)||r.geometry,getGeometry:()=>carriers?.geometryForActor(r.geometry,e)||r.geometry,breakSolid:({solid})=>{r.geometry=r.geometry.filter(q=>q!==solid);contraptions?.destroyBrick(roomId,solid.id);for(let n=0;n<4;n++)r.effects.push({kind:'brick-debris',x:solid.x+n%2*8,y:solid.y+Math.floor(n/2)*8,w:8,h:8,sx:n%2*8,sy:Math.floor(n/2)*8,vx:n%2?1.4:-1.4,vy:n<2?-3.8:-2.5,life:40,age:0});emit('sound',{event:'break'});}});if(result?.impact){const impact=result.impact,toggle=!impact.embedded&&impact.material==='study-switch'?switchStudy?.thwompHit(roomId,impact.solidId,e.id):null;if(toggle){applyStudyStates(true);emit('sound',{event:'bump'});emit('switch-study',toggle);}applySmm2PowEffects(r,smm2Items?.afterThwompImpact(e,{tick,contact:result.impact,actors:r.items,targets:ordinaryEnemyTargets(r.enemies),screen:{x:cam,y:Math.max(0,Math.min(plan.rooms[roomId].height-viewportHeight,p.y-100)),w:viewportWidth,h:viewportHeight},geometry:r.geometry}));r.geometry=smm2Items?.geometry(r.geometry,r.items)||r.geometry;}}
  function applyCastleCommands(r,commands){for(const cmd of commands||[]){
    if(cmd.type==='hide-markers'){for(const id of cmd.ids)if(!r.hiddenMarkers.includes(id))r.hiddenMarkers.push(id);}
    else if(cmd.type==='clear-projectiles'){r.shots.length=0;r.enemies=r.enemies.filter(e=>!/bowserfire/i.test(e.type));}
    else if(cmd.type==='sound')emit('sound',{event:cmd.event});
    else if(cmd.type==='remove-bridge-tile'){const bridge=r.geometry.find(q=>q.id===cmd.bridgeId);if(bridge){bridge.w=cmd.remainingWidth;if(bridge.w<=0)r.geometry=r.geometry.filter(q=>q!==bridge);}}
    else if(cmd.type==='boss-fall-step'){const boss=r.enemies.find(q=>q.id===cmd.actorId&&!q.dead);if(boss){boss.vy=(boss.vy||0)+cmd.gravity;boss.y+=boss.vy;boss.grounded=false;}}
    else if(cmd.type==='remove-boss')r.enemies=r.enemies.filter(q=>q.id!==cmd.actorId);
    else if(cmd.type==='walk'){
      // Authored ending velocity enters the unchanged motor before collision.
      // Its zero-axis ground friction is compensated, without moving the pose.
      p.jumpBuffer=0;p.facing=cmd.direction;p.vx=cmd.direction*(cmd.speed+(p.grounded?.05078125:0));
      motor.step(p,{x:0},character,{solids:r.geometry,width:plan.rooms[roomId].width});
    }
    else if(cmd.type==='stop-player'){p.vx=p.vy=0;}
    else if(cmd.type==='open-castle-door'&&finish?.variant==='smm2-door'&&finish.doorId===cmd.id){finish.doorOpen=true;}
    else if(cmd.type==='camera')cam=Math.min(cmd.targetX,Math.max(cam,Math.min(cmd.targetX,p.x-cameraAnchor)));
    else if(cmd.type==='complete'){completed=true;emit('complete',{result:'cleared',coins,score});}
  }}
  function hurt(){if(invulnerable||p.star||completed||dying||shoesFor(roomId)?.isPlayingDead(p))return;stonesFor(roomId)?.onHurt(p,{tick});if(shoesFor(roomId)?.ownsPlayer(p)){shoesFor(roomId).dismount(p,{reason:'hurt',jump:false,consume:true});invulnerable=120;emit('sound',{event:'hurt'});return;}if(p.helmet==='buzzy'){delete p.helmet;invulnerable=120;emit('sound',{event:'hurt'});emit('smm2-item',{event:'helmet-consumed',roomId,tick});return;}carsFor(roomId)?.disembark?.(p,{reason:'hurt',jump:false});cloudsFor(roomId)?.disembark(p,{reason:'hurt'});if(bill){respawn();return;}if(p.power){p.power=0;p.y+=p.h-14;p.h=14;invulnerable=120;shrink=24;emit('sound',{event:'hurt'});return;}health--;invulnerable=60;if(health<=0)respawn();else emit('sound',{event:'hurt'});}
  enter(roomId,plan.stage.entrySpawn);
  if(contraptions&&!initialState)lives=contraptions.initialLives;if(!initialState&&visualRooms.find(r=>r.roomId===roomId)?.smm2Mechanics?.startingLives)lives=visualRooms.find(r=>r.roomId===roomId).smm2Mechanics.startingLives;
  if(initialState){lives=Math.max(1,initialState.lives||3);coins=initialState.coins||0;score=initialState.score||0;p.power=bill?0:Math.max(0,Math.min(2,initialState.power||0));if(bill&&initialState.hero==='bill'&&Object.hasOwn(weaponNames,initialState.weapon))p.weapon=initialState.weapon;if(!bill&&p.power){p.y-=14;p.h=28;}}
  arcadeStageReady=true;if(arcadeWalletEnabled){const initialCraneRoom=stateFor(roomId);cranesFor(roomId)?.reset({entry:true,objects:craneBodies(initialCraneRoom),taken:craneTaken(roomId,initialCraneRoom)});}
  saveEchoBaseline();
  function bump(r,id,{byShell=false}={}){
    const q=r.geometry.find(g=>g.id===id),room=visualRooms.find(r=>r.roomId===roomId);if(!q||!room||q.spikeTrap||q.pConverted)return;
    const type=sourceType(room,room.map.geometry.find(g=>g.id===(q.sourceId||id))||q);if(!['Brick','Block'].includes(type))return;
    if(q.bump)return;
    if(q.used){emit('sound',{event:'bump'});return;}
    const marker=room.markers?.find(m=>m.x===q.x&&m.y===q.y&&/contents|hidden/.test(m.kind));
    const semantic=room.semantics?.find(m=>m.id===(q.sourceId||id))?.source;
    const override=blockContent(room.map.geometry.find(g=>g.id===(q.sourceId||id)));
    let content=override||marker?.source?.contents||semantic?.contents||(type==='Block'?'coin':null);
    if(Array.isArray(content))content=content[0];content=String(content||'').toLowerCase();
    q.hidden=false;q.bump=12;
    for(const e of r.enemies)if(!e.dead&&!thwompsFor(roomId)?.ownsActor(e)&&e.x+e.w>q.x&&e.x<q.x+q.w&&Math.abs(e.y+e.h-q.y)<5){if(koopaView(e))commitKoopaContact(r,e,transitionToKoopaShell(e,{cause:'topple',tick,launchSpeed:4.35,...(e.smm2WalkingKoopa?.variant.size==='giant'?{horizontalSpeed:Math.sign(e.vx||e.smm2WalkingKoopa.walkDirection)*.8}:{})}));else killEnemy(r,e);}
    for(const item of r.items)if(!item.dead&&!item.emerge&&item.x+item.w>q.x&&item.x<q.x+q.w&&Math.abs(item.y+item.h-q.y)<5){item.vy=-3;item.vx=(p.x<item.x?1:-1)*.8;}
    if(content==='vine'){
      q.used=true;const portal=plan.rooms[roomId].objects.find(o=>o.id.endsWith('-vine-portal')&&Math.abs(o.x-q.x)<2);
      if(portal)r.vines.push({x:q.x+1,y:q.y,w:14,h:0,bottom:q.y,portal});emit('sound',{event:'appear'});return;
    }
    if(content){
      if(content==='multi'||(type==='Brick'&&content==='coin')){q.remaining??=modulesFor(roomId)?.rewardLimit(id)||modulesFor(roomId)?.rewardLimit(q.sourceId)||10;q.remaining--;q.used=q.remaining===0||!!(modulesFor(roomId)?.coinWindowExpired(id)||modulesFor(roomId)?.coinWindowExpired(q.sourceId));}else q.used=true;
      if(/coin|multi/.test(content)){collectCoin();r.effects.push({kind:'coin-pop',x:q.x+3,y:q.y-14,w:10,h:14,vx:0,vy:-2.8,life:34,age:0});}
      else {const kind=/life|1up/.test(content)?'life':/star/.test(content)?'star':bill?'bill-supply':p.power?'flower':'mushroom';r.items.push({kind,...(kind==='bill-supply'?{weapon:/^bill-[msfl]$/.test(content)?content.slice(-1).toUpperCase():nextWeapon()}:{}),x:q.x+1,y:q.y+1,w:14,h:14,vy:0,vx:['flower','bill-supply'].includes(kind)?0:.75,emerge:32,targetY:q.y-14,blockTop:q.y,age:0});emit('sound',{event:'appear'});}
    }else if(p.power||byShell){r.geometry=r.geometry.filter(g=>g.id!==id);contraptions?.destroyBrick(roomId,id);for(let i=0;i<4;i++)r.effects.push({kind:'brick-debris',x:q.x+(i%2)*8,y:q.y+Math.floor(i/2)*8,w:8,h:8,sx:(i%2)*8,sy:Math.floor(i/2)*8,vx:i%2?1.4:-1.4,vy:i<2?-3.8:-2.5,life:40,age:0});score+=50;emit('sound',{event:'break'});}else emit('sound',{event:'bump'});
  }
  function step(raw={}){
    if(disposed||completed)return;
    if(pipeInputLatch&&!heldPipeInput(raw,pipeInputLatch))pipeInputLatch=null;
    const echoEdges={record:!!raw.echo&&!echoHeld.record,retry:!!raw.echoRetry&&!echoHeld.retry,clear:!!raw.echoClear&&!echoHeld.clear};
    echoHeld={record:!!raw.echo,retry:!!raw.echoRetry,clear:!!raw.echoClear};
    if(echo&&(echoEdges.clear||echoEdges.retry||echoEdges.record)){
      echoCommand(echoEdges.clear?'clear':echoEdges.retry?'retry':'record');return;
    }
    if(completed)return;
    if(shrink||growth||fireGrowth){tick++;if(shrink)shrink--;if(growth)growth--;if(fireGrowth)fireGrowth--;return;}
    if(transition){tick++;const q=transition;q.age++;contraptions?.frameKeyFollowers({tick,roomId,player:p});
      if(q.door){if(q.age>=20){const target=q.targetRoom;for(const rewardToken of koopaContactRewards)if(rewardToken.startsWith(target+'\n'))koopaContactRewards.delete(rewardToken);roomStates.delete(target);coinCraneStates.delete(target);arenaAudienceStates.delete(target);arenaSpawnQueues.delete(target);chainChompGuardStates.delete(target);terrainStates.delete(target);thwompStates.delete(target);smm2ItemStates.delete(target);carrierStates.delete(target);shoeStates.delete(target);liquidStates.delete(target);moduleStates.delete(target);conveyorStates.delete(target);npcSpringStates.delete(target);railStates.delete(target);carStates.delete(target);portableStoneStates.delete(target);updraftStates.delete(target);parachuteStates.delete(target);cloudStates.delete(target);skyShooterStates.delete(target);railHazardStates.delete(target);snakeBlockStates.delete(target);underwaterActorStates.delete(target);goalTapeStates.delete(target);contraptions?.resetRoom(target);enter(target,q.targetSpawn);transition=null;portalLock=30;}return;}
      if(q.phase==='enter'){if(q.smm2Direction){if(q.smm2Direction==='left')p.x-=.7;else if(q.smm2Direction==='right')p.x+=.7;else p.y+=q.smm2Direction==='up'?-.8:.8;}else if(q.side)p.x+=.7;else p.y+=q.upward?-.8:.8;
        shoesFor(roomId)?.syncTransition?.(p);if(q.age>=(q.side?40:56)){if(q.targetWorld){warpTarget=q.targetWorld;completed=true;transition=null;return;}enter(q.targetRoom,q.targetSpawn);const r=stateFor(roomId),arrival=modulesFor(roomId)?.arrivalRule(q.targetSpawn),downPipe=arrival?r.geometry.find(g=>g.id===arrival.pipeId):null,pipe=r.geometry.filter(g=>g.material==='pipe'&&p.x+p.w/2>=g.x&&p.x+p.w/2<=g.x+g.w&&Math.abs(p.y+p.h-g.y)<80).sort((a,b)=>Math.abs(p.y+p.h-a.y)-Math.abs(p.y+p.h-b.y))[0];
          if(arrival&&visualRooms.find(z=>z.roomId===roomId)?.smm2Mechanics){const pipe=r.geometry.find(g=>g.id===arrival.pipeId),direction=arrival.direction;if(!pipe)throw Error('Declared arrival pipe missing');p.vx=p.vy=0;p.crouch=false;p.grounded=false;const q={phase:'exit',age:0,smm2Direction:direction,side:['left','right'].includes(direction)};if(direction==='up'){p.x=pipe.x+(pipe.w-p.w)/2;p.y=pipe.y+2;q.clipTop=pipe.y;q.targetY=pipe.y-p.h;}else if(direction==='down'){p.x=pipe.x+(pipe.w-p.w)/2;p.y=pipe.y+pipe.h-p.h-2;q.clipBottom=pipe.y+pipe.h;q.targetY=pipe.y+pipe.h+2;}else{const foot=shoesFor(roomId)?.shoeBody(p),extra=foot?foot.y+foot.h-(p.y+p.h):0;p.y=pipe.y+pipe.h-p.h-extra;if(direction==='left'){p.x=pipe.x+2;q.clipRight=pipe.x;q.targetX=pipe.x-p.w-2;}else{p.x=pipe.x+pipe.w-p.w-2;q.clipLeft=pipe.x+pipe.w;q.targetX=pipe.x+pipe.w+2;}}shoesFor(roomId)?.syncTransition?.(p);transition=q;emit('sound',{event:'portal'});return;}
          if(downPipe){p.x=downPipe.x+(downPipe.w-p.w)/2;p.y=downPipe.y+downPipe.h-p.h-2;p.vx=p.vy=0;p.crouch=false;p.grounded=false;transition={phase:'exit',age:0,downward:true,clipBottom:downPipe.y+downPipe.h,targetY:downPipe.y+downPipe.h+2};emit('sound',{event:'portal'});}
          else if(pipe){for(const e of r.enemies)if(/piranha/i.test(e.type)&&e.clipTop===pipe.y&&e.x+e.w>pipe.x&&e.x<pipe.x+pipe.w){e.age=0;e.y=e.clipTop;}p.x=pipe.x+(pipe.w-p.w)/2;p.y=pipe.y+2;p.vx=p.vy=0;p.crouch=false;p.grounded=true;transition={phase:'exit',age:0,clipTop:pipe.y,targetY:pipe.y-p.h};emit('sound',{event:'portal'});}else{transition=null;p.grounded=false;}}
      }else{if(q.age<=12)return;if(q.smm2Direction){if(q.side)p.x=q.smm2Direction==='left'?Math.max(q.targetX,p.x-.5):Math.min(q.targetX,p.x+.5);else p.y=q.smm2Direction==='up'?Math.max(q.targetY,p.y-.5):Math.min(q.targetY,p.y+.5);shoesFor(roomId)?.syncTransition?.(p);if(q.side?p.x===q.targetX:p.y===q.targetY){transition=null;p.grounded=q.smm2Direction==='up';portalLock=30;}return;}p.y=q.downward?Math.min(q.targetY,p.y+.5):Math.max(q.targetY,p.y-.5);if(p.y===q.targetY){transition=null;p.grounded=!q.downward;portalLock=30;}}return;
    }
    if(dying){tick++;dying++;for(const e of stateFor(roomId).effects)if(e.coinLossVisual&&e.life>0){e.age++;e.life--;e.x+=e.vx;e.y+=e.vy;e.vy+=.12;}stateFor(roomId).effects=stateFor(roomId).effects.filter(e=>!e.coinLossVisual||e.life>0);if(dying>24){p.y+=p.vy;p.vy+=.22;}if(dying>=105){if(autoContinue){if(!echo&&!switchStudy){continueFromCurrent();return;}if(lives>0&&continueFromCurrent())return;}if(manualDeath&&lives>0)return;dying=0;if(lives<=0){completed=true;emit('sound',{event:'gameover'});emit('complete',{result:'failed',coins,score});}else{roomStates.clear();coinCraneStates.clear();arenaAudienceStates.clear();arenaSpawnQueues.clear();chainChompGuardStates.clear();terrainStates.clear();thwompStates.clear();smm2ItemStates.clear();carrierStates.clear();shoeStates.clear();liquidStates.clear();cardStates.clear();sideSpringStates.clear();portableStoneStates.clear();updraftStates.clear();parachuteStates.clear();cloudStates.clear();skyShooterStates.clear();railHazardStates.clear();snakeBlockStates.clear();underwaterActorStates.clear();goalTapeStates.clear();pinkTaken.clear();pinkKeyReleased=false;enemyRewardsSpent.clear();moduleStates.clear();conveyorStates.clear();npcSpringStates.clear();koopaContactRewards.clear();aquaticStates.clear();castleStates.clear();railStates.clear();carStates.clear();contraptions?.reset();switchStudy?.reset();timeLeft=rules.timeLimit;timerTicks=0;p=null;enter(checkpoint.roomId,checkpoint.spawnId,!!echo);health=character.motion.maxHealth;invulnerable=90;}}return;}
    if(finish&&bill){p.aimX=1;p.aimY=0;p.firing=false;p.fireFrames=0;p.crouch=false;p.onVine=false;stateFor(roomId).shots.length=0;}
    if(finish?.castle&&finish.component){tick++;const r=stateFor(roomId),result=castleFor(roomId).stepFinish({tick,player:p,finish});for(const e of r.effects){e.age++;e.life--;e.x+=e.vx;e.y+=e.vy;if(e.kind!=='bubble'&&!e.flat)e.vy+=e.kind==='coin-pop'?.14:.22;}r.effects=r.effects.filter(e=>e.life>0);applyCastleCommands(r,result.commands);return;}
    if(finish?.castle){tick++;finish.age++;const r=stateFor(roomId);if(finish.phase==='bridge'){
      {const bridge=r.geometry.find(g=>g.id===finish.bridgeId);if(bridge){bridge.w=Math.max(0,bridge.w-4);if(!bridge.w)r.geometry=r.geometry.filter(g=>g!==bridge);}}
      if(!r.geometry.some(g=>g.id===finish.bridgeId)){finish.phase='boss-fall';finish.age=0;emit('sound',{event:'bowser_fall'});}
    }else if(finish.phase==='boss-fall'){for(const e of r.enemies)if(/bowser/i.test(e.type)){e.vy+=.22;e.y+=e.vy;}if(finish.age>80){r.enemies=r.enemies.filter(e=>!/bowser/i.test(e.type));finish.phase='walk';emit('sound',{event:'world_clear'});}}
    else if(finish.phase==='walk'){motor.step(p,{x:1},character,{solids:r.geometry,width:plan.rooms[roomId].width});cam=Math.max(cam,Math.min(Math.max(0,plan.rooms[roomId].width-viewportWidth),p.x-cameraAnchor));if(p.x>=finish.target){p.vx=0;finish.phase='reunion';finish.age=0;}}
    else if(finish.phase==='reunion'){if(finish.age>=180)finish.phase='score';}
    else if(timeLeft>0){const n=Math.min(4,timeLeft);timeLeft-=n;score+=50*n;}else{completed=true;emit('complete',{result:'cleared',coins,score});}return;}
    if(finish?.tape){
      tick++;finish.age++;const r=stateFor(roomId),map=plan.rooms[roomId];
      for(const e of r.effects){e.age++;e.life--;e.x+=e.vx||0;e.y+=e.vy||0;if(e.kind==='fish-bone-break')e.vy+=.22;}r.effects=r.effects.filter(e=>e.life>0);
      // Actual tape contact authorizes a native clear impulse. The authored
      // room profile retains observed water descent; legacy dry fits stay intact.
      if(['tape-hop','tape-fall','tape-walk'].includes(finish.phase)){
        const walking=finish.phase==='tape-walk',terrain=terrainFor(roomId),contactMotor=terrain?withSMM2TerrainContact(motor,terrain):motor;
        p.jumpBuffer=0;p.crouch=false;p.onVine=false;
        const water=finish.motion==='room'?aquaticFor(roomId)?.waterContext(p,{tick}):null;
        contactMotor.step(p,{x:walking?1:0,jump:false,jumpPressed:false},character,{solids:r.geometry,width:map.width,swimming:!!water,...(water?{swimPhysics:{...water,...(walking?{groundCap:finish.walkSpeed,horizontalCap:Math.max(water.horizontalCap,finish.walkSpeed)}:{})}}:walking?{carryMotion:{walkCap:finish.walkSpeed,runCap:finish.walkSpeed,airCap:finish.walkSpeed}}:{})});
        cam=Math.max(cam,Math.min(Math.max(0,map.width-viewportWidth),p.x-cameraAnchor));
        if(!walking){if(p.grounded){finish.phase='tape-walk';finish.age=0;}else if(p.vy>=0)finish.phase='tape-fall';}
        else if(p.x>=Math.min(map.width-p.w,finish.walkTarget)){finish.phase='tape-score';finish.age=0;p.vx=0;}
      }else if(finish.phase==='tape-score'){
        if(timeLeft>0){const n=Math.min(modulesFor(roomId)?.goalScoreRate()??4,timeLeft);timeLeft-=n;score+=n*50;}else{finish.phase='tape-clear';finish.age=0;}
      }else if(finish.phase==='tape-clear'&&finish.age>=finish.clearFrames){completed=true;emit('complete',{result:'cleared',coins,score});}
      return;
    }
    if(finish?.card){tick++;finish.age++;const r=stateFor(roomId);for(const e of r.effects){e.age++;e.life--;e.y+=e.vy||0;}r.effects=r.effects.filter(e=>e.life>0);if(finish.phase==='card-reveal'){if(finish.age>=finish.revealFrames){finish.phase='card-walk';finish.age=0;emit('sound',{event:'complete'});}}else if(finish.phase==='card-walk'){p.jumpBuffer=0;motor.step(p,{x:1},character,{solids:r.geometry,width:plan.rooms[roomId].width});cam=Math.max(cam,Math.min(Math.max(0,plan.rooms[roomId].width-viewportWidth),p.x-cameraAnchor));if(p.x>=finish.walkTarget){finish.phase='card-score';finish.age=0;p.vx=0;}}else if(finish.phase==='card-score'){if(timeLeft>0){const n=Math.min(modulesFor(roomId)?.goalScoreRate()??4,timeLeft);timeLeft-=n;score+=n*50;}else{finish.phase='card-clear';finish.age=0;}}else if(finish.phase==='card-clear'&&finish.age>=finish.clearFrames){completed=true;emit('complete',{result:'cleared',coins,score});}return;}
    if(finish){tick++;finish.age++;const endingState=stateFor(roomId);if(visualRooms.find(r=>r.roomId===roomId)?.smm2Mechanics?.goalEnemyRewards)for(const e of endingState.effects){e.age++;e.life--;e.x+=e.vx||0;e.y+=e.vy||0;}endingState.effects=endingState.effects.filter(e=>e.life>0);if(finish.phase==='slide'){p.y=Math.min(finish.floor-p.h,p.y+1.5);finish.flagY=Math.min(finish.floor-16,finish.flagY+1.8);if(p.y>=finish.floor-p.h&&finish.flagY>=finish.floor-16){finish.phase='walk';p.x=finish.poleX+4;p.vy=-1.8;p.grounded=false;emit('sound',{event:'complete'});}}else if(finish.phase==='walk'){p.jumpBuffer=0;motor.step(p,{x:1},character,{solids:stateFor(roomId).geometry,width:plan.rooms[roomId].width});if(p.x>=(echo?Math.min(plan.rooms[roomId].width-p.w,finish.x+96):(finish.walkTarget??finish.x+96))){finish.phase='score';p.vx=0;}}else if(finish.phase==='castle-flag'){finish.castleFlagAge++;if(finish.castleFlagAge>=modulesFor(roomId).castleFlagFrames()){finish.phase='castle-wait';finish.castleFlagWaitAge=0;}}else if(finish.phase==='castle-wait'){finish.castleFlagWaitAge++;if(finish.castleFlagWaitAge>=modulesFor(roomId).castleFlagWait()){completed=true;emit('complete',{result:'cleared',coins,score});}}else if(timeLeft>0){const n=Math.min(modulesFor(roomId)?.goalScoreRate()??4,timeLeft);timeLeft-=n;score+=n*50;}else if(modulesFor(roomId)?.castleFlagFrames()!==undefined){finish.phase='castle-flag';finish.castleFlagAge=0;}else{completed=true;emit('complete',{result:'cleared',coins,score});}return;}
    if(echo){echo.beforeFrame();const r=stateFor(roomId);r.geometry=echo.apply(r.geometry,p);}
    if(switchStudy){switchStudy.frame(roomId,p);applyStudyStates();}
    tick++;if(++timerTicks>=rules.timerFrames){timerTicks=0;timeLeft--;if(timeLeft===100)emit('sound',{event:'hurry'});if(timeLeft<=0){respawn();timeLeft=rules.timeLimit;return;}}if(invulnerable)invulnerable--;if(cooldown)cooldown--;if(attackAge)attackAge--;if(portalLock)portalLock--;
    if(entryWalkPortalId)raw={x:1};
    const v={x:Math.max(-1,Math.min(1,Number(raw.x)||0)),up:!!raw.up,upPressed:!!raw.up&&!prev.up,down:!!raw.down,jump:!!raw.jump,run:!!raw.run,jumpPressed:!!raw.jump&&!prev.jump,attackPressed:(!!raw.attack&&!prev.attack)||(!!raw.run&&!prev.run),interactPressed:!!raw.interact&&!prev.interact,dismount:!!raw.dismount,dismountPressed:!!raw.dismount&&!prev.dismount||!!raw.dismountPressed};prev={...raw};
    const r=stateFor(roomId),conveyors=conveyorsFor(roomId),npcSprings=npcSpringsFor(roomId),map=plan.rooms[roomId],before=roomSerial,oldBottom=p.y+p.h,marioModules=modulesFor(roomId),castle=castleFor(roomId),rail=railFor(roomId),cars=carsFor(roomId),clouds=cloudsFor(roomId),railHazards=railHazardsFor(roomId),snakes=snakeBlocksFor(roomId),underwaterActors=underwaterActorsFor(roomId);const framePlayerStart={...p},terrain=terrainFor(roomId),thwomps=thwompsFor(roomId),smm2Items=smm2ItemsFor(roomId),carriers=carriersFor(roomId),shoes=shoesFor(roomId),sideSprings=sideSpringsFor(roomId),liquid=liquidFor(roomId),stones=stonesFor(roomId),updrafts=updraftsFor(roomId),parachutes=parachutesFor(roomId),presteppedThwomps=new Map(),enemyFrameStarts=new Map(r.enemies.map(e=>[e.id,{...e}]));liquid?.step({tick});shoes?.beginFrame({tick,actors:[...r.items,...r.enemies],player:p});terrain?.beginFrame({tick,actors:[p,...r.items,...r.enemies,...(carriers?.physicsActors(r.geometry)||[])]});r.geometry=terrain?.geometry(r.geometry)||r.geometry;smm2Items?.beginFrame({tick,actors:r.items,player:p});for(const item of r.items)if(smm2Items?.ownsActor(item)&&!carriers?.ownsItem(item)){const flight=parachutes?.preStep(item,{tick,active:item.x+item.w>=cam&&item.x<=cam+viewportWidth});if(!flight?.handled||flight.advance){smm2Items.stepItem(item,{tick,geometry:r.geometry,getGeometry:()=>r.geometry,motion:flight?.motion??null});if(item.grounded)parachutes?.landed(item,{support:item.support});}}r.geometry=smm2Items?.geometry(r.geometry,r.items)||r.geometry;castle?.stepFirebars({tick,cam,viewportWidth});marioModules?.frameNotes?.({tick,actors:[p,...r.items],input:v});r.geometry=marioModules?.geometry(r.geometry)||r.geometry;
    snakes?.step({tick,player:p});if(snakes)r.geometry=[...r.geometry.filter(q=>!snakes.ownsGeometry(q)),...snakes.geometry()];
    const activeCrane=cranesFor(roomId),nearSlot=(visualRooms.find(q=>q.roomId===roomId)?.contraptions?.coinCranes||[]).find(q=>q.payment&&Math.abs(p.x+p.w/2-(q.payment.slot.x+q.payment.slot.w/2))<=28&&Math.abs(p.y+p.h-(q.payment.slot.y+q.payment.slot.h))<=40);
    activeCrane?.step({tick,objects:craneBodies(r),geometry:r.geometry,taken:craneTaken(roomId,r),payPressed:!!raw.up||!!raw.interact,nearSlotId:nearSlot?.payment.slotId});contraptions?.frame({tick});r.geometry=contraptions?.geometry(roomId,r.geometry,r.items)||r.geometry;conveyors.frame({tick});const npcSpringFrame=npcSprings.frame({tick,actors:underwaterActors?ordinaryEnemyTargets(r.enemies).filter(e=>!underwaterActors.ownsActor(e)):ordinaryEnemyTargets(r.enemies),geometry:r.geometry,resolveBodyMotion:(a,d,c)=>resolveActorTransport(a,d,c)}),npcCompressionOwned=new Set(npcSpringFrame.ownedActorIds);r.geometry=npcSpringFrame.geometry;rail?.releasePlayer(v);const heldBefore=rail?new Set(r.enemies.filter(e=>rail.held(e))):null,walkBefore=rail?new Map(r.enemies.map(e=>[e,e.vx])):null;rail?.step({tick,player:p,enemies:ordinaryEnemyTargets(r.enemies),items:r.items,geometry:r.geometry,input:v});if(rail){for(const e of r.enemies){if(rail.held(e)&&!heldBefore.has(e))e.gizmoWalkVx=walkBefore.get(e);if(!rail.held(e)&&heldBefore.has(e))e.gizmoReleased=true;}for(const a of [p,...r.enemies,...r.items])a.clawHeld=rail.held(a);}cars?.step({tick,player:p,enemies:ordinaryEnemyTargets(r.enemies),geometry:r.geometry,input:v,oneWayWalls:visualRooms.find(q=>q.roomId===roomId)?.contraptions?.oneWayWalls,isHeld:a=>!!rail?.held(a)});
    railHazards?.step({tick});clouds?.step({tick,player:p,input:v,geometry:r.geometry});
    for(const vine of r.vines)if(!vine.static){vine.y=Math.max(0,vine.y-1);vine.h=vine.bottom-vine.y;}
    const vine=r.vines.find(a=>p.x+p.w>a.x&&p.x<a.x+a.w&&p.y+p.h>a.y&&p.y<a.bottom);
    if(p.onVine&&(!vine||v.jump||v.x)){p.onVine=false;if(v.jump){p.vy=-4;p.grounded=false;}}
    if(vine&&(raw.up||p.onVine)&&!v.jump&&!v.x){if(vine.static)climbStaticVine(vine,{up:raw.up,down:v.down});else{p.onVine=true;p.x=vine.x+7-p.w/2;p.vx=p.vy=0;p.grounded=false;p.y+=raw.up?-1.5:v.down?1.5:0;if(p.y<=0){enter(vine.portal.targetRoom,vine.portal.targetSpawn);p.onVine=false;emit('sound',{event:'portal'});}return;}}
    const nativePlatformStarts=new Map(r.geometry.map(q=>[q.id,{...q}]));
for(const q of r.geometry){if(/Sky/.test(visualRooms.find(v=>v.roomId===roomId)?.setting||'')&&visualRooms.find(v=>v.roomId===roomId)?.semantics?.some(s=>s.id===q.id&&s.source?.transport===true)){if(p.support===q.id)q.riding=true;if(q.riding){q.x+=1.2;q.dx=1.2;q.dy=0;continue;}}if(q.smm2ItemBody||q.smm2CarrierGeometry||q.noteCompressionGeometry||q.smm2SnakeBlock)continue;q.dx=q.dy=0;if(marioModules?.stepPlatform(q,{cam,viewportWidth,tick}))continue;if(q.liftSpeed){q.y+=q.liftSpeed;q.dy=q.liftSpeed;if(q.y>map.height||q.y+q.h<0){q.y=q.liftSpeed>0?-q.h:map.height;q.dy=0;if(p.support===q.id){p.support=null;p.grounded=false;}}}else if(q.motion){const {axis,min,max,speed}=q.motion,old=q[axis];q[axis]=Math.max(min,Math.min(max,old+speed*q.dir));if(q[axis]>=max||q[axis]<=min)q.dir*=-1;q[axis=== 'x'?'dx':'dy']=q[axis]-old;}}
    marioModules?.updatePlatforms(r.geometry,p,{tick});sideSprings?.beforeFrame(r.geometry,{tick});
    for(const marker of visualRooms.find(q=>q.roomId===roomId)?.markers||[]){
      if(marker.kind!=='coupled-scale'||marker.source?.macro!=='Scale')continue;
      const left=r.geometry.find(g=>g.id===marker.id+'-left'),right=r.geometry.find(g=>g.id===marker.id+'-right');
      if(!left||!right)continue;
      const scaleRule=marioModules?.scaleRule(marker.id);
      if(left.scaleBroken){for(const g of [left,right]){g.fallSpeed=Math.min(scaleRule?.fallMaxSpeed??4.25,(g.fallSpeed||0)+(scaleRule?.fallAcceleration??.125));g.dy=g.fallSpeed;g.y+=g.dy;}continue;}
      const weight=p.grounded?(p.support===left.id?1:p.support===right.id?-1:0):0;
      let speed=left.scaleSpeed||0;
      if(scaleRule){const acceleration=scaleRule.acceleration,maxSpeed=scaleRule.maxSpeed;if(scaleRule.emptyStops&&(!weight||left.lastScaleWeight!==weight))speed=0;speed=weight?Math.max(-maxSpeed,Math.min(maxSpeed,speed+weight*acceleration)):scaleRule.emptyStops?0:Math.sign(speed)*Math.max(0,Math.abs(speed)-acceleration);left.lastScaleWeight=weight;}
      else speed=weight?Math.max(-1.5,Math.min(1.5,speed+weight*.04)):Math.sign(speed)*Math.max(0,Math.abs(speed)-.04);
      left.scaleSpeed=speed;
      const delta=Math.max(marker.y-left.y,Math.min(right.y-marker.y,speed));
      left.dy=delta;right.dy=-delta;left.y+=delta;right.y-=delta;
      if(weight&&(left.y<=marker.y||right.y<=marker.y)){left.scaleBroken=right.scaleBroken=true;left.fallSpeed=right.fallSpeed=0;}
    }
    // Advance only native support parents before the player's motor. Their
    // genuine impact handlers remain shared with the ordinary enemy pass.
    for(const id of carriers?.parentActorIds()||[]){const e=r.enemies.find(q=>q.id===id&&!q.dead);if(e&&thwomps?.ownsActor(e)){presteppedThwomps.set(e.id,{...e});advanceSmm2Thwomp(r,e,thwomps,smm2Items,carriers);}}
    r.geometry=carriers?.apply(r.geometry,[...r.enemies,...r.items],{tick})||r.geometry;
    for(const item of r.items)if(carriers?.ownsItem(item))smm2Items.stepItem(item,{tick,geometry:r.geometry,getGeometry:()=>r.geometry,support:carriers,actors:[...r.enemies,...r.items]});
    r.geometry=smm2Items?.geometry(r.geometry,r.items)||r.geometry;
    for(const e of r.enemies)if(updrafts?.ownsActor(e))updrafts.stepActor(e,{tick,geometry:r.geometry,cam,viewportWidth});
    for(const item of r.items)if(stones?.ownsActor(item))stones.stepItem(item,{tick,geometry:r.geometry,terrain,afterActor:(a,b,c)=>marioModules?.afterActor(a,b,c)});
    r.geometry=stones?.geometry(r.geometry,r.items)||r.geometry;stones?.beforePlayer(p,v,tick,r.geometry);r.geometry=stones?.geometry(r.geometry,r.items)||r.geometry;
    if(!rail?.playerHeld()&&!cars?.ownsPlayer()&&!clouds?.ownsPlayer(p)&&!p.onVine)carriers?.beforeActor(p,{tick,geometry:r.geometry,verticalDelta:Math.min(4.25,p.vy+(p.vy<0&&v.jump?p.jumpG:p.fallG))});
    // Also acquire a resting rider before ordinary jump handling. This covers
    // resumed/saved contact states whose support id has not been reconstructed.
    if(!p.springId&&p.grounded&&p.vy>=0){const spring=r.geometry.find(q=>q.material==='spring'&&visualRooms.find(r=>r.roomId===roomId)?.smm2Mechanics?.springs?.find(s=>s.id===q.id)?.orientation!=='horizontal'&&!q.npcSpringOwned&&!q.springAge&&p.x+p.w>q.x&&p.x<q.x+q.w&&Math.abs(p.y+p.h-q.y)<=1);
      if(spring){spring.springAge=1;spring.launchVx=p.vx;spring.restY??=spring.y;spring.restH??=spring.h;p.springId=spring.id;}
    }
    if(p.springId)p.vx=0;
    const starSupport=p.star?r.enemies.filter(e=>!e.dead&&marioModules?.enemyContact(e)?.starImmune&&e.type==='muncher').map(e=>({id:e.id,x:e.x,y:e.y,w:e.w,h:e.h,collision:'oneway',material:'muncher-support',dx:0,dy:0})):[];
    if(marioModules?.ownsNoteCompression?.(p))p.jumpBuffer=0;
    const preparedSnake=snakes?.preparePlayer(p,{tick}),playerGeometry=preparedSnake?[...r.geometry.filter(q=>!snakes.ownsGeometry(q)),...preparedSnake.geometry]:r.geometry;
    const aquatic=aquaticFor(roomId),beforePlayer=visualRooms.find(q=>q.roomId===roomId)?.smm2Mechanics?framePlayerStart:{...p},contactMotor=terrain?withSMM2TerrainContact(motor,terrain):motor,playerWorld={...(stones?.heldMotion(p)?{carryMotion:stones.heldMotion(p)}:{}),...(updrafts?.playerField(p,r.enemies)?{windMotion:updrafts.playerField(p,r.enemies)}:{}),solids:carriers?.geometryForPlayer(starSupport.length?[...playerGeometry,...starSupport]:playerGeometry,p,{tick})||(starSupport.length?[...playerGeometry,...starSupport]:playerGeometry),width:Math.min(map.width,visualRooms.find(q=>q.roomId===roomId)?.castle?.finish?.lockCameraX!==undefined?visualRooms.find(q=>q.roomId===roomId).castle.finish.lockCameraX+viewportWidth:map.width),swimming:/Underwater/.test(visualRooms.find(q=>q.roomId===roomId)?.setting||''),...(aquatic?{swimPhysics:aquatic.waterContext(p,{tick,cam,viewportWidth,input:v})}:{})},playerInput=p.springId?{...v,x:0,jump:false,jumpPressed:false}:marioModules?.ownsNoteCompression?.(p)?{...v,jump:false,jumpPressed:false}:v;for(const event of (rail?.playerHeld()||cars?.ownsPlayer()||clouds?.ownsPlayer(p)||p.onVine&&vine?.static?[]:shoes?.stepPlayer(p,playerInput,character,playerWorld,{tick,motor,targets:ordinaryEnemyTargets(r.enemies)})??contactMotor.step(p,playerInput,character,playerWorld)))emit('sound',{event:event==='jump'&&p.power?'jump_super':event});
    snakes?.observePlayerContact(p,{tick,previousPlayer:framePlayerStart});
    clouds?.sync({tick,player:p,geometry:r.geometry});
    stones?.afterPlayer(p,v,tick,r.geometry);r.geometry=stones?.geometry(r.geometry,r.items)||r.geometry;
    if(!rail?.playerHeld()&&!cars?.ownsPlayer()&&!clouds?.ownsPlayer(p)&&!p.onVine&&!p.springId)conveyorCarry(conveyors,p,beforePlayer,r.geometry);
    const itemContacts=smm2Items?.afterPlayer(p,beforePlayer,{tick,input:v,actors:r.items,targets:ordinaryEnemyTargets(r.enemies),screen:{x:cam,y:Math.max(0,Math.min(map.height-viewportHeight,p.y-100)),w:viewportWidth,h:viewportHeight},geometry:r.geometry});applySmm2PowEffects(r,itemContacts);for(const q of itemContacts?.pPressed||[])contraptions?.activateP(roomId,r.items.find(a=>a.id===q.actorId),q);if(itemContacts?.worn.length)emit('sound',{event:'powerup'});r.geometry=smm2Items?.geometry(r.geometry,r.items)||r.geometry;if(itemContacts?.pPressed?.length)r.geometry=contraptions?.geometry(roomId,r.geometry,r.items)||r.geometry;
    if(entryWalkPortalId){entryWalkStall=p.x<=entryWalkLastX+.001?entryWalkStall+1:0;entryWalkLastX=p.x;if(entryWalkStall>=30){emit('mario-module',{event:'entry-walk-blocked',roomId,portalId:entryWalkPortalId});entryWalkPortalId=null;}}
    for(const q of r.geometry)if(q.material==='spring'&&visualRooms.find(r=>r.roomId===roomId)?.smm2Mechanics?.springs?.find(s=>s.id===q.id)?.orientation!=='horizontal'&&!q.npcSpringOwned){
      q.restY??=q.y;q.restH??=q.h;
      if(!q.springAge&&p.grounded&&p.support===q.id){q.springAge=1;p.springId=q.id;q.launchVx=p.vx;p.vx=0;}
      if(q.springAge){
        const rule=visualRooms.find(r=>r.roomId===roomId)?.smm2Mechanics?.springs?.find(s=>s.id===q.id),duration=rule?.compressionFrames??12,half=duration/2,age=q.springAge++;if(age>=Math.max(1,duration-4)&&v.jump)q.boost=true;const depth=Math.min(q.restH-8,12)*(age<=half?age/half:Math.max(0,(duration-age)/half));
        q.y=q.restY+depth;q.h=q.restH-depth;
        if(p.springId===q.id){
          if(p.x+p.w<=q.x||p.x>=q.x+q.w){p.springId=null;}
          else{const placement=carriers?.positionSpringRider(p,q,{tick,geometry:r.geometry});if(placement&&!placement.reached){p.springId=null;p.grounded=false;p.support=null;p.vy=placement.blocked?.normal.y>0?.5:0;continue;}p.y=q.y-p.h;p.vy=0;p.jumpBuffer=0;p.grounded=true;p.support=q.id;
            if(age>=duration){p.springId=null;p.grounded=false;p.support=null;p.vx=v.x?Math.sign(v.x)*Math.max(Math.abs(q.launchVx||0),1.5):0;p.vy=-(rule?rule.launchSpeed*(q.boost?1.5:1):q.boost?9:6);p.jumpG=.22;p.fallG=.32;p.airCap=v.run?2.5:1.5;emit('sound',{event:p.power?'jump_super':'jump'});}
          }
        }
        if(age>=duration){q.springAge=0;q.boost=false;q.y=q.restY;q.h=q.restH;}
      }
    }
    carriers?.afterCompression(p,{tick,geometry:r.geometry,before:beforePlayer});
    sideSprings?.afterActor(p,beforePlayer,{tick,geometry:r.geometry});
    marioModules?.afterActor(p,beforePlayer,{kind:'player',input:v,tick,geometry:r.geometry});contraptions?.afterActor(roomId,p,beforePlayer,{kind:'player',input:v,tick,geometry:r.geometry,items:r.items});if(contraptions?.pressP(roomId,p,beforePlayer,r.items))r.geometry=contraptions.geometry(roomId,r.geometry,r.items);
    if(p.x<cam&&!switchStudy?.allowsBacktracking(roomId)&&!visualRooms.find(q=>q.roomId===roomId)?.contraptions){p.x=cam;if(p.vx<0)p.vx=0;}
    if(echo){
      const autoCommit=echo.afterFrame(p);r.geometry=echo.apply(r.geometry,p);
      if(autoCommit){echo.commit();restoreEchoBaseline();const resetRoom=stateFor(roomId);resetRoom.geometry=echo.apply(resetRoom.geometry,p);emit('sound',{event:'portal'});return;}
    }
    if(p.grounded)stompChain=0;
    if(p.headHit){if(cranesFor(roomId)?.headHit(p.headHit,{tick,objects:craneBodies(r),taken:craneTaken(roomId,r)}))p.headHit=null;if(marioModules?.bumpNote(p.headHit,r.items)||contraptions?.bumpNote(roomId,p.headHit,r.items))p.headHit=null;const toggle=switchStudy?.headHit(roomId,p.headHit);if(toggle){applyStudyStates(true);emit('sound',{event:'bump'});emit('switch-study',toggle);}else bump(r,p.headHit);}
    const visual=visualRooms.find(q=>q.roomId===roomId);
    if(allowWarp&&!portalLock&&(v.down||raw.interact))for(const m of visual?.markers||[]){
      if(!['world-transport','source-transport-not-simulated'].includes(m.kind)||!/^([1-8])-1$/.test(m.source?.transport?.map||''))continue;
      if(p.grounded&&Math.abs(p.y+p.h-m.y)<=4&&p.x+p.w>m.x+4&&p.x<m.x+28){p.x=m.x+(32-p.w)/2;p.vx=p.vy=0;transition={phase:'enter',age:0,clipTop:m.y,targetWorld:m.source.transport.map};emit('sound',{event:'portal'});return;}
    }
    r.sectionPassed??=new Set();
    for(const m of visual?.markers||[])if(m.kind==='conditional-sectionpass'&&motor.overlap(p,{x:m.x,y:m.y,w:2*(m.source?.width||8),h:2*(m.source?.height||8)})){
      const section=[...(visual.assembly||[])].reverse().find(a=>a.x*2<=m.x);if(section)r.sectionPassed.add(section.section);
    }
    // Multi-section mazes decide at the exit, never inside a route sensor.
    const deciders=(visual?.markers||[]).filter(m=>m.kind==='conditional-sectiondecider'&&m.source.pass-m.source.fail>1);
    r.sectionDecided??=new Set();
    for(const m of deciders){
      if(r.sectionDecided.has(m.id)||p.x<m.x||p.x>m.x+16)continue;
      const start=visual.assembly?.find(a=>a.section===m.source.fail);
      if(!start)continue;
      const required=visual.assembly.filter(a=>a.section>=m.source.fail&&a.section<m.source.pass)
        .filter(a=>(visual.markers||[]).some(q=>q.kind==='conditional-sectionpass'&&q.x>=a.x*2&&q.x<(visual.assembly.find(b=>b.x>a.x)?.x*2||map.width)));
      if(required.every(a=>r.sectionPassed.has(a.section))){r.sectionDecided.add(m.id);continue;}
      const x=start.x*2+4,screenX=p.x-cam;
      const landing=r.geometry.filter(g=>!g.hidden&&g.y>=48&&x+p.w>g.x&&x<g.x+g.w)
        .sort((a,b)=>Math.abs(a.y-(p.y+p.h))-Math.abs(b.y-(p.y+p.h)))
        .find(g=>!r.geometry.some(q=>!q.hidden&&q.collision==='solid'&&motor.overlap({x,y:g.y-p.h,w:p.w,h:p.h},q)));
      if(landing){for(const prior of deciders)if(prior.x<=start.x*2)r.sectionDecided.add(prior.id);for(const a of required)r.sectionPassed.delete(a.section);p.x=x;p.y=landing.y-p.h;p.vy=0;p.grounded=true;p.support=landing.id;p.springId=null;cam=Math.max(0,x-screenX);return;}
    }
    // Compiled castle sections retain pass/fail sensors. A failed corridor
    // must loop before its closing wall, even when camera backtracking is off.
    for(const m of visual?.markers||[]){
      if(m.kind!=='conditional-sectionfail'||!visual.assembly?.length||deciders.length)continue;
      const section=[...visual.assembly].reverse().find(a=>a.x*2<=m.x);
      if(!section||r.sectionPassed.has(section.section))continue;
      const next=visual.assembly.find(a=>a.x>section.x),end=next?next.x*2:map.width;
      // The route sensor records a choice; it is not a teleport trigger.
      r.sectionFailed??=new Set();
      if(motor.overlap(p,{x:m.x,y:m.y,w:2*(m.source?.width||8),h:2*(m.source?.height||8)}))r.sectionFailed.add(section.section);
      if(!r.sectionFailed.has(section.section)||p.x>=end)continue;
      const wall=r.geometry.filter(g=>!g.hidden&&g.collision==='solid'&&g.x>m.x+2*(m.source?.width||8)&&g.x<end&&g.y<p.y+p.h&&g.y+g.h>p.y).sort((a,b)=>a.x-b.x)[0];
      const retryAt=wall?wall.x-p.w-2:end-2;
      if(p.x<retryAt)continue;
      const x=section.x*2+4,screenX=p.x-cam;
      const landing=r.geometry.filter(g=>!g.hidden&&g.y>=48&&x+p.w>g.x&&x<g.x+g.w)
        .sort((a,b)=>b.y-a.y).find(g=>!r.geometry.some(q=>!q.hidden&&q.collision==='solid'&&motor.overlap({x,y:g.y-p.h,w:p.w,h:p.h},q)));
      if(landing){
        const free=!r.geometry.some(g=>!g.hidden&&g.collision==='solid'&&motor.overlap({x,y:p.y,w:p.w,h:p.h},g));
        p.x=x;if(!free){p.y=landing.y-p.h;p.vy=0;p.grounded=true;p.support=landing.id;}else {p.grounded=false;p.support=null;}
        p.springId=null;r.sectionFailed.delete(section.section);cam=Math.max(0,x-screenX);return;
      }
    }
    const castleFinish=castle?.triggerFinish({player:p,markers:visual?.markers,enemies:r.enemies,geometry:r.geometry});if(castleFinish){finish=castleFinish.finish;p.vx=p.vy=0;applyCastleCommands(r,castleFinish.commands);return;}
    for(const m of visual?.markers||[]){
      if(m.kind==='rotating-firebar'&&(castle?.firebarNodes(m.id)||markerParts({...visual,tick},m)).some(b=>motor.overlap(shoes?.contactBody(p)||p,b))){hurt();if(dying)return;}
      if(liquid?.ownsMarker(m.id)){if(liquid.contact(shoes?.contactBody(p)||p)&&!shoes?.isBoneShell(p)){respawn(true);return;}continue;}
      if(castle?.lavaMode()!=='pit'&&/lava/.test(m.kind)&&motor.overlap(p,{x:m.x,y:m.y,w:2*(m.source?.width||8),h:Math.max(1,map.height-m.y)})){respawn(true);return;}
      if(!castle&&['bridge-axe-finish','marker-CastleAxe'].includes(m.kind)&&motor.overlap(p,{x:m.x,y:m.y,w:16,h:16})){
        const bridge=r.geometry.filter(g=>sourceType(visual,visual.map.geometry.find(a=>a.id===g.id)||g)==='CastleBridge'&&g.x<=m.x).sort((a,b)=>b.x-a.x)[0];
        if(bridge){r.hiddenMarkers.push(m.id,...visual.markers.filter(a=>a.kind==='marker-CastleChain').map(a=>a.id));const npc=visual.markers.find(a=>a.kind==='castle-finish');finish={castle:true,phase:'bridge',age:0,bridgeId:bridge.id,target:(npc?.x??bridge.x)+360};p.vx=p.vy=0;emit('sound',{event:'break'});return;}
      }
    }

    for(const q of r.geometry)if(q.bump)q.bump--;for(const e of r.effects){e.age++;e.life--;e.x+=e.vx;e.y+=e.vy;if(e.kind!=='bubble'&&!e.flat)e.vy+=e.kind==='coin-pop'?.14:.22;}r.effects=r.effects.filter(e=>e.life>0);
    if(p.swimming&&tick%48===0&&p.y>24)r.effects.push({kind:'bubble',x:p.x+(p.facing>0?p.w:0),y:p.y+4,w:4,h:4,vx:0,vy:-.6,life:Math.max(1,Math.floor((p.y-20)/.6)),age:0});
    if(p.star)p.star--;
    r.items.push(...(marioModules?.spawnItems({player:p,items:r.items,tick,geometry:r.geometry})||[]),...(contraptions?.spawnP(roomId,r.items,r.geometry,{tick})||[]));
    for(const item of r.items){
      if(item.dead||rail?.held(item)||stones?.ownsActor(item))continue;if(smm2Items?.ownsActor(item)){const contact=smm2Items.ownedItemContact(item,p,{tick});if(contact?.collect){score+=contact.collect.points??0;pickupItem(r,item);}continue;}if(contraptions?.stepKey(roomId,item,p)){if(item.dead)score+=visualRooms.find(r=>r.roomId===roomId)?.smm2Mechanics?.scoreProfile?.keyPoints??0;continue;}
      if(item.emerge){item.emerge--;item.y=Math.max(item.targetY,item.y-.5);continue;}
      const beforeItem={...item};item.age++;const bottom=item.y+item.h,top=item.y;
      item.x+=item.vx;
      for(const q of r.geometry)if(!q.hidden&&q.collision==='solid'&&motor.overlap(item,q)){item.x=item.vx>0?q.x-item.w:q.x+q.w;item.vx*=-1;break;}
      item.vy=Math.min(4.25,item.vy+.22);item.y+=item.vy;
      for(const q of [...r.geometry].sort((a,b)=>a.y-b.y))if(!q.hidden&&item.x+item.w>q.x&&item.x<q.x+q.w&&bottom<=q.y+1&&item.y+item.h>=q.y&&item.vy>=0){item.y=q.y-item.h;item.vy=item.kind==='star'?-3.9:0;if(item.kind==='p-switch')item.vx=0;break;}
      if(item.vy<0)for(const q of r.geometry)if(!q.hidden&&q.collision==='solid'&&item.x+item.w>q.x&&item.x<q.x+q.w&&top>=q.y+q.h&&item.y<q.y+q.h){item.y=q.y+q.h;item.vy=.5;break;}
      terrain?.afterActor(item,beforeItem,{tick,geometry:r.geometry});marioModules?.afterActor(item,beforeItem,{kind:'item',tick,geometry:r.geometry});contraptions?.afterActor(roomId,item,beforeItem,{kind:'item',tick,geometry:r.geometry,items:r.items});
      if(item.kind!=='p-switch'&&motor.overlap(p,item))pickupItem(r,item);
      if(item.y>map.height+32||item.age>1800)item.dead=true;
    }
    if(growth||fireGrowth)return;
    if(p.y>map.height+40){const back=map.objects.find(o=>o.id==='sky-return');if(back){enter(back.targetRoom,back.targetSpawn);p.vy=1;emit('sound',{event:'portal'});}else respawn(true);return;}
    if(bill){p.aimY=raw.up?-1:v.down&&(!p.grounded||v.x)?1:0;p.aimX=p.aimY?v.x:p.facing;p.fireFrames=Math.max(0,(p.fireFrames||0)-1);p.firing=p.fireFrames>0;
     if((v.run||raw.attack)&&!cooldown&&r.shots.length<32){r.shots.push(...billShots(p));cooldown={N:12,M:7,S:17,F:24,L:28}[p.weapon||'N'];p.firing=true;p.fireFrames=3;emit('sound',{event:'bill_'+(p.weapon||'N')});}}
    if(!bill&&v.attackPressed&&p.power===2&&!cooldown&&r.shots.length<2){r.shots.push({kind:'fireball',x:p.x+(p.facing>0?p.w:-4),y:p.y+10,w:5,h:5,vx:p.facing*3.4,vy:1.2,age:0});cooldown=12;emit('sound',{event:'fire'});}
    for(const shot of r.shots){if(shot.kind==='bill-shot'){if(!advanceBillShot(shot))continue;
      for(const q of r.geometry)if(!q.hidden&&motor.overlap(shot,q)){shot.dead=true;
       const room=visualRooms.find(v=>v.roomId===roomId),source=room?.semantics?.find(v=>v.id===(q.sourceId||q.id))?.source;
       if(source?.contents||q.hidden||blockContent(room.map.geometry.find(g=>g.id===(q.sourceId||q.id))))bump(r,q.id);
       else if(q.material==='brick'){q.shotHp=(q.shotHp??2)-shot.damage;if(q.shotHp<=0){const power=p.power;p.power=1;bump(r,q.id);p.power=power;}}
       break;}
      if(!shot.dead)for(const e of ordinaryEnemyTargets(r.enemies))if(!e.dead&&touches(shot,e)){if(guardsFor(roomId)?.ownsActor(e)||juniorsFor(roomId)?.protectsActor(e)||castle?.protectsBoss(e)||thwompsFor(roomId)?.ownsActor(e)||e.type==='study-chomp'||marioModules?.enemyContact(e)?.fireImmune||shoes?.ownsActor(e)){shot.dead=true;break;}e.hp-=shot.damage;shot.dead=true;if(e.hp<=0){killEnemy(r,e);score+=100;}break;}
      if(shot.age>90||shot.y>map.height||shot.y<0)shot.dead=true;continue;}shot.age++;const oldY=shot.y;shot.x+=shot.vx;shot.vy=Math.min(4,shot.vy+.2);shot.y+=shot.vy;for(const q of r.geometry)if(!q.hidden&&motor.overlap(shot,q)){if(oldY+shot.h<=q.y+1){shot.y=q.y-shot.h;shot.vy=-3;}else {shot.dead=true;break;}}if(shot.dead){r.effects.push({kind:'fire-impact',x:shot.x-3,y:shot.y-3,w:12,h:12,vx:0,vy:0,life:6,age:0});continue;}for(const e of ordinaryEnemyTargets(r.enemies))if(!e.dead&&touches(shot,e)){if(guardsFor(roomId)?.ownsActor(e)||juniorsFor(roomId)?.protectsActor(e)||thwomps?.ownsActor(e)||marioModules?.enemyContact(e)?.fireImmune||shoes?.ownsActor(e)){shot.dead=true;break;}const hit=castle?.hitBoss(e,shot);if(hit?.handled){if(hit.defeated){killEnemy(r,e);chainReward(r,e,0,[hit.points]);}break;}shot.dead=true;if(!/beetle|bowser|study-chomp/i.test(e.type)){killEnemy(r,e);const aqPoints=aquatic?.firePoints(e),points=aqPoints??marioModules?.fireKillPoints();if(points===undefined)score+=100;else{chainReward(r,e,0,[points]);emit(aqPoints===undefined?'mario-module':'aquatic',{event:'fire-defeat',actorId:e.id,points});}}else if(/bowser/i.test(e.type)){e.hp=(e.hp??5)-1;if(e.hp<=0)killEnemy(r,e);}break;}if(shot.age>160||shot.y>map.height)shot.dead=true;}r.shots=r.shots.filter(s=>!s.dead);
    if(v.attackPressed&&!cooldown&&character.capabilities.includes('attack')){attackAge=9;cooldown=18;emit('sound',{event:'attack'});const box={x:p.facing>0?p.x+p.w:p.x-28,y:p.y-2,w:28,h:p.h+4};for(const e of ordinaryEnemyTargets(r.enemies))if(!e.dead&&!guardsFor(roomId)?.ownsActor(e)&&!thwomps?.ownsActor(e)&&!shoes?.ownsActor(e)&&!marioModules?.enemyContact(e)?.fireImmune&&!castle?.protectsBoss(e)&&!juniorsFor(roomId)?.protectsActor(e)&&e.type!=='study-chomp'&&motor.overlap(box,e)){e.hp--;if(e.hp<=0){killEnemy(r,e);score+=100;}}}
    if((visual?.markers||[]).some(m=>m.kind==='spawn-zone-LakituStop'&&p.x+p.w>=m.x)){r.lakituStopped=true;r.lakituRespawn=null;}
    if(r.lakituRespawn&&!r.lakituStopped){
      const pending=r.lakituRespawn;
      if(--pending.ticks<=0){
        if(!r.enemies.some(e=>!e.dead&&/^(enemy-|marker-)?lakitu$/i.test(e.type))){
          const e=pending.enemy,x=Math.min(map.width-e.w,cam+viewportWidth+8);
          r.enemies.push({...e,x,y:e.homeY,homeX:x,vx:0,vy:0,age:0,hp:2,dead:false,safe:0});
        }
        r.lakituRespawn=null;
      }
    }
    const contactPlayer={...(shoes?.contactBody(p)||p)},descending=p.vy>=0;
    const spawned=[];
    const spawn=(type,x,y,vx=0,vy=0)=>spawned.push({id:'runtime-'+tick+'-'+spawned.length,kind:'walker',type,x,y,w:16,h:16,vx,vy,homeX:x,homeY:y,age:0,dead:false});
    // Both imported Cannon geometry and hand-placed cannon material fire.
    r.cannonClocks??=new Map();
    for(const g of r.geometry){
      const original=visual?.map.geometry.find(q=>q.id===(g.sourceId||g.id))||g;
      if(g.hidden||marioModules?.ownsLauncher(g.sourceId||g.id)||!(g.material==='cannon'||sourceType(visual||{map},original)==='Cannon'))continue;
      if(g.x+g.w<cam||g.x>cam+viewportWidth)continue;
      const distance=p.x+p.w/2-(g.x+g.w/2);
      if(Math.abs(distance)<32)continue;
      const clock=(r.cannonClocks.get(g.id)||0)+1;r.cannonClocks.set(g.id,clock);
      if(clock%150!==60||r.enemies.filter(e=>!e.dead&&e.type==='bulletbill').length+spawned.filter(e=>e.type==='bulletbill').length>=3)continue;
      const direction=Math.sign(distance);
      spawn('bulletbill',direction<0?g.x-16:g.x+g.w,g.y,direction*2,0);
      spawned.at(-1).source={cannonId:g.id};emit('sound',{event:'cannon'});
    }
    // Source CheepsStart/CheepsStop detectors activate the full-height bridge zone.
    const triggers=(visualRooms.find(q=>q.roomId===roomId)?.markers||[]).filter(m=>/spawn-zone-Cheeps(Start|Stop)/.test(m.kind)&&m.x<=p.x+p.w).sort((a,b)=>a.x-b.x);
    const active=triggers.length>0&&triggers.at(-1).kind.endsWith('Start');
    r.fishClock=active?(r.fishClock||0)+1:0;
    if(active&&r.fishClock%21===0&&r.enemies.filter(e=>e.flying).length<20){
      r.fishSeed=((r.fishSeed??12345)*1664525+1013904223)>>>0;const position=r.fishSeed/4294967296;
      const x=cam+position*(viewportWidth-16);
      spawn('cheepcheep',x,map.height, (position<.5?1:-1)*(.2+position*2.6),-2.8);Object.assign(spawned.at(-1),{flying:true,falling:false,source:{red:true}});
    }
    for(const e of marioModules?.spawnEnemies?.({player:p,enemies:r.enemies,actors:r.enemies,tick,geometry:r.geometry})||[]){if(e.moduleShoeTemplateId)shoes?.registerActor(e,e.moduleShoeTemplateId);underwaterActors?.decorateActor(e);if(e.moduleEmergence?.emitterKind==='launcher'){const mouth=e.sourceClip.mouth,left=e.sourceClip.direction==='left';r.effects.push({kind:'cannon-muzzle-flash',launcherId:e.moduleEmergence.launcherId,sourceId:e.moduleSource,direction:e.sourceClip.direction,x:left?mouth-8:mouth,y:e.y+e.h/2-4,w:8,h:8,age:0,life:8,phase:'emission',flat:true,vx:0,vy:0});}r.enemies.push(e);}
    r.enemies.push(...(castle?.spawnFlames({tick,cam,enemies:r.enemies,player:p})||[]));
    r.enemies.push(...(aquatic?.spawnEnemies({player:p,cam,viewportWidth,enemies:r.enemies,tick})||[]));
    const supportDepth=e=>{let n=0,id=marioModules?.stackSupport(e.id);while(id&&n<256){n++;id=marioModules?.stackSupport(id);}return n;};
    const enemyOrder=marioModules?[...r.enemies].sort((a,b)=>supportDepth(a)-supportDepth(b)):r.enemies;
    const steppedEnemies=new Set();
    const sky=skyFor(roomId);sky?.step({tick,player:p,input:{...v,attack:!!raw.attack},enemies:r.enemies,geometry:r.geometry,clouds:clouds?.view()});if(roomSerial!==before||dying)return;
    for(const e of enemyOrder){
      if(activeCrane?.isCaptiveActor?.(e)){marioModules?.applyEnemyVariant(e);continue;}
      if(e.dead||updrafts?.ownsActor(e)||sky?.ownsActor(e)&&!sky.isActiveActor(e))continue;const beforeEnemy=presteppedThwomps.get(e.id)||(sky?.ownsActor(e)?enemyFrameStarts.get(e.id):null)||{...e};
      // This existing native body has one owner. Its pixel-swept contact is
      // authoritative even when the full visual square has a safe corner.
      const guard=guardsFor(roomId);if(guard?.ownsActor(e)){
        guard.stepActor(e,{tick,player:p,geometry:r.geometry});steppedEnemies.add(e);
        const contact=guard.playerContact(e,contactPlayer,beforePlayer,{tick,beforeActor:beforeEnemy});
        if(contact.hurt)hurt();if(roomSerial!==before||completed||dying)return;continue;
      }
      // Study actors begin at the ordinary forward activation boundary. Once
      // seen, retain their real simulation while Mario backtracks away.
      if(isStudyEnemy(e)&&!e.studyActivated){if(Math.min(e.homeX??e.x,e.x)>(visualRooms.some(r=>r.playRules)?cam+viewportWidth+16:p.x+320))continue;e.studyActivated=true;}
      const platformEnemyCarry=!underwaterActors?.ownsActor(e)&&marioModules?.carriesEnemiesOnPlatforms()&&!rail?.held(e)&&!cars?.ownsActor(e)&&!shoes?.ownsActor(e)?carryNativePlatformEnemy(e,enemyFrameStarts.get(e.id),r.geometry,nativePlatformStarts,{sweep:terrain?.sweep,tick}):null;
      const stoneEnemyCarry=!underwaterActors?.ownsActor(e)&&stones?.carryOpponent(e,{tick,previous:enemyFrameStarts.get(e.id)||beforeEnemy,resolveDisplacement:(body,delta,options)=>resolveActorTransport(body,delta,{geometry:r.geometry,...options})});
      const platformTopBefore=q=>q.portableStoneSolid&&stoneEnemyCarry?.supportId!==q.id?(q.previousTop??q.y):q.noteCompressionGeometry?q.y-(q.dy??0):marioModules?.carriesEnemiesOnPlatforms()&&platformEnemyCarry?.supportId!==q.id?(nativeMovingPlatformPreviousTop(q,nativePlatformStarts)??q.y):q.y;
      const parentId=underwaterActors?.ownsActor(e)?null:marioModules?.stackSupport(e.id),stackParent=parentId?r.enemies.find(a=>a.id===parentId&&!a.dead&&marioModules.stackSupportEligible(a)):null,priorParent=parentId?enemyFrameStarts.get(parentId):null;
      if(stackParent&&priorParent&&(e.support===parentId&&e.grounded||e.vy>=0&&Math.abs(e.y+e.h-priorParent.y)<=1.01&&e.x+e.w>priorParent.x&&e.x<priorParent.x+priorParent.w)){const dx=stackParent.x-priorParent.x,dy=stackParent.y-priorParent.y,count=Math.max(1,Math.ceil(Math.max(Math.abs(dx),Math.abs(dy))));for(let i=0;i<count;i++){const candidate={...e,x:e.x+dx/count,y:e.y+dy/count};if(r.geometry.some(g=>!g.hidden&&g.collision==='solid'&&motor.overlap(candidate,g)))break;e.x=candidate.x;e.y=candidate.y;}}
      if(!underwaterActors?.ownsActor(e)&&marioModules?.usesGenericStack(e.id)){const mounted=stackParent&&priorParent&&(e.grounded&&e.support===parentId||e.vy>=0&&Math.abs(e.y+e.h-stackParent.y)<=1.01&&e.x+e.w>stackParent.x&&e.x<stackParent.x+stackParent.w);if(mounted){if(e.stackWalkVx===undefined)e.stackWalkVx=e.vx;e.vx=0;}else if(e.stackWalkVx!==undefined){e.vx=e.stackWalkVx;delete e.stackWalkVx;}}
      const enemyGeometry=stackParent?[...r.geometry,{id:stackParent.id,x:stackParent.x,y:stackParent.y,w:stackParent.w,h:stackParent.h,collision:'oneway',dx:priorParent?stackParent.x-priorParent.x:0,dy:priorParent?stackParent.y-priorParent.y:0}]:e.type==='muncher'?[...r.geometry,...r.enemies.filter(a=>a!==e&&!a.dead&&a.type==='muncher').map(a=>({...a,collision:'oneway'}))]:r.geometry;
      const bossIntent=castle?.bossIntent(e,{tick,cam,viewportWidth,player:p,enemies:r.enemies});if(bossIntent&&!bossIntent.active)continue;if(bossIntent){e.vx=bossIntent.vx;e.facing=bossIntent.facing;e.frame=bossIntent.frame;if(bossIntent.jumpVelocity!==null)e.vy=bossIntent.jumpVelocity;if(bossIntent.flame){r.enemies.push(bossIntent.flame);emit('sound',{event:'bowser_fire'});}}
      if(!bossIntent&&/^(enemy-|marker-)?bowser$/i.test(e.type)&&e.x-p.x<1024){
        e.fireClock=(e.fireClock||0)+1;e.frame=e.fireClock%180>=40&&e.fireClock%180<=65?'firing':'';
        if(e.fireClock%180===60){const direction=p.x<e.x?-1:1;spawn('bowserfire',e.x+(direction<0?-24:e.w),e.y+8,direction*1.5,0);Object.assign(spawned.at(-1),{w:24,h:8});emit('sound',{event:'bowser_fire'});}
      }
      const parachuteFlight=parachutes?.preStep(e,{tick,active:e.x+e.w>=cam&&e.x<=cam+viewportWidth});if(parachuteFlight?.handled&&!parachuteFlight.advance)continue;
      if(e.x>p.x+320&&!e.smm2BowserJr&&e.type!=='bowser-jr-fireball'&&!parachuteFlight?.active&&!thwomps?.ownsActor(e)&&!/bowserfire|^study-/.test(e.type))continue;if(!e.smm2BowserJr&&e.type!=='bowser-jr-fireball')e.age=(e.age||0)+1;
      const type=e.type.replace(/^(enemy-|marker-)/,'').toLowerCase(),direction=p.x<e.x?-1:1,oldY=e.y,bottom=e.y+e.h;
      const classicEnemyCollision=e.emptyShell===true||marioModules?.usesClassicEnemyCollision(e.id);
      const platformShellSupport=marioModules?.carriesEnemiesOnPlatforms()&&['koopa','beetle'].includes(type);
      const observedGoombaSupport=type==='goomba'&&(!!stones||parachutes?.ownsActor(e)||visual?.marioModules?.noteBlocks.some(q=>q.enemyBounceSpeed!==undefined));
      if(koopaView(e))commitKoopaContact(r,e,recoverWalkingKoopa(e,{tick,canStand:b=>!enemyGeometry.some(g=>!g.hidden&&g.collision==='solid'&&motor.overlap(nativeTerrainBody({...e,...b}),g))}));
      if(e.shell&&!e.smm2BowserJr&&!koopaView(e)){
        // A supplied empty shell has no living occupant to revive. This does
        // not change the separate preplaced Shellmet item's equip behavior.
        if(e.emptyShell===true||Math.abs(e.vx)>1){e.shellAge=0;e.frame='';}
        else{
          e.shellAge=(e.shellAge||0)+1;e.frame=e.shellAge>=480?'peeking':'';
          if(e.shellAge>=600){
            const height=e.walkHeight||(/beetle/i.test(type)?17:24),body={...e,y:e.y+e.h-height,h:height};
            if(!r.geometry.some(g=>!g.hidden&&g.collision==='solid'&&motor.overlap(body,g))){
              e.y=body.y;e.h=height;e.shell=false;e.shellAge=0;e.frame='';e.hits=0;e.vx=direction*.5;playerActivatedShells.delete(e);
            }
          }
        }
      }
if(e.moduleEmergence){marioModules?.stepEnemy(e,{tick,geometry:enemyGeometry,player:p,canStand:b=>b.x>=0&&b.y>=0&&b.x+b.w<=map.width&&b.y+b.h<=map.height&&!enemyGeometry.some(g=>!g.hidden&&g.collision==='solid'&&motor.overlap(b,g))});continue;}
      if(shoes?.ownsActor(e)){shoes.stepActor(e,{tick,geometry:r.geometry,targets:ordinaryEnemyTargets(r.enemies)});continue;}
      const juniorStep=juniorsFor(roomId)?.stepActor(e,{tick,player:p,geometry:enemyGeometry});if(juniorStep?.projectile){spawned.push(juniorStep.projectile);emit('sound',{event:'bowser_fire'});}
      if(sky?.ownsActor(e)){/* Explicit original aerial motion; contact remains native. */}
      else if(juniorStep){/* This same native Jr/fireball has one motion owner. */}
      else if(thwomps?.ownsActor(e)){advanceSmm2Thwomp(r,e,thwomps,smm2Items,carriers);}
      else if(npcCompressionOwned.has(e.id)){
        // This tick's genuine Spring compression already positioned the actor.
      }else if(rail?.held(e)||cars?.ownsActor(e)){
        // Actual claw/vehicle constraints carry this live enemy; contact stays native.
      }else if(marioModules?.stepEnemy(e,{tick,geometry:enemyGeometry,player:p,canStand:b=>b.x>=0&&b.y>=0&&b.x+b.w<=map.width&&b.y+b.h<=map.height&&!enemyGeometry.some(g=>!g.hidden&&g.collision==='solid'&&motor.overlap(b,g))})){
        // A live winged Koopa follows the authored vertical path. It remains a
        // normal contact enemy; the first real stomp releases it to gravity.
      }else if(underwaterActors?.stepActor(e,{tick,player:p,geometry:enemyGeometry})){
        // This same live body owns exactly one underwater motion step.
      }else if(aquatic?.stepEnemy(e,{player:p,tick,cam,viewportWidth})){
        // Authored aquatic bodies ignore terrain, retaining real contact/projectiles.
      }else if(type==='study-piranha'||type==='study-chomp'){
        marioModules?.beforeEnemy(e);stepStudyEnemy(e,enemyGeometry,map.width,type==='study-piranha'?{topBefore:platformTopBefore}:{});
      }else if(type==='lakitu'){
        if(r.lakituStopped){e.x+=2.5;if(e.x>cam+viewportWidth+24)e.dead=true;continue;}
        const target=p.x+(Math.abs(p.vx)>1.5?64:Math.sin(e.age*.022)*100);e.vx=Math.max(-2,Math.min(2,(target-e.x)*.035));e.x+=e.vx;
        e.frame=e.age%140<21?'hiding':'out';if(e.age%140===21)spawn('spinyegg',e.x,e.y,0,-4.2);
      }else if(type==='piranha'){
        let phase=e.age%180;
        const near=Math.abs(p.x+p.w/2-e.homeX-e.w/2)<28;
        // Proximity suppresses the next emergence, never interrupts an active cycle.
        if(near&&phase<=60){e.age=0;phase=0;}
        const depth=phase<60?e.h:phase<90?e.h*(90-phase)/30:phase<150?0:e.h*(phase-150)/30;
        e.y=e.homeY+depth;
      }else if(type==='bulletbill'){e.vx=e.vx<0?-2:2;e.x+=e.vx;}
      else if(type==='blooper'){const phase=e.age%120;e.vy=phase<45?-1.3:phase<75?.1:.7;e.y+=e.vy;e.x+=phase<45?direction*.65:0;}
      else if(type==='cheepcheep'){if(e.flying){e.x+=e.vx;e.y+=e.vy;if(e.y<56)e.falling=true;if(e.falling)e.vy+=.48/7;}else{e.x-=.7;e.y=e.homeY+Math.sin(e.age/45)*12;}}
      else if(type==='podoboo'){
        const surface=e.source?.managedLiquidMarkerId&&liquid?.ownsMarker(e.source.managedLiquidMarkerId)?liquid.view():null;
        if(surface){e.homeY=surface.y-e.h;if(!e.managedBubbleStarted){const phase=e.source.initialPhaseFrames||0;e.y=e.homeY-5*phase+.14*phase*(phase+1)/2;e.vy=-5+.14*phase;e.managedBubbleStarted=true;}}
        e.vy+=.14;e.y+=e.vy;if(e.y>=e.homeY){e.y=e.homeY;e.vy=-5;}
      }
      else {
        if(type==='hammerbro') {e.vx=Math.sin(e.age/22)*.65;e.facing=direction;if(e.age%140===0)e.vy=-4.2;if(e.age%120>=35&&e.age%120<84&&e.age%7===0){spawn('hammer',e.x,e.y-8,direction*1.43,-2.8);e.frame='throwing';}else e.frame='';}
        if(type==='bowser'&&!bossIntent){e.vx=direction*.4;if(e.age%150===0)e.vy=-4;}
        if(type==='bowserfire'){e.x+=e.vx;}
        else {
          const oldX=e.x;e.x+=e.vx;
          const stripTop=terrain?.followSlopeTop(e,beforeEnemy,{tick,geometry:marioModules?.usesGenericStack(e.id)?enemyGeometry:r.geometry});if(stripTop)e.y=stripTop.body.y;
          if(e.emptyShell===true||marioModules?.usesGenericStack(e.id)||platformShellSupport||koopaView(e)||observedGoombaSupport)e.support=null;
          if(type!=='hammer')for(const q of (marioModules?.usesGenericStack(e.id)?enemyGeometry:r.geometry))if(!q.hidden&&q.collision==='solid'&&motor.overlap(nativeTerrainBody(e),q)&&bottom>(q.portableStoneSolid?platformTopBefore(q):q.y)+(e.emptyShell===true?1e-7:1)){if(e.shell&&Math.abs(e.vx)>1){const toggle=switchStudy?.shellHit(roomId,q.id,e.id);if(toggle){applyStudyStates(true);emit('sound',{event:'bump'});emit('switch-study',toggle);}else if(koopaView(e)&&breakKoopaHardBlock(r,e,q,{...beforeEnemy,x:oldX})){continue;}else if(['brick','block','used'].includes(q.material)){bump(r,q.id,{byShell:true});if(!r.geometry.some(g=>g.id===q.id))continue;}}e.x=e.emptyShell===true?(e.vx>0?q.x-e.w:q.x+q.w):oldX;e.vx*=-1;break;}
          if((e.smm2WalkingKoopa?(e.smm2WalkingKoopa.variant.avoidLedges??e.smm2WalkingKoopa.variant.color==='red'):(e.source?.smart||e.source?.red))&&!e.shell&&e.grounded&&e.vx&&!conveyors.ownsSupport(beforeEnemy.support)){
            // Probe the leading foot, not the sprite's outer edge. Adjacent top
            // pieces count as continuous support; unrevealed blocks do not.
            const supports=r.geometry.filter(q=>!q.hidden&&Math.abs(q.y-bottom)<1.01),probe=e.x+e.w/2+Math.sign(e.vx)*Math.min(4,e.w/4);
            const beltSupport=conveyors.bodySupport({x:probe-.01,y:bottom-1,w:.02,h:1});if(!supports.some(q=>probe>=q.x&&probe<q.x+q.w)&&!(beltSupport&&Math.abs(beltSupport.y-bottom)<1.01)){e.x=oldX;e.vx*=-1;}
          }
          const noteGravity=e.noteBounceMotion?(e.vy<0?e.noteBounceMotion.riseGravity:e.noteBounceMotion.fallGravity):null;
          e.vy=Math.min(parachuteFlight?.motion?.maxFallSpeed??5,e.vy+(parachuteFlight?.motion?.gravity??noteGravity??(type==='hammer'||type==='hammerbro'?.12:.3)));e.y+=e.vy;e.grounded=false;
          if((visualRooms.find(q=>q.roomId===roomId)?.contraptions||classicEnemyCollision)&&e.vy<0)for(const q of r.geometry)if(!q.hidden&&q.collision==='solid'&&e.x+e.w>q.x&&e.x<q.x+q.w&&nativeTerrainBody({...e,y:oldY}).y>=q.y+q.h&&nativeTerrainBody(e).y<q.y+q.h){e.y=q.y+q.h-(nativeTerrainBody(e).y-e.y);e.vy=0;break;}
          if(e.emptyShell===true||marioModules?.usesGenericStack(e.id)||platformShellSupport||koopaView(e)||observedGoombaSupport)e.support=null;
          if(type!=='hammer')for(const q of (marioModules?.usesGenericStack(e.id)?enemyGeometry:r.geometry))if((!visualRooms.find(v=>v.roomId===roomId)?.contraptions&&!classicEnemyCollision||!q.hidden&&['solid','oneway'].includes(q.collision))&&e.x+e.w>q.x&&e.x<q.x+q.w&&bottom<=((platformShellSupport||q.portableStoneSolid||q.noteCompressionGeometry)?platformTopBefore(q):q.y)+1&&e.y+e.h>=q.y&&e.vy>=0){e.y=q.y-e.h;e.vy=0;e.grounded=true;if(e.emptyShell===true||marioModules?.usesGenericStack(e.id)||platformShellSupport||koopaView(e)||observedGoombaSupport||type==='goomba'&&(q.portableStoneSolid||marioModules?.noteRule?.(q.id)?.enemyBounceSpeed!==undefined)||parachuteFlight?.open)e.support=q.id;if(e.smm2WalkingKoopa?.phase==='flipped-shell')e.vx=0;if(type==='spinyegg'){e.type='spiny';e.vx=direction*.5;}else if(e.source?.jumping)e.vy=-(marioModules?.hoppingImpulse(e.id)??3);break;}
        }
      }
      if(!sky?.ownsActor(e)&&!underwaterActors?.ownsActor(e)&&!e.moduleEmergence&&!rail?.held(e)&&!cars?.ownsActor(e)&&!shoes?.ownsActor(e)&&!npcCompressionOwned.has(e.id))conveyorCarry(conveyors,e,beforeEnemy,r.geometry);
      if(terrain&&!sky?.ownsActor(e)&&!underwaterActors?.ownsActor(e)&&!thwomps?.ownsActor(e)&&!shoes?.ownsActor(e))terrain.afterActor(e,beforeEnemy,{tick,input:v,geometry:r.geometry});
      if(!sky?.ownsActor(e)&&!underwaterActors?.ownsActor(e))npcSprings.afterActor(e,beforeEnemy,{tick,geometry:r.geometry});r.geometry=npcSprings.geometry(r.geometry);
      if(e.grounded){delete e.noteBounceMotion;parachutes?.landed(e,{support:e.support});}
      if(e.dead)continue;steppedEnemies.add(e);
      if(e.gizmoReleased&&e.grounded&&/goomba/i.test(e.type)){e.vx=Math.sign(e.gizmoWalkVx||e.vx||-1)*.5;e.gizmoReleased=false;}if(!sky?.ownsActor(e)&&!underwaterActors?.ownsActor(e))marioModules?.afterActor(e,beforeEnemy,{kind:'enemy',tick,geometry:r.geometry});if(e.smm2WalkingKoopa){const body=nativeTerrainBody(e),prior=nativeTerrainBody(beforeEnemy),inset=body.y-e.y;contraptions?.afterActor(roomId,body,prior,{kind:'enemy',tick,geometry:r.geometry,items:r.items});e.x=body.x;e.y=body.y-inset;e.vx=body.vx;e.vy=body.vy;e.grounded=body.grounded;e.support=body.support;}else if(!sky?.ownsActor(e)&&!underwaterActors?.ownsActor(e))contraptions?.afterActor(roomId,e,beforeEnemy,{kind:'enemy',tick,geometry:r.geometry,items:r.items});
      if(!thwomps?.ownsActor(e)&&visualRooms.find(q=>q.roomId===roomId)?.contraptions&&map.objects.some(o=>o.kind==='hazard'&&!smm2Items?.ownsActor(o)&&!contraptions?.isSpikeTrap(roomId,o.id)&&motor.overlap(e,o))){killEnemy(r,e);emit('contraption',{event:'enemy-thorn-contact',roomId,actorId:e.id});}
      if(e.y>map.height+40||(e.castleBattleFlame&&(e.x+e.w<0||e.x>map.width))||(!thwomps?.ownsActor(e)&&!e.smm2BowserJr&&e.type!=='bowser-jr-fireball'&&!type.startsWith('study-')&&e.x<p.x-512)||(type==='bulletbill'&&(e.x+e.w<cam-32||e.x>cam+viewportWidth+32)))e.dead=true;
      let stoneDefeated=false;for(const item of r.items){const contact=stones?.opponentContact(e,item,{actorBefore:beforeEnemy});if(contact?.eligible){killEnemy(r,e);chainReward(r,e,0,[contact.points??200]);emit('sound',{event:'kick'});emit('portable-stone',{event:'enemy-defeated',roomId,...contact});stoneDefeated=true;break;}}if(stoneDefeated)continue;
      const shellHeadContact=!bill&&!shoes?.ownsPlayer(p)&&!cars?.ownsPlayer()&&!rail?.playerHeld()?suppliedEmptyShellHeadContact(p,beforePlayer,e,beforeEnemy):null;
      if(shellHeadContact){
        // Equip consumes this live shell once, without an enemy defeat reward.
        e.dead=true;e.removed=true;e.grounded=false;e.support=null;e.vx=e.vy=0;playerActivatedShells.delete(e);terrain?.clearActorContact?.(e);p.helmet='buzzy';
        emit('smm2-item',{event:'helmet-worn',roomId,actorId:e.id,sourceId:e.moduleSource,source:'empty-beetle-shell',helmet:'buzzy',contact:shellHeadContact,power:p.power||0,tick});emit('sound',{event:'powerup'});continue;
      }
      spawned.push(...(marioModules?.fireShots(e,{tick,player:p,projectiles:[...r.enemies,...spawned]})||[]));
      const juniorContact=!bill&&!shoes?.ownsPlayer(p)?juniorsFor(roomId)?.playerContact(e,contactPlayer,beforePlayer,{tick,beforeActor:beforeEnemy}):null;
      if(juniorContact?.handled){if(juniorContact.bounce){p.y=Math.min(p.y,juniorContact.bounceY);p.vy=-4.1333333;p.jumpG=.125;p.fallG=.4375;p.grounded=false;p.support=null;emit('sound',{event:'stomp'});}if(juniorContact.defeated){killEnemy(r,e);chainReward(r,e,0,[4000]);}else if(juniorContact.harmful)hurt();if(roomSerial!==before||completed||dying)return;continue;}
      const shoeContact=shoes?.playerEnemyContact(p,beforePlayer,e,{tick,targetBefore:beforeEnemy});if(shoeContact?.handled&&shoeContact.protected){if(shoeContact.action==='collapse'){marioModules?.dryBonesContact(e,{tick,attack:'bone-shell-stomp'});emit('sound',{event:'stomp'});}else if(shoeContact.action==='defeat'){killEnemy(r,e);chainReward(r,e,0,[200]);emit('sound',{event:'stomp'});}continue;}
      if(e.type==='dry-bones'&&!e.dead){const touching=touches(contactPlayer,e),top=e.y,attack=!shoes?.ownsPlayer(p)&&descending&&oldBottom<=oldY+7&&touching?'stomp':'body';if(touching){const result=marioModules?.dryBonesContact(e,{tick,attack});if(result?.handled){if(result.bounce){p.y=Math.min(p.y,top-p.h);p.vy=-(result.bounceSpeed||4.1333333);p.grounded=false;p.support=null;emit('sound',{event:'stomp'});}if(result.harmful)hurt();if(roomSerial!==before||completed||dying)return;continue;}}}
      const standableHazard=marioModules?.enemyContact(e)?.harmful&&marioModules?.enemyContact(e)?.solidTop&&p.grounded&&p.support===e.id&&Math.abs(p.y+p.h-e.y)<=1.01;
      if(!e.dead&&(touches(contactPlayer,e)||standableHazard)){if(thwomps?.ownsActor(e)){const protection=smm2Items?.helmetContact(p,beforePlayer,e,{tick,hazardBefore:beforeEnemy});if(protection?.protected){thwomps.requestReturn?.(e,{tick,contact:protection.contact});p.y=protection.contact.point.y;e.y=protection.contact.point.y-e.h;p.vy=Math.max(0,p.vy);p.jumpBuffer=0;emit('sound',{event:'bump'});}else if(p.star){killEnemy(r,e);chainReward(r,e,0,[100]);}else hurt();if(roomSerial!==before||completed||dying)return;continue;}
        if(p.star){if(juniorsFor(roomId)?.protectsActor(e)||castle?.protectsBoss(e)||marioModules?.enemyContact(e)?.starImmune)continue;killEnemy(r,e);const points=marioModules?.starKillPoints();if(points===undefined)score+=100;else{chainReward(r,e,0,[points]);emit('mario-module',{event:'star-defeat',actorId:e.id,points});}continue;}
        if(e.safe){e.safe--;continue;}
        if(!bill&&!aquatic?.disallowStomp(e)&&marioModules?.enemyContact(e)?.stompable!==false&&descending&&oldBottom<=oldY+7&&!/piranha|study-chomp|podoboo|spiny|bowser|hammer$/.test(type)){
          let contactSound='stomp';
          if(koopaView(e)){const phase=koopaView(e).phase;if(phase==='walking')commitKoopaContact(r,e,transitionToKoopaShell(e,{cause:'stomp',tick}));else if(Math.abs(e.vx)>1){commitKoopaContact(r,e,stopWalkingKoopaShell(e,{tick}));playerActivatedShells.delete(e);}else if(phase==='shell'){kickShell(e,12,'stomp-kick');contactSound='kick';}}else if(marioModules?.stompEnemy(e)){}else if(type==='koopa'||type==='beetle'){if(!e.shell){e.walkHeight=e.h;e.shellAge=0;e.shell=true;e.y+=e.h-16;e.h=16;e.vx=0;playerActivatedShells.delete(e);e.source={...e.source,jumping:false};}else if(Math.abs(e.vx)>1){e.vx=0;e.shellAge=0;e.frame='';playerActivatedShells.delete(e);}else{kickShell(e,12,'stomp-kick');contactSound='kick';}}else killEnemy(r,e,!cars?.ownsActor(e));
          p.y=Math.min(p.y,e.y-p.h);p.vy=-4.1333333;p.jumpG=.125;p.fallG=.4375;p.grounded=false;if(!koopaView(e))chainReward(r,e,stompChain++,visualRooms.find(q=>q.roomId===roomId)?.contraptions?[200,400,800,1000,2000,4000,5000,8000]:[100,200,400,500,800,1000,2000,4000,5000,8000]);emit('sound',{event:contactSound});continue;
        }if(e.shell&&Math.abs(e.vx)<1){kickShell(e,14,'side-kick');emit('sound',{event:'kick'});continue;}hurt();if(roomSerial!==before||completed||dying)return;
      }else if(e.safe)e.safe--;
    }
    // Resolve each contact once, after both actors have moved. Projectiles and
    // scripted airborne actors do not participate in ground crowd separation.
    cars?.sync({player:p,enemies:ordinaryEnemyTargets(r.enemies),geometry:r.geometry,isHeld:a=>!!rail?.held(a)});
    const groundBody=e=>!sky?.ownsActor(e)&&!activeCrane?.isCaptiveActor?.(e)&&!underwaterActors?.ownsActor(e)&&!e.clawHeld&&!e.vehicleId&&!e.moduleEmergence&&!e.smm2BowserJr&&/^(walker|goomba|koopa|beetle|spiny)$/.test(e.type.replace(/^(enemy-|marker-)/,'').toLowerCase());
    for(let i=0;i<r.enemies.length;i++)for(let j=i+1;j<r.enemies.length;j++){
      const a=r.enemies[i],b=r.enemies[j];if(sky?.ownsActor(a)||sky?.ownsActor(b)||activeCrane?.isCaptiveActor?.(a)||activeCrane?.isCaptiveActor?.(b)||a.dead||b.dead||!a.age||!b.age||!motor.overlap(a,b))continue;
      const movingA=a.shell&&Math.abs(a.vx)>1,movingB=b.shell&&Math.abs(b.vx)>1;
      // Typed stationary enemies still receive real shell impacts; their
      // collision response is independent of walking crowd separation.
      if(movingA!==movingB){const shell=movingA?a:b,victim=movingA?b:a;if(victim.smm2BowserJr)continue;const rule=marioModules?.enemyContact(victim);if(rule?.shellImmune===false){killEnemy(r,victim);shell.hits=(shell.hits||0)+1;chainReward(r,victim,shell.hits-1,[200,400,800,1000,2000,4000,8000]);emit('sound',{event:'kick'});emit('smm2-shell',{event:'enemy-hit',roomId,actorId:shell.id,victimId:victim.id,tick});continue;}}
      if(!groundBody(a)||!groundBody(b))continue;
      if(movingA||movingB){
        if(a.shell&&b.shell&&movingA&&movingB){const vx=a.vx;a.vx=b.vx;b.vx=vx;a.x+=a.vx;b.x+=b.vx;}
        else{const shell=movingA?a:b,victim=movingA?b:a;killEnemy(r,victim);shell.hits=(shell.hits||0)+1;chainReward(r,victim,shell.hits-1,[500,800,1000,2000,4000,5000,8000]);}
        emit('sound',{event:'kick'});continue;
      }
      if(a.verticalFlight||b.verticalFlight)continue;
      const left=a.x+a.w/2<=b.x+b.w/2?a:b,right=left===a?b:a,overlap=left.x+left.w-right.x;
      if(left.shell&&right.shell)continue;
      if(left.shell){right.x+=overlap;right.vx=Math.abs(right.vx||.5);}
      else if(right.shell){left.x-=overlap;left.vx=-Math.abs(left.vx||.5);}
      else{left.x-=overlap/2;right.x+=overlap/2;left.vx=-Math.abs(left.vx||.5);right.vx=Math.abs(right.vx||.5);}
    }
    const shoeContacts=shoes?.afterPlayer(p,beforePlayer,{tick,actors:r.enemies,geometry:r.geometry});
    for(const q of shoeContacts?.defeated||[]){const e=r.enemies.find(a=>a.id===q.actorId);if(e){chainReward(r,{...e,y:q.contact.point.y-8},0,[200]);r.effects.push({id:e.id+'-occupant',kind:'enemy-death',type:'goomba',x:e.x,y:q.contact.point.y-8,w:e.w,h:8,vx:0,vy:-3,life:60,age:0,flat:false});emit('sound',{event:'stomp'});}}
    if(shoeContacts?.damage?.length){hurt();if(dying)return;}
    for(const id of shoeContacts?.boarded||[])emit('sound',{event:'bump'});
    for(const request of shoeContacts?.breaks||[]){const q=r.geometry.find(g=>g.id===request.solidId);if(!q)continue;r.geometry=r.geometry.filter(g=>g!==q);contraptions?.destroyBrick(roomId,q.id);for(let n=0;n<4;n++)r.effects.push({kind:'brick-debris',x:q.x+n%2*8,y:q.y+Math.floor(n/2)*8,w:8,h:8,sx:n%2*8,sy:Math.floor(n/2)*8,vx:n%2?1.4:-1.4,vy:n<2?-3.8:-2.5,life:40,age:0});score+=50;emit('sound',{event:'break'});}
    for(const q of shoes?.stepEffects({tick,geometry:r.geometry,targets:ordinaryEnemyTargets(r.enemies)})||[]){const e=r.enemies.find(a=>a.id===q.targetId&&!a.dead);if(e){killEnemy(r,e);chainReward(r,e,0,[200]);emit('sound',{event:'kick'});}}
    if(!shoes?.ownsPlayer(p))for(const e of r.enemies)if(shoes?.ownsActor(e)&&!e.dead&&!e.moduleEmergence&&e.smm2Shoe?.occupancy==='npc'&&motor.overlap(p,shoes.contactBody(e))){hurt();if(dying)return;}
    arenaFor(roomId)?.step({tick,boss:r.enemies.find(e=>e.id===visual?.smm2Mechanics?.arenaAudience?.bossId)?.smm2BowserJr,enemies:r.enemies,player:p});const arenaQueue=arenaSpawnQueues.get(roomId);if(arenaQueue?.length)r.enemies.push(...arenaQueue.splice(0));
    r.enemies.push(...spawned);r.enemies=r.enemies.filter(e=>!e.dead);
    terrain?.finishFrame({tick,actors:[p,...r.items,...r.enemies,...(carriers?.physicsActors(r.geometry)||[])],settleImpactLoads:carriers?.hasWeightedSpringBodies()===true});
    carriers?.afterFrame();
    // A real seesaw impact detaches a Spring and every actual stander. Native
    // compression must not recapture the now-airborne player next frame.
    if(p.springId&&!p.grounded&&r.geometry.some(q=>q.id===p.springId&&q.smm2CarrierGeometry?.carrierType==='seesaw'))p.springId=null;
    if(smm2Items?.playerHazardContact(p,beforePlayer,{tick,actors:r.items}).length){hurt();if(dying)return;}
    if(railHazards?.contact(p,framePlayerStart)){hurt();if(dying)return;}
    contraptions?.frameKeyFollowers({tick,roomId,player:p,hidden:!!p.dying});
    const nativeObjects=contraptions?.objects(roomId,r.objects||map.objects,r.geometry)||r.objects||map.objects;
    const goalTape=goalTapeFor(roomId),tapeExit=goalTape&&nativeObjects.find(o=>o.id===visual.smm2Mechanics.goalTape.id&&o.kind==='exit');
    if(tapeExit&&(!stones||stones.readyForGoal(tapeExit.id,p))){
      // Relative swept tape contact comes before broad static exit occupancy.
      const next=goalTape.step(p,{tick,before:framePlayerStart,object:tapeExit});
      if(next){
        finish=next;score+=next.reward.points;lives+=next.reward.lives;
        if(next.reward.coins)collectCoin(next.reward.coins,0);
        if(next.reward.points)r.effects.push({kind:'score-pop',text:String(next.reward.points),x:p.x,y:p.y-8,w:40,h:8,vx:0,vy:-.4,flat:true,life:60,age:0});
        if(next.reward.coins)r.effects.push({kind:'score-pop',text:'coin × '+next.reward.coins,x:p.x,y:p.y-18,w:48,h:8,vx:0,vy:-.4,flat:true,life:60,age:0});
        if(next.reward.lives){r.effects.push({kind:'score-pop',text:next.reward.lives===1?'1UP':next.reward.lives+'UP',x:p.x,y:p.y-28,w:32,h:8,vx:0,vy:-.4,flat:true,life:60,age:0});emit('sound',{event:'life'});}
        clouds?.disembark(p,{reason:'goal'});shoes?.dismount(p,{reason:'goal',jump:false});cars?.disembark?.(p,{reason:'goal',jump:false});
        p.vx=0;p.vy=-next.hopSpeed;p.grounded=false;p.support=null;p.jumpBuffer=0;p.crouch=false;p.onVine=false;p.facing=1;p.swimming=next.motion==='room'&&!!aquaticFor(roomId);emit('sound',{event:'complete'});return;
      }
    }
    for(const o of nativeObjects){if(smm2Items?.ownsActor(o)||railHazards?.poseFor(o.id))continue;if(pinkTaken.has(roomId+'\n'+o.id))continue;if(castle&&o.kind==='exit')continue;if(goalTape&&o.kind==='exit'&&o.id===visual.smm2Mechanics.goalTape.id)continue;if(o.id.endsWith('-vine-portal')||o.id==='sky-return')continue;if(o.kind==='coin'){if(motor.overlap(p,o))takeWorldCoin(r,o);else if(visual?.smm2Mechanics?.shellCoinCollection===true){const shell=r.enemies.find(e=>shellCoinCollector(e,o,steppedEnemies));if(shell)takeWorldCoin(r,o,shell);}continue;}if(activeCrane?.isInertPayload?.(o.id))continue;const cameraCheckpoint=visual?.checkpointRules?.[o.id],contact=cameraCheckpoint?.trigger==='camera-x'?cam>=cameraCheckpoint.x:o.kind==='hazard'&&contraptions?.isSpikeTrap(roomId,o.id)?contraptions.spikePlayerContact(roomId,o,p):motor.overlap(o.kind==='hazard'?(shoes?.contactBody(p)||cars?.contactBody(p)||p):p,o);if(!contact&&(o.kind!=='portal'||!motor.overlap({...p,x:p.x-2,w:p.w+4,h:p.h+2},o)))continue;

      if(o.kind==='hazard'){const protectedSole=shoes?.playerHazardContact(p,beforePlayer,{...o,spikeTrap:contraptions?.isSpikeTrap(roomId,o.id)||o.spikeTrap},{tick});if(protectedSole?.handled&&protectedSole.protected)continue;hurt();if(roomSerial!==before||completed||dying)return;}
      if(o.kind==='checkpoint')activateCheckpoint(roomId,o);
      if(o.kind==='portal'&&!portalLock){const door=contraptions?.useDoor(roomId,o,p,v);if(door?.handled){if(door.enter){p.vx=p.vy=0;transition={door:true,phase:'enter',age:0,targetRoom:door.targetRoom,targetSpawn:door.targetSpawn};emit('sound',{event:'portal'});return;}continue;}const rule=marioModules?.portalRule(o.id);if(rule){if(visual?.smm2Mechanics){const pipe=r.geometry.find(g=>g.id===rule.pipeId);if(!pipe)continue;const direction=rule.direction,side=['left','right'].includes(direction),body=shoes?.contactBody(p)||p,across=side?body.y>=pipe.y-1&&body.y+body.h<=pipe.y+pipe.h+1:body.x+body.w>pipe.x+4&&body.x<pipe.x+pipe.w-4,aligned=across&&(direction==='left'?Math.abs(p.x-pipe.x-pipe.w)<=6:direction==='right'?Math.abs(p.x+p.w-pipe.x)<=6:direction==='up'?Math.abs(p.y-pipe.y-pipe.h)<=4:p.grounded&&Math.abs(p.y+p.h-pipe.y)<=4),requested=raw.interact||(direction==='left'?v.x<0:direction==='right'?v.x>0:direction==='up'?raw.up:v.down);if(aligned&&requested&&!pipeInputLatch){pipeInputLatch=direction;p.vx=p.vy=0;const q={phase:'enter',age:0,smm2Direction:direction,side,targetRoom:o.targetRoom,targetSpawn:o.targetSpawn};if(side){if(direction==='left')q.clipLeft=pipe.x+pipe.w;else q.clipRight=pipe.x;}else{p.x=pipe.x+(pipe.w-p.w)/2;if(direction==='up')q.clipBottom=pipe.y+pipe.h;else q.clipTop=pipe.y;}transition=q;emit('sound',{event:'portal'});return;}continue;}const pipe=r.geometry.find(g=>g.id===rule.pipeId),mouth=pipe?pipe.y+pipe.h:0,aligned=pipe&&p.x+p.w>pipe.x+4&&p.x<pipe.x+pipe.w-4&&Math.abs(p.y-mouth)<=4;if((raw.up||v.interactPressed||raw.interact)&&aligned){p.x=pipe.x+(pipe.w-p.w)/2;p.vx=p.vy=0;transition={phase:'enter',age:0,upward:true,clipBottom:mouth,targetRoom:o.targetRoom,targetSpawn:o.targetSpawn};emit('sound',{event:'portal'});return;}continue;}const side=r.geometry.find(g=>g.material==='pipe-side'&&Math.abs(g.x-o.x)<32&&Math.abs(g.y-o.y)<32)||(o.h>o.w&&r.geometry.some(g=>g.material==='pipe'&&g.x>=o.x&&g.x<=o.x+32&&g.y<o.y-32)?{x:o.x,y:o.y,w:o.w,h:o.h}:null);if(raw.interact||(side&&v.x>0)||(!side&&v.down)){
        const pipe=side||r.geometry.find(g=>g.material==='pipe'&&o.x<g.x+g.w&&o.x+o.w>g.x&&Math.abs(o.y-g.y)<32);
        if(pipe){const mouthOverlap=p.x+p.w>pipe.x+4&&p.x<pipe.x+pipe.w-4,aligned=side?Math.abs(p.x+p.w-pipe.x)<=6&&p.y+p.h>pipe.y+4&&p.y<pipe.y+pipe.h-4:p.grounded&&Math.abs(p.y+p.h-pipe.y)<=4&&mouthOverlap;if(!aligned)continue;p.vx=p.vy=0;if(!side)p.x=pipe.x+(pipe.w-p.w)/2;transition={phase:'enter',age:0,side:!!side,clipTop:side?null:pipe.y,clipRight:side?pipe.x:null,targetRoom:o.targetRoom,targetSpawn:o.targetSpawn};emit('sound',{event:'portal'});}else{enter(o.targetRoom,o.targetSpawn);emit('sound',{event:'portal'});}return;
      }}
      if(!castle&&o.kind==='exit'&&visual?.markers?.some(m=>m.kind==='castle-finish')){const npc=visual.markers.find(m=>m.kind==='castle-finish');finish={castle:true,phase:'walk',age:0,target:Math.min(map.width-p.w,npc.x+360)};emit('sound',{event:'world_clear'});return;}
      if(o.kind==='exit'){const requirement=visual?.smm2Mechanics?.goalCloudRequirements?.find(q=>q.exitId===o.id);if(requirement&&(!clouds?.ownsPlayer(p)||p.lakituCloudId!==requirement.cloudId))continue;}
      if(o.kind==='exit'&&cardFor(roomId)){if(stones&&!stones.readyForGoal(o.id,p))continue;const next=cardFor(roomId).contact(p,{tick,object:o});if(next){finish=next;score+=next.reward.points;lives+=next.reward.lives;if(next.reward.coins){collectCoin(next.reward.coins,0);r.effects.push({kind:'score-pop',text:'coin × '+next.reward.coins,x:o.x,y:o.y-8,w:48,h:8,vx:0,vy:-.4,flat:true,life:60,age:0});}p.vx=p.vy=0;p.jumpBuffer=0;p.crouch=false;if(next.reward.lives){r.effects.push({kind:'score-pop',text:next.reward.lives===1?'1UP':next.reward.lives+'UP',x:o.x,y:o.y-8,w:32,h:8,vx:0,vy:-.4,flat:true,life:60,age:0});emit('sound',{event:'life'});}else if(!next.reward.coins)emit('sound',{event:'pickup'});}return;}
      if(o.kind==='exit'){clouds?.disembark(p,{reason:'goal'});if(visual?.smm2Mechanics?.goalCoins)collectCoin(visual.smm2Mechanics.goalCoins,visual.smm2Mechanics.goalCoinPoints);shoes?.dismount(p,{reason:'goal',jump:false});for(const reward of visual?.smm2Mechanics?.goalEnemyRewards||[]){const enemy=r.enemies.find(e=>e.id===reward.id&&!e.dead);if(enemy){enemy.dead=true;score+=reward.points;r.effects.push({kind:'score-pop',text:String(reward.points),x:enemy.x,y:enemy.y,w:32,h:8,vx:0,vy:-.4,flat:true,life:45,age:0});emit('smm2-goal',{event:'enemy-cleared',roomId,actorId:enemy.id,points:reward.points});}}r.enemies=r.enemies.filter(e=>!e.dead);cars?.disembark?.(p,{reason:'goal',jump:false});const ground=r.geometry.filter(q=>p.x+p.w>=q.x&&p.x<=q.x+q.w&&q.y>=p.y+p.h).sort((a,b)=>a.y-b.y)[0];const marker=visual?.markers?.find(m=>m.kind==='flagpole-finish'&&Math.abs(m.x-o.x)<32),poleX=marker?marker.x+8:o.x+o.w/2;const base=r.geometry.filter(g=>g.x<=poleX&&g.x+g.w>=poleX&&g.y>=p.y+p.h).sort((a,b)=>a.y-b.y)[0];finish={phase:'slide',age:0,x:o.x,...(marker?.source?.walkDistance?{walkTarget:o.x+marker.source.walkDistance}:{}),poleX,flagY:marker?flagRestY(marker):o.y,floor:base?.y||ground?.y||map.height-32};if(visual?.smm2Mechanics?.flagScore===false){}else if(visual?.smm2Mechanics?.goalTopLife){const relative=p.y-o.y;if(relative<24){lives++;r.effects.push({kind:'score-pop',text:'1UP',x:p.x,y:p.y-8,w:24,h:8,vx:0,vy:-.4,flat:true,life:48,age:0});emit('sound',{event:'life'});}else score+=relative<64?2000:relative<100?800:relative<136?400:100;}else score+=p.y<62?5000:p.y<100?2000:p.y<140?800:p.y<176?400:100;p.x=poleX-p.w;p.facing=1;p.crouch=false;p.vx=p.vy=0;emit('sound',{event:'flag'});return;}
    }
    const nextCam=Math.max(0,Math.min(Math.max(0,cameraWidth(roomId)-viewportWidth),p.x-cameraAnchor));cam=visual?.smm2Mechanics?.camera?.horizontalForwardOnly?Math.max(cam,nextCam):switchStudy?.allowsBacktracking(roomId)||visual?.contraptions?nextCam:Math.max(cam,nextCam);const castleCamera=visual?.castle?.finish?.lockCameraX;if(castleCamera!==undefined&&!finish)cam=Math.min(cam,castleCamera);
  }
  function continueFromCurrent(){
    if((!completed&&!dying)||!p||((echo||switchStudy)&&lives<=0))return false;
    if(castleFor(roomId)||contraptions||finish?.tape){
      if(lives<=0)return false;const battleCheckpoint=dying&&castleFor(roomId)?.bossRule()?.battle?copy(checkpoint):null;
      roomStates.clear();coinCraneStates.clear();arenaAudienceStates.clear();arenaSpawnQueues.clear();chainChompGuardStates.clear();terrainStates.clear();thwompStates.clear();smm2ItemStates.clear();carrierStates.clear();shoeStates.clear();liquidStates.clear();cardStates.clear();sideSpringStates.clear();portableStoneStates.clear();updraftStates.clear();parachuteStates.clear();cloudStates.clear();skyShooterStates.clear();railHazardStates.clear();snakeBlockStates.clear();underwaterActorStates.clear();goalTapeStates.clear();pinkTaken.clear();pinkKeyReleased=false;enemyRewardsSpent.clear();moduleStates.clear();conveyorStates.clear();npcSpringStates.clear();koopaContactRewards.clear();aquaticStates.clear();castleStates.clear();railStates.clear();carStates.clear();contraptions?.reset();switchStudy?.reset();if(!battleCheckpoint)activatedCheckpoints.clear();
      completed=false;dying=0;finish=transition=null;shrink=growth=fireGrowth=0;timeLeft=rules.timeLimit;timerTicks=0;prev={};deathSpot=null;p=null;
      checkpoint=battleCheckpoint||{roomId:plan.stage.entryRoom,spawnId:plan.stage.entrySpawn};enter(checkpoint.roomId,checkpoint.spawnId);health=character.motion.maxHealth;invulnerable=90;emit('sound',{event:'continue'});return true;
    }
    let spot=deathSpot||{roomId,x:p.x,y:p.y,power:0};
    if(spot.terrain){
      const map=plan.rooms[spot.roomId],r=stateFor(spot.roomId),h=bill?30:spot.power?28:14,w=p.w;
      const hazards=[...map.objects.filter(o=>o.kind==='hazard'),...(visualRooms.find(q=>q.roomId===spot.roomId)?.markers||[]).filter(m=>/lava/.test(m.kind)).map(m=>({x:m.x,y:m.y,w:2*(m.source?.width||8),h:Math.max(1,map.height-m.y)}))];
      const candidates=[];
      // Land must connect down to the bottom of the room. The top face of a
      // castle ceiling is solid too, but is outside the playable corridor.
      const land=r.geometry.filter(g=>!g.hidden&&!g.motion&&!g.liftSpeed&&g.collision==='solid');
      const grounded=new Set(land.filter(g=>g.y+g.h>=map.height).map(g=>g.id));
      for(let changed=true;changed;){changed=false;for(const g of land)if(!grounded.has(g.id)&&land.some(b=>grounded.has(b.id)&&Math.abs(g.y+g.h-b.y)<1&&g.x<b.x+b.w&&g.x+g.w>b.x)){grounded.add(g.id);changed=true;}}
      for(const g of r.geometry){
        const visual=visualRooms.find(q=>q.roomId===spot.roomId),original=visual?.map.geometry.find(q=>q.id===(g.sourceId||g.id))||g;
        const platform=g.collision==='oneway'||['TreeTop','ShroomTop','Platform'].includes(sourceType(visual||{map},original))||['tree','shroom','platform'].includes(g.material);
        if(g.hidden||g.scaleBroken||(!grounded.has(g.id)&&!platform)||/pipe/.test(g.material||'')||g.w<w+4||g.y-h<48||g.y>=map.height)continue;
        const left=Math.max(0,g.x+2),right=Math.min(map.width-w,g.x+g.w-w-2);
        for(let x=left;x<=right;x+=2){
          const body={x,y:g.y-h,w,h};
          if(hazards.some(q=>motor.overlap({...body,y:body.y-1,h:h+2},q))||r.geometry.some(q=>q!==g&&!q.hidden&&q.collision==='solid'&&motor.overlap(body,q)))continue;
          candidates.push({...spot,x,y:body.y,distance:Math.hypot(x-spot.x,body.y-spot.y)});
        }
      }
      candidates.sort((a,b)=>a.distance-b.distance);
      if(!candidates.length)return false;
      spot=candidates[0];
    }
    roomId=spot.roomId||roomId;completed=false;dying=0;finish=null;transition=null;shrink=0;growth=0;fireGrowth=0;health=character.motion.maxHealth;lives=Math.max(1,lives);timeLeft=rules.timeLimit;timerTicks=0;invulnerable=90;portalLock=30;prev={};deathSpot=null;
    p.dying=false;p.x=spot.x;p.y=spot.y;p.vx=0;p.vy=0;p.power=Math.max(0,Math.min(2,spot.power||0));p.h=p.power?28:14;if(bill){p.power=0;p.h=30;p.weapon='N';}p.dropTicks=0;p.grounded=false;p.crouch=false;p.star=0;cam=Math.max(0,Math.min(Math.max(0,plan.rooms[roomId].width-viewportWidth),p.x-cameraAnchor));
    emit('sound',{event:'continue'});return true;
  }
  function view(){const map=plan.rooms[roomId],r=stateFor(roomId),e=echo?.view(),study=switchStudy?.view(roomId),modules=modulesFor(roomId)?.view(),aquatic=aquaticFor(roomId)?.view(),castle=castleFor(roomId)?.view(),contraption=contraptions?.view(roomId);const portableView=stonesFor(roomId)?.view(p),heldStone=portableView?.stones.find(q=>q.state.held&&!q.dead);const smm2=visualRooms.find(q=>q.roomId===roomId)?.smm2Mechanics,shoeView=shoesFor(roomId)?.view(r.enemies),mountedShoe=shoeView?.shoes.find(q=>q.occupancy==='player');return{...(smm2?{smm2Mechanics:{version:1,...(smm2.completionMarks!==undefined?{completionMarks:completionMarksView(visualRooms.find(q=>q.roomId===roomId),pinkTaken,visualRooms)}:{}),...(arenaFor(roomId)?{arenaAudience:arenaFor(roomId).view()}:{}),...(skyFor(roomId)?{skyShooter:skyFor(roomId).view()}:{}),art:smm2.art,...(finish?.tape&&finish.cameraY!==undefined?{camera:{...(smm2.camera||{}),baseY:finish.cameraY,minY:finish.cameraY,riseTop:smm2.camera?.riseTop??100}}:smm2.camera?{camera:copy(smm2.camera)}:{}),...(liquidFor(roomId)?{liquid:liquidFor(roomId).view()}:{}),...(cardFor(roomId)?{goalCard:cardFor(roomId).view(tick)}:{}),...(goalTapeFor(roomId)?{goalTape:goalTapeFor(roomId).view(tick)}:{}),...(underwaterActorsFor(roomId)?{underwaterActors:underwaterActorsFor(roomId).view(r.enemies)}:{}),...(terrainFor(roomId)?.view()||{}),...(portableView?{portableStones:portableView}:{}),...(updraftsFor(roomId)?{localUpdrafts:updraftsFor(roomId).view(r.enemies)}:{}),...(parachutesFor(roomId)?{parachuteActors:parachutesFor(roomId).view()}:{}),...(cloudsFor(roomId)?{lakituClouds:cloudsFor(roomId).view()}:{}),...(railHazardsFor(roomId)?{railHazards:railHazardsFor(roomId).view()}:{}),...(snakeBlocksFor(roomId)?{snakeBlocks:snakeBlocksFor(roomId).view()}:{}),...(smm2.goalCloudRequirements?{goalCloudRequirements:copy(smm2.goalCloudRequirements)}:{}),thwomps:thwompsFor(roomId)?.view(r.enemies),items:smm2ItemsFor(roomId)?.view(r.items),carriers:carriersFor(roomId)?.view(),pinkCoins:{taken:pinkTaken.size,total:pinkIds.size,keyReleased:pinkKeyReleased},...(shoeView?{shoes:shoeView}:{})}}:{}),...(contraption?{contraptions:{...contraption,...(p?.dying?{keyFollowers:[]}:{}),...railFor(roomId)?.view(),...carsFor(roomId)?.view(),...cranesFor(roomId)?.view()}}:{}),...(castle?{castle}:{}),...(aquatic?{aquatic}:{}),...(visualRooms.some(r=>r.playRules)?{viewportWidth,viewportHeight}:{}),...(modules?{marioModules:modules}:{}),...(study?{switchStudy:study}:{}),...(e?{echo:{...e,canRetry:e.hasSavedTape&&canEchoRewind()}}:{}),...(conveyorsFor(roomId).view()?{conveyors:conveyorsFor(roomId).view()}:{}),...(npcSpringsFor(roomId).view()?{npcSprings:npcSpringsFor(roomId).view()}:{}),warpTarget,roomId,title:plan.stage.title,character:copy(character),p:{...p,...(heldStone?{carriedStoneId:heldStone.id}:{}),...(mountedShoe?{smm2Shoe:mountedShoe}:{}),shrink,growth,fireGrowth,invulnerable,climbing:!!p.onVine||finish?.phase==='slide',piping:!!transition},transition:transition?{...transition}:null,width:map.width,height:map.height,geometry:copy(r.geometry),objects:(contraptions?.objects(roomId,r.objects||map.objects,r.geometry)||r.objects||map.objects).filter(o=>(o.kind==='checkpoint'||!r.taken.has(o.id)&&!pinkTaken.has(roomId+'\n'+o.id))&&o.kind!=='walker'&&!smm2ItemsFor(roomId)?.ownsActor(o)).map(o=>o.kind==='checkpoint'?{...copy(o),activated:activatedCheckpoints.has(roomId+'\n'+o.id),activationAge:activatedCheckpoints.has(roomId+'\n'+o.id)?Math.max(0,tick-activatedCheckpoints.get(roomId+'\n'+o.id)):null}:{...copy(o),...(railHazardsFor(roomId)?.poseFor(o.id)||{})}),vines:copy(r.vines),items:[...r.items.filter(i=>!i.dead),...r.shots,...r.effects].map(i=>{const source=portableView?.stones.find(q=>q.id===i.id);return source?.state.held?{...copy(i),...source.body}:copy(i);}),enemies:r.enemies.filter(e=>!e.dead).map(copy),hiddenMarkers:[...r.hiddenMarkers],tick,health,lives,coins,score,timeLeft,cam,invulnerable,attackAge,completed,checkpoint:{...checkpoint},disposed,finish:finish?{...finish}:null};}
  return Object.freeze({step,view,continueFromCurrent,dispose(){disposed=true;roomStates.clear();},pause(){prev={};stonesFor(roomId)?.pause(true);cranesFor(roomId)?.pause(true);guardsFor(roomId)?.pause(true);},resume(){prev={};stonesFor(roomId)?.pause(false);cranesFor(roomId)?.pause(false);guardsFor(roomId)?.pause(false);}});
}
