/** Original opt-in rail/claw constraints. Values are authored local approximations,
 * not recovered Nintendo physics. No reward, damage or level-specific logic. */
const copy=value=>JSON.parse(JSON.stringify(value));
const TAU=Math.PI*2,DEG=Math.PI/180,EPS=1e-9,CURVE_TOLERANCE=.05;
const finite=(value,min,max)=>Number.isFinite(value)&&value>=min&&value<=max;
const integer=(value,min,max)=>Number.isInteger(value)&&finite(value,min,max);
const unsafe=value=>['__proto__','constructor','prototype'].includes(value);
const fail=message=>{throw Error(message);};
const mod=(value,period)=>((value%period)+period)%period;
const distance=(a,b)=>Math.hypot(a[0]-b[0],a[1]-b[1]);
const lerp=(a,b,t)=>a+(b-a)*t;
const same=(a,b)=>distance(a,b)<EPS;
const compare=(a,b)=>a===b?0:a<b?-1:1;
const overlap=(a,b)=>a.x<b.x+b.w-EPS&&a.x+a.w>b.x+EPS&&a.y<b.y+b.h-EPS&&a.y+a.h>b.y+EPS;
function object(value,allowed,label){
 if(!value||typeof value!=='object'||Array.isArray(value)||![Object.prototype,null].includes(Object.getPrototypeOf(value)))fail('Invalid '+label);
 for(const key of Object.keys(value))if(unsafe(key)||!allowed.includes(key))fail('Unknown '+label+' field: '+key);
}
function list(value,label,max){if(!Array.isArray(value)||value.length>max)fail('Invalid '+label+' list');}
function point(value,map,label){if(!Array.isArray(value)||value.length!==2||!finite(value[0],0,map.width)||!finite(value[1],0,map.height))fail('Invalid '+label+' point outside room');}
export const RAIL_CLAW_DEFAULTS=Object.freeze({speed:.75,position:0,direction:1,ropeLength:42,swingDegrees:18,swingPeriodFrames:160,swingPhaseDegrees:0,catchRadius:6,releaseHalfWidth:24,releaseBelowHeight:144,regrabFrames:16,playerJumpSpeed:4.5});
/** Used only inside an explicitly authored playerSwing object. Uncalibrated. */
export const RAIL_PLAYER_SWING_DEFAULTS=Object.freeze({driveDegreesPerFrameSquared:.12,restoringDegreesPerFrameSquared:.18,damping:.992,maxAngleDegrees:75,maxAngularVelocityDegreesPerFrame:4});
const clawFields=['id','trackId','anchor',...Object.keys(RAIL_CLAW_DEFAULTS),'playerSwing'];
const fixedClaw=q=>Object.hasOwn(q,'anchor');
const clawFor=q=>({...RAIL_CLAW_DEFAULTS,...(fixedClaw(q)?{speed:0}:{}),...q});
const playerSwingFor=q=>({...RAIL_PLAYER_SWING_DEFAULTS,...q});
const clamp=(value,min,max)=>Math.max(min,Math.min(max,value));
function evaluate(segment,t){
 const a=segment.start,b=segment.to;
 if(segment.kind==='line')return [lerp(a[0],b[0],t),lerp(a[1],b[1],t)];
 const u=1-t,c=segment.control;return [u*u*a[0]+2*u*t*c[0]+t*t*b[0],u*u*a[1]+2*u*t*c[1]+t*t*b[1]];
}
function derivative(segment,t){
 const a=segment.start,b=segment.to;
 if(segment.kind==='line')return [b[0]-a[0],b[1]-a[1]];
 const c=segment.control;return [2*((1-t)*(c[0]-a[0])+t*(b[0]-c[0])),2*((1-t)*(c[1]-a[1])+t*(b[1]-c[1]))];
}
function compileTrack(track){
 let start=track.start,length=0;const segments=[],points=[copy(start)];
 for(const authored of track.segments){
  const segment={...authored,start,offset:length,samples:[{t:0,p:start,distance:0}]};
  function append(t,p){const previous=segment.samples.at(-1);segment.samples.push({t,p,distance:previous.distance+distance(previous.p,p)});points.push(copy(p));}
  // Subdivide on both curvature and chord length. Arc lookup interpolates t,
  // then evaluates the real quadratic, rather than walking a control polygon.
  function subdivide(t0,p0,t1,p1,depth){
   const tm=(t0+t1)/2,pm=evaluate(segment,tm),chordMid=[(p0[0]+p1[0])/2,(p0[1]+p1[1])/2];
   if(depth<14&&(distance(pm,chordMid)>CURVE_TOLERANCE||distance(p0,p1)>4)){subdivide(t0,p0,tm,pm,depth+1);subdivide(tm,pm,t1,p1,depth+1);}else append(t1,p1);
  }
  if(segment.kind==='quadratic')subdivide(0,start,1,segment.to,0);else append(1,segment.to);
  segment.length=segment.samples.at(-1).distance;length+=segment.length;segment.end=length;segments.push(segment);start=segment.to;
 }
 return {spec:track,segments,length,points};
}
function sampleTrack(track,position,direction=1){
 const segment=track.segments.find(q=>position<=q.end+EPS)||track.segments.at(-1),local=Math.max(0,Math.min(segment.length,position-segment.offset)),samples=segment.samples;
 let low=0,high=samples.length-1;
 while(low+1<high){const mid=(low+high)>>1;if(samples[mid].distance<local)low=mid;else high=mid;}
 const a=samples[low],b=samples[high],span=b.distance-a.distance,t=span>EPS?lerp(a.t,b.t,(local-a.distance)/span):a.t,p=evaluate(segment,t);
 let d=derivative(segment,t),magnitude=Math.hypot(...d);
 if(magnitude<EPS){d=[b.p[0]-a.p[0],b.p[1]-a.p[1]];magnitude=Math.hypot(...d);}
 return {anchor:{x:p[0],y:p[1]},tangent:{x:magnitude?direction*d[0]/magnitude:0,y:magnitude?direction*d[1]/magnitude:0}};
}
// Shared pure path geometry; aliases retain the existing claw implementation.
export {compileTrack as compileRailPath,sampleTrack as sampleRailPath};
/** Checks only the tracks/claws leaf of a shared contraptions spec, without mutation. */
export function validateRailClaws(room,spec=room?.contraptions){
 if(spec===undefined)return;
 if(!spec||typeof spec!=='object'||Array.isArray(spec)||![Object.prototype,null].includes(Object.getPrototypeOf(spec)))fail('Invalid contraptions');
 if(spec.tracks===undefined&&spec.claws===undefined)return;
 const map=room?.map;if(!map||!finite(map.width,1,32768)||!finite(map.height,1,4096))fail('Rail claws need valid room bounds');
 if(spec.tracks!==undefined)list(spec.tracks,'track',128);
 if(spec.claws!==undefined)list(spec.claws,'claw',256);
 const ids=new Set([...(map.geometry||[]),...(map.objects||[]),...(room.markers||[])].map(q=>q.id)),tracks=new Map();
 function id(q){if(typeof q.id!=='string'||q.id.length>72||!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(q.id)||unsafe(q.id)||ids.has(q.id))fail('Duplicate or invalid rail claw ID');ids.add(q.id);}
 for(const q of spec.tracks||[]){
  object(q,['id','start','segments','mode'],'track');id(q);point(q.start,map,'track start');list(q.segments,'track segment',128);
  if(!q.segments.length||!['bounce','loop'].includes(q.mode??'bounce'))fail('Invalid track path or mode');
  let from=q.start;
  for(const segment of q.segments){
   object(segment,['kind','to',...(segment?.kind==='quadratic'?['control']:[])],'track segment');
   if(!['line','quadratic'].includes(segment.kind))fail('Unknown track segment kind');point(segment.to,map,'track endpoint');
   if(segment.kind==='quadratic')point(segment.control,map,'track control');
   if(same(from,segment.to)&&(segment.kind==='line'||same(from,segment.control)))fail('Zero-length track segment');
   from=segment.to;
  }
  if(q.mode==='loop'&&!same(from,q.start))fail('Loop track must close at its start');
  const track=compileTrack(q);if(!finite(track.length,EPS,1000000))fail('Invalid track length');tracks.set(q.id,track);
 }
 for(const q of spec.claws||[]){
  object(q,clawFields,'claw');id(q);const c=clawFor(q),fixed=fixedClaw(q),track=tracks.get(c.trackId);
  if(fixed&&Object.hasOwn(q,'trackId'))fail('Claw anchor and trackId are mutually exclusive');
  if(fixed)point(q.anchor,map,'claw anchor');else if(!track)fail('Claw needs an existing track or fixed anchor');
  if(!finite(c.speed,0,fixed?0:256)||!finite(c.position,0,fixed?0:track.length)||![1,-1].includes(c.direction)||!finite(c.ropeLength,.1,4096)||!finite(c.swingDegrees,0,80)||!integer(c.swingPeriodFrames,2,36000)||!finite(c.swingPhaseDegrees,-360,360)||!finite(c.catchRadius,0,64)||!finite(c.releaseHalfWidth,0,512)||!finite(c.releaseBelowHeight,0,4096)||!integer(c.regrabFrames,0,36000)||!finite(c.playerJumpSpeed,0,12))fail('Invalid claw motion, sensor or release values');
  if(c.playerSwing!==undefined){object(c.playerSwing,Object.keys(RAIL_PLAYER_SWING_DEFAULTS),'player swing');const s=playerSwingFor(c.playerSwing);if(!finite(s.driveDegreesPerFrameSquared,0,2)||!finite(s.restoringDegreesPerFrameSquared,.001,2)||!finite(s.damping,0,1)||!finite(s.maxAngleDegrees,Math.max(1,c.swingDegrees),89)||!finite(s.maxAngularVelocityDegreesPerFrame,Math.max(.01,2*c.swingDegrees*Math.sin(Math.PI/c.swingPeriodFrames)-EPS),12))fail('Invalid player swing drive, restoring, damping or limits; limits must contain passive motion');}
 }
}
const alive=actor=>actor&&typeof actor==='object'&&!actor.dead&&!actor.dying&&!actor.removed&&!actor.taken;
const body=actor=>alive(actor)&&['x','y','w','h'].every(key=>Number.isFinite(actor[key]))&&actor.w>0&&actor.h>0;
function gripContact(grip,actor,radius){
 const x=Math.max(actor.x,Math.min(actor.x+actor.w,grip.x)),y=Math.max(actor.y,Math.min(actor.y+actor.h,grip.y));
 return (grip.x-x)**2+(grip.y-y)**2<=radius**2+EPS;
}
const poseFor=(state,actor)=>({x:state.grip.x-actor.w/2,y:state.grip.y,w:actor.w,h:actor.h});
const terrainFor=geometry=>geometry.filter(q=>q&&!q.hidden&&q.visible!==false&&['solid','oneway'].includes(q.collision)&&['x','y','w','h'].every(key=>Number.isFinite(q[key]))&&q.w>0&&q.h>0);
function axisInterval(position,delta,min,max){
 if(Math.abs(delta)<EPS)return position>min+EPS&&position<max-EPS?[-Infinity,Infinity]:null;
 const a=(min-position)/delta,b=(max-position)/delta;return [Math.min(a,b),Math.max(a,b)];
}
function crossesSolid(from,to,q){
 if(overlap(from,q)||overlap(to,q))return true;
 const x=axisInterval(from.x,to.x-from.x,q.x-from.w,q.x+q.w),y=axisInterval(from.y,to.y-from.y,q.y-from.h,q.y+q.h);
 return !!(x&&y&&Math.max(0,x[0],y[0])<Math.min(1,x[1],y[1])-EPS);
}
function crossesOneWay(from,to,q){
 const dy=to.y-from.y;if(dy<=EPS||from.y+from.h>q.y+EPS||to.y+to.h<q.y-EPS)return false;
 const fraction=Math.max(0,Math.min(1,(q.y-from.y-from.h)/dy)),x=lerp(from.x,to.x,fraction);
 return x+from.w>q.x+EPS&&x<q.x+q.w-EPS;
}
function obstruction(from,to,terrain){
 // One-unit substeps keep contact checks local. Exact swept slabs within each
 // step also catch very thin walls and diagonal crossings between endpoints.
 const steps=Math.max(1,Math.min(16384,Math.ceil(Math.max(Math.abs(to.x-from.x),Math.abs(to.y-from.y)))));let previous=from;
 for(let i=1;i<=steps;i++){
  const next={...to,x:lerp(from.x,to.x,i/steps),y:lerp(from.y,to.y,i/steps)};
  for(const q of terrain)if(q.collision==='solid'?crossesSolid(previous,next,q):crossesOneWay(previous,next,q))return q;
  previous=next;
 }
 return null;
}
/** Native host skips its motor/gravity for held actors, and owns every other rule. */
export function createRailClaws(room,{emit=()=>{}}={}){
 validateRailClaws(room);const extension=room?.contraptions;
 if(!extension||(extension.tracks||[]).length+(extension.claws||[]).length===0)return null;
 const trackSpecs=copy(extension.tracks||[]),clawSpecs=copy(extension.claws||[]).map(clawFor),tracks=new Map(trackSpecs.map(q=>[q.id,compileTrack({...q,mode:q.mode??'bounce'})]));
 let states,holders,records,cooldowns,releasedThisFrame,recordOrdinal,frame,lastTick,currentTick,lastPlayer,jumpHeld;
 const diagnostic=(event,data)=>emit('rail-claw',{event,roomId:room.roomId,tick:currentTick,frame,...data});
 const passiveAngle=(state,atFrame=frame)=>state.spec.swingDegrees*DEG*Math.sin(state.spec.swingPhaseDegrees*DEG+atFrame*TAU/state.spec.swingPeriodFrames);
 function pose(state){
  const sampled=fixedClaw(state.spec)?{anchor:{x:state.spec.anchor[0],y:state.spec.anchor[1]},tangent:{x:0,y:0}}:sampleTrack(tracks.get(state.spec.trackId),state.position,state.direction),angle=state.swing?.active?state.swing.angle:passiveAngle(state);
  return {...sampled,angleRadians:angle,grip:{x:sampled.anchor.x+Math.sin(angle)*state.spec.ropeLength,y:sampled.anchor.y+Math.cos(angle)*state.spec.ropeLength}};
 }
 function beginPlayerSwing(state){
  if(!state.swing||state.swing.active)return;
  state.swing.active=true;state.swing.angle=state.angleRadians;
  state.swing.velocity=passiveAngle(state)-passiveAngle(state,frame-1);
 }
 function stepPlayerSwing(state,input){
  const s=state.swing,rule=s.rule,x=clamp(Number(input?.x)||0,-1,1),limit=rule.maxAngleDegrees*DEG,velocityLimit=rule.maxAngularVelocityDegreesPerFrame*DEG;
  s.velocity=clamp((s.velocity+x*rule.driveDegreesPerFrameSquared*DEG-rule.restoringDegreesPerFrameSquared*DEG*Math.sin(s.angle))*rule.damping,-velocityLimit,velocityLimit);
  const angle=s.angle+s.velocity;s.angle=clamp(angle,-limit,limit);
  if(angle>limit&&s.velocity>0||angle<-limit&&s.velocity<0)s.velocity=0;
 }
 function reset(){
  frame=0;lastTick=null;currentTick=0;lastPlayer=null;jumpHeld=false;recordOrdinal=0;holders=new WeakMap();records=new WeakMap();cooldowns=new WeakMap();releasedThisFrame=new WeakMap();
  states=clawSpecs.map(spec=>{const state={spec,position:spec.position,direction:spec.direction,held:null,vx:0,vy:0,...(spec.playerSwing!==undefined?{swing:{rule:playerSwingFor(spec.playerSwing),active:false,angle:0,velocity:0}}:{})};return Object.assign(state,pose(state));});
 }
 reset();
 function record(actor,kind){let r=records.get(actor);if(!r){r={kind,id:typeof actor.id==='string'?actor.id:kind==='player'?'player':'rail-claw-'+kind+'-'+recordOrdinal++};records.set(actor,r);}return r;}
 function constrain(state){const actor=state.held.actor;Object.assign(actor,poseFor(state,actor));actor.vx=state.vx;actor.vy=state.vy;actor.grounded=false;actor.support=null;}
 function release(state,reason,{jump=false,blockNextFrame=false,constrainPose=true,blockerId}={}){
  const held=state.held;if(!held)return false;
  if(constrainPose&&body(held.actor))constrain(state);
  if(jump)held.actor.vy=state.vy-state.spec.playerJumpSpeed;
  holders.delete(held.actor);state.held=null;
  let perClaw=cooldowns.get(held.actor);if(!perClaw){perClaw=new Map();cooldowns.set(held.actor,perClaw);}perClaw.set(state.spec.id,frame+state.spec.regrabFrames);
  releasedThisFrame.set(held.actor,frame+(blockNextFrame?1:0));
  diagnostic('release',{clawId:state.spec.id,actorId:held.id,actorKind:held.kind,reason,...(blockerId!==undefined?{blockerId}:{}),position:{x:held.actor.x,y:held.actor.y},grip:{...state.grip},velocity:{x:held.actor.vx||0,y:held.actor.vy||0}});return true;
 }
 function held(actor){return !!actor&&alive(actor)&&!!holders.get(actor);}
 function playerHeld(){return !!lastPlayer&&held(lastPlayer);}
 function releasePlayer(input={}){
  const pressed=Object.hasOwn(input,'jumpPressed')?!!input.jumpPressed:!!input.jump&&!jumpHeld;jumpHeld=!!input.jump;
  const state=lastPlayer&&holders.get(lastPlayer);return !!(pressed&&state&&release(state,'player-jump',{jump:true,blockNextFrame:true}));
 }
 function belowSensor(player,state){
  return body(player)&&player.y>=state.grip.y+EPS&&player.y<=state.grip.y+state.spec.releaseBelowHeight&&player.x+player.w>=state.grip.x-state.spec.releaseHalfWidth&&player.x<=state.grip.x+state.spec.releaseHalfWidth;
 }
 function eligible(actor,kind){
  if(!body(actor)||actor.clawCatchable===false||actor.emerge>0||actor.carried||actor.carriedBy||actor.vehicleId||actor.clownCarId)return false;
  if(kind==='enemy')return /^(enemy-|marker-)?(walker|goomba|koopa|beetle|spiny)$/i.test(actor.type||actor.kind||'walker');
  return kind!=='item'||!['bubble','score-pop','enemy-death','fireball','hammer'].includes(actor.kind);
 }
 function step({tick,player,enemies=[],items=[],geometry=[],input={}}={}){
  const activeTick=tick??(lastTick===null?1:lastTick+1);if(!integer(activeTick,0,Number.MAX_SAFE_INTEGER))fail('Invalid rail claw tick');
  if(lastTick!==null&&activeTick<=lastTick)return false;lastTick=activeTick;currentTick=activeTick;frame++;lastPlayer=player||null;
  const actors=[],seen=new Set(),terrain=terrainFor(geometry);
  for(const [kind,entries]of [['player',player?[player]:[]],['enemy',enemies],['item',items]])for(const actor of entries)if(actor&&typeof actor==='object'&&!seen.has(actor)){seen.add(actor);actors.push({actor,...record(actor,kind)});}
  for(const state of states){
   const driving=state.swing?.active&&state.held?.kind==='player'&&state.held.actor===player&&seen.has(player)&&body(player);
   const oldGrip=state.grip,track=tracks.get(state.spec.trackId),speed=state.spec.speed;
   // First real player capture enters the physical model. From then until
   // reset, empty and NPC-held claws coast under the same restoring/damping
   // forces; only that live held player may add horizontal drive.
   if(state.swing?.active)stepPlayerSwing(state,driving?input:{x:0});
   if(track&&speed){
    if(track.spec.mode==='loop')state.position=mod(state.position+state.direction*speed,track.length);
    else{const phase=mod((state.direction===1?state.position:2*track.length-state.position)+speed,2*track.length);state.position=phase<=track.length?phase:2*track.length-phase;state.direction=phase<track.length?1:-1;}
   }
   Object.assign(state,pose(state));state.vx=state.grip.x-oldGrip.x;state.vy=state.grip.y-oldGrip.y;
   if(state.held){
    if(!seen.has(state.held.actor)||!body(state.held.actor)){release(state,'actor-unavailable',{constrainPose:false});continue;}
    const actor=state.held.actor,blocker=obstruction({x:actor.x,y:actor.y,w:actor.w,h:actor.h},poseFor(state,actor),terrain);
    if(blocker){actor.vx=state.vx;actor.vy=state.vy;release(state,'terrain-blocked',{constrainPose:false,blockerId:blocker.id});continue;}
    constrain(state);
    if(state.held.kind!=='player'&&belowSensor(player,state))release(state,'player-below');
   }
  }
  // Resolve simultaneous real overlaps by proximity, then stable IDs. No claw
  // or actor priority and no level-specific relay or target selection.
  const candidates=[];
  for(const state of states)if(!state.held)for(const actor of actors){
   if(held(actor.actor)||!eligible(actor.actor,actor.kind)||(releasedThisFrame.get(actor.actor)??-1)>=frame||(cooldowns.get(actor.actor)?.get(state.spec.id)??-1)>frame||!gripContact(state.grip,actor.actor,state.spec.catchRadius)||obstruction({x:actor.actor.x,y:actor.actor.y,w:actor.actor.w,h:actor.actor.h},poseFor(state,actor.actor),terrain))continue;
   candidates.push({state,...actor,distance:(actor.actor.x+actor.actor.w/2-state.grip.x)**2+(actor.actor.y+actor.actor.h/2-state.grip.y)**2});
  }
  candidates.sort((a,b)=>a.distance-b.distance||compare(a.state.spec.id,b.state.spec.id)||compare(a.id,b.id));
  for(const candidate of candidates){const {state,actor,id,kind}=candidate;if(state.held||held(actor))continue;state.held={actor,id,kind};holders.set(actor,state);if(kind==='player')beginPlayerSwing(state);constrain(state);diagnostic('capture',{clawId:state.spec.id,actorId:id,actorKind:kind,position:{x:actor.x,y:actor.y},grip:{...state.grip},velocity:{x:actor.vx,y:actor.vy}});}
  return true;
 }
 function view(){return {version:1,approximation:true,tick:currentTick,frame,tracks:[...tracks.values()].map(q=>({...copy(q.spec),length:q.length,points:copy(q.points)})),claws:states.map(state=>({...copy(state.spec),position:state.position,direction:state.direction,anchor:{...state.anchor},grip:{...state.grip},tangent:{...state.tangent},angleRadians:state.angleRadians,vx:state.vx,vy:state.vy,heldId:state.held?.id??null,heldKind:state.held?.kind??null,...(state.swing?{playerSwingState:{approximation:true,model:'local-driven-pendulum',active:state.swing.active,angleDegrees:state.angleRadians/DEG,angularVelocityDegreesPerFrame:state.swing.velocity/DEG}}:{})}))};}
 return Object.freeze({step,held,playerHeld,releasePlayer,view,reset});
}
