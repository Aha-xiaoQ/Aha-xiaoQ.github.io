/** Opt-in player Lakitu Cloud, limited to the observed SMB1 Sky course actions.
 * Every numerical field is explicit local author tuning, not a Nintendo formula.
 * The 20 by 16 image rectangle is independent from terrain/damage collision:
 * mounted terrain solidity belongs to the real native passenger body. Empty
 * clouds hover without asserting unobserved terrain collision faces or armor.
 * The host owns damage, rewards, actual goal contact, native release impulses,
 * and room/death transitions. There is no NPC capture, expiry, or jump ejection.
 * Once the host reports real goal contact via disembark({reason:'goal'}), that
 * same cloud becomes spent/invisible, matching the observed flag-contact frame.
 * Hurt and manual release instead leave its visible empty hovering state.
 *
 * Call step before the native player motor, skip that motor while ownsPlayer(p),
 * and call sync after the unowned motor. Each consumes its own tick once; only
 * step travels. view/contactBody are pure frozen projections. Boarding requires
 * a recorded prior pose and descending top crossing, with swept path and seat
 * clearance. boardTolerance is minimum horizontal overlap at that crossing;
 * it cannot turn a side/below approach into a top contact. Room bounds contain
 * both sprite and passenger; terrain tests use only the native passenger body.
 */
export const LAKITU_CLOUD_VERSION=1;
const EPS=1e-7;
const fields=['id','x','y','w','h','acceleration','maxSpeed','drag','seatOffsetY','boardTolerance','hoverAmplitude','hoverPeriodFrames'];
const fail=message=>{throw Error(message);};
const finite=(value,min,max)=>Number.isFinite(value)&&value>=min&&value<=max;
const integer=(value,min,max)=>Number.isSafeInteger(value)&&finite(value,min,max);
const unsafe=key=>['__proto__','constructor','prototype'].includes(key);
const plain=value=>value&&typeof value==='object'&&!Array.isArray(value)&&[Object.prototype,null].includes(Object.getPrototypeOf(value));
const clamp=(value,min,max)=>Math.max(min,Math.min(max,value));
const approach=(value,target,amount)=>value+clamp(target-value,-amount,amount);
const rect=value=>value&&['x','y','w','h'].every(key=>Number.isFinite(value[key]))&&value.w>0&&value.h>0;
const live=actor=>!!actor&&!actor.dead&&!actor.dying&&!actor.removed;
const body=actor=>({x:actor.x,y:actor.y,w:actor.w,h:actor.h});
const pose=actor=>({...body(actor),vx:actor.vx??0,vy:actor.vy??0});
const overlap=(a,b)=>a.x+a.w>b.x+EPS&&a.x<b.x+b.w-EPS&&a.y+a.h>b.y+EPS&&a.y<b.y+b.h-EPS;
const seatedBody=(cloud,actor)=>({x:cloud.x+(cloud.w-actor.w)/2,y:cloud.y+cloud.seatOffsetY,w:actor.w,h:actor.h});
const freeze=value=>{if(value&&typeof value==='object'){for(const item of Object.values(value))freeze(item);Object.freeze(value);}return value;};
function object(value,allowed,label){
 if(!plain(value))fail('Invalid '+label);
 for(const key of Reflect.ownKeys(value))if(typeof key!=='string'||unsafe(key)||!allowed.includes(key))fail('Unknown '+label+' field: '+String(key));
 for(const key of allowed)if(!Object.hasOwn(value,key))fail('Missing '+label+' field: '+key);
}
function nativeIds(room){
 const ids=new Set(),visited=new WeakSet();
 function scan(value){
  if(!value||typeof value!=='object'||visited.has(value))return;visited.add(value);
  if(typeof value.id==='string')ids.add(value.id);
  for(const child of Object.values(value))scan(child);
 }
 for(const [key,value]of Object.entries(room)){
  if(key==='smm2Mechanics'){for(const [leaf,child]of Object.entries(value||{}))if(leaf!=='lakituClouds')scan(child);}
  else scan(value);
 }
 return ids;
}

/** Validate this authored leaf only. The enclosing importer validates siblings. */
export function validateLakituClouds(room,spec=room?.smm2Mechanics?.lakituClouds){
 if(spec===undefined)return;
 object(spec,['version','clouds'],'Lakitu Clouds');
 if(spec.version!==LAKITU_CLOUD_VERSION)fail('Unknown Lakitu Clouds version');
 const map=room?.map;
 if(!map||!finite(map.width,20,32768)||!finite(map.height,16,4096)||['geometry','objects'].some(key=>map[key]!==undefined&&!Array.isArray(map[key])))fail('Lakitu Clouds need a bounded native room');
 if(!Array.isArray(spec.clouds)||spec.clouds.length>256)fail('Invalid Lakitu Cloud list');
 const ids=nativeIds(room);
 for(const cloud of spec.clouds){
  object(cloud,fields,'Lakitu Cloud');
  if(typeof cloud.id!=='string'||cloud.id.length>72||!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(cloud.id)||unsafe(cloud.id)||ids.has(cloud.id))fail('Duplicate or invalid Lakitu Cloud ID');ids.add(cloud.id);
  if(cloud.w!==20||cloud.h!==16||!finite(cloud.x,0,map.width-cloud.w)||!finite(cloud.y,0,map.height-cloud.h))fail('Lakitu Cloud must be a 20 by 16 sprite inside the room');
  if(!finite(cloud.acceleration,.000001,64)||!finite(cloud.maxSpeed,.001,256)||!finite(cloud.drag,0,64)||!finite(cloud.seatOffsetY,-64,16)||!finite(cloud.boardTolerance,0,8)||!finite(cloud.hoverAmplitude,0,8)||!integer(cloud.hoverPeriodFrames,16,36000))fail('Invalid explicit Lakitu Cloud motion tuning');
  if(cloud.y-cloud.hoverAmplitude<0||cloud.y+cloud.h+cloud.hoverAmplitude>map.height)fail('Lakitu Cloud hover range is outside the room');
 }
}

/** Continuous entry of a native rectangle, including inward edge contact. */
function entry(from,delta,target){
 if(overlap(from,target))return {fraction:0,embedded:true};
 let near=-Infinity,far=Infinity;
 for(const axis of ['x','y']){
  const size=axis==='x'?'w':'h',amount=delta[axis];
  if(Math.abs(amount)<EPS){if(from[axis]+from[size]<=target[axis]+EPS||from[axis]>=target[axis]+target[size]-EPS)return null;continue;}
  const first=(target[axis]-from[axis]-from[size])/amount,last=(target[axis]+target[size]-from[axis])/amount;
  near=Math.max(near,Math.min(first,last));far=Math.min(far,Math.max(first,last));
  if(near>far+EPS)return null;
 }
 if(near<-EPS||near>1+EPS||far<0)return null;
 return {fraction:clamp(near,0,1),embedded:false};
}
function colliders(geometry){return geometry.filter(q=>!q.hidden&&rect(q)&&['solid','oneway'].includes(q.collision));}
function blockedPath(from,to,geometry){
 const delta={x:to.x-from.x,y:to.y-from.y};
 for(const q of colliders(geometry)){
  if(q.collision==='oneway'&&(delta.y<=EPS||from.y+from.h>q.y+EPS))continue;
  const hit=entry(from,delta,q);
  if(hit&&(hit.embedded||hit.fraction<1-EPS))return true;
  if(q.collision==='solid'&&overlap(to,q))return true;
 }
 return false;
}

export function createLakituClouds(room,{emit=()=>{}}={}){
 validateLakituClouds(room);
 const extension=room?.smm2Mechanics?.lakituClouds;
 if(!extension?.clouds.length)return null;
 if(typeof emit!=='function')fail('Lakitu Clouds emit must be a function');
 const authored=structuredClone(extension.clouds),width=room.map.width,height=room.map.height,roomId=room.roomId;
 let clouds=[],poses=new WeakMap(),clock=0,lastStep=null,lastSync=null,context={player:null,input:{},geometry:[]};
 const ownsPlayer=actor=>clouds.some(cloud=>cloud.occupant&&live(cloud.occupant)&&(actor===undefined||cloud.occupant===actor));
 const owned=actor=>clouds.find(cloud=>cloud.occupant===actor&&live(actor));
 function diagnostic(event,cloud,actor,extra={}){emit('lakitu-cloud',{event,roomId,cloudId:cloud.id,actorId:actor?'player':null,tick:clock,occupancy:cloud.occupant?'player':'empty',spent:cloud.spent,visible:!cloud.spent,x:cloud.x,y:cloud.y,...(actor?{actor:pose(actor)}:{}),...extra});}
 function seat(cloud){
  const actor=cloud.occupant;if(!actor)return;
  Object.assign(actor,seatedBody(cloud,actor),{vx:cloud.vx,vy:cloud.vy,grounded:false,support:null,lakituCloudId:cloud.id,vehicleId:cloud.id,crouch:false,jumpBuffer:0,onVine:false,springId:null});
 }
 function vacate(cloud,event,reason){
  const actor=cloud.occupant;if(!actor)return;
  if(actor.lakituCloudId===cloud.id)delete actor.lakituCloudId;
  if(actor.vehicleId===cloud.id)delete actor.vehicleId;
  if(reason==='goal')cloud.spent=true;
  cloud.occupant=null;cloud.hoverY=cloud.y;cloud.hoverFrames=0;cloud.vx=cloud.vy=0;cloud.reentryPlayer=actor;
  diagnostic(event,cloud,actor,{reason});
 }
 function remember(actor){if(rect(actor))poses.set(actor,{...pose(actor),clouds:new Map(clouds.map(cloud=>[cloud.id,{x:cloud.x,y:cloud.y}]))});}
 function inside(candidate){return candidate.x>=-EPS&&candidate.y>=-EPS&&candidate.x+candidate.w<=width+EPS&&candidate.y+candidate.h<=height+EPS;}
 function candidateBoard(cloud,actor,geometry){
  if(cloud.spent||!live(actor)||!rect(actor)||ownsPlayer(actor)||actor.vehicleId||actor.lakituCloudId||actor.clawHeld||actor.clawId||actor.clawHeldBy||actor.heldByClaw||actor.onVine||actor.springId)return null;
  const before=poses.get(actor),oldCloud=before?.clouds.get(cloud.id);if(!before||!oldCloud||before.w!==actor.w||before.h!==actor.h||actor.y<=before.y+EPS)return null;
  if(cloud.reentryPlayer===actor){
   if(before.y+before.h<oldCloud.y-EPS||before.x+before.w<=oldCloud.x+EPS||before.x>=oldCloud.x+cloud.w-EPS||actor.y+actor.h<cloud.y-EPS||actor.x+actor.w<=cloud.x+EPS||actor.x>=cloud.x+cloud.w-EPS)cloud.reentryPlayer=null;
   else return null;
  }
  const oldBottom=before.y+before.h,bottom=actor.y+actor.h,oldGap=oldBottom-oldCloud.y,newGap=bottom-cloud.y;
  if(oldGap>EPS||newGap<-EPS||newGap-oldGap<=EPS)return null;
  const fraction=clamp(-oldGap/(newGap-oldGap),0,1),contact={x:before.x+(actor.x-before.x)*fraction,y:before.y+(actor.y-before.y)*fraction,w:actor.w,h:actor.h};
  const cloudX=oldCloud.x+(cloud.x-oldCloud.x)*fraction,span=Math.min(contact.x+contact.w,cloudX+cloud.w)-Math.max(contact.x,cloudX);
  if(span<=EPS||span+EPS<cloud.boardTolerance)return null;
  const target=seatedBody(cloud,actor);
  if(!inside(target)||blockedPath(before,contact,geometry)||blockedPath(contact,target,geometry))return null;
  return {cloud,fraction};
 }
 function reconcile(){
  const {player,geometry}=context;
  for(const cloud of clouds)if(cloud.occupant){
   if(cloud.occupant!==player||!live(cloud.occupant))vacate(cloud,'vacancy',cloud.occupant.dead?'occupant-dead':cloud.occupant.dying?'occupant-dying':'occupant-left');
   else seat(cloud);
  }
  if(player&&!ownsPlayer(player)){
   const candidate=clouds.filter(cloud=>!cloud.spent&&!cloud.occupant).map(cloud=>candidateBoard(cloud,player,geometry)).filter(Boolean).sort((a,b)=>a.fraction-b.fraction)[0];
   if(candidate){const cloud=candidate.cloud;cloud.occupant=player;cloud.vx=cloud.vy=0;cloud.hoverFrames=0;cloud.reentryPlayer=null;seat(cloud);diagnostic('board',cloud,player);}
  }
 }
 function tick(value,fallback){if(value===undefined)return fallback;if(!integer(value,0,Number.MAX_SAFE_INTEGER))fail('Invalid Lakitu Cloud tick');return value;}
 function nextContext(next){
  if(next.player!==undefined&&next.player!==null&&!rect(next.player))fail('Invalid native Lakitu Cloud passenger body');
  if(next.geometry!==undefined&&!Array.isArray(next.geometry))fail('Invalid Lakitu Cloud geometry');
  if(next.input!==undefined&&!plain(next.input))fail('Invalid Lakitu Cloud input');
  return {...context,...next};
 }
 function sweep(cloud,axis,delta,geometry){
  const actor=cloud.occupant,from=seatedBody(cloud,actor);let travel=delta,hit=false;
  if(Math.abs(delta)>EPS)for(const q of colliders(geometry)){
   if(q.collision==='oneway'&&(axis!=='y'||delta<0||from.y+from.h>q.y+EPS))continue;
   const transverse=axis==='x'?from.y+from.h>q.y+EPS&&from.y<q.y+q.h-EPS:from.x+from.w>q.x+EPS&&from.x<q.x+q.w-EPS;if(!transverse)continue;
   const size=axis==='x'?'w':'h',start=from[axis],edge=q[axis],extent=q[size];
   if(delta>0&&start+from[size]<=edge+EPS&&start+from[size]+travel>edge){travel=Math.max(0,edge-start-from[size]);hit=true;}
   else if(delta<0&&start>=edge+extent-EPS&&start+travel<edge+extent){travel=Math.min(0,edge+extent-start);hit=true;}
  }
  const size=axis==='x'?'w':'h',limit=axis==='x'?width:height,min=-Math.min(cloud[axis],from[axis]),max=limit-Math.max(cloud[axis]+cloud[size],from[axis]+from[size]),bounded=clamp(travel,min,max);
  if(Math.abs(bounded-travel)>EPS)hit=true;
  cloud[axis]+=bounded;if(hit)cloud[axis==='x'?'vx':'vy']=0;return bounded;
 }
 function sync(next={}){
  const now=tick(next.tick,clock);if(now<clock||lastSync!==null&&now<=lastSync)return view();
  const pending=nextContext(next);clock=now;lastSync=now;context=pending;reconcile();remember(context.player);return view();
 }
 function step(next={}){
  const now=tick(next.tick,clock+1);if(now<clock||lastStep!==null&&now<=lastStep)return view();
  const pending=nextContext(next);clock=now;lastStep=now;context=pending;reconcile();
  const {input={},geometry}=context;
  for(const cloud of clouds){
   if(cloud.spent)continue;
   if(cloud.occupant){
    const x=clamp(Number(input.x)||0,-1,1),y=Number.isFinite(input.y)?clamp(input.y,-1,1):Number(!!input.down)-Number(!!input.up);
    cloud.vx=approach(cloud.vx,x*cloud.maxSpeed,x?cloud.acceleration:cloud.drag);cloud.vy=approach(cloud.vy,y*cloud.maxSpeed,y?cloud.acceleration:cloud.drag);
    sweep(cloud,'x',cloud.vx,geometry);sweep(cloud,'y',cloud.vy,geometry);seat(cloud);if(x)cloud.occupant.facing=Math.sign(x);
   }else{
    cloud.hoverFrames++;const before=cloud.y;cloud.y=clamp(cloud.hoverY+Math.sin(cloud.hoverFrames*Math.PI*2/cloud.hoverPeriodFrames)*cloud.hoverAmplitude,0,height-cloud.h);cloud.vx=0;cloud.vy=cloud.y-before;
   }
  }
  remember(context.player);return view();
 }
 function contactBody(actor){const cloud=actor===undefined?clouds.find(q=>q.occupant&&live(q.occupant)):owned(actor);return cloud?freeze(body(cloud.occupant)):null;}
 function disembark(actor,options={reason:'manual'}){
  if(!plain(options)||Reflect.ownKeys(options).some(key=>key!=='reason')||!['hurt','goal','manual'].includes(options.reason))fail('Invalid Lakitu Cloud disembark options');
  const cloud=clouds.find(q=>q.occupant===actor);if(!cloud)return false;
  vacate(cloud,'disembark',options.reason);remember(actor);return true;
 }
 function view(){return freeze({version:LAKITU_CLOUD_VERSION,approximation:true,tuningStatus:'explicit-author-configuration',collisionPolicy:'native-passenger-body',clouds:clouds.map(cloud=>{const {occupant,hoverY,hoverFrames,reentryPlayer,...data}=cloud;return {...data,visible:!cloud.spent,occupancy:occupant?'player':'empty',occupantId:occupant?'player':null,occupant:occupant?{id:'player',type:'player',...pose(occupant)}:null,opening:{x:cloud.x,y:cloud.y,w:cloud.w,h:1},contactBody:occupant?body(occupant):null};})});}
 function reset(){
  for(const cloud of clouds){const actor=cloud.occupant;if(actor?.lakituCloudId===cloud.id)delete actor.lakituCloudId;if(actor?.vehicleId===cloud.id)delete actor.vehicleId;}
  clouds=authored.map(cloud=>({...cloud,vx:0,vy:0,spent:false,occupant:null,hoverY:cloud.y,hoverFrames:0,reentryPlayer:null}));poses=new WeakMap();clock=0;lastStep=lastSync=null;context={player:null,input:{},geometry:[]};
 }
 reset();return Object.freeze({step,sync,ownsPlayer,contactBody,disembark,view,reset});
}
