/** Opt-in SMM2 Thwomp motion. Every numeric setting is an authored approximation.
 * Uses real native walker bodies and current rectangular/actual shaped terrain;
 * no rewards, combat, automatic destruction, room scripts or Mario motor. */
const EPS=1e-9,OWNER=Symbol('smm2-thwomp-controller');
const fields=['id','direction','triggerRange','transverseTolerance','leadReference','windupFrames','chargeAcceleration','chargeSpeedCap','impactWaitFrames','returnSpeed','breakMaterials'];
const optionalFields=['oneWaySupportIds','winged','mass'];
const finite=(v,min,max)=>Number.isFinite(v)&&v>=min&&v<=max;
const integer=(v,min,max)=>Number.isSafeInteger(v)&&finite(v,min,max);
const unsafe=key=>['__proto__','constructor','prototype'].includes(key);
const plain=v=>v&&typeof v==='object'&&!Array.isArray(v)&&[Object.prototype,null].includes(Object.getPrototypeOf(v));
const safeId=v=>typeof v==='string'&&v.length>0&&v.length<=128&&!/[\u0000-\u001f\u007f]/.test(v)&&!unsafe(v);
const fail=message=>{throw Error(message);};
const copy=v=>structuredClone(v);
const body=v=>v&&['x','y','w','h'].every(k=>Number.isFinite(v[k]))&&v.w>0&&v.h>0;
const alive=v=>v&&!v.dead&&!v.dying&&!v.removed;
const overlap=(a,b)=>a.x<b.x+b.w-EPS&&a.x+a.w>b.x+EPS&&a.y<b.y+b.h-EPS&&a.y+a.h>b.y+EPS;
const clamp=(v,min,max)=>Math.max(min,Math.min(max,v));
const vector=direction=>direction==='down'?{x:0,y:1}:direction==='left'?{x:-1,y:0}:{x:1,y:0};
const compare=(a,b)=>a===b?0:a<b?-1:1;
function object(v,allowed,label){if(!plain(v))fail('Invalid '+label);for(const k of Object.keys(v))if(!allowed.includes(k))fail('Unknown '+label+' field: '+k);}

/** Deliberately unresolved: host must intercept generic walker/Goomba combat. */
export const SMM2_THWOMP_COMBAT_POLICY=Object.freeze({playerBody:'unverified',stomp:'unverified',shell:'unverified',fire:'unverified',star:'unverified',helmet:'unverified',spikeFace:'unverified'});
/** Validates only version/Thwomp leaf. Root sibling validation belongs to importer. */
export function validateSmm2ThwompsRoom(room,spec=room?.smm2Mechanics){
 if(spec===undefined)return;
 if(!plain(spec))fail('Invalid SMM2 mechanics');
 if(Object.keys(spec).some(unsafe))fail('Unsafe SMM2 mechanics field');
 if(spec.version!==1)fail('Unknown SMM2 mechanics version');
 if(spec.thwomps===undefined)return;
 if(!Array.isArray(spec.thwomps)||spec.thwomps.length>256)fail('Invalid SMM2 Thwomp list');
 const map=room?.map;
 if(!map||!finite(map.width,1,32768)||!finite(map.height,1,4096)||!Array.isArray(map.objects))fail('SMM2 Thwomps need valid native room bounds and objects');
 const seen=new Set();
 for(const q of spec.thwomps){
  object(q,[...fields,...optionalFields],'SMM2 Thwomp');for(const k of fields)if(!Object.hasOwn(q,k))fail('Missing SMM2 Thwomp field: '+k);
  if(!safeId(q.id)||seen.has(q.id))fail('Duplicate or invalid SMM2 Thwomp ID');seen.add(q.id);
  const matches=map.objects.filter(a=>a.id===q.id),a=matches[0];
  if(matches.length!==1||a.kind!=='walker'||!body(a)||!finite(a.x,0,map.width-a.w)||!finite(a.y,0,map.height-a.h))fail('SMM2 Thwomp needs one existing native walker body inside the room');
  if(!['down','left','right'].includes(q.direction))fail('Invalid SMM2 Thwomp direction');
  if(!['center','near-edge'].includes(q.leadReference))fail('Invalid SMM2 Thwomp lead reference');
  if(!finite(q.triggerRange,0,4096)||!finite(q.transverseTolerance,0,512)||!integer(q.windupFrames,0,600)||!finite(q.chargeAcceleration,.001,64)||!finite(q.chargeSpeedCap,.001,256)||!integer(q.impactWaitFrames,0,36000)||!finite(q.returnSpeed,.001,256))fail('Invalid SMM2 Thwomp authored sensor, timing or motion values');
  if(!Array.isArray(q.breakMaterials)||q.breakMaterials.length>1||q.breakMaterials.some(m=>m!=='brick'))fail('SMM2 Thwomp break materials must be [] or ["brick"]');
  if(q.oneWaySupportIds!==undefined&&(!Array.isArray(q.oneWaySupportIds)||q.oneWaySupportIds.length>256||q.oneWaySupportIds.some(id=>!safeId(id))||new Set(q.oneWaySupportIds).size!==q.oneWaySupportIds.length))fail('Invalid SMM2 Thwomp named one-way supports');
  if(q.winged!==undefined&&typeof q.winged!=='boolean')fail('Invalid SMM2 Thwomp winged render flag');
  if(q.mass!==undefined&&!finite(q.mass,.001,10000))fail('Invalid SMM2 Thwomp authored mass');
 }
}
function perceived(actor,player,spec){
 if(!alive(player)||!body(player))return false;
 const d=vector(spec.direction),vertical=d.y!==0,lead=vertical?actor.y+actor.h:d.x>0?actor.x+actor.w:actor.x;
 const reference=spec.leadReference==='center'?(vertical?player.y+player.h/2:player.x+player.w/2):(vertical?player.y:d.x>0?player.x:player.x+player.w);
 const distance=(reference-lead)*(vertical?d.y:d.x),a=vertical?actor.x:actor.y,as=vertical?actor.w:actor.h,p=vertical?player.x:player.y,ps=vertical?player.w:player.h;
 return distance>=-EPS&&distance<=spec.triggerRange+EPS&&p+ps>=a-spec.transverseTolerance-EPS&&p<=a+as+spec.transverseTolerance+EPS;
}
const terrainFor=(geometry,oneWayIds)=>geometry.filter(q=>body(q)&&!q.hidden&&q.visible!==false&&!q.removed&&!q.dead&&(q.collision==='solid'||q.collision==='oneway'&&oneWayIds?.has(q.id)));
function slab(position,delta,min,max){if(Math.abs(delta)<=EPS)return position>min+EPS&&position<max-EPS?{entry:-Infinity,exit:Infinity}:null;const a=(min-position)/delta,b=(max-position)/delta;return {entry:Math.min(a,b),exit:Math.max(a,b)};}
function terrainOrder(a,b){return compare(String(a.id??''),String(b.id??''))||a.x-b.x||a.y-b.y||a.w-b.w||a.h-b.h;}
/** Continuous swept AABB. Moving-away boundaries/corner grazes are not hits. */
function sweep(actor,delta,terrain){
 let nearest=null;
 for(const solid of terrain){
  if(solid.collision==='oneway'){
   // Explicitly named tops only: a true descending crossing, never side or
   // underside walls. Horizontal charges cannot opt into this policy.
   const bottom=actor.y+actor.h;if(delta.y<=EPS||bottom>solid.y+EPS||bottom+delta.y<solid.y-EPS)continue;
   const fraction=clamp((solid.y-bottom)/delta.y,0,1),x=actor.x+delta.x*fraction;
   if(x+actor.w<=solid.x+EPS||x>=solid.x+solid.w-EPS)continue;
   if(!nearest||fraction<nearest.fraction-EPS||Math.abs(fraction-nearest.fraction)<=EPS&&terrainOrder(solid,nearest.solid)<0)nearest={solid,fraction,normal:{x:0,y:-1},embedded:false};
   continue;
  }
  const x=slab(actor.x,delta.x,solid.x-actor.w,solid.x+solid.w),y=slab(actor.y,delta.y,solid.y-actor.h,solid.y+solid.h);if(!x||!y)continue;
  const entry=Math.max(x.entry,y.entry),exit=Math.min(x.exit,y.exit),embedded=overlap(actor,solid);
  if(!embedded&&(entry<-EPS||entry>1+EPS||exit<=Math.max(0,entry)+EPS))continue;
  const fraction=embedded?0:clamp(entry,0,1),normal=embedded?(Math.abs(delta.y)>=Math.abs(delta.x)?{x:0,y:-Math.sign(delta.y)}:{x:-Math.sign(delta.x),y:0}):x.entry>y.entry?{x:-Math.sign(delta.x),y:0}:{x:0,y:-Math.sign(delta.y)};
  if(!nearest||fraction<nearest.fraction-EPS||Math.abs(fraction-nearest.fraction)<=EPS&&terrainOrder(solid,nearest.solid)<0)nearest={solid,fraction,normal,embedded};
 }return nearest;
}
function contactRecord(actor,delta,hit,tick,incomingVelocity=delta){
 const at={x:actor.x+delta.x*hit.fraction,y:actor.y+delta.y*hit.fraction,w:actor.w,h:actor.h},q=hit.solid,n=hit.normal;
 return {solidId:q.id??null,material:typeof q.material==='string'?q.material:null,tick,fraction:hit.fraction,normal:{...n},point:{x:n.x<0?at.x+at.w:n.x>0?at.x:clamp(at.x+at.w/2,q.x,q.x+q.w),y:n.y<0?at.y+at.h:n.y>0?at.y:clamp(at.y+at.h/2,q.y,q.y+q.h)},body:at,incomingVelocity:{...incomingVelocity},embedded:hit.embedded,terrainKind:'rectangle'};
}
function applyMove(actor,delta,fraction=1){actor.x+=delta.x*fraction;actor.y+=delta.y*fraction;actor.vx=delta.x*fraction;actor.vy=delta.y*fraction;actor.grounded=false;actor.support=null;}
const stopped=(actor,contact=null)=>{actor.vx=0;actor.vy=0;actor.grounded=!!contact&&contact.normal?.y<0;actor.support=actor.grounded?contact.solidId:null;};

/** State belongs to room-owned native actors. Host skips their ordinary motor. */
export function createSmm2Thwomps(room,{emit=()=>{},terrain=null}={}){
 validateSmm2ThwompsRoom(room);
 const definitions=new Map((room?.smm2Mechanics?.thwomps||[]).map(q=>[q.id,copy(q)]));if(!definitions.size)return null;
 if(typeof emit!=='function')fail('Invalid SMM2 Thwomp emitter');
 if(terrain!==null&&(!terrain||typeof terrain.sweep!=='function'||typeof terrain.support!=='function'||typeof terrain.recordImpact!=='function'))fail('SMM2 Thwomp shaped terrain needs sweep, support and recordImpact');
 const owner={};
 function ownsActor(actor){return !!actor&&definitions.has(actor.id);}
 function decorateEnemy(actor){
  if(!ownsActor(actor))return actor;if(!body(actor))fail('Invalid live SMM2 Thwomp body');if(actor.smm2Thwomp?.[OWNER]===owner)return actor;
  const spec=definitions.get(actor.id),state={version:1,id:actor.id,direction:spec.direction,home:{x:actor.x,y:actor.y,w:actor.w,h:actor.h},phase:'idle',remaining:0,speed:0,lastTick:null,contact:null,returnBlocked:null,lastMotion:null,returnRequestedTick:null,returnReason:null};
  Object.defineProperty(state,OWNER,{value:owner});actor.smm2Thwomp=state;actor.type='smm2-thwomp';if(spec.winged!==undefined)actor.winged=spec.winged;if(spec.mass!==undefined)actor.smm2Mass=spec.mass;stopped(actor);return actor;
 }
 function event(actor,tick,name,data={}){emit('smm2-thwomp',{event:name,actorId:actor.id,tick,direction:definitions.get(actor.id).direction,...copy(data)});}
 /** Host supplies the verified helmetContact head leaf. This validates its
  * actual owned underside, changes only return state, and never defeats or
  * relocates an actor. Requests cannot move until a later normal tick. */
 function requestReturn(actor,{tick,contact}={}){
  if(!ownsActor(actor))return false;
  if(!integer(tick,0,Number.MAX_SAFE_INTEGER))fail('Invalid SMM2 Thwomp return tick');
  const state=actor.smm2Thwomp;
  if(!alive(actor)||!body(actor)||actor.type!=='smm2-thwomp'||state?.[OWNER]!==owner||!['windup','charge','impact'].includes(state.phase)||state.lastTick===null||tick<state.lastTick||tick>state.lastTick+1)return false;
  if(!plain(contact)||Object.keys(contact).some(k=>!['kind','fraction','normal','point','relativeMotion','nativeHeadHit'].includes(k))||contact.kind!=='head'||!finite(contact.fraction,0,1)||typeof contact.nativeHeadHit!=='boolean')return false;
  const xy=v=>plain(v)&&Object.keys(v).every(k=>['x','y'].includes(k))&&['x','y'].every(k=>Number.isFinite(v[k]));
  if(!xy(contact.normal)||contact.normal.x!==0||contact.normal.y!==1||!xy(contact.point)||!xy(contact.relativeMotion)||!finite(contact.relativeMotion.x,-32768,32768)||!finite(contact.relativeMotion.y,-32768,-EPS))return false;
  const now={x:actor.x,y:actor.y,w:actor.w,h:actor.h},motion=tick===state.lastTick?state.lastMotion:null;
  if(motion&&(['x','y','w','h'].some(k=>Math.abs(now[k]-motion.to[k])>1e-6)||motion.tick!==tick))return false;
  const from=motion?.from??now,to=motion?.to??now,fraction=contact.fraction,x=from.x+(to.x-from.x)*fraction,y=from.y+from.h+(to.y+to.h-from.y-from.h)*fraction;
  if(contact.point.x<x-1.01||contact.point.x>x+now.w+1.01||Math.abs(contact.point.y-y)>1.01)return false;
  state.phase='return';state.remaining=0;state.speed=0;state.contact=null;state.returnBlocked=null;state.returnRequestedTick=tick;state.returnReason='buzzy-head-bonk';stopped(actor);terrain?.clearActorContact?.(actor);
  event(actor,tick,'return',{reason:state.returnReason,requested:true,contact});return true;
 }
 function stepEnemy(actor,{tick,player,geometry=[],getGeometry=()=>geometry,breakSolid=null}={}){
  if(!ownsActor(actor))return false;
  if(!integer(tick,0,Number.MAX_SAFE_INTEGER))fail('Invalid SMM2 Thwomp tick');
  if(!Array.isArray(geometry)||geometry.length>20000)fail('Invalid live SMM2 Thwomp geometry');
  if(typeof getGeometry!=='function'||breakSolid!==null&&typeof breakSolid!=='function')fail('Invalid SMM2 Thwomp live terrain callbacks');
  if(!alive(actor))return {handled:true,advanced:false,unavailable:true};decorateEnemy(actor);
  const state=actor.smm2Thwomp,spec=definitions.get(actor.id);
  if(state.lastTick!==null&&tick<=state.lastTick)return {handled:true,advanced:false,phase:state.phase};state.lastTick=tick;
  const frameStart={x:actor.x,y:actor.y,w:actor.w,h:actor.h},result={handled:true,advanced:true,phase:state.phase},d=vector(spec.direction),oneWayIds=new Set(spec.direction==='down'?(spec.oneWaySupportIds||[]):[]);
  const readTerrain=()=>{const current=getGeometry();if(!Array.isArray(current)||current.length>20000)fail('Invalid live SMM2 Thwomp geometry');return terrainFor(current,oneWayIds).filter(q=>!terrain?.ownsGeometry?.(q));};
  stopped(actor);
  if(state.phase==='idle'){if(perceived(actor,player,spec)){state.phase='windup';state.remaining=spec.windupFrames;event(actor,tick,'trigger');}}
  else if(state.phase==='windup'){if(state.remaining>0)state.remaining--;else{state.phase='charge';event(actor,tick,'charge');charge();}}
  else if(state.phase==='charge')charge();
  else if(state.phase==='impact'){
   const current=currentSupport();
   if(!current){state.contact=null;state.remaining=0;state.speed=0;state.phase='charge';terrain?.clearActorContact?.(actor);event(actor,tick,'support-lost');}
   else if(state.remaining>0)state.remaining--;
   else{state.phase='return';state.speed=0;state.contact=null;state.returnReason='terrain-impact';terrain?.clearActorContact?.(actor);event(actor,tick,'return',{reason:state.returnReason});returnHome();}
  }else if(state.phase==='return'){if(state.returnRequestedTick===null||tick>state.returnRequestedTick)returnHome();}else fail('Invalid live SMM2 Thwomp phase');
  state.lastMotion={tick,from:frameStart,to:{x:actor.x,y:actor.y,w:actor.w,h:actor.h}};result.phase=state.phase;return result;
  function normalizeShape(contact,delta,incomingVelocity){
   if(!plain(contact)||!finite(contact.fraction,0,1)||!safeId(contact.solidId)||!contact.normal||!['x','y'].every(k=>finite(contact.normal[k],-1,1))||!finite(Math.hypot(contact.normal.x,contact.normal.y),.999999,1.000001)||!contact.point||!['x','y'].every(k=>Number.isFinite(contact.point[k])))fail('Invalid SMM2 Thwomp shaped terrain contact');
   const expected={x:actor.x+delta.x*contact.fraction,y:actor.y+delta.y*contact.fraction,w:actor.w,h:actor.h};
   if(contact.surfaceMotion){
    if(spec.direction!=='down'||delta.x!==0||delta.y<=EPS||!body(contact.body)||contact.body.w!==actor.w||contact.body.h!==actor.h||typeof terrain.validateMovingTopContact!=='function'||terrain.validateMovingTopContact(actor,delta,contact,{tick})!==true)fail('Invalid measured SMM2 Thwomp moving-top contact');
    const motion=contact.surfaceMotion;if(!plain(motion)||motion.kind!=='seesaw-top'||!body(motion.contactBody)||['x','y','w','h'].some(k=>Math.abs(motion.contactBody[k]-expected[k])>1e-6)||!plain(motion.displacement)||motion.displacement.x!==0||!finite(motion.displacement.y,-32768,0)||Math.abs(contact.body.x-expected.x)>1e-6||Math.abs(contact.body.y-expected.y-motion.displacement.y)>1e-6||contact.fraction<=0)fail('Invalid measured SMM2 Thwomp moving-top body displacement');
    return {fraction:contact.fraction,record:{solidId:contact.solidId,material:typeof contact.material==='string'?contact.material:null,tick,fraction:contact.fraction,normal:{...contact.normal},point:{...contact.point},body:{...contact.body},incomingVelocity:{...incomingVelocity},embedded:false,terrainKind:'shaped',surfaceMotion:copy(motion)}};
   }
   if(contact.body&&(!body(contact.body)||contact.body.w!==actor.w||contact.body.h!==actor.h||Math.abs(contact.body.x-expected.x)>1e-6||Math.abs(contact.body.y-expected.y)>1e-6))fail('SMM2 Thwomp shaped sweep must preserve the actual body and swept position');
   return {fraction:contact.fraction,record:{solidId:contact.solidId,material:typeof contact.material==='string'?contact.material:null,tick,fraction:contact.fraction,normal:{...contact.normal},point:{...contact.point},body:expected,incomingVelocity:{...incomingVelocity},embedded:!!contact.embedded,terrainKind:'shaped'}};
  }
  function nearest(delta,phase,incomingVelocity=delta){
   const rectangular=sweep(actor,delta,readTerrain()),shape=terrain?.sweep(actor,delta,{tick,direction:spec.direction,phase,movingTop:phase==='charge'&&spec.direction==='down'}),shaped=shape?normalizeShape(shape,delta,incomingVelocity):null;
   const rectangle=rectangular?{...rectangular,record:contactRecord(actor,delta,rectangular,tick,incomingVelocity)}:null;
   if(!shaped)return rectangle;if(!rectangle)return shaped;
   return shaped.fraction<rectangle.fraction-EPS||Math.abs(shaped.fraction-rectangle.fraction)<=EPS&&compare(shaped.record.solidId,String(rectangle.record.solidId??''))<0?shaped:rectangle;
  }
  function currentSupport(){
   const previous=state.contact;
   if(previous?.terrainKind==='rectangle'&&oneWayIds.has(previous.solidId)){
    const top=readTerrain().find(q=>q.id===previous.solidId&&q.collision==='oneway');
    if(top&&actor.x+actor.w>top.x+EPS&&actor.x<top.x+top.w-EPS&&Math.abs(actor.y+actor.h-previous.point.y)<=1e-6){
     const delta={x:0,y:top.y-actor.h-actor.y},obstruction=Math.abs(delta.y)>EPS?sweep(actor,delta,readTerrain()):null,blocked=obstruction?contactRecord(actor,delta,obstruction,tick):null;
     applyMove(actor,delta,obstruction?.fraction??1);stopped(actor);
     if(obstruction&&obstruction.fraction<1-EPS){result.blocked=blocked;return null;}
     state.contact={...previous,tick,point:{x:clamp(actor.x+actor.w/2,top.x,top.x+top.w),y:top.y},body:{x:actor.x,y:actor.y,w:actor.w,h:actor.h}};stopped(actor,state.contact);return state.contact;
    }
   }
   if(state.contact?.terrainKind==='shaped'){
    const support=terrain?.support(actor,copy(state.contact),{tick,direction:spec.direction});
    if(support){
     if(!plain(support)||support.solidId!==state.contact.solidId||support.body&&(!body(support.body)||support.body.w!==actor.w||support.body.h!==actor.h))fail('Invalid current SMM2 Thwomp shaped support');
     if(support.normal&&(!['x','y'].every(k=>finite(support.normal[k],-1,1))||!finite(Math.hypot(support.normal.x,support.normal.y),.999999,1.000001))||support.point&&!['x','y'].every(k=>Number.isFinite(support.point[k])))fail('Invalid current SMM2 Thwomp shaped support normal or point');
     if(support.body){
      const delta={x:support.body.x-actor.x,y:support.body.y-actor.y},obstruction=Math.hypot(delta.x,delta.y)>EPS?sweep(actor,delta,readTerrain()):null,blocked=obstruction?contactRecord(actor,delta,obstruction,tick):null;
      applyMove(actor,delta,obstruction?.fraction??1);stopped(actor);if(obstruction&&obstruction.fraction<1-EPS){result.blocked=blocked;return null;}
     }
     // The measured sweep belongs to the initial impact event. A later live
     // support pose must not retain that earlier crossing/body certificate.
     const liveContact={...state.contact};delete liveContact.surfaceMotion;
     state.contact={...liveContact,point:support.point?{...support.point}:state.contact.point,normal:support.normal?{...support.normal}:state.contact.normal,body:{x:actor.x,y:actor.y,w:actor.w,h:actor.h}};stopped(actor,state.contact);return support;
    }
   }
   const hit=nearest({x:d.x*.001,y:d.y*.001},'impact');if(!hit||hit.fraction>EPS)return null;state.contact=hit.record;stopped(actor,state.contact);return hit.record;
  }
  function breakable(solid){
   if(!solid||solid.collision!=='solid'||!spec.breakMaterials.includes(solid.material)||solid.used||solid.reward||solid.contents||solid.source?.contents)return false;
   const original=room.map.objects.find(q=>q.id===solid.id)||room.map.geometry?.find(q=>q.id===(solid.sourceId||solid.id));
   return !original?.used&&!original?.reward&&!original?.contents&&!original?.source?.contents&&!(room.markers||[]).some(m=>(m.id===solid.id||m.id===solid.sourceId)&&m.source?.contents);
  }
  function charge(){
   state.speed=Math.min(spec.chargeSpeedCap,state.speed+spec.chargeAcceleration);
   const velocity={x:d.x*state.speed,y:d.y*state.speed},start={x:actor.x,y:actor.y};let remaining=1;
   for(let iteration=0;iteration<=256;iteration++){
    const delta={x:velocity.x*remaining,y:velocity.y*remaining},hit=nearest(delta,'charge',velocity);
    if(!hit){applyMove(actor,delta);actor.vx=actor.x-start.x;actor.vy=actor.y-start.y;return;}
    const contact={...hit.record,fraction:1-remaining+hit.fraction*remaining};applyMove(actor,delta,hit.fraction);
    if(contact.surfaceMotion){
     const correction=contact.surfaceMotion.displacement,obstruction=nearest(correction,'surface-motion'),blocked=obstruction?.record;
     applyMove(actor,correction,obstruction?.fraction??1);contact.body={x:actor.x,y:actor.y,w:actor.w,h:actor.h};
     if(obstruction&&obstruction.fraction<1-EPS){stopped(actor);state.contact=null;terrain?.clearActorContact?.(actor);result.blocked=copy(blocked);event(actor,tick,'surface-motion-blocked',{contact:blocked});return;}
    }
    if(iteration===256&&breakSolid&&breakable(hit.solid)){result.breakLimitReached=true;actor.vx=actor.x-start.x;actor.vy=actor.y-start.y;return;}
    if(breakSolid&&breakable(hit.solid)){
     const at={x:actor.x,y:actor.y,w:actor.w,h:actor.h},answer=breakSolid({actor,solid:hit.solid,contact:copy(contact)});
     if(answer?.then)fail('SMM2 Thwomp breakSolid must be synchronous');if(['x','y','w','h'].some(k=>actor[k]!==at[k]))fail('SMM2 Thwomp breakSolid may change terrain, not actor pose');
     if(!readTerrain().some(q=>q===hit.solid||q.id===hit.solid.id)){
      (result.breaks??=[]).push(copy(contact));event(actor,tick,'break',{contact});remaining*=1-hit.fraction;
      if(remaining<=EPS){actor.vx=actor.x-start.x;actor.vy=actor.y-start.y;return;}continue;
     }
    }
    stopped(actor,contact);state.phase='impact';state.remaining=spec.impactWaitFrames;state.speed=0;state.contact=contact;result.impact=copy(contact);
    if(contact.terrainKind==='shaped')terrain.recordImpact(actor,copy(contact),{tick});event(actor,tick,'impact',{contact});return;
   }
  }
  function returnHome(){
   const dx=state.home.x-actor.x,dy=state.home.y-actor.y,length=Math.hypot(dx,dy),distance=Math.min(spec.returnSpeed,length),delta=length>EPS?{x:dx/length*distance,y:dy/length*distance}:{x:0,y:0},hit=length>EPS?nearest(delta,'return'):null;
   if(hit){const contact=hit.record;applyMove(actor,delta,hit.fraction);stopped(actor);result.blocked=copy(contact);if(!state.returnBlocked||state.returnBlocked.solidId!==contact.solidId||state.returnBlocked.normal.x!==contact.normal.x||state.returnBlocked.normal.y!==contact.normal.y)event(actor,tick,'return-blocked',{contact});state.returnBlocked=contact;return;}
   state.returnBlocked=null;applyMove(actor,delta);if(distance>=length-EPS){actor.x=state.home.x;actor.y=state.home.y;stopped(actor);state.phase='idle';state.remaining=0;state.speed=0;state.contact=null;state.returnRequestedTick=null;state.returnReason=null;event(actor,tick,'home');}
  }
 }
 function view(enemies=[]){if(!Array.isArray(enemies))fail('Invalid SMM2 Thwomp view actors');return {version:1,thwomps:[...definitions.values()].map(spec=>{const actor=enemies.find(q=>q.id===spec.id),state=actor?.smm2Thwomp;return {...copy(spec),...(state?.[OWNER]===owner?{body:{x:actor.x,y:actor.y,w:actor.w,h:actor.h},state:copy(state)}:{})};})};}
 return Object.freeze({ownsActor,decorateEnemy,stepEnemy,requestReturn,view});
}
