/** Checkpoint styling stays outside strict native map objects. */
export function validateCheckpointVisuals(room){
 const styles=room.checkpointVisuals;if(styles===undefined)return;
 if(!styles||typeof styles!=='object'||Array.isArray(styles)||Object.keys(styles).length>20000)throw Error('检查点外观数据无效');
 for(const [id,style]of Object.entries(styles)){
  if(!style||style.version!==1||Object.keys(style).some(k=>!['version','base','hidden','style'].includes(k))||!(style.base===true&&style.hidden===undefined||style.hidden===true&&style.base===undefined)||style.style!==undefined&&(style.style!=='smm2-small'||style.base!==true||!(room.smm2Mechanics?.version===1||room.aquatic?.version===1&&/Underwater/.test(room.setting||''))))throw Error('未知检查点外观版本或字段');
  const object=room.map.objects.find(o=>o.id===id&&o.kind==='checkpoint');if(!object)throw Error('检查点外观没有对应旗帜');
  if(style.hidden)continue;
  const small=style.style==='smm2-small',baseTop=object.y+object.h-(small?4:16);if(baseTop<32||baseTop+(small?4:16)>room.map.height||object.w<8||small&&object.h<32)throw Error('检查点基座超出房间');
 }
}

/** Invisible NES-style midpoints can be triggered by the real camera boundary.
 * This only changes a respawn marker; it creates no collision or hidden gate. */
export function validateCheckpointRules(room){
 const rules=room.checkpointRules;if(rules===undefined)return;
 if(!rules||typeof rules!=='object'||Array.isArray(rules)||Object.keys(rules).length>20000)throw Error('检查点触发数据无效');
 for(const [id,rule]of Object.entries(rules)){
  if(!rule||rule.version!==1||rule.trigger!=='camera-x'||Object.keys(rule).some(k=>!['version','trigger','x'].includes(k))||!Number.isFinite(rule.x)||rule.x<0||rule.x>room.map.width-(room.playRules?.viewportWidth||256))throw Error('隐形中途点的镜头边界无效');
  if(!room.map.objects.some(o=>o.id===id&&o.kind==='checkpoint')||room.checkpointVisuals?.[id]?.hidden!==true)throw Error('镜头中途点需要已有隐形检查点');
 }
}
