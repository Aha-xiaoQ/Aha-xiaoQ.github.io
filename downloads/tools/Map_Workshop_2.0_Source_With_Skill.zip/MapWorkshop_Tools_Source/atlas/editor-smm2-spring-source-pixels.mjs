/** Exact decoded RGBA of the verified 16 x 16 SMM1 SMB1 standing Springboard.
 * Nintendo artwork, private learning only; not covered by the MIT code licence.
 * Original response bytes and source/rights record: assets/smm2-spring-private/.
 * No original compressed GIF/animation or complete SMM2 animation sheet obtained.
 */
const source = {"width":16,"height":16,"sourceGame":"Super Mario Maker (2015), Super Mario Bros. style","sourceFile":"smm1-smb1-springboard-standing.original.png","sourceSha256":"ad865950e94aaf224ccbe4d43e138bb57e7542bc2251aa34fc26550a3ad915ff","rgbaSha256":"f4655ce6ca41858e71f811f6190be5b3a7efa9026b14869e199041c5e412f4f4","palette":[[255,255,255,255],[255,178,89,255],[247,57,16,255],[0,0,0,0]],"rows":["0000000000000001","0111111111111112","2222222222222222","3333321111233333","3333211221123333","3332112332112333","3321123333211233","3200233333320023","3200233333320023","3321123333211233","3332112332112333","3333211221123333","3333321111233333","0000000000000001","0111111111111112","2222222222222222"]};
source.palette=Object.freeze(source.palette.map(p=>Object.freeze(p)));
source.rows=Object.freeze(source.rows);
export const SMM1_SMB1_SPRINGBOARD_SOURCE=Object.freeze(source);
export function springboardSourcePixels(){
 return {width:source.width,height:source.height,pixels:source.rows.flatMap(row=>[...row].flatMap(n=>source.palette[Number(n)]))};
}
