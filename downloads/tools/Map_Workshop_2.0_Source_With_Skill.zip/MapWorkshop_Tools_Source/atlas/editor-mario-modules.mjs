/** Opt-in data and contact adapters. Native movement, collection and death stay native. */
import {stepStudyEnemy} from './editor-switch.mjs';
import {createSmm2DryBones,validateDryBonesVariant} from './editor-smm2-dry-bones.mjs';
import {validateWalkingKoopaVariant,walkingKoopaBody,applyWalkingKoopaVariant} from './editor-walking-koopa.mjs';
const clone=x=>JSON.parse(JSON.stringify(x));
const overlap=(a,b)=>a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y;
const error=message=>{throw Error(message);};
function keys(value,allowed,label){if(!value||typeof value!=='object'||Array.isArray(value))error('Invalid '+label);for(const key of Object.keys(value))if(!allowed.includes(key))error('Unknown '+label+' field: '+key);}
const finite=(n,min,max)=>Number.isFinite(n)&&n>=min&&n<=max;
const integer=(n,min,max)=>Number.isInteger(n)&&finite(n,min,max);
const own=(map,id)=>map&&Object.hasOwn(map,id)?map[id]:undefined;
const unsafe=id=>['__proto__','prototype','constructor'].includes(id);
/** Ordinary shell/floor-plant top support only. Constraint-driven actors keep
 * their own movement; neither an actor's authored velocity nor a support ID
 * alone proves that it was actually standing on the previous platform top. */
export function nativePlatformEnemy(enemy){
 const type=enemy?.type?.replace(/^(enemy-|marker-)/,'').toLowerCase();
 return !!enemy&&!enemy.dead&&!enemy.hidden&&!enemy.moduleEmergence&&!enemy.emerge&&!enemy.clawHeld&&!enemy.vehicleId&&!enemy.onVine&&!enemy.verticalFlight&&!enemy.flying&&!enemy.moduleProjectile&&(type==='study-piranha'||enemy.shell===true&&['koopa','beetle'].includes(type));
}
function sweptSolidFraction(body,delta,solid){
 if(overlap(body,solid))return 0;
 let enter=-Infinity,leave=Infinity;
 for(const [axis,size]of [['x','w'],['y','h']]){
  const speed=delta[axis],lo=solid[axis]-body[axis]-body[size],hi=solid[axis]+solid[size]-body[axis];
  if(speed===0){if(lo>=0||hi<=0)return 1;continue;}
  const a=lo/speed,b=hi/speed;enter=Math.max(enter,Math.min(a,b));leave=Math.min(leave,Math.max(a,b));
 }
 return enter>=0&&enter<leave&&enter<=1&&leave>0?enter:1;
}
export function nativeMovingPlatformPreviousTop(q,previousGeometry){
 const prior=previousGeometry.get(q.id),eps=1e-7;
 return prior&&!q.hidden&&q.collision==='oneway'&&prior.collision==='oneway'&&(q.motion||q.liftSpeed)&&!q.smm2ItemBody&&!q.smm2CarrierGeometry&&q.w===prior.w&&q.h===prior.h&&Number.isFinite(q.dx)&&Number.isFinite(q.dy)&&Math.abs(q.x-prior.x-q.dx)<=eps&&Math.abs(q.y-prior.y-q.dy)<=eps?prior.y:null;
}
/** Carry with the same-frame native displacement, swept against other solids.
 * The Stage supplies actual prior geometry; this is not rigid parenting. */
export function carryNativePlatformEnemy(enemy,before,geometry,previousGeometry,{sweep=null,tick=0}={}){
 if(!nativePlatformEnemy(enemy)||!nativePlatformEnemy(before)||(before.vy||0)<0||enemy.x!==before.x||enemy.y!==before.y)return null;
 const eps=1e-7,initialPlant=before.type==='study-piranha'&&(before.age||0)===0&&!before.grounded&&!before.support;
 const support=geometry.find(q=>{
  const prior=previousGeometry.get(q.id),top=nativeMovingPlatformPreviousTop(q,previousGeometry);return top!==null&&(before.grounded&&before.support===q.id||initialPlant)&&Math.abs(before.y+before.h-top)<=eps&&before.x+before.w>prior.x+eps&&before.x<prior.x+prior.w-eps;
 });
 if(!support)return null;
 const delta={x:support.dx,y:support.dy};let fraction=1;
 for(const q of geometry)if(q.id!==support.id&&!q.hidden&&q.collision==='solid')fraction=Math.min(fraction,sweptSolidFraction(enemy,delta,q));
 const shape=sweep?.(enemy,delta,{tick});if(shape)fraction=Math.min(fraction,shape.fraction);
 enemy.x+=delta.x*fraction;enemy.y+=delta.y*fraction;
 const touching=Math.abs(enemy.y+enemy.h-support.y)<=eps&&enemy.x+enemy.w>support.x+eps&&enemy.x<support.x+support.w-eps;
 enemy.grounded=touching;enemy.support=touching?support.id:null;
 return {supportId:support.id,dx:delta.x*fraction,dy:delta.y*fraction,fraction,blocked:fraction<1};
}
/** A shell-only Buzzy can fall onto Mario's head without a Down input in SMB1.
 * Use both bodies' actual motion, not endpoint AABB overlap or a stored velocity.
 * This bounded adapter covers downward supplied-shell contact; native side kicks
 * and Mario descending onto a shell remain in the stage's ordinary branches. */
export function suppliedEmptyShellHeadContact(player,beforePlayer,shell,beforeShell){
 const eps=1e-7,body=q=>q&&['x','y','w','h'].every(k=>Number.isFinite(q[k]))&&q.w>0&&q.h>0,live=q=>q&&!q.dead&&!q.dying&&!q.removed&&!q.taken&&!q.hidden;
 if(![player,beforePlayer,shell,beforeShell].every(body)||!live(player)||!live(shell)||!live(beforeShell)||player.helmet==='buzzy'||player.hero==='bill'||typeof shell.type!=='string'||shell.type.replace(/^(enemy-|marker-)/,'').toLowerCase()!=='beetle'||shell.shell!==true||shell.emptyShell!==true||shell.moduleEmergence||beforeShell.moduleEmergence||shell.emerge||beforeShell.emerge||shell.clawHeld||beforeShell.clawHeld||shell.vehicleId||beforeShell.vehicleId)return null;
 if(shell.y-beforeShell.y<=eps)return null;
 const oldGap=beforeShell.y+beforeShell.h-beforePlayer.y,newGap=shell.y+shell.h-player.y,closure=newGap-oldGap;
 if(oldGap>eps||newGap<-eps||closure<=eps)return null;
 const fraction=Math.max(0,Math.min(1,-oldGap/closure)),at=(old,current,key)=>old[key]+(current[key]-old[key])*fraction;
 const shellLeft=at(beforeShell,shell,'x'),shellRight=shellLeft+at(beforeShell,shell,'w'),headLeft=at(beforePlayer,player,'x'),headRight=headLeft+at(beforePlayer,player,'w'),left=Math.max(shellLeft,headLeft),right=Math.min(shellRight,headRight);
 if(right-left<=eps)return null;
 const pose=q=>({x:q.x,y:q.y,w:q.w,h:q.h});
 return {kind:'head',fraction,point:{x:(left+right)/2,y:at(beforePlayer,player,'y')},normal:{x:0,y:1},relativeMotion:{x:player.x-beforePlayer.x-shell.x+beforeShell.x,y:-closure},relativeDescent:closure,shellDescent:shell.y-beforeShell.y,bodies:{playerBefore:pose(beforePlayer),player:pose(player),shellBefore:pose(beforeShell),shell:pose(shell)}};
}
function rect(room,q){if(!['x','y','w','h'].every(k=>Number.isFinite(q[k]))||q.x<0||q.y<0||q.w<=0||q.h<=0||q.x+q.w>room.map.width||q.y+q.h>room.map.height)error('Mario module rectangle outside room');}
function validatePipeSource(room,q,enemy=false){
 keys(q,['id','pipeId',...(enemy?['enemy','smart','shoeTemplateId','emergenceFrames','actorVariant','emitterKind','launcherId','muzzleOffset']:['item']),'direction','intervalFrames','initialDelayFrames','maxAlive','maxEmissions','activationDistance','vx','vy'],enemy?'enemy source':'item source');
 const launcher=enemy&&q.emitterKind==='launcher';
 if(enemy&&q.emitterKind!==undefined&&!['pipe','launcher'].includes(q.emitterKind))error('Unknown enemy emitter kind');
 if(launcher){
  const g=room.map.geometry.find(g=>g.id===q.launcherId),semantic=room.semantics?.find(s=>s.id===q.launcherId)?.kind;
  if(typeof q.launcherId!=='string'||unsafe(q.launcherId)||Object.hasOwn(q,'pipeId')||!g||g.collision!=='solid'||!(g.material==='cannon'||semantic==='Cannon'))error('Launcher source needs an existing actual solid cannon and no pipeId');
  rect(room,g);keys(q.muzzleOffset,['x','y'],'launcher muzzle offset');
  if(q.enemy!=='beetle-shell'||q.smart!==false||!['left','right'].includes(q.direction)||q.shoeTemplateId!==undefined||q.actorVariant!==undefined||!finite(q.muzzleOffset.x,0,g.w)||q.muzzleOffset.x!==(q.direction==='left'?0:g.w)||!finite(q.muzzleOffset.y,8,g.h-8))error('Launcher needs an explicit boundary muzzle center for an empty Buzzy shell');
 }else{
  if(enemy&&(Object.hasOwn(q,'launcherId')||Object.hasOwn(q,'muzzleOffset')))error('Pipe source cannot contain launcher fields');
  const pipe=room.map.geometry.find(g=>g.id===q.pipeId),semantic=room.semantics?.find(s=>s.id===q.pipeId)?.kind;
  if(!pipe||(!['pipe','pipe-side'].includes(pipe.material)&&!['Pipe','PipeHorizontal','PipeVertical'].includes(semantic)))error('Source needs an existing pipe');
 }
 if((enemy?(!['koopa','goomba','bone-shell','beetle-shell','fish-bone','galoomba'].includes(q.enemy)||typeof q.smart!=='boolean'):!['life','star','flower'].includes(q.item))||!['left','right','up','down'].includes(q.direction))error('Unknown pipe actor or direction');
 if(!integer(q.intervalFrames,1,36000)||!integer(q.initialDelayFrames,0,36000)||!integer(q.maxAlive,1,32)||(q.maxEmissions!==null&&!integer(q.maxEmissions,1,1000))||!finite(q.activationDistance,0,32768)||!finite(q.vx,-8,8)||!finite(q.vy,-12,12))error('Invalid authored source timing or launch values');
 if(enemy&&q.emergenceFrames!==undefined&&!integer(q.emergenceFrames,1,240))error('Invalid enemy source emergence duration');
 if(enemy&&q.actorVariant!==undefined){if(q.enemy!=='koopa')error('Walking Koopa source variant needs a Koopa source');validateWalkingKoopaVariant(q.actorVariant);}
 if(enemy&&q.enemy==='beetle-shell'&&(q.smart||q.shoeTemplateId!==undefined||!integer(q.emergenceFrames,1,240)))error('Empty Buzzy Beetle shell supply needs explicit emergence frames, no occupant or footwear template');
 if(enemy&&q.enemy==='bone-shell'&&(q.shoeTemplateId===undefined||q.smart))error('Bone Shell supply needs an explicit empty-shell template');
 if(enemy&&q.shoeTemplateId!==undefined){const shoe=q.enemy==='bone-shell'?room.smm2Mechanics?.boneShells?.find(v=>v.id===q.shoeTemplateId):room.smm2Mechanics?.shoes?.find(v=>v.id===q.shoeTemplateId),actor=room.map.objects.find(v=>v.id===q.shoeTemplateId&&v.kind==='walker');if(typeof q.shoeTemplateId!=='string'||unsafe(q.shoeTemplateId)||!['goomba','bone-shell'].includes(q.enemy)||!shoe||!actor||!finite(actor.w,1,64)||!finite(actor.h,1,64))error('Footwear source needs an existing matching typed native foot template');rect(room,actor);}
}
export function validateMarioModulesRoom(room){
 const spec=room.marioModules;if(spec===undefined)return;
 keys(spec,['version','switchCrush','carryEnemiesOnPlatforms','itemSources','enemySources','noteBlocks','oneWayWalls','enemyVariants','motionPlatforms','contactPlatforms','scaleRules','coinValues','rewardLimits','rewardWindows','starFrames','starKillPoints','fireKillPoints','castleFlagRiseFrames','goalScoreUnitsPerFrame','castleFlagWaitFrames','portalDirections','arrivalDirections','entryWalkToPortal','enemyStacks'],'Mario modules');if(spec.version!==1)error('Unknown Mario module version');if(spec.switchCrush!==undefined&&typeof spec.switchCrush!=='boolean')error('switchCrush must be a boolean');if(spec.carryEnemiesOnPlatforms!==undefined&&typeof spec.carryEnemiesOnPlatforms!=='boolean')error('carryEnemiesOnPlatforms must be a boolean');
 if(room.mechanics!==undefined||room.devices?.length)error('Mario modules cannot combine with echo before rewind state is supported');
 for(const key of ['itemSources','noteBlocks','oneWayWalls'])if(!Array.isArray(spec[key])||spec[key].length>1024)error('Invalid '+key+' list');keys(spec.enemyVariants,Object.keys(spec.enemyVariants||{}),'enemy variants');
 if(spec.enemySources!==undefined&&(!Array.isArray(spec.enemySources)||spec.enemySources.length>1024))error('Invalid enemy source list');
 const ids=new Set([...room.map.geometry,...room.map.objects,...(room.switchStudy?.devices||[])].map(q=>q.id));
 const id=q=>{if(typeof q.id!=='string'||!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(q.id)||q.id.length>72||ids.has(q.id))error('Duplicate or invalid Mario module ID');ids.add(q.id);};
 for(const q of spec.itemSources){id(q);validatePipeSource(room,q);}
 for(const q of spec.enemySources||[]){id(q);validatePipeSource(room,q,true);}
 for(const q of spec.noteBlocks){
  keys(q,['id','x','y','w','h','playerBounceSpeed','heldBounceSpeed','itemBounceSpeed','compressionFrames','compressionDepth','playerRiseGravity','playerFallGravity','enemyBounceSpeed','enemyRiseGravity','enemyFallGravity'],'note block');id(q);rect(room,q);if(q.w!==16||q.h!==16||!finite(q.playerBounceSpeed,.1,12)||!finite(q.heldBounceSpeed,q.playerBounceSpeed,12)||!finite(q.itemBounceSpeed,.1,12))error('Note blocks are 16 by 16 with explicit positive bounce speeds');
  const enemyProfile=['enemyBounceSpeed','enemyRiseGravity','enemyFallGravity'].some(k=>q[k]!==undefined),compressed=enemyProfile||['compressionFrames','compressionDepth','playerRiseGravity','playerFallGravity'].some(k=>q[k]!==undefined);
  if(compressed&&(!integer(q.compressionFrames,2,240)||!finite(q.compressionDepth,.01,q.h-.01)))error('Compressed Note needs explicit 2–240 active frames and a positive depth smaller than its height');
  for(const k of ['playerRiseGravity','playerFallGravity'])if(q[k]!==undefined&&!finite(q[k],.001,4))error('Invalid authored Note '+k);
  if(enemyProfile&&(!finite(q.enemyBounceSpeed,.1,12)||!finite(q.enemyRiseGravity,.001,4)||!finite(q.enemyFallGravity,.001,4)))error('Goomba Note contact needs explicit positive enemyBounceSpeed, enemyRiseGravity and enemyFallGravity');
 }
 for(const q of spec.oneWayWalls){keys(q,['id','x','y','w','h','direction'],'one-way wall');id(q);rect(room,q);if(q.direction!=='left'||q.w%16||q.h%16)error('One-way walls allow leftward crossing and use whole tiles');}
 for(const [id,variant]of Object.entries(spec.enemyVariants)){
  if(unsafe(id))error('Unsafe enemy variant key');
  if(variant?.kind==='walking-koopa'){validateWalkingKoopaVariant(room,id,variant);continue;}
  if(variant?.kind==='dry-bones'){validateDryBonesVariant(room,id,variant);rect(room,room.map.objects.find(o=>o.id===id&&o.kind==='walker'));continue;}
  if(variant?.kind==='muncher'){keys(variant,['kind'],'Muncher');const actor=room.map.objects.find(o=>o.id===id&&o.kind==='walker');if(!actor||!finite(actor.w,1,64)||!finite(actor.h,1,64))error('Muncher needs an existing native walker body');rect(room,actor);continue;}
  if(variant?.kind==='hopping-koopa'){keys(variant,['kind','speed','direction','hopSpeed'],'hopping Koopa');const actor=room.map.objects.find(o=>o.id===id&&o.kind==='walker');if(!actor||!finite(variant.speed,.01,2)||![1,-1].includes(variant.direction)||!finite(variant.hopSpeed,.1,8))error('Invalid hopping Koopa behavior');rect(room,{...actor,w:16,h:24});continue;}
  if(variant?.kind==='pipe-piranha'){keys(variant,['kind','hiddenFrames','riseFrames','outFrames','fallFrames','nearRadius'],'pipe Piranha');const actor=room.map.objects.find(o=>o.id===id&&o.kind==='walker');if(!actor||!['hiddenFrames','riseFrames','outFrames','fallFrames'].every(k=>integer(variant[k],1,3600))||!finite(variant.nearRadius,0,128)||!room.map.geometry.some(q=>(['pipe','pipe-side'].includes(q.material)||room.semantics?.some(v=>v.id===q.id&&['Pipe','PipeVertical'].includes(v.kind)))&&actor.x+8>=q.x&&actor.x+8<=q.x+q.w&&Math.abs(actor.y+24-q.y)<2))error('Pipe Piranha needs an actual native pipe and positive phase timings');rect(room,{...actor,w:16,h:24});continue;}
  if(variant?.kind==='vertical-koopa'){
   keys(variant,['kind','minY','maxY','speed','direction'],'vertical Koopa variant');
   const actor=room.map.objects.find(o=>o.id===id&&o.kind==='walker');if(!actor)error('Enemy variant target must be an existing enemy');
   if(!finite(variant.minY,0,room.map.height-24)||!finite(variant.maxY,variant.minY+.01,room.map.height-24)||!finite(variant.speed,.01,Math.min(4,variant.maxY-variant.minY))||![1,-1].includes(variant.direction)||actor.y<variant.minY||actor.y>variant.maxY)error('Invalid vertical Koopa path or initial position');
   rect(room,{...actor,w:16,h:24});continue;
  }
  keys(variant,['kind','size','winged','hopSpeed','hopIntervalFrames','stackedOn','fire','fireIntervalFrames','fireInitialDelayFrames','fireVx','fireVy','fireDirection','fireLifetimeFrames'],'enemy variant');if(!room.map.objects.some(o=>o.id===id&&o.kind==='walker'))error('Enemy variant target must be an existing enemy');
  if(variant.kind!=='floor-piranha'||!['normal','giant'].includes(variant.size)||typeof variant.winged!=='boolean')error('Unknown floor Piranha variant');
  const actor=room.map.objects.find(o=>o.id===id),w=variant.size==='giant'?32:16,h=variant.size==='giant'?48:24;rect(room,{x:actor.x+(actor.w-w)/2,y:actor.y+actor.h-h,w,h});
  if(variant.winged){if(!finite(variant.hopSpeed,.1,12)||!integer(variant.hopIntervalFrames,1,3600))error('Winged plants require authored hop speed and interval');}
  else if(variant.hopSpeed!==undefined||variant.hopIntervalFrames!==undefined)error('Unwinged plants cannot have a wing impulse');
  if(variant.stackedOn!==undefined&&(typeof variant.stackedOn!=='string'||unsafe(variant.stackedOn)||variant.stackedOn===id||!room.map.objects.some(o=>o.id===variant.stackedOn&&o.kind==='walker')))error('Stacked floor plant needs a distinct existing native enemy');
  if(variant.fire!==undefined&&typeof variant.fire!=='boolean')error('Invalid floor Fire Piranha flag');
  if(variant.fire){if(!integer(variant.fireIntervalFrames,1,3600)||!integer(variant.fireInitialDelayFrames,0,3600)||!finite(variant.fireVx,.01,8)||!finite(variant.fireVy,-8,8)||!['left','right','player'].includes(variant.fireDirection)||!integer(variant.fireLifetimeFrames,1,3600))error('Fire Piranha needs explicit bounded projectile tuning');}
  else if(['fireIntervalFrames','fireInitialDelayFrames','fireVx','fireVy','fireDirection','fireLifetimeFrames'].some(k=>variant[k]!==undefined))error('Ordinary floor plants cannot have fire projectile tuning');
 }
 if(spec.enemyStacks!==undefined){keys(spec.enemyStacks,Object.keys(spec.enemyStacks),'enemy stacks');for(const [id,parent]of Object.entries(spec.enemyStacks)){if(unsafe(id)||typeof parent!=='string'||unsafe(parent)||id===parent||![id,parent].every(k=>room.map.objects.some(o=>o.id===k&&o.kind==='walker')))error('Enemy stack needs two distinct native walkers');}for(const id of Object.keys(spec.enemyStacks)){let k=id;const seen=new Set();while(spec.enemyStacks[k]!==undefined){if(seen.has(k))error('Cyclic enemy stack');seen.add(k);k=spec.enemyStacks[k];}}}
 const completedStacks=new Set();for(const id of Object.keys(spec.enemyVariants)){const trail=new Set();let cursor=id;while(cursor!==undefined&&!completedStacks.has(cursor)){if(trail.has(cursor))error('Cyclic floor plant stack');trail.add(cursor);cursor=own(spec.enemyVariants,cursor)?.stackedOn;}for(const node of trail)completedStacks.add(node);}

 if(spec.entryWalkToPortal!==undefined){keys(spec.entryWalkToPortal,['spawnId','portalId'],'automatic entry walk');const {spawnId,portalId}=spec.entryWalkToPortal,spawn=room.map.objects.find(o=>o.kind==='spawn'&&o.id===spawnId),portal=room.map.objects.find(o=>o.kind==='portal'&&o.id===portalId);if(!spawn||!portal||portal.x<=spawn.x)error('Automatic entry needs an existing spawn and a portal to its right');}
 if(spec.goalScoreUnitsPerFrame!==undefined&&!integer(spec.goalScoreUnitsPerFrame,1,16))error('Invalid goal score rate');if(spec.castleFlagWaitFrames!==undefined&&(!integer(spec.castleFlagWaitFrames,0,3600)||spec.castleFlagRiseFrames===undefined))error('Castle flag wait needs native castle feedback');
 if(spec.castleFlagRiseFrames!==undefined&&(!integer(spec.castleFlagRiseFrames,1,3600)||!room.markers?.some(m=>m.kind==='flagpole-finish')))error('Castle flag feedback needs a native flagpole goal and positive rise frames');
 if(spec.fireKillPoints!==undefined&&!integer(spec.fireKillPoints,0,100000))error('Invalid fire contact points');
 if(spec.starFrames!==undefined&&!integer(spec.starFrames,1,36000))error('Invalid star duration');if(spec.starKillPoints!==undefined&&!integer(spec.starKillPoints,0,100000))error('Invalid star contact points');
 if(spec.rewardWindows!==undefined){keys(spec.rewardWindows,Object.keys(spec.rewardWindows||{}),'coin reward windows');for(const [id,frames]of Object.entries(spec.rewardWindows)){if(unsafe(id)||!room.map.geometry.some(q=>q.id===id)||!integer(frames,1,36000))error('Invalid repeated reward window');}}
 if(spec.contactPlatforms!==undefined){
  keys(spec.contactPlatforms,Object.keys(spec.contactPlatforms||{}),'contact platform map');
  for(const [id,rule]of Object.entries(spec.contactPlatforms)){
   keys(rule,['speed','acceleration','maxSpeed','continueAfterLeave'],'contact platform');const q=room.map.geometry.find(g=>g.id===id);
   if(unsafe(id)||!q||q.collision!=='oneway'||q.motion||room.markers?.some(m=>m.kind==='coupled-scale'&&(id===m.id+'-left'||id===m.id+'-right')))error('Contact platform needs an existing independent nonmoving one-way platform');
   rect(room,q);if(!finite(rule.speed,.01,4)||!finite(rule.acceleration,0,.5)||!finite(rule.maxSpeed,rule.speed,6)||typeof rule.continueAfterLeave!=='boolean')error('Invalid contact platform speed or continuation');
  }
 }
 if(spec.motionPlatforms!==undefined){
  keys(spec.motionPlatforms,Object.keys(spec.motionPlatforms||{}),'motion platform map');for(const [id,rule]of Object.entries(spec.motionPlatforms)){
   keys(rule,['profile','direction','activationDistance','periodFrames','phaseDegrees'],'platform motion rule');const q=room.map.geometry.find(g=>g.id===id);
   if(unsafe(id)||!q?.motion||!['linear','smooth'].includes(rule.profile)||![1,-1].includes(rule.direction)||!finite(rule.activationDistance,0,4096))error('Invalid motion platform target or activation');
   const motion=q.motion,extent=motion.axis==='x'?room.map.width-q.w:room.map.height-q.h;if(motion.min<0||motion.max>extent||q[motion.axis]<motion.min||q[motion.axis]>motion.max)error('Motion range or initial position outside room');
   if(rule.profile==='smooth'){
    if(!integer(rule.periodFrames,30,3600)||!finite(rule.phaseDegrees,0,360)||(motion.max-motion.min)*Math.PI/rule.periodFrames>2)error('Smooth platforms require an authored safe period and phase');
    const m=q.motion,initial=(m.min+m.max)/2+(m.max-m.min)/2*Math.sin(rule.phaseDegrees*Math.PI/180);if(Math.abs(q[m.axis]-initial)>.01)error('Authored smooth platform position must match its phase');
   }else if(rule.periodFrames!==undefined||rule.phaseDegrees!==undefined)error('Linear platforms do not use a periodic phase');
  }
 }
 if(spec.scaleRules!==undefined){
  keys(spec.scaleRules,Object.keys(spec.scaleRules||{}),'scale rule map');for(const [id,rule]of Object.entries(spec.scaleRules)){
   keys(rule,['acceleration','maxSpeed','emptyStops','fallAcceleration','fallMaxSpeed'],'scale rule');if(unsafe(id)||!room.markers?.some(m=>m.id===id&&m.kind==='coupled-scale'&&m.source?.macro==='Scale'))error('Scale rule needs an existing linked scale pair');
   if(!finite(rule.acceleration,.001,.5)||!finite(rule.maxSpeed,rule.acceleration,4)||typeof rule.emptyStops!=='boolean'||!finite(rule.fallAcceleration,.001,1)||!finite(rule.fallMaxSpeed,rule.fallAcceleration,8))error('Invalid scale forces');
  }
 }
 for(const [key,label,allowed]of [['coinValues','coin value',id=>room.map.objects.some(o=>o.id===id&&o.kind==='coin')],['rewardLimits','reward limit',id=>{const q=room.map.geometry.find(q=>q.id===id),semantic=room.semantics?.find(s=>s.id===id)?.kind;return !!q&&(['brick','block'].includes(q.material)||['Brick','Block'].includes(semantic));}]]){
  if(spec[key]===undefined)continue;keys(spec[key],Object.keys(spec[key]||{}),label+' map');for(const [id,value]of Object.entries(spec[key]))if(unsafe(id)||!allowed(id)||!integer(value,1,100))error('Invalid '+label+' target or count');
 }
 for(const [key,kind,direction]of [['portalDirections','portal','up'],['arrivalDirections','spawn','down']]){
  if(spec[key]===undefined)continue;keys(spec[key],Object.keys(spec[key]||{}),key);for(const [id,rule]of Object.entries(spec[key])){keys(rule,['pipeId','direction'],'pipe direction');const pipe=room.map.geometry.find(q=>q.id===rule.pipeId),semantic=room.semantics?.find(q=>q.id===rule.pipeId)?.kind;if(unsafe(id)||!room.map.objects.some(q=>q.id===id&&q.kind===kind)||!pipe||(!['pipe','pipe-side'].includes(pipe.material)&&!['Pipe','PipeVertical','PipeHorizontal'].includes(semantic))||!(room.smm2Mechanics?.version===1?['up','down','left','right']:[direction]).includes(rule.direction))error('Invalid same-room '+key+' reference or direction');}
 }
}

export function createMarioModules(room,{emit=()=>{}}={}){
 validateMarioModulesRoom(room);if(room.marioModules===undefined)return null;
 const dryBones=createSmm2DryBones(room,{emit});
 const spec=clone(room.marioModules),allSources=[...spec.itemSources,...(spec.enemySources||[])],notes=new Map(spec.noteBlocks.map(q=>[q.id,q])),bumps=new Map(),sourceStates=new Map(allSources.map(q=>[q.id,{active:false,clock:q.initialDelayFrames,emitted:0}]));
 const authoredShoeIds=new Set((room.smm2Mechanics?.shoes||[]).map(q=>q.id));
 const reservedIds=new Set([...room.map.geometry,...room.map.objects,...(room.markers||[]),...(room.switchStudy?.devices||[]),...Object.values(room.smm2Mechanics||{}).filter(Array.isArray).flat()].map(q=>q?.id)),runtimeIds=new Set();
 let currentTick=0,lastRewardTick=null,projectileSerial=0,contactFrames=new WeakMap(),wingClocks=new WeakMap(),flightFrames=new WeakMap(),sourceFrames=new Map(),fireClocks=new WeakMap(),compressionActors=new WeakMap(),lastNoteTick=null;const platformStates=new Map(),motionStates=new Map(),rewardWindows=new Map(),runtimeVariants=new Map(),noteStates=new Map(),enemyNoteMotions=new Map();
 const diagnostic=(event,data)=>emit('mario-module',{event,...data});
 const compresses=q=>q.compressionFrames!==undefined;
 function resetNotes(){noteStates.clear();for(const q of spec.noteBlocks)if(compresses(q))noteStates.set(q.id,{y:q.y,h:q.h,dy:0,frame:0,phase:'idle',actors:new Map()});}
 resetNotes();
 function noteState(q){return noteStates.get(q.id);}
 function notePose(q){if(!compresses(q))return {...q,bump:bumps.get(q.id)||0};const state=noteState(q);return {...q,y:state.y,h:state.h,dy:state.dy,resty:q.y,resth:q.h,currenty:state.y,compressionFrame:state.frame,compressionPhase:state.phase,compressionParameterStatus:'explicit-author-configuration',bump:0};}
 function geometry(base){return [...base.filter(q=>!q.marioModuleDevice),...spec.noteBlocks.map(q=>({...notePose(q),collision:'solid',material:'study-note',marioModuleDevice:true,...(compresses(q)?{noteCompressionGeometry:true}:{}),dir:1,dx:0,dy:compresses(q)?noteState(q).dy:0}))];}
 const noteActorLive=actor=>actor&&!actor.dead&&!actor.dying&&!actor.removed&&!actor.taken&&!actor.hidden&&!actor.emerge&&!actor.moduleEmergence&&!actor.portableStone?.held;
 const onNote=(actor,note,top)=>noteActorLive(actor)&&actor.grounded&&actor.support===note.id&&Math.abs(actor.y+actor.h-top)<.01&&actor.x+actor.w>note.x&&actor.x<note.x+note.w;
 function forgetCompression(actor,state){state.actors.delete(actor);compressionActors.delete(actor);}
 /** Call once per active tick BEFORE rebuilding geometry and moving any actor.
  * actors contains the actual player/item identities, not view snapshots. This
  * advances authored geometry only: the native player motor and portable item
  * controller each consume support.dy once. afterActor then verifies the new
  * top before releasing the actor. A skipped/paused tick never spends frames.
  * The host must preserve noteCompressionGeometry dy when updating ordinary
  * platforms; the Note has already supplied this frame's physical motion.
  * The first 3/4 of the authored interval depress the top; the remainder returns
  * it to rest. This bounded interpolation is an author model, not a recovered
  * Nintendo formula. An opted-in plain Goomba launches on first real top contact;
  * the tile keeps advancing without retaining that enemy as a compression load.
  * Neither drawing nor geometry/view reads advance it. */
 function frameNotes({tick,actors=[],input={},paused=false}={}){
  if(!Number.isSafeInteger(tick)||tick<0||!Array.isArray(actors)||typeof paused!=='boolean')error('Invalid compressed Note frame');
  if(paused||lastNoteTick!==null&&tick<=lastNoteTick)return {advanced:false};
  lastNoteTick=tick;currentTick=tick;const present=new Set(actors);
  for(const [actor,motion]of enemyNoteMotions)if(!noteActorLive(actor)||actor.noteBounceMotion!==motion)forgetEnemyMotion(actor);
  for(const q of spec.noteBlocks){if(!compresses(q))continue;const state=noteState(q),oldY=state.y;state.dy=0;
   for(const [actor]of state.actors)if(!present.has(actor)||!onNote(actor,q,oldY))forgetCompression(actor,state);
   if(state.phase==='release'){for(const actor of state.actors.keys())forgetCompression(actor,state);state.phase='idle';state.frame=0;}
   if(state.phase==='compressing'){
    state.frame++;const peak=Math.max(1,Math.min(q.compressionFrames-1,Math.ceil(q.compressionFrames*.75))),depth=state.frame<=peak?q.compressionDepth*state.frame/peak:q.compressionDepth*(q.compressionFrames-state.frame)/(q.compressionFrames-peak);
    state.y=q.y+Math.max(0,depth);state.h=q.h-(state.y-q.y);state.dy=state.y-oldY;if(state.frame>=q.compressionFrames)state.phase='release';
   }
   for(const [actor,contact]of state.actors)if(contact.kind==='player'){contact.input={...input};if(Object.hasOwn(actor,'jumpBuffer'))actor.jumpBuffer=0;}
  }
  return {advanced:true};
 }
 /** Suppress only the native ground-jump trigger while the Note owns contact.
  * Keep held jump and horizontal/run/down input: held jump selects the release
  * impulse and the native motor subsequently applies its normal hold rule. */
 function ownsCompression(actor){const contact=compressionActors.get(actor),q=contact&&notes.get(contact.id),state=q&&noteStates.get(q.id);return !!(state&&state.phase!=='idle'&&state.actors.has(actor)&&(onNote(actor,q,state.y)||onNote(actor,q,state.y-state.dy)));}
 function stepPlatform(q,{cam=0,viewportWidth=256,tick=currentTick}={}){
  const rule=own(spec.motionPlatforms,q.id);if(!rule)return false;const state=motionStates.get(q.id)||{active:false,lastTick:null,phase:(rule.phaseDegrees||0)*Math.PI/180,direction:rule.direction};
  if(state.lastTick===tick)return true;state.lastTick=tick;
  if(!state.active&&q.x+q.w>=cam&&q.x<=cam+viewportWidth+rule.activationDistance)state.active=true;
  if(state.active){const m=q.motion,old=q[m.axis];if(rule.profile==='smooth'){state.phase+=rule.direction*2*Math.PI/rule.periodFrames;q[m.axis]=(m.min+m.max)/2+(m.max-m.min)/2*Math.sin(state.phase);}else{q[m.axis]=Math.max(m.min,Math.min(m.max,old+m.speed*state.direction));if(q[m.axis]>=m.max||q[m.axis]<=m.min)state.direction*=-1;}q[m.axis==='x'?'dx':'dy']=q[m.axis]-old;q.dir=state.direction;}
  motionStates.set(q.id,state);return true;
 }
 function updatePlatforms(base,player,{tick=currentTick}={}){
  for(const [id,rule]of Object.entries(spec.contactPlatforms||{})){
   const q=base.find(q=>q.id===id);if(!q)continue;const state=platformStates.get(id)||{speed:rule.speed,triggered:false,ridden:false,lastTick:null};
   if(state.lastTick===tick)continue;state.lastTick=tick;const ridden=!!(player?.grounded&&player.support===id);
   if(ridden&&!state.ridden)diagnostic('contact-platform-ridden',{deviceId:id});if(!ridden&&state.ridden&&!rule.continueAfterLeave)diagnostic('contact-platform-paused',{deviceId:id});
   state.ridden=ridden;state.triggered||=ridden;if(ridden||state.triggered&&rule.continueAfterLeave){q.dy=state.speed;q.y+=q.dy;state.speed=Math.min(rule.maxSpeed,state.speed+rule.acceleration);}else q.dy=0;
   platformStates.set(id,state);
  }
 }
 function sourceItem(q,pipe){const w=14,h=14,x=q.direction==='left'?pipe.x-w:q.direction==='right'?pipe.x+pipe.w:pipe.x+(pipe.w-w)/2,y=q.direction==='up'?pipe.y-h:q.direction==='down'?pipe.y+pipe.h:pipe.y+(pipe.h-h)/2;return {id:'module-item-'+q.id+'-'+sourceStates.get(q.id).emitted,kind:q.item,x,y,w,h,vx:q.vx,vy:q.vy,age:0,moduleSource:q.id,dead:false};}
 function runtimeId(base){let id=base,suffix=0;while(reservedIds.has(id)||runtimeIds.has(id))id=base+'-spawn-'+(++suffix);runtimeIds.add(id);return id;}
 function sourceEmitterId(q){return q.emitterKind==='launcher'?q.launcherId:q.pipeId;}
 function sourceEnemy(q,pipe){const emptyShell=q.enemy==='beetle-shell',template=q.shoeTemplateId?room.map.objects.find(a=>a.id===q.shoeTemplateId):null,walkingBody=q.actorVariant?walkingKoopaBody(q.actorVariant).walk:null,giant=q.enemy==='galoomba'&&room.smm2Mechanics?.underwaterActors?.profiles.some(p=>p.sourceId===q.id&&p.kind==='galoomba'&&p.size==='giant'),w=walkingBody?.w??template?.w??(giant?32:16),h=walkingBody?.h??template?.h??(giant?32:emptyShell||['goomba','fish-bone','galoomba'].includes(q.enemy)?16:24),launcher=q.emitterKind==='launcher',x=launcher?pipe.x+q.muzzleOffset.x-(q.direction==='left'?w:0):q.direction==='left'?pipe.x-w:q.direction==='right'?pipe.x+pipe.w:pipe.x+(pipe.w-w)/2,y=launcher?pipe.y+q.muzzleOffset.y-h/2:q.direction==='up'?pipe.y-h:q.direction==='down'?pipe.y+pipe.h:q.actorVariant?pipe.y+pipe.h-h:pipe.y+(pipe.h-h)/2;return {kind:'walker',type:emptyShell?'beetle':q.enemy,source:{smart:q.smart,red:q.smart,...(launcher?{cannonId:q.launcherId}:{}),...(q.enemy==='fish-bone'?{winged:true}:{})},...(emptyShell?{shell:true,emptyShell:true,shellAge:0,frame:''}:{}),x,y,w,h,vx:q.vx,vy:q.vy,hp:2,age:0,moduleSource:q.id,...(template?{moduleShoeTemplateId:q.shoeTemplateId}:{}),homeX:x,homeY:y,grounded:false,support:null,dead:false};}
 function startSourceEmergence(e,q,pipe){const frames=q.emergenceFrames??(q.shoeTemplateId?24:0);if(!frames)return;
  const targetX=e.x,targetY=e.y;if(q.direction==='left')e.x=pipe.x;else if(q.direction==='right')e.x=pipe.x+pipe.w-e.w;else if(q.direction==='up')e.y=pipe.y;else e.y=pipe.y+pipe.h-e.h;
  const binding=q.emitterKind==='launcher'?{emitterKind:'launcher',launcherId:q.launcherId}:{pipeId:q.pipeId};
  e.moduleEmergence={sourceId:q.id,...binding,direction:q.direction,remainingFrames:frames,totalFrames:frames,startX:e.x,startY:e.y,targetX,targetY,launchVx:q.vx,launchVy:q.vy,lastTick:null};
  e.sourceClip={...binding,direction:q.direction,mouth:q.direction==='left'?pipe.x:q.direction==='right'?pipe.x+pipe.w:q.direction==='up'?pipe.y:pipe.y+pipe.h};e.vx=0;e.vy=0;
 }
 function spawnItems({player,items=[],tick,geometry:solids=[]}){
  currentTick=Number.isInteger(tick)?tick:currentTick+1;if(lastRewardTick!==currentTick){for(const [id,frames]of rewardWindows)if(frames>0)rewardWindows.set(id,frames-1);lastRewardTick=currentTick;}for(const [id,age]of bumps)if(age>1)bumps.set(id,age-1);else bumps.delete(id);
  const spawned=[];for(const q of spec.itemSources){const state=sourceStates.get(q.id),pipe=solids.find(g=>g.id===q.pipeId)||room.map.geometry.find(g=>g.id===q.pipeId);
   if(!state.active){if(!player||pipe.x>player.x+q.activationDistance)continue;state.active=true;}
   if(state.clock>0){state.clock--;continue;}if((q.maxEmissions!==null&&state.emitted>=q.maxEmissions)||[...items,...spawned].filter(i=>!i.dead&&i.moduleSource===q.id).length>=q.maxAlive)continue;
   const item=sourceItem(q,pipe);if(item.x<0||item.y<0||item.x+item.w>room.map.width||item.y+item.h>room.map.height||solids.some(g=>!g.hidden&&g.collision==='solid'&&overlap(item,g)))continue;
   spawned.push(item);state.emitted++;state.clock=q.intervalFrames-1;emit('sound',{event:'appear'});diagnostic('item-source',{sourceId:q.id,itemId:item.id,item:q.item});
  }return spawned;
 }
 function spawnEnemies({player,enemies=[],actors=[],tick,geometry:solids=[]}){
  currentTick=Number.isInteger(tick)?tick:currentTick+1;const spawned=[];for(const q of spec.enemySources||[]){const state=sourceStates.get(q.id),emitterId=sourceEmitterId(q),pipe=solids.find(g=>g.id===emitterId)||room.map.geometry.find(g=>g.id===emitterId);
   if(sourceFrames.get(q.id)===currentTick)continue;sourceFrames.set(q.id,currentTick);
   if(!state.active){if(!player||pipe.x>player.x+q.activationDistance)continue;state.active=true;}
   const liveActors=new Map([...enemies,...actors,...spawned].filter(e=>!e.dead&&!e.dying&&!e.removed&&!e.taken&&e.smm2Shoe?.occupancy!=='removed').map(e=>[e.id,e]));
   const liveSourceActors=[...liveActors.values()].filter(e=>e.moduleSource===q.id);
   if(state.clock>0){state.clock--;continue;}if((q.maxEmissions!==null&&state.emitted>=q.maxEmissions)||liveSourceActors.length>=q.maxAlive)continue;
   const e=sourceEnemy(q,pipe);if(e.x<0||e.y<0||e.x+e.w>room.map.width||e.y+e.h>room.map.height||solids.some(g=>!g.hidden&&g.collision==='solid'&&overlap(e,g)))continue;
   if(q.shoeTemplateId&&[...liveActors.values()].some(a=>(authoredShoeIds.has(a.id)||a.smm2Shoe||a.moduleShoeTemplateId)&&overlap(e,a)))continue;
   if(q.enemy==='beetle-shell'&&[...liveActors.values()].some(a=>overlap(e,a)||a.moduleEmergence&&(a.moduleEmergence.launcherId??a.moduleEmergence.pipeId)===emitterId&&a.moduleEmergence.direction===q.direction))continue;
   // The pure helper needs the stable ID and an ordinary live body before the
   // pipe owns emergence. Explicit source launch velocity remains source-owned.
   e.id=runtimeId('module-enemy-'+q.id+'-'+state.emitted);
   if(q.actorVariant){runtimeVariants.set(e.id,clone(q.actorVariant));applyEnemyVariant(e);e.vx=q.vx;e.vy=q.vy;}
   startSourceEmergence(e,q,pipe);if(e.x<0||e.y<0||e.x+e.w>room.map.width||e.y+e.h>room.map.height){runtimeVariants.delete(e.id);runtimeIds.delete(e.id);continue;}
   spawned.push(e);state.emitted++;state.clock=q.intervalFrames-1;diagnostic('enemy-source',{sourceId:q.id,actorId:e.id,enemy:q.enemy});
  }return spawned;
 }
 function release(actor,speed){actor.vy=-speed;actor.grounded=false;actor.support=null;if(Object.hasOwn(actor,'jumpBuffer'))actor.jumpBuffer=0;}
 function bounce(actor,note,{kind='player',input={},tick=currentTick}={}){
  const old=contactFrames.get(actor);if(old?.tick===tick&&old.id===note.id)return false;
  release(actor,kind==='player'?(input.jump?note.heldBounceSpeed:note.playerBounceSpeed):kind==='enemy'?note.enemyBounceSpeed:note.itemBounceSpeed);
  if(compresses(note)){if(kind==='player'){if(note.playerRiseGravity!==undefined)actor.jumpG=note.playerRiseGravity;if(note.playerFallGravity!==undefined)actor.fallG=note.playerFallGravity;}}
  else bumps.set(note.id,12);
  contactFrames.set(actor,{tick,id:note.id});emit('sound',{event:kind==='player'&&actor.power?'jump_super':'jump'});diagnostic('note-bounce',{deviceId:note.id,actorId:actor.id||kind,actorKind:kind});return true;
 }
 // Only the observed plain Goomba contact is enabled. The host retains the
 // authored vertical profile until actual landing; this module owns no motor.
 const plainGoomba=actor=>String(actor.type||'').replace(/^(enemy-|marker-)/,'').toLowerCase()==='goomba'&&!actor.shell&&!actor.smm2Shoe&&!actor.vehicleId&&!actor.clawHeld&&!actor.source?.winged&&!actor.source?.floating;
 function forgetEnemyMotion(actor){const motion=enemyNoteMotions.get(actor);if(motion&&actor.noteBounceMotion===motion)delete actor.noteBounceMotion;enemyNoteMotions.delete(actor);}
 function enemyNoteContact(actor,before,note,context){
  if(note.enemyBounceSpeed===undefined||!plainGoomba(actor))return false;
  const state=noteState(note),tick=context.tick??currentTick,priorTop=state.y-state.dy,priorBottom=before.y+before.h;
  if(!onNote(actor,note,state.y)||!Number.isFinite(before.vy)||before.vy<0||!Number.isFinite(priorBottom)||priorBottom>priorTop+.01)return false;
  const old=contactFrames.get(actor);if(old?.tick===tick&&old.id===note.id)return false;
  if(state.phase==='idle'||state.phase==='release'){state.phase='compressing';state.frame=0;diagnostic('note-compress',{deviceId:note.id,actorId:actor.id||'enemy',actorKind:'enemy'});}
  if(!bounce(actor,note,{kind:'enemy',tick}))return false;
  const motion={noteId:note.id,launchTick:tick,riseGravity:note.enemyRiseGravity,fallGravity:note.enemyFallGravity};actor.noteBounceMotion=motion;enemyNoteMotions.set(actor,motion);return true;
 }
 function compressedContact(actor,before,note,context){
  const state=noteState(note),contact=state.actors.get(actor),kind=context.kind||'player',tick=context.tick??currentTick;
  if(contact){
   if(!onNote(actor,note,state.y)){forgetCompression(actor,state);return false;}
   contact.input={...(context.input||contact.input)};
   if(state.phase==='release'){const bounced=bounce(actor,note,{kind:contact.kind,input:contact.input,tick});forgetCompression(actor,state);return bounced;}
   if(Object.hasOwn(actor,'jumpBuffer'))actor.jumpBuffer=0;return false;
  }
  if(state.phase==='release'||!onNote(actor,note,state.y)||before.y+before.h>state.y+1.01||before.vy<0)return false;
  const old=contactFrames.get(actor);if(old?.tick===tick&&old.id===note.id)return false;
  const previous=compressionActors.get(actor);if(previous){const prior=noteStates.get(previous.id);if(prior)forgetCompression(actor,prior);}
  const entry={id:note.id,kind,input:{...(context.input||{})}};state.actors.set(actor,entry);compressionActors.set(actor,entry);contactFrames.set(actor,{tick,id:note.id});if(Object.hasOwn(actor,'jumpBuffer'))actor.jumpBuffer=0;
  if(state.phase==='idle'){state.phase='compressing';state.frame=0;diagnostic('note-compress',{deviceId:note.id,actorId:actor.id||kind,actorKind:kind});}
  return true;
 }
 function afterActor(actor,before,context={}){
  const kind=context.kind||'player',events=[],enemyMotion=enemyNoteMotions.get(actor);if(kind==='enemy'&&enemyMotion&&(actor.noteBounceMotion!==enemyMotion||actor.grounded&&(context.tick??currentTick)>enemyMotion.launchTick||!noteActorLive(actor)))forgetEnemyMotion(actor);if(actor.dead||actor.dying||actor.emerge||actor.moduleEmergence){const contact=compressionActors.get(actor),state=contact&&noteStates.get(contact.id);if(state)forgetCompression(actor,state);return events;}
  if(actor.x>before.x){for(const wall of spec.oneWayWalls){const oldRight=before.x+before.w,newRight=actor.x+actor.w;if(oldRight<=wall.x+.001&&newRight>wall.x&&before.y+before.h>wall.y&&before.y<wall.y+wall.h){actor.x=wall.x-actor.w;actor.vx=kind==='player'?0:-Math.abs(actor.vx||before.vx||.75);const support=context.geometry?.find(q=>q.id===actor.support);if(support&&(actor.x+actor.w<=support.x||actor.x>=support.x+support.w)){actor.grounded=false;actor.support=null;}events.push(wall.id);diagnostic('one-way-stop',{deviceId:wall.id,actorId:actor.id||kind,actorKind:kind});break;}}}
  if(kind==='player'||kind==='item')for(const note of spec.noteBlocks){if(compresses(note)){const owned=compressionActors.get(actor)?.id===note.id||actor.support===note.id;if(compressedContact(actor,before,note,context))events.push(note.id);if(owned)break;continue;}if(before.y+before.h<=note.y+1.01&&actor.x+actor.w>note.x&&actor.x<note.x+note.w&&Math.abs(actor.y+actor.h-note.y)<.01&&before.vy>=0){if(bounce(actor,note,context))events.push(note.id);break;}}
  if(kind==='enemy')for(const note of spec.noteBlocks)if(enemyNoteContact(actor,before,note,context)){events.push(note.id);break;}
  return events;
 }
 function bumpNote(id,actors=[]){const q=notes.get(id);if(!q)return false;if(!compresses(q))bumps.set(id,12);emit('sound',{event:'bump'});diagnostic('note-bump',{deviceId:id});if(!compresses(q))for(const actor of actors)if(!actor.dead&&actor.x+actor.w>q.x&&actor.x<q.x+q.w&&Math.abs(actor.y+actor.h-q.y)<1.01)bounce(actor,q,{kind:'item'});return true;}
 function enemyVariant(id){const v=own(spec.enemyVariants,id)??runtimeVariants.get(id);if(!v)return null;if(v.kind==='walking-koopa')return{...v,type:'koopa',...walkingKoopaBody(v).walk,npcSpringEligible:true};if(v.kind==='dry-bones')return dryBones.descriptor(id);if(v.kind==='muncher'){const a=room.map.objects.find(q=>q.id===id);return{...v,type:'muncher',w:a.w,h:a.h};}return ['vertical-koopa','hopping-koopa'].includes(v.kind)?{...v,type:'koopa',w:16,h:24}:v.kind==='pipe-piranha'?{...v,type:'piranha',w:16,h:24}:{...v,type:'study-piranha',w:v.size==='giant'?32:16,h:v.size==='giant'?48:24};}
 function applyEnemyVariant(enemy){const v=enemyVariant(enemy.id);if(!v)return enemy;
  if(v.kind==='walking-koopa'){const rule=own(spec.enemyVariants,enemy.id)??runtimeVariants.get(enemy.id),result=applyWalkingKoopaVariant(enemy,rule,{tick:currentTick});if(result.handled)Object.assign(enemy,result.actor,{npcSpringEligible:true});return enemy;}
  if(v.kind==='dry-bones')return dryBones.decorateEnemy(enemy);
  if(v.kind==='muncher'){const center=enemy.x+enemy.w/2,bottom=enemy.y+enemy.h;Object.assign(enemy,{x:center-v.w/2,y:bottom-v.h,w:v.w,h:v.h,type:'muncher',smm2EnemyKind:'muncher',vx:0,vy:Number.isFinite(enemy.vy)?enemy.vy:0,standable:true,source:{...enemy.source,muncher:true,stationary:true}});return enemy;}
  if(v.kind==='hopping-koopa'){Object.assign(enemy,{type:'koopa',w:16,h:24,vx:v.speed*v.direction,vy:0,hoppingWings:true,grounded:false,source:{...enemy.source,smart:false,red:false,jumping:true,floating:false}});return enemy;}
  if(v.kind==='pipe-piranha'){Object.assign(enemy,{type:'piranha',w:16,h:24,vx:0,vy:0,homeX:enemy.x,homeY:enemy.y,clipTop:enemy.y+24,source:{...enemy.source,studyPipePlant:true}});return enemy;}
  if(v.kind==='vertical-koopa'){Object.assign(enemy,{type:'koopa',w:16,h:24,vx:0,vy:v.speed*v.direction,verticalFlight:true,flightDirection:v.direction,grounded:false,support:null,source:{...room.markers?.find(m=>m.id===enemy.id)?.source,...enemy.source,smart:true,red:true,jumping:true,floating:true}});return enemy;}
  const center=enemy.x+enemy.w/2,bottom=enemy.y+enemy.h;enemy.x=center-v.w/2;enemy.y=bottom-v.h;enemy.w=v.w;enemy.h=v.h;enemy.type='study-piranha';enemy.vx=0;enemy.source={...enemy.source,studyFloorPlant:true,giant:v.size==='giant',winged:v.winged,...(v.stackedOn?{stackedOn:v.stackedOn}:{}),...(v.fire?{fire:true}: {})};return enemy;}
 function stackSupport(id){const v=own(spec.enemyVariants,id);return own(spec.enemyStacks,id)??(v?.kind==='floor-piranha'?v.stackedOn??null:null);}
 function enemyContact(enemy){const v=own(spec.enemyVariants,typeof enemy==='string'?enemy:enemy?.id),kind=v?.kind??enemy?.smm2EnemyKind;if(kind==='dry-bones')return dryBones.contactRule(enemy);if(kind==='muncher')return{harmful:true,stompable:false,shoeStompable:false,fireImmune:true,shellImmune:true,starImmune:true,solidTop:true};if(kind==='fire-piranha-shot')return{harmful:true,stompable:false,shoeStompable:false,fireImmune:true,shellImmune:true,solidTop:false};if(['floor-piranha','pipe-piranha'].includes(kind))return{harmful:true,stompable:false,shoeStompable:false,fireImmune:false,shellImmune:false,solidTop:false};return null;}
 const dryBonesContact=(enemy,context={})=>dryBones.playerEnemyContact(enemy,{tick:currentTick,...context});
 const stackSupportEligible=enemy=>dryBones.ownsActor(enemy)?dryBones.supportEligible(enemy):!!enemy&&!enemy.dead;
 function stepSourceEmergence(enemy,tick){const phase=enemy.moduleEmergence;if(!phase)return false;if(phase.lastTick===tick)return true;phase.lastTick=tick;phase.remainingFrames=Math.max(0,phase.remainingFrames-1);const progress=1-phase.remainingFrames/phase.totalFrames;enemy.x=phase.startX+(phase.targetX-phase.startX)*progress;enemy.y=phase.startY+(phase.targetY-phase.startY)*progress;enemy.vx=0;enemy.vy=0;enemy.grounded=false;enemy.support=null;
  if(!phase.remainingFrames){enemy.x=phase.targetX;enemy.y=phase.targetY;enemy.homeX=enemy.x;enemy.homeY=enemy.y;enemy.vx=phase.launchVx;enemy.vy=phase.launchVy;delete enemy.moduleEmergence;delete enemy.sourceClip;diagnostic('enemy-source-emerged',{sourceId:phase.sourceId,actorId:enemy.id});}return true;
 }
 function stepEnemy(enemy,{tick=currentTick,geometry=[],player=null,canStand}={}){if(enemy.dead)return false;if(stepSourceEmergence(enemy,tick))return true;
  if(dryBones.ownsActor(enemy)){dryBones.stepEnemy(enemy,{tick,canStand});return false;}
  if(enemy.moduleProjectile===true&&enemy.smm2EnemyKind==='fire-piranha-shot'){if(flightFrames.get(enemy)===tick)return true;flightFrames.set(enemy,tick);enemy.x+=enemy.vx;enemy.y+=enemy.vy;enemy.remainingFrames--;if(enemy.remainingFrames<=0||enemy.x+enemy.w<0||enemy.x>room.map.width||enemy.y+enemy.h<0||enemy.y>room.map.height||geometry.some(q=>!q.hidden&&q.collision==='solid'&&overlap(enemy,q)))enemy.dead=true;return true;}
  const v=own(spec.enemyVariants,enemy.id);if(v?.kind==='muncher'){if(flightFrames.get(enemy)!==tick){flightFrames.set(enemy,tick);enemy.vx=0;stepStudyEnemy(enemy,geometry.filter(q=>['solid','oneway'].includes(q.collision)),room.map.width);}return true;}
  if(v?.kind==='pipe-piranha'){let phase=enemy.age%(v.hiddenFrames+v.riseFrames+v.outFrames+v.fallFrames);const near=player&&Math.abs(player.x+player.w/2-enemy.homeX-enemy.w/2)<v.nearRadius;if(near&&phase<=v.hiddenFrames){enemy.age=0;phase=0;}const riseEnd=v.hiddenFrames+v.riseFrames,outEnd=riseEnd+v.outFrames;const depth=phase<v.hiddenFrames?enemy.h:phase<riseEnd?enemy.h*(riseEnd-phase)/v.riseFrames:phase<outEnd?0:enemy.h*(phase-outEnd)/v.fallFrames;enemy.y=enemy.homeY+depth;return true;}if(v?.kind!=='vertical-koopa'||!enemy.verticalFlight||enemy.shell)return false;
  if(flightFrames.get(enemy)===tick)return true;flightFrames.set(enemy,tick);let direction=enemy.flightDirection||v.direction,next=enemy.y+direction*v.speed;
  if(next>v.maxY){next=v.maxY-(next-v.maxY);direction=-1;}else if(next<v.minY){next=v.minY+(v.minY-next);direction=1;}
  const oldY=enemy.y;for(const q of geometry){if(q.hidden||enemy.x+enemy.w<=q.x||enemy.x>=q.x+q.w)continue;if(next>oldY&&['solid','oneway'].includes(q.collision)&&oldY+enemy.h<=q.y+.01&&next+enemy.h>q.y){next=q.y-enemy.h;direction=-1;}else if(next<oldY&&q.collision==='solid'&&oldY>=q.y+q.h-.01&&next<q.y+q.h){next=q.y+q.h;direction=1;}}
  enemy.y=next;enemy.vy=direction*v.speed;enemy.vx=0;enemy.flightDirection=direction;enemy.grounded=false;enemy.support=null;return true;
 }
 function fireShots(enemy,{tick=currentTick,player=null,projectiles=[]}={}){const v=own(spec.enemyVariants,enemy.id);if(!v?.fire||enemy.dead||enemy.studyActivated===false||enemy.moduleEmergence)return[];const state=fireClocks.get(enemy)||{clock:v.fireInitialDelayFrames,lastTick:null};if(state.lastTick===tick)return[];state.lastTick=tick;fireClocks.set(enemy,state);if(state.clock>0){state.clock--;return[];}if(projectiles.filter(e=>!e.dead&&e.moduleProjectile===true&&e.moduleSource===enemy.id).length>=32)return[];
  const direction=v.fireDirection==='left'?-1:v.fireDirection==='right'?1:player&&player.x+player.w/2<enemy.x+enemy.w/2?-1:1,w=8,h=8,x=direction<0?enemy.x-w:enemy.x+enemy.w,y=enemy.y+Math.min(10,enemy.h/4)-h/2;
  const shot={id:runtimeId('module-plant-fire-'+(++projectileSerial)),kind:'walker',type:'bowserfire',smm2EnemyKind:'fire-piranha-shot',moduleProjectile:true,moduleSource:enemy.id,x,y,w,h,vx:direction*v.fireVx,vy:v.fireVy,age:0,remainingFrames:v.fireLifetimeFrames,homeX:x,homeY:y,hp:1,dead:false};state.clock=v.fireIntervalFrames-1;enemy.facing=direction;diagnostic('fire-piranha-shot',{actorId:enemy.id,projectileId:shot.id,direction});return[shot];
 }
 function stompEnemy(enemy,context={}){if(dryBones.ownsActor(enemy))return dryBonesContact(enemy,{attack:'stomp',...context});if(enemy.hoppingWings&&own(spec.enemyVariants,enemy.id)?.kind==='hopping-koopa'){enemy.hoppingWings=false;enemy.vy=0;enemy.source={...enemy.source,jumping:false,floating:false};diagnostic('koopa-wings-lost',{actorId:enemy.id});return true;}if(!enemy.verticalFlight||own(spec.enemyVariants,enemy.id)?.kind!=='vertical-koopa')return false;
  enemy.verticalFlight=false;enemy.vx=-.5;enemy.vy=0;enemy.grounded=false;enemy.support=null;enemy.source={...enemy.source,jumping:false,floating:false};diagnostic('koopa-wings-lost',{actorId:enemy.id});return true;
 }
 function beforeEnemy(enemy){const v=own(spec.enemyVariants,enemy.id);if(!v?.winged||enemy.dead||enemy.studyActivated===false)return false;let clock=(wingClocks.get(enemy)||0)+1;if(enemy.grounded&&clock>=v.hopIntervalFrames){release(enemy,v.hopSpeed);clock=0;wingClocks.set(enemy,clock);diagnostic('wing-hop',{actorId:enemy.id});return true;}wingClocks.set(enemy,clock);return false;}
 function reset(){dryBones.reset();currentTick=0;lastRewardTick=null;projectileSerial=0;contactFrames=new WeakMap();wingClocks=new WeakMap();flightFrames=new WeakMap();sourceFrames.clear();fireClocks=new WeakMap();compressionActors=new WeakMap();lastNoteTick=null;resetNotes();for(const actor of enemyNoteMotions.keys())forgetEnemyMotion(actor);runtimeIds.clear();runtimeVariants.clear();platformStates.clear();motionStates.clear();rewardWindows.clear();bumps.clear();for(const q of allSources)sourceStates.set(q.id,{active:false,clock:q.initialDelayFrames,emitted:0});}
 const coinValue=id=>own(spec.coinValues,id)??1,rewardLimit=id=>own(spec.rewardLimits,id);
 const noteRule=id=>notes.has(id)?clone(notes.get(id)):null;
 const scaleRule=id=>own(spec.scaleRules,id)||null;
 const portalRule=id=>own(spec.portalDirections,id)?clone(spec.portalDirections[id]):null,arrivalRule=id=>own(spec.arrivalDirections,id)?clone(spec.arrivalDirections[id]):null;
 function coinWindowExpired(id){const frames=own(spec.rewardWindows,id);if(frames===undefined)return false;if(!rewardWindows.has(id)){rewardWindows.set(id,frames);return false;}return rewardWindows.get(id)<=0;}
 function hoppingImpulse(id){const v=own(spec.enemyVariants,id);return v?.kind==='hopping-koopa'?v.hopSpeed:null;}
 function view(){return {version:1,...(spec.carryEnemiesOnPlatforms===undefined?{}:{carryEnemiesOnPlatforms:spec.carryEnemiesOnPlatforms}),itemSources:spec.itemSources.map(q=>({...q,...sourceStates.get(q.id)})),enemySources:(spec.enemySources||[]).map(q=>({...clone(q),...sourceStates.get(q.id)})),noteBlocks:spec.noteBlocks.map(notePose),oneWayWalls:clone(spec.oneWayWalls),enemyVariants:clone(spec.enemyVariants),...(Object.values(spec.enemyVariants).some(v=>v.kind==='dry-bones')?{dryBones:dryBones.view()}:{}),...(spec.enemyStacks===undefined?{}:{enemyStacks:clone(spec.enemyStacks)}),...(spec.motionPlatforms===undefined?{}:{motionPlatforms:clone(spec.motionPlatforms)}),...(spec.contactPlatforms===undefined?{}:{contactPlatforms:clone(spec.contactPlatforms)}),...(spec.scaleRules===undefined?{}:{scaleRules:clone(spec.scaleRules)}),...(spec.entryWalkToPortal===undefined?{}:{entryWalkToPortal:clone(spec.entryWalkToPortal)}),...(spec.goalScoreUnitsPerFrame===undefined?{}:{goalScoreUnitsPerFrame:spec.goalScoreUnitsPerFrame}),...(spec.castleFlagWaitFrames===undefined?{}:{castleFlagWaitFrames:spec.castleFlagWaitFrames}),...(spec.castleFlagRiseFrames===undefined?{}:{castleFlagRiseFrames:spec.castleFlagRiseFrames}),...(spec.fireKillPoints===undefined?{}:{fireKillPoints:spec.fireKillPoints}),...(spec.starFrames===undefined?{}:{starFrames:spec.starFrames}),...(spec.starKillPoints===undefined?{}:{starKillPoints:spec.starKillPoints}),...(spec.rewardWindows===undefined?{}:{rewardWindows:clone(spec.rewardWindows)}),coinValues:clone(spec.coinValues||{}),rewardLimits:clone(spec.rewardLimits||{}),portalDirections:clone(spec.portalDirections||{}),arrivalDirections:clone(spec.arrivalDirections||{})};}
 return Object.freeze({ownsLauncher:id=>(spec.enemySources||[]).some(q=>q.emitterKind==='launcher'&&q.launcherId===id),carriesEnemiesOnPlatforms:()=>spec.carryEnemiesOnPlatforms===true,entryWalkPortal:spawnId=>spec.entryWalkToPortal?.spawnId===spawnId?spec.entryWalkToPortal.portalId:null,switchCrushEnabled:()=>spec.switchCrush===true,frameNotes,ownsCompression,ownsNoteCompression:ownsCompression,geometry,noteRule,stepPlatform,updatePlatforms,spawnItems,spawnEnemies,afterActor,bumpNote,enemyVariant,applyEnemyVariant,enemyContact,dryBonesContact,stackSupport,stackSupportEligible,usesGenericStack:id=>Object.hasOwn(spec.enemyStacks||{},id),fireShots,stepEnemy,stompEnemy,usesClassicEnemyCollision:id=>['hopping-koopa','dry-bones','walking-koopa'].includes((own(spec.enemyVariants,id)??runtimeVariants.get(id))?.kind),hoppingImpulse,coinWindowExpired,starDuration:()=>spec.starFrames??600,starKillPoints:()=>spec.starKillPoints,fireKillPoints:()=>spec.fireKillPoints,castleFlagFrames:()=>spec.castleFlagRiseFrames,goalScoreRate:()=>spec.goalScoreUnitsPerFrame??4,castleFlagWait:()=>spec.castleFlagWaitFrames??0, beforeEnemy,coinValue,rewardLimit,scaleRule,portalRule,arrivalRule,view,reset});
}
