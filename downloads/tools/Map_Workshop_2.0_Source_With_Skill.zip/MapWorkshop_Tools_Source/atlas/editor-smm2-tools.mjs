import {captureBowserJrBindings,appendCopiedBowserJrBindings,pruneBowserJrReferences} from './editor-bowser-jr-tools.mjs';
import {pruneSmm2LightingReferences} from './editor-smm2-lighting.mjs';
import {clone,validate,uid,linked,deleteSelection} from './editor-model.mjs';
import {captureSmm2GeometryBindings,appendSmm2GeometryBindings,pruneSmm2CourseReferences} from './editor-smm2-course-tools.mjs';
import {captureSmm2LightingBindings,appendCopiedSmm2LightingBindings} from './editor-smm2-lighting-tools.mjs';
import {createSMM2Terrain,sampleSMM2Surface} from './editor-smm2-terrain.mjs';
import {staticVines} from './editor-smm2-mechanics.mjs';
import {drawSmm2Actor,drawSmm2World} from './editor-smm2-art.mjs';
import {drawReference} from './editor-art.mjs';
import {SMM2_SHOE_TUNING} from './editor-smm2-shoes.mjs';
import {smm2ShoeVisualBounds} from './editor-smm2-shoe-art.mjs';
import {smm2ItemRailAnchor} from './editor-smm2-items.mjs';
import {createConveyorSurfaces,validateConveyorsRoom,CONVEYOR_CONTACT_MODE,CONVEYOR_PARAMETER_STATUS,CONVEYOR_COORDINATE_LIMIT} from './editor-conveyor-surfaces.mjs';
import {drawConveyorSurface} from './editor-walking-koopa-art.mjs';
export {conveyorPlacementIssues as conveyorAuthoringIssues} from './editor-conveyor-surfaces.mjs';

// Neutral component defaults are author tuning,
// not calibrated SMM2 constants. Importer/controller validators own all limits.
const number=(label,value)=>({label,value,type:'number'}),choice=(label,value,choices)=>({label,value,choices}),check=(label,value)=>({label,value,type:'checkbox'});
const body={x:number('左边 X（像素）',128),y:number('顶部 Y（像素）',80),w:number('宽（像素）',16),h:number('高（像素）',16)};
const falling={gravity:number('重力 / 帧',.3),maxFallSpeed:number('最大下落速度',4.25)};
const shoeTuningLabels={gravity:'鞋重力 / 帧',maxFallSpeed:'鞋最大下落速度',npcSpeed:'栗宝宝横向速度',npcHopSpeed:'栗宝宝弹跳速度',npcWingHopSpeed:'带翼栗宝宝弹跳速度',npcHopFrames:'栗宝宝弹跳间隔帧',seatInset:'乘员座位下沉像素',npcHeadHeight:'栗宝宝头部高度',boardingTolerance:'上鞋顶面接触容差',stompBounceSpeed:'踩敌人反弹速度',ejectSpeed:'下鞋上升速度',groundPoundSpeed:'Big 鞋砸地下落速度',flutterFrames:'带翼空中延缓帧数',flutterFallSpeed:'带翼延缓下落速度',walkHopSpeed:'行走小跳速度',walkHopFrames:'行走小跳间隔帧',remountLockFrames:'下鞋后再上鞋等待帧',blastSpeed:'Big 高跟鞋气波速度',blastRange:'气波最大距离',blastWidth:'气波宽',blastHeight:'气波高',blastLifetimeFrames:'气波存续帧'};
const shoeTuningFields=Object.fromEntries(Object.entries(SMM2_SHOE_TUNING).map(([key,value])=>['tuning.'+key,number(shoeTuningLabels[key]||key,value)]));
const valueAt=(values,key)=>key.split('.').reduce((v,k)=>v?.[k],values);
function setValue(values,key,value){const path=key.split('.');let parent=values;for(const part of path.slice(0,-1))parent=parent[part]??={};parent[path.at(-1)]=value;}

export const smm2ComponentTypes=Object.freeze({
 thwomp:{label:'咚咚 Thwomp',leaf:'thwomps',native:'walker',fields:{...body,w:number('碰撞宽',24),h:number('碰撞高',32),direction:choice('冲撞方向','down',[['down','下'],['left','左'],['right','右']]),triggerRange:number('感应距离',160),transverseTolerance:number('横向容差',16),leadReference:choice('感应参考','near-edge',[['near-edge','近边'],['center','中心']]),windupFrames:number('蓄力帧数',12),chargeAcceleration:number('冲撞加速度',.32),chargeSpeedCap:number('最高冲撞速度',6),impactWaitFrames:number('撞击后等待帧数',45),returnSpeed:number('返回速度',1),breakMaterials:check('可撞碎普通砖',true),winged:check('带翅膀',false),mass:number('质量',1),oneWaySupportIds:{label:'承接单向平台 ID（逗号分隔）',value:[],type:'text'}}},
 donut:{label:'甜甜圈 Donut',leaf:'donuts',fields:{...body,delayFrames:number('踩踏后下落帧数',30),gravity:number('重力 / 帧',.18),maxFallSpeed:number('最大下落速度',4),triggerPolicy:choice('踩踏触发者','all-actors',[['all-actors','所有实体'],['player','玩家'],['explicit','显式标记实体']]),resetPolicy:choice('离开后的计时','leave-before-drop',[['leave-before-drop','下落前离开会重置'],['continue','继续计时']]),collision:choice('碰撞','oneway',[['oneway','单向顶面'],['solid','实心']])}},
 slope:{label:'地面 / 天花板斜坡',leaf:'slopes',fields:{...body,w:number('宽（像素）',64),h:number('对角线垂直落差 h（像素）',32),thickness:{...number('薄斜坡垂直厚度（像素；留空为原三角形）',''),optional:true},orientation:choice('斜坡方向','rise-right',[['rise-right','地面：向右上升'],['rise-left','地面：向左上升'],['ceiling-rise-right','天花板：向右上升'],['ceiling-rise-left','天花板：向左上升']])},fixed:{collision:'solid'}},
 seesaw:{label:'跷跷板 Seesaw',leaf:'seesaws',fields:{pivotX:number('轴心 X',128),pivotY:number('轴心 Y',128),length:number('长度',128),thickness:number('厚度',8),initialAngleDegrees:number('初始角度',0),maxAngleDegrees:number('最大角度',24),weightAcceleration:number('重量加速度',.07),maxAngularSpeedDegrees:number('最大转速（度 / 帧）',2),damping:number('阻尼',.985),impactSpeedThreshold:number('冲击速度门槛',2),impactGain:number('冲击倍率',2),maxLaunchSpeed:number('最大弹射速度',8),impactMinLeverFraction:number('最小力臂比例',.12),impactPolicy:choice('冲击来源','thwomp',[['thwomp','咚咚'],['explicit','显式标记实体']])}},
 vine:{label:'静态藤蔓',leaf:'vines',fields:{...body,h:number('高（像素）',64),climbSpeed:number('攀爬速度',1.4)}},
pow:{label:'POW 方块',leaf:'powBlocks',native:'walker',fields:{...body,...falling,blastRadius:number('局部模式半径',128),supportedScreenEffect:check('屏内接地目标模式',true)},extra:['rail']},
 pSwitch:{label:'预置 P 开关',leaf:'pSwitches',native:'walker',fields:{...body,orientation:choice('按压方向','up',[['up','直立：从上踩'],['down','倒挂：从下头顶']]),gravity:number('重力 / 帧（固定倒挂用 0）',0),maxFallSpeed:number('最大下落速度',4.25)},extra:['rail']},
 helmet:{label:'预置钢盔 Buzzy',leaf:'helmets',native:'walker',fields:{...body,...falling}},
 skewer:{label:'尖刺柱 Skewer',leaf:'skewers',native:'hazard',fields:{...body,w:number('底座宽',32),h:number('底座高',24),direction:choice('伸出方向','down',[['down','下'],['up','上'],['left','左'],['right','右']]),travel:number('伸出距离',96),extendSpeed:number('伸出速度',3),retractSpeed:number('收回速度',2),waitFrames:number('等待帧数',72),holdFrames:number('停留帧数',42),loadDistance:number('近屏激活距离',384),phaseOffsetFrames:number('初始周期偏移帧数',0)}},
 pinkCoin:{label:'粉红金币',leaf:'pinkCoins',native:'coin',fields:{...body,w:number('碰撞宽',8),h:number('碰撞高',14)}},
 shoe:{label:'栗宝宝鞋 / 高跟鞋',leaf:'shoes',native:'walker',shoeDimensions:true,fields:{...body,kind:choice('鞋样式','shoe',[['shoe','栗宝宝鞋'],['stiletto','高跟鞋']]),size:choice('尺寸','small',[['small','普通（默认 16×16）'],['big','Big（默认 32×32）']]),winged:check('带翅膀',false),occupant:choice('初始乘员','goomba',[['goomba','栗宝宝'],['empty','空鞋']]),crouchCompatible:check('允许乘员下蹲',true),...shoeTuningFields},extra:['tuning']},
 placed1UP:{label:'预置 1UP',leaf:'placedItems',native:'walker',fields:{...body,...falling,points:number('拾取分数（0–100000）',0)},fixed:{kind:'life'},extra:['rail']},
 placedMushroom:{label:'预置蘑菇 Mushroom',leaf:'placedItems',native:'walker',fields:{...body,...falling,initialVx:{...number('自由蘑菇初始水平速度（轨道物件留空）',''),optional:true},points:number('拾取分数（0–100000）',1000)},fixed:{kind:'mushroom'},extra:['rail']},
 placedStar:{label:'预置无敌星 Star',leaf:'placedItems',native:'walker',fields:{...body,...falling,points:number('拾取分数（0–100000）',0)},fixed:{kind:'star'},extra:['rail']}
});
const actorLeaves=[...new Set(Object.values(smm2ComponentTypes).filter(q=>q.native).map(q=>q.leaf))];
const terrainLeaves=['donuts','slopes','seesaws','vines','conveyors'];
const defaults=type=>{const d=definition(type),values={...d.fixed};for(const [key,q]of Object.entries(d.fields))if(!q.optional)setValue(values,key,clone(key==='breakMaterials'?(q.value?['brick']:[]):q.value));return values;};
function definition(type){if(!Object.hasOwn(smm2ComponentTypes,type))throw Error('未知 SMM2 组件');return smm2ComponentTypes[type];}
function optionsFor(type,options){const d=definition(type);if(!options||typeof options!=='object'||Array.isArray(options)||![Object.prototype,null].includes(Object.getPrototypeOf(options)))throw Error('Invalid SMM2 authoring options');for(const k of Object.keys(options))if(!['id',...Object.keys(d.fields).filter(k=>!k.includes('.')),...Object.keys(d.fixed||{}),...(d.extra||[])].includes(k))throw Error('Unknown SMM2 authoring field: '+k);if(d.fixed?.kind&&options.kind!==undefined&&options.kind!==d.fixed.kind)throw Error('SMM2 component kind cannot change');for(const [key,field]of Object.entries(d.fields))if(field.optional&&field.type==='number'&&options[key]!==undefined&&options[key]!==null&&!Number.isFinite(options[key]))throw Error('Invalid SMM2 optional number: '+key);return clone(options);}
function edit(room,fn){const next=clone(room);fn(next);pruneSmm2LightingReferences(next,room);for(const q of listSmm2Components(next).filter(q=>q.actor)){const a=q.actor;if(!['x','y','w','h'].every(k=>Number.isFinite(a[k]))||a.x<0||a.y<0||a.w<=0||a.h<=0||a.x+a.w>next.map.width||a.y+a.h>next.map.height)throw Error('SMM2 native body outside room');}validate({format:'xiaoq-map-project',version:1,id:'smm2-tools-validation',title:'SMM2 authoring',rooms:[next]},{allowIncompleteCompletionMarks:true});for(const k of Object.keys(room))if(!Object.hasOwn(next,k))delete room[k];Object.assign(room,next);}
function leaves(room){return room.smm2Mechanics??={version:1};}
function allIds(room){return [...room.map.geometry,...room.map.objects,...room.markers,...room.decorations,...terrainLeaves.flatMap(key=>room.smm2Mechanics?.[key]||[])].map(q=>q.id);}

const CONVEYOR_FIELDS=['id','topEndpoints','visual','speedPxPerSecond','visualTreadSpeedPxPerSecond','treadPeriodPx','directionOn','contactMode','parameterStatus'];
export function defaultSmm2Conveyor(){return {topEndpoints:[{x:128,y:80},{x:256,y:80}],visual:{kind:'rect',rect:{x:128,y:80,w:128,h:16},rollerCenters:[{x:136,y:88},{x:248,y:88}],rollerRadiusPx:8},speedPxPerSecond:60,visualTreadSpeedPxPerSecond:120,directionOn:1,contactMode:CONVEYOR_CONTACT_MODE,parameterStatus:CONVEYOR_PARAMETER_STATUS};}
function conveyorOptions(options){if(!options||typeof options!=='object'||Array.isArray(options)||![Object.prototype,null].includes(Object.getPrototypeOf(options))||Object.keys(options).some(k=>!CONVEYOR_FIELDS.includes(k)))throw Error('Unknown conveyor authoring fields');return structuredClone(options);}
function conveyorById(room,id){const matches=(room.smm2Mechanics?.conveyors||[]).filter(q=>q.id===id);if(matches.length!==1)throw Error('请选择一个已有 ON/OFF 传送带');return matches[0];}
export function listSmm2Conveyors(room){return (room.smm2Mechanics?.conveyors||[]).map(spec=>({id:spec.id,type:'conveyor',label:'ON/OFF 传送带',spec,actor:null}));}
export function addSmm2Conveyor(room,options={}){const values=conveyorOptions(options),id=values.id===undefined?'conveyor-'+globalThis.crypto.randomUUID():values.id,spec={...defaultSmm2Conveyor(),...values,id};validateConveyorsRoom([spec],{width:room.map.width,height:room.map.height});edit(room,r=>{if(allIds(r).includes(id))throw Error('Duplicate conveyor component ID');(leaves(r).conveyors??=[]).push(spec);});return id;}
export function updateSmm2Conveyor(room,id,options={}){const values=conveyorOptions(options);if(values.id!==undefined&&values.id!==id)throw Error('Conveyor component ID cannot change');edit(room,r=>{const previous=conveyorById(r,id);r.smm2Mechanics.conveyors=r.smm2Mechanics.conveyors.map(q=>q.id===id?{...previous,...values,id}:q);});}
export function removeSmm2Conveyor(room,id){edit(room,r=>{conveyorById(r,id);r.smm2Mechanics.conveyors=r.smm2Mechanics.conveyors.filter(q=>q.id!==id);});}
export function cloneSmm2Conveyor(room,id,options={}){if(!options||typeof options!=='object'||Array.isArray(options)||![Object.prototype,null].includes(Object.getPrototypeOf(options))||Object.keys(options).some(k=>!['id','dx','dy'].includes(k)))throw Error('Unknown conveyor clone fields');const {id:copyId,dx=16,dy=32}=options;if(!Number.isFinite(dx)||!Number.isFinite(dy))throw Error('复制传送带偏移必须为有限数值');const spec=structuredClone(conveyorById(room,id));delete spec.id;for(const p of [...spec.topEndpoints,...spec.visual.rollerCenters]){p.x+=dx;p.y+=dy;}spec.visual.rect.x+=dx;spec.visual.rect.y+=dy;return addSmm2Conveyor(room,{...spec,...(copyId!==undefined?{id:copyId}:{})});}

/** Explicit regular-NPC top contact on existing STATIC vertical Springs.
 * Tuning is independent of the player spring rule and is not universal. */
export function setSmm2NpcSpringContact(room,id,options){if(!options||typeof options!=='object'||Array.isArray(options)||![Object.prototype,null].includes(Object.getPrototypeOf(options))||Object.keys(options).some(k=>!['compressionFrames','launchSpeed','compressionDepth'].includes(k)))throw Error('Unknown NPC Spring authoring fields');edit(room,r=>{const s=leaves(r),old=s.springs?.find(q=>q.id===id);if(!old)throw Error('请先绑定已有竖向弹簧规则，再配置 NPC 顶面接触');s.springs=s.springs.map(q=>q.id===id?{...old,npcContact:structuredClone(options)}:q);});}
export function clearSmm2NpcSpringContact(room,id){edit(room,r=>{const rule=r.smm2Mechanics?.springs?.find(q=>q.id===id);if(!rule)throw Error('请选择已有弹簧规则');delete rule.npcContact;});}
function parts(type,options){const d=definition(type),values={...defaults(type),...(d.shoeDimensions?{w:options.size==='big'?32:16,h:options.size==='big'?32:16}:{}),...options},keys=['id',...Object.keys(d.fields).filter(k=>!k.includes('.')),...Object.keys(d.fixed||{}),...(d.extra||[])].filter(k=>!d.native||!['x','y','w','h'].includes(k)),leaf=Object.fromEntries(keys.filter(k=>Object.hasOwn(values,k)&&!(d.fields[k]?.optional&&values[k]===null)).map(k=>[k,values[k]]));return {leaf,actor:d.native?{id:values.id,kind:d.native,x:values.x,y:values.y,w:values.w,h:values.h}:null};}
function springSupportSettings(options){
 if(options===undefined)return {};if(!options||typeof options!=='object'||Array.isArray(options)||![Object.prototype,null].includes(Object.getPrototypeOf(options))||Object.keys(options).some(k=>!['carrierType','mass','gravity','maxFallSpeed'].includes(k))||options.carrierType!=='seesaw'||![['mass',.001,10000],['gravity',.001,4],['maxFallSpeed',.001,64]].every(([k,min,max])=>Number.isFinite(options[k])&&options[k]>=min&&options[k]<=max))throw Error('请选择跷跷板类型并填写作者近似质量、重力和最大下落速度');return clone(options);
}
/** Bind authored native Spring geometry to an existing moving top atomically. */
export function bindSmm2SpringSupport(room,springId,carrierId,options){
 const settings=springSupportSettings(options);
 edit(room,r=>{const s=leaves(r);s.carrierGeometry=[...(s.carrierGeometry||[]).filter(q=>q.id!==springId),{id:springId,carrierId,...settings}];});
}
/** Explicit author action: move only source y to the actual initial top sampled
 * under this body's finite feet, then bind in the same validated transaction.
 * Strict bind/import and runtime contact never invoke this alignment helper. */
export function alignSmm2SpringToSeesawSupport(room,springId,carrierId,options){
 const settings=springSupportSettings(options);if(settings.carrierType!=='seesaw')throw Error('对齐需要明确选择跷跷板类型并填写作者近似参数');
 edit(room,r=>{const spring=r.map.geometry.find(q=>q.id===springId);if(!spring||spring.material!=='spring'||spring.collision!=='solid'||spring.motion||spring.liftSpeed||![16,32].includes(spring.w)||spring.h!==spring.w||spring.springOrientation==='horizontal'||r.smm2Mechanics?.springs?.some(q=>q.id===springId&&q.orientation==='horizontal'))throw Error('对齐需要独立竖向原生弹簧，静止身体为 16×16 或作者 2× 的 32×32');if(!r.smm2Mechanics?.seesaws?.some(q=>q.id===carrierId))throw Error('对齐需要本区域已有的真实跷跷板');const surface=createSMM2Terrain(r)?.surfaces().find(q=>q.id===carrierId&&q.kind==='seesaw'),top=surface&&sampleSMM2Surface(surface,spring.x,spring.w);if(!top)throw Error('弹簧脚底与跷跷板真实顶面没有横向重叠；请先调整 X 位置');spring.y=top.y-spring.h;const s=leaves(r);s.carrierGeometry=[...(s.carrierGeometry||[]).filter(q=>q.id!==springId),{id:springId,carrierId,...settings}];});
}
/** Explicit author sizing; native brush Springboards keep their legacy size
 * until this button/API is used. Preserve the current foot anchor and ID. */
export function setSmm2SpringRestBodySize(room,springId,size){
 if(![16,32].includes(size))throw Error('弹簧静止身体尺寸只能是 16×16 或作者 2× 的 32×32');edit(room,r=>{const spring=r.map.geometry.find(q=>q.id===springId);if(!spring||spring.material!=='spring'||spring.collision!=='solid'||spring.motion||spring.liftSpeed||spring.springOrientation==='horizontal'||r.smm2Mechanics?.springs?.some(q=>q.id===springId&&q.orientation==='horizontal'))throw Error('请选择独立竖向原生弹簧来调整静止身体尺寸');spring.y+=spring.h-size;spring.w=spring.h=size;if(spring.x<0||spring.y<0||spring.x+spring.w>r.map.width||spring.y+spring.h>r.map.height)throw Error('弹簧静止身体超出地图范围');});
}
export function unbindSmm2SpringSupport(room,springId){edit(room,r=>{const s=leaves(r);s.carrierGeometry=(s.carrierGeometry||[]).filter(q=>q.id!==springId);});}
/** Opt in only an existing POW to a real moving top; no rigid item mount. */
export function bindSmm2PowSupport(room,powId,carrierId){edit(room,r=>{const s=leaves(r);s.carrierItems=[...(s.carrierItems||[]).filter(q=>q.id!==powId),{id:powId,carrierId}];});}
export function unbindSmm2PowSupport(room,powId){edit(room,r=>{if(r.smm2Mechanics)r.smm2Mechanics.carrierItems=(r.smm2Mechanics.carrierItems||[]).filter(q=>q.id!==powId);});}
/** Annotate an existing native checkpoint; this never creates a spawn object. */
export function setSmm2CheckpointReward(room,id,{reward='none',points=0,...unknown}={}){
 if(Object.keys(unknown).length)throw Error('Unknown checkpoint reward authoring field');
 if(!['none','mushroom','star'].includes(reward))throw Error('Unknown checkpoint reward kind');
 edit(room,r=>{const s=leaves(r);s.checkpointRewards=[...(s.checkpointRewards||[]).filter(q=>q.id!==id),{id,reward,points}];});
}
export function clearSmm2CheckpointReward(room,id){edit(room,r=>{if(!r.map.objects.some(q=>q.id===id&&q.kind==='checkpoint'))throw Error('Checkpoint reward must reference an existing native checkpoint');const s=leaves(r);s.checkpointRewards=(s.checkpointRewards||[]).filter(q=>q.id!==id);});}

/** Bound score for an existing native actor removed during real goal contact. */
export function setSmm2GoalEnemyReward(room,id,{points=0,...unknown}={}){
 if(Object.keys(unknown).length)throw Error('Unknown goal enemy reward authoring field');
 edit(room,r=>{const s=leaves(r);s.goalEnemyRewards=[...(s.goalEnemyRewards||[]).filter(q=>q.id!==id),{id,points}];});
}
export function clearSmm2GoalEnemyReward(room,id){edit(room,r=>{if(!r.map.objects.some(q=>q.id===id&&q.kind==='walker'))throw Error('Goal enemy reward must reference an existing native walker');const s=leaves(r);s.goalEnemyRewards=(s.goalEnemyRewards||[]).filter(q=>q.id!==id);});}
export function setSmm2FlagScore(room,enabled){if(typeof enabled!=='boolean')throw Error('Classic flag score must be a boolean');edit(room,r=>{leaves(r).flagScore=enabled;});}
export function clearSmm2FlagScore(room){edit(room,r=>{if(r.smm2Mechanics)delete r.smm2Mechanics.flagScore;});}

/** Opt in to real contact by shells that the player actually kicked to spin.
 * This room policy is not an actor flag and never grants authored ownership. */
export function setSmm2ShellCoinCollection(room,enabled){if(typeof enabled!=='boolean')throw Error('Shell coin collection must be a boolean');edit(room,r=>{leaves(r).shellCoinCollection=enabled;});}
export function clearSmm2ShellCoinCollection(room){edit(room,r=>{if(r.smm2Mechanics)delete r.smm2Mechanics.shellCoinCollection;});}

export function listSmm2Components(room){return Object.entries(smm2ComponentTypes).flatMap(([type,d])=>(room.smm2Mechanics?.[d.leaf]||[]).filter(spec=>!d.fixed?.kind||spec.kind===d.fixed.kind).map(spec=>({id:spec.id,type,label:d.label,spec,actor:d.native?room.map.objects.find(q=>q.id===spec.id):null})));}
function existing(room,id){const matches=listSmm2Components(room).filter(q=>q.id===id);if(matches.length!==1)throw Error('请选择一个已有 SMM2 组件');return matches[0];}
// Creation seeds may differ from optional-field semantics on an existing leaf.
function componentValues(q){return {...q.actor,...q.spec,...(definition(q.type).leaf==='placedItems'?{points:q.spec.points??0}:{})};}
export function addSmm2Component(room,type,options={}){
 const values=optionsFor(type,options),id=values.id||'smm2-'+type.toLowerCase()+'-'+globalThis.crypto.randomUUID();
 edit(room,r=>{if(allIds(r).includes(id)||listSmm2Components(r).some(q=>q.id===id))throw Error('Duplicate SMM2 component ID');const {leaf,actor}=parts(type,{...values,id}),d=definition(type);(leaves(r)[d.leaf]??=[]).push(leaf);if(actor)r.map.objects.push(actor);});return id;
}
/** Attach a P body at the actual declared rail sample, or detach with null. */
export function bindSmm2PSwitchRail(room,id,rail){edit(room,r=>{const q=existing(r,id);if(q.type!=='pSwitch')throw Error('请选择预置 P 开关');if(rail===null){delete q.spec.rail;return;}const anchor=smm2ItemRailAnchor(r,rail);q.spec.rail=clone(rail);q.actor.x=anchor.x-q.actor.w/2;q.actor.y=anchor.y-q.actor.h/2;});}
/** Give an existing native walker its Shoe meaning without resizing its feet. */
export function bindSmm2Shoe(room,id,options={}){
 const values=optionsFor('shoe',options);if(Object.keys(values).some(k=>['id','x','y','w','h'].includes(k)))throw Error('Shoe binding preserves the existing native foot body');
 edit(room,r=>{const actor=r.map.objects.find(q=>q.id===id&&q.kind==='walker');if(!actor)throw Error('SMM2 Shoe binding needs an existing native walker');if(listSmm2Components(r).some(q=>q.id===id))throw Error('Native foot body already owns an SMM2 component');const {kind,...physical}=actor,{leaf}=parts('shoe',{...physical,...values,id});(leaves(r).shoes??=[]).push(leaf);});return id;
}
export function updateSmm2Component(room,id,options={}){
 edit(room,r=>{const q=existing(r,id),d=definition(q.type),values=optionsFor(q.type,options);if(values.id!==undefined&&values.id!==id)throw Error('SMM2 component ID cannot change');const sizing=d.shoeDimensions&&values.size!==undefined&&values.size!==q.spec.size?{w:values.size==='big'?32:16,h:values.size==='big'?32:16}:{};const {leaf,actor}=parts(q.type,{...componentValues(q),...sizing,...values,...(d.shoeDimensions?{tuning:{...q.spec.tuning,...values.tuning}}:{}),id});leaves(r)[d.leaf]=leaves(r)[d.leaf].map(v=>v.id===id?leaf:v);if(actor)Object.assign(q.actor,actor);});
}
function pruneRemoved(room,removedObjects,removedSupports){const s=room.smm2Mechanics;if(!s)return;if(room.marioModules?.enemySources)room.marioModules.enemySources=room.marioModules.enemySources.filter(q=>q.enemy==='bone-shell'||!removedObjects.has(q.shoeTemplateId));for(const key of [...actorLeaves,'enemyRewards','checkpointRewards','goalEnemyRewards'])if(s[key])s[key]=s[key].filter(q=>!removedObjects.has(q.id));if(s.carrierGeometry)s.carrierGeometry=s.carrierGeometry.filter(q=>!removedObjects.has(q.carrierId)&&!removedSupports.has(q.id)&&!removedSupports.has(q.carrierId));if(s.carrierItems)s.carrierItems=s.carrierItems.filter(q=>!removedObjects.has(q.id)&&!removedObjects.has(q.carrierId)&&!removedSupports.has(q.carrierId));for(const q of s.thwomps||[])if(q.oneWaySupportIds)q.oneWaySupportIds=q.oneWaySupportIds.filter(id=>!removedSupports.has(id));}
/** Only remove references whose real native owner/support was deleted. Invalid
 * newly-added dangling leaves remain validator errors, never silently repaired. */
export function pruneSmm2DeletedReferences(room,before){
 pruneBowserJrReferences(room,before);
 const now=new Set(room.map.objects.map(q=>q.id)),supports=new Set([...room.map.geometry,...room.smm2Mechanics?.donuts||[]].filter(q=>q.collision==='oneway').map(q=>q.id));
 const geometryNow=new Set(room.map.geometry.map(q=>q.id)),seesawNow=new Set((room.smm2Mechanics?.seesaws||[]).map(q=>q.id)),removedCarrierIds=new Set([...before.map.geometry,...before.map.objects,...before.smm2Mechanics?.seesaws||[]].filter(q=>!now.has(q.id)&&!geometryNow.has(q.id)&&!seesawNow.has(q.id)).map(q=>q.id));if(room.smm2Mechanics?.carrierItems)room.smm2Mechanics.carrierItems=room.smm2Mechanics.carrierItems.filter(q=>!removedCarrierIds.has(q.id)&&!removedCarrierIds.has(q.carrierId));if(room.smm2Mechanics?.carrierGeometry)room.smm2Mechanics.carrierGeometry=room.smm2Mechanics.carrierGeometry.filter(q=>!removedCarrierIds.has(q.id)&&!removedCarrierIds.has(q.carrierId));
 pruneRemoved(room,new Set(before.map.objects.filter(q=>!now.has(q.id)).map(q=>q.id)),new Set([...before.map.geometry,...before.smm2Mechanics?.donuts||[]].filter(q=>q.collision==='oneway'&&!supports.has(q.id)).map(q=>q.id)));
}
export function removeSmm2Component(room,id){edit(room,r=>{const q=existing(r,id),d=definition(q.type);leaves(r)[d.leaf]=leaves(r)[d.leaf].filter(v=>v.id!==id);if(d.native)r.map.objects=r.map.objects.filter(v=>v.id!==id);pruneRemoved(r,new Set(d.native?[id]:[]),new Set([id]));});}
export function cloneSmm2Component(room,id,{id:copyId,dx=16,dy=0}={}){
 const q=existing(room,id);if(q.spec.rail)throw Error('轨道道具请保留原件；复制前需重新设计轨道锚点');if(!Number.isFinite(dx)||!Number.isFinite(dy))throw Error('复制偏移必须为数字');
 const d=definition(q.type),values=componentValues(q);if(!d.fields.kind)delete values.kind;if(d.fixed?.kind)values.kind=d.fixed.kind;delete values.id;
 // Native author bodies can have unrelated ABI metadata, never copy it into a
 // strict mechanics leaf. Keep only recognized settings plus the physical box.
 const options=Object.fromEntries(Object.entries(values).filter(([k])=>[...Object.keys(d.fields).filter(k=>!k.includes('.')),...Object.keys(d.fixed||{}),...(d.extra||[])].includes(k)));
 if(q.type==='seesaw'){options.pivotX+=dx;options.pivotY+=dy;}else{options.x+=dx;options.y+=dy;}let created;edit(room,r=>{created=addSmm2Component(r,q.type,{...options,...(copyId?{id:copyId}:{})});const light=r.smm2Mechanics?.lighting?.sources.find(v=>v.targetId===id);if(light&&d.native)r.smm2Mechanics.lighting.sources.push({...clone(light),targetId:created});});return created;
}
export function captureSmm2ActorLeaves(room,ids){return {bowserJuniors:captureBowserJrBindings(room,ids),...Object.fromEntries([...actorLeaves,'enemyRewards','checkpointRewards','goalEnemyRewards'].map(key=>[key,clone((room.smm2Mechanics?.[key]||[]).filter(q=>ids.has(q.id)))])),carrierItems:clone((room.smm2Mechanics?.carrierItems||[]).filter(q=>ids.has(q.id)&&ids.has(q.carrierId)))};}
/** Used inside the native editor's same History transaction as body paste. */
export function appendCopiedSmm2ActorLeaves(room,snapshot,idMap){
 for(const key of actorLeaves)for(const q of snapshot?.[key]||[])if(q.rail)throw Error('轨道道具复制需要新的轨道锚点；未粘贴任何组件');
 if(!Object.values(snapshot||{}).some(q=>q.length))return;
 edit(room,r=>{appendCopiedBowserJrBindings(r,snapshot?.bowserJuniors,idMap);for(const key of [...actorLeaves,'enemyRewards','checkpointRewards','goalEnemyRewards'])for(const q of snapshot?.[key]||[]){if(!idMap.has(q.id))throw Error('Copied SMM2 actor is missing its native body');const leaf={...clone(q),id:idMap.get(q.id)};if(leaf.oneWaySupportIds)leaf.oneWaySupportIds=leaf.oneWaySupportIds.map(id=>idMap.get(id)||id);if(key==='pinkCoins'&&leaves(r)[key]?.some(prior=>prior.id===leaf.id))continue;(leaves(r)[key]??=[]).push(leaf);}for(const q of snapshot?.carrierItems||[]){if(!idMap.has(q.id)||!idMap.has(q.carrierId))throw Error('Copied POW support is missing its copied child or parent');(leaves(r).carrierItems??=[]).push({id:idMap.get(q.id),carrierId:idMap.get(q.carrierId)});}});
}

/** A support group contains actual native bodies and their existing sidecars.
 * Its neutral clipboard can cross rooms; no body schema or placement exemption
 * is introduced. Copying a component alone still copies only that component. */
export function captureSmm2SupportGroup(room,carrierId){
 const component=listSmm2Components(room).find(q=>q.id===carrierId&&['seesaw','thwomp'].includes(q.type)),geometry=room.map.geometry.find(q=>q.id===carrierId&&(q.motion||q.liftSpeed));if(!component&&!geometry)throw Error('请选择现有跷跷板、移动平台或咚咚');
 const bindings=(room.smm2Mechanics?.carrierGeometry||[]).filter(q=>q.carrierId===carrierId),ids=new Set([carrierId,...bindings.map(q=>q.id)]),markers=room.markers.filter(q=>[...ids].some(id=>linked(q,id))),all=new Set([...ids,...markers.map(q=>q.id)]);
 return {version:1,carrierId,geometry:clone(room.map.geometry.filter(q=>ids.has(q.id))),objects:clone(room.map.objects.filter(q=>ids.has(q.id))),markers:clone(markers),seesaws:clone((room.smm2Mechanics?.seesaws||[]).filter(q=>ids.has(q.id))),actors:captureSmm2ActorLeaves(room,ids),geometryBindings:captureSmm2GeometryBindings(room,ids),lighting:captureSmm2LightingBindings(room,all)};
}
export function pasteSmm2SupportGroup(room,snapshot,{dx=16,dy=0}={}){
 if(!snapshot||snapshot.version!==1||!Number.isFinite(dx)||!Number.isFinite(dy))throw Error('复制组与偏移无效');const idMap=new Map();for(const q of [...snapshot.geometry,...snapshot.objects,...snapshot.seesaws]){if(idMap.has(q.id))throw Error('复制组存在重复身体 ID');idMap.set(q.id,uid());}if(!idMap.has(snapshot.carrierId))throw Error('复制组缺少真实载体');
 edit(room,r=>{
  for(const q of snapshot.geometry){const body={...clone(q),id:idMap.get(q.id),x:q.x+dx,y:q.y+dy};if(body.x<0||body.y<0||body.x+body.w>r.map.width||body.y+body.h>r.map.height)throw Error('复制组地形超出地图范围');if(body.motion){const shift=body.motion.axis==='x'?dx:dy;body.motion.min+=shift;body.motion.max+=shift;const limit=body.motion.axis==='x'?r.map.width:r.map.height,extent=body.motion.axis==='x'?body.w:body.h;if(body.motion.min<0||body.motion.max+extent>limit)throw Error('复制组运动范围超出地图');}r.map.geometry.push(body);}
  r.map.objects.push(...snapshot.objects.map(q=>({...clone(q),id:idMap.get(q.id),x:q.x+dx,y:q.y+dy})));
  for(const q of snapshot.markers){const owner=[...idMap.keys()].find(id=>linked(q,id));if(!owner)throw Error('复制组的标记缺少原生身体');const id=idMap.get(owner)+q.id.slice(owner.length);idMap.set(q.id,id);r.markers.push({...clone(q),id,x:q.x+dx,y:q.y+dy});}
  if(snapshot.seesaws.length)(leaves(r).seesaws??=[]).push(...snapshot.seesaws.map(q=>({...clone(q),id:idMap.get(q.id),pivotX:q.pivotX+dx,pivotY:q.pivotY+dy})));
  appendCopiedSmm2ActorLeaves(r,snapshot.actors,idMap);appendSmm2GeometryBindings(r,snapshot.geometryBindings,idMap);appendCopiedSmm2LightingBindings(r,snapshot.lighting,idMap);
 });return {carrierId:idMap.get(snapshot.carrierId),idMap};
}
export function removeSmm2SupportGroup(room,carrierId){
 const snapshot=captureSmm2SupportGroup(room,carrierId),ids=new Set([carrierId,...snapshot.geometry.map(q=>q.id),...snapshot.objects.map(q=>q.id)]);edit(room,r=>{const before=clone(r);deleteSelection(r,'geometry',ids);deleteSelection(r,'objects',ids);for(const key of terrainLeaves)if(r.smm2Mechanics?.[key])r.smm2Mechanics[key]=r.smm2Mechanics[key].filter(q=>!ids.has(q.id));pruneSmm2DeletedReferences(r,before);pruneSmm2CourseReferences(r,before);});
}

function polygon(c,points){c.beginPath();points.forEach((q,i)=>i?c.lineTo(q.x,q.y):c.moveTo(q.x,q.y));c.closePath();c.fill();}
/** Render controller-initial terrain rather than constructing rectangular
 * proxies. The native editor already renders native same-ID actor sidecars. */
export function drawSmm2EditorTerrain(c,room,{effect=true}={}){
 if(room.smm2Mechanics?.version!==1)return false;const terrain=createSMM2Terrain(room),view=terrain?.view()||{version:1},vines=staticVines(room);
 if(effect){drawSmm2World(c,room,view,0);for(const q of vines)drawReference(c,{...q,kind:'active-vine'},room);}
 else{c.save();c.fillStyle='#e8e0cb';for(const q of view.surfaces||[])polygon(c,q.polygon);for(const q of view.donuts||[])c.fillRect(q.x,q.y,q.w,q.h);c.fillStyle='#77bcae';for(const q of vines)c.fillRect(q.x,q.y,q.w,q.h);c.restore();}return !!terrain||vines.length>0;
}
const bounds=q=>q.actor||(q.type==='seesaw'?{x:q.spec.pivotX-q.spec.length/2,y:q.spec.pivotY-q.spec.length/2,w:q.spec.length,h:q.spec.length}:q.type==='slope'&&q.spec.thickness!==undefined?{...q.spec,y:q.spec.y-(q.spec.orientation.startsWith('ceiling-')?q.spec.thickness:0),h:q.spec.h+q.spec.thickness}:q.spec);
function drawThumbnail(canvas,r,q){const c=canvas.getContext('2d');c.clearRect(0,0,canvas.width,canvas.height);c.fillStyle='#000';c.fillRect(0,0,canvas.width,canvas.height);if(!q)return;const previewRoom={...r,smm2Mechanics:{version:1,[definition(q.type).leaf]:[q.spec]}},visual=q.type==='shoe'&&q.actor?smm2ShoeVisualBounds({...q.actor,smm2Shoe:{...q.spec,occupancy:q.spec.occupant==='goomba'?'npc':'empty'}}):null,b=visual||bounds(q),scale=Math.min(3,(canvas.width-16)/b.w,(canvas.height-16)/b.h);c.save();c.imageSmoothingEnabled=false;c.translate((canvas.width-b.w*scale)/2,(canvas.height-b.h*scale)/2);c.scale(scale,scale);c.translate(-b.x,-b.y);const preview={...r,renderBounds:undefined,map:{...r.map,width:Math.max(512,r.map.width),height:Math.max(512,r.map.height)},markers:[],smm2Mechanics:{version:1,[definition(q.type).leaf]:[q.spec]}};if(q.actor)drawSmm2Actor(c,q.actor,0,preview);else drawSmm2EditorTerrain(c,preview);c.restore();}

/** Creator-only sidebar, with actual DOM handlers using the host History. */
export function mountSmm2Tools({parent,room,selected=()=>new Set(),change,report=()=>{}}){
 const panel=document.createElement('section');panel.id='smm2-tools';parent.append(panel);const controls=new Map();let selectedId='',lastRoom=null,lastSelection='',currentType='thwomp',fieldControls=new Map();
 const node=(tag,text='',container=panel)=>{const n=document.createElement(tag);n.textContent=text;container.append(n);return n;};
 const fill=(n,entries,value)=>{n.replaceChildren(...entries.map(([v,t])=>{const o=document.createElement('option');o.value=v;o.textContent=t;return o;}));n.value=value;};
 const control=(tag,id,container)=>{const n=document.createElement(tag);n.setAttribute('data-smm2-control',id);container.append(n);controls.set(id,n);return n;};
 const field=(id,label,choices,container)=>{const l=node('label',label,container),n=control('select',id,l);fill(n,choices,'');return n;};
 const get=id=>controls.get(id),attempt=fn=>{try{change(fn);refresh();}catch(e){report(e.message);refresh();}};
 node('h2','SMM2 实体与地形');const detail=node('details');node('summary','咚咚、平台与道具',detail);
 const conveyorDetail=node('details');node('summary','ON/OFF 传送带 · 固定顶面',conveyorDetail);
 field('conveyor-select','已有传送带',[],conveyorDetail);
 field('conveyor-kind','外观形状',[['rect','水平传送带'],['line','连续倾斜传送带']],conveyorDetail);
 const conveyorNumbers=[
  ['conveyor-start-x','左端顶面 X','topEndpoints.0.x'],['conveyor-start-y','左端顶面 Y','topEndpoints.0.y'],
  ['conveyor-end-x','右端顶面 X','topEndpoints.1.x'],['conveyor-end-y','右端顶面 Y','topEndpoints.1.y'],
  ['conveyor-speed','作者搬运速度（像素 / 秒）','speedPxPerSecond'],['conveyor-visual-speed','作者履带动画速度（像素 / 秒）','visualTreadSpeedPxPerSecond'],
  ['conveyor-period','作者履带重复长度（像素）','treadPeriodPx']
 ];
 field('conveyor-direction','ON 顶面方向',[['1','沿顶面向右'],['-1','沿顶面向左']],conveyorDetail);
 const conveyorGeometry=node('details','',conveyorDetail);node('summary','实际滚轴与外观边界（像素）',conveyorGeometry);
 const visualNumbers=[
  ['conveyor-rect-x','外观边界左 X','visual.rect.x'],['conveyor-rect-y','外观边界顶 Y','visual.rect.y'],
  ['conveyor-rect-w','外观边界宽','visual.rect.w'],['conveyor-rect-h','外观边界高','visual.rect.h'],
  ['conveyor-roller-start-x','左滚轴中心 X','visual.rollerCenters.0.x'],['conveyor-roller-start-y','左滚轴中心 Y','visual.rollerCenters.0.y'],
  ['conveyor-roller-end-x','右滚轴中心 X','visual.rollerCenters.1.x'],['conveyor-roller-end-y','右滚轴中心 Y','visual.rollerCenters.1.y'],
  ['conveyor-radius','滚轴半径','visual.rollerRadiusPx']
 ];
 for(const [id,title]of [...conveyorNumbers,...visualNumbers]){const l=node('label',title,visualNumbers.some(row=>row[0]===id)?conveyorGeometry:conveyorDetail),n=control('input',id,l);n.type='number';n.step='any';n.min=id.includes('speed')||id==='conveyor-period'||id==='conveyor-radius'?'0.000001':String(-CONVEYOR_COORDINATE_LIMIT);n.max=String(CONVEYOR_COORDINATE_LIMIT);}
 for(const [id,title,value]of [['conveyor-contact-mode','已验证接触范围',CONVEYOR_CONTACT_MODE],['conveyor-parameter-status','参数状态',CONVEYOR_PARAMETER_STATUS]]){const l=node('label',title,conveyorDetail),n=control('input',id,l);n.type='text';n.value=value;n.readOnly=true;}
 field('conveyor-preview-state','预览开关状态',[['on','ON · 红色'],['off','OFF · 蓝色']],conveyorDetail);
 const conveyorCanvas=control('canvas','conveyor-preview',conveyorDetail);conveyorCanvas.width=144;conveyorCanvas.height=96;conveyorCanvas.setAttribute('aria-label','传送带原素材静止预览');conveyorCanvas.style.cssText='width:144px;height:96px;image-rendering:pixelated;max-width:100%';
 let conveyorId='',conveyorRoom=null,conveyorSelection='',conveyorPreviewOn=true;
 const conveyorNumeric=id=>{if(String(get(id).value).trim()==='')throw Error('请填写传送带参数 '+id);const value=Number(get(id).value);if(!Number.isFinite(value))throw Error('传送带参数必须为有限数值');return value;};
 function readConveyor(){const spec={topEndpoints:[{},{}],visual:{kind:get('conveyor-kind').value,rect:{},rollerCenters:[{},{}]},directionOn:Number(get('conveyor-direction').value),contactMode:CONVEYOR_CONTACT_MODE,parameterStatus:CONVEYOR_PARAMETER_STATUS};for(const [id,,path]of [...conveyorNumbers,...visualNumbers])setValue(spec,path,conveyorNumeric(id));return spec;}
 function drawConveyorThumbnail(spec){const c=conveyorCanvas.getContext('2d');c.clearRect(0,0,144,96);c.fillStyle='#000';c.fillRect(0,0,144,96);if(!spec)return;const descriptor=createConveyorSurfaces([{...spec,id:spec.id||'conveyor-preview'}],{isOn:conveyorPreviewOn}).view().surfaces[0],b=spec.visual.rect,scale=Math.min(3,128/b.w,80/b.h);c.save();c.imageSmoothingEnabled=false;c.translate((144-b.w*scale)/2,(96-b.h*scale)/2);c.scale(scale,scale);c.translate(-b.x,-b.y);drawConveyorSurface(c,descriptor,{animate:false});c.restore();}
 function populateConveyor(spec){const values=spec||defaultSmm2Conveyor();get('conveyor-kind').value=values.visual.kind;get('conveyor-direction').value=String(values.directionOn);for(const [id,,path]of [...conveyorNumbers,...visualNumbers])get(id).value=String(valueAt(values,path)??(path==='treadPeriodPx'?16:path==='visualTreadSpeedPxPerSecond'?values.speedPxPerSecond:''));get('conveyor-preview-state').value=conveyorPreviewOn?'on':'off';drawConveyorThumbnail(values);}
 get('conveyor-select').onchange=()=>{conveyorId=get('conveyor-select').value;populateConveyor(room().smm2Mechanics?.conveyors?.find(q=>q.id===conveyorId));refreshConveyorButtons();};
 get('conveyor-preview-state').onchange=()=>{conveyorPreviewOn=get('conveyor-preview-state').value==='on';try{drawConveyorThumbnail(readConveyor());}catch(e){report(e.message);}};
 const conveyorButton=(id,text,fn)=>{const n=control('button',id,conveyorDetail);n.type='button';n.textContent=text;n.onclick=()=>attempt(fn);return n;};
 const conveyorFit=control('button','conveyor-fit-visual',conveyorGeometry);conveyorFit.type='button';conveyorFit.textContent='按当前顶面与半径计算外观边界';conveyorFit.onclick=()=>{try{const spec=readConveyor(),[a,b]=spec.topEndpoints,r=spec.visual.rollerRadiusPx,flat=spec.visual.kind==='rect';if(flat&&a.y!==b.y)throw Error('水平传送带两个顶面端点须同高');const centers=flat?[{x:a.x+r,y:a.y+r},{x:b.x-r,y:b.y+r}]:[{x:a.x,y:a.y+r},{x:b.x,y:b.y+r}],left=Math.min(...centers.map(p=>p.x))-r,top=Math.min(...centers.map(p=>p.y))-r;spec.visual={kind:spec.visual.kind,rect:{x:left,y:top,w:Math.max(...centers.map(p=>p.x))+r-left,h:Math.max(...centers.map(p=>p.y))+r-top},rollerCenters:centers,rollerRadiusPx:r};validateConveyorsRoom([{...spec,id:'conveyor-preview'}]);populateConveyor(spec);}catch(e){report(e.message);}};
 conveyorButton('conveyor-add','新增传送带',()=>{conveyorId=addSmm2Conveyor(room(),readConveyor());});
 conveyorButton('conveyor-apply','更新所选传送带',()=>updateSmm2Conveyor(room(),conveyorId,readConveyor()));
 for(const [id,title,value]of [['conveyor-copy-dx','复制水平偏移（像素）',16],['conveyor-copy-dy','复制垂直偏移（像素）',32]]){const l=node('label',title,conveyorDetail),n=control('input',id,l);n.type='number';n.step='any';n.value=String(value);}
 conveyorButton('conveyor-clone','按偏移复制所选传送带',()=>{conveyorId=cloneSmm2Conveyor(room(),conveyorId,{dx:conveyorNumeric('conveyor-copy-dx'),dy:conveyorNumeric('conveyor-copy-dy')});});
 conveyorButton('conveyor-remove','删除所选传送带',()=>{removeSmm2Conveyor(room(),conveyorId);conveyorId='';});
 node('p','ON 为红色、OFF 为蓝色，改变顶面搬运方向。两端与滚轴固定；速度是作者拟合值。只验证顶面接触，底面与侧面规则未取得原作证据。倾斜顶面跟随实际滚轴中心线，外观包围框不作为原生实心碰撞。',conveyorDetail).className='small';
 function refreshConveyorButtons(){const exists=room().smm2Mechanics?.conveyors?.some(q=>q.id===conveyorId);for(const id of ['conveyor-apply','conveyor-clone','conveyor-remove'])get(id).disabled=!exists;}
 function refreshConveyors(r,picked){const changed=conveyorRoom!==r.roomId,key=picked.join('|'),selectionChanged=changed||conveyorSelection!==key;if(changed){conveyorId='';conveyorPreviewOn=r.switchStudy?.initialOn??true;}if(selectionChanged&&picked.length===1&&r.smm2Mechanics?.conveyors?.some(q=>q.id===picked[0]))conveyorId=picked[0];conveyorRoom=r.roomId;conveyorSelection=key;const list=r.smm2Mechanics?.conveyors||[];if(conveyorId&&!list.some(q=>q.id===conveyorId))conveyorId='';fill(get('conveyor-select'),[['','新增 / 未选择'],...list.map(q=>[q.id,q.id+' · '+(q.visual.kind==='rect'?'水平':'倾斜')])],conveyorId);populateConveyor(list.find(q=>q.id===conveyorId));refreshConveyorButtons();}
 const npcSpringDetail=node('details');node('summary','静止竖向弹簧 · 普通 NPC 顶面接触',npcSpringDetail);
 field('npc-spring-select','已有静止竖向弹簧规则',[],npcSpringDetail);
 const npcEnabledLabel=node('label','启用普通 NPC 顶面压缩与弹起',npcSpringDetail),npcEnabled=control('input','npc-spring-enabled',npcEnabledLabel);npcEnabled.type='checkbox';
 for(const [id,title,value,min,max]of [['npc-spring-frames','作者 NPC 压缩帧数',8,1,600],['npc-spring-speed','作者 NPC 弹出速度（像素 / 帧）',10,.001,64],['npc-spring-depth','作者 NPC 压缩深度（像素；留空用模块拟合值）','',.001,64]]){const l=node('label',title,npcSpringDetail),n=control('input',id,l);n.type='number';n.step=id==='npc-spring-frames'?'1':'any';n.min=String(min);n.max=String(max);n.value=String(value);}
 const npcSpringApply=control('button','npc-spring-apply',npcSpringDetail);npcSpringApply.type='button';npcSpringApply.textContent='更新所选 NPC 弹簧接触';npcSpringApply.onclick=()=>attempt(()=>{const id=get('npc-spring-select').value;if(!npcEnabled.checked){clearSmm2NpcSpringContact(room(),id);return;}const options={compressionFrames:conveyorNumeric('npc-spring-frames'),launchSpeed:conveyorNumeric('npc-spring-speed')};if(String(get('npc-spring-depth').value).trim()!=='')options.compressionDepth=conveyorNumeric('npc-spring-depth');setSmm2NpcSpringContact(room(),id,options);});
 node('p','请先在弹簧方向面板绑定已有竖向弹簧。原作对照只验证静止竖向弹簧的普通 NPC 顶面响应；移动载体、侧面与其他 NPC 类型不继承此能力。NPC 压缩和弹速是独立作者拟合，不修改玩家参数。',npcSpringDetail).className='small';
 let npcSpringRoom=null,npcSpringSelection='';
 get('npc-spring-select').onchange=()=>populateNpcSpring(room());
 function populateNpcSpring(r){const rule=r.smm2Mechanics?.springs?.find(q=>q.id===get('npc-spring-select').value),npc=rule?.npcContact;npcEnabled.checked=!!npc;get('npc-spring-frames').value=String(npc?.compressionFrames??8);get('npc-spring-speed').value=String(npc?.launchSpeed??10);get('npc-spring-depth').value=npc?.compressionDepth===undefined?'':String(npc.compressionDepth);npcEnabled.disabled=npcSpringApply.disabled=!rule;}
 function refreshNpcSprings(r,picked){const key=picked.join('|'),changed=npcSpringRoom!==r.roomId||npcSpringSelection!==key,rules=(r.smm2Mechanics?.springs||[]).filter(q=>q.orientation==='vertical'&&r.map.geometry.some(g=>g.id===q.id&&g.material==='spring'&&!g.hidden&&!g.motion&&!g.liftSpeed&&g.springOrientation!=='horizontal')&&!(r.smm2Mechanics.carrierGeometry||[]).some(g=>g.id===q.id)&&!r.marioModules?.contactPlatforms?.[q.id]);let chosen=npcSpringRoom!==r.roomId?'':get('npc-spring-select').value;if(changed&&picked.length===1&&rules.some(q=>q.id===picked[0]))chosen=picked[0];npcSpringRoom=r.roomId;npcSpringSelection=key;fill(get('npc-spring-select'),[['','选择已有静止竖向弹簧'],...rules.map(q=>[q.id,q.id])],chosen);populateNpcSpring(r);}
 field('select','已有组件',[],detail).onchange=()=>{selectedId=get('select').value;refresh();};
 field('type','新增组件类型',Object.entries(smm2ComponentTypes).map(([k,q])=>[k,q.label]),detail).onchange=()=>{selectedId='';get('select').value='';currentType=get('type').value;populate(null);};
 const canvas=control('canvas','preview',detail);canvas.width=144;canvas.height=96;canvas.style.cssText='width:144px;height:96px;image-rendering:pixelated;max-width:100%';canvas.setAttribute('aria-label','所选组件的初始外观');
 const fields=node('div','',detail),note=node('p','',detail);note.className='small';
 function build(type){currentType=type;fields.replaceChildren();fieldControls=new Map();let advanced;for(const [id,q]of Object.entries(definition(type).fields)){if(id.startsWith('tuning.')&&!advanced){advanced=node('details','',fields);node('summary','鞋运动参数（工坊近似值）',advanced);}const l=node('label',q.label,id.startsWith('tuning.')?advanced:fields),n=document.createElement(q.choices?'select':'input');n.setAttribute('data-smm2-control',id);if(q.choices)fill(n,q.choices,q.value);else{n.type=q.type;if(q.type==='number')n.step='any';}l.append(n);fieldControls.set(id,n);}}
 function read(){const values={};for(const [id,n]of fieldControls){const q=definition(currentType).fields[id];let value=n.value;if(q.type==='checkbox')value=id==='breakMaterials'?(n.checked?['brick']:[]):!!n.checked;else if(q.type==='number'){if(String(n.value).trim()===''){if(!q.optional)throw Error('请填写 '+q.label);value=null;}else value=Number(n.value);}else if(id==='oneWaySupportIds')value=n.value.split(',').map(s=>s.trim()).filter(Boolean);setValue(values,id,value);}return values;}
 function populate(q){const type=q?.type||currentType;build(type);get('type').value=type;const values=q?componentValues(q):defaults(type);for(const [id,n]of fieldControls){const f=definition(type).fields[id];const value=valueAt(values,id);if(f.type==='checkbox')n.checked=id==='breakMaterials'?value?.includes('brick'):value??f.value;else n.value=Array.isArray(value)?value.join(', '):value??f.value;}
  if(type==='shoe')fieldControls.get('size').onchange=()=>{const size=fieldControls.get('size').value==='big'?32:16;fieldControls.get('w').value=fieldControls.get('h').value=String(size);};
  const preview=q||(()=>{const {leaf,actor}=parts(type,{...defaults(type),id:'smm2-tool-preview'});return {type,spec:leaf,actor};})();drawThumbnail(canvas,room(),preview);note.textContent=type==='slope'?'h 是对角线垂直落差，厚度是独立的垂直距离。地面薄斜坡从对角线向下延伸；天花板薄斜坡向上延伸。留空保留原三角形；完整多边形必须位于区域内。':type==='shoe'?'普通鞋默认 16×16，Big 鞋默认 32×32；实体矩形只表示鞋底。乘员与翅膀不扩大鞋底。数值为本工坊近似参数。':q?.spec.rail?'此道具已接轨道。更新会保留轨道设置；位置仍须符合原锚点。':'实体可用对象层框选移动；地形用本面板定位。数值为本工坊近似参数。';get('apply').disabled=get('remove').disabled=get('clone').disabled=!q;
 }
 const button=(id,text,fn)=>{const n=control('button',id,detail);n.type='button';n.textContent=text;n.onclick=()=>attempt(fn);return n;};
 button('add','新增组件',()=>{selectedId=addSmm2Component(room(),currentType,read());});button('apply','更新所选组件',()=>updateSmm2Component(room(),selectedId,read()));button('clone','复制所选（右移 16）',()=>{selectedId=cloneSmm2Component(room(),selectedId);});button('remove','删除所选组件',()=>{removeSmm2Component(room(),selectedId);selectedId='';});
 const pRailDetail=node('details');node('summary','P 开关轨道（真实运动，数值近似）',pRailDetail);
 field('p-track','现有轨道',[],pRailDetail);for(const [id,title,value]of [['p-rail-speed','速度（像素 / 帧）',.5],['p-rail-position','初始曲线距离（像素）',0]]){const l=node('label',title,pRailDetail),n=control('input',id,l);n.type='number';n.step='any';n.value=String(value);}
 field('p-rail-direction','起始运动方向',[['1','正向'],['-1','反向']],pRailDetail);
 const pRailBind=control('button','p-rail-bind',pRailDetail);pRailBind.type='button';pRailBind.textContent='连接轨道并移动到真实锚点';pRailBind.onclick=()=>attempt(()=>bindSmm2PSwitchRail(room(),selectedId,{trackId:get('p-track').value,speed:Number(get('p-rail-speed').value),position:Number(get('p-rail-position').value),direction:Number(get('p-rail-direction').value)}));
 const pRailUnbind=control('button','p-rail-unbind',pRailDetail);pRailUnbind.type='button';pRailUnbind.textContent='取消 P 轨道连接';pRailUnbind.onclick=()=>attempt(()=>bindSmm2PSwitchRail(room(),selectedId,null));
 node('p','倒挂只由真实向上头部接触按压；尚未按原作逐帧校准。侧碰不按压。连接轨道会改变真实实体位置。',pRailDetail).className='small';
 function refreshPRail(r,list){const q=list.find(q=>q.id===selectedId),isP=q?.type==='pSwitch';pRailDetail.hidden=!isP;fill(get('p-track'),[['','选择轨道'],...(r.contraptions?.tracks||[]).map(q=>[q.id,q.id])],q?.spec.rail?.trackId||get('p-track').value);if(q?.spec.rail){get('p-rail-speed').value=String(q.spec.rail.speed);get('p-rail-position').value=String(q.spec.rail.position);get('p-rail-direction').value=String(q.spec.rail.direction);}pRailBind.disabled=!isP;pRailUnbind.disabled=!q?.spec.rail;}
 const checkpointDetail=node('details');node('summary','中间旗奖励',checkpointDetail);
 field('checkpoint','现有原生中间旗',[],checkpointDetail);field('checkpoint-reward','触旗奖励',[['none','不提供道具'],['mushroom','蘑菇（小马里奥长大）'],['star','无敌星']],checkpointDetail);
 const pointsLabel=node('label','触旗分数（0–100000）',checkpointDetail),checkpointPoints=control('input','checkpoint-points',pointsLabel);checkpointPoints.type='number';checkpointPoints.min='0';checkpointPoints.max='100000';checkpointPoints.step='1';
 const checkpointApply=control('button','checkpoint-apply',checkpointDetail);checkpointApply.type='button';checkpointApply.textContent='更新中间旗奖励';checkpointApply.onclick=()=>attempt(()=>{if(String(checkpointPoints.value).trim()==='')throw Error('请填写触旗分数');setSmm2CheckpointReward(room(),get('checkpoint').value,{reward:get('checkpoint-reward').value,points:Number(checkpointPoints.value)});});
 const checkpointClear=control('button','checkpoint-clear',checkpointDetail);checkpointClear.type='button';checkpointClear.textContent='恢复原生默认奖励';checkpointClear.onclick=()=>attempt(()=>clearSmm2CheckpointReward(room(),get('checkpoint').value));
 node('p','选择地图中已有的中间旗。不会创建出生点；复活仍由原生中间旗处理。',checkpointDetail).className='small';
 get('checkpoint').onchange=()=>refreshCheckpoints(room(),[]);
 function refreshCheckpoints(r,picked){const checkpoints=r.map.objects.filter(q=>q.kind==='checkpoint'),selected=picked.length===1&&checkpoints.some(q=>q.id===picked[0])?picked[0]:get('checkpoint').value;fill(get('checkpoint'),[['','选择已有中间旗'],...checkpoints.map(q=>[q.id,q.id])],selected);const reward=r.smm2Mechanics?.checkpointRewards?.find(q=>q.id===selected);get('checkpoint-reward').value=reward?.reward||'none';checkpointPoints.value=String(reward?.points??0);checkpointApply.disabled=!checkpoints.some(q=>q.id===selected);checkpointClear.disabled=!reward;}
 const goalDetail=node('details');node('summary','终点收尾奖励',goalDetail);
 field('goal-enemy','已有原生敌人',[],goalDetail);const goalPointsLabel=node('label','触终点时的敌人分数（0–100000）',goalDetail),goalPoints=control('input','goal-enemy-points',goalPointsLabel);goalPoints.type='number';goalPoints.min='0';goalPoints.max='100000';goalPoints.step='1';
 const goalApply=control('button','goal-enemy-apply',goalDetail);goalApply.type='button';goalApply.textContent='设置所选敌人的终点分数';goalApply.onclick=()=>attempt(()=>{if(String(goalPoints.value).trim()==='')throw Error('请填写终点敌人分数');setSmm2GoalEnemyReward(room(),get('goal-enemy').value,{points:Number(goalPoints.value)});});
 const goalClear=control('button','goal-enemy-clear',goalDetail);goalClear.type='button';goalClear.textContent='移除所选敌人的终点奖励';goalClear.onclick=()=>attempt(()=>clearSmm2GoalEnemyReward(room(),get('goal-enemy').value));
 const flagLabel=node('label','启用经典旗杆位置分数',goalDetail),flagScore=control('input','flag-score',flagLabel);flagScore.type='checkbox';flagScore.onchange=()=>attempt(()=>setSmm2FlagScore(room(),flagScore.checked));
 const coinDetail=node('details');node('summary','玩家激活龟壳收集金币',coinDetail);
 const shellCoinLabel=node('label','允许玩家踢动的旋转龟壳接触收集普通 / 粉红金币',coinDetail),shellCoins=control('input','shell-coin-collection',shellCoinLabel);shellCoins.type='checkbox';shellCoins.onchange=()=>attempt(()=>setSmm2ShellCoinCollection(room(),shellCoins.checked));
 node('p','默认关闭。初次踩成静止龟壳不算激活；真正踢动后才可收集。碰墙和正常落地保留激活，停止旋转后须由玩家再次踢动。',coinDetail).className='small';
 node('p','仅在真正触及终点时，为仍活着的所选敌人结算一次。此选项不添加金币或任务奖励。未设置旗杆分数选项时沿用经典默认。',goalDetail).className='small';
 get('goal-enemy').onchange=()=>refreshGoalRewards(room(),[]);
 function refreshGoalRewards(r,picked){const actors=r.map.objects.filter(q=>q.kind==='walker'),selected=picked.length===1&&actors.some(q=>q.id===picked[0])?picked[0]:get('goal-enemy').value;fill(get('goal-enemy'),[['','选择已有敌人'],...actors.map(q=>[q.id,q.id])],selected);const reward=r.smm2Mechanics?.goalEnemyRewards?.find(q=>q.id===selected);goalPoints.value=String(reward?.points??0);goalApply.disabled=!actors.some(q=>q.id===selected);goalClear.disabled=!reward;flagScore.checked=r.smm2Mechanics?.flagScore??true;}
 const carrierDetail=node('details');node('summary','弹簧与移动载体',carrierDetail);
 field('carrier-spring','现有弹簧',[],carrierDetail);field('carrier-parent','允许支撑它的载体',[],carrierDetail);
 field('carrier-rest-size','弹簧静止身体尺寸',[['16','16×16'],['32','32×32 · 作者 2× 像素适配，非原作变体']],carrierDetail);get('carrier-rest-size').value='16';
 const sizeButton=control('button','carrier-size-apply',carrierDetail);sizeButton.type='button';sizeButton.textContent='应用选中弹簧静止身体尺寸（保留底部）';sizeButton.onclick=()=>attempt(()=>setSmm2SpringRestBodySize(room(),get('carrier-spring').value,Number(get('carrier-rest-size').value)));
 field('carrier-type','支撑类型',[['native','移动平台 / 咚咚（原有设置）'],['seesaw','跷跷板（作者近似参数）']],carrierDetail);get('carrier-type').value='native';
 for(const [id,title,value,min,max]of [['carrier-mass','作者近似质量 mass',1,.001,10000],['carrier-gravity','作者近似重力 gravity（像素 / 帧²）',.3,.001,4],['carrier-max-fall-speed','作者近似最大下落速度 maxFallSpeed',4.25,.001,64]]){const l=node('label',title,carrierDetail),n=control('input',id,l);n.type='number';n.step='any';n.min=String(min);n.max=String(max);n.value=String(value);}
 function carrierMode(){for(const id of ['carrier-mass','carrier-gravity','carrier-max-fall-speed'])get(id).disabled=get('carrier-type').value!=='seesaw';}
 get('carrier-type').onchange=carrierMode;
 const springSupportOptions=()=>get('carrier-type').value==='seesaw'?{carrierType:'seesaw',mass:carrierNumber('carrier-mass'),gravity:carrierNumber('carrier-gravity'),maxFallSpeed:carrierNumber('carrier-max-fall-speed')}:undefined;
 const bindButton=control('button','carrier-bind',carrierDetail);bindButton.type='button';bindButton.textContent='连接 / 更新真实顶面';bindButton.onclick=()=>attempt(()=>bindSmm2SpringSupport(room(),get('carrier-spring').value,get('carrier-parent').value,springSupportOptions()));
 const alignButton=control('button','carrier-align-bind',carrierDetail);alignButton.type='button';alignButton.textContent='对齐跷跷板顶面并绑定';alignButton.onclick=()=>attempt(()=>alignSmm2SpringToSeesawSupport(room(),get('carrier-spring').value,get('carrier-parent').value,springSupportOptions()));
 function carrierNumber(id){if(String(get(id).value).trim()==='')throw Error('请填写作者近似支撑参数');return Number(get(id).value);}
 const unbindButton=control('button','carrier-unbind',carrierDetail);unbindButton.type='button';unbindButton.textContent='取消移动支撑';unbindButton.onclick=()=>attempt(()=>unbindSmm2SpringSupport(room(),get('carrier-spring').value));
 node('p','先把独立竖向原生弹簧底部贴在载体真实顶面。原画笔弹簧为 16×29；跷跷板支撑需显式应用 16×16 静止身体，或作者 2× 像素适配的 32×32（非原作变体）。再明确选择支撑类型并填写质量、重力和最大下落速度，它们是工坊作者近似值。可显式点击“对齐跷跷板顶面并绑定”，按当前脚底范围只调整源 Y；X 无真实重叠会拒绝。普通连接不移动弹簧，运行中不自动对齐。离开顶面会下落，再接触可以承载。单独复制弹簧会得到独立弹簧。',carrierDetail).className='small';
 get('carrier-spring').onchange=()=>refreshCarriers(room(),[]);
 function refreshCarriers(r,picked){const springIds=r.map.geometry.filter(q=>q.material==='spring'),parents=[...r.map.geometry.filter(q=>q.motion||q.liftSpeed),...r.map.objects.filter(q=>r.smm2Mechanics?.thwomps?.some(t=>t.id===q.id)),...(r.smm2Mechanics?.seesaws||[])],oldSpring=get('carrier-spring').value,oldParent=get('carrier-parent').value,pickedSpring=picked.length===1&&springIds.some(q=>q.id===picked[0])?picked[0]:null,spring=pickedSpring||oldSpring;fill(get('carrier-spring'),[['','选择原生弹簧'],...springIds.map(q=>[q.id,q.id])],spring);const body=springIds.find(q=>q.id===spring),linked=r.smm2Mechanics?.carrierGeometry?.find(q=>q.id===spring);get('carrier-rest-size').value=body?.w===32&&body.h===32?'32':'16';fill(get('carrier-parent'),[['','选择已有移动平台 / 咚咚 / 跷跷板'],...parents.map(q=>[q.id,q.id+(r.smm2Mechanics?.seesaws?.some(s=>s.id===q.id)?' · 跷跷板':'')])],linked?.carrierId||oldParent);if(linked){get('carrier-type').value=linked.carrierType||'native';if(linked.carrierType==='seesaw'){get('carrier-mass').value=String(linked.mass);get('carrier-gravity').value=String(linked.gravity);get('carrier-max-fall-speed').value=String(linked.maxFallSpeed);}}carrierMode();bindButton.disabled=alignButton.disabled=sizeButton.disabled=!body;unbindButton.disabled=!linked;refreshSupportGroups(r,picked);}
 const supportGroupDetail=node('details');node('summary','载体与弹簧组复制',supportGroupDetail);field('support-group-parent','真实载体',[],supportGroupDetail);let supportClipboard=null,supportGroupRoom=null,supportGroupSelection='';
 for(const [id,title,value]of [['support-group-dx','整组水平偏移 dx（像素）',16],['support-group-dy','整组垂直偏移 dy（像素）',0]]){const l=node('label',title,supportGroupDetail),n=control('input',id,l);n.type='number';n.step='any';n.value=String(value);}
 const groupCopy=control('button','support-group-copy',supportGroupDetail);groupCopy.type='button';groupCopy.textContent='复制载体与已连接弹簧组';groupCopy.onclick=()=>{try{supportClipboard=captureSmm2SupportGroup(room(),get('support-group-parent').value);report('已复制载体及 '+(supportClipboard.geometry.length-(supportClipboard.geometry.some(q=>q.id===supportClipboard.carrierId)?1:0))+' 个原生弹簧；粘贴按整组偏移保留支撑和作者参数');refresh();}catch(e){report(e.message);}};
 const groupPaste=control('button','support-group-paste',supportGroupDetail);groupPaste.type='button';groupPaste.textContent='粘贴复制组（独立新 ID）';groupPaste.onclick=()=>attempt(()=>{if(!supportClipboard)throw Error('请先复制载体与弹簧组');const result=pasteSmm2SupportGroup(room(),supportClipboard,{dx:carrierNumber('support-group-dx'),dy:carrierNumber('support-group-dy')});selectedId=result.carrierId;get('support-group-parent').value=result.carrierId;});
 const groupRemove=control('button','support-group-remove',supportGroupDetail);groupRemove.type='button';groupRemove.textContent='删除所选载体与已连接弹簧组';groupRemove.onclick=()=>attempt(()=>removeSmm2SupportGroup(room(),get('support-group-parent').value));
 node('p','组复制同时保留真实载体、所有已连接的原生弹簧、弹簧作者参数与支撑参数。偏移从复制时的位置计算；每次粘贴生成新 ID，整笔失败会回滚。单独删除组件只取消它的支撑连接。',supportGroupDetail).className='small';
 get('support-group-parent').onchange=()=>refreshSupportGroups(room(),[...selected()]);
 function refreshSupportGroups(r,picked){const parents=[...r.map.geometry.filter(q=>q.motion||q.liftSpeed),...listSmm2Components(r).filter(q=>['seesaw','thwomp'].includes(q.type))],selection=picked.join('|'),changed=supportGroupRoom!==r.roomId||supportGroupSelection!==selection,current=changed&&picked.length===1&&parents.some(q=>q.id===picked[0])?picked[0]:get('support-group-parent').value;supportGroupRoom=r.roomId;supportGroupSelection=selection;fill(get('support-group-parent'),[['','选择真实载体'],...parents.map(q=>[q.id,q.id])],current);groupCopy.disabled=groupRemove.disabled=!parents.some(q=>q.id===current);groupPaste.disabled=!supportClipboard;}
 field('carrier-pow','现有 POW',[],carrierDetail);field('carrier-pow-parent','允许支撑 POW 的载体',[],carrierDetail);
 const bindPowButton=control('button','carrier-pow-bind',carrierDetail);bindPowButton.type='button';bindPowButton.textContent='连接 POW 真实顶面';bindPowButton.onclick=()=>attempt(()=>bindSmm2PowSupport(room(),get('carrier-pow').value,get('carrier-pow-parent').value));
 const unbindPowButton=control('button','carrier-pow-unbind',carrierDetail);unbindPowButton.type='button';unbindPowButton.textContent='取消 POW 移动支撑';unbindPowButton.onclick=()=>attempt(()=>unbindSmm2PowSupport(room(),get('carrier-pow').value));
 node('p','POW 底部须实际接触载体顶面，并使用自身重力。快速下冲会脱离，回升可重新顶起；耗尽后消失。仅复制 POW 会得到独立道具，一起复制咚咚和 POW 才保留支撑。',carrierDetail).className='small';
 get('carrier-pow').onchange=()=>{const q=room().smm2Mechanics?.carrierItems?.find(q=>q.id===get('carrier-pow').value);if(q)get('carrier-pow-parent').value=q.carrierId;};
 function refreshPowCarriers(r,picked){const pows=r.smm2Mechanics?.powBlocks||[],parents=[...r.map.geometry.filter(q=>q.motion||q.liftSpeed),...r.map.objects.filter(q=>r.smm2Mechanics?.thwomps?.some(t=>t.id===q.id))],oldPow=get('carrier-pow').value,chosen=picked.length===1&&pows.some(q=>q.id===picked[0])?picked[0]:oldPow,link=r.smm2Mechanics?.carrierItems?.find(q=>q.id===chosen);fill(get('carrier-pow'),[['','选择已有 POW'],...pows.map(q=>[q.id,q.id])],chosen);fill(get('carrier-pow-parent'),[['','选择已有移动平台 / 咚咚'],...parents.map(q=>[q.id,q.id])],link?.carrierId||get('carrier-pow-parent').value);bindPowButton.disabled=!pows.some(q=>q.id===chosen);unbindPowButton.disabled=!link;}
 function refresh(){const r=room();shellCoins.checked=r.smm2Mechanics?.shellCoinCollection===true;if(r.roomId!==lastRoom){lastRoom=r.roomId;selectedId='';lastSelection='';}const list=listSmm2Components(r),picked=[...selected()],selectionKey=picked.join('|');if(selectionKey!==lastSelection&&picked.length===1&&list.some(q=>q.id===picked[0]))selectedId=picked[0];lastSelection=selectionKey;refreshConveyors(r,picked);refreshNpcSprings(r,picked);refreshCarriers(r,picked);refreshPowCarriers(r,picked);refreshCheckpoints(r,picked);refreshGoalRewards(r,picked);if(selectedId&&!list.some(q=>q.id===selectedId))selectedId='';fill(get('select'),[['','新增 / 未选择'],...list.map(q=>{const b=bounds(q);return [q.id,q.label+' · ('+Math.round(b.x)+', '+Math.round(b.y)+')'];})],selectedId);populate(list.find(q=>q.id===selectedId));}
 refresh();return {panel,refresh};
}
