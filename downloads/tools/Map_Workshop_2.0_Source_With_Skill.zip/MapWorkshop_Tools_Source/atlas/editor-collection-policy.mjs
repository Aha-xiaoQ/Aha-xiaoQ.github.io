/** Pure JSON admission rules shared by authoring and the offline player. */
const fail=message=>{throw Error('Collection admission: '+message);};
const hash=value=>typeof value==='string'&&/^[a-f0-9]{64}$/.test(value);
const text=(value,max)=>typeof value==='string'&&value.trim().length>0&&value.length<=max;
const positive=value=>Number.isSafeInteger(value)&&value>0;
function object(value,keys){if(!value||typeof value!=='object'||Array.isArray(value)||![Object.prototype,null].includes(Object.getPrototypeOf(value)))fail('expected plain object');for(const key of Reflect.ownKeys(value)){if(typeof key!=='string'||!keys.includes(key))fail('unknown field '+String(key));const descriptor=Object.getOwnPropertyDescriptor(value,key);if(descriptor.get||descriptor.set)fail('accessor field');}}
export function canonicalCollectionJson(value){
 const seen=new WeakSet();let nodes=0;
 function visit(v,depth){if(++nodes>1000000||depth>80)fail('fingerprint data exceeds limits');if(v===null||typeof v==='string'||typeof v==='boolean')return JSON.stringify(v);if(typeof v==='number'&&Number.isFinite(v))return JSON.stringify(v);if(typeof v!=='object'||!v)fail('fingerprint requires JSON data');if(seen.has(v))fail('cyclic fingerprint data');seen.add(v);let result;if(Array.isArray(v)){const values=[];for(const key of Reflect.ownKeys(v))if(key!=='length'&&(typeof key!=='string'||!/^(0|[1-9]\d*)$/.test(key)||Number(key)>=v.length))fail('array fields are not JSON data');for(let i=0;i<v.length;i++){const descriptor=Object.getOwnPropertyDescriptor(v,String(i));if(!descriptor||descriptor.get||descriptor.set)fail('sparse or accessor array');values.push(visit(descriptor.value,depth+1));}result='['+values.join(',')+']';}else{if(![Object.prototype,null].includes(Object.getPrototypeOf(v)))fail('fingerprint requires plain objects');const descriptors=Object.getOwnPropertyDescriptors(v);if(Reflect.ownKeys(v).some(key=>typeof key!=='string'))fail('symbol field');result='{'+Object.keys(descriptors).sort().map(key=>{if(descriptors[key].get||descriptors[key].set)fail('accessor field');return JSON.stringify(key)+':'+visit(descriptors[key].value,depth+1);}).join(',')+'}';}seen.delete(v);return result;}
 return visit(value,0);
}
// Synchronous SHA-256 keeps the existing validation/build APIs synchronous in browsers.
export function collectionSha256(value){
 const bytes=new TextEncoder().encode(value),size=Math.ceil((bytes.length+9)/64)*64,data=new Uint8Array(size);data.set(bytes);data[bytes.length]=128;const view=new DataView(data.buffer);view.setUint32(size-8,Math.floor(bytes.length/0x20000000));view.setUint32(size-4,bytes.length*8>>>0);
 const constants=[0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2],state=[0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19],words=new Uint32Array(64),rotate=(n,b)=>(n>>>b)|(n<<(32-b));
 for(let offset=0;offset<size;offset+=64){for(let i=0;i<16;i++)words[i]=view.getUint32(offset+i*4);for(let i=16;i<64;i++){const a=words[i-15],b=words[i-2];words[i]=(words[i-16]+(rotate(a,7)^rotate(a,18)^(a>>>3))+words[i-7]+(rotate(b,17)^rotate(b,19)^(b>>>10)))>>>0;}let [a,b,c,d,e,f,g,h]=state;for(let i=0;i<64;i++){const t1=(h+(rotate(e,6)^rotate(e,11)^rotate(e,25))+((e&f)^(~e&g))+constants[i]+words[i])>>>0,t2=((rotate(a,2)^rotate(a,13)^rotate(a,22))+((a&b)^(a&c)^(b&c)))>>>0;h=g;g=f;f=e;e=(d+t1)>>>0;d=c;c=b;b=a;a=(t1+t2)>>>0;}for(const [i,n]of [a,b,c,d,e,f,g,h].entries())state[i]=(state[i]+n)>>>0;}
 return state.map(n=>n.toString(16).padStart(8,'0')).join('');
}
export const projectFingerprint=project=>collectionSha256(canonicalCollectionJson(project));
export function authoredLevelContent(level){if(!level||typeof level!=='object'||Array.isArray(level)||![Object.prototype,null].includes(Object.getPrototypeOf(level))||Reflect.ownKeys(level).some(key=>typeof key!=='string'))fail('level fingerprint requires plain JSON data');const content={};for(const [key,descriptor]of Object.entries(Object.getOwnPropertyDescriptors(level))){if(descriptor.get||descriptor.set)fail('accessor field');if(!['approval','testAdmission','admissionWithdrawal'].includes(key))content[key]=descriptor.value;}return content;}
export const levelContentFingerprint=level=>projectFingerprint(authoredLevelContent(level));
export function validateAdmissionPolicy(policy){
 if(policy===undefined)return;
 if(policy?.mode==='owner-approved-only'){object(policy,['version','mode']);if(policy.version!==1)fail('unsupported policy version');return;}
 object(policy,['version','mode','scope','by','evidence']);if(policy.version!==1||policy.mode!=='owner-approved-or-tested'||policy.scope!=='private'||policy.by!=='owner'||!text(policy.evidence,1000))fail('private test inclusion requires an explicit owner delegation');
}
export function validateTestAdmission(record){
 object(record,['version','status','by','revision','projectFingerprint','contentFingerprint','evidence','summary']);
 if(record.version!==1||record.status!=='passed'||record.by!=='automated-tests'||!positive(record.revision)||!hash(record.projectFingerprint)||!hash(record.contentFingerprint)||!Array.isArray(record.evidence)||record.evidence.length<2||record.evidence.length>8)fail('invalid revision-pinned passed-test record');
 if(record.summary!==undefined&&!text(record.summary,1000))fail('invalid test summary');
 const kinds=[];
 for(const proof of record.evidence){
  const common=['kind','artifact','sha256'];if(!text(proof?.artifact,240)||!hash(proof.sha256))fail('test evidence requires a named artifact and SHA-256');
  if(proof.kind==='native-full-clear'){object(proof,[...common,'frames','completed','developerMode','noStateMutation','noGodmode','noTeleport']);if(!positive(proof.frames)||proof.frames>10000000||proof.completed!==true||proof.developerMode!==false||proof.noStateMutation!==true||proof.noGodmode!==true||proof.noTeleport!==true)fail('native full-clear evidence did not pass normal input conditions');}
  else if(proof.kind==='offline-closure'){object(proof,[...common,'passed']);if(proof.passed!==true)fail('offline resource closure did not pass');}
  else if(proof.kind==='standard-controller'){object(proof,[...common,'passed','layout']);if(proof.passed!==true||!['bottom','right'].includes(proof.layout))fail('invalid controller evidence');}
  else fail('unsupported test evidence kind');
  const key=proof.kind+(proof.layout||'');if(kinds.includes(key))fail('duplicate test evidence');kinds.push(key);
 }
 if(!kinds.includes('native-full-clear')||!kinds.includes('offline-closure'))fail('native full-clear and offline-closure evidence are required');
 return record;
}
export function validateAdmissionWithdrawal(record){object(record,['version','by','evidence']);if(record.version!==1||record.by!=='owner'||record.evidence!==undefined&&!text(record.evidence,500))fail('invalid owner withdrawal');}
export function testAdmissionMatches(level){const record=level.testAdmission;if(record)validateTestAdmission(record);return !!record&&record.revision===level.revision&&record.projectFingerprint===projectFingerprint(level.project)&&record.contentFingerprint===levelContentFingerprint(level);}
export function admissionForLevel(level,policy){
 if(level.admissionWithdrawal)return {status:'withdrawn',label:'已撤回',eligible:false};
 if(level.approval?.status==='approved'&&(!level.approval.contentFingerprint||level.approval.contentFingerprint===levelContentFingerprint(level)))return {status:'owner-approved',label:'作者已认可',eligible:true,revision:level.revision,contentFingerprint:levelContentFingerprint(level),projectFingerprint:projectFingerprint(level.project)};
 if(policy?.version===1&&policy.mode==='owner-approved-or-tested'&&policy.scope==='private'&&policy.by==='owner'&&testAdmissionMatches(level))return {status:'tested-awaiting-owner-review',label:'测试通过 / 待你查看',eligible:true,revision:level.revision,contentFingerprint:level.testAdmission.contentFingerprint,projectFingerprint:level.testAdmission.projectFingerprint};
 return {status:'pending-review',label:'待验收',eligible:false};
}
/** Runtime entries are built and fingerprint-checked by the authoring model. */
export function runtimeAdmissionForLevel(level,policy){
 if(level.admissionWithdrawal)return {status:'withdrawn',label:'已撤回',eligible:false};
 if(level.authoredContent){
  const derived=new Set(['title','namespace','pack','rooms','requiredCapabilities','admission','authoredContent']),content={...level.authoredContent};
  if(level.title!==level.project?.title)return {status:'pending-review',label:'待验收',eligible:false};
  if(content.completion===undefined&&canonicalCollectionJson(level.completion)!==canonicalCollectionJson({type:'exit'}))return {status:'pending-review',label:'待验收',eligible:false};
  for(const key of Object.keys(content))if(!derived.has(key))content[key]=level[key];
  if(Object.keys(level).some(key=>!derived.has(key)&&!['approval','testAdmission','admissionWithdrawal','completion'].includes(key)&&!Object.hasOwn(content,key))||level.admission?.contentFingerprint!==projectFingerprint(content)||level.admission?.projectFingerprint!==projectFingerprint(level.project)||level.admission?.revision!==level.revision)return {status:'pending-review',label:'待验收',eligible:false};
 }
 if(level.approval?.status==='approved'&&(!level.admission||level.admission.status==='owner-approved'))return {status:'owner-approved',label:'作者已认可',eligible:true};
 const record=level.testAdmission,admission=level.admission;
 if(policy?.version===1&&policy.mode==='owner-approved-or-tested'&&policy.scope==='private'&&policy.by==='owner'&&record&&level.authoredContent&&admission?.status==='tested-awaiting-owner-review'){
  validateTestAdmission(record);if(record.revision===level.revision&&admission.revision===level.revision&&record.contentFingerprint===admission.contentFingerprint&&record.projectFingerprint===admission.projectFingerprint&&record.projectFingerprint===projectFingerprint(level.project))return {status:'tested-awaiting-owner-review',label:'测试通过 / 待你查看',eligible:true};
 }
 return {status:'pending-review',label:'待验收',eligible:false};
}
