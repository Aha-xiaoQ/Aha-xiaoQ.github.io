import {mountCompletionMarksTools,pruneCompletionMarksReferences} from './editor-completion-marks-tools.mjs';
import {mountSkyShooterTools,pruneSkyShooterReferences} from './editor-sky-shooter-tools.mjs';
import {mountChainChompGuardTools,captureChainChompGuardBindings,appendCopiedChainChompGuardBindings} from './editor-chain-chomp-guard-tools.mjs';
import {mountCoinCraneTools,captureCoinCraneBindings,appendCopiedCoinCraneBindings} from './editor-coin-crane-tools.mjs';
import {drawCoinCraneWorld} from './editor-coin-crane-art.mjs';
import {mountBowserJrTools} from './editor-bowser-jr-tools.mjs';
import {mountJrArenaAudienceTools,pruneJrArenaAudienceReferences} from './editor-jr-arena-tools.mjs';
import {rendererVisible} from './editor-renderer.mjs';
import {mountSmm2CameraTools} from './editor-camera-tools.mjs';
import {mountDirectionArrowTools} from './editor-direction-arrow-tools.mjs';
import {blockContent,setBlockContent} from './editor-block-content.mjs';
import {placementIssues,formatPlacementIssue} from './editor-placement.mjs';
import {mountSmm2CourseTools,pruneSmm2CourseReferences,captureSmm2GeometryBindings,appendSmm2GeometryBindings} from './editor-smm2-course-tools.mjs';
import {mountHeavyStoneTools,pruneHeavyStoneReferences,captureHeavyStoneBindings,appendCopiedHeavyStoneBindings} from './editor-heavy-stone-tools.mjs';
import {mountLakituTools,pruneLakituReferences,captureRailHazardBindings,appendCopiedRailHazardBindings} from './editor-lakitu-tools.mjs';
import {mountSmm2SnakeBlockTools,captureSmm2SnakeBlockTrains,appendCopiedSmm2SnakeBlockTrains,moveSmm2SnakeBlockSelection,removeSmm2SnakeBlockTrain,initialSmm2SnakeBlockGeometry} from './editor-snake-block-tools.mjs';
import {mountSmwGoalTools,pruneSmwGoalTapeReference} from './editor-smw-goal-tools.mjs';
import {drawSmwUnderwaterSnakeWorld} from './editor-smw-underwater-art.mjs';
import {mountUnderwaterActorTools,pruneUnderwaterActorReferences,captureUnderwaterActorBindings,appendCopiedUnderwaterActorBindings} from './editor-underwater-actor-tools.mjs';
import {mountSmm2LightingTools,pruneSmm2LightingReferences,captureSmm2LightingBindings,appendCopiedSmm2LightingBindings} from './editor-smm2-lighting-tools.mjs';
import {drawSmm2LightingMask} from './editor-smm2-lighting.mjs';
import {mountSmm2BoneTools,pruneSmm2BoneReferences,captureSmm2BoneBindings,appendCopiedSmm2BoneBindings} from './editor-smm2-bone-tools.mjs';
import {mountMissionBriefEditor} from './editor-mission-brief.mjs';
import {mountContraptionsEditor} from './editor-contraptions-editor.mjs';
import {enableCopiedSpikeTraps} from './editor-contraptions-tools.mjs';
import {createContraptionsCourse} from './editor-contraptions.mjs';
import {createRailClaws} from './editor-rail-claws.mjs';
import {createClownCars} from './editor-clown-cars.mjs';
import {drawContraptionsScene,drawCar,drawDoor,drawOneWayWall} from './editor-contraptions-art.mjs';
import {mountCastleTools} from './editor-castle-tools.mjs';
import {mountAquaticTools} from './editor-aquatic-tools.mjs';
import {mountClassicMotionTools} from './editor-classic-motion-tools.mjs';
import {mountNativeSceneryTools} from './editor-native-scenery-tools.mjs';
import {mountSmm2Tools,drawSmm2EditorTerrain,pruneSmm2DeletedReferences,captureSmm2ActorLeaves,appendCopiedSmm2ActorLeaves} from './editor-smm2-tools.mjs';
import {mountPlayRulesEditor} from './editor-play-rules.mjs';
import {mountMarioModulesEditor,pruneMarioEmptyShellReferences,captureMarioEmptyShellSources,appendCopiedMarioEmptyShellSources} from './editor-mario-modules-editor.mjs';
import {createMarioModules} from './editor-mario-modules.mjs';
import {drawMarioModuleWorld} from './editor-study-module-art.mjs';
import {mountCollectionEditor} from './editor-collection-editor.mjs';
import {buildCollection} from './editor-collection.mjs';
import {mountStudyTools} from './editor-study-tools.mjs';
import {createSwitchStudy} from './editor-switch.mjs';
import {drawStudyWorld} from './editor-switch-art.mjs';
import {echoEnabled,createEchoRecorder,drawEchoWorld} from './editor-echo.mjs';
import {mountEchoEditor} from './editor-echo-editor.mjs';
import {heroFor,selectHero} from './editor-heroes.mjs';
import {orderedTerrain,sourceType} from './map-appearance.mjs';
import {enemySprite,enemyLabels,promoteEnemies} from './map-appearance.mjs';
import {classicSprite} from './classic-art.mjs';
import {placeObject,batchObjects,connectPortal,connectionProblems,cleanupStarts} from './editor-objects.mjs';
import {background,drawTile,drawObject,drawScenery,drawConveyorWorld,preloadArt,drawReference} from './editor-art.mjs';
import {offlineFile} from './editor-offline.mjs';
import {developerPack,projectPack,filesForPack} from './editor-runtime.mjs';
import {zipFiles} from './editor-zip.mjs';
import {play} from './editor-play.mjs';
import {displayRoom,roomLabel} from './room-selection.mjs';
import {blank,fromTemplate,parseProject,clone,uid,materials,resizeComponent,paint,bucket,lineCells,History,resize,runtimeMap,problems,intersects,moveSelection,deleteSelection,linked,validate} from './editor-model.mjs';
const $=id=>document.getElementById(id),canvas=$('canvas'),ctx=canvas.getContext('2d'),vp=$('viewport');
const KEY='xiaoq-map-workshop-tools-v1',locks=new Set();
let history=new History(blank()),ri=0,tool='brush',material='ground',objectKind='coin',selected=new Set(),clipboard=null,gesture=null,space=false,camera={x:0,y:0},dirty=false,saveTimer,loadEpoch=0;
const room=()=>history.doc.rooms[ri],layer=()=>$('layer').value,items=()=>layer()==='decoration'?room().decorations:layer()==='objects'?room().map.objects:room().map.geometry;
// Generated collision cells are selectable through their stable train ID;
// items() remains the actual native array used by paint and clipboard writes.
const selectionItems=()=>layer()==='geometry'&&room().smm2Mechanics?.snakeBlocks?[...items(),...initialSmm2SnakeBlockGeometry(room()).map(q=>({...q,id:q.trainId}))]:items();
const z=()=>Number($('zoom').value),lockKey=()=>room().roomId+':'+layer(),locked=()=>locks.has(lockKey());
const compound=()=>layer()!=='objects'&&['tree','shroom','pipe'].includes(material);
const componentBox=(a,b)=>material==='pipe'?{x:a.x*16,y:Math.min(a.y,b.y)*16,w:32,h:Math.max(32,(Math.abs(a.y-b.y)+1)*16)}:{x:Math.min(a.x,b.x)*16,y:a.y*16,w:Math.max(32,(Math.abs(a.x-b.x)+1)*16),h:16};
const say=t=>{$('message').textContent=t;if(/请选择|人物外观|区域已切换/.test(t)){let note=$('skin-feedback');if(!note){note=document.createElement('p');note.id='skin-feedback';note.className='small';note.setAttribute('role','status');$('skin-file').after(note);}note.textContent=t;}};
let rejectedPlacement=[];
function reportError(e){rejectedPlacement=e.issues||[];say(e.message);if(rejectedPlacement.length)render();}
const run=fn=>{try{rejectedPlacement=[];fn();}catch(e){reportError(e);}};
function options(node,list){node.replaceChildren(...list.map(([v,t])=>{const o=document.createElement('option');o.value=v;o.textContent=t;return o;}));}
function buttons(id,list,current,action){$(id).replaceChildren(...list.map(([v,t])=>{const b=document.createElement('button');b.type='button';b.textContent=t;if(id==='materials'){const names={cloud:'src|Scenery|Cloud1||',tree:'src|Solid|TreeTop||left',shroom:'src|Solid|ShroomTop||left',coral:'src|Solid|Coral||',bridge:'src|Solid|BridgeBase||',cannon:'src|Solid|Cannon||top',castle:'src|Solid|CastleBlock||',spring:'src|Solid|Springboard||middle',platform:'src|Solid|Platform||',decoration:'bush1',ground:'ground',brick:'brick',block:'question0',stone:'stone',pipe:'pipe_top',coin:'coin0',walker:'goomba',spawn:'small_idle',arrival:'small_idle',portal:'pipe_top',exit:'flag'};const spriteName=names[v]||enemySprite(v);if(spriteName){const thumb=document.createElement('canvas');thumb.width=32;thumb.height=32;thumb.setAttribute('aria-hidden','true');const g=thumb.getContext('2d'),im=classicSprite(spriteName);g.imageSmoothingEnabled=false;if(v==='spring')drawTile(g,{material:'spring',x:8,y:3,w:16,h:29},{setting:'Overworld'});else g.drawImage(im,Math.floor((32-im.width)/2),32-im.height);b.append(thumb);}}b.setAttribute('aria-pressed',String(v===current));b.onclick=()=>{action(v);palette();};return b;}));}
function palette(){
 buttons('tools',[['brush','画笔 B'],['erase','橡皮 E'],['rect','矩形 R'],['fill','填充 F'],['select','框选 V'],['pick','吸管 I'],['pan','平移']],tool,v=>{cancelGesture();tool=v;});
 buttons('materials',layer()==='objects'?[['spawn','出生点'],['coin','金币'],['exit','出口'],['hazard','危险区'],...Object.entries(enemyLabels),['portal','管道入口'],['arrival','管道落地点']]:Object.entries(materials),layer()==='objects'?objectKind:material,v=>{if(layer()==='objects')objectKind=v;else material=v;});
 let hint=$('placement-hint');if(!hint){hint=document.createElement('p');hint.id='placement-hint';$('materials').after(hint);}hint.textContent=compound()?(material==='pipe'?'完整管道：纵向拖动设置高度；管口固定两格。放置后可在右侧修改尺寸。':'整体平台：横向拖动设置宽度；支撑自动接地，可在右侧设置整体高度。'):'';
 $('locked').checked=locked();
}
function save(){
 clearTimeout(saveTimer);
 try{const saved=gesture?.before||history.doc;validate(saved);localStorage.setItem(KEY,JSON.stringify(saved));dirty=false;$('save-state').textContent='已保存到本机 · '+new Date().toLocaleTimeString();}
 catch(e){dirty=true;if(e.issues){$('save-state').textContent='保存被拦：'+e.message;reportError(e);}else $('save-state').textContent='本机保存失败，请导出工程备份';}
}
function changed(){dirty=true;$('save-state').textContent='正在保存…';clearTimeout(saveTimer);saveTimer=setTimeout(save,450);refresh();}
function pruneDeletedComponents(before){for(const r of history.doc.rooms){const old=before.rooms.find(q=>q.roomId===r.roomId);if(old){pruneSmm2DeletedReferences(r,old);pruneSmm2CourseReferences(r,old);pruneSmm2BoneReferences(r,old);pruneMarioEmptyShellReferences(r,old);pruneSmm2LightingReferences(r,old);pruneHeavyStoneReferences(r,old);pruneLakituReferences(r,old);pruneSmwGoalTapeReference(r,old);pruneUnderwaterActorReferences(r,old);pruneJrArenaAudienceReferences(r,old);pruneSkyShooterReferences(r,old);}}pruneCompletionMarksReferences(history.doc.rooms,before.rooms);}
function transaction(fn){cancelGesture();if(locked())throw Error('当前图层已锁定');if(history.change(d=>{const before=clone(d);fn(d);pruneDeletedComponents(before);}))changed();}
function refresh(){
 const rewardBlock=selected.size===1?room().map.geometry.find(g=>selected.has(g.id)&&['Brick','Block'].includes(sourceType(room(),g))):null;$('reward-settings').hidden=!rewardBlock;if(rewardBlock)$('reward-content').value=blockContent(rewardBlock);
 const hero=heroFor(history.doc),selector=document.getElementById('play-hero');if(selector)selector.value=hero;const description=document.getElementById('hero-description');if(description)description.textContent=hero==='bill'?'魂斗罗 · 比尔：八向连射、趴射，M / S / F / L 武器补给，接触敌人会死亡。此恢复版缺少比尔 BGM，保留声音特效。':'马里奥 · 单跳与踩敌';$('skin-upload').disabled=$('skin-reset').disabled=hero==='bill';
 $('title').value=history.doc.title;
 const r=room();options($('room'),history.doc.rooms.map((r,i)=>[String(i),roomLabel(history.doc.reference?.level,r)]));$('room').value=String(ri);
 $('width').value=Math.ceil(r.map.width/16);$('height').value=Math.ceil(r.map.height/16);
 $('undo').disabled=!history.undoStack.length;$('redo').disabled=!history.redoStack.length;
 const needsNative=history.doc.rooms.some(r=>echoEnabled(r)||r.switchStudy||r.marioModules||r.aquatic||r.contraptions?.coinCranes?.length||r.contraptions?.chainChompGuards?.length||r.smm2Mechanics?.lakituClouds||r.smm2Mechanics?.railHazards||r.smm2Mechanics?.goalCloudRequirements||r.smm2Mechanics?.snakeBlocks||r.map.geometry.some(g=>blockContent(g))||r.markers.some(m=>m.kind==='coupled-scale'));$('pack-export').disabled=needsNative;$('pack-export').title=needsNative?'机关工程请导出 qmap 或原生离线试玩；通用开发包缺少这些行为':'通用基础开发数据';$('campaign-download').textContent='自制合集';$('campaign-download').title='打开自制合集编辑器，按稳定 ID 管理关卡与进度';
 const selectable=selectionItems();selected=new Set([...selected].filter(id=>selectable.some(q=>q.id===id)));
 const chosen=selectable.filter(q=>selected.has(q.id)),chosenIds=new Set(chosen.map(q=>q.id));
 const component=chosen.length===1&&['tree','shroom','pipe'].includes(chosen[0].material)?chosen[0]:null;$('component-size').hidden=!component;if(component){$('component-width').value=component.w;$('component-width').disabled=component.material==='pipe';$('component-height').value=component.material==='pipe'?component.h:component.stemHeight==null?0:component.h+component.stemHeight;}
 $('selection-info').textContent=chosen.length?chosenIds.size+' 个元素 · '+[...new Set(chosen.map(q=>q.kind||q.material||q.collision))].join('、'):'尚未选中';
 $('x').value=chosen.length?Math.min(...chosen.map(q=>q.x)):'';$('y').value=chosen.length?Math.min(...chosen.map(q=>q.y)):'';
 const checks=[...problems(r),...placementIssues(r).filter(q=>q.severity==='warning').map(formatPlacementIssue)];
 $('issues').replaceChildren(...(checks.length?checks:['基础位置检查通过；不代表游戏已通关']).map(t=>{const li=document.createElement('li');li.textContent=t;return li;}));
 $('markers').replaceChildren(...r.markers.filter(q=>!q.kind?.startsWith('decorative')&&!(r.enemiesEditable&&enemySprite(q.kind))).map(q=>{const p=document.createElement('p');p.textContent=(q.kind==='source-arrow'?'方向指引':q.kind||'标记')+' · ('+q.x+', '+q.y+') '+(q.source?.contents?'奖励：'+JSON.stringify(q.source.contents):'')+(q.source?.transport?' 连接：'+JSON.stringify(q.source.transport):'')+(q.kind==='source-arrow'?'（视觉指引，无碰撞）':'（参考机制，未接入行为）');return p;}));
 refreshConnections();palette();echoInspector.refresh();studyTools.refresh();playRulesInspector.refresh();marioModuleTools.refresh();contraptionTools.refresh();coinCraneTools.refresh();if(typeof chainChompGuardTools!=='undefined')chainChompGuardTools.refresh();missionBriefTools.refresh();classicMotionTools.refresh();nativeSceneryTools.refresh();smm2Tools.refresh();smm2CourseTools.refresh();smm2BoneTools.refresh();smm2LightingTools.refresh();heavyStoneTools.refresh();lakituTools.refresh();snakeBlockTools.refresh();smwGoalTools.refresh();underwaterActorTools.refresh();bowserJrTools.refresh();jrArenaTools.refresh();skyShooterTools.refresh();completionMarksTools.refresh();directionArrowTools.refresh();aquaticTools.refresh();castleTools.refresh();cameraTools.refresh();collectionInspector.refresh();render();
}
const playRulesInspector=mountPlayRulesEditor({parent:document.querySelector('aside.properties'),getProject:()=>history.doc,change:fn=>transaction(fn),report:say});
const missionBriefTools=mountMissionBriefEditor({parent:document.querySelector('aside.properties'),room,change:fn=>transaction(fn),report:say});
const chainChompGuardTools=mountChainChompGuardTools({parent:document.querySelector('aside.properties'),room,change:fn=>transaction(fn),report:say});
const coinCraneTools=mountCoinCraneTools({parent:document.querySelector('aside.properties'),room,change:fn=>transaction(fn),report:say});
const contraptionTools=mountContraptionsEditor({parent:document.querySelector('aside.properties'),room,getProject:()=>history.doc,change:fn=>transaction(fn),report:say});
const marioModuleTools=mountMarioModulesEditor({parent:document.querySelector('aside.properties'),room,change:fn=>transaction(fn),report:say});
const studyTools=mountStudyTools({parent:document.querySelector('aside.properties'),room,selected:()=>selected,change:fn=>transaction(fn),report:say});
const classicMotionTools=mountClassicMotionTools({parent:document.querySelector('aside.properties'),room,change:fn=>transaction(fn),report:say});
const nativeSceneryTools=mountNativeSceneryTools({parent:document.querySelector('aside.properties'),room,change:fn=>transaction(fn),report:say});
const directionArrowTools=mountDirectionArrowTools({parent:$('direction-arrow-authoring'),room,change:fn=>transaction(fn),report:say});
const smm2Tools=mountSmm2Tools({parent:document.querySelector('aside.properties'),room,selected:()=>selected,change:fn=>transaction(fn),report:say});
const smm2CourseTools=mountSmm2CourseTools({parent:document.querySelector('aside.properties'),room,selected:()=>selected,change:fn=>transaction(fn),report:say});
const heavyStoneTools=mountHeavyStoneTools({parent:document.querySelector('aside.properties'),room,selected:()=>selected,change:fn=>transaction(fn),report:say});
const lakituTools=mountLakituTools({parent:document.querySelector('aside.properties'),room,selected:()=>selected,change:fn=>transaction(fn),report:say});
const snakeBlockTools=mountSmm2SnakeBlockTools({parent:document.querySelector('aside.properties'),room,selected:()=>selected,select:ids=>{selected=new Set(ids);render();},change:fn=>transaction(fn),report:say});
const smwGoalTools=mountSmwGoalTools({parent:document.querySelector('aside.properties'),room,selected:()=>selected,change:fn=>transaction(fn),report:say});
const bowserJrTools=mountBowserJrTools({parent:document.querySelector('aside.properties'),room,selected:()=>selected,change:fn=>transaction(fn),report:say});
const completionMarksTools=mountCompletionMarksTools({parent:document.querySelector('aside.properties'),room,getRooms:()=>history.doc.rooms,change:fn=>transaction(fn),report:say});
const skyShooterTools=mountSkyShooterTools({parent:document.querySelector('aside.properties'),room,change:fn=>transaction(fn),report:say});
const jrArenaTools=mountJrArenaAudienceTools({parent:document.querySelector('aside.properties'),room,change:fn=>transaction(fn),report:say});
const underwaterActorTools=mountUnderwaterActorTools({parent:document.querySelector('aside.properties'),room,selected:()=>selected,change:fn=>transaction(fn),report:say});
const smm2BoneTools=mountSmm2BoneTools({parent:document.querySelector('aside.properties'),room,selected:()=>selected,change:fn=>transaction(fn),report:say});
const smm2LightingTools=mountSmm2LightingTools({parent:document.querySelector('aside.properties'),room,selected:()=>selected,change:fn=>transaction(fn),report:say});
const aquaticTools=mountAquaticTools({parent:document.querySelector('aside.properties'),room,change:fn=>transaction(fn),report:say});
const cameraTools=mountSmm2CameraTools({parent:document.querySelector('aside.properties'),room,change:fn=>transaction(fn),report:say});
const castleTools=mountCastleTools({parent:document.querySelector('aside.properties'),room,change:fn=>transaction(fn),report:say});
const collectionInspector=mountCollectionEditor({key:'xiaoq-tools-collection-draft-v1',parent:document.querySelector('aside.properties'),getProject:()=>{cancelGesture();save();return history.doc;},getEntryRoom:()=>room().roomId,loadProject:d=>{if(safeSwitch())replace(d);},exportOffline:exportCustomCollection,report:say});
const echoInspector=mountEchoEditor({parent:document.querySelector('aside.properties'),room,change:fn=>transaction(fn),report:say});
const colors={ground:'#99704d',brick:'#ba6849',stone:'#8d99ae',block:'#e5ae38',platform:'#cba964',decoration:'#477862'};
function render(){
 const w=vp.clientWidth,h=vp.clientHeight,dpr=Math.min(devicePixelRatio||1,2);canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,w,h);ctx.imageSmoothingEnabled=false;
 const r=room(),m=r.map,scale=z(),artRoom={...r,renderBounds:{x:camera.x,y:camera.y,w:w/z(),h:h/z()}},effect=$('view').value!=='structure';ctx.save();ctx.scale(scale,scale);ctx.translate(-camera.x,-camera.y);
 if(effect){background(ctx,r,m.width,m.height);drawScenery(ctx,artRoom);}else{ctx.fillStyle='#16161c';ctx.fillRect(0,0,m.width,m.height);}
 if(effect)for(const q of r.markers)if(/^(lava|water)-/.test(q.kind))drawReference(ctx,q,artRoom);
 drawSmm2EditorTerrain(ctx,artRoom,{effect});
 const visible=q=>rendererVisible(q,artRoom,artRoom.renderBounds);
 for(const [kind,a] of [['decoration',r.decorations],['geometry',orderedTerrain(r,m.geometry)],['objects',m.objects]])for(const q of a){
  if(!visible(q))continue;const mat=q.material||(q.collision==='oneway'?'platform':'ground');
  ctx.fillStyle=kind==='objects'?({spawn:'#50d5bd',coin:'#ffdb50',exit:'#7fe580',hazard:'#fa5260',portal:'#ac88ff',walker:'#bf664b'}[q.kind]||'#f7f3e7'):effect?colors[mat]||colors.ground:q.motion?'#dbad55':q.collision==='oneway'?'#77bcae':'#e8e0cb';
  if(effect){if(kind==='objects')drawObject(ctx,{...q,skin:r.enemySkins?.[q.id],source:r.markers?.find(m=>m.id===q.id)?.source},0,r);else if(q.studyArt!=='native-cloud')drawTile(ctx,q,artRoom,{sceneryDrawn:true});}else ctx.fillRect(q.x,q.y,q.w,q.h);
  if(selected.has(q.id)&&kind===layer()){ctx.strokeStyle='#ffef89';ctx.lineWidth=2/scale;ctx.strokeRect(q.x,q.y,q.w,q.h);}
 }
 if(effect)drawConveyorWorld(ctx,artRoom);
 if(effect)drawSmwUnderwaterSnakeWorld(ctx,artRoom);
 if(r.smm2Mechanics?.snakeBlocks)for(const q of initialSmm2SnakeBlockGeometry(r)){if(!visible(q))continue;if(!effect){ctx.fillStyle=q.color==='blue'?'#73afff':'#95cf52';ctx.fillRect(q.x,q.y,q.w,q.h);}if(layer()==='geometry'&&selected.has(q.trainId)){ctx.strokeStyle='#ffef89';ctx.lineWidth=2/scale;ctx.strokeRect(q.x,q.y,q.w,q.h);}}
 if(r.aquatic&&$('view').value!=='effect')for(const q of aquaticTools.currentOverlays()){ctx.save();ctx.lineWidth=1/scale;ctx.strokeStyle='#86dff7';ctx.setLineDash([3,3]);ctx.strokeRect(q.x,q.y,q.w,q.h);ctx.beginPath();ctx.moveTo(q.centerX,q.y);ctx.lineTo(q.centerX,q.y+q.h);ctx.stroke();ctx.restore();}
 if(r.switchStudy){const preview=createSwitchStudy([r],r.roomId);if(effect)drawStudyWorld(ctx,{switchStudy:preview.view(r.roomId)},artRoom);else for(const q of preview.view(r.roomId).devices){ctx.strokeStyle=q.active?'#f66':'#77f';ctx.setLineDash(q.active?[]:[3,2]);ctx.strokeRect(q.x,q.y,q.w,q.h);ctx.setLineDash([]);}}
 if(r.marioModules){const preview=createMarioModules(r);const geometry=preview.geometry(r.map.geometry),view={geometry,marioModules:preview.view()};if(effect){for(const q of geometry.filter(q=>q.marioModuleDevice))drawTile(ctx,q,artRoom);drawMarioModuleWorld(ctx,view,artRoom);}else for(const q of [...preview.view().noteBlocks,...preview.view().oneWayWalls]){ctx.strokeStyle='#ffdf82';ctx.strokeRect(q.x,q.y,q.w,q.h);}}
 if(r.contraptions){const p=createContraptionsCourse([r]),state={...p.view(r.roomId),...createRailClaws(r)?.view(),...createClownCars(r)?.view()},viewRoom={...artRoom,contraptionsView:state};if(effect){for(const q of p.geometry(r.roomId,m.geometry).filter(q=>q.contraptionDevice))drawTile(ctx,q,viewRoom);drawContraptionsScene(ctx,viewRoom,{backdrop:false});drawCoinCraneWorld(ctx,viewRoom);for(const q of state.doors)drawDoor(ctx,q,viewRoom);for(const q of state.oneWayWalls)drawOneWayWall(ctx,q);for(const q of state.cars||[])drawCar(ctx,q);}else for(const q of [...state.notes,...state.oneWayWalls,...state.cars||[]]){ctx.strokeStyle='#ffdf82';ctx.strokeRect(q.x,q.y,q.w,q.h);}}
 if(echoEnabled(r)){const preview=createEchoRecorder(r);const solidDevices=preview.apply([],{x:-100,y:-100,w:1,h:1,grounded:false});if(effect)for(const g of solidDevices)drawTile(ctx,g,artRoom);drawEchoWorld(ctx,preview.view(),artRoom);}
 if($('reference').checked||$('view').value==='secrets')for(const q of r.markers){
  if(effect&&/^(lava|water)-/.test(q.kind))continue;
  if(r.enemiesEditable&&enemySprite(q.kind))continue;if(drawReference(ctx,q,artRoom))continue;const hidden=q.kind==='hidden-block'||q.source?.hidden;if(hidden&&$('view').value!=='secrets')continue;
  if($('view').value==='effect')continue;
  if(q.x<camera.x-30||q.x>camera.x+w/scale||q.y<camera.y-30||q.y>camera.y+h/scale||q.kind?.startsWith('decorative'))continue;
  ctx.strokeStyle='#ff7399';ctx.lineWidth=1/scale;ctx.setLineDash(hidden?[3,2]:[]);ctx.strokeRect(q.x,q.y,16,16);ctx.setLineDash([]);
  ctx.fillStyle='#1b1026';ctx.font='9px sans-serif';ctx.fillText(hidden?'隐':q.kind?.startsWith('enemy')?(enemyLabels[q.kind]||q.kind.slice(6)):q.kind==='block-contents'?'?':'◇',q.x+2,q.y+12);
 }
 if($('view').value==='secrets'){
  ctx.font='10px sans-serif';
  const placed=[];const label=(text,x,y,color='#fff19c')=>{const width=ctx.measureText(text).width+8;x=Math.max(camera.x+2,Math.min(x,camera.x+w/scale-width-2));while(placed.some(b=>x<b.x+b.w&&x+width>b.x&&y-12<b.y+15&&y>b.y))y-=18;placed.push({x,y:y-12,w:width});ctx.fillStyle='#171324ee';ctx.fillRect(x,y-12,width,15);ctx.fillStyle=color;ctx.fillText(text,x+4,y);};
  for(const q of r.markers){if(q.x+16<camera.x||q.x>camera.x+w/scale||(!/hidden|contents|pipe|transport|finish/.test(q.kind)&&!q.source?.contents))continue;ctx.strokeStyle='#ffcf62';ctx.lineWidth=2/scale;ctx.setLineDash([4,3]);ctx.strokeRect(q.x,q.y,16,16);ctx.setLineDash([]);const content=q.source?.contents,labels={coin:'金币',power:'成长道具',mushroom:'成长道具',life:'加命蘑菇',star:'无敌星',multi:'多枚金币'};label((/hidden/.test(q.kind)?'隐藏奖励：':'奖励：')+(content?(labels[String(content).toLowerCase()]||JSON.stringify(content)):q.kind),q.x,q.y-5);}
  for(const o of m.objects.filter(o=>o.kind==='portal'&&visible(o))){const target=history.doc.rooms.find(r=>r.roomId===o.targetRoom),arrival=target?.map.objects.find(q=>q.id===o.targetSpawn);ctx.strokeStyle='#bd9aff';ctx.lineWidth=2/scale;ctx.strokeRect(o.x,o.y,o.w,o.h);label('管道 → '+(target?.map.title||o.targetRoom)+' / '+o.targetSpawn,o.x,o.y-20,'#cfb7ff');if(target===r&&arrival){ctx.setLineDash([6,3]);ctx.beginPath();ctx.moveTo(o.x+o.w/2,o.y);ctx.lineTo(arrival.x+arrival.w/2,arrival.y);ctx.stroke();ctx.setLineDash([]);label('落点',arrival.x,arrival.y-4,'#cfb7ff');}}
  for(const o of m.objects.filter(o=>(o.kind==='spawn'||o.kind==='exit')&&visible(o)))label(o.kind==='exit'?'终点':'起点 / 落点',o.x,o.y-8,'#9effd0');
 }
 if($('view').value==='effect'){ctx.restore();const lightingDrawn=drawSmm2LightingMask(ctx,r,null,{camera:{x:camera.x,y:camera.y,width:w/scale,height:h/scale},width:Math.round(w),height:Math.round(h),preview:true});ctx.save();ctx.scale(scale,scale);ctx.translate(-camera.x,-camera.y);if(lightingDrawn){ctx.strokeStyle='#ffef89';ctx.lineWidth=2/scale;for(const q of items().filter(q=>selected.has(q.id)))ctx.strokeRect(q.x,q.y,q.w,q.h);}}
 if($('grid').checked&&scale>=1){ctx.strokeStyle='#0002';ctx.lineWidth=.5/scale;ctx.beginPath();for(let x=Math.max(0,Math.floor(camera.x/16)*16);x<Math.min(m.width,camera.x+w/scale);x+=16){ctx.moveTo(x,Math.max(0,camera.y));ctx.lineTo(x,Math.min(m.height,camera.y+h/scale));}for(let y=Math.max(0,Math.floor(camera.y/16)*16);y<Math.min(m.height,camera.y+h/scale);y+=16){ctx.moveTo(Math.max(0,camera.x),y);ctx.lineTo(Math.min(m.width,camera.x+w/scale),y);}ctx.stroke();}
 for(const q of m.geometry)if(blockContent(q)){ctx.fillStyle='#ffdf65';ctx.font='9px sans-serif';ctx.fillText('藏 '+blockContent(q),q.x,q.y-3);}
 for(const issue of [...placementIssues(r).filter(q=>q.severity==='error'),...rejectedPlacement])if(issue.bounds){const b=issue.bounds;ctx.strokeStyle='#ff355d';ctx.fillStyle='#ff355d33';ctx.lineWidth=2/scale;ctx.fillRect(b.x,b.y,b.w,b.h);ctx.strokeRect(b.x,b.y,b.w,b.h);ctx.font='10px sans-serif';const lines=[issue.code+' @ '+b.x+', '+b.y,...issue.ids],labelWidth=Math.max(...lines.map(t=>ctx.measureText(t).width))+10,labelX=Math.max(camera.x,Math.min(b.x,camera.x+w/scale-labelWidth)),labelY=Math.max(camera.y,b.y-12*lines.length-4);ctx.fillStyle='#210b18';ctx.fillRect(labelX,labelY,labelWidth,12*lines.length+4);ctx.fillStyle='#ffb4c3';for(let n=0;n<lines.length;n++)ctx.fillText(lines[n],labelX+5,labelY+11+n*12);}
 if(gesture?.box){ctx.strokeStyle='#fff';ctx.fillStyle='#fff2';const b=gesture.box;ctx.fillRect(b.x,b.y,b.w,b.h);ctx.strokeRect(b.x,b.y,b.w,b.h);}
 ctx.strokeStyle='#f7f3e7';ctx.lineWidth=1/scale;ctx.strokeRect(0,0,m.width,m.height);ctx.restore();
}
function point(e){const b=canvas.getBoundingClientRect();return {x:(e.clientX-b.left)/z()+camera.x,y:(e.clientY-b.top)/z()+camera.y};}
const cell=p=>({x:Math.floor(p.x/16),y:Math.floor(p.y/16)});
const box=(a,b)=>({x:Math.min(a.x,b.x)*16,y:Math.min(a.y,b.y)*16,w:(Math.abs(a.x-b.x)+1)*16,h:(Math.abs(a.y-b.y)+1)*16});
function stroke(c){
 if(layer()==='objects'){
  if(tool==='erase')room().map.objects=items().filter(q=>!intersects(q,{x:c.x*16,y:c.y*16,w:16,h:16}));
  else placeObject(room(),objectKind,c.x*16,c.y*16);
 }else paint(room(),{x:c.x*16,y:c.y*16,w:16,h:16},material,{erase:tool==='erase',layer:layer()});
}
function cancelGesture(){if(!gesture)return;if(gesture.before)history.doc=gesture.before;gesture=null;refresh();}
canvas.onpointerdown=e=>run(()=>{
 if(e.button>1||gesture)return;e.preventDefault();vp.focus();canvas.setPointerCapture(e.pointerId);
 const p=point(e),c=cell(p);if(tool==='pan'||space||e.button===1){gesture={pointerId:e.pointerId,pan:true,start:{x:e.clientX,y:e.clientY},camera:{...camera}};return;}
 if(tool==='pick'){const q=[...items()].reverse().find(q=>intersects(q,{...p,w:1,h:1}));if(q){if(layer()==='objects')objectKind=q.kind;else material=q.material||(q.collision==='oneway'?'platform':'ground');palette();}return;}
 if(locked())throw Error('当前图层已锁定');
 if(tool==='fill'){if(compound())throw Error('完整组件请拖动放置，不使用填充');if(layer()==='objects')throw Error('对象层不支持填充');transaction(()=>bucket(room(),c.x,c.y,material,{layer:layer()}));return;}
 gesture={pointerId:e.pointerId,before:clone(history.doc),start:c,last:c,box:null,compound:compound()&&['brush','rect'].includes(tool)};
 if(tool==='select'&&selectionItems().some(q=>selected.has(q.id)&&intersects(q,{...p,w:1,h:1})))gesture.move=true;
 try{if(gesture.compound)gesture.box=componentBox(c,c);else if(['brush','erase'].includes(tool))stroke(c);else gesture.box=box(c,c);}catch(err){cancelGesture();throw err;}render();
});
canvas.onpointermove=e=>run(()=>{
 const p=point(e),c=cell(p);if(!gesture){say('位置：'+c.x+', '+c.y+' 格 · '+Math.round(p.x)+', '+Math.round(p.y)+' 像素');return;}if(e.pointerId!==gesture.pointerId)return;
 if(gesture.pan){camera.x=Math.max(0,Math.min(room().map.width-32,gesture.camera.x-(e.clientX-gesture.start.x)/z()));camera.y=Math.max(0,Math.min(room().map.height-32,gesture.camera.y-(e.clientY-gesture.start.y)/z()));render();return;}
 try{if(gesture.compound){gesture.box=componentBox(gesture.start,c);}else if(gesture.move){gesture.last=c;gesture.box=box(c,c);}else if(['brush','erase'].includes(tool)){for(const t of lineCells(gesture.last,c))stroke(t);gesture.last=c;}else gesture.box=box(gesture.start,c);}catch(err){cancelGesture();throw err;}render();
});
canvas.onpointerup=e=>run(()=>{
 if(!gesture||e.pointerId!==gesture.pointerId)return;if(gesture.pan){gesture=null;return;}
 const g=gesture;gesture=null;
 try{
  if(g.move){translateSelection((g.last.x-g.start.x)*16,(g.last.y-g.start.y)*16);if(history.commit(g.before))changed();else refresh();return;}
  if(tool==='select'){selected=new Set(selectionItems().filter(q=>intersects(q,g.box)).map(q=>q.id));refresh();return;}
  if(g.compound){if(g.box.x+g.box.w>room().map.width||g.box.y+g.box.h>room().map.height)throw Error('组件超出地图，请留出完整宽高');paint(room(),g.box,material,{layer:layer()});selected=new Set(items().filter(q=>q.material===material&&intersects(q,g.box)).map(q=>q.id));}
  else if(tool==='rect'){if(layer()==='objects')batchObjects(room(),objectKind,g.box,Number($('spacing').value)||2);else paint(room(),g.box,material,{layer:layer()});}
  pruneDeletedComponents(g.before);if(history.commit(g.before))changed();else refresh();
 }catch(e){history.doc=g.before;refresh();throw e;}
});
canvas.onpointercancel=e=>{if(gesture?.pointerId===e.pointerId)cancelGesture();};canvas.onlostpointercapture=e=>{if(gesture?.pointerId===e.pointerId)cancelGesture();};
canvas.oncontextmenu=e=>e.preventDefault();
vp.onwheel=e=>{e.preventDefault();camera.x=Math.max(0,Math.min(room().map.width-32,camera.x+(e.shiftKey?e.deltaY:e.deltaX)/z()));camera.y=Math.max(0,Math.min(room().map.height-32,camera.y+(e.shiftKey?0:e.deltaY)/z()));render();};
function translateSelection(dx,dy){if(room().smm2Mechanics?.snakeBlocks?.trains.some(q=>selected.has(q.id)))moveSmm2SnakeBlockSelection(room(),layer(),selected,dx,dy);else moveSelection(room(),layer(),selected,dx,dy);}
function move(dx,dy){transaction(()=>translateSelection(dx,dy));}
function download(name,data){const u=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'})),a=document.createElement('a');a.href=u;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(u),30000);}
function safeSwitch(){cancelGesture();save();return !dirty||confirm('本机保存失败，切换会丢失当前改动。仍要继续吗？建议取消并先导出工程。');}
function selectedRoom(d){return d.rooms.findIndex(r=>r.roomId===displayRoom(d.reference?.level,d.rooms,d.activeRoomId));}
function replace(d){history=new History(d);const loaded=history.doc;restoreAppearance().then(()=>{if(history.doc===loaded){for(const r of loaded.rooms)promoteEnemies(r);render();}});ri=selectedRoom(d);selected.clear();locks.clear();camera={x:0,y:0};preloadArt(d.rooms).then(render).catch(e=>say(e.message));changed();}
$('new').onclick=()=>{if(confirm('新建会替换当前本机草稿。需要保留多个工程时，请先导出。')&&safeSwitch())replace(selectHero(blank(),heroFor(history.doc)));};
$('open').onclick=()=>$('file').click();
$('file').onchange=async()=>{const f=$('file').files[0];$('file').value='';if(!f)return;try{if(f.size>12*1024*1024)throw Error('文件超过 12 MB');const d=parseProject(await f.text());if(confirm('打开工程会替换当前本机草稿，是否继续？')&&safeSwitch())replace(d);}catch(e){reportError(e);}};
$('export').onclick=()=>run(()=>{cancelGesture();validate(history.doc);save();download('my-map.qmap.json',history.doc);say('工程已导出，可在其他电脑打开继续编辑。');});
$('save').onclick=save;
$('undo').onclick=()=>{cancelGesture();if(history.undo())changed();};
$('redo').onclick=()=>{cancelGesture();if(history.redo())changed();};
$('title').onchange=()=>run(()=>{const title=$('title').value.trim();cancelGesture();history.change(d=>{d.title=title;});changed();});
$('layer').onchange=()=>{cancelGesture();selected.clear();refresh();};
$('locked').onchange=()=>{cancelGesture();if($('locked').checked)locks.add(lockKey());else locks.delete(lockKey());};
$('room').onchange=()=>{const next=Number($('room').value);cancelGesture();ri=next;history.doc.activeRoomId=room().roomId;save();camera={x:0,y:0};selected.clear();refresh();};
for(const id of ['zoom','view','grid','reference'])$(id).onchange=render;
$('size').onsubmit=e=>{e.preventDefault();run(()=>{transaction(()=>resize(room(),Number($('width').value)*16,Number($('height').value)*16));});};
$('component-size').onsubmit=e=>{e.preventDefault();run(()=>transaction(()=>{const q=items().find(q=>selected.has(q.id));if(!q)throw Error('先选中一个组件');resizeComponent(room(),q,Number($('component-width').value),Number($('component-height').value));}));};
$('position').onsubmit=e=>{e.preventDefault();run(()=>{const a=selectionItems().filter(q=>selected.has(q.id));if(!a.length)throw Error('请先框选元素');move(Number($('x').value)-Math.min(...a.map(q=>q.x)),Number($('y').value)-Math.min(...a.map(q=>q.y)));});};
$('copy').onclick=()=>{const picked=items().filter(q=>selected.has(q.id)),snakeBlocks=layer()==='geometry'&&room().smm2Mechanics?.snakeBlocks?captureSmm2SnakeBlockTrains(room(),selected):[],anchors=[...picked,...(snakeBlocks.length?initialSmm2SnakeBlockGeometry(room()).filter(q=>selected.has(q.trainId)):[])],underwaterActors=['objects','geometry'].includes(layer())&&(room().smm2Mechanics?.underwaterActors||room().marioModules?.enemySources?.some(q=>q.emitterKind==='launcher'||['fish-bone','galoomba'].includes(q.enemy)))?captureUnderwaterActorBindings(room(),selected,{layer:layer()}):null,marioEmptyShellSources=layer()==='geometry'?captureMarioEmptyShellSources(room(),selected):null;if(underwaterActors?.enemySources?.length&&marioEmptyShellSources)marioEmptyShellSources.enemySources=marioEmptyShellSources.enemySources.filter(q=>!underwaterActors.enemySources.some(source=>source.id===q.id));clipboard={layer:layer(),chainChompGuards:room().contraptions?.chainChompGuards?.length&&layer()==='objects'?captureChainChompGuardBindings(room(),selected):null,coinCranes:room().contraptions?.coinCranes?.length&&['objects','geometry'].includes(layer())?captureCoinCraneBindings(room(),selected):null,items:clone(picked),snakeBlocks,underwaterActors,bounds:anchors.length?{x:Math.min(...anchors.map(q=>q.x)),y:Math.min(...anchors.map(q=>q.y))}:null,markers:layer()==='geometry'?clone(room().markers.filter(m=>picked.some(q=>linked(m,q.id)))):[],smm2Actors:layer()==='objects'?captureSmm2ActorLeaves(room(),selected):null,smm2Geometry:layer()==='geometry'?captureSmm2GeometryBindings(room(),selected):null,smm2Lighting:['objects','geometry'].includes(layer())?captureSmm2LightingBindings(room(),new Set([...selected,...(layer()==='geometry'?room().markers.filter(m=>picked.some(q=>linked(m,q.id))).map(q=>q.id):[])])):null,smm2Bones:['objects','geometry'].includes(layer())?captureSmm2BoneBindings(room(),selected,{layer:layer()}):null,heavyStones:layer()==='objects'&&(room().smm2Mechanics?.portableStones||room().smm2Mechanics?.localUpdrafts||room().smm2Mechanics?.parachuteActors)?captureHeavyStoneBindings(room(),selected):null,railHazards:layer()==='objects'&&room().smm2Mechanics?.railHazards?captureRailHazardBindings(room(),selected):null,marioWalkingVariants:layer()==='objects'?Object.fromEntries(Object.entries(room().marioModules?.enemyVariants||{}).filter(([id,q])=>selected.has(id)&&q.kind==='walking-koopa').map(([id,q])=>[id,clone(q)])):null,marioEmptyShellSources};say('已复制 '+(clipboard.items.length+(clipboard.snakeBlocks?.length||0))+' 个元素，粘贴到当前视图左上角。');};
$('paste').onclick=()=>run(()=>{
 if(!clipboard?.items.length&&!clipboard?.snakeBlocks?.length)throw Error('请先框选并复制');if(clipboard.layer!==layer())throw Error('请切换到复制时的图层再粘贴');
 if(layer()==='objects'&&clipboard.items.some(o=>['spawn','portal'].includes(o.kind)||o.kind==='exit'&&clipboard.heavyStones?.clearCondition?.goalId!==o.id))throw Error('起点、终点和管道请单独放置；搬运终点须与有效石材一起复制');
 const a=clone(clipboard.items),markers=clone(clipboard.markers),dx=Math.ceil(camera.x/16)*16+16-(clipboard.bounds?.x??Math.min(...a.map(q=>q.x))),dy=Math.ceil(camera.y/16)*16+16+(clipboard.chainChompGuards?.length?(room().smm2Mechanics?.art?.tileOriginY??0)%16:0)-(clipboard.bounds?.y??Math.min(...a.map(q=>q.y)));let snakeIds=new Map();
 transaction(()=>{const idMap=new Map();for(const q of a){const old=q.id;q.id=uid();idMap.set(old,q.id);for(const m of markers){if(linked(m,old)){const markerId=m.id;m.id=q.id+m.id.slice(old.length);idMap.set(markerId,m.id);}}}items().push(...a);room().markers.push(...markers);moveSelection(room(),layer(),new Set(a.map(q=>q.id)),dx,dy);if(clipboard.coinCranes)appendCopiedCoinCraneBindings(room(),clipboard.coinCranes,idMap,{dx,dy});if(layer()==='objects'){appendCopiedSmm2ActorLeaves(room(),clipboard.smm2Actors,idMap);if(clipboard.heavyStones)appendCopiedHeavyStoneBindings(room(),clipboard.heavyStones,idMap);if(clipboard.railHazards)appendCopiedRailHazardBindings(room(),clipboard.railHazards,idMap,{dx,dy});for(const [id,q]of Object.entries(clipboard.marioWalkingVariants||{})){const copyId=idMap.get(id);if(copyId){room().marioModules??={version:1};room().marioModules.enemyVariants??={};room().marioModules.enemyVariants[copyId]=clone(q);}}enableCopiedSpikeTraps(room());}else if(layer()==='geometry')appendSmm2GeometryBindings(room(),clipboard.smm2Geometry,idMap);appendCopiedSmm2BoneBindings(room(),clipboard.smm2Bones,idMap);appendCopiedMarioEmptyShellSources(room(),clipboard.marioEmptyShellSources,idMap);if(clipboard.underwaterActors)appendCopiedUnderwaterActorBindings(room(),clipboard.underwaterActors,idMap);appendCopiedSmm2LightingBindings(room(),clipboard.smm2Lighting,idMap);if(clipboard.chainChompGuards)appendCopiedChainChompGuardBindings(room(),clipboard.chainChompGuards,idMap,{dx,dy});if(clipboard.snakeBlocks?.length)snakeIds=appendCopiedSmm2SnakeBlockTrains(room(),clipboard.snakeBlocks,{dx,dy});});selected=new Set([...a.map(q=>q.id),...snakeIds.values()]);refresh();
});
$('delete').onclick=()=>run(()=>transaction(()=>{for(const id of [...selected])if(room().smm2Mechanics?.snakeBlocks?.trains.some(q=>q.id===id))removeSmm2SnakeBlockTrain(room(),id);deleteSelection(room(),layer(),selected);}));
$('map-export').onclick=async()=>{try{const p=await getPack();download('map.json',p.maps[0]);say('区域数据已导出，完整接入请使用开发包。');}catch(e){say(e.message);}};
$('help').onclick=()=>$('help-dialog').showModal();
document.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>b.closest('dialog').close());
function updateTemplateInfo(){$('template-info').textContent='中性组件样例 · 用于验证工具，不是原作关卡。';}
function updateTemplateLevels(){options($('base'),[['neutral-demo','中性组件样例']]);updateTemplateInfo();}
$('base-world').onchange=()=>updateTemplateLevels();$('base').onchange=updateTemplateInfo;
$('template').onclick=async()=>{options($('base-world'),[['neutral','工具样例']]);updateTemplateLevels();$('template-dialog').showModal();};
$('load-template').onclick=async()=>{const n=++loadEpoch;$('load-template').disabled=true;try{const res=await fetch('../examples/neutral-demo.qmap.json');if(!res.ok)throw Error('中性样例读取失败，请先运行 npm run build');const d=selectHero(parseProject(await res.text()),heroFor(history.doc));d.id=uid();if(n!==loadEpoch)return;if(confirm('将用中性样例替换本机草稿，请确认已导出需要保留的工程。')&&safeSwitch()){replace(d);$('template-dialog').close();say('中性样例已载入，可编辑并导出。');}}catch(e){say(e.message);}finally{$('load-template').disabled=false;}};
document.addEventListener('keydown',e=>{
 if(e.target.closest('input,select,textarea,dialog'))return;
 if(e.code==='Space'){space=true;e.preventDefault();return;}
 if(e.key==='Escape'){cancelGesture();return;}
 const k=e.key.toLowerCase();
 if(e.ctrlKey||e.metaKey){const id=k==='z'?(e.shiftKey?'redo':'undo'):k==='y'?'redo':k==='c'?'copy':k==='v'?'paste':k==='s'?'export':null;if(id){e.preventDefault();$(id).click();}return;}
 if(k==='delete'||k==='backspace'){e.preventDefault();$('delete').click();return;}
 const arrows={ArrowLeft:[-16,0],ArrowRight:[16,0],ArrowUp:[0,-16],ArrowDown:[0,16]};if(arrows[e.key]){e.preventDefault();run(()=>move(...arrows[e.key]));return;}
 const tools={b:'brush',e:'erase',r:'rect',f:'fill',v:'select',i:'pick'};if(tools[k]){cancelGesture();tool=tools[k];palette();}
});
document.addEventListener('keyup',e=>{if(e.code==='Space')space=false;});window.addEventListener('blur',()=>{space=false;cancelGesture();});
window.addEventListener('beforeunload',e=>{if(dirty){save();if(dirty){e.preventDefault();e.returnValue='';}}});
new ResizeObserver(render).observe(vp);
try{const saved=localStorage.getItem(KEY);if(saved){history=new History(parseProject(saved));ri=selectedRoom(history.doc);}}catch(e){say('未恢复本机草稿：'+e.message+'。原存储尚未覆盖，请先导出可用备份。');}
refresh();

async function getPack(){cancelGesture();if(room().map.geometry.some(g=>blockContent(g)))throw Error('砖块藏物依赖原生作者数据，请导出 qmap 工程或离线试玩；区域 map.json 不保存藏物');const copy=clone(room()),namespace='map-'+history.doc.id.slice(-12)+'-'+ri;copy.map.title=history.doc.title+' / '+room().roomId;const res=await fetch('./runtime/character.json');if(!res.ok)throw Error('实验角色加载失败');return developerPack(copy,await res.json(),namespace);}
$('play').onclick=async()=>{try{const p=await getProjectPack();await play(p,clone(history.doc.rooms),{},{onWarp:async()=>say('此工具包使用作者自制合集管理关卡，不附原作32关模板。'),...(history.doc.rooms.some(echoEnabled)?{developerMode:false}:{})});}catch(e){say(e.message);}};
$('pack-export').onclick=async()=>{if(history.doc.rooms.some(r=>echoEnabled(r)||r.switchStudy||r.marioModules||r.aquatic||r.contraptions?.coinCranes?.length||r.contraptions?.chainChompGuards?.length||r.smm2Mechanics?.lakituClouds||r.smm2Mechanics?.railHazards||r.smm2Mechanics?.goalCloudRequirements||r.smm2Mechanics?.snakeBlocks||r.map.geometry.some(g=>blockContent(g))||r.markers.some(m=>m.kind==='coupled-scale'))){say('通用开发包无法执行这些原生机关，请导出 qmap 工程或下载离线试玩。');return;}try{const pack=await getProjectPack(),bytes=zipFiles(filesForPack(pack)),url=URL.createObjectURL(new Blob([bytes],{type:'application/zip'})),a=document.createElement('a');a.href=url;a.download='map-development.zip';a.click();setTimeout(()=>URL.revokeObjectURL(url),30000);say('开发数据包已导出，内含接入说明。请另存工程文件作为完整备份。');}catch(e){say(e.message);}};

async function getProjectPack(){cancelGesture();await restoreAppearance();const res=await fetch('./runtime/character.json');if(!res.ok)throw Error('角色加载失败');return projectPack(history.doc,room().roomId,await res.json(),'map-'+history.doc.id.slice(-12));}
function refreshConnections(){
 const portal=items().find(o=>selected.has(o.id)&&o.kind==='portal');
 options($('target'),history.doc.rooms.flatMap(r=>r.map.objects.filter(o=>o.kind==='spawn').map(o=>[JSON.stringify([r.roomId,o.id]),r.roomId+' / '+(o.id.startsWith('arrival-')?'落地点':'起点')+' ('+o.x+', '+o.y+')'])));
 if(portal?.targetRoom)$('target').value=JSON.stringify([portal.targetRoom,portal.targetSpawn]);
 $('connect').disabled=!portal;
 $('connection-status').textContent=portal?'选中管道：'+portal.id:'框选一个管道后设置目标；每个落地点显示坐标。';
 const errors=connectionProblems(history.doc);if(errors.length)$('connection-status').textContent+=' '+errors.length+' 个连接待配置';
}
$('connect').onclick=()=>run(()=>{const p=items().find(o=>selected.has(o.id)&&o.kind==='portal');if(!p)throw Error('请先框选管道');const [r,s]=JSON.parse($('target').value);transaction(()=>connectPortal(history.doc,room().roomId,p.id,r,s));});
let offlineUrl=null;
$('play-download').onclick=async()=>{const button=$('play-download'),dialog=$('download-dialog'),status=$('download-status'),progress=$('download-progress'),link=$('download-ready');button.disabled=true;button.textContent='正在准备…';status.textContent='正在准备地图与声音…';progress.value=0;link.hidden=true;if(offlineUrl){URL.revokeObjectURL(offlineUrl);offlineUrl=null;}if(!dialog.open)dialog.showModal();try{const pack=await getProjectPack(),html=await offlineFile(pack,clone(history.doc.rooms),undefined,undefined,(done,total)=>{progress.value=Math.round(done/total*100);status.textContent='正在打包地图、画面与声音… '+progress.value+'%';});offlineUrl=URL.createObjectURL(new Blob([html],{type:'text/html;charset=utf-8'}));link.href=offlineUrl;link.download=(pack.stages[0].title||'my-map').replace(/[<>:"/\\|?*\x00-\x1f]/g,'-').slice(0,80)+'-play.html';link.hidden=false;progress.value=100;status.textContent='离线文件已准备好（'+(new Blob([html]).size/1024/1024).toFixed(1)+' MB），点击下方按钮保存。';if(!dialog.open)dialog.showModal();say('离线试玩文件已准备好，请点击保存链接。');}catch(e){status.textContent='未能生成离线文件：'+e.message;say(status.textContent);if(!dialog.open)dialog.showModal();}finally{button.disabled=false;button.textContent='下载离线试玩';}};
$('download-ready').onclick=()=>{$('download-status').textContent='已请求浏览器保存。若没有出现下载，请再点一次，并检查浏览器下载列表。';};
window.addEventListener('pagehide',()=>{if(offlineUrl)URL.revokeObjectURL(offlineUrl);});

$('add-room').onclick=()=>run(()=>{cancelGesture();history.change(d=>{const r=blank('新区域',1280,480).rooms[0];r.playHero=heroFor(d);r.roomId='room-'+uid().slice(-8);d.rooms.push(r);});ri=history.doc.rooms.length-1;camera={x:0,y:0};selected.clear();changed();});

preloadArt(history.doc.rooms).then(render).catch(e=>say(e.message));
$('art-upload').onclick=()=>$('art-file').click();
$('art-file').onchange=async()=>{const f=$('art-file').files[0];$('art-file').value='';if(!f)return;const roomId=room().roomId,key=material,projectId=history.doc.id;try{if(f.type!=='image/png'||f.size>500*1024)throw Error('请选择不超过 500 KB 的 PNG');const src=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=reject;reader.readAsDataURL(f);});await preloadArt([{art:{[key]:src}}]);if(history.doc.id!==projectId||room().roomId!==roomId)throw Error('区域已切换，请重新导入');transaction(()=>{room().art??={};room().art[key]=src;});say('已替换当前区域的 '+materials[key]+' 素材，工程与离线试玩都会保留。');}catch(e){say(e.message);}};

$('clean-starts').onclick=()=>run(()=>{let count=0;transaction(()=>{count=cleanupStarts(history.doc);});say('已清理 '+count+' 个重复起点，保留管道和检查点使用的落地点，可撤销。');});

$('focus-mode').onclick=()=>{document.body.classList.toggle('focus-mode');$('focus-mode').textContent=document.body.classList.contains('focus-mode')?'显示属性':'专注编辑';render();};
$('home-view').onclick=()=>{const p=room().map.objects.find(o=>o.kind==='spawn');camera={x:Math.max(0,(p?.x||0)-32),y:0};render();};

$('skin-upload').onclick=()=>$('skin-file').click();
$('reward-content').onchange=()=>run(()=>transaction(()=>{const q=room().map.geometry.find(g=>selected.has(g.id));if(q)setBlockContent(room(),q.id,$('reward-content').value);}));
$('skin-reset').onclick=()=>run(()=>transaction(()=>{delete room().playerSkin;}));
$('skin-file').onchange=async()=>{const f=$('skin-file').files[0];$('skin-file').value='';if(!f)return;const original=room(),project=history.doc.id;try{if(f.type!=='image/png'||f.size>50000)throw Error('请选择 16×16 PNG，50 KB 内');const data=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(f);});const im=new Image();im.src=data;await im.decode();if(im.width!==16||im.height!==16)throw Error('人物外观需为 16×16 像素，不会拉伸图片');await preloadArt([{playerSkin:data}]);if(history.doc.id!==project||room()!==original)throw Error('区域已切换，请重试');transaction(()=>{room().playerSkin=data;});say('已替换人物外观，操作能力保持马里奥基础试玩。');}catch(e){say(e.message);}};

document.querySelectorAll('.project-menu button').forEach(b=>b.addEventListener('click',()=>b.closest('details').removeAttribute('open')));
$('mobile-palette').onclick=()=>{document.body.classList.toggle('palette-open');$('mobile-palette').textContent=document.body.classList.contains('palette-open')?'收起素材与工具 ▴':'素材与工具 ▾';render();};

async function restoreAppearance(){/* Authoring data carries its own appearance; this tools package never fetches stock course templates. */}
await restoreAppearance();
for(const r of history.doc.rooms)promoteEnemies(r);render();

$('pan-left').onclick=()=>{camera.x=Math.max(0,camera.x-vp.clientWidth/z()*.7);render();};
$('pan-right').onclick=()=>{camera.x=Math.max(0,Math.min(room().map.width-vp.clientWidth/z(),camera.x+vp.clientWidth/z()*.7));render();};

$('campaign-download').onclick=async()=>{const panel=document.querySelector('.collection-authoring');if(panel){panel.open=true;panel.scrollIntoView({behavior:'smooth',block:'start'});}say('右侧自制合集面板：添加当前工程、导入 qcollection、设定顺序并导出离线合集。');};

// Character behavior is stored with the project rooms and travels with offline exports.
const heroSelect=$('play-hero');
heroSelect.onchange=async()=>{await preloadArt([{playHero:heroSelect.value}]);run(()=>transaction(()=>{selectHero(history.doc,heroSelect.value);}));};

heroSelect.value=heroFor(history.doc);

async function exportCustomCollection(doc){const res=await fetch('./runtime/character.json');if(!res.ok)throw Error('角色配置无法读取');const collection=buildCollection(doc,await res.json()),first=collection.levels[0],allRooms=collection.levels.flatMap(l=>l.rooms);const html=await offlineFile(first.pack,allRooms,undefined,undefined,(n,total)=>say('正在打包自制合集… '+Math.round(n/total*100)+'%'),{collection});const url=URL.createObjectURL(new Blob([html],{type:'text/html;charset=utf-8'})),a=document.createElement('a');a.href=url;a.download=doc.id+'-collection.html';a.click();setTimeout(()=>URL.revokeObjectURL(url),30000);say('自制合集已导出，只含已认可版本；顺序、选关和可迁移进度随文件保存。');}
