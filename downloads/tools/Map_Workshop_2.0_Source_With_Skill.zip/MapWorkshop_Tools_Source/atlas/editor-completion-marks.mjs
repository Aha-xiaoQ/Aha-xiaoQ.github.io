/** Optional display-only bindings. The native Stage owns Pink collection and
 * its lifetime; this module never creates or persists completion progress. */
export const COMPLETION_MARK_FIELDS=Object.freeze(['id','portalId','rewardRoomId','coinId']);
export const COMPLETION_MARK_LIMIT=32;
export const COMPLETION_MARK_SIZE=12,COMPLETION_MARK_GAP=6;
export const COMPLETION_MARK_ART_PROVENANCE=Object.freeze({kind:'original-display-only',calibratedNintendoMechanic:false,description:'Original hollow badge / green white-check indicator; no source-game pixels or collision body'});
const plain=q=>q&&typeof q==='object'&&!Array.isArray(q)&&[Object.prototype,null].includes(Object.getPrototypeOf(q));
const safeId=q=>typeof q==='string'&&q.length<=100&&/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(q)&&!['constructor','prototype'].includes(q);
const roomId=q=>typeof q==='string'&&q.length>0&&q.length<=100&&!/[\r\n]/.test(q)&&!['__proto__','constructor','prototype'].includes(q);
const fail=q=>{throw new TypeError(q);};
const finite=(q,a,b)=>Number.isFinite(q)&&q>=a&&q<=b;
const own=(q,keys)=>plain(q)&&Reflect.ownKeys(q).length===keys.length&&Reflect.ownKeys(q).every(k=>typeof k==='string'&&keys.includes(k))&&keys.every(k=>Object.hasOwn(q,k));
const token=q=>q.rewardRoomId+'\n'+q.coinId;
const actualPink=(room,id)=>room?.map?.objects?.some(q=>q.id===id&&q.kind==='coin')===true&&room?.smm2Mechanics?.pinkCoins?.some(q=>q.id===id)===true;
const actualPortal=(room,id)=>room?.map?.objects?.find(q=>q.id===id&&q.kind==='portal');

export function completionMarkBounds(portal){
 return {x:Math.round(portal.x+portal.w/2-COMPLETION_MARK_SIZE/2),y:Math.round(portal.y-COMPLETION_MARK_SIZE-COMPLETION_MARK_GAP),w:COMPLETION_MARK_SIZE,h:COMPLETION_MARK_SIZE};
}

/** Shared shape validation also prevents authoring helpers from dropping an
 * unknown / Symbol field while cloning a proposed edit. */
export function validateCompletionMarkEntries(marks){
 if(!Array.isArray(marks)||marks.length>COMPLETION_MARK_LIMIT||Reflect.ownKeys(marks).some(k=>typeof k!=='string'||k!=='length'&&!/^(?:0|[1-9][0-9]*)$/.test(k)))fail('Invalid completion marks list');
 const ids=new Set(),portals=new Set(),rewards=new Set();
 for(const q of marks){
  if(!own(q,COMPLETION_MARK_FIELDS)||!safeId(q.id)||!safeId(q.portalId)||!roomId(q.rewardRoomId)||!safeId(q.coinId))fail('Completion mark needs exactly id, portalId, rewardRoomId and coinId');
  if(ids.has(q.id)||portals.has(q.portalId)||rewards.has(token(q)))fail('Duplicate completion mark, portal or Pink identity');
  ids.add(q.id);portals.add(q.portalId);rewards.add(token(q));
 }
 return marks;
}

/** With no complete room context only local references can be checked.
 * Real document import / History / compile must supply its complete rooms.
 * allowMissingRewardRooms is reserved for explicitly partial author helpers. */
export function validateCompletionMarksRoom(room,rooms,{allowMissingRewardRooms=false}={}){
 const marks=room?.smm2Mechanics?.completionMarks;if(marks===undefined)return;
 if(room.smm2Mechanics.version!==1||!roomId(room.roomId))fail('Completion marks need a version 1 room identity');
 validateCompletionMarkEntries(marks);
 if(rooms!==undefined&&!Array.isArray(rooms))fail('Completion mark room context must be a room list');
 for(const q of marks){
  const portal=actualPortal(room,q.portalId);
  if(!portal||!['x','y','w','h'].every(k=>Number.isFinite(portal[k]))||portal.w<=0||portal.h<=0)fail('Completion mark must reference an actual local portal');
  const b=completionMarkBounds(portal);
  if(!finite(b.x,0,room.map.width-b.w)||!finite(b.y,0,room.map.height-b.h)||b.y+b.h>portal.y)fail('Completion mark must fit above its actual portal');
  const target=q.rewardRoomId===room.roomId?room:rooms?.find(r=>r.roomId===q.rewardRoomId);
  if(!target){if(rooms!==undefined&&!allowMissingRewardRooms)fail('Completion mark reward room is missing');continue;}
  if(!actualPink(target,q.coinId))fail('Completion mark must reference an actual typed Pink coin');
 }
 return marks;
}

export function validateCompletionMarksRooms(rooms,options){
 if(!Array.isArray(rooms))fail('Completion mark validation needs the complete room list');
 const ids=new Set();for(const r of rooms){if(ids.has(r.roomId))fail('Completion mark room identity is ambiguous');ids.add(r.roomId);}
 for(const r of rooms)validateCompletionMarksRoom(r,rooms,options);
}

/** No controller, cached booleans, saved completion leaf or visited-room rule.
 * Use the current native Set on every projection, including after a clear or
 * full restart. Intrinsic Set.has rejects duck-typed / fabricated progress. */
export function completionMarksView(room,pinkTaken,rooms){
 const marks=validateCompletionMarksRoom(room,rooms);if(marks===undefined)return;
 try{Set.prototype.has.call(pinkTaken,'');}catch{fail('Completion marks require the actual native Pink Set');}
 return marks.map(q=>({...q,...completionMarkBounds(actualPortal(room,q.portalId)),completed:Set.prototype.has.call(pinkTaken,token(q))}));
}

/** World-layer drawing shared by editor / play / recording. Static author
 * previews are always incomplete. HUD remains in the host's later HUD pass. */
export function drawCompletionMarks(c,room={}){
 if(room.smm2Mechanics?.completionMarks===undefined)return false;
 const marks=room.completionMarksView??completionMarksView(room,new Set());
 if(!Array.isArray(marks))fail('Invalid completion mark render projection');
 let drawn=false;c.save();c.imageSmoothingEnabled=false;
 for(const q of marks){
  const b=completionMarkBounds(actualPortal(room,q.portalId)||fail('Completion mark portal missing during drawing')),v=room.renderBounds;
  if(v&&(b.x+b.w<=v.x||b.x>=v.x+v.w||b.y+b.h<=v.y||b.y>=v.y+v.h))continue;
  const rect=(color,x,y,w,h)=>{c.fillStyle=color;c.fillRect(b.x+x,b.y+y,w,h);};
  // A small rounded badge, deliberately unlike any terrain tile.
  rect('#152638',3,0,6,12);rect('#152638',1,1,10,10);rect('#152638',0,3,12,6);
  const rim='#dbeaf4';rect(rim,3,1,6,1);rect(rim,3,10,6,1);rect(rim,1,3,1,6);rect(rim,10,3,1,6);
  for(const [x,y]of [[2,2],[9,2],[2,9],[9,9]])rect(rim,x,y,1,1);
  if(q.completed===true){
   rect('#167a43',3,2,6,8);rect('#167a43',2,3,8,6);
   for(const [x,y]of [[3,5],[4,6],[5,7],[6,6],[7,5],[8,4]])rect('#ffffff',x,y,2,2);
  }
  drawn=true;
 }
 c.restore();return drawn;
}

/** Internal reference predicates are exported for the deletion helpers;
 * checking them never grants a reward or alters a native object. */
export function completionMarkReferencesExist(room,mark,rooms){
 return !!actualPortal(room,mark.portalId)&&actualPink(mark.rewardRoomId===room.roomId?room:rooms?.find(q=>q.roomId===mark.rewardRoomId),mark.coinId);
}
