import {sourceKey,sourcePixels} from './source-art.mjs';

/** Authored background components. Native pixels are reused at 1:1 scale. */
export const nativeSceneryTypes=Object.freeze({PlantSmall:'小树',PlantLarge:'大树',Fence:'围栏',Cloud1:'一朵云',Cloud2:'两朵云',Cloud3:'三朵云',HillLarge:'大山丘',HillSmall:'小山丘',Bush1:'小灌木',Bush2:'中灌木',Bush3:'大灌木',BushEdge:'地面边缘灌木'});
export const nativeSceneryPalettes=Object.freeze({native:'原生房间配色',snow:'雪白树木'});
const sprites=new Map();
export const isNativeScenery=q=>!!q?.nativeScenery;
export function nativeSceneryKey(q,room={}){
 const {type,palette}=q.nativeScenery;
 // The upstream plants have an explicit Alt snow sprite. Do not apply Alt2 to
 // clouds: that unrelated filter changes their blue shading to red.
 const setting=palette==='snow'?(/^Plant/.test(type)?'Alt':''):room.setting||'';
 return sourceKey('Scenery',type==='BushEdge'?'Bush1':type,setting);
}
export function nativeSceneryDimensions({type,repeat=1}){
 if(!Object.hasOwn(nativeSceneryTypes,type))throw Error('未知原生背景组件');
 if(!Number.isInteger(repeat)||repeat<1||repeat>2048||(type!=='Fence'&&repeat!==1))throw Error('只有围栏可以重复，数量须为 1–2048 的整数');
 if(type==='BushEdge')return {w:16,h:8};
 const p=sourcePixels(sourceKey('Scenery',type));return {w:p.w*repeat,h:p.h};
}
export function makeNativeScenery({id,x,y,type='PlantSmall',palette='native',repeat=1,hidden=false}){
 if(!Object.hasOwn(nativeSceneryPalettes,palette))throw Error('未知原生背景配色');
 const nativeScenery={version:1,type,palette,repeat},size=nativeSceneryDimensions(nativeScenery);
 return {id,x,y,...size,material:'decoration',nativeScenery,...(hidden?{hidden:true}:{})};
}
export function validateNativeSceneryRoom(room){
 if(room.nativeSceneryMode!==undefined&&!['auto','authored'].includes(room.nativeSceneryMode))throw Error('原生背景模式须为 auto 或 authored');
 const ids=new Set([...(room.map?.geometry||[]),...(room.map?.objects||[])].map(q=>q.id));
 for(const q of room.decorations||[]){
  if(!isNativeScenery(q)){ids.add(q.id);continue;}
  const s=q.nativeScenery;
  if(!s||typeof s!=='object'||Array.isArray(s)||s.version!==1||Object.keys(s).some(k=>!['version','type','palette','repeat'].includes(k)))throw Error('原生背景组件版本或字段无效');
  if(typeof q.id!=='string'||!q.id||q.id.length>100||ids.has(q.id))throw Error('原生背景组件标识重复或缺失');ids.add(q.id);
  if(!Object.hasOwn(nativeSceneryPalettes,s.palette))throw Error('未知原生背景配色');
  const {w,h}=nativeSceneryDimensions(s);
  if(q.w!==w||q.h!==h||q.material!=='decoration'||q.collision!==undefined||q.motion!==undefined||q.studyArt!==undefined)throw Error('原生背景须使用完整原生尺寸且不带碰撞或运动');
  if(!Number.isInteger(q.x)||!Number.isInteger(q.y)||q.x<0||q.y<0||q.x+w>room.map.width||q.y+h>room.map.height)throw Error('原生背景组件超出房间');
  if(q.hidden!==undefined&&typeof q.hidden!=='boolean')throw Error('背景显示状态无效');
 }
}
export function drawNativeScenery(c,q,room={}){
 if(!isNativeScenery(q)||q.hidden)return false;
 const v=room.renderBounds;if(v&&(q.x+q.w<=v.x||q.x>=v.x+v.w||q.y+q.h<=(v.y??0)||q.y>=(v.y??0)+(v.h??room.map?.height??4096)))return true;
 const key=nativeSceneryKey(q,room);let sprite=sprites.get(key);
 if(!sprite){const p=sourcePixels(key);sprite=document.createElement('canvas');sprite.width=p.w;sprite.height=p.h;const ctx=sprite.getContext('2d'),data=ctx.createImageData(p.w,p.h);for(let n=0;n<p.pixels.length;n++)data.data.set(p.pixels[n],n*4);ctx.putImageData(data,0,0);sprites.set(key,sprite);}
 c.save();c.imageSmoothingEnabled=false;c.beginPath();c.rect(q.x,q.y,q.w,q.h);c.clip();
 for(let x=q.x;x<q.x+q.w;x+=sprite.width)c.drawImage(sprite,x,q.y);
 c.restore();return true;
}
