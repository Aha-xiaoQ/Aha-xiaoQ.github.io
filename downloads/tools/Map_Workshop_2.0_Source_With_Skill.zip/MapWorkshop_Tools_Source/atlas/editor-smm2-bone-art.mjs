import {drawSmm2SourcePixels,SMM2_SOURCE_PIXELS} from './editor-smm2-source-assets.mjs';
import {castleFirebarNodes} from './editor-castle.mjs';
/** Original source pixels and tagged scenery for the private Bone Shell study.
 * Only poses and actual controller rectangles are read. Public catalogue assets
 * are separately credited; no walkthrough cuts, collision resizing or state writes.
 */
export const SMM2_BONE_ART_PALETTE=Object.freeze({
 bone:'#ffffff',shade:'#4c4c4c',seam:'#4c4c4c',dark:'#000000',eye:'#29ceff'
});
const P=SMM2_BONE_ART_PALETTE;
const valid=q=>q&&['x','y','w','h'].every(k=>Number.isFinite(q[k]))&&q.w>0&&q.h>0;
const visible=q=>q&&!q.hidden&&q.visible!==false&&!q.dead&&!q.removed;
function pixels(c,q,width,height,draw,{mirror=false}={}){
 if(!valid(q))return false;
 const w=Math.max(1,Math.round(q.w)),h=Math.max(1,Math.round(q.h));
 c.save();c.imageSmoothingEnabled=false;c.translate(Math.round(q.x)+(mirror?w:0),Math.round(q.y));if(mirror)c.scale(-1,1);
 const p=(color,x,y,pw=1,ph=1)=>{
  const left=Math.round(x*w/width),top=Math.round(y*h/height),right=Math.round((x+pw)*w/width),bottom=Math.round((y+ph)*h/height);
  if(right<=left||bottom<=top)return;c.fillStyle=color;c.fillRect(left,top,right-left,bottom-top);
 };
 draw(p);c.restore();return true;
}
function mask(p,rows,x,y,color){for(let y0=0;y0<rows.length;y0++)for(let x0=0;x0<rows[y0].length;x0++)if(rows[y0][x0]==='1')p(color,x+x0,y+y0);}

export function smm2BoneShellPlayingDead(actor){
 const s=actor?.smm2Shoe??actor;
 return s?.kind==='bone-shell'&&(s.playingDead===true||['collapsed','playing-dead','recovering'].includes(s.phase));
}

/** Empty and mounted shells share their real foot body. Mario is separate. */
export function drawSmm2BoneShell(c,actor,{tick=0,rider=false}={}){
 const s=actor?.smm2Shoe??actor;
 if(!visible(actor)||!valid(actor)||s?.kind!=='bone-shell'||['removed','carried'].includes(s.occupancy))return false;
 if(smm2BoneShellPlayingDead(actor))return pixels(c,{...actor,y:actor.y+actor.h-8*actor.w/16,h:8*actor.w/16},16,8,p=>{
  // A low bone mound keeps the actual foot anchor; no hidden rider pixels.
  mask(p,['0000111100000000','0001111110000000','0011111111000000','0011000011000000','0001111110011100','0110111101111110','1111111111111111','0111111111111110'],0,0,P.shade);
  p(P.bone,5,0,3);p(P.bone,4,1,5,2);p(P.bone,3,3,2,2);p(P.bone,7,3,2,2);
  p(P.dark,5,3,2,2);p(P.bone,5,5,3);p(P.seam,5,6,3);
  p(P.bone,10,4,3);p(P.bone,9,5,5);p(P.seam,11,5,1,2);
  p(P.bone,1,6,3);p(P.bone,3,7,4);p(P.bone,9,7,5);p(P.bone,14,6,2);
 });
 // Original artwork is 16×15. Mounted occupancy never stretches the shell.
 const visual=smm2BoneShellVisualRect(actor);
 return drawSmm2SourcePixels(c,'boneShell',{x:visual.x,y:visual.y,scale:visual.scale});
}

/** Visual sprite boxes are independent of the physical foot/body colliders. */
export function smm2BoneShellVisualRect(actor){
 const scale=actor.w/16;return {x:actor.x,y:actor.y+actor.h-15*scale,w:actor.w,h:15*scale,scale};
}

/** Four authored limb poses derived from the sourced SMB1 standing family.
 * These are independently adapted gait pixels, not a Nintendo animation rip.
 * The face/eye and shell use the existing palette and silhouette. Passing
 * poses nod only the head by one source pixel; planted soles never bob.
 * Keeping the rows in this shared module also preserves the offline closure. */
const dryBonesSource=SMM2_SOURCE_PIXELS.dryBonesStanding;
function gaitRows(legs,nod=false){
 const rows=dryBonesSource.rows.map(row=>row.split(''));
 if(nod){
  for(let y=0;y<10;y++)for(let x=0;x<7;x++)rows[y][x]='0';
  for(let y=0;y<9;y++)for(let x=0;x<7;x++)rows[y+1][x]=dryBonesSource.rows[y][x];
 }
 for(let i=0;i<legs.length;i++)rows[20+i]=legs[i].split('');
 return Object.freeze(rows.map(row=>row.join('')));
}
export const SMM2_DRY_BONES_GAIT_ROWS=Object.freeze([
 Object.freeze([...dryBonesSource.rows]),
 gaitRows(['0000121102211100','0001111101122210','0000000000001111'],true),
 gaitRows(['0012111222111100','0111122111112200','1111000001111100']),
 gaitRows(['0001211122012100','0011122110111110','0111110000000000'],true)
]);
const dryBonesAirRows=gaitRows(['0000121122212100','0000011110121110','0000000000000000']);

/** Pure pose selection reads native movement; it never creates another clock.
 * A quarter-step spans two source pixels, so speed and Big scale naturally
 * control cadence. Real x drives progress: repeated draws, pause, and platform
 * idle transport do not fabricate walking. Explicit airborne bodies tuck feet. */
export function smm2DryBonesVisualPose(actor){
 const s=actor?.smm2DryBones??{};
 if(['collapsed','recovering'].includes(s.phase))return {kind:s.phase,frame:0};
 if(s.phase==='walking'&&actor.grounded===false)return {kind:'airborne',frame:0};
 if(s.phase!=='walking'||actor.grounded!==true||!Number.isFinite(actor.vx)||Math.abs(actor.vx)<.0001)return {kind:'standing',frame:0};
 const quarterStep=2*actor.w/16,step=Math.floor(actor.x/quarterStep+1e-7);
 return {kind:'walking',frame:((step%4)+4)%4};
}
function drawDryBonesRows(c,rows,{x,y,scale,mirror}){
 c.save();c.imageSmoothingEnabled=false;c.translate(Math.round(x)+(mirror?16*scale:0),Math.round(y));if(mirror)c.scale(-1,1);
 for(let iy=0;iy<rows.length;iy++)for(let ix=0;ix<16;){
  const index=Number(rows[iy][ix]);let end=ix+1;while(end<16&&rows[iy][end]===rows[iy][ix])end++;
  if(index){c.fillStyle=dryBonesSource.palette[index];c.fillRect(ix*scale,iy*scale,(end-ix)*scale,scale);}ix=end;
 }
 c.restore();return true;
}

/** Original standing/pile pixels and a movement-driven authored walk cycle.
 * Big is nearest 2×, every live pose shares its body and bottom anchor, and
 * recovery remains a separately credited whole-pile warning shake. */
export function drawSmm2DryBones(c,actor,{tick=0}={}){
 if(!visible(actor)||!valid(actor)||actor.type!=='dry-bones')return false;
 const s=actor.smm2DryBones??{},pose=smm2DryBonesVisualPose(actor),pile=['collapsed','recovering'].includes(pose.kind),mirror=(actor.facing??(actor.vx>0?1:-1))>0;
 const scale=actor.w/16,w=(pile?21:16)*scale,h=(pile?8:23)*scale;
 const shake=s.phase==='recovering'&&Number.isFinite(tick)?[0,1,0,-1][((Math.floor(tick/4)%4)+4)%4]*scale:0;
 const placement={x:actor.x+(actor.w-w)/2+shake,y:actor.y+actor.h-h,scale,mirror};
 if(pose.kind==='walking')return drawDryBonesRows(c,SMM2_DRY_BONES_GAIT_ROWS[pose.frame],placement);
 if(pose.kind==='airborne')return drawDryBonesRows(c,dryBonesAirRows,placement);
 return drawSmm2SourcePixels(c,pile?'dryBonesPile':'dryBonesStanding',placement);
}

/** The explicitly tagged castle variant has three decorative hanging bones.
 * It adds no cap, solidity or inferred collision below the real semisolid.
 */
export function drawSmm2BoneCastlePosts(c,q){
 if(!visible(q)||!valid(q))return false;
 if(q.w===64&&q.h===64)return drawSmm2SourcePixels(c,'boneSemisolid',{x:q.x,y:q.y});
 c.save();c.beginPath();c.rect(q.x,q.y,q.w,q.h);c.clip();
 for(let offset=0;offset<q.w;offset+=16){
  const x=q.x+offset,sx=offset%64;
  drawSmm2SourcePixels(c,'boneSemisolid',{x,y:q.y,sourceX:sx,sourceWidth:16,sourceHeight:16});
  const middle=Math.max(0,q.h-23);
  for(let y=0;y<middle;y++)drawSmm2SourcePixels(c,'boneSemisolid',{x,y:q.y+16+y,sourceX:sx,sourceWidth:16,sourceY:16+(y%32),sourceHeight:1});
  drawSmm2SourcePixels(c,'boneSemisolid',{x,y:q.y+q.h-7,sourceX:sx,sourceWidth:16,sourceY:57,sourceHeight:7});
 }
 c.restore();return true;

}

/** Original approximate scenery, authored from the observed silhouette only.
 * Measured examples are 16px wide and 32/48px tall. The carved figure keeps
 * its small head/body while the fluted pedestal takes the remaining height.
 * These background pixels neither create nor modify a collider or actor.
 */
export function drawSmm2BoneCastleStatue(c,q){
 if(!visible(q)||!valid(q))return false;
 if(q.w===16&&q.h===48)return drawSmm2SourcePixels(c,'bowserStatue',{x:q.x,y:q.y});
 const scale=q.w/16,height=q.h/scale;
 drawSmm2SourcePixels(c,'bowserStatue',{x:q.x,y:q.y,scale,sourceHeight:29});
 for(let y=29;y<height-3;y++)drawSmm2SourcePixels(c,'bowserStatue',{x:q.x,y:q.y+y*scale,scale,sourceY:32+(y-29)%12,sourceHeight:1});
 drawSmm2SourcePixels(c,'bowserStatue',{x:q.x,y:q.y+q.h-3*scale,scale,sourceY:45,sourceHeight:3});return true;

}

/** Approximate dark end-castle backdrop, with a separate native door in front.
 * Its 78×80 reference rectangle is scenery only. No reference-image pixels,
 * new doorway, collision edge, or unseen extension is supplied by this art.
 */
export function drawSmm2BoneCastleFacade(c,q){
 if(!visible(q)||!valid(q))return false;
 const stone='#414141',shade='#292929',mortar='#171717',edge='#565656';
 return pixels(c,q,78,80,p=>{
  // The crenellated upper edge has transparent gaps against the black room.
  for(let x=2;x<78;x+=8){const width=Math.min(6,78-x);p(shade,x,0,width,6);p(edge,x,0,width,1);p(stone,x,1,Math.min(5,width),4);}
  p(shade,6,10,72,6);p(stone,7,10,71,5);
  for(let x=12;x<78;x+=12)p(mortar,x,10,1,6);
  p(mortar,0,16,78,64);
  for(let y=16;y<80;y+=8){
   const offset=((y-16)/8)%2?6:0;
   for(let x=-offset;x<78;x+=12){
    const left=Math.max(0,x),right=Math.min(78,x+11);
    if(right<=left)continue;
    p(stone,left,y+1,right-left,6);p(edge,left,y+1,right-left,1);p(shade,left,y+6,right-left,1);
   }
  }
  // The measured terminal door owns its own red/white artwork above this.
  p('#101010',25,39,24,41);
 });
}

/** Existing collision nodes own the firebar pose. Only their image changes. */
export function drawSmm2SourceFirebar(c,marker,room){
 if(room?.smm2Mechanics?.art?.palette!=='smb1-castle-stone'||marker?.kind!=='rotating-firebar'||!room.castle?.firebars?.[marker.id])return false;
 // The catalogue composite obscures part of its fixed mount with balls. This
 // independently restored symmetric inset uses its visible gray/white frame,
 // rather than rotating an entire screenshot/composite or adding a collider.
 pixels(c,{x:marker.x,y:marker.y,w:16,h:16},16,16,p=>{
  p('#ffffff',1,0,14,16);p('#ffffff',0,1,16,14);
  p('#bdbdbd',1,1,14,14);p('#ffffff',3,3,10,10);
  for(const [x,y]of [[2,2],[12,2],[2,12],[12,12]])p('#4c4c4c',x,y,2,2);
 });
 const nodes=room.castleView?.firebars?.find(q=>q.id===marker.id)?.nodes||castleFirebarNodes(marker,room.castle.firebars[marker.id],0);
 for(const node of nodes)drawSmm2SourcePixels(c,'firebarOrb',{x:node.x,y:node.y,scale:node.w/8,rotateQuarterTurns:Math.floor((room.tick||0)/3)%4});return true;
}
