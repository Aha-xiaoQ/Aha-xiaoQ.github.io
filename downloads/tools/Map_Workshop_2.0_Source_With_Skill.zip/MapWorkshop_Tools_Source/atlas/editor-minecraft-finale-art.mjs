import {paintMinecraftEnchantmentGlint} from './editor-minecraft-enchantment-art.mjs';
/** R5 original pixel artwork. Every block, creature and effect is painted here;
 * no sampled Minecraft assets. Geometry remains entirely owned by the runtime.
 * Public painters are deterministic and restore their caller's Canvas state.
 * Scenery anchors use world pixels and y at the floor (torches: flame y).
 */
const rr=(c,color,x,y,w,h)=>{if(w>0&&h>0){c.fillStyle=color;c.fillRect(Math.round(x),Math.round(y),Math.ceil(w),Math.ceil(h));}};
const hash=(x,y,s=0)=>{let n=Math.imul(x|0,374761393)^Math.imul(y|0,668265263)^Math.imul(s|0,982451653);n=Math.imul(n^(n>>>13),1274126177);return(n^(n>>>16))>>>0;};
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
const isFinale=room=>room?.minecraft?.version===1&&['nether','stronghold','end'].includes(room.minecraft.biome);
const geometry=room=>room.map?.geometry||[];
const stateOf=(room,view)=>{const v=view??room.minecraftView??{};return v.minecraft||v;};
const tickOf=room=>Number.isFinite(room.tick)?room.tick:0;
const bounds=room=>room.renderBounds||{x:0,y:0,w:room.map?.width||512,h:room.map?.height||320};
const floorOf=room=>room.minecraft?.groundY??room.minecraft?.dragon?.groundY??Math.max(0,...geometry(room).filter(g=>g.h>=24&&!/roof|ceiling/.test(g.id||'')).map(g=>g.y))??320;
const visible=g=>!g.hidden&&!g.removed&&g.visible!==false;
function groundAt(room,x,y=0){const gs=geometry(room).filter(g=>visible(g)&&g.x<=x&&g.x+g.w>x&&g.y>=y&&g.h>=8&&!/roof|ceiling|crystal|seal/.test(g.id||''));return gs.length?Math.min(...gs.map(g=>g.y)):null;}
function pixelLine(c,x1,y1,x2,y2,color,width=1){const steps=Math.max(1,Math.ceil(Math.max(Math.abs(x2-x1),Math.abs(y2-y1))));for(let i=0;i<=steps;i++){const t=i/steps;rr(c,color,x1+(x2-x1)*t-width/2,y1+(y2-y1)*t-width/2,width,width);}}
// Integer scanlines prevent Canvas antialiasing on membrane and crystal edges.
function poly(c,points,color){let min=Math.floor(Math.min(...points.map(p=>p[1]))),max=Math.ceil(Math.max(...points.map(p=>p[1])));for(let y=min;y<max;y++){const xs=[];for(let i=0;i<points.length;i++){const [ax,ay]=points[i],[bx,by]=points[(i+1)%points.length];if((ay<=y+.5&&by>y+.5)||(by<=y+.5&&ay>y+.5))xs.push(ax+(y+.5-ay)*(bx-ax)/(by-ay));}xs.sort((a,b)=>a-b);for(let i=0;i+1<xs.length;i+=2){const l=Math.ceil(xs[i]-.5),r=Math.ceil(xs[i+1]-.5);rr(c,color,l,y,r-l,1);}}}
/** R8 faces stay inside the real solid. Adjoining solids suppress exposed rims.
 * Top is brightest, front mid-tone and the right side darkest in every biome. */
export function minecraftVoxelFacePlan(q={},room={}){
 const solids=(room.playGeometry||room.geometry||geometry(room)).filter(g=>visible(g)&&(g.sourceId||g.id)!==(q.sourceId||q.id));
 const split=(start,end,covers)=>{let spans=[[start,end]];for(const [a,b] of covers){spans=spans.flatMap(([l,r])=>b<=l||a>=r?[[l,r]]:[[l,Math.max(l,a)],[Math.min(r,b),r]].filter(([x,z])=>z>x));}return spans;};
 const x=q.x||0,y=q.y||0,w=Math.max(0,q.w||0),h=Math.max(0,q.h||0),d=Math.min(5,Math.max(2,Math.floor(Math.min(w,h)/4)));
 return {x,y,w,h,depth:d,top:split(x,x+w,solids.filter(g=>Math.abs(g.y+g.h-y)<.01).map(g=>[g.x,g.x+g.w])),right:split(y,y+h,solids.filter(g=>Math.abs(g.x-x-w)<.01).map(g=>[g.y,g.y+g.h])),bottom:split(x,x+w,solids.filter(g=>Math.abs(g.y-y-h)<.01).map(g=>[g.x,g.x+g.w]))};
}
export function paintMinecraftVoxelRelief(c,q,room,palette){
 if(!visible(q))return;const p=minecraftVoxelFacePlan(q,room),d=p.depth;
 c.save();c.beginPath();c.rect(p.x,p.y,p.w,p.h);c.clip();
 for(const [a,b] of p.top){rr(c,palette[2],a,p.y,b-a,d);rr(c,palette[4]||palette[2],a,p.y,b-a,1);rr(c,palette[0],a,p.y+d-1,b-a,1);
  for(let x=p.x;x<p.x+p.w;x+=16){const from=Math.max(a,x),to=Math.min(b,x+16);if(to>from){rr(c,palette[0],Math.max(from,x+14),p.y+1,Math.max(0,to-Math.max(from,x+14)),d-1);if(to-from>7)rr(c,palette[4]||palette[2],from+3,p.y+2,Math.min(5,to-from-4),1);}}
 }
 for(const [a,b] of p.right){poly(c,[[p.x+p.w-d,a+d],[p.x+p.w,a],[p.x+p.w,b],[p.x+p.w-d,b]],palette[1]);rr(c,palette[3]||palette[0],p.x+p.w-d,a+d,1,Math.max(0,b-a-d));for(let y=Math.ceil(a/16)*16;y<b;y+=16)rr(c,palette[3]||palette[0],p.x+p.w-d,y,d,1);}
 for(const [a,b] of p.bottom){rr(c,palette[1],a,p.y+p.h-2,b-a,2);rr(c,palette[3]||palette[0],a,p.y+p.h-3,b-a,1);}
 c.restore();
}
function block(c,x,y,w,h,palette,seed=0,brick=false){rr(c,palette[0],x,y,w,h);for(let py=0;py<h;py+=2)for(let px=0;px<w;px+=2){const n=hash(px,py,seed);if(n%7)rr(c,palette[n%palette.length],x+px,y+py,Math.min(2+(n>>>5)%3,w-px),Math.min(2+(n>>>8)%2,h-py));}rr(c,palette[2],x,y,w,1);rr(c,palette[1],x+w-1,y,1,h);if(brick)for(let py=7;py<h;py+=8){rr(c,palette[1],x,y+py,w,1);rr(c,palette[1],x+(Math.floor(py/8)%2?8:0),y+py-6,1,6);}}
const OBS=['#211b30','#100f1d','#493358','#31253e','#5a3f68'];
const BLACKSTONE=['#36313b','#1d202b','#59505b','#443b46','#6a5152'];
const ENDSTONE=['#c8c491','#a6a675','#e3dfa8','#b7b783','#eee9b6'];
const STRONGHOLD=['#59645c','#34423f','#74816c','#48594d','#89927b'];
function tiled(c,q,palette,seed=0,brick=false){c.save();c.beginPath();c.rect(q.x,q.y,q.w,q.h);c.clip();for(let y=q.y;y<q.y+q.h;y+=16)for(let x=q.x;x<q.x+q.w;x+=16)block(c,x,y,16,16,palette,hash(x,y,seed),brick);c.restore();}
function glow(c,x,y,r,color,strength=.15){const alpha=c.globalAlpha;for(let py=-r;py<=r;py+=4)for(let px=-r;px<=r;px+=4){const d=Math.hypot(px,py);if(d<r){c.globalAlpha=alpha*strength*(1-d/r)**2;rr(c,color,x+px,y+py,4,4);}}c.globalAlpha=alpha;}
function sparks(c,x,y,tick,color='#eeb855',count=6,spread=20){for(let i=0;i<count;i++){const t=(tick+i*17)%80,dx=(hash(i,17)%spread-spread/2),dy=t*.5;rr(c,i%3?color:'#fff2b0',x+dx+Math.sin(i+t*.05)*3,y-dy,1+i%2,1+i%2);}}
function obsidianPortal(c,room,q,tick){const w=q.w||48,h=q.h||80,base=groundAt(room,q.x+w/2,q.y-2)??q.y,x=q.x,y=base-h;glow(c,x+w/2,y+h/2,70,'#c178f6',.2);rr(c,'#29143e',x+8,y+8,w-16,h-16);for(let py=8;py<h-8;py+=4)for(let px=8;px<w-8;px+=4){const n=hash(Math.floor((px+tick*.3)/4),Math.floor((py-tick*.2)/4),8);rr(c,['#6b3e99','#8a4abd','#a75bc7','#4a286c','#bc75db'][n%5],x+px,y+py,4,4);if(n%7===0)rr(c,'#e5b2ed',x+px,y+py,2,1);}for(let py=0;py<h;py+=8)for(let px=0;px<w;px+=8)if(px<8||px>=w-8||py<8||py>=h-8)block(c,x+px,y+py,Math.min(8,w-px),Math.min(8,h-py),OBS,px+py);rr(c,'#393443',x-4,base-3,w+8,3);rr(c,'#8b788e',x-3,base-3,w+6,1);sparks(c,x+w/2,base-7,tick,'#c280ec',8,w+12);}
function sconce(c,x,y,tick,soul=false){const hot=soul?'#6be3d2':'#ffbe60';glow(c,x,y,44,hot,.2);rr(c,'#292c30',x-4,y+7,9,17);rr(c,'#817c6b',x-3,y+8,7,15);rr(c,'#b0a185',x-2,y+9,1,11);pixelLine(c,x,y+20,x+5,y+12,'#b59b72',3);rr(c,'#553e2e',x+3,y+5,3,12);rr(c,soul?'#237d7e':'#bb4925',x+1,y,7,9);rr(c,soul?'#55cfc4':'#f28a35',x+2,y-3-Math.floor(tick/7)%3,5,10);rr(c,soul?'#cbfff0':'#fff0a4',x+3,y-1,2,6);rr(c,'#e0e6c1',x,y+10,1,1);}
function eye(c,x,y,lit=true){rr(c,'#243b34',x,y,12,7);rr(c,'#759d82',x+1,y,10,5);rr(c,lit?'#d6e69c':'#516c5b',x+2,y+1,8,4);rr(c,lit?'#2c6a57':'#30473e',x+5,y+1,3,4);rr(c,lit?'#b4f2b6':'#4e6e5e',x+5,y+1,1,1);}
function endPortal(c,room,q,tick,lit=true){const x=q.x,w=q.w||112,base=groundAt(room,x+w/2,q.y-2)??q.y,h=q.h||24;glow(c,x+w/2,base-12,80,'#66d9bc',lit?.15:.025);rr(c,'#22372f',x,base-h,w,h);rr(c,'#456657',x+2,base-h+2,w-4,h-3);rr(c,'#76927a',x+3,base-h+2,w-6,3);rr(c,'#142724',x+12,base-h+6,w-24,h-12);rr(c,lit?'#080c18':'#263932',x+14,base-h+7,w-28,h-14);if(lit)for(let i=0;i<36;i++){const px=x+15+hash(i,19)%(w-30),py=base-h+7+hash(i,20)%Math.max(1,h-14);rr(c,i%4?'#8ac9c4':'#f5f0c1',px,py,1,1);if((tick+i*9)%70<8)rr(c,'#d3eff0',px-1,py,3,1);}for(let ex=4;ex<w-10;ex+=16){eye(c,x+ex,base-h-3,lit);rr(c,'#263b33',x+ex,base-7,12,6);rr(c,'#76947a',x+ex+1,base-7,10,2);}for(const xx of [x,x+w-11]){rr(c,'#809779',xx,base-h+5,11,h-7);rr(c,'#a5b48b',xx+1,base-h+5,2,h-9);rr(c,'#263b32',xx+4,base-h+9,3,h-13);}rr(c,'#a4b48d',x,base-1,w,1);}
function bedrockExit(c,room,q,tick,lit){
 const x=q.x,w=q.w||96,base=groundAt(room,x+w/2,q.y-2)??q.y;
 tiled(c,{x,y:base-10,w,h:10},BEDROCK,23);for(const xx of [x,x+w-10])tiled(c,{x:xx,y:base-23,w:10,h:18},BEDROCK,24);
 rr(c,'#17151f',x+10,base-18,w-20,9);rr(c,'#41364b',x+10,base-18,w-20,1);rr(c,lit?'#080b19':'#24232c',x+11,base-16,w-22,7);
 if(lit){glow(c,x+w/2,base-12,44,'#bfa4d5',.12);for(let i=0;i<24;i++){const xx=x+12+hash(i,92)%(w-24),yy=base-16+hash(i,93)%7;rr(c,i%3?'#9c89bd':'#e6dcef',xx,yy,1,1);}}
 tiled(c,{x:x+w/2-6,y:base-30,w:12,h:12},BEDROCK,25);rr(c,'#a9a0ad',x+w/2-6,base-30,12,1);
}
export function minecraftBastionRewardArtPlan(reward={}){
 const opened=!!reward.opened||!!reward.taken,progress=opened?clamp((reward.openAge??18)/18,0,1):0;
 const item=reward.item&&!reward.taken&&reward.item.state!=='collected'?{...reward.item}:null;
 return {opened,progress,lidY:(reward.y||0)-progress*6,item};
}
function chest(c,q,open=false){
 const x=q.x,y=q.y,w=q.w||16,h=q.h||16,plan=minecraftBastionRewardArtPlan({...q,opened:open}),lift=plan.progress*6;
 rr(c,'#332a24',x-1,y+1,w+2,h-1);rr(c,'#9d692f',x,y+5,w,h-5);rr(c,'#c18b41',x+1,y+7,w-2,h-8);rr(c,'#5b3b27',x,y+8,w,2);
 for(const dx of [1,w-3]){rr(c,'#d9bf77',x+dx,y+5,2,h-6);rr(c,'#6a5940',x+dx,y+h-3,2,2);}rr(c,'#563c2b',x+3,y+h-2,w-6,1);
 if(open){rr(c,'#1d2026',x+2,y+2,w-4,6);rr(c,'#4b3526',x+1,y+2,w-2,1);}
 rr(c,'#3a2922',x-1,y-lift,w+2,6);rr(c,'#bd8c45',x,y+1-lift,w,4);rr(c,'#e0b76b',x+1,y+1-lift,w-2,1);rr(c,'#6c4c2c',x,y+5-lift,w,1);
 const latchY=open?y+2-lift:y+6;rr(c,'#f6dc8f',x+w/2-2,latchY,4,5);rr(c,'#796342',x+w/2-1,latchY+2,2,2);
}
function bastionTrident(c,item){
 if(!item||item.state==='collected')return;const x=item.x,y=item.y,w=item.w||18,h=item.h||8,age=item.age||0;c.save();c.translate(Math.round(x),Math.round(y));c.scale(w/18,h/8);
 // This is the controller's ejected item, not a decorative standing weapon.
 rr(c,'#17434d',5,3,13,3);rr(c,'#55b9bb',5,3,13,1);rr(c,'#2c7f89',6,4,11,1);
 rr(c,'#1a5864',5,0,3,8);rr(c,'#80ded4',5,1,2,6);for(const yy of [0,3,6]){rr(c,'#287782',0,yy,7,2);rr(c,'#a7f3df',0,yy,6,1);rr(c,'#e8ffe9',0,yy,1,1);}
 paintMinecraftEnchantmentGlint(c,[[5,3,13,3],[5,0,3,8],...[0,3,6].map(yy=>[0,yy,7,2])],age,{strength:.4});c.restore();
 // Capacity reward follows the same physical item, with no separate pickup.
 const hx=Math.round(x+w+3),hy=Math.round(y-3);for(const [dx,dy,ww,hh] of [[1,0,2,1],[5,0,2,1],[0,1,8,3],[1,4,6,1],[2,5,4,1],[3,6,2,1]])rr(c,'#e6b75f',hx+dx,hy+dy,ww,hh);for(const [dx,dy,ww,hh] of [[1,1,2,1],[5,1,2,1],[1,2,6,2],[2,4,4,1],[3,5,2,1]])rr(c,'#d84258',hx+dx,hy+dy,ww,hh);rr(c,'#ffb9a1',hx+1,hy+1,1,2);
}


/** All foundation coordinates are derived from authored collision surfaces. */
export function finaleSupportPlan(room={}){const crystals=room.minecraft?.dragon?.crystalIds||[],pedestals=[];for(const id of crystals){const q=geometry(room).find(g=>g.id===id);if(!q)continue;const ground=groundAt(room,q.x+q.w/2,q.y+q.h);if(ground!=null)pedestals.push({id,x:q.x+q.w/2,top:q.y+q.h,ground});}const portals=(room.minecraft?.scenery||[]).filter(q=>q.kind==='portal'||q.kind==='end-portal').map(q=>({x:q.x,w:q.w||(q.kind==='end-portal'?112:48),base:groundAt(room,q.x+(q.w||48)/2,q.y-2)??q.y}));return {pedestals,portals};}

const BEDROCK=['#53515a','#24242c','#8b8990','#6c6972','#b2afb0'];
function glassBlock(c,q){
 c.save();c.beginPath();c.rect(q.x,q.y,q.w,q.h);c.clip();const a=c.globalAlpha;c.globalAlpha=a*.15;rr(c,'#92c8d2',q.x,q.y,q.w,q.h);c.globalAlpha=a;
 rr(c,'#b7d8d8',q.x,q.y,q.w,1);rr(c,'#e0eded',q.x+1,q.y+1,q.w-2,1);rr(c,'#b7d8d8',q.x,q.y,1,q.h);rr(c,'#6e9ca8',q.x+q.w-1,q.y,1,q.h);rr(c,'#7ca9b4',q.x,q.y+q.h-1,q.w,1);
 for(let x=q.x;x<q.x+q.w;x+=16){rr(c,'#c5e1df',x+3,q.y+4,3,1);rr(c,'#c5e1df',x+2,q.y+5,1,3);rr(c,'#8ab7c0',x+9,q.y+q.h-5,4,1);rr(c,'#8ab7c0',x+12,q.y+q.h-8,1,3);}c.restore();
}
function workshopTile(c,q,room){
 const id=String(q.sourceId||q.id||'');if(!/^mc-(?:workshop|glass)-/.test(id))return false;if(!visible(q))return true;c.save();c.beginPath();c.rect(q.x,q.y,q.w,q.h);c.clip();
 if(id.startsWith('mc-glass-')){rr(c,'#45524f',q.x,q.y,16,q.h);rr(c,'#45524f',q.x+q.w-16,q.y,16,q.h);rr(c,'#aeb69b',q.x,q.y,q.w,2);rr(c,'#637064',q.x,q.y+q.h-3,q.w,3);for(const xx of [q.x+2,q.x+q.w-8]){rr(c,'#856b47',xx,q.y+2,6,q.h-5);rr(c,'#c0a575',xx,q.y+3,1,q.h-6);}glassBlock(c,{x:q.x+16,y:q.y+2,w:Math.max(1,q.w-32),h:q.h-5});for(let xx=q.x+11;xx<q.x+q.w-8;xx+=12)rr(c,'#d0c8a2',xx,q.y+q.h-2,2,1);}
 else if(id.startsWith('mc-workshop-sand-'))tiled(c,q,['#d8bf80','#bba46d','#ebd69c','#cdb47b','#e4cc8f'],3);
 else if(id==='mc-workshop-hopper-gate'){rr(c,'#414b4e',q.x,q.y,q.w,q.h);rr(c,'#bbc4b6',q.x,q.y,q.w,2);rr(c,'#7a8884',q.x+1,q.y+2,q.w-2,3);for(let x=q.x+3;x<q.x+q.w;x+=8)rr(c,'#2d383e',x,q.y+4,3,3);}
 else{tiled(c,q,['#757b78','#484f52','#9b9e91','#606967','#868e84'],8);if(id==='mc-workshop-coal')for(let xx=q.x;xx<q.x+q.w;xx+=16)for(const [x,y]of [[3,3],[10,5],[5,11],[12,11]]){rr(c,'#292c30',xx+x,q.y+y,3,3);rr(c,'#151d23',xx+x,q.y+y,2,2);rr(c,'#adb0a1',xx+x,q.y+y+3,3,1);}}
 c.restore();return true;
}
function redstoneWire(c,points,on,tick){for(let i=1;i<points.length;i++){pixelLine(c,...points[i-1],...points[i],'#302b2d',4);pixelLine(c,...points[i-1],...points[i],on?'#c84532':'#692c2b',2);if(on)pixelLine(c,...points[i-1],...points[i],'#ff7850',1);}if(on&&tick%12<5)for(const [x,y]of points)rr(c,'#ffd28c',x,y-3,1,1);}
/** Eight physically wall-mounted note banks. Their sounding material and
 * signal pulses come exclusively from the live redstone sequencer view. */
export function minecraftSequencerArtPlan(room={},view=room.minecraftView){
 const sequence=stateOf(room,view).workshop?.sequence;
 if(!isFinale(room)||!room.minecraft?.workshop?.sequence||!sequence)return null;
 const age=Math.max(0,sequence.age||0),duration=Math.max(1,sequence.durationFrames||640),bar=sequence.currentBank??Math.min(7,Math.floor(age/(duration/8)));
 return {age,bar,active:!!sequence.active,started:!!sequence.started,complete:!!sequence.complete,banks:(sequence.banks||[]).map(q=>({...q,pulse:Math.max(0,q.pulse||0),active:!!sequence.active&&q.bar===bar,baseBlock:q.baseBlock||'dirt',lanes:(q.lanes||['dirt','stone','sand','gold_block'].map(baseBlock=>({baseBlock,pulse:q.baseBlock===baseBlock?q.pulse||0:0,note:q.note}))).map(l=>({...l,pulse:Math.max(0,l.pulse||0)}))}))};
}
function sequencerBanks(c,room,state,tick){const seq=minecraftSequencerArtPlan(room,state);if(!seq)return;const first=seq.banks[0],last=seq.banks.at(-1);if(!first||!last)return;
 const wireY=first.y-17;redstoneWire(c,[[124,319],[124,wireY],[last.x+24,wireY]],seq.started,tick);
 for(const q of seq.banks){const x=q.x,y=q.y,w=q.w||48,h=q.h||24,pulse=q.pulse>0;
  // Deep inset, bolted rails and lower corbels attach four fixed instruments.
  rr(c,'#142a26',x-5,y-6,w+10,h+28);rr(c,'#3f5546',x-5,y-6,w+10,3);rr(c,'#1d352c',x+w+2,y-3,3,h+25);
  for(const xx of [x-4,x+w+1]){rr(c,'#64705d',xx,y-4,3,h+25);rr(c,'#89917b',xx,y-3,1,h+23);for(const yy of [y-2,y+h+18]){rr(c,'#2b4035',xx-1,yy,5,4);rr(c,'#b2b79b',xx,yy+1,2,1);}}
  for(const [i,lane]of q.lanes.entries()){const xx=x+i*12,ww=10,material=lane.baseBlock,lit=lane.pulse>0,p=/gold/.test(material)?['#b39633','#756027','#dfc86b','#9b8131','#f2dea0']:/sand/.test(material)?['#bca873','#8b805c','#d8c591','#a29367','#e6d9ae']:/stone/.test(material)?['#697772','#3c4e4a','#92a08d','#52665b','#b4bca2']:['#77583d','#493e30','#9e7d51','#614c36','#bc9a63'];
   block(c,xx,y+h,ww,14,p,i+Math.floor(x),false);rr(c,p[1],xx+ww-2,y+h+2,2,12);rr(c,p[2],xx,y+h,ww,2);
   rr(c,'#3d3028',xx,y+7,ww,h-7);rr(c,'#855e38',xx+1,y+10,ww-3,h-11);rr(c,'#bb9255',xx+1,y+7,ww-3,3);rr(c,'#5a452e',xx+ww-2,y+8,2,h-8);rr(c,'#d3ac6b',xx+1,y+7,ww-3,1);
   for(let yy=y+12;yy<y+h-2;yy+=4)for(let dx=2;dx<ww-2;dx+=3){rr(c,'#45382b',xx+dx,yy,2,2);rr(c,lit?'#eed388':'#aa8350',xx+dx,yy,1,1);}
   rr(c,lit?'#f6d285':'#653e2e',xx+4,y+3,2,4);rr(c,lit?'#fff2bb':'#9a6640',xx+3,y+2,4,2);
   if(lit){const rise=(12-lane.pulse)*1.4,nx=xx+5,ny=y-5-rise,color=/gold/.test(material)?'#f6df88':/stone/.test(material)?'#acbad3':/sand/.test(material)?'#d9c9a3':'#b6db91';rr(c,color,nx,ny,1,7);rr(c,color,nx-3,ny+5,4,2);rr(c,color,nx+1,ny,3,1);}
  }
  rr(c,'#4d6051',x-2,y+h+14,w+4,4);rr(c,'#92a083',x-2,y+h+14,w+4,1);for(const xx of [x+1,x+w-6])pixelLine(c,xx,y+h+18,xx+4,y+h+22,'#4a5e4c',3);
  redstoneWire(c,[[x+24,wireY],[x+24,y+1],[x+4,y+1],[x+40,y+1]],pulse,tick);rr(c,'#3b4b3c',x+15,wireY-5,18,4);rr(c,'#b2b198',x+16,wireY-5,16,2);
  for(const xx of [x+19,x+28]){rr(c,pulse?'#e26d44':'#6e3d31',xx,wireY-9,2,5);rr(c,pulse?'#ffe3a2':q.active?'#c28e53':'#895b3b',xx-1,wireY-10,4,3);}
  rr(c,'#243b30',x+20,y+h+24,9,4);rr(c,seq.complete?'#9dc88a':q.active?'#e3c87e':seq.started&&q.bar<seq.bar?'#788f61':'#415b41',x+21,y+h+25,7,2);
 }
}
function workshopScenery(c,room){
 if(!room.minecraft.workshop)return;const v=stateOf(room).workshop||{},tick=tickOf(room);
 // Reservoir rails are bolted to the real ceiling and hold a physical gate.
 for(const x of [298,338]){rr(c,'#2c3838',x,32,5,137);rr(c,'#77877c',x+1,32,2,135);for(let y=44;y<168;y+=24){rr(c,'#aeb39a',x,y,5,3);rr(c,'#384744',x+2,y+1,1,1);}}
 rr(c,'#58675e',296,48,49,6);rr(c,'#9ca68e',297,48,47,1);rr(c,'#2c3838',296,166,49,3);
 if(v.gateOpen){rr(c,'#4d5b59',337,157,21,8);rr(c,'#b2baaa',338,157,19,2);}
 // Coal is exposed in a wall recess whose two side piers reach the ceiling.
 rr(c,'#263a34',194,32,62,240);for(const x of [194,248]){tiled(c,{x,y:32,w:8,h:240},STRONGHOLD,9,true);}rr(c,'#1b2a29',207,254,34,19);rr(c,'#4b5e4e',202,252,8,17);rr(c,'#86927a',203,253,2,15);rr(c,'#4b5e4e',239,252,10,17);rr(c,'#86927a',240,253,2,15);rr(c,'#3a4d42',202,249,47,6);rr(c,'#718269',203,249,45,1);
 for(let i=0;i<3;i++){
  if(room.minecraft.workshop.sequence){const x=[352,392,424][i];rr(c,'#273c33',x+1,299,18,17);rr(c,'#7f8970',x+2,299,16,3);rr(c,'#4c6251',x+2,302,16,13);for(let dx=4;dx<15;dx+=4)rr(c,'#293e34',x+dx,304,2,8);rr(c,'#a2ac8b',x+3,300,14,1);continue;}
  const x=352+i*40+(i===2?-8:0),px=x+1,base=['dirt','stone','gold'][i],p=base==='dirt'?['#76533a','#523e30','#a17b50','#896343']:base==='gold'?['#d2ab39','#987526','#f2d974','#e1c456']:['#737d77','#4a5653','#9ea591','#647269'];
  // A note block rests on its instrument-selecting material, all on the floor.
  rr(c,'#1b2d2b',px-3,268,25,51);rr(c,'#3d5143',px-4,267,27,2);rr(c,'#718069',px-4,268,1,50);rr(c,'#152925',px+21,269,2,50);c.save();c.globalAlpha*=.76;tiled(c,{x:px+1,y:288,w:16,h:32},p,14+i);rr(c,'#40312a',px,272,18,16);rr(c,'#94683d',px+1,272,16,15);rr(c,'#b99059',px+1,272,16,2);
  for(let yy=276;yy<286;yy+=3)for(let xx=px+3;xx<px+16;xx+=3){rr(c,'#4e392b',xx,yy,2,2);rr(c,'#d0a165',xx,yy,1,1);}rr(c,'#5a412c',px+17,273,1,15);c.restore();
 }
 // Thin redstone runs over the exposed masonry face, away from the head lane.
 redstoneWire(c,[[124,319],[124,333],[280,333],[280,163],[298,163]],!!v.gateOpen,tick);
 for(let i=0;i<3;i++){
  const q=v.plates?.[i]||{x:[352,392,424][i]},active=q.latched||q.pressed||q.delay>0;
  redstoneWire(c,[[q.x+10,318],[q.x+10,332+i*5],[448+i*64+32,332+i*5],[448+i*64+32,365]],active,tick);
  // Repeater: two redstone torches on a pale stone slab, in the foreground.
  rr(c,'#444c46',q.x+2,308,16,7);rr(c,'#b2b5a2',q.x+2,308,16,2);rr(c,'#777e70',q.x+3,310,14,5);rr(c,active?'#ee6e43':'#6f3330',q.x+5,306,2,6);rr(c,active?'#ffba73':'#995342',q.x+4,305,4,3);rr(c,q.delay>0?'#ffb469':q.latched?'#e36b45':'#6f3330',q.x+12,306,2,6);rr(c,q.delay>0?'#ffe5a5':q.latched?'#ffb469':'#995342',q.x+11,305,4,3);
  const bx=448+i*64,installed=v.bridges?.some(b=>b.x===bx),lift=q.delay>0?1-q.delay/24:installed?1:0;
  // The narrow piston rods are visibly anchored below the gap. No false deck.
  rr(c,'#263937',bx+26,368,12,16);rr(c,'#667568',bx+27,369,10,14);rr(c,'#a0a98c',bx+26,368,12,2);const top=365-lift*45;rr(c,'#414f4b',bx+29,top,6,368-top);rr(c,'#a6b1a2',bx+30,top,2,368-top);rr(c,'#5a5140',bx+8,top-4,48,5);rr(c,'#bea574',bx+8,top-4,48,1);
  if(q.delay>0)workshopTile(c,{id:'mc-glass-bridge-'+i,x:bx,y:top-20,w:64,h:16},room);
 }
}
function coalItem(c,x,y){rr(c,'#38403f',x+2,y,7,2);rr(c,'#19232a',x,y+2,11,7);rr(c,'#0d1820',x+2,y+7,7,4);rr(c,'#5b6460',x+2,y+2,5,2);rr(c,'#747c6b',x+3,y+2,2,1);}
function workshopWorld(c,room,state,tick){
 if(!room.minecraft.workshop)return;sequencerBanks(c,room,state,tick);const v=state.workshop||{},f=v.furnace||{x:288,y:288,w:48,h:32},x=f.x,y=f.y;
 // Left module is a square furnace; the right module is its output tray.
 rr(c,'#353e40',x,y,32,32);tiled(c,{x:x+1,y:y+1,w:30,h:30},['#777e78','#4b5453','#a8ac9b','#92998a'],5);rr(c,'#b9bcaa',x,y,32,2);rr(c,'#313b3d',x+5,y+5,22,9);rr(c,'#151f28',x+7,y+7,18,5);rr(c,'#555e58',x+7,y+12,18,2);rr(c,'#343d3d',x+5,y+19,22,10);rr(c,'#101b24',x+7,y+21,18,7);
 if(f.lit){glow(c,x+16,y+26,34,'#ffab55',.2);for(let i=0;i<6;i++){const fh=3+(hash(i,Math.floor(tick/6))%5);rr(c,'#d45528',x+7+i*3,y+28-fh,3,fh);rr(c,'#f49c35',x+8+i*3,y+29-fh,2,fh-1);rr(c,'#ffe293',x+8+i*3,y+27,1,1);}for(let i=0;i<3;i++){const age=(tick+i*17)%60;rr(c,i%2?'#5b6060':'#77796e',x+11+(i%2)*7,y-5-age*.5,2,3);}}
 rr(c,'#53635d',x+32,y+9,16,23);rr(c,'#99a18a',x+32,y+9,16,2);rr(c,'#263c3b',x+34,y+12,12,16);for(let i=0;i<(f.glass||0);i++)glassBlock(c,{x:x+35,y:y+22-i*4,w:10,h:5});
 if(f.lit){rr(c,'#374a43',x+34,y+3,12,3);rr(c,'#e3be68',x+34,y+3,12*(f.progress||0)/90,2);}
 // Fallen sand items arc into this hopper, which points directly into the top.
 const hopper=v.hopper||{x:280,y:264,w:32,h:16};rr(c,'#293b3b',hopper.x,hopper.y,hopper.w,4);rr(c,'#98a69b',hopper.x+1,hopper.y,hopper.w-2,1);rr(c,'#182c2d',hopper.x+3,hopper.y+1,hopper.w-6,2);rr(c,'#52665d',hopper.x+4,hopper.y+4,hopper.w-8,4);rr(c,'#42564f',hopper.x+8,hopper.y+8,hopper.w-16,4);rr(c,'#708478',hopper.x+12,hopper.y+12,hopper.w-24,288-hopper.y-12);
 const tq=v.torch||{x:312,y:240};const tx=tq.x+3,ty=tq.y;glow(c,tx,ty,28,'#ffbf67',.18);rr(c,'#5a3e29',tx-1,ty+5,3,11);rr(c,'#b58b4c',tx,ty+5,1,10);rr(c,'#d36827',tx-3,ty+1,7,6);rr(c,'#fdb54b',tx-2,ty-2-Math.floor(tick/8)%2,5,7);rr(c,'#fff3ad',tx-1,ty,2,4);
 for(const item of v.sandItems||[])if(item.state!=='collected'){rr(c,'#a68a55',item.x,item.y,8,8);rr(c,'#dfc389',item.x,item.y,7,6);rr(c,'#f2dca3',item.x,item.y,7,1);rr(c,'#bda16b',item.x+2,item.y+3,2,1);}
 if(v.coal?.state==='dropping')coalItem(c,v.coal.x,v.coal.y);else if(v.coal?.state==='carried')coalItem(c,v.coal.x,v.coal.y);else if((f.fuel||f.consumedCoal)&&!f.lit)rr(c,'#36413e',x+9,y+23,14,3);
 for(const q of [v.releasePlate||{x:112,y:316,w:24,h:4},...(v.plates||[])]){const py=q.pressed?318:316;rr(c,'#45574d',q.x,py,q.w||20,320-py);rr(c,q.pressed?'#91a28c':'#bdc7ab',q.x+1,py,(q.w||20)-2,1);rr(c,'#728574',q.x+1,py+1,(q.w||20)-2,Math.max(1,319-py));}
 for(const q of v.plates||[])if(q.pulse>0&&!room.minecraft.workshop.sequence){const yy=264-(24-q.pulse)*.55,xx=q.x+9;rr(c,q.baseBlock==='gold'?'#edc866':q.baseBlock==='stone'?'#b8a0df':'#8bcba0',xx,yy,2,8);rr(c,'#e4dca1',xx-3,yy+6,4,3);rr(c,'#c6bd85',xx+1,yy,4,2);}
}
/** Texture marks stay on authored faces: pitted End stone and staggered
 * stronghold masonry read as different materials without inventing platforms. */
function finaleMaterialDetail(c,q,kind){
 if(kind!=='endstone'&&kind!=='stronghold')return;c.save();c.beginPath();c.rect(q.x,q.y,q.w,q.h);c.clip();
 if(kind==='endstone'){
  for(let y=q.y+4;y<q.y+q.h;y+=16)for(let x=q.x;x<q.x+q.w;x+=16){const n=hash(x,y,104);for(let i=0;i<3;i++){const px=x+2+hash(n,i)%10,py=y+hash(n,i+4)%10,ww=2+hash(n,i+8)%3;rr(c,'#a4a36e',px,py,ww,2);rr(c,'#e2dc9f',px-1,py-1,ww,1);rr(c,'#8e9464',px+1,py+1,Math.max(1,ww-2),1);}}
 }else{
  for(let row=0,y=q.y;y<q.y+q.h;row++,y+=16)for(let x=q.x-(row%2?16:0);x<q.x+q.w;x+=32){const n=hash(x,y,105),p=['#626b65','#68716a','#5b6761','#6f776d'];rr(c,'#35433f',x,y,32,16);rr(c,p[n%4],x+1,y+1,30,13);rr(c,'#879083',x+2,y+1,27,1);rr(c,'#47564f',x+2,y+13,28,1);rr(c,'#748072',x+4,y+5,6,1);
   if(n%5===0){pixelLine(c,x+18,y+2,x+15,y+6,'#394a43',1);pixelLine(c,x+15,y+6,x+20,y+10,'#394a43',1);}
   if(n%4===0){rr(c,'#465e43',x+3,y+10,7,3);rr(c,'#65794c',x+5,y+10,3,1);rr(c,'#557042',x+9,y+12,4,2);}
  }
 }c.restore();
}
function paintFinaleTile(c,q,room={}){if(!isFinale(room))return false;if(workshopTile(c,q,room))return true;const id=String(q.sourceId||q.id||'');if((room.minecraft.dragon?.crystalIds||[]).includes(id)||q.mcDragonEgg||id===room.minecraft.dragon?.id+'-egg')return true;const bedrock=/^mc-bedrock(?:-|$)/.test(id),end=/^mc-endstone(?:-|$)/.test(id),hold=/^mc-stronghold(?:-|$)/.test(id),vault=/(?:bastion|vault).*(?:wall|roof|floor|back|step)|mc-blackstone/.test(id);if(!bedrock&&!end&&!hold&&!vault)return false;if(!visible(q))return true;c.save();tiled(c,q,bedrock?BEDROCK:end?ENDSTONE:hold?STRONGHOLD:BLACKSTONE,id.length,!end&&!bedrock);if(bedrock){rr(c,'#bab7b4',q.x,q.y,q.w,1);rr(c,'#34343e',q.x,q.y+q.h-1,q.w,1);if(/fountain-base/.test(id)){rr(c,'#181820',q.x+8,q.y+2,q.w-16,5);rr(c,'#3e3546',q.x+9,q.y+2,q.w-18,1);rr(c,'#8d8891',q.x+8,q.y+7,q.w-16,1);}if(/fountain-step/.test(id)){rr(c,'#11131e',q.x+8,q.y+2,q.w-16,9);rr(c,'#332c40',q.x+9,q.y+2,q.w-18,1);tiled(c,{x:q.x+q.w/2-12,y:q.y,w:24,h:q.h},BEDROCK,19);rr(c,'#a49da9',q.x+8,q.y+11,q.w-16,1);}if(/fountain-plinth/.test(id)){rr(c,'#272731',q.x,q.y+4,12,q.h-4);rr(c,'#272731',q.x+q.w-12,q.y+4,12,q.h-4);rr(c,'#aba5ac',q.x,q.y+3,q.w,1);rr(c,'#7a7383',q.x+12,q.y+4,2,q.h-4);}}finaleMaterialDetail(c,q,end?'endstone':hold?'stronghold':'');if(end){rr(c,'#f3edb7',q.x,q.y,q.w,2);for(let x=q.x+5;x<q.x+q.w-3;x+=13){rr(c,'#8f9466',x,q.y+6,4,2);rr(c,'#e0dba3',x-1,q.y+5,3,1);}}if(vault&&/cracked|wall/.test(id)){const x=q.x+q.w/2;pixelLine(c,x,q.y,x-4,q.y+q.h*.3,'#0e1420',2);pixelLine(c,x-4,q.y+q.h*.3,x+3,q.y+q.h*.55,'#0e1420',2);pixelLine(c,x+3,q.y+q.h*.55,x-2,q.y+q.h,'#0e1420',2);rr(c,'#c28945',q.x+3,q.y+7,4,2);rr(c,'#e4b865',q.x+4,q.y+7,2,1);}paintMinecraftVoxelRelief(c,q,room,bedrock?BEDROCK:end?ENDSTONE:hold?STRONGHOLD:BLACKSTONE);c.restore();return true;}

function paintFinaleBackground(c,room,w,h){if(!isFinale(room))return false;c.save();const biome=room.minecraft.biome,p=biome==='end'?['#070912','#0c0c19','#121020','#181326']:biome==='stronghold'?['#172322','#202e29','#27392e','#364638']:['#1a1020','#32172a','#54212d','#762d2d'];for(let i=0;i<p.length;i++)rr(c,p[i],0,Math.floor(h*i/p.length),w,Math.ceil(h/p.length));c.restore();return true;}
function rearButtress(c,x,y,w,h,p,depth=6){
 rr(c,p[0],x,y+depth,w-depth,h-depth);poly(c,[[x,y+depth],[x+depth,y],[x+w,y],[x+w-depth,y+depth]],p[2]);poly(c,[[x+w-depth,y+depth],[x+w,y],[x+w,y+h-depth],[x+w-depth,y+h]],p[1]);
 rr(c,p[3]||p[2],x,y+depth,1,h-depth);for(let yy=y+depth+15;yy<y+h;yy+=16){rr(c,p[1],x,yy,w-depth,1);rr(c,p[0],x+w-depth,yy-depth,depth,1);}
}
function fortressDistance(c,room){const v=bounds(room),floor=floorOf(room),speed=.31,spacing=286;
 for(let i=Math.floor(v.x*speed/spacing)-1;i<(v.x*speed+v.w)/spacing+1;i++){const x=i*spacing+v.x*(1-speed),y=91+hash(i,92)%31,p=['#332231','#211c2a','#45303c','#4d3440'];
  // A far fortress arcade, deliberately dimmer than the real block path.
  rr(c,'#261b2a',x-6,y+22,228,13);rr(c,'#462c37',x-4,y+22,224,2);
  for(let n=0;n<4;n++){const xx=x+n*65;rearButtress(c,xx,y-14,25,floor-y+46,p,7);for(let t=0;t<3;t++)rr(c,'#3b2634',xx-3+t*12,y-23,7,10);}
  for(let n=0;n<3;n++){const xx=x+22+n*65;for(let k=0;k<3;k++){rr(c,'#31212e',xx+k*5,y+35+k*6,8,7);rr(c,'#31212e',xx+39-k*5,y+35+k*6,8,7);}}
 }
}
function netherBackdrop(c,room){const v=bounds(room),floor=floorOf(room),tick=tickOf(room);fortressDistance(c,room);for(let layer=0;layer<2;layer++){const step=layer?146:112,parallax=layer?.5:.78;for(let i=Math.floor(v.x*(1-parallax)/step)-2;i<(v.x*(1-parallax)+v.w)/step+2;i++){const x=i*step+v.x*parallax,n=hash(i,layer+10),base=floor+40,top=42+n%90,w=38+n%46;rr(c,layer?'#36323b':'#262532',x,top,w,base-top);rr(c,layer?'#48404a':'#35313f',x+4,top+2,w-10,5);rr(c,layer?'#242330':'#1d1e2b',x+w-7,top+5,7,base-top-5);rr(c,layer?'#5a4b50':'#443c46',x+2,top+2,2,base-top-3);for(let y=top+22;y<base;y+=24)rr(c,layer?'#282833':'#20212e',x,y,w,2);for(let k=0;k<4;k++)rr(c,layer?'#403a43':'#302d3c',x+6+k*8,top-12-k*5,8,18+k*5);for(let xx=x+8;xx<x+w-9;xx+=9){rr(c,layer?'#4b4149':'#35313c',xx,top+8,2,base-top-9);rr(c,layer?'#2a2935':'#211f2d',xx+2,top+9,1,base-top-10);}if(n%3===0){const lx=x+w-8;rr(c,'#6d2e29',lx,0,8,base);rr(c,'#a74429',lx+2,0,4,base);rr(c,'#db6931',lx+3,0,2,base);for(let y=0;y<base;y+=19)rr(c,'#f39847',lx+3,y+(tick*.25)%19,2,6);}}}
 // Distant lava shelf sits below the native banks; foreground gaps remain honest.
 rr(c,'#692c2c',v.x,floor+14,v.w,v.h);for(let y=floor+22;y<v.y+v.h;y+=9){rr(c,y%2?'#a5472b':'#8f3929',v.x,y,v.w,2);for(let x=v.x-30;x<v.x+v.w;x+=83)rr(c,'#c55a31',x+(tick*.2)%30,y,31,1);}
 // Low, transparent heat bands remain behind the collision banks.
 c.save();c.globalAlpha*=.08;for(let i=0;i<4;i++){const drift=Math.sin(tick*.008+i)*7;rr(c,'#71352f',v.x,floor-20+i*10+drift,v.w,2);}c.restore();
 for(let i=0;i<28;i++){const x=v.x+hash(i,31)%Math.max(1,Math.ceil(v.w)),y=v.y+(hash(i,32)%Math.max(1,Math.ceil(v.h)) -tick*.15%v.h+v.h)%v.h;rr(c,i%4?'#ac6744':'#e59759',x,y,1,i%3?1:2);}
}
function bastionScenery(c,room){const spec=room.minecraft.nether?.bastion;if(!spec)return;const walls=(spec.wallIds||[]).map(id=>geometry(room).find(g=>g.id===id)).filter(Boolean);const reward=spec.reward||{},left=walls.length?Math.min(...walls.map(g=>g.x)):reward.x-48,top=walls.length?Math.min(...walls.map(g=>g.y))-16:reward.y-56,right=Math.max(left+112,reward.x+40),base=groundAt(room,right-8,top+96)??floorOf(room);const open=stateOf(room).nether?.bastion?.opened;
 rr(c,'#151b25',left+8,top+8,right-left-8,base-top-8);for(let y=top+16;y<base;y+=16)for(let x=left+12;x<right-8;x+=16)block(c,x,y,16,16,['#292834','#191d29','#3c3540','#302b37'],hash(x,y),true);
 for(const x of [left-8,right-8]){tiled(c,{x,y:top+8,w:16,h:base-top-8},BLACKSTONE,11,true);rr(c,'#1d232d',x-5,base-8,26,8);rr(c,'#6b5960',x-4,base-8,24,1);rr(c,'#b39257',x+4,top+22,6,5);rr(c,'#e7c278',x+5,top+22,2,3);}
 tiled(c,{x:left-10,y:top,w:right-left+28,h:16},BLACKSTONE,12,true);for(let x=left-8;x<right+10;x+=24){rr(c,'#36303b',x,top-9,12,10);rr(c,'#64505a',x+1,top-9,10,1);}rr(c,'#a77d42',left+26,top+5,right-left-40,3);rr(c,'#d9b56a',left+27,top+5,right-left-42,1);sconce(c,right-18,top+39,tickOf(room),true);
 // Recessed masonry supports the high vault without inventing a solid front
 // wall across its real walkable underpass. Dark back-plane piers meet ground.
 const deck=reward.y+24;
 if(base>deck){rr(c,'#141923',left+12,deck+8,right-left-24,base-deck-8);rr(c,'#1b1e29',left+18,deck+11,right-left-36,base-deck-11);for(const x of [left-8,right-8]){rr(c,'#262431',x,deck+8,16,base-deck-8);rr(c,'#463943',x+1,deck+8,2,base-deck-8);for(let y=deck+15;y<base;y+=12)rr(c,'#191d29',x,y,16,1);rr(c,'#33303b',x-4,base-5,24,5);}for(let i=0;i<4;i++){const y=deck+8+i*6,inset=i*5;rr(c,'#352c39',left+8,y,18-inset,6);rr(c,'#352c39',right-8-18+inset,y,18-inset,6);}rr(c,'#1a1e28',left+16,deck+8,right-left-32,2);}
 for(const g of geometry(room).filter(g=>/(?:bastion|vault).*step/.test(g.id||'')&&g.y<300)){const ground=groundAt(room,g.x+g.w-5,g.y+g.h);if(ground!=null&&ground>g.y+g.h){const top=g.y+g.h;rr(c,'#292633',g.x+g.w-9,top,8,ground-top);rr(c,'#483945',g.x+g.w-9,top,2,ground-top);pixelLine(c,g.x+3,top+1,g.x+g.w-5,top+24,'#443540',5);rr(c,'#38303a',g.x+g.w-12,ground-4,15,4);}}
 if(open){rr(c,'#0f1720',left,top+16,20,Math.min(64,base-top-16));rr(c,'#76594a',left-2,top+18,3,base-top-18);for(let i=0;i<6;i++)block(c,left-8+i*5,base-5-(i%2)*3,4,3,BLACKSTONE,i);}
}
function strongholdBackdrop(c,room){const v=bounds(room),floor=floorOf(room);for(let y=Math.floor(v.y/16)*16;y<floor;y+=16)for(let bx=Math.floor(v.x*.2/32)*32;bx<v.x*.2+v.w;bx+=32){const x=bx+v.x*.8,n=hash(bx,y,13);rr(c,['#283b35','#2b3e36','#304238','#263a33'][n%4],x,y,32,16);rr(c,'#3c4e41',x+1,y,30,1);rr(c,'#20322e',x+(Math.floor(y/16)%2?16:0),y,1,16);if(n%5===0){rr(c,'#41583e',x+4,y+8,5,3);rr(c,'#537047',x+8,y+9,4,2);}if(y>=224){rr(c,['#252d30','#293234','#30383a'][n%3],x,y,32,16);rr(c,'#38433f',x+1,y+1,30,1);rr(c,'#1b272b',x,y+14,32,2);rr(c,'#1d292c',x+(Math.floor(y/16)%2?15:1),y+1,1,13);rr(c,'#3d4641',x+5+n%12,y+7,7,1);}}
 for(let i=Math.floor(v.x*.68/192)-1;i<(v.x*.68+v.w)/192+1;i++){const x=48+i*192+v.x*.32,base=floor;
 rr(c,'#102724',x+20,53,104,base-53);for(let depth=0;depth<4;depth++){const inset=8+depth*9,yy=61+depth*12,ww=104-inset*2,col=['#354c3e','#2b4538','#233c32','#1b342d'][depth];rr(c,col,x+20+inset,yy,ww,4);rr(c,col,x+20+inset,yy,4,base-yy-12);rr(c,col,x+120-inset,yy,4,base-yy-12);}
 for(const side of [0,1])pixelLine(c,x+(side?126:22),base-9,x+(side?86:64),166,'#2c4438',1);
 for(const px of [x,x+128]){rearButtress(c,px,43,16,base-43,['#32473d','#1f342f','#627159','#596a52'],5);rr(c,'#596a52',px+1,48,3,base-48);rr(c,'#1f342f',px+13,48,3,base-48);for(let y=48;y<base;y+=16)rr(c,'#213730',px,y+15,16,1);rr(c,'#4e6049',px-4,base-8,24,8);}for(let n=0;n<4;n++){rr(c,'#364b3f',x+16+n*12,48-n*9,128-n*24,10);rr(c,'#56684e',x+17+n*12,48-n*9,126-n*24,1);}rr(c,'#102723',x+57,113,32,53);for(let px=x+60;px<x+89;px+=9){rr(c,'#51645b',px,113,2,53);rr(c,'#798478',px,114,1,50);}for(const y of [124,155])rr(c,'#394f43',x+57,y,32,2);for(let i=0;i<5;i++){const xx=x+20+i*18,depth=17+hash(i,x)%30;rr(c,'#3b5b3d',xx,50,1,depth);for(let dy=6;dy<depth;dy+=8)rr(c,'#597345',xx-2+(dy%3),50+dy,4,3);}}
}
function endIsland(c,x,y,w,depth,near=false){const p=near?ENDSTONE:['#625d54','#41414a','#7b7364','#57534f','#8e816a'];rr(c,p[2],x+10,y,w-20,4);rr(c,p[0],x,y+4,w,8);poly(c,[[x+10,y],[x+w-10,y],[x+w,y+4],[x,y+4]],p[2]);rr(c,p[1],x+w-12,y+5,12,7);for(let row=0;row<depth;row+=8){const inset=Math.floor(row/8)*7;rr(c,p[row%16?1:3],x+inset,y+12+row,Math.max(0,w-inset*2),8);rr(c,p[0],x+inset+2,y+12+row,Math.max(0,w-inset*2-4),1);}for(let i=0;i<w/12;i++)rr(c,p[1],x+7+i*12,y+5+hash(i,w)%5,3,2);}
function endBackdrop(c,room){const v=bounds(room),floor=floorOf(room),tick=tickOf(room);for(let i=0;i<60;i++){const x=v.x+(hash(i,70)%Math.ceil(v.w)+v.x*.07)%v.w,y=v.y+hash(i,71)%Math.ceil(v.h);rr(c,i%7?'#393047':'#73637e',x,y,1,1);}for(let i=-1;i<8;i++){const x=i*191+v.x*.72,y=188+hash(i,20)%89;endIsland(c,x,y,50+hash(i,21)%50,34+hash(i,22)%28);}
 // Tall rear monoliths are desaturated background shapes; the three playable
 // crystal pedestals are independently aligned to their real native platforms.
 for(let i=Math.floor(v.x*.52/187)-1;i<(v.x*.52+v.w)/187+1;i++){const x=90+i*187+v.x*.48,y=38+hash(i,8)%77,w=20+hash(i,9)%12;rearButtress(c,x,y-5,w,floor-y+17,['#181522','#100f1b','#41314d','#30253b'],6);rr(c,'#30253b',x,y,3,floor-y+12);rr(c,'#3d2d48',x,y,w,2);for(let py=y+12;py<floor;py+=16){rr(c,'#211a2c',x+3,py,w-3,1);rr(c,'#3a2945',x+5+hash(i,py)%(w-10),py+4,4,1);}rr(c,'#120f1d',x+w-4,y+2,4,floor-y+10);}
 for(const g of geometry(room)){if(!/^mc-endstone/.test(g.id||'')||g.h<24)continue;const base=g.y+g.h;for(let i=0;i<3;i++){const inset=8+i*11;rr(c,['#716f59','#58584f','#3e3e43'][i],g.x+inset,base+i*7,Math.max(0,g.w-inset*2),8);}}
 for(let i=0;i<12;i++){const x=v.x+hash(i,77)%Math.ceil(v.w),y=v.y+50+(hash(i,78)%Math.max(1,Math.ceil(v.h-50))+tick*.13)%(v.h-50);rr(c,i%3?'#6a4d7e':'#ac82bd',x,y,1,i%2?2:1);}
}
function crystalPedestals(c,room){for(const p of finaleSupportPlan(room).pedestals){const h=p.ground-p.top;if(h>0){tiled(c,{x:p.x-6,y:p.top,w:12,h},OBS,7);rr(c,'#6c526f',p.x-6,p.top,12,2);rr(c,'#8b7790',p.x-5,p.top,10,1);}rr(c,'#32263f',p.x-10,p.ground-4,20,4);rr(c,'#79617e',p.x-9,p.ground-4,18,1);}}
function authoredOcclusion(c,room){const v=bounds(room);c.save();c.globalAlpha*=.25;for(const g of geometry(room)){if(!visible(g)||g.x>v.x+v.w||g.x+g.w<v.x||g.h<16||/crystal/.test(g.id||''))continue;
 // The shadow falls into the rear plane, never across the playable top edge.
 rr(c,'#080b14',g.x+5,g.y+7,g.w,g.h);rr(c,'#080b14',g.x+2,g.y+3,g.w,g.h);
 }c.restore();}
function paintFinaleScenery(c,room={}){if(!isFinale(room))return false;c.save();const biome=room.minecraft.biome,tick=tickOf(room);if(biome==='nether'){netherBackdrop(c,room);bastionScenery(c,room);}else if(biome==='stronghold'){strongholdBackdrop(c,room);workshopScenery(c,room);for(let x=128;x<(room.map?.width||640);x+=192)sconce(c,x,224,tick);}else{endBackdrop(c,room);crystalPedestals(c,room);}authoredOcclusion(c,room);for(const q of room.minecraft.scenery||[]){if(q.hidden)continue;if(q.kind==='portal')obsidianPortal(c,room,q,tick);else if(q.kind==='end-portal'){if(biome==='end')bedrockExit(c,room,q,tick,!!stateOf(room).dragon?.exitUnlocked);else endPortal(c,room,q,tick,q.lit!==false);}else if(q.kind==='torch')sconce(c,q.x,q.y,tick,q.variant==='soul'||biome==='end');else if(q.kind==='mushroom'){rr(c,'#b89b85',q.x+3,q.y-7,2,7);rr(c,'#a54135',q.x,q.y-11,8,5);rr(c,'#f0af78',q.x+2,q.y-10,2,2);}}
 c.restore();return true;}

/** Short, controller-driven death beats. These plans never change collision,
 * reward or portal timing, and never introduce weather in the End. */
export function minecraftBossDeathArtPlan(kind,q={},room={}){
 const dragon=kind==='dragon';if(dragon?!(q.defeated||q.state==='defeated')||!q.body:!q.dead||!Number.isFinite(q.defeatDuration))return null;
 const duration=dragon?(q.deathSequence?.duration||84):q.defeatDuration,age=clamp(dragon?(q.deathSequence?.age??q.stateAge??0):(q.defeatAge||0),0,duration),progress=age/duration;
 const box=dragon?q.body:q,cx=box.x+box.w/2,cy=box.y+box.h/2,lift=Math.min(dragon?22:14,age*.3),start=dragon?18:12,end=dragon?66:48;
 const opacity=clamp(1-(age-start)/(end-start),0,1),dissolve=clamp((age-start)/(end-start),0,1),phase=age>=duration?'complete':age<start?'fracture':dragon&&age>=66?'portal':'dissolve';
 const rays=[],fragments=[],orbs=[];
 if(age<end){const strength=Math.sin(Math.PI*clamp((age+3)/(end+8),0,1));for(let i=0;i<(dragon?10:7);i++){const angle=i*Math.PI*2/(dragon?10:7)+.13,reach=(dragon?48:28)+strength*(dragon?75:35);rays.push({x:cx,y:cy-lift,angle,reach,width:dragon?8:5,alpha:strength*.45});}}
 if(age>=start&&age<duration){const n=dragon?58:28,t=age-start,fade=clamp((duration-age)/22,0,1);for(let i=0;i<n;i++){const ox=(hash(i,11)%100/100-.5)*box.w,oy=(hash(i,12)%100/100-.5)*box.h,a=i*2.399,travel=t*(.35+hash(i,13)%7*.085),size=2+hash(i,14)%4;fragments.push({x:cx+ox+Math.cos(a)*travel,y:cy+oy+Math.sin(a)*travel*.7-lift-t*.19,size,alpha:fade,color:dragon?['#37273f','#83569b','#d4a0ee','#f8dcff'][i%4]:['#d9d3ce','#fff3df','#ad9fa7','#e7bba3'][i%4]});}}
 if(dragon&&age>=36&&age<duration){const exit=room.map?.objects?.find(e=>e.id===room.minecraft?.dragon?.exitPortalId);if(exit){const tx=exit.x+exit.w/2,ty=(groundAt(room,tx,exit.y)??exit.y+exit.h)-16;for(let i=0;i<9;i++){const t=clamp((age-36-i*2)/34,0,1);if(t<=0||t>=1)continue;orbs.push({x:cx+(tx-cx)*t,y:cy-lift+(ty-cy+lift)*t-Math.sin(t*Math.PI)*(40+i%3*8),size:2+i%3,alpha:Math.sin(t*Math.PI),color:i%3?'#d9a2f5':'#e2ffd4'});}}}
 return {kind,age,duration,progress,phase,opacity,dissolve,lift,cx,cy,rays,fragments,orbs};
}
function pixelRing(c,x,y,r,color,width=2,flatten=1){let prev=null;for(let i=0;i<=20;i++){const a=i*Math.PI/10,p=[x+Math.cos(a)*r,y+Math.sin(a)*r*flatten];if(prev)pixelLine(c,...prev,...p,color,width);prev=p;}}
function paintBossDeath(c,plan){if(!plan||plan.phase==='complete')return;c.save();const alpha=c.globalAlpha;
 for(const r of plan.rays){c.globalAlpha=alpha*r.alpha;const side=r.width,dx=Math.cos(r.angle),dy=Math.sin(r.angle);poly(c,[[r.x-dy*side*.5,r.y+dx*side*.5],[r.x+dx*r.reach,r.y+dy*r.reach],[r.x+dy*side*.5,r.y-dx*side*.5]],plan.kind==='dragon'?'#c790ee':'#ffce9c');}
 for(const p of plan.fragments){c.globalAlpha=alpha*p.alpha;rr(c,p.color,p.x,p.y,p.size,p.size);rr(c,plan.kind==='dragon'?'#f6d5ff':'#fff4dd',p.x,p.y,p.size,1);}
 for(const p of plan.orbs){c.globalAlpha=alpha*p.alpha;glow(c,p.x,p.y,12,p.color,.25);rr(c,p.color,p.x,p.y,p.size,p.size);rr(c,'#ffffff',p.x,p.y,1,1);}
 c.restore();
}
function dissolveClip(c,plan,box){if(!plan||plan.dissolve<=0)return;c.beginPath();for(let y=box.y;y<box.y+box.h;y+=5)for(let x=box.x;x<box.x+box.w;x+=5)if(hash(x,y,91)%1000>=plan.dissolve*1000)c.rect(x,y,5,5);c.clip();}

function ghast(c,q,tick){
 const death=minecraftBossDeathArtPlan('ghast',q);if((q.dead||q.state==='defeated')&&!death)return;if(death?.opacity<=0){paintBossDeath(c,death);return;}const w=q.w||48,h=q.h||48,charging=q.state==='charge',injured=(q.flash||0)>0&&Math.floor(q.flash/4)%2===0,blink=charging?Math.floor((q.charge||q.age||0)/4)%2:0;
 c.save();if(death)c.globalAlpha*=death.opacity;c.translate(Math.round(q.x),Math.round(q.y)-(death?.lift||0));c.scale(w/48,h/48);dissolveClip(c,death,{x:0,y:0,w:48,h:78});if(charging)glow(c,24,29,48,'#ff7c4d',.2);
 const p=injured?['#f4b4ad','#ffdfc8','#bb8586','#d59b98']:['#deded6','#f5f3e9','#a9afae','#c8cbc5'];
 // Three staggered rows of three tentacles beneath a full square cube.
 for(let row=0;row<3;row++)for(let col=0;col<3;col++){
  const i=row*3+col,x=2+col*15+row*5,y=44+row*2,len=15+hash(i,5)%12,sway=Math.round(Math.sin(tick*.055+i*.9)*2);
  rr(c,row===0?p[2]:p[3],x,y,4,len*.55);rr(c,p[0],x+1,y,2,len*.55);
  rr(c,p[2],x+sway,y+len*.5,4,len*.5);rr(c,row===2?p[1]:p[0],x+sway+1,y+len*.5,2,len*.5);
 }
 rr(c,p[2],0,0,48,48);rr(c,p[0],0,0,44,46);rr(c,p[1],0,0,44,4);rr(c,p[3],0,38,44,8);rr(c,p[2],44,3,4,45);
 for(const [x,y,ww,hh] of [[7,7,3,5],[32,6,5,2],[3,27,4,3],[35,32,3,5],[13,36,3,4],[22,8,4,2],[7,34,2,7]]){rr(c,p[3],x,y,ww,hh);rr(c,p[1],x+1,y+hh,Math.max(1,ww-1),2);}
 if(charging){for(const x of [9,28]){rr(c,'#4c3b3b',x,15,10,9);rr(c,blink?'#ffb584':'#d64b3b',x+1,17,8,5);rr(c,'#ffd7b1',x+2,17,2,2);}rr(c,'#8d6868',17,30,14,13);rr(c,'#302731',19,31,10,12);rr(c,blink?'#f28b52':'#ab4744',21,36,6,6);rr(c,'#f6b77d',22,39,4,3);}
 else{for(const x of [9,28]){rr(c,'#5b6262',x,17,10,3);rr(c,'#899593',x+1,20,2,10);rr(c,'#99a3a0',x+7,20,2,7);}rr(c,'#66716f',19,33,10,3);rr(c,'#8b9791',22,36,4,2);}
 if(!death&&(q.hp??2)<(q.maxHp??2)){for(let i=0;i<(q.maxHp||2);i++)rr(c,i<q.hp?'#df988b':'#55454c',19+i*7,-5,5,2);}
 c.restore();paintBossDeath(c,death);
}
function fireball(c,q,tick,dragon=false){const x=q.x,y=q.y,w=q.w||14,h=q.h||14,returned=q.state==='returned',p=dragon?['#3f1d5c','#8d45bb','#c985e1','#f2bef1']:returned?['#216377','#38b9c2','#9aeddf','#f4ffcd']:['#9e321d','#eb6a25','#ffb34b','#fff4af'];const vx=Number(q.vx)||1,vy=Number(q.vy)||0,length=Math.hypot(vx,vy)||1;glow(c,x+w/2,y+h/2,25,p[2],.21);for(let i=4;i>=1;i--){const s=Math.max(2,w*.65-i*1.1),tx=x+w/2-vx/length*i*4,ty=y+h/2-vy/length*i*4;rr(c,p[i%2],tx-s/2,ty-s/2,s,s);}rr(c,p[0],x+2,y,w-4,h);rr(c,p[0],x,y+2,w,h-4);rr(c,p[1],x+2,y+2,w-4,h-4);rr(c,p[2],x+4,y+3,w-7,h-6);rr(c,p[3],x+5,y+4,3,4);rr(c,p[3],x+4,y+6,5,2);if((tick+q.age)%4<2)rr(c,p[2],x-3,y+3,2,2);}
function magmaCube(c,q,tick){
 if(q.dead||q.state==='defeated')return;const w=q.w||24,h=q.h||24,squash=q.state==='squash',air=q.state==='airborne',base=q.y+h,gap=air?Math.min(3,1+Math.abs(q.vy||3)*.3):0;
 c.save();c.translate(Math.round(q.x+w/2),Math.round(base));c.scale(w/24,1);const width=squash?28:24,height=squash?16:h,left=-width/2,top=-height-gap*7,p=q.flash?['#a26348','#e4a56c','#783d32']:['#282021','#4b2925','#6d3629'];
 glow(c,0,top+height/2,27,'#ff8e28',.1);
 if(air){rr(c,'#a43e1c',left+4,top+2,width-8,height+gap*7-3);rr(c,'#f48b22',left+6,top+4,width-12,height+gap*7-6);rr(c,'#ffcb49',-3,top+5,5,height+gap*7-8);}
 for(let i=0;i<8;i++){const y=top+i*(height/8+gap),bh=Math.max(2,height/8);rr(c,p[0],left,y,width,bh);rr(c,p[1],left+1,y,width-3,Math.max(1,bh-1));rr(c,p[2],left+2,y,4,1);rr(c,'#1c191e',left+width-4,y,4,bh);if(i%2===1){rr(c,'#c25b26',left+4,y+bh-1,width-10,1);rr(c,'#e59131',left+7,y+bh-1,3,1);}}
 // Broad yellow eyes are recessed into the front two slabs, no round face.
 for(const x of [-8,3]){rr(c,'#180f16',x,top+4,6,7);rr(c,'#d36f1e',x+1,top+5,4,5);rr(c,'#ffcb38',x+1,top+5,3,4);rr(c,'#ffed86',x+1,top+5,2,1);}
 c.restore();
}
function crystal(c,q,tick){if(q.active===false)return;const x=q.x,y=q.y,w=q.w||20,h=q.h||20,cx=x+w/2,cy=y+h/2;glow(c,cx,cy,36,'#c68ee9',.18);const bob=Math.round(Math.sin(tick*.045+(q.x||0))*.8),a=[cx,y+bob],b=[x+w-2,cy+bob],d=[cx,y+h+bob],e=[x+2,cy+bob];poly(c,[a,b,d,e],'#b66ac6');poly(c,[a,[cx,cy+bob],e],'#f0b9e6');poly(c,[b,[cx,cy+bob],d],'#74448f');poly(c,[[cx,y+5+bob],[cx+5,cy+bob],[cx,y+h-5+bob],[cx-5,cy+bob]],'#f8e7f2');for(const [p,r] of [[a,b],[b,d],[d,e],[e,a]])pixelLine(c,...p,...r,'#e1aadf',1);rr(c,'#ffffff',cx-1,cy-3+bob,2,6);rr(c,'#d8c9db',x-2,y+h-1,w+4,3);rr(c,'#4f3c5e',x,y+h+2,w,2);rr(c,'#a785b0',x+2,y+h+2,w-4,1);}
function dragonWing(c,root,points,near=true){
 const [rx,ry]=root,p=[root,...points];poly(c,p,near?'#24212c':'#171722');poly(c,[root,points[0],points[1]],near?'#39303e':'#282331');poly(c,[root,points[1],points[2]],near?'#302832':'#1e1d29');
 pixelLine(c,rx,ry,...points[0],near?'#837b8b':'#595365',3);for(let i=0;i<points.length;i++)pixelLine(c,rx,ry,...points[i],near?'#665f72':'#413d51',2);for(let i=1;i<points.length;i++)pixelLine(c,...points[i-1],...points[i],near?'#50495c':'#332e41',1);rr(c,'#9d94a3',points[0][0]-1,points[0][1]-2,3,4);
}
/** Bilateral shoulders in body-local 3D, projected into the same oblique view
 * as the cuboid torso. Lateral span has opposite signs for the two wings;
 * it is not a second tailward silhouette translated a few screen pixels.
 * The near shoulder sits on the visible flank, the far shoulder behind the
 * dorsal edge. This plan is artwork only and never alters the hitboxes. */
export function dragonIdleArtPlan(q={},tick=0){
 const active=q.state==='perch'&&!q.defeated,sx=(q.body?.w||88)/88,sy=(q.body?.h||48)/48,f=q.facing===-1?-1:1;
 return {bodyLift:active?-Math.round((1+Math.sin(tick*.075))*.5)*sy:0,headShift:{x:active?Math.round(Math.sin(tick*.035))*f*sx:0,y:active?Math.round(Math.sin(tick*.06+1))*sy:0},wingSettle:active?Math.sin(tick*.075)*1.6:0};
}
export function dragonWingArtPlan(q={},tick=0){
 if(!q.body)return {wings:[],paintOrder:['far-wing','torso','near-wing']};const idle=dragonIdleArtPlan(q,tick),b={...q.body,y:q.body.y+idle.bodyLift};
 const f=q.facing===-1?-1:1,cx=b.x+b.w/2,cy=b.y+b.h/2,sx=b.w/88,sy=b.h/48;
 const folded=q.wingPose==='folded'||q.legPose==='perched'||['perch','recovery'].includes(q.state),brake=q.wingPose==='brake'||q.legPose==='landing'||q.state==='landing',dive=['swoop','charge','telegraph-charge','telegraph-swoop'].includes(q.state);
 const rise=folded?32:brake?53:dive?37:65+Math.sin(tick*.11)*16;
 // A restrained bank follows the controller's existing flight tilt, without
 // rotating or displacing its collision-owned torso, neck or head.
 const bank=clamp((q.flightTilt||0)*f,-.3,.3),span=folded?.43:dive?.86:1;
 const settle=idle.wingSettle,joints=folded?[[15,-34+settle,28],[-38,-27+settle*1.4,47],[-32,2+settle*.6,32],[-8,8,16]]:[[-4,-rise,48*span],[-2,-rise+12,112*span],[-15,-8,80*span],[-21,7,34*span]];
 const wings=[true,false].map(far=>{
  const side=far?-1:1,project=([along,lift,lateral])=>[cx+f*(along-.88*lateral*side)*sx,cy+(lift+.29*lateral*side+bank*lateral*side)*sy];
  return {far,side,root:project([14,-10,10]),points:joints.map(project),localRoot:[14,-10,side*10],localPoints:joints.map(([x,y,z])=>[x,y,z*side])};
 });
 return {wings,folded,brake,dive,bank,paintOrder:['far-wing','torso','near-wing']};
}
/** Fixed anatomy-local limb joints. No floor coordinate can lengthen a leg. */
export function dragonAnatomy(q={}){
 const b=q.body;if(!b)return {legs:[],deployment:0};const f=q.facing===-1?-1:1,cx=b.x+b.w/2,sx=b.w/88,sy=b.h/48;
 const folded=q.legPose==='perched'||q.wingPose==='folded'||['perch','recovery'].includes(q.state),brake=q.legPose==='landing'||q.wingPose==='brake'||q.state==='landing',deployment=Number.isFinite(q.legExtension)?clamp(q.legExtension,0,1):folded?1:brake?.72:q.legPose==='tucked'?0:q.state==='hurt'?1:0;
 const legs=[];for(const far of [true,false])for(const front of [false,true]){
  const anchor=cx+f*(front?25:-25)*sx+(far?f*4:0),hipY=b.y+b.h-9*sy+(far?-2:0),extra=front?20:36;
  const knee={x:anchor-f*(front?7:11)*sx,y:hipY+(4+deployment*(front?7:20))*sy};
  const foot={x:anchor+f*(front?2:-2)*sx,y:b.y+b.h+(4+deployment*(extra-4))*sy};
  legs.push({far,front,hip:{x:anchor,y:hipY},knee,foot,width:(far?4:6)*sx});
 }return {legs,deployment};
}
function dragonLeg(c,leg,f){
 const {hip,knee,foot,width,far}=leg;pixelLine(c,hip.x,hip.y,knee.x,knee.y,far?'#1c1b27':'#38323f',width+1);pixelLine(c,knee.x,knee.y,foot.x-f*4,foot.y-2,far?'#161622':'#211f2c',width);
 rr(c,far?'#292532':'#3a3440',foot.x-5,foot.y-3,11,3);for(let i=0;i<3;i++)rr(c,far?'#6e6576':'#a299a5',foot.x-4+i*3,foot.y-2,2,2);
}
function dragon(c,q,tick,room={}){
 if(!q.body||!q.head)return;const idle=dragonIdleArtPlan(q,tick),b={...q.body,y:q.body.y+idle.bodyLift},h={...q.head,x:q.head.x+idle.headShift.x,y:q.head.y+idle.headShift.y},f=q.facing===-1?-1:1,cx=b.x+b.w/2,cy=b.y+b.h/2,age=q.stateAge||0,defeat=q.state==='defeated'||q.defeated,anatomy=dragonAnatomy(q),perch=anatomy.deployment>.7,swoop=['swoop','charge','telegraph-charge','telegraph-swoop'].includes(q.state),breath=['breath','telegraph-breath'].includes(q.state),death=minecraftBossDeathArtPlan('dragon',q,room),alpha=death?death.opacity:1;if(alpha<=0){paintBossDeath(c,death);return;}
 c.save();c.globalAlpha*=alpha;c.translate(0,-(death?.lift||0));dissolveClip(c,death,{x:Math.min(b.x,h.x)-150,y:Math.min(b.y,h.y)-120,w:b.w+h.w+320,h:260});if(q.state==='hurt'&&Math.floor(age/4)%2===0)c.globalAlpha*=.5;
 const wings=dragonWingArtPlan(q,tick).wings,farWing=wings.find(w=>w.far),nearWing=wings.find(w=>!w.far);
 dragonWing(c,farWing.root,farWing.points,false);
 const tailRoot=[cx-35*f,cy+6];let prev=tailRoot;for(let i=0;i<8;i++){
  const next=[tailRoot[0]-f*(i+1)*12,tailRoot[1]+Math.sin(tick*.06-i*.5)*(perch?2:5)+(swoop?-i*2:i)],width=11-i;
  pixelLine(c,...prev,...next,'#10111a',width+2);pixelLine(c,...prev,...next,'#292530',width);pixelLine(c,prev[0],prev[1]-width/2,next[0],next[1]-width/2,'#5c5366',1);if(i<6)rr(c,'#867b90',next[0]-2,next[1]-width/2-4,4,5);prev=next;
 }
 for(const leg of anatomy.legs.filter(p=>p.far))dragonLeg(c,leg,f);
 // Long black cuboid torso, subtle underside plates and pale dorsal spines.
 rr(c,'#11111b',b.x,b.y+8,b.w,b.h-13);rr(c,'#1b1924',b.x+4,b.y+3,b.w-8,b.h-11);rr(c,'#332c3a',b.x+7,b.y+1,b.w-17,5);rr(c,'#5b5264',b.x+9,b.y+1,b.w-21,1);rr(c,'#272230',b.x+5,b.y+b.h-14,b.w-10,8);
 for(let i=0;i<5;i++){const x=b.x+12+i*(b.w-26)/5;rr(c,'#403848',x,b.y+b.h-13,4,6);rr(c,'#746a80',x,b.y-5,5,8);rr(c,'#978b9f',x,b.y-5,2,6);}
 // The far root is hidden by the torso; the near root crosses its visible
 // flank and owns that overlap. Forelegs and the neck remain in front.
 dragonWing(c,nearWing.root,nearWing.points,true);
 for(const leg of anatomy.legs.filter(p=>!p.far))dragonLeg(c,leg,f);
 const neckX=f>0?b.x+b.w-6:b.x+6,neckY=cy-5,headBack=f>0?h.x+5:h.x+h.w-5,endY=h.y+h.h/2;
 for(let i=0;i<4;i++){const t=i/4,t2=(i+1)/4,x=neckX+(headBack-neckX)*t,y=neckY+(endY-neckY)*t,x2=neckX+(headBack-neckX)*t2,y2=neckY+(endY-neckY)*t2;pixelLine(c,x,y,x2,y2,'#11121b',19);pixelLine(c,x,y-1,x2,y2-1,'#302936',13);pixelLine(c,x,y-7,x2,y2-7,'#5b5064',2);rr(c,'#8b7f96',x-2,y-12,4,6);}
 c.save();c.translate(f>0?h.x:h.x+h.w,h.y);c.scale(f,1);const hw=h.w||40,hh=h.h||24;
 rr(c,'#10111a',1,0,hw-4,hh-1);rr(c,'#292332',1,1,22,hh-3);rr(c,'#403647',2,1,19,3);rr(c,'#5e516a',3,1,16,1);rr(c,'#1a1924',19,8,hw-19,13);rr(c,'#383040',20,8,hw-21,2);rr(c,'#10111b',20,hh-5,hw-19,6);
 // Horns are rectangular and fixed to the skull, not decorative floating fins.
 rr(c,'#8d8196',7,-8,4,11);rr(c,'#c1b5c4',7,-8,2,9);rr(c,'#695e78',17,-6,3,8);rr(c,'#a89bad',17,-6,1,6);
 rr(c,'#763791',12,6,11,5);rr(c,'#c675e2',13,7,10,3);rr(c,'#eeb1f8',14,7,6,1);rr(c,'#fbe3ff',15,7,2,2);rr(c,'#6d597b',hw-7,11,3,2);rr(c,'#554660',hw-3,11,2,2);
 if(breath){rr(c,'#070b15',23,hh-5,hw-23,8);rr(c,'#9143b0',25,hh-2,hw-25,5);rr(c,'#e2a0ec',hw-6,hh-1,4,4);for(const xx of [25,31,37])rr(c,'#b8abbf',xx,hh-5,2,2);}else{rr(c,'#090d17',23,hh-3,hw-23,1);rr(c,'#a89bad',hw-8,hh-2,3,2);}
 if(q.headOpen&&!defeat){const pulse=Math.floor(tick/12)%2;rr(c,pulse?'#f5d8a0':'#d7b6dc',1,-2,7,1);rr(c,pulse?'#f5d8a0':'#d7b6dc',hw-8,-2,6,1);rr(c,'#ead2ec',1,-1,1,4);rr(c,'#ead2ec',hw-3,-1,1,4);rr(c,'#f7e3ae',4,-3,2,1);}c.restore();
 // Cyan corner glints mark the controller's real airborne ranged window.
 // Perch openings keep their existing warm cue and anatomy-local limbs.
 if(q.rangedOpen&&!defeat){const hx=h.x-3,hy=h.y-4,hw=h.w+6,hh=h.h+8;for(const [xx,yy,dx,dy]of [[hx,hy,1,1],[hx+hw,hy,-1,1],[hx,hy+hh,1,-1],[hx+hw,hy+hh,-1,-1]]){rr(c,'#a5dbe5',xx+(dx<0?-4:0),yy,5,1);rr(c,'#77b8db',xx,yy+(dy<0?-3:0),1,4);}if(tick%20<10)rr(c,'#d3ecf6',h.x+h.w/2-1,h.y-8,2,2);}
 if(q.healingActive&&!defeat)for(let i=0;i<4;i++){const angle=tick*.025+i*Math.PI/2;rr(c,i%2?'#8e58a6':'#c58fdb',cx+Math.cos(angle)*49,cy+Math.sin(angle)*24,2,2);}
 c.restore();paintBossDeath(c,death);
}
function telegraph(c,t,tick){if(!t)return;const x=t.x,y=t.y,w=t.w||64,h=t.h||20,color=t.kind==='breath'?'#b96ae0':'#e7a9dd';c.save();c.globalAlpha=.13;rr(c,color,x,y,w,h);c.globalAlpha=.65;for(let xx=x;xx<x+w;xx+=12){rr(c,color,xx,y,Math.min(6,x+w-xx),1);rr(c,color,xx,y+h-1,Math.min(6,x+w-xx),1);}for(let yy=y;yy<y+h;yy+=10){rr(c,color,x,yy,1,5);rr(c,color,x+w-1,yy,1,5);}if(t.kind==='swoop'||t.kind==='charge')for(let xx=x+9;xx<x+w-8;xx+=28){const bob=(Math.floor(tick/6)%2);pixelLine(c,xx,y+h/2-4,xx+5+bob,y+h/2,color,1);pixelLine(c,xx+5+bob,y+h/2,xx,y+h/2+4,color,1);}
 if(t.kind==='strafe'){
  // The warning spans the visible arena even while the attacker is offscreen.
  // Tick-based energy keeps a fair, stationary warning visibly alive; no
  // attack age, camera, collision or warning duration is altered.
  c.globalAlpha=.32+.16*Math.sin(tick*.16);rr(c,'#c699e4',x,y,w,1);rr(c,'#c699e4',x,y+h-1,w,1);
  c.globalAlpha=.6;for(let i=0;i<Math.ceil(w/56);i++){const drift=(i*56+tick*1.8)%Math.max(1,w-8);rr(c,'#9a6cbd',x+drift,y+3,6,1);rr(c,'#d0a4ec',x+drift+4,y+2,2,2);rr(c,'#9a6cbd',x+w-drift-7,y+h-5,6,1);rr(c,'#d0a4ec',x+w-drift-7,y+h-5,2,2);}
 }
 c.restore();}
function dragonSafeLanes(c,lanes,tick){
 for(const lane of lanes||[]){const x=lane.x,y=lane.y,w=lane.w,h=lane.h;c.save();c.globalAlpha*=.55;for(let i=0;i<2;i++){const xx=i?x+w-2:x;rr(c,'#80baaa',xx,y+h-7,2,7);rr(c,'#80baaa',i?xx-5:xx,y+h-1,7,1);}if(tick%32<18){rr(c,'#b1d9ba',x+w/2-3,y+h-3,6,1);rr(c,'#b1d9ba',x+w/2-1,y+h-5,2,3);}c.restore();}
}
/** The purple carpet is the exact active collision footprint. The low curling
 * pixels are mist, never a hidden tall hitbox; warning and expiry stay legible. */
export function minecraftBreathCloudArtPlan(q={},tick=0){
 const x=q.x||0,y=q.y||0,w=q.w||0,h=q.h||10,warning=(q.warning||0)>0,fade=clamp((q.life??60)/36,0,1),phase=(q.age??tick),motes=[];
 for(let i=0;i<Math.ceil(w/4);i++){const rise=(phase+i*11)%42;motes.push({x:x+1+hash(i,x)%Math.max(1,Math.floor(w-3)),y:y+h-2-rise*.42,size:1+i%2,alpha:(1-rise/48)*fade,color:i%3?'#bf69de':'#f0b4ff'});}
 return {x,y,w,h,warning,fade,pulse:.66+Math.sin(phase*Math.PI/18)*.12,motes};
}
function breathCloud(c,q,tick){
 const p=minecraftBreathCloudArtPlan(q,tick),{x,y,w,h,warning,fade}=p;c.save();const alpha=c.globalAlpha;
 // Both warning and active state have a grounded rim; no circular aerial glow
 // suggests a cloud on an unsupported platform or hides a neighbouring ledge.
 c.globalAlpha=alpha*fade*(warning?.35:.66);rr(c,'#54206d',x,y+h-3,w,3);
 c.globalAlpha=alpha*fade;if(warning){for(let xx=x+1;xx<x+w-1;xx+=6)rr(c,'#dda0f0',xx,y+h-2,Math.min(3,x+w-xx),1);}
 else{c.globalAlpha=alpha*fade*p.pulse;rr(c,'#8f3bb7',x,y+3,w,h-3);rr(c,'#b453cd',x+1,y+h-4,Math.max(0,w-2),2);
  for(let i=0;i<Math.ceil(w/8);i++){const xx=x+i*8,ww=Math.min(8,x+w-xx),rise=2+Math.round(Math.sin((q.age||0)*.085+i*1.7)*2);rr(c,i%2?'#aa4ac6':'#763098',xx,y+rise,ww,Math.max(1,h-rise-3));}
  c.globalAlpha=alpha*fade;rr(c,'#df8af2',x,y+h-1,w,1);rr(c,'#f0b6ff',x,y+h-3,1,3);rr(c,'#f0b6ff',x+w-1,y+h-3,1,3);
 }
 for(const m of p.motes){c.globalAlpha=alpha*m.alpha*(warning?.35:1);rr(c,m.color,m.x,m.y,m.size,m.size);}c.restore();
}
function finaleEffect(c,q){const t=clamp((q.age||0)/(q.duration||q.life||30),0,1),x=q.x+(q.w||0)/2,y=q.y+(q.h||0)/2;if(t>=1)return;
 if(q.stationary){c.save();const alpha=c.globalAlpha;c.globalAlpha=alpha*(1-t);const purple=q.kind!=='ghast-death-ring',color=q.color||(purple?'#dfa0ff':'#ffe2bd'),radius=(q.kind==='dragon-shield-collapse'?42:7)+t*(q.kind==='end-portal-bloom'?54:64);glow(c,x,y,18+radius*.6,color,.18*(1-t));pixelRing(c,x,y,radius,color,2,q.kind==='end-portal-bloom'?.36:1);if(t<.45)pixelRing(c,x,y,radius*.6,purple?'#f8dcff':'#fff2db',1);
  if(q.kind==='crystal-collapse'||q.kind==='dragon-egg-trail'){for(let i=0;i<8;i++){const a=i*Math.PI/4,reach=12+t*48;pixelLine(c,x+Math.cos(a)*reach*.55,y+Math.sin(a)*reach*.55,x+Math.cos(a)*reach,y+Math.sin(a)*reach,i%2?'#b064df':'#f2caff',2);}for(let i=0;i<7;i++){const k=clamp((q.age-i*3)/30,0,1);if(k<=0||k>=1)continue;const px=x+(q.targetX-x)*k,py=y+(q.targetY-y)*k-Math.sin(k*Math.PI)*18;c.globalAlpha=alpha*Math.sin(k*Math.PI)*(1-t*.5);pixelLine(c,px-3,py+2,px+3,py-2,'#a856d5',3);rr(c,'#f2cfff',px,py,3,3);}}
  c.restore();return;
 }const kind=q.kind||'',purple=/dragon|crystal|breath/.test(kind);c.save();c.globalAlpha*=1-t;for(let i=0;i<(/defeat/.test(kind)?28:8);i++){const angle=i*2.399,dist=(4+t*25)*(1+(i%3)*.3),px=x+Math.sin(angle)*dist+(q.vx||0)*(q.age||0),py=y+Math.cos(angle)*dist-t*14+(q.vy||0)*(q.age||0);rr(c,q.color||(purple?['#d59ae4','#f2c6f0','#74618e'][i%3]:['#e7954c','#ae6650','#51434a'][i%3]),px,py,1+i%3,1+i%3);}c.restore();}
function dragonEgg(c,q,tick){if(!q?.active)return;const x=q.x,y=q.y;glow(c,x+8,y+10,24,'#a864ce',.13);for(const [dy,inset,w] of [[0,6,4],[2,4,8],[5,2,12],[9,1,14],[14,0,16],[18,2,12]]){rr(c,'#160f20',x+inset,y+dy,w,dy===18?2:4);rr(c,'#413149',x+inset,y+dy,Math.max(2,w-4),1);}for(const [dx,dy]of [[5,4],[10,8],[3,12],[9,16]]){rr(c,'#704b85',x+dx,y+dy,3,2);rr(c,'#aa73c4',x+dx,y+dy,1,1);}if(!q.teleported&&tick%48<18)rr(c,'#d7a8ed',x+7,y-3,2,1);}
function paintFinaleWorld(c,room={},view=room.minecraftView){if(!isFinale(room))return false;const state=stateOf(room,view),nether=state.nether,dr=state.dragon,tick=tickOf(room);c.save();workshopWorld(c,room,state,tick);if(nether){for(const q of nether.ghasts||[])ghast(c,q,tick);for(const q of nether.magmaCubes||[])magmaCube(c,q,tick);for(const q of nether.fireballs||[])fireball(c,q,tick);if(nether.bastion?.reward){const r=nether.bastion.reward;chest(c,r,!!r.opened||r.taken);bastionTrident(c,minecraftBastionRewardArtPlan(r).item);if(nether.bastion.opened&&!r.opened&&!r.taken)sparks(c,r.x+8,r.y+4,tick,'#eed18c',4,20);}for(const q of nether.effects||[])finaleEffect(c,q);}else if(room.minecraft.nether){for(const q of room.minecraft.nether.ghasts||[])ghast(c,{w:48,h:48,...q,state:'idle'},tick);for(const q of room.minecraft.nether.magmaCubes||[])magmaCube(c,{w:24,h:24,...q,state:'idle'},tick);if(room.minecraft.nether.bastion?.reward)chest(c,room.minecraft.nether.bastion.reward);}
 if(dr){telegraph(c,dr.telegraph,tick);dragonSafeLanes(c,dr.safeLanes||dr.telegraph?.safeLanes,tick);for(const q of dr.pools||[])breathCloud(c,q,tick);for(const q of dr.crystals||[])crystal(c,q,tick);if((dr.healingActive||dr.shielded)&&dr.body)for(const q of dr.crystals||[]){if(q.active===false)continue;const bx=dr.body.x+dr.body.w/2,by=dr.body.y+dr.body.h/2;c.save();c.globalAlpha=.12;pixelLine(c,q.x+q.w/2,q.y+q.h/2,bx,by,'#bf7cdd',3);c.globalAlpha=.28;for(let i=0;i<6;i++){const t=((tick*.01+i/6)%1);rr(c,'#e0b8ed',q.x+q.w/2+(bx-q.x-q.w/2)*t,q.y+q.h/2+(by-q.y-q.h/2)*t,2,2);}c.restore();}dragon(c,dr,tick,room);dragonEgg(c,dr.egg,tick);for(const q of dr.projectiles||[])fireball(c,q,tick,true);for(const q of dr.effects||[])finaleEffect(c,q);if(dr.exitUnlocked){const exit=room.map?.objects?.find(q=>q.id===room.minecraft.dragon?.exitPortalId);if(exit){const base=groundAt(room,exit.x+exit.w/2,exit.y)??exit.y+exit.h;if(!(room.minecraft.scenery||[]).some(q=>q.kind==='end-portal'))bedrockExit(c,room,{x:exit.x-24,y:base,w:72,h:24},tick,true);sparks(c,exit.x+exit.w/2,base-16,tick,'#dbc2f0',8,48);}}}else if(room.minecraft.dragon){for(const id of room.minecraft.dragon.crystalIds||[]){const q=geometry(room).find(q=>q.id===id);if(q)crystal(c,{...q,active:true},tick);}}
 c.restore();return true;}

// Some Canvas backends restore the paint itself but not the fillStyle getter.
// Preserve it explicitly so native and browser renderers share the same contract.
function withFill(c,paint,args){const fill=c.fillStyle;try{return paint(c,...args);}finally{c.fillStyle=fill;}}
export function drawFinaleTile(c,...args){return withFill(c,paintFinaleTile,args);}
export function drawFinaleBackground(c,...args){return withFill(c,paintFinaleBackground,args);}
export function drawFinaleScenery(c,...args){return withFill(c,paintFinaleScenery,args);}
export function drawFinaleWorld(c,...args){return withFill(c,paintFinaleWorld,args);}
