import {clone,validate} from './editor-model.mjs';
import {validateSwitchStudyRoom} from './editor-switch.mjs';

/** Authoring only. These records use the existing native preview contracts. */
const uid=prefix=>prefix+'-'+globalThis.crypto.randomUUID();
const isScale=m=>m.kind==='coupled-scale'&&m.source?.macro==='Scale';
const scaleOwner=(room,id)=>room.markers.find(m=>isScale(m)&&(id===m.id+'-left'||id===m.id+'-right'));
const ids=room=>new Set([...room.map.geometry,...room.map.objects,...room.markers,...(room.switchStudy?.devices||[])].map(q=>q.id));
function rect(room,q){
 if(!['x','y','w','h'].every(k=>Number.isFinite(q[k]))||q.x<0||q.y<0||q.w<=0||q.h<=0||q.x+q.w>room.map.width||q.y+q.h>room.map.height)throw Error('位置或尺寸超出房间');
}
function editRoom(room,edit){
 const draft=clone(room);edit(draft);validateSwitchStudyRoom(draft);
 validate({format:'xiaoq-map-project',version:1,id:'study-tools-check',title:'Study tools',rooms:[draft]},{allowIncompleteCompletionMarks:true});
 for(const key of Object.keys(room))if(!Object.hasOwn(draft,key))delete room[key];Object.assign(room,draft);
}
export function setStudyEnabled(room,enabled){
 editRoom(room,r=>{if(enabled){if(r.mechanics!==undefined||r.devices?.length)throw Error('回声合作与 ON/OFF 不能同时启用，请先关闭回声');r.switchStudy??={version:1,initialOn:true,allowBacktracking:true,devices:[]};}else delete r.switchStudy;});
}
export function setStudyOptions(room,options){
 editRoom(room,r=>{if(!r.switchStudy)throw Error('请先启用 ON/OFF');for(const key of ['initialOn','allowBacktracking'])if(Object.hasOwn(options,key))r.switchStudy[key]=options[key];});
}
export function addStudyDevice(room,kind,position={}){
 if(!['switch','red','blue'].includes(kind))throw Error('请选择开关、红块或蓝块');const id=uid('study-'+kind);
 editRoom(room,r=>{if(!r.switchStudy)throw Error('请先启用 ON/OFF');r.switchStudy.devices.push({id,kind:kind==='switch'?'switch':'block',...(kind==='switch'?{}:{color:kind}),x:position.x??Math.min(64,r.map.width-16),y:position.y??Math.max(0,r.map.height-96),w:position.w??16,h:position.h??16});});return id;
}
export function updateStudyDevice(room,id,position){editRoom(room,r=>{const q=r.switchStudy?.devices.find(q=>q.id===id);if(!q)throw Error('请先选择 ON/OFF 元素');for(const key of ['x','y','w','h'])q[key]=position[key];});}
export function removeStudyDevice(room,id){editRoom(room,r=>{if(!r.switchStudy?.devices.some(q=>q.id===id))throw Error('请先选择 ON/OFF 元素');r.switchStudy.devices=r.switchStudy.devices.filter(q=>q.id!==id);});}

/** Matches stage-catalog motion bounds, including start position and extent. */
export function validateStudyMotion(room,q,motion){
 rect(room,q);if(!['solid','oneway'].includes(q.collision))throw Error('平台需要实心或单向碰撞');if(!motion)return;
 const {axis,min,max,speed}=motion,extent=axis==='x'?q.w:q.h,limit=axis==='x'?room.map.width:room.map.height;
 if(Object.keys(motion).some(k=>!['axis','min','max','speed'].includes(k))||!['x','y'].includes(axis)||![min,max,speed].every(Number.isFinite)||min<0||min>32768||max<min+1||max>32768||speed<.01||speed>2||q[axis]<min||q[axis]>max||max+extent>limit)throw Error('运动范围须包含当前坐标且留在房间内，速度为 0.01–2');
}
export function updateStudyPlatform(room,id,position,motion){
 editRoom(room,r=>{const q=r.map.geometry.find(q=>q.id===id);if(!q)throw Error('请先选择地形平台');if(scaleOwner(r,id))throw Error('天平平台必须在天平面板中成对调整');const next={...q,...position};validateStudyMotion(r,next,motion);Object.assign(q,next);if(motion)q.motion={...motion};else delete q.motion;});
}
export function addStudyPlatform(room,position={},motion){
 const id=uid('study-platform');editRoom(room,r=>{const q={id,x:position.x??64,y:position.y??Math.max(0,r.map.height-96),w:position.w??48,h:position.h??8,collision:position.collision??'oneway',material:'platform'};validateStudyMotion(r,q,motion);if(motion)q.motion={...motion};r.map.geometry.push(q);});return id;
}

export function studyScale(room,id){
 const marker=room.markers.find(m=>m.id===id&&isScale(m));if(!marker)return null;
 const left=room.map.geometry.find(q=>q.id===id+'-left'),right=room.map.geometry.find(q=>q.id===id+'-right');if(!left||!right)return {id,broken:true};
 return {id,leftX:left.x,leftY:left.y,rightX:right.x,rightY:right.y,width:left.w,rightWidth:right.w,anchorY:marker.y};
}
export function upsertStudyScale(room,id,values){
 const key=id||uid('study-scale');editRoom(room,r=>{
  const existing=r.markers.find(m=>m.id===key&&isScale(m));if(id&&!existing)throw Error('所选天平不存在');
  const {leftX,leftY,rightX,rightY,width,anchorY}=values;
  if(![leftX,leftY,rightX,rightY,width,anchorY].every(Number.isFinite)||width<16||(values.rightWidth??width)<16||anchorY<0||anchorY>=Math.min(leftY,rightY)||rightX<leftX+width)throw Error('天平须左右分开，宽度至少 16，绳顶位于房间内且高于两块平台');
  const left={id:key+'-left',x:leftX,y:leftY,w:width,h:8,collision:'oneway',material:'platform'},right={id:key+'-right',x:rightX,y:rightY,w:values.rightWidth??width,h:8,collision:'oneway',material:'platform'};rect(r,left);rect(r,right);
  const used=ids(r);for(const q of [left,right])if(used.has(q.id)&&(!existing||!r.map.geometry.some(g=>g.id===q.id)))throw Error('天平平台标识已被使用');if(!existing&&used.has(key))throw Error('天平标识已被使用');
  const pair=new Set([left.id,right.id]);r.map.geometry=r.map.geometry.filter(q=>!pair.has(q.id));r.map.geometry.push(left,right);
  const leftCenter=left.x+left.w/2,rightCenter=right.x+right.w/2;
  const marker={...(existing||{}),id:key,kind:'coupled-scale',x:leftCenter,y:anchorY,source:{...(existing?.source||{}),macro:'Scale',between:(rightCenter-leftCenter)/2,dropLeft:(left.y-anchorY)/2,dropRight:(right.y-anchorY)/2}};
  r.markers=r.markers.filter(m=>m.id!==key);r.markers.push(marker);
  r.semantics=(r.semantics||[]).filter(s=>!pair.has(s.id));for(const q of [left,right])r.semantics.push({id:q.id,kind:'ScalePlatform',source:{},referenceRect:{x:q.x,y:q.y,w:q.w,h:q.h}});
 });return key;
}
export function removeStudyScale(room,id){
 editRoom(room,r=>{if(!r.markers.some(m=>m.id===id&&isScale(m)))throw Error('请先选择天平');const pair=new Set([id+'-left',id+'-right']);r.markers=r.markers.filter(m=>m.id!==id);r.map.geometry=r.map.geometry.filter(q=>!pair.has(q.id));if(r.semantics)r.semantics=r.semantics.filter(s=>!pair.has(s.id));});
}

const overlap=(a,b)=>a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y;
const staticSupports=room=>room.map.geometry.filter(q=>!q.hidden&&!q.motion&&!q.liftSpeed&&!scaleOwner(room,q.id)&&['solid','oneway'].includes(q.collision));
export function checkpointSupports(room){return staticSupports(room).filter(q=>q.y>=48&&q.w>=16);}
const checkpointHasBase=(room,id)=>room.checkpointVisuals?.[id]?.version===1&&room.checkpointVisuals[id].base===true;
function validateCheckpoint(room,q,surfaceY){
 rect(room,q);if(q.w!==16||q.h!==48||q.y!==surfaceY-(checkpointHasBase(room,q.id)?48:32)||!checkpointSupports(room).some(g=>g.y===surfaceY&&q.x>=g.x&&q.x+q.w<=g.x+g.w))throw Error('检查点须落在静止支撑面，宽 16、高 48');
 const spawn=room.map.objects.find(o=>o.id===q.targetSpawn&&o.kind==='spawn');if(!spawn)throw Error('请选择本房间有效出生点');
 const body={x:spawn.x,y:spawn.y,w:10,h:14};rect(room,body);
 const blocks=(room.switchStudy?.devices||[]).filter(d=>d.kind==='switch'||(d.color==='red')===room.switchStudy.initialOn);
 if([...room.map.geometry.filter(g=>!g.hidden&&g.collision==='solid'),...blocks].some(g=>overlap(body,g))||room.map.objects.some(o=>['hazard','walker'].includes(o.kind)&&overlap(body,o)))throw Error('目标出生点被地形或危险物占用');
 if(!staticSupports(room).some(g=>Math.abs(body.y+body.h-g.y)<=1.01&&body.x>=g.x&&body.x+body.w<=g.x+g.w))throw Error('目标出生点必须站在稳定支撑面');
}
export function addStudyCheckpoint(room,{supportId,targetSpawn,x}={}){
 const id=uid('study-checkpoint');editRoom(room,r=>{const support=checkpointSupports(r).find(q=>q.id===supportId)||(!supportId?checkpointSupports(r)[0]:null);if(!support)throw Error('请先选择静止支撑面');const q={id,kind:'checkpoint',x:x??support.x+Math.min(32,support.w-16),y:support.y-48,w:16,h:48,targetSpawn:targetSpawn??r.map.objects.find(o=>o.kind==='spawn')?.id};r.checkpointVisuals??={};r.checkpointVisuals[id]={version:1,base:true};validateCheckpoint(r,q,support.y);r.map.objects.push(q);});return id;
}
export function updateStudyCheckpoint(room,id,{x,surfaceY,targetSpawn}){editRoom(room,r=>{const q=r.map.objects.find(q=>q.id===id&&q.kind==='checkpoint');if(!q)throw Error('请先选择检查点');const next={...q,x,y:surfaceY-(checkpointHasBase(r,id)?48:32),w:16,h:48,targetSpawn};validateCheckpoint(r,next,surfaceY);Object.assign(q,next);});}
export function removeStudyCheckpoint(room,id){editRoom(room,r=>{if(!r.map.objects.some(q=>q.id===id&&q.kind==='checkpoint'))throw Error('请先选择检查点');r.map.objects=r.map.objects.filter(q=>q.id!==id);if(r.checkpointVisuals){delete r.checkpointVisuals[id];if(!Object.keys(r.checkpointVisuals).length)delete r.checkpointVisuals;}});}

export function mountStudyTools({parent,room,selected=()=>new Set(),change,report=()=>{}}){
 const panel=document.createElement('section');panel.id='study-tools';parent.append(panel);const controls=new Map();let deviceId='',platformId='',scaleId='',checkpointId='',lastRoom=null;
 function node(tag,text,parentNode=panel){const n=document.createElement(tag);if(text)n.textContent=text;parentNode.append(n);return n;}
 function field(key,label,{type='number',value='',options,container=panel}={}){const l=node('label',label,container),n=document.createElement(options?'select':'input');n.setAttribute('data-study-control',key);if(!options){n.type=type;n.value=value;if(type==='number')n.step='any';}else fill(n,options,value);l.append(n);controls.set(key,n);return n;}
 function fill(n,options,value){n.replaceChildren(...options.map(([v,t])=>{const o=document.createElement('option');o.value=v;o.textContent=t;return o;}));n.value=value;}
 function button(key,text,fn,container=panel){const b=node('button',text,container);b.type='button';b.setAttribute('data-study-control',key);b.onclick=fn;controls.set(key,b);return b;}
 const get=key=>controls.get(key),number=key=>{const text=get(key).value;if(String(text).trim()==='')throw Error('请填写全部位置和参数');return Number(text);};
 const attempt=fn=>{try{change(fn);refresh();}catch(e){report(e.message);refresh();}};
 const position=prefix=>Object.fromEntries(['x','y','w','h'].map(k=>[k,number(prefix+'-'+k)]));
 const motion=()=>get('platform-moving').checked?{axis:get('platform-axis').value,min:number('platform-min'),max:number('platform-max'),speed:number('platform-speed')}:null;
 node('h2','基础机关工具');node('p','这些工具保存为原生工程记录；撤销、导入和离线试玩保留相同机制。').className='small';
 const enabled=field('switch-enabled','启用本房间 ON/OFF',{type:'checkbox'}),switchBody=node('div');
 const initial=field('switch-initial','初始状态 ON',{type:'checkbox',container:switchBody}),backtrack=field('switch-backtrack','允许往左回看',{type:'checkbox',container:switchBody});
 field('switch-select','ON/OFF 元素',{options:[],container:switchBody});for(const [kind,label]of [['switch','+ 开关'],['red','+ 红块'],['blue','+ 蓝块']])button('switch-add-'+kind,label,()=>attempt(()=>{deviceId=addStudyDevice(room(),kind);}),switchBody);
 const switchForm=node('form','',switchBody);for(const k of ['x','y','w','h'])field('switch-'+k,{x:'X',y:'Y',w:'宽',h:'高'}[k],{container:switchForm});
 const switchApply=node('button','应用 ON/OFF 元素',switchForm);switchApply.type='submit';switchApply.setAttribute('data-study-control','switch-apply');button('switch-remove','删除元素',()=>attempt(()=>{removeStudyDevice(room(),deviceId);deviceId='';}),switchForm);
 switchForm.onsubmit=e=>{e.preventDefault();attempt(()=>updateStudyDevice(room(),deviceId,position('switch')));};enabled.onchange=()=>attempt(()=>setStudyEnabled(room(),enabled.checked));initial.onchange=()=>attempt(()=>setStudyOptions(room(),{initialOn:initial.checked}));backtrack.onchange=()=>attempt(()=>setStudyOptions(room(),{allowBacktracking:backtrack.checked}));get('switch-select').onchange=()=>{deviceId=get('switch-select').value;refresh();};
 node('p','红块在 ON 实心，蓝块在 OFF 实心；开关始终实心。开关固定 16×16，色块宽高为整格。关闭本机制会移除本房间机关，撤销可恢复。').className='small';

 node('h3','移动平台');field('platform-select','地形 / 平台',{options:[]});button('platform-use-selection','使用画布所选地形',()=>{try{const set=typeof selected==='function'?selected():selected,list=room().map.geometry.filter(q=>set?.has(q.id));if(list.length!==1)throw Error('请在地形图层只选一个平台');platformId=list[0].id;refresh();}catch(e){report(e.message);}});
 button('platform-add','+ 单向平台',()=>attempt(()=>{platformId=addStudyPlatform(room());}));const platformForm=node('form');for(const k of ['x','y','w','h'])field('platform-'+k,{x:'X',y:'Y',w:'宽',h:'高'}[k],{container:platformForm});field('platform-collision','碰撞',{options:[['oneway','单向（可从下方穿过）'],['solid','实心']],container:platformForm});field('platform-moving','往返运动',{type:'checkbox',container:platformForm});field('platform-axis','运动轴',{options:[['x','水平 X'],['y','竖直 Y']],container:platformForm});for(const [k,label,value]of [['min','最小坐标',32],['max','最大坐标',160],['speed','速度（每帧）',.5]])field('platform-'+k,label,{value,container:platformForm});const platformApply=node('button','应用平台',platformForm);platformApply.type='submit';platformApply.setAttribute('data-study-control','platform-apply');platformForm.onsubmit=e=>{e.preventDefault();attempt(()=>updateStudyPlatform(room(),platformId,{...position('platform'),collision:get('platform-collision').value},motion()));};get('platform-select').onchange=()=>{platformId=get('platform-select').value;refresh();};node('p','运动范围填写所选轴的绝对坐标，须包含平台当前坐标。速度 0.01–2；取消往返会保留平台、移除运动。天平平台请在下面成对修改。').className='small';

 node('h3','绳索天平');field('scale-select','天平',{options:[]});button('scale-add','+ 一对天平',()=>attempt(()=>{const r=room();scaleId=upsertStudyScale(r,null,{leftX:Math.max(0,Math.min(64,r.map.width-128)),leftY:Math.min(128,r.map.height-8),rightX:Math.max(64,Math.min(192,r.map.width-48)),rightY:Math.min(144,r.map.height-8),width:48,anchorY:Math.min(64,r.map.height-32)});}));
 const scaleForm=node('form');for(const [k,label]of [['leftX','左平台 X'],['leftY','左平台 Y'],['rightX','右平台 X'],['rightY','右平台 Y'],['width','左平台宽'],['rightWidth','右平台宽'],['anchorY','绳顶 Y']])field('scale-'+k,label,{container:scaleForm});const scaleApply=node('button','应用整对天平',scaleForm);scaleApply.type='submit';scaleApply.setAttribute('data-study-control','scale-apply');button('scale-remove','删除整对天平',()=>attempt(()=>{removeStudyScale(room(),scaleId);scaleId='';}),scaleForm);scaleForm.onsubmit=e=>{e.preventDefault();attempt(()=>upsertStudyScale(room(),scaleId,Object.fromEntries(['leftX','leftY','rightX','rightY','width','rightWidth','anchorY'].map(k=>[k,number('scale-'+k)]))));};get('scale-select').onchange=()=>{scaleId=get('scale-select').value;refresh();};node('p','站在一边使它下降、另一边上升；平台抵达绳顶会断绳，两边一起下落。平台厚度固定为原生 8 像素。').className='small';
 node('h3','检查点');field('checkpoint-support','新增检查点的支撑面',{options:[]});button('checkpoint-add','+ 检查点',()=>attempt(()=>{checkpointId=addStudyCheckpoint(room(),{supportId:get('checkpoint-support').value,targetSpawn:get('checkpoint-target').value});}));field('checkpoint-select','检查点',{options:[]});const checkpointForm=node('form');field('checkpoint-x','X',{container:checkpointForm});field('checkpoint-surface','支撑面 Y',{container:checkpointForm});field('checkpoint-target','复活出生点（本房间）',{options:[],container:checkpointForm});const checkpointApply=node('button','应用检查点',checkpointForm);checkpointApply.type='submit';checkpointApply.setAttribute('data-study-control','checkpoint-apply');button('checkpoint-remove','删除检查点',()=>attempt(()=>{removeStudyCheckpoint(room(),checkpointId);checkpointId='';}),checkpointForm);checkpointForm.onsubmit=e=>{e.preventDefault();attempt(()=>updateStudyCheckpoint(room(),checkpointId,{x:number('checkpoint-x'),surfaceY:number('checkpoint-surface'),targetSpawn:get('checkpoint-target').value}));};get('checkpoint-select').onchange=()=>{checkpointId=get('checkpoint-select').value;refresh();};node('p','支撑面填写脚下平台顶面。旗座顶面在它上方 16 像素，触发区高 48。出生点须清空并站在静止支撑面。').className='small';
 function refresh(){
  const r=room();if(lastRoom!==r.roomId){deviceId=platformId=scaleId=checkpointId='';lastRoom=r.roomId;}
  enabled.checked=!!r.switchStudy;switchBody.hidden=!r.switchStudy;initial.checked=r.switchStudy?.initialOn??true;backtrack.checked=r.switchStudy?.allowBacktracking??true;
  const devices=r.switchStudy?.devices||[];if(!devices.some(q=>q.id===deviceId))deviceId=devices[0]?.id||'';fill(get('switch-select'),devices.map(q=>[q.id,(q.kind==='switch'?'开关':q.color==='red'?'红块':'蓝块')+' · '+q.id]),deviceId);const d=devices.find(q=>q.id===deviceId);switchForm.hidden=!d;if(d)for(const k of ['x','y','w','h'])get('switch-'+k).value=d[k];
  if(!r.map.geometry.some(q=>q.id===platformId))platformId=r.map.geometry[0]?.id||'';fill(get('platform-select'),r.map.geometry.map(q=>[q.id,(q.material||q.collision)+' · '+q.id]),platformId);const p=r.map.geometry.find(q=>q.id===platformId);platformForm.hidden=!p;if(p){for(const k of ['x','y','w','h'])get('platform-'+k).value=p[k];get('platform-collision').value=p.collision;get('platform-moving').checked=!!p.motion;get('platform-axis').value=p.motion?.axis||'x';get('platform-min').value=p.motion?.min??p.x;get('platform-max').value=p.motion?.max??Math.min(r.map.width-p.w,p.x+96);get('platform-speed').value=p.motion?.speed??.5;}
  const scales=r.markers.filter(isScale);if(!scales.some(m=>m.id===scaleId))scaleId=scales[0]?.id||'';fill(get('scale-select'),scales.map(m=>[m.id,m.id]),scaleId);const scale=studyScale(r,scaleId);scaleForm.hidden=!scale||!!scale.broken;if(scale&&!scale.broken)for(const k of ['leftX','leftY','rightX','rightY','width','rightWidth','anchorY'])get('scale-'+k).value=scale[k];
  const supports=checkpointSupports(r),supportId=get('checkpoint-support').value;fill(get('checkpoint-support'),supports.map(q=>[q.id,q.id+' · Y '+q.y]),supports.some(q=>q.id===supportId)?supportId:supports[0]?.id||'');const checkpoints=r.map.objects.filter(q=>q.kind==='checkpoint');if(!checkpoints.some(q=>q.id===checkpointId))checkpointId=checkpoints[0]?.id||'';fill(get('checkpoint-select'),checkpoints.map(q=>[q.id,q.id]),checkpointId);const c=checkpoints.find(q=>q.id===checkpointId),spawns=r.map.objects.filter(q=>q.kind==='spawn');fill(get('checkpoint-target'),spawns.map(q=>[q.id,q.id]),c?.targetSpawn||spawns[0]?.id||'');checkpointForm.hidden=!c;if(c){get('checkpoint-x').value=c.x;get('checkpoint-surface').value=c.y+c.h-(checkpointHasBase(r,c.id)?0:16);}
 }
 refresh();return Object.freeze({refresh});
}
