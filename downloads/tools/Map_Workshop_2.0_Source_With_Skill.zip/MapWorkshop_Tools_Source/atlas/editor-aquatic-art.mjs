import {AQUATIC_CURRENT_DEFAULTS} from './editor-aquatic.mjs';

// Original, procedurally drawn pixel marks. No source sprites or controller state.
const mod=(value,length)=>((value%length)+length)%length;
const phaseFor=id=>{let value=2166136261;for(const ch of id)value=Math.imul(value^ch.charCodeAt(0),16777619);return value>>>0;};
const visible=(q,v)=>!v||q.x<v.x+v.w&&q.x+q.w>v.x&&q.y<(v.y??0)+(v.h??Infinity)&&q.y+q.h>(v.y??0);

function boundary(c,q,alpha){
 c.fillStyle='#82ddff';c.globalAlpha=alpha*.18;
 // Broken one-pixel edges expose the volume without putting a filled box over play.
 for(let x=q.x;x<q.x+q.w;x+=14){c.fillRect(x,q.y,Math.min(3,q.x+q.w-x),1);c.fillRect(x,q.y+q.h-1,Math.min(3,q.x+q.w-x),1);}
 for(let y=q.y;y<q.y+q.h;y+=14){c.fillRect(q.x,y,1,Math.min(3,q.y+q.h-y));c.fillRect(q.x+q.w-1,y,1,Math.min(3,q.y+q.h-y));}
}

function horizontal(c,x,y,direction,alpha){
 c.fillStyle='#6be5ff';c.globalAlpha=alpha*.44;
 c.fillRect(direction>0?x-5:x,y,6,1);
 c.fillRect(x-direction,y-1,1,1);c.fillRect(x-direction,y+1,1,1);
 c.fillStyle='#e0ffff';c.globalAlpha=alpha*.78;c.fillRect(x,y,1,1);
}

function downward(c,x,y,alpha){
 c.fillStyle='#6be5ff';c.globalAlpha=alpha*.36;c.fillRect(x,y-5,1,6);
 c.fillRect(x-1,y-1,1,1);c.fillRect(x+1,y-1,1,1);
 c.fillStyle='#e0ffff';c.globalAlpha=alpha*.66;c.fillRect(x,y,1,1);
}

/** Paint validated opt-in volumes in world pixels, behind terrain and actors.
 * Tick is the parent's active-frame tick: repeated or paused ticks freeze pixels.
 * This visual speed expresses direction; it is not a physical velocity scale. */
export function drawAquaticCurrents(c,room,tick=room?.tick??0){
 if(room?.aquatic?.version!==1||!/Underwater/.test(room.setting||'')||room.underwater===false)return false;
 const currents=room.aquatic.currents||[],activeTick=Number.isFinite(tick)&&tick>=0?Math.floor(tick):0;
 let drawn=false;
 for(const q of currents){
  if(!visible(q,room.renderBounds))continue;
  const pull=q.pull??AQUATIC_CURRENT_DEFAULTS.pull,down=q.down??AQUATIC_CURRENT_DEFAULTS.down,seed=phaseFor(q.id);
  c.save();c.beginPath();c.rect(q.x,q.y,q.w,q.h);c.clip();
  const alpha=c.globalAlpha;c.imageSmoothingEnabled=false;boundary(c,q,alpha);
  if(pull>0){
   const speed=Math.min(.9,.25+pull*12);
   for(let row=0,y=Math.ceil(q.y)+9;y<q.y+q.h;y+=20,row++){
    const offset=(seed%97)+row*17;
    for(const [left,right,direction]of [[q.x,q.centerX,1],[q.centerX,q.x+q.w,-1]]){
     const span=right-left;if(span<6)continue;
     const count=Math.max(1,Math.ceil(span/32));
     for(let i=0;i<count;i++){
      const travel=mod(i*span/count+offset+activeTick*speed,span);
      const x=Math.floor(direction>0?left+travel:right-travel);
      // Keep convergence marks on their own side of the physical centre.
      if(direction>0&&x>=left+5&&x<right-1||direction<0&&x>left+1&&x<=right-6)horizontal(c,x,y,direction,alpha);
     }
    }
   }
  }
  if(down>0){
   const speed=Math.min(1,.25+down*8),count=Math.max(1,Math.ceil(q.h/32));
   for(let col=0,x=Math.ceil(q.x)+13;x<q.x+q.w;x+=28,col++)for(let i=0;i<count;i++){
    const y=Math.floor(q.y+mod(i*q.h/count+(seed%83)+col*19+activeTick*speed,q.h));
    downward(c,x,y,alpha);
   }
  }
  c.restore();drawn=true;
 }
 return drawn;
}
