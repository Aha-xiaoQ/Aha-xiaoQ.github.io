/** Shared, transparent native-grid adaptations from the observed SMB1 course.
 * See course-head-in-clouds/reference/TRACE_PROVENANCE.md. No physics writes.
 * Cloud/Spike/Grinder are traced pixels, not claimed original PNG rips.
 */
import {SMM2_SMB1_LAKITU_CLOUD_TRACE as CLOUD,SMM2_SMB1_SPIKE_TRACE as SPIKE,SMM2_SMB1_GRINDER_TRACE as GRINDER} from './editor-lakitu-source-pixels.mjs';
import {OBSERVED_SKY_MOUNTAINS} from './editor-lakitu-mountain-data.mjs';
import {classicDraw} from './classic-art.mjs';
export const isLakituSkyRoom=r=>r?.smm2Mechanics?.art?.palette==='smb1-sky-source';
const visible=q=>q&&!q.hidden&&!q.dead&&!q.removed&&q.visible!==false;
function pixel(c,color,x,y){c.fillStyle=color;c.fillRect(Math.round(x),Math.round(y),1,1);}
function css(a){return `rgba(${a[0]},${a[1]},${a[2]},${a[3]/255})`;}
export function drawLakituPixels(c,a,{x,y,w=a?.width,h=a?.height,angle=0,shadow=false}={}){
 if(!a||![x,y,w,h,angle].every(Number.isFinite)||w<=0||h<=0)return false;w=Math.round(w);h=Math.round(h);
 const cs=Math.cos(angle),sn=Math.sin(angle),cx=a.width/2,cy=a.height/2;
 const left=Math.round(x),top=Math.round(y),colors=Object.fromEntries(Object.entries(a.palette).map(([k,v])=>[k,css(v)]));
 const paint=(dx,dy,shade)=>{for(let yy=0;yy<h;yy++)for(let xx=0;xx<w;xx++){
  const rx=(xx+.5)*a.width/w-cx,ry=(yy+.5)*a.height/h-cy,sx=Math.floor(rx*cs+ry*sn+cx),sy=Math.floor(-rx*sn+ry*cs+cy),k=a.rows[sy]?.[sx],rgba=a.palette[k];
  if(rgba?.[3])pixel(c,shade??colors[k],left+xx+dx,top+yy+dy);
 }};
 if(shadow)paint(2,2,'rgba(25,34,62,.42)');paint(0,0);return true;
}
export function lakituCloudView(room){return room.lakituCloudView?.clouds??(room.smm2Mechanics?.lakituClouds?.clouds??[]).map(q=>({...q,occupancy:'empty'}));}
export function occupiedLakituCloud(room,p){return lakituCloudView(room).find(q=>visible(q)&&q.occupancy==='player'&&p?.lakituCloudId===q.id)??null;}
export function drawLakituWorld(c,room){
 for(const q of lakituCloudView(room))if(visible(q)&&!q.spent){drawLakituPixels(c,CLOUD,q);
  if(q.occupancy==='player'&&room.smm2Mechanics?.goalCloudRequirements?.some(r=>r.cloudId===q.id)){
   const x=Math.round(q.x)-9,y=Math.round(q.y)-22;c.save();c.fillStyle='#ffffff';c.beginPath();c.arc(x+7,y+7,7,0,Math.PI*2);c.fill();c.fillStyle='#f73910';c.beginPath();c.arc(x+7,y+7,5,0,Math.PI*2);c.fill();
   for(const [px,py]of [[4,4],[8,4],[4,5],[5,5],[7,5],[8,5],[4,6],[6,6],[8,6],[4,7],[8,7],[4,8],[8,8]])pixel(c,'#ffffff',x+px,y+py);c.restore();
  }
 }
}
export function drawLakituActor(c,q,tick,room){
 if(!isLakituSkyRoom(room)||!visible(q))return false;
 if(q.spikeTrap||room.contraptions?.spikeTraps?.some(p=>p.id===q.id)){for(let y=q.y;y<q.y+q.h;y+=16)for(let x=q.x;x<q.x+q.w;x+=16)drawLakituPixels(c,SPIKE,{x,y});return true;}
 if(q.collisionShape==='circle'&&Number.isFinite(q.angleRadians)){drawLakituPixels(c,GRINDER,{x:q.x,y:q.y,w:q.w,h:q.h,angle:q.angleRadians,shadow:true});return true;}
 const spec=room.smm2Mechanics?.railHazards?.hazards?.find(h=>h.id===q.id);
 if(spec){drawLakituPixels(c,GRINDER,{x:q.x,y:q.y,w:q.w,h:q.h,angle:spec.rotationDirection*(tick%spec.rotationFrames)/spec.rotationFrames*Math.PI*2,shadow:true});return true;}
 return false;
}
export function drawLakituGoalMarker(c,o,room){
 if(!isLakituSkyRoom(room)||o.kind!=='flagpole-finish'||!room.smm2Mechanics.goalCloudRequirements?.length)return false;
 const active=!!room.finish||lakituCloudView(room).some(q=>q.occupancy==='player'&&!q.spent),h=o.source?.poleHeight??176,y=o.y-h,color=active?'#80d010':'#000000';
 c.fillStyle=color;c.fillRect(Math.round(o.x+7),Math.round(y+8),2,h-24);
 const rows=['..####..','.######.','########','########','########','########','.######.','..####..'];for(let yy=0;yy<8;yy++)for(let xx=0;xx<8;xx++)if(rows[yy][xx]==='#')pixel(c,color,o.x+4+xx,y+yy);
 if(active)classicDraw(c,'src|Scenery|Flag||',o.x-8,room.finish?.flagY??y+8);
 return true;
}
export function drawLakituGoalHud(c,v,room){
 if(!room.smm2Mechanics?.goalCloudRequirements?.length)return false;
 c.save();c.translate(66,7);c.fillStyle='#93c5fa';c.fillRect(0,0,14,14);c.scale(.6,.6);drawLakituPixels(c,CLOUD,{x:1.5,y:3});c.restore();return true;
}

export function drawLakituSkyMountain(c,q,room){
 if(!isLakituSkyRoom(room)||!visible(q))return false;const a=OBSERVED_SKY_MOUNTAINS[q.smm2Art];if(!a)return false;
 const points=a.points.map(([x,y])=>[q.x+x*q.w/a.w,q.y+y*q.h/a.h]);
 c.save();c.beginPath();c.rect(q.x,q.y,q.w,q.h);c.clip();
 for(let x=Math.ceil(q.x);x<q.x+q.w;x++){const local=(x+.5-q.x)*a.w/q.w;let i=1;while(i<a.points.length-1&&a.points[i][0]<local)i++;const p=a.points[i-1],n=a.points[i],f=Math.max(0,Math.min(1,(local-p[0])/(n[0]-p[0]))),top=Math.round(q.y+(p[1]+(n[1]-p[1])*f)*q.h/a.h);c.fillStyle='#50a88b';c.fillRect(x,top,1,Math.ceil(q.y+q.h)-top);pixel(c,'#3c8878',x,top);}
 // The source shows a few native dark speckles on the exposed mountain face.
 if(q.smm2Art.endsWith('group-fragment'))for(const [x,y]of [[81,12],[87,16],[78,24],[90,27]]){pixel(c,'#347563',q.x+x*q.w/a.w,q.y+y*q.h/a.h);pixel(c,'#347563',q.x+x*q.w/a.w,q.y+(y+1)*q.h/a.h);}
 c.restore();return true;
}
