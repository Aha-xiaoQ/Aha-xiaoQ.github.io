/** Authoring for the evidenced normal-Underwater native actor leaf. Every
 * motion coefficient is an explicit author fit; this module supplies no stock
 * motion defaults and never replaces, resizes or moves a native body. */
import {validate} from './editor-model.mjs';
import {validateUnderwaterActorsRoom} from './editor-underwater-actors.mjs';
import {validateMarioModulesRoom} from './editor-mario-modules.mjs';

const copy = value => structuredClone(value);
const profiles = room => room.smm2Mechanics?.underwaterActors?.profiles || [];
const sources = room => room.marioModules?.enemySources || [];
const kinds = ['fish-bone', 'galoomba', 'beetle-shell'];
const motionFields = {
  'fish-bone': ['cruiseVx', 'alertRadius', 'alertFrames', 'aimSample', 'chargeInitialSpeed', 'chargeAcceleration', 'chargeMaxSpeed', 'blueContactPolicy','sensorFacing'],
  galoomba: ['idleBobAmplitude', 'idleBobPeriodFrames', 'idleBobPhaseFrames', 'approachRadius', 'approachAcceleration', 'approachMaxSpeed', 'approachVerticalCap', 'solidResponse'],
  'beetle-shell': ['initialVx', 'initialVy', 'gravity', 'maxFallSpeed', 'horizontalRestitution']
};
const sourceFields = ['emitterKind', 'launcherId', 'muzzleOffset', 'enemy', 'direction', 'smart', 'intervalFrames', 'initialDelayFrames', 'maxAlive', 'maxEmissions', 'activationDistance', 'vx', 'vy', 'emergenceFrames'];
const plain = value => !!value && typeof value === 'object' && !Array.isArray(value) && [Object.prototype, null].includes(Object.getPrototypeOf(value));
function safeId(value, max = 100) {
  if (typeof value !== 'string' || value.length > max || !/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(value) || ['constructor', 'prototype'].includes(value)) throw new TypeError('Invalid underwater authoring identifier');
}
function fields(value, allowed, required = allowed, label = 'underwater authoring') {
  if (!plain(value)) throw new TypeError('Invalid ' + label);
  for (const key of Reflect.ownKeys(value)) if (typeof key !== 'string' || ['__proto__', 'prototype', 'constructor'].includes(key) || !allowed.includes(key)) throw new TypeError('Unknown ' + label + ' field: ' + String(key));
  for (const key of required) if (!Object.hasOwn(value, key)) throw new TypeError('Missing ' + label + ' field: ' + key);
}
function list(value, label) {
  if (!Array.isArray(value)) throw new TypeError('Invalid ' + label);
  for (const key of Reflect.ownKeys(value)) if (key !== 'length' && (typeof key !== 'string' || !/^(0|[1-9][0-9]*)$/.test(key) || Number(key) >= value.length)) throw new TypeError('Unknown ' + label + ' field: ' + String(key));
  for (let i = 0; i < value.length; i++) if (!Object.hasOwn(value, i)) throw new TypeError('Missing ' + label + ' entry');
}
function target(value) {
  fields(value, ['id', 'sourceId'], [], 'underwater actor target');
  if (Object.hasOwn(value, 'id') === Object.hasOwn(value, 'sourceId')) throw new TypeError('Choose exactly one native actor id or sourceId');
  const key = Object.hasOwn(value, 'id') ? 'id' : 'sourceId'; safeId(value[key]); return key;
}
function profile(value) {
  fields(value, ['id', 'sourceId', 'kind', 'size', 'motion'], ['kind', 'motion'], 'underwater actor profile');
  target(Object.fromEntries(['id', 'sourceId'].filter(key => Object.hasOwn(value, key)).map(key => [key, value[key]])));
  if (!kinds.includes(value.kind)) throw new TypeError('Unsupported underwater actor kind');
  if (value.kind === 'galoomba' ? !Object.hasOwn(value, 'size') : Object.hasOwn(value, 'size')) throw new TypeError('Only Galoomba needs an explicit size');
  fields(value.motion, motionFields[value.kind], motionFields[value.kind].filter(k=>k!=='sensorFacing'), 'explicit ' + value.kind + ' motion');
}
function launcher(value, withId = false) {
  fields(value, withId ? ['id', ...sourceFields] : sourceFields, undefined, 'explicit launcher source');
  fields(value.muzzleOffset, ['x', 'y'], undefined, 'launcher muzzle offset');
  if (value.emitterKind !== 'launcher' || value.enemy !== 'beetle-shell' || value.smart !== false || !['left', 'right'].includes(value.direction)) throw new TypeError('Launcher source requires an empty Buzzy, left/right direction and smart:false');
  if (withId) safeId(value.id, 72);
}
function copiedSource(value) {
  if (value?.emitterKind === 'launcher') return launcher(value, true);
  const required = ['id', 'pipeId', 'enemy', 'smart', 'direction', 'intervalFrames', 'initialDelayFrames', 'maxAlive', 'maxEmissions', 'activationDistance', 'vx', 'vy'];
  fields(value, [...required, 'emitterKind', 'emergenceFrames'], required, 'copied underwater pipe source');
  safeId(value.id, 72); safeId(value.pipeId);
  if (!kinds.includes(value.enemy) || value.emitterKind !== undefined && value.emitterKind !== 'pipe') throw new TypeError('Invalid copied underwater enemy source');
}
function strict(room) {
  const leaf = room.smm2Mechanics?.underwaterActors;
  if (leaf !== undefined) {
    fields(leaf, ['version', 'profiles'], undefined, 'underwater actor authoring leaf');
    list(leaf.profiles, 'underwater actor profile list');
    for (const q of leaf.profiles) profile(q);
  }
  if (room.marioModules?.enemySources !== undefined) {
    list(room.marioModules.enemySources, 'native enemy source list');
    for (const q of sources(room)) if (q?.emitterKind === 'launcher') launcher(q, true);
  }
}
function edit(room, operation) {
  strict(room);
  const next = copy(room), result = operation(next);
  strict(next);
  validateUnderwaterActorsRoom(next);
  validateMarioModulesRoom(next);
  validate({format: 'xiaoq-map-project', version: 1, id: 'underwater-authoring-check', title: 'Underwater actor authoring', rooms: [next]},{allowIncompleteCompletionMarks:true});
  for (const key of Object.keys(room)) if (!Object.hasOwn(next, key)) delete room[key];
  Object.assign(room, next);
  return result;
}
function leaf(room) {
  room.smm2Mechanics ??= {version: 1};
  return room.smm2Mechanics.underwaterActors ??= {version: 1, profiles: []};
}
function clean(room) {
  if (room.smm2Mechanics?.underwaterActors && !profiles(room).length) delete room.smm2Mechanics.underwaterActors;
}

/** Complete replace/add on one actual native walker or actual source. */
export function setUnderwaterActor(room, value) {
  profile(value);
  return edit(room, r => {
    const key = Object.hasOwn(value, 'id') ? 'id' : 'sourceId', rows = leaf(r).profiles;
    const index = rows.findIndex(q => q[key] === value[key]);
    if (index < 0) rows.push(copy(value)); else rows[index] = copy(value);
    return value[key];
  });
}
export function removeUnderwaterActor(room, value) {
  const key = target(value); strict(room);
  if (!profiles(room).some(q => q[key] === value[key])) return false;
  return edit(room, r => {r.smm2Mechanics.underwaterActors.profiles = profiles(r).filter(q => q[key] !== value[key]); clean(r); return true;});
}

/** The caller supplies every timing, launch and emergence field. A cannon is
 * an existing native solid, never a synthetic pipe or a second live launcher. */
export function setUnderwaterLauncherSource(room, id, options) {
  safeId(id, 72); launcher(options);
  return edit(room, r => {
    const previous = sources(r).find(q => q.id === id);
    if (previous && previous.emitterKind !== 'launcher') throw new Error('Launcher editing cannot replace an existing pipe source');
    r.marioModules ??= {version: 1, itemSources: [], noteBlocks: [], oneWayWalls: [], enemyVariants: {}};
    const rows = r.marioModules.enemySources ??= [], index = rows.findIndex(q => q.id === id), value = {id, ...copy(options)};
    if (index < 0) rows.push(value); else rows[index] = value;
    return id;
  });
}
export function removeUnderwaterLauncherSource(room, id) {
  strict(room);
  const old = sources(room).find(q => q.id === id);
  if (!old) return false;
  if (old.emitterKind !== 'launcher') throw new Error('Choose an existing cannon-bound launcher source');
  return edit(room, r => {
    r.marioModules.enemySources = sources(r).filter(q => q.id !== id);
    if (r.smm2Mechanics?.underwaterActors) r.smm2Mechanics.underwaterActors.profiles = profiles(r).filter(q => q.sourceId !== id);
    clean(r); return true;
  });
}

/** For one native History edit: prune only bindings that already referenced
 * a target actually deleted in that edit. Newly invalid bindings still fail
 * the enclosing History validation. Other delete helpers can run first. */
export function pruneUnderwaterActorReferences(room, before) {
  if (!before) return false;
  strict(before); strict(room);
  const nowObjects = new Set(room.map.objects.map(q => q.id)), nowGeometry = new Set(room.map.geometry.map(q => q.id));
  const removedActors = new Set(before.map.objects.filter(q => !nowObjects.has(q.id)).map(q => q.id));
  const removedGeometry = new Set(before.map.geometry.filter(q => !nowGeometry.has(q.id)).map(q => q.id));
  const previousSources = sources(before), removedEmitters = new Set(sources(room).filter(q => previousSources.some(old => old.id === q.id && (q.emitterKind === 'launcher' ? old.emitterKind === 'launcher' && old.launcherId === q.launcherId && removedGeometry.has(q.launcherId) : kinds.includes(q.enemy) && old.pipeId === q.pipeId && removedGeometry.has(q.pipeId)))).map(q => q.id));
  const nextSources = sources(room).filter(q => !removedEmitters.has(q.id)), nowSources = new Set(nextSources.map(q => q.id));
  const removedSources = new Set(previousSources.filter(q => !nowSources.has(q.id)).map(q => q.id));
  const previousProfiles = profiles(before), nextProfiles = profiles(room).filter(q => !previousProfiles.some(old => Object.hasOwn(q, 'id') ? old.id === q.id && removedActors.has(q.id) : old.sourceId === q.sourceId && removedSources.has(q.sourceId)));
  const changed = removedEmitters.size > 0 || nextProfiles.length !== profiles(room).length;
  if (!changed) return false;
  if (removedEmitters.size) room.marioModules.enemySources = nextSources;
  if (room.smm2Mechanics?.underwaterActors) room.smm2Mechanics.underwaterActors.profiles = nextProfiles;
  for (const q of previousProfiles) if (q.id !== undefined && removedActors.has(q.id) && Object.hasOwn(before.enemySkins || {}, q.id) && room.enemySkins?.[q.id] === before.enemySkins[q.id]) delete room.enemySkins[q.id];
  clean(room); return true;
}

/** Detached clipboard bindings for the native object/geometry selection.
 * Source records are owned here when their underwater motion must follow the
 * new source ID. Other pipe source clipboard helpers must exclude these IDs. */
export function captureUnderwaterActorBindings(room, ids, options = {}) {
  fields(options, ['layer'], [], 'underwater clipboard options');
  const layer = options.layer ?? 'objects';
  if (!(ids instanceof Set) || !['objects', 'geometry'].includes(layer)) throw new TypeError('Invalid underwater clipboard selection');
  strict(room); validateUnderwaterActorsRoom(room); validateMarioModulesRoom(room);
  const selectedSources = layer === 'geometry' ? sources(room).filter(q => q.emitterKind === 'launcher' ? ids.has(q.launcherId) : ids.has(q.pipeId) && (['fish-bone', 'galoomba'].includes(q.enemy) || profiles(room).some(p => p.sourceId === q.id))) : [];
  for (const q of selectedSources) copiedSource(q);
  const selectedSourceIds = new Set(selectedSources.map(q => q.id));
  const selectedProfiles = profiles(room).filter(q => Object.hasOwn(q, 'id') ? layer === 'objects' && ids.has(q.id) : selectedSourceIds.has(q.sourceId));
  const enemySkins = Object.fromEntries(selectedProfiles.filter(q => q.id !== undefined && Object.hasOwn(room.enemySkins || {}, q.id)).map(q => [q.id, room.enemySkins[q.id]]));
  return copy({profiles: selectedProfiles, enemySources: selectedSources, enemySkins});
}
function snapshot(value) {
  fields(value, ['profiles', 'enemySources', 'enemySkins'], undefined, 'underwater clipboard');
  list(value.profiles, 'copied underwater profiles'); list(value.enemySources, 'copied underwater sources');
  const seen = new Set();
  for (const q of value.profiles) {
    profile(q); const key = q.id === undefined ? 'source:' + q.sourceId : 'actor:' + q.id;
    if (seen.has(key)) throw new TypeError('Duplicate copied underwater target'); seen.add(key);
  }
  const sourceIds = new Set();
  for (const q of value.enemySources) {copiedSource(q); if (sourceIds.has(q.id)) throw new TypeError('Duplicate copied underwater source'); sourceIds.add(q.id);}
  for (const q of value.profiles) if (q.sourceId !== undefined && !sourceIds.has(q.sourceId)) throw new TypeError('Copied underwater profile is missing its source');
  fields(value.enemySkins, value.profiles.filter(q => q.id !== undefined).map(q => q.id), [], 'copied underwater native skins');
}
function roomIds(room) {
  const result = new Set(), visited = new WeakSet();
  function visit(value) {if (!value || typeof value !== 'object' || visited.has(value)) return; visited.add(value); if (typeof value.id === 'string') result.add(value.id); for (const child of Object.values(value)) visit(child);}
  visit(room); return result;
}
/** Called after copied native bodies/cannons/pipes are appended in the same
 * real History transaction. Every source is assigned a fresh ID; motion and
 * local muzzle coordinates stay exact. idMap updates only after validation. */
export function appendCopiedUnderwaterActorBindings(room, value, idMap) {
  if (value == null) return new Map(); snapshot(value);
  if (!(idMap instanceof Map)) throw new TypeError('Underwater clipboard needs a native ID map');
  if (!value.profiles.length && !value.enemySources.length && !Object.keys(value.enemySkins).length) return new Map();
  const additions = new Map();
  edit(room, r => {
    const occupied = roomIds(r);
    for (const source of value.enemySources) {
      const binding = source.emitterKind === 'launcher' ? 'launcherId' : 'pipeId', nativeId = idMap.get(source[binding]);
      if (!nativeId || nativeId === source[binding]) throw new Error('Copied underwater source is missing its copied native emitter');
      let id = idMap.get(source.id);
      if (id === undefined) do {id = 'underwater-source-' + globalThis.crypto.randomUUID();} while (occupied.has(id));
      safeId(id, 72);
      if (id === source.id || occupied.has(id)) throw new Error('Copied underwater source needs an unused new ID');
      occupied.add(id); additions.set(source.id, id);
      r.marioModules ??= {version: 1, itemSources: [], noteBlocks: [], oneWayWalls: [], enemyVariants: {}};
      (r.marioModules.enemySources ??= []).push({...copy(source), id, [binding]: nativeId});
    }
    for (const q of value.profiles) {
      const key = q.id === undefined ? 'sourceId' : 'id', old = q[key], id = key === 'sourceId' ? additions.get(old) : idMap.get(old);
      if (!id || id === old) throw new Error('Copied underwater profile is missing its copied native body or source');
      if (profiles(r).some(p => p[key] === id)) throw new Error('Copied underwater profile target is already bound');
      if (key === 'id' && Object.hasOwn(value.enemySkins, old)) (r.enemySkins ??= {})[id] = copy(value.enemySkins[old]);
      leaf(r).profiles.push({...copy(q), [key]: id});
    }
  });
  for (const [old, id] of additions) idMap.set(old, id);
  return additions;
}

const controls = {
  'fish-bone': [
    ['cruiseVx', '巡游水平速度', -4, 4], ['alertRadius', '警戒半径', 1, 1024], ['alertFrames', '红眼停留帧数', 1, 600, '1'],
    ['sensorFacing','警戒朝向（原片背面鱼保持蓝眼）',['','forward','any']], ['aimSample', '固定冲刺瞄准采样', ['alert-start', 'charge-start']], ['chargeInitialSpeed', '冲刺初速', 0, 16], ['chargeAcceleration', '冲刺加速度', .000001, 4], ['chargeMaxSpeed', '冲刺速度上限', .001, 64], ['blueContactPolicy', '蓝眼真实实体接触', ['reverse', 'stop', 'slide']]
  ],
  galoomba: [
    ['idleBobAmplitude', '闲置上下振幅', 0, 16], ['idleBobPeriodFrames', '闲置周期帧数', 8, 36000, '1'], ['idleBobPhaseFrames', '初始闲置相位帧数', 0, 36000], ['approachRadius', '靠近玩家范围', 0, 1024], ['approachAcceleration', '靠近加速度', .000001, 1], ['approachMaxSpeed', '靠近速度上限', 0, 8], ['approachVerticalCap', '靠近竖向速度上限', 0, 8], ['solidResponse', '真实实体接触响应', ['slide', 'stop', 'reverse']]
  ],
  'beetle-shell': [
    ['initialVx', '空壳初始水平速度', -8, 8], ['initialVy', '空壳初始竖向速度', -8, 8], ['gravity', '空壳重力', .000001, .5], ['maxFallSpeed', '空壳下落速度上限', .001, 8], ['horizontalRestitution', '水平碰撞反弹系数', 0, 1]
  ]
};
const launcherControls = [
  ['muzzle-x', '炮口中心相对 X', 0, 32768], ['muzzle-y', '炮口中心相对 Y', 8, 4096], ['intervalFrames', '供给间隔帧数', 1, 36000, '1'], ['initialDelayFrames', '首次供给等待帧数', 0, 36000, '1'], ['maxAlive', '同时存活上限', 1, 32, '1'], ['activationDistance', '玩家启用距离', 0, 32768], ['vx', '供给水平速度', -8, 8], ['vy', '供给竖向速度', -12, 12], ['emergenceFrames', '真实出炮帧数', 1, 240, '1']
];
function markup(prefix, [key, label, min, max, step = 'any']) {
  return '<label>' + label + (Array.isArray(min) ? '<select data-underwater-actor="' + prefix + key + '"><option value="">请选择</option>' + min.map(value => '<option value="' + value + '">' + value + '</option>').join('') + '</select>' : '<input type="number" step="' + step + '" min="' + min + '" max="' + max + '" data-underwater-actor="' + prefix + key + '">') + '</label>';
}
const cannons = room => room.map.geometry.filter(q => q.collision === 'solid' && (q.material === 'cannon' || room.semantics?.some(s => s.id === q.id && s.kind === 'Cannon')));

/** Mount the existing-source/native-body panel. Each Apply and Remove passes
 * through the supplied real History change callback. refresh() reflects undo,
 * redo, imported documents and actual native selection. */
export function mountUnderwaterActorTools({parent, room, selected = () => new Set(), change, report = () => {}}) {
  const panel = document.createElement('details'); parent.append(panel);
  panel.innerHTML = '<summary>水下 Fish Bone、Galoomba 与空甲壳</summary><p class="small">仅绑定正常 Underwater 的已有 walker 或已有敌人供给源。所有运动与供给数值必须显式填写，属于作者拟定；未声明原版物理或巨型追踪校准。</p><label>真实身体 / 敌人供给源<select data-underwater-actor="target"></select></label><label>行为种类<select data-underwater-actor="kind"><option value="">请选择</option>' + kinds.map(kind => '<option value="' + kind + '">' + kind + '</option>').join('') + '</select></label><label data-underwater-size="true">Galoomba 尺寸<select data-underwater-actor="size"><option value="">请选择</option><option value="small">small</option><option value="giant">giant</option></select></label>' + kinds.map(kind => '<div data-underwater-motion="' + kind + '">' + controls[kind].map(q => markup(kind + '-', q)).join('') + '</div>').join('') + '<button type="button" data-underwater-actor="apply">绑定 / 更新水下行为</button><button type="button" data-underwater-actor="remove">移除水下行为绑定</button><p class="small">空甲壳炮台供给使用已有实体 cannon。炮口中心相对左上角；左发射 X=0、右发射 X=炮台宽，Y 必须容纳完整 16px 身体。</p><label>已有炮台供给源<select data-underwater-actor="launcher-source"></select></label><label>供给源 ID<input type="text" data-underwater-actor="launcher-id"></label><label>已有真实炮台 ID<select data-underwater-actor="launcher-cannon"></select></label><label>发射方向<select data-underwater-actor="launcher-direction"><option value="">请选择</option><option value="left">left</option><option value="right">right</option></select></label>' + launcherControls.map(q => markup('launcher-', q)).join('') + '<label>总供给上限（填写整数或 null 表示不限）<input type="text" data-underwater-actor="launcher-maxEmissions"></label><button type="button" data-underwater-actor="launcher-apply">新增 / 更新炮台空甲壳供给</button><button type="button" data-underwater-actor="launcher-remove">移除炮台供给与行为绑定</button><p class="small" data-underwater-actor="status"></p>';
  const get = key => panel.querySelector('[data-underwater-actor="' + key + '"]');
  const number = key => {const raw = String(get(key).value).trim(); if (!raw) throw new Error('请填写作者参数 ' + key); const value = Number(raw); if (!Number.isFinite(value)) throw new Error('参数必须为有限数字：' + key); return value;};
  const attempt = fn => {try {change(fn);} catch (error) {report(error.message);} refresh();};
  let pendingLauncher = null;
  const chosen = () => {const raw = get('target').value, separator = raw.indexOf(':'); if (separator < 0) throw new Error('请选择已有 walker 或敌人供给源'); return {[raw.slice(0, separator)]: raw.slice(separator + 1)};};
  function showMotion() {
    const kind = get('kind').value;
    for (const value of kinds) panel.querySelector('[data-underwater-motion="' + value + '"]').hidden = value !== kind;
    panel.querySelector('[data-underwater-size]').hidden = kind !== 'galoomba';
  }
  get('kind').onchange = showMotion;
  get('apply').onclick = () => attempt(() => {
    const kind = get('kind').value; if (!kinds.includes(kind)) throw new Error('请选择明确的水下行为种类');
    const motion = Object.fromEntries(controls[kind].map(([key, , min]) => [key, Array.isArray(min) ? get(kind + '-' + key).value : number(kind + '-' + key)]));
    if(motion.sensorFacing==='')delete motion.sensorFacing;
    setUnderwaterActor(room(), {...chosen(), kind, ...(kind === 'galoomba' ? {size: get('size').value} : {}), motion});
  });
  get('remove').onclick = () => attempt(() => removeUnderwaterActor(room(), chosen()));
  get('launcher-apply').onclick = () => attempt(() => {
    const raw = String(get('launcher-maxEmissions').value).trim();
    if (!raw) throw new Error('请填写总供给上限整数或 null');
    const maxEmissions = raw === 'null' ? null : number('launcher-maxEmissions');
    const options = Object.fromEntries(launcherControls.filter(([key]) => !key.startsWith('muzzle-')).map(([key]) => [key, number('launcher-' + key)]));
    pendingLauncher = setUnderwaterLauncherSource(room(), String(get('launcher-id').value).trim(), {...options, maxEmissions, emitterKind: 'launcher', launcherId: get('launcher-cannon').value, muzzleOffset: {x: number('launcher-muzzle-x'), y: number('launcher-muzzle-y')}, enemy: 'beetle-shell', direction: get('launcher-direction').value, smart: false});
  });
  get('launcher-remove').onclick = () => attempt(() => removeUnderwaterLauncherSource(room(), get('launcher-source').value));
  get('target').onchange = () => refresh();
  get('launcher-source').onchange = () => refresh();
  function fill(key, rows, pick, emptyLabel) {
    const options = rows.map(({value, label}) => {const option = document.createElement('option'); option.value = value; option.textContent = label; return option;});
    if (emptyLabel !== undefined) {const option = document.createElement('option'); option.value = ''; option.textContent = emptyLabel; options.unshift(option);}
    const node = get(key); node.replaceChildren(...options); node.value = rows.some(q => q.value === pick) ? pick : emptyLabel !== undefined ? '' : rows[0]?.value || '';
  }
  let lastRoom = null, lastSelection = '';
  function refresh() {
    const r = room(), ids = selected(), selection = [...ids].sort().join('|'), roomChanged = lastRoom !== r.roomId, selectionChanged = roomChanged || selection !== lastSelection;
    const walkers = r.map.objects.filter(q => q.kind === 'walker'), actualSources = sources(r).filter(q => kinds.includes(q.enemy) && q.shoeTemplateId === undefined && q.actorVariant === undefined);
    const targets = [...walkers.map(q => ({value: 'id:' + q.id, label: 'walker: ' + q.id})), ...actualSources.map(q => ({value: 'sourceId:' + q.id, label: 'source: ' + q.id}))];
    const nativeSelected = selectionChanged && ids.size === 1 ? targets.find(q => q.value === 'id:' + [...ids][0])?.value : undefined;
    const firstProfile = profiles(r)[0], preferred = firstProfile ? (Object.hasOwn(firstProfile, 'id') ? 'id:' + firstProfile.id : 'sourceId:' + firstProfile.sourceId) : undefined;
    fill('target', targets, nativeSelected ?? (roomChanged ? preferred : get('target').value));
    const picked = get('target').value, current = profiles(r).find(q => picked === (Object.hasOwn(q, 'id') ? 'id:' + q.id : 'sourceId:' + q.sourceId));
    get('kind').value = current?.kind ?? ''; get('size').value = current?.size ?? '';
    for (const kind of kinds) for (const [key] of controls[kind]) get(kind + '-' + key).value = current?.kind === kind && current.motion[key] !== undefined ? String(current.motion[key]) : '';
    showMotion();
    const launcherRows = sources(r).filter(q => q.emitterKind === 'launcher');
    fill('launcher-source', launcherRows.map(q => ({value: q.id, label: q.id})), pendingLauncher ?? (roomChanged ? launcherRows[0]?.id : get('launcher-source').value), '新增供给源'); pendingLauncher = null;
    const source = launcherRows.find(q => q.id === get('launcher-source').value), cannonRows = cannons(r);
    fill('launcher-cannon', cannonRows.map(q => ({value: q.id, label: q.id})), source?.launcherId ?? (roomChanged ? '' : get('launcher-cannon').value));
    get('launcher-id').value = source?.id ?? ''; get('launcher-direction').value = source?.direction ?? '';
    for (const [key] of launcherControls) {const value = key === 'muzzle-x' ? source?.muzzleOffset.x : key === 'muzzle-y' ? source?.muzzleOffset.y : source?.[key]; get('launcher-' + key).value = value === undefined ? '' : String(value);}
    get('launcher-maxEmissions').value = source?.maxEmissions === null ? 'null' : source?.maxEmissions === undefined ? '' : String(source.maxEmissions);
    get('apply').disabled = !targets.length; get('remove').disabled = !current;
    get('launcher-apply').disabled = !cannonRows.length; get('launcher-remove').disabled = !source;
    get('status').textContent = profiles(r).length + ' 个显式水下行为绑定；' + launcherRows.length + ' 个真实炮台供给源';
    lastRoom = r.roomId; lastSelection = selection;
  }
  refresh();
  return {panel, refresh, destroy() {panel.remove();}};
}
