/** Private opt-in ON/OFF study. Every block uses the same global predicate. */
export const SWITCH_STUDY_VERSION=1;
const clone=x=>JSON.parse(JSON.stringify(x));
const overlap=(a,b)=>a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y;
export const switchStudyEnabled=room=>room?.switchStudy?.version===SWITCH_STUDY_VERSION;

export function validateSwitchStudyRoom(room){
 const spec=room.switchStudy;if(spec===undefined)return;
 if(!spec||Array.isArray(spec)||spec.version!==SWITCH_STUDY_VERSION)throw Error('Unknown switch study version');
 for(const key of Object.keys(spec))if(!['version','initialOn','allowBacktracking','devices','clouds'].includes(key))throw Error('Unknown switch study field: '+key);
 if(typeof spec.initialOn!=='boolean'||typeof spec.allowBacktracking!=='boolean')throw Error('Switch study state and backtracking must be booleans');
 if(room.mechanics!==undefined||room.devices?.length)throw Error('Switch study cannot combine with echo devices');
 if(!Array.isArray(spec.devices)||spec.devices.length>20000)throw Error('Invalid switch study device list');
 if(spec.clouds!==undefined){
  if(!Array.isArray(spec.clouds)||spec.clouds.length>20000)throw Error('Invalid study cloud list');
  for(const q of spec.clouds){if(!q||!['Cloud1','Cloud2','Cloud3'].includes(q.type)||!Number.isInteger(q.x)||!Number.isInteger(q.y)||q.x<0||q.y<0||q.x>=room.map.width||q.y>=room.map.height)throw Error('Invalid study cloud');for(const key of Object.keys(q))if(!['x','y','type'].includes(key))throw Error('Unknown study cloud field: '+key);}
 }
 const ids=new Set([...room.map.geometry,...room.map.objects].map(q=>q.id));
 for(const q of spec.devices){
  if(!q||typeof q.id!=='string'||!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(q.id)||q.id.length>72||ids.has(q.id))throw Error('Duplicate or invalid switch study device ID');ids.add(q.id);
  if(!['switch','block'].includes(q.kind))throw Error('Unknown switch study device kind');
  for(const key of Object.keys(q))if(!['id','kind','color','x','y','w','h'].includes(key))throw Error('Unknown switch study device field: '+key);
  if(!['x','y','w','h'].every(k=>Number.isInteger(q[k]))||q.x<0||q.y<0||q.w<=0||q.h<=0||q.x+q.w>room.map.width||q.y+q.h>room.map.height)throw Error('Switch study device is outside the room');
  if(q.kind==='switch'&&(q.w!==16||q.h!==16||q.color!==undefined))throw Error('ON/OFF switches must be 16 by 16');
  if(q.kind==='block'&&(!['red','blue'].includes(q.color)||q.w%16||q.h%16))throw Error('Switch blocks need red or blue and whole tile dimensions');
 }
}

export function createSwitchStudy(rooms=[],entryRoom){
 const enabled=rooms.filter(switchStudyEnabled);if(!enabled.length)return null;
 for(const room of enabled)validateSwitchStudyRoom(room);
 const initialOn=(enabled.find(r=>r.roomId===entryRoom)||enabled[0]).switchStudy.initialOn;
 if(enabled.some(r=>r.switchStudy.initialOn!==initialOn))throw Error('All switch study rooms share one initial state');
 const specs=new Map(enabled.map(r=>[r.roomId,clone(r.switchStudy)])),bumps=new Map();
 let on=initialOn,cooldown=0,guard=null,toggles=0;
 const key=(roomId,id)=>roomId+'\n'+id;
 const active=q=>q.kind==='switch'||(q.color==='red'?on:!on);
 function frame(roomId,player){
  if(cooldown)cooldown--;
  for(const [id,age]of bumps)if(age>1)bumps.set(id,age-1);else bumps.delete(id);
  if(guard){const q=specs.get(guard.roomId)?.devices.find(d=>d.id===guard.id);
   if(roomId!==guard.roomId||!q||player.x+player.w<=q.x||player.x>=q.x+q.w||player.y>q.y+q.h+2)guard=null;
  }
 }
 function toggleHit(roomId,id,actor=null,actorId=null){
  const q=specs.get(roomId)?.devices.find(d=>d.id===id&&d.kind==='switch');
  if(!q||cooldown||(!actor&&guard))return null;
  const previousOn=on;on=!on;toggles++;cooldown=12;if(!actor)guard={roomId,id};bumps.set(key(roomId,id),12);
  return {event:'toggle',roomId,deviceId:id,on,previousOn,toggles,...(actor?{actor}:{}),...(actor==='thwomp'?{actorId}:{})};
 }
 function apply(roomId,geometry,actors=[],externalSupportIds=[]){
  if(!Array.isArray(externalSupportIds)||externalSupportIds.some(id=>typeof id!=='string'))throw Error('External support IDs must be an array of strings');
  const spec=specs.get(roomId);if(!spec)return geometry;
  const base=geometry.filter(q=>!q.studyDevice),colliders=spec.devices.filter(active).map(q=>({...q,collision:'solid',material:q.kind==='switch'?'study-switch':'study-'+q.color,studyDevice:true,dir:1,dx:0,dy:0,bump:bumps.get(key(roomId,q.id))||0}));
  const next=[...base,...colliders],ids=new Set([...next.map(q=>q.id),...externalSupportIds]);
  for(const actor of actors)if(actor?.support&&!ids.has(actor.support)){actor.support=null;actor.grounded=false;}
  return next;
 }
 function reset(){on=initialOn;cooldown=0;guard=null;toggles=0;bumps.clear();}
 function view(roomId){const spec=specs.get(roomId);return spec?{version:SWITCH_STUDY_VERSION,on,initialOn,allowBacktracking:spec.allowBacktracking,toggles,devices:spec.devices.map(q=>({...q,active:active(q),solid:active(q),bump:bumps.get(key(roomId,q.id))||0})),...(spec.clouds?{clouds:clone(spec.clouds)}:{})}:null;}
 return Object.freeze({frame,headHit:(roomId,id)=>toggleHit(roomId,id),shellHit:(roomId,id)=>toggleHit(roomId,id,'shell'),thwompHit:(roomId,id,actorId)=>typeof actorId==='string'?toggleHit(roomId,id,'thwomp',actorId):null,apply,reset,view,allowsBacktracking:roomId=>specs.get(roomId)?.allowBacktracking===true});
}

/** Resolve a newly materialized solid without removing or killing an actor. */
export function resolveStudyOverlap(actor,geometry,width){
 const solids=geometry.filter(q=>!q.hidden&&q.collision==='solid'&&!(q.smm2ItemBody&&q.id===actor.id));
 for(let n=0;n<8;n++){
  const hits=solids.filter(q=>overlap(actor,q));if(!hits.length)break;
  const candidates=hits.flatMap(q=>[
   {x:q.x-actor.w,y:actor.y,axis:'x'},{x:q.x+q.w,y:actor.y,axis:'x'},
   {x:actor.x,y:q.y-actor.h,axis:'y',support:q.id},{x:actor.x,y:q.y+q.h,axis:'y'}
  ]).filter(pos=>pos.x>=0&&pos.x+actor.w<=width&&!solids.some(q=>overlap({...actor,...pos},q)))
   .sort((a,b)=>Math.abs(a.x-actor.x)+Math.abs(a.y-actor.y)-Math.abs(b.x-actor.x)-Math.abs(b.y-actor.y));
  const pos=candidates[0];if(!pos)break;
  actor.x=pos.x;actor.y=pos.y;if(pos.axis==='x')actor.vx=-(actor.vx||0);else{actor.vy=0;actor.grounded=!!pos.support;actor.support=pos.support||null;}
 }
}

/** Dedicated study actors share the actual world solids, with swept contacts. */
export function stepStudyEnemy(e,geometry,width,{topBefore=q=>q.y}={}){
 const solids=geometry.filter(q=>!q.hidden),chomp=e.type==='study-chomp';
 if(chomp){
  e.hopClock=(e.hopClock||0)+1;
  if(e.grounded&&e.hopClock>=48){e.vy=-3.5;e.grounded=false;e.support=null;e.hopClock=0;}
  e.vx=e.vx||-.7;e.facing=Math.sign(e.vx);e.frame=e.grounded?'rest':'hop';
 }else{e.vx=0;e.frame='floor';}
 const oldX=e.x,bottom=e.y+e.h,top=e.y;e.x+=e.vx;
 for(const q of solids)if(q.collision==='solid'&&overlap(e,q)&&bottom>q.y+1){e.x=e.vx>0?q.x-e.w:q.x+q.w;e.vx*=-1;break;}
 if(e.x<0||e.x+e.w>width){e.x=Math.max(0,Math.min(width-e.w,e.x));e.vx*=-1;}
 e.vy=Math.min(5,e.vy+.3);e.y+=e.vy;e.grounded=false;e.support=null;
 if(e.vy>=0){
  for(const q of [...solids].sort((a,b)=>a.y-b.y))if(e.x+e.w>q.x&&e.x<q.x+q.w&&bottom<=topBefore(q)+1.01&&e.y+e.h>=q.y){e.y=q.y-e.h;e.vy=0;e.grounded=true;e.support=q.id;break;}
 }else{
  const ceiling=solids.filter(q=>q.collision==='solid'&&e.x+e.w>q.x&&e.x<q.x+q.w&&top>=q.y+q.h-1&&e.y<q.y+q.h).sort((a,b)=>b.y+b.h-a.y-a.h)[0];
  if(ceiling){e.y=ceiling.y+ceiling.h;e.vy=0;}
 }
 e.falling=!e.grounded&&e.vy>0;return {oldX};
}
