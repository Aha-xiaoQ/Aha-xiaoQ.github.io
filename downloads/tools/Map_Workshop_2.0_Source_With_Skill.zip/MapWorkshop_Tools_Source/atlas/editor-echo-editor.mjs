import {echoEnabled} from './editor-echo.mjs';
/** Small authoring inspector; all writes use the workshop's existing History. */
export function mountEchoEditor({parent,room,change,report}){
 const panel=document.createElement('section');panel.id='echo-inspector';
 panel.innerHTML=`<h2>六秒回声 · 实验机关</h2><p class="small">此副本支持影子板、本人板和 ON / OFF 关联门/桥。箭头表示需要踩下，横杠表示需要松开。全部保存在工程中；原公开工坊尚无此机制。</p><label><input id="echo-enabled" type="checkbox">启用本房间回声合作</label><div id="echo-authoring" hidden><label>重录锚点<select id="echo-anchor"></select></label><label>本房间提示<input id="echo-instructions" maxlength="500"></label><label>回声机关<select id="echo-device"></select></label><div class="row"><button type="button" data-add="ghost">+ 蓝板</button><button type="button" data-add="live">+ 橙板</button><button type="button" data-add="gate">+ 门</button><button type="button" data-add="bridge">+ 桥</button></div><form id="echo-device-form"><p id="echo-device-id" class="small"></p><label>标签<input name="label" maxlength="8" required></label><div class="row"><label>X<input name="x" type="number" min="0" required></label><label>Y<input name="y" type="number" min="0" required></label></div><div class="row"><label>宽<input name="w" type="number" min="1" required></label><label>高<input name="h" type="number" min="1" required></label></div><label id="echo-actor-label">谁能触发<select name="actor"><option value="ghost">影子（蓝）</option><option value="live">本人（橙）</option></select></label><label id="echo-requires-label">ON：全部需要踩下的踏板 ID<input name="requires" placeholder="ghost-a,live-c"></label><label id="echo-requires-off-label">OFF：全部需要松开的踏板 ID<input name="requiresOff" placeholder="ghost-a"></label><label id="echo-wire-label">连线高度（仅显示，可留空）<input name="wireY" type="number" min="0" placeholder="自动"></label><p id="echo-plate-links" class="small"></p><label id="echo-latch-label"><input name="latch" type="checkbox">同时满足后锁定开启</label><div class="row"><button type="submit">应用机关</button><button type="button" id="echo-remove">删除机关</button></div></form><p class="small">踏板 Y 对齐支撑面，建议高 4。ON 与 OFF 必须同时成立，同一踏板不能同时放在两栏。没有影子时影子板视为松开，包括待机和录制中。桥在条件满足时出现；门在满足时消失。OFF 门通常不锁定；A+C 终点门可勾选锁定。R 录制/保存，T 保留上次轨迹原样重试，C 明确清空；重试会重置现场锁定。导出 qmap 工程和离线试玩均保留机关；此工程禁止导出通用开发包和旧版32关连续版。</p></div>`;
 parent.append(panel);const get=id=>panel.querySelector('#'+id),form=get('echo-device-form');let selected='';
 const attempt=fn=>{try{change(fn);}catch(e){report(e.message);refresh();}};
 const options=(select,list,value)=>{select.replaceChildren(...list.map(([v,text])=>{const option=document.createElement('option');option.value=v;option.textContent=text;return option;}));select.value=value;};
 get('echo-enabled').onchange=()=>attempt(()=>{const r=room();if(get('echo-enabled').checked){r.mechanics={type:'echo-cooperation',version:1,maxFrames:360,anchorSpawn:r.map.objects.find(o=>o.kind==='spawn')?.id};r.devices=[];}else{delete r.mechanics;delete r.devices;}});
 get('echo-anchor').onchange=()=>attempt(()=>{room().mechanics.anchorSpawn=get('echo-anchor').value;});
 get('echo-instructions').onchange=()=>attempt(()=>{room().mechanics.instructions=get('echo-instructions').value;});
 get('echo-device').onchange=()=>{selected=get('echo-device').value;refresh();};
 for(const button of panel.querySelectorAll('[data-add]'))button.onclick=()=>attempt(()=>{
  const r=room(),kind=button.dataset.add,isPlate=['ghost','live'].includes(kind),plates=r.devices.filter(d=>d.kind==='plate');
  if(!isPlate&&!plates.length)throw Error('先添加一块踏板，再设置关联门或桥');
  const id='echo-'+globalThis.crypto.randomUUID(),label=isPlate?String.fromCharCode(65+Math.min(25,plates.length)):plates[0].label;
  const x=Math.max(0,Math.min(r.map.width-32,Math.round((r.map.width/2)/16)*16));
  const d=isPlate?{id,kind:'plate',actor:kind,label,x,y:r.map.height-16,w:32,h:4}:{id,kind,label,x,y:Math.max(64,r.map.height-96),w:kind==='gate'?16:48,h:kind==='gate'?80:8,requires:[plates[0].id],material:kind==='gate'?'stone':'bridge'};
  r.devices.push(d);selected=id;
 });
 form.onsubmit=event=>{event.preventDefault();attempt(()=>{
  const d=room().devices.find(d=>d.id===selected);if(!d)throw Error('请先选择机关');
  d.label=form.elements.label.value.trim().toUpperCase();for(const key of ['x','y','w','h'])d[key]=Number(form.elements[key].value);
  if(d.kind==='plate')d.actor=form.elements.actor.value;
  else{for(const key of ['requires','requiresOff'])d[key]=form.elements[key].value.split(',').map(s=>s.trim()).filter(Boolean);d.latch=form.elements.latch.checked;const wire=form.elements.wireY.value.trim();if(wire)d.wireY=Number(wire);else delete d.wireY;}
 });};
 get('echo-remove').onclick=()=>attempt(()=>{const r=room();if(r.devices.some(d=>d.requires?.includes(selected)||d.requiresOff?.includes(selected)))throw Error('该踏板仍被门或桥引用，请先修改关联或删除相应机关');r.devices=r.devices.filter(d=>d.id!==selected);selected='';});
 function refresh(){
  const r=room(),enabled=echoEnabled(r);get('echo-enabled').checked=enabled;get('echo-authoring').hidden=!enabled;if(!enabled)return;
  options(get('echo-anchor'),r.map.objects.filter(o=>o.kind==='spawn').map(o=>[o.id,o.id]),r.mechanics.anchorSpawn||r.map.objects.find(o=>o.kind==='spawn')?.id);
  get('echo-instructions').value=r.mechanics.instructions||'';
  if(!r.devices.some(d=>d.id===selected))selected=r.devices[0]?.id||'';
  options(get('echo-device'),r.devices.map(d=>[d.id,d.label+' · '+(d.kind==='plate'?(d.actor==='ghost'?'蓝色影子板':'橙色本人板'):d.kind==='bridge'?'条件桥':'条件门')+' · '+d.id]),selected);
  const d=r.devices.find(d=>d.id===selected);form.hidden=!d;if(!d)return;
  get('echo-device-id').textContent=d.id+' · '+d.kind;
  for(const key of ['label','x','y','w','h'])form.elements[key].value=d[key];
  const plate=d.kind==='plate';get('echo-actor-label').hidden=!plate;get('echo-requires-label').hidden=plate;get('echo-requires-off-label').hidden=plate;get('echo-wire-label').hidden=plate;get('echo-latch-label').hidden=plate;get('echo-plate-links').hidden=plate;
  form.elements.actor.value=d.actor||'ghost';form.elements.requires.value=(d.requires||[]).join(',');form.elements.requiresOff.value=(d.requiresOff||[]).join(',');form.elements.wireY.value=d.wireY??'';form.elements.latch.checked=!!d.latch;
  get('echo-plate-links').textContent=r.devices.filter(d=>d.kind==='plate').map(p=>p.label+' = '+p.id).join('；');
 }
 return {refresh};
}
