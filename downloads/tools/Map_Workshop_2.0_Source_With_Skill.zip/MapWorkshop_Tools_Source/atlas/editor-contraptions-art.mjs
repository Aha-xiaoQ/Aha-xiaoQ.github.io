import {drawSmwUnderwaterObject} from './editor-smw-underwater-art.mjs';
import {classicDraw} from './classic-art.mjs';
import {drawOriginalClownCar} from './editor-clown-car-art.mjs';
import {isSmb3ArtRoom,drawSmb3OneWayWall} from './editor-smb3-art.mjs';
import {drawSmm2SourcePixels} from './editor-smm2-source-assets.mjs';
import {SMM1_SMB1_KEY_DOOR_SOURCE_PIXELS} from './editor-smm1-key-door-source-pixels.mjs';
import {drawSmm2PSwitch} from './editor-smm2-p-switch-art.mjs';

/** Original, code-native pixel art for the private claw-course study.
 * Clown Car, P Switch, native SMB1 key and explicit unlocked door use attributed source
 * pixels. Plain/locked doors and unsupported styles retain legacy adaptations.
 * Native coins/bricks continue to use the existing attributed classic atlas.
 * These functions describe appearance only; the mechanics own all collisions.
 */
export const CONTRAPTIONS_PALETTE=Object.freeze({
 sky:'#747bef',skyShadow:'#656acb',sand:'#e4c7b8',sandEdge:'#dcbda8',
 ground:'#ffdfac',groundLight:'#fff0c7',groundGold:'#eca451',groundDark:'#a55b22',
 copper:'#c5792b',copperDark:'#743b22',copperLight:'#ffe2a1',
 white:'#fffdf4',ink:'#28272b',rail:'#39383b',green:'#43b92c',greenDark:'#237c28',
 red:'#ec4552',redDark:'#9f2637',blue:'#5259ed',blueDark:'#242b8f',cyan:'#8fe7e1'
});
const P=CONTRAPTIONS_PALETTE;
const enabled=room=>room?.contraptions?.scene==='desert'||room?.contraptionsView?.scene==='desert';
const live=room=>room.contraptionsView||room.contraptions||{};
const point=p=>Array.isArray(p)?{x:p[0],y:p[1]}:p;
const finitePoint=p=>p&&Number.isFinite(p.x)&&Number.isFinite(p.y);
function rect(c,color,x,y,w=1,h=1){
 const x0=Math.round(x),y0=Math.round(y),x1=Math.round(x+w),y1=Math.round(y+h);
 if(x1<=x0||y1<=y0)return;c.fillStyle=color;c.fillRect(x0,y0,x1-x0,y1-y0);
}
function localPainter(c,o,bw,bh){
 const w=o.w??bw,h=o.h??bh,x=Math.round(o.x),y=Math.round(o.y);
 return (color,px,py,pw=1,ph=1)=>rect(c,color,x+px*w/bw,y+py*h/bh,pw*w/bw,ph*h/bh);
}
function mask(r,rows,color,x=0,y=0){for(let yy=0;yy<rows.length;yy++)for(let xx=0;xx<rows[yy].length;xx++)if(rows[yy][xx]!=='0'&&rows[yy][xx]!=='.')r(color,x+xx,y+yy);}
function pixelLine(c,a,b,color,size=1){
 let x=Math.round(a.x),y=Math.round(a.y),tx=Math.round(b.x),ty=Math.round(b.y),dx=Math.abs(tx-x),dy=-Math.abs(ty-y),sx=x<tx?1:-1,sy=y<ty?1:-1,err=dx+dy;
 for(;;){rect(c,color,x-Math.floor(size/2),y-Math.floor(size/2),size,size);if(x===tx&&y===ty)break;const e=2*err;if(e>=dy){err+=dy;x+=sx;}if(e<=dx){err+=dx;y+=sy;}}
}

export function drawContraptionsBackground(c,room,w,h){if(!enabled(room))return false;rect(c,P.sky,0,0,w,h);return true;}

// Original scalloped clouds: no diagnostic outline or text, and no collision.
function cloud(c,o){
 const r=localPainter(c,{...o,w:o.w??48,h:o.h??24},48,24);
 for(const [x,y,w,h]of [[0,12,48,8],[3,9,42,12],[7,5,10,16],[10,2,5,19],[20,4,11,17],[24,0,4,21],[33,7,9,14],[38,4,4,17],[45,15,3,5]])r(P.skyShadow,x+1,y+1,w,h);
 for(const [x,y,w,h]of [[0,12,47,7],[3,9,40,11],[7,5,10,15],[10,2,5,18],[20,4,11,16],[24,0,4,20],[33,7,9,13],[38,4,4,16],[45,15,3,4]])r(P.white,x,y,w,h);
 for(const [x,y,w,h]of [[3,18,6,2],[7,20,6,2],[12,18,8,3],[20,20,7,2],[27,18,8,3],[35,20,8,2],[43,18,4,2]])r(P.cyan,x,y,w,h);
 for(const [x,y]of [[10,6],[24,4],[38,8]]){r(P.cyan,x,y,3,1);r(P.cyan,x+1,y-1,1,1);}
}
function dune(c,points,bottom,left,right){
 for(let i=1;i<points.length;i++){
  const a=point(points[i-1]),b=point(points[i]),x0=Math.max(Math.floor(a.x),left),x1=Math.min(Math.ceil(b.x),right);
  if(b.x<=a.x)continue;
  for(let x=x0;x<x1;x++){const y=Math.round(a.y+(b.y-a.y)*((x-a.x)/(b.x-a.x)));rect(c,P.sandEdge,x,y,1,bottom-y);rect(c,P.sand,x,y+2,1,bottom-y-2);}
 }
}
function backgroundCactus(c,o){
 const r=localPainter(c,{...o,w:o.w??10,h:o.h??36},10,36),color=P.sandEdge;
 // Only pale outlines, with open sky between branches: visibly scenery.
 r(color,4,2,3,1);r(color,3,3,1,30);r(color,7,3,1,30);r(color,4,33,3,1);
 r(color,1,14,1,9);r(color,0,14,1,1);r(color,0,23,4,1);r(color,8,10,1,8);r(color,9,10,1,1);r(color,7,18,3,1);
 for(const y of [12,22]){r(color,4,y,3,1);r(color,4,y+1,1,1);r(color,6,y+1,1,1);}
}
/** Draw before solid terrain. Parent may call Scene with backdrop:false after it. */
export function drawContraptionsBackdrop(c,room){
 if(!enabled(room))return false;
 const authored=room.contraptions||{},v=room.renderBounds||{x:0,w:room.map?.width||384},bottom=room.map?.height||224,left=Math.floor(v.x)-2,right=Math.ceil(v.x+v.w)+2;
 const dunes=authored.dunes;
 if(Array.isArray(dunes))for(const d of dunes)dune(c,d.points||d,bottom,left,right);
 else for(let page=Math.floor(left/384);page<=Math.floor(right/384);page++){
  const b=page*384;dune(c,[[b,166],[b+64,146],[b+126,175],[b+160,162],[b+194,176],[b+224,162],[b+286,192],[b+352,166],[b+384,166]],bottom,left,right);
 }
 const clouds=authored.clouds??[{x:48,y:66,w:48,h:24},{x:160,y:52,w:64,h:24},{x:304,y:70,w:32,h:24}];
 for(const o of clouds)if(o.x+(o.w||48)>=left&&o.x<=right)cloud(c,o);
 const cacti=authored.backgroundCacti??[{x:110,y:190,w:10,h:25},{x:165,y:176,w:10,h:40}];
 for(const o of cacti)if(o.x+(o.w||10)>=left&&o.x<=right)backgroundCactus(c,o);
 return true;
}

function groundCell(c,x,y){
 rect(c,P.ground,x,y,16,16);
 // Diagonal light stone faces and tan grain are authored from small integers.
 for(let py=0;py<16;py++)for(let px=0;px<16;px++){
  const n=(px+py+2)%16;
  if(n<3)rect(c,P.groundDark,x+px,y+py);
  else if(n<7)rect(c,P.groundGold,x+px,y+py);
  else if(n<11)rect(c,P.groundLight,x+px,y+py);
 }
 rect(c,P.groundGold,x,y,16,1);rect(c,P.groundLight,x+1,y+1,14,1);rect(c,P.groundDark,x+15,y,1,16);rect(c,P.groundDark,x,y+15,16,1);
 for(const [px,py]of [[3,4],[4,6],[6,8],[11,11],[12,13]])rect(c,P.groundGold,x+px,y+py);
}
function tiled(c,q,draw){
 const w=q.w??16,h=q.h??16;if(w<=0||h<=0)return;c.save();c.beginPath();c.rect(Math.round(q.x),Math.round(q.y),Math.round(w),Math.round(h));c.clip();
 for(let y=q.y;y<q.y+h;y+=16)for(let x=q.x;x<q.x+w;x+=16)draw(c,Math.round(x),Math.round(y));c.restore();
}
export function drawNote(c,o){
 const bump=o.bump?Math.round(Math.sin(o.bump/12*Math.PI)*5):0,r=localPainter(c,{...o,y:o.y-bump},16,16);
 r(P.skyShadow,2,2,16,16);r(P.ink,0,1,16,14);r(P.ink,1,0,14,16);r(P.white,1,1,14,14);r('#b8b3b2',14,2,1,12);r('#b8b3b2',2,14,12,1);
 r(P.ink,10,3,1,9);r(P.ink,11,3,1,2);r(P.ink,12,4,1,2);r(P.ink,8,10,3,3);r(P.ink,5,11,5,3);r(P.ink,6,14,3,1);
}
export function drawContraptionsTile(c,q,room={}){
 if(q.pBody)return true; // The item's native one-way collider has no tile art.
 if(!enabled(room))return false;
 if(q.material==='desert-ground'||q.studyArt==='desert-ground'){tiled(c,q,groundCell);return true;}
 if(['contraption-note','study-note','note-block'].includes(q.material)||q.contraptionNote||q.studyArt==='contraption-note'){drawNote(c,{...q,bump:0});return true;}
 if(q.material==='ps-block'){
  const state=live(room),d=state.psBlocks?.find(d=>d.id===(q.sourceId||q.id))||q,form=d.form||d.currentMaterial||d.state||(d.coin?'coin':'brick');
  if(d.collected||d.hidden)return true;
  tiled(c,q,(ctx,x,y)=>classicDraw(ctx,form==='coin'?'coin0':'brick',x+(form==='coin'?3:0),y));return true;
 }
 return false;
}

function trackPoints(track){
 if(track.start&&track.segments){const out=[point(track.start)];let a=out[0];
  for(const s of track.segments){const b=point(s.to),control=point(s.control);if(!finitePoint(a)||!finitePoint(b))continue;
   const n=Math.max(1,Math.ceil(Math.hypot(b.x-a.x,b.y-a.y)+(finitePoint(control)?Math.hypot(control.x-a.x,control.y-a.y)+Math.hypot(b.x-control.x,b.y-control.y):0)));
   for(let i=1;i<=n;i++){const t=i/n,u=1-t;out.push(s.kind==='quadratic'&&finitePoint(control)?{x:u*u*a.x+2*u*t*control.x+t*t*b.x,y:u*u*a.y+2*u*t*control.y+t*t*b.y}:{x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t});}a=b;
  }return out;
 }
 const input=(track.points||track.normalized_16px_centerline_points||[]).map(point).filter(finitePoint),out=input.length?[input[0]]:[];
 for(let i=1;i<input.length;i++){const a=input[i-1],b=input[i],n=Math.max(1,Math.ceil(Math.hypot(b.x-a.x,b.y-a.y)));for(let j=1;j<=n;j++)out.push({x:a.x+(b.x-a.x)*j/n,y:a.y+(b.y-a.y)*j/n});}return out;
}
function trackEnd(c,p){rect(c,P.rail,p.x-4,p.y-4,8,8);rect(c,P.white,p.x-3,p.y-3,6,6);rect(c,P.rail,p.x-2,p.y-2,4,4);rect(c,P.white,p.x,p.y,1,1);}
export function drawTrack(c,track){
 const points=trackPoints(track);if(points.length<2)return false;let d=0;
 for(let i=1;i<points.length;i++){pixelLine(c,points[i-1],points[i],P.rail,3);}
 for(let i=0;i<points.length;i++){if(i)d+=Math.hypot(points[i].x-points[i-1].x,points[i].y-points[i-1].y);if(Math.floor(d)%10<8)rect(c,P.white,points[i].x,points[i].y);}
 if(track.mode!=='loop'){trackEnd(c,points[0]);trackEnd(c,points.at(-1));}return true;
}
function ring(c,x,y){
 const r=(color,px,py,w=1,h=1)=>rect(c,color,x+px-3,y+py-3,w,h);
 mask(r,['001100','011110','110011','110011','011110','001100'],P.rail);
 mask(r,['000000','001100','010010','010010','001100','000000'],P.white);
}
function wheel(c,p,size=10){
 const r=localPainter(c,{x:p.x-size/2,y:p.y-size/2,w:size,h:size},10,10);
 mask(r,['0011111100','0111111110','1111111111','1111111111','1111111111','1111111111','1111111111','1111111111','0111111110','0011111100'],P.copperDark);
 r(P.copper,2,1,6,8);r(P.copper,1,2,8,6);r(P.copperLight,3,2,4,1);r(P.copperLight,2,3,1,4);r(P.copperLight,4,3,3,4);r(P.copperDark,4,4,2,2);
}
function staticClawPose(o,tracks){
 if(finitePoint(o.anchor)&&finitePoint(o.grip))return o;
 const track=tracks.find(t=>t.id===o.trackId),points=track?trackPoints(track):[],total=points.reduce((n,p,i)=>i?n+Math.hypot(p.x-points[i-1].x,p.y-points[i-1].y):0,0);
 let remaining=Math.max(0,Math.min(total,o.position??0)),anchor=point(o.anchor)||points[0]||{x:o.x??0,y:o.y??0};
 for(let i=1;i<points.length;i++){const a=points[i-1],b=points[i],length=Math.hypot(b.x-a.x,b.y-a.y);if(remaining<=length){const t=length?remaining/length:0;anchor={x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t};break;}remaining-=length;anchor=b;}
 const angle=o.angleRadians??((o.swingDegrees??18)*Math.PI/180*Math.sin((o.swingPhaseDegrees??0)*Math.PI/180)),rope=o.ropeLength??42;
 return {...o,anchor,grip:{x:anchor.x+Math.sin(angle)*rope,y:anchor.y+Math.cos(angle)*rope}};
}
export function drawClaw(c,o){
 const a=point(o.anchor)||{x:o.x,y:o.y},g=point(o.grip)||{x:a.x,y:a.y+(o.ropeLength??42)};if(!finitePoint(a)||!finitePoint(g))return false;
 const dx=g.x-a.x,dy=g.y-a.y,length=Math.hypot(dx,dy);
 for(let d=9;d<length-5;d+=8)ring(c,a.x+dx*d/length,a.y+dy*d/length);
 wheel(c,a);const held=o.heldId!=null||o.heldKind!=null||o.closed,spread=held?13:(o.fingerSpread??21),cy=g.y-4;
 for(const direction of [-1,1]){
  const outer={x:g.x+direction*spread,y:cy-1},tip={x:g.x+direction*(held?8:spread+3),y:cy+10},elbow={x:g.x+direction*(spread-3),y:cy-5},root={x:g.x+direction*5,y:cy-3};
  for(const [from,to]of [[root,elbow],[elbow,outer],[outer,tip]]){pixelLine(c,from,to,P.copperDark,5);pixelLine(c,from,to,P.copper,3);pixelLine(c,{x:from.x,y:from.y-1},{x:to.x,y:to.y-1},P.copperLight,1);}
 }
 wheel(c,{x:g.x,y:cy+1},9);return true;
}

// Default workshop artwork is SMB1; explicit other styles remain adaptations.
const originalKeyDoorArt=room=>!isSmb3ArtRoom(room)&&(!room?.smm2Mechanics?.art?.palette||/^smb1-/.test(room.smm2Mechanics.art.palette));
function sourceAtActorBase(c,name,o,scale=1){
 const source=SMM1_SMB1_KEY_DOOR_SOURCE_PIXELS[name];
 // Native pixels have their own bottom/centre anchor, independent of collision.
 const x=Math.round(o.x+((o.w??16)-source.w*scale)/2),y=Math.round(o.y+(o.h??source.h)-source.h*scale);
 if(scale!==1){
  // Inventory effects are also drawn while the editor's synthetic DOM and the
  // native recording Canvas coexist. Draw the same source cells through the
  // caller's context rather than handing it a canvas from another DOM host.
  if(o.inventoryPresentation===true)return drawSmm2SourcePixels(c,name,{x,y,scale});
  c.save();c.imageSmoothingEnabled=false;c.drawImage(keySourceCanvas(),x,y,source.w*scale,source.h*scale);c.restore();return true;
 }
 return drawSmm2SourcePixels(c,name,{x,y});
}
export function drawKey(c,o,room={}){
 if(originalKeyDoorArt(room)){
  const w=o.w??16,h=o.h??16,native=w===h&&[12,14,16].includes(w),scale=native?1:Math.min(w/16,h/16);
  sourceAtActorBase(c,'smb1Key',o,scale);return;
 }
 const r=localPainter(c,o,16,16);mask(r,['00111100','01111110','11000011','11000011','11000011','11000011','01111110','00111100'],P.copperDark,4,0);
 mask(r,['00011000','00111100','01100110','01000010','01000010','01100110','00111100','00011000'],P.groundLight,4,0);
 r(P.copperDark,6,7,4,7);r(P.groundGold,7,7,2,7);r(P.copperDark,3,11,5,3);r(P.groundLight,3,11,4,1);r(P.copperDark,3,13,2,2);r(P.copperDark,6,13,2,2);
}
let keySourceSprite;
function keySourceCanvas(){
 const source=SMM1_SMB1_KEY_DOOR_SOURCE_PIXELS.smb1Key;
 if(!keySourceSprite){keySourceSprite=document.createElement('canvas');keySourceSprite.width=source.w;keySourceSprite.height=source.h;drawSmm2SourcePixels(keySourceSprite.getContext('2d'),'smb1Key',{x:0,y:0});}
 return keySourceSprite;
}
/** The unchanged 12px HUD slot uses a uniform nearest-neighbour UI thumbnail.
 * Its 10.5 x 12 display is separate from native world pixels and colliders. */
export function drawKeyHud(c,o,room={}){
 if(!originalKeyDoorArt(room)){drawKey(c,o,room);return;}
 const source=SMM1_SMB1_KEY_DOOR_SOURCE_PIXELS.smb1Key;
 const width=o.w??12,height=o.h??12,scale=Math.min(width/source.w,height/source.h),w=source.w*scale,h=source.h*scale;
 c.save();c.imageSmoothingEnabled=false;c.drawImage(keySourceCanvas(),o.x+(width-w)/2,o.y+height-h,w,h);c.restore();
}
export function drawPSwitch(c,o){
 // Pipe-supplied and authored P items share the attributed source frame.
 // Their native item controllers still own the live/pressed body geometry.
 return drawSmm2PSwitch(c,o);
}
export function drawDoor(c,o,room={}){
 if(drawSmwUnderwaterObject(c,{...o,kind:'door'},room))return;
 if(o.unlocked===true&&originalKeyDoorArt(room)){sourceAtActorBase(c,'smb1UnlockedDoor',o);return;}
 const r=localPainter(c,o,16,32),isReturn=o.style==='plain'||o.locked===false||o.color==='green',locked=!isReturn&&!o.unlocked,color=isReturn?P.green:P.red,dark=isReturn?P.greenDark:P.redDark;
 r(P.ink,0,0,16,32);r(P.white,1,1,14,30);r(dark,2,4,12,24);r(color,3,4,10,24);r(color,5,2,6,28);r(P.ink,2,2,2,2);r(P.ink,12,2,2,2);r(P.ink,2,28,2,2);r(P.ink,12,28,2,2);
 if(locked){r(P.white,5,11,6,8);r(P.white,7,19,3,3);r(P.ink,6,12,4,3);r(P.ink,7,14,2,7);}
 else{r(P.groundLight,11,16,2,2);if(o.unlocked&&!isReturn){r(P.ink,4,5,2,22);r(P.red,7,4,5,24);}}
}
export function drawCar(c,o,tick=0){
 // One recovered original frame; motion does not manufacture animation.
 return drawOriginalClownCar(c,o);
}
export function drawOneWayWall(c,o){
 if(o.direction==='right'){drawSmb3OneWayWall(c,o);return;}
 const r=localPainter(c,o,32,32);r(P.ink,0,0,32,32);r('#777574',1,1,30,30);r('#454446',2,2,28,24);r(P.white,2,26,28,5);r('#a8a5a2',3,27,26,3);
 for(const x of [3,27])for(const y of [3,23])r(P.ink,x,y,2,2);
 for(const top of [4,14])for(let row=0;row<7;row++){const width=16-row*2;r('#96928d',8+row,top+row,width,1);if(row<5)r(P.sky,9+row,top+row+1,width-2,1);}
}
export function drawArrow(c,o){
 const r=localPainter(c,{...o,w:o.w??32,h:o.h??16},32,16);
 for(let y=0;y<16;y++){const span=7-Math.abs(7.5-y);if(span>0)r(P.copperDark,21,y,Math.floor(span)+3,1);}
 r(P.copperDark,0,4,24,8);r(P.groundGold,1,5,23,6);
 for(let y=2;y<14;y++){const span=7-Math.abs(7.5-y);if(span>0)r(P.groundGold,22,y,Math.floor(span),1);}
 r(P.groundLight,2,6,20,1);r(P.groundLight,2,9,19,1);r(P.groundLight,22,4,2,1);r(P.groundLight,24,6,2,1);r(P.groundLight,23,10,2,1);r(P.copper,13,7,3,2);
}
function thornCell(c,x,y){
 const r=(color,px,py,w=1,h=1)=>rect(c,color,x+px,y+py,w,h);
 // Original branching hazard silhouette. Dark, dense foreground thorns are
 // deliberately different from the faint outlined background cactus.
 for(const [a,b]of [[{x:3,y:15},{x:5,y:2}],[{x:7,y:15},{x:10,y:0}],[{x:12,y:15},{x:14,y:3}],[{x:4,y:7},{x:0,y:3}],[{x:7,y:10},{x:12,y:6}],[{x:12,y:12},{x:15,y:9}]]){
  pixelLine(c,{x:x+a.x,y:y+a.y},{x:x+b.x,y:y+b.y},P.copperDark,3);pixelLine(c,{x:x+a.x,y:y+a.y},{x:x+b.x,y:y+b.y},P.copperLight,1);
 }
 for(const [px,py]of [[2,0],[5,1],[10,0],[14,1],[0,2],[12,5],[15,8]])r(P.copper,px,py,1,4);
}
export function drawContraptionsActor(c,o,tick=0,room={}){
 const kind=o.type||o.skin||o.kind;
 // Existing loose/placed native keys already enter the shared actor renderer.
 // Their artwork is independent of the optional desert scene; no held-key
 // world icon or additional actor is synthesized here.
 if(['key','contraption-key'].includes(kind)&&originalKeyDoorArt(room)){drawKey(c,o,room);return true;}
 // A real loose P is visible in source SMB1 rooms as well as desert studies.
 // Its one-way collider is suppressed separately by drawContraptionsTile.
 if(['p-switch','p_switch','contraption-p-switch'].includes(kind)&&originalKeyDoorArt(room)){drawPSwitch(c,o);return true;}
 if(isSmb3ArtRoom(room)){
  if(kind==='claw'){drawClaw(c,o);return true;}
  if(kind==='contraption-arrow'){drawArrow(c,{...o,x:o.x-16,y:o.y-8});return true;}
  return false;
 }
 if(!enabled(room))return false;
 if(o.kind==='portal'){const door=(live(room).doors||room.contraptions?.doors||[]).find(d=>d.id===(o.sourceId||o.id));if(door){drawDoor(c,{...o,...door},room);return true;}}
 if(['key','contraption-key'].includes(kind)){drawKey(c,o,room);return true;}
 if(['p-switch','p_switch','contraption-p-switch'].includes(kind)){drawPSwitch(c,o);return true;}
 if(['clown-car','koopa-clown-car','koopa_clown_car'].includes(kind)){drawCar(c,o,tick);return true;}
 if(['key-door','return-door','contraption-door'].includes(kind)){drawDoor(c,o,room);return true;}
 if(kind==='one-way-wall'&&o.direction==='down'){drawOneWayWall(c,o);return true;}
 if(kind==='hazard'||kind==='desert-thorn'){tiled(c,{...o,w:o.w??16,h:o.h??16},thornCell);return true;}
 if(kind==='contraption-note'){drawNote(c,o);return true;}
 if(kind==='contraption-arrow'){drawArrow(c,{...o,x:o.x-16,y:o.y-8});return true;}
 if(kind==='claw'){drawClaw(c,o);return true;}
 return false;
}
/** World machinery sits after terrain and before NPCs/car/player. Defaults
 * include the backdrop for standalone authoring; split layers in live play. */
export function drawContraptionsScene(c,room={},options={}){
 const state=live(room),tracks=state.tracks||room.contraptions?.tracks||[],claws=state.claws||room.contraptions?.claws||[];
 // Tracks and their machinery belong to the authored room in every theme.
 // The desert backdrop remains an opt-in appearance, independent of the rails.
 if(!enabled(room)&&!isSmb3ArtRoom(room)&&!tracks.length&&!claws.length)return false;if(enabled(room)&&options.backdrop!==false)drawContraptionsBackdrop(c,room);
 for(const track of tracks)drawTrack(c,track);
 for(const claw of claws)drawClaw(c,staticClawPose(claw,tracks));
 // This scenery marker is a measured center point, like the source pole point,
 // rather than a collider/top-left rectangle. Keep the arrowhead in view.
 for(const marker of room.markers||[])if(marker.kind==='contraption-arrow')drawArrow(c,{...marker,x:marker.x-16,y:marker.y-8});
 return true;
}
