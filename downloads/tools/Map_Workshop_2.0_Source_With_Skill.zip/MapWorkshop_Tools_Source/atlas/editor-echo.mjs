import {drawPlayer,drawPixelText} from './editor-art.mjs';
/** Independent opt-in room extension. The tape stores poses, never collidable actors. */
export const ECHO_TYPE='echo-cooperation', ECHO_VERSION=1, ECHO_FRAMES=360;
const clone=x=>JSON.parse(JSON.stringify(x));
const finite=n=>Number.isFinite(n);
const overlaps=(a,b)=>a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y;
export const echoEnabled=room=>room?.mechanics?.type===ECHO_TYPE&&room.mechanics.version===ECHO_VERSION;
export function validateEchoRoom(room){
 const mechanics=room.mechanics,devices=room.devices;
 if(mechanics===undefined){if(devices?.length)throw Error('回声机关需要 echo-cooperation 机制');return;}
 if(!mechanics||mechanics.type!==ECHO_TYPE||mechanics.version!==ECHO_VERSION)throw Error('未知房间机制或版本');
 for(const key of Object.keys(mechanics))if(!['type','version','maxFrames','anchorSpawn','instructions'].includes(key))throw Error('未知回声机制字段：'+key);
 if(mechanics.maxFrames!==undefined&&mechanics.maxFrames!==ECHO_FRAMES)throw Error('回声录制必须为 360 帧（6 秒）');
 if(mechanics.instructions!==undefined&&(typeof mechanics.instructions!=='string'||mechanics.instructions.length>500))throw Error('回声说明无效');
 if(mechanics.anchorSpawn!==undefined&&!room.map.objects.some(o=>o.kind==='spawn'&&o.id===mechanics.anchorSpawn))throw Error('回声锚点出生点不存在');
 if(room.playHero==='bill')throw Error('回声合作原型目前仅支持马里奥');
 if(!Array.isArray(devices)||devices.length>128)throw Error('回声机关列表无效');
 const ids=new Set([...room.map.geometry,...room.map.objects].map(q=>q.id));
 for(const device of devices){
  if(!device||typeof device.id!=='string'||!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(device.id)||device.id.length>72||ids.has(device.id))throw Error('回声机关标识重复或无效');ids.add(device.id);
  if(!['plate','gate','bridge'].includes(device.kind))throw Error('未知回声机关类型');
  if(!['x','y','w','h'].every(k=>finite(device[k]))||device.x<0||device.y<0||device.w<=0||device.h<=0||device.x+device.w>room.map.width||device.y+device.h>room.map.height)throw Error('回声机关超出房间或坐标无效');
  if(typeof device.label!=='string'||!/^[A-Z][A-Z0-9+ -]{0,7}$/.test(device.label))throw Error('回声机关需要简短 A/B/C 标签');
  if(device.color!==undefined&&!/^#[\da-f]{6}$/i.test(device.color))throw Error('回声机关颜色无效');
  if(device.kind==='plate'){
   if(!['ghost','live'].includes(device.actor)||device.requires!==undefined||device.requiresOff!==undefined||device.latch!==undefined||device.wireY!==undefined)throw Error('踏板须标记 ghost 或 live');
  }else{
   for(const key of ['requires','requiresOff'])if(device[key]!==undefined&&(!Array.isArray(device[key])||device[key].some(id=>typeof id!=='string')||new Set(device[key]).size!==device[key].length))throw Error('门或桥需要有效踏板关联：'+key);
   const on=device.requires||[],off=device.requiresOff||[];
   if(!on.length&&!off.length||on.length+off.length>16||on.some(id=>off.includes(id)))throw Error('门或桥需要不重叠的 ON / OFF 踏板关联');
   if(device.latch!==undefined&&typeof device.latch!=='boolean')throw Error('回声锁存参数无效');
   if(device.material!==undefined&&!['bridge','castle','stone','platform'].includes(device.material))throw Error('请使用原生桥或石块素材');
   if(device.wireY!==undefined&&(!finite(device.wireY)||device.wireY<0||device.wireY>room.map.height))throw Error('回声连线高度无效');
  }
 }
 const plates=new Set(devices.filter(d=>d.kind==='plate').map(d=>d.id));
 for(const device of devices)for(const id of [...device.requires||[],...device.requiresOff||[]])if(!plates.has(id))throw Error('回声机关关联踏板不存在：'+id);
}
const pose=p=>{
 const q={};for(const key of ['x','y','w','h','vx','vy','facing','grounded','power','anim','crouch','swimming','swimStroke','onVine','springId'])if(p[key]!==undefined)q[key]=p[key];
 return q;
};
export function pressureContact(actor,plate){
 return !!actor&&!actor.dying&&!!actor.grounded&&actor.x+actor.w>plate.x+1&&actor.x<plate.x+plate.w-1&&actor.y+actor.h>=plate.y-2&&actor.y+actor.h<=plate.y+plate.h+2;
}
export function createEchoRecorder(room){
 validateEchoRoom(room);
 if(!echoEnabled(room))return null;
 const specs=clone(room.devices);let phase='idle',draft=[],savedTape=null,savedJson=null,savedDigest=null,age=0,cursor=0,ghost=null;const latched=new Set(),states=new Map();
 // A draft and a committed tape have independent lifetimes. Death, a new
 // recording and retry may discard the draft, but never the saved recording.
 function cancel(){phase='idle';draft=[];age=0;cursor=0;ghost=null;latched.clear();states.clear();}
 function reset(){cancel();savedTape=savedJson=savedDigest=null;}
 function start(player){cancel();phase='recording';draft=[pose(player)];}
 function retry(){
  if(!savedTape)return false;
  cancel();phase='playing';age=savedTape.length-1;ghost={...savedTape[0],tick:0};return true;
 }
 function commit(){
  if(phase!=='recording')return false;
  savedTape=draft.map(q=>Object.freeze({...q}));Object.freeze(savedTape);
  savedJson=JSON.stringify(savedTape);
  // Deterministic diagnostic fingerprint. It is cached at commit, not rebuilt
  // from mutable ghost/device state, so callers can verify retry invariants.
  let hash=2166136261;for(let i=0;i<savedJson.length;i++){hash^=savedJson.charCodeAt(i);hash=Math.imul(hash,16777619);}
  savedDigest=(hash>>>0).toString(16).padStart(8,'0');return retry();
 }
 function beforeFrame(){if(phase==='playing'){cursor=Math.min(age,cursor+1);ghost={...savedTape[cursor],tick:cursor};if(cursor>=age)phase='holding';}}
 function afterFrame(player){if(phase!=='recording')return false;draft.push(pose(player));age++;return age>=ECHO_FRAMES;}
 function apply(geometry,player){
  const base=geometry.filter(g=>!g.echoDevice),active=new Map();
  for(const device of specs.filter(d=>d.kind==='plate')){const on=pressureContact(device.actor==='ghost'?ghost:player,device);active.set(device.id,on);states.set(device.id,{...device,active:on});}
  const colliders=[];
  for(const device of specs.filter(d=>d.kind!=='plate')){
   const pressed=(device.requires||[]).every(id=>active.get(id))&&(device.requiresOff||[]).every(id=>!active.get(id));if(device.latch&&pressed)latched.add(device.id);
   const enabled=pressed||latched.has(device.id);let solid=device.kind==='gate'?!enabled:enabled;
   // A closing doorway waits until the real player leaves its footprint.
   const deferred=device.kind==='gate'&&solid&&overlaps(player,device);if(deferred)solid=false;
   const state={...device,active:enabled,solid,latched:latched.has(device.id),deferred};states.set(device.id,state);
   if(solid)colliders.push({id:device.id,x:device.x,y:device.y,w:device.w,h:device.h,collision:'solid',material:device.material||(device.kind==='bridge'?'bridge':'stone'),echoDevice:true,dir:1,dx:0,dy:0});
  }
  return [...base,...colliders];
 }
 function pressureTimeline(){
  const plate=specs.find(d=>d.kind==='plate'&&d.actor==='ghost');if(!plate)return null;
  const tape=phase==='recording'?draft:savedTape||[],spans=[];
  for(const [frame,p] of tape.entries()){
   const active=pressureContact(p,plate),last=spans.at(-1);
   if(last&&last.active===active)last.end=frame;else spans.push({start:frame,end:frame,active});
  }
  return {plateId:plate.id,label:plate.label,source:phase==='recording'?'draft':savedTape?'saved':'empty',frames:Math.max(0,tape.length-1),spans,tailActive:spans.at(-1)?.active||false};
 }
 function view(){return {type:ECHO_TYPE,version:ECHO_VERSION,phase,currentPhase:phase,frames:age,recordingAge:phase==='recording'?age:0,cursor,maxFrames:ECHO_FRAMES,hasSavedTape:!!savedTape,savedFrames:savedTape?savedTape.length-1:0,canRetry:!!savedTape,tapeDigest:savedDigest,ghost:ghost?clone(ghost):null,devices:[...states.values()].map(clone),pressureTimeline:pressureTimeline(),holdsLastPose:true,anchorSpawn:room.mechanics.anchorSpawn||null,instructions:room.mechanics.instructions||''};}
 return Object.freeze({reset,cancel,start,commit,retry,beforeFrame,afterFrame,apply,view,serializeTape:()=>savedJson});
}
const ghostCanvases=new WeakMap();
function drawGhost(c,ghost,room){
 let canvas=ghostCanvases.get(c);
 if(!canvas){
  canvas=globalThis.document?.createElement?.('canvas')||(typeof OffscreenCanvas!=='undefined'?new OffscreenCanvas(48,48):null);
  if(canvas){canvas.width=48;canvas.height=48;ghostCanvases.set(c,canvas);}
 }
 if(canvas){
  const b=canvas.getContext('2d');b.clearRect(0,0,48,48);b.imageSmoothingEnabled=false;
  drawPlayer(b,{...ghost,x:16,y:32-ghost.h,invulnerable:0,star:0,dying:false},ghost.tick||0,room.playerSkin);
  b.save();b.globalCompositeOperation='source-atop';b.globalAlpha=.55;b.fillStyle='#69dcff';b.fillRect(0,0,48,48);b.restore();
  c.save();c.globalAlpha=.58;c.drawImage(canvas,Math.round(ghost.x-16),Math.round(ghost.y+ghost.h-32));c.restore();
 }else{c.save();c.globalAlpha=.5;drawPlayer(c,ghost,ghost.tick||0,room.playerSkin);c.restore();}
}
/** Circuit overlays describe the same direct ON/OFF predicate as the motor. */
function drawEchoRelations(c,echo,room){
 const plates=new Map(echo.devices.filter(d=>d.kind==='plate').map(d=>[d.id,d]));
 for(const d of echo.devices.filter(d=>d.kind!=='plate')){
  const links=[...(d.requires||[]).map(id=>({id,off:false})),...(d.requiresOff||[]).map(id=>({id,off:true}))];
  for(const [i,link] of links.entries()){
   const plate=plates.get(link.id);if(!plate)continue;
   const sourceX=Math.round(plate.x+plate.w/2),sourceY=plate.y-5,dir=sourceX<d.x+d.w/2?1:-1;
   const endX=dir>0?d.x-2:d.x+d.w+2;
   const rowY=Math.round(Math.max(6,Math.min((room.map?.height||240)-6,(d.wireY??Math.max(84,d.y+d.h/2-24))+i*11)));
   const endY=Math.max(d.y+Math.min(4,d.h/2),Math.min(d.y+d.h-Math.min(4,d.h/2),rowY));
   const neckX=endX-dir*7,satisfied=link.off?!plate.active:!!plate.active;
   c.strokeStyle=satisfied?'#e7f5ff':'#678497';c.lineWidth=1;c.setLineDash(link.off?[3,2]:[]);
   c.beginPath();c.moveTo(sourceX,sourceY);c.lineTo(sourceX,rowY);c.lineTo(neckX,rowY);c.lineTo(neckX,endY);c.lineTo(endX,endY);c.stroke();c.setLineDash([]);
   c.strokeRect(sourceX-2,sourceY-2,4,4);if(plate.active){c.fillStyle='#e7f5ff';c.fillRect(sourceX-1,sourceY-1,2,2);}
   // Positive arrow versus inhibitory bar: relation remains readable in monochrome.
   c.beginPath();if(link.off){c.moveTo(endX,endY-4);c.lineTo(endX,endY+4);}else{c.moveTo(endX-dir*4,endY-3);c.lineTo(endX,endY);c.lineTo(endX-dir*4,endY+3);}c.stroke();
   const text=plate.label+(link.off?' OFF':' ON'),textX=Math.round(Math.abs(neckX-sourceX)>=text.length*5+12?(sourceX+neckX)/2:sourceX-dir*(text.length*2.5+8)),textY=rowY-6;
   c.fillStyle='rgba(4,12,22,.9)';c.fillRect(textX-text.length*2.5-2,textY-5,text.length*5+4,10);
   c.fillStyle=satisfied?'#fff':'#a6bdcb';c.fillText(text,textX,textY);
  }
 }
}
function drawEchoFactorySign(c,room){
 const number=room.map?.title?.match(/^(\d{2})(?:\s|[·.])/)?.[1];if(!number)return;
 c.fillStyle='rgba(4,12,22,.9)';c.fillRect(8,80,48,34);c.strokeStyle='#69dcff';c.strokeRect(8.5,80.5,47,33);
 c.fillStyle='#b8ecff';c.fillText('时间工厂',32,87);c.fillText(number,43,103);
 // A UI hourglass, deliberately outlined on a dark sign rather than tile art.
 c.beginPath();c.moveTo(14,95);c.lineTo(25,95);c.lineTo(25,97);c.lineTo(14,109);c.lineTo(25,109);c.lineTo(25,107);c.lineTo(14,97);c.lineTo(14,95);c.stroke();
 c.beginPath();c.moveTo(17,97);c.lineTo(22,97);c.moveTo(19.5,103);c.lineTo(19.5,105);c.moveTo(17,107);c.lineTo(22,107);c.stroke();
}
/** World-space overlay. Terrain beneath active colliders still uses the native atlas. */
export function drawEchoWorld(c,echo,room={}){
 if(!echo)return;c.save();c.lineWidth=1;c.textAlign='center';c.textBaseline='middle';c.font='8px ChillBitmap, monospace';
 drawEchoRelations(c,echo,room);
 for(const d of echo.devices){
  const color=d.kind==='plate'?(d.actor==='ghost'?'#69dcff':'#ffbd61'):'#69dcff';
  if(d.kind==='plate'){
   c.fillStyle='#172632';c.fillRect(d.x,d.y-3,d.w,4);c.fillStyle=d.active?color:'#405669';c.fillRect(d.x+1,d.y-2,d.w-2,2);
   c.strokeStyle=color;c.strokeRect(d.x+.5,d.y-3.5,d.w-1,4);c.fillStyle=d.active?'#fff':color;c.fillText(d.label+(d.active?' ON':' OFF'),Math.round(d.x+d.w/2),d.y-10);
   // Two small blue diamonds versus a single warm live-person marker.
   c.fillRect(d.x+2,d.y-6,2,2);if(d.actor==='ghost')c.fillRect(d.x+6,d.y-6,2,2);
  }else{
   c.strokeStyle=d.active?'#b1f29a':color;c.setLineDash(d.solid?[]:[2,3]);c.strokeRect(d.x+.5,d.y+.5,d.w-1,d.h-1);c.setLineDash([]);
   c.fillStyle=d.active?'#b1f29a':color;c.fillRect(d.x,d.y,Math.min(d.w,16),3);c.fillText(d.label,Math.round(d.x+d.w/2),d.kind==='gate'?Math.max(78,d.y+d.h/2):d.y-6);
   const status=d.kind==='gate'?(d.deferred?'WAIT':d.solid?'SHUT':'OPEN'):(d.solid?'SOLID':'GAP'),statusY=d.kind==='gate'?Math.max(88,d.y+d.h-10):d.y+10;
   const statusX=Math.round(d.x+d.w/2);c.fillStyle='rgba(4,12,22,.9)';c.fillRect(statusX-status.length*2.5-2,statusY-5,status.length*5+4,10);c.fillStyle='#fff';c.fillText(status,statusX,statusY);
   if(d.latched){c.fillStyle='#b1f29a';c.fillRect(d.x+2,d.y+5,3,3);c.fillStyle='rgba(4,12,22,.9)';c.fillRect(statusX-12,statusY-15,24,10);c.fillStyle='#b1f29a';c.fillText('LOCK',statusX,statusY-10);}
  }
 }
 for(const portal of room.map?.objects?.filter(o=>o.kind==='portal')||[]){c.strokeStyle='#b1f29a';c.strokeRect(portal.x+.5,portal.y+.5,portal.w-1,portal.h-1);c.fillStyle='rgba(67,123,60,.18)';c.fillRect(portal.x+1,portal.y+1,portal.w-2,portal.h-2);c.fillStyle='#b1f29a';c.fillText(echo.inputLabels?.interact||'E',Math.round(portal.x+portal.w/2),Math.round(portal.y+portal.h/2));c.fillText('下一室',Math.round(portal.x+portal.w/2),portal.y-6);}
 drawEchoFactorySign(c,room);
 if(echo.ghost)drawGhost(c,echo.ghost,room);
 c.restore();
}
/** Screen-space HUD (256x240 logical pixels), below the stock Mario score line. */
export function drawEchoHud(c,echo){
 if(!echo)return;c.save();c.fillStyle='rgba(4,12,22,.88)';c.fillRect(4,34,248,40);c.fillStyle='#69dcff';
 c.font='8px ChillBitmap';c.textAlign='left';c.textBaseline='top';
 const labels=echo.inputLabels||{record:'R',retry:'T',clear:'C'},recordKey=labels.record,retryKey=labels.retry,clearKey=labels.clear;
 const status=echo.phase==='recording'?'REC':echo.phase==='playing'?'PLAY':echo.phase==='holding'?'HOLD':'READY';
 drawPixelText(c,status,8,38);c.fillStyle='#69dcff';c.font='8px ChillBitmap';
 c.fillText(recordKey+(echo.phase==='recording'?' 保存本次录制':' 从锚点新录制'),52,37);
 c.fillStyle=echo.canRetry?'#b1f29a':'#7c92a5';c.fillText(retryKey+' 重试上次 · '+clearKey+(echo.inputLabels?.mode==='controller'?' 长按清空':' 清空'),8,47);
 c.fillStyle='#b2c5d6';c.fillText(echo.hasSavedTape?'缓存 '+echo.savedFrames+'帧':'尚无缓存',166,47);
 c.fillStyle='#344354';c.fillRect(8,58,222,4);const count=echo.phase==='recording'?echo.frames:echo.cursor;
 if(echo.pressureTimeline){
  for(const span of echo.pressureTimeline.spans){
   const start=8+Math.min(221,Math.floor(222*span.start/echo.maxFrames)),end=8+Math.min(222,Math.ceil(222*(span.end+1)/echo.maxFrames)),width=Math.max(1,end-start);
   c.fillStyle=span.active?'#69dcff':'#627386';c.fillRect(start,58,width,4);c.fillStyle=span.active?'#fff':'#263744';
   if(span.active){if(width>=5){const middle=start+Math.floor(width/2);c.fillRect(middle-1,59,3,1);c.fillRect(middle,58,1,3);}}else for(let x=start;x<end;x+=4)c.fillRect(x,59,Math.min(2,end-x),2);
  }
 }else{c.fillStyle=echo.phase==='recording'?'#ff765e':'#69dcff';c.fillRect(8,58,Math.round(222*count/echo.maxFrames),4);}
 c.fillStyle='#fff';c.fillRect(8+Math.min(222,Math.round(222*count/echo.maxFrames)),57,1,6);c.fillText('6s',232,56);
 const timelineLegend=echo.pressureTimeline?echo.pressureTimeline.label+' +踩下 -松开 · 蓝=影子 橙=本人':'蓝=影子 橙=本人 · 影子不碰人/道具';
 const holdText=echo.pressureTimeline?'影子停最后帧 '+echo.pressureTimeline.label+(echo.pressureTimeline.tailActive?' ON':' OFF')+' · '+retryKey+' 原样重播':'影子停最后一帧 · '+retryKey+' 原样重播';
 c.fillStyle='#b2c5d6';c.fillText(echo.phase==='recording'&&echo.hasSavedTape?'新草稿未保存 · '+retryKey+' 可找回旧录制':echo.phase==='holding'?holdText:timelineLegend,8,65);c.restore();
}
