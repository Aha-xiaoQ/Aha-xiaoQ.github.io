import {validateLakituCloudPlacement} from './editor-lakitu-placement.mjs';
import {validateSmm2SnakeBlockPlacement} from './editor-snake-block-placement.mjs';
import {sourceType} from './map-appearance.mjs';
import {createSMM2Terrain} from './editor-smm2-terrain.mjs';
import {validateSmm2CarriersRoom} from './editor-smm2-carriers.mjs';
import {blockContent,blockContentIssues} from './editor-block-content.mjs';

const EPS=1e-7;
const box=q=>({x:q.x,y:q.y,w:q.w,h:q.h});
const rectangle=q=>q&&['x','y','w','h'].every(k=>Number.isFinite(q[k]))&&q.w>0&&q.h>0;
export const placementOverlap=(a,b)=>a.x<b.x+b.w-EPS&&a.x+a.w>b.x+EPS&&a.y<b.y+b.h-EPS&&a.y+a.h>b.y+EPS;
const knownSolids=new Set(['Floor','Brick','Block','Stone','Pipe','PipeVertical','PipeHorizontal','TreeTop','ShroomTop','BridgeBase','CastleBlock','Coral','Cannon','Springboard']);
/** Strict separating-axis overlap against the controller's actual convex polygon. */
export function polygonPlacementOverlap(rect,polygon){
 const a=[{x:rect.x,y:rect.y},{x:rect.x+rect.w,y:rect.y},{x:rect.x+rect.w,y:rect.y+rect.h},{x:rect.x,y:rect.y+rect.h}],axes=[{x:1,y:0},{x:0,y:1}];
 for(let n=0;n<polygon.length;n++){const p=polygon[n],q=polygon[(n+1)%polygon.length],dx=q.x-p.x,dy=q.y-p.y,length=Math.hypot(dx,dy);if(length>EPS)axes.push({x:-dy/length,y:dx/length});}
 for(const axis of axes){const range=points=>{const dots=points.map(p=>p.x*axis.x+p.y*axis.y);return [Math.min(...dots),Math.max(...dots)];},[al,ar]=range(a),[bl,br]=range(polygon);if(ar<=bl+EPS||br<=al+EPS)return false;}
 return true;
}
export function pickupType(room,q){
 if(q.kind==='coin')return 'coin';
 if(room.smm2Mechanics?.portableStones?.stones?.some(v=>v.id===q.id))return 'portable-stone';
 const item=room.smm2Mechanics?.placedItems?.find(v=>v.id===q.id);if(item)return item.kind;
 if(room.smm2Mechanics?.helmets?.some(v=>v.id===q.id))return 'buzzy-shellmet';
 return null;
}
const roomContexts=new WeakMap();
function pSources(room){
 const typed=(room.smm2Mechanics?.version===1?room.smm2Mechanics.pSwitches||[]:[]).filter(q=>room.map?.objects?.some(o=>o.id===q.id&&o.kind==='walker'&&o.w===16&&o.h===16));
 const pipes=(room.contraptions?.version===1?room.contraptions.pSources||[]:[]).filter(q=>room.map?.geometry?.some(g=>g.id===q.pipeId&&g.material==='pipe'&&g.w===32));
 return {typed,pipes};
}
/** Concrete P controllers and valid directed portal paths, never a document override. */
export function placementOptionsForRooms(rooms){
 const byId=new Map(rooms.map(r=>[r.roomId,r])),sources=rooms.map(r=>({room:r,...pSources(r)})),authoredP=sources.some(q=>q.typed.length),reachable=new Set();
 function visit(id){if(reachable.has(id))return;reachable.add(id);for(const portal of byId.get(id)?.map?.objects||[]){if(portal.kind!=='portal')continue;const target=byId.get(portal.targetRoom);if(target?.map.objects.some(o=>o.id===portal.targetSpawn&&o.kind==='spawn'))visit(target.roomId);}}
 for(const source of sources)if(source.typed.length||source.pipes.length)visit(source.room.roomId);
 const options=new Map(rooms.map(r=>[r,{pSwitchEnabled:reachable.has(r.roomId),pConversionOwned:authoredP||!!r.contraptions}]));
 for(const [room,context]of options)roomContexts.set(room,context);return options;
}
export function geometryPlacementType(room,q,options={}){
 const local=pSources(room),context={pSwitchEnabled:!!(local.typed.length||local.pipes.length),pConversionOwned:!!(local.typed.length||room.contraptions),...roomContexts.get(room),...options};

 if(q.collision!=='solid')return {type:q.collision==='oneway'?'oneway':'noncolliding',permanent:false};
 // An explicit, validated moving Spring body has its own gravity and can
 // leave this source pose. A dangling tag never grants a placement exception.
 if(room.smm2Mechanics?.carrierGeometry?.some(v=>v.id===q.id&&v.carrierType==='seesaw')){
  try{validateSmm2CarriersRoom(room);return {type:'gravity-spring-body',permanent:false};}catch{}
 }
 if(q.motion||q.liftSpeed||room.marioModules?.motionPlatforms?.[q.id]||room.marioModules?.contactPlatforms?.[q.id])return {type:'moving',permanent:false};
 if(q.hidden)return {type:'hidden-state',permanent:false};
 const kind=sourceType(room,q);
 if(kind==='Brick'&&context.pSwitchEnabled&&context.pConversionOwned&&!blockContent(q)&&!room.markers?.some(m=>m.x===q.x&&m.y===q.y&&m.source?.contents)&&!room.semantics?.some(s=>s.id===(q.sourceId||q.id)&&s.source?.contents))return {type:'p-convertible-brick',permanent:false};
 if(kind==='CastleBridge'||room.markers?.some(m=>m.kind==='coupled-scale'&&(q.id===m.id+'-left'||q.id===m.id+'-right')))return {type:'mechanism-owned',permanent:false};
 if((q.material===undefined&&!room.semantics?.some(s=>s.id===(q.sourceId||q.id)))||['cloud-solid','desert-ground'].includes(q.material)||q.smm2BlockKind==='hard-block'||knownSolids.has(kind))return {type:'permanent-solid',permanent:true};
 return {type:'unknown-solid',permanent:false};
}
export function arrivalOwnsGeometry(room,spawn,geometry){
 const rule=room.marioModules?.arrivalDirections?.[spawn.id];return !!rule&&rule.pipeId===geometry.id&&spawn.kind==='spawn';
}
function index(records){
 const grid=new Map(),wide=[];
 for(const q of records){const a=Math.floor(q.x/64),b=Math.floor((q.x+q.w-EPS)/64),c=Math.floor(q.y/64),d=Math.floor((q.y+q.h-EPS)/64);if((b-a+1)*(d-c+1)>4096){wide.push(q);continue;}for(let x=a;x<=b;x++)for(let y=c;y<=d;y++){const key=x+','+y,list=grid.get(key)||[];list.push(q);grid.set(key,list);}}
 return q=>{const result=new Set(wide);for(let x=Math.floor(q.x/64);x<=Math.floor((q.x+q.w-EPS)/64);x++)for(let y=Math.floor(q.y/64);y<=Math.floor((q.y+q.h-EPS)/64);y++)for(const r of grid.get(x+','+y)||[])result.add(r);return result;};
}
export function placementAudit(room,options={}){
 options={...roomContexts.get(room),...options};
 const issues=blockContentIssues(room),exemptions=[],contents=[],shapes=[],records=[];
 const add=(code,severity,ids,bounds,message)=>issues.push({code,severity,roomId:room.roomId,ids,bounds,message});
 const actualP=pSources(room),pIds=new Set([...actualP.typed,...actualP.pipes].map(q=>q.id));for(const source of [...(room.smm2Mechanics?.pSwitches||[]),...(room.contraptions?.pSources||[])])if(!pIds.has(source.id))add('PLACEMENT_UNKNOWN_P_SOURCE','warning',[source.id,...(source.pipeId?[source.pipeId]:[])],null,'P声明缺少匹配的当前版本身体或真实管道，不作为砖块转换许可');
 for(const source of room.marioModules?.itemSources||[])if(source.item==='p-switch')add('PLACEMENT_UNKNOWN_P_SOURCE','warning',[source.id,source.pipeId],null,'当前Mario itemSources不执行P供给，不把此声明当作砖块转换许可');
 const pickups=(room.map?.objects||[]).filter(q=>rectangle(q)&&pickupType(room,q)),poses=new Map();
 for(const q of room.map?.geometry||[]){if(!rectangle(q))continue;const classification=geometryPlacementType(room,q,options);records.push({...box(q),id:q.id,...classification});if(blockContent(q))contents.push({id:q.id,content:blockContent(q),storage:q.content===undefined?'legacy-reward':'explicit-content',bounds:box(q)});}
 if(room.smm2Mechanics?.slopes?.length){try{for(const s of createSMM2Terrain(room).surfaces().filter(q=>q.kind==='slope')){const xs=s.polygon.map(p=>p.x),ys=s.polygon.map(p=>p.y);shapes.push({id:s.id,x:Math.min(...xs),y:Math.min(...ys),w:Math.max(...xs)-Math.min(...xs),h:Math.max(...ys)-Math.min(...ys),polygon:s.polygon,type:'slope',permanent:true});}}catch(error){add('PLACEMENT_UNKNOWN_TERRAIN','warning',room.smm2Mechanics.slopes.map(q=>q.id),null,error.message);}}
 for(const source of room.smm2Mechanics?.portableStones?.stones||[]){const q=room.map?.objects?.find(a=>a.id===source.id);if(rectangle(q))records.push({...box(q),id:q.id,type:'portable-stone-body',permanent:false});}
 for(const q of room.decorations||[])if(rectangle(q))records.push({...box(q),id:q.id,type:'decoration',permanent:false});
 for(const q of [...(room.marioModules?.noteBlocks||[]),...(room.contraptions?.notes||[])])if(rectangle(q))records.push({...box(q),id:q.id,type:'permanent-note-block',permanent:true});
 for(const q of room.switchStudy?.devices||[])if(q.kind==='switch'&&rectangle(q))records.push({...box(q),id:q.id,type:'permanent-onoff-switch',permanent:true});
 for(const q of room.smm2Mechanics?.donuts||[])if(rectangle(q))records.push({...box(q),id:q.id,type:'falling-platform',permanent:false});
 for(const q of room.markers||[])if(/contents|hidden/.test(q.kind||'')&&q.source?.contents)contents.push({id:q.id,content:q.source.contents,storage:'legacy-marker',bounds:{x:q.x,y:q.y,w:16,h:16}});
 for(const q of room.semantics||[])if(q.source?.contents&&!contents.some(v=>v.id===q.id))contents.push({id:q.id,content:q.source.contents,storage:'legacy-semantics',bounds:box(room.map.geometry.find(g=>g.id===q.id)||{x:q.x,y:q.y,w:16,h:16})});
 const candidates=index([...records,...shapes]);
 for(const q of pickups){
  const type=pickupType(room,q),key=type+'\n'+q.x+'\n'+q.y,prior=poses.get(key);if(prior)add('DUPLICATE_PICKUP','error',[prior.id,q.id],box(q),'重复独立可拾物 '+type+' 位于同一位置');else poses.set(key,q);
  for(const g of candidates(q)){
   if(q.id===g.id||!placementOverlap(q,g))continue;
   if(g.polygon&&!polygonPlacementOverlap(q,g.polygon)){exemptions.push({ids:[q.id,g.id],type:'slope-empty-space',bounds:box(q)});continue;}
   if(g.permanent)add('PICKUP_SOLID_OVERLAP','error',[q.id,g.id],box(q),'独立 '+type+' 与永久实体相交；请移开，或在奖励砖的藏物设置中保存');
   else if(g.type==='unknown-solid')add('PLACEMENT_UNKNOWN_SOLID','warning',[q.id,g.id],box(q),'未知实体类型需人工检查，不自动修改或豁免');
   else exemptions.push({ids:[q.id,g.id],type:g.type,bounds:box(q)});
  }
  for(const g of room.switchStudy?.devices||[])if(g.kind==='block'&&rectangle(g)&&placementOverlap(q,g))exemptions.push({ids:[q.id,g.id],type:'onoff-state',bounds:box(q)});
 }
 for(const q of room.map?.objects||[]){
  if(q.kind==='spawn')for(const g of records)if(placementOverlap(q,g)&&arrivalOwnsGeometry(room,q,g))exemptions.push({ids:[q.id,g.id],type:'typed-pipe-arrival',bounds:box(q)});
  if(q.kind==='exit'||q.kind==='portal')for(const g of records)if(placementOverlap(q,g))exemptions.push({ids:[q.id,g.id],type:q.kind+'-trigger',bounds:box(q)});
  const owner=room.marioModules?.enemySources?.find(s=>s.shoeTemplateId===q.id),template=room.smm2Mechanics?.boneShells?.find(s=>s.id===q.id&&s.templateOnly);if(owner&&template)exemptions.push({ids:[q.id,owner.id,owner.pipeId],type:'typed-pipe-template',bounds:box(q)});
 }
 return {roomId:room.roomId,issues,contents,exemptions};
}
export const placementIssues=(room,options={})=>placementAudit(room,options).issues;
export const formatPlacementIssue=q=>q.code+' · '+q.roomId+' / '+q.ids.join(' ↔ ')+(q.bounds?' @ ('+q.bounds.x+', '+q.bounds.y+')':'')+'：'+q.message;
export function assertPlacement(room,options={}){validateLakituCloudPlacement(room,options);validateSmm2SnakeBlockPlacement(room,options);const errors=placementIssues(room,options).filter(q=>q.severity==='error');if(errors.length){const error=Error(errors.map(formatPlacementIssue).join('；'));error.issues=errors;throw error;}return room;}

/** Reversible room-level author operation, also safe outside a History host. */
export function placementMutation(room,operation){const before=structuredClone(room);try{const result=operation();assertPlacement(room);return result;}catch(error){for(const key of Object.keys(room))delete room[key];Object.assign(room,before);throw error;}}
