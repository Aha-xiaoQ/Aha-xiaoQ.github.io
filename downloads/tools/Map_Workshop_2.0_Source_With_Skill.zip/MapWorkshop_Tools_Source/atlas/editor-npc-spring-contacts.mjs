/** Opt-in NPC contacts with a STATIC vertical Spring's top.
 *
 * The observed regular-Koopa response is a short compression followed by a
 * vertical impulse. Coefficients below are authored fits, not universal SMM2
 * physics. This module does not drive gravity, horizontal AI, players, carriers,
 * spring sides/undersides, or unverified actor families.
 *
 * Leaf schema: {id, compressionFrames, launchSpeed, compressionDepth?}.
 * Both required tuning fields are NPC-specific; do not inherit the player's
 * duration/boost automatically. Units are caller ticks and caller world pixels.
 * compressionDepth defaults to min(7.2, restH - 1), an authored native-size fit.
 * The enclosing room validator owns sibling fields and geometry references.
 *
 * Bodies explicitly opt in with npcSpringEligible:true and a stable string id.
 * Call frame() before their ordinary motion, once per tick, and skip that motion
 * for its ownedActorIds. Call afterActor() after ordinary collision resolution.
 * Compression keeps vx and direction fields intact. Release clears support and
 * supplies vy=-launchSpeed; the caller resumes its own gravity/motion.
 *
 * frame's resolveBodyMotion(actor, delta, context) is the caller's swept collision
 * port. Return {body:{x,y}, blocked?, reached?}. It must resolve real ceiling/wall
 * clearance and must not teleport to the requested goal. Its context geometry
 * excludes ONLY the owned Spring. A blocked placement cancels the bounce.
 *
 * geometry() returns a detached projection. npcSpringOwned marks only an active
 * NPC compression so the legacy player loop can skip that Spring for that tick.
 * No imported spec/geometry is changed and legacy springAge is never advanced.
 */
const EPS=1e-7, CONTACT_EPS=1.01;
const finite=(n,min,max)=>Number.isFinite(n)&&n>=min&&n<=max;
const copy=v=>structuredClone(v);
const fail=s=>{throw new Error(s);};
const safeId=id=>typeof id==='string'&&id.length>0&&id.length<=200&&!['__proto__','prototype','constructor'].includes(id);
const rect=a=>a&&['x','y','w','h'].every(k=>Number.isFinite(a[k]))&&a.w>0&&a.h>0;
const eligible=a=>rect(a)&&safeId(a.id)&&a.npcSpringEligible===true&&a.kind!=='player'&&a.type!=='player'&&a.active!==false&&!a.dead&&!a.dying&&!a.removed&&!a.taken&&!a.emerge&&!a.emerging&&!a.moduleEmergence;
const span=(a,q)=>a.x+a.w>q.x+EPS&&a.x<q.x+q.w-EPS;

export function validateNpcSpringContactSpec(spec){
 if(!spec||typeof spec!=='object'||Array.isArray(spec)||![Object.prototype,null].includes(Object.getPrototypeOf(spec)))fail('Invalid NPC Spring contact spec');
 for(const k of Object.keys(spec))if(!['id','compressionFrames','launchSpeed','compressionDepth'].includes(k))fail('Unknown NPC Spring contact field: '+k);
 if(!safeId(spec.id)||spec.id.length>72)fail('Invalid NPC Spring ID');
 if(!Number.isInteger(spec.compressionFrames)||!finite(spec.compressionFrames,1,600))fail('Invalid NPC Spring compressionFrames');
 if(!finite(spec.launchSpeed,.001,64))fail('Invalid NPC Spring launchSpeed');
 if(spec.compressionDepth!==undefined&&!finite(spec.compressionDepth,.001,64))fail('Invalid NPC Spring compressionDepth');
 return true;
}

export function createNpcSpringContacts(specs=[],{emit=()=>{}}={}){
 if(!Array.isArray(specs)||specs.length>256)fail('Invalid NPC Spring contacts list');
 if(typeof emit!=='function')fail('Invalid NPC Spring emit callback');
 const definitions=new Map();
 for(const spec of specs){validateNpcSpringContactSpec(spec);if(definitions.has(spec.id))fail('Duplicate NPC Spring ID');definitions.set(spec.id,copy(spec));}
 let states=new Map(),actorsById=new Map(),lastTick=null,lastFrameTick=null,paused=false,afterTicks=new Map(),lastFrameResult=null,events=[];
 const fresh=(id)=>({id,actorId:null,phase:'idle',age:0,rest:null,currentTop:null,startTick:null,releaseTick:null,advanceTick:null,blocked:null});
 function tickAt(tick){
  if(!Number.isSafeInteger(tick)||tick<0)fail('NPC Spring tick must be a non-negative safe integer');
  if(lastTick!==null&&tick<lastTick)fail('NPC Spring clock moved backwards; reset or restore first');
  if(tick!==lastTick){lastTick=tick;events=[];afterTicks.clear();}
 }
 function readGeometry(geometry){
  if(!Array.isArray(geometry))fail('NPC Spring needs a geometry array');
  const found=new Map();
  for(const q of geometry)if(definitions.has(q?.id)){if(found.has(q.id))fail('Duplicate NPC Spring collision ID');found.set(q.id,q);}
  return found;
 }
 function springAt(id,found){
  const q=found.get(id);if(!rect(q)||q.hidden||q.active===false||q.material!=='spring'||q.collision!=='solid'||q.springOrientation==='horizontal'||q.orientation==='horizontal')return null;
  // A moving carrier is a separate unverified mechanism, not a static support.
  if(['dx','dy','vx','vy'].some(k=>q[k]!==undefined&&q[k]!==0))return null;
  const st=states.get(id)||fresh(id);states.set(id,st);
  const rest={x:q.x,y:q.restY??q.y,w:q.w,h:q.restH??q.h};
  if(!rect(rest)||rest.h<=1)fail('Invalid NPC Spring rest rectangle');
  const depth=definitions.get(id).compressionDepth??Math.min(7.2,rest.h-1);
  if(depth>=rest.h)fail('NPC Spring compressionDepth must leave a positive body');
  if(st.rest&&['x','y','w','h'].some(k=>Math.abs(st.rest[k]-rest[k])>EPS))return null;
  st.rest??=rest;st.currentTop??=rest.y;
  return {q,st,rest:st.rest,depth};
 }
 function record(event,st,tick,more={}){
  const e={event,springId:st.id,actorId:st.actorId,tick,...more};events.push(copy(e));emit('npc-spring',copy(e));
 }
 function clearSupport(actor,id){if(actor&&actor.support===id){actor.support=null;actor.grounded=false;}}
 function interrupt(st,actor,tick,reason,blocked=null){
  clearSupport(actor,st.id);st.blocked=blocked?copy(blocked):null;record('compression-interrupted',st,tick,{reason,...(blocked?{blocked:copy(blocked)}:{})});
  actorsById.delete(st.actorId);st.actorId=null;st.phase='idle';st.age=0;st.currentTop=st.rest?.y??null;st.startTick=null;
 }
 function ownerOf(id){for(const st of states.values())if(st.actorId===id&&st.phase==='compressing')return st;return null;}
 function standing(actor,st){return eligible(actor)&&actor.grounded===true&&actor.support===st.id&&(actor.vy??0)>=0&&span(actor,st.rest)&&Math.abs(actor.y+actor.h-st.currentTop)<=CONTACT_EPS;}
 function resultFor(actor,{started=false,contact=false,interrupted=false}={}){
  const owner=ownerOf(actor?.id);return {contact,started,interrupted,owned:!!owner,skipLegacyGravity:!!owner,springId:owner?.id??null};
 }
 function currentFrameResult(tick){return {tick,paused,
  ownedActorIds:[...states.values()].filter(st=>st.phase==='compressing').map(st=>st.actorId),
  launchedActorIds:events.filter(e=>e.event==='launch').map(e=>e.actorId),
  interruptedActorIds:events.filter(e=>e.event==='compression-interrupted').map(e=>e.actorId),events:copy(events)};}
 function geometryProjection(geometry){
  readGeometry(geometry);
  return geometry.map(q=>{
   const st=states.get(q.id);if(!definitions.has(q.id)||!st?.rest)return q;
   const projected={...q};delete projected.npcSpringOwned;delete projected.npcSpringActorId;delete projected.npcSpringCompressionAge;
   // Restore only a projection produced by this controller; preserve an idle
   // Spring's genuine legacy/player compression if the host owns it instead.
   if(st.phase==='compressing'){
    projected.y=st.currentTop;projected.h=st.rest.y+st.rest.h-st.currentTop;projected.restY=st.rest.y;projected.restH=st.rest.h;
    projected.npcSpringOwned=true;projected.npcSpringActorId=st.actorId;projected.npcSpringCompressionAge=st.age;
   }else if(q.npcSpringOwned){projected.y=st.rest.y;projected.h=st.rest.h;projected.restY=st.rest.y;projected.restH=st.rest.h;}
   return projected;
  });
 }
 function afterActor(actor,before,{tick,geometry}={}){
  tickAt(tick);const found=readGeometry(geometry);
  if(paused)return resultFor(actor);
  if(!safeId(actor?.id))return resultFor(actor);
  const owner=ownerOf(actor.id);
  if(owner){
   afterTicks.set(actor.id,tick);
   actorsById.set(actor.id,actor);
   if(!springAt(owner.id,found)||!standing(actor,owner)){interrupt(owner,actor,tick,'lost-top-contact');return resultFor(actor,{interrupted:true});}
   return resultFor(actor,{contact:true});
  }
  if(afterTicks.get(actor.id)===tick)return resultFor(actor);
  afterTicks.set(actor.id,tick);
  if(!eligible(actor)||!rect(before)||before.id!==undefined&&before.id!==actor.id||(actor.vy??0)<0||(before.vy??0)<0)return resultFor(actor);
  for(const id of definitions.keys()){
   const spring=springAt(id,found);if(!spring)continue;const {q,st,rest}=spring;
   if(st.phase!=='idle'||st.releaseTick===tick||q.springAge||!span(actor,rest))continue;
   const oldFoot=before.y+before.h,foot=actor.y+actor.h;
   // afterActor sees the caller's resolved top landing, never an arbitrary
   // overlap below/alongside the Spring or an airborne body above it.
   if(actor.grounded!==true||actor.support!=null&&actor.support!==id||Math.abs(foot-rest.y)>CONTACT_EPS||oldFoot>rest.y+CONTACT_EPS)continue;
   const down=foot>oldFoot+EPS&&(before.vy??0)>=0;
   const settled=actor.grounded===true&&(actor.support==null||actor.support===id)&&Math.abs(oldFoot-rest.y)<=CONTACT_EPS;
   if(!down&&!settled)continue;
   // A diagonal corner touch from outside the foot span is not a top landing.
   const deltaFoot=foot-oldFoot,fraction=deltaFoot>EPS?Math.max(0,Math.min(1,(rest.y-oldFoot)/deltaFoot)):1;
   const atCrossing={x:before.x+(actor.x-before.x)*fraction,w:before.w};
   if(!span(atCrossing,rest))continue;
   st.actorId=actor.id;st.phase='compressing';st.age=0;st.currentTop=rest.y;st.startTick=tick;st.blocked=null;
   actorsById.set(actor.id,actor);actor.vy=0;actor.grounded=true;actor.support=id;
   record('compression-start',st,tick,{incomingVy:before.vy??0});return resultFor(actor,{started:true,contact:true});
  }
  return resultFor(actor);
 }
 function frame({tick,actors=[],geometry,resolveBodyMotion}={}){
  tickAt(tick);const found=readGeometry(geometry);
  if(!Array.isArray(actors))fail('Invalid NPC Spring actors list');
  const live=new Map();for(const actor of actors)if(safeId(actor?.id)){if(live.has(actor.id))fail('Duplicate NPC Spring actor ID');live.set(actor.id,actor);}
  if(lastFrameTick===tick)return {...currentFrameResult(tick),geometry:geometryProjection(geometry)};
  if(!paused&&[...states.values()].some(st=>st.phase==='compressing')&&typeof resolveBodyMotion!=='function')fail('NPC Spring compression needs caller swept resolveBodyMotion');
  if(!paused)for(const st of states.values())if(st.phase==='compressing'){
   if(st.advanceTick===tick)continue;
   const actor=live.get(st.actorId),spring=springAt(st.id,found);
   if(!actor||!spring||!standing(actor,st)){afterTicks.set(st.actorId,tick);st.advanceTick=tick;interrupt(st,actor||actorsById.get(st.actorId),tick,'lost-top-contact');continue;}
   actorsById.set(actor.id,actor);
   if(st.startTick===tick)continue;
   const spec=definitions.get(st.id),age=st.age+1,duration=spec.compressionFrames;
   const depth=age>=duration?0:spring.depth*(age<=duration/2?age/(duration/2):(duration-age)/(duration/2));
   const target=st.rest.y+depth-actor.h,delta={x:0,y:target-actor.y};
   const placed=resolveBodyMotion(actor,delta,{tick,springId:st.id,phase:age>=duration?'release':'compression',geometry:geometry.filter(q=>q.id!==st.id),excludeIds:[st.id]});
   if(!placed||!placed.body||!Number.isFinite(placed.body.x)||!Number.isFinite(placed.body.y))fail('Invalid NPC Spring swept placement result');
   actor.x=placed.body.x;actor.y=placed.body.y;
   if(placed.reached===false||Math.abs(actor.y-target)>EPS||!span(actor,st.rest)||placed.blocked){
    afterTicks.set(st.actorId,tick);st.advanceTick=tick;interrupt(st,actor,tick,'blocked-placement',placed.blocked);continue;
   }
   st.advanceTick=tick;st.age=age;st.currentTop=st.rest.y+depth;actor.vy=0;actor.grounded=true;actor.support=st.id;
   if(age>=duration){
    actor.vy=-spec.launchSpeed;actor.grounded=false;actor.support=null;st.releaseTick=tick;
    record('launch',st,tick,{launchSpeed:spec.launchSpeed,compressionFrames:duration});
    actorsById.delete(st.actorId);st.actorId=null;st.phase='idle';st.age=0;st.startTick=null;
   }
  }
  lastFrameTick=tick;
  lastFrameResult=currentFrameResult(tick);
  return {...copy(lastFrameResult),geometry:geometryProjection(geometry)};
 }
 function reset(){for(const st of states.values())clearSupport(actorsById.get(st.actorId),st.id);states=new Map();actorsById=new Map();lastTick=lastFrameTick=null;afterTicks=new Map();lastFrameResult=null;events=[];paused=false;}
 function view(){return {tick:lastTick,paused,springs:[...definitions.keys()].map(id=>copy(states.get(id)||fresh(id))),events:copy(events)};}
 function snapshot(){return {version:1,definitions:copy([...definitions.values()]),tick:lastTick,frameTick:lastFrameTick,paused,states:copy([...states.values()]),afterTicks:[...afterTicks],lastFrameResult:copy(lastFrameResult),events:copy(events)};}
 function restore(saved){
  if(!saved||saved.version!==1||JSON.stringify(saved.definitions)!==JSON.stringify([...definitions.values()]))fail('NPC Spring snapshot belongs to different definitions');
  if(saved.tick!==null&&(!Number.isSafeInteger(saved.tick)||saved.tick<0)||saved.frameTick!==null&&(!Number.isSafeInteger(saved.frameTick)||saved.frameTick<0)||typeof saved.paused!=='boolean'||!Array.isArray(saved.states)||!Array.isArray(saved.afterTicks)||!Array.isArray(saved.events))fail('Invalid NPC Spring snapshot');
  const restored=new Map(),owners=new Set();
  for(const st of saved.states){
   if(!definitions.has(st?.id)||restored.has(st.id)||!['idle','compressing'].includes(st.phase)||!Number.isInteger(st.age)||st.age<0||st.age>=definitions.get(st.id).compressionFrames||st.rest!==null&&!rect(st.rest)||st.currentTop!==null&&!Number.isFinite(st.currentTop))fail('Invalid NPC Spring snapshot state');
   if(st.phase==='compressing'&&(!safeId(st.actorId)||owners.has(st.actorId)||!st.rest||!Number.isSafeInteger(st.startTick)||st.startTick>saved.tick))fail('Invalid NPC Spring snapshot owner');
   if(st.phase==='idle'&&st.actorId!==null)fail('Invalid NPC Spring idle snapshot owner');
   owners.add(st.actorId);restored.set(st.id,copy(st));
  }
  for(const [id,tick]of saved.afterTicks)if(!safeId(id)||!Number.isSafeInteger(tick)||tick<0||tick>saved.tick)fail('Invalid NPC Spring snapshot actor clock');
  reset();states=restored;lastTick=saved.tick;lastFrameTick=saved.frameTick;paused=saved.paused;afterTicks=new Map(saved.afterTicks);lastFrameResult=copy(saved.lastFrameResult);events=copy(saved.events);
 }
 return {afterActor,frame,geometry:geometryProjection,view,reset,pause(value=true){if(typeof value!=='boolean')fail('Invalid NPC Spring pause');paused=value;return paused;},ownsActor(actor){return !!ownerOf(typeof actor==='string'?actor:actor?.id);},snapshot,restore};
}
