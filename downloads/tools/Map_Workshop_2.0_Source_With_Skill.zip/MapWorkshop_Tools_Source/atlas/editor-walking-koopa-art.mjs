/** Native SMB1 catalogue artwork for the opted-in Walking Koopa study.
 * Copyrighted Nintendo pixels are independent of the MIT implementation.
 * Exact responses, palette and family-adaptation limits are recorded in
 * assets/smm2-story71/ASSET_PROVENANCE.json. No image fetch or DOM is needed.
 */
const RAW_SOURCE_ASSETS={"redKoopaStand":{"w":16,"h":23,"palette":[[0,0,0,0],[247,57,16,255],[255,178,89,255],[255,255,255,255]],"rows":["0003000000000000","0033300000000000","0033320000000000","0213322000000000","0213322000000000","0213322000000000","0233322000000000","2223222000000000","2122222000000000","2222220011111000","2220220121112100","2200220112121110","2202231111213310","0202231112121310","0002232121112120","0022331211111210","0002312121112120","0002321112121110","0000311111211110","0000331112121333","0002233321133300","0022222333332220","0222220000002222"],"sourceSha256":"2aa3a408c40ff918f66555f47b71b4b11bb896a7b25fb0cec8c780279040ea1c","rgbaSha256":"bdc051d640f17e3b6b2e87c1fcd9cd051f841b3bed95a59d60f6afa5ebb5b419","status":"original-catalogue-static"},"redShell":{"w":16,"h":14,"palette":[[0,0,0,0],[247,57,16,255],[255,178,89,255],[255,255,255,255]],"rows":["0000021111200000","0000112222110000","0001121111211000","0001211111121000","0012111111112100","0021211111121200","0211121111211120","0111112222111110","3331121111211333","3333211111123333","0023311111133200","0022331111332200","0002233333322000","0000223333220000"],"sourceSha256":"d41f83db86b1e373703d1dcba069ef407c3d45b476db636fe1d8cb6a34b36956","rgbaSha256":"cdd57a3b7eef521adb14127453d476788a27ff8a345744ed61c0c817712c36e0","status":"original-catalogue-static"},"redConveyor":{"w":48,"h":15,"palette":[[0,0,0,0],[31,31,31,255],[124,29,8,255],[247,57,16,255],[255,157,198,255],[255,255,255,255]],"rows":["000004444430044444300444443004444430044444300000","000224333322243333222433332224333322243333222000","002222222222243333222433332224333322222222222200","022225555522243333222433332224333322225555522220","022255111552232222200322222003222222255111552220","442551553155200000000222220000000002551553155243","432515533315200000000233320000000002515533315232","432515333315200000000232320000000002515333315232","432513333315200000000233320000000002513333315232","322551333155200000000222220000000002551333155222","022255111552244444300444443004444432255111552220","022225555522243333222433332224333322225555522220","002222222222243333222433332224333322222222222200","000224333322243333222433332224333322243333222000","000003222220032222200322222003222220032222200000"],"sourceSha256":"b6685183ba7d6eb2bb8fe99727c15a8d4fbfd35a3d464227e6206939cbeb0bed","rgbaSha256":"47256e7e0e86c62717ecbb1c579029be6b4896b9bfe03b691d66a48026fed063","status":"original-catalogue-static"},"blueConveyor":{"w":48,"h":15,"palette":[[0,0,0,0],[10,27,138,255],[31,31,31,255],[80,80,255,255],[160,234,255,255],[255,255,255,255]],"rows":["000004444430044444300444443004444430044444300000","000114333311143333111433331114333311143333111000","001111111111143333111433331114333311111111111100","011115555511143333111433331114333311115555511110","011155222551131111100311111003111111155222551110","441552553255100000000111110000000001552553255143","431525533325100000000133310000000001525533325131","431525333325100000000131310000000001525333325131","431523333325100000000133310000000001523333325131","311552333255100000000111110000000001552333255111","011155222551144444300444443004444431155222551110","011115555511143333111433331114333311115555511110","001111111111143333111433331114333311111111111100","000114333311143333111433331114333311143333111000","000003111110031111100311111003111110031111100000"],"sourceSha256":"6fc6fead777a5beed5fee567603ff1b9ac95cc11a1b72df445995e3f679e4462","rgbaSha256":"2294ca74bfe50c1da7dae983272a7681e7e0f00444521f39cf6b0fc067fde400","status":"original-catalogue-static"},"redConveyorSlope":{"w":48,"h":31,"palette":[[0,0,0,0],[31,31,31,255],[124,29,8,255],[247,57,16,255],[255,157,198,255],[255,255,255,255]],"rows":["000004444430044400000000000000000000000000000000","000224333322243340000000000000000000000000000000","002222222222243334000000000000000000000000000000","022225555522243333300000000000000000000000000000","022255111552232233200000000000000000000000000000","442551553155200023220000000000000000000000000000","432515533315200002222400000000000000000000000000","432515333315200000222440000000000000000000000000","432513333315200000002434000000000000000000000000","322551333155200000000433400000000000000000000000","022255111552244400000333340000000000000000000000","022225555522243340000023333000000000000000000000","002222222222243334000002332000000000000000000000","000224333322243333300022232200000000000000000000","000003222220032233200233322224000000000000000000","000000000000000023220232322224400000000000000000","000000000000000002222433320024344430044444300000","000000000000000000222442200004333322243333222000","000000000000000000002434000003333322222222222200","000000000000000000000433400000233322225555522220","000000000000000000000333340000022222255111552220","000000000000000000000023333000000002551553155243","000000000000000000000002332000000002515533315232","000000000000000000000000232200000002515333315232","000000000000000000000000022224000002513333315232","000000000000000000000000002224400002551333155222","000000000000000000000000000024344432255111552220","000000000000000000000000000004333322225555522220","000000000000000000000000000003333322222222222200","000000000000000000000000000000233322243333222000","000000000000000000000000000000022220032222200000"],"sourceSha256":"fe2700962c7b260dc78f548d03ab80f04fe89aa6d29c27bb05329e459a18f899","rgbaSha256":"f0bb0abd209ae394c2b5fee7b77aa645b73d6e241eb963e999a570aa76719b84","status":"original-catalogue-static"},"blueConveyorSlope":{"w":48,"h":31,"palette":[[0,0,0,0],[10,27,138,255],[31,31,31,255],[80,80,255,255],[94,94,255,255],[160,234,255,255],[255,255,255,255]],"rows":["000005555530055500000000000000000000000000000000","000115333311153350000000000000000000000000000000","001111111111153335000000000000000000000000000000","011116666611153333300000000000000000000000000000","011166222661131133100000000000000000000000000000","551662664266100013110000000000000000000000000000","531626644426100001111500000000000000000000000000","531626444426100000111550000000000000000000000000","531624444426100000001535000000000000000000000000","311662444266100000000533500000000000000000000000","011166222661155500000333350000000000000000000000","011116666611153350000013333000000000000000000000","001111111111153335000001331000000000000000000000","000115333311153333300011131100000000000000000000","000003111110031133100133311115000000000000000000","000000000000000013110131311115500000000000000000","000000000000000001111533310015355530055555300000","000000000000000000111551100005333311153333111000","000000000000000000001535000003333311111111111100","000000000000000000000533500000133311116666611110","000000000000000000000333350000011111166222661110","000000000000000000000013333000000001662664266153","000000000000000000000001331000000001626644426131","000000000000000000000000131100000001626444426131","000000000000000000000000011115000001624444426131","000000000000000000000000001115500001662444266111","000000000000000000000000000015355531166222661110","000000000000000000000000000005333311116666611110","000000000000000000000000000003333311111111111100","000000000000000000000000000000133311153333111000","000000000000000000000000000000011110031111100000"],"sourceSha256":"81d6e4f15d067903db32ecbbf1647d8253389f5df833354f8cd331d79946de8d","rgbaSha256":"539c9e39612c574b50d444816cf336082a61d84366df1329630820853e2832b1","status":"original-catalogue-static"},"redKoopaWalkSecond":{"w":16,"h":24,"palette":[[0,0,0,0],[247,57,16,255],[255,178,89,255],[255,255,255,255]],"rows":["0000300000000000","0003330000000000","0023330000000000","0021332000000000","0221332000000000","0221332000000000","0223332000000000","2122322000000000","2222222000000000","2220022011111000","2200023121112100","0000223112121100","0002231111213310","0222231112121310","0022232121112120","0002331211111210","0002312121112120","0002321112121110","0000311111211110","0000331112121333","0000233321133320","0000222333332220","0000022200002220","0000002220022200"],"sourceSha256":"f3b477a5ca36662193df47b98e1f9f656a838b9d7f654a20fe97a49f4797bd14","rgbaSha256":"f743d0989a589bb51db581a7dc01bdb62e304291adf8d22afbcc3d4a626ebd4c","status":"original-NES-family-palette-adaptation"}};

RAW_SOURCE_ASSETS.noteBlock={"w":16,"h":16,"palette":[[0,0,0,0],[31,31,31,255],[132,132,132,255],[255,255,255,255]],"rows":["0022222222222200","0233333333333310","2333333333133331","2333333333133331","2333333333133331","2333333333133331","2333333333133331","2333333333133331","2333333111133331","2333311111133331","2333111111133331","2333111111333331","2333311133333331","2333333333333331","0133333333333310","0011111111111100"],"sourceSha256":"47978f381424c3d00b5ee94738a8750b43e79deae807eb70d811a8a1b26f19ae","rgbaSha256":"90d2e555b181c627e3bf8e23de26af8b551336a7294c2b2b6594600e66a55dbf","status":"original-catalogue-static"};

const finite=Number.isFinite;
const mod=(n,m)=>((n%m)+m)%m;
const rect=q=>q&&['x','y','w','h'].every(k=>finite(q[k]))&&q.w>0&&q.h>0;
const alive=q=>q&&!q.dead&&!q.dying&&!q.defeated&&!q.removed&&!q.hidden&&q.visible!==false;
const rgba=c=>c[3]===255?'#'+c.slice(0,3).map(v=>v.toString(16).padStart(2,'0')).join(''):`rgba(${c[0]},${c[1]},${c[2]},${c[3]/255})`;
export const WALKING_KOOPA_SOURCE_ASSETS=Object.freeze(Object.fromEntries(Object.entries(RAW_SOURCE_ASSETS).map(([key,q])=>[key,Object.freeze({...q,palette:Object.freeze(q.palette.map(c=>Object.freeze([...c]))),rows:Object.freeze([...q.rows])})])));
export const WALKING_KOOPA_ANIMATION_STATUS='authored-family-adaptation-not-calibrated';

/** Palette-indexed exact source pixels. Source crop defaults to all pixels. */
export function drawWalkingKoopaSourcePixels(c,key,{x=0,y=0,scale=1,sx=0,sy=0,w,h}={}){
 const a=WALKING_KOOPA_SOURCE_ASSETS[key];
 if(!a||!finite(x)||!finite(y)||!finite(scale)||scale<=0)return false;
 w=w??a.w;h=h??a.h;
 if(!Number.isInteger(sx)||!Number.isInteger(sy)||!Number.isInteger(w)||!Number.isInteger(h)||sx<0||sy<0||w<1||h<1||sx+w>a.w||sy+h>a.h)return false;
 for(let row=0;row<h;row++){
  const values=a.rows[row+sy];
  for(let col=0;col<w;){const index=Number(values[col+sx]),color=a.palette[index];let end=col+1;while(end<w&&values[end+sx]===values[col+sx])end++;
   if(color[3]){c.fillStyle=rgba(color);c.fillRect(x+col*scale,y+row*scale,(end-col)*scale,scale);}col=end;
  }
 }
 return true;
}

/** Exact native Note pixels; the caller owns the physical/bump pose. */
export function drawNativeNoteBlock(c,q){
 if(!alive(q)||!rect(q)||q.w!==16||q.h!==16)return false;
 return drawWalkingKoopaSourcePixels(c,'noteBlock',{x:Math.round(q.x),y:Math.round(q.y)});
}

function descriptor(actor,opts){
 const v=opts.view??actor?.koopaView;
 if(v)return v;
 const s=actor?.smm2WalkingKoopa;
 if(!s||s.version!==1||s.variant?.kind!=='walking-koopa')return null;
 const scale=s.variant.size==='giant'?2:1,shell=s.phase!=='walking';
 return {color:s.variant.color,size:s.variant.size,phase:s.phase,alive:true,scale,shell,flipped:s.phase==='flipped-shell',body:actor,render:{anchorX:actor.x+actor.w/2,anchorY:actor.y+actor.h,pivotX:actor.x+actor.w/2,pivotY:actor.y+actor.h/2,flipY:s.phase==='flipped-shell'}};
}

/** Only opted-in red, live, unwinged actors are owned. Feet and inversion
 * pivot follow the descriptor; physical width/height never stretches pixels.
 * Second walking stance and 8-tick rhythm are declared family adaptations.
 * Explicit typed upright defeated-shell effects are a separate opt-in image;
 * they remain dead effects and do not acquire living-shell behavior.
 */
export function drawWalkingKoopa(c,actor,tick=0,opts={}){
 const v=descriptor(actor,opts),q=v?.body??actor;
 const defeatedEffect=opts.defeatedEffect===true&&actor?.kind==='enemy-death'&&actor.shell===true&&v?.phase==='shell'&&actor.smm2DefeatOrientation==='upright';
 const drawable=alive(actor)||(defeatedEffect&&!actor.hidden&&!actor.removed&&actor.visible!==false);
 if(!drawable||!rect(q)||!v||(!defeatedEffect&&v.alive===false)||v.winged||v.color!=='red'||!['normal','giant'].includes(v.size)||!['walking','shell','flipped-shell'].includes(v.phase))return false;
 const scale=v.size==='giant'?2:1,shell=v.phase!=='walking',r=v.render??{},cx=finite(r.anchorX)?r.anchorX:q.x+q.w/2,feet=finite(r.anchorY)?r.anchorY:q.y+q.h;
 const state=actor.smm2WalkingKoopa,moving=!shell&&Math.abs(actor.vx||0)>.01&&opts.animate!==false&&!opts.stopped&&!actor.stopped;
 const key=shell?'redShell':moving&&Math.floor((finite(tick)?Math.max(0,tick):0)/8)%2?'redKoopaWalkSecond':'redKoopaStand';
 const a=WALKING_KOOPA_SOURCE_ASSETS[key],flipped=shell&&!defeatedEffect&&(r.flipY??v.flipped??v.phase==='flipped-shell'),direction=opts.direction??(Math.sign(actor.vx||0)||state?.walkDirection||state?.variant?.direction||-1);
 c.save();c.imageSmoothingEnabled=false;
 if(flipped){const px=finite(r.pivotX)?r.pivotX:cx,py=finite(r.pivotY)?r.pivotY:q.y+q.h/2;c.translate(px,py);c.scale(1,-1);c.translate(-px,-py);}
 const left=Math.round(cx-8*scale),top=Math.round(feet-a.h*scale);
 if(!shell&&direction>0){c.translate(left+16*scale,top);c.scale(-1,1);drawWalkingKoopaSourcePixels(c,key,{scale});}
 else drawWalkingKoopaSourcePixels(c,key,{x:left,y:top,scale});
 c.restore();return true;
}

function cap(c,key,center,right,phase,animate){
 const x=Math.round(center.x-7.5),y=Math.round(center.y-7.5);
 drawWalkingKoopaSourcePixels(c,key,{x,y,sx:right?32:0,w:16,h:15});
 if(animate&&finite(phase)){
  // Rotate only the original 9x9 inner ring/highlight. The cap center and
  // native circle remain fixed, even when tread or flow reverses.
  const quarter=mod(Math.floor(phase/(Math.PI/2)),4);
  if(quarter){c.save();c.translate(x+7.5,y+7.5);c.rotate(quarter*Math.PI/2);drawWalkingKoopaSourcePixels(c,key,{x:-4.5,y:-4.5,sx:(right?32:0)+3,sy:3,w:9,h:9});c.restore();}
 }
}

/** Geometry/controller descriptor comes from conveyor.view().surfaces.
 * Native 15px caps retain circular proportions. Original middle palette
 * pixels repeat along fixed endpoints, sampled at integer world pixels on
 * arbitrary slopes. Slope angle/gear cadence are local visual adaptations.
 */
export function drawConveyorSurface(c,surface,opts={}){
 const centers=surface?.visual?.rollerCenters??surface?.rollers;
 if(!alive(surface)||!['red','blue'].includes(surface.colorState)||!Array.isArray(centers)||centers.length!==2||centers.some(q=>!finite(q.x)||!finite(q.y)))return false;
 const [p0,p1]=centers,dx=p1.x-p0.x,dy=p1.y-p0.y,length=Math.hypot(dx,dy);
 if(length<1)return false;
 const ux=dx/length,uy=dy/length,nx=-uy,ny=ux,key=surface.colorState==='red'?'redConveyor':'blueConveyor',a=WALKING_KOOPA_SOURCE_ASSETS[key],animate=opts.animate!==false;
 // The controller has already integrated the signed tread direction. Its
 // positive modulo phase is consumed directly, so a toggle cannot mirror the
 // current phase or create an extra visual jump.
 const phase=animate&&finite(surface.treadPhasePx)?surface.treadPhasePx:0;
 const left=Math.floor(Math.min(p0.x,p1.x)-9),right=Math.ceil(Math.max(p0.x,p1.x)+9),top=Math.floor(Math.min(p0.y,p1.y)-9),bottom=Math.ceil(Math.max(p0.y,p1.y)+9);
 c.save();c.imageSmoothingEnabled=false;
 for(let y=top;y<bottom;y++)for(let x=left;x<right;x++){
  const rx=x+.5-p0.x,ry=y+.5-p0.y,s=rx*ux+ry*uy,t=rx*nx+ry*ny,row=Math.floor(t+7.5);
  if(s<0||s>length||row<0||row>=15)continue;
  let col;
  if(row<5)col=16+mod(Math.floor(s+7-phase),16);
  else if(row>=10)col=16+mod(Math.floor(s+7+phase),16);
  else {const offset=s-length/2+7;if(offset<0||offset>=16)continue;col=16+Math.floor(offset);}
  const color=a.palette[Number(a.rows[row][col])];if(color[3]){c.fillStyle=rgba(color);c.fillRect(x,y,1,1);}
 }
 for(let i=0;i<2;i++)cap(c,key,centers[i],i===1,surface.rollers?.[i]?.phaseRadians,animate);
 c.restore();return true;
}
