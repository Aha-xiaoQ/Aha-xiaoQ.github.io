import {spritePixels} from './classic-art.mjs';
const goomba=spritePixels('goomba');
const colors={'.':null,k:'#181818',w:'#ffffff',s:'#bcbcbc',b:'#184c78',c:'#3cbcfc',o:'#fc9838',r:'#d82800'};
// Newly authored upright cloud hand-gun, using the native palette. This is an
// original compact copper/steel tool, not a Namco ship or a Nintendo sprite.
const gun=['..kkk...','..ksk...','..kwk...','..ksk...','.kkkkkk.','.kwsbsk.','.kssbbk.','.kkbbkk.','..kbbk..','..koook.','..koook.','..kkkk..'];
function pixels(c,data,x,y,flip=false){for(let row=0;row<data.h;row++)for(let col=0;col<data.w;col++){const rgba=data.pixels[row*data.w+(flip?data.w-1-col:col)];if(!rgba[3])continue;c.fillStyle=`rgba(${rgba[0]},${rgba[1]},${rgba[2]},${rgba[3]/255})`;c.fillRect(x+col,y+row,1,1);}}
function authored(c,rows,x,y){for(let row=0;row<rows.length;row++)for(let col=0;col<rows[row].length;col++){const color=colors[rows[row][col]];if(color){c.fillStyle=color;c.fillRect(x+col,y+row,1,1);}}}
function reticle(c,x,y,age){c.fillStyle=Math.floor(age/6)%2?'#ffffff':'#fc9838';for(const [dx,dy,w,h]of [[-9,-9,5,1],[-9,-9,1,5],[5,-9,5,1],[9,-9,1,5],[-9,9,5,1],[-9,5,1,5],[5,9,5,1],[9,5,1,5]])c.fillRect(x+dx,y+dy,w,h);c.fillRect(x-1,y-1,3,3);}
function viewFor(room){return room.skyShooterView??room.smm2Mechanics?.skyShooterView??null;}
function drone(c,q,tick){
 const x=Math.round(q.x),y=Math.round(q.y),rotor=Math.floor(tick/4)%2;
 // Original visible flight pack is behind the unchanged 16px Goomba body.
 c.fillStyle='#181818';c.fillRect(x-6,y+7,6,5);c.fillRect(x+16,y+7,6,5);c.fillRect(x-5,y+12,26,3);
 c.fillStyle='#bcbcbc';c.fillRect(x-5,y+8,5,3);c.fillRect(x+16,y+8,5,3);c.fillRect(x-3,y+13,22,1);
 c.fillStyle='#ffffff';c.fillRect(x-5,y+8,4,1);c.fillRect(x+17,y+8,4,1);
 // The optional diving rank has copper exhaust on its original flight pack;
 // the same source Goomba pixels and 16px native collision body stay intact.
 c.fillStyle=q.looping?'#fc9838':'#3cbcfc';c.fillRect(x-3,y+15,2,rotor?3:1);c.fillRect(x+17,y+15,2,rotor?1:3);
 c.fillStyle='#181818';c.fillRect(x+7,y-4,2,4);c.fillRect(x+(rotor?1:4),y-5,rotor?14:8,2);
 c.fillStyle='#bcbcbc';c.fillRect(x+(rotor?1:4),y-5,rotor?14:8,1);
 pixels(c,goomba,x,y,q.facing<0);
 if(q.state==='warning'&&Math.floor(tick/6)%2===0){c.fillStyle='#ffffff';c.fillRect(x+7,y-17,2,7);c.fillRect(x+7,y-8,2,2);}
}
/** Draw after scenery and before Mario. The host excludes bound drones from its
 * generic enemy draw because this draws their native source pixels once. */
export function drawSkyShooter(c,room,tick=room?.tick??0){
 const spec=room?.smm2Mechanics?.skyShooter;if(!spec)return false;
 const v=viewFor(room)??{drones:spec.drones.filter(q=>q.wave===1).map(q=>({...q,state:'waiting',facing:1,...(spec.loopingDivers?.actorIds.includes(q.id)?{looping:true}:{})})),shots:[],missiles:[],warnings:[]};
 for(const q of v.drones||[])drone(c,q,tick);
 for(const q of v.shots||[]){const x=Math.round(q.x),y=Math.round(q.y);c.fillStyle='#184c78';c.fillRect(x-1,y+1,5,7);c.fillStyle='#ffffff';c.fillRect(x,y,3,6);c.fillStyle='#3cbcfc';c.fillRect(x+1,y+6,1,3);}
 for(const q of v.missiles||[]){const x=Math.round(q.x),y=Math.round(q.y);c.fillStyle='#181818';c.fillRect(x-1,y+2,6,6);c.fillStyle='#d82800';c.fillRect(x,y+1,4,6);c.fillStyle='#ffffff';c.fillRect(x+1,y,2,2);c.fillStyle='#fc9838';c.fillRect(x,y+7,4,Math.floor(tick/3)%2?4:2);}
 for(const q of v.enemyFire?.shots||[]){const x=Math.round(q.x),y=Math.round(q.y),d=Math.max(.001,Math.hypot(q.vx,q.vy)),tail={x:Math.round(x+2-q.vx/d*4),y:Math.round(y+4-q.vy/d*4)};c.fillStyle='#181818';c.fillRect(x-1,y+1,6,6);c.fillStyle='#d82800';c.fillRect(x,y+1,4,6);c.fillStyle='#ffffff';c.fillRect(x+1,y+3,2,2);c.fillStyle='#fc9838';c.fillRect(tail.x-1,tail.y-1,3,3);}
 for(const q of v.warnings||[]){reticle(c,Math.round(q.target.x),Math.round(q.target.y),q.age);const source=v.drones.find(a=>a.id===q.actorId);if(source){c.fillStyle='#fc9838';const from=q.source??{x:source.x+8,y:source.y+16},dx=q.target.x-from.x,dy=q.target.y-from.y,steps=Math.ceil(Math.hypot(dx,dy)/12);for(let n=1;n<steps;n++)if(n%2===0)c.fillRect(Math.round(from.x+dx*n/steps),Math.round(from.y+dy*n/steps),1,2);
   if(q.source){const sx=Math.round(from.x),sy=Math.round(from.y);c.fillStyle=Math.floor(q.age/6)%2?'#ffffff':'#fc9838';c.fillRect(sx-4,sy+1,2,4);c.fillRect(sx+3,sy+1,2,4);c.fillRect(sx-1,sy+2,3,2);if(q.kind==='downward'){c.fillRect(sx-3,sy+9,2,2);c.fillRect(sx+2,sy+9,2,2);c.fillRect(sx-1,sy+11,3,2);}}
   // A source beyond the actual camera still warns on the visible edge. The
   // target reticle always remains at the latched player's visible position.
   const b=room.renderBounds;if(b&&(from.x<b.x+8||from.x>b.x+b.w-8||from.y<b.y+24||from.y>b.y+b.h-8)){const ex=Math.round(Math.max(b.x+8,Math.min(b.x+b.w-12,from.x))),ey=Math.round(Math.max(b.y+28,Math.min(b.y+b.h-14,from.y)));c.fillStyle='#181818';c.fillRect(ex-3,ey-9,8,14);c.fillStyle=Math.floor(q.age/6)%2?'#ffffff':'#fc9838';c.fillRect(ex,ey-7,2,7);c.fillRect(ex,ey+2,2,2);}
  }}
 return true;
}
/** Draw after the seated native Mario so the hand-gun remains clearly visible. */
export function drawSkyShooterWeapon(c,room,tick=room?.tick??0){
 const v=viewFor(room),q=v?.weapon;if(!q)return false;const x=Math.round(q.x),y=Math.round(q.y);authored(c,gun,x,y);
 if(q.shooting){c.fillStyle='#ffffff';c.fillRect(x+2,y-4,3,3);c.fillStyle='#fc9838';c.fillRect(x+1,y-2,5,1);c.fillRect(x+3,y-6,1,3);}
 return true;
}
export const SKY_SHOOTER_ART_PROVENANCE=Object.freeze({droneBody:'classic-art.mjs spritePixels(goomba), unchanged native pixels',flightPack:'original author pixels',weapon:'original author pixels',projectiles:'original author pixels',originalAnimationCalibration:false});
