/** Original opt-in course components. Tuning is authored approximation.
 * Fixed springs, camera framing and SMB3 cards do not change Mario's motor. */
import {validateNpcSpringContactSpec} from './editor-npc-spring-contacts.mjs';
import {NATIVE_PLAY_RULES} from './editor-play-rules.mjs';
const EPS=1e-7;
const finite=(n,a,b)=>Number.isFinite(n)&&n>=a&&n<=b;
const integer=(n,a,b)=>Number.isSafeInteger(n)&&finite(n,a,b);
const plain=q=>q&&typeof q==='object'&&!Array.isArray(q)&&[Object.prototype,null].includes(Object.getPrototypeOf(q));
const safe=s=>typeof s==='string'&&/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(s)&&s.length<=100;
const copy=q=>structuredClone(q);
const rect=q=>q&&['x','y','w','h'].every(k=>Number.isFinite(q[k]))&&q.w>0&&q.h>0;
const overlap=(a,b)=>a.x<b.x+b.w-EPS&&a.x+a.w>b.x+EPS&&a.y<b.y+b.h-EPS&&a.y+a.h>b.y+EPS;
function fields(q,allowed,label){if(!plain(q)||Object.keys(q).some(k=>!allowed.includes(k)||['__proto__','prototype','constructor'].includes(k)))throw Error('Invalid '+label+' fields');}
export function validateSmm2CourseComponents(room){
 const s=room?.smm2Mechanics;if(!s)return;
 if(s.camera!==undefined){
  const q=s.camera;fields(q,['baseY','minY','riseTop','horizontalBarrier','horizontalForwardOnly'],'SMM2 camera');if(!finite(q.baseY,0,room.map.height)||!finite(q.minY,0,q.baseY)||!finite(q.riseTop,0,320))throw Error('Invalid SMM2 camera frame');if(q.horizontalForwardOnly!==undefined&&typeof q.horizontalForwardOnly!=='boolean')throw Error('Invalid authored camera horizontal direction');
  if(q.horizontalBarrier!==undefined){
   const barrier=q.horizontalBarrier;fields(barrier,['right','releaseWhenRemovedGeometryIds'],'horizontal camera barrier');
   const viewportWidth=room.playRules?.viewportWidth??NATIVE_PLAY_RULES.viewportWidth,ids=barrier.releaseWhenRemovedGeometryIds;
   if(!finite(barrier.right,viewportWidth,room.map.width)||!Array.isArray(ids)||ids.length<1||ids.length>256||new Set(ids).size!==ids.length)throw Error('Invalid horizontal camera barrier bounds or references');
   for(const id of ids){const matches=room.map.geometry.filter(g=>g.id===id);if(!safe(id)||['__proto__','prototype','constructor'].includes(id)||room.map.objects.some(o=>o.id===id)||matches.length!==1||matches[0].collision!=='solid'||!rect(matches[0]))throw Error('Horizontal camera barrier needs unique existing native solid geometry IDs');}
  }
 }
 if(s.goalCard!==undefined){const q=s.goalCard;fields(q,['id','cycle','framesPerCard','phaseFrames','revealFrames','walkDistance','clearFrames','rewards'],'goal card');const o=room.map.objects.find(o=>o.id===q.id&&o.kind==='exit');if(!safe(q.id)||!o||!rect(o)||!Array.isArray(q.cycle)||q.cycle.length<1||q.cycle.length>16||q.cycle.some(k=>!['mushroom','flower','star','life'].includes(k))||!integer(q.framesPerCard,1,3600)||!integer(q.phaseFrames,0,36000)||!integer(q.revealFrames,1,3600)||!finite(q.walkDistance,0,room.map.width-o.x-o.w)||!integer(q.clearFrames,0,3600))throw Error('Invalid SMB3 goal card configuration');fields(q.rewards,['mushroom','flower','star','life'],'card rewards');for(const kind of q.cycle){const r=q.rewards[kind];fields(r,['points','lives','coins'],'card reward');if(r.coins!==undefined&&!integer(r.coins,0,99))throw Error('Invalid explicit card coin reward');if(!integer(r.points,0,100000)||!integer(r.lives,0,99))throw Error('Invalid card reward');}}
 if(s.springs!==undefined){if(!Array.isArray(s.springs)||s.springs.length>256)throw Error('Invalid oriented spring list');const seen=new Set();for(const q of s.springs){
  fields(q,['id','orientation','launchSpeed','compressionFrames','cooldownFrames','npcContact'],'oriented spring');const g=room.map.geometry.find(g=>g.id===q.id);
  if(!safe(q.id)||seen.has(q.id)||!g||g.collision!=='solid'||!rect(g)||!finite(g.w,1,64)||!finite(g.h,8,64)||!['vertical','horizontal'].includes(q.orientation)||!finite(q.launchSpeed,.1,12)||!integer(q.compressionFrames,1,60)||!integer(q.cooldownFrames,0,240))throw Error('Oriented spring needs real independent solid geometry');seen.add(q.id);
  // Optional NPC coefficients are independent of the existing player tune.
  // Only a fixed vertical top has an observed regular-Koopa launch reference;
  // binding a Spring to a moving carrier does not inherit this capability.
  if(q.npcContact!==undefined){
   fields(q.npcContact,['compressionFrames','launchSpeed','compressionDepth'],'NPC Spring contact');
   validateNpcSpringContactSpec({id:q.id,...q.npcContact});
   if(q.orientation!=='vertical'||g.springOrientation==='horizontal'||g.material!=='spring'||g.hidden||g.motion||g.liftSpeed||(s.carrierGeometry||[]).some(binding=>binding.id===q.id)||room.marioModules?.contactPlatforms?.[q.id])throw Error('NPC Spring contact needs a static vertical Springboard');
   if(q.npcContact.compressionDepth!==undefined&&q.npcContact.compressionDepth>=g.h)throw Error('NPC Spring compressionDepth must leave a positive body');
  }
 }}
}
/** Authored framing policy fitted to the observed closed-wall/open-exit view.
 * It is not a claim about the original engine's binary camera algorithm.
 * Returns a maximum viewport-right coordinate until every referenced native
 * body has actually been removed; null releases the cap. Runtime tiled bodies
 * retain sourceId, so partial destruction of one body cannot release it early.
 * The host applies this ONLY to camera framing, never world/motor bounds. */
export function horizontalCameraBarrierRight(room,geometry=room?.map?.geometry||[]){
 const barrier=room?.smm2Mechanics?.camera?.horizontalBarrier;if(!barrier)return null;
 const ids=new Set(barrier.releaseWhenRemovedGeometryIds);
 return geometry.some(g=>ids.has(g.id)||ids.has(g.sourceId))?barrier.right:null;
}
export function goalCardAt(room,tick=0){const q=room?.smm2Mechanics?.goalCard;if(!q)return null;return q.cycle[Math.floor((Math.max(0,tick)+q.phaseFrames)/q.framesPerCard)%q.cycle.length];}
export function createSmm2GoalCard(room,{emit=()=>{}}={}){
 validateSmm2CourseComponents(room);const q=room?.smm2Mechanics?.goalCard;if(!q)return null;
 const source=room.map.objects.find(o=>o.id===q.id),spec=copy(q);let spent=false;
 function contact(player,{tick,object=source}={}){if(spent||!integer(tick,0,Number.MAX_SAFE_INTEGER)||object.id!==spec.id||!rect(player)||!overlap(player,object))return null;spent=true;const result=goalCardAt(room,tick),reward=copy(spec.rewards[result]),finish={card:true,phase:'card-reveal',age:0,x:source.x,y:source.y,cardId:spec.id,result,contactTick:tick,reward,revealFrames:spec.revealFrames,walkTarget:source.x+source.w+spec.walkDistance,clearFrames:spec.clearFrames};emit('smm2-goal-card',{event:'card-contact',roomId:room.roomId,cardId:spec.id,result,tick,reward});return finish;}
 return Object.freeze({contact,view:tick=>({id:spec.id,current:goalCardAt(room,tick),spent}),reset:()=>{spent=false;}});
}
/** Real side impact transfers velocity after a brief visible compression.
 * The host retains native collision resolution and does not warp the actor. */
export function createSmm2SideSprings(room,{emit=()=>{}}={}){
 validateSmm2CourseComponents(room);const rules=(room?.smm2Mechanics?.springs||[]).filter(q=>q.orientation==='horizontal');if(!rules.length)return null;
 const states=new Map(rules.map(q=>[q.id,{rule:copy(q),age:0,direction:0,cooldown:0,lastTick:null,actor:null}]));
 function beforeFrame(geometry,{tick}={}){for(const state of states.values()){if(state.lastTick===tick)continue;state.lastTick=tick;if(state.cooldown)state.cooldown--;const g=geometry.find(g=>g.id===state.rule.id);if(g)g.springAge=state.age;if(state.age){state.age++;if(state.age>state.rule.compressionFrames){const a=state.actor;const contact=a&&g&&a.y+a.h>g.y+EPS&&a.y<g.y+g.h-EPS&&Math.abs(state.direction<0?a.x+a.w-g.x:a.x-g.x-g.w)<=1.01;if(contact&&!a.dead&&!a.dying&&!a.clawHeld){a.vx=state.direction*state.rule.launchSpeed;a.airCap=Math.max(a.airCap||0,state.rule.launchSpeed);emit('smm2-spring',{event:'side-release',roomId:room.roomId,deviceId:state.rule.id,tick,direction:state.direction,speed:state.rule.launchSpeed});}state.age=0;state.actor=null;state.cooldown=state.rule.cooldownFrames;}}}}
 function afterActor(actor,before,{tick,geometry=[]}={}){if(!rect(actor)||!rect(before)||actor.clawHeld||actor.dead||actor.dying)return false;for(const state of states.values()){if(state.age||state.cooldown)continue;const g=geometry.find(g=>g.id===state.rule.id);if(!g||actor.y+actor.h<=g.y+EPS||actor.y>=g.y+g.h-EPS)continue;const left=before.x+before.w<=g.x+1.01&&before.vx>0&&Math.abs(actor.x+actor.w-g.x)<=1.01,right=before.x>=g.x+g.w-1.01&&before.vx<0&&Math.abs(actor.x-g.x-g.w)<=1.01;if(!left&&!right)continue;state.age=1;state.direction=left?-1:1;state.actor=actor;actor.vx=0;emit('smm2-spring',{event:'side-impact',roomId:room.roomId,deviceId:state.rule.id,tick,direction:state.direction});return true;}return false;}
 return Object.freeze({beforeFrame,afterActor,view:()=>[...states.values()].map(s=>({id:s.rule.id,age:s.age,direction:s.direction,cooldown:s.cooldown})),reset:()=>{for(const s of states.values()){s.age=0;s.direction=0;s.cooldown=0;s.lastTick=null;s.actor=null;}}});
}
