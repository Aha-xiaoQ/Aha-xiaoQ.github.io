import {GHOST_SOURCE_PIXELS} from './editor-smm2-ghost-source-pixels.mjs';

/** Recovered SMM1 SMB1 16×16 P source frame. Only the bounded P glyph is
 * adapted from dark blue to white for the observed Story43 appearance.
 * Loose pipe-supplied and authored items use this same source family.
 * The pressed 4px strip is a source-frame crop, not recovered animation. */
export const SMM2_P_SWITCH_ART=Object.freeze({source:'ghostPSwitch',glyphAdaptation:'white bounded P glyph only',pressedFrame:'approximate bottom-four-row source crop',originalAnimationCalibrated:false});
export function drawSmm2PSwitch(c,actor){
 if(!actor)return false;if(actor.dead||actor.removed||actor.hidden||actor.visible===false||actor.smm2PSwitch?.phase==='removed')return true;
 const frame=GHOST_SOURCE_PIXELS.ghostPSwitch;if(!frame)throw Error('Missing embedded original P Switch source pixels');
 const pressed=actor.pressed===true||actor.smm2PSwitch?.phase==='pressed',down=actor.smm2PSwitch?.orientation==='down'||actor.orientation==='down',rows=pressed?4:16,start=pressed?12:0,w=actor.w??16,h=actor.h??16,height=pressed?Math.min(4,h):h;
 c.save();c.imageSmoothingEnabled=false;c.translate(actor.x,actor.y+(down?height:h-height));c.scale(w/16,(down?-1:1)*height/rows);
 for(let y=start;y<16;y++)for(let x=0;x<16;x++){const index=parseInt(frame.rows[y][x],36),color=frame.palette[index];if(!color||color.endsWith('00'))continue;c.fillStyle=!pressed&&x>=5&&x<=10&&y>=4&&y<=10&&index===1?'#ffffff':color;c.fillRect(x,y-start,1,1);}
 c.restore();return true;
}
