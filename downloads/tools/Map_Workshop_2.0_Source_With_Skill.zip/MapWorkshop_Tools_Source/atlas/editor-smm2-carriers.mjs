/** Optional gravity-affected Springboards/POWs on explicitly permitted live tops.
 * Source placement verifies initial support only. No rigid attachment, route
 * script, Mario motor, bounce force, reward, or bare Thwomp standing policy. */
import {createSMM2Terrain,sampleSMM2Surface} from './editor-smm2-terrain.mjs';
const EPS=1e-7;
const plain=v=>v&&typeof v==='object'&&!Array.isArray(v)&&[Object.prototype,null].includes(Object.getPrototypeOf(v));
const finite=(v,a,b)=>Number.isFinite(v)&&v>=a&&v<=b;
const unsafe=k=>['__proto__','prototype','constructor'].includes(k);
const id=v=>typeof v==='string'&&v.length<=72&&/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(v)&&!unsafe(v);
const rect=v=>plain(v)&&['x','y','w','h'].every(k=>Number.isFinite(v[k]))&&v.w>0&&v.h>0;
const pose=v=>({x:v.x,y:v.y,w:v.w,h:v.h});
const copy=v=>structuredClone(v);
const fail=s=>{throw Error(s);};
const alive=v=>v&&!v.dead&&!v.dying&&!v.removed&&v.visible!==false;
const same=(a,b)=>a&&b&&['x','y','w','h'].every(k=>Math.abs(a[k]-b[k])<=1e-6);
const overlapX=(a,b)=>a.x+a.w>b.x+EPS&&a.x<b.x+b.w-EPS;
const overlap=(a,b)=>overlapX(a,b)&&a.y+a.h>b.y+EPS&&a.y<b.y+b.h-EPS;
const lerp=(a,b,t)=>a+(b-a)*t;
function overlapPolygon(a,polygon){
 if(!Array.isArray(polygon)||polygon.length<3||polygon.length>8||polygon.some(p=>!plain(p)||!finite(p.x,-32768,65536)||!finite(p.y,-32768,65536)))fail('Invalid SMM2 carrier obstruction polygon');
 const axes=[{x:1,y:0},{x:0,y:1}],corners=[{x:a.x,y:a.y},{x:a.x+a.w,y:a.y},{x:a.x+a.w,y:a.y+a.h},{x:a.x,y:a.y+a.h}];
 for(let n=0;n<polygon.length;n++){const p=polygon[n],q=polygon[(n+1)%polygon.length],dx=q.x-p.x,dy=q.y-p.y,length=Math.hypot(dx,dy);if(length>EPS)axes.push({x:-dy/length,y:dx/length});}
 return axes.every(axis=>{const body=corners.map(p=>p.x*axis.x+p.y*axis.y),shape=polygon.map(p=>p.x*axis.x+p.y*axis.y);return Math.max(...body)>Math.min(...shape)+EPS&&Math.min(...body)<Math.max(...shape)-EPS;});
}
function boundedRect(q,map,label){if(!rect(q)||!finite(q.x,0,map.width-q.w)||!finite(q.y,0,map.height-q.h))fail(label+' needs a real rectangle inside this room');}
function nativeMoving(q,map){
 if(q.motion){const m=q.motion,extent=m.axis==='x'?map.width-q.w:map.height-q.h;return plain(m)&&['x','y'].includes(m.axis)&&finite(m.min,0,extent)&&finite(m.max,m.min+EPS,extent)&&finite(m.speed,EPS,256)&&finite(q[m.axis],m.min,m.max);}
 return finite(q.liftSpeed,-64,64)&&Math.abs(q.liftSpeed)>EPS;
}
export function validateSmm2CarriersRoom(room,spec=room?.smm2Mechanics){
 if(spec===undefined)return;
 if(!plain(spec)||spec.version!==1||Object.keys(spec).some(unsafe))fail('Invalid SMM2 carrier mechanics version');
 if(spec.carrierGeometry===undefined&&spec.carrierItems===undefined)return;
 for(const key of ['carrierGeometry','carrierItems'])if(spec[key]!==undefined&&(!Array.isArray(spec[key])||spec[key].length>256))fail('Invalid bounded SMM2 '+key+' list');
 const map=room?.map;if(!plain(map)||!finite(map.width,1,32768)||!finite(map.height,1,4096)||!Array.isArray(map.geometry)||map.geometry.length>20000||!Array.isArray(map.objects)||map.objects.length>20000)fail('SMM2 carriers need bounded native room geometry and actors');
 const childIds=new Set(),all=new Map();for(const q of [...map.geometry,...map.objects]){if(!plain(q)||!id(q.id)||all.has(q.id))fail('Ambiguous or invalid SMM2 carrier source ID');all.set(q.id,q);}
 const geometryIds=new Set(map.geometry.map(q=>q.id)),thwompIds=new Set((spec.thwomps||[]).map(q=>q.id)),powSpecs=new Map((spec.powBlocks||[]).map(q=>[q.id,q])),seesawIds=new Set((spec.seesaws||[]).map(q=>q.id));
 let sourceSurfaces;
 for(const [key,bindings] of [['carrierGeometry',spec.carrierGeometry||[]],['carrierItems',spec.carrierItems||[]]])for(const q of bindings){
  const shaped=q?.carrierType==='seesaw',fields=shaped&&key==='carrierGeometry'?['id','carrierId','carrierType','mass','gravity','maxFallSpeed']:['id','carrierId'];
  if(!plain(q)||Object.keys(q).some(k=>!fields.includes(k))||!id(q.id)||!id(q.carrierId)||q.id===q.carrierId||childIds.has(q.id))fail('Invalid, duplicate or self SMM2 carrier binding');childIds.add(q.id);
  const child=all.get(q.id),parent=all.get(q.carrierId);
  if(key==='carrierGeometry'){if(!geometryIds.has(q.id)||child?.material!=='spring'||child.collision!=='solid'||child.motion||child.liftSpeed)fail('SMM2 carrier child must be an existing independent solid Springboard');}
  else if(geometryIds.has(q.id)||child?.kind!=='walker'||!powSpecs.has(q.id)||powSpecs.get(q.id).rail||!finite(powSpecs.get(q.id).gravity,0,64)||!finite(powSpecs.get(q.id).maxFallSpeed,.001,256))fail('SMM2 carrier item must be an existing independent declared POW without a rail and with finite gravity');
  boundedRect(child,map,key==='carrierGeometry'?'Springboard':'POW');
  if(shaped){
   if(key!=='carrierGeometry'||!seesawIds.has(q.carrierId)||all.has(q.carrierId)||![16,32].includes(child.w)||child.h!==child.w||child.springOrientation==='horizontal'||spec.springs?.some(s=>s.id===q.id&&s.orientation==='horizontal'))fail('Typed seesaw carrier needs a real seesaw and vertical Springboard with a square 16x16 or authored 32x32 rest body');
   if(!finite(q.mass,.001,10000)||!finite(q.gravity,.001,4)||!finite(q.maxFallSpeed,.001,64))fail('Typed seesaw Springboard needs bounded authored mass and gravity');
   sourceSurfaces??=createSMM2Terrain(room)?.surfaces();const surface=sourceSurfaces?.find(s=>s.id===q.carrierId&&s.kind==='seesaw'),sample=surface&&sampleSMM2Surface(surface,child.x,child.w);
   if(!sample||Math.abs(child.y+child.h-sample.y)>EPS)fail('Source Springboard bottom must really touch its initial seesaw top');
   continue;
  }
  if(!parent)fail('SMM2 carrier needs an existing same-room parent');boundedRect(parent,map,'Carrier');
  if(geometryIds.has(q.carrierId)){if(!['solid','oneway'].includes(parent.collision)||!nativeMoving(parent,map))fail('SMM2 carrier geometry must be an existing native moving rectangle');}
  else if(parent.kind!=='walker'||!thwompIds.has(q.carrierId))fail('SMM2 actor carrier must be an existing declared Thwomp');
  if(Math.abs(child.y+child.h-parent.y)>EPS||!overlapX(child,parent))fail('Source carried body bottom must really touch and overlap its carrier top');
 }
 // These leaves support direct native parents only, never hidden mount chains.
 for(const q of [...spec.carrierGeometry||[],...spec.carrierItems||[]])if(childIds.has(q.carrierId))fail('Nested or cyclic SMM2 carrier bindings are unsupported');
}
function interval(p,d,min,max){if(Math.abs(d)<=EPS)return p>min+EPS&&p<max-EPS?{entry:-Infinity,exit:Infinity}:null;const a=(min-p)/d,b=(max-p)/d;return {entry:Math.min(a,b),exit:Math.max(a,b)};}
function sweepRect(a,d,q){
 if(q.collision==='oneway'){
  const gap=q.y-a.y-a.h;if(d.y<=EPS||gap<-EPS||gap>d.y+EPS)return null;const fraction=Math.max(0,Math.min(1,gap/d.y)),x=a.x+d.x*fraction;if(!overlapX({...a,x},q))return null;return {fraction,normal:{x:0,y:-1},solidId:q.id,body:{x,y:a.y+d.y*fraction,w:a.w,h:a.h}};
 }
 const x=interval(a.x,d.x,q.x-a.w,q.x+q.w),y=interval(a.y,d.y,q.y-a.h,q.y+q.h);if(!x||!y)return null;const entry=Math.max(x.entry,y.entry),exit=Math.min(x.exit,y.exit),embedded=overlap(a,q);
 if(!embedded&&(entry<-EPS||entry>1+EPS||exit<=Math.max(0,entry)+EPS))return null;
 const fraction=embedded?0:Math.max(0,Math.min(1,entry)),normal=embedded?(Math.abs(d.y)>=Math.abs(d.x)?{x:0,y:-Math.sign(d.y)}:{x:-Math.sign(d.x),y:0}):x.entry>y.entry?{x:-Math.sign(d.x),y:0}:{x:0,y:-Math.sign(d.y)};
 return {fraction,normal,solidId:q.id,body:{x:a.x+d.x*fraction,y:a.y+d.y*fraction,w:a.w,h:a.h},embedded};
}
function parentTopHit(a,d,motion,start=0){
 const from={...motion.from,x:lerp(motion.from.x,motion.to.x,start),y:lerp(motion.from.y,motion.to.y,start)},dx=motion.to.x-from.x,dy=motion.to.y-from.y,gap=from.y-a.y-a.h,closing=d.y-dy;
 if(gap<-EPS||closing<-EPS||closing<=EPS&&gap>EPS)return null;const fraction=closing<=EPS?0:Math.max(0,Math.min(1,gap/closing));if(gap>closing+EPS)return null;
 const child={...a,x:a.x+d.x*fraction,y:a.y+d.y*fraction},parent={...from,x:from.x+dx*fraction,y:from.y+dy*fraction};if(!overlapX(child,parent))return null;
 return {fraction,normal:{x:0,y:-1},solidId:motion.id,body:child,parentTop:true,point:{x:Math.max(child.x,parent.x),y:parent.y}};
}
/** Engine options are explicit authored approximations, not measured SMM2 forces. */
export function createSmm2Carriers(room,{gravity=.3,maxFallSpeed=4.25,terrain=null}={}){
 validateSmm2CarriersRoom(room);const bindings=[...(room?.smm2Mechanics?.carrierGeometry||[]).map(q=>({...q,childKind:'geometry'})),...(room?.smm2Mechanics?.carrierItems||[]).map(q=>({...q,childKind:'pow'}))];if(!bindings.length)return null;
 if(!finite(gravity,.001,4)||!finite(maxFallSpeed,.001,64)||terrain!==null&&(!terrain||typeof terrain.sweep!=='function'))fail('Invalid SMM2 Springboard carrier gravity or terrain port');
 const map=room.map,source=new Map([...map.geometry,...map.objects].map(q=>[q.id,copy(q)])),geometryIds=new Set(map.geometry.map(q=>q.id)),definitions=bindings.map(q=>({...copy(q),kind:q.carrierType==='seesaw'?'seesaw':geometryIds.has(q.carrierId)?'geometry':'thwomp'})),parentIds=[...new Set(definitions.filter(q=>q.kind==='thwomp').map(q=>q.carrierId))],powDefinitions=new Map((room.smm2Mechanics.powBlocks||[]).map(q=>[q.id,copy(q)])),initialSurfaces=definitions.some(q=>q.kind==='seesaw')?createSMM2Terrain(room).surfaces():[];
 if(definitions.some(q=>q.kind==='seesaw')&&(!terrain||typeof terrain.surfaces!=='function'||typeof terrain.recordImpact!=='function'||typeof terrain.clearActorContact!=='function'||typeof terrain.validateMovingTopContact!=='function'))fail('Typed seesaw Springboard needs the live terrain controller');
 let states,lastTick,actorTicks,itemTicks;
 function reset(){lastTick=null;actorTicks=new WeakMap();itemTicks=new WeakMap();states=new Map(definitions.map(q=>{const child=source.get(q.id),parent=source.get(q.carrierId);return [q.id,{...q,x:child.x,y:child.y,w:child.w,h:child.h,vx:0,vy:0,dx:0,dy:0,phase:'supported',supportId:q.carrierId,parentPose:parent?pose(parent):null,parentSurface:q.kind==='seesaw'?copy(initialSurfaces.find(s=>s.id===q.carrierId)):null,carrierUnavailable:false,collider:null,previousCollider:null,currentCollider:null,contact:null,blocked:null,offset:parent?{x:child.x-parent.x,y:child.y-parent.y}:null}];}));}
 reset();
 function parentActorIds(){return [...parentIds];}
 function ownsItem(a){return states.get(a?.id)?.childKind==='pow';}
 function hasWeightedSpringBodies(){return definitions.some(q=>q.kind==='seesaw');}
 /** The same geometry bodies drive native collision, compression and weight.
  * Legacy/static springs never gain a terrain mass or standable proxy. */
 function physicsActors(geometry){
  if(!Array.isArray(geometry)||geometry.length>20000)fail('Invalid Springboard physics geometry');
  const result=[];
  for(const s of states.values())if(s.kind==='seesaw'&&s.phase!=='removed'){
   const q=geometry.find(q=>q.id===s.id);if(!q||!alive(q))continue;
   if(!s.collider){q.vx=0;q.vy=0;q.grounded=true;q.support=s.carrierId;q.smm2Mass=s.mass;q.standable=true;q.smm2CarrierGeometry={carrierId:s.carrierId,carrierType:'seesaw',phase:s.phase,supportId:s.supportId};s.collider=q;}
   if(q!==s.collider)fail('Weighted Springboard physics needs its actual collision body');result.push(q);
  }
  return result;
 }
 function geometryForActor(geometry,actor){if(!Array.isArray(geometry)||geometry.length>20000)fail('Invalid SMM2 carrier actor geometry');const children=new Set(definitions.filter(q=>q.carrierId===actor?.id).map(q=>q.id));return children.size?geometry.filter(q=>!children.has(q.id)):geometry;}
 function measuredParent(s,geometries,actors,tick){
  if(s.carrierUnavailable)return null;const parent=(s.kind==='geometry'?geometries:actors).get(s.carrierId);if(!alive(parent)||!rect(parent)){s.carrierUnavailable=true;return null;}
  const original=source.get(s.carrierId);if(parent.w!==original.w||parent.h!==original.h||!finite(parent.x,-1024,map.width+1024)||!finite(parent.y,-1024,map.height+1024))fail('Carrier changed its actual source body bounds');
  const to=pose(parent),from=s.parentPose;let dx=to.x-from.x,dy=to.y-from.y;
  if(s.kind==='thwomp'){
   const motion=parent.smm2Thwomp?.lastMotion;if(Math.abs(dx)>EPS||Math.abs(dy)>EPS){if(!plain(motion)||motion.tick!==tick||!same(motion.from,from)||!same(motion.to,to))fail('Moving Thwomp carrier needs its actual current lastMotion');}
  }else if(Math.abs(dx)>EPS||Math.abs(dy)>EPS){
   if(!finite(parent.dx,-256,256)||!finite(parent.dy,-256,256)||Math.abs(parent.dx-dx)>1e-6||Math.abs(parent.dy-dy)>1e-6){s.carrierUnavailable=true;return null;}
  }
  if(!finite(dx,-256,256)||!finite(dy,-256,256))fail('Unbounded live carrier displacement');s.parentPose=to;return {id:s.carrierId,from,to,dx,dy};
 }
 function nearest(a,d,geometry,tick,{excludeTerrainId,movingTop=false}={}){
  let best=null;for(const q of geometry){if(!rect(q)||q.hidden||!alive(q)||!['solid','oneway'].includes(q.collision)||terrain?.ownsGeometry?.(q))continue;const hit=sweepRect(a,d,q);if(hit&&(!best||hit.fraction<best.fraction-EPS||Math.abs(hit.fraction-best.fraction)<=EPS&&hit.solidId<best.solidId))best=hit;}
  const hit=terrain?.sweep(a,d,{tick,movingTop,excludeIds:excludeTerrainId?[excludeTerrainId]:[]});if(hit){
   const measured=hit.surfaceMotion&&terrain.validateMovingTopContact(a,d,hit,{tick});
   if(!plain(hit)||!finite(hit.fraction,0,1)||!rect(hit.body)||hit.body.w!==a.w||hit.body.h!==a.h||!measured&&(Math.abs(hit.body.x-a.x-d.x*hit.fraction)>1e-6||Math.abs(hit.body.y-a.y-d.y*hit.fraction)>1e-6)||hit.surfaceMotion&&!measured||!id(hit.solidId)||!plain(hit.normal)||!finite(hit.normal.x,-1,1)||!finite(hit.normal.y,-1,1)||Math.abs(Math.hypot(hit.normal.x,hit.normal.y)-1)>1e-6)fail('Invalid SMM2 carrier shaped collision');
   if(!best||hit.fraction<best.fraction-EPS)best=hit;
  }return best;
 }
 function worldMove(a,d,geometry,tick,options){
  let remaining={...d},blocked=null,supportId=null;
  for(let n=0;n<4;n++){
   if(Math.hypot(remaining.x,remaining.y)<=EPS)break;const hit=nearest(a,remaining,geometry,tick,options),f=hit?.fraction??1;a.x+=remaining.x*f;a.y+=remaining.y*f;if(!hit)break;blocked=hit;if(hit.normal.y<0)supportId=hit.solidId;
   remaining={x:Math.abs(hit.normal.x)>EPS?0:remaining.x*(1-f),y:Math.abs(hit.normal.y)>EPS?0:remaining.y*(1-f)};
  }return {blocked,supportId};
 }
 function advance(s,depth,motion,geometry,tick,physics={}){
  const before={x:s.x,y:s.y},a={x:s.x,y:s.y+depth,w:s.w,h:s.h-depth},supported=motion&&s.supportId===s.carrierId&&overlapX(a,motion.from)&&Math.abs(a.y+a.h-motion.from.y)<=EPS;
  const vx=physics.vx||0;s.vx=vx;s.vy=Math.min(physics.maxFallSpeed??maxFallSpeed,s.vy+(physics.gravity??gravity));let d={x:vx+(supported?motion.dx:0),y:s.vy},time=0,contact=null,blocked=null,supportId=null;
  for(let n=0;n<4;n++){
   const staticHit=nearest(a,d,geometry,tick),parentHit=motion?parentTopHit(a,d,motion,time):null,hit=parentHit&&(!staticHit||parentHit.fraction<staticHit.fraction-EPS)?parentHit:staticHit;
   const fraction=hit?.fraction??1;a.x+=d.x*fraction;a.y+=d.y*fraction;time+=fraction*(1-time);if(!hit)break;contact=hit;
   if(hit.parentTop){
    const carry={x:(motion.dx+vx)*(1-time),y:motion.dy*(1-time)},moved=worldMove(a,carry,geometry,tick);blocked=moved.blocked;supportId=moved.supportId;if(blocked?.normal.x)s.vx=0;
    if(overlapX(a,motion.to)&&Math.abs(a.y+a.h-motion.to.y)<=EPS){supportId=motion.id;s.vy=0;}
    else if(blocked?.normal.y)s.vy=0;break;
   }
   blocked=hit;if(hit.normal.x)s.vx=0;if(Math.abs(hit.normal.y)>EPS)s.vy=0;if(hit.normal.y<0)supportId=hit.solidId;
   d={x:Math.abs(hit.normal.x)>EPS?0:d.x*(1-fraction),y:Math.abs(hit.normal.y)>EPS?0:d.y*(1-fraction)};if(Math.hypot(d.x,d.y)<=EPS)break;
  }
  s.x=a.x;s.y=a.y-depth;s.dx=s.x-before.x;s.dy=s.y-before.y;s.supportId=supportId;s.contact=contact?copy(contact):null;s.blocked=blocked?copy(blocked):null;s.phase=s.y>map.height?'removed':supportId===s.carrierId?'supported':supportId?'resting':'airborne';
 }
 function advanceSeesaw(s,depth,geometry,tick){
  const q=s.collider,before={x:s.x,y:s.y},a={x:s.x,y:s.y+depth,w:s.w,h:s.h-depth},surfaces=terrain.surfaces(),old=s.supportSurface||s.parentSurface,current=surfaces.find(v=>v.kind==='seesaw'&&v.id===s.supportId),prior=old&&sampleSMM2Surface(old,a.x,a.w),sample=current&&sampleSMM2Surface(current,a.x+(q.vx||0),a.w);
  if(!finite(q.vx??0,-256,256)||!finite(q.vy??0,-256,256))fail('Invalid weighted Springboard velocity');
  s.vx=q.vx??0;s.vy=Math.min(s.maxFallSpeed,s.vy+s.gravity);
  const supported=q.grounded&&q.vy>=0&&old?.id===s.supportId&&prior&&Math.abs(a.y+a.h-prior.y)<=EPS;
  let supportId=null,contact=null,blocked=null;
  if(supported&&sample&&sample.y-a.y-a.h<=s.vy+EPS){
   // A top can push up, but cannot pull down faster than the body's gravity.
   const moved=worldMove(a,{x:s.vx,y:sample.y-a.y-a.h},geometry,tick,{excludeTerrainId:current.id});blocked=moved.blocked;
   if(blocked?.normal.x)s.vx=0;if(blocked?.normal.y)s.vy=0;
   const at=sampleSMM2Surface(current,a.x,a.w);
   if(at&&Math.abs(a.y+a.h-at.y)<=EPS){supportId=current.id;s.vy=0;contact={solidId:current.id,normal:{x:at.gradient/Math.hypot(at.gradient,1),y:-1/Math.hypot(at.gradient,1)},point:{x:at.x,y:at.y},incomingVelocity:{x:s.vx,y:0},body:pose(a)};}
   else supportId=moved.supportId;
  }else{
   let remaining={x:s.vx,y:s.vy};
   for(let n=0;n<4;n++){
    const hit=nearest(a,remaining,geometry,tick,{movingTop:true}),fraction=hit?.fraction??1;a.x+=remaining.x*fraction;a.y+=remaining.y*fraction;if(!hit)break;contact=hit;
    if(hit.surfaceMotion){
     const moved=worldMove(a,{x:hit.body.x-a.x,y:hit.body.y-a.y},geometry,tick,{excludeTerrainId:hit.solidId});blocked=moved.blocked;
     if(!same(a,hit.body)){supportId=moved.supportId;s.vy=0;break;}
    }
    blocked??=hit;if(hit.normal.x)s.vx=0;if(hit.normal.y)s.vy=0;if(hit.normal.y<0)supportId=hit.solidId;
    remaining={x:hit.normal.x?0:remaining.x*(1-fraction),y:hit.normal.y?0:remaining.y*(1-fraction)};if(Math.hypot(remaining.x,remaining.y)<=EPS)break;
   }
  }
  s.x=a.x;s.y=a.y-depth;s.dx=s.x-before.x;s.dy=s.y-before.y;s.supportId=supportId;s.contact=contact?copy(contact):null;s.blocked=blocked?copy(blocked):null;s.phase=s.y>map.height?'removed':supportId===s.carrierId?'supported':supportId?'resting':'airborne';
  s.parentSurface=copy(surfaces.find(v=>v.id===s.carrierId)||null);s.supportSurface=copy(surfaces.find(v=>v.id===supportId)||null);
 }
 function apply(geometry,actors,{tick}={}){
  if(!Array.isArray(geometry)||geometry.length>20000||!Array.isArray(actors)||actors.length>4096||!Number.isSafeInteger(tick)||tick<0)fail('Invalid SMM2 carrier frame');
  const geometries=new Map(),liveActors=new Map();for(const [entries,index]of [[geometry,geometries],[actors,liveActors]])for(const q of entries){if(!plain(q)||typeof q.id!=='string')continue;if(index.has(q.id))fail('Duplicate live SMM2 carrier input ID');index.set(q.id,q);}
  const advanceTick=lastTick===null||tick>lastTick;if(advanceTick)lastTick=tick;
  let result=geometry.filter(q=>states.get(q.id)?.childKind!=='geometry');
  for(const s of states.values()){
   if(s.childKind!=='geometry'){const a=liveActors.get(s.id);if(!alive(a)||a.taken||a.smm2Pow?.phase==='spent'){s.phase='removed';s.supportId=null;s.previousCollider=s.currentCollider=null;}continue;}
   if(s.kind==='seesaw'&&(s.phase==='removed'||!alive(geometries.get(s.id)))){s.phase='removed';s.supportId=null;s.previousCollider=s.currentCollider=null;if(s.collider)terrain.clearActorContact(s.collider);continue;}
   const original=source.get(s.id),input=geometries.get(s.id),fresh=input?.smm2CarrierGeometry===undefined,current=s.collider&&fresh?s.collider:input,depth=current?.restY!==undefined?current.y-current.restY:current?.h!==undefined?original.h-current.h:0;
   if(!finite(depth,0,original.h-EPS))fail('Invalid native Springboard compression on carrier');
   if(advanceTick){const previous=current||original;if(s.phase!=='removed'&&(!rect(previous)||Math.abs(previous.x-s.x)>1e-6||Math.abs(previous.y-s.y-depth)>1e-6||Math.abs(previous.w-s.w)>1e-6||Math.abs(previous.h-s.h+depth)>1e-6))fail('Springboard contact history needs its actual owned body and native compression');s.previousCollider=s.phase==='removed'?null:pose(previous);const world=[...geometry.filter(q=>q.id!==s.id&&q.id!==s.carrierId),...result.filter(q=>states.has(q.id)&&!geometry.some(g=>g.id===q.id))];
    if(s.kind==='seesaw'){if(!s.collider)physicsActors(geometry);s.vy=s.collider.vy;s.supportId=s.collider.grounded?s.collider.support:null;advanceSeesaw(s,depth,world,tick);}else advance(s,depth,measuredParent(s,geometries,liveActors,tick),world,tick);
   }
   if(s.phase==='removed')continue;
   const q=input||{...copy(original)};if(current&&current!==q)for(const key of ['springAge','boost','launchVx'])if(current[key]!==undefined)q[key]=current[key];
   q.x=s.x;q.restY=s.y;q.restH=s.h;q.y=s.y+depth;q.w=s.w;q.h=s.h-depth;q.material='spring';q.collision='solid';q.dx=s.dx;q.dy=s.dy;q.smm2CarrierGeometry={carrierId:s.carrierId,phase:s.phase,supportId:s.supportId};s.collider=q;if(advanceTick)s.currentCollider=pose(q);result.push(q);
   if(s.kind==='seesaw'){
    Object.assign(q,{vx:s.vx,vy:s.vy,grounded:!!s.supportId,support:s.supportId,smm2Mass:s.mass,standable:true});q.smm2CarrierGeometry.carrierType='seesaw';
    if(s.contact&&s.supportSurface&&q.grounded)terrain.recordImpact(q,{...s.contact,solidId:s.supportId,incomingVelocity:s.contact.incomingVelocity||{x:s.vx,y:0}},{tick});
   }
  }return result;
 }
 /** The item controller calls this only for explicitly bound POWs, after the
  * real parent has moved. No enemy top enters Mario's collision geometry. */
 function stepItem(a,{tick,geometry=[],actors=[],held=false}={}){
  if(!ownsItem(a))return null;
  if(!Number.isSafeInteger(tick)||tick<0||!Array.isArray(geometry)||geometry.length>20000||!Array.isArray(actors)||actors.length>20000||typeof held!=='boolean'||!rect(a))fail('Invalid SMM2 carrier item frame');
  const s=states.get(a.id);if(itemTicks.get(a)===tick)return {advanced:false,phase:s.phase};itemTicks.set(a,tick);
  const original=source.get(a.id);if(a.w!==original.w||a.h!==original.h||!finite(a.x,-1024,map.width+1024)||!finite(a.y,-1024,map.height+1024)||!finite(a.vx??0,-256,256)||!finite(a.vy??0,-256,256))fail('Carried POW changed its real source bounds or bounded velocity');
  if(!alive(a)||a.taken||a.smm2Pow?.phase==='spent'||s.phase==='removed'){s.phase='removed';s.supportId=null;s.previousCollider=s.currentCollider=null;return {advanced:false,phase:s.phase};}
  const geometries=new Map(geometry.map(q=>[q.id,q])),liveActors=new Map(actors.map(q=>[q.id,q]));
  const motion=measuredParent(s,geometries,liveActors,tick),before=pose(a),fresh=s.currentCollider===null;
  s.x=a.x;s.y=a.y;s.w=a.w;s.h=a.h;s.vy=Number.isFinite(a.vy)?a.vy:0;
  if(!fresh||!same(a,source.get(a.id)))s.supportId=a.support??null;
  s.previousCollider=before;
  if(held){s.supportId=null;s.phase='airborne';s.dx=s.dy=0;s.currentCollider=pose(a);return {advanced:false,held:true,phase:s.phase};}
  const q=powDefinitions.get(a.id),world=geometry.filter(g=>g.id!==a.id&&g.id!==s.carrierId);
  advance(s,0,motion,world,tick,{gravity:q.gravity,maxFallSpeed:q.maxFallSpeed,vx:Number.isFinite(a.vx)?a.vx:0});
  Object.assign(a,{x:s.x,y:s.y,vx:s.vx,vy:s.vy,grounded:!!s.supportId,support:s.supportId});s.currentCollider=pose(a);
  if(s.phase==='removed'){a.removed=true;a.dead=true;}
  return {advanced:true,phase:s.phase,contact:s.contact?copy(s.contact):null,dx:s.dx,dy:s.dy};
 }
 /** A moving solid top can overtake just-launched feet before the native
  * horizontal pass. Separate only that measured upward crossing, preserving
  * the actor's native velocity and contact state. Other geometry still blocks. */
 function beforeActor(actor,{tick,geometry,verticalDelta}={}){
  if(!Array.isArray(geometry)||geometry.length>20000||!Number.isSafeInteger(tick)||tick<0)fail('Invalid SMM2 carrier actor contact frame');
  if(tick!==lastTick||!rect(actor)||!alive(actor)||actor.grounded||!finite(actor.vy,-256,-EPS)||!finite(actor.x,-1024,map.width+1024)||!finite(actor.y,-1024,map.height+1024)||!finite(actor.w,EPS,256)||!finite(actor.h,EPS,256)||actorTicks.get(actor)===tick)return null;
  const live=new Map();for(const q of geometry){if(!plain(q)||typeof q.id!=='string')continue;if(live.has(q.id))fail('Duplicate live SMM2 carrier contact geometry ID');live.set(q.id,q);}
  actorTicks.set(actor,tick);const foot=actor.y+actor.h,crossings=[];
  for(const s of states.values()){
   const q=live.get(s.id),from=s.previousCollider,to=s.currentCollider;
   const owned=s.childKind==='geometry'?q?.material==='spring'&&q.smm2CarrierGeometry?.carrierId===s.carrierId:q?.material==='smm2-pow'&&q.smm2ItemBody===true;
   if(s.phase==='removed'||!from||!to||!alive(q)||q.hidden||!owned||q.collision!=='solid'||!same(q,to))continue;
   const rise=from.y-to.y,gap=from.y-foot;if(rise<=EPS||gap<-EPS||gap>=rise-EPS||!overlapX(actor,to))continue;
   const freeSpring=s.kind==='seesaw'&&!q.grounded&&finite(verticalDelta,-256,0),closing=rise+(freeSpring?verticalDelta:0);
   if(freeSpring&&(closing<=EPS||gap>=closing-EPS))continue;
   const fraction=Math.max(0,Math.min(1,gap/closing)),at={...from,x:lerp(from.x,to.x,fraction),y:foot};if(!overlapX(actor,at))continue;
   crossings.push({solidId:s.id,fraction,from:copy(from),to:copy(to),...(freeSpring?{verticalDelta}:{})});
  }
  if(!crossings.length)return null;
  const requiredDy=Math.min(...crossings.map(q=>q.to.y-(q.verticalDelta||0)))-foot,crossedIds=new Set(crossings.map(q=>q.solidId)),before=pose(actor);
  // Native hidden blocks still have an underside head collision. They are
  // visible to this upward sweep only when approached from below.
  const world=geometry.filter(q=>!crossedIds.has(q.id)).map(q=>q.hidden&&q.collision==='solid'&&actor.y>=q.y+q.h-EPS?{...q,hidden:false}:q);
  let hit=nearest(before,{x:0,y:requiredDy},world,tick);
  // Exact terrain sweeps expect an initially separated body. An actual
  // pre-existing polygon overlap blocks correction rather than escaping it.
  const surfaces=terrain?.surfaces?.();if(surfaces!==undefined){if(!Array.isArray(surfaces)||surfaces.length>512)fail('Invalid SMM2 carrier obstruction surfaces');for(const q of surfaces)if(q.collision==='solid'&&overlapPolygon(before,q.polygon)){hit={fraction:0,normal:{x:0,y:1},solidId:q.id,body:before,embedded:true};break;}}
  const dy=hit?.fraction===0?0:requiredDy*(hit?.fraction??1);
  actor.y+=dy;
  return {kind:crossings.some(q=>states.get(q.solidId)?.childKind==='pow')?'moving-carried-item-top':'moving-spring-top',tick,before,after:pose(actor),requiredDy,dy,crossings,blocked:hit?copy(hit):null};
 }
 function actorWorld(geometry,actor,excludeId){return geometry.filter(q=>q.id!==excludeId).map(q=>q.hidden&&q.collision==='solid'&&actor.y>=q.y+q.h-EPS?{...q,hidden:false}:q);}
 /** A free moving Spring's top is resolved relative to airborne feet. Its
  * currently-overlapping side must not stop the unchanged motor's horizontal
  * pass when those feet truly came from above. Grounded carry is swept first. */
 function geometryForPlayer(geometry,actor,{tick}={}){
  if(tick!==lastTick||!rect(actor)||!alive(actor))return geometry;
  return geometry.map(q=>{
   const s=states.get(q.id);if(s?.kind!=='seesaw'||s.collider!==q||!s.previousCollider||!s.currentCollider)return q;
   const prior=s.previousCollider;if(!overlapX(actor,prior)||actor.y+actor.h>prior.y+EPS)return q;
   if(!actor.grounded&&actor.vy<0&&!q.grounded&&q.dy<0)return {...q,collision:'oneway'};
   if(actor.grounded&&actor.support===q.id&&Math.abs(actor.y+actor.h-prior.y)<=EPS){
    const a=pose(actor);worldMove(a,{x:q.dx,y:q.dy},actorWorld(geometry,actor,q.id),tick);return {...q,dx:a.x-actor.x,dy:a.y-actor.y};
   }
   return q;
  });
 }
 /** Preserve the native compression bottom anchor while making its real top
  * expansion respect other bodies. This never changes launch velocity. */
 function positionSpringRider(actor,spring,{tick,geometry}={}){
  const s=states.get(spring?.id);if(s?.kind!=='seesaw')return null;
  if(tick!==lastTick||s.collider!==spring||!rect(actor)||!alive(actor))return {reached:false};
  const a=pose(actor),moved=worldMove(a,{x:0,y:spring.y-actor.h-actor.y},actorWorld(geometry,actor,spring.id),tick);
  actor.y=a.y;if(moved.blocked?.normal.y>0)actor.headHit=moved.blocked.solidId;
  return {reached:Math.abs(actor.y+actor.h-spring.y)<=EPS,blocked:moved.blocked};
 }
 function afterCompression(actor,{tick,geometry,before}={}){
  if(tick!==lastTick||!rect(actor)||!alive(actor))return null;
  let expansion=null;
  for(const s of states.values()){
   const q=s.collider,from=s.currentCollider,standing=actor.grounded&&actor.support===q?.id;
   if(s.kind!=='seesaw'||!q||!from||q.y>=from.y-EPS||!standing&&actor.vy>=0||!overlapX(actor,q)||actor.y+actor.h>from.y+EPS||actor.y+actor.h<=q.y+EPS)continue;
   expansion=positionSpringRider(actor,q,{tick,geometry});if(expansion.reached)return expansion;break;
  }
  // The Spring is stepped before the native motor. If the same previously
  // top-touching airborne body actually hits a ceiling, bound that Spring's
  // advance at the body's real feet rather than letting the two overlap.
  for(const s of states.values()){
   const q=s.collider,prior=s.previousCollider;
   if(s.kind!=='seesaw'||!q||!prior||q.y>=prior.y-EPS||!rect(before)||before.y+before.h>prior.y+EPS||!actor.headHit||actor.headHit===q.id||!overlap(actor,q))continue;
   const a=pose(q),moved=worldMove(a,{x:0,y:actor.y+actor.h-q.y},actorWorld(geometry,q,q.id),tick,{excludeTerrainId:s.supportId});
   const correction=a.y-q.y;if(correction<=EPS)continue;
   q.y+=correction;q.restY+=correction;q.dy+=correction;q.vy=0;q.grounded=!!moved.supportId;q.support=moved.supportId;terrain.clearActorContact(q);
   s.y=q.restY;s.dy=q.dy;s.vy=0;s.supportId=q.support;s.phase=q.support===s.carrierId?'supported':q.support?'resting':'airborne';Object.assign(q.smm2CarrierGeometry,{phase:s.phase,supportId:s.supportId});
   return {reached:!overlap(actor,q),blocked:moved.blocked,springStoppedBy:actor.headHit};
  }
  return expansion;
 }
 function afterFrame(){for(const s of states.values())if(s.kind==='seesaw'&&s.collider&&s.phase!=='removed'){const q=s.collider;s.vx=q.vx;s.vy=q.vy;s.supportId=q.grounded?q.support:null;s.phase=s.supportId===s.carrierId?'supported':s.supportId?'resting':'airborne';Object.assign(q.smm2CarrierGeometry,{phase:s.phase,supportId:s.supportId});}}
 function view(){const rows=kind=>[...states.values()].filter(s=>s.childKind===kind).map(({collider,parentSurface,supportSurface,...state})=>copy(state));return {version:1,approximation:true,tick:lastTick,gravity,maxFallSpeed,carrierGeometry:rows('geometry'),carrierItems:rows('pow')};}
 return Object.freeze({parentActorIds,ownsItem,hasWeightedSpringBodies,stepItem,apply,geometryForActor,beforeActor,geometryForPlayer,positionSpringRider,afterCompression,physicsActors,afterFrame,reset,view});
}
