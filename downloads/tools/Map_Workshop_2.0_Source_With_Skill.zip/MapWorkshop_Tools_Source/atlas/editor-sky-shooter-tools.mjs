import {validateSkyShooterRoom,SKY_SHOOTER_FIELDS} from './editor-sky-shooter.mjs';
const clone=q=>structuredClone(q);
function commit(room,next){for(const key of Object.keys(room))if(!Object.hasOwn(next,key))delete room[key];Object.assign(room,next);}
/** Full explicit leaf authoring. Clone, validate, then commit: failed edits do
 * not partially mutate the room or the enclosing native History transaction. */
export function setSkyShooter(room,config){const next=clone(room);(next.smm2Mechanics??={version:1}).skyShooter=clone(config);validateSkyShooterRoom(next);commit(room,next);}
export function removeSkyShooter(room){if(room.smm2Mechanics)delete room.smm2Mechanics.skyShooter;}
/** If any actual previously referenced native body/cloud/gate/reward is deleted,
 * remove the optional group. Never silently reduce the required defeat count or
 * open a reward by pruning one drone. Newly invalid IDs must fail validation. */
export function pruneSkyShooterReferences(room,before){
 const old=before?.smm2Mechanics?.skyShooter,current=room?.smm2Mechanics?.skyShooter;if(!old||!current)return false;
 const changed=key=>JSON.stringify(old[key])!==JSON.stringify(current[key]);
 const objects=new Set(room.map.objects.map(q=>q.id)),geometry=new Set(room.map.geometry.map(q=>q.id)),clouds=new Set(room.smm2Mechanics.lakituClouds?.clouds.map(q=>q.id)||[]);
 if(!changed('cloudId')&&!clouds.has(old.cloudId)||!changed('rewardId')&&!objects.has(old.rewardId)||!changed('gateIds')&&old.gateIds.some(q=>!geometry.has(q))||!changed('drones')&&old.drones.some(q=>!objects.has(q.id))){removeSkyShooter(room);return true;}return false;
}
/** Full group clipboard: partial groups intentionally do not copy a rule which
 * could point back into its source room. Native bodies are pasted by the host. */
export function captureSkyShooterBindings(room,ids){
 if(!(ids instanceof Set))throw Error('Invalid Sky Shooter clipboard selection');validateSkyShooterRoom(room);const s=room.smm2Mechanics?.skyShooter;if(!s)return null;
 const refs=[s.cloudId,s.rewardId,...s.gateIds,...s.drones.map(q=>q.id)];return refs.every(q=>ids.has(q))?clone(s):null;
}
export function appendCopiedSkyShooterBindings(room,snapshot,idMap,{dx,dy}={}){
 if(snapshot===null||snapshot===undefined)return;if(!(idMap instanceof Map)||!Number.isFinite(dx)||!Number.isFinite(dy)||room.smm2Mechanics?.skyShooter)throw Error('Sky Shooter paste needs a fresh room, complete IDs and explicit translation');
 const next=clone(snapshot),remap=id=>{const to=idMap.get(id);if(!to||to===id)throw Error('Sky Shooter paste is missing a new bound ID');return to;};
 next.cloudId=remap(next.cloudId);next.rewardId=remap(next.rewardId);next.gateIds=next.gateIds.map(remap);next.drones=next.drones.map(q=>({...q,id:remap(q.id),x:q.x+dx,y:q.y+dy}));next.activation.x+=dx;next.activation.y+=dy;
 if(next.loopingDivers){next.loopingDivers.actorIds=next.loopingDivers.actorIds.map(remap);next.loopingDivers.sideX+=dx;next.loopingDivers.exitY+=dy;next.loopingDivers.reentryY+=dy;}
 if(next.enemyFire){next.enemyFire.downwardActorIds=next.enemyFire.downwardActorIds.map(remap);next.enemyFire.diverActorIds=next.enemyFire.diverActorIds.map(remap);next.enemyFire.diverAttackY+=dy;}
 setSkyShooter(room,next);
}
/** One optional room capability; the textarea is the exact strict saved config.
 * No hidden default tuning, duplicated native entities or implicit reward IDs. */
export function mountSkyShooterTools({parent,room,change,report=()=>{}}){
 const panel=document.createElement('details');panel.id='sky-shooter-tools';parent.append(panel);
 panel.innerHTML='<summary>原创骑云射击编队</summary><p class="small">绑定已有空云、16×16 栗宝宝、实体闸门和 typed 粉币。X / 加速键发射真正上行子弹；预警后俯冲与导弹都为原创作者规则。可选 loopingDivers 显式配置同一活敌的下方退出、左侧返航、上方再入与原位归队，须避开实体地形。可选完整 enemyFire 指定基础敌人逐个锁定枪口垂直轮射、俯冲者到 diverAttackY 后暂停预告并快照瞄准；过近跳过射击，所有敌弹共用有限弹数，启用后替代旧基础瞄准弹。参数不称 Nintendo / Namco 原版校准。删除任一绑定目标会移除此规则组。</p><label>完整显式配置<textarea rows="14" data-sky-shooter="config" spellcheck="false"></textarea></label><button type="button" data-sky-shooter="apply">保存 / 更新规则</button><button type="button" data-sky-shooter="remove">移除规则</button><p class="small" data-sky-shooter="status"></p>';
 const get=k=>panel.querySelector('[data-sky-shooter="'+k+'"]');let previous=null;
 const refresh=()=>{const r=room();if(previous!==r){get('config').value=r?.smm2Mechanics?.skyShooter?JSON.stringify(r.smm2Mechanics.skyShooter,null,2):'';previous=r;}const spec=r?.smm2Mechanics?.skyShooter;get('status').textContent=spec?'已绑定 '+spec.drones.length+' 个真实敌人'+(spec.loopingDivers?'，其中 '+spec.loopingDivers.actorIds.length+' 个同体返航':'')+(spec.enemyFire?'，'+spec.enemyFire.downwardActorIds.length+' 个垂直轮射 / '+spec.enemyFire.diverActorIds.length+' 个下降后瞄准':'')+'；所有启用字段必须显式填写':'未启用；现有原生玩法不变'};
 const attempt=fn=>{try{change(fn);previous=null;}catch(e){report(e.message);get('status').textContent=e.message;}refresh();};
 get('apply').onclick=()=>attempt(()=>setSkyShooter(room(),JSON.parse(get('config').value)));get('remove').onclick=()=>attempt(()=>removeSkyShooter(room()));refresh();return {refresh,panel,fields:[...SKY_SHOOTER_FIELDS]};
}
