/** Intentional, edge-triggered trading. Inventory belongs to the stage, never the room. */
export const VILLAGE_HEART_ID='village:heart-container';
export const SHOP_ITEMS=Object.freeze([
 Object.freeze({id:'healing',name:'现场治疗',detail:'立即恢复 2 颗心；满血不收费',price:4,amount:2}),
 Object.freeze({id:'potion',name:'治疗药水',detail:'带在背包里，按 H 恢复 2 颗心',price:5,amount:2}),
 Object.freeze({id:'heart',name:'生命之心',detail:'永久增加 1 颗心上限；限购 1 次',price:8,amount:1,purchaseId:VILLAGE_HEART_ID})
]);
export function createVillageShop({inventory={},transaction=()=>({ok:false,reason:'poor'}),usePotion=()=>({ok:false,reason:'empty'}),onResult=()=>{}}={}){
 let state,previous={};
 function reset(){state={near:false,open:false,selected:0,flash:null,pulse:0,message:''};previous={};}
 function step({near=false,input={},alive=true}={}){
  const pressed=key=>!!input[key]&&!previous[key],wasOpen=state.open;
  state.near=!!near&&alive;state.pulse=Math.max(0,state.pulse-1);
  if(!state.near||pressed('shopClose'))state.open=false;
  else if(!wasOpen&&pressed('interact')&&!input.down){state.open=true;state.message='选择物品，再确认购买';state.flash=null;}
  else if(wasOpen&&state.open){
   const delta=Math.sign(Number(input.shopMove)||0);if(delta&&delta!==previous.shopMove)state.selected=(state.selected+delta+SHOP_ITEMS.length)%SHOP_ITEMS.length;
   if(Number.isInteger(input.shopSelect)&&input.shopSelect>=0&&input.shopSelect<SHOP_ITEMS.length)state.selected=input.shopSelect;
   if(pressed('shopConfirm')||(pressed('interact')&&!input.up&&!input.down)){
    const item=SHOP_ITEMS[state.selected];let result;
    if(item.id==='heart'&&(inventory.healthUpgrades||[]).includes(VILLAGE_HEART_ID))result={ok:false,reason:'sold'};
    else if(item.id==='potion'&&(inventory.potions||0)>=3)result={ok:false,reason:'bag-full'};
    else result=transaction({item:item.id,price:item.price,amount:item.amount,...(item.purchaseId?{purchaseId:item.purchaseId}:{})});
    feedback(result,item.id);onResult({...result,item:item.id});
   }
  }
  if(alive&&!state.open&&pressed('usePotion')){const result=usePotion();feedback(result,'use-potion');onResult({...result,item:'use-potion'});}
  previous={interact:!!input.interact,shopConfirm:!!input.shopConfirm,shopClose:!!input.shopClose,usePotion:!!input.usePotion,shopMove:Math.sign(Number(input.shopMove)||0)};
  return view();
 }
 function feedback(result,item){state.flash=result.ok?'bought':result.reason;state.pulse=120;state.message=result.ok?({healing:'治疗完成',potion:'药水已放入背包 · H 使用',heart:'生命上限 +1 · 已售罄','use-potion':'已使用药水'}[item]):({'full':'生命已满，没有消耗','poor':'金币不足，没有扣款','sold':'这颗生命之心已经售罄','bag-full':'药水已满（3 / 3）','empty':'背包里没有药水'}[result.reason]||'交易未完成');}
 function view(){return {...state,potions:inventory.potions||0,items:SHOP_ITEMS.map(q=>({...q,sold:q.id==='heart'&&(inventory.healthUpgrades||[]).includes(VILLAGE_HEART_ID),stock:q.id==='heart'?((inventory.healthUpgrades||[]).includes(VILLAGE_HEART_ID)?0:1):null}))};}
 reset();return {step,view,reset};
}
