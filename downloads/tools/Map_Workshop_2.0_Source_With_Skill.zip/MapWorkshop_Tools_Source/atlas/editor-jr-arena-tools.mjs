import {clone,validate} from './editor-model.mjs';
import {validateJrArenaAudienceRoom} from './editor-jr-arena-audience.mjs';
const keys=['version','bossId','sourceParameterStatus','seats','exits','cheerFrames','telegraphFrames','waveGapFrames','waveCount','goombasPerWave','maxAlive','formation','rowCount','spawnGapFrames'];
const plain=q=>q&&typeof q==='object'&&!Array.isArray(q)&&[Object.prototype,null].includes(Object.getPrototypeOf(q));
function edit(room,change){
 const next=clone(room);change(next);validateJrArenaAudienceRoom(next);validate({format:'xiaoq-map-project',version:1,id:'jr-arena-authoring',title:'Jr arena authoring',rooms:[next]},{allowIncompleteCompletionMarks:true});
 for(const key of Object.keys(room))if(!Object.hasOwn(next,key))delete room[key];Object.assign(room,next);
}
/** Full closed leaf replacement, cloned before validation and commit. */
export function setJrArenaAudience(room,spec){
 if(!plain(spec))throw TypeError('Arena audience requires a complete JSON object');
 edit(room,next=>{next.smm2Mechanics??={version:1};next.smm2Mechanics.arenaAudience=clone(spec);});
}
/** Partial changes use the same full schema/geometry validation as set. */
export function updateJrArenaAudience(room,patch){
 if(!plain(patch)||Object.keys(patch).some(key=>!keys.includes(key)))throw TypeError('Unknown arena audience authoring option');
 if(!room.smm2Mechanics?.arenaAudience)throw Error('Choose an existing arena audience');
 setJrArenaAudience(room,{...clone(room.smm2Mechanics.arenaAudience),...clone(patch)});
}
export function clearJrArenaAudience(room){edit(room,next=>{if(next.smm2Mechanics)delete next.smm2Mechanics.arenaAudience;});}
/** Called within the host's existing atomic delete/History transaction.
 * Removing Jr removes its scene; deleting seats removes only dependent crowd.
 * Empty scenes are cleared rather than leaving invalid mandatory seats. */
export function pruneJrArenaAudienceReferences(room,before){
 const spec=room.smm2Mechanics?.arenaAudience;if(!spec)return;
 const objects=new Set(room.map.objects.map(q=>q.id)),geometry=new Set(room.map.geometry.map(q=>q.id));
 if(!objects.has(spec.bossId)||!room.smm2Mechanics?.bowserJuniors?.actors?.some(q=>q.id===spec.bossId)){delete room.smm2Mechanics.arenaAudience;return;}
 spec.seats=spec.seats.filter(q=>geometry.has(q.seatGeometryId));
 if(!spec.seats.length)delete room.smm2Mechanics.arenaAudience;
}
/** JSON is the narrow authoring surface: every save/clear uses caller History.
 * It edits scene actors only and never creates hidden enemy/contact bodies. */
export function mountJrArenaAudienceTools({parent,room,change,report=()=>{}}){
 const doc=parent.ownerDocument||document,section=doc.createElement('details'),summary=doc.createElement('summary');summary.textContent='角斗场观众 · 实体座位／有限入场';section.append(summary);
 const note=doc.createElement('p');note.textContent='完整 JSON 配置。座位引用实体地形；坐席栗宝宝免伤、不算敌人。HP1用原生栗宝宝物理入场。缺省两侧成对：最多6只／3只存活。formation:"row"单出口整排：rowCount最多6只、spawnGapFrames至少32帧，预警至少72帧，最多两排／6只存活。胜利取消未入场者。这是原创组合。';section.append(note);
 const label=doc.createElement('label'),input=doc.createElement('textarea');label.textContent='观众 JSON';input.rows=18;input.dataset.jrArenaControl='json';input.placeholder='粘贴完整 arenaAudience 配置：bossId、seats、exits、欢呼、预警和有限波次';label.append(input);section.append(label);
 const button=(text,key,fn)=>{const b=doc.createElement('button');b.type='button';b.textContent=text;b.dataset.jrArenaControl=key;b.onclick=()=>{try{change(fn);refresh();}catch(e){report(e.message);}};section.append(b);return b;};
 button('保存观众配置','apply',()=>{if(!input.value.trim())throw Error('观众 JSON 不能为空');setJrArenaAudience(room(),JSON.parse(input.value));});
 const clear=button('移除观众配置','clear',()=>clearJrArenaAudience(room()));
 parent.append(section);
 function refresh(){const spec=room().smm2Mechanics?.arenaAudience;input.value=spec?JSON.stringify(spec,null,2):'';clear.disabled=!spec;}
 refresh();return {refresh};
}
