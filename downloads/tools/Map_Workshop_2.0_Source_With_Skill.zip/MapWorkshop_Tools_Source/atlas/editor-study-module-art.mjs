import {sourcePixels,sourceKey} from './source-art.mjs';

/** Additive private-study art helpers. Sprite topology comes from the embedded
 * native atlas. New checkpoint symbols are code-native approximations, never
 * crops of Nintendo screenshots. Parent renderers opt in explicitly.
 */
const cache=new Map();
function nativeSprite(key,style='normal'){
 const id=key+':'+style;if(cache.has(id))return cache.get(id);
 const d=sourcePixels(key),canvas=document.createElement('canvas');canvas.width=d.w;canvas.height=d.h;
 const c=canvas.getContext('2d'),im=c.createImageData(d.w,d.h);
 for(let i=0;i<d.pixels.length;i++){
  const p=d.pixels[i];let color=p;
  if(style==='checkpoint-base'&&p[3])color=p[0]===0&&p[1]===0?[155,82,27,255]:p[0]===252&&p[1]===216?[255,237,180,255]:p[0]===200&&p[1]===76?[217,163,80,255]:p;
  if(style==='sky-brick-gold'&&p[3])color=p[0]===0&&p[1]===0?[196,95,39,255]:p[0]===252&&p[1]===216?[246,208,127,255]:p[0]===200&&p[1]===76?[252,240,188,255]:p;
  if(style==='underground-floor'&&p[3])color=p[0]===0&&p[1]===128?[14,109,116,255]:p[0]===156&&p[1]===252?[120,186,164,255]:p;
  if(style==='bridge'&&p[3])color=p[0]===216&&p[1]===40?[185,111,22,255]:p[0]===252&&p[1]===216?[239,179,91,255]:p;
  if(style==='plant'&&p[3])color=p[0]===0&&p[1]===168?[118,239,18,255]:p[0]===252&&p[1]===152?[220,202,85,255]:p;
  im.data.set(color,i*4);
 }
 c.putImageData(im,0,0);cache.set(id,canvas);return canvas;
}
// Original SMM2 SMB1 unactivated/Mario checkpoint frames. Nintendo assets;
// source bytes and hashes are in assets/smm2-checkpoint-private/PROVENANCE.json.
const checkpointOriginalFrames=[{"w":19,"h":32,"palette":[[0,0,0,0],[74,74,74,255],[255,255,255,255],[33,173,16,255],[189,189,189,255]],"rows":["0011000000000000000","0123100000000000000","1233310000000000000","1333310000000000000","0133100000000000000","0011000000000000000","0021111111111111111","0021111111111111110","0021122222111111100","0021221212211111000","0021211211211110000","0021212221211100000","0021222122211000000","0021112221110000000","0021111111100000000","0021111111000000000","0021111110000000000","0021111100000000000","0021111000000000000","0021110000000000000","0021100000000000000","0021000000000000000","0024000000000000000","0024000000000000000","0024000000000000000","0024000000000000000","0024000000000000000","0024000000000000000","0011000000000000000","2222240000000000000","2444410000000000000","1111110000000000000"]},{"w":19,"h":32,"palette":[[0,0,0,0],[74,74,74,255],[255,255,255,255],[33,173,16,255],[247,57,16,255],[189,189,189,255]],"rows":["0011000000000000000","0123100000000000000","1233310000000000000","1333310000000000000","0133100000000000000","0011000000000000000","0024444444444444444","0024444444444444440","0024442244444224440","0024444224442244400","0024444222422244400","0024444242224244000","0024444244244244000","0024444244444244400","0024444244444244400","0024442224442224440","0024444444444444440","0024444444444444444","0025000000000000000","0025000000000000000","0025000000000000000","0025000000000000000","0025000000000000000","0025000000000000000","0025000000000000000","0025000000000000000","0025000000000000000","0025000000000000000","0011000000000000000","2222250000000000000","2555510000000000000","1111110000000000000"]}];
function checkpointOriginal(activated){
 const key='smm2-checkpoint-original-'+(activated?1:0);if(cache.has(key))return cache.get(key);
 const d=checkpointOriginalFrames[activated?1:0],canvas=document.createElement('canvas');canvas.width=d.w;canvas.height=d.h;const ctx=canvas.getContext('2d'),image=ctx.createImageData(d.w,d.h);
 for(let y=0;y<d.h;y++)for(let x=0;x<d.w;x++)image.data.set(d.palette[Number(d.rows[y][x])],(y*d.w+x)*4);
 ctx.putImageData(image,0,0);cache.set(key,canvas);return canvas;
}
const WHITE='#ffffff';
function symbol(c,activated,x,y){
 c.fillStyle=WHITE;
 if(activated){
  // A small white M, matching the observed activated flag's meaning.
  for(const [r,row]of ['10001','11011','10101','10101','10001','10001'].entries())for(let col=0;col<row.length;col++)if(row[col]==='1')c.fillRect(x+col,y+r,1,1);
 }else{
  // A compact horned-face approximation, not an extracted official emblem.
  for(const [r,row]of ['10001','11111','10101','11111','01110','01010'].entries())for(let col=0;col<row.length;col++)if(row[col]==='1')c.fillRect(x+col,y+r,1,1);
 }
}
export function drawCheckpoint(c,o,tick=0,room={}){
 const visual=room.checkpointVisuals?.[o.sourceId||o.id]||(o.kind==='checkpoint'&&room.smm2Mechanics?.version===1?{version:1,base:true,style:'smm2-small'}:null);
 if(visual?.version===1&&visual.hidden){
  if(!room.playGeometry){c.save();c.strokeStyle='#7fcfe6';c.globalAlpha=.65;c.setLineDash([2,2]);c.strokeRect(o.x,o.y,o.w,o.h);c.restore();}return true;
 }
 if(!visual||visual.version!==1||!visual.base)return false;
 const small=visual.style==='smm2-small',foot=o.y+o.h,baseTop=foot-(small?4:16),center=Math.round(o.x+(o.w||16)/2),activated=!!o.activated;
 c.save();c.imageSmoothingEnabled=false;
 if(small&&room.smm2Mechanics?.art?.palette!=='smb3-underground'){const sprite=checkpointOriginal(activated);c.drawImage(sprite,center-1,Math.round(foot-sprite.height));c.restore();return true;}
 if(small){c.fillStyle='#765329';c.fillRect(center-4,baseTop,8,4);c.fillStyle='#dfb455';c.fillRect(center-3,baseTop,6,3);c.fillStyle='#f9e8a4';c.fillRect(center-3,baseTop,6,1);}else c.drawImage(nativeSprite('src|Solid|Stone|normal|','checkpoint-base'),Math.round(center-8),Math.round(baseTop));
 const poleTop=Math.round(small?foot-30:baseTop-32),rod=small?baseTop-poleTop-4:29;c.fillStyle='#746848';c.fillRect(center-1,poleTop+4,3,rod);c.fillStyle=WHITE;c.fillRect(center,poleTop+4,1,rod);
 const cap=nativeSprite('src|Scenery|FlagTop||');c.drawImage(cap,center-3,poleTop-2);
 // A brief one-pixel flutter is cosmetic; Nintendo's exact timing is unknown.
 const age=o.activationAge,flutter=activated&&Number.isFinite(age)&&age>=0&&age<12&&Math.floor(age/3)%2?1:0;
 const flagX=center+1,flagY=poleTop+5;c.fillStyle=activated?'#e83f24':'#272722';
 for(let r=0;r<11;r++)c.fillRect(flagX,flagY+r,Math.max(4,12-Math.max(0,r-3))-flutter,1);
 symbol(c,activated,flagX+2,flagY+2);c.restore();return true;
}

function tiled(c,q,s){c.save();c.beginPath();c.rect(q.x,q.y,q.w,q.h);c.clip();for(let y=q.y;y<q.y+q.h;y+=s.height)for(let x=q.x;x<q.x+q.w;x+=s.width)c.drawImage(s,Math.round(x),Math.round(y));c.restore();}
function skyGoldTile(){
 const key='code-native:sky-gold-diagonal-v1';if(cache.has(key))return cache.get(key);
 // Original 16px study approximation of the inspected Sky motif. This is not
 // an official sprite or screenshot crop, and it does not define collision.
 const s=document.createElement('canvas');s.width=s.height=16;const c=s.getContext('2d'),cream='#fcf0bc',gold='#f6d07f',brown='#c45f27';
 c.fillStyle=cream;c.fillRect(0,0,16,16);
 for(let y=1;y<15;y++)for(let x=1;x<15;x++){
  const band=(x+y)%8;
  if(band===0||band===1){c.fillStyle=gold;c.fillRect(x,y,1,1);}
  else if(band===2&&(x+2*y)%5!==0){c.fillStyle=brown;c.fillRect(x,y,1,1);}
 }
 // A small stepped loop interrupts the parallel grain at the cell's center.
 c.fillStyle=cream;c.fillRect(6,6,4,4);c.fillStyle=gold;c.fillRect(5,7,1,3);c.fillRect(7,5,3,1);c.fillRect(10,6,1,3);c.fillRect(6,10,3,1);
 c.fillStyle=brown;for(const [x,y]of [[6,8],[7,7],[8,6],[9,7],[9,8],[8,9],[7,10],[6,9]])c.fillRect(x,y,1,1);
 // A distinct one-pixel bevel keeps adjoining 16px cells readable.
 c.fillStyle=gold;c.fillRect(0,0,16,1);c.fillRect(0,1,1,15);c.fillStyle=brown;c.fillRect(1,15,15,1);c.fillRect(15,1,1,14);
 cache.set(key,s);return s;
}
function note(c,q){
 c.save();c.translate(Math.round(q.x),Math.round(q.y));c.fillStyle='#222222';c.fillRect(0,0,16,16);c.fillStyle=WHITE;c.fillRect(1,1,14,14);c.fillStyle='#bcbcbc';c.fillRect(14,1,1,14);c.fillRect(1,14,14,1);c.fillStyle='#111111';c.fillRect(10,4,2,8);c.fillRect(8,5,2,2);c.fillRect(5,10,6,3);c.fillRect(6,13,4,1);c.restore();
}
/** Explicit local opt-in prevents any change to ordinary native tiles. */
export function drawMarioModuleTile(c,q,room={}){
 if(q.used||q.material==='used')return false;
 const style=q.studyArt;
 if(style==='native-cloud'){
  const type=['Cloud1','Cloud2','Cloud3'].includes(q.nativeCloud)?q.nativeCloud:'Cloud1';c.drawImage(nativeSprite('src|Scenery|'+type+'||'),Math.round(q.x),Math.round(q.y));return true;
 }
 if(q.material==='study-note'||style==='note-block'){note(c,q);return true;}
 if(style==='sky-brick-gold'){tiled(c,q,skyGoldTile());return true;}
 if(style==='underground-floor'){tiled(c,q,nativeSprite('src|Solid|Floor|Underworld|',style));return true;}
 if(style==='goal-base'){tiled(c,q,nativeSprite('src|Solid|Stone|normal|'));return true;}
 if(style==='pipe-down'){
  const cap=nativeSprite('src|Solid|Pipe||top'),body=nativeSprite('src|Solid|Pipe||middle');c.save();c.translate(q.x,q.y+q.h);c.scale(1,-1);c.beginPath();c.rect(0,0,q.w,q.h);c.clip();c.drawImage(cap,0,0,q.w,cap.height);for(let y=cap.height;y<q.h;y+=body.height)c.drawImage(body,0,y,q.w,body.height);c.restore();return true;
 }
 if(style==='orange-truss'){
  c.save();c.fillStyle='#703d38';c.fillRect(q.x,q.y,q.w,q.h);c.fillStyle='#f4a666';c.fillRect(q.x+1,q.y,q.w-2,q.h);c.fillStyle='#755b78';c.fillRect(q.x+3,q.y,q.w-6,q.h);for(let y=q.y;y<q.y+q.h;y+=16){c.strokeStyle='#f4a666';c.lineWidth=2;c.beginPath();c.moveTo(q.x+3,y+8);c.lineTo(q.x+8,y+2);c.lineTo(q.x+13,y+8);c.lineTo(q.x+8,y+14);c.closePath();c.stroke();}c.restore();return true;
 }
 if(style==='route-arrow'){
  c.fillStyle='#945138';c.beginPath();c.moveTo(q.x,q.y+5);c.lineTo(q.x+20,q.y+5);c.lineTo(q.x+20,q.y);c.lineTo(q.x+31,q.y+8);c.lineTo(q.x+20,q.y+16);c.lineTo(q.x+20,q.y+11);c.lineTo(q.x,q.y+11);c.closePath();c.fill();c.fillStyle='#ffcf78';c.fillRect(q.x+2,q.y+6,21,4);c.beginPath();c.moveTo(q.x+22,q.y+3);c.lineTo(q.x+29,q.y+8);c.lineTo(q.x+22,q.y+13);c.closePath();c.fill();return true;
 }
 if(style==='rope-bridge'){
  tiled(c,q,nativeSprite('src|Solid|BridgeBase||','bridge'));
  tiled(c,{...q,y:q.y-8,h:8},nativeSprite('src|Scenery|Railing||'));return true;
 }
 return false;
}
const WING=[
 '1111000000000000','1111100000000000','1111110000000000','0111111000000000',
 '0111111100000000','0011111110000000','0011111111000000','0001111111100000',
 '0001111111110000','0000111111111000','0000111111111100','0000011111111110',
 '0000011111111111','0000001111111111','0000001111111111','0000000111111111',
 '0000000111111111','0000000011111111','0000000011111110','0000000001111100',
 '0000000001111000','0000000000110000'
];
function wing(c,x,y,mirror=false){
 c.save();c.translate(x+(mirror?16:0),y);if(mirror)c.scale(-1,1);c.fillStyle=WHITE;
 for(let r=0;r<WING.length;r++)for(let col=0;col<16;col++)if(WING[r][col]==='1')c.fillRect(col,r,1,1);
 c.fillStyle='#f9d87b';for(let r=5;r<18;r++){const col=4+Math.floor((r-5)/2);if(WING[r][col]==='1')c.fillRect(col,r,1,2);}c.restore();
}
function giantPlant(c,o,tick){
 const w=o.w||32,h=o.h||48,phase=Math.floor((tick+(Math.round((o.homeX??o.x)/16)%2)*12)/12)%2,frame=o.frame==='two'||phase?'two':'',s=nativeSprite('src|Character|Piranha|'+frame+'|','plant');
 c.save();c.translate(Math.round(o.x),Math.round(o.y));c.scale(w/32,h/48);
 // Wing art and its 2px flutter are declared approximations around the real body.
 if(o.source?.winged!==false){const dy=(o.wingFrame??Math.floor(tick/8)%2)?-2:0;wing(c,-14,20+dy);wing(c,30,20+dy,true);}
 c.drawImage(s,0,0,32,48);c.restore();
}
function largeCoin(c,o){
 const w=o.w||32,h=o.h||32;c.save();c.translate(Math.round(o.x),Math.round(o.y));c.scale(w/32,h/32);
 for(let y=0;y<32;y++)for(let x=0;x<32;x++){const r=(x-15.5)**2+(y-15.5)**2;if(r<=169){c.fillStyle='#111111';c.fillRect(x+2,y+1,1,1);}}
 for(let y=0;y<32;y++)for(let x=0;x<32;x++){const r=(x-15.5)**2+(y-15.5)**2;if(r>169)continue;c.fillStyle=r>144?'#874b19':r>110?'#efb65b':'#f7d16f';c.fillRect(x,y,1,1);}
 c.fillStyle='#8b4a18';const one=['010','110','010','010','010','010','010','010','010','111'],zero=['01110','11011','10001','10001','10001','10001','10001','10001','11011','01110'];
 for(const [glyph,gx]of [[one,10],[zero,15]])for(let y=0;y<glyph.length;y++)for(let x=0;x<glyph[y].length;x++)if(glyph[y][x]==='1')c.fillRect(gx+x,11+y,1,1);
 c.restore();
}
function leftDoor(c,o){
 c.save();c.beginPath();c.rect(o.x,o.y,o.w,o.h);c.clip();
 for(let y=o.y;y<o.y+o.h;y+=32)for(let x=o.x;x<o.x+o.w;x+=32){
  c.save();c.translate(Math.round(x),Math.round(y));c.fillStyle='#1e1e1e';c.fillRect(0,0,32,32);c.fillStyle='#515151';c.fillRect(7,1,24,30);c.fillStyle='#aaaaaa';c.fillRect(1,2,5,28);c.fillStyle=WHITE;c.fillRect(1,2,1,28);c.fillRect(2,2,4,1);c.fillStyle='#262626';for(const xx of [9,28])for(const yy of [3,27])c.fillRect(xx,yy,2,2);
  for(const xx of [10,20])for(let y=0;y<16;y++){const width=8-Math.abs(7.5-y);c.fillStyle='#a0a0a0';c.fillRect(xx+Math.ceil(8-width),8+y,Math.floor(width),1);if(width>2){c.fillStyle='#111111';c.fillRect(xx+Math.ceil(9-width),8+y,Math.floor(width)-2,1);}}
  c.restore();
 }
 c.restore();
}
export function drawMarioModuleActor(c,o,tick=0,room={}){
 const variant=room.marioModules?.enemyVariants?.[o.id];
 if(o.kind==='walker'&&!o.type&&['vertical-koopa','hopping-koopa'].includes(variant?.kind)){
  const key=sourceKey('Character','Koopa',[room.setting||'',variant.kind==='vertical-koopa'?'smart':'','jumping',Math.floor(tick/8)%2?'two':''].join(' ')),sprite=nativeSprite(key);c.drawImage(sprite,Math.round(o.x),Math.round(o.y));return true;
 }
 if(o.kind==='walker'&&!o.type&&variant?.kind==='pipe-piranha'){const sprite=nativeSprite(sourceKey('Character','Piranha',[room.setting||'',Math.floor(tick/8)%2?'two':''].join(' ')));c.drawImage(sprite,Math.round(o.x),Math.round(o.y));return true;}
 const type=o.type||o.skin||o.kind;
 if(type==='study-giant-winged-piranha'||type==='study-piranha'&&o.source?.giant){giantPlant(c,o,tick);return true;}
 if(type==='study-large-coin'||o.kind==='coin'&&(room.marioModules?.coinValues?.[o.id]===10||o.value===10||o.source?.value===10||o.source?.largeCoin)){largeCoin(c,o);return true;}
 if(type==='study-oneway-left'){leftDoor(c,o);return true;}
 if(o.kind==='checkpoint')return drawCheckpoint(c,o,tick,room);
 return false;
}
/** One-way walls are view-only directional colliders: draw them once here. */
export function drawMarioModuleWorld(c,view={},room={}){
 const rise=room.marioModules?.castleFlagRiseFrames;if(rise&&view.finish?.castleFlagAge!==undefined){const marker=room.markers?.find(m=>m.kind==='flagpole-finish'&&Math.abs(m.x-view.finish.x)<32);if(marker){const source=marker.source||{},castleX=marker.x+2*(source.castleDistance||(source.large?24:32)),roofY=marker.y-(source.large?176:80),x=castleX+(source.large?64:32),sprite=nativeSprite(sourceKey('Scenery','CastleFlag',room.setting||'')),progress=view.completed?1:Math.min(1,view.finish.castleFlagAge/rise);c.save();c.beginPath();c.rect(x,0,sprite.width,Math.max(0,roofY));c.clip();c.drawImage(sprite,Math.round(x),Math.round(roofY+16-(sprite.height+16)*progress));c.restore();}}
 const modules=view.marioModules||room.marioModulesView||room.marioModules;if(!modules)return false;
 for(const wall of modules.oneWayWalls||[])if(wall.direction==='left')leftDoor(c,wall);
 const drawn=new Set((view.geometry||room.playGeometry||room.map?.geometry||[]).map(q=>q.id));
 for(const q of modules.noteBlocks||[])if(!drawn.has(q.id))note(c,{...q,y:q.y-(q.bump?Math.sin(q.bump/12*Math.PI)*6:0)});
 return true;
}
