/** Opt-in contact terrain. All numerical tuning is authored local approximation.
 * No course IDs, input scripts, rewards, damage, or changes to the native motor. */
const EPS=1e-7,CONTACT_EPS=1.01,DEG=Math.PI/180;
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
const finite=(n,a,b)=>Number.isFinite(n)&&n>=a&&n<=b;
const integer=(n,a,b)=>Number.isInteger(n)&&finite(n,a,b);
const copy=v=>JSON.parse(JSON.stringify(v));
const fail=s=>{throw Error(s);};
const unsafe=k=>['__proto__','constructor','prototype'].includes(k);
function object(q,fields,label){
 if(!q||typeof q!=='object'||Array.isArray(q)||![Object.prototype,null].includes(Object.getPrototypeOf(q)))fail('Invalid '+label);
 for(const k of Object.keys(q))if(unsafe(k)||!fields.includes(k))fail('Unknown '+label+' field: '+k);
}
function rect(q,map,label){if(!['x','y','w','h'].every(k=>finite(q[k],0,32768))||q.w<=0||q.h<=0||q.x+q.w>map.width||q.y+q.h>map.height)fail(label+' rectangle outside room');}
const donutFields=['id','x','y','w','h','delayFrames','gravity','maxFallSpeed','triggerPolicy','resetPolicy','collision'];
const slopeFields=['id','x','y','w','h','thickness','orientation','collision'];
const seesawFields=['id','pivotX','pivotY','length','thickness','initialAngleDegrees','maxAngleDegrees','weightAcceleration','maxAngularSpeedDegrees','damping','impactSpeedThreshold','impactGain','maxLaunchSpeed','impactMinLeverFraction','impactPolicy'];
/** Validates terrain leaves without accepting or interpreting sibling actor leaves.
 * The enclosing importer must also validate its entire smm2Mechanics object. */
export function validateSMM2Terrain(room,spec=room?.smm2Mechanics){
 if(spec===undefined)return;
 if(!spec||typeof spec!=='object'||Array.isArray(spec)||![Object.prototype,null].includes(Object.getPrototypeOf(spec))||spec.version!==1)fail('Invalid SMM2 mechanics version');
 for(const k of Object.keys(spec))if(unsafe(k))fail('Unsafe SMM2 mechanics field');
 const map=room?.map;
 if(!map||!finite(map.width,1,32768)||!finite(map.height,1,4096))fail('SMM2 terrain needs bounded room dimensions');
 const ids=new Set([...(map.geometry||[]),...(map.objects||[]),...(room.markers||[])].map(q=>q.id));
 const id=q=>{if(typeof q.id!=='string'||q.id.length>72||!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(q.id)||unsafe(q.id)||ids.has(q.id))fail('Duplicate or invalid SMM2 terrain ID');ids.add(q.id);};
 for(const [key,fields]of [['donuts',donutFields],['slopes',slopeFields],['seesaws',seesawFields]]){
  if(spec[key]===undefined)continue;
  if(!Array.isArray(spec[key])||spec[key].length>256)fail('Invalid '+key+' list');
  for(const q of spec[key]){
   object(q,fields,key);id(q);
   if(key==='donuts'){
    rect(q,map,'Donut');
    if(!integer(q.delayFrames,1,36000)||!finite(q.gravity,.001,4)||!finite(q.maxFallSpeed,.001,64)||!['player','all-actors','explicit'].includes(q.triggerPolicy)||!['leave-before-drop','continue'].includes(q.resetPolicy)||!['solid','oneway'].includes(q.collision))fail('Invalid Donut contact or fall policy');
   }else if(key==='slopes'){
    rect(q,map,'Slope');
    if(!['rise-left','rise-right','ceiling-rise-left','ceiling-rise-right'].includes(q.orientation)||q.collision!=='solid')fail('Invalid slope orientation or collision');
    if(q.thickness!==undefined){
     if(!finite(q.thickness,.1,1024))fail('Invalid slope strip thickness');
     // h is the diagonal's vertical difference, not the strip's thickness.
     // Floor strips extend down from that diagonal; ceiling strips extend up.
     if(slopeShape(q).polygon.some(p=>p.x<0||p.x>map.width||p.y<0||p.y>map.height))fail('Slope strip polygon outside room');
    }
   }else{
    if(!finite(q.pivotX,0,map.width)||!finite(q.pivotY,0,map.height)||!finite(q.length,1,1024)||!finite(q.thickness,.1,64)||!finite(q.maxAngleDegrees,0,75)||!finite(q.initialAngleDegrees,-q.maxAngleDegrees,q.maxAngleDegrees)||!finite(q.weightAcceleration,0,5)||!finite(q.maxAngularSpeedDegrees,0,15)||!finite(q.damping,0,1)||!finite(q.impactSpeedThreshold,.001,64)||!finite(q.impactGain,0,16)||!finite(q.maxLaunchSpeed,0,64)||!finite(q.impactMinLeverFraction,0,1)||!['thwomp','explicit'].includes(q.impactPolicy))fail('Invalid seesaw dimensions, weights or impulse parameters');
    // Contain the real rotated rectangle for every permitted angle, not just
    // its neutral bounding box. A finite extremum calculation avoids sampling.
    const limit=q.maxAngleDegrees*DEG,half=q.length/2,t=q.thickness/2;
    const maximum=(a,b)=>{const candidates=[0,limit];const critical=Math.atan2(b,a);if(critical<=limit)candidates.push(critical);return Math.max(...candidates.map(v=>a*Math.cos(v)+b*Math.sin(v)));};
    const rx=maximum(half,t),ry=maximum(t,half);
    if(q.pivotX-rx<0||q.pivotX+rx>map.width||q.pivotY-ry<0||q.pivotY+ry>map.height)fail('Seesaw permitted rotation outside room');
   }
  }
 }
}
const alive=a=>a&&typeof a==='object'&&!a.dead&&!a.dying&&!a.removed&&!a.taken;
const body=a=>alive(a)&&['x','y','w','h'].every(k=>Number.isFinite(a[k]))&&a.w>0&&a.h>0;
const mass=a=>{if(a?.smm2Mass===undefined)return 1;if(!finite(a.smm2Mass,.001,10000))fail('Invalid explicit SMM2 actor mass');return a.smm2Mass;};
const overlaps=(a,b)=>a.x<b.x+b.w-EPS&&a.x+a.w>b.x+EPS&&a.y<b.y+b.h-EPS&&a.y+a.h>b.y+EPS;
const pose=a=>({x:a.x,y:a.y,w:a.w,h:a.h,vx:a.vx||0,vy:a.vy||0,grounded:!!a.grounded,support:a.support??null});
function slopeShape(spec){
 const {x,y,w,h,orientation}=spec,riseRight=orientation.endsWith('rise-right'),solidAbove=orientation.startsWith('ceiling-');
 const diagonalA={x,y:y+(riseRight?h:0)},diagonalB={x:x+w,y:y+(riseRight?0:h)};
 if(spec.thickness!==undefined){
  const offset=solidAbove?-spec.thickness:0,a={x:diagonalA.x,y:diagonalA.y+offset},b={x:diagonalB.x,y:diagonalB.y+offset};
  const underside={a:{x:a.x,y:a.y+spec.thickness},b:{x:b.x,y:b.y+spec.thickness}};
  return {id:spec.id,kind:'slope',collision:'solid',a,b,polygon:[a,b,underside.b,underside.a],solidAbove,underside,spec};
 }
 const a=solidAbove?{x,y}:diagonalA,b=solidAbove?{x:x+w,y}:diagonalB;
 return {id:spec.id,kind:'slope',collision:'solid',a,b,polygon:[a,b,{x:solidAbove?(riseRight?x:x+w):(riseRight?x+w:x),y:y+h}],solidAbove,underside:solidAbove?{a:diagonalA,b:diagonalB}:null,spec};
}
function seesawShape(state,angle=state.angle){
 const s=state.spec,c=Math.cos(angle),n=Math.sin(angle),h=s.length/2,t=s.thickness/2;
 const a={x:s.pivotX-c*h+n*t,y:s.pivotY-n*h-c*t},b={x:s.pivotX+c*h+n*t,y:s.pivotY+n*h-c*t};
 return {id:s.id,kind:'seesaw',collision:'oneway',a,b,polygon:[a,b,{x:b.x-n*s.thickness,y:b.y+c*s.thickness},{x:a.x-n*s.thickness,y:a.y+c*s.thickness}],spec:s};
}
/** Highest real contact point under an axis-aligned actor's finite foot span.
 * Strict horizontal overlap excludes contact at an edge after walking away. */
function sampleLine(a,b,x,width,lowest=false){
 if(!a||!b||!finite(x,-1000000,1000000)||!finite(width,EPS,32768))return null;
 const left=Math.max(x,a.x),right=Math.min(x+width,b.x);
 if(right-left<=EPS)return null;
 const gradient=(b.y-a.y)/(b.x-a.x),contactX=(gradient>=0)!==lowest?left:right;
 return {x:contactX,y:a.y+(contactX-a.x)*gradient,gradient,left,right};
}
export function sampleSMM2Surface(shape,x,width){return sampleLine(shape?.a,shape?.b,x,width);}
function polygonAxes(poly){const axes=[{x:1,y:0},{x:0,y:1}];for(let i=0;i<poly.length;i++){const a=poly[i],b=poly[(i+1)%poly.length],dx=b.x-a.x,dy=b.y-a.y,l=Math.hypot(dx,dy);if(l>EPS)axes.push({x:-dy/l,y:dx/l});}return axes;}
function projection(points,axis){const p=points.map(q=>q.x*axis.x+q.y*axis.y);return [Math.min(...p),Math.max(...p)];}
const corners=a=>[{x:a.x,y:a.y},{x:a.x+a.w,y:a.y},{x:a.x+a.w,y:a.y+a.h},{x:a.x,y:a.y+a.h}];
function overlapsPolygon(actor,polygon){return polygonAxes(polygon).every(axis=>{const [amin,amax]=projection(corners(actor),axis),[bmin,bmax]=projection(polygon,axis);return amax>bmin+EPS&&amin<bmax-EPS;});}
/** Continuous SAT against the actual convex polygon; no bounding-box walls. */
function sweepPolygon(from,dx,dy,poly){
 let enter=-Infinity,exit=Infinity,normal=null;
 for(const axis of polygonAxes(poly)){
  const [amin,amax]=projection(corners(from),axis),[bmin,bmax]=projection(poly,axis),v=dx*axis.x+dy*axis.y;
  if(Math.abs(v)<EPS){if(amax<=bmin+EPS||amin>=bmax-EPS)return null;continue;}
  const t1=(bmin-amax)/v,t2=(bmax-amin)/v,lo=Math.min(t1,t2),hi=Math.max(t1,t2);
  if(lo>enter){enter=lo;normal={x:axis.x*(v>0?-1:1),y:axis.y*(v>0?-1:1)};}exit=Math.min(exit,hi);
  if(enter>exit+EPS)return null;
 }
 if(enter<-EPS||enter>1+EPS||exit<0||!normal)return null;
 return {time:clamp(enter,0,1),normal};
}
// Exact trigonometric extrema and branch boundaries isolate the first top
// crossing during the measured angular step. No staircase or frame grid.
function trigRange(a,b,lo,hi){
 const values=[a*Math.cos(lo)+b*Math.sin(lo),a*Math.cos(hi)+b*Math.sin(hi)],phase=Math.atan2(b,a);
 for(let k=-2;k<=2;k++)for(const angle of [phase+k*Math.PI*2,phase+Math.PI+k*Math.PI*2])if(angle>lo&&angle<hi)values.push(a*Math.cos(angle)+b*Math.sin(angle));
 return [Math.min(...values)-EPS,Math.max(...values)+EPS];
}
function trigRoots(a,b,c,lo,hi){
 const radius=Math.hypot(a,b);if(Math.abs(c)>radius)return [];
 const phase=Math.atan2(b,a),offset=Math.acos(clamp(c/radius,-1,1)),roots=[];
 for(let k=-2;k<=2;k++)for(const angle of [phase-offset+k*Math.PI*2,phase+offset+k*Math.PI*2])if(angle>lo+EPS&&angle<hi-EPS)roots.push(angle);
 return roots;
}
function movingSeesawTop(actor,delta,previous,current){
 if(delta.x!==0||delta.y<=EPS||current.kind!=='seesaw'||!previous)return null;
 const from=Math.atan2(previous.b.y-previous.a.y,previous.b.x-previous.a.x),to=Math.atan2(current.b.y-current.a.y,current.b.x-current.a.x),omega=to-from;
 if(Math.abs(omega)<=EPS)return null;
 const prior=sampleSMM2Surface(previous,actor.x,actor.w),now=sampleSMM2Surface(current,actor.x,actor.w),bottom=actor.y+actor.h;
 // This port repairs a surface genuinely overtaking a previously separated
 // descending body. Already embedded bodies and static contacts stay outside.
 if(!prior||!now||prior.y-bottom<=EPS||now.y-bottom>=-EPS)return null;
 const s=current.spec,half=s.length/2,thickness=s.thickness/2,loAngle=Math.min(from,to),hiAngle=Math.max(from,to),state={spec:s};
 const at=t=>{const angle=from+omega*t,shape=seesawShape(state,angle),sample=sampleSMM2Surface(shape,actor.x,actor.w);return {angle,sample,gap:sample?sample.y-bottom-delta.y*t:Infinity};};
 const cuts=[0,1];if(loAngle<0&&hiAngle>0)cuts.push(-from/omega);
 for(const angle of [...trigRoots(-half,thickness,actor.x-s.pivotX,loAngle,hiAngle),...trigRoots(half,thickness,actor.x+actor.w-s.pivotX,loAngle,hiAngle)])cuts.push((angle-from)/omega);
 cuts.sort((a,b)=>a-b);
 let budget=2048;
 function derivativeRange(lo,hi){
  const a=from+omega*lo,b=from+omega*hi,l=Math.min(a,b),h=Math.max(a,b),mid=at((lo+hi)/2),shape=seesawShape(state,mid.angle);let range;
  if(mid.angle>=0&&actor.x<shape.a.x)range=trigRange(-half,thickness,l,h);
  else if(mid.angle<0&&actor.x+actor.w>shape.b.x)range=trigRange(half,thickness,l,h);
  else{
   const d=(mid.angle>=0?actor.x:actor.x+actor.w)-s.pivotX,sin=[Math.sin(l),Math.sin(h)],factor=[d-thickness*sin[1],d-thickness*sin[0]],minAbs=l<=0&&h>=0?0:Math.min(Math.abs(l),Math.abs(h)),maxAbs=Math.max(Math.abs(l),Math.abs(h)),sec=[1/Math.cos(minAbs)**2,1/Math.cos(maxAbs)**2],values=factor.flatMap(v=>sec.map(w=>v*w));range=[Math.min(...values)-EPS,Math.max(...values)+EPS];
  }
  const values=range.map(v=>v*omega-delta.y);return [Math.min(...values)-EPS,Math.max(...values)+EPS];
 }
 function firstCrossing(lo,hi,depth=0){
  if(--budget<0||depth>60)fail('Unresolved bounded SMM2 moving-top crossing');
  const left=at(lo),right=at(hi),derivative=derivativeRange(lo,hi);
  if(derivative[0]>=0||left.gap>0&&left.gap+derivative[0]*(hi-lo)>0)return null;
  if(derivative[1]<=0){
   if(left.gap<0||right.gap>0)return null;
   let a=lo,b=hi;for(let n=0;n<52;n++){const mid=(a+b)/2;if(at(mid).gap>0)a=mid;else b=mid;}return (a+b)/2;
  }
  const mid=(lo+hi)/2;return firstCrossing(lo,mid,depth+1)??firstCrossing(mid,hi,depth+1);
 }
 let fraction=null;for(let n=1;n<cuts.length&&fraction===null;n++)if(cuts[n]-cuts[n-1]>EPS)fraction=firstCrossing(cuts[n-1],cuts[n]);
 if(fraction===null||fraction<=0||fraction>1)return null;
 const crossing=at(fraction);if(!crossing.sample||Math.abs(crossing.gap)>1e-6)return null;
 const contactBody={x:actor.x,y:actor.y+delta.y*fraction,w:actor.w,h:actor.h},displacement={x:0,y:now.y-crossing.sample.y},target={...contactBody,y:now.y-actor.h},length=Math.hypot(now.gradient,1);
 return {fraction,normal:{x:now.gradient/length,y:-1/length},point:{x:now.x,y:now.y},solidId:current.id,material:'smm2-seesaw',body:target,incomingVelocity:{x:0,y:delta.y},surfaceMotion:{kind:'seesaw-top',fromAngleDegrees:from/DEG,toAngleDegrees:to/DEG,contactAngleDegrees:crossing.angle/DEG,contactBody,previousTop:{x:prior.x,y:prior.y},contactTop:{x:crossing.sample.x,y:crossing.sample.y},currentTop:{x:now.x,y:now.y},displacement}};
}
/** Controller owns surfaces and contact records only. Native stage owns actors. */
export function createSMM2Terrain(room,{emit=()=>{}}={}){
 validateSMM2Terrain(room);const extension=room?.smm2Mechanics;
 if(!extension||!(extension.donuts?.length||extension.slopes?.length||extension.seesaws?.length))return null;
 const specs=copy(extension),slopes=(specs.slopes||[]).map(slopeShape);
 const ownedShapeIds=new Set([...slopes.map(q=>q.id),...(specs.seesaws||[]).map(q=>q.id)]);
 let donuts,seesaws,lastTick,lastFinished,currentTick,actors,records,previousShapes,currentShapes,contacts,events,seenActors,initializedActors,frameStarts,actorIds,actorOrdinal;
 function actorId(actor){if(typeof actor.id==='string'&&actor.id.length)return actor.id;let id=actorIds.get(actor);if(!id){id='smm2-actor-'+actorOrdinal++;actorIds.set(actor,id);}return id;}
 function actorList(entries){
  if(!Array.isArray(entries)||entries.length>4096)fail('Invalid terrain actor list');
  const result=[...new Set(entries)].filter(body),ids=new Set();
  for(const actor of result){const id=actorId(actor);if(ids.has(id))fail('Duplicate SMM2 actor ID');ids.add(id);mass(actor);}return result;
 }
 const diagnostic=(event,data)=>{const e={event,roomId:room.roomId,tick:currentTick,...data};events.push(e);emit('smm2-terrain',e);};
 function reset(){
  donuts=(specs.donuts||[]).map(spec=>({spec,x:spec.x,y:spec.y,dy:0,vy:0,contactFrames:0,phase:'idle'}));
  seesaws=(specs.seesaws||[]).map(spec=>({spec,angle:spec.initialAngleDegrees*DEG,angularVelocity:0,moment:0,leftMass:0,rightMass:0}));
  lastTick=lastFinished=null;currentTick=0;actors=[];records=new WeakMap();contacts=new WeakMap();events=[];seenActors=new Set();initializedActors=new WeakSet();frameStarts=new WeakMap();actorIds=new WeakMap();actorOrdinal=0;
  currentShapes=[...slopes,...seesaws.map(s=>seesawShape(s))];previousShapes=currentShapes;
 }
 reset();
 function beginFrame({tick,actors:entries=[]}={}){
  const next=tick??(lastTick===null?1:lastTick+1);
  if(!integer(next,0,Number.MAX_SAFE_INTEGER)||!Array.isArray(entries)||entries.length>4096)fail('Invalid SMM2 terrain frame');
  if(lastTick!==null&&next<=lastTick)return false;
  lastTick=currentTick=next;seenActors=new Set();events=[];actors=actorList(entries);previousShapes=currentShapes;frameStarts=new WeakMap(actors.map(a=>[a,pose(a)]));
  for(const actor of actors){const c=contacts.get(actor);if(c&&(!actor.grounded||actor.support!==c.id))contacts.delete(actor);}
  for(const state of donuts){
   const s=state.spec;state.dy=0;
   if(state.phase==='removed')continue;
   if(state.phase==='falling'){
    state.vy=Math.min(s.maxFallSpeed,state.vy+s.gravity);state.dy=state.vy;state.y+=state.dy;
    if(state.y>room.map.height){state.phase='removed';diagnostic('donut-left-room',{componentId:s.id});}continue;
   }
   const trigger=actors.some(a=>a.grounded&&a.support===s.id&&a.x+a.w>state.x+EPS&&a.x<state.x+s.w-EPS&&Math.abs(a.y+a.h-state.y)<=CONTACT_EPS&&(s.triggerPolicy==='all-actors'||s.triggerPolicy==='player'&&(a.kind==='player'||a.hero||a.smm2Player===true)||s.triggerPolicy==='explicit'&&a.smm2DonutTrigger===true));
   if(trigger||s.resetPolicy==='continue'&&state.contactFrames>0){state.contactFrames++;state.phase='shaking';}
   else if(s.resetPolicy==='leave-before-drop'){if(state.contactFrames)diagnostic('donut-contact-reset',{componentId:s.id});state.contactFrames=0;state.phase='idle';}
   if(state.contactFrames>=s.delayFrames){state.phase='falling';diagnostic('donut-drop',{componentId:s.id});}
  }
  for(const state of seesaws){
   const s=state.spec,limit=s.maxAngleDegrees*DEG,speed=s.maxAngularSpeedDegrees*DEG;
   state.angularVelocity=clamp((state.angularVelocity+state.moment*s.weightAcceleration*DEG)*s.damping,-speed,speed);
   const target=state.angle+state.angularVelocity;state.angle=clamp(target,-limit,limit);
   if(target!==state.angle)state.angularVelocity=0;
  }
  currentShapes=[...slopes,...seesaws.map(s=>seesawShape(s))];return true;
 }
 /** Donuts are genuine native rectangular solids. Inclined surfaces remain
  * shape descriptors and MUST be resolved with afterActor/the motor adapter. */
 function ownsGeometry(solid){return !!solid&&ownedShapeIds.has(solid.id);}
 function geometry(base=[]){return [...base.filter(q=>!q.smm2Terrain&&!ownsGeometry(q)),...donuts.filter(s=>s.phase!=='removed').map(s=>({id:s.spec.id,x:s.x,y:s.y,w:s.spec.w,h:s.spec.h,collision:s.spec.collision,material:'smm2-donut',smm2Terrain:true,dx:0,dy:s.dy}))];}
 function surfaces(){return currentShapes.map(q=>({id:q.id,kind:q.kind,collision:q.collision,a:{...q.a},b:{...q.b},polygon:copy(q.polygon),spec:copy(q.spec),...(q.kind==='slope'?{orientation:q.spec.orientation,solidAbove:q.solidAbove,underside:copy(q.underside)}:{})}));}
 function standableGeometry(exclude){return actors.filter(a=>a!==exclude&&a.standable===true).map((a,index)=>{const before=frameStarts.get(a);return {id:actorId(a,index),x:a.x,y:a.y,w:a.w,h:a.h,collision:'oneway',smm2StandableActor:true,dx:before?a.x-before.x:0,dy:before?a.y-before.y:0};});}
 function actorGeometry(base,actor){const current=geometry(base),nativeIds=new Set(current.filter(q=>['solid','oneway'].includes(q.collision)).map(q=>q.id));return [...current,...standableGeometry(actor).filter(q=>!nativeIds.has(q.id))];}
 /** The native motor consumes carry displacement before testing floor contact.
  * Bound only a true falling Donut rider's consumed carry at the first static
  * rectangular floor. The Donut's live pose/dy remain authoritative elsewhere;
  * native gravity, jump and landing then transfer support in the usual step. */
 function motorGeometry(base,actor){
  const solids=actorGeometry(base,actor);
  if(!body(actor)||!actor.grounded||actor.vy<0)return solids;
  const state=donuts.find(s=>s.spec.id===actor.support&&s.phase==='falling'&&s.dy>EPS);
  if(!state||actor.x+actor.w<=state.x+EPS||actor.x>=state.x+state.spec.w-EPS)return solids;
  const bottom=actor.y+actor.h;
  if(Math.abs(bottom-(state.y-state.dy))>CONTACT_EPS)return solids;
  const floor=solids.filter(q=>q.id!==state.spec.id&&!q.hidden&&!q.smm2Terrain&&!q.smm2StandableActor&&['solid','oneway'].includes(q.collision)&&!(q.dx||q.dy)&&body(q)&&actor.x+actor.w>q.x+EPS&&actor.x<q.x+q.w-EPS&&bottom<=q.y+EPS&&bottom+state.dy>=q.y-EPS).sort((a,b)=>a.y-b.y||a.id.localeCompare(b.id))[0];
  if(!floor)return solids;
  const dy=clamp(floor.y-bottom,0,state.dy);
  return solids.map(q=>q.id===state.spec.id?{...q,dy}:q);
 }
 function followSample(shape,actor){
  const sample=sampleSMM2Surface(shape,actor.x,actor.w);if(sample||shape.kind!=='slope'||shape.spec.thickness===undefined||shape.solidAbove)return sample;
  // A grounded foot can end its horizontal step exactly at the low vertex.
  // Keep that tangent out of lateral wall resolution, without granting a
  // zero-width standing contact or changing the exact polygon sweep itself.
  const low=shape.a.y>shape.b.y?shape.a:shape.b,edge=low===shape.a?actor.x+actor.w:actor.x;
  return Math.abs(edge-low.x)<=EPS?{x:low.x,y:low.y,gradient:(shape.b.y-shape.a.y)/(shape.b.x-shape.a.x),left:low.x,right:low.x}:null;
 }
 function canFollow(shape,oldShape,before,actor,jumping){
  if(!before.grounded||jumping||actor.vy<0)return false;
  const now=followSample(shape,actor);if(!now)return false;
  const prior=sampleSMM2Surface(oldShape,before.x,before.w),bottom=before.y+before.h;
  if(before.support===shape.id&&prior&&Math.abs(bottom-prior.y)<=CONTACT_EPS)return true;
  // Enter from the physically low edge of a slope while walking on real floor.
  // The vertical rise is bounded by the local foot displacement on that line.
  if(shape.kind!=='slope'||prior&&Math.abs(bottom-prior.y)>CONTACT_EPS)return false;
  const low=oldShape.a.y>oldShape.b.y?oldShape.a:oldShape.b;
  const crossingLow=low===oldShape.a?before.x+before.w<=low.x+CONTACT_EPS:before.x>=low.x-CONTACT_EPS;
  return crossingLow&&Math.abs(bottom-low.y)<=CONTACT_EPS&&Math.abs(now.y-bottom)<=Math.abs(now.gradient)*(Math.abs(actor.x-before.x)+Math.abs(actor.w-before.w))+CONTACT_EPS;
 }
 /** Native enemies test ordinary horizontal walls before their vertical step.
  * Preview a genuinely supported strip's reachable top at the moved x so a
  * joined flat platform cannot masquerade as a side wall. No contact is granted
  * here, and real body/shape obstructions still reject the candidate. */
 function followSlopeTop(actor,before,{tick=currentTick,geometry:base=[]}={}){
  if(tick!==currentTick||!body(actor)||!body(before))return null;
  const candidates=currentShapes.filter(q=>q.kind==='slope'&&q.spec.thickness!==undefined&&canFollow(q,q,before,actor,false)).map(shape=>({shape,sample:followSample(shape,actor)})).sort((a,b)=>a.sample.y-b.sample.y||a.shape.id.localeCompare(b.shape.id));
  for(const {shape,sample}of candidates){
   const target={x:actor.x,y:sample.y-actor.h,w:actor.w,h:actor.h};
   if(currentShapes.some(q=>q.id!==shape.id&&q.collision==='solid'&&overlapsPolygon(target,q.polygon))||base.some(q=>q.id!==actorId(actor)&&q.collision==='solid'&&!q.hidden&&!q.smm2Terrain&&overlaps(target,q)))continue;
   return {solidId:shape.id,body:target};
  }
  return null;
 }
 function afterActor(actor,before,{tick=currentTick,input={},geometry:base=[],incomingVelocity}={}){
  if(tick!==currentTick||!body(actor)||!body(before)||seenActors.has(actor))return null;
  const initial=!initializedActors.has(actor);initializedActors.add(actor);
  seenActors.add(actor);const priorContact=contacts.get(actor),incomingVy=Math.max(incomingVelocity?.y||0,actor.vy||0,before.vy||0),jumping=!!input.jumpPressed&&(before.grounded||actor.vy<0),nativeGrounded=actor.grounded;
  const previousById=new Map(previousShapes.map(q=>[q.id,q]));
  const followers=currentShapes.filter(shape=>canFollow(shape,previousById.get(shape.id)||shape,before,actor,jumping));
  const start={...before,y:before.y+before.h-actor.h,w:actor.w,h:actor.h};
  // Airborne or high-side entry collides with the actual polygon. Walking
  // surface contact bypasses its inclined face, never its vertical high side.
  for(const shape of currentShapes.filter(q=>q.kind==='slope'&&!followers.includes(q))){
   const previous=sampleSMM2Surface(previousById.get(shape.id)||shape,before.x,before.w),next=sampleSMM2Surface(shape,actor.x,actor.w);
   if(actor.vy<0&&previous&&next&&Math.abs(before.y+before.h-previous.y)<=CONTACT_EPS&&actor.y+actor.h<=next.y+EPS)continue;
   const dx=actor.x-start.x,hit=sweepPolygon(start,dx,0,shape.polygon);
   if(hit&&Math.abs(hit.normal.x)>EPS){actor.x=start.x+dx*hit.time;actor.vx=shape.spec.thickness!==undefined&&actor.shell===true&&Math.abs(before.vx)>1?-Math.sign(dx)*Math.abs(before.vx):0;if(hit.normal.y>EPS)actor.headHit=shape.id;}
  }
  const candidates=[];
  if(actor.vy>=0&&!jumping){
   for(const shape of currentShapes){
    const sampled=sampleSMM2Surface(shape,actor.x,actor.w);if(!sampled)continue;
    const old=previousById.get(shape.id)||shape,previous=sampleSMM2Surface(old,before.x,before.w)||sampleSMM2Surface(old,actor.x,actor.w);
    const crossing=previous&&before.y+before.h<=previous.y+CONTACT_EPS&&actor.y+actor.h>=sampled.y-EPS;
    const follows=followers.includes(shape);
    // Some imported bodies are placed with the center foot on a diagonal,
    // leaving only their uphill foot corner inside the finite strip. On this
    // body's first resolved move, settle that shallow top overlap upward to
    // the existing full-width contact. Later motion must cross/follow normally.
    const centerX=before.x+before.w/2,centerY=shape.a.y+(centerX-shape.a.x)*(shape.b.y-shape.a.y)/(shape.b.x-shape.a.x);
    const initialSupport=initial&&shape.kind==='slope'&&shape.spec.thickness!==undefined&&!shape.solidAbove&&previous&&before.x>=shape.a.x-EPS&&before.x+before.w<=shape.b.x+EPS&&(before.vy||0)>=0&&actor.y>=start.y-EPS&&(!before.support||before.support===shape.id)&&!actor.hidden&&!actor.emerge&&!actor.moduleEmergence&&!actor.clawHeld&&!actor.vehicleId&&!actor.onVine&&before.y<previous.y-EPS&&before.y+before.h>previous.y+EPS&&Math.abs(before.y+before.h-centerY)<=CONTACT_EPS&&overlapsPolygon(before,shape.polygon);
    if((crossing||follows||initialSupport)&&(!nativeGrounded||sampled.y<=actor.y+actor.h+EPS||follows))candidates.push({shape,sampled,follows,crossing,initialSupport});
   }
  }
  candidates.sort((a,b)=>a.sampled.y-b.sampled.y||a.shape.id.localeCompare(b.shape.id));
  let contact=null;
  for(const candidate of candidates){
   const target={...actor,y:candidate.sampled.y-actor.h};
   // A live standable item can also own a real host solid. Its prior-frame
   // collider is not an external obstruction to that same body's movement.
   const blockers=base.filter(q=>q.id!==actorId(actor)&&q.collision==='solid'&&!q.hidden&&!q.smm2Terrain);
   const shapedBlocker=currentShapes.find(q=>q.id!==candidate.shape.id&&q.collision==='solid'&&overlapsPolygon(target,q.polygon));
   if(shapedBlocker||blockers.some(q=>overlaps(target,q))){
    // A low ceiling stops ascent at the real obstruction. Keep the previous
    // reachable pose rather than lifting a body through another solid.
    if(candidate.follows){actor.x=before.x;actor.y=before.y+before.h-actor.h;actor.vx=actor.vy=0;actor.grounded=true;actor.support=before.support;if(shapedBlocker?.underside)actor.headHit=shapedBlocker.id;}
    continue;
   }
   const isLanding=!candidate.initialSupport&&!candidate.follows&&priorContact?.id!==candidate.shape.id&&before.support!==candidate.shape.id;
   actor.y=target.y;actor.vy=0;actor.grounded=true;actor.support=candidate.shape.id;actor.jumps=0;
   if(candidate.initialSupport)diagnostic('slope-initial-support',{componentId:candidate.shape.id,actorId:actorId(actor),displacementY:target.y-start.y});
   contact={id:candidate.shape.id,kind:candidate.shape.kind,x:candidate.sampled.x,y:candidate.sampled.y,phase:isLanding?'landing':'standing',incomingVy:isLanding?incomingVy:0};break;
  }
  if(!contact&&actor.vy<0){
   const from={...start,x:actor.x};
   for(const shape of currentShapes.filter(q=>q.kind==='slope')){
    const dy=actor.y-from.y,hit=sweepPolygon(from,0,dy,shape.polygon);
    if(hit&&hit.normal.y>EPS){actor.y=from.y+dy*hit.time;actor.vy=.5;actor.headHit=shape.id;}
   }
  }
  if(contact)contacts.set(actor,contact);else{
   contacts.delete(actor);
   const strip=currentShapes.find(q=>q.id===actor.support&&q.kind==='slope'&&q.spec.thickness!==undefined);
   if(strip&&!sampleSMM2Surface(strip,actor.x,actor.w))actor.support=null;
   // Native shell motion otherwise leaves rectangular support IDs unassigned.
   // Record an actual flat contact once it has physically left a finite strip.
   if(actor.shell===true&&nativeGrounded&&!actor.support&&currentShapes.some(q=>q.kind==='slope'&&q.spec.thickness!==undefined))actor.support=base.find(q=>['solid','oneway'].includes(q.collision)&&!q.hidden&&actor.x+actor.w>q.x+EPS&&actor.x<q.x+q.w-EPS&&Math.abs(actor.y+actor.h-q.y)<=CONTACT_EPS)?.id??null;
  }
  const rec={tick:currentTick,before:pose(before),after:pose(actor),contact,previousContact:priorContact??null};records.set(actor,rec);
  if(priorContact&&!contact)diagnostic('contact-leave',{componentId:priorContact.id,actorId:actorId(actor,actors.indexOf(actor))});
  return contact?{...contact}:null;
 }
 /** Engine-only continuous shape collision port. The caller retains its actor
  * movement/impact state machine and chooses the nearest ordinary/shape hit. */
 function sweep(actor,delta,{tick=currentTick,movingTop=false,excludeIds=[]}={}){
  if(!Array.isArray(excludeIds)||excludeIds.length>512||excludeIds.some(id=>typeof id!=='string'))fail('Invalid bounded terrain sweep exclusions');
  if(tick!==currentTick||!body(actor)||!delta||!finite(delta.x,-32768,32768)||!finite(delta.y,-32768,32768))return null;
  const candidates=[];
  for(const shape of currentShapes){
   if(excludeIds.includes(shape.id))continue;
   if(shape.kind==='seesaw'&&delta.y<=EPS)continue;
   if(movingTop&&shape.kind==='seesaw'){
    const previous=previousShapes.find(q=>q.id===shape.id),moving=movingSeesawTop(actor,delta,previous,shape);
    if(moving){candidates.push(moving);continue;}
   }
   const hit=sweepPolygon(actor,delta.x,delta.y,shape.polygon);if(!hit)continue;
   if(shape.kind==='seesaw'&&hit.normal.y>=-EPS)continue;
   const at={...actor,x:actor.x+delta.x*hit.time,y:actor.y+delta.y*hit.time},sample=sampleSMM2Surface(shape,at.x,at.w);
   if(shape.kind==='seesaw'&&(!sample||Math.abs(at.y+at.h-sample.y)>CONTACT_EPS))continue;
   const underside=hit.normal.y>EPS&&shape.underside?sampleLine(shape.underside.a,shape.underside.b,at.x,at.w,true):null;
   const point=hit.normal.y<-EPS&&sample?{x:sample.x,y:sample.y}:underside?{x:underside.x,y:underside.y}:{x:hit.normal.x<0?at.x+at.w:hit.normal.x>0?at.x:at.x+at.w/2,y:hit.normal.y>0?at.y:at.y+at.h/2};
   candidates.push({fraction:hit.time,normal:hit.normal,point,solidId:shape.id,material:'smm2-'+shape.kind,body:{x:at.x,y:at.y,w:at.w,h:at.h},incomingVelocity:{x:delta.x,y:delta.y}});
  }
  return candidates.sort((a,b)=>a.fraction-b.fraction||a.solidId.localeCompare(b.solidId))[0]||null;
 }
 /** Engine-only measured correction verifier. Author data cannot supply this
  * result: its complete shape/pose history is recomputed from owned state. */
 function validateMovingTopContact(actor,delta,contact,{tick=currentTick}={}){
  if(tick!==currentTick||!body(actor)||!delta||delta.x!==0||!finite(delta.y,EPS,32768)||!contact?.surfaceMotion)return false;
  const shape=currentShapes.find(q=>q.id===contact.solidId),previous=previousShapes.find(q=>q.id===contact.solidId);if(!shape||shape.kind!=='seesaw')return false;
  const expected=movingSeesawTop(actor,delta,previous,shape);if(!expected)return false;
  function equal(a,b){
   if(typeof a==='number')return Number.isFinite(b)&&Math.abs(a-b)<=1e-6;
   if(a===null||typeof a!=='object')return a===b;
   if(!b||typeof b!=='object'||Array.isArray(b)||![Object.prototype,null].includes(Object.getPrototypeOf(b)))return false;
   const keys=Object.keys(a);return Object.keys(b).length===keys.length&&keys.every(k=>!unsafe(k)&&Object.hasOwn(b,k)&&equal(a[k],b[k]));
  }
  return equal(expected,contact);
 }
 function support(actor,contact,{tick=currentTick,direction={x:0,y:1}}={}){
  if(tick!==currentTick||!body(actor)||!contact)return null;
  const shape=currentShapes.find(q=>q.id===contact.solidId);if(!shape)return null;
  const down=direction==='down'||direction?.y>0;
  if(down&&contact.normal?.y<-EPS){
   const sample=sampleSMM2Surface(shape,actor.x,actor.w);if(!sample)return null;
   const prior=previousShapes.find(q=>q.id===shape.id),old=prior&&sampleSMM2Surface(prior,actor.x,actor.w),distance=Math.abs(actor.y+actor.h-sample.y);
   if(distance>CONTACT_EPS+Math.abs(sample.y-(old?.y??sample.y)))return null;
   const length=Math.hypot(sample.gradient,1),target={x:actor.x,y:sample.y-actor.h,w:actor.w,h:actor.h};
   if(currentShapes.some(q=>q.id!==shape.id&&q.collision==='solid'&&overlapsPolygon(target,q.polygon)))return null;
   return {...contact,point:{x:sample.x,y:sample.y},normal:{x:sample.gradient/length,y:-1/length},body:target};
  }
  const vector=typeof direction==='string'?{left:{x:-1,y:0},right:{x:1,y:0},up:{x:0,y:-1},down:{x:0,y:1}}[direction]:direction;
  if(!vector||!Number.isFinite(vector.x)||!Number.isFinite(vector.y))return null;
  const hit=sweep(actor,{x:vector.x*CONTACT_EPS,y:vector.y*CONTACT_EPS},{tick});
  return hit?.solidId===contact.solidId?hit:null;
 }
 /** A real engine sweep can have already zeroed impact velocity. Record its
  * pre-impact value once; this neither positions nor activates the actor. */
 function recordImpact(actor,impact,{tick=currentTick}={}){
  if(tick!==currentTick||!body(actor)||!impact||!currentShapes.some(q=>q.id===impact.solidId)||!finite(impact.incomingVelocity?.y,-256,256)||!Number.isFinite(impact.normal?.y)||impact.normal.y>=-EPS||seenActors.has(actor))return false;
  const shape=currentShapes.find(q=>q.id===impact.solidId),sample=sampleSMM2Surface(shape,actor.x,actor.w);
  if(!sample||Math.abs(actor.y+actor.h-sample.y)>CONTACT_EPS)return false;
  seenActors.add(actor);const prior=contacts.get(actor),c={id:shape.id,kind:shape.kind,x:sample.x,y:sample.y,phase:prior?.id===shape.id?'standing':'landing',incomingVy:prior?.id===shape.id?0:Math.max(0,impact.incomingVelocity.y)};
  contacts.set(actor,c);records.set(actor,{tick:currentTick,before:null,after:pose(actor),contact:c,previousContact:prior??null});return true;
 }
 function clearActorContact(actor){if(!actor||typeof actor!=='object')return false;const had=contacts.has(actor);contacts.delete(actor);records.delete(actor);return had;}
 function rootFor(actor,byId){
  const seen=new Set();let current=actor;
  while(current&&!seen.has(current)){
   seen.add(current);
   const shape=currentShapes.find(q=>q.kind==='seesaw'&&q.id===current.support),sample=shape&&sampleSMM2Surface(shape,current.x,current.w);
   if(current.grounded&&sample&&Math.abs(current.y+current.h-sample.y)<=CONTACT_EPS)return {id:current.support,root:current};
   if(!current.grounded||!current.support)return null;const next=byId.get(current.support);
   if(!next||next.standable!==true||current.x+current.w<=next.x+EPS||current.x>=next.x+next.w-EPS||Math.abs(current.y+current.h-next.y)>CONTACT_EPS)return null;current=next;
  }return null;
 }
 function updateLoads(state,roots){
  const s=state.spec;state.moment=state.leftMass=state.rightMass=0;
  for(const a of actors)if(roots.get(a)?.id===s.id){const lever=clamp((a.x+a.w/2-s.pivotX)/(s.length/2),-1,1),m=mass(a);state.moment+=m*lever;if(lever<-EPS)state.leftMass+=m;else if(lever>EPS)state.rightMass+=m;}
 }
 function finishFrame({tick=currentTick,actors:entries=actors,settleImpactLoads=false}={}){
  if(!Array.isArray(entries)||entries.length>4096||typeof settleImpactLoads!=='boolean')fail('Invalid terrain actors or impact load settlement');
  if(tick!==currentTick||lastFinished===tick)return false;lastFinished=tick;
  actors=actorList(entries);const byId=new Map(actors.map(a=>[actorId(a),a]));
  const roots=new Map(actors.map(a=>[a,rootFor(a,byId)]));let launchedAny=false;
  for(const state of seesaws){
   const s=state.spec;updateLoads(state,roots);
   for(const a of actors){
    const record=records.get(a),c=record?.tick===currentTick?record.contact:null;
    if(!c||c.id!==s.id||c.phase!=='landing'||c.incomingVy<s.impactSpeedThreshold||(s.impactPolicy==='thwomp'?a.type!=='smm2-thwomp':a.smm2Impact!==true))continue;
    const lever=clamp((a.x+a.w/2-s.pivotX)/(s.length/2),-1,1);if(Math.abs(lever)<=Math.max(EPS,s.impactMinLeverFraction))continue;
    const launched=[];
    for(const target of actors){
     const root=roots.get(target);if(target===a||root?.id!==s.id)continue;
     const otherLever=(root.root.x+root.root.w/2-s.pivotX)/(s.length/2);if(otherLever*lever>=-EPS)continue;
     const speed=Math.min(s.maxLaunchSpeed,c.incomingVy*mass(a)*s.impactGain*Math.abs(lever)*Math.min(1,Math.abs(otherLever)));
     if(speed<=EPS)continue;target.vy=-speed;target.grounded=false;target.support=null;contacts.delete(target);launched.push(actorId(target,actors.indexOf(target)));
    }
    if(launched.length){launchedAny=true;diagnostic('seesaw-impact-launch',{componentId:s.id,actorId:actorId(a,actors.indexOf(a)),incomingVy:c.incomingVy,launchedIds:launched});}
   }
  }
  // Only new weighted Spring rooms request final contact ownership. An impact
  // cleared the launched bodies' support; the next angle must not use that
  // pre-launch load. No actor, impact or angle is advanced a second time.
  if(settleImpactLoads&&launchedAny){const currentRoots=new Map(actors.map(a=>[a,rootFor(a,byId)]));for(const state of seesaws)updateLoads(state,currentRoots);}
  return true;
 }
 function view(){return {version:1,approximation:true,tick:currentTick,surfaces:surfaces(),donuts:donuts.map(s=>({...copy(s.spec),x:s.x,y:s.y,dy:s.dy,vy:s.vy,phase:s.phase,contactFrames:s.contactFrames})),seesaws:seesaws.map(s=>({...copy(s.spec),angleDegrees:s.angle/DEG,angularVelocityDegrees:s.angularVelocity/DEG,leftMass:s.leftMass,rightMass:s.rightMass,moment:s.moment})),events:copy(events)};}
 return Object.freeze({beginFrame,finishFrame,geometry,ownsGeometry,actorGeometry,motorGeometry,followSlopeTop,afterActor,sweep,validateMovingTopContact,support,recordImpact,clearActorContact,surfaces,view,reset});
}
/** Opt-in motor wrapper: executes the supplied motor exactly once per step.
 * Host calls beginFrame before actors and finishFrame after every actor moves. */
export function withSMM2TerrainContact(motor,terrain){
 if(!terrain)return motor;
 return {...motor,step(actor,input,character,world){const before={...actor},solids=terrain.motorGeometry(world.solids||[],actor),out=motor.step(actor,input,character,{...world,solids});terrain.afterActor(actor,before,{input,geometry:solids});return out;}};
}
