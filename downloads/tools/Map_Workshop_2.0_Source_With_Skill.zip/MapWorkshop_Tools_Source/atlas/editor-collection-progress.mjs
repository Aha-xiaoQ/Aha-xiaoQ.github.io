/** Dependency-free level-boundary progress, also embedded in offline players. */
export const PROGRESS_FORMAT='xiaoq-map-collection-progress', PROGRESS_VERSION=1;
export const PROGRESS_MAX_BYTES=128*1024;
const KEYS=['lives','coins','score','power','hero','weapon'];
const defaults=()=>({lives:3,coins:0,score:0,power:0,hero:'mario',weapon:'N'});
const copy=x=>JSON.parse(JSON.stringify(x));
const fail=message=>{throw Error('Collection progress: '+message);};
const positive=n=>Number.isSafeInteger(n)&&n>0;
const fingerprint=x=>typeof x==='string'&&/^[a-f0-9]{64}$/.test(x);
const id=x=>typeof x==='string'&&/^[A-Za-z0-9][A-Za-z0-9_-]{0,71}$/.test(x);
const object=(x,keys)=>{
 if(!x||typeof x!=='object'||Array.isArray(x)||![Object.prototype,null].includes(Object.getPrototypeOf(x)))fail('expected plain object');
 for(const key of Reflect.ownKeys(x)){
  if(typeof key!=='string'||!keys.includes(key))fail('unknown field '+String(key));
  const desc=Object.getOwnPropertyDescriptor(x,key);if(desc.get||desc.set)fail('accessor field');
 }
};
function collectionInfo(collection){
 if(!collection||!id(collection.id)||!Array.isArray(collection.levels)||collection.levels.length>32||!Array.isArray(collection.order)||collection.order.length!==collection.levels.length)fail('invalid collection descriptor');
 const levels=new Map();
 for(const level of collection.levels){if(!level||!id(level.id)||!positive(level.revision)||levels.has(level.id))fail('invalid collection level ID/revision');levels.set(level.id,level);}
 if(new Set(collection.order).size!==levels.size||collection.order.some(value=>!levels.has(value)))fail('invalid collection order');
 return levels;
}
function validateCarry(carry){
 object(carry,KEYS);
 if(KEYS.some(key=>!Object.hasOwn(carry,key)))fail('incomplete carry state');
 if(!positive(carry.lives)||carry.lives>1000000||!Number.isSafeInteger(carry.coins)||carry.coins<0||carry.coins>99||!Number.isSafeInteger(carry.score)||carry.score<0||![0,1,2].includes(carry.power)||!['mario','bill'].includes(carry.hero)||!['N','M','S','F','L'].includes(carry.weapon))fail('invalid native carry state');
 return copy(carry);
}
/** Pick only the six native carryPlayer fields, never live world/checkpoint data. */
export function collectionCarry(value={}){
 const carry=defaults();
 for(const key of KEYS)if(value[key]!==undefined)carry[key]=value[key];
 return validateCarry(carry);
}
function validateRawProgress(progress){
 object(progress,['format','version','collectionId','cleared','resume','completed','terminalCarry']);
 if(progress.format!==PROGRESS_FORMAT||progress.version!==PROGRESS_VERSION||!id(progress.collectionId))fail('unsupported format/version or invalid collection ID');
 if(!Array.isArray(progress.cleared)||progress.cleared.length>32)fail('invalid cleared list');
 const seen=new Set();
 for(const cleared of progress.cleared){object(cleared,['levelId','revision']);if(!id(cleared.levelId)||!positive(cleared.revision)||seen.has(cleared.levelId))fail('duplicate or invalid cleared entry');seen.add(cleared.levelId);}
 if(progress.resume!==null){
  object(progress.resume,['levelId','revision','carry']);
  if(!id(progress.resume.levelId)||!positive(progress.resume.revision))fail('invalid resume boundary');
  validateCarry(progress.resume.carry);
 }
 if(Object.hasOwn(progress,'terminalCarry')){
  const terminal=progress.terminalCarry;object(terminal,['version','fromLevelId','fromRevision','contentFingerprint','carry']);
  if(terminal.version!==1||!id(terminal.fromLevelId)||!positive(terminal.fromRevision)||Object.hasOwn(terminal,'contentFingerprint')&&!fingerprint(terminal.contentFingerprint))fail('invalid terminal carry boundary');
  validateCarry(terminal.carry);
 }
 if(progress.completed!==undefined&&typeof progress.completed!=='boolean')fail('invalid completed flag');
 return copy(progress);
}
// Admission is established by the validated authored/runtime descriptor, never by progress.
// Minimal ID/revision descriptors remain supported by the dependency-free data API.
function eligibleBoundary(collection,level){
 if(level.admissionWithdrawal)return false;
 if(level.approval?.status==='approved')return !level.admission||level.admission.status==='owner-approved';
 const policy=collection.admissionPolicy,record=level.testAdmission,admission=level.admission;
 if(record){
  return policy?.version===1&&policy.mode==='owner-approved-or-tested'&&policy.scope==='private'&&policy.by==='owner'&&typeof policy.evidence==='string'&&policy.evidence.trim().length>0&&collection.privateStudy===true&&collection.publicDeployment!==true&&record.version===1&&record.status==='passed'&&record.by==='automated-tests'&&record.revision===level.revision&&fingerprint(record.contentFingerprint)&&fingerprint(record.projectFingerprint)&&(!admission||admission.status==='tested-awaiting-owner-review'&&admission.revision===level.revision&&admission.contentFingerprint===record.contentFingerprint&&admission.projectFingerprint===record.projectFingerprint);
 }
 return !level.approval&&!level.admission&&collection.format!=='xiaoq-map-collection'&&collection.format!=='xiaoq-map-collection-runtime';
}
function levelFingerprint(level){return level.admission?.contentFingerprint??level.approval?.contentFingerprint??level.testAdmission?.contentFingerprint;}
function withCompletion(collection,progress){
 progress.completed=collection.order.length>0&&progress.resume===null&&progress.cleared.length===collection.order.length;
 return progress;
}
export function createProgress(collection,{lives=3,...carry}={}){
 const levels=collectionInfo(collection),first=collection.order[0];
 return withCompletion(collection,{format:PROGRESS_FORMAT,version:1,collectionId:collection.id,cleared:[],resume:first?{levelId:first,revision:levels.get(first).revision,carry:collectionCarry({lives,...carry})}:null});
}
/** Reconcile stable boundaries; a valid terminal cache may continue into a new successor. */
export function reconcileProgress(collection,progress){
 const levels=collectionInfo(collection),next=validateRawProgress(progress);
 if(next.collectionId!==collection.id)fail('progress belongs to a different collection');
 next.cleared=next.cleared.filter(entry=>levels.get(entry.levelId)?.revision===entry.revision);
 if(next.resume&&levels.get(next.resume.levelId)?.revision!==next.resume.revision)next.resume=null;
 if(next.terminalCarry){
  const terminal=next.terminalCarry,source=levels.get(terminal.fromLevelId),sourceFingerprint=source&&levelFingerprint(source);
  if(!source||source.revision!==terminal.fromRevision||!next.cleared.some(entry=>entry.levelId===terminal.fromLevelId&&entry.revision===terminal.fromRevision)||!eligibleBoundary(collection,source)||(terminal.contentFingerprint??null)!==(sourceFingerprint??null)){
   // While present, a resume was derived from this still-unentered terminal cache.
   delete next.terminalCarry;next.resume=null;
  }else{
   const cleared=new Set(next.cleared.map(entry=>entry.levelId));
   const nextId=collection.order.slice(collection.order.indexOf(source.id)+1).find(levelId=>!cleared.has(levelId)&&eligibleBoundary(collection,levels.get(levelId)));
   next.resume=nextId?{levelId:nextId,revision:levels.get(nextId).revision,carry:copy(terminal.carry)}:null;
  }
 }
 return withCompletion(collection,next);
}
/** Call on entering a level, with its initial carry; never persist a live room. */
export function resumeBoundary(collection,progress,levelId,carry){
 const levels=collectionInfo(collection),next=reconcileProgress(collection,progress),level=levels.get(levelId);
 if(!level)fail('resume level is missing');
 delete next.terminalCarry;
 next.resume={levelId,revision:level.revision,carry:collectionCarry(carry)};
 return withCompletion(collection,next);
}
/** Called only after the authored exit or explicit checkpoint completion. */
export function markLevelComplete(collection,progress,levelId,carry){
 const levels=collectionInfo(collection),next=reconcileProgress(collection,progress),level=levels.get(levelId);
 if(!level)fail('completed level is missing');
 const state=collectionCarry(carry);
 delete next.terminalCarry;
 if(!next.cleared.some(entry=>entry.levelId===levelId))next.cleared.push({levelId,revision:level.revision});
 const nextId=collection.order[collection.order.indexOf(levelId)+1];
 next.resume=nextId?{levelId:nextId,revision:levels.get(nextId).revision,carry:state}:null;
 if(!nextId){const contentFingerprint=levelFingerprint(level);if(contentFingerprint!==undefined&&!fingerprint(contentFingerprint))fail('invalid terminal content fingerprint');next.terminalCarry={version:1,fromLevelId:levelId,fromRevision:level.revision,...(contentFingerprint===undefined?{}:{contentFingerprint}),carry:state};}
 return withCompletion(collection,next);
}
export function serializeProgress(progress,collection){
 const value=collection?reconcileProgress(collection,progress):validateRawProgress(progress),text=JSON.stringify(value,null,2);
 if(new TextEncoder().encode(text).length>PROGRESS_MAX_BYTES)fail('file exceeds 128 KB');
 return text;
}
export function parseProgress(text,collection){
 if(typeof text!=='string'||text.length>PROGRESS_MAX_BYTES||new TextEncoder().encode(text).length>PROGRESS_MAX_BYTES)fail('file exceeds 128 KB or is not JSON text');
 const value=JSON.parse(text,(key,value)=>{if(['__proto__','prototype','constructor'].includes(key))fail('unsafe field');return value;});
 return collection?reconcileProgress(collection,value):validateRawProgress(value);
}
const unavailable=error=>({ok:false,reason:'unavailable',message:error?.message||'Local storage is unavailable'});
function storageFailure(error){return error?.name==='QuotaExceededError'||error?.name==='NS_ERROR_DOM_QUOTA_REACHED'||error?.code===22||error?.code===1014?{ok:false,reason:'quota',message:'Local storage is full; export progress JSON instead'}:unavailable(error);}
/** Every read/write is guarded, including blocked global localStorage access. */
export function createProgressStore(collection,{storage,key='xiaoq-map-collection-progress:'+collection.id}={}){
 collectionInfo(collection);
 const getStorage=()=>{const target=storage===undefined?globalThis.localStorage:storage;if(!target||typeof target.getItem!=='function'||typeof target.setItem!=='function'||typeof target.removeItem!=='function')throw Error('Local storage is unavailable');return target;};
 return Object.freeze({
  key,
  load(){
   let text;try{text=getStorage().getItem(key);}catch(error){return {...unavailable(error),progress:createProgress(collection)};}
   if(text===null)return {ok:true,reason:'empty',progress:createProgress(collection)};
   try{return {ok:true,reason:'loaded',progress:parseProgress(text,collection)};}catch(error){return {ok:false,reason:'malformed',message:error.message,progress:createProgress(collection)};}
  },
  save(progress){
   let text,value;try{value=reconcileProgress(collection,progress);text=serializeProgress(value);}catch(error){return {ok:false,reason:'malformed',message:error.message};}
   try{getStorage().setItem(key,text);return {ok:true,reason:'saved',progress:value};}catch(error){return {...storageFailure(error),progress:value};}
  },
  clear(){try{getStorage().removeItem(key);return {ok:true,reason:'cleared',progress:createProgress(collection)};}catch(error){return unavailable(error);}}
 });
}

// Descriptive aliases retained for callers that prefer collection-scoped names.
export {createProgress as createCollectionProgress,reconcileProgress as reconcileCollectionProgress,markLevelComplete as recordCollectionClear,resumeBoundary as setCollectionBoundary,parseProgress as parseCollectionProgress,serializeProgress as serializeCollectionProgress,createProgressStore as createCollectionProgressStore};
