import {GHOST_SOURCE_PIXELS} from './editor-smm2-ghost-source-pixels.mjs';

/** Public SMM1 SMB1 originals, matched to the observed SMM2 ghost-house family.
 * Layout/tiling and the timber beam reconstruction are explicit adaptations.
 * This renderer owns no collision, motion, lighting or game-state mutation.
 */
export const isSmm2GhostArtRoom=room=>room?.smm2Mechanics?.version===1&&room.smm2Mechanics.art?.palette==='smb1-ghost-source';
const visible=q=>q&&!q.hidden&&q.visible!==false&&!q.removed&&!q.dead&&!q.taken;
const rect=q=>q&&['x','y','w','h'].every(k=>Number.isFinite(q[k]))&&q.w>0&&q.h>0;
const crops=new Map();
function crop(name,x=0,y=0,w,h){
 const src=GHOST_SOURCE_PIXELS[name];if(!src)return null;w??=src.w;h??=src.h;
 const key=[name,x,y,w,h].join(':');if(crops.has(key))return crops.get(key);
 const rows=src.rows.slice(y,y+h).map(row=>row.slice(x,x+w)),runs=[];
 for(let iy=0;iy<rows.length;iy++)for(let ix=0;ix<rows[iy].length;){let end=ix+1;while(end<rows[iy].length&&rows[iy][end]===rows[iy][ix])end++;const color=src.palette[parseInt(rows[iy][ix],36)];if(!color.endsWith('00'))runs.push([color,ix,iy,end-ix]);ix=end;}
 const out={w,h,runs};crops.set(key,out);return out;
}
function paint(c,im,x,y,scale=1){if(!im)return false;for(const [color,ix,iy,w]of im.runs){c.fillStyle=color;c.fillRect(Math.round(x)+ix*scale,Math.round(y)+iy*scale,w*scale,scale);}return true;}
function clipped(c,q,fn){c.save();c.imageSmoothingEnabled=false;c.beginPath();c.rect(q.x,q.y,q.w,q.h);c.clip();fn();c.restore();}
export function drawSmm2GhostBackground(c,room,w,h){if(!isSmm2GhostArtRoom(room)||!Number.isFinite(w)||!Number.isFinite(h)||w<=0||h<=0)return false;c.fillStyle='#000000';c.fillRect(0,0,w,h);return true;}
export function ghostGroundColorAt(x,y,room,distance=0){const src=GHOST_SOURCE_PIXELS.ghostGroundComposite,ox=room.smm2Mechanics.art.tileOriginX??0,oy=room.smm2Mechanics.art.tileOriginY??0,ix=((Math.floor(x)-ox)%16+16)%16,iy=((Math.floor(y)-oy)%16+16)%16;return distance<1?'#98b6adff':src.palette[parseInt(src.rows[iy+16][ix+48],36)];}

function contains(q,x,y){return rect(q)&&x>=q.x&&x<q.x+q.w&&y>=q.y&&y<q.y+q.h;}
function originalGround(c,q,room){
 const ox=room.smm2Mechanics.art.tileOriginX??0,oy=room.smm2Mechanics.art.tileOriginY??0;
 // Neighbours are read only to choose an interior/rim motif. Split geometry
 // keeps the same world grid; no composite panorama is pasted into the level.
 const ground=(room.map?.geometry||[]).filter(g=>g.material==='ground'&&!g.hidden&&g.visible!==false);
 const occupied=(x,y)=>ground.some(g=>contains(g,x,y))||contains(q,x,y);
 clipped(c,q,()=>{
  for(let y=Math.floor((q.y-oy)/16)*16+oy;y<q.y+q.h;y+=16)for(let x=Math.floor((q.x-ox)/16)*16+ox;x<q.x+q.w;x+=16){
   const interior=[[x+8,y-8],[x+8,y+24],[x-8,y+8],[x+24,y+8]].every(([px,py])=>occupied(px,py));
   const col=((Math.floor((x-ox)/16)+Math.floor((y-oy)/16))&1)?4:3;
   paint(c,interior?crop('ghostGroundComposite',col*16,96,16,16):crop('ghostGroundComposite',48,16,16,16),x,y);
  }
 });return true;
}
export function drawSmm2GhostScenery(c,q,room={}){
 if(!isSmm2GhostArtRoom(room)||!visible(q)||!rect(q))return false;
 if(q.smm2Art==='ghost-timber-backdrop'){
  // Original vertical timber motif; its placement is authored from lit views.
  clipped(c,q,()=>{for(let y=q.y;y<q.y+q.h;y+=56)for(let x=q.x;x<q.x+q.w;x+=64)paint(c,crop('ghostTimberSemisolid',0,8,64,56),x,y);});return true;
 }
 if(q.smm2Art==='ghost-timber-beam'){
  // Source-constrained reconstruction: the isolated source PNG does not
  // contain the thick backdrop cross-beams. Keep that limit in provenance.
  clipped(c,q,()=>{c.fillStyle='#082b30';c.fillRect(q.x,q.y,q.w,q.h);for(let y=Math.floor(q.y);y<q.y+q.h;y++)for(let x=Math.floor(q.x);x<q.x+q.w;x++)if(((x+y)%8+8)%8<2){c.fillStyle='#11444f';c.fillRect(x,y,1,1);}});return true;
 }
 return false;
}
export function drawSmm2GhostTile(c,q,room={}){
 if(!isSmm2GhostArtRoom(room)||!visible(q)||!rect(q))return false;
 if(drawSmm2GhostScenery(c,q,room))return true;
 if(q.material==='ground'||q.smm2Art==='ghost-ground')return originalGround(c,q,room);
 if(q.smm2Art==='ghost-timber-semisolid'){
  clipped(c,q,()=>{for(let y=q.y;y<q.y+q.h;y+=64)for(let x=q.x;x<q.x+q.w;x+=64)paint(c,crop('ghostTimberSemisolid'),x,y);});return true;
 }
 return false;
}
export function drawSmm2GhostActor(c,a,tick=0,room={}){
 if(!isSmm2GhostArtRoom(room)||!rect(a))return false;
 const thwomp=a.type==='smm2-thwomp'&&!!a.smm2Thwomp,spiny=a.type==='spiny'||a.type==='Spiny'||a.smm2EnemyKind==='spiny';
 const pow=a.type==='smm2-pow'||['pow','smm2-pow'].includes(a.kind)||!!a.smm2Pow;
 if(!thwomp&&!spiny&&!pow)return false;
 if((a.kind==='enemy-death'?a.hidden||a.visible===false||a.removed||a.life<=0:!visible(a))||['spent','removed'].includes(a.smm2Pow?.phase))return true;
 const im=crop(thwomp?'ghostThwomp':spiny?'ghostSpiny':'ghostPow');
 // Original enemy frames retain their native aspect ratio and bottom anchor.
 // The physical hit box stays owned by the actor controller.
 const scale=thwomp?a.h/im.h:spiny?a.w/im.w:1,x=a.x+(a.w-im.w*scale)/2,y=a.y+a.h-im.h*scale;
 c.save();c.imageSmoothingEnabled=false;
 if(a.kind==='enemy-death'){c.translate(0,Math.round(y+im.h*scale)*2-im.h*scale);c.scale(1,-1);}
 if(spiny&&(a.vx>0||a.facing>0)){c.translate(2*Math.round(x)+im.w*scale,0);c.scale(-1,1);}
 paint(c,im,x,y,scale);c.restore();return true;
}
