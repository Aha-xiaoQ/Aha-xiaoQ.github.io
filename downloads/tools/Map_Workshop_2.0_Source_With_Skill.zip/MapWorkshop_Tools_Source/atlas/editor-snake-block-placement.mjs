/** Pure author-time occupancy checks for formal, room-owned Snake Blocks.
 * Only the controller's initial full 16px collision cells are checked. Its
 * future route and dynamic/state terrain remain authorable. Cloud solidity
 * belongs to the native passenger seat, never the visible cloud overhang. */
import {createSmm2SnakeBlocks} from './editor-snake-blocks.mjs';
import {geometryPlacementType, placementOverlap, polygonPlacementOverlap, pickupType} from './editor-placement.mjs';
import {createSMM2Terrain} from './editor-smm2-terrain.mjs';

const rectangle = q => q && ['x', 'y', 'w', 'h'].every(k => Number.isFinite(q[k])) && q.w > 0 && q.h > 0;
const bounds = q => ({x: q.x, y: q.y, w: q.w, h: q.h});
function nearby(records) {
  const grid = new Map(), wide = [];
  const range = q => [Math.floor(q.x / 64), Math.floor((q.x + q.w - 1e-7) / 64), Math.floor(q.y / 64), Math.floor((q.y + q.h - 1e-7) / 64)];
  for (const q of records) {
    const [a, b, c, d] = range(q);
    if ((b - a + 1) * (d - c + 1) > 4096) {wide.push(q); continue;}
    for (let x = a; x <= b; x++) for (let y = c; y <= d; y++) {const key = x + ',' + y, list = grid.get(key) || []; list.push(q); grid.set(key, list);}
  }
  return q => {const result = new Set(wide), [a, b, c, d] = range(q); for (let x = a; x <= b; x++) for (let y = c; y <= d; y++) for (const other of grid.get(x + ',' + y) || []) result.add(other); return result;};
}

/** Detached geometry, using the runtime controller's exact initial window. */
export function initialSmm2SnakeBlockGeometry(room) {
  return createSmm2SnakeBlocks(room)?.geometry() || [];
}

export function smm2SnakeBlockPlacementIssues(room, options = {}) {
  const cells = initialSmm2SnakeBlockGeometry(room);
  if (!cells.length) return [];
  const issues = [], seen = new Set();
  const add = (code, cell, other, description) => {
    const ids = [cell.trainId, other.trainId || other.id], key = code + '\n' + [...ids].sort().join('\n');
    if (seen.has(key)) return;
    seen.add(key);
    issues.push({code, severity: 'error', roomId: room.roomId, ids, bounds: bounds(cell), message: description});
  };
  const permanent = (room.map.geometry || []).filter(q => rectangle(q) && geometryPlacementType(room, q, options).permanent);
  // These components create permanent native rectangles outside map.geometry.
  permanent.push(...[...(room.marioModules?.noteBlocks || []), ...(room.contraptions?.notes || [])].filter(rectangle));
  permanent.push(...(room.switchStudy?.devices || []).filter(q => q.kind === 'switch' && rectangle(q)));
  const slopes = room.smm2Mechanics?.slopes?.length ? createSMM2Terrain(room).surfaces().filter(q => q.kind === 'slope') : [];
  const objects = (room.map.objects || []).filter(q => rectangle(q) && (pickupType(room, q) || ['spawn', 'portal', 'exit', 'checkpoint', 'key'].includes(q.kind)));
  const seats = (room.smm2Mechanics?.lakituClouds?.clouds || []).map(q => ({id: q.id, x: q.x + (q.w - 10) / 2, y: q.y + q.seatOffsetY, w: 10, h: 14}));
  const record = (q, kind, extra = {}) => ({...bounds(q), body: q, kind, ...extra});
  const candidates = nearby([
    ...permanent.map(q => record(q, 'solid')), ...objects.map(q => record(q, 'object')), ...seats.map(q => record(q, 'seat')),
    ...cells.map((q, ordinal) => record(q, 'train', {ordinal})),
    ...slopes.map(q => {const xs = q.polygon.map(p => p.x), ys = q.polygon.map(p => p.y); return {body: q, kind: 'slope', x: Math.min(...xs), y: Math.min(...ys), w: Math.max(...xs) - Math.min(...xs), h: Math.max(...ys) - Math.min(...ys)};})
  ]);
  for (let i = 0; i < cells.length; i++) {
    const cell = cells[i];
    for (const candidate of candidates(cell)) {
      const other = candidate.body;
      if (!placementOverlap(cell, candidate)) continue;
      if (candidate.kind === 'solid') add('SNAKE_INITIAL_SOLID_OVERLAP', cell, other, 'Snake Block initial collision overlaps permanent solid ' + other.id);
      else if (candidate.kind === 'slope' && polygonPlacementOverlap(cell, other.polygon)) add('SNAKE_INITIAL_SOLID_OVERLAP', cell, other, 'Snake Block initial collision overlaps permanent slope ' + other.id);
      else if (candidate.kind === 'object') add('SNAKE_INITIAL_OBJECT_OVERLAP', cell, other, 'Snake Block initial collision overlaps independent native ' + (pickupType(room, other) || other.kind) + ' ' + other.id);
      else if (candidate.kind === 'seat') add('SNAKE_INITIAL_CLOUD_SEAT_OVERLAP', cell, other, 'Snake Block initial collision overlaps Lakitu Cloud native passenger seat ' + other.id);
      // Fractional endpoints can overlap their own occupied window's cells.
      else if (candidate.kind === 'train' && candidate.ordinal > i && cell.trainId !== other.trainId) add('SNAKE_INITIAL_TRAIN_OVERLAP', cell, other, 'Snake Block initial collision overlaps another train ' + other.trainId);
    }
  }
  return issues;
}

export function validateSmm2SnakeBlockPlacement(room, options = {}) {
  const issues = smm2SnakeBlockPlacementIssues(room, options);
  if (issues.length) {
    const error = new Error(issues.map(q => q.message).join('; '));
    error.issues = issues;
    throw error;
  }
  return room;
}
