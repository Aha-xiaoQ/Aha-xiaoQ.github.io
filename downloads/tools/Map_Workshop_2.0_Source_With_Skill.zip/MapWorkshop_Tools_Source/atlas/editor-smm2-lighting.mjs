/** Appearance-only, explicitly authored night lighting. All radii/soft edges are
 * workshop approximations, not recovered Nintendo constants or a type table. */
const plain=v=>v&&typeof v==='object'&&!Array.isArray(v)&&[Object.prototype,null].includes(Object.getPrototypeOf(v));
const finite=(v,min,max)=>Number.isFinite(v)&&v>=min&&v<=max;
const safeId=v=>typeof v==='string'&&v.length>0&&v.length<=128&&!/[\u0000-\u001f\u007f]/.test(v)&&!['__proto__','prototype','constructor'].includes(v);
function fields(value,allowed,required,label){
 if(!plain(value))throw Error('Invalid SMM2 lighting '+label);
 for(const key of Object.keys(value))if(!allowed.includes(key)||['__proto__','prototype','constructor'].includes(key))throw Error('Unknown SMM2 lighting '+label+' field: '+key);
 for(const key of required)if(!Object.hasOwn(value,key))throw Error('Missing SMM2 lighting '+label+' field: '+key);
}
/** Only stable preplaced native bodies and explicitly centered fixed arrows. */
export function smm2LightingTargets(room){
 const out=[...(room?.map?.objects||[]).filter(q=>q.kind!=='spawn').map(q=>({id:q.id,kind:'object',body:q})),...(room?.map?.geometry||[]).map(q=>({id:q.id,kind:'geometry',body:q}))];
 for(const q of room?.contraptions?.coinCranes||[])out.push({id:q.id,kind:'coin-crane',body:{x:(q.initialX??q.minX)-8,y:q.restY-8,w:16,h:16}});
 const ids=new Set(out.map(q=>q.id));
 for(const q of room?.markers||[])if(q.kind==='source-arrow'&&!ids.has(q.id))out.push({id:q.id,kind:'marker',body:q});
 return out;
}
export function validateSmm2LightingRoom(room){
 const q=room?.smm2Mechanics?.lighting;if(q===undefined)return;
 if(room.smm2Mechanics.version!==1)throw Error('Unknown SMM2 lighting mechanics version');
 fields(q,['darkness','playerRadius','softness','sources','offRadiusScale','sweepingLamps'],['darkness','playerRadius','sources'],'config');
 if(!finite(q.darkness,0,1)||!finite(q.playerRadius,8,512)||q.softness!==undefined&&!finite(q.softness,0,1))throw Error('Invalid SMM2 lighting darkness, radius or softness');
 if(Object.hasOwn(q,'offRadiusScale')&&(!finite(q.offRadiusScale,.05,1)||room.switchStudy?.version!==1))throw Error('SMM2 lighting OFF radius scale requires a finite value in [0.05,1] and switchStudy version 1');
 if(!Array.isArray(q.sources)||q.sources.length>64)throw Error('Invalid SMM2 lighting source list');
 const targets=smm2LightingTargets(room),seen=new Set(),byId=new Map();
 for(const target of targets){const list=byId.get(target.id)||[];list.push(target);byId.set(target.id,list);}
 for(const source of q.sources){
  fields(source,['targetId','radius','offsetX','offsetY'],['targetId','radius'],'source');
  const matches=byId.get(source.targetId),target=matches?.[0];
  if(!safeId(source.targetId)||seen.has(source.targetId)||!target||matches.length!==1)throw Error('SMM2 lighting source must reference a unique stable preplaced target');
  if(!finite(source.radius,8,512))throw Error('Invalid SMM2 lighting source radius');
  for(const key of ['offsetX','offsetY'])if(Object.hasOwn(source,key)&&!finite(source[key],-512,512))throw Error('Invalid SMM2 lighting source offset');
  if(target.kind==='marker'&&(!finite(source.offsetX,-512,512)||!finite(source.offsetY,-512,512)))throw Error('SMM2 lighting arrow requires explicit center offsets');
  if(!Number.isFinite(target.body.x)||!Number.isFinite(target.body.y))throw Error('Invalid SMM2 lighting target position');
  seen.add(source.targetId);
 }
 if(Object.hasOwn(q,'sweepingLamps')){
  if(!Array.isArray(q.sweepingLamps)||q.sweepingLamps.length>16)throw Error('Invalid SMM2 sweeping lamp list');
  const lampIds=new Set(),targetIds=new Set(targets.map(q=>q.id));
  for(const lamp of q.sweepingLamps){
   fields(lamp,['id','x','y','length','halfAngle','minAngle','maxAngle','periodFrames','phaseFrames','enabledWhenOn','enabledWhenMachine'],['id','x','y','length','halfAngle','minAngle','maxAngle','periodFrames'],'sweeping lamp');
   if(!safeId(lamp.id)||lampIds.has(lamp.id)||targetIds.has(lamp.id))throw Error('SMM2 sweeping lamp needs an independent unique stable ID');
   if(!finite(lamp.x,0,room.map?.width)||!finite(lamp.y,0,room.map?.height)||!finite(lamp.length,8,1024)||!finite(lamp.halfAngle,1,60)||!finite(lamp.minAngle,-85,85)||!finite(lamp.maxAngle,-85,85)||lamp.minAngle>lamp.maxAngle||lamp.minAngle-lamp.halfAngle<=-90||lamp.maxAngle+lamp.halfAngle>=90)throw Error('Invalid SMM2 sweeping lamp position, cone or angle range');
   if(!Number.isInteger(lamp.periodFrames)||!finite(lamp.periodFrames,2,36000)||Object.hasOwn(lamp,'phaseFrames')&&(!Number.isInteger(lamp.phaseFrames)||!finite(lamp.phaseFrames,0,35999)))throw Error('Invalid SMM2 sweeping lamp frame period or phase');
   if(Object.hasOwn(lamp,'enabledWhenOn')&&typeof lamp.enabledWhenOn!=='boolean'||lamp.enabledWhenOn===true&&room.switchStudy?.version!==1)throw Error('SMM2 ON-gated sweeping lamp requires an existing switchStudy version 1');
   if(lamp.enabledWhenMachine!==undefined&&(!safeId(lamp.enabledWhenMachine)||lamp.enabledWhenOn===true||!room.contraptions?.coinCranes?.some(q=>q.id===lamp.enabledWhenMachine&&q.searchlight)))throw Error('Machine-gated sweeping lamp needs one independently switched real crane');
   lampIds.add(lamp.id);
  }
 }
}
/** Pure parsing; omission is the only default-off state. */
export function parseSmm2Lighting(room){
 validateSmm2LightingRoom(room);const q=room?.smm2Mechanics?.lighting;
 return q===undefined?null:{darkness:q.darkness,playerRadius:q.playerRadius,softness:q.softness??.25,sources:q.sources.map(q=>({...q})),...(Object.hasOwn(q,'offRadiusScale')?{offRadiusScale:q.offRadiusScale}:{}),...(Object.hasOwn(q,'sweepingLamps')?{sweepingLamps:q.sweepingLamps.map(lamp=>({...lamp,phaseFrames:lamp.phaseFrames??0,enabledWhenOn:lamp.enabledWhenOn??false}))}:{})};
}
/** Authored appearance only: clockwise degrees from downward vertical. The
 * simulation tick is read, never advanced; repeated renders are identical. */
export function resolveSmm2SweepingLamps(room,view,{preview=false}={}){
 return resolveLamps(room,view,preview,parseSmm2Lighting(room));
}
function resolveLamps(room,view,preview,spec){
 if(typeof preview!=='boolean')throw Error('Invalid SMM2 lighting preview mode');
 if(!spec?.sweepingLamps?.length||!preview&&(!view||view.roomId!==undefined&&view.roomId!==room.roomId))return [];
 const tick=preview?0:view.tick;if(!Number.isInteger(tick)||tick<0)return [];
 const switchState=preview?room.switchStudy:view.switchStudy,on=preview?switchState?.initialOn:switchState?.on;
 return spec.sweepingLamps.filter(lamp=>(!lamp.enabledWhenOn||switchState?.version===1&&on===true)&&(!lamp.enabledWhenMachine||(preview?room.contraptions?.coinCranes?.find(q=>q.id===lamp.enabledWhenMachine)?.searchlight?.initialOn:view.contraptions?.coinCranes?.find(q=>q.id===lamp.enabledWhenMachine)?.lampOn)===true)).map(lamp=>{
  const t=((tick+lamp.phaseFrames)%lamp.periodFrames)/lamp.periodFrames,weight=(1-Math.cos(t*Math.PI*2))/2;
  return{id:lamp.id,x:lamp.x,y:lamp.y,length:lamp.length,halfAngle:lamp.halfAngle,angle:lamp.minAngle+(lamp.maxAngle-lamp.minAngle)*weight};
 });
}
const visible=q=>q&&!q.dead&&!q.dying&&!q.removed&&!q.taken&&!q.collected&&!q.hidden&&q.visible!==false;
const body=q=>visible(q)&&['x','y','w','h'].every(k=>Number.isFinite(q[k]))&&q.w>0&&q.h>0;
const centered=(q,source)=>({targetId:source.targetId,x:q.x+q.w/2+(source.offsetX??0),y:q.y+q.h/2+(source.offsetY??0),radius:source.radius});
/** Runtime lookup never falls back to an author's initial actor position.
 * POW actor data wins over its same-ID collision proxy. Split native geometry
 * uses the bounding box of the remaining live pieces with the same sourceId. */
export function resolveSmm2LightSources(room,view,{preview=false}={}){
 return resolveSources(room,view,preview,parseSmm2Lighting(room));
}
function resolveSources(room,view,preview,spec){
 if(!spec)return [];
 if(typeof preview!=='boolean')throw Error('Invalid SMM2 lighting preview mode');
 if(!preview&&(!view||view.roomId!==undefined&&view.roomId!==room.roomId))return [];
 // An associated room must supply the actual global switch state. Missing or
 // malformed runtime state emits no sources; author initialOn is preview-only.
 let radiusScale=1;
 if(spec.offRadiusScale!==undefined){
  const switchState=preview?room.switchStudy:view.switchStudy,on=preview?switchState?.initialOn:switchState?.on;
  if(switchState?.version!==1||typeof on!=='boolean')return [];
  if(!on)radiusScale=spec.offRadiusScale;
 }
 const result=[],player=preview?room.map.objects.find(q=>q.kind==='spawn'):view.p;
 if(body(player))result.push(centered(player,{targetId:'player',radius:spec.playerRadius}));
 const targets=new Map(smm2LightingTargets(room).map(q=>[q.id,q])),actors=new Map(),geometry=new Map();
 if(!preview){
  for(const q of [...(view.items||[]),...(view.enemies||[]),...(view.objects||[])])if(!actors.has(q.id))actors.set(q.id,q);
  const geometryIds=new Set(spec.sources.filter(q=>targets.get(q.targetId).kind==='geometry').map(q=>q.targetId));
  for(const q of view.geometry||[])if(body(q))for(const id of new Set([q.id,q.sourceId]))if(geometryIds.has(id)){
   const prior=geometry.get(id);geometry.set(id,prior?{x:Math.min(prior.x,q.x),y:Math.min(prior.y,q.y),right:Math.max(prior.right,q.x+q.w),bottom:Math.max(prior.bottom,q.y+q.h)}:{x:q.x,y:q.y,right:q.x+q.w,bottom:q.y+q.h});
  }
 }
 for(const source of spec.sources){
  const target=targets.get(source.targetId);
  if(target.kind==='coin-crane'){const q=preview?target.body:(view.contraptions?.coinCranes||[]).find(q=>q.id===source.targetId);if(preview){if(body(q))result.push(centered(q,source));}else if(q?.grip&&Number.isFinite(q.grip.x)&&Number.isFinite(q.grip.y))result.push({targetId:source.targetId,x:q.grip.x+(source.offsetX??0),y:q.grip.y+(source.offsetY??0),radius:source.radius});continue;}
  if(target.kind==='marker'){
   const q=target.body;if(visible(q)&&(preview||!view.hiddenMarkers?.includes(q.id)))result.push({targetId:q.id,x:q.x+source.offsetX,y:q.y+source.offsetY,radius:source.radius});
   continue;
  }
  if(preview){if(body(target.body))result.push(centered(target.body,source));continue;}
  if(target.kind==='object'){
   // Find first before visibility filtering: a spent/dead item must never
   // accidentally gain light from a stale collision proxy with the same ID.
   const q=actors.get(source.targetId);
   if(body(q))result.push(centered(q,source));
  }else{
   const bounds=geometry.get(source.targetId);
   if(bounds)result.push(centered({x:bounds.x,y:bounds.y,w:bounds.right-bounds.x,h:bounds.bottom-bounds.y},source));
  }
 }
 return radiusScale===1?result:result.map(q=>({...q,radius:q.radius*radiusScale}));
}
/** Prune only bindings to targets that actually existed before deletion.
 * Newly authored invalid IDs remain validation errors. Movement needs no edit. */
export function pruneSmm2LightingReferences(room,before){
 const q=room.smm2Mechanics?.lighting;if(!q||!before)return;
 const oldIds=new Set(smm2LightingTargets(before).map(q=>q.id)),nowIds=new Set(smm2LightingTargets(room).map(q=>q.id));
 q.sources=q.sources.filter(q=>!oldIds.has(q.targetId)||nowIds.has(q.targetId));if(q.sweepingLamps)q.sweepingLamps=q.sweepingLamps.filter(lamp=>!lamp.enabledWhenMachine||room.contraptions?.coinCranes?.some(c=>c.id===lamp.enabledWhenMachine&&c.searchlight));
}
const masks=new WeakMap();
function defaultCanvas(width,height){
 if(typeof OffscreenCanvas!=='undefined')return new OffscreenCanvas(width,height);
 if(typeof document!=='undefined'){const canvas=document.createElement('canvas');canvas.width=width;canvas.height=height;return canvas;}
 throw Error('SMM2 lighting renderer needs a createCanvas factory');
}
/** Call in output/viewport coordinates after drawing the world, before HUD.
 * camera is the exact world rectangle used by that render, including rounding.
 * An injected Canvas factory makes the same renderer work in offline video QA. */
export function drawSmm2LightingMask(ctx,room,view,{camera,width=ctx.canvas?.width,height=ctx.canvas?.height,preview=false,createCanvas=defaultCanvas}={}){
 const spec=parseSmm2Lighting(room);if(!spec||spec.darkness===0)return false;
 if(!camera||!['x','y','width','height'].every(k=>Number.isFinite(camera[k]))||camera.width<=0||camera.height<=0||!Number.isInteger(width)||!Number.isInteger(height)||width<=0||height<=0||width>16384||height>16384||typeof createCanvas!=='function')throw Error('Invalid SMM2 lighting viewport');
 let cached=masks.get(ctx);if(!cached||cached.factory!==createCanvas){const canvas=createCanvas(width,height);cached={canvas,ctx:canvas.getContext('2d'),factory:createCanvas};masks.set(ctx,cached);}
 const mask=cached.canvas,m=cached.ctx;if(mask.width!==width)mask.width=width;if(mask.height!==height)mask.height=height;
 m.save();m.setTransform(1,0,0,1,0,0);m.globalAlpha=1;m.globalCompositeOperation='source-over';m.clearRect(0,0,width,height);m.fillStyle='rgba(0,0,0,'+spec.darkness+')';m.fillRect(0,0,width,height);
 const sx=width/camera.width,sy=height/camera.height;m.scale(sx,sy);m.translate(-camera.x,-camera.y);m.globalCompositeOperation='destination-out';
 for(const q of resolveSources(room,view,preview,spec)){
  if(q.x+q.radius<camera.x||q.x-q.radius>camera.x+camera.width||q.y+q.radius<camera.y||q.y-q.radius>camera.y+camera.height)continue;
  if(spec.softness===0)m.fillStyle='#000';
  else{const gradient=m.createRadialGradient(q.x,q.y,q.radius*(1-spec.softness),q.x,q.y,q.radius);gradient.addColorStop(0,'rgba(0,0,0,1)');gradient.addColorStop(1,'rgba(0,0,0,0)');m.fillStyle=gradient;}
  m.beginPath();m.arc(q.x,q.y,q.radius,0,Math.PI*2);m.fill();
 }
 for(const lamp of resolveLamps(room,view,preview,spec)){
  if(lamp.x+lamp.length<camera.x||lamp.x-lamp.length>camera.x+camera.width||lamp.y+lamp.length<camera.y||lamp.y-lamp.length>camera.y+camera.height)continue;
  const radians=Math.PI/180,start=(90+lamp.angle-lamp.halfAngle)*radians,end=(90+lamp.angle+lamp.halfAngle)*radians;
  if(spec.softness===0)m.fillStyle='#000';
  else{const gradient=m.createRadialGradient(lamp.x,lamp.y,lamp.length*(1-spec.softness),lamp.x,lamp.y,lamp.length);gradient.addColorStop(0,'rgba(0,0,0,1)');gradient.addColorStop(1,'rgba(0,0,0,0)');m.fillStyle=gradient;}
  m.beginPath();m.moveTo(lamp.x,lamp.y);m.arc(lamp.x,lamp.y,lamp.length,start,end);m.closePath();m.fill();
 }
 m.restore();ctx.save();ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';ctx.drawImage(mask,0,0,width,height);ctx.restore();return true;
}
