/** Original, code-native SMB3 underground study artwork.
 * Authored from visual observation of the private story-7 reference. These
 * pixels are approximate, not official Nintendo assets or screenshot crops.
 * No native SMB1 atlas reads, mutation, collision, timing, or reward writes.
 * The underground palette keeps this authored study path; the finite Desert
 * source/adaptation family dispatches to editor-heavy-stone-art.mjs.
 */
import {isHeavyStoneArtRoom,drawHeavyStoneBackground,drawHeavyStoneTile,drawHeavyStoneSlope,drawHeavyStoneActor,drawHeavyStonePlayer,drawHeavyStoneScenery,drawHeavyStoneWorld} from './editor-heavy-stone-art.mjs';
export const SMB3_ART_PALETTE=Object.freeze({
 black:'#000000',ink:'#171918',white:'#fffdf1',dot:'#24494a',
 cyan:'#86dce4',cyanLight:'#b0f2ec',blue:'#327c88',blueDark:'#17505b',
 red:'#ef4429',redDark:'#913d23',skin:'#ffce92',brown:'#713e22',
 gold:'#eda44d',goldLight:'#ffda92',orange:'#c57c2c',orangeDark:'#78441e',
 green:'#49be25',greenDark:'#227014',greenLight:'#b6ea72',
 liftBlue:'#2c83d4',liftDark:'#154e92',liftLight:'#a4e8ef',
 plantDark:'#28484d',plant:'#417580',root:'#d58d2e'
});
const P=SMB3_ART_PALETTE;
const validRect=q=>q&&['x','y','w','h'].every(k=>Number.isFinite(q[k]))&&q.w>0&&q.h>0;
const visible=q=>q&&!q.hidden&&q.visible!==false&&!q.removed&&!q.dead&&!q.taken;
const point=q=>q&&Number.isFinite(q.x)&&Number.isFinite(q.y);
export const isSmb3ArtRoom=room=>room?.smm2Mechanics?.version===1&&['smb3-underground','smb3-desert'].includes(room.smm2Mechanics.art?.palette);
function rect(c,color,x,y,w=1,h=1){
 const x0=Math.round(x),y0=Math.round(y),x1=Math.round(x+w),y1=Math.round(y+h);
 if(x1<=x0||y1<=y0)return;c.fillStyle=color;c.fillRect(x0,y0,x1-x0,y1-y0);
}
function painter(c,q,w,h,fn){
 if(!validRect(q))return false;c.save();c.imageSmoothingEnabled=false;
 const x=Math.round(q.x),y=Math.round(q.y),tw=Math.max(1,Math.round(q.w)),th=Math.max(1,Math.round(q.h));
 const p=(color,px,py,pw=1,ph=1)=>{
  const l=Math.round(px*tw/w),t=Math.round(py*th/h),r=Math.round((px+pw)*tw/w),b=Math.round((py+ph)*th/h);
  rect(c,color,x+l,y+t,r-l,b-t);
 };fn(p);c.restore();return true;
}
function mask(p,rows,x,y,color){for(let yy=0;yy<rows.length;yy++)for(let xx=0;xx<rows[yy].length;xx++)if(rows[yy][xx]==='1')p(color,x+xx,y+yy);}
function clipped(c,q,fn){c.save();c.beginPath();c.rect(Math.round(q.x),Math.round(q.y),Math.round(q.w),Math.round(q.h));c.clip();fn();c.restore();}
const mod8=x=>((x%8)+8)%8;
/** Broad diagonal facets continue across adjoining world-space rectangles. */
function groundPixel(x,y){
 const px=mod8(x),py=mod8(y);
 if(px===0||py===0)return P.blue;
 if(py===1&&px<6||px===1&&py<6)return P.cyanLight;
 return py>=8-px?P.blueDark:P.cyan;
}
function ground(c,q){
 clipped(c,q,()=>{
  for(let y=Math.floor(q.y/8)*8;y<q.y+q.h;y+=8)for(let x=Math.floor(q.x/8)*8;x<q.x+q.w;x+=8){
   rect(c,P.cyan,x,y,8,8);
   for(let py=1;py<8;py++)rect(c,P.blueDark,x+8-py,y+py,py,1);
   rect(c,P.blue,x,y,8,1);rect(c,P.blue,x,y,1,8);rect(c,P.cyanLight,x+1,y+1,5,1);rect(c,P.cyanLight,x+1,y+1,1,5);
  }
 });
}
export function drawSmb3Background(c,room,w,h){
 if(isHeavyStoneArtRoom(room))return drawHeavyStoneBackground(c,room,w,h);
 if(!isSmb3ArtRoom(room)||!Number.isFinite(w)||!Number.isFinite(h)||w<=0||h<=0)return false;
 rect(c,P.black,0,0,w,h);
 const offset=Math.round(room.renderBounds?.x??0);
 for(let y=4;y<h;y+=8)for(let x=4-(offset%16)+(Math.floor(y/8)%2)*8;x<w;x+=16)rect(c,P.dot,x,y);
 return true;
}
function blockCell(c,q,kind){
 return painter(c,q,16,16,p=>{
  p(P.ink,0,0,16,16);p(P.orange,1,1,14,14);p(P.goldLight,1,1,14,1);p(P.goldLight,1,2,1,12);p(P.orangeDark,14,2,1,13);p(P.orangeDark,2,14,12,1);
  if(kind==='brick'){
   p(P.orangeDark,1,7,14,1);p(P.orangeDark,8,1,1,6);p(P.orangeDark,4,8,1,6);p(P.orangeDark,12,8,1,6);
   p(P.gold,2,3,5,1);p(P.gold,10,3,3,1);p(P.gold,5,10,6,1);
  }else if(kind==='used'){
   for(const [x,y]of [[3,3],[11,3],[3,11],[11,11]])p(P.orangeDark,x,y);
  }else{
   for(const [x,y]of [[2,2],[13,2],[2,13],[13,13]])p(P.orangeDark,x,y);
   mask(p,['01110','11011','00011','00110','00100','00000','00100'],6,4,P.orangeDark);
   p(P.goldLight,7,4,2,1);p(P.gold,7,9,1,1);
  }
 });
}
function tiled(c,q,fn){clipped(c,q,()=>{for(let y=q.y;y<q.y+q.h;y+=16)for(let x=q.x;x<q.x+q.w;x+=16)fn(c,{x,y,w:16,h:16});});return true;}
function conveyor(c,q){
 clipped(c,q,()=>{
  rect(c,P.greenDark,q.x,q.y,q.w,q.h);rect(c,P.green,q.x,q.y,q.w,2);rect(c,P.green,q.x,q.y+q.h-2,q.w,2);rect(c,P.ink,q.x+1,q.y+3,q.w-2,Math.max(1,q.h-6));
  for(let x=q.x+2;x<q.x+q.w;x+=16){
   const cy=q.y+q.h/2;for(let d=0;d<6;d++){rect(c,P.goldLight,x+d,cy-1-d);rect(c,P.goldLight,x+d,cy+d);rect(c,P.goldLight,x+11-d,cy-1-d);rect(c,P.goldLight,x+11-d,cy+d);}
  }
 });return true;
}
/** White, open semisolid supports remain scenery below the physical top. */
function semisolid(c,q,{postsOnly=false}={}){
 clipped(c,q,()=>{
  const cap=postsOnly?0:Math.min(q.h,8);
  if(cap){rect(c,P.ink,q.x,q.y,q.w,cap);rect(c,P.white,q.x+1,q.y+1,q.w-2,Math.max(1,cap-2));rect(c,P.blue,q.x,q.y+cap-1,q.w,1);}
  for(let x=q.x+5;x<q.x+q.w;x+=16){rect(c,P.blueDark,x,q.y+cap,3,q.h-cap);rect(c,P.white,x+1,q.y+cap,1,q.h-cap);if(cap){rect(c,P.ink,x-1,q.y+3,3,3);rect(c,P.white,x,q.y+4);}}
 });return true;
}
export function drawSmb3Tile(c,q,room={}){
 if(isHeavyStoneArtRoom(room))return drawHeavyStoneTile(c,q,room);
 if(!isSmb3ArtRoom(room)||!validRect(q))return false;
 const original=room.map?.geometry?.find(g=>g.id===(q.sourceId||q.id))??room.decorations?.find(g=>g.id===(q.sourceId||q.id)),style=q.smm2Art??original?.smm2Art;
 const material=q.material??original?.material;
 const known=['ground','brick','block','used','spring','platform'].includes(material)||['smb3-underground-ground','smb3-conveyor','smb3-semisolid','smb3-semisolid-posts','smb3-blue-fall-lift','smb3-outline-hill','smb3-dark-spiral'].includes(style)||q.smm2Platform==='blue-falling';
 if(!known)return false;if(!visible(q))return true;
 if(['smb3-outline-hill','smb3-dark-spiral'].includes(style))return true; // The scenery pass owns these open outline bodies.
 if(material==='spring'){drawSmb3Spring(c,q);return true;}
 if(style==='smb3-blue-fall-lift'||q.smm2Platform==='blue-falling'){drawSmb3BluePlatform(c,q);return true;}
 if(['brick','block','used'].includes(material)){tiled(c,q,(ctx,cell)=>blockCell(ctx,cell,q.used||material==='used'?'used':material==='brick'?'brick':'question'));return true;}
 if(style==='smb3-conveyor')return conveyor(c,q);
 if(style==='smb3-semisolid-posts')return semisolid(c,q,{postsOnly:true});
 if(style==='smb3-semisolid'||material==='platform')return semisolid(c,q);
 ground(c,q);return true;
}
/** The live polygon is authoritative, including finite diagonal strips. */
export function drawSmb3Slope(c,q,room={}){
 if(isHeavyStoneArtRoom(room))return drawHeavyStoneSlope(c,q,room);
 const spec=q?.spec??q,orientation=q?.orientation??spec?.orientation;
 if(!visible(q)||!visible(spec)||!validRect(spec)||!['rise-left','rise-right','ceiling-rise-left','ceiling-rise-right'].includes(orientation))return false;
 const right=orientation.endsWith('rise-right'),above=typeof q.solidAbove==='boolean'?q.solidAbove:orientation.startsWith('ceiling-');
 const diagonal={a:{x:spec.x,y:spec.y+(right?spec.h:0)},b:{x:spec.x+spec.w,y:spec.y+(right?0:spec.h)}};
 const offset=above?-spec.thickness:0,strip=spec.thickness===undefined?null:[{x:diagonal.a.x,y:diagonal.a.y+offset},{x:diagonal.b.x,y:diagonal.b.y+offset},{x:diagonal.b.x,y:diagonal.b.y+offset+spec.thickness},{x:diagonal.a.x,y:diagonal.a.y+offset+spec.thickness}];
 const polygon=q.polygon??strip??(above?[{x:spec.x,y:spec.y},{x:spec.x+spec.w,y:spec.y},{x:right?spec.x:spec.x+spec.w,y:spec.y+spec.h}]:[diagonal.a,diagonal.b,{x:right?spec.x+spec.w:spec.x,y:spec.y+spec.h}]);
 if(!Array.isArray(polygon)||polygon.length<3||polygon.length>32||!polygon.every(point))return false;
 const inside=(x,y)=>{let sign=0;for(let n=0;n<polygon.length;n++){const a=polygon[n],b=polygon[(n+1)%polygon.length],cross=(b.x-a.x)*(y-a.y)-(b.y-a.y)*(x-a.x);if(Math.abs(cross)<1e-7)continue;const next=Math.sign(cross);if(sign&&sign!==next)return false;sign=next;}return !!sign;};
 const minX=Math.min(...polygon.map(p=>p.x)),maxX=Math.max(...polygon.map(p=>p.x)),minY=Math.min(...polygon.map(p=>p.y)),maxY=Math.max(...polygon.map(p=>p.y));
 for(let y=Math.floor(minY);y<Math.ceil(maxY);y++)for(let x=Math.floor(minX);x<Math.ceil(maxX);x++)if(x+.5>=minX&&x+.5<maxX&&y+.5>=minY&&y+.5<maxY&&inside(x+.5,y+.5))rect(c,groundPixel(x,y),x,y);
 return true;
}
export function drawSmb3Spring(c,q){
 if(!visible(q)||!validRect(q))return false;
 const horizontal=q.springOrientation==='horizontal'||q.orientation==='horizontal'||q.axis==='x'||q.direction==='left'||q.direction==='right';
 const draw=(p,w,h)=>{
  p(P.ink,0,0,w,3);p(P.green,1,0,w-2,2);p(P.greenLight,2,0,w-4,1);p(P.ink,0,h-3,w,3);p(P.green,1,h-2,w-2,2);p(P.greenLight,2,h-2,w-4,1);
  const gap=h-6;
  let prior=2+Math.round(w-5);
  for(let n=0;n<gap;n++){
   const section=n/Math.max(1,gap-1),zig=Math.abs((section*4)%2-1),x=2+Math.round(zig*(w-5)),left=Math.min(x,prior),span=Math.abs(x-prior)+1;
   p(P.goldLight,left,3+n,span,1);p(P.goldLight,w-1-left-span,3+n,span,1);p(P.orangeDark,x,3+n);prior=x;
  }
 };
 if(!horizontal)return painter(c,q,16,Math.max(8,Math.round(q.h)),p=>draw(p,16,Math.max(8,Math.round(q.h))));
 c.save();c.translate(Math.round(q.x+q.w),Math.round(q.y));c.rotate(Math.PI/2);const handled=painter(c,{x:0,y:0,w:q.h,h:q.w},16,Math.max(8,Math.round(q.w)),p=>draw(p,16,Math.max(8,Math.round(q.w))));c.restore();return handled;
}
export function drawSmb3BluePlatform(c,q){
 if(!visible(q)||!validRect(q)||q.phase==='removed')return false;
 return painter(c,q,Math.max(16,Math.round(q.w)),Math.max(8,Math.round(q.h)),p=>{
  const w=Math.max(16,Math.round(q.w)),h=Math.max(8,Math.round(q.h));
  p(P.liftDark,0,0,w,h);p(P.liftLight,0,0,w,1);p(P.liftBlue,1,1,w-2,h-2);p(P.liftLight,1,h-2,w-2,1);
  for(let x=1;x<w-2;x+=8)for(let y=1;y<h-1;y++){
   const offset=Math.round((1-Math.abs((y-(h-1)/2)/Math.max(1,(h-3)/2)))*4);
   p(P.liftLight,x+offset,y,2,1);
  }
 });
}
export function drawSmb3OneWayWall(c,q){
 if(!visible(q)||!validRect(q)||!['right','left','down','up'].includes(q.direction??'right'))return false;
 const dir=q.direction??'right';
 return tiled(c,q,(ctx,cell)=>painter(ctx,cell,16,16,p=>{
  p(P.blueDark,0,0,16,16);p(P.goldLight,1,1,14,14);p(P.orange,2,2,12,12);p(P.gold,2,2,11,11);p(P.blue,14,1,1,14);p(P.blue,1,14,14,1);
  const d=(color,x,y)=>dir==='left'?p(color,15-x,y):dir==='down'?p(color,y,x):dir==='up'?p(color,y,15-x):p(color,x,y);
  for(const start of [3,8])for(let y=3;y<13;y++){const x=start+Math.min(y-3,12-y);d(P.blueDark,x,y);d(P.blueDark,x+1,y);}
 }));
}
export function drawSmb3Mushroom(c,q,{life=false,card=false}={}){
 if(!visible(q)||!validRect(q))return false;
 return painter(c,q,16,16,p=>{
  const top=life?P.green:P.red,dark=life?P.greenDark:P.redDark;
  mask(p,['0000111111110000','0001111111111000','0011111111111100','0111111111111110','1111111111111111','1111111111111111','1111111111111111','1111111111111111','0111111111111110'],0,0,P.ink);
  mask(p,['0000011111100000','0000111111110000','0001111111111000','0011111111111100','0111111111111110','0111111111111110','0111111111111110','0111111111111110'],0,1,top);
  p(dark,1,7,14,1);p(P.white,5,1,3,4);p(P.white,1,4,3,3);p(P.white,11,4,3,3);
  p(P.ink,4,9,8,6);p(P.skin,5,9,6,5);p(P.skin,4,10,8,3);p(P.ink,6,10,1,3);p(P.ink,9,10,1,3);p(P.brown,5,14,6,1);
  if(card)p(P.white,7,14,2,1);
 });
}
function flower(c,q){return painter(c,q,16,16,p=>{
 mask(p,['000111111110000','001111111111000','011111111111100','111111111111110','111111111111110','011111111111100','001111111111000','000111111110000'],1,0,P.ink);
 mask(p,['0001111111000','0011111111100','0111111111110','1111111111111','0111111111110','0011111111100'],2,1,P.red);
 p(P.skin,5,2,7,4);p(P.ink,7,3,1,2);p(P.ink,10,3,1,2);p(P.greenDark,7,8,2,8);p(P.green,7,8,1,7);
 mask(p,['100000000001','111000000111','011110011110','001111111100','000111111000'],2,10,P.green);p(P.greenLight,4,11,2,1);p(P.greenLight,10,11,2,1);
});}
function star(c,q,tick=0,{card=false}={}){return painter(c,q,16,16,p=>{
 const color=card?P.goldLight:[P.goldLight,P.greenLight,P.liftLight][Math.floor(tick/4)%3];
 mask(p,['0000000110000000','0000001111000000','0000011111100000','0000011111100000','0111111111111110','1111111111111111','0111111111111110','0011111111111100','0001111111111000','0001111111111000','0011111111111100','0011111111111100','0111111001111110','0111100000011110','0110000000000110'],0,0,P.ink);
 mask(p,['0000000110000000','0000001111000000','0000001111000000','0000011111100000','0111111111111110','0011111111111100','0001111111111000','0001111111111000','0000111111110000','0001111111111000','0001111111111000','0011111001111100','0011100000011100','0010000000000100'],0,1,color);
 p(P.ink,6,6,1,4);p(P.ink,9,6,1,4);
});}
function coin(c,q,tick=0){return painter(c,q,16,16,p=>{
 if(q.value===10||q.source?.value===10||q.source?.largeCoin){
  mask(p,['0000011111100000','0001111111111000','0011111111111100','0111111111111110','0111111111111110','1111111111111111','1111111111111111','1111111111111111','1111111111111111','1111111111111111','1111111111111111','0111111111111110','0111111111111110','0011111111111100','0001111111111000','0000011111100000'],0,0,P.blueDark);
  mask(p,['0000011111100000','0001111111111000','0011111111111100','0011111111111100','0111111111111110','0111111111111110','0111111111111110','0111111111111110','0111111111111110','0111111111111110','0011111111111100','0011111111111100','0001111111111000','0000011111100000'],0,1,P.gold);
  mask(p,['010','110','010','010','010','010','111'],4,5,P.orangeDark);mask(p,['01110','11011','10001','10001','10001','11011','01110'],8,5,P.orangeDark);p(P.goldLight,3,4,1,7);return;
 }
 const slim=Math.floor(tick/7)%4===2,l=slim?6:3,r=slim?9:12;
 p(P.blueDark,l,2,r-l+1,12);p(P.blueDark,l+1,1,r-l-1,14);p(P.gold,l+1,2,r-l-1,12);p(P.goldLight,l+2,3,1,10);p(P.goldLight,l+2,2,r-l-3,1);p(P.orange,l+4,4,1,8);p(P.goldLight,r-2,3,1,10);p(P.goldLight,l+2,13,r-l-3,1);
});}
export function drawSmb3Piranha(c,q,tick=0){
 if(!visible(q)||!validRect(q))return false;
 return painter(c,q,16,24,p=>{
  const open=q.mouthOpen??Math.floor(tick/12)%2===0;
  if(open){
   mask(p,['0111000000001110','0111000000001110','0111100000011110','0111100000011110','0011110000111100','0011111001111100','0011111111111100','0001111111111000','0000111111110000','0000011111100000'],0,0,P.ink);
   for(const [x,flip]of [[2,1],[12,-1]])for(let y=1;y<7;y++){p(P.white,x+Math.floor(y/3)*flip,y,2,1);p(P.red,x+Math.floor(y/3)*flip+(flip>0?-1:1),y+2,1,1);}
   p(P.red,4,8,8,3);p(P.red,6,11,4,1);p(P.white,3,7,2,1);p(P.white,11,7,2,1);
  }else{
   mask(p,['0000111111110000','0001111111111000','0011111111111100','0111111111111110','0111111111111110','0111111111111110','0011111111111100','0001111111111000','0000111111110000','0000011111100000'],0,1,P.ink);
   p(P.red,4,2,8,8);p(P.red,2,4,12,4);p(P.white,3,5,10,2);p(P.ink,6,5,4,1);p(P.white,5,2,2,2);p(P.white,10,8,2,2);
  }
  p(P.greenDark,7,12,2,12);p(P.green,7,12,1,11);
  mask(p,['100000000001','111000000111','111100001111','011110011110','001111111100','000111111000'],2,16,P.greenDark);
  mask(p,['1000000001','1100000011','0110000110','0011111100'],3,17,P.green);p(P.greenLight,4,18,1,2);p(P.greenLight,11,18,1,2);
 });
}
export function drawSmb3Muncher(c,q,tick=0){
 if(!visible(q)||!validRect(q))return false;
 return painter(c,q,16,16,p=>{
  const open=q.mouthOpen??Math.floor(tick/12)%2===0;
  mask(p,open?['0010000000000100','0011000000001100','0111100000011110','0111110000111110','1111111001111111','1111111111111111','0111111111111110','0011111111111100','0001111111111000']:['0000111111110000','0011111111111100','0111111111111110','1111111111111111','1111111111111111','0111111111111110','0011111111111100','0001111111111000'],0,0,P.plantDark);
  for(const [x,y,w,h]of [[2,4,3,4],[5,6,6,3],[11,4,3,4]])p(P.plant,x,y,w,h);
  p(P.plantDark,7,9,2,6);mask(p,['100000000001','111000000111','011110011110','001111111100'],2,10,P.plantDark);
  p(P.root,3,14,4,1);p(P.root,9,14,4,1);p(P.gold,5,13,2,1);p(P.gold,9,13,2,1);p(P.orangeDark,7,15,2,1);
 });
}
function shell(c,q){return painter(c,q,16,16,p=>{
 mask(p,['0001111111110000','0011111111111000','0111111111111100','1111111111111110','1111111111111110','1111111111111110','1111111111111110','0111111111111100','0011111111111000','0001111111110000'],0,3,P.ink);
 p(P.red,3,4,9,8);p(P.red,1,7,13,4);p(P.redDark,6,5,1,7);p(P.redDark,2,8,10,1);p(P.white,1,12,13,2);p(P.white,3,14,9,1);
});}
function koopaWings(c,q,tick=0){
 if(!(q.source?.winged===true||q.source?.floating===true||q.verticalFlight===true))return;
 const y=q.y+q.h-20+(Math.floor(tick/8)%2),rows=['00011000','00111100','01111100','11111100','11111110','01111110','00111111','00011111','00001111','00000111','00000011','00000001'];
 for(const side of [-1,1]){
  const x=side<0?q.x-5:q.x+q.w-3;
  painter(c,{x,y,w:8,h:12},8,12,p=>{
   const r=(color,px,py,pw=1,ph=1)=>side<0?p(color,px,py,pw,ph):p(color,8-px-pw,py,pw,ph);
   mask(r,rows,0,0,P.white);for(const [px,py,pw]of [[2,3,3],[1,6,4],[3,8,3]])r(P.cyanLight,px,py,pw,1);
  });
 }
}
function koopa(c,q,tick=0){if(q.shell||/shell/i.test(q.skin??''))return shell(c,q);koopaWings(c,q,tick);return painter(c,{...q,y:q.y+q.h-24,h:24},16,24,p=>{
 p(P.ink,9,0,4,9);p(P.skin,10,1,3,7);p(P.skin,8,4,7,3);p(P.ink,12,2,1,2);p(P.skin,8,8,4,7);
 mask(p,['000111111000','001111111100','011111111110','111111111111','111111111111','111111111111','011111111110','001111111100'],1,10,P.ink);
 mask(p,['0011111100','0111111110','1111111111','1111111111','1111111111','0111111110'],2,11,P.red);p(P.redDark,6,12,1,6);p(P.redDark,3,14,6,1);p(P.white,2,18,9,2);
 const step=Math.floor(tick/8)%2;p(P.orangeDark,2+step*2,21,5,2);p(P.orangeDark,9-step*2,21,5,2);p(P.skin,3+step*2,20,3,2);p(P.skin,10-step*2,20,3,2);
});}
export function drawSmb3Checkpoint(c,q,tick=0){
 if(!visible(q)||!validRect(q))return false;
 const center=Math.round(q.x+q.w/2),bottom=Math.round(q.y+q.h),top=bottom-32;
 rect(c,P.orangeDark,center-1,top+3,3,bottom-top-3);rect(c,P.goldLight,center,top+3,1,bottom-top-3);rect(c,P.orangeDark,center-3,top,6,5);rect(c,P.gold,center-2,top+1,4,3);
 const active=q.activated===true,age=q.activationAge,flutter=active&&Number.isFinite(age)&&age<16&&Math.floor(age/4)%2?1:0;
 const fx=center+2,fy=top+7,color=active?P.red:P.brown;
 for(let y=0;y<12;y++)rect(c,color,fx,fy+y,Math.max(4,12-Math.max(0,y-6))-flutter,1);
 const p=(color,x,y,w=1,h=1)=>rect(c,color,fx+x,fy+y,w,h);
 mask(p,active?['10001','11011','10101','10001','10001']:['10001','11111','10101','11111','01110'],2,3,P.white);
 return true;
}
/** A true floating card square, never a substitute flagpole or door. */
export function drawSmb3Goal(c,q,tick=0){
 if(!visible(q)||!validRect(q))return false;
 const state=q.cardState??q.state??q.card??['mushroom','flower','star'][Math.floor(tick/8)%3];
 painter(c,q,32,32,p=>{p(P.white,0,0,32,32);p(P.black,2,2,28,28);p(P.blueDark,2,30,28,1);});
 if(q.collected||state==='empty')return true;
 const icon={x:q.x+q.w/4,y:q.y+q.h/4,w:q.w/2,h:q.h/2};
 if(state==='flower')flower(c,icon);else if(state==='star')star(c,icon,tick,{card:true});else drawSmb3Mushroom(c,icon,{card:true,life:state==='life'});
 return true;
}
/** Small and Big bodies use their own authored silhouettes and real pose flags. */
export function drawSmb3Player(c,q,tick=0,room={}){
 if(isHeavyStoneArtRoom(room))return drawHeavyStonePlayer(c,q,tick,room);
 if(!isSmb3ArtRoom(room)||q?.hero==='bill'||!validRect(q))return false;
 if(q.hidden||q.visible===false||q.removed)return true;
 if(!q.dying&&!q.shrink&&!q.growth&&!q.fireGrowth&&q.invulnerable&&Math.floor(tick/4)%2)return true;
 const big=!q.dying&&!!((q.shrink||q.growth)?Math.floor((q.shrink||q.growth)/4)%2:q.power),crouch=big&&q.crouch&&!q.clawHeld,height=q.dying?16:crouch?20:big?28:16;
 const body={x:Math.round(q.x+(q.w-16)/2),y:Math.round(q.y+q.h-height),w:16,h:height};
 const hanging=!!(q.clawHeld||q.hanging||q.pose==='hang'),run=q.grounded&&Math.abs(q.vx||0)>.08&&!q.springId&&!q.piping,phase=Math.floor((q.anim??tick)/6)%3,air=!q.grounded&&!hanging&&!q.springId&&!q.piping;
 const palettes=q.star?[[P.skin,P.red,P.ink],[P.skin,P.greenLight,P.greenDark],[P.white,P.liftLight,P.liftDark],[P.skin,P.goldLight,P.orangeDark]]:q.power===2?[[P.skin,P.white,P.red]]:[[P.skin,P.red,P.ink]],colors=palettes[Math.floor(tick/4)%palettes.length];
 const [skin,shirt,overall]=colors;
 c.save();if(q.facing<0){c.translate(body.x+16,0);c.scale(-1,1);body.x=0;}
 const handled=painter(c,body,16,height,p=>{
  const head=crouch?2:0,face=big?11:8,torso=head+face,feet=height-3;
  p(P.ink,4,head,7,1);p(shirt,4,head+1,7,2);p(shirt,3,head+3,10,1);p(P.ink,5,head+4,7,face-4);p(skin,6,head+4,6,face-4);p(skin,5,head+5,8,Math.max(2,face-6));
  p(P.ink,4,head+4,2,3);p(P.ink,5,head+6,2,2);p(P.ink,10,head+4,1,3);p(skin,11,head+6,3,2);p(P.ink,8,head+8,5,1);p(P.ink,11,head+7,3,1);
  if(big){p(skin,7,head+9,4,2);p(P.ink,7,head+10,1,1);}
  p(shirt,4,torso,8,Math.max(3,feet-torso));p(overall,7,torso+1,3,Math.max(2,feet-torso-1));p(overall,4,torso+4,8,Math.max(1,feet-torso-4));p(skin,7,torso+3,1,1);p(skin,10,torso+3,1,1);
  const armY=hanging?torso-4:q.dying?torso-2:torso+2;
  if(hanging||q.dying){p(shirt,2,armY,2,6);p(skin,1,armY-1,3,2);p(shirt,12,armY,2,6);p(skin,12,armY-1,3,2);}
  else{p(shirt,2,torso+1,3,Math.max(2,feet-torso-3));p(skin,2,Math.min(feet-2,torso+4+(run&&phase===1?-2:0)),3,2);p(shirt,11,torso+1,2,4);p(skin,12,torso+(air?0:4),3,2);}
  if(q.dying){p(shirt,3,feet,4,2);p(shirt,10,feet,4,2);p(P.ink,9,head+5,3,1);}
  else if(air){p(overall,4,feet-1,3,3);p(shirt,2,feet+1,5,2);p(overall,10,feet-3,3,3);p(shirt,11,feet-1,4,2);}
  else if(hanging){p(overall,4,feet-2,3,3);p(overall,9,feet-2,3,3);p(shirt,3,feet+1,4,2);p(shirt,9,feet+1,4,2);}
  else if(run&&phase===0){p(overall,3,feet-2,4,3);p(shirt,1,feet+1,5,2);p(overall,9,feet-2,3,2);p(shirt,10,feet-1,4,2);}
  else if(run&&phase===2){p(overall,4,feet-2,3,2);p(shirt,3,feet-1,4,2);p(overall,9,feet-2,4,3);p(shirt,10,feet+1,5,2);}
  else{p(overall,4,feet-2,3,3);p(overall,9,feet-2,3,3);p(shirt,3,feet+1,5,2);p(shirt,9,feet+1,5,2);}
 });c.restore();return handled;
}
/** Tall rounded outline hills use open black interiors behind foreground. */
export function drawSmb3Scenery(c,q,room={}){
 if(isHeavyStoneArtRoom(room))return drawHeavyStoneScenery(c,q,room);
 if(!isSmb3ArtRoom(room)||!validRect(q))return false;
 const style=q.smm2Art,type=q.nativeScenery?.type;
 if(!['smb3-outline-hill','smb3-dark-spiral'].includes(style)&&!['HillLarge','HillSmall'].includes(type))return false;
 if(!visible(q))return true;
 return painter(c,q,Math.max(16,Math.round(q.w)),Math.max(16,Math.round(q.h)),p=>{
  const w=Math.max(16,Math.round(q.w)),h=Math.max(16,Math.round(q.h));
  if(style==='smb3-dark-spiral'){
   const cx=Math.floor(w/2),cy=Math.min(Math.floor(w/2),h-4),radius=Math.max(3,Math.floor(w/2)-1);
   for(let n=0;n<radius*16;n++){const t=n/(radius*16),a=t*Math.PI*4,r=radius*(1-t),x=Math.round(cx+Math.cos(a)*r),y=Math.round(cy+Math.sin(a)*r);p(P.blueDark,x,y);}
   p(P.blueDark,cx,cy+radius,1,h-cy-radius);return;
  }
  const radius=Math.floor((w-1)/2),cx=(w-1)/2;
  for(let y=0;y<Math.min(radius+1,h);y++){const dx=Math.sqrt(Math.max(0,radius*radius-(radius-y)*(radius-y))),l=Math.round(cx-dx),r=Math.round(cx+dx);p(P.white,l,y);p(P.white,r,y);if(y===0)p(P.white,l,0,Math.max(1,r-l+1));}
  p(P.white,0,radius,1,h-radius);p(P.white,w-1,radius,1,h-radius);
 });
}
/** Recognized private palette actors consume dispatch even when removed. */
export function drawSmb3Actor(c,q,tick=0,room={}){
 if(isHeavyStoneArtRoom(room)&&drawHeavyStoneActor(c,q,tick,room))return true;
 if(!isSmb3ArtRoom(room)||!q)return false;
 const placed=q.kind==='walker'&&!q.smm2PlacedItem?room.smm2Mechanics.placedItems?.find(item=>item.id===q.id):null;
 if(placed&&['life','mushroom','star'].includes(placed.kind))return drawSmb3Actor(c,{...q,kind:placed.kind},tick,room);
 const variant=room.marioModules?.enemyVariants?.[q.id],type=q.smm2EnemyKind??q.type??variant?.kind??q.skin??q.kind;
 if(q.kind==='enemy-death'&&['muncher','study-muncher','study-piranha','floor-piranha','fire-piranha','pipe-piranha','piranha','koopa','vertical-koopa','hopping-koopa'].includes(type)){
  if(q.hidden||q.visible===false||q.removed||q.life<=0||!validRect(q))return true;
  c.save();if(!q.flat){c.translate(0,Math.round(2*q.y+q.h));c.scale(1,-1);}drawSmb3Actor(c,{...q,kind:'walker',dead:false},tick,room);c.restore();return true;
 }
 let fn;
 if(['mushroom','life'].includes(q.kind))fn=()=>drawSmb3Mushroom(c,q,{life:q.kind==='life'});
 else if(q.kind==='flower')fn=()=>flower(c,q);
 else if(q.kind==='star')fn=()=>star(c,q,tick);
 else if(q.kind==='coin'||q.kind==='coin-pop')fn=()=>coin(c,{...q,value:q.value??room.marioModules?.coinValues?.[q.id]},tick);
 else if(q.kind==='checkpoint')fn=()=>drawSmb3Checkpoint(c,q,tick);
 else if(q.kind==='exit'&&(room.smm2Mechanics.goalCard?.id===(q.sourceId||q.id)||['smb3-card-goal','card-goal'].includes(q.smm2Art??q.style))){
  const card=room.smm2Mechanics.goalCard,cycle=card?.cycle??['mushroom','flower','star','life'],current=room.finish?.card?room.finish.result:room.goalCardView?.current??cycle[Math.floor(tick/(card?.framesPerCard??8))%cycle.length];
  fn=()=>drawSmb3Goal(c,{...q,cardState:current},tick);
 }
 else if(['muncher','study-muncher'].includes(type))fn=()=>drawSmb3Muncher(c,q,tick);
 else if(['study-piranha','floor-piranha','fire-piranha','pipe-piranha','piranha'].includes(type)||q.source?.studyFloorPlant)fn=()=>drawSmb3Piranha(c,q,tick);
 else if(['koopa','vertical-koopa','hopping-koopa','Koopa'].includes(type))fn=()=>koopa(c,q,tick);
 else if(q.smm2Platform==='blue-falling'||q.smm2Art==='smb3-blue-fall-lift'||q.type==='smb3-blue-fall-lift')fn=()=>drawSmb3BluePlatform(c,q);
 else if(q.smm2Art==='smb3-right-oneway'||q.type==='smb3-one-way-wall')fn=()=>drawSmb3OneWayWall(c,q);
 else if(q.kind==='spawn'){return drawSmb3Player(c,{...q,grounded:true,power:0,facing:1},tick,room);}
 if(!fn)return false;if(!visible(q)||q.life<=0)return true;
 const clipTop=q.emerge?q.blockTop:q.clipTop;
 if(Number.isFinite(clipTop)&&validRect(q)){c.save();c.beginPath();c.rect(q.x-16,q.y-32,q.w+32,Math.max(0,clipTop-q.y+32));c.clip();fn();c.restore();}else fn();
 return true;
}
export function drawSmb3World(c,room={},view={},tick=0){
 if(isHeavyStoneArtRoom(room))return drawHeavyStoneWorld(c,room,view,tick);
 if(!isSmb3ArtRoom(room))return false;
 const smm2=view.smm2Mechanics??view;let handled=false;
 for(const q of smm2.surfaces||[])if(q.kind==='slope'){handled=drawSmb3Slope(c,q)||handled;}
 const modules=view.marioModules??room.marioModulesView??room.marioModules;
 for(const q of modules?.oneWayWalls||[])handled=drawSmb3OneWayWall(c,q)||handled;
 return handled;
}
