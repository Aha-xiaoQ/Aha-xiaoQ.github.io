/** Door-feature signage. Only explicitly tagged decoration pixels are drawn.
 * Cabinet/snake/flight-pack signs are original author artwork; the red shell
 * uses the unchanged verified catalogue frame and Jr uses the existing streamed
 * frame reconstruction. No actors, terrain, progression or rewards are created.
 */
import {WALKING_KOOPA_SOURCE_ASSETS} from './editor-walking-koopa-art.mjs';
import {BOWSER_JR_PIXELS} from './editor-bowser-jr-pixels.mjs';
import {spritePixels} from './classic-art.mjs';
export const DOOR_FEATURE_ICON_SIZE=24;
export const DOOR_FEATURE_KINDS=Object.freeze(['crane','snake','shell','shooter','jr']);
const kinds=new Set(DOOR_FEATURE_KINDS),prefix='authored-door-feature-';
const plain=q=>q&&typeof q==='object'&&!Array.isArray(q)&&[Object.prototype,null].includes(Object.getPrototypeOf(q));
const finite=Number.isFinite;
const rgba=q=>typeof q==='string'?q:`rgba(${q[0]},${q[1]},${q[2]},${(q[3]??255)/255})`;
function indexed(c,im,x,y){for(let row=0;row<im.h;row++)for(let col=0;col<im.w;col++){const at=parseInt(im.rows[row][col],36),color=im.palette[at];if(at&&color&&color!=='transparent'&&(!Array.isArray(color)||color[3])){c.fillStyle=rgba(color);c.fillRect(x+col,y+row,1,1);}}}
function source(c,im,x,y){for(let row=0;row<im.h;row++)for(let col=0;col<im.w;col++){const color=im.pixels[row*im.w+col];if(color[3]){c.fillStyle=rgba(color);c.fillRect(x+col,y+row,1,1);}}}
function rect(c,color,x,y,w,h){c.fillStyle=color;c.fillRect(x,y,w,h);}
function plate(c){
 rect(c,'#122b43',4,0,16,24);rect(c,'#122b43',1,3,22,18);rect(c,'#122b43',0,7,24,10);
 rect(c,'#dbeaf4',5,1,14,1);rect(c,'#8babbb',5,22,14,1);rect(c,'#8babbb',1,7,1,10);rect(c,'#dbeaf4',22,7,1,10);
}
function crane(c){
 rect(c,'#e3aa43',4,3,16,18);rect(c,'#ffda88',5,3,14,1);rect(c,'#a86e27',4,20,16,1);
 rect(c,'#123b52',6,5,12,12);rect(c,'#5ac9db',6,5,1,12);rect(c,'#a8edf2',7,5,10,1);
 rect(c,'#b6cbd1',8,7,8,1);rect(c,'#edf8f2',11,8,2,3);
 rect(c,'#b6cbd1',9,11,1,3);rect(c,'#b6cbd1',14,11,1,3);rect(c,'#edf8f2',10,14,1,1);rect(c,'#edf8f2',13,14,1,1);
 rect(c,'#efb7d8',11,15,2,2);rect(c,'#9c671d',6,18,7,2);rect(c,'#eef5e5',15,18,2,2);
}
function snake(c){
 for(const [x,y]of [[3,15],[9,15],[9,9],[15,9]]){rect(c,'#113e1a',x,y,6,6);rect(c,'#25b423',x+1,y+1,4,4);rect(c,'#ace25a',x+1,y+1,4,1);}
 rect(c,'#ffffff',16,10,2,2);rect(c,'#ffffff',19,10,2,2);rect(c,'#122b43',17,11,1,1);rect(c,'#122b43',20,11,1,1);
 rect(c,'#f1dc62',20,14,2,1);
}
function flight(c){
 rect(c,'#aebfc5',1,13,4,3);rect(c,'#aebfc5',19,13,4,3);rect(c,'#f3f9ed',1,13,4,1);rect(c,'#f3f9ed',19,13,4,1);
 rect(c,'#36c4fb',2,17,2,3);rect(c,'#36c4fb',20,17,2,3);rect(c,'#b8c7cc',7,3,10,1);rect(c,'#ffffff',11,4,2,2);
 source(c,spritePixels('goomba'),4,6);
}
export function doorFeatureKind(q){return q?.material==='decoration'&&typeof q.smm2Art==='string'&&q.smm2Art.startsWith(prefix)&&kinds.has(q.smm2Art.slice(prefix.length))?q.smm2Art.slice(prefix.length):null;}
export function drawDoorFeatureIcon(c,q){
 const kind=doorFeatureKind(q);if(!kind)return false;
 if(q.hidden||q.visible===false)return true;
 if(![q.x,q.y].every(finite)||q.w!==24||q.h!==24)throw new TypeError('Door feature icon requires its exact24px native frame');
 const priorFill=c.fillStyle;c.save();c.imageSmoothingEnabled=false;c.translate(Math.round(q.x),Math.round(q.y));plate(c);
 if(kind==='crane')crane(c);else if(kind==='snake')snake(c);else if(kind==='shell')indexed(c,WALKING_KOOPA_SOURCE_ASSETS.redShell,4,5);else if(kind==='shooter')flight(c);else indexed(c,BOWSER_JR_PIXELS['walk-open'],1,1);
 c.restore();c.fillStyle=priorFill;return true;
}
/** Author helper. Recompute after moving doors; coordinates are normal saved
 * decoration data, not a hidden live association or a progression rule. */
export function makeDoorFeatureIcon(room,request){
 if(!plain(request)||Reflect.ownKeys(request).length!==3||!['id','portalId','feature'].every(k=>Object.hasOwn(request,k)))throw new TypeError('Door feature request needs id,portalId,feature');
 const {id,portalId,feature}=request;
 if(!plain(room)||!plain(room.map)||!Array.isArray(room.map.objects)||!kinds.has(feature)||typeof id!=='string'||['constructor','prototype','__proto__'].includes(id)||!/^[a-z][a-z0-9-]*$/.test(id))throw new TypeError('Invalid door feature author request');
 const portal=room.map.objects.find(q=>q.id===portalId&&q.kind==='portal');if(!portal||![portal.x,portal.y,portal.w,portal.h].every(finite)||portal.w<=0||portal.h<=0)throw new TypeError('Door feature needs a real authored portal');
 const q={id,x:Math.round(portal.x+portal.w/2-12),y:Math.round(portal.y-50),w:24,h:24,material:'decoration',smm2Art:prefix+feature};
 if(q.x<0||q.y<0||q.x+24>room.map.width||q.y+24>room.map.height)throw new RangeError('Door feature must fit above its actual portal');return q;
}
export const DOOR_FEATURE_ART_PROVENANCE=Object.freeze({crane:'original author pictogram',snake:'original segmented author pictogram',shell:'unchanged SMB1 red-shell catalogue pixels',shooter:'unchanged native Goomba pixels with original compact author flight pack',jr:'existing observed-gameplay Jr pixel reconstruction, not source rip',purpose:'display-only signs; no NPC or collision bodies'});

/** Parse/export boundary for the named display-only style family. Unrelated
 * decoration styles remain untouched; unknown family variants cannot silently
 * render a generic rectangle or acquire terrain behavior. */
export function validateDoorFeatureIcons(room){
 for(const q of room?.decorations||[]){
  if(typeof q.smm2Art!=='string'||!q.smm2Art.startsWith(prefix))continue;
  if(!doorFeatureKind(q)||q.w!==24||q.h!==24||![q.x,q.y].every(finite)||q.x<0||q.y<0||q.x+24>room.map.width||q.y+24>room.map.height||q.collision!==undefined||q.motion!==undefined||q.nativeScenery!==undefined)throw new TypeError('Invalid display-only door feature icon');
 }
 return true;
}
