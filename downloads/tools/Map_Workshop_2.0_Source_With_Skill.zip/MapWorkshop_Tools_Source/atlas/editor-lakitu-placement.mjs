/** Pure initial Cloud-seat author check. Empty clouds need no support. Sprite
 * overhang is visual, never an invented runtime collision face or armor.
 * The default small native passenger is 10×14; runtime checks its actual body
 * on every boarding attempt. Dynamic/state terrain remains authorable. */
import {geometryPlacementType,placementOverlap,polygonPlacementOverlap} from './editor-placement.mjs';
import {createSMM2Terrain} from './editor-smm2-terrain.mjs';

export function validateLakituCloudPlacement(room,options={}){
 const clouds=room.smm2Mechanics?.lakituClouds?.clouds||[];if(!clouds.length)return;
 const solids=(room.map.geometry||[]).filter(q=>geometryPlacementType(room,q,options).permanent);
 const slopes=room.smm2Mechanics?.slopes?.length?createSMM2Terrain(room).surfaces().filter(q=>q.kind==='slope'):[];
 for(const cloud of clouds){
  const seat={x:cloud.x+(cloud.w-10)/2,y:cloud.y+cloud.seatOffsetY,w:10,h:14};
  if(seat.x<0||seat.y<0||seat.x+seat.w>room.map.width||seat.y+seat.h>room.map.height)throw Error('Lakitu Cloud initial native seat is outside the room');
  for(const solid of solids)if(placementOverlap(seat,solid))throw Error('Lakitu Cloud initial native seat overlaps permanent solid '+solid.id);
  for(const slope of slopes)if(polygonPlacementOverlap(seat,slope.polygon))throw Error('Lakitu Cloud initial native seat overlaps permanent slope '+slope.id);
 }
}
