/** Shared desktop-input adapters. These only translate input, never grant gear. */
export function createDirectionalInput(){
 let sequence=0;const sources=new Map();
 return {
  update(source,{x=0,y=0}={},intent=false){const prior=sources.get(source)||{x:0,y:0,rx:0,ry:0},next={...prior};for(const axis of ['x','y']){const value=Math.sign(Number(axis==='x'?x:y)||0);if(value&&(intent||value!==prior[axis]))next['r'+axis]=++sequence;next[axis]=value;}sources.set(source,next);},
  read(){const out={x:0,y:0};for(const axis of ['x','y']){let rank=-1;for(const state of sources.values())if(state[axis]&&state['r'+axis]>rank){out[axis]=state[axis];rank=state['r'+axis];}}return out;},
  clear(){sources.clear();sequence=0;}
 };
}
/** Canvas-only mouse actions. Mouse events support button chords (PointerEvent
 * pointerdown alone only reports the first pressed mouse button). A global up,
 * lost-buttons move, canvas leave/cancel, blur or explicit suspend releases all.
 * A fresh click is required after suspension; menu/UI clicks are never consumed.
 */
export function createCanvasMouseInput(canvas,{host=globalThis.window,enabled=()=>true,onActivity=()=>{}}={}){
 const held=new Set(),blocked=new Set();let pulse=false,disposed=false,pointerType='mouse';
 const mask=button=>button===0?1:button===2?2:0;
 const pointer=event=>{pointerType=event.pointerType||'mouse';if(pointerType!=='mouse')suspend();};
 const down=event=>{if(event.target!==canvas||!mask(event.button)||pointerType!=='mouse'||event.sourceCapabilities?.firesTouchEvents)return;if(!enabled()||disposed){blocked.add(event.button);return;}if(blocked.has(event.button))return;event.preventDefault();canvas.focus();onActivity();if(event.button===0&&!held.has(0))pulse=true;held.add(event.button);};
 const up=event=>{held.delete(event.button);blocked.delete(event.button);};
 const move=event=>{if(!Number.isFinite(event.buttons))return;for(const button of [0,2])if(!(event.buttons&mask(button))){held.delete(button);blocked.delete(button);}};
 const suspend=()=>{for(const button of held)blocked.add(button);held.clear();pulse=false;};
 const menu=event=>{if(event.target===canvas&&enabled()&&!disposed)event.preventDefault();};
 const registrations=[[canvas,'pointerdown',pointer],[canvas,'mousedown',down],[host,'mouseup',up],[host,'mousemove',move],[canvas,'mouseleave',suspend],[canvas,'pointercancel',suspend],[canvas,'lostpointercapture',suspend],[canvas,'contextmenu',menu],[host,'blur',suspend]];
 for(const [target,type,listener]of registrations)target.addEventListener(type,listener);
 return {read:()=>({attack:held.has(0)||pulse,shield:held.has(2)}),consume(){pulse=false;},suspend,destroy(){disposed=true;suspend();for(const [target,type,listener]of registrations)target.removeEventListener(type,listener);}};
}
