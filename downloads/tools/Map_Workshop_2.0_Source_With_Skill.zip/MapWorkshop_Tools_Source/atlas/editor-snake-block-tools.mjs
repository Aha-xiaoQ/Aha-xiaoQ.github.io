/** Shared native authoring for the formal Snake Block room leaf. All motion
 * and collapse coefficients are explicitly saved author values. There is no
 * dependency on the independent 2019 preview or on a specific course. */
import {uid, validate, moveSelection} from './editor-model.mjs';
import {validateSmm2SnakeBlocksRoom} from './editor-snake-blocks.mjs';
import {initialSmm2SnakeBlockGeometry, validateSmm2SnakeBlockPlacement} from './editor-snake-block-placement.mjs';
export {initialSmm2SnakeBlockGeometry, validateSmm2SnakeBlockPlacement, smm2SnakeBlockPlacementIssues} from './editor-snake-block-placement.mjs';

const numericFields = ['lengthCells', 'speedPxPerTick', 'initialHeadDistancePx', 'endpointHoldFrames', 'collapseIntervalFrames', 'collapseGravity', 'collapseFallCap'];
const configFields = ['color', 'origin', 'path', 'lengthCells', 'speedPxPerTick', 'initialHeadDistancePx', 'activation', 'endpointHoldFrames', 'collapseIntervalFrames', 'collapseGravity', 'collapseFallCap', 'collapseOrder'];
const plain = value => value && typeof value === 'object' && !Array.isArray(value) && [Object.prototype, null].includes(Object.getPrototypeOf(value));
const trains = room => room.smm2Mechanics?.snakeBlocks?.trains || [];
function fields(value, allowed, label) {
  if (!plain(value)) throw new TypeError('Invalid ' + label);
  for (const key of Reflect.ownKeys(value)) if (typeof key !== 'string' || ['__proto__', 'constructor', 'prototype'].includes(key) || !allowed.includes(key)) throw new TypeError('Unknown ' + label + ' field: ' + String(key));
  for (const key of allowed) if (!Object.hasOwn(value, key)) throw new TypeError('Missing ' + label + ' field: ' + key);
}
function array(value, min, max, label) {
  if (!Array.isArray(value) || value.length < min || value.length > max) throw new TypeError('Invalid ' + label);
  for (const key of Reflect.ownKeys(value)) if (key !== 'length' && (typeof key !== 'string' || !/^(0|[1-9][0-9]*)$/.test(key) || Number(key) >= value.length)) throw new TypeError('Unknown ' + label + ' field: ' + String(key));
  for (let i = 0; i < value.length; i++) if (!Object.hasOwn(value, i)) throw new TypeError('Missing ' + label + ' entry');
}
function config(value, withId = false) {
  fields(value, withId ? ['id', ...configFields] : configFields, 'Snake Block authoring');
  fields(value.origin, ['x', 'y'], 'Snake Block origin');
  array(value.path, 2, 1024, 'Snake Block path');
  for (const point of value.path) fields(point, ['id', 'x', 'y'], 'Snake Block waypoint');
}
function strictLeaf(room) {
  const value = room.smm2Mechanics?.snakeBlocks;
  if (value === undefined) return;
  fields(value, ['version', 'trains'], 'Snake Blocks authoring leaf');
  array(value.trains, 0, 256, 'Snake Blocks authoring train list');
  for (const q of value.trains) config(q, true);
}
function allIds(room) {
  const ids = new Set(), visited = new WeakSet();
  function walk(value) {
    if (!value || typeof value !== 'object' || visited.has(value)) return;
    visited.add(value);
    if (typeof value.id === 'string') ids.add(value.id);
    for (const child of Object.values(value)) walk(child);
  }
  walk(room);
  return ids;
}
function freshId(ids) {let id; do {id = uid();} while (ids.has(id)); ids.add(id); return id;}
function leaf(room) {room.smm2Mechanics ??= {version: 1}; return room.smm2Mechanics.snakeBlocks ??= {version: 1, trains: []};}
function clean(room) {if (room.smm2Mechanics?.snakeBlocks && !room.smm2Mechanics.snakeBlocks.trains.length) delete room.smm2Mechanics.snakeBlocks;}
function edit(room, operation) {
  strictLeaf(room);
  const next = structuredClone(room), result = operation(next);
  strictLeaf(next);
  validateSmm2SnakeBlocksRoom(next);
  validateSmm2SnakeBlockPlacement(next);
  validate({format: 'xiaoq-map-project', version: 1, id: 'snake-block-authoring-check', title: 'Snake Block authoring', rooms: [next]},{allowIncompleteCompletionMarks:true});
  for (const key of Object.keys(room)) if (!Object.hasOwn(next, key)) delete room[key];
  Object.assign(room, next);
  return result;
}

/** Complete replace/add; missing coefficients never receive runtime defaults. */
export function setSmm2SnakeBlockTrain(room, id, options) {
  config(options);
  return edit(room, r => {
    const list = leaf(r).trains, index = list.findIndex(q => q.id === id);
    const other = structuredClone(r);
    if (index >= 0) other.smm2Mechanics.snakeBlocks.trains.splice(index, 1);
    if (allIds(other).has(id)) throw new Error('Snake Block train needs an unused component ID');
    const value = {id, ...structuredClone(options)};
    if (index < 0) list.push(value); else list[index] = value;
    return id;
  });
}

export function removeSmm2SnakeBlockTrain(room, id) {
  if (!trains(room).some(q => q.id === id)) return false;
  return edit(room, r => {r.smm2Mechanics.snakeBlocks.trains = trains(r).filter(q => q.id !== id); clean(r); return true;});
}

/** Saved configuration is copied, with new train and waypoint IDs. */
export function cloneSmm2SnakeBlockTrain(room, sourceId, newId, origin) {
  fields(origin, ['x', 'y'], 'Snake Block clone origin');
  strictLeaf(room);
  validateSmm2SnakeBlocksRoom(room);
  const source = trains(room).find(q => q.id === sourceId);
  if (!source || allIds(room).has(newId)) throw new Error('Select an existing Snake Block train and an unused clone ID');
  const ids = allIds(room); ids.add(newId);
  const {id, ...options} = structuredClone(source);
  return setSmm2SnakeBlockTrain(room, newId, {...options, origin: structuredClone(origin), path: options.path.map(q => ({...q, id: freshId(ids)}))});
}

export function moveSmm2SnakeBlockTrains(room, ids, dx, dy) {
  if (!(ids instanceof Set) || !Number.isFinite(dx) || !Number.isFinite(dy)) throw new TypeError('Invalid Snake Block selection or translation');
  if (!trains(room).some(q => ids.has(q.id))) return false;
  return edit(room, r => {for (const q of trains(r)) if (ids.has(q.id)) {q.origin.x += dx; q.origin.y += dy;} return true;});
}

/** Translate a mixed native/train selection as one complete authoring edit.
 * Native movement sees the unselected trains; the selected trains are restored
 * at their translated origins before the final shared layout validation. */
export function moveSmm2SnakeBlockSelection(room, layer, ids, dx, dy) {
  if (!['geometry', 'objects', 'decoration'].includes(layer) || !(ids instanceof Set) || !Number.isFinite(dx) || !Number.isFinite(dy)) throw new TypeError('Invalid Snake Block mixed selection or translation');
  return edit(room, r => {
    const original = trains(r), selected = original.filter(q => ids.has(q.id));
    if (selected.length) r.smm2Mechanics.snakeBlocks.trains = original.filter(q => !ids.has(q.id));
    moveSelection(r, layer, ids, dx, dy);
    for (const q of selected) {q.origin.x += dx; q.origin.y += dy;}
    if (selected.length) r.smm2Mechanics.snakeBlocks.trains = original;
    return true;
  });
}

export function captureSmm2SnakeBlockTrains(room, ids) {
  if (!(ids instanceof Set)) throw new TypeError('Invalid selected Snake Block train IDs');
  strictLeaf(room);
  validateSmm2SnakeBlocksRoom(room);
  return structuredClone(trains(room).filter(q => ids.has(q.id)));
}

/** One transaction also supports cross-room paste. Relative waypoints stay put. */
export function appendCopiedSmm2SnakeBlockTrains(room, snapshot, translation) {
  fields(translation, ['dx', 'dy'], 'Snake Block clipboard translation');
  array(snapshot, 0, 256, 'Snake Block clipboard');
  if (!Number.isFinite(translation.dx) || !Number.isFinite(translation.dy)) throw new TypeError('Invalid Snake Block clipboard translation');
  const seen = new Set();
  for (const q of snapshot) {config(q, true); if (seen.has(q.id)) throw new TypeError('Duplicate Snake Block clipboard train ID'); seen.add(q.id);}
  if (!snapshot.length) return new Map();
  // Validate source semantics before remapping identifiers can erase mistakes.
  // The envelope uses the controller's public host bounds; target room bounds
  // are independently checked after the requested translation is applied.
  validateSmm2SnakeBlocksRoom({map: {width: 32768, height: 4096, geometry: [], objects: []}, smm2Mechanics: {version: 1, snakeBlocks: {version: 1, trains: snapshot}}});
  return edit(room, r => {
    const ids = allIds(r), mapping = new Map();
    // Reserve source identifiers even for cross-room copying.
    for (const q of snapshot) {ids.add(q.id); for (const p of q.path) ids.add(p.id);}
    for (const q of snapshot) {
      const id = freshId(ids); mapping.set(q.id, id);
      leaf(r).trains.push({...structuredClone(q), id, origin: {x: q.origin.x + translation.dx, y: q.origin.y + translation.dy}, path: q.path.map(p => ({...p, id: freshId(ids)}))});
    }
    return mapping;
  });
}

const numericInputs = [
  ['lengthCells', '节长（格）'], ['speedPxPerTick', '速度（像素 / 60Hz 帧）'], ['initialHeadDistancePx', '初始前沿路径距离（像素）'],
  ['endpointHoldFrames', '终点静止时长（帧）'], ['collapseIntervalFrames', '逐格变暗 / 下落间隔（帧）'], ['collapseGravity', '坠落重力'], ['collapseFallCap', '坠落速度上限']
];
const numberInput = ([key, label]) => '<label>' + label + '<input type="number" step="any" data-snake-block-tool="' + key + '"></label>';

/** Shared details-panel convention. Visible neutral seeds are author fits;
 * applying always reads every numeric field and the complete waypoint JSON. */
export function mountSmm2SnakeBlockTools({parent, room, selected = () => new Set(), select = () => {}, change, report = () => {}}) {
  const dom = parent.ownerDocument || document, panel = dom.createElement('details'); panel.id = 'snake-block-tools'; parent.append(panel);
  panel.innerHTML = '<summary>正式 Snake Blocks 蛇块</summary><p class="small">数值是显式作者配置，未认定为原作精确物理。原点为第一路径格左上角；路径是相对原点的 16px 正交坐标。新建表单显示中性作者数值；完整列车配置随地图工程一起保存。</p>' +
    '<label>已有蛇块列车<select data-snake-block-tool="train"></select></label><button type="button" data-snake-block-tool="new">填写新蛇块</button>' +
    '<label>列车稳定 ID<input type="text" data-snake-block-tool="id"></label><label>颜色<select data-snake-block-tool="color"><option value="green">Green 绿</option><option value="blue">Blue 蓝</option></select></label>' +
    numberInput(['origin-x', '第一路径格左上角 X']) + numberInput(['origin-y', '第一路径格左上角 Y']) + numericInputs.map(numberInput).join('') +
    '<label>启动条件<input type="text" data-snake-block-tool="activation"></label><label>坠落次序<select data-snake-block-tool="collapseOrder"><option value="tail-to-head">尾到头</option><option value="head-to-tail">头到尾</option></select></label>' +
    '<label>完整路径 JSON（各点 id、x、y；首点 0,0）<textarea rows="8" data-snake-block-tool="path"></textarea></label><button type="button" data-snake-block-tool="apply">放置 / 更新完整蛇块</button><button type="button" data-snake-block-tool="remove">删除所选蛇块</button>' +
    '<label>复制列车的新 ID<input type="text" data-snake-block-tool="clone-id"></label>' + numberInput(['clone-x', '复制原点 X']) + numberInput(['clone-y', '复制原点 Y']) +
    '<button type="button" data-snake-block-tool="clone">复制已保存列车配置</button><p class="small" data-snake-block-tool="status"></p>';
  const get = key => panel.querySelector('[data-snake-block-tool="' + key + '"]');
  get('path').style.cssText = 'width:100%;box-sizing:border-box;font:12px/1.5 ui-monospace,monospace;color:inherit;background:var(--bg);border:1px solid var(--line);padding:8px;resize:vertical'; get('path').spellcheck = false;
  const number = key => {const raw = String(get(key).value).trim(); if (!raw) throw new Error('请填写作者参数 ' + key); const value = Number(raw); if (!Number.isFinite(value)) throw new Error('作者参数必须是有限数值 ' + key); return value;};
  let current = '', newMode = true, lastRoom = null, lastSelection = '', loaded = '', error = '';
  const newId = () => freshId(allIds(room()));
  function populate(value) {
    get('id').value = value.id; get('color').value = value.color; get('origin-x').value = String(value.origin.x); get('origin-y').value = String(value.origin.y);
    for (const key of numericFields) get(key).value = String(value[key]);
    get('activation').value = value.activation; get('activation').readOnly = true; get('collapseOrder').value = value.collapseOrder; get('path').value = JSON.stringify(value.path, null, 2);
    get('clone-id').value = newId(); get('clone-x').value = String(value.origin.x); get('clone-y').value = String(value.origin.y + 48);
  }
  function populateNew() {
    const r = room(), ids = allIds(r), origin = {x: Math.min(64, r.map.width - 96), y: Math.min(128, r.map.height - 16)}, distance = Math.min(256, Math.floor((r.map.width - 16 - origin.x) / 16) * 16);
    populate({id: freshId(ids), color: 'green', origin, path: [{id: freshId(ids), x: 0, y: 0}, {id: freshId(ids), x: distance, y: 0}], lengthCells: 6, speedPxPerTick: 1, initialHeadDistancePx: 80, activation: 'player-top', endpointHoldFrames: 3, collapseIntervalFrames: 9, collapseGravity: .35, collapseFallCap: 6, collapseOrder: 'tail-to-head'});
  }
  function attempt(operation, success = () => {}) {
    try {let result; change(() => {result = operation();}); success(result); error = ''; loaded = '';}
    catch (failure) {error = failure.message; report(error); loaded = '';}
    refresh();
  }
  get('new').onclick = () => {current = ''; newMode = true; loaded = ''; error = ''; populateNew(); refresh();};
  get('train').onchange = () => {current = get('train').value; newMode = !current; loaded = ''; error = ''; if (newMode) populateNew(); else select(new Set([current])); refresh();};
  get('apply').onclick = () => attempt(() => {
    const id = newMode ? get('id').value.trim() : current;
    if (newMode && trains(room()).some(q => q.id === id)) throw new Error('新蛇块需要未使用的 ID');
    return setSmm2SnakeBlockTrain(room(), id, {color: get('color').value, origin: {x: number('origin-x'), y: number('origin-y')}, path: JSON.parse(get('path').value), ...Object.fromEntries(numericFields.map(key => [key, number(key)])), activation: get('activation').value, collapseOrder: get('collapseOrder').value});
  }, id => {current = id; newMode = false; select(new Set([id]));});
  get('remove').onclick = () => attempt(() => removeSmm2SnakeBlockTrain(room(), current), () => {current = ''; newMode = true; select(new Set()); populateNew();});
  get('clone').onclick = () => attempt(() => cloneSmm2SnakeBlockTrain(room(), current, get('clone-id').value.trim(), {x: number('clone-x'), y: number('clone-y')}), id => {current = id; newMode = false; select(new Set([id]));});
  function refresh() {
    const r = room(), list = trains(r), ids = selected(), selection = [...ids].sort().join('|'), changedRoom = lastRoom !== r;
    if (selection !== lastSelection && ids.size === 1 && list.some(q => ids.has(q.id))) {current = [...ids][0]; newMode = false; loaded = '';}
    if (changedRoom) {if (!list.some(q => q.id === current)) {current = list[0]?.id || ''; newMode = !current;} loaded = '';}
    if (!newMode && !list.some(q => q.id === current)) {current = list[0]?.id || ''; newMode = !current; loaded = '';}
    const options = list.map(q => {const option = dom.createElement('option'); option.value = q.id; option.textContent = q.id; return option;}), blank = dom.createElement('option'); blank.value = ''; blank.textContent = '新蛇块'; get('train').replaceChildren(blank, ...options); get('train').value = newMode ? '' : current;
    const value = list.find(q => q.id === current), signature = value ? JSON.stringify(value) : 'new';
    if (loaded !== signature) {if (value && !newMode) populate(value); else if (!get('id').value || changedRoom) populateNew(); loaded = signature;}
    get('id').readOnly = !newMode; get('remove').disabled = get('clone').disabled = !value || newMode;
    get('status').textContent = error || (value && !newMode ? '已保存 ' + value.id + '；初始实体 ' + initialSmm2SnakeBlockGeometry(r).filter(q => q.trainId === value.id).length + ' 格。复制保留已保存参数并重建所有路径点 ID。' : '请核对并填写完整作者参数后放置。');
    lastRoom = r; lastSelection = selection;
  }
  refresh();
  return Object.freeze({panel, refresh});
}
