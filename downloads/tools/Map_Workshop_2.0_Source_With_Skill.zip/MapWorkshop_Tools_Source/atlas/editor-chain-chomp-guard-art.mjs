/** Original, authored workshop guard art. The observed cross-style gameplay
 * establishes a round biting head, distinct chain rings, and a timber post.
 * These pixels and poses are an SMB1-compatible adaptation, not Nintendo
 * sprite extraction, native SMB1 animation frames, or measured native timing.
 * This module only draws; the guard controller owns all motion and damage. */
export const CHAIN_CHOMP_GUARD_ART_STATUS='original-authored-pixel-adaptation';

const PALETTE=Object.freeze({
 '.':'#00000000',k:'#080810',b:'#171720',s:'#393943',h:'#71717b',
 w:'#fff8e8',g:'#c5c5c7',r:'#c63131',d:'#721818',p:'#f36352',
});
// One deliberately stepped silhouette, shared by the two mouth poses and
// the exported pixel-contact helper. The bounding rectangle is 32 by 32.
const SPANS=Object.freeze([
 [12,19],[9,22],[7,24],[6,25],[5,26],[4,27],[3,28],[2,29],
 [2,29],[1,30],[1,30],[1,30],[0,31],[0,31],[0,31],[0,31],
 [0,31],[0,31],[0,31],[0,31],[1,30],[1,30],[1,30],[2,29],
 [2,29],[3,28],[4,27],[5,26],[6,25],[7,24],[9,22],[12,19],
]);
function authoredHead(open){
 const grid=SPANS.map(([a,b],y)=>Array.from({length:32},(_,x)=>x<a||x>b?'.':x===a||x===b||y===0||y===31?'s':'k'));
 const pixel=(x,y,color)=>{if(y>=0&&y<32&&x>=0&&x<32&&grid[y][x]!=='.')grid[y][x]=color;};
 const block=(x,y,w,h,color)=>{for(let yy=y;yy<y+h;yy++)for(let xx=x;xx<x+w;xx++)pixel(xx,yy,color);};
 // Upper-left steel glint remains a small stepped patch, not a gradient.
 for(const [x,y,w]of [[10,1,10],[7,2,6],[5,3,4],[4,4,3],[3,5,2],[3,6,1],[2,7,1],[2,8,1]])block(x,y,w,1,'h');
 for(const [x,y,w]of [[8,3,7],[6,4,5],[5,5,4],[4,6,3],[4,7,2],[3,8,2]])block(x,y,w,1,'b');
 // A single bold eye keeps the bite silhouette legible at native scale.
 const eye=['..wwww..','.wwwwww.','wwwwwwww','wwwwwkkw','wwwwwkkw','wwwwwkkw','.wwwwkw.','..gggg..'];
 for(let y=0;y<eye.length;y++)for(let x=0;x<8;x++)if(eye[y][x]!=='.')pixel(17+x,6+y,eye[y][x]);
 if(open){
  // Red cavity and paired sawtooth jaws: each row is hand-authored pixels.
  const bite=[
   '...........wwwwww',
   '.......wwwwwwwwww',
   '...wwwwwwwwwwwwww',
   '.wwwwwwrwwrrwwrrw',
   'wwwrwrrrwwrrrwrrr',
   'wrrrwrrrrwrrrrrrr',
   'drrrrrrrrrrrrrrrr',
   'ddrrrrrrrrrrrrrrr',
   'dddrrrrrrrrrrrrrr',
   'ddddrrrrrrrrrrrrr',
   'dddddrrrwrrrrwrrr',
   'ddddwrrwwrrrwwrrw',
   '.wwwwwwwwwwwwwwww',
   '...wwwwwwwwwwwwww',
   '......ggggggggggg',
  ];
  for(let y=0;y<bite.length;y++)for(let x=0;x<bite[y].length;x++)if(bite[y][x]!=='.')pixel(15+x,14+y,bite[y][x]);
  block(21,23,5,1,'p');block(22,24,6,1,'p');
 }else{
  const jaw=[
   '...........wwwwww',
   '.......wwwwwwwwww',
   '....wwwwwwwwwwwww',
   '..wwwwkwwkwwkwwkw',
   '.wwkwwkwwkwwkwwkw',
   'wwkwwkwwkwwkwwkww',
   'wwwwwwwwwwwwwwwww',
   '.gggggggggggggggg',
  ];
  for(let y=0;y<jaw.length;y++)for(let x=0;x<jaw[y].length;x++)if(jaw[y][x]!=='.')pixel(15+x,17+y,jaw[y][x]);
 }
 return Object.freeze({w:32,h:32,palette:PALETTE,rows:Object.freeze(grid.map(row=>row.join('')))});
}
export const CHAIN_CHOMP_GUARD_HEAD_PIXELS=Object.freeze({closed:authoredHead(false),open:authoredHead(true)});
const HEAD_MASK=Object.freeze(SPANS.map(([a,b])=>'.'.repeat(a)+'1'.repeat(b-a+1)+'.'.repeat(31-b)));
export const CHAIN_CHOMP_GUARD_HEAD_MASK=Object.freeze({w:32,h:32,rows:HEAD_MASK});
const OPAQUE_RUNS=Object.freeze(SPANS.map(([x,right],y)=>Object.freeze({x,y,w:right-x+1,h:1})));
/** Relative native-32 horizontal runs. Every occupied pixel centre lies
 * within radius 16, so a circular broadphase encloses the visible mask. */
export function chainChompGuardOpaqueRects(actor){return OPAQUE_RUNS;}
export function chainChompGuardHeadFrame(actor){
 const state=actor?.chainChompGuard||{},open=typeof state.openMouth==='boolean'?state.openMouth:['windup','lunge'].includes(state.phase),frame=CHAIN_CHOMP_GUARD_HEAD_PIXELS[open?'open':'closed'];
 const direction=finite(state.direction,finite(actor?.facing,actor?.chainChompGuardRule?.direction||1));
 return direction<0?{...frame,rows:frame.rows.map(row=>Array.from(row).reverse().join(''))}:frame;
}

const finite=(n,fallback)=>Number.isFinite(n)?n:fallback;
function binding(actor,room){
 const id=actor?.sourceId||actor?.id;
 const records=room?.contraptionsView?.chainChompGuards||room?.contraptions?.chainChompGuards||room?.map?.contraptions?.chainChompGuards||[];
 const rule=actor?.chainChompGuardRule||records.find(q=>q.actorId===id);
 return rule||actor?.chainChompGuard?{rule:rule||{},state:actor?.chainChompGuard||{}}:null;
}
function headRect(actor,rule={}){
 const w=finite(actor?.w,32),h=finite(actor?.h,32);
 return {x:finite(actor?.x,finite(rule.rest?.x,w/2)-w/2),y:finite(actor?.y,finite(rule.rest?.y,h/2)-h/2),w,h};
}
/** True for an opaque head pixel at world coordinates. Chain and post are
 * visual only and deliberately absent from this contact mask. */
export function headOpaqueAt(actor,worldX,worldY){
 if(!actor||!Number.isFinite(worldX)||!Number.isFinite(worldY))return false;
 const q=headRect(actor,actor?.chainChompGuardRule),x=Math.floor((worldX-q.x)*32/q.w),y=Math.floor((worldY-q.y)*32/q.h);
 return q.w>0&&q.h>0&&x>=0&&x<32&&y>=0&&y<32&&HEAD_MASK[y][x]==='1';
}
export const chainChompGuardHeadOpaqueAt=headOpaqueAt;

function pixelRect(c,color,x,y,w=1,h=1){c.fillStyle=color;c.fillRect(Math.round(x),Math.round(y),w,h);}
function paintHead(c,actor,rule,state){
 const q=headRect(actor,rule),open=typeof state.openMouth==='boolean'?state.openMouth:['windup','lunge'].includes(state.phase),im=CHAIN_CHOMP_GUARD_HEAD_PIXELS[open?'open':'closed'];
 // The pixel cells translate at the actor's exact float position. The mask
 // helper and controller's moving horizontal runs use this same geometry;
 // only the decorative post/chain are projected onto the world pixel grid.
 const direction=finite(state.direction,finite(actor.facing,rule.direction||1))<0?-1:1,x=q.x,y=q.y,sx=q.w/32,sy=q.h/32;
 for(let yy=0;yy<32;yy++)for(let xx=0;xx<32;){const key=im.rows[yy][xx];let end=xx+1;while(end<32&&im.rows[yy][end]===key)end++;if(key!=='.'){c.fillStyle=PALETTE[key];c.fillRect(x+(direction<0?32-end:xx)*sx,y+yy*sy,(end-xx)*sx,sy);}xx=end;}
}
function paintPost(c,post){
 const x=Math.round(post.x),y=Math.round(post.y);
 pixelRect(c,'#392010',x+2,y+1,12,22);pixelRect(c,'#392010',x,y+3,16,18);
 pixelRect(c,'#8e4a20',x+2,y+3,12,20);pixelRect(c,'#c87b36',x+3,y+3,4,19);pixelRect(c,'#633018',x+11,y+4,3,19);
 pixelRect(c,'#f6b867',x+3,y,10,2);pixelRect(c,'#d58c44',x+1,y+2,14,2);pixelRect(c,'#7a3c1b',x+3,y+4,10,1);
 pixelRect(c,'#633018',x+5,y+7,1,7);pixelRect(c,'#f6b867',x+4,y+6,1,5);pixelRect(c,'#633018',x+8,y+13,1,7);
 pixelRect(c,'#e29b4b',x+9,y+7,1,5);pixelRect(c,'#b26629',x+2,y+21,11,2);pixelRect(c,'#392010',x+2,y+23,12,1);
}
// Rasterize the ring itself on the world pixel grid. Canvas paths/rotated
// vector strokes would lose the square-pixel character of the head and post.
function paintRing(c,p,tangent,index,radius){
 const angle=Math.atan2(tangent.y,tangent.x),cs=Math.cos(angle),sn=Math.sin(angle),rx=radius*(index%2?.76:1),ry=radius;
 const edge=Math.ceil(radius)+1,cx=Math.round(p.x),cy=Math.round(p.y),innerX=Math.max(.65,rx-1.25),innerY=Math.max(.65,ry-1.25);
 for(let y=-edge;y<=edge;y++)for(let x=-edge;x<=edge;x++){
  const u=x*cs+y*sn,v=-x*sn+y*cs,outer=u*u/(rx*rx)+v*v/(ry*ry),inside=u*u/(innerX*innerX)+v*v/(innerY*innerY);
  if(outer<=1&&inside>=1)pixelRect(c,y<=0?'#dedee1':'#8b8b96',cx+x,cy+y);
 }
}
function paintChain(c,actor,rule,state,anchor,post){
 const q=headRect(actor,rule),center={x:q.x+q.w/2,y:q.y+q.h/2},dx=center.x-anchor.x,dy=center.y-anchor.y,distance=Math.hypot(dx,dy),direction=state.direction<0?-1:1;
 const ux=distance>0?dx/distance:direction,uy=distance>0?dy/distance:0;
 const end={x:center.x-ux*q.w*.43,y:center.y-uy*q.h*.43},span=Math.hypot(end.x-anchor.x,end.y-anchor.y),leash=Math.max(24,finite(state.leashLength,finite(rule.leashLength,80)));
 const taut=distance>=leash-2,loose=Math.sqrt(Math.max(0,(leash-q.w*.43)**2-span**2));
 const floor=post.y+24-2,sag=taut?0:Math.max(0,Math.min(26,loose*.36,floor-Math.max(anchor.y,end.y)-3));
 const control={x:(anchor.x+end.x)/2,y:(anchor.y+end.y)/2+sag*2};
 const curve=t=>({x:(1-t)*(1-t)*anchor.x+2*(1-t)*t*control.x+t*t*end.x,y:(1-t)*(1-t)*anchor.y+2*(1-t)*t*control.y+t*t*end.y});
 // Equal arc-length spacing keeps the hollow links visibly separate in both
 // the slack curve and the fully extended straight chain.
 const samples=[{t:0,length:0,p:anchor}];let length=0,previous=anchor;
 for(let i=1;i<=32;i++){const t=i/32,p=curve(t);length+=Math.hypot(p.x-previous.x,p.y-previous.y);samples.push({t,length,p});previous=p;}
 const physicalCount=Math.max(3,Math.min(12,Math.round((leash-q.w*.43)/10)));
 // Slack links keep their native hollow size. The shortened visible arc
 // uses fewer separated rings; excess links bunch beside the fixed stake.
 const count=Math.max(1,Math.min(physicalCount,Math.floor(length/8))),spacing=length/count,radius=Math.max(2.4,Math.min(3.4,spacing*.38));
 if(!taut&&physicalCount>count){
  const side=ux<0?-1:1;
  paintRing(c,{x:anchor.x+side*3,y:anchor.y+4},{x:side,y:1},0,2.8);
  if(physicalCount-count>1)paintRing(c,{x:anchor.x+side*5,y:anchor.y+8},{x:side,y:1},1,2.8);
 }
 for(let i=0;i<count;i++){
  const target=length*(i+.5)/count;let j=1;while(j<samples.length-1&&samples[j].length<target)j++;
  const a=samples[j-1],b=samples[j],f=(target-a.length)/(b.length-a.length||1),t=a.t+(b.t-a.t)*f,p=curve(t),before=curve(Math.max(0,t-.015)),after=curve(Math.min(1,t+.015));
  paintRing(c,p,{x:after.x-before.x,y:after.y-before.y},i,radius);
 }
}
/** Draw the fixed post, tether and head for the same owned actor in the
 * editor, live game, offline player, and shared Canvas movie renderer.
 * Returns false only when there is no guard binding. */
export function drawChainChompGuard(c,actor,tick=0,room={}){
 if(!actor)return false;
 const owned=binding(actor,room);if(!owned)return false;
 const {rule,state}=owned,q=headRect(actor,rule),sourcePost=rule.post||{};
 const anchor={x:finite(state.anchor?.x,finite(sourcePost.anchorX,finite(sourcePost.x,q.x-40)+8)),y:finite(state.anchor?.y,finite(sourcePost.anchorY,finite(sourcePost.y,q.y+8)+7))};
 const post={x:finite(sourcePost.x,anchor.x-8),y:finite(sourcePost.y,anchor.y-7)};
 c.save();c.imageSmoothingEnabled=false;
 paintPost(c,post);
 if(actor.hidden||actor.visible===false||actor.removed||actor.dead){c.restore();return true;}
 paintChain(c,actor,rule,state,anchor,post);
 pixelRect(c,'#25252d',anchor.x-2,anchor.y-2,5,5);pixelRect(c,'#c5c5c7',anchor.x-1,anchor.y-1,3,3);pixelRect(c,'#55555e',anchor.x,anchor.y,1,1);
 paintHead(c,actor,rule,state);c.restore();return true;
}
