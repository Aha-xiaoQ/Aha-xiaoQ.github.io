import {drawDoorFeatureIcon} from './editor-door-feature-art.mjs';
import {isAuthoredSceneAccent,drawAuthoredSceneAccent} from './editor-authored-scene-accents.mjs';
import {drawSkyShooterWeapon} from './editor-sky-shooter-art.mjs';
import {drawBowserJuniorArenaBackdrop} from './editor-bowser-jr-art.mjs';
import {drawCoinCraneTile,drawCoinCraneBackdrop,drawCoinCraneObject} from './editor-coin-crane-art.mjs';
import {drawChainChompGuard} from './editor-chain-chomp-guard-art.mjs';
import {isLakituSkyRoom,drawLakituWorld,drawLakituActor,occupiedLakituCloud,drawLakituGoalMarker,drawLakituGoalHud,drawLakituSkyMountain} from './editor-lakitu-art.mjs';
import {isSmm2GhostArtRoom,drawSmm2GhostScenery} from './editor-smm2-ghost-art.mjs';
import {occupiedClownCar,drawClownCarPassenger} from './editor-clown-car-art.mjs';
import {drawSmm2ShoeRider,drawSmm2ShoeFrontRim} from './editor-smm2-shoe-art.mjs';
import {drawSmm2SourcePixels} from './editor-smm2-source-assets.mjs';
import {drawContraptionsBackground,drawContraptionsTile,drawContraptionsActor,drawContraptionsBackdrop,drawKey,drawKeyHud,drawNote} from './editor-contraptions-art.mjs';
import {drawCheckpoint,drawMarioModuleTile,drawMarioModuleActor} from './editor-study-module-art.mjs';
import {loadBill,drawBill,drawBillItem} from './editor-bill.mjs';
import {materialFor,enemySprite,terrainParts,markerParts,sourceType,castleParts,walkingKoopaActorForArt,contraptionNoteForArt} from './map-appearance.mjs';
import {classicSprite,classicDraw} from './classic-art.mjs';
import {drawStudyBackground,drawStudyTile,drawStudyScenery,drawStudyActor} from './editor-switch-art.mjs';
import {isNativeScenery,drawNativeScenery} from './editor-native-scenery.mjs';
import {drawSmm2Background,drawSmm2Tile,drawSmm2Actor,drawSmm2PlayerGear,drawSmm2PlayerFootwear,smm2PlayerFootwear,drawSmm2SnowScenery,drawSmm2SourceScenery,drawSmm2SourceCastle,drawSmm2CastleSnow,drawSmm2Pipe,drawSmm2PinkCoinHud,drawSmm2SourceArrow} from './editor-smm2-art.mjs';
import {drawSmm2SourceFirebar,smm2BoneShellVisualRect,smm2BoneShellPlayingDead} from './editor-smm2-bone-art.mjs';
import {isSmb3ArtRoom,drawSmb3Player,drawSmb3Scenery} from './editor-smb3-art.mjs';
import {drawAquaticCurrents} from './editor-aquatic-art.mjs';
import {drawSmm2WeightedSpring} from './editor-smm2-spring-art.mjs';
import {drawWalkingKoopa,drawConveyorSurface,drawNativeNoteBlock} from './editor-walking-koopa-art.mjs';
import {isSmwUnderwaterRoom,drawSmm2SnakeBlockTile,drawSmwUnderwaterBackground,drawSmwUnderwaterBackdrop,drawSmwUnderwaterTile,drawSmwUnderwaterObject,drawSmwUnderwaterPlayer,drawSmwUnderwaterGoalGate,drawSmwUnderwaterReference,drawSmwUnderwaterHudSprite} from './editor-smw-underwater-art.mjs';
const verifiedSmb1Room=room=>room?.smm2Mechanics?.version===1&&['smb1-castle-stone','smb1-snow','smb1-shoe-underworld','smb1-underground-source','smb1-overworld-source','smb1-ghost-source','smb1-sky-source'].includes(room.smm2Mechanics.art?.palette);
const desertNotes=room=>room?.contraptions?.scene==='desert'||room?.contraptionsView?.scene==='desert';

/** Foreground world pass: call after terrain and before NPCs. Authored editor
 * fallback preserves the same fixed caps at the initial switch state; live
 * surfaces supply exact current palette and integrated animation phase.
 */
export function drawConveyorWorld(c,room={}){
 const live=room.conveyorView?.surfaces;
 const on=room.switchStudyView?.on??room.switchStudy?.initialOn??true;
 const surfaces=live??(room.smm2Mechanics?.conveyors??[]).map(q=>({...q,colorState:on?'red':'blue',treadPhasePx:0,rollers:q.visual.rollerCenters.map(center=>({...center,phaseRadians:0}))}));
 let drawn=false;for(const surface of surfaces)drawn=drawConveyorSurface(c,surface)||drawn;return drawn;
}
/** Shared native-pixel renderer; provenance is recorded in CLASSIC_ART_NOTICE.txt. */
const images=new Map();
export function preloadArt(rooms){return Promise.all([...(rooms.some(r=>r.playHero==='bill')?[loadBill()]:[]),...rooms.flatMap(r=>[...Object.values(r.art||{}),...(r.playerSkin?[r.playerSkin]:[])]).map(src=>{
 if(!/^data:image\/png;base64,[A-Za-z0-9+/=]+$/.test(src)||src.length>700000)return Promise.reject(Error('素材须为小于 500 KB 的 PNG'));
 if(images.has(src))return images.get(src).ready;
 const image=new Image(),entry={image,ready:null};entry.ready=new Promise((resolve,reject)=>{image.onload=()=>{if(image.width!==image.height||image.width>256||image.width<16||image.width%16)reject(Error('地块图需为 16–256 像素正方形，边长为 16 的倍数'));else resolve();};image.onerror=()=>reject(Error('素材图片无法读取'));});images.set(src,entry);image.src=src;return entry.ready;
} )]);}
export function background(c,room,w,h){if(drawSmwUnderwaterBackground(c,room,w,h))return;if(isLakituSkyRoom(room)){c.fillStyle="#767ff7";c.fillRect(0,0,w,h);return;}if(drawSmm2Background(c,room,w,h))return;if(drawContraptionsBackground(c,room,w,h))return;if(drawStudyBackground(c,room,w,h))return;c.fillStyle=/Underwater/.test(room.setting||'')?'#5c94fc':/Underworld|Castle|Night/.test(room.setting||'')?'#000000':'#5c94fc';c.fillRect(0,0,w,h);}
export function drawParts(c,parts,room={}){for(const p of parts){const im=classicSprite(p.name),v=room.renderBounds||p;if(p.w<=0||p.h<=0)continue;c.save();c.beginPath();c.rect(p.x,p.y,p.w,p.h);c.clip();const left=p.x+Math.max(0,Math.floor((v.x-p.x)/im.width))*im.width,top=p.y+Math.max(0,Math.floor(((v.y??p.y)-p.y)/im.height))*im.height;for(let y=top;y<Math.min(p.y+p.h,(v.y??p.y)+(v.h??p.h));y+=im.height)for(let x=left;x<Math.min(p.x+p.w,v.x+v.w);x+=im.width)c.drawImage(im,x,y);c.restore();}}
/** Original pixel door, restricted to the explicit SMM2 final-door marker.
 * Closed red panels and the white opening follow the inspected last still;
 * the local pause/completion does not claim a watched auto-entry sequence. */
/** SMM2 end-door visual bounds have their own bottom/centre anchor. The
 * marker remains a non-colliding finish object; optional source doorArt keeps
 * imported authoring projects independent of a particular course. */
export function smm2CastleDoorVisual(o){
 const q=o.source?.doorArt??{},w=Number.isFinite(q.width)&&q.width>=16&&q.width<=64?q.width:24,h=Number.isFinite(q.height)&&q.height>=24&&q.height<=96?q.height:40;
 return{x:o.x+8-w/2+(Number.isFinite(q.offsetX)?q.offsetX:0),y:o.y+48-h+(Number.isFinite(q.offsetY)?q.offsetY:0),w,h};
}
export function drawSmm2CastleDoor(c,o,room){
 if(o.kind!=='smm2-castle-door'||room.castle?.finish?.variant!=='smm2-door'||room.castle.finish.doorId!==o.id)return false;
 const f=room.castleView?.finish||room.finish,open=f?.variant==='smm2-door'&&f.doorId===o.id&&f.doorOpen===true,q=smm2CastleDoorVisual(o),sx=q.w/24,sy=q.h/40;
 c.save();c.translate(Math.round(q.x),Math.round(q.y));c.scale(sx,sy);c.imageSmoothingEnabled=false;c.fillStyle='#101010';c.fillRect(0,0,24,40);
 if(open){c.fillStyle='#ffffff';c.fillRect(2,1,20,39);}else{
  c.fillStyle='#8c3110';c.fillRect(1,0,22,40);c.fillStyle='#f73910';c.fillRect(2,1,20,38);
  for(const [y,h]of [[4,8],[17,6],[28,8]]){c.fillStyle='#4c1608';c.fillRect(5,y-1,14,h+2);c.fillStyle='#ffb259';c.fillRect(5,y,14,h+1);c.fillStyle='#c62a08';c.fillRect(6,y,12,h);}
  for(const x of [3,11,20])for(const y of [2,14,25,37]){c.fillStyle='#4c1608';c.fillRect(x,y,2,2);c.fillStyle='#ffb259';c.fillRect(x,y,1,1);}
  c.fillStyle='#101010';c.fillRect(21,19,1,2);
 }
 c.restore();return true;
}
export function drawReference(c,o,room){if(drawSmwUnderwaterReference(c,o,room))return true;if(isSmwUnderwaterRoom(room)){if((['smw-goal-gate','giant-gate'].includes(o.kind)||room.smm2Mechanics?.goalTape?.id===o.id)&&drawSmwUnderwaterGoalGate(c,o,room))return true;if(/^(?:flagpole|castle)-finish$/.test(o.kind))return true;}if(drawLakituGoalMarker(c,o,room))return true;if((room.aquatic?.version===1||room.smm2Mechanics?.version===1)&&o.kind==='source-arrow')return drawSmm2SourceArrow(c,o,room);const liquid=room.liquidView;if(liquid&&liquid.markerId===o.id)o={...o,y:liquid.y,h:liquid.bottom-liquid.y};if(drawSmm2CastleDoor(c,o,room))return true;if(drawSmm2SourceFirebar(c,o,room))return true;if(o.kind==='active-vine'){drawParts(c,[{name:'src|Character|Vine||middle',x:o.x,y:o.y,w:o.w,h:o.h}],room);return true;}if(['world-transport','source-transport-not-simulated'].includes(o.kind)){const world=String(o.source?.transport?.map||'').split('-')[0];if(/^[1-8]$/.test(world)){drawPixelText(c,world,o.x+12,o.y-24);return true;}}const parts=markerParts(room,o);if(o.kind==='rotating-firebar'){const quarter=Math.floor((room.tick||0)/3)%4;for(const part of parts){const im=classicSprite(part.name);c.save();c.translate(Math.round(part.x)+4,Math.round(part.y)+4);c.rotate(quarter*Math.PI/2);c.drawImage(im,-4,-4);c.restore();}return parts.length>0;}drawParts(c,parts,room);return parts.length>0;}
export function drawTile(c,q,room={},display={}){
 if(drawDoorFeatureIcon(c,q))return true;
 if(isAuthoredSceneAccent(q))return drawAuthoredSceneAccent(c,q,room,room.tick||0);
 if(q.smm2Art==='jr-grandstand')return;
 if(drawCoinCraneTile(c,q,room))return;
 if(drawSmm2SnakeBlockTile(c,q))return;
 if(drawSmwUnderwaterTile(c,q,room))return;
 if(display.sceneryDrawn&&isSmm2GhostArtRoom(room)&&['ghost-timber-backdrop','ghost-timber-beam'].includes(q.smm2Art??room.decorations?.find(d=>d.id===(q.sourceId||q.id))?.smm2Art))return;
 if(display.sceneryDrawn&&['smb1-overworld-source','smb1-sky-source'].includes(room.smm2Mechanics?.art?.palette)&&['source-scenery-hill','source-scenery-hill-edge','source-scenery-cloud','source-scenery-bush','source-scenery-round-plant','source-scenery-capsule-plant','source-scenery-plant-stem'].includes(q.smm2Art??room.decorations?.find(d=>d.id===(q.sourceId||q.id))?.smm2Art))return;
 if(display.sceneryDrawn&&isLakituSkyRoom(room)&&q.smm2Art?.startsWith("source-sky-mountain-"))return;
 if(q.spikeTrap)return; // Its visible hazard object draws this same physical tile once.
 if(!desertNotes(room)&&contraptionNoteForArt(room,q)){
  if(q.hidden||q.removed||q.visible===false)return;
  // The terrain pass already applies the live bump offset once.
  if(verifiedSmb1Room(room)&&drawNativeNoteBlock(c,{...q,bump:0}))return;
  drawNote(c,{...q,bump:0});return;
 }
 if(room.smm2Mechanics?.version===1&&(q.smm2Terrain||q.smm2ItemBody))return; // Live component/actor passes own this artwork.
 if(room.smm2Mechanics?.version===1){const platform=q.smm2Platform??room.map?.geometry?.find(g=>g.id===(q.sourceId||q.id))?.smm2Platform;if(platform&&drawSmm2Actor(c,{...q,smm2Platform:platform},room.tick||0,room))return;}
 if(drawSmm2WeightedSpring(c,q,room))return;
 if(drawSmm2Tile(c,q,room))return;
 if(drawSmm2Pipe(c,q,room))return;
 if(drawContraptionsTile(c,q,room))return;
 if(room.contraptions&&q.material==='pipe'&&room.marioModules?.enemySources?.some(s=>s.pipeId===(q.sourceId||q.id)&&s.direction==='down')){c.save();c.translate(0,2*q.y+q.h);c.scale(1,-1);drawParts(c,terrainParts(room,q),room);c.restore();return;}
 if(isNativeScenery(q))return; // Authored scene components are drawn once in drawScenery.
 if(!q.studyArt){const style=room.map?.geometry?.find(g=>g.id===(q.sourceId||q.id))?.studyArt;if(style)q={...q,studyArt:style};}
 if(drawMarioModuleTile(c,q,room))return;
 if(drawStudyTile(c,q,room))return;
 if(q.material==='cloud-solid'){drawParts(c,[{name:'src|Solid|Cloud|'+(room.setting||'')+'|',x:q.x,y:q.y,w:q.w,h:q.h}],room);return;}
 if(q.material==='used'){classicDraw(c,'src|Solid|Block|used|',q.x,q.y);return;}
 const mat=materialFor(room,q),image=images.get(room.art?.[mat])?.image;
 if(image?.complete&&image.naturalWidth){c.save();c.beginPath();c.rect(q.x,q.y,q.w,q.h);c.clip();for(let y=q.y;y<q.y+q.h;y+=16)for(let x=q.x;x<q.x+q.w;x+=16)c.drawImage(image,x,y,16,16);c.restore();return;}
 const parts=terrainParts(room,q);if(parts.length)drawParts(c,parts,room);else{c.fillStyle='#e251ac';c.fillRect(q.x,q.y,q.w,q.h);}
}
function drawBaseScenery(c,room){
 if(drawSmwUnderwaterBackdrop(c,room))return;
 if(isLakituSkyRoom(room)){for(const q of room.decorations||[])if(!drawLakituSkyMountain(c,q,room)&&!drawSmm2SourceScenery(c,q,room)&&isNativeScenery(q))drawNativeScenery(c,q,room);drawSmm2SourceCastle(c,castleParts(room),room);drawLakituWorld(c,room);return;}
 drawAquaticCurrents(c,room,room.tick??0);
 if(isSmm2GhostArtRoom(room)){for(const q of room.decorations||[])drawSmm2GhostScenery(c,q,room);drawParts(c,castleParts(room),room);return;}
 if(room.smm2Mechanics?.version===1&&['smb1-overworld-source','smb1-sky-source'].includes(room.smm2Mechanics.art?.palette)){
  for(const q of room.decorations||[])if(!drawSmm2SourceScenery(c,q,room)&&isNativeScenery(q))drawNativeScenery(c,q,room);
  drawSmm2SourceCastle(c,castleParts(room),room);return;
 }
 if(isSmb3ArtRoom(room)){
  for(const q of room.decorations||[])if(!drawSmb3Scenery(c,q,room)&&isNativeScenery(q))drawNativeScenery(c,q,room);
  return;
 }
 if(room.smm2Mechanics?.version===1&&room.smm2Mechanics.art?.palette==='smb1-snow'){
  for(const q of room.decorations||[])if(!drawSmm2SnowScenery(c,q,room)&&isNativeScenery(q))drawNativeScenery(c,q,room);
  const parts=castleParts(room);drawParts(c,parts,room);drawSmm2CastleSnow(c,parts,room);return;
 }
 if(room.contraptions){drawContraptionsBackdrop(c,room);if(room.smm2Mechanics?.version===1){for(const q of room.decorations||[])if(isNativeScenery(q))drawNativeScenery(c,q,room);for(const q of room.decorations||[])if(!q.hidden&&q.studyArt==='native-cloud')drawMarioModuleTile(c,q,room);}drawParts(c,castleParts(room),room);return;}
 for(const q of room.decorations||[])if(isNativeScenery(q))drawNativeScenery(c,q,room);
 for(const q of room.decorations||[])if(!q.hidden&&q.studyArt==='native-cloud')drawMarioModuleTile(c,q,room);
 if(drawStudyScenery(c,room)){drawParts(c,castleParts(room),room);return;}
 if(/\bSky\b/.test(room.setting||''))return; // Coin heaven uses its authored cloud floor, not ground scenery.
 if(/Underwater/.test(room.setting||'')&&!/Castle/.test(room.setting||'')){const v=room.renderBounds||{x:0,w:room.map?.width||256},name='src|Scenery|Water|Underwater|top';drawParts(c,[{name,x:Math.floor(v.x/8)*8,y:32,w:v.w+16,h:classicSprite(name).height}],room);}
 for(const q of room.map?.geometry||[])if(['TreeTop','ShroomTop'].includes(sourceType(room,q)))drawReference(c,{id:q.id+'-trunk',kind:'decorative-trunk',source:{macro:sourceType(room,q)==='ShroomTop'?'Shroom':'Tree'}},room);

 if(room.nativeSceneryMode==='authored'||/Under|Castle|Night/.test(room.setting||'')){drawParts(c,castleParts(room),room);return;}
 const trees=room.map?.geometry.some(q=>['TreeTop','ShroomTop'].includes(sourceType(room,q)));
 const v=room.renderBounds||{x:0,w:room.map?.width||256},floor=(room.map?.height||240)-32;
 for(let page=Math.floor(v.x/768)-1;page<=Math.floor((v.x+v.w)/768)+1;page++){
  const b=page*768;
  for(const [name,x,y] of [['hill_large',0,floor-35],['hill_small',256,floor-19],['hill_large',512,floor-35],['bush3',184,floor-16],['bush1',376,floor-16],['bush2',664,floor-16],['cloud1',136,48],['cloud1',312,64],['cloud2',440,48],['cloud2',568,64]]){if(trees&&/hill|bush/.test(name))continue;classicDraw(c,name,b+x,y);}
 }
 drawParts(c,castleParts(room),room);
}
export function drawScenery(c,room){drawBaseScenery(c,room);drawCoinCraneBackdrop(c,room);drawBowserJuniorArenaBackdrop(c,room);}
/** A pipe supply is clipped at its declared mouth while it emerges. */
export function drawObject(c,o,tick=0,room={},display={}){
 if(o.kind!=='enemy-death'&&room.smm2Mechanics?.skyShooter?.drones.some(q=>q.id===o.id))return;
 if(!display.seated){const car=occupiedClownCar(room.contraptionsView?.cars,o);if(car)return drawClownCarPassenger(c,car,o,pose=>drawObject(c,pose,tick,room,{seated:true}));}

 const clip=o.sourceClip;
 if(room.smm2Mechanics?.version===1&&clip&&['up','down','left','right'].includes(clip.direction)&&Number.isFinite(clip.mouth)){
  const pad=128,x=Math.min(-pad,o.x-pad),y=Math.min(-pad,o.y-pad),right=Math.max(room.map?.width??0,o.x+o.w)+pad,bottom=Math.max(room.map?.height??0,o.y+o.h)+pad;
  c.save();c.beginPath();
  if(clip.direction==='up')c.rect(x,y,right-x,Math.max(0,clip.mouth-y));
  if(clip.direction==='down')c.rect(x,clip.mouth,right-x,Math.max(0,bottom-clip.mouth));
  if(clip.direction==='left')c.rect(x,y,Math.max(0,clip.mouth-x),bottom-y);
  if(clip.direction==='right')c.rect(clip.mouth,y,Math.max(0,right-clip.mouth),bottom-y);
  c.clip();drawObjectBody(c,o,tick,room);c.restore();return;
 }drawObjectBody(c,o,tick,room);
}
function drawObjectBody(c,o,tick=0,room={}){
 if(drawCoinCraneObject(c,o,room,tick))return;
 if(drawChainChompGuard(c,o,tick,room))return;
 if(drawSmwUnderwaterObject(c,o,room))return;
 if(drawLakituActor(c,o,tick,room))return;
 if(!isSmb3ArtRoom(room)&&drawWalkingKoopa(c,walkingKoopaActorForArt(o,room),tick,{defeatedEffect:o.kind==='enemy-death'&&o.shell===true}))return;
 if(!desertNotes(room)&&contraptionNoteForArt(room,o)){
  if(o.dead||o.removed||o.hidden||o.visible===false)return;
  if(verifiedSmb1Room(room)&&drawNativeNoteBlock(c,o))return;
  drawNote(c,o);return;
 }
 if(drawSmm2Actor(c,o,tick,room))return;if(drawContraptionsActor(c,o,tick,room))return;if(drawMarioModuleActor(c,o,tick,room))return;if(drawCheckpoint(c,o,tick,room))return;if(drawStudyActor(c,o,tick,room))return;if(o.kind==='bill-shot'){drawBillItem(c,o);return;}
 const {x,y,w,h}=o;c.save();
 const clipTop=o.emerge?o.blockTop:o.clipTop;if(Number.isFinite(clipTop)){c.beginPath();c.rect(x-16,y-32,w+32,Math.max(0,clipTop-y+32));c.clip();}
 if(o.kind==='bill-supply'){drawBillItem(c,o);}
 else if(o.kind==='spawn'&&room.playHero==='bill'){drawBill(c,{...o,y:o.y+o.h-30,h:30,facing:1,grounded:true},tick);}
 else if(o.kind==='enemy-death'){const name=o.flat?'goomba_flat':enemySprite(o.skin||o.type,room.setting,o.source)||'goomba',im=classicSprite(name);c.translate(Math.round(x+(w-im.width)/2),Math.round(y+h-im.height));if(!o.flat){c.translate(0,im.height);c.scale(1,-1);}c.drawImage(im,0,0);}
 else if(o.kind==='score-pop'){c.fillStyle='#fff';c.font='8px ChillBitmap, monospace';c.fillText(o.text,Math.round(x),Math.round(y));}
 else if(o.kind==='bubble'){classicDraw(c,'src|Character|Bubble||',x,y);}
 else if(o.kind==='coin-pop'){classicDraw(c,'coin'+(Math.floor((o.age||0)/4)%3),x,y);}
 else if(o.kind==='brick-debris'){const im=classicSprite('brick');c.drawImage(im,o.sx,o.sy,8,8,Math.round(x),Math.round(y),8,8);}
 else if(o.kind==='fire-impact'){classicDraw(c,'fireball'+(Math.floor((o.age||0)/2)%4),x+2,y+2);}
 else if(o.kind==='fireball'){classicDraw(c,'fireball'+(Math.floor(tick/3)%4),x-1,y-1);}
 else if(['mushroom','life','star','flower'].includes(o.kind)){const name=o.kind==='star'?'star0':o.kind==='flower'?'flower':'mushroom',variant=o.kind==='life'?'life':o.kind==='star'?['normal','starItem1','starItem2','starItem3'][Math.floor(tick/4)%4]:o.kind==='flower'?['normal','flower1','flower2','flower3'][Math.floor(tick/6)%4]:'normal',im=classicSprite(name,variant);classicDraw(c,name,x+(w-im.width)/2,y+h-im.height,false,variant);}
 else if(o.kind==='coin'){const im=classicSprite('coin0');classicDraw(c,'coin0',x+(w-im.width)/2,y+h-im.height);}
 else if(o.kind==='portal'){c.globalAlpha=.65;c.strokeStyle='#aaff99';c.strokeRect(x,y,w,h);}
 else if(o.kind==='walker'||enemySprite(o.kind)){const name=enemySprite(o.skin||o.kind,room.setting,{...o.source,frame:o.source?.frame||(Math.floor(tick/8)%2?'two':'')})||'goomba',im=classicSprite(name);classicDraw(c,name,x+(w-im.width)/2,y+h-im.height,/(Goomba|goomba)/.test(name)?!!(Math.floor(tick/8)%2):/BulletBill/.test(name)?o.vx<0:o.castleBattle?o.castleBattleFacing>0:o.vx>0);}
 else if(o.kind==='exit'&&room.markers?.some(m=>m.kind==='castle-finish')){c.restore();return;}
 else if(isSmwUnderwaterRoom(room)&&o.kind==='exit'){c.restore();return;}
 else if(o.kind==='exit'||o.kind==='checkpoint'){if(o.kind==='exit'&&room.markers?.some(m=>m.kind==='flagpole-finish'&&Math.abs(m.x-x)<32)){c.restore();return;}c.fillStyle='#80d010';c.fillRect(x+w/2-1,y-8,2,h-8);classicDraw(c,'flag_top',x+w/2-4,y-16);classicDraw(c,'flag',x+w/2-16,room.finish?.flagY??y);}
 else if(o.kind==='hazard'&&room.markers?.some(m=>/lava/.test(m.kind)&&o.x<m.x+2*(m.source?.width||8)&&o.x+o.w>m.x)){c.restore();return;}
 else if(o.kind==='hazard'){c.fillStyle='#eb5250';c.beginPath();c.moveTo(x,y+h);c.lineTo(x+w/2,y);c.lineTo(x+w,y+h);c.fill();}
 else {if(room.smm2Mechanics?.version===1&&o.kind!=='spawn'){c.restore();return;}if(!o.id?.startsWith('arrival-')){const skin=images.get(room.playerSkin)?.image;if(skin)c.drawImage(skin,x+(w-16)/2,y+h-16,16,16);else classicDraw(c,'small_idle',x+(w-16)/2,y+h-16);}c.strokeStyle='#80ffd8';c.strokeRect(x,y,w,h);c.fillStyle='#80ffd8';c.font='9px sans-serif';c.fillText(o.id?.startsWith('arrival-')?'落点':'起点',x,y-5);}
 c.restore();
}
export function drawPlayer(c,p,tick=0,skin,room={},display={}){
 drawNativePlayer(c,p,tick,skin,room,display);
 if(p.dying||!p.shrink&&!p.growth&&!p.fireGrowth&&p.invulnerable&&Math.floor(tick/4)%2)return;
 if(!display.seated)drawSkyShooterWeapon(c,room,tick);
}
function drawNativePlayer(c,p,tick=0,skin,room={},display={}){
 if(drawSmwUnderwaterPlayer(c,p,{room,tick}))return;
 if(!display.seated){const cloud=occupiedLakituCloud(room,p);if(cloud){c.save();c.beginPath();c.rect(p.x-32,p.y-64,p.w+64,Math.max(0,cloud.y-(p.y-64)));c.clip();drawNativePlayer(c,{...p,vx:0,vy:0,anim:0,grounded:true,crouch:false},tick,skin,room,{seated:true});c.restore();return;}}
 if(!display.seated){const car=occupiedClownCar(room.contraptionsView?.cars,p,true);if(car)return drawClownCarPassenger(c,car,p,pose=>drawNativePlayer(c,pose,tick,skin,room,{seated:true}),{player:true});}
 if(p.hero==='bill'){drawBill(c,p,tick);return;}
 if(drawSmb3Player(c,p,tick,room))return;
 const boneFootwear=smm2PlayerFootwear(p,room),boneShell=(boneFootwear?.smm2Shoe??boneFootwear)?.kind==='bone-shell';
 if(boneShell){drawSmm2PlayerFootwear(c,p,tick,room);if(smm2BoneShellPlayingDead(boneFootwear))return;}
 if(!p.dying&&!p.shrink&&!p.growth&&!p.fireGrowth&&p.invulnerable&&Math.floor(tick/4)%2)return;
 if(boneShell){
  const rect=smm2BoneShellVisualRect(boneFootwear),large=!!(p.shrink||p.growth?Math.floor((p.shrink||p.growth)/4)%2:p.power),reveal=large?12:8;
  // Exact catalogue Super rider has a 12px upper body over the unchanged 15px
  // shell. Small/Fire colour variants retain native head pixels, seated at the
  // same rim. Neither velocity nor airborne state can select running legs.
  if(large&&p.power!==2&&!p.star&&!p.fireGrowth)drawSmm2SourcePixels(c,'mountedSuper',{x:rect.x,y:rect.y-12*rect.scale,scale:rect.scale,mirror:p.facing<0,sourceHeight:27});
  else {const name=(large?'big':'small')+'_idle',im=classicSprite(name,p.fireGrowth?(Math.floor(p.fireGrowth/4)%2?'normal':'fire'):p.star?'star'+(1+Math.floor(tick/4)%3):p.power===2?'fire':'normal');c.save();c.imageSmoothingEnabled=false;c.translate(Math.round(rect.x)+(p.facing<0?16*rect.scale:0),Math.round(rect.y-reveal*rect.scale));c.scale(p.facing<0?-1:1,1);c.drawImage(im,0,0,16,reveal,0,0,16*rect.scale,reveal*rect.scale);c.restore();}
  drawSmm2PlayerGear(c,p,tick,room,{headX:rect.x,headY:rect.y-reveal*rect.scale,scale:rect.scale});return;
 }
 const footwear=boneFootwear;if(footwear)drawSmm2PlayerFootwear(c,p,tick,room);
 const prefix=(p.shrink||p.growth?Math.floor((p.shrink||p.growth)/4)%2:p.power)?'big':'small',name=p.dying?'dead':p.climbing?prefix+'_climb'+Math.floor(tick/8)%2:footwear||p.piping||p.springId?prefix+'_idle':p.power&&p.crouch?'big_crouch':p.swimming&&!p.grounded?'src|Character|Player|normal '+(prefix==='big'?(p.power===2?'fiery':'large'):'')+' paddling '+(p.swimStroke?'paddle'+(1+Math.floor((24-p.swimStroke)/8)%3):'swim2')+'|':!p.grounded?prefix+'_jump':p.vx*p.facing<-.08?prefix+'_skid':Math.abs(p.vx||0)>.08?prefix+'_run'+Math.floor((p.anim||0)/6)%3:prefix+'_idle';
 const im=images.get(skin)?.image||classicSprite(name,p.fireGrowth?(Math.floor(p.fireGrowth/4)%2?'normal':'fire'):p.star?'star'+(1+Math.floor(tick/4)%3):p.power===2?'fire':'normal');
 if(footwear){const pose=drawSmm2ShoeRider(c,p,footwear,im,{large:prefix==='big'});drawSmm2PlayerGear(c,p,tick,room,{headX:pose.x,headY:pose.y});drawSmm2ShoeFrontRim(c,p,footwear,tick);return;}
 c.save();c.translate(Math.round(p.x+(p.w-im.width)/2)+(p.facing<0?im.width:0),Math.round(p.y+p.h-im.height));c.scale(p.facing<0?-1:1,1);c.drawImage(im,0,0);c.restore();drawSmm2PlayerGear(c,p,tick,room);
}

/** Shared inventory world presentation, separate from loose key pickup bodies.
 * The native original sprite is centre/bottom anchored without collider writes.
 */
export function drawInventoryKeyFollowers(c,v,room={}, {layer='all'}={}){
 if(v.p?.dying)return false;
 let count=0;
 for(const key of v.contraptions?.keyFollowers||[]){
  const foreground=key.kind==='consuming-key'&&(key.scale??1)<=1;
  if(layer==='behind'&&foreground||layer==='front'&&!foreground)continue;
  if(![key.x,key.y,key.w,key.h].every(Number.isFinite))continue;
  const scale=Number.isFinite(key.scale)?key.scale:1,w=key.w*scale,h=key.h*scale;
  drawKey(c,{...key,inventoryPresentation:true,x:key.x+(key.w-w)/2,y:key.y+(key.h-h)/2,w,h},room);count++;
 }
 return count>0;
}

const HUD_GLYPHS={
 '0':[0x3c,0x66,0x6e,0x76,0x66,0x66,0x3c], '1':[0x18,0x38,0x18,0x18,0x18,0x18,0x7e],
 '2':[0x3c,0x66,0x06,0x0c,0x30,0x60,0x7e], '3':[0x3c,0x66,0x06,0x1c,0x06,0x66,0x3c],
 '4':[0x0c,0x1c,0x3c,0x6c,0x7e,0x0c,0x0c], '5':[0x7e,0x60,0x7c,0x06,0x06,0x66,0x3c],
 '6':[0x1c,0x30,0x60,0x7c,0x66,0x66,0x3c], '7':[0x7e,0x66,0x06,0x0c,0x18,0x18,0x18],
 '8':[0x3c,0x66,0x66,0x3c,0x66,0x66,0x3c], '9':[0x3c,0x66,0x66,0x3e,0x06,0x0c,0x38],
 'A':[0x18,0x3c,0x66,0x66,0x7e,0x66,0x66], 'B':[0x7c,0x66,0x66,0x7c,0x66,0x66,0x7c],
 'C':[0x3c,0x66,0x60,0x60,0x60,0x66,0x3c], 'D':[0x78,0x6c,0x66,0x66,0x66,0x6c,0x78],
 'E':[0x7e,0x60,0x60,0x7c,0x60,0x60,0x7e], 'F':[0x7e,0x60,0x60,0x7c,0x60,0x60,0x60],
 'G':[0x3c,0x66,0x60,0x6e,0x66,0x66,0x3e], 'H':[0x66,0x66,0x66,0x7e,0x66,0x66,0x66],
 'I':[0x7e,0x18,0x18,0x18,0x18,0x18,0x7e], 'J':[0x1e,0x0c,0x0c,0x0c,0x0c,0x6c,0x38],
 'K':[0x66,0x6c,0x78,0x70,0x78,0x6c,0x66], 'L':[0x60,0x60,0x60,0x60,0x60,0x60,0x7e],
 'M':[0x63,0x77,0x7f,0x6b,0x63,0x63,0x63], 'N':[0x66,0x76,0x7e,0x7e,0x6e,0x66,0x66],
 'O':[0x3c,0x66,0x66,0x66,0x66,0x66,0x3c], 'P':[0x7c,0x66,0x66,0x7c,0x60,0x60,0x60],
 'Q':[0x3c,0x66,0x66,0x66,0x6e,0x3c,0x0e], 'R':[0x7c,0x66,0x66,0x7c,0x78,0x6c,0x66],
 'S':[0x3c,0x66,0x60,0x3c,0x06,0x66,0x3c], 'T':[0x7e,0x18,0x18,0x18,0x18,0x18,0x18],
 'U':[0x66,0x66,0x66,0x66,0x66,0x66,0x3c], 'V':[0x66,0x66,0x66,0x66,0x66,0x3c,0x18],
 'W':[0x63,0x63,0x63,0x6b,0x7f,0x77,0x63], 'X':[0x66,0x66,0x3c,0x18,0x3c,0x66,0x66],
 'Y':[0x66,0x66,0x66,0x3c,0x18,0x18,0x18], 'Z':[0x7e,0x06,0x0c,0x18,0x30,0x60,0x7e],
 '-':[0,0,0,0x3c,0,0,0], '!':[0x18,0x18,0x18,0x18,0x18,0,0x18], ' ':[0,0,0,0,0,0,0],
 '/':[0x02,0x06,0x0c,0x18,0x30,0x60,0x40],
 '×':[0,0,0x66,0x3c,0x18,0x3c,0x66]
};

/** A SMM2 course needs its collectible/key feedback even when ON/OFF is enabled.
 * Legacy comparison-only switch studies keep their prior clean viewport. */
export const nativeHudEnabled=room=>!room?.switchStudy||room.smm2Mechanics?.version===1;
/** Runtime health and attack cues use the same renderer for preview, HTML and recording. */
export function drawCastleBattleHud(c,v){
 const battle=v.castle?.battle;if(!battle||!Number.isFinite(battle.hp)||!Number.isFinite(battle.maxHp))return false;
 const width=v.viewportWidth||384,x=Math.round((width-176)/2),modern=v.smm2Mechanics?.version===1||v.aquatic?.version===1;
 const y=modern?Math.max(60,smm2AuxiliaryHud(v,width).bottom+8):40,barY=y+12;
 c.save();
 if(!modern&&Number.isFinite(v.lives))drawSmm2OutlinedText(c,'LIFE ×'+Math.max(0,Math.trunc(v.lives)),64,32);
 (modern?drawSmm2OutlinedText:drawPixelText)(c,'BOWSER '+battle.hp+'/'+battle.maxHp,x,y);
 c.fillStyle='#5a2525';c.fillRect(x,barY,176,4);c.fillStyle=battle.exposed?'#83e86b':'#ef693c';c.fillRect(x,barY,Math.round(176*Math.max(0,Math.min(1,battle.hp/battle.maxHp))),4);
 if(battle.cue)(modern?drawSmm2OutlinedText:drawPixelText)(c,battle.cue,Math.round((width-battle.cue.length*8)/2),y+22);
 c.restore();return true;
}
export function drawHud(c,v,level='1-1',room=v){
 const smm2=v.smm2Mechanics?.version===1||v.aquatic?.version===1,width=v.viewportWidth||(smm2?256:384);
 if(smm2){
  const layout=smm2HudLayout(width);
  if(Number.isFinite(v.lives))drawSmm2LifeHud(c,v.lives,layout,room);
  if(!drawSmwUnderwaterHudSprite(c,room,'coin',layout.iconCenterX,layout.coinBottom,10))drawHudSpriteBottom(c,'coin0',layout.iconCenterX,layout.coinBottom,10);
  drawSmm2OutlinedText(c,'×'+hudNumber(v.coins,2),layout.countX,layout.coinY);
  const score=hudNumber(v.score,9);drawSmm2OutlinedText(c,score,layout.clockX-8-score.length*8,layout.firstY);
  drawSmm2ClockGlyph(c,layout.clockX,layout.firstY);
  drawSmm2OutlinedText(c,hudNumber(v.timeLeft,3),layout.timeX,layout.firstY);
  drawSmm2AuxiliaryHud(c,v,width,room);drawLakituGoalHud(c,v,room);drawCastleBattleHud(c,v);return;
 }
 drawCastleBattleHud(c,v);
 const text=(str,x,y)=>smm2?drawSmm2OutlinedText(c,str,x,y):drawPixelText(c,str,x,y);
 drawSmm2PinkCoinHud(c,v,smm2?{x:Math.max(64,width-72),y:32,hideCompleted:true}:{x:64,y:8});
 if(smm2&&Number.isFinite(v.contraptions?.pFrames)&&v.contraptions.pFrames>0)drawSmm2OutlinedText(c,'P '+String(Math.ceil(v.contraptions.pFrames/60)).padStart(2,'0'),Math.max(144,width-176),32);
 if(v.contraptions||smm2){classicDraw(c,'coin0',8,10);text('×'+String(v.coins).padStart(3,'0'),24,16);text(String(v.score).padStart(6,'0'),width-144,12);text(String(v.timeLeft).padStart(3,'0'),width-48,12);if(v.contraptions?.keys&&!(v.contraptions.keyFollowers?.length>0)){drawKeyHud(c,{x:8,y:32,w:12,h:12},room);text(String(v.contraptions.keys),24,36);}return;}
 text(v.p?.hero==='bill'?'BILL':'MARIO',24,16);if(v.p?.hero==='bill')text(v.p.weapon||'N',24,34);text(String(v.score).padStart(6,'0'),24,24);c.save();c.translate(91,24);c.scale(.5,.5);classicDraw(c,'coin0',0,0);c.restore();text('×'+String(v.coins).padStart(2,'0'),104,24);text('WORLD',144,16);text(level,152,24);text('TIME',208,16);text(String(v.timeLeft).padStart(3,'0'),216,24);if(v.finish?.component&&['message','complete'].includes(v.finish.phase)){const messages=v.finish.messages||[],index=Math.min(v.finish.messageIndex,messages.length-1);let y=88;for(let n=0;n<=index;n++){const lines=[];let line='';for(const word of messages[n].split(' ')){if((line+' '+word).trim().length>26){lines.push(line);line=word;}else line=(line+' '+word).trim();}if(line)lines.push(line);for(const line of lines){text(line,Math.round((256-line.length*8)/2),y);y+=16;}y+=16;}}
}

function drawSmm2OutlinedText(c,text,x,y){c.save();for(const [dx,dy]of [[-1,0],[1,0],[0,-1],[0,1]])drawPixelText(c,text,x+dx,y+dy,'#1f1f1f');drawPixelText(c,text,x,y);c.restore();}
/** Original-like transparent two-row layout. The inspected 24-tile source
 * has its score at x256, clock at x336 and time at x348. Narrow/wide views
 * keep these right margins while the life/coin rows share the same left slot.
 */
export function smm2HudLayout(width=384){return {margin:12,iconCenterX:20,countX:24,firstY:12,coinY:26,lifeBottom:20,coinBottom:34,scoreX:width-128,clockX:width-48,timeX:width-36,auxiliaryY:40};}
const hudNumber=(value,digits)=>String(Math.max(0,Math.trunc(Number.isFinite(value)?value:0))).padStart(digits,'0');
function drawHudSpriteBottom(c,name,centerX,bottom,height){
 const im=classicSprite(name),scale=height/im.height,w=im.width*scale;
 c.save();c.imageSmoothingEnabled=false;c.drawImage(im,Math.round(centerX-w/2),bottom-height,w,height);c.restore();
}
function drawSmm2LifeHud(c,lives,layout,room){
 // The retained native 16x16 Mario sprite is uniformly thumbnailed to 12px;
 // its feet anchor the slot. It is never stretched into a wide LIFE label.
 if(!drawSmwUnderwaterHudSprite(c,room,'mario',layout.iconCenterX,layout.lifeBottom,12))drawHudSpriteBottom(c,'small_idle',layout.iconCenterX,layout.lifeBottom,12);
 drawSmm2OutlinedText(c,'×'+hudNumber(lives,2),layout.countX,layout.firstY);
}
// Authored 8x7 clock-font adaptation of the inspected source silhouette.
// An exact original SMM2 HUD font/clock payload has not been recovered.
const HUD_CLOCK_ROWS=[0x7e,0x81,0x91,0x91,0x9d,0x81,0x7e];
function drawSmm2ClockGlyph(c,x,y){
 const mask=(color,dx,dy)=>{c.fillStyle=color;for(let row=0;row<7;row++)for(let col=0;col<8;col++)if(HUD_CLOCK_ROWS[row]&(128>>col))c.fillRect(x+col+dx,y+row+dy,1,1);};
 c.save();for(const [dx,dy]of [[-1,0],[1,0],[0,-1],[0,1]])mask('#1f1f1f',dx,dy);mask('#fff',0,0);c.restore();
}
function smm2AuxiliaryHud(v,width){
 const layout=smm2HudLayout(width),keys=Number.isFinite(v.contraptions?.keys)&&v.contraptions.keys>0&&!(v.contraptions.keyFollowers?.length>0),pFrames=v.contraptions?.pFrames;
 const pText=Number.isFinite(pFrames)&&pFrames>0?'P '+hudNumber(Math.ceil(pFrames/60),2):null;
 const pX=Math.max(layout.margin+64,width-176),progress=v.smm2Mechanics?.pinkCoins,rows=[];
 const valid=progress&&Number.isInteger(progress.total)&&progress.total>0&&progress.total<=128&&Number.isInteger(progress.taken)&&progress.taken>=0&&progress.taken<=progress.total;
 let bottom=layout.auxiliaryY+(keys||pText?12:0);
 if(valid){
  let offset=0,row=0;
  while(offset<progress.total){
   const left=row===0?(pText?pX+pText.length*8+8:keys?layout.margin+56:layout.margin):layout.margin;
   const capacity=Math.max(1,Math.floor((width-layout.margin-left-7)/12)+1),total=Math.min(capacity,progress.total-offset),w=(total-1)*12+7,y=layout.auxiliaryY+row*12;
   rows.push({x:width-layout.margin-w,y,total,taken:Math.max(0,Math.min(total,progress.taken-offset))});bottom=Math.max(bottom,y+9);offset+=total;row++;
  }
 }
 return {layout,keys,pText,pX,progress,rows,bottom};
}
function drawSmm2AuxiliaryHud(c,v,width,room){
 const q=smm2AuxiliaryHud(v,width),y=q.layout.auxiliaryY;
 if(q.keys){drawKeyHud(c,{x:q.layout.margin,y,w:12,h:12},room);drawSmm2OutlinedText(c,hudNumber(v.contraptions.keys,1),q.layout.margin+16,y+2);}
 if(q.pText)drawSmm2OutlinedText(c,q.pText,q.pX,y+2);
 if(q.progress?.taken===q.progress?.total&&q.progress?.keyReleased===true)return;
 for(const row of q.rows)drawSmm2PinkCoinHud(c,{smm2Mechanics:{version:1,pinkCoins:{taken:row.taken,total:row.total,keyReleased:false}}},{x:row.x,y:row.y,spacing:12});
}

export function drawPixelText(c,str,x,y,color='#fff'){c.fillStyle=color;for(const ch of String(str).toUpperCase()){const glyph=HUD_GLYPHS[ch]||HUD_GLYPHS[' '];for(let r=0;r<7;r++)for(let col=0;col<8;col++)if(glyph[r]&(128>>col))c.fillRect(x+col,y+r,1,1);x+=8;}}
