import {geometryPlacementType,pickupType} from './editor-placement.mjs';
import {createSMM2Terrain} from './editor-smm2-terrain.mjs';

/**
 * Fixed conveyor geometry with additive, swept surface transport.
 *
 * The reference establishes occupied TOP contact and ON/OFF reversal. It does
 * not establish underside/side solidity or universal player/enemy physics.
 * All speeds and contact endpoints are explicit authored fits. Renderer tread
 * speed is independent of physical transport speed; neither is a measurement
 * obtained from video stripe motion.
 *
 * Caps outside topEndpoints are visual-only. A rectangular body contacts the
 * highest analytic point in the positive-width overlap of its actual footprint
 * and the top segment. This conservative footprint rule avoids penetrating an
 * incline and is an authored approximation, not a recovered original hitbox.
 */
export const CONVEYOR_PARAMETER_STATUS = 'observed-top-contract/authored-fit-not-universal-calibration';
export const CONVEYOR_CONTACT_MODE = 'observed-top-only';
export const CONVEYOR_COORDINATE_LIMIT = 1_000_000;
const EPS = 1e-7;
const MAX_SURFACES = 256;
const copy = value => structuredClone(value);
const plain = value => value !== null && typeof value === 'object' && !Array.isArray(value) && [Object.prototype, null].includes(Object.getPrototypeOf(value));
const fail = message => { throw new TypeError(message); };
const fields = (value, allowed, name) => {
  if (!plain(value) || Object.keys(value).some(key => !allowed.includes(key))) fail(`${name} has invalid or unknown fields`);
};
const finite = (value, name, min = -CONVEYOR_COORDINATE_LIMIT, max = CONVEYOR_COORDINATE_LIMIT) => {
  if (!Number.isFinite(value) || value < min || value > max) fail(`${name} must be finite and within the tool numerical-safety range`);
  return value;
};
const stableId = (value, name) => {
  if (typeof value !== 'string' || !/^[a-zA-Z0-9][a-zA-Z0-9._:-]{0,127}$/.test(value) || ['constructor', 'prototype', '__proto__'].includes(value)) fail(`${name} needs a stable ID`);
};
const tickNumber = value => {
  if (!Number.isSafeInteger(value) || value < 0) fail('tick must be a nonnegative safe integer');
  return value;
};
const seconds = value => finite(value, 'deltaSeconds', 0, 3600);
const equal = (a, b) => Math.abs(a - b) <= EPS;
const wrap = (value, period) => ((value % period) + period) % period;

function point(value, name) {
  fields(value, ['x', 'y'], name);
  finite(value.x, `${name}.x`); finite(value.y, `${name}.y`);
}
function rectangle(value, name) {
  fields(value, ['x', 'y', 'w', 'h'], name);
  finite(value.x, `${name}.x`); finite(value.y, `${name}.y`);
  finite(value.w, `${name}.w`, EPS); finite(value.h, `${name}.h`, EPS);
  finite(value.x + value.w, `${name}.right`); finite(value.y + value.h, `${name}.bottom`);
}
function roomBounds(value) {
  if (value === undefined) return null;
  if (plain(value) && 'width' in value) {
    fields(value, ['width', 'height'], 'bounds');
    const result = {x: 0, y: 0, w: value.width, h: value.height};
    rectangle(result, 'bounds'); return result;
  }
  rectangle(value, 'bounds'); return value;
}
function contains(rect, x, y) {
  return x >= rect.x - EPS && x <= rect.x + rect.w + EPS && y >= rect.y - EPS && y <= rect.y + rect.h + EPS;
}

/** Validates detached pixel-valued definitions. No room IDs or course rules. */
export function validateConveyorsRoom(specs, bounds) {
  if (!Array.isArray(specs) || specs.length > MAX_SURFACES) fail('conveyors must be a bounded array');
  const room = roomBounds(bounds), ids = new Set();
  for (const spec of specs) {
    fields(spec, ['id', 'topEndpoints', 'visual', 'speedPxPerSecond', 'visualTreadSpeedPxPerSecond', 'treadPeriodPx', 'directionOn', 'contactMode', 'parameterStatus'], 'conveyor');
    stableId(spec.id, 'conveyor.id');
    if (ids.has(spec.id)) fail('Duplicate conveyor stable ID');
    ids.add(spec.id);
    if (spec.contactMode !== CONVEYOR_CONTACT_MODE) fail('Conveyor contactMode must explicitly be observed-top-only');
    if (spec.parameterStatus !== CONVEYOR_PARAMETER_STATUS) fail('Conveyor parameters must explicitly retain their authored-fit status');
    finite(spec.speedPxPerSecond, 'speedPxPerSecond', EPS);
    if (spec.visualTreadSpeedPxPerSecond !== undefined) finite(spec.visualTreadSpeedPxPerSecond, 'visualTreadSpeedPxPerSecond', EPS);
    if (spec.treadPeriodPx !== undefined) finite(spec.treadPeriodPx, 'treadPeriodPx', EPS);
    if (![1, -1].includes(spec.directionOn)) fail('directionOn must be +1 or -1 along the increasing-x top');
    if (!Array.isArray(spec.topEndpoints) || spec.topEndpoints.length !== 2) fail('Conveyor needs two authored topEndpoints');
    spec.topEndpoints.forEach((p, n) => point(p, `topEndpoints[${n}]`));
    const [a, b] = spec.topEndpoints;
    if (b.x - a.x <= EPS) fail('Conveyor topEndpoints must have a positive increasing-x span');
    const visual = spec.visual;
    fields(visual, ['kind', 'rect', 'rollerCenters', 'rollerRadiusPx'], 'visual');
    if (!['rect', 'line'].includes(visual.kind)) fail('visual.kind must be rect or line');
    rectangle(visual.rect, 'visual.rect');
    finite(visual.rollerRadiusPx, 'rollerRadiusPx', EPS);
    if (!Array.isArray(visual.rollerCenters) || visual.rollerCenters.length !== 2) fail('Conveyor needs two real visual roller centers');
    visual.rollerCenters.forEach((p, n) => point(p, `rollerCenters[${n}]`));
    const [ra, rb] = visual.rollerCenters;
    if (rb.x - ra.x <= EPS) fail('Roller centerline must have a positive increasing-x span');
    for (const p of visual.rollerCenters) {
      for (const [dx, dy] of [[-1, -1], [-1, 1], [1, -1], [1, 1]]) {
        if (!contains(visual.rect, p.x + dx * visual.rollerRadiusPx, p.y + dy * visual.rollerRadiusPx)) fail('Visual rectangle must contain the actual roller bounds');
      }
    }
    for (const p of spec.topEndpoints) if (!contains(visual.rect, p.x, p.y)) fail('Authored top must lie within its visual bounds');
    if (visual.kind === 'rect') {
      if (!equal(a.y, b.y) || !equal(ra.y, rb.y) || !equal(a.y, visual.rect.y) || !equal(a.x, visual.rect.x) || !equal(b.x, visual.rect.x + visual.rect.w)) fail('Rect conveyor needs its real horizontal top and matching visual extent');
    } else {
      const topSlope = (b.y - a.y) / (b.x - a.x), visualSlope = (rb.y - ra.y) / (rb.x - ra.x);
      if (!equal(topSlope, visualSlope)) fail('Sloped contact must follow the actual visual roller centerline, not a generic diagonal');
    }
    if (room && (!contains(room, visual.rect.x, visual.rect.y) || !contains(room, visual.rect.x + visual.rect.w, visual.rect.y + visual.rect.h))) fail('Conveyor visual geometry exceeds room bounds');
  }
  return copy(specs);
}

function segmentBuriedInPolygon([a,b],polygon) {
  const dx=b.x-a.x,dy=b.y-a.y,breaks=[0,1];
  const inside=p=>{let sign=0;for(let i=0;i<polygon.length;i++){const u=polygon[i],v=polygon[(i+1)%polygon.length],cross=(v.x-u.x)*(p.y-u.y)-(v.y-u.y)*(p.x-u.x);if(Math.abs(cross)<=EPS)return false;const next=Math.sign(cross);if(sign&&sign!==next)return false;sign=next;}return !!sign;};
  for(let i=0;i<polygon.length;i++){const u=polygon[i],v=polygon[(i+1)%polygon.length],ex=v.x-u.x,ey=v.y-u.y,den=dx*ey-dy*ex;if(Math.abs(den)<=EPS)continue;const t=((u.x-a.x)*ey-(u.y-a.y)*ex)/den,s=((u.x-a.x)*dy-(u.y-a.y)*dx)/den;if(t>0&&t<1&&s>=0&&s<=1)breaks.push(t);}
  breaks.sort((x,y)=>x-y);for(let i=1;i<breaks.length;i++){const t=(breaks[i-1]+breaks[i])/2;if(inside({x:a.x+dx*t,y:a.y+dy*t}))return true;}return false;
}
const rectanglePolygon=q=>[{x:q.x,y:q.y},{x:q.x+q.w,y:q.y},{x:q.x+q.w,y:q.y+q.h},{x:q.x,y:q.y+q.h}];
/** Shared import/export/authoring placement gate, with no UI or model import.
 * Only actual verified top segments are checked. Render bounds do not become
 * solid rectangles, empty slope space remains legal, and state-dependent
 * ON/OFF block overlays do not acquire an invented permanent-solid policy. */
export function conveyorPlacementIssues(room) {
  const conveyors=room.smm2Mechanics?.conveyors||[];if(!conveyors.length)return [];
  validateConveyorsRoom(conveyors,{width:room.map.width,height:room.map.height});
  const solids=room.map.geometry.filter(q=>geometryPlacementType(room,q).permanent).map(q=>({id:q.id,polygon:rectanglePolygon(q)}));
  for(const q of [...(room.contraptions?.notes||[]),...(room.marioModules?.noteBlocks||[]),...(room.switchStudy?.devices||[]).filter(q=>q.kind==='switch')])solids.push({id:q.id,polygon:rectanglePolygon(q)});
  for(const q of createSMM2Terrain(room)?.surfaces().filter(q=>q.kind==='slope')||[])solids.push({id:q.id,polygon:q.polygon});
  const pickups=room.map.objects.filter(q=>pickupType(room,q)).map(q=>({id:q.id,polygon:rectanglePolygon(q)})),issues=[];
  const add=(code,ids)=>issues.push({code,severity:'error',roomId:room.roomId,ids,message:'传送带已验证顶面与禁止重叠的真实内容相交'});
  for(const q of conveyors){for(const g of solids)if(segmentBuriedInPolygon(q.topEndpoints,g.polygon))add('CONVEYOR_TOP_SOLID_OVERLAP',[q.id,g.id]);for(const g of pickups)if(segmentBuriedInPolygon(q.topEndpoints,g.polygon))add('CONVEYOR_TOP_PICKUP_OVERLAP',[q.id,g.id]);}
  for(let i=0;i<conveyors.length;i++)for(let j=i+1;j<conveyors.length;j++){const a=conveyors[i],b=conveyors[j],left=Math.max(a.topEndpoints[0].x,b.topEndpoints[0].x),right=Math.min(a.topEndpoints[1].x,b.topEndpoints[1].x);if(right-left<=EPS)continue;const y=(q,x)=>q.topEndpoints[0].y+(x-q.topEndpoints[0].x)*(q.topEndpoints[1].y-q.topEndpoints[0].y)/(q.topEndpoints[1].x-q.topEndpoints[0].x),lo=y(a,left)-y(b,left),hi=y(a,right)-y(b,right);if(Math.abs(lo)<=EPS&&Math.abs(hi)<=EPS||lo*hi<0)add('CONVEYOR_TOP_SURFACE_OVERLAP',[a.id,b.id]);}
  return issues;
}
export function assertConveyorPlacement(room) {
  const issues=conveyorPlacementIssues(room);
  if(issues.length){const error=new TypeError(issues.map(q=>q.code+' · '+q.ids.join(' ↔ ')).join('；'));error.issues=issues;throw error;}
  return room;
}

function validBody(body, name = 'body') {
  if (!plain(body)) fail(`${name} must be an actual rectangular actor body`);
  for (const key of ['x', 'y', 'w', 'h']) finite(body[key], `${name}.${key}`, ['w', 'h'].includes(key) ? EPS : -CONVEYOR_COORDINATE_LIMIT);
  finite(body.x + body.w, `${name}.right`); finite(body.y + body.h, `${name}.feet`);
  if (body.vy !== undefined) finite(body.vy, `${name}.vy`);
  if (body.id !== undefined) stableId(body.id, `${name}.id`);
}
function prepared(spec) {
  const [from, to] = spec.topEndpoints, dx = to.x - from.x, dy = to.y - from.y, length = Math.hypot(dx, dy);
  return {spec, from, to, slope: dy / dx, tangent: {x: dx / length, y: dy / length}, length};
}
function sample(surface, body) {
  const left = Math.max(surface.from.x, body.x), right = Math.min(surface.to.x, body.x + body.w);
  if (right - left <= EPS) return null;
  const x = surface.slope < 0 ? right : left;
  return {surfaceId: surface.spec.id, x, y: surface.from.y + (x - surface.from.x) * surface.slope, overlap: {left, right}, tangent: {...surface.tangent}, contactMode: CONVEYOR_CONTACT_MODE, footprintRule: 'highest-overlapped-analytic-point'};
}

/** Earliest descending top crossing, solving clipped footprint-line pieces. */
function crossing(surface, before, after) {
  const dx = after.x - before.x, dy = after.y + after.h - before.y - before.h;
  if (dy < -EPS || (after.vy ?? dy) < -EPS) return null;
  const breaks = [0, 1];
  if (Math.abs(dx) > EPS) for (const edge of [surface.from.x, surface.to.x]) for (const offset of [0, before.w]) {
    const t = (edge - before.x - offset) / dx;
    if (t > EPS && t < 1 - EPS) breaks.push(t);
  }
  breaks.sort((a, b) => a - b);
  const bodyAt = t => ({...before, x: before.x + dx * t, y: before.y + dy * t});
  const gapAt = t => {
    const body = bodyAt(t), support = sample(surface, body);
    return support ? {gap: body.y + body.h - support.y, support} : null;
  };
  for (let n = 1; n < breaks.length; n++) {
    const lo = breaks[n - 1], hi = breaks[n];
    // Endpoints can have zero overlap. Take an interior limit without treating
    // a side/underside entry already below the top as a descending landing.
    const inset = Math.min((hi - lo) / 4, 1e-8);
    const start = gapAt(lo) || gapAt(lo + inset), end = gapAt(hi) || gapAt(hi - inset);
    if (!start || !end || start.gap > EPS || end.gap < -EPS) continue;
    const slope = (end.gap - start.gap) / (hi - lo);
    if (slope < -EPS) continue;
    const fraction = slope <= EPS ? lo : Math.max(lo, Math.min(hi, lo - start.gap / slope));
    const at = gapAt(fraction) || gapAt(Math.min(hi, fraction + inset));
    if (at) return {...at.support, fraction, reason: 'descending-top-crossing'};
  }
  return null;
}

/**
 * Generic player/NPC port. intrinsic vx and facing are never overwritten.
 * frame() advances tread phase only, never the whole platform geometry.
 */
export function createConveyorSurfaces(specs, {isOn = true, emit = () => {}, bounds} = {}) {
  const definitions = validateConveyorsRoom(specs, bounds), surfaces = definitions.map(prepared), byId = new Map(surfaces.map(s => [s.spec.id, s]));
  if (typeof isOn !== 'boolean' && typeof isOn !== 'function') fail('isOn must be a boolean or current-switch-state callback');
  if (typeof emit !== 'function') fail('emit must be a callback');
  const specSignature = JSON.stringify(definitions);
  let lastTick = null, deltaSeconds = 1 / 60, paused = false, on, phases, actorTicks, actorIds;
  function switchState() {
    const next = typeof isOn === 'function' ? isOn() : isOn;
    if (typeof next !== 'boolean') fail('isOn callback must return a boolean');
    if (on !== undefined && on !== next) emit('conveyor-direction', {tick: lastTick, on: next, surfaceIds: definitions.map(s => s.id)});
    on = next; return next;
  }
  function view() {
    switchState();
    return {
      contactMode: CONVEYOR_CONTACT_MODE, parameterStatus: CONVEYOR_PARAMETER_STATUS,
      tick: lastTick, deltaSeconds, paused, on,
      surfaces: surfaces.map(surface => {
        const {spec, tangent} = surface, directionSign = on ? spec.directionOn : -spec.directionOn;
        const treadDistancePx = phases.get(spec.id), visualSpeed = spec.visualTreadSpeedPxPerSecond ?? spec.speedPxPerSecond;
        return {
          id: spec.id, dx: 0, dy: 0, topEndpoints: copy(spec.topEndpoints), visual: copy(spec.visual),
          contactMode: spec.contactMode, parameterStatus: spec.parameterStatus,
          colorState: on ? 'red' : 'blue', on, directionSign,
          topTreadDirection: {x: tangent.x * directionSign, y: tangent.y * directionSign},
          bottomTreadDirection: {x: -tangent.x * directionSign, y: -tangent.y * directionSign},
          surfaceFlow: {x: paused ? 0 : tangent.x * directionSign * spec.speedPxPerSecond, y: paused ? 0 : tangent.y * directionSign * spec.speedPxPerSecond},
          treadDistancePx, treadPhasePx: wrap(treadDistancePx, spec.treadPeriodPx ?? 16),
          visualTreadSpeedPxPerSecond: paused ? 0 : visualSpeed,
          rollers: spec.visual.rollerCenters.map((center, index) => ({id: `${spec.id}:roller:${index}`, ...center, radiusPx: spec.visual.rollerRadiusPx, phaseRadians: wrap(treadDistancePx / spec.visual.rollerRadiusPx, Math.PI * 2)}))
        };
      })
    };
  }
  function reset() {
    lastTick = null; deltaSeconds = 1 / 60; paused = false; on = undefined;
    phases = new Map(definitions.map(spec => [spec.id, 0])); actorTicks = new WeakMap(); actorIds = new Set();
    return view();
  }
  reset();
  function frame(options) {
    if (typeof options === 'number') options = {tick: options};
    fields(options, ['tick', 'deltaSeconds'], 'frame');
    const tick = tickNumber(options.tick), dt = seconds(options.deltaSeconds ?? 1 / 60);
    if (lastTick !== null && tick < lastTick) fail('Conveyor ticks cannot move backward; reset or restore explicitly');
    switchState();
    if (tick === lastTick) {
      if (!equal(dt, deltaSeconds)) fail('Repeated conveyor tick cannot change deltaSeconds');
      return view();
    }
    lastTick = tick; deltaSeconds = dt; actorTicks = new WeakMap(); actorIds = new Set();
    if (!paused) for (const spec of definitions) {
      const value = phases.get(spec.id) + (on ? spec.directionOn : -spec.directionOn) * (spec.visualTreadSpeedPxPerSecond ?? spec.speedPxPerSecond) * dt;
      if (!Number.isFinite(value) || Math.abs(value) > Number.MAX_SAFE_INTEGER) fail('Conveyor tread phase exceeds the tool numerical-safety range');
      phases.set(spec.id, value);
    }
    return view();
  }
  function surfaceAtX(id, x) {
    finite(x, 'surface x'); const surface = byId.get(id);
    if (!surface || x < surface.from.x - EPS || x > surface.to.x + EPS) return null;
    return {surfaceId: id, x, y: surface.from.y + (x - surface.from.x) * surface.slope, tangent: {...surface.tangent}, contactMode: CONVEYOR_CONTACT_MODE};
  }
  function bodySupport(body, id) {
    validBody(body);
    if (id !== undefined) return byId.has(id) ? sample(byId.get(id), body) : null;
    return surfaces.map(s => sample(s, body)).filter(Boolean).sort((a, b) => a.y - b.y || a.surfaceId.localeCompare(b.surfaceId))[0] ?? null;
  }
  function contact(body, {previous} = {}) {
    validBody(body); if (previous !== undefined) validBody(previous, 'previous');
    if (body.dead || body.removed || body.dying || (body.vy ?? 0) < -EPS) return null;
    if (previous && (!equal(body.w, previous.w) || !equal(body.h, previous.h))) fail('Conveyor previous body must retain the actual footprint');
    const contacts = [];
    const preceding = previous && byId.get(previous.support), precedingTop = preceding && sample(preceding, previous);
    const genuinePreceding = !!precedingTop && previous.grounded === true && Math.abs(previous.y + previous.h - precedingTop.y) <= EPS && (previous.vy ?? 0) >= -EPS && body.y + body.h >= previous.y + previous.h - EPS;
    function followsConnectedTop(surface) {
      if (!genuinePreceding || surface === preceding || !sample(preceding, body)) return false;
      // The actual current footprint must overlap BOTH genuine tops. Equal
      // junction height plus this overlap proves a finite gap is bridged by
      // the body; nearby airborne/underside bodies cannot use this transfer.
      if (surface.from.x >= preceding.to.x - EPS) {
        return equal(preceding.to.y, surface.from.y) && surface.from.x - preceding.to.x < body.w - EPS;
      }
      if (surface.to.x <= preceding.from.x + EPS) {
        return equal(surface.to.y, preceding.from.y) && preceding.from.x - surface.to.x < body.w - EPS;
      }
      return false;
    }
    for (const surface of surfaces) {
      const now = sample(surface, body); if (!now) continue;
      const feet = body.y + body.h;
      if (Math.abs(feet - now.y) <= EPS) contacts.push({...now, fraction: 0, reason: 'standing-top'});
      else if (previous) {
        const old = sample(surface, previous);
        if (old && previous.grounded === true && previous.support === surface.spec.id && Math.abs(previous.y + previous.h - old.y) <= EPS && (previous.vy ?? 0) >= -EPS && body.y + body.h >= previous.y + previous.h - EPS) {
          // Follow only genuine preceding support. A rising top can lift its
          // supported actor along the continuous incline; airborne/below-side
          // overlap alone never grants this correction.
          contacts.push({...now, fraction: 0, reason: 'following-previous-top'});
        } else if (followsConnectedTop(surface)) {
          contacts.push({...now, fraction: 0, reason: 'following-connected-top', previousSurfaceId: preceding.spec.id});
        } else {
          const hit = crossing(surface, previous, body); if (hit) contacts.push({...now, fraction: hit.fraction, reason: hit.reason, impact: {x: hit.x, y: hit.y}});
        }
      }
    }
    // A connected uphill top underneath the real footprint takes precedence
    // over the lower outgoing flat. Otherwise that flat would hold the actor
    // at its old height until the new incline became an apparent side wall.
    return contacts.sort((a, b) => a.fraction - b.fraction || a.y - b.y || (a.surfaceId === previous?.support ? -1 : 0) - (b.surfaceId === previous?.support ? -1 : 0) || a.surfaceId.localeCompare(b.surfaceId))[0] ?? null;
  }
  function invalidateSupport(body) {
    if (byId.has(body.support)) {body.support = null; body.grounded = false;}
  }
  function carryActor(body, options = {}) {
    validBody(body);
    fields(options, ['tick', 'deltaSeconds', 'previous', 'resolveDisplacement'], 'carryActor options');
    const tick = tickNumber(options.tick ?? lastTick);
    const dt = seconds(options.deltaSeconds ?? (tick === lastTick ? deltaSeconds : 1 / 60));
    frame({tick, deltaSeconds: dt});
    if (paused) return {carried: false, reason: 'paused', surfaceId: null, dx: 0, dy: 0};
    if (actorTicks.get(body) === tick || body.id !== undefined && actorIds.has(body.id)) return {carried: false, reason: 'already-carried-this-tick', surfaceId: body.support ?? null, dx: 0, dy: 0};
    const top = contact(body, {previous: options.previous});
    if (!top) {invalidateSupport(body); return {carried: false, reason: 'no-observed-top-contact', surfaceId: null, dx: 0, dy: 0};}
    const surface = byId.get(top.surfaceId), direction = on ? surface.spec.directionOn : -surface.spec.directionOn;
    const distance = surface.spec.speedPxPerSecond * dt * (1 - top.fraction);
    const dx = surface.tangent.x * direction * distance;
    // A single additive carry may reach a genuine adjoining incline even with
    // zero/opposite intrinsic vx. Query the receiving top using the already
    // verified current contact, and sweep its real vertical correction in the
    // SAME movement. This never carries twice or waits buried at flat height.
    const supportedStart = {...body, y: top.y - body.h, vy: 0, grounded: true, support: top.surfaceId};
    const receiving = contact({...supportedStart, x: body.x + dx}, {previous: supportedStart});
    const receivingSurface = receiving ? byId.get(receiving.surfaceId) : surface;
    const next = sample(receivingSurface, {...body, x: body.x + dx});
    const targetFeet = next?.y ?? top.y + surface.tangent.y * direction * distance;
    const requested = {dx, dy: targetFeet - body.y - body.h};
    finite(body.x + requested.dx, 'transport target x'); finite(body.y + requested.dy, 'transport target y');
    let actual = {dx: 0, dy: 0}, blocked = false;
    if (Math.abs(requested.dx) > EPS || Math.abs(requested.dy) > EPS) {
      if (typeof options.resolveDisplacement !== 'function') fail('Conveyor transport requires caller resolveDisplacement against actual world collisions');
      // A detached rectangle stops a resolver accidentally changing intrinsic
      // motion, facing, or the live actor before its result has been checked.
      const resolved = options.resolveDisplacement({...body}, {...requested}, {surfaceId: top.surfaceId, kind: 'conveyor-contact-and-carry', tick, contact: copy(top)});
      if (!plain(resolved)) fail('resolveDisplacement must return an actual displacement or swept fraction');
      if ('fraction' in resolved) {
        finite(resolved.fraction, 'resolved fraction', 0, 1);
        actual = {dx: requested.dx * resolved.fraction, dy: requested.dy * resolved.fraction};
        blocked = resolved.fraction < 1 - EPS || !!resolved.blocked;
      } else {
        finite(resolved.dx, 'resolved dx'); finite(resolved.dy, 'resolved dy');
        actual = {dx: resolved.dx, dy: resolved.dy}; blocked = !!resolved.blocked;
        for (const axis of ['dx', 'dy']) if (Math.abs(actual[axis]) > Math.abs(requested[axis]) + EPS || actual[axis] * requested[axis] < -EPS) fail('Resolver cannot expand or reverse requested conveyor displacement');
      }
    }
    actorTicks.set(body, tick); if (body.id !== undefined) actorIds.add(body.id);
    body.x += actual.dx; body.y += actual.dy;
    const finalSurface = receivingSurface !== surface && !sample(receivingSurface, body) ? surface : receivingSurface;
    const finalTop = sample(finalSurface, body), supported = !!finalTop && Math.abs(body.y + body.h - finalTop.y) <= EPS;
    if (supported) {body.support = finalSurface.spec.id; body.grounded = true; body.vy = 0;}
    else invalidateSupport(body);
    const result = {carried: Math.abs(actual.dx) > EPS || Math.abs(actual.dy) > EPS, surfaceId: finalSurface.spec.id, transportSourceId: top.surfaceId, reason: supported ? receiving?.reason ?? top.reason : 'left-or-obstructed-top', dx: actual.dx, dy: actual.dy, requested, supported, blocked, contact: copy(top)};
    emit('conveyor-carry', {...result, actorId: body.id ?? null, tick}); return result;
  }
  function setPaused(value) {
    if (typeof value !== 'boolean') fail('Paused state must be boolean'); paused = value; return view();
  }
  function saveState() {
    switchState();
    return {format: 'conveyor-surfaces-state', version: 1, specSignature, tick: lastTick, deltaSeconds, paused, on, phases: definitions.map(spec => ({id: spec.id, treadDistancePx: phases.get(spec.id)})), carriedActorIds: [...actorIds].sort()};
  }
  function restore(input) {
    const state = typeof input === 'string' ? JSON.parse(input) : copy(input);
    fields(state, ['format', 'version', 'specSignature', 'tick', 'deltaSeconds', 'paused', 'on', 'phases', 'carriedActorIds'], 'conveyor state');
    if (state.format !== 'conveyor-surfaces-state' || state.version !== 1 || state.specSignature !== specSignature) fail('Conveyor state must match the exact authored definitions');
    if (state.tick !== null) tickNumber(state.tick);
    seconds(state.deltaSeconds);
    if (typeof state.paused !== 'boolean' || typeof state.on !== 'boolean') fail('Conveyor state booleans are invalid');
    if (!Array.isArray(state.phases) || state.phases.length !== definitions.length) fail('Conveyor state needs every stable surface phase');
    const nextPhases = new Map();
    for (const phase of state.phases) {
      fields(phase, ['id', 'treadDistancePx'], 'conveyor phase');
      if (!byId.has(phase.id) || nextPhases.has(phase.id)) fail('Conveyor state phase IDs are ambiguous');
      finite(phase.treadDistancePx, 'saved treadDistancePx', -Number.MAX_SAFE_INTEGER, Number.MAX_SAFE_INTEGER);
      nextPhases.set(phase.id, phase.treadDistancePx);
    }
    if (!Array.isArray(state.carriedActorIds) || state.carriedActorIds.length > 20_000) fail('Conveyor state actor deduplication is invalid');
    state.carriedActorIds.forEach(value => stableId(value, 'saved actor ID'));
    if (new Set(state.carriedActorIds).size !== state.carriedActorIds.length) fail('Conveyor state has duplicate actor IDs');
    if (state.tick === null && state.carriedActorIds.length) fail('Conveyor state cannot carry actors before a tick');
    // Validate the external switch before changing any controller state. The
    // caller owns switch restoration; restoring this controller cannot flip it.
    const currentOn = typeof isOn === 'function' ? isOn() : isOn;
    if (typeof currentOn !== 'boolean' || currentOn !== state.on) fail('Restore the owning switch state before restoring conveyors');
    lastTick = state.tick; deltaSeconds = state.deltaSeconds; paused = state.paused; on = state.on;
    phases = nextPhases; actorTicks = new WeakMap(); actorIds = new Set(state.carriedActorIds);
    return view();
  }
  return Object.freeze({frame, view, surfaceAtX, bodySupport, contact, carryActor, setPaused, reset, saveState, serialize: () => JSON.stringify(saveState()), restore, getSpecs: () => copy(definitions), ownsSupport: id => byId.has(id)});
}
