/** Opt-in Dry Bones lifecycle. All numeric tuning is authored, not calibrated SMM2 data. */
const copy=x=>JSON.parse(JSON.stringify(x));
const finite=(x,min,max)=>Number.isFinite(x)&&x>=min&&x<=max;
const frames=(x,max)=>Number.isInteger(x)&&finite(x,1,max);
const responses=['bounce','hurt','harmless'];
const fields=['kind','size','speed','direction','collapsedHeight','collapseFrames','recoverFrames','bounceSpeed','giantStompResponse'];

export function validateDryBonesVariant(room,id,rule){
 if(!rule||typeof rule!=='object'||Array.isArray(rule)||Object.keys(rule).some(k=>!fields.includes(k)))throw Error('Unknown Dry Bones variant field');
 const body=room.map.objects.find(a=>a.id===id&&a.kind==='walker');
 if(rule.kind!=='dry-bones'||!body||!finite(body.w,1,64)||!finite(body.h,2,64)||!['normal','giant'].includes(rule.size))throw Error('Dry Bones needs an existing native walker and explicit size behavior');
 if(!finite(rule.speed,.01,2)||![-1,1].includes(rule.direction)||!finite(rule.collapsedHeight,1,body.h-1)||!frames(rule.collapseFrames,36000)||!frames(rule.recoverFrames,3600)||!finite(rule.bounceSpeed,.1,12))throw Error('Dry Bones needs bounded authored motion, collapse and recovery tuning');
 if(rule.size==='giant'?!responses.includes(rule.giantStompResponse):rule.giantStompResponse!==undefined)throw Error('Giant Dry Bones needs an explicit authored ordinary-stomp response');
}

export function createSmm2DryBones(room,{emit=()=>{}}={}){
 const definitions=new Map(Object.entries(room.marioModules?.enemyVariants||{}).filter(([,v])=>v?.kind==='dry-bones').map(([id,rule])=>{
  validateDryBonesVariant(room,id,rule);
  return[id,{rule:copy(rule),body:copy(room.map.objects.find(a=>a.id===id&&a.kind==='walker'))}];
 })),actors=new Map();
 const diagnostic=(event,a,data={})=>emit('mario-module',{event,actorId:a.id,...data});
 const ownsActor=a=>!!a&&definitions.has(typeof a==='string'?a:a.id);
 function descriptor(id){const d=definitions.get(id);return d?{...d.rule,type:'dry-bones',w:d.body.w,h:d.body.h,tuningStatus:'authored-uncalibrated'}:null;}
 function publish(record){const {actor:a,state:s}=record;a.smm2DryBones={size:s.size,phase:s.phase,remainingFrames:s.remainingFrames,walkWidth:s.walkWidth,walkHeight:s.walkHeight,supportEligible:s.phase==='walking',tuningStatus:'authored-uncalibrated'};}
 function decorateEnemy(a){
  const d=definitions.get(a?.id);if(!d)return a;
  const old=actors.get(a.id);if(old?.actor===a)return a;
  if(a.w!==d.body.w||a.h!==d.body.h)throw Error('Dry Bones must preserve its authored native walker dimensions');
  const initial={x:a.x,y:a.y,w:a.w,h:a.h,vx:d.rule.speed*d.rule.direction,vy:Number.isFinite(a.vy)?a.vy:0,grounded:!!a.grounded,support:a.support??null,frame:a.frame};
  Object.assign(a,{type:'dry-bones',smm2EnemyKind:'dry-bones',vx:initial.vx,vy:initial.vy,standable:false,source:{...a.source,dryBones:true,giant:d.rule.size==='giant'}});
  const record={actor:a,initial,state:{size:d.rule.size,phase:'walking',remainingFrames:0,walkWidth:a.w,walkHeight:a.h,walkVx:initial.vx,lastStepTick:null,lastAttackTick:null,lastResult:null}};
  actors.set(a.id,record);publish(record);return a;
 }
 function recordFor(a){if(!ownsActor(a))return null;if(actors.get(a.id)?.actor!==a)decorateEnemy(a);return actors.get(a.id);}
 function supportEligible(a){const r=typeof a==='string'?actors.get(a):recordFor(a);return ownsActor(a)&&!a?.dead&&(!r||r.state.phase==='walking');}
 function contactRule(a){if(!ownsActor(a))return null;const r=typeof a==='string'?actors.get(a):recordFor(a),phase=r?.state.phase??'walking';return{handled:true,requiresContactHandler:true,harmful:phase==='walking',harmless:phase!=='walking',stompable:false,shoeStompable:false,fireImmune:true,solidTop:false,supportEligible:phase==='walking',phase,type:'dry-bones'};}
 function collapse(a,{tick,attack}={}){
  const r=recordFor(a);if(!r||a.dead)return null;const s=r.state,rule=definitions.get(a.id).rule;
  if(s.phase!=='walking')return{handled:true,action:'harmless',harmless:true,harmful:false,collapse:false,bounce:false,phase:s.phase};
  const bottom=a.y+a.h;s.walkVx=Number.isFinite(a.stackWalkVx)?a.stackWalkVx:(a.vx||rule.speed*rule.direction);
  s.phase='collapsed';s.remainingFrames=rule.collapseFrames;s.lastStepTick=tick??null;
  a.y=bottom-rule.collapsedHeight;a.h=rule.collapsedHeight;a.vx=0;a.standable=false;a.frame='collapsed';publish(r);
  diagnostic('dry-bones-collapse',a,{size:s.size,attack,tuningStatus:'authored-uncalibrated'});
  return{handled:true,action:'collapse',harmless:true,harmful:false,collapse:true,bounce:true,bounceSpeed:rule.bounceSpeed,changed:true,phase:s.phase,points:null,tuningStatus:'authored-uncalibrated'};
 }
 /** Caller establishes the real collision face/attack. This method never kills or awards points. */
 function playerEnemyContact(a,{tick,attack='body'}={}){
  const r=recordFor(a);if(!r||a.dead)return null;const s=r.state,rule=definitions.get(a.id).rule;
  if(!['body','stomp','bone-shell-stomp','ground-pound'].includes(attack))throw Error('Unknown Dry Bones contact attack');
  if(attack!=='body'&&tick!==undefined&&s.lastAttackTick===tick)return{...copy(s.lastResult),changed:false,bounce:false,repeated:true};
  let result;
  if(s.phase!=='walking')result={handled:true,action:'harmless',harmless:true,harmful:false,collapse:false,bounce:false,phase:s.phase};
  else if(attack==='body')result={handled:true,action:'hurt',harmful:true,harmless:false,collapse:false,bounce:false,phase:s.phase};
  else if(s.size==='normal'||attack==='bone-shell-stomp'||attack==='ground-pound')result=collapse(a,{tick,attack});
  else{const response=rule.giantStompResponse;result={handled:true,action:'resisted-stomp',collapse:false,changed:false,bounce:response==='bounce',...(response==='bounce'?{bounceSpeed:rule.bounceSpeed}:{}),harmful:response==='hurt',harmless:response==='harmless'||response==='bounce',requiresHostResponse:false,authoredResponse:response,unverified:'giant-ordinary-stomp-player-response',phase:s.phase,points:null};}
  if(attack!=='body'){s.lastAttackTick=tick??null;s.lastResult=copy(result);}return result;
 }
 /** Native host motion still moves the actual body; only this lifecycle is handled here. */
 function stepEnemy(a,{tick,canStand}={}){
  const r=recordFor(a);if(!r||a.dead)return false;const s=r.state,rule=definitions.get(a.id).rule;
  if(!Number.isInteger(tick))throw Error('Dry Bones lifecycle needs an integer tick');
  if(s.lastStepTick===tick)return false;s.lastStepTick=tick;
  if(s.phase==='walking')return false;
  a.vx=0;a.standable=false;
  if(s.remainingFrames>0){s.remainingFrames--;if(s.phase==='collapsed'){if(s.remainingFrames===0){s.phase='recovering';s.remainingFrames=rule.recoverFrames;a.frame='recovering';diagnostic('dry-bones-recovering',a);}publish(r);return false;}if(s.remainingFrames>0){publish(r);return false;}}
  if(s.phase==='recovering'){
   // Exactly one bounded callback per distinct tick; no timer-dependent teleport or retry loop.
   const candidate=Object.freeze({id:a.id,x:a.x,y:a.y+a.h-s.walkHeight,w:s.walkWidth,h:s.walkHeight});
   if(typeof canStand!=='function'||canStand(candidate)!==true){publish(r);return false;}
   a.x=candidate.x;a.y=candidate.y;a.w=candidate.w;a.h=candidate.h;a.vx=s.walkVx;a.frame='';s.phase='walking';s.remainingFrames=0;publish(r);diagnostic('dry-bones-recovered',a);
  }
  return false;
 }
 function view(){return [...actors.values()].map(r=>({actorId:r.actor.id,x:r.actor.x,y:r.actor.y,w:r.actor.w,h:r.actor.h,...copy(r.actor.smm2DryBones)}));}
 function reset(){for(const r of actors.values()){const {actor:a,initial:i,state:s}=r;Object.assign(a,{x:i.x,y:i.y,w:i.w,h:i.h,vx:i.vx,vy:i.vy,grounded:i.grounded,support:i.support,standable:false});if(i.frame===undefined)delete a.frame;else a.frame=i.frame;Object.assign(s,{phase:'walking',remainingFrames:0,walkVx:i.vx,lastStepTick:null,lastAttackTick:null,lastResult:null});publish(r);}}
 return Object.freeze({ownsActor,descriptor,decorateEnemy,contactRule,playerEnemyContact,stepEnemy,supportEligible,view,reset});
}
