// Independent, finite Snake Block occupancy experiment. No qmap or Stage mutation.
import {createSnakeWindowPreview,parseSnakeWindowPreview,serializeSnakeWindowPreview} from './editor-snake-window-preview.mjs';

export function createNeutralSnakeWindowPreviewDocument(){
 return {format:'snake-window-preview',version:1,id:'neutral-snake-window',tileSize:16,origin:{x:32,y:32},path:[{id:'start',x:0,y:80},{id:'lower-right',x:80,y:80},{id:'middle-right',x:80,y:64},{id:'front-right',x:128,y:64},{id:'upper-right',x:128,y:48},{id:'beyond-window',x:0,y:48}],lengthCells:9,initialHeadDistancePx:152,speedPxPerSecond:60,observationDurationMs:1334.668,parameterStatus:'authored-not-calibrated'};
}

// Replacement is deliberately transactional: construction must succeed first.
export function createSnakeWindowPreviewEditorSession(initialDocument=createNeutralSnakeWindowPreviewDocument()){
 let controller=createSnakeWindowPreview(initialDocument),paused=true;
 controller.setPaused(true);
 const api={
  snapshot:()=>controller.snapshot(),getDocument:()=>controller.getDocument(),isPaused:()=>paused,
  tick(deltaMs=1000/60){controller.tick(deltaMs);return controller.snapshot();},
  setPaused(value){if(typeof value!=='boolean')throw new TypeError('paused must be a boolean');controller.setPaused(value);paused=value;return controller.snapshot();},
  reset(){controller.reset();controller.setPaused(true);paused=true;return controller.snapshot();},
  replaceDocument(candidate){const replacement=createSnakeWindowPreview(candidate);replacement.setPaused(true);controller=replacement;paused=true;return controller.getDocument();},
  applyFields(fields){const next={...controller.getDocument(),...fields};return api.replaceDocument(next);},
  importText(text){return api.replaceDocument(parseSnakeWindowPreview(text));},
  exportText:()=>serializeSnakeWindowPreview(controller.getDocument()),
  seekMs(value){const ms=Number(value),duration=controller.getDocument().observationDurationMs;if(!Number.isFinite(ms)||ms<0||ms>duration)throw new RangeError('seek time must be within the observation window');controller.reset();controller.setPaused(false);if(ms>0)controller.tick(ms);controller.setPaused(true);paused=true;return controller.snapshot();}
 };
 return Object.freeze(api);
}

export function snakeWindowStatusLabel(snapshot,paused=true){
 if(snapshot.status==='preview-complete'||snapshot.elapsedMs>=snapshot.effectiveDurationMs||snapshot.elapsedMs>=snapshot.observationDurationMs)return '观察窗口结束';
 return paused?'已暂停':'观察中';
}

export function referenceFrameTimeline(observations){
 if(!observations||typeof observations!=='object')return [];
 const rows=Array.isArray(observations)?observations:observations.frames??observations.frameTimesSeconds??observations.timestampsSeconds??observations.timestamps??[];
 if(!Array.isArray(rows))return [];
 return rows.map((row,index)=>({index:typeof row==='object'?(row?.index??row?.frame??index):index,seconds:typeof row==='number'?row:Number(row?.timestampSeconds??row?.timeSeconds??row?.seconds??row?.timestamp??row?.pts_time),...(typeof row?.cameraX==='number'&&Number.isFinite(row.cameraX)?{cameraX:row.cameraX}:{}),...(Array.isArray(row?.headWorldCenter)?{headWorldCenter:[...row.headWorldCenter]}:{})})).filter(row=>Number.isFinite(row.seconds)&&row.seconds>=0).sort((a,b)=>a.seconds-b.seconds);
}

export function referenceFrameAtTime(timeline,seconds){
 if(!timeline.length||!Number.isFinite(seconds))return null;
 let current=timeline[0];for(const frame of timeline){if(frame.seconds>seconds+0.000001)break;current=frame;}return {...current};
}

export const SNAKE_WINDOW_EDITOR_CSS=`
.snake-window-editor{color:#182d3e;background:#f4f7fa;font:15px/1.55 system-ui,-apple-system,"Segoe UI",sans-serif;padding:24px;box-sizing:border-box;border-radius:16px;max-width:1400px;margin:auto}
.snake-window-editor *{box-sizing:border-box}.snake-window-editor h1{font-size:26px;line-height:1.3;margin:0 0 8px}.snake-window-editor h2{font-size:17px;margin:0 0 10px}.snake-window-editor p{margin:6px 0 12px}.snake-window-editor .snake-muted{color:#516579;font-size:13px}.snake-window-editor .snake-scenes{display:grid;grid-template-columns:1fr 1fr;gap:18px}.snake-window-editor .snake-panel{background:white;border:1px solid #dce5ec;padding:18px;border-radius:12px;min-width:0}.snake-window-editor canvas,.snake-window-editor video,.snake-window-editor .snake-reference-empty{display:block;width:100%;aspect-ratio:16/9;background:#eaf1f7;border:1px solid #d7e2eb;border-radius:8px}.snake-window-editor canvas{height:auto}.snake-window-editor video{object-fit:contain;background:#111820}.snake-window-editor .snake-reference-empty{display:flex;align-items:center;justify-content:center;padding:28px;color:#516579;text-align:center}.snake-window-editor .snake-actions{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:12px 0}.snake-window-editor button,.snake-window-editor input,.snake-window-editor textarea{font:inherit}.snake-window-editor button{border:1px solid #bdcddb;border-radius:7px;padding:7px 13px;background:#f8fafc;color:#203b50;cursor:pointer}.snake-window-editor button:hover{background:#e8f2fa}.snake-window-editor button:disabled{opacity:.55;cursor:default}.snake-window-editor input[type=range]{width:100%;accent-color:#197fc2}.snake-window-editor input[type=number],.snake-window-editor input[type=text],.snake-window-editor textarea{width:100%;border:1px solid #bdcddb;border-radius:6px;background:#fff;padding:7px;color:#18364b}.snake-window-editor textarea{font:13px/1.5 ui-monospace,monospace;min-height:132px;resize:vertical}.snake-window-editor .snake-settings{margin-top:18px}.snake-window-editor .snake-fields{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}.snake-window-editor label{display:block;font-size:13px;color:#415b70}.snake-window-editor .snake-path-field{margin-top:12px}.snake-window-editor .snake-legend{display:flex;gap:14px;flex-wrap:wrap;font-size:12px;margin-top:10px}.snake-window-editor .snake-swatch{display:inline-block;width:12px;height:12px;margin-right:5px;border-radius:2px;vertical-align:-1px}.snake-window-editor .snake-error{color:#a02626;min-height:23px}.snake-window-editor output{font-variant-numeric:tabular-nums}.snake-window-editor [hidden]{display:none!important}.snake-window-editor .snake-provenance{overflow-wrap:anywhere}.snake-window-editor .snake-file{max-width:100%}
@media(max-width:800px){.snake-window-editor{padding:14px}.snake-window-editor .snake-scenes{grid-template-columns:1fr}.snake-window-editor .snake-fields{grid-template-columns:repeat(2,minmax(0,1fr))}.snake-window-editor .snake-panel{padding:12px}}
`;

export function snakeWindowViewport(previewDocument,width=960,height=540){
 const {tileSize:tile,origin,path}=previewDocument;
 const points=path.map(p=>({x:origin.x+p.x,y:origin.y+p.y}));
 const minX=Math.min(...points.map(p=>p.x))-tile*2,minY=Math.min(...points.map(p=>p.y))-tile*2,maxX=Math.max(...points.map(p=>p.x))+tile*3,maxY=Math.max(...points.map(p=>p.y))+tile*3;
 const scale=Math.min(width/(maxX-minX),height/(maxY-minY),4);
 return {scale,offsetX:(width-(maxX-minX)*scale)/2-minX*scale,offsetY:(height-(maxY-minY)*scale)/2-minY*scale,width,height,minX,minY,maxX,maxY};
}

export function drawSnakeWindowPreview(canvas,previewDocument,snapshot,{referenceViewport=null}={}){
 const ctx=canvas.getContext('2d');if(!ctx)return null;
 const width=canvas.width||960,height=canvas.height||540,tile=previewDocument.tileSize,view=referenceViewport?{scale:width/384,offsetX:-(referenceViewport.cameraX||0)*width/384,offsetY:0,width,height,minX:referenceViewport.cameraX||0,minY:0,maxX:(referenceViewport.cameraX||0)+384,maxY:216}:snakeWindowViewport(previewDocument,width,height);
 ctx.clearRect(0,0,width,height);ctx.fillStyle='#f3f8fc';ctx.fillRect(0,0,width,height);
 ctx.save();ctx.translate(view.offsetX,view.offsetY);ctx.scale(view.scale,view.scale);
 ctx.lineWidth=1/view.scale;ctx.strokeStyle='#dce7ef';ctx.beginPath();
 const gridOriginX=previewDocument.origin.x-tile/2,gridOriginY=previewDocument.origin.y-tile/2;
 for(let x=Math.floor((view.minX-gridOriginX)/tile)*tile+gridOriginX;x<=view.maxX;x+=tile){ctx.moveTo(x,view.minY);ctx.lineTo(x,view.maxY);}
 for(let y=Math.floor((view.minY-gridOriginY)/tile)*tile+gridOriginY;y<=view.maxY;y+=tile){ctx.moveTo(view.minX,y);ctx.lineTo(view.maxX,y);}ctx.stroke();
 ctx.strokeStyle='#8fa6b6';ctx.lineWidth=2/view.scale;ctx.setLineDash([6/view.scale,4/view.scale]);ctx.beginPath();
 previewDocument.path.forEach((p,i)=>{const x=previewDocument.origin.x+p.x,y=previewDocument.origin.y+p.y;i?ctx.lineTo(x,y):ctx.moveTo(x,y);});ctx.stroke();ctx.setLineDash([]);
 for(const cell of snapshot.renderCells){ctx.fillStyle=cell.role==='head'?'#ef943c':cell.role==='tail'?'#9b70cb':'#258ecd';ctx.fillRect(cell.x,cell.y,cell.w??tile,cell.h??tile);ctx.strokeStyle='#fff';ctx.lineWidth=1/view.scale;ctx.strokeRect(cell.x,cell.y,cell.w??tile,cell.h??tile);}
 // Static support/contact cells are explicitly separate from moving end tiles.
 ctx.strokeStyle='#164b72';ctx.lineWidth=1.5/view.scale;for(const cell of snapshot.fixedContactCells){ctx.strokeRect(cell.x+1/view.scale,cell.y+1/view.scale,(cell.w??tile)-2/view.scale,(cell.h??tile)-2/view.scale);}
 ctx.restore();return view;
}

export function mountSnakeWindowPreviewEditor({parent,initialDocument=createNeutralSnakeWindowPreviewDocument(),reference=null,animate=true,injectStyle=true,onDocumentChange=()=>{}}={}){
 if(!parent)throw new TypeError('A parent element is required');
 const dom=parent.ownerDocument||globalThis.document,session=createSnakeWindowPreviewEditorSession(initialDocument),controls=new Map(),root=dom.createElement('section');root.className='snake-window-editor';parent.append(root);
 if(injectStyle){const style=dom.createElement('style');style.textContent=SNAKE_WINDOW_EDITOR_CSS;root.append(style);}
 const node=(tag,text,container=root)=>{const el=dom.createElement(tag);if(text!==undefined)el.textContent=text;container.append(el);return el;};
 const control=(el,name)=>{el.setAttribute('data-snake-window-control',name);controls.set(name,el);return el;};
 const button=(name,label,fn,container)=>{const el=control(node('button',label,container),name);el.type='button';el.onclick=fn;return el;};
 node('h1','蛇块 · 有限观察窗口');node('p','独立的占格几何实验：头尾沿路径前进，中间占格保持世界位置。数值由作者设置，未按原作标定。').className='snake-muted';
 const scenes=node('div');scenes.className='snake-scenes';const sourcePanel=node('article',undefined,scenes);sourcePanel.className='snake-panel';const modelPanel=node('article',undefined,scenes);modelPanel.className='snake-panel';
 node('h2',reference?.videoDataUrl?'原动态参考 · 独立时间轴':'参考区域',sourcePanel);
 let video=null,referenceSeek=null,referenceTime=null,referenceSync=null,referenceView=null;const timeline=referenceFrameTimeline(reference?.observations);
 if(reference?.videoDataUrl){
  video=control(node('video',undefined,sourcePanel),'reference-video');video.controls=true;video.preload='metadata';video.playsInline=true;video.src=reference.videoDataUrl;if(reference.posterDataUrl)video.poster=reference.posterDataUrl;
  const timeLabel=node('label','原片时间',sourcePanel);referenceSeek=control(node('input',undefined,timeLabel),'reference-time');referenceSeek.type='range';referenceSeek.min='0';referenceSeek.max=String(reference.durationSeconds??timeline.at(-1)?.seconds??0);referenceSeek.step='0.001';referenceSeek.value='0';referenceTime=control(node('output',undefined,sourcePanel),'reference-time-output');
  const showReferenceTime=()=>{const seconds=Number(video.currentTime)||0,duration=Number(video.duration);if(Number.isFinite(duration)&&duration>0)referenceSeek.max=String(duration);referenceSeek.value=String(seconds);const frame=referenceFrameAtTime(timeline,seconds);referenceTime.textContent=`原片 ${seconds.toFixed(3)} s${frame?` · 已解码帧 ${frame.index} @ ${frame.seconds.toFixed(6)} s`:''}${timeline.length&&seconds>=timeline.at(-1).seconds?' · 原片观察窗口结束':''}${video.ended?' · 原片播放结束':''}`;if(referenceSync?.checked&&!disposed){session.seekMs(Math.min(seconds*1000,session.getDocument().observationDurationMs));refresh();}};
  for(const event of ['timeupdate','loadedmetadata','seeked','ended','play','pause'])video.addEventListener(event,showReferenceTime);video.addEventListener('error',()=>{referenceTime.textContent='原片未能加载或解码；预览仍可独立编辑。';});referenceSeek.oninput=()=>{video.pause();video.currentTime=Number(referenceSeek.value);showReferenceTime();};showReferenceTime();
  button('reference-to-preview','把预览定位到原片时间',()=>attempt(()=>session.seekMs(Math.min((Number(video.currentTime)||0)*1000,session.getDocument().observationDurationMs))),sourcePanel);
  const syncLabel=node('label',undefined,sourcePanel);referenceSync=control(node('input',undefined,syncLabel),'reference-sync');referenceSync.type='checkbox';referenceSync.checked=reference.syncByDefault===true;node('span','按原片自身时间联动预览',syncLabel);referenceSync.onchange=showReferenceTime;
  node('p','原片用自身时钟播放和定位。勾选联动时，以实际原片时间计算右侧占格；数值可改，未认定为原作精确参数。',sourcePanel).className='snake-muted';
  node('p',reference.label||'本地嵌入的实际动态参考',sourcePanel).className='snake-muted snake-provenance';if(reference.provenance)node('p',reference.provenance,sourcePanel).className='snake-muted snake-provenance';
 }else{node('div','此文件未嵌入原动态。右侧仅为作者设置的中性几何预览。',sourcePanel).className='snake-reference-empty';node('p','构建时可显式加入本地原片与观测时间戳；静态图片不用于代替连续原片。',sourcePanel).className='snake-muted';}
 node('h2','占格几何预览',modelPanel);const canvas=control(node('canvas',undefined,modelPanel),'canvas');canvas.width=960;canvas.height=540;canvas.setAttribute('aria-label','蛇块路径与固定占格几何，蓝色中格、橙色前沿、紫色后沿');
 const legend=node('div',undefined,modelPanel);legend.className='snake-legend';for(const [color,label]of [['#258ecd','固定中格'],['#ef943c','移动前沿'],['#9b70cb','移动后沿'],['#8fa6b6','作者路径']]){const item=node('span',undefined,legend),swatch=node('i',undefined,item);swatch.className='snake-swatch';swatch.style.background=color;node('span',label,item);}
 const stopSync=()=>{if(referenceSync)referenceSync.checked=false;};
 const actions=node('div',undefined,modelPanel);actions.className='snake-actions';const toggle=button('pause','继续',()=>{stopSync();session.setPaused(!session.isPaused());lastFrame=null;refresh();},actions);button('reset','重置',()=>{stopSync();session.reset();lastFrame=null;refresh();},actions);const status=control(node('output',undefined,actions),'status');
 const previewLabel=node('label','预览时间（毫秒）',modelPanel),previewSeek=control(node('input',undefined,previewLabel),'time');previewSeek.type='range';previewSeek.min='0';previewSeek.step='0.001';previewSeek.value='0';previewSeek.oninput=()=>{stopSync();attempt(()=>session.seekMs(Number(previewSeek.value)));};const previewTime=control(node('output',undefined,modelPanel),'time-output');
 if(timeline.some(frame=>Number.isFinite(frame.cameraX))){const viewLabel=node('label',undefined,modelPanel);referenceView=control(node('input',undefined,viewLabel),'reference-viewport');referenceView.type='checkbox';referenceView.checked=true;node('span','采用原片 384×216 取景及对应时刻镜头偏移',viewLabel);referenceView.onchange=()=>refresh();}
 node('p','仅显示有限窗口中的占格运动。未验证启动方式、路径终点、玩家随动或完整关卡规则。',modelPanel).className='snake-muted';
 const settings=node('section');settings.className='snake-panel snake-settings';node('h2','编辑独立预览文档',settings);node('p','所有更改先验证整份预览契约；错误时保留上一次有效配置和当前时间。',settings).className='snake-muted';const fields=node('div',undefined,settings);fields.className='snake-fields';
 const field=(key,label,type='number')=>{const el=control(node('input',undefined,node('label',label,fields)),key);el.type=type;if(type==='number')el.step='any';return el;};
 field('id','预览 ID','text');field('lengthCells','节长（格）');field('speedPxPerSecond','速度（像素／秒）');field('initialHeadDistancePx','初始前沿距离（像素）');field('observationDurationMs','观察窗口（毫秒）');field('originX','原点 X（世界像素）');field('originY','原点 Y（世界像素）');
 const pathLabel=node('label','路径 JSON：相对原点的像素中心坐标（16 的倍数），稳定 id，正交边可跨多格',settings);pathLabel.className='snake-path-field';const pathInput=control(node('textarea',undefined,pathLabel),'path');pathInput.spellcheck=false;
 const fileActions=node('div',undefined,settings);fileActions.className='snake-actions';button('apply','验证并应用',()=>attempt(()=>{const num=key=>{const text=String(controls.get(key).value).trim();if(!text)throw new Error(`请填写 ${key}`);const n=Number(text);if(!Number.isFinite(n))throw new Error(`${key} 必须是有限数字`);return n;};session.applyFields({id:controls.get('id').value.trim(),lengthCells:num('lengthCells'),speedPxPerSecond:num('speedPxPerSecond'),initialHeadDistancePx:num('initialHeadDistancePx'),observationDurationMs:num('observationDurationMs'),origin:{x:num('originX'),y:num('originY')},path:JSON.parse(pathInput.value)});importGeneration++;stopSync();populate();onDocumentChange(session.getDocument());}),fileActions);
 button('export','导出 .snake-preview.json',()=>{const url=URL.createObjectURL(new Blob([session.exportText()],{type:'application/json'})),anchor=dom.createElement('a');anchor.href=url;anchor.download=session.getDocument().id.replace(/[^a-zA-Z0-9_-]/g,'_')+'.snake-preview.json';anchor.click();URL.revokeObjectURL(url);},fileActions);
 const importLabel=node('label','导入 .snake-preview.json',fileActions),fileInput=control(node('input',undefined,importLabel),'import');fileInput.type='file';fileInput.accept='.json,.snake-preview.json,application/json';fileInput.className='snake-file';let importGeneration=0;
 fileInput.onchange=async()=>{const file=fileInput.files?.[0];if(!file)return;const generation=++importGeneration;try{const text=await file.text();if(disposed||generation!==importGeneration)return;session.importText(text);stopSync();populate();onDocumentChange(session.getDocument());error.textContent='';lastFrame=null;refresh();}catch(e){if(!disposed&&generation===importGeneration)error.textContent=`导入失败：${e.message}`;}finally{if(generation===importGeneration)fileInput.value='';}};
 const error=control(node('p','',settings),'error');error.className='snake-error';error.setAttribute('role','alert');node('p','格式 snake-window-preview v1 · tileSize 16 · parameterStatus authored-not-calibrated。此文档独立于 qmap／qcollection，不保存为 Stage 新字段。',settings).className='snake-muted';
 let disposed=false,raf=null,lastFrame=null;
 function populate(){const d=session.getDocument();for(const key of ['id','lengthCells','speedPxPerSecond','initialHeadDistancePx','observationDurationMs'])controls.get(key).value=String(d[key]);controls.get('originX').value=String(d.origin.x);controls.get('originY').value=String(d.origin.y);pathInput.value=JSON.stringify(d.path,null,2);}
 function refresh(){const snapshot=session.snapshot(),d=session.getDocument(),referenceFrame=referenceView?.checked?referenceFrameAtTime(timeline,snapshot.elapsedMs/1000):null;drawSnakeWindowPreview(canvas,d,snapshot,{referenceViewport:referenceFrame&&Number.isFinite(referenceFrame.cameraX)?referenceFrame:null});previewSeek.max=String(snapshot.effectiveDurationMs);previewSeek.value=String(snapshot.elapsedMs);previewTime.textContent=`${snapshot.elapsedMs.toFixed(3)} / ${snapshot.effectiveDurationMs.toFixed(3)} ms`;status.textContent=snakeWindowStatusLabel(snapshot,session.isPaused());if(snapshot.status!=='preview-complete'&&referenceSync?.checked)status.textContent=video.paused?'原片定位':'随原片观察中';toggle.textContent=session.isPaused()?'继续':'暂停';toggle.disabled=snapshot.status==='preview-complete';return snapshot;}
 function attempt(fn){try{fn();error.textContent='';lastFrame=null;refresh();return true;}catch(e){error.textContent=e.message;return false;}}
 function frame(now){if(disposed)return;const delta=lastFrame===null?0:Math.max(0,now-lastFrame);lastFrame=now;if(referenceSync?.checked&&video){session.seekMs(Math.min((Number(video.currentTime)||0)*1000,session.getDocument().observationDurationMs));refresh();}else if(!session.isPaused()&&delta>0){session.tick(delta);refresh();}raf=requestAnimationFrame(frame);}
 const visibility=()=>{lastFrame=null;};dom.addEventListener?.('visibilitychange',visibility);populate();refresh();if(animate)raf=requestAnimationFrame(frame);
 return Object.freeze({root,canvas,controls,session,refresh,importText(text){const ok=attempt(()=>{session.importText(text);importGeneration++;stopSync();populate();onDocumentChange(session.getDocument());});return ok;},dispose(){disposed=true;importGeneration++;if(raf!==null)cancelAnimationFrame(raf);dom.removeEventListener?.('visibilitychange',visibility);video?.pause();root.remove();}});
}
