/** Opt-in Shoe/Goomba-in-Shoe adapter. Native source bodies describe shoe feet.
 * Host owns score, NPC defeat, damage, room transitions and block destruction.
 * All numbers, composite bounds and optional flutter are author approximations. */
import {validateSmm2BoneShellsRoom,boneShellDefinitions,boneSeatInset,validateBonePlayingDead} from './editor-smm2-bone-shells.mjs';
const EPS=1e-7,OWNER=Symbol('smm2-shoes-owner');
const copy=v=>structuredClone(v),clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
const finite=(n,a,b)=>Number.isFinite(n)&&n>=a&&n<=b;
const integer=(n,a,b)=>Number.isSafeInteger(n)&&finite(n,a,b);
const unsafe=k=>['__proto__','prototype','constructor'].includes(k);
const plain=v=>v&&typeof v==='object'&&!Array.isArray(v)&&[Object.prototype,null].includes(Object.getPrototypeOf(v));
const safeId=v=>typeof v==='string'&&v.length>0&&v.length<=128&&!/[\u0000-\u001f\u007f]/.test(v)&&!unsafe(v);
const fail=s=>{throw Error(s);};
const rect=a=>a&&['x','y','w','h'].every(k=>Number.isFinite(a[k]))&&a.w>0&&a.h>0;
const live=a=>a&&!a.dead&&!a.dying&&!a.removed&&!a.taken;
const body=a=>({x:a.x,y:a.y,w:a.w,h:a.h});
const xOverlap=(a,b)=>a.x+a.w>b.x+EPS&&a.x<b.x+b.w-EPS;
const overlap=(a,b)=>xOverlap(a,b)&&a.y+a.h>b.y+EPS&&a.y<b.y+b.h-EPS;
const union=boxes=>{const x=Math.min(...boxes.map(a=>a.x)),y=Math.min(...boxes.map(a=>a.y));return{x,y,w:Math.max(...boxes.map(a=>a.x+a.w))-x,h:Math.max(...boxes.map(a=>a.y+a.h))-y};};
const typeOf=a=>(a?.type||a?.kind||'').replace(/^(enemy-|marker-)/,'').toLowerCase();
const muncher=a=>a?.smm2EnemyKind==='muncher'||['muncher','study-muncher'].includes(typeOf(a));
const spike=a=>a?.spikeTrap===true;
const nativeStompable=a=>/^(walker|goomba|koopa|beetle|hammerbro)$/.test(typeOf(a));
export const SMM2_SHOES_VERSION=1;
export const SMM2_SHOE_TUNING=Object.freeze({gravity:.4375,maxFallSpeed:4.25,npcSpeed:.5,npcHopSpeed:1.8,npcWingHopSpeed:3.3,npcHopFrames:36,seatInset:4,npcHeadHeight:8,boardingTolerance:1.01,stompBounceSpeed:4.1333333,ejectSpeed:4.1333333,groundPoundSpeed:7,flutterFrames:0,flutterFallSpeed:.5,walkHopSpeed:0,walkHopFrames:8,remountLockFrames:2,blastSpeed:1.8,blastRange:64,blastWidth:12,blastHeight:12,blastLifetimeFrames:36});
const leafFields=['id','kind','size','winged','occupant','tuning','crouchCompatible'];
function fields(value,allowed,label,required=[]){
 if(!plain(value))fail('Invalid '+label);
 for(const key of Object.keys(value))if(unsafe(key)||!allowed.includes(key))fail('Unknown '+label+' field: '+key);
 for(const key of required)if(!Object.hasOwn(value,key))fail('Missing '+label+' field: '+key);
}
function validateTuning(value={},height=64){
 fields(value,Object.keys(SMM2_SHOE_TUNING),'SMM2 Shoe tuning');const q={...SMM2_SHOE_TUNING,...value};
 for(const key of ['gravity','npcSpeed','npcHopSpeed','npcWingHopSpeed','walkHopSpeed'])if(!finite(q[key],0,16))fail('Invalid SMM2 Shoe '+key);
 for(const key of ['maxFallSpeed','stompBounceSpeed','ejectSpeed','groundPoundSpeed'])if(!finite(q[key],.001,64))fail('Invalid SMM2 Shoe '+key);
 if(!finite(q.seatInset,0,height)||!finite(q.npcHeadHeight,.001,64)||!finite(q.boardingTolerance,0,2)||!finite(q.flutterFallSpeed,0,16))fail('Invalid SMM2 Shoe body or contact tuning');
 for(const key of ['npcHopFrames','walkHopFrames'])if(!integer(q[key],1,36000))fail('Invalid SMM2 Shoe hop interval');
 for(const key of ['flutterFrames','remountLockFrames'])if(!integer(q[key],0,36000))fail('Invalid SMM2 Shoe frame tuning');
 if(!finite(q.blastSpeed,.001,16)||!finite(q.blastRange,0,4096)||!finite(q.blastWidth,1,64)||!finite(q.blastHeight,1,64)||!integer(q.blastLifetimeFrames,1,36000))fail('Invalid SMM2 Shoe landing blast tuning');return q;
}
/** Leaf validation deliberately leaves sibling validation to the importer. */
export function validateSmm2ShoesRoom(room,spec=room?.smm2Mechanics){
 if(spec===undefined)return;
 if(!plain(spec)||Object.keys(spec).some(unsafe)||spec.version!==1)fail('Invalid SMM2 mechanics version or unsafe field');
 validateSmm2BoneShellsRoom(room);
 if(spec.shoes===undefined)return;
 if(!Array.isArray(spec.shoes)||spec.shoes.length>256)fail('Invalid SMM2 Shoe list');
 const map=room?.map;if(!map||!finite(map.width,1,32768)||!finite(map.height,1,4096)||!Array.isArray(map.objects))fail('SMM2 Shoes need native room bounds and objects');
 const nativeIds=[...(map.geometry||[]),...map.objects,...(room.markers||[])].map(a=>a.id),ids=new Set();
 for(const q of spec.shoes){
  fields(q,leafFields,'SMM2 Shoe',['id','kind','size','winged','occupant']);
  if(!safeId(q.id)||ids.has(q.id))fail('Duplicate or invalid SMM2 Shoe ID');ids.add(q.id);
  if(!['shoe','stiletto'].includes(q.kind)||!['small','big'].includes(q.size)||typeof q.winged!=='boolean'||!['goomba','empty'].includes(q.occupant))fail('Invalid SMM2 Shoe variant or occupant');
  if(q.crouchCompatible!==undefined&&typeof q.crouchCompatible!=='boolean')fail('Invalid SMM2 Shoe crouch compatibility');
  const a=map.objects.find(a=>a.id===q.id);
  if(nativeIds.filter(id=>id===q.id).length!==1||!a||a.kind!=='walker'||!rect(a)||!finite(a.w,1,64)||!finite(a.h,1,64)||!finite(a.x,0,map.width-a.w)||!finite(a.y,0,map.height-a.h))fail('SMM2 Shoe needs one matching native walker foot body inside the room');
  validateTuning(q.tuning,a.h);
 }
}
function interval(position,delta,min,max){if(Math.abs(delta)<EPS)return position>min+EPS&&position<max-EPS?{entry:-Infinity,exit:Infinity}:null;const a=(min-position)/delta,b=(max-position)/delta;return{entry:Math.min(a,b),exit:Math.max(a,b)};}
function sweptRect(a,delta,b,{topSurface=false}={}){
 // A landing wave may physically touch the Muncher's upper surface without
 // entering its body. Keep that exact plane inclusive only for typed targets;
 // world solids/walls retain the ordinary strict volume sweep.
 const touchingSurface=topSurface&&Math.abs(delta.y)<=EPS&&Math.abs(a.y+a.h-b.y)<=EPS;
 const x=interval(a.x,delta.x,b.x-a.w,b.x+b.w),y=touchingSurface?{entry:-Infinity,exit:Infinity}:interval(a.y,delta.y,b.y-a.h,b.y+b.h);if(!x||!y)return null;
 const entry=Math.max(x.entry,y.entry),exit=Math.min(x.exit,y.exit),embedded=overlap(a,b)||touchingSurface&&xOverlap(a,b);
 if(!embedded&&(entry<-EPS||entry>1+EPS||exit<Math.max(0,entry)-EPS))return null;
 return{fraction:embedded?0:clamp(entry,0,1),normal:x.entry>y.entry?{x:-Math.sign(delta.x),y:0}:{x:0,y:-Math.sign(delta.y)},embedded};
}
function topContact(a,b,fromA,fromB,tolerance=EPS){
 if(![a,b,fromA,fromB].every(rect))return null;
 const start=fromA.y+fromA.h-fromB.y,end=a.y+a.h-b.y,delta=end-start;
 if(delta<=EPS||start>tolerance||end<-EPS)return null;
 const fraction=clamp(-start/delta,0,1),at={...fromA,x:fromA.x+(a.x-fromA.x)*fraction,y:fromA.y+(a.y-fromA.y)*fraction},target={...fromB,x:fromB.x+(b.x-fromB.x)*fraction,y:fromB.y+(b.y-fromB.y)*fraction};
 if(!xOverlap(at,target))return null;
 return{kind:'sole',fraction,normal:{x:0,y:-1},point:{x:clamp(at.x+at.w/2,target.x,target.x+target.w),y:target.y},body:body(at),relativeMotion:{x:a.x-fromA.x-b.x+fromB.x,y:delta}};
}
function touchingTop(a,b){return xOverlap(a,b)&&Math.abs(a.y+a.h-b.y)<=1.01;}
/** Only typed native block identity can request destruction; gray is no type. */
export function smm2ShoeBlockKind(solid){
 if(!solid||solid.hidden||solid.visible===false||solid.collision!=='solid'||['ground','dirt','ground-fill'].includes(solid.material))return null;
 // Native Stone can render several original block types. Explicit sidecar
 // identity wins over that generic material; native Ground remains Ground.
 if(solid.smm2BlockKind!==undefined)return['hard-block','brick'].includes(solid.smm2BlockKind)?solid.smm2BlockKind:null;
 return['hard-block','brick'].includes(solid.material)?solid.material:null;
}
export function createSmm2Shoes(room,{emit=()=>{},terrain=null,liquid=null,allowCarry=false,isStompTarget=nativeStompable}={}){
 validateSmm2ShoesRoom(room);
 if(typeof emit!=='function'||typeof isStompTarget!=='function'||typeof allowCarry!=='boolean'||terrain!==null&&(!terrain||typeof terrain.sweep!=='function'||typeof terrain.afterActor!=='function'))fail('Invalid SMM2 Shoe host callbacks');
 if(liquid!==null&&(!liquid||typeof liquid.surfaceForBoat!=='function'||typeof liquid.contact!=='function'))fail('Invalid Bone Shell liquid port');
 const definitions=new Map([...(room?.smm2Mechanics?.shoes||[]),...boneShellDefinitions(room)].map(q=>[q.id,{...copy(q),crouchCompatible:q.crouchCompatible??true,tuning:validateTuning(q.tuning,room.map.objects.find(a=>a.id===q.id).h)}]));
 if(!definitions.size&&!allowCarry)return null;
 if(allowCarry&&(!room?.map||!finite(room.map.width,1,32768)||!finite(room.map.height,1,4096)||!Array.isArray(room.map.objects)))fail('SMM2 Shoe carry needs native room bounds and objects');
 const originalDefinitions=new Map([...definitions].map(([id,q])=>[id,copy(q)]));
 const sources=new Map([...definitions.keys()].map(id=>[id,copy(room.map.objects.find(a=>a.id===id))])),owner={};
 const reservedIds=new Set([...(room.map.geometry||[]),...(room.map.objects||[]),...(room.markers||[]),...Object.values(room.smm2Mechanics||{}).filter(Array.isArray).flat(),...Object.values(room.contraptions||{}).filter(Array.isArray).flat()].map(a=>a?.id).filter(id=>typeof id==='string'));
 let actors=new Map(),passenger=null,currentTick=null,lastTick=null,paused=false,frameStarts=new Map(),playerFrame=null,lastPlayerTick=null,lastAfterTick=null,lastEffectsTick=null,pendingBreaks=[],enemyDecisions=new Map(),shoeDecisions=new Map(),eventLog=[],blasts=[];
 const diagnostic=(event,data={})=>{const q={event,roomId:room.roomId,tick:currentTick,...copy(data)};eventLog.push(q);emit('smm2-shoe',q);};
 const ownsActor=a=>!!a&&definitions.has(a.id);
 const stPlayer=foot=>passenger?.actor===foot?passenger.player:null;
 const occupied=player=>passenger?.player===player&&live(player)&&live(passenger.actor)&&passenger.actor.smm2Shoe?.occupancy==='player';
 const ownsPlayer=player=>player?occupied(player):!!passenger&&occupied(passenger.player);
 const state=a=>a.smm2Shoe;
 function decorateActor(a){
  if(!ownsActor(a))return a;if(!rect(a))fail('Invalid live SMM2 Shoe foot body');
  if(state(a)?.[OWNER]===owner){actors.set(a.id,a);return a;}
  const q=definitions.get(a.id),st={version:1,kind:q.kind,size:q.size,winged:q.winged,occupancy:q.occupant==='goomba'?'npc':'empty',originRoomId:q.originRoomId??room.roomId,sourceId:q.sourceId??q.id,lastTick:null,hopClock:0,walkHopClock:0,noBoardUntil:-1,groundPound:false,flutterRemaining:q.tuning.flutterFrames,contact:null};Object.defineProperty(st,OWNER,{value:owner});
  if(q.kind==='bone-shell')Object.assign(st,{originalHeight:a.h,playingDead:false,playingDeadAge:0,wasDown:false,phase:'active'});
  Object.assign(a,{type:'smm2-shoe',vx:Number.isFinite(a.vx)?a.vx:0,vy:Number.isFinite(a.vy)?a.vy:0,grounded:!!a.grounded,support:a.support??null,standable:false,smm2Shoe:st});actors.set(a.id,a);return a;
 }
 function shoeFor(player){return occupied(player)?passenger.actor:null;}
 /** A native pipe factory calls this only after producing a genuine spawn.
  * The dynamic body is never relocated to its authored template's position. */
 function registerActor(a,templateId){
  const q=originalDefinitions.get(templateId),source=sources.get(templateId);
  if(!safeId(templateId)||!q||!source||source.kind!=='walker')fail('SMM2 Shoe registration needs an authored template in this room');
  if(!a||!safeId(a.id)||definitions.has(a.id)||reservedIds.has(a.id)||actors.has(a.id)||definitions.size>=20000)fail('Duplicate or invalid dynamic SMM2 Shoe ID');
  if(a.kind!=='walker'||!live(a)||a.smm2Shoe!==undefined||!rect(a)||a.w!==source.w||a.h!==source.h||!finite(a.x,0,room.map.width-a.w)||!finite(a.y,0,room.map.height-a.h)||a.roomId!==undefined&&a.roomId!==room.roomId||a.vx!==undefined&&!finite(a.vx,-256,256)||a.vy!==undefined&&!finite(a.vy,-256,256))fail('Dynamic SMM2 Shoe needs a bounded matching native foot profile in this room');
  definitions.set(a.id,{...copy(q),id:a.id,sourceId:a.id,templateId,dynamic:true});decorateActor(a);diagnostic('register-source-actor',{shoeId:a.id,templateId,position:body(a)});return a;
 }
 function npcBody(a,foot=body(a)){const q=definitions.get(a.id);return{x:foot.x,y:foot.y-q.tuning.npcHeadHeight,w:foot.w,h:q.tuning.npcHeadHeight};}
 function exposedBody(player,foot=shoeFor(player)){if(!foot)return body(player);if(state(foot)?.playingDead)return{x:player.x,y:player.y,w:player.w,h:0};return{x:player.x,y:player.y,w:player.w,h:Math.max(0,Math.min(player.h,foot.y-player.y))};}
 function contactBody(actor){if(occupied(actor)&&state(passenger.actor).playingDead)return body(passenger.actor);if(actor&&ownsActor(actor)){decorateActor(actor);if(actor.moduleEmergence)return null;if(state(actor).occupancy==='player'&&passenger?.actor===actor)return state(actor).playingDead?body(actor):union([body(actor),body(passenger.player)]);return state(actor).occupancy==='npc'?union([body(actor),npcBody(actor)]):body(actor);}const shoe=actor?shoeFor(actor):passenger&&shoeFor(passenger.player);return shoe?union([body(shoe),body(actor||passenger.player)]):null;}
 function syncPlayer(player,a,{kinematics=true}={}){
  const q=definitions.get(a.id),inset=boneSeatInset(player,q);
  player.x=a.x+(a.w-player.w)/2;player.y=a.y-player.h+inset;
  if(kinematics)for(const key of ['vx','vy','grounded','support'])player[key]=a[key];
  player.shoeId=a.id;player.vehicleId=a.id;player.onVine=false;
 }
 /** Native pipe animation owns the actual player pose. Follow that pose only;
  * do not run a physics frame, change contacts or synthesize a transition rule. */
 function syncTransition(player){
  const a=shoeFor(player);if(!a)return null;if(!rect(player))fail('Invalid SMM2 Shoe transition player body');
  const q=definitions.get(a.id);a.x=player.x+(player.w-a.w)/2;a.y=player.y+player.h-boneSeatInset(player,q);return a;
 }
 function clearPassenger(player,a){if(player.shoeId===a.id)delete player.shoeId;if(player.vehicleId===a.id)delete player.vehicleId;delete a.smm2Player;terrain?.clearActorContact?.(passenger?.proxy);passenger=null;}
 function dismount(player,{reason='manual',jump=true,consume=false}={}){
  if(!['manual','hurt','goal','death','transition'].includes(reason)||typeof jump!=='boolean'||typeof consume!=='boolean')fail('Invalid SMM2 Shoe dismount options');
  const a=shoeFor(player);if(!a)return false;const q=definitions.get(a.id),st=state(a);if(q.kind==='bone-shell'&&st.playingDead)setBoneCollapse(a,player,false);
  st.occupancy=consume?'removed':'empty';st.groundPound=false;st.noBoardUntil=(currentTick??0)+q.tuning.remountLockFrames;a.vx=player.vx||0;a.vy=Math.max(0,a.vy||0);a.grounded=false;a.support=null;if(consume)a.dead=true;
  clearPassenger(player,a);player.grounded=false;player.support=null;player.jumpBuffer=0;
  if(jump)player.vy=(player.vy||0)-q.tuning.ejectSpeed;
  diagnostic('dismount',{shoeId:a.id,actorId:player.id??'player',reason,consumed:consume,jump});return true;
 }
 function beginFrame({tick,actors:entries=[],player,paused:stop=false}={}){
  if(!integer(tick,0,Number.MAX_SAFE_INTEGER)||!Array.isArray(entries)||entries.length>20000||typeof stop!=='boolean')fail('Invalid SMM2 Shoe frame');
  if(lastTick!==null&&tick<=lastTick)return false;currentTick=tick;paused=stop;if(stop)return false;lastTick=tick;frameStarts=new Map();pendingBreaks=[];enemyDecisions=new Map();shoeDecisions=new Map();eventLog=[];
  const ids=new Set();for(const a of entries){if(rect(a))frameStarts.set(a,body(a));if(!ownsActor(a))continue;if(ids.has(a.id))fail('Duplicate live SMM2 Shoe ID');ids.add(a.id);decorateActor(a);}
  if(passenger){const p=passenger.player,a=passenger.actor;
   if(!live(p)||!live(a)||player&&player!==p){if(live(p)&&live(a))dismount(p,{reason:'transition',jump:false});else{if(live(a)){state(a).occupancy='removed';a.dead=true;}clearPassenger(p,a);}}
   else{syncPlayer(p,a);if(!frameStarts.has(a))frameStarts.set(a,body(a));}
  }
  playerFrame=passenger?{player:passenger.player,shoe:body(passenger.actor),exposed:exposedBody(passenger.player,passenger.actor)}:null;return true;
 }
 function geometry(base=[],targets=[],{actor}={}){
  if(!Array.isArray(base)||!Array.isArray(targets))fail('Invalid SMM2 Shoe geometry');
  if(!actor||!ownsActor(actor)&&!ownsPlayer(actor))return base;
  const foot=ownsActor(actor)?actor:shoeFor(actor),definition=foot&&definitions.get(foot.id),bone=definition?.kind==='bone-shell';
  const result=base.filter(g=>!g.smm2ShoeSupport&&!(bone&&state(foot)?.playingDead&&definition.boneCollapse.dropThroughIds.includes(g.id)));
  if(bone&&liquid){
   const surface=liquid.surfaceForBoat(),player=ownsPlayer(actor)?actor:stPlayer(foot),height=state(foot).playingDead?foot.h:player?player.h+foot.h-boneSeatInset(player,definition):foot.h,width=player?Math.max(player.w,foot.w):foot.w,top=foot.y+foot.h-height,profile={x:foot.x+(foot.w-width)/2,w:width};
   // Fluid pressure can hold a boat below the free surface when a REAL solid
   // roof obstructs its rider. This actor-only reaction plane never supports
   // bare Mario or becomes a common map collider. Relaxation is rate-bounded.
   const ceiling=base.filter(g=>!g.hidden&&g.collision==='solid'&&xOverlap(profile,g)&&g.y+g.h<=top+1.01).reduce((y,g)=>Math.max(y,g.y+g.h),-Infinity),target=Math.max(surface.y,ceiling+height),prior=frameStarts.get(foot)||foot,oldBottom=prior.y+prior.h;
   if(foot.grounded&&foot.support===surface.id){const cap=Math.max(1,Math.abs(surface.dy));surface.y=oldBottom+clamp(target-oldBottom,-cap,cap);surface.dy=surface.y-oldBottom;}
   else{const previous=Math.max(surface.y-surface.dy,ceiling+height);surface.y=target;surface.dy=target-previous;}
   result.push(surface);
  }
  for(const g of base)if(rect(g)&&live(g)&&!g.hidden&&g.visible!==false&&spike(g)&&!['solid','oneway'].includes(g.collision))result.push({...body(g),id:g.id,collision:'oneway',material:'smm2-spike-support',smm2ShoeSupport:true});
  const seen=new Set(result.filter(g=>['solid','oneway'].includes(g.collision)).map(g=>g.id));
  // Owned footwear uses the real typed Muncher rectangle as a blocking body.
  // A one-way top lets an ascending sole penetrate its side before clearing
  // the top. These conservative full-body bounds are an author approximation;
  // contact protection still requires an actual sole landing/resting support.
  for(const a of targets)if(a!==actor&&rect(a)&&live(a)&&!a.hidden&&a.visible!==false&&!a.moduleEmergence&&muncher(a)&&!seen.has(a.id)){const old=frameStarts.get(a);result.push({...body(a),id:a.id,collision:'solid',material:'smm2-muncher-support',smm2ShoeSupport:true,dx:old?a.x-old.x:0,dy:old?a.y-old.y:0});seen.add(a.id);}
  return result;
 }
 function sweepTerrain(a,delta,base){
  let nearest=null;
  for(const solid of base){if(!rect(solid)||!live(solid)||solid.hidden||solid.visible===false||!['solid','oneway'].includes(solid.collision)||terrain?.ownsGeometry?.(solid))continue;let hit;
   if(solid.smm2LiquidSupport){const relative=delta.y-(solid.dy||0),gap=solid.y-(solid.dy||0)-a.y-a.h;if(relative<=EPS||gap<-1.01||gap>relative+EPS)continue;const fraction=clamp(gap/relative,0,1),at={...a,x:a.x+delta.x*fraction};if(!xOverlap(at,solid))continue;hit={fraction,normal:{x:0,y:-1},embedded:false};}
   else if(solid.collision==='oneway'){if(delta.y<=EPS||a.y+a.h>solid.y+1.01||a.y+a.h+delta.y<solid.y-EPS)continue;const fraction=clamp((solid.y-a.y-a.h)/delta.y,0,1),at={...a,x:a.x+delta.x*fraction};if(!xOverlap(at,solid))continue;hit={fraction,normal:{x:0,y:-1},embedded:false};}
   else hit=sweptRect(a,delta,solid);
   if(hit&&(!nearest||hit.fraction<nearest.fraction-EPS))nearest={...hit,solidId:solid.id,material:solid.material,body:{...body(a),x:a.x+delta.x*hit.fraction,y:a.y+delta.y*hit.fraction}};
  }
  const shaped=terrain?.sweep(a,delta,{tick:currentTick});
  if(shaped&&(!finite(shaped.fraction,0,1)||!rect(shaped.body)||shaped.body.w!==a.w||shaped.body.h!==a.h||!shaped.normal||!finite(shaped.normal.x,-1,1)||!finite(shaped.normal.y,-1,1)))fail('Invalid SMM2 Shoe shaped sweep');
  return shaped&&(!nearest||shaped.fraction<nearest.fraction-EPS)?shaped:nearest;
 }
 /** A Bone Shell entering a liquid VOLUME sideways is buoyant as well as one
  * falling onto its surface. The native one-way landing test alone rejects
  * that entry. Resolve the eligible carrier upward through the same physical
  * sweep, never through a solid ceiling or into a common Mario support plane.
  * This correction is a local recovery fit, not a measured Nintendo rate. */
 function recoverBoneSurface(proxy,solids,a){
  if(definitions.get(a.id)?.kind!=='bone-shell'||!liquid)return false;
  const surface=solids.find(g=>g.smm2LiquidSupport);
  if(!surface||!xOverlap(proxy,surface)||proxy.y+proxy.h<=surface.y+EPS||!liquid.contact(body(proxy)))return false;
  const rise=surface.y-proxy.y-proxy.h,hit=sweepTerrain(proxy,{x:0,y:rise},solids.filter(g=>g.id!==surface.id)),fraction=hit?.fraction??1;
  if(fraction<=EPS)return false;
  proxy.y+=rise*fraction;
  if(!hit||fraction>=1-EPS){proxy.y=surface.y-proxy.h;proxy.vy=0;proxy.grounded=true;proxy.support=surface.id;}
  else{proxy.vy=0;proxy.grounded=false;proxy.support=null;}
  diagnostic('liquid-volume-recovery',{shoeId:a.id,rise:rise*fraction,blockedBy:hit?.solidId??null,approximation:true});return true;
 }
 function stepActor(a,{tick=currentTick,geometry:base=[],targets=[]}={}){
  if(!ownsActor(a))return{handled:false,advanced:false};decorateActor(a);const st=state(a),q=definitions.get(a.id);
  if(!integer(tick,0,Number.MAX_SAFE_INTEGER)||!Array.isArray(base)||!Array.isArray(targets))fail('Invalid SMM2 Shoe actor step');
  if(paused||tick!==currentTick||!live(a)||a.moduleEmergence||!['npc','empty'].includes(st.occupancy)||st.lastTick!==null&&tick<=st.lastTick)return{handled:true,advanced:false};st.lastTick=tick;
  const before={...a},solids=geometry(base,targets,{actor:a});
  if(q.kind==='bone-shell'&&a.grounded&&liquid){const surface=liquid.surfaceForBoat();if(a.support===surface.id&&surface.dy){const hit=sweepTerrain(a,{x:0,y:surface.dy},solids.filter(g=>g.id!==surface.id));a.y+=surface.dy*(hit?.fraction??1);if(hit){a.grounded=false;a.support=null;}}}
  if(st.occupancy==='npc'){const direction=Math.sign(a.vx||a.facing||-1);a.vx=direction*q.tuning.npcSpeed;if(a.grounded&&++st.hopClock>=q.tuning.npcHopFrames){a.vy=-(q.winged?q.tuning.npcWingHopSpeed:q.tuning.npcHopSpeed);a.grounded=false;a.support=null;st.hopClock=0;}}
  else a.vx*=.9;
  a.vy=Math.min(q.tuning.maxFallSpeed,(a.vy||0)+q.tuning.gravity);a.grounded=false;a.support=null;
  const head=st.occupancy==='npc'?q.tuning.npcHeadHeight:0,proxy={...a,y:a.y-head,h:a.h+head};
  const move=delta=>{const hit=sweepTerrain(proxy,delta,solids);proxy.x+=delta.x*(hit?.fraction??1);proxy.y+=delta.y*(hit?.fraction??1);if(hit){st.contact=copy(hit);if(hit.normal.x){if(st.occupancy==='npc')a.vx*=-1;else a.vx=0;}if(hit.normal.y){a.vy=0;if(hit.normal.y<0){a.grounded=true;a.support=hit.solidId;const surface=solids.find(g=>g.id===hit.solidId&&g.smm2LiquidSupport);if(surface)proxy.y=surface.y-proxy.h;}}}return hit;};
  move({x:a.vx,y:0});proxy.x=clamp(proxy.x,0,room.map.width-proxy.w);move({x:0,y:a.vy});
  if(recoverBoneSurface(proxy,solids,a))for(const key of ['vy','grounded','support'])a[key]=proxy[key];
  a.x=proxy.x;a.y=proxy.y+head;
  terrain?.afterActor(a,before,{tick,input:{},geometry:solids});if(a.y>room.map.height+64){a.dead=true;st.occupancy='removed';}return{handled:true,advanced:true};
 }
 const kineticKeys=['vx','vy','grounded','support','facing','airCap','jumpG','fallG','jumpBuffer','jumps','anim','headHit','dropTicks','swimming','swimStroke'];
 function resizePassenger(player,a,input,solids){
  const q=definitions.get(a.id);if(q.kind==='bone-shell'){player.crouch=false;return;}if(!player.power){player.crouch=false;return;}
  if(!q.crouchCompatible){player.crouch=false;return;}
  const target=input.down&&player.grounded?16:28;if(target===player.h){player.crouch=target===16;return;}
  const width=Math.max(a.w,player.w),candidate={x:a.x+(a.w-width)/2,y:a.y-target+Math.min(q.tuning.seatInset,target),w:width,h:target+a.h-Math.min(q.tuning.seatInset,target)};
  if(target>player.h){const current={x:candidate.x,y:player.y,w:width,h:player.h+a.h-Math.min(q.tuning.seatInset,player.h)},rise=current.y-candidate.y;
   if(solids.some(s=>rect(s)&&live(s)&&!s.hidden&&s.visible!==false&&s.collision==='solid'&&overlap(candidate,s)))return;
   const ceiling=rise>EPS?sweepTerrain(current,{x:0,y:-rise},solids):null;if(ceiling&&(ceiling.embedded||ceiling.fraction<1-EPS))return;
  }
  player.h=target;player.crouch=target===16;syncPlayer(player,a,{kinematics:false});
 }
 function setBoneCollapse(a,player,enabled){const st=state(a);if(st.kind!=='bone-shell'||st.playingDead===enabled)return;const bottom=a.y+a.h;st.playingDead=enabled;st.phase=enabled?'playing-dead':'active';st.playingDeadAge=0;a.h=enabled?Math.min(4,st.originalHeight):st.originalHeight;a.y=bottom-a.h;a.vx=0;player.vx=0;syncPlayer(player,a,{kinematics:false});diagnostic(enabled?'playing-dead-start':'playing-dead-end',{shoeId:a.id});}
 function stepPlayer(player,input={},character,world,{tick=currentTick,motor,targets=[]}={}){
  const a=shoeFor(player);if(!a)return null;
  if(!integer(tick,0,Number.MAX_SAFE_INTEGER)||!motor||typeof motor.step!=='function'||!world||!Array.isArray(world.solids)||!finite(world.width,1,32768)||!Array.isArray(targets))fail('Invalid SMM2 Shoe player motor port');
  if(paused||tick!==currentTick||lastPlayerTick===tick)return[];lastPlayerTick=tick;const q=definitions.get(a.id),st=state(a);
  if(input.dismountPressed){dismount(player);return[];}
  let boneDownPressed=false;if(q.kind==='bone-shell'){const freshDown=input.down&&!st.wasDown;boneDownPressed=!!freshDown;st.wasDown=!!input.down;if(st.playingDead){st.playingDeadAge++;if(input.jumpPressed||st.playingDeadAge>=q.boneCollapse.durationFrames&&(!input.down||st.playingDeadAge>=q.boneCollapse.maxFrames)){const width=Math.max(player.w,a.w),height=player.h+st.originalHeight-boneSeatInset(player,q),candidate={x:a.x+(a.w-width)/2,y:a.y+a.h-height,w:width,h:height};if(!world.solids.some(g=>!g.hidden&&g.collision==='solid'&&overlap(candidate,g)))setBoneCollapse(a,player,false);}}else if(freshDown&&player.grounded)setBoneCollapse(a,player,true);}
  const solids=geometry(world.solids,targets,{actor:player});resizePassenger(player,a,input,solids);
  const inset=boneSeatInset(player,q),height=st.playingDead?a.h:player.h+a.h-inset,width=Math.max(player.w,a.w),proxy=passenger.proxy;
  Object.assign(proxy,player,{x:a.x+(a.w-width)/2,y:st.playingDead?a.y:a.y-player.h+inset,w:width,h:height,power:0,hero:'mario',crouch:false,vehicleId:undefined,shoeId:undefined});
  const before={...proxy},wasGrounded=proxy.grounded;let activeInput={...input,down:false,...(player.crouch?{x:0}:{})};
  if(st.playingDead)activeInput={...activeInput,x:0,run:false,jump:false,jumpPressed:false};
  if((q.kind==='bone-shell'?boneDownPressed:q.size==='big'&&input.down)&&!st.playingDead&&!wasGrounded&&!st.groundPound){st.groundPound=true;st.flutterRemaining=0;diagnostic('ground-pound-start',{shoeId:a.id});}
  if(st.groundPound){proxy.vy=Math.max(proxy.vy||0,q.tuning.groundPoundSpeed);proxy.jumpBuffer=0;activeInput={...activeInput,jump:false,jumpPressed:false};}
  else if(q.winged&&q.tuning.flutterFrames>0&&!wasGrounded&&input.jump&&proxy.vy>=0&&st.flutterRemaining>0){proxy.vy=Math.min(proxy.vy,q.tuning.flutterFallSpeed)-(Number.isFinite(proxy.fallG)?proxy.fallG:q.tuning.gravity);activeInput.jump=false;st.flutterRemaining--;}
  else if(q.tuning.walkHopSpeed>0&&wasGrounded&&input.x&&!input.jumpPressed&&++st.walkHopClock>=q.tuning.walkHopFrames){proxy.vy=-q.tuning.walkHopSpeed;proxy.grounded=false;proxy.support=null;st.walkHopClock=0;}
  if(q.kind==='bone-shell'&&liquid&&proxy.grounded&&proxy.support===liquid.surfaceForBoat().id){const surface=liquid.surfaceForBoat();if(surface.dy>0){const hit=sweepTerrain(proxy,{x:0,y:surface.dy},solids.filter(g=>g.id!==surface.id));if(hit){proxy.y+=surface.dy*hit.fraction;proxy.support=hit.solidId;proxy.grounded=hit.normal.y<0;proxy.vy=0;}}}
  const incomingVy=proxy.vy||0,out=motor.step(proxy,activeInput,character,{...world,solids});
  // Native Mario caps falling velocity; a requested pound supplies its own
  // remaining *physical* sweep instead of discarding collision or teleporting.
  if(st.groundPound&&!proxy.grounded&&incomingVy>proxy.vy){const extra=Math.max(0,incomingVy-Math.max(0,proxy.vy)),hit=sweepTerrain(proxy,{x:0,y:extra},solids);proxy.y+=extra*(hit?.fraction??1);proxy.vy=hit?0:incomingVy;if(hit?.normal.y<0){proxy.grounded=true;proxy.support=hit.solidId;}}
  recoverBoneSurface(proxy,solids,a);
  terrain?.afterActor(proxy,before,{tick,input:activeInput,geometry:solids,incomingVelocity:{x:proxy.vx||0,y:incomingVy}});
  a.x=proxy.x+(width-a.w)/2;a.y=proxy.y+proxy.h-a.h;for(const key of ['vx','vy','grounded','support','facing'])a[key]=proxy[key];
  for(const key of kineticKeys)if(Object.hasOwn(proxy,key))player[key]=proxy[key];syncPlayer(player,a,{kinematics:false});
  st.contact=proxy.grounded?{kind:'support',solidId:proxy.support,normal:{x:0,y:-1},point:{x:a.x+a.w/2,y:a.y+a.h},body:body(a),incomingVelocity:{x:a.vx||0,y:incomingVy}}:null;
  if(proxy.grounded){st.flutterRemaining=q.tuning.flutterFrames;if(st.groundPound){const solid=solids.find(s=>s.id===proxy.support),kind=smm2ShoeBlockKind(solid),contact=solid&&topContact(body(a),solid,playerFrame?.shoe||body(a),solid,q.tuning.boardingTolerance);
    if(q.kind!=='bone-shell'&&contact&&(kind==='brick'||q.kind==='stiletto'&&kind==='hard-block')){pendingBreaks.push({shoeId:a.id,solidId:solid.id,blockKind:kind,action:'break-solid',contact,approximation:true});diagnostic('block-break-request',{shoeId:a.id,solidId:solid.id,blockKind:kind,contact});}
    if(q.kind==='shoe'&&q.tuning.blastRange>0){for(const direction of [-1,1])blasts.push({id:a.id+':blast:'+tick+':'+direction,shoeId:a.id,x:direction<0?a.x-q.tuning.blastWidth:a.x+a.w,y:a.y+a.h-q.tuning.blastHeight,w:q.tuning.blastWidth,h:q.tuning.blastHeight,vx:direction*q.tuning.blastSpeed,travelled:0,range:q.tuning.blastRange,remainingFrames:q.tuning.blastLifetimeFrames,birthTick:tick,hitIds:new Set()});diagnostic('landing-blasts',{shoeId:a.id,effectIds:blasts.slice(-2).map(b=>b.id),approximation:true});}
    st.landedPoundTick=tick;st.groundPound=false;if(q.kind==='bone-shell')setBoneCollapse(a,player,true);diagnostic('ground-pound-land',{shoeId:a.id,supportId:proxy.support});}}
  return Array.isArray(out)?out:[];
 }
 /** Landing clouds are live lateral bodies, not radius or screen-wide kills.
  * Their only confirmed NPC target here is Muncher; geometry clips travel. */
 function stepEffects({tick=currentTick,geometry:base=[],targets=[]}={}){
  if(!integer(tick,0,Number.MAX_SAFE_INTEGER)||!Array.isArray(base)||!Array.isArray(targets)||base.length>20000||targets.length>20000)fail('Invalid SMM2 Shoe effect frame');
  if(paused||tick!==currentTick||lastEffectsTick===tick)return[];lastEffectsTick=tick;const requests=[];
  for(const b of blasts){if(b.birthTick===tick||b.remainingFrames<=0)continue;const before=body(b),distance=Math.min(Math.abs(b.vx),b.range-b.travelled),delta={x:Math.sign(b.vx)*distance,y:0},wall=sweepTerrain(b,delta,base),travel=delta.x*(wall?.fraction??1);
   if(wall?.embedded){b.remainingFrames=0;continue;}
   for(const target of targets){if(!muncher(target)||!live(target)||!rect(target)||target.hidden||target.visible===false||target.moduleEmergence||b.hitIds.has(target.id??target))continue;const prior=frameStarts.get(target)||body(target),hit=sweptRect(before,{x:travel-target.x+prior.x,y:prior.y-target.y},prior,{topSurface:true});if(!hit||wall&&hit.fraction>=1-EPS&&!hit.embedded)continue;b.hitIds.add(target.id??target);const contact={kind:'landing-blast',fraction:hit.fraction,normal:hit.normal,body:{...before,x:before.x+travel*hit.fraction},point:{x:before.x+travel*hit.fraction+(travel>0?before.w:0),y:clamp(before.y+before.h/2,target.y,target.y+target.h)}};const request={action:'defeat',targetId:target.id??null,shoeId:b.shoeId,effectId:b.id,contact,approximation:true};requests.push(request);diagnostic('landing-blast-defeat-request',request);}
   b.x+=travel;b.travelled+=Math.abs(travel);b.remainingFrames--;if(wall||b.travelled>=b.range-EPS||b.x+b.w<0||b.x>room.map.width)b.remainingFrames=0;
  }
  blasts=blasts.filter(b=>b.remainingFrames>0);return requests;
 }
 function pathBlocked(player,before,contact,base){
  const delta={x:player.x-before.x,y:player.y-before.y};return base.some(s=>{if(!rect(s)||s.hidden||s.visible===false||!['solid','oneway'].includes(s.collision))return false;if(s.collision==='oneway'){const c=topContact(player,s,before,s);return c&&c.fraction<contact.fraction-EPS;}const hit=sweptRect(before,delta,s);return hit&&!hit.embedded&&hit.fraction<contact.fraction-EPS;});
 }
 /** Typed NPC-shoe contact. Empty feet are neutral; a mounted sole may defeat
  * only another Goomba occupant, while actual side/exposed-body contact hurts. */
 function shoeContactDecision(player,before,target,{tick=currentTick,targetBefore=frameStarts.get(target)||target,geometry:base=[]}={}){
  const neutral={handled:false,protected:false,action:null};if(paused||tick!==currentTick||!live(player)||!rect(player)||!rect(before)||!ownsActor(target)||!live(target)||target.moduleEmergence||!rect(targetBefore)||!Array.isArray(base))return neutral;
  const current=shoeFor(player);if(target===current)return neutral;decorateActor(target);if(state(target).occupancy!=='npc')return neutral;
  const q=definitions.get(target.id),head=npcBody(target),priorHead=npcBody(target,body(targetBefore)),sole=current?body(current):body(player),priorSole=current?(playerFrame?.player===player?playerFrame.shoe:{...body(current),x:current.x+before.x-player.x,y:current.y+before.y-player.y}):body(before),stomp=topContact(sole,head,priorSole,priorHead,q.tuning.boardingTolerance);
  const parts=current?[{kind:'shoe-body',now:sole,prior:priorSole},{kind:'player-body',now:exposedBody(player,current),prior:playerFrame?.player===player?playerFrame.exposed:body(before)}]:[{kind:'player-body',now:body(player),prior:body(before)}],targetParts=[{kind:'npc-head',now:head,prior:priorHead},{kind:'shoe-body',now:body(target),prior:body(targetBefore)}];let harmful=null;
  for(const part of parts){if(!rect(part.now)||!rect(part.prior))continue;const prior={...part.prior,y:part.prior.y+part.prior.h-part.now.h,w:part.now.w,h:part.now.h};
   for(const targetPart of targetParts){const hit=sweptRect(prior,{x:part.now.x-prior.x-targetPart.now.x+targetPart.prior.x,y:part.now.y-prior.y-targetPart.now.y+targetPart.prior.y},targetPart.prior);if(!hit||pathBlocked(part.now,prior,hit,base))continue;
    // A genuine downward sole/head crossing is the intended stomp, rather
    // than a damaging contact at its own geometric entry fraction.
    if(stomp&&part.kind==='shoe-body'&&hit.normal.y<0&&hit.fraction>=stomp.fraction-EPS)continue;
    if(stomp&&!current&&hit.normal.y<0&&hit.fraction>=stomp.fraction-EPS)continue;
    if(!harmful||hit.fraction<harmful.fraction-EPS)harmful={kind:'npc-shoe-contact',part:part.kind,targetPart:targetPart.kind,fraction:hit.fraction,normal:hit.normal,body:{...prior,x:prior.x+(part.now.x-prior.x)*hit.fraction,y:prior.y+(part.now.y-prior.y)*hit.fraction},embedded:hit.embedded};
   }
  }
  let answer=neutral;
  if(stomp&&!pathBlocked(sole,priorSole,stomp,base)&&(!harmful||harmful.fraction>=stomp.fraction-EPS)){
   answer={handled:true,protected:true,action:'defeat-occupant',actorId:target.id,shoeId:target.id,ridingShoeId:current?.id??null,occupantOnly:true,contact:stomp,approximation:true};
  }else if(harmful)answer={handled:true,protected:false,action:'hurt',actorId:target.id,shoeId:target.id,ridingShoeId:current?.id??null,contact:harmful,approximation:true};
  return answer;
 }
 function playerShoeContact(player,before,target,options={}){
  if(paused||(options.tick??currentTick)!==currentTick)return{handled:false,protected:false,action:null};
  if(shoeDecisions.has(target))return copy(shoeDecisions.get(target));const answer=shoeContactDecision(player,before,target,options);
  if(answer.action==='defeat-occupant'){
   const tick=options.tick??currentTick,q=definitions.get(target.id),current=shoeFor(player),st=state(target);st.occupancy='empty';st.groundPound=false;st.noBoardUntil=tick;
   if(current){const own=definitions.get(current.id);current.y=npcBody(target).y-current.h;current.vy=-own.tuning.stompBounceSpeed;current.grounded=false;current.support=null;state(current).groundPound=false;syncPlayer(player,current);}
   else{player.y=Math.min(player.y,answer.contact.point.y-player.h);player.vy=-q.tuning.stompBounceSpeed;player.grounded=false;player.support=null;}
   player.jumpBuffer=0;player.jumpG=.125;player.fallG=.4375;diagnostic(current?'mounted-stomp-release':'stomp-release',{...answer,actorId:player.id??'player',targetId:target.id});
  }
  if(target&&typeof target==='object')shoeDecisions.set(target,copy(answer));return answer;
 }
 function afterPlayer(player,before,{tick=currentTick,actors:entries=[...actors.values()],geometry:base=[]}={}){
  if(!integer(tick,0,Number.MAX_SAFE_INTEGER)||!Array.isArray(entries)||!Array.isArray(base))fail('Invalid SMM2 Shoe player contact frame');
  const result={boarded:[],defeated:[],breaks:[]};if(paused||tick!==currentTick||lastAfterTick===tick||!live(player)||!rect(player)||!rect(before))return result;lastAfterTick=tick;result.breaks=copy(pendingBreaks);pendingBreaks=[];
  if(ownsPlayer(player)){
   // Resolve the first real crossing, independent of authored/source order.
   // A bounce stops that descent; it must not kill occupants farther below.
   const candidates=entries.filter(ownsActor).map(target=>({target,options:{tick,targetBefore:frameStarts.get(target)||target,geometry:base},decision:shoeContactDecision(player,before,target,{tick,targetBefore:frameStarts.get(target)||target,geometry:base})})).filter(q=>q.decision.action).sort((a,b)=>a.decision.contact.fraction-b.decision.contact.fraction||a.target.id.localeCompare(b.target.id));
   if(candidates.length){const {target,options}=candidates[0],decision=playerShoeContact(player,before,target,options);if(decision.action==='defeat-occupant')result.defeated.push({actorId:decision.actorId,shoeId:decision.shoeId,occupantOnly:true,action:decision.action,contact:decision.contact,approximation:true});else if(decision.action==='hurt')result.damage=[decision];}
   return result;
  }
  if(player.vehicleId||player.clawHeld||player.clawId||player.onVine)return result;
  const contacts=[];for(const a of entries.filter(ownsActor)){decorateActor(a);const st=state(a),q=definitions.get(a.id);if(!live(a)||a.moduleEmergence||!['npc','empty'].includes(st.occupancy)||tick<=st.noBoardUntil)continue;
   const prior=frameStarts.get(a)||body(a),target=st.occupancy==='npc'?npcBody(a):body(a),from=st.occupancy==='npc'?npcBody(a,prior):prior,contact=topContact(player,target,before,from,q.tuning.boardingTolerance);
   if(contact&&!pathBlocked(player,before,contact,base))contacts.push({a,contact});}
  const nearest=contacts.sort((a,b)=>a.contact.fraction-b.contact.fraction||a.a.id.localeCompare(b.a.id))[0];if(!nearest){for(const target of entries.filter(ownsActor)){const decision=playerShoeContact(player,before,target,{tick,targetBefore:frameStarts.get(target)||target,geometry:base});if(decision.action==='hurt')(result.damage??=[]).push(decision);}return result;}
  const {a,contact}=nearest,q=definitions.get(a.id),st=state(a),occupantOnly=st.occupancy==='npc';
  if(occupantOnly){
   // Observed course contact leaves an empty live foot below Mario's Goomba
   // bounce. Boarding happens on a later genuine descending contact.
   st.occupancy='empty';st.groundPound=false;st.noBoardUntil=tick;player.y=Math.min(player.y,contact.point.y-player.h);player.vy=-q.tuning.stompBounceSpeed;player.grounded=false;player.support=null;player.jumpBuffer=0;player.jumpG=.125;player.fallG=.4375;
   result.defeated.push({actorId:a.id,shoeId:a.id,occupantOnly:true,action:'defeat-occupant',contact,approximation:true});diagnostic('stomp-release',{shoeId:a.id,actorId:player.id??'player',occupantOnly:true,contact});return result;
  }
  st.occupancy='player';st.groundPound=false;st.flutterRemaining=q.tuning.flutterFrames;a.vx=player.vx||0;
  passenger={player,actor:a,proxy:{}};a.smm2Player=true;syncPlayer(player,a);player.jumpBuffer=0;player.jumpG=.125;player.fallG=.4375;result.boarded.push(a.id);
  diagnostic('board-empty',{shoeId:a.id,actorId:player.id??'player',occupantOnly:false,contact});return result;
 }
 function playerEnemyContact(player,before,target,{tick=currentTick,targetBefore=target}={}){
  const a=shoeFor(player),unhandled={handled:false,protected:false,action:null};if(!a||paused||tick!==currentTick||!rect(target)||!live(target)||target.moduleEmergence||target===a||!rect(before))return unhandled;
  const key=target.id??target;if(enemyDecisions.has(key))return copy(enemyDecisions.get(key));const st=state(a),q=definitions.get(a.id),from=playerFrame?.player===player?playerFrame.shoe:{...body(a),x:a.x+before.x-player.x,y:a.y+before.y-player.y},contact=topContact(body(a),target,from,targetBefore,q.tuning.boardingTolerance),exposed=exposedBody(player,a);
  // A source that reaches the protruding body never becomes harmless merely
  // because its label is a Muncher, Piranha or a shoe-stomp candidate.
  if(st.playingDead&&overlap(body(a),target))return{handled:true,protected:true,action:null,shoeId:a.id,targetId:target.id};
  const exposedHit=exposed.h>0&&overlap(exposed,target),pounding=st.groundPound||st.landedPoundTick===tick;
  const resting=player.grounded&&player.support===target.id&&touchingTop(a,target);
  let answer=unhandled;
  if(!exposedHit&&muncher(target)&&(contact||resting)){answer={handled:true,protected:true,action:q.size==='big'&&pounding&&contact?'defeat':null,targetId:target.id??null,shoeId:a.id,contact:contact||{kind:'support',normal:{x:0,y:-1},point:{x:a.x+a.w/2,y:target.y},body:body(a)},approximation:true};}
  else if(!exposedHit&&contact&&!(typeOf(target)==='dry-bones'&&['collapsed','recovering'].includes(target.smm2DryBones?.phase))&&isStompTarget(target,q)===true){answer={handled:true,protected:true,action:q.kind==='bone-shell'&&typeOf(target)==='dry-bones'?'collapse':'defeat',targetId:target.id??null,shoeId:a.id,contact,approximation:true};a.y=target.y-a.h;a.vy=-q.tuning.stompBounceSpeed;a.grounded=false;a.support=null;st.groundPound=false;syncPlayer(player,a);diagnostic('enemy-stomp-request',{shoeId:a.id,targetId:target.id??null,contact});}
  else if(contact&&/piranha|fireplant|spiny|thwomp/.test(typeOf(target)))answer={...unhandled,unverified:'shoe-'+typeOf(target)+'-stomp',contact};
  enemyDecisions.set(key,copy(answer));return answer;
 }
 function playerHazardContact(player,before,hazard,{tick=currentTick,hazardBefore=hazard}={}){
  const a=shoeFor(player),answer={handled:false,protected:false,action:null};if(!a||paused||tick!==currentTick||!rect(hazard)||!live(hazard)||hazard.hidden||hazard.visible===false||!rect(before))return answer;
  if(state(a).playingDead&&overlap(body(a),hazard))return{handled:true,protected:true,action:null,shoeId:a.id,hazardId:hazard.id};
  if(muncher(hazard))return playerEnemyContact(player,before,hazard,{tick,targetBefore:hazardBefore});
  if(!spike(hazard))return answer;
  const from=playerFrame?.player===player?playerFrame.shoe:{...body(a),x:a.x+before.x-player.x,y:a.y+before.y-player.y},contact=topContact(body(a),hazard,from,hazardBefore,definitions.get(a.id).tuning.boardingTolerance),standing=player.grounded&&player.support===hazard.id&&touchingTop(a,hazard),exposed=exposedBody(player,a);
  if(exposed.h>0&&overlap(exposed,hazard)||!contact&&!standing)return answer;
  return{handled:true,protected:true,action:null,shoeId:a.id,hazardId:hazard.id??null,contact:contact||{kind:'support',normal:{x:0,y:-1},point:{x:a.x+a.w/2,y:hazard.y},body:body(a)},approximation:true};
 }
 function exportCarry(player,{detach=false}={}){
  if(typeof detach!=='boolean')fail('Invalid SMM2 Shoe carry export');const a=shoeFor(player);if(!a)return null;const q=definitions.get(a.id),st=state(a);if(q.kind==='bone-shell'&&st.playingDead)setBoneCollapse(a,player,false);const snapshot={version:1,originRoomId:st.originRoomId,sourceId:st.sourceId,kind:q.kind,size:q.size,winged:q.winged,crouchCompatible:q.crouchCompatible,w:a.w,h:a.h,tuning:copy(q.tuning),...(q.kind==='bone-shell'?{boneCollapse:copy(q.boneCollapse)}:{})};
  if(detach){st.occupancy='carried';clearPassenger(player,a);diagnostic('carry-export',{shoeId:a.id});}return snapshot;
 }
 function importCarry(player,snapshot,{tick=currentTick}={}){
  if(!allowCarry)fail('SMM2 Shoe carry was not enabled by the host');
  if(passenger)fail('SMM2 Shoe controller already has a passenger');
  fields(snapshot,['version','originRoomId','sourceId','kind','size','winged','w','h','tuning','crouchCompatible','boneCollapse'],'SMM2 Shoe carry',['version','originRoomId','sourceId','kind','size','winged','w','h','tuning']);
  if(snapshot.version!==1||!safeId(snapshot.originRoomId)||!safeId(snapshot.sourceId)||!['shoe','stiletto','bone-shell'].includes(snapshot.kind)||!['small','big'].includes(snapshot.size)||typeof snapshot.winged!=='boolean'||!finite(snapshot.w,1,64)||!finite(snapshot.h,1,64)||!live(player)||!rect(player)||player.vehicleId||!integer(tick??0,0,Number.MAX_SAFE_INTEGER))fail('Invalid SMM2 Shoe carry snapshot or player');
  if(snapshot.kind!=='bone-shell'&&snapshot.boneCollapse!==undefined)fail('Only Bone Shell carry can contain collapse state');
  let boneCollapse;if(snapshot.kind==='bone-shell'){if(snapshot.size!=='small'||snapshot.winged||!plain(snapshot.boneCollapse)||!Array.isArray(snapshot.boneCollapse.dropThroughIds)||snapshot.boneCollapse.dropThroughIds.some(id=>!safeId(id)))fail('Invalid Bone Shell carry');boneCollapse={...copy(snapshot.boneCollapse),dropThroughIds:snapshot.boneCollapse.dropThroughIds.filter(id=>room.map.geometry.some(g=>g.id===id&&g.collision==='oneway'))};validateBonePlayingDead(room,boneCollapse);}
  const tuning=validateTuning(snapshot.tuning,snapshot.h),id=snapshot.sourceId,existing=actors.get(id);
  if(snapshot.crouchCompatible!==undefined&&typeof snapshot.crouchCompatible!=='boolean')fail('Invalid SMM2 Shoe carry crouch compatibility');
  if(definitions.has(id)&&(!existing||state(existing).occupancy!=='carried')||room.map.objects.some(o=>o.id===id)&&!definitions.has(id))fail('SMM2 Shoe carry ID conflicts with a native source');
  const x=player.x+(player.w-snapshot.w)/2,y=player.y+player.h-boneSeatInset(player,{kind:snapshot.kind,tuning});
  if(!finite(x,0,room.map.width-snapshot.w)||!finite(y,0,room.map.height-snapshot.h))fail('SMM2 Shoe carried foot is outside the destination room');
  definitions.set(id,{id,kind:snapshot.kind,size:snapshot.size,winged:snapshot.winged,crouchCompatible:snapshot.crouchCompatible??true,occupant:'empty',tuning,originRoomId:snapshot.originRoomId,sourceId:id,imported:true,...(boneCollapse?{boneCollapse}: {})});
  // Returning to the source room reuses its carried live object. Otherwise the
  // host's native actor list would retain a second actor with the same ID.
  const a=existing||{};delete a.smm2Shoe;Object.assign(a,{id,kind:'walker',x,y,w:snapshot.w,h:snapshot.h,vx:player.vx||0,vy:player.vy||0,grounded:!!player.grounded,support:player.support??null,dead:false});decorateActor(a);state(a).occupancy='player';a.smm2Player=true;passenger={player,actor:a,proxy:{}};syncPlayer(player,a);diagnostic('carry-import',{shoeId:id,originRoomId:snapshot.originRoomId});return a;
 }
 function view(entries=[...actors.values()]){
  const list=[...new Set([...entries.filter(ownsActor),...(passenger?[passenger.actor]:[])])];
  return{version:1,approximation:true,tick:currentTick,mountedId:passenger?.actor.id??null,shoes:list.map(a=>{decorateActor(a);const st=state(a),q=definitions.get(a.id);return{id:a.id,...body(a),vx:a.vx||0,vy:a.vy||0,grounded:!!a.grounded,support:a.support??null,kind:st.kind,size:st.size,winged:st.winged,occupancy:st.occupancy,originRoomId:st.originRoomId,sourceId:st.sourceId,templateId:q.templateId??null,crouchCompatible:q.crouchCompatible,groundPound:st.groundPound,flutterRemaining:st.flutterRemaining,occupantId:st.occupancy==='player'?passenger?.player.id??'player':st.occupancy==='npc'?a.id+':goomba':null,contactBody:contactBody(a),emerging:!!a.moduleEmergence,...(a.moduleEmergence?{moduleEmergence:copy(a.moduleEmergence)}:{}),...(st.occupancy==='npc'&&!a.moduleEmergence?{npcBody:npcBody(a)}:{}),...(st.occupancy==='player'?{exposedBody:exposedBody(passenger.player,a),playerBody:body(passenger.player)}:{}),dead:!!a.dead,...(q.kind==='bone-shell'?{playingDead:st.playingDead,playingDeadAge:st.playingDeadAge,phase:st.phase,originalHeight:st.originalHeight}:{} )};}),blasts:blasts.map(b=>{const{hitIds,...data}=b;return copy(data);}),events:copy(eventLog)};
 }
 function reset(){
  if(passenger)clearPassenger(passenger.player,passenger.actor);
  for(const [id,a]of actors){const source=sources.get(id);if(!source){definitions.delete(id);delete a.smm2Shoe;delete a.smm2Player;a.dead=true;continue;}definitions.set(id,copy(originalDefinitions.get(id)));delete a.smm2Shoe;delete a.smm2Player;Object.assign(a,copy(source),{vx:0,vy:0,grounded:false,support:null,dead:false});decorateActor(a);}
  for(const [id,q]of definitions)if(q.imported&&!sources.has(id))definitions.delete(id);for(const [id]of actors)if(!definitions.has(id))actors.delete(id);
  currentTick=lastTick=lastPlayerTick=lastAfterTick=lastEffectsTick=null;paused=false;frameStarts=new Map();playerFrame=null;pendingBreaks=[];enemyDecisions=new Map();shoeDecisions=new Map();eventLog=[];blasts=[];
 }
 return Object.freeze({ownsActor,ownsPlayer,isPlayingDead:player=>!!shoeFor(player)&&!!state(shoeFor(player)).playingDead,isBoneShell:player=>!!shoeFor(player)&&state(shoeFor(player)).kind==='bone-shell',registerActor,decorateActor,syncTransition,beginFrame,stepActor,stepPlayer,stepEffects,afterPlayer,geometry,contactBody,shoeBody:player=>{const a=shoeFor(player);return a?body(a):null;},exposedBody,playerShoeContact,playerEnemyContact,playerHazardContact,dismount,exportCarry,importCarry,view,reset});
}
/** Absence of the leaf leaves the exact supplied native motor object intact. */
export function withSmm2Shoes(motor,shoes){if(!shoes)return motor;return{...motor,step(player,input,character,world){const out=shoes.stepPlayer(player,input,character,world,{motor});return out===null?motor.step(player,input,character,world):out;}};}
