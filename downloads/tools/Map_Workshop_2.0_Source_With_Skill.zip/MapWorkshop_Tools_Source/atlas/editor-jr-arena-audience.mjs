/** Authored colosseum crowd. Seated figures are scene actors, never enemies.
 * Only the bounded gallery runners enter the existing native Goomba physics.
 * This is an original scene composition, not a Nintendo HP-unlocked skill. */
export const JR_ARENA_AUDIENCE_STATUS='authored-not-calibrated';
const plain=q=>q&&typeof q==='object'&&!Array.isArray(q)&&[Object.prototype,null].includes(Object.getPrototypeOf(q));
const safeId=q=>typeof q==='string'&&q.length<=100&&/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(q)&&!['constructor','prototype'].includes(q);
const finite=(q,a,b)=>Number.isFinite(q)&&q>=a&&q<=b;
const integer=(q,a,b)=>Number.isSafeInteger(q)&&finite(q,a,b);
const fail=q=>{throw new TypeError(q);};
const closed=(q,keys)=>plain(q)&&Object.keys(q).every(k=>keys.includes(k))&&keys.every(k=>Object.hasOwn(q,k));
const keys=['version','bossId','sourceParameterStatus','seats','exits','cheerFrames','telegraphFrames','waveGapFrames','waveCount','goombasPerWave','maxAlive'];
const rowKeys=['formation','rowCount','spawnGapFrames'];
const rowSize=spec=>spec.rowCount??6;
const spawnGap=spec=>spec.spawnGapFrames??32;
const isRow=spec=>spec.formation==='row';
const waveSize=spec=>isRow(spec)?rowSize(spec):spec.goombasPerWave;
export function validateJrArenaAudienceRoom(room,spec=room?.smm2Mechanics?.arenaAudience){
 if(spec===undefined)return;
 if(!plain(spec)||!keys.every(k=>Object.hasOwn(spec,k))||Object.keys(spec).some(k=>!keys.includes(k)&&!rowKeys.includes(k))||spec.version!==1||!safeId(spec.bossId)||spec.sourceParameterStatus!==JR_ARENA_AUDIENCE_STATUS)fail('Invalid authored Jr arena audience');
 if(Object.hasOwn(spec,'formation')&&!['pair','row'].includes(spec.formation)||!isRow(spec)&&(Object.hasOwn(spec,'rowCount')||Object.hasOwn(spec,'spawnGapFrames'))||Object.hasOwn(spec,'rowCount')&&!integer(spec.rowCount,2,6)||Object.hasOwn(spec,'spawnGapFrames')&&!integer(spec.spawnGapFrames,32,120))fail('Invalid arena gallery formation');
 if(!room.smm2Mechanics?.bowserJuniors?.actors?.some(q=>q.id===spec.bossId))fail('Arena audience needs an existing Bowser Jr actor');
 if(!Array.isArray(spec.seats)||!spec.seats.length||spec.seats.length>64||!Array.isArray(spec.exits)||spec.exits.length!==(isRow(spec)?1:2))fail('Arena audience needs seats and the formation\'s actual gallery exits');
 const seen=new Set(room.map.objects.map(q=>q.id));
 for(const q of spec.seats){
  if(!closed(q,['id','x','y','w','h','seatGeometryId','facing'])||!safeId(q.id)||seen.has(q.id)||!safeId(q.seatGeometryId)||q.w!==16||q.h!==16||![-1,1].includes(q.facing)||!finite(q.x,0,room.map.width-16)||!finite(q.y,0,room.map.height-16))fail('Invalid nonhazardous arena spectator');
  seen.add(q.id);const seat=room.map.geometry.find(g=>g.id===q.seatGeometryId);
  if(!seat||seat.collision!=='solid'||seat.hidden||q.x<seat.x||q.x+16>seat.x+seat.w||q.y+16!==seat.y)fail('Arena spectator must sit on an actual solid stair seat');
 }
 for(const q of spec.exits){
  if(!closed(q,['id','x','y','direction'])||!safeId(q.id)||seen.has(q.id)||![-1,1].includes(q.direction)||!finite(q.x,0,room.map.width-16)||!finite(q.y,0,room.map.height-16))fail('Invalid arena gallery exit');
  seen.add(q.id);const body={x:q.x,y:q.y,w:16,h:16};
  if(room.map.geometry.some(g=>!g.hidden&&g.collision==='solid'&&body.x<g.x+g.w&&body.x+body.w>g.x&&body.y<g.y+g.h&&body.y+body.h>g.y))fail('Arena gallery exit must have a clear native Goomba body');
 }
 if(!integer(spec.cheerFrames,30,240)||!integer(spec.telegraphFrames,isRow(spec)?72:60,240)||!integer(spec.waveGapFrames,120,600)||!integer(spec.waveCount,1,isRow(spec)?2:3)||!integer(spec.goombasPerWave,1,isRow(spec)?1:2)||!integer(spec.maxAlive,1,isRow(spec)?6:3)||spec.waveCount*waveSize(spec)>(isRow(spec)?12:6)||isRow(spec)&&(!integer(rowSize(spec),2,6)||!integer(spawnGap(spec),32,120)))fail('Arena runners require a bounded, visibly telegraphed wave budget');
 if(isRow(spec)){
  const exit=spec.exits[0],lastX=exit.x+exit.direction*(rowSize(spec)-1)*16;
  if(!finite(lastX,0,room.map.width-16))fail('Arena row must fit the gallery floor');
 }
 return spec;
}

/** Integration receives real controller notifications and its current view.
 * spawn(actor) must append this ordinary Goomba to the host enemy list. This
 * controller never moves/hits/kills a runner after that handoff. */
export function createJrArenaAudience(room,{emit=()=>{},spawn=()=>{}}={}){
 const spec=validateJrArenaAudienceRoom(room);if(!spec)return null;
 let state={version:1,tick:0,lastStepTick:-1,cheerStarted:-1000,cheerUntil:-1,lastBossEventTick:-1,finalPhase:false,defeated:false,wavesStarted:0,totalSpawned:0,nextWaveTick:null,pending:[]};
 const notify=(event,extra={})=>emit('smm2-arena-audience',{event,roomId:room.roomId,bossId:spec.bossId,tick:state.tick,sourceParameterStatus:JR_ARENA_AUDIENCE_STATUS,...extra});
 function handleBossEvent(event){
  if(!event||event.roomId!==room.roomId||event.actorId!==spec.bossId||!integer(event.tick,0,Number.MAX_SAFE_INTEGER)||event.tick<=state.lastBossEventTick||!['head-stomp','defeated'].includes(event.event)||event.event==='head-stomp'&&![1,2].includes(event.hp)||event.event==='defeated'&&event.hp!==0)return false;
  state.lastBossEventTick=event.tick;state.tick=event.tick;state.cheerStarted=event.tick;state.cheerUntil=event.tick+spec.cheerFrames;notify('cheer',{cause:event.event,hp:event.hp});
  if(event.hp===1&&!state.finalPhase){state.finalPhase=true;state.nextWaveTick=event.tick;notify('final-phase');}
  if(event.hp===0){state.defeated=true;state.pending=[];state.nextWaveTick=null;notify('waves-ended');}
  return true;
 }
 function step({tick,boss,enemies=[],player}={}){
  if(!integer(tick,0,Number.MAX_SAFE_INTEGER)||tick<=state.lastStepTick)return;
  state.lastStepTick=tick;state.tick=tick;
  if(state.defeated||!state.finalPhase||boss?.hp!==1||boss?.phase==='defeated')return;
  let alive=enemies.filter(a=>!a.dead&&a.arenaRunner?.bossId===spec.bossId).length;
  if(state.nextWaveTick!==null&&tick>=state.nextWaveTick&&!state.pending.length&&state.wavesStarted<spec.waveCount&&(!isRow(spec)||state.wavesStarted===0||alive===0)){
   const wave=++state.wavesStarted;
   state.pending=Array.from({length:waveSize(spec)},(_,index)=>({exitId:spec.exits[isRow(spec)?0:index].id,wave,index,startedTick:tick,readyTick:tick+spec.telegraphFrames+(isRow(spec)?index*spawnGap(spec):0)}));
   state.nextWaveTick=null;notify('gallery-warning',{wave,exitIds:[...new Set(state.pending.map(q=>q.exitId))],durationFrames:spec.telegraphFrames,...(isRow(spec)?{formation:'row',rowCount:rowSize(spec),spawnGapFrames:spawnGap(spec)}:{})});
  }
  for(const pending of [...state.pending]){
   // A row is an ordered queue at one real exit. If its first member waits,
   // later members wait too; delayed entries never burst on the same tick.
   if(isRow(spec)&&pending!==state.pending[0])continue;
   if(tick<pending.readyTick||alive>=spec.maxAlive)continue;
   const exit=spec.exits.find(q=>q.id===pending.exitId),center=exit.x+8;
   // The actual spawn remains at its authored visible exit, never at the
   // player's feet. Waiting near an exit pauses this runner, not the boss.
   if(player&&Math.abs(player.x+player.w/2-center)<56)continue;
   if(isRow(spec)&&enemies.some(a=>!a.dead&&a.arenaRunner?.exitId===exit.id&&Math.abs(a.x-exit.x)<16&&Math.abs(a.y-exit.y)<16))continue;
   const serial=state.totalSpawned+1,actor={id:spec.bossId+'-gallery-goomba-'+serial,kind:'walker',type:'goomba',x:exit.x,y:exit.y,w:16,h:16,vx:exit.direction*.5,vy:0,homeX:exit.x,homeY:exit.y,age:0,dead:false,grounded:true,support:null,arenaRunner:{version:1,bossId:spec.bossId,exitId:exit.id,wave:pending.wave,sourceParameterStatus:JR_ARENA_AUDIENCE_STATUS}};
   spawn(actor);state.totalSpawned++;alive++;state.pending=state.pending.filter(q=>q!==pending);
   if(isRow(spec))for(const q of state.pending)q.readyTick=Math.max(q.readyTick,tick+(q.index-pending.index)*spawnGap(spec));
   notify('runner-entered',{actorId:actor.id,exitId:exit.id,wave:pending.wave,totalSpawned:state.totalSpawned,...(isRow(spec)?{formation:'row',index:pending.index,rowCount:rowSize(spec)}:{})});
   if(isRow(spec))break;
  }
  if(!state.pending.length&&state.nextWaveTick===null&&state.wavesStarted<spec.waveCount)state.nextWaveTick=tick+spec.waveGapFrames;
 }
 function view(){
  const cheering=state.tick<state.cheerUntil,age=Math.max(0,state.tick-state.cheerStarted);
  const warnings=isRow(spec)?state.pending.slice(0,1):state.pending;
  return {version:1,bossId:spec.bossId,sourceParameterStatus:JR_ARENA_AUDIENCE_STATUS,cheering,finalPhase:state.finalPhase,defeated:state.defeated,wavesStarted:state.wavesStarted,totalSpawned:state.totalSpawned,maxTotal:spec.waveCount*waveSize(spec),spectators:spec.seats.map((q,index)=>{const phase=(age+index*5)%32,pose=cheering?['cheer','jump','wave'][index%3]:'seated',lift=pose==='jump'?Math.round(Math.sin(phase/32*Math.PI)*8):pose==='cheer'?(phase<16?2:0):0;return {...q,y:q.y-lift,seatY:q.y,pose,poseAge:age,facing:q.facing,harmless:true,stompable:false,countsAsEnemy:false};}),galleryWarnings:warnings.map(q=>{const exit=spec.exits.find(e=>e.id===q.exitId);return {...exit,w:16,h:16,wave:q.wave,age:state.tick-q.startedTick,remaining:Math.max(0,q.readyTick-state.tick),...(isRow(spec)?{formation:'row',rowCount:rowSize(spec),queuedCount:state.pending.length,spawnGapFrames:spawnGap(spec)}:{})};})};
 }
 function snapshot(){return structuredClone(state);}
 function restore(saved){
  const fields=Object.keys(state);if(!closed(saved,fields)||saved.version!==1||!integer(saved.tick,0,Number.MAX_SAFE_INTEGER)||!integer(saved.lastStepTick,-1,Number.MAX_SAFE_INTEGER)||!integer(saved.lastBossEventTick,-1,Number.MAX_SAFE_INTEGER)||!integer(saved.cheerStarted,-1000,Number.MAX_SAFE_INTEGER)||!integer(saved.cheerUntil,-1,Number.MAX_SAFE_INTEGER)||typeof saved.finalPhase!=='boolean'||typeof saved.defeated!=='boolean'||!integer(saved.wavesStarted,0,spec.waveCount)||!integer(saved.totalSpawned,0,spec.waveCount*waveSize(spec))||saved.nextWaveTick!==null&&!integer(saved.nextWaveTick,0,Number.MAX_SAFE_INTEGER)||!Array.isArray(saved.pending)||saved.pending.length>waveSize(spec))fail('Invalid arena audience snapshot');
  if(saved.defeated&&(saved.pending.length||saved.nextWaveTick!==null)||saved.totalSpawned+saved.pending.length>saved.wavesStarted*waveSize(spec)||!saved.defeated&&saved.totalSpawned+saved.pending.length!==saved.wavesStarted*waveSize(spec))fail('Invalid arena audience wave accounting');
  const indices=new Set();let previous=null;
  for(const q of saved.pending){
   const nominal=q.startedTick+spec.telegraphFrames+(isRow(spec)?q.index*spawnGap(spec):0);
   if(!closed(q,['exitId','wave','index','startedTick','readyTick'])||q.exitId!==spec.exits[isRow(spec)?0:q.index]?.id||!integer(q.wave,1,spec.waveCount)||q.wave!==saved.wavesStarted||!integer(q.index,0,waveSize(spec)-1)||!integer(q.startedTick,0,saved.tick)||!integer(q.readyTick,0,Number.MAX_SAFE_INTEGER)||(isRow(spec)?q.readyTick<nominal:q.readyTick!==nominal)||indices.has(q.index)||isRow(spec)&&previous&&(q.index!==previous.index+1||q.readyTick-previous.readyTick<spawnGap(spec)||q.startedTick!==previous.startedTick))fail('Invalid arena audience pending runner');
   indices.add(q.index);previous=q;
  }
  state=structuredClone(saved);
 }
 return {handleBossEvent,step,view,snapshot,restore};
}
