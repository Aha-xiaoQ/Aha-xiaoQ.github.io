import {validateCompletionMarksRoom,validateCompletionMarkEntries,completionMarkReferencesExist,COMPLETION_MARK_FIELDS} from './editor-completion-marks.mjs';
const clone=q=>structuredClone(q);
const equal=(a,b)=>[a,b].every(q=>q&&Reflect.ownKeys(q).length===COMPLETION_MARK_FIELDS.length&&Reflect.ownKeys(q).every(k=>COMPLETION_MARK_FIELDS.includes(k)))&&COMPLETION_MARK_FIELDS.every(k=>a[k]===b[k]);
const array=q=>{if(!Array.isArray(q))throw new TypeError('Completion mark references need room lists');return q;};

/** Validate the un-cloned proposal before committing one optional leaf.
 * The host supplies its History transaction and full project room context. */
export function setCompletionMarks(room,marks,rooms){
 validateCompletionMarkEntries(marks);
 const next={...room,smm2Mechanics:{...(room.smm2Mechanics??{version:1}),completionMarks:marks}};
 validateCompletionMarksRoom(next,rooms);
 (room.smm2Mechanics??={version:1}).completionMarks=clone(marks);
}
export function removeCompletionMarks(room){if(room.smm2Mechanics)delete room.smm2Mechanics.completionMarks;}

/** Local portal deletion can be handled by native deleteSelection itself.
 * Cross-room reward deletion is handled by the whole-project helper below. */
export function pruneCompletionMarksRoomReferences(room,before){
 const marks=room?.smm2Mechanics?.completionMarks,old=before?.smm2Mechanics?.completionMarks;if(!Array.isArray(marks)||!Array.isArray(old))return 0;
 const remove=marks.filter(mark=>{
  const previous=old.find(q=>q.id===mark.id);if(!previous||!equal(previous,mark))return false;
  const hadPortal=before.map.objects.some(q=>q.id===mark.portalId&&q.kind==='portal'),hasPortal=room.map.objects.some(q=>q.id===mark.portalId&&q.kind==='portal');
  return hadPortal&&!hasPortal||mark.rewardRoomId===room.roomId&&completionMarkReferencesExist(before,previous,[before])&&!completionMarkReferencesExist(room,mark,[room]);
 });
 if(remove.length){room.smm2Mechanics.completionMarks=marks.filter(q=>!remove.includes(q));if(!room.smm2Mechanics.completionMarks.length)removeCompletionMarks(room);}
 return remove.length;
}

/** Run once after all native leaf cleanup in the same History transaction.
 * Only formerly valid, unchanged bindings are pruned. A newly invalid edit
 * still fails strict validation instead of silently deleting the user's edit. */
export function pruneCompletionMarksReferences(rooms,beforeRooms){
 array(rooms);array(beforeRooms);let removed=0;
 for(const room of rooms){
  const marks=room?.smm2Mechanics?.completionMarks,before=beforeRooms.find(q=>q.roomId===room.roomId),old=before?.smm2Mechanics?.completionMarks;
  if(!Array.isArray(marks)||!Array.isArray(old))continue;
  const retained=marks.filter(mark=>{
   const previous=old.find(q=>q.id===mark.id);
   if(previous&&equal(previous,mark)&&completionMarkReferencesExist(before,previous,beforeRooms)&&!completionMarkReferencesExist(room,mark,rooms)){removed++;return false;}
   return true;
  });
  if(retained.length!==marks.length){room.smm2Mechanics.completionMarks=retained;if(!retained.length)removeCompletionMarks(room);}
 }
 return removed;
}

/** Explicit graph-copy API: a Map of room IDs to selected native object-ID
 * Sets must contain BOTH the portal and its typed Pink. Partial copy carries
 * no mark. This is not an integration with the single-layer clipboard UI. */
export function captureCompletionMarkBindings(room,selections,rooms){
 if(!(selections instanceof Map)||[...selections.values()].some(q=>!(q instanceof Set)))throw new TypeError('Completion mark copy needs room-scoped native selections');
 array(rooms);
 const marks=validateCompletionMarksRoom(room,rooms);if(marks===undefined)return null;
 const captured=marks.filter(q=>selections.get(room.roomId)?.has(q.portalId)&&selections.get(q.rewardRoomId)?.has(q.coinId));
 return captured.length?{roomId:room.roomId,marks:clone(captured)}:null;
}

/** Native bodies and typed leaves must already be pasted by the host. Every
 * object / mark gets a fresh ID; room remapping may stay within the same room. */
export function appendCopiedCompletionMarkBindings(room,snapshot,{roomIds,objectIds,markIds}={},rooms){
 if(snapshot===null||snapshot===undefined)return;
 if(!snapshot||![Object.prototype,null].includes(Object.getPrototypeOf(snapshot))||Reflect.ownKeys(snapshot).length!==2||!Object.hasOwn(snapshot,'roomId')||!Object.hasOwn(snapshot,'marks')||typeof snapshot.roomId!=='string')throw new TypeError('Invalid completion mark copy snapshot');
 validateCompletionMarkEntries(snapshot.marks);
 if(!(roomIds instanceof Map)||!(objectIds instanceof Map)||!(markIds instanceof Map)||roomIds.get(snapshot.roomId)!==room.roomId)throw new TypeError('Completion mark paste needs explicit room, object and mark ID maps');
 const remap=(map,key,old,label)=>{const id=map.get(key);if(typeof id!=='string'||!id.length||id===old)throw new TypeError('Completion mark paste is missing a fresh '+label);return id;};
 const marks=snapshot.marks.map(q=>{
  const targetRoom=roomIds.get(q.rewardRoomId);if(typeof targetRoom!=='string'||!targetRoom.length)throw new TypeError('Completion mark paste is missing its reward room mapping');
  return {id:remap(markIds,q.id,q.id,'mark ID'),portalId:remap(objectIds,snapshot.roomId+'\n'+q.portalId,q.portalId,'portal ID'),rewardRoomId:targetRoom,coinId:remap(objectIds,q.rewardRoomId+'\n'+q.coinId,q.coinId,'Pink ID')};
 });
 setCompletionMarks(room,[...(room.smm2Mechanics?.completionMarks??[]),...marks],rooms);
}

/** The JSON textarea is exactly the strict saved array; there is no saved
 * "completed" value, hidden default target or implicit reward-room naming. */
export function mountCompletionMarksTools({parent,room,getRooms,change,report=()=>{}}){
 if(typeof getRooms!=='function')throw new TypeError('Completion mark authoring requires complete project rooms');
 const panel=document.createElement('details');panel.id='completion-marks-tools';parent.append(panel);
 panel.innerHTML='<summary>门上粉币进度标记</summary><p class="small">仅绑定真实本房传送门和目标房 typed 粉币。运行中亲自收取粉币才变成绿色白勾；死亡重生和整局重开跟随真实粉币身份重置。标记无碰撞、不发奖。完整跨房复制仅有显式引用重映射 API，普通单图层复制按钮不会复制此绑定。</p><label>完整显式标记数组<textarea rows="8" data-completion-marks="config" spellcheck="false"></textarea></label><button type="button" data-completion-marks="apply">保存 / 更新标记</button><button type="button" data-completion-marks="remove">移除标记</button><p class="small" data-completion-marks="status"></p>';
 const get=k=>panel.querySelector('[data-completion-marks="'+k+'"]');let previous=null,saved;
 const refresh=()=>{const r=room(),serialized=JSON.stringify(r?.smm2Mechanics?.completionMarks);if(previous!==r||serialized!==saved){get('config').value=serialized===undefined?'':JSON.stringify(r.smm2Mechanics.completionMarks,null,2);previous=r;saved=serialized;}get('status').textContent=serialized===undefined?'未启用':'已绑定 '+r.smm2Mechanics.completionMarks.length+' 个门上标记；编辑预览为空心轮廓';};
 const attempt=fn=>{try{change(fn);previous=null;refresh();}catch(e){report(e.message);get('status').textContent=e.message;}};
 get('apply').onclick=()=>attempt(()=>setCompletionMarks(room(),JSON.parse(get('config').value),getRooms()));get('remove').onclick=()=>attempt(()=>removeCompletionMarks(room()));refresh();return {refresh,panel,fields:[...COMPLETION_MARK_FIELDS]};
}
