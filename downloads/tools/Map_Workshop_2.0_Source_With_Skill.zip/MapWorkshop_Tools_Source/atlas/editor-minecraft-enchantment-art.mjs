/** Original pixel enchantment bands shared by thrown and physical loot tridents.
 * Rectangles describe the item's actual local silhouette, never its broad box.
 * Call in the same translated/rotated/scaled space as the already-painted item.
 * No textures are copied, no game state is changed, and no new weapon is drawn. */
const mod=(n,d)=>((n%d)+d)%d;
export function minecraftEnchantmentBandPlan(rectangles,tick=0){
 const rects=(rectangles||[]).filter(q=>q.length===4&&q.every(Number.isFinite)&&q[2]>0&&q[3]>0);
 if(!rects.length)return [];
 const x0=Math.floor(Math.min(...rects.map(q=>q[0]))),y0=Math.floor(Math.min(...rects.map(q=>q[1]))),x1=Math.ceil(Math.max(...rects.map(q=>q[0]+q[2]))),y1=Math.ceil(Math.max(...rects.map(q=>q[1]+q[3]))),shift=Math.floor((Number.isFinite(tick)?tick:0)/3),pixels=[];
 for(let y=y0;y<y1;y++)for(let x=x0;x<x1;x++){
  const phase=mod(x+y+shift,18);if(phase>2||!rects.some(q=>x>=q[0]&&x<q[0]+q[2]&&y>=q[1]&&y<q[1]+q[3]))continue;
  pixels.push({x,y,color:phase===0?'#d5b4f6':phase===1?'#a66dd7':'#8d58bd'});
 }
 return pixels;
}
export function paintMinecraftEnchantmentGlint(c,rectangles,tick=0,{strength=.34}={}){
 const pixels=minecraftEnchantmentBandPlan(rectangles,tick);if(!pixels.length)return;
 const previousFill=c.fillStyle;c.save();c.beginPath();for(const [x,y,w,h]of rectangles)c.rect(x,y,w,h);c.clip();
 // Atop preserves the exact existing alpha, including rotated antialiased
 // boundary pixels. The local mask excludes gaps between all three prongs.
 c.globalCompositeOperation='source-atop';c.globalAlpha*=Math.max(0,Math.min(.6,strength));
 for(const p of pixels){c.fillStyle=p.color;c.fillRect(p.x,p.y,1,1);}c.restore();c.fillStyle=previousFill;
}
