import {sourcePixels} from './source-art.mjs';
import {isSmb3ArtRoom} from './editor-smb3-art.mjs';
import {SMM2_SMB1_SWITCH_SOURCE_PIXELS} from './editor-smm2-switch-source-pixels.mjs';

/** Private comparison renderer for the four inspected SMM2 reference frames.
 * Source sprites keep their original encoded pixels; palette changes are local
 * to the other study art. SMB1 ON/OFF devices use exact static source RGBA;
 * unsupported styles and Chain Chomp retain code-native approximations.
 * Source ON/highlights are one bright phase; no original blink timing verified.
 * No screenshot pixels are used as game textures or inferred animation frames.
 */
export const STUDY_PALETTE=Object.freeze({sky:'#8287fd',cyan:'#5efdfc',white:'#ffffff',shadow:'#635bd1',red:'#f12c34',redDark:'#ae242c',redLight:'#ff959c',blue:'#6052ef',blueDark:'#443cc1',blueLight:'#cac6ff'});
export const switchStudyEnabled=room=>!!room?.switchStudy;
const spriteCache=new Map();
const rgba=hex=>[parseInt(hex.slice(1,3),16),parseInt(hex.slice(3,5),16),parseInt(hex.slice(5,7),16),255];
function sourceSprite(name,style){
 const key=name+':'+style;if(spriteCache.has(key))return spriteCache.get(key);
 const data=sourcePixels(name),canvas=document.createElement('canvas');canvas.width=data.w;canvas.height=data.h;
 const c=canvas.getContext('2d'),im=c.createImageData(data.w,data.h);
 for(let i=0;i<data.pixels.length;i++){
  const p=data.pixels[i];let color=p;
  if(p[3]&&style==='solid-cloud')color=p[0]===0&&p[1]===0&&p[2]===0?rgba(STUDY_PALETTE.cyan):p;
  if(p[3]&&style==='cloud')color=p[0]===0&&p[1]===0&&p[2]===0?rgba(STUDY_PALETTE.shadow):p[0]===60&&p[1]===188?rgba(STUDY_PALETTE.cyan):p;
  if(p[3]&&style==='piranha')color=p[0]===0&&p[1]===168?rgba('#76ef12'):p[0]===252&&p[1]===152?rgba('#dcca55'):p;
  if(p[3]&&style==='gold-brick')color=p[0]===0&&p[1]===0&&p[2]===0?rgba('#c45f27'):p[0]===252&&p[1]===216?rgba('#f6d07f'):p[0]===200&&p[1]===76?rgba('#fcf0bc'):p;
  im.data.set(color,i*4);
 }
 c.putImageData(im,0,0);spriteCache.set(key,canvas);return canvas;
}
export function drawStudyBackground(c,room,w,h){if(!switchStudyEnabled(room))return false;c.fillStyle=/Underworld|Castle|Night/.test(room.setting||'')?'#000000':STUDY_PALETTE.sky;c.fillRect(0,0,w,h);return true;}
export function drawStudyScenery(c,room){
 if(!switchStudyEnabled(room))return false;
 for(const cloud of room.switchStudy.clouds||[]){const type=['Cloud1','Cloud2','Cloud3'].includes(cloud.type)?cloud.type:'Cloud1',s=sourceSprite('src|Scenery|'+type+'||','cloud');c.drawImage(s,Math.round(cloud.x),Math.round(cloud.y));}
 return true;
}
const currentState=(room,view)=>view?.switchStudy||room.switchStudyView||room.switchStudy||{};
function liveDevice(room,q,view){const state=currentState(room,view);return state.devices?.find(d=>d.id===(q.sourceId||q.id))||q;}
function isActive(device,state){return typeof device.active==='boolean'?device.active:device.kind==='switch'||((device.color||'red')==='red')===(state.on??state.initialOn??true);}
const glyphs={O:['111','101','101','101','101','101','111'],N:['1001','1101','1101','1011','1011','1001','1001'],F:['111','100','100','110','100','100','100']};
function switchLetters(c,on){const text=on?'ON':'OFF',width=on?8:11;let x=(16-width)/2;for(const letter of text){const rows=glyphs[letter];for(let y=0;y<rows.length;y++)for(let col=0;col<rows[y].length;col++)if(rows[y][col]==='1')c.fillRect(x+col,4+y,1,1);x+=rows[0].length+1;}}
function blockPixel(c,color,active){
 const p=STUDY_PALETTE,base=color==='blue'?p.blue:p.red,dark=color==='blue'?p.blueDark:p.redDark,light=color==='blue'?p.blueLight:p.redLight;
 if(active){
  c.fillStyle=p.shadow;c.fillRect(2,2,14,14);c.fillStyle=dark;c.fillRect(1,0,14,16);c.fillRect(0,1,16,14);c.fillStyle=base;c.fillRect(1,2,14,12);c.fillRect(2,1,12,14);
  c.fillStyle=light;c.fillRect(3,1,9,1);c.fillRect(1,3,1,8);c.fillRect(2,2,1,1);c.fillRect(12,2,1,1);c.fillRect(14,4,1,1);c.fillRect(9,13,1,1);c.fillRect(12,13,1,1);c.fillRect(13,12,1,1);
 }else{
  // A 14px dotted frame sits inside its unchanged 16px world cell.
  c.fillStyle=base;c.fillRect(2,1,12,2);c.fillRect(2,13,12,2);c.fillRect(1,2,2,12);c.fillRect(13,2,2,12);
  c.fillStyle=light;for(const n of [3,7,11]){c.fillRect(n,2,2,1);c.fillRect(n,13,2,1);c.fillRect(2,n,1,2);c.fillRect(13,n,1,2);}c.fillRect(2,2,1,1);c.fillRect(13,13,1,1);
 }
}
// Rooms without an art profile use this workshop's native SMB1 renderer.
// The explicit SMB3 opt-in and other style profiles keep the legacy fallback;
// SMB1 sprites are never represented as verified assets for those styles.
const originalSwitchArt=room=>!isSmb3ArtRoom(room)&&(!room.smm2Mechanics?.art?.palette||/^smb1-/.test(room.smm2Mechanics.art.palette));
function sourceDevicePixel(c,name){
 const src=SMM2_SMB1_SWITCH_SOURCE_PIXELS[name],[ox,oy]=src.cellOffset;
 for(let y=0;y<src.h;y++)for(let x=0;x<src.w;x++){
  const color=src.palette[parseInt(src.rows[y][x],36)];
  if(!color.endsWith('00')){c.fillStyle=color;c.fillRect(x+ox,y+oy,1,1);}
 }
}
function drawDevice(c,d,state,room){
 const w=d.w||16,h=d.h||16,bump=d.bump?Math.sin(d.bump/12*Math.PI)*6:0;
 c.save();c.imageSmoothingEnabled=false;c.translate(Math.round(d.x),Math.round(d.y-bump));
 if(originalSwitchArt(room)&&(d.kind==='switch'||d.kind==='block'&&['red','blue'].includes(d.color))){
  c.beginPath();c.rect(0,0,w,h);c.clip();
  if(d.kind==='switch'){
   c.scale(w/16,h/16);sourceDevicePixel(c,(state.on??state.initialOn??true)?'smb1SwitchOn':'smb1SwitchOff');
  }else{
   const name=(d.color==='blue'?'smb1BlueBlock':'smb1RedBlock')+(isActive(d,state)?'Active':'Inactive');
   for(let y=0;y<h;y+=16)for(let x=0;x<w;x+=16){c.save();c.translate(x,y);sourceDevicePixel(c,name);c.restore();}
  }
  c.restore();return;
 }
 if(d.kind==='switch'){
  c.scale(w/16,h/16);
  const on=state.on??state.initialOn??true,base=on?STUDY_PALETTE.red:STUDY_PALETTE.blue,dark=on?STUDY_PALETTE.redDark:STUDY_PALETTE.blueDark;
  c.fillStyle=STUDY_PALETTE.shadow;c.fillRect(2,2,16,16);c.fillStyle=dark;c.fillRect(0,0,16,16);c.fillStyle=base;c.fillRect(1,1,14,14);c.fillStyle=on?STUDY_PALETTE.redLight:STUDY_PALETTE.blueLight;c.fillRect(1,1,13,1);c.fillRect(1,2,1,12);c.fillStyle=on?'#a61621':'#efeeff';switchLetters(c,on);
 }else{c.beginPath();c.rect(0,0,w,h);c.clip();for(let y=0;y<h;y+=16)for(let x=0;x<w;x+=16){c.save();c.translate(x,y);blockPixel(c,d.color||'red',isActive(d,state));c.restore();}}
 c.restore();
}
function drawCloudTile(c,q){
 const sprite=sourceSprite('src|Solid|Cloud||','solid-cloud');c.save();c.beginPath();c.rect(q.x,q.y,q.w,q.h);c.clip();
 for(let y=q.y;y<q.y+q.h;y+=16)for(let x=q.x;x<q.x+q.w;x+=16){c.fillStyle=STUDY_PALETTE.blue;c.fillRect(x,y,16,16);c.drawImage(sprite,Math.round(x),Math.round(y));}
 c.restore();
}
export function drawStudyTile(c,q,room){
 if(!switchStudyEnabled(room))return false;
 if(q.material==='cloud-solid'){drawCloudTile(c,q);return true;}
 // The four observed Sky bricks retain their native, breakable Brick topology.
 // Only their local palette changes; the SMM2 diagonal hatch is approximate.
 if(q.material==='brick'&&/^s3-brick-(left|right)(@|$)/.test(q.sourceId||q.id||'')){
  const s=sourceSprite('src|Solid|Brick|normal|','gold-brick');c.save();c.beginPath();c.rect(q.x,q.y,q.w,q.h);c.clip();for(let y=q.y;y<q.y+q.h;y+=16)for(let x=q.x;x<q.x+q.w;x+=16)c.drawImage(s,Math.round(x),Math.round(y));c.restore();return true;
 }
 if(q.studyDevice||/^study-(switch|red|blue)$/.test(q.material||'')){const d=liveDevice(room,q),state=currentState(room);drawDevice(c,{...d,y:q.y,bump:0},state,room);return true;}
 return false;
}
export function drawStudyWorld(c,view={},room={}){
 if(!switchStudyEnabled(room))return false;
 const state=currentState(room,view),geometry=view.geometry||room.playGeometry||room.map?.geometry||[],drawn=new Set(geometry.filter(q=>!q.hidden).map(q=>q.sourceId||q.id));
 for(const d of state.devices||[])if(!drawn.has(d.id))drawDevice(c,d,state,room);
 return true;
}
function chainRing(c,x,y){
 c.fillStyle=STUDY_PALETTE.shadow;c.fillRect(x+3,y+2,10,10);
 for(let py=0;py<12;py++)for(let px=0;px<12;px++){const r=(px-5.5)**2+(py-5.5)**2;if(r>35||r<8)continue;c.fillStyle=r>24||r<13?'#4a4a4a':'#ffffff';c.fillRect(x+px,y+py,1,1);}
}
function drawChomp(c,o){
 const w=o.w||32,h=o.h||32;c.save();c.translate(Math.round(o.x),Math.round(o.y));c.scale(w/32,h/32);
 // Loose rings follow the body visually; they do not imply tether collision.
 chainRing(c,23,-3);chainRing(c,40,2);chainRing(c,31,19);
 for(let py=0;py<32;py++)for(let px=0;px<32;px++){const r=(px-15.5)**2+(py-15.5)**2;if(r<=246){c.fillStyle=r>214?'#4b4b4b':'#111111';c.fillRect(px,py,1,1);}}
 c.fillStyle='#ffffff';c.fillRect(19,5,7,9);c.fillRect(18,7,1,5);c.fillRect(26,7,1,5);c.fillStyle='#111111';c.fillRect(20,7,4,6);
 // Jagged white jaw/teeth and a black open mouth facing left.
 c.fillStyle='#ffffff';for(const [x,y,a,b] of [[0,16,2,5],[2,18,2,5],[4,20,2,5],[6,18,2,5],[8,15,2,5],[10,13,2,5],[12,11,2,5],[14,9,2,4],[16,11,2,5]])c.fillRect(x,y,a,b);
 c.fillStyle='#111111';c.fillRect(1,15,3,4);c.fillRect(4,16,3,5);c.fillRect(7,14,3,4);c.fillRect(10,12,3,4);c.fillRect(13,11,3,3);
 c.restore();
}
export function drawStudyActor(c,o,tick=0,room={}){
 if(!switchStudyEnabled(room))return false;
 const kind=o.type||o.skin||o.kind;
 if(kind==='study-chomp'){drawChomp(c,o);return true;}
 if(kind==='study-piranha'){
  // Native mouth frames only; the inferred cadence is cosmetic and does not
  // affect falling, collision, or contact harm. Home position keeps its phase.
  const phase=(Math.round((o.homeX??o.x)/16)%2)*12,frame=o.frame==='two'||o.source?.frame==='two'||Math.floor((tick+phase)/12)%2?'two':'',s=sourceSprite('src|Character|Piranha|'+frame+'|','piranha');
  c.drawImage(s,Math.round(o.x+(o.w-s.width)/2),Math.round(o.y+o.h-s.height));return true;
 }
 return false;
}
