/** Original authored tethered night guard. The viewed SMW-style footage proves
 * a separate head/chain/post and bounded motion, not an SMB1 attack clock.
 * All phase durations and motion values here are explicit project tuning.
 * This component owns one existing 32x32 walker. The host owns player damage;
 * never run generic walker movement, stomps, weapons or NPC transport on it. */
import {chainChompGuardOpaqueRects} from './editor-chain-chomp-guard-art.mjs';

const EPS=1e-9,copy=structuredClone;
const plain=q=>q&&typeof q==='object'&&!Array.isArray(q)&&[Object.prototype,null].includes(Object.getPrototypeOf(q));
const finite=(n,a,b)=>Number.isFinite(n)&&n>=a&&n<=b;
const integer=(n,a,b)=>Number.isSafeInteger(n)&&finite(n,a,b);
const safe=s=>typeof s==='string'&&/^[a-zA-Z0-9][a-zA-Z0-9_.:-]{0,99}$/.test(s)&&!['__proto__','constructor','prototype'].includes(s);
const rect=q=>q&&['x','y','w','h'].every(k=>Number.isFinite(q[k]))&&q.w>0&&q.h>0;
const live=q=>q&&!q.dead&&!q.dying&&!q.hidden&&!q.removed;
const center=a=>({x:a.x+a.w/2,y:a.y+a.h/2});
const lerp=(a,b,t)=>a+(b-a)*t;
const phaseFields=['idleFrames','windupFrames','lungeFrames','retractFrames','recoveryFrames'];
const motionFields=['lungeHeight','windupRetreat','retractHeight'];
export const CHAIN_CHOMP_GUARD_DEFAULTS=Object.freeze({
 leashLength:72,
 phase:Object.freeze({idleFrames:48,windupFrames:30,lungeFrames:18,retractFrames:48,recoveryFrames:36}),
 motion:Object.freeze({lungeHeight:12,windupRetreat:4,retractHeight:4}),
});
export const CHAIN_CHOMP_GUARD_STATUS='original-authored-guard-not-native-smm2-cycle';
function fields(q,allowed,label){
 if(!plain(q))throw Error('Invalid '+label);
 for(const k of Reflect.ownKeys(q))if(typeof k!=='string'||['__proto__','constructor','prototype'].includes(k)||!allowed.includes(k))throw Error('Unknown '+label+' field: '+String(k));
 for(const k of allowed)if(!Object.hasOwn(q,k))throw Error('Missing '+label+' field: '+k);
}
function point(q,label){fields(q,['x','y'],label);if(!Number.isFinite(q.x)||!Number.isFinite(q.y))throw Error('Invalid '+label+' coordinates');}
function circleRect(c,r,q){const x=Math.max(q.x,Math.min(q.x+q.w,c.x)),y=Math.max(q.y,Math.min(q.y+q.h,c.y));return (x-c.x)**2+(y-c.y)**2<=r*r+EPS;}
function actorClaimed(room,id){
 const s=room.smm2Mechanics||{};
 for(const key of ['bowserJuniors','thwomps','shoes','portableStones','localUpdrafts','parachuteActors','underwaterActors']){
  const leaf=s[key];if(Array.isArray(leaf)?leaf.some(q=>q.id===id):leaf&&Object.values(leaf).some(value=>Array.isArray(value)&&value.some(q=>q.id===id)))return true;
 }
 const variants=room.marioModules?.enemyVariants;
 return (Array.isArray(variants)?variants.some(q=>q.id===id):variants&&Object.hasOwn(variants,id))||(room.contraptions?.claws||[]).some(q=>q.actorId===id);
}
/** Strict optional record list. Omitting it preserves old document shape and
 * old walkers. Post is visible decoration with a stable ID, not a hidden solid. */
export function validateChainChompGuards(room,spec=room?.contraptions?.chainChompGuards){
 if(spec===undefined)return;
 if(!Array.isArray(spec)||spec.length>32)throw Error('Invalid chain chomp guard list');
 const map=room?.map;
 if(!map||!finite(map.width,1,32768)||!finite(map.height,1,4096)||!Array.isArray(map.objects)||!Array.isArray(map.geometry))throw Error('Chain chomp guards need a bounded native room');
 if(spec.length&&(room.aquatic||room.underwater||/Underwater/.test(room.setting||'')||room.mechanics||room.devices?.length||room.castle))throw Error('Authored chain chomp guards support dry native rooms only');
 const actorIds=new Set(),postIds=new Set(),native=[...map.objects,...map.geometry,...(room.markers||[]),...(room.decorations||[])],otherIds=new Set(Object.entries(room.contraptions||{}).filter(([key])=>key!=='chainChompGuards').flatMap(([,value])=>Array.isArray(value)?value.map(q=>q.id):[]));
 for(const q of spec){
  fields(q,['actorId','postId','post','rest','leashLength','phase','motion'],'chain chomp guard');
  if(!safe(q.actorId)||actorIds.has(q.actorId)||!safe(q.postId)||postIds.has(q.postId)||q.actorId===q.postId||native.some(o=>o.id===q.postId)||otherIds.has(q.postId))throw Error('Duplicate or invalid chain chomp actor/post ID');
  actorIds.add(q.actorId);postIds.add(q.postId);
  const a=map.objects.find(o=>o.id===q.actorId);
  if([...map.objects,...map.geometry].filter(o=>o.id===q.actorId).length!==1||a?.kind!=='walker'||!rect(a)||a.w!==32||a.h!==32||a.x<0||a.y<0||a.x+32>map.width||a.y+32>map.height||actorClaimed(room,q.actorId))throw Error('Chain chomp guard needs one unclaimed native 32 by 32 walker');
  fields(q.post,['x','y','w','h','anchorX','anchorY'],'chain chomp post');point(q.rest,'chain chomp rest');
  const p=q.post;
  if(!rect(p)||p.w!==16||p.h!==24||p.x<0||p.y<0||p.x+16>map.width||p.y+24>map.height||p.anchorX!==p.x+8||p.anchorY!==p.y+8)throw Error('Chain chomp post needs a rooted 16 by 24 stake with its explicit upper anchor');
  if(!map.geometry.some(g=>!g.hidden&&!g.motion&&['solid','oneway'].includes(g.collision)&&g.x<=p.x&&g.x+g.w>=p.x+p.w&&Math.abs(g.y-p.y-p.h)<EPS))throw Error('Chain chomp post must be rooted on actual fixed terrain');
  if(!finite(q.leashLength,32,160)||Math.hypot(q.rest.x-p.anchorX,q.rest.y-p.anchorY)>q.leashLength||q.rest.x!==a.x+16||q.rest.y!==a.y+16||q.rest.y!==p.y+p.h-16)throw Error('Chain chomp rest must match the native standing head within its finite leash');
  if(q.rest.x-16<p.x+p.w&&q.rest.x+16>p.x)throw Error('Chain chomp resting head overlaps its visible post');
  if(map.geometry.some(g=>!g.hidden&&g.collision==='solid'&&circleRect(q.rest,15.5,{...g,x:g.x+EPS,y:g.y+EPS,w:g.w-2*EPS,h:g.h-2*EPS})))throw Error('Chain chomp resting head overlaps solid terrain');
  fields(q.phase,phaseFields,'chain chomp phase');fields(q.motion,motionFields,'chain chomp motion');
  if(!integer(q.phase.idleFrames,1,36000)||!integer(q.phase.windupFrames,24,3600)||!integer(q.phase.lungeFrames,8,120)||!integer(q.phase.retractFrames,24,3600)||!integer(q.phase.recoveryFrames,1,3600))throw Error('Invalid explicit chain chomp phase timing; windup must remain readable');
  if(!finite(q.motion.lungeHeight,0,48)||!finite(q.motion.windupRetreat,0,12)||!finite(q.motion.retractHeight,0,24)||q.rest.y-16-Math.max(q.motion.lungeHeight,q.motion.retractHeight)<0)throw Error('Invalid explicit chain chomp motion');
 }
 for(const id of postIds)if(actorIds.has(id))throw Error('A chain chomp post cannot reuse an actor ID');
}

/** Exact continuous circle/AABB broad phase. Native size changes are linear.
 * The opaque pixel-run narrow phase below removes circular/square corners. */
export function sweptChainChompCircle(c0,c1,r,before,after){
 const x0=c0.x-before.x,y0=c0.y-before.y,dx=c1.x-after.x-x0,dy=c1.y-after.y-y0,dw=after.w-before.w,dh=after.h-before.h,knots=[0,1];
 for(const [a,b]of [[x0,dx],[x0-before.w,dx-dw],[y0,dy],[y0-before.h,dy-dh]])if(Math.abs(b)>EPS){const t=-a/b;if(t>0&&t<1)knots.push(t);}
 knots.sort((a,b)=>a-b);
 const sep=t=>{const x=x0+dx*t,y=y0+dy*t,w=before.w+dw*t,h=before.h+dh*t;return Math.max(0,-x,x-w)**2+Math.max(0,-y,y-h)**2;};
 for(let i=1;i<knots.length;i++){
  const lo=knots[i-1],hi=knots[i],mid=(lo+hi)/2;if(sep(lo)<=r*r+EPS||sep(hi)<=r*r+EPS)return true;
  const x=x0+dx*mid,y=y0+dy*mid,w=before.w+dw*mid,h=before.h+dh*mid,ax=x<0?x0:x>w?x0-before.w:0,bx=x<0?dx:x>w?dx-dw:0,ay=y<0?y0:y>h?y0-before.h:0,by=y<0?dy:y>h?dy-dh:0,den=bx*bx+by*by;
  if(den>0&&sep(Math.max(lo,Math.min(hi,-(ax*bx+ay*by)/den)))<=r*r+EPS)return true;
 }return false;
}
/** Earliest overlap of two linearly moving rectangles, including dimension
 * changes. Solids require positive area; damage accepts genuine edge contact. */
function sweepRect(a0,a1,b0,b1,{touch=false}={}){
 let lo=0,hi=1;const threshold=touch?-EPS:EPS;
 for(const [c,v]of [
  [a0.x+a0.w-b0.x,a1.x+a1.w-b1.x-a0.x-a0.w+b0.x],
  [b0.x+b0.w-a0.x,b1.x+b1.w-a1.x-b0.x-b0.w+a0.x],
  [a0.y+a0.h-b0.y,a1.y+a1.h-b1.y-a0.y-a0.h+b0.y],
  [b0.y+b0.h-a0.y,b1.y+b1.h-a1.y-b0.y-b0.h+a0.y],
 ]){
  if(Math.abs(v)<=EPS){if(c<=threshold)return null;continue;}
  const t=(threshold-c)/v;if(v>0)lo=Math.max(lo,t);else hi=Math.min(hi,t);
  if(lo>hi||hi<0||lo>1)return null;
 }return Math.max(0,lo);
}
function bounded(q,p,map){
 const a={x:q.post.anchorX,y:q.post.anchorY},dx=p.x-a.x,dy=p.y-a.y,d=Math.hypot(dx,dy),scale=d>q.leashLength?q.leashLength/d:1;
 return {x:Math.max(16,Math.min(map.width-16,a.x+dx*scale)),y:Math.max(16,Math.min(map.height-16,a.y+dy*scale))};
}
function newState(q,a){const c=center(a);return {version:1,phase:'idle',phaseFrame:0,cycle:0,direction:q.rest.x>=q.post.anchorX?1:-1,openMouth:false,anchor:{x:q.post.anchorX,y:q.post.anchorY},leashLength:q.leashLength,from:{...c},target:{...c},previous:{...c},lastTick:null,lastContactTick:null,blocked:false};}
function stateValid(s){return plain(s)&&s.version===1&&['idle','windup','lunge','retract','recovery'].includes(s.phase)&&integer(s.phaseFrame,0,36000)&&integer(s.cycle,0,Number.MAX_SAFE_INTEGER)&&[1,-1].includes(s.direction)&&typeof s.openMouth==='boolean'&&typeof s.blocked==='boolean'&&(s.lastTick===null||integer(s.lastTick,0,Number.MAX_SAFE_INTEGER))&&(s.lastContactTick===null||integer(s.lastContactTick,0,Number.MAX_SAFE_INTEGER))&&finite(s.leashLength,32,160)&&[s.from,s.target,s.previous,s.anchor].every(p=>plain(p)&&Number.isFinite(p.x)&&Number.isFinite(p.y));}

export function createChainChompGuards(room,{emit=()=>{}}={}){
 validateChainChompGuards(room);const spec=room?.contraptions?.chainChompGuards;if(!spec?.length)return null;
 if(typeof emit!=='function')throw Error('Chain chomp emit must be a function');
 const rules=new Map(copy(spec).map(q=>[q.actorId,q])),actors=new Map();let paused=false;
 const ownsActor=a=>rules.has(typeof a==='string'?a:a?.id);
 function decorateActor(a){
  const q=rules.get(a?.id);if(!q)return a;
  if(a.chainChompGuard!==undefined&&(!stateValid(a.chainChompGuard)||a.chainChompGuard.anchor.x!==q.post.anchorX||a.chainChompGuard.anchor.y!==q.post.anchorY||a.chainChompGuard.leashLength!==q.leashLength||a.chainChompGuard.phaseFrame>=q.phase[a.chainChompGuard.phase+'Frames']||Math.hypot(a.x+16-q.post.anchorX,a.y+16-q.post.anchorY)>q.leashLength+EPS))throw Error('Invalid chain chomp actor snapshot');
  a.chainChompGuard??=newState(q,a);a.chainChompGuardRule=copy(q);a.type='chain-chomp-guard';a.vx??=0;a.vy??=0;a.dx??=0;a.dy??=0;a.age??=0;a.dead??=false;a.grounded=false;a.support=null;actors.set(a.id,a);return a;
 }
 const event=(name,a,tick,extra={})=>emit('chain-chomp-guard',{event:name,roomId:room.roomId,actorId:a.id,postId:rules.get(a.id).postId,tick,...extra});
 function enter(a,q,phase,tick,player){
  const s=a.chainChompGuard;s.phase=phase;s.phaseFrame=0;s.from=center(a);s.target={...s.from};s.blocked=false;s.openMouth=phase==='windup'||phase==='lunge';
  if(phase==='windup'){
   s.direction=rect(player)?Math.sign(player.x+player.w/2-q.post.anchorX)||s.direction:s.direction;
   s.target=bounded(q,{x:s.from.x-s.direction*q.motion.windupRetreat,y:s.from.y-2},room.map);
  }else if(phase==='lunge')s.target=bounded(q,{x:q.post.anchorX+s.direction*q.leashLength,y:q.rest.y},room.map);
  else if(phase==='retract')s.target={...q.rest};
  else if(phase==='idle')s.cycle++;
  event('phase',a,tick,{phase,cycle:s.cycle,direction:s.direction});
  if(phase==='lunge')emit('sound',{event:'kick'});
 }
 function move(a,q,target,geometry){
  const start=center(a),end=bounded(q,target,room.map),runs=chainChompGuardOpaqueRects(a);let allowed=1,solidId=null;
  for(const g of geometry)if(rect(g)&&!g.hidden&&g.collision==='solid'){
   // A circular rejection only saves work; every actual stop uses opaque rows.
   if(!sweptChainChompCircle(start,end,16.75,g,g))continue;
   for(const run of runs){
    const b0={x:start.x-16+run.x,y:start.y-16+run.y,w:run.w,h:run.h},b1={...b0,x:b0.x+end.x-start.x,y:b0.y+end.y-start.y},t=sweepRect(b0,b1,g,g);
    if(t!==null&&t<allowed){allowed=Math.max(0,t-1e-7);solidId=g.id;}
   }
  }
  a.x=lerp(start.x,end.x,allowed)-16;a.y=lerp(start.y,end.y,allowed)-16;a.vx=a.x+16-start.x;a.vy=a.y+16-start.y;a.dx=a.vx;a.dy=a.vy;a.grounded=false;a.support=null;
  return solidId;
 }
 function stepActor(a,{tick,player,geometry,paused:hostPaused=false}={}){
  const q=rules.get(a?.id);if(!q)return false;
  if(!integer(tick,0,Number.MAX_SAFE_INTEGER)||!Array.isArray(geometry))throw Error('Chain chomp step needs a nonnegative tick and actual geometry');
  decorateActor(a);const s=a.chainChompGuard;if(paused||hostPaused||!live(a)||s.lastTick!==null&&tick<=s.lastTick)return true;
  s.lastTick=tick;s.previous=center(a);s.phaseFrame++;a.age=(a.age||0)+1;
  const duration=q.phase[s.phase+'Frames'],t=Math.min(1,s.phaseFrame/duration);let target=center(a);
  if(s.phase==='windup')target={x:lerp(s.from.x,s.target.x,t),y:lerp(s.from.y,s.target.y,t)};
  else if(s.phase==='lunge'){const eased=1-(1-t)**2;target={x:lerp(s.from.x,s.target.x,eased),y:lerp(s.from.y,s.target.y,t)-Math.sin(Math.PI*t)*q.motion.lungeHeight};}
  else if(s.phase==='retract')target={x:lerp(s.from.x,s.target.x,t),y:lerp(s.from.y,s.target.y,t)-Math.sin(Math.PI*t)*q.motion.retractHeight};
  else {const c=center(a),dx=q.rest.x-c.x,dy=q.rest.y-c.y,d=Math.hypot(dx,dy),k=d>1?1/d:1;target={x:c.x+dx*k,y:c.y+dy*k};}
  const solidId=move(a,q,target,geometry);if(solidId&&!s.blocked){s.blocked=true;event('blocked',a,tick,{phase:s.phase,solidId});}
  if(s.phaseFrame>=duration)enter(a,q,({idle:'windup',windup:'lunge',lunge:'retract',retract:'recovery',recovery:'idle'})[s.phase],tick,player);
  return true;
 }
 function playerContact(a,player,beforePlayer=player,{tick,beforeActor}={}){
  if(!ownsActor(a))return {handled:false};
  const neutral={handled:true,hurt:false,contact:false,stomp:false};
  if(paused||!live(a)||!live(player)||!rect(a)||!rect(player)||!rect(beforePlayer))return neutral;
  const s=a.chainChompGuard;if(!stateValid(s))return neutral;
  const c1=center(a),c0=rect(beforeActor)?center(beforeActor):s.previous;
  if(!sweptChainChompCircle(c0,c1,16.75,beforePlayer,player))return neutral;
  let hit=null;
  for(const run of chainChompGuardOpaqueRects(a)){
   const b0={x:c0.x-16+run.x,y:c0.y-16+run.y,w:run.w,h:run.h},b1={...b0,x:b0.x+c1.x-c0.x,y:b0.y+c1.y-c0.y},t=sweepRect(b0,b1,beforePlayer,player,{touch:true});
   if(t!==null&&(hit===null||t<hit))hit=t;
  }
  if(hit===null)return neutral;
  if(integer(tick,0,Number.MAX_SAFE_INTEGER)&&s.lastContactTick!==tick){s.lastContactTick=tick;event('head-contact',a,tick,{phase:s.phase,point:{x:lerp(c0.x,c1.x,hit),y:lerp(c0.y,c1.y,hit)}});}
  return {handled:true,hurt:true,contact:true,stomp:false,kind:'opaque-swept-head',time:hit,actorId:a.id};
 }
 function view(list=[...actors.values()]){return {version:1,status:CHAIN_CHOMP_GUARD_STATUS,guards:list.filter(a=>ownsActor(a)&&live(a)).map(a=>({actorId:a.id,postId:rules.get(a.id).postId,post:copy(rules.get(a.id).post),rest:copy(rules.get(a.id).rest),body:{x:a.x,y:a.y,w:a.w,h:a.h},state:copy(a.chainChompGuard),phase:copy(rules.get(a.id).phase),motion:copy(rules.get(a.id).motion)}))};}
 function reset(list=[...actors.values()]){for(const a of list){const q=rules.get(a.id);if(!q)continue;Object.assign(a,{x:q.rest.x-16,y:q.rest.y-16,w:32,h:32,vx:0,vy:0,dx:0,dy:0,age:0,dead:false,grounded:false,support:null});a.chainChompGuard=newState(q,a);}paused=false;}
 return Object.freeze({ownsActor,decorateActor,stepActor,playerContact,view,reset,pause(value=true){paused=!!value;},resume(){paused=false;}});
}
