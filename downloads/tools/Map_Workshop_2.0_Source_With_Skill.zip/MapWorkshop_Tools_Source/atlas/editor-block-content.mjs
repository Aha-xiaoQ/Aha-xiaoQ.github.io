import {sourceType} from './map-appearance.mjs';

/** Optional qmap v1 author metadata. Values are the existing Stage reward tokens. */
export const BLOCK_CONTENTS=Object.freeze(['coin','multi','power','mushroom','flower','life','star','vine','bill-M','bill-S','bill-F','bill-L']);
export const blockContent=q=>q?.content||q?.reward||'';
export const isRewardBlock=(room,q)=>['Brick','Block'].includes(sourceType(room,q))&&q.smm2BlockKind!=='hard-block';
export function setBlockContent(room,id,value){
 const q=room.map.geometry.find(q=>q.id===id);if(!q||!isRewardBlock(room,q))throw Error('CONTENT_OWNER: 请选择砖块或奖励块 · '+id);
 if(value===''){delete q.content;delete q.reward;return q;}
 if(!BLOCK_CONTENTS.includes(value))throw Error('CONTENT_KIND: 不支持的藏物 · '+id+' · '+value);
 q.content=value;q.reward=value;return q;
}
export function blockContentIssues(room){
 const out=[];const issue=(code,q,message)=>out.push({code,severity:'error',roomId:room.roomId,ids:[q.id],bounds:{x:q.x,y:q.y,w:q.w,h:q.h},message});
 for(const q of room.map?.geometry||[]){
  if(q.content===undefined)continue;
  if(!isRewardBlock(room,q))issue('CONTENT_OWNER',q,'藏物只能属于可顶击的砖块或奖励块');
  if(typeof q.content!=='string'||!BLOCK_CONTENTS.includes(q.content))issue('CONTENT_KIND',q,'藏物须为既有奖励类型：'+BLOCK_CONTENTS.join(', '));
  if(q.content==='vine'&&!room.map.objects.some(o=>o.kind==='portal'&&o.id.endsWith('-vine-portal')&&Math.abs(o.x-q.x)<2))out.push({code:'CONTENT_VINE_CONNECTION',severity:'warning',roomId:room.roomId,ids:[q.id],bounds:{x:q.x,y:q.y,w:q.w,h:q.h},message:'藤蔓藏物需要已有藤蔓转场 portal；当前Stage不会生成无连接的活动藤蔓'});
  if(q.reward!==undefined&&q.reward!==q.content)issue('CONTENT_ALIAS_MISMATCH',q,'content 与兼容 reward 必须一致');
 }
 return out;
}
