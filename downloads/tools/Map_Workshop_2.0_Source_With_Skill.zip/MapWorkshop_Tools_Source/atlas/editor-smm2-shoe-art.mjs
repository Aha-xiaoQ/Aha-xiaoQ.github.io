import {shoeSourcePixels} from './editor-smm2-shoe-source-pixels.mjs';
/** Verified original green-shoe pixels; Stiletto and landing blasts retain
 * explicit code approximations. Visuals never change controller bodies. */
const rect=q=>q&&['x','y','w','h'].every(k=>Number.isFinite(q[k]))&&q.w>0&&q.h>0;
const colors={shoe:['#245d0c','#63b914','#bef044'],stiletto:['#191925','#4a4b60','#9293a5']};
function pixelSprite(c,q,draw){
 c.save();c.imageSmoothingEnabled=false;c.translate(Math.round(q.x),Math.round(q.y));
 const pixel=(color,x,y,w=1,h=1)=>{c.fillStyle=color;const a=Math.round(x*q.w/16),b=Math.round(y*q.h/16);c.fillRect(a,b,Math.round((x+w)*q.w/16)-a,Math.round((y+h)*q.h/16)-b);};draw(pixel);c.restore();
}
function sourceSprite(c,actor,{winged=false,npc=false,wingOnly=false,facing=-1}={}){
 const source=shoeSourcePixels(winged,{bodyOnly:!npc}),sx=actor.w/16,sy=actor.h/16;
 c.save();c.imageSmoothingEnabled=false;c.translate(Math.round(actor.x)+(facing>0?Math.round(actor.w):0),Math.round(actor.y)-(npc?Math.round(8*sy):0));if(facing>0)c.scale(-1,1);
 for(let y=0;y<source.height;y++)for(let x=0;x<source.width;x++){
  const color=source.pixels[y*source.width+x];if(!color[3]||wingOnly&&!(color[0]===255&&color[1]>=178))continue;
  c.fillStyle=`rgba(${color[0]},${color[1]},${color[2]},${color[3]/255})`;const left=Math.round(x*sx),top=Math.round(y*sy);c.fillRect(left,top,Math.round((x+1)*sx)-left,Math.round((y+1)*sy)-top);
 }c.restore();return true;
}
/** Display bounds for tool thumbnails only, never a collider or hit region. */
export function smm2ShoeVisualBounds(actor,{facing=actor?.facing??(actor?.vx>0?1:-1)}={}){
 if(!rect(actor))return null;const s=actor.smm2Shoe||actor,head=s.occupancy==='npc'&&!actor.emerging&&!actor.moduleEmergence?actor.h/2:0,wing=s.winged?actor.w*3/16:0;
 return {x:actor.x-(facing>0?wing:0),y:actor.y-head,w:actor.w+wing,h:actor.h+head};
}
export function drawSmm2Shoe(c,actor,{tick=0,facing=actor?.facing??(actor?.vx>0?1:-1)}={}){
 if(!rect(actor)||actor.dead||actor.removed)return false;const s=actor.smm2Shoe||actor;if(!['shoe','stiletto'].includes(s.kind)||['removed','carried'].includes(s.occupancy))return false;
 const npc=s.occupancy==='npc'&&!actor.emerging&&!actor.moduleEmergence;
 if(s.kind==='shoe')return sourceSprite(c,actor,{winged:!!s.winged,npc,facing});
 const [dark,mid,light]=colors[s.kind];
 c.save();if(facing>0){c.translate(2*actor.x+actor.w,0);c.scale(-1,1);}
 // A small exposed brown head follows the actual NPC contact strip. The full
 // native Goomba body is not permanently stacked on top of the shoe.
 if(npc){const head=actor.npcBody||{x:actor.x,y:actor.y-actor.h*.5,w:actor.w,h:actor.h*.5};pixelSprite(c,head,p=>{p('#56270e',4,4,8,12);p('#aa5b1e',3,6,10,10);p('#f8d890',5,8,2,6);p('#f8d890',9,8,2,6);p('#111111',6,9,1,4);p('#111111',9,9,1,4);});}
 pixelSprite(c,actor,p=>{
  if(s.kind==='shoe'){p(dark,4,0,11,3);p(mid,5,2,9,10);p(light,6,3,7,2);p(dark,3,8,11,7);p(mid,1,10,12,5);p(light,2,11,4,2);p(dark,1,15,12,1);p(dark,13,5,2,8);}
  else{p(dark,5,0,9,3);p(mid,6,2,7,10);p(light,7,3,2,7);p(dark,3,10,10,4);p(mid,1,12,9,3);p(light,3,12,5,1);p(dark,11,11,3,5);p(light,12,12,1,3);}
 });c.restore();if(s.winged)sourceSprite(c,actor,{winged:true,wingOnly:true,facing});return true;
}
/** Native Mario idle head, fixed at the collar independently of motor pose.
 * This is a visible-pose adaptation; no original mounted composite was found. */
export function smm2ShoeSeatPose(p,shoe,sprite,{large=!!p.power}={}){
 return {x:Math.round(p.x+(p.w-sprite.width)/2),y:Math.round(shoe.y)-(large?11:7),clipBottom:Math.round(shoe.y)+2,facing:p.facing<0?-1:1};
}
export function drawSmm2ShoeRider(c,p,shoe,sprite,options={}){
 const pose=smm2ShoeSeatPose(p,shoe,sprite,options);c.save();c.imageSmoothingEnabled=false;c.beginPath();c.rect(pose.x,pose.y,sprite.width,Math.max(0,pose.clipBottom-pose.y));c.clip();c.translate(pose.x+(pose.facing<0?sprite.width:0),pose.y);c.scale(pose.facing,1);c.drawImage(sprite,0,0);c.restore();return pose;
}
export function drawSmm2ShoeFrontRim(c,p,shoe,tick=0){
 c.save();c.beginPath();c.rect(shoe.x-shoe.w,Math.round(shoe.y),shoe.w*3,Math.max(1,Math.round(shoe.h*3/16)));c.clip();drawSmm2Shoe(c,shoe,{tick,facing:p.facing});c.restore();
}
export function drawSmm2ShoeBlast(c,blast,{tick=0}={}){
 if(!rect(blast)||blast.remainingFrames<=0)return false;pixelSprite(c,blast,p=>{const step=Math.floor(tick/4)%2;p('#9db8b8',3,3+step,9,9);p('#f3ffff',1,5,5,6);p('#f3ffff',6,2+step,6,10);p('#f3ffff',11,5,4,5);p('#c5dddd',5,11,7,2);});return true;
}
