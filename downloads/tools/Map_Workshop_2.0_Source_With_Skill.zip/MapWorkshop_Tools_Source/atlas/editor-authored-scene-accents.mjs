/** Original scenery pixels for explicitly tagged decoration records.
 * The crown/young-turtle emblem is an authored Jr-themed motif, not an extracted
 * Nintendo flag. This module has no collision, actors, pickups or progression.
 * Implementation and original pixel artwork follow LICENSE-CODE.md.
 */
export const AUTHORED_SCENE_ACCENT_TAGS = Object.freeze([
  'authored-jr-gallery-flag',
  'authored-hub-crane-prize',
  'authored-hub-snake-constellation',
  'authored-hub-flight-formation'
]);
const tags = new Set(AUTHORED_SCENE_ACCENT_TAGS);
export const JR_GALLERY_FLAG_PIXELS = Object.freeze([
  'RRRRRRRRRRRRRRRR.',
  'RooooooooooooooRR',
  'RooooY.Y.YooooooR',
  'RooooYYYYYooooooR',
  'RoooooGGGoooooooR',
  'RooooWGKGGKWooooR',
  'RooooWWGGGWWooooR',
  'RoooooWWKWWoooooR',
  'RoooooWKKKWoooooR',
  'RoooooWWWWWoooooR',
  'RoooooooooooooooR',
  'RooooooooooooooRR',
  'RRRRRRRRRRRRRRRR.'
]);
const flagPalette = Object.freeze({R:'#792d22',o:'#da643d',Y:'#f8d06b',G:'#7ab64a',W:'#fff0c4',K:'#273529'});
function pixels(c, rows, palette, x, y) {
  for (let row=0; row<rows.length; row++) for (let col=0; col<rows[row].length; col++) {
    const color=palette[rows[row][col]];
    if (color) {c.fillStyle=color;c.fillRect(x+col,y+row,1,1);}
  }
}
export function isAuthoredSceneAccent(q) {
  return q?.material === 'decoration' && tags.has(q.smm2Art);
}
function flag(c,q,tick) {
  const w=23,h=14;
  if(q.facing<0){c.translate(w,0);c.scale(-1,1);}
  // The pole ends at the real pillar top, and its five-pixel foot is attached.
  c.fillStyle='#735037';c.fillRect(2,1,2,h-2);c.fillRect(1,h-2,5,2);
  c.fillStyle='#dfbd72';c.fillRect(2,1,1,h-3);c.fillRect(1,h-2,4,1);
  c.fillStyle='#fff0c4';c.fillRect(2,0,1,1);
  // A single native-pixel trailing-edge flicker leaves the emblem/pole fixed.
  const phase=Math.floor(tick/24)%2;
  // Two empty cloth padding rows are omitted for this compact fourteen-pixel
  // staff: the motif/crown pixels are unchanged and sit below the native HUD.
  const cloth=JR_GALLERY_FLAG_PIXELS.filter((_,index)=>index!==10&&index!==11);
  pixels(c,cloth,flagPalette,4,2);
  if(phase){c.fillStyle=flagPalette.R;c.fillRect(20,3,1,1);c.fillRect(20,11,1,1);}
}
function cranePrize(c) {
  c.fillStyle='#c5d9fa';
  c.fillRect(3,1,14,1);c.fillRect(10,2,1,7);
  c.fillRect(8,8,1,3);c.fillRect(12,8,1,3);
  c.fillRect(7,10,1,2);c.fillRect(13,10,1,2);
  c.fillRect(8,12,2,1);c.fillRect(11,12,2,1);
  // Small hanging prize spark, separate from the three-finger claw silhouette.
  c.fillStyle='#f2cbea';c.fillRect(10,16,1,1);c.fillRect(9,17,3,3);c.fillRect(10,20,1,1);
}
function snakeConstellation(c) {
  // Sparse points joined by one-pixel starlight, with no square terrain tiles.
  const points=[[2,8],[6,8],[10,8],[10,4],[14,4],[18,4]];
  for(const [index,[x,y]] of points.entries()){
    c.fillStyle=index===points.length-1?'#e0edd6':'#a9dfd3';c.fillRect(x,y,1,1);
  }
  c.globalAlpha*=.48;
  for(let i=1;i<points.length;i++) {
    const [ax,ay]=points[i-1],[bx,by]=points[i];
    if(ay===by)c.fillRect(ax+1,ay,bx-ax-1,1);
    else c.fillRect(ax,by+1,1,ay-by-1);
  }
  c.globalAlpha/=.48;
}
function flightFormation(c) {
  c.fillStyle='#d4dcf0';
  // Three tiny rounded flight-pack silhouettes, without arrows or weapons.
  for(const [x,y] of [[3,8],[12,3],[21,8]]) {
    c.fillRect(x+1,y,3,1);c.fillRect(x,y+1,5,2);
    c.fillRect(x-1,y+3,2,1);c.fillRect(x+4,y+3,2,1);
    c.fillRect(x+2,y+3,1,2);
  }
}
/** Draw one tagged decoration in world coordinates. Untagged input is ignored. */
export function drawAuthoredSceneAccent(c,q,room={},tick=room?.tick||0) {
  if(!isAuthoredSceneAccent(q)||q.hidden)return false;
  const priorFill=c.fillStyle;
  c.save();c.translate(Math.round(q.x),Math.round(q.y));
  if(q.smm2Art==='authored-jr-gallery-flag')flag(c,q,tick);
  else {
    // Keep the Hub motifs quieter than sprites, terrain, door/clear feedback.
    c.globalAlpha*=.22;
    if(q.smm2Art==='authored-hub-crane-prize')cranePrize(c);
    else if(q.smm2Art==='authored-hub-snake-constellation')snakeConstellation(c);
    else flightFormation(c);
  }
  c.restore();c.fillStyle=priorFill;return true;
}
/** Only explicit tags are drawn; this does not identify rooms by name. */
export function drawAuthoredSceneAccents(c,room,tick=room?.tick||0) {
  let drawn=false;
  for(const q of room?.decorations||[])drawn=drawAuthoredSceneAccent(c,q,room,tick)||drawn;
  return drawn;
}

/** Suggest attached flags from authored pillar IDs/actual geometry, not guesses.
 * The caller owns insertion into decorations; no geometry is changed here.
 */
export function jrGalleryFlagDecorations(room) {
  const result=[];
  for(const side of ['left','right']) {
    const pillar=room?.map?.geometry?.find(g=>g.id===`boss-${side}-inner-arch`);
    if(!pillar)continue;
    const facing=side==='left'?1:-1,anchorX=pillar.x+Math.floor(pillar.w/2);
    result.push({id:`boss-${side}-gallery-flag`,x:anchorX-(facing>0?3:20),y:pillar.y-14,w:23,h:14,material:'decoration',smm2Art:'authored-jr-gallery-flag',facing});
  }
  return result;
}

/** Exactly three background references; doors and HUD retain empty space. */
export function hubSceneAccentDecorations() {
  return [
    {id:'hub-crane-prize-accent',x:112,y:292,w:22,h:22,material:'decoration',smm2Art:'authored-hub-crane-prize'},
    {id:'hub-snake-stars-accent',x:174,y:310,w:22,h:12,material:'decoration',smm2Art:'authored-hub-snake-constellation'},
    {id:'hub-flight-trio-accent',x:292,y:294,w:28,h:16,material:'decoration',smm2Art:'authored-hub-flight-formation'}
  ];
}
