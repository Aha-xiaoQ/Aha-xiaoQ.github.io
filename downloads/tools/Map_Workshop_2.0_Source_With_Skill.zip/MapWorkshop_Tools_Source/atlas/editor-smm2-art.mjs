import {drawCompletionMarks} from './editor-completion-marks.mjs';
import {drawSkyShooter} from './editor-sky-shooter-art.mjs';
import {drawBowserJr} from './editor-bowser-jr-art.mjs';
import {drawSmwUnderwaterReference} from './editor-smw-underwater-art.mjs';
import {isSmm2GhostArtRoom,drawSmm2GhostBackground,drawSmm2GhostTile,drawSmm2GhostActor,ghostGroundColorAt} from './editor-smm2-ghost-art.mjs';
import {SMM2_SOURCE_PIXELS,drawSmm2SourcePixels} from './editor-smm2-source-assets.mjs';
import {sourcePixels,sourceKey} from './source-art.mjs';
import {drawSmm2Shoe,drawSmm2ShoeBlast} from './editor-smm2-shoe-art.mjs';
import {drawSmm2BoneShell,drawSmm2DryBones,drawSmm2BoneCastlePosts,drawSmm2BoneCastleStatue,drawSmm2BoneCastleFacade} from './editor-smm2-bone-art.mjs';
import {isSmb3ArtRoom,drawSmb3Background,drawSmb3Tile,drawSmb3Actor,drawSmb3World} from './editor-smb3-art.mjs';
import {drawSmm2PSwitch} from './editor-smm2-p-switch-art.mjs';
import {smm2WeightedSpringVisualPose} from './editor-smm2-spring-art.mjs';
import {SMM1_SMB1_SPRINGBOARD_SOURCE as springSource} from './editor-smm2-spring-source-pixels.mjs';

/** Private learning-study appearance, authored from visual observation.
 * Missing SMM2 components are self-written pixel approximations. Existing
 * atlas/source pixels are read without editing or recoloring. Mechanics own poses.
 * No gameplay-frame crops, DOM, room IDs, collision or game state writes.
 */
export const SMM2_ART_PALETTE=Object.freeze({
 black:'#000000',ink:'#20282a',stoneDark:'#193b40',stone:'#326369',stoneMid:'#4b797d',stoneLight:'#87aaa8',
 dirt:'#2e727a',dirtDark:'#193b49',dirtLight:'#43858a',pillarDark:'#0e292e',pillar:'#173f45',pillarLight:'#26535a',
 thwompDark:'#666a69',thwomp:'#a4a9a6',thwompLight:'#e7e9df',white:'#fffbea',
 donut:'#f5e8bc',donutDark:'#b7a680',donutLight:'#fff9de',
 red:'#e6432b',redDark:'#913625',redLight:'#ffd5a0',
 blue:'#3c46d7',blueDark:'#24216e',blueLight:'#bacbff',
 pink:'#ff80aa',pinkDark:'#b62b5b',pinkInk:'#4c1534',
 skewer:'#27616a',skewerDark:'#183d45',skewerLight:'#a8e0dd'
});
const P=SMM2_ART_PALETTE;
const enabled=room=>room?.smm2Mechanics?.version===1;
const palette=room=>enabled(room)&&room.smm2Mechanics.art?.palette==='smb1-castle-stone';
const shoePalette=room=>enabled(room)&&['smb1-snow','smb1-shoe-underworld'].includes(room.smm2Mechanics.art?.palette);
const sourceGroundProfile=room=>enabled(room)&&['smb1-underground-source','smb1-overworld-source','smb1-sky-source'].includes(room.smm2Mechanics.art?.palette);
const sourceUnderground=room=>enabled(room)&&room.smm2Mechanics.art?.palette==='smb1-underground-source';
const sourceOverworld=room=>enabled(room)&&['smb1-overworld-source','smb1-sky-source'].includes(room.smm2Mechanics.art?.palette);
const snowPalette=room=>enabled(room)&&room.smm2Mechanics.art?.palette==='smb1-snow';
export const SMM2_SHOE_SCENE_PALETTE=Object.freeze({sky:'#7883f8',snow:'#fbfcff',ice:'#c8d3ed',iceShade:'#9ca7d2',snowStone:'#a3afd0',snowDark:'#505977',teal:'#245e63',tealDark:'#102c35',tealLight:'#8fb7b7',tealShade:'#356f73'});
const S=SMM2_SHOE_SCENE_PALETTE;
const validRect=q=>q&&['x','y','w','h'].every(k=>Number.isFinite(q[k]))&&q.w>0&&q.h>0;
const visible=q=>q&&!q.hidden&&q.visible!==false&&!q.removed&&!q.dead&&!q.taken;
const finitePoint=q=>q&&Number.isFinite(q.x)&&Number.isFinite(q.y);
function rect(c,color,x,y,w=1,h=1){if(w<=0||h<=0)return;c.fillStyle=color;c.fillRect(x,y,w,h);}
function sprite(c,q,w,h,fn){
 if(!validRect(q))return false;
 c.save();c.imageSmoothingEnabled=false;c.translate(Math.round(q.x),Math.round(q.y));
 // Integer output grid preserves crisp pixels even for large component bodies.
 const targetW=Math.max(1,Math.round(q.w)),targetH=Math.max(1,Math.round(q.h));
 const pixel=(color,x,y,pw=1,ph=1)=>{
  const left=Math.round(x*targetW/w),top=Math.round(y*targetH/h),right=Math.round((x+pw)*targetW/w),bottom=Math.round((y+ph)*targetH/h);
  rect(c,color,left,top,right-left,bottom-top);
 };
 fn(pixel);c.restore();return true;
}
function mask(pixel,rows,x,y,color){for(let r=0;r<rows.length;r++)for(let col=0;col<rows[r].length;col++)if(rows[r][col]==='1')pixel(color,x+col,y+r);}
function clipped(c,q,fn){c.save();c.beginPath();c.rect(q.x,q.y,q.w,q.h);c.clip();fn();c.restore();}

export function drawSmm2Background(c,room,w,h){
 if(drawSmm2GhostBackground(c,room,w,h))return true;
 if(drawSmb3Background(c,room,w,h))return true;
 if(!(palette(room)||shoePalette(room)||sourceGroundProfile(room))||!Number.isFinite(w)||!Number.isFinite(h)||w<=0||h<=0)return false;
 rect(c,snowPalette(room)||sourceOverworld(room)?S.sky:P.black,0,0,w,h);return true;
}

/** Authored irregular rock cells, rather than a recolor of atlas pixels.
 * World anchoring makes subdivided geometry visually continuous. */
function shoeMasonry(c,q,snow=false){
 const dark=snow?S.snowDark:S.tealDark,face=snow?S.snowStone:S.teal,light=snow?S.ice:S.tealLight,shade=snow?S.iceShade:S.tealShade;
 clipped(c,q,()=>{
  rect(c,dark,q.x,q.y,q.w,q.h);
  for(let y=Math.floor(q.y/16)*16;y<q.y+q.h;y+=16)for(let x=Math.floor(q.x/16)*16;x<q.x+q.w;x+=16){
   rect(c,face,x+1,y+1,8,6);rect(c,light,x+1,y+1,8,1);rect(c,shade,x+1,y+2,1,5);
   rect(c,face,x+10,y+1,5,10);rect(c,light,x+10,y+1,5,1);rect(c,light,x+10,y+2,1,8);
   rect(c,face,x+1,y+8,8,7);rect(c,light,x+1,y+8,7,1);rect(c,light,x+1,y+9,1,5);
   rect(c,face,x+10,y+12,5,3);rect(c,light,x+10,y+12,5,1);
   rect(c,dark,x+6,y+5,3,2);rect(c,light,x+6,y+5,2,1);rect(c,shade,x+4,y+12,4,1);
  }
 });
}
/** Public original 16px SMB1 Underground cell; world anchoring keeps splits aligned. */
function originalUndergroundGround(c,q,room){
 const ox=room.smm2Mechanics?.art?.tileOriginX??0,oy=room.smm2Mechanics?.art?.tileOriginY??0;
 clipped(c,q,()=>{for(let y=Math.floor((q.y-oy)/16)*16+oy;y<q.y+q.h;y+=16)for(let x=Math.floor((q.x-ox)/16)*16+ox;x<q.x+q.w;x+=16)drawSmm2SourcePixels(c,'undergroundGround',{x,y,...(sourceOverworld(room)?{paletteMap:{'#000000ff':'#1f1f1fff','#165966ff':'#ba6111ff','#98b6adff':'#ffd9b2ff'}}:{})});});
}
function snowGround(c,q,{cap=true}={}){
 shoeMasonry(c,q,true);
 if(cap)clipped(c,q,()=>{rect(c,S.snow,q.x,q.y,q.w,3);for(let x=q.x;x<q.x+q.w;x+=16){rect(c,S.snow,x+2,q.y+3,10,2);rect(c,S.ice,x+4,q.y+5,6,1);rect(c,S.ice,x+12,q.y+2,3,1);}});
}

export function drawSmm2SnowScenery(c,q,room={}){
 if(!snowPalette(room)||!validRect(q)||!visible(q))return false;
 const type=q.nativeScenery?.type,style=q.smm2Art;
 const hill=style==='snow-scenery-hill'||['HillLarge','HillSmall'].includes(type),cloud=style==='snow-scenery-cloud'||['Cloud1','Cloud2','Cloud3'].includes(type);
 if(!hill&&!cloud)return false;
 if(hill)return sprite(c,q,Math.round(q.w),Math.round(q.h),p=>{
  const w=Math.round(q.w),h=Math.round(q.h),cx=(w-1)/2;
  for(let y=0;y<h;y++){const half=Math.min(cx,3+y*(w/2-3)/Math.max(1,h-1)),left=Math.ceil(cx-half),right=Math.floor(cx+half);p(S.iceShade,left-1,y,right-left+3);p(S.ice,left,y,right-left+1);}
  for(const [x,y]of [[Math.round(w*.46),4],[Math.round(w*.33),Math.round(h*.54)],[Math.round(w*.69),Math.round(h*.67)]]){p(S.snowDark,x,y,2,4);p(S.snowDark,x+3,y+2,2,3);}
 });
 // The existing clouds already have the exact white/cyan native SMB1 outline.
 const cloudType=['Cloud1','Cloud2','Cloud3'].includes(type)?type:q.w>=60?'Cloud3':q.w>=44?'Cloud2':'Cloud1',key=sourceKey('Scenery',cloudType),native=sourcePixels(key);
 return nativePixels(c,key,{x:q.x,y:q.y,w:native.w,h:native.h});
}

/** Scaled native silhouettes/palette adaptation for authored source-study scenery.
 * Decorations only; exact SMM2 background sprites/parallax were not recovered. */
function nativeSourceDecoration(c,type,q,paletteMap){
 const key=sourceKey('Scenery',type),native=sourcePixels(key);
 // Source measurements may differ by one pixel from a complete sprite. Keep
 // the native silhouette and a uniform integer scale instead of squeezing a
 // 16x46 capsule into a measured16x45 box or stretching a64px bush to65px.
 const scale=Math.max(1,Math.floor(Math.min((q.w+1)/native.w,(q.h+1)/native.h))),w=native.w*scale,h=native.h*scale;
 return nativePixels(c,key,{x:Math.round(q.x+(q.w-w)/2),y:Math.round(q.y+q.h-h),w,h},{paletteMap});
}
export function drawSmm2SourceScenery(c,q,room={}){
 if(!sourceOverworld(room)||!visible(q)||!validRect(q))return false;
 if(q.smm2Art==='source-scenery-hill')return nativePixels(c,sourceKey('Scenery','HillLarge'),q,{paletteMap:{'0,0,0':'#286556','0,168,0':'#50a88b'}});
 if(q.smm2Art==='source-scenery-hill-edge')return sprite(c,q,16,20,p=>{
  // Only the observed rising edge is reconstructed. No unseen full hill
  // or expanded room extent is implied by this clipped scenery fragment.
  const observedTop=[14,11,9,7,6,5,4,3,2,2,1,1,0,0,0,0];
  for(let x=0;x<16;x++){const top=observedTop[x];p('#286556',x,top,1,20-top);p('#50a88b',x,top+1,1,19-top);}
 });
 if(q.smm2Art==='source-scenery-cloud')return nativePixels(c,sourceKey('Scenery',q.w>=60?'Cloud3':q.w>=44?'Cloud2':'Cloud1'),q,{paletteMap:{'0,0,0':'#245e63','60,188,252':'#68d4df'}});
 const plantPalette={'0,0,0':'#286556','128,208,16':'#b6ce68','252,216,168':'#ffd9b2'};
 if(q.smm2Art==='source-scenery-bush'){
  const type=['Bush1','Bush2','Bush3'].includes(q.nativeScenery?.type)?q.nativeScenery.type:['Bush1','Bush2','Bush3'].reduce((best,name)=>Math.abs(sourcePixels(sourceKey('Scenery',name)).w-q.w)<Math.abs(sourcePixels(sourceKey('Scenery',best)).w-q.w)?name:best,'Bush1');
  return nativeSourceDecoration(c,type,q,{...plantPalette,'0,168,0':'#50a88b'});
 }
 if(q.smm2Art==='source-scenery-capsule-plant')return nativeSourceDecoration(c,'PlantLarge',q,plantPalette);
 if(q.smm2Art==='source-scenery-round-plant'){
  // The native round crown stays 14px wide; short source plants expose only
  // that crown and a tiny stem. Palette/crop adaptation is explicit.
  const tall=q.h>16,insetY=2;
  return nativePixels(c,sourceKey('Scenery','PlantSmall'),{x:q.x+1,y:q.y+insetY,w:q.w-2,h:q.h-insetY},{cropH:tall?30:14,paletteMap:plantPalette});
 }
 if(q.smm2Art==='source-scenery-plant-stem')return nativePixels(c,sourceKey('Scenery','PlantSmall'),q,{cropX:3,cropW:8,cropY:14,cropH:16,paletteMap:plantPalette});

 return false;
}

/** An independent, explicitly typed NPC Spring uses the original standing
 * pixels and its actual compressed body. The reusable row pose is pure;
 * reading it does not make this a weighted/carried Spring or own its timer.
 * Compression rows remain an authored adaptation, not an original frame rip.
 */
export function drawSmm2StaticNpcSpring(c,q,room={}){
 if(!enabled(room)||room.smm2Mechanics.art?.palette?.startsWith('smb3-')||!validRect(q)||!visible(q)||q.material!=='spring'||q.springOrientation==='horizontal'||q.smm2CarrierGeometry)return false;
 const id=q.sourceId||q.id,rule=room.smm2Mechanics.springs?.find(s=>s.id===id),authored=room.map?.geometry?.find(g=>g.id===id);
 if(!rule?.npcContact||rule.orientation!=='vertical'||room.smm2Mechanics.carrierGeometry?.some(s=>s.id===id)||!authored||authored.material!=='spring'||authored.w!==16||authored.h!==16||authored.motion||q.w!==16||q.h>16||(q.restH!==undefined&&q.restH!==16))return false;
 const p=smm2WeightedSpringVisualPose({...q,restH:16});if(!p)return false;
 const fillStyle=c.fillStyle;c.save();c.imageSmoothingEnabled=false;
 for(const strip of p.strips){
  const row=springSource.rows[strip.sourceRow];
  for(let x=0;x<springSource.width;){let end=x+1;while(end<springSource.width&&row[end]===row[x])end++;
   const color=springSource.palette[Number(row[x])];
   if(color[3]){c.fillStyle='#'+color.map(v=>v.toString(16).padStart(2,'0')).join('');c.fillRect(p.x+x,p.y+strip.y,end-x,strip.h);}x=end;
  }
 }
 c.restore();c.fillStyle=fillStyle;return true;
}

/** Preserve the existing native castle composition and brick pixels. The
 * source-study overworld uses the inspected brown/gold palette, independently
 * of collision geometry and the original renderer used by other themes. */
export function drawSmm2SourceCastle(c,parts,room={}){
 if(!sourceOverworld(room))return false;
 const small=[];
 for(const marker of room.markers||[]){
  const q=marker.source||{};
  if(q.macro==='CastleSmall')small.push({x:marker.x,y:marker.y-80,w:80,h:80});
  else if(marker.kind==='flagpole-finish'&&!q.large)small.push({x:marker.x+2*(q.castleDistance||32),y:marker.y-80,w:80,h:80});
 }
 const paletteMap={'200,76,12':'#ba6111','252,216,168':'#ffd9b2','0,0,0':'#1f1f1f'};
 for(const q of parts)if(!small.some(s=>q.x>=s.x&&q.y>=s.y&&q.x+q.w<=s.x+s.w&&q.y+q.h<=s.y+s.h))nativePixels(c,q.name,q,{paletteMap});
 for(const q of small)drawSmm2SourcePixels(c,'overworldFortress',q);
 return true;
}

/** Snow rests on the original castle's railing pieces; native masonry, door
 * and its 80×80 composition are left at their original dimensions. */
export function drawSmm2CastleSnow(c,parts,room={}){
 if(!snowPalette(room))return false;let drawn=false;
 for(const q of parts)if(/\|CastleRailing(?:Filled)?\|/.test(q.name)){
  clipped(c,q,()=>{rect(c,S.snow,q.x,q.y,q.w,2);rect(c,S.snow,q.x+1,q.y+2,4,3);rect(c,S.snow,q.x+9,q.y+2,5,3);rect(c,S.ice,q.x+2,q.y+5,2,1);});drawn=true;
 }return drawn;
}

function masonry(c,q){
 clipped(c,q,()=>{
  rect(c,P.stoneDark,q.x,q.y,q.w,q.h);
  for(let y=Math.floor(q.y/8)*8;y<q.y+q.h;y+=8){
   const shift=(Math.floor(y/8)%2)*8;
   for(let x=Math.floor((q.x-shift)/16)*16+shift;x<q.x+q.w;x+=16){
    rect(c,P.stone,x+1,y+1,14,6);rect(c,P.stoneLight,x+1,y+1,14,1);rect(c,P.stoneMid,x+1,y+2,1,4);
    rect(c,P.stoneMid,x+5,y+3,6,1);rect(c,P.stoneDark,x+3,y+5,5,1);rect(c,P.stoneLight,x+11,y+4,2,1);
   }
  }
 });
}
function groundFill(c,q){
 clipped(c,q,()=>{
  rect(c,P.dirt,q.x,q.y,q.w,q.h);
  // Authored pebbles, anchored in world space so adjacent fill cells join.
  // No tile border or masonry cap belongs to this interior material.
  for(let y=Math.floor(q.y/16)*16;y<q.y+q.h;y+=16)for(let x=Math.floor(q.x/16)*16;x<q.x+q.w;x+=16){
   const shift=((Math.floor(x/16)+Math.floor(y/16))&1)*3;
   for(const [px,py,w,h]of [[2,3,2,2],[8,1,1,1],[12,4,2,3],[5,10,2,3],[11,12,2,2],[1,14,1,1],[7,6,1,2]])rect(c,P.dirtDark,x+(px+shift)%14,y+py,w,h);
   rect(c,P.dirtLight,x+(4+shift)%14,y+2,1,1);rect(c,P.dirtLight,x+(9+shift)%14,y+11,1,1);
  }
 });
}
function ground(c,q){groundFill(c,q);masonry(c,{...q,h:Math.min(q.h,16)});}
function semisolidBody(c,q){
 clipped(c,q,()=>{
  for(let x=Math.floor(q.x/16)*16+4;x<q.x+q.w;x+=16){
   rect(c,P.pillarDark,x,q.y,5,q.h);rect(c,P.pillar,x+1,q.y,3,q.h);rect(c,P.pillarLight,x+1,q.y,1,q.h);
   for(let y=Math.floor(q.y/8)*8+7;y<q.y+q.h;y+=8)rect(c,P.pillarDark,x+1,y,3,1);
  }
 });
}
function flowerCenter(c,q){
 return sprite(c,q,16,16,p=>{
  mask(p,['00011000','00111100','01111110','11100111','11100111','01111110','00111100','00011000'],4,4,P.blueDark);
  p(P.blue,7,4,2,3);p(P.blue,4,7,3,2);p(P.blue,9,7,3,2);p(P.blue,7,9,2,3);p(P.blueLight,7,7,2,2);
 });
}
/** Semisolid cap is solid-looking; declared pillars below it have black gaps.
 * The pillar artwork does not create or imply additional collision geometry. */
export function drawSmm2Semisolid(c,q){
 if(!validRect(q)||!visible(q))return false;
 const cap=Math.min(q.h,Number.isFinite(q.topThickness)?Math.max(1,q.topThickness):8),spacing=Number.isFinite(q.pillarSpacing)?Math.max(8,q.pillarSpacing):16;
 clipped(c,q,()=>{
  for(let x=q.x+3;x<q.x+q.w;x+=spacing){
   rect(c,P.pillarDark,x,q.y+cap,6,q.h-cap);rect(c,P.pillar,x+1,q.y+cap,4,q.h-cap);rect(c,P.pillarLight,x+1,q.y+cap,1,q.h-cap);
   for(let y=q.y+cap+7;y<q.y+q.h;y+=8)rect(c,P.pillarDark,x+1,y,4,1);
  }
  for(let x=q.x;x<q.x+q.w;x+=8){rect(c,P.stoneDark,x,q.y,8,cap);rect(c,P.stoneMid,x+1,q.y+1,6,Math.max(1,cap-2));rect(c,P.stoneLight,x+1,q.y+1,6,1);}
 });return true;
}

export function drawSmm2Tile(c,q,room={}){
 if(drawSmm2StaticNpcSpring(c,q,room))return true;
 if(drawSmm2GhostTile(c,q,room))return true;
 if(drawSmm2SourceScenery(c,q,room))return true;
 if(drawSmb3Tile(c,q,room))return true;
 if(!enabled(room)||!validRect(q)||!visible(q)||q.used||q.material==='used')return false;
 // Native bricks, rewards, pipes and coins always retain their existing path.
 if(sourceOverworld(room)&&q.material==='brick'){
  const key=sourceKey('Solid','Brick',room.setting||'');
  clipped(c,q,()=>{for(let y=q.y;y<q.y+q.h;y+=16)for(let x=q.x;x<q.x+q.w;x+=16)nativePixels(c,key,{x,y,w:16,h:16},{paletteMap:{'200,76,12':'#ba6111','0,0,0':'#1f1f1f'}});});
  return true;
 }
 if(['brick','block','pipe','pipe-side','cloud-solid'].includes(q.material))return false;
 const original=room.map?.geometry?.find(g=>g.id===(q.sourceId||q.id))??room.decorations?.find(g=>g.id===(q.sourceId||q.id));
 const style=q.smm2Art??original?.smm2Art;
 if(palette(room)&&q.material==='platform'&&room.decorations?.some(d=>d.id===(q.sourceId||q.id)+'-posts'&&d.smm2Art==='bone-castle-semisolid-posts'))return true; // Original bone caps are painted by the scenery body once.
 if(style==='native-castle-floor')return false;
 if(style&&original)q={...original,...q,smm2Art:style};
 if(style==='bone-castle-semisolid-posts')return drawSmm2BoneCastlePosts(c,q);
 if(style==='bone-castle-statue')return drawSmm2BoneCastleStatue(c,q);
 if(style==='bone-castle-facade')return drawSmm2BoneCastleFacade(c,q);
 if(snowPalette(room)&&['snow-scenery-hill','snow-scenery-cloud'].includes(style))return true; // The scenery pass already owns these background bodies.
 // Native stone is a distinct hard block, never the course's ground texture.
 if(style==='shoe-hard-block'||q.smm2BlockKind==='hard-block')return false;
 if(['smb1-underground-ground','smb1-overworld-ground'].includes(style)||sourceGroundProfile(room)&&q.material==='ground'){originalUndergroundGround(c,q,room);return true;}
 if(style==='snow-ground'||snowPalette(room)&&q.material==='ground'){snowGround(c,q);return true;}
 if(style==='snow-ground-fill'){snowGround(c,q,{cap:false});return true;}
 if(['shoe-underground-ground','shoe-underground-masonry'].includes(style)||shoePalette(room)&&!snowPalette(room)&&q.material==='ground'){shoeMasonry(c,q);return true;}
 if(shoePalette(room)&&!snowPalette(room)&&q.material==='platform')return drawSmm2Semisolid(c,q);
 if(style==='castle-ground-fill'){groundFill(c,q);return true;}
 if(style==='castle-semisolid-body'){semisolidBody(c,q);return true;}
 if(style==='flower-center')return flowerCenter(c,q);
 if(style==='unresolved-rail-shell')return drawSmm2BuzzyShell(c,q);
 if(style==='castle-semisolid')return drawSmm2Semisolid(c,q);
 if(style==='castle-stone'){masonry(c,q);return true;}
 if(style==='castle-ground'||palette(room)&&q.material==='ground'){ground(c,q);return true;}
 return false;
}

/** Face remains upright. Pupils/brows show the real left/down/right direction. */
export function drawSmm2Thwomp(c,actor){
 if(!visible(actor)||!validRect(actor))return false;
 const state=actor.smm2Thwomp||{},angry=['windup','charge','impact'].includes(state.phase),direction=state.direction||'down';
 return sprite(c,actor,24,32,p=>{
  // Stepped spikes lie inside the actor's complete physical footprint.
  for(const x of [1,6,11,16,21]){
   p(P.thwompDark,x,0);p(P.thwompLight,x,1);p(P.thwompLight,x-1,2,3);p(P.thwompDark,x-1,3,3);
   p(P.thwompDark,x,31);p(P.thwompLight,x,30);p(P.thwompLight,x-1,29,3);p(P.thwompDark,x-1,28,3);
  }
  for(const y of [5,11,17,23])for(const side of [0,21]){
   p(P.thwompDark,side,y+1,3,3);p(P.thwompLight,side===0?1:22,y+1,1,3);p(P.thwompLight,side===0?0:23,y+2);
  }
  p(P.thwompDark,3,3,18,26);p(P.thwompLight,4,4,16,24);p(P.thwomp,5,5,14,22);p(P.thwompDark,19,5,1,22);p(P.thwompDark,5,27,14,1);
  for(const [x,y]of [[6,6],[15,5],[7,17],[17,18],[6,24],[17,25],[12,17]])p(P.thwompLight,x,y);
  for(const [x,y]of [[6,16],[16,7],[8,26],[16,24],[11,6]])p(P.thwompDark,x,y);
  p(P.thwompDark,6,9,5,7);p(P.thwompDark,13,9,5,7);
  p(P.white,7,10,3,4);p(P.white,14,10,3,4);
  const dx=direction==='left'?-1:direction==='right'?1:0,dy=direction==='down'?1:0;
  p(P.ink,8+dx,11+dy,2,3);p(P.ink,15+dx,11+dy,2,3);
  if(angry){mask(p,['11000','01100','00110','00011'],6,8,P.ink);mask(p,['00011','00110','01100','11000'],13,8,P.ink);}
  else {p(P.thwompDark,7,8,3);p(P.thwompDark,14,8,3);}
  if(angry){
   p(P.ink,6,20,12,6);p(P.white,7,21,10,4);p(P.thwompDark,7,23,10,1);
   for(const x of [9,12,15])p(P.thwompDark,x,21,1,4);
  }else mask(p,['0011111100','0110000110','1100000011'],7,21,P.thwompDark);
 });
}

/** Verified original SMM SMB-style static 16px sprite, preserving its RGBA.
 * Contact shake and native-cell tiling are author adaptations, not original
 * animation frames or a claim of byte-identical SMM2 artwork. */
export function drawSmm2Donut(c,q,tick=0){
 if(!visible(q)||!validRect(q)||q.phase==='removed')return false;
 const shake=q.phase==='shaking'?((Math.floor((q.contactFrames??tick)/2)%2)?1:-1):0;
 const width=Math.max(1,Math.round(q.w)),height=Math.max(1,Math.round(q.h));
 c.save();c.translate(Math.round(q.x)+shake,Math.round(q.y));
 c.beginPath();c.rect(0,0,width,height);c.clip();
 for(let y=0;y<height;y+=16)for(let x=0;x<width;x+=16)
  drawSmm2SourcePixels(c,'donutBlock',{x,y,sourceWidth:Math.min(16,width-x),sourceHeight:Math.min(16,height-y)});
 c.restore();return true;
}

/** Rasterize the declared bar angle: no synthetic horizontal collision bar. */
export function drawSmm2Seesaw(c,q){
 if(!visible(q)||![q.pivotX,q.pivotY,q.length,q.thickness,q.angleDegrees].every(Number.isFinite)||q.length<=0||q.thickness<=0)return false;
 const angle=q.angleDegrees*Math.PI/180,co=Math.cos(angle),si=Math.sin(angle),half=q.length/2,t=q.thickness/2;
 const rx=Math.abs(co)*half+Math.abs(si)*t,ry=Math.abs(si)*half+Math.abs(co)*t;
 for(let y=Math.floor(q.pivotY-ry);y<Math.ceil(q.pivotY+ry);y++)for(let x=Math.floor(q.pivotX-rx);x<Math.ceil(q.pivotX+rx);x++){
  const dx=x+.5-q.pivotX,dy=y+.5-q.pivotY,u=dx*co+dy*si,v=-dx*si+dy*co;
  if(Math.abs(u)>half||Math.abs(v)>t)continue;
  const color=Math.abs(u)>half-1||v>t-1?P.redDark:v<-t+2?P.redLight:P.red;
  rect(c,color,x,y);
 }
 // The visible central axle is an attachment, sized from the declared bar.
 const radius=Math.max(2,Math.min(4,q.thickness/2)),cx=Math.round(q.pivotX),cy=Math.round(q.pivotY);
 for(let y=-Math.ceil(radius);y<=Math.ceil(radius);y++)for(let x=-Math.ceil(radius);x<=Math.ceil(radius);x++){
  const d=x*x+y*y;if(d>radius*radius)continue;rect(c,d>(radius-1)**2?P.redDark:d>1?P.redLight:P.red,cx+x,cy+y);
 }
 return true;
}

export function drawSmm2Slope(c,q,room={}){
 const spec=q?.spec??q,orientation=q?.orientation??spec?.orientation;
 if(!visible(q)||!visible(spec)||!validRect(spec)||!['rise-left','rise-right','ceiling-rise-left','ceiling-rise-right'].includes(orientation))return false;
 const right=orientation.endsWith('rise-right'),solidAbove=typeof q.solidAbove==='boolean'?q.solidAbove:orientation.startsWith('ceiling-');
 const diagonal={a:{x:spec.x,y:spec.y+(right?spec.h:0)},b:{x:spec.x+spec.w,y:spec.y+(right?0:spec.h)}};
 const line=solidAbove?(q.underside??diagonal):(q.a&&q.b?{a:q.a,b:q.b}:diagonal);
 if(!finitePoint(line?.a)||!finitePoint(line?.b)||Math.abs(line.b.x-line.a.x)<1e-7)return false;
 const offset=solidAbove?-spec.thickness:0;
 const strip=spec.thickness===undefined?null:[{x:diagonal.a.x,y:diagonal.a.y+offset},{x:diagonal.b.x,y:diagonal.b.y+offset},{x:diagonal.b.x,y:diagonal.b.y+offset+spec.thickness},{x:diagonal.a.x,y:diagonal.a.y+offset+spec.thickness}];
 const polygon=q.polygon??strip??(solidAbove?[{x:spec.x,y:spec.y},{x:spec.x+spec.w,y:spec.y},{x:right?spec.x:spec.x+spec.w,y:spec.y+spec.h}]:[diagonal.a,diagonal.b,{x:right?spec.x+spec.w:spec.x,y:spec.y+spec.h}]);
 if(!Array.isArray(polygon)||polygon.length<3||polygon.length>32||!polygon.every(finitePoint))return false;
 const inside=(x,y)=>{
  let sign=0;
  for(let n=0;n<polygon.length;n++){
   const a=polygon[n],b=polygon[(n+1)%polygon.length],cross=(b.x-a.x)*(y-a.y)-(b.y-a.y)*(x-a.x);
   if(Math.abs(cross)<1e-7)continue;
   const next=Math.sign(cross);if(sign&&sign!==next)return false;sign=next;
  }
  return sign!==0;
 };
 const minX=Math.min(...polygon.map(p=>p.x)),maxX=Math.max(...polygon.map(p=>p.x)),minY=Math.min(...polygon.map(p=>p.y)),maxY=Math.max(...polygon.map(p=>p.y));
 for(let y=Math.floor(minY);y<Math.ceil(maxY);y++)for(let x=Math.floor(minX);x<Math.ceil(maxX);x++){
  const px=x+.5,py=y+.5;
  if(px<minX||px>=maxX||py<minY||py>=maxY||!inside(px,py))continue;
  const edge=line.a.y+(px-line.a.x)*(line.b.y-line.a.y)/(line.b.x-line.a.x);
  const distance=solidAbove?edge-py:py-edge,mortar=(Math.floor(x)%16===0||Math.floor(distance)%8===7);
  if(isSmm2GhostArtRoom(room)){rect(c,ghostGroundColorAt(x,y,room,distance),x,y);continue;}
  if(sourceGroundProfile(room)){const im=SMM2_SOURCE_PIXELS.undergroundGround,ox=room.smm2Mechanics.art.tileOriginX??0,oy=room.smm2Mechanics.art.tileOriginY??0,ix=((x-ox)%16+16)%16,iy=((y-oy)%16+16)%16;let color=distance<1?'#98b6adff':im.palette[parseInt(im.rows[iy][ix],36)];if(sourceOverworld(room))color={'#000000ff':'#1f1f1fff','#165966ff':'#ba6111ff','#98b6adff':'#ffd9b2ff'}[color]??color;rect(c,color,x,y);continue;}
  rect(c,distance<1?P.stoneLight:distance<8?(mortar?P.stoneDark:P.stone):((x*3+y*5)%13===0?P.dirtDark:P.dirt),x,y);
 }
 return true;
}

const LETTERS={P:['110','101','110','100','100'],O:['010','101','101','101','010'],W:['101','101','101','111','101']};
export function drawSmm2Pow(c,q){
 if(!visible(q)||!validRect(q)||['spent','removed'].includes(q.smm2Pow?.phase))return false;
 return sprite(c,q,16,16,p=>{
  p(P.blueDark,1,0,14,16);p(P.blueLight,2,0,12,1);p(P.blue,2,1,12,14);p(P.blueLight,1,2,1,12);p(P.white,2,14,12,1);p(P.blueDark,14,1,1,14);
  for(const [ch,x]of [['P',3],['O',7],['W',11]])mask(p,LETTERS[ch],x,5,P.white);
 });
}

const effectVisible=q=>q&&!q.hidden&&q.visible!==false&&!q.removed&&!q.taken&&(!Number.isFinite(q.life)||q.life>0);

/** A copied dead enemy is a live death effect. Only appearance is flipped;
 * the Stage remains the sole owner of its ballistic position and lifetime. */
export function drawSmm2ThwompDeath(c,q,tick=0){
 if(!effectVisible(q)||!validRect(q))return false;
 const body={...q,x:0,y:0,dead:false};
 c.save();c.translate(Math.round(q.x),Math.round(q.y)+Math.round(q.h));c.scale(1,-1);
 const drawn=drawSmm2Thwomp(c,body);
 if(drawn&&q.winged===true)drawSmm2Wings(c,body,Number.isFinite(q.age)?q.age:tick);
 c.restore();return drawn;
}

/** Authored short POW burst inside the actual effect rectangle. It uses the
 * supplied age/life for appearance, never moves the effect or adds a collider. */
export function drawSmm2PowEffect(c,q){
 if(!effectVisible(q)||!validRect(q))return false;
 const age=Number.isFinite(q.age)?Math.max(0,q.age):0,life=Number.isFinite(q.life)?Math.max(0,q.life):16;
 const progress=Math.min(1,age/Math.max(1,age+life)),flash=Math.floor(age/2)%2===0;
 return sprite(c,q,48,48,p=>{
  const radius=7+Math.floor(progress*15),rayColor=flash?P.white:P.blueLight;
  for(let n=0;n<8;n++){
   const a=n*Math.PI/4,dx=Math.round(Math.cos(a)*radius),dy=Math.round(Math.sin(a)*radius);
   p(rayColor,23+dx,23+dy,2,2);
   if(progress>.25)p(P.blueLight,23+Math.round(dx*.8),23+Math.round(dy*.8),1,1);
  }
  if(progress<.7){
   const size=14+Math.floor(progress*18),left=(48-size)/2,scale=size/16;
   const stamp=(color,x,y,w=1,h=1)=>p(color,left+x*scale,left+y*scale,w*scale,h*scale);
   stamp(P.blueDark,1,0,14,16);stamp(P.blueLight,2,0,12,1);stamp(flash&&age>1?P.white:P.blue,2,1,12,14);stamp(P.blueLight,1,2,1,12);stamp(P.white,2,14,12,1);
   for(const [ch,x]of [['P',3],['O',7],['W',11]])mask(stamp,LETTERS[ch],x,5,flash&&age>1?P.blueDark:P.white);
  }
 });
}

function nativePixels(c,key,q,{cropX=0,cropW,cropY=0,cropH,paletteMap={}}={}){
 const native=sourcePixels(key),height=cropH??native.h,width=cropW??native.w;
 return sprite(c,q,width,height,p=>{
  for(let y=0;y<height;y++)for(let x=0;x<width;x++){
   const color=native.pixels[(y+cropY)*native.w+x+cropX];if(!color?.[3])continue;
   p(paletteMap[color.slice(0,3).join(',')]??`rgba(${color[0]},${color[1]},${color[2]},${color[3]/255})`,x,y);
  }
 });
}

/** Mouth orientation is read from real source/traversal declarations.
 * Portal direction is travel into the pipe; arrival/source direction is out. */
export function smm2PipeDirection(q,room={}){
 if(!enabled(room)||!q)return null;
 const id=q.sourceId||q.id,m=room.marioModules||{},opposite={up:'down',down:'up',left:'right',right:'left'},directions=[];
 for(const s of [...(m.itemSources||[]),...(m.enemySources||[])])if(s.pipeId===id)directions.push(s.direction);
 for(const s of Object.values(m.arrivalDirections||{}))if(s.pipeId===id)directions.push(s.direction);
 for(const s of Object.values(m.portalDirections||{}))if(s.pipeId===id)directions.push(opposite[s.direction]);
 if(!directions.length&&room.smm2Mechanics?.version===1){const facing=room.semantics?.find(s=>s.id===id&&['Pipe','PipeVertical','PipeHorizontal'].includes(s.kind))?.source?.direction;if(Object.hasOwn(opposite,facing))directions.push(facing);}
 const unique=[...new Set(directions)];return unique.length===1&&Object.hasOwn(opposite,unique[0])?unique[0]:null;
}
export function drawSmm2Pipe(c,q,room={}){
 if(!validRect(q)||!visible(q)||!['pipe','pipe-side'].includes(q.material))return false;
 const direction=smm2PipeDirection(q,room);if(!direction)return false;const requested=room.smm2Mechanics?.version===1?room.semantics?.find(s=>s.id===(q.sourceId||q.id))?.source?.pipeArtSetting:null,artSetting=['Overworld','Underworld','Castle','Underwater'].includes(requested)?requested:room.setting||'';
 const semantic=room.semantics?.find(s=>s.id===(q.sourceId||q.id)),color=semantic?.source?.pipeColor,paletteMap=color==='yellow'?{'0,0,0':'#8c7318','128,208,16':'#ffb259','0,168,0':'#ba6111'}:sourceGroundProfile(room)?{'0,0,0':'#386800','128,208,16':'#b5de31','0,168,0':'#21ad10'}:{};
 c.save();c.imageSmoothingEnabled=false;c.beginPath();c.rect(q.x,q.y,q.w,q.h);c.clip();
 if(['left','right'].includes(direction)){
  c.translate(Math.round(q.x)+(direction==='right'?q.w:0),Math.round(q.y));if(direction==='right')c.scale(-1,1);
  const key=sourceKey('Solid','PipeHorizontal',artSetting);
  nativePixels(c,key,{x:0,y:0,w:16,h:32},{cropW:16,paletteMap});
  // The 39px source includes a rounded rear connector. Only its straight
  // inner shaft repeats; repeating the transparent rear corners opens notches.
  for(let x=16;x<q.w;x+=16)nativePixels(c,key,{x,y:0,w:16,h:32},{cropX:16,cropW:16,paletteMap});
 }else{
  c.translate(Math.round(q.x),Math.round(q.y)+(direction==='down'?q.h:0));if(direction==='down')c.scale(1,-1);
  const top=sourceKey('Solid','Pipe',artSetting,'top'),body=sourceKey('Solid','Pipe',artSetting,'middle');
  for(let x=0;x<q.w;x+=32){nativePixels(c,top,{x,y:0,w:32,h:16},{paletteMap});for(let y=16;y<q.h;y+=16)nativePixels(c,body,{x,y,w:32,h:16},{paletteMap});}
 }c.restore();return true;
}
export function drawSmm2BuzzyShell(c,q){
 if(!visible(q)||!validRect(q))return false;
 return nativePixels(c,'src|Character|ShellBeetle|Underworld|',q);
}

/** Explicit key-coin palette tint of the same native 10×14 coin topology.
 * Ordinary coins continue through the original renderer with original colors. */
export function drawSmm2PinkCoin(c,q){
 if(!visible(q)||!validRect(q))return false;
 const native=sourcePixels('src|Character|Coin||');
 const body={x:q.x+(q.w-native.w)/2,y:q.y+q.h-native.h,w:native.w,h:native.h};
 return sprite(c,body,native.w,native.h,p=>{
  for(let y=0;y<native.h;y++)for(let x=0;x<native.w;x++){
   const color=native.pixels[y*native.w+x];if(!color[3])continue;
   p(color[0]===0?P.pinkInk:color[0]===216?P.pinkDark:P.pink,x,y);
  }
 });
}

/** Progress slots represent collection count from left to right, not map IDs.
 * Reads the Stage's actual full-course view count; contains no local counter. */
export function drawSmm2PinkCoinHud(c,view,{x=0,y=0,spacing=12,hideCompleted=false}={}){
 const mechanics=view?.smm2Mechanics??view,progress=mechanics?.pinkCoins;
 if(mechanics?.version!==1||!progress||!Number.isInteger(progress.total)||progress.total<1||progress.total>128||!Number.isInteger(progress.taken)||progress.taken<0||progress.taken>progress.total||![x,y,spacing].every(Number.isFinite)||spacing<7)return false;
 if(hideCompleted&&progress.taken===progress.total&&progress.keyReleased===true)return true;
 const filled=['0011100','0111110','1111111','1111111','1111111','1111111','1111111','0111110','0011100'];
 const outline=['0011100','0100010','1000001','1000001','1000001','1000001','1000001','0100010','0011100'];
 c.save();
 for(let n=0;n<progress.total;n++){
  const pixel=(color,px,py,w=1,h=1)=>rect(c,color,Math.round(x+n*spacing)+px,Math.round(y)+py,w,h);
  const collected=n<progress.taken;mask(pixel,collected?filled:outline,0,0,collected?P.pink:P.pinkDark);
  if(collected){pixel(P.pinkDark,3,2,1,5);pixel(P.pinkInk,4,2,1,5);}
 }
 c.restore();return true;
}

const WING=['11000000','11100000','11110000','01111000','01111100','00111110','00111111','00011111','00011111','00001111','00000110','00000100'];
export function drawSmm2Wings(c,q,tick=0){
 if(!validRect(q)||!visible(q))return false;
 const frame=Number.isFinite(q.wingFrame)?q.wingFrame:Math.floor(tick/8)%2,dy=frame%2?-2:0;
 for(const side of [-1,1]){
  const x=side<0?q.x-8:q.x+q.w,y=q.y+q.h/2-8+dy;
  c.save();c.translate(Math.round(x)+(side>0?8:0),Math.round(y));if(side>0)c.scale(-1,1);
  const pixel=(color,px,py,w=1,h=1)=>rect(c,color,px,py,w,h);mask(pixel,WING,0,0,P.white);mask(pixel,['100000','010000','001000','000100','000010'],2,4,P.donutDark);c.restore();
 }
 return true;
}
export function drawSmm2Platform(c,q,tick=0){
 if(!visible(q)||!validRect(q))return false;
 const style=q.smm2Platform?.style??q.platformStyle;
 if(!['blue','orange','skull'].includes(style))return false;
 clipped(c,q,()=>{
  const dark=style==='blue'?P.blueDark:P.redDark,light=style==='blue'?P.blueLight:P.redLight;
  if(style==='skull'){
   for(let x=q.x;x<q.x+q.w;x+=16)sprite(c,{x,y:q.y,w:16,h:q.h},16,8,p=>{
    mask(p,['0011111111111100','0111111111111110','1111111111111111','1100011111100011','1100011111100011','0111111001111110','0011101111011100','0001101111011000'],0,0,P.white);
   });
  }else{
   rect(c,dark,q.x,q.y,q.w,2);rect(c,dark,q.x,q.y+q.h-2,q.w,2);rect(c,light,q.x,q.y,q.w,1);rect(c,light,q.x,q.y+q.h-2,q.w,1);
   // Truss openings remain transparent, with only diagonal physical frame art.
   for(let x=q.x+1;x<q.x+q.w-1;x++){
    const n=(Math.floor(x-q.x)-1)%12,height=Math.max(1,q.h-4),py=Math.round(Math.min(n,11-n)/5*height);
    rect(c,light,x,q.y+2+py,1,1);rect(c,light,x,q.y+q.h-3-py,1,1);
   }
  }
 });
 if(q.smm2Platform?.winged===true||q.winged===true)drawSmm2Wings(c,q,tick);
 return true;
}

/** Expects live axis-aligned rectangles, not an inferred timing/extension pose.
 * base is fixed. shaft is the current visible extension footprint including
 * spikes/tip. Retracted state provides a zero-width/height shaft or omits it. */
export function drawSmm2Skewer(c,q){
 const s=q.smm2Skewer||q,base=s.base,shaft=s.shaft,direction=s.direction;
 if(!visible(q)||!validRect(base)||!['down','up','left','right'].includes(direction))return false;
 const horizontal=direction==='left'||direction==='right';
 if(validRect(shaft))sprite(c,shaft,horizontal?Math.max(16,Math.round(shaft.w)):24,horizontal?24:Math.max(16,Math.round(shaft.h)),p=>{
  const w=horizontal?Math.max(16,Math.round(shaft.w)):24,h=horizontal?24:Math.max(16,Math.round(shaft.h));
  p(P.skewerDark,3,3,w-6,h-6);p(P.skewerLight,4,4,w-8,h-8);p(P.skewer,5,5,w-10,h-10);
  for(let x=6;x<w-5;x+=12)for(const y of [0,h-3]){p(P.skewerDark,x-2,y+2,5);p(P.skewerLight,x-1,y+1,3);p(P.white,x,y);}
  for(let y=6;y<h-5;y+=12)for(const x of [0,w-3]){p(P.skewerDark,x+2,y-2,1,5);p(P.skewerLight,x+1,y-1,1,3);p(P.white,x,y);}
  for(let y=9;y<h-6;y+=12)for(let x=9;x<w-6;x+=12){mask(p,['00100','01110','11111','01110','00100'],x-2,y-2,P.skewerLight);p(P.white,x,y);}
 });
 sprite(c,base,Math.max(8,Math.round(base.w)),Math.max(8,Math.round(base.h)),p=>{
  const w=Math.max(8,Math.round(base.w)),h=Math.max(8,Math.round(base.h));p(P.skewerDark,0,0,w,h);p(P.skewerLight,1,1,w-2,h-2);p(P.skewer,3,3,w-6,h-6);
  for(let y=4;y<h-2;y+=8)for(let x=4;x<w-2;x+=8){p(P.stoneMid,x,y,2,2);p(P.skewerLight,x+1,y+1);}
 });
 return true;
}

/** Static editor objects keep their native ABI. A same-ID sidecar leaf can
 * supply a temporary appearance descriptor, never a controller or actor edit. */
function authoredSmm2Descriptor(actor,room){
 if(!['walker','hazard'].includes(actor.kind)||['smm2Thwomp','smm2Pow','smm2Helmet','smm2PlacedItem','smm2Skewer'].some(k=>actor[k]))return null;
 const leaves=room.smm2Mechanics,find=key=>Array.isArray(leaves[key])?leaves[key].find(q=>q.id===actor.id):null;
 if(actor.kind==='walker'){
  const boneShell=find('boneShells');if(boneShell)return {...actor,type:'smm2-shoe',smm2Shoe:{...boneShell,kind:'bone-shell',occupancy:'empty'}};
  const shoe=find('shoes');if(shoe)return {...actor,facing:actor.facing??room.semantics?.find(q=>q.id===actor.id)?.source?.direction,type:'smm2-shoe',smm2Shoe:{...shoe,occupancy:shoe.occupant==='goomba'?'npc':'empty'}};
  const variant=room.marioModules?.enemyVariants?.[actor.id];
  if(variant?.kind==='dry-bones')return {...actor,type:'dry-bones',smm2DryBones:{phase:'walking',size:variant.size}};
  if(variant?.kind==='muncher')return {...actor,type:'muncher',smm2EnemyKind:'muncher'};
  if(shoePalette(room)&&['floor-piranha','fire-piranha'].includes(variant?.kind))return {...actor,type:'study-piranha',source:{...actor.source,studyFloorPlant:true,giant:variant.size==='giant',winged:variant.winged}};
  const thwomp=find('thwomps');
  if(thwomp)return {...actor,type:'smm2-thwomp',winged:thwomp.winged===true,smm2Thwomp:{phase:'idle',direction:thwomp.direction}};
  if(find('powBlocks'))return {...actor,kind:'pow',type:'smm2-pow',smm2Pow:{phase:'live'}};
  const pSwitch=find('pSwitches');if(pSwitch)return {...actor,kind:'p-switch',type:'smm2-p-switch',smm2PSwitch:{phase:'live',orientation:pSwitch.orientation}};
  if(find('helmets'))return {...actor,kind:'buzzy-shellmet',type:'smm2-buzzy-shell',smm2Helmet:{phase:'loose'}};
  const placed=find('placedItems');if(['life','mushroom','star'].includes(placed?.kind))return {...actor,kind:placed.kind};
 }else{
  const skewer=find('skewers');
  if(skewer)return {...actor,type:'smm2-skewer',smm2Skewer:{direction:skewer.direction,phase:'unloaded',loaded:false,extension:0,base:{x:actor.x,y:actor.y,w:actor.w,h:actor.h}}};
 }
 return null;
}

/** Only declared live components are dispatched; unknown native actors pass. */
export function drawSmm2Actor(c,actor,tick=0,room={}){
 if(!enabled(room)||!actor)return false;
 if(drawBowserJr(c,actor,tick,room))return true;
 if(drawSmm2GhostActor(c,actor,tick,room))return true;
 if(drawSmb3Actor(c,actor,tick,room))return true;
 // Recognized effects consume dispatch even while hidden or expired, so they
 // cannot fall through to a generic native enemy or spawn illustration.
 if(actor.kind==='enemy-death'&&actor.type==='smm2-thwomp'&&actor.smm2Thwomp){drawSmm2ThwompDeath(c,actor,tick);return true;}
 if(actor.kind==='enemy-death'&&shoePalette(room)&&(actor.type==='muncher'||actor.smm2EnemyKind==='muncher'||actor.type==='study-piranha')){
  if(actor.hidden||actor.visible===false||actor.removed||actor.life<=0)return true;
  c.save();c.translate(0,2*actor.y+actor.h);c.scale(1,-1);drawSmm2Actor(c,{...actor,kind:'walker',dead:false},tick,room);c.restore();return true;
 }
 if(actor.kind==='pow-effect'){drawSmm2PowEffect(c,actor);return true;}
 const powActor=actor.type==='smm2-pow'||['pow','smm2-pow'].includes(actor.kind)||!!actor.smm2Pow;
 if(actor.type==='smm2-p-switch'||actor.smm2PSwitch)return drawSmm2PSwitch(c,actor);
 if(powActor&&['spent','removed'].includes(actor.smm2Pow?.phase))return true;
 if(actor.type==='smm2-shoe'||actor.smm2Shoe){
  const state=actor.smm2Shoe??actor;
  if(!visible(actor)||['player','removed','carried'].includes(state.occupancy))return true;
  if(state.kind==='bone-shell')return drawSmm2BoneShell(c,actor,{tick});
  return drawSmm2Shoe(c,actor,{tick});
 }
 if(actor.type==='dry-bones'){drawSmm2DryBones(c,actor,{tick});return true;}
 if(!visible(actor))return false;
 if(sourceGroundProfile(room)&&actor.emptyShell===true)return nativePixels(c,'src|Character|ShellBeetle|Underworld|',actor,{paletteMap:{'24,60,92':'#165966','0,128,136':'#ffb259','156,252,240':'#ffffff'}});
 if(palette(room)&&actor.type==='podoboo'){return drawSmm2SourcePixels(c,'lavaBubble',{x:actor.x+(actor.w-14)/2,y:actor.y+actor.h-16});}
 if(actor.type==='muncher'||actor.type==='study-muncher'||actor.smm2EnemyKind==='muncher')return drawSmm2Muncher(c,actor,tick);
 if(shoePalette(room)&&actor.kind==='hazard'&&room.contraptions?.spikeTraps?.some(q=>q.id===(actor.sourceId||actor.id)))return drawSmm2ShoeSpike(c,actor);
 if(shoePalette(room)&&(actor.type==='study-piranha'||actor.type==='study-giant-winged-piranha'||actor.source?.studyFloorPlant)){
  const frame=actor.source?.frame|| (Math.floor(tick/12)%2?'two':''),key=sourceKey('Character','Piranha',[room.setting||'',frame].join(' ').trim());
  const drawn=nativePixels(c,key,actor);if(drawn&&actor.source?.winged===true)drawSmm2Wings(c,actor,tick);return drawn;
 }
 if(shoePalette(room)&&actor.smm2EnemyKind==='fire-piranha-shot')return nativePixels(c,sourceKey('Character','BowserFire',room.setting||''),actor);
 if(actor.kind==='coin'&&room.smm2Mechanics.pinkCoins?.some(q=>q.id===actor.id))return drawSmm2PinkCoin(c,actor);
 if(actor.type==='smm2-thwomp'&&actor.smm2Thwomp){
  const drawn=drawSmm2Thwomp(c,actor);
  if(drawn&&actor.winged===true)drawSmm2Wings(c,actor,tick);
  return drawn;
 }
 if(powActor)return drawSmm2Pow(c,actor);
 if(actor.type==='smm2-buzzy-shell'||['buzzy-shellmet','smm2-buzzy-shell'].includes(actor.kind))return drawSmm2BuzzyShell(c,actor);
 if(actor.type==='smm2-skewer'&&actor.smm2Skewer)return drawSmm2Skewer(c,actor);
 if(actor.type==='smm2-platform'||actor.smm2Platform||actor.platformStyle)return drawSmm2Platform(c,actor,tick);
 const authored=authoredSmm2Descriptor(actor,room);
 if(authored?.smm2PSwitch)return drawSmm2PSwitch(c,authored);
 if(['life','mushroom','star'].includes(authored?.kind)){
  if(drawSmb3Actor(c,authored,tick,room))return true;
  const key=authored.kind==='life'?'src|Character|Mushroom1Up||':authored.kind==='mushroom'?'src|Character|Mushroom||':'src|Character|Star||',native=sourcePixels(key);
  return nativePixels(c,key,{x:actor.x+(actor.w-native.w)/2,y:actor.y+actor.h-native.h,w:native.w,h:native.h});
 }
 if(authored)return drawSmm2Actor(c,authored,tick,room);
 return false;
}

/** Stationary typed black plant, authored on the native sixteen-pixel grid.
 * A fire plant continues through the original Piranha body above. */
export function drawSmm2Muncher(c,actor,tick=0){
 if(!visible(actor)||!validRect(actor))return false;
 return sprite(c,actor,16,16,p=>{
  const open=Math.floor(tick/12)%2===0;
  mask(p,open?['0001100000011000','0011110000111100','0111111001111110','0111111111111110','1111111111111111','1111111111111111','0111111111111110','0011111111111100']:['0000111111110000','0011111111111100','0111111111111110','1111111111111111','1111111111111111','0111111111111110','0011111111111100','0001111111111000'],0,0,'#101719');
  p('#6c9092',3,3,2,1);p('#6c9092',11,3,2,1);p('#6c9092',4,6,8,1);
  p('#263e40',7,8,2,7);mask(p,['100000000001','111000000111','011110011110','001111111100','000111111000'],2,10,'#101719');p('#6c9092',4,12,2,1);p('#6c9092',10,12,2,1);
 });
}

export function drawSmm2ShoeSpike(c,actor){
 if(!visible(actor)||!validRect(actor))return false;
 return sprite(c,actor,16,16,p=>{
  mask(p,['0000000110000000','0000001111000000','0110001111000110','0111111111111110','0011111111111100','0001111111111000','0011111111111100','1111111111111111','1111111111111111','0011111111111100','0001111111111000','0011111111111100','0111111111111110','0110001111000110','0000001111000000','0000000110000000'],0,0,S.tealLight);
  mask(p,['000001100000','000011110000','010011110010','011111111110','001110011100','111100001111','111100001111','001110011100','011111111110','010011110010','000011110000','000001100000'],2,2,S.snow);
  p(S.tealDark,6,6,4,4);p(S.teal,7,7,2,2);
 });
}

/** Only declared source-arrow markers are signs, with no coordinate labels. */
export function drawSmm2SourceArrow(c,marker,room={}){
 if(drawSmwUnderwaterReference(c,marker,room))return true;
 if(marker?.kind!=='source-arrow'||!visible(marker)||!finitePoint(marker))return false;
 const placement=room.semantics?.find(q=>q.id===marker.id)?.source?.bottom_origin;
 const w=Number.isFinite(marker.w)?marker.w:Number.isFinite(placement?.w)?placement.w*16:32;
 const h=Number.isFinite(marker.h)?marker.h:Number.isFinite(placement?.h)?placement.h*16:32;
 if(w<=0||h<=0||w>96||h>96)return false;
 if(marker.source?.signArt==='smb1-large-wood'){
  c.save();
  if(marker.source?.facing==='left'){c.translate(2*Math.round(marker.x)+Math.round(w),0);c.scale(-1,1);}
  const drawn=sprite(c,{x:marker.x,y:marker.y,w,h},40,48,p=>{
  // Shared configurable wooden sign: measured board proportions and a post
  // with its own ground anchor, rather than stretching the small sign glyph.
  p('#a96939',13,6,7,42);p('#e5a269',14,7,5,41);p('#ffdfa8',15,7,2,41);p('#a96939',18,8,1,40);
  for(let y=5;y<27;y++){const right=y<=16?28+(y-5):39-(y-16);if(y>=12&&y<=22)p('#a96939',0,y,right,1);else p('#a96939',28,y,Math.max(1,right-28),1);if(y>=13&&y<=21)p('#e5a269',1,y,Math.max(0,right-2),1);else p('#e5a269',29,y,Math.max(0,right-30),1);}
  p('#ffdfa8',1,13,28,1);p('#ffdfa8',1,19,29,1);p('#ffdfa8',1,21,26,1);p('#a96939',14,15,2,4);p('#ffdfa8',14,16,1,2);p('#a96939',4,16,7,1);p('#a96939',21,17,8,1);
  });
  c.restore();return drawn;
 }
 c.save();
 if(marker.source?.facing==='left'){c.translate(Math.round(marker.x)+Math.round(w),0);c.scale(-1,1);}else c.translate(Math.round(marker.x),0);
 const boardOnly=marker.source?.signArt==='smb1-board-only';
 const drawn=sprite(c,{x:0,y:marker.y,w,h},24,boardOnly?16:24,p=>{
  const dark=snowPalette(room)?S.snowDark:'#a96939',gold=snowPalette(room)?S.ice:'#e5a269',light=snowPalette(room)?S.snow:'#ffdfa8';
  if(!boardOnly){p(dark,5,12,4,12);p(light,6,12,2,12);p(gold,8,13,1,11);}
  for(let y=3;y<=13;y++){
   const head=y<=8?14+(y-3):19-(y-8);
   if(y>=5&&y<=11)p(dark,1,y,head,1);else p(dark,14,y,Math.max(1,head-13),1);
   if(y>=6&&y<=10)p(light,2,y,Math.max(1,head-2),1);else p(light,15,y,Math.max(1,head-15),1);
  }
  p(gold,2,10,12,1);p(gold,13,7,2,3);
 });
 // A ground sign can bridge a short placement gap of at most one 16px tile.
 // The rule uses actual support geometry and applies equally after duplication.
 const postX=marker.x+w*7/24,postBottom=marker.y+h,support=(room.playGeometry||room.map?.geometry||[]).filter(q=>!q.hidden&&q.collision==='solid'&&q.x<=postX&&q.x+q.w>postX&&q.y>=postBottom&&q.y-postBottom<=16).sort((a,b)=>a.y-b.y)[0];
 if(support&&!boardOnly){const dark=snowPalette(room)?S.snowDark:'#a96939',gold=snowPalette(room)?S.ice:'#e5a269',light=snowPalette(room)?S.snow:'#ffdfa8',left=Math.round(w*5/24),width=Math.round(w*9/24)-left,top=Math.round(postBottom),height=Math.max(0,Math.round(support.y)-top);c.fillStyle=dark;c.fillRect(left,top,width,height);c.fillStyle=light;c.fillRect(Math.round(w*6/24),top,Math.max(1,Math.round(w*2/24)),height);c.fillStyle=gold;c.fillRect(Math.round(w*8/24),top,Math.max(1,Math.round(w/24)),height);}
 c.restore();return drawn;
}

export function drawSmm2World(c,room={},view,tick=0){
 drawCompletionMarks(c,room);
 drawSkyShooter(c,room,tick);
 if(isSmb3ArtRoom(room)){
  let handled=drawSmb3World(c,room,view,tick);
  for(const q of room.markers||[])if(q.kind==='source-arrow'&&!view?.hiddenMarkers?.includes(q.id))handled=drawSmm2SourceArrow(c,q,room)||handled;
  return handled;
 }
 const hiddenMarkers=view?.hiddenMarkers??[];
 view=view?.smm2Mechanics??view;
 if(!enabled(room)||view?.version!==1)return false;
 let count=0;
 for(const q of view.surfaces||[])if(q.kind==='slope'&&q.spec)count+=Number(drawSmm2Slope(c,q,room));
 for(const q of view.donuts||[])count+=Number(drawSmm2Donut(c,q,tick));
 for(const q of view.seesaws||[])count+=Number(drawSmm2Seesaw(c,q));
 for(const q of view.shoes?.blasts||[])count+=Number(drawSmm2ShoeBlast(c,q,{tick}));
 for(const q of room.markers||[])if(q.kind==='source-arrow'&&!hiddenMarkers.includes(q.id))count+=Number(drawSmm2SourceArrow(c,q,room));
 return count>0;
}

/** Footwear underlay uses the real controller foot rectangle. Native Mario
 * is drawn once by editor-art at his seated position. */
export function smm2PlayerFootwear(p,room={}){
 if(!enabled(room)||!visible(p)||p.dying)return null;
 const q=p.smm2Shoe??p.smm2Gear?.shoe;
 return validRect(q)&&q.occupancy==='player'&&!q.dead&&!q.removed?q:null;
}
export function drawSmm2PlayerFootwear(c,p,tick=0,room={}){
 const q=smm2PlayerFootwear(p,room);if(!q)return false;
 if((q.smm2Shoe??q).kind==='bone-shell')return drawSmm2BoneShell(c,q,{tick});
 return drawSmm2Shoe(c,q,{tick,facing:p.facing});
}

/** Overlay the existing Mario sprite. No Mario replacement or motor changes. */
/** Anchor an accessory to the displayed sprite head; this never moves its body. */
export function smm2PlayerGearRect(p,{headX,headY,scale=1}={}){
 const large=!!p.power,spriteHeight=large?(p.crouch?22:32):16;
 return {x:Math.round(Number.isFinite(headX)?headX:p.x+(p.w-16)/2),y:Math.round((Number.isFinite(headY)?headY:p.y+p.h-spriteHeight)-3*scale),w:16*scale,h:12*scale};
}
export function drawSmm2PlayerGear(c,p,tick=0,room={},displayHead={}){
 if(!enabled(room)||!visible(p)||!validRect(p)||p.dying||(p.helmet??p.smm2Gear?.helmet)!=='buzzy')return false;
 if(!p.shrink&&!p.growth&&!p.fireGrowth&&p.invulnerable&&Math.floor(tick/4)%2)return false;
 // Preserve the existing crown-to-head offset and native blue-shell pixels.
 return nativePixels(c,'src|Character|ShellBeetle|Underworld|',smm2PlayerGearRect(p,displayHead),{cropY:0,cropH:12});
}
