/** Opt-in slime/honey contact adapter; the Mario motor remains unchanged.
 * Slime returns 2/3 of measured fall height (Minecraft's published 6 -> 4 example).
 * Native terminal speed is retained, so apex-to-contact distance preserves the
 * lost fall energy. Rebound is ballistic at 7/16 px/tick² with no held-jump boost.
 * Honey uses the motor's existing carryMotion contract: 40% walk/run speed,
 * 40% ordinary jump impulse, and 0.7 px/tick downward wall slide. These are
 * authored 2D adaptations, not a claim of exact Java/Bedrock physics parity. */
export const GROTTO_TUNING=Object.freeze({reboundRatio:2/3,reboundGravity:.4375,maxReboundHeight:160,minBounceHeight:3,honeySpeedRatio:.4,honeyJumpRatio:.4,honeySlideSpeed:.7});
const copy=v=>JSON.parse(JSON.stringify(v));
const solid=q=>q.collision==='solid'&&!q.hidden;
const across=(p,q)=>p.x+p.w>q.x+.01&&p.x<q.x+q.w-.01;
const unsafe=id=>['__proto__','constructor','prototype'].includes(id);
export function validateGrotto(spec,room){
 if(!spec||typeof spec!=='object'||Array.isArray(spec)||Object.keys(spec).some(k=>!['version','slimeIds','honeyIds','geode'].includes(k))||spec.version!==1)throw Error('Invalid Minecraft grotto');
 const used=new Set();
 const own=id=>{const q=room.map.geometry.find(g=>g.id===id);if(typeof id!=='string'||unsafe(id)||used.has(id)||!q||!solid(q)||q.motion||q.liftSpeed||q.material==='spring')throw Error('Minecraft grotto needs unique static non-spring solids');used.add(id);return q;};
 for(const key of ['slimeIds','honeyIds']){if(!Array.isArray(spec[key])||!spec[key].length||spec[key].length>32)throw Error('Invalid Minecraft grotto '+key);for(const id of spec[key]){const q=own(id);if(q.w%16||q.h%16||!room.map.geometry.some(g=>g!==q&&solid(g)&&across(q,g)&&Math.abs(g.y-q.y-q.h)<.01))throw Error('Minecraft grotto blocks must be grounded on real solid supports');}}
 if(spec.geode){const q=spec.geode;if(Object.keys(q).some(k=>!['id','coins'].includes(k))||!Number.isInteger(q.coins)||q.coins<1||q.coins>10)throw Error('Invalid Minecraft grotto geode');own(q.id);}
}
export function createGrottoController(room,{emit=()=>{},rewardCoins=()=>{},restoreHealth=()=>{},grantHealthUpgrade=()=>false}={}){
 const spec=room.minecraft?.grotto;if(!spec)return null;validateGrotto(spec,room);
 const slime=new Set(spec.slimeIds),honey=new Set(spec.honeyIds),T=GROTTO_TUNING;
 let apex=null,rebounding=false,restoreGravity=null,before=null,lastHoney=null,tick=0,paused=false,state;
 const event=(name,data={})=>emit('minecraft',{event:name,roomId:room.roomId,tick,...data});
 const sound=name=>emit('sound',{event:name});
 function reset(){apex=null;rebounding=false;restoreGravity=null;before=null;lastHoney=null;state={bounceCount:0,suppressedCount:0,honeyTicks:0,slidingTicks:0,geodeUsed:false,reward:null,geodePulse:0,slimePulse:0,lastBounce:null,honeyContact:null};}
 reset();
 function restore(p){if(restoreGravity){p.jumpG=restoreGravity.jumpG;p.fallG=restoreGravity.fallG;restoreGravity=null;}rebounding=false;}
 function leave(p){if(p)restore(p);else{restoreGravity=null;rebounding=false;}apex=null;before=null;lastHoney=null;state.honeyContact=null;}
 function beforePlayer(p,input,geometry,now){
  if(paused)return null;if(!p||p.dead||p.dying){leave(p);return null;}tick=now;state.geodePulse=Math.max(0,state.geodePulse-1);state.slimePulse=Math.max(0,state.slimePulse-1);
  if(p.grounded){if(rebounding)restore(p);apex=p.y+p.h;}else apex=Math.min(apex??p.y+p.h,p.y+p.h);
  before={...p};
  const support=p.grounded&&geometry.find(q=>honey.has(q.id)&&across(p,q)&&Math.abs(p.y+p.h-q.y)<1.1);
  const wall=!p.grounded&&p.vy>=0&&geometry.find(q=>honey.has(q.id)&&p.y+p.h>q.y+3&&p.y<q.y+q.h-1&&(Math.abs(p.x+p.w-q.x)<1.1||Math.abs(p.x-q.x-q.w)<1.1));
  const contact=support?.id||wall?.id||null;state.honeyContact=contact;
  if(contact&&contact!==lastHoney){sound('mc-honey-stick');event('honey-contact',{actorId:contact,kind:support?'ground':'side'});}lastHoney=contact;
  if(wall){p.vy=Math.min(p.vy,T.honeySlideSpeed-(p.fallG||.4375));state.slidingTicks++;apex=p.y+p.h;}
  if(support){state.honeyTicks++;p.vx=Math.max(-(input.run?1:.6),Math.min(input.run?1:.6,p.vx));return {carryMotion:{walkCap:.6,runCap:1,airCap:1.5,jumpSpeed:4.1333333*T.honeyJumpRatio,jumpGravity:.125,fallGravity:.4375}};}
  return null;
 }
 function afterPlayer(p,input,geometry){
  if(paused||!before||!p||p.dead||p.dying)return;
  const q=p.grounded&&geometry.find(q=>q.id===p.support&&slime.has(q.id));
  if(q&&!before.grounded&&before.vy>=0){
   const fallHeight=Math.max(0,q.y-(apex??before.y+before.h)),impactVelocity=Math.max(0,Math.min(4.25,before.vy+(before.fallG||.4375))),height=Math.min(T.maxReboundHeight,fallHeight*T.reboundRatio);
   if(input.down){state.suppressedCount++;state.slimePulse=8;sound('mc-slime-suppress');event('slime-suppressed',{actorId:q.id,fallHeight,impactVelocity});restore(p);apex=q.y;}
   else if(height>=T.minBounceHeight&&impactVelocity>.8){restore(p);restoreGravity={jumpG:p.jumpG,fallG:p.fallG};p.jumpG=p.fallG=T.reboundGravity;p.vy=-(Math.sqrt(2*T.reboundGravity*height)+T.reboundGravity/2);p.grounded=false;p.support=null;p.jumpBuffer=0;rebounding=true;apex=q.y;state.bounceCount++;state.slimePulse=18;state.lastBounce={actorId:q.id,fallHeight,impactVelocity,height,launchSpeed:-p.vy};sound('mc-slime-bounce');event('slime-bounced',state.lastBounce);}
  }else if(rebounding&&(p.grounded||p.headHit))restore(p);
  if(spec.geode&&!state.geodeUsed&&p.headHit===spec.geode.id){state.geodeUsed=true;state.geodePulse=70;const bud=geometry.find(q=>q.id===spec.geode.id);state.reward={x:bud.x+bud.w-6,y:bud.y+bud.h,w:10,h:12,vx:.55,vy:.4,state:'falling',age:0};sound('mc-amethyst-chime');event('amethyst-discovered',{actorId:spec.geode.id,coins:0,rewardPending:true});}
  const item=state.reward;if(item){item.age++;if(item.state==='falling'){const oldBottom=item.y+item.h;item.vy=Math.min(3,item.vy+.16);const nextX=item.x+item.vx;if(!geometry.some(q=>solid(q)&&nextX+item.w>q.x&&nextX<q.x+q.w&&item.y+item.h>q.y&&item.y<q.y+q.h))item.x=nextX;else item.vx=0;const floor=geometry.filter(q=>solid(q)&&across(item,q)&&q.y>=oldBottom-.01&&q.y<=oldBottom+item.vy+.01).sort((a,b)=>a.y-b.y)[0];if(floor){item.y=floor.y-item.h;item.vy=item.vx=0;item.state='settled';event('amethyst-reward-settled',{x:item.x,y:item.y,supportId:floor.id});}else item.y+=item.vy;}if(item.state!=='collected'&&item.age>=18&&p.x+p.w>item.x&&p.x<item.x+item.w&&p.y+p.h>item.y&&p.y<item.y+item.h&&!geometry.some(q=>solid(q)&&item.x+item.w>q.x&&item.x<q.x+q.w&&item.y+item.h>q.y&&item.y<q.y+q.h)){item.state='collected';item.age=0;rewardCoins(spec.geode.coins);const capacity=grantHealthUpgrade(room.roomId+':geode');const healed=Number(restoreHealth(1))||0;state.geodePulse=45;sound('mc-pickup');sound('mc-amethyst-chime');event('amethyst-reward-collected',{coins:spec.geode.coins,healed,capacity,x:item.x,y:item.y});}}
  before=null;
 }
 return {beforePlayer,afterPlayer,reset,leave,pause(value=true){paused=!!value;before=null;},view:()=>copy(state)};
}
