/** The existing native preview's camera, shared by play and input-video renderers.
 * This is a refactor of the preview calculation, not a claim of SMM2 calibration.
 */
export function nativeCamera(view){
 const width=view.viewportWidth||256,height=view.viewportHeight||240;
 const frame=view.smm2Mechanics?.camera;
 const y=frame?Math.max(frame.minY,Math.min(frame.baseY,view.p.y-frame.riseTop)):Math.max(0,Math.min(Math.max(0,view.height-height),view.p.y-100));
 return {x:view.cam,y,width,height};
}

/** Presentation only: smooth a seat/growth alignment without changing the
 * camera used by enemy activation, collision or the recorded native state.
 * A repeated render of one simulation tick does not advance this tracker. */
export function createNativeCameraTracker(){
 let prior=null;
 return {reset(){prior=null;},sample(view){
  const target=nativeCamera(view),enabled=view.smm2Mechanics?.version===1||view.aquatic?.version===1;
  const changed=prior&&(prior.roomId!==view.roomId||prior.dying&&!view.p.dying||view.tick<prior.tick||prior.width!==target.width||prior.height!==target.height);
  let x=target.x,y=target.y,fadeStart=prior?.fadeStart??null;
  if(enabled&&prior&&!changed){
   const dt=Math.max(0,view.tick-prior.tick),limitX=Math.max(3,Math.abs(view.p.vx||0))*dt,limitY=Math.max(4.25,Math.abs(view.p.vy||0))*dt;
   if(Math.abs(target.x-prior.x)<=target.width){x=prior.x+Math.max(-limitX,Math.min(limitX,target.x-prior.x));y=prior.y+Math.max(-limitY,Math.min(limitY,target.y-prior.y));}
   else fadeStart=view.tick; // actual respawn/warp, never pan through unrelated terrain
  }
  if(enabled&&changed)fadeStart=view.tick;
  let fade=0;
  const q=view.transition;
  if(enabled&&q){
   if(q.door)fade=Math.max(0,Math.min(1,q.age/19));
   else if(q.phase==='enter'){const end=q.side?40:56;fade=Math.max(0,Math.min(1,(q.age-(end-12))/11));}
   else if(q.phase==='exit')fade=Math.max(0,Math.min(1,1-(q.age-12)/12));
  }
  if(enabled&&fadeStart!==null){fade=Math.max(fade,Math.max(0,1-(view.tick-fadeStart)/12));if(view.tick-fadeStart>=12)fadeStart=null;}
  prior={x,y,width:target.width,height:target.height,tick:view.tick,roomId:view.roomId,dying:!!view.p.dying,fadeStart};
  return {...target,x,y,fade};
 }};
}

/** Used by both interactive play and native-input video after their HUD pass. */
export function drawNativeRoomFade(c,camera,width,height){
 if(!(camera?.fade>0))return false;c.save();c.fillStyle=`rgba(0,0,0,${Math.min(1,camera.fade)})`;c.fillRect(0,0,width,height);c.restore();return true;
}
