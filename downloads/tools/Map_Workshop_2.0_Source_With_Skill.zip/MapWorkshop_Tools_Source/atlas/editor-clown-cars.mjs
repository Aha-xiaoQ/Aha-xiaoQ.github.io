/** Original, opt-in normal Clown Car approximation. Positions are world pixels.
 * This controller owns vehicle motion and seating, never combat or rewards. */
export const CLOWN_CAR_VERSION = 1;
// These are local approximation parameters, not calibrated Nintendo timings.
export const NPC_SPIKE_PANIC_DEFAULTS = Object.freeze({acceleration:.125,maxSpeed:2.75,durationFrames:90,horizontalDrag:.1});
const EPS = .001;
const defaults = Object.freeze({w:32,h:28,bobPixels:2,bobPeriodFrames:120,npcAcceleration:.035,npcMaxSpeed:1.05,playerAcceleration:.065,playerMaxSpeed:2.25,drag:.055,occupantOffsetY:-12,boardingTolerance:4});
const fields = ['id','x','y',...Object.keys(defaults),'npcSpikePanic'];
const finite = (n,lo,hi) => Number.isFinite(n)&&n>=lo&&n<=hi;
const clamp = (n,lo,hi) => Math.max(lo,Math.min(hi,n));
const approach = (v,target,amount) => v+clamp(target-v,-amount,amount);
const clone = value => JSON.parse(JSON.stringify(value));
const live = actor => !!actor&&!actor.dead&&!actor.dying;
const passengerBody = (car,actor) => ({x:car.x+(car.w-actor.w)/2,y:car.y+car.occupantOffsetY,w:actor.w,h:actor.h});
const bodyOf = car => ({x:car.x,y:car.y,w:car.w,h:car.h});
const union = boxes => {const x=Math.min(...boxes.map(q=>q.x)),y=Math.min(...boxes.map(q=>q.y));return {x,y,w:Math.max(...boxes.map(q=>q.x+q.w))-x,h:Math.max(...boxes.map(q=>q.y+q.h))-y};};

export function validateClownCars(room,spec=room?.contraptions){
 if(spec===undefined)return;
 if(!spec||typeof spec!=='object'||Array.isArray(spec))throw Error('Invalid contraptions');
 if(spec.cars===undefined)return;
 if(!Array.isArray(spec.cars)||spec.cars.length>1024)throw Error('Invalid Clown Car list');
 const map=room?.map;if(!map||!finite(map.width,32,100000)||!finite(map.height,28,100000))throw Error('Clown Cars need a bounded room');
 const ids=new Set([...(map.geometry||[]),...(map.objects||[]),...['tracks','claws','notes','oneWayWalls','pSources'].flatMap(k=>Array.isArray(spec[k])?spec[k]:[])].map(q=>q.id));
 for(const authored of spec.cars){
  if(!authored||typeof authored!=='object'||Array.isArray(authored)||Object.keys(authored).some(k=>!fields.includes(k)))throw Error('Unknown Clown Car field');
  if(typeof authored.id!=='string'||!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(authored.id)||authored.id.length>72||ids.has(authored.id))throw Error('Duplicate or invalid Clown Car ID');ids.add(authored.id);
  const q={...defaults,...authored};
  if(!finite(q.w,16,64)||!finite(q.h,16,64)||!finite(q.x,0,map.width-q.w)||!finite(q.y,0,map.height-q.h))throw Error('Clown Car is outside the room');
  if(!finite(q.bobPixels,0,8)||!Number.isInteger(q.bobPeriodFrames)||!finite(q.bobPeriodFrames,16,1800)||!finite(q.npcAcceleration,.001,1)||!finite(q.npcMaxSpeed,.01,8)||!finite(q.playerAcceleration,.001,1)||!finite(q.playerMaxSpeed,.01,8)||!finite(q.drag,0,1)||!finite(q.occupantOffsetY,-q.h,0)||!finite(q.boardingTolerance,0,8))throw Error('Invalid Clown Car tuning');
  if(q.npcSpikePanic!==undefined){
   const panic=q.npcSpikePanic;
   if(!panic||typeof panic!=='object'||Array.isArray(panic)||Object.keys(panic).some(k=>!Object.hasOwn(NPC_SPIKE_PANIC_DEFAULTS,k)))throw Error('Invalid NPC spike panic options');
   const p={...NPC_SPIKE_PANIC_DEFAULTS,...panic};
   if(!finite(p.acceleration,.001,2)||!finite(p.maxSpeed,.01,8)||!Number.isInteger(p.durationFrames)||!finite(p.durationFrames,1,3600)||!finite(p.horizontalDrag,0,1))throw Error('Invalid NPC spike panic tuning');
  }
 }
}

export function createClownCars(room,{emit=()=>{}}={}){
 validateClownCars(room);
 if(!room?.contraptions?.cars?.length)return null;
 const authored=room.contraptions.cars.map(q=>({...defaults,...clone(q),...(q.npcSpikePanic===undefined?{}:{npcSpikePanic:{...NPC_SPIKE_PANIC_DEFAULTS,...clone(q.npcSpikePanic)}})}));
 const width=room.map.width,height=room.map.height;
 let cars=[],poses=new Map(),lastTick=null,clock=0,context={player:null,enemies:[],geometry:[],oneWayWalls:[]};
 const pose=actor=>({x:actor.x,y:actor.y,w:actor.w,h:actor.h,vx:actor.vx||0,vy:actor.vy||0});
 const key=actor=>actor===context.player?'player':actor?.id||actor;
 const boxes=car=>[bodyOf(car),...(car.occupant?[passengerBody(car,car.occupant)]:[])];
 const isOwned=actor=>cars.some(car=>car.occupant===actor&&live(actor));
 function diagnostic(event,car,actor,extra={}){emit('clown-car',{event,roomId:room.roomId,carId:car.id,actorId:actor===context.player?'player':actor?.id??null,occupancy:car.occupancy,x:car.x,y:car.y,body:bodyOf(car),...(actor?{actor:pose(actor)}:{}),...extra});}
 function seat(car){
  const actor=car.occupant;if(!actor)return;
  const position=passengerBody(car,actor);Object.assign(actor,{x:position.x,y:position.y,vx:car.vx,vy:car.vy,grounded:false,support:null,clownCarId:car.id,vehicleId:car.id});
  if(car.occupancy==='player'){actor.crouch=false;actor.jumpBuffer=0;actor.onVine=false;actor.springId=null;actor.airCap=Math.abs(car.vx)>1.5?2.5:1.5;if(car.vx)actor.facing=Math.sign(car.vx);actor.anim=(actor.anim||0)+Math.abs(car.vx);}
 }
 function vacate(car,event='vacancy',reason='occupant-left'){
  const actor=car.occupant;if(!actor)return;
  stopPanic(car,'vacancy');
  if(actor.clownCarId===car.id)delete actor.clownCarId;
  if(actor.vehicleId===car.id)delete actor.vehicleId;
  car.occupant=null;car.occupancy='empty';car.hoverX=car.x;car.hoverY=car.y;car.hoverClock=0;
  diagnostic(event,car,actor,{reason});
 }
 function adopt(car,actor,occupancy){car.occupant=actor;car.occupancy=occupancy;car.hoverClock=0;if(car.panicState)car.panicState.touchIds.clear();seat(car);diagnostic(occupancy==='npc'?'capture-NPC':'board',car,actor);}
 function spikeContacts(car,geometry){
  const a=bodyOf(car);
  return geometry.filter(b=>{
   if(b.hidden||b.collision!=='solid'||b.spikeTrap!==true)return false;
   const x=Math.min(a.x+a.w,b.x+b.w)-Math.max(a.x,b.x),y=Math.min(a.y+a.h,b.y+b.h)-Math.max(a.y,b.y);
   return x>EPS&&y>=-EPS||y>EPS&&x>=-EPS;
  }).map(q=>q.id??q.sourceId??`spike@${q.x},${q.y},${q.w},${q.h}`);
 }
 function startPanic(car,geometry){
  const state=car.panicState;if(!state||car.occupancy!=='npc'||state.remainingFrames)return false;
  const contacts=spikeContacts(car,geometry),newContacts=contacts.filter(id=>!state.touchIds.has(id));if(!newContacts.length)return false;
  state.remainingFrames=car.npcSpikePanic.durationFrames;state.triggerSpikeIds=newContacts;
  diagnostic('npc-spike-panic-start',car,car.occupant,{spikeIds:[...newContacts],remainingFrames:state.remainingFrames});return true;
 }
 function stopPanic(car,reason){
  const state=car.panicState;if(!state)return;
  if(state.remainingFrames){state.remainingFrames=0;diagnostic('npc-spike-panic-stop',car,car.occupant,{reason});}
  if(reason==='vacancy'){state.touchIds.clear();state.triggerSpikeIds=[];}
 }
 function disembark(player,{reason='manual',jump=false}={}){
  const car=cars.find(q=>q.occupancy==='player'&&q.occupant===player);if(!car)return false;
  if(!['goal','hurt','manual'].includes(reason)||typeof jump!=='boolean')throw Error('Invalid Clown Car disembark options');
  // The caller may already have set a flag-slide pose or native hurt velocity.
  // Detach the actual actor without seating, moving, or resetting either body.
  if(jump){player.vy=(player.vy||0)-4.1333333;player.grounded=false;player.support=null;player.jumpBuffer=0;}
  car.noBoardUntil=clock+2;vacate(car,'eject',reason);poses.set(key(player),pose(player));return true;
 }

 // Swept component contacts keep the wide cup and the protruding actor real.
 // One-way terrain blocks falling; a DOWN wall blocks rising and allows falling.
 function sweep(car,axis,delta,geometry,walls){
  if(Math.abs(delta)<EPS)return null;
  let travel=delta,hit=null;
  const parts=boxes(car),colliders=[...geometry.filter(q=>!q.hidden&&['solid','oneway'].includes(q.collision)),...walls.map(q=>({...q,carOneWay:true}))];
  for(const q of colliders){
   if(q.carOneWay){if(!((axis==='x'&&((delta>0&&q.direction==='left')||(delta<0&&q.direction==='right')))||(axis==='y'&&((delta>0&&q.direction==='up')||(delta<0&&q.direction==='down')))))continue;}
   else if(q.collision==='oneway'&&(axis!=='y'||delta<0))continue;
   for(const b of parts){
    const transverse=axis==='x'?b.y+b.h>q.y+EPS&&b.y<q.y+q.h-EPS:b.x+b.w>q.x+EPS&&b.x<q.x+q.w-EPS;if(!transverse)continue;
    const start=axis==='x'?b.x:b.y,size=axis==='x'?b.w:b.h,edge=axis==='x'?q.x:q.y,qsize=axis==='x'?q.w:q.h;
    if(delta>0&&start+size<=edge+EPS&&start+size+travel>edge){const d=Math.max(0,edge-start-size);if(d<=travel){travel=d;hit=q;}}
    else if(delta<0&&start>=edge+qsize-EPS&&start+travel<edge+qsize){const d=Math.min(0,edge+qsize-start);if(d>=travel){travel=d;hit=q;}}
   }
  }
  const contact=union(parts),min=axis==='x'?-contact.x:-contact.y,max=axis==='x'?width-contact.x-contact.w:height-contact.y-contact.h;
  const bounded=clamp(travel,min,max);if(Math.abs(bounded-travel)>EPS)hit={id:'room-boundary'};travel=bounded;
  car[axis]+=travel;if(hit)car[axis==='x'?'vx':'vy']=0;return hit;
 }
 function clearBoardingPath(car,actor,before,geometry){
  // The native motor normally supplies this guarantee. Keep contact tolerance
  // from pulling an actor through a platform/ceiling when used independently.
  const opening=car.y,bottom=before.y+before.h,now=actor.y+actor.h;
  return !geometry.some(q=>!q.hidden&&['solid','oneway'].includes(q.collision)&&actor.x+actor.w>q.x+EPS&&actor.x<q.x+q.w-EPS&&q.y>bottom+EPS&&q.y<Math.min(now,opening)+EPS&&q.y+q.h<=opening+EPS);
 }
 function descendingContact(car,actor,geometry){
  if(!live(actor)||isOwned(actor)||actor.vehicleId||actor.clawHeld||actor.clawId||actor.clawHeldBy||actor.heldByClaw||context.isHeld?.(actor))return false;
  const previous=poses.get(key(actor))||{...pose(actor),y:actor.y-(actor.vy||0)};
  const bottom=actor.y+actor.h,oldBottom=previous.y+previous.h,opening=car.y,oldOpening=car.previousY??opening;
  if(!(actor.vy>EPS||actor.y>previous.y+EPS)||oldBottom>oldOpening+car.boardingTolerance||bottom<opening-car.boardingTolerance||bottom>opening+car.boardingTolerance+Math.max(0,actor.vy||0)||actor.grounded)return false;
  const lip=4;if(actor.x+actor.w<=car.x+lip||actor.x>=car.x+car.w-lip)return false;
  return clearBoardingPath(car,actor,previous,geometry);
 }
 function sync(next={}){
  context={...context,...next};const {player,enemies=[],geometry=[]}=context;
  for(const car of cars){
   if(car.occupant){const present=car.occupancy==='player'?car.occupant===player:enemies.includes(car.occupant);
    if(!live(car.occupant)||!present)vacate(car,'vacancy',car.occupant.dead?'occupant-dead':car.occupant.dying?'occupant-dying':'occupant-left');else seat(car);
   }
   if(car.occupant)continue;
   const enemy=enemies.find(e=>/goomba|walker/i.test(e.type||'')&&!e.shell&&descendingContact(car,e,geometry));
   if(enemy){adopt(car,enemy,'npc');continue;}
   if(player&&clock>car.noBoardUntil&&descendingContact(car,player,geometry))adopt(car,player,'player');
  }
  for(const actor of [player,...enemies].filter(Boolean))poses.set(key(actor),pose(actor));
  return view();
 }
 function step(next={}){
  context={...context,...next};
  const supplied=next.tick,now=Number.isFinite(supplied)?supplied:clock+1;
  if(lastTick===now)return view();lastTick=now;clock=now;
  sync(context);
  const {player,geometry=[],oneWayWalls=[],input={}}=context;
  for(const car of cars){
   car.previousY=car.y;car.previousX=car.x;
   if(car.occupancy==='player'&&input.jumpPressed){
    const actor=car.occupant;actor.vx=car.vx;actor.vy=car.vy-4.1333333;actor.grounded=false;actor.support=null;actor.jumpBuffer=0;car.noBoardUntil=clock+2;vacate(car,'eject','jump');
   }
   if(car.occupancy==='npc'){
    startPanic(car,geometry);
    if(car.panicState?.remainingFrames){
     car.vx=approach(car.vx,0,car.npcSpikePanic.horizontalDrag);car.vy=approach(car.vy,-car.npcSpikePanic.maxSpeed,car.npcSpikePanic.acceleration);
    }else{
     const dx=player?player.x+player.w/2-(car.x+car.w/2):0,dy=player?player.y+player.h/2-(car.y+car.h/2):0;
     car.vx=approach(car.vx,Math.abs(dx)<2?0:Math.sign(dx)*car.npcMaxSpeed,car.npcAcceleration);
     car.vy=approach(car.vy,Math.abs(dy)<2?0:Math.sign(dy)*car.npcMaxSpeed,car.npcAcceleration);
    }
   }else if(car.occupancy==='player'){
    const x=clamp(Number(input.x)||0,-1,1),y=Number.isFinite(input.y)?clamp(input.y,-1,1):Number(!!input.down)-Number(!!input.up);
    car.vx=approach(car.vx,x*car.playerMaxSpeed,x?car.playerAcceleration:car.drag);
    car.vy=approach(car.vy,y*car.playerMaxSpeed,y?car.playerAcceleration:car.drag);
   }else{
    car.hoverClock++;car.vx=approach(car.vx,0,car.drag);const target=car.hoverY+Math.sin(car.hoverClock*Math.PI*2/car.bobPeriodFrames)*car.bobPixels;
    car.vy=clamp(target-car.y,-.4,.4);
   }
   sweep(car,'x',car.vx,geometry,oneWayWalls);
   // A sideways swept cup contact can reverse the vertical target this frame.
   // A falling contact starts the same state after landing, for the next frame.
   if(startPanic(car,geometry))car.vy=approach(car.vy,-car.npcSpikePanic.maxSpeed,car.npcSpikePanic.acceleration);
   const panicMoved=car.panicState?.remainingFrames>0&&car.occupancy==='npc';
   sweep(car,'y',car.vy,geometry,oneWayWalls);startPanic(car,geometry);seat(car);
   if(car.panicState){
    car.panicState.touchIds=new Set(car.occupancy==='npc'?spikeContacts(car,geometry):[]);
    if(panicMoved){if(car.panicState.remainingFrames===1)stopPanic(car,'duration');else car.panicState.remainingFrames--;}
   }
  }
  return view();
 }
 function contactBody(actor){const car=typeof actor==='string'?cars.find(q=>q.id===actor):actor?cars.find(q=>q.occupant===actor):cars.find(q=>q.occupancy==='player');return car?union(boxes(car)):null;}
 function view(){return {version:CLOWN_CAR_VERSION,approximation:true,cars:cars.map(car=>{const {occupant,panicState,hoverX,hoverY,hoverClock,noBoardUntil,previousX,previousY,...data}=car;return {...data,...(panicState?{npcPanic:{active:panicState.remainingFrames>0,remainingFrames:panicState.remainingFrames,triggerSpikeIds:[...panicState.triggerSpikeIds]}}:{}),occupantId:car.occupancy==='player'?'player':occupant?.id??null,occupant:occupant?{id:car.occupancy==='player'?'player':occupant.id,type:car.occupancy==='player'?'player':occupant.type,...pose(occupant)}:null,opening:{x:car.x+4,y:car.y,w:car.w-8,h:1},contactBody:union(boxes(car))};})};}
 function reset(){for(const car of cars){if(car.occupant?.clownCarId===car.id)delete car.occupant.clownCarId;if(car.occupant?.vehicleId===car.id)delete car.occupant.vehicleId;}cars=authored.map(q=>({...q,...(q.npcSpikePanic?{panicState:{remainingFrames:0,touchIds:new Set(),triggerSpikeIds:[]}}:{}),vx:0,vy:0,occupancy:'empty',occupant:null,hoverX:q.x,hoverY:q.y,hoverClock:0,noBoardUntil:-Infinity,previousX:q.x,previousY:q.y}));poses=new Map();lastTick=null;clock=0;context={player:null,enemies:[],geometry:[],oneWayWalls:[]};}
 reset();return Object.freeze({step,sync,disembark,ownsActor:isOwned,ownsPlayer:()=>cars.some(car=>car.occupancy==='player'&&live(car.occupant)),contactBody,view,reset});
}
