import {clone} from './editor-model.mjs';
import {validateMinecraftRoom} from './editor-minecraft.mjs';

export const MINECRAFT_ROOM_BIOMES=Object.freeze(['forest','cave','nether','stronghold','end']);
export const MINECRAFT_ADVENTURE_EXAMPLE='../examples/minecraft-adventure/blast-trail.qmap.json';
const basicFields=new Set(['version','biome','musicMode','hero']);
const settingFields=new Set(['enabled','biome','musicMode','alwaysBig','maxHealth']);

/** The basic panel does not own authored mobs, geometry bindings or scenery.
 * Refuse to remove their parent, rather than silently losing those records. */
export function minecraftAdvancedDataKeys(room){
 return Object.keys(room.minecraft||{}).filter(key=>!basicFields.has(key));
}

/** Apply only opt-in room settings. Existing IDs, world data, music defaults
 * and unexposed hero feedback remain untouched. Call through History.change. */
export function setMinecraftRoomSettings(room,settings){
 if(!settings||typeof settings!=='object'||Array.isArray(settings)||![Object.prototype,null].includes(Object.getPrototypeOf(settings))||Object.keys(settings).some(key=>!settingFields.has(key)))throw Error('无效的 MC 房间设置');
 if(typeof settings.enabled!=='boolean')throw Error('请明确选择是否启用 MC 环境');
 if(settings.biome!==undefined&&settings.biome!==null&&!MINECRAFT_ROOM_BIOMES.includes(settings.biome))throw Error('请选择支持的 MC 环境');
 if(settings.musicMode!==undefined&&settings.musicMode!==null&&!['licensed','local'].includes(settings.musicMode))throw Error('请选择授权音乐或本地音乐');
 if(settings.alwaysBig!==undefined&&typeof settings.alwaysBig!=='boolean')throw Error('无效的常驻大体型设置');
 if(settings.maxHealth!==undefined&&(!Number.isInteger(settings.maxHealth)||settings.maxHealth<1||settings.maxHealth>12))throw Error('本房间基础生命上限须为 1–12 的整数');
 if(!settings.enabled){
  if(!room.minecraft)return false;
  if(minecraftAdvancedDataKeys(room).length)throw Error('此房间含已编排的 MC 机关或场景数据，基础面板不能关闭它。请先另存工程备份，再按模板文档调整；当前数据未删除。');
  delete room.minecraft;return true;
 }
 const next=clone(room),spec=next.minecraft??={version:1};
 for(const key of ['biome','musicMode'])if(settings[key]===null)delete spec[key];else if(settings[key]!==undefined)spec[key]=settings[key];
 if(settings.alwaysBig===false)delete spec.hero;
 else if(settings.alwaysBig===true)spec.hero={...spec.hero,alwaysBig:true,maxHealth:settings.maxHealth??spec.hero?.maxHealth??3};
 else if(settings.maxHealth!==undefined){if(!spec.hero)throw Error('设置房间基础生命上限前请启用常驻大体型');spec.hero.maxHealth=settings.maxHealth;}
 validateMinecraftRoom(next);
 if(JSON.stringify(room.minecraft)===JSON.stringify(spec))return false;
 room.minecraft=spec;return true;
}

/** Small, honest room-authoring surface. Full adventures are separate files;
 * this panel neither injects a template nor replaces the current document. */
export function mountMinecraftTools({parent,room,change,report=()=>{}}){
 const root=document.createElement('details');root.className='tool-details';root.setAttribute('data-minecraft-panel','room');
 const summary=document.createElement('summary');summary.textContent='MC 冒险 · 可选房间设置';root.append(summary);parent.append(root);
 const controls=new Map();
 function field(id,label,tag='input',type='checkbox'){
  const row=document.createElement('label'),node=document.createElement(tag);row.textContent=label;if(tag==='input')node.type=type;node.setAttribute('data-minecraft-control',id);row.append(node);root.append(row);controls.set(id,node);return node;
 }
 const enabled=field('enabled','启用当前房间的 MC 环境');
 const biome=field('biome','环境','select');
 const music=field('musicMode','背景音乐来源','select');
 function options(node,entries){for(const [value,title]of entries){const option=document.createElement('option');option.value=value;option.textContent=title;node.append(option);}}
 options(biome,[['','沿用默认（森林）'],['forest','森林'],['cave','洞穴'],['nether','下界'],['stronghold','要塞'],['end','末地']]);
 options(music,[['','沿用默认（仅本地音乐）'],['licensed','包内授权配乐 · Dark Reaven Music'],['local','仅本地文件（试玩中选择）']]);
 const big=field('alwaysBig','常驻大体型与独立生命值（可选）');
 const health=field('maxHealth','本房间基础生命上限（1–12，默认 3）','input','number');health.min='1';health.max='12';health.step='1';
 const help=document.createElement('p');help.className='small';help.textContent='仅改变当前房间。未启用时沿用普通地图行为。此数值是本房间的基础生命上限，已获取的唯一容量奖励继续累加。进入上限较低的房间时，超出新上限的当前生命会降至该上限；进入上限较高的房间不会自动治疗。已有机关可能限制环境选择，例如雷暴要求森林；不兼容的修改会被拦下。';root.append(help);
 const provenance=document.createElement('p');provenance.className='small';provenance.setAttribute('data-minecraft-control','provenance');root.append(provenance);
 const credits=document.createElement('a');credits.href='./assets/voxel-music/MUSIC_CREDITS.md';credits.textContent='查看曲目、来源与 CC BY-SA 3.0 授权说明';credits.target='_blank';credits.rel='noopener';root.append(credits);
 const status=document.createElement('p');status.className='small';status.setAttribute('data-minecraft-control','status');status.setAttribute('role','status');root.append(status);
 const apply=document.createElement('button');apply.type='button';apply.textContent='应用 MC 房间设置';apply.setAttribute('data-minecraft-control','apply');root.append(apply);
 const advanced=document.createElement('p');advanced.className='small';advanced.textContent='苦力怕、落沙、村民任务、装备、雷暴与 Boss 需要完整模板或作者数据及真实实体引用；本面板没有这些机关的拖放组件。含这类数据的房间不能在此直接关闭 MC 环境。';root.append(advanced);
 const example=document.createElement('a');example.href=MINECRAFT_ADVENTURE_EXAMPLE;example.download='blast-trail.qmap.json';example.textContent='下载可选完整 MC 冒险示例（qmap）';example.setAttribute('data-minecraft-control','example');root.append(example);
 const exampleHelp=document.createElement('p');exampleHelp.className='small';exampleHelp.textContent='下载不会替换当前地图。请先保存自己的工程，再用“导入工程”打开示例。';root.append(exampleHelp);
 function updateAvailability(){
  biome.disabled=music.disabled=big.disabled=!enabled.checked;health.disabled=!enabled.checked||!big.checked;
  provenance.textContent=music.value==='licensed'?'包内配乐：Dark Reaven Music 的 Magic of the Forest、Deep Mining、Traitor，来自 VoxeLibre，CC BY-SA 3.0；不是 Minecraft 原声。发布时保留署名与许可。':'仅播放你在试玩页自行选择的本地音乐；未选文件时没有背景音乐。文件留在当前页面内存，不上传、不写入 qmap、不随导出打包。';
 }
 enabled.onchange=big.onchange=music.onchange=updateAvailability;
 apply.onclick=()=>{
  try{
   const settings={enabled:!!enabled.checked};
   if(settings.enabled){settings.biome=biome.value||null;settings.musicMode=music.value||null;settings.alwaysBig=!!big.checked;if(big.checked){if(health.value.trim()==='')throw Error('请填写本房间基础生命上限（1–12）');settings.maxHealth=Number(health.value);}}
   change(()=>setMinecraftRoomSettings(room(),settings));refresh();report('MC 房间设置已应用，可撤销');
  }catch(error){report(error.message);refresh();status.textContent=error.message;}
 };
 function refresh(){
  const spec=room().minecraft;enabled.checked=!!spec;biome.value=spec?.biome??'';music.value=spec?.musicMode??'';big.checked=!!spec?.hero?.alwaysBig;health.value=String(spec?.hero?.maxHealth??3);
  const keys=minecraftAdvancedDataKeys(room());status.textContent=keys.length?'此房间保留高级 MC 数据：'+keys.join('、')+'。基础设置不会改写它们。':'MC 环境默认关闭，仅在勾选并应用后启用。';updateAvailability();
 }
 refresh();return {refresh};
}
