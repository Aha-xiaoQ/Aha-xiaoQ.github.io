/**
 * Bounded authoring experiment, independent of qmap / Stage / NSMBU modules.
 * The observed scene supports fixed world nodes with sliding front/rear tiles.
 * It does not establish activation, end-tile collision/carry, final-game speed,
 * payloads, or original end-of-route behavior. Completion is this tool's limit.
 * Path coordinates are tile CENTERS relative to an arbitrary world origin.
 */
export const SNAKE_WINDOW_PREVIEW_FORMAT = 'snake-window-preview';
export const SNAKE_WINDOW_PREVIEW_VERSION = 1;
export const SNAKE_WINDOW_PREVIEW_TILE_SIZE = 16;
// Tool numerical-safety bound: keeps 16px renderer grid steps distinguishable.
// This is not an original-game maximum coordinate or a gameplay parameter.
export const SNAKE_WINDOW_PREVIEW_COORDINATE_LIMIT = 1_000_000;
const SIZE = SNAKE_WINDOW_PREVIEW_TILE_SIZE;
const EPSILON = 1e-8;
const clone = value => JSON.parse(JSON.stringify(value));
const record = value => !!value && typeof value === 'object' && !Array.isArray(value);
const prefix = id => `snake-window:${encodeURIComponent(id)}:`;

function keys(value, allowed, label) {
  if (!record(value)) throw new TypeError(`${label} must be an object`);
  for (const key of Object.keys(value)) {
    if (!allowed.includes(key)) throw new TypeError(`${label}.${key} is not part of snake-window-preview v1`);
  }
}
function finite(value, label) {
  if (typeof value !== 'number' || !Number.isFinite(value)) throw new TypeError(`${label} must be finite`);
}
function coordinate(value, label) {
  finite(value, label);
  if (Math.abs(value) > SNAKE_WINDOW_PREVIEW_COORDINATE_LIMIT) throw new TypeError(`${label} exceeds the preview tool numerical-safety range of +/-1000000px`);
}
function identifier(value, label) {
  if (typeof value !== 'string' || !value.trim() || value.length > 128) throw new TypeError(`${label} must be a nonempty ID of at most 128 characters`);
}

/** Validate and return a detached document. No qmap fields are accepted. */
export function validateSnakeWindowPreview(document) {
  keys(document, ['format', 'version', 'id', 'tileSize', 'origin', 'path', 'lengthCells', 'initialHeadDistancePx', 'speedPxPerSecond', 'observationDurationMs', 'parameterStatus'], 'document');
  if (document.format !== SNAKE_WINDOW_PREVIEW_FORMAT || document.version !== SNAKE_WINDOW_PREVIEW_VERSION) throw new TypeError('Expected snake-window-preview version 1');
  identifier(document.id, 'document.id');
  if (document.tileSize !== SIZE) throw new TypeError('snake-window-preview v1 uses a 16px grid');
  if (document.parameterStatus !== 'authored-not-calibrated') throw new TypeError('Parameters must be explicitly authored-not-calibrated');
  keys(document.origin, ['x', 'y'], 'origin');
  coordinate(document.origin.x, 'origin.x');
  coordinate(document.origin.y, 'origin.y');
  if (!Array.isArray(document.path) || document.path.length < 2 || document.path.length > 1024) throw new TypeError('path must contain 2..1024 waypoints');
  const ids = new Set();
  let pathLength = 0;
  document.path.forEach((node, index) => {
    keys(node, ['id', 'x', 'y'], `path[${index}]`);
    identifier(node.id, `path[${index}].id`);
    if (ids.has(node.id)) throw new TypeError('Waypoint IDs must be unique');
    ids.add(node.id);
    for (const axis of ['x', 'y']) {
      coordinate(node[axis], `path[${index}].${axis}`);
      if (!Number.isSafeInteger(node[axis]) || node[axis] % SIZE !== 0) throw new TypeError(`path[${index}].${axis} must be an integer multiple of 16`);
      // Intermediate points lie between these orthogonal-edge endpoints.
      coordinate(document.origin[axis] + node[axis], `path[${index}].world${axis.toUpperCase()}`);
    }
    if (index) {
      const previous = document.path[index - 1];
      const dx = node.x - previous.x, dy = node.y - previous.y;
      if ((!dx && !dy) || (dx && dy)) throw new TypeError('Each path edge must be nonzero and orthogonal');
      pathLength += Math.abs(dx) + Math.abs(dy);
    }
  });
  if (!Number.isInteger(document.lengthCells) || document.lengthCells < 2) throw new TypeError('lengthCells must be an integer >= 2');
  finite(document.initialHeadDistancePx, 'initialHeadDistancePx');
  const span = (document.lengthCells - 1) * SIZE;
  if (document.initialHeadDistancePx < span || document.initialHeadDistancePx > pathLength) throw new TypeError('The complete initial occupied window must lie on the authored path');
  finite(document.speedPxPerSecond, 'speedPxPerSecond');
  if (document.speedPxPerSecond <= 0) throw new TypeError('speedPxPerSecond must be positive');
  finite(document.observationDurationMs, 'observationDurationMs');
  if (document.observationDurationMs <= 0) throw new TypeError('observationDurationMs must be positive');
  // Restrict this experiment to a simple route; crossings/revisits are unproved.
  const visited = new Set();
  for (const node of expandPath(document)) {
    const coordinate = `${node.relativeX},${node.relativeY}`;
    if (visited.has(coordinate)) throw new TypeError('This bounded preview does not support route crossings or revisits');
    visited.add(coordinate);
  }
  return clone(document);
}

export function serializeSnakeWindowPreview(document) {
  return JSON.stringify(validateSnakeWindowPreview(document), null, 2) + '\n';
}

export function parseSnakeWindowPreview(json) {
  if (typeof json !== 'string') throw new TypeError('Expected a snake-window-preview JSON string');
  return validateSnakeWindowPreview(JSON.parse(json));
}

function expandPath(document) {
  const nodes = [];
  const append = (x, y, waypointId = null) => {
    if (nodes.length >= 16384) throw new TypeError('Expanded preview path exceeds 16384 grid nodes');
    nodes.push({
      id: `${prefix(document.id)}node:${x},${y}`,
      waypointId, relativeX: x, relativeY: y,
      centerX: document.origin.x + x, centerY: document.origin.y + y,
      pathDistancePx: nodes.length * SIZE
    });
  };
  const first = document.path[0];
  append(first.x, first.y, first.id);
  for (let index = 1; index < document.path.length; index++) {
    const from = document.path[index - 1], to = document.path[index];
    const dx = Math.sign(to.x - from.x) * SIZE, dy = Math.sign(to.y - from.y) * SIZE;
    const count = (Math.abs(to.x - from.x) + Math.abs(to.y - from.y)) / SIZE;
    for (let step = 1; step <= count; step++) append(from.x + dx * step, from.y + dy * step, step === count ? to.id : null);
  }
  return nodes;
}

function rectangle(centerX, centerY) {
  return {x: centerX - SIZE / 2, y: centerY - SIZE / 2, w: SIZE, h: SIZE};
}

/** lengthCells N means the authored end-center separation is (N-1)*16px. */
export function createSnakeWindowPreview(document) {
  const data = validateSnakeWindowPreview(document), nodes = expandPath(data);
  const pathLengthPx = nodes.at(-1).pathDistancePx;
  const spanPx = (data.lengthCells - 1) * SIZE;
  const pathLimitMs = (pathLengthPx - data.initialHeadDistancePx) / data.speedPxPerSecond * 1000;
  const durationMs = Math.min(data.observationDurationMs, pathLimitMs);
  const supportNamespace = `${prefix(data.id)}node:`;
  let elapsedMs = 0, paused = false;

  function end(role, distance) {
    const segment = Math.min(nodes.length - 2, Math.floor(distance / SIZE));
    const from = nodes[segment], to = nodes[segment + 1];
    const fraction = (distance - from.pathDistancePx) / SIZE;
    const centerX = from.centerX + (to.centerX - from.centerX) * fraction;
    const centerY = from.centerY + (to.centerY - from.centerY) * fraction;
    return {id: `${prefix(data.id)}${role}`, role, centerX, centerY, ...rectangle(centerX, centerY), pathDistancePx: distance, direction: {x: Math.sign(to.centerX - from.centerX), y: Math.sign(to.centerY - from.centerY)}, visualOnly: true};
  }

  function snapshot() {
    const complete = elapsedMs >= durationMs;
    const headDistancePx = Math.min(pathLengthPx, data.initialHeadDistancePx + data.speedPxPerSecond * elapsedMs / 1000);
    const tailDistancePx = headDistancePx - spanPx;
    const head = end('head', headDistancePx), tail = end('tail', tailDistancePx);
    const fixed = nodes.filter(node => node.pathDistancePx > tailDistancePx + EPSILON && node.pathDistancePx < headDistancePx - EPSILON).map(node => ({...node, ...rectangle(node.centerX, node.centerY), role: 'fixed', visualOnly: false}));
    // Only wholly exposed FIXED top faces get contact. A sliding end's visible
    // footprint neither becomes a collider nor authorizes carry. If an end
    // masks any part of a fixed top, that top is conservatively visual-only.
    const fixedContactCells = fixed.filter(cell => ![head, tail].some(cap => cap.y <= cell.y + EPSILON && cap.y + cap.h > cell.y + EPSILON && cap.x < cell.x + cell.w - EPSILON && cap.x + cap.w > cell.x + EPSILON)).map(cell => ({id: cell.id, nodeId: cell.id, x: cell.x, y: cell.y, w: cell.w, h: cell.h, collision: 'oneway', role: 'fixed', contactScope: 'exposed-fixed-top-only'}));
    return {
      format: data.format, version: data.version, previewId: data.id,
      scope: 'preview-experiment-only', parameterStatus: data.parameterStatus,
      status: complete ? 'preview-complete' : paused ? 'paused' : 'running',
      elapsedMs, observationDurationMs: data.observationDurationMs,
      effectiveDurationMs: durationMs, pathLengthPx, spanPx,
      completionReason: complete ? (pathLimitMs < data.observationDurationMs ? 'authored-path-window-ended' : 'observation-window-ended') : null,
      completionIsOriginalEndpointEvidence: false,
      head, tail, renderCells: [...fixed, tail, head], fixedContactCells,
      supportNamespace,
      sourceLimits: ['activation-unseen', 'endpoint-unseen', 'end-tile-contact-unverified', 'payloads-unseen', 'final-build-unverified', 'parameters-not-calibrated']
    };
  }

  function tick(deltaMs = 1000 / 60) {
    finite(deltaMs, 'deltaMs');
    if (deltaMs < 0) throw new TypeError('deltaMs must be nonnegative');
    if (!paused && elapsedMs < durationMs) elapsedMs = Math.min(durationMs, elapsedMs + deltaMs);
    return snapshot();
  }
  function setPaused(value) {
    if (typeof value !== 'boolean') throw new TypeError('Paused state must be boolean');
    paused = value;
    return snapshot();
  }
  function reset() {elapsedMs = 0; paused = false; return snapshot();}
  return Object.freeze({snapshot, tick, setPaused, reset, getDocument: () => clone(data)});
}

/**
 * Local integration guard, BEFORE the supplied legacy motor reads grounded.
 * It prevents stale preview support from granting a ghost jump. It does not
 * change player coordinates, velocities, other supports, or the global motor.
 */
export function invalidateSnakeWindowPreviewSupport(player, snapshot) {
  const previousSupport = player.support;
  if (typeof previousSupport !== 'string' || !previousSupport.startsWith(snapshot.supportNamespace)) return {invalidated: false, previousSupport, reason: null};
  const valid = player.grounded && (player.vy || 0) >= 0 && snapshot.fixedContactCells.some(cell => cell.id === previousSupport && player.x + player.w > cell.x && player.x < cell.x + cell.w && Math.abs(player.y + player.h - cell.y) <= 1.01);
  if (valid) return {invalidated: false, previousSupport, reason: null};
  player.grounded = false;
  player.support = null;
  if ('jumpBuffer' in player) player.jumpBuffer = 0;
  return {invalidated: true, previousSupport, reason: 'preview-fixed-top-no-longer-valid'};
}

/** Run the unchanged caller-supplied motor against current fixed top faces. */
export function stepSnakeWindowPreviewPlayer({motor, player, input = {}, character, world, snapshot}) {
  if (!motor || typeof motor.step !== 'function') throw new TypeError('An existing motor with step() is required');
  const supportCheck = invalidateSnakeWindowPreviewSupport(player, snapshot);
  const solids = [...(world.solids || []).filter(cell => typeof cell.id !== 'string' || !cell.id.startsWith(snapshot.supportNamespace)), ...snapshot.fixedContactCells];
  const events = motor.step(player, input, character, {...world, solids});
  return {events, supportCheck};
}
