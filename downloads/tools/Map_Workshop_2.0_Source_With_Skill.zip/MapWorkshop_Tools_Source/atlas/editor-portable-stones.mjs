/** Opt-in portable Stone contact controller, for the observed SMB3 Stone actions.
 * All motion tuning is required author configuration, never claimed native data.
 * This controller moves stones only. The host owns Mario's motor, Note impulses,
 * damage, enemy defeat, score, actual goal contact and room/death transitions.
 *
 * Integration: skip owned native walkers and insert seedItems() into live items.
 * stepItem once per active tick, then use geometry(base,items) for Mario's motor.
 * beforePlayer/afterPlayer bracket that motor; heldMotion returns its explicit
 * carry-motion override. Use geometry(...,{excludeActor:item}) for stone motion.
 * afterActor is a callback with the existing Mario-module signature, including
 * kind:'item'; it may apply the real Note bounce after terrain resolution.
 * Geometry/view/heldMotion/readyForGoal are pure projections, never ticking.
 * The motor alone consumes support dx/dy; no second passenger movement exists.
 * No cross-room carry, water/lava behavior, giant stones or damage immunity.
 */
const EPS=1e-7;
const clone=value=>structuredClone(value);
const fail=message=>{throw Error(message);};
const finite=(value,min,max)=>Number.isFinite(value)&&value>=min&&value<=max;
const integer=(value,min,max)=>Number.isSafeInteger(value)&&finite(value,min,max);
const unsafe=key=>['__proto__','constructor','prototype'].includes(key);
const plain=value=>value&&typeof value==='object'&&!Array.isArray(value)&&[Object.prototype,null].includes(Object.getPrototypeOf(value));
const safeId=value=>typeof value==='string'&&value.length>0&&value.length<=128&&!/[\u0000-\u001f\u007f]/.test(value)&&!unsafe(value);
const rect=value=>value&&['x','y','w','h'].every(key=>Number.isFinite(value[key]))&&value.w>0&&value.h>0;
const live=value=>value&&!value.dead&&!value.dying&&!value.removed&&!value.taken;
const body=value=>({x:value.x,y:value.y,w:value.w,h:value.h});
const pose=value=>({...body(value),vx:value.vx??0,vy:value.vy??0,grounded:!!value.grounded,support:value.support??null});
const overlap=(a,b)=>a.x<b.x+b.w-EPS&&a.x+a.w>b.x+EPS&&a.y<b.y+b.h-EPS&&a.y+a.h>b.y+EPS;
const horizontal=(a,b)=>a.x<b.x+b.w-EPS&&a.x+a.w>b.x+EPS;
const vertical=(a,b)=>a.y<b.y+b.h-EPS&&a.y+a.h>b.y+EPS;
const stoneFields=['id','gravity','maxFallSpeed','throwSpeedX','throwSpeedY','releaseSafeFrames','heldOffsetX','heldBottomOffset','carryMotion','points'];
const motionFields=['walkCap','runCap','airCap','jumpSpeed','jumpGravity','fallGravity'];
function fields(value,allowed,label,required=allowed){
 if(!plain(value))fail('Invalid '+label);
 for(const key of Object.keys(value))if(unsafe(key)||!allowed.includes(key))fail('Unknown '+label+' field: '+key);
 for(const key of required)if(!Object.hasOwn(value,key))fail('Missing '+label+' field: '+key);
}
function inside(value,map){return rect(value)&&value.x>=0&&value.y>=0&&value.x+value.w<=map.width&&value.y+value.h<=map.height;}

/** Validate just the portableStones leaf. The enclosing importer validates all
 * sibling leaves; this validator neither accepts nor rewrites those siblings. */
export function validatePortableStones(room,spec=room?.smm2Mechanics?.portableStones){
 if(spec===undefined)return;
 fields(spec,['version','stones','clearCondition'],'portable stones',['version','stones']);
 if(spec.version!==1)fail('Unknown portable stones version');
 const map=room?.map;
 if(!map||!finite(map.width,1,32768)||!finite(map.height,1,4096)||!Array.isArray(map.objects)||!Array.isArray(map.geometry))fail('Portable stones need bounded native room geometry and objects');
 if(!Array.isArray(spec.stones)||spec.stones.length>256)fail('Invalid portable stones list');
 const native=[...map.geometry,...map.objects,...(room.markers||[])],seen=new Set();
 for(const stone of spec.stones){
  fields(stone,stoneFields,'portable stone',stoneFields.filter(key=>key!=='points'));
  if(!safeId(stone.id)||seen.has(stone.id))fail('Duplicate or invalid portable stone ID');
  seen.add(stone.id);
  const source=map.objects.find(actor=>actor.id===stone.id);
  if(native.filter(actor=>actor.id===stone.id).length!==1||source?.kind!=='walker'||source.w!==16||source.h!==16||!inside(source,map))fail('Portable stone needs one native 16 by 16 walker inside the room');
  if(!finite(stone.gravity,0,64)||!finite(stone.maxFallSpeed,.001,256)||!finite(stone.throwSpeedX,0,256)||!finite(stone.throwSpeedY,-256,0)||!integer(stone.releaseSafeFrames,0,36000)||!finite(stone.heldOffsetX,0,256)||!finite(stone.heldBottomOffset,-256,256))fail('Invalid explicit portable stone motion tuning');
  fields(stone.carryMotion,motionFields,'stone carry motion');
  if(!['walkCap','runCap','airCap'].every(key=>finite(stone.carryMotion[key],0,256))||!finite(stone.carryMotion.jumpSpeed,.001,256)||!finite(stone.carryMotion.jumpGravity,0,64)||!finite(stone.carryMotion.fallGravity,0,64))fail('Invalid explicit stone carry motion');
  if(stone.points!==undefined&&!integer(stone.points,0,100000))fail('Invalid portable stone points');
 }
 if(spec.clearCondition!==undefined){
  fields(spec.clearCondition,['kind','goalId'],'portable stone clear condition');
  const condition=spec.clearCondition,goal=map.objects.find(actor=>actor.id===condition.goalId);
  if(condition.kind!=='carry-stone'||!safeId(condition.goalId)||native.filter(actor=>actor.id===condition.goalId).length!==1||goal?.kind!=='exit'||!inside(goal,map)||!spec.stones.length)fail('Carry-stone clear condition needs a unique native goal and at least one stone');
 }
}

/** Continuous AABB entry, including a zero-time inward contact. Embedded starts
 * are not attacks or pickup evidence and are deliberately not fabricated hits. */
function sweepRect(from,delta,target){
 if(overlap(from,target))return null;
 let enter=-Infinity,exit=Infinity,normal=null;
 for(const axis of ['x','y']){
  const size=axis==='x'?'w':'h',amount=delta[axis];
  if(Math.abs(amount)<EPS){if(from[axis]+from[size]<=target[axis]+EPS||from[axis]>=target[axis]+target[size]-EPS)return null;continue;}
  const a=(target[axis]-from[axis]-from[size])/amount,b=(target[axis]+target[size]-from[axis])/amount,near=Math.min(a,b),far=Math.max(a,b);
  if(near>enter){enter=near;normal={x:axis==='x'?-Math.sign(amount):0,y:axis==='y'?-Math.sign(amount):0};}
  exit=Math.min(exit,far);
  if(enter>exit+EPS)return null;
 }
 if(!normal||enter<-EPS||enter>1+EPS||exit<0)return null;
 return {fraction:Math.max(0,Math.min(1,enter)),normal,solidId:target.id};
}
function rectangleSweep(actor,delta,geometry){
 let closest=null;
 for(const solid of geometry){
  if(solid.hidden||solid.id===actor.id||!rect(solid)||!['solid','oneway'].includes(solid.collision))continue;
  if(solid.collision==='oneway'&&(delta.y<=0||delta.x!==0||actor.y+actor.h>solid.y+EPS))continue;
  const hit=sweepRect(actor,delta,solid);
  if(hit&&(!closest||hit.fraction<closest.fraction-EPS))closest=hit;
 }
 return closest;
}
function sideContact(before,player,itemBefore,item){
 if(vertical(player,item)&&(Math.abs(player.x+player.w-item.x)<=EPS||Math.abs(player.x-item.x-item.w)<=EPS))return {fraction:1,normal:{x:player.x<item.x?-1:1,y:0}};
 const hit=sweepRect(before,{x:player.x-before.x-item.x+itemBefore.x,y:player.y-before.y-item.y+itemBefore.y},itemBefore);
 return hit&&hit.normal.x?hit:null;
}

export function createPortableStones(room,{emit=()=>{}}={}){
 validatePortableStones(room);
 const extension=room?.smm2Mechanics?.portableStones;
 if(extension===undefined)return null;
 if(typeof emit!=='function')fail('Portable stones emit must be a function');
 const spec=clone(extension),bounds={width:room.map.width,height:room.map.height};
 const definitions=new Map(spec.stones.map(stone=>[stone.id,{tuning:stone,source:clone(room.map.objects.find(actor=>actor.id===stone.id))}]));
 const records=new Map();let held=null,frame=null,lastBefore=null,lastAfter=null,currentTick=0,previousRun=false,paused=false,opponentCarryTicks=new WeakMap();
 const ownsActor=actor=>definitions.has(typeof actor==='string'?actor:actor?.id);
 const diagnostic=(event,record,data={})=>emit('portable-stone',{event,roomId:room.roomId,actorId:record.item.id,tick:currentTick,...data});
 function publish(record){
  record.item.portableStone={phase:record.phase,held:record.phase==='held',thrown:record.thrown,holderId:record.holder?.id??null,tuningStatus:'explicit-author-configuration'};
  record.item.standable=record.phase==='free'&&live(record.item);
 }
 function initial(record){
  const source=definitions.get(record.item.id).source;
  Object.assign(record.item,clone(source),{kind:'portable-stone',type:'stone',vx:0,vy:0,age:0,dead:false,dying:false,taken:false,removed:false,grounded:false,support:null});
  Object.assign(record,{phase:'free',holder:null,thrown:false,motionThrown:false,lastTick:null,dx:0,dy:0,pickupAfter:-1,previous:pose(record.item),segments:[],attackSerial:0,claimed:new WeakSet()});publish(record);
 }
 /** Stable live identities. Repeated calls return the same stones, not new
  * physical actors; source objects and optional live-enemy arrays are untouched. */
 function seedItems(){
  for(const [id]of definitions)if(!records.has(id)){const record={item:{id}};records.set(id,record);initial(record);}
  return [...records.values()].map(record=>record.item);
 }
 seedItems();
 function recordFor(actor){
  const record=records.get(typeof actor==='string'?actor:actor?.id);
  if(record&&typeof actor!=='string'&&record.item!==actor)fail('Portable stone live ID must have one actor instance');
  if(record&&(!rect(record.item)||record.item.w!==16||record.item.h!==16||!Number.isFinite(record.item.vx)||!Number.isFinite(record.item.vy)))fail('Invalid live portable stone contact body or velocity');
  return record;
 }
 const heldBy=player=>held&&held.holder===player&&live(player)&&live(held.item)?held:null;
 function heldPose(record,player){
  const tuning=definitions.get(record.item.id).tuning,direction=player.facing<0?-1:1;
  return {x:direction>0?player.x+player.w+tuning.heldOffsetX:player.x-tuning.heldOffsetX-record.item.w,y:player.y+player.h+tuning.heldBottomOffset-record.item.h};
 }
 function syncHeld(record,player){
  const next=heldPose(record,player);record.item.x=next.x;record.item.y=next.y;
  Object.assign(record.item,{vx:0,vy:0,grounded:false,support:null});record.dx=record.dy=0;publish(record);
 }
 function canRelease(candidate,geometry){
  return rect(candidate)&&candidate.x>=0&&candidate.x+candidate.w<=bounds.width&&!geometry.some(solid=>solid.id!==candidate.id&&!solid.hidden&&solid.collision==='solid'&&rect(solid)&&overlap(candidate,solid));
 }
 function release(record,player,{drop=false,geometry=[],hurt=false}={}){
  const tuning=definitions.get(record.item.id).tuning,direction=player.facing<0?-1:1,next={...record.item,...heldPose(record,player)};
  if(drop)next.y=player.y+player.h-next.h;
  if(!hurt&&!canRelease(next,geometry)){diagnostic('release-blocked',record,{action:drop?'put-down':'throw'});return {action:'blocked',actorId:next.id};}
  if(hurt)next.x=Math.max(0,Math.min(bounds.width-next.w,next.x));
  Object.assign(record.item,{x:next.x,y:next.y,vx:drop||hurt?0:direction*tuning.throwSpeedX,vy:drop||hurt?0:tuning.throwSpeedY,grounded:false,support:null});
  record.phase='free';record.holder=null;record.thrown=!drop&&!hurt;record.motionThrown=false;record.pickupAfter=currentTick+tuning.releaseSafeFrames;
  record.dx=record.dy=0;record.previous=pose(record.item);record.segments=[];record.attackSerial++;record.claimed=new WeakSet();record.lastTick=currentTick;
  held=null;publish(record);const action=hurt?'hurt-release':drop?'put-down':'throw';diagnostic(action,record,{velocity:{x:record.item.vx,y:record.item.vy}});
  return {action,actorId:record.item.id};
 }
 function checkFrame(player,input,tick,geometry){
  if(!rect(player)||!plain(input)||!integer(tick,0,Number.MAX_SAFE_INTEGER)||!Array.isArray(geometry))fail('Invalid portable stone player frame');
 }
 /** No player displacement, jump or gravity is applied here. */
 function beforePlayer(player,input={},tick,geometry=[]){
  checkFrame(player,input,tick,geometry);
  if(paused||lastBefore!==null&&tick<=lastBefore)return {advanced:false,actions:[]};
  currentTick=tick;lastBefore=tick;
  const run=!!input.run,releaseEdge=previousRun&&!run;previousRun=run;
  frame={tick,player,before:pose(player),input:{...input},releaseEdge};
  const actions=[];
  if(held&&held.holder===player){
   if(!live(player))actions.push(release(held,player,{drop:true,hurt:true}));
   else{syncHeld(held,player);if(releaseEdge)actions.push(release(held,player,{drop:!!input.down,geometry}));}
  }
  return {advanced:true,actions};
 }
 function afterPlayer(player,input={},tick,geometry=[]){
  checkFrame(player,input,tick,geometry);
  if(paused||lastAfter!==null&&tick<=lastAfter)return {advanced:false,actions:[]};
  if(frame?.tick!==tick||frame.player!==player)fail('Portable stone afterPlayer needs matching beforePlayer');
  currentTick=tick;lastAfter=tick;const actions=[];
  if(heldBy(player))syncHeld(held,player);
  else if(live(player)&&frame.input.run&&!frame.releaseEdge&&!held){
   const candidates=[];
   for(const record of records.values()){
    if(record.phase!=='free'||!live(record.item)||tick<=record.pickupAfter)continue;
    const prior=record.lastTick===tick?record.previous:pose(record.item),contact=sideContact(frame.before,player,prior,record.item);
    if(contact)candidates.push({record,contact});
   }
   candidates.sort((a,b)=>a.contact.fraction-b.contact.fraction||a.record.item.id.localeCompare(b.record.item.id));
   if(candidates.length){
    const {record,contact}=candidates[0];held=record;record.phase='held';record.holder=player;record.thrown=false;record.motionThrown=false;record.segments=[];record.claimed=new WeakSet();
    // Spending this tick also prevents a later native item pass from dropping
    // the newly held stone or applying its gravity a second time.
    record.lastTick=tick;syncHeld(record,player);actions.push({action:'pickup',actorId:record.item.id,contact:clone(contact)});diagnostic('pickup',record,{contact:clone(contact)});
   }
  }
  return {advanced:true,actions};
 }
 function heldMotion(player){const record=heldBy(player);return record?clone(definitions.get(record.item.id).tuning.carryMotion):null;}
 function geometry(base=[],items=seedItems(),{excludeActor}={}){
  if(!Array.isArray(base)||!Array.isArray(items))fail('Invalid portable stone geometry list');
  const excludeId=typeof excludeActor==='string'?excludeActor:excludeActor?.id,result=base.filter(solid=>!solid.portableStoneSolid&&!ownsActor(solid));
  const seen=new Set();
  for(const item of items){
   if(!ownsActor(item)||item.id===excludeId)continue;
   if(seen.has(item.id))fail('Duplicate live portable stone body');seen.add(item.id);
   const record=recordFor(item);
   if(!record||record.phase!=='free'||!live(item))continue;
   result.push({id:item.id,...body(item),collision:'solid',material:'portable-stone',portableStoneSolid:true,previousTop:record.previous.y,dx:paused?0:record.dx,dy:paused?0:record.dy});
  }
  return result;
 }
 /** Genuine swept stone motion. Native support carry is applied once to the
  * stone, never to Mario; the projected dx/dy then lets Mario's motor carry him. */
 function stepItem(item,{tick,geometry:base=[],terrain,afterActor}={}){
  if(!ownsActor(item))return {handled:false,advanced:false};
  if(!integer(tick,0,Number.MAX_SAFE_INTEGER)||!Array.isArray(base)||afterActor!==undefined&&typeof afterActor!=='function')fail('Invalid portable stone item frame');
  const record=recordFor(item),tuning=definitions.get(item.id).tuning;
  if(paused||!live(item)||record.lastTick!==null&&tick<=record.lastTick)return {handled:true,advanced:false,held:record.phase==='held'};
  currentTick=tick;record.lastTick=tick;record.previous=pose(item);record.segments=[];record.dx=record.dy=0;record.motionThrown=record.thrown;
  if(record.phase==='held'){if(live(record.holder))syncHeld(record,record.holder);return {handled:true,advanced:false,held:true};}
  const before=pose(item),solids=base.filter(solid=>solid.id!==item.id&&!terrain?.ownsGeometry?.(solid)),contacts=[];
  function move(delta){
   if(!delta.x&&!delta.y)return null;
   const start=body(item),rectangle=rectangleSweep(item,delta,solids),shaped=terrain?.sweep?.(item,delta,{tick,excludeIds:[item.id]});
   if(shaped&&(!finite(shaped.fraction,0,1)||!shaped.normal||!finite(shaped.normal.x,-1,1)||!finite(shaped.normal.y,-1,1)||!safeId(shaped.solidId)))fail('Invalid portable stone shaped terrain sweep');
   const hit=shaped&&(!rectangle||shaped.fraction<rectangle.fraction-EPS)?shaped:rectangle;
   item.x+=delta.x*(hit?.fraction??1);item.y+=delta.y*(hit?.fraction??1);
   // Room sides are actual walls. The bottom is a pit, never a made-up floor.
   if(item.x<0){item.x=0;item.vx=0;}else if(item.x+item.w>bounds.width){item.x=bounds.width-item.w;item.vx=0;}
   if(hit){
    contacts.push(clone(hit));if(Math.abs(hit.normal.x)>EPS)item.vx=0;
    if(Math.abs(hit.normal.y)>EPS)item.vy=0;
    if(hit.normal.y<-EPS){item.grounded=true;item.support=hit.solidId;}
   }
   if(Math.abs(item.x-start.x)>EPS||Math.abs(item.y-start.y)>EPS)record.segments.push({before:start,after:body(item)});
   return hit;
  }
  item.grounded=false;item.support=null;
  if(before.grounded&&before.support){const support=solids.find(solid=>solid.id===before.support);if(support)move({x:support.dx??0,y:support.dy??0});}
  item.vy=Math.min(tuning.maxFallSpeed,item.vy+tuning.gravity);const incomingVelocity={x:item.vx,y:item.vy};
  move({x:item.vx,y:0});move({x:0,y:item.vy});
  terrain?.afterActor?.(item,before,{tick,input:{},geometry:base,incomingVelocity});
  afterActor?.(item,before,{kind:'item',tick,input:{},geometry:base,incomingVelocity});
  if(item.grounded&&item.vx===0&&item.vy===0)record.thrown=false;
  if(item.y>=bounds.height){item.dead=true;item.grounded=false;item.support=null;record.thrown=false;diagnostic('left-room',record);}
  record.dx=item.x-before.x;record.dy=item.y-before.y;item.age=(item.age??0)+1;publish(record);
  return {handled:true,advanced:true,held:false,dx:record.dx,dy:record.dy,contacts};
 }
 /** Only observed Goomba defeat eligibility. No damage or rewards are applied.
  * previous accepts {actorBefore,itemBefore}; absent itemBefore uses the actual
  * recorded path this tick. A claim is returned once per target/release episode.
  * Passing a prior body alone means the opponent's prior body. */
 function opponentContact(actor,item,previous={}){
  const neutral={eligible:false};
  if(paused||!ownsActor(item)||!live(item)||!live(actor)||!rect(actor)||!rect(item))return neutral;
  const record=recordFor(item);
  if(record.phase!=='free'||record.lastTick!==currentTick||record.claimed.has(actor))return neutral;
  const type=String(actor.type??actor.smm2EnemyKind??actor.kind??'').replace(/^(enemy-|marker-)/,'').toLowerCase();
  if(type!=='goomba')return neutral;
  const actorBefore=rect(previous)?previous:previous.actorBefore??actor;
  if(!rect(actorBefore))fail('Invalid previous portable stone opponent body');
  let paths=record.segments;
  if(previous.itemBefore!==undefined){if(!rect(previous.itemBefore))fail('Invalid previous portable stone body');paths=[{before:previous.itemBefore,after:body(item)}];}
  for(let index=0;index<paths.length;index++){
   const path=paths[index],fractionStart=index/paths.length,fractionEnd=(index+1)/paths.length,enemyStart={...actorBefore,x:actorBefore.x+(actor.x-actorBefore.x)*fractionStart,y:actorBefore.y+(actor.y-actorBefore.y)*fractionStart};
   const dx=path.after.x-path.before.x,dy=path.after.y-path.before.y;
   if(Math.abs(dx)<=EPS&&Math.abs(dy)<=EPS)continue;
   const contact=sweepRect(path.before,{x:dx-(actor.x-actorBefore.x)*(fractionEnd-fractionStart),y:dy-(actor.y-actorBefore.y)*(fractionEnd-fractionStart)},enemyStart);
   if(!contact)continue;
   // The original G1 stays alive while the rising Stone top lifts its feet.
   // A thrown body is therefore not an unconditional attack on every face.
   const falling=dy>EPS&&contact.normal.y<-EPS,thrown=record.motionThrown&&contact.normal.y<=0;
   if(!falling&&!thrown)continue;
   record.claimed.add(actor);const tuning=definitions.get(item.id).tuning;
   return {eligible:true,action:'defeat',cause:falling?'stone-fall':'stone-throw',actorId:actor.id,stoneId:item.id,tick:currentTick,attackSerial:record.attackSerial,contact:clone(contact),...(tuning.points===undefined?{}:{points:tuning.points})};
  }
  return neutral;
 }
 /** The observed Goomba can stand on the same live rising Stone as Mario.
  * This transports an already-established top rider once. Acquiring a new
  * rider still belongs to the host's genuine previous-top crossing test.
  * No general NPC weight, immunity or unobserved enemy support is inferred. */
 function carryOpponent(actor,{tick=currentTick,previous=actor,resolveDisplacement}={}){
  const neutral={carried:false};
  if(!integer(tick,0,Number.MAX_SAFE_INTEGER)||resolveDisplacement!==undefined&&typeof resolveDisplacement!=='function')fail('Invalid portable stone opponent transport');
  if(paused||!live(actor)||!rect(actor)||!rect(previous)||opponentCarryTicks.get(actor)===tick)return neutral;
  const type=String(actor.type??actor.smm2EnemyKind??'').replace(/^(enemy-|marker-)/,'').toLowerCase();
  if(type!=='goomba'||actor.shell||!previous.grounded||!previous.support)return neutral;
  const record=records.get(previous.support);
  if(!record||record.phase!=='free'||!live(record.item)||record.lastTick!==tick||Math.abs(previous.y+previous.h-record.previous.y)>1.01||!horizontal(previous,record.previous))return neutral;
  opponentCarryTicks.set(actor,tick);
  const delta={x:record.dx,y:record.dy},resolved=resolveDisplacement?resolveDisplacement(actor,delta,{excludeIds:[record.item.id]}):{dx:delta.x,dy:delta.y};
  if(!resolved||!finite(resolved.dx,-Math.abs(delta.x),Math.abs(delta.x))||!finite(resolved.dy,-Math.abs(delta.y),Math.abs(delta.y))||delta.x&&resolved.dx*delta.x<-EPS||delta.y&&resolved.dy*delta.y<-EPS)fail('Invalid portable stone resolved transport');
  actor.x+=resolved.dx;actor.y+=resolved.dy;
  if(resolved.blocked||Math.abs(resolved.dx-delta.x)>EPS||Math.abs(resolved.dy-delta.y)>EPS){actor.support=null;actor.grounded=false;}
  return {carried:true,supportId:record.item.id,dx:resolved.dx,dy:resolved.dy,blocked:!!resolved.blocked};
 }
 /** Qualification only. The host still requires real goal contact and owns
  * finish/reward. Unrelated goals are not gated by this local clear condition. */
 function readyForGoal(goalId,player){return !spec.clearCondition||goalId!==spec.clearCondition.goalId||!!heldBy(player);}
 function onHurt(player,{tick=currentTick}={}){
  if(!integer(tick,0,Number.MAX_SAFE_INTEGER))fail('Invalid portable stone hurt tick');
  if(paused||!held||held.holder!==player)return null;
  if(!rect(player))fail('Invalid portable stone hurt player');currentTick=tick;
  return release(held,player,{drop:true,hurt:true});
 }
 function reset(){
  held=frame=null;lastBefore=lastAfter=null;currentTick=0;previousRun=false;paused=false;opponentCarryTicks=new WeakMap();
  for(const record of records.values())initial(record);
 }
 function pause(value=true){if(typeof value!=='boolean')fail('Invalid portable stone pause');paused=value;if(value)previousRun=false;return paused;}
 function view(player=null){return {version:1,tick:currentTick,paused,clearCondition:spec.clearCondition?clone(spec.clearCondition):null,stones:[...records.values()].map(record=>({id:record.item.id,kind:'portable-stone',body:record.phase==='held'&&record.holder===player?{...pose(record.item),...heldPose(record,player)}:pose(record.item),dead:!!record.item.dead,dx:paused?0:record.dx,dy:paused?0:record.dy,state:clone(record.item.portableStone)}))};}
 return Object.freeze({ownsActor,seedItems,beforePlayer,afterPlayer,heldMotion,geometry,stepItem,opponentContact,carryOpponent,readyForGoal,onHurt,reset,pause,view});
}
