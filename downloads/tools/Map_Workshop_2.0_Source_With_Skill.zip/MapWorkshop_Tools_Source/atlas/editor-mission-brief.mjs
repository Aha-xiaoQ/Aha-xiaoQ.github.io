import {sourceKey,sourcePixels} from './source-art.mjs';

// Optional authored pre-course brief. Reward is reference information, never
// an automatic addition to the player's coins or campaign state.
export function missionBrief(room){
 const q=room?.missionBrief;if(q===undefined)return null;
 if(!q||q.version!==1)throw Error('关前委托说明版本无效');
 for(const [key,max]of [['title',80],['description',240],['client',80]])if(typeof q[key]!=='string'||!q[key].trim()||q[key].length>max)throw Error('委托'+key+'文字无效');
 if(q.rewardPresentation!==undefined&&q.rewardPresentation!=='reference-already-claimed')throw Error('未知委托报酬参考状态');
 if(q.description.split('\n').length>5)throw Error('委托说明最多五段');
 for(const [key,min,max]of [['number',1,999],['difficulty',1,4],['rewardCoins',0,99999]]){if(['number','rewardCoins'].includes(key)&&q[key]===null)continue;if(!Number.isInteger(q[key])||q[key]<min||q[key]>max)throw Error('委托'+key+'数值无效');}
 return q;
}
export function validateMissionBriefRoom(room){missionBrief(room);}

function round(c,x,y,w,h,r,fill){c.fillStyle=fill;c.beginPath();c.moveTo(x+r,y);c.lineTo(x+w-r,y);c.quadraticCurveTo(x+w,y,x+w,y+r);c.lineTo(x+w,y+h-r);c.quadraticCurveTo(x+w,y+h,x+w-r,y+h);c.lineTo(x+r,y+h);c.quadraticCurveTo(x,y+h,x,y+h-r);c.lineTo(x,y+r);c.quadraticCurveTo(x,y,x+r,y);c.closePath();c.fill();}
function star(c,x,y,r,filled){c.beginPath();for(let n=0;n<10;n++){const a=-Math.PI/2+n*Math.PI/5,k=n%2?r*.44:r;const px=x+Math.cos(a)*k,py=y+Math.sin(a)*k;n?c.lineTo(px,py):c.moveTo(px,py);}c.closePath();c.lineWidth=2;c.strokeStyle='#382c1d';if(filled){c.fillStyle='#382c1d';c.fill();}else c.stroke();}
function lines(c,text,max){const out=[];for(const paragraph of text.split('\n')){let line='';for(const letter of paragraph){if(line&&c.measureText(line+letter).width>max){out.push(line);line=letter;}else line+=letter;}out.push(line);}return out;}
function constructionBackdrop(c){
 c.fillStyle='#7b978f';c.fillRect(0,0,960,540);c.fillStyle='#d7d6be';c.fillRect(0,0,960,72);c.fillStyle='#a7aaa1';for(let x=0;x<960;x+=112){c.fillRect(x,76,108,32);c.fillRect(x+30,112,76,46);}c.fillStyle='#628680';c.fillRect(0,176,960,144);c.fillStyle='#a4b478';c.fillRect(0,324,960,216);c.fillStyle='#84704d';c.fillRect(0,404,960,24);for(const x of [40,912]){c.fillRect(x,122,14,300);c.fillRect(x-30,172,74,10);c.fillRect(x-30,252,74,10);}
 // Existing native Toad sprite with a simple self-drawn construction helmet.
 const p=sourcePixels(sourceKey('Scenery','Toad'));for(let y=0;y<p.h;y++)for(let x=0;x<p.w;x++){const rgba=p.pixels[y*p.w+x];if(!rgba[3])continue;c.fillStyle='rgb('+rgba.slice(0,3).join(',')+')';c.fillRect(25+x*3,274+y*3,3,3);}c.fillStyle='#dfb519';c.fillRect(26,270,45,11);c.fillRect(35,262,27,11);
 c.fillStyle='#0008';c.fillRect(0,0,960,540);
}
/** Shared actual Canvas renderer; the comparison PNG uses this same function. */
export function drawMissionBrief(c,q,{fontFamily="system-ui, sans-serif"}={}){
 c.save();c.scale(c.canvas.width/960,c.canvas.height/540);constructionBackdrop(c);
 round(c,85,23,790,491,10,'#ffd20b');round(c,92,76,776,430,3,'#fff9df');
 c.fillStyle='#825321';c.fillRect(93,80,775,43);if(q.number!==null){c.fillStyle='#fff';c.fillRect(101,84,48,34);c.fillStyle='#342f25';c.font='bold 30px '+fontFamily;c.textAlign='center';c.textBaseline='middle';c.fillText(String(q.number),125,102);}
 c.fillStyle='#fff';c.font='25px '+fontFamily;c.fillText(q.title,508,102);
 c.fillStyle='#f35643';c.beginPath();c.moveTo(112,40);c.lineTo(133,48);c.lineTo(112,56);c.closePath();c.fill();c.strokeStyle='#fff';c.lineWidth=2;c.stroke();c.beginPath();c.moveTo(109,37);c.lineTo(109,64);c.stroke();
 round(c,824,33,40,39,5,'#141411');c.strokeStyle='#fff';c.lineWidth=5;c.beginPath();c.moveTo(834,42);c.lineTo(854,62);c.moveTo(854,42);c.lineTo(834,62);c.stroke();
 round(c,103,132,754,176,8,'#e4dac1');c.fillStyle='#342c20';let font=23,wrapped;do{c.font=font+'px '+fontFamily;wrapped=lines(c,q.description,674);if(wrapped.length*(font+6)<=128)break;font--;}while(font>9);c.textAlign='left';c.textBaseline='top';wrapped.forEach((line,i)=>c.fillText(line,165,148+i*(font+6)));c.font='21px '+fontFamily;c.textAlign='right';c.fillText(q.client,801,276);const avatar=sourcePixels(sourceKey('Scenery','Toad'));c.fillStyle='#f7f2e5';c.beginPath();c.ellipse(827,286,15,16,0,0,Math.PI*2);c.fill();for(let y=0;y<avatar.h;y++)for(let x=0;x<avatar.w;x++){const p=avatar.pixels[y*avatar.w+x];if(!p[3])continue;const grey=Math.round((p[0]+p[1]+p[2])/3);c.fillStyle='rgb('+grey+','+grey+','+grey+')';c.fillRect(819+x,274+y,1,1);}
 c.font='18px '+fontFamily;c.textAlign='left';c.textBaseline='middle';c.fillText('难度',252,348);for(let n=0;n<4;n++)star(c,318+n*24,348,10,n<q.difficulty);c.fillText('报酬',489,348);
 if(q.rewardCoins===null){c.fillStyle='#342c20';c.font='23px '+fontFamily;c.fillText('—',570,348);}else{const paid=q.rewardPresentation==='reference-already-claimed';if(paid){round(c,556,332,95,32,3,'#e5dfc9');c.globalAlpha=.38;}c.fillStyle='#ddbf54';c.beginPath();c.ellipse(570,348,9,11,0,0,Math.PI*2);c.fill();c.strokeStyle='#8e7323';c.lineWidth=2;c.stroke();c.beginPath();c.moveTo(570,342);c.lineTo(570,354);c.stroke();c.fillStyle='#342c20';c.font='23px '+fontFamily;c.fillText(String(q.rewardCoins),588,348);c.globalAlpha=1;}
 round(c,359,436,240,65,12,'#f5ce00');c.fillStyle='#ee5937';for(const [x,y,a]of [[359,436,0],[599,436,1],[599,501,2],[359,501,3]]){c.save();c.translate(x,y);c.rotate(a*Math.PI/2);c.beginPath();c.moveTo(0,0);c.lineTo(17,0);c.lineTo(0,17);c.closePath();c.fill();c.restore();}c.fillStyle='#25220f';c.font='25px '+fontFamily;c.textAlign='center';c.fillText('开始',479,469);c.restore();
}

export function mountMissionCard({host,brief,onStart,onClose}){
 const card=document.createElement('section');card.className='play-mission-card';card.setAttribute('role','region');card.setAttribute('aria-label','关前委托');card.hidden=true;
 const canvas=document.createElement('canvas');canvas.width=960;canvas.height=540;canvas.setAttribute('aria-hidden','true');canvas.className='play-mission-canvas';
 const words=document.createElement('div');words.className='mission-accessible-copy';words.textContent=(brief.number===null?'':brief.number+' · ')+brief.title+'。'+brief.description+' 委托人：'+brief.client+'。难度'+brief.difficulty+' / 4。'+(brief.rewardCoins===null?'原任务没有金币报酬栏。':'原作报酬'+brief.rewardCoins+'金币，仅作参考信息。');
 const start=document.createElement('button');start.type='button';start.className='mission-start';start.textContent='开始';start.setAttribute('aria-label','开始委托关卡');start.onclick=onStart;
 const close=document.createElement('button');close.type='button';close.className='mission-close';close.textContent='关闭';close.setAttribute('aria-label','关闭委托卡');close.onclick=onClose;
 card.append(canvas,words,start,close);host.append(card);drawMissionBrief(canvas.getContext('2d'),brief);
 return {card,canvas,start,close,show(){card.hidden=false;start.focus();},hide(){card.hidden=true;},destroy(){card.remove();}};
}

export function mountMissionBriefEditor({parent,room,change,report=()=>{}}){
 const panel=document.createElement('details');parent.append(panel);const title=document.createElement('summary');title.textContent='关前委托与规则教学';panel.append(title);
 const fields=new Map();for(const [key,label,type]of [['number','编号','number'],['title','委托名称','text'],['description','只教规则的委托说明','textarea'],['client','委托人','text'],['difficulty','难度（1–4）','number'],['rewardCoins','参考报酬金币（不加入游戏分数）','number']]){const l=document.createElement('label'),f=document.createElement(type==='textarea'?'textarea':'input');l.textContent=label;if(type!=='textarea')f.type=type;f.setAttribute('data-mission-field',key);l.append(f);panel.append(l);fields.set(key,f);}
 const apply=document.createElement('button'),remove=document.createElement('button');apply.type=remove.type='button';apply.textContent='应用本区域的关前委托';remove.textContent='移除关前委托';panel.append(apply,remove);
 apply.onclick=()=>{try{const q={version:1};for(const [key,f]of fields)q[key]=f.type==='number'?(['number','rewardCoins'].includes(key)&&String(f.value).trim()===''?null:Number(f.value)):f.value;missionBrief({missionBrief:q});change(()=>{room().missionBrief=q;});refresh();}catch(e){report(e.message);}};
 remove.onclick=()=>{change(()=>{delete room().missionBrief;});refresh();};
 function refresh(){const q=room().missionBrief||{number:1,title:room().map.title,description:'',client:'地图作者',difficulty:1,rewardCoins:0};for(const [key,f]of fields)f.value=q[key]??'';remove.disabled=!room().missionBrief;}
 refresh();return {refresh};
}
