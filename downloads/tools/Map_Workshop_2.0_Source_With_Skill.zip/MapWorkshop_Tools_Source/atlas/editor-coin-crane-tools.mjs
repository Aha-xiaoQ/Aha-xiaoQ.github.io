import {clone,uid,validate} from './editor-model.mjs';
import {COIN_CRANE_DEFAULTS} from './editor-coin-crane.mjs';
const id=()=>('crane-'+uid()).slice(0,72);
function edit(room,fn){const draft=clone(room),doc={format:'xiaoq-map-project',version:1,id:'coin-crane-edit',title:'Original coin crane',rooms:[draft]};const result=fn(draft);validate(doc);Object.assign(room,draft);return result;}
export function addCoinCrane(room,values={}){return edit(room,r=>{
 const {coinX=Math.min(r.map.width-80,208),coinY=Math.min(r.map.height-48,176)-7,buttonX=48,buttonY=r.map.height-80,coinId,buttonId,...authored}=values;
 const coin=coinId?r.map.objects.find(o=>o.id===coinId):{id:id(),kind:'coin',x:coinX,y:coinY,w:8,h:14};if(!coin)throw Error('请选择实体粉币');
 const button=buttonId?r.map.geometry.find(g=>g.id===buttonId):{id:id(),x:buttonX,y:buttonY,w:16,h:16,material:'stone',collision:'solid'};if(!button)throw Error('请选择按钮实体');
 if(!coinId){r.map.objects.push(coin);r.smm2Mechanics??={version:1};r.smm2Mechanics.pinkCoins??=[];r.smm2Mechanics.pinkCoins.push({id:coin.id});}if(!buttonId)r.map.geometry.push(button);
 const cx=coin.x+coin.w/2,cy=coin.y+coin.h/2;r.contraptions??={version:1};r.contraptions.coinCranes??=[];
 const q={id:id(),coinId:coin.id,buttonId:button.id,minX:Math.max(28,cx-80),maxX:Math.min(r.map.width-28,cx+80),restY:Math.max(40,cy-96),grabY:cy,deliveryX:80,deliveryY:Math.max(40,cy-16),...COIN_CRANE_DEFAULTS};delete q.gravity;delete q.maxFallSpeed;Object.assign(q,clone(authored));r.contraptions.coinCranes.push(q);return q.id;
});}
export function addPaidCoinCrane(room,values={}){const {buttonX=48,buttonY=room.map.height-80}=values;return addCoinCrane(room,{...values,payment:values.payment??{price:1,entryBonus:10,slotId:id(),slot:{x:buttonX+32,y:buttonY+24,w:16,h:16}}});}
const objectIds=q=>[q.coinId,...(q.payloads||[]).map(p=>p.id)];
const geometryIds=q=>[q.buttonId,...(q.glassIds||[]),...(q.searchlight?[q.searchlight.buttonId]:[])];
const machineLamps=(room,ids)=>clone((room.smm2Mechanics?.lighting?.sweepingLamps||[]).filter(q=>ids.has(q.enabledWhenMachine)));
function appendMachineLamps(room,lamps,idMap,dx,dy,style){if(!lamps?.length)return;room.smm2Mechanics??={version:1};room.smm2Mechanics.lighting??={darkness:style?.darkness??.94,playerRadius:style?.playerRadius??56,softness:style?.softness??.25,sources:[]};for(const lamp of lamps){const machine=idMap.get(lamp.enabledWhenMachine);if(!machine)throw Error('Copied cabinet lamp is missing its real machine');const lampId=idMap.get(lamp.id)||id();idMap.set(lamp.id,lampId);(room.smm2Mechanics.lighting.sweepingLamps??=[]).push({...clone(lamp),id:lampId,enabledWhenMachine:machine,x:lamp.x+dx,y:lamp.y+dy});}}
function capturePayloadBindings(room,ids){return {markers:clone((room.markers||[]).filter(q=>ids.has(q.id))),semantics:clone((room.semantics||[]).filter(q=>ids.has(q.id))),enemySkins:clone(Object.fromEntries(Object.entries(room.enemySkins||{}).filter(([id])=>ids.has(id)))),coinValues:clone(Object.fromEntries(Object.entries(room.marioModules?.coinValues||{}).filter(([id])=>ids.has(id)))),enemyVariants:clone(Object.fromEntries(Object.entries(room.marioModules?.enemyVariants||{}).filter(([id])=>ids.has(id))))};}
function appendPayloadBindings(room,binding,idMap,dx,dy){
 for(const key of ['markers','semantics'])for(const original of binding?.[key]||[]){const mapped=idMap.get(original.id);if(!mapped||room[key]?.some(q=>q.id===mapped))continue;const q={...clone(original),id:mapped};if(Number.isFinite(q.x))q.x+=dx;if(Number.isFinite(q.y))q.y+=dy;(room[key]??=[]).push(q);}
 for(const [old,value]of Object.entries(binding?.enemySkins||{})){const mapped=idMap.get(old);if(mapped)(room.enemySkins??={})[mapped]=value;}
 for(const key of ['coinValues','enemyVariants'])for(const [old,value]of Object.entries(binding?.[key]||{})){const mapped=idMap.get(old);if(!mapped)continue;room.marioModules??={version:1,itemSources:[],noteBlocks:[],oneWayWalls:[],enemyVariants:{}};room.marioModules[key]??={};room.marioModules[key][mapped]=clone(value);}
}
function removePayloadBindings(room,ids){for(const key of ['markers','semantics'])if(room[key])room[key]=room[key].filter(q=>!ids.has(q.id));for(const key of ['coinValues','enemyVariants'])if(room.marioModules?.[key])for(const id of ids)delete room.marioModules[key][id];if(room.enemySkins)for(const id of ids)delete room.enemySkins[id];}
function shiftSpec(c,dx,dy,idMap){
 c.id=idMap.get(c.id);c.coinId=idMap.get(c.coinId);c.buttonId=idMap.get(c.buttonId);
 if(c.searchlight)c.searchlight.buttonId=idMap.get(c.searchlight.buttonId);
 if(c.glassIds)c.glassIds=c.glassIds.map(old=>idMap.get(old));
 for(const k of ['minX','maxX','deliveryX','initialX'])if(c[k]!==undefined)c[k]+=dx;
 for(const k of ['restY','grabY','deliveryY'])c[k]+=dy;
 if(c.payment){c.payment.slotId=idMap.get(c.payment.slotId);c.payment.slot.x+=dx;c.payment.slot.y+=dy;}
 if(c.cabinet){c.cabinet.x+=dx;c.cabinet.y+=dy;}
 for(const p of c.payloads||[]){p.id=idMap.get(p.id);if(p.motion){p.motion.minX+=dx;p.motion.maxX+=dx;p.motion.y+=dy;}}
 return c;
}
export function updateCoinCrane(room,recordId,values){return edit(room,r=>{
 const q=r.contraptions?.coinCranes?.find(q=>q.id===recordId);if(!q)throw Error('请选择抓币机');const {buttonX,buttonY,...fields}=values,oldGrab=q.grabY;
 Object.assign(q,clone(fields),{id:recordId});for(const key of ['payment','payloads','cabinet','searchlight'])if(Object.hasOwn(fields,key)&&fields[key]===undefined)delete q[key];
 if(values.grabY!==undefined){const coin=r.map.objects.find(o=>o.id===q.coinId);if(coin)coin.y=q.grabY-coin.h/2;for(const p of q.payloads||[]){const body=r.map.objects.find(o=>o.id===p.id);if(body&&['large-coin','live-goomba','live-koopa'].includes(p.kind)){const dy=q.grabY-oldGrab;body.y+=dy;for(const marker of r.markers.filter(m=>m.id===p.id))marker.y+=dy;}else if(body&&p.kind!=='bomb')body.y=q.grabY-body.h/2;else if(body&&p.motion&&Math.abs(p.motion.y-oldGrab)<.01){p.motion.y=q.grabY;body.y=q.grabY-body.h/2;}}}
 const b=r.map.geometry.find(g=>g.id===q.buttonId);if(buttonX!==undefined)b.x=buttonX;if(buttonY!==undefined)b.y=buttonY;
});}
export function removeCoinCrane(room,recordId,{removeBodies=true}={}){return edit(room,r=>{
 const q=r.contraptions?.coinCranes?.find(q=>q.id===recordId);if(!q)throw Error('请选择抓币机');r.contraptions.coinCranes=r.contraptions.coinCranes.filter(a=>a.id!==recordId);
 if(removeBodies){r.map.geometry=r.map.geometry.filter(g=>!geometryIds(q).includes(g.id));r.map.objects=r.map.objects.filter(o=>!objectIds(q).includes(o.id));removePayloadBindings(r,new Set(objectIds(q)));if(r.smm2Mechanics?.pinkCoins)r.smm2Mechanics.pinkCoins=r.smm2Mechanics.pinkCoins.filter(p=>p.id!==q.coinId);}
 if(r.smm2Mechanics?.lighting)r.smm2Mechanics.lighting.sources=r.smm2Mechanics.lighting.sources.filter(s=>s.targetId!==recordId&&s.targetId!==q.payment?.slotId&&(!removeBodies||![...objectIds(q),...geometryIds(q)].includes(s.targetId)));
 if(r.smm2Mechanics?.lighting?.sweepingLamps)r.smm2Mechanics.lighting.sweepingLamps=r.smm2Mechanics.lighting.sweepingLamps.filter(lamp=>lamp.enabledWhenMachine!==recordId);
});}
export function cloneCoinCrane(room,recordId,{dx=16,dy=0}={}){return edit(room,r=>{
 const q=r.contraptions?.coinCranes?.find(q=>q.id===recordId);if(!q||!Number.isFinite(dx)||!Number.isFinite(dy))throw Error('请选择抓币机并填写复制位移');
 const nativeBindings=capturePayloadBindings(r,new Set(objectIds(q))),lamps=machineLamps(r,new Set([q.id])),ids=new Map([[q.id,id()]]);if(q.payment)ids.set(q.payment.slotId,id());
 for(const [wanted,list]of [[objectIds(q),r.map.objects],[geometryIds(q),r.map.geometry]])for(const oldId of wanted){const body=clone(list.find(o=>o.id===oldId)),newId=id();ids.set(oldId,newId);list.push({...body,id:newId,x:body.x+dx,y:body.y+dy});}
 const c=shiftSpec(clone(q),dx,dy,ids);r.contraptions.coinCranes.push(c);r.smm2Mechanics.pinkCoins.push({id:c.coinId});appendPayloadBindings(r,nativeBindings,ids,dx,dy);
 appendMachineLamps(r,lamps,ids,dx,dy);
 if(r.smm2Mechanics?.lighting)r.smm2Mechanics.lighting.sources.push(...r.smm2Mechanics.lighting.sources.filter(s=>ids.has(s.targetId)).map(s=>({...s,targetId:ids.get(s.targetId)})));return c.id;
});}
/** Selecting any physical payload/button/glass copies the complete machine graph. */
export function captureCoinCraneBindings(room,ids){
 const rows=(room.contraptions?.coinCranes||[]).filter(q=>[q.id,q.payment?.slotId,...objectIds(q),...geometryIds(q)].some(id=>ids.has(id))).map(q=>({spec:clone(q),coin:clone(room.map.objects.find(o=>o.id===q.coinId)),button:clone(room.map.geometry.find(g=>g.id===q.buttonId)),glass:(q.glassIds||[]).map(id=>clone(room.map.geometry.find(g=>g.id===id))),searchlightButton:q.searchlight?clone(room.map.geometry.find(g=>g.id===q.searchlight.buttonId)):null,payloadBodies:(q.payloads||[]).map(p=>clone(room.map.objects.find(o=>o.id===p.id))),nativeBindings:capturePayloadBindings(room,new Set(objectIds(q)))}));
 const captured=new Set(rows.flatMap(q=>[q.spec.id,q.spec.payment?.slotId,q.coin.id,q.button.id,q.searchlightButton?.id,...q.glass.map(g=>g.id),...q.payloadBodies.map(o=>o.id)])),lighting=room.smm2Mechanics?.lighting;return {rows,lighting:clone((lighting?.sources||[]).filter(s=>captured.has(s.targetId))),machineLamps:machineLamps(room,new Set(rows.map(q=>q.spec.id))),lightingStyle:lighting?{darkness:lighting.darkness,playerRadius:lighting.playerRadius,softness:lighting.softness??.25}:null};
}
export function appendCopiedCoinCraneBindings(room,binding,idMap,{dx=0,dy=0}={}){
 if(!binding?.rows?.length)return;room.contraptions??={version:1};room.contraptions.coinCranes??=[];room.smm2Mechanics??={version:1};room.smm2Mechanics.pinkCoins??=[];
 for(const row of binding.rows){for(const [body,list]of [[row.coin,room.map.objects],...(row.payloadBodies||[]).map(o=>[o,room.map.objects]),[row.button,room.map.geometry],...(row.glass||[]).map(g=>[g,room.map.geometry]),...(row.searchlightButton?[[row.searchlightButton,room.map.geometry]]:[])])if(!idMap.has(body.id)){const c={...clone(body),id:id(),x:body.x+dx,y:body.y+dy};idMap.set(body.id,c.id);list.push(c);}
  idMap.set(row.spec.id,id());if(row.spec.payment)idMap.set(row.spec.payment.slotId,id());const c=shiftSpec(clone(row.spec),dx,dy,idMap);room.contraptions.coinCranes.push(c);if(!room.smm2Mechanics.pinkCoins.some(p=>p.id===c.coinId))room.smm2Mechanics.pinkCoins.push({id:c.coinId});appendPayloadBindings(room,row.nativeBindings,idMap,dx,dy);
 }
 appendMachineLamps(room,binding.machineLamps,idMap,dx,dy,binding.lightingStyle);
 if(room.smm2Mechanics.lighting){const sources=room.smm2Mechanics.lighting.sources;for(const source of binding.lighting||[]){const targetId=idMap.get(source.targetId);if(targetId&&!sources.some(s=>s.targetId===targetId))sources.push({...source,targetId});}}
}
export function mountCoinCraneTools({parent,room,change,report=()=>{}}){
 const panel=document.createElement('details');panel.id='coin-crane-tools';parent.append(panel);const node=(tag,text,body=panel)=>{const n=document.createElement(tag);n.textContent=text;body.append(n);return n;};node('summary','原创抓币机');node('p','跳起顶蓝色箭头按钮，锁住横移位置后下抓。抓中会把同一枚实体粉币送到出口；失手可重试。付费款可选择靠近投币槽投入1币或按上投币；未用次数跨重入保留。入场赠币可设0或10。普通／大金币须实际拾取；活栗宝宝和龟送出后自然下落行走，旧布偶返回柜内，炸弹接触使本次空回。数值和流程为原创。').className='small';let selected='';
 const attempt=fn=>{try{change(fn);refresh();}catch(e){report(e.message);refresh();}};
 const button=(title,fn)=>{const b=node('button',title);b.type='button';b.onclick=fn;return b;};button('+ 放置原创抓币机',()=>attempt(()=>{selected=addCoinCrane(room());}));button('+ 放置付费抓奖机（1币）',()=>attempt(()=>{selected=addPaidCoinCrane(room());}));
 const select=node('select',''),form=node('form',''),inputs=new Map();select.onchange=()=>{selected=select.value;refresh();};button('复制抓币机和实体币／按钮',()=>attempt(()=>{selected=cloneCoinCrane(room(),selected);}));button('删除抓币机和实体币／按钮',()=>attempt(()=>removeCoinCrane(room(),selected)));
 const labels={coinId:'实体粉币ID',buttonId:'实体按钮ID',minX:'横移左端',maxX:'横移右端',restY:'爪休息高度',grabY:'抓取高度（真实身体交点）',deliveryX:'出币口横坐标',deliveryY:'松爪高度',initialX:'起始横坐标',direction:'初始方向（1／-1）',speed:'横移速度',dropSpeed:'下降速度',liftSpeed:'提升速度',captureHalfWidth:'抓中左右半宽',closeFrames:'闭爪帧数',openFrames:'开爪帧数',buttonX:'按钮横坐标',buttonY:'按钮纵坐标',glassIds:'玻璃实体ID列表 JSON',payment:'付费槽 JSON（留空免费）',payloads:'实体金币／活NPC／布偶／炸弹 JSON',cabinet:'机柜矩形 JSON',searchlight:'独立探照灯按钮 JSON'};
 form.onsubmit=e=>{e.preventDefault();attempt(()=>{const values={};for(const [k,input]of inputs){if(String(input.value).trim()===''){if(['payment','payloads','cabinet','searchlight'].includes(k)){values[k]=undefined;continue;}throw Error('参数不能为空');}values[k]=['glassIds','payment','payloads','cabinet','searchlight'].includes(k)?JSON.parse(String(input.value)):input.type==='number'?Number(input.value):String(input.value);}updateCoinCrane(room(),selected,values);});};
 function refresh(){const rows=room().contraptions?.coinCranes||[];if(!rows.some(q=>q.id===selected))selected=rows[0]?.id||'';select.replaceChildren(...rows.map(q=>{const o=document.createElement('option');o.value=q.id;o.textContent=q.id;return o;}));select.value=selected;form.replaceChildren();inputs.clear();const q=rows.find(q=>q.id===selected);form.hidden=!q;if(!q)return;const b=room().map.geometry.find(g=>g.id===q.buttonId);for(const [key,value]of Object.entries({...COIN_CRANE_DEFAULTS,payment:'',payloads:'',cabinet:'',searchlight:'',...q,initialX:q.initialX??q.minX,direction:q.direction??1,buttonX:b.x,buttonY:b.y})){if(['id','gravity','maxFallSpeed'].includes(key))continue;const label=node('label',labels[key]||key,form),input=node('input','',label);input.type=typeof value==='number'?'number':'text';input.step='any';input.value=value&&typeof value==='object'?JSON.stringify(value):value;input.setAttribute('data-coin-crane-control',key);inputs.set(key,input);}const apply=node('button','应用抓币机参数',form);apply.type='submit';}
 refresh();return Object.freeze({refresh});
}
