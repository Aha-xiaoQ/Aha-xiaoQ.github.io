import {validateRailClaws} from './editor-rail-claws.mjs';

/** Opt-in live POWs, preplaced Buzzy Shellmets/items and local cycling Skewers.
 * Numeric tuning and uncalibrated contact/effect rules are authored approximations.
 * The host owns damage, NPC defeat and score. Mario's motor is not changed. */
const EPS=1e-7,OWNER=Symbol('smm2-items-controller');
const copy=v=>structuredClone(v),clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
const finite=(n,a,b)=>Number.isFinite(n)&&n>=a&&n<=b;
const integer=(n,a,b)=>Number.isSafeInteger(n)&&finite(n,a,b);
const unsafe=k=>['__proto__','constructor','prototype'].includes(k);
const plain=v=>v&&typeof v==='object'&&!Array.isArray(v)&&[Object.prototype,null].includes(Object.getPrototypeOf(v));
const safeId=v=>typeof v==='string'&&v.length>0&&v.length<=128&&!/[\u0000-\u001f\u007f]/.test(v)&&!unsafe(v);
const fail=s=>{throw Error(s);};
const rect=v=>v&&['x','y','w','h'].every(k=>Number.isFinite(v[k]))&&v.w>0&&v.h>0;
const pose=v=>({x:v.x,y:v.y,w:v.w,h:v.h});
const alive=v=>v&&!v.dead&&!v.dying&&!v.removed&&!v.taken;
const overlap=(a,b)=>a.x<b.x+b.w-EPS&&a.x+a.w>b.x+EPS&&a.y<b.y+b.h-EPS&&a.y+a.h>b.y+EPS;
const xOverlap=(a,b)=>a.x+a.w>b.x+EPS&&a.x<b.x+b.w-EPS;
const centre=a=>({x:a.x+a.w/2,y:a.y+a.h/2});
function fields(q,allowed,label,required=allowed){
 if(!plain(q))fail('Invalid '+label);
 for(const k of Object.keys(q))if(unsafe(k)||!allowed.includes(k))fail('Unknown '+label+' field: '+k);
 for(const k of required)if(!Object.hasOwn(q,k))fail('Missing '+label+' field: '+k);
}
const powFields=['id','gravity','maxFallSpeed','blastRadius','supportedScreenEffect'];
const pSwitchFields=['id','orientation','gravity','maxFallSpeed'];
const helmetFields=['id','gravity','maxFallSpeed'];
const placedFields=['id','kind','gravity','maxFallSpeed'];
const placedKinds=['life','mushroom','star'];
const skewerFields=['id','direction','travel','extendSpeed','retractSpeed','waitFrames','holdFrames','loadDistance','phaseOffsetFrames'];
const railFields=['trackId','speed','position','direction'];

// Quadratic paths use an arc-length lookup and evaluate the real curve, never
// a control polygon. This follows the existing declared track representation.
function compileTrack(spec){
 let from=spec.start,length=0;const segments=[];
 for(const authored of spec.segments){
  const q={...authored,from,offset:length,samples:[{t:0,p:from,d:0}]};
  const evaluate=t=>q.kind==='line'?[from[0]+(q.to[0]-from[0])*t,from[1]+(q.to[1]-from[1])*t]:[(1-t)**2*from[0]+2*(1-t)*t*q.control[0]+t*t*q.to[0],(1-t)**2*from[1]+2*(1-t)*t*q.control[1]+t*t*q.to[1]];
  function append(t,p){const a=q.samples.at(-1);q.samples.push({t,p,d:a.d+Math.hypot(p[0]-a.p[0],p[1]-a.p[1])});}
  function subdivide(t0,p0,t1,p1,depth){const tm=(t0+t1)/2,pm=evaluate(tm),error=Math.hypot(pm[0]-(p0[0]+p1[0])/2,pm[1]-(p0[1]+p1[1])/2);if(depth<14&&(error>.005||Math.hypot(p1[0]-p0[0],p1[1]-p0[1])>1)){subdivide(t0,p0,tm,pm,depth+1);subdivide(tm,pm,t1,p1,depth+1);}else append(t1,p1);}
  if(q.kind==='line')append(1,q.to);else subdivide(0,from,1,q.to,0);
  q.length=q.samples.at(-1).d;length+=q.length;q.end=length;segments.push(q);from=q.to;
 }
 return {spec,segments,length};
}
function sampleTrack(track,position){
 const q=track.segments.find(s=>position<=s.end+EPS)||track.segments.at(-1),d=clamp(position-q.offset,0,q.length);let lo=0,hi=q.samples.length-1;
 while(lo+1<hi){const m=(lo+hi)>>1;if(q.samples[m].d<d)lo=m;else hi=m;}
 const a=q.samples[lo],b=q.samples[hi],t=b.d-a.d>EPS?a.t+(b.t-a.t)*(d-a.d)/(b.d-a.d):a.t,u=1-t;
 return q.kind==='line'?{x:q.from[0]+(q.to[0]-q.from[0])*t,y:q.from[1]+(q.to[1]-q.from[1])*t}:{x:u*u*q.from[0]+2*u*t*q.control[0]+t*t*q.to[0],y:u*u*q.from[1]+2*u*t*q.control[1]+t*t*q.to[1]};
}
function railAdvance(track,position,direction,speed){
 if(track.spec.mode==='loop'){const p=((position+speed*direction)%track.length+track.length)%track.length;return {position:p,direction};}
 const period=track.length*2,unfolded=direction>0?position:period-position,phase=((unfolded+speed)%period+period)%period;
 return {position:phase<=track.length?phase:period-phase,direction:phase<track.length?1:-1};
}
/** Shared creator/runtime rail anchor, using the same real curve and arc table. */
export function smm2ItemRailAnchor(room,rail){
 fields(rail,railFields,'SMM2 item rail');validateRailClaws(room);const spec=room.contraptions?.tracks?.find(q=>q.id===rail.trackId),track=spec&&compileTrack(spec);
 if(!track||!finite(rail.speed,0,256)||!finite(rail.position,0,track.length)||![1,-1].includes(rail.direction))fail('Invalid SMM2 item rail attachment');return sampleTrack(track,rail.position);
}
function cycleLength(q){return q.waitFrames+Math.ceil(q.travel/q.extendSpeed)+q.holdFrames+Math.ceil(q.travel/q.retractSpeed);}
function skewerPose(base,direction,extension){
 const horizontal=direction==='left'||direction==='right';
 const shaft=horizontal?{x:direction==='right'?base.x+base.w:base.x-extension,y:base.y,w:extension,h:base.h}:{x:base.x,y:direction==='down'?base.y+base.h:base.y-extension,w:base.w,h:extension};
 const length=Math.min(extension,horizontal?base.h:base.w),tip=horizontal?{x:direction==='right'?shaft.x+extension-length:shaft.x,y:shaft.y,w:length,h:shaft.h}:{x:shaft.x,y:direction==='down'?shaft.y+extension-length:shaft.y,w:shaft.w,h:length};
 return {base:copy(base),shaft,tip};
}
/** Validates only these leaves; root/sibling validation belongs to importer. */
export function validateSmm2ItemsRoom(room,spec=room?.smm2Mechanics){
 if(spec===undefined)return;
 if(!plain(spec)||Object.keys(spec).some(unsafe))fail('Invalid or unsafe SMM2 mechanics');
 if(spec.version!==1)fail('Unknown SMM2 mechanics version');
 if(['powBlocks','pSwitches','helmets','skewers','placedItems'].every(k=>spec[k]===undefined))return;
 const map=room?.map;if(!map||!finite(map.width,1,32768)||!finite(map.height,1,4096)||!Array.isArray(map.objects))fail('SMM2 items need native room bounds and objects');
 const seen=new Set(),nativeIds=[...(map.geometry||[]),...map.objects,...(room.markers||[])].map(q=>q.id);
 let tracks=null;
 for(const [key,kind,allowed]of [['powBlocks','pow',powFields],['pSwitches','p-switch',pSwitchFields],['helmets','buzzy-shellmet',helmetFields],['skewers','hazard',skewerFields],['placedItems','life',placedFields]]){
  if(spec[key]===undefined)continue;
  if(!Array.isArray(spec[key])||spec[key].length>256)fail('Invalid SMM2 '+key+' list');
  for(const q of spec[key]){
   fields(q,key==='placedItems'?[...allowed,'rail','points','initialVx']:['powBlocks','pSwitches'].includes(key)?[...allowed,'rail']:allowed,'SMM2 '+key,allowed);
   if(key==='placedItems'&&!placedKinds.includes(q.kind))fail('SMM2 placed item kind must be life, mushroom or star');
   if(key==='placedItems'&&q.points!==undefined&&!integer(q.points,0,100000))fail('Invalid SMM2 placed item score');
   if(key==='placedItems'&&q.initialVx!==undefined&&(!finite(q.initialVx,-8,8)||q.rail!==undefined))fail('Invalid SMM2 free item initial horizontal velocity');
   if(!safeId(q.id)||seen.has(q.id))fail('Duplicate or invalid SMM2 item ID');seen.add(q.id);
   const a=map.objects.find(a=>a.id===q.id);
   const nativeKind=kind==='hazard'?'hazard':'walker';
   if(nativeIds.filter(id=>id===q.id).length!==1||!a||a.kind!==nativeKind||!rect(a)||!finite(a.w,.001,4096)||!finite(a.h,.001,4096)||!finite(a.x,0,map.width-a.w)||!finite(a.y,0,map.height-a.h))fail('SMM2 '+key+' needs one matching native '+nativeKind+' body inside the room');
   if(key!=='skewers'&&(!finite(q.gravity,0,64)||!finite(q.maxFallSpeed,.001,256)))fail('Invalid SMM2 item gravity or fall speed');
   if(key==='pSwitches'&&(!['up','down'].includes(q.orientation)||a.w!==16||a.h!==16))fail('SMM2 P Switch needs an up/down orientation and a real 16 by 16 native body');
   if(key==='powBlocks'||key==='placedItems'||key==='pSwitches'){
    if(key==='powBlocks'&&(!finite(q.blastRadius,0,4096)||typeof q.supportedScreenEffect!=='boolean'))fail('Invalid SMM2 POW effect policy');
    if(q.rail!==undefined){
     fields(q.rail,railFields,'SMM2 item rail');
     if(tracks===null){validateRailClaws(room);tracks=new Map((room.contraptions?.tracks||[]).map(t=>[t.id,compileTrack(t)]));}
     const t=tracks.get(q.rail.trackId);
     if(!safeId(q.rail.trackId)||!t||!finite(q.rail.speed,0,256)||!finite(q.rail.position,0,t.length)||![1,-1].includes(q.rail.direction))fail('Invalid SMM2 item rail attachment');
     const anchor=sampleTrack(t,q.rail.position),c=centre(a);
     if(Math.hypot(c.x-anchor.x,c.y-anchor.y)>.01)fail('SMM2 item source centre must match its initial declared rail sample');
    }
   }
   if(key==='skewers'){
    if(!['down','up','left','right'].includes(q.direction)||!finite(q.travel,.001,4096)||!finite(q.extendSpeed,.001,256)||!finite(q.retractSpeed,.001,256)||!integer(q.waitFrames,0,36000)||!integer(q.holdFrames,0,36000)||!finite(q.loadDistance,0,4096)||!integer(q.phaseOffsetFrames,0,36000))fail('Invalid SMM2 Skewer cycle, load or motion values');
    const reach=skewerPose(pose(a),q.direction,q.travel).shaft;
    if(!finite(reach.x,0,map.width-reach.w)||!finite(reach.y,0,map.height-reach.h)||q.phaseOffsetFrames>=cycleLength(q))fail('SMM2 Skewer extension/phase is outside its authored room/cycle');
   }
  }
 }
}
const terrainFor=geometry=>geometry.filter(q=>rect(q)&&alive(q)&&!q.hidden&&q.visible!==false&&['solid','oneway'].includes(q.collision));
function interval(position,delta,min,max){if(Math.abs(delta)<EPS)return position>min+EPS&&position<max-EPS?{entry:-Infinity,exit:Infinity}:null;const a=(min-position)/delta,b=(max-position)/delta;return {entry:Math.min(a,b),exit:Math.max(a,b)};}
function sweepRect(a,delta,b){
 const x=interval(a.x,delta.x,b.x-a.w,b.x+b.w),y=interval(a.y,delta.y,b.y-a.h,b.y+b.h);if(!x||!y)return null;
 const entry=Math.max(x.entry,y.entry),exit=Math.min(x.exit,y.exit),embedded=overlap(a,b);
 if(!embedded&&(entry<-EPS||entry>1+EPS||exit<=Math.max(0,entry)+EPS))return null;
 return {fraction:embedded?0:clamp(entry,0,1),normal:x.entry>y.entry?{x:-Math.sign(delta.x),y:0}:{x:0,y:-Math.sign(delta.y)},embedded};
}
function sweepTerrain(a,delta,geometry){
 let nearest=null;
 for(const solid of terrainFor(geometry)){
  let hit;
  if(solid.collision==='oneway'){
   if(delta.y<=EPS||a.y+a.h>solid.y+EPS||a.y+a.h+delta.y<solid.y-EPS)continue;
   const fraction=clamp((solid.y-a.y-a.h)/delta.y,0,1),at={...a,x:a.x+delta.x*fraction};if(!xOverlap(at,solid))continue;
   hit={fraction,normal:{x:0,y:-1},embedded:false};
  }else hit=sweepRect(a,delta,solid);
  if(hit&&(!nearest||hit.fraction<nearest.fraction-EPS||Math.abs(hit.fraction-nearest.fraction)<=EPS&&String(solid.id)<String(nearest.solid.id)))nearest={...hit,solid};
 }
 return nearest;
}
function contactRecord(a,delta,hit,tick){const at={x:a.x+delta.x*hit.fraction,y:a.y+delta.y*hit.fraction,w:a.w,h:a.h},n=hit.normal,q=hit.solid;return {tick,fraction:hit.fraction,solidId:q.id??null,normal:copy(n),point:{x:n.x<0?at.x+at.w:n.x>0?at.x:clamp(at.x+at.w/2,q.x,q.x+q.w),y:n.y<0?at.y+at.h:n.y>0?at.y:clamp(at.y+at.h/2,q.y,q.y+q.h)},body:at,embedded:!!hit.embedded};}
function headContact(player,before,item,itemBefore=pose(item),native=false){
 if(!alive(player)||!rect(player)||!rect(before)||!rect(item)||!rect(itemBefore))return null;
 const startGap=before.y-itemBefore.y-itemBefore.h,endGap=player.y-item.y-item.h,relative=endGap-startGap;
 const verified=native&&player.headHit===item.id&&startGap>=-1.01&&Math.abs(endGap)<=1.01;
 if(!verified&&(relative>=-EPS||startGap<-EPS||endGap>EPS))return null;
 const fraction=verified&&Math.abs(relative)<EPS?1:clamp(-startGap/relative,0,1),px=before.x+(player.x-before.x)*fraction,ix=itemBefore.x+(item.x-itemBefore.x)*fraction;
 if(px+player.w<=ix+EPS||px>=ix+item.w-EPS)return null;
 return {kind:'head',fraction,normal:{x:0,y:1},point:{x:clamp(px+player.w/2,ix,ix+item.w),y:itemBefore.y+itemBefore.h+(item.y-itemBefore.y)*fraction},relativeMotion:{x:player.x-before.x-item.x+itemBefore.x,y:relative},nativeHeadHit:verified};
}
function touchingSolid(a,q){
 if(q.collision!=='solid')return false;
 const vertical=xOverlap(a,q)&&(Math.abs(a.y+a.h-q.y)<=.01||Math.abs(a.y-q.y-q.h)<=.01),horizontal=a.y+a.h>q.y+EPS&&a.y<q.y+q.h-EPS&&(Math.abs(a.x+a.w-q.x)<=.01||Math.abs(a.x-q.x-q.w)<=.01);
 return vertical||horizontal;
}
const distanceToRect=(p,q)=>Math.hypot(p.x-clamp(p.x,q.x,q.x+q.w),p.y-clamp(p.y,q.y,q.y+q.h));
/** Host-supplied eligible live NPC bodies; no actor is mutated by this query. */
export function smm2PowTargets(effect,targets=[],{isEligible=a=>a.powEligible===true||a.type==='smm2-thwomp'||/^(?:marker-)?(?:walker|goomba|(?:red|green)?koopa|koopa(?:red|green)?|muncher)$/i.test(a.type||''),isGrounded=a=>a.grounded===true}={}){
 if(!plain(effect)||!effect.position||!finite(effect.position.x,-32768,65536)||!finite(effect.position.y,-4096,8192)||!finite(effect.blastRadius,0,4096)||typeof effect.supportedScreenEffect!=='boolean'||typeof effect.touchingSolid!=='boolean'||!Array.isArray(targets)||targets.length>20000||typeof isEligible!=='function'||typeof isGrounded!=='function')fail('Invalid SMM2 POW target query');
 const out=[],seen=new Set();
 for(const a of targets){if(!alive(a)||!rect(a)||!safeId(a.id)||seen.has(a.id))continue;const eligible=isEligible(a);if(typeof eligible!=='boolean')fail('SMM2 POW eligibility must return a synchronous boolean');if(!eligible)continue;let reason=null;
  if(effect.trigger?.kind==='thwomp-impact'&&effect.trigger.actorId===a.id)reason='direct-charge';
  else if(effect.supportedScreenEffect){const grounded=isGrounded(a);if(typeof grounded!=='boolean')fail('SMM2 POW ground query must return a synchronous boolean');if(grounded&&rect(effect.screen)&&overlap(a,effect.screen))reason='supported-screen';}
  else if(distanceToRect(effect.position,a)<=effect.blastRadius+EPS)reason='local';
  if(reason){seen.add(a.id);out.push({id:a.id,reason,body:pose(a)});}
 }
 return out;
}
// Four strict linear inequalities give continuous overlap for a moving player
// and an expanding/retracting shaft. A union rectangle would produce false hits
// when the player and the spike tip visit the same place at different times.
function changingRectContact(before,after,oldRect,newRect){
 let low=0,high=1;
 for(const [v0,v1]of [[before.x+before.w-oldRect.x,after.x+after.w-newRect.x],[oldRect.x+oldRect.w-before.x,newRect.x+newRect.w-after.x],[before.y+before.h-oldRect.y,after.y+after.h-newRect.y],[oldRect.y+oldRect.h-before.y,newRect.y+newRect.h-after.y]]){
  const d=v1-v0;if(Math.abs(d)<EPS){if(v0<=EPS)return null;continue;}
  const t=(EPS-v0)/d;if(d>0)low=Math.max(low,t);else high=Math.min(high,t);if(low>=high-EPS)return null;
 }
 return {fraction:clamp(low,0,1)};
}

export function createSmm2Items(room,{emit=()=>{},terrain=null,isPowTarget,isHeld=()=>false}={}){
 validateSmm2ItemsRoom(room);
 const s=room?.smm2Mechanics,definitions=new Map();
 for(const [key,kind]of [['powBlocks','pow'],['pSwitches','p-switch'],['helmets','buzzy-shellmet'],['skewers','hazard'],['placedItems',null]])for(const q of s?.[key]||[])definitions.set(q.id,{...copy(q),kind:kind??q.kind});
 // A pipe-only empty Buzzy supply can equip Mario without any preplaced item.
 // Keep the ordinary helmet protection controller available in that room.
 if(!definitions.size&&!room.marioModules?.enemySources?.some(q=>q.enemy==='beetle-shell'))return null;
 if(typeof emit!=='function'||typeof isHeld!=='function'||isPowTarget!==undefined&&typeof isPowTarget!=='function'||terrain!==null&&(!terrain||typeof terrain.sweep!=='function'||typeof terrain.afterActor!=='function'))fail('Invalid SMM2 item host callbacks');
 const railIds=new Set([...definitions.values()].filter(q=>q.rail).map(q=>q.rail.trackId)),tracks=new Map((room.contraptions?.tracks||[]).filter(t=>railIds.has(t.id)).map(t=>[t.id,compileTrack(copy(t))])),sources=new Map([...definitions.keys()].map(id=>[id,copy(room.map.objects.find(a=>a.id===id))])),owner={};
 let currentTick=null,lastTick=null,paused=false,frameStarts=new Map(),liveActors=[];
 const ownsActor=a=>!!a&&definitions.has(a.id);
 const diagnostic=(event,data={})=>emit('smm2-item',{event,roomId:room.roomId,tick:currentTick,...copy(data)});
 function stateFor(a){return a.smm2Pow||a.smm2PSwitch||a.smm2Helmet||a.smm2Skewer||a.smm2PlacedItem;}
 function decorateActor(a){
  if(!ownsActor(a))return a;if(!rect(a))fail('Invalid live SMM2 item body');if(stateFor(a)?.[OWNER]===owner)return a;
  const q=definitions.get(a.id),state={version:1,id:a.id,lastTick:null};Object.defineProperty(state,OWNER,{value:owner});
  a.vx=Number.isFinite(a.vx)?a.vx:0;a.vy=Number.isFinite(a.vy)?a.vy:0;a.grounded=!!a.grounded;a.support??=null;
  if(q.kind==='pow'){a.kind='pow';a.type='smm2-pow';a.standable=true;Object.assign(state,{phase:'live',contact:null,rail:q.rail?copy(q.rail):null,dx:0,dy:0});a.smm2Pow=state;}
  else if(q.kind==='p-switch'){a.kind='p-switch';a.type='smm2-p-switch';a.standable=q.orientation==='up';Object.assign(state,{phase:'live',orientation:q.orientation,contact:null,rail:q.rail?copy(q.rail):null,dx:0,dy:0});a.smm2PSwitch=state;}
  else if(q.kind==='buzzy-shellmet'){a.kind='buzzy-shellmet';a.type='smm2-buzzy-shell';a.standable=false;Object.assign(state,{phase:'loose',contact:null,dx:0,dy:0});a.smm2Helmet=state;}
  else if(placedKinds.includes(q.kind)){a.kind=q.kind;a.standable=false;if(q.initialVx!==undefined)a.vx=q.initialVx;Object.assign(state,{phase:'live',contact:null,rail:q.rail?copy(q.rail):null,dx:0,dy:0});a.smm2PlacedItem=state;}
  else{const extension=q.phaseOffsetFrames>0?cycle(q,q.phaseOffsetFrames-1).extension:0;a.kind='hazard';a.type='smm2-skewer';a.standable=false;Object.assign(state,{direction:q.direction,loaded:false,clock:q.phaseOffsetFrames,phase:'unloaded',extension,...skewerPose(pose(a),q.direction,extension),previous:skewerPose(pose(a),q.direction,extension)});a.smm2Skewer=state;}
  return a;
 }
 function beginFrame({tick,actors=[],player,paused:stop=false}={}){
  if(!integer(tick,0,Number.MAX_SAFE_INTEGER)||!Array.isArray(actors)||actors.length>20000||typeof stop!=='boolean')fail('Invalid SMM2 item frame');
  if(lastTick!==null&&tick<lastTick)return false;currentTick=tick;paused=stop;if(stop||lastTick===tick)return false;
  lastTick=tick;liveActors=actors.filter(ownsActor);frameStarts=new Map();
  for(const a of liveActors){decorateActor(a);frameStarts.set(a,pose(a));const st=stateFor(a);if(st.dx!==undefined)st.dx=st.dy=0;if(a.smm2Skewer)stepSkewer(a,player,tick);}
  return true;
 }
 function cycle(q,clock){
  const extending=Math.ceil(q.travel/q.extendSpeed),retracting=Math.ceil(q.travel/q.retractSpeed),c=clock%cycleLength(q);
  if(c<q.waitFrames)return {phase:'wait',extension:0};
  if(c<q.waitFrames+extending)return {phase:'extend',extension:Math.min(q.travel,(c-q.waitFrames+1)*q.extendSpeed)};
  if(c<q.waitFrames+extending+q.holdFrames)return {phase:'hold',extension:q.travel};
  return {phase:'retract',extension:Math.max(0,q.travel-(c-q.waitFrames-extending-q.holdFrames+1)*q.retractSpeed),retracting};
 }
 function stepSkewer(a,player,tick){
  if(!alive(a))return;const q=definitions.get(a.id),st=a.smm2Skewer;if(st.lastTick!==null&&tick<=st.lastTick)return;st.lastTick=tick;st.previous={base:copy(st.base),shaft:copy(st.shaft),tip:copy(st.tip)};
  if(!st.loaded&&alive(player)&&rect(player)&&distanceToRect(centre(player),st.base)<=q.loadDistance+EPS){st.loaded=true;diagnostic('skewer-loaded',{actorId:a.id,position:centre(a),phaseOffsetFrames:q.phaseOffsetFrames});}
  if(!st.loaded)return;
  const c=cycle(q,st.clock++),previous=st.phase;st.phase=c.phase;st.extension=c.extension;Object.assign(st,skewerPose(st.base,q.direction,c.extension));
  if(st.phase!==previous)diagnostic('skewer-phase',{actorId:a.id,phase:st.phase,extension:st.extension});
 }
 function geometry(base=[],actors=liveActors,{exclude}={}){
  if(!Array.isArray(base)||!Array.isArray(actors))fail('Invalid SMM2 item geometry');
  const result=base.filter(g=>!g.smm2ItemBody);
  for(const a of actors){if(a===exclude||!ownsActor(a)||!alive(a)||!['pow','p-switch'].includes(definitions.get(a.id).kind))continue;decorateActor(a);const st=stateFor(a);if(st.phase!=='live')continue;
   result.push({id:a.id,...pose(a),collision:a.smm2PSwitch?.orientation==='up'?'oneway':'solid',material:a.smm2PSwitch?'smm2-p-switch':'smm2-pow',smm2ItemBody:true,dx:st.dx,dy:st.dy});
  }
  return result;
 }
 function stepItem(a,{tick=currentTick,geometry:base=[],getGeometry=()=>base,support=null,actors=[],motion=null}={}){
  if(!ownsActor(a))return false;
  if(!integer(tick,0,Number.MAX_SAFE_INTEGER)||!Array.isArray(base)||typeof getGeometry!=='function')fail('Invalid SMM2 item motion frame');
  decorateActor(a);const q=definitions.get(a.id),st=stateFor(a);
  if(motion!==null){fields(motion,['gravity','maxFallSpeed'],'placed item host motion',['gravity','maxFallSpeed']);if(!placedKinds.includes(q.kind)||!finite(motion.gravity,0,64)||!finite(motion.maxFallSpeed,.001,256))fail('Invalid placed item host motion');}
  if(q.kind==='hazard')return {handled:true,advanced:false,phase:st.phase};
  if(paused||tick!==currentTick||!alive(a)||['spent','worn','pressed'].includes(st.phase)||st.lastTick!==null&&tick<=st.lastTick)return {handled:true,advanced:false,phase:st.phase};
  st.lastTick=tick;
  // The claw controller owns a held body's pose and release velocity. Spending
  // this tick prevents a second item step from moving it after a same-tick drop.
  const held=isHeld(a);if(typeof held!=='boolean')fail('SMM2 item held query must return a synchronous boolean');
  if(q.kind==='pow'&&support?.ownsItem(a)){
   const before={...a},incoming={x:a.vx,y:Math.min(q.maxFallSpeed,a.vy+q.gravity)},result=support.stepItem(a,{tick,geometry:getGeometry(),actors,held});
   st.contact=result.contact?copy(result.contact):null;st.dx=result.dx||0;st.dy=result.dy||0;
   if(result.advanced)terrain?.afterActor(a,before,{tick,input:{},geometry:base,incomingVelocity:incoming});
   return {handled:true,...result,phase:st.phase};
  }
  if(held)return {handled:true,advanced:false,held:true,phase:st.phase};
  const before={...a};
  const read=()=>{const g=getGeometry();if(!Array.isArray(g)||g.length>20000)fail('Invalid SMM2 live item terrain');return terrainFor(g).filter(g=>g.id!==a.id&&!terrain?.ownsGeometry?.(g));};
  function move(delta){
   const rectangle=sweepTerrain(a,delta,read()),shaped=terrain?.sweep(a,delta,{tick});
   if(shaped&&(!plain(shaped)||!finite(shaped.fraction,0,1)||!safeId(shaped.solidId)||!rect(shaped.body)||shaped.body.w!==a.w||shaped.body.h!==a.h||Math.abs(shaped.body.x-a.x-delta.x*shaped.fraction)>1e-5||Math.abs(shaped.body.y-a.y-delta.y*shaped.fraction)>1e-5||!shaped.normal||!finite(shaped.normal.x,-1,1)||!finite(shaped.normal.y,-1,1)||Math.abs(Math.hypot(shaped.normal.x,shaped.normal.y)-1)>1e-5))fail('Invalid SMM2 shaped item sweep');
   const hit=shaped&&(!rectangle||shaped.fraction<rectangle.fraction-EPS)?shaped:rectangle?contactRecord(a,delta,rectangle,tick):null;
   a.x+=delta.x*(hit?.fraction??1);a.y+=delta.y*(hit?.fraction??1);
   if(hit){if(hit.normal.x)a.vx=0;if(hit.normal.y)a.vy=0;if(hit.normal.y<0){a.grounded=true;a.support=hit.solidId;st.contact=copy(hit);}}
   return hit;
  }
  a.grounded=false;a.support=null;st.contact=null;
  if(st.rail){
   const t=tracks.get(st.rail.trackId);let remaining=st.rail.speed;
   // Walk the actual arc, including intermediate curves and endpoint reversals.
   // Sampling only the final pose would tunnel when a short rail loops in a tick.
   while(remaining>EPS){const distance=Math.min(1,remaining),next=railAdvance(t,st.rail.position,st.rail.direction,distance),anchor=sampleTrack(t,next.position),delta={x:anchor.x-a.w/2-a.x,y:anchor.y-a.h/2-a.y},hit=move(delta);
    if(hit&&hit.fraction<1-EPS)break;st.rail.position=next.position;st.rail.direction=next.direction;remaining-=distance;
   }a.vx=a.x-before.x;a.vy=a.y-before.y;
  }else{
   if(before.grounded&&before.support){const support=read().find(g=>g.id===before.support);if(support)move({x:support.dx||0,y:support.dy||0});}
   a.vy=Math.min(motion?.maxFallSpeed??q.maxFallSpeed,a.vy+(motion?.gravity??q.gravity));const incoming={x:a.vx,y:a.vy};
   if(Math.abs(a.vx)>EPS)move({x:a.vx,y:0});move({x:0,y:a.vy});
   terrain?.afterActor(a,before,{tick,input:{},geometry:base,incomingVelocity:incoming});
  }
  st.dx=a.x-before.x;st.dy=a.y-before.y;return {handled:true,advanced:true,phase:st.phase,contact:st.contact?copy(st.contact):null,dx:st.dx,dy:st.dy};
 }
 function activatePow(a,contact,{tick,targets,screen,geometry:base,trigger}){
  const q=definitions.get(a.id),st=a.smm2Pow;
  if(q?.kind!=='pow'||!alive(a)||st?.phase!=='live')return null;
  const shapedSolidIds=new Set((terrain?.surfaces?.()||[]).filter(shape=>shape.collision==='solid').map(shape=>shape.id));
  const touchingShape=shapedSolidIds.size>0&&[{x:0,y:.001},{x:0,y:-.001},{x:.001,y:0},{x:-.001,y:0}].some(delta=>{const hit=terrain.sweep(a,delta,{tick});return hit&&hit.fraction<=EPS&&shapedSolidIds.has(hit.solidId);});
  const position=centre(a),touching=terrainFor(base).filter(g=>g.id!==a.id&&!terrain?.ownsGeometry?.(g)).some(g=>touchingSolid(a,g))||touchingShape;
  const effect={actorId:a.id,tick,position,contact:copy(contact),trigger:copy(trigger),approximation:true,blastRadius:q.blastRadius,supportedScreenEffect:q.supportedScreenEffect,touchingSolid:touching,...(rect(screen)?{screen:pose(screen)}:{})};
  effect.targets=smm2PowTargets(effect,targets,{...(isPowTarget?{isEligible:isPowTarget}:{}),isGrounded:target=>target.grounded===true||base.some(g=>g.id!==target.id&&!g.hidden&&['solid','oneway'].includes(g.collision)&&target.x+target.w>g.x+EPS&&target.x<g.x+g.w-EPS&&Math.abs(target.y+target.h-g.y)<=.001)||(()=>{const hit=terrain?.sweep(target,{x:0,y:.001},{tick});return !!hit&&!hit.embedded&&hit.fraction<=EPS&&hit.normal.y<0;})()});
  st.phase='spent';a.dead=true;a.standable=false;a.grounded=false;a.support=null;a.vx=a.vy=0;terrain?.clearActorContact?.(a);diagnostic('pow-activate',effect);return effect;
 }
 function afterPlayer(player,before,{tick=currentTick,input={},actors=liveActors,targets=[],screen,geometry:base=[]}={}){
  const result={handled:true,activated:[],worn:[],effects:[]};
  if(paused||tick!==currentTick||!alive(player)||!rect(player)||!rect(before))return result;
  if(!Array.isArray(actors)||!Array.isArray(targets)||!Array.isArray(base))fail('Invalid SMM2 player item contact inputs');
  for(const a of actors){if(!ownsActor(a)||!alive(a))continue;decorateActor(a);const q=definitions.get(a.id),st=stateFor(a);if(q.kind==='hazard'||placedKinds.includes(q.kind)||['spent','worn','pressed'].includes(st.phase))continue;
   if(q.kind==='p-switch'){
    if(isHeld(a))continue;const old=frameStarts.get(a)||pose(a);let contact=null;
    if(q.orientation==='down')contact=headContact(player,before,a,old,true);
    else{
     const start=old.y-before.y-before.h,end=a.y-player.y-player.h,relative=end-start;
     const native=player.grounded===true&&player.support===a.id&&start>=-1.01&&Math.abs(end)<=1.01;
     if((native||start>=-EPS&&end<=EPS&&relative<-EPS)&&before.vy>=0){const fraction=Math.abs(relative)>EPS?clamp(-start/relative,0,1):1,px=before.x+(player.x-before.x)*fraction,ix=old.x+(a.x-old.x)*fraction;if(px+player.w>ix+EPS&&px<ix+a.w-EPS)contact={kind:'foot',fraction,normal:{x:0,y:-1},nativeSupport:native};}
    }
    if(!contact)continue;const original=pose(a);st.phase='pressed';st.contact=copy(contact);st.dx=st.dy=0;a.pressed=true;if(q.orientation==='up')a.y+=a.h-4;a.h=4;a.vx=a.vy=0;a.standable=false;a.grounded=false;a.support=null;if(player.headHit===a.id)player.headHit=null;
    (result.pPressed??=[]).push({actorId:a.id,orientation:q.orientation,contact:copy(contact),body:original});diagnostic('p-switch-pressed',result.pPressed.at(-1));continue;
   }
   const contact=headContact(player,before,a,frameStarts.get(a)||pose(a),true);
   if(q.kind==='pow'&&contact){
    const effect=activatePow(a,contact,{tick,targets,screen,geometry:base,trigger:{kind:'player-head',actorId:player.id??'player'}});
    if(effect){result.activated.push(a.id);result.effects.push(copy(effect));if(player.headHit===a.id)player.headHit=null;}
   }else if(q.kind==='buzzy-shellmet'&&player.helmet!=='buzzy'){
    if(!contact)continue;st.phase='worn';a.dead=true;a.standable=false;a.grounded=false;a.support=null;a.vx=a.vy=0;player.helmet='buzzy';terrain?.clearActorContact?.(a);
    result.worn.push(a.id);diagnostic('helmet-worn',{actorId:a.id,helmet:'buzzy',contact,power:player.power??0});
   }
  }
  return result;
 }
 /** Real placed-item overlap, with reward application left to the host. */
 function ownedItemContact(a,player,{tick=currentTick}={}){
  const result={handled:ownsActor(a),collect:null};if(!result.handled)return result;
  decorateActor(a);const q=definitions.get(a.id),st=stateFor(a);
  if(!placedKinds.includes(q.kind)||paused||tick!==currentTick||!integer(tick,0,Number.MAX_SAFE_INTEGER)||!alive(a)||st.phase!=='live'||!alive(player)||!rect(player))return result;
  const held=isHeld(a);if(typeof held!=='boolean')fail('SMM2 item held query must return a synchronous boolean');
  if(held||!overlap(player,a))return result;
  result.collect={actorId:a.id,kind:q.kind,points:q.points??0,tick,position:centre(a)};
  st.phase='collected';st.contact=null;st.dx=st.dy=0;a.dead=true;a.taken=true;a.standable=false;a.grounded=false;a.support=null;a.vx=a.vy=0;terrain?.clearActorContact?.(a);
  diagnostic('placed-item-collected',result.collect);return result;
 }
 /** Consume the actual Thwomp controller's freshly returned result.impact.
  * A mere matching ID, resting body or a falling POW is not a trigger. */
 function afterThwompImpact(enemy,{tick=currentTick,contact,actors=liveActors,targets=[],screen,geometry:base=[]}={}){
  const result={handled:true,activated:[],effects:[]};
  if(paused||tick!==currentTick||!integer(tick,0,Number.MAX_SAFE_INTEGER)||!alive(enemy)||!rect(enemy)||enemy.type!=='smm2-thwomp')return result;
  if(!Array.isArray(actors)||!Array.isArray(targets)||!Array.isArray(base)||actors.length>20000||targets.length>20000||base.length>20000)fail('Invalid SMM2 Thwomp POW impact inputs');
  const st=enemy.smm2Thwomp,authored=room.smm2Mechanics?.thwomps?.find(q=>q.id===enemy.id),motion=st?.lastMotion,actual=st?.contact;
  if(!plain(st)||st.id!==enemy.id||st.phase!=='impact'||st.direction!=='down'||st.lastTick!==tick||!authored||authored.direction!=='down'||!plain(contact)||!plain(actual)||!plain(motion)||motion.tick!==tick||!rect(motion.from)||!rect(motion.to))return result;
  const contactKeys=['solidId','material','tick','fraction','normal','point','body','incomingVelocity','embedded','terrainKind'];
  if(Object.keys(contact).some(k=>!contactKeys.includes(k))||contactKeys.some(k=>!Object.hasOwn(contact,k))||contact.tick!==tick||actual.tick!==tick||contact.embedded!==false||actual.embedded!==false||contact.terrainKind!=='rectangle'||actual.terrainKind!=='rectangle'||contact.material!=='smm2-pow'||!finite(contact.fraction,0,1)||!rect(contact.body))return result;
  const xy=v=>plain(v)&&Object.keys(v).every(k=>['x','y'].includes(k))&&finite(v.x,-32768,65536)&&finite(v.y,-32768,65536),near=(a,b)=>Number.isFinite(a)&&Number.isFinite(b)&&Math.abs(a-b)<=EPS;
  if(!xy(contact.normal)||!xy(contact.point)||!xy(contact.incomingVelocity)||!near(contact.normal.x,0)||!near(contact.normal.y,-1)||!near(contact.incomingVelocity.x,0)||!finite(contact.incomingVelocity.y,EPS,256))return result;
  if(['solidId','material','tick','embedded','terrainKind'].some(k=>contact[k]!==actual[k])||!near(contact.fraction,actual.fraction)||['normal','point','incomingVelocity'].some(k=>!xy(actual[k])||!near(contact[k].x,actual[k].x)||!near(contact[k].y,actual[k].y))||!rect(actual.body)||['x','y','w','h'].some(k=>!near(contact.body[k],actual.body[k])||!near(contact.body[k],enemy[k])||!near(motion.to[k],enemy[k])||!near(motion.from[k],motion.to[k])&&k!=='y'))return result;
  const a=actors.find(a=>a.id===contact.solidId&&ownsActor(a)&&definitions.get(a.id).kind==='pow'&&alive(a));if(!a)return result;decorateActor(a);if(a.smm2Pow.phase!=='live')return result;
  const bodySolid=terrainFor(base).find(g=>g.id===a.id&&g.collision==='solid'&&g.smm2ItemBody===true&&['x','y','w','h'].every(k=>near(g[k],a[k])));
  if(!bodySolid||enemy.grounded!==true||enemy.support!==a.id||!xOverlap(enemy,a)||!near(enemy.y+enemy.h,a.y)||!near(contact.point.y,a.y)||contact.point.x<Math.max(enemy.x,a.x)-EPS||contact.point.x>Math.min(enemy.x+enemy.w,a.x+a.w)+EPS||motion.from.y+motion.from.h>a.y+EPS||motion.to.y<motion.from.y-EPS||!near(motion.to.y-motion.from.y,contact.incomingVelocity.y*contact.fraction))return result;
  // A real charge may start exactly on the top (fraction zero). A later resting
  // impact-phase support probe has already spent at least one wait frame.
  if(near(motion.to.y,motion.from.y)&&(!near(contact.fraction,0)||st.remaining!==authored.impactWaitFrames))return result;
  const effect=activatePow(a,contact,{tick,targets,screen,geometry:base,trigger:{kind:'thwomp-impact',actorId:enemy.id}});
  if(effect){result.activated.push(a.id);result.effects.push(copy(effect));}return result;
 }
 function helmetContact(player,before,hazard,{tick=currentTick,hazardBefore=pose(hazard||{})}={}){
  if(paused||tick!==currentTick||player?.helmet!=='buzzy'||!alive(hazard)||hazard?.type!=='smm2-thwomp')return {handled:false,protected:false};
  const contact=headContact(player,before,hazard,hazardBefore,false);
  if(contact)return {handled:true,protected:true,action:'request-return',consumeHelmet:false,approximation:true,contact};
  const bodyContact=rect(before)&&rect(player)&&rect(hazardBefore)&&rect(hazard)?changingRectContact(before,player,hazardBefore,hazard):null;
  return {handled:true,protected:false,consumeHelmet:!!bodyContact,...(bodyContact?{contact:{kind:'body',fraction:bodyContact.fraction}}:{})};
 }
 function playerHazardContact(player,before,{tick=currentTick,actors=liveActors}={}){
  if(paused||tick!==currentTick||!alive(player)||!rect(player)||!rect(before))return [];
  const contacts=[];
  for(const a of actors){if(!ownsActor(a)||definitions.get(a.id).kind!=='hazard'||!alive(a))continue;decorateActor(a);const st=a.smm2Skewer;
   for(const part of ['base','shaft']){const old=st.previous?.[part]||st[part],now=st[part];if(!old||!now||part==='shaft'&&old.w<=EPS&&now.w<=EPS||part==='shaft'&&old.h<=EPS&&now.h<=EPS)continue;
    const hit=changingRectContact(before,player,old,now);if(hit)contacts.push({actorId:a.id,tick,part,fraction:hit.fraction,body:copy(now),damage:true,solid:false,helmetProtected:false});
   }
  }
  return contacts.sort((a,b)=>a.fraction-b.fraction||a.actorId.localeCompare(b.actorId));
 }
 function reset(actors=liveActors){
  for(const a of actors){if(!ownsActor(a))continue;const source=sources.get(a.id);Object.assign(a,pose(source),{vx:0,vy:0,dead:false,dying:false,removed:false,taken:false,grounded:false,support:null});delete a.pressed;delete a.smm2Pow;delete a.smm2PSwitch;delete a.smm2Helmet;delete a.smm2Skewer;delete a.smm2PlacedItem;terrain?.clearActorContact?.(a);decorateActor(a);}
  currentTick=lastTick=null;paused=false;frameStarts=new Map();
 }
 function view(actors=liveActors){return {version:1,approximation:true,tick:currentTick,actors:actors.filter(ownsActor).map(a=>({id:a.id,kind:definitions.get(a.id).kind,body:pose(a),dead:!!a.dead,state:copy(stateFor(decorateActor(a)))}))};}
 return Object.freeze({ownsActor,decorateActor,beginFrame,stepItem,geometry,afterPlayer,ownedItemContact,afterThwompImpact,helmetContact,playerHazardContact,view,reset});
}
