import {validateCoinCranes} from './editor-coin-crane.mjs';
import {validateChainChompGuards} from './editor-chain-chomp-guard.mjs';
import {blockContent} from './editor-block-content.mjs';
import {createKeyFollowers} from './editor-key-followers.mjs';
import {validateRailClaws} from './editor-rail-claws.mjs';
import {validateClownCars} from './editor-clown-cars.mjs';
import {validateCastleContraptionCompatibility} from './editor-castle.mjs';

/** Authored, opt-in native mechanisms. No course-specific room or answer scripts.
 * Keys, spent note contents, paired doors and timed P conversion share one life.
 * Rail constraints/vehicles are separate local motion adapters; Mario remains native. */
const copy=x=>JSON.parse(JSON.stringify(x));
const safeId=x=>typeof x==='string'&&/^[a-zA-Z0-9][a-zA-Z0-9_.:-]{0,99}$/.test(x)&&!['__proto__','constructor','prototype'].includes(x);
const finite=(x,a,b)=>Number.isFinite(x)&&x>=a&&x<=b;
const integer=(x,a,b)=>Number.isInteger(x)&&finite(x,a,b);
const overlap=(a,b)=>a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y;
const fail=x=>{throw Error(x);};
function fields(q,allowed,label){if(!q||typeof q!=='object'||Array.isArray(q))fail('Invalid '+label);for(const k of Object.keys(q))if(!allowed.includes(k)||['__proto__','constructor','prototype'].includes(k))fail('Unknown '+label+' field: '+k);}
function list(q,label,max=256){if(!Array.isArray(q)||q.length>max)fail('Invalid '+label+' list');}
function rectangle(room,q,label){if(!['x','y','w','h'].every(k=>finite(q[k],0,32768))||q.w<=0||q.h<=0||q.x+q.w>room.map.width||q.y+q.h>room.map.height)fail(label+' is outside its native room');}
export const CONTRAPTION_DEFAULTS=Object.freeze({notePlayerBounce:4.8,noteHeldBounce:6.2,noteEnemyBounce:2.5,pDurationFrames:600,keySpeed:3,keyDelayFrames:12});
export function validateContraptionsRoom(room){
 const s=room?.contraptions;if(s===undefined)return;
 fields(s,['version','scene','startingLives','tracks','claws','cars','notes','doors','pSwitch','pSources','oneWayWalls','spikeTraps','coinCranes','chainChompGuards'],'contraptions');
 if(s.version!==1)fail('Unknown contraptions version');if(s.scene!==undefined&&s.scene!=='desert')fail('Unknown contraption scene');
 const water=!!room.aquatic||!!room.underwater||/Underwater/.test(room.setting||'');
 const supportedWater=water&&room.aquatic?.contactBodies==='smm2-solid-actors'&&room.smm2Mechanics?.version===1&&!(s.claws?.length||s.cars?.length||s.notes?.length||s.pSources?.length||s.oneWayWalls?.length||s.spikeTraps?.length)&&s.pSwitch===undefined&&(s.doors||[]).every(q=>q.style==='plain');
 if(room.mechanics||room.devices?.length||water&&!supportedWater)fail('Contraptions are not yet compatible with rewind, aquatic or castle adapters');
 validateCastleContraptionCompatibility(room);
 if(s.startingLives!==undefined&&!integer(s.startingLives,1,99))fail('Invalid initial life count');
 const ids=new Set([...room.map.geometry,...room.map.objects].map(q=>q.id));
 function id(q){if(!safeId(q.id)||ids.has(q.id))fail('Duplicate or invalid contraption ID');ids.add(q.id);}
 for(const k of ['tracks','claws','cars','notes','doors','pSources','oneWayWalls','spikeTraps'])if(s[k]!==undefined)list(s[k],k);
 validateRailClaws(room,s);validateClownCars(room,s);validateCoinCranes(room,s);validateChainChompGuards(room,s.chainChompGuards);
 for(const q of s.notes||[]){fields(q,['id','x','y','w','h','reward','playerBounceSpeed','heldBounceSpeed','enemyBounceSpeed','keySpeed','keyDelayFrames'],'note');id(q);rectangle(room,q,'Note');if(q.w!==16||q.h!==16||!['key','mushroom','none'].includes(q.reward))fail('Note content must be key, mushroom or none');for(const [k,a,b] of [['playerBounceSpeed',.1,12],['heldBounceSpeed',.1,12],['enemyBounceSpeed',.1,12],['keySpeed',.1,12]])if(q[k]!==undefined&&!finite(q[k],a,b))fail('Invalid note '+k);if(q.keyDelayFrames!==undefined&&!integer(q.keyDelayFrames,0,300))fail('Invalid key delay');}
 for(const o of room.map.objects)if(o.spikeTrap!==undefined&&(typeof o.spikeTrap!=='boolean'||o.kind!=='hazard'))fail('Intrinsic Spike Trap flag belongs to a visible hazard');
 const spikeIds=new Set();for(const q of s.spikeTraps||[]){fields(q,['id'],'spike trap');if(!safeId(q.id)||spikeIds.has(q.id)||!room.map.objects.some(o=>o.id===q.id&&o.kind==='hazard'))fail('Spike Trap needs a unique visible hazard object');spikeIds.add(q.id);}
 for(const q of s.doors||[]){fields(q,['id','pairId','style'],'door');if(!safeId(q.id)||!safeId(q.pairId)||!['key','plain'].includes(q.style)||!room.map.objects.some(o=>o.id===q.id&&o.kind==='portal'&&o.w===16&&o.h===32))fail('Door needs a paired native 16 by 32 portal');}
 if(s.pSwitch!==undefined){fields(s.pSwitch,['durationFrames'],'P switch');if(!integer(s.pSwitch.durationFrames,1,36000))fail('Invalid P duration');}
 for(const q of s.pSources||[]){fields(q,['id','pipeId','intervalFrames','initialDelayFrames','maxAlive','maxEmissions'],'P source');id(q);const p=room.map.geometry.find(g=>g.id===q.pipeId);if(!p||p.material!=='pipe'||p.w!==32||!integer(q.intervalFrames,1,36000)||!integer(q.initialDelayFrames,0,36000)||!integer(q.maxAlive,1,32)||(q.maxEmissions!==null&&!integer(q.maxEmissions,1,1000)))fail('P source needs a real pipe and valid supply limits');}
 for(const q of s.oneWayWalls||[]){fields(q,['id','x','y','w','h','direction'],'directional wall');id(q);rectangle(room,q,'Directional wall');if(!['down','up','left','right'].includes(q.direction)||q.w%16||q.h%16)fail('Directional walls use whole tiles and one crossing direction');}
}
export function validateContraptionPairs(rooms,{allowIncomplete=false}={}){
 const pairs=new Map();for(const r of rooms)for(const q of r.contraptions?.doors||[]){const p=r.map.objects.find(o=>o.id===q.id);if(!pairs.has(q.pairId))pairs.set(q.pairId,[]);pairs.get(q.pairId).push({r,q,p});}
 for(const rows of pairs.values()){if(rows.length!==2){if(allowIncomplete&&rows.every(a=>!rooms.some(r=>r.roomId===a.p.targetRoom)))continue;fail('Each authored door pair must have exactly two endpoints');}for(const a of rows){const b=rows.find(b=>b!==a);if(a.p.targetRoom!==b.r.roomId||!b.r.map.objects.some(o=>o.id===a.p.targetSpawn&&o.kind==='spawn'))fail('Door pair target is missing or mismatched');}}
}

export function createContraptionsCourse(rooms,{emit=()=>{}}={}){
 const authoredP=rooms.some(r=>r.smm2Mechanics?.pSwitches?.length);if(!authoredP&&!rooms.some(r=>r.contraptions))return null;
 const roomById=new Map(rooms.map(r=>[r.roomId,r]));let keys=0,pFrames=0,lastTick=null;const keyFollowers=createKeyFollowers();
 const spent=new Set(),removedBricks=new Set(),unlocked=new Set(),bumps=new Map(),sources=new Map(),pressedP=new Map(),consumedP=new Set();let contactFrames=new WeakMap();
 const token=(roomId,id)=>roomId+'\n'+id;
 const event=(name,data={})=>emit('contraption',{event:name,...data});
 const initialLives=rooms.find(r=>r.contraptions?.startingLives)?.contraptions.startingLives??3;
 function frame({tick}={}){if(lastTick===tick)return;lastTick=tick;if(pFrames>0&&--pFrames===0){emit('sound',{event:'bump'});event('p-expired');}for(const [id,q]of pressedP)if(--q.remaining<=0){q.item.dead=true;q.item.removed=true;if(q.item.smm2PSwitch)q.item.smm2PSwitch.phase='removed';pressedP.delete(id);}for(const [id,n]of bumps)if(n>1)bumps.set(id,n-1);else bumps.delete(id);}
 function isConvertibleBrick(roomId,q){const room=roomById.get(roomId),source=room?.map.geometry.find(g=>g.id===(q.sourceId||q.id));return !!room&&(authoredP||!!room.contraptions)&&q.material==='brick'&&!q.used&&!blockContent(q)&&!blockContent(source)&&!room.markers?.some(m=>m.x===q.x&&m.y===q.y&&m.source?.contents)&&!room.semantics?.some(s=>s.id===(q.sourceId||q.id)&&s.source?.contents);}
 function isPinkCoin(room,q){return (room.smm2Mechanics?.pinkCoins||[]).some(p=>p.id===q.id);}
 function geometry(roomId,base,items=[]){
  const room=roomById.get(roomId),s=room?.contraptions||{};if(!room||!authoredP&&!room.contraptions)return base;
  const result=base.filter(q=>!q.contraptionDevice&&!removedBricks.has(token(roomId,q.id))).map(q=>q.pConverted?{...q,hidden:!!q.pOriginalHidden,collision:q.pOriginalCollision??q.collision,pConverted:false}:q);
  // Hidden blocks intentionally still receive upward head contacts. A converted
  // brick is a coin, so its dormant original must have no collision body at all.
  if(pFrames>0){for(let n=0;n<result.length;n++){const q=result[n];if(isConvertibleBrick(roomId,q))result[n]={...q,pConverted:true,pOriginalHidden:!!q.hidden,pOriginalCollision:q.collision,collision:'none',hidden:true};}for(const q of room.map.objects)if(q.kind==='coin'&&!isPinkCoin(room,q)&&!spent.has(token(roomId,q.id)))result.push({...q,id:'p-coin-'+q.id,sourceCoinId:q.id,collision:'solid',material:'brick',contraptionDevice:true,pCoin:true});}
  for(const o of room.map.objects.filter(o=>o.spikeTrap===true||(s.spikeTraps||[]).some(q=>q.id===o.id))){result.push({...copy(o),collision:'solid',material:'contraption-spike',contraptionDevice:true,spikeTrap:true});}
  for(const q of s.notes||[])result.push({...q,collision:'solid',material:'contraption-note',contraptionDevice:true,bump:bumps.get(token(roomId,q.id))||0,spent:spent.has(token(roomId,q.id))});
  for(const q of items)if(q.kind==='p-switch'&&!q.smm2PSwitch&&!q.dead&&!q.clawHeld)result.push({id:'p-body-'+q.id,x:q.x,y:q.y,w:q.w,h:q.h,collision:'oneway',contraptionDevice:true,pBody:true});
  return result;
 }
 function objects(roomId,base,geometry){const room=roomById.get(roomId);if(!room||!authoredP&&!room.contraptions)return base;const result=base.filter(o=>!(o.kind==='coin'&&(pFrames>0&&!isPinkCoin(room,o)||spent.has(token(roomId,o.id)))));if(pFrames>0)for(const q of geometry)if(q.pConverted&&!removedBricks.has(token(roomId,q.id)))result.push({id:'p-brick-coin-'+q.id,kind:'coin',x:q.x,y:q.y,w:q.w,h:q.h,sourceBrickId:q.id});return result;}
 function isSpikeTrap(roomId,id){const r=roomById.get(roomId);return !!r?.map.objects.some(o=>o.id===id&&o.spikeTrap===true)||(r?.contraptions?.spikeTraps||[]).some(q=>q.id===id);}
 function spikePlayerContact(roomId,o,player){if(!isSpikeTrap(roomId,o.id))return false;const e=.01;return player.x+player.w>=o.x-e&&player.x<=o.x+o.w+e&&player.y+player.h>=o.y-e&&player.y<=o.y+o.h+e;}
 function collectCoin(roomId,q){if(q.sourceBrickId){removedBricks.add(token(roomId,q.sourceBrickId));event('p-brick-collected',{roomId,deviceId:q.sourceBrickId});}else spent.add(token(roomId,q.id));}
 function releaseContent(roomId,note,items,actorKind){const key=token(roomId,note.id);if(spent.has(key)||note.reward==='none')return;spent.add(key);const item={id:'note-item-'+note.id,kind:note.reward,x:note.x+1,y:note.y+note.h,w:14,h:14,vx:note.reward==='mushroom'?.5:0,vy:0,age:0,dead:false,noteSource:note.id,...(note.reward==='key'?{keyDelay:note.keyDelayFrames??CONTRAPTION_DEFAULTS.keyDelayFrames,keySpeed:note.keySpeed??CONTRAPTION_DEFAULTS.keySpeed}:{})};items.push(item);emit('sound',{event:'appear'});event('note-content',{roomId,deviceId:note.id,itemId:item.id,item:item.kind,actorKind});}
 function bounce(roomId,actor,note,{kind='player',input={},tick,items=[]}={}){
  const prior=contactFrames.get(actor);if(prior?.tick===tick&&prior.id===note.id)return false;
  actor.vy=-(kind==='player'?(input.jump?(note.heldBounceSpeed??CONTRAPTION_DEFAULTS.noteHeldBounce):(note.playerBounceSpeed??CONTRAPTION_DEFAULTS.notePlayerBounce)):(note.enemyBounceSpeed??CONTRAPTION_DEFAULTS.noteEnemyBounce));actor.grounded=false;actor.support=null;if(Object.hasOwn(actor,'jumpBuffer'))actor.jumpBuffer=0;contactFrames.set(actor,{tick,id:note.id});bumps.set(token(roomId,note.id),12);emit('sound',{event:'jump'});event('note-bounce',{roomId,deviceId:note.id,actorId:actor.id||kind,actorKind:kind});
  releaseContent(roomId,note,items,kind);return true;
 }
 function afterActor(roomId,actor,before,context={}){
  const s=roomById.get(roomId)?.contraptions;if(!s||actor.dead||actor.dying||actor.emerge||actor.clawHeld||actor.vehicleId)return;
  for(const q of s.oneWayWalls||[]){let hit=false;if(q.direction==='down'&&actor.y<before.y&&before.y>=q.y+q.h-.01&&actor.y<q.y+q.h&&actor.x+actor.w>q.x&&actor.x<q.x+q.w){actor.y=q.y+q.h;actor.vy=0;hit=true;}else if(q.direction==='up'&&actor.y>before.y&&before.y+before.h<=q.y+.01&&actor.y+actor.h>q.y&&actor.x+actor.w>q.x&&actor.x<q.x+q.w){actor.y=q.y-actor.h;actor.vy=0;actor.grounded=true;actor.support=null;hit=true;}else if(q.direction==='left'&&actor.x>before.x&&before.x+before.w<=q.x+.01&&actor.x+actor.w>q.x&&actor.y+actor.h>q.y&&actor.y<q.y+q.h){actor.x=q.x-actor.w;actor.vx=0;hit=true;}else if(q.direction==='right'&&actor.x<before.x&&before.x>=q.x+q.w-.01&&actor.x<q.x+q.w&&actor.y+actor.h>q.y&&actor.y<q.y+q.h){actor.x=q.x+q.w;actor.vx=0;hit=true;}if(hit)event('one-way-stop',{roomId,deviceId:q.id,actorId:actor.id||context.kind});}
  for(const note of s.notes||[]){if(before.y+before.h<=note.y+1.01&&before.vy>=0&&actor.x+actor.w>note.x&&actor.x<note.x+note.w&&Math.abs(actor.y+actor.h-note.y)<.01){bounce(roomId,actor,note,context);break;}const sideContact=actor.y+actor.h>note.y&&actor.y<note.y+note.h&&((before.x+before.w<=note.x+.01&&before.vx>0&&Math.abs(actor.x+actor.w-note.x)<.01)||(before.x>=note.x+note.w-.01&&before.vx<0&&Math.abs(actor.x-note.x-note.w)<.01));if(sideContact){bumps.set(token(roomId,note.id),12);releaseContent(roomId,note,context.items||[],context.kind||'actor');break;}}
 }
 function bumpNote(roomId,id,items=[]){const q=roomById.get(roomId)?.contraptions?.notes?.find(q=>q.id===id);if(!q)return false;bumps.set(token(roomId,id),12);emit('sound',{event:'bump'});event('note-head-bump',{roomId,deviceId:id});releaseContent(roomId,q,items,'head');return true;}
 function stepKey(roomId,item,player){if(item.kind!=='key'||item.dead)return false;if(item.keyDelay>0){item.keyDelay--;return true;}const dx=player.x+player.w/2-item.x-item.w/2,dy=player.y+player.h/2-item.y-item.h/2,d=Math.hypot(dx,dy),speed=item.keySpeed??CONTRAPTION_DEFAULTS.keySpeed;if(d>0){item.x+=dx/d*Math.min(speed,d);item.y+=dy/d*Math.min(speed,d);}item.age++;if(overlap(player,item)){item.dead=true;keys++;keyFollowers.collect(roomId,item,player);emit('sound',{event:'pickup'});event('key-collected',{roomId,itemId:item.id,keys});}return true;}
 function activateP(roomId,item,{contact}={}){if(!item||item.dead||item.kind!=='p-switch'||!item.smm2PSwitch||item.smm2PSwitch.phase!=='pressed'||!roomById.get(roomId)?.smm2Mechanics?.pSwitches?.some(q=>q.id===item.id)||consumedP.has(token(roomId,item.id)))return false;const key=token(roomId,item.id);consumedP.add(key);pFrames=roomById.get(roomId)?.contraptions?.pSwitch?.durationFrames??CONTRAPTION_DEFAULTS.pDurationFrames;pressedP.set(key,{item,remaining:pFrames});emit('sound',{event:'bump'});event('p-pressed',{roomId,itemId:item.id,frames:pFrames,orientation:item.smm2PSwitch.orientation,contact});return true;}
 function restoreP(roomId,item){if(item?.smm2PSwitch&&consumedP.has(token(roomId,item.id))){item.dead=true;item.removed=true;item.smm2PSwitch.phase='removed';}return item;}
 function pressP(roomId,player,before,items){for(const item of items)if(item.kind==='p-switch'&&!item.smm2PSwitch&&!item.dead&&!item.pressed&&!item.clawHeld&&before.vy>=0&&before.y+before.h<=item.y+1.1&&player.x+player.w>item.x&&player.x<item.x+item.w&&Math.abs(player.y+player.h-item.y)<1.1){item.pressed=true;item.y+=item.h-4;item.h=4;item.vx=item.vy=0;pFrames=roomById.get(roomId)?.contraptions?.pSwitch?.durationFrames??CONTRAPTION_DEFAULTS.pDurationFrames;emit('sound',{event:'bump'});event('p-pressed',{roomId,itemId:item.id,frames:pFrames});return true;}return false;}
 function spawnP(roomId,items,geometry,{tick}={}){const room=roomById.get(roomId),result=[];for(const q of room?.contraptions?.pSources||[]){const key=token(roomId,q.id);let st=sources.get(key);if(!st){st={clock:q.initialDelayFrames,emitted:0,lastTick:null};sources.set(key,st);}if(st.lastTick===tick)continue;st.lastTick=tick;if(st.clock>0){st.clock--;continue;}if((q.maxEmissions!==null&&st.emitted>=q.maxEmissions)||[...items,...result].filter(i=>!i.dead&&!i.pressed&&i.pSource===q.id).length>=q.maxAlive)continue;const pipe=room.map.geometry.find(g=>g.id===q.pipeId),item={id:'p-source-'+q.id+'-'+st.emitted,kind:'p-switch',x:pipe.x+8,y:pipe.y-16,w:16,h:16,vx:0,vy:0,age:0,dead:false,pSource:q.id};if(geometry.some(g=>!g.hidden&&g.collision==='solid'&&overlap(g,item)))continue;result.push(item);st.emitted++;st.clock=q.intervalFrames-1;emit('sound',{event:'appear'});event('p-source',{roomId,sourceId:q.id,itemId:item.id});}return result;}
 function useDoor(roomId,portal,player,input){const q=roomById.get(roomId)?.contraptions?.doors?.find(q=>q.id===portal.id);if(!q)return {handled:false};if(!player.grounded||Math.abs(player.y+player.h-portal.y-portal.h)>4||!(input.upPressed||input.interactPressed)||!overlap({...player,x:player.x-2,w:player.w+4,h:player.h+2},portal))return {handled:true};if(q.style==='key'&&!unlocked.has(q.pairId)){if(keys<=0){emit('sound',{event:'bump'});event('door-locked',{roomId,deviceId:q.id});return {handled:true};}keys--;keyFollowers.consume(portal);unlocked.add(q.pairId);emit('sound',{event:'pickup'});event('door-unlocked',{roomId,deviceId:q.id,pairId:q.pairId,keys});}event('door-enter',{roomId,deviceId:q.id,targetRoom:portal.targetRoom});return {handled:true,enter:true,targetRoom:portal.targetRoom,targetSpawn:portal.targetSpawn};}
 function resetRoom(roomId){for(const q of roomById.get(roomId)?.contraptions?.pSources||[])sources.delete(token(roomId,q.id));}
 function reset(){keys=0;pFrames=0;lastTick=null;keyFollowers.reset();spent.clear();removedBricks.clear();unlocked.clear();bumps.clear();sources.clear();pressedP.clear();consumedP.clear();contactFrames=new WeakMap();}
 function view(roomId){const r=roomById.get(roomId),s=r?.contraptions||{};if(!r||!authoredP&&!r.contraptions)return null;return {version:1,keys,keyFollowers:keyFollowers.view(roomId),pFrames,scene:s.scene,notes:(s.notes||[]).map(q=>({...q,spent:spent.has(token(roomId,q.id)),bump:bumps.get(token(roomId,q.id))||0})),doors:(s.doors||[]).map(q=>({...r.map.objects.find(o=>o.id===q.id),...q,unlocked:q.style==='plain'||unlocked.has(q.pairId)})),oneWayWalls:copy(s.oneWayWalls||[]),pSources:(s.pSources||[]).map(q=>({...q,...sources.get(token(roomId,q.id))})),spent:[...spent],removedBricks:[...removedBricks],unlockedPairs:[...unlocked]};}
 return Object.freeze({initialLives,frame,frameKeyFollowers:keyFollowers.frame,enterKeyFollowers:keyFollowers.enter,geometry,objects,isSpikeTrap,spikePlayerContact,collectCoin,afterActor,bumpNote,stepKey,pressP,activateP,restoreP,spawnP,useDoor,resetRoom,reset,view,destroyBrick:(roomId,id)=>removedBricks.add(token(roomId,id)),isDoor:(roomId,id)=>(roomById.get(roomId)?.contraptions?.doors||[]).some(q=>q.id===id)});
}
