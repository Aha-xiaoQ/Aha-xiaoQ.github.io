/** Standalone source-arrow authoring. Markers remain visual guides, with no
 * native collision body, physics leaf, or coin-style placement restriction. */
import {uid, validate, linked} from './editor-model.mjs';
import {isSmwUnderwaterRoom} from './editor-smw-underwater-art.mjs';

export const DIRECTION_ARROW_DIRECTIONS = Object.freeze(['right', 'down-right', 'down', 'down-left', 'left', 'up-left', 'up', 'up-right']);
export const DIRECTION_ARROW_STYLES = Object.freeze(['smw-observed-arrow', 'smw-observed-floating-arrow']);
const GROUND = DIRECTION_ARROW_STYLES[0], FLOATING = DIRECTION_ARROW_STYLES[1];
const plain = q => !!q && typeof q === 'object' && !Array.isArray(q) && [Object.prototype, null].includes(Object.getPrototypeOf(q));
const arrows = room => (room.markers || []).filter(q => q.kind === 'source-arrow');
function fields(q, allowed, label) {
  if (!plain(q)) throw new TypeError('Invalid ' + label);
  for (const key of Reflect.ownKeys(q)) if (typeof key !== 'string' || !allowed.includes(key)) throw new TypeError('Unknown ' + label + ' field: ' + String(key));
  for (const key of allowed) if (!Object.hasOwn(q, key)) throw new TypeError('Missing ' + label + ' field: ' + key);
}
function safeId(id) {
  if (typeof id !== 'string' || id.length > 100 || !/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(id) || ['constructor', 'prototype'].includes(id)) throw new TypeError('Invalid direction arrow identifier');
}
function options(q) {
  fields(q, ['x', 'y', 'w', 'h', 'direction', 'signArt'], 'direction arrow authoring');
  if (!['x', 'y', 'w', 'h'].every(k => Number.isFinite(q[k])) || q.x < 0 || q.y < 0 || q.w < 4 || q.h < 4 || q.w > 96 || q.h > 96) throw new TypeError('Direction arrow coordinates and size must be finite, with size 4..96 pixels');
  if (!DIRECTION_ARROW_DIRECTIONS.includes(q.direction)) throw new TypeError('Unsupported direction arrow direction');
  if (!DIRECTION_ARROW_STYLES.includes(q.signArt)) throw new TypeError('Unsupported direction arrow source style');
  if (q.signArt === GROUND && (q.direction !== 'right' || q.w !== 48 || q.h !== 48)) throw new TypeError('The observed ground sign is a right-facing 48 × 48 raster');
}
function savedOptions(q) {
  if (!q || q.kind !== 'source-arrow' || !plain(q.source)) throw new TypeError('Choose an existing source-arrow marker');
  const signArt = q.source.signArt ?? FLOATING, value = {x: q.x, y: q.y, w: q.w ?? (signArt === GROUND ? 48 : 20), h: q.h ?? (signArt === GROUND ? 48 : 20), direction: q.source.direction ?? 'right', signArt};
  options(value); return value;
}
function identifiers(room) {
  const ids = new Set(), seen = new WeakSet();
  const visit = value => {if (!value || typeof value !== 'object' || seen.has(value)) return; seen.add(value); if (typeof value.id === 'string') ids.add(value.id); for (const child of Object.values(value)) visit(child);};
  visit(room); return ids;
}
function unused(room, id, existing) {
  safeId(id);
  const rest = structuredClone(room);
  if (existing) {
    rest.markers = rest.markers.filter(q => q.kind !== 'source-arrow' || q.id !== id);
    // The real marker has already been checked for duplicates below. Its
    // optional same-ID semantic entry is provenance, rather than another body.
    rest.semantics = (rest.semantics || []).filter(q => q.id !== id);
  }
  if (identifiers(rest).has(id)) throw new Error('Direction arrow needs an unused standalone marker ID');
  if ((room.map.geometry || []).some(q => linked({id, kind: 'source-arrow'}, q.id))) throw new Error('Direction arrow cannot be a linked native geometry marker');
}
function check(room, id, value, existing) {
  if (!isSmwUnderwaterRoom(room)) throw new Error('Apply the existing SMW underwater source art profile before authoring direction arrows');
  options(value); unused(room, id, existing);
  if (value.x + value.w > room.map.width || value.y + value.h > room.map.height) throw new Error('Direction arrow must stay inside the room');
}
function edit(room, operation) {
  const next = structuredClone(room), result = operation(next);
  validate({format: 'xiaoq-map-project', version: 1, id: 'direction-arrow-authoring-check', title: 'Direction guide authoring', rooms: [next]},{allowIncompleteCompletionMarks:true});
  for (const key of Object.keys(room)) if (!Object.hasOwn(next, key)) delete room[key];
  Object.assign(room, next); return result;
}
function replace(room, id, value) {
  const found = arrows(room).filter(q => q.id === id);
  if (found.length > 1) throw new Error('Duplicate direction arrow marker ID');
  const previous = found[0]; check(room, id, value, previous);
  const {direction, signArt, ...bounds} = value;
  const source = {...previous?.source, direction, signArt};
  if (Object.hasOwn(source, 'facing')) source.facing = direction.endsWith('left') ? 'left' : 'right';
  const marker = {...previous, id, kind: 'source-arrow', ...bounds, source};
  const index = room.markers.findIndex(q => q.id === id);
  if (index < 0) room.markers.push(marker); else room.markers[index] = marker;
  return id;
}

/** Full add/update; the existing marker ID and unrelated source metadata stay. */
export function setDirectionArrow(room, id, value) {options(value); return edit(room, next => replace(next, id, structuredClone(value)));}
export function removeDirectionArrow(room, id) {
  safeId(id);
  if (!arrows(room).some(q => q.id === id)) return false;
  return edit(room, next => {
    const list = arrows(next).filter(q => q.id === id); if (list.length !== 1) throw new Error('Duplicate direction arrow marker ID');
    check(next, id, savedOptions(list[0]), list[0]);
    next.markers = next.markers.filter(q => q.id !== id);
    // Preserve semantic provenance and every unrelated native marker.
    return true;
  });
}
/** Clone the saved guide, with a fresh standalone ID at an explicit position. */
export function cloneDirectionArrow(room, sourceId, newId, position) {
  fields(position, ['x', 'y'], 'direction arrow clone position'); safeId(sourceId); safeId(newId);
  return edit(room, next => {
    const list = arrows(next).filter(q => q.id === sourceId); if (list.length !== 1) throw new Error('Choose one existing direction arrow');
    const original = list[0], value = savedOptions(original); check(next, sourceId, value, original); unused(next, newId);
    const id = replace(next, newId, {...value, ...position}), copy = next.markers.find(q => q.id === id);
    copy.source = {...structuredClone(original.source), ...copy.source}; return id;
  });
}
/** One atomic translation, including marker/source consistency and bounds. */
export function moveDirectionArrows(room, ids, dx, dy) {
  if (!(ids instanceof Set) || !Number.isFinite(dx) || !Number.isFinite(dy)) throw new TypeError('Invalid direction arrow selection or translation');
  if (!ids.size) return false;
  return edit(room, next => {
    for (const id of ids) {safeId(id); const list = arrows(next).filter(q => q.id === id); if (list.length !== 1) throw new Error('Choose existing direction arrows only'); const q = savedOptions(list[0]); replace(next, id, {...q, x: q.x + dx, y: q.y + dy});}
    return true;
  });
}

const directionLabels = ['→ 右', '↘ 右下', '↓ 下', '↙ 左下', '← 左', '↖ 左上', '↑ 上', '↗ 右上'];
const numberInput = (key, text) => '<label>' + text + '<input type="number" step="any" data-direction-arrow="' + key + '"></label>';
/** Small guide-only panel. The host owns actual History and persistent save. */
export function mountDirectionArrowTools({parent, room, change, report = () => {}}) {
  const dom = parent.ownerDocument || document, panel = dom.createElement('details'); panel.id = 'direction-arrow-tools'; parent.append(panel);
  panel.innerHTML = '<summary>方向箭头指引</summary><p class="small">使用已接入的 SMW 水下素材。箭头只作方向指引，不碰撞；浮空箭头可放在空中。坐标为标记左上角，尺寸随工程保存。</p>' +
    '<label>已有指引<select data-direction-arrow="marker"></select></label><button type="button" data-direction-arrow="new">填写新箭头</button><label>稳定 ID<input type="text" data-direction-arrow="id"></label>' +
    '<label>已支持的素材<select data-direction-arrow="signArt"><option value="' + FLOATING + '">浮空箭头</option><option value="' + GROUND + '">原起点路牌（48 × 48，向右）</option></select></label>' +
    '<label>方向<select data-direction-arrow="direction">' + DIRECTION_ARROW_DIRECTIONS.map((q, i) => '<option value="' + q + '">' + directionLabels[i] + '</option>').join('') + '</select></label>' +
    numberInput('x', 'X（像素）') + numberInput('y', 'Y（像素）') + numberInput('w', '宽度（像素，4–96）') + numberInput('h', '高度（像素，4–96）') +
    '<button type="button" data-direction-arrow="apply">放置 / 更新指引</button><button type="button" data-direction-arrow="remove">删除所选指引</button><div class="row">' +
    [['left', '← 移一格'], ['right', '→ 移一格'], ['up', '↑ 移一格'], ['down', '↓ 移一格']].map(([q, label]) => '<button type="button" data-direction-arrow="move-' + q + '">' + label + '</button>').join('') + '</div>' +
    '<label>复制的新 ID<input type="text" data-direction-arrow="clone-id"></label>' + numberInput('clone-x', '复制 X') + numberInput('clone-y', '复制 Y') + '<button type="button" data-direction-arrow="clone">复制已保存指引</button><p class="small" role="status" data-direction-arrow="status"></p>';
  const get = key => panel.querySelector('[data-direction-arrow="' + key + '"]');
  const fresh = () => {const ids = identifiers(room()); let id; do {id = uid();} while (ids.has(id)); return id;};
  const number = key => {const raw = String(get(key).value).trim(); if (!raw || !Number.isFinite(Number(raw))) throw new Error('请填写有限数字：' + key); return Number(raw);};
  let current = '', newMode = true, lastRoom = null, loaded = '', error = '';
  function styleFields() {const ground = get('signArt').value === GROUND; if (ground) {get('w').value = '48'; get('h').value = '48'; get('direction').value = 'right';} get('w').disabled = get('h').disabled = get('direction').disabled = ground;}
  function populate(value, id) {get('id').value = id; for (const [key, q] of Object.entries(value)) get(key).value = String(q); get('clone-id').value = fresh(); get('clone-x').value = String(Math.min(room().map.width - value.w, value.x + 32)); get('clone-y').value = String(value.y); styleFields();}
  function seed() {populate({x: 32, y: 32, w: 24, h: 24, direction: 'right', signArt: FLOATING}, fresh());}
  function attempt(operation, success = () => {}) {try {let result; change(() => {result = operation();}); success(result); error = ''; loaded = '';} catch (failure) {error = failure.message; report(error); loaded = '';} refresh();}
  get('signArt').onchange = () => {if (get('signArt').value === FLOATING) {get('w').value = '24'; get('h').value = '24';} styleFields();};
  get('new').onclick = () => {current = ''; newMode = true; loaded = 'new'; error = ''; seed(); refresh();};
  get('marker').onchange = () => {current = get('marker').value; newMode = !current; loaded = ''; error = ''; if (newMode) seed(); refresh();};
  get('apply').onclick = () => attempt(() => {const id = newMode ? get('id').value.trim() : current; if (newMode && identifiers(room()).has(id)) throw new Error('新箭头需要未使用的 ID'); return setDirectionArrow(room(), id, {x: number('x'), y: number('y'), w: number('w'), h: number('h'), direction: get('direction').value, signArt: get('signArt').value});}, id => {current = id; newMode = false;});
  get('remove').onclick = () => attempt(() => removeDirectionArrow(room(), current), () => {current = ''; newMode = true; seed();});
  get('clone').onclick = () => attempt(() => cloneDirectionArrow(room(), current, get('clone-id').value.trim(), {x: number('clone-x'), y: number('clone-y')}), id => {current = id; newMode = false;});
  for (const [direction, dx, dy] of [['left', -16, 0], ['right', 16, 0], ['up', 0, -16], ['down', 0, 16]]) get('move-' + direction).onclick = () => attempt(() => moveDirectionArrows(room(), new Set([current]), dx, dy));
  function refresh() {
    const r = room(), changedRoom = lastRoom !== r, list = arrows(r).filter(q => {try {savedOptions(q); return true;} catch {return false;}}), enabled = isSmwUnderwaterRoom(r);
    if (changedRoom) {if (!list.some(q => q.id === current)) {current = list[0]?.id || ''; newMode = !current;} loaded = '';}
    if (!newMode && !list.some(q => q.id === current)) {current = list[0]?.id || ''; newMode = !current; loaded = '';}
    const blank = dom.createElement('option'); blank.value = ''; blank.textContent = '新箭头'; get('marker').replaceChildren(blank, ...list.map(q => {const option = dom.createElement('option'); option.value = q.id; option.textContent = q.id + ' · ' + (q.source.direction || 'right'); return option;})); get('marker').value = newMode ? '' : current;
    const q = list.find(q => q.id === current), signature = !newMode && q ? JSON.stringify(q) : 'new';
    if (loaded !== signature) {if (!newMode && q) populate(savedOptions(q), q.id); else if (!get('id').value || changedRoom) seed(); loaded = signature;}
    get('id').readOnly = !newMode; get('apply').disabled = get('new').disabled = !enabled; get('clone').disabled = get('remove').disabled = !enabled || newMode || !q;
    for (const key of ['left', 'right', 'up', 'down']) get('move-' + key).disabled = !enabled || newMode || !q;
    get('status').textContent = error || (!enabled ? '先在「图像风格」中选择 SMW 水下，再点击「应用图像风格」。' : !newMode && q ? '已保存 ' + q.id + '；复制使用已保存的方向与素材。可用撤销 / 重做恢复。' : '填写坐标、尺寸和方向后放置。'); lastRoom = r;
  }
  refresh(); return Object.freeze({panel, refresh});
}
