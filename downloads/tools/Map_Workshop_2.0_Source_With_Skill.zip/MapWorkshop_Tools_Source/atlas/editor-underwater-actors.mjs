/** Explicit opt-in motion for the observed normal-Underwater SMW bodies.
 * Fish Bones: blue cruise -> red alert hold -> accelerating FIXED aimed charge
 * -> breakup on actual solid contact. Thin one-way surfaces do not break them.
 * Galoombas: unwinged idle bob/near-player approach, bounded author fits, with
 * actual solid-body resolution. Giant pursuit and buoyancy remain unverified.
 * Empty Buzzy: local shallow ballistic fit on the SAME native empty shell.
 *
 * Positions are moved here exactly once per actor/tick; the host must omit its
 * ordinary movement branch when stepActor returns true. Emergence, Mario,
 * helmet equip/loss, attacks, scoring and source emission remain host-owned.
 * All motion numbers, sensor radii, target sample times and contact policies
 * are explicit authored approximations, never claimed Nintendo constants.
 * No defaults are inserted into documents. No source timeline controls actors.
 */
export const UNDERWATER_ACTORS_VERSION = 1;
const EPS = 1e-7;
const copy = value => structuredClone(value);
const fail = message => {throw new TypeError(message);};
const plain = value => !!value && typeof value === 'object' && !Array.isArray(value) && [Object.prototype, null].includes(Object.getPrototypeOf(value));
const finite = (value, min, max) => Number.isFinite(value) && value >= min && value <= max;
const integer = (value, min, max) => Number.isSafeInteger(value) && finite(value, min, max);
const safeId = value => typeof value === 'string' && value.length <= 100 && /^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(value) && !['constructor', 'prototype'].includes(value);
const body = value => !!value && ['x', 'y', 'w', 'h'].every(key => Number.isFinite(value[key])) && value.w > 0 && value.h > 0;
const pose = value => ({x: value.x, y: value.y, w: value.w, h: value.h});
const live = value => !!value && !value.dead && !value.dying && !value.removed && !value.hidden;
const nativeType = value => typeof value === 'string' ? value.replace(/^(?:enemy-|marker-)/, '').toLowerCase() : null;
const overlap = (a, b) => a.x + a.w > b.x + EPS && a.x < b.x + b.w - EPS && a.y + a.h > b.y + EPS && a.y < b.y + b.h - EPS;
const center = value => ({x: value.x + value.w / 2, y: value.y + value.h / 2});
const approach = (value, target, acceleration) => value + Math.max(-acceleration, Math.min(acceleration, target - value));
const fishFields = ['cruiseVx', 'alertRadius', 'alertFrames', 'aimSample', 'chargeInitialSpeed', 'chargeAcceleration', 'chargeMaxSpeed', 'blueContactPolicy'];
const galoombaFields = ['idleBobAmplitude', 'idleBobPeriodFrames', 'idleBobPhaseFrames', 'approachRadius', 'approachAcceleration', 'approachMaxSpeed', 'approachVerticalCap', 'solidResponse'];
const shellFields = ['initialVx', 'initialVy', 'gravity', 'maxFallSpeed', 'horizontalRestitution'];
function fields(value, allowed, required, label) {
  if (!plain(value)) fail(`Invalid ${label}`);
  for (const key of Object.keys(value)) if (!allowed.includes(key)) fail(`Unknown ${label} field: ${key}`);
  for (const key of required) if (!Object.hasOwn(value, key)) fail(`Missing ${label} field: ${key}`);
}
const allFields = (value, keys, label) => fields(value, keys, keys, label);

/** Validate this leaf only; the enclosing importer owns siblings and sources.
 * Limits below protect editor/runtime bounds and do not imply original limits.
 */
export function validateUnderwaterActorsRoom(room, spec = room?.smm2Mechanics?.underwaterActors) {
  if (spec === undefined) return;
  allFields(spec, ['version', 'profiles'], 'underwater actors');
  if (spec.version !== UNDERWATER_ACTORS_VERSION || !Array.isArray(spec.profiles) || spec.profiles.length > 256) fail('Invalid underwater actors v1 profile list');
  const map = room?.map;
  if (!plain(map) || !finite(map.width, 16, 32768) || !finite(map.height, 16, 4096) || !Array.isArray(map.objects) || !Array.isArray(map.geometry)) fail('Underwater actors need bounded native room geometry and objects');
  if (typeof room.setting !== 'string' || !/Underwater/.test(room.setting) || room.underwater === false || /night/i.test(room.setting) || room.night === true) fail('Underwater actors require an explicit normal Underwater setting');
  if (room.mechanics !== undefined || room.devices?.length) fail('Underwater actor rewind is unsupported');
  const seen = new Set(), mechanics = room.smm2Mechanics || {};
  for (const q of spec.profiles) {
    fields(q, ['id', 'sourceId', 'kind', 'motion', 'size'], ['kind', 'motion'], 'underwater actor profile');
    const byId = Object.hasOwn(q, 'id'), bySource = Object.hasOwn(q, 'sourceId');
    if (byId === bySource || !safeId(byId ? q.id : q.sourceId)) fail('Underwater profile needs exactly one safe native id or sourceId');
    const key = `${byId ? 'actor' : 'source'}:${byId ? q.id : q.sourceId}`;
    if (seen.has(key)) fail('Duplicate underwater actor target');
    seen.add(key);
    if (!['fish-bone', 'galoomba', 'beetle-shell'].includes(q.kind)) fail('Unsupported underwater actor kind');
    if (q.kind === 'galoomba' ? !['small', 'giant'].includes(q.size) : Object.hasOwn(q, 'size')) fail('Only Galoomba profiles need explicit small/giant size');
    if (byId) {
      const actor = map.objects.find(actor => actor.id === q.id);
      if (map.objects.filter(actor => actor.id === q.id).length !== 1 || map.geometry.some(g => g.id === q.id) || actor?.kind !== 'walker' || !body(actor) || !finite(actor.w, 1, 128) || !finite(actor.h, 1, 128) || !finite(actor.x, 0, map.width - actor.w) || !finite(actor.y, 0, map.height - actor.h)) fail('Underwater profile needs one bounded existing native walker');
      const type = nativeType(room.enemySkins?.[q.id] ?? room.markers?.find(m => m.id === q.id)?.kind ?? actor.type ?? 'walker');
      const permitted = q.kind === 'fish-bone' ? ['walker', 'fish-bone', 'fishbone'] : q.kind === 'galoomba' ? ['walker', 'goomba', 'galoomba'] : ['walker', 'beetle', 'beetle-shell'];
      if (!permitted.includes(type)) fail('Underwater profile cannot change an incompatible native variant');
      const owned = ['thwomps', 'shoes', 'boneShells', 'placedItems'].some(name => mechanics[name]?.some(a => a.id === q.id)) || mechanics.parachuteActors?.actors?.some(a => a.id === q.id) || mechanics.localUpdrafts?.twisters?.some(a => a.id === q.id) || room.aquatic?.enemyProfiles?.[q.id] !== undefined || room.marioModules?.enemyVariants?.[q.id] !== undefined;
      if (owned) fail('Underwater profile cannot own another actor motion controller');
    } else {
      const sources = room.marioModules?.enemySources?.filter(source => source.id === q.sourceId) || [];
      if (sources.length !== 1 || sources[0].enemy !== q.kind || sources[0].shoeTemplateId !== undefined || sources[0].actorVariant !== undefined) fail('Underwater sourceId needs one existing matching native enemy source');
    }
    if (q.kind === 'fish-bone') {
      fields(q.motion,[...fishFields,'sensorFacing'],fishFields,'Fish Bone motion');
      if(q.motion.sensorFacing!==undefined&&!['forward','any'].includes(q.motion.sensorFacing))fail('Invalid explicit Fish Bone facing gate');
      const m = q.motion;
      if (!finite(m.cruiseVx, -4, 4) || m.cruiseVx === 0 || !finite(m.alertRadius, 1, 1024) || !integer(m.alertFrames, 1, 600) || !['alert-start', 'charge-start'].includes(m.aimSample) || !finite(m.chargeInitialSpeed, 0, 16) || !finite(m.chargeAcceleration, .000001, 4) || !finite(m.chargeMaxSpeed, .001, 64) || m.chargeInitialSpeed > m.chargeMaxSpeed || !['reverse', 'stop', 'slide'].includes(m.blueContactPolicy)) fail('Invalid explicit Fish Bone motion or unverified blue contact policy');
    } else if (q.kind === 'galoomba') {
      allFields(q.motion, galoombaFields, 'Galoomba motion');
      const m = q.motion;
      if (!finite(m.idleBobAmplitude, 0, 16) || !integer(m.idleBobPeriodFrames, 8, 36000) || !finite(m.idleBobPhaseFrames, 0, m.idleBobPeriodFrames - EPS) || !finite(m.approachRadius, 0, 1024) || !finite(m.approachAcceleration, .000001, 1) || !finite(m.approachMaxSpeed, 0, 8) || !finite(m.approachVerticalCap, 0, 8) || !['slide', 'stop', 'reverse'].includes(m.solidResponse)) fail('Invalid bounded authored Galoomba motion');
    } else {
      allFields(q.motion, shellFields, 'empty Buzzy motion');
      const m = q.motion;
      if (!finite(m.initialVx, -8, 8) || !finite(m.initialVy, -8, 8) || !finite(m.gravity, .000001, .5) || !finite(m.maxFallSpeed, .001, 8) || m.initialVy > m.maxFallSpeed || !finite(m.horizontalRestitution, 0, 1)) fail('Invalid explicit empty Buzzy ballistic motion');
    }
  }
  return spec;
}

/** Actual relative swept AABB, including a solid's dx/dy for this host tick.
 * Normal points out of the surface. Initial overlaps are real contacts and
 * get the minimum separating normal; touching while departing is not a hit.
 */
function sweep(bodyBefore, delta, surface, elapsed, remaining, oneWay) {
  const sx = Number.isFinite(surface.dx) ? surface.dx : 0, sy = Number.isFinite(surface.dy) ? surface.dy : 0;
  const start = {...pose(surface), x: surface.x - sx + sx * elapsed, y: surface.y - sy + sy * elapsed};
  const relative = {x: delta.x - sx * remaining, y: delta.y - sy * remaining};
  if (oneWay) {
    const gap = start.y - bodyBefore.y - bodyBefore.h;
    if (gap < -EPS || relative.y <= EPS) return null;
    const fraction = gap / relative.y;
    if (fraction < -EPS || fraction > 1 + EPS) return null;
    const x = bodyBefore.x + delta.x * fraction, gx = start.x + sx * remaining * fraction;
    return x + bodyBefore.w > gx + EPS && x < gx + start.w - EPS ? {fraction: Math.max(0, Math.min(1, fraction)), normal: {x: 0, y: -1}, initialOverlap: false, surface, surfaceVelocity: {x: sx, y: sy}} : null;
  }
  if (overlap(bodyBefore, start)) {
    const penetrations = [
      {depth: bodyBefore.x + bodyBefore.w - start.x, normal: {x: -1, y: 0}},
      {depth: start.x + start.w - bodyBefore.x, normal: {x: 1, y: 0}},
      {depth: bodyBefore.y + bodyBefore.h - start.y, normal: {x: 0, y: -1}},
      {depth: start.y + start.h - bodyBefore.y, normal: {x: 0, y: 1}}
    ].sort((a, b) => a.depth - b.depth);
    return {fraction: 0, normal: penetrations[0].normal, initialOverlap: true, surface, surfaceVelocity: {x: sx, y: sy}};
  }
  let enter = -Infinity, leave = Infinity, normal = {x: 0, y: 0};
  for (const [axis, size] of [['x', 'w'], ['y', 'h']]) {
    const speed = relative[axis], low = start[axis] - bodyBefore[axis] - bodyBefore[size], high = start[axis] + start[size] - bodyBefore[axis];
    if (Math.abs(speed) <= EPS) {if (low >= -EPS || high <= EPS) return null; continue;}
    const a = low / speed, b = high / speed, near = Math.min(a, b), far = Math.max(a, b);
    if (near > enter) {enter = near; normal = axis === 'x' ? {x: speed > 0 ? -1 : 1, y: 0} : {x: 0, y: speed > 0 ? -1 : 1};}
    leave = Math.min(leave, far);
  }
  if (enter < -EPS || enter > 1 + EPS || enter >= leave - EPS || leave <= EPS) return null;
  return {fraction: Math.max(0, Math.min(1, enter)), normal, initialOverlap: false, surface, surfaceVelocity: {x: sx, y: sy}};
}

export function createUnderwaterActors(room, {emit = () => {}} = {}) {
  const leaf = validateUnderwaterActorsRoom(room);
  if (!leaf?.profiles.length) return null;
  if (typeof emit !== 'function') fail('Underwater actor emit must be a function');
  const definitions = copy(leaf.profiles), byId = new Map(definitions.filter(q => q.id !== undefined).map(q => [q.id, q])), bySource = new Map(definitions.filter(q => q.sourceId !== undefined).map(q => [q.sourceId, q]));
  let records = new Map();
  function ruleFor(actor) {
    if (typeof actor === 'string') return byId.get(actor) || null;
    const direct = byId.get(actor?.id), source = bySource.get(actor?.moduleSource);
    if (direct && source) fail('Underwater actor has ambiguous native/source ownership');
    return direct || source || null;
  }
  const ownsActor = actor => !!ruleFor(actor);
  function initialPhase(q) {return q.kind === 'fish-bone' ? 'cruise' : q.kind === 'galoomba' ? 'idle' : 'ballistic';}
  function state(q, record, actor) {
    const phase = record?.phase ?? initialPhase(q);
    return {version: 1, kind: q.kind, phase: actor?.moduleEmergence ? 'emerging' : phase, eye: q.kind === 'fish-bone' ? phase === 'cruise' ? 'blue' : 'red' : null, winged: q.kind === 'fish-bone', ...(q.kind === 'galoomba' ? {size: q.size} : {}), aim: record?.aim ? copy(record.aim) : null, alertElapsedFrames: record?.alertElapsedFrames ?? 0, chargeSpeed: record?.chargeSpeed ?? 0, elapsedFrames: record?.elapsedFrames ?? 0, lastContact: record?.lastContact ? copy(record.lastContact) : null, tuningStatus: 'explicit-author-fits'};
  }
  function checkActor(actor) {
    if (typeof actor?.id !== 'string' || !actor.id || !body(actor) || !finite(actor.w, 1, 128) || !finite(actor.h, 1, 128) || (actor.vx !== undefined && !finite(actor.vx, -64, 64)) || (actor.vy !== undefined && !finite(actor.vy, -64, 64))) fail('Invalid live underwater native actor');
  }
  /** Decoration retains the supplied live object, coordinates and body size.
   * It does not bind simulation state or advance/restart a motion profile. */
  function decorateActor(actor) {
    const q = ruleFor(actor); if (!q) return actor;
    checkActor(actor);
    actor.type = q.kind === 'beetle-shell' ? 'beetle' : q.kind;
    actor.source = {...actor.source, underwaterActor: true, winged: q.kind === 'fish-bone'};
    if (q.kind === 'beetle-shell') {actor.shell = true; actor.emptyShell = true; actor.shellAge = 0;}
    actor.underwaterActor = state(q, records.get(actor.id), actor);
    return actor;
  }
  function recordFor(actor, q) {
    checkActor(actor);
    let record = records.get(actor.id);
    if (record && record.actor !== actor) fail('Underwater native ID must have exactly one live actor instance');
    if (!record) {
      record = {actor, definition: q, phase: initialPhase(q), lastTick: null, elapsedFrames: 0, alertElapsedFrames: 0, aim: null, chargeSpeed: q.kind === 'fish-bone' ? q.motion.chargeInitialSpeed : 0, cruiseVx: q.kind === 'fish-bone' ? q.motion.cruiseVx : 0, idleY: actor.y, lastContact: null};
      records.set(actor.id, record);
      if (q.kind === 'beetle-shell') {actor.vx = q.motion.initialVx; actor.vy = q.motion.initialVy;}
      else actor.vx = actor.vy = 0;
    }
    return record;
  }
  function aimAt(actor, player, fallback) {
    const from = center(actor), to = body(player) && live(player) ? center(player) : {x: from.x + Math.sign(fallback || -1), y: from.y};
    const dx = to.x - from.x, dy = to.y - from.y, length = Math.hypot(dx, dy);
    return length > EPS ? {x: dx / length, y: dy / length} : {x: Math.sign(fallback || -1), y: 0};
  }
  function nearPlayer(actor, player, radius) {return body(player) && live(player) && Math.hypot(center(actor).x - center(player).x, center(actor).y - center(player).y) <= radius;}
  function diagnostic(actor, q, tick, event, data) {emit('underwater-actor', {event, roomId: room.roomId, actorId: actor.id, ...(actor.moduleSource ? {sourceId: actor.moduleSource} : {}), kind: q.kind, tick, parameterStatus: 'explicit-author-fits', ...copy(data)});}
  function prepareMotion(actor, q, record, player, tick) {
    const m = q.motion;
    if (q.kind === 'fish-bone') {
      if (record.phase === 'cruise') {
        if (nearPlayer(actor, player, m.alertRadius) && (m.sensorFacing!=='forward' || Math.sign(record.cruiseVx)*(center(player).x-center(actor).x)>=0)) {
          record.phase = 'alert'; record.alertElapsedFrames = 0;
          if (m.aimSample === 'alert-start') record.aim = aimAt(actor, player, record.cruiseVx);
          actor.vx = actor.vy = 0;
          diagnostic(actor, q, tick, 'fish-bone-alert', {phase: 'alert', aim: record.aim});
        } else {actor.vx = record.cruiseVx; actor.vy = 0;}
      } else if (record.phase === 'alert') {
        record.alertElapsedFrames++;
        if (record.alertElapsedFrames >= m.alertFrames) {
          record.phase = 'charge';
          if (!record.aim) record.aim = aimAt(actor, player, record.cruiseVx);
          record.chargeSpeed = m.chargeInitialSpeed;
          diagnostic(actor, q, tick, 'fish-bone-charge', {phase: 'charge', aim: record.aim});
          actor.vx = record.aim.x * record.chargeSpeed; actor.vy = record.aim.y * record.chargeSpeed;
        } else actor.vx = actor.vy = 0;
      } else if (record.phase === 'charge') {
        record.chargeSpeed = Math.min(m.chargeMaxSpeed, record.chargeSpeed + m.chargeAcceleration);
        actor.vx = record.aim.x * record.chargeSpeed; actor.vy = record.aim.y * record.chargeSpeed;
      }
    } else if (q.kind === 'galoomba') {
      if (nearPlayer(actor, player, m.approachRadius)) {
        record.phase = 'approach';
        const direction = aimAt(actor, player, actor.vx), target = {x: direction.x * m.approachMaxSpeed, y: Math.max(-m.approachVerticalCap, Math.min(m.approachVerticalCap, direction.y * m.approachMaxSpeed))};
        actor.vx = approach(actor.vx || 0, target.x, m.approachAcceleration); actor.vy = approach(actor.vy || 0, target.y, m.approachAcceleration);
      } else {
        if (record.phase === 'approach') {record.idleY = actor.y; record.elapsedFrames = 0;}
        record.phase = 'idle'; actor.vx = 0;
        const phase = 2 * Math.PI * m.idleBobPhaseFrames / m.idleBobPeriodFrames;
        const targetY = record.idleY + m.idleBobAmplitude * (Math.sin(phase + 2 * Math.PI * (record.elapsedFrames + 1) / m.idleBobPeriodFrames) - Math.sin(phase));
        actor.vy = Math.max(-m.approachVerticalCap, Math.min(m.approachVerticalCap, targetY - actor.y));
      }
    } else actor.vy = Math.min(m.maxFallSpeed, actor.vy + m.gravity);
  }
  function move(actor, q, record, geometry, tick) {
    let elapsed = 0, remaining = 1, delta = {x: actor.vx, y: actor.vy};
    actor.grounded = false; actor.support = null;
    for (let pass = 0; pass < 8 && remaining > EPS; pass++) {
      let hit = null;
      for (const surface of geometry) {
        if (surface.id === actor.id || !live(surface) || !['solid', 'oneway'].includes(surface.collision)) continue;
        if (!body(surface)) fail('Underwater actor collision needs finite actual geometry');
        const oneWay = surface.collision === 'oneway';
        if (oneWay && q.kind !== 'beetle-shell') continue;
        const next = sweep(actor, delta, surface, elapsed, remaining, oneWay);
        if (next && (!hit || next.fraction < hit.fraction - EPS)) hit = next;
      }
      if (!hit) {actor.x += delta.x; actor.y += delta.y; break;}
      actor.x += delta.x * hit.fraction; actor.y += delta.y * hit.fraction;
      elapsed += remaining * hit.fraction; remaining *= 1 - hit.fraction;
      const surface = hit.surface, at = {...pose(surface), x: surface.x - hit.surfaceVelocity.x * (1 - elapsed), y: surface.y - hit.surfaceVelocity.y * (1 - elapsed)};
      // Separate against the actual moving face, including genuine overlaps.
      if (hit.normal.x < 0) actor.x = at.x - actor.w;
      if (hit.normal.x > 0) actor.x = at.x + at.w;
      if (hit.normal.y < 0) actor.y = at.y - actor.h;
      if (hit.normal.y > 0) actor.y = at.y + at.h;
      const contact = {surfaceId: surface.id, collision: surface.collision, material: surface.material ?? null, snakeBlock: !!surface.smm2SnakeBlock, fraction: elapsed, normal: copy(hit.normal), initialOverlap: hit.initialOverlap, point: {x: hit.normal.x < 0 ? actor.x + actor.w : hit.normal.x > 0 ? actor.x : (Math.max(actor.x, at.x) + Math.min(actor.x + actor.w, at.x + at.w)) / 2, y: hit.normal.y < 0 ? actor.y + actor.h : hit.normal.y > 0 ? actor.y : (Math.max(actor.y, at.y) + Math.min(actor.y + actor.h, at.y + at.h)) / 2}};
      record.lastContact = contact;
      diagnostic(actor, q, tick, 'contact', {phase: record.phase, contact});
      if (q.kind === 'fish-bone' && record.phase === 'charge') {
        const velocity = {x: actor.vx, y: actor.vy}; record.phase = 'broken';
        actor.dead = true; actor.removed = true; actor.vx = actor.vy = 0;
        diagnostic(actor, q, tick, 'fish-bone-broken', {phase: 'broken', contact, body: pose(actor), velocity, winged: true});
        break;
      }
      const policy = q.kind === 'fish-bone' ? q.motion.blueContactPolicy : q.kind === 'galoomba' ? q.motion.solidResponse : 'shell';
      if (policy === 'stop') actor.vx = actor.vy = 0;
      if (hit.normal.x) {
        actor.vx = policy === 'reverse' || policy === 'shell' ? hit.surfaceVelocity.x - (actor.vx - hit.surfaceVelocity.x) * (policy === 'shell' ? q.motion.horizontalRestitution : 1) : hit.surfaceVelocity.x;
        if (q.kind === 'fish-bone' && record.phase === 'cruise') record.cruiseVx = policy === 'stop' ? 0 : actor.vx;
      }
      if (hit.normal.y) {
        actor.vy = policy === 'reverse' ? hit.surfaceVelocity.y - (actor.vy - hit.surfaceVelocity.y) : hit.surfaceVelocity.y;
        if (q.kind === 'beetle-shell' && hit.normal.y < 0) {actor.grounded = true; actor.support = surface.id;}
      }
      delta = {x: actor.vx * remaining, y: actor.vy * remaining};
    }
  }
  function stepActor(actor, {tick, player = null, geometry} = {}) {
    const q = ruleFor(actor); if (!q) return false;
    if (!integer(tick, 0, Number.MAX_SAFE_INTEGER) || !Array.isArray(geometry)) fail('Underwater actor step needs an explicit nonnegative tick and actual geometry');
    if (!live(actor) || actor.moduleEmergence || actor.emerge || actor.clawHeld || actor.vehicleId) return true;
    const record = recordFor(actor, q);
    if (record.lastTick !== null && tick <= record.lastTick) return true;
    const before = pose(actor); record.lastTick = tick;
    prepareMotion(actor, q, record, player, tick);
    move(actor, q, record, geometry, tick);
    record.elapsedFrames++; actor.dx = actor.x - before.x; actor.dy = actor.y - before.y;
    actor.underwaterActor = state(q, record, actor);
    return true;
  }
  /** Pure detached projection. Reading a view never registers an actor, sets
   * its launch velocity, samples targets, emits events or advances a clock. */
  function view(actors = []) {
    if (!Array.isArray(actors)) fail('Underwater actor view needs an actor list');
    return {version: 1, parameterStatus: 'explicit-author-fits', actors: actors.filter(ownsActor).map(actor => {
      const q = ruleFor(actor); return {id: actor.id, ...(actor.moduleSource ? {sourceId: actor.moduleSource} : {}), kind: q.kind, body: pose(actor), dead: !live(actor), state: state(q, records.get(actor.id), actor), motion: copy(q.motion)};
    })};
  }
  return Object.freeze({ownsActor, decorateActor, stepActor, view, reset() {records = new Map();}, getDocument: () => copy(leaf)});
}
