# Heavy Stone source artwork

The acquired PNGs are Nintendo artwork obtained from their cited public Mario Wiki file pages for private study. Their copyright is separate from the workshop code license. They are not MIT-licensed and were not created by this project.

Runtime source-pixel rows preserve the acquired image palettes/shapes. Carrying-pose color adaptation, unacquired Big/run phases, scenery, Goomba and parachute artwork, Twister bubbles, and animation cadence are documented authored adaptations of finite gameplay observations. Original complete animation tables are not claimed recovered.
