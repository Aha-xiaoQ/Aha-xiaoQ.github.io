# Music credits

Magic of the Forest, Deep Mining, and Traitor by [Dark Reaven Music](https://soundcloud.com/dark-reaven-music), sourced from [VoxeLibre](https://github.com/VoxeLibre/VoxeLibre/blob/4492ce6ff8d856daa4567abe2ea689f4e7a39842/CREDITS.md#music), licensed under [Creative Commons Attribution-ShareAlike 3.0 Unported](https://creativecommons.org/licenses/by-sa/3.0/).

The supplied OGG recordings are unchanged from upstream commit 4492ce6ff8d856daa4567abe2ea689f4e7a39842. These are alternative soundtracks, not Minecraft original soundtrack recordings.

Retain this credit, the track titles, source links, and license link when distributing. If creating edited/remixed audio, identify your modifications and distribute the adapted audio under CC BY-SA 3.0 (or a compatible license permitted by its terms). The ShareAlike requirement should not be summarized as automatically licensing all independent game code; the boundary between a collection and adaptation depends on how material is used. Avoid definitive legal claims.
