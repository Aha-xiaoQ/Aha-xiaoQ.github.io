/** Opt-in underwater adapters. All forces are passed into the native collision motor.
 * Native adaptation values and the local seeded sequence are approximations, not
 * an emulation of Nintendo's fixed-point engine or original PRNG. */
const clone=value=>JSON.parse(JSON.stringify(value));
const own=(map,id)=>map&&Object.hasOwn(map,id)?map[id]:undefined;
const fail=message=>{throw Error(message);};
const unsafe=id=>['__proto__','constructor','prototype'].includes(id);
const finite=(value,min,max)=>Number.isFinite(value)&&value>=min&&value<=max;
const integer=(value,min,max)=>Number.isInteger(value)&&finite(value,min,max);
const clamp=(value,min,max)=>Math.max(min,Math.min(max,value));
const overlap=(a,b)=>a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y;
function object(value,allowed,label){
 if(!value||typeof value!=='object'||Array.isArray(value)||![Object.prototype,null].includes(Object.getPrototypeOf(value)))fail('Invalid '+label);
 for(const key of Object.keys(value))if(unsafe(key)||!allowed.includes(key))fail('Unknown '+label+' field: '+key);
}
function list(value,label,max=128){if(!Array.isArray(value)||value.length>max)fail('Invalid '+label+' list');}
export const AQUATIC_PHYSICS_DEFAULTS=Object.freeze({horizontalCap:1.5,groundCap:.75,acceleration:.037109375,deceleration:.05078125,strokeSpeed:2.5,gravity:.075,maxFall:1.5,top:16,strokeFrames:24});
export const AQUATIC_CURRENT_DEFAULTS=Object.freeze({pull:.018,down:.025,strokeMultiplier:.72});
export const AQUATIC_FISH_DEFAULTS=Object.freeze({intervalFrames:32,initialDelayFrames:0,maxAlive:3,maxEmissions:null,spawnLead:32,yCandidates:Object.freeze([64,48,144,80,32,96,160,112]),grayWeight:1,redWeight:1,graySpeed:.25,redSpeed:.5,seed:1,driftSpeed:.125,driftRange:12});
export const AQUATIC_BLOOPER_DEFAULTS=Object.freeze({kind:'blooper',activationDistance:32,pulseFrames:28,decelFrames:24,floatFrames:24,pulseX:.65,pulseY:1.3,deceleration:.055,floatSpeed:.55,top:32,initialDelayFrames:0});
const physicsFor=spec=>({...AQUATIC_PHYSICS_DEFAULTS,...spec.physics});
const currentFor=q=>({...AQUATIC_CURRENT_DEFAULTS,...q});
const fishFor=q=>({...AQUATIC_FISH_DEFAULTS,...q,yCandidates:[...(q.yCandidates||AQUATIC_FISH_DEFAULTS.yCandidates)]});
const blooperFor=(room,id,q)=>({...AQUATIC_BLOOPER_DEFAULTS,bottom:room.map.height-(room.map.objects.find(o=>o.id===id)?.h||16)-16,...q});
/** Validation does not mutate input. An omitted spec retains all existing behavior. */
export function validateAquaticRoom(room){
 const spec=room?.aquatic;if(spec===undefined)return;
 object(spec,['version','physics','currents','maxFishAlive','fishSources','enemyProfiles','fireKillPoints','contactBodies'],'aquatic');
 if(spec.version!==1)fail('Unknown aquatic version');
 if(spec.contactBodies!==undefined&&(spec.contactBodies!=='smm2-solid-actors'||room.smm2Mechanics?.version!==1))fail('Aquatic contactBodies requires an explicit supported SMM2 solid-body profile');
 if(room.mechanics!==undefined||room.devices?.length)fail('Aquatic cannot combine with echo before rewind state is supported');
 if(typeof room.setting!=='string'||!/Underwater/.test(room.setting)||(room.underwater!==undefined&&room.underwater!==true))fail('Aquatic modules require an Underwater room setting');
 const map=room.map;if(!map||!finite(map.width,16,32768)||!finite(map.height,32,4096)||!Array.isArray(map.objects)||!Array.isArray(map.geometry))fail('Aquatic room needs valid native map bounds');
 if(spec.physics!==undefined)object(spec.physics,Object.keys(AQUATIC_PHYSICS_DEFAULTS),'water physics');
 const p=physicsFor(spec);
 if(!finite(p.horizontalCap,.01,4)||!finite(p.groundCap,.01,p.horizontalCap)||!finite(p.acceleration,.001,.5)||!finite(p.deceleration,.001,.5)||!finite(p.strokeSpeed,.1,8)||!finite(p.gravity,.001,.5)||!finite(p.maxFall,.1,5)||!finite(p.top,0,map.height-16)||!integer(p.strokeFrames,1,240))fail('Invalid water physics');
 if(spec.maxFishAlive!==undefined&&!integer(spec.maxFishAlive,1,3))fail('Water fish occupancy must be between one and three');
 if(spec.fireKillPoints!==undefined&&!integer(spec.fireKillPoints,0,100000))fail('Invalid aquatic fire kill points');
 const ids=new Set([...map.geometry,...map.objects,...(room.markers||[]),...(room.marioModules?.itemSources||[]),...(room.marioModules?.enemySources||[])].map(q=>q.id));
 function id(q){if(typeof q.id!=='string'||q.id.length>72||!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(q.id)||unsafe(q.id)||ids.has(q.id))fail('Duplicate or invalid aquatic ID');ids.add(q.id);}
 if(spec.currents!==undefined)list(spec.currents,'current');
 for(const q of spec.currents||[]){
  object(q,['id','x','y','w','h','centerX','pull','down','strokeMultiplier'],'current');id(q);const c=currentFor(q);
  if(!['x','y','w','h'].every(k=>Number.isFinite(c[k]))||c.x<0||c.y<0||c.w<=0||c.h<=0||c.x+c.w>map.width||c.y+c.h>map.height||!finite(c.centerX,c.x,c.x+c.w)||!finite(c.pull,0,.25)||!finite(c.down,0,.5)||!finite(c.strokeMultiplier,.1,1))fail('Invalid current bounds or force');
 }
 if(spec.fishSources!==undefined)list(spec.fishSources,'fish source',64);
 for(const q of spec.fishSources||[]){
  object(q,['id','startX','endX',...Object.keys(AQUATIC_FISH_DEFAULTS)],'fish source');id(q);const s=fishFor(q);
  if(!finite(s.startX,0,map.width)||!finite(s.endX,s.startX+.01,map.width)||!integer(s.intervalFrames,1,36000)||!integer(s.initialDelayFrames,0,36000)||!integer(s.maxAlive,1,3)||(s.maxEmissions!==null&&!integer(s.maxEmissions,1,100000))||!finite(s.spawnLead,16,256)||!finite(s.grayWeight,0,100)||!finite(s.redWeight,0,100)||s.grayWeight+s.redWeight<=0||!finite(s.graySpeed,.01,4)||!finite(s.redSpeed,.01,4)||!integer(s.seed,0,0xffffffff)||!finite(s.driftSpeed,0,1)||!finite(s.driftRange,0,64))fail('Invalid fish source region, timing, palette or motion');
  list(s.yCandidates,'fish height',64);if(!s.yCandidates.length||!s.yCandidates.every(y=>finite(y,0,map.height-16)))fail('Fish source height outside room');
 }
 if(spec.enemyProfiles!==undefined)object(spec.enemyProfiles,Object.keys(spec.enemyProfiles),'aquatic enemy profiles');
 for(const [id,q]of Object.entries(spec.enemyProfiles||{})){
  if(unsafe(id))fail('Unsafe aquatic enemy target');
  object(q,[...Object.keys(AQUATIC_BLOOPER_DEFAULTS),'bottom'],'Blooper profile');
  const actor=map.objects.find(o=>o.id===id&&o.kind==='walker'),b=blooperFor(room,id,q);
  if(!actor||room.marioModules?.enemyVariants&&Object.hasOwn(room.marioModules.enemyVariants,id))fail('Aquatic profile needs an existing independent walker');
  if(b.kind!=='blooper'||!finite(actor.w,.1,64)||!finite(actor.h,.1,64)||!finite(actor.x,0,map.width-actor.w)||!finite(actor.y,0,map.height-actor.h)||!finite(b.activationDistance,0,512)||!integer(b.pulseFrames,1,600)||!integer(b.decelFrames,1,600)||!integer(b.floatFrames,1,3600)||!finite(b.pulseX,.01,4)||!finite(b.pulseY,.01,5)||!finite(b.deceleration,.001,1)||!finite(b.floatSpeed,.01,2)||!finite(b.top,0,map.height-actor.h)||!finite(b.bottom,b.top+.01,map.height-actor.h)||!integer(b.initialDelayFrames,0,3600)||actor.y<b.top||actor.y>b.bottom)fail('Invalid Blooper pursuit bounds or motion');
 }
}

/** Returns null when omitted; controller state advances only on distinct active calls. */
export function createAquaticController(room,{emit=()=>{}}={}){
 validateAquaticRoom(room);if(room.aquatic===undefined)return null;
 const spec=clone(room.aquatic),physics=physicsFor(spec),currents=(spec.currents||[]).map(currentFor),sources=(spec.fishSources||[]).map(fishFor),profiles=new Map(Object.entries(spec.enemyProfiles||{}).map(([id,q])=>[id,blooperFor(room,id,q)]));
 let sourceStates,bodies,lastSpawnTick=null,currentTick=0,bodyStates=new WeakMap();
 const diagnostic=(event,data)=>emit('aquatic',{event,...data});
 function reset(){sourceStates=new Map(sources.map(q=>[q.id,{active:false,clock:q.initialDelayFrames,emitted:0,rng:q.seed>>>0,lastTick:null}]));bodyStates=new WeakMap();bodies=new Set();lastSpawnTick=null;currentTick=0;}
 reset();
 const tickFor=tick=>Number.isInteger(tick)&&tick>=0?tick:currentTick;
 function waterContext(player,{tick=currentTick}={}){
  // Pure force sampling: no input latch, pose change, teleport or score mutation.
  const result={...physics,flowX:0,flowY:0,currentIds:[],approximation:true};
  if(player&&!player.dead&&!player.dying){const center=player.x+player.w/2;for(const q of currents)if(overlap(player,q)){result.flowX+=Math.sign(q.centerX-center)*q.pull;result.flowY+=q.down;result.strokeSpeed=Math.min(result.strokeSpeed,physics.strokeSpeed*q.strokeMultiplier);result.currentIds.push(q.id);}}
  return result;
 }
 function random(state){state.rng=(Math.imul(state.rng,1664525)+1013904223)>>>0;return state.rng/0x100000000;}
 function decorateEnemy(q){
  if(!q||typeof q!=='object')return q;
  const rule=profiles.get(q.id);
  if(rule){q.type='blooper';q.aquaticProfile='blooper';q.source={...q.source,aquatic:true};q.homeX??=q.x;q.homeY??=q.y;q.vx=0;q.vy=0;q.grounded=false;q.support=null;q.aquaticActive=false;}
  if(q.aquaticSource){q.type='cheepcheep';q.aquaticProfile='fish';q.source={...q.source,aquatic:true};q.grounded=false;q.support=null;}
  return q;
 }
 function spawnEnemies({player,cam=0,viewportWidth=256,enemies=[],tick=currentTick}={}){
  const activeTick=tickFor(tick);if(lastSpawnTick===activeTick)return [];lastSpawnTick=activeTick;currentTick=activeTick;
  if(!player||player.dead||player.dying)return [];
  for(const body of bodies)if(body.dead)bodies.delete(body);
  const spawned=[],isFish=e=>!e.dead&&(!!e.aquaticSource||/^(enemy-|marker-)?cheepcheep$/i.test(e.type||''));
  for(const q of sources){
   const s=sourceStates.get(q.id);s.active=cam>=q.startX&&cam<q.endX;
   if(!s.active)continue;s.lastTick=activeTick;
   if(s.clock>0){s.clock--;continue;}
   if((q.maxEmissions!==null&&s.emitted>=q.maxEmissions)||[...enemies,...spawned].filter(isFish).length>=(spec.maxFishAlive??3)||[...enemies,...spawned].filter(e=>isFish(e)&&e.aquaticSource===q.id).length>=q.maxAlive)continue;
   const red=random(s)*(q.grayWeight+q.redWeight)>=q.grayWeight,y=q.yCandidates[Math.floor(random(s)*q.yCandidates.length)],ordinal=s.emitted;
   const x=cam+viewportWidth+q.spawnLead,drifting=ordinal%3===2;
   const e=decorateEnemy({id:'aquatic-fish-'+q.id+'-'+ordinal,kind:'walker',type:'cheepcheep',source:{red,gray:!red,aquaticVariant:red?'red':'gray'},aquaticSource:q.id,aquaticOrdinal:ordinal,x,y,w:16,h:16,vx:-(red?q.redSpeed:q.graySpeed),vy:0,homeX:x,homeY:y,age:0,hp:1,dead:false,aquaticMotion:{speed:red?q.redSpeed:q.graySpeed,driftSpeed:drifting?q.driftSpeed:0,driftRange:q.driftRange,direction:ordinal%2?1:-1}});
   spawned.push(e);s.emitted++;s.clock=q.intervalFrames-1;diagnostic('fish-spawn',{sourceId:q.id,actorId:e.id,variant:red?'red':'gray',sequence:'seeded-local-approximation'});
  }
  return spawned;
 }
 function startPulse(e,state,rule,player){state.phase='pulse';state.clock=0;state.direction=Math.sign((player?.x||0)+(player?.w||0)/2-e.x-e.w/2)||state.direction||-1;e.vx=state.direction*rule.pulseX;e.vy=-rule.pulseY;state.floatTarget=clamp(Math.max(e.homeY,player?player.y+player.h-e.h-16:e.homeY),rule.top,rule.bottom);diagnostic('blooper-pulse',{actorId:e.id,direction:state.direction});}
 function stepEnemy(e,{player,tick=currentTick,cam=0,viewportWidth=256}={}){
  const fish=e?.aquaticSource&&sources.find(s=>s.id===e.aquaticSource),rule=profiles.get(e?.id);if(!fish&&!rule)return false;
  if(e.dead)return true;const activeTick=tickFor(tick);currentTick=activeTick;
  let state=bodyStates.get(e);if(!state){state={lastTick:null,active:!!fish,phase:fish?'swim':'wait',clock:rule?.initialDelayFrames||0,direction:-1,floatTarget:e.homeY??e.y};bodyStates.set(e,state);bodies.add(e);}
  if(state.lastTick===activeTick)return true;state.lastTick=activeTick;
  if(fish){
   const motion=e.aquaticMotion||{speed:e.source?.red?fish.redSpeed:fish.graySpeed,driftSpeed:0,driftRange:fish.driftRange,direction:-1};
   e.vx=-Math.abs(motion.speed);e.x+=e.vx;
   if(motion.driftSpeed&&motion.driftRange){const min=Math.max(0,e.homeY-motion.driftRange),max=Math.min(room.map.height-e.h,e.homeY+motion.driftRange);e.vy=motion.direction*motion.driftSpeed;e.y=clamp(e.y+e.vy,min,max);if(e.y<=min||e.y>=max)motion.direction*=-1;}
   else e.vy=0;
   e.aquaticActive=true;e.aquaticPhase='swim';e.grounded=false;e.support=null;
   // Physical departure only. No lifespan or player-distance scripted disappearance.
   if(e.x+e.w<cam-32){e.dead=true;diagnostic('fish-departed',{actorId:e.id,sourceId:e.aquaticSource});}
   return true;
  }
  if(!state.active){if(e.x+e.w<cam||e.x>cam+viewportWidth+rule.activationDistance)return true;state.active=true;e.aquaticActive=true;diagnostic('blooper-activated',{actorId:e.id});}
  if(state.phase==='wait'){if(state.clock>0){state.clock--;e.vx=e.vy=0;}else startPulse(e,state,rule,player);}
  if(state.phase==='pulse'){e.x+=e.vx;e.y+=e.vy;if(++state.clock>=rule.pulseFrames){state.phase='decelerate';state.clock=0;}}
  else if(state.phase==='decelerate'){e.vx=Math.sign(e.vx)*Math.max(0,Math.abs(e.vx)-rule.deceleration);e.vy=Math.sign(e.vy)*Math.max(0,Math.abs(e.vy)-rule.deceleration);e.x+=e.vx;e.y+=e.vy;if(++state.clock>=rule.decelFrames){state.phase='float';state.clock=0;e.vx=0;e.vy=rule.floatSpeed;}}
  else if(state.phase==='float'){e.vx=0;e.vy=rule.floatSpeed;e.y=Math.min(rule.bottom,e.y+e.vy);state.clock++;if(state.clock>=rule.floatFrames&&e.y>=state.floatTarget){startPulse(e,state,rule,player);}}
  e.x=clamp(e.x,0,room.map.width-e.w);e.y=clamp(e.y,rule.top,rule.bottom);if(e.y===rule.top&&e.vy<0)e.vy=0;if(e.y===rule.bottom&&e.vy>0)e.vy=0;
  e.grounded=false;e.support=null;e.aquaticPhase=state.phase;return true;
 }
 const isAquaticEnemy=e=>!!e&&(profiles.has(e.id)||!!e.aquaticSource||/^(enemy-|marker-)?(blooper|cheepcheep)$/i.test(e.type||''));
 function view(){return {version:1,approximation:true,sequence:'seeded-local-approximation',tick:currentTick,physics:{...physics},currents:clone(currents),fishSources:sources.map(q=>({id:q.id,...sourceStates.get(q.id)})),enemies:[...bodies].filter(e=>!e.dead).map(e=>({id:e.id,type:e.type,phase:e.aquaticPhase,active:!!e.aquaticActive}))};}
 return Object.freeze({waterContext,spawnEnemies,decorateEnemy,stepEnemy,disallowStomp:e=>!!e,firePoints:e=>isAquaticEnemy(e)?spec.fireKillPoints??200:undefined,reset,view});
}
