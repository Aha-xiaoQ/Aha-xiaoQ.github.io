import {play} from './editor-play.mjs';
import {showCredits,mountStartingLives} from './campaign-ui.mjs';
import {createGamepadInput,gamepadLabels} from './editor-gamepad.mjs';
import {createProgress,reconcileProgress,markLevelComplete,resumeBoundary,parseProgress,serializeProgress,createProgressStore} from './editor-collection-progress.mjs';
import {validateAdmissionPolicy,runtimeAdmissionForLevel} from './editor-collection-policy.mjs';

/** Plays authored entries only. Stock templates, stock warps and editor drafts are unrelated. */
export function mountCustomCollection(collection,media,{host=document.querySelector('.launch-copy'),storage,playLevel=play}={}){
 if(collection?.format!=='xiaoq-map-collection-runtime'||collection.version!==1||!collection.levels?.length)throw Error('自制合集运行数据无效');
 validateAdmissionPolicy(collection.admissionPolicy);
 if(collection.admissionPolicy?.mode==='owner-approved-or-tested'&&(collection.privateStudy!==true||collection.publicDeployment===true))throw Error('测试纳入授权仅适用于私人合集');
 const admissions=new Map(collection.levels.map(level=>[level.id,runtimeAdmissionForLevel(level,collection.admissionPolicy)]));
 if([...admissions.values()].some(admission=>!admission.eligible))throw Error('合集包含未获认可、未通过授权测试或已撤回的关卡');
 const entries=new Map(collection.levels.map(l=>[l.id,l])),ordered=()=>collection.order.map(id=>entries.get(id));
 host.replaceChildren();const title=document.createElement('h1');title.id='map-title';title.textContent=collection.title;
 const approvedCount=[...admissions.values()].filter(admission=>admission.status==='owner-approved').length,testedCount=collection.levels.length-approvedCount;
 const note=document.createElement('p');note.className='lead';note.textContent=collection.levels.length+' 关私人学习集 · '+approvedCount+' 关作者已认可'+(testedCount?'，'+testedCount+' 关测试通过 / 待你查看':'')+'。自由选关与连续游玩；续关从关卡入口开始，不保存房间现场。完成末关后保存实际生命与奖励，供同一合集新增关卡时继续。';host.append(title,note);
 const list=document.createElement('select');list.id='custom-level-select';list.setAttribute('aria-label','选择自制关卡');
 const actions=document.createElement('div');actions.className='actions';const start=document.createElement('button'),resume=document.createElement('button'),selected=document.createElement('button');start.className='primary';start.textContent='从第一关开始';resume.textContent='继续上次进度';selected.textContent='游玩所选关';actions.append(start,resume,selected);host.append(list,actions);
 const lives=mountStartingLives(host),layout=document.createElement('select');layout.id='collection-controller-layout';layout.setAttribute('aria-label','手柄布局');for(const [id,label]of [['auto','手柄布局：自动'],['bottom','Xbox · A 在下方'],['right','Nintendo · A 在右方']])layout.add(new Option(label,id));host.append(layout);
 const hint=document.createElement('p'),status=document.createElement('p');hint.className='small';status.className='small';status.setAttribute('role','status');host.append(hint,status);
 const details=document.createElement('p');details.className='small';host.append(details);
 const tools=document.createElement('div');tools.className='actions';const exportProgress=document.createElement('button'),importProgress=document.createElement('button'),resetProgress=document.createElement('button'),file=document.createElement('input');exportProgress.textContent='导出进度';importProgress.textContent='导入进度';resetProgress.textContent='清除通关记录';file.type='file';file.accept='.json,application/json';file.hidden=true;tools.append(exportProgress,importProgress,resetProgress,file);host.append(tools);
 const store=createProgressStore(collection,{storage});const loaded=store.load();let progress=loaded.progress||createProgress(collection),busy=false,session=null,activeId=null,launchSerial=0;
 if(!progress.resume&&progress.cleared.length){const cleared=new Set(progress.cleared.map(entry=>entry.levelId));list.value=collection.order.find(id=>!cleared.has(id))||collection.order[0];}
 const storageMessage=result=>{if(!result.ok)status.textContent='本机进度未保存：'+(result.message||result.reason)+'。可用“导出进度”备份。';};storageMessage(loaded);
 const persist=()=>{progress=reconcileProgress(collection,progress);storageMessage(store.save(progress));refresh();};
 function refresh(){
  const chosen=list.value||collection.order[0],cleared=new Set(progress.cleared.map(q=>q.levelId));list.replaceChildren(...ordered().map((entry,i)=>new Option((i+1)+' · '+entry.title+' · '+admissions.get(entry.id).label+(cleared.has(entry.id)?' · 已完成':''),entry.id)));list.value=entries.has(chosen)?chosen:collection.order[0];
  const entry=entries.get(list.value),admission=entry&&admissions.get(entry.id);details.textContent=(admission?.status==='tested-awaiting-owner-review'?'依据你的私人连续测试授权加入；完成记录表示游戏通关，此修订待你查看。':'作者已认可当前修订。')+(entry?.completion?.type==='checkpoint'?'本节选到指定检查点结束；不是原作整关终点。':'本关到原生关卡终点结束。')+(!progress.resume&&!progress.terminalCarry&&progress.cleared.length&&!progress.completed?'此进度没有可继续的携带状态；可游玩所选关，默认 3 命、普通形态。':'');
  start.disabled=selected.disabled=busy;resume.disabled=busy||!progress.resume;resume.textContent=progress.resume?'继续：'+entries.get(progress.resume.levelId)?.title+' · '+admissions.get(progress.resume.levelId).label:progress.completed?'全合集已完成'+(testedCount?' · 部分修订待你查看':''):'暂无续关进度';
 }
 function optionsFor(entry){const hasNext=collection.order.indexOf(entry.id)<collection.order.length-1;return {developerMode:false,gamepadLayout:layout.value,initialState:progress.resume?.levelId===entry.id?progress.resume.carry:{lives:lives()},completionMessage:(entry.completion?.type==='checkpoint'?'节选完成':'本关完成')+(hasNext?'，进入下一关…':'，显示制作信息…'),...(entry.completion?.type==='checkpoint'?{endAtCheckpoint:entry.completion}:{}),onComplete:async(carry,current)=>{
   if(activeId!==entry.id)return;progress=markLevelComplete(collection,progress,entry.id,carry);persist();
   if(progress.resume)await run(progress.resume.levelId,progress.resume.carry,current);
   else{activeId=null;showCredits(current,{backLabel:'返回合集',title:collection.title,replay:()=>{run(collection.order[0],{lives:lives(),coins:0,score:0,power:0,hero:'mario',weapon:'N'},current);}});}
  }};}
 async function run(levelId,carry,current=null){
  if(busy)return;const entry=entries.get(levelId);if(!entry)throw Error('关卡不存在');const serial=++launchSerial;busy=true;activeId=entry.id;status.textContent='准备 '+entry.title+'…';refresh();
  try{
   progress=resumeBoundary(collection,progress,entry.id,carry);persist();const options=optionsFor(entry);
   if(current)await current.load(entry.pack,entry.rooms,options);else session=await playLevel(entry.pack,entry.rooms,media,options);
   if(serial!==launchSerial)return;session=current||session;status.textContent='';
   const dialog=document.querySelector('dialog[open]');if(dialog){const close=[...dialog.querySelectorAll('button')].find(b=>b.textContent==='返回编辑');if(close)close.textContent='返回合集';dialog.addEventListener('close',()=>{activeId=null;coverPad.suspend();refresh();start.focus();},{once:true});}
  }catch(error){status.textContent='无法开始：'+error.message;activeId=null;}finally{busy=false;refresh();}
 }
 start.onclick=()=>run(collection.order[0],{lives:lives(),coins:0,score:0,power:0,hero:'mario',weapon:'N'});
 selected.onclick=()=>run(list.value,{lives:lives(),coins:0,score:0,power:0,hero:'mario',weapon:'N'});
 resume.onclick=()=>{if(progress.resume)run(progress.resume.levelId,progress.resume.carry);};
 list.onchange=refresh;
 const download=text=>{const url=URL.createObjectURL(new Blob([text],{type:'application/json;charset=utf-8'})),a=document.createElement('a');a.href=url;a.download=collection.id+'.progress.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),30000);};
 exportProgress.onclick=()=>download(serializeProgress(progress,collection));importProgress.onclick=()=>file.click();file.onchange=async()=>{const input=file.files[0];file.value='';if(!input)return;try{progress=parseProgress(await input.text(),collection);persist();status.textContent='进度已导入';}catch(error){status.textContent='未导入进度：'+error.message;}};
 resetProgress.onclick=()=>{progress=createProgress(collection,{lives:lives()});persist();status.textContent='通关记录已清除；地图工程保留';};
 const coverPad=createGamepadInput(undefined,()=>layout.value);let menuIndex=progress.resume?1:0,hadDialog=false,lastHorizontal=0;const buttons=[start,resume,selected,exportProgress,importProgress,resetProgress];
 layout.onchange=()=>coverPad.suspend();
 const selectMenu=delta=>{const enabled=buttons.filter(b=>!b.disabled);if(!enabled.length)return;menuIndex=(menuIndex+delta+enabled.length)%enabled.length;enabled[menuIndex].focus({preventScroll:true});};
 function frame(now){const gp=coverPad(now),open=!!document.querySelector('dialog[open]');if(open!==hadDialog){coverPad.suspend();hadDialog=open;}const labels=gamepadLabels(gp.layout||layout.value);hint.textContent=gp.connected?'手柄：左右选关，↑/↓ 选择操作，'+labels.jump+' 确认，Start 续关/开始；游戏中 Start 暂停':'键盘和手柄均可操作；手柄连接后先松开按键';
  if(!open&&!busy&&!document.hidden){if(gp.x&&gp.x!==lastHorizontal){const i=collection.order.indexOf(list.value),delta=gp.x>0?1:-1;list.value=collection.order[(i+delta+collection.order.length)%collection.order.length];refresh();}if(gp.upPressed)selectMenu(-1);if(gp.downPressed)selectMenu(1);if(gp.confirmPressed)(buttons.filter(b=>!b.disabled)[menuIndex]||start).click();if(gp.pausePressed)(progress.resume?resume:start).click();}lastHorizontal=gp.x;requestAnimationFrame(frame);
 }
 refresh();requestAnimationFrame(frame);return {readProgress:()=>structuredClone(progress),selectedLevel:()=>list.value,startLevel:(id,carry={lives:3})=>run(id,carry),get session(){return session;}};
}
