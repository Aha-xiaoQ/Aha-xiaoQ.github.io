import {drawClaw} from './editor-contraptions-art.mjs';
import {COIN_CRANE_DEFAULTS} from './editor-coin-crane.mjs';
import {sourcePixels,sourceKey} from './source-art.mjs';
/** Original workshop machine casing/button; the reused claw silhouette is the
 * existing workshop approximation. Every live pose comes from the controller. */
const rect=(c,color,x,y,w,h)=>{c.fillStyle=color;c.fillRect(Math.round(x),Math.round(y),Math.round(w),Math.round(h));};
const recordsFor=room=>room.contraptionsView?.coinCranes||room.contraptions?.coinCranes||[];
const cabinet=q=>q.cabinet&&['x','y','w','h'].every(k=>Number.isFinite(q.cabinet[k]));
function nativePrize(c,type,q,{scale=1}={}){
 const image=sourcePixels(sourceKey('Character',type)),x=Math.round(q.x+(q.w-image.w*scale)/2),y=Math.round(q.y+q.h-image.h*scale);
 for(let yy=0;yy<image.h;yy++)for(let xx=0;xx<image.w;xx++){const p=image.pixels[yy*image.w+xx];if(p[3])rect(c,'rgba('+p.slice(0,3).join(',')+','+p[3]/255+')',x+xx*scale,y+yy*scale,scale,scale);}
}
/** Round red-ring black fuse bomb, authored on a 16px grid from the inspected
 * public Neon Abyss still. This is an SMB1-style adaptation, not a sprite rip. */
const BOMB_ROWS=Object.freeze([
 '.......yy.......','......ryr.......','......kk........','.....kkkk.......',
 '....rrrrrr......','...rkkkkkkr.....','..rkkhhkkkkr....','..rkhhkkkkkr....',
 '..rkhkkkkkkr....','..rkkkkkkkkr....','..rkkkkkkkkr....','..rkkkkkkkkr....',
 '...rkkkkkkr.....','....rrrrrr......','................','................'
]);
function bombPrize(c,q,flash=false){
 const colors={y:'#ffe884',r:flash?'#fff3bd':'#f23b39',k:'#151721',h:'#7d909d'};
 const x=Math.round(q.x+(q.w-16)/2),y=Math.round(q.y+q.h-16);
 for(let yy=0;yy<16;yy++)for(let xx=0;xx<16;xx++)if(colors[BOMB_ROWS[yy][xx]])rect(c,colors[BOMB_ROWS[yy][xx]],x+xx,y+yy,1,1);
}
/** Variant art dispatch uses each real object body; no hidden actor or fake
 * prize is spawned. Pink remains the existing typed-coin renderer's responsibility. */
export function drawCoinCraneObject(c,o,room={},tick=0){
 const machine=recordsFor(room).find(q=>q.payloads?.some(p=>p.id===o.id)),payload=machine?.payloads?.find(p=>p.id===o.id);
 // Live NPCs and actual 32px ten-coins keep their existing shared native
 // animation and ten-coin dispatch, even while the crane owns their motion.
 if(!payload||['pink','large-coin','live-goomba','live-koopa'].includes(payload.kind))return false;
 if(o.hidden||o.visible===false||o.dead||o.removed||o.collected||o.taken)return true;
 c.save();c.imageSmoothingEnabled=false;
 if(payload.kind==='bomb')bombPrize(c,o,!!machine.bombFlash&&(tick%8<4));
 else if(payload.kind==='coin')nativePrize(c,'Coin',o);
 else if(payload.kind==='goomba')nativePrize(c,'Goomba',o);
 else if(payload.kind==='spiny')nativePrize(c,'Spiny',o);
 else{c.restore();return false;}
 c.restore();return true;
}
/** Place before objects in the editor/runtime: this preserves the original
 * typed Pink body and all other live prize silhouettes over the purple glass. */
export function drawCoinCraneBackdrop(c,room={}){
 let drawn=false;for(const q of recordsFor(room))if(cabinet(q)){
  const {x,y,w,h}=q.cabinet;drawn=true;c.save();c.beginPath();c.rect(x+2,y+8,w-4,h-14);c.clip();
  rect(c,'#171333',x+2,y+8,w-4,h-14);
  // Low-contrast, repeated diamond facets are authored from the viewed still.
  for(let yy=y+10;yy<y+h-8;yy+=16)for(let xx=x+3;xx<x+w-3;xx+=16)for(let d=0;d<8;d++){
   const length=(d+1)*2,left=xx+7-d;rect(c,'#211942',left,yy+d,length,1);rect(c,'#211942',left,yy+15-d,length,1);
  }
  rect(c,'#242047',x+2,y+h-46,w-4,34);rect(c,'#39304f',x+2,y+h-13,w-4,3);c.restore();
 }return drawn;
}
function pixelLine(c,color,a,b,width=1){
 let x=Math.round(a.x),y=Math.round(a.y),tx=Math.round(b.x),ty=Math.round(b.y),dx=Math.abs(tx-x),dy=-Math.abs(ty-y),sx=x<tx?1:-1,sy=y<ty?1:-1,error=dx+dy;
 for(;;){rect(c,color,x-Math.floor(width/2),y-Math.floor(width/2),width,width);if(x===tx&&y===ty)break;const twice=2*error;if(twice>=dy){error+=dy;x+=sx;}if(twice<=dx){error+=dx;y+=sy;}}
}
function whitePrizeClaw(c,q){
 const grip=q.grip||{x:q.initialX??q.minX,y:q.restY},anchor=q.anchor||{x:grip.x,y:q.restY-32},x=grip.x,y=grip.y-9,spread=q.closed||q.heldId?6:13;
 pixelLine(c,'#5c7581',anchor,{x,y:y-3},3);pixelLine(c,'#d6e4e4',anchor,{x,y:y-3},1);
 rect(c,'#526b7b',anchor.x-6,anchor.y-4,12,9);rect(c,'#ecf7ed',anchor.x-4,anchor.y-3,8,5);rect(c,'#768995',anchor.x-2,anchor.y-1,4,2);
 rect(c,'#839aa5',x-4,y-3,8,7);rect(c,'#e5eee4',x-3,y-2,6,4);
 for(const direction of [-1,1]){
  const points=[{x:x+direction*2,y},{x:x+direction*spread,y:y+4},{x:x+direction*(spread+1),y:y+12},{x:x+direction*(q.closed?3:spread-1),y:y+15}];
  for(let i=1;i<points.length;i++){pixelLine(c,'#546b79',points[i-1],points[i],3);pixelLine(c,'#e4f0e5',points[i-1],points[i],1);}
 }
 pixelLine(c,'#65818c',{x,y:y+3},{x,y:y+13},3);pixelLine(c,'#c5d6d0',{x,y:y+3},{x,y:y+13},1);
}
const DIGITS=['111101101101111','010110010010111','111001111100111','111001111001111','101101111001001','111100111001111','111100111101111','111001001001001','111101111101111','111101111001111'];
function tinyNumber(c,value,x,y,color='#fff3bf'){const text=String(Math.max(0,Math.floor(value)));for(let i=0;i<text.length;i++)for(let n=0;n<15;n++)if(DIGITS[Number(text[i])][n]==='1')rect(c,color,x+i*4+n%3,y+Math.floor(n/3),1,1);}
function consoleArt(c,q,room={}){
 const slot=q.payment?.slot;if(!slot)return;const x=Math.round(slot.x),y=Math.round(slot.y),floor=q.cabinet?q.cabinet.y+q.cabinet.h:room.map?.height??y+54,top=y-12,bottom=Math.max(y+18,Math.min(floor,y+54));
 rect(c,'#3b2c29',x-5,top-1,26,bottom-top+1);rect(c,'#ad7734',x-4,top,24,bottom-top);rect(c,'#f3c950',x-3,top,22,bottom-top-3);rect(c,'#fff29a',x-3,top,22,2);rect(c,'#d79139',x+16,top+2,3,bottom-top-5);
 rect(c,'#40394a',x,top+4,16,10);rect(c,'#8199a7',x+1,top+5,14,1);rect(c,'#222137',x+1,y+1,14,13);rect(c,'#e6c26c',x+7,y+3,2,8);rect(c,'#82766a',x+9,y+3,1,8);
 nativePrize(c,'Coin',{x:x+1,y:top+7,w:7,h:7},{scale:.5});tinyNumber(c,q.price??q.payment.price??1,x+10,top+7);
 const tick=room.tick??q.tick??0,inserting=(q.paymentFlash??0)>0,signal=q.needMoney?'#ec543b':inserting&&tick%4<2?'#fff7b3':q.paid?'#81e567':'#77839d';rect(c,'#3f422f',x+1,y+16,14,5);rect(c,signal,x+2,y+17,12,3);
 if(inserting){
  // The coin is a render-only receipt of an actual accepted wallet debit.
  // Its twelve-tick travel into the slot freezes with the projected state.
  const progress=Math.max(0,Math.min(1,1-q.paymentFlash/12));
  nativePrize(c,'Coin',{x:x-7+progress*12,y:y-3+progress*6,w:7,h:7},{scale:.5});
  rect(c,tick%4<2?'#fff29a':'#c79244',x+6,y+2,4,1);
 }
 // The shared native HUD owns the wallet total. This console shows only the
 // one-play price, accepted insertion and remaining paid-play indicator.
 rect(c,'#6f4c2a',x-4,bottom-3,24,3);
}
function cabinetArt(c,q,room){
 const {x,y,w,h}=q.cabinet,right=x+w,bottom=y+h,railY=q.restY-32,railLeft=Math.min(q.minX,q.deliveryX)-14,railRight=Math.max(q.maxX,q.deliveryX)+14;
 rect(c,'#152f49',x,y,w,8);rect(c,'#71929f',x+2,y+1,w-4,2);rect(c,'#dcf3e3',x+3,y+1,w-6,1);rect(c,'#315568',x,y+8,2,h-8);rect(c,'#315568',right-2,y+8,2,h-8);
 rect(c,'#73b9c9',x+2,y+8,1,h-17);rect(c,'#a7e2e2',right-3,y+8,1,h-17);rect(c,'#2e6385',x+2,bottom-10,w-4,10);rect(c,'#7bc4d0',x+2,bottom-10,w-4,2);rect(c,'#142b42',x+2,bottom-3,w-4,3);
 rect(c,'#4e6876',railLeft,railY-3,railRight-railLeft,7);rect(c,'#ceded8',railLeft+1,railY-3,railRight-railLeft-2,2);rect(c,'#8f9f9e',railLeft+1,railY+2,railRight-railLeft-2,1);
 for(let xx=q.minX;xx<=q.maxX;xx+=16)rect(c,'#677e8b',xx,railY,2,2);
 const tick=room.tick??q.tick??0,jolt=q.bombFlash>0?(Math.floor(tick/2)%2?1:-1):0,grip=q.grip||{x:q.initialX??q.minX,y:q.restY};
 whitePrizeClaw(c,jolt?{...q,grip:{...grip,x:grip.x+jolt}}:q);
 if(q.bombFlash>0&&tick%6<3)for(const [dx,dy]of [[-18,-8],[17,-5],[-11,11],[12,13]]){rect(c,'#ffe3a1',grip.x+dx,grip.y+dy,3,1);rect(c,'#f06544',grip.x+dx+1,grip.y+dy-1,1,3);}
 // Open collection tray on the player's side, aligned with actual release.
 for(const xx of [q.deliveryX-14,q.deliveryX+12]){rect(c,'#24465e',xx,q.deliveryY-8,2,22);rect(c,'#b1dbd9',xx,q.deliveryY-8,2,2);}rect(c,'#4b7184',q.deliveryX-14,q.deliveryY+12,28,3);
 // The foreground console keeps its price/slot legible if a compact author's
 // collection tray shares its horizontal display bounds.
 consoleArt(c,q,room);
 const button=room.map?.geometry?.find(g=>g.id===q.buttonId);if(button){
  const cableX=x-8,color=q.paid?'#97dacf':'#365d76';
  pixelLine(c,color,{x:button.x+8,y:button.y},{x:cableX,y:button.y},1);pixelLine(c,color,{x:cableX,y:button.y},{x:cableX,y:railY},1);pixelLine(c,color,{x:cableX,y:railY},{x:railLeft,y:railY},1);
 }
 const lampControl=room.map?.geometry?.find(g=>g.id===q.searchlight?.buttonId);
 if(lampControl){const color=q.lampOn?'#f6da77':'#755e3a',leadX=x-20,leadY=railY-5;pixelLine(c,color,{x:lampControl.x+8,y:lampControl.y},{x:lampControl.x+8,y:lampControl.y-8},1);pixelLine(c,color,{x:lampControl.x+8,y:lampControl.y-8},{x:leadX,y:lampControl.y-8},1);pixelLine(c,color,{x:leadX,y:lampControl.y-8},{x:leadX,y:leadY},1);}
 for(const lamp of room.smm2Mechanics?.lighting?.sweepingLamps||[]){
  if(lamp.enabledWhenMachine&&lamp.enabledWhenMachine!==q.id)continue;
  const on=lamp.enabledWhenMachine?!!(q.lampOn??q.searchlight?.initialOn):!lamp.enabledWhenOn||(room.switchStudyView??room.switchStudy)?.on===true||!room.switchStudyView&&room.switchStudy?.initialOn===true;
  if(lampControl&&lamp.enabledWhenMachine===q.id){const color=on?'#f6da77':'#755e3a';pixelLine(c,color,{x:x-20,y:railY-5},{x:lamp.x,y:railY-5},1);pixelLine(c,color,{x:lamp.x,y:railY-5},{x:lamp.x,y:lamp.y-8},1);}
  rect(c,'#355269',lamp.x-5,lamp.y-8,10,7);rect(c,'#b4cccf',lamp.x-4,lamp.y-7,8,2);rect(c,on?'#fff8ca':'#768c9d',lamp.x-3,lamp.y-1,6,2);
 }
}
function lampButton(c,g,q){
 const x=Math.round(g.x),y=Math.round(g.y),on=!!(q.lampOn??q.searchlight?.initialOn);
 rect(c,'#4c3425',x,y,16,16);rect(c,on?'#eebf45':'#aa7b36',x+1,y+1,14,14);rect(c,on?'#fff6b1':'#ead089',x+2,y+1,12,2);rect(c,'#725326',x+1,y+13,14,2);
 const rows=['..1111..','.111111.','11111111','11111111','.111111.','..1111..','..1111..','..1111..'];
 for(let yy=0;yy<rows.length;yy++)for(let xx=0;xx<8;xx++)if(rows[yy][xx]==='1')rect(c,on?'#fffadc':'#353b4e',x+4+xx,y+3+yy,1,1);
 rect(c,on?'#ffe288':'#858a95',x+6,y+11,4,2);
}
function joystickButton(c,g,q){
 const x=Math.round(g.x),y=Math.round(g.y),pressed=q.buttonPressed;
 rect(c,'#172e52',x,y,16,16);rect(c,pressed?'#265788':'#317fcc',x+1,y+1,14,14);rect(c,pressed?'#65a9de':'#c7f5ff',x+2,y+1,12,2);rect(c,'#153450',x+1,y+13,14,2);
 const lower=['lower','close'].includes(q.phase),tilt=lower?4:q.phase==='transfer'?-3:pressed?2:0,down=lower?3:pressed?1:0,tip={x:x+8+tilt,y:y+4+down};
 rect(c,'#0b2339',x+4,y+11,8,3);rect(c,'#85b9cf',x+5,y+11,6,1);
 pixelLine(c,'#153042',{x:x+8,y:y+12},tip,3);pixelLine(c,'#e3ece4',{x:x+8,y:y+11},tip,1);
 rect(c,'#6d211f',tip.x-2,tip.y-2,5,5);rect(c,lower?'#df6539':'#f34232',tip.x-2,tip.y-2,4,4);rect(c,'#ffad65',tip.x-1,tip.y-2,2,1);
}
export function drawCoinCraneTile(c,g,room={}){
 const records=room.contraptionsView?.coinCranes||room.contraptions?.coinCranes||[],sourceId=g.sourceId||g.id;
 if(records.some(q=>cabinet(q)&&q.glassIds?.includes(sourceId))){const x=Math.round(g.x),y=Math.round(g.y),w=Math.round(g.w),h=Math.round(g.h);rect(c,'#2c597d',x,y,w,Math.min(2,h));rect(c,'#2c597d',x,y+h-Math.min(2,h),w,Math.min(2,h));rect(c,'#4698b6',x,y,1,h);rect(c,'#a0d9df',x+w-1,y,1,h);if(w>=6){rect(c,'#5b9db7',x+2,y,1,h);for(let yy=12;yy<h-8;yy+=36)rect(c,'#bedce1',x+w-4,y+yy,1,6);}return true;}
 if(records.some(q=>q.glassIds?.includes(sourceId))){const x=Math.round(g.x),y=Math.round(g.y),w=Math.round(g.w),h=Math.round(g.h);const border=Math.min(2,h);rect(c,'#193e59',x,y,w,border);rect(c,'#193e59',x,y+h-border,w,border);rect(c,'#326987',x,y,2,h);rect(c,'#326987',x+w-2,y,2,h);rect(c,'#a4d3db',x+2,y+2,1,Math.max(0,h-4));if(w>=6)for(let yy=8;yy<h-8;yy+=24)rect(c,'#5d8d9f',x+Math.max(3,w-5),y+yy,Math.min(2,w-4),6);return true;}
 const light=records.find(q=>q.searchlight?.buttonId===sourceId);if(light){lampButton(c,g,light);return true;}
 const q=records.find(q=>q.buttonId===sourceId);if(!q)return false;
 if(cabinet(q)){joystickButton(c,g,q);return true;}
 const x=Math.round(g.x),y=Math.round(g.y),pressed=q.buttonPressed;
 rect(c,'#172e52',x,y,16,16);rect(c,pressed?'#265788':'#317fcc',x+1,y+1,14,14);rect(c,pressed?'#65a9de':'#c7f5ff',x+2,y+1,12,2);rect(c,'#153450',x+1,y+13,14,2);
 // A large upward head-bump arrow, with no ON/OFF or P-switch identity.
 const rows=['...11...','..1111..','.111111.','11111111','...11...','...11...','...11...'];
 for(let yy=0;yy<rows.length;yy++)for(let xx=0;xx<8;xx++)if(rows[yy][xx]==='1')rect(c,pressed?'#76c9eb':'#fffcef',x+4+xx,y+4+yy,1,1);
 return true;
}
export function drawCoinCraneWorld(c,room={}){
 const records=room.contraptionsView?.coinCranes||room.contraptions?.coinCranes;if(!records?.length)return false;
 for(const source of records){const q={...COIN_CRANE_DEFAULTS,...source};if(cabinet(q)){cabinetArt(c,q,room);continue;}const x=q.minX-28,right=q.maxX+28,railY=q.restY-32,railLeft=Math.min(q.minX,q.deliveryX)-28,railRight=Math.max(q.maxX,q.deliveryX)+28;
  const button=room.map?.geometry?.find(g=>g.id===q.buttonId);
  if(button){
   // A visible insulated control lead connects the head-bump button to the
   // carriage rail. It is appearance only, never a climbable support.
   const cableX=button.x+button.w+4,top=Math.min(railY,button.y+8),bottom=Math.max(railY,button.y+8);
   rect(c,'#14324d',cableX-1,top,3,bottom-top+1);
   rect(c,q.buttonPressed?'#91eddd':'#397898',cableX,top,1,bottom-top+1);
   rect(c,'#397898',Math.min(cableX,railLeft),railY,Math.abs(cableX-railLeft)+1,1);
  }
  rect(c,'#14324d',railLeft,railY-6,railRight-railLeft,12);rect(c,'#397898',railLeft+2,railY-5,railRight-railLeft-4,3);rect(c,'#a5e7ec',railLeft+2,railY-5,railRight-railLeft-4,1);rect(c,'#7093a1',railLeft+2,railY+3,railRight-railLeft-4,2);
  for(let xx=q.minX;xx<=q.maxX;xx+=16)rect(c,'#f9efb7',xx-1,railY-3,2,2);
  const grip=q.grip||{x:q.initialX??q.minX,y:q.restY},anchor=q.anchor||{x:grip.x,y:railY};drawClaw(c,{anchor,grip,closed:q.closed,heldId:q.heldId});
  // Only light chassis edges: real room geometry authors access and collision.
  if(!q.glassIds?.length){const bottom=Math.min(q.grabY+22,room.map?.height??q.grabY+22);rect(c,'#326987',x,railY+6,2,bottom-railY-6);rect(c,'#326987',right-2,railY+6,2,bottom-railY-6);rect(c,'#92c4ce',x+2,railY+6,1,bottom-railY-7);}
  for(const xx of [q.deliveryX-14,q.deliveryX+12]){rect(c,'#183448',xx,q.deliveryY-10,2,20);rect(c,'#88d4dc',xx,q.deliveryY-10,2,2);}
  if(q.payment)consoleArt(c,q,room);
 }
 return true;
}
