/** Original pixel art: grounded jelly blocks, stored honey and embedded geode.
 * No Mojang textures or images. Every foreground solid is an authored collider. */
const rect=(c,color,x,y,w,h)=>{if(w>0&&h>0){c.fillStyle=color;c.fillRect(Math.round(x),Math.round(y),Math.ceil(w),Math.ceil(h));}};
const hash=(x,y,s=0)=>{let n=Math.imul(x|0,374761393)^Math.imul(y|0,668265263)^Math.imul(s|0,982451653);n=Math.imul(n^(n>>>13),1274126177);return(n^(n>>>16))>>>0;};
const state=room=>room.minecraftView?.grotto||{};
const body=(room,id)=>(room.geometry||room.map?.geometry||[]).find(q=>q.id===id);
const line=(c,color,x,y,dx,dy,n,size=2)=>{for(let i=0;i<n;i++)rect(c,color,x+dx*i,y+dy*i,size,size);};
function crystal(c,x,y,w,h,used=false){
 const p=used?['#8b69ac','#c4a2d8','#5b427b','#dfc7ef']:['#a767d5','#dba6f6','#67418e','#fff0ff'];
 // A full faceted prism with a stepped point, light left face and dark right
 // face. It stays broad enough to read as amethyst at normal camera scale.
 for(let row=0;row<h;row++){const inset=row<4?Math.ceil((4-row)*w/9):row>h-4?Math.floor((row-h+4)/2):1,width=Math.max(1,w-inset*2),left=x+inset;rect(c,p[0],left,y+row,width,1);rect(c,p[1],left,y+row,Math.max(1,Math.floor(width*.4)),1);if(width>3)rect(c,p[2],left+width-2,y+row,2,1);}
 rect(c,p[3],x+Math.floor(w*.4),y+4,1,Math.max(1,h-8));rect(c,p[2],x+2,y+h-2,Math.max(1,w-4),2);
}
function pointedCrystal(c,x,y,w,h,rotation=0,used=false){c.save();c.translate(Math.round(x),Math.round(y));if(rotation===1){c.rotate(Math.PI/2);}else if(rotation===2){c.rotate(Math.PI);}else if(rotation===3){c.rotate(-Math.PI/2);}crystal(c,-w/2,-h,w,h,used);c.restore();}
export function drawGrottoTile(c,q,room){
 const spec=room.minecraft?.grotto;if(!spec)return false;const id=q.sourceId||q.id,honey=spec.honeyIds.includes(id),slime=spec.slimeIds.includes(id),geode=id===spec.geode?.id;if(!honey&&!slime&&!geode)return false;if(q.hidden||q.removed||q.visible===false)return true;
 const s=state(room);c.save();c.beginPath();c.rect(q.x,q.y,q.w,q.h);c.clip();
 if(geode){rect(c,'#3f344f',q.x-1,q.y,q.w+2,q.h);rect(c,'#866f96',q.x,q.y,q.w,3);for(let n=0;n<4;n++)crystal(c,q.x+n*8,q.y+(n%2?2:0),8,16-(n%2?2:0),s.geodeUsed);c.restore();return true;}
 const p=slime?['#75b65a','#bbdf87','#3c713d','#d5f7ae','#4c9547']:['#c88727','#ffe074','#8b4d1e','#fff1a7','#e7a932'];
 for(let y=q.y;y<q.y+q.h;y+=16)for(let x=q.x;x<q.x+q.w;x+=16){
  rect(c,p[2],x,y,16,16);rect(c,p[0],x+1,y+1,13,13);rect(c,p[1],x+1,y,13,3);rect(c,p[4],x+12,y+3,3,12);rect(c,p[3],x+2,y+1,10,1);rect(c,p[1],x+1,y+3,1,10);rect(c,p[2],x+1,y+14,14,2);
  if(honey){const n=((x-q.x)/16*7+(y-q.y)/16*11)%5;
   c.globalAlpha*=.26;rect(c,'#ffe28d',x+2,y+3,9,10);rect(c,'#9b571c',x+8,y+5,4,8);c.globalAlpha/=.26;
   // Amber density and trapped two-pixel bubbles replace the old white Ls.
   rect(c,'#eebd51',x+3,y+5+n,6,2);rect(c,'#d48b29',x+4,y+8+n%3,7,2);rect(c,'#f9d471',x+3+n,y+4,2,2);rect(c,'#b76a22',x+4+n,y+6,1,1);rect(c,'#ffe691',x+9-n,y+10,2,1);rect(c,'#ae631e',x+9,y+12,2,1);rect(c,'#fff1b2',x+2,y+4,1,4);
  }else{c.globalAlpha*=.48;rect(c,p[1],x+4,y+5,7,7);rect(c,p[2],x+6,y+7,5,5);c.globalAlpha/=.48;rect(c,p[1],x+3,y+5,2,2);rect(c,p[2],x+5,y+9,2,2);rect(c,p[3],x+10,y+5,2,1);rect(c,'#91c76d',x+4,y+11,2,1);}

 }
 // A shallow exposed top plane gives stored translucent cubes a visible volume.
 if(honey){for(let i=0;i<3;i++)rect(c,i<2?p[1]:p[0],q.x+i,q.y+i,q.w-i,1);rect(c,p[3],q.x+3,q.y,q.w-5,1);}
 c.restore();c.save();
 if(slime&&s.slimePulse){const phase=1-s.slimePulse/18;for(let n=0;n<5;n++){const x=q.x+8+n*(q.w-16)/4,y=q.y-2-Math.sin(phase*Math.PI)*8-n%2*2;rect(c,p[n%2?1:3],x,y,2,2);}}
 c.restore();return true;
}
export function drawGrottoScenery(c,room){
 const spec=room.minecraft?.grotto;if(!spec)return false;const g=room.map.geometry,v=room.renderBounds,w=Math.max(room.map.width,v?v.x+v.w:0),h=Math.max(room.map.height,v?v.y+v.h:0),tick=room.tick||0;
 rect(c,'#273c39',0,0,w,h);
 // Deep green-grey stone is geological, with no repeated panel/mortar grid.
 // Broad rough pockets stay behind all authored solids, crystals and actors.
 for(let y=26;y<h;y+=21)for(let x=-8;x<w;x+=29){const n=hash(x,y,37),dx=x+n%5,dy=y+(n>>>4)%4;rect(c,['#2d433d','#31463f','#293f3c','#34483f'][n%4],dx,dy,24,13);rect(c,'#30453d',dx+5,dy-4,14,5);if(n%4===0){rect(c,'#203632',dx+4,dy+9,8,2);rect(c,'#243b36',dx+10,dy+11,7,1);}if(n%5===0){rect(c,'#486044',dx+2,dy+2,3,2);rect(c,'#38543d',dx+4,dy+4,5,2);}}
 // Broken mineral beds snake across the wall; none is a solid, bright ledge.
 for(let row=0;row<8;row++)for(let x=4;x<w;x+=37){const n=hash(x,row,19),y=48+row*30+n%4;if(n%3===0)continue;rect(c,'#3e5145',x,y,22+n%9,1);rect(c,'#203a34',x+6,y+2,17,1);}
 for(const [cx,top,width]of [[176,52,74],[292,73,48],[437,99,54]]){const bottom=266;for(let step=0;step<4;step++){const inset=step*4;rect(c,step%2?'#203933':'#233b35',cx+inset,top+step*10,width-inset*2,bottom-top-step*10);}for(let n=0;n<5;n++){rect(c,'#385044',cx-2,top+22+n*23,3,12);rect(c,'#30483e',cx+width-2,top+15+n*25,2,17);}}
 // Roots remain attached to the real ceiling, with tapering side branches.
 for(const [x,depth]of [[24,55],[102,40],[186,58],[304,56],[478,98]]){rect(c,'#493d2a',x,30,8,depth);rect(c,'#877147',x+2,32,3,depth-3);for(let k=0;k<3;k++){rect(c,'#65543a',x-5+k*4,30+depth+k*3,10-k*2,3);rect(c,'#8a744b',x-4+k*4,30+depth+k*3,7-k*2,1);}line(c,'#446f46',x+11,48,0,5,Math.floor(depth/5),2);for(let k=0;k<depth/12;k++)rect(c,'#77964f',x+9+(k%2)*3,52+k*11,5,3);}
 // Fractured geode is a torn mineral cavity, not a smooth framed oval.
 // Its stepped outer rock remains joined to the authored ceiling, while large
 // differently oriented crystal fans make its material and bud unmistakable.
 const bud=g.find(q=>q.id===spec.geode?.id);if(bud){const cx=bud.x+bud.w/2,used=state(room).geodeUsed;
  rect(c,'#364540',cx-22,30,39,30);rect(c,'#4d5950',cx-18,32,27,32);rect(c,'#596153',cx-11,38,12,15);
  for(const [dx,y,width,height]of [[-29,47,47,18],[-37,61,70,22],[-43,83,80,24],[-38,107,73,27],[-29,134,54,15],[-18,146,37,13]]){
   rect(c,'#4e5550',cx+dx,y,width,height);rect(c,'#6e7567',cx+dx+3,y+2,width-7,height-3);rect(c,'#a6ad96',cx+dx+6,y+4,width-13,height-5);rect(c,'#766285',cx+dx+10,y+7,width-21,Math.max(3,height-7));
  }
  // Unequal broken calcite lips and violet block faces expose the interior.
  rect(c,'#302943',cx-19,70,40,64);rect(c,'#443257',cx-25,84,50,42);rect(c,'#382a4e',cx-20,78,39,51);rect(c,'#604179',cx-19,92,13,16);rect(c,'#503461',cx+5,103,14,17);rect(c,'#76538c',cx-10,125,26,15);
  for(const [dx,dy,width,height]of [[-31,66,8,13],[-37,89,9,14],[24,77,8,17],[26,112,7,14],[-25,132,9,9],[5,56,11,8]]){rect(c,'#ced0b3',cx+dx,dy,width,height);rect(c,'#8b9580',cx+dx+width-2,dy+2,2,height-2);}
  // Cracks break across shell layers instead of forming a polished closed rim.
  line(c,'#34423b',cx-17,46,-3,3,6,3);line(c,'#34423b',cx+29,104,3,2,4,3);line(c,'#3a3c42',cx-28,132,3,3,5,2);
  for(const [dx,y,width,height,rotation]of [[-9,83,12,24,2],[8,80,10,20,2],[-28,104,11,25,1],[29,96,10,22,3],[-20,133,13,29,0],[3,141,16,36,0],[23,132,10,24,0],[-8,118,9,22,0]])pointedCrystal(c,cx+dx,y,width,height,rotation,true);
  // The lower, bright growing cluster is the actual bonkable 32×16 collider.
  rect(c,'#82559e',bud.x-4,bud.y-7,bud.w+8,7);rect(c,'#b681cc',bud.x-1,bud.y-7,bud.w-2,2);
  if(!used){pointedCrystal(c,cx-2,bud.y+1,12,26,0,false);pointedCrystal(c,cx+9,bud.y,9,19,0,false);const phase=Math.floor(tick/12)%4;if(phase<2){rect(c,'#ead0fa',cx-8,bud.y-17,1,5);rect(c,'#ead0fa',cx-10,bud.y-15,5,1);}}
 }
 // Honey is a small stored supply: wooden crate plinth, straps and end stops.
 for(const id of spec.honeyIds){const q=g.find(q=>q.id===id);if(!q)continue;rect(c,'#57422b',q.x-3,q.y+q.h-2,q.w+6,5);rect(c,'#b39252',q.x-3,q.y+q.h-2,q.w+6,1);for(const x of [q.x-3,q.x+q.w]){rect(c,'#685335',x,q.y+q.h-14,3,17);rect(c,'#c4ab67',x,q.y+q.h-13,1,13);}for(let n=0;n<3;n++){const x=q.x+16+n*32;rect(c,'#625234',x,q.y+q.h+3,3,29);rect(c,'#b19d63',x,q.y+q.h+5,1,24);}}
 // Moss grows only on an actual ledge or floor. No decorative floating land.
 for(const q of g.filter(q=>/entry|return|floor/.test(q.id)))for(let x=q.x+7;x<q.x+q.w;x+=23){const buried=g.some(o=>o!==q&&x>=o.x&&x<o.x+o.w&&o.y<=q.y&&o.y+o.h>=q.y);if(!buried){rect(c,'#507345',x,q.y-2,9,3);rect(c,'#86a35c',x+2,q.y-3,4,1);}}
 for(const id of spec.slimeIds){const q=g.find(q=>q.id===id);if(!q)continue;c.globalAlpha=.12;rect(c,'#9acb7e',q.x-8,q.y-20,q.w+16,20);c.globalAlpha=1;}
 return true;
}
export function drawGrottoWorld(c,room,view){
 const spec=room.minecraft?.grotto,s=(view?.minecraft||view||room.minecraftView)?.grotto;if(!spec||!s)return;
 drawAmethystReward(c,s.reward,room.tick||0);
 const q=body(room,spec.geode?.id);if(q&&s.geodePulse){c.save();const t=70-s.geodePulse;for(let n=0;n<8;n++){const a=n*Math.PI/4,r=t*.55;c.globalAlpha=Math.max(0,1-t/70);rect(c,n%2?'#dba7ff':'#fff0ff',q.x+q.w/2+Math.cos(a)*r,q.y+7+Math.sin(a)*r-t*.25,2+n%2,2+n%2);}c.restore();}
}

/** Physical amethyst loot projection, driven entirely by the controller's drop
 * and contact pickup. Only the tiny settled shimmer is visual; bounds stay put. */
function drawAmethystReward(c,q,tick){
 if(!q||q.hidden||q.visible===false)return;
 const age=q.collectedAge??q.age??0,cx=q.x+(q.w||10)/2,cy=q.y+(q.h||12)/2;
 c.save();
 if(q.state==='collected'){
  const t=Math.max(0,Math.min(1,age/36));if(t<1){c.globalAlpha*=1-t;for(let i=0;i<12;i++){const angle=i*2.399,r=3+t*(12+i%4*3);rect(c,i%3?'#dbadfa':'#ffe098',cx+Math.cos(angle)*r,cy+Math.sin(angle)*r-t*14,2,2);}const hx=cx-3,hy=cy-7-t*20;rect(c,'#e8be68',hx,hy+1,3,3);rect(c,'#e8be68',hx+4,hy+1,3,3);rect(c,'#e8be68',hx+1,hy+4,5,1);rect(c,'#e8be68',hx+2,hy+5,3,1);rect(c,'#e8be68',hx+3,hy+6,1,1);rect(c,'#f77f9e',hx+1,hy+2,5,2);rect(c,'#ffcfda',hx+1,hy+1,1,1);}
  c.restore();return;
 }
 const bob=q.state==='settled'?Math.round(Math.sin(tick*.12)):0,spin=[8,6,3,6][Math.floor(age/7)%4],x=Math.round(cx-spin/2),y=Math.round(q.y+bob);
 const alpha=c.globalAlpha;for(let r=3;r>0;r--){c.globalAlpha=alpha*.035;rect(c,'#c98aed',cx-spin/2-r*3,y-r*3,spin+r*6,12+r*6);}c.globalAlpha=alpha;
 for(let row=0;row<12;row++){const inset=row<3?3-row:row>8?row-8:0,width=Math.max(1,spin-inset*2),left=Math.round(cx-width/2);rect(c,'#9d59cd',left,y+row,width,1);rect(c,'#e2b4fb',left,y+row,Math.max(1,Math.floor(width*.4)),1);if(width>3)rect(c,'#654084',left+width-2,y+row,2,1);}
 rect(c,'#fff0ff',x+Math.max(0,Math.floor(spin*.35)),y+3,1,5);if(q.state==='settled'){const offset=Math.floor(tick/12)%4;rect(c,'#f4dbff',cx-8,y+2+offset,1,3);rect(c,'#f4dbff',cx-9,y+3+offset,3,1);}else{c.globalAlpha*=.6;rect(c,'#be89e4',cx-2,y-5,2,2);rect(c,'#7d56ad',cx+3,y-9,1,2);}
 c.restore();
}
