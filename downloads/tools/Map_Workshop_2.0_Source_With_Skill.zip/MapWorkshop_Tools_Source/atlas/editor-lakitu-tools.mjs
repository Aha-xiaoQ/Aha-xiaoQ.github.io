import {pruneSkyShooterReferences} from './editor-sky-shooter-tools.mjs';
/** Observed Cloud/rail Grinder authoring. All coefficients are explicit local
 * fits. Clouds are independent components, never proxy native walker actors.
 * Native hazard clipboard edits preserve their real body, profile and curve in
 * one History transaction. No rewards, teleports or direct goal completion. */
import {uid,validate} from './editor-model.mjs';
import {validateLakituClouds} from './editor-lakitu-clouds.mjs';
import {validateRailHazards} from './editor-rail-hazards.mjs';
import {validateLakituCloudPlacement} from './editor-lakitu-placement.mjs';
export {validateLakituCloudPlacement} from './editor-lakitu-placement.mjs';

const cloudFields=['x','y','w','h','acceleration','maxSpeed','drag','seatOffsetY','boardTolerance','hoverAmplitude','hoverPeriodFrames'];
const hazardFields=['trackId','speed','distance','direction','collisionRadius','rotationFrames','rotationDirection'];
const plain=value=>value&&typeof value==='object'&&!Array.isArray(value)&&[Object.prototype,null].includes(Object.getPrototypeOf(value));
function fields(value,allowed,label,{required=true}={}){
 if(!plain(value))throw Error('Invalid '+label);
 for(const key of Reflect.ownKeys(value))if(typeof key!=='string'||['__proto__','constructor','prototype'].includes(key)||!allowed.includes(key))throw Error('Unknown '+label+' field: '+String(key));
 if(required)for(const key of allowed)if(!Object.hasOwn(value,key))throw Error('Missing '+label+' field: '+key);
}
const mechanics=room=>(room.smm2Mechanics??={version:1});
function clean(room){const s=room.smm2Mechanics;if(!s)return;if(s.lakituClouds&&!s.lakituClouds.clouds.length)delete s.lakituClouds;if(s.railHazards&&!s.railHazards.hazards.length)delete s.railHazards;if(s.goalCloudRequirements&&!s.goalCloudRequirements.length)delete s.goalCloudRequirements;}
function edit(room,operation){
 const next=structuredClone(room);operation(next);pruneSkyShooterReferences(next,room);validateLakituClouds(next);validateRailHazards(next);validateLakituCloudPlacement(next);
 validate({format:'xiaoq-map-project',version:1,id:'cloud-rail-authoring-check',title:'Cloud and rail authoring',rooms:[next]},{allowIncompleteCompletionMarks:true});
 for(const key of Object.keys(room))if(!Object.hasOwn(next,key))delete room[key];Object.assign(room,next);
}

export function setLakituCloud(room,id,options){
 fields(options,cloudFields,'Lakitu Cloud authoring');
 edit(room,r=>{const leaf=mechanics(r).lakituClouds??={version:1,clouds:[]},value={id,...structuredClone(options)},index=leaf.clouds.findIndex(q=>q.id===id);if(index<0)leaf.clouds.push(value);else leaf.clouds[index]=value;});
 return id;
}
export function removeLakituCloud(room,id){
 if(!room.smm2Mechanics?.lakituClouds?.clouds.some(q=>q.id===id))return;
 edit(room,r=>{const s=r.smm2Mechanics;s.lakituClouds.clouds=s.lakituClouds.clouds.filter(q=>q.id!==id);if(s.goalCloudRequirements)s.goalCloudRequirements=s.goalCloudRequirements.filter(q=>q.cloudId!==id);clean(r);});
}
/** Copy the saved component configuration, with a new stable ID and position. */
export function cloneLakituCloud(room,sourceId,newId,options){
 fields(options,['x','y'],'Lakitu Cloud clone position');const {x,y}=options;
 const source=room.smm2Mechanics?.lakituClouds?.clouds.find(q=>q.id===sourceId);
 if(!source||sourceId===newId||room.smm2Mechanics.lakituClouds.clouds.some(q=>q.id===newId))throw Error('请选择已有云，并为复制云使用新的 ID');
 const {id,...config}=structuredClone(source);return setLakituCloud(room,newId,{...config,x,y});
}
export function setGoalCloudRequirement(room,exitId,cloudId){
 edit(room,r=>{if(!r.map.objects.some(q=>q.id===exitId&&q.kind==='exit')||!r.smm2Mechanics?.lakituClouds?.clouds.some(q=>q.id===cloudId))throw Error('请选择真实终点与已有 Lakitu Cloud');const list=mechanics(r).goalCloudRequirements??=[],value={exitId,cloudId},index=list.findIndex(q=>q.exitId===exitId);if(index<0)list.push(value);else list[index]=value;});
}
export function clearGoalCloudRequirement(room,exitId){
 if(!room.smm2Mechanics?.goalCloudRequirements?.some(q=>q.exitId===exitId))return;
 edit(room,r=>{r.smm2Mechanics.goalCloudRequirements=r.smm2Mechanics.goalCloudRequirements.filter(q=>q.exitId!==exitId);clean(r);});
}
export function setRailHazard(room,id,options){
 fields(options,hazardFields,'rail hazard authoring');
 edit(room,r=>{const leaf=mechanics(r).railHazards??={version:1,hazards:[]},value={id,...structuredClone(options)},index=leaf.hazards.findIndex(q=>q.id===id);if(index<0)leaf.hazards.push(value);else leaf.hazards[index]=value;});
}
export function removeRailHazard(room,id){
 if(!room.smm2Mechanics?.railHazards?.hazards.some(q=>q.id===id))return;
 edit(room,r=>{r.smm2Mechanics.railHazards.hazards=r.smm2Mechanics.railHazards.hazards.filter(q=>q.id!==id);clean(r);});
}
/** Prune references only when a real prior target has just been removed. New
 * malformed bindings still reach full validation and roll back the native edit.
 * Removing native hazards never deletes a shared guide track. */
export function pruneLakituReferences(room,before){
 if(!before||!room.smm2Mechanics)return;
 const nativeIds=new Set(room.map.objects.map(q=>q.id)),removedNative=new Set(before.map.objects.filter(q=>!nativeIds.has(q.id)).map(q=>q.id));
 const cloudIds=new Set(room.smm2Mechanics.lakituClouds?.clouds.map(q=>q.id)||[]),removedClouds=new Set((before.smm2Mechanics?.lakituClouds?.clouds||[]).filter(q=>!cloudIds.has(q.id)).map(q=>q.id));
 const trackIds=new Set(room.contraptions?.tracks?.map(q=>q.id)||[]),removedTracks=new Set((before.contraptions?.tracks||[]).filter(q=>!trackIds.has(q.id)).map(q=>q.id));
 const s=room.smm2Mechanics;
 if(s.railHazards){const prior=before.smm2Mechanics?.railHazards?.hazards||[];s.railHazards.hazards=s.railHazards.hazards.filter(q=>!prior.some(old=>old.id===q.id&&old.trackId===q.trackId&&(removedNative.has(q.id)||removedTracks.has(q.trackId))));}
 if(s.goalCloudRequirements){const prior=before.smm2Mechanics?.goalCloudRequirements||[];s.goalCloudRequirements=s.goalCloudRequirements.filter(q=>!prior.some(old=>old.exitId===q.exitId&&old.cloudId===q.cloudId&&(removedNative.has(q.exitId)||removedClouds.has(q.cloudId))));}
 clean(room);
}

export function captureRailHazardBindings(room,ids){
 if(!(ids instanceof Set))throw Error('Invalid selected native hazard IDs');validateRailHazards(room);
 const hazards=structuredClone((room.smm2Mechanics?.railHazards?.hazards||[]).filter(q=>ids.has(q.id))),tracks=new Set(hazards.map(q=>q.trackId));
 return {hazards,tracks:structuredClone((room.contraptions?.tracks||[]).filter(q=>tracks.has(q.id)))};
}
function allIds(room){const ids=new Set();const walk=value=>{if(!value||typeof value!=='object')return;if(typeof value.id==='string')ids.add(value.id);for(const child of Object.values(value))walk(child);};walk(room);return ids;}
export function appendCopiedRailHazardBindings(room,snapshot,idMap,translation){
 if(snapshot==null)return;fields(translation,['dx','dy'],'copied guide translation');const {dx,dy}=translation;fields(snapshot,['hazards','tracks'],'rail hazard clipboard');
 if(!Array.isArray(snapshot.hazards)||!Array.isArray(snapshot.tracks)||snapshot.hazards.length>256||snapshot.tracks.length>128||!(idMap instanceof Map)||!Number.isFinite(dx)||!Number.isFinite(dy))throw Error('Invalid rail hazard clipboard');
 if(!snapshot.hazards.length){if(snapshot.tracks.length)throw Error('Rail hazard clipboard has unbound tracks');return;}
 edit(room,r=>{
  const trackMap=new Map(),ids=allIds(r),needed=new Set(snapshot.hazards.map(q=>q.trackId));
  r.contraptions??={version:1};r.contraptions.tracks??=[];
  for(const source of snapshot.tracks){
   fields(source,['id','start','segments',...(Object.hasOwn(source,'mode')?['mode']:[])],'copied guide track');
   if(typeof source.id!=='string'||source.id.length>72||!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(source.id))throw Error('Invalid copied guide track ID');
   if(trackMap.has(source.id)||!needed.has(source.id))throw Error('Duplicate or unbound copied guide track');
   let id;do{id=uid();}while(ids.has(id));ids.add(id);trackMap.set(source.id,id);
   const point=p=>{if(!Array.isArray(p)||p.length!==2||!p.every(Number.isFinite))throw Error('Invalid copied guide point');return [p[0]+dx,p[1]+dy];};
   if(!Array.isArray(source.segments))throw Error('Invalid copied guide segments');
   const segments=source.segments.map(q=>{fields(q,['kind','to',...(q.kind==='quadratic'?['control']:[])],'copied guide segment');return {...structuredClone(q),to:point(q.to),...(q.control?{control:point(q.control)}:{})};});
   r.contraptions.tracks.push({...structuredClone(source),id,start:point(source.start),segments});
  }
  const leaf=mechanics(r).railHazards??={version:1,hazards:[]},seen=new Set();
  for(const source of snapshot.hazards){
   fields(source,['id',...hazardFields],'copied rail hazard');
   const id=idMap.get(source.id),trackId=trackMap.get(source.trackId);
   if(!id||id===source.id||!trackId||seen.has(id)||leaf.hazards.some(q=>q.id===id))throw Error('复制轨道危险区需要新的原生 ID 与完整轨道');seen.add(id);
   leaf.hazards.push({...structuredClone(source),id,trackId});
  }
 });
}

const cloudSeed={x:64,y:64,w:20,h:16,acceleration:.16,maxSpeed:2,drag:.125,seatOffsetY:-4,boardTolerance:2,hoverAmplitude:0,hoverPeriodFrames:120};
const cloudInputs=[['x','空云 X'],['y','空云 Y'],['w','宽（固定 20）'],['h','高（固定 16）'],['acceleration','驾驶加速度'],['maxSpeed','最高速度'],['drag','松手减速'],['seatOffsetY','乘员 Y 偏移'],['boardTolerance','顶面最小水平重叠'],['hoverAmplitude','空云浮动幅度'],['hoverPeriodFrames','空云浮动周期（帧）']];
const hazardSeed={speed:1,distance:0,direction:1,collisionRadius:22,rotationFrames:160,rotationDirection:-1};
const hazardInputs=[['speed','轨道速度'],['distance','初始轨道距离'],['direction','轨道方向（1 / -1）'],['collisionRadius','真实圆形接触半径'],['rotationFrames','一圈旋转帧数'],['rotationDirection','旋转方向（1 / -1）']];
const input=(prefix,[key,label])=>'<label>'+label+'<input type="number" step="any" data-lakitu-tool="'+prefix+key+'"></label>';

export function mountLakituTools({parent,room,selected=()=>new Set(),change,report=()=>{}}){
 const panel=document.createElement('details');panel.id='lakitu-tools';parent.append(panel);
 panel.innerHTML='<summary>空 Lakitu Cloud 与轨道 Grinder</summary><p class="small">本地参数需按原动态核对。空云是独立 20×16 组件；驾驶碰撞仍属于真实乘员身体。使用此面板编辑、删除与复制空云。</p><label>已有空云<select data-lakitu-tool="cloud"></select></label><button type="button" data-lakitu-tool="cloud-new">填写新空云</button><label>空云稳定 ID<input type="text" data-lakitu-tool="cloud-id"></label>'+cloudInputs.map(q=>input('cloud-',q)).join('')+'<button type="button" data-lakitu-tool="cloud-apply">放置 / 更新空云</button><button type="button" data-lakitu-tool="cloud-remove">删除所选空云</button><label>复制云的新 ID<input type="text" data-lakitu-tool="clone-id"></label><label>复制云 X<input type="number" step="any" data-lakitu-tool="clone-x"></label><label>复制云 Y<input type="number" step="any" data-lakitu-tool="clone-y"></label><button type="button" data-lakitu-tool="cloud-clone">复制已保存云配置到新位置</button><label>真实终点<select data-lakitu-tool="goal"></select></label><label>必须驾驶的云<select data-lakitu-tool="goal-cloud"></select></label><button type="button" data-lakitu-tool="goal-apply">要求驾驶所选云接触此终点</button><button type="button" data-lakitu-tool="goal-remove">移除此终点的驾驶要求</button><p class="small">Grinder 绑定已有正方形原生危险区与轨道。轨道与曲线请在「轨道、搬运与钥匙机关」编辑；本地参数需按原动态核对。</p><label>真实正方形危险区<select data-lakitu-tool="hazard"></select></label><label>已有轨道<select data-lakitu-tool="track"></select></label>'+hazardInputs.map(q=>input('hazard-',q)).join('')+'<button type="button" data-lakitu-tool="hazard-apply">绑定 / 更新轨道 Grinder</button><button type="button" data-lakitu-tool="hazard-remove">移除 Grinder 绑定</button><p class="small" data-lakitu-tool="status"></p>';
 const get=key=>panel.querySelector('[data-lakitu-tool="'+key+'"]'),number=key=>{const raw=String(get(key).value).trim();if(!raw)throw Error('请填写本地参数 '+key);const value=Number(raw);if(!Number.isFinite(value))throw Error('本地参数必须是有限数值 '+key);return value;};
 let currentCloud='',newMode=true,lastRoom=null,lastSelection='';
 const attempt=fn=>{try{change(fn);}catch(error){report(error.message);}refresh();};
 const newCloudId=()=>('lakitu-cloud-'+uid().slice(2)).slice(0,72);
 get('cloud-new').onclick=()=>{newMode=true;currentCloud='';get('cloud-id').value=newCloudId();refresh();};
 get('cloud').onchange=()=>{currentCloud=get('cloud').value;newMode=!currentCloud;refresh();};
 get('cloud-apply').onclick=()=>attempt(()=>{const id=newMode?get('cloud-id').value.trim():currentCloud;if(newMode&&room().smm2Mechanics?.lakituClouds?.clouds.some(q=>q.id===id))throw Error('新空云需要未使用的 ID');setLakituCloud(room(),id,Object.fromEntries(cloudFields.map(key=>[key,number('cloud-'+key)])));currentCloud=id;newMode=false;});
 get('cloud-remove').onclick=()=>attempt(()=>{removeLakituCloud(room(),currentCloud);currentCloud='';newMode=true;});
 get('cloud-clone').onclick=()=>attempt(()=>{currentCloud=cloneLakituCloud(room(),currentCloud,get('clone-id').value.trim(),{x:number('clone-x'),y:number('clone-y')});newMode=false;});
 get('goal-apply').onclick=()=>attempt(()=>setGoalCloudRequirement(room(),get('goal').value,get('goal-cloud').value));
 get('goal-remove').onclick=()=>attempt(()=>clearGoalCloudRequirement(room(),get('goal').value));
 get('hazard-apply').onclick=()=>attempt(()=>setRailHazard(room(),get('hazard').value,{trackId:get('track').value,...Object.fromEntries(hazardInputs.map(([key])=>[key,number('hazard-'+key)]))}));
 get('hazard-remove').onclick=()=>attempt(()=>removeRailHazard(room(),get('hazard').value));
 for(const key of ['goal','hazard'])get(key).onchange=()=>refresh();
 function fill(key,rows,pick,{blank=false}={}){const node=get(key),options=rows.map(q=>{const option=document.createElement('option');option.value=q.id;option.textContent=q.id;return option;});if(blank){const option=document.createElement('option');option.value='';option.textContent='新空云';options.unshift(option);}node.replaceChildren(...options);node.value=rows.some(q=>q.id===pick)?pick:blank?'':rows[0]?.id||'';}
 function refresh(){
  const r=room(),s=r.smm2Mechanics,clouds=s?.lakituClouds?.clouds||[],ids=selected(),signature=[...ids].sort().join('|'),roomChanged=lastRoom!==r,selectionChanged=roomChanged||lastSelection!==signature;
  if(roomChanged){currentCloud=clouds[0]?.id||'';newMode=!currentCloud;get('cloud-id').value=newCloudId();}
  if(!newMode&&!clouds.some(q=>q.id===currentCloud)){currentCloud=clouds[0]?.id||'';newMode=!currentCloud;}
  fill('cloud',clouds,newMode?'':currentCloud,{blank:true});const cloud=clouds.find(q=>q.id===currentCloud),values=newMode?cloudSeed:cloud;
  if(!newMode)get('cloud-id').value=currentCloud;else if(!get('cloud-id').value)get('cloud-id').value=newCloudId();get('cloud-id').readOnly=!newMode;
  for(const [key]of cloudInputs){get('cloud-'+key).value=String(values?.[key]??cloudSeed[key]);get('cloud-'+key).readOnly=['w','h'].includes(key);}
  get('clone-id').value=newCloudId();get('clone-x').value=String((cloud?.x??cloudSeed.x)+32);get('clone-y').value=String(cloud?.y??cloudSeed.y);
  get('cloud-remove').disabled=get('cloud-clone').disabled=!cloud;
  const goals=r.map.objects.filter(q=>q.kind==='exit'),hazards=r.map.objects.filter(q=>q.kind==='hazard'&&q.w===q.h&&!q.spikeTrap&&!r.contraptions?.spikeTraps?.some(s=>s.id===q.id)),tracks=r.contraptions?.tracks||[],pick=rows=>selectionChanged&&ids.size===1&&rows.some(q=>ids.has(q.id))?[...ids][0]:null;
  fill('goal',goals,pick(goals)||(roomChanged?goals[0]?.id:get('goal').value));const requirement=s?.goalCloudRequirements?.find(q=>q.exitId===get('goal').value);
  fill('goal-cloud',clouds,requirement?.cloudId||(roomChanged?currentCloud:get('goal-cloud').value));
  fill('hazard',hazards,pick(hazards)||(roomChanged?s?.railHazards?.hazards[0]?.id:get('hazard').value));const hazard=s?.railHazards?.hazards.find(q=>q.id===get('hazard').value);
  fill('track',tracks,hazard?.trackId||(roomChanged?tracks[0]?.id:get('track').value));const nativeHazard=hazards.find(q=>q.id===get('hazard').value);for(const [key]of hazardInputs)get('hazard-'+key).value=String(hazard?.[key]??(key==='collisionRadius'?Math.min(hazardSeed.collisionRadius,(nativeHazard?.w??48)/2):hazardSeed[key]));
  get('goal-apply').disabled=!goals.length||!clouds.length;get('goal-remove').disabled=!requirement;get('hazard-apply').disabled=!hazards.length||!tracks.length;get('hazard-remove').disabled=!hazard;
  get('status').textContent='空云 '+clouds.length+' 个；轨道 Grinder '+(s?.railHazards?.hazards.length??0)+' 个；驾驶终点要求 '+(s?.goalCloudRequirements?.length??0)+' 个';lastRoom=r;lastSelection=signature;
 }
 refresh();return Object.freeze({refresh});
}
