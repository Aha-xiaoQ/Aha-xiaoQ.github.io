import {SMM1_SMB1_SPRINGBOARD_SOURCE as source} from './editor-smm2-spring-source-pixels.mjs';

/** Source standing pixels for explicitly typed, weighted SMB1 Springboards.
 * Only the ten coil rows are resampled during native compression. The original
 * three-row upper/lower caps remain intact wherever the real body has room.
 * An unusually shorter body samples cap rows within its own actual height,
 * rather than growing the visible body. This is an authored visual
 * adaptation, not a recovered Nintendo compressed frame or animation rip.
 * Rendering reads the real body; it never writes collision, mass or velocity.
 */
const valid=q=>q&&['x','y','w','h'].every(k=>Number.isFinite(q[k]))&&q.w>0&&q.h>0;
const colors=source.palette.map(p=>'#'+p.map(n=>n.toString(16).padStart(2,'0')).join(''));

export function isSmm2WeightedSpringArt(q,room={}){
 if(room.smm2Mechanics?.version!==1||room.smm2Mechanics.art?.palette?.startsWith('smb3-')||!valid(q)||q.material!=='spring'||q.springOrientation==='horizontal')return false;
 const id=q.sourceId||q.id,rule=room.smm2Mechanics.carrierGeometry?.find(s=>s.id===id&&s.carrierType==='seesaw');
 if(!rule||!room.smm2Mechanics.seesaws?.some(s=>s.id===rule.carrierId)||room.smm2Mechanics.springs?.some(s=>s.id===id&&s.orientation==='horizontal'))return false;
 const authored=room.map?.geometry?.find(g=>g.id===id),restHeight=q.restH??q.h;
 if(!authored||![16,32].includes(authored.w)||authored.h!==authored.w||q.w!==authored.w||restHeight!==authored.h||q.h>restHeight)return false;
 const live=q.smm2CarrierGeometry;
 return !live||live.carrierType==='seesaw'&&live.carrierId===rule.carrierId;
}

/** 16 x 16 is exact. The only larger source size is the explicit author 32 x 32
 * adaptation, with both axes scaled equally. Unsupported source shapes return
 * no pose; they cannot gain a smaller sprite over an invisible wider collider.
 * Raster rounding is shared by preview, offline play and native video.
 */
export function smm2WeightedSpringVisualPose(q){
 if(!valid(q))return null;
 const restHeight=Number.isFinite(q.restH)&&q.restH>=q.h?q.restH:q.h;
 if(![16,32].includes(restHeight)||q.w!==restHeight)return null;
 const scale=restHeight/source.width,w=q.w,bottom=Math.round(q.y+q.h),y=Math.round(q.y),h=bottom-y,strips=[];
 const append=(rows,height,top)=>{for(let i=0;i<rows.length;i++){const from=Math.round(i*height/rows.length),to=Math.round((i+1)*height/rows.length);strips.push({sourceRow:rows[i],y:top+from,h:to-from});}};
 const sample=(first,count)=>Array.from({length:count},(_,i)=>first+Math.min(2,Math.floor((i+.5)*3/count)));
 const completeCaps=h>=6*scale;
 if(completeCaps){const capHeight=3*scale,coilHeight=h-2*capHeight,coilRows=Math.max(0,Math.round(coilHeight/scale));append([0,1,2],capHeight,0);if(coilRows)append(Array.from({length:coilRows},(_,i)=>3+Math.min(9,Math.floor((i+.5)*10/coilRows))),coilHeight,capHeight);append([13,14,15],capHeight,h-capHeight);}
 else if(h>0){const topHeight=Math.ceil(h/2),bottomHeight=h-topHeight;append(sample(0,Math.min(3,Math.ceil(topHeight/scale))),topHeight,0);if(bottomHeight)append(sample(13,Math.min(3,Math.ceil(bottomHeight/scale))),bottomHeight,topHeight);}
 const rows=strips.map(s=>s.sourceRow);
 return {x:Math.round(q.x),y,w,h,bottom,physicalBottom:q.y+q.h,scale,sourceHeight:rows.length,rows,strips,capMode:completeCaps?'source-complete':'sampled-to-body',
  pose:q.h===restHeight?'source-standing':'authored-compression',
  sizing:restHeight===16?'original-16px':'authored-32px-2x'};
}

export function drawSmm2WeightedSpring(c,q,room={}){
 if(!isSmm2WeightedSpringArt(q,room)||q.hidden||q.visible===false||q.removed||q.dead)return false;
 const p=smm2WeightedSpringVisualPose(q);if(!p||!p.w||!p.h)return false;
 const fillStyle=c.fillStyle;c.save();c.imageSmoothingEnabled=false;c.translate(p.x,p.y);
 for(const strip of p.strips){
  const row=source.rows[strip.sourceRow],top=strip.y,bottom=strip.y+strip.h;
  for(let x=0;x<source.width;){let end=x+1;while(end<source.width&&row[end]===row[x])end++;
   const index=Number(row[x]);if(source.palette[index][3]){const left=Math.round(x*p.scale),right=Math.round(end*p.scale);c.fillStyle=colors[index];c.fillRect(left,top,right-left,bottom-top);}x=end;
  }
 }
 c.restore();c.fillStyle=fillStyle;return true;
}
