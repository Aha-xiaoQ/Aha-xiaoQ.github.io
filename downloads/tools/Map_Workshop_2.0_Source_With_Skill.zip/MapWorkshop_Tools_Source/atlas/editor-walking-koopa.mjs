/** Opt-in, deterministic Walking Koopa body/lifecycle helpers.
 * Host movement supplies gravity, collisions and confirmed contact faces.
 * Dimensions are an authored body contract, not recovered binary hitboxes.
 * Original observed transitions justify the phases; numeric tuning stays authored.
 * No global clocks, actor registries, reward ledger or course-specific behavior.
 */
const EPS=1e-7;
const STATUS='authored-not-calibrated';
const fields=['kind','color','size','walkSpeed','direction','flippedRecoveryFrames','shellRecoveryFrames','stompPoints','kickPoints','bumpPoints','sourceParameterStatus','avoidLedges'];
const fail=message=>{throw new TypeError(message);};
const object=q=>q!==null&&typeof q==='object'&&!Array.isArray(q);
const finite=(n,min,max)=>Number.isFinite(n)&&n>=min&&n<=max;
const tickValue=n=>Number.isSafeInteger(n)&&n>=0;
const scoreValue=n=>Number.isInteger(n)&&finite(n,0,100000);
const shape=q=>object(q)&&['x','y','w','h'].every(k=>Number.isFinite(q[k]))&&q.w>0&&q.h>0;
const body=q=>({x:q.x,y:q.y,w:q.w,h:q.h});
const forbidden=q=>!object(q)||q.dead||q.dying||q.defeated||q.removed||q.taken||q.hidden||q.visible===false||q.emptyShell||q.moduleEmergence||q.emerge||q.clawHeld||q.vehicleId||q.onVine||q.verticalFlight||q.flying||q.hoppingWings||q.moduleProjectile;
const unchanged=(actor,handled=false,extra={})=>({handled,changed:false,actor,points:0,events:[],...extra});

/** The portable form is validateWalkingKoopaVariant(rule). The editor may use
 * (room,id,rule) to also verify the existing native walker and authored bounds. */
export function validateWalkingKoopaVariant(roomOrRule,id,rule){
 const room=arguments.length===1?null:roomOrRule,q=arguments.length===1?roomOrRule:rule;
 if(!object(q)||Object.keys(q).some(k=>!fields.includes(k)))fail('Unknown Walking Koopa variant field');
 if(q.kind!=='walking-koopa'||!['red','green'].includes(q.color)||!['normal','giant'].includes(q.size)||![-1,1].includes(q.direction))fail('Walking Koopa needs explicit kind, color, size and direction');
 if(!finite(q.walkSpeed,Number.MIN_VALUE,8)||!['flippedRecoveryFrames','shellRecoveryFrames'].every(k=>Number.isInteger(q[k])&&finite(q[k],1,36000)))fail('Walking Koopa needs positive finite authored speed and recovery frames');
 if(!['stompPoints','kickPoints','bumpPoints'].every(k=>scoreValue(q[k])))fail('Walking Koopa needs explicit bounded integer contact points');
 if(q.sourceParameterStatus!==STATUS)fail('Walking Koopa parameters must be authored-not-calibrated');
 if(q.avoidLedges!==undefined&&typeof q.avoidLedges!=='boolean')fail('Walking Koopa ledge avoidance override must be a boolean');
 if(room){
  if(typeof id!=='string'||['__proto__','prototype','constructor'].includes(id))fail('Invalid Walking Koopa actor ID');
  const a=room.map?.objects?.find(v=>v.id===id&&v.kind==='walker'),d=walkingKoopaBody(q);
  if(!shape(a)||a.w!==d.walk.w||a.h!==d.walk.h)fail('Walking Koopa needs a matching authored native walker body');
  if(!Number.isFinite(room.map.width)||!Number.isFinite(room.map.height)||a.x<0||a.y<0||a.x+a.w>room.map.width||a.y+a.h>room.map.height)fail('Walking Koopa body outside room');
 }
 return true;
}

/** Feet and center anchor both native-scale and giant bodies. No wing stage.
 * Terrain uses a separate authored lower-body profile fitted to observed
 * passage traversal, not a claim that the original binary hitbox was recovered. */
export function walkingKoopaBody(rule){
 const scale=rule?.size==='giant'?2:1;
 if(!['normal','giant'].includes(rule?.size))fail('Unknown Walking Koopa body size');
 return {scale,walk:{w:16*scale,h:24*scale},shell:{w:16*scale,h:16*scale},terrain:{w:16*scale,h:16*scale,anchor:'bottom-center'},anchor:'bottom-center',bodyParameterStatus:STATUS};
}

function stateFor(actor){
 const s=actor?.smm2WalkingKoopa;
 if(forbidden(actor)||!shape(actor)||typeof actor.id!=='string'||!actor.id||!object(s)||s.version!==1||!['walking','shell','flipped-shell'].includes(s.phase))return null;
 try{validateWalkingKoopaVariant(s.variant);}catch{return null;}
 const d=walkingKoopaBody(s.variant),expected=s.phase==='walking'?d.walk:d.shell;
 if(actor.type!=='koopa'||actor.w!==expected.w||actor.h!==expected.h||actor.shell!==(s.phase!=='walking')||!Number.isSafeInteger(s.transitionSerial)||s.transitionSerial<0||!tickValue(s.lastStepTick)||!Number.isInteger(s.remainingFrames)||!finite(s.remainingFrames,0,36000)||![-1,1].includes(s.walkDirection))return null;
 return s;
}
function actorCopy(actor,state){return {...actor,source:{...actor.source},smm2WalkingKoopa:state};}
function terrainBody(actor,dimensions){return{x:actor.x+actor.w/2-dimensions.w/2,y:actor.y+actor.h-dimensions.h,w:dimensions.w,h:dimensions.h};}
/** Native-world adapter profile only. Player/enemy contacts still use the full
 * authored walking body; artwork stays independently anchored at the feet.
 * Emerging, unsupported or defeated actors return null for the host's fallback. */
export function walkingKoopaTerrainBody(actor){const s=stateFor(actor);return s?terrainBody(actor,walkingKoopaBody(s.variant).terrain):null;}
function requireTick(tick){if(!tickValue(tick))fail('Walking Koopa needs a nonnegative safe integer tick');}
function event(actor,s,name,tick,points,extra={}){
 return {event:name,actorId:actor.id,transitionId:'walking-koopa:'+actor.id+':'+s.transitionSerial,tick,points,color:s.variant.color,size:s.variant.size,sourceParameterStatus:STATUS,...extra};
}
function changed(actor,s,name,tick,points,extra={}){return {handled:true,changed:true,actor,points,events:[event(actor,s,name,tick,points,extra)]};}

/** Pure decoration: caller commits result.actor onto its live native actor.
 * Re-applying the same variant after restore never resets a living shell. */
export function applyWalkingKoopaVariant(actor,rule,{tick=0}={}){
 validateWalkingKoopaVariant(rule);requireTick(tick);
 if(forbidden(actor)||!shape(actor)||actor.kind!=='walker'||typeof actor.id!=='string'||!actor.id)return unchanged(actor);
 if(actor.smm2WalkingKoopa!==undefined){
  const s=stateFor(actor);
  if(!s||fields.some(k=>s.variant[k]!==rule[k]))fail('Walking Koopa variant cannot overwrite an existing lifecycle');
  return unchanged(actor,true);
 }
 const d=walkingKoopaBody(rule);
 if(actor.w!==d.walk.w||actor.h!==d.walk.h)fail('Walking Koopa decoration requires its authored walking body');
 const s={version:1,variant:{...rule},phase:'walking',remainingFrames:0,walkDirection:rule.direction,transitionSerial:0,lastStepTick:tick};
 const a=actorCopy(actor,s);
 Object.assign(a,{type:'koopa',smm2EnemyKind:'walking-koopa',vx:rule.direction*rule.walkSpeed,vy:Number.isFinite(actor.vy)?actor.vy:0,shell:false,shellAge:0,walkHeight:d.walk.h,frame:'',source:{...actor.source,red:rule.color==='red',smart:rule.avoidLedges??(rule.color==='red'),giant:rule.size==='giant',jumping:false}});
 return {handled:true,changed:true,actor:a,points:0,events:[]};
}

/** Contact ownership belongs to the caller. A topple is the observed below-
 * block impact, with an explicit upward speed. Repeated shell impacts are not
 * assigned an invented extra reward or restart cadence. */
export function transitionToKoopaShell(actor,{cause,tick,launchSpeed,horizontalSpeed}={}){
 if(!['topple','stomp'].includes(cause))fail('Unknown Walking Koopa shell transition');
 requireTick(tick);
 if(cause==='topple'&&!finite(launchSpeed,Number.MIN_VALUE,16))fail('Topple needs an explicit positive finite launch speed');
 if(horizontalSpeed!==undefined&&!finite(horizontalSpeed,-8,8))fail('Topple horizontal speed must be finite and within -8..8');
 const old=stateFor(actor);
 if(!old)return unchanged(actor);
 if(old.phase!=='walking'||tick<old.lastStepTick)return unchanged(actor,true);
 const horizontal=cause==='topple'?(horizontalSpeed??actor.vx):0;
 if(!Number.isFinite(horizontal))fail('Topple needs an actual finite horizontal velocity');
 const s={...old,variant:{...old.variant},phase:cause==='topple'?'flipped-shell':'shell',remainingFrames:cause==='topple'?old.variant.flippedRecoveryFrames:old.variant.shellRecoveryFrames,walkDirection:Math.sign(cause==='topple'?horizontal:actor.stackWalkVx||actor.vx)||old.walkDirection,transitionSerial:old.transitionSerial+1,lastStepTick:tick};
 const a=actorCopy(actor,s),d=walkingKoopaBody(s.variant),feet=actor.y+actor.h,center=actor.x+actor.w/2;
 Object.assign(a,{x:center-d.shell.w/2,y:feet-d.shell.h,w:d.shell.w,h:d.shell.h,shell:true,shellAge:0,vx:horizontal,hits:0,frame:s.phase==='flipped-shell'?'flipped':''});
 if(cause==='topple')Object.assign(a,{vy:-launchSpeed,grounded:false,support:null});
 return changed(a,s,'walking-koopa-shell',tick,cause==='topple'?s.variant.bumpPoints:s.variant.stompPoints,{cause,flipped:s.phase==='flipped-shell'});
}

/** One contact can kick an upright resting occupied shell. Host wall rebounds
 * retain velocity and do not call this reward-producing player contact helper. */
export function kickWalkingKoopa(actor,{direction,speed,tick,safeFrames=0}={}){
 requireTick(tick);
 if(![-1,1].includes(direction)||!finite(speed,Number.MIN_VALUE,16)||!Number.isInteger(safeFrames)||!finite(safeFrames,0,120))fail('Walking Koopa kick needs explicit direction, positive speed and bounded safety frames');
 const old=stateFor(actor);
 if(!old)return unchanged(actor);
 if(old.phase!=='shell'||!Number.isFinite(actor.vx)||Math.abs(actor.vx)>EPS||tick<old.lastStepTick)return unchanged(actor,true);
 const s={...old,variant:{...old.variant},remainingFrames:old.variant.shellRecoveryFrames,transitionSerial:old.transitionSerial+1,lastStepTick:tick};
 const a=actorCopy(actor,s);Object.assign(a,{vx:direction*speed,safe:safeFrames,shellAge:0,frame:''});
 return changed(a,s,'walking-koopa-kick',tick,s.variant.kickPoints,{direction,speed});
}

/** This preserves the legacy contact that stops a rolling shell. It awards no
 * points; the Stage owns any separately configured stomp-chain reward. */
export function stopWalkingKoopaShell(actor,{tick}={}){
 requireTick(tick);const old=stateFor(actor);
 if(!old)return unchanged(actor);
 if(old.phase!=='shell'||!Number.isFinite(actor.vx)||Math.abs(actor.vx)<=EPS||tick<old.lastStepTick)return unchanged(actor,true);
 const s={...old,variant:{...old.variant},remainingFrames:old.variant.shellRecoveryFrames,transitionSerial:old.transitionSerial+1,lastStepTick:tick};
 const a=actorCopy(actor,s);Object.assign(a,{vx:0,shellAge:0,frame:''});
 return changed(a,s,'walking-koopa-shell-stopped',tick,0);
}

/** Advances only authored recovery state. Real gravity/landing remain in the
 * host. Full-body clearance is required, once per new tick. Missing or blocked
 * clearance keeps an occupied living shell instead of growing through a roof. */
export function recoverWalkingKoopa(actor,{tick,canStand}={}){
 requireTick(tick);const old=stateFor(actor);
 if(!old)return unchanged(actor);
 if(old.phase==='walking'||tick<=old.lastStepTick)return unchanged(actor,true);
 const s={...old,variant:{...old.variant},lastStepTick:tick},a=actorCopy(actor,s);
 // Keep the last real horizontal direction through a host-owned wall rebound
 // or a stationary landing. A moving inverted shell still ages its timer.
 if(old.phase==='flipped-shell'&&Number.isFinite(actor.vx)&&Math.abs(actor.vx)>EPS)s.walkDirection=Math.sign(actor.vx);
 if(old.phase==='shell'&&Number.isFinite(actor.vx)&&Math.abs(actor.vx)>EPS){s.remainingFrames=s.variant.shellRecoveryFrames;a.shellAge=0;return {handled:true,changed:true,actor:a,points:0,events:[]};}
 s.remainingFrames=Math.max(0,old.remainingFrames-(tick-old.lastStepTick));
 a.shellAge=(old.phase==='shell'?s.variant.shellRecoveryFrames:s.variant.flippedRecoveryFrames)-s.remainingFrames;
 if(s.remainingFrames>0)return {handled:true,changed:true,actor:a,points:0,events:[]};
 const d=walkingKoopaBody(s.variant),candidate=Object.freeze({id:actor.id,x:actor.x+actor.w/2-d.walk.w/2,y:actor.y+actor.h-d.walk.h,w:d.walk.w,h:d.walk.h});
 if(typeof canStand!=='function'||canStand(candidate)!==true)return {handled:true,changed:true,actor:a,points:0,events:[],blocked:true};
 s.phase='walking';s.transitionSerial++;
 Object.assign(a,candidate,{shell:false,shellAge:0,vx:s.walkDirection*s.variant.walkSpeed,walkHeight:d.walk.h,hits:0,frame:''});
 return changed(a,s,'walking-koopa-recovered',tick,0);
}

/** Read-only renderer/contact descriptor, with explicit bottom-center drawing
 * and a center pivot for inverted art. It never mutates animation state. */
export function koopaView(actor){
 const s=stateFor(actor);if(!s)return null;
 const d=walkingKoopaBody(s.variant),shell=s.phase!=='walking',flipped=s.phase==='flipped-shell';
 return {actorId:actor.id,color:s.variant.color,size:s.variant.size,phase:s.phase,remainingFrames:s.remainingFrames,transitionSerial:s.transitionSerial,sourceParameterStatus:STATUS,body:body(actor),terrainBody:terrainBody(actor,d.terrain),walkingBody:{...d.walk},shellBody:{...d.shell},scale:d.scale,shell,flipped,winged:false,alive:true,movingShell:shell&&Math.abs(actor.vx||0)>EPS,edgeAvoidance:(s.variant.avoidLedges??(s.variant.color==='red'))&&!shell,render:{sprite:shell?'shell':'koopa',nativeW:16,nativeH:shell?16:24,w:actor.w,h:actor.h,x:actor.x,y:actor.y,anchor:'bottom-center',anchorX:actor.x+actor.w/2,anchorY:actor.y+actor.h,pivotX:actor.x+actor.w/2,pivotY:actor.y+actor.h/2,flipY:flipped}};
}

/** Swept horizontal contact from an actual previous pose. This is a request,
 * never a deletion: host removes that one collider, persists its tile ID, emits
 * debris, and keeps the shell's motion. Typed Ground/Brick/unknown Stone cannot
 * substitute for Hard Block. Explicit points are an authored style rule. */
export function hardBlockBreakEligibility(actor,solid,{before,tick,points}={}){
 requireTick(tick);if(!scoreValue(points))fail('Hard Block contact needs explicit bounded integer points');
 const no={eligible:false,points:0,events:[]},s=stateFor(actor);
 if(!s||s.variant.size!=='giant'||s.phase!=='shell'||!Number.isFinite(actor.vx)||Math.abs(actor.vx)<=EPS||!shape(before)||before.w!==actor.w||before.h!==actor.h||!shape(solid)||typeof solid.id!=='string'||!solid.id||solid.hidden||solid.removed||solid.visible===false||solid.collision!=='solid'||['ground','dirt','ground-fill'].includes(solid.material)||(solid.smm2BlockKind??solid.material)!=='hard-block')return no;
 const dx=actor.x-before.x;if(Math.abs(dx)<=EPS||Math.sign(dx)!==Math.sign(actor.vx))return no;
 const direction=Math.sign(dx),edge=direction>0?solid.x:solid.x+solid.w,start=direction>0?before.x+before.w:before.x;
 if(direction>0?start>edge+EPS:start<edge-EPS)return no;
 const fraction=(edge-start)/dx;if(fraction<-EPS||fraction>1+EPS)return no;
 const t=Math.max(0,Math.min(1,fraction)),y=before.y+(actor.y-before.y)*t,top=Math.max(y,solid.y),bottom=Math.min(y+actor.h,solid.y+solid.h);
 if(bottom-top<=EPS)return no;
 const contact={kind:'side',axis:'x',fraction:t,normal:{x:-direction,y:0},point:{x:edge,y:(top+bottom)/2}};
 const e=event(actor,s,'walking-koopa-hard-block',tick,points,{solidId:solid.id,contact});
 e.transitionId+=':hard-block:'+solid.id;
 return {eligible:true,solidId:solid.id,points,contact,events:[e]};
}
