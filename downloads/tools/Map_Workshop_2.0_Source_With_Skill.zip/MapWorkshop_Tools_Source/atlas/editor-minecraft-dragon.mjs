/** Three readable Ender Dragon phases, physical trident hits, parries and Mario stomps. */
const copy = value => JSON.parse(JSON.stringify(value));
const clamp = (v,lo,hi) => Math.max(lo,Math.min(hi,v));
const bounded = (v,lo,hi) => Number.isFinite(v)&&v>=lo&&v<=hi;
const unsafe = v => ['__proto__','constructor','prototype'].includes(v);
const solid = q => q.collision==='solid'&&!q.hidden;
const horizontal = (a,b) => a.x+a.w>b.x&&a.x<b.x+b.w;
const overlaps = (a,b) => horizontal(a,b)&&a.y+a.h>b.y&&a.y<b.y+b.h;
const safeId = v => typeof v==='string'&&v.length>0&&v.length<=100&&!unsafe(v);
function record(value,keys,name) {
 if(!value||typeof value!=='object'||Array.isArray(value)||![Object.prototype,null].includes(Object.getPrototypeOf(value)))throw Error('Invalid Minecraft dragon '+name);
 for(const key of Object.keys(value))if(unsafe(key)||!keys.includes(key))throw Error('Unknown Minecraft dragon '+name+' field: '+key);
}
export const DRAGON_TIMING=Object.freeze({firstCircle:180,flight:150,phaseIntro:30,strafeWarning:42,strafe:174,chargeWarning:42,charge:76,deflected:96,deflectRise:12,parryRecoil:24,breathWarning:42,breath:100,landing:42,perch:160,hurt:36,protection:66,heal:120,hitRecovery:120,defeat:84,dissolve:24,portal:66});
// Minecraft fireballs leave lingering area clouds. The 5-second duration,
// footprint budget and 1.1-second damage cadence are our short 60 Hz 2D adaptation,
// not the Bedrock sample's 120-second cloud or its 20-game-tick reapplication.
export const DRAGON_BREATH=Object.freeze({life:300,warning:24,width:52,height:10,damageInterval:66,maxClouds:4,maxCoverage:.34});
/** Exact swept AABB contact. Terrain wins ties, so neither a player nor a
 * reflected head can be hit through a nearer wall or a thin platform. */
export function dragonProjectileImpact(before,after,geometry=[],actor=null){
 const dx=after.x-before.x,dy=after.y-before.y;
 const sweep=target=>{
  if(overlaps(before,target))return {time:0,normal:{x:0,y:0}};
  const axis=(pos,size,d,lo,hi)=>d===0?(pos+size<=lo||pos>=hi?null:{enter:-Infinity,exit:Infinity}):d>0?{enter:(lo-pos-size)/d,exit:(hi-pos)/d}:{enter:(hi-pos)/d,exit:(lo-pos-size)/d};
  const x=axis(before.x,before.w,dx,target.x,target.x+target.w),y=axis(before.y,before.h,dy,target.y,target.y+target.h);if(!x||!y)return null;
  const enter=Math.max(x.enter,y.enter),exit=Math.min(x.exit,y.exit);if(enter<0||enter>1||enter>exit||exit<0)return null;
  return {time:enter,normal:x.enter>y.enter?{x:-Math.sign(dx),y:0}:{x:0,y:-Math.sign(dy)}};
 };
 let nearest=null;
 for(const target of geometry.filter(solid)){const hit=sweep(target);if(hit&&(!nearest||hit.time<nearest.time))nearest={...hit,target,contact:'terrain'};}
 if(actor){const hit=sweep(actor);if(hit&&(!nearest||hit.time<nearest.time-1e-8))nearest={...hit,target:actor,contact:'actor'};}
 return nearest?{...nearest,x:before.x+dx*nearest.time,y:before.y+dy*nearest.time}:null;
}
/** Downward support ray from the actual contact. Side/ceiling hits never jump
 * to an occluder's top; the whole footprint is clipped to one exposed surface. */
export function dragonBreathFootprint(point,geometry,arena,excludedIds=[]){
 if(point.x<arena.x||point.x>=arena.x+arena.w)return null;
 const terrain=geometry.filter(g=>solid(g)&&!excludedIds.includes(g.id)&&!excludedIds.includes(g.sourceId)&&!g.mcDragonCrystal&&!g.mcDragonEgg);
 const support=terrain.filter(g=>g.x<=point.x&&g.x+g.w>point.x&&g.y>=point.y-.001).sort((a,b)=>a.y-b.y)[0];if(!support)return null;
 let spans=[[Math.max(arena.x,support.x),Math.min(arena.x+arena.w,support.x+support.w)]];
 for(const g of terrain){if(g===support||g.y>=support.y||g.y+g.h<=support.y-DRAGON_BREATH.height)continue;spans=spans.flatMap(([l,r])=>g.x>=r||g.x+g.w<=l?[[l,r]]:[[l,Math.max(l,g.x)],[Math.min(r,g.x+g.w),r]].filter(([x,z])=>z>x));}
 const span=spans.find(([l,r])=>point.x>=l&&point.x<r);if(!span||span[1]-span[0]<4)return null;
 const w=Math.min(DRAGON_BREATH.width,span[1]-span[0]);return {x:clamp(point.x-w/2,span[0],span[1]-w),y:support.y-DRAGON_BREATH.height,w,h:DRAGON_BREATH.height,supportId:support.id,supportY:support.y};
}
export const DRAGON_MIN_BOW_CHARGE=18; // Import compatibility only; bows do not damage this encounter.
export const DRAGON_RANGED_TIMING=Object.freeze({warning:0,open:150});
export const DRAGON_PHASES=Object.freeze([
 Object.freeze({phase:1,name:'WINGS OF THE END',minHp:9,maxHp:12,pattern:'aimed-strafe',shotEvery:50,shotSpeed:2.7,spread:0,chargePasses:1}),
 Object.freeze({phase:2,name:'PURPLE CROSSFIRE',minHp:5,maxHp:8,pattern:'crossfire-fans',shotEvery:58,shotSpeed:3.1,spread:.25,chargePasses:1}),
 Object.freeze({phase:3,name:'ENDER TEMPEST',minHp:1,maxHp:4,pattern:'double-swoop-tempest',shotEvery:52,shotSpeed:3.5,spread:.38,chargePasses:2})
]);
export function validateDragon(spec,room) {
 if(spec===undefined)return;
 record(spec,['version','id','arena','groundY','activationX','crystalIds','exitPortalId','landingX'],'encounter');
 const map=room?.map;
 if(spec.version!==1||!safeId(spec.id)||!map||!Array.isArray(map.geometry)||!Array.isArray(map.objects))throw Error('Invalid Minecraft dragon encounter');
 record(spec.arena,['x','y','w','h'],'arena');const a=spec.arena;
 if(!bounded(a.x,0,map.width)||!bounded(a.y,0,map.height)||!bounded(a.w,384,map.width-a.x)||!bounded(a.h,192,map.height-a.y)||!bounded(spec.groundY,a.y+160,a.y+a.h)||!bounded(spec.activationX,a.x,a.x+a.w-96)||!bounded(spec.landingX,a.x+96,a.x+a.w-96))throw Error('Invalid Minecraft dragon arena bounds');
 // A real grounded fountain platform is necessary: the head is too high to hit from the floor.
 const perchY=spec.groundY-48,plinth=map.geometry.find(q=>solid(q)&&q.x<=spec.landingX+26&&q.x+q.w>=spec.landingX+36&&Math.abs(q.y-perchY)<.001);
 if(!plinth)throw Error('Minecraft dragon perch needs a central fountain plinth 48 pixels above ground');
 if(!map.geometry.some(q=>solid(q)&&q.x<=plinth.x&&q.x+q.w>=plinth.x+plinth.w&&Math.abs(q.y-spec.groundY)<.001))throw Error('Minecraft dragon fountain needs supported ground');
 if(!map.geometry.some(q=>solid(q)&&q!==plinth&&horizontal(q,{x:plinth.x-48,w:plinth.w+96})&&bounded(q.y-perchY,12,32)))throw Error('Minecraft dragon fountain needs a reachable step');
 const headLane={x:spec.landingX,y:spec.groundY-124,w:40,h:76};
 if(map.geometry.some(q=>solid(q)&&overlaps(q,headLane)))throw Error('Minecraft dragon needs unobstructed space above its fountain');
 if(!Array.isArray(spec.crystalIds)||spec.crystalIds.length!==3||new Set(spec.crystalIds).size!==3)throw Error('Minecraft dragon needs exactly three unique crystals');
 for(const id of spec.crystalIds){const q=map.geometry.find(q=>q.id===id);if(!safeId(id)||!q||!solid(q)||q.motion||q.liftSpeed||!bounded(q.w,16,32)||!bounded(q.h,16,32)||!bounded(q.x,a.x,a.x+a.w-q.w)||!bounded(q.y,a.y+64,spec.groundY-q.h-16)||(room.minecraft?.sandIds||[]).includes(id)||(room.minecraft?.destructibleIds||[]).includes(id))throw Error('Minecraft dragon crystal needs a unique static solid');if(!map.geometry.some(g=>g.id!==id&&solid(g)&&horizontal(g,q)&&bounded(g.y-q.y-q.h,24,64)))throw Error('Minecraft dragon crystal needs a reachable pillar');}
 if(!safeId(spec.exitPortalId)||!map.objects.some(q=>q.id===spec.exitPortalId&&(q.kind==='portal'||q.kind==='exit')))throw Error('Minecraft dragon needs a real exit portal');
 if([...map.geometry,...map.objects,...(room.markers||[])].some(q=>q.id===spec.id))throw Error('Duplicate Minecraft dragon ID');
}

/** Runs before the unchanged Mario motor. Throws and reflected fireballs must
 * physically reach the flying head; melee or a swept falling stomp hits a perch. */
export function createDragonController(room,{emit=()=>{},hurtPlayer=()=>{},rewardCoins=()=>{},defend=()=>null}={}) {
 const authored=room?.minecraft?.dragon;if(!authored)return null;validateDragon(authored,room);
 const spec=copy(authored),a=spec.arena,ids=new Set(spec.crystalIds),sources=spec.crystalIds.map(id=>copy(room.map.geometry.find(q=>q.id===id))),maxHp=12;
 const perchY=spec.groundY-48,headY=spec.groundY-96;
 let state,stateAge,age,hp,phase,phaseAge,crystals,head,body,facing,telegraph,projectiles,pools,effects,previousPlayer,lastTick,currentTick,paused,disposed,cycle,damageCooldown,hitRecovery,shotSerial,landingFrom,breathTarget,chargePass,chargeY,healAge,hitCount,flightTilt,perchHit,headVelocity,egg,deflectedFrom,deflectedTarget,deflectedHit,currentGeometry,meleeSwings;
 // Both egg positions are resolved once against real static fountain solids.
 const eggSpot=x=>{for(const g of room.map.geometry.filter(g=>solid(g)&&!ids.has(g.id)&&g.y>=perchY&&g.y<=spec.groundY&&g.x<=x&&g.x+g.w>=x+16).sort((a,b)=>a.y-b.y)){const spot={x,y:g.y-20,w:16,h:20,supportId:g.id};if(!room.map.geometry.some(q=>solid(q)&&!ids.has(q.id)&&overlaps(q,spot))&&!room.map.objects.some(q=>q.kind==='hazard'&&overlaps(q,spot)))return spot;}return null;};
 const eggId=spec.id+'-egg',eggHome=[...room.map.geometry,...room.map.objects,...(room.markers||[])].some(q=>q.id===eggId)?null:eggSpot(spec.landingX+24),eggDestination=eggSpot(spec.landingX+72)||eggSpot(spec.landingX-32),eggEnabled=!!eggHome&&!!eggDestination;
 const event=(name,data={})=>emit('minecraft',{event:name,roomId:room.roomId,actorId:spec.id,tick:currentTick,phase,...data});const sound=name=>emit('sound',{event:name});
 const healing=()=>crystals.some(q=>q.active),phaseForHp=()=>hp>8?1:hp>4?2:3,config=()=>DRAGON_PHASES[phase-1];
 function pose(x,y,direction=facing,tilt=0){headVelocity=head?{x:x-head.x,y:y-head.y}:{x:0,y:0};facing=direction;head={x,y,w:40,h:24};body={x:facing>0?x-78:x+22,y:y-20,w:88,h:48};flightTilt=tilt;}
 function reset(){state='dormant';stateAge=age=phaseAge=0;hp=maxHp;phase=1;crystals=sources.map(q=>({...q,active:true}));facing=-1;head=null;pose(a.x+a.w-96,a.y+88);telegraph=null;projectiles=[];pools=[];effects=[];previousPlayer=null;lastTick=-1;currentTick=0;paused=disposed=false;cycle=damageCooldown=hitRecovery=shotSerial=chargePass=healAge=hitCount=0;landingFrom=breathTarget=null;perchHit=false;chargeY=spec.groundY-28;egg=null;deflectedFrom=deflectedTarget=null;deflectedHit=false;currentGeometry=room.map.geometry;meleeSwings=new Set();}
 reset();
 function geometryFor(geometry){const active=new Set(crystals.filter(q=>q.active).map(q=>q.id));return [...geometry.filter(q=>!ids.has(q.id)&&!ids.has(q.sourceId)&&(!eggEnabled||q.id!==eggId&&q.sourceId!==eggId)),...sources.filter(q=>active.has(q.id)).map(q=>({...copy(q),mcDragonCrystal:true,dx:0,dy:0})),...(egg?.active?[{id:eggId,x:egg.x,y:egg.y,w:egg.w,h:egg.h,collision:'solid',material:'stone',mcDragonEgg:true,dx:0,dy:0}]:[])];}
 function burst(kind,x,y,color,count=12){for(let n=0;n<count;n++)effects.push({kind,x,y,w:3+n%2,h:3+n%2,vx:Math.cos(n*Math.PI*2/count)*(1+n%3*.3),vy:Math.sin(n*Math.PI*2/count)*1.8-1,age:0,life:30,color});}
 function warn(kind,ticks,rectangle,extra={}){telegraph={kind,...rectangle,ticks,safeLanes:[],...extra};sound('mc-dragon-warn');event('dragon-'+kind+'-warning',{ticks,...extra});}
 function begin(next,player,geometry=[]){state=next;stateAge=0;telegraph=null;
  if(next==='phase-intro'){projectiles=[];event('dragon-phase-start',{hp,name:config().name,pattern:config().pattern});sound('mc-dragon-warn');}
  else if(next==='flight'){chargePass=0;perchHit=false;event('dragon-ranged-open',{ticks:DRAGON_TIMING.flight,head:copy(head)});}
  else if(next==='telegraph-strafe'){facing=cycle%2?-1:1;pose(facing>0?a.x+30:a.x+a.w-72,a.y+94,facing);warn('strafe',DRAGON_TIMING.strafeWarning,{x:a.x,y:a.y+112,w:a.w,h:spec.groundY-a.y-112},{pattern:config().pattern});}
  else if(next==='strafe'){sound('mc-dragon-breath');event('dragon-strafe-start',{pattern:config().pattern});}
  else if(next==='telegraph-charge'){chargeY=phase===2||(phase===3&&chargePass===1)?spec.groundY-66:spec.groundY-28;facing=chargePass%2?-1:1;pose(facing>0?a.x-80:a.x+a.w+40,chargeY,facing);warn('charge',DRAGON_TIMING.chargeWarning,{x:a.x,y:chargeY-20,w:a.w,h:48},{direction:facing,altitude:chargeY<spec.groundY-40?'high':'low',pass:chargePass+1});}
  else if(next==='charge'){sound('mc-dragon-swoop');event('dragon-charge-start',{altitude:chargeY<spec.groundY-40?'high':'low',pass:chargePass+1});}
  else if(next==='deflected'){
   deflectedFrom={...head};deflectedHit=false;const cx=player.x+player.w/2,feet=player.y+player.h,candidates=[];
   for(const x of [cx,cx-32,cx+32,cx-64,cx+64]){const support=dragonBreathFootprint({x,y:feet-16},geometry,a,spec.crystalIds);if(!support||support.w<40||support.supportY-feet>96)continue;const target={x:clamp(cx-20,support.x,support.x+support.w-40),y:support.supportY-56,w:40,h:24,supportId:support.supportId};if(!geometry.some(g=>solid(g)&&overlaps(g,target)))candidates.push(target);}
   deflectedTarget=candidates.sort((u,v)=>Math.abs(u.x+20-cx)+Math.abs(u.y+56-feet)-Math.abs(v.x+20-cx)-Math.abs(v.y+56-feet))[0]||{x:spec.landingX,y:headY,w:40,h:24,supportId:null};
   telegraph={kind:'deflected',...deflectedTarget,ticks:DRAGON_TIMING.deflected,safeLanes:[],opening:true};burst('dragon-deflected',head.x+20,head.y+12,'#c7f5ff',14);sound('mc-dragon-hit');event('dragon-charge-deflected',{ticks:DRAGON_TIMING.deflected,head:copy(deflectedTarget),supportId:deflectedTarget.supportId,pass:chargePass+1});
  }
  else if(next==='parry-recoil'){landingFrom={...head};event('dragon-parry-stomp-recoil',{ticks:DRAGON_TIMING.parryRecoil});}
  else if(next==='telegraph-breath'){pose(a.x+a.w-126,a.y+94,-1);breathTarget={x:clamp(player?player.x+player.w/2:spec.landingX,a.x+30,a.x+a.w-30),y:player?Math.min(spec.groundY,player.y+player.h):spec.groundY};warn('breath',DRAGON_TIMING.breathWarning,{x:breathTarget.x-34,y:breathTarget.y-14,w:68,h:14},{target:copy(breathTarget),unblockable:true,pattern:phase===1?'targeted-cloud':phase===2?'double-cloud':'triple-cloud'});}
  else if(next==='breath'){sound('mc-dragon-breath');event('dragon-breath-start',{target:copy(breathTarget),unblockable:true});}
  else if(next==='landing'){landingFrom={...head};event('dragon-landing',{landingX:spec.landingX,perchY,healingActive:healing()});}
  else if(next==='perch'){pose(spec.landingX,headY,-1);projectiles=[];perchHit=false;event('dragon-vulnerable',{healingActive:healing(),ticks:DRAGON_TIMING.perch,head:copy(head),perchY});}
  else if(next==='defeated'){projectiles=[];pools=[];headVelocity={x:0,y:0};sound('mc-dragon-defeat');event('dragon-defeated',{hits:hitCount,exitPortalId:spec.exitPortalId});effects.push({kind:'dragon-death-ring',x:body.x+body.w/2,y:body.y+body.h/2,age:0,life:36,duration:36,stationary:true,color:'#edbeff'});rewardCoins(12);}
 }
 function advanceDefeat(p){
  if(stateAge===DRAGON_TIMING.dissolve){sound('mc-dragon-dissolve');event('dragon-dissolving',{ticks:DRAGON_TIMING.defeat-DRAGON_TIMING.dissolve});}
  if(stateAge===DRAGON_TIMING.portal){const exit=room.map.objects.find(q=>q.id===spec.exitPortalId);effects.push({kind:'end-portal-bloom',x:exit.x+exit.w/2,y:exit.y+exit.h-16,age:0,life:36,duration:36,stationary:true,color:'#d4ffe5'});sound('mc-end-portal-open');event('dragon-portal-energized',{exitPortalId:spec.exitPortalId});}
  if(stateAge===DRAGON_TIMING.defeat)event('dragon-death-complete',{exitPortalId:spec.exitPortalId});
  // A new or relocated solid must never materialize inside Mario. Appearance
  // stays pending while he occupies the plinth; touching queues one teleport.
  const playerClear=spot=>!p||!overlaps(p,spot);
  if(stateAge>=DRAGON_TIMING.defeat&&!egg&&eggEnabled&&playerClear(eggHome)){egg={...eggHome,id:eggId,active:true,teleported:false,teleportPending:false,age:0};event('dragon-egg-appeared',{x:egg.x,y:egg.y,supportId:egg.supportId});}
  if(egg){egg.age++;if(egg.age>1&&!egg.teleported&&p&&!p.dead&&!p.dying&&(p.headHit===eggId||p.support===eggId||overlaps({...p,x:p.x-.1,y:p.y-.1,w:p.w+.2,h:p.h+.2},egg)))egg.teleportPending=true;
   if(egg.teleportPending&&playerClear(eggDestination)){const from={x:egg.x+8,y:egg.y+10};if(p?.headHit===eggId)p.headHit=null;if(p?.support===eggId){p.support=null;p.grounded=false;}egg={...egg,...eggDestination,teleported:true,teleportPending:false,age:0};effects.push({kind:'dragon-egg-trail',x:from.x,y:from.y,targetX:egg.x+8,targetY:egg.y+10,age:0,life:42,duration:42,stationary:true});sound('mc-crystal-energy');event('dragon-egg-teleported',{from,x:egg.x,y:egg.y,supportId:egg.supportId});}}
 }
 function bounce(p){p.y=Math.min(p.y,head.y-p.h);p.vy=-4.6;p.grounded=false;p.support=null;p.jumpBuffer=0;p.jumpG=.125;p.fallG=.4375;}
 function sweptStomp(p,previous,target){if(!p||!previous||p.dead||p.dying||p.y+p.h<=previous.y+previous.h+.001)return false;const old=previous.y+previous.h,bottom=p.y+p.h;if(old>target.y+1||bottom<target.y-.001||bottom-old>16||Math.abs(p.x-previous.x)>12)return false;const t=clamp((target.y-old)/(bottom-old),0,1);return horizontal({x:previous.x+(p.x-previous.x)*t,w:p.w},target);}
 function breakCrystal(q,contact,p){if(!q.active||state==='defeated')return;q.active=false;const x=q.x+q.w/2,y=q.y+q.h/2;burst('crystal-shard',x,y,'#eb8dff',16);effects.push({kind:'crystal-collapse',x,y,targetX:body.x+body.w/2,targetY:body.y+body.h/2,age:0,life:54,duration:54,stationary:true,contact});sound('mc-crystal-break');sound('mc-crystal-energy');event('dragon-crystal-broken',{crystalId:q.id,contact,remaining:crystals.filter(c=>c.active).length});if(!healing()){effects.push({kind:'dragon-shield-collapse',x:body.x+body.w/2,y:body.y+body.h/2,age:0,life:42,duration:42,stationary:true,color:'#f0b8ff'});event('dragon-healing-ended');event('dragon-shield-broken');begin('phase-intro',p);}}
 function breakCrystals(p){if(!p||p.dead||p.dying)return;for(const q of crystals){if(!q.active)continue;const bonk=p.headHit===q.id,stomp=sweptStomp(p,previousPlayer,q)||(p.support===q.id&&previousPlayer&&previousPlayer.y+previousPlayer.h<q.y-.01&&p.y+p.h>=q.y-.001);if(!bonk&&!stomp)continue;breakCrystal(q,bonk?'bonk':'stomp',p);if(stomp){p.vy=-3.8;p.grounded=false;p.support=null;}if(bonk)p.headHit=null;}}
 const airborne=()=>!['dormant','defeated','perch','hurt','phase-intro'].includes(state),rangedOpen=()=>airborne()&&!healing()&&!hitRecovery;
 function rangedTargets(){return [...crystals.filter(q=>q.active).map(q=>({...copy(q),kind:'end-crystal',aimable:true})),...(state!=='dormant'&&state!=='defeated'?[{id:spec.id+'-head',kind:'dragon-head',...copy(head),vx:headVelocity.x,vy:headVelocity.y,aimable:airborne()&&!healing()}]:[])];}
 function applyHit(kind,p,amount=1){if(state==='defeated')return;hp=Math.max(healing()?1:0,hp-amount);hitCount++;hitRecovery=DRAGON_TIMING.hitRecovery;burst('dragon-hit',head.x+20,head.y,'#fff0b9');sound('mc-dragon-hit');event(kind==='stomp'?'dragon-stomp':kind==='parry-return'?'dragon-parry-hit':kind==='sword'?'dragon-melee-hit':'dragon-ranged-hit',{kind,hp,damage:amount,cycle,...(kind==='stomp'?{opening:state==='deflected'?'charge-parry':'perch'}:{}),head:copy(head)});if(hp===0)begin('defeated',p);else{const next=phaseForHp();if(next!==phase){phase=next;phaseAge=0;event('dragon-phase-changed',{hp,name:config().name,pattern:config().pattern});}}}
 function receiveRangedHit(q){if(paused||disposed||state==='defeated'||!q||!['loyalty-trident','parry-return'].includes(q.kind)||![q.x,q.y,q.w,q.h,q.vx,q.vy].every(Number.isFinite)||q.w<=0||q.h<=0||q.w>24||q.h>16)return false;const target=crystals.find(c=>c.id===q.targetId&&c.active)||(q.targetId===spec.id+'-head'&&state!=='defeated'?head:null);if(!target)return false;const contact={...q,x:q.x-.01,y:q.y-.01,w:q.w+.02,h:q.h+.02};if(!overlaps(contact,target))return false;if(target!==head){breakCrystal(target,q.kind,q.player);return true;}if(!(q.kind==='parry-return'?airborne()&&!healing():rangedOpen())){event('dragon-projectile-rejected',{kind:q.kind,state,reason:state==='perch'?'perched-projectile-immunity':healing()?'crystal-healing':hitRecovery?'hit-recovery':'grounded-immunity'});burst('dragon-glance',q.x+q.w/2,q.y+q.h/2,'#c7a1df',5);return true;}applyHit(q.kind,q.player);return true;}
 // Sword contact is deliberately separate from projectile immunity. Gear owns
 // the active blade frames; this boundary independently rejects remote/wall hits.
 function meleeTargets(){return rangedTargets().map(q=>({...q,aimable:false}));}
 function receiveMeleeHit(q){
  const p=q?.player;if(paused||disposed||state==='defeated'||!q||q.kind!=='sword'||!p||p.dead||p.dying||![q.x,q.y,q.w,q.h,p.x,p.y,p.w,p.h].every(Number.isFinite)||q.w<=0||q.h<=0||q.w>34||q.h>32||![-1,1].includes(q.facing)||!(typeof q.swingId==='string'||Number.isInteger(q.swingId)))return false;
  const target=crystals.find(c=>c.id===q.targetId&&c.active)||(q.targetId===spec.id+'-head'?head:null),key=q.swingId+':'+q.targetId;
  if(!target||meleeSwings.has(key)||!overlaps(q,target)||q.y<p.y-8||q.y+q.h>p.y+p.h+8||q.facing>0&&(q.x<p.x+p.w-4||q.x+q.w>p.x+p.w+32)||q.facing<0&&(q.x<p.x-32||q.x+q.w>p.x+4))return false;
  const from={x:p.x+p.w/2,y:p.y+p.h/2,w:1,h:1},to={...from,x:Math.max(target.x,Math.min(target.x+target.w,q.x+q.w/2)),y:Math.max(target.y,Math.min(target.y+target.h,q.y+q.h/2))};
  if(dragonProjectileImpact(from,to,currentGeometry.filter(g=>g.id!==q.targetId&&g.sourceId!==q.targetId)))return false;
  meleeSwings.add(key);if(meleeSwings.size>64)meleeSwings.delete(meleeSwings.values().next().value);
  if(target!==head){breakCrystal(target,'sword',p);return true;}
  if(healing()||hitRecovery||['dormant','phase-intro','hurt'].includes(state)){event('dragon-melee-rejected',{kind:'sword',state,reason:healing()?'crystal-healing':hitRecovery?'hit-recovery':'inactive-head'});return true;}
  applyHit('sword',p,.5);return true;
 }
 function damage(p,kind,id,sourceX,reflectable=false){if(state==='defeated'||damageCooldown||!p||p.dead||p.dying)return {damage:0,parried:false,blocked:false,reflect:false,reason:'protection'};const areaBreath=kind==='dragon-breath-cloud',decision=areaBreath?{damage:1,parried:false,blocked:false,reflect:false}:defend({player:p,sourceX,kind,damage:1,reflectable})||{damage:1,parried:false,blocked:false,reflect:false};if(decision.damage>0){damageCooldown=areaBreath?DRAGON_BREATH.damageInterval:DRAGON_TIMING.protection;hurtPlayer({kind,actorId:id||spec.id,sourceX,damage:decision.damage,guarded:true});event('dragon-player-hit',{kind,damage:decision.damage,blocked:!!decision.blocked});}return decision;}
 function sweptOverlap(now,before,target){if(overlaps(now,target)||overlaps(before,target))return true;const dx=now.x-before.x,dy=now.y-before.y,steps=Math.max(1,Math.ceil(Math.max(Math.abs(dx),Math.abs(dy))/3));for(let n=1;n<steps;n++)if(overlaps({...now,x:before.x+dx*n/steps,y:before.y+dy*n/steps},target))return true;return false;}
 function projectile(kind,x,y,vx,vy,extra={}){projectiles.push({id:spec.id+'-shot-'+(++shotSerial),kind,x,y,w:12,h:12,vx,vy,age:0,life:240,...extra});}
 function spawnStrafe(p){const c=config(),x=head.x+14,y=head.y+18,tx=p?p.x+p.w/2:spec.landingX,ty=p?p.y+p.h*.5:spec.groundY-18,angle=Math.atan2(ty-y,tx-x),offsets=phase===1?[0]:phase===2?[-c.spread,c.spread]:[-c.spread,0,c.spread];for(const offset of offsets)projectile('dragon-fireball',x,y,Math.cos(angle+offset)*c.shotSpeed,Math.sin(angle+offset)*c.shotSpeed,{pattern:c.pattern,reflectable:true});event('dragon-volley',{count:offsets.length,pattern:c.pattern});}
 function spawnBreath(index){const offset=phase===1?0:phase===2?[-22,22][index%2]:[-38,0,38][index%3],tx=breathTarget.x+offset,x=head.x+4,y=head.y+14,dx=tx-x,dy=breathTarget.y-y,length=Math.hypot(dx,dy)||1,speed=4.1;projectile('dragon-breath',x,y,dx/length*speed,dy/length*speed,{cloud:true,targetX:tx,reflectable:false});}
 function cloud(q,impact,geometry){
  const point={x:impact.x+q.w/2,y:impact.y+q.h/2};
  if(impact.contact==='terrain'&&impact.normal.y<0){point.x=clamp(point.x,impact.target.x+.001,impact.target.x+impact.target.w-.001);point.y=impact.target.y;}
  const footprint=dragonBreathFootprint(point,geometry,a,spec.crystalIds);burst('dragon-breath-puff',point.x,point.y,'#af51d9',7);if(!footprint)return;
  // Coalesce overlapping impacts without extending the original lifetime. A
  // packed arena absorbs further deposits instead of endlessly refreshing it.
  const existing=pools.find(p=>p.supportId===footprint.supportId&&point.x>=p.x&&point.x<p.x+p.w);
  if(existing){event('dragon-cloud-merged',{cloudId:existing.id,projectileId:q.id,life:existing.life});return;}
  if(pools.length>=DRAGON_BREATH.maxClouds||pools.reduce((n,p)=>n+p.w,0)+footprint.w>a.w*DRAGON_BREATH.maxCoverage){event('dragon-cloud-dispersed',{projectileId:q.id,reason:'footprint-budget'});return;}
  const pool={id:q.id+'-cloud',kind:'dragon-breath-cloud',...footprint,age:0,life:DRAGON_BREATH.life,duration:DRAGON_BREATH.life,warning:DRAGON_BREATH.warning,damageInterval:DRAGON_BREATH.damageInterval,unblockable:true};pools.push(pool);
  event('dragon-cloud-created',{cloudId:pool.id,projectileId:q.id,sourceKind:q.kind,contact:impact.contact,supportId:pool.supportId,x:pool.x,y:pool.y,w:pool.w,h:pool.h,life:pool.life,warning:pool.warning});
 }
 function reflect(q,p){const dx=head.x+head.w/2-(q.x+q.w/2),dy=head.y+head.h/2-(q.y+q.h/2),length=Math.hypot(dx,dy)||1;q.vx=dx/length*8;q.vy=dy/length*8;q.kind='parry-return';q.reflected=true;q.life=130;q.age=0;q.player=p;q.cloud=false;event('dragon-projectile-reflected',{projectileId:q.id,targetId:spec.id+'-head'});}
 function stepProjectiles(p,geometry){if(state==='defeated')return;
  for(const q of projectiles){if(state==='defeated')break;const old={...q};if(q.reflected){const dx=head.x+20-q.x-q.w/2,dy=head.y+12-q.y-q.h/2,len=Math.hypot(dx,dy)||1;q.vx=dx/len*13;q.vy=dy/len*13;}q.x+=q.vx;q.y+=q.vy;q.age++;q.life--;if(q.life<=0)continue;
   const actor=q.reflected?head:p&&!p.dead&&!p.dying?p:null,impact=dragonProjectileImpact(old,q,geometry,actor);
   if(impact){q.x=impact.x;q.y=impact.y;
    event('dragon-projectile-impact',{projectileId:q.id,kind:q.kind,contact:impact.contact==='actor'?(q.reflected?'head':'player'):'terrain',targetId:impact.target.id||null,x:q.x+q.w/2,y:q.y+q.h/2});
    if(impact.contact==='actor'&&q.reflected){receiveRangedHit({...q,x:clamp(q.x,head.x-q.w+.001,head.x+head.w-.001),y:clamp(q.y,head.y-q.h+.001,head.y+head.h-.001),targetId:spec.id+'-head'});q.life=0;continue;}
    if(impact.contact==='actor'){const decision=damage(p,q.kind,q.id,old.x+q.w/2,!!q.reflectable);if(decision.reflect){reflect(q,p);continue;}}
    q.life=0;if(!q.reflected)cloud(q,impact,geometry);else burst('dragon-breath-puff',q.x+6,q.y+6,'#af51d9',4);
   }else if(q.x<a.x-64||q.x>a.x+a.w+64||q.y<a.y-96||q.y>spec.groundY+16)q.life=0;
  }
  projectiles=projectiles.filter(q=>q.life>0);
  for(const q of pools){q.age++;q.life--;q.warning=Math.max(0,q.warning-1);
   const support=geometry.find(g=>g.id===q.supportId&&solid(g)&&Math.abs(g.y-q.supportY)<.001&&g.x<=q.x&&g.x+g.w>=q.x+q.w);
   if(!support||geometry.some(g=>solid(g)&&g!==support&&overlaps(q,g))){q.life=0;continue;}
   if(q.life>0&&!q.warning&&p&&overlaps(q,p))damage(p,'dragon-breath-cloud',q.id,q.x+q.w/2);
  }pools=pools.filter(q=>q.life>0);
 }
 function advance(p,geometry){stateAge++;age++;phaseAge++;if(damageCooldown)damageCooldown--;if(hitRecovery)hitRecovery--;for(const q of effects){q.age++;q.life--;if(!q.stationary){q.x+=q.vx||0;q.y+=q.vy||0;q.vy=(q.vy||0)+.055;}}effects=effects.filter(q=>q.life>0);breakCrystals(p);
  if(healing()&&hp<maxHp&&state!=='defeated'){if(++healAge>=DRAGON_TIMING.heal){healAge=0;hp++;phase=phaseForHp();event('dragon-healed',{hp,crystals:crystals.filter(q=>q.active).length});}}else healAge=0;
  if(state==='dormant'){if(p&&p.x+p.w>=spec.activationX){begin('flight',p);event('dragon-awakened');}return;}if(state==='defeated'){advanceDefeat(p);return;}
  if(state==='phase-intro'){pose(a.x+a.w*.65,a.y+98,-1);if(stateAge>=DRAGON_TIMING.phaseIntro)begin('flight',p);}
  else if(state==='flight'){pose(a.x+a.w*.65+Math.sin(stateAge/90)*36,a.y+106+Math.sin(stateAge/40)*10,-1,.08);if(stateAge>=(healing()&&cycle===0?DRAGON_TIMING.firstCircle:DRAGON_TIMING.flight))begin('telegraph-strafe',p);}
  else if(state==='telegraph-strafe'){telegraph.ticks=Math.max(0,DRAGON_TIMING.strafeWarning-stateAge);if(stateAge>=DRAGON_TIMING.strafeWarning)begin('strafe',p);}
  else if(state==='strafe'){const t=stateAge/DRAGON_TIMING.strafe;pose(facing>0?a.x+30+(a.w-102)*t:a.x+a.w-72-(a.w-102)*t,a.y+94+Math.sin(t*Math.PI)*16,facing,facing*.12);if(stateAge===1||stateAge%config().shotEvery===0)spawnStrafe(p);if(stateAge>=DRAGON_TIMING.strafe)begin('telegraph-charge',p);}
  else if(state==='telegraph-charge'){telegraph.ticks=Math.max(0,DRAGON_TIMING.chargeWarning-stateAge);if(stateAge>=DRAGON_TIMING.chargeWarning)begin('charge',p);}
  else if(state==='charge'){const oldHead={...head},oldBody={...body},t=stateAge/DRAGON_TIMING.charge;pose(facing>0?a.x-136+(a.w+272)*t:a.x+a.w+96-(a.w+272)*t,chargeY,facing,0);if(p&&(sweptOverlap(head,oldHead,p)||sweptOverlap(body,oldBody,p))){const decision=damage(p,'dragon-charge',spec.id,oldHead.x+20);if(decision.parried){begin('deflected',p,geometry);stepProjectiles(p,geometry);return;}}if(stateAge>=DRAGON_TIMING.charge){chargePass++;begin(chargePass<config().chargePasses?'telegraph-charge':'telegraph-breath',p);}}
  else if(state==='deflected'){
   const t=clamp(stateAge/DRAGON_TIMING.deflectRise,0,1),ease=1-(1-t)**2;pose(deflectedFrom.x+(deflectedTarget.x-deflectedFrom.x)*ease,deflectedFrom.y+(deflectedTarget.y-deflectedFrom.y)*ease,facing,-facing*.22*(1-t));telegraph.ticks=Math.max(0,DRAGON_TIMING.deflected-stateAge);
   if(!deflectedHit&&stateAge>=DRAGON_TIMING.deflectRise&&sweptStomp(p,previousPlayer,head)){deflectedHit=true;bounce(p);applyHit('stomp',p,3);if(hp>0)begin('parry-recoil',p);}else if(stateAge>=DRAGON_TIMING.deflected)begin('telegraph-breath',p);
  }
  else if(state==='parry-recoil'){const t=clamp(stateAge/DRAGON_TIMING.parryRecoil,0,1);pose(landingFrom.x+facing*30*t,landingFrom.y-30*t,facing,-facing*.15);if(stateAge>=DRAGON_TIMING.parryRecoil)begin('telegraph-breath',p);}
  else if(state==='telegraph-breath'){telegraph.ticks=Math.max(0,DRAGON_TIMING.breathWarning-stateAge);if(stateAge>=DRAGON_TIMING.breathWarning)begin('breath',p);}
  else if(state==='breath'){if(stateAge>=1&&(stateAge-1)%20===0&&(stateAge-1)/20<phase)spawnBreath((stateAge-1)/20);if(stateAge>=DRAGON_TIMING.breath)begin('landing',p);}
  else if(state==='landing'){const t=clamp(stateAge/DRAGON_TIMING.landing,0,1),smooth=t*t*(3-2*t);pose(landingFrom.x+(spec.landingX-landingFrom.x)*smooth,landingFrom.y+(headY-landingFrom.y)*smooth,-1);if(stateAge>=DRAGON_TIMING.landing)begin('perch',p);}
  else if(state==='perch'){if(!perchHit&&sweptStomp(p,previousPlayer,head)){perchHit=true;bounce(p);applyHit('stomp',p,2);if(hp>0)begin('hurt',p);}else if(stateAge>=DRAGON_TIMING.perch){cycle++;begin('flight',p);}}
  else if(state==='hurt'){const t=clamp(stateAge/DRAGON_TIMING.hurt,0,1);pose(spec.landingX+120*t,headY-90*t,-1,-.15);if(stateAge>=DRAGON_TIMING.hurt){cycle++;begin('flight',p);}}
  stepProjectiles(p,geometry);
 }
 function step({tick,player,geometry=[]}={}){if(paused||disposed||player?.dead||player?.dying)return {geometry:geometryFor(geometry)};const next=Number.isInteger(tick)?tick:lastTick+1;if(next===lastTick)return {geometry:geometryFor(geometry)};if(next<lastTick)previousPlayer=null;currentTick=lastTick=next;currentGeometry=geometryFor(geometry);advance(player,currentGeometry);previousPlayer=player?{x:player.x,y:player.y,w:player.w,h:player.h}:null;return {geometry:geometryFor(geometry)};}
 function view(){return copy({id:spec.id,state,stateAge,age,hp,maxHp,phase,phaseName:config().name,phaseAge,attackPattern:config().pattern,shielded:healing(),healingActive:healing(),crystalsRemaining:crystals.filter(q=>q.active).length,crystals,head,body,facing,flightTilt,wingPose:state==='perch'?'folded':state==='landing'?'brake':'flight',legPose:state==='perch'?'perched':state==='landing'?'landing':'tucked',headOpen:state==='perch'&&!perchHit||state==='deflected'&&stateAge>=DRAGON_TIMING.deflectRise&&!deflectedHit,rangedOpen:rangedOpen(),rangedTelegraph:null,rangedWindow:{open:rangedOpen(),remaining:rangedOpen()?999:0,spent:false},hitRecovery,perchY,perch:{x:spec.landingX+16,y:perchY,w:48,h:16,topY:perchY},telegraph,safeLanes:[],egg,projectiles:projectiles.map(({player,...q})=>q),pools,effects,chargePass,chargeAltitude:chargeY<spec.groundY-40?'high':'low',defeated:state==='defeated',deathSequence:state==='defeated'?{age:Math.min(stateAge,DRAGON_TIMING.defeat),duration:DRAGON_TIMING.defeat,phase:stateAge<DRAGON_TIMING.dissolve?'fracture':stateAge<DRAGON_TIMING.portal?'dissolve':stateAge<DRAGON_TIMING.defeat?'portal':'complete'}:null,exitUnlocked:state==='defeated',damageCooldown});}
 return Object.freeze({step,view,reset,rangedTargets,receiveRangedHit,meleeTargets,receiveMeleeHit,allowsObject:id=>id!==spec.exitPortalId||state==='defeated',ownsGeometry:q=>ids.has(typeof q==='string'?q:q?.id)||ids.has(q?.sourceId)||eggEnabled&&((typeof q==='string'?q:q?.id)===eggId||q?.sourceId===eggId),pause(value=true){paused=!!value;},dispose(){disposed=true;projectiles=[];pools=[];effects=[];}});
}
