import * as JR_PIXELS from './editor-bowser-jr-pixels.mjs';
const {BOWSER_JR_PIXELS}=JR_PIXELS;
/** Source-observed normal SMB1 ground Bowser Jr lifecycle.
 * Exposed head -> two spiked-shell pursuits -> recovery hop/reveal; third
 * exposed-head stomp defeats. Numeric motion/body/cadence is author tuning.
 * No giant, wings, vehicle, new projectile or terrain destruction.
 * Optional authored tempo/bursts combine the existing aimed round fire only.
 * State lives on the same native walker and survives ordinary JSON snapshots.
 */
export const BOWSER_JR_PARAMETER_STATUS='authored-not-calibrated';
export const BOWSER_JR_AUTHORING_DEFAULTS=Object.freeze({kind:'bowser-jr',size:'normal',direction:-1,walkSpeed:.45,shellSpeed:2.6,shellAcceleration:.16,shellFrames:260,recoveryHopSpeed:4,revealFrames:10,fireIntervalFrames:150,fireWindupFrames:18,fireSpeed:1.6,initialFireDelayFrames:65,hitTransitionFrames:0,hitHopSpeed:0,pursuitWindupFrames:0,pursuitAimIntervalFrames:1,sourceParameterStatus:BOWSER_JR_PARAMETER_STATUS});
export const BOWSER_JR_BODY=Object.freeze({w:24,h:24,shellW:18,shellH:16});
export const BOWSER_JR_TEMPO_FIELDS=Object.freeze(['walkSpeed','shellSpeed','shellAcceleration','initialFireDelayFrames','recoveryFireDelayFrames','fireIntervalFrames','fireWindupFrames','fireSpeed']);
export const BOWSER_JR_ATTACK_PATTERN_FIELDS=Object.freeze(['shotsPerBurst','burstSpacingFrames']);
const baseKeys=Object.keys(BOWSER_JR_AUTHORING_DEFAULTS),keys=[...baseKeys,'stageTempo','attackPatterns'],optionalKeys=['hitTransitionFrames','hitHopSpeed','pursuitWindupFrames','pursuitAimIntervalFrames','stageTempo','attackPatterns'],requiredKeys=keys.filter(k=>!optionalKeys.includes(k)),EPS=1e-7;
const finite=(n,min,max)=>Number.isFinite(n)&&n>=min&&n<=max;
const integer=(n,min,max)=>Number.isSafeInteger(n)&&finite(n,min,max);
const plain=q=>q&&typeof q==='object'&&!Array.isArray(q)&&[Object.prototype,null].includes(Object.getPrototypeOf(q));
const safeId=id=>typeof id==='string'&&id.length<=100&&/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(id)&&!['constructor','prototype'].includes(id);
const shape=q=>q&&['x','y','w','h'].every(k=>Number.isFinite(q[k]))&&q.w>0&&q.h>0;
const overlap=(a,b)=>a.x+a.w>b.x+EPS&&a.x<b.x+b.w-EPS&&a.y+a.h>b.y+EPS&&a.y<b.y+b.h-EPS;
const fail=s=>{throw new TypeError(s);};
/** Closed author tuning, not a claim that the original unlocks new attacks.
 * Three stages are complete and ordered by remaining HP: 3, 2, then 1. */
export function validateBowserJrStageTempo(q){
 if(!plain(q)||Object.keys(q).some(k=>!['version','sourceParameterStatus','stages'].includes(k))||q.version!==1||q.sourceParameterStatus!==BOWSER_JR_PARAMETER_STATUS||!Array.isArray(q.stages)||q.stages.length!==3)fail('Invalid authored Bowser Jr stage tempo');
 for(const [i,s]of q.stages.entries()){
  const fields=['hp',...BOWSER_JR_TEMPO_FIELDS];
  if(!plain(s)||Object.keys(s).some(k=>!fields.includes(k))||fields.some(k=>!Object.hasOwn(s,k))||s.hp!==3-i)fail('Bowser Jr tempo requires complete ordered HP 3, 2, 1 stages');
  for(const k of ['walkSpeed','shellSpeed','fireSpeed'])if(!finite(s[k],.01,8))fail('Invalid authored Bowser Jr stage '+k);
  if(!finite(s.shellAcceleration,.001,1))fail('Invalid authored Bowser Jr stage shellAcceleration');
  for(const k of ['initialFireDelayFrames','recoveryFireDelayFrames','fireIntervalFrames','fireWindupFrames'])if(!integer(s[k],1,36000))fail('Invalid authored Bowser Jr stage '+k);
  if(s.fireWindupFrames>=s.fireIntervalFrames)fail('Invalid authored Bowser Jr stage firing cadence');
 }
 return true;
}
/** Neutral editor seed: enabling the optional leaf preserves the selected
 * actor's existing tempo until its author changes a stage. */
export function createBowserJrStageTempo(rule=BOWSER_JR_AUTHORING_DEFAULTS){
 const stages=[3,2,1].map(hp=>({hp,...Object.fromEntries(BOWSER_JR_TEMPO_FIELDS.map(k=>[k,rule[k==='recoveryFireDelayFrames'?'initialFireDelayFrames':k]]))}));
 const q={version:1,sourceParameterStatus:BOWSER_JR_PARAMETER_STATUS,stages};validateBowserJrStageTempo(q);return q;
}
/** Original author composition: repeated existing aimed shots, not a newly
 * observed Nintendo HP skill. Each shot samples aim once at its emission. */
export function validateBowserJrAttackPatterns(q){
 if(!plain(q)||Object.keys(q).some(k=>!['version','sourceParameterStatus','stages'].includes(k))||q.version!==1||q.sourceParameterStatus!==BOWSER_JR_PARAMETER_STATUS||!Array.isArray(q.stages)||q.stages.length!==3)fail('Invalid authored Bowser Jr attack patterns');
 for(const [i,s]of q.stages.entries()){
  const fields=['hp',...BOWSER_JR_ATTACK_PATTERN_FIELDS];
  if(!plain(s)||Object.keys(s).some(k=>!fields.includes(k))||fields.some(k=>!Object.hasOwn(s,k))||s.hp!==3-i||!integer(s.shotsPerBurst,1,3)||!integer(s.burstSpacingFrames,6,120))fail('Bowser Jr attack patterns require ordered HP 3, 2, 1, 1–3 shots and 6–120 tick spacing');
 }
 return true;
}
export function createBowserJrAttackPatterns(){
 return {version:1,sourceParameterStatus:BOWSER_JR_PARAMETER_STATUS,stages:[3,2,1].map(hp=>({hp,shotsPerBurst:1,burstSpacingFrames:18}))};
}
export function bowserJrAttackPatternForHp(rule,hp){
 if(![1,2,3].includes(hp))fail('Bowser Jr attack-pattern HP must be 3, 2 or 1');
 return rule.attackPatterns?{...rule.attackPatterns.stages[3-hp]}:{hp,shotsPerBurst:1,burstSpacingFrames:18};
}
/** Pure current-HP lookup. It never edits config, actor state or a clock. */
export function bowserJrTempoForHp(rule,hp){
 if(![1,2,3].includes(hp))fail('Bowser Jr tempo HP must be 3, 2 or 1');
 return rule.stageTempo?{...rule.stageTempo.stages[3-hp]}:{hp,...Object.fromEntries(BOWSER_JR_TEMPO_FIELDS.map(k=>[k,rule[k==='recoveryFireDelayFrames'?'initialFireDelayFrames':k]]))};
}
export function validateBowserJrRule(q){
 if(!plain(q)||Object.keys(q).some(k=>!keys.includes(k))||requiredKeys.some(k=>!Object.hasOwn(q,k)))fail('Bowser Jr requires explicit closed authored parameters');
 if(q.kind!=='bowser-jr'||q.size!=='normal'||![-1,1].includes(q.direction)||q.sourceParameterStatus!==BOWSER_JR_PARAMETER_STATUS)fail('Only normal unwinged ground Bowser Jr is supported');
 for(const k of ['walkSpeed','shellSpeed','fireSpeed'])if(!finite(q[k],.01,8))fail('Invalid authored Bowser Jr '+k);
 if(!finite(q.shellAcceleration,.001,1)||!finite(q.recoveryHopSpeed,.1,12))fail('Invalid authored Bowser Jr pursuit or hop');
 for(const k of ['shellFrames','fireIntervalFrames','fireWindupFrames','revealFrames'])if(!integer(q[k],1,36000))fail('Invalid authored Bowser Jr '+k);
 if(!integer(q.initialFireDelayFrames,1,36000)||q.fireWindupFrames>=q.fireIntervalFrames)fail('Invalid authored Bowser Jr firing cadence');
 const hitFrames=Object.hasOwn(q,'hitTransitionFrames')?q.hitTransitionFrames:0,hitSpeed=Object.hasOwn(q,'hitHopSpeed')?q.hitHopSpeed:0;
 if(!integer(hitFrames,0,120)||!finite(hitSpeed,0,12)||!hitFrames&&hitSpeed!==0||hitFrames&&hitSpeed<=0)fail('Invalid authored Bowser Jr hit transition');
 if(Object.hasOwn(q,'pursuitWindupFrames')&&!integer(q.pursuitWindupFrames,0,120)||Object.hasOwn(q,'pursuitAimIntervalFrames')&&!integer(q.pursuitAimIntervalFrames,1,120))fail('Invalid authored Bowser Jr pursuit reaction timing');
 if(Object.hasOwn(q,'stageTempo'))validateBowserJrStageTempo(q.stageTempo);
 if(Object.hasOwn(q,'attackPatterns'))validateBowserJrAttackPatterns(q.attackPatterns);
 return true;
}
export function validateBowserJuniorsRoom(room,spec=room?.smm2Mechanics?.bowserJuniors){
 if(spec===undefined)return;
 if(!plain(spec)||Object.keys(spec).some(k=>!['version','actors'].includes(k))||spec.version!==1||!Array.isArray(spec.actors)||spec.actors.length>32)fail('Invalid Bowser Jr v1 actor list');
 if(room.underwater||room.aquatic||room.playHero==='bill'||room.mechanics||room.devices?.length||/SMB3|SMW|NSMB|Underwater|Night/i.test(room.setting||'')||room.night)fail('Bowser Jr requires the supported normal SMB1 ground room');
 const seen=new Set(),s=room.smm2Mechanics||{};
 for(const q of spec.actors){
  if(!plain(q)||!safeId(q.id)||seen.has(q.id))fail('Bowser Jr needs a unique safe native actor ID');seen.add(q.id);
  const {id,...rule}=q;validateBowserJrRule(rule);
  const a=room.map?.objects?.find(a=>a.id===id),other=room.enemySkins?.[id]??room.markers?.find(m=>m.id===id)?.kind??a?.type;
  if(a?.kind!=='walker'||!shape(a)||a.w!==BOWSER_JR_BODY.w||a.h!==BOWSER_JR_BODY.h||!finite(a.x,0,room.map.width-a.w)||!finite(a.y,0,room.map.height-a.h)||room.map.objects.filter(a=>a.id===id).length!==1)fail('Bowser Jr needs one bounded matching 24x24 native walker');
  if(other!==undefined&&!['walker','bowser-jr','enemy-bowser-jr','marker-bowser-jr'].includes(other))fail('Bowser Jr cannot rename a different native enemy');
  const owned=['thwomps','shoes','boneShells','placedItems','powBlocks','pSwitches','helmets'].some(k=>s[k]?.some(a=>a.id===id))||s.parachuteActors?.actors?.some(a=>a.id===id)||s.lakituClouds?.clouds?.some(a=>a.id===id)||s.railHazards?.hazards?.some(a=>a.id===id)||s.localUpdrafts?.twisters?.some(a=>a.id===id)||s.portableStones?.stones?.some(a=>a.id===id)||s.underwaterActors?.profiles?.some(a=>a.id===id)||room.marioModules?.enemyVariants?.[id]||room.marioModules?.enemyStacks?.some(a=>a.id===id||a.supportId===id)||room.contraptions?.claws?.some(a=>a.actorId===id)||room.contraptions?.clownCars?.some(a=>a.actorId===id);
  if(owned)fail('Bowser Jr cannot share another actor motion controller');
 }
 return spec;
}
const ruleOf=q=>({...Object.fromEntries(baseKeys.map(k=>[k,q[k]??BOWSER_JR_AUTHORING_DEFAULTS[k]])),...Object.fromEntries(['stageTempo','attackPatterns'].filter(k=>Object.hasOwn(q,k)).map(k=>[k,structuredClone(q[k])]))});
const currentRule=(q,hp)=>q.stageTempo?{...q,...q.stageTempo.stages[3-hp]}:q;
export function bowserJrView(actor){
 const s=actor?.smm2BowserJr;if(!s||s.version!==1)return null;
 return {actorId:actor.id,phase:s.phase,phaseAge:s.phaseAge,hp:s.hp,exposed:['normal','firing','recovery-exposed'].includes(s.phase),shell:['shell','shell-windup','recovery-shell'].includes(s.phase),facing:actor.facing||s.direction,animationFrame:s.animationFrame||0,sourceParameterStatus:BOWSER_JR_PARAMETER_STATUS,anchor:'bottom-center'};
}

/** Shared visible pixel bounds: a 1px author margin around 22x22 exposed
 * art, and 1px horizontal margin around the 16x16 shell. Contacts use these
 * actual reconstructed opaque pixels rather than invisible box corners. */
export function bowserJrVisibleFrame(actor,{phase='normal',animationFrame=0,facing=-1}={}){
 const v=bowserJrView(actor);phase=v?.phase||phase;animationFrame=v?.animationFrame??animationFrame;facing=v?.facing??actor.facing??facing;
 const shell=['shell','shell-windup','recovery-shell'].includes(phase);let key=shell?(animationFrame?'shell2':'shell1'):phase==='firing'?'firing':animationFrame?'normal2':'normal1';
 if(phase==='shell-windup')key='shell1';
 if(phase==='hit-transition')key=(v?.phaseAge??0)<8&&Math.floor((v?.phaseAge??0)/3)%2===0?'hurt-flash':'hit-air';
 else if(phase==='recovery-shell')key='shell-air';
 else if(phase==='recovery-exposed')key='recovery-air';
 const image=BOWSER_JR_PIXELS[key]??BOWSER_JR_PIXELS[shell?'shell1':'normal1'];
 return {image,key,facing,x:Math.round(actor.x+(actor.w-image.w)/2),y:Math.round(actor.y+actor.h-image.h)};
}
export function bowserJrFireballVisibleFrame(actor,tick=0){
 const frames=JR_PIXELS.BOWSER_JR_FIRE_PIXELS;if(!frames?.length)return null;
 const frame=Math.floor((actor.age??tick)/6)%frames.length,image=frames[frame],w=12,h=12;
 return {image,frame,x:Math.round(actor.x+(actor.w-w)/2),y:Math.round(actor.y+(actor.h-h)/2),w,h};
}
function opaqueContact(frame,body){
 const im=frame.image,sx=(frame.w??im.w)/im.w,sy=(frame.h??im.h)/im.h;
 if(!overlap({x:frame.x,y:frame.y,w:im.w*sx,h:im.h*sy},body))return false;
 for(let row=0;row<im.h;row++)for(let col=0;col<im.w;col++)if(parseInt(im.rows[row][col],36)&&overlap({x:frame.x+col*sx,y:frame.y+row*sy,w:sx,h:sy},body))return true;
 return false;
}
export function createBowserJuniors(room,{emit=()=>{}}={}){
 const spec=room?.smm2Mechanics?.bowserJuniors;if(spec===undefined)return null;validateBowserJuniorsRoom(room,spec);
 const rules=new Map(spec.actors.map(q=>[q.id,ruleOf(q)]));
 const ownsActor=a=>rules.has(typeof a==='string'?a:a?.id)&&!!a?.smm2BowserJr;
 const notify=(actor,event,tick,extra={})=>emit('smm2-bowser-jr',{event,roomId:room.roomId,actorId:actor.id,tick,hp:actor.smm2BowserJr.hp,phase:actor.smm2BowserJr.phase,sourceParameterStatus:BOWSER_JR_PARAMETER_STATUS,...extra});
 function decorateActor(a,{tick=0}={}){const base=rules.get(a?.id);if(!base)return a;if(a.smm2BowserJr)return a;const q=currentRule(base,3);Object.assign(a,{type:'bowser-jr',smm2EnemyKind:'bowser-jr',hp:3,age:0,vx:q.direction*q.walkSpeed,vy:0,shell:false,facing:q.direction,grounded:false,support:null,source:{...a.source,jumping:false},smm2BowserJr:{version:1,phase:'normal',hp:3,direction:q.direction,phaseAge:0,fireRemaining:q.initialFireDelayFrames,serial:0,lastStepTick:tick,animationFrame:0}});return a;}
 function setShell(a,shell){const feet=a.y+a.h,center=a.x+a.w/2;a.w=shell?BOWSER_JR_BODY.shellW:BOWSER_JR_BODY.w;a.h=shell?BOWSER_JR_BODY.shellH:BOWSER_JR_BODY.h;a.x=center-a.w/2;a.y=feet-a.h;a.shell=shell;}
 function startPursuit(a,q,direction,tick){const s=a.smm2BowserJr;s.phase='shell';s.phaseAge=0;s.direction=direction;a.facing=direction;a.vx=q.pursuitWindupFrames?0:direction*q.shellSpeed;if(q.pursuitAimIntervalFrames>1){s.pursuitAimDirection=direction;s.pursuitAimRemaining=q.pursuitAimIntervalFrames;}notify(a,'shell-pursuit-start',tick);}
 function move(a,geometry){
  const solids=geometry.filter(q=>!q.hidden&&!q.removed&&['solid','oneway'].includes(q.collision));
  const count=Math.max(1,Math.ceil(Math.max(Math.abs(a.vx),Math.abs(a.vy))*2)),dx=a.vx/count,dy=a.vy/count;let side=false;
  a.grounded=false;a.support=null;
  for(let n=0;n<count;n++){
   const old={x:a.x,y:a.y,w:a.w,h:a.h},nextX=a.x+dx;
   const wall=solids.find(q=>q.collision==='solid'&&overlap({...a,x:nextX},q));
   if(wall){a.x=dx>0?wall.x-a.w:wall.x+wall.w;side=true;}else a.x=Math.max(0,Math.min(room.map.width-a.w,nextX));
   if(a.x!==nextX)side=true;
   const oldTop=a.y,oldFeet=a.y+a.h;a.y+=dy;
   const vertical=solids.find(q=>a.x+a.w>q.x+EPS&&a.x<q.x+q.w-EPS&&(dy>=0?oldFeet<=q.y+EPS&&a.y+a.h>=q.y: q.collision==='solid'&&oldTop>=q.y+q.h-EPS&&a.y<=q.y+q.h));
   if(vertical){if(dy>=0){a.y=vertical.y-a.h;a.grounded=true;a.support=vertical.id;}else a.y=vertical.y+vertical.h;a.vy=0;}
  }
  if(side){a.vx=-a.vx;a.smm2BowserJr.direction=Math.sign(a.vx)||a.smm2BowserJr.direction;}
 }
 function stepActor(a,{tick,player,geometry=[]}={}){
  if(a?.type==='bowser-jr-fireball'){if(a.dead)return true;a.age++;a.x+=a.vx;a.y+=a.vy;if(a.age>240||a.x+a.w<0||a.x>room.map.width||a.y+a.h<0||a.y>room.map.height||geometry.some(q=>!q.hidden&&q.collision==='solid'&&overlap(a,q)))a.dead=true;return true;}
  if(!ownsActor(a)||a.dead)return false;const s=a.smm2BowserJr,q=currentRule(rules.get(a.id),s.hp);if(tick<=s.lastStepTick)return true;s.lastStepTick=tick;s.phaseAge++;a.age++;s.animationFrame=Math.floor(a.age/8)%2;
  const aimDirection=player?.x+player?.w/2<a.x+a.w/2?-1:1;
  if(s.phase==='hit-transition'){
   a.vx=0;if(s.phaseAge>=q.hitTransitionFrames){setShell(a,true);if(q.pursuitWindupFrames){s.phase='shell-windup';s.phaseAge=0;notify(a,'shell-windup',tick);}else startPursuit(a,q,aimDirection,tick);}
  }else if(s.phase==='shell-windup'){
   a.vx=0;if(s.phaseAge>=q.pursuitWindupFrames&&a.grounded)startPursuit(a,q,aimDirection,tick);
  }else if(s.phase==='shell'){
   if(q.pursuitAimIntervalFrames>1&&--s.pursuitAimRemaining<=0){s.pursuitAimDirection=aimDirection;s.pursuitAimRemaining=q.pursuitAimIntervalFrames;}
   const target=(q.pursuitAimIntervalFrames>1?s.pursuitAimDirection:aimDirection)*q.shellSpeed;a.vx+=Math.max(-q.shellAcceleration,Math.min(q.shellAcceleration,target-a.vx));s.direction=Math.sign(a.vx)||s.direction;a.facing=s.direction;
   if(s.phaseAge>=q.shellFrames&&a.grounded){s.phase='recovery-shell';s.phaseAge=0;a.vx=0;a.vy=-q.recoveryHopSpeed;a.grounded=false;a.support=null;notify(a,'recovery-hop',tick);}
  }else if(s.phase==='recovery-shell'){
   a.vx=0;if(s.phaseAge>=q.revealFrames){const next={...a,x:a.x+a.w/2-BOWSER_JR_BODY.w/2,y:a.y+a.h-BOWSER_JR_BODY.h,w:BOWSER_JR_BODY.w,h:BOWSER_JR_BODY.h};if(!geometry.some(g=>!g.hidden&&g.collision==='solid'&&overlap(next,g))){setShell(a,false);s.phase='recovery-exposed';s.phaseAge=0;notify(a,'head-revealed',tick);}}
  }else if(s.phase==='recovery-exposed'){
   a.vx=0;if(a.grounded){s.phase='normal';s.phaseAge=0;s.fireRemaining=q.recoveryFireDelayFrames??q.initialFireDelayFrames;a.vx=s.direction*q.walkSpeed;notify(a,'recovered',tick);}
  }else if(s.phase==='normal'){
   a.vx=s.direction*q.walkSpeed;a.facing=s.direction;if(--s.fireRemaining<=0){s.phase='firing';s.phaseAge=0;a.vx=0;a.facing=aimDirection;if(q.attackPatterns){s.burstIndex=0;s.burstCount=bowserJrAttackPatternForHp(q,s.hp).shotsPerBurst;s.nextBurstShotAge=q.fireWindupFrames;}notify(a,'fire-windup',tick,q.attackPatterns?{burstCount:s.burstCount}:{});}
  }else if(s.phase==='firing'){
   a.vx=0;if(s.phaseAge>=(q.attackPatterns?s.nextBurstShotAge:q.fireWindupFrames)){
    if(q.attackPatterns)a.facing=aimDirection;
    const x=a.x+(a.facing<0?-8:a.w),y=a.y+9,tx=player.x+player.w/2,ty=player.y+player.h/2,len=Math.max(EPS,Math.hypot(tx-(x+4),ty-(y+4))),fire={id:a.id+'-fire-'+(++s.serial),kind:'walker',type:'bowser-jr-fireball',sourceActorId:a.id,x,y,w:8,h:8,vx:(tx-x-4)/len*q.fireSpeed,vy:(ty-y-4)/len*q.fireSpeed,age:0,dead:false,bowserJrAim:{x:tx,y:ty},smm2EnemyKind:'bowser-jr-fireball'};
    const burst=q.attackPatterns?{burstIndex:++s.burstIndex,burstCount:s.burstCount}:{};
    if(q.attackPatterns&&s.burstIndex<s.burstCount)s.nextBurstShotAge=s.phaseAge+bowserJrAttackPatternForHp(q,s.hp).burstSpacingFrames;
    else{s.phase='normal';s.phaseAge=0;s.fireRemaining=q.fireIntervalFrames;delete s.burstIndex;delete s.burstCount;delete s.nextBurstShotAge;}
    notify(a,'fireball',tick,{projectileId:fire.id,aim:{x:tx,y:ty},...burst});a.vy=Math.min(5,a.vy+.3);move(a,geometry);return {handled:true,projectile:fire};
   }
  }
  a.vy=Math.min(5,a.vy+.3);move(a,geometry);return true;
 }
 function playerContact(a,p,beforeP,{tick,beforeActor}={}){
  if(a?.type==='bowser-jr-fireball'&&!a.dead){const frame=bowserJrFireballVisibleFrame(a,tick);return {handled:true,harmful:frame?opaqueContact(frame,p):overlap(a,p),bounce:false};}
  if(!ownsActor(a)||a.dead)return null;const s=a.smm2BowserJr,v=bowserJrView(a);if(!overlap(a,p))return null;
  const old=beforeActor||a,relativeDrop=(p.y-beforeP.y)-(a.y-old.y),oldBottom=beforeP.y+beforeP.h;
  // A successful stomp is already one resolved top contact. While its native
  // upward rebound is still separating from the hurt pose, a newly taller
  // artwork row must not reclassify that same contact as an instant side hit.
  // This is limited to upward, top-origin separation; sides and a descending
  // re-contact remain harmful, and the shell never gains this guard.
  if(s.phase==='hit-transition'&&p.vy<0&&oldBottom<=old.y+12)return {handled:true,harmful:false,bounce:false};
  const frame=bowserJrVisibleFrame(a),im=frame.image;let visibleContact=false,headTop=Infinity;
  for(let row=0;row<im.h;row++)for(let col=0;col<im.w;col++){if(parseInt(im.rows[row][col],36)===0)continue;const cell={x:frame.x+(frame.facing>0?im.w-1-col:col),y:frame.y+row,w:1,h:1};if(overlap(cell,p))visibleContact=true;if(v.exposed&&col<19&&row<12&&p.x+p.w>cell.x+EPS&&p.x<cell.x+1-EPS)headTop=Math.min(headTop,cell.y);}
  const oldHeadTop=headTop-(a.y-old.y),valid=v.exposed&&p.vy>=0&&relativeDrop>EPS&&oldBottom<=oldHeadTop+2&&p.y+p.h>=headTop&&Number.isFinite(headTop)&&s.lastHitTick!==tick;
  if(!valid)return {handled:true,harmful:visibleContact,bounce:false};
  const bounceY=headTop-p.h;s.hp--;a.hp=s.hp;s.lastHitTick=tick;s.serial++;delete s.burstIndex;delete s.burstCount;delete s.nextBurstShotAge;delete s.pursuitAimDirection;delete s.pursuitAimRemaining;
  if(s.hp===0){s.phase='defeated';s.phaseAge=0;a.defeated=true;notify(a,'defeated',tick,{points:4000});return {handled:true,harmful:false,bounce:true,bounceY,defeated:true,points:4000};}
  const q=currentRule(rules.get(a.id),s.hp);s.phaseAge=0;
  if(q.hitTransitionFrames){s.phase='hit-transition';a.vx=0;a.vy=-q.hitHopSpeed;a.grounded=false;a.support=null;}
  else{setShell(a,true);s.phase=q.pursuitWindupFrames?'shell-windup':'shell';a.vx=q.pursuitWindupFrames?0:s.direction*q.shellSpeed;a.vy=0;if(!q.pursuitWindupFrames&&q.pursuitAimIntervalFrames>1){s.pursuitAimDirection=s.direction;s.pursuitAimRemaining=q.pursuitAimIntervalFrames;}}
  notify(a,'head-stomp',tick);return {handled:true,harmful:false,bounce:true,bounceY,defeated:false,points:0};
 }
 return {ownsActor,decorateActor,stepActor,playerContact,protectsActor:a=>ownsActor(a)&&a.smm2BowserJr.hp>0,view:bowserJrView};
}
