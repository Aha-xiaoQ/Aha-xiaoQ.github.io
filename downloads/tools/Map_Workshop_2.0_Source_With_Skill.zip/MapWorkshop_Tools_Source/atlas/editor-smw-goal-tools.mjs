import {clone,validate} from './editor-model.mjs';
import {validateSmwGoalTapeRoom} from './editor-smw-goal-tape.mjs';
const plain=q=>q&&typeof q==='object'&&!Array.isArray(q)&&[Object.prototype,null].includes(Object.getPrototypeOf(q));

/** Neutral defaults are author fits, not a Nintendo reward/physics table. */
export function defaultsSmwGoalTapeForExit(exit,roomWidth){
 if(!exit||exit.kind!=='exit'||exit.w<24||exit.h<24)throw Error('SMW Goal Tape needs an existing exit at least 24 × 24');
 const width=Math.min(16,exit.w/3),left={x:exit.x,y:exit.y,w:width,h:exit.h},right={...left,x:exit.x+exit.w-width};
 const minY=exit.y+Math.min(16,exit.h/3),maxY=exit.y+exit.h-Math.min(8,exit.h/3);
 return{posts:{left,right},tape:{x:left.x+width/2,w:right.x+width/2-left.x-width/2,h:4,minY,maxY,speed:1,phaseFrames:0,direction:'up'},rewardBands:[{minY,maxY,points:0,coins:0,lives:0}],clear:{hopSpeed:2,walkSpeed:.5,walkDistance:Math.min(96,Math.max(0,roomWidth-right.x-right.w)),clearFrames:300}};
}
function edit(room,fn){const draft=clone(room);fn(draft);validateSmwGoalTapeRoom(draft);validate({format:'xiaoq-map-project',version:1,id:'smw-goal-tape-check',title:'SMW Goal Tape',rooms:[draft]},{allowIncompleteCompletionMarks:true});for(const key of Object.keys(room))if(!Object.hasOwn(draft,key))delete room[key];Object.assign(room,draft);}
export function setSmwGoalTape(room,id,options={}){
 if(id===null)return clearSmwGoalTape(room);
 edit(room,r=>{
  const exit=r.map.objects.find(o=>o.id===id&&o.kind==='exit');if(!exit)throw Error('请选择已有终点对象');
  if(!plain(options)||Object.hasOwn(options,'id'))throw Error('Goal Tape options must configure the selected exit');
  for(const key of ['posts','tape','clear'])if(Object.hasOwn(options,key)&&!plain(options[key]))throw Error('Invalid Goal Tape '+key+' options');
  for(const key of ['left','right'])if(options.posts&&Object.hasOwn(options.posts,key)&&!plain(options.posts[key]))throw Error('Invalid Goal Tape '+key+' post options');
  const base=r.smm2Mechanics?.goalTape?.id===id?clone(r.smm2Mechanics.goalTape):defaultsSmwGoalTapeForExit(exit,r.map.width),extra=clone(options);
  r.smm2Mechanics??={version:1};
  r.smm2Mechanics.goalTape={...base,...extra,id,posts:{...base.posts,...extra.posts,left:{...base.posts.left,...extra.posts?.left},right:{...base.posts.right,...extra.posts?.right}},tape:{...base.tape,...extra.tape},clear:{...base.clear,...extra.clear}};
 });
}
export function clearSmwGoalTape(room){edit(room,r=>{if(r.smm2Mechanics)delete r.smm2Mechanics.goalTape;});}
/** Prune only a previously bound exit that an actual deletion removed. */
export function pruneSmwGoalTapeReference(room,before){const q=room.smm2Mechanics?.goalTape;if(q&&before?.smm2Mechanics?.goalTape?.id===q.id&&before.map.objects.some(o=>o.id===q.id&&o.kind==='exit')&&!room.map.objects.some(o=>o.id===q.id&&o.kind==='exit'))delete room.smm2Mechanics.goalTape;}

/** Native change callback must own the complete History transaction. */
export function mountSmwGoalTools({parent,room,selected=()=>new Set(),change,report=()=>{}}){
 const panel=document.createElement('details');parent.append(panel);
 panel.innerHTML='<summary>SMW 移动终点横带</summary><p class="small">先应用 SMW 水下图像风格，再绑定已有终点。柱体、横带范围／碰撞尺寸／速度、各高度报酬及清关数值都是作者设置；其他高度报酬未据原作验证。points 是接触时总分数增量，金币不再另加分。</p><label>已有终点<select data-smw-goal="exit"></select></label><label>完整横带、柱体、报酬与清关 JSON<textarea data-smw-goal="options" rows="15"></textarea></label><button type="button" data-smw-goal="apply">设置移动横带终点</button><button type="button" data-smw-goal="clear">恢复普通终点</button>';
 const get=k=>panel.querySelector('[data-smw-goal="'+k+'"]');let lastRoom=null,lastSelection='';
 const attempt=fn=>{try{change(fn);}catch(e){report(e.message);}refresh();};
 get('apply').onclick=()=>attempt(()=>setSmwGoalTape(room(),get('exit').value,JSON.parse(get('options').value)));
 get('clear').onclick=()=>attempt(()=>clearSmwGoalTape(room()));get('exit').onchange=()=>refresh();
 function refresh(){
  const r=room(),ids=selected(),goals=r.map.objects.filter(o=>o.kind==='exit'),q=r.smm2Mechanics?.goalTape,roomChanged=r.roomId!==lastRoom,key=[...ids].sort().join('|'),selectionChanged=roomChanged||key!==lastSelection;
  let pick=selectionChanged&&ids.size===1&&goals.some(o=>ids.has(o.id))?[...ids][0]:roomChanged?q?.id:get('exit').value;
  if(!goals.some(o=>o.id===pick))pick=q?.id||goals[0]?.id||'';
  get('exit').replaceChildren();for(const o of goals){const option=document.createElement('option');option.value=o.id;option.textContent=o.id;get('exit').append(option);}get('exit').value=pick;
  const exit=goals.find(o=>o.id===pick);let options={};
  if(q?.id===pick){options=clone(q);delete options.id;}else if(exit){try{options=defaultsSmwGoalTapeForExit(exit,r.map.width);}catch{}}
  get('options').value=JSON.stringify(options,null,2);get('apply').disabled=!exit;get('clear').disabled=!q;lastRoom=r.roomId;lastSelection=key;
 }
 refresh();return{refresh};
}
