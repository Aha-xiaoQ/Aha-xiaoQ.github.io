// Standard Gamepad API indexes are physical positions, not the printed letters.
export function gamepadFaceLayout(layout='auto',id=''){
 return layout==='right'||(layout==='auto'&&/Nintendo|Switch|Joy-Con|Pro Controller/i.test(id))?'right':'bottom';
}
export function gamepadLabels(layout='bottom'){
 return layout==='right'?{jump:'A（右）',run:'B（下）',record:'Y（左）',retry:'X（上）'}:{jump:'A（下）',run:'B（右）',record:'X（左）',retry:'Y（上）'};
}
const empty=()=>({x:0,up:false,down:false,interact:false,jump:false,run:false,auxRun:false,dismount:false,dismountPressed:false,connected:false,pause:false,mute:false,echo:false,echoRetry:false,echoClear:false,pausePressed:false,mutePressed:false,echoPressed:false,retryPressed:false,clearPressed:false,confirmPressed:false,cancelPressed:false,upPressed:false,downPressed:false,clearHolding:false,clearProgress:0});
/** Poll once per animation frame. Commands are edges; movement is hysteretic.
 * Buttons/axes held at connect, reconnect, or suspend stay neutral until released.
 * The injectable reader and clock allow deterministic simulated-API tests.
 */
export function createGamepadInput(read=()=>globalThis.navigator?.getGamepads?.()||[],layout=()=>'auto',options={}){
 const clock=options.now||(()=>globalThis.performance?.now?.()||Date.now()),press=options.pressThreshold??.35,release=options.releaseThreshold??.20,holdMs=options.clearHoldMs??600;
 let active=null,previous={},axes=[0,0],blocked=new Set(),blockedAxes=new Set(),clearSince=null,clearFired=false,lastButtons=[],context=null;
 const identity=p=>`${p.index??0}:${p.id||''}:${p.mapping||''}`;
 const pressed=b=>!!b?.pressed||(b?.value||0)>.5;
 function arm(p){previous={};axes=[0,0];blocked=new Set((p.buttons||[]).map((b,i)=>pressed(b)?i:null).filter(i=>i!==null));blockedAxes=new Set([0,1].filter(i=>Math.abs(p.axes?.[i]||0)>release));clearSince=null;clearFired=false;}
 function poll(time=clock()){
  let pads;try{pads=Array.from(read()||[]).filter(p=>p&&p.connected!==false);}catch{pads=[];}
  const old=active,pad=pads.find(p=>identity(p)===active)||pads.find(p=>p.mapping==='standard')||pads[0];
  if(!pad){active=null;previous={};axes=[0,0];blocked.clear();blockedAxes.clear();clearSince=null;clearFired=false;return {...empty(),disconnected:old!==null,identityChanged:false};}
  const next=identity(pad),changed=next!==active;if(changed){active=next;arm(pad);}
  lastButtons=pad.buttons||[];
  // Shoulder commands are room-specific. A shoulder already held on entering
  // a Shoe room must be released, just like one held during connection.
  const nextContext=typeof options.context==='function'?options.context():options.context||'legacy';
  if(context!==null&&context!==nextContext){for(const i of [4,5,6,7])if(pressed(pad.buttons?.[i]))blocked.add(i);clearSince=null;clearFired=false;}
  context=nextContext;
  const button=i=>{const raw=pressed(pad.buttons?.[i]);if(!raw)blocked.delete(i);return raw&&!blocked.has(i);};
  const axis=i=>{const raw=Number(pad.axes?.[i])||0;if(blockedAxes.has(i)){if(Math.abs(raw)<=release)blockedAxes.delete(i);else return 0;}
   if(Math.abs(raw)<=release)axes[i]=0;else if(Math.abs(raw)>=press)axes[i]=Math.sign(raw);else if(axes[i]&&Math.sign(raw)!==axes[i])axes[i]=0;return axes[i];};
  const rightA=gamepadFaceLayout(layout(),pad.id)==='right',horizontal=axis(0),vertical=axis(1),left=button(14),right=button(15),up=button(12)||vertical<0,down=button(13)||vertical>0;
  const state={...empty(),connected:true,index:pad.index??0,id:pad.id||'',standard:pad.mapping==='standard',layout:rightA?'right':'bottom',connectedNow:changed,identityChanged:changed&&old!==null,disconnected:changed&&old!==null,x:left||right?Number(right)-Number(left):horizontal,up,down,interact:up||down,jump:button(rightA?1:0),run:button(rightA?0:1),auxRun:button(2)||button(3),echo:button(2),echoRetry:button(3),pause:button(9),mute:button(8)};
  const shoulders=[4,5,6,7].map(button);state.dismount=context==='shoe'&&shoulders.some(Boolean);state.dismountPressed=state.dismount&&!previous.dismount;
  for(const [edge,key]of [['pausePressed','pause'],['mutePressed','mute'],['echoPressed','echo'],['retryPressed','echoRetry'],['confirmPressed','jump'],['cancelPressed','run'],['upPressed','up'],['downPressed','down']])state[edge]=state[key]&&!previous[key];
  const clear=context!=='shoe'&&shoulders[0];if(clear){clearSince??=time;state.clearProgress=Math.min(1,Math.max(0,(time-clearSince)/holdMs));state.clearHolding=!clearFired;if(!clearFired&&time-clearSince>=holdMs){state.clearPressed=state.echoClear=true;clearFired=true;state.clearHolding=false;}}else{clearSince=null;clearFired=false;}
  previous=state;return state;
 }
 // Used on pause/blur: do not carry a held jump, direction or command into resume.
 poll.suspend=()=>{blocked=new Set(lastButtons.map((b,i)=>pressed(b)?i:null).filter(i=>i!==null));blockedAxes=new Set([0,1]);axes=[0,0];previous={};clearSince=null;clearFired=false;};
 return poll;
}
