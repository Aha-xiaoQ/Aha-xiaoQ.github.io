/** One authoritative authored liquid surface, shared by art, harm and eligible
 * boat collision. Motion numbers are local approximations, not SMM2 calibration.
 * Never insert the liquid volume or surface into the common Mario solids. */
const EPS=1e-7;
const plain=q=>q&&typeof q==='object'&&!Array.isArray(q)&&[Object.prototype,null].includes(Object.getPrototypeOf(q));
const finite=(n,a,b)=>Number.isFinite(n)&&n>=a&&n<=b;
const integer=(n,a,b)=>Number.isSafeInteger(n)&&finite(n,a,b);
const safe=s=>typeof s==='string'&&/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(s)&&s.length<=100;
const fields=['markerId','kind','minY','maxY','initialY','speed','direction','waitMinFrames','waitMaxFrames'];
const rect=q=>q&&['x','y','w','h'].every(k=>Number.isFinite(q[k]))&&q.w>0&&q.h>0;
export function validateSmm2LiquidRoom(room){
 const q=room?.smm2Mechanics?.liquid;if(q===undefined)return;
 if(!plain(q)||Object.keys(q).some(k=>!fields.includes(k))||!safe(q.markerId)||q.kind!=='lava')throw Error('Invalid managed SMM2 lava fields');
 const marker=room.markers?.find(m=>m.id===q.markerId);
 if(!marker||!/^lava-/.test(marker.kind)||!rect(marker)||!finite(marker.x,0,room.map.width-marker.w)||!finite(marker.y,0,room.map.height)||!finite(q.minY,0,room.map.height)||!finite(q.maxY,q.minY,room.map.height-1)||!finite(q.initialY,q.minY,q.maxY)||Math.abs(marker.y-q.initialY)>EPS)throw Error('Managed lava needs a real same-room marker and valid surface range');
 if(!finite(q.speed,0,16)||(q.minY===q.maxY?q.speed!==0:q.speed<=0||q.speed>q.maxY-q.minY))throw Error('Invalid lava surface speed');
 if(![-1,1].includes(q.direction)||!integer(q.waitMinFrames,0,36000)||!integer(q.waitMaxFrames,0,36000))throw Error('Invalid lava direction or endpoint waits');
 const colliderId=q.markerId+'-boat-surface';
 if([...room.map.geometry,...room.map.objects,...room.markers].some(a=>a.id===colliderId))throw Error('Lava boat surface ID conflicts with authored object');
 for(const marker of room.markers||[])if(marker.source?.managedLiquidMarkerId!==undefined){
  const actor=room.map.objects.find(a=>a.id===marker.id&&a.kind==='walker');
  if(marker.source.managedLiquidMarkerId!==q.markerId||marker.kind!=='podoboo'||!actor||!integer(marker.source.initialPhaseFrames??0,0,70))throw Error('Lava Bubble must reference the same managed liquid and real native actor with bounded initial phase');
 }
}
export function createSmm2Liquid(room,{emit=()=>{}}={}){
 validateSmm2LiquidRoom(room);const source=room?.smm2Mechanics?.liquid;if(!source)return null;
 if(typeof emit!=='function')throw Error('Invalid liquid event callback');
 const q=structuredClone(source),marker=structuredClone(room.markers.find(m=>m.id===q.markerId));
 let y,previousY,direction,wait,lastTick,activeFrames;
 function reset(){y=previousY=q.initialY;direction=q.direction;wait=0;lastTick=null;activeFrames=0;}
 reset();
 function step({tick,paused=false}={}){
  if(!integer(tick,0,Number.MAX_SAFE_INTEGER)||typeof paused!=='boolean')throw Error('Invalid liquid tick');
  if(paused||lastTick!==null&&tick<=lastTick)return false;
  lastTick=tick;activeFrames++;previousY=y;
  if(wait>0)wait--;
  else if(q.speed){
   y+=direction*q.speed;
   if(y<=q.minY){y=q.minY;direction=1;wait=q.waitMinFrames;emit('smm2-liquid',{event:'surface-limit',roomId:room.roomId,markerId:q.markerId,tick,edge:'min',y});}
   else if(y>=q.maxY){y=q.maxY;direction=-1;wait=q.waitMaxFrames;emit('smm2-liquid',{event:'surface-limit',roomId:room.roomId,markerId:q.markerId,tick,edge:'max',y});}
  }
  return true;
 }
 function surfaceForBoat(){return {id:q.markerId+'-boat-surface',x:marker.x,y,w:marker.w,h:1,collision:'oneway',material:'managed-lava-surface',dx:0,dy:y-previousY,smm2LiquidSupport:true};}
 function contact(body){if(!rect(body))throw Error('Liquid contact needs a real body');return body.x+body.w>marker.x+EPS&&body.x<marker.x+marker.w-EPS&&body.y+body.h>y+EPS&&body.y<room.map.height-EPS;}
 function view(){return {version:1,approximation:true,markerId:q.markerId,kind:q.kind,x:marker.x,w:marker.w,y,previousY,dy:y-previousY,bottom:room.map.height,direction,wait,activeFrames,tick:lastTick};}
 return Object.freeze({step,reset,view,surfaceForBoat,contact,ownsMarker:id=>id===q.markerId});
}
