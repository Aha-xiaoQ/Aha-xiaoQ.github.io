// Existing recordings are reused without synthesized replacements.
// Checkpoint uses the documented shared SMM/SMM2 SMB1+SMB3 checkpoint sample,
// decoded without PCM changes to WAV; see assets/classic-audio/CHECKPOINT_AUDIO_PROVENANCE.json.
// Castle uses an evidence-backed whole-period PCM crop of the same recording;
// source/crop/seam treatment and hashes are in assets/classic-audio/AUDIO_LOOP_PROVENANCE.json.
// Underwater retains the owned source musical sequence after measured silent-lead removal
// with20ms file-boundary fades; this is an authored excerpt wrap, not a recovered
// complete Nintendo loop. Details: assets/classic-audio/UNDERWATER_PLAYBACK_ADAPTATION.json.
// Bill theme response was absent from the restored inputs. null is an explicit
// unavailable soundtrack; effects and Bill gameplay are preserved. No substitute.
export const audioFiles={smw_underwater:null,smw_star:null,smb3_overworld:null,checkpoint:'smm2-smb1-smb3-checkpoint.wav',bill_theme:null,bill_death:'../character-audio/bill-death.wav',bill_pickup:'../character-audio/bill-pickup.wav',bill_N:'../character-audio/bill-shot.wav',bill_M:'../character-audio/bill-machine-shot.wav',bill_S:'../character-audio/bill-spread.wav',bill_F:'../character-audio/bill-flare.wav',bill_L:'../character-audio/bill-laser.wav',cannon:'bowser_fire.mp3',pause:'pause.mp3',castle:'castle-loop.wav',ghost_house_night:'ghost-house-night-loop.wav',underwater:'underwater-playback-adapted.mp3',hurry_castle:'hurry_castle.mp3',hurry_underwater:'hurry_underwater.mp3',hurry_overworld:'hurry_overworld.mp3',hurry_underworld:'hurry_underworld.mp3',hurry_star:'hurry_star.mp3',hurry:'hurry.mp3',flag:'flag.mp3',world_clear:'world_clear.mp3',bowser_fall:'bowser_fall.mp3',bowser_fire:'bowser_fire.mp3',jump_super:'jump_super.mp3',gameover:'gameover.mp3',life:'oneup.mp3',fire:'fire.mp3',bump:'bump.mp3',break:'break.mp3',appear:'appear.mp3',powerup:'powerup.mp3',kick:'kick.mp3',star:'star.mp3',overworld:'overworld.mp3',underworld:'underworld.mp3',jump:'jump_small.mp3',pickup:'coin.mp3',death:'death.mp3',hurt:'hurt.mp3',portal:'pipe.mp3',complete:'clear.mp3',stomp:'stomp.wav'};
export function themeFor(setting='',star=false,timeLeft=400){
 if(/^SMW Underwater$/i.test(setting))return star?'smw_star':'smw_underwater';
 if(!star&&/^SMB3 (Desert|Overworld)$/i.test(setting))return 'smb3_overworld';
 // Only this original night-theme family is known; no unverified hurry remix.
 if(!star&&/Ghost\s*House/i.test(setting)&&/Night/i.test(setting))return 'ghost_house_night';
 const theme=(star||/\bSky\b/i.test(setting))?'star':/Underwater/i.test(setting)?'underwater':/Underworld/i.test(setting)?'underworld':/Castle/i.test(setting)?'castle':'overworld';
 return timeLeft<=100?'hurry_'+theme:theme;
}
export function createSound(media={}){
 // Keep one background element for this session. A gesture authorizes that
 // element, including later room themes; effects remain separate one-shots.
 let music=null,track='',enabled=true,blocked=false,suspended=false,attempt=0,pending=null,lastError='',transientFailures=0;const effects=new Set(),events=[];const log=key=>{events.push(key);if(events.length>30)events.shift();};
 const url=key=>media[key]||new URL('./assets/classic-audio/'+audioFiles[key],import.meta.url).href;
 function haltEffects(){for(const a of effects)a.pause();effects.clear();}
 function pauseMusic(){suspended=true;attempt++;pending=null;music?.pause();}
 function stopMusic(){pauseMusic();track='';blocked=false;lastError='';transientFailures=0;if(music)music.currentTime=0;}
 function stop(){stopMusic();haltEffects();}
 function select(key){if((key==='bill_theme'||key==='smb3_overworld')&&!audioFiles[key]){stopMusic();return false;}if(!audioFiles[key])return false;if(track===key)return true;attempt++;pending=null;music?.pause();music??=new Audio();track=key;music.src=url(key);music.loop=true;music.preload='auto';music.volume=.35;music.currentTime=0;blocked=false;lastError='';transientFailures=0;return true;}
 function startMusic(){
  if(!enabled||blocked||suspended||!track||!music||pending||!music.paused)return pending;
  const a=music,key=track,id=++attempt;
  // Call play synchronously, before any promise/RAF boundary, when a gesture
  // handler asks to unlock. Catch both synchronous and promise rejections.
  let result;try{result=a.play();}catch(error){result=Promise.reject(error);}
  pending=Promise.resolve(result).then(()=>{if(id!==attempt)return;pending=null;lastError='';transientFailures=0;log(key);},error=>{
   if(id!==attempt)return;pending=null;lastError=error?.name||'PlaybackError';a.pause();
   // AbortError means playback/loading was interrupted, not that autoplay was
   // denied. Let the next ordinary music update retry the same element/cursor.
   // Bound repeated interruptions; real policy/format failures still wait for
   // a user gesture, and stale promises cannot revive a paused/closed session.
   blocked=lastError==='AbortError'?++transientFailures>2:true;
  });
  return pending;
 }
 function background(key){if(select(key))return startMusic();}
 function resumeMusic(key=track,gesture=false){suspended=false;if(gesture){blocked=false;lastError='';transientFailures=0;}return background(key);}
 function unlock(key=track){blocked=false;lastError='';transientFailures=0;if(key)select(key);return startMusic();}
 function effect(key){if(!enabled||!audioFiles[key])return;if(/^bill_[NMSFL]$/.test(key))for(const old of [...effects])if(/^bill_[NMSFL]$/.test(old.effectKey)){old.pause();effects.delete(old);}const a=new Audio(url(key));a.effectKey=key;a.volume=/^bill_[NMSFL]$/.test(key)?.12:.65;effects.add(a);a.onended=()=>effects.delete(a);a.play().then(()=>log(key)).catch(()=>effects.delete(a));}
 return {snapshot(){return {enabled,blocked,track,playing:!!track&&!!music&&!music.paused,suspended,pending:!!pending,lastError,events:[...events]};},background,effect,stop,unlock,pauseMusic,pause(){pauseMusic();haltEffects();},resumeMusic,stopMusic,get blocked(){return blocked;},toggle(){if(blocked&&enabled){unlock();return true;}enabled=!enabled;if(enabled)unlock();else{attempt++;pending=null;music?.pause();haltEffects();}return enabled;},get enabled(){return enabled;}};
}
