/** Bone Shell definitions share the existing native footwear motor, with a
 * distinct empty vehicle type and explicit locally-authored collapse tuning. */
const finite=(n,a,b)=>Number.isFinite(n)&&n>=a&&n<=b;
const integer=(n,a,b)=>Number.isSafeInteger(n)&&finite(n,a,b);
const plain=q=>q&&typeof q==='object'&&!Array.isArray(q)&&[Object.prototype,null].includes(Object.getPrototypeOf(q));
const safe=s=>typeof s==='string'&&/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(s)&&s.length<=100;
const fields=(q,keys,label)=>{if(!plain(q)||Object.keys(q).some(k=>!keys.includes(k)))throw Error('Invalid '+label+' fields');};
export const BONE_SHELL_TUNING=Object.freeze({gravity:.4375,maxFallSpeed:4.25,seatInset:14,boardingTolerance:1.01,stompBounceSpeed:4.1333333,ejectSpeed:4.1333333});
export function validateBonePlayingDead(room,q){
 fields(q,['durationFrames','maxFrames','dropThroughIds'],'Bone Shell playing-dead');
 if(!integer(q.durationFrames,1,3600)||!integer(q.maxFrames,q.durationFrames,3600)||!Array.isArray(q.dropThroughIds)||q.dropThroughIds.length>256||new Set(q.dropThroughIds).size!==q.dropThroughIds.length)throw Error('Invalid authored Bone Shell collapse duration or drop targets');
 for(const id of q.dropThroughIds)if(!safe(id)||!room.map.geometry.some(g=>g.id===id&&g.collision==='oneway'))throw Error('Bone Shell drop target must be an actual same-room one-way platform');
}
export function validateSmm2BoneShellsRoom(room){
 const list=room?.smm2Mechanics?.boneShells;if(list===undefined)return;
 if(!Array.isArray(list)||list.length>256)throw Error('Invalid Bone Shell list');const seen=new Set();
 const all=[...room.map.geometry,...room.map.objects,...(room.markers||[])];
 for(const q of list){
  fields(q,['id','tuning','playingDead','templateOnly'],'Bone Shell');
  const a=room.map.objects.find(a=>a.id===q.id);
  if(!safe(q.id)||seen.has(q.id)||all.filter(a=>a.id===q.id).length!==1||!a||a.kind!=='walker'||!['x','y','w','h'].every(k=>Number.isFinite(a[k]))||!finite(a.w,1,64)||!finite(a.h,1,64)||!finite(a.x,0,room.map.width-a.w)||!finite(a.y,0,room.map.height-a.h))throw Error('Bone Shell requires one real native walker foot body');seen.add(q.id);
  if(q.templateOnly!==undefined&&typeof q.templateOnly!=='boolean')throw Error('Invalid Bone Shell source-template flag');
  if(q.templateOnly&&!room.marioModules?.enemySources?.some(s=>s.enemy==='bone-shell'&&s.shoeTemplateId===q.id))throw Error('Pipe-only Bone Shell must be bound to an actual typed supply');
  if(q.tuning!==undefined){fields(q.tuning,Object.keys(BONE_SHELL_TUNING),'Bone Shell tuning');for(const [key,value]of Object.entries(q.tuning))if(!finite(value,key==='boardingTolerance'?0:.001,key==='boardingTolerance'?2:key==='seatInset'?a.h:64))throw Error('Invalid Bone Shell '+key);}
  validateBonePlayingDead(room,q.playingDead);
 }
}
export function boneShellDefinitions(room){
 return (room?.smm2Mechanics?.boneShells||[]).map(q=>({id:q.id,kind:'bone-shell',size:'small',winged:false,occupant:'empty',crouchCompatible:false,tuning:{...BONE_SHELL_TUNING,...q.tuning,npcSpeed:0,npcHopSpeed:0,npcWingHopSpeed:0,walkHopSpeed:0,flutterFrames:0,blastRange:0},boneCollapse:structuredClone(q.playingDead),templateOnly:q.templateOnly??false}));
}
export function boneSeatInset(player,definition){return definition.kind==='bone-shell'?Math.min(definition.tuning.seatInset,Math.max(0,player.h-14)):Math.min(definition.tuning.seatInset,player.h);}
