import {clone,validate} from './editor-model.mjs';
export function setSmm2CameraFrame(room,spec){
 const next=clone(room);next.smm2Mechanics??={version:1};if(spec===null)delete next.smm2Mechanics.camera;else next.smm2Mechanics.camera=clone(spec);
 validate({format:'xiaoq-map-project',version:1,id:'camera-settings-validation',title:'Camera settings',rooms:[next]},{allowIncompleteCompletionMarks:true});
 for(const k of Object.keys(room))if(!Object.hasOwn(next,k))delete room[k];Object.assign(room,next);
}
/** Presentation policy: references real colliders, never opens an exit or
 * changes physics. The original course demonstrates release after breaking
 * the wall; the stored policy is an explicit authored reconstruction. */
export function mountSmm2CameraTools({parent,room,change,report=()=>{}}){
 const root=document.createElement('details');root.className='tool-details';const summary=document.createElement('summary');summary.textContent='镜头范围与拆墙后滚屏';root.append(summary);parent.append(root);
 const controls=new Map();
 function input(id,label,type='number'){const row=document.createElement('label'),n=document.createElement('input');row.textContent=label;n.type=type;n.setAttribute('data-camera-control',id);if(type==='number')n.step='any';row.append(n);root.append(row);controls.set(id,n);return n;}
 input('enabled','启用固定纵向构图','checkbox');input('baseY','纵向镜头基准 Y');input('minY','最低镜头 Y');input('riseTop','角色上移跟随阈值');input('barrier','拆除指定实体后开放横向滚屏','checkbox');input('right','封闭阶段右侧画面边界');input('ids','须全部拆除的地形 ID（逗号分隔）','text');
 const help=document.createElement('p');help.className='small';help.textContent='只限制镜头。实体必须真实拆除后才释放；不会改变角色活动范围或自动开路。镜头参数为作者拟定。';root.append(help);
 const apply=document.createElement('button');apply.type='button';apply.textContent='应用镜头设置';root.append(apply);apply.onclick=()=>{try{const spec=controls.get('enabled').checked?{baseY:Number(controls.get('baseY').value),minY:Number(controls.get('minY').value),riseTop:Number(controls.get('riseTop').value),...(controls.get('barrier').checked?{horizontalBarrier:{right:Number(controls.get('right').value),releaseWhenRemovedGeometryIds:controls.get('ids').value.split(',').map(s=>s.trim()).filter(Boolean)}}:{})}:null;change(()=>setSmm2CameraFrame(room(),spec));refresh();report('镜头设置已保存');}catch(e){report(e.message);refresh();}};
 function refresh(){const r=room(),q=r.smm2Mechanics?.camera;controls.get('enabled').checked=!!q;for(const k of ['baseY','minY','riseTop'])controls.get(k).value=q?.[k]??(k==='baseY'?Math.max(0,r.map.height-(r.playRules?.viewportHeight??216)):0);controls.get('barrier').checked=!!q?.horizontalBarrier;controls.get('right').value=q?.horizontalBarrier?.right??Math.min(r.map.width,r.playRules?.viewportWidth??384);controls.get('ids').value=q?.horizontalBarrier?.releaseWhenRemovedGeometryIds.join(', ')??'';}
 refresh();return {refresh};
}
