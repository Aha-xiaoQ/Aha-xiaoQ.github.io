import {paintMinecraftEnchantmentGlint} from './editor-minecraft-enchantment-art.mjs';
import {drawGrottoTile,drawGrottoScenery,drawGrottoWorld} from './editor-minecraft-grotto-art.mjs';
import {drawFinaleBackground,drawFinaleScenery,drawFinaleWorld,drawFinaleTile,paintMinecraftVoxelRelief,minecraftVoxelFacePlan} from './editor-minecraft-finale-art.mjs';
/** Original, programmatically drawn pixel artwork for the Minecraft adventure.
 * No Minecraft textures are bundled or sampled. Physics and Mario's retained
 * sprite/motor stay with their existing owners; this module only paints.
 * All coordinates are world pixels. Scenery y is its ground/bottom anchor,
 * except a torch, whose y marks the flame. Textures never use random/time state.
 */
export {minecraftVoxelFacePlan};
export const isMinecraftRoom=room=>room?.minecraft?.version===1;
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
const hash=(x,y,s=0)=>{let n=Math.imul(x|0,374761393)^Math.imul(y|0,668265263)^Math.imul(s|0,982451653);n=Math.imul(n^(n>>>13),1274126177);return(n^(n>>>16))>>>0;};
const rr=(c,color,x,y,w,h)=>{if(w>0&&h>0){c.fillStyle=color;c.fillRect(Math.round(x),Math.round(y),Math.ceil(w),Math.ceil(h));}};
const bounds=room=>room.renderBounds||{x:0,y:0,w:room.map?.width||384,h:room.map?.height||240};
const floorY=room=>room.minecraft?.groundY??room.map?.geometry?.find(q=>q.x===0&&q.w>=128&&q.y>0)?.y??(room.map?.height||240)-32;
const tickOf=room=>Number.isFinite(room.tick)?room.tick:0;
const explorationOf=room=>room.minecraftView?.exploration||{};
const stormOf=(room,view=room.minecraftView)=>{const state=view?.minecraft||view||{};return isMinecraftRoom(room)&&room.minecraft.biome==='forest'&&room.roomId!=='burrow'?(state.storm??(room.minecraft.storm?.thunderstorm?{active:true,age:tickOf(room)}:null)):null;};
const tilePalettes={
 dirt:['#785139','#67432f','#886044','#5b3e2d','#93694b'],
 stone:['#707878','#616a6b','#818987','#515b5e','#8e9590'],
 sand:['#d8be79','#bda364','#ead295','#cdb16c','#f4dc9b'],
 obsidian:['#282036','#171826','#342440','#44304d','#211c31'],
 nether:['#673232','#4c262c','#80413b','#9a5146','#592b31'],
 wood:['#916233','#6d4728','#ac7a42','#78512d','#bf8d4e'],
 planks:['#b48c50','#9b703e','#c7a361','#78572f','#d1ad6c'],
 brick:['#756c63','#625b55','#9a8a73','#544e49','#a89b84']
};
const textureCache=new Map();
function pixelCanvas(w,h){
 if(typeof OffscreenCanvas==='function')return new OffscreenCanvas(w,h);
 if(typeof document!=='undefined'&&typeof document.createElement==='function'){const surface=document.createElement('canvas');surface.width=w;surface.height=h;return surface;}return null;
}
function texture(c,kind,x,y,w=16,h=16,seed=0){
 const variant=(seed>>>0)%32,key=kind+':'+w+':'+h+':'+variant;
 let image=textureCache.get(key);if(!image){image=pixelCanvas(w,h);if(image){paintTexture(image.getContext('2d'),kind,0,0,w,h,variant);textureCache.set(key,image);}}
 if(image){c.drawImage(image,Math.round(x),Math.round(y));return;}
 paintTexture(c,kind,x,y,w,h,variant);
}
/** Material-scale clusters replace generic high-frequency noise. Natural rock has
 * broken mineral patches, never the continuous mortar lines used by masonry.
 * Stamps are tile-local, so cached and direct rendering are pixel-identical. */
function paintTexture(c,kind,x,y,w,h,seed){
 let pal=tilePalettes[kind]||tilePalettes.stone;
 if(kind==='stone')pal=seed%5===0?['#737c79','#67716f','#818987','#596562','#90958b']:['#707a7c','#616d70','#7e8888','#526165','#909896'];
 const stamp=(color,px,py,pw,ph)=>{const left=Math.max(0,px),top=Math.max(0,py),right=Math.min(w,px+pw),bottom=Math.min(h,py+ph);rr(c,color,x+left,y+top,right-left,bottom-top);};
 rr(c,pal[0],x,y,w,h);
 if(kind==='wood'){
  // Oak bark follows the trunk. Narrow, staggered furrows and short branch
  // knots remain vertical, unlike the deliberate horizontal plank boards.
  for(let px=-1;px<w;px+=4){const n=hash(px,seed,9),offset=n%3;stamp(pal[1],px+offset,0,1+(n%2),h);stamp(pal[2],px+offset-1,2+n%4,1,h-4);for(let py=1;py<h;py+=7){const k=hash(px,py,seed);stamp(k%2?pal[3]:pal[2],px+offset+1,py+k%3,2,3+k%3);}}
  if(seed%3===0&&w>8&&h>8){const kx=3+seed%Math.max(1,w-7),ky=3+seed%Math.max(1,h-7);stamp(pal[1],kx,ky,4,5);stamp(pal[3],kx+1,ky+1,3,3);stamp(pal[2],kx+1,ky+1,1,2);stamp(pal[1],kx+2,ky+2,1,1);}
  return;
 }
 if(kind==='planks'){
  for(let py=0;py<h;py+=8){stamp(seed%2?pal[0]:pal[2],0,py,w,7);stamp(pal[1],0,py+7,w,1);stamp(pal[4],0,py,w,1);const join=(Math.floor(py/8)+seed)%2?11:3;stamp(pal[3],join,py+1,1,6);for(let n=0;n<3;n++){const k=hash(n,py,seed);stamp(n%2?pal[1]:pal[2],k%Math.max(1,w-3),py+2+k%4,3+(k>>>5)%5,1);}}
  return;
 }
 if(kind==='sand'){
  rr(c,'#d8c084',x,y,w,h);for(let py=1;py<h;py+=4)for(let px=0;px<w;px+=5){const n=hash(px,py,seed);stamp(n%3?'#e3cc95':'#c5ac73',px+n%3,py,2+n%3,1);if(n%4===0)stamp('#b7a071',px+2,py+2,1,1);}return;
 }
 if(kind==='obsidian'){
  for(let py=0;py<h;py+=5)for(let px=-2;px<w;px+=6){const n=hash(px,py,seed),dx=px+n%3;stamp(n%2?'#211b31':'#342640',dx,py,5,4);stamp('#171623',dx+1,py+3,4,2);if(n%3===0){stamp('#563966',dx+1,py,3,1);stamp('#432c52',dx+4,py+1,1,2);}}
  return;
 }
 if(kind==='nether'){
  for(let py=-1;py<h;py+=4)for(let px=-2;px<w;px+=5){const n=hash(px,py,seed),dx=px+n%3,dy=py+(n>>>4)%2;stamp(n%3?'#51282d':'#823e38',dx,dy,4,3);stamp(n%3?'#73372f':'#a25345',dx+1,dy+2,3,2);stamp('#49252c',dx+3,dy,2,2);if(n%5===0)stamp('#be6c50',dx+1,dy+2,1,1);}
  return;
 }
 // Coarse two-to-six-pixel islands read as minerals/soil at the real camera.
 for(let py=-2;py<h;py+=4)for(let px=-2;px<w;px+=5){const n=hash(px,py,seed),dx=px+n%3,dy=py+(n>>>4)%3;if(n%6===0)continue;
  const rock=kind==='stone',dark=n%3===0;stamp(pal[dark?1:2],dx,dy,3+(n>>>7)%3,2+(n>>>10)%2);stamp(pal[dark?1:2],dx+1,dy-1,2,1);
  if(n%4===0)stamp(pal[dark?3:0],dx+1,dy+2,3,1);if(rock&&n%5===0)stamp(pal[4],dx+1,dy,2,1);
 }
 if(kind==='dirt')for(let i=0;i<7;i++){const n=hash(i,seed,51),px=n%w,py=(n>>>8)%h;stamp(i%3?'#a27c53':'#514333',px,py,1+(i%2),1);if(i%3===0)stamp('#8b7254',px,py-1,1,1);}
}
function grassTop(c,x,y,w,seed){
 rr(c,'#41642c',x,y,w,5);rr(c,'#609033',x,y,w,3);rr(c,'#8eb345',x,y,w,1);
 for(let px=0;px<w;px+=3){const n=hash(x+px,y,seed),depth=2+n%4;rr(c,n%2?'#4c7b30':'#75a33d',x+px,y+1,Math.min(3,w-px),depth);if(n%3===0){rr(c,'#476a2c',x+px+1,y+depth+1,1,2);rr(c,'#b2c766',x+px,y,1,1);}}
}
function ore(c,x,y,type,seed){
 const p=type==='emerald'?['#1e5843','#35af6a','#95e896']:type==='gold'?['#604d24','#cf9f30','#f9d856']:type==='redstone'?['#692d34','#c64c4b','#ff8070']:type==='diamond'?['#2e6f72','#4fc3c3','#a3ece0']:type==='coal'?['#394143','#252e32','#555e60']:['#736057','#ad8e76','#dec3a2'];
 for(const [a,b] of [[3,3],[10,5],[5,11],[12,12]]){let dx=hash(a,seed)%2,dy=hash(b,seed)%2;rr(c,p[0],x+a-1+dx,y+b+dy,4,3);rr(c,p[1],x+a+dx,y+b+dy,3,2);rr(c,p[2],x+a+dx,y+b+dy,1,1);}
}
/** Return true only for explicit Minecraft ID/material tags within this room. */
export function drawMinecraftTile(c,q,room={}){
 // The bottom of the authored world is a camera boundary, not an exposed
 // block face. Continue its strata in render space without editing a collider.
 const rv=room.renderBounds,mh=room.map?.height;
 if(isMinecraftRoom(room)&&rv&&q.collision==='solid'&&!q.motion&&Math.abs(q.y+q.h-mh)<.01&&rv.y+rv.h>mh)q={...q,h:rv.y+rv.h-q.y};
 if(drawGrottoTile(c,q,room)||drawFinaleTile(c,q,room))return true;
 if(!isMinecraftRoom(room))return false;
 const id=String(q.sourceId||q.id||'');
 if(id===room.minecraft.exploration?.cart?.geometryId)return true;
 if(id===room.minecraft.exploration?.redstone?.bridgeId){drawRedstoneBridge(c,q,room);return true;}
 const match=id.match(/^mc-(grass|dirt|stone|sand|ore|obsidian|nether|wood|planks|brick|lava|glowstone|leaf)(?:-|$)/);
 if(!match)return false;if(q.hidden||q.removed||q.visible===false)return true;
 const kind=match[1],v=bounds(room),seed=hash(id.length,id.charCodeAt(id.length-1)||0),x=Math.round(q.x),y=Math.round(q.y),w=Math.round(q.w),h=Math.round(q.h);
 c.save();c.beginPath();c.rect(x,y,w,h);c.clip();
 const ix=Math.max(0,Math.floor((v.x-x)/16)),iy=Math.max(0,Math.floor((v.y-y)/16));
 for(let ty=iy;ty*16<h&&y+ty*16<v.y+v.h;ty++)for(let tx=ix;tx*16<w&&x+tx*16<v.x+v.w;tx++){
  const px=x+tx*16,py=y+ty*16,ts=seed+tx*13+ty*31;
  if(id==='mc-ore-burrowgift'){giftChest(c,px,py,q.mcOreUsed||explorationOf(room).ores?.some(o=>o.id===id&&o.used));continue;}
  if(kind==='leaf'){leafBlock(c,px,py,16,16,['#477238','#73954b','#31582f','#60823b'],ts);continue;}
  if(kind==='lava'){drawLavaTile(c,px,py,tickOf(room),ts);continue;}
  if(kind==='glowstone'){texture(c,'sand',px,py,16,16,ts);for(let i=0;i<8;i++){const hx=hash(i,ts)%13,hy=hash(ts,i)%13;rr(c,i%3?'#fff3ac':'#ffd269',px+hx,py+hy,3,3);}continue;}
  texture(c,kind==='grass'?'dirt':kind==='ore'?'stone':kind,px,py,16,16,ts);
  if(kind==='grass'&&ty===0){grassTop(c,px,py,16,ts);for(let n=0;n<3;n++){const rx=hash(n,ts)%15;rr(c,'#665439',px+rx,py+5,1,3+hash(ts,n)%4);}}
  if(kind==='nether'&&ty===0){rr(c,'#ac6354',px,py,16,1);rr(c,'#c47a61',px+2,py,3,1);rr(c,'#4c282e',px+15,py+1,1,15);}
  if(kind==='wood'&&id.includes('stump')&&ty===0){rr(c,'#c39b5b',px,py,16,3);rr(c,'#6b482b',px+3,py+1,9,1);}
  if(kind==='planks'&&ty===0){rr(c,'#d6b978',px,py,16,2);rr(c,'#654d30',px,py+Math.min(14,h-1),16,1);}
  if(kind==='ore'){const used=q.mcOreUsed||explorationOf(room).ores?.some(o=>o.id===id&&o.used);if(used){rr(c,'#3c5152',px+3,py+4,9,7);rr(c,'#263c40',px+4,py+4,7,5);rr(c,'#81918b',px+3,py+12,9,1);rr(c,'#4a9b77',px+5,py+9,2,1);}else ore(c,px,py,/emerald|diamond|gold|coal|redstone|iron/.exec(id)?.[0]||(id.includes('reward')?'emerald':'iron'),ts);}
  if(kind==='stone'&&room.minecraft.biome==='cave'&&ty>0){const n=hash(Math.floor(px/16),Math.floor(py/16),13);if(n%17===0||n%23===0)ore(c,px,py,n%3===0?'gold':n%2?'iron':'coal',ts);}
  if(kind==='stone'&&room.minecraft.destructibleIds?.includes(q.sourceId||q.id)){for(const [cx,cy,cw,ch] of [[6,0,1,5],[5,4,2,2],[7,5,1,3],[8,7,3,1],[10,7,1,5],[9,11,1,3],[8,13,1,3],[4,5,1,2],[2,6,2,1]])rr(c,'#303a3b',px+cx,py+cy,cw,ch);}
  // Natural stone has no per-block mortar grid. Only exposed collision
  // boundaries receive the existing voxel-relief top/right/bottom planes.
  if(kind==='sand'){rr(c,'#ead49b',px,py,16,1);rr(c,'#b39b61',px+15,py,1,16);rr(c,'#c0a56a',px,py+15,16,1);}
  if(kind==='obsidian'){rr(c,'#100f1c',px+15,py,1,16);rr(c,'#4a335c',px,py,16,1);rr(c,'#644477',px+2,py+2,4,1);}
  if(kind==='brick'){for(let by=0;by<16;by+=8){rr(c,'#4f4b47',px,py+by+7,16,1);rr(c,'#494540',px+(by?8:0),py+by,1,7);rr(c,'#aa9981',px+1,py+by,14,1);}}
 }
 if(!['lava','leaf','glowstone'].includes(kind)&&id!=='mc-ore-burrowgift')paintMinecraftVoxelRelief(c,q,room,kind==='grass'?['#567f34','#4f382a','#81a94d','#3d5e2c','#b2c76a']:tilePalettes[kind==='ore'?'stone':kind]);
 c.restore();return true;
}
function giftChest(c,x,y,used=false){
 rr(c,'#4d3426',x,y+2,16,14);rr(c,'#a77635',x+1,y+3,14,12);rr(c,'#cea15b',x+2,y+4,12,2);rr(c,'#6c482b',x+2,y+7,12,1);rr(c,'#68482d',x+1,y+13,14,2);
 for(const dx of [2,12]){rr(c,'#e1c68a',x+dx,y+3,2,11);rr(c,'#816b46',x+dx,y+12,2,2);}
 if(used){rr(c,'#4b3328',x,y,16,4);rr(c,'#c19550',x+1,y+1,14,2);rr(c,'#2e3026',x+2,y+4,12,4);rr(c,'#edce81',x+7,y+9,2,3);}else{rr(c,'#59452f',x,y+8,16,2);rr(c,'#f4d898',x+6,y+7,4,5);rr(c,'#80613b',x+7,y+9,2,2);}
}
function drawLavaTile(c,x,y,tick,seed=0){
 rr(c,'#dd4d14',x,y,16,16);for(let py=0;py<16;py+=2)for(let px=0;px<16;px+=2){const n=hash(px+Math.floor(tick/9)%7,py,seed);rr(c,['#f66b18','#fd9b20','#ffc446','#a83013'][n%4],x+px,y+py,2+(n%3),2);}rr(c,'#ffe175',x,y,16,1);
}
export function drawMinecraftBackground(c,room,w,h){
 if(drawFinaleBackground(c,room,w,h))return true;
 if(!isMinecraftRoom(room))return false;
 const biome=room.minecraft.biome||'forest';
 const colors=stormOf(room)?.active?['#202d43','#34465b','#4a6270','#708784']:biome==='forest'?['#5a9fb7','#71afbf','#96c5c2','#c4d9bd']:biome==='nether'?['#200e20','#3a1729','#58232c','#83332c']:['#18262f','#20323b','#2b4047','#3b5054'];
 for(let i=0;i<colors.length;i++)rr(c,colors[i],0,Math.floor(h*i/colors.length),w,Math.ceil(h/colors.length));
 return true;
}
// Cuboid foliage uses a five-pixel top plane and a shaded right face. The
// silhouette is blocky, but the three light values read as volume at 2× scale.
function leafBlock(c,x,y,w,h,palette,seed=0){
 const d=Math.max(3,Math.min(7,Math.floor(Math.min(w,h)/4)));
 rr(c,palette[0],x,y+d,w-d,h-d);rr(c,palette[2],x+w-d,y+d,d,h-d);
 for(let row=0;row<d;row++){rr(c,palette[1],x+d-row,y+row,w-d,row===d-1?2:1);rr(c,palette[2],x+w-row-1,y+row,row+1,1);}
 rr(c,palette[1],x,y+d,w-d,1);rr(c,palette[3],x+1,y+d+1,1,h-d-2);rr(c,palette[2],x,y+h-2,w-d,2);
 for(let py=d+2;py<h-3;py+=4)for(let px=2;px<w-d-3;px+=5){const n=hash(px,py,seed),dx=px+n%2,dy=py+(n>>>4)%2;if(n%5===0)continue;rr(c,palette[n%3===0?2:3],x+dx,y+dy,3,2);rr(c,palette[n%3===0?2:0],x+dx+1,y+dy+2,2,1);if(n%4===0)rr(c,palette[1],x+dx,y+dy,2,1);}
 for(let px=d+3;px<w-4;px+=5){const n=hash(px,seed,19);rr(c,palette[n%3?3:0],x+px,y+1+n%2,3,1);}
 for(let py=d+4;py<h-3;py+=5){rr(c,palette[0],x+w-d+1,y+py,2,2);rr(c,palette[3],x+w-d+1,y+py,1,1);}
}
// These darker structures live in the rear world plane. They are deliberately
// not terrain: the authored solids alone define Mario's collision surfaces.
function pixelBeam(c,x1,y1,x2,y2,width=4,color='#65543a'){
 const steps=Math.max(1,Math.ceil(Math.max(Math.abs(x2-x1),Math.abs(y2-y1))/2));
 for(let i=0;i<=steps;i++){const t=i/steps;rr(c,color,x1+(x2-x1)*t-width/2,y1+(y2-y1)*t-width/2,width,width);}
}
const roomGeometry=room=>room.map?.geometry||[];
function localGround(room,x,minY=0){
 const matches=roomGeometry(room).filter(g=>!g.hidden&&!g.removed&&g.visible!==false&&g.x<=x&&g.x+g.w>x&&g.y>=minY&&g.h>=24&&!/roof|seal/.test(g.id||''));
 return matches.length?Math.min(...matches.map(g=>g.y)):null;
}
function ceilingBottom(room,x,maxY){
 const matches=roomGeometry(room).filter(g=>g.y===0&&g.x<=x&&g.x+g.w>x&&g.y+g.h<maxY);
 return matches.length?Math.max(...matches.map(g=>g.y+g.h)):32;
}
function timber(c,x,y,w,h,{rear=true}={}){
 if(h<=0||w<=0)return;rr(c,rear?'#3e4138':'#57442f',x-1,y,w+2,h);rr(c,rear?'#625a43':'#876039',x,y,w,h);rr(c,rear?'#867955':'#bd9256',x+1,y,1,h);rr(c,rear?'#494937':'#68482d',x+w-2,y,2,h);
 for(let n=12;n<h;n+=20){rr(c,'#393f35',x,y+n,w,2);rr(c,'#a69c72',x+2,y+n,1,1);}
}
function fixing(c,x,y){rr(c,'#303d38',x-2,y-2,5,5);rr(c,'#9da58c',x-1,y-1,3,3);rr(c,'#d4cfaa',x,y,1,1);}
/** Read-only plan used both by the painter and structural regression tests. */
export function minecraftSupportPlan(room={}){
 const cart=room.minecraft?.exploration?.cart,source=cart&&roomGeometry(room).find(q=>q.id===cart.geometryId),piers=[];
 if(source){const left=Math.min(source.x,cart.endX),right=Math.max(source.x,cart.endX)+source.w,top=source.y+source.h+5,positions=new Set([left+8,right-8]);for(let x=left+8;x<right-8;x+=64)positions.add(x);
  for(const x of [...positions].sort((a,b)=>a-b)){const ground=localGround(room,x,top);if(ground!=null)piers.push({x,top,ground});}
 }
 const hanging=roomGeometry(room).filter(q=>q.id==='mc-wood-cart-bonus').map(q=>({id:q.id,x:q.x,y:q.y,w:q.w,h:q.h,ceiling:ceilingBottom(room,q.x+q.w/2,q.y)}));
 return {piers,hanging};
}
function railTrestle(c,room,source,left,right,y){
 const plan=minecraftSupportPlan(room),piers=plan.piers;
 // Stringer, sleepers and bolted bents form one continuous bridge. A pit has
 // no invented foundation: the cross-braced span reaches the next real bank.
 timber(c,left,y+3,right-left,5);rr(c,'#929077',left,y+3,right-left,1);
 for(const p of piers){timber(c,p.x-4,p.top,8,p.ground-p.top+2);rr(c,'#424d47',p.x-8,p.ground-4,16,6);rr(c,'#727967',p.x-7,p.ground-4,14,1);fixing(c,p.x,p.top+3);}
 for(let i=1;i<piers.length;i++){const a=piers[i-1],b=piers[i],bottom=Math.min(a.ground,b.ground)-7;if(bottom>a.top+9){pixelBeam(c,a.x,a.top+6,b.x,bottom,4,'#5c5842');pixelBeam(c,a.x,bottom,b.x,b.top+6,4,'#5c5842');fixing(c,(a.x+b.x)/2,(a.top+6+bottom)/2);}}
 for(const x of [left,right-2]){timber(c,x-2,y-13,5,17);rr(c,'#adb099',x-4,y-13,10,3);}
}
function mineralAssembly(c,room){
 const ores=(room.minecraft.exploration?.ores||[]).map(o=>roomGeometry(room).find(g=>g.id===o.id)).filter(q=>q&&q.id!=='mc-ore-burrowgift');if(ores.length<2)return null;
 const x=Math.min(...ores.map(q=>q.x))-16,right=Math.max(...ores.map(q=>q.x+q.w))+16,top=Math.min(...ores.map(q=>q.y)),ceiling=ceilingBottom(room,x,top);
 // Cut mineral face remains part of the rock ceiling. Foreground ore blocks
 // sit inside this recess; dark backing never suggests another walkable ledge.
 rr(c,'#283d43',x-7,ceiling,right-x+14,top+20-ceiling);rr(c,'#374e52',x-3,ceiling,right-x+6,top+18-ceiling);
 for(let yy=ceiling;yy<top+16;yy+=16){rr(c,'#42595b',x+1,yy,right-x-2,1);for(let xx=x+(yy%32?9:25);xx<right;xx+=32)rr(c,'#293e45',xx,yy,1,16);}
 // Heavy timbers clamp the exposed mineral strip, visibly joined to ceiling.
 for(const px of [x+1,right-9]){timber(c,px,ceiling,8,top+17-ceiling);rr(c,'#788078',px-3,ceiling,14,5);fixing(c,px+4,ceiling+2);}
 timber(c,x-4,top-8,right-x+8,8);rr(c,'#8e8059',x-4,top-8,right-x+8,1);
 for(const q of ores){rr(c,'#182f36',q.x-3,q.y-2,q.w+6,q.h+4);rr(c,'#74837a',q.x-2,q.y-1,q.w+4,1);}
 return {x,right,top,ceiling};
}
function suspendedShelf(c,room,q){
 const ceiling=ceilingBottom(room,q.x+q.w/2,q.y),bottom=q.y+q.h;
 for(const x of [q.x+4,q.x+q.w-12]){timber(c,x,ceiling,8,bottom-ceiling);rr(c,'#788078',x-3,ceiling-1,14,5);fixing(c,x+4,ceiling+2);fixing(c,x+4,bottom-4);}
 pixelBeam(c,q.x+8,q.y-28,q.x+28,q.y-2,4,'#6d6247');pixelBeam(c,q.x+q.w-8,q.y-28,q.x+q.w-28,q.y-2,4,'#6d6247');timber(c,q.x-3,bottom-2,q.w+6,5);rr(c,'#91815a',q.x-3,bottom-2,q.w+6,1);
}
function geologicalMount(c,room,q){
 const ceiling=ceilingBottom(room,q.x+q.w/2,q.y),x=q.x-7,w=q.w+14;
 rr(c,'#2c4148',x-6,ceiling,w+12,q.y+q.h+12-ceiling);
 for(let y=ceiling;y<q.y+q.h+6;y+=16){const n=hash(y,q.x);rr(c,'#3b5356',x+(n%3),y,w-3,16);rr(c,'#4c6262',x+2,y,w-5,1);rr(c,'#30474d',x+7+(Math.floor(y/16)%2)*18,y+1,1,15);}
 for(let n=0;n<4;n++){const yy=q.y+q.h+n*6;rr(c,'#344b50',x+6+n*5,yy,w-12-n*10,6);rr(c,'#435b5c',x+7+n*5,yy,w-14-n*10,1);}
}
function burrowMounts(c,room){
 const shelf=roomGeometry(room).find(q=>q.id==='mc-wood-burrow-ledge'),chest=roomGeometry(room).find(q=>q.id==='mc-ore-burrowgift');
 if(shelf){const ceiling=ceilingBottom(room,shelf.x,shelf.y);for(const x of [shelf.x+4,shelf.x+shelf.w-11]){timber(c,x,ceiling,7,shelf.y+shelf.h+32-ceiling);pixelBeam(c,x+3,shelf.y+shelf.h+29,x+(x<shelf.x+20?25:-19),shelf.y+shelf.h+1,5,'#665936');fixing(c,x+3,shelf.y+shelf.h+2);}timber(c,shelf.x-3,shelf.y+shelf.h-2,shelf.w+6,4);}
 if(chest){const x=chest.x,y=chest.y,ceiling=ceilingBottom(room,x,y);timber(c,x-15,ceiling,7,y+12-ceiling);pixelBeam(c,x-11,y+10,x+1,y+7,5,'#756039');rr(c,'#493d2b',x-5,y-3,chest.w+10,chest.h+4);rr(c,'#99804e',x-4,y-3,chest.w+8,2);fixing(c,x-3,y+8);fixing(c,x+chest.w+2,y+8);}
}
function forestJoinery(c,room){
 const geometry=roomGeometry(room),branch=geometry.find(q=>q.id===room.minecraft.exploration?.appleTree?.branchId),ledge=geometry.find(q=>q.id==='mc-planks-secret-ledge'||q.id==='mc-stone-secret-ledge');
 if(branch){const treeSpec=(room.minecraft.scenery||[]).filter(q=>['oak','birch'].includes(q.kind)).sort((a,b)=>Math.abs(a.x+39.6*(a.scale||1)-branch.x)-Math.abs(b.x+39.6*(b.scale||1)-branch.x))[0];if(treeSpec){const sx=(treeSpec.scale||1)*1.65,trunk=treeSpec.x+24*sx;pixelBeam(c,trunk,branch.y+9,branch.x+12,branch.y+9,9,'#79552f');pixelBeam(c,trunk,branch.y+31,branch.x+12,branch.y+11,6,'#79552f');rr(c,'#b58a49',trunk,branch.y+5,branch.x+12-trunk,2);const root=geometry.find(q=>q.id==='mc-wood-root');if(root){pixelBeam(c,branch.x+16,branch.y+branch.h-1,root.x+root.w/2,root.y+5,7,'#654a2e');pixelBeam(c,root.x+root.w/2,root.y+root.h-4,trunk,treeSpec.y-2,6,'#755431');}}}
 if(ledge){const host=(room.minecraft.scenery||[]).filter(q=>['oak','birch'].includes(q.kind)).sort((a,b)=>Math.abs(a.x+39.6*(a.scale||1)-(ledge.x+ledge.w/2))-Math.abs(b.x+39.6*(b.scale||1)-(ledge.x+ledge.w/2)))[0],x=host?host.x+39.6*(host.scale||1):ledge.x+ledge.w/2,ground=localGround(room,x,ledge.y+ledge.h)??240;timber(c,x-6,ledge.y-23,12,ground-ledge.y+23,{rear:false});pixelBeam(c,x,ledge.y+42,ledge.x+5,ledge.y+ledge.h,5,'#6c502f');pixelBeam(c,x,ledge.y+42,ledge.x+ledge.w-5,ledge.y+ledge.h,5,'#6c502f');rr(c,'#493d2c',ledge.x-3,ledge.y+ledge.h-3,ledge.w+6,5);for(const xx of [ledge.x+5,ledge.x+ledge.w-7])fixing(c,xx,ledge.y+ledge.h-1);pixelBeam(c,x-3,ground-7,x-14,ground,5,'#664d2f');pixelBeam(c,x+3,ground-7,x+15,ground,5,'#664d2f');}
}
function portalFooting(c,room,q){
 const ground=localGround(room,q.x+(q.w||48)/2,q.y)??q.y,w=q.w||48;
 if(ground>q.y){rr(c,'#3b4142',q.x-4,q.y,w+8,ground-q.y);for(let y=q.y;y<ground;y+=8)rr(c,'#676862',q.x-3,y,w+6,1);}
 rr(c,'#555557',q.x-5,q.y-4,w+10,4);rr(c,'#999085',q.x-4,q.y-4,w+8,1);rr(c,'#302e3d',q.x-5,q.y-1,w+10,1);
 for(const px of [q.x-4,q.x+w-2]){rr(c,'#46414e',px,q.y-12,6,12);rr(c,'#70616c',px,q.y-12,6,1);}
}
function torchMount(c,room,q){
 const x=q.x,y=q.y,s=q.scale||1,forest=room.minecraft.biome==='forest',base=y+16*s;
 if(forest){const ground=localGround(room,x,base);if(ground!=null){timber(c,x-2,base-3,5,ground-base+5,{rear:false});rr(c,'#535241',x-5,ground-3,11,4);return;}}
 // Forged sconce: the plate bolts to the rock wall, and a bracket reaches the
 // torch handle. Mine lights are additionally wired into the rock lintel.
 rr(c,'#28363a',x-5,y+7*s,11,15*s);rr(c,'#66716b',x-4,y+8*s,9,13*s);rr(c,'#899183',x-3,y+9*s,1,10*s);fixing(c,x,y+10*s);pixelBeam(c,x,y+19*s,x+4,y+14*s,3,'#a79b72');
 if(q.variant==='mine-light'){const ores=(room.minecraft.exploration?.ores||[]).map(o=>roomGeometry(room).find(g=>g.id===o.id)).filter(Boolean);if(ores.length){const top=Math.min(...ores.map(g=>g.y))-8;timber(c,x+4,Math.min(base,top),3,Math.abs(top-base)+2);}}
}
function structureScenery(c,room){
 if(room.roomId==='burrow')burrowMounts(c,room);else if(room.minecraft.biome==='forest')forestJoinery(c,room);else{
  for(const q of roomGeometry(room)){if(q.id==='mc-wood-cart-bonus')suspendedShelf(c,room,q);if(q.id==='mc-ore-emerald'||q.id==='mc-stone-secret')geologicalMount(c,room,q);}
  mineralAssembly(c,room);redstoneCircuit(c,room);
 }
}
function conduit(c,points,powered=false,tick=0){
 for(let i=1;i<points.length;i++){const [ax,ay]=points[i-1],[bx,by]=points[i];pixelBeam(c,ax,ay,bx,by,6,'#25363a');pixelBeam(c,ax,ay,bx,by,4,'#747568');pixelBeam(c,ax,ay,bx,by,2,powered?'#e97847':'#743c36');
  const length=Math.abs(bx-ax)+Math.abs(by-ay);for(let d=0;d<=length;d+=32){const t=length?d/length:0,x=ax+(bx-ax)*t,y=ay+(by-ay)*t;rr(c,'#3c4b45',x-2,y-3,4,6);rr(c,powered?'#e29a62':'#9b8971',x-1,y-1,2,2);}if(powered&&length){const d=(tick*.8+i*11)%length,t=d/length;rr(c,'#ffe4a1',ax+(bx-ax)*t-1,ay+(by-ay)*t-1,3,3);}}
}
function redstoneCircuit(c,room){
 const spec=room.minecraft.exploration?.redstone,cartSpec=room.minecraft.exploration?.cart;if(!spec||!cartSpec)return;
 const state=explorationOf(room),red=state.redstone||{},cart=roomGeometry(room).find(g=>g.id===cartSpec.geometryId),bridge=roomGeometry(room).find(g=>g.id===spec.bridgeId);if(!cart||!bridge)return;
 const x=cartSpec.endX+cart.w+8,y=cart.y+cart.h-8,ores=(room.minecraft.exploration?.ores||[]).map(o=>roomGeometry(room).find(g=>g.id===o.id)).filter(Boolean);if(!ores.length)return;
 const oreLeft=Math.min(...ores.map(g=>g.x)),oreRight=Math.max(...ores.map(g=>g.x+g.w)),oreTop=Math.min(...ores.map(g=>g.y)),roof=ceilingBottom(room,x,oreTop),wireY=roof+14,delivered=!!red.cartDelivered;
 // A physical buffer and battery socket terminate the cart track. Conduit
 // rises to the ceiling, avoiding arbitrary red lines crossing the play path.
 const ground=localGround(room,x,y+18)??localGround(room,x-12,y+18);if(ground!=null)timber(c,x-4,y+9,8,ground-y-8);
 rr(c,'#263b3d',x-10,y-13,20,25);rr(c,'#6e7264',x-9,y-12,18,23);rr(c,'#292f30',x-6,y-9,12,15);rr(c,delivered?'#e27b4d':'#503d35',x-4,y-7,8,11);rr(c,delivered?'#ffe1a1':'#8d765a',x-2,y-5,4,4);rr(c,'#b6b192',x-12,y+6,24,3);
 conduit(c,[[x,y-13],[x,wireY],[oreLeft-8,wireY],[oreLeft-8,oreTop-16],[oreRight+12,oreTop-16]],delivered,tickOf(room));
 const used=state.ores||[];for(const q of ores){const active=!!used.find(o=>o.id===q.id&&o.used);conduit(c,[[q.x+q.w/2,oreTop-16],[q.x+q.w/2,q.y-1]],active,tickOf(room));rr(c,active?'#ffe49a':'#784e3c',q.x+q.w/2-2,oreTop-20,5,5);}
 const active=red.state==='extending'||red.state==='extended'||(red.required>0&&red.charge>=red.required&&delivered);conduit(c,[[oreRight+12,oreTop-16],[bridge.x-12,oreTop-16],[bridge.x-12,bridge.y+17],[bridge.x+9,bridge.y+17]],active,tickOf(room));
 // The extending deck brings its own triangular underside truss. Its far
 // bearing is a recessed pier planted on the authored receiving bank.
 const liveBridge=red.bridge||bridge,extent=Math.max(bridge.w,liveBridge.w||bridge.w),deckBottom=bridge.y+bridge.h,lower=deckBottom+12;
 timber(c,bridge.x,lower,extent,3);for(let dx=0;dx<extent;dx+=32){const end=Math.min(extent,dx+32);pixelBeam(c,bridge.x+dx,deckBottom,bridge.x+end,lower,3,'#586251');pixelBeam(c,bridge.x+dx,lower,bridge.x+end,deckBottom,3,'#586251');}
 const bearingX=bridge.x+spec.extendedWidth-8,bearingGround=localGround(room,bearingX,deckBottom);if(bearingGround!=null){timber(c,bearingX-4,deckBottom,8,bearingGround-deckBottom+2);rr(c,'#5c6c61',bearingX-7,deckBottom,14,4);rr(c,'#86917b',bearingX-7,deckBottom,14,1);rr(c,'#46554e',bearingX-8,bearingGround-4,16,6);}
 // Piston anchor is built into the actual upper cliff, behind its live deck.
 rr(c,'#263b3e',bridge.x-17,bridge.y-5,33,33);rr(c,'#777966',bridge.x-15,bridge.y-3,28,29);rr(c,'#343f3d',bridge.x-11,bridge.y+3,24,17);for(let i=0;i<3;i++)rr(c,'#a8aa8a',bridge.x-9+i*6,bridge.y+5,3,13);fixing(c,bridge.x-12,bridge.y-1);fixing(c,bridge.x-12,bridge.y+22);
}
function drawRedstoneBridge(c,q,room){
 if(q.hidden||q.removed||q.visible===false)return;const state=explorationOf(room).redstone||{},active=state.state==='extended'||state.state==='extending';
 c.save();c.beginPath();c.rect(q.x,q.y,q.w,q.h);c.clip();
 rr(c,'#343d3c',q.x,q.y,q.w,q.h);rr(c,'#c1b78b',q.x,q.y,q.w,2);rr(c,'#5e6254',q.x,q.y+q.h-3,q.w,3);
 for(let x=q.x;x<q.x+q.w;x+=16){rr(c,'#84765a',x+1,q.y+2,14,q.h-5);rr(c,'#bba171',x+1,q.y+2,14,1);rr(c,'#43493f',x+15,q.y+2,1,q.h-2);rr(c,active?'#de9a57':'#776f53',x+7,q.y+q.h-3,2,1);}
 rr(c,'#d6ccaa',q.x+q.w-4,q.y,4,q.h);rr(c,'#6d7466',q.x+q.w-3,q.y+3,2,q.h-4);c.restore();
}

function tree(c,x,y,kind='oak',scale=1,layer=0,seed=0,shake=0){
 c.save();c.translate(Math.round(x),Math.round(y));c.scale(scale,scale);
 const birch=kind==='birch',height=birch?66:58;
 if(layer){const p=layer===1?['#487d67','#578c70','#3f705c','#528468']:['#6c9c84','#79a98e','#5f8c7b','#79a58e'];rr(c,p[2],18,-height+19,8,height-19);leafBlock(c,0,-height,44,24,p,seed);leafBlock(c,8,-height-12,28,18,p,seed+1);}
 else{
  for(let py=-height+17;py<0;py+=16){const segment=Math.min(16,-py);if(birch){rr(c,'#d6d8be',19,py,9,segment);rr(c,'#a9b1a3',26,py,2,segment);rr(c,'#f0e9ca',19,py,2,segment);rr(c,'#475454',21,py+4,4,2);rr(c,'#62675a',24,py+11,3,2);}else texture(c,'wood',18,py,12,segment,seed);}
  // Forks enter the crown and roots spread into the same planting surface.
  pixelBeam(c,22,-height+22,11,-height+8,5,birch?'#b7bfaa':'#78532f');pixelBeam(c,25,-height+22,39,-height+5,4,birch?'#b7bfaa':'#78532f');
  pixelBeam(c,20,-7,12,0,4,'#624a30');pixelBeam(c,28,-7,36,0,4,'#624a30');rr(c,'#8a683d',15,-2,19,2);
  const p=birch?['#7b9b3d','#a0b953','#536f31','#8fa946']:['#467a35','#72a545','#2d5d31','#578b38'];
  const flutter=shake?Math.sin(shake*1.3)*Math.min(2,shake*.14):0;c.save();c.translate(Math.round(flutter),Math.round(Math.abs(flutter)*.3));
  leafBlock(c,3,-height-3,43,24,p,seed);leafBlock(c,-5,-height+9,24,21,p,seed+2);leafBlock(c,29,-height+7,24,21,p,seed+5);leafBlock(c,8,-height-14,30,20,p,seed+8);c.restore();
  rr(c,'#526c32',16,-2,17,2);
 }
 c.restore();
}
function house(c,x,y,scale=1,variant=0){
 c.save();c.translate(Math.round(x),Math.round(y));c.scale(scale,scale);
 const w=variant%2?70:62,h=40;rr(c,'#4a5345',-3,-2,w+6,3);
 for(let yy=-h;yy<0;yy+=16)for(let xx=0;xx<w;xx+=16)texture(c,'planks',xx,yy,Math.min(16,w-xx),Math.min(16,-yy),variant);
 for(const xx of [0,w-8])for(let yy=-h;yy<0;yy+=16)texture(c,'wood',xx,yy,8,Math.min(16,-yy),variant);
 for(let n=0;n<5;n++){const yy=-h-20+n*4,left=18-n*5;rr(c,'#4c3827',left-2,yy,w-2*left+4,4);rr(c,'#886036',left,yy,w-2*left,3);rr(c,'#b68a4c',left,yy,w-2*left,1);for(let rx=left+5;rx<w-left;rx+=10)rr(c,'#6a4c2c',rx,yy+1,1,2);}
 rr(c,'#4a3828',-6,-h,w+12,4);rr(c,'#b08a50',-5,-h,w+10,1);
 rr(c,'#4c3c2a',24,-26,14,26);rr(c,'#8f6538',26,-24,10,23);rr(c,'#bc9756',27,-23,8,1);rr(c,'#d3b86e',33,-12,2,2);
 for(const wx of [10,w-20]){rr(c,'#544b35',wx-1,-28,12,14);rr(c,'#b5d3c0',wx,-27,10,11);rr(c,'#6e9694',wx+1,-26,8,9);rr(c,'#d4ead2',wx+1,-26,2,3);rr(c,'#dbd8b0',wx+4,-27,1,11);rr(c,'#dbd8b0',wx,-22,10,1);}
 for(let xx=0;xx<w;xx+=16)texture(c,'brick',xx,-5,Math.min(16,w-xx),5,variant);
 // Side wall and receding eaves share the upper-left light of the blocks.
 rr(c,'#6b4f31',w-13,-h+4,13,h-6);rr(c,'#8e683c',w-13,-h+4,2,h-7);
 for(let yy=-h+10;yy<-4;yy+=7){rr(c,'#493b29',w-11,yy,11,1);rr(c,'#aa824b',w-11,yy+1,9,1);}
 rr(c,'#38493e',w-9,-25,6,10);rr(c,'#88aaa0',w-8,-24,3,7);rr(c,'#b3cfb6',w-8,-24,1,3);
 pixelBeam(c,w-24,-h-18,w+4,-h+3,4,'#5c412c');pixelBeam(c,w-24,-h-19,w+4,-h+2,1,'#c79b55');rr(c,'#362f27',-4,-h+4,w+7,3);rr(c,'#8c8e79',24,-1,14,3);c.restore();
}
function village(c,q){const s=(q.scale||1)*1.35;house(c,q.x,q.y,s,q.variant||0);if(q.variant!==1){for(let y=q.y-5*s;y<q.y;y+=4)for(let x=q.x+86*s;x<q.x+86*s+70*s*.75;x+=8){rr(c,'#625e4b',x,y,8,4);rr(c,'#a29872',x,y,7,1);}house(c,q.x+86*s,q.y-5*s,s*.75,1);rr(c,'#796c46',q.x+66*s,q.y-9*s,3*s,11*s);rr(c,'#796c46',q.x+79*s,q.y-9*s,3*s,11*s);rr(c,'#9d8755',q.x+66*s,q.y-7*s,16*s,2*s);}}
function heart(c,x,y,scale=1){
 const p=[[0,1,2,2],[3,1,2,2],[1,3,3,1],[2,4,1,1]];for(const[a,b,w,h]of p)rr(c,'#f29d9f',x+a*scale,y+b*scale,w*scale,h*scale);rr(c,'#ffe2cc',x+scale,y+scale,scale,scale);
}
function apple(c,q,tick){
 if(!q||['given','lost'].includes(q.state))return;
 const x=q.x,y=q.y,bob=q.state==='hanging'?Math.sin(tick*.025)*.6:0;
 rr(c,'#593b2b',x+5,y-2+bob,1,3);rr(c,'#84ae48',x+6,y-2+bob,3,1);rr(c,'#8d302e',x+1,y+2+bob,8,6);rr(c,'#c74836',x+2,y+1+bob,6,8);rr(c,'#e36c46',x+2,y+2+bob,3,5);rr(c,'#ffd49a',x+3,y+2+bob,1,2);rr(c,'#9d352b',x+6,y+6+bob,2,2);
}
function pig(c,q,tick){
 const active=['follow','flee'].includes(q.state),sniff=q.state==='sniff',joy=q.state==='celebrate',step=active?Math.floor(tick/(q.state==='flee'?3:7))%2:0,bob=joy?Math.max(0,Math.sin(tick*.45))*2:0;
 c.save();c.translate(Math.round(q.x),Math.round(q.y-bob));const s=q.scale||1;c.scale(s*(q.facing<0?-1:1),s);if(q.facing<0)c.translate(-26,0);
 // A long cuboid, four short square legs, and an eight-pixel cube head.
 // The rear pair is staggered by two pixels, rather than merged into two legs.
 for(const x of [5,18]){const dx=active?(step?1:-1):0;rr(c,'#b76d7a',x+dx,-8,4,7);rr(c,'#854c5c',x+dx,-3,4,2);}
 rr(c,'#c77d89',1,-20,24,14);rr(c,'#e6a1a8',1,-20,23,3);rr(c,'#dc919c',1,-17,21,10);rr(c,'#edb0b2',4,-17,5,2);rr(c,'#ce8290',14,-10,6,3);rr(c,'#bc7181',22,-17,3,11);
 for(const x of [2,16]){const dx=active?(step?-1:1):0;rr(c,'#d78e9a',x+dx,-8,5,8);rr(c,'#e8a8ae',x+dx,-8,2,5);rr(c,'#8d5263',x+dx,-2,5,2);rr(c,'#bd7c8a',x+dx+1,-2,3,1);}
 const headY=sniff?2+(Math.floor(tick/7)%2):q.state==='flee'?-1:0;c.save();c.translate(0,headY);
 rr(c,'#c87c8b',20,-22,13,13);rr(c,'#eca6ae',20,-22,11,11);rr(c,'#f4b9bb',20,-22,11,2);rr(c,'#d98c9b',29,-20,4,11);rr(c,'#e79ba7',21,-19,3,3);
 rr(c,'#f5ded5',22,-18,3,3);rr(c,'#34313a',23,-18,2,2);rr(c,'#f5ded5',29,-18,2,3);rr(c,'#34313a',30,-18,1,2);
 rr(c,'#bb6b82',27,-15,8,5);rr(c,'#f2a4b2',27,-15,7,4);rr(c,'#f7b8bd',27,-15,7,1);rr(c,'#9b4c6b',28,-13,2,2);rr(c,'#9b4c6b',32,-13,2,2);c.restore();
 rr(c,'#df99a2',-2,-17,3,2);rr(c,'#b76f80',-3,-17,1,4);rr(c,'#ebacb1',-2,-14,3,1);
 if(sniff){const phase=tick%28;c.globalAlpha*=1-phase/28;rr(c,'#e3dcb3',36+phase*.1,-10-phase*.08,1,1);rr(c,'#e3dcb3',38+phase*.1,-7-phase*.08,1,1);}
 if(joy||(q.state==='follow'&&Math.floor(tick/36)%4===0))heart(c,12,-31-(tick%36)/12);
 if(q.state==='flee')for(let i=0;i<2;i++)rr(c,'#d4c4a2',-4-i*5,-3+(tick+i)%3,2,1);
 c.restore();
}
const animalSizes={cow:{w:30,h:26},sheep:{w:26,h:22},llama:{w:22,h:38}};
/** Authored animals have one live identity. The controller owns ground, turning,
 * greetings and movement; this plan only exposes an immutable render pose. */
export function minecraftAnimalArtPlan(room={},view=room.minecraftView){
 if(!isMinecraftRoom(room))return [];
 const state=view?.minecraft||view||{},seen=new Set(),source=Array.isArray(state.animals)?state.animals:[];
 return source.filter(q=>q&&animalSizes[q.kind]&&!q.dead&&!q.hidden&&q.visible!==false&&!seen.has(q.id)&&seen.add(q.id)).map(q=>({...q,w:q.w||animalSizes[q.kind].w,h:q.h||animalSizes[q.kind].h,facing:q.facing<0?-1:1}));
}
function animal(c,q,tick){
 const size=animalSizes[q.kind];if(!size||q.hidden||q.dead||q.visible===false)return;
 const w=q.w||size.w,h=q.h||size.h,walking=['walk','graze-walk','amble','roam','wander'].includes(q.state)||Math.abs(q.vx||0)>.01,stride=walking?Math.floor((q.age??tick)/9)%2:0,grazing=['graze','grazing','sniff'].includes(q.state),talk=q.speakTicks>0&&Math.floor(tick/6)%2;
 c.save();c.translate(Math.round(q.x)+(q.facing<0?w:0),Math.round(q.y));c.scale((q.facing<0?-1:1)*w/size.w,h/size.h);
 if(q.kind==='cow'){
  // Dark brown cuboid, four separate cream-patched legs, horns and pink muzzle.
  for(const x of [7,20]){const dy=walking?(stride?1:0):0;rr(c,'#675745',x,16,3,9-dy);rr(c,'#c6c0a6',x,19,2,4-dy);rr(c,'#3c3932',x,23-dy,3,2);}
  rr(c,'#473a30',1,7,22,13);rr(c,'#6e5140',2,7,20,12);rr(c,'#92715a',2,7,19,2);rr(c,'#d9d5bd',3,9,6,7);rr(c,'#e8e2cb',3,9,5,2);rr(c,'#c4c4ac',7,13,4,5);rr(c,'#e1dcc4',14,8,5,5);rr(c,'#b3b39c',17,11,5,6);rr(c,'#3f352d',10,11,3,6);
  rr(c,'#b58b7d',10,19,6,3);rr(c,'#d1a092',11,20,4,2);
  for(const x of [3,17]){const dy=walking?(stride?0:1):0;rr(c,'#775846',x,17,4,9-dy);rr(c,'#d8d0b8',x,20,3,4-dy);rr(c,'#443b33',x,24-dy,4,2);}
  rr(c,'#6b5140',0,9,2,9);rr(c,'#342d28',0,17,3,4);
  c.save();c.translate(0,grazing?5:talk?1:0);rr(c,'#7c614d',18,4,4,3);rr(c,'#c7b999',19,4,2,1);rr(c,'#e1d9bd',21,0,2,4);rr(c,'#c9c5ad',27,0,2,4);rr(c,'#544238',20,3,10,11);rr(c,'#80624c',20,3,8,10);rr(c,'#e6dfc5',21,3,5,3);rr(c,'#bdb99e',27,4,2,4);rr(c,'#efe8d4',21,7,3,3);rr(c,'#efe8d4',27,7,2,3);rr(c,'#292b26',22,7,2,2);rr(c,'#292b26',28,7,1,2);rr(c,'#a97567',22,11,8,5);rr(c,'#d4a393',22,11,7,3);rr(c,'#ead0b8',23,11,6,1);rr(c,'#795347',23,13,2,1);rr(c,'#795347',27,13,2,1);if(talk)rr(c,'#503a33',24,15,4,1);c.restore();
 }else if(q.kind==='sheep'){
  // Thick off-white fleece wraps a low broad body; the face stays bare tan.
  for(const x of [6,18]){rr(c,'#9b8d72',x,13,3,8);rr(c,'#605440',x,19,3,2);}
  rr(c,'#9ea18c',1,3,21,13);rr(c,'#d5d7bd',1,2,20,12);rr(c,'#eee9d2',2,1,17,3);rr(c,'#e3e0c9',0,5,19,7);rr(c,'#c1c6ad',3,12,18,4);rr(c,'#f0ecd5',3,4,5,4);rr(c,'#d0d3b9',7,8,6,4);rr(c,'#f0ecd5',12,4,5,3);rr(c,'#b8bfa7',17,10,4,4);rr(c,'#eaead0',2,10,4,2);
  for(const x of [2,15]){const dy=walking?(x===2?stride:1-stride):0;rr(c,'#b6aa8e',x,15,4,7-dy);rr(c,'#d0c5a6',x,15,2,4-dy);rr(c,'#6c5a44',x,20-dy,4,2);}
  rr(c,'#e9e5cb',0,7,2,4);c.save();c.translate(0,grazing?4:talk?1:0);rr(c,'#c6bea0',18,3,8,10);rr(c,'#ece7ce',18,2,7,4);rr(c,'#a29478',24,5,2,9);rr(c,'#b2a284',19,6,5,8);rr(c,'#d3c2a0',19,6,2,7);rr(c,'#2f322b',20,7,2,2);rr(c,'#2f322b',24,7,1,2);rr(c,'#876c59',21,11,5,3);rr(c,'#c5a994',21,11,4,1);rr(c,'#685645',22,13,3,1);if(talk)rr(c,'#493b30',22,14,3,1);c.restore();
 }else{
  // Trader llama: long upright neck, two ears, four slender legs and a woven
  // blue/gold carpet. Its silhouette is not a resized horse, cow or pig.
  for(const x of [5,14]){rr(c,'#ab9577',x,27,3,10);rr(c,'#695a49',x,35,3,2);}
  rr(c,'#b99c78',1,20,16,11);rr(c,'#dfc49a',1,20,14,9);rr(c,'#f1dbb1',2,20,12,2);rr(c,'#d3b58a',1,24,3,6);rr(c,'#b19a78',0,22,2,7);
  for(const x of [2,12]){const dy=walking?(x===2?stride:1-stride):0;rr(c,'#c9ad87',x,29,3,9-dy);rr(c,'#edd3a8',x,29,1,7-dy);rr(c,'#76624a',x,36-dy,3,2);}
  rr(c,'#b39773',14,6,6,21);rr(c,'#e2c79e',14,6,4,20);rr(c,'#f2dcb4',14,7,1,17);rr(c,'#caad85',17,13,2,11);
  rr(c,'#293e60',4,21,10,11);rr(c,'#3b6a90',4,21,9,9);rr(c,'#d0a34d',4,21,10,2);rr(c,'#e3c36b',5,23,1,7);rr(c,'#e3c36b',11,23,1,7);rr(c,'#b65846',7,24,3,5);rr(c,'#efcb72',8,25,1,3);rr(c,'#24495d',4,30,10,2);for(const x of [4,8,12])rr(c,'#d5b45e',x,31,1,2);
  c.save();c.translate(0,talk?1:0);rr(c,'#b59a77',13,0,3,5);rr(c,'#b59a77',18,0,3,5);rr(c,'#f2ddba',13,0,1,4);rr(c,'#f2ddba',18,0,1,4);rr(c,'#d6bb91',13,4,9,7);rr(c,'#edd5ab',13,4,7,3);rr(c,'#a98d6d',20,5,2,6);rr(c,'#2b2d29',15,6,2,2);rr(c,'#443c31',21,6,1,2);rr(c,'#d2b48b',18,9,4,4);rr(c,'#f0d2a5',18,9,4,1);rr(c,'#8b7158',20,11,2,1);rr(c,'#c49a51',14,10,4,2);rr(c,'#395c7c',14,11,4,1);if(talk)rr(c,'#6f5540',19,12,3,1);c.restore();
 }
 c.restore();
}
function villager(c,q,tick,{rear=false}={}){
 if(!q||q.hidden||q.dead)return;const celebrate=q.state==='celebrate',working=q.state==='work'||q.state==='watch',phase=Math.floor((q.age??tick)/10)%2,bob=celebrate?Math.max(0,Math.sin(tick*.3))*2:0,speaking=q.speakTicks>0;
 c.save();c.translate(Math.round(q.x),Math.round(q.y+(q.h||24)-32-bob));if(q.facing<0){c.translate(16,0);c.scale(-1,1);}if(rear)c.globalAlpha*=.88;
 // The hem hangs below folded arms; a bald tall head, green eyes and one
 // protruding cuboid nose remain readable at the gameplay camera size.
 rr(c,'#493a30',3,25,4,7);rr(c,'#544033',9,25,4,7);rr(c,'#302e29',2,30,5,2);rr(c,'#302e29',9,30,5,2);
 rr(c,'#594132',2,10,12,18);rr(c,'#826044',3,11,10,16);rr(c,'#9a7852',3,12,3,14);rr(c,'#664b37',10,12,3,16);rr(c,'#4a392e',3,26,10,2);rr(c,'#a28b5b',6,18,3,8);
 if(q.role==='trader'){rr(c,'#244660',2,10,12,18);rr(c,'#3d6d8a',3,11,10,15);rr(c,'#739cad',3,11,2,14);rr(c,'#203f56',11,12,2,15);rr(c,'#d0a55b',5,11,2,16);rr(c,'#b78543',10,11,1,16);rr(c,'#8e4c45',7,22,3,4);rr(c,'#dfbc72',3,26,10,2);}
 else if(q.role==='farmer'){rr(c,'#5b6740',5,19,7,7);rr(c,'#a39b56',5,19,2,6);rr(c,'#544f32',9,22,2,3);}
 c.save();c.translate(q.state==='react'&&speaking?(Math.floor(tick/4)%2?1:-1):0,q.lookUp?-1:speaking&&Math.floor(tick/7)%2?1:0);
 rr(c,'#856247',3,0,11,12);rr(c,'#bb936b',3,0,9,10);rr(c,'#cba67b',4,1,7,2);rr(c,'#a77f59',11,2,3,8);
 rr(c,'#57442f',3,4,10,2);rr(c,'#d7dfc4',4,6,3,2);rr(c,'#d7dfc4',10,6,3,2);rr(c,'#4e8151',5,6,2,2);rr(c,'#4e8151',10,6,2,2);
 rr(c,'#8c6748',7,6,4,8);rr(c,'#c39b70',7,6,3,7);rr(c,'#d1ae7d',7,6,1,6);rr(c,'#6e503b',8,12,3,2);if(speaking)rr(c,'#4c392e',4,10,2,Math.floor(tick/5)%2?2:1);if((q.age??tick)%180<5){rr(c,'#a77f59',4,6,3,1);rr(c,'#a77f59',10,6,3,1);}
 if(q.role==='farmer'){rr(c,'#806631',1,-2,16,3);rr(c,'#d4b75e',0,-3,18,2);rr(c,'#a1843e',4,-7,10,4);rr(c,'#d8bc65',4,-7,9,1);rr(c,'#e7cd7d',5,-6,2,2);rr(c,'#796036',4,-4,10,1);for(let x=1;x<17;x+=3)rr(c,'#f1d783',x,-3,1,1);}
 else if(q.role==='trader'){rr(c,'#2c4f6b',2,-3,13,4);rr(c,'#527d93',3,-3,10,2);rr(c,'#86a4ad',3,-3,3,1);rr(c,'#b78e4d',2,0,13,1);rr(c,'#2a4e68',2,1,2,4);rr(c,'#24445d',13,1,2,8);}
 c.restore();
 if(celebrate){pixelBeam(c,3,14,-1,6,4,'#826044');pixelBeam(c,12,14,17,7,4,'#826044');rr(c,'#c3a071',-2,4,3,4);rr(c,'#c3a071',16,5,3,4);if(tick%40<15){rr(c,'#edcc7e',-3,-4,1,3);rr(c,'#edcc7e',18,-3,1,3);}}
 else{rr(c,'#5c4433',0,14,16,7);rr(c,'#9e8055',1,14,14,3);rr(c,'#bb9c6c',7,15,7,3);rr(c,'#7b5c3e',2,18,12,3);rr(c,'#c5a575',3,17,5,2);if(q.role==='trader'){rr(c,'#315870',0,14,16,3);rr(c,'#7392a0',1,14,5,2);rr(c,'#bd9b68',7,15,7,3);rr(c,'#d4ad62',0,18,3,2);rr(c,'#d4ad62',13,18,3,2);}
  if(working){if(q.role==='farmer'){pixelBeam(c,12,16,18,24-phase*4,2,'#966e3b');rr(c,'#b8a477',17,22-phase*4,7,2);rr(c,'#657974',21,23-phase*4,3,3);rr(c,'#c1c9ac',18,22-phase*4,6,1);rr(c,'#c3a071',12,16,3,3);}else{rr(c,'#775635',15,14-phase*3,2,11);rr(c,'#83918a',13,12-phase*3,6,4);rr(c,'#c0c2a5',13,12-phase*3,6,1);}}}
 if(q.poppy)poppy(c,celebrate?18:16,celebrate?4:18);
 c.restore();
}
function poppy(c,x,y){rr(c,'#537346',x,y-11,1,12);rr(c,'#77954b',x-2,y-6,2,2);rr(c,'#a23532',x-3,y-15,6,5);rr(c,'#e16145',x-2,y-16,4,4);rr(c,'#f3a06a',x-1,y-15,1,1);}
function enderman(c,q,tick){
 if(!q||q.hidden||q.visible===false||q.state==='departed'||q.state==='teleporting')return;
 const w=q.w||16,h=q.h||48,lifting=q.state==='lifting',carrying=q.state==='carrying'||q.state==='placing',reach=lifting?clamp((q.age||q.ticks||20)/40,0,1):0;
 c.save();c.translate(Math.round(q.x),Math.round(q.y));c.scale(w/16,h/48);
 rr(c,'#080b13',4,22,3,26);rr(c,'#282332',4,23,1,24);rr(c,'#080b13',10,22,3,26);rr(c,'#282332',10,23,1,24);
 rr(c,'#10101a',4,10,9,15);rr(c,'#262130',4,10,2,13);rr(c,'#070a13',11,10,2,15);
 const placed=q.state==='placed',handY=carrying?28:placed?36:lifting?31:37,leftX=lifting?-9*reach:carrying?11:0,rightX=carrying?29:placed?34:16;
 pixelBeam(c,4,11,leftX,handY,2,'#0d0e19');pixelBeam(c,13,11,rightX,handY,2,'#0d0e19');pixelBeam(c,3,11,leftX-1,handY,1,'#292335');pixelBeam(c,13,11,rightX-1,handY,1,'#292335');
 if(carrying){texture(c,'dirt',12,22,16,16,42);grassTop(c,12,22,16,42);rr(c,'#0a0d17',10,26,3,5);rr(c,'#0a0d17',27,26,3,5);}
 rr(c,'#080b14',2,0,13,10);rr(c,'#272031',2,0,12,1);rr(c,'#181522',13,1,2,8);rr(c,'#5b326c',3,4,11,3);rr(c,'#d17ae4',3,4,4,2);rr(c,'#d17ae4',10,4,4,2);rr(c,'#f7b8f8',4,4,2,1);rr(c,'#f7b8f8',11,4,2,1);rr(c,'#b06cce',6,5,1,1);rr(c,'#b06cce',10,5,1,1);
 const alpha=c.globalAlpha;for(let i=0;i<5;i++){const life=(tick+i*13)%60,px=(i%2?-5:20)+(hash(i,8)%5),py=42-life*.65;c.globalAlpha=alpha*(1-life/60)*.7;rr(c,i%2?'#b66cd2':'#74449b',px,py,1,2);}c.restore();
}
/** Canonical rail guard: no block cargo or teleport. The controller owns the
 * uppercut target, lift and timing; the renderer only projects its view. */
export function minecraftIronGolemArtPlan(room={},view=room.minecraftView){
 const state=view?.minecraft||view||{},q=state.exploration?.golem;
 if(!isMinecraftRoom(room)||!q||q.hidden||q.dead||q.visible===false)return null;
 const armLift=Number.isFinite(q.armLift)?clamp(q.armLift,-1,1):q.state==='uppercut'?1:q.state==='windup'?-.45:0;
 return {...q,x:Math.round(q.x),y:Math.round(q.y),w:24,h:48,armLift,rose:!!q.rose||q.state==='rose'};
}
function ironGolem(c,q,tick){
 if(!q)return;const f=q.facing<0?-1:1,walking=q.state==='approach',stride=walking?Math.floor((q.age??tick)/8)%2:0,lift=Math.max(0,q.armLift),windup=Math.max(0,-q.armLift);
 c.save();c.translate(q.x+(f<0?24:0),q.y);c.scale(f,1);
 // Broad iron torso, high square shoulders, two long heavy arms and short legs.
 for(const [x,dy]of [[5,stride],[14,walking?1-stride:0]]){rr(c,'#8f9587',x,31,6,17-dy);rr(c,'#c8c7b1',x,32,4,14-dy);rr(c,'#e4dfc8',x,32,1,12-dy);rr(c,'#686f67',x-1,45-dy,8,3);rr(c,'#b4b7a2',x-1,45-dy,7,1);}
 rr(c,'#8a9486',3,11,19,22);rr(c,'#c8cbb5',4,11,15,21);rr(c,'#ece9ce',4,11,15,3);rr(c,'#e0ddc4',4,14,3,15);rr(c,'#a5ad99',16,14,4,18);rr(c,'#758475',19,15,3,17);rr(c,'#929a87',5,29,14,3);
 rr(c,'#809178',7,17,1,14);rr(c,'#5d7f4a',6,20,3,4);rr(c,'#78954f',7,25,4,3);rr(c,'#a4b66b',6,21,1,2);rr(c,'#536e43',10,26,1,5);rr(c,'#829a55',11,29,2,3);
 const arm=(x,near)=>{const endY=near?(q.rose?25:38)-lift*34+windup*4:37-lift*28+windup*4,endX=near?(q.rose?32:21)+lift*7-windup*3:1+lift*5+windup*2;
  pixelBeam(c,x,14,endX,endY,6,near?'#afb6a2':'#929e8e');pixelBeam(c,x-1,13,endX-1,endY-1,3,near?'#e3e0c7':'#c1c6af');rr(c,'#7e8a7b',endX-3,endY-2,6,5);rr(c,near?'#dedcc3':'#bac3ab',endX-3,endY-3,5,4);rr(c,'#eff0d6',endX-3,endY-3,4,1);if(!near&&lift<.3){rr(c,'#5e7d4c',endX-2,endY-8,2,4);rr(c,'#95aa60',endX-1,endY-7,2,2);}return {x:endX,y:endY};};
 arm(3,false);const hand=arm(21,true);
 rr(c,'#a8b19e',7,0,13,12);rr(c,'#e0e0c7',7,0,11,10);rr(c,'#f2ecd2',7,0,11,2);rr(c,'#939f8c',18,2,2,9);rr(c,'#8b9684',7,4,11,2);
 rr(c,'#572c29',9,5,3,2);rr(c,'#b75438',10,5,1,1);rr(c,'#572c29',16,5,2,2);rr(c,'#b75438',16,5,1,1);rr(c,'#b0b8a1',12,5,4,9);rr(c,'#d7d7bb',12,5,2,8);rr(c,'#7d8978',13,12,3,2);
 if(q.rose)poppy(c,hand.x+3,hand.y-2);
 if(q.state==='uppercut'&&lift>.6){for(let i=0;i<4;i++){const x=25+i*3,y=15-i*5;rr(c,i%2?'#e6e5c9':'#a8c3b5',x,y,2,5);}}
 c.restore();
}
/** Wild actors have their own fixed anatomy and never borrow the rail helper's
 * cargo pose. The plan exposes the same 16×48 footprint as the live controller. */
export function minecraftWildEndermanArtPlan(room={},view=room.minecraftView){
 const state=view?.minecraft||view||{},wild=state.wildEnderman;
 if(!isMinecraftRoom(room)||!wild||wild.active===false)return {actors:[],effects:[]};
 const actors=(wild.actors||[]).filter(q=>!q.dead&&!q.hidden&&q.visible!==false&&q.state!=='departed').map(q=>{
  const phase=q.state||q.phase||'calm',angry=!!q.angry||['stared','grace','chase','blocked'].includes(phase),shaking=q.shaking??angry,age=q.age??wild.age??tickOf(room),shake=shaking?[0,-1,1,-1][Math.floor(age/2)%4]:0;
  return {...q,x:Math.round(q.x),y:Math.round(q.y),w:16,h:48,phase,angry,shake,openMouth:!!q.screaming||angry,age};
 });
 return {actors,effects:wild.effects||[]};
}
function wildTeleportCue(c,q,tick,{arrival=false,progress=0}={}){
 const x=Math.round(q.x),y=Math.round(q.y),alpha=c.globalAlpha;
 c.save();c.globalAlpha=alpha*(arrival?.66:.38)*(1-clamp(progress,0,1));
 // Broken square brackets are a location cue, never a second solid mob.
 for(const dx of [-4,18]){rr(c,'#b169dc',x+dx,y-2,2,10);rr(c,'#b169dc',x+dx,y+37,2,12);rr(c,'#e2a3ff',x+dx,y-2,2,2);}
 rr(c,'#8d4db6',x-2,y+48,20,1);rr(c,'#cf8ded',x+1,y+47,14,1);
 for(let i=0;i<12;i++){const life=(tick+i*7)%36,px=x-7+(hash(i,73)%30),py=y+47-life*1.4;c.globalAlpha=alpha*(1-life/36)*(1-progress)*.75;rr(c,i%3?'#b767d5':'#f1b2ff',px,py,1+i%2,2);}
 c.restore();
}
function wildEnderman(c,q,tick){
 const phase=q.phase,teleporting=phase==='teleporting',chasing=phase==='chase',stride=chasing?Math.floor(q.age/5)%2:0;
 c.save();c.translate(q.x,q.y);if(teleporting)c.globalAlpha*=Math.max(.13,1-(q.stateAge||0)/18);
 // All body pixels, including head shake and chasing limbs, remain inside the
 // actual collision footprint. Only the purple particles extend beyond it.
 for(const [x,lift]of [[4,stride],[9,1-stride]]){const foot=chasing?lift*3:0;rr(c,'#080911',x,23,3,25-foot);rr(c,'#302839',x,24,1,23-foot);rr(c,'#171420',x+1,46-foot,2,2);}
 rr(c,'#0a0a12',4,11,8,14);rr(c,'#302638',4,11,1,13);rr(c,'#1d1827',11,11,1,14);
 for(const [x,lift]of [[0,chasing?stride*5:0],[14,chasing?(1-stride)*5:0]]){rr(c,'#0a0a13',x,11,2,28-lift);rr(c,'#34293d',x,12,1,25-lift);rr(c,'#17131f',x,38-lift,2,1);}
 const hx=2+q.shake,headH=q.openMouth?8:10;
 rr(c,'#090a12',hx,0,12,headH);rr(c,'#3b2d44',hx,0,12,1);rr(c,'#241d30',hx+11,1,1,headH-1);
 const ey=q.openMouth?3:4;rr(c,'#693775',hx+1,ey,10,3);
 for(const ex of [1,7]){rr(c,q.angry?'#efa2fc':'#cc7de1',hx+ex,ey,4,2);rr(c,q.angry?'#ffe2ff':'#f2b1fa',hx+ex+1,ey,2,1);}
 if(q.openMouth){rr(c,'#3b2b45',hx+1,7,10,5);rr(c,'#05060c',hx+2,7,8,4);rr(c,'#221b2b',hx+2,11,8,1);rr(c,'#8a548e',hx+2,7,1,1);}
 c.restore();
 const alpha=c.globalAlpha;c.save();for(let i=0;i<(q.angry?7:4);i++){const life=(tick+i*13)%60;c.globalAlpha=alpha*(1-life/60)*(q.angry?.7:.43);rr(c,i%2?'#b46cd2':'#85519f',q.x+(i%2?-5:20)+(hash(i,8)%4),q.y+43-life*.68,1,2);}c.restore();
}
function wildEndermanWorld(c,room,state,tick){
 const plan=minecraftWildEndermanArtPlan(room,state),v=bounds(room);
 for(const q of plan.actors){if(q.teleportCue)wildTeleportCue(c,q.teleportCue,tick);if(q.x+24>=v.x&&q.x-8<=v.x+v.w){wildEnderman(c,q,tick);if(q.phase==='teleporting')wildTeleportCue(c,q,tick,{arrival:true,progress:(q.stateAge||0)/22});}}
 for(const q of plan.effects){if(!['enderman-teleport-depart','enderman-teleport-arrive'].includes(q.kind))continue;wildTeleportCue(c,q,tick,{arrival:q.kind==='enderman-teleport-arrive',progress:clamp((q.age||0)/(q.life||24),0,1)});}
}
/** One canonical drawn identity per controller villager. Edit previews use the
 * same authored records; no coordinate-only residents are invented by art. */
export function minecraftVillagerArtPlan(room={},view=room.minecraftView){
 if(!isMinecraftRoom(room))return [];
 const state=view?.minecraft||view||{},e=state.exploration,spec=room.minecraft.exploration||{},source=e?.villagers||[e?.villager??spec.villager,...(!e?spec.villagers||[]:[])].filter(Boolean),seen=new Set();
 return source.filter(q=>q&&!q.dead&&!q.hidden&&q.visible!==false&&!seen.has(q.id)&&seen.add(q.id)).map(q=>({...q,w:16,h:24,state:q.state||(q.role==='worker'?'work':'idle'),facing:q.facing||-1}));
}

/** Village dressing projects real residents, grounded plots and live animal
 * positions; it neither invents colliders nor performs the coin transaction. */
export function minecraftVillageArtPlan(room={},view=room.minecraftView){
 if(!isMinecraftRoom(room))return {farms:[],leash:null,offer:null};
 const state=view?.minecraft||view||{},auth=room.minecraft.exploration||{},residents=[auth.villager,...(auth.villagers||[])].filter(Boolean),farms=[];
 for(const q of residents.filter(q=>q.role==='farmer')){const x=q.x-12,w=40,y=q.y+24,ground=roomGeometry(room).find(g=>!g.hidden&&!g.removed&&g.visible!==false&&g.x<=x&&g.x+g.w>=x+w&&g.y===y);const blocked=roomGeometry(room).some(g=>g!==ground&&!g.hidden&&!g.removed&&g.visible!==false&&g.x<x+w&&g.x+g.w>x&&g.y<y&&g.y+g.h>y-14);if(ground&&!blocked)farms.push({id:q.id,x,y,w,groundId:ground.id});}
 const trader=minecraftVillagerArtPlan(room,state).find(q=>q.role==='trader'),animals=Array.isArray(state.animals)?minecraftAnimalArtPlan(room,state):(room.minecraft.scenery||[]).filter(q=>q.kind==='llama').map(q=>({...q,y:q.y-38,w:22,h:38})),llama=animals.find(q=>q.kind==='llama'&&!q.hidden&&!q.dead),trade=state.exploration?.trade;
 const leash=trader&&llama&&Math.abs(trader.x-llama.x)<100?{from:{x:trader.x+(trader.facing<0?2:14),y:trader.y+10},to:{x:llama.x+(llama.facing<0?6:16),y:llama.y+11}}:null;
 return {farms,leash,offer:trader&&trade?.near&&!trade.open?{x:trader.x+8,y:trader.y-34,price:trade.price||4,flash:trade.pulse>0?trade.flash:null,pulse:trade.pulse||0}:null};
}
function villageFarm(c,room){
 for(const q of minecraftVillageArtPlan(room).farms){const x=q.x,y=q.y,w=q.w;
  // The shallow rear soil plane touches the actual floor; its dark lip is
  // behind the player and cannot be mistaken for another jumping platform.
  rr(c,'#4d4430',x,y-5,w,5);rr(c,'#6b5433',x+2,y-7,w-4,5);rr(c,'#927345',x+4,y-7,w-8,1);for(let n=0;n<2;n++){const ry=y-5+n*4;rr(c,'#392f24',x+3,ry,w-6,1);for(let px=x+5;px<x+w-3;px+=7){const height=6+hash(px,n)%4;rr(c,'#486438',px,ry-height,1,height);rr(c,'#7c934a',px-2,ry-height+2,2,2);rr(c,'#a5ab50',px+1,ry-height+1,2,2);if(n===0||px%3){rr(c,'#c7ac54',px-1,ry-height-1,3,3);rr(c,'#e5c774',px,ry-height-2,1,3);}else{rr(c,'#799747',px-2,ry-height,5,2);rr(c,'#93ae53',px-1,ry-height-2,3,2);}}}
 }
}
function villageLeash(c,plan){if(!plan.leash)return;const {from:a,to:b}=plan.leash,m={x:(a.x+b.x)/2,y:Math.max(a.y,b.y)+4};for(const [p,q]of [[a,m],[m,b]]){pixelBeam(c,p.x,p.y,q.x,q.y,2,'#554329');pixelBeam(c,p.x,p.y-1,q.x,q.y-1,1,'#b28b54');}}
function villageTradeOffer(c,plan){const q=plan.offer;if(!q)return;const x=Math.round(q.x-24),y=Math.round(q.y);c.save();rr(c,'#233a36',x-2,y-2,52,20);rr(c,'#b4c6a3',x-1,y-1,50,1);c.fillStyle='#f2e9c9';c.font='10px sans-serif';c.textAlign='center';c.textBaseline='middle';c.fillText('E / ↑ 交易',x+24,y+8);c.restore();}
function minecart(c,q,tick){
 const w=q.w||40,h=q.h||16,x=q.x,y=q.y,riding=q.state==='riding',shake=riding?Math.floor(tick/3)%2:0;
 c.save();c.translate(Math.round(x),Math.round(y+shake));
 if(q.cargo&&!q.delivered){rr(c,'#412e30',w/2-7,-12,14,12);rr(c,'#9d4d3e',w/2-6,-11,12,10);rr(c,'#eb8953',w/2-4,-9,8,6);rr(c,'#ffd58a',w/2-2,-8,4,3);rr(c,'#60564b',w/2-8,-3,16,3);}
 rr(c,'#343d40',1,0,w-2,h-5);rr(c,'#929b97',0,0,w,3);rr(c,'#c0c8b6',2,0,w-4,1);rr(c,'#657271',2,3,w-4,Math.max(5,h-8));rr(c,'#7f8e87',3,4,w-6,2);rr(c,'#455552',3,h-8,w-6,3);
 for(const wx of [5,w-12]){rr(c,'#202e31',wx,h-6,7,6);rr(c,'#566660',wx+1,h-6,5,5);rr(c,'#bcc0a2',wx+2,h-5,3,3);const roll=Math.floor((q.x||tick)/3)%4;rr(c,'#3c4e4b',wx+2+(roll%2),h-5+Math.floor(roll/2),2,2);}
 for(const rx of [4,w-6]){rr(c,'#d0c6a5',rx,4,1,1);rr(c,'#2a403e',rx,Math.max(7,h-9),1,1);}rr(c,'#40514e',w-1,3,2,h-8);c.restore();
}
function rail(c,room){
 const spec=room.minecraft.exploration?.cart;if(!spec)return;
 const source=room.map.geometry.find(q=>q.id===spec.geometryId);if(!source)return;
 const left=Math.min(source.x,spec.endX),right=Math.max(source.x,spec.endX)+source.w,y=source.y+source.h-1,v=bounds(room),from=Math.max(left,Math.floor(v.x/12)*12-12),to=Math.min(right,v.x+v.w+12);
 if(to<=from)return;
 railTrestle(c,room,source,left,right,y);
 for(let x=from;x<to;x+=12){rr(c,'#4b3f2f',x,y,8,3);rr(c,'#8e7146',x+1,y,6,1);}rr(c,'#455955',from,y-2,to-from,2);rr(c,'#b6b69b',from,y-3,to-from,1);rr(c,'#8d9c8c',from,y+1,to-from,1);
}
function tinyPortalKey(c,q,tick){
 if(!q)return;const x=q.x+(q.w||24)/2-5,y=q.y-15-Math.round(Math.sin(tick*.08));
 rr(c,'#1b2c2d',x-1,y-1,11,13);rr(c,'#e7e9d2',x,y,9,11);rr(c,'#4e6051',x+2,y+2,5,1);rr(c,'#4e6051',x+2,y+3,1,6);rr(c,'#4e6051',x+2,y+5,4,1);rr(c,'#4e6051',x+2,y+8,5,1);
}
function torch(c,x,y,tick,scale=1){
 c.save();c.translate(Math.round(x),Math.round(y));c.scale(scale,scale);const flame=Math.floor(tick/7)%3;
 const alpha=c.globalAlpha;for(let gy=-36;gy<=36;gy+=4)for(let gx=-36;gx<=36;gx+=4){const d=Math.sqrt(gx*gx+gy*gy);if(d>38)continue;c.globalAlpha=alpha*.18*(1-d/40)**2;rr(c,'#ffd487',gx,gy,4,4);}c.globalAlpha=alpha;
 rr(c,'#4a3429',-1,5,3,12);rr(c,'#b98843',0,5,2,11);rr(c,'#edb85b',0,5,1,8);rr(c,'#e46b27',-2,1,6,6);rr(c,'#ffa83c',-1,-1-flame,4,7+flame);rr(c,'#ffec9b',0,0,2,4);rr(c,'#fff8cf',0,1,1,2);if(tick%24<8)rr(c,'#c99c65',1,-8-(tick%24),1,2);c.restore();
}
function portal(c,q,tick,lit=true){
 const w=q.w||48,h=q.h||80,x=q.x,y=q.y-h,frame=8;
 c.save();c.globalAlpha=lit?.05:.012;for(let n=4;n>0;n--)rr(c,'#be71ec',x-n*5,y-n*5,w+n*10,h+n*10);c.globalAlpha=1;
 rr(c,lit?'#301a50':'#17232a',x+frame,y+frame,w-frame*2,h-frame*2);
 if(lit)for(let py=frame;py<h-frame;py+=4)for(let px=frame;px<w-frame;px+=4){const n=hash(Math.floor((px+tick*.4)/4),Math.floor((py-tick*.2)/4),8);rr(c,['#7846b5','#8b51c5','#58307f','#b46bd5','#9a59c4'][n%5],x+px,y+py,4,4);if(n%9===0)rr(c,'#d99ee9',x+px,y+py,2,1);}
 for(let py=0;py<h;py+=8)for(let px=0;px<w;px+=8)if(px<frame||px>=w-frame||py<frame||py>=h-frame){texture(c,'obsidian',x+px,y+py,Math.min(8,w-px),Math.min(8,h-py),px+py);rr(c,'#684373',x+px+1,y+py+1,3,1);}
 if(lit)for(let i=0;i<12;i++){const cycle=(tick+i*17)%100,dx=(hash(i,8)%w)-w/2,dy=cycle*.6;rr(c,i%2?'#c380ed':'#8b4fca',x+w/2+dx+(i%2?1:-1)*cycle*.12,y+h/2-dy,cycle%3?1:2,2);}
 c.restore();
}
function smallPlant(c,q,tick){const x=q.x,y=q.y,s=q.scale||1;
 if(q.kind==='mushroom'){rr(c,'#d7c49f',x+3*s,y-6*s,2*s,6*s);rr(c,'#7f2926',x,y-9*s,8*s,4*s);rr(c,'#c74c35',x+s,y-10*s,6*s,3*s);rr(c,'#f2d5b8',x+2*s,y-9*s,s,s);rr(c,'#f2d5b8',x+5*s,y-8*s,2*s,s);}
 else{const p=['#476d30','#6c8b34','#99ae4a'];for(let i=0;i<5;i++){const h=3+hash(i,x)%6;rr(c,p[i%3],x+i*2*s,y-h*s,s,h*s);if(i%2)rr(c,p[i%3],x+(i*2-1)*s,y-h*s,s,2*s);}if(q.variant===1){rr(c,'#e4ca5c',x+3*s,y-10*s,3*s,3*s);rr(c,'#eff0be',x+4*s,y-11*s,s,s);}}
}
function skyCloud(c,x,y,w){rr(c,'#c8e0d6',x,y+5,w,6);rr(c,'#e0ecda',x+5,y,w*.52,8);rr(c,'#e8efde',x+w*.27,y-4,w*.36,8);rr(c,'#d8e6d6',x+w*.62,y+2,w*.25,6);}
/** Decorative render overscan only. Every rectangle lies wholly outside the
 * authored world; no collider, actor, pickup or playable ledge is created. */
export function minecraftBoundaryArtPlan(room={}){
 if(!isMinecraftRoom(room)||!room.map)return [];
 const v=bounds(room),right=v.x+v.w,bottom=v.y+v.h,w=room.map.width,h=room.map.height,geometry=room.playGeometry||room.map.geometry||[],regions=[];
 if(bottom>h){regions.push({kind:'depth',x:v.x,y:h,w:v.w,h:bottom-h});for(const q of geometry)if(q.collision==='solid'&&!q.hidden&&!q.motion&&Math.abs(q.y+q.h-h)<.01){const x=Math.max(v.x,q.x),end=Math.min(right,q.x+q.w);if(end>x)regions.push({kind:'strata',x,y:h,w:end-x,h:bottom-h,source:{...q,h:bottom-q.y}});}}
 if(right>w){const x=Math.max(w,v.x),underground=room.minecraft.biome!=='forest'||!!room.minecraft.grotto,edge=geometry.filter(q=>q.collision==='solid'&&!q.hidden&&q.x+q.w>=w&&q.y>0).sort((a,b)=>a.y-b.y)[0],top=underground?v.y:(edge?.y??floorY(room))+12;regions.push({kind:underground?'rock-wall':'distant-soil',x,y:Math.max(v.y,top),w:right-x,h:Math.max(0,bottom-Math.max(v.y,top))});}
 return regions.filter(q=>q.w>0&&q.h>0);
}
function drawMinecraftBoundary(c,room){
 const regions=minecraftBoundaryArtPlan(room);for(const q of regions){c.save();c.beginPath();c.rect(q.x,q.y,q.w,q.h);c.clip();
  if(q.kind==='strata'){drawMinecraftTile(c,q.source,room);}
  else{const kind=q.kind==='distant-soil'?'dirt':'stone';for(let y=Math.floor(q.y/16)*16;y<q.y+q.h;y+=16)for(let x=Math.floor(q.x/16)*16;x<q.x+q.w;x+=16)texture(c,kind,x,y,16,16,hash(x/16,y/16,131));c.globalAlpha*=q.kind==='depth'?.83:q.kind==='rock-wall'?.53:.48;rr(c,q.kind==='distant-soil'?'#19372e':'#102622',q.x,q.y,q.w,q.h);}
  c.restore();
 }
}
function forestBackdrop(c,room){
 const v=bounds(room),floor=floorY(room),cam=v.x,storm=!!stormOf(room)?.active;
 // Parallax positions are expressed back in world coordinates, so the ordinary
 // camera transform remains the only transform shared with the live renderer.
 if(storm){for(let i=Math.floor(cam*.16/110)-2;i<(cam*.16+v.w)/110+2;i++){const x=i*110+cam*.84+hash(i,11)%24,y=22+hash(i,12)%24;rr(c,'#263448',x,y,124,19);rr(c,'#344458',x+10,y-8,93,12);rr(c,'#405367',x+28,y-13,57,8);rr(c,'#1d2c40',x+8,y+16,112,7);}}else for(let i=Math.floor(cam*.16/150)-2;i<(cam*.16+v.w)/150+2;i++)skyCloud(c,i*150+cam*.84+hash(i,11)%40,35+hash(i,12)%28,45+hash(i,13)%28);
 // Far ridges are stepped voxel silhouettes, with quiet moss-lit ledges.
 for(let i=Math.floor(cam*.2/94)-2;i<(cam*.2+v.w)/94+2;i++){const x=i*94+cam*.8,h=52+hash(i,72)%55;rr(c,'#80a991',x,floor-h,96,h);rr(c,'#8eb39b',x+12,floor-h-14,64,15);rr(c,'#9abc9f',x+27,floor-h-23,35,10);rr(c,'#a5c6a8',x+27,floor-h-23,35,2);rr(c,'#739b88',x+70,floor-h+2,26,h-2);rr(c,'#759c89',x+12,floor-h+20,54,2);for(let n=0;n<3;n++){const xx=x+17+hash(i,n,18)%43,yy=floor-h+32+n*13;rr(c,'#86ad96',xx,yy,12+hash(n,i)%13,2);rr(c,'#779f8b',xx+4,yy+3,9,1);}}
 rr(c,'#82aa86',v.x,floor-36,v.w,36);
 for(let i=Math.floor(cam*.3/60)-2;i<(cam*.3+v.w)/60+2;i++){const x=i*60+cam*.7,y=floor-20-(hash(i,4)%12);tree(c,x,y, i%3?'oak':'birch',1.05+(hash(i,2)%3)*.15,2,hash(i,8));}
 rr(c,'#568465',v.x,floor-12,v.w,18);
 for(let i=Math.floor(cam*.55/75)-2;i<(cam*.55+v.w)/75+2;i++){const x=i*75+cam*.45,y=floor+8+(hash(i,5)%9);tree(c,x,y,i%4?'oak':'birch',1.1+(hash(i,3)%3)*.15,1,hash(i,4));}
 rr(c,'#3e674b',v.x,floor+4,v.w,24);
 if(storm){c.save();c.globalAlpha*=.28;rr(c,'#182c45',v.x,v.y,v.w,v.h);c.restore();}
}
function caveBackdrop(c,room){
 const v=bounds(room),floor=floorY(room),cam=v.x,nether=room.minecraft.biome==='nether';
 const wallX=cam*.12,wallLeft=Math.floor(wallX/24)*24;
 // The remote rock is a continuous formation, not a brick wall. Offset
 // mineral islands and interrupted sediment seams carry a much quieter value
 // range than playable terrain and the real mining timber in front of them.
 rr(c,nether?'#341923':'#23353d',v.x,v.y,v.w,v.h);
 for(let gy=Math.floor(v.y/18)*18-18;gy<v.y+v.h;gy+=18)for(let gx=Math.floor(wallX/30)*30-30;gx<wallX+v.w+30;gx+=30){
  const n=hash(gx/30,gy/18,71),x=gx+cam*.88,dy=gy+n%7;
  rr(c,(nether?['#3c1d27','#42202a','#361924']:['#293c43','#2b3e44','#20323b'])[n%3],x+2,dy,24,10);
  rr(c,nether?'#3c1d27':'#293c43',x+7,dy-4,15,5);
  if(n%4===0){rr(c,nether?'#28141e':'#1c2e37',x+5,dy+8,8,2);rr(c,nether?'#28141e':'#1c2e37',x+11,dy+10,6,1);}
  if(n%13===0){const p=nether?['#763a2b','#945033']:n%3?['#635f4b','#817956']:['#365c61','#4b7977'];for(const [dx,dy] of [[4,5],[9,7],[15,12],[7,17]]){rr(c,p[0],x+dx,gy+dy,3,2);rr(c,p[1],x+dx,gy+dy,1,1);}}
 }
 for(let band=0;band<8;band++)for(let i=Math.floor(wallX/38)-1;i<(wallX+v.w)/38+1;i++){const n=hash(i,band,93);if(n%4===0)continue;const x=i*38+cam*.88,y=band*41+12+(n%3)*2;rr(c,nether?'#4b282b':'#35494e',x,y,20+n%13,1);rr(c,nether?'#291722':'#20333b',x+8,y+2,18,1);}
 // Large cave piers and crooked stepped stalactites frame an open route.
 for(let i=Math.floor(cam*.25/116)-2;i<(cam*.25+v.w)/116+2;i++){
  const x=i*116+cam*.75,n=hash(i,119),reach=80+n%74;
  for(let step=0;step<6;step++){const width=70-step*10,top=step*15;rr(c,nether?'#49232b':'#30464c',x+step*5,top,width,reach-top-5*step);rr(c,nether?'#54282c':'#3b5155',x+step*5+2,top+1,2,Math.max(0,reach-top-5*step-3));}
  if(i%3===0){rr(c,nether?'#3d1e28':'#2c4249',x+82,60,20,floor-60);rr(c,nether?'#4c252d':'#354e52',x+83,61,3,floor-64);}
 }
 if(!nether){
  // Old mining galleries, brown timber braces, rails and green copper seams.
  for(let i=Math.floor(cam*.46/292)-1;i<(cam*.46+v.w)/292+1;i++){
   const x=i*292+cam*.54+32,base=floor-10,top=104+hash(i,41)%29,w=170;
   rr(c,'#354d50',x-6,top-10,w+20,base-top+12);rr(c,'#273b42',x+7,top+7,w-14,base-top-7);
   // Converging rear gallery frames and dim receding rails make the mine deep.
   rr(c,'#172c35',x+59,top+35,60,base-top-47);for(let k=0;k<3;k++){const inset=17+k*17,yy=top+12+k*11,ww=w-inset*2;rr(c,'#354a49',x+inset,yy,ww,3);rr(c,'#3d5049',x+inset,yy,3,base-yy-14);rr(c,'#273e3e',x+w-inset-3,yy,3,base-yy-14);}
   for(const side of [0,1])pixelBeam(c,x+(side?w-14:14),base-8,x+(side?113:65),top+74,1,'#465951');
   pixelBeam(c,x+8,top+8,x+59,top+35,2,'#4b5c51');pixelBeam(c,x+w-8,top+8,x+119,top+35,2,'#304542');
   for(const dx of [0,w]){rr(c,'#504b3d',x+dx,top,9,base-top);rr(c,'#6b6149',x+dx,top,2,base-top);for(let yy=top+8;yy<base;yy+=14){rr(c,'#383d35',x+dx+2,yy,6,2);rr(c,'#72664b',x+dx+1,yy+4,1,6);}}
   rr(c,'#635b44',x-4,top,w+17,9);rr(c,'#7b6e50',x-4,top,w+17,2);rr(c,'#383e35',x-3,top+8,w+15,2);
   for(let n=0;n<5;n++){rr(c,'#575241',x+8+n*4,top+9+n*4,5,5);rr(c,'#575241',x+w-4-n*4,top+9+n*4,5,5);}
   for(let dx=8;dx<w;dx+=15)rr(c,'#574f3c',x+dx,base-3,8,5);rr(c,'#777a63',x+9,base-3,w-18,1);rr(c,'#424d46',x+9,base,w-18,1);
   for(const [dx,dy] of [[42,48],[46,53],[51,51],[54,58]]){rr(c,'#416c60',x+dx,top+dy,4,3);rr(c,'#70937a',x+dx,top+dy,2,1);}
  }
 }else{
  for(let i=Math.floor(cam*.3/206)-1;i<(cam*.3+v.w)/206+1;i++){
   const x=i*206+cam*.7+90,y=45+hash(i,13)%42;
   rr(c,'#873a27',x,y,10,floor-y+20);rr(c,'#ad4b29',x+2,y,4,floor-y+20);rr(c,'#cc6a32',x+3,y+10,2,floor-y+5);
   for(let ly=y+8;ly<floor;ly+=19)rr(c,'#ed9c47',x+2,ly+(tickOf(room)/4)%19,5,2);
   const glowX=x+45;rr(c,'#4a252d',glowX+5,0,16,y+8);rr(c,'#60332f',glowX+6,0,2,y+6);for(const [dx,dy]of [[0,0],[8,0],[16,0],[8,8]]){rr(c,'#977347',glowX+dx,y+dy,8,8);rr(c,'#d6b16c',glowX+dx+1,y+dy+1,4,3);rr(c,'#e9cf88',glowX+dx+3,y+dy+3,3,3);}
  }
 }

 const p=nether?['#3a1b28','#4e252c','#5d2a2c','#6b3030']:['#24343d','#2d4249','#385158','#425b5c'];
 for(let layer=0;layer<3;layer++){
  const speed=.22+layer*.18,step=layer===2?44:68;
  for(let i=Math.floor(cam*speed/step)-2;i<(cam*speed+v.w)/step+2;i++){
   const x=i*step+cam*(1-speed),n=hash(i,layer+7),w=step+3,h=24+n%75,y=floor-h+(layer===0?-22:8);
   rr(c,p[layer],x,y,w,h+45);rr(c,p[layer+1],x+3,y,w-7,3);rr(c,p[layer],x+9,y-12,w-18,14);
   const top=26+n%35;rr(c,p[layer],x,-10,w,top);rr(c,p[layer],x+5,top-10,w*.48,12+n%18);rr(c,p[layer+1],x+6,top+2,w*.33,2);
   if(layer===1&&n%3===0){const glow=nether?'#be613d':'#537b7c';rr(c,glow,x+13,y+10,3,3);rr(c,glow,x+21,y+15,2,2);}
  }
 }
 if(nether){
  rr(c,'#8c382a',v.x,floor+10,v.w,25);for(let i=Math.floor((cam*.35)/22)-1;i<(cam*.35+v.w)/22+1;i++){const x=i*22+cam*.65,y=floor+12+hash(i,7)%12;rr(c,i%2?'#d76431':'#ac482a',x,y,16,2);}
  for(let i=0;i<26;i++){const x=v.x+((hash(i,73)%Math.ceil(v.w)+tickOf(room)*(.05+i%3*.02))%v.w),y=v.y+((hash(i,44)%Math.ceil(v.h)-tickOf(room)*.12+v.h*30)%v.h);rr(c,i%3?'#a9563c':'#da8d4a',x,y,1,i%4===0?2:1);}
 }
}
function secretDoorway(c,room,tick){
 const state=explorationOf(room);if(!state.pig?.gateOpen)return;
 const gate=room.map.geometry.find(q=>q.id===state.pig.gateId);if(!gate)return;
 const x=gate.x,y=gate.y,w=gate.w,h=gate.h;
 rr(c,'#263328',x,y+4,w,h-4);rr(c,'#182b26',x+3,y+5,w-6,h-5);rr(c,'#0d201e',x+6,y+8,w-12,h-8);rr(c,'#7d663e',x+4,y+h-3,w-8,3);rr(c,'#d6ad63',x+8,y+h-3,w-16,1);
 for(const dx of [0,w-4]){rr(c,'#5d452e',x+dx,y+5,4,h-5);rr(c,'#8b6b3c',x+dx+1,y+7,1,h-9);}rr(c,'#694f2e',x+2,y+1,w-4,6);rr(c,'#9c7b42',x+4,y+2,w-8,1);rr(c,'#416b32',x-1,y,9,4);rr(c,'#73913d',x+1,y,7,1);rr(c,'#416b32',x+w-8,y+2,9,5);
 for(let i=0;i<3;i++){const phase=(tick+i*17)%60;c.globalAlpha=(1-phase/60)*.6;rr(c,'#e6bd6b',x+8+i*7,y+h-6-phase*.2,1,1);}c.globalAlpha=1;
}
function burrowBackdrop(c,room){
 const v=bounds(room),floor=floorY(room),tick=tickOf(room);
 rr(c,'#4c4d34',v.x,v.y,v.w,v.h);
 // Small blocks and shallow roots close the sky, making the discovered pocket
 // feel intimate while every playable ledge stays with native geometry.
 for(let y=Math.floor(v.y/16)*16;y<floor+16;y+=16)for(let x=Math.floor(v.x/16)*16;x<v.x+v.w;x+=16){const n=hash(x/16,y/16,31);rr(c,['#5d5b3c','#686144','#555738','#6d6745'][n%4],x,y,16,16);rr(c,'#71744e',x+1,y+1,14,1);rr(c,'#444f3a',x+15,y+1,1,15);if(n%4===0){rr(c,'#798551',x+2,y+3,4,2);rr(c,'#455a37',x+9,y+8,4,3);}}
 const alpha=c.globalAlpha;
 for(const [cx,cy]of [[96,214],[292,224],[416,158]])for(let y=-80;y<=80;y+=4)for(let x=-80;x<=80;x+=4){const d=Math.hypot(x,y);if(d<84){c.globalAlpha=alpha*.15*(1-d/84);rr(c,'#ffd88a',cx+x,cy+y,4,4);}}c.globalAlpha=alpha;
 for(let i=0;i<12;i++){const x=i*46-12,depth=28+hash(i,16)%24;texture(c,'dirt',x,0,46,depth,i);grassTop(c,x,depth-4,46,i);const root=x+10+hash(i,8)%20;rr(c,'#60492e',root,depth-2,6,20);rr(c,'#87643b',root+1,depth,2,19);rr(c,'#60492e',root+4,depth+14,10,4);rr(c,'#60492e',root+12,depth+14,3,14);if(i%3===0){rr(c,'#355938',root+16,depth+4,1,40);for(let n=0;n<4;n++)rr(c,'#77944c',root+14-(n%2)*2,depth+10+n*8,5,3);}}
 const ceiling=room.map.geometry.filter(q=>q.y===0&&q.w>=room.map.width*.7).reduce((bottom,q)=>Math.max(bottom,q.h),48);
 for(const [rx,depth,width]of [[30,74,7],[104,36,5],[234,27,4],[380,43,5],[464,91,8]]){
  rr(c,'#4b412c',rx,ceiling-2,width,depth);rr(c,'#8b7040',rx+1,ceiling,width-3,depth-4);rr(c,'#a18a4a',rx+1,ceiling,1,depth-7);const dir=rx<256?1:-1;for(let n=0;n<3;n++){const x=rx+dir*(n*8),y=ceiling+depth-12+n*6;rr(c,'#5b4930',x,y,10,4);rr(c,'#876b3c',x,y,8,1);}
  if(width>5){const x=rx+(rx<256?12:-7);for(let n=0;n<7;n++){rr(c,'#4a6938',x+(n%2?2:0),ceiling+12+n*10,1,11);rr(c,n%2?'#6e8a40':'#83994b',x+(n%2?-2:1),ceiling+16+n*10,5,3);}}
 }
 for(let i=0;i<22;i++){const x=20+i*23,n=hash(i,3);smallPlant(c,{kind:'grass',x,y:floor,scale:1,variant:i%7===0?1:0},tick);if(n%3===0)rr(c,'#77984b',x+4,floor-11,2,3);}
 for(let i=0;i<9;i++){const x=32+hash(i,21)%446,y=72+hash(i,24)%168+Math.sin(tick*.025+i)*4;c.globalAlpha=.3+.25*Math.sin(tick*.04+i);rr(c,'#eddea0',x,y,1,1);}c.globalAlpha=alpha;
}
/** Door follows the same authored exit + walk distance as the stage finish. */
export function minecraftHomeCastleArtPlan(room={}){
 if(!isMinecraftRoom(room)||room.roomId!=='home')return null;
 const exit=room.map?.objects?.find(q=>q.kind==='exit');if(!exit)return null;
 const marker=room.markers?.find(q=>q.kind==='flagpole-finish'&&Math.abs(q.x-exit.x)<32);
 const target=exit.x+(marker?.source?.walkDistance||96),doorX=target+5,ground=localGround(room,doorX,exit.y)??exit.y+exit.h;
 return {x:doorX-42,y:ground-76,w:84,h:76,doorX,ground,walkTarget:target};
}
function homeCastle(c,room){
 const q=minecraftHomeCastleArtPlan(room);if(!q)return;const {x,y,ground,doorX}=q;
 const wall=(xx,yy,w,h)=>{rr(c,'#563c39',xx,yy,w,h);for(let by=0;by<h;by+=8)for(let bx=0;bx<w;bx+=12){const off=(by/8)%2?6:0,l=Math.max(0,bx-off),r=Math.min(w,bx+12-off);rr(c,(bx+by)%3?'#ba8064':'#a76b56',xx+l+1,yy+by+1,r-l-1,6);rr(c,'#d59c79',xx+l+1,yy+by+1,r-l-1,1);}};
 wall(x,y+28,84,48);wall(x+22,y+8,40,24);
 for(const dx of [0,12,24,48,60,72])wall(x+dx,y+20,10,10);
 for(const dx of [22,36,50])wall(x+dx,y,12,10);
 rr(c,'#e1b48a',x,y+30,84,3);rr(c,'#784e42',x,y+33,84,3);
 for(const wx of [x+12,x+65,x+36]){const wy=wx===x+36?y+13:y+43;rr(c,'#392f35',wx,wy,7,11);rr(c,'#edd0a1',wx-1,wy-1,9,2);}
 rr(c,'#e8c49c',doorX-11,ground-30,22,30);rr(c,'#3b3032',doorX-9,ground-28,18,28);rr(c,'#241f29',doorX-7,ground-30,14,30);rr(c,'#e8c49c',doorX-6,ground-32,12,2);
 rr(c,'#a68c72',x-3,ground-3,90,3);rr(c,'#342c30',doorX-9,ground-3,18,3);
}
/** Background decorative entities deliberately never modify collision. */
export function drawMinecraftScenery(c,room={}){
 if(drawFinaleScenery(c,room)){drawMinecraftBoundary(c,room);return true;}
 if(!isMinecraftRoom(room))return false;
 const tick=tickOf(room),v=bounds(room),priorFill=c.fillStyle,exploration=explorationOf(room),appleSpec=room.minecraft.exploration?.appleTree,branch=appleSpec&&room.map.geometry.find(g=>g.id===appleSpec.branchId);
 const fruitTree=branch?(room.minecraft.scenery||[]).filter(q=>['oak','birch'].includes(q.kind)).sort((a,b)=>Math.abs(a.x+39.6*(a.scale||1)-branch.x-branch.w/2)-Math.abs(b.x+39.6*(b.scale||1)-branch.x-branch.w/2))[0]:null;c.save();
 if(room.minecraft.grotto)drawGrottoScenery(c,room);else if(room.roomId==='burrow')burrowBackdrop(c,room);else if(room.minecraft.biome==='forest')forestBackdrop(c,room);else caveBackdrop(c,room);
 drawMinecraftBoundary(c,room);
 structureScenery(c,room);homeCastle(c,room);
 for(const [index,q] of (room.minecraft.scenery||[]).entries()){
  if(q.x>v.x+v.w+180||q.x+240<v.x||q.hidden)continue;
  if(q.kind==='oak'||q.kind==='birch'){tree(c,q.x,localGround(room,q.x+39.6*(q.scale||1),q.y-20)??q.y,q.kind,(q.scale||1)*1.65,0,index*3+(Number(q.variant)||0),q===fruitTree?exploration.treeShake||0:0);}
  else if(q.kind==='village')village(c,q);
  else if(q.kind==='pig')pig(c,{...q,y:localGround(room,q.x+13,q.y-20)??q.y},tick);
  else if(animalSizes[q.kind]&&!Array.isArray(room.minecraftView?.animals)){const size=animalSizes[q.kind],ground=localGround(room,q.x+size.w/2,q.y-16);if(ground!=null)animal(c,{...q,w:size.w,h:size.h,y:ground-size.h},tick);}
  else if(q.kind==='torch'){torchMount(c,room,q);if(q.variant!=='mine-light'||exploration.mineLights)torch(c,q.x,q.y,tick,q.scale||1);else{rr(c,'#4c4439',q.x-1,q.y+4,3,13);rr(c,'#76674c',q.x,q.y+4,1,12);rr(c,'#4e5850',q.x-2,q.y+1,5,5);}}
  else if(q.kind==='portal'){portalFooting(c,room,q);const locked=(room.minecraft.exploration?.lockedPortals||[]).some(lock=>{const obj=room.map.objects.find(o=>o.id===lock.portalId);return obj&&obj.x+obj.w>q.x&&obj.x<q.x+(q.w||48)&&!exploration.mineLights;});portal(c,q,tick,!locked);}
  else if(q.kind==='cave-mouth'){portalFooting(c,room,q);rr(c,'#25302d',q.x-8,q.y-q.h+8,q.w+16,q.h-8);rr(c,'#152323',q.x,q.y-q.h,q.w,q.h);rr(c,'#0c191c',q.x+8,q.y-q.h+8,q.w-8,q.h-8);rr(c,'#4c5347',q.x-8,q.y-q.h+8,8,q.h-8);}
  else if(q.kind==='mushroom'||q.kind==='grass'){const ground=localGround(room,q.x+4*(q.scale||1),q.y-12);if(ground!=null)smallPlant(c,{...q,y:ground},tick);}
 }
 villageFarm(c,room);
 secretDoorway(c,room,tick);
 if(branch&&appleSpec){const a=appleSpec;rr(c,'#5c442b',branch.x+branch.w-2,branch.y-1,Math.max(2,a.x+6-branch.x-branch.w),3);rr(c,'#8d6738',branch.x+branch.w-2,branch.y-1,Math.max(2,a.x+6-branch.x-branch.w),1);rr(c,'#60472e',a.x+5,Math.min(branch.y,a.y-3),2,Math.abs(branch.y-a.y)+4);}
 rail(c,room);
 // Soft, sparse square motes, never obscuring the player's contour.
 if(room.minecraft.biome==='forest'&&!stormOf(room)?.active)for(let i=0;i<11;i++){const x=v.x+(hash(i,45)%Math.ceil(v.w)+tick*.04)%v.w,y=v.y+50+(hash(i,46)%Math.max(1,Math.ceil(v.h-70))+tick*.025)%(Math.max(1,v.h-70));c.globalAlpha=.5;rr(c,i%3?'#d8d9a0':'#eff0c8',x,y,1,1);}c.restore();c.fillStyle=priorFill;return true;
}
function creeper(c,q,tick){
 const w=q.w||16,h=q.h||28,flash=q.flash===true||q.state==='fuse'&&Math.floor((q.fuse||0)/5)%2===0;
 c.save();c.translate(Math.round(q.x),Math.round(q.y));c.scale(w/16,h/28);
 const p=flash?['#e1e9cc','#ffffff','#b9c8aa','#d1dfbc']:['#5b9b42','#91bb60','#2d6033','#76aa4d'];
 const mottled=(x,y,width,height,seed)=>{rr(c,p[0],x,y,width,height);for(let yy=0;yy<height;yy+=2)for(let xx=0;xx<width;xx+=2){const n=hash(xx,yy,seed);rr(c,p[n%4],x+xx,y+yy,Math.min(2,width-xx),Math.min(2,height-yy));}};
 mottled(4,11,8,13,27);rr(c,p[2],11,12,2,12);
 const stride=q.state==='chase'?Math.floor(tick/7)%2:0;
 for(const [x,dy]of [[2,-stride],[10,stride]]){mottled(x,21+dy,4,6-dy,x);rr(c,p[2],x,26,4,1);}
 for(const [x,dy]of [[0,stride],[9,-stride]]){mottled(x,22+dy,6,6-dy,x+9);rr(c,p[2],x,27,6,1);}
 mottled(1,0,14,12,41);rr(c,p[2],14,1,2,11);rr(c,p[1],1,0,13,1);
 // The face uses the characteristic stepped dark eye/nose/mouth mask.
 rr(c,'#11251d',3,3,3,3);rr(c,'#11251d',10,3,3,3);rr(c,'#11251d',6,5,4,5);rr(c,'#11251d',4,7,8,3);rr(c,'#11251d',4,9,2,2);rr(c,'#11251d',10,9,2,2);rr(c,p[0],6,9,4,2);
 if(q.state==='fuse'){const ratio=clamp((q.fuse||0)/(q.fuseTicks||90),0,1);rr(c,'#253126',-2,-6,20,3);rr(c,ratio<.35?'#ff9e59':'#c7dc86',-1,-5,18*(1-ratio),1);}
 c.restore();
}
// One enchanted trident and a raised shield are the entire equipment set.
// These render plans only project state; they never grant or move equipment.
export function minecraftGearArtPlan(room={},view=room.minecraftView){
 const state=view?.minecraft||view||{},gear=state.gear;
 const stands=(gear?.stands||room.minecraft?.gear?.stands||[]).filter(q=>(q.heal||0)>0||room.minecraft?.biome==='end'&&q.loyaltyTrident).map(q=>({...q,w:q.w||24,h:q.h||32,footY:q.y+(q.h||32),available:q.available??!q.taken,tridentRack:room.minecraft?.biome==='end'&&!!q.loyaltyTrident}));
 return {stands,gear,weapon:gear?.loyaltyTrident?'loyalty-trident':null};
}
function gearLine(c,x1,y1,x2,y2,color,width=1){pixelBeam(c,x1,y1,x2,y2,width,color);}
/** Axis-local trident points right. Rotation follows the actual velocity. */
function tridentSprite(c,x,y,angle=0,tick=0,returning=false,scale=1){
 c.save();c.translate(Math.round(x),Math.round(y));c.rotate(angle);c.scale(scale,scale);
 // Long wrapped shaft, crossbar and three separate square prongs.
 rr(c,'#17454e',-13,-1,22,3);rr(c,'#77c9c0',-12,-1,20,1);rr(c,'#458f91',-12,1,20,1);
 for(const xx of [-10,-6,-2])rr(c,'#abcfc5',xx,-1,1,3);
 rr(c,'#1d5d65',6,-6,4,13);rr(c,'#74d6c9',7,-5,2,11);rr(c,'#b5f2dc',7,-5,1,11);
 for(const yy of [-6,0,6]){rr(c,'#195560',8,yy-1,8,3);rr(c,'#8ee4d5',9,yy-1,7,1);rr(c,'#c6f9e6',15,yy-2,2,3);}
 // Diagonal purple bands move through the actual local shaft/crossbar/prong
 // silhouette. The same rotation applies to metal and glint; no glowing box
 // fills the air between prongs or invents an idle-hand weapon.
 const silhouette=[[-13,-1,22,3],[6,-6,4,13],...[-6,0,6].flatMap(yy=>[[8,yy-1,8,3],[15,yy-2,2,3]])];
 paintMinecraftEnchantmentGlint(c,silhouette,tick,{strength:returning?.4:.34});
 c.restore();
}
function shieldSprite(c,x,y,facing=1,{tone='normal',scale=1,flash=0}={}){
 c.save();c.translate(Math.round(x),Math.round(y));c.scale(facing*scale,scale);
 const edge=tone==='parry'?'#99edff':tone==='block'?'#efc76e':'#9dbab9',shine=tone==='parry'?'#efffff':tone==='block'?'#fff2ad':'#dce1c5';
 rr(c,'#23373b',-5,-10,11,16);rr(c,'#23373b',-4,6,9,3);rr(c,'#23373b',-2,9,5,2);
 rr(c,edge,-4,-9,9,15);rr(c,edge,-3,6,7,2);rr(c,edge,-1,8,3,2);
 rr(c,'#735735',-2,-7,5,13);rr(c,'#b78d4b',-2,-7,1,12);rr(c,'#947040',0,-7,2,14);rr(c,'#51452f',3,-7,1,12);
 rr(c,shine,-4,-9,8,1);rr(c,shine,4,-8,1,13);rr(c,'#4f686b',-4,-6,1,11);
 rr(c,'#394f52',-2,-1,5,3);rr(c,edge,-1,-1,3,2);rr(c,shine,0,-1,1,1);
 if(flash>0){const spread=2+Math.floor((18-Math.min(18,flash))/5);gearLine(c,8,-11-spread,11+spread,-4,edge,2);gearLine(c,11+spread,-4,11+spread,5,shine,2);gearLine(c,11+spread,5,7,11+spread,edge,2);if(tone==='parry'){rr(c,shine,14,-7,1,7);rr(c,shine,11,-4,7,1);rr(c,edge,9,12,2,2);}}
 c.restore();
}
export function minecraftGuardArtPlan(room={},view={}){
 const state=view?.minecraft||view||{},gear=state.gear||room.minecraftView?.gear,p=view.p||view.player||room.playerView,guard=gear?.guard;
 if(!isMinecraftRoom(room)||!p||p.dead||p.dying||!gear?.shield||!guard?.active)return null;
 const facing=guard.facing<0?-1:1;
 return {x:p.x+p.w/2+facing*9,y:p.y+p.h*.51,facing,flash:guard.flash||0,tone:guard.flash>0?(guard.flashKind==='parry'?'parry':'block'):(guard.parryTicks>0?'parry':'normal')};
}
/** The perfect-parry burst is directional and local to the shield. */
export function minecraftParryArtPlan(guard){
 if(!guard||guard.tone!=='parry'||!(guard.flash>0))return null;
 const age=18-Math.min(18,guard.flash),f=guard.facing<0?-1:1,r=10+age*.8,cx=guard.x+f*8,cy=guard.y;
 const ring=(radius)=>[[0,-radius],[radius*.7,-radius*.7],[radius,0],[radius*.7,radius*.7],[0,radius],[-radius*.22,radius*.55],[-radius*.22,-radius*.55]].map(([x,y])=>({x:cx+f*x,y:cy+y}));
 return {x:cx,y:cy,facing:f,age,alpha:clamp(1-age/24,.2,1),rings:[ring(r),ring(r+5)],rays:[-.8,-.4,0,.4,.8].map(a=>({x1:cx+f*Math.cos(a)*r,y1:cy+Math.sin(a)*r,x2:cx+f*Math.cos(a)*(r+7),y2:cy+Math.sin(a)*(r+7)})),trail:[0,1,2].map(i=>({x:cx-f*(9+i*5),y:cy-4+i*4,w:5-i,h:1}))};
}
function parryBurst(c,guard){const p=minecraftParryArtPlan(guard);if(!p)return;c.save();c.globalAlpha*=p.alpha;
 for(const [i,ring]of p.rings.entries()){for(let n=0;n<ring.length;n++){const a=ring[n],b=ring[(n+1)%ring.length];gearLine(c,a.x,a.y,b.x,b.y,i?'#62bdda':'#d2f9ff',i?1:2);}}
 for(const ray of p.rays)gearLine(c,ray.x1,ray.y1,ray.x2,ray.y2,'#f3fff0',1);
 for(const q of p.trail)rr(c,'#91dff0',q.x,q.y,q.w,q.h);
 rr(c,'#ffffff',p.x-1,p.y-4,2,8);rr(c,'#e8ffff',p.x-4,p.y-1,8,2);c.restore();
}
export function minecraftThrowArtPlan(room={},view={}){
 const state=view?.minecraft||view||{},gear=state.gear||room.minecraftView?.gear,p=view.p||view.player||room.playerView;
 if(!isMinecraftRoom(room)||!p||p.dead||p.dying||!gear?.loyaltyTrident||gear.guard?.active)return null;
 const windup=gear.windup;if(windup?.remaining>0)return {x:p.x+p.w/2,y:p.y+p.h*.43,facing:windup.facing<0?-1:1,stage:'windup',progress:clamp(1-windup.remaining/Math.max(1,windup.total||1),0,1),age:(windup.total||windup.remaining)-windup.remaining,angle:Number.isFinite(windup.angle)?windup.angle:0};
 const q=(gear.projectiles||[]).find(q=>!q.dead&&q.kind==='loyalty-trident');
 if(!q||q.state!=='flying'||!Number.isFinite(q.age)||q.age<0||q.age>7)return null;
 return {x:p.x+p.w/2,y:p.y+p.h*.43,facing:p.facing<0?-1:1,age:q.age,angle:Number.isFinite(q.angle)?q.angle:0};
}
// Retained export for old consumers; legacy starter-sword state never paints.
export function minecraftSwordArtPlan(){return null;}
function throwArm(c,q){
 c.save();c.translate(Math.round(q.x),Math.round(q.y));c.scale(q.facing,1);
 if(q.stage==='windup'){
  // Only the real queued throw owns this raised-back weapon. Empty hands
  // return as soon as the controller launches the single outgoing trident.
  const handX=-5-q.progress*3,handY=-5-q.progress*3;tridentSprite(c,handX-3,handY-2,-Math.PI*.22-q.progress*.1,q.age,false,.78);
  pixelBeam(c,1,2,handX,handY,4,'#9f342b');pixelBeam(c,1,1,handX,handY-1,2,'#e4513b');rr(c,'#624b3d',handX-2,handY-2,5,5);rr(c,'#f3ead4',handX-2,handY-2,4,4);rr(c,'#fff7df',handX-1,handY-2,3,1);c.restore();return;
 }
 // A short Mario sleeve/glove follow-through, never another held trident.
 const lift=q.age<3?-4:q.age<6?-2:0;
 pixelBeam(c,2,2,7,lift,4,'#9f342b');pixelBeam(c,2,1,7,lift-1,2,'#e4513b');rr(c,'#624b3d',7,lift-3,5,5);rr(c,'#f3ead4',7,lift-3,4,4);rr(c,'#fff7df',8,lift-3,3,1);c.restore();
}
/** Must be called after Mario, within the same portal clip and camera transform. */
export function drawMinecraftForeground(c,room={},view={}){
 if(!isMinecraftRoom(room))return false;
 const state=view?.minecraft||view||{},gear=state.gear||room.minecraftView?.gear,p=view.p||view.player||room.playerView;
 if(!gear||!p||p.dead||p.dying)return true;
 const priorFill=c.fillStyle;c.save();const guard=minecraftGuardArtPlan(room,view);
 if(guard){shieldSprite(c,guard.x,guard.y,guard.facing,guard);parryBurst(c,guard);}
 else{const pose=minecraftThrowArtPlan(room,view);if(pose)throwArm(c,pose);}
 c.restore();c.fillStyle=priorFill;return true;
}
function healingTable(c,q,tick){
 const x=q.x,bottom=q.footY,top=bottom-12;
 // Low potion table: both feet terminate at the real authored ground line.
 for(const dx of [2,19]){rr(c,'#493b2c',x+dx,top+2,4,10);rr(c,'#a37d47',x+dx,top+3,1,8);rr(c,'#66523a',x+dx-1,bottom-2,6,2);}
 rr(c,'#45382c',x-1,top,26,4);rr(c,q.available?'#b49157':'#786547',x,top,24,2);rr(c,q.available?'#d9ba7b':'#9b855e',x+1,top,22,1);rr(c,'#5a4b38',x+3,bottom-5,18,2);
 rr(c,'#665a45',x+8,top-1,10,1);
 if(q.available){rr(c,'#63858b',x+8,top-10,10,10);rr(c,'#bed6d0',x+9,top-10,8,9);rr(c,'#bed6d0',x+11,top-14,4,5);rr(c,'#876442',x+10,top-15,6,2);rr(c,'#dd6379',x+10,top-6,6,5);rr(c,'#f7a4ad',x+10,top-6,2,4);rr(c,'#f3f5da',x+10,top-9,1,3);rr(c,'#ecf5df',x+12,top-12,1,3);
  const pulse=(tick+(q.age||0))%40;if(pulse<17){rr(c,'#bfdcff',x+21,top-14,1,5);rr(c,'#a2bafa',x+19,top-12,5,1);}
 }else if(q.respawnTicks>0){const progress=clamp(1-q.respawnTicks/(q.renewTicks||600),0,1);rr(c,'#3e4140',x+7,top+2,11,1);rr(c,'#88a797',x+7,top+2,11*progress,1);}
}
function endTridentRack(c,q,tick){
 const x=q.x,bottom=q.footY;
 // Obsidian footing and two metal hooks stay after pickup. The enchanted
 // three-pronged weapon itself is visible only while the End grant is live.
 rr(c,'#4b3f54',x-2,bottom-4,28,4);rr(c,'#9785a1',x-1,bottom-4,26,1);rr(c,'#695b72',x-2,bottom-1,28,1);
 for(const dx of [3,18]){rr(c,'#342b42',x+dx,bottom-32,3,28);rr(c,'#75647d',x+dx,bottom-32,1,26);rr(c,'#a394a1',x+dx-2,bottom-23,6,2);rr(c,'#b1a5ad',x+dx-2,bottom-11,6,2);}
 rr(c,'#594760',x+3,bottom-30,18,2);rr(c,'#97829a',x+3,bottom-30,18,1);
 if(!q.weaponTaken&&(q.available||q.weaponTaken===false))tridentSprite(c,x+12,bottom-18,-Math.PI/2,tick,false,.83);
 if((q.heal||0)>0){rr(c,'#716079',x+18,bottom-7,9,2);if(q.available){rr(c,'#b9d6d3',x+20,bottom-15,6,8);rr(c,'#bed6d0',x+22,bottom-18,2,4);rr(c,'#98704b',x+21,bottom-19,4,2);rr(c,'#df6b89',x+21,bottom-12,4,4);rr(c,'#ffe9e7',x+21,bottom-14,1,3);}}
}
function drawGearWorld(c,room,state,tick){
 const {stands,gear}=minecraftGearArtPlan(room,state),v=bounds(room);for(const q of stands)if(q.x+54>=v.x&&q.x-2<=v.x+v.w)(q.tridentRack?endTridentRack:healingTable)(c,q,tick);if(!gear)return;
 // The controller permits only one live trident; stale legacy ammo never paints.
 const q=(gear.projectiles||[]).find(q=>!q.dead&&q.kind==='loyalty-trident');
 if(q&&q.x+48>=v.x&&q.x-32<=v.x+v.w){const x=q.x+(q.w||0)/2,y=q.y+(q.h||0)/2,angle=Number.isFinite(q.angle)?q.angle:Math.atan2(q.vy||0,q.vx||1),returning=q.state==='returning',ux=Math.cos(angle),uy=Math.sin(angle);
  c.save();for(let i=1;i<=(returning?6:4);i++){c.globalAlpha=.65-i*.075;rr(c,i%2?'#8bcfff':'#c6a8ff',x-ux*(12+i*5)-1,y-uy*(12+i*5)-1,returning?3:2,2);}c.globalAlpha=1;tridentSprite(c,x,y,angle,tick+(q.age||0),returning);c.restore();
 }
 for(const q of gear.effects||[]){const t=clamp((q.age||0)/Math.max(1,(q.age||0)+(q.life||0)),0,1);c.save();c.globalAlpha*=1-t;
  if(q.kind==='healing-heart'){heart(c,q.x-2,q.y-10,1.2);rr(c,'#ffe8ed',q.x,q.y-9,1,1);}
  else for(let i=0;i<6;i++){const a=i*2.399,dist=3+t*11;rr(c,q.color||'#95c5ef',q.x+Math.cos(a)*dist,q.y+Math.sin(a)*dist-t*4,1+i%2,1+i%2);}c.restore();}

}
function gearHud(c,gear,draw,tick,maxHealth=3){
 if(!gear||(!gear.loyaltyTrident&&!gear.shield))return;
 const weapon=gear.loyaltyTrident;c.save();c.translate(0,Math.max(0,Math.ceil(minecraftHealthArtPlan(0,maxHealth).length/6)-1)*12);rr(c,'rgba(15,29,26,.74)',8,28,weapon?104:68,19);
 if(gear.loyaltyTrident){tridentSprite(c,20,37,-Math.PI/4,tick,!!gear.trident,.46);draw(c,'K',33,33,gear.trident?'#8299ad':'#d4eaf0');if(gear.trident){rr(c,'#bcb6f5',13,44,25,1);rr(c,'#d8e2ff',13,42,2,2);}}
 if(gear.shield){if(!weapon)c.translate(-36,0);const g=gear.guard||{},broken=g.reason==='exhausted'||g.reason==='impact',color=broken&&g.cooldown>0?'#e76a68':g.flash>0&&g.flashKind==='block'?'#e8c46e':g.flashKind==='parry'&&g.flash>0||g.parryTicks>0?'#92e4ff':g.active?'#bfddc1':'#99b4ad';if(weapon)rr(c,'#465c57',45,31,1,13);shieldSprite(c,56,37,1,{scale:.55,tone:g.flash>0?g.flashKind:'normal'});draw(c,'L',66,33,color);rr(c,'#3b484b',79,34,26,5);rr(c,color,80,35,24*clamp((g.stamina??100)/(g.maxStamina||100),0,1),3);if(g.cooldown>0){rr(c,broken?'#a1454a':'#657b89',80,42,24,1);rr(c,broken?'#f3a39a':'#adc4d2',80,42,24*(1-clamp(g.cooldown/(broken?90:18),0,1)),1);}if(broken&&g.cooldown>0){rr(c,'#f5aba1',86,33,1,7);rr(c,'#f5aba1',95,33,1,7);}}
 c.restore();
}
export function minecraftHealthArtPlan(health=0,max=3){return Array.from({length:Math.max(1,Math.floor(Number.isFinite(max)?max:3))},(_,i)=>clamp(Math.floor((health-i)*2+.00001),0,2));}
function healthHearts(c,health,max=3,gear={},tick=0,upgradePulse=0){
 const count=minecraftHealthArtPlan(health,max).length;for(let row=0;row<Math.ceil(count/6);row++)rr(c,'rgba(20,28,37,.64)',92,7+row*12,7+Math.min(6,count-row*6)*12,17);
 for(const [i,halves]of minecraftHealthArtPlan(health,max).entries()){const x=96+(i%6)*12,y=11+Math.floor(i/6)*12;
  const paint=(body,light)=>{rr(c,body,x,y+1,8,4);rr(c,light,x+1,y,2,2);rr(c,light,x+5,y,2,2);rr(c,body,x+1,y+5,6,1);rr(c,body,x+2,y+6,4,1);rr(c,body,x+3,y+7,2,1);};
  if(upgradePulse>0&&i===count-1){c.save();c.globalAlpha*=Math.min(1,upgradePulse/15)*(.45+.2*Math.sin(tick*.5));rr(c,'#e1bb64',x-1,y,10,9);rr(c,'#ffe9a8',x-1,y-1,10,1);c.restore();}
  paint('#4f4455','#69556b');if(halves){c.save();c.beginPath();c.rect(x,y,halves===1?4:8,8);c.clip();paint('#df5b68','#ff9b9f');rr(c,'#ffe1ca',x+1,y+1,1,1);c.restore();}
  if(halves&&gear.healPulse>0&&i>=Math.floor(Math.max(0,health-(gear.healAmount||1)))){c.save();c.globalAlpha*=Math.min(1,gear.healPulse/15)*(.45+.35*Math.sin(tick*.6+i));const sx=x+4+(i%2?3:0),sy=y-2;rr(c,'#ffe4ee',sx,sy-1,1,3);rr(c,'#ffaccc',sx-1,sy,3,1);rr(c,'#ffd2e4',x+8,y+5,1,1);c.restore();}
 }
}
/** Roof occlusion uses live solid surfaces, so rain cannot pass through cover. */
export function minecraftStormArtPlan(room={},view=room.minecraftView){
 const storm=stormOf(room,view),v=bounds(room);if(!storm?.active)return {active:false,drops:[],lightning:[]};
 const geometry=room.playGeometry||room.geometry||room.map?.geometry||storm.shelters||[],solids=geometry.filter(q=>!q.hidden&&!q.removed&&q.visible!==false&&(q.collision==='solid'||q.collision==null)),tick=storm.age??tickOf(room),drops=[];
 for(let col=Math.floor((v.x-12)/11);col<Math.ceil((v.x+v.w+12)/11);col++){
  const x=col*11+hash(col,81)%8,roof=solids.filter(q=>x+2>=q.x&&x<=q.x+q.w).reduce((y,q)=>Math.min(y,q.y),room.map?.height||v.y+v.h),span=room.map?.height||384;
  for(let row=0;row<3;row++){const y=((hash(col,row,41)%span+tick*5.6+row*span/3)%(span+24))-18,len=7+hash(col,row,13)%7;if(y+len<Math.min(roof,v.y+v.h)&&y>v.y-16)drops.push({x,y,len,roof,bright:(col+row)%4===0});}
 }
 return {active:true,drops,lightning:(storm.lightning||[]).filter(q=>q.age>=0&&q.age<10),storm};
}
function stormRain(c,room,state){
 const plan=minecraftStormArtPlan(room,state);if(!plan.active)return;c.save();
 for(const q of plan.drops){c.globalAlpha=q.bright?.62:.38;for(let n=0;n<q.len;n+=3)rr(c,q.bright?'#b8daea':'#83acc6',q.x+Math.floor(n/5),q.y+n,1,Math.min(3,q.len-n));}
 c.restore();
}
function zombie(c,q,tick){
 if(q.dead)return;c.save();c.translate(Math.round(q.x+(q.facing<0?18:0)),Math.round(q.y));c.scale(q.facing<0?-1:1,1);
 const stride=Math.abs(q.vx||0)>.01?Math.floor((q.age??tick)/9)%2:0;
 rr(c,'#243b47',4,10,10,13);rr(c,'#358e95',5,10,8,12);rr(c,'#65b0a7',5,10,8,2);rr(c,'#226c7e',11,12,3,10);
 rr(c,'#275b69',1,12,4,11);rr(c,'#559047',1,21,4,4);rr(c,'#416c36',1,24,4,1);
 for(const [x,dy]of [[4,stride],[10,-stride]]){rr(c,'#514a7c',x,22,5,9-dy);rr(c,'#76688f',x,22,2,7-dy);rr(c,'#343748',x,30-dy,5,2);}
 rr(c,'#2e622f',4,0,11,10);rr(c,'#659443',4,0,10,9);rr(c,'#83aa58',4,0,10,2);rr(c,'#4d7a37',11,2,4,7);rr(c,'#739c4c',6,3,3,2);
 rr(c,'#1e3b2b',8,3,2,2);rr(c,'#1e3b2b',12,3,2,2);rr(c,'#3c5b2e',10,5,3,2);rr(c,'#283d2c',8,7,5,1);rr(c,'#96a866',9,7,2,1);
 // A square outstretched forearm gives the zombie a readable silhouette.
 rr(c,'#2a7985',11,12,7,5);rr(c,'#54a5a1',11,12,6,1);rr(c,'#6d9c4a',15,13,3,4);rr(c,'#9ab968',15,13,3,1);
 c.restore();
}
function stormActors(c,room,state,tick){
 const storm=stormOf(room,state);if(!storm?.active)return;
 for(const q of storm.zombies||[])zombie(c,q,tick);
 for(const q of storm.effects||[]){if(q.kind!=='zombie-defeat')continue;const t=clamp(q.age/36,0,1);c.save();c.globalAlpha*=1-t;for(let i=0;i<15;i++){const a=i*2.399,r=3+t*21;rr(c,['#a7b978','#74944c','#719dba'][i%3],q.x+9+Math.cos(a)*r,q.y+16+Math.sin(a)*r-t*13,2,2);}c.restore();}
}
function stormLightning(c,room,state){
 const {active,lightning}=minecraftStormArtPlan(room,state);if(!active||!lightning.length)return;const v=bounds(room);c.save();
 const flash=Math.max(...lightning.map(q=>(1-q.age/10)**2));c.globalAlpha*=flash*.12;rr(c,'#d9eaff',v.x,v.y,v.w,v.h);
 for(const q of lightning){const power=1-q.age/10,start=Math.min(-16,v.y-16),height=q.y-start,points=[[q.x-12,start]];for(let i=1;i<8;i++){const y=start+height*i/8,offset=(hash(i,Math.floor(q.x),29)%33)-16;points.push([q.x+offset,y]);}points.push([q.x,q.y]);
  c.globalAlpha=power*.52;for(let i=1;i<points.length;i++)gearLine(c,...points[i-1],...points[i],'#88adff',7);
  c.globalAlpha=power;for(let i=1;i<points.length;i++)gearLine(c,...points[i-1],...points[i],'#efffff',2);
  const fork=points[3];c.globalAlpha=power*.74;gearLine(c,fork[0],fork[1],fork[0]+23,fork[1]+20,'#c8deff',2);gearLine(c,fork[0]+23,fork[1]+20,fork[0]+17,fork[1]+36,'#c8deff',1);
  rr(c,'#e7faff',q.x-10,q.y-2,21,2);rr(c,'#a3d4ff',q.x-15,q.y-4,5,1);rr(c,'#a3d4ff',q.x+11,q.y-4,5,1);rr(c,'#ffffff',q.x-2,q.y-9,4,9);
 }
 c.restore();
}

function capacityHeart(c,q,tick){
 if(!q||q.hidden||q.visible===false)return;const x=Math.round(q.x),y=Math.round(q.y),age=q.collectedAge??q.age??0;
 c.save();
 if(q.collected){const t=clamp(age/42,0,1);c.globalAlpha*=1-t;if(t<1)for(let i=0;i<8;i++){const a=i*Math.PI/4,r=4+t*19,px=x+6+Math.cos(a)*r,py=y+6+Math.sin(a)*r-t*12;if(i%2)heart(c,px-2,py-2);else{rr(c,'#ffe0a0',px,py-2,1,5);rr(c,'#ffe0a0',px-2,py,5,1);}}c.restore();return;}
 // Twelve-pixel physical heart container, with an unmistakable gold perimeter.
 for(const [dy,dx,w]of [[0,2,3],[0,7,3],[1,1,10],[2,0,12],[3,0,12],[4,0,12],[5,0,12],[6,1,10],[7,2,8],[8,3,6],[9,4,4],[10,5,2],[11,5,2]])rr(c,'#c49743',x+dx,y+dy,w,1);
 rr(c,'#fff0b2',x+2,y,3,1);rr(c,'#fff0b2',x+7,y,3,1);rr(c,'#f7d87b',x+1,y+2,1,4);rr(c,'#a25d3b',x+10,y+3,1,3);
 for(const [dy,dx,w]of [[1,2,3],[1,7,3],[2,1,10],[3,1,10],[4,1,10],[5,2,8],[6,2,8],[7,3,6],[8,4,4],[9,5,2]])rr(c,dy<4?'#ea6682':'#c74267',x+dx,y+dy,w,1);
 rr(c,'#ffb8c7',x+2,y+2,2,2);rr(c,'#ffe5da',x+2,y+2,1,1);rr(c,'#aa3158',x+8,y+4,2,2);
 const phase=Math.floor(tick/8)%4;if(phase<2){rr(c,'#ffecb5',x+11,y-3,1,3);rr(c,'#ffecb5',x+10,y-2,3,1);}c.restore();
}
/** The live controller owns fuse, explosion ages and every falling sand body. */
export function drawMinecraftWorld(c,room={},view=room.minecraftView){
 const priorFill=c.fillStyle;
 drawGrottoWorld(c,room,view);drawFinaleWorld(c,room,view);
 if(!isMinecraftRoom(room))return false;
 const state=view?.minecraft||view||{},tick=tickOf(room),v=bounds(room),exploration=state.exploration||{};c.save();
 stormRain(c,room,state);stormActors(c,room,state,tick);drawGearWorld(c,room,state,tick);
 const villagePlan=minecraftVillageArtPlan(room,state);villageLeash(c,villagePlan);
 wildEndermanWorld(c,room,state,tick);
 for(const q of state.capacityRewards||[])if(q.kind==='heart-container'&&q.x+32>=v.x&&q.x-20<=v.x+v.w)capacityHeart(c,q,tick);
 for(const q of minecraftAnimalArtPlan(room,state))if(q.x+q.w>=v.x&&q.x<=v.x+v.w)animal(c,q,tick);
 for(const q of minecraftVillagerArtPlan(room,state))if(q.x+24>=v.x&&q.x-8<=v.x+v.w)villager(c,q,tick);
 if(exploration.golem)ironGolem(c,minecraftIronGolemArtPlan(room,state),tick);else if(exploration.enderman)enderman(c,exploration.enderman,tick);
 if(exploration.railZombie)zombie(c,exploration.railZombie,tick);
 if(exploration.cart)minecart(c,exploration.cart,tick);
 if(exploration.pig&&!exploration.pig.dead)pig(c,{...exploration.pig,y:exploration.pig.y+exploration.pig.h},tick);
 for(const q of exploration.fleePigs||[])if(!q.dead)pig(c,{...q,y:q.y+q.h},tick);
 villageTradeOffer(c,villagePlan,tick);
 apple(c,exploration.apple,tick);
 tinyPortalKey(c,exploration.nearPortal,tick);
 for(const q of state.creepers||[])if(!q.dead&&q.state!=='exploded'&&q.x+q.w>=v.x-20&&q.x<=v.x+v.w+20)creeper(c,q,tick);
 for(const q of state.effects||[]){
  const life=q.life||30,t=clamp((q.age||0)/life,0,1),x=q.x+(q.w||0)/2,y=q.y+(q.h||0)/2;
  if(q.kind==='explosion'){
   if(t<.2){c.globalAlpha=(1-t/.2)*.7;rr(c,'#fff5c0',x-16,y-16,32,32);}
   for(let i=0;i<14;i++){const angle=i*2.399,dist=4+t*(22+hash(i,4)%22),px=x+Math.cos(angle)*dist,py=y+Math.sin(angle)*dist-t*14,size=Math.max(2,8-t*6);c.globalAlpha=1-t;rr(c,i%3===0?'#ffe8a0':i%2?'#d0cab0':'#6c6b60',px-size/2,py-size/2,size,size);}
  }else if(q.kind==='enderman-teleport'||q.kind==='teleport'||q.kind==='ore-spark'&&q.color==='#be86e6'){for(let i=0;i<18;i++){const px=x+(hash(i,91)%29-14)*(1+t),py=y+(hash(i,11)%49-24)-t*15;c.globalAlpha=1-t;rr(c,i%3?'#b46bd3':'#ebaff1',px,py,1+i%2,2);}
  }else if(q.kind==='heart'){c.globalAlpha=1-t;heart(c,x,y-t*16,1.4);
  }else if(q.kind==='leaf-burst'){for(let i=0;i<9;i++){const dx=(hash(i,4)%25-12)*(1+t*2),dy=-(8+hash(i,8)%14)*Math.sin(t*Math.PI)+t*18;c.globalAlpha=1-t;rr(c,['#84a848','#b4bf5b','#507e37'][i%3],x+dx,y+dy,i%2?2:3,2);}
  }else if(q.kind==='ore-spark'||q.kind==='reward-coin'){c.globalAlpha=1-t;for(let i=0;i<5;i++){const dx=Math.sin(i*2.4)*(4+t*15),dy=Math.cos(i*2.4)*(4+t*15)-t*12;rr(c,q.kind==='reward-coin'?'#f8dd7c':'#a1f1b2',x+dx,y+dy,1,3);rr(c,q.kind==='reward-coin'?'#fff1b2':'#d5f5cc',x+dx-1,y+dy+1,3,1);}
  }else{
   for(let i=0;i<8;i++){const dx=(hash(i,4)%21-10)*(1+t),dy=-(5+hash(i,8)%17)*Math.sin(t*Math.PI);c.globalAlpha=1-t;rr(c,q.kind==='sand-dust'?'#d9c38b':['#766348','#ab8f5f','#56614b'][i%3],x+dx,y+dy,2,2);}
  }
 }
 stormLightning(c,room,state);c.restore();c.fillStyle=priorFill;return true;
}
/** Native HUD remains compact and shares the retained Mario/coin counters. */
export function drawMinecraftHud(c,v,room,text){
 if(!isMinecraftRoom(room))return false;
 c.save();rr(c,'rgba(15,29,26,.55)',8,7,80,17);
 // Tiny Mario cap / face icon and the native counters, with no tutorial panel.
 rr(c,'#d84c35',13,10,7,2);rr(c,'#ed6744',12,12,10,2);rr(c,'#6e432d',13,14,2,4);rr(c,'#efbd85',15,14,6,5);rr(c,'#31362d',19,14,1,2);rr(c,'#6e432d',18,17,4,1);
 const draw=text||((ctx,value,x,y,color)=>{ctx.fillStyle=color;ctx.font='8px monospace';ctx.textAlign='left';ctx.textBaseline='top';ctx.fillText(value,x,y);});
 draw(c,String(v.lives??3).padStart(2,'0'),26,12,'#f2e4c5');
 rr(c,'#a5792f',51,10,7,10);rr(c,'#edc858',52,9,5,11);rr(c,'#fff09a',53,10,1,8);rr(c,'#b98d38',55,11,1,7);
 draw(c,String(v.coins||0).padStart(2,'0'),63,12,'#f5dc8b');if(room.minecraft.hero||room.minecraft.dragon||room.minecraft.nether)healthHearts(c,v.health??0,v.maxHealth??room.minecraft.hero?.maxHealth??3,v.minecraft?.gear||room.minecraftView?.gear||{},tickOf(room),v.healthUpgradePulse||0);if(v.minecraft?.dragon){const d=v.minecraft.dragon;rr(c,'#66516f',180,10,10,9);rr(c,'#d495e3',181,12,2,2);rr(c,'#d495e3',186,12,2,2);const max=d.maxHp||6;
 for(let i=0;i<max;i++){const x=196+i*7+Math.floor(i/2)*2;rr(c,i<d.hp?'#b779d0':'#3d3249',x,12,5,6);if(i<d.hp)rr(c,'#e4b4ee',x,12,5,1);}
 for(let i=0;i<3;i++)rr(c,i<(d.phase||1)?'#cda0df':'#4d3d5c',196+i*17,21,13,2);
 if(d.healingActive){rr(c,'#6d3f85',180,21,11,2);rr(c,'#dab2e5',184,19,2,6);rr(c,'#dab2e5',181,21,8,2);}
 }gearHud(c,v.minecraft?.gear||room.minecraftView?.gear,draw,tickOf(room),v.maxHealth??room.minecraft.hero?.maxHealth??3);c.restore();return true;
}
