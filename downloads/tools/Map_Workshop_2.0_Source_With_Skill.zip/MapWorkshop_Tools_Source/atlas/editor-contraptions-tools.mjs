import {pruneCompletionMarksReferences} from './editor-completion-marks-tools.mjs';
import {clone,uid,validate} from './editor-model.mjs';
import {validateContraptionsRoom} from './editor-contraptions.mjs';
import {RAIL_PLAYER_SWING_DEFAULTS} from './editor-rail-claws.mjs';
import {NPC_SPIKE_PANIC_DEFAULTS} from './editor-clown-cars.mjs';
const collections=['tracks','claws','staticclaw','notes','cars','pSources','oneWayWalls','spikeTraps'];
const storageCollection=collection=>collection==='staticclaw'?'claws':collection;
const empty=()=>({version:1,scene:'desert',tracks:[],claws:[],notes:[],cars:[],pSources:[],oneWayWalls:[],spikeTraps:[],doors:[]});
function edit(room,fn,{plain=false}={}){const draft=clone(room),newAdapter=!draft.contraptions;draft.contraptions??=empty();if(plain&&newAdapter)delete draft.contraptions.scene;fn(draft);validateContraptionsRoom(draft);room.contraptions=draft.contraptions;room.map=draft.map;}
const id=()=>('contraption-'+uid()).slice(0,72);
export function contraptionRecords(room){return collections.flatMap(collection=>collection==='spikeTraps'?room.map.objects.filter(o=>o.spikeTrap===true||(room.contraptions?.spikeTraps||[]).some(q=>q.id===o.id)).map(o=>({collection,...clone(o)})):(room.contraptions?.[storageCollection(collection)]||[]).filter(q=>collection==='staticclaw'?Object.hasOwn(q,'anchor'):collection!=='claws'||!Object.hasOwn(q,'anchor')).map(q=>({collection,...clone(q)})));}
export function addContraption(room,collection,values={}){
 if(!collections.includes(collection))throw Error('未知搬运组件');const spec=room.contraptions||empty(),recordId=id(),fixed=collection==='staticclaw'||collection==='claws'&&Object.hasOwn(values,'anchor');let initial;
 if(collection==='tracks')initial={start:[64,24],segments:[{kind:'line',to:[200,24]}],mode:'bounce'};
 else if(fixed)initial={anchor:[128,64],ropeLength:48,swingDegrees:0,playerSwing:{}};
 else if(collection==='claws'){if(!spec.tracks?.length)throw Error('先添加一条轨道');initial={trackId:spec.tracks[0].id,speed:.5,position:0,direction:1,ropeLength:40,swingDegrees:16,swingPeriodFrames:180,swingPhaseDegrees:0,catchRadius:18,releaseHalfWidth:30,releaseBelowHeight:176,regrabFrames:120,playerJumpSpeed:4.5};}
 else if(collection==='notes')initial={x:96,y:96,w:16,h:16,reward:'key',playerBounceSpeed:4.8,heldBounceSpeed:6.2,enemyBounceSpeed:2.5,keySpeed:3,keyDelayFrames:12};
 else if(collection==='cars')initial={x:128,y:96,w:32,h:28,bobPixels:2,bobPeriodFrames:120,npcAcceleration:.035,npcMaxSpeed:1.05,playerAcceleration:.065,playerMaxSpeed:2.25,drag:.055,occupantOffsetY:-12,boardingTolerance:4};
 else if(collection==='spikeTraps')initial={x:128,y:112,w:16,h:16};
 else if(collection==='oneWayWalls')initial={x:128,y:112,w:32,h:32,direction:'down'};
 else {const pipe=room.map.geometry.find(q=>q.material==='pipe'&&q.w===32);if(!pipe)throw Error('先放一根32像素宽的管道');initial={pipeId:pipe.id,intervalFrames:240,initialDelayFrames:0,maxAlive:2,maxEmissions:null};}
 edit(room,r=>{const key=storageCollection(collection);r.contraptions[key]??=[];if(collection==='spikeTraps'){r.map.objects.push({...initial,...values,id:recordId,kind:'hazard',spikeTrap:true});}else r.contraptions[key].push({...initial,...clone(values),id:recordId});},{plain:collection==='spikeTraps'||fixed});return recordId;
}
export function updateContraption(room,collection,recordId,values){if(!collections.includes(collection))throw Error('未知搬运组件');edit(room,r=>{if(collection==='spikeTraps'){const o=r.map.objects.find(o=>o.id===recordId);if(!o||!contraptionRecords(r).some(q=>q.collection==='spikeTraps'&&q.id===recordId))throw Error('请选择尖刺');Object.assign(o,values,{id:recordId,kind:'hazard',spikeTrap:true});}else{const list=r.contraptions[storageCollection(collection)]||[],at=list.findIndex(q=>q.id===recordId);if(at<0||collection==='staticclaw'&&!Object.hasOwn(list[at],'anchor'))throw Error('请选择组件');list[at]={...list[at],...clone(values),id:recordId};}});}
export function removeContraption(room,collection,recordId,{cascade=false}={}){if(!collections.includes(collection))throw Error('未知搬运组件');edit(room,r=>{if(collection==='tracks'){const linked=(r.contraptions.claws||[]).filter(q=>q.trackId===recordId);if(linked.length&&!cascade)throw Error('这条轨道仍连接吊臂；先删除吊臂或选择连同删除');if(cascade)r.contraptions.claws=r.contraptions.claws.filter(q=>q.trackId!==recordId);}const key=storageCollection(collection);if(collection==='staticclaw'&&!(r.contraptions[key]||[]).some(q=>q.id===recordId&&Object.hasOwn(q,'anchor')))throw Error('请选择固定吊爪');r.contraptions[key]=(r.contraptions[key]||[]).filter(q=>q.id!==recordId);if(collection==='spikeTraps')r.map.objects=r.map.objects.filter(q=>q.id!==recordId);});}
/** Copy fixed claws without a phantom rail or shared mutable anchor. */
export function cloneStaticClaw(room,recordId,{dx=16,dy=0}={}){const q=contraptionRecords(room).find(q=>q.id===recordId&&q.collection==='staticclaw');if(!q||!Number.isFinite(dx)||!Number.isFinite(dy))throw Error('请选择固定吊爪并填写复制位移');const {id:oldId,collection,...values}=q;return addContraption(room,'staticclaw',{...values,anchor:[q.anchor[0]+dx,q.anchor[1]+dy]});}
export function moveContraptionTrack(room,recordId,dx,dy){edit(room,r=>{const q=r.contraptions.tracks.find(q=>q.id===recordId);if(!q||!Number.isFinite(dx)||!Number.isFinite(dy))throw Error('请选择轨道并填写位移');const shifted=p=>[p[0]+dx,p[1]+dy];q.start=shifted(q.start);q.segments=q.segments.map(s=>({...s,to:shifted(s.to),...(s.control?{control:shifted(s.control)}:{})}));});}
export function setContraptionOptions(room,values){edit(room,r=>Object.assign(r.contraptions,values));}
export function addContraptionDoorPair(doc,sourceId,targetId,{source,target,style='key'}={}){
 if(!['key','plain'].includes(style))throw Error('未知门样式');
 const draft=clone(doc),a=draft.rooms.find(r=>r.roomId===sourceId),b=draft.rooms.find(r=>r.roomId===targetId);if(!a||!b||a===b)throw Error('请选择另一个有效区域');
 const pairId=id(),outId=id(),backId=id(),outSpawn='arrival-'+id(),backSpawn='arrival-'+id();
 const pos=(room,value,side)=>value||{x:side==='right'?room.map.width-32:32,y:room.map.height-48};const ap=pos(a,source,'right'),bp=pos(b,target,'left');
 for(const [r,q]of [[a,ap],[b,bp]])if(!Number.isFinite(q.x)||!Number.isFinite(q.y)||q.x<0||q.y<0||q.x+16>r.map.width||q.y+32>r.map.height)throw Error('门位置超出区域');
 const adapter=()=>style==='plain'?{version:1,doors:[]}:empty();
 a.contraptions??=adapter();b.contraptions??=adapter();a.map.objects.push({id:outId,kind:'portal',...ap,w:16,h:32,targetRoom:b.roomId,targetSpawn:backSpawn},{id:outSpawn,kind:'spawn',x:ap.x+3,y:ap.y+18,w:10,h:14});b.map.objects.push({id:backId,kind:'portal',...bp,w:16,h:32,targetRoom:a.roomId,targetSpawn:outSpawn},{id:backSpawn,kind:'spawn',x:bp.x+3,y:bp.y+18,w:10,h:14});
 a.contraptions.doors??=[];b.contraptions.doors??=[];a.contraptions.doors.push({id:outId,pairId,style});b.contraptions.doors.push({id:backId,pairId,style:'plain'});pruneCompletionMarksReferences(draft.rooms,doc.rooms);validate(draft);doc.rooms=draft.rooms;return pairId;
}
export function removeContraptionDoorPair(doc,pairId){const draft=clone(doc),records=draft.rooms.flatMap(r=>(r.contraptions?.doors||[]).filter(q=>q.pairId===pairId).map(q=>({r,q,p:r.map.objects.find(o=>o.id===q.id)})));if(records.length!==2)throw Error('门对不存在');const removedIds=new Set(records.map(q=>q.q.id));for(const {r,q}of records){r.contraptions.doors=r.contraptions.doors.filter(d=>d!==q);r.map.objects=r.map.objects.filter(o=>o.id!==q.id);}for(const {p}of records){const dest=draft.rooms.find(r=>r.roomId===p.targetRoom),used=draft.rooms.some(r=>r.map.objects.some(o=>o.kind==='portal'&&o.targetRoom===dest.roomId&&o.targetSpawn===p.targetSpawn));if(!used&&p.targetSpawn.startsWith('arrival-contraption-'))dest.map.objects=dest.map.objects.filter(o=>o.id!==p.targetSpawn);}pruneCompletionMarksReferences(draft.rooms,doc.rooms);validate(draft);doc.rooms=draft.rooms;}

export function setClawPlayerSwing(room,recordId,values){edit(room,r=>{const q=(r.contraptions.claws||[]).find(q=>q.id===recordId);if(!q)throw Error('请选择吊臂');if(values===false)delete q.playerSwing;else q.playerSwing={...RAIL_PLAYER_SWING_DEFAULTS,...(values||{})};});}
export function setCarNpcSpikePanic(room,recordId,values){edit(room,r=>{const q=(r.contraptions.cars||[]).find(q=>q.id===recordId);if(!q)throw Error('请选择飞船');if(values===false)delete q.npcSpikePanic;else q.npcSpikePanic={...NPC_SPIKE_PANIC_DEFAULTS,...(values||{})};});}
// A generic object paste can cross into a room that has no component adapter.
// Preserve the copied solid spike without silently changing that room's theme.
export function enableCopiedSpikeTraps(room){if(!room.map.objects.some(o=>o.spikeTrap===true)||room.contraptions)return false;const draft=clone(room);draft.contraptions={version:1,tracks:[],claws:[],notes:[],cars:[],doors:[],pSources:[],oneWayWalls:[],spikeTraps:[]};validateContraptionsRoom(draft);room.contraptions=draft.contraptions;return true;}
