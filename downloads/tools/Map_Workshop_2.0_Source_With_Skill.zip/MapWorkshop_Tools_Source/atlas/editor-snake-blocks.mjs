/** Optional, room-owned Snake Blocks, separate from the 2019 preview experiment.
 * Observed final-game behavior: player top occupation starts a fixed-world
 * occupied path window; dismount does not stop it; the exact endpoint shape
 * darkens and falls cell by cell. No final-body compression/arrival phase.
 * All numerical dynamics and collapse ordering are explicit authored values,
 * not undocumented Nintendo constants. Mario's motor remains caller-owned.
 */
export const SMM2_SNAKE_BLOCKS_VERSION = 1;
export const SMM2_SNAKE_BLOCK_SIZE = 16;
const SIZE = SMM2_SNAKE_BLOCK_SIZE, EPS = 1e-7;
const MAX_PATH_CELLS = 16384, MAX_TOTAL_PATH_CELLS = 262144;
const NAMESPACE = 'smm2-snake-block:';
const plain = v => !!v && typeof v === 'object' && !Array.isArray(v) && [Object.prototype, null].includes(Object.getPrototypeOf(v));
const copy = v => structuredClone(v);
const fail = message => {throw new TypeError(message);};
const finite = (v, min, max) => typeof v === 'number' && Number.isFinite(v) && v >= min && v <= max;
const integer = (v, min, max) => Number.isSafeInteger(v) && v >= min && v <= max;
const safeId = v => typeof v === 'string' && v.length <= 72 && /^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(v) && !['constructor', 'prototype'].includes(v);
const body = v => plain(v) && ['x', 'y', 'w', 'h'].every(k => Number.isFinite(v[k])) && v.w > 0 && v.h > 0;
const alive = v => v && !v.dead && !v.dying && !v.removed && v.visible !== false;
const pose = v => ({x: v.x, y: v.y, w: v.w, h: v.h});
const overlapX = (a, b) => a.x + a.w > b.x + EPS && a.x < b.x + b.w - EPS;
const onTop = (a, q) => overlapX(a, q) && Math.abs(a.y + a.h - q.y) <= EPS;
const prefix = train => `${NAMESPACE}${train.id}:`;
const trainFields = ['id', 'color', 'origin', 'path', 'lengthCells', 'speedPxPerTick', 'initialHeadDistancePx', 'activation', 'endpointHoldFrames', 'collapseIntervalFrames', 'collapseGravity', 'collapseFallCap', 'collapseOrder'];
function fields(value, allowed, label) {
  if (!plain(value)) fail(`${label} must be a plain object`);
  for (const key of Reflect.ownKeys(value)) if (typeof key !== 'string' || !allowed.includes(key)) fail(`Unknown ${label} field: ${String(key)}`);
  for (const key of allowed) if (!Object.hasOwn(value, key)) fail(`Missing ${label} field: ${key}`);
}
function array(value, min, max, label) {
  if (!Array.isArray(value) || value.length < min || value.length > max) fail(`Invalid bounded ${label}`);
  for (const key of Reflect.ownKeys(value)) if (key !== 'length' && (typeof key !== 'string' || !/^(0|[1-9][0-9]*)$/.test(key) || Number(key) >= value.length)) fail(`Unknown ${label} field: ${String(key)}`);
  for (let i = 0; i < value.length; i++) if (!Object.hasOwn(value, i)) fail(`Missing ${label} entry`);
}
function expandPath(train) {
  const nodes = [], visited = new Set();
  const append = (x, y, waypointId = null) => {
    if (nodes.length >= MAX_PATH_CELLS) fail('SMM2 Snake Block expanded path exceeds the tool limit of 16384 cells');
    const coordinate = `${x},${y}`;
    if (visited.has(coordinate)) fail('SMM2 Snake Block route crossings and revisits are unsupported');
    visited.add(coordinate);
    nodes.push({id: `${prefix(train)}node:${coordinate}`, nodeId: `${prefix(train)}node:${coordinate}`, waypointId, relativeX: x, relativeY: y, x: train.origin.x + x, y: train.origin.y + y, w: SIZE, h: SIZE, pathDistancePx: nodes.length * SIZE});
  };
  const first = train.path[0];
  append(first.x, first.y, first.id);
  for (let i = 1; i < train.path.length; i++) {
    const from = train.path[i - 1], to = train.path[i];
    const dx = Math.sign(to.x - from.x) * SIZE, dy = Math.sign(to.y - from.y) * SIZE;
    const count = (Math.abs(to.x - from.x) + Math.abs(to.y - from.y)) / SIZE;
    for (let n = 1; n <= count; n++) append(from.x + dx * n, from.y + dy * n, n === count ? to.id : null);
  }
  return nodes;
}

/** Only the optional Snake Block leaf is validated here; siblings stay importer-owned.
 * origin is the top-left of the FIRST path cell, never a center coordinate.
 * Limits below protect the host's bounded geometry, not original-game limits.
 */
export function validateSmm2SnakeBlocksRoom(room, spec = room?.smm2Mechanics) {
  if (spec === undefined) return;
  if (!plain(spec) || spec.version !== 1 || Reflect.ownKeys(spec).some(k => typeof k !== 'string' || ['__proto__', 'prototype', 'constructor'].includes(k))) fail('Invalid SMM2 Snake Block mechanics version');
  if (spec.snakeBlocks === undefined) return;
  const leaf = spec.snakeBlocks;
  fields(leaf, ['version', 'trains'], 'SMM2 Snake Blocks');
  if (leaf.version !== SMM2_SNAKE_BLOCKS_VERSION) fail('Invalid bounded SMM2 Snake Blocks v1 train list');
  array(leaf.trains, 0, 256, 'SMM2 Snake Blocks v1 train list');
  const map = room?.map;
  if (!plain(map) || !finite(map.width, SIZE, 32768) || !finite(map.height, SIZE, 4096) || !Array.isArray(map.geometry) || !Array.isArray(map.objects)) fail('SMM2 Snake Blocks need bounded native room geometry and objects');
  const nativeIds = new Set([...map.geometry, ...map.objects].map(q => q?.id)), ids = new Set();
  let totalPathCells = 0;
  for (const q of leaf.trains) {
    fields(q, trainFields, 'SMM2 Snake Block train');
    if (!safeId(q.id) || ids.has(q.id) || nativeIds.has(q.id)) fail('Duplicate, invalid or ambiguous SMM2 Snake Block train ID');
    ids.add(q.id);
    if (!['green', 'blue'].includes(q.color) || q.activation !== 'player-top' || !['tail-to-head', 'head-to-tail'].includes(q.collapseOrder)) fail('Invalid SMM2 Snake Block color, activation or authored collapse ordering');
    fields(q.origin, ['x', 'y'], 'SMM2 Snake Block origin');
    if (!finite(q.origin.x, 0, map.width - SIZE) || !finite(q.origin.y, 0, map.height - SIZE)) fail('SMM2 Snake Block origin must be inside the room');
    array(q.path, 2, 1024, 'SMM2 Snake Block path (2..1024 cardinal waypoints)');
    const waypointIds = new Set();
    let distance = 0;
    q.path.forEach((node, i) => {
      fields(node, ['id', 'x', 'y'], 'SMM2 Snake Block waypoint');
      if (!safeId(node.id) || waypointIds.has(node.id)) fail('Duplicate or invalid SMM2 Snake Block waypoint ID');
      waypointIds.add(node.id);
      if (!integer(node.x, -32768, 32768) || !integer(node.y, -4096, 4096) || node.x % SIZE || node.y % SIZE) fail('SMM2 Snake Block waypoints must use 16px cardinal grid coordinates');
      if (!finite(q.origin.x + node.x, 0, map.width - SIZE) || !finite(q.origin.y + node.y, 0, map.height - SIZE)) fail('SMM2 Snake Block path cell must be inside the room');
      if (!i) {if (node.x || node.y) fail('SMM2 Snake Block first relative waypoint must be 0,0');}
      else {
        const before = q.path[i - 1], dx = node.x - before.x, dy = node.y - before.y;
        if ((!dx && !dy) || (dx && dy)) fail('SMM2 Snake Block path edges must be nonzero and cardinal');
        distance += Math.abs(dx) + Math.abs(dy);
      }
    });
    const pathCells = 1 + distance / SIZE;
    if (pathCells > MAX_PATH_CELLS) fail('SMM2 Snake Block expanded path exceeds the tool limit of 16384 cells');
    totalPathCells += pathCells;
    if (totalPathCells > MAX_TOTAL_PATH_CELLS) fail('SMM2 Snake Blocks total expanded paths exceed the tool limit of 262144 cells');
    if (!integer(q.lengthCells, 2, 1024) || !finite(q.initialHeadDistancePx, (q.lengthCells - 1) * SIZE, distance)) fail('SMM2 Snake Block complete initial occupied window must lie on its path');
    // One path cell per update keeps an endpoint's measured displacement bounded.
    if (!finite(q.speedPxPerTick, EPS, SIZE) || !integer(q.endpointHoldFrames, 0, 36000) || !integer(q.collapseIntervalFrames, 1, 36000) || !finite(q.collapseGravity, EPS, 64) || !finite(q.collapseFallCap, EPS, 256)) fail('Invalid explicit SMM2 Snake Block speed, endpoint or collapse dynamics');
    if (nativeIds.has(`${prefix(q)}head`) || nativeIds.has(`${prefix(q)}tail`)) fail('SMM2 Snake Block endpoint ID collides with native geometry');
  }
  // All path budgets are checked before expanding any controller geometry.
  for (const q of leaf.trains) for (const node of expandPath(q)) if (nativeIds.has(node.id)) fail('SMM2 Snake Block generated cell ID collides with native geometry');
  return copy(leaf);
}

/** The host supplies the actual player, never an NPC array or proximity trigger.
 * step advances one 60Hz host update, regardless of skipped tick identifiers.
 * observePlayerContact is called after the normal motor for same-frame landing.
 * preparePlayer runs BEFORE the motor reads grounded, and never transports it.
 */
export function createSmm2SnakeBlocks(room, {emit = () => {}} = {}) {
  const leaf = validateSmm2SnakeBlocksRoom(room);
  if (!leaf?.trains.length) return null;
  if (typeof emit !== 'function') fail('Invalid SMM2 Snake Block emitter');
  const definitions = leaf.trains.map(q => ({...copy(q), nodes: expandPath(q)}));
  let states, lastTick, motions, playerTicks;
  function reset() {
    lastTick = null; motions = []; playerTicks = new WeakMap();
    states = definitions.map(q => ({definition: q, headDistancePx: q.initialHeadDistancePx, phase: 'idle', activationTick: null, endpointElapsedFrames: null, endpointCells: null}));
    return view();
  }
  function endpoint(q, nodes, role, distance) {
    const segment = Math.min(nodes.length - 2, Math.floor(distance / SIZE)), from = nodes[segment], to = nodes[segment + 1], fraction = (distance - from.pathDistancePx) / SIZE;
    return {id: `${prefix(q)}${role}`, nodeId: null, waypointId: fraction === 0 ? from.waypointId : fraction === 1 ? to.waypointId : null, role, x: from.x + (to.x - from.x) * fraction, y: from.y + (to.y - from.y) * fraction, w: SIZE, h: SIZE, pathDistancePx: distance, direction: {x: Math.sign(to.x - from.x), y: Math.sign(to.y - from.y)}};
  }
  function occupied(s) {
    const q = s.definition, tailDistance = s.headDistancePx - (q.lengthCells - 1) * SIZE;
    return [endpoint(q, q.nodes, 'tail', tailDistance), ...q.nodes.filter(n => n.pathDistancePx > tailDistance + EPS && n.pathDistancePx < s.headDistancePx - EPS).map(n => ({...n, role: 'fixed', direction: null})), endpoint(q, q.nodes, 'head', s.headDistancePx)].map(q => ({...q, phase: 'occupied', darkened: false, vy: 0}));
  }
  function cells(s) {return s.endpointCells || occupied(s);}
  function geometry() {
    const byId = new Map(motions.map(m => [m.id, m]));
    return states.flatMap(s => cells(s).filter(q => q.phase !== 'removed').map(q => {
      const motion = byId.get(q.id), definition = s.definition;
      return {...copy(q), trainId: definition.id, color: definition.color, collision: 'solid', material: 'snake-block', dx: motion?.dx || 0, dy: motion?.dy || 0, smm2SnakeBlock: {version: 1, trainId: definition.id, color: definition.color, role: q.role, phase: q.phase, darkened: q.darkened}, lastMotion: motion ? copy(motion) : null};
    }));
  }
  function ownsGeometry(q) {return typeof q?.id === 'string' && states.some(s => q.id.startsWith(prefix(s.definition)));}
  function view() {
    return {version: 1, tick: lastTick, parameterStatus: 'authored-not-original-calibrated', trains: states.map(s => ({id: s.definition.id, color: s.definition.color, phase: s.phase, activationTick: s.activationTick, headDistancePx: s.headDistancePx, tailDistancePx: s.headDistancePx - (s.definition.lengthCells - 1) * SIZE, pathLengthPx: s.definition.nodes.at(-1).pathDistancePx, lengthCells: s.definition.lengthCells, collapseOrder: s.definition.collapseOrder, endpointElapsedFrames: s.endpointElapsedFrames, cells: copy(cells(s))})), geometry: geometry(), motions: copy(motions)};
  }
  function event(s, tick, event, data = {}) {emit('smm2-snake-block', {event, trainId: s.definition.id, tick, ...copy(data)});}
  function topContact(player, previous, collider) {
    if (player.grounded && player.support === collider.id && onTop(player, collider)) return {kind: 'supported-top', solidId: collider.id};
    if (!body(previous) || previous.w !== player.w || previous.h !== player.h) return null;
    const dy = player.y - previous.y, gap = collider.y - previous.y - previous.h;
    if (dy <= EPS || gap < -EPS || gap > dy + EPS) return null;
    const fraction = Math.max(0, Math.min(1, gap / dy)), at = {...player, x: previous.x + (player.x - previous.x) * fraction};
    return overlapX(at, collider) ? {kind: 'descending-top', solidId: collider.id, fraction} : null;
  }
  function observePlayerContact(player, {tick = lastTick, previousPlayer = null} = {}) {
    if (!integer(tick, 0, Number.MAX_SAFE_INTEGER)) fail('Invalid SMM2 Snake Block player-contact tick');
    if (lastTick !== null && tick < lastTick) return [];
    if (!alive(player) || !body(player) || !finite(player.vy ?? 0, 0, 256)) return [];
    const activated = [], actual = geometry();
    for (const s of states) {
      if (s.phase !== 'idle') continue;
      const contact = actual.filter(q => q.trainId === s.definition.id).map(q => topContact(player, previousPlayer, q)).find(Boolean);
      if (!contact) continue;
      s.phase = 'moving'; s.activationTick = tick; activated.push(s.definition.id);
      event(s, tick, 'activate', {contact});
    }
    return activated;
  }
  function collapse(s, tick) {
    const q = s.definition, elapsed = s.endpointElapsedFrames;
    if (elapsed < q.endpointHoldFrames) return;
    const ordered = q.collapseOrder === 'tail-to-head' ? s.endpointCells : [...s.endpointCells].reverse();
    for (let rank = 0; rank < ordered.length; rank++) {
      const cell = ordered[rank];
      if (cell.phase === 'occupied' && elapsed >= q.endpointHoldFrames + rank * q.collapseIntervalFrames) {
        cell.phase = 'falling'; cell.darkened = true; cell.collapseIndex = rank;
        event(s, tick, 'cell-collapse', {cellId: cell.id, collapseIndex: rank});
      }
    }
    s.phase = 'collapsing';
    for (const cell of s.endpointCells) if (cell.phase === 'falling') {
      cell.vy = Math.min(q.collapseFallCap, cell.vy + q.collapseGravity); cell.y += cell.vy;
      if (cell.y >= room.map.height) cell.phase = 'removed';
    }
    if (s.endpointCells.every(q => q.phase === 'removed')) {s.phase = 'complete'; event(s, tick, 'complete');}
  }
  function step({tick, player = null, previousPlayer = null} = {}) {
    if (!integer(tick, 0, Number.MAX_SAFE_INTEGER)) fail('Invalid SMM2 Snake Block tick');
    if (lastTick !== null && tick <= lastTick) return {advanced: false, tick: lastTick, activated: []};
    const before = new Map(geometry().map(q => [q.id, pose(q)]));
    lastTick = tick;
    const activated = observePlayerContact(player, {tick, previousPlayer});
    for (const s of states) {
      if (s.phase === 'moving' && s.activationTick < tick) {
        s.headDistancePx = Math.min(s.definition.nodes.at(-1).pathDistancePx, s.headDistancePx + s.definition.speedPxPerTick);
        if (s.headDistancePx === s.definition.nodes.at(-1).pathDistancePx) {
          s.phase = 'endpoint'; s.endpointElapsedFrames = 0;
          s.endpointCells = occupied(s); event(s, tick, 'endpoint'); collapse(s, tick);
        }
      } else if (s.phase === 'endpoint' || s.phase === 'collapsing') {s.endpointElapsedFrames++; collapse(s, tick);}
    }
    motions = [];
    const after = new Map(geometry().map(q => [q.id, pose(q)]));
    for (const id of new Set([...before.keys(), ...after.keys()])) {
      const from = before.get(id) || null, to = after.get(id) || null;
      motions.push({id, tick, from, to, dx: from && to ? to.x - from.x : 0, dy: from && to ? to.y - from.y : 0, appeared: !from, departed: !to});
    }
    return {advanced: true, tick, activated};
  }
  function preparePlayer(player, {tick = lastTick} = {}) {
    if (!body(player)) fail('SMM2 Snake Block preparation needs an actual finite player body');
    if (tick !== lastTick || !integer(tick, 0, Number.MAX_SAFE_INTEGER)) fail('SMM2 Snake Block preparation needs the current advanced tick');
    const repeated = playerTicks.get(player) === tick;
    const actual = geometry().map(q => repeated ? {...q, dx: 0, dy: 0} : q);
    const previousSupport = player.support;
    let invalidated = false;
    if (typeof previousSupport === 'string' && states.some(s => previousSupport.startsWith(prefix(s.definition)))) {
      const current = actual.find(q => q.id === previousSupport), motion = motions.find(q => q.id === previousSupport);
      const top = repeated ? current : motion?.from || current;
      const valid = alive(player) && current && top && player.grounded && (player.vy ?? 0) >= 0 && onTop(player, top);
      if (!valid) {player.grounded = false; player.support = null; if ('jumpBuffer' in player) player.jumpBuffer = 0; invalidated = true;}
    }
    playerTicks.set(player, tick);
    return {geometry: actual, supportCheck: {invalidated, previousSupport, reason: invalidated ? 'snake-block-top-no-longer-valid' : null}};
  }
  reset();
  return Object.freeze({step, observePlayerContact, preparePlayer, geometry, ownsGeometry, view, reset, getDocument: () => copy(leaf)});
}

/** Optional convenience adapter. It leaves normal input/physics with the motor.
 * Consumers that already call the motor should use preparePlayer + observePlayerContact.
 */
export function stepSmm2SnakeBlockPlayer({controller, motor, player, input = {}, character, world, tick}) {
  if (!controller || typeof controller.preparePlayer !== 'function' || !motor || typeof motor.step !== 'function') fail('Snake Block player adapter needs its controller and existing motor');
  const before = pose(player), prepared = controller.preparePlayer(player, {tick});
  const solids = [...(world.solids || []).filter(q => !controller.ownsGeometry(q)), ...prepared.geometry];
  const events = motor.step(player, input, character, {...world, solids});
  const activated = controller.observePlayerContact(player, {tick, previousPlayer: before});
  return {events, activated, supportCheck: prepared.supportCheck};
}
