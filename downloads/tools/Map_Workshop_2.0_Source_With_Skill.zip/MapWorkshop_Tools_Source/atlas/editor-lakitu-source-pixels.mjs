/** Native-grid pixel reconstructions measured from an already possessed course video.
 * Nintendo artwork depicted in the source; private learning only.
 * These are transparent code-native adaptations, not original sprite PNGs or rips.
 * Compression colors, occluded cells and lattice phase are resolved manually.
 * Evidence and comparison boards: next-lakitu-pixel-reconstruction-20261005.
 */
const freeze=value=>{if(value&&typeof value==='object'){for(const child of Object.values(value))freeze(child);Object.freeze(value);}return value;};
export const SMM2_SMB1_LAKITU_CLOUD_TRACE=freeze({
  "width": 20,
  "height": 16,
  "palette": {
    ".": [
      0,
      0,
      0,
      0
    ],
    "g": [
      67,
      180,
      54,
      255
    ],
    "w": [
      252,
      253,
      250,
      255
    ]
  },
  "rows": [
    ".....gggggggggg.....",
    "...ggwwwwwwwwwwgg...",
    "..gwwwwwwwwwwwwwwg..",
    ".gwwwwwwwwwwwwwwwwg.",
    ".gwwwwwwwwwwwwwwwwg.",
    ".gwwwwwwgwwgwwwwwwg.",
    "gwwwwwwwgwwgwwwwwwwg",
    "gwwwwwwwgwwgwwwwwwwg",
    "gwwwwwwwwwwwwwwwwwwg",
    "gwwwwwwwwwwwwwwwwwwg",
    "gwgwwwwgwwwwgwwwwgwg",
    ".gwwwwwwggggwwwwwwg.",
    ".gwwwwwwwwwwwwwwwwg.",
    "..gwwwwwwwwwwwwwwg..",
    "...ggwwwwggwwwwgg...",
    ".....gggg..gggg....."
  ],
  "sourceKind": "manual native-grid trace from already possessed compressed gameplay video; adaptation, not an original asset rip",
  "sourceGame": "Super Mario Maker 2, Super Mario Bros. style, Head in the Clouds",
  "sourceVideoSha256": "49d4f47587625ba00616324f22b4d1bbecbae632ff14496333a7a6a7ab4e4985",
  "sourceFramePts": 33842,
  "sourceSeconds": 1128.0666666666666,
  "sourceRaster": [
    854,
    480
  ],
  "nativeRaster": [
    384,
    216
  ],
  "scale": [
    2.2239583333333335,
    2.2222222222222223
  ],
  "nativeSizeMeaning": "rendering rectangle only; not a collision mask",
  "sourceRawOrigin": [
    325.1,
    277.78
  ],
  "comparisonFramePts": 34078,
  "comparisonSeconds": 1135.9333333333334,
  "adaptation": "Integer silhouette/lobe alignment reconciled with PTS34078; lower right, partly covered by a spike at PTS33842, is reflected from the clearly visible left. H.264 color mixtures are assigned to two manually identified classes. Eyes and smile follow clear unoccupied-cloud cells."
});
export const SMM2_SMB1_SPIKE_TRACE=freeze({
  "width": 16,
  "height": 16,
  "palette": {
    ".": [
      0,
      0,
      0,
      0
    ],
    "b": [
      47,
      48,
      47,
      255
    ],
    "w": [
      253,
      253,
      251,
      255
    ]
  },
  "rows": [
    "bb.....b......bb",
    "bwbb..bwb...bbwb",
    ".bwbbbbwb.bbbwb.",
    ".bbwwbbwwbbwwbb.",
    "..bwwwbwwbwwwb..",
    "..bbwwbbbbwwbb..",
    "..bbbbbwwbbbbbb.",
    ".bbwwbwwwwbwwwwb",
    "bwwwwbwwwwbwwbb.",
    ".bbbbbbwwbbbbb..",
    "..bbwwbbbbwwbb..",
    "..bwwwbwwbwwwb..",
    ".bbwwbbwwbbwwbb.",
    ".bwbbb.bwbbbbwb.",
    "bwbb...bwb..bbwb",
    "bb......b.....bb"
  ],
  "sourceKind": "manual native-grid trace from already possessed compressed gameplay video; adaptation, not an original asset rip",
  "sourceGame": "Super Mario Maker 2, Super Mario Bros. style, Head in the Clouds",
  "sourceVideoSha256": "49d4f47587625ba00616324f22b4d1bbecbae632ff14496333a7a6a7ab4e4985",
  "sourceFramePts": 33842,
  "sourceSeconds": 1128.0666666666666,
  "sourceRaster": [
    854,
    480
  ],
  "nativeRaster": [
    384,
    216
  ],
  "scale": [
    2.2239583333333335,
    2.2222222222222223
  ],
  "nativeSizeMeaning": "rendering rectangle only; not a collision mask",
  "sourceRawOrigin": [
    355.33,
    49.19
  ],
  "sourceRepeatedOriginsY": [
    13.633333,
    49.188889,
    84.744445,
    120.300001
  ],
  "adaptation": "Four repeated wall tiles aligned to a 16-cell lattice and compared with PTS34078. Two observed solid classes, dark gray and white; blue chroma spill is transparent. Lower half uses the strongly observed 180-degree symmetry of the white crags to resolve edge cells."
});
export const SMM2_SMB1_GRINDER_TRACE=freeze({
  "width": 48,
  "height": 48,
  "palette": {
    ".": [
      0,
      0,
      0,
      0
    ],
    "g": [
      39,
      81,
      78,
      255
    ],
    "m": [
      151,
      183,
      173,
      255
    ],
    "w": [
      249,
      255,
      252,
      255
    ]
  },
  "rows": [
    ".......................gg.......................",
    ".............gg.......gwwg.......gg.............",
    ".............gwg......gwwg......gwg.............",
    ".............gwwg....gwwwwg....gwwg.............",
    ".............gwwwgg..gwwwwg..ggwwwg.............",
    ".............gwwwwwggwwwwwwggwwwwwg.............",
    "......ggg....gwwwwwwwwwmmwwwwwwwwwg....ggg......",
    "......gwwgg..gwwmmwwwwmmmmwwwwmmwwg..ggwwg......",
    "......gwwwwggwwwmmmwwmmwwmmwwmmmwwwggwwwwg......",
    ".......gwwwwwwwwmmmmmmmmmmmmmmmmwwwwwwwwg.......",
    ".......gwwwwwwwwmmmmmmwwwwmmmmmmwwwwwwwwg.......",
    "........gwwmmmmmmmmmwwwwwwwwmmmmmmmmmwwg........",
    "........gwwmmmmmmmmmmmmmmmmmmmmmmmmmmwwg........",
    ".gggggggwwwmmmmmmmmmmmwwwwmmmmmmmmmmmwwwggggggg.",
    ".gwwwwwwwwwmmmmmmmmmmwwwwwwmmmmmmmmmmwwwwwwwwwg.",
    "..gwwwwwwwwmmmmmmmmmmmmmmmmmmmmmmmmmmwwwwwwwwg..",
    "...gwwwmmmmmmmmmmmmmmmwwwwmmmmmmmmmmmmmmmwwwg...",
    "....gwwmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmwwg....",
    "....gwwwmmmmmmmmmmmmmmmwwmmmmmmmmmmmmmmmwwwg....",
    ".....gwwwmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmwwwg.....",
    ".....gwwwmmwmmmmmmmmmmggggmmmmmmmmmmwmmwwwg.....",
    "...ggwwwmmmwmmwmmmmmmgwwwwgmmmmmmwmmwmmmwwwgg...",
    ".ggwwwwmmmwwmwwmwmmmgwwggwwgmmmwmwwmwwmmmwwwwgg.",
    "gwwwwwmmwmwwmwwmwmwmgwgwwgwgmwmwmwwmwwmwmmwwwwwg",
    "gwwwwwmmwmwwmwwmwmwmgwgwwgwgmwmwmwwmwwmwmmwwwwwg",
    ".ggwwwwmmmwwmwwmwmmmgwwggwwgmmmwmwwmwwmmmwwwwgg.",
    "...ggwwwmmmwmmwmmmmmmgwwwwgmmmmmmwmmwmmmwwwgg...",
    ".....gwwwmmwmmmmmmmmmmggggmmmmmmmmmmwmmwwwg.....",
    ".....gwwwmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmwwwg.....",
    "....gwwwmmmmmmmmmmmmmmmwwmmmmmmmmmmmmmmmwwwg....",
    "....gwwmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmwwg....",
    "...gwwwmmmmmmmmmmmmmmmwwwwmmmmmmmmmmmmmmmwwwg...",
    "..gwwwwwwwwmmmmmmmmmmmmmmmmmmmmmmmmmmwwwwwwwwg..",
    ".gwwwwwwwwwmmmmmmmmmmwwwwwwmmmmmmmmmmwwwwwwwwwg.",
    ".gggggggwwwmmmmmmmmmmmwwwwmmmmmmmmmmmwwwggggggg.",
    "........gwwmmmmmmmmmmmmmmmmmmmmmmmmmmwwg........",
    "........gwwmmmmmmmmmwwwwwwwwmmmmmmmmmwwg........",
    ".......gwwwwwwwwmmmmmmwwwwmmmmmmwwwwwwwwg.......",
    ".......gwwwwwwwwmmmmmmmmmmmmmmmmwwwwwwwwg.......",
    "......gwwwwggwwwmmmwwmmwwmmwwmmmwwwggwwwwg......",
    "......gwwgg..gwwmmwwwwmmmmwwwwmmwwg..ggwwg......",
    "......ggg....gwwwwwwwwwmmwwwwwwwwwg....ggg......",
    ".............gwwwwwggwwwwwwggwwwwwg.............",
    ".............gwwwgg..gwwwwg..ggwwwg.............",
    ".............gwwg....gwwwwg....gwwg.............",
    ".............gwg......gwwg......gwg.............",
    ".............gg.......gwwg.......gg.............",
    ".......................gg......................."
  ],
  "sourceKind": "manual native-grid trace from already possessed compressed gameplay video; adaptation, not an original asset rip",
  "sourceGame": "Super Mario Maker 2, Super Mario Bros. style, Head in the Clouds",
  "sourceVideoSha256": "49d4f47587625ba00616324f22b4d1bbecbae632ff14496333a7a6a7ab4e4985",
  "sourceFramePts": 33842,
  "sourceSeconds": 1128.0666666666666,
  "sourceRaster": [
    854,
    480
  ],
  "nativeRaster": [
    384,
    216
  ],
  "scale": [
    2.2239583333333335,
    2.2222222222222223
  ],
  "nativeSizeMeaning": "rendering rectangle only; not a collision mask",
  "sourceRawOrigin": [
    604.4,
    71.2
  ],
  "comparisonFramePts": 34176,
  "comparisonSeconds": 1139.2,
  "phaseDegrees": 0,
  "phaseDescription": "Near-cardinal four-arm hatch phase visible at PTS33842 and PTS34176",
  "toothCount": 16,
  "adaptation": "48-cell lattice fit to near-cardinal original-video frame. Left/top clear quadrant reflected across the hub to remove track rails, diagonal drop shadow and compression ambiguity. One reconstructed static phase; runtime angle progression is an independently observed adaptation, not an extracted original animation sheet."
});
export const LAKITU_OBSERVED_PIXEL_TRACES=freeze({cloud:SMM2_SMB1_LAKITU_CLOUD_TRACE,spike:SMM2_SMB1_SPIKE_TRACE,grinder:SMM2_SMB1_GRINDER_TRACE});
function decode(source){return {width:source.width,height:source.height,pixels:source.rows.flatMap(row=>[...row].flatMap(cell=>source.palette[cell]))};}
export function lakituCloudSourcePixels(){return decode(SMM2_SMB1_LAKITU_CLOUD_TRACE);}
export function spikeSourcePixels(){return decode(SMM2_SMB1_SPIKE_TRACE);}
export function grinderSourcePixels(){return decode(SMM2_SMB1_GRINDER_TRACE);}
