/** Bounded, opt-in local updrafts observed in Heavy Stone Heave-Ho.
 * The source shows a friendly cloud walking on one flat support and lifting a
 * Stone-carrying player. Coefficients are explicit measured-scene fits; this
 * does not implement global desert wind or unobserved NPC/liquid matrices. */
const EPS=1e-7;
const plain=q=>q&&typeof q==='object'&&!Array.isArray(q)&&[Object.prototype,null].includes(Object.getPrototypeOf(q));
const finite=(n,a,b)=>Number.isFinite(n)&&n>=a&&n<=b;
const safe=s=>typeof s==='string'&&/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(s)&&s.length<=100;
const copy=q=>structuredClone(q);
const body=q=>q&&['x','y','w','h'].every(k=>Number.isFinite(q[k]))&&q.w>0&&q.h>0;
function fields(q,allowed,label){if(!plain(q)||Object.keys(q).some(k=>!allowed.includes(k)||['__proto__','prototype','constructor'].includes(k)))throw Error('Invalid '+label+' fields');}
export function validateLocalUpdrafts(room,spec=room?.smm2Mechanics?.localUpdrafts){
 if(spec===undefined)return;
 fields(spec,['version','twisters'],'local updrafts');
 if(spec.version!==1||!Array.isArray(spec.twisters)||spec.twisters.length>64)throw Error('Invalid local updraft version/list');
 const map=room.map,seen=new Set();if(!map||!finite(map.width,1,32768)||!finite(map.height,1,4096))throw Error('Local updrafts need a bounded native room');
 for(const q of spec.twisters){
  fields(q,['id','speed','direction','windHeight','visualHeight','bottomHalfWidth','topHalfWidth','riseAcceleration','maxRiseSpeed'],'local Twister');
  const source=map.objects.find(o=>o.id===q.id&&o.kind==='walker');
  if(!safe(q.id)||seen.has(q.id)||map.objects.filter(o=>o.id===q.id).length!==1||!body(source)||source.w!==16||source.h!==16||!finite(source.x,0,map.width-16)||!finite(source.y,0,map.height-16))throw Error('Local Twister needs one unique 16 by 16 native body');
  seen.add(q.id);
  if(q.visualHeight!==undefined&&!finite(q.visualHeight,16,512))throw Error('Invalid visible local updraft particle extent');
  if(!finite(q.speed,.001,4)||![1,-1].includes(q.direction)||!finite(q.windHeight,16,512)||!finite(q.bottomHalfWidth,1,64)||!finite(q.topHalfWidth,q.bottomHalfWidth,128)||!finite(q.riseAcceleration,.001,4)||!finite(q.maxRiseSpeed,.01,16))throw Error('Invalid explicit local updraft coefficients');
 }
}
export function createLocalUpdrafts(room,{emit=()=>{}}={}){
 validateLocalUpdrafts(room);const spec=room?.smm2Mechanics?.localUpdrafts;if(!spec)return null;
 if(typeof emit!=='function')throw Error('Local updraft emit must be a function');
 const rules=new Map(spec.twisters.map(q=>[q.id,copy(q)])),lastTicks=new Map(),active=new Set();
 const ownsActor=a=>rules.has(typeof a==='string'?a:a?.id);
 function decorateActor(a){const q=rules.get(a.id);if(!q)return a;return Object.assign(a,{type:'local-twister',localUpdraft:true,vx:q.speed*q.direction,vy:0,grounded:true,support:null,dead:false});}
 function stepActor(a,{tick,geometry,cam=0,viewportWidth=384}={}){
  const q=rules.get(a?.id);if(!q)return false;if(!Number.isSafeInteger(tick)||tick<0||!Array.isArray(geometry))throw Error('Local Twister step needs a tick and actual geometry');
  if(lastTicks.get(a.id)===tick)return true;lastTicks.set(a.id,tick);
  if(a.dead||a.hidden||a.x>cam+viewportWidth+32||a.x+a.w<cam-32)return true;
  active.add(a.id);const oldX=a.x,feet=a.y+a.h,dir=Math.sign(a.vx)||q.direction;
  const floor=geometry.find(g=>!g.hidden&&['solid','oneway'].includes(g.collision)&&g.x<a.x+a.w-EPS&&g.x+g.w>a.x+EPS&&Math.abs(g.y-feet)<=1.01);
  if(!floor){a.vx=0;a.grounded=false;a.support=null;return true;}
  const nextX=a.x+dir*q.speed,probe=dir>0?nextX+a.w-EPS:nextX+EPS;
  const supported=geometry.some(g=>!g.hidden&&['solid','oneway'].includes(g.collision)&&probe>=g.x&&probe<g.x+g.w&&Math.abs(g.y-feet)<=1.01);
  const blocked=geometry.some(g=>!g.hidden&&g.collision==='solid'&&nextX<g.x+g.w-EPS&&nextX+a.w>g.x+EPS&&a.y<g.y+g.h-EPS&&feet>g.y+EPS);
  if(!supported||blocked||nextX<0||nextX+a.w>room.map.width){a.vx=-dir*q.speed;emit('smm2-updraft',{event:'turn',roomId:room.roomId,actorId:a.id,tick,x:a.x,reason:blocked?'wall':'support-edge'});}
  else a.x=nextX;
  a.grounded=true;a.support=floor.id;a.vy=0;a.dx=a.x-oldX;a.dy=0;return true;
 }
 function playerField(player,actors=[]){
  if(!body(player)||player.dead||player.dying||player.onVine||player.vehicleId||player.clawHeld)return null;
  const foot=player.y+player.h,cx=player.x+player.w/2;
  for(const a of actors){const q=rules.get(a.id);if(!q||!active.has(a.id)||a.dead||a.hidden)continue;
   const bottom=a.y+a.h/2,relative=bottom-foot;if(relative<-4||relative>q.windHeight)continue;
   const t=Math.max(0,Math.min(1,relative/q.windHeight)),radius=q.bottomHalfWidth+(q.topHalfWidth-q.bottomHalfWidth)*t;
   if(Math.abs(cx-a.x-a.w/2)<=radius+player.w/2)return {actorId:a.id,riseAcceleration:q.riseAcceleration,maxRiseSpeed:q.maxRiseSpeed};
  }return null;
 }
 function view(actors=[]){return {version:1,scope:'observed-flat-support-player-lift',twisters:actors.filter(a=>ownsActor(a)&&!a.dead).map(a=>({...copy(a),field:copy(rules.get(a.id)),active:active.has(a.id)}))};}
 return Object.freeze({ownsActor,decorateActor,stepActor,playerField,view,reset(){lastTicks.clear();active.clear();}});
}
