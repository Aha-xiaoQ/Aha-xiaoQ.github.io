import {parseProject} from './editor-model.mjs';
import {projectPack} from './editor-runtime.mjs';
import {createStageCatalog} from './runtime/stage-catalog.mjs';
import {validateAdmissionPolicy,validateTestAdmission,validateAdmissionWithdrawal,testAdmissionMatches,admissionForLevel,projectFingerprint,levelContentFingerprint,authoredLevelContent} from './editor-collection-policy.mjs';
export {admissionForLevel,projectFingerprint,levelContentFingerprint} from './editor-collection-policy.mjs';

/** Authored levels, not stock-template names. Keep editor projects intact. */
export const COLLECTION_FORMAT='xiaoq-map-collection', COLLECTION_VERSION=1;
export const COLLECTION_LIMITS=Object.freeze({levels:32,rooms:256,bytes:24*1024*1024,depth:80,nodes:1000000});
const validId=id=>typeof id==='string'&&/^[A-Za-z0-9][A-Za-z0-9_-]{0,71}$/.test(id);
const revision=n=>Number.isSafeInteger(n)&&n>0;
const json=x=>JSON.stringify(x);
const copy=x=>JSON.parse(json(x));
const fail=message=>{throw Error('Collection: '+message);};
const executableKeys=new Set(['script','scripts','javascript','js','eval','code','sourcecode','function','functions','handler','handlers','callback','callbacks','imports','importmap','module','onload','onerror','onclick','onkeydown','onkeyup','onmessage']);

/** Reject executable/accessor values before stringify can silently drop them. */
export function assertSafeCollectionData(value){
 const stack=new WeakSet();let nodes=0;
 function visit(v,depth){
  if(++nodes>COLLECTION_LIMITS.nodes||depth>COLLECTION_LIMITS.depth)fail('data exceeds structural limits');
  if(v===null||typeof v==='boolean'||typeof v==='string')return;
  if(typeof v==='number'){if(!Number.isFinite(v))fail('numbers must be finite');return;}
  if(typeof v!=='object')fail('only plain JSON data is allowed');
  if(stack.has(v))fail('cyclic data is not allowed');
  if(!Array.isArray(v)&&![Object.prototype,null].includes(Object.getPrototypeOf(v)))fail('only plain JSON objects are allowed');
  stack.add(v);
  for(const key of Reflect.ownKeys(v)){
   if(typeof key!=='string')fail('symbol fields are not allowed');
   if(Array.isArray(v)&&key==='length')continue;
   if(['__proto__','prototype','constructor'].includes(key)||executableKeys.has(key.toLowerCase()))fail('unsafe or executable field '+key);
   const desc=Object.getOwnPropertyDescriptor(v,key);
   if(!desc||desc.get||desc.set)fail('accessor fields are not allowed');
   visit(desc.value,depth+1);
  }
  stack.delete(v);
 }
 visit(value,0);
 return value;
}

function noUnknownExtensions(value,where){
 if(value.extensions!==undefined){
  const e=value.extensions;
  if(!e||typeof e!=='object'||(Array.isArray(e)?e.length:Object.keys(e).length))fail(where+' declares unsupported extensions');
 }
 if(value.mechanics!==undefined&&where!=='room')fail(where+' declares unsupported mechanics');
}
function projectFor(value){
 noUnknownExtensions(value,'project');
 const project=parseProject(json(value));
 for(const room of project.rooms){
  noUnknownExtensions(room,'room');
  if(room.devices!==undefined&&!Array.isArray(room.devices))fail('room devices must be an array');
 }
 return project;
}
function validateCompletion(level){
 const spec=level.completion;if(spec===undefined)return;
 if(!spec||typeof spec!=='object'||Array.isArray(spec))fail('invalid completion');
 if(spec.type==='exit'){
  if(Object.keys(spec).some(key=>key!=='type'))fail('exit completion has unsupported fields');
  return;
 }
 if(spec.type!=='checkpoint'||Object.keys(spec).some(key=>!['type','roomId','checkpointId'].includes(key)))fail('unknown completion type or fields');
 const rooms=new Map(level.project.rooms.map(room=>[room.roomId,room])),reached=new Set();
 function visit(roomId){
  if(reached.has(roomId))return;const room=rooms.get(roomId);if(!room)fail('portal target room is missing');reached.add(roomId);
  for(const portal of room.map.objects.filter(object=>object.kind==='portal'))visit(portal.targetRoom);
 }
 visit(level.entryRoom);
 if(typeof spec.roomId!=='string'||typeof spec.checkpointId!=='string'||!reached.has(spec.roomId)||!rooms.get(spec.roomId).map.objects.some(object=>object.kind==='checkpoint'&&object.id===spec.checkpointId))fail('completion checkpoint is missing or unreachable');
}
const pendingApproval=()=>({status:'pending',by:'owner'});
function validateApproval(level){
 if(level.approval===undefined)level.approval=pendingApproval();
 const spec=level.approval;
 if(!spec||typeof spec!=='object'||Array.isArray(spec)||Object.keys(spec).some(key=>!['status','by','evidence','contentFingerprint'].includes(key))||!['pending','approved'].includes(spec.status)||spec.by!=='owner')fail('invalid owner approval');
 if(spec.evidence!==undefined&&(typeof spec.evidence!=='string'||!spec.evidence.trim()||spec.evidence.length>500))fail('approval evidence must be nonempty text up to 500 characters');
 if(spec.contentFingerprint!==undefined&&(spec.status!=='approved'||typeof spec.contentFingerprint!=='string'||!/^[a-f0-9]{64}$/.test(spec.contentFingerprint)))fail('invalid owner approval fingerprint');
}

/** Returns an independent normalized copy; never mutates the supplied document. */
export function validateCollection(value){
 assertSafeCollectionData(value);
 if(!value||value.format!==COLLECTION_FORMAT||value.version!==COLLECTION_VERSION)fail('expected xiaoq-map-collection version 1');
 if(!validId(value.id)||typeof value.title!=='string'||!value.title.trim()||value.title.length>100||!revision(value.revision))fail('invalid ID, title, or revision');
 if(!Array.isArray(value.levels)||value.levels.length>COLLECTION_LIMITS.levels)fail('invalid level count (maximum 32)');
 if(!Array.isArray(value.order)||value.order.length!==value.levels.length)fail('order must contain every level exactly once');
 noUnknownExtensions(value,'collection');
 validateAdmissionPolicy(value.admissionPolicy);
 if(value.admissionPolicy?.mode==='owner-approved-or-tested'&&(value.privateStudy!==true||value.publicDeployment===true))fail('delegated test inclusion is private only');
 const bytes=new TextEncoder().encode(json(value)).length;
 if(bytes>COLLECTION_LIMITS.bytes)fail('file exceeds 24 MB');
 const doc=copy(value),ids=new Set();let rooms=0;
 for(const level of doc.levels){
  if(!level||!validId(level.id)||ids.has(level.id)||!revision(level.revision))fail('duplicate or invalid level ID/revision');
  ids.add(level.id);noUnknownExtensions(level,'level');
  if(!level.project||typeof level.project!=='object')fail('each level needs a full native project');
  level.project=projectFor(level.project);
  if(typeof level.entryRoom!=='string'||!level.project.rooms.some(r=>r.roomId===level.entryRoom))fail('entry room is missing from '+level.id);
  validateCompletion(level);
  validateApproval(level);
  if(level.admissionWithdrawal!==undefined)validateAdmissionWithdrawal(level.admissionWithdrawal);
  if(level.testAdmission!==undefined){validateTestAdmission(level.testAdmission);if(!testAdmissionMatches(level)){delete level.testAdmission;level.approval=pendingApproval();}}
  if(level.approval.contentFingerprint&&level.approval.contentFingerprint!==levelContentFingerprint(level))level.approval=pendingApproval();
  rooms+=level.project.rooms.length;
 }
 if(rooms>COLLECTION_LIMITS.rooms)fail('collection exceeds 256 rooms');
 if(new Set(doc.order).size!==ids.size||doc.order.some(id=>!ids.has(id)))fail('order must contain every level exactly once');
 return doc;
}
export function parseCollection(text){
 if(typeof text!=='string')fail('expected JSON text');
 if(text.length>COLLECTION_LIMITS.bytes||new TextEncoder().encode(text).length>COLLECTION_LIMITS.bytes)fail('file exceeds 24 MB');
 return validateCollection(JSON.parse(text));
}
export function serializeCollection(collection){return JSON.stringify(validateCollection(collection),null,2);}
const freshId=prefix=>prefix+'-'+globalThis.crypto.randomUUID();
export function createCollection(titleOrOptions='我的合集'){
 const options=typeof titleOrOptions==='string'?{title:titleOrOptions}:titleOrOptions;
 return validateCollection({format:COLLECTION_FORMAT,version:1,id:freshId('collection'),title:'我的合集',revision:1,levels:[],order:[],...options});
}
export function addLevel(collection,project,{id=freshId('level'),revision:levelRevision=1,entryRoom=project?.rooms?.[0]?.roomId,...metadata}={}){
 const doc=validateCollection(collection);
 delete metadata.testAdmission;delete metadata.admissionWithdrawal;
 doc.levels.push({...metadata,id,revision:levelRevision,entryRoom,project,approval:pendingApproval()});doc.order.push(id);doc.revision++;
 return validateCollection(doc);
}
export function updateLevel(collection,levelId,project,{entryRoom,...metadata}={}){
 const doc=validateCollection(collection),level=doc.levels.find(level=>level.id===levelId);
 if(!level)fail('level does not exist: '+levelId);
 if(Object.hasOwn(metadata,'id')||Object.hasOwn(metadata,'revision'))fail('update cannot replace stable ID or revision');
 if(Object.hasOwn(metadata,'approval'))fail('use explicit owner approval controls');
 if(Object.hasOwn(metadata,'testAdmission')||Object.hasOwn(metadata,'admissionWithdrawal'))fail('use explicit test admission or owner withdrawal controls');
 const next={...level,...metadata,project:project??level.project,entryRoom:entryRoom??level.entryRoom};
 if(levelContentFingerprint(next)===levelContentFingerprint(level))return doc;
 next.revision=level.revision+1;next.approval=pendingApproval();delete next.testAdmission;doc.levels[doc.levels.indexOf(level)]=next;doc.revision++;
 return validateCollection(doc);
}
/** The caller must have explicit owner approval for this exact level revision. */
export function approveLevel(collection,levelId,evidence){
 const doc=validateCollection(collection),level=doc.levels.find(level=>level.id===levelId);
 if(!level)fail('level does not exist: '+levelId);
 const approval={status:'approved',by:'owner',...(evidence===undefined?{}:{evidence}),contentFingerprint:levelContentFingerprint(level)};
 validateApproval({approval});
 if(json(level.approval)!==json(approval)||level.admissionWithdrawal){level.approval=approval;delete level.admissionWithdrawal;doc.revision++;}
 return validateCollection(doc);
}
export function unapproveLevel(collection,levelId){
 return withdrawLevelAdmission(collection,levelId);
}
/** Explicit owner action blocks delegated re-admission until explicitly restored. */
export function withdrawLevelAdmission(collection,levelId,evidence){
 const doc=validateCollection(collection),level=doc.levels.find(level=>level.id===levelId);
 if(!level)fail('level does not exist: '+levelId);
 const withdrawal={version:1,by:'owner',...(evidence===undefined?{}:{evidence})};validateAdmissionWithdrawal(withdrawal);
 if(json(level.approval)!==json(pendingApproval())||level.testAdmission||json(level.admissionWithdrawal)!==json(withdrawal)){level.approval=pendingApproval();delete level.testAdmission;level.admissionWithdrawal=withdrawal;doc.revision++;}
 return validateCollection(doc);
}
export function restoreLevelAdmission(collection,levelId){const doc=validateCollection(collection),level=doc.levels.find(level=>level.id===levelId);if(!level)fail('level does not exist: '+levelId);if(level.admissionWithdrawal){delete level.admissionWithdrawal;doc.revision++;}return validateCollection(doc);}
/** Caller needs the owner's explicit delegation for private tested versions. */
export function enablePrivateTestInclusion(collection,evidence){return setCollectionAdmissionPolicy(collection,{version:1,mode:'owner-approved-or-tested',scope:'private',by:'owner',evidence});}
export function setCollectionAdmissionPolicy(collection,policy){const doc=validateCollection(collection);validateAdmissionPolicy(policy);if(json(doc.admissionPolicy)!==json(policy)){if(policy===undefined)delete doc.admissionPolicy;else doc.admissionPolicy=copy(policy);if(policy?.mode==='owner-approved-or-tested')doc.privateStudy=true;doc.revision++;}return validateCollection(doc);}
/** Capture before testing, so a later edit cannot reuse older test evidence. */
export function levelTestTarget(collection,levelId){const doc=validateCollection(collection),level=doc.levels.find(level=>level.id===levelId);if(!level)fail('level does not exist: '+levelId);return {levelId,revision:level.revision,projectFingerprint:projectFingerprint(level.project),contentFingerprint:levelContentFingerprint(level)};}
/** Records externally verified evidence; it never grants owner approval. */
export function recordPassedLevelTests(collection,levelId,proof){
 const doc=validateCollection(collection),level=doc.levels.find(level=>level.id===levelId);if(!level)fail('level does not exist: '+levelId);if(level.admissionWithdrawal)fail('owner withdrew admission; explicitly restore before recording new tests');
 assertSafeCollectionData(proof);if(!proof||proof.levelId!==undefined&&proof.levelId!==levelId)fail('test target level does not match');
 if(Object.keys(proof).some(key=>!['levelId','revision','projectFingerprint','contentFingerprint','evidence','summary'].includes(key)))fail('unsupported passed-test input field');
 const record={version:1,status:'passed',by:'automated-tests',revision:proof.revision,projectFingerprint:proof.projectFingerprint,contentFingerprint:proof.contentFingerprint,evidence:proof.evidence,...(proof.summary===undefined?{}:{summary:proof.summary})};validateTestAdmission(record);
 if(record.revision!==level.revision||record.projectFingerprint!==projectFingerprint(level.project)||record.contentFingerprint!==levelContentFingerprint(level))fail('test evidence fingerprint/revision no longer matches current level');
 if(json(level.testAdmission)!==json(record)){level.testAdmission=copy(record);doc.revision++;}return validateCollection(doc);
}
export function removeLevel(collection,levelId){
 const doc=validateCollection(collection);
 if(!doc.levels.some(level=>level.id===levelId))fail('level does not exist: '+levelId);
 doc.levels=doc.levels.filter(level=>level.id!==levelId);doc.order=doc.order.filter(id=>id!==levelId);doc.revision++;
 return validateCollection(doc);
}
export function reorderLevels(collection,order){
 const doc=validateCollection(collection);
 if(json(doc.order)!==json(order)){doc.order=order;doc.revision++;}
 return validateCollection(doc);
}
/** Append/update explicit stable IDs without recreating the collection or order. */
export function upsertLevel(collection,project,{id,entryRoom,...metadata}={}){
 const doc=validateCollection(collection);if(!validId(id))fail('upsert requires an explicit stable level ID');
 if(doc.levels.some(level=>level.id===id))return updateLevel(doc,id,project,{...(entryRoom===undefined?{}:{entryRoom}),...metadata});
 return addLevel(doc,project,{id,entryRoom:entryRoom??project?.rooms?.[0]?.roomId,...metadata});
}

// Two independent deterministic 32-bit hashes keep native namespaces bounded.
// Any collision inside one collection is checked before a pack is built.
function digest(text){
 let a=2166136261,b=5381;
 for(const byte of new TextEncoder().encode(text)){a=Math.imul(a^byte,16777619);b=Math.imul(b,33)^byte;}
 return (a>>>0).toString(16).padStart(8,'0')+(b>>>0).toString(16).padStart(8,'0');
}
export const collectionNamespace=(collectionId,levelId)=>'qmc-'+digest(collectionId)+'-'+digest(levelId);
export function requiredCollectionCapabilities(project){
 const caps=new Set(['native-mario-v1']);
 for(const room of project.rooms){
  if(project.playHero==='bill'||room.playHero==='bill')caps.add('bill-v1');
  if(room.smm2Mechanics?.completionMarks!==undefined)caps.add('typed-pink-door-completion-v1');if(room.smm2Mechanics?.skyShooter)caps.add('authored-armed-cloud-arcade-v1');if(room.smm2Mechanics?.skyShooter?.loopingDivers)caps.add('authored-armed-cloud-looping-divers-v1');if(room.smm2Mechanics?.skyShooter?.enemyFire)caps.add('authored-armed-cloud-enemy-fire-v1');if(room.smm2Mechanics?.arenaAudience)caps.add('authored-jr-arena-audience-v1');if(room.smm2Mechanics?.lighting?.sweepingLamps?.length)caps.add('authored-sweeping-spotlights-v1');if(room.contraptions)caps.add('contraptions-v1');if(room.contraptions?.coinCranes?.length)caps.add('original-coin-crane-v1');if(room.contraptions?.coinCranes?.some(q=>q.payment||q.payloads?.length))caps.add('original-paid-arcade-crane-v1');if(room.contraptions?.chainChompGuards?.length)caps.add('authored-chain-chomp-guard-v1');if(room.castle)caps.add('castle-components-v1');if(room.underwater)caps.add('swimming-v1');if(room.aquatic)caps.add('aquatic-components-v1');
  if(room.nativeSceneryMode!==undefined||room.decorations?.some(q=>q.nativeScenery))caps.add('native-scenery-v1');
  if(room.decorations?.some(q=>q.smm2Art?.startsWith('authored-door-feature-')))caps.add('authored-door-feature-signs-v1');
  if(room.mechanics)caps.add('echo-cooperation-v1');
  if(room.switchStudy)caps.add('switch-study-v1');
  if(room.marioModules)caps.add('mario-modules-v1');
  if(room.marioModules?.itemSources?.some(q=>q.item==='flower'))caps.add('flower-pipe-supply-v1');
  if(room.castle?.boss?.battle?.version===1)caps.add('castle-boss-battle-v1');
  if(room.castle?.finish?.requireBossDefeated===true)caps.add('boss-gated-castle-finish-v1');
  if(room.marioModules?.carryEnemiesOnPlatforms===true)caps.add('native-enemy-platform-carry-v1');
  if(room.smm2Mechanics?.bowserJuniors?.version===1)caps.add('bowser-jr-ground-v1');
  if(room.smm2Mechanics?.version===1)caps.add('smm2-components-v1');if(room.smm2Mechanics?.lighting)caps.add('explicit-night-lighting-v1');if(room.smm2Mechanics?.lighting?.offRadiusScale!==undefined)caps.add('switch-linked-night-lighting-v1');if(room.smm2Mechanics?.carrierItems?.length)caps.add('pow-top-support-v1');if(room.smm2Mechanics?.pSwitches?.length)caps.add('authored-p-switches-v1');if(room.smm2Mechanics?.goalCard)caps.add('smb3-goal-card-v1');if(room.smm2Mechanics?.springs?.length)caps.add('oriented-springs-v1');if(room.smm2Mechanics?.art?.palette==='smb3-underground')caps.add('smb3-study-art-v1');if(room.contraptions?.claws?.some(q=>q.anchor))caps.add('static-claws-v1');
  if(room.marioModules&&(room.marioModules.castleFlagRiseFrames!==undefined||room.marioModules.starFrames!==undefined||room.marioModules.starKillPoints!==undefined||room.marioModules.rewardWindows||Object.values(room.marioModules.enemyVariants||{}).some(v=>['hopping-koopa','pipe-piranha'].includes(v.kind))))caps.add('classic-interactions-v1');
  if(room.playRules)caps.add('mario-play-rules-v1');if(room.missionBrief)caps.add('mission-brief-v1');
  if(room.checkpointVisuals)caps.add('checkpoint-feedback-v1');
  if(room.checkpointRules)caps.add('hidden-midpoint-v1');
  if(room.marioModules&&(room.marioModules.motionPlatforms||room.marioModules.contactPlatforms||room.marioModules.scaleRules||Object.values(room.marioModules.enemyVariants||{}).some(v=>v.kind==='vertical-koopa')))caps.add('classic-motion-v1');
  if(room.map.geometry.some(g=>g.motion))caps.add('moving-platforms-v1');
  if(room.markers.some(m=>m.kind==='coupled-scale'))caps.add('paired-scale-v1');
  if(room.map.objects.some(o=>o.kind==='portal'))caps.add('portals-v1');
  if(room.map.objects.some(o=>o.kind==='checkpoint'))caps.add('checkpoints-v1');
 }
 return [...caps].sort();
}
function runtimeRooms(project,pack){
 const rooms=copy(project.rooms.filter(room=>Object.hasOwn(pack.stages[0].rooms,room.roomId)));
 for(const room of rooms)for(const marker of room.markers||[]){
  // Native stock-world warp pipes are outside an authored collection's graph.
  // Keep their artwork and editable source, but disable the runtime transport.
  if(marker.source?.transport&&typeof marker.source.transport==='object'&&Object.hasOwn(marker.source.transport,'map'))delete marker.source.transport;
 }
 return rooms;
}
/** Builds only included authored data. No template fetch, global cache, or I/O. */
export function buildCollection(collection,character,{includePending=false}={}){
 const doc=validateCollection(collection);
 if(typeof includePending!=='boolean')fail('includePending must be a boolean');
 if(!doc.levels.length)fail('add at least one level before playing or exporting');
 const included=doc.levels.filter(level=>includePending||admissionForLevel(level,doc.admissionPolicy).eligible);
 if(!included.length)fail('no owner-approved levels; review and explicitly approve a level before exporting a playable collection');
 const order=doc.order.filter(id=>included.some(level=>level.id===id));
 const namespaces=new Set(),byId=new Map(doc.levels.map(level=>[level.id,level]));
 const levels=order.map(id=>{
  const level=byId.get(id),namespace=collectionNamespace(doc.id,level.id);
  if(namespaces.has(namespace))fail('native namespace collision; choose a different level ID');namespaces.add(namespace);
  const project=copy(level.project),pack=projectPack(project,level.entryRoom,character,namespace);
  // Native projectPack uses one default character ID; give every authored pack
  // its own character too, so combined exports never overwrite another level.
  pack.characters[0].id=namespace+'-hero';pack.stages[0].characters=[pack.characters[0].id];
  createStageCatalog(pack);
  return {...level,title:project.title,completion:copy(level.completion||{type:'exit'}),namespace,project,pack,rooms:runtimeRooms(project,pack),authoredContent:copy(authoredLevelContent(level)),admission:admissionForLevel(level,doc.admissionPolicy),requiredCapabilities:requiredCollectionCapabilities(project)};
 });
 return {...doc,format:'xiaoq-map-collection-runtime',version:1,levels,order,requiredCapabilities:[...new Set(levels.flatMap(level=>level.requiredCapabilities))].sort()};
}
