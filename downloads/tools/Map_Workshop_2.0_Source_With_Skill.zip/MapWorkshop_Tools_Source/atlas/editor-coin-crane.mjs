/** Original workshop coin-crane cycle. This is not SMM2 Swinging Claw physics.
 * A real head collision locks a scanning carriage; the controller moves linked real world bodies.
 * Rendering/view never advances this controller or awards coins/keys. */
import {validateWalkingKoopaVariant} from './editor-walking-koopa.mjs';
export const COIN_CRANE_DEFAULTS=Object.freeze({speed:.75,dropSpeed:1.5,liftSpeed:1.5,captureHalfWidth:6,closeFrames:12,openFrames:12});
const GRAVITY=.22,MAX_FALL_SPEED=4;
const copy=x=>JSON.parse(JSON.stringify(x));
const safeId=x=>typeof x==='string'&&/^[a-zA-Z0-9][a-zA-Z0-9_.:-]{0,99}$/.test(x)&&!['__proto__','constructor','prototype'].includes(x);
const finite=(x,a,b)=>Number.isFinite(x)&&x>=a&&x<=b;
const overlap=(a,b)=>a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y;
const fail=s=>{throw Error(s);};
const move=(a,b,s)=>a+Math.sign(b-a)*Math.min(s,Math.abs(b-a));

const PAYLOAD_KINDS=new Set(['coin','goomba','spiny','bomb','large-coin','live-goomba','live-koopa']);
const coinKind=kind=>['pink','coin','large-coin'].includes(kind);
const liveKind=kind=>['live-goomba','live-koopa'].includes(kind);
const hitspanKind=kind=>kind==='large-coin'||liveKind(kind);
const exactFields=(q,keys,label)=>{if(!q||typeof q!=='object'||Array.isArray(q)||Object.keys(q).some(k=>!keys.includes(k)))fail('Unknown '+label+' field');};
function validateCoinCraneExtensions(room,q,all,coins,payloadIds){
 if(q.cabinet!==undefined){exactFields(q.cabinet,['x','y','w','h'],'coin crane cabinet');const c=q.cabinet;if(!finite(c.w,32,room.map.width)||!finite(c.h,32,room.map.height)||!finite(c.x,0,room.map.width-c.w)||!finite(c.y,0,room.map.height-c.h))fail('Coin crane cabinet must fit its room');}
 if(q.payment!==undefined){
  const p=q.payment;exactFields(p,['price','entryBonus','slotId','slot','trigger'],'coin crane payment');
  if(p.price!==1||![0,10].includes(p.entryBonus)||p.trigger!==undefined&&!['up','approach'].includes(p.trigger))fail('Paid coin crane price must be 1, entryBonus must be 0 or 10, and trigger must be up or approach');
  if(!safeId(p.slotId)||all.has(p.slotId))fail('Paid coin crane needs a unique slot ID');all.add(p.slotId);
  exactFields(p.slot,['x','y','w','h'],'coin crane payment slot');const slot=p.slot;
  if(slot.w!==16||slot.h!==16||!finite(slot.x,0,room.map.width-16)||!finite(slot.y,0,room.map.height-16))fail('Paid coin crane slot must be a bounded 16px actor');
  if(room.map.geometry.some(g=>g.collision==='solid'&&!g.hidden&&overlap(slot,g))||room.map.objects.some(o=>o.kind==='portal'&&overlap(slot,o)))fail('Paid coin crane slot needs clear terrain and a separate interaction position');
 }
 if(q.payloads===undefined)return;
 if(!Array.isArray(q.payloads)||q.payloads.length>24)fail('Invalid coin crane payloads list');
 for(const p of q.payloads){
  exactFields(p,['id','kind','motion'],'coin crane payload');const body=room.map.objects.find(o=>o.id===p.id);
  const expectedKind=coinKind(p.kind)?'coin':liveKind(p.kind)?'walker':'crate';
  const validSize=p.kind==='large-coin'?body?.w===32&&body?.h===32:p.kind==='live-goomba'?body?.w===16&&body?.h===16:p.kind==='live-koopa'?body?.w===16&&body?.h===24:finite(body?.w,1,16)&&finite(body?.h,1,16);
  if(!safeId(p.id)||p.id===q.coinId||payloadIds.has(p.id)||coins.has(p.id)||!PAYLOAD_KINDS.has(p.kind)||!body||body.kind!==expectedKind||body.hidden||body.motion||!validSize||!finite(body.x,0,room.map.width-body.w)||!finite(body.y,0,room.map.height-body.h)||(room.smm2Mechanics?.pinkCoins||[]).some(o=>o.id===p.id))fail('Coin crane payload needs one unique matching real coin, live walker or inert crate body');
  if(p.kind==='large-coin'&&room.marioModules?.coinValues?.[p.id]!==10)fail('Large coin crane payload needs a real 32px coin with coinValues 10');
  if(p.kind==='live-goomba'&&(!room.markers?.some(m=>m.id===p.id&&/^(?:enemy-|marker-)?goomba$/i.test(m.kind))||room.marioModules?.enemyVariants?.[p.id]||room.enemySkins?.[p.id]&&!/^(?:enemy-|marker-)?goomba$/i.test(room.enemySkins[p.id])))fail('Live Goomba crane payload needs an ordinary native Goomba marker');
  if(p.kind==='live-koopa'&&(room.marioModules?.enemyVariants?.[p.id]?.kind!=='walking-koopa'||room.marioModules.enemyVariants[p.id].size!=='normal'))fail('Live Koopa crane payload needs a normal native Walking Koopa variant');
  if(p.kind==='live-koopa')validateWalkingKoopaVariant(room,p.id,room.marioModules.enemyVariants[p.id]);
  payloadIds.add(p.id);if(coinKind(p.kind))coins.add(p.id);
  const cx=body.x+body.w/2,cy=body.y+body.h/2;
  const badHeight=hitspanKind(p.kind)?body.y<q.restY||q.grabY<body.y||q.grabY>body.y+body.h:cy<q.restY+body.h/2||cy>q.grabY||p.kind!=='bomb'&&Math.abs(cy-q.grabY)>.01;
  if(cx<q.minX||cx>q.maxX||badHeight)fail('Coin crane payload must stay inside its cabinet and meet the grab height with its real body');
  if(q.cabinet&&(body.x<q.cabinet.x||body.x+body.w>q.cabinet.x+q.cabinet.w||body.y<q.cabinet.y||body.y+body.h>q.cabinet.y+q.cabinet.h))fail('Coin crane payload must fit its cabinet');
  if(room.map.geometry.some(g=>g.collision==='solid'&&!g.hidden&&overlap(body,g)))fail('Coin crane payload overlaps solid terrain');
  if(hitspanKind(p.kind)){const aperture=q.captureHalfWidth??COIN_CRANE_DEFAULTS.captureHalfWidth,top=q.restY+cy-q.grabY-body.h/2,deliveryBottom=q.deliveryY+cy-q.grabY+body.h/2;const paths=[{x:body.x,y:top,w:body.w,h:body.y+body.h-top},{x:Math.min(cx,q.deliveryX-aperture)-body.w/2,y:top,w:Math.max(cx,q.deliveryX+aperture)-Math.min(cx,q.deliveryX-aperture)+body.w,h:body.h},{x:q.deliveryX-aperture-body.w/2,y:top,w:body.w+2*aperture,h:deliveryBottom-top}];if(paths.some(path=>path.x<0||path.y<0||path.x+path.w>room.map.width||path.y+path.h>room.map.height||room.map.geometry.some(g=>g.collision==='solid'&&!g.hidden&&overlap(path,g))))fail('Large/live coin crane payload needs a clear full-body lift, transfer and delivery path');}
  if(p.motion!==undefined){const m=p.motion;exactFields(m,['minX','maxX','y','speed','phase'],'coin crane payload motion');if(p.kind!=='bomb'||!finite(m.minX,q.minX,q.maxX)||!finite(m.maxX,q.minX,q.maxX)||m.maxX-m.minX<8||!finite(m.y,q.restY+body.h/2,q.grabY)||!finite(m.speed,.05,4)||m.phase!==undefined&&!finite(m.phase,0,2*(m.maxX-m.minX))||cx<m.minX||cx>m.maxX||Math.abs(cy-m.y)>.01)fail('Only an inert bomb may use a bounded cabinet motion path');
   const sweep={x:m.minX-body.w/2,y:m.y-body.h/2,w:m.maxX-m.minX+body.w,h:body.h};if(q.cabinet&&(sweep.x<q.cabinet.x||sweep.x+sweep.w>q.cabinet.x+q.cabinet.w||sweep.y<q.cabinet.y||sweep.y+sweep.h>q.cabinet.y+q.cabinet.h))fail('Coin crane bomb path must fit its cabinet');if(room.map.geometry.some(g=>g.collision==='solid'&&!g.hidden&&overlap(sweep,g)))fail('Coin crane bomb motion needs clear cabinet terrain');
  }
 }
}

export function validateCoinCranes(room,s=room.contraptions){
 const ownedPrizeIds=new Set((s?.coinCranes||[]).flatMap(q=>(q.payloads||[]).filter(p=>p.kind!=='coin').map(p=>p.id)));
 if(room.map.objects.some(o=>o.kind==='crate'&&!ownedPrizeIds.has(o.id)))fail('Arcade prize crates require a linked crane payload; they are not generic solid boxes');
 if(s?.coinCranes===undefined)return;
 if(!Array.isArray(s.coinCranes)||s.coinCranes.length>32)fail('Invalid coinCranes list');
 const all=new Set([...room.map.geometry,...room.map.objects,...(s.tracks||[]),...(s.claws||[]),...(s.notes||[]),...(s.cars||[]),...(s.pSources||[]),...(s.oneWayWalls||[])].map(q=>q.id)),coins=new Set(),buttons=new Set(),glass=new Set(),payloadIds=new Set();
 const fields=['id','coinId','buttonId','minX','maxX','restY','grabY','deliveryX','deliveryY','speed','dropSpeed','liftSpeed','captureHalfWidth','closeFrames','openFrames','initialX','direction','glassIds','payment','payloads','cabinet','searchlight'];
 for(const q of s.coinCranes){
  if(!q||typeof q!=='object'||Array.isArray(q)||Object.keys(q).some(k=>!fields.includes(k)))fail('Unknown coin crane field');
  if(!safeId(q.id)||all.has(q.id))fail('Duplicate or invalid coin crane ID');all.add(q.id);
  const coin=room.map.objects.find(o=>o.id===q.coinId),button=room.map.geometry.find(g=>g.id===q.buttonId);
  if(!safeId(q.coinId)||coins.has(q.coinId)||coin?.kind!=='coin'||!(room.smm2Mechanics?.pinkCoins||[]).some(p=>p.id===q.coinId)||coin.w>16||coin.h>16||coin.hidden||coin.motion)fail('Coin crane needs one unique real typed Pink coin');coins.add(q.coinId);
  if(!safeId(q.buttonId)||buttons.has(q.buttonId)||!button||button.w!==16||button.h!==16||!finite(button.x,0,room.map.width-16)||!finite(button.y,0,room.map.height-16)||button.collision!=='solid'||button.hidden||button.motion||button.content||button.reward||room.switchStudy?.devices?.some(d=>d.id===button.id))fail('Coin crane needs one dedicated visible solid 16px button');buttons.add(q.buttonId);
  if(!['minX','maxX','deliveryX'].every(k=>finite(q[k],28,room.map.width-28))||q.maxX-q.minX<16||!['restY','grabY','deliveryY'].every(k=>finite(q[k],40,room.map.height-20))||q.grabY<=q.restY||q.deliveryY<q.restY)fail('Coin crane path is outside its room or inverted');
  if(!finite(coin.x,0,room.map.width-coin.w)||!finite(coin.y,0,room.map.height-coin.h)||coin.x+coin.w/2<q.minX||coin.x+coin.w/2>q.maxX||Math.abs(coin.y+coin.h/2-q.grabY)>.01)fail('Coin crane grabY must be the real coin centre within its scan');
  if(q.initialX!==undefined&&!finite(q.initialX,q.minX,q.maxX)||q.direction!==undefined&&q.direction!==1&&q.direction!==-1)fail('Invalid coin crane initial carriage state');
  for(const [k,a,b]of [['speed',.05,4],['dropSpeed',.05,8],['liftSpeed',.05,8],['captureHalfWidth',.5,16]])if(q[k]!==undefined&&!finite(q[k],a,b))fail('Invalid coin crane '+k);
  for(const k of ['closeFrames','openFrames'])if(q[k]!==undefined&&(!Number.isInteger(q[k])||!finite(q[k],1,120)))fail('Invalid coin crane '+k);
  validateCoinCraneExtensions(room,q,all,coins,payloadIds);
  if(q.searchlight!==undefined){exactFields(q.searchlight,['buttonId','initialOn'],'coin crane searchlight');const light=q.searchlight,lampButton=room.map.geometry.find(g=>g.id===light.buttonId);if(!safeId(light.buttonId)||buttons.has(light.buttonId)||typeof light.initialOn!=='boolean'||!lampButton||lampButton.w!==16||lampButton.h!==16||!finite(lampButton.x,0,room.map.width-16)||!finite(lampButton.y,0,room.map.height-16)||lampButton.collision!=='solid'||lampButton.hidden||lampButton.motion||lampButton.content||lampButton.reward||room.switchStudy?.devices?.some(d=>d.id===lampButton.id)||room.map.geometry.some(g=>g.id!==lampButton.id&&g.collision==='solid'&&!g.hidden&&overlap(lampButton,g))||room.map.objects.some(o=>o.kind==='portal'&&overlap(lampButton,o)))fail('Coin crane searchlight needs one separate visible solid 16px button and explicit initialOn');buttons.add(light.buttonId);}
  if(q.glassIds!==undefined){if(!Array.isArray(q.glassIds)||q.glassIds.length>16)fail('Invalid coin crane glassIds');for(const id of q.glassIds){const g=room.map.geometry.find(g=>g.id===id);if(!safeId(id)||glass.has(id)||id===q.buttonId||!g||g.hidden||g.motion||g.collision!=='solid'||!finite(g.w,4,32)||!finite(g.h,1,room.map.height)||!finite(g.x,0,room.map.width-g.w)||!finite(g.y,0,room.map.height-g.h))fail('Coin crane glass needs unique static bounded solid geometry');glass.add(id);}}
  for(const p of [coin,button,{x:q.deliveryX-coin.w/2,y:q.deliveryY-coin.h/2,w:coin.w,h:coin.h}])if(room.map.geometry.some(g=>g.id!==button.id&&g.collision==='solid'&&!g.hidden&&overlap(p,g)))fail('Coin crane coin/button/delivery overlaps solid terrain');
  const aperture=q.captureHalfWidth??COIN_CRANE_DEFAULTS.captureHalfWidth,cx=coin.x+coin.w/2;
  const paths=[{x:coin.x,y:q.restY-coin.h/2,w:coin.w,h:q.grabY-q.restY+coin.h},{x:Math.min(cx,q.deliveryX-aperture)-coin.w/2,y:q.restY-coin.h/2,w:Math.max(cx,q.deliveryX+aperture)-Math.min(cx,q.deliveryX-aperture)+coin.w,h:coin.h},{x:q.deliveryX-aperture-coin.w/2,y:q.restY-coin.h/2,w:coin.w+2*aperture,h:q.deliveryY-q.restY+coin.h}];
  if(paths.some(p=>room.map.geometry.some(g=>g.collision==='solid'&&!g.hidden&&overlap(p,g))))fail('Coin crane needs a clear physical coin lift, transfer and delivery path');
 }
 if(s.coinCranes.length&&(room.aquatic||room.underwater||room.mechanics||/Underwater/.test(room.setting||'')))fail('Original coin crane is a dry native room mechanism');
}
function createFreeCoinCranes(room,{emit=()=>{}}={}){
 const specs=room?.contraptions?.coinCranes;if(!specs?.length)return null;
 validateCoinCranes(room);let lastTick=null,paused=false,lastHead=null;
 const states=specs.map(q=>({spec:{...COIN_CRANE_DEFAULTS,...copy(q)},home:copy(room.map.objects.find(o=>o.id===q.coinId))}));
 const event=(name,s,data={})=>emit('coin-crane',{event:name,roomId:room.roomId,craneId:s.spec.id,coinId:s.spec.coinId,...data});
 const taken=(s,ids)=>ids?.has(s.spec.coinId);
 function reset({objects=[],taken:ids=new Set()}={}){lastTick=null;lastHead=null;for(const s of states){Object.assign(s,{phase:taken(s,ids)?'collected':'scan',x:s.spec.initialX??s.spec.minX,y:s.spec.restY,direction:s.spec.direction??1,closed:false,held:false,age:0,cycles:0,vy:0,released:false,offsetX:0,offsetY:0});const coin=objects.find(q=>q.id===s.spec.coinId);if(coin&&!taken(s,ids)){coin.x=s.home.x;coin.y=s.home.y;}}}
 reset();
 function headHit(id,{tick,objects=[],taken:ids=new Set()}={}){
  const s=states.find(s=>s.spec.buttonId===id);if(!s)return false;
  if(paused||lastHead?.id===id&&lastHead.tick===tick)return true;lastHead={id,tick};
  if(s.phase!=='scan'||taken(s,ids)||!objects.some(q=>q.id===s.spec.coinId)){event('button-ignored',s,{tick,phase:s.phase});return true;}
  s.phase='lower';s.age=0;s.cycles++;event('button-press',s,{tick,lockedX:s.x,cycle:s.cycles});emit('sound',{event:'bump'});return true;
 }
 function shiftCoin(s,coin,x,y,geometry){
  const dx=x-coin.x,dy=y-coin.y,n=Math.max(1,Math.ceil(Math.max(Math.abs(dx),Math.abs(dy))*2));
  for(let i=1;i<=n;i++){const candidate={...coin,x:coin.x+dx*i/n,y:coin.y+dy*i/n};const solid=geometry.find(g=>g.collision==='solid'&&!g.hidden&&overlap(candidate,g));if(solid){event('transport-blocked',s,{solidId:solid.id});return false;}}
  coin.x=x;coin.y=y;return true;
 }
 function step({tick,objects=[],geometry=[],taken:ids=new Set()}={}){
  if(paused||tick===lastTick)return false;lastTick=tick;
  for(const s of states){const q=s.spec,coin=objects.find(o=>o.id===q.coinId);if(taken(s,ids)||!coin){if(s.phase!=='collected'){s.phase='collected';s.held=false;s.closed=false;event('coin-collected',s,{tick});}continue;}
   if(s.phase==='collected')continue;
   if(s.phase==='scan'){const distance=s.x-q.minX+s.direction*q.speed,span=q.maxX-q.minX,period=2*span,p=((distance%period)+period)%period;s.x=q.minX+(p<=span?p:period-p);if(distance<0||distance>span)s.direction*=-1;}
   else if(s.phase==='lower'){s.y=move(s.y,q.grabY,q.dropSpeed);if(s.y===q.grabY){s.phase='close';s.age=0;}}
   else if(s.phase==='close'){s.closed=true;if(++s.age>=q.closeFrames){const cx=coin.x+coin.w/2,cy=coin.y+coin.h/2;s.held=Math.abs(cx-s.x)<=q.captureHalfWidth&&Math.abs(cy-s.y)<=.5;if(s.held){s.offsetX=cx-s.x;s.offsetY=cy-s.y;event('capture',s,{tick,position:{x:coin.x,y:coin.y},grip:{x:s.x,y:s.y}});emit('sound',{event:'appear'});}else{event('miss',s,{tick,lockedX:s.x,coinCentre:{x:cx,y:cy}});emit('sound',{event:'bump'});}s.phase='raise';}}
   else if(s.phase==='raise'){s.y=move(s.y,q.restY,q.liftSpeed);if(s.y===q.restY)s.phase=s.held?'transfer':'return';}
   else if(s.phase==='transfer'){s.x=move(s.x,q.deliveryX,q.speed);if(s.x===q.deliveryX){s.phase='deliver';event('delivery-arrival',s,{tick});}}
   else if(s.phase==='deliver'){s.y=move(s.y,q.deliveryY,q.dropSpeed);if(s.y===q.deliveryY){s.phase='open';s.age=0;}}
   else if(s.phase==='open'){s.closed=false;if(++s.age>=q.openFrames){s.held=false;s.released=true;s.vy=0;s.phase='return';event('release',s,{tick,position:{x:coin.x,y:coin.y}});emit('sound',{event:'appear'});}}
   else if(s.phase==='return'){s.y=move(s.y,q.restY,q.liftSpeed);if(s.y===q.restY)s.x=move(s.x,q.minX,q.speed);if(s.y===q.restY&&s.x===q.minX){s.closed=false;s.phase=s.released?'delivered':'scan';s.direction=1;event(s.released?'cycle-complete':'retry-ready',s,{tick});}}
   if(s.held&&!shiftCoin(s,coin,s.x+s.offsetX-coin.w/2,s.y+s.offsetY-coin.h/2,geometry)){s.held=false;s.closed=false;s.released=true;s.vy=0;s.phase='return';}
   if(s.released&&!s.held){s.vy=Math.min(MAX_FALL_SPEED,s.vy+GRAVITY);const bottom=coin.y+coin.h,next=coin.y+s.vy,land=geometry.filter(g=>!g.hidden&&['solid','oneway'].includes(g.collision)&&coin.x+coin.w>g.x&&coin.x<g.x+g.w&&bottom<=g.y+.001&&next+coin.h>=g.y).sort((a,b)=>a.y-b.y)[0];if(land){coin.y=land.y-coin.h;s.vy=0;}else coin.y=Math.min(room.map.height-coin.h,next);}
  }return true;
 }
 function view(){return {coinCranes:states.map(s=>({...copy(s.spec),phase:s.phase,grip:{x:s.x,y:s.y},anchor:{x:s.x,y:s.spec.restY-32},direction:s.direction,closed:s.closed,heldId:s.held?s.spec.coinId:null,released:s.released,cycle:s.cycles,buttonPressed:!['scan','collected','delivered'].includes(s.phase)}))};}
 return Object.freeze({step,headHit,reset,view,pause(value=true){paused=!!value;},ownsCoin:id=>states.some(s=>s.spec.coinId===id),ownsObject:id=>states.some(s=>s.spec.coinId===id),isInertPayload:()=>false,isCaptiveActor:()=>false,npcDisposition:()=>null,canCollectCoin:id=>{const s=states.find(s=>s.spec.coinId===id);return !s||s.released&&!s.held;}});
}

/** Optional paid/multiple-payload controller. Legacy cranes use the unchanged
 * single-Pink implementation above. The bank is the course-session wallet. */
export function createCoinCranes(room,options={}){
 const specs=room?.contraptions?.coinCranes;
 if(!specs?.some(q=>q.payment!==undefined||q.payloads!==undefined||q.searchlight!==undefined))return createFreeCoinCranes(room,options);
 validateCoinCranes(room);
 const {emit=()=>{},bank}=options;
 if(specs.some(q=>q.payment)&&(!bank||['balance','grantOnce','setCredit','spend'].some(k=>typeof bank[k]!=='function')||typeof(bank.credit??bank.getCredit)!=='function'))throw Error('Paid coin crane requires a course-session bank');
 let paused=false,lastTick=null,lastHead=null,payHeld=false,currentObjects=[],currentTaken=new Set();
 const states=specs.map(q=>({spec:{...COIN_CRANE_DEFAULTS,...copy(q)},token:String(room.roomId)+':'+q.id,items:[{id:q.coinId,kind:'pink'},...(q.payloads||[])].map(p=>({...copy(p),home:copy(room.map.objects.find(o=>o.id===p.id))}))}));
 const event=(name,s,data={})=>emit('coin-crane',{event:name,roomId:room.roomId,craneId:s.spec.id,coinId:s.spec.coinId,...data});
 const credit=s=>s.spec.payment?Math.max(0,Number((bank.credit??bank.getCredit).call(bank,s.token))||0):1;
 const primaryTaken=(s,ids=currentTaken)=>ids.has(s.spec.coinId);
 // Stage appends real native NPC references after its authored walker copies.
 const bodyFor=(item,objects=currentObjects)=>objects.findLast(o=>o.id===item.id&&(!liveKind(item.kind)||typeof o.type==='string'));
 const objectOwner=id=>states.find(s=>s.items.some(item=>item.id===id));
 const actorId=actor=>typeof actor==='string'?actor:actor?.id;
 const npcDisposition=actor=>{const id=actorId(actor),s=objectOwner(id),item=s?.items.find(item=>item.id===id);return item&&liveKind(item.kind)?item.released?'native':s.heldId===id?'held':item.falling?'falling':'captive':null;};
 function holdNative(item,body){if(!liveKind(item.kind)||!body)return;item.nativeBody=body;if(item.walkVx===undefined)item.walkVx=body.vx||body.smm2WalkingKoopa?.walkDirection*body.smm2WalkingKoopa?.variant.walkSpeed||room.marioModules?.enemyVariants?.[item.id]?.direction*room.marioModules?.enemyVariants?.[item.id]?.walkSpeed||-.5;body.vx=0;body.vy=0;body.grounded=false;body.support=null;}
 function releaseNative(item,body){if(!liveKind(item.kind)||!body)return;body.vx=item.walkVx;body.vy=0;body.grounded=false;body.support=null;item.falling=false;}
 function reset({objects=[],taken:ids=new Set(),entry=false}={}){
  if(entry)for(const s of states)if(s.spec.payment?.entryBonus>0&&bank.grantOnce(room.roomId,s.spec.payment.entryBonus)===true)event('entry-bonus',s,{amount:s.spec.payment.entryBonus});
  lastTick=null;lastHead=null;currentObjects=objects;currentTaken=ids;
  for(const s of states){Object.assign(s,{phase:primaryTaken(s,ids)?'collected':'scan',x:s.spec.initialX??s.spec.minX,y:s.spec.restY,direction:s.spec.direction??1,closed:false,heldId:null,age:0,cycles:0,bombFlash:0,paymentFlash:0,lampOn:s.spec.searchlight?.initialOn??false,failedKind:null,offsetX:0,offsetY:0,released:false,nearPayment:false});
   for(const item of s.items){const body=bodyFor(item,objects);if(liveKind(item.kind)&&item.released&&body===item.nativeBody){item.falling=false;continue;}item.released=false;item.falling=false;item.returned=false;item.vy=0;item.motionAge=0;if(body&&!ids.has(item.id)){body.x=item.home.x;body.y=item.home.y;holdNative(item,body);}}
  }
 }
 reset();
 function pay(slotId,{tick,objects=currentObjects,taken:ids=currentTaken}={}){
  const s=states.find(s=>s.spec.payment?.slotId===slotId);if(!s)return false;
  if(paused||s.phase!=='scan'||primaryTaken(s,ids)||!objects.some(o=>o.id===s.spec.coinId)||credit(s)>0){event('payment-ignored',s,{tick,phase:s.phase});return true;}
  if(bank.spend(s.spec.payment.price)!==true){event('payment-rejected',s,{tick,price:s.spec.payment.price,wallet:bank.balance()});emit('sound',{event:'bump'});return true;}
  bank.setCredit(s.token,1);s.paymentFlash=12;event('payment-accepted',s,{tick,price:s.spec.payment.price,wallet:bank.balance()});emit('sound',{event:'pickup'});return true;
 }
 function headHit(id,{tick,objects=currentObjects,taken:ids=currentTaken}={}){
  const lamp=states.find(s=>s.spec.searchlight?.buttonId===id);if(lamp){if(paused||lastHead?.id===id&&lastHead.tick===tick)return true;lastHead={id,tick};lamp.lampOn=!lamp.lampOn;event('lamp-toggle',lamp,{tick,buttonId:id,lampOn:lamp.lampOn});emit('sound',{event:'bump'});return true;}
  const s=states.find(s=>s.spec.buttonId===id);if(!s)return false;
  if(paused||lastHead?.id===id&&lastHead.tick===tick)return true;lastHead={id,tick};
  if(s.phase!=='scan'||primaryTaken(s,ids)||!objects.some(o=>o.id===s.spec.coinId)){event('button-ignored',s,{tick,phase:s.phase});return true;}
  if(s.spec.payment&&credit(s)<1){event('payment-needed',s,{tick,price:s.spec.payment.price,wallet:bank.balance()});emit('sound',{event:'bump'});return true;}
  if(s.spec.payment)bank.setCredit(s.token,0);
  s.phase='lower';s.age=0;s.cycles++;s.failedKind=null;s.released=false;event('button-press',s,{tick,lockedX:s.x,cycle:s.cycles,price:s.spec.payment?.price??0});emit('sound',{event:'bump'});return true;
 }
 function shiftBody(s,body,x,y,geometry){
  const dx=x-body.x,dy=y-body.y,n=Math.max(1,Math.ceil(Math.max(Math.abs(dx),Math.abs(dy))*2));
  for(let i=1;i<=n;i++){const candidate={...body,x:body.x+dx*i/n,y:body.y+dy*i/n};const solid=geometry.find(g=>g.collision==='solid'&&!g.hidden&&overlap(candidate,g));if(solid){event('transport-blocked',s,{solidId:solid.id,payloadId:body.id});return false;}}
  body.x=x;body.y=y;return true;
 }
 const dropInBin=(s,tick,reason)=>{const item=s.items.find(item=>item.id===s.heldId);if(item){item.falling=true;item.vy=0;item.released=false;item.returned=true;holdNative(item,bodyFor(item));}s.heldId=null;s.closed=false;s.phase='return';s.failedKind=reason;event('payload-return',s,{tick,...(item?{payloadId:item.id,kind:item.kind}:{}),reason});};
 function lowerTarget(s,objects,ids){const q=s.spec;if(!s.items.some(item=>hitspanKind(item.kind)))return q.grabY;const returned=s.items.filter(item=>item.returned&&!item.released&&!ids.has(item.id)).map(item=>bodyFor(item,objects)).filter(body=>body&&!body.dead&&Math.abs(body.x+body.w/2-s.x)<=q.captureHalfWidth&&(!q.cabinet||body.x>=q.cabinet.x&&body.x+body.w<=q.cabinet.x+q.cabinet.w&&body.y+body.h<=q.cabinet.y+q.cabinet.h));return returned.length?Math.max(q.grabY,Math.min(...returned.map(body=>body.y+body.h/2))):q.grabY;}
 function step({tick,objects=[],geometry=[],taken:ids=new Set(),payPressed=false,nearSlotId,nearSlot=false}={}){
  if(paused||tick===lastTick)return false;lastTick=tick;currentObjects=objects;currentTaken=ids;
  for(const s of states)if(s.paymentFlash>0)s.paymentFlash--;
  const payEdge=!!payPressed&&!payHeld;payHeld=!!payPressed;
  const paidStates=states.filter(s=>s.spec.payment),slot=nearSlotId||(nearSlot&&paidStates.length===1?paidStates[0].spec.payment.slotId:null);
  for(const s of paidStates){const near=slot===s.spec.payment.slotId,approachEdge=near&&!s.nearPayment;s.nearPayment=near;if(near&&(s.spec.payment.trigger==='approach'?approachEdge:payEdge))pay(s.spec.payment.slotId,{tick,objects,taken:ids});}
  for(const s of states){const q=s.spec,primary=objects.find(o=>o.id===q.coinId);if(s.bombFlash>0)s.bombFlash--;
   for(const item of s.items){const body=bodyFor(item,objects);if(!body||ids.has(item.id))continue;if(item.kind==='bomb'&&item.motion&&!item.falling&&s.heldId!==item.id){const m=item.motion,span=m.maxX-m.minX,p=((m.phase??(item.home.x+item.home.w/2-m.minX))+item.motionAge++*m.speed)%(2*span),cx=m.minX+(p<=span?p:2*span-p);body.x=cx-body.w/2;body.y=m.y-body.h/2;}}
   if(primaryTaken(s,ids)||!primary){if(s.phase!=='collected'){s.phase='collected';s.heldId=null;s.closed=false;event('coin-collected',s,{tick});}continue;}
   if(s.phase==='collected')continue;
   const before=s.phase,oldY=s.y;
   if(s.phase==='scan'){const distance=s.x-q.minX+s.direction*q.speed,span=q.maxX-q.minX,period=2*span,p=((distance%period)+period)%period;s.x=q.minX+(p<=span?p:period-p);if(distance<0||distance>span)s.direction*=-1;}
   else if(s.phase==='lower'){const target=lowerTarget(s,objects,ids);s.y=move(s.y,target,q.dropSpeed);if(s.y===target){s.phase='close';s.age=0;}}
   else if(s.phase==='close'){s.closed=true;if(++s.age>=q.closeFrames){const candidates=s.items.filter(item=>!item.released&&!ids.has(item.id)).map(item=>({item,body:bodyFor(item,objects)})).filter(({item,body})=>body&&!body.dead&&Math.abs(body.x+body.w/2-s.x)<=q.captureHalfWidth&&(hitspanKind(item.kind)?s.y>=body.y&&s.y<=body.y+body.h:Math.abs(body.y+body.h/2-s.y)<=2)).sort((a,b)=>Math.abs(a.body.x+a.body.w/2-s.x)-Math.abs(b.body.x+b.body.w/2-s.x)||a.item.id.localeCompare(b.item.id));const target=candidates[0];
    if(target?.item.kind==='bomb'){s.bombFlash=24;s.failedKind='bomb';event('bomb-contact',s,{tick,payloadId:target.item.id,phase:'close'});s.phase='return';s.closed=false;emit('sound',{event:'bump'});}
    else{if(target){s.heldId=target.item.id;s.offsetX=target.body.x+target.body.w/2-s.x;s.offsetY=target.body.y+target.body.h/2-s.y;target.item.falling=false;holdNative(target.item,target.body);event('capture',s,{tick,payloadId:target.item.id,kind:target.item.kind,position:{x:target.body.x,y:target.body.y},grip:{x:s.x,y:s.y}});emit('sound',{event:'appear'});}else{event('miss',s,{tick,lockedX:s.x,coinCentre:{x:primary.x+primary.w/2,y:primary.y+primary.h/2}});emit('sound',{event:'bump'});}s.phase='raise';}
   }}
   else if(s.phase==='raise'){s.y=move(s.y,q.restY,q.liftSpeed);if(s.y===q.restY){const held=s.items.find(item=>item.id===s.heldId);s.phase=held?coinKind(held.kind)||liveKind(held.kind)?'transfer':'reject-lower':'return';}}
   else if(s.phase==='reject-lower'){s.y=move(s.y,q.grabY,q.dropSpeed);if(s.y===q.grabY){s.phase='reject-open';s.age=0;}}
   else if(s.phase==='reject-open'){s.closed=false;if(++s.age>=q.openFrames)dropInBin(s,tick,'wrong-prize');}
   else if(s.phase==='transfer'){s.x=move(s.x,q.deliveryX,q.speed);if(s.x===q.deliveryX){s.phase='deliver';event('delivery-arrival',s,{tick,payloadId:s.heldId});}}
   else if(s.phase==='deliver'){s.y=move(s.y,q.deliveryY,q.dropSpeed);if(s.y===q.deliveryY){s.phase='open';s.age=0;}}
   else if(s.phase==='open'){s.closed=false;if(++s.age>=q.openFrames){const item=s.items.find(item=>item.id===s.heldId),body=item&&bodyFor(item,objects);if(item){item.released=true;item.falling=true;item.vy=0;releaseNative(item,body);}s.heldId=null;s.released=true;s.phase='return';event('release',s,{tick,payloadId:item?.id,kind:item?.kind,position:body?{x:body.x,y:body.y}:null});emit('sound',{event:'appear'});}}
   else if(s.phase==='return'){s.y=move(s.y,q.restY,q.liftSpeed);if(s.y===q.restY)s.x=move(s.x,q.minX,q.speed);if(s.y===q.restY&&s.x===q.minX){s.closed=false;const pink=s.items[0];s.phase=pink.released?'delivered':'scan';s.direction=1;event(s.released?'cycle-complete':'retry-ready',s,{tick});}}
   if(['lower','raise'].includes(before)){const sweep={x:s.x-q.captureHalfWidth,y:Math.min(oldY,s.y)-3,w:q.captureHalfWidth*2,h:Math.abs(s.y-oldY)+6};const bomb=s.items.find(item=>item.kind==='bomb'&&bodyFor(item,objects)&&overlap(sweep,bodyFor(item,objects)));if(bomb){s.bombFlash=24;event('bomb-contact',s,{tick,payloadId:bomb.id,phase:before});dropInBin(s,tick,'bomb');emit('sound',{event:'bump'});}}
   if(s.heldId){const item=s.items.find(item=>item.id===s.heldId),body=item&&bodyFor(item,objects);if(!body||!shiftBody(s,body,s.x+s.offsetX-body.w/2,s.y+s.offsetY-body.h/2,geometry))dropInBin(s,tick,'blocked');}
   for(const item of s.items){const body=bodyFor(item,objects);if(!body||!item.falling||s.heldId===item.id)continue;item.vy=Math.min(MAX_FALL_SPEED,item.vy+GRAVITY);const bottom=body.y+body.h,next=body.y+item.vy,land=geometry.filter(g=>!g.hidden&&['solid','oneway'].includes(g.collision)&&body.x+body.w>g.x&&body.x<g.x+g.w&&bottom<=g.y+.001&&next+body.h>=g.y).sort((a,b)=>a.y-b.y)[0];if(land){body.y=land.y-body.h;item.vy=0;item.falling=false;}else{const cabinetBottom=!item.released&&q.cabinet?q.cabinet.y+q.cabinet.h:room.map.height;body.y=Math.min(cabinetBottom-body.h,next);if(body.y===cabinetBottom-body.h){item.vy=0;item.falling=false;}}}
  }return true;
 }
 function view(){return {coinCranes:states.map(s=>({...copy(s.spec),phase:s.phase,tick:lastTick,grip:{x:s.x,y:s.y},anchor:{x:s.x,y:s.spec.restY-32},direction:s.direction,closed:s.closed,heldId:s.heldId,released:s.released,cycle:s.cycles,buttonPressed:!['scan','collected','delivered'].includes(s.phase),...(s.spec.searchlight?{lampOn:s.lampOn}:{}),...(s.spec.payment?{wallet:bank.balance(),price:s.spec.payment.price,paid:credit(s)>0,needMoney:credit(s)<1&&bank.balance()<s.spec.payment.price,paymentFlash:s.paymentFlash}:{}),bombFlash:s.bombFlash,failedKind:s.failedKind,payloads:s.items.filter(item=>!currentTaken.has(item.id)).flatMap(item=>{const body=bodyFor(item)||(!currentObjects.length?item.home:null);return body&&!body.dead?[{id:item.id,kind:item.kind,body:{x:body.x,y:body.y,w:body.w,h:body.h},released:item.released,held:s.heldId===item.id,...(liveKind(item.kind)?{npcDisposition:npcDisposition(item.id)}:{})}]:[]})}))};}
 return Object.freeze({step,headHit,pay,reset,view,pause(value=true){paused=!!value;},ownsCoin:id=>states.some(s=>s.items.some(item=>item.id===id&&coinKind(item.kind))),ownsObject:id=>!!objectOwner(id),isInertPayload:id=>states.some(s=>s.items.some(item=>item.id===id&&!coinKind(item.kind)&&!liveKind(item.kind))),isCaptiveActor:actor=>{const state=npcDisposition(actor);return state!==null&&state!=='native';},npcDisposition,canCollectCoin:id=>{const s=objectOwner(id),item=s?.items.find(item=>item.id===id);return !item||coinKind(item.kind)&&item.released&&s.heldId!==id;}});
}
