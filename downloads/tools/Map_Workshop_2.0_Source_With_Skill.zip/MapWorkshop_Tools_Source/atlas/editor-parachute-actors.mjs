/** Opt-in parachutes for the observed ordinary Goomba and Super Mushroom.
 * Tuning uses native pixels per host tick and authored oscillator frames. The
 * measured SMB3 scene shows slow descent and sideways reversals; its original
 * spawn, phase, activation boundary and motion law have not been recovered.
 *
 * This controller sets incoming velocities BEFORE the host's single ordinary
 * collision pass. It never moves x/y, resolves support, awards a pickup, adds
 * armor, spawns a replacement actor, or changes enemy/player contact rules.
 * The host must honor advance:false and the returned gravity/maxFallSpeed
 * override. After a real support contact, landed() closes the same canopy once
 * and releases the same actor to its seeded ordinary horizontal velocity.
 *
 * decorateActor is a pure projection: store its result once when constructing
 * a live host actor. preStep then binds that instance; projected render copies
 * must not be stepped. view/decorateActor never bind or advance simulation.
 */
const copy=value=>structuredClone(value);
const fail=message=>{throw Error(message);};
const finite=(value,min,max)=>Number.isFinite(value)&&value>=min&&value<=max;
const integer=(value,min,max)=>Number.isSafeInteger(value)&&finite(value,min,max);
const unsafe=key=>['__proto__','constructor','prototype'].includes(key);
const plain=value=>value&&typeof value==='object'&&!Array.isArray(value)&&[Object.prototype,null].includes(Object.getPrototypeOf(value));
const safeId=value=>typeof value==='string'&&value.length>0&&value.length<=128&&!/[\u0000-\u001f\u007f]/.test(value)&&!unsafe(value);
const rect=value=>value&&['x','y','w','h'].every(key=>Number.isFinite(value[key]))&&value.w>0&&value.h>0;
const live=value=>value&&!value.dead&&!value.dying&&!value.removed&&!value.taken;
const nativeType=value=>typeof value==='string'?value.replace(/^(?:enemy-|marker-)/,'').toLowerCase():null;
const body=value=>({x:value.x,y:value.y,w:value.w,h:value.h});
function fields(value,allowed,label){
 if(!plain(value))fail('Invalid '+label);
 for(const key of Object.keys(value))if(unsafe(key)||!allowed.includes(key))fail('Unknown '+label+' field: '+key);
 for(const key of allowed)if(!Object.hasOwn(value,key))fail('Missing '+label+' field: '+key);
}
const list=value=>Array.isArray(value)?value:[];

/** Validate only the parachuteActors version-1 leaf. Its enclosing importer
 * remains responsible for sibling schemas and their ordinary item tuning. */
export function validateParachuteActors(room,spec=room?.smm2Mechanics?.parachuteActors){
 if(spec===undefined)return;
 fields(spec,['version','actors'],'parachute actors');
 if(spec.version!==1)fail('Unknown parachute actors version');
 const map=room?.map;
 if(!map||!finite(map.width,1,32768)||!finite(map.height,1,4096)||!Array.isArray(map.objects)||!Array.isArray(map.geometry))fail('Parachute actors need bounded native room geometry and objects');
 if(!Array.isArray(spec.actors)||spec.actors.length>256)fail('Invalid parachute actor list');
 const seen=new Set(),native=[...map.objects,...map.geometry,...list(room.markers)],mechanics=room.smm2Mechanics||{};
 const exclusive=[...list(mechanics.portableStones?.stones),...list(mechanics.localUpdrafts?.twisters),...['thwomps','shoes','boneShells','powBlocks','pSwitches','helmets','skewers'].flatMap(key=>list(mechanics[key]))];
 for(const q of spec.actors){
  fields(q,['id','variant','fallSpeed','oscillation','activation'],'parachute actor');
  if(!safeId(q.id)||seen.has(q.id))fail('Duplicate or invalid parachute actor ID');seen.add(q.id);
  if(!['goomba','super-mushroom'].includes(q.variant))fail('Parachute variant must be ordinary goomba or super-mushroom');
  const source=map.objects.find(actor=>actor.id===q.id);
  if(native.filter(actor=>actor.id===q.id).length!==1||source?.kind!=='walker'||!rect(source)||source.w!==16||source.h!==16||!finite(source.x,0,map.width-16)||!finite(source.y,0,map.height-16))fail('Parachute actor needs one native 16 by 16 walker inside the room');
  if(exclusive.some(actor=>actor.id===q.id))fail('Parachute actor cannot own another actor motion mechanic');
  if(!finite(q.fallSpeed,.001,64))fail('Invalid explicit parachute fall speed');
  fields(q.oscillation,['amplitude','periodFrames','phaseFrames'],'parachute oscillation');
  const oscillation=q.oscillation;
  if(!finite(oscillation.amplitude,0,256)||!integer(oscillation.periodFrames,4,36000)||!finite(oscillation.phaseFrames,0,oscillation.periodFrames)||oscillation.phaseFrames===oscillation.periodFrames)fail('Invalid explicit parachute oscillation');
  fields(q.activation,['kind'],'parachute activation');
  if(!['frame-in-view','room-entry'].includes(q.activation.kind))fail('Invalid explicit parachute activation');
  const items=list(mechanics.placedItems).filter(actor=>actor.id===q.id);
  if(q.variant==='super-mushroom'){
   if(items.length!==1||items[0].kind!=='mushroom'||items[0].rail!==undefined)fail('Parachute Super Mushroom needs one ordinary placedItems mushroom with the same ID');
  }else{
   if(items.length)fail('Parachute Goomba cannot also be a placed item');
   const type=room.enemySkins?.[q.id]??source.type;
   if(type!==undefined&&!['walker','goomba'].includes(nativeType(type)))fail('Parachute Goomba cannot change an existing native enemy variant');
   const variant=room.marioModules?.enemyVariants?.[q.id];
   if(variant!==undefined)fail('Parachute Goomba cannot also own an enemyVariants controller');
  }
 }
}

export function createParachuteActors(room){
 validateParachuteActors(room);
 const spec=room?.smm2Mechanics?.parachuteActors;if(spec===undefined)return null;
 const definitions=new Map(copy(spec.actors).map(q=>[q.id,q]));
 const records=new Map([...definitions].map(([id,q])=>[id,{id,variant:q.variant,actor:null,source:copy(room.map.objects.find(a=>a.id===id)),phase:'waiting',active:false,activationTick:null,lastTick:null,elapsedFrames:0,nativeVx:null,landingSupport:null}]));
 const ownsActor=actor=>definitions.has(typeof actor==='string'?actor:actor?.id);
 function state(record){return {version:1,variant:record.variant,phase:record.phase,open:record.phase!=='closed',active:record.active,activationTick:record.activationTick,elapsedFrames:record.elapsedFrames,landingSupport:record.landingSupport,tuningStatus:'explicit-author-configuration'};}
 function checkActor(actor){
  if(!rect(actor)||actor.w!==16||actor.h!==16||actor.vx!==undefined&&!finite(actor.vx,-256,256)||actor.vy!==undefined&&!finite(actor.vy,-256,256))fail('Invalid live parachute body or velocity');
  const q=definitions.get(actor.id);
  if(q.variant==='goomba'&&(actor.kind!=='walker'||!['walker','goomba'].includes(nativeType(actor.type??'walker'))))fail('Parachute Goomba needs its ordinary native enemy actor');
  if(q.variant==='super-mushroom'&&actor.kind!=='mushroom')fail('Parachute Super Mushroom needs its actual decorated placed item');
 }
 function decorateActor(actor){
  if(!ownsActor(actor))return actor;
  checkActor(actor);const record=records.get(actor.id);
  return {...actor,...(record.variant==='goomba'&&nativeType(actor.type??'walker')==='walker'?{type:'goomba'}:{}),parachuteActor:state(record)};
 }
 function recordFor(actor){
  checkActor(actor);const record=records.get(actor.id);
  if(record.actor&&record.actor!==actor)fail('Parachute live ID must have one actor instance');
  if(!record.actor){record.actor=actor;record.nativeVx=actor.vx??0;}
  return record;
 }
 function publish(record){record.actor.parachuteActor=state(record);}
 function result(record,{advance=false,waiting=false,activationHold=false}={}){
  const open=record.phase!=='closed';
  return {handled:true,active:record.active,advance,waiting,activationHold,open,motion:open?{gravity:0,maxFallSpeed:definitions.get(record.id).fallSpeed}:null};
 }
 /** One velocity preparation per tick; no displacement or gravity is added.
  * active is the host's actual frame-in-view test, never an inferred video
  * timeline. The activation tick holds the authored first visible pose. Once
  * activated, offscreen prehistory is not replayed and active stays sticky. */
 function preStep(actor,{tick,active}={}){
  if(!ownsActor(actor))return {handled:false,active:false,advance:false,waiting:false,activationHold:false,open:false,motion:null};
  if(!integer(tick,0,Number.MAX_SAFE_INTEGER)||typeof active!=='boolean')fail('Parachute preStep needs a nonnegative tick and explicit active boolean');
  const record=recordFor(actor),q=definitions.get(actor.id);
  if(record.lastTick!==null&&tick<=record.lastTick)return result(record,{waiting:record.phase==='waiting'});
  record.lastTick=tick;
  if(!live(actor))return result(record);
  if(record.phase==='closed')return result(record,{advance:true});
  if(!record.active){
   if(q.activation.kind==='frame-in-view'&&!active){actor.vx=actor.vy=0;publish(record);return result(record,{waiting:true});}
   record.active=true;record.activationTick=tick;record.phase='open';actor.vx=actor.vy=0;publish(record);
   return result(record,{activationHold:true});
  }
  const {amplitude,periodFrames,phaseFrames}=q.oscillation,omega=2*Math.PI/periodFrames;
  const previous=(phaseFrames+record.elapsedFrames%periodFrames)*omega,next=(phaseFrames+(record.elapsedFrames+1)%periodFrames)*omega;
  actor.vx=amplitude*(Math.sin(next)-Math.sin(previous));
  actor.vy=q.fallSpeed;record.elapsedFrames++;publish(record);
  return result(record,{advance:true});
 }
 /** Only an actual downward host support contact closes a canopy. Call before
  * a real Note/Spring module may launch the newly grounded ordinary actor. */
 function landed(actor,{support}={}){
  if(!ownsActor(actor))return {handled:false,changed:false,open:false};
  const record=recordFor(actor);
  if(!safeId(support))fail('Parachute landing needs an actual stable support ID');
  if(record.phase==='closed'||!record.active||!live(actor)||actor.grounded!==true||!Number.isFinite(actor.vy)||actor.vy<0||actor.support!==support)return {handled:true,changed:false,open:record.phase!=='closed'};
  record.phase='closed';record.landingSupport=support;actor.vx=record.nativeVx;publish(record);
  return {handled:true,changed:true,open:false};
 }
 /** Pure bounded projections, including unbound source poses for an editor. */
 function view(){return {version:1,approximation:true,actors:[...records.values()].map(record=>({id:record.id,variant:record.variant,body:body(record.actor??record.source),dead:record.actor?!live(record.actor):false,state:state(record),tuning:copy(definitions.get(record.id))}))};}
 return Object.freeze({ownsActor,decorateActor,preStep,landed,view});
}
