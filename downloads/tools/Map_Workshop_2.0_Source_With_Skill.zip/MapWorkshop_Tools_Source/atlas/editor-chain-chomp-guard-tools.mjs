/** Authoring for the explicitly original guard. Native body and tether record
 * are changed atomically; callers wrap these operations in their History. */
import {uid,validate} from './editor-model.mjs';
import {validateChainChompGuards,CHAIN_CHOMP_GUARD_DEFAULTS} from './editor-chain-chomp-guard.mjs';
const copy=structuredClone;
const id=()=>('guard-'+uid()).slice(0,96);
const clean=r=>{if(r.contraptions?.chainChompGuards&&!r.contraptions.chainChompGuards.length)delete r.contraptions.chainChompGuards;};
function edit(room,operation){const draft=copy(room),result=operation(draft);validateChainChompGuards(draft);validate({format:'xiaoq-map-project',version:1,id:'chain-chomp-authoring',title:'Original tethered guard',rooms:[draft]},{allowIncompleteCompletionMarks:true});for(const k of Object.keys(room))if(!Object.hasOwn(draft,k))delete room[k];Object.assign(room,draft);return result;}
function translate(q,dx,dy){q.post.x+=dx;q.post.y+=dy;q.post.anchorX+=dx;q.post.anchorY+=dy;q.rest.x+=dx;q.rest.y+=dy;}
export function addChainChompGuard(room,values={}){return edit(room,r=>{
 const floor=r.map.geometry.filter(g=>!g.hidden&&!g.motion&&['solid','oneway'].includes(g.collision)&&g.w>=64&&g.y>=48).sort((a,b)=>b.y-a.y)[0];
 if(!floor)throw Error('先放一块至少64像素宽的固定地面');
 const actorId=values.actorId||id(),postId=values.postId||id(),post=values.post||{x:Math.min(floor.x+72,floor.x+floor.w-48),y:floor.y-24,w:16,h:24,anchorX:Math.min(floor.x+80,floor.x+floor.w-40),anchorY:floor.y-16};
 const rest=values.rest||{x:post.x+32,y:post.y+8},q={actorId,postId,post:copy(post),rest:copy(rest),...copy(CHAIN_CHOMP_GUARD_DEFAULTS),...copy(values)};
 if(!r.map.objects.some(o=>o.id===actorId))r.map.objects.push({id:actorId,kind:'walker',x:q.rest.x-16,y:q.rest.y-16,w:32,h:32});
 r.contraptions??={version:1};r.contraptions.chainChompGuards??=[];r.contraptions.chainChompGuards.push(q);return actorId;
});}
export function updateChainChompGuard(room,actorId,values){return edit(room,r=>{
 const q=r.contraptions?.chainChompGuards?.find(q=>q.actorId===actorId);if(!q)throw Error('请选择已有的拴链大狗');
 if(Object.keys(values).some(k=>!['post','rest','leashLength','phase','motion'].includes(k)))throw Error('未知大狗作者参数');
 Object.assign(q,copy(values));const a=r.map.objects.find(o=>o.id===actorId);Object.assign(a,{x:q.rest.x-16,y:q.rest.y-16,w:32,h:32});
});}
export function moveChainChompGuard(room,actorId,{dx=0,dy=0}={}){return edit(room,r=>{
 if(!Number.isFinite(dx)||!Number.isFinite(dy))throw Error('大狗移动距离必须有限');const q=r.contraptions?.chainChompGuards?.find(q=>q.actorId===actorId);if(!q)throw Error('请选择已有的拴链大狗');translate(q,dx,dy);const a=r.map.objects.find(o=>o.id===actorId);a.x+=dx;a.y+=dy;
});}
export function cloneChainChompGuard(room,actorId,{dx=80,dy=0}={}){return edit(room,r=>{
 if(!Number.isFinite(dx)||!Number.isFinite(dy))throw Error('大狗复制距离必须有限');const q=copy(r.contraptions?.chainChompGuards?.find(q=>q.actorId===actorId));if(!q)throw Error('请选择已有的拴链大狗');
 q.actorId=id();q.postId=id();translate(q,dx,dy);const source=r.map.objects.find(o=>o.id===actorId);r.map.objects.push({...copy(source),id:q.actorId,x:q.rest.x-16,y:q.rest.y-16});r.contraptions.chainChompGuards.push(q);
 if(r.smm2Mechanics?.lighting){const lights=r.smm2Mechanics.lighting.sources;for(const light of copy(lights.filter(l=>l.targetId===actorId)))lights.push({...light,targetId:q.actorId});}return q.actorId;
});}
export function removeChainChompGuard(room,actorId,{removeBody=true}={}){return edit(room,r=>{
 r.contraptions.chainChompGuards=(r.contraptions?.chainChompGuards||[]).filter(q=>q.actorId!==actorId);if(removeBody){r.map.objects=r.map.objects.filter(o=>o.id!==actorId);if(r.enemySkins)delete r.enemySkins[actorId];if(r.smm2Mechanics?.lighting)r.smm2Mechanics.lighting.sources=r.smm2Mechanics.lighting.sources.filter(q=>q.targetId!==actorId);}clean(r);
});}
/** Preserve native actor clipboard identity. Host native paste supplies idMap
 * and translation; no extra bodies or shared mutable post records are created. */
export function captureChainChompGuardBindings(room,ids){if(!(ids instanceof Set))throw Error('Invalid selected guard IDs');return copy((room.contraptions?.chainChompGuards||[]).filter(q=>ids.has(q.actorId)));}
export function appendCopiedChainChompGuardBindings(room,snapshot,idMap,{dx=0,dy=0}={}){
 if(!snapshot?.length)return;if(!Array.isArray(snapshot)||!(idMap instanceof Map)||!Number.isFinite(dx)||!Number.isFinite(dy))throw Error('Invalid copied chain chomp bindings');
 room.contraptions??={version:1};room.contraptions.chainChompGuards??=[];
 for(const source of snapshot){const actorId=idMap.get(source.actorId);if(!actorId||actorId===source.actorId)throw Error('Copied guard needs a new native actor ID');const q=copy(source);q.actorId=actorId;q.postId=id();translate(q,dx,dy);room.contraptions.chainChompGuards.push(q);}validateChainChompGuards(room);
}
export function pruneChainChompGuardReferences(room,before){
 if(!room.contraptions?.chainChompGuards)return;const ids=new Set(room.map.objects.map(o=>o.id)),removed=new Set((before?.map.objects||[]).filter(o=>!ids.has(o.id)).map(o=>o.id));room.contraptions.chainChompGuards=room.contraptions.chainChompGuards.filter(q=>!removed.has(q.actorId));clean(room);
}
export function mountChainChompGuardTools({parent,room,change,report=()=>{}}){
 const panel=document.createElement('details');panel.id='chain-chomp-guard-tools';parent.append(panel);const node=(tag,text,body=panel)=>{const n=document.createElement(tag);n.textContent=text;body.append(n);return n;};node('summary','原创拴链大狗');node('p','先张嘴预警，再向一侧扑咬、收链。伤害只来自实际狗头接触；等收链后跳过。时长是本作作者参数。').className='small';let selected='';
 const attempt=fn=>{try{change(fn);refresh();}catch(e){report(e.message);refresh();}};
 const button=(text,fn)=>{const b=node('button',text);b.type='button';b.onclick=fn;return b;};button('+ 放置拴链大狗',()=>attempt(()=>{selected=addChainChompGuard(room());}));const select=node('select',''),form=node('form',''),inputs=new Map();select.onchange=()=>{selected=select.value;refresh();};button('复制狗头和木桩',()=>attempt(()=>{selected=cloneChainChompGuard(room(),selected);}));button('删除狗头和木桩',()=>attempt(()=>removeChainChompGuard(room(),selected)));
 const labels={'post.x':'木桩X','post.y':'木桩Y','rest.x':'休息狗头中心X','rest.y':'休息狗头中心Y',leashLength:'最大链长','phase.idleFrames':'休息帧','phase.windupFrames':'张嘴预警帧（≥24）','phase.lungeFrames':'扑咬帧','phase.retractFrames':'收链帧','phase.recoveryFrames':'恢复帧','motion.lungeHeight':'扑咬弧高','motion.windupRetreat':'预警后退距离','motion.retractHeight':'收链弧高'};
 form.onsubmit=e=>{e.preventDefault();attempt(()=>{const original=room().contraptions.chainChompGuards.find(q=>q.actorId===selected),q=copy(original);for(const [path,input]of inputs){if(String(input.value).trim()===''||!Number.isFinite(Number(input.value)))throw Error('作者参数须为有限数值');const keys=path.split('.');if(keys.length===2)q[keys[0]][keys[1]]=Number(input.value);else q[path]=Number(input.value);}q.post.anchorX=q.post.x+8;q.post.anchorY=q.post.y+8;const {actorId,postId,...values}=q;updateChainChompGuard(room(),selected,values);});};
 function refresh(){const rows=room().contraptions?.chainChompGuards||[];if(!rows.some(q=>q.actorId===selected))selected=rows[0]?.actorId||'';select.replaceChildren(...rows.map(q=>{const o=document.createElement('option');o.value=q.actorId;o.textContent=q.actorId;return o;}));select.value=selected;form.replaceChildren();inputs.clear();const q=rows.find(q=>q.actorId===selected);form.hidden=!q;if(!q)return;for(const [path,label]of Object.entries(labels)){const keys=path.split('.'),value=keys.length===2?q[keys[0]][keys[1]]:q[path],l=node('label',label,form),input=node('input','',l);input.type='number';input.step='any';input.value=value;input.setAttribute('data-chain-chomp-guard-control',path);inputs.set(path,input);}const apply=node('button','应用大狗参数',form);apply.type='submit';}
 refresh();return Object.freeze({refresh});
}
