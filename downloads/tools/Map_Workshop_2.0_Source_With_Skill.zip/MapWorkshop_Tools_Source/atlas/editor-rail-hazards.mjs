/** Opt-in rail Grinder motion for an existing square native hazard. The source
 * observation establishes rotation and travel along a closed rail. Distances,
 * speed, circular contact radius and rotation period remain explicit authored
 * fits; this is not recovered Nintendo collision or frame timing.
 *
 * The host owns player damage and every NPC, reward and velocity rule. Exclude
 * owned native hazards from the old static AABB contact pass, render poseFor(),
 * step once per host tick and call contact(player,beforePlayer) for harm only.
 * A rail is a motion guide, never player support or a damaging collider.
 */
import {validateRailClaws,compileRailPath,sampleRailPath} from './editor-rail-claws.mjs';
const EPS=1e-9,TAU=Math.PI*2,MAX_SWEEP_POINTS=8192;
const copy=value=>structuredClone(value);
const fail=message=>{throw Error(message);};
const finite=(value,min,max)=>Number.isFinite(value)&&value>=min&&value<=max;
const integer=(value,min,max)=>Number.isSafeInteger(value)&&finite(value,min,max);
const unsafe=key=>['__proto__','constructor','prototype'].includes(key);
const plain=value=>value&&typeof value==='object'&&!Array.isArray(value)&&[Object.prototype,null].includes(Object.getPrototypeOf(value));
const safeId=value=>typeof value==='string'&&value.length>0&&value.length<=128&&!/[\u0000-\u001f\u007f]/.test(value)&&!unsafe(value);
const rect=value=>value&&['x','y','w','h'].every(key=>Number.isFinite(value[key]))&&value.w>0&&value.h>0;
const live=value=>value&&!value.dead&&!value.dying&&!value.removed&&!value.taken;
const mod=(value,period)=>((value%period)+period)%period;
const lerp=(a,b,t)=>a+(b-a)*t;
const hazardFields=['id','trackId','speed','distance','direction','collisionRadius','rotationFrames','rotationDirection'];
function fields(value,allowed,label){
 if(!plain(value))fail('Invalid '+label);
 for(const key of Object.keys(value))if(unsafe(key)||!allowed.includes(key))fail('Unknown '+label+' field: '+key);
 for(const key of allowed)if(!Object.hasOwn(value,key))fail('Missing '+label+' field: '+key);
}
function inside(value,map){return rect(value)&&value.x>=0&&value.y>=0&&value.x+value.w<=map.width&&value.y+value.h<=map.height;}

function motionCycle(track){
 const loop=track.spec.mode==='loop',period=track.length*(loop?1:2),knots=new Set([0]);
 for(const segment of track.segments)for(const sample of segment.samples){
  const position=segment.offset+sample.distance;
  if(position<period)knots.add(position);
  if(!loop&&2*track.length-position<period)knots.add(2*track.length-position);
 }
 return {period,knots:[...knots].sort((a,b)=>a-b)};
}
/** Bound all possible per-tick path traversals before creating a controller.
 * This is a work-budget limit, not an inferred original speed limit. A dense
 * long path can still use a short local sweep without inspecting a whole lap. */
function sweepPointLimit(cycle,speed){
 if(!speed)return 2;
 const {period,knots}=cycle,n=knots.length,laps=Math.floor(speed/period),remainder=speed-laps*period;
 if(laps*n+2>MAX_SWEEP_POINTS)return laps*n+2;
 let end=0,maximum=0;
 const at=i=>knots[i%n]+(i>=n?period:0);
 for(let start=0;start<n;start++){
  if(end<start)end=start;
  while(end<start+n&&at(end)-at(start)<=remainder+EPS)end++;
  maximum=Math.max(maximum,end-start);
 }
 return laps*n+maximum+2;
}
function lowerBound(values,target){
 let low=0,high=values.length;
 while(low<high){const mid=(low+high)>>1;if(values[mid]<target)low=mid+1;else high=mid;}
 return low;
}

/** Besides the compiler's actual curve samples, check analytic quadratic
 * extrema. A control point may sit outside the visual margin while its curve
 * remains inside; a violation between lookup samples still must be rejected. */
function boundedPath(track,half,map){
 const points=[...track.points];
 for(const segment of track.segments)if(segment.kind==='quadratic')for(let axis=0;axis<2;axis++){
  const a=segment.start[axis],c=segment.control[axis],b=segment.to[axis],denominator=a-2*c+b;
  if(Math.abs(denominator)<EPS)continue;
  const t=(a-c)/denominator;if(t<=0||t>=1)continue;
  const u=1-t;points.push([0,1].map(k=>u*u*segment.start[k]+2*u*t*segment.control[k]+t*t*segment.to[k]));
 }
 return points.every(p=>p[0]>=half-EPS&&p[0]<=map.width-half+EPS&&p[1]>=half-EPS&&p[1]<=map.height-half+EPS);
}

/** Validate only railHazards version 1, without changing any authored data. */
export function validateRailHazards(room,spec=room?.smm2Mechanics?.railHazards){
 if(spec===undefined)return;
 fields(spec,['version','hazards'],'rail hazards');
 if(spec.version!==1)fail('Unknown rail hazards version');
 const map=room?.map;
 if(!map||!finite(map.width,1,32768)||!finite(map.height,1,4096)||!Array.isArray(map.objects)||!Array.isArray(map.geometry))fail('Rail hazards need bounded native room geometry and objects');
 if(!Array.isArray(spec.hazards)||spec.hazards.length>256)fail('Invalid rail hazard list');
 // Reuse track closure, segment and ID rules without validating sibling claws.
 validateRailClaws(room,{tracks:room.contraptions?.tracks});
 const tracks=new Map((room.contraptions?.tracks||[]).map(q=>[q.id,compileRailPath(q)])),cycles=new Map();
 const native=[...map.objects,...map.geometry,...(room.markers||[])],seen=new Set();
 for(const q of spec.hazards){
  fields(q,hazardFields,'rail hazard');
  if(!safeId(q.id)||seen.has(q.id))fail('Duplicate or invalid rail hazard ID');seen.add(q.id);
  const source=map.objects.find(actor=>actor.id===q.id);
  if(native.filter(actor=>actor.id===q.id).length!==1||source?.kind!=='hazard'||!inside(source,map)||source.w!==source.h)fail('Rail hazard needs one square native hazard inside the room');
  if(source.spikeTrap===true||room.contraptions?.spikeTraps?.some(p=>p.id===q.id))fail('A static Spike Trap cannot also own rail hazard motion');
  if(!safeId(q.trackId)||!tracks.has(q.trackId))fail('Rail hazard needs an existing same-room track');
  const track=tracks.get(q.trackId);
  if(!finite(q.speed,0,256)||!finite(q.distance,0,track.length)||![1,-1].includes(q.direction)||!finite(q.collisionRadius,.001,source.w/2)||!integer(q.rotationFrames,2,36000)||![1,-1].includes(q.rotationDirection))fail('Invalid explicit rail hazard motion, circular radius or rotation tuning');
  if(!cycles.has(q.trackId))cycles.set(q.trackId,motionCycle(track));
  if(sweepPointLimit(cycles.get(q.trackId),q.speed)>MAX_SWEEP_POINTS)fail('Invalid explicit rail hazard speed: path sweep exceeds the bounded work budget');
  if(!boundedPath(track,source.w/2,map))fail('Rail hazard visual bounds leave the room along its track curve');
 }
}

/** Minimum circle-to-AABB separation during one linear relative motion. The
 * point-to-box squared distance is a quadratic on intervals separated by real
 * face crossings. Minimize each interval rather than enlarging the entire box
 * by the radius, which would incorrectly make its outer corners damaging.
 * Linear changes in the native player dimensions are handled on the same
 * intervals, allowing before/after power transitions without a box fallback. */
function sweptCircle(centerBefore,centerAfter,radius,before,after){
 const x0=centerBefore.x-before.x,y0=centerBefore.y-before.y;
 const dx=centerAfter.x-after.x-x0,dy=centerAfter.y-after.y-y0;
 const dw=after.w-before.w,dh=after.h-before.h,breaks=[0,1];
 for(const [a,b]of [[x0,dx],[x0-before.w,dx-dw],[y0,dy],[y0-before.h,dy-dh]])if(Math.abs(b)>EPS){const t=-a/b;if(t>0&&t<1)breaks.push(t);}
 breaks.sort((a,b)=>a-b);
 const separation=t=>{
  const x=x0+dx*t,y=y0+dy*t,w=before.w+dw*t,h=before.h+dh*t;
  const ex=Math.max(0,-x,x-w),ey=Math.max(0,-y,y-h);return ex*ex+ey*ey;
 };
 const limit=radius*radius+EPS;
 for(let i=1;i<breaks.length;i++){
  const lo=breaks[i-1],hi=breaks[i],mid=(lo+hi)/2;
  if(separation(lo)<=limit||separation(hi)<=limit)return true;
  const x=x0+dx*mid,y=y0+dy*mid,w=before.w+dw*mid,h=before.h+dh*mid;
  const ax=x<0?x0:x>w?x0-before.w:0,bx=x<0?dx:x>w?dx-dw:0;
  const ay=y<0?y0:y>h?y0-before.h:0,by=y<0?dy:y>h?dy-dh:0;
  const denominator=bx*bx+by*by;
  if(denominator>0){const t=Math.max(lo,Math.min(hi,-(ax*bx+ay*by)/denominator));if(separation(t)<=limit)return true;}
 }
 return false;
}

export function createRailHazards(room,{emit=()=>{}}={}){
 validateRailHazards(room);
 const spec=room?.smm2Mechanics?.railHazards;if(!spec?.hazards.length)return null;
 const definitions=copy(spec.hazards),sources=new Map(definitions.map(q=>[q.id,copy(room.map.objects.find(o=>o.id===q.id))]));
 const ids=new Set(definitions.map(q=>q.trackId));
 const tracks=new Map(copy(room.contraptions.tracks).filter(q=>ids.has(q.id)).map(q=>[q.id,compileRailPath({...q,mode:q.mode??'bounce'})]));
 const cycles=new Map([...tracks].map(([id,track])=>[id,motionCycle(track)]));
 let states,frame,lastTick,currentTick;
 const diagnostic=(event,state,extra={})=>emit('rail-hazard',{event,roomId:room.roomId,tick:currentTick,frame,hazardId:state.spec.id,trackId:state.spec.trackId,...extra});
 function place(state){
  const source=sources.get(state.spec.id),sample=sampleRailPath(tracks.get(state.spec.trackId),state.distance,state.direction),center=sample.anchor;
  state.pose={id:state.spec.id,kind:'hazard',trackId:state.spec.trackId,x:center.x-source.w/2,y:center.y-source.h/2,w:source.w,h:source.h,center:{...center},collisionShape:'circle',collisionRadius:state.spec.collisionRadius,angleRadians:state.spec.rotationDirection*mod(frame,state.spec.rotationFrames)*TAU/state.spec.rotationFrames,rotationFrames:state.spec.rotationFrames,rotationDirection:state.spec.rotationDirection,distance:state.distance,direction:state.direction,tangent:{...sample.tangent},vx:state.previous?center.x-state.previous.center.x:0,vy:state.previous?center.y-state.previous.center.y:0};
 }
 function reset(){
  frame=0;lastTick=null;currentTick=0;
  states=definitions.map(spec=>{const state={spec,distance:spec.distance,direction:spec.direction,previous:null,pose:null,sweep:[]};place(state);state.previous=copy(state.pose);state.sweep=[{t:0,center:{...state.pose.center}},{t:1,center:{...state.pose.center}}];return state;});
 }
 reset();
 function trajectory(state,track){
  const loop=track.spec.mode==='loop',{period,knots}=cycles.get(state.spec.trackId);
  const start=loop?state.distance:state.direction===1?state.distance:2*track.length-state.distance,velocity=(loop?state.direction:1)*state.spec.speed,end=start+velocity;
  const points=[{t:0,center:{...state.previous.center}}];
  if(velocity){
   const min=Math.min(start,end),max=Math.max(start,end),first=Math.floor(min/period),last=Math.floor(max/period);
   for(let lap=first;lap<=last;lap++){
    const offset=lap*period;
    for(let i=lowerBound(knots,min-offset);i<knots.length&&knots[i]<=max-offset;i++){
     const phase=knots[i]+offset,t=(phase-start)/velocity;if(t<=0||t>=1)continue;
     const folded=mod(phase,period),distance=loop?folded:folded<=track.length?folded:2*track.length-folded;
     points.push({t,center:sampleRailPath(track,distance).anchor});
    }
   }
   points.sort((a,b)=>a.t-b.t);
  }
  return points;
 }
 function step({tick}={}){
  if(!integer(tick,0,Number.MAX_SAFE_INTEGER))fail('Rail hazard step needs an explicit nonnegative tick');
  if(lastTick!==null&&tick<=lastTick)return false;
  lastTick=tick;currentTick=tick;frame++;
  for(const state of states){
   state.previous=copy(state.pose);const track=tracks.get(state.spec.trackId),oldDirection=state.direction;
   state.sweep=trajectory(state,track);
   if(state.spec.speed){
    if(track.spec.mode==='loop'){
     const next=state.distance+state.direction*state.spec.speed;state.distance=mod(next,track.length);
     if(next<0||next>=track.length)diagnostic('track-loop',state,{direction:state.direction});
    }else{
     const phase=mod((state.direction===1?state.distance:2*track.length-state.distance)+state.spec.speed,2*track.length);
     state.distance=phase<=track.length?phase:2*track.length-phase;state.direction=phase<track.length?1:-1;
     if(state.direction!==oldDirection)diagnostic('track-reversal',state,{direction:state.direction});
    }
   }
   place(state);
   state.sweep.push({t:1,center:{...state.pose.center}});
   if(frame===1)diagnostic('motion-start',state,{center:{...state.pose.center},speed:state.spec.speed,collisionShape:'circle',tuningStatus:'explicit-author-configuration'});
  }
  return true;
 }
 function poseFor(id){const state=states.find(q=>q.spec.id===id);return state?copy(state.pose):null;}
 function contact(player,before){
  if(!rect(player)||!live(player))return false;
  if(before!==undefined&&!rect(before))fail('Rail hazard contact needs a native before-player AABB');
  const start=before??player;
  const playerAt=t=>Object.fromEntries(['x','y','w','h'].map(key=>[key,lerp(start[key],player[key],t)]));
  return states.some(state=>{
   for(let i=1;i<state.sweep.length;i++){
    const a=state.sweep[i-1],b=state.sweep[i];
    if(sweptCircle(a.center,b.center,state.spec.collisionRadius,playerAt(a.t),playerAt(b.t)))return true;
   }
   return false;
  });
 }
 function view(){return {version:1,approximation:true,tuningStatus:'explicit-author-configuration',tick:currentTick,frame,tracks:[...tracks.values()].map(q=>({...copy(q.spec),length:q.length,points:copy(q.points)})),hazards:states.map(state=>({...copy(state.spec),...copy(state.pose)}))};}
 return Object.freeze({step,poseFor,contact,view,reset});
}
