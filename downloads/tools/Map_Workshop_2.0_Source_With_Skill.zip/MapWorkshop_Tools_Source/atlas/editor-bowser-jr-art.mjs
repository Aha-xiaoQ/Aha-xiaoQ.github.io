import {bowserJrView,bowserJrVisibleFrame,bowserJrFireballVisibleFrame} from './editor-bowser-jr.mjs';
import {drawJrArenaAudience} from './editor-jr-arena-art.mjs';
export const BOWSER_JR_ART_STATUS='gameplay-frame-reconstruction-not-source-rip';
/** Original pixel grandstands, strictly scenery. The ordinary room renderer
 * calls this before live actors; no geometry/contact object is created here. */
export function drawBowserJuniorArenaBackdrop(c,room){
 if(drawJrArenaAudience(c,room))return;
 for(const d of room?.decorations||[]){
  if(d.smm2Art!=='jr-grandstand'||d.hidden||d.visible===false)continue;
  const x=d.x,y=d.y,w=d.w,h=d.h,facing=d.facing??1;
  c.save();c.translate(x,y);if(facing<0){c.translate(w,0);c.scale(-1,1);}
  c.fillStyle='#1c1527';c.fillRect(0,0,w,h);
  for(let row=0;row<4;row++){
   const yy=row*24+8,start=row*12;
   c.fillStyle=row%2?'#363146':'#40394f';c.fillRect(0,yy+17,w-start,7);
   c.fillStyle='#625270';c.fillRect(0,yy+17,w-start,2);
   for(let col=0;col<Math.floor((w-start-4)/16);col++){
    const xx=col*16+5,palette=['#e1a862','#98b6cf','#cc849d','#9bba78'];
    c.fillStyle=palette[(row+col)%palette.length];c.fillRect(xx+2,yy+4,6,6);c.fillRect(xx,yy+10,10,5);
    c.fillStyle='#ded4b9';c.fillRect(xx+1,yy+1,8,3);
    c.fillStyle='#211b28';c.fillRect(xx+6,yy+6,1,1);c.fillRect(xx+1,yy+15,3,2);c.fillRect(xx+6,yy+15,3,2);
   }
  }
  c.fillStyle='#8c7359';c.fillRect(0,h-4,w,4);c.restore();
 }
}
function pixels(c,im,x,y,w,h){
 const sx=w/im.w,sy=h/im.h;
 for(let row=0;row<im.h;row++)for(let col=0;col<im.w;){const index=parseInt(im.rows[row][col],36),start=col;while(col<im.w&&parseInt(im.rows[row][col],36)===index)col++;const color=im.palette[index];if(!index||!color||color==='transparent')continue;c.fillStyle=Array.isArray(color)?`rgba(${color[0]},${color[1]},${color[2]},${(color[3]??255)/255})`:color;c.fillRect(x+start*sx,y+row*sy,(col-start)*sx,sy);}
}
/** Actual editor sidecar, live body, native defeat effect and projectile all
 * share the controller's native-grid frame and placement. Pose changes animate
 * measured limbs/mouth/shell, without stretching artwork to the collision box.
 * Animation durations and collision dimensions remain author tuning. */
export function drawBowserJr(c,actor,tick=0,room={}){
 if(!actor)return false;
 if(actor.type==='bowser-jr-fireball'||actor.smm2EnemyKind==='bowser-jr-fireball'){
  if(!actor.dead&&!actor.hidden&&actor.life!==0){const visible=bowserJrFireballVisibleFrame(actor,tick);if(visible)pixels(c,visible.image,visible.x,visible.y,visible.w,visible.h);}return true;
 }
 const authored=room.smm2Mechanics?.bowserJuniors?.actors.find(q=>q.id===(actor.sourceId||actor.id)),v=bowserJrView(actor),defeat=actor.kind==='enemy-death'&&actor.smm2BowserJr;
 if(!v&&!authored)return false;if(actor.hidden||actor.removed||actor.visible===false||actor.dead&&!defeat||defeat&&actor.life<=0)return true;
 const visible=bowserJrVisibleFrame(actor,{phase:v?.phase||'normal',animationFrame:v?.animationFrame??0,facing:authored?.direction??-1}),im=visible.image,w=im.w,h=im.h,x=visible.x,y=visible.y,facing=visible.facing;
 c.save();if(facing>0){c.translate(x+w,0);c.scale(-1,1);}else c.translate(x,0);
 if(defeat){c.translate(0,2*y+h);c.scale(1,-1);}pixels(c,im,0,y,w,h);c.restore();return true;
}
