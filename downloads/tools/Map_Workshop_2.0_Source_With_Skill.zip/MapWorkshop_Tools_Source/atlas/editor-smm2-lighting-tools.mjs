import {clone,validate} from './editor-model.mjs';
import {validateSmm2LightingRoom,smm2LightingTargets,pruneSmm2LightingReferences} from './editor-smm2-lighting.mjs';
export {pruneSmm2LightingReferences} from './editor-smm2-lighting.mjs';
export const SMM2_LIGHTING_AUTHORING_DEFAULTS=Object.freeze({darkness:.94,playerRadius:56,softness:.25});
export const SMM2_SWEEPING_LAMP_AUTHORING_DEFAULTS=Object.freeze({length:184,halfAngle:10,minAngle:-28,maxAngle:28,periodFrames:240,phaseFrames:0,enabledWhenOn:false});
function edit(room,fn){const next=clone(room);fn(next);validate({format:'xiaoq-map-project',version:1,id:'night-lighting-check',title:'Night lighting authoring',rooms:[next]},{allowIncompleteCompletionMarks:true});for(const key of Object.keys(room))if(!Object.hasOwn(next,key))delete room[key];Object.assign(room,next);}
/** Supply a complete validated leaf. Missing lighting stays disabled. */
export function setSmm2Lighting(room,options){
 if(room.smm2Mechanics?.version!==1)throw Error('Lighting requires an existing SMM2 mechanics version 1 room');
 validateSmm2LightingRoom({...room,smm2Mechanics:{...room.smm2Mechanics,lighting:options}});
 if(options===undefined)throw Error('Supply a complete SMM2 lighting config');
 edit(room,r=>{r.smm2Mechanics.lighting=clone(options);});
}
export function clearSmm2Lighting(room){if(room.smm2Mechanics?.lighting===undefined)return;edit(room,r=>{delete r.smm2Mechanics.lighting;});}
/** Associate appearance with the existing real global ON/OFF component. */
export function setSmm2LightingOffRadiusScale(room,scale){
 if(!room.smm2Mechanics?.lighting)throw Error('Enable lighting before associating its OFF radius');
 setSmm2Lighting(room,{...room.smm2Mechanics.lighting,offRadiusScale:scale});
}
export function clearSmm2LightingOffRadiusScale(room){
 if(!Object.hasOwn(room.smm2Mechanics?.lighting||{},'offRadiusScale'))return;
 edit(room,r=>{delete r.smm2Mechanics.lighting.offRadiusScale;});
}
export function setSmm2ObjectLight(room,targetId,options){
 if(!options||typeof options!=='object'||Array.isArray(options)||![Object.prototype,null].includes(Object.getPrototypeOf(options))||Object.keys(options).some(k=>!['radius','offsetX','offsetY'].includes(k)))throw Error('Invalid SMM2 object light authoring options');
 if(!room.smm2Mechanics?.lighting)throw Error('Enable lighting before binding a light source');
 const spec={...room.smm2Mechanics.lighting,sources:[...room.smm2Mechanics.lighting.sources.filter(q=>q.targetId!==targetId),{targetId,...options}]};
 setSmm2Lighting(room,spec);
}
export function clearSmm2ObjectLight(room,targetId){edit(room,r=>{if(r.smm2Mechanics?.lighting)r.smm2Mechanics.lighting.sources=r.smm2Mechanics.lighting.sources.filter(q=>q.targetId!==targetId);});}
/** Independent world-space lamps have stable IDs, never actor references. */
export function setSmm2SweepingLamp(room,id,options){
 if(!room.smm2Mechanics?.lighting)throw Error('Enable lighting before adding a sweeping lamp');
 if(!options||typeof options!=='object'||Array.isArray(options)||![Object.prototype,null].includes(Object.getPrototypeOf(options))||Object.keys(options).some(k=>!['x','y','length','halfAngle','minAngle','maxAngle','periodFrames','phaseFrames','enabledWhenOn','enabledWhenMachine'].includes(k)))throw Error('Invalid SMM2 sweeping lamp authoring options');
 setSmm2Lighting(room,{...room.smm2Mechanics.lighting,sweepingLamps:[...(room.smm2Mechanics.lighting.sweepingLamps||[]).filter(q=>q.id!==id),{id,...clone(options)}]});
 return id;
}
export function clearSmm2SweepingLamp(room,id){
 if(!room.smm2Mechanics?.lighting?.sweepingLamps?.some(q=>q.id===id))return;
 edit(room,r=>{r.smm2Mechanics.lighting.sweepingLamps=r.smm2Mechanics.lighting.sweepingLamps.filter(q=>q.id!==id);if(!r.smm2Mechanics.lighting.sweepingLamps.length)delete r.smm2Mechanics.lighting.sweepingLamps;});
}
export function cloneSmm2SweepingLamp(room,id,{id:newId,dx=16,dy=0}={}){
 const source=room.smm2Mechanics?.lighting?.sweepingLamps?.find(q=>q.id===id);
 if(!source||!newId||newId===id||room.smm2Mechanics.lighting.sweepingLamps.some(q=>q.id===newId)||!Number.isFinite(dx)||!Number.isFinite(dy))throw Error('Sweeping lamp clone requires a source, unique ID and finite offsets');
 const {id:oldId,...options}=source;return setSmm2SweepingLamp(room,newId,{...options,x:options.x+dx,y:options.y+dy});
}
export function captureSmm2SweepingLamps(room,ids){return clone((room.smm2Mechanics?.lighting?.sweepingLamps||[]).filter(q=>ids.has(q.id)));}
/** Explicit lamp paste carries only selected world-space fixtures. Whole-room
 * copies naturally preserve all lamps; ordinary actor/terrain paste does not. */
export function appendCopiedSmm2SweepingLamps(room,snapshot,idMap,{dx=0,dy=0}={}){
 if(!Array.isArray(snapshot)||!snapshot.length)return;
 if(!room.smm2Mechanics?.lighting||!Number.isFinite(dx)||!Number.isFinite(dy))throw Error('Sweeping lamp paste requires enabled lighting and finite offsets');
 edit(room,r=>{for(const q of snapshot){const id=idMap.get(q.id);if(!id||r.smm2Mechanics.lighting.sweepingLamps?.some(lamp=>lamp.id===id))throw Error('Copied sweeping lamp needs a unique stable ID');(r.smm2Mechanics.lighting.sweepingLamps??=[]).push({...clone(q),id,x:q.x+dx,y:q.y+dy});}});
}
export function captureSmm2LightingBindings(room,ids){return{sources:clone((room.smm2Mechanics?.lighting?.sources||[]).filter(q=>ids.has(q.targetId)))};}
/** Body paste and bindings share the editor's existing History transaction.
 * A destination room must explicitly opt in before accepting copied lights. */
export function appendCopiedSmm2LightingBindings(room,snapshot,idMap){
 if(!snapshot?.sources?.length)return;
 if(!room.smm2Mechanics?.lighting)throw Error('Enable lighting in the destination before pasting light sources');
 edit(room,r=>{for(const q of snapshot.sources){const id=idMap.get(q.targetId);if(!id)throw Error('Copied light source is missing its stable target');if(!r.smm2Mechanics.lighting.sources.some(s=>s.targetId===id))r.smm2Mechanics.lighting.sources.push({...clone(q),targetId:id});}});
}
/** Native selection, validation and History; never edits collision or motor data. */
export function mountSmm2LightingTools({parent,room,selected=()=>new Set(),change,report=()=>{}}){
 const panel=document.createElement('details');parent.append(panel);panel.innerHTML='<summary>夜间圆光（作者近似）</summary><p class="small">默认关闭。Mario 与明确绑定的预放对象拥有圆光。半径、暗度与软边都是作者近似参数；夜间名称不改变重力或游泳。效果视图显示初始光源。</p><label><input type="checkbox" data-lighting="enabled"> 启用夜间照明</label><label>暗度（0–1）<input type="number" data-lighting="darkness" min="0" max="1" step="0.01"></label><label>Mario 光半径（8–512 像素）<input type="number" data-lighting="playerRadius" min="8" max="512" step="1"></label><label>圆光软边比例（0–1）<input type="number" data-lighting="softness" min="0" max="1" step="0.01"></label><label><input type="checkbox" data-lighting="offLinked"> 关联真实 ON/OFF：OFF 缩小所有圆光</label><label>OFF 光半径倍率（0.05–1，作者近似）<input type="number" data-lighting="offRadiusScale" min="0.05" max="1" step="0.01"></label><p class="small">需要本区域已有 ON/OFF version 1 组件。开关本身不产生光；效果预览只读初始 ON/OFF 状态。</p><button type="button" data-lighting="apply">应用照明参数</button><label>明确光源对象 / 地形 / 固定箭头<select data-lighting="target"></select></label><label>对象光半径（8–512 像素）<input type="number" data-lighting="radius" min="8" max="512" step="1"></label><label>光心偏移 X（固定箭头为相对锚点）<input type="number" data-lighting="offsetX" min="-512" max="512" step="1"></label><label>光心偏移 Y（固定箭头为相对锚点）<input type="number" data-lighting="offsetY" min="-512" max="512" step="1"></label><button type="button" data-lighting="bind">绑定 / 更新对象光源</button><button type="button" data-lighting="remove">移除所选对象光源</button><p class="small" data-lighting="status"></p>';
 const get=key=>panel.querySelector('[data-lighting="'+key+'"]'),number=key=>{if(String(get(key).value).trim()==='')throw Error('请填写照明参数 '+key);return Number(get(key).value);};
 const attempt=fn=>{try{change(fn);}catch(e){report(e.message);}refresh();};let lastRoom=null,lastSelection='';
 get('enabled').onchange=()=>attempt(()=>{if(get('enabled').checked)setSmm2Lighting(room(),room().smm2Mechanics?.lighting??{...SMM2_LIGHTING_AUTHORING_DEFAULTS,sources:[]});else clearSmm2Lighting(room());});
 get('offLinked').onchange=()=>attempt(()=>{if(get('offLinked').checked)setSmm2LightingOffRadiusScale(room(),number('offRadiusScale'));else clearSmm2LightingOffRadiusScale(room());});
 get('apply').onclick=()=>attempt(()=>{const spec={...clone(room().smm2Mechanics?.lighting||{}),darkness:number('darkness'),playerRadius:number('playerRadius'),softness:number('softness'),sources:clone(room().smm2Mechanics?.lighting?.sources||[])};if(get('offLinked').checked)spec.offRadiusScale=number('offRadiusScale');else delete spec.offRadiusScale;setSmm2Lighting(room(),spec);});
 get('bind').onclick=()=>attempt(()=>setSmm2ObjectLight(room(),get('target').value,{radius:number('radius'),offsetX:number('offsetX'),offsetY:number('offsetY')}));
 get('remove').onclick=()=>attempt(()=>clearSmm2ObjectLight(room(),get('target').value));get('target').onchange=()=>refreshSource();
 const lampPanel=document.createElement('details');panel.append(lampPanel);lampPanel.innerHTML='<summary>扫动探照灯（作者原创）</summary><p class="small">独立世界坐标，不绑定怪物或金币。角度从正下方顺时针计；正角朝左。周期只读游戏 tick，ON 联动只读真实全局开关。</p><label>已有灯<select data-lighting="lamp-select"></select></label><label>稳定 ID<input type="text" data-lighting="lamp-id"></label>'+[['x','灯心 X',0,16384,1],['y','灯心 Y',0,16384,1],['length','照射长度',8,1024,1],['halfAngle','半张角（度）',1,60,1],['minAngle','最小角（度）',-85,85,1],['maxAngle','最大角（度）',-85,85,1],['periodFrames','往返周期（tick）',2,36000,1],['phaseFrames','初始相位（tick）',0,35999,1]].map(([key,label,min,max,step])=>'<label>'+label+'<input type="number" data-lighting="lamp-'+key+'" min="'+min+'" max="'+max+'" step="'+step+'"></label>').join('')+'<label><input type="checkbox" data-lighting="lamp-enabledWhenOn"> 只在真实 ON 时照亮</label><label>独立机器开关（可空）<input type="text" data-lighting="lamp-machine"></label><button type="button" data-lighting="lamp-apply">添加 / 更新探照灯</button><button type="button" data-lighting="lamp-copy">复制所选灯（右移 16）</button><button type="button" data-lighting="lamp-remove">删除所选灯</button>';
 const lampKeys=['x','y','length','halfAngle','minAngle','maxAngle','periodFrames','phaseFrames'];
 get('lamp-select').onchange=()=>refreshLamp();
 get('lamp-apply').onclick=()=>attempt(()=>{const id=get('lamp-id').value.trim(),options=Object.fromEntries(lampKeys.map(key=>[key,number('lamp-'+key)]));options.enabledWhenOn=get('lamp-enabledWhenOn').checked;const machine=get('lamp-machine').value.trim();if(machine){options.enabledWhenMachine=machine;options.enabledWhenOn=false;}setSmm2SweepingLamp(room(),id,options);get('lamp-select').value=id;});
 get('lamp-remove').onclick=()=>attempt(()=>clearSmm2SweepingLamp(room(),get('lamp-select').value));
 get('lamp-copy').onclick=()=>attempt(()=>{const id=get('lamp-select').value,all=new Set((room().smm2Mechanics?.lighting?.sweepingLamps||[]).map(q=>q.id));let next=id+'-copy',index=2;while(all.has(next))next=id+'-copy-'+index++;cloneSmm2SweepingLamp(room(),id,{id:next});get('lamp-select').value=next;});
 function refreshLamp(){const r=room(),spec=r.smm2Mechanics?.lighting,list=spec?.sweepingLamps||[],old=get('lamp-select').value;get('lamp-select').replaceChildren(...[['','新探照灯'],...list.map(q=>[q.id,q.id])].map(([value,label])=>{const node=document.createElement('option');node.value=value;node.textContent=label;return node;}));get('lamp-select').value=list.some(q=>q.id===old)?old:'';const lamp=list.find(q=>q.id===get('lamp-select').value);get('lamp-id').value=lamp?.id??'sweep-lamp-'+(list.length+1);for(const key of lampKeys)get('lamp-'+key).value=String(lamp?.[key]??SMM2_SWEEPING_LAMP_AUTHORING_DEFAULTS[key]??(key==='x'?Math.round(r.map.width/2):Math.min(64,r.map.height)));get('lamp-machine').value=lamp?.enabledWhenMachine??'';get('lamp-enabledWhenOn').checked=lamp?.enabledWhenOn??false;get('lamp-enabledWhenOn').disabled=!spec||r.switchStudy?.version!==1;get('lamp-apply').disabled=!spec;get('lamp-copy').disabled=!lamp;get('lamp-remove').disabled=!lamp;}
 function refreshSource(){const target=get('target').value,s=room().smm2Mechanics?.lighting?.sources.find(q=>q.targetId===target);get('radius').value=String(s?.radius??56);get('offsetX').value=String(s?.offsetX??0);get('offsetY').value=String(s?.offsetY??0);get('remove').disabled=!s;get('bind').disabled=!room().smm2Mechanics?.lighting||!target;}
 function refresh(){const r=room(),spec=r.smm2Mechanics?.lighting,targets=smm2LightingTargets(r),selection=[...selected()].sort().join('|'),changed=lastRoom!==r.roomId||selection!==lastSelection;let pick=changed&&selected().size===1&&targets.some(q=>selected().has(q.id))?[...selected()][0]:lastRoom!==r.roomId?'':get('target').value;lastRoom=r.roomId;lastSelection=selection;get('enabled').checked=!!spec;get('enabled').disabled=r.smm2Mechanics?.version!==1;for(const key of ['darkness','playerRadius','softness'])get(key).value=String(spec?.[key]??SMM2_LIGHTING_AUTHORING_DEFAULTS[key]);get('offLinked').checked=Object.hasOwn(spec||{},'offRadiusScale');get('offLinked').disabled=!spec||r.switchStudy?.version!==1;get('offRadiusScale').value=String(spec?.offRadiusScale??.5);get('offRadiusScale').disabled=get('offLinked').disabled||!get('offLinked').checked;get('apply').disabled=!spec;get('target').replaceChildren(...targets.map(q=>{const node=document.createElement('option');node.value=q.id;node.textContent=q.id+' · '+(q.kind==='marker'?'固定箭头':q.kind==='geometry'?'地形':'对象');return node;}));get('target').value=targets.some(q=>q.id===pick)?pick:targets[0]?.id||'';get('status').textContent=spec?'已绑定 '+spec.sources.length+' 个对象光源；Mario 光源由实际玩家位置读取'+(get('offLinked').checked?'；OFF 倍率读取实时全局开关状态':r.switchStudy?.version!==1?'；关联 OFF 需已有 ON/OFF version 1 组件':''):get('enabled').disabled?'请先应用 SMM2 图像风格或设置机关，再启用照明':'照明关闭';refreshSource();}
 const refreshRoom=refresh;function refreshAll(){refreshRoom();refreshLamp();}refresh=refreshAll;
 refresh();return{refresh};
}
