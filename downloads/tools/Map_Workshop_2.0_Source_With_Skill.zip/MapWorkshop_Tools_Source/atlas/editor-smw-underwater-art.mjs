/** Pure optional SMW Underwater presentation.
 * Original PNG cells, explicit video reconstructions and their provenance live
 * in editor-smw-underwater-source-pixels.mjs. No controller or Stage writes.
 * Every sprite uses its visual raster/alpha, independently of its collision body.
 */
import {SMW_UNDERWATER_SOURCE_PIXELS as A} from './editor-smw-underwater-source-pixels.mjs';
import {SMW_PLAYER_MOTION_PIXELS as M} from './editor-smw-player-motion-pixels.mjs';
import {SMW_DIRECTION_ARROW_PIXELS as D} from './editor-smw-direction-arrow-pixels.mjs';
export {SMW_UNDERWATER_ART_PROVENANCE} from './editor-smw-underwater-source-pixels.mjs';
export {SMW_PLAYER_MOTION_PROVENANCE} from './editor-smw-player-motion-pixels.mjs';
export const isSmwUnderwaterRoom=r=>r?.smm2Mechanics?.art?.palette==='smw-underwater-source';
const visible=q=>!!q&&!q.hidden&&!q.dead&&!q.removed&&!q.taken&&q.visible!==false&&q.smm2SnakeBlock?.phase!=='removed';
const rect=q=>q&&['x','y','w','h'].every(k=>Number.isFinite(q[k]))&&q.w>0&&q.h>0;
const css=v=>`rgba(${v[0]},${v[1]},${v[2]},${v[3]/255})`;
const rasterCaches=new WeakMap();
const variantCaches=new WeakMap();
function raster(c,a,shade=1){
 const factory=c.canvas?.constructor;if(typeof factory!=='function')return null;
 let cache=rasterCaches.get(factory);if(!cache){cache=new WeakMap();rasterCaches.set(factory,cache);}
 let variants=cache.get(a);if(!variants){variants=new Map();cache.set(a,variants);}if(variants.has(shade))return variants.get(shade);
 let canvas;try{canvas=typeof OffscreenCanvas==='function'?new OffscreenCanvas(a.width,a.height):typeof document!=='undefined'?Object.assign(document.createElement('canvas'),{width:a.width,height:a.height}):new factory(a.width,a.height);}catch{return null;}
 const context=canvas.getContext('2d');if(!context)return null;paintRows(context,a,0,0,1,shade);variants.set(shade,canvas);return canvas;
}
function paintRows(c,a,x,y,scale=1,shade=1){
 const colors=Object.fromEntries(Object.entries(a.palette).map(([k,v])=>[k,css([Math.round(v[0]*shade),Math.round(v[1]*shade),Math.round(v[2]*shade),v[3]])]));
 for(let yy=0;yy<a.height;yy++){const row=a.rows[yy];for(let xx=0;xx<a.width;){const k=row[xx];let end=xx+1;while(end<a.width&&row[end]===k)end++;if(a.palette[k]?.[3]){c.fillStyle=colors[k];c.fillRect(x+xx*scale,y+yy*scale,(end-xx)*scale,scale);}xx=end;}}
}
/** Native source crop, with nearest-neighbor uniform scale. Dimensions never
 * come from an actor's body. Context changes are restored before returning. */
export function drawSmwUnderwaterPixels(c,a,{x,y,scale=1,mirror=false,shade=1,sourceX=0,sourceY=0,sourceWidth=a?.width,sourceHeight=a?.height}={}){
 if(!c||!a||![x,y,scale,shade,sourceX,sourceY,sourceWidth,sourceHeight].every(Number.isFinite)||scale<=0||shade<0||shade>1||sourceWidth<=0||sourceHeight<=0)return false;
 c.save();c.imageSmoothingEnabled=false;c.translate(Math.round(x)+(mirror?sourceWidth*scale:0),Math.round(y));if(mirror)c.scale(-1,1);
 const im=raster(c,a,shade);if(im)c.drawImage(im,sourceX,sourceY,sourceWidth,sourceHeight,0,0,sourceWidth*scale,sourceHeight*scale);
 else{c.beginPath();c.rect(0,0,sourceWidth*scale,sourceHeight*scale);c.clip();paintRows(c,a,-sourceX*scale,-sourceY*scale,scale,shade);}
 c.restore();return true;
}
export function smwUnderwaterSpriteRect(q,a,{scale=1}={}){if(!rect(q)||!a||!Number.isFinite(scale)||scale<=0)return null;return{x:Math.round(q.x+(q.w-a.width*scale)/2),y:Math.round(q.y+q.h-a.height*scale),w:a.width*scale,h:a.height*scale,scale};}
function anchored(c,q,a,{scale=1,mirror=false,shade=1}={}){const p=smwUnderwaterSpriteRect(q,a,{scale});return p&&drawSmwUnderwaterPixels(c,a,{...p,mirror,shade});}
function sourceFor(q,room){return room?.map?.geometry?.find(g=>g.id===(q.sourceId||q.id))??room?.map?.objects?.find(g=>g.id===(q.sourceId||q.id))??room?.decorations?.find(g=>g.id===(q.sourceId||q.id))??q;}
function artFor(q,room){return q.smm2Art??sourceFor(q,room).smm2Art;}
function isGround(q,room){const s=sourceFor(q,room);return artFor(q,room)==='smw-underwater-ground'||!q.smm2SnakeBlock&&!s.smm2BlockKind&&['ground','dirt'].includes(q.material??s.material);}
function clip(c,q,fn){c.save();c.beginPath();c.rect(q.x,q.y,q.w,q.h);c.clip();fn();c.restore();}
function tileCrop(c,a,x,y,sx,sy,w=16,h=16,shade=1){return drawSmwUnderwaterPixels(c,a,{x,y,sourceX:sx,sourceY:sy,sourceWidth:w,sourceHeight:h,shade});}
function repeat(c,q,a,{sx=0,sy=0,w=a.width,h=a.height,shade=1}={}){clip(c,q,()=>{for(let y=q.y;y<q.y+q.h;y+=h)for(let x=q.x;x<q.x+q.w;x+=w)tileCrop(c,a,x,y,sx,sy,w,h,shade);});}
/** Eight-neighbor quadrants come from the original assembled SMM2 ground.
 * Adjacent authored rectangles join; absent diagonal cells retain concave edges.
 * Unseen combinations mix original quadrants, explicitly a topology adaptation. */
export function drawSmwUnderwaterGround(c,q,room={}){
 if(!rect(q))return false;const origin=room.smm2Mechanics?.art??{},ox=origin.tileOriginX??0,oy=origin.tileOriginY??0;
 const sources=[q,...(room.map?.geometry??[]).filter(g=>g.id!==(q.sourceId||q.id)&&visible(g)&&isGround(g,room))];
 const solid=(x,y)=>sources.some(g=>x>=g.x&&x<g.x+g.w&&y>=g.y&&y<g.y+g.h);
 const top=[3,4],bottom=[2,7],left=[0,6],right=[7,5];
 const outer=[[5,0],[6,0],[0,7],[6,7]],inner=[[5,1],[2,4],[5,1],[2,1]];
 clip(c,q,()=>{for(let y=Math.floor((q.y-oy)/16)*16+oy;y<q.y+q.h;y+=16)for(let x=Math.floor((q.x-ox)/16)*16+ox;x<q.x+q.w;x+=16){
  for(let n=0;n<4;n++){const east=n%2===1,south=n>=2,dx=east?1:-1,dy=south?1:-1,vertical=solid(x+8,y+8+dy*16),horizontal=solid(x+8+dx*16,y+8),diagonal=solid(x+8+dx*16,y+8+dy*16);
   let source=!vertical&&!horizontal?outer[n]:!vertical?(south?bottom:top):!horizontal?(east?right:left):!diagonal?inner[n]:[2+((Math.floor((x-ox)/16)+Math.floor((y-oy)/16)*2)&3),5];
   tileCrop(c,A.ground,x+(east?8:0),y+(south?8:0),source[0]*16+(east?8:0),source[1]*16+(south?8:0),8,8);
  }
 }});return true;
}
/** Only the cap is collision geometry. stemHeight has the existing editor
 * meaning: height BELOW q.h. Columns/holes retain their original transparency. */
export function drawSmwUnderwaterSemisolid(c,q,room={},style='column'){
 if(!rect(q))return false;const source=sourceFor(q,room),stem=q.stemHeight??source.stemHeight??0,total=Math.max(q.h,q.h+stem),a=style==='masonry'?A.masonrySemisolid:A.columnSemisolid;
 const region={x:q.x,y:q.y,w:q.w,h:total};clip(c,region,()=>{
  for(let x=q.x;x<q.x+q.w;x+=16){const sx=((Math.round(x-q.x)/16)%4)*16;tileCrop(c,a,x,q.y,sx,0,16,8);
   if(style==='column'){
    if(total>8)tileCrop(c,a,x,q.y+8,sx,8,16,Math.min(8,total-8));
    const foot=Math.min(16,Math.max(0,total-16)),middle=Math.max(0,total-16-foot);
    // Preserve all original highlight/column/base rows at the native height.
    // Longer author stems repeat only the unobstructed 32-row middle section.
    for(let offset=0;offset<middle;offset+=32)tileCrop(c,a,x,q.y+16+offset,sx,16,16,Math.min(32,middle-offset));
    if(foot)tileCrop(c,a,x,q.y+total-foot,sx,64-foot,16,foot);
   }else for(let y=q.y+8;y<q.y+total;y+=56)tileCrop(c,a,x,y,sx,8,16,56);
  }
 });return true;
}
function drawPipe(c,q,room){
 const s=sourceFor(q,room),direction=q.direction??s.direction??q.source?.direction??s.source?.direction??'up';
 c.save();let width=q.w,length=q.h;
 if(direction==='down'){c.translate(q.x+q.w,q.y+q.h);c.rotate(Math.PI);}else if(direction==='left'){width=q.h;length=q.w;c.translate(q.x,q.y+q.h);c.rotate(-Math.PI/2);}else if(direction==='right'){width=q.h;length=q.w;c.translate(q.x+q.w,q.y);c.rotate(Math.PI/2);}else c.translate(q.x,q.y);
 const scale=width/32;if(!Number.isFinite(scale)||scale<=0){c.restore();return false;}c.beginPath();c.rect(0,0,width,length);c.clip();
 drawSmwUnderwaterPixels(c,A.pipeBlue,{x:0,y:0,scale,sourceHeight:16});
 for(let y=16*scale;y<length;y+=16*scale)drawSmwUnderwaterPixels(c,A.pipeBlue,{x:0,y,scale,sourceY:16,sourceHeight:16});
 c.restore();return true;
}
/** Formal Snake cells use the existing source-backed SMW material family.
 * Cross-style use is an explicit artwork adaptation; it changes no controller,
 * room palette, player sprite, camera, collisions or motion timing. */
export function drawSmm2SnakeBlockTile(c,q){
 if(!q?.smm2SnakeBlock||!['green','blue'].includes(q.smm2SnakeBlock.color)||!rect(q))return false;
 if(!visible(q))return true;
 return !!anchored(c,q,q.smm2SnakeBlock.color==='blue'?A.snakeBlue:A.snakeGreen,{shade:q.smm2SnakeBlock.darkened ? .43 : 1});
}
export function drawSmwUnderwaterTile(c,q,room={}){
 if(!isSmwUnderwaterRoom(room))return false;if(!visible(q))return !!q;if(!rect(q))return false;
 const s=sourceFor(q,room),tag=artFor(q,room),material=q.material??s.material;
 if(drawSmm2SnakeBlockTile(c,q))return true;
 if(tag==='smw-underwater-column-semisolid')return drawSmwUnderwaterSemisolid(c,q,room,'column');
 if(tag==='smw-underwater-masonry-semisolid')return drawSmwUnderwaterSemisolid(c,q,room,'masonry');
 if(tag==='smw-underwater-hard-block'||q.smm2BlockKind==='hard-block'||s.smm2BlockKind==='hard-block'||['hard-block','rock'].includes(material)){repeat(c,q,A.hardBlock);return true;}
 if(tag==='smw-underwater-ice'||material==='ice'){repeat(c,q,A.iceObserved);return true;}
 if(tag==='smw-underwater-blue-pipe'||material==='pipe')return drawPipe(c,q,room);
 if(material==='cannon'){
  clip(c,q,()=>{const scale=q.w/16;drawSmwUnderwaterPixels(c,A.cannonObserved,{x:q.x,y:q.y,scale});for(let y=q.y+32*scale;y<q.y+q.h;y+=8*scale)drawSmwUnderwaterPixels(c,A.cannonObserved,{x:q.x,y,scale,sourceY:6,sourceHeight:8});});return true;
 }
 if(isGround(q,room))return drawSmwUnderwaterGround(c,q,room);
 return false;
}
function variant(a,name,fn){let map=variantCaches.get(a);if(!map){map=new Map();variantCaches.set(a,map);}if(!map.has(name))map.set(name,fn());return map.get(name);}
function redEyeFish(){return variant(A.fishBone,'red-eye',()=>{const rows=[...A.fishBone.rows],palette={...A.fishBone.palette,R:[248,32,56,255]};for(let y=4;y<=6;y++){const row=rows[y].split('');for(let x=5;x<=6;x++)row[x]='R';rows[y]=row.join('');}return{...A.fishBone,rows,palette,sourceKind:'Original public Fish Bone body with a finite source-observed red-eye patch; adaptation.'};});}
function quarterTurn(a,quarter){quarter=((quarter%4)+4)%4;if(!quarter)return a;return variant(a,'quarter-'+quarter,()=>{const width=quarter%2?a.height:a.width,height=quarter%2?a.width:a.height,rows=[];for(let y=0;y<height;y++){let row='';for(let x=0;x<width;x++){const sx=quarter===1?y:quarter===2?a.width-1-x:a.width-1-y,sy=quarter===1?a.height-1-x:quarter===2?a.height-1-y:x;row+=a.rows[sy][sx];}rows.push(row);}return{...a,width,height,rows,sourceKind:'Original PNG rigid quarter rotation; source-supported shape adaptation, not original animation frame.'};});}
function actorDescriptor(q,room){
 if(q.underwaterActor)return q.underwaterActor;if(q.state?.kind&&q.body)return q.state;
 const live=room.underwaterActorsView?.actors?.find(a=>a.id===q.id);if(live?.state)return live.state;
 return room.smm2Mechanics?.underwaterActors?.profiles?.find(a=>a.id!==undefined&&a.id===q.id||a.sourceId!==undefined&&a.sourceId===q.moduleSource)??{};
}
// Native aquatic FishSources own the type, palette flags and moving body.
// The static source pose is presentation only; it has no renderer motion clock.
function isRedCheep(q,kind){
 const nativeType=q.type??kind;
 return /^(enemy-|marker-)?(fish|cheep|cheep-?cheep|red-cheep-?cheep|cheep-?cheep-red)$/i.test(nativeType??'')
  &&(q.palette==='red'||q.source?.palette==='red'||q.source?.aquaticVariant==='red'||q.source?.red===true||q.red===true||/^red-|[-]red$/.test(nativeType));
}
function drawFish(c,q,state){
 const a=state.eye==='red'?redEyeFish():A.fishBone,p=smwUnderwaterSpriteRect(q,a);if(!p)return false;
 const heading=state.aim,explicit=state.headingRadians??q.headingRadians,mirror=heading?heading.x>0:(q.vx??0)>0;
 let angle=Number.isFinite(explicit)?explicit:heading&&['charge','alert'].includes(state.phase)?mirror?Math.atan2(heading.y,Math.abs(heading.x)):Math.atan2(-heading.y,-heading.x):0;
 if(!Number.isFinite(angle))angle=0;
 c.save();c.translate(p.x+a.width/2,p.y+a.height/2);c.rotate(angle);if(mirror)c.scale(-1,1);c.translate(-a.width/2,-a.height/2);
 if(state.winged!==false&&q.source?.winged!==false){const wingFrame=state.wingFrame??q.wingFrame??((state.elapsedFrames??0)%15<8?0:1),wing=Number(wingFrame)%2?A.wingFoldedAdapted:A.wing;drawSmwUnderwaterPixels(c,wing,{x:13,y:-11});drawSmwUnderwaterPixels(c,wing,{x:17,y:3,mirror:true});}
 drawSmwUnderwaterPixels(c,a,{x:0,y:0});c.restore();return true;
}
/** Shaft/base rectangles and direction are read verbatim from the controller.
 * Original down-facing PNG motifs are cropped/repeated on that real extension;
 * variable length/cross-size and alternate directions are geometry adaptations. */
export function drawSmwUnderwaterSkewer(c,q){
 const s=q.smm2Skewer??q,base=s.base,shaft=s.shaft,direction=s.direction;if(!rect(base)||!['down','up','left','right'].includes(direction))return false;
 const horizontal=['left','right'].includes(direction),cross=horizontal?base.h:base.w,depth=horizontal?base.w:base.h,scale=cross/64,extension=rect(shaft)?horizontal?shaft.w:shaft.h:0;
 c.save();if(direction==='down')c.translate(base.x,base.y+base.h);else if(direction==='up'){c.translate(base.x+base.w,base.y);c.rotate(Math.PI);}else if(direction==='right'){c.translate(base.x+base.w,base.y+base.h);c.rotate(-Math.PI/2);}else{c.translate(base.x,base.y);c.rotate(Math.PI/2);}
 clip(c,{x:0,y:-depth,w:cross,h:depth},()=>{for(let y=-depth;y<0;y+=16*scale)drawSmwUnderwaterPixels(c,A.skewer,{x:0,y,scale,sourceHeight:16});});
 if(extension>0)clip(c,{x:0,y:0,w:cross,h:extension},()=>{const tip=Math.min(extension,16*scale);for(let y=0;y<extension-tip;y+=32*scale)drawSmwUnderwaterPixels(c,A.skewer,{x:0,y,scale,sourceY:16,sourceHeight:32});drawSmwUnderwaterPixels(c,A.skewer,{x:0,y:extension-16*scale,scale,sourceY:48,sourceHeight:16});});
 c.restore();return true;
}

/** The original pole has an exact eight-row stripe period. The fixed bar in
 * the public full-gate PNG covered ten pole rows; those visible stripe cells
 * are reconstructed from the unobstructed identical phase sixteen rows above. */
function goalPost(side){return variant(A.goalGate,'pole-'+side,()=>{const sx=side==='left'?0:32,rows=A.goalGate.rows.map((row,y)=>A.goalGate.rows[y>=65&&y<=74?y-16:y].slice(sx,sx+16));return{...A.goalGate,width:16,rows,sourceKind:'Original public SMW pole with its covered fixed-bar strip restored from the exact eight-row stripe period; finite reconstruction.'};});}
function drawGoalPost(c,q,side){const a=goalPost(side),scale=q.w/16;clip(c,q,()=>{drawSmwUnderwaterPixels(c,a,{x:q.x,y:q.y,scale});for(let y=q.y+a.height*scale;y<q.y+q.h;y+=8*scale)drawSmwUnderwaterPixels(c,a,{x:q.x,y,scale,sourceY:16,sourceHeight:8});});}
/** Dynamic gate uses the actual owner projection, never a renderer timer. */
export function drawSmwUnderwaterGoalGate(c,q,room={}){
 if(!isSmwUnderwaterRoom(room)||!visible(q))return false;
 const authored=room.smm2Mechanics?.goalTape,view=q.goalTape??room.goalTapeView??room.smwGoalTapeView;
 const posts=view?.posts??q.posts??authored?.posts??(rect(q)?{left:{x:q.x,y:q.y,w:16,h:q.h},right:{x:q.x+32,y:q.y,w:16,h:q.h}}:null);
 if(!posts||!rect(posts.left)||!rect(posts.right))return false;
 drawGoalPost(c,posts.left,'left');drawGoalPost(c,posts.right,'right');
 const tape=view?.tape??view??q.tape??(authored?{x:authored.tape.x,y:authored.tape.minY-authored.tape.h/2,w:authored.tape.w,h:authored.tape.h}:null);
 if(rect(tape)&&!view?.spent){const h=8,y=tape.y+tape.h/2-h/2,x=tape.x;c.save();c.beginPath();c.rect(x,y,tape.w,h);c.clip();
  // Left rounded tip and repeated original white/shaded interior. The physical
  // tape height remains controller-owned and need not equal its eight-pixel art.
  drawSmwUnderwaterPixels(c,A.goalGate,{x,y,sourceX:8,sourceY:66,sourceWidth:4,sourceHeight:8});
  for(let px=x+4;px<x+tape.w;px++)drawSmwUnderwaterPixels(c,A.goalGate,{x:px,y,sourceX:20,sourceY:66,sourceWidth:1,sourceHeight:8});c.restore();
 }
 return true;
}

function doorDescriptor(q,room){return room.contraptions?.doors?.find(d=>d.id===q.id)??room.contraptionsView?.doors?.find(d=>d.id===q.id);}
export function drawSmwUnderwaterObject(c,actor,room={}){
 if(!isSmwUnderwaterRoom(room))return false;if(!visible(actor))return !!actor;
 const q=actor.body?{...actor,...actor.body}:actor;if(!rect(q))return false;
 const state=actorDescriptor(q,room),kind=state.kind??q.type??q.skin??q.kind,tag=artFor(q,room)??q.source?.smm2Art;
 if(q.kind==='fish-bone-break'){
  if(q.life<=0)return true;const wing=q.fragment==='wing',a=wing?A.wing:A.fishBone,w=wing?6:4,h=wing?6:4,sx=wing?4:12,sy=wing?5:8;
  c.save();c.translate(Math.round(q.x+q.w/2),Math.round(q.y+q.h/2));c.rotate(Math.floor((q.age??0)/5)*Math.PI/2);drawSmwUnderwaterPixels(c,a,{x:-w/2,y:-h/2,sourceX:sx,sourceY:sy,sourceWidth:w,sourceHeight:h});c.restore();return true;
 }
 if(q.kind==='cannon-muzzle-flash'){
  if(q.life<=0)return true;c.save();c.translate(Math.round(q.x),Math.round(q.y));const colors=['#fff8b8','#ffd838','#fff'];for(let y=0;y<8;y++)for(let x=0;x<8;x++){const distance=Math.abs(x-3.5)+Math.abs(y-3.5);if(distance<=5&&(x===3||x===4||y===3||y===4||distance<=3)){c.fillStyle=colors[distance<2?2:distance<4?0:1];c.fillRect(x,y,1,1);}}c.restore();return true;
 }
 if(isRedCheep(q,kind)&&!['fish-bone','fishbone','galoomba'].includes(state.kind)){anchored(c,q,A.cheepRed,{mirror:(q.facing??q.vx??-1)>0});return true;}
 if(kind==='fish-bone'||kind==='fishbone')return drawFish(c,q,state);
 if(kind==='galoomba'){const scale=state.size==='giant'||q.source?.giant?2:1,angle=state.rollAngleRadians??q.rollAngleRadians??-Math.floor((state.elapsedFrames??0)/45)*(Math.PI/2),quarter=Number.isFinite(state.rollQuarter)?state.rollQuarter:Number.isFinite(angle)?Math.round(angle/(Math.PI/2)):0;anchored(c,q,quarterTurn(A.galoomba,quarter),{scale,mirror:(q.facing??q.vx??-1)>0});return true;}
 if(q.smm2Thwomp||kind==='smm2-thwomp'||kind==='thwomp'){const phase=q.smm2Thwomp?.phase??q.phase??'waiting';anchored(c,q,['windup','charge','impact','return','attack','falling','slamming','moving','returning'].includes(phase)?A.thwompAngry:A.thwompPeek);return true;}
 if(q.smm2Skewer||kind==='smm2-skewer')return drawSmwUnderwaterSkewer(c,q);
 const skewer=room.smm2Mechanics?.skewers?.find(s=>s.id===q.id);if(skewer)return drawSmwUnderwaterSkewer(c,{...q,smm2Skewer:{direction:skewer.direction,base:q}});
 const thwomp=room.smm2Mechanics?.thwomps?.find(s=>s.id===q.id);if(thwomp){anchored(c,q,A.thwompPeek);return true;}
 if(['beetle-shell','beetleshell','beetle','buzzy-shellmet','smm2-buzzy-shell'].includes(kind)||q.smm2Helmet){if(q.smm2Helmet?.phase==='worn')return true;anchored(c,q,q.smm2Helmet?A.buzzyHelmet:A.buzzyLoose);return true;}
 if(q.kind==='coin'||q.kind==='coin-pop'){anchored(c,q,A.coin);return true;}
 if(q.kind==='mushroom'||q.smm2PlacedItem?.kind==='mushroom'){anchored(c,q,A.mushroom);return true;}
 if(['door','wood-door'].includes(kind)||tag==='smw-underwater-door'||doorDescriptor(q,room)){anchored(c,q,A.door);return true;}
 if(['smw-goal-gate','giant-gate'].includes(q.kind)||tag==='smw-underwater-goal-gate'||q.kind==='exit'&&room.smm2Mechanics?.goalTape?.id===q.id)return drawSmwUnderwaterGoalGate(c,q,room);
 if(q.kind==='spawn')return drawSmwUnderwaterPlayer(c,{...q,grounded:true,power:0,facing:1},{room});
 return false;
}
/** The existing motor owns stroke/stride clocks. Only observed Story42
 * normal-SMW-water limb timing is used here. A real stroke displays
 * pose1 for4ticks, pose2 for8ticks, then returns to pose0/coast and HOLDS.
 * There is no timer-driven bob, perpetual coast loop or player-body mutation. */
export function smwUnderwaterPlayerPose(p,room={}){
 if(!rect(p))return null;
 if(p.dying)return{key:'small_death_0',sprite:M.small_death_0,registered:true,mirror:false,phase:'death'};
 const growing=!!p.growth,large=!!(growing?Math.floor(p.growth/4)%2:p.power),size=large?'super':'small',swim=!!p.swimming&&!p.grounded;
 if(swim){
  const strokeFrames=room.aquatic?.physics?.strokeFrames??24,remaining=Math.max(0,p.swimStroke||0),age=Math.max(0,strokeFrames-remaining),index=!remaining?0:age<4?1:age<12?2:0,key=size+'_swim_'+index;
  return{key,sprite:M[key],registered:true,mirror:p.facing>0,phase:index?'stroke':'coast',strokeAge:age};
 }
 if(p.grounded&&!p.piping&&!p.shrink&&!growing&&!p.fireGrowth&&Math.abs(p.vx||0)>.08){
  // Source Small has only two distinct walking appearances. The duplicate
  // sheet columns are not promoted into a third invented limb pose.
  const stride=large?16:10,index=large?Math.floor((Math.max(0,p.anim||0)%stride)/(stride/3)):Math.floor((Math.max(0,p.anim||0)%stride)/(stride/2))*2,key=size+'_walk_'+index;
  return{key,sprite:M[key],registered:true,mirror:p.facing>0,phase:'walk'};
 }
 const key=!p.grounded&&!p.piping?(large?'marioBigJump':'marioSmallJump'):(large?'marioBigIdle':'marioSmallIdle');
 return{key,sprite:A[key],registered:false,mirror:p.facing<0,phase:p.grounded?'idle':'jump'};
}
function smwPlayerHiddenDuringHurt(p){
 if(p.dying||p.growth||p.fireGrowth||!p.invulnerable)return false;
 const age=Math.max(0,120-p.invulnerable);
 // First contact is partially occluded in the reference. Its initial6tick
 // hidden window is an explicit fit; subsequent8tick visible/hidden phases
 // are directly supported by the 30fps source sequence.
 return age<6||Math.floor((age-6)/8)%2===1;
}
export function drawSmwUnderwaterPlayer(c,p,options={}){
 const room=options.room??options;if(!isSmwUnderwaterRoom(room))return false;if(!visible(p))return !!p;if(!rect(p))return false;
 if(smwPlayerHiddenDuringHurt(p))return true;
 const pose=smwUnderwaterPlayerPose(p,room),a=pose?.sprite;if(!a)return false;let visual;
 if(pose.registered){const anchor=a.nativeAnchor;visual={x:Math.round(p.x+p.w/2-anchor.x),y:Math.round(p.y+p.h-anchor.y)};}
 else visual=smwUnderwaterSpriteRect(p,a);if(!visual)return false;
 drawSmwUnderwaterPixels(c,a,{...visual,mirror:pose.mirror});
 if(p.helmet==='buzzy'&&!p.dying){const headCenter=p.x+p.w/2+(p.swimming&&!p.grounded?(p.facing<0?-2:2):0),headTop=visual.y+(pose.registered?a.visibleBounds[1]:0);drawSmwUnderwaterPixels(c,A.buzzyHelmet,{x:headCenter-8,y:headTop-7,mirror:p.facing<0});}
 return true;
}
/** Fill is usable before the host applies its world-camera transform. */
export function drawSmwUnderwaterBackground(c,room,w,h){if(!isSmwUnderwaterRoom(room)||!Number.isFinite(w)||!Number.isFinite(h))return false;c.save();c.fillStyle='#09538f';c.fillRect(0,0,w,h);c.restore();return true;}
export function drawSmwUnderwaterHudSprite(c,room,role,centerX,bottom,height){
 if(!isSmwUnderwaterRoom(room))return false;const a=role==='coin'?A.coin:A.marioSmallIdle,scale=height/a.height;return drawSmwUnderwaterPixels(c,a,{x:centerX-a.width*scale/2,y:bottom-height,scale});
}
/** Source-observed pale/pink signs retain their own raster dimensions.
 * A floating marker rotates the one fitted shape; it has no simulated body.
 */
export function drawSmwUnderwaterReference(c,q,room={}){
 if(!isSmwUnderwaterRoom(room)||q?.kind!=='source-arrow')return false;if(!visible(q))return true;
 if(q.source?.signArt==='smw-observed-arrow')return anchored(c,{...q,w:q.w??48,h:q.h??48},A.startSignObserved);
 const direction=q.source?.direction??'right',mirror=['up-left','down-left'].includes(direction),a=D[direction]??D[direction==='up-left'?'up-right':direction==='down-left'?'down-right':'down'],angle={up:Math.PI,right:-Math.PI/2,left:Math.PI/2}[direction]??0;
 const w=q.w??24,h=q.h??24,scale=Math.min(w/24,h/24);if(!Number.isFinite(scale)||scale<=0)return false;
 const anchor=a.nativeAnchor,x=mirror?a.width-anchor.x:anchor.x;
 c.save();c.translate(Math.round(q.x+w/2),Math.round(q.y+h/2));c.rotate(angle);drawSmwUnderwaterPixels(c,a,{x:-x*scale,y:-anchor.y*scale,scale,mirror});c.restore();return true;
}
/** World-space backdrop. The finite motif placements are reconstructed from
 * the observed ordinary underwater rock/weed pattern. Repeat and
 * hidden face choices are adapted; collision/room/camera objects are untouched. */
export function drawSmwUnderwaterBackdrop(c,room={},bounds=room.renderBounds){
 if(!isSmwUnderwaterRoom(room))return false;const b=bounds&&rect(bounds)?bounds:{x:room.sourceCameraX??0,y:room.sourceCameraY??0,w:room.map?.width??384,h:room.map?.height??216};
 c.save();c.beginPath();c.rect(b.x,b.y,b.w,b.h);c.clip();c.fillStyle='#09538f';c.fillRect(b.x,b.y,b.w,b.h);
 const period=288,oy=room.smm2Mechanics?.camera?.baseY??0;for(let page=Math.floor((b.x-40)/period);page<=Math.floor((b.x+b.w)/period);page++){
  const origin=page*period;for(let vertical=Math.floor((b.y-oy-178)/224);vertical<=Math.floor((b.y-oy+b.h)/224);vertical++){const by=oy+vertical*224;for(const [dx,dy]of [[25,38],[152,8],[267,50]])drawSmwUnderwaterPixels(c,A.backgroundCliffAdapted,{x:origin+dx,y:by+dy});
   for(const [dx,dy]of [[45,38],[155,8],[275,50],[196,82],[243,70]])drawSmwUnderwaterPixels(c,A.backgroundWeedAdapted,{x:origin+dx,y:by+dy});}
  // Architecture belongs to explicit authored decorations. Distant motifs
  // never manufacture foreground-like solid or non-solid column placement.
  c.fillStyle='#46317e';for(let vertical=Math.floor((b.y-oy)/224);vertical<=Math.floor((b.y-oy+b.h)/224);vertical++)for(const [dx,dy]of [[6,74],[78,118],[176,38],[264,176]])for(let x=0;x<32;x++){const inset=x<4||x>28?1:0;c.fillRect(origin+dx+x,oy+vertical*224+dy+inset,1,2-inset);}
 }
 c.restore();return true;
}
/** Static editor preview only. Runtime cells already go through drawTile.
 * Initial occupancy is sampled from the authored path with no controller and
 * no clock, activation, falling state, or geometry mutation. */
export function drawSmwUnderwaterSnakeWorld(c,room={}){
 const trains=room.smm2Mechanics?.snakeBlocks?.trains??[];
 for(const train of trains){if(!Array.isArray(train.path)||train.path.length<2||!Number.isFinite(train.initialHeadDistancePx)||!Number.isInteger(train.lengthCells)||!train.origin)continue;
  const nodes=[];for(let i=0;i<train.path.length;i++){const p=train.path[i];if(!i)nodes.push({...p,distance:0});else{const from=train.path[i-1],steps=(Math.abs(p.x-from.x)+Math.abs(p.y-from.y))/16;if(!Number.isInteger(steps)||steps>16384)continue;for(let n=1;n<=steps;n++)nodes.push({x:from.x+Math.sign(p.x-from.x)*n*16,y:from.y+Math.sign(p.y-from.y)*n*16,distance:nodes.length*16});}}
  const point=distance=>{let i=Math.min(nodes.length-2,Math.max(0,Math.floor(distance/16))),p=nodes[i],n=nodes[i+1],f=(distance-p.distance)/16;return{x:train.origin.x+p.x+(n.x-p.x)*f,y:train.origin.y+p.y+(n.y-p.y)*f,w:16,h:16};};
  if(nodes.length<2)continue;const head=train.initialHeadDistancePx,tail=head-(train.lengthCells-1)*16;
  const cells=[point(tail),...nodes.filter(n=>n.distance>tail&&n.distance<head).map(n=>({x:train.origin.x+n.x,y:train.origin.y+n.y,w:16,h:16})),point(head)];for(const q of cells)drawSmm2SnakeBlockTile(c,{...q,smm2SnakeBlock:{color:train.color,phase:'occupied',darkened:false}});
 }
 return trains.length>0;
}
