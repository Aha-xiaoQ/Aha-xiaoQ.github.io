/** SMW Goal Tape, opt-in author contract fitted to the observed Underwater end.
 * The reference shows vertical tape motion, high contact, a short clear hop,
 * falling to the ground and a rightward walk. It does not establish the full
 * lower travel limit, an engine hitbox, or a reward table for other heights.
 * Every collider, travel bound, reward band and clear coefficient below is
 * explicitly authored. The host owns Mario's motor, score and time bonus.
 */
const EPS=1e-7;
const copy=q=>structuredClone(q);
const plain=q=>q&&typeof q==='object'&&!Array.isArray(q)&&[Object.prototype,null].includes(Object.getPrototypeOf(q));
const finite=(n,min,max)=>Number.isFinite(n)&&n>=min&&n<=max;
const integer=(n,min,max)=>Number.isSafeInteger(n)&&finite(n,min,max);
const safeId=s=>typeof s==='string'&&s.length<=100&&/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(s);
const rect=q=>plain(q)&&['x','y','w','h'].every(k=>Number.isFinite(q[k]))&&q.w>0&&q.h>0;
function fields(q,keys,label){if(!plain(q)||Object.keys(q).some(k=>!keys.includes(k)||['__proto__','prototype','constructor'].includes(k)))throw Error('Invalid SMW Goal Tape '+label+' fields');}
function contained(a,b){return a.x>=b.x-EPS&&a.y>=b.y-EPS&&a.x+a.w<=b.x+b.w+EPS&&a.y+a.h<=b.y+b.h+EPS;}
function overlap(a,b){return a.x+a.w>b.x+EPS&&b.x+b.w>a.x+EPS&&a.y+a.h>b.y+EPS&&b.y+b.h>a.y+EPS;}

export function validateSmwGoalTapeRoom(room){
 const q=room?.smm2Mechanics?.goalTape;if(q===undefined)return;
 fields(q,['id','posts','tape','rewardBands','clear'],'configuration');
 const matches=(room.map?.objects||[]).filter(o=>o.id===q.id&&o.kind==='exit'),exit=matches[0];
 if(!safeId(q.id)||matches.length!==1||!rect(exit)||!contained(exit,{x:0,y:0,w:room.map.width,h:room.map.height})||(room.map?.geometry||[]).some(g=>g.id===q.id))throw Error('SMW Goal Tape needs one unique existing native exit inside the room');
 if(room.smm2Mechanics.goalCard?.id===q.id)throw Error('An exit cannot own both an SMW Goal Tape and an SMB3 goal card');
 if(room.smm2Mechanics.art?.palette!=='smw-underwater-source')throw Error('SMW Goal Tape needs the explicit SMW Underwater art profile');
 if(!/Underwater/.test(room.setting||'')||/Night/i.test(room.setting||'')||room.underwater===false||room.aquatic?.version!==1||room.aquatic.contactBodies!=='smm2-solid-actors')throw Error('SMW Goal Tape needs the supported normal Underwater solid-body profile');
 fields(q.posts,['left','right'],'posts');
 for(const p of [q.posts.left,q.posts.right]){fields(p,['x','y','w','h'],'post');if(!rect(p)||!finite(p.w,1,64)||!finite(p.h,16,1024)||!contained(p,exit))throw Error('SMW Goal Tape posts must fit their actual exit');}
 const left=q.posts.left,right=q.posts.right;
 if(left.y!==right.y||left.h!==right.h||left.w!==right.w||left.x+left.w>right.x||right.x-left.x>256)throw Error('SMW Goal Tape needs an ordered pair of equal upright posts');
 fields(q.tape,['x','w','h','minY','maxY','speed','phaseFrames','direction'],'motion');
 const t=q.tape;
 if(!finite(t.x,left.x,left.x+left.w)||!finite(t.w,1,256)||t.x+t.w<right.x||t.x+t.w>right.x+right.w||!finite(t.h,.1,32)||!finite(t.minY,left.y+t.h/2,left.y+left.h-t.h/2)||!finite(t.maxY,t.minY+1,left.y+left.h-t.h/2)||!finite(t.speed,.01,32)||!integer(t.phaseFrames,0,360000)||!['up','down'].includes(t.direction))throw Error('Invalid SMW Goal Tape authored motion or collider');
 if(!Array.isArray(q.rewardBands)||!q.rewardBands.length||q.rewardBands.length>32)throw Error('SMW Goal Tape needs explicit authored reward bands');
 let edge=t.minY;
 for(const band of q.rewardBands){
  fields(band,['minY','maxY','points','coins','lives'],'reward band');
  if(!finite(band.minY,t.minY,t.maxY)||Math.abs(band.minY-edge)>EPS||!finite(band.maxY,band.minY+EPS,t.maxY)||!integer(band.points,0,100000)||!integer(band.coins,0,100)||!integer(band.lives,0,99))throw Error('SMW Goal Tape reward bands must cover the authored travel range once, in ascending Y');
  edge=band.maxY;
 }
 if(Math.abs(edge-t.maxY)>EPS)throw Error('SMW Goal Tape reward bands must cover the authored travel range');
 fields(q.clear,['hopSpeed','walkSpeed','walkDistance','clearFrames','motion','cameraY'],'clear');
 if(q.clear.motion!==undefined&&!['room','dry'].includes(q.clear.motion))throw Error('Invalid SMW clear motion profile');
 if(q.clear.cameraY!==undefined&&!finite(q.clear.cameraY,0,room.map.height-(room.playRules?.viewportHeight??216)))throw Error('Invalid authored SMW clear camera framing');
 if(!finite(q.clear.hopSpeed,.01,12)||!finite(q.clear.walkSpeed,.01,4)||!finite(q.clear.walkDistance,0,room.map.width-right.x-right.w)||!integer(q.clear.clearFrames,0,3600))throw Error('Invalid SMW Goal Tape authored clear sequence');
}

function projection(q,tick){
 if(!integer(tick,0,Number.MAX_SAFE_INTEGER))throw Error('SMW Goal Tape tick must be a nonnegative safe integer');
 const t=q.tape,span=t.maxY-t.minY,period=span*2;
 const distance=((tick+t.phaseFrames)*t.speed+(t.direction==='up'?span:0))%period;
 const centerY=t.minY+(distance<=span?distance:period-distance);
 return{id:q.id,x:t.x,y:centerY-t.h/2,w:t.w,h:t.h,centerY,direction:distance<span?'down':'up',posts:copy(q.posts)};
}
/** Pure projection: inspection/rendering cannot advance or rewind motion. */
export function smwGoalTapeAt(room,tick=0){const q=room?.smm2Mechanics?.goalTape;return q?projection(q,tick):null;}

function lerpRect(a,b,f){return Object.fromEntries(['x','y','w','h'].map(k=>[k,a[k]+(b[k]-a[k])*f]));}
function sweptOverlap(a0,a1,b0,b1){
 // Each strict overlap condition is affine, including body size changes.
 let low=0,high=1;
 const values=(a,b)=>[a.x+a.w-b.x,b.x+b.w-a.x,a.y+a.h-b.y,b.y+b.h-a.y];
 const start=values(a0,b0),end=values(a1,b1);
 for(let k=0;k<4;k++){const slope=end[k]-start[k];if(Math.abs(slope)<EPS){if(start[k]<=EPS)return null;}else if(slope>0)low=Math.max(low,(EPS-start[k])/slope);else high=Math.min(high,(EPS-start[k])/slope);}
 return high>Math.max(0,low)+EPS&&low<1?Math.max(0,low):null;
}
function contactDuringPreviousFrame(q,before,player,tick){
 const t=q.tape,span=t.maxY-t.minY,period=span*2,startTick=tick-1;
 const phase=((startTick+t.phaseFrames)*t.speed+(t.direction==='up'?span:0))%period;
 const remainder=phase%span;
 const firstTurn=(span-(Math.abs(remainder)<EPS?0:remainder))/t.speed;
 const fractions=[0];for(let f=firstTurn;f<1-EPS;f+=span/t.speed)fractions.push(f);fractions.push(1);
 for(let i=1;i<fractions.length;i++){
  const low=fractions[i-1],high=fractions[i],a0=lerpRect(before,player,low),a1=lerpRect(before,player,high);
  // Projection accepts integer simulation ticks publicly. This local affine
  // segment interpolates its endpoints at the exact authored turn times.
  const at=f=>{const p=(phase+f*t.speed)%period,centerY=t.minY+(p<=span?p:period-p);return{x:t.x,y:centerY-t.h/2,w:t.w,h:t.h,centerY};};
  const b0=at(low),b1=at(high),local=sweptOverlap(a0,a1,b0,b1);
  if(local!==null){const fraction=low+(high-low)*local;return{fraction,centerY:at(fraction).centerY,player:lerpRect(before,player,fraction)};}
 }
 return null;
}

export function createSmwGoalTape(room,{emit=()=>{}}={}){
 validateSmwGoalTapeRoom(room);const authored=room?.smm2Mechanics?.goalTape;if(!authored)return null;
 const q=copy(authored),source=copy(room.map.objects.find(o=>o.id===q.id&&o.kind==='exit'));
 let spent=false,lastTick=null,contactY=null,contactTick=null;
 function step(player,{tick,before,object=source}={}){
  if(!integer(tick,0,Number.MAX_SAFE_INTEGER))throw Error('SMW Goal Tape tick must be a nonnegative safe integer');
  if(lastTick!==null&&tick<=lastTick)return null;lastTick=tick;
  if(spent||!rect(player)||player.dead||player.dying||player.clawHeld||!object||object.id!==q.id||object.kind!=='exit')return null;
  const tape=projection(q,tick);
  // A static exit rectangle is never a substitute for the moving tape body.
  const swept=tick>0&&rect(before)?contactDuringPreviousFrame(q,before,player,tick):null;
  if(!swept&&!overlap(player,tape))return null;
  contactY=swept?.centerY??tape.centerY;contactTick=tick;spent=true;
  const band=q.rewardBands.find((b,i)=>contactY>=b.minY-EPS&&(contactY<b.maxY-EPS||i===q.rewardBands.length-1));
  const reward={points:band.points,coins:band.coins,lives:band.lives};
  const finish={tape:true,phase:'tape-hop',age:0,x:player.x,y:player.y,tapeId:q.id,contactTick:tick,contactY,contactFraction:swept?.fraction??1,reward,...copy(q.clear),walkTarget:q.posts.right.x+q.posts.right.w+q.clear.walkDistance};
  emit('smw-goal-tape',{event:'tape-contact',roomId:room.roomId,tapeId:q.id,tick,contactY,reward:copy(reward)});
  return finish;
 }
 return Object.freeze({step,view:tick=>({...projection(q,tick),spent,contactY,contactTick}),reset:()=>{spent=false;lastTick=null;contactY=null;contactTick=null;}});
}
