import {spritePixels} from './classic-art.mjs';
const goomba=spritePixels('goomba');
/** Existing native SMB1 Goomba pixels, without enemy physics or hit contact.
 * The small pennant and celebratory pose are authored scene animation. */
function drawGoomba(c,a,tick){
 c.save();c.translate(Math.round(a.x),Math.round(a.y));if(a.facing<0){c.translate(16,0);c.scale(-1,1);}
 const flip=a.pose==='cheer'&&Math.floor((a.poseAge||tick)/8)%2;
 for(let y=0;y<goomba.h;y++)for(let x=0;x<goomba.w;x++){const rgba=goomba.pixels[y*goomba.w+(flip?goomba.w-1-x:x)];if(!rgba[3])continue;c.fillStyle=`rgba(${rgba[0]},${rgba[1]},${rgba[2]},${rgba[3]/255})`;c.fillRect(x,y,1,1);}
 if(a.pose==='wave'){
  const up=Math.floor((a.poseAge||0)/10)%2,px=up?16:14,py=up?-7:-4;c.fillStyle='#bcbcbc';c.fillRect(px,py,1,14);c.fillStyle='#fc9838';c.fillRect(px+1,py,5,4);c.fillStyle='#ffffff';c.fillRect(px+1,py,4,1);
 }
 c.restore();
}
export function drawJrArenaAudience(c,room,tick=room?.tick||0){
 const spec=room?.smm2Mechanics?.arenaAudience;if(!spec)return false;
 const view=room.arenaAudienceView??spec,spectators=view.spectators??spec.seats.map(q=>({...q,pose:'seated'}));
 for(const actor of spectators)drawGoomba(c,actor,tick);
 for(const warning of view.galleryWarnings||[]){
  if(warning.formation==='row'){
   // One actual gallery mouth, with six finite queue lamps. Warning pixels
   // never impersonate an enemy or create a collision-free row on the floor.
   c.fillStyle=Math.floor(warning.age/8)%2?'#bcbcbc':'#fc9838';
   c.fillRect(warning.x-1,warning.y-1,18,1);c.fillRect(warning.x-1,warning.y,1,16);c.fillRect(warning.x+16,warning.y,1,16);
   for(let index=0;index<warning.rowCount;index++){c.fillStyle=index<warning.queuedCount?'#fc9838':'#5c5c5c';c.fillRect(warning.x+index*2+2,warning.y-4,1,2);}
  }else{
  drawGoomba(c,{...warning,pose:'cheer',poseAge:warning.age,facing:warning.direction},tick);
  }
  // A blinking native-grid exclamation makes the imminent gallery entry clear.
  if(Math.floor(warning.age/8)%2===0){c.fillStyle='#ffffff';c.fillRect(warning.x+7,warning.y-14,2,7);c.fillRect(warning.x+7,warning.y-5,2,2);}
 }
 return true;
}
