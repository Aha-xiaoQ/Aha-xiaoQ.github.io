import {validateCompletionMarksRoom} from './editor-completion-marks.mjs';
import {validateSkyShooterRoom} from './editor-sky-shooter.mjs';
import {validateJrArenaAudienceRoom} from './editor-jr-arena-audience.mjs';
import {validateBowserJuniorsRoom} from './editor-bowser-jr.mjs';
import {validateSmm2LiquidRoom} from './editor-smm2-liquid.mjs';
import {validateCastleSmm2Compatibility,isSmm2CastleDoor,isSmm2CastleRegion} from './editor-castle.mjs';
import {validateSmm2CourseComponents} from './editor-smm2-course-components.mjs';
import {validateSmm2CarriersRoom} from './editor-smm2-carriers.mjs';
import {validateSmm2ItemsRoom} from './editor-smm2-items.mjs';
import {validateSmm2ThwompsRoom} from './editor-smm2-thwomps.mjs';
import {validateSMM2Terrain} from './editor-smm2-terrain.mjs';
import {validateSmm2ShoesRoom} from './editor-smm2-shoes.mjs';
import {validateSmm2LightingRoom} from './editor-smm2-lighting.mjs';
import {validateConveyorsRoom,assertConveyorPlacement} from './editor-conveyor-surfaces.mjs';
import {validatePortableStones} from './editor-portable-stones.mjs';
import {validateLocalUpdrafts} from './editor-local-updrafts.mjs';
import {validateParachuteActors} from './editor-parachute-actors.mjs';
import {validateLakituClouds} from './editor-lakitu-clouds.mjs';
import {validateRailHazards} from './editor-rail-hazards.mjs';
import {validateSmm2SnakeBlocksRoom} from './editor-snake-blocks.mjs';
import {validateUnderwaterActorsRoom} from './editor-underwater-actors.mjs';
import {validateSmwGoalTapeRoom} from './editor-smw-goal-tape.mjs';

const plain=v=>v&&typeof v==='object'&&!Array.isArray(v);
const finite=(n,a,b)=>Number.isFinite(n)&&n>=a&&n<=b;
const safeId=s=>typeof s==='string'&&/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(s)&&s.length<=100;
function fields(v,keys,label){if(!plain(v))throw Error('Invalid '+label);for(const k of Object.keys(v))if(!keys.includes(k)||['__proto__','prototype','constructor'].includes(k))throw Error('Unknown '+label+' field: '+k);}
export function validateSmm2MechanicsRoom(room){
 const s=room.smm2Mechanics;if(s===undefined)return;
 fields(s,['version','art','startingLives','thwomps','donuts','slopes','seesaws','vines','powBlocks','pSwitches','helmets','skewers','placedItems','pinkCoins','shellCoinCollection','goalTopLife','enemyRewards','carrierGeometry','carrierItems','checkpointRewards','shoes','goalEnemyRewards','flagScore','goalCard','springs','camera','boneShells','liquid','lighting','conveyors','goalCoins','goalCoinPoints','scoreProfile','portableStones','localUpdrafts','parachuteActors','lakituClouds','railHazards','goalCloudRequirements','deathCoinPenalty','snakeBlocks','underwaterActors','goalTape','bowserJuniors','arenaAudience','skyShooter','completionMarks'],'SMM2 mechanics');
 if(s.version!==1)throw Error('Unknown SMM2 mechanics version');
 validateCompletionMarksRoom(room);
 const water=!!room.aquatic||/Underwater/.test(room.setting||'');
 const underwaterFields=new Set(['version','art','startingLives','thwomps','skewers','placedItems','helmets','camera','scoreProfile','flagScore','goalCoins','goalCoinPoints','checkpointRewards','snakeBlocks','underwaterActors','goalTape']);
 const verifiedWater=water&&room.aquatic?.contactBodies==='smm2-solid-actors'&&Object.keys(s).every(k=>underwaterFields.has(k));
 if(room.mechanics||room.devices?.length||water&&!verifiedWater||room.castle&&!isSmm2CastleDoor(room)&&!isSmm2CastleRegion(room)||room.playHero==='bill')throw Error('SMM2 contact mechanics need the explicit supported solid-body water profile and cannot combine unverified rewind, castle-ending or Bill adapters');
 validateCastleSmm2Compatibility(room);
 if(s.flagScore!==undefined&&typeof s.flagScore!=='boolean')throw Error('Invalid SMM2 classic flag score rule');
 if(s.shellCoinCollection!==undefined&&typeof s.shellCoinCollection!=='boolean')throw Error('Invalid SMM2 shell coin collection rule');
 if(s.goalEnemyRewards!==undefined){if(!Array.isArray(s.goalEnemyRewards)||s.goalEnemyRewards.length>256)throw Error('Invalid goal enemy reward list');const seen=new Set();for(const q of s.goalEnemyRewards){fields(q,['id','points'],'goal enemy reward');if(!safeId(q.id)||seen.has(q.id)||!Number.isInteger(q.points)||q.points<0||q.points>100000||!room.map.objects.some(o=>o.kind==='walker'&&o.id===q.id))throw Error('Goal enemy reward must reference a unique native walker and bounded score');seen.add(q.id);}}
 if(s.goalTopLife!==undefined&&typeof s.goalTopLife!=='boolean')throw Error('Invalid SMM2 goal life rule');
 if(s.deathCoinPenalty!==undefined&&(!Number.isInteger(s.deathCoinPenalty)||!finite(s.deathCoinPenalty,0,100)))throw Error('Invalid authored death coin penalty');
 if(s.goalCloudRequirements!==undefined){if(!Array.isArray(s.goalCloudRequirements)||s.goalCloudRequirements.length>256)throw Error('Invalid cloud goal requirements');const seen=new Set();for(const q of s.goalCloudRequirements){fields(q,['exitId','cloudId'],'cloud goal requirement');if(!safeId(q.exitId)||!safeId(q.cloudId)||seen.has(q.exitId)||!room.map.objects.some(o=>o.kind==='exit'&&o.id===q.exitId)||!s.lakituClouds?.clouds?.some(c=>c.id===q.cloudId))throw Error('Cloud goal requires one real exit and authored cloud');seen.add(q.exitId);}}
 // Optional authored score configuration. Validation never inserts defaults
 // into legacy courses or awards anything; live Stage contacts own rewards.
 if(s.goalCoins!==undefined&&(!Number.isInteger(s.goalCoins)||!finite(s.goalCoins,0,100)))throw Error('Invalid SMM2 authored goal coin count');
 if(s.goalCoinPoints!==undefined&&(!Number.isInteger(s.goalCoinPoints)||!finite(s.goalCoinPoints,0,100000)))throw Error('Invalid SMM2 authored goal coin points');
 if(s.scoreProfile!==undefined){fields(s.scoreProfile,['coinPoints','keyPoints'],'SMM2 score profile');if(![Object.prototype,null].includes(Object.getPrototypeOf(s.scoreProfile)))throw Error('Invalid SMM2 score profile');for(const key of ['coinPoints','keyPoints'])if(!Number.isInteger(s.scoreProfile[key])||!finite(s.scoreProfile[key],0,100000))throw Error('Invalid SMM2 authored '+key);}
 if(s.conveyors!==undefined)validateConveyorsRoom(s.conveyors,{width:room.map.width,height:room.map.height});
 if(s.enemyRewards!==undefined){if(!Array.isArray(s.enemyRewards)||s.enemyRewards.length>256)throw Error('Invalid enemy reward list');const seen=new Set();for(const q of s.enemyRewards){fields(q,['id','reward'],'enemy reward');if(!safeId(q.id)||seen.has(q.id)||q.reward!=='key'||!room.map.objects.some(o=>o.kind==='walker'&&o.id===q.id))throw Error('Enemy key reward must reference a unique native walker');seen.add(q.id);}}
 if(s.checkpointRewards!==undefined){if(!Array.isArray(s.checkpointRewards)||s.checkpointRewards.length>256)throw Error('Invalid checkpoint reward list');const seen=new Set();for(const q of s.checkpointRewards){fields(q,['id','reward','points'],'checkpoint reward');if(!safeId(q.id)||seen.has(q.id)||!['none','mushroom','star'].includes(q.reward)||!Number.isInteger(q.points)||q.points<0||q.points>100000||!room.map.objects.some(o=>o.kind==='checkpoint'&&o.id===q.id))throw Error('Checkpoint reward must reference a unique native checkpoint and bounded score');seen.add(q.id);}}
 for(const g of room.map.geometry)if(g.smm2BlockKind!==undefined&&(!(g.smm2BlockKind==='hard-block'&&g.collision==='solid')||g.material!=='stone'||g.w%16||g.h%16))throw Error('Hard-block identity must mark real solid whole-tile native stone geometry');
 if(s.startingLives!==undefined&&(!Number.isInteger(s.startingLives)||s.startingLives<1||s.startingLives>99))throw Error('Invalid SMM2 starting lives');
 if(s.art!==undefined){fields(s.art,['palette','tileOriginX','tileOriginY','goalBackdropX','dropShadows'],'SMM2 art');if(!['smb1-castle-stone','smb1-snow','smb1-shoe-underworld','smb3-underground','smb3-desert','smb1-underground-source','smb1-overworld-source','smb1-ghost-source','smb1-sky-source','smw-underwater-source'].includes(s.art.palette))throw Error('Unknown SMM2 art palette');for(const k of ['tileOriginX','tileOriginY'])if(s.art[k]!==undefined&&(!Number.isInteger(s.art[k])||!finite(s.art[k],-32768,32768)))throw Error('Invalid source tile origin');if(s.art.dropShadows!==undefined&&typeof s.art.dropShadows!=='boolean')throw Error('Invalid source art shadow flag');if(s.art.goalBackdropX!==undefined&&!finite(s.art.goalBackdropX,0,room.map.width))throw Error('Invalid source goal backdrop coordinate');}
 validateSmm2LiquidRoom(room);validateSmm2CourseComponents(room);validateSmm2ThwompsRoom(room);validateSMM2Terrain(room);validateSmm2ItemsRoom(room);validateSmm2CarriersRoom(room);validateSmm2ShoesRoom(room);validateSmm2LightingRoom(room);validatePortableStones(room);validateLocalUpdrafts(room);validateParachuteActors(room);validateLakituClouds(room);validateRailHazards(room);validateSmm2SnakeBlocksRoom(room);validateUnderwaterActorsRoom(room);validateSmwGoalTapeRoom(room);validateBowserJuniorsRoom(room);validateJrArenaAudienceRoom(room);validateSkyShooterRoom(room);
 const portableIds=new Set((s.portableStones?.stones||[]).map(q=>q.id)),twisterIds=new Set((s.localUpdrafts?.twisters||[]).map(q=>q.id));for(const id of portableIds)if(twisterIds.has(id))throw Error("Stone body cannot also own local updraft motion");for(const key of ["thwomps","shoes","boneShells","powBlocks","pSwitches","helmets","skewers","placedItems"])for(const q of s[key]||[])if(portableIds.has(q.id)||twisterIds.has(q.id))throw Error("Portable Stone or Twister body cannot also own another actor mechanic");for(const id of Object.keys(room.marioModules?.enemyVariants||{}))if(portableIds.has(id)||twisterIds.has(id))throw Error("Portable Stone or Twister body cannot own a typed enemy variant");
 const shoeIds=new Set([...(s.shoes||[]),...(s.boneShells||[])].map(q=>q.id));
 const pIds=new Set((s.pSwitches||[]).map(q=>q.id));for(const q of s.thwomps||[])if(pIds.has(q.id))throw Error('P Switch body cannot also own a Thwomp mechanic');for(const id of Object.keys(room.marioModules?.enemyVariants||{}))if(pIds.has(id))throw Error('P Switch body cannot also own a typed enemy variant');
 for(const key of ['thwomps','powBlocks','pSwitches','helmets','skewers','placedItems','pinkCoins'])for(const q of s[key]||[])if(shoeIds.has(q.id))throw Error('SMM2 Shoe foot body cannot also own another actor mechanic');
 for(const id of Object.keys(room.marioModules?.enemyVariants||{}))if(shoeIds.has(id))throw Error('SMM2 Shoe foot body cannot also own a typed enemy variant');
 const solids=new Set([...room.map.geometry.filter(q=>q.collision==='oneway').map(q=>q.id),...(s.donuts||[]).filter(q=>q.collision==='oneway').map(q=>q.id)]);
 for(const q of s.thwomps||[])for(const id of q.oneWaySupportIds||[])if(!solids.has(id))throw Error('Thwomp one-way support must reference a real authored one-way collider');
 if(s.pinkCoins!==undefined){if(!Array.isArray(s.pinkCoins)||s.pinkCoins.length>32)throw Error('Invalid pink coin list');const seen=new Set();for(const q of s.pinkCoins){fields(q,['id'],'pink coin');if(!safeId(q.id)||seen.has(q.id)||!room.map.objects.some(o=>o.id===q.id&&o.kind==='coin'))throw Error('Pink coin must reference a unique native coin');seen.add(q.id);}}
 const ids=new Set([...room.map.geometry,...room.map.objects,...(room.markers||[])].map(q=>q.id));
 for(const key of ['donuts','slopes','seesaws'])for(const q of s[key]||[])ids.add(q.id);
 for(const q of s.conveyors||[]){if(ids.has(q.id))throw Error('Duplicate SMM2 conveyor surface ID');ids.add(q.id);}
 if(s.vines!==undefined){if(!Array.isArray(s.vines)||s.vines.length>256)throw Error('Invalid static vine list');for(const q of s.vines){fields(q,['id','x','y','w','h','climbSpeed'],'static vine');if(!safeId(q.id)||ids.has(q.id))throw Error('Duplicate static vine ID');ids.add(q.id);if(!finite(q.x,0,room.map.width-q.w)||!finite(q.y,0,room.map.height-q.h)||!finite(q.w,1,32)||!finite(q.h,1,room.map.height)||!finite(q.climbSpeed,.05,4))throw Error('Static vine bounds or climb speed are invalid');}}
 assertConveyorPlacement(room);
}
export function staticVines(room){return (room.smm2Mechanics?.vines||[]).map(q=>({...q,bottom:q.y+q.h,static:true,portal:null}));}
