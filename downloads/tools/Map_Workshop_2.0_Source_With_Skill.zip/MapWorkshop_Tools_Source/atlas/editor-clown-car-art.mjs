import {CLOWN_CAR_SOURCE} from './clown-car-source-data.mjs';

/** @typedef {'empty'|'npc'|'player'} ClownCarOccupancy */
/** @typedef {'empty-hover'|'npc-occupied'|'npc-spike-panic'|'player-rest'|'player-moving'} ClownCarVisualState */
/** @typedef {{id:string,x:number,y:number,w:number,h:number,vx?:number,vy?:number,occupancy?:ClownCarOccupancy,occupantId?:string|null,npcPanic?:{active:boolean}}} ClownCarRenderView */
/** @typedef {{id:string,frame:string,width:number,height:number,rimRows:number,smallVisibleRows:number,bigVisibleRows:number}} ClownCarAppearance */

/** Appearance is independent of the motor, its passenger collider and timings.
 * Every real vehicle state uses the one recovered frame; no animation is made up.
 */
export const CLOWN_CAR_APPEARANCE=Object.freeze({
 id:'smm2-smb1-source-v1',frame:CLOWN_CAR_SOURCE.id,width:32,height:32,
 rimRows:4,smallVisibleRows:13,bigVisibleRows:18
});
const colors=CLOWN_CAR_SOURCE.palette.map(([r,g,b])=>`rgb(${r},${g},${b})`);

/** @param {ClownCarRenderView} car @returns {ClownCarVisualState} */
export function clownCarVisualState(car){
 if(car.occupancy==='npc')return car.npcPanic?.active?'npc-spike-panic':'npc-occupied';
 if(car.occupancy==='player')return Math.abs(car.vx||0)+Math.abs(car.vy||0)>.001?'player-moving':'player-rest';
 return 'empty-hover';
}

/** @param {ClownCarRenderView} car @param {ClownCarAppearance} appearance */
export function clownCarRenderBounds(car,appearance=CLOWN_CAR_APPEARANCE){
 if(appearance.frame!==CLOWN_CAR_SOURCE.id)throw Error('Clown Car frame is unavailable');
 return {x:Math.round(car.x+((car.w??32)-appearance.width)/2),y:Math.round(car.y+(car.h??28)-appearance.height),w:appearance.width,h:appearance.height};
}

function sourceRows(c,b,start,end){
 for(let y=start;y<end;y++){
  const row=CLOWN_CAR_SOURCE.rows[y];
  for(let x=0;x<32;){let right=x+1;while(right<32&&row[right]===row[x])right++;
   const index=Number(row[x]);if(index){c.fillStyle=colors[index];c.fillRect(b.x+x,b.y+y,right-x,1);}x=right;
  }
 }
}

/** Paint unchanged source pixels at native size, bottom anchored to the body. */
export function drawOriginalClownCar(c,car,appearance=CLOWN_CAR_APPEARANCE){
 const b=clownCarRenderBounds(car,appearance);sourceRows(c,b,0,32);return b;
}

/** This foreground pass reuses original rim rows; it is not a recovered layer. */
export function drawClownCarFrontRim(c,car,appearance=CLOWN_CAR_APPEARANCE){
 const b=clownCarRenderBounds(car,appearance),rows=appearance.rimRows;
 sourceRows(c,b,0,rows);
}

/** Resolve the actual occupant ID from the live view, never proximity or a guess. */
export function occupiedClownCar(cars,actor,player=false){
 return (cars||[]).find(car=>player
  ?car.occupancy==='player'&&car.occupantId==='player'&&actor?.vehicleId===car.id
  :car.occupancy==='npc'&&actor?.id!=null&&car.occupantId===actor.id)||null;
}

/** A rendering copy only. Its y/pose do not replace the actor or collision box. */
export function clownCarPassengerPose(car,actor,{player=false,appearance=CLOWN_CAR_APPEARANCE}={}){
 const b=clownCarRenderBounds(car,appearance);
 if(player){
  const big=!!(actor.shrink||actor.growth?Math.floor((actor.shrink||actor.growth)/4)%2:actor.power);
  const nativeHeight=big?32:16,visibleRows=big?appearance.bigVisibleRows:appearance.smallVisibleRows;
  return {...actor,x:b.x+(b.w-actor.w)/2,y:b.y-visibleRows+nativeHeight-actor.h,
   grounded:true,vx:0,vy:0,piping:true,climbing:false,swimming:false,crouch:false,springId:null};
 }
 // Existing NPC renderer owns its sprite/frame; its bottom six native body rows
 // sit inside the cup. For a Goomba this leaves the head/upper body above the rim.
 const visibleRows=Math.max(1,actor.h-6);
 return {...actor,x:b.x+(b.w-actor.w)/2,y:b.y-visibleRows};
}

/** Render a passenger through its existing native renderer, then restore the lip.
 * Clip at the rim even at transparent edge pixels so feet cannot leak outside.
 */
export function drawClownCarPassenger(c,car,actor,draw,{player=false,appearance=CLOWN_CAR_APPEARANCE}={}){
 const b=clownCarRenderBounds(car,appearance),pose=clownCarPassengerPose(car,actor,{player,appearance});
 c.save();c.beginPath();c.rect(b.x-64,b.y-128,b.w+128,128);c.clip();draw(pose);c.restore();
 drawClownCarFrontRim(c,car,appearance);return pose;
}

/** Exposed for pixel-identity verification without a browser image decoder. */
export function clownCarSourcePixels(){return {
 w:32,h:32,pixels:CLOWN_CAR_SOURCE.rows.flatMap(row=>[...row].map(index=>[...CLOWN_CAR_SOURCE.palette[Number(index)]]))
};}
