/** Pure render projection shared by gameplay and native Canvas recording.
 * Keep the authored room for source-ID art lookup, and expose owner views
 * without replacing authoring leaves or advancing any simulation controller.
 */
export function rendererRoom(authoredRoom={},view={},bounds){
 return {...authoredRoom,...(view.smm2Mechanics?.completionMarks!==undefined?{completionMarksView:view.smm2Mechanics.completionMarks}:{}),...(view.smm2Mechanics?.skyShooter?{skyShooterView:view.smm2Mechanics.skyShooter}:{}),...(view.smm2Mechanics?.arenaAudience?{arenaAudienceView:view.smm2Mechanics.arenaAudience}:{}),contraptionsView:view.contraptions,lakituCloudView:view.smm2Mechanics?.lakituClouds,conveyorView:view.conveyors,castleView:view.castle,liquidView:view.smm2Mechanics?.liquid,switchStudyView:view.switchStudy,marioModulesView:view.marioModules,goalCardView:view.smm2Mechanics?.goalCard,goalTapeView:view.smm2Mechanics?.goalTape,snakeBlockView:view.smm2Mechanics?.snakeBlocks,underwaterActorsView:view.smm2Mechanics?.underwaterActors,playGeometry:view.geometry,finish:view.finish,tick:view.tick,...(bounds?{renderBounds:bounds}:{})};
}
/** A thin semisolid's ornamental columns extend below its collision cap.
 * Visibility uses those display bounds without altering the physical body.
 */
export function rendererVisualBounds(q,room={}){
 if(room.smm2Mechanics?.art?.palette!=='smw-underwater-source')return q;
 const source=room.map?.geometry?.find(g=>g.id===(q.sourceId||q.id))??room.decorations?.find(g=>g.id===(q.sourceId||q.id))??q,tag=q.smm2Art??source.smm2Art;
 if(['smw-underwater-column-semisolid','smw-underwater-masonry-semisolid'].includes(tag))return{...q,h:q.h+Math.max(0,q.stemHeight??source.stemHeight??0)};
 // Native PNGs can be wider/taller than an actor's separately owned body.
 if(q.kind==='walker'||q.underwaterActor||q.smm2Thwomp)return{x:q.x-16,y:q.y-32,w:q.w+32,h:q.h+32};
 return q;
}
export function rendererVisible(q,room,bounds){
 const v=rendererVisualBounds(q,room);return v.x+v.w>=bounds.x&&v.x<=bounds.x+bounds.w&&v.y+v.h>=bounds.y&&v.y<=bounds.y+bounds.h;
}
