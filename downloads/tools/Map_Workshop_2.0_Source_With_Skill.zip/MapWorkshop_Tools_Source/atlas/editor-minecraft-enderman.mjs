/** Original 60 Hz, side-view adaptation of the wild Enderman encounter.
 * A FACE-level gaze must be held; a full stare screams and freezes the actor,
 * then breaking eye contact starts persistent anger. Standing facing the head uses a readable upward cone; Up explicitly aims.
 * This independent sidecar never owns geometry or alters the rail-repair helper.
 * Timing and movement are authored crossover rules, not Minecraft parameters.
 */
const EPS=1e-6;
const clone=q=>JSON.parse(JSON.stringify(q));
const finite=(n,min,max)=>Number.isFinite(n)&&n>=min&&n<=max;
const safeId=id=>typeof id==='string'&&id.length>0&&id.length<=100&&!['__proto__','constructor','prototype'].includes(id);
const solid=q=>q.collision==='solid'&&!q.hidden;
const overlap=(a,b)=>a.x+a.w>b.x+EPS&&a.x<b.x+b.w-EPS&&a.y+a.h>b.y+EPS&&a.y<b.y+b.h-EPS;
const centerX=q=>q.x+q.w/2;
const unsafeSurface=q=>/water|lava/i.test(q.material||q.kind||'');
const staticSupport=q=>solid(q)&&!q.motion&&!q.liftSpeed&&!unsafeSurface(q)&&Math.abs(q.dx||0)<EPS&&Math.abs(q.dy||0)<EPS;
const supportFor=(q,geometry)=>geometry.find(g=>staticSupport(g)&&g.x<=q.x+EPS&&g.x+g.w>=q.x+q.w-EPS&&Math.abs(g.y-q.y-q.h)<EPS);
export const WILD_ENDERMAN_RULES=Object.freeze({w:16,h:48,stareTicks:42,warningTicks:12,gazeRange:208,faceY:6.5,faceTolerance:7,upSlope:.25,teleportWindup:18,teleportGrace:36,teleportCooldown:150,teleportMinDistance:56,teleportMaxDistance:128,chaseSpeed:1.05,hitCooldown:54});
const R=WILD_ENDERMAN_RULES;
function record(q,keys,label){if(!q||typeof q!=='object'||Array.isArray(q)||![Object.prototype,null].includes(Object.getPrototypeOf(q)))throw Error('Invalid Minecraft wild Enderman '+label);for(const key of Object.keys(q))if(!safeId(key)||!keys.includes(key))throw Error('Unknown Minecraft wild Enderman '+label+' field: '+key);}
function otherIds(room){const ids=new Set([...room.map.geometry,...room.map.objects,...(room.markers||[]),...(room.decorations||[])].map(q=>q.id));const scan=q=>{if(!q||typeof q!=='object')return;if(safeId(q.id))ids.add(q.id);for(const value of Object.values(q))if(value&&typeof value==='object')scan(value);};for(const [key,value]of Object.entries(room.minecraft||{}))if(key!=='wildEnderman')scan(value);return ids;}
function hazardsFor(room,geometry){return [...room.map.objects,...geometry].filter(q=>!q.hidden&&(q.kind==='hazard'||unsafeSurface(q)));}
function safePlacement(q,room,geometry){return finite(q.x,0,room.map.width-q.w)&&finite(q.y,0,room.map.height-q.h)&&!!supportFor(q,geometry)&&!geometry.some(g=>solid(g)&&overlap(q,g))&&!hazardsFor(room,geometry).some(g=>overlap({...q,x:q.x-2,y:q.y-2,w:q.w+4,h:q.h+4},g));}
/** Strict additive schema. A whole 16px footprint needs dry, static support. */
export function validateWildEnderman(spec,room){
 if(spec===undefined)return;record(spec,['version','actors'],'room');const map=room?.map;
 if(spec.version!==1||room.underwater||room.setting==='Underwater'||!map||!finite(map.width,64,32768)||!finite(map.height,64,4096)||!Array.isArray(map.geometry)||!Array.isArray(map.objects)||!Array.isArray(spec.actors)||spec.actors.length>8)throw Error('Invalid Minecraft wild Enderman room');
 const ids=otherIds(room),boxes=[];for(const authored of spec.actors){record(authored,['id','x','y'],'actor');const q={...authored,w:R.w,h:R.h};if(!safeId(q.id)||ids.has(q.id)||!safePlacement(q,room,map.geometry)||boxes.some(b=>overlap(q,b)))throw Error('Minecraft wild Enderman needs unique ID and dry supported clear placement');ids.add(q.id);boxes.push(q);}
}
/** Exact segment/rectangle test catches even one-pixel occluders. */
function segmentHits(a,b,q){let enter=0,leave=1;for(const [axis,size]of [['x','w'],['y','h']]){const d=b[axis]-a[axis],lo=q[axis],hi=lo+q[size];if(Math.abs(d)<EPS){if(a[axis]<=lo+EPS||a[axis]>=hi-EPS)return false;continue;}let t0=(lo-a[axis])/d,t1=(hi-a[axis])/d;if(t0>t1)[t0,t1]=[t1,t0];enter=Math.max(enter,t0);leave=Math.min(leave,t1);if(enter>leave-EPS)return false;}return leave>EPS&&enter<1-EPS;}
function clearLine(a,b,geometry){return !geometry.some(g=>solid(g)&&segmentHits(a,b,g));}
/** Looking toward a torso or through a wall is not face-level eye contact. */
export function endermanFaceGaze(actor,player,input={},geometry=[]){
 if(!player||player.dead||player.dying||input.down||player.crouch||actor.visible===false)return false;
 const from={x:centerX(player),y:player.y+Math.min(7,player.h*.25)},to={x:centerX(actor),y:actor.y+R.faceY},dx=to.x-from.x,facing=input.x?Math.sign(input.x):Math.sign(player.facing||1);
 if(dx*facing<=0||Math.abs(dx)>R.gazeRange||Math.abs(dx)<8)return false;
 if(!input.up&&Math.abs(player.vx||0)>.35)return false;
 const rayY=from.y-(input.up?Math.abs(dx)*R.upSlope:0),tolerance=input.up?R.faceTolerance:Math.min(30,Math.max(23,R.faceTolerance+Math.abs(dx)*.42));
 return Math.abs(rayY-to.y)<=tolerance&&clearLine(from,to,geometry);
}
/** Relative swept contact, so ordinary fast movement cannot tunnel through. */
function contact(a0,a1,b0,b1){let enter=0,leave=1;for(const [axis,size]of [['x','w'],['y','h']]){const p=a0[axis]-b0[axis],d=(a1[axis]-a0[axis])-(b1[axis]-b0[axis]),lo=-a0[size],hi=b0[size];if(Math.abs(d)<EPS){if(p<=lo+EPS||p>=hi-EPS)return false;continue;}let t0=(lo-p)/d,t1=(hi-p)/d;if(t0>t1)[t0,t1]=[t1,t0];enter=Math.max(enter,t0);leave=Math.min(leave,t1);if(enter>leave+EPS)return false;}return enter>=-EPS&&enter<=1+EPS;}
export function createWildEndermanController(room,{emit=()=>{},hurtPlayer=()=>{},defend=hit=>({damage:hit.damage??1})}={}){
 const authored=room?.minecraft?.wildEnderman;if(authored===undefined)return null;validateWildEnderman(authored,room);const spec=clone(authored);
 let actors,effects,age,lastTick,currentTick,paused,disposed,previousPlayer,lastPlayer,lastGeometry;
 const event=(name,data={})=>emit('minecraft',{event:name,roomId:room.roomId,tick:currentTick,...data});
 const sound=event=>emit('sound',{event});
 function reset(){actors=spec.actors.map(q=>({...q,w:R.w,h:R.h,vx:0,vy:0,facing:-1,age:0,stateAge:0,state:'calm',hp:4,dead:false,stareTicks:0,angry:false,visible:true,grounded:true,gazing:false,hitCooldown:0,teleportCooldown:0,teleportTicks:0,graceTicks:0,teleportFrom:null,teleportCue:null,teleportFlash:0,blockedTicks:0,stranded:false}));effects=[];age=0;lastTick=-1;currentTick=0;paused=disposed=false;previousPlayer=null;lastPlayer=null;lastGeometry=room.map.geometry;}
 function state(q,next){if(q.state!==next){q.state=next;q.stateAge=0;}}
 function safeTarget(q,p,geometry){
  const side=Math.sign(centerX(q)-centerX(p))||1,distances=[56,64,80,96,112,128],candidates=[];
  for(const sign of [side,-side])for(const distance of distances){const x=centerX(p)+sign*distance-R.w/2;for(const floor of geometry){if(!staticSupport(floor)||Math.abs(floor.y-p.y-p.h)>64)continue;const target={x,y:floor.y-R.h,w:R.w,h:R.h};if(Math.abs(target.x-q.x)<24&&Math.abs(target.y-q.y)<16)continue;if(!safePlacement(target,room,geometry)||overlap(target,{...p,x:p.x-32,y:p.y-8,w:p.w+64,h:p.h+16})||actors.some(a=>a.id!==q.id&&a.visible&&overlap(a,target)))continue;candidates.push({...target,supportId:floor.id});}}
  return candidates[0]||null;
 }
 function beginTeleport(q,p,geometry){const target=safeTarget(q,p,geometry);if(!target){q.teleportCue=null;q.teleportCooldown=30;return false;}q.teleportCue=target;q.teleportTicks=R.teleportWindup;q.vx=0;state(q,'teleporting');event('wild-enderman-teleport-warning',{actorId:q.id,x:target.x,y:target.y,ticks:R.teleportWindup});return true;}
 function teleport(q,p,geometry){
  const target=q.teleportCue,min=R.teleportMinDistance,max=R.teleportMaxDistance,distance=target&&Math.abs(centerX(target)-centerX(p));
  if(!target||!safePlacement(target,room,geometry)||distance<min||distance>max||overlap(target,{...p,x:p.x-32,y:p.y-8,w:p.w+64,h:p.h+16})||actors.some(a=>a.id!==q.id&&a.visible&&overlap(a,target))){q.teleportCue=null;q.teleportCooldown=30;state(q,'blocked');event('wild-enderman-teleport-cancelled',{actorId:q.id});return false;}
  q.teleportFrom={x:q.x,y:q.y,w:q.w,h:q.h};effects.push({kind:'enderman-teleport-depart',...q.teleportFrom,age:0,life:24},{kind:'enderman-teleport-arrive',x:target.x,y:target.y,w:q.w,h:q.h,age:0,life:24});q.x=target.x;q.y=target.y;q.visible=q.grounded=true;q.stranded=false;q.teleportCue=null;q.teleportFlash=24;q.teleportCooldown=R.teleportCooldown;q.graceTicks=R.teleportGrace;q.blockedTicks=0;state(q,'grace');sound('mc-enderman-teleport');event('wild-enderman-teleported',{actorId:q.id,x:q.x,y:q.y,supportId:target.supportId,graceTicks:q.graceTicks});return true;
 }
 function anger(q,p,geometry){q.angry=true;q.stareTicks=R.stareTicks;q.graceTicks=R.teleportGrace;q.teleportCooldown=0;sound('mc-enderman-aggro');event('wild-enderman-angered',{actorId:q.id});if(!beginTeleport(q,p,geometry))state(q,'chase');}
 function move(q,p,geometry){
  const dx=centerX(p)-centerX(q);q.facing=Math.sign(dx)||q.facing;const speed=Math.sign(dx)*Math.min(R.chaseSpeed,Math.abs(dx)),next={...q,x:q.x+speed};q.vx=0;
  // Full-height clearance and full-foot support make a 32px refuge genuinely
  // impassable. There is no invulnerability zone and no added player collider.
  if(safePlacement(next,room,geometry)){q.x=next.x;q.vx=speed;q.blockedTicks=0;state(q,'chase');}else{q.blockedTicks++;state(q,'blocked');}
 }
 function step({tick,input={},player,geometry=room.map.geometry}={}){
  if(paused||disposed)return {geometry};const next=Number.isInteger(tick)?tick:lastTick+1;if(next<=lastTick)return {geometry};lastTick=currentTick=next;lastPlayer=player;lastGeometry=geometry;age++;effects=effects.filter(q=>++q.age<q.life);
  const active=!!player&&!player.dead&&!player.dying;for(const q of actors){if(q.dead)continue;q.age++;q.stateAge++;if(q.hitCooldown)q.hitCooldown--;if(q.teleportCooldown)q.teleportCooldown--;if(q.teleportFlash)q.teleportFlash--;if(q.graceTicks)q.graceTicks--;const before={...q};q.vx=0;
   const supported=safePlacement(q,room,geometry);q.grounded=supported;if(!supported){q.stranded=true;q.visible=false;}else if(q.stranded){q.stranded=false;q.visible=true;}
   if(!active){q.gazing=false;if(!q.angry&&q.state!=='stared'){q.stareTicks=0;state(q,'calm');}continue;}
   q.gazing=endermanFaceGaze(q,player,input,geometry);
   if(!q.angry){
    if(q.state==='stared'){if(!q.gazing)anger(q,player,geometry);continue;}
    if(q.gazing){q.stareTicks++;q.facing=Math.sign(centerX(player)-centerX(q))||q.facing;state(q,'watching');if(q.stareTicks===R.warningTicks){sound('mc-enderman-warning');event('wild-enderman-stare-warning',{actorId:q.id,stareTicks:q.stareTicks});}if(q.stareTicks>=R.stareTicks){q.stareTicks=R.stareTicks;state(q,'stared');sound('mc-enderman-stare');event('wild-enderman-stared',{actorId:q.id,stareTicks:q.stareTicks});}}
    else{if(q.stareTicks>=R.warningTicks)event('wild-enderman-stare-broken',{actorId:q.id});q.stareTicks=0;state(q,'calm');}continue;
   }
   if(q.state==='teleporting'){if(--q.teleportTicks<=0)teleport(q,player,geometry);continue;}
   if(q.graceTicks>0){state(q,'grace');continue;}
   if(!q.teleportCooldown&&(q.stranded||Math.abs(centerX(player)-centerX(q))>176||q.blockedTicks>=45)){if(beginTeleport(q,player,geometry))continue;}
   if(q.stranded){state(q,'blocked');continue;}move(q,player,geometry);
   if(!q.hitCooldown&&contact(previousPlayer||player,player,before,q)&&clearLine({x:centerX(q),y:q.y+q.h*.65},{x:centerX(player),y:player.y+player.h*.5},geometry)){
    q.hitCooldown=R.hitCooldown;const defended=defend({player,sourceX:centerX(q),kind:'wild-enderman',damage:1,reflectable:false})||{},damage=finite(defended.damage,0,100)?defended.damage:1;if(damage>0)hurtPlayer({kind:'wild-enderman',actorId:q.id,damage});sound('mc-enderman-attack');event('wild-enderman-contact',{actorId:q.id,damage,blocked:!!defended.blocked,parried:!!defended.parried});
    if(defended.parried){q.graceTicks=24;state(q,'grace');}
   }
  }
  previousPlayer=active?{x:player.x,y:player.y,w:player.w,h:player.h,vy:player.vy}:null;return {geometry};
 }
 function view(){return clone({active:!disposed,age,actors:actors.map(q=>({...q,phase:q.state,warning:q.stareTicks/R.stareTicks,screaming:q.state==='stared'||q.angry,shaking:q.state==='stared'||q.angry})),effects});}
 function rangedTargets(){return actors.filter(q=>!q.dead&&q.visible).map(q=>({id:q.id,kind:'wild-enderman',x:q.x,y:q.y,w:q.w,h:q.h}));}
 function receiveRangedHit(hit){const q=actors.find(q=>q.id===hit.targetId&&!q.dead);if(paused||disposed||!q||!lastPlayer)return false;if(hit.kind==='loyalty-trident'){if(beginTeleport(q,lastPlayer,lastGeometry)){teleport(q,lastPlayer,lastGeometry);event('wild-enderman-projectile-evaded',{actorId:q.id});}return true;}if(hit.kind!=='sword')return false;if(!q.angry)anger(q,lastPlayer,lastGeometry);q.hp=Math.max(0,q.hp-.5);sound('mc-enderman-attack');event('wild-enderman-melee-hit',{actorId:q.id,hp:q.hp});if(!q.hp){q.dead=true;q.visible=false;q.angry=false;state(q,'defeated');event('wild-enderman-defeated',{actorId:q.id});}return true;}
 reset();return Object.freeze({step,view,reset,rangedTargets,receiveRangedHit,pause(value=true){paused=!!value;previousPlayer=null;},dispose(){disposed=true;effects=[];previousPlayer=null;}});
}
