import {clone,validate} from './editor-model.mjs';
import {validatePortableStones} from './editor-portable-stones.mjs';
import {validateLocalUpdrafts} from './editor-local-updrafts.mjs';
import {validateParachuteActors} from './editor-parachute-actors.mjs';

const stoneFields=['gravity','maxFallSpeed','throwSpeedX','throwSpeedY','releaseSafeFrames','heldOffsetX','heldBottomOffset','carryMotion','points'];
const carryFields=['walkCap','runCap','airCap','jumpSpeed','jumpGravity','fallGravity'];
const twisterFields=['speed','direction','windHeight','visualHeight','bottomHalfWidth','topHalfWidth','riseAcceleration','maxRiseSpeed'];
const parachuteFields=['variant','fallSpeed','oscillation','activation'];
const oscillationFields=['amplitude','periodFrames','phaseFrames'];
const nativeGoomba=value=>typeof value==='string'&&value.replace(/^(?:enemy-|marker-)/,'').toLowerCase()==='goomba';
const plain=q=>q&&typeof q==='object'&&!Array.isArray(q)&&[Object.prototype,null].includes(Object.getPrototypeOf(q));
function fields(q,allowed,label){if(!plain(q)||Object.keys(q).some(k=>!allowed.includes(k)||['__proto__','prototype','constructor'].includes(k)))throw Error('Invalid '+label+' fields');}
function edit(room,fn){const next=clone(room);fn(next);validate({format:'xiaoq-map-project',version:1,id:'heavy-stone-authoring-check',title:'Stone and local updraft authoring',rooms:[next]},{allowIncompleteCompletionMarks:true});for(const key of Object.keys(room))if(!Object.hasOwn(next,key))delete room[key];Object.assign(room,next);}
function mechanics(room){room.smm2Mechanics??={version:1};return room.smm2Mechanics;}
function requireBody(room,id,kind){
 const source=room.map.objects.find(q=>q.id===id);
 if(!source||source.kind!=='walker'||source.w!==16||source.h!==16)throw Error('请选择已有 16×16 原生 walker 对象');
 const s=room.smm2Mechanics;
 if(s?.parachuteActors?.actors.some(q=>q.id===id))throw Error('此原生对象已绑定降落伞');
 if(kind!=='stone'&&s?.portableStones?.stones.some(q=>q.id===id)||kind!=='twister'&&s?.localUpdrafts?.twisters.some(q=>q.id===id))throw Error('同一原生对象不能同时绑定石材与局部龙卷风');
 for(const key of ['thwomps','powBlocks','pSwitches','helmets','skewers','placedItems','shoes','boneShells'])if(s?.[key]?.some(q=>q.id===id))throw Error('此原生对象已绑定其他实体机关');
 if(room.marioModules?.enemyVariants?.[id])throw Error('此原生对象已绑定敌人变体');
}
function emptyLeaves(room){const s=room.smm2Mechanics;if(!s)return;if(s.portableStones&&!s.portableStones.stones.length&&!s.portableStones.clearCondition)delete s.portableStones;if(s.localUpdrafts&&!s.localUpdrafts.twisters.length)delete s.localUpdrafts;if(s.parachuteActors&&!s.parachuteActors.actors.length)delete s.parachuteActors;}

/** Complete explicit tuning only. The source walker and its native ID stay put. */
export function setPortableStone(room,id,options){
 fields(options,stoneFields,'portable stone authoring');
 fields(options.carryMotion,carryFields,'stone carry motion');
 edit(room,r=>{requireBody(r,id,'stone');const s=mechanics(r),leaf=s.portableStones??={version:1,stones:[]};const value={...clone(options),id};const index=leaf.stones.findIndex(q=>q.id===id);if(index<0)leaf.stones.push(value);else leaf.stones[index]=value;validatePortableStones(r);});
}
export function removePortableStone(room,id){
 if(!room.smm2Mechanics?.portableStones?.stones.some(q=>q.id===id))return;
 edit(room,r=>{const leaf=r.smm2Mechanics.portableStones;leaf.stones=leaf.stones.filter(q=>q.id!==id);if(!leaf.stones.length)delete leaf.clearCondition;emptyLeaves(r);});
}
/** The gate qualifies actual contact with one existing native exit. */
export function setCarryStoneClearCondition(room,goalId){
 if(goalId===null)return clearCarryStoneClearCondition(room);
 edit(room,r=>{const leaf=r.smm2Mechanics?.portableStones;if(!leaf?.stones.length)throw Error('请先绑定至少一个真实石材对象');leaf.clearCondition={kind:'carry-stone',goalId};validatePortableStones(r);});
}
export function clearCarryStoneClearCondition(room){if(!room.smm2Mechanics?.portableStones?.clearCondition)return;edit(room,r=>{delete r.smm2Mechanics.portableStones.clearCondition;emptyLeaves(r);});}
export function setLocalTwister(room,id,options){
 fields(options,twisterFields,'local Twister authoring');
 edit(room,r=>{requireBody(r,id,'twister');const s=mechanics(r),leaf=s.localUpdrafts??={version:1,twisters:[]},value={...clone(options),id},index=leaf.twisters.findIndex(q=>q.id===id);if(index<0)leaf.twisters.push(value);else leaf.twisters[index]=value;validateLocalUpdrafts(r);});
}
export function removeLocalTwister(room,id){if(!room.smm2Mechanics?.localUpdrafts?.twisters.some(q=>q.id===id))return;edit(room,r=>{r.smm2Mechanics.localUpdrafts.twisters=r.smm2Mechanics.localUpdrafts.twisters.filter(q=>q.id!==id);emptyLeaves(r);});}

/** Canopies decorate the existing ordinary actor. Mushroom physics/reward
 * remain in placedItems; binding a Goomba never rewrites its enemy identity. */
export function setParachuteActor(room,id,options){
 fields(options,parachuteFields,'parachute authoring');fields(options.oscillation,oscillationFields,'parachute oscillation');fields(options.activation,['kind'],'parachute activation');
 edit(room,r=>{const source=r.map.objects.find(q=>q.id===id);if(options.variant==='goomba'&&!nativeGoomba(r.enemySkins?.[id]??source?.type))throw Error('Goomba 降落伞需要已有原生 Goomba 类型或外观；不会自动改写敌人身份');const s=mechanics(r),leaf=s.parachuteActors??={version:1,actors:[]},value={...clone(options),id},index=leaf.actors.findIndex(q=>q.id===id);if(index<0)leaf.actors.push(value);else leaf.actors[index]=value;validateParachuteActors(r);});
}
export function removeParachuteActor(room,id){if(!room.smm2Mechanics?.parachuteActors?.actors.some(q=>q.id===id))return;edit(room,r=>{r.smm2Mechanics.parachuteActors.actors=r.smm2Mechanics.parachuteActors.actors.filter(q=>q.id!==id);emptyLeaves(r);});}

/** Remove only references to bodies actually deleted in this native edit.
 * Newly introduced invalid references must still fail the enclosing History. */
export function pruneHeavyStoneReferences(room,before){
 if(!before)return;const now=new Set(room.map.objects.map(q=>q.id)),removed=new Set(before.map.objects.filter(q=>!now.has(q.id)).map(q=>q.id)),s=room.smm2Mechanics;if(!s)return;
 if(!removed.size)return;
 if(s.portableStones){const leaf=s.portableStones,prior=before.smm2Mechanics?.portableStones?.clearCondition,count=leaf.stones.length;leaf.stones=leaf.stones.filter(q=>!removed.has(q.id));const deletedStone=count!==leaf.stones.length;if(leaf.clearCondition&&prior?.kind===leaf.clearCondition.kind&&prior.goalId===leaf.clearCondition.goalId&&(removed.has(prior.goalId)||deletedStone&&!leaf.stones.length))delete leaf.clearCondition;if(deletedStone&&!leaf.stones.length&&!leaf.clearCondition)delete s.portableStones;}
 if(s.localUpdrafts){const count=s.localUpdrafts.twisters.length;s.localUpdrafts.twisters=s.localUpdrafts.twisters.filter(q=>!removed.has(q.id));if(count!==s.localUpdrafts.twisters.length&&!s.localUpdrafts.twisters.length)delete s.localUpdrafts;}
 if(s.parachuteActors){const count=s.parachuteActors.actors.length;s.parachuteActors.actors=s.parachuteActors.actors.filter(q=>!removed.has(q.id));if(count!==s.parachuteActors.actors.length&&!s.parachuteActors.actors.length)delete s.parachuteActors;}
 for(const q of before.smm2Mechanics?.parachuteActors?.actors||[])if(q.variant==='goomba'&&removed.has(q.id)&&room.enemySkins)delete room.enemySkins[q.id];
}
/** This snapshot is deliberately separate from existing actor sidecars. */
export function captureHeavyStoneBindings(room,ids){
 validatePortableStones(room);validateLocalUpdrafts(room);validateParachuteActors(room);
 const stones=clone((room.smm2Mechanics?.portableStones?.stones||[]).filter(q=>ids.has(q.id))),twisters=clone((room.smm2Mechanics?.localUpdrafts?.twisters||[]).filter(q=>ids.has(q.id))),condition=room.smm2Mechanics?.portableStones?.clearCondition;
 const parachutes=clone((room.smm2Mechanics?.parachuteActors?.actors||[]).filter(q=>ids.has(q.id))),parachuteSkins=Object.fromEntries(parachutes.filter(q=>q.variant==='goomba'&&Object.hasOwn(room.enemySkins||{},q.id)).map(q=>[q.id,room.enemySkins[q.id]]));
 return {stones,twisters,parachutes,parachuteSkins,...(condition&&stones.length&&ids.has(condition.goalId)?{clearCondition:clone(condition)}:{})};
}
/** Body paste and sidecars share one native History transaction. A room has one
 * carry-stone gate, so pasting a second distinct gate is an explicit error. */
export function appendCopiedHeavyStoneBindings(room,snapshot,idMap){
 if(snapshot==null)return;fields(snapshot,['stones','twisters','parachutes','parachuteSkins','clearCondition'],'heavy stone clipboard');
 if(!Array.isArray(snapshot.stones)||!Array.isArray(snapshot.twisters)||snapshot.parachutes!==undefined&&!Array.isArray(snapshot.parachutes)||!(idMap instanceof Map))throw Error('Invalid heavy stone clipboard');
 fields(snapshot.parachuteSkins===undefined?{}:snapshot.parachuteSkins,(snapshot.parachutes||[]).filter(q=>q.variant==='goomba').map(q=>q.id),'copied Goomba skins');
 if(!snapshot.stones.length&&!snapshot.twisters.length&&!snapshot.parachutes?.length&&!snapshot.clearCondition)return;
 edit(room,r=>{
  for(const [key,list,kind]of [['portableStones','stones','stone'],['localUpdrafts','twisters','twister']])for(const q of snapshot[list]){
   fields(q,['id',...(kind==='stone'?stoneFields:twisterFields)],'copied '+kind);if(kind==='stone')fields(q.carryMotion,carryFields,'copied stone carry motion');
   const id=idMap.get(q.id);if(!id||id===q.id)throw Error('复制机关缺少新的原生对象 ID');requireBody(r,id,kind);const s=mechanics(r),leaf=s[key]??={version:1,[list]:[]};leaf[list].push({...clone(q),id});
  }
  for(const q of snapshot.parachutes||[]){
   fields(q,['id',...parachuteFields],'copied parachute');fields(q.oscillation,oscillationFields,'copied parachute oscillation');fields(q.activation,['kind'],'copied parachute activation');
   const id=idMap.get(q.id);if(!id||id===q.id)throw Error('复制降落伞缺少新的原生对象 ID');const skin=snapshot.parachuteSkins?.[q.id];if(skin!==undefined){if(!nativeGoomba(skin))throw Error('复制降落伞不能改写 Goomba 身份');(r.enemySkins??={})[id]=skin;}
   const s=mechanics(r),leaf=s.parachuteActors??={version:1,actors:[]};leaf.actors.push({...clone(q),id});
  }
  if(snapshot.clearCondition){
   fields(snapshot.clearCondition,['kind','goalId'],'copied carry-stone clear condition');
   const goalId=idMap.get(snapshot.clearCondition.goalId);if(snapshot.clearCondition.kind!=='carry-stone'||!goalId||goalId===snapshot.clearCondition.goalId||!snapshot.stones.length||!snapshot.stones.some(q=>idMap.has(q.id)))throw Error('复制搬运过关条件必须同时复制真实终点与石材');
   const leaf=r.smm2Mechanics.portableStones;if(leaf.clearCondition&&leaf.clearCondition.goalId!==goalId)throw Error('目标区域已有搬运石材终点；请先移除该条件再粘贴终点组');leaf.clearCondition={kind:'carry-stone',goalId};
  }
 });
}

const stoneInputs=[['gravity','石材重力',0,64],['maxFallSpeed','最大下落速度',.001,256],['throwSpeedX','水平投掷速度',0,256],['throwSpeedY','投掷竖向速度',-256,0],['releaseSafeFrames','释放后拾取等待帧',0,36000],['heldOffsetX','手持水平间距',0,256],['heldBottomOffset','手持底部偏移',-256,256],['points','击败 Goomba 分数（可留空）',0,100000]];
const carryInputs=[['walkCap','搬运步速上限',0,256],['runCap','搬运跑速上限',0,256],['airCap','搬运空中速度上限',0,256],['jumpSpeed','搬运起跳速度',.001,256],['jumpGravity','搬运上升重力',0,64],['fallGravity','搬运下降重力',0,64]];
const twisterInputs=[['speed','平地行走速度',.001,4],['windHeight','有效风场高度',16,512],['visualHeight','可见粒子高度（可留空）',16,512],['bottomHalfWidth','风场底部半宽',1,64],['topHalfWidth','风场顶部半宽',1,128],['riseAcceleration','玩家上升加速度',.001,4],['maxRiseSpeed','最大上升速度',.01,16]];
const parachuteInputs=[['fallSpeed','开伞下落速度',.001,64],['amplitude','横向振荡幅度',0,256],['periodFrames','振荡周期帧数',4,36000],['phaseFrames','初始振荡相位（帧）',0,36000]];
const input=(prefix,[key,label,min,max])=>'<label>'+label+'<input type="number" step="any" min="'+min+'" max="'+max+'" data-heavy-stone="'+prefix+key+'"></label>';

/** Existing bodies are selected by stable native IDs. Blank unbound tuning is
 * deliberate: no physical or carry coefficient is inferred from artwork. */
export function mountHeavyStoneTools({parent,room,selected=()=>new Set(),change,report=()=>{}}){
 const panel=document.createElement('details');parent.append(panel);
 const baseMarkup='<summary>石材、局部龙卷风与降落伞</summary><p class="small">绑定已有 16×16 walker；不创建第二个实体。运动、搬运与风场数值均为作者配置，未声明原版物理校准。局部龙卷风仅支持已观察的平地行走与玩家升力。</p><label>真实石材对象 ID<select data-heavy-stone="stone"></select></label>'+stoneInputs.map(q=>input('stone-',q)).join('')+carryInputs.map(q=>input('carry-',q)).join('')+'<button type="button" data-heavy-stone="stone-apply">绑定 / 更新石材</button><button type="button" data-heavy-stone="stone-remove">移除石材绑定</button><label>真实终点 ID<select data-heavy-stone="goal"></select></label><button type="button" data-heavy-stone="goal-apply">接触此终点时必须手持石材</button><button type="button" data-heavy-stone="goal-remove">移除搬运过关条件</button><label>真实局部龙卷风对象 ID<select data-heavy-stone="twister"></select></label><label>初始行走方向<select data-heavy-stone="twister-direction"><option value="-1">向左</option><option value="1">向右</option></select></label>'+twisterInputs.map(q=>input('twister-',q)).join('')+'<button type="button" data-heavy-stone="twister-apply">绑定 / 更新局部龙卷风</button><button type="button" data-heavy-stone="twister-remove">移除局部龙卷风绑定</button><p class="small" data-heavy-stone="status"></p>';
 panel.innerHTML=baseMarkup+'<p class="small">降落伞绑定已有普通 Goomba 或预置 Mushroom。下落速度、振荡与启用方式都是作者拟定；原版启动边界和完整运动参数未取得。</p><label>真实降落伞对象 ID<select data-heavy-stone="parachute"></select></label><label>已有普通实体类型<select data-heavy-stone="parachute-variant"><option value="goomba">Goomba</option><option value="super-mushroom">Super Mushroom</option></select></label>'+parachuteInputs.map(q=>input('parachute-',q)).join('')+'<label>启用方式<select data-heavy-stone="parachute-activation"><option value="frame-in-view">首次进入实际画面</option><option value="room-entry">进入区域</option></select></label><button type="button" data-heavy-stone="parachute-apply">绑定 / 更新降落伞</button><button type="button" data-heavy-stone="parachute-remove">移除降落伞绑定</button>';
 const get=key=>panel.querySelector('[data-heavy-stone="'+key+'"]'),number=(key,optional=false)=>{const raw=String(get(key).value).trim();if(!raw){if(optional)return undefined;throw Error('请填写作者参数 '+key);}return Number(raw);},attempt=fn=>{try{change(fn);}catch(e){report(e.message);}refresh();};
 let lastRoom=null,lastSelection='';
 get('stone-apply').onclick=()=>attempt(()=>{const values={};for(const [key]of stoneInputs){const n=number('stone-'+key,key==='points');if(n!==undefined)values[key]=n;}values.carryMotion=Object.fromEntries(carryFields.map(key=>[key,number('carry-'+key)]));setPortableStone(room(),get('stone').value,values);});
 get('stone-remove').onclick=()=>attempt(()=>removePortableStone(room(),get('stone').value));
 get('goal-apply').onclick=()=>attempt(()=>setCarryStoneClearCondition(room(),get('goal').value));get('goal-remove').onclick=()=>attempt(()=>clearCarryStoneClearCondition(room()));
 get('twister-apply').onclick=()=>attempt(()=>{const values={direction:number('twister-direction')};for(const [key]of twisterInputs){const n=number('twister-'+key,key==='visualHeight');if(n!==undefined)values[key]=n;}setLocalTwister(room(),get('twister').value,values);});
 get('twister-remove').onclick=()=>attempt(()=>removeLocalTwister(room(),get('twister').value));
 get('parachute-apply').onclick=()=>attempt(()=>setParachuteActor(room(),get('parachute').value,{variant:get('parachute-variant').value,fallSpeed:number('parachute-fallSpeed'),oscillation:{amplitude:number('parachute-amplitude'),periodFrames:number('parachute-periodFrames'),phaseFrames:number('parachute-phaseFrames')},activation:{kind:get('parachute-activation').value}}));
 get('parachute-remove').onclick=()=>attempt(()=>removeParachuteActor(room(),get('parachute').value));
 for(const key of ['stone','twister','goal','parachute'])get(key).onchange=()=>refresh();
 function fill(key,rows,pick){const node=get(key);node.replaceChildren(...rows.map(q=>{const option=document.createElement('option');option.value=q.id;option.textContent=q.id;return option;}));node.value=rows.some(q=>q.id===pick)?pick:rows[0]?.id||'';}
 function refresh(){
  const r=room(),ids=selected(),roomChanged=lastRoom!==r.roomId,selection=[...ids].sort().join('|'),selectionChanged=roomChanged||selection!==lastSelection,walkers=r.map.objects.filter(q=>q.kind==='walker'&&q.w===16&&q.h===16),goals=r.map.objects.filter(q=>q.kind==='exit'),s=r.smm2Mechanics,stoneLeaf=s?.portableStones,twisterLeaf=s?.localUpdrafts,parachuteLeaf=s?.parachuteActors;
  const pick=rows=>selectionChanged&&ids.size===1&&rows.some(q=>ids.has(q.id))?[...ids][0]:null;
  fill('stone',walkers,pick(walkers)||(roomChanged?stoneLeaf?.stones[0]?.id:get('stone').value));fill('twister',walkers,pick(walkers)||(roomChanged?twisterLeaf?.twisters[0]?.id:get('twister').value));fill('goal',goals,pick(goals)||(roomChanged?stoneLeaf?.clearCondition?.goalId:get('goal').value));
  fill('parachute',walkers,pick(walkers)||(roomChanged?parachuteLeaf?.actors[0]?.id:get('parachute').value));
  lastRoom=r.roomId;lastSelection=selection;
  const stone=stoneLeaf?.stones.find(q=>q.id===get('stone').value),twister=twisterLeaf?.twisters.find(q=>q.id===get('twister').value);
  for(const [key]of stoneInputs)get('stone-'+key).value=stone?.[key]===undefined?'':String(stone[key]);for(const key of carryFields)get('carry-'+key).value=stone?.carryMotion?.[key]===undefined?'':String(stone.carryMotion[key]);for(const [key]of twisterInputs)get('twister-'+key).value=twister?.[key]===undefined?'':String(twister[key]);get('twister-direction').value=String(twister?.direction??-1);
  const parachute=parachuteLeaf?.actors.find(q=>q.id===get('parachute').value);get('parachute-variant').value=parachute?.variant??'goomba';get('parachute-activation').value=parachute?.activation.kind??'frame-in-view';for(const [key]of parachuteInputs){const value=key==='fallSpeed'?parachute?.fallSpeed:parachute?.oscillation[key];get('parachute-'+key).value=value===undefined?'':String(value);}get('parachute-apply').disabled=!walkers.length;get('parachute-remove').disabled=!parachute;
  get('stone-apply').disabled=!walkers.length;get('stone-remove').disabled=!stone;get('twister-apply').disabled=!walkers.length;get('twister-remove').disabled=!twister;get('goal-apply').disabled=!goals.length||!stoneLeaf?.stones.length;get('goal-remove').disabled=!stoneLeaf?.clearCondition;
  get('status').textContent='已绑定石材 '+(stoneLeaf?.stones.length??0)+' 个，局部龙卷风 '+(twisterLeaf?.twisters.length??0)+' 个，降落伞 '+(parachuteLeaf?.actors.length??0)+' 个；'+(stoneLeaf?.clearCondition?'手持石材门禁：'+stoneLeaf.clearCondition.goalId:'搬运过关条件关闭');
 }
 refresh();return {refresh};
}
