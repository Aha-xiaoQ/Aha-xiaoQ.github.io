/** Finite SMB3 Desert artwork shared by editor, browser and native Canvas.
 * Exact acquired sprites use immutable source palette/rows. Scenery, diagonal
 * rims, shadows and additional animation poses are documented adaptations in
 * assets/heavy-stone-source/NOTICE.md. No physics, rewards or state writes. */
import {HEAVY_STONE_SOURCE_PIXELS as S} from './editor-heavy-stone-source-pixels.mjs';
import {WALKING_KOOPA_SOURCE_ASSETS} from './editor-walking-koopa-art.mjs';
const finite=Number.isFinite;
const valid=q=>q&&['x','y','w','h'].every(k=>finite(q[k]))&&q.w>0&&q.h>0;
const visible=q=>q&&!q.hidden&&q.visible!==false&&!q.removed&&!q.dead&&!q.taken;
const mod=(x,n)=>((x%n)+n)%n;
const P=Object.freeze({ink:'#000000',marioInk:'#1f1f1f',sand:'#ffaa47',light:'#ffd9b2',sky:'#f7c3b0',cloud:'#fbeeeb',mint:'#c1f2dd',shadow:'#725849',palm:'#7dba45',palmLight:'#c5df76',palmDark:'#79502f',trunk:'#754b36',red:'#f73910',skin:'#ffd9b2',white:'#ffffff',twister:'#a1f6ff',green:'#2cc70b',greenLight:'#b0f23b'});
export const isHeavyStoneArtRoom=room=>room?.smm2Mechanics?.version===1&&room.smm2Mechanics.art?.palette==='smb3-desert';
const rgba=p=>p[3]===255?'#'+p.slice(0,3).map(v=>v.toString(16).padStart(2,'0')).join(''):`rgba(${p[0]},${p[1]},${p[2]},${p[3]/255})`;
const cssPal=new WeakMap();
function colors(a,map){let p=cssPal.get(a);if(!p){p=a.palette.map(rgba);cssPal.set(a,p);}return map?p.map((s,i)=>map[rgba(a.palette[i])]??s):p;}
function rect(c,color,x,y,w=1,h=1){const l=Math.round(x),t=Math.round(y),r=Math.round(x+w),b=Math.round(y+h);if(r<=l||b<=t)return;c.fillStyle=color;c.fillRect(l,t,r-l,b-t);}
function clipped(c,q,fn){c.save();c.beginPath();c.rect(Math.round(q.x),Math.round(q.y),Math.round(q.w),Math.round(q.h));c.clip();fn();c.restore();}
function sourceIndex(a,x,y){return (a.alphabet??'0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-_').indexOf(a.rows[y]?.[x]);}
/** Integer nearest sampling also works on Node Canvas without a DOM resource. */
export function drawHeavyStoneSource(c,key,{x=0,y=0,w,h,sx=0,sy=0,sw,sh,paletteMap}={}){
 const a=typeof key==='string'?S[key]:key;if(!a||!finite(x)||!finite(y))return false;
 sw=sw??a.w;sh=sh??a.h;w=Math.round(w??sw);h=Math.round(h??sh);if(w<1||h<1||sx<0||sy<0||sx+sw>a.w||sy+sh>a.h)return false;
 const pal=colors(a,paletteMap),left=Math.round(x),top=Math.round(y);
 for(let yy=0;yy<h;yy++){const ay=sy+Math.min(sh-1,Math.floor(yy*sh/h));for(let xx=0;xx<w;){const ax=sx+Math.min(sw-1,Math.floor(xx*sw/w)),i=sourceIndex(a,ax,ay);let end=xx+1;while(end<w&&sourceIndex(a,sx+Math.min(sw-1,Math.floor(end*sw/w)),ay)===i)end++;if(i>=0&&a.palette[i][3])rect(c,pal[i],left+xx,top+yy,end-xx,1);xx=end;}}
 return true;
}
function mask(c,rows,x,y,color){for(let yy=0;yy<rows.length;yy++)for(let xx=0;xx<rows[yy].length;xx++)if(rows[yy][xx]==='1')rect(c,color,x+xx,y+yy);}
function sampled(c,a,q,sample,paletteMap){const pal=colors(a,paletteMap),w=Math.round(q.w),h=Math.round(q.h);for(let y=0;y<h;y++)for(let x=0;x<w;){const [sx,sy]=sample(x,y),i=sourceIndex(a,sx,sy);let end=x+1;while(end<w){const [tx,ty]=sample(end,y);if(sourceIndex(a,tx,ty)!==i)break;end++;}if(i>=0&&a.palette[i][3])rect(c,pal[i],q.x+x,q.y+y,end-x,1);x=end;}return true;}
function shadowRoom(room){return {...room,smm2Mechanics:{...room.smm2Mechanics,art:{...room.smm2Mechanics.art,dropShadows:false}}};}
/** Observed lower-right shadow, fitted as 3 native pixels with 55% coverage.
 * This is a renderer effect, not a source PNG pixel or collision extension. */
function terrainContains(room,x,y){return (room.map?.geometry??[]).some(a=>visible(a)&&['desert-ground','ground'].includes(a.material)&&x>=a.x&&x<a.x+a.w&&y>=a.y&&y<a.y+a.h)||(room.smm2Mechanics?.slopes??[]).some(a=>{if(!visible(a)||!valid(a)||x<a.x||x>a.x+a.w||y<a.y||y>=a.y+a.h)return false;const right=a.orientation?.endsWith('rise-right'),edge=a.y+(right?a.h*(1-(x-a.x)/a.w):a.h*(x-a.x)/a.w),above=a.orientation?.startsWith('ceiling-');return above?y<=edge:y>=edge;});}
function shadowPass(c,draw,{skipTerrain}={}){
 c.save();c.translate(3,3);c.globalAlpha=(finite(c.globalAlpha)?c.globalAlpha:1)*.55;
 const tint=new Proxy(c,{get(target,key){if(key==='fillRect'&&skipTerrain)return (x,y,w,h)=>{for(let yy=Math.round(y);yy<Math.round(y+h);yy++)for(let xx=Math.round(x);xx<Math.round(x+w);xx++)if(!terrainContains(skipTerrain,xx+3.5,yy+3.5))target.fillRect(xx,yy,1,1);};const value=Reflect.get(target,key,target);return typeof value==='function'?value.bind(target):value;},set(target,key,value){if(key==='fillStyle'){target.fillStyle=P.shadow;return true;}return Reflect.set(target,key,value,target);}});
 draw(tint);c.restore();
}
function originalFor(q,room){return room.map?.geometry?.find(a=>a.id===(q.sourceId||q.id))??room.decorations?.find(a=>a.id===(q.sourceId||q.id));}
function artOrigin(room){return finite(room.smm2Mechanics?.art?.tileOriginY)?room.smm2Mechanics.art.tileOriginY:0;}
function ground(c,q,room){
 q={...q,x:Math.round(q.x),y:Math.round(q.y),w:Math.max(1,Math.round(q.w)),h:Math.max(1,Math.round(q.h))};
 const origin=artOrigin(room),geometries=room.map?.geometry??[],slopes=room.smm2Mechanics?.slopes??[];
 const underSlope=slopes.some(a=>Math.abs(a.y+a.h-q.y)<.01&&a.x<=q.x&&a.x+a.w>=q.x+q.w);
 const covered=(x,y)=>geometries.some(a=>a!==q&&a.id!==q.id&&(a.material==='desert-ground'||a.material==='ground')&&x>=a.x&&x<a.x+a.w&&y>=a.y&&y<a.y+a.h)||slopes.some(a=>{if(!valid(a)||x<a.x||x>a.x+a.w||y<a.y||y>=a.y+a.h||a.orientation?.startsWith('ceiling-'))return false;const right=a.orientation==='rise-right',surface=a.y+(right?a.h*(1-(x-a.x)/a.w):a.h*(x-a.x)/a.w);return y>=surface;});
 const b=room.renderBounds,paint=valid(b)?{x:Math.max(q.x,Math.floor(b.x)-4),y:Math.max(q.y,Math.floor(b.y)-4),w:Math.min(q.x+q.w,Math.ceil(b.x+b.w)+4)-Math.max(q.x,Math.floor(b.x)-4),h:Math.min(q.y+q.h,Math.ceil(b.y+b.h)+4)-Math.max(q.y,Math.floor(b.y)-4)}:q;if(paint.w<=0||paint.h<=0)return true;
 return sampled(c,S.ground,paint,(px,py)=>{
  const x=px+paint.x-q.x,y=py+paint.y-q.y,wx=Math.round(q.x+x),wy=Math.round(q.y+y),tx=mod(wx,16),ty=mod(wy-origin-8,16);
  if(!underSlope&&y<16){if(x<16&&!covered(q.x-.5,q.y+y+.5))return [16+x,64+y];if(x>=q.w-16&&!covered(q.x+q.w+.5,q.y+y+.5))return [112+x-(Math.round(q.w)-16),64+y];return [32+tx,64+y];}
  if(x<16&&!covered(q.x-.5,q.y+y+.5))return [x,96+ty];
  if(x>=q.w-16&&!covered(q.x+q.w+.5,q.y+y+.5))return [112+x-(Math.round(q.w)-16),80+ty];
  return [32+tx,80+ty];
 });
}
function panel(c,q,variant){const a=S['semisolid'+variant],w=Math.round(q.w),h=Math.round(q.h);return sampled(c,a,q,(x,y)=>[x<16?x:x>=w-16?64-(w-x):16+mod(x-16,32),y<16?y:y>=h-16?64-(h-y):16+mod(y-16,32)]);}
function mushroomSource(color){return color==='red'?S.mushroomRed:color==='green'?S.mushroomGreen:S.mushroomYellow;}
function mushroomColors(color){return color==='green'?{'#191919':P.ink,'#adff00':P.greenLight,'#1ab000':P.green,'#f9e1b5':P.light,'#f4b74d':P.sand}:color==='orange'?{'#191919':P.ink,'#f9e1b5':P.light,'#ffca00':P.sand,'#f4b74d':P.sand}:{};}
function mushroomPlatform(c,q,color,stem=false){if(stem)q={...q,x:q.x+(q.w-16)/2,w:16};const a=mushroomSource(color),scale=a.w/48,w=Math.round(q.w),h=Math.round(q.h),map=mushroomColors(color);return sampled(c,a,q,(x,y)=>stem?[(16+mod(x,16))*scale,(16+mod(y,32))*scale]:[(x<16?x:x>=w-16?48-(w-x):16+mod(x-16,16))*scale,Math.min(15,y)*scale],map);}
function topStrip(c,q){const w=Math.round(q.w);return sampled(c,S.semisolid2,{...q,h:16},(x,y)=>[x<16?x:x>=w-16?64-(w-x):16+mod(x-16,32),y]);}
function bridge(c,q){return sampled(c,S.bridge,{...q,y:q.y-8,h:15},(x,y)=>[mod(x,8),y]);}
function block(c,q,kind){clipped(c,q,()=>{for(let y=q.y;y<q.y+q.h;y+=16)for(let x=q.x;x<q.x+q.w;x+=16){rect(c,P.ink,x,y,16,16);rect(c,P.sand,x+1,y+1,14,14);rect(c,P.light,x+1,y+1,14,1);rect(c,P.light,x+1,y+1,1,13);if(kind==='brick'){rect(c,P.ink,x+1,y+7,14,1);rect(c,P.ink,x+8,y+1,1,6);rect(c,P.ink,x+4,y+8,1,7);rect(c,P.ink,x+12,y+8,1,7);}else if(kind==='used'){for(const [px,py]of [[3,3],[12,3],[3,12],[12,12]])rect(c,P.ink,x+px,y+py);}else{mask(c,['01110','11011','00011','00110','00100','00000','00100'],x+6,y+4,P.ink);}}});return true;}
function note(c,q){const a=WALKING_KOOPA_SOURCE_ASSETS.noteBlock;return drawHeavyStoneSource(c,a,{x:q.x,y:q.y,w:q.w,h:q.h});}
export function drawHeavyStoneTile(c,q,room={}){
 if(!isHeavyStoneArtRoom(room)||!valid(q))return false;const original=originalFor(q,room),style=q.smm2Art??original?.smm2Art,material=q.material??original?.material;
 const mushrooms=/^smb3-desert-mushroom-(red|orange|green)(-stem)?$/.exec(style??''),panelKind=/^smb3-desert-semisolid-([12])$/.exec(style??'');
 const topStrip=style==='smb3-desert-semisolid-2-top-strip';
 const known=mushrooms||panelKind||topStrip||style==='smb3-desert-bridge'||['desert-ground','ground','brick','block','used','study-note','contraption-note','note-block','portable-stone'].includes(material)||/^smb3-desert-(palm|sign|outline-hill|cloud|pyramid|purple-strip|unclassified-purple-band)$/.test(style??'');
 if(!known)return false;if(!visible(q))return true;
 if(/^smb3-desert-(palm|sign|outline-hill|cloud|pyramid)$/.test(style??''))return true;
 if(mushrooms?.[2]||topStrip)return true; // Scenery owns these decorative bodies, including their shadow.
 if(room.smm2Mechanics.art.dropShadows===true)shadowPass(c,ctx=>drawHeavyStoneTile(ctx,q,shadowRoom(room)),{skipTerrain:['ground','desert-ground'].includes(material)?room:null});
 if(mushrooms)return mushroomPlatform(c,q,mushrooms[1],false);
 if(panelKind)return panel(c,q,panelKind[1]);
 if(style==='smb3-desert-bridge')return bridge(c,q);
 if(['study-note','contraption-note','note-block'].includes(material))return note(c,q);
 if(material==='portable-stone'){if(q.portableStoneSolid)return true;return drawHeavyStoneSource(c,'stone',{x:q.x+(q.w-16)/2,y:q.y+q.h-16});}
 if(['brick','block','used'].includes(material))return block(c,q,q.used?'used':material);
 if(['smb3-desert-purple-strip','smb3-desert-unclassified-purple-band'].includes(style)){rect(c,P.ink,q.x,q.y,q.w,q.h);rect(c,'#aa1fbe',q.x+1,q.y+1,q.w-2,Math.max(1,q.h-2));rect(c,'#e36ef3',q.x+1,q.y+1,q.w-2,1);return true;}
 return ground(c,q,room);
}
export function drawHeavyStoneSlope(c,q,room={}){
 const a=q?.spec??q,orientation=q?.orientation??a?.orientation;if(!visible(q)||!visible(a)||!valid(a)||!['rise-left','rise-right','ceiling-rise-left','ceiling-rise-right'].includes(orientation))return false;
 const right=orientation.endsWith('rise-right'),above=typeof q.solidAbove==='boolean'?q.solidAbove:orientation.startsWith('ceiling-'),line={a:{x:a.x,y:a.y+(right?a.h:0)},b:{x:a.x+a.w,y:a.y+(right?0:a.h)}};
 const off=above?-a.thickness:0,strip=a.thickness===undefined?null:[{x:line.a.x,y:line.a.y+off},{x:line.b.x,y:line.b.y+off},{x:line.b.x,y:line.b.y+off+a.thickness},{x:line.a.x,y:line.a.y+off+a.thickness}],polygon=q.polygon??strip??(above?[{x:a.x,y:a.y},{x:a.x+a.w,y:a.y},{x:right?a.x:a.x+a.w,y:a.y+a.h}]:[line.a,line.b,{x:right?a.x+a.w:a.x,y:a.y+a.h}]);
 if(!Array.isArray(polygon)||polygon.length<3||!polygon.every(p=>finite(p.x)&&finite(p.y)))return false;
 const inside=(x,y)=>{let sign=0;for(let n=0;n<polygon.length;n++){const u=polygon[n],v=polygon[(n+1)%polygon.length],cross=(v.x-u.x)*(y-u.y)-(v.y-u.y)*(x-u.x);if(Math.abs(cross)<1e-7)continue;const next=Math.sign(cross);if(sign&&sign!==next)return false;sign=next;}return !!sign;},pal=colors(S.ground),origin=artOrigin(room);
 const b=room.renderBounds,x0=Math.max(Math.floor(Math.min(...polygon.map(p=>p.x))),valid(b)?Math.floor(b.x)-4:-Infinity),x1=Math.min(Math.ceil(Math.max(...polygon.map(p=>p.x))),valid(b)?Math.ceil(b.x+b.w)+4:Infinity),y0=Math.max(Math.floor(Math.min(...polygon.map(p=>p.y))),valid(b)?Math.floor(b.y)-4:-Infinity),y1=Math.min(Math.ceil(Math.max(...polygon.map(p=>p.y))),valid(b)?Math.ceil(b.y+b.h)+4:Infinity);
 for(let x=x0;x<x1;x++)for(let y=y0;y<y1;y++)if(inside(x+.5,y+.5)){let color=pal[sourceIndex(S.ground,32+mod(x,16),80+mod(y-origin-8,16))];if(!above&&!inside(x+.5,y-.5))color=P.ink;else if(!above&&!inside(x+.5,y-1.5))color=P.light;rect(c,color,x,y);}
 return true;
}
function cloud(c,q){const w=Math.round(q.w),h=Math.round(q.h);for(let y=0;y<h;y++){const t=y/Math.max(1,h-1),inset=t<.22?Math.round(w*(.25-t*.5)):t>.78?Math.round(w*((t-.78)*.6+.09)):Math.round(w*.04);rect(c,y>=h-2?P.mint:P.cloud,q.x+inset,q.y+y,w-inset*2,1);}}
function pyramid(c,q){const w=Math.round(q.w),h=Math.round(q.h),mid=Math.round(w/2);for(let y=0;y<h;y++){const span=Math.floor((y+1)*w/(2*h)),x=q.x+mid-span;rect(c,y%2?'#e5a184':'#f1b59a',x,q.y+y,span,1);rect(c,y%2?'#d88666':'#e8a181',q.x+mid,q.y+y,span,1);}}
export function drawHeavyStoneBackground(c,room,w,h){
 if(!isHeavyStoneArtRoom(room)||!finite(w)||!finite(h)||w<=0||h<=0)return false;
 const nativeW=room.renderBounds?.w??w,nativeH=room.renderBounds?.h??h;
 if(!finite(nativeW)||!finite(nativeH)||nativeW<=0||nativeH<=0)return false;
 c.save();c.scale(w/nativeW,h/nativeH);rect(c,P.sky,0,0,nativeW,nativeH);
 const camX=room.renderBounds?.x??0,camY=room.renderBounds?.y??0,origin=artOrigin(room),parallax=camX*.35,dy=origin-camY;
 // Finite observed cloud/pyramid silhouettes; phase and scroll remain adapted.
 for(let k=Math.floor((parallax-128)/320);k<Math.ceil((parallax+nativeW+128)/320);k++){cloud(c,{x:k*320+304-parallax,y:24+dy,w:32,h:16});cloud(c,{x:k*320+112-parallax,y:56+dy,w:32,h:16});}
 pyramid(c,{x:208-camX,y:136+dy,w:96,h:72});pyramid(c,{x:304-camX,y:104+dy,w:144,h:104});
 const edge=room.smm2Mechanics.art.goalBackdropX;if(finite(edge)){for(let y=0;y<nativeH;y++){const worldY=y+camY-origin,zig=8-Math.abs(mod(worldY,16)-8),left=Math.round(edge-camX+zig);if(left<nativeW)rect(c,P.ink,Math.max(0,left),y,nativeW-Math.max(0,left),1);}}
 c.restore();return true;
}

function palm(c,q){const cx=Math.round(q.x+q.w/2),canopyY=Math.round(q.y),h=Math.round(q.h);rect(c,P.trunk,cx-1,canopyY+9,3,Math.max(0,h-9));rect(c,'#9a6544',cx,canopyY+10,1,Math.max(0,h-10));const rows=['00000000000111111111000000000000','00000000111111111111111100000000','00000011111111111111111111000000','00001111111111111111111111110000','00011111111111111111111111111000','00111111111111111111111111111100','01111111011111111111111011111110','11111110011111111111110001111111','11111100011111111111100000111111','11111000111111111111110000011111','01110000111100111100111100001110','00110000111000011000011100001100','00000000111000000000011100000000','00000000011000000000011000000000','00000000001000000000010000000000'];const left=cx-16;mask(c,rows,left,canopyY,P.palmDark);for(let y=1;y<13;y++)for(let x=1;x<31;x++)if(rows[y]?.[x]==='1'&&rows[y-1]?.[x]==='1'&&rows[y]?.[x-1]==='1'&&rows[y]?.[x+1]==='1')rect(c,y<4?P.palmLight:P.palm,left+x,canopyY+y);}
function outlineHill(c,q){
 const w=Math.round(q.w),h=Math.round(q.h),radius=Math.min(Math.floor((w-1)/2),h-1),cx=(w-1)/2;let priorL=null,priorR=null;
 for(let y=0;y<=radius;y++){const dy=Math.max(0,radius-y-.5),dx=Math.sqrt(Math.max(0,radius*radius-dy*dy)),l=Math.max(0,Math.floor(cx-dx)),r=Math.min(w-1,Math.ceil(cx+dx));
  if(priorL===null)rect(c,P.white,q.x+l,q.y+y,r-l+1,1);else{rect(c,P.white,q.x+Math.min(l,priorL),q.y+y,Math.abs(l-priorL)+1,1);rect(c,P.white,q.x+Math.min(r,priorR),q.y+y,Math.abs(r-priorR)+1,1);}priorL=l;priorR=r;
 }
 rect(c,P.white,q.x,q.y+radius,1,h-radius);rect(c,P.white,q.x+w-1,q.y+radius,1,h-radius);
}

function sign(c,q){
 const w=Math.round(q.w),large=w>36,h=large?28:q.floating===true?Math.min(28,Math.max(16,Math.round(q.h))):16,head=large?16:Math.ceil(h/2),boardY=Math.round(q.y),shaftTop=large?8:4,shaftBottom=h-shaftTop,cx=Math.round(q.x+w/2-(large?4:0));
 if(q.floating!==true){const postTop=boardY+Math.floor(h/2);rect(c,P.ink,cx-2,postTop,5,Math.max(0,q.y+q.h-postTop));rect(c,'#ab6a1d',cx-1,postTop+1,3,Math.max(0,q.y+q.h-postTop-1));rect(c,P.light,cx,postTop+2,1,Math.max(0,q.y+q.h-postTop-2));}
 for(let y=0;y<h;y++){const tip=Math.max(0,head-Math.abs(y-(h-1)/2)*(head/((h-1)/2))),start=y>=shaftTop&&y<shaftBottom?0:w-head,end=Math.round(w-head+tip);if(end>start)rect(c,P.ink,q.x+start,boardY+y,end-start,1);if(y>0&&y<h-1&&end-start>2)rect(c,y<h/2?'#d69537':'#ad6b17',q.x+start+1,boardY+y,end-start-2,1);}
 rect(c,P.light,q.x+2,boardY+shaftTop+1,Math.max(1,w-head-2),1);rect(c,'#57350c',q.x+1,boardY+Math.floor(h/2),Math.max(1,w-head+head/2),1);
 for(const yy of large?[h/2-4,h/2+4]:[h/2]){rect(c,P.light,cx-2,boardY+yy-1,3,3);rect(c,P.ink,cx-1,boardY+yy);}
}

export function drawHeavyStoneScenery(c,q,room={}){
 if(!isHeavyStoneArtRoom(room)||!valid(q))return false;const style=q.smm2Art??originalFor(q,room)?.smm2Art;if(style==='smb3-desert-semisolid-2-top-strip'){if(!visible(q))return true;if(room.smm2Mechanics.art.dropShadows===true)shadowPass(c,ctx=>topStrip(ctx,q));return topStrip(c,q);}const match=/^smb3-desert-(palm|sign|outline-hill|cloud|pyramid)$/.exec(style??''),stem=/^smb3-desert-mushroom-(red|orange|green)-stem$/.exec(style??'');if(!match&&!stem)return false;if(!visible(q))return true;
 if(room.smm2Mechanics.art.dropShadows===true&&match?.[1]!=='outline-hill')shadowPass(c,ctx=>drawHeavyStoneScenery(ctx,q,shadowRoom(room)));
 if(stem)return mushroomPlatform(c,q,stem[1],true);({palm,sign,'outline-hill':outlineHill,cloud,pyramid}[match[1]])(c,q);return true;
}
function parachute(c,q,tick){const open=q.parachuteActor!==undefined?q.parachuteActor?.open===true:q.sourceParachute===true;if(!open)return;const cx=Math.round(q.x+q.w/2),top=Math.round(q.y-18+(Math.floor(tick/12)%2)),rows=['0000011111100000','0001111111111000','0011111111111100','0111111111111110','0111111111111110','1111111111111111','1111111111111111','1111111111111111','0111111111111110'];mask(c,rows,cx-8,top,P.marioInk);for(let y=1;y<8;y++)for(let x=1;x<15;x++)if(rows[y]?.[x]==='1'&&rows[y]?.[x-1]==='1'&&rows[y]?.[x+1]==='1')rect(c,x<7?'#ffdbf0':'#ed1a92',cx-8+x,top+y);for(let n=0;n<10;n++){rect(c,'#fbeeeb',cx-6+Math.round(n*.5),top+8+n);rect(c,'#fbeeeb',cx+5-Math.round(n*.5),top+8+n);} }
function goomba(c,q,tick){const x=Math.round(q.x+(q.w-16)/2),y=Math.round(q.y+q.h-16);parachute(c,{...q,x,y,w:16,h:16},tick);const rows=['0000001111000000','0000011111100000','0000111111110000','0001111111111000','0011111111111100','0111111111111110','1111111111111111','1111111111111111','0111111111111110','0011111111111100'];mask(c,rows,x,y,P.marioInk);for(let yy=1;yy<9;yy++)for(let xx=1;xx<15;xx++)if(rows[yy]?.[xx]==='1'&&rows[yy]?.[xx-1]==='1'&&rows[yy]?.[xx+1]==='1')rect(c,P.sand,x+xx,y+yy);rect(c,P.skin,x+4,y+10,8,4);rect(c,P.marioInk,x+3,y+4,3,1);rect(c,P.marioInk,x+10,y+4,3,1);rect(c,P.white,x+4,y+5,2,3);rect(c,P.white,x+10,y+5,2,3);rect(c,P.marioInk,x+5,y+5,1,2);rect(c,P.marioInk,x+10,y+5,1,2);const step=Math.floor(tick/8)%2;rect(c,P.marioInk,x+1+step,y+13,6,3);rect(c,P.marioInk,x+9-step,y+13,6,3);return true;}
function coin(c,q,tick){const slim=Math.floor(tick/7)%4===2,w=slim?3:7,x=Math.round(q.x+(q.w-w)/2),y=Math.round(q.y+q.h-16);rect(c,P.marioInk,x,y+1,w,14);rect(c,P.sand,x+1,y,w-2,16);rect(c,P.light,x+1,y+1,1,14);if(!slim)rect(c,'#a06314',x+w-2,y+2,1,12);return true;}
function powerup(c,q,kind,tick=0){
 const x=Math.round(q.x+(q.w-16)/2),y=Math.round(q.y+q.h-16);parachute(c,{...q,x,y,w:16,h:16},tick);
 if(kind==='flower'){
  mask(c,['0001111111100000','0011111111110000','0111111111111000','1111111111111100','1111111111111100','0111111111111000','0011111111110000','0001111111100000'],x+1,y,P.ink);
  mask(c,['0001111111000','0011111111100','0111111111110','1111111111111','0111111111110','0011111111100'],x+2,y+1,P.red);rect(c,P.skin,x+5,y+2,7,4);rect(c,P.ink,x+7,y+3,1,2);rect(c,P.ink,x+10,y+3,1,2);rect(c,'#228400',x+7,y+8,2,8);mask(c,['100000000001','111000000111','011110011110','001111111100','000111111000'],x+2,y+10,P.green);return true;
 }
 if(kind==='star'){
  const rows=['0000000110000000','0000001111000000','0000011111100000','0000011111100000','0111111111111110','1111111111111111','0111111111111110','0011111111111100','0001111111111000','0001111111111000','0011111111111100','0011111111111100','0111111001111110','0111100000011110','0110000000000110'];mask(c,rows,x,y,P.ink);const color=[P.light,P.greenLight,P.twister][Math.floor(tick/4)%3];for(let yy=1;yy<14;yy++)for(let xx=1;xx<15;xx++)if(rows[yy]?.[xx]==='1'&&rows[yy]?.[xx-1]==='1'&&rows[yy]?.[xx+1]==='1')rect(c,color,x+xx,y+yy);rect(c,P.ink,x+6,y+6,1,4);rect(c,P.ink,x+9,y+6,1,4);return true;
 }
 const life=kind==='life',rows=['0000111111110000','0001111111111000','0011111111111100','0111111111111110','1111111111111111','1111111111111111','1111111111111111','1111111111111111','0111111111111110'];mask(c,rows,x,y,P.ink);for(let yy=1;yy<8;yy++)for(let xx=1;xx<15;xx++)if(rows[yy]?.[xx]==='1'&&rows[yy]?.[xx-1]==='1'&&rows[yy]?.[xx+1]==='1')rect(c,life?P.green:P.red,x+xx,y+yy);rect(c,P.light,x+5,y+1,3,4);rect(c,P.light,x+1,y+4,3,3);rect(c,P.light,x+11,y+4,3,3);rect(c,P.ink,x+4,y+9,8,7);rect(c,P.skin,x+5,y+9,6,6);rect(c,P.ink,x+6,y+10,1,3);rect(c,P.ink,x+9,y+10,1,3);return true;
}
function cardGoal(c,q,state,tick){
 rect(c,P.white,q.x,q.y,q.w,q.h);rect(c,P.ink,q.x+2,q.y+2,q.w-4,q.h-4);if(q.collected||state==='empty')return true;
 return powerup(c,{x:q.x+(q.w-16)/2,y:q.y+(q.h-16)/2,w:16,h:16},state==='mushroom'?'mushroom':state,tick);
}
function clippedActor(c,q,draw){const clipTop=q.emerge?q.blockTop:q.clipTop;if(!finite(clipTop))return draw();c.save();c.beginPath();c.rect(q.x-16,q.y-32,q.w+32,Math.max(0,clipTop-q.y+32));c.clip();draw();c.restore();return true;}
export function drawHeavyStoneActor(c,q,tick=0,room={}){
 if(!isHeavyStoneArtRoom(room)||!q)return false;
 // Static editor objects use same-ID author bindings; actual runtime state,
 // including open:false, always wins and cannot reopen a landed canopy.
 if(q.parachuteActor===undefined&&room.smm2Mechanics.parachuteActors?.actors?.some(a=>a.id===(q.sourceId??q.id)))q={...q,parachuteActor:{open:true,phase:'static-preview'}};
 const placed=room.smm2Mechanics.placedItems?.find(a=>a.id===q.id),stone=q.kind==='portable-stone'||q.type==='stone'||q.material==='portable-stone'||room.smm2Mechanics.portableStones?.stones?.some(a=>a.id===q.id),twister=q.type==='local-twister'||q.localUpdraft===true||room.smm2Mechanics.localUpdrafts?.twisters?.some(a=>a.id===q.id),type=q.smm2EnemyKind??q.type??q.skin??q.kind;
 if(q.kind==='exit'&&(room.smm2Mechanics.goalCard?.id===(q.sourceId||q.id)||['smb3-card-goal','card-goal'].includes(q.smm2Art??q.style))){if(!visible(q)||!valid(q))return true;const card=room.smm2Mechanics.goalCard,cycle=card?.cycle??['mushroom','flower','star','life'],state=room.finish?.card?room.finish.result:room.goalCardView?.current??cycle[Math.floor(tick/(card?.framesPerCard??8))%cycle.length];return cardGoal(c,q,state,tick);}
 const powerKind=['mushroom','life','flower','star'].includes(q.kind)?q.kind:q.kind==='walker'&&['mushroom','life','flower','star'].includes(placed?.kind)?placed.kind:null;
 if(powerKind){if(!visible(q)||!valid(q))return true;return clippedActor(c,q,()=>{if(room.smm2Mechanics.art.dropShadows===true)shadowPass(c,ctx=>powerup(ctx,q,powerKind,tick));return powerup(c,q,powerKind,tick);});}
 if(stone||twister){if(!visible(q)||!valid(q))return true;if(room.smm2Mechanics.art.dropShadows===true)shadowPass(c,ctx=>drawHeavyStoneActor(ctx,q,tick,shadowRoom(room)));return drawHeavyStoneSource(c,stone?'stone':'twisterIcon',stone?{x:q.x+(q.w-16)/2,y:q.y+q.h-16}:{x:q.x+(q.w-13)/2,y:q.y+q.h-12,w:13,h:12,sx:25,sy:20,sw:78,sh:72});}
 if(['goomba','Goomba','walker'].includes(type)&&q.kind==='walker'&&!placed){if(!visible(q)||!valid(q))return true;if(room.smm2Mechanics.art.dropShadows===true)shadowPass(c,ctx=>goomba(ctx,q,tick));return goomba(c,q,tick);}
 if(q.kind==='coin'||q.kind==='coin-pop'){if(!visible(q)||!valid(q))return true;if(room.smm2Mechanics.art.dropShadows===true)shadowPass(c,ctx=>coin(ctx,q,tick));return coin(c,q,tick);}
 return false;
}
const carryMap={'#000000':P.marioInk,'#b53120':P.red,'#ffccc5':P.skin};
function carryJumpAsset(){const a=S.smallCarry,b=S.smallJump,palette=[[0,0,0,0],[31,31,31,255],[247,57,16,255],[255,217,178,255]],rows=a.rows.map((row,y)=>[...row].map((ch,x)=>{const p=y<11?a.palette[a.alphabet.indexOf(ch)]:b.palette[b.alphabet.indexOf(b.rows[y][x])];if(!p[3])return '0';const css=y<11?(carryMap[rgba(p)]??rgba(p)):rgba(p);return css===P.marioInk?'1':css===P.red?'2':'3';}).join(''));return {...a,palette,alphabet:'0123',rows,status:'authored-carry-jump-source-pose-combination'};}
// Big source acquisition was not completed. This bounded fallback keeps native
// target proportions (14×27 / 16×26), derives every column from the acquired
// Small source, and explicitly adapts only row repetition for head/torso height.
function bigProportionFallback(air){const a=air?S.smallJump:S.smallIdle,index=air?[0,1,1,2,2,3,3,4,5,6,7,8,8,9,9,10,10,11,11,11,11,12,12,13,14,15]:[0,1,1,2,2,3,3,4,5,6,7,8,8,9,9,10,10,11,11,11,11,11,11,11,12,13,14],w=air?16:14,rows=index.map(y=>air?a.rows[y]:'0'+a.rows[y]+'0');return {...a,w,h:rows.length,rows,status:'authored-big-proportion-adaptation-source-unavailable'};}

function poseAsset(q,tick,big,carried){const air=!q.grounded&&!q.piping&&!q.springId,run=q.grounded&&Math.abs(q.vx||0)>.08&&!q.piping&&!q.springId,phase=Math.floor((q.anim??tick)/6)%3;let a=big?(air&&S.bigJump?S.bigJump:S.bigIdle??bigProportionFallback(air)):carried?S.smallCarry:air?S.smallJump:S.smallIdle;
 if(!big&&carried&&air)return {asset:carryJumpAsset(),map:null};
 if(!run&&!carried||run&&phase===1||carried&&!air&&!run)return {asset:a,map:!big&&carried?carryMap:null};
 // Unacquired foot phases keep the acquired head/body fixed. Only lower rows
 // move, and carry-jump combines the acquired carrying top with jump legs.
 const w=big?16:16,h=a.h,transparent=a.alphabet?.[a.palette.findIndex(p=>p[3]===0)]??'0',rows=a.rows.map(row=>a.w===w?row:transparent.repeat(Math.floor((w-a.w)/2))+row+transparent.repeat(Math.ceil((w-a.w)/2)));
 const start=Math.max(0,h-(big?6:4));for(let y=start;y<h;y++){const row=rows[y],shift=air?0:phase===0?(y>=h-2?-1:1):(y>=h-2?1:-1);rows[y]=shift<0?row.slice(-shift)+transparent.repeat(-shift):transparent.repeat(shift)+row.slice(0,w-shift);}
 return {asset:{...a,w,rows},map:!big&&carried?carryMap:null};
}
function clearMarker(c,x,y){const rows=['0000011111100000','0001111111111000','0011111111111100','0111111111111110','0111111111111110','1111111111111111','1111111111111111','1111111111111111','1111111111111111','1111111111111111','1111111111111111','0111111111111110','0111111111111110','0011111111111100','0001111111111000','0000011111100000'];mask(c,rows,x-8,y-8,P.white);for(let yy=-5;yy<=5;yy++)for(let xx=-5;xx<=5;xx++)if(xx*xx+yy*yy<=25)rect(c,P.red,x+xx,y+yy);mask(c,['10001','11011','10101','10001','10001'],x-2,y-2,P.white);for(let n=0;n<5;n++)rect(c,P.white,x+5+n,y+5+n,Math.max(1,5-n),1);}
export function drawHeavyStonePlayer(c,q,tick=0,room={}){
 if(!isHeavyStoneArtRoom(room)||q?.hero==='bill'||!valid(q))return false;if(q.hidden||q.visible===false||q.removed)return true;if(!q.dying&&!q.shrink&&!q.growth&&!q.fireGrowth&&q.invulnerable&&Math.floor(tick/4)%2)return true;
 if(room.smm2Mechanics.art.dropShadows===true)shadowPass(c,ctx=>drawHeavyStonePlayer(ctx,q,tick,shadowRoom(room)));
 const big=!q.dying&&!!((q.shrink||q.growth)?Math.floor((q.shrink||q.growth)/4)%2:q.power),carried=!!q.carriedStoneId,pose=poseAsset(q,tick,big,carried),a=pose.asset,feet=Math.round(q.y+q.h),x=Math.round(q.x+(q.w-a.w)/2),y=feet-a.h,map={...(pose.map??{})};
 if(q.power===2){map[P.red]=P.white;map[P.marioInk]=P.red;}if(q.star){const shades=[P.red,P.green,'#50b2ef',P.light];map[P.red]=shades[Math.floor(tick/4)%shades.length];}
 c.save();if(q.facing<0){c.translate(x+a.w,y);c.scale(-1,1);drawHeavyStoneSource(c,a,{paletteMap:map});}else drawHeavyStoneSource(c,a,{x,y,paletteMap:map});c.restore();
 if(big&&carried){const hx=q.facing<0?q.x-2:q.x+q.w+1;rect(c,P.skin,hx,y+14,3,3);rect(c,P.red,hx+(q.facing<0?2:-2),y+15,2,3);}
 if(carried&&!q.dying)clearMarker(c,Math.round(q.x+q.w/2-22),y-16);return true;
}
export function drawHeavyStoneWorld(c,room={},view={},tick=0){
 if(!isHeavyStoneArtRoom(room))return false;const smm2=view.smm2Mechanics??view;let handled=false;for(const q of smm2.surfaces??[])if(q.kind==='slope'){if(room.smm2Mechanics.art.dropShadows===true)shadowPass(c,ctx=>drawHeavyStoneSlope(ctx,q,shadowRoom(room)),{skipTerrain:room});handled=drawHeavyStoneSlope(c,q,room)||handled;}
 for(const q of smm2.localUpdrafts?.twisters??[]){const f=q.field;if(!visible(q)||q.active===false||!valid(q)||!f||![f.windHeight,f.bottomHalfWidth,f.topHalfWidth].every(finite)||f.windHeight<=0)continue;const height=finite(f.visualHeight)&&f.visualHeight>0?f.visualHeight:f.windHeight,cx=q.x+q.w/2,base=q.y+q.h/2;for(let n=0;n<24;n++){const t=mod(tick*1.35+n*height/24,height)/height,spread=f.bottomHalfWidth+(f.topHalfWidth-f.bottomHalfWidth)*t,side=Math.sin(n*2.399+tick*.055)*.86,x=Math.round(cx+side*Math.max(0,spread-2)),y=Math.round(base-t*height);rect(c,P.white,x+1,y,2,1);rect(c,P.white,x,y+1,1,2);rect(c,P.white,x+3,y+1,1,2);rect(c,P.mint,x+1,y+3,2,1);}handled=true;}
 return handled;
}
