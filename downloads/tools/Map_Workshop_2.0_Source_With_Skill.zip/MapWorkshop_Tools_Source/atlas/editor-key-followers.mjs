/** Inventory presentation only: never a collectible, collider or door key.
 * Story71's carried single key is visibly about four 30fps source frames behind
 * the small player's moving centre (about 24 native pixels in steady running). The intervening turn/jump and multiple-key paths are
 * not observed; this bounded trail model is an explicit presentation fit.
 * The local Small sprite centre is 1px above its 14px physical body centre;
 * offsetY includes that anchor difference and the observed -2.85px bob mean.
 */
const copy=q=>structuredClone(q);
const center=p=>({x:p.x+p.w/2,y:p.y+p.h/2});
const validPoint=p=>p&&Number.isFinite(p.x)&&Number.isFinite(p.y);
export const KEY_FOLLOWER_PROFILE=Object.freeze({delayTicks:8,approachPxPerTick:3,bobPeriodTicks:13,bobAmplitudePx:1.85,offsetY:-3.85,sourceStatus:'observed-single-key-lag/source-interval-bob-fit'});

export function createKeyFollowers(profile=KEY_FOLLOWER_PROFILE){
 const delay=profile.delayTicks,speed=profile.approachPxPerTick,period=profile.bobPeriodTicks??13,amplitude=profile.bobAmplitudePx??1.85,offsetY=profile.offsetY??-3.85;
 if(!Number.isSafeInteger(delay)||delay<1||delay>120||!Number.isFinite(speed)||speed<=0||speed>16||!Number.isFinite(period)||period<1||period>240||!Number.isFinite(amplitude)||amplitude<0||amplitude>16||!Number.isFinite(offsetY)||Math.abs(offsetY)>32)throw new TypeError('Invalid key follower presentation profile');
 let roomId=null,lastTick=null,trail=[],serial=0;
 const carried=[],consuming=[];
 function anchor(player,id){
  if(!player||![player.x,player.y,player.w,player.h].every(Number.isFinite))return false;
  const c=center(player);
  roomId=id;trail=[{...c,tick:lastTick??0}];
  return true;
 }
 function enter(id,player){
  if(!anchor(player,id))return;
  const c=center(player);
  for(const key of carried){key.x=c.x-8;key.y=c.y-8;}
  consuming.length=0;lastTick=null;
 }
 function collect(id,item,player){
  if(!validPoint(item))return false;
  if(roomId!==id||!trail.length)anchor(player,id);
  carried.push({id:'carried-key-'+serial++,kind:'carried-key',x:item.x+(item.w??16)/2-8,y:item.y+(item.h??16)/2-8,w:16,h:16,sourceItemId:item.id});
  return true;
 }
 function sample(at){
  if(at<=trail[0].tick)return trail[0];
  for(let index=1;index<trail.length;index++){const a=trail[index-1],b=trail[index];if(b.tick>=at){const t=(at-a.tick)/Math.max(1e-9,b.tick-a.tick);return{x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t};}}
  return trail.at(-1);
 }
 function frame({tick,roomId:id,player,hidden=false}={}){
  if(!Number.isSafeInteger(tick)||tick<0||lastTick===tick)return;
  lastTick=tick;
  for(const key of consuming){key.age++;const t=Math.min(1,key.age/key.duration);key.x=key.from.x+(key.target.x-key.from.x)*t;key.y=key.from.y+(key.target.y-key.from.y)*t;key.scale=1.5*(1-t);}
  for(let i=consuming.length-1;i>=0;i--)if(consuming[i].age>=consuming[i].duration)consuming.splice(i,1);
  if(hidden||!player)return;
  if(roomId!==id||!trail.length){enter(id,player);lastTick=tick;}
  const c=center(player);trail.push({...c,tick});
  const retain=tick-delay*(carried.length+2);
  while(trail.length>2&&trail[1].tick<retain)trail.shift();
  // Duplicate ticks, paused rendering and querying view never move a key.
  for(const [index,key]of carried.entries()){
   const target=sample(tick-delay*(index+1)),kx=key.x+8,ky=key.y+8,dx=target.x-kx,dy=target.y-ky,d=Math.hypot(dx,dy);
   if(d>0){const travel=Math.min(speed,d);key.x+=dx/d*travel;key.y+=dy/d*travel;}
  }
 }
 function presented(key,index=0){return {...key,y:key.y+offsetY+Math.sin((lastTick??0)*Math.PI*2/period+index)*amplitude};}
 function consume(portal,{durationFrames=12}={}){
  const raw=carried.shift();if(!raw)return false;const key=presented(raw);
  if(!Number.isSafeInteger(durationFrames)||durationFrames<1||durationFrames>60)throw new TypeError('Invalid key consumption presentation duration');
  // The first source frame exposes the enlarged ring, with its shaft partly
  // hidden by Mario. Its full-glyph centre is therefore an authored anchor fit.
  const from={x:portal.x+portal.w/2-8,y:portal.y+18-8},target={x:from.x,y:portal.y+portal.h-4-8};
  consuming.push({...key,...from,kind:'consuming-key',age:0,duration:durationFrames,from,target,scale:1.5});
  return true;
 }
 function reset(){carried.length=0;consuming.length=0;trail=[];roomId=null;lastTick=null;serial=0;}
 function view(id){return roomId===id?copy([...carried.map(presented),...consuming]):[];}
 return Object.freeze({collect,frame,enter,consume,reset,view,profile:copy(profile)});
}
