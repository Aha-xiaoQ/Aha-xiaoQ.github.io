import {validateSmm2MechanicsRoom} from './editor-smm2-mechanics.mjs';
import {validateAquaticRoom,AQUATIC_PHYSICS_DEFAULTS,AQUATIC_CURRENT_DEFAULTS,AQUATIC_FISH_DEFAULTS,AQUATIC_BLOOPER_DEFAULTS} from './editor-aquatic.mjs';
const clone=value=>JSON.parse(JSON.stringify(value));
const empty=()=>({version:1,currents:[],fishSources:[],enemyProfiles:{}});
function edit(room,fn){const next=clone(room);next.aquatic??=empty();fn(next);if(next.aquatic!==undefined){if(!/Underwater/.test(next.setting||''))next.setting='Underwater';next.underwater=true;}validateAquaticRoom(next);if(next.aquatic===undefined)delete room.aquatic;else{room.aquatic=next.aquatic;room.setting=next.setting;room.underwater=next.underwater;}}
function nextId(room,prefix){const used=new Set([...room.map.geometry,...room.map.objects,...(room.markers||[]),...(room.aquatic?.currents||[]),...(room.aquatic?.fishSources||[]),...(room.marioModules?.itemSources||[]),...(room.marioModules?.enemySources||[])].map(q=>q.id));let n=1;while(used.has(prefix+'-'+n))n++;return prefix+'-'+n;}
export function setAquaticPhysics(room,physics,{maxFishAlive=room.aquatic?.maxFishAlive??3,fireKillPoints=room.aquatic?.fireKillPoints??200}={}){edit(room,r=>{if(physics===null)delete r.aquatic.physics;else r.aquatic.physics={...physics};r.aquatic.maxFishAlive=maxFishAlive;r.aquatic.fireKillPoints=fireKillPoints;});}
/** Explicit interoperation choice. Validation is atomic; removing it cannot
 * silently strand live SMM2 leaves in an unsupported underwater profile. */
export function setAquaticContactBodies(room,mode){
 const next=clone(room);next.aquatic??=empty();
 if(mode==='smm2-solid-actors'){next.smm2Mechanics??={version:1};next.aquatic.contactBodies=mode;if(!/Underwater/.test(next.setting||''))next.setting='Underwater';next.underwater=true;}
 else if(mode===null)delete next.aquatic.contactBodies;else throw Error('请选择支持的水下接触类型');
 validateAquaticRoom(next);validateSmm2MechanicsRoom(next);
 room.aquatic=next.aquatic;room.setting=next.setting;room.underwater=next.underwater;
 if(next.smm2Mechanics)room.smm2Mechanics=next.smm2Mechanics;
}
export function removeAquatic(room){edit(room,r=>{delete r.aquatic;});}
function upsert(room,key,prefix,id,rule){const result=rule?.id||id||nextId(room,prefix);edit(room,r=>{r.aquatic[key]??=[];if(id&&!r.aquatic[key].some(q=>q.id===id))throw Error('请选择已有水下组件');const row={...rule,id:result},index=r.aquatic[key].findIndex(q=>q.id===id);if(index<0)r.aquatic[key].push(row);else r.aquatic[key][index]=row;});return result;}
export function upsertAquaticCurrent(room,id,rule){return upsert(room,'currents','aquatic-current',id,rule);}
export function upsertAquaticFishSource(room,id,rule){return upsert(room,'fishSources','aquatic-source',id,rule);}
export function removeAquaticCurrent(room,id){edit(room,r=>{if(!r.aquatic.currents?.some(q=>q.id===id))throw Error('请选择已有水流');r.aquatic.currents=r.aquatic.currents.filter(q=>q.id!==id);});}
export function removeAquaticFishSource(room,id){edit(room,r=>{if(!r.aquatic.fishSources?.some(q=>q.id===id))throw Error('请选择已有鱼源');r.aquatic.fishSources=r.aquatic.fishSources.filter(q=>q.id!==id);});}
export function setAquaticBlooper(room,id,rule){edit(room,r=>{if(!r.map.objects.some(q=>q.id===id&&q.kind==='walker'))throw Error('请选择已有敌人');r.aquatic.enemyProfiles??={};if(rule===null)delete r.aquatic.enemyProfiles[id];else r.aquatic.enemyProfiles[id]={...rule,kind:'blooper'};});}
/** Editor-only rectangle overlay data. Never introduces gameplay debug labels. */
export function aquaticCurrentOverlays(room){return (room.aquatic?.currents||[]).map(q=>({...AQUATIC_CURRENT_DEFAULTS,...clone(q),editorOnly:true}));}

/** All changes flow through the caller's History transaction and explicit refresh. */
export function mountAquaticTools({parent,room,change,report=()=>{}}){
 const panel=document.createElement('section');panel.id='aquatic-tools';parent.append(panel);
 const controls=new Map();let currentId='',sourceId='',enemyId='',lastRoom=null;
 const node=(tag,text='',container=panel)=>{const n=document.createElement(tag);n.textContent=text;container.append(n);return n;};
 function fill(n,options,value){n.replaceChildren(...options.map(([v,t])=>{const q=document.createElement('option');q.value=v;q.textContent=t;return q;}));n.value=value;}
 function field(id,label,{container=panel,type='number',choices,value=''}={}){const labelNode=node('label',label,container),n=document.createElement(choices?'select':'input');n.setAttribute('data-aquatic-control',id);if(choices)fill(n,choices,value);else{n.type=type;n.value=value;if(type==='number')n.step='any';}labelNode.append(n);controls.set(id,n);return n;}
 const get=id=>controls.get(id),number=id=>{const value=String(get(id).value).trim();if(!value)throw Error('请填写参数');const n=Number(value);if(!Number.isFinite(n))throw Error('参数须为有限数值');return n;};
 const text=id=>String(get(id).value).trim();
 const attempt=fn=>{try{change(fn);refresh();}catch(e){report(e.message);refresh();}};
 function button(id,label,fn,container){const n=node('button',label,container);n.type='button';n.setAttribute('data-aquatic-control',id);n.onclick=()=>attempt(fn);controls.set(id,n);return n;}
 const section=label=>{const n=node('details');node('summary',label,n);return n;};
 const fields=(prefix,items,container)=>{for(const [key,label]of items)field(prefix+'-'+key,label,{container});};
 const read=(prefix,keys)=>Object.fromEntries(keys.map(key=>[key,number(prefix+'-'+key)]));
 const reflect=(prefix,values,keys)=>{for(const key of keys)get(prefix+'-'+key).value=values[key];};
 node('h2','水下组件');node('p','游泳、吸流、追踪鱿鱼与屏外鱼源都参与真实运动。下列运动值和可重复随机序列为本地近似，未以原 ROM 校准。').className='small';
 const swim=section('本房间：游泳与水下接触规则');
 field('contactBodies','接触物件配置',{container:swim,choices:[['legacy','既有游泳配置'],['smm2-solid-actors','实心蛇块与水下实体']]});
 button('contactBodies-apply','应用接触配置',()=>setAquaticContactBodies(room(),text('contactBodies')==='legacy'?null:text('contactBodies')),swim);
 const physicsLabels=[['horizontalCap','浮游水平上限'],['groundCap','海床步行上限'],['acceleration','水平加速度'],['deceleration','海床减速度'],['strokeSpeed','新按键上划速度'],['gravity','停划下沉加速度'],['maxFall','下沉终速'],['top','游泳顶部 Y'],['strokeFrames','泳姿显示帧']];
 fields('physics',physicsLabels,swim);field('maxFishAlive','全房间鱼存活上限（1–3）',{container:swim});field('fireKillPoints','水下鱼 / 鱿鱼火球击杀分数',{container:swim});
 button('physics-apply','应用本房间水下规则',()=>setAquaticPhysics(room(),read('physics',Object.keys(AQUATIC_PHYSICS_DEFAULTS)),{maxFishAlive:number('maxFishAlive'),fireKillPoints:number('fireKillPoints')}),swim);
 button('aquatic-remove','移除本房间全部水下扩展',()=>removeAquatic(room()),swim);node('p','一次新按上划一次；长按不自动续划。水下普通接触不能踩敌人；火球仍可使用。退出水下后由原生地面规则接管。',swim).className='small';
 const flow=section('吸流水域：范围、中心与力');field('current-select','已有水流',{container:flow,choices:[]});get('current-select').onchange=()=>{currentId=get('current-select').value;refresh();};field('current-id','水流标识',{container:flow,type:'text'});
 const currentLabels=[['x','左 X'],['y','上 Y'],['w','宽度'],['h','高度'],['centerX','吸流中心 X'],['pull','向中心的水平加速度'],['down','额外下吸加速度'],['strokeMultiplier','水流内上划倍率']];fields('current',currentLabels,flow);
 const currentRule=()=>({id:text('current-id'),...read('current',currentLabels.map(([k])=>k))});
 button('current-add','添加水流',()=>{const q=currentRule();if(q.id===currentId)delete q.id;currentId=upsertAquaticCurrent(room(),null,q);},flow);
 button('current-apply','修改所选水流',()=>{currentId=upsertAquaticCurrent(room(),currentId,currentRule());},flow);
 button('current-remove','移除所选水流',()=>{removeAquaticCurrent(room(),currentId);currentId='';},flow);node('p','范围与中心只在设计器显示。拉力由真实碰撞运动处理；不在碰撞之后移动角色，也不把吸流直接做成伤害。',flow).className='small';
 const fish=section('鱼源：镜头区域与屏外补充');field('source-select','已有鱼源',{container:fish,choices:[]});get('source-select').onchange=()=>{sourceId=get('source-select').value;refresh();};field('source-id','鱼源标识',{container:fish,type:'text'});
 const sourceLabels=[['startX','启用镜头左界 X（含）'],['endX','停用镜头左界 X（不含）'],['intervalFrames','补充间隔帧'],['initialDelayFrames','首次补充延迟帧'],['maxAlive','本源存活上限（1–3）'],['spawnLead','屏幕右边以外出生距离'],['grayWeight','灰鱼权重'],['redWeight','红鱼权重'],['graySpeed','灰鱼向左速度'],['redSpeed','红鱼向左速度'],['seed','本地序列种子'],['driftSpeed','每第三条鱼竖直速度'],['driftRange','每第三条鱼竖直半范围']];fields('source',sourceLabels,fish);
 field('source-maxEmissions','总补充上限（空白=无限）',{container:fish,type:'text'});field('source-yCandidates','出生 Y 列表（逗号分隔）',{container:fish,type:'text'});
 const sourceRule=()=>({id:text('source-id'),...read('source',sourceLabels.map(([k])=>k)),maxEmissions:text('source-maxEmissions')===''?null:number('source-maxEmissions'),yCandidates:text('source-yCandidates').split(',').map(value=>{if(!value.trim())throw Error('鱼高度列表不能为空');return Number(value.trim());})});
 button('source-add','添加鱼源',()=>{const q=sourceRule();if(q.id===sourceId)delete q.id;sourceId=upsertAquaticFishSource(room(),null,q);},fish);
 button('source-apply','修改所选鱼源',()=>{sourceId=upsertAquaticFishSource(room(),sourceId,sourceRule());},fish);
 button('source-remove','移除所选鱼源',()=>{removeAquaticFishSource(room(),sourceId);sourceId='';},fish);node('p','start / end 是镜头左界区域。真实红 / 灰鱼从右屏外出生并向左穿过地形；活鱼计入上限，击杀后可继续补充。序列可重复，但不声称是原作随机算法。',fish).className='small';
 const blooper=section('已有敌人：鱿鱼追踪脉冲');field('enemy-select','已有敌人',{container:blooper,choices:[]});get('enemy-select').onchange=()=>{enemyId=get('enemy-select').value;refresh();};
 const blooperLabels=[['activationDistance','右屏外预激活距离'],['pulseFrames','斜上冲刺帧'],['decelFrames','减速帧'],['floatFrames','缓落最短帧'],['pulseX','冲刺水平速度'],['pulseY','冲刺上升速度'],['deceleration','每帧减速'],['floatSpeed','缓落速度'],['top','顶部 Y'],['bottom','最低 Y'],['initialDelayFrames','激活后的首次延迟帧']];fields('blooper',blooperLabels,blooper);
 button('blooper-apply','应用鱿鱼追踪行为',()=>setAquaticBlooper(room(),enemyId,read('blooper',blooperLabels.map(([k])=>k))),blooper);
 button('blooper-remove','移除所选鱿鱼行为',()=>setAquaticBlooper(room(),enemyId,null),blooper);node('p','冲刺起点按玩家位置选择左右方向，随后减速和缓落。顶部、最低位置与相位为可编辑的本地近似；敌人忽略海床、珊瑚和石块碰撞。',blooper).className='small';
 function refresh(){
  const r=room();if(lastRoom!==r.roomId){currentId=sourceId=enemyId='';lastRoom=r.roomId;}
  const a=r.aquatic||empty();get('contactBodies').value=a.contactBodies??'legacy';reflect('physics',{...AQUATIC_PHYSICS_DEFAULTS,...a.physics},Object.keys(AQUATIC_PHYSICS_DEFAULTS));get('maxFishAlive').value=a.maxFishAlive??3;get('fireKillPoints').value=a.fireKillPoints??200;
  const currents=a.currents||[];if(!currents.some(q=>q.id===currentId))currentId=currents[0]?.id||'';fill(get('current-select'),currents.map(q=>[q.id,q.id]),currentId);
  const c={...AQUATIC_CURRENT_DEFAULTS,x:64,y:Math.min(144,r.map.height-32),w:64,h:Math.min(96,r.map.height-Math.min(144,r.map.height-32)),centerX:96,...currents.find(q=>q.id===currentId)};get('current-id').value=currentId||nextId(r,'aquatic-current');reflect('current',c,currentLabels.map(([k])=>k));
  const sources=a.fishSources||[];if(!sources.some(q=>q.id===sourceId))sourceId=sources[0]?.id||'';fill(get('source-select'),sources.map(q=>[q.id,q.id]),sourceId);
  const s={...AQUATIC_FISH_DEFAULTS,startX:0,endX:r.map.width,yCandidates:AQUATIC_FISH_DEFAULTS.yCandidates.filter(y=>y<=r.map.height-16),...sources.find(q=>q.id===sourceId)};get('source-id').value=sourceId||nextId(r,'aquatic-source');reflect('source',s,sourceLabels.map(([k])=>k));get('source-maxEmissions').value=s.maxEmissions??'';get('source-yCandidates').value=s.yCandidates.join(',');
  const actors=r.map.objects.filter(q=>q.kind==='walker');if(!actors.some(q=>q.id===enemyId))enemyId=actors[0]?.id||'';fill(get('enemy-select'),actors.map(q=>[q.id,q.id]),enemyId);
  const actor=actors.find(q=>q.id===enemyId),b={...AQUATIC_BLOOPER_DEFAULTS,top:Math.min(32,actor?.y??32),bottom:Math.min(r.map.height-(actor?.h||16),Math.max(actor?.y??0,r.map.height-(actor?.h||16)-16)),...a.enemyProfiles?.[enemyId]};reflect('blooper',b,blooperLabels.map(([k])=>k));
  get('current-apply').disabled=get('current-remove').disabled=!currentId;get('source-apply').disabled=get('source-remove').disabled=!sourceId;get('blooper-apply').disabled=get('blooper-remove').disabled=!enemyId;
 }
 refresh();return Object.freeze({refresh,panel,currentOverlays:()=>aquaticCurrentOverlays(room())});
}
