import {clone,validate} from './editor-model.mjs';
import {makeNativeScenery,nativeSceneryTypes,nativeSceneryPalettes,isNativeScenery} from './editor-native-scenery.mjs';

function edit(room,fn){const copy=clone(room);fn(copy);validate({format:'xiaoq-map-project',version:1,id:'native-scenery-validation',title:'Native scenery',rooms:[copy]},{allowIncompleteCompletionMarks:true});Object.assign(room,copy);}
export function addNativeScenery(room,options){const id=options.id||'native-scenery-'+globalThis.crypto.randomUUID();edit(room,r=>r.decorations.push(makeNativeScenery({...options,id})));return id;}
export function updateNativeScenery(room,id,options){edit(room,r=>{const index=r.decorations.findIndex(q=>q.id===id&&isNativeScenery(q));if(index<0)throw Error('请选择已有原生背景');const q=r.decorations[index];r.decorations[index]=makeNativeScenery({x:q.x,y:q.y,...q.nativeScenery,hidden:!!q.hidden,...options,id});});}
export function removeNativeScenery(room,id){edit(room,r=>{if(!r.decorations.some(q=>q.id===id&&isNativeScenery(q)))throw Error('请选择已有原生背景');r.decorations=r.decorations.filter(q=>q.id!==id);});}
export function setNativeSceneryMode(room,mode){edit(room,r=>{r.nativeSceneryMode=mode;});}

/** Real editor panel; changes use the editor's existing History transaction. */
export function mountNativeSceneryTools({parent,room,change,report=()=>{}}){
 const panel=document.createElement('section');panel.id='native-scenery-tools';parent.append(panel);const controls=new Map();let selectedId='',lastRoom=null;
 const node=(tag,text='',container=panel)=>{const n=document.createElement(tag);n.textContent=text;container.append(n);return n;};
 const fill=(n,entries,value)=>{n.replaceChildren(...entries.map(([v,t])=>{const o=document.createElement('option');o.value=v;o.textContent=t;return o;}));n.value=value;};
 function field(id,label,{choices,value='',type='number',container=panel}={}){const l=node('label',label,container),n=document.createElement(choices?'select':'input');n.setAttribute('data-native-scenery-control',id);if(choices)fill(n,choices,value||choices[0]?.[0]||'');else{n.type=type;n.value=value;if(type==='number')n.step='1';}l.append(n);controls.set(id,n);return n;}
 const get=id=>controls.get(id),number=id=>{if(String(get(id).value).trim()==='')throw Error('请填写背景参数');return Number(get(id).value);};
 const attempt=fn=>{try{change(fn);refresh();}catch(e){report(e.message);refresh();}};
 const button=(id,text,fn,container=panel)=>{const n=node('button',text,container);n.type='button';n.setAttribute('data-native-scenery-control',id);n.onclick=()=>attempt(fn);controls.set(id,n);return n;};
 node('h2','原生背景景物');const detail=node('details');node('summary','树木、围栏与云朵',detail);
 field('mode','背景来源',{container:detail,choices:[['auto','原有自动背景 + 已放置景物'],['authored','仅已放置景物']]});button('mode-apply','应用背景来源',()=>setNativeSceneryMode(room(),get('mode').value),detail);
 field('select','已有景物',{container:detail,choices:[]});get('select').onchange=()=>{selectedId=get('select').value;refresh();};
 field('type','景物类型',{container:detail,choices:Object.entries(nativeSceneryTypes)});field('palette','配色',{container:detail,choices:Object.entries(nativeSceneryPalettes)});
 field('x','左边 X（像素）',{container:detail,value:176});field('y','顶部 Y（像素）',{container:detail,value:178});field('repeat','围栏块数',{container:detail,value:1});field('hidden','隐藏景物',{container:detail,type:'checkbox'});
 const options=()=>({x:number('x'),y:number('y'),type:get('type').value,palette:get('palette').value,repeat:get('type').value==='Fence'?number('repeat'):1,hidden:get('hidden').checked});
 button('add','新增完整景物',()=>{selectedId=addNativeScenery(room(),options());},detail);button('apply','更新所选景物',()=>updateNativeScenery(room(),selectedId,options()),detail);button('remove','删除所选景物',()=>{removeNativeScenery(room(),selectedId);selectedId='';},detail);
 node('p','背景不带碰撞。树木与云朵使用原生尺寸；围栏按 16 像素整块重复。雪白树木使用原有雪景素材；云与围栏保持原生颜色。切换为仅已放置景物会关闭自动山丘、灌木与云朵，城堡、水面和实体平台支撑仍保留。可在装饰层框选移动，也可撤销、重做和导出后重新打开。',detail).className='small';
 function refresh(){const r=room();if(r.roomId!==lastRoom){lastRoom=r.roomId;selectedId='';}const list=r.decorations.filter(isNativeScenery);if(!list.some(q=>q.id===selectedId))selectedId=list[0]?.id||'';fill(get('select'),list.map(q=>[q.id,nativeSceneryTypes[q.nativeScenery.type]+' · ('+q.x+', '+q.y+')']),selectedId);get('mode').value=r.nativeSceneryMode||'auto';const q=list.find(q=>q.id===selectedId);if(q){get('type').value=q.nativeScenery.type;get('palette').value=q.nativeScenery.palette;get('x').value=q.x;get('y').value=q.y;get('repeat').value=q.nativeScenery.repeat;get('hidden').checked=!!q.hidden;}get('apply').disabled=get('remove').disabled=!q;get('repeat').disabled=get('type').value!=='Fence';}
 get('type').onchange=()=>{get('repeat').disabled=get('type').value!=='Fence';};refresh();return {panel,refresh};
}
