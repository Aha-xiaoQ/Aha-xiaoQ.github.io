import {rendererRoom,rendererVisible} from './atlas/editor-renderer.mjs';
import {drawSmm2LightingMask} from './atlas/editor-smm2-lighting.mjs';
import {drawCoinCraneWorld} from './atlas/editor-coin-crane-art.mjs';
/** Renderer-only native Canvas bridge for the night-light course, from the delivered source baseline.
 * Draw order, clipping, shared camera/fade, artwork and HUD come from this project.
 * It never changes runtime state. */
import fs from 'node:fs/promises';
import {existsSync} from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {createRequire} from 'node:module';
import {spawn,spawnSync} from 'node:child_process';
import {once} from 'node:events';
const {createCanvas,Image,GlobalFonts}=createRequire(import.meta.url)('@napi-rs/canvas');
globalThis.Image=Image;
globalThis.document={createElement(tag){assert.equal(tag,'canvas');return createCanvas(1,1);}};
GlobalFonts.register(await fs.readFile(new URL('./renderer-assets/story28-study-regular.otf',import.meta.url)),'StudySans');
GlobalFonts.register(await fs.readFile(new URL('./renderer-assets/story28-study-bold.otf',import.meta.url)),'StudySansBold');
const fontSource=await fs.readFile(new URL('./atlas/chill-font.mjs',import.meta.url),'utf8');
for(const [i,m]of [...fontSource.matchAll(/data:font\/woff2;base64,([A-Za-z0-9+/=]+)/g)].entries())GlobalFonts.register(Buffer.from(m[1],'base64'),i===0?'ChillBitmap':'ChillBitmap16');
const art=await import('./atlas/editor-art.mjs');
const {drawContraptionsScene,drawCar,drawDoor,drawOneWayWall}=await import('./atlas/editor-contraptions-art.mjs');
const {drawStudyWorld,switchStudyEnabled}=await import('./atlas/editor-switch-art.mjs');
const {drawSmm2World}=await import('./atlas/editor-smm2-art.mjs');
const {drawMarioModuleWorld}=await import('./atlas/editor-study-module-art.mjs');
const {drawEchoWorld,drawEchoHud}=await import('./atlas/editor-echo.mjs');
const {orderedTerrain,enemySprite}=await import('./atlas/map-appearance.mjs');
const {createStageCatalog}=await import('./atlas/runtime/stage-catalog.mjs');
const {createPlatformStage}=await import('./atlas/editor-mario-stage.mjs');
const {createPlatformMotor}=await import('./atlas/editor-mario-motor.mjs');
const {nativeCamera:editorCamera,createNativeCameraTracker,drawNativeRoomFade}=await import('./atlas/editor-camera.mjs');
export {createNativeCameraTracker};
const hudLogo=new Image();hudLogo.src=await fs.readFile(new URL('./atlas/assets/q-logo-pixel-core.svg',import.meta.url));await hudLogo.decode();
const hudMark=createCanvas(16,16),markContext=hudMark.getContext('2d');markContext.imageSmoothingEnabled=false;markContext.drawImage(hudLogo,0,0,16,16);markContext.globalCompositeOperation='source-in';markContext.fillStyle='#ffffff';markContext.fillRect(0,0,16,16);
const markPixels=markContext.getImageData(0,0,16,16).data;let markTop=16,markBottom=0,markLeft=16,markRight=0;for(let y=0;y<16;y++)for(let x=0;x<16;x++)if(markPixels[(y*16+x)*4+3]){markLeft=Math.min(markLeft,x);markRight=Math.max(markRight,x+1);markTop=Math.min(markTop,y);markBottom=Math.max(markBottom,y+1);}const markCenter=(markTop+markBottom)/2;

export function nativeCamera(v){const q=editorCamera(v);assert(Number.isFinite(q.width)&&q.width>0&&Number.isFinite(q.height)&&q.height>0);return {...q,w:q.width,h:q.height};}
/** Same projection, draw order and pipe clipping as current editor-play.mjs. */
export function nativeWorld(v, doc, {camera = nativeCamera(v), showPlayer = true, scale = 2, completionMessage = '按 A / Start / Enter 再玩一次'} = {}) {
  const canvas = createCanvas(Math.max(1, Math.round(camera.w * scale)), Math.max(1, Math.round(camera.h * scale))), c = canvas.getContext('2d');
  const room = rendererRoom(doc.rooms.find(r => r.roomId === v.roomId),v,{x:camera.x,y:camera.y,w:camera.w,h:camera.h});
  c.imageSmoothingEnabled = false; art.background(c, room, canvas.width, canvas.height);
  c.save(); c.scale(scale, scale); c.translate(-Math.round(camera.x), -Math.round(camera.y)); art.drawScenery(c, room);
  const visible = o => rendererVisible(o,room,room.renderBounds);
  for (const vine of v.vines || []) art.drawReference(c, {kind: 'active-vine', ...vine}, room);
  for (const marker of room.markers || []) if (/^(lava|water)-/.test(marker.kind)) art.drawReference(c, marker, room);
  for (const g of room.decorations || []) if (!g.hidden && g.studyArt !== 'native-cloud' && visible(g)) art.drawTile(c, g, room,{sceneryDrawn:true});
  const behind = o => !!o.emerge || Number.isFinite(o.clipTop);
  const actor = o => art.drawObject(c, {...o, skin: o.shell ? (/beetle/i.test(o.type) ? 'beetleshell' : 'shell') : o.type || room.enemySkins?.[o.id] || room.markers?.find(m => m.id === o.id)?.kind, source: {...o.source, frame: o.frame}}, v.tick, room);
  for (const o of [...v.enemies, ...v.items]) if (behind(o) && visible(o)) actor(o);
  for (const g of orderedTerrain(room, v.geometry)) if (!g.hidden && visible(g)) art.drawTile(c, {...g, y: g.y - (g.bump ? Math.sin(g.bump / 12 * Math.PI) * 6 : 0), material: g.used ? 'used' : g.material || room.map?.geometry.find(q => q.id === (g.sourceId || g.id))?.material}, room);
  art.drawConveyorWorld(c,room);
  drawStudyWorld(c, v, room); drawMarioModuleWorld(c, v, room);drawSmm2World(c,room,v,v.tick);if(v.contraptions){drawContraptionsScene(c,room,{backdrop:false});for(const q of v.contraptions.doors)drawDoor(c,q,room);for(const q of v.contraptions.oneWayWalls)drawOneWayWall(c,q);}
  drawCoinCraneWorld(c,room);
  for (const marker of room.markers || []) if (!/^(lava|water)-/.test(marker.kind) && !v.hiddenMarkers?.includes(marker.id) && marker.kind !== 'decorative-trunk' && !enemySprite(marker.kind) && marker.kind !== 'marker-Bowser') art.drawReference(c, marker, room);
  for (const o of [...v.objects, ...v.enemies, ...v.items]) if (!['spawn', 'portal'].includes(o.kind) && !behind(o) && visible(o)) actor(o);
  if(v.contraptions)for(const car of v.contraptions.cars||[])drawCar(c,car);if(!switchStudyEnabled(room))drawEchoWorld(c,v.echo,room);
  art.drawInventoryKeyFollowers(c,v,room,{layer:'behind'});
  if (showPlayer && (v.finish?.castle || !['score','castle-flag','castle-wait'].includes(v.finish?.phase))) {
    c.save();
    if (v.transition&&!v.transition.door) {
      c.beginPath();
      if (v.transition.clipBottom != null) c.rect(camera.x, v.transition.clipBottom, camera.w, Math.max(0, camera.y + camera.h - v.transition.clipBottom));
      else if (v.transition.clipTop != null) c.rect(camera.x, camera.y, camera.w, Math.max(0, v.transition.clipTop - camera.y));
      else if(v.transition.clipLeft!=null)c.rect(v.transition.clipLeft,camera.y,Math.max(0,camera.x+camera.w-v.transition.clipLeft),camera.h);else c.rect(camera.x, camera.y, Math.max(0, v.transition.clipRight - camera.x), camera.h);
      c.clip();
    }
    art.drawPlayer(c, v.p, v.tick, room.playerSkin, room); c.restore();
  }
  art.drawInventoryKeyFollowers(c,v,room,{layer:'front'});
  if(room.liquidView)for(const marker of room.markers||[])if(marker.id===room.liquidView.markerId)art.drawReference(c,marker,room);
  c.restore();
  drawSmm2LightingMask(c,room,v,{camera:{x:Math.round(camera.x),y:Math.round(camera.y),width:camera.w,height:camera.h},width:canvas.width,height:canvas.height,createCanvas});
  if(art.nativeHudEnabled(room)){
    c.save();c.scale(2,2);if(!v.contraptions&&room.smm2Mechanics?.version!==1&&room.aquatic?.version!==1){c.drawImage(hudMark,Math.round(12-(markLeft+markRight)/2),3,16,16);c.fillStyle='#fff';c.textAlign='left';c.font='8px ChillBitmap';c.textBaseline='alphabetic';const brandMetrics=c.measureText('在下小Q · 非官方同人');c.fillText('在下小Q · 非官方同人',24+brandMetrics.actualBoundingBoxLeft,Math.round(3+markCenter+(brandMetrics.actualBoundingBoxAscent-brandMetrics.actualBoundingBoxDescent)/2));c.textBaseline='alphabetic';}art.drawHud(c,v,'--',room);drawEchoHud(c,v.echo);c.restore();
  }
  if(v.completed){c.fillStyle='rgba(16,16,22,.88)';c.fillRect(canvas.width/2-176,174,352,126);c.fillStyle='#faf7eb';c.textAlign='center';c.font='32px ChillBitmap16';c.fillText(v.lives>0?'关卡完成':'游戏结束',canvas.width/2,218);c.font='16px ChillBitmap16';c.fillText(completionMessage,canvas.width/2,262);}
  drawNativeRoomFade(c,camera,canvas.width,canvas.height);
  return {canvas,room,camera};
}
