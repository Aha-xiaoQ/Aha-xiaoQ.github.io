# 马里奥地图工坊 2.0 · 1.11.0

独立工具更新包。基于1.10.34合入已验证的试玩、输入、全屏、音频与离线导出改进，新增可选Minecraft房间设置入口。没有替换旧版目录，也未同步网站。

## 安装与启动
标准下载包已合并全部源码、图像和音频。解压后进入 `MapWorkshop_Tools_Source`，无需手动拼合组件。

安装 Node.js 22 或更新版本后，进入该目录运行 `node server.mjs`（或 `npm run dev`），打开终端显示的完整地址。普通编辑和试玩无需先下载 npm 依赖；运行构建、CLI、原生测试前执行 `npm ci`。首次安装测试依赖需要 npm 网络。

Windows 可双击“启动工坊.cmd”；macOS/Linux 可在终端运行 `sh 启动工坊.sh`。启动器只运行本机服务，不安装软件。

编辑器需要本地HTTP服务；导出的独立HTML可直接离线打开。不要直接双击模块化editor.html。

## 保存、试玩与导出
旧的qmap/qcollection根格式仍为1。先备份工程，再导入、保存、试玩、导出。新增可选字段需要配套新运行时；不要用旧编辑器覆盖新功能工程。

- `npm run build`：重建普通中性示例及离线单图/合集。
- `npm test`：运行本包回归测试。
- `npm run verify`：构建并验证。
- `npm run map:validate -- examples/neutral-demo.qmap.json`
- `npm run map:export -- examples/neutral-demo.qmap.json --output dist/my-map.html`

## 新的可选房间设置
右侧属性区提供Minecraft房间面板；普通新建地图不自动启用。启用后可选择环境主题、配乐来源及英雄房间基础生命上限设置，改动进入现有撤销/重做和保存流程。

面板给出包内完整冒险qmap下载入口，下载不会替换当前地图；通过现有导入按钮主动打开。高级Boss、村民交易、熔炉、沙子、矿车等使用示例里的作者数据和对应控制器，本版没有把这些全部做成拖拽组件或通用连线编辑器。

可选完整示例：`examples/minecraft-adventure/blast-trail.qmap.json`。其普通输入测试数据一同附在evidence内。默认仍是普通马里奥地图。

## 控制与音频
试玩支持现有键盘/触屏/标准GamepadAPI流程。MC专用攻击、盾、药水和交易键根据房间启用；武器由实际地图奖励决定，开局不宣称拥有剑或弓。失焦、断连、菜单和切换输入源会清理按键状态。

全屏识别画面自身及祖先/子级目标，MC房间横屏按显示比例扩展呈现视野；模拟与碰撞尺寸不变。旧地图保留原有取景行为。

本地音乐导入留在浏览器内，不上传、不写入分享HTML。可选打包配乐来自Dark Reaven Music/VoxeLibre，遵循CC BY-SA3.0，不是Minecraft原版录音；详见docs/MINECRAFT_MUSIC_CREDITS.md及素材目录。

## 支持范围与验证
详见CHANGELOG-1.11.0.md、UPGRADE_AND_ALIGNMENT.md和RELEASE-CHECK-1.11.0.md。实际普通输入、共享Canvas及模拟DOM测试与真实浏览器/实体设备测试明确区分。未宣称真实浏览器全屏、实体手柄或触屏已实测。

代码许可见LICENSE-CODE.md；其他素材保留各自权利。随附AI制图Skill入口 `.agents/skills/map-workshop/SKILL.md`，其CLI与此包一起运行。

## 录制默认画幅

附带原生输入回放录制脚本默认 1920×1080、30 fps（16:9）。通过扩展真实渲染视口保留原有画面范围，不做横向拉伸或裁切 HUD。录制为确定性原生 Canvas 回放，不能当作真实浏览器或实体手柄录像证明。历史验收截图可能仍为其他比例。

## 标准仓库更新包

交付覆盖包以 Aha-xiaoQ.github.io 仓库根目录为相对路径。仅替换 downloads/tools/Map_Workshop_2.0_Source_With_Skill.zip，并添加对应发布说明；其它网站文件保留。详见 docs/GITHUB_UPDATE_1.11.0.md。该步骤是本地发布准备，没有推送或部署。
