# 马里奥地图工坊 2.0

创建地图、配置机关、管理多关合集，边编辑边试玩，并导出可离线打开的HTML。本包附带源码、资源许可和AI制图Skill。

## 启动编辑器

安装Node.js 22或更新版本，解压后进入 `MapWorkshop_Tools_Source`：

```sh
npm ci
npm run dev
```

首次安装需要连接npm。在浏览器打开终端显示的地址，并进入 `/atlas/editor.html`。模块化编辑器需要本地服务；导出的HTML可以直接打开。

## 保存与导出

`.qmap.json` 保存可继续编辑的地图，`.qcollection.json` 管理多关合集。保存工程副本后再修改，HTML不能替代工程备份。

```sh
npm run build
npm run map:validate -- examples/neutral-demo.qmap.json
npm run map:export -- examples/neutral-demo.qmap.json --output dist/my-map.html
npm run map:validate -- examples/neutral-demo.qcollection.json
npm run map:export -- examples/neutral-demo.qcollection.json --output dist/my-collection.html
```

示例与导出结果位于 `dist/`。自己的地图建议保存在独立项目目录。格式及机关配置见 `docs/`；迁移工程前阅读 `UPGRADE_AND_ALIGNMENT.md`。

## AI制图Skill

入口：`.agents/skills/map-workshop/SKILL.md`。无需全局安装，可让支持项目Skill的助手读取该文件，也可直接使用上面的验证和导出命令。Skill附带四份参考文档和一个CLI脚本。

## 使用范围

代码使用范围见 `LICENSE-CODE.md`；图像、音频和字体分别见 `ASSET_LICENSES.md` 及资源目录的许可说明。附带源码不意味着取得素材的新增授权。部分机关使用可调整的近似参数，具体支持范围见对应接口文档。
