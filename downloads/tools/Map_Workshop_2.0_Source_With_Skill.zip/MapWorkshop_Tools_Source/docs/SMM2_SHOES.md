# 马里奥地图工坊 2.0 · Shoe/Goomba-in-Shoe contact adapter

`atlas/editor-smm2-shoes.mjs` is an opt-in reusable adapter for native walker sidecars. It owns live NPC, empty and Mario-occupied Shoe motion, acquisition, separate dismount, typed sole contacts and bounded landing blast actors. Stage owns scoring, actual enemy defeat, damage, block removal, goal cleanup and room transitions. Native Mario motor files and delivered Stone artifacts are unchanged.

## Evidence and approximation boundary

The [Nintendo SMM2 element palette](https://www.guiasnintendo.com/2c-switch/super-mario-maker-2/guia-super-mario-maker-2/paleta-elementos.html) establishes Goomba stomp acquisition, walking over spikes and Munchers, Small/Big/winged variants, Big Stiletto forced landing breaking hard blocks, and Big Shoe pound/cloud defeat of Munchers. The [Nintendo controls](https://www.guiasnintendo.com/2c-switch/super-mario-maker-2/guia-super-mario-maker-2/controles.html) separate jumping from L/R/ZL/ZR dismount and specify Down in the air for Big Shoe pound. The host input name is `dismountPressed`; jump never ejects.

Original course 8 [observed playback](https://www.twitch.tv/videos/451814210), identified by [the run record](https://www.speedrun.com/smm2/runs/zqrw751y), shows ordinary green Shoe movement over Munchers, a Goomba stomp and 200 points, approximately one-tile Small shoes and two-tile Big shoes, and wings outside the foot body. The supplied task card, course-start, underground and selected actual frames were visually inspected. A Goomba's partially exposed head should not be rendered as a permanently additional full-height body.

Every numeric value is an author approximation, including foot/passenger/head bounds, NPC hop timing, composite collision envelope, ejection and stomp impulses, pound speed, cloud size/speed/range/lifetime and contact tolerances. Horizontal acceleration, native held jump and ground movement use the supplied native Mario motor exactly once per occupied step. Optional walking hops and wing flutter are explicit author tuning, disabled by default. Flutter controls/timing, cross-pipe retention and general Shoe damage interactions have not been calibrated from the source. The carry API supplies a capability; it does not silently choose a course pipe rule.

Ordinary green Shoe versus Piranha/Spiny sole combat has not been clearly verified for this SMB1 source. The default stomp policy recognizes ordinary native stompable enemies and leaves those special targets unverified. A host may pass a narrow `isStompTarget(target,shoeDefinition)` predicate for an explicit author approximation; it still requires real downward sole contact. The final two plants vanish during flag cleanup in the observed course, so their disappearance does not establish bare-Mario or Shoe stomp immunity. Fireballs, arbitrary hazards, boss/Thwomp kills, blanket invulnerability, carrying other riders, and unmeasured shell/projectile interactions are not invented. Big Stiletto landing clouds are not asserted; the current blast implementation is for the regular Big green Shoe.

## Native-compatible authoring

```js
room.map.objects.push({
  id: 'shoe-01', kind: 'walker', x: 160, y: 144, w: 16, h: 16
});
room.smm2Mechanics = {
  version: 1,
  shoes: [{
    id: 'shoe-01', kind: 'shoe', size: 'small', winged: false,
    occupant: 'goomba', tuning: {npcSpeed: 0.5, npcHopFrames: 36}
  }]
};
```

All variant fields are required. `kind` is `shoe` or `stiletto`; `size` is `small` or `big`; `winged` is boolean; `occupant` is `goomba` or `empty`. `tuning` is optional. `crouchCompatible` is an optional boolean defaulting to `true`. The native object is the actual foot rectangle, not the entire sprite or wing span. Native kinds/IDs stay unchanged in authored data. Each definition must bind exactly one bounded native walker; duplicate IDs, scripts, unsafe keys, unsupported variants and invalid tuning are rejected. Native dimensions may be 1–64 pixels and need not be constrained to a hard-coded sprite scale. UI/course defaults are 16×16 Small and 32×32 Big; explicit reusable collision bounds remain author approximations. Lists are capped at 256.

`SMM2_SHOE_TUNING` exports all defaults. Gravity and NPC/walking hop speeds are 0–16; player/pound/ejection speed values are positive and at most 64. Head height is positive and at most 64, seat inset fits the native foot height, and boarding tolerance is 0–2. Hop intervals are integer 1–36000. Flutter and remount lock are integer 0–36000. Cloud speed is positive and at most 16, range 0–4096, dimensions 1–64, lifetime integer 1–36000. A zero cloud range disables clouds. These bounds validate authoring; they are not Nintendo constants.

Typed hard-block destruction requires `smm2BlockKind:'hard-block'` or `material:'hard-block'` on a live solid. Brick requests use the separate `brick` type. An explicit block identity takes precedence over generic native `material:'stone'`, which may represent a visually similar original hard block while preserving the native ABI. Tagless Stone, Ground/dirt and gray pixels do not grant breakability. Native Ground remains protected even if mislabeled with a block tag. A genuine Big Stiletto Down pound may request hard-block removal. A Big regular Shoe may request brick removal; ordinary landing, Small shoes, hidden solids and room ground do not qualify.

## Genuine pipe-source registration

`registerActor(actor,templateId)` registers an already produced native source spawn. The template ID must resolve to an original authored `shoes` sidecar and matching native walker **in this controller's room**. Dynamic/imported actors cannot become templates. The dynamic actor needs native `kind:'walker'`, a unique safe ID, a live foot rectangle fully inside the room and exactly the template's width/height. An explicit foreign `roomId`, existing native/component ID, unknown template, duplicate registration, altered dimensions, foreign Shoe state or invalid velocity is rejected. The controller clones the template's variant, occupancy, tuning and crouch policy; it keeps the actual spawn ID, position and velocity. It never relocates a spawn to the template's coordinates or scripts acquisition.

The native bounded source factory owns spawn periods, maximum live bodies, pipe direction and emergence. A source's empty or occupied Shoe remains a genuine live body for the host's `maxAlive` count; Goomba release does not delete it. While `actor.moduleEmergence` exists, Shoe motion, NPC body/contact and boarding are suppressed. The host steps that factory-controlled emergence first. `view()` reports `emerging:true`, the actual foot pose and copied emergence metadata for pipe clipping, with no protruding NPC body or contact envelope. Once emergence is finished, the usual physics/contact path applies. This is an actor state check, not a course time/location branch.

Dynamic registrations remain owned even after their actor dies, so ID reuse cannot resurrect them accidentally. `reset()` removes every dynamic registration, clears its Shoe/player sidecars and marks its old live body dead; authored templates reset to their original pose and NPC/empty occupant. A later genuine spawn may register a fresh ID again. Total controller definitions are bounded at 20000; the source factory must keep active population substantially below that bound.

## Stage integration contract

```js
const shoes = createSmm2Shoes(room, {emit, terrain});
// Native walker source copies are decorated once and bypass generic AI/combat.
for (const a of shoeActors) shoes?.decorateActor(a);

terrain?.beginFrame({tick, actors: [player, ...allActors]});
shoes?.beginFrame({tick, actors: allActors, player, paused});
for (const a of shoeActors) shoes?.stepActor(a, {
  tick, geometry: roomGeometry, targets: allEnemies
});
const before = {...player};
const events = shoes?.stepPlayer(player, input, character, {
  width: roomWidth, solids: roomGeometry
}, {tick, motor: bareNativeMotor, targets: allEnemies});
if (events == null) ordinaryContactMotor.step(player, input, character, world);
const actions = shoes?.afterPlayer(player, before, {
  tick, actors: shoeActors, geometry: roomGeometry
});
const blastActions = shoes?.stepEffects({
  tick, geometry: roomGeometry, targets: allEnemies
});
terrain?.finishFrame({tick, actors: [player, ...allActors]});
```

Pass the **bare** motor to `stepPlayer`: the controller resolves its composite proxy through `terrain.afterActor` once. Do not additionally terrain-step the real player in this branch. A persistent proxy includes the real passenger height and foot width. Native kinematics are copied back selectively; power, helmet and normal body ownership remain with Stage. `shoeBody(player)` and `exposedBody(player)` expose separate actual contact boxes. The composite world collision rectangle is an explicitly conservative approximation; wings are decorative. The occupied foot is tagged as a player trigger for existing donut terrain, so player-only support can observe actual feet rather than the passenger's inset bottom.

Powered Big/Fire Mario with `crouchCompatible:true` uses ordinary ground Down to crouch to the native 16-pixel crouch height; standing uses the native 28-pixel powered height. Feet remain at the actual Shoe support, power/helmet are preserved and crouched movement uses native friction instead of standing acceleration. Standing requires real headroom against solid rectangles and existing shaped ceiling sweeps. A low roof keeps the body crouched until space is available; there are no holes, auto-small rules or arbitrary roof exceptions. Small Mario does not shrink from Down. Airborne Down does not request crouch and only a Big Shoe starts a pound. `crouchCompatible:false` is an explicit author policy that disables this body resizing; exact original Shoe crouch bounds remain uncalibrated.

Muncher blocking bodies and non-solid Spike top supports are added by `geometry(base,targets,{actor})` only for an owned Shoe/NPC or occupied player. They must never be written into the global room geometry or used for bare Mario. A typed Muncher's actual live rectangle becomes a full solid proxy so an ascending Shoe cannot enter its side before its sole clears the top. This conservative rectangular collision policy is an explicit author approximation until original hitboxes are calibrated; it does not grant protection to real side or exposed-body overlaps. The native motor remains responsible for approach, wall blocking, jump clearance and landing. Typed Munchers must be real live target bodies. Spike identity is `spikeTrap:true`; generic hazard identity never grants protection. Inert, hidden and dead targets do not participate.

`afterPlayer` returns `{boarded:[],defeated:[],breaks:[]}`. Goomba-head stomp emits a `defeated` action with `action:'defeat-occupant'`, `occupantOnly:true`, `actorId` and `shoeId` equal to the source ID. Stage may award the ordinary Goomba points/flip effect, but must **not call full `killEnemy` on that foot actor**. The live occupancy changes to `empty`, Mario takes his native Goomba bounce, and the foot retains its actual motion/support. The observed 5.25-second frame shows this separate empty Shoe below the bouncing Mario and flipped Goomba. A later genuine descent into the empty foot changes occupancy to `player` and returns `boarded:[id]` without another defeat/reward or artificial stomp bounce. `breaks` entries are `action:'break-solid'` with the actual `solidId`, `blockKind`, Shoe ID and geometric contact. Stage removes the real solid and emits its ordinary debris/sound once.

When already mounted, `afterPlayer` also resolves real Shoe-to-Shoe NPC contacts. A genuine downward sole crossing of another Goomba's actual head releases only **that target occupant**, returns the same occupant-only defeat action and bounces Mario in his existing Shoe. It does not switch vehicles, delete the second foot or award an empty-foot reward. Real side/exposed-body contact with an NPC Shoe instead appends an optional `damage` array of `action:'hurt'` requests. Stage applies its ordinary damage policy. `damage` is absent for neutral legacy results. Empty, carried, removed and emerging feet cannot become arbitrary damage/defeat targets.

The public resolver is `playerShoeContact(player,before,target,{tick,targetBefore,geometry})`. It uses frame-start shoe/head poses, separate real Shoe and exposed-player rectangles, swept relative contact and actual intervening solid/one-way paths. It returns typed `handled`, `protected`, `action`, target `actorId`/`shoeId`, current `ridingShoeId` and contact. An occupant release changes the target to `empty`; damage remains a host request. Both direct and `afterPlayer` paths latch their decisions within the frame. Use one host action-consumption path to avoid consuming a returned query twice. Numeric contact bounds and Shoe-to-Shoe motion remain author approximations; this adapter does not claim a separately calibrated original combat matrix.

`playerEnemyContact(player,before,target,{tick,targetBefore})` returns `{handled,protected,action,targetId,shoeId,contact}`. Muncher top support is protected and leaves it alive; Big Down pound direct contact requests `action:'defeat'`. An ordinary confirmed stomp target requests the same action and a native bounce. This method never marks the target dead or assigns points. Unsupported special stomp targets return `unverified` and no protection. `playerHazardContact(player,before,hazard,{tick,hazardBefore})` supplies typed Spike/Muncher protection only for real sole landing/resting support, with exposed-body contact excluded. Stage retains native damage for unprotected contact. Neither query synthesizes a remote collision from a target ID.

Big green Shoe pound landing emits two actual moving cloud bodies visible as `view().blasts`. `stepEffects` advances them once per tick. Clouds have bounded travel/lifetime, continuous collision against actual walls/shaped terrain, and swept contacts against live Munchers. It returns explicit `action:'defeat'` requests, never radius/screen-wide damage or a course-script kill. Other NPC types and targets behind a wall remain unchanged. No cloud is created by airborne Down alone, an ordinary landing or a Small Shoe.

A wave's bottom may touch an adjacent same-plane Muncher's exact top surface. That target contact is inclusive without extending the cloud into the Muncher or underlying floor. Ordinary world-solid/wall sweeps remain strict and take precedence; a flush blocking wall removes its cloud rather than permitting a hit behind it. A positive vertical gap is not padded into a contact. This boundary rule is exercised by an actual Big Shoe Down pound/support landing on a center Muncher, with adjacent same-row Munchers and physical blocking geometry. Cloud dimensions/range/speed remain author approximations.

`dismount(player,{reason='manual',jump=true,consume=false})` detaches without relocating the player. Manual dismount supplies an author ejection impulse and leaves an empty Shoe with a bounded remount lock. For `hurt`, `goal` or host transition handling, use `jump:false`; Stage can choose `consume:true` when its confirmed damage policy consumes the Shoe. The controller does not infer a blanket damage rule. Death clears ownership and removes the occupied live foot until reset. `reset()` restores authored source pose/occupant and removes dynamic registrations, imported carry states and clouds.

`syncTransition(player)` follows a genuine native pipe animation's actual player `x/y/w/h` into the occupied foot pose and returns that same live actor. It changes only foot `x/y`; it does not step gravity, generate actors, process contacts, emit events or advance any timer. The player remains untouched. An unowned player returns `null`. Stage calls this after updating native animated player pose, so the next ordinary frame cannot pull the player back toward stale footwear. It supplies pose synchronization only and does not choose whether an original course retains Shoes through a pipe.

Frame/motion entry points reject invalid frames. Equal/stale `beginFrame` and repeated actor/player/effect steps do not advance again. Acquisition, defeat queries, break requests and manual dismount are idempotent within their defined tick/ownership state. Paused frames emit no motion, acquisition, combat or clouds. A missing leaf returns `null`; `withSmm2Shoes(motor,null)` returns the exact motor object.

## Optional cross-room carry

`createSmm2Shoes(room,{allowCarry:true})` can exist without local shoes. `exportCarry(player,{detach:false})` returns a plain JSON snapshot of variant, source/origin identity, dimensions, tuning and crouch compatibility. `detach:true` marks the origin foot `carried` and clears ownership. `importCarry(player,snapshot,{tick})` restores an occupied live foot at the destination player's current position while preserving their power/helmet. Unknown keys, ID conflicts and out-of-room feet are rejected. Returning to the origin reuses its carried live actor rather than creating duplicate IDs. Carry is disabled unless the host explicitly enables it. The course generator must choose its transition policy from observed evidence rather than treating this capability as proof that the original pipe retained a Shoe.

`view()` includes root `mountedId` and arrays `shoes`/`blasts`. Each Shoe reports its actual foot rectangle, native kinematics, variant, occupancy, source/origin ID, optional dynamic `templateId`, crouch policy and emergence state. Occupied Shoes also expose `playerBody`, `exposedBody` and the true composite `contactBody`; native Stage player pose already has the seated/crouched dimensions. `atlas/editor-smm2-shoe-art.mjs` draws self-written green Shoe, dark Stiletto, partial Goomba head, decorative wings and cloud approximations from live/controller state. It suppresses the NPC head during source emergence. It does not read reference pixels, alter native sprite data or change mechanics.