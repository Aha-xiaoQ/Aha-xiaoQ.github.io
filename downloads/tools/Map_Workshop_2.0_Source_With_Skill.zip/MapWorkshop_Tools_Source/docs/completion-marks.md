# 马里奥地图工坊 2.0 · 门上实体粉币进度标记

completionMarks 是可复用、显式启用的纯显示绑定，位于 room.smm2Mechanics.completionMarks。它不包含游戏控制器，不增加奖励或碰撞，也不按进入区域、击败敌人、打开闸门、计时或完成某段输入判断通关。它只显示共享 Stage 当前真实 pinkTaken Set 中，目标 typed Pink 的稳定身份是否已存在。

这是本作原创显示提示。空心轮廓与绿色白勾不是 Nintendo 原作素材或未经核验的原游戏机制。旧房间没有此叶时，验证器及视图构建器返回 undefined，渲染器不绘制标记；宿主不得给旧 view 插入空 completionMarks 属性。

## 保存格式和严格边界

数组可有 0–32 项，每项必须且只能包含以下四个字符串字段：

```json
[
  {
    "id": "sandbox-mark",
    "portalId": "entry-portal",
    "rewardRoomId": "reward-sandbox",
    "coinId": "reward-pink"
  }
]
```

id、portalId 和 coinId 使用项目已有的安全小写字母／数字／连字符 ID，最长 100 字符。rewardRoomId 必须是非空、最长 100 字符且不含换行的真实房间 ID，不依赖任何私有中枢命名。每个数组的标记 ID、portalId 及 rewardRoomId + 换行 + coinId 身份分别唯一。未知字段、completed／taken 等伪进度、缺字段、原型别名、Symbol 字段和超界数组均拒绝。

portalId 必须引用本房 map.objects 中实际 kind: portal 的对象。标记位置只从该对象实时计算，不保存 x／y。12×12 标记在门口中心上方，间隔 6 像素；放置必须在地图内、真正位于门口上方。移动门户会直接移动标记。它不进入 geometry、objects、碰撞或奖励列表。

完整项目验证必须提供全部 rooms，核对 rewardRoomId 实际存在，且 coinId 同时引用目标房的原生 kind: coin 与 smm2Mechanics.pinkCoins typed 记录。普通金币、失效 typed 记录及删除的房间均不能被标记。目标粉币可以在门后经过其他房间才能到达，因此不要求 rewardRoomId 等于 portal.targetRoom。

qmap／qcollection 根格式仍为 1。旧严格 reader 不认识 completionMarks，须升级至包含此叶及完整引用校验的工坊版本；根版本不变不代表旧 reader 兼容。源项目只保存四个绑定字段，从不保存完成布尔值。

## 运行态与死亡／重开

atlas/editor-completion-marks.mjs 的 completionMarksView(room, pinkTaken, rooms) 每次生成新的标记数组。completed 仅来自 Set.prototype.has 对真实 Set 的精确 roomId + 换行 + coinId 查询。总数、裸币 ID、普通币身份、房间访问记录、伪造 has 函数及先前 view 都不能替代真实 Set。构建器不调用 add／delete／clear，不缓存 Set 或标记状态，不修改作者 room。

宿主必须传入当前 Stage 内部真实 pinkTaken，不能从 HUD 的 taken 数字还原身份。粉币被原生拾取后，门标记变成绿色白勾；跨门重入沿用同一真实身份，不重复领奖。死亡动画仍按宿主的实际身份生命周期显示，真正重生清空粉币身份时，下一次 view 自动恢复空心轮廓。整局重开使用新 Stage 和新 Set，标记也立即恢复。此模块不提前或延后宿主的死亡／钥匙重置。

drawCompletionMarks(ctx, room) 使用 room.completionMarksView 绘制动态投影，未提供运行态投影时生成全部未完成的静态作者预览。绘制只有小圆角徽记，没有文字、砖块纹理或额外钱包；按 renderBounds 裁除画面外的标记。它在世界层绘制，宿主 HUD 后绘制；不写入 HUD 或屏幕手柄布局。编辑、试玩、原生 Canvas 录像和离线 HTML 应使用此同一函数。

## 原子作者工具和引用清理

editor-completion-marks-tools.mjs 提供 setCompletionMarks／removeCompletionMarks 与完整数组 JSON 面板 mountCompletionMarksTools。面板需要 room、getRooms、change、report；getRooms 返回当前完整 History.doc.rooms，change 必须接入原有 History 事务。set 在复制前验证原始提案，避免克隆静默丢失 Symbol／未知字段；成功才替换此一个叶子。失败不部分修改房间，错误草稿保留在面板供修正。Undo／redo 与 qmap JSON 往返使用原有 History 和 strict parseProject。

pruneCompletionMarksRoomReferences(room, beforeRoom) 可在原生单房删除中清掉本房被删门户及本房目标。pruneCompletionMarksReferences(rooms, beforeRooms) 必须在同一 History 事务里，完成所有原生对象／typed 叶清理后调用一次，处理跨房粉币删除、typed Pink 取消及整房删除。它返回删除的标记数，最后一项被删除时移除此可选叶。仅此前有效且四个绑定字段及字段集合均未改变的条目会被清理；新写错的 ID／字段继续由严格验证拒绝，不以自动清理吞掉作者错误。清理只删对应标记，不减少奖励要求、不发钥匙、不改其他标记或原生对象。

完整项目 import／History／compile 必须调用 validateCompletionMarksRooms(rooms)。仅有一个房间快照的通用组件编辑 helper 不具有完整跨房上下文：它可显式调用 validateCompletionMarksRoom(room) 做本地校验，或用 allowMissingRewardRooms: true 进行已声明的局部校验。这个选项不得用于实际项目导入、保存提交或完整编译；存在的目标房仍必须含真实 typed Pink。

## 显式复制 helper 与 UI 范围

captureCompletionMarkBindings(room, selections, rooms) 接收 Map<roomId, Set<objectId>> 与完整源 rooms；仅同时选中了真实本房 portal 和目标房 typed Pink 时捕获绑定，否则返回 null。返回的快照为 {roomId, marks}，不含运行完成状态。

appendCopiedCompletionMarkBindings(room, snapshot, {roomIds, objectIds, markIds}, rooms) 要求宿主先复制真实原生对象及 typed 叶，再提供三个显式 Map。roomIds 把原 roomId 映射到目标 roomId；objectIds 以原 roomId + 换行 + objectId 为键映射新原生 ID；markIds 把原标记 ID 映射到新标记 ID。门户、粉币和标记必须取得新的对象／标记 ID，房间映射可留在同房内。缺任一映射、重复目标或目标不是实际 typed Pink 时，整次 append 失败且不修改房间。它不默默保留指向源房粉币的旧引用。

这是显式图复制 helper API。现有普通剪贴板 UI 按单图层、单房选择操作，尚未接入跨房完整 portal／Pink 绑定的自动捕获和粘贴；普通复制按钮不承诺复制 completionMarks。整份 qmap 导入／导出保留已有绑定，JSON 面板可重建或更新绑定。

中性 fixture 为 tests/fixtures/completion-marks.mjs，只有两个普通房间、门户、typed Pink、普通金币及可选原生伤害体；不导入私有关卡工厂或整图路线。

```sh
node --test tests/completion-marks.test.mjs tests/completion-marks-native.test.mjs
```

中央接入点：SMM2 mechanics closed allowlist 加 completionMarks 并调用本地 validator；editor-model 完整 room 循环后执行 validateCompletionMarksRooms；Stage 只在作者叶存在时投影 completionMarksView；rendererRoom 仅在运行 view 明确含该属性时转接 completionMarksView；共享世界绘制调用 drawCompletionMarks；编辑面板与原有全局事务清理接上述 helpers。需同时保留明确的单房编辑 helper 局部上下文，不能把部分 rooms 列表误当完整工程，也不能弱化实际完整工程验证。
