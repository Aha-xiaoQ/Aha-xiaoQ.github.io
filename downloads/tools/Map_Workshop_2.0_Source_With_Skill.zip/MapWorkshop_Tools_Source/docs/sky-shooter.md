# 马里奥地图工坊 2.0 · 原创骑云小蜜蜂组合契约

skyShooter 是显式 opt-in 的原创房间组合，version 1。它把已观察并已支持的 Lakitu Cloud 顶面登乘、座位与原生乘员运动，与真实原生 Goomba 的伤害、死亡和得分管线组合成紧凑的骑云射击关。编队、外挂推进器、手持武器、上行子弹、瞄准预警、俯冲、导弹、数量和闸门要求都是作者规则；不声称 Nintendo 或 Namco 原物理、关卡、像素或时序复刻。

## 所有权与运行接口

atlas/editor-sky-shooter.mjs 的 createSkyShooter(room, {emit, defeatEnemy, hurtPlayer}) 返回 step、ownsActor、isActiveActor、defeatedActor、view 与 reset。缺省房间没有此叶时返回 null。step 接收 tick、player、input、enemies、geometry，以及既有 Cloud 控制器的 clouds.view()。

Stage 必须先执行原生 Cloud step / sync 和乘员运动，再执行 skyShooter.step。绑定无人机仅由本控制器拥有飞行位置；绑定且未启用的后续波体不得参与原生运动、玩家接触或普通武器目标。启用的无人机保留同一原生 enemy 对象、接触、死亡、分数与死亡图像。Stage 不再对其重复施加行走 / 重力。其他敌人和 Cloud motor 不变。

defeatEnemy 只在一发真实运动子弹的连续矩形碰撞之后调用，参数包含敌人引用、shotId、tick 与 contact point。Stage 使用已有 killEnemy 和 score-pop 管线，真实设置同一对象的 dead。仅同一已注册、当前波且真实 dead 的对象能被 defeatedActor 确认。返回值、输入次数、经过时间、消失的敌人、伪造的同 ID 对象都不授予击败进度。其他真实原生攻击造成的死亡也可由 Stage 通知；每个 ID 只计一次。

导弹与可选 enemyFire 的真实敌弹接触调用 hurtPlayer，Stage 使用原有 hurt / 云离座 / Small 失命 / 死亡动画 / 重生流程。控制器不改 player 位置、速度、power、health、lives、inventory、coins、invulnerability 或 checkpoints。它不决定 Small 会不会失命，不发钥匙、不收粉币。

所有配置波次中的实际敌人击败后，控制器仅隐藏运行态 geometry 中 gateIds 指定的真实闸门。Pink 始终为原生 typed coin；玩家必须实际接触它，随后走进原有横向奖励管。死亡和真实房间重入时必须清理该房的控制器状态，和原生敌人 / 闸门一起重新建立。已经收过的 Pink 继续由 Stage 全局身份防重复。

## 保存字段与边界

根叶接受必填 version、cloudId、activation、gateIds、rewardId、drones、weapon、formation、attack，以及可选 loopingDivers、enemyFire。cloudId 引用已有 Lakitu Cloud；gateIds 引用一至十六个不重复、可见的原生 solid；rewardId 引用一个真实 coin 且同时列在 pinkCoins。缺省 drone 列表一至二十四个，绑定唯一的已有 16×16 walker，各含 id、wave、x、y、phaseFrames；wave 从 1 连续，最多 8。没有 loopingDivers 时，旧叶行为、视图字段和波次规则保持原样。没有 enemyFire 时，基础瞄准导弹、原俯冲与全部旧视图字段保持原样。

weapon 含 cooldownFrames（6–120）、speed（1–16 px/tick）、lifeFrames（8–240）、maxShots（1–12）。formation 含 amplitudeX（0–64）、amplitudeY（0–32）、periodFrames（60–36000）、waveDelayFrames（24–600）。整个编队运动范围必须在房间内。

attack 含 firstAttackFrames（36–600）、intervalFrames（至少 telegraphFrames+24，最多1200）、telegraphFrames（36–180）、diveSpeed（0.5–4）、diveTurnFrames（24–240）、missileSpeed（0.5–3）、missileLifeFrames（24–300）、maxMissiles（1–6）。所有数字必须有限；帧数与数量必须安全整数。未知字段、原型 / Symbol alias、无效版本、缺字段、重复 ID 和失效引用严格拒绝。

loopingDivers 若存在必须是完整的严格对象，不能是 null、false 或缺字段的默认开关：version=1，actorIds 为 1–6 个不重复且已绑定的 drone ID；exitY、reentryY、sideX 是连续返航通道的坐标；exitSpeed、reentrySpeed、returnSpeed 为 0.5–4 px/tick；maxActive 为 1–2 且不能超过 actorIds 数量。启用时只允许一波，总数最多 30，未列入 actorIds 的基础敌人最多 24。actorIds 引用同一组已存在的原生敌人，不创建补位体或库存。

坐标必须在真实房间内，sideX ∈ [0,width−16]，reentryY ∈ [0,height−16]，exitY ∈ [reentryY+32,height−16]。上入口须比整个编队最上运动范围至少高 8px；下出口须低于所有所选俯冲体的完整运动范围；sideX+16 不得超过 activation 左边或编队最左运动范围。覆盖左柱、下出口、上入口与编队的通道矩形不得与任何可见原生 solid 重叠。这种保守布局检查确保不会从实体顶墙、地板或闸门中瞬移穿过；通道仍有真实玩家接触。

没有 enemyFire 时，同一注册 enemy 对象沿 warning → dive → exit → outside-return → top-reentry → return → formation 运动。48tick 等具体预警由 attack.telegraphFrames 显式配置；瞄准在预警开始时锁定。未击落的俯冲体通过锁定位置，继续到下出口，横移到左侧开放柱，上升到高处再进入，并返回自己的原始编队槽位。每帧位移受显式速度限制，运动中仍可被真实子弹击败、接触玩家，也可连续再次俯冲。基础编队继续发射导弹，所选俯冲体按稳定 ID 排序轮换，最多 maxActive 个在途。死亡只确认一次 ID；返航事件、暂离编队、返回次数和经过时间均不增加分数、击败或奖励。

仅启用叶的视图增加 loopingDivers（actorIds、maxActive、active、corridor、cycles），所选无人机增加 looping=true 与 returns。cycles 为按稳定 ID 的真实归队次数；死亡后原 ID 保留统计但不再出现在活体 drones 中。事件包括 diver-exit-start、diver-exit、diver-top-reentry、diver-slot-approach、diver-formation-return；均只观察运动，不执行结算。reset 清除返回次数、飞行态与对象注册，并由宿主重建真实房间实体。

## 可选敌人射击

enemyFire 是完整严格对象，不能使用 null、false、缺字段或隐式默认值。它要求已有单轮 loopingDivers；不创建敌人，仍由同一最多 24 基础 + 6 返航敌人的原生对象完成战斗。必填字段如下：

- version = 1
- downwardActorIds：1–24 个不重复已绑定 drone ID，指定逐个垂直轮射的基础敌人
- diverActorIds：1–6 个不重复已绑定 drone ID，必须与 loopingDivers.actorIds 是同一集合，且与 downwardActorIds 无交集
- firstDownwardShotFrames：36–600 整数；第一次垂直射击的预告从 wave-start 后这个 tick 数开始
- downwardIntervalFrames：至少 telegraphFrames + 24，最多 1200 的整数；相邻垂直射击预告的间隔
- telegraphFrames：36–180 整数，垂直／下降后瞄准射击共用的完整预告时长
- shotSpeed：0.5–3 px/tick；shotLifeFrames：24–300 整数；maxShots：1–6 整数，所有新敌弹共享一个有限池
- diverAttackY：俯冲者 body-top 的攻击坐标，严格低于所选编队身体的最下运动边界，严格高于 loopingDivers.exitY
- minAimDistance：24–128 px，枪口到锁定目标的距离低于该值时跳过下降后瞄准弹；等于该值允许射击

底排按 downwardActorIds 的显式顺序循环选择仍活着且空闲的原生敌人，每次只有一只底排敌人在预告。开始预告时锁定同一身体位置与底部枪口 `{x:actor.x+8,y:actor.y+16}`，期间暂停编队运动。完整预告结束才产生 4×8 真实弹，其 vx = 0、vy = shotSpeed，随后同一身体以 loopingDivers.returnSpeed 有界追随并回到自己运动中的槽位。死人或返航中的身体会跳过；全体真实击败仍是开门的唯一条件。

启用 enemyFire 后，旧基础瞄准导弹被替换，俯冲调度只选择 diverActorIds 并仍受 maxActive 限制。初次俯冲沿 attack 的现有可见预告与锁定 x 下探，以 diveSpeed 连续到达准确的 diverAttackY，不再因旧 diveTurnFrames 提早掉头。到攻击段后，同一身体暂停，再按 enemyFire.telegraphFrames 显示枪口和瞄准线；此时对 Mario 中心位置只取一次快照。距离低于 minAimDistance 或真实弹池已满便明确跳过本发，仍沿既有 exit → outside-return → top-reentry → return 通路返阵。成功发射的速度向量从锁定枪口指向该快照，Mario 后续移动不会追踪改向。下降、暂停、返航均保留原生接触和可被击落身份；不复活、不重新得分。

仅启用的视图增加 enemyFire（version、downwardActorIds、diverActorIds、maxShots、shots）。真实敌弹含 id、actorId、kind（downward／aimed）、x、y、w、h、vx、vy、age。warnings 增加相应 kind、锁定 source、target、startedTick、readyTick、age、remainingFrames；这些预告统一由共享 renderer 绘制可见枪口闪烁、方向线／目标框，垂直枪口另有向下箭头，不依靠文字。预告中的 drone.state 为 warning；基础回槽为 downward-return。新事件为 enemy-shot-launch、enemy-shot-skipped（too-close／capacity）、enemy-shot-contact、enemy-shot-blocked，原 diver-* 返阵事件不变。死亡取消其待发预告，但已发出的真实弹仍按空间碰撞／寿命处理。实际弹与可见原生 solid、玩家作连续矩形扫掠；地形优先遮挡，玩家接触只请求宿主原生伤害。

中性配置示例使用 firstDownwardShotFrames=90、downwardIntervalFrames=84、telegraphFrames=36、shotSpeed=1.8、shotLifeFrames=240、maxShots=4、diverAttackY=280、minAimDistance=40。它们是本作作者组合参数，既有官方影像仅支持俯冲／返回编队的结构观察，不证明新枪口、垂直轮射、攻击段或射击时序是原作校准。

qmap / qcollection 根版本仍为 1；旧 reader 不认识 skyShooter 或其可选 loopingDivers／enemyFire 时，必须升级到含这些严格叶子的工具版本。这不是旧 reader 兼容承诺。集合能力包含 authored-armed-cloud-arcade-v1，启用返航时另有 authored-armed-cloud-looping-divers-v1，启用敌人射击另有 authored-armed-cloud-enemy-fire-v1。

## 作者编辑与渲染

editor-sky-shooter-tools.mjs 提供原子 set / remove、完整规则 JSON 作者面板、删除清理及完整组复制引用重映射。set 先复制、验证后提交，外层 History 再执行整图校验。删除任何此前绑定的无人机、云、闸门或奖励会移除整个规则组；不会自动减少通关人数。部分复制不带规则；完整复制必须给所有绑定体新的稳定 ID。可选 actorIds、downwardActorIds、diverActorIds 一并重映射，sideX 按 dx、exitY / reentryY / diverAttackY 按 dy 平移后重新校验，射速／距离／时序不平移。此完整组复制仅为已验证的 helper API 契约；现有编辑器剪贴板 UI 仍为单图层，不支持一键选择或复制跨云组件 / 原生体 / 闸门 / 奖励的完整图。

editor-sky-shooter-art.mjs 使用 classic-art.mjs 的完整、未改色原 Goomba 像素一次绘制绑定敌人。飞行包、枪和子弹是本作作者绘制，采用既有像素调色板；未提取 Galaga 舰船素材。可选俯冲排的铜色尾焰仅改原创飞行包，不改 Goomba 身体像素或 16px 碰撞。drawSkyShooter 在场景后、Mario 前绘制；drawSkyShooterWeapon 在原生坐姿 Mario 后绘制，使武器在手边可见。Stage / renderer 的 skyShooterView 来自同一控制器。一般敌人渲染必须排除这些绑定 ID，防止双画。

[Galaga 官方历史页](https://galaga.com/en/history/galaga.php)与其 publisher 图像可见上方居中的阶梯编队、击败后的空位。[官方 Steam 页面](https://store.steampowered.com/app/403430/ARCADE_GAME_SERIES_GALAGA/)预告实际观察的 23.023–28.028s 段可见红敌下方退出、25.359s 左右上方再现、回到左上空槽，期间分数 4150 不变。其为同一敌人的判断是视觉连续性推断，未取得原作对象身份、槽位记账、完整 AI、精确物理或时序。当前 24 基础 + 6 可选顶排、连续左柱返航、坐标、预警和速度均为本作作者改编，不称 Namco 屏幕绕回或参数校准。
