# 马里奥地图工坊 2.0 · 工具接口与能力边界

本文件记录实际源码提供的可选能力，根格式不变不意味着旧读取器能识别新字段。普通 qmap/collection、编译器和共享 Stage 累计保留。实际入口为 atlas/editor.html；正式 Snake、water actor 和 Goal Tape 面板在同一个普通编辑器，2019实验入口单独保留。

## 正式 Snake Block 叶子

room.smm2Mechanics.snakeBlocks={version:1,trains:[...]}。每列车必须显式含 id,color,origin,path,lengthCells,speedPxPerTick,initialHeadDistancePx,activation,endpointHoldFrames,collapseIntervalFrames,collapseGravity,collapseFallCap,collapseOrder。origin是首格左上角；path是有稳定 id 的相对16px正交路径，首点0,0，不能交叉／重复路径节点。

当前支持 green/blue、activation:"player-top" 和明确 head-to-tail/tail-to-head 掉落顺序。内部完全占据的节点是固定世界 collider；前后沿连续运动，不能把全列格以头速搬动。真实顶面启动后离台继续，抵端原形保持、暗化、逐格掉落；不是压成一条新直台。速度、保持、顺序、重力、末速和碰撞接触体均为明确作者数值；示例配置Green0.5／Blue1px/tick、62tick保持（约1.033秒）符合原动态1.00–1.07秒区间，但不称原引擎常量。路径预算、房间限界属于工具安全约束。

atlas/editor-snake-blocks.mjs 是纯定义校验和实运行controller；editor-snake-block-placement.mjs核初始布局；editor-snake-block-tools.mjs提供 set/remove/clone/move/capture/append API及原生UI。真正起点、geometry、动态cells和玩家都由共享 Stage 负责。同frame/重复tick、失撑、普通跳离、端点、布局、作者复制／删除／撤销及离线闭包分别测试。

## 正常水下实体与来源

room.smm2Mechanics.underwaterActors={version:1,profiles:[...]}。每项只能有id或sourceId之一，引用已有native walker或匹配enemy source，不偷偷创建第二个actor或更改身体。Fish Bone字段为 cruiseVx,alertRadius,alertFrames,aimSample,chargeInitialSpeed,chargeAcceleration,chargeMaxSpeed,blueContactPolicy，以及可选sensorFacing:"forward"/"any"。Galoomba必须明确small/giant以及idleBobAmplitude,idleBobPeriodFrames,idleBobPhaseFrames,approachRadius,approachAcceleration,approachMaxSpeed,approachVerticalCap,solidResponse。空Buzzy shell必须明确initialVx,initialVy,gravity,maxFallSpeed,horizontalRestitution。

Fish Bone保持巡游蓝眼、警戒／冲刺红眼、对真实玩家采样aim、与实际solid/Snake接触后散开；瞄准采样、蓝眼接触策略和sensor范围是作者契约。Galoomba和shell使用真实相对扫掠，原32/16身体身份不靠画面推定，速度／加速度／gravity等不称原作常量。正常Underwater限定、单一controller ownership、来源类型、身体/房间范围由validator明确拒绝不兼容组合；未支持夜间、任意NPC、跨风格或rewind推广。

atlas/editor-underwater-actors.mjs与editor-underwater-actor-tools.mjs为controller/strict API/UI；source仍由marioModules.enemySources拥有。新增launcher类型可引用原生cannon，明确炮口偏移、方向、间隔、在场数／总数／激活距、初速度／emergence，不把视觉炮口当隐形独立spawner。删除／复制／稳定引用/History和sourceId重映射受通用测试约束。

aquatic.contactBodies:"smm2-solid-actors"选择当前有限正常水下接触协议。水下mario motor系数继续是现有作者近似；其它aquatic房间不隐式启用新实体ownership。普通Red Cheep Cheep沿用原native fish source/controller，新的静态原图只改变显示，未伪造尾/body原动画时序。

## SMW移动终点带

room.smm2Mechanics.goalTape绑定唯一真实exit，要求明确SMW Underwater源art、正常水下与上述solid-body协议。posts.left/right必须是适合exit的等高竖柱；tape明确x,w,h,minY,maxY,speed,phaseFrames,direction；rewardBands按Y无缝覆盖作者旅行区间，每档显式points/coins/lives；clear显式hopSpeed,walkSpeed,walkDistance,clearFrames，并可选motion:"room"/"dry"与cameraY。省略motion继续旧dry终场；room显式保留房间水下下降规则；cameraY只有真实碰带后才采用作者终场镜头。

editor-smw-goal-tape.mjs仅让实际player与运动带连续相交触发一次终点；柱或exit矩形本身不触发。折返点的同frame sweep与连续contact不会跨过带体漏判或重复奖励。共享Stage完成普通清关短跳、落地、右行／等待；碰撞形状、下端旅行界、奖励档和clear系数没有原完整表，全部标作者参数。editor-smw-goal-tools.mjs接入真正配置、引用、复制／删除和History。

## 图像、镜头、声音与兼容

SMW源art只由明确smw-underwater-source profile选择。公共原图、响应hash/decodedRGBA及游戏年份保留在assets/story42-original；editor-smw-underwater-source-pixels/art负责同一原图或明示适配。SMW背景/鱼眼/翅膀/游泳/弹壳滚动/箭头/炮口的未恢复帧和时序不扩成原动画认证。正确SMW BGM缺失；不以其它style音乐替换。

camera是在实际editor-smm2-course-components、editor-camera及playRules中定义的可选作者框架，不是原机相机算法还原；它不变成world/motor墙。gravity、motor、NPC速度及碰撞体均按源码的明确有限参数。旧未opt-in工程的精确fixture和行为门禁保留，不能为新增字段重写native-baseline。

offlineFile新增可选options.essentialAudio:true，以当前房间主题和实际Bill/ghost使用筛选所需声音资源，降低明确单场景导出大小；省略时保留原默认资源行为。它不新增或恢复缺失的SMW音乐。工具的默认中性build仍使用原默认参数，全部共享声音源及许可继续封入独立工具源码。