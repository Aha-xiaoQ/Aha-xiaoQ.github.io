# 马里奥地图工坊 2.0 · 乌龟、传送带与摄像接口背景

以下组件的动态研究参考包含公开SMM2故事71录像：
https://archive.org/details/Super_Mario_Maker_2_Switch_RUS_Walkthrought

## 可复用能力

- Walking Koopa：静态walker的enemyVariants和管道enemySources.actorVariant都用同一严格规则。普通／巨型身体、红绿与行为、顶砖临时翻壳、空中横向动量、恢复、踩壳、踢壳、真正接触Hard Block逐块破坏
- 传送带：smm2Mechanics.conveyors独立存取；实际顶面端点与绘制圆齿中心独立；ON/OFF全局反向，扫掠承载不覆盖实体自己的速度；平面到相连斜面保持真实支撑
- NPC弹簧：springs[].npcContact仅启用已核普通Koopa踩固定竖弹簧的压缩／自动弹射。未推广到任意NPC或移动载簧
- 摄像：camera.horizontalBarrier在指定原生地形都真实消失后开放镜头，不改变世界边界、玩家移动或出口实体
- 声音／得分：scoreProfile、goalCoins、goalCoinPoints为可选独立数据。原片金币每枚100分；取钥匙没有额外分；原杆+1币不加金币分。默认旧规则未改
- 原素材：公开Nintendo原图单独保留出处与权利；SMM1家族与SMM2实际画面比对使用，不冒称完整SMM2提取动画表

## 原关因果与边界

原前三房以同一开关改变横向通路、落层时机与弹簧起跳；第四房从安全控制层引导NPC经过六条反向水平／斜带；末房需真实从下顶砖，使临时巨壳上抛到高一格红台，再恢复、撤台落下，踩成同尺寸巨壳、踢碎四硬块出口。

数值不是恢复的原版常量：步速／基础motor、恢复550/600帧、顶砖上抛4.35与巨型水平0.8、NPC弹簧6帧/6.75、传送带30px/s及接触端点均为原画约束下的拟定。原片显示高46px巨龟可穿32px下层通道，故分开底锚32px地形体与48px玩家接触体；确切原机hitbox仍未恢复。传送带下／侧面的全部语义也未观察。

## 反馈修订

新editor-key-followers是库存的纯可见状态，使用实际pickup/consume/reset生命周期；不会成为道具collider、补钥匙、免伤或移动人物。世界绘制共享editor-art，浏览器与native录像均分离carry后层/consume前后层。固定地面水平滞后8tick与bob13tick/1.85px为连续原帧区间拟合；其他动作、消费初完整glyph中心受人物遮挡而存在不确定性。默认consume12tick并非已得原60Hz精确动画表。

普通平带60/快平带120来自原30fps纹周期与实际载龟位移的独立交叉测量。斜帶当前物理60＋纹相位60仅拟合现在的触线/纹坐标，原中段45度顶面仍是明确缺口，不推广成全部原带物理认证。
