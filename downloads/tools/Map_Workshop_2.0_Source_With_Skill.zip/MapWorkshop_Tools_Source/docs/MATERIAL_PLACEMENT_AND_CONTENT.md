# 马里奥地图工坊 2.0 · 素材放置与砖块藏物

本版在 qmap version 1 中增加可选作者字段 geometry.content。原生地图、Stage Catalog、Mario motor 和 collision ABI 仍为版本1；作者字段随 visualRooms 使用，不写入原生 map.geometry。qcollection version 1 保留完整 qmap，因此同样保存此字段。

## 确定非法的位置

独立金币（objects.kind=coin，包括粉红金币）与已绑定的 SMM2 placedItems（life、mushroom、star）和 helmets 使用真实身体检查：

- 与永久实体的正面积相交产生 PICKUP_SOLID_OVERLAP，指明 room、对象 ID、实体 ID 和对象坐标
- 相同类型的两个独立可拾物在相同 x、y 产生 DUPLICATE_PICKUP；相邻或边界接触不算重复，也不把附近拾物强制吸附到网格
- 矩形使用严格边界；SMM2 斜坡使用现有 terrain controller 导出的真实 convex polygon，包括薄条、天花斜坡和空三角，使用严格分离轴检查

永久实体来自明确的原生 solid 碰撞、已知地形、真实 note block 或始终实心的 ON/OFF 按钮。装饰层、oneway、运动平台、会下落的甜甜圈、隐藏状态、ON/OFF红蓝状态块、可由 P Switch 转换的空砖块按真实类型审计，不套永久矩形禁令。P豁免必须来自真实typed P身体或真实管道pSources，并沿有效portal目标／spawn关系传播到该房；同时要求实际controller拥有该房的砖转换。空contraptions、仅cars或tracks不构成P来源。Mario itemSources只执行life/star/flower，声明p-switch产生PLACEMENT_UNKNOWN_P_SOURCE warning，不作为转换许可。砖块带藏物时不能当作空砖被 P 转换。未识别的实体类型只产生 PLACEMENT_UNKNOWN_SOLID warning；无法读取地形多边形时产生 PLACEMENT_UNKNOWN_TERRAIN warning。未知情况不自动改地图。

出口和 portal 是触发器，不是可拾物。管道落地点只能凭 marioModules.arrivalDirections 中真实的 pipeId 关系跳过自己的管道；ID 名叫 arrival 并不会自动绕过别的实体。管道供给模板按 enemySources.shoeTemplateId 与 boneShells.templateOnly 的实际关系识别，不解释为一颗独立金币。没有通用 allowOverlap 开关。

## 合法藏物

选中可顶击的 Brick 或 Block，在“砖块藏物”中保存内容。例如：

```json
{"id":"reward-brick","x":128,"y":160,"w":16,"h":16,"material":"brick","collision":"solid","content":"mushroom","reward":"mushroom"}
```

不再另放一个独立 coin 与砖块相交。选择“沿用底图 / 默认”删除 content 和 reward，保留既有 marker、semantics 或 Block 默认coin逻辑。画笔不切碎有藏物的砖块；请选中后移动、修改内容或整块删除。

content 是一个字符串，不能使用未经实现的对象、数组或自定义脚本。支持值严格取自当前 Stage 奖励消费者：coin、multi、power、mushroom、flower、life、star、vine、bill-M、bill-S、bill-F、bill-L。Small顶出成长道具为蘑菇，Big顶出火花，这是现有Stage规则；mushroom/flower并不是强制覆盖当前力量的独立道具种类。Bill 武器在 Bill 主角下消费。

Brick 的 coin 与 multi 默认最多10次；普通 Block 的 coin 一次。已有 marioModules.rewardLimits 和 rewardWindows 保持原有数量与时间窗口语义，不在 content 中捏造 count 字段。vine 使用已有的藤蔓转场 portal，必须满足当前Stage寻找的 -vine-portal ID与砖块同x规则；缺少连接产生 CONTENT_VINE_CONNECTION warning，当前引擎不会生成无连接的活动藤蔓。静态藤蔓继续使用 smm2Mechanics.vines，不迁移为砖块内容。

content 属于硬块或非奖励地形时产生 CONTENT_OWNER；类型不支持产生 CONTENT_KIND；content 与已有 reward 不一致产生 CONTENT_ALIAS_MISMATCH。这三种错误都拦截导入、保存和导出。

## 兼容与升级

- 旧 reward-only 工程按原字节结构读写，不在读取时批量迁移、不改稳定ID或合集指纹
- 新编辑器写 content 时同时保存完全一致的 reward 兼容别名。新Stage以 content 优先读取，旧Stage继续读取 reward
- content-only 工程由本版消费者执行；旧工具会忽略 content，因此向旧版本交付必须带一致的 reward。这不是所有旧工具支持新字段的承诺
- marker.source.contents 与 semantics.source.contents 的旧格式、数组和关联仍保留并按既有消费者读取，不转写成未经实现的新content结构
- 修改 content 会真实改变工程与合集内容指纹，既有合集审核与测试凭据按原规则重新核验
- 旧非法独立金币不会被静默移到砖块content。导入时给出位置和ID，作者应在来源生成器或新的编辑副本中明确修正

完整工程、原生试玩和离线HTML保存藏物语义。区域map.json和通用开发数据包的闭合原生ABI不保存此作者行为，编辑器对此类导出显示说明并要求改用qmap或离线试玩。

validate/parseProject、History commit、单区域画笔/填充/对象放置/移动、工程save/export、projectPack、developerPack以及offlineFile检查确定非法位置。失败的作者操作整笔回滚；不会新增撤销步骤或覆盖本机有效草稿。复制/粘贴保留content与别名，并检查目标位置。合集重新导入和编译通过相同门禁。

```sh
node --test tests/material-placement.test.mjs
node scripts/verify-material-placement.mjs
node --experimental-vm-modules scripts/check-block-content-offline.mjs validation/material-placement-evidence/Legal_Block_Content_Playable.html
node scripts/audit-map-placement.mjs --root /path/to/maps --output placement-audit.json
```

可见证据输出在 validation/material-placement-evidence：实际editor.mjs的EditorCanvas、拒绝叠放红框、实际play渲染器的顶砖前／顶出中／顶出后、同一工程qmap和自包含Playable HTML。使用既有模拟DOM加真实raster Canvas，不是实体浏览器、CUA或硬件输入验证；模拟logo图像不作为像素证据。

审计脚本只读真实可读 *.qmap.json，按SHA-256去重并列出每个路径及当前分支课程／历史冻结／中性fixture类别。跳过symlink、依赖、VCS及私有运行目录，不修改历史工程。JSON报告保存issues、旧与显式合法content以及typed exemptions；相同SHA的多个拷贝不重复计为不同地图。
