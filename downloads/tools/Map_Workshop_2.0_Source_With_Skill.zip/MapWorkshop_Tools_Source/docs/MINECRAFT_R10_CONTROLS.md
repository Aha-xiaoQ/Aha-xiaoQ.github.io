# R10 input and responsive display

## Controls

- Keyboard: arrows / A D move; Space jumps; Shift, J or X runs; K attacks; L holds the shield; E or up/down interacts; Esc / P pauses. Enter replays after the ending; restart remains in the pause menu.
- Mouse: left button on the game canvas attacks; right button holds the shield. Menu clicks and context menus outside active canvas play keep their normal behavior. The mouse does not change facing or aim, which remain the existing movement / up-down aim rules.
- Standard Gamepad API: left stick or D-pad moves; A jumps and B runs. Auto / manual Nintendo layout places A on the right and B on the bottom. Left face button (Xbox X / Nintendo Y), RB/R or RT/ZR attacks. Top face button (Xbox Y / Nintendo X), LB/L or LT/ZL holds the shield. Start pauses; Select / Back mutes.
- Existing touch buttons remain available. Canvas touch/pen compatibility mouse events do not fire a mouse attack.

The starter primary is a short-range sword. The physical bastion chest pickup automatically upgrades it to the enchanted trident; there is no weapon cycling. Mario stays big. Shield stamina costs, trident damage, projectile trajectory and throw cooldown are unchanged. The requested consecutive-parry correction is described below. Throwing while guarding still lowers the shield under the existing combat rule.

## Starter sword

K / left mouse / the controller attack buttons start one directional sword swing: 14 ticks total, active on ticks 3–7, reach 30 world pixels, recovery 22 ticks and damage 0.5 versus the trident's 1. Holding never repeats. Each target can be hit only once per swing; rear, distant and wall-obstructed targets cannot be hit. Only actual local blade contact reflects a Ghast fireball. The sword has no projectile, enchantment or Loyalty return; bow and arrows are not enabled. Idle hands remain empty.

The upgrade cancels an unfinished sword swing. Continuing to hold attack through the pickup does not throw the newly acquired trident; release and press again. E / up interacts and trades; down is not a trade command.

## Mixed inputs and interruption

The freshest active directional source wins independently on each axis. Releasing it falls back to another still-held source. Within one device, simultaneous opposites are neutral. Actions combine across devices. Prompts change on a deliberate new action, not merely connecting a controller or keeping its stick held.

Mouse release outside the canvas, lost-buttons movement, canvas leave/cancel, pause, blur, hidden tab, restart and disconnect clear held input. Keyboard autorepeat after interruption cannot re-arm a cleared key. A held controller command on connect, reconnect or resume must be released before it can act. Mouse quick clicks are retained until a simulation tick; a held left button does not repeatedly throw after Loyalty returns. Closed sessions remove listeners.

## Fullscreen

Minecraft fullscreen / immersive display hides the bottom menu and fullscreen header. Esc / P and Start open the pause menu; its fullscreen action exits. Browsers may own Escape for native-fullscreen exit; the fullscreen-change path then pauses safely rather than leaving play running. Touch Start remains available when touch controls are shown.

Landscape uses a real expanded render field and matching canvas backing size. At 1920×1080 the logical field grows from 512×320 to 569×320, removing the former 96-pixel sidebars. 16:10 retains 512×320; 4:3 expands to 512×384. The render scale stays uniform, HUD uses the presentation dimensions, and the entire authored field remains visible. Pixel rounding can leave less than one display pixel unused. Native simulation, camera activation, saved input replay and collision dimensions stay 512×320.

Camera origins remain room-clamped. A room narrower than the expanded view uses textured decorative overscan beyond its edge: a dark geological side wall for caves and recessed distant soil for forests. Vertical expansion continues only strata that actually touch the authored bottom; open pits remain open. No traversable geometry is added. Portrait retains the full, readable authored landscape frame with touch controls below, rather than stretching or cutting off the field.

## Consecutive parries

The five-frame impact freeze now observes shield release / re-press while leaving world ticks, enemies, Mario, cooldown clocks and stamina frozen. At most one held raise waits for the next live frame. Releasing after a successful parry during its feedback period permits a prompt new timed raise; each raise still costs 6 stamina and each perfect parry 18, and its window remains eight live ticks. Holding the shield cannot create another parry.

During ordinary 18-frame release recovery, a fresh press can wait for that recovery to finish instead of disappearing. The buffer is bounded to that recovery period and is canceled by release, attack, pause, reset or leaving the room. The 90-frame exhaustion recovery remains intact. Tests against staggered authored zombies demonstrate three successive timed parries with keyboard, mouse and standard Gamepad input, then insufficient stamina for a fourth.

## Verification

Run:

    node --test tests/minecraft-desktop-input.test.mjs tests/minecraft-responsive-viewport.test.mjs tests/minecraft-responsive-boundary-art.test.mjs tests/minecraft-parry-input.test.mjs tests/minecraft-gear.test.mjs tests/minecraft-starter-sword.test.mjs tests/gamepad-input.test.mjs tests/play-screen-controls.test.mjs tests/clean-gameplay-ui.test.mjs

76 focused tests cover the R10 controls, starter sword, physical chest upgrade, display boundaries and consecutive-parry correction. Tests exercise the actual play module and native Stage using DOM keyboard / mouse events and an injected standard navigator.getGamepads surface, plus interruption and resizing paths. The offline exporter embeds the shared input and camera modules. These checks are simulated DOM / native Canvas evidence, not physical mouse/gamepad, real-browser layout or OS-fullscreen acceptance.

Native shared-Canvas render proofs are generated with scripts/render-minecraft-r10-responsive.mjs into the project evidence/r10-responsive directory: main, grotto and village at 16:9, 16:10, 4:3 and the retained portrait landscape field. The report labels portrait as a field render, not a fabricated mobile browser screenshot.
