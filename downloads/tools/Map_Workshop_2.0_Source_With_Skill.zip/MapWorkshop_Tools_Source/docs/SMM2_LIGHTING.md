# 马里奥地图工坊 2.0 · Explicit night lighting authoring

The optional `room.smm2Mechanics.lighting` leaf is disabled when omitted. It never changes Mario's motor, collision bodies, gravity, enemies, pickups, score or swimming. A `Night` setting alone neither installs this lighting component nor enables air swimming. Circular lights belong to Mario and explicitly bound stable targets; optional authored sweeping lamps are independent world-space fixtures. There is no automatic NPC/type eligibility list or dynamic pipe-source binding.

## Actual version-1 sidecar

```js
room.smm2Mechanics = {
  version: 1,
  lighting: {
    darkness: 0.94,
    playerRadius: 56,
    softness: 0.25,
    sources: [
      {targetId: 'placed-pow', radius: 56},
      {targetId: 'moving-platform', radius: 48},
      {targetId: 'fixed-arrow', radius: 32, offsetX: 8, offsetY: 8}
    ]
  }
};
```

These numbers are author approximations. No radius, falloff or complete light-source classification is asserted as a recovered Nintendo constant.

The authoritative validator is [editor-smm2-lighting.mjs](../atlas/editor-smm2-lighting.mjs), integrated by [editor-smm2-mechanics.mjs](../atlas/editor-smm2-mechanics.mjs). `darkness` is finite in `[0,1]`, `playerRadius` and each source `radius` are finite in `[8,512]` world pixels, and optional `softness` is finite in `[0,1]` with default `0.25`. Zero softness makes a hard circular edge; positive softness fades only the outer fraction of the declared radius. Sources are an array capped at 64, with unique safe stable target IDs. Unknown fields and unsafe keys are rejected.

### Optional real ON/OFF association

Observed SMB1 Ghost House Night ON→OFF transitions shrink the existing Mario, fixed P Switch and POW light windows together; a repeated transition supports the same rule. The ON/OFF switch itself is not an independent lamp. This observation establishes the direction of the change, not an exact radius or multiplier. All declared radii, softness and OFF scales remain author approximations; a visual size comparison is not a recovered original constant.

`lighting.offRadiusScale` is an optional finite number in `[0.05,1]`, allowed only when the same room already has `switchStudy.version:1`. For example, adding `offRadiusScale:0.5` requests an authored half-radius OFF appearance. It does not install a switch or alter its state. ON uses the unchanged declared Mario/source radii; OFF multiplies every resolved radius, including explicitly bound fixed arrows, by this scale. Centers, offsets, softness proportion and source visibility retain their existing rules. The final OFF radius may be smaller than the base radius's authoring minimum of 8 pixels.

Runtime resolution requires actual `view.switchStudy.version:1` and Boolean `view.switchStudy.on`. A missing, malformed or wrong-version live switch state returns no light sources, producing darkness rather than an invented initial state. It never falls back to author `initialOn`. Explicit editor `preview:true` uses only `room.switchStudy.initialOn`; live state is ignored for preview. Omitting `offRadiusScale` preserves the previous constant-radius behavior and does not require runtime switch data. This component never writes game state, switch state, collision or physics.

Targets are same-room preplaced `map.objects` except spawns, `map.geometry`, or fixed `markers` whose kind is exactly `source-arrow`. Native object and geometry sources use the current body's center, plus optional finite `offsetX`/`offsetY` in `[-512,512]`. A fixed arrow has an explicit authored anchor; both offsets are required and its center is `marker.x + offsetX`, `marker.y + offsetY`. No marker dimensions are guessed. Arrow artwork is still owned by the host's marker renderer.

Runtime lookup reads the matching room's actual `view.p`, `view.items`, `view.enemies`, `view.objects` and `view.geometry`. It never restores missing actors from initial author coordinates. Defeated, removed, collected, taken, dying, hidden and explicitly invisible bodies do not emit. POW item positions take priority over their collision proxies. Split native geometry uses the bounding box of its remaining live pieces with the authored `sourceId`; a fully removed body emits nothing. Fixed arrows respect `hiddenMarkers` and their own hidden/visible flags. Off-screen circles are clipped to the viewport.

## Creator API and native editor

[editor-smm2-authoring.mjs](../atlas/editor-smm2-authoring.mjs) re-exports:

- `setSmm2Lighting(room, completeConfig)` and `clearSmm2Lighting(room)`
- `setSmm2LightingOffRadiusScale(room, scale)` and `clearSmm2LightingOffRadiusScale(room)`
- `setSmm2ObjectLight(room, targetId, {radius, offsetX?, offsetY?})` and `clearSmm2ObjectLight(room, targetId)`
- `captureSmm2LightingBindings(room, selectedIds)` and `appendCopiedSmm2LightingBindings(room, snapshot, idMap)`
- `pruneSmm2LightingReferences(room, before)` and `SMM2_LIGHTING_AUTHORING_DEFAULTS`

The validated mutations are atomic. `setSmm2Lighting` requires an already existing `smm2Mechanics.version:1` room; its panel is disabled in legacy non-SMM2 rooms. It never creates a new SMM2 root or switches the host's existing player/pipe mode. Converting a legacy room into SMM2 format is a separate authoring decision: the existing host uses that root to select some player and pipe rules. Enabling and clearing lighting within an existing SMM2 room preserves that mode.

The OFF-scale setter requires lighting already enabled and the existing same-room version-1 ON/OFF component. It validates atomically and preserves all other lighting and room fields. Clearing removes only the association; absent association is a no-op. Complete lighting configs, object source edits, component clones, History, qmap import/export and collection compilation preserve the optional field. Clipboard source bindings do not carry room-wide settings such as the OFF scale into a destination room.

Bind lighting only after explicitly enabling it in the destination room. A copy contains selected target light bindings, not the room's darkness/player settings. The native editor carries and remaps those bindings in the same History transaction as its object/geometry paste; paste into a room with lighting disabled is rejected and rolled back. Movement follows stable targets automatically. Real deletion removes previously valid bindings. Newly introduced dangling bindings remain errors rather than silently repaired imports. Undo/redo restores the actual sidecar and its bodies together.

The native `夜间圆光（作者近似）` panel is implemented by [editor-smm2-lighting-tools.mjs](../atlas/editor-smm2-lighting-tools.mjs). It exposes enable/disable, darkness, Mario radius, softness, a real ON/OFF association checkbox and OFF multiplier, stable target selection, radius, offsets and source removal. Association controls require lighting and the existing same-room version-1 switch component; ordinary lighting apply does not insert an OFF-scale field. Checkbox, parameter updates and undo/redo use the same APIs and host History. Effect preview reads initial author positions and the initial ON/OFF state; structure and secrets views remain inspection views.

## Shared Canvas renderer and offline export

```js
drawSmm2LightingMask(ctx, room, stageView, {
  camera: {x: cameraX, y: cameraY, width: worldWidth, height: worldHeight},
  width: outputWidth,
  height: outputHeight,
  createCanvas // optional in browsers; inject a native Canvas factory in Node
});
```

Call in output coordinates after the world is drawn and before HUD. Supply the exact world rectangle used by that draw, including its camera rounding. Width and height are viewport/output dimensions, not world bounds. The native play renderer uses its real `Math.round` camera translation and draws HUD after the mask. The editor calls the same renderer with `preview: true` only in effect mode. The renderer restores Canvas state, caches one mask per output context, and supports an injected factory for the shared native Canvas/video workflow. It does not rewrite the caller's world or actor data.

`parseSmm2Lighting(room)` returns a normalized copy or `null`. `resolveSmm2LightSources(room, view, {preview})` returns world-centered `{targetId,x,y,radius}` records. Runtime resolution with an absent or different-room view returns no sources; preview must be explicit.

[editor-offline.mjs](../atlas/editor-offline.mjs) embeds the lighting module in both single-map and collection HTML dependency closure. The optional data travels in visual rooms, not the base platform-map ABI. qmap version 1, qcollection version 1, and pack `schemaVersion:1` remain unchanged. Existing projects with no lighting retain their previous behavior. Older strict SMM2 readers reject the new `lighting` field: use matching branch source/offline exports, or remove only the lighting leaf from a copy for rollback. That rollback removes this appearance effect.

Collections requiring the optional OFF scale declare `switch-linked-night-lighting-v1`, in addition to `explicit-night-lighting-v1` and `switch-study-v1`. A reader that supports initial lighting but predates the OFF-scale extension rejects that unknown field. Remove only `offRadiusScale` from a copy to retain constant-radius lighting for that reader; this rollback removes ON/OFF appearance association. Matching single-map and collection offline exports embed and run the same real switch/light code.

## Optional authored sweeping lamps

`lighting.sweepingLamps` adds appearance-only light sectors. This is an original
workshop feature, not a claimed Neon Abyss or Nintendo spotlight mechanism.
Omission preserves the previous circle-only behavior.

```js
sweepingLamps: [{
  id: 'ceiling-lamp', x: 328, y: 220,
  length: 184, halfAngle: 10,
  minAngle: -28, maxAngle: 28,
  periodFrames: 240, phaseFrames: 0,
  enabledWhenOn: true
}]
```

The list has at most 16 independent unique safe IDs, distinct from existing
actor/terrain/light targets. Lamp coordinates must be finite and inside the
map. Length is finite in `[8,1024]` world pixels. Half-angle is finite in
`[1,60]` degrees; angle endpoints are finite in `[-85,85]`, ordered, and the
entire cone must remain below the horizontal. Angles run clockwise from
downward vertical, so negative angles point right and positive angles point
left. `periodFrames` is an integer in `[2,36000]`; optional `phaseFrames` is an
integer in `[0,35999]`, default 0. The optional Boolean `enabledWhenOn` defaults
false. Unknown fields, malformed values and duplicate IDs are rejected.

The angle follows a cosine round trip between the two endpoints, using only
the actual nonnegative integer `view.tick` plus the configured phase. A paused
or repeated render at the same tick produces the same pixels; neither parsing
nor drawing advances simulation. Runtime requires the matching room and an
actual tick. A gated lamp also requires existing `switchStudy.version:1` and
actual `view.switchStudy.version:1, on:true`; missing or malformed switch data
does not fall back to initial ON. Explicit effect preview uses tick 0 and the
authored initial switch state. `offRadiusScale` controls circles only; a gated
lamp disappears in OFF rather than becoming a smaller circle.

`resolveSmm2SweepingLamps(room, view, {preview})` returns normalized world-space
`{id,x,y,length,halfAngle,angle}` poses. `drawSmm2LightingMask` cuts these sectors
out of the same mask as circular lights, with the same camera and output
scaling. Softness fades the outer radial portion of the sector. A declared
darkness of 0.86 leaves approximately 14% ambient brightness outside all lights;
this value is an author choice, not a recovered original setting.

The lighting tool panel provides stable lamp selection, add/update, position,
cone/period/phase, real ON gating, copy by a 16px offset, and delete. Its mutations
use the existing host History and strict room validator. The authoring module
exports `setSmm2SweepingLamp`, `clearSmm2SweepingLamp`,
`cloneSmm2SweepingLamp`, `captureSmm2SweepingLamps`,
`appendCopiedSmm2SweepingLamps` and
`SMM2_SWEEPING_LAMP_AUTHORING_DEFAULTS`. Explicit copy remaps stable IDs and
translates fixture coordinates; whole-room clone preserves its independent
lamps. Ordinary actor/terrain copying and deletion leave unrelated world lamps
alone. Deleting a selected lamp is explicit and undoable.