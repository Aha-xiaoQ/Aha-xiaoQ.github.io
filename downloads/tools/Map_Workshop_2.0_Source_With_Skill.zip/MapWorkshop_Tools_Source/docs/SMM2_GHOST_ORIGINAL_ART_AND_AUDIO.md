# 马里奥地图工坊 2.0 · SMB1 鬼屋素材与夜间曲

本批用于私人机制学习与离线工程。原图片和音乐由 Nintendo 享有权利，独立于工坊代码许可。原始响应、真实格式、尺寸、调色板及 SHA-256 在 [SOURCE_ASSETS](../atlas/assets/smm2-ghost-private/SOURCE_ASSETS.json)。没有把公开视频截图裁为运行素材。

区域图像风格 `smm2Mechanics.art.palette = "smb1-ghost-source"` 已接入编辑器风格选择、共享渲染与离线模块闭包。原地块复合图是公开图鉴作者排列的素材示例，不能当作课程地图；运行时只取其中真实 16px 砖纹与内填充纹样，按作者地形选择边缘/内部并保持世界格原点。地块相接和斜坡铺贴是适配。

木板背景 `ghost-timber-backdrop` 复用原竖木板图案。粗横梁 `ghost-timber-beam` 是依据已照亮画面重建的近似。两者只用于装饰层，绘制一次，没有碰撞体。`ghost-timber-semisolid` 必须由作者另行声明真实顶面碰撞；下方木纹不创建隐形墙。

咚咚保留原 24×32 图像比例；巨型显示为整数 2 倍 48×64，并在独立物理体中居中、底锚。刺壳原 16×15，同样按原比例底锚。POW 使用真实 16×16 黑芯白字原图。这些图片来源是 SMM1 SMB1 的单帧，与已见 SMM2 家族匹配；尚无完整原步态、怒脸或闪烁表，不声称整套 SMM2 动画已提取。

运行像素使用 PNG 原调色板 RGBA。POW 的 gamma 元数据会使部分管理色彩的 PNG 解码器把原 `#030303` 转成 `#000000`、原 `#4242ff` 转成 `#4040ff`；原始文件仍保留。原像素测试比较原索引色、尺寸和透明轮廓，不把这种解码器差异当作补绘。

夜间曲选择只在 setting 同时包含 Ghost House（或 GhostHouse）和 Night 时启用。使用正确 SMM2 SMB1 Ghost House Night 公共 30s 样本中的一个经波形重复分析支持的 21⅓s 周期，派生为本地 PCM WAV，在 HTML 内嵌、播放音量 0.35。原样本和来源保留；[循环出处](../atlas/assets/classic-audio/GHOST_NIGHT_LOOP_PROVENANCE.json) 记录准确裁切样点、客观接缝及限制。

预制 WAV 已随包提供，安装/构建不需要 Python。只有重新生成音频时才需 Python 3、NumPy 和 ffmpeg，并运行 `python3 scripts/build-ghost-night-loop.py`；该脚本只读取包内样本，不联网。