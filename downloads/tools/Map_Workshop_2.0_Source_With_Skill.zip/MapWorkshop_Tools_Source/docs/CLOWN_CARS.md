# 马里奥地图工坊 2.0 · Original normal Clown Car controller

`atlas/editor-clown-cars.mjs` is an optional reusable vehicle controller in the map workshop. It approximates the ordinary white Koopa Clown Car with local tunable motion. It does not claim Nintendo's exact acceleration, collision hull, bob period, or seating rules.

The original final-puzzle stills were inspected directly. The first car is empty above the upper platform. The misleading `source-room5-player-car-flight.jpg` still has a live Goomba in the car and Mario on the lower floor. In `source-room5-player-boards-car.jpg`, Mario has actually stomped the occupant, the Goomba is flipped out, and the native score pop is 200. The next flight still has Mario in the car. Two fixed DOWN one-way walls permit the vehicle to cross from the upper area to the lower corridor. Flight then passes three alternating spike columns before the real flagpole.

## Authoring

Add optional `room.contraptions.cars` entries. Coordinates are world pixels and `x/y` are the cup body's top-left. Shared contraptions fields remain the enclosing controller's responsibility.

```js
{
  id: 'normal-car', x: 128.8, y: 99.2, w: 32, h: 28,
  bobPixels: 2, bobPeriodFrames: 120,
  npcAcceleration: .035, npcMaxSpeed: 1.05,
  playerAcceleration: .065, playerMaxSpeed: 2.25,
  drag: .055, occupantOffsetY: -12, boardingTolerance: 4
}
```

Only `id/x/y` are required; the remaining shown numbers are defaults. Dimensions, room bounds, unique IDs, tuning ranges, and unexpected car fields are validated. An absent/empty car list returns `null`, preserving the ordinary native path.

## Native integration

```js
const cars = createClownCars(room, {emit});
cars?.step({tick, player, enemies, geometry, input, oneWayWalls});
if (!cars?.ownsPlayer()) nativePlayerMotor();
for (const enemy of enemies) {
  if (!cars?.ownsActor(enemy)) nativeEnemyMotor(enemy);
  nativeStompAndDamageContacts(enemy);
}
cars?.sync({player, enemies, geometry});
```

Pass current native geometry, including moving platforms and switch materialization, and normalized `input.x`, `input.up`, `input.down`, and `input.jumpPressed`. Optional `input.y` is a signed vertical axis. `step` advances only once for each numeric tick. The post-motion `sync` does not advance time: it observes real descending contacts and occupant death. Pass the actual live native actor objects, rather than view copies. Held claw actors should expose `clawHeld`, `clawHeldBy`, `clawId`, or `heldByClaw`, or supply `isHeld: actor => claws.held(actor)` to `step/sync`. They cannot enter until released.

A falling Goomba enters only through the opening by geometric descending contact. The controller then owns its movement, sets `clownCarId/vehicleId`, and keeps it alive, centered on the vehicle. Native contact, stomp, damage, and enemy-death handling still run. Direct NPC acceleration chases Mario; an upper platform physically stops descent until Mario leads the vehicle horizontally to the actual opening. There is no route planner or room-completion trigger. When native combat marks the occupant dead, `sync` vacates the car without moving or deleting it.

Mario also requires genuine descending contact with an empty opening. Proximity from below, rising contact, occupied cars, and a solid/one-way platform between him and the opening cannot grant a ride. While riding, his real position follows the vehicle. Big Mario retains his native dimensions. Jump press ejects from the current real pose with the vehicle's horizontal velocity and an approximate native jump impulse; native motion then resumes. Death/dying or actor replacement releases occupancy without changing death velocity.

`disembark(player, {reason:'goal'|'hurt'|'manual', jump:false})` explicitly releases Mario before native flag sliding, hurt, or manual handling. It leaves the car at its current position, removes `vehicleId/clownCarId`, and preserves Mario's current geometry and velocity, including adjustments the native caller has already made. It emits one physical `eject` event with the supplied reason. A repeated call returns `false` and has no effect. Optional `jump:true` adds the approximate jump impulse; goal/hurt callers use `false` and retain full native responsibility for progression, damage, and lives.

The cup and protruding occupant each use swept terrain contacts. Solids block both directions; native `collision:'oneway'` platforms stop falling and allow rising. Separate direction walls support DOWN, UP, LEFT, and RIGHT: their named direction is allowed, and the opposite direction is blocked. DOWN permits falling and blocks upward return. Vehicle movement remains inside room bounds. Hazards, damage, coins, score, lives, room progression, and goal activation remain native responsibilities. Use `contactBody(player)` or each rendered car's `contactBody` for full vehicle hazard contact, so the large cup cannot pass a spike merely because Mario's smaller body misses it.

`view()` returns `{version:1,cars:[...]}` with authored fields, physical `x/y/vx/vy`, `occupancy:'empty'|'npc'|'player'`, `occupantId`, an actor pose snapshot, the opening, and full contact body. Native rendering draws the cup separately from its live seated actor. `ownsActor(actor)` and `ownsPlayer()` report current occupancy. `contactBody(actorOrCarId)` retrieves the corresponding physical envelope; with no argument it retrieves Mario's currently ridden cup.

An initially empty car gently bobs around its authored origin. After an occupant leaves, it bobs locally around the vacated position, preserving the accessible delivered vehicle. It never teleports back to the upper platform. `reset()` releases actor metadata, restores the authored empty position, clears motion and contact history, and clears the per-tick guard.

## Optional NPC Spike Trap panic

The official [FUN 2024 paper, *Undecidable Mario Games*, section 4.2 and Figure 20](https://drops.dagstuhl.de/storage/00lipics/lipics-vol291-fun2024/LIPIcs.FUN.2024.22/LIPIcs.FUN.2024.22.pdf#page=17) describes a car carrying a falling enemy reacting to spike contact by panicking and flying upward, and shows a Goomba riding the upward car in actual play. Section 4.2 covers the four ordinary 2D SMM2 styles. This evidence does not establish equivalent Mario-piloted behavior, the exact speed/acceleration, duration, or exit condition. The following is an explicitly authored, uncalibrated local approximation.

Enable it for a particular car by adding an object:

```js
npcSpikePanic: {
  acceleration: .125,
  maxSpeed: 2.75,
  durationFrames: 90,
  horizontalDrag: .1
}
```

An empty object explicitly opts in to these local defaults. Omitting `npcSpikePanic` preserves the previous car behavior and view shape. Only these four tuning keys are accepted. Acceleration is pixels per active frame squared in `[.001,2]`; upward max speed is pixels per frame in `[.01,8]`; duration is an integer number of active motion frames in `[1,3600]`; horizontal braking is pixels per frame squared in `[0,1]`. These ranges are validation bounds, not observations of Nintendo's implementation.

The parent must identify actual Spike Trap geometry with `{collision:'solid',spikeTrap:true}` and pass it through the existing `geometry` argument. No additional stage callback is needed. Generic hazards, hidden geometry, or unmarked solid obstacles do not trigger this model. Only the physical cup body triggers it; a passenger touching a trap while the cup is separated does not. Positive edge contact and contacts produced by the existing swept movement both count. Point-only corner adjacency does not count. A previously empty cup that acquires a live NPC while already touching a trap can react as a newly loaded vehicle.

Panic operates only during `occupancy:'npc'`. The enemy remains alive, seated, and available to native combat. The model brakes horizontal velocity toward zero and approaches negative `maxSpeed` with `acceleration`, retaining real position and momentum. A sideways cup collision redirects the vertical target in that frame. A falling cup collision starts the episode for the next motion frame. There is no positional jump or scripted route. The existing cup/passenger swept collision continues to enforce solid terrain, room bounds, and directional walls; a ceiling or DOWN wall sets upward velocity to zero instead of allowing the vehicle through.

The configured episode lasts exactly `durationFrames` active panic motion frames, including frames blocked by terrain. At expiry, ordinary NPC chase resumes from the current velocity and changes it with ordinary `npcAcceleration`; expiry itself adds no stop impulse. Continuous contact with the same spike cannot refresh or restart the timer. After separation, a new trap contact may start another episode. Occupant vacancy cancels panic immediately. Reset clears the timer and contact latch and returns the cup to its authored empty origin. Repeated numeric ticks and `sync` do not advance the timer.

Opted-in car views additionally expose `npcPanic:{active,remainingFrames,triggerSpikeIds}`. Unconfigured cars expose none of these fields. Events `npc-spike-panic-start` and `npc-spike-panic-stop` use the existing `clown-car` event channel with physical positions; start includes spike IDs and stop gives `duration` or `vacancy`. This controller still performs no hazard damage, enemy death, score, lives, or finish changes, and does not apply this NPC response to Mario-piloted or empty cups.