# 马里奥地图工坊 2.0 · 关前委托（missionBrief version1）

入口区域可存 missionBrief，必需字段为 version:1、number(1..999)、title(1..80字)、description(1..240字且最多5段)、client(1..80字)、difficulty(1..4)、rewardCoins(0..99999)。它是规则教学和任务信息，不参与金币、分数、生命或存档经济。可选rewardPresentation="reference-already-claimed"只用于把参考报酬数字变灰，不表示离线玩家获奖；来源说明应放版本页。

编辑器面板支持应用、移除、撤销重做、导出再导入；离线试玩含同一个Canvas renderer与可读的无障碍文本。开始/Enter/空格/手柄A或Start确认；开始键必须释放后才能成为跳跃输入。初次Esc/B/关闭返回封面；关内重看时关闭返回原现场。读取时暂停本地世界，不伪装重置奖励，150参考值不会进入携带数据。

模板没有missionBrief时保持原有入口。合集源元数据声明mission-brief-v1，不包括Toad故事Hub、Nintendo全部菜单、按开始的未知动画或原作报酬系统。
