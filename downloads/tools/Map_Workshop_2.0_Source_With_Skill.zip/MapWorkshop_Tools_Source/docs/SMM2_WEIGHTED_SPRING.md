# 马里奥地图工坊 2.0 · Weighted Springboard on a seesaw

This opt-in workshop mechanism uses one existing native solid Springboard as
its actual gravity body, collider, compression body and weighted terrain actor.
It adds no invisible mass proxy, rigid mount, source-offset reset, extra player
jump force or course script. The new neutral example is a mechanism acceptance
fixture, not a Nintendo course reconstruction or a new finished course.

## Source and tuning boundary

Public qualitative references support a spring resting at a seesaw end and the
other end lifting it. The complete Story 32 video was not obtained. Story 32 is
the course number; the available public local-reference set contains 12 screenshots,
not 32 screenshots. This qualitative set does not calibrate mass, gravity, angular velocity,
impulse timing or original handling. Nintendo's palette describes seesaw tilt
by end weight and configurable length, and vertical/horizontal springs with
style-dependent carrying. Every numerical parameter here is a workshop
approximation. SMB1 hand pickup is not added.

- [Nintendo palette](https://www.guiasnintendo.com/2c-switch/super-mario-maker-2/guia-super-mario-maker-2/paleta-elementos.html): Balancín 546, Trampolín 508
- Existing native Springboard collider/compression is reused. The new explicitly
  typed SMB1 drawing uses an original 16×16 standing PNG from Super Mario Maker
  (2015), Super Mario Bros. style, hosted by
  [MarioWiki](https://www.mariowiki.com/File:SMM-SMB-Springboard.png). Its original
  245 PNG bytes and standing RGBA are preserved. Compressed views adapt the
  original cap/coil rows to the actual live body height; they are authored
  visual adaptations. No original compressed GIF/frames or complete SMM2
  animation sheet was obtained. Reference screenshots are not runtime textures
- The 32×32 option is a uniform author 2× adaptation. Drawn pixels remain inside
  the real rounded body top and bottom. Nintendo image rights remain separate
  from code rights and are limited to the documented private learning scope;
  see [asset provenance](../atlas/assets/smm2-spring-private/SOURCE_ASSETS.json)
  and [notice](../atlas/assets/smm2-spring-private/NOTICE.txt)
- Existing native bounce emits `jump` / `jump_super`; no new Spring sound alias
  was invented, and a source-specific original Spring SFX is not established

## Explicit schema, version 1

Legacy `{id, carrierId}` bindings retain the existing moving rectangle/Thwomp
semantics and defaults. A seesaw requires this explicit new typed leaf:

```js
carrierGeometry: [{
  id: 'spring', carrierId: 'board', carrierType: 'seesaw',
  mass: 2, gravity: .3, maxFallSpeed: 4.25
}]
```

`mass` is required in `.001..10000`, `gravity` in `.001..4`, and
`maxFallSpeed` in `.001..64`. The child must be a same-room existing independent
vertical native solid Springboard with a square 16×16 or 32×32 rest body, without motion/liftSpeed. The 32×32 option is an authored 2× adaptation, not an established original Spring variant. The parent must be
a real `smm2Mechanics.seesaws` leaf. The Spring's source bottom must touch the
highest actual point of the finite rotated initial seesaw top under its foot
span. Unknown fields, ambiguous/native-alias parent IDs, unsupported child
types, dangling references, duplicates, self-links and nested/cyclic bindings
are rejected. No `allowOverlap` field exists.

The qmap/qcollection/pack version remains 1. New-aware importers are required
for typed seesaw bindings; older strict carrier readers reject the new fields.
No migration is required for old two-field bindings. Native `map.geometry`
receives no authored mass/carrier fields; author data lives in visualRooms and
complete qmap/pack exports as before.

## Actual physics and support

`createSmm2Carriers(room,{terrain})` requires the live terrain port for a typed
seesaw child. `physicsActors(geometry)` returns the same real Spring collision
object, decorated with its own mass, velocity, grounded/support state and
standable identity. Only those explicitly typed Springs enter the terrain
actor list; static/legacy Springs remain outside it. The host includes these
same objects in both terrain `beginFrame` and `finishFrame`.

The existing terrain root walk verifies every finite foot/top contact. A player
on the Spring contributes the player's own mass exactly once through the real
Spring support; the Spring contributes only its own mass. Walking/jumping away,
airborne motion, dead bodies, invalid support IDs, removed real geometry and
separated feet do not add a load or receive an invisible launch. Same-object
repetition is deduplicated; distinct duplicate actor IDs are rejected.

Spring gravity uses exact rectangular/shaped sweeps and the terrain's measured
rotated top. An upward board can push it through a swept reachable path. A
downward board that outruns the body's gravity loses contact instead of pulling
it down. The free body can recontact a real board, fall off its finite end, land
on an actual floor, or leave the room. Its source offset is never a recovery
target. Unsupported headroom clears board contact rather than retaining fake
weight. A removed owned body stays removed until a real host reset.

A true downward Thwomp sweep records its original incoming speed. The existing
terrain impact path launches the opposite actual Spring and all actual standers
in the support chain once. New typed weighted rooms then settle loads from the
updated actual grounded/support chain, so airborne bodies leave no end-frame
weight or next-frame cached torque. This engine-only `settleImpactLoads` option
does not repeat an impact, actor movement or board rotation; legacy rooms retain
the existing default behavior. A nearby player receives no impulse. The airborne
Spring retains its own velocity, and the native compression lock releases the
now-airborne player. Relative free-Spring top contact prevents adding the
Spring's entire displacement a second time to the player's own native motion.
The native motor and normal/high Spring launch constants are unchanged.

Native compression preserves `y+h === restY+restH`. Real top expansion and
transport are swept against headroom. A co-launched stander that hits a real
ceiling bounds the Spring's actual advance at reachable feet, preserving the
bottom anchor through physical translation. This establishes bounded collision
behavior, not original SMM2 crush timing or a new damage/pickup policy.

The host APIs additionally expose `geometryForPlayer`, `positionSpringRider`,
`afterCompression` and `afterFrame` for this narrow ordering adaptation. Canonical
Spring geometry remains solid. Only a proven rising free top approached from
above becomes a one-way collision view during the native motor pass, so its
already pre-stepped side cannot stop unrelated airborne horizontal movement.
Velocity, damage, bounce, reset and room lifecycle remain owned by Stage.

## Author workflows and placement

`bindSmm2SpringSupport(room,springId,carrierId,options)` accepts the explicit typed
settings; the original three-argument form still writes the exact legacy pair.
The sidebar exposes existing seesaws, type selection and approximate numerical
settings. Existing native Spring tuning remains separately editable.

The historical Spring paint brush creates a 16×29 body. An explicit author
`setSmm2SpringRestBodySize` action prepares a 16×16 or author 32×32 rest body while retaining
its source bottom; the old paint behavior remains intact. The separate
`alignSmm2SpringToSeesawSupport` action moves only authored Y to the true initial
rotated top and writes the typed binding in one History transaction. Ordinary
bind does not move a body. No foot overlap, unsupported source dimensions and
invalid settings fail atomically; undo restores the source pose and old leaf.
These are visible author edits, never runtime alignment or teleport.

`captureSmm2SupportGroup`, `pasteSmm2SupportGroup` and
`removeSmm2SupportGroup` support explicit complete carrier groups. They translate
real geometry/pivot coordinates, remap all IDs and preserve bindings, Spring
tuning and lights inside the existing atomic History transaction. Repeated paste,
erase, undo/redo and qmap roundtrip are tested. A copied lone native Spring is
independent; ordinary geometry-layer copying retains a moving-platform link
only when both real bodies are copied. Deleting a seesaw alone prunes its links
while preserving native Springs.

A validated typed child has placement type `gravity-spring-body`, expressing
its actual moving-body lifecycle. A static Spring remains permanent solid;
a malformed/dangling tag cannot grant a placement exemption. Source bounds,
rotated top contact, existing permanent material gates and group mutations all
use the shared validators. There is no unrestricted overlap override.

## Repeatable neutral evidence

- [Editable example](../examples/weighted-spring-seesaw.qmap.json)
- [Opposite-weight lift](../examples/weighted-spring-seesaw-lift.qmap.json)
- [Finite-support drop](../examples/weighted-spring-seesaw-drop.qmap.json)
- [Existing POW support chain](../examples/weighted-spring-seesaw-cargo.qmap.json)
- [Fixture and ordinary-input assertion](../tests/fixtures/weighted-spring-seesaw.mjs)
- [Runtime tests](../tests/smm2-weighted-spring.test.mjs)
- [Actual editor/authoring tests](../tests/smm2-weighted-spring-authoring.test.mjs)
- [Single/collection offline tests](../tests/smm2-weighted-spring-offline.test.mjs)

The default fixture begins at its authored native spawn and sends `{}` only.
At tick 10, a real Thwomp impact has incoming speed 6.4 and launches the real
Spring plus its actual stander at 7.6. At tick 11, both remain airborne and the
player's feet match the actual Spring top, without duplicate carry or a fake
bounce sound. Alternative neutral fixture settings place the player on the
opposite end to lift the Spring by actual weight alone. The tests also cover
Small/Big blocked headroom, native normal/high bounce, departure, floor landing,
source rotation, removed bodies, automatic death reconstruction, room transfer,
strict schema, mass ownership and editor transaction handling.

The four source-only scenes contain 89 ordinary `{}` inputs: impact 11, lift
24, finite-support drop 30, and existing POW cargo 24. The cargo scene physically
balances the real POW→Spring→board chain: Spring mass 2 plus POW mass 1 on the
left, player mass 1 on the right, with actual lever moment 0. This is a real
load/support-chain proof, not a unified NPC Spring bounce implementation. NPC
Spring bounce remains unimplemented. All fixtures use the same 384×240 actual
Stage viewport with camera anchor 192 so both ends and the real impact are
visible in playable export and video. No alternate video camera or runtime
state injection is used.

`node scripts/verify-weighted-spring-native.mjs [output-directory]` rebuilds the
four editable qmaps and full per-frame body/terrain/controller acceptance data.
The offline checker executes the actual embedded modules for every scene and
compares canonical trace, events and terminal view exactly with native source.