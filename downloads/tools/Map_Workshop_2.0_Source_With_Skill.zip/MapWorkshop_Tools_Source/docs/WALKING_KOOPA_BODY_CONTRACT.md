# 马里奥地图工坊 2.0 · Opt-in Walking Koopa body helpers

`atlas/editor-walking-koopa.mjs` provides deterministic helpers for an explicitly authored Walking Koopa. It does not register a qmap field, replace Stage movement, manage rewards, or implement a course. The host must integrate it with its strict persisted enemy-variant schema and actual collision branches.

The observed SMM2 SMB1 red Koopa behavior establishes ordinary and giant walking forms, a one-stomp occupied shell, a living inverted shell after an impact from below, recovery, a same-scale shell kick, and moving giant-shell Hard Block destruction. Numeric motion, hitboxes and universal recovery constants have not been recovered from game binaries. The API calls its body geometry an authored contract and requires `sourceParameterStatus: 'authored-not-calibrated'`. An observed sample of about 9.166667 seconds can justify an authored 550-frame fixture at 60 Hz; it does not establish a universal original timer.

## Variant

The fields below are required. Unknown fields are rejected. An optional `avoidLedges: boolean` is an explicit author override; omitting it keeps the color default (red avoids ledges, green does not). It does not establish a new original-game rule for giant Koopas.

```js
{
  kind: 'walking-koopa',
  color: 'red',                  // red | green
  size: 'giant',                 // normal | giant
  walkSpeed: 0.5,                // > 0, finite, <= 8 px/runtime frame
  direction: -1,                // -1 | 1
  flippedRecoveryFrames: 550,    // integer 1..36000, authored
  shellRecoveryFrames: 600,      // integer 1..36000, authored
  stompPoints: 200,              // integer 0..100000
  kickPoints: 200,
  bumpPoints: 200,
  sourceParameterStatus: 'authored-not-calibrated'
}
```

The authored native walker must be 16×24 for `normal`, or 32×48 for `giant`. Its occupied shell is respectively 16×16 or 32×32. Conversions preserve the body center and feet. These sizes are separate from source-sprite opaque bounds and do not claim recovered original collision dimensions.

World terrain collision uses a separate authored lower-body profile: 16×16 for normal and 32×32 for giant, anchored to the same center and feet. The full 16×24 / 32×48 walking body remains available for player/enemy contact and native authoring. This profile fits the directly observed giant traversal through a 32-pixel-high passage; that observation establishes the need to distinguish world collision from the visible upper body, not the exact original binary hitbox. The standing source artwork remains 16×23 (32×46 at giant scale), with its existing foot anchor; terrain does not stretch or shrink those pixels.

`validateWalkingKoopaVariant(rule)` checks the portable rule. `validateWalkingKoopaVariant(room,id,rule)` also checks that the matching native walker exists, has the correct body and fits within the room. `walkingKoopaBody(rule)` describes both forms.

## Pure results and host responsibilities

Lifecycle calls return `{handled, changed, actor, points, events}` and leave the input actor unchanged. Commit `result.actor` before processing the next contact. Actor state under `smm2WalkingKoopa` is plain JSON-compatible data; snapshots need no registry or hidden timer.

```js
Object.assign(liveActor, result.actor);
```

Event `transitionId` is stable after JSON snapshot/restore. The host must scope its reward ledger by room/attempt, deduplicate the event, then add points and feedback exactly once. A helper cannot deduplicate callers that discard its returned state.

- `applyWalkingKoopaVariant(actor,rule,{tick=0})` decorates an authored walker; reapplying an identical variant to restored state preserves its phase and clock
- `transitionToKoopaShell(actor,{cause:'stomp'|'topple',tick,launchSpeed,horizontalSpeed})` converts a walking body; `topple` requires an explicit positive finite launch speed up to 16 and clears support/grounded state. It preserves actual `actor.vx` unless an explicit signed finite `horizontalSpeed` within −8..8 is supplied. Stomp still makes a resting shell with zero horizontal speed
- `kickWalkingKoopa(actor,{direction,speed,tick,safeFrames=0})` kicks an upright resting occupied shell and returns its configured kick points; speed is explicit, positive, finite and at most 16
- `stopWalkingKoopaShell(actor,{tick})` stops a rolling shell, resets its idle recovery and awards zero helper points
- `recoverWalkingKoopa(actor,{tick,canStand})` advances authored recovery by runtime tick deltas; duplicate/old ticks do nothing, rolling upright shells reset their idle clock, and missing or blocked clearance keeps the living shell. Moving inverted shells continue aging and retain their latest actual horizontal direction through a stationary landing for recovery
- `koopaView(actor)` supplies the full contact `body`, separate foot-anchored `terrainBody`, scale, color, phase and render dimensions, a bottom-center anchor and a center pivot with `flipY` for inversion
- `walkingKoopaTerrainBody(actor)` returns only `{x,y,w,h}` for a living owned actor's native-world adapter; shell terrain matches its shell body. Emerging, unsupported, hidden or defeated actors return `null` so the host can retain its ordinary fallback

Gravity, floor landing, edge probing, wall rebounds, contacts, sound, score popups, and key ownership stay with the host. The helper preserves key metadata and never emits enemy defeat. `source.red` describes color. `source.smart` and the view's edge-avoidance descriptor use an explicit `avoidLedges` override when supplied, or the red/green default otherwise. The host must distinguish those owned behavior and palette fields when probing ledges. Legacy enemies without this explicit state are unaffected.

Repeated impacts on an existing shell produce no invented bump reward or timer restart. Flipped-shell kicking is not established by the inspected behavior and is not introduced. The host owns the physical flight and stationary landing; no perpetual bounce is injected. The helper does not decide pipe cycles, conveyors, Spring physics or animation timing.

## Typed Hard Block side impact

`hardBlockBreakEligibility(actor,solid,{before,tick,points})` returns a request with `{eligible, solidId, points, contact, events}`. It needs the actual previous body pose, explicit contact points, a living moving giant upright shell, and a swept horizontal contact with the specified typed Hard Block. It rejects initial overlap, vertical-only motion, wrong-facing motion, small or flipped shells, distant blocks, untyped Stone, Brick and Ground. `points: 10` matches the inspected per-block feedback; the helper requires it explicitly rather than declaring a universal style rule.

The host removes only that contacted collider, persists its tile ID for the attempt, emits debris and continues the shell motion. The helper does not remove geometry, reverse velocity, consume keys or pre-open an exit.

```sh
node --test tests/walking-koopa.test.mjs
```

Original game footage/screenshots remain separate copyrighted source material. The new helper, tests and this documentation follow the project code license; this does not extend permission over original assets.
