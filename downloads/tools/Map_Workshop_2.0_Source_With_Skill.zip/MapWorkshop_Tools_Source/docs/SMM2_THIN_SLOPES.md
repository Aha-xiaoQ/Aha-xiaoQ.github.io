# 马里奥地图工坊 2.0 · Finite diagonal slope strips

## Authoring fields

A slope still requires `id`, `x`, `y`, `w`, `h`, `orientation` and
`collision: 'solid'`. Optional `thickness` is a finite number in 0.1–1024.

- `w` is the horizontal run
- `h` is the diagonal's positive vertical difference, never strip thickness
- `y` is the smaller y coordinate of the named diagonal's endpoints
- `thickness` is the vertical distance between two parallel diagonal edges,
  not distance measured perpendicular to the slope
- `rise-right` names endpoints `(x, y+h)`, `(x+w, y)`; `rise-left` names
  `(x, y)`, `(x+w, y+h)`
- Floor strips (`rise-*`) keep that diagonal as the standable top and extend
  down by `thickness`
- Ceiling strips (`ceiling-rise-*`) keep that diagonal as the solid underside
  and extend up by `thickness`; their real standable top is diagonal too

The polygon is the real top's left/right endpoints followed by the underside's
right/left endpoints. Bounds include the entire strip. A floor needs
`y+h+thickness <= map.height`; a ceiling needs `y-thickness >= 0`.
`x+w <= map.width` and the existing positive run / rise limits also apply.
Neither representation creates solid terrain outside this four-vertex strip.

Neutral example: `{id:'finite-ramp', x:96, y:96, w:128, h:64,
thickness:12, orientation:'rise-left', collision:'solid'}` has a 1:2 diagonal,
not a 12-pixel height triangle.

`addSmm2Component(room, 'slope', options)` and
`updateSmm2Component(room, id, options)` use the same strict validator.
`updateSmm2Component(room, id, {thickness:null})` removes the optional field.
`null` is only an API clear instruction; persisted JSON rejects it. Omitting
thickness during update preserves an existing value. The sidebar number field
starts blank, accepts a real positive value, and blank clears it. Cloning
preserves thickness / orientation and moves its anchor. Deletion and invalid
operations retain normal atomic History / undo / redo behavior.

## Collision and rendering

`surfaces()` reports authoritative `a/b` top endpoints, `underside.a/b`, exact
`polygon`, `solidAbove`, orientation and copied authored spec. Both normal and
SMB3 generic renderers draw the actual polygon including portions outside the
old `y..y+h` diagonal rectangle. The editor structural preview and thumbnail
also use actual strip bounds. No new terrain textures are supplied here.

The existing continuous SAT sweep handles every face of the convex strip.
Native small and Big player bodies follow the top and hit the correct diagonal
underside from below; empty space beneath stays passable. Thin floor strips can
act as ceilings for a body approaching their underside, including lateral head
contact. A rolling live shell uses its actual native body and velocity.

The engine-only `followSlopeTop(actor, before, {tick, geometry})` returns a
reachable `{solidId,body}` preview after horizontal motion on a genuinely
supported explicit strip, or null. It never moves actors or grants contact.
The native Stage applies this top height before the usual enemy rectangle wall
check, so an uphill flat-platform join does not falsely reverse a shell before
its necessary lift. Whole-body obstruction by other real polygons / rectangles
rejects the preview. Normal gravity, landing and `afterActor` then establish
actual support. An actor walking off an isolated end releases support and
falls; a shell rebounding from an actual strip end retains native spin speed.
After leaving a strip, a native rolling shell's true flat contact receives the
real rectangular support ID.

## Initial standing support and flat joins (v2)

A body imported with its center foot on an inclined top can already have its
uphill foot corner inside the strip. A normal downward crossing test cannot
recover a body that starts overlapping. On an actor's first resolved movement,
`afterActor` may therefore settle that specific shallow initial top overlap
upward by the minimum vertical distance needed for the existing full-width foot
contact. It then establishes ordinary standing support with zero incoming
landing impulse. This is geometry-based settlement, not an actor-position lock.
The authored actor rectangle and terrain are not edited.

Eligibility is deliberately bounded: an explicit floor strip, full horizontal
foot containment, body above the sampled top, actual convex polygon overlap,
and initial center-foot height within the existing 1.01px contact tolerance of
the diagonal. Neither prior nor current motion may travel upward. Jump departure,
unrelated prior support, hidden / emerging bodies and vine / claw / vehicle
constraints do not qualify. Other real rectangles / polygons still block the
corrected body. Only the first resolved movement is eligible; losing or clearing
contact does not renew it. A terrain reset starts a fresh initialization epoch.
Legacy triangles, ceiling strips, ordinary air crossings, deep overlap and
underside contact keep their prior rules.

For a neutral 16px body centered on a 1:2 line, the uphill foot corner is 4px
above the center-foot point; this initial settlement lifts its rectangle 4px.
This is an explicit physical support approximation. The actual original stem
width, foot probe and sprite-to-collider relationship are uncalibrated; these
rules are not an exact Nintendo hitbox or timing claim.

The grounded horizontal preview also recognizes a step that ends exactly at a
floor strip's low vertex within the 1e-7 geometric epsilon. Otherwise positive
foot-span overlap is absent while continuous SAT reports the same vertex as a
lateral hit. The preview uses only the real low endpoint's height, without
changing x or velocity. `afterActor` avoids that false side wall for a genuine
grounded top approach. It still grants strip support only after a positive-width
foot overlap; an exact tangent frame retains real flat-floor support, or falls
if no flat exists. Airborne approaches and true vertical end walls retain the
exact sweep. This repairs both slope directions, including floating residuals,
without changing rolling-shell speed.

## Compatibility and limits

Omitted thickness preserves exactly the original triangles: floor diagonal top
and flat bottom, ceiling flat top and diagonal underside. Qmap, qcollection and
SMM2 mechanics stay at version 1; basic pack schemaVersion stays at 1. Strip
leaves remain in matching visualRooms and are embedded with the same native
runtime in offline HTML, without fake rectangular terrain in basic pack data.

Old strict slope validators reject the additional field. To open in old tools,
remove thickness only in a copy and review the resulting triangle: it fills
previously empty space and can change navigation. This is not a geometry-safe
lossless downgrade. Legacy data does not need migration.

Physics remain authored workshop approximations. Native descending departure
can briefly release support at a discrete end crossing before real flat-floor
gravity contact. No original frame timing, private level clearance, manual
browser play or hardware controller calibration is claimed.

## Validation