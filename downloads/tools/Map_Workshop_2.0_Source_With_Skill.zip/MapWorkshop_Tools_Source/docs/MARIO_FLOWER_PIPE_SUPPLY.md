# 马里奥地图工坊 2.0 · Repeatable native fire-flower supply

`marioModules.version: 1` item sources accept `item: 'flower'` alongside the existing `life` and `star` types. Every source still requires an existing local native pipe and explicit bounded timing, launch velocity, direction and capacity fields. No custom actor, reward script or new asset is introduced.

The existing native `flower` item uses gravity, solid collision, ordinary contact collection, its existing classic flower sprite and powerup sound. Small Mario grows to big Mario on the first flower; a second flower grants native firepower. A real hit removes that power under the existing Stage hurt rule. Further supplied flowers allow the same two-step recovery. Native death rebuilds room and module state at the real activated checkpoint, clearing live flowers, source activation, elapsed source clock and emission count.

The source-author panel offers 火焰花. New flower sources default to upward supply, zero launch velocity, a 180-frame interval, no initial delay, one simultaneously live flower and `maxEmissions: null` for unlimited replacement. These are editable workshop values, not measured Nintendo timing. Picking up a flower or its ordinary native disappearance releases the source slot. A solid mouth obstruction prevents emission, and the mouth follows the actual current pipe geometry. Sideward and downward supplies remain authorable with the same explicit values.

The qmap, qcollection and runtime pack version numbers remain 1. Current import/export and collection compilation preserve the complete source record. Collection compilation advertises `flower-pipe-supply-v1` only when a flower source exists. Life/star records and runtime behavior are unchanged. Older strict readers that accept only life/star reject a flower source; to open a copy with those readers, remove its flower sources or explicitly replace them with a supported item. Keep the original project when doing so.

Implementation: `atlas/editor-mario-modules.mjs`, `atlas/editor-mario-modules-editor.mjs`, `atlas/editor-collection.mjs`. Native collection and movement remain in `atlas/editor-mario-stage.mjs`; native flower artwork remains in `atlas/editor-art.mjs` and `atlas/editor-smb3-art.mjs`.

Run the focused component and existing source regressions:

```sh
node --test tests/mario-flower-sources.test.mjs tests/mario-flower-sources-offline.test.mjs tests/mario-modules.test.mjs tests/mario-modules-editor.test.mjs
```
