# 马里奥地图工坊 2.0 · Normal SMB1 ground Bowser Jr

The optional `smm2Mechanics.bowserJuniors` v1 leaf binds an existing native
walker by stable ID. It does not rename generic Bowser or use its five HP.
The initial exposed body is an authored 24×24 rectangle; the shell is 18×16. Artwork is bottom-centred and preserves
its nominal 22×22 / 16×16 sizes. There is only a one-pixel fit margin on
each exposed side and each shell horizontal side. Actual contact and head
stomp tests use the displayed reconstructed opaque pixels, so transparent
box corners and margins do not hurt or bounce the player.

The controller supports three exposed-head stomps by ordinary Small Mario.
The first two change that same walker into a spiked shell, pursue the player
along real ground, turn as the player changes sides, and recover through an
actual hop and head reveal. Shell contact cannot take another head stomp.
The third exposed-head stomp creates the native upside-down falling defeat
effect, 4000 score, and an optional existing `enemyRewards: key` world item.
Normal and shell body contact use the existing native damage/protection path. Fire contact uses the same displayed opaque flame pixels, including its measured rotating silhouette, instead of an invisible bounding rectangle.
Player flashing protection is inherited from that path, not new boss logic.

The normal state fires a small round projectile with an 8×8 internal body and a source-measured 12×12 animated flame footprint in a straight line
toward the player's position sampled at emission. It has no gravity, ground
bounce, or retargeting. Its visible firing pose uses the same common renderer.
Boss and circular fireball each have one movement owner. The actor state
stores phase, HP, countdowns and direction; view calls cannot advance them.
Door re-entry and death/continue use the host's ordinary room reset.

Only this normal, unwinged, ground SMB1 form is supported. Giant, winged,
clown-car, underwater, other styles, rewind and new health-gated attack types
are rejected. Terrain destruction and landing shockwaves are not implemented.
This first observed contract permits head-stomp damage only; generic player
fire, star, shells or weapon attacks cannot silently invoke Bowser's five-HP
path. Their exact original interactions are outside this supported subset.

All configurable numbers carry `sourceParameterStatus:
authored-not-calibrated`. Default values are exported as
`BOWSER_JR_AUTHORING_DEFAULTS`; import validation never inserts them into old
documents. The editor sidebar and `add/bind/update/clone/removeSmm2BowserJr`
author API use the same validation, History, stable ID, native body and
selection clipboard. Root qmap/qcollection version stays 1; a reader without
the new leaf must be upgraded before importing it.

Observed transitions: Nintendo Unity, “Super Mario 2D Games - All Bosses (No
Damage) [1985 - 2024]”, normal SMB1 Jr fight about 02:14:29–02:14:45. Three
stomps appear about 1.7, 7.5 and 13.8 seconds in the local evidence segment.
The first two shell pursuits end with hop/reveal; the third shows 4000 and
upside-down defeat. Long horizontal flames from the neighboring Bowser room
were excluded. Contact damage to the player, collision boxes, speeds,
acceleration, fixed cadence and random choices were not calibrated from it.

Original recording: https://www.youtube.com/watch?v=qa9CTjBgSYU

Credited playback copy: https://www.bilibili.com/video/BV1c6421f7ue/

Five poses are gameplay-frame reconstructions, not a raw sprite rip. Their
palette and native animation cadence remain unverified; the second normal
frame is an independent visible sample, not a certified native walk-cycle
frame. `atlas/assets/bowser-jr-gameplay-reconstruction/PROVENANCE.json` records
the exact crop times and reconstruction method. Original rights and adaptation
limits are also in `atlas/BOWSER_JR_ART_NOTICE.txt`.

## source refinement

A new set of independently observed player-screen frames at about49.1669screen pixels per16px logicaltile replaces the older low-resolution art. Ten body/shell poses and four8×8 flame rotations are explicit inverse reconstructions, not original asset rips. The first orange flash and body rise occur **after the first head stomp**; this source does not prove an autonomous unhurt jump. The small third projectile leaves Jr’s mouth and travels right/up with the floor fixed, independently of the neighbouring Bowser’s long flame.

Optional `hitTransitionFrames` and `hitHopSpeed` are finite authored parameters. Missing fields or explicit0/0 preserve the old v1 immediate-shell lifecycle without changing imported document bytes. Enabling both produces the observed hurt flash/short physical hop before shell pursuit. The current authored arena uses15ticks and3.5px/tick; these are fits, not a measured universal original trigger/curve. Explicitnull and invalid partial pairs are rejected. Both fields are editable, copied, saved and re-imported through the shared author APIs.

A narrow upward, top-origin rebound separation guard prevents that already-resolved successful stomp from being counted again as a new side hit merely because the hurt pose has a taller opaque row. It does not grant player invulnerability or protect a side/descending re-contact, and never applies during the spiked-shell chase. Original detailed contact faces remain unmeasured.

## Optional authored HP-dependent tempo

`stageTempo` is an optional, closed v1 authoring object on the same Jr actor
rule. It changes only existing walk speed, shell pursuit speed/acceleration,
and the existing aimed fireball's speed and timing. It does not unlock a new
attack, add HP, add invulnerability, change body/contact pixels, shorten the
two shell phases, or introduce autonomous jumps. HP still falls through
3 → 2 → 1 → defeated from the same three exposed-head contacts.
This is explicitly **authored difficulty tuning**, not an observed original
HP-dependent skill rule or a calibration of original timing.

The object requires `version: 1`, `sourceParameterStatus:
'authored-not-calibrated'` and exactly three complete `stages` ordered by
remaining HP, 3, 2, 1. Every stage has exactly these fields:

| Field | Unit / validation |
| --- | --- |
| `hp` | Exact ordered value 3, 2, 1 |
| `walkSpeed` | px/tick, finite 0.01–8 |
| `shellSpeed` | px/tick, finite 0.01–8 |
| `shellAcceleration` | px/tick², finite 0.001–1 |
| `initialFireDelayFrames` | Integer 1–36000; room initialization uses HP3 |
| `recoveryFireDelayFrames` | Integer 1–36000; counted after physical recovery landing |
| `fireIntervalFrames` | Integer 1–36000; counted from the previous shot |
| `fireWindupFrames` | Integer 1–36000, strictly less than `fireIntervalFrames` |
| `fireSpeed` | px/tick, finite 0.01–8 |

The normal countdown enters the existing exposed firing state, then its
windup runs before emission. Thus a post-recovery shot occurs after
`recoveryFireDelayFrames + fireWindupFrames` ticks, and successive emissions
are `fireIntervalFrames + fireWindupFrames` ticks apart when uninterrupted.
A legal exposed-head stomp can interrupt either countdown or windup.
An author can tune pressure on hesitation while preserving an earlier
genuine recovery stomp. No forced minimum fight time or automatic shot is
added. Initial delays at HP2/HP1 remain explicit stage metadata; a new room
actor always starts at HP3, while the two later normal returns use recovery
delays.

Runtime parameters are selected from current real remaining HP on each
simulation step and after each successful head contact. The first stomp
therefore selects the HP2 shell parameters immediately, and the second
selects HP1. Hit-hop duration/speed, shell duration, recovery-hop speed and
reveal timing continue to use the existing base fields. A projectile's aim
and velocity are sampled once at emission and do not change with later HP.

`add/bind/update/cloneSmm2BowserJr` accept and independently copy `stageTempo`.
The sidebar has an opt-in checkbox and all 24 numeric controls. Its initial
seed repeats the actor's existing base tempo for all HP stages, so enabling
the checkbox alone does not silently increase difficulty. Turning it off
and saving removes the optional leaf. `clearSmm2BowserJrStageTempo`, exported
from `atlas/editor-bowser-jr-tools.mjs`, removes it atomically for programmatic
authors. `createBowserJrStageTempo` provides the neutral seed, and the pure
`bowserJrTempoForHp` lookup returns an independent metric snapshot for a
validated rule. Neither lookup nor pose/render reads advances state.

Explicit null, unknown fields, missing or reordered stages, duplicate HP,
partial stage fields and out-of-range numbers are rejected. History,
selection clipboard, clone, qmap JSON and collection compilation preserve
all fields. Root qmap/qcollection and Jr leaf versions remain 1. An older
strict reader that does not know `stageTempo` rejects a newly configured
actor and must be upgraded; this is not a claim of forward compatibility.

Missing `stageTempo` preserves the previous native behavior and imported
document bytes. The compatibility test uses frozen complete native trace
and event SHA-256 values captured before this change for missing hit knobs,
explicit 0/0 and the 15-tick hurt transition. Its neutral tempo seed produces
those same hashes. Existing base and hurt-transition test fixtures remain
unchanged.

The neutral authored pressure fixture uses walk 0.5/0.6/0.7, shell
2.6/2.9/3.15, acceleration 0.16/0.19/0.22, fire speed 1.7/1.95/2.2,
windup 18/15/12 and intervals 140/112/88. Genuine Small input completes all
three contacts with five lives, zero invulnerability, two 260-tick pursuits,
real aimed fire after both recoveries, 4000 score and one physical key.
Its tests also cover actual standalone single and collection HTML Stage,
motor and artwork parity with zero network, all sidebar fields, invalid
atomic edits, pause/read immutability and death/continue HP3 reseeding.
These neutral checks do not replace acceptance of any particular authored
arena, physical browser, touch hardware, or original game timing.

## Optional original repeated-fire composition

`attackPatterns` is a separate optional, closed authoring leaf. It combines
only the existing small round aimed projectile into bursts of 1–3 shots.
It is an original difficulty composition, not evidence that Nintendo Jr
unlocks new skills at different HP. The source clip still supports the
three head contacts, two shell pursuits and recovery/hurt state order;
it does not establish these authored burst counts or intervals.

The exact object has `version: 1`, `sourceParameterStatus:
'authored-not-calibrated'`, and three complete `stages` ordered HP 3, 2, 1.
Each row has exactly `hp`, `shotsPerBurst` (integer 1–3), and
`burstSpacingFrames` (integer 6–120 ticks). Null, missing/extra fields,
unknown projectile types, reordered/duplicate HP and invalid numbers are
rejected through the same model/editor/compiled-project validation.

The first shot uses the existing `fireWindupFrames`. Jr remains in the
visible exposed firing pose for the burst; each later shot samples the
player's actual current position and facing separately. Every emitted fire
keeps its own straight velocity and native visible-pixel collision. Later
shots neither home nor appear across the room. Only after the final shot
does the usual `fireIntervalFrames` normal countdown start. A genuine head
stomp can interrupt the windup or any unfinished burst, clearing its pending
shots and entering the next ordinary shell pursuit. HP, collision pixels,
head protection and native key reward remain the same.

The selected actor sidebar has a separate opt-in checkbox and six numeric
controls. `createBowserJrAttackPatterns()` seeds one shot at every HP;
`bowserJrAttackPatternForHp()` returns an independent metric copy.
`clearSmm2BowserJrAttackPatterns()` removes the optional leaf atomically.
Author APIs, stable-ID body copy/clipboard, History, qmap JSON and collection
compilation preserve the nested author configuration independently.
An unfinished burst's index/count/next emission age live on the same native
actor, so ordinary JSON state restoration resumes it without duplicate
emission. Reading/rendering does not advance it.

No leaf is inserted into older maps. Missing `attackPatterns` retains the
old single-shot behavior, exact actor snapshots and events; its addition
requires upgrading old strict readers despite root and Jr leaf versions
remaining 1. The existing frozen compatibility checks also still exercise
missing stage tempo and both legacy/hurt-hop lifecycle variants.

## Optional pause and inertial pursuit decisions

`pursuitWindupFrames` is an optional integer 0–120 (missing/0 retains the
old start), and `pursuitAimIntervalFrames` is an optional integer 1–120
(missing/1 retains the old per-tick target sampling). Old actor config bytes
are not expanded on import. Both are available in the same sidebar,
author APIs, History, independent copies and strict round-trip validation.
These optional fields require the updated strict reader.

After an enabled hurt transition, Jr changes to its ordinary shell body
and visibly pauses in `shell-windup`. Horizontal speed stays exactly zero
through this period; pursuit begins only when the configured pause has
elapsed and the real shell has landed. Its first pursuit velocity remains
zero and subsequent steps accelerate towards the chosen direction using
the existing bounded `shellAcceleration`. During pursuit, changing the
player's side changes the target only at the authored decision interval.
It never assigns the current velocity to the new opposite maximum speed.
The shell therefore continues moving, slows through zero and then reverses.
Stationary spiked-shell contact is still harmful; no added invulnerability
or scripted player movement is provided.

Dense inspection of the retained 30fps original clip gives the following
zero-based visible-frame observations. Contact and first motion have about
one source frame of uncertainty; these are two examples, not universal
Nintendo parameters.

| Original event | First hit | Second hit |
| --- | --- | --- |
| Visible head contact | n53, 1.767s | n225, 7.500s |
| Orange hurt flash | n54 | n226 |
| Shell first visible | n61, +8 source frames | n233, +8 source frames |
| Shell grounded | n68, +15 source frames | n240, +15 source frames |
| Sustained horizontal motion | n74–75, +0.70–0.73s | n247–248, +0.73–0.77s |

The previous authored 15-tick transition started pursuit at 0.25s, while its
hop was still airborne. The friendly arena now uses 16 transition ticks,
a gentler 2.5px/tick hit hop and 48 stationary shell ticks: first horizontal
movement is normally at tick65, about 1.083s after contact. This deliberately
allows more reaction time than those source examples and is labelled author
tuning, not exact original calibration. A normal released rebound is not
given protection against falling back onto the stationary spikes; the
player still chooses a safe landing with their ordinary jump and direction.

The first source cross occurs about n107–108: the shell continues left,
slows towards n114, is nearly stationary around n116–119, then clearly moves
right by n122. The second cross is about n264–265, followed by continued
rightward motion, a near-stop around n272–277, then leftward motion by n279.
Fixed right-wall/fence/statue positions separate that horizontal change
from camera movement. Pose/codec bounds do not establish a precise original
velocity or acceleration. Reproducible source boards, frame samples and
scope limits are in `arcade-jr-pressure/source-reaction/`.
