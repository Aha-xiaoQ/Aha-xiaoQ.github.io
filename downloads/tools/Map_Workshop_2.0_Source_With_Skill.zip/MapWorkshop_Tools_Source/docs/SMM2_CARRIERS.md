# 马里奥地图工坊 2.0 · Optional live Springboard support

This controller gives an existing native Springboard its own gravity and an
explicitly permitted live support top. It does not create new course geometry,
change Mario's motor or Springboard bounce, make a bare Thwomp safe to stand on,
or provide a scripted route or height boost.

## Data and validation

A room may opt in with plain data:

```js
smm2Mechanics: {
  version: 1,
  carrierGeometry: [
    {id: 'existing-spring-id', carrierId: 'existing-thwomp-id'}
  ]
}
```

`validateSmm2CarriersRoom(room)` validates this leaf while allowing other
mechanic leaves. The list is bounded to 256 bindings. IDs are unique existing
same-room references, and each child must be an independent solid rectangle
with native `material: 'spring'`. Its source bottom must touch the parent's
source top, with actual horizontal overlap. A parent is an existing declared
SMM2 Thwomp actor or native moving solid/one-way geometry. Invalid rectangles,
unknown binding fields, duplicate IDs, self references, and nested/cyclic
bindings are rejected. Source data is not mutated.

Source placement offsets are recorded as initial evidence. They are never a
rule for restoring a Springboard to a parent's offset after losing contact.

## Host API

`createSmm2Carriers(room, {gravity: .3, maxFallSpeed: 4.25, terrain: null})`
returns `null` when there are no bindings. Gravity and the falling cap are
bounded engine options and explicitly authored approximations; they are not
measured SMM2 parameters. An optional engine terrain port supplies exact slope
and other shaped collisions. No author scripts or callbacks are stored in the
room data.

The controller exposes:

- `parentActorIds()` lists the distinct Thwomp parents to advance before Mario
- `apply(geometry, actors, {tick})` advances each child's physical world pose
  once and returns current native Springboard colliders
- `geometryForActor(geometry, actor)` excludes only that parent's own hinted
  children from its collision list, including during upward return
- `beforeActor(actor, {tick, geometry})` separates an ascending airborne body
  only when a measured upward Spring top actually crosses its feet, before
  the unchanged native motor's horizontal pass
- `view()` reports measured displacement, support, contact, blocked motion,
  phase, source offsets, and approximation parameters
- `reset()` restores controller physics to source placement; the host supplies
  its rebuilt native geometry and actor state

The host must supply each moving Thwomp's actual current-tick
`lastMotion.from/to`. Moving native geometry supplies measured `dx/dy` matching
its current pose. Source body dimensions remain fixed. A native wrap/rebase
with incompatible transport displacement loses support instead of carrying a
rider through a teleport.

The host advances the permitted parent actors and native platforms, then calls
`apply` before Mario's ordinary collision step. Returned colliders have
`smm2CarrierGeometry` ownership metadata and measured `dx/dy`; the generic
platform loop must preserve these values. The native Springboard renderer and
bounce code continue to own `springAge`, `boost`, `launchVx`, compression,
`restY`, and `restH`. The controller moves the real resting baseline while
preserving that native state. Same-tick or stale calls do not advance gravity
again, and rebuilding a child collider preserves its current physical pose and
native bounce state.

`beforeActor` runs immediately after `apply`, before native player collision.
Stage calls it only for a player using normal motor movement. It captures the
previous **actual** collider pose at the next `apply` entry, including the
native compression or launch reset performed at the preceding frame's end.
The current pose must match the owned returned collider. Previous source body,
resting baseline, and native compression bounds are validated; a rebuilt
same-tick collider cannot fabricate a new surface displacement.

For an upward top movement, the contact fraction is
`(previousTop - actorFeet) / (previousTop - currentTop)`. The old feet must be
above or exactly on the old top, the new top must overtake them, and horizontal
overlap must exist both at that fraction and at the current pose. A fraction
of zero means a true prior top touch; it never repairs an initially embedded
Spring contact. Ascending means the live actor has negative `vy`, is airborne,
alive, and has a bounded real rectangle. A distant foot, descent, standing
rider, exact horizontal edge, stale tick, missing child or changed collider
does not qualify.

The minimum correction is `currentTop - actorFeet`, using the highest of all
genuinely crossed adjacent Spring tops. Only those verified tops are omitted
from this correction's sweep; they remain solid in the native motor's complete
geometry list. All other Springs, solid walls and ceilings block correction.
One-way undersides remain open. Hidden native blocks retain their genuine
underside collision. The engine's exact convex terrain sweep handles inclined
ceiling faces and permits passage through a triangle's empty half. An existing
overlap with a solid terrain polygon prevents correction. No slope sliding or
horizontal correction is applied.

The port changes only `actor.y` by the measured, swept distance. It preserves
`vx`, `vy`, horizontal position, grounded/support state, native jump constants,
and bounce state. Its return value reports the measured old/new top poses,
crossing fractions, required/actual displacement and any blocking collision;
it does not emit a bounce or reward. Calling it again for the same actor/tick
does not move the body twice. `reset` clears contact history. A dying actor is
ineligible; Stage's actual room/death rebuild discards the controller. Ordinary
continue paths which preserve mechanism physics still require a new current
`apply` frame, so historical ticks cannot supply a correction.

The complete Stage integration patch is one call after the existing apply:

```js
r.geometry = carriers?.apply(r.geometry, r.enemies, {tick}) || r.geometry;
if (!rail?.playerHeld() && !cars?.ownsPlayer() && !p.onVine)
  carriers?.beforeActor(p, {tick, geometry: r.geometry});
```

## Actual support and loss

A Springboard uses its own world pose and gravity. Support requires a real
previous/current top crossing and horizontal overlap. Downward acceleration
can outrun the Springboard: it remains above the carrier, loses support, and
falls. It may land on the actual top later. An upward carrier can catch a
separated falling Springboard at a positive-time crossing, then transport it
through the measured remainder of that motion. The correction is swept
against real solid and one-way colliders and optional exact shaped terrain.

Side or ceiling obstruction limits transport at the actual collision. A
blocked Springboard does not snap back to its source offset; support persists
only while the final foot really coincides with an overlapping live top. Bare
Thwomp/Mario combat remains the host's separate policy.

A dead or missing parent disables its support hint until reset. The Springboard
continues physically from its current pose with gravity and the stated fall
cap, lands on real room geometry, or removes its collider after falling below
the room. It leaves no floating or invisible support. This controller does not
introduce a new crushing, pickup, or enemy interaction policy.

## Evidence boundary and observed repair

The Stone Citadel source map and saved frame establish the two Springboard
pairs resting above Thwomps49 and58. The course-specific bindings are a
**topological inference**, not exported attachment flags or an observed full
charge/return cycle. Existing maker text supports springs on Thwomps; it does
not establish permanent rigid attachment or exact gravity and collision
parameters. `spring-thwomp-bounded-check.json` records that evidence and its
limits. No blocked original-video navigation was used for this implementation.

The actual ordinary-input Stone trace exposed a launch-frame defect at input
4912→4913 (zero-based trace frames4911→4912): Small Mario launched from the
real supported spring at `(1313.05859375, 218)` with `vx=1.5`, `vy=-9`. On the
next frame the Thwomp's genuine upward return moved the Spring top up1px into
the just-airborne feet. The native motor's horizontal pass encountered that
overlap before its upward vertical pass and shoved Mario to `x=1302`, clearing
`vx` to0. The original trace still cleared the course; this was an observed
physical contact bug, not evidence of missing jump force.

This independent revision corrects that exact ordering case with the measured
top-crossing port. It does not alter the previously delivered frozen source,
map, video or full-clear proof. The course topology and Spring/Thwomp binding
evidence remain inferred; original collision timing and gravity are not
source-calibrated.

The separate ordinary-input replay starts at the original `main/start` spawn
as Small with3 lives and applies4915 saved inputs without state mutation.
At the repaired frame, the captured pre-motor pose moves up exactly1px;
`vx=1.5` and `vy=-9` entering the native motor remain intact. Normal held-run
acceleration then gives `x=1314.6142578125`, `vx=1.5556640625`, `vy=-8.78`,
`y=208.22`, with3 lives. Baseline and repaired contacts are saved in
`dynamic-spring-contact-deliverables/dynamic-spring-top-prefix4913-regression.json`.
This bounded prefix verifies the repair, and does not establish a new full
course clear for this revision.