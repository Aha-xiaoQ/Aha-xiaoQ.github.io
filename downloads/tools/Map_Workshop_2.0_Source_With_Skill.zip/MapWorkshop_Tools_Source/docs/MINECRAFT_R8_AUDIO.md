# R8 audio implementation and verification

## Contextual sound effects

- `mc-villager-greet`, `mc-villager-success`, and `mc-villager-disagree` use original harmonic/formant synthesis and distinct pitch contours. They are short non-verbal hums/interjections, not TTS or ripped samples. Gameplay owns proximity/quest triggers and cooldowns.
- `mc-shield-parry` now combines a sharp metallic contact, stopped low impact, and rising metal answer. It remains distinct from the shorter low wooden block sound.
- `mc-golem-uppercut` combines arm movement, impact, and an iron ring; `mc-golem-rose` provides a quiet original offering cue.
- Browser and captured-video sound effects use the same deterministic PCM function and options.

## Redstone passage

`MINECRAFT_REDSTONE_TUNE` is an immutable 44-event score: 31 melody notes, 11 percussion events, and 2 bell accents. `minecraftRedstoneSequence({startTime, fps})` returns fresh events with absolute seconds and rounded frames. Every event contains `note`, `baseBlock`, `instrument`, `role`, `duration`, `volume`, `beat`, `bar`, and `step`.

The passage is 8 short bars of 2/4 at 90 BPM, lasting 10⅔ seconds. It uses the recognizable Mario overworld opening and A response, followed by a short arranged C-major cadence. The low E is folded up an octave so the dirt/piano melody stays within F#3–F#5. Dirt selects harp/piano, stone the bass drum, sand the snare, and gold the bell. Controllers schedule events on simulation time; they must retain the event `role` so the BGM remains ducked during the passage.

Composition credit: Koji Kondo / Nintendo. This is a local synthesized note-block arrangement, not an original Nintendo recording. The composition remains copyrighted; it is not represented as royalty-free. This is a short complete arranged passage, not the entire commercial theme.

## Licensed alternative BGM

The R8 project opts in with `room.minecraft.musicMode = 'licensed'`. Existing projects without that flag retain R7 local-only/default-effects behavior. Explicit `musicMode: 'local'` never selects a bundled or procedural fallback.

The unchanged OGG recordings in `atlas/assets/voxel-music/` are:

- Forest, home and village: “Magic of the Forest”
- Caves, mines, stronghold and burrow: “Deep Mining”
- Nether and End: “Traitor”

All three are by Dark Reaven Music, sourced from VoxeLibre commit `4492ce6ff8d856daa4567abe2ea689f4e7a39842`, under CC BY-SA 3.0. Full per-track source URLs, SHA-256 hashes, lengths and license links are in the accompanying manifest and credits. They are alternative licensed recordings, not Minecraft's original soundtrack.

The offline HTML embeds the three original OGG byte streams once each. Decoding starts only after a user gesture. A locally selected file overrides the appropriate realm (the overworld override includes caves). Local selections stay in page memory and are never uploaded or exported. BGM-only pause preserves effects; global mute and pause stop all relevant playback. Transitions use the existing 650 ms crossfade. Notes with a sequence role duck BGM to 16%; perfect parries duck to 23%, with shared attack/release envelopes.

## Native video audio

`scripts/minecraft-licensed-audio.mjs` exports `loadMinecraftLicensedPCM`, `renderMinecraftLicensedAudioPCM`, and `renderMinecraftLicensedAudioTape`. It uses ffmpeg to decode the unchanged OGGs to stereo float PCM and feeds those recordings into the same event mixer. Use `minecraftMusicIntervals(changes, {musicMode:'licensed', fps, endFrame})` to derive scene intervals. Missing recorded buffers in licensed mode produce a diagnostic and silence rather than an unrequested synthetic substitution.

The recorded-video soundtrack applies runtime volume/fades/ducking and mixes sound effects. Retain the CC attribution, identify these mixing changes, and handle the adapted soundtrack under the applicable ShareAlike terms. The original bundled OGG assets remain byte-identical to upstream.

## Evidence scope

`tests/minecraft-r8-audio.test.mjs` verifies the literal melody, timing, pitch range, deterministic effects, stronger parry attack, provenance hashes, gesture-only playback, local override and cleanup, stereo video mixing, ducking, OGG decode, and self-contained offline embedding. Existing R5–R7 audio regressions are also run. Browser playback tests use a simulated AudioContext; they are not a claim of physical-speaker listening or real-device testing.
