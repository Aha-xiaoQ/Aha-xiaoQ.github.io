# 马里奥地图工坊 2.0 · Explicit SMM2 castle door ending

This implementation uses the observed end of Nintendo's SMM2
story course 13, Dry Bones Shell Boating. Source record:
https://www.speedrun.com/smm2/runs/y6l5x5jy and full source VOD:
https://www.twitch.tv/videos/451970830.

The inspected last frame shows Mario beside the axe, the bridge/Bowser gone,
and the red door open with a white interior. Score 3500 and timer 275 stay fixed.
The clip ends before an automatic door entry or result screen. Local completion
after the explicitly authored pause is an implementation choice, not a claim
that those later actions were observed.

## Authoring

Use a distinct marker with top-left coordinates; it renders at 16×48 native
pixels. It is scenery controlled by the ending and does not create an exit,
Toad, princess or transport.

```json
{"id":"final-door","kind":"smm2-castle-door","x":1488,"y":160}
```

The optional ending references existing native axe and whole-tile bridge IDs.
Provide endingPauseFrames explicitly; it must be an integer from 1 to 36000.
This count starts when the door opens after bridge removal and Bowser's fall.

```json
{
  "version": 1,
  "boss": {"actorId":"bowser"},
  "finish": {
    "variant":"smm2-door",
    "axeId":"axe",
    "bridgeId":"bridge",
    "chainIds":["chain"],
    "doorId":"final-door",
    "bridgeStepFrames":4,
    "bossFallFrames":80,
    "endingPauseFrames":90
  }
}
```

Those illustrative times are authored values, not source-measured timing.
The existing foot trigger, bridge tile removal and native falling boss execute
the sequence. Player input is stationary during the ending. The controller
exposes variant, doorId, doorOpen, phase and endingPauseFrames in its finish view.
The stage executes open-castle-door and completes once after the pause.
The ended stage preserves score, coins, lives and remaining time.

## Compatibility

Only this explicit variant permits the bounded SMM2 leaves version, art,
startingLives, placedItems, checkpointRewards, boneShells, dryBones and liquid.
Future leaves still require their own root schema and payload validator;
the compatibility whitelist alone does not accept unimplemented payloads.
Ordinary castle endings combined with SMM2 metadata still fail validation.
Rewind, underwater, Bill and contraption restrictions remain in effect.
NPC/message fields and automatic-walk fields are rejected on this variant.

Omitting the variant retains the exact legacy NPC/message sequence and command
serialization. The test fixture legacy-editor-castle.mjs is a frozen copy of the
workshop controller before this extension, used only to verify byte parity.