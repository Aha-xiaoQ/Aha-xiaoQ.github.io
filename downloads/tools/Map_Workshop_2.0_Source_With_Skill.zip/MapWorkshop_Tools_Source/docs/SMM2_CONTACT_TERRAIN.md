# 马里奥地图工坊 2.0 · Opt-in SMM2 contact terrain foundation

`atlas/editor-smm2-terrain.mjs` supplies reusable Donut, triangle / finite-strip slope, and
seesaw contacts. It contains no course rooms, recorded input answers, reward
logic, POW activation, damage, camera rules, or native motor edits. Its fixtures
are mechanism checks, **not a full course clear**.

Stone Citadel (V99-QD1-74G, u/ceb131) is an SMB1 SMM2 course. Inspected reference
pixels show the two-cell Donut opening between the upper road and lower door
chamber, two small Thwomps with the left seesaw, and a giant Thwomp above the
right seesaw with POW at its opposite end. The later vertically followed view
shows Mario high in the launch room. This foundation implements the physical
contact needed for that mechanism; it does not infer unmeasured course geometry
or an automatic red-coin pickup. The ground stair pattern in the starting image
does not establish that SMB1 has a native slope object.

All delay, gravity, angle, acceleration, mass, damping, and impulse numbers are
local author tuning, not recovered Nintendo constants. Course actor activation
policies must remain explicit until the relevant style/reference is checked.

## Authoring and validation

The optional room field is `smm2Mechanics: {version: 1, donuts: [], slopes: [],
seesaws: []}`. Empty or absent terrain returns `null` from `createSMM2Terrain`.
`validateSMM2Terrain` validates these leaves while allowing separately validated
actor leaves at the root. The importer must validate that entire enclosing root.
Each list has at most 256 entries. IDs use lowercase dash-separated letters and
digits, are at most 72 characters, and cannot duplicate another terrain entry,
native map object/geometry, or marker. Records reject unknown fields, executable
hooks, unsafe keys, nonplain objects, nonfinite values, and out-of-room shapes.
Room dimensions are bounded to width 1–32768 and height 1–4096 world pixels.

Every Donut requires:

- `id`, `x`, `y`, `w`, `h`: a positive authored rectangle entirely within its room
- `delayFrames`: integer 1–36000; counts real supported contact starting on the
  following frame
- `gravity`: 0.001–4 pixels/frame²; `maxFallSpeed`: 0.001–64 pixels/frame
- `collision`: `solid` or `oneway`
- `triggerPolicy`: `player`, `all-actors`, or `explicit`
- `resetPolicy`: `leave-before-drop` or `continue`

`player` requires an actor with `kind: 'player'`, a hero identity, or
`smm2Player: true`. `explicit` requires `smm2DonutTrigger: true`. Merely touching
the side or intersecting a Donut does not count. `leave-before-drop` resets its
delay when real support is lost before falling; `continue` advances a started
countdown after leaving. Falling applies actual gravity and capped displacement,
keeps a native collider at its true current position, and continues until the
Donut leaves the room. `reset()` restores authored position and idle state.

Every slope requires `id`, `x`, `y`, `w`, `h`, `collision: 'solid'`, and one of
four `orientation` values:

- `rise-left` or `rise-right`: solid below the diagonal, with an inclined
  standable upper edge, flat bottom, and a real high vertical side
- `ceiling-rise-left` or `ceiling-rise-right`: solid above the same named
  diagonal, with a flat standable upper edge at `y` and a sloped solid underside

For a right-rising diagonal the endpoints are `(x, y + h)` and `(x + w, y)`;
for a left-rising diagonal they are `(x, y)` and `(x + w, y + h)`. Ceiling
orientations fill the triangle above those endpoints. Native upward or lateral
head contacts hit the actual sloped underside; the underside is never sampled
as a standable floor. The empty half of each bounding rectangle remains empty.
All-face collision uses the exact convex triangle, with no staircase
approximation or bounding-box wall. The full map reference's arch ceiling
triangles require the explicit solid-above orientations.

Slopes may opt in to finite strips with `thickness` (0.1–1024 vertical pixels).
`h` remains the diagonal's vertical difference. Floor strips extend downward
from the named diagonal; ceiling strips extend upward, preserving its underside.
Both expose a real diagonal top and parallel underside, plus two vertical ends.
The actual polygon must stay inside the room: a floor needs `y + h + thickness`
within its height; a ceiling needs `y - thickness >= 0`. Omission preserves all
legacy triangular geometry. See [SMM2_THIN_SLOPES.md](SMM2_THIN_SLOPES.md) for
API clearing, compatibility and tested contact limits.

Every seesaw requires:

- `id`, `pivotX`, `pivotY`, `length` (1–1024), `thickness` (0.1–64)
- `initialAngleDegrees`, `maxAngleDegrees` (0–75), with the initial angle inside
  its maximum limits
- `weightAcceleration` (0–5 degrees/frame² per normalized mass moment),
  `maxAngularSpeedDegrees` (0–15 degrees/frame), and `damping` (0–1)
- `impactSpeedThreshold` (0.001–64), `impactGain` (0–16),
  `maxLaunchSpeed` (0–64), and `impactMinLeverFraction` (0–1)
- `impactPolicy`: `thwomp` or `explicit`

Positive angle lowers the right end. The pivot is the beam's center; the
standable top is half the thickness above its rotated centerline. Every point
of the actual rotated rectangle, over all permitted angles, must remain within
room bounds. The seesaw is a one-way inclined platform: its underside creates no
invisible collision wall.

## Stage integration

Create one controller per room. At the beginning of a normal fixed 60 Hz frame,
call `beginFrame({tick, actors})` with all actual actors. Use a strictly increasing
integer tick. At most 4096 actors are accepted; duplicate actor references are
deduplicated and duplicate explicit actor IDs are rejected. Actors without IDs
receive stable controller-local IDs. No actor is created by this controller.

`withSMM2TerrainContact(nativeMotor, controller)` wraps `step` while executing the
supplied motor exactly once. Walk acceleration, jump input, jump buffering,
gravity, events, and native rectangular collision remain the motor's work.
The wrapper adapts contact to the true current inclined surface, supports
continuous ascent/descent, and releases support when the foot span leaves the
edge or the native jump begins. An overhead native solid or exact ceiling
triangle stops reachable ascent. Moving shape support also returns `null` if
its real target body would intersect another solid triangle.

The stage's ordinary actor paths can alternatively call
`afterActor(actor, before, {tick, input, geometry, incomingVelocity})` after their
own movement. `before` is the real pre-move body. `incomingVelocity` is optional
and preserves a pre-impact speed when the actor's own collision engine has
already zeroed it. Resolve each actor once per tick. Only real downward crossings
produce a landing record; standing and leaving are separate contact phases.

`geometry(base)` adds true current native Donut rectangles and never converts
slopes/seesaws into rectangular floors. `actorGeometry(base, actor)` also adds
the current positions and measured frame displacement of other explicitly
standable actors. `ownsGeometry(solid)` identifies inclined components so an
independent engine can exclude accidental same-ID rectangular proxies.
Its bounded shape-ID set stays constant across seesaw rotation and reset, so
filtering native rectangles does not scan every triangle for every rectangle.
If a real native `solid` or `oneway` collider already has the standable actor's
ID, `actorGeometry` preserves that base collider and omits the same-ID proxy.
A physical POW's solid underside and native `headHit` therefore stay intact;
the one-way actor proxy is a fallback only when no base collider owns that ID.

`motorGeometry(base, actor)` is the native motor wrapper's per-actor geometry
projection. For a grounded, nonascending rider on an owned falling Donut, it
sweeps only that frame's actual downward carrier displacement from the rider's
current feet. The first crossed visible static `solid` or `oneway` rectangular
floor clamps the Donut `dy` consumed by that rider to `floor.y - feet.y`. Strict
horizontal overlap and real prior Donut top contact are required. Hidden faces,
moving rectangles, standable actor proxies, off-span floors and already embedded
feet do not receive this correction. The motor still executes once and performs
its own horizontal movement, jump/buffering, gravity and floor landing; ordinary
landing transfers `support` to the floor. The Donut itself continues falling
through the floor and eventually leaves the room.

`geometry`, `actorGeometry` and `view` retain the Donut's complete real current
pose and displacement; only `motorGeometry` clips this rider's consumed carry.
This is a narrow rectangular floor boundary for falling Donuts, not a generic
moving-platform or inclined carrier sweep. Its tested actor scope is unmounted
native Small Mario (14px) and Big Mario (28px), including native Stage death
retry. Shoe/vehicle controllers and independent enemy/item movement ports are
outside this repair's verified scope. No schema, authored coordinates or native
motor source changes are required; absent/empty terrain keeps the original motor
object and behavior.

Before native movement, a host's rectangular collider rebuild must preserve
valid external slope/seesaw support IDs. These IDs intentionally have no fake
rectangular collider. Clearing them makes a standing body's native motor treat
its own inclined contact as an airborne side collision and removes jump input.
The native switch integration supplies these room-owned declared IDs through
`apply(roomId, geometry, actors, externalSupportIds)`, where the fourth argument
is an array. Contact validation and native jump/walk controls remain unchanged.

Finish all actor movement, then call `finishFrame({tick, actors})`. This computes
two-sided mass moments and applies actual new impact impulses. Duplicate tick,
actor, and finish calls cannot duplicate an impact. Calling only `geometry`
without a contact adapter does **not** implement inclined collision.

For rendering, `surfaces()` exposes the actual standable top endpoints in `a/b`,
the exact convex `polygon`, and a detached copy of the authored `spec`. Slope
records also expose `orientation`, `solidAbove`, and `underside`; for legacy
ceiling triangles, `a/b` are the flat top and `underside.a/b` the sloped bottom.
Finite strips expose their diagonal top in `a/b` and parallel sloped bottom in
`underside.a/b`, including floor strips. Render the exact
polygon for either fill direction, rather than inferring solidity from `a/b`.
`view()` exposes authored parameters, current Donut poses/phase, current seesaw
angle/angular velocity/two-sided loads, and frame diagnostics. It always marks
the simulation as an approximation.

## Engine-only shape port

The directional Thwomp controller can retain its existing charge/hold/return
state machine and choose the earliest ordinary rectangle versus exact shape hit:

- `sweep(actor, {x, y}, {tick, direction, phase})` returns `null` or
  `{fraction, normal, point, solidId, material, body, incomingVelocity}` from
  continuous SAT against the actual convex triangle, strip or rotated beam
- `support(actor, contact, {tick, direction})` returns updated true boundary
  contact/body pose or `null`; moving support follows only a real current top
- `recordImpact(actor, impact, {tick})` records the verified pre-impact speed
  after the engine applied `impact.body`; it does not move, pin, or activate an
  actor; the incoming vertical speed is bounded to ±256
- `clearActorContact(actor)` clears contact history on return/support loss
- `followSlopeTop(actor, before, {tick, geometry})` previews a reachable top body
  only for a genuinely supported finite strip after horizontal movement. It
  returns `null` or `{solidId, body}`, rejects actual rectangular / shaped
  obstruction, and does not move actors or grant contact. The native Stage uses
  this before enemy wall checks, then its normal vertical step / `afterActor`
  establish the real contact. An exact grounded low-vertex tangent may preview
  endpoint height, but does not grant zero-width standing contact

Seesaw sweeps accept only actual downward top-face hits. Slopes include real
side/underside boundaries. The engine should mark actual downward holds as
`grounded: true, support: impact.solidId` and clear those fields on departure.
Do not separately call `afterActor` for the same swept impact. Historical impact
records from a prior tick cannot launch a body again.

## Weights, physical POW, and launch

Each actor can supply `smm2Mass` (0.001–10000); the default is 1, and invalid
explicit masses are rejected. All live supported actors contribute, including
stacked bodies whose real foot contact reaches an explicitly `standable: true`
actor. An unverified support ID, a gap underfoot, a dead/taken actor, or a body
off the current seesaw contributes no weight.

`impactPolicy: 'thwomp'` requires the impacting actor's type to be
`'smm2-thwomp'`; `explicit` requires `smm2Impact: true`. A new actual downward
landing at an end must exceed the authored speed and lever thresholds. The
opposite supported root and its supported riders receive an upward velocity:

`min(maxLaunchSpeed, incomingVy * impactingMass * impactGain * abs(impactLever)
* min(1, abs(oppositeRootLever)))`

The controller changes velocity and releases support. It assigns no target
height or route, awards no content, and thereafter the stage's normal gravity
and collision resume. A POW supplied by the host as a physical live standable
item remains alive and standable while Mario stands on it or launches with it.
POW activation/pickup and enemy effects belong to separate explicitly referenced
host rules.

A native Stage fixture births Small Mario on the right POW while an explicitly
heavier physical POW loads the left side. Ordinary idle input verifies that
measured item collider displacement carries Mario through the real rising
board without a sideways shove, activation or reward. Stage must preserve a
generated `smm2ItemBody` collider's measured `dx`/`dy` through its generic
platform loop; zeroing those values discards the native carry contract.

### Measured moving-top engine contact

`terrain.sweep(actor, delta, {tick, movingTop: true})` additionally catches a
rotating seesaw overtaking a previously separated descending body. This
bounded repair applies to vertical downward travel (`delta.x === 0`) when the
previous top is genuinely above the actor's foot and the current top has
crossed it. Previously embedded bodies, upward/side travel, and static hits
retain the existing contract. POW item sweeps do not opt into this engine
port; their ordinary `afterActor` uses previous/current contact surfaces.

The angular path interpolates the two actual frame angles. Trigonometric
extrema and foot/endpoint branch boundaries bound the derivative and isolate
the first genuine crossing. The result has a positive contact `fraction`;
`surfaceMotion.contactBody` equals `actor + delta * fraction` on the exact top
at `contactAngleDegrees`. Its final body follows only the measured top change
`displacement = {x: 0, y: currentTop.y - contactTop.y}`. The metadata also names
`fromAngleDegrees`, `toAngleDegrees`, `previousTop`, `contactTop`, and
`currentTop`. No fraction-zero embedded substitute, velocity boost or target
height is inserted.

`validateMovingTopContact(actor, delta, hit, {tick})` recomputes the entire
record from the controller's owned previous/current state. Unknown fields,
stale ticks, altered IDs, angles, normals, body dimensions, contact positions,
and displacements are rejected. The Thwomp adapter requires that verifier,
keeps its real pre-impact charge velocity, and sweeps the measured correction
against ordinary solids and exact ceiling triangles before accepting support.
A blocked correction stops at the actual obstruction, reports `blocked`, and
creates no seesaw landing or launch. Duplicate ticks remain inert. The original
impact event keeps its measured crossing; later live support drops that old
certificate and follows the fresh exact top.

Focused fixtures cover the true positive-time crossing, tampering rejection,
static/underside/outside bounds, both rotation signs, zero-angle and high-angle
endpoint/foot branches with Small/Big dimensions, a real Thwomp transition,
and real rectangular
and triangular ceiling obstruction. These are reusable contact checks, not
force calibration or full-course clear proof.

Finite-floor strips also admit a one-time initial shallow top-overlap settlement
when an imported body's center foot is already on the diagonal. This lifts the
full rectangle the minimum vertical distance, checks real overhead obstruction,
and then uses ordinary standing support. It excludes legacy triangles, ceilings,
upward / constrained bodies and later re-entry. The center-foot placement and
full-body depenetration are workshop approximations; original stem / hitbox
geometry is not calibrated. Exact conditions are in
[SMM2_THIN_SLOPES.md](SMM2_THIN_SLOPES.md#initial-standing-support-and-flat-joins-v2).
