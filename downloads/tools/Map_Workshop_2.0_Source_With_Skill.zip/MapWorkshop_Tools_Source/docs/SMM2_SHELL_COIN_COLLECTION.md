# 马里奥地图工坊 2.0 · 玩家激活旋转龟壳的金币接触

## 作者开关与格式

区域 `smm2Mechanics.shellCoinCollection` 是一个严格 Boolean，可省略。仅 `true` 开启；缺省 / `false` 关闭龟壳收币。模型版本仍为 qmap 1 / qcollection 1 / SMM2 mechanics 1，基础 pack 仍为 schemaVersion 1。

- 权威验证：`atlas/editor-smm2-mechanics.mjs` 的 `validateSmm2MechanicsRoom`
- 稳定作者 API：`atlas/editor-smm2-authoring.mjs` 导出的 `setSmm2ShellCoinCollection(room, enabled)` 与 `clearSmm2ShellCoinCollection(room)`
- 实际 UI：SMM2 侧栏「玩家激活龟壳收集金币」复选框，通过原生 History 事务修改
- 运行时：`atlas/editor-mario-stage.mjs`，所有音效与奖励仍使用原生 `collectCoin`

导入 / 导出 / 再导入保留开关；undo / redo 可恢复；复制整个区域保留其政策。单个对象剪贴板只重映射实际粉币 ID 等对象引用，不复制房间政策或运行时激活信息。合集保存整个作者 qmap，编译时把开关保留在匹配的 `visualRooms`；基础 pack ABI 不新增非标准字段。自包含 HTML 包含同一运行时及作者数据，功能不依赖联网。

旧严格 SMM2 读取器会拒绝新增字段。需要旧工具打开时，在副本中删除 `shellCoinCollection`；金币仍由玩家收集。不能声称旧运行时理解此新能力。未设置开关的现有地图无需迁移。

## 真实激活与接触

既有 Koopa / Beetle 接触分三步：第一次踩到行走敌人产生静止壳；玩家侧踢或踩到静止壳产生旋转壳；再踩旋转壳使它停下。只有第二步的真实接触分支记录激活。

激活保存在 WeakSet 中，以实际运行时 actor 对象身份为准。作者 JSON、敌人 ID、初始速度、`source`、同名属性都不能制造激活。停壳或醒回行走形态清除激活；再次真实踢动可激活。碰墙、普通重力下落 / 落地、回到已模拟房间保留激活。没有把含糊的「dropped shell」帖子推断为所有落地都会失去所有权。

收币时还必须：该壳本帧真的模拟，活着且可见，属于 Koopa / Beetle，`shell === true` 且处于既有引擎的旋转速度状态，没有正在出管、吊爪抓取或载具约束。金币必须是可见活跃原生 coin，并与壳的真实身体矩形重叠。仅邻近、远处未模拟演员、炮台 / 管道自动运动、普通 Goomba、火球、骑乘 Bone Shell、Spiny Shell 不授予权限。未新增炮台发射 Buzzy 壳的作者类型；本功能复用已有原生 Koopa / Beetle 壳生命周期，动态管道供应的 Koopa 也需要真实玩家踢动。

没有计时收币、传送、脚本奖励或远程判定范围。碰撞矩形、速度、重力、屏外激活和现有旋转壳外观保持原引擎路径。

## 奖励一致性

玩家与合格旋转壳共用 `takeWorldCoin`：每房间的 `taken` ID 防止同币重复，粉币使用 `roomId + newline + stableID` 命名空间。普通币复用作者 `coinValue`，粉币沿用原计数语义。二者都调用 `collectCoin` 更新 coins / score / pickup 声音，跨越 100 金币时复用既有 1UP 音效和加命。不可见 / 死亡金币不会通过此共用路径结算。

粉币 HUD 来自同一 `pinkTaken` 集合；收齐所有房间实际声明的粉币只产生一次现有 homing key。壳不直接赋予钥匙，也不代替玩家拾取钥匙。收币后对象沿用既有 `view()` 的 taken 过滤消失，没有新美术、强制动画或附加静默奖励。

## 证据与限制

机制参考是 2019-07-23 的 [SMB1 粉币机关作者实测](https://www.reddit.com/r/MarioMaker/comments/cgof7z)：一手文字区分玩家使壳旋转后收币与自动炮台发出的 Buzzy 壳，并有先踢壳、隔开 Mario、用壳接触收 key coin 的实作回复。访问方式是公开索引中的一手文本；正文直接打开 Cache miss，未观看链接演示。

这支持玩家激活 / 远程粉币接触的有条件模型。普通币、Koopa / Beetle 各组合的精确原作矩阵，以及任何具体课程的碰撞 / 时序 / HUD 动画仍没有原帧校准。本开关是明确的作者近似能力，不能泛化为全部 shell、全部游戏风格、所有投掷 / 掉落所有权规则或 Nintendo 引擎等价。

中性 fixture 固定声明起点、敌人和金币；测试只发送普通 x / jump / run / attack / interact 输入，不在游玩中改坐标、演员状态、奖励计数或权限。逐帧证据验证收币时旋转壳确实重叠金币且 Mario 不在金币身体中。

代码许可仍在 `LICENSE-CODE.md`；Nintendo / Contra / 字体 / 恢复素材仍由 `ASSET_LICENSES.md` 和已有素材通知约束。没有新素材，也不扩大许可。
