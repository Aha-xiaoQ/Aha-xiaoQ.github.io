# 马里奥地图工坊 2.0 · Opt-in SMM2 Thwomps

`atlas/editor-smm2-thwomps.mjs` decorates an existing native walker and moves its actual body through perception, windup, charge, real terrain impact, and return. It adds no course geometry, room-name branches, answer sequences, automatic kills, scores, or Mario motor changes. Component tests are not proof of a complete course reproduction or clear.

## Evidence and limits

The reference is **Stone Citadel**, **V99-QD1-74G**, by **u/ceb131**, in **SMM2's Super Mario Bros. 1 style**, not SMB3. The [creator's complete segmented walkthrough](https://www.reddit.com/r/MarioMaker/comments/hcftyr/) shows an initial downward charge, a lower-room guard charging left away from a green door, small and giant Thwomps hitting actual seesaws, and a later left charge opening a brick tower. Right is a reusable mirrored engine direction, not a claimed Stone Citadel encounter.

Actual research pixels inspected before implementation:

- `stone_citadel_u04_horizontal_guard_12_8.jpg`: left guard, lower-left ledge and right door
- `stone_citadel_u03_pow_launch_54.jpg`: small/giant Thwomps, inclined seesaws and POW context
- `stone_citadel_u05_secret1_launch_68_2.jpg`: later launch context; a still does not measure its impulse
- `stone_citadel_u08_tower_brick_smash_145_4.jpg`: debris and a new tower opening
- `stone_citadel_u07_secret2_tower_149.jpg`: tower return/drop and red-coin context

The brick-smash filename is not a calibrated timestamp. The research worker reports capture near 145.15 seconds; final timing belongs to the complete reference manifest.

[FUN 2024, §4.2, p. 22:17](https://drops.dagstuhl.de/storage/00lipics/lipics-vol291-fun2024/LIPIcs.FUN.2024.22/LIPIcs.FUN.2024.22.pdf) describes proximity-triggered down charge and return, and physical Thwomp impact launching occupants on the opposite side of a seesaw. It supports those qualitative mechanisms, not this implementation's numeric values.

Exact original detection boundaries, timing, normal-versus-giant body/mass relationships, style-dependent combat, and the full breakable-material matrix remain unresolved. Every numeric course value is an explicit local approximation until measured. Artwork does not determine body size or mass: the actual native actor's `x`, `y`, `w`, and `h` are authoritative.

## Schema

Optional room data uses `room.smm2Mechanics.version === 1` and an optional `thwomps` array, capped at 256 entries. `validateSmm2ThwompsRoom(room)` checks that version and its own leaf without mutation; the enclosing importer rejects unknown sibling modules. Unsafe root keys and all unknown Thwomp definition fields are rejected. Empty or omitted Thwomps make `createSmm2Thwomps` return `null`.

All definition fields are required; there are no inferred physics defaults:

| Field | Meaning and permitted range |
| --- | --- |
| `id` | Exactly one existing native `map.objects` walker, inside valid room bounds |
| `direction` | `down`, `left`, or `right` |
| `triggerRange` | Forward sensor distance, 0–4096 pixels |
| `transverseTolerance` | Perpendicular sensor extension, 0–512 pixels |
| `leadReference` | Mario's longitudinal `center` or facing `near-edge` |
| `windupFrames` | 0–600 whole stationary frames after the trigger frame |
| `chargeAcceleration` | 0.001–64 pixels/frame² |
| `chargeSpeedCap` | 0.001–256 pixels/frame |
| `impactWaitFrames` | 0–36000 whole stationary frames after actual impact |
| `returnSpeed` | 0.001–256 pixels/frame |
| `breakMaterials` | Exactly `[]` or `["brick"]` |

The optional `oneWaySupportIds` field is a unique list of up to 256 safe collider IDs. Omission or an empty list ignores one-way rectangle tops. The enclosing importer must validate those references against actual authored support components; this leaf validates the list's bounds and safe IDs, and runtime requires the named live collider to really exist.

Two other optional fields are `winged` (strict boolean) and `mass` (finite 0.001–10000). `winged` decorates the actor's render flag only; it does not add hovering, flight, vertical offsets or a separate movement engine. `mass` sets the live actor's `smm2Mass` for actual terrain load/impact calculations. Neither size nor mass is inferred from wing art or sprite scale. Omitted fields preserve existing actor values.

Decoration captures the live pose as home and tags the runtime type `smm2-thwomp`. Native kind, ID, dimensions, health and other stats remain intact. Decorate before the ordinary walker motor gets a chance to move the actor.

The sensor starts at the Thwomp's actual leading face. `center` samples Mario's center; `near-edge` samples Mario's closest edge facing that face. Mario must be in front, within the forward range, and within the expanded perpendicular body interval. Missing/dead/invalid player bodies cannot trigger. This geometric sensor is an authored approximation; exact Nintendo trigger boundaries and occlusion are not asserted.

## Runtime API

```js
const terrain = createSMM2Terrain(room); // optional actual shaped terrain
const thwomps = createSmm2Thwomps(room, {emit, terrain});
thwomps?.decorateEnemy(enemy);
const result = thwomps?.stepEnemy(enemy, {
  tick,
  player,
  geometry: state.geometry,
  getGeometry: () => state.geometry,
  breakSolid: ({solid, contact}) => {
    // Host owns the real collider deletion and debris policy.
    state.geometry = state.geometry.filter(q => q !== solid);
  }
});
```

`ownsActor(enemy)` identifies native IDs. `stepEnemy` returns `false` for unowned actors. An owned actor returns `{handled:true, advanced, phase}`; an unavailable actor returns `unavailable:true` without mutation. Repeated or stale ticks return `advanced:false`, with no movement, countdown, callbacks, or events. State and the monotonic tick guard live on each `enemy.smm2Thwomp`. Reconstructing native actors naturally resets the mechanism.

The trigger frame starts windup; the following authored windup frames are stationary, then charge begins. Acceleration advances once per distinct tick. A committed charge follows its direction even after Mario leaves. Real impact begins the stationary authored wait; return starts on the next tick after that wait. Return sweeps the current path to exact captured home and can be blocked by new terrain. Reaching home gives exact position and zero velocity; another distinct tick can retrigger.

Result fields can include `impact` for a new real hit, `breaks` for confirmed collider removals in sweep order, and `blocked` for a real return/support-follow obstruction. `breakLimitReached` means a pathological dense frame reached the 256-break processing bound; it remains in charge at real contact for the next tick.

Contact records include `solidId`, `material`, `tick`, `fraction`, `normal`, `point`, exact hit `body`, pre-impact `incomingVelocity`, `embedded`, and `terrainKind`. Break fractions refer to the whole charge frame; original full velocity remains available after earlier layers disappear. Initial actual overlap can stop motion at fraction zero, without teleporting a body out of terrain.

`view(enemies)` returns detached authored definitions and matching live body/state snapshots. Authored `room.map.objects` never receive live charge state; JSON export/reimport preserves only definitions. Build a new simulation from reconstructed authored actors, rather than importing copied runtime bodies as author data.

`emit('smm2-thwomp', data)` reports actual `trigger`, `charge`, `impact`, `support-lost`, `return`, `return-blocked`, `home`, and confirmed `break` events. It grants no rewards or damage.

### Verified Buzzy head-contact return port

```js
const protection = items.helmetContact(player, beforePlayer, enemy, {
  tick,
  hazardBefore: beforeEnemy
});
if (protection.protected) {
  thwomps.requestReturn(enemy, {tick, contact: protection.contact});
}
```

`requestReturn(actor,{tick,contact})` consumes the host's verified `helmetContact` head record, not a generic body overlap or a command to clear an enemy. Its bounded contact leaf contains `kind:'head'`, fraction 0–1, normal `{x:0,y:1}`, finite point and relative motion, and a boolean `nativeHeadHit`. Relative vertical motion must actually approach the underside; the point must lie on this actor's interpolated current-frame swept underside. Unknown/malformed, remote, side/body, stale, dead, unowned or inactive requests return `false` without mutation. Invalid numeric ticks throw.

Only already committed `windup`, `charge` or `impact` states can accept. Call after that tick's Thwomp step, or immediately before its next normal step using the current stationary target pose. Acceptance returns `true`, clears real support/contact history and the impact timer, and changes phase to the existing `return` state. It does not change position/dimensions, kill the actor, award points, consume a helmet, change Mario power, or trigger completion.

Accepted requests emit one `return` event with `reason:'buzzy-head-bonk'`, `requested:true`, and the detached verified contact. Duplicate requests emit nothing. Return motion starts on a later normal tick, sweeps actual current terrain, can be blocked, and reaches the original captured home exactly. A request made before a normal step cannot force movement during that same tick. Ordinary terrain-driven returns emit `reason:'terrain-impact'`.

This engine port does not automatically detect helmet contact or broaden default combat policy. The separate items controller decides the genuine head collision and exposes its documented local approximation. The Stage owns Mario's rebound/contact handling. The renderer must call its wings drawing routine for `actor.winged === true`; merely exposing the flag does not draw it automatically.

## Actual terrain and brick response

Rectangles use continuous swept AABB collision, selecting the closest true solid independent of array order. Hidden/invisible/removed/non-solid rectangles and tangential grazes are excluded. A bare one-way rectangle is not silently promoted to a Thwomp support. Room edges are not floors: without terrain the body genuinely travels outside the room, with no fake impact, automatic return, kill or score.

An authored `oneWaySupportIds` entry permits a genuine descending top crossing against that named current `collision:'oneway'` rectangle. It applies only to a down-direction Thwomp. Horizontal charges pass even a named one-way rectangle, and upward return has no one-way underside wall. Non-collision background pillars remain background. During impact, the body follows the actual named collider's changing top y while its foot span really overlaps it; collider deletion, loss of overlap or an intervening true ceiling releases support. This is a narrow authored support capability, not a claim that every original semisolid blocks Thwomps.

An optional shaped-terrain controller supplies these engine ports:

```js
terrain.sweep(actor, delta, {tick, direction, phase})
terrain.support(actor, priorContact, {tick, direction})
terrain.recordImpact(actor, actualImpact, {tick})
terrain.ownsGeometry?.(solid)
terrain.clearActorContact?.(actor)
```

Shape sweep must return a real contact or `null`, with valid fraction, normalized normal, point and collider ID. A supplied body must equal the actual swept pose and preserve dimensions. It competes against the nearest rectangle. Shape-owned IDs are excluded from rectangle collision, so slope/seesaw bounding boxes cannot act as synthetic walls or floors.

After applying a new shaped hit, `recordImpact` receives actual pre-impact velocity exactly once. Stage integration calls terrain `beginFrame` before Thwomp stepping and `finishFrame` after all actors move. It must not separately record the same Thwomp hit through `afterActor`. The terrain controller computes actual two-sided load and opposite-side impulse; no launch coordinates, recipient order or level answers are encoded here.

A down/upper-face impact sets real `grounded`/`support` so resting Thwomp mass enters terrain load. During impact, `support` rechecks the current rotated face and may supply its physically updated body position. Width/height stay authoritative; an intervening rectangle blocks support-follow motion. Removed/hidden/shifted-away rectangular support or absent shaped contact releases hold and resumes charge. That support-loss response remains a stated local approximation. Leaving impact clears grounded/support and terrain contact history, allowing a later genuine hit to launch again.

`breakMaterials:[]` always stops. `["brick"]` allows only real encountered ordinary bricks without used/reward/content metadata, including linked native sources or markers. Ground, hard blocks, unknown materials and content bricks stop. No giant-versus-normal breakage rule is inferred.

The synchronous `breakSolid` callback runs only after real brick contact. The host must alter its actual collider data; `getGeometry` then re-reads it. Returning `true` while the collider remains is not a break. Only genuinely absent/non-solid colliders enter `breaks`, after which the same frame's remaining sweep continues to surviving terrain. Omitting the callback stops the body. Callbacks may change terrain; they may not script an actor pose or resize it.

`SMM2_THWOMP_COMBAT_POLICY` marks player-body, stomp, shell, fire, star, helmet and spike-face responses `unverified`. Stage integration must intercept every generic walker/Goomba combat path using `ownsActor`; skipping the walker motor alone would still invent generic defeat rules. Terrain contact does not authorize killing, scoring, bouncing Mario, or making a Thwomp standable to Mario.

The current public-data viewer screenshots `mario-replica-references/stone-citadel-full-study/viewer-main-slice-02.png` and `viewer-sub-slice-01.png` were inspected after recovery. They corroborate authored Thwomp/lift positions, including adjacent same-height original placements; they are static public course-data views. They do not independently prove wing motion, original helmet timing, or the previously observed dynamic lift contact. Wing visuals can be explicitly authored from source observations while their movement remains uncalibrated.

The focused command is `node --test tests/smm2-thwomps.test.mjs tests/smm2-terrain.test.mjs`. Coverage includes all directions and non-triggers, sensor boundaries, exact fast terrain contact, no-floor travel, support loss, exact home/retrigger, return blockage, duplicate ticks, strict schema/reimport, actual brick removal, true triangle sweeps, rotating seesaw/opposite POW launch, a later genuine launch after return, and explicit moving one-way top support with horizontal/underside/background exclusions. Test tuning values are synthetic contract fixtures, not measured Stone Citadel settings or full-course proof.

The original Mario motor hash, freshly verified after source recovery, is `d9c0d6f30a1d540338969891a34f52e2673548e057f7310901057c15cddb5795`. This component did not edit it.

The shared workspace was replaced after an earlier 41-test combined pass. The actual native source was subsequently recovered from the user's exact source ZIP, and the terrain controller was restored. This module, tests and document were reconstructed from retained source context with condensed formatting; no substitute native baseline or fake terrain source was created.

A fresh final run passes 172 tests: 32 Thwomp, 29 items, 32 terrain and 79 native regressions, including recorded native 1-1 completion. The command is `node --test tests/smm2-thwomps.test.mjs tests/smm2-items.test.mjs tests/smm2-terrain.test.mjs tests/native-mario-regression.test.mjs`. New cases use the actual items `helmetContact` helper and cover post-step/pre-step requests, no same-tick teleport, obstruction and exact home/retrigger, invalid contact rejection, windup/impact requests, and wing/mass schema/body preservation. This certifies current component fixtures and preserved native baseline behavior; complete measured Stone Citadel authoring, original numeric calibration and whole-course route/render validation remain separate work.
