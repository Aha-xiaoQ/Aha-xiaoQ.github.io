# 马里奥地图工坊 2.0 · 显示与作者接口

继承 [基础接口](WORKSHOP_1.10.22_INTERFACE.md)。qmap/qcollection根版本不变，本版没有新增碰撞、运动、奖励或物理叶子。旧读取器可以读取同一方向标记，但缺本次人物动画、原方向轮廓和原生编辑面板。

## 人物素材与时钟

editor-smw-player-motion-pixels.mjs提供原SNES SMW的21个确切48×48姿态格及来源。Small/Super站姿与此前SMM-SMW原PNG的透明轮廓一致；SNES白色是#f8f8f8，图库PNG是#ffffff。固定原格锚保持头部登记，不能每帧按不同可见宽度重新居中或拉伸至碰撞体。

editor-smw-underwater-art.mjs的smwUnderwaterPlayerPose是纯显示投影。读取真实p.swimStroke和room.aquatic.physics.strokeFrames：实际划水后姿1为4tick、姿2为8tick，再回姿0并保持；不是强制循环或整体晃动。原片的输入与按键迟延未知，当前由本地既有stroke字段选择时相，未改变stroke物理系数。

Small走步只有两种确切外观，按真实p.anim位移每约5px切换；Super为0→1→2、约16px完整步幅。原片实际转向是立即镜像，p.facing与p.vx符号分开。停走、原生暂停/受伤冻结时不自行增长动画时钟。

SMW受伤显隐每约8tick有实证，初次碰撞隐藏起点被遮挡，仍明示作者拟合。Small原死亡姿最高优先，不误用泳姿；本关原片没有死亡，它是原SMW补图而非原42死亡实测。成长中间高度、Fire/Cape/Yoshi全表与所有动作控制条件未恢复，不称完整原机角色系统。旧非SMW-profile角色仍使用原路径。

## 原生方向指引

现有room.markers中kind:"source-arrow"保存id,x,y,w,h和source.direction/source.signArt，无额外物理体。共享drawReference/SMW source drawing读取同一数据。地面起点牌signArt:"smw-observed-arrow"为已核48×48/right；浮空指引signArt:"smw-observed-floating-arrow"用8个方向，旧无signArt标记保持可读。

editor-direction-arrow-tools.mjs提供setDirectionArrow、removeDirectionArrow、cloneDirectionArrow、moveDirectionArrows和真正作者面板。放置/同ID配置/保存复制/移动/删除均走既有History事务；字段、原生ID冲突、房间范围、样式/方向非法时整次回滚，保留其它标记。指引可以合法浮空或视觉叠层，不误当金币/实心碰撞校验。

三个实际原形是↗/↘/↓，editor-smw-direction-arrow-pixels.mjs逐个保存原录像轮廓、不对称nativeAnchor和出处。不能旋转旧20px粗黑轮廓替代它们；其它五方向仅为这些原形的镜像/直角适配。作者宽高以24×24基准统一等比缩放，保持原形比例；标记盒子与可见alpha范围不同，不能据显示宽度扩大碰撞。

离线catalog额外嵌入两份人物/箭头像素模块。编辑器、独立HTML和实际Canvas录像共用同一渲染，没有关卡坐标脚本控制姿态。原素材/源稿/原片密帧时序和版权分别保存，图库GIF的delay不当原机时序。