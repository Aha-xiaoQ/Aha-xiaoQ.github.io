# 马里奥地图工坊 2.0 · Carry after completing a private collection

Progress version 1 now accepts an optional `terminalCarry` object:

```json
{
  "version": 1,
  "fromLevelId": "fourth-course",
  "fromRevision": 1,
  "contentFingerprint": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
  "carry": { "lives": 7, "coins": 62, "score": 48950, "power": 2, "hero": "mario", "weapon": "N" }
}
```

`contentFingerprint` is included when the validated level descriptor supplies one; the hexadecimal value above is synthetic. Only actual completion of the last playable entry creates this cache. The completed collection still has `resume: null`. On a later same-ID collection append or reorder, reconciliation preserves valid clears and offers the first eligible uncleared entry after the cached source with exactly those earned counters and form. Source revision, content fingerprint, deletion or admission withdrawal invalidates the cache. Entries before the source are independent starts. Entering a level consumes the cache and saves the ordinary entry boundary; explicit free selection uses fresh starting lives and ordinary form.

The field stores no position, room, checkpoint, world, timer or input tape. It does not approve a course, qualify a pending revision or change private test inclusion policy. Production callers use the validated, admission-filtered runtime descriptor.

Old version-1 files remain valid. Previously completed files without this field cannot recover discarded carry. After additions, the launcher selects the first uncleared course for a fresh start, normally three lives and ordinary form, and explains that no carry is available.

Verification: `node --test tests/collection-terminal-carry.test.mjs`. Synthetic launcher fixtures cover four final completions, storage/JSON roundtrip, a tested pending fifth, unchanged resumed carry, independent fresh selection, legacy files, failed launch, reorder, revision and policy withdrawal. They do not claim physical hardware or native browser coverage.
