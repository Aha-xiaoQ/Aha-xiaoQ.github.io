# 马里奥地图工坊 2.0 · Live POW, Buzzy Shellmet, placed 1UP and Skewer adapters

`atlas/editor-smm2-items.mjs` implements four opt-in leaves of `room.smm2Mechanics.version:1`. It uses native room bodies and ordinary/shaped terrain. Mario's motor is unchanged. Damage, score and NPC defeat stay with the host. All numeric tuning, effect distances and uncertain interaction policies are authored approximations rather than recovered Nintendo constants.

## Observed evidence and limits

The actual pixels inspected were `original-observed-t206500-head-contact-rail-pow.png`, `original-observed-t207300-pow-effect-two-thwomps.png`, `original-observed-t207700-pipe-fade-after-pow.png`, `original-observed-2102-preplaced-buzzy-shellmet.png`, `original-observed-2111-shellmet-worn.png` and `original-observed-t261174-skewer-hall.png` in the supplied Stone Citadel reference directory.

The first POW image shows Mario's head at the live rail POW underside. The aftermath shows the POW expanded, both nearby Thwomps tilting, and score rising from 11020 to 11220. The supplied 2077 image remains a fade frame with the expanded POW visible; it does **not** prove its later disappearance or exact fall trajectory. The adapter's immediate collider removal is the once-only detonation contract, not a calibrated animation timeline.

The loose blue inverted Buzzy shell is preplaced on the first semisolid pillar, and the next image shows Mario wearing it while still Fire. It is not a question-block reward. This SMB1 adapter equips it through a real underside head approach. It does not implement carrying, duck pickup, Spiny helmets, universal body immunity or protection against Skewers.

The blue POW screen policy follows the [official element guide](https://www.guiasnintendo.com/2c-switch/super-mario-maker-2/guia-super-mario-maker-2/paleta-elementos.html): its ground condition refers to affected enemies, not to the POW itself. The optional local-radius study mode remains an explicit approximation; neither its radius nor airborne target scope has been calibrated. The narrow Buzzy/Thwomp head-bonk decision follows the supplied author experiment `cakjc1`; it requests live return motion and never kills or teleports the enemy. Skewer load distance, initial phase and fixed local cycle are authored values. Course camera and screen-edge behavior remain approximate.

[Stephan Klenner's 2020 mechanism example](https://gaming-village.de/wp/2020/08/03/contraptions-in-mario-maker-2-03-die-einstuerzende-mauer/) describes an actively charging downward Thwomp hitting an actual POW, which then removes the Thwomp and nearby Muncher. The bounded impact API supports that explicit collision. This source does not establish an ordinary falling POW detonating on an enemy head, exact numerical contact/effect constants, or a verified continuous solution through Stone Citadel's final room. No falling-POW activation rule is implemented.

## Authoring

Every definition references exactly one existing native map object by stable `id`. POW, helmet and placed 1UP source placeholders use native `kind:'walker'`; Skewer bases use native `kind:'hazard'`. The host removes owned walker placeholders from ordinary enemy construction and decorates their live copies as `kind:'pow'`, `kind:'buzzy-shellmet'` or `kind:'life'`. The closed native object-kind ABI is preserved. The native object's dimensions are the actual body/base dimensions.

```js
room.smm2Mechanics = {
  version: 1,
  powBlocks: [{
    id: 'pow-body', gravity: 0.4375, maxFallSpeed: 4.25,
    blastRadius: 96, supportedScreenEffect: false
  }],
  helmets: [{id: 'loose-buzzy', gravity: 0.4375, maxFallSpeed: 4.25}],
  placedItems: [{id: 'placed-1up', kind: 'life', gravity: 0, maxFallSpeed: 4.25}],
  skewers: [{
    id: 'skewer-base', direction: 'down', travel: 96,
    extendSpeed: 16, retractSpeed: 8, waitFrames: 90, holdFrames: 20,
    loadDistance: 320, phaseOffsetFrames: 0
  }]
};
```

These example values are illustrative tuning only. All listed fields are required. Unknown fields, scripts, unsafe/prototype keys, duplicate references, wrong source kinds, nonfinite/out-of-range numbers and source bodies outside the native room are rejected. Each list has a 256-definition cap. Validators inspect only these leaves and the version; the importer validates root siblings and cross-component ownership.

Numeric bounds are gravity 0–64; maximum fall speed, extend/retract speed and rail speed no greater than 256; positive maximum fall/extend/retract speeds; radius, travel and load distance no greater than 4096; integer wait/hold/phase values no greater than 36000. Travel must be positive, the full Skewer extension must fit the room, and the phase offset must fit its full authored cycle. Native body width/height must be positive and no greater than 4096.

An optional POW or placed 1UP `rail:{trackId,speed,position,direction}` uses a real `room.contraptions.tracks` path. `position` is arc distance, `direction` is 1 or -1, and track modes are the existing bounce/closed-loop modes. The native source body centre must match that initial track sample within 0.01 world unit. Lines and real quadratic curves are sampled; one-unit arc substeps retain intermediate motion and obstruction checks even through a reversal or short loop. A wall stops motion. Standstill, carrying a rider, and seesaw launching leave the POW live. A placed 1UP uses the same path/body motion but has no standable or solid collider. Rail attachment constrains its trajectory; a free POW retains gravity and real launch velocity.

`placedItems:[{id,kind:'life',gravity,maxFallSpeed,rail?}]` supports an actual preplaced 1UP only. A static source may use `gravity:0`; a free source otherwise receives authored gravity and terrain support. Decoration sets `kind:'life'`, `standable:false`, and `smm2PlacedItem` state. Neither overlap nor head contact awards/spends anything in this adapter. The host performs its ordinary life-item contact and marks the actual item dead after awarding one life. All references share duplicate-ID validation with POW, helmets and Skewers.

Skewer source objects describe fixed **bases**, not a maximum extended hazard rectangle. The shaft grows from the directional base edge by the current extension, with a leading tip rectangle. Directions may be down, up, left or right. Each controller starts unloaded. A live player's centre within `loadDistance` of the base starts its own clock once; walking away does not freeze it or alter its direction. It cycles wait → extend → hold → retract, with ceil(travel/speed) movement ticks. Phase offset zero starts retracted. A nonzero initial cycle seed supplies the corresponding prior-tick initial footprint so loading never teleports a whole shaft into place. It is an authored source state, not an observed hidden timer.

## Exact host API

```js
validateSmm2ItemsRoom(room, spec = room.smm2Mechanics);
const items = createSmm2Items(room, {emit, terrain, isPowTarget});
```

`createSmm2Items` returns null when all owned leaves are absent/empty. `terrain` is optional and, when present, supplies `sweep`, `afterActor`, and optionally `ownsGeometry`/`clearActorContact` from the existing shaped-terrain controller. `isPowTarget(actor)` is an optional synchronous boolean eligibility decision; without it only live `type:'smm2-thwomp'` bodies or explicitly `powEligible:true` bodies qualify.

- `ownsActor(actor)` identifies source-owned actors by id
- `decorateActor(actor)` sets live kind/type, state and POW `standable:true`, preserving supplied dimensions
- `beginFrame({tick,actors,player,paused:false})` records frame-start poses and advances loaded Skewers once per increasing native tick; duplicate, stale and paused ticks do not advance clocks
- `stepItem(actor,{tick,geometry,getGeometry})` handles gravity/rail/support for POW, loose helmet and placed 1UP. The host skips ordinary item motion for owned actors. It skips generic pickup for POW/helmet/Skewer and owns ordinary placed-life collection. Skewers are handled without generic motion
- `geometry(base,actors,{exclude})` replaces prior adapter bodies with live solid POW rectangles and true `dx/dy`; excludes the stepping actor, spent bodies, helmets, placed 1UPs and Skewers. Preserve these POW solids when adding generic standable geometry so the native motor can report underside head-hits
- `afterPlayer(player,before,{tick,input,actors,targets,screen,geometry})` validates real moving/native head contact and returns `{handled,activated,worn,effects}`. A remote matching `headHit` id cannot activate an object. Standing and side/body contact cannot activate POW. A genuine head strike spends it exactly once, marks its body dead/nonstandable and requests an effect at its actual world centre. Equipping a loose shell marks that shell worn/dead and sets only `player.helmet='buzzy'`; Fire, power and body dimensions are preserved. Placed 1UPs are skipped completely by `afterPlayer`
- `afterThwompImpact(enemy,{tick,contact,actors,targets,screen,geometry})` consumes the actual `createSmm2Thwomps.stepEnemy(...).impact` on the same tick and returns `{handled,activated,effects}`. It requires a live declared downward `type:'smm2-thwomp'` in its live `impact` state, matching native stored contact and `lastMotion`, positive downward incoming velocity, a non-embedded upward-facing POW-top contact, the actual enemy bottom/impact point at that top, and the live owned POW solid (`smm2ItemBody:true`) at its current pose in `geometry`. Remote/mismatched IDs or poses, idle/return/dead state, horizontal/underside collisions and old resting support records do not activate it. A genuine first charge may start exactly touching the top with fraction zero; the full unspent authored impact wait distinguishes that from later resting probes. It shares precisely the player-head detonation/target selection/removal code; the host still owns NPC defeat, score and effects
- `helmetContact(player,before,hazard,{tick,hazardBefore})` returns a narrow head-only `{protected:true,action:'request-return',consumeHelmet:false,approximation:true,contact}` decision for a live Thwomp. Supply its actual prior pose for a falling Thwomp. Side/body contact stays unprotected and requests `consumeHelmet:true` only for a genuine body sweep. The host first checks ordinary invulnerability, then consumes the helmet for ordinary side/bottom damage while preserving Fire/power/body size. A Skewer receives no head-protection decision. The host calls the Thwomp's actual return controller
- `playerHazardContact(player,before,{tick,actors})` returns actual Skewer base/shaft contacts with fractions, body rectangles, `damage:true`, `solid:false` and `helmetProtected:false`. Four continuous inequalities resolve the player and changing shaft together, avoiding false positives from union-footprint sweeps. Only the host applies ordinary player hurt/invulnerability. Damage boosts can pass through; there are no NPC, POW or spring kill calls
- `view(actors)` exposes the actual live bodies/states with `approximation:true`. Skewer states include the renderer's `direction`, `base`, `shaft` and `tip` rectangles
- `reset(actors)` restores owned source positions and loose/live/unloaded states and clears local clocks/contact records. A newly constructed room controller has fresh state. The host owns when death/room rebuild calls reset and whether a worn player helmet survives an ordinary room transfer

Recommended tick order: terrain begin → item begin → item motion → native player motion against current POW/terrain geometry → item player contact → enemy movement, immediate fresh `afterThwompImpact` dispatch, and real helmet decisions → player-only Skewer hurt check → terrain finish. Invoke the impact hook only when the native controller returns a new `.impact`; pass live runtime actors rather than serialized diagnostics. Rebuild geometry after a POW activation before later actor motion. A removed source placeholder never goes through generic Goomba, pickup, stomp, fire or ordinary static hazard rules. POW standing, seesaw support/launch, and ordinary falling-POW/NPC overlap remain inert.

POW activation emits `emit('smm2-item',{event:'pow-activate',roomId,tick,actorId,position,contact,trigger,approximation:true,blastRadius,supportedScreenEffect,touchingSolid,screen?,targets})`. `trigger` is `{kind:'player-head',actorId}` or `{kind:'thwomp-impact',actorId}`. The blue-POW policy (`supportedScreenEffect:true`) queries eligible bodies touching ground and overlapping the supplied screen, regardless of whether the POW itself touches terrain. Ground contact includes the real current rectangular/shaped support of a horizontally moving Thwomp. A genuine Thwomp charge striking the POW is separately reported as `direct-charge`. This follows the official palette's grounded-enemy wording and a firsthand Thwomp/POW contraption example; exact screen-edge behavior remains approximate. `touchingSolid` is a measured POW diagnostic, not a gate on the screen effect. The legacy study option (`supportedScreenEffect:false`) retains an explicitly approximate authored local radius and does not claim original blue-POW behavior. The exported `smm2PowTargets(effect,targets,{isEligible,isGrounded})` never mutates NPCs. The host defeats/scores only returned live targets.

`node --test tests/smm2-items.test.mjs tests/smm2-thwomps.test.mjs tests/smm2-terrain.test.mjs tests/smm2-stage-integration.test.mjs` covers native POW stand/jump/head-hit and once-only removal, actual native downward Thwomp-to-POW strikes (including a first zero-distance strike), rejected resting/fake/stale/side contacts and natural falling POWs, shared real radius/support-screen boundaries, free gravity and declared rail support, genuine seesaw POW/rider launch remaining inert, semisolid underside Shellmet equip with Fire preserved, rejected side/remote/duck cases, narrow Thwomp return decisions, four Skewer orientations, local fixed cycles, continuous hazard contact and damage-boost passage, no direct NPC killing by this adapter, duplicate/pause/reset/rebuild behavior, and placed 1UP validation/rail/free-motion/no-automatic-reward behavior. These focused component fixtures do not prove the complete course is playable or all original interactions are calibrated.
