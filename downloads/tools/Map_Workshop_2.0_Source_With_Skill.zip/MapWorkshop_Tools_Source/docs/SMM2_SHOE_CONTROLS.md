# 马里奥地图工坊 2.0 · Shoe controls in native play

The keyboard and controller retain their existing movement, jump, run and fireball controls. In a Shoe course:

- Space / the layout-selected A face button jumps while staying in the Shoe
- R dismounts; it never doubles as Shoe jump
- L, R, ZL or ZR on Nintendo, or LB, RB, LT or RT at the corresponding Standard Gamepad API positions 4–7, dismounts
- The explicit **下鞋** touch button dismounts; the normal touch jump button remains jump
- Down while airborne requests Big Shoe ground pound

The dismount button sits in the touch pad's middle controls and remains available when the fullscreen top toolbar is hidden. Help changes with keyboard, touch or controller use and only appears in authored Shoe rooms or while carrying a Shoe. It does not expose route coordinates or hidden layout information.

The raw Stage input contract includes `dismount` and `dismountPressed`. The play surface emits an edge for each keyboard press, touch click or newly pressed shoulder. Held commands on controller connect/reconnect, after pause/blur or during a change into Shoe context stay neutral until released. Stick deadzone hysteresis and D-pad movement are unchanged.

In existing Echo rooms, LB/L retains the deliberate 600 ms clear command. In Shoe context the shoulders emit dismount and cannot start or complete Echo clearing. Existing Clown Car courses retain their original jump-eject behavior; this input extension does not alter that adapter.

Start / P / Esc opens and resumes the existing pause menu. Controller Up/Down navigates it, the layout-selected A confirms, and B returns. The offline cover and finished-course replay continue accepting A / Start; keyboard Enter and the visible start/restart buttons remain available. Dismount is gated while paused, on a mission card or after completion.