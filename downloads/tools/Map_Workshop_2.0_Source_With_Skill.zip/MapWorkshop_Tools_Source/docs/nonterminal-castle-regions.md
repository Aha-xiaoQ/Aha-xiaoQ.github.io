# 马里奥地图工坊 2.0 · 可返回的非终场 Castle 区域

已有的 `castle.finish` 缺省形式可以与一组明确限定的 SMM2 组件组合。它仍是格式版本 1；没有新增 `finish` 枚举、终场状态、运动参数或 NPC／液面行为。

## 支持范围

- 房间 `setting: "Castle"`，`smm2Mechanics.art.palette: "smb1-castle-stone"`
- `castle.version: 1`，可配置原有 `firebars` 和 `lavaMode`；省略 `finish`
- SMM2 叶子限于 `version`、`art`、`startingLives`、`boneShells`、`liquid`、`camera`、`pinkCoins`
- 每个此类房间最多一枚粉币，必须绑定真实 `map.objects` 中的 `coin`；收集仍由人物与该身体的实际接触触发
- 旋转 Firebar 必须逐个绑定真实 `rotating-firebar` marker 的显式 `castle.firebars` 规则，不能落回旧 marker Firebar 路径
- 可使用原生管道 portal；普通门仅允许 `contraptions: {version: 1, doors: [...]}` 和 `style: "plain"`，每对仍须两个真实 16×32 portal 与合法目标 spawn

不接受 Boss、flameSources、斧头／NPC／城堡终场门／旗杆 marker 或 exit。经典斧桥终场继续排除 SMM2；已有 `variant: "smm2-door"` 的白名单和终场执行保持原样。Notes、吊爪、飞船、P、rewind、水下、Bill 等组合没有因此放行。每个已允许组件仍执行原来的字段、身体所有权、布局及目标引用校验。

## 作者操作和存取

先选择 Castle 房间和 SMB1 石城图像，然后使用已有 Bone Shell、液面、粉币及 Firebar 面板。未配置终场就是非终场房间；不需要放置隐藏斧头或新增模式。图像、角色、液面与 Firebar 的物理／绘制都复用现有实现。

搬运与钥匙面板新增“+ 成对普通门”，在两房中原子创建普通门及真实到达点，不附加沙漠场景或其他机关叶子。作者 API 为：

```js
addContraptionDoorPair(doc, sourceRoomId, targetRoomId, {
  style: 'plain',
  source: {x: 592, y: 144},
  target: {x: 32, y: 144},
});
```

`style` 缺省仍为原来的钥匙门与普通返回门，原输出形状保持不变。普通门依然要求实际站稳、人物脚部接近门底及新按下 Up／E。骨壳乘客要先 R／肩键下壳并落到安全陆地；静止下壳可能落回原壳，应给移动下壳留足距离。编辑器、History、qmap 导入／导出、collection 编译和独立 HTML 使用同一兼容门禁。

普通门转场保留全局粉币记录；死亡或整关重启的原有重置语义未改变。该中性样例保留另一房间尚未收取的粉币，因此直接验证 `taken: 1, total: 2` 的跨房状态。最后一枚粉币释放后的实体钥匙仍需真正拾取后再离房。

现有 `castle-components` 与 `smm2-castle-door-ending` 回归继续验证经典终场逐帧命令、事件、默认消息完全等于旧 fixture，以及 SMM2 真斧头、逐格断桥、Boss 坠落、开门和明确停顿后的完成状态。没有扩大原版动态或物理校准声明。
