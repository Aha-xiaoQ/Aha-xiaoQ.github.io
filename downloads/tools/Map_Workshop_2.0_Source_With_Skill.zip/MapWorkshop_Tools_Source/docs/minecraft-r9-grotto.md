# R9 slime and honey grotto

The optional `burrow` room replaces its spring entirely. It retains the pig-secret entrance, room ID, original return portal, and return spawn. Entry rock, the safe lower floor, recovery step, storage plinth, honey stack, and upper return ledge are actual native solids. Roots attach to the ceiling. Honey is visibly stored on a wooden plinth; there are no underground bees or floating natural honey. The amethyst reward is embedded in a calcite-lined formation.

## Source behavior versus authored adaptation

- Mojang's [Block of the Week: Slime](https://www.minecraft.net/en-us/article/block-week-slime) illustrates a six-block fall rebounding four blocks.
- The official [1.21.50.26 preview notes](https://feedback.minecraft.net/hc/en-us/articles/31476211695501-Minecraft-Beta-Preview-1-21-50-26) establish sneaking suppressing slime bounce.
- The official [19w41a snapshot notes](https://www.minecraft.net/nb-no/article/minecraft-snapshot-19w41a) describe honey slowing movement, reducing jumping and slowing side falls.

This is a deliberate 60 Hz, 16-pixel-block 2D adaptation, not a claim of exact Minecraft Java/Bedrock simulation:

- Slime tracks the player's true apex-to-landing foot distance and actual pre-contact downward velocity. Target rebound height is 2/3 of measured drop, capped at160 px. The native Mario terminal fall speed remains4.25 px/tick, so fall distance preserves height-dependent rebound even after downward speed saturates.
- Rebound gravity is7/16 px/tick². Launch speed is √(2 × gravity × target height) + gravity/2, accounting for the native discrete update. Test falls of32,96,144 px rebound within0.6 px of21.33,64,96 px. Holding jump gives no extra slime boost. Falls below a3 px target or impact speed below0.8 px/tick settle.
- Down on contact suppresses the rebound. It does not re-trigger while standing still. Holding jump or run never adds spring charge.
- Honey uses the existing motor's `carryMotion` contract: walk/run caps0.6/1.0 px/tick (40% of1.5/2.5), jump impulse1.6533 px/tick (40% of4.1333), and existing jump/fall gravity. Side contact caps downward speed at0.7 px/tick. Ordinary gravity and movement restore after the contact/rebound ends.
- The original Mario motor file is byte-identical to R8: SHA-256 ad453838732d359be7e72022c7ba8e29e18223eec662b1e3cc50874ccbddda90.
- Contact audio is edge-triggered, not emitted every frame. Geode coins and chime occur once per life; normal death/checkpoint reconstruction resets the room.

## Verification

`node --test tests/minecraft-r9-grotto.test.mjs` checks variable-height native fall/rebound, held-jump independence, crouch suppression, actual honey movement/jump/side slide, pause/reset, static-solid schema rejection, native route completion, missed/suppressed bounce recovery, and a genuine ordinary fall death after return followed by a complete second visit.

`node tests/minecraft-r9-grotto-proof.mjs` produces ordinary-input native-rendered evidence. No physics, reward, player position or contact state is injected. The room-first test fixture chooses the real optional room as its entry; the full discovery route separately reaches it through the pig-secret entrance. The deterministic successful room traverse is370 frames (6.17 seconds), leaving a compact first-time detour without lengthening the whole adventure. Slower first-time exploration may take longer. Full discovery and death/retry were also re-run successfully.

Evidence uses the actual native stage and shared playable Canvas renderer, not a real browser or physical-controller recording. Final package regression and offline checks are recorded separately.
