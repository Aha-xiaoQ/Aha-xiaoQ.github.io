# 1.11.0 标准 GitHub 更新包

目标仓库：https://github.com/Aha-xiaoQ/Aha-xiaoQ.github.io
只做本地交付，尚未提交、推送或发布。

## 应用方法

1. 保留当前仓库和现有下载包备份。核对当前工作区，不能覆盖未提交的自定义修改。
2. 将外层 Aha-xiaoQ.github.io_Map_Workshop_1.11.0_Update.zip 解压到临时目录。它是仓库相对路径覆盖包，不是完整网站副本。
3. 将 downloads/ 和 docs/ 下列出的文件按同名相对路径复制到现有仓库根目录。只覆盖 downloads/tools/Map_Workshop_2.0_Source_With_Skill.zip；新增 docs/release-map-workshop-1.11.0 下的说明和校验文件。不要删除其他网站文件。
4. 检查Git差异和SHA清单。若原下载包不是下方基线SHA，先检查是否已有人更新，不要盲目覆盖。
5. 用户决定发布时，再在完整仓库运行当前站点发布检查/构建流程并提交。此包不执行发布，未声称整站测试或线上验收完成。

标准下载包内部顶层为 MapWorkshop_Tools_Source，包含完整源码、音频、图片、例图、工程skill及许可。用户下载后只需解压一次，Node.js22+运行 node server.mjs。构建/测试前运行 npm ci。

## 基线与变更范围

官方main提交：cb682d3baa2592db07163714d61e8aa66251305a。
原下载包SHA256：3b1bef9e47c9ef47e12c9d12a9b892e5fd8b886e64108372a9f61c3144b389b9。
原工坊实现1.10.34，新实现1.11.0；网页“地图工坊2.0”为发行名，固定下载URL不变。
已核对 content/asset-manifest.js 与 content/site-data.js：没有该下载包的大小或哈希登记。因此本次不修改内容登记或生成页面。
packages 下旧在线编辑器、游戏、视频、网站首页等全部保留。临时录制视频、node_modules、dist缓存、私人录音不在包内。

## 发布前证据

2348项自动化测试通过；9份旧地图原样往返、可选MC模板普通输入通关、独立目录重建字节一致；新作者面板、逐房间音乐与条件导出已独立复核。标准单包还须通过ZIP CRC、双层安全路径、内部manifest全文件SHA、skill引用和版本检查。
真实浏览器全屏、实体手柄、音频设备及整个1.75GB站点的发布投影未在本次完整验收。该限制不影响本次确定的下载文件替换，但实际发布前仍应在完整站点工作区验证。

配乐署名和各类素材许可完整保留，不因合并ZIP改变授权。详见 ASSET_LICENSES.md、docs/MINECRAFT_MUSIC_CREDITS.md 与各资源目录。
