# 马里奥地图工坊 2.0 · 作者场景旗帜与背景彩蛋

`atlas/editor-authored-scene-accents.mjs` 只绘制明确 `smm2Art` 标签、`material:'decoration'` 的记录。`drawAuthoredSceneAccent(c,q,room,tick)` 供通用地块派发逐条调用，`drawAuthoredSceneAccents(c,room,tick)` 供宿主一次绘制整组。没有房间名特判、碰撞体、敌人、奖励、触发器或进度。

## 小库巴竞技场

`jrGalleryFlagDecorations(room)` 从真实 `boss-left-inner-arch`、`boss-right-inner-arch` 的位置与宽度获取顶部中心；当前柱顶中心为 (88,224)、(488,224)。两根 14px 短旗杆的底脚与柱顶相接，11px 布旗从世界 y212 开始，主图案位于默认 y192 镜头的主 HUD 下方。旗杆／旗布均不穿过坐席观众。

布旗包含橙红底色、金色三尖小冠、绿脸与米色围领。像素由本项目作者绘制，是小库巴主题的原创场景徽记，不是 Nintendo 原旗帜或原贴图。只有布边每 24tick 一像素微动，徽记、柱脚与旗杆保持稳定。旗帜的字段与普通装饰一起保存于 qmap，标准编辑器的装饰选择与移动仍有效。

## 中枢

`hubSceneAccentDecorations()` 返回恰好三个小图案：

- (112,292) 的细线抓爪与悬挂奖品小光点
- (174,310) 的六点蛇形星座，细光线连接，无箭头或地形方块
- (292,294) 的三架小飞行包，松散三角编队，无武器或攻击提示

图案以约 0.22 alpha 绘在背景，墨格大小一世界像素，不构成 16px 方块地形的假轮廓。三个图区均在世界 y280–322，离门顶 y360、门上清除标记及 HUD 位置有空白。保留当前原生地面、门、回程管与进度标记。

代码与这些原创场景像素按 `LICENSE-CODE.md`；既有 Nintendo 人物、地形、音频以及字体数据继续各自保留来源与许可。新旗帜不声称原版 Nintendo 旗帜；三种背景彩蛋不声称原版 Nintendo／Namco 资源。

```sh
node --test tests/authored-scene-accents.test.mjs
```