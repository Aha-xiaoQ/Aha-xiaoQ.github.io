# 马里奥地图工坊 2.0 · 格式与接口

权威 schema 是实际 JavaScript 验证器：atlas/editor-model.mjs、atlas/editor-collection.mjs、atlas/runtime/stage-catalog.mjs。各组件叶使用对应模块的 validate…Room 验证器。本包未恢复额外 JSON Schema 文件。

## qmap

JSON format 为 xiaoq-map-project，version 为 1。blank(title,width,height) 创建带 main 区域和出生点的工程；parseProject(text) 导入并验证；validate(doc) 可能执行兼容正规化，应保留输入副本。clone 和 History 管理整份作者数据。

工程 id/title/rooms 必须存在。单工程 1–128 个区域；16px tile；宽 256–32768，高 120–4096，总网格受 MAX_CELLS=262144 限制；geometry/objects 各不超过 20000 项。roomId 在工程内唯一，元素 id 在区域 geometry/objects 内不重复。组件 sidecar 绑定真实同 ID 原生体，复制/删除需同时维护引用。

作者 ID 规则不等同严格原生 pack namespace 规则。创建新工程/样例副本给新工程 ID，不靠改变对象 ID 消除格式错误。History.change(fn)、undo()、redo() 保留整个作者数据；导出 JSON 后用 parseProject 重新核对。

## qcollection

format 为 xiaoq-map-collection，version 为 1。COLLECTION_FORMAT/COLLECTION_VERSION 是真实源码常量。collection 与 level 稳定 ID 匹配 [A-Za-z0-9][A-Za-z0-9_-]{0,71}；revision 为正安全整数。最多 32 个自制关卡、总计 256 区域、24 MiB JSON；这不代表附带原版 32 关。

levels 保存完整 qmap，order 恰好包含每个 level ID 一次，entryRoom 必须存在。addLevel(collection,project,options) 新增；updateLevel(collection,levelId,project,options) 保留稳定 ID，内容变化递增修订并使旧纳入证明失效；reorderLevels(collection,order) 改顺序。parseCollection/serializeCollection 校验可迁移 JSON；可执行字段、accessor、循环、危险原型键和未知扩展受真实验证器约束。

buildCollection(collection,character,{includePending=false}) 默认只纳入满足当前条件的关卡，返回 xiaoq-map-collection-runtime 版本 1，含编译 pack、rooms 和能力清单。作者认可与私人测试纳入分开；中性 fixture 的认可只针对合成测试数据。

进度模块 editor-collection-progress.mjs 提供 createProgress、reconcileProgress、resumeBoundary、markLevelComplete、parseProgress、serializeProgress、createProgressStore，按稳定 ID/修订/指纹对齐；变更、移除、重排后调用真实 reconcile，不靠数组索引复用通关记录。

## 编译与运行

projectPack(doc,entryRoom,character,namespace='workshop') 编译可达区域、验证管道图和组件引用；developerPack(room,character,namespace,allowSwimming=false) 生成基础单区域 ABI。pack 为 schemaVersion:1，含 maps/stages/characters/audio。

createStageCatalog(pack) 严格验证；catalog.plan(stageId,characterId,{allowDraft:true}) 生成计划。原生 ID 使用小写字母/数字及连字符，最长72；编译 namespace 最长48。room/map/spawn 引用真实存在。基础 ABI 的枚举由 schema 约束；机关 sidecar、表现与扩展行为由匹配 editor-mario-stage 和 visualRooms 参与运行，不全部扁平化入 developerPack。

createPlatformMotor() 和 createPlatformStage({plan,motor,visualRooms,...}) 执行普通输入；play(pack,rooms,media,options) 挂载试玩。offlineFile(pack,rooms,read,readAudio,onProgress,options) 返回完整 HTML；options.collection 接编译后的 runtime collection，运行模块、字体、音频和品牌数据嵌入。

不要从美术名称、缩略图大小或原作名称推断物理参数。可视边界不自动改变碰撞体。更多字段直接查实际 validator 和作者工具；具体限制见 README 与各组件文档。

## Activated shell coin collection (private feature branch)

Optional room field `smm2Mechanics.shellCoinCollection` is strictly Boolean and defaults off. `setSmm2ShellCoinCollection(room, enabled)` / `clearSmm2ShellCoinCollection(room)` are atomic validated authoring APIs exported by `atlas/editor-smm2-authoring.mjs`; the existing SMM2 sidebar uses them through History. This is room policy, not per-actor clipboard data or a serialized activation token. See [SMM2_SHELL_COIN_COLLECTION.md](SMM2_SHELL_COIN_COLLECTION.md) for lifecycle, compatibility and verification limits.

## Finite slope strips (private source feature branch)

`slopes[].thickness` is optional in SMM2 mechanics 1. It is vertical strip thickness (0.1–1024), while `h` is the diagonal vertical difference. Shared `addSmm2Component(room, 'slope', options)` and `updateSmm2Component(room, id, options)` accept it; update with `thickness: null` clears the field, while persisted JSON must omit it. The sidebar uses a blank optional number control for the same clear operation. Full polygon room containment, orientation anchors, new engine `followSlopeTop` preview and legacy fallback are documented in [SMM2_THIN_SLOPES.md](SMM2_THIN_SLOPES.md).

## Explicit night lighting (Story43 development branch)

Optional `smm2Mechanics.lighting` owns only appearance. The current strict validator accepts bounded darkness/player radius/softness and at most 64 explicit stable target light sources; omission remains disabled. The shared Canvas mask reads current runtime actor/item/geometry positions and is drawn before HUD. It adds no air swimming or NPC state flags. Creator APIs and native History/clipboard bindings are exported by `editor-smm2-authoring.mjs`; complete interfaces, arrow center offsets, runtime lifecycle and old-reader rollback are documented in [SMM2_LIGHTING.md](SMM2_LIGHTING.md). qmap/qcollection/pack versions remain 1; older strict SMM2 readers reject this new optional leaf.

Optional `lighting.offRadiusScale` is finite in `[0.05,1]` and requires an existing same-room `switchStudy.version:1`. It multiplies all existing light radii only when actual runtime `view.switchStudy.on` is false; absent or malformed live version/state emits no sources and never falls back to author `initialOn`. Explicit preview uses initial state. The switch is not a light source and no game state or physics is changed. Omission preserves constant-radius lighting. Native set/clear APIs, sidebar checkbox/multiplier, History, clone/import/export and offline exports support it; collection capability is `switch-linked-night-lighting-v1`. Older lighting-aware strict readers can use a copy with only this field removed.

## Authored physical P Switches (Story43 development branch)

Optional `smm2Mechanics.pSwitches` binds stable IDs to actual native 16×16 walker bodies, with explicit up/down pressure direction, gravity/fall speed and optional shared item rail. `addSmm2Component(room,'pSwitch',options)` and `bindSmm2PSwitchRail(room,id,rail)` are atomic author APIs. Real directional contact drives the existing global timed coin/brick conversion; expired items remove their light. See [SMM2_P_SWITCHES.md](SMM2_P_SWITCHES.md) for schema, approximate ceiling contact/art, author clipboard and offline closure. The native qmap/qcollection/pack versions remain 1; old strict mechanics readers reject this new leaf.

## 可选 geometry.content 与放置检查

qmap／qcollection 仍为version 1；content是已有奖励enum的可选作者字符串，新作者操作同步保存一致reward别名，旧reward-only工程保持原结构。原生map剥离两字段，实际奖励由matching editor-mario-stage与visualRooms消费。导入、作者操作、History、保存、原生pack／离线导出拦截确定非法独立可拾物与永久实体的真实相交；未知类型只warning。具体issue codes、真实斜坡边界、合法藏物、旧版本兼容范围与重跑入口见 [素材放置与藏物](MATERIAL_PLACEMENT_AND_CONTENT.md)。
