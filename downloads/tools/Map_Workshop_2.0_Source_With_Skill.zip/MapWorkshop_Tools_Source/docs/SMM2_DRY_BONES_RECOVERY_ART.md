# 马里奥地图工坊 2.0 · Dry Bones recovery warning

`drawSmm2DryBones` now translates the whole original pile horizontally only when a visible, valid `type:'dry-bones'` actor has `smm2DryBones.phase === 'recovering'`. The supplied draw tick selects 0, +1, 0, −1 source pixels, held for four ticks each and repeated every 16 ticks. The offset scales by `actor.w / 16`: a normal 16px body moves 1px and a 32px giant moves 2px. Tick 0 preserves the exact static pile. Non-finite draw ticks use the static pose.

This warning is an authored adaptation. No original recovery animation was obtained, and its timing is not calibrated to Nintendo's animation. The existing original Super Mario Maker SMB-family standing 16×23 and enemy pile 21×8 images, palette, transparency, mirroring and foot anchors remain intact. Their recorded provenance is in [SOURCE_ASSETS.json](../atlas/assets/smm2-private/SOURCE_ASSETS.json); these copyrighted Nintendo pixels remain limited to the existing private learning scope and are not covered by the code license.

Walking and collapsed phases retain their prior pixels at every draw tick. Static editor sidecars still supply a temporary walking descriptor. Generic `frame` or `phase` labels cannot trigger the warning. Bone Shell recovery remains its separate pile rendering; this enemy warning adds no rider. The visual pile overhang and offset create no collider or support surface.

Drawing reads the actual typed phase and supplied tick without changing position, dimensions, velocity, phase, remaining frames or controller clocks. The shared editor dispatch, embedded HTML art modules and existing native video bridge use this same function.

Command: `node --test tests/smm2-dry-bones-recovery-art.test.mjs tests/smm2-bone-art.test.mjs tests/smm2-original-assets.test.mjs tests/smm2-dry-bones.test.mjs`.