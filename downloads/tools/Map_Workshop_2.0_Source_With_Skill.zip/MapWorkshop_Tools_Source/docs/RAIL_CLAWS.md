# 马里奥地图工坊 2.0 · Reusable authored rails and swinging claws

`atlas/editor-rail-claws.mjs` is an original, opt-in constraint controller. It moves
real native actor bodies on authored rails. It contains no course IDs, room IDs,
target lists, enemy spawn logic, note rewards, key grants, death logic, score or
life changes. Native stage code owns those systems and all free actor motion.

The controller's numerical values are **local approximations**. The saved private
reference stills show rails with straight sections and curved ends, roughly
42-native-unit hanging chains, multiple claws and real carried objects. They do
not establish exact Nintendo speeds, swing equations, hitboxes or cooldowns.
The four inspected images were `source-course-44.jpg`, `source-course-67.jpg`,
`source-course-88.jpg` and `source-course-108.jpg`, alongside the screenshot-based
`static-qa/geometry.json` study. No image pixels become sprites or runtime data.

## Authored schema

Rails and claws are independent lists in the shared `room.contraptions` extension.
This leaf validates only these lists. The parent extension validator owns the
extension version, sibling fields and cross-module ID rules.

```js
room.contraptions = {
  version: 1,
  tracks: [{
    id: 'demo-rail',
    start: [32, 24],
    segments: [
      { kind: 'line', to: [96, 24] },
      { kind: 'quadratic', control: [128, 24], to: [128, 56] }
    ],
    mode: 'bounce'
  }],
  claws: [{
    id: 'demo-claw',
    trackId: 'demo-rail',
    speed: 0.75,
    position: 20,
    direction: 1,
    ropeLength: 42,
    swingDegrees: 18,
    swingPeriodFrames: 160,
    swingPhaseDegrees: 0,
    catchRadius: 6,
    releaseHalfWidth: 24,
    releaseBelowHeight: 144,
    regrabFrames: 16,
    playerJumpSpeed: 4.5
  }]
};
```

Coordinates and lengths use the native room coordinate system, typically 16 units
per tile, with positive y downward. `position` is **arc length in native units**,
not a fraction. Multiple claws can use the same track with independent positions,
speeds, directions and swing phases.

Every segment begins at the previous endpoint. A quadratic uses the actual
quadratic Bézier equation. `bounce` (also the omitted-mode default) reflects at
both endpoints while retaining overshoot, even when one active frame crosses
several endpoints. `loop` wraps in either direction and must end at its start;
an open path cannot teleport across a discontinuous loop seam.

The quadratic arc-length table uses adaptive subdivision with a 0.05-unit
midpoint tolerance and at most four-unit chords, bounded at subdivision depth 14.
The table estimates distance-to-parameter mapping. Anchor evaluation then uses
the actual curve, so the anchor never follows its control polygon. Tangents use
the curve derivative, with a sampled-chord fallback at a zero derivative.

All start, control and endpoint coordinates must be finite points inside room
bounds. The curve's control hull stays inside those bounds. Zero-length segments
are rejected. Swing envelopes and actor bodies can extend beyond rail bounds;
the host owns collision, camera and world-boundary behavior.

## Tunables and defaults

The exported `RAIL_CLAW_DEFAULTS` fills any omitted claw tunables. Every value is
authored and none is inferred from level progression or a desired puzzle result.

| Field | Default | Meaning / accepted range |
| --- | ---: | --- |
| `speed` | 0.75 | Native arc units per active frame; 0–256, including stationary |
| `position` | 0 | Initial native arc length; 0 through the compiled path length |
| `direction` | 1 | Initial rail direction; exactly 1 or -1 |
| `ropeLength` | 42 | Anchor-to-grip distance; 0.1–4096 |
| `swingDegrees` | 18 | Peak angle away from vertically down; 0–80 degrees |
| `swingPeriodFrames` | 160 | One local sine period; integer 2–36000 active frames |
| `swingPhaseDegrees` | 0 | Initial sine phase; -360–360 degrees |
| `catchRadius` | 6 | Grip circle radius against actual actor AABB; 0–64 |
| `releaseHalfWidth` | 24 | Half width of the below-grip cargo release sensor; 0–512 |
| `releaseBelowHeight` | 144 | Sensor distance below grip; 0–4096 |
| `regrabFrames` | 16 | Source-claw/actor cooldown after a release; integer 0–36000 |
| `playerJumpSpeed` | 4.5 | Positive upward impulse added to inherited grip velocity; 0–12 |

### Optional player-controlled swing

`claw.playerSwing` explicitly opts that claw into a **self-written, uncalibrated
driven pendulum approximation beginning at its first real player capture**.
Once established, that physical state continues until scene reset. The exact
Nintendo continuous model and numerical parameters have not been recovered.
These controls establish functional pumping, inertia, braking and restoring
motion, not numerical equivalence to Nintendo's implementation.

```js
room.contraptions.claws[0].playerSwing = {
  driveDegreesPerFrameSquared: 0.12,
  restoringDegreesPerFrameSquared: 0.18,
  damping: 0.992,
  maxAngleDegrees: 75,
  maxAngularVelocityDegreesPerFrame: 4
};
```

Omitting the entire `playerSwing` object keeps the prior passive behavior and
view fields exactly. No new field is inserted into `RAIL_CLAW_DEFAULTS` or old
claw snapshots. An explicitly present empty object enables the optional model
using the exported `RAIL_PLAYER_SWING_DEFAULTS`; omitted fields inside that
object use only these opt-in defaults.

| `playerSwing` field | Opt-in default | Meaning / accepted range |
| --- | ---: | --- |
| `driveDegreesPerFrameSquared` | 0.12 | Angular acceleration for full left/right pressure; 0–2 degrees per frame² |
| `restoringDegreesPerFrameSquared` | 0.18 | Downward-centering angular acceleration coefficient, multiplied by `sin(angle)`; 0.001–2 degrees per frame² |
| `damping` | 0.992 | Fraction of angular velocity retained per active frame, after acceleration; 0–1 |
| `maxAngleDegrees` | 75 | Symmetric angular travel bound about vertically down; 1–89 degrees |
| `maxAngularVelocityDegreesPerFrame` | 4 | Symmetric angular-velocity bound; 0.01–12 degrees per active frame |

The angle limit must contain the authored passive `swingDegrees`. The angular
velocity limit must also contain the passive sine's largest adjacent-frame angle
difference, `2 × swingDegrees × sin(π / swingPeriodFrames)`. This prevents a
capture from introducing an out-of-range initial angle or angular velocity.
Unknown fields, malformed objects and non-finite values are rejected atomically.

At the first real player capture, the driven state starts at the actual grip angle and
its current adjacent-frame passive angular velocity. Input begins affecting
the model on the next active frame while that same live player remains held.
The host passes `input.x` in -1 through 1. Input on an empty claw, carried NPC or
unheld player adds no drive force. After initialization, those empty/NPC frames
still integrate the existing angle and angular velocity with zero drive,
restoring torque and damping. Before that first player capture, the configured
claw and any carried NPC retain the exact prior passive sine behavior. Later
player captures keep the established physical state instead of reseeding it.
The angle/velocity integration is:

```text
angularVelocity = clamp(
  (angularVelocity + horizontalInput * drive
   - restoring * sin(angle)) * damping,
  -maximumAngularVelocity, maximumAngularVelocity
)
angle = clamp(angle + angularVelocity, -maximumAngle, maximumAngle)
```

The implementation converts degree-based parameters to radians for integration.
An outward angular velocity is zeroed only upon reaching an authored angle stop.
Zero input preserves inertia while damping and restoring torque progressively
return the pendulum toward down. Opposite input first reduces the existing
angular velocity and can then reverse it. Rope length does not silently select
different force constants; this model does not add moving-pivot acceleration
coupling. These are explicit boundaries of the current approximation.

Player displacement uses the resulting **actual** grip, including moving-rail
and driven angular motion. Jump release inherits that measured grip `vx/vy`,
then adds the separately authored upward `playerJumpSpeed`. The existing real
body/terrain sweep still rejects penetration and releases at the previous safe
body pose on obstruction. Driving never changes terrain, doors or rewards.

Player detach, disappearance, death or terrain-blocked release stops input
drive without resetting the claw's physical angle or angular velocity. The
empty grip continues smoothly from its previous pose, then slows and returns
toward down through restoring torque and damping. An NPC subsequently captured
by that physical grip follows the same continuous pendulum and inherits its
measured motion; the ordinary capture/body sweep still checks actual terrain.
Nothing switches back to a sine pose or supplies a fabricated transition
velocity. A controller disconnect should be handled by zero input or host pause;
a paused host does not call `step`, so physical clocks do not advance.
Only scene `reset()` clears this established physical model and restores its
authored passive initial pose. NPC transportation contains no scripted route
or destination. These lifecycle choices remain local approximations, not
verified properties or parameters of Nintendo's implementation.

IDs are unique against the native geometry, objects, markers and these two lists.
They use lowercase letters/digits separated by hyphens and are at most 72
characters. Prototype-reserved IDs and unknown track, segment or claw fields are
rejected. Limits are 128 tracks, 128 segments per track and 256 claws per room.
Validation does not modify inputs or accept non-finite numerical values.

## Controller API and native integration

```js
validateRailClaws(room, spec = room.contraptions);
const railClaws = createRailClaws(room, { emit });
railClaws.step({ tick, player, enemies, items, geometry, input });
railClaws.held(actor);
railClaws.playerHeld();
railClaws.releasePlayer({ jumpPressed, jump });
railClaws.view();
railClaws.reset();
```

Construction returns `null` when both rail/claw lists are omitted or empty,
including when only sibling contraption modules are enabled. Controller state
uses a private snapshot of the authored lists, preserving original room data.

Pass the real mutable player, enemy and item objects, not view snapshots.
The host should update this controller once per active native frame, skip its
normal motor/gravity and ordinary held-enemy contact rules for bodies where
`held(actor)` is true, and resume native motion immediately after release.
The host owns free-actor native collisions, lethal contacts and collectible
interaction. Pass the current active `geometry` every frame, including changes
from P transformations. The controller checks held/capture body constraints
against visible solids and ordinary one-way platforms. The rail pivot, chain
and empty grip continue on their authored path through terrain. No terrain is
removed or changed by this leaf.

For Mario, call `releasePlayer` every active frame with normalized `jumpPressed`
and `jump`, before deciding whether to run Mario's native motor. An explicit
`jumpPressed` is authoritative. Raw `jump` also works: the controller keeps a
button-edge latch, which needs those calls even while Mario is not held.
A release before the next `step` cannot be immediately recaptured in that step.
For explicitly authored `playerSwing`, also pass the normalized horizontal
input as `step({ ..., input: { x } })`. This input does not itself release Mario;
Jump edges remain the responsibility of `releasePlayer`.

Distinct increasing tick values advance **one** active frame, even across a
large tick gap. `step` returns `true` for a newly processed frame and `false` for
a duplicate/stale tick. Duplicate or stale ticks do not advance motion or emit events.
Omitting `tick` requests the next increasing tick. Pauses and inactive rooms
should not call `step`. `reset` clears held relationships, clocks, cooldowns and
anonymous actor ordinals and returns all claws to their authored initial poses.
It neither rewinds nor kills any actor body; native room/reset code owns that.

## Capture, hold and release behavior

The grip circle must physically contact an eligible live actor's AABB. Distant
enemies cannot be selected or teleported. Mario, portable items (including keys
and P switches), and ordinary Goomba/walker, Koopa, beetle and spiny bodies are
supported. Native enemy/marker name prefixes are accepted. Dead, dying, removed
or taken bodies cannot be caught. Emerging or carried items, seated bodies with
`vehicleId` / `clownCarId`, and bodies with
`clawCatchable: false` are excluded. Bubble, score, death and projectile effects
are excluded. A host can filter additional actors before passing the arrays.

If several actual contacts compete, the closest actor-center/grip pair wins,
then stable claw/actor IDs resolve equal distances. Array order has no gameplay
priority. One claw holds at most one actor and one actor is held by at most one
claw. A captured actor's top center follows the grip: `x = grip.x - w / 2` and
`y = grip.y`. Its `grounded` is false and `support` is null.

Before capture or an existing held-body update, the controller sweeps the real
body from its current safe pose to the desired grip constraint. It uses
one-native-unit substeps with an exact continuous solid intersection check in
each step, so a very thin wall cannot be skipped even when both endpoint boxes
are clear. Visible `collision: 'solid'` geometry blocks from every direction;
`hidden` or `visible: false` geometry is excluded. Touching a solid boundary
without entering it is allowed. `collision: 'oneway'` platforms block descent
when the body's bottom crosses their top from above, and permit upward,
horizontal and underside movement. No lethal contact logic is added.

An unsafe capture is rejected without moving the candidate. When an already
held body is blocked, it releases at its **previous real safe body position**,
without snapping to the new grip or pushing through the obstacle. It inherits
the current grip velocity and the normal source/actor cooldown. The next free
motion/collision belongs to the native stage. Thus a live brick cage prevents
extraction, while removal of those real P-converted colliders allows ordinary
transport. Removing terrain does not cancel an already incurred cooldown.

The passive local angle is `swingDegrees × sin(initialPhase + activeFrame × 2π / period)`.
The grip hangs at `anchor + [sin(angle), cos(angle)] × ropeLength`. Actor `vx/vy`
equal the grip's actual displacement since the previous active frame. This
combines curved-rail movement with visible pendulum/tangent motion and is
inherited on cargo release. No fixed velocity substitutes for that motion.

Mario's top must be strictly below the grip and within the authored vertical
sensor distance, and his AABB must touch its horizontal span, to release cargo.
Mario above the grip, too far horizontally or too far below it cannot release.
The sensor applies to held cargo only. It cannot make a claw release Mario.
Cargo releases at its current constrained pose with its current velocity.

After cargo release, every claw ignores that actor for the remainder of the
same active frame. On the next frame another claw may catch it if actual spatial
contact occurs. The original claw keeps its own per-actor cooldown; other
sources do not share or bypass that cooldown. There is no prescribed relay
order. Mario's Jump release additionally blocks capture through the next active
frame, then adds `-playerJumpSpeed` to inherited grip `vy`, retaining `vx`.

If a held actor disappears or becomes unavailable, the relationship is cleared
without moving its corpse or awarding anything. Held Goombas remain normal live
native objects. A key-bearing actor's capture/release alone never grants a key.

## Rendering and diagnostics

`view()` returns a detached snapshot:

- `version`, `approximation: true`, `tick` and active `frame`
- `tracks`: authored `id/start/segments/mode`, estimated `length` and sampled
  `points` in `[x,y]` form
- `claws`: authored/default tunables plus current arc `position/direction`,
  `anchor: {x,y}`, `grip: {x,y}`, signed unit `tangent: {x,y}`, `angleRadians`,
  actual grip `vx/vy`, and nullable `heldId/heldKind`

Only claws with an explicitly authored `playerSwing` also expose that authored
object and `playerSwingState: { approximation: true, model:
'local-driven-pendulum', active, angleDegrees,
angularVelocityDegreesPerFrame }`. `active` means the claw has entered the
continuous physical model after its first real player capture; it remains true
for empty/NPC coasting and does not indicate that player input is being applied.
Before that first capture, or after reset, it is false and physical-model
angular momentum is zero even while the passive sine claw moves. Old claws
have neither added field.

Static authoring previews can call `createRailClaws(room)?.view()` without
stepping to get the exact authored initial poses. Held actors are rendered by
the native actor renderer; they are not baked into claw art.

Diagnostics call `emit('rail-claw', data)` for `capture` and `release`, with room,
tick/frame, claw and actor IDs, actor kind, actual actor position, grip and
velocity. Release reasons are `player-below`, `player-jump`, `terrain-blocked` or
`actor-unavailable`; blocked releases include the encountered `blockerId`.
Anonymous native items receive deterministic private IDs
such as `rail-claw-item-0`; the controller does not change their native IDs.