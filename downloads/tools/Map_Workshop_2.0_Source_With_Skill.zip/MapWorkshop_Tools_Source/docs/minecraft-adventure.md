# Original voxel adventure sidecar

This local extension adds authored Minecraft-inspired creepers and falling sand to the workshop's existing Mario motor. It is an original fan-adventure rule set, not a Minecraft engine port, calibrated vanilla behavior, or official Minecraft content. The core map remains the existing native map ABI; `room.minecraft` is retained in qmap and visual-room exports.

## Authoring contract

Optional room record:

```js
minecraft: {
  version: 1,
  biome: 'forest', // forest, cave, or nether
  creepers: [{
    id: 'entry-creeper', x: 300, y: 196,
    w: 16, h: 28,
    detectionRadius: 176, triggerRadius: 48,
    fuseTicks: 90, blastRadius: 80, speed: 0.62
  }],
  destructibleIds: ['cracked-wall'],
  sandIds: ['sand-cell-a', 'sand-cell-b'],
  scenery: [{kind: 'oak', x: 128, y: 224, scale: 1}],
  labels: [{x: 32, y: 140, text: 'Retreat after the flash'}]
}
```

The fields after creeper x/y have the defaults shown. Creepers require a unique independent ID and a clear 16×28 body inside room bounds. Detection, trigger, blast and timing values are author choices and validated within bounded ranges. All destructible/sand references must name actual static solid geometry. Sand cells must be independent 16×16 solids. Sand should normally be omitted from `destructibleIds`: destroying its support causes it to fall rather than disappear. Visual scenery never grants collision, rewards or portals. Portals and exits remain ordinary native map objects.

`validateMinecraftRoom` participates in central qmap validation. It rejects unsupported echo-rewind composition, invalid/missing solid references, duplicate actor IDs, hidden/dynamic supports, unsafe fields and non-finite tuning. The new collection capability is `authored-minecraft-adventure-v1`.

## Runtime

- A creeper approaches a visible player inside detection range. Native solid geometry blocks its horizontal/vertical body. Solids also occlude sight.
- Proximity arms one visible fuse. Once triggered, it stays armed after retreat; it stops walking but retains gravity. The default is 90 active frames at 60 Hz. Pause freezes simulation and resumes the remaining hiss duration.
- One explosion removes only the explicitly authored destructible solids within circle/AABB radius. It calls the shared native player-damage path for actual radius contact. It never grants score or completes the level by elapsed time.
- Each sand cell checks actual solid support. It falls only after that support disappears, uses swept downward collision, stacks bottom-up, and remains the same native solid with the same stable ID after landing. Falling solids publish native `dy`, so the Mario motor can carry a rider. Swept head contact uses the shared player-damage path.
- Native death/continue restores authored geometry and mechanics at the actual last checkpoint. Leaving and returning to an ordinary portal room preserves that room's current state within the same life, as in the existing stage. Explicit new-room door rebuilds reset the destination controller with its geometry.
- Omission preserves the old runtime. Reset/dispose cancels fuse audio. The view is a copy and does not advance state.

`createMinecraftController(room, {emit, hurtPlayer})` exposes `step({tick,player,geometry}) -> {geometry}`, `view`, `reset`, `pause` and `dispose`. Repeating the same active tick does not advance physics twice.

Stage output is `stage.view().minecraft`:

- `creepers`: live body, state `idle/chase/fuse/exploded/fallen`, `fuse` remaining, `fuseTicks`, `flash`, `dead`
- `sand`: live bodies with `stable/falling/settled` state and support ID
- `effects`: bounded explosion, debris and sand-dust lifetimes
- `destroyedIds`: the destroyed actual geometry IDs

`stage.view().geometry` is authoritative for collision and all moved sand positions. The renderer receives the live Minecraft view, never authored coordinates in place of runtime motion. Diagnostic events use `type: minecraft`; sound events use `mc-fuse`, `mc-fuse-stop`, `mc-explosion`, `mc-sand`, `mc-sand-settle`, `mc-footstep` and `mc-portal-ambience`.

## Evidence

`node --test tests/minecraft-adventure.test.mjs` checks schema/import roundtrip, supported sand stability, locked exact fuse, one-shot explosion, bounded damage/destructible ownership, sand stacking, a one-pixel collision shelf, real native player standing/rider carry, swept sand head contact, occlusion, pause, per-tick idempotence, and normal blast death/checkpoint reset. These are JavaScript/native motor tests, not browser or listening evidence. The level-specific route and offline/browser evidence are separate deliverables.
