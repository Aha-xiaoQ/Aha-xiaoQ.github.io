# 马里奥地图工坊 2.0 · Private claw-study art and provenance

2026-10-05 correction: the native SMB1/default key and explicitly unlocked
Key Door now use two byte-preserved original SMM1 SMB1 static PNGs, described
in [key/door source notice](SMM1_KEY_DOOR_ART_NOTICE.md). The historical gold-key,
red-door and green-return drawings below describe legacy adaptations, retained
for unsupported styles and authored plain/locked state without explicit true.
The separate key HUD thumbnail and larger author sizes are uniform nearest
adaptations; no actor collision or original animation timing changes.

`atlas/editor-contraptions-art.mjs` contains original, code-native pixel drawings
made for this private educational implementation. Its copper claw, linked chain,
rail endpoints and dashes, gold key, blue P button, red key door, green return
door, note block, white/green clown cup, downward one-way wall, right arrow, diagonal desert
ground, thorn hazards, clouds, dunes and background cactus outlines are local
approximations. They are not Nintendo's official sprite sheets or exact SMM2
pixel encodings. No reference screenshot was cropped, resampled, painted over,
or embedded as a game texture. The renderer needs no network requests.

The four inspected original gameplay stills were `source-course-44.jpg`,
`source-course-67.jpg`, `source-course-88.jpg` and `source-course-108.jpg` in the
existing private reference study. The existing grid calibration and measured
geometry guided relative composition, material identities and object sizes;
the artwork was written as small rectangles, bitmap masks and integer pixel
lines. Gameplay reference: Nintendo's Super Mario Maker 2 Story Mode course 17,
“Swing, Claw! Swing!” The limited comparison stills originate in the previously
saved gameplay reference at https://www.bilibili.com/video/av57764200/?p=3 by
美国游戏玩家大斯. The original video is not included or republished.

Mario, Goombas, coins, bricks, question blocks, green pipes, finish structures
and audio stay in the existing native layer. When an explicitly authored
`ps-block` changes form, the helper reuses the existing native coin/brick
renderer. Their separate attribution and rights limitations are unchanged in
`atlas/CLASSIC_ART_NOTICE.txt`. Ownership of these new
local drawings does not convey any rights in Nintendo characters, designs,
trademarks or source gameplay. This is a private, unofficial study.

## Appearance contract

- World units are the calibrated 16px grid. Every generated shape lands on
  integer canvas pixels; no anti-aliased curves or decorative glow is used
- Desert ground completely fills its solid geometry bounds. Copper thorn
  silhouettes represent contact hazards. Faint pale cactus outlines, stepped
  dunes and clouds are background scenery and add no colliders
- Rails and chain follow their authored/runtime coordinates. Open claws spread
  about 48px, with a narrower grip when holding an actor. Chain length comes
  from the actual anchor/grip positions; the unobserved source timing is not
  inferred from artwork
- The normal car occupies a nominal 32×28px cup. Its green upper lip makes the
  opening visible. Occupants remain native actors and are rendered separately
- P depression, removal of the keyhole after unlocking, note bumping and claw
  opening give visible state feedback without labels, debug wires or a new HUD
- Draw the backdrop before terrain, machinery after terrain, then native NPCs,
  car and Mario. `drawContraptionsScene(c, room, {backdrop:false})` supports the
  split live-play layers; its default includes the backdrop for isolated previews

The resemblance is approximate, especially the copper claw fingers and wheel,
cloud silhouettes, ground grain, cup face, door frame and hazard branches.
Source measurements establish composition rather than official sprite fidelity.
The art tests verify bounded silhouettes, integer opaque edges, solid fill,
native pass-through and state differences. Saved QA renders are original-art
comparison fixtures and do not constitute source-synchronized gameplay captures.
