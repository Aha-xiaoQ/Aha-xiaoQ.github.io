# 马里奥地图工坊 2.0 · 通用回放存储codec

`scripts/replay-record-codec.mjs` 是通用Node证据存储工具；它不改变地图schema、Stage、Mario motor或普通输入规则。当前qmap／qcollection／pack仍为1，与证据容器版本独立。

旧JSON与v1/v2容器可由同步／异步readers读取，恢复完整canonical原JSON字节。默认encoder仍生成v1；显式version2或recompress使用Brotli包裹完整v1 DAG再保存gzip。存储SHA、内部v1 DAG SHA与恢复原JSON SHA分别核验，不能因路径或无损容器变化把原证据当作新游戏记录。

可对自己明确指定的文件执行：

```sh
node scripts/replay-record-codec.mjs verify route.json.gz
node scripts/replay-record-codec.mjs decompress route.json.gz restored.json
node scripts/replay-record-codec.mjs compress original.json route.json.gz
node scripts/replay-record-codec.mjs recompress old.json.gz new.json.gz --version=2
```

合成unit通过只证明当前codec契约，不能称为本包重放了36条私人课程。原完整证据与test在私人开发工程及已交质量修复ZIP中保全。
