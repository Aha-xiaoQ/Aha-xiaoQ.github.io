# 马里奥地图工坊 2.0 · Original workshop coin crane v1

This mechanism is an original arcade-style coin crane. It does not implement or
claim measured SMM2 Swinging Claw physics. Its process, aperture, speeds, timing,
button and glass artwork are workshop authored. The arm/chain/jaw silhouette
reuses the existing code-native workshop approximation from
`editor-contraptions-art.mjs`; that silhouette is not a newly verified source rip.

## Authoring contract

The qmap project stays version 1. The optional `room.contraptions.coinCranes`
array is strictly validated by `editor-coin-crane.mjs`, alongside the existing
contraptions v1 validator. Omission keeps legacy documents and Stage views
unchanged. Each room can author at most 32 cranes.

```json
{
  "version": 1,
  "coinCranes": [{
    "id": "machine",
    "coinId": "physical-pink",
    "buttonId": "push",
    "minX": 192,
    "maxX": 320,
    "restY": 64,
    "grabY": 160,
    "deliveryX": 128,
    "deliveryY": 168,
    "initialX": 246,
    "direction": 1,
    "speed": 0.75,
    "dropSpeed": 1.5,
    "liftSpeed": 1.5,
    "captureHalfWidth": 6,
    "closeFrames": 12,
    "openFrames": 12
  }]
}
```

`coinId` references one real map object of kind coin, at most 16×16, also listed
in `smm2Mechanics.pinkCoins`. `buttonId` references a unique, visible, stationary
solid geometry body exactly 16×16. It cannot be an ON/OFF switch or contain a
block reward. The shared renderer draws a dedicated blue upward head-bump arrow.
No global ON/OFF state is changed by this button.

All X coordinates are world-space grip centres. Scan endpoints must fit the room
with 28px margins and have at least 16px separation. `restY`, `grabY` and
`deliveryY` are world-space grip centres from 40 through room height−20.
`grabY` must equal the authored coin's centre Y, and its centre X must lie in the
scan. Delivery can be on either side of the scan. `initialX` defaults to `minX`;
`direction` defaults to +1 and permits only +1 or −1.

Optional defaults are speed 0.75, descent/lift speed 1.5, capture half-width 6,
and close/open duration 12 ticks each. Speeds must be finite and positive: scan
0.05–4, descent/lift 0.05–8. Aperture permits 0.5–16px; close/open duration permits
integer 1–120 ticks. The coin lift, horizontal transfer and delivery paths must
be clear of solid geometry. The validator includes the full capture tolerance
in the delivery corridor and rejects invalid edits atomically.

Optional `glassIds` is a list of at most 16 unique static solid geometry IDs.
Each body must be within the room, 4–32px wide and have positive height.
The common tile renderer draws transparent blue glass edges inside the body's
exact rectangle. These bodies retain their authored solid collisions; visual
transparency is not a collision exemption. The arm's open tips extend about
24px either side of the grip, so authors should also leave that visual clearance
inside the glass. Coin-path validation does not claim full jaw collision physics.

The dedicated editor panel places a crane with a real Pink and solid button,
edits all parameters and button coordinates, duplicates/removes the linked
device and supports History. Editing `grabY` moves the same authored coin to
the new centre height. Component cloning and ordinary selection copying remap
crane, coin, button, optional glass and light IDs; selecting either linked body
copies missing counterparts in their actual layers. Generic deletion prunes
dangling references. Qmap import, export and reimport preserve stable IDs.

## Native cycle and ownership

The carriage scans automatically and reflects at its authored endpoints. Only
the native player's actual underside/head collision with the dedicated button
starts a cycle. A press locks the current X; it lowers, closes, then compares
the actual coin centre with that grip's capture aperture. Missing does not move
the coin or award anything. The empty claw rises, returns to the scan's left
end and becomes ready for another jump. Busy/finished presses are ignored;
duplicate contacts in the same tick cannot start another cycle.

A capture preserves the same world coin ID and its small horizontal offset
from the grip. The actual mutable room object's position advances on every tick
of lift, horizontal transfer and delivery descent. The controller sweeps the
coin against real solids. Unexpected dynamic obstruction releases the coin at
its last safe position and returns the claw; it does not teleport through walls.

At the delivery height, the claw opens for the authored duration and releases
that real coin. It falls with workshop gravity 0.22px/tick², capped at 4px/tick,
and lands on native solid or semisolid tops. This is original machine motion,
not a measured Nintendo coin-gravity claim. A released coin stays in the bay
while the claw returns. The machine's ownership deliberately prevents collection
before release; it also reserves its coin for actual player pickup rather than
a passing shell. This is an original machine rule, not a new SMM2 ordinary-coin
rule. Native player/coin overlap performs the existing Pink pickup. Capture,
release and reaching a phase never increment coins or release a key.

Uncollected room reentry resets the crane and original coin position. Collected
reentry stays collected without duplicating a Pink. Real death and the existing
life continuation reset all run-local Pink/key progress. View/render calls are
pure; pause and dying frames freeze the crane. Mutable object storage and new
view leaves are only allocated in rooms opting into coin cranes.

`view.contraptions.coinCranes` reports phases scan, lower, close, raise, transfer,
deliver, open, return, delivered and collected, actual grip/anchor, held coin ID,
cycle count and button state. `coin-crane` events report button-press,
button-ignored, capture, miss, delivery-arrival, release, retry-ready,
cycle-complete, transport-blocked and coin-collected with room/crane/coin IDs.

## Lighting, rendering and offline closure

The existing explicit night mask is preserved. An authored light source may
reference the stable crane ID, resolving to the live grip, or the real coin,
button or glass IDs. Collected coins cease emitting light because the real
object disappears from the runtime view. No stale authored position is used
for a runtime crane light. Preview resolves only authored initial positions.

Gameplay, editor preview and Canvas recording use
`drawCoinCraneWorld(ctx, rendererRoom(authoredRoom, view))` after the world terrain
pass. `drawTile` dispatches the same button/glass pixel code. Both new runtime
and art modules are embedded by `editor-offline.mjs`; tools are editor-only.
Collection builds declare `original-coin-crane-v1` alongside `contraptions-v1`.
There is no separate runtime capability allowlist in this source; the existing
collection capability manifest is the actual consumer.

## Neutral evidence

```sh
node --test tests/coin-crane*.test.mjs
```

## Optional paid cabinet and linked payloads 

The free single-Pink controller stays unchanged when the following new
options are absent. These strictly optional leaves extend the same qmap v1
reader; older strict readers can reject them. The 1-coin fee, 10-coin entry
bonus and automatic close are original workshop rules. They are not a native
Neon/SMM2 price, two-button sequence or physics calibration.

```json
{
  "payment": {
    "price": 1,
    "entryBonus": 10,
    "slotId": "cabinet-slot",
    "slot": { "x": 96, "y": 176, "w": 16, "h": 16 }
  },
  "cabinet": { "x": 176, "y": 32, "w": 176, "h": 176 },
  "payloads": [
    { "id": "ordinary-coin", "kind": "coin" },
    { "id": "goomba-plush", "kind": "goomba" },
    { "id": "spiny-plush", "kind": "spiny" },
    {
      "id": "cabinet-bomb",
      "kind": "bomb",
      "motion": { "minX": 240, "maxX": 312, "y": 128, "speed": 1, "phase": 0 }
    }
  ]
}
```

Payment is all-or-nothing: `price` must be 1, `entryBonus` must be 10, and
`slotId` is a new unique actor ID. Its rectangle is exactly 16×16, bounded and
clear of solid terrain and portal bodies. It is a visible interaction actor,
not an added solid map tile. The parent Stage supplies near-slot input only
for that actor, and must resolve door/switch interaction priority before payment.

A bank passed to `createCoinCranes(room, { emit, bank })` implements `balance()`,
`grantOnce(roomId, amount)`, `credit(token)` (or `getCredit(token)`),
`setCredit(token, n)`, and `spend(price)` returning a boolean. The token is
`roomId + ':' + craneId`. Constructing the controller, rendering a view, and
ordinary reset never grant a bonus. Actual room entry calls
`reset({ objects, taken, entry: true })`; the session bank records the once-only
room grant. The same bank keeps unused prepaid credit across controller rebuild,
room reentry and life continuation. A new course session uses a new bank.

`step({ tick, objects, geometry, taken, payPressed, nearSlotId })` accepts a
rising-edge payment input. Holding that input cannot repeatedly debit the
wallet. Far input, a busy/finished machine, an already paid machine, and an
insufficient wallet cannot debit. Payment records one unused play; only the
existing real head-button contact consumes it and starts a cycle. A miss,
wrong plush or bomb contact consumes that play without an automatic refund.
The parent owns real global coin collection and the wallet counter.

Each optional payload references a unique existing map object. `coin` must
reference an ordinary, untyped coin; `goomba`, `spiny` and `bomb` must reference
an inert `crate` body. They do not instantiate ordinary enemy movement,
stomping, contact damage or inventory rewards. Bodies are at most 16×16,
stationary in authored map data and inside the scan cabinet. Ordinary coins
and plushes start with their centre at `grabY`; bombs may occupy the descent
column above it. Only bomb payloads may author `motion`. Its X endpoints and Y
are centre coordinates, speed is 0.05–4px/tick, and optional `phase` is an initial
path distance in 0–twice-the-span. The actual crate moves on that bounded
horizontal reflected path. The optional cabinet is a room-bounded rectangle,
and every payload and complete bomb motion path must fit inside it.

Closing compares the real current centres against the horizontal aperture and
matching grab height, then chooses the nearest actual body. A grabbed ordinary
coin follows the same physical carry, delivery, fall and later player-overlap
pickup path as the primary Pink. It never increments inventory on capture or
release; collecting an ordinary coin leaves the machine available for Pink.
The 1-coin pickup can restore the 1-coin fee through actual collection. Every
owned coin is uncollectible until successfully released. Taken IDs prevent
ordinary/Pink duplication on reset and reentry.

A captured Goomba/Spiny plush visibly lifts, lowers back into the bin, opens
and returns without a reward. Bomb contact with the actual descent/lift sweep
flashes and jolts the cabinet, drops any held body safely into the bin and sends
the empty claw back. This event is cabinet-local, does not depend on a global
movement-speed threshold, and never emits a global explosion or player damage.

The extended controller exposes `ownsObject(id)`, `isInertPayload(id)`,
`ownsCoin(id)` and `canCollectCoin(id)` so Stage can suppress generic crate
movement/collection and premature owned-coin pickup. View projects every live
payload as `{ id, kind, body: { x, y, w, h }, released, held }`, including the
primary coin as kind `pink`. Additional fields are `tick`, `wallet`, `price`,
`paid`, `needMoney`, `bombFlash` and `failedKind`. Plush return adds the
`reject-lower` and `reject-open` phases. Views do not mutate the bank, bodies or
cycle state.

The author panel supports paid placement, strict payment/payload/cabinet JSON
configuration and atomic History save. Component clone and selection copy
remap the virtual slot, all actual payload IDs, bounded motion coordinates and
cabinet rectangle. Component deletion removes the complete linked graph.
The parent model must also prune optional payload references when a real map
body is deleted.

## Optional approach payment, real large coins and live NPCs 

The preceding examples retain their explicit Up payment, 10-coin entry
bonus and inert Goomba/Spiny prizes. New maps can explicitly select no entry
gift and a once-per-approach fee:

```json
{
  "payment": {
    "price": 1,
    "entryBonus": 0,
    "trigger": "approach",
    "slotId": "cabinet-slot",
    "slot": { "x": 96, "y": 176, "w": 16, "h": 16 }
  },
  "payloads": [
    { "id": "real-ten-coin", "kind": "large-coin" },
    { "id": "real-goomba", "kind": "live-goomba" },
    { "id": "real-koopa", "kind": "live-koopa" }
  ],
  "searchlight": { "buttonId": "lamp-button", "initialOn": false }
}
```

`entryBonus` is exactly 0 or 10. Zero calls no grant function and emits no entry
bonus, including on room entry, reset or life continuation. `trigger` is
optional and accepts `up` or `approach`; omission preserves the explicit
Up rising edge. Approach uses Stage's real near-slot actor contact region.
The first entering tick attempts one 1-coin payment, without Up. The controller
tracks being inside continuously, including while busy, already paid,
exhausted or short of money. Remaining inside never retries a rejected debit
or rearms after a cycle. The player must leave and return to make a new
attempt. Unused session credit prevents a second debit even after returning.
An accepted payment exposes a 12-tick `paymentFlash`; paused steps and pure
views do not advance it. A machine whose primary Pink has been collected or
successfully delivered accepts no further fee under the existing end rule.

The new payload kinds require exact existing map identities:

- `large-coin`: an ordinary untyped `coin` body exactly 32×32, with
  `marioModules.coinValues[id] === 10`
- `live-goomba`: a `walker` body exactly 16×16 and an exact-ID native Goomba
  marker, without an alternate Mario enemy variant
- `live-koopa`: a `walker` body exactly 16×24 with an existing normal-size
  `marioModules.enemyVariants[id]` Walking Koopa configuration

All three use their actual body centre for horizontal capture and their actual
top-to-bottom span for vertical contact. Thus `grabY` can intersect a large
coin or Koopa without requiring its centre to match the Pink's centre. Their
authored bodies and full transport sweeps must fit clear room terrain; outlet
clearance includes the horizontal aperture tolerance. Carry preserves the
actual contact offset and full dimensions rather than snapping or shrinking a
body. Updating `grabY` moves these bodies by the same height difference and
preserves their existing centre offset.

All three successfully captured kinds use `raise → transfer → deliver → open`.
Large coins remain the same real map body throughout transport, gravity and
player-overlap collection. Capture and release award nothing. Stage's existing
ten-coin value gives 10 exactly once on real pickup; its existing session taken
ID ledger prevents reentry/death duplicates. Old `coin`, `goomba`, `spiny` and
`bomb` kinds retain their earlier size and inert-prize contracts.

Live NPCs use the existing mutable native enemy body. Stage passes
`objects: [...r.objects, ...r.enemies]` to `reset`, `step` and `headHit`; the
controller resolves the last matching identity, so the native enemy wins over
its duplicate authored walker record. `isCaptiveActor(idOrBody)` identifies
controller-owned static, carried and failed-drop NPCs. Stage must exclude them
from ordinary movement, platform/NPC transports, player/enemy contact,
projectiles and reward targets while captive. `npcDisposition(idOrBody)` is
`captive`, `held`, `falling` or `native`, and is null for a non-live payload.
Views also expose that disposition on each live payload.

Only the actual outlet open/release transfers live NPC ownership to Stage.
The controller restores that body's prior native walking velocity, clears its
vertical velocity and support, and stops applying its own gravity or position
updates. The same NPC then falls, lands, walks and uses the already existing
Goomba/Walking Koopa stomp, shell, damage and reward rules. Release creates no
new enemy or inventory reward. A reset receiving that same released native
body preserves its world position, velocity and native lifecycle. Existing
room/life rebuilds supply a fresh body, which starts captive under the same
authored map contract. On bomb or transport failure, ownership stays
with the controller and the actual body falls safely inside the cabinet.
A later descent follows that returned body's current centre, permitting
recapture after it has landed below the original grab height.

`searchlight` binds a second dedicated, visible, static 16×16 solid button.
Its ID differs from the start button and every other machine button. It has no
fee or play credit. A real head hit toggles only `lampOn`, including while the
claw is busy; a same-tick duplicate is ignored. Reset restores `initialOn`,
independently of the course's global ON/OFF state. Sweeping lamps can bind to
this machine using `enabledWhenMachine: craneId`; lighting reads `lampOn`
without advancing the controller or changing the global switch.

Component clone and full-machine selection copy preserve actual large/live
dimensions, ten-coin values, native markers/semantics, Walking Koopa variants,
searchlight button, payment slot and machine-bound sweeping lamps. Their IDs
and world coordinates are remapped together. Component removal clears those
linked bodies, native/value references and machine-bound lamps atomically;
generic object deletion must prune its now-stale payload/value/variant links.