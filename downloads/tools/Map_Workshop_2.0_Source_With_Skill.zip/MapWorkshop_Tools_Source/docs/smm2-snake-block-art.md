# 马里奥地图工坊 2.0 · 正式Snake Blocks跨风格材质适配

为Snake Block元数据增加最窄的材质派发。`drawSmm2SnakeBlockTile`只接受真实`smm2SnakeBlock`色别和有限矩形，复用`editor-smw-underwater-source-pixels.mjs`中的原绿／蓝16×16RGBA；共享`editor-art.mjs`在普通材质派发前调用它。其它地形、人物、背景、物件和房间palette保持原来的选择规则。

这使SMB1／SMB3等环境中的正式Snake不再退回未知材质色块，但它是SMM2 SMW素材家族适配，并非取得对应风格的原作完整素材。原素材许可和来源保持既有记录，公共原PNG保留原始颜色与透明角；落下时的0.43色彩暗化为已有作者呈现。原视觉alpha不变，碰撞仍由Snake controller自己的16×16实体负责。

原生编辑器效果预览沿用已有`drawSmwUnderwaterSnakeWorld`入口，名称保持兼容；现在当且仅当房间实际配置正式snakeBlocks时，按初始占据路径使用同一材质，不需要水下palette。预览不启动列车、不推进时钟、不写author配置。运行时只画controller当帧cells；removed格不画，falling格按物理坐标画。