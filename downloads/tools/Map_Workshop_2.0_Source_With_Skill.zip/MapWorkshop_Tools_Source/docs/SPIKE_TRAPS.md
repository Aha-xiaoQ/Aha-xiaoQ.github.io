# 马里奥地图工坊 2.0 · Spike Trap component and fidelity boundary

This optional component models the ordinary Spike Trap used in SMM2's SMB-style
story course 17. It is a visible solid obstacle which damages Mario on actual
body contact. It is distinct from the moving Spike Block in the 3D World style,
from a non-solid generic hazard, and from lava.

Author it through **轨道、搬运与钥匙机关 → 实体尖刺陷阱**, or store a visible
map object with `kind: "hazard", spikeTrap: true`. Position and size are the same
for its artwork and collider. Copying the object retains the flag; changing its
position or removing it changes the component atomically. The old optional
`contraptions.spikeTraps: [{id}]` reference format remains readable.

The editable project and offline `visualRooms` keep this metadata. Export to the
closed base native-map ABI strips the author-side flag. Therefore the project
requires this extended workshop runtime; a bare base pack is not enough to
execute the Spike Trap rules. Existing untyped hazards retain their old behavior.

## Verified qualitative rules

The primary paper *You Can't Solve These Super Mario Bros. Levels: Undecidable
Mario Games* (FUN 2024), sections 4.1–4.2, describes the Spike/Goomba rules for the
four ordinary 2D game styles in SMM1 and SMM2. Goombas safely walk on spikes, and
an enemy-loaded Clown Car touching spikes panics upward. Its Figure 20 includes
an actual SMM2 gameplay screenshot of that upward flight.

https://drops.dagstuhl.de/storage/00lipics/lipics-vol291-fun2024/LIPIcs.FUN.2024.22/LIPIcs.FUN.2024.22.pdf

This source does not specify the exact collision tolerance, Goomba sprite-sized
hit box, panic acceleration/duration, or Mario-driven car response. It does not
explicitly establish Koopa or every other NPC's spike behavior. In this component,
all native actors collide with the solid terrain, but the independently tested
immunity case is an ordinary Goomba. Other actor cases are not fidelity claims.

Clown Car panic is an explicit `npcSpikePanic` option and applies only to an
NPC-occupied cup. Player-driven and empty cups do not enter that state. Mario's
body contact remains a real hazard. See `CLOWN_CARS.md` for the openly authored,
uncalibrated parameters and limits.

## Regression coverage

Old course inputs and files are retained as historical evidence. Their former
non-solid, NPC-killing spikes were a transcription error, so current corrected
rules are not weakened to make that old recording pass.
