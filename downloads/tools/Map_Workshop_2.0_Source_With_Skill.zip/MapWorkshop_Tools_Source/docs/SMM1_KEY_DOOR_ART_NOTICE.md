# 马里奥地图工坊 2.0 · SMB1 key and unlocked door source artwork

SMM1 SMB1 key and unlocked Key Door source sprites — 2026-10-05

The two .original.png files preserve the successful public MarioWiki original
PNG responses byte for byte. They are Nintendo copyrighted Super Mario Maker
(2015), Super Mario Bros. style artwork, not a native SMM2 extraction. File
pages, successful direct GET URLs, source-version timestamps, response hashes,
decoded RGBA hashes, dimensions and palettes are recorded in SOURCE_ASSETS.json.
Public catalogue availability and the file pages' fair-use rationale are not
an open-content artwork licence. Private learning comparison only; artwork
rights remain independent of the workshop MIT code licence.

The native key is 14 x 16, 150 opaque pixels and three opaque colours, with
right-side teeth. A standard 16 x 16 cell places it at (1,0), without stretching.
Existing released 14 x 14 and 12 x 12 actors keep their unchanged colliders;
world art retains its own native centre/bottom anchor. Only already-existing
key actors reach this art dispatch, including non-desert native SMB1 rooms.
No owned-key world follower or additional actor is created. Other explicit
styles keep their legacy fallback. Larger or other explicit author rectangles
use a uniform nearest-neighbour adaptation relative to a 16px cell, centred
and bottom anchored; 32 x 32 displays 28 x 32 source art. This is author scaling,
not an original giant sprite. The HUD uses a separate uniform 0.75 thumbnail
(10.5 x 12) in its existing 12 x 12 slot, with unchanged text positions.

The green door is the original 16 x 32 static unlocked Key Door, with white
frame, left handle, right hinges and screw corners. Only an already explicit
unlocked === true native SMB1/default state selects it. The existing controller
already marks plain return doors true; its state overlay now also reaches the
actual editor preview across themes. Authored plain doors without that flag,
locked red doors and unsupported styles retain labelled legacy adaptations.
The regular SMM1 panel-door sprite is not used. No approved original red locked
PNG is included, and the green image does not reconstruct a red original.

The retained SMM2 Story28 finite frames at actual 80.435 s (key) and 84.397 s
(green door) corroborate appearance only. No continuous key animation, key
following speed, delay, collection, inventory, door transformation, red-to-green
transition, score, sound or original timing is established by those frames.
No such mechanics, schema, ownership, physical rectangle or sound is changed.
The separate decorative castle terminal door is unchanged.

Exact source rows are encoded once in editor-smm1-key-door-source-pixels.mjs,
shared with editor-smm2-source-assets.mjs, editor preview, live play, offline
HTML and native Canvas. No screenshot is used as a texture, and no runtime
network request is needed. Test/raster evidence uses real workshop Stage/motor
with ordinary simulated jump, movement and Up input, not game state injection,
a physical browser or original Nintendo timing calibration.
