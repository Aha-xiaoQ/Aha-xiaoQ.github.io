# 马里奥地图工坊 2.0 · SMM2 component authoring in the native workshop

The existing editor now has **SMM2 实体与地形 → 咚咚、平台与道具** in its properties sidebar. Open that section, choose a component type, adjust the pixel coordinates and settings, and click **新增组件**. Its thumbnail shows the component's initial appearance. Choose an existing component to edit, clone 16 pixels to the right, or delete it.

Supported components:

| Component | Authoring storage | Physical representation |
| --- | --- | --- |
| Thwomp, including explicit wing and mass settings | `smm2Mechanics.thwomps` | Same-ID native `walker` body |
| Donut | `smm2Mechanics.donuts` | Controller-owned solid or one-way rectangle |
| Floor or ceiling slope, rising left or right | `smm2Mechanics.slopes` | Actual solid triangle |
| Seesaw | `smm2Mechanics.seesaws` | Actual angled bar and declared pivot |
| Static vine | `smm2Mechanics.vines` | Native climbing region, with no top portal |
| POW | `smm2Mechanics.powBlocks` | Same-ID native `walker` body |
| Preplaced Buzzy helmet | `smm2Mechanics.helmets` | Same-ID native `walker` body |
| Skewer | `smm2Mechanics.skewers` | Same-ID native `hazard` base |
| Pink coin | `smm2Mechanics.pinkCoins` | Same-ID native `coin` body |
| Preplaced 1UP (`placed1UP` tool type) | `smm2Mechanics.placedItems`, `kind: "life"` | Same-ID native `walker` body |

The defaults reproduce the existing Stone Citadel transcription's authored tuning. They are local approximations. Validators enforce bounded dimensions, timing, movement, safe leaves and room compatibility. The tools introduce no world scripts, automatic key-bearing bosses, goal requirements or course layout changes.

## Positioning, selection and copying

Physical actor coordinates and sizes belong to the native object. Use the existing **对象层** selection and movement tools to drag or numerically move a Thwomp, POW, helmet, Skewer, pink coin or 1UP. Selecting one such actor in the map selects its component in the inspector. You can subsequently choose another component in the inspector without changing the map selection.

Donuts, slopes, seesaws and static vines live entirely in their mechanics leaf. Use the inspector's position/size fields and clone/delete buttons for these terrain components. Native geometry brushes and selection boxes do not select, crop or move them. Seesaws use `pivotX`/`pivotY`, length and angle rather than a fictitious flat rectangular collider.

Native object **复制 / 粘贴** retains the SMM2 actor leaves with new actor IDs. It preserves the captured direction, timing, gravity, equipment/item meaning, pink status, named one-way support IDs and any already-authored enemy key reward. A clipboard can cross rooms only when its preserved support references and all other settings validate in the destination. A failed paste restores the complete pre-paste project.

POWs and 1UPs already attached to a rail can be inspected and updated. Their existing rail leaf is retained, and a position change must still match that rail's declared initial sample. The inspector does not author tracks or attachments. Both the component clone button and native object paste reject rail-attached items atomically, since a translated body would no longer match its rail anchor. Original components remain intact.

The clone button duplicates the selected component's settings and shifts its physical position by 16 pixels. Native clipboard copying also retains separate already-authored enemy reward bindings. The inspector does not create or edit those bindings, and its component clone button does not duplicate them.

## Deletion, history and export

Deleting or erasing a native actor removes its owned SMM2 sidecar and any same-ID enemy reward. Deleting a named one-way native support or a Donut removes that ID from Thwomp support lists. Replacing/cropping native one-way geometry creates new native IDs; the inspector does not guess a replacement support binding. Newly introduced invalid references remain errors instead of being silently discarded.

Creator actions run through the workshop's existing `History` change/commit path. Invalid edits leave the document and undo stack unchanged. Undo and redo include both body and leaf changes. Local save, qmap JSON export/reimport and native standalone/offline play keep the existing project format. The offline player uses the established mechanics and art modules; the creator inspector is not embedded into play.

The map preview initializes the actual terrain controller, draws its true floor/ceiling slopes, Donuts and seesaw angles, and renders static vines through the same native sprite path as play. Existing same-ID actor art dispatch supplies the Thwomp/POW/helmet/Skewer/pink coin/1UP appearance. Structure view draws real triangular and angled terrain geometry. Preview initialization neither advances the course nor mutates author data.

## Reusable authoring API

`atlas/editor-smm2-tools.mjs` exports:

- `addSmm2Component(room, type, options)` returning the created ID
- `updateSmm2Component(room, id, options)` preserving unedited recognized settings
- `removeSmm2Component(room, id)`
- `cloneSmm2Component(room, id, {id, dx, dy})`
- `listSmm2Components(room)` and `smm2ComponentTypes`
- `mountSmm2Tools({parent, room, selected, change, report})`
- `drawSmm2EditorTerrain(context, room, {effect})`
- `captureSmm2ActorLeaves(room, ids)` and `appendCopiedSmm2ActorLeaves(room, snapshot, idMap)` for native clipboard integration
- `pruneSmm2DeletedReferences(room, beforeRoom)` for native delete/erase integration

Create/update/remove/clone and clipboard append validate detached room copies before replacement. To make an operation undoable, call it inside the host's `History.change`. Cleanup is intentionally a mutation hook used between native deletion and the surrounding History validation; callers must retain that atomic outer transaction. It removes only references to real owners/supports present before the deletion.

Focused coverage is in `tests/smm2-authoring.test.mjs`: actual sidebar DOM handlers for every component, bad-input rollback, native editor pointer/copy/paste/delete/eraser/save handlers, undo/redo, importer and native catalog compatibility, offline import-map retention, raw native actor dispatch, and raster parity with initialized live terrain/vines. These checks do not establish a complete natural clear of Stone Citadel.

## Card goals, oriented springs and camera framing

The **卡牌终点、弹簧方向与镜头** section binds existing native exit/solid geometry and controls the room's explicit art profile and camera settings. Card goals and horizontal springs require selecting **SMB3 地下** and applying that profile first so their appearance matches their physics. Binding them never switches a room's palette automatically. Removing or changing that profile is blocked while a card goal or horizontal spring remains; first restore the ordinary goal and change horizontal springs to vertical.

Existing POW/Donut and other component creation keeps `smm2Mechanics.art` absent in ordinary rooms, and preserves a previously explicit profile. Horizontal spring geometry pasted into another room requires that destination's explicit SMB3 profile. An incompatible paste rolls back the native bodies and bindings together; same-room paste and qmap reimport retain their existing behavior.

Dropdown choices remain under the creator's control while the map selection stays unchanged. A newly selected exit or solid updates the matching inspector. Blank camera fields are rejected without adding an undo entry; explicit zero is allowed. Native geometry deletion/erase prunes falling-platform contact rules only for real owners present before the deletion, and undo restores both geometry and bindings. Newly introduced invalid platform bindings remain validation errors.

These creator flows are covered by `tests/smm2-course-authoring.test.mjs`, including actual native editor geometry copy/paste/delete/save/undo handlers. Runtime modules, artwork, exported course HTML and recorded video are unchanged by these authoring fixes.

## Springs on live tops

In the native geometry layer, place a solid Springboard with its bottom touching an existing moving platform or declared Thwomp top. The SMM2 sidebar's Spring/support section binds their existing stable IDs. Binding and unlinking share the normal History transaction, validation, undo/redo, native import and export. Deleting an actual child or parent prunes its binding. A linked Spring keeps real gravity and can leave/recontact the permitted top; it is not rigidly glued. Mario still uses the existing native compression and normal/high launch. Numeric gravity and SMM2 transport fidelity remain authored approximations. Naked SMB1 Thwomp contact remains harmful.

## Shoes and native checkpoint rewards

The component picker also contains **栗宝宝鞋 / 高跟鞋**. Author the normal Shoe or Stiletto, ordinary or Big size, wings, and an initial Goomba passenger or empty Shoe. Newly added feet default to 16×16 for ordinary Shoes and 32×32 for Big Shoes. Width and height remain explicit authored native walker dimensions; the passenger and wings do not expand that foot rectangle. Changing the size selector proposes the matching default dimensions. Existing custom feet are preserved by ordinary updates and cloning. Movement and contact parameters are under the collapsed **鞋运动参数（工坊近似值）** section and are validated by the same Shoe controller as play.

`bindSmm2Shoe(room, existingWalkerId, options)` gives a real existing walker a Shoe sidecar without moving or resizing it. `addSmm2Component(room, 'shoe', options)` creates the usual native walker body and its same-ID leaf together. A Shoe body cannot simultaneously own another actor mechanic or typed enemy variant. Partial `tuning` updates retain other authored tuning values. The reusable creator entrypoint is `atlas/editor-smm2-authoring.mjs`; its exports use the same validated transactions as the existing sidebar.

**中间旗奖励** lists existing native checkpoints. Choose **不提供道具** or **蘑菇（小马里奥长大）** and an integer score from 0 to 100000, then apply. The action only annotates that checkpoint; it never creates a spawn or changes its native respawn target. **恢复原生默认奖励** removes the explicit override. The corresponding API is `setSmm2CheckpointReward(room, checkpointId, {reward: 'none' | 'mushroom', points})` and `clearSmm2CheckpointReward(room, checkpointId)`.

Native object copying retains both Shoe leaves and checkpoint rewards under the new body IDs. Native paste, delete, eraser, save, undo/redo and qmap reimport include both halves. Deleting the actual native owner prunes its leaf; unrelated new dangling references still fail validation. Removing a Shoe template also removes pipe emitters explicitly bound to that template, with undo restoring the original supply and Shoe together.

The existing Mario components pipe inspector exposes **栗宝宝鞋补给模板** for Goomba emitters and optional **出管帧数** for enemy emitters. Choose an existing Shoe template to retain its variant, feet and bounded tuning in repeated supplies. Editing the emission interval or other source setting preserves these fields. A Shoe source is an authored native pipe emitter, so item and ordinary enemy source behavior stays available through the same controls.

## Declared enemy points at the goal

**终点收尾奖励** lets an author select an existing native walker and assign an integer goal reward from 0 to 100000. The separate `smm2Mechanics.goalEnemyRewards` leaf stores `{id, points}`. It does not add enemies or change their position, dimensions or ordinary behavior. Runtime goal contact can settle only those declared actors that are actually still alive; it removes each such actor and adds its assigned points once, with visible score feedback. Ordinary enemy key rewards and checkpoint rewards remain separate authored leaves.

The **启用经典旗杆位置分数** checkbox writes optional `smm2Mechanics.flagScore`. An absent value retains the established classic flag scoring; `false` disables that flag-position score. This policy does not add goal coins or a mission reward. The Story 8 source shows a score increase from 5100 to 8100 with two living plants disappearing and 1000/2000 point feedback. Its goal coin conversion is unresolved, so no extra three-coin award is inferred from this leaf.

Reusable APIs are `setSmm2GoalEnemyReward(room, existingWalkerId, {points})`, `clearSmm2GoalEnemyReward(room, existingWalkerId)`, `setSmm2FlagScore(room, boolean)` and `clearSmm2FlagScore(room)`. Existing actor clipboard actions copy/remap the goal reward to the new native body ID. Deleting the native owner prunes its reward; undo restores both. New dangling IDs remain validation errors. The room-wide flag policy remains with its room during actor copying. All actions share the normal validated History transaction, qmap reimport and native export workflow.

## Bone Shells, Dry Bones and managed lava

The **骨壳、枯骨与升降熔岩** sidebar creates or binds a real native `walker` as an empty Bone Shell or a normal/giant Dry Bones. Starting rectangles are 16×16, 16×24 and 32×48 respectively. These are authored presets, not claims about exact source collision. Binding preserves the existing body dimensions; updates expose the actual body coordinates and size. All motion, collapse and recovery numbers are explicitly stored as workshop tuning. Giant Dry Bones has an explicit ordinary-stomp response: bounce, hurt or harmless.

Bone Shell playing-dead duration, maximum duration and drop targets are authored separately. The drop-target selector contains only actual same-room native one-way geometry. A Donut, an actor support or a managed lava surface cannot be substituted for that geometry. The lava surface remains an actor-scoped runtime support and is never inserted into common map geometry.

**骨壳管道补给** binds an existing real native pipe to an existing real Bone foot. It writes a typed `marioModules.enemySources` record with `enemy: 'bone-shell'`, `smart: false`, a `shoeTemplateId`, and explicit emergence, interval, delay, capacity, distance and launch numbers. The template-only checkbox commits with the supply in the same validated transaction. It suppresses only the initial live instance of that actual authored foot; there is no hidden or offscreen template. Removing the final source, its pipe, or disabling Mario modules clears the template-only dependency. Deleting the foot removes its bound supplies. Undo restores the complete relationship. The ordinary source inspector directs these records to the Bone panel, and its plant selector excludes Bone and Dry Bones bodies.

**真实熔岩标记与液面** creates an actual `lava-region` marker or binds an existing lava marker. A room has one managed surface with explicit minimum, maximum and initial Y, motion speed, initial direction and endpoint waits. Static lava has equal bounds and zero speed. Updating initial Y updates the actual marker atomically. Removing management can either remove the marker or restore ordinary marker behavior through the API. Moving a native geometry component with its linked lava marker moves the unchanged authored range with it. The usual object/material palette is unchanged.

The stable `atlas/editor-smm2-authoring.mjs` entrypoint exports:

- `addSmm2BoneShell`, `bindSmm2BoneShell`, `updateSmm2BoneShell`, `removeSmm2BoneShell`
- `addSmm2DryBones`, `bindSmm2DryBones`, `updateSmm2DryBones`, `removeSmm2DryBones`
- `addSmm2ManagedLiquid`, `bindSmm2ManagedLiquid`, `updateSmm2ManagedLiquid`, `removeSmm2ManagedLiquid`
- `addSmm2BoneSupply`, `bindSmm2BoneSupply`, `updateSmm2BoneSupply`, `removeSmm2BoneSupply`
- `captureSmm2BoneBindings`, `appendCopiedSmm2BoneBindings`, `pruneSmm2BoneReferences`

Creation and binding return the real actor, marker or source ID. Actor removal defaults to deleting the native body; `{removeNativeBody: false}` removes only its typed binding. Liquid removal defaults to deleting the real marker; `{removeMarker: false}` retains ordinary lava. Partial Bone `tuning` and `playingDead` updates preserve unedited settings. Supply create/update accepts `foot: {x, y, w, h}`, `tuning`, `playingDead` and `templateOnly` alongside source settings, so foot configuration and its typed source can be committed atomically.

Native object copying preserves Bone/Dry leaves and duplicates Bone supplies with new IDs and remapped real foot references. Native pipe copying retains its typed supplies; copying linked managed lava into another room preserves and rebases its range. A destination with an existing managed surface rejects the whole paste because the schema allows one surface per room. Body, source, marker and one-way-owner deletion prunes only previously valid dependencies. Newly introduced malformed references stay visible to validation. These authoring actions participate in the same save, undo/redo and qmap reimport flow as existing tools.
