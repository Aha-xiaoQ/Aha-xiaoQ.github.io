# Original Minecraft-style adventure audio

`atlas/editor-minecraft-audio.mjs` contains newly authored procedural audio. It
does not contain or download Mojang/Minecraft recordings, music, or sound files.
It creates fuse hiss, blast, granular sand, settling impacts, footsteps, portal
tones, a quiet seamless environment bed, and brief movement/reward cues.

## Runtime

The existing `createSound` gateway in `editor-audio.mjs` owns mute, stop, and
pause for both sound families. Selecting the `mc-ambience` theme explicitly
enables the adventure family. The ordinary Mario playback path, recordings,
gains, and theme selectors are retained for rooms without the Minecraft sidecar.
`editor-play.mjs` derives the custom theme from that sidecar and forwards the
complete sound-event payload.

The custom AudioContext is created only from the existing start/input unlock
path. Where supported, browser user activation is checked first. Effects fired
before unlock are dropped rather than replayed unexpectedly after permission.
Mute and pause stop active sources; reset/dispose can emit `mc-fuse-stop`.
Explosion also cancels an active fuse. Failed unlocks report their state and can
be retried by the next ordinary input gesture.

Supported event names: `mc-fuse`, `mc-fuse-stop`, `mc-explosion`, `mc-sand`,
`mc-sand-settle`, `mc-footstep`, `mc-portal`, `mc-portal-ambience`, `mc-jump`,
`mc-hurt`, `mc-pickup`, `mc-complete`, and `mc-ui`. Optional event fields are
`duration` in seconds, `seed`, `volume`, `intensity`, and stereo `pan` from -1 to 1.
Default fuse duration is 1.5 seconds. Seeded synthesis is deterministic.

## Native capture / WAV export

The browser and native export call the same `synthesizeMinecraftSound` function.
Capture the actual runtime `sound` events with a monotonically increasing video
frame index. Do not use room-local ticks as video time if the room counter resets.

```js
import {writeFile} from 'node:fs/promises';
import {renderMinecraftAudioTape, renderMinecraftAudioPCM}
  from '../atlas/editor-minecraft-audio.mjs';

// Push {type, frame:videoFrame, ...data} inside the stage's emit callback.
const options = {duration:videoFrames / 60, fps:60, sampleRate:48000,
  ambience:true};
await writeFile('adventure.wav', renderMinecraftAudioTape(events, options));
const {report} = renderMinecraftAudioPCM(events, options);
```

The WAV is stereo signed 16-bit PCM. Events accept `frame`, `tick`, or `time`
(seconds); an event's nested `data` payload is also understood. Generic jump,
pickup, hurt, portal and completion names are mapped to the adventure family by
this Minecraft-specific renderer. Unknown names and non-sound events are ignored.
The report includes exact event timing, peak, RMS, and clipped sample count.

For precise stopping on death, completion, pause, or edited cuts, pass
`musicIntervals: [{startFrame, endFrame, key:'mc-ambience'}]` instead of an
unbroken `ambience:true` bed. These intervals control only ambience; effect tails
continue normally. Frame-accurate `mc-fuse-stop` events stop a fuse in the tape.

## Verification

`node --test tests/minecraft-audio.test.mjs` checks deterministic non-silent PCM,
loop seam continuity, startup gating, mute/pause/reset and cancellation, stale
unlock promises, recovery from blocked playback, legacy gateway isolation,
frame-accurate sample matching, and WAV headers. These are synthesis and
simulated-WebAudio tests; they do not claim device-speaker listening verification.
