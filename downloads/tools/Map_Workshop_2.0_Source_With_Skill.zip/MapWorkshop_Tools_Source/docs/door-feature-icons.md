# 马里奥地图工坊 2.0 · 门特色符号

`atlas/editor-door-feature-art.mjs`提供五种24×24原生像素标志：crane（娃娃机）、snake（蛇块）、shell（运龟壳）、shooter（栗宝宝飞行包）和jr（小库巴）。这是门上显示图，不是实体敌人、机关、奖励或完成状态；实际通关勾记继续由独立completionMarks读取真实粉币身份。

用`makeDoorFeatureIcon(room,{id,portalId,feature})`生成普通decoration数据，再通过History事务加入room.decorations并validate完整工程。它检查真实本地portal，按门中心摆图：24px画框，底部位于门顶上方26px；按当前completionMarks间距，图和勾记之间留8px。修改门位置后重新调用helper更新图；保存的数据是显式坐标，不承诺自动追随门移动或绑定删除。标志可在普通装饰图层选取、移动、删除，保持24px原生尺寸；任意拉伸、负坐标、越界、碰撞／运动字段、未知本样式族会在导入／导出校验中拒绝。

标签为`authored-door-feature-`加上述五种名称，material必须是decoration。`drawDoorFeatureIcon`与共享drawTile在编辑、试玩、原生录像及离线HTML共用，导出模块闭包包含此模块。收藏编译声明`authored-door-feature-signs-v1`；根qmap/qcollection格式仍1，旧reader可能不识别此视觉能力，须升级。

柜体、分节蛇形与飞行包是本作自绘标识；壳体复用已验证SMB1原红壳16×14像素，小库巴复用现有22×22实机压缩画面逆重建。栗宝宝原像素与作者飞行包组合，不使用Namco舰船图。第三方像素与代码许可分别记录。