# 马里奥地图工坊 2.0 · Authored P Switches

This optional mechanics-1 leaf is a reusable physical component. It contains
`pSwitches: [{id, orientation, gravity, maxFallSpeed, rail?}]`. Each ID owns one
existing native `walker` object with exactly a 16×16 body. Its native ABI stays
unchanged; its meaning travels with the matching visual room. `placedItems`
does not supply or accept P Switches. Unknown fields and duplicate item owners
remain import errors. Old strict readers reject the new optional leaf.

`orientation` is `up` (descending foot pressure) or `down` (rising head pressure).
Both require a genuine directional crossing or matching native support/head
contact, with horizontal overlap at that contact. Side proximity, generic body
overlap, shell overlap and POW effects do not press this component. Upside-down
P uses a real solid body. Upright P supplies a real one-way top. A fixed ceiling
P is authored with gravity 0. Mario's ordinary motor and jump values are unchanged.

The Nintendo palette documents ten seconds of coin/empty-brick conversion and
SMB1's inability to carry a P Switch. The upside-down head rule is this workshop's
explicit directional model: the Story43 reference shows ceiling placement but
does not contain a confirmed pressing input. Contact tolerance, motion values,
rail timings and pressed art are not original-game frame calibrations. Source:
https://www.guiasnintendo.com/2c-switch/super-mario-maker-2/guia-super-mario-maker-2/paleta-elementos.html

A real press activates the existing course-wide conversion controller for 600
frames by default. An optional room `contraptions.pSwitch.durationFrames`
overrides that duration. Multiple presses refresh conversion. Each pressed
switch compresses to a noncolliding 4px strip and is removed when its own press
duration ends. Its stable ID remains consumed on room reload; a life/course reset
restores it. Empty content-free bricks convert, reward/used bricks do not.
Collected converted coins and their original bricks retain existing causal state.
The older pipe `pSources` behavior and top-stomp API are preserved.

`rail` uses the shared item representation `{trackId, speed, position, direction}`:
`position` is arc distance and `direction` is 1 or -1. The native source centre
must match the actual initial quadratic/linear rail sample. Live movement walks
the real arc in bounded steps and sweeps solid terrain, including intermediate
points on loops; a track picture alone does not move anything.

The stable author API in `editor-smm2-authoring.mjs` accepts `pSwitch` with
`addSmm2Component` and `updateSmm2Component`. `bindSmm2PSwitchRail(room,id,rail)`
atomically moves the real body to its actual starting anchor; `null` detaches it.
The sidebar exposes orientation/gravity and real rail connection controls through
History. Native clipboard, nonrail clone, remove, undo, export/reimport and
collection compilation preserve the leaf. Rail item clone/paste rejects atomically
until a new initial rail anchor is authored, as it does for existing rail items.

Lighting binds the same native stable ID and follows the current runtime item,
including moving rail P and compressed P. Once the item is removed there is no
fallback to the author's initial position or a collision proxy. Single-map and
collection offline players embed the same source/controller/art modules.

Art uses the recovered 16×16 SMM1 SMB1 source. Only dark pixels within the bounded
P glyph are adapted to white to match the observed Story43 family; blue border
and background pixels are unchanged. Down orientation vertically flips the frame.
The compressed image is an explicitly approximate bottom-four-row crop, not a
recovered Nintendo pressed animation. The original asset provenance and limits
are listed in `atlas/assets/smm2-ghost-private/SOURCE_ASSETS.json`.

Focused evidence is in `tests/smm2-p-switches.test.mjs` and
`tests/smm2-p-switches-offline.test.mjs`; it covers actual ordinary-input Stage
contact, conversion and 600-frame expiry, light lifecycle, true curves/sweeps,
stable-ID author operations, actual inspector handlers, source pixels and both
offline module closures. It does not claim an observed Story43 pressing route.
