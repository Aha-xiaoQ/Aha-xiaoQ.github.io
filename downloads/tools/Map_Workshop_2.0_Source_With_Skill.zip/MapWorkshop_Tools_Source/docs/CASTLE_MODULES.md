# 马里奥地图工坊 2.0 · Native castle modules

`room.castle` is an optional, strict version 1 extension. Rooms that omit it retain the legacy native path. It connects existing native markers, terrain, Bowser walkers and projectiles. It contains no copied Nintendo source code, ROM data, reference graphics, external images or alternate movement engine.

The full private NES World 1-4 study was informed by the supplied complete 2560×240 map analysis and thirteen finite decoded video observations. Seven six-node firebars and their directions are map-supported. The first six turn counterclockwise and the seventh clockwise. The period of 204.8 native frames is code-derived, not video-calibrated. Phase zero pointing down is a local authoring choice. Boss patrol, seeded jump jitter, attack cadence, platform motion endpoints, camera lock timing and dialogue duration remain local approximations. Five fire hits, the Goomba identity, the two axe branches, four-frame bridge removal, foot sampling and timer freezing are reference-analysis rules; the supplied video did not continuously show all of them.

## Metadata

All sections except `version` are optional. Unknown fields, unsafe/bad IDs, missing or incompatible targets, non-finite values and out-of-range values are rejected without input mutation. Castle extensions cannot combine with Echo mechanics/devices or aquatic rules until their full runtime states can be rewound consistently.

```json
{
  "version": 1,
  "lavaMode": "pit",
  "firebars": {
    "firebar-1": {
      "direction": "ccw", "ballCount": 6,
      "periodFrames": 204.8, "phaseDegrees": 0,
      "activationDistance": 32
    }
  },
  "boss": {
    "actorId": "castle-bowser", "hp": 5,
    "identity": "goomba", "fireKillPoints": 5000,
    "patrol": {"minX": 2128, "maxX": 2192, "speed": 0.4, "activationDistance": 32},
    "jump": {"intervalFrames": 150, "jitterFrames": 30, "velocity": 4, "seed": 1},
    "fire": {"intervalFrames": 180, "initialDelayFrames": 60, "tellFrames": 20,
      "speed": 1.25, "w": 24, "h": 8, "mouthY": 8, "maxAlive": 3}
  },
  "finish": {
    "axeId": "castle-axe", "bridgeId": "castle-bridge",
    "chainIds": ["castle-chain"], "npcId": "castle-toad",
    "bridgeStepFrames": 4, "bossFallFrames": 80,
    "targetX": 2424, "lockCameraX": 2048, "finalCameraX": 2304,
    "walkSpeed": 1.25, "messageFrames": 180,
    "messages": ["THANK YOU MARIO!", "BUT OUR PRINCESS IS IN ANOTHER CASTLE!"]
  },
  "flameSources": [{
    "id": "castle-approach-fire", "sourceX": 1664,
    "startX": 1440, "endX": 2048, "y": 136,
    "intervalFrames": 180, "initialDelayFrames": 60,
    "speed": 1.25, "w": 24, "h": 8, "maxAlive": 3
  }]
}
```

Firebar IDs target native `rotating-firebar` markers. There is one direction field and a strictly positive period; legacy marker speed/direction signs cannot reverse the new rule. Each node is an 8×8 rectangle, centered on the 16×16 mount center at radii 0,8,16,24,32,40 pixels. Rendering and damage use exactly these resolved rectangles. Each bar advances once per distinct active native tick, only near the camera; pauses, repeated reads, repeated ticks and inactive frames do not advance it. Before activation, design preview uses its authored static phase. `reset()` clears age and activation.

`lavaMode: "pit"` treats lava markers as artwork over actual unsupported terrain; ordinary native fall death applies. `"contact"` preserves the legacy lava touch rule. Omitting `lavaMode` retains `"contact"`.

Boss IDs target existing native `walker` bodies with a Bowser skin. The adapter sets their actual HP and preserves their ID and authored configuration. Patrol bounds describe the body's left X. Positive jump velocity is an upward speed magnitude. Positive fire speed is a leftward speed magnitude. `bossIntent()` yields a velocity, a ground-gated jump impulse, facing, a mouth frame and optionally a real `walker` / `bowserfire` body. Apply these through the native enemy collision/gravity loop and skip the legacy Bowser-specific attack/jump approximation. It does not move the body itself. Its seeded jump sequence is a reproducible local approximation. Repeated same-tick calls yield no second jump or flame.

`hitBoss(enemy, shot)` only accepts an overlapping live native `kind: "fireball"` rectangle. Call it before marking the shot dead. It consumes that shot and decrements actual HP once. The fifth valid default hit changes the body type to `goomba` and returns `defeated: true`, `identity: "goomba"`, `points: 5000`. The native stage creates the real Goomba death effect and awards that returned reward once. A defeat does not finish the room; the axe is still required.

Source regions use camera-left X, with the start inclusive and end exclusive. They emit actual leftward `bowserfire` bodies at `sourceX` / `y` and count real living bodies against `maxAlive`. They do not create invisible damage boxes. Parent stage owns their normal native motion, contact and physical departure. Restart the controller together with the native room state on a real death/restart.

## Ending contract

A valid axe trigger samples the player's horizontal foot center and bottom Y inside the axe's 16×16 cell, with vertical velocity non-negative. A powered player standing with feet at bridge Y=160 cannot trigger an axe at Y=128 merely by touching it with the head.

`triggerFinish({player, markers, enemies, geometry})` returns `{finish, commands}` on the valid trigger. `finish` is the single shared authoritative FSM record. Store that same record in the native stage. The leaf owns `finish.age`; do not also advance it in the stage. Use `stepFinish({tick, player, finish, paused})` once per native tick. It returns the same record and ordered commands. The leaf never writes player pose, score, lives, timer or terrain.

- Both branches hide the axe, freeze the timer immediately, clear existing projectiles and stop new combat
- Alive Boss: hide the linked chain, remove one real 16-pixel bridge tile from right to left each four active frames, then apply native gravity to the Boss for eighty active frames, remove that falling body and begin the automatic walk
- Dead Boss: retain the whole bridge and chain, then begin the automatic walk directly
- Use the native motor for walking. Arrival is detected from the player's real X reaching `targetX`; no player teleport, invulnerability cheat or scripted actor position is used
- Show the configured first and later message phases, then emit native completion. There is no remaining-time-to-score conversion phase

Command names are `hide-markers`, `clear-projectiles`, `freeze-timer`, `sound`, `remove-bridge-tile`, `boss-fall-step`, `remove-boss`, `camera`, `walk`, `stop-player`, `message`, `complete`. Tile commands provide `bridgeId`, the real tile rectangle and `remainingWidth`. Walk provides `direction`, `speed`, `targetX`; apply the authored speed through native motion. Camera provides its desired final left X. The stage's early finish return must suppress ordinary timer/combat processing; clear enemy flame bodies as well as player shots. Dialogue is available in the shared `finish.messages` / `messageIndex` for rendering.

## Authoring and checks

`mountCastleTools({parent, room, change, report})` mounts the actual editor panel. Pass the existing History transaction as `change`. Its inputs label pixels, frames, degrees, counts and speed units explicitly. It can add or edit firebars and their real solid mounts, configure an existing Boss or add a real Bowser walker, link existing native axe/bridge/chain/NPC markers, add a native bridge assembly, edit its real tile count and positions, choose lava behavior, and add/edit/remove flame sources. The native terrain tools supply the bridge abutment and floor before the NPC. Static firebar previews are editor-only and introduce no gameplay HUD labels.

Every linked edit validates a complete candidate before committing. Undo/redo, refresh and project import preserve the same metadata. Removing the castle extension leaves authored native objects available on their legacy path.