# 马里奥地图工坊 2.0 · Native SMB1 Koopa and Conveyor artwork

The opted-in renderer is `atlas/editor-walking-koopa-art.mjs`. It owns only live red Walking Koopa descriptors and explicit red/blue Conveyor Surface descriptors. It does not change bodies, collisions, recovery, velocities, Stage, schema, rewards or sounds. Green and unowned actors return `false`.

## Verified source pixels

The seven original PNG responses in `atlas/assets/smm2-story71/` were obtained from ordinary public MarioWiki Gallery and File pages. Each actual original URL came from that page's `fullImageLink` anchor, rather than an invented filename URL. `ASSET_PROVENANCE.json` retains URLs, exact response and RGBA hashes, byte counts, dimensions, palette, PNG chunks, encoding and copyright scope. All seven responses are real PNGs; none is WebP behind a PNG suffix. They contain no ICC profile. Runtime draws the exact embedded RGBA palette indices without a DOM, Image object, fetch or external resource request.

Standing Koopa, Red Shell and Note Block are SMM1 SMB1 catalogue images visually matched to the supplied SMM2 SMB1 final-game footage. They are not labelled SMM2 binary rips. The flat and slope conveyor catalogue images are SMM2 SMB1 originals. Source movie crops are inspection references only and do not become runtime textures.

## Walking Koopa contract

Call `drawWalkingKoopa(ctx, actor, tick, opts)` with `actor.smm2WalkingKoopa`, or an explicit `opts.view` returned by `koopaView(actor)`. The view supplies physical body, bottom-center foot anchor and inversion pivot. The red original stance is 16×23 pixels, drawn without stretching inside the independent 16×24 body. Giant artwork scales by exactly 2, so its stance is 32×46 within the 32×48 body.

The actual Red Shell source is 16×14 pixels. The nominal 16×16 visual/body canvas has two transparent rows above it; rendering retains the feet rather than vertically stretching the shell. Giant shell art is exactly 32×28 within the 32×32 canvas. A flipped living shell mirrors about the descriptor's physical center. Neither shell state uses walking legs.

The older retained original NES first walking stance matches all 368 RGBA pixels of the SMM catalogue stance after removing its one transparent top row and replacing red `#d82800` with `#f73910` and orange `#fc9838` with `#ffb259`. Its second original-family stance was therefore adapted with those same verified palette substitutions, preserving its native 16×24 proportions. This is explicitly an original-family adaptation, not a recovered SMM2 animation table. Moving, alive walking actors alternate the two stances every eight ticks. Stopped actors use the exact static catalogue stance. The cadence remains authored and uncalibrated.

The observed ON/OFF crush around original source frames 031279–031289 changes the normal red Koopa to a falling defeated shell. The specifically inspected1042.9667s frame has a red dome above and a white rim below, matching the upright source image. Shared dispatch therefore permits that native upright shell only when `opts.defeatedEffect === true`, `actor.kind === 'enemy-death'`, `actor.shell === true`, its appearance phase is `shell`, and `actor.smm2DefeatOrientation === 'upright'`. The effect remains a dead world entity; it does not become a living occupied shell. The exception does not render dead live actors or hidden effects. Normal/giant effects retain16/32px width and native14/28px source height within their16/32px effect canvas. A complete original defeated-shell orientation sequence or rotation cadence has not been calibrated. The separately observed live brick-bumped `flipped-shell` retains its existing inverted rendering.

## Conveyor contract

Call `drawConveyorSurface(ctx, controller.view().surfaces[i], opts)`. The descriptor's two `visual.rollerCenters` fix both cap centers. Each cap uses a 16×15 native crop from the original 48×15 image. Circles are never enlarged into ellipses or moved by tread animation. The original middle band repeats along the segment, with its top and bottom phases running oppositely. The controller's `treadPhasePx` is already a positive modulo of signed integrated distance and is used directly, preserving phase when the state reverses.

The canonical 48×15 flat composition at zero phase matches every decoded original source pixel. Original 48×31 sloped images are retained and verified separately. Arbitrary measured slope segments use sharp integer-pixel sampling of the original middle band while retaining upright circular native caps. Their angle fitting is a visual adaptation, not a canonical ripped sprite. Only the original inner 9×9 ring/highlight is quarter-turned for gear animation; the surrounding cap remains fixed. Tread speed and gear cadence are supplied/authored by the controller and are not inferred as physical surface velocity.

## Shared dispatch and Note rendering

`editor-art.drawObject` dispatches an owned Walking Koopa before legacy actor artwork. Static authoring objects may receive a temporary appearance from their actual same-ID `marioModules.enemyVariants` rule; stored objects and physics remain unchanged. Explicit SMB3 art dispatch retains its previous style.

`editor-art.drawConveyorWorld(ctx, room)` is a foreground pass to call after terrain and before NPCs. It consumes `room.conveyorView.surfaces`; an explicitly empty live view remains empty. Without a live view, editor previews use authored surface definitions at the initial switch state. It does not draw from `drawScenery` or a collider proxy, preventing a duplicate or covered cap.

Actual same-ID room Notes in supported SMB1 palettes use the verified native 16×16 Note Block through `drawTile`, independent of a desert scene flag. The terrain pass's current bump offset is applied once. There is no added external shadow and no background selection from Note membership. Existing desert and Mario-module Note styles remain unchanged.

## Native foliage families

The source-study overworld renderer also dispatches `source-scenery-bush` to the existing native Bush1/Bush2/Bush3 family (32/48/64×16), and `source-scenery-capsule-plant` to existing PlantLarge (16×46). These reuse the retained exact native silhouette pixels with the explicitly adapted source-study palette; canonical SMM2 scenery sprite/palette files are not claimed. The original R1 triple-crown bush and R5 tall capsule crown were personally inspected, alongside the distinct round crowns in original R4/R5.

Complete native artwork uses uniform integer scaling and a bottom-center anchor. The measured65×16 bush resolves to64×16 rather than stretching one extra column. The measured16/17×45 capsule resolves to16×46 and can extend one pixel above its approximate measured box. A one-pixel tolerance permits approximate measurements to select the intended native scale. None of these decorative bounds becomes collision geometry. The scenery-drawn second tile pass suppresses both styles, preserving foreground art. `tests/story71-native-foliage-art.test.mjs` checks exact source silhouettes, integer2× scaling, ownership, anchors, single rendering, native ground and Note preservation. The generated `foliage-art-proof.png` illustrates the palette adaptation and round/capsule distinction.

## Independent static NPC Spring

`editor-smm2-art.drawSmm2StaticNpcSpring` dispatches only an actual same-ID vertical `springs[].npcContact` binding, a static16×16 authored Spring rest body, and no carrier binding. It uses the already retained original SMM1 SMB1 standing Springboard pixels from `smm2-spring-private/`; the original R3 X-coil source crop was personally inspected. It does not acquire weighted/carrier ownership or change the NPC controller.

The actual projected NPC compression body supplies its position and height, including the observed-fit h8.8/yrest+7.2 projection. The existing pure row-pose helper preserves complete original upper/lower cap rows and adapts only the coil rows to that real rounded body. These compressed poses remain authored visual adaptations; a native compressed animation table/cadence has not been recovered. `tests/story71-static-npc-spring-art.test.mjs` verifies original standing RGBA, actual NPC-controller projection, compression rows/bottom bounds, strict independent ownership and render-state/body immutability. Embedded offline shared dispatch also executes the static source Spring with network disabled. `static-spring-art-proof.png` shows source standing and authored body compression.

## Rights and limits

Nintendo retains all original character and game-art rights. The code's MIT licence does not grant image rights. These responses and derivatives are retained for the user's authorized private learning comparison only. No general redistribution or commercial rights are asserted. Full native SMM2 walking/recovery/shell-spin animation tables and exact original animation cadence remain unverified.
