# Music credits

Magic of the Forest, Deep Mining, and Traitor by [Dark Reaven Music](https://soundcloud.com/dark-reaven-music), sourced from [VoxeLibre](https://github.com/VoxeLibre/VoxeLibre/blob/4492ce6ff8d856daa4567abe2ea689f4e7a39842/CREDITS.md#music), licensed under [Creative Commons Attribution-ShareAlike 3.0 Unported](https://creativecommons.org/licenses/by-sa/3.0/).

The supplied OGG recordings are unchanged from upstream commit 4492ce6ff8d856daa4567abe2ea689f4e7a39842. These are alternative soundtracks, not Minecraft original soundtrack recordings.

Retain this credit, the track titles, source links, and license link when distributing. If creating edited/remixed audio, identify your modifications and distribute the adapted audio under CC BY-SA 3.0 (or a compatible license permitted by its terms). The ShareAlike requirement should not be summarized as automatically licensing all independent game code; the boundary between a collection and adaptation depends on how material is used. Avoid definitive legal claims.

## R12 demonstration mix

The demonstration synchronizes these recordings to gameplay, changes playback volume, applies scene crossfades and sound-effect ducking, and mixes game effects and the synthesized note-block passage. The original OGG files are unchanged. The music-containing adapted mix and synchronized demonstration are offered under CC BY-SA 3.0 to the extent of the rights held in this adaptation. This does not assert ownership or relicense third-party Nintendo/Minecraft artwork or compositions. Code retains its separate stated license.

Short note-block musical quotation: Super Mario Bros. Ground Theme, composed by Koji Kondo (Nintendo), locally synthesized in a complete sixteen-bar miniature with distinct continuation, development and resolution; no original recording used. No open-license claim is made for that composition.

R12 jump and clear effects are locally synthesized pulse/additive musical effects. They are not Nintendo or Minecraft original sound recordings. The short clear arpeggio is a Mario-style arrangement; no claim of exclusive authorship or open licensing is made for any recognizable third-party musical quotation. The clean-ending video intentionally has no on-screen credit card; retain this accompanying attribution when distributing.

## Original recording integrity

- DarkReaven-deep_mining.ogg: SHA-256 `82e0b1386954e70d6785363e00cb332e65994d98a863639d0e05647a86faeef1`
- DarkReaven-magic_of_the_forest.ogg: SHA-256 `7bf9b1776473a64121992f9c76be6ed8b755d54efcfe7c31e02f0529fd1450ec`
- DarkReaven-traitor.ogg: SHA-256 `c8c8d056bbba4f20af00c07046ac0fa4f2c26e31d084e866e57220613312b55e`

## R12 redstone passage
The 16-bar, 13.783-second local note-block arrangement states the familiar opening once, follows it with distinct continuation, development, dominant preparation and a sustained tonic resolution. Opening and continuation reference Koji Kondo / Nintendo; the development and cadence are newly arranged. No Nintendo recording is included. The underlying composition is not represented as open-licensed. The three licensed Dark Reaven recordings and their credits above are unchanged.
