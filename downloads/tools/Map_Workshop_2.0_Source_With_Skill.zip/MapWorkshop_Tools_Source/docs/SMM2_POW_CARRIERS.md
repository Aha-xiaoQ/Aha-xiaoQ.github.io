# 马里奥地图工坊 2.0 · 实际 POW 顶面承载

此组件按需启用。qmap 1、qcollection 1、pack schemaVersion 1 不变；较旧的严格 SMM2 读取器会拒绝新增 `carrierItems` 叶。需要同版本的模型、作者工具和运行器。移回旧版本前，在输入副本删除此叶即可保留独立 POW 的旧行为。

## 作者数据与接口

在已有 `smm2Mechanics.version: 1` 根声明：

```json
"carrierItems": [
  {"id": "pow-left", "carrierId": "thwomp"},
  {"id": "pow-right", "carrierId": "thwomp"}
]
```

`id` 是同房间现有原生 walker 的稳定 ID，并且必须已列在 `powBlocks`。`carrierId` 指同房间已声明 Thwomp 的真实原生 body，或现有原生矩形移动平台。每个初始 POW 底部须真正贴在父载体顶部，且水平区间有正面积重叠。两块 POW 可以占同一载体的不同部分；不把槽宽当作敌人碰撞宽。

每叶至多 256 项；不接受重复子 ID、自引用、隐藏链、脚本、不存在的父、未声明 POW、带轨道的 POW 或站立在普通 NPC 上。字段仅 `id` / `carrierId`。已有 `carrierGeometry` 弹簧叶保持独立。POW 自身的 `gravity` 与 `maxFallSpeed` 决定下落，不使用弹簧默认重力。

公共作者出口 `editor-smm2-authoring.mjs` 提供 `bindSmm2PowSupport(room,powId,carrierId)` 与 `unbindSmm2PowSupport(room,powId)`；编辑器 SMM2 面板提供同一原子验证事务。失败不会部分更改房间，History 支持撤销、重做、导出和再导入。一起复制原生 POW 与其 Thwomp 会重映射两个稳定 ID；单独复制 POW 或调用组件克隆获得独立 POW，不复制顶面支撑。删除现存子或父时清理其引用；新引入的非法引用仍由导入器报错。

## 实际运行

绑定 POW 在 native 父控制器的当帧运动完成后更新。Thwomp 的位移必须和其真实 `lastMotion.from/to/tick` 相符；原生移动平台位移必须与 `dx/dy` 一致。仅使用父 body 的顶面相对运动求碰撞，不添加可以让 Mario 站在裸 Thwomp 上的几何。

POW 有实际位置、速度、地面支撑和墙/顶碰撞。下冲速度超过 POW 下落时会分离；回升或下落重新交会时才获得支撑；被墙挡住不能恢复初始固定偏移。父消失后 POW 按自身重力继续下落并可落到真实地面。爪持时服从爪的当前姿态，释放后保留真实速度。零重力 POW 可接触静止顶面，但父下冲会失去支撑。

玩家的真实头顶碰撞，以及另一个 Thwomp 的真实向下 charge，继续使用原 POW 激活/效果接口。耗尽 POW 立即移除实体和灯光，承载器不会重建它；重试重新创建真实来源及接触历史。夜间光源读取真实 actor 的稳定 ID 和当前 body，随运动改变，死去或耗尽后停止发光。

直接组合控制器时，先 `items.beginFrame`，再更新父控制器；将全部真实敌人和道具传给 `carriers.apply`，然后对绑定 POW 调用 `items.stepItem(actor,{tick,geometry,support:carriers,actors})`。最后重建 `items.geometry`。标准 native Stage 已接入此顺序。不能先对同一 POW 做普通 item 更新，再同帧做支撑更新。

这些碰撞和重力是作者设定的近似；没有原作逐帧的力学或手感校准。通用源码、fixture 和验证不含具体地图、通关路线、原始参考或美术变更。
