# 马里奥地图工坊 2.0 · Optional arcade cabinet artwork

The optional `coinCranes[].cabinet = {x,y,w,h}` authors the display bounds of a
grounded arcade machine. Its strict controller validation owns map bounds and
prize placement. Missing cabinet data uses the previous free crane drawing.
The cabinet artwork never installs geometry, changes payment, moves a prize,
grants a coin or advances a controller.

The visible composition was authored after viewing the actual pixels of this
public [Neon Abyss original-game still](https://nekoyakata.net/wp-content/uploads/2020/07/b7784145a598879a3598efcca45c8d45.jpg),
published with the [July 2020 guide](https://nekoyakata.net/neon-abyss-shop/).
The 600×338 image identifies game version v1.2.2.26. It shows a large prize
chamber with thin cyan boundaries, dark purple diamond facets, a pale metal
three-finger claw/rope, a dense bottom prize field, two suspended black red-ring
fuse bombs, and a separate yellow payment console at the player's left.
This source is static evidence. It does not establish motion, physics, exact
colors, frame timing, original payment interaction or a spotlight. The
workshop's smaller grounded cabinet, external collection tray, 1-coin price,
wallet readout, paid/need-money lights, independent bulb button, joystick and
sweeping lamp are author adaptations.
No original Neon Abyss asset is cropped or embedded as runtime art.

`drawCoinCraneBackdrop(ctx, room)` paints the chamber's dark diamond field before
live objects. `drawCoinCraneWorld(ctx, room)` paints the frame, top rail, actual
rope/claw pose, independent yellow console and collection tray. The optional
console reads `payment.slot`, `price`, `wallet`, `paid`, `needMoney` and
`paymentFlash` from the
controller's render projection. Price and wallet are tiny coin-and-digit
symbols, not debug text. A positive `paymentFlash` projects the accepted debit's
short coin insertion and LED blink; drawing never accepts payment itself. The
cabinet's real 16px control body shows a red-tipped joystick. Its shaft tilts
and depresses during the real lowering/closing phase, then returns with the
machine state. Free cranes retain their existing upward-arrow button.
The claw reads only projected anchor/grip/closed/held
state. Thin glass artwork remains within each real authored solid body.

Optional `searchlight.buttonId` gives the machine a separate gold bulb head
button. Its bulb and the linked `enabledWhenMachine` lamp read only the owning
crane's `lampOn`, falling back to `searchlight.initialOn` in an editor preview.
Global ON/OFF does not change that lamp's projected appearance. The gold lamp
lead and blue crane lead connect the distinct controls to their mechanisms and
avoid the console's price display. A compact overlapping collection tray stays
behind the foreground console so its bar cannot obscure the price or insertion
slit. The current night room authors an initially
off lamp, low side-by-side buttons, and no long timber divider; their collision
bodies remain ordinary authored geometry.

`drawCoinCraneObject(ctx, body, room, tick)` dispatches only explicitly typed
extra payloads. Ordinary Coin, Goomba and Spiny use existing original SMB1 source
pixels and their normal source dimensions/palette; actual live body positions
provide the bottom/center anchor. The round black/red-ring/fuse bomb is an
explicitly authored 16px SMB1-style adaptation of the observed shape. Its
transparent corners remain open. A projected bomb failure flashes its red ring,
adds four short sparks, and jolts the claw's displayed grip by one pixel; these
effects do not change the actual grip or any prize body. Typed Pink always stays with the existing Pink renderer.
Legacy `goomba` and `spiny` prizes are real device-owned inert body objects;
their appearance does not make them autonomous NPCs. New `large-coin`,
`live-goomba` and `live-koopa` payloads pass through this dispatch to the existing
native ten-coin/Goomba/Walking-Koopa renderer. The large coin keeps its actual
32×32 body and `10` glyph; live NPCs retain their native pose and walking
animation after delivery. The art layer never activates their physics.

The editor/runtime/native Canvas/offline HTML use these same shared draw
functions. Backdrop ordering matters: it must precede live prize pixels so the
original typed Pink stays visible. The normal world pass follows terrain and
precedes foreground NPCs. Rendering, source lookup and preview do not mutate
the room or projected state. Source code permission and Nintendo/Neon Abyss
third-party art permission remain separate; this feature does not expand the
license of reference images or existing source sprites.