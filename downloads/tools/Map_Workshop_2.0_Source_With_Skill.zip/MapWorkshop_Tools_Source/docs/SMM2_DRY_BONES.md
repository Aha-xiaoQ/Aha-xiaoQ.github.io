# 马里奥地图工坊 2.0 · Typed Dry Bones lifecycle

This private workshop adds an opt-in `kind:'dry-bones'` Mario enemy variant. Its runtime descriptor is `type:'dry-bones'`. The descriptor must name a real native `kind:'walker'` in this room. Decorating it preserves the original body's width, height, center and feet. `size:'giant'` changes stomp eligibility; it does not resize an ordinary body. Author a genuinely larger walker if the observed source warrants one.

Nintendo's [element guide](https://www.guiasnintendo.com/2c-switch/super-mario-maker-2/guia-super-mario-maker-2/paleta-elementos.html) supports normal Dry Bones temporarily collapsing after a stomp, later recovering, and ignoring fireballs. Giant Dry Bones resists ordinary stomps and can collapse after a shell-rider stomp or ground pound. Collapse is not implemented as a permanent defeat. That source does not calibrate exact body dimensions, phase durations, walking speed, bounce impulse, player response to a resisted giant stomp, point rewards or every collision face.

## Authored schema

```js
room.marioModules.enemyVariants['existing-native-walker-id'] = {
  kind: 'dry-bones',
  size: 'giant',
  speed: 0.5,
  direction: -1,
  collapsedHeight: 8,
  collapseFrames: 180,
  recoverFrames: 24,
  bounceSpeed: 4,
  giantStompResponse: 'bounce'
};
```

These numbers illustrate an author's tuning and are not measurements of SMM2. Every numeric field is required and bounded. `collapsedHeight` must be positive and smaller than the actual native walker height. Giant variants must explicitly author `giantStompResponse:'bounce'|'hurt'|'harmless'`; normal variants omit that field. The chosen player response is flagged `unverified:'giant-ordinary-stomp-player-response'` in contact results. No unresolved runtime choice silently falls into native combat. Descriptors, actor state, module views and collapse diagnostics label numeric tuning `authored-uncalibrated`.

## Identity, phases and actual collision

`applyEnemyVariant(actor)` decorates the existing live actor with `type:'dry-bones'`, `smm2EnemyKind:'dry-bones'` and `smm2DryBones`. Its phases are `walking`, `collapsed`, and `recovering`. Collapse reduces only the authored body's height with its feet fixed, stops lateral walking and stores the real walking velocity for recovery. It never sets `dead`, sets `shell`, creates another enemy, awards points or calls host defeat logic.

`stepEnemy(actor,{tick,canStand})` updates the phase clock once per distinct integer tick and returns false. The host must continue its usual gravity and physical collision on this actual body, including while collapsed. There is no floating tombstone or invisible support platform. Dry Bones opts into the host's actual solid/one-way and ceiling collision guard.

For a collapse at tick T, the collapse clock first decrements at T+1. After `collapseFrames` distinct steps, `recovering` begins with the full `recoverFrames` clock. The first recovery headroom attempt occurs at T + collapseFrames + recoverFrames. Attempts after that occur at most once per distinct tick, without a retry loop. Recovery keeps the shorter body and zero remaining clock until `canStand(candidate)` returns exactly true. Omitting the callback leaves recovery blocked. The callback receives one frozen candidate rectangle at the actor's current feet, never the live actor or the author's input data.

The stage supplies actual world bounds and current solid collision:

```js
marioModules.stepEnemy(enemy, {
  tick,
  geometry: enemyGeometry,
  player,
  canStand: body => body.x >= 0 && body.y >= 0
    && body.x + body.w <= roomWidth
    && body.y + body.h <= roomHeight
    && !enemyGeometry.some(g => !g.hidden
      && g.collision === 'solid' && motor.overlap(body, g))
});
```

`stackSupportEligible(actor)` returns false during collapsed and recovering phases. The host must use it when selecting a real stack parent and building that parent's one-way top rectangle. Clear a follower's old support through its existing generic stack/gravity path when the parent becomes ineligible. The stored `enemyStacks` relationship remains authored data; it does not create a replacement surface. This preserves the actual tower and lets followers detach and later land through real body physics.

## Handled contact contract

`enemyContact(actor)` returns `fireImmune:true` for every Dry Bones phase, so the stage's existing fireball guards consume fireballs without damaging or killing this enemy. It also returns explicit `handled:true`, `requiresContactHandler:true`, `harmless`, `phase`, and `supportEligible`. `stompable:false` and `shoeStompable:false` prevent the generic host and Shoe adapter from converting an already typed contact into a permanent kill.

The host establishes the actual contact geometry and calls:

```js
const contactTop = enemy.y;
const result = marioModules.dryBonesContact(enemy, {
  tick,
  attack: 'bone-shell-stomp' // body, stomp, bone-shell-stomp, ground-pound
});
if (result?.handled) {
  if (result.harmful) hurt();
  if (result.bounce) {
    player.y = Math.min(player.y, contactTop - player.h);
    player.vy = -result.bounceSpeed;
    player.grounded = false;
    player.support = null;
  }
  // Consume the handled contact and skip the generic defeat/reward branch.
}
```

Run this typed top-contact resolver before Shoe/native contact can defeat the actor. A real bone-shell controller may protect mounted body contact separately; the Dry Bones helper does not invent mounted collision protection. `body` requests ordinary host hurt while walking, while any contact during collapsed/recovering is an explicit harmless handled result.

For normal stomp, shell-rider stomp of either size, or ground-pound of either size, the result is `action:'collapse'`, `collapse:true`, `bounce:true`, and `points:null`. `points:null` means this adapter provides no measured reward rule; do not pass the action into the native stomp-chain reward or `killEnemy`. A repeated attack query in the same tick returns `repeated:true`, `changed:false`, and `bounce:false`; it does not reset timers or emit another collapse event. Contacts on an already collapsed/recovering actor are harmless and do not refresh its clock.

For ordinary stomp of a giant, the result is `action:'resisted-stomp'`, `collapse:false`, with the explicit authored bounce/hurt/harmless response and its uncertainty flag. The enemy remains walking and alive. `stompEnemy(enemy,context)` also returns this typed result for Dry Bones; its existing boolean wing-removal result is unchanged for legacy Koopas. Hosts must consume the typed result separately rather than treating any truthy value as permission to apply a native stomp reward.

`view().dryBones` is present only in rooms with authored Dry Bones variants and copies live states. `reset()` restores decorated actors to their original authored pose, full body, walking velocity and fresh phase/contact clocks. It keeps their identity and leaves host life/death ownership intact. Other enemy variants, pipe factories, legacy stack mappings and opt-out module views retain their prior behavior.

## Validation