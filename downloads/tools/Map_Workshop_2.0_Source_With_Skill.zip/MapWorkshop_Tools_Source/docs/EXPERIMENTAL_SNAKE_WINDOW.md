# 马里奥地图工坊 2.0 · 蛇块有限占格实验

本项参考是 SMM2 的 NSMBU 雪地原游戏短片。公开 GIPHY 上传者与原视频出处为空；同场景与2019年2月公开预览截图相符。它不是完整关卡，未认证最终发售版本或参数。实际原 MOV 呈现41帧、时间0至1.334668秒；GIF有21帧、1.39秒。保留各自原时间轴，不把GIF帧率当原机帧率。

## 已实际看到的机制

前沿先右行、再上转、再左行。尾沿随后沿相同路径收缩。固定金币校正镜头后，中间完整格保持同一世界位置；不是整台平移，也不是每节以头速沿轨道搬人。头尾可显示完整滑动方块覆盖邻格，形成局部可见的半格。

该观察改变了实现方案：使用有长度的路径占据窗口，内部完整格按固定世界节点生成；仅前后沿改变位置。未给中格统一添加运动位移。

## 支持范围

`atlas/editor-snake-window-preview.mjs`只实现独立的有限预览控制器、严格数据验证与中格接触探针。它不接入qmap、Stage、合集能力或普通地图导出。`atlas/editor-snake-window-tools.mjs`提供独立编辑与存取，主编辑器有“蛇块实验预览”入口。

- 格距为工坊约定16px；路径是相对任意原点的正交格中心，当前只接受无交叉／重访路径
- 原点、相对路径点与相加后的世界中心限定在±1,000,000px；这是保持16px数值／绘制辨识度的工具安全保护，不是原游戏世界最大坐标或已校准参数
- 长度N表示作者给定的两端中心路径距离(N−1)×16，不把彩色可见patch数当原物件数
- 速度、初相和观察时长都是明确作者值；示例的9格、134.9px初相、60px/s只是本短片几何拟合
- 完整固定格有稳定世界节点ID；仅其完整暴露顶面参与局部接触验证，位移为0
- 头尾只有可视轮廓；不推断头尾碰撞／搬运、NPC／道具载荷、踩踏启动或末端掉落
- `preview-complete`只表示观察区间或作者截断已结束，不表示原蛇块停住、循环、掉落或关卡完成

接触探针调用既有motor，人物通过原生重力落到固定中格，以普通输入跳离。尾部失撑时先核当前真实顶面并清失效grounded/support，防止旧grounded在同帧产生幽灵跳。旧motor和既有关卡没有为此修改。这个探针证明局部工程接触行为，不认证原NSMBU完整运动或手感。

## 独立数据契约

格式为`snake-window-preview/version:1`。字段为`id`、`tileSize:16`、`origin:{x,y}`、`path:[{id,x,y}]`、`lengthCells`、`initialHeadDistancePx`、`speedPxPerSecond`、`observationDurationMs`、`parameterStatus:'authored-not-calibrated'`。路径点为相对原点的16px倍数，可跨多格；不是格序号。

保存为`.snake-preview.json`，使用`validateSnakeWindowPreview`、`serializeSnakeWindowPreview`与`parseSnakeWindowPreview`往返。它不能冒充qmap导入；旧qmap／qcollection／native pack的ABI未变。

控制器API：`createSnakeWindowPreview(document)`，返回`snapshot()`、`tick(deltaMs)`、`setPaused(boolean)`、`reset()`、`getDocument()`。快照分`renderCells`与`fixedContactCells`；矩形x/y为左上，centerX/Y为世界中心。

## 对照与后续门槛

同屏页左栏保存原短片和其自身时间轴，右栏是明确图例的占格几何模型，不画假NSMBU角色或贴图。观察帧的前沿中心拟合与中格不平移分别验证；模型拟合结果不等于最终版速度验证。

正式支持仍需要可观测的启动、末端、头尾实体接触和碰撞面资料，再接普通编辑／qmap／Stage／资源／布局／完整实例闭环。这些缺项继续单列，不把实验预览写成已完整支持机制。

原素材／画面版权属于Nintendo；公开参考只供私人学习和对照。工具代码许可与原画面许可分开。工具源码默认不嵌原片、原场景或私人地图；同屏研究文件显式传入已取得的参考媒体后独立生成。
