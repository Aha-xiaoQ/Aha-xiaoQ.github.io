# 马里奥地图工坊 2.0 · BGM有限中断恢复与通用音频验证

本版共享editor-audio.mjs区分HTMLAudioElement.play()的AbortError与真正的自动播放权限拒绝。当前背景播放请求因AbortError中断时，后续普通background更新最多自动重试两次；使用同一背景元素，保留实际游标。连续第三次中断后等待新的显式手势。NotAllowedError保持权限等待，普通更新不能假装用户手势。

暂停、静音、stop/stopMusic、换曲与旧promise有独立保护。背景乐和Boss攻击/受击/死亡的一次性音效各自播放；音效不应重置同曲游标。此修复只覆盖play()中断返回AbortError这一明确分支，不承诺恢复浏览器所有意外pause、操作系统音频或硬件状态。

renderer-audio/mix-native-scene-audio.mjs报告musicTimeline[].musicEnergy与musicSourceQuietSampleSpans，单独测量加入混音前的BGM贡献。总体混合RMS可能由音效填充，不能单独证明BGM仍然存在。信号窗口能量不等于个人听感，也不能排除更短缺口、实体设备差异或浏览器环境差异。

初次中性build/dev/HTML导出不需ffmpeg，所需精确循环WAV已随通用素材包含。完整音频通用测试需ffmpeg以解码真实WAV：

```sh
node --test --test-reporter=tap tests/music-interruption-recovery.test.mjs tests/native-scene-audio-continuity.test.mjs
npm run verify
```

可选真实原生音频fixture另需Chromium；它启动本机中性服务，并使用明确允许自动播放的受控浏览器策略：

```sh
node renderer-audio/check-browser-music-continuity.mjs dist/neutral-browser-audio.json
```