# 素材来源与许可边界

代码许可见 [LICENSE-CODE.md](LICENSE-CODE.md)。代码MIT不转移 Nintendo／Contra 游戏图像与声音、品牌图像或字体的权利；本页不是新的素材授权。保留的游戏素材沿用已有私人学习交接范围，不构成公开分发、商业使用或完整原作素材集许可。

| 类别 | 本包实际内容与来源记录 | 边界 |
| --- | --- | --- |
| SMB原生像素与基础绘制 | `atlas/source-sprite-data.mjs`、`source-art.mjs`；`atlas/CLASSIC_ART_NOTICE.txt` | 原署名／权利保留，历史未恢复文件路径不表示本包有该证据 |
| Mario／Contra音效与Bill数据 | `atlas/assets/classic-audio/`、`character-audio/`及模块内嵌数据 | Nintendo／Contra权利与代码分别保存；没有补造缺失Bill Jungle BGM |
| 检查点声音 | 原 `.oga` 与完整原PCM的WAV；`CHECKPOINT_AUDIO_PROVENANCE.json`／`CHECKPOINT_AUDIO_NOTICE.txt` | 公开SMB1／SMB3身份已核，未加工原PCM；其它style、ROM现场或原机耳听未核 |
| Bone Shell／Dry Bones／骨平台／雕像／Fire Bar／Lava Bubble／地下地块／堡 | `atlas/assets/smm2-private/SOURCE_ASSETS.json`及实际响应文件 | 逐文件来源／SHA随资源保留；文件夹旧private命名表示原素材的学习权利范围，不是混入私人地图 |
| Dry Bones四相行走 | `dry-bones-authored-walk-4x16x23.png`及对应 `.provenance.json` | 原站姿衍生作者步态，原walking rip未取得，帧时序／步幅未校准，仍为Nintendo衍生素材 |
| Springboard原standing像素 | `atlas/assets/smm2-spring-private/smm1-smb1-springboard-standing.original.png`与该目录 `SOURCE_ASSETS.json`／`NOTICE.txt` | 已取得SMM1（2015）SMB1原16×16standing PNG，原245字节response与RGBA保留；压缩态是保留caps／重采样coil的作者适配，原compressed GIF／压缩帧／完整SMM2表未取得 |
| SMB1 ON/OFF与红蓝块六种状态 | `atlas/assets/smm2-switch-private/`完整六原PNG、来源URL／响应SHA／RGBA SHA、`NOTICE.txt` | Nintendo版权独立于MIT代码；只核六种静态原状态，ON亮字／原帧暗字相位和闪烁时序未校准；SMB3保留既有作者fallback |
| SMB1钥匙与已解锁Key Door | `atlas/assets/smm1-key-door-private/`两原PNG、URL／版本／字节SHA／RGBA SHA、`NOTICE.txt` | SMM1（2015）SMB1静态原像素，与有限SMM2 Story28帧定性相符；不称SMM2 rip或原动画。世界钥匙底／中锚独立于碰撞体，HUD与作者缩放是等比nearest适配；plain／locked与其它style仍旧近似 |
| Donut Block | 原16×16PNG及既有source-art／notice；旧provenance/ORIGINAL_DONUT_SOURCE.json为历史路径 | 公开SMM SMB来源原像素；fair-use页面不是开放许可，不宣称完整SMM2动画或SMM1/SMM2字节同一 |
| 检查点旗 | `atlas/assets/smm2-checkpoint-private/PROVENANCE.json`及原PNG | Nintendo图像，原19×32比例／底锚，RGBA副本不改变权利 |
| 幽灵屋／P／POW／Thwomp／Spiny来源 | `atlas/assets/smm2-ghost-private/SOURCE_ASSETS.json`与实际文件 | 运行适配与原响应分别保留；部分动画／压扁／配色是明确近似 |
| 鞋与Clown Car恢复像素 | `recovered-source-pixels/RECOVERED_PIXELS.json`、`atlas/RECOVERED_ASSET_NOTICE.txt` | HTML恢复静态像素重编码副本，原PNG／WebP响应未取得，原响应SHA不冒充副本SHA |
| 工坊机关与SMB3近似绘制 | `docs/CONTRAPTION_ART_NOTICE.md`、`docs/SMM2_ART_NOTICE.md`与绘制源码 | 作者raster／轮廓适配不称Nintendo原PNG；跷板红板与咚咚脸部状态为近似绘制 |
| Castle／Ghost／水下循环资源 | `AUDIO_LOOP_PROVENANCE.json`、`GHOST_NIGHT_LOOP_PROVENANCE.json`、`UNDERWATER_PLAYBACK_ADAPTATION.json` | 原响应与播放段落适配分开，未恢复完整原机周期或校准声画时序 |
| 寒蝉像素字体 | `atlas/chill-font.mjs`与 `atlas/CHILL_FONT_LICENSE.txt` | 内嵌字体及许可完整保存 |
| Renderer两份OTF子集字体 | `renderer-assets/story28-study-regular.otf`、`story28-study-bold.otf`；`FONT_PROVENANCE.json`／`FONT_LICENSE.txt` | Noto CJK子集，SIL OFL1.1，按原来源记录重命名，非系统字体依赖 |
| 工坊品牌SVG | `atlas/assets/q-logo-*.svg`、`xiaoq-avatar-p63a.svg` | 沿用已有图像，不扩大授权 |

原 `CLASSIC_ART_NOTICE.txt` 中的 `../reference/`、`RIGHTS.md` 或旧完整工程脚本是历史路径，部分没有恢复，不应把它们解释为当前包内来源文件。当前实际负载用本工具 `PACKAGE_MANIFEST.json` 校验；未取得的原二进制仍明确缺失。

本版Spring／跷板能力使用已取得的上述原standing像素与作者压缩适配，跷板继续使用作者raster；取得原响应不扩大许可，也不把SMM1standing冒称SMM2完整动画。普通16×16使用真RGBA；32×32是明确作者等比2倍原像素。新typed支撑拒绝非方与其它尺寸，不将它们画成相同source图或列为支持。图像底锚跟随真实Spring压缩，绘制不改变碰撞体、mass或物理。质量、重力、倾角、冲量和时序均为作者有限参数，不由截图、sprite大小或素材名称推定。局部截图只有定性作用，未完成参考Story32全片研究，不称Story32完整原关复刻。

工具的中性fixture、作者工具代码与校验数据属于工具验收范围。本独立工具投影不包含私人课程布局、完整过关输入或当前原参考影片。通用测试中实际Canvas像素／模拟DOM与新工具冷验的结果，不能替代原机实测、耳听或法律授权判断。

## Story42 SMW Underwater

The historical older attachment recorded original Nintendo sprite supplements and source research in assets/story42-original/ASSET_MANIFEST.json. That historical research directory is excluded from this independent projection; the exact old path/SHA is retained in provenance/INCOMING_1.10.23_UPGRADE_TARGET_COMPARISON.json. Actual retained runtime assets and their bytes are listed in PACKAGE_MANIFEST.json and the accompanying atlas asset notices. SMM1 and original SMW supplements are labelled separately from SMM2 sprites. Finite swim, wings, rolling cadence, sign and cannon reconstructions remain author adaptations. The code license does not grant a license to Nintendo artwork or music. This project is a private learning reproduction. Correct SMW BGM is unavailable and is not replaced by SMB1 music.


## 1.10.23 原SMW人物动作补图

assets/smw-player-motion-original保存Mario Universe原SNES Super Mario World（Mister Man rip署名）的21个确切姿态格/透明alpha/原尺寸与可复现裁出manifest；原始大图表和历史contact研究图未包含，原来源URL与SHA在裁出manifest中保留，原第三方notice按原字节保留；与SMM-SMW公开站姿轮廓一致。新增图库GIF/deathPNG仅作原素材来源补充，其播放delay不当原动画周期。Nintendo图形版权独立于工程MIT，来源托管页不授新资产许可。划水/地面/转向/受伤实测来自既有合法原42录像，death属于原SMW补图而非原42实测；Fire/Cape/Yoshi/完整成长中间帧未承诺恢复。

## Normal SMB1 Bowser Jr reconstruction

Five gameplay-frame-derived poses and a circular fireball visual adaptation are shared by the editor/runtime/offline renderer. They are not a raw game sprite rip or recovered native animation table. Original Nintendo imagery and the Nintendo Unity recording retain their respective rights; no expanded license is asserted. See atlas/BOWSER_JR_ART_NOTICE.txt and atlas/assets/bowser-jr-gameplay-reconstruction/PROVENANCE.json.

## 1.10.31 新素材与字形

- 骑云手持武器、栗宝宝飞行包、上行弹道与瞄准标识由本作代码绘制；原Goomba／Mario／Cloud像素权利沿既有Nintendo声明保存。组合玩法为原创配置，不称“小蜜蜂”原关或Namco图像提取
- 绿蓝Snake砖使用已保留SMW原像素家族，在SMB1背景中是明确风格适配；正式动态依据沿已研究SMM2 Story42，不引用2019短预览推定完整规则
- 砖块“小Q”墨格由现有寒蝉7px“小”与16px“Q”真实嵌入WOFF2生成；作者仓库Warren2060/ChillBitmap，本包保留的字体许可见atlas/CHILL_FONT_LICENSE.txt；课程内的另行字体研究证据不在本投影中。字形数据不归MIT代码许可，不声称与官方字体发布二进制逐字节一致

## 1.10.32 等高字形与原创新装饰

小采用原寒蝉7px墨格不变；Q取原寒蝉16px字形的源行[0,1,2,5,8,9,10]做明确作者等高归一化，仅省重复直侧行，保留原帽／肩／斜笔／尾格。两字7×7砖格、112px高、同顶同底；归一化后的Q不称未改原字形，字体来源及许可声明继续保留。竞技场冠饰旗与三枚大厅彩蛋为原创像素装饰，不称Nintendo旗原素材或可碰实体。门上通关勾记是读取真实Pink集合的原创显示反馈，不授予任何奖励或碰撞能力。

## 1.10.33 门符号与返阵编队

门上柜体、分节蛇、飞行包和底牌为原创像素图；壳沿用已核SMB1原红壳，小库巴沿用实机画面重建，栗宝宝原图与作者外挂飞行包组合。原像素不随MIT代码授权。Galaga官方截图与Steam演示仅作阵型／可见俯冲返阵结构的研究依据，不进入运行纹理；组件允许的基础／返阵体上限、连续左侧返航、AI与速度为作者规则与配置，非Namco原图／原参数／原脚本提取。
