import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import {History,parseProject} from '../atlas/editor-model.mjs';
import {makeDoorFeatureIcon} from '../atlas/editor-door-feature-art.mjs';
import {createCollection,addLevel,approveLevel,serializeCollection,parseCollection} from '../atlas/editor-collection.mjs';
import {createNeutralProject} from '../scripts/neutral-fixtures.mjs';
// Author a new tiny tool-only example through actual History and collection APIs.
const h=new History(createNeutralProject({second:true}));
h.change(doc=>{
 doc.id='skill-ordinary-project';doc.title='Skill ordinary portal task';
 const room=doc.rooms[0];room.title=doc.title;
 room.decorations.push(makeDoorFeatureIcon(room,{id:'skill-door-sign',portalId:'portal',feature:'snake'}));
});
const changed=JSON.stringify(h.doc);h.undo();assert.equal(h.doc.rooms[0].decorations.length,0);h.redo();assert.equal(JSON.stringify(h.doc),changed);
const qmap=JSON.stringify(h.doc,null,2)+'\n';assert.deepEqual(parseProject(qmap),h.doc);
let collection=createCollection({id:'skill-ordinary-task',title:'Skill ordinary two-level task'});
collection=addLevel(collection,h.doc,{id:'skill-first',entryRoom:'main'});
collection=approveLevel(collection,'skill-first','Explicit author approval of synthetic neutral CLI fixture only');
collection=addLevel(collection,createNeutralProject(),{id:'skill-second',entryRoom:'main'});
collection=approveLevel(collection,'skill-second','Explicit author approval of synthetic neutral CLI fixture only');
const qcollection=serializeCollection(collection)+'\n';assert.deepEqual(parseCollection(qcollection),collection);
await fs.writeFile(new URL('skill-ordinary-task.qmap.json',import.meta.url),qmap);
await fs.writeFile(new URL('skill-ordinary-task.qcollection.json',import.meta.url),qcollection);
console.log(JSON.stringify({historyUndoRedo:true,qmapRoundtrip:true,qcollectionRoundtrip:true,actualDoorFeatureHelper:true,syntheticNeutral:true,levels:collection.levels.length}));
