// Run with node --experimental-vm-modules. Executes the HTML's embedded modules
// against the packaged simulated DOM. This is not browser layout/hardware testing.
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createContext,SourceTextModule} from 'node:vm';
import {installSimulatedPlayDom} from '../tests/fixtures/simulated-play-dom.mjs';
import {inspectOfflineHtml} from '../scripts/check-offline-html.mjs';

const file=process.argv[2],isCollection=process.argv[3]==='collection';
if(!file)throw Error('Usage: node --experimental-vm-modules scripts/check-offline-runtime.mjs HTML [collection]');
const html=await readFile(file,'utf8'),checked=inspectOfflineHtml(html,{collection:isCollection});
const dom=installSimulatedPlayDom(),timers=new Map(),storageData=new Map();let timerId=0;
const settle=async()=>{for(let turn=0;turn<60;turn++)await Promise.resolve();};
const imageSources=[];
class EmbeddedImage{
 set src(value){assert.ok(String(value).startsWith('data:image/'),'offline Image source must be embedded');imageSources.push(value);this._src=value;}
 get src(){return this._src;}
 async decode(){return this;}
}
class EmbeddedAudio{
 paused=true;
 constructor(source){if(source)this.src=source;}
 set src(value){assert.ok(String(value).startsWith('data:audio/'),'offline audio source must be embedded');this._src=value;}
 get src(){return this._src;}
 async play(){this.paused=false;}
 pause(){this.paused=true;}
}
let fetches=0;
try{
 const body=html.match(/<body>([\s\S]*?)<script type="importmap">/);assert.ok(body);
 dom.document.body.innerHTML=body[1];
 const sandbox={
  document:dom.document,window:dom.window,navigator:globalThis.navigator,performance:globalThis.performance,
  requestAnimationFrame:globalThis.requestAnimationFrame,cancelAnimationFrame:globalThis.cancelAnimationFrame,
  FontFace:globalThis.FontFace,Option:globalThis.Option,Image:EmbeddedImage,Audio:EmbeddedAudio,
  URL,Blob,TextEncoder,TextDecoder,Uint8Array,Uint8ClampedArray,ArrayBuffer,structuredClone,crypto:globalThis.crypto,atob,btoa,console,
  localStorage:{getItem:key=>storageData.get(key)??null,setItem:(key,value)=>storageData.set(key,value),removeItem:key=>storageData.delete(key)},
  fetch(){fetches++;throw Error('Network use is forbidden in the offline verification');},
  setTimeout(callback,delay){const id=++timerId;timers.set(id,{callback,delay});return id;},
  clearTimeout(id){timers.delete(id);},
 };
 const context=createContext(sandbox),modules=new Map();
 for(const [id,source] of checked.modules)modules.set(id,new SourceTextModule(source,{context,identifier:id,initializeImportMeta(meta){meta.url='data:text/javascript,';}}));
 const root=new SourceTextModule(checked.root,{context,identifier:'offline-bootstrap'});
 const link=specifier=>{assert.ok(modules.has(specifier),'runtime cannot read external module '+specifier);return modules.get(specifier);};
 await root.link(link);
 for(const module of modules.values())if(module.status==='unlinked')await module.link(link);
 await root.evaluate();
 if(isCollection){
  const button=dom.document.querySelectorAll('button').find(node=>node.textContent==='从第一关开始');assert.ok(button);button.click();await settle();
 }else{const button=dom.document.getElementById('start');assert.ok(button);await button.onclick();await settle();}
 let canvas=dom.document.querySelector('dialog canvas');assert.ok(canvas?.workshopRead,'embedded player launched');
 assert.equal(canvas.workshopRead().p.x,32);
 dom.key('ArrowRight');
 let ordinaryInputFrames=0;for(;ordinaryInputFrames<1200&&!canvas.workshopRead().completed;ordinaryInputFrames++)dom.frames(1);
 dom.release('ArrowRight');const cleared=canvas.workshopRead();
 assert.equal(cleared.completed,true);assert.equal(cleared.coins,2);assert.equal(cleared.lives,3);
 if(isCollection){
  const completion=[...timers].find(([,timer])=>timer.delay===1800);assert.ok(completion);
  timers.delete(completion[0]);await completion[1].callback();await settle();
  canvas=dom.document.querySelector('dialog canvas');assert.equal(canvas.workshopRead().title,'Neutral editor fixture');
  assert.equal(canvas.workshopRead().roomId,'main');assert.equal(canvas.workshopRead().p.x,32);assert.equal(canvas.workshopRead().coins,2);
  const progress=JSON.parse(storageData.get('xiaoq-map-collection-progress:skill-ordinary-task'));
  assert.deepEqual(progress.cleared,[{levelId:'skill-first',revision:1}]);assert.equal(progress.resume.levelId,'skill-second');
  dom.key('ArrowRight');let secondFrames=0;
  for(;secondFrames<1200&&!canvas.workshopRead().completed;secondFrames++)dom.frames(1);
  ordinaryInputFrames+=secondFrames;dom.release('ArrowRight');
  assert.equal(canvas.workshopRead().completed,true);assert.equal(canvas.workshopRead().coins,3);assert.equal(canvas.workshopRead().lives,3);
  const finalTimer=[...timers].find(([,timer])=>timer.delay===1800);assert.ok(finalTimer);
  timers.delete(finalTimer[0]);await finalTimer[1].callback();await settle();
  const terminalProgress=JSON.parse(storageData.get('xiaoq-map-collection-progress:skill-ordinary-task'));
  assert.deepEqual(terminalProgress.cleared,[{levelId:'skill-first',revision:1},{levelId:'skill-second',revision:1}]);

 }
 assert.equal(fetches,0);assert.ok(imageSources.length>0);
 console.log(JSON.stringify({file,kind:isCollection?'collection':'single',moduleCount:checked.moduleCount,reachableModuleCount:checked.reachableModuleCount,embeddedRuntimeLaunched:true,actualExitCleared:true,collectionAdvanced:isCollection,allCollectionLevelsCleared:isCollection,ordinaryInputFrames,runtimeStateInjection:false,networkRequests:fetches}));
}finally{dom.document.querySelector('dialog')?.close();dom.restore();}
