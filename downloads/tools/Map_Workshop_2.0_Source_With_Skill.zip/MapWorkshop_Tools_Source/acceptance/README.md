# Skill 创作与离线诊断

以下脚本使用随附中性地图演示作者API、History撤销/重做、合集及离线导出。它们不会修改其它用户地图。

```sh
node acceptance/skill-ordinary-task.mjs
npm run map:validate -- acceptance/skill-ordinary-task.qmap.json
npm run map:validate -- acceptance/skill-ordinary-task.qcollection.json
npm run map:export -- acceptance/skill-ordinary-task.qmap.json --output dist/skill-task-single.html
npm run map:export -- acceptance/skill-ordinary-task.qcollection.json --output dist/skill-task-collection.html
node --experimental-vm-modules acceptance/skill-ordinary-task-replay.mjs dist/skill-task-single.html
node --experimental-vm-modules acceptance/skill-ordinary-task-replay.mjs dist/skill-task-collection.html collection
```

重放检查嵌入模块与普通输入驱动的通关；模拟DOM不验证实体设备或浏览器视觉布局。
