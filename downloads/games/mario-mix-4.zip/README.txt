混合马里奥Ⅳ · 索尼克 × 奥日

1. 将压缩包完整解压到一个文件夹。
2. 用电脑 Chrome 或 Edge 打开 index.html。
3. 点击游戏内的开始按钮启用声音，按页面提示选择角色并游玩。

这是混合马里奥第4期的离线试玩包，素材已内置在 index.html 中，无需安装游戏引擎。
版权、素材与上游许可说明请阅读 NOTICE.txt，以及 index.html 中保留的来源说明。

Extract the ZIP and open index.html in desktop Chrome or Edge.
Click the in-game start button to enable audio and follow the on-screen controls.
Read NOTICE.txt and the preserved source notices before reusing content.
