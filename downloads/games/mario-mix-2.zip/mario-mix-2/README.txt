混合马里奥Ⅱ · 忍者龙剑传 × 坦克大战

1. 将压缩包完整解压到一个文件夹。
2. 使用电脑 Chrome 或 Edge 打开 index.html。
3. 点击游戏内的开始按钮启用声音；按页面提示使用键盘或手柄。

程序与所需游戏素材已包含在 index.html 中。无需安装游戏引擎。
版权、素材及上游许可请阅读 RIGHTS.txt、UPSTREAM-NOTICES.txt 和游戏文件中的来源说明。
界面使用系统字体；本包不附字体文件。

网站与更新：https://aha-xiaoq.github.io/

Extract the ZIP and open index.html in desktop Chrome or Edge.
Click the in-game start button to enable audio. See the game for controls.
Read RIGHTS.txt and the preserved upstream/font notices before reusing content.
