# 运行第三期开发版

**0.4.1 · 待实机验收**，文档修订 R15。游戏玩法和界面与 M05 相同。源码用于本地开发与测试，不会自动替换线上试玩。

## 环境与启动

安装 Node.js 22 或以上。解压后进入 `MarioMix_Terraria_M05` 文件夹，无需 npm install。

```sh
npm run verify
npm run dev
```

普通候选：`http://127.0.0.1:4193/play.html`

关卡试验场：`http://127.0.0.1:4193/play.html?dev=1`。打开侧栏的“关卡开发 · 接入试验场”，勾选“显示开发草稿”。

另开一个终端运行 `npm run reference`，访问 `http://127.0.0.1:4194/` 查看原始第三期对照。

## 修改与验证

修改 `src/` 或 `content/`，重启服务并刷新。不要修改 `dist/`。运行 `npm run tasks` 查看范围明确的工作项；参与前先在项目 Issue 中确认。

[代码贡献指南](CONTRIBUTING.md) · [模块地图](docs/generated/MODULES.md) · [UI 约定](docs/UI_CONTRACT.md) · [新增关卡](docs/stages/ADD_LEVEL.md)

## 界面选项

右上“专注画面”收起侧栏；侧栏提供大号菜单文字、高对比和减少界面动效。大号文字不放大固定像素 HUD；减少界面动效不关闭游戏世界震动或闪光。专注模式不跨刷新保存。

## 能力与验收

已接入 27 个独立模块；其余逻辑仍有 33 个兼容片段。关卡接口仅支持已登记的原型能力，完整泰拉角色尚不能任意跨图。

Windows、真实 HTTP 加载、实体手柄与触屏、持久设置、音频听感和自然通关仍需验收。详见 [已知限制](docs/KNOWN_LIMITS.md) 和 [UI 验收清单](docs/ACCEPTANCE_UI_M05.md)。

## 打包与发布

`npm run pack` 生成 `.local/MarioMix_Terraria_M05_R15_Source.zip`。`npm run prepublish:check` 核对自动产物；`npm run release:check` 另行核对人工证据。测试通过不是上线批准。

当前版本由 `release.json` 记录。游戏变更见 [M05 记录](docs/CHANGELOG_M05.md)，文档修订见 [R15 记录](docs/CHANGELOG_R15.md)。历史记录在 `docs/history/` 与各版本交接文件中保留；源包无字体文件。
