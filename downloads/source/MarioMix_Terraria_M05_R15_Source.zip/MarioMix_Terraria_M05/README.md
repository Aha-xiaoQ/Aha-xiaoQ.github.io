# 混合马里奥 · 第三期开发源码

不同游戏的角色，用自己的动作与武器闯过经典关卡。第三期加入泰拉瑞亚角色、装备与地下挑战。

**开发版 0.4.1 · 待实机验收**。本源码包包含构建工具、测试与开发指南；与当前线上试玩分别维护。R15 是文档修订号，游戏逻辑与 M05 保持一致。

[运行项目](START_HERE.md) · [代码贡献指南](CONTRIBUTING.md) · [可参与任务](docs/TASKS.json) · [已知限制](docs/KNOWN_LIMITS.md)

```sh
npm run verify
npm run dev
```

需要 Node.js 22 或以上，无需 npm install。访问 `http://127.0.0.1:4193/play.html`。修改 `src/` 或 `content/` 后重启服务并刷新；`dist/` 是生成产物。

关卡扩展仍为实验功能：完整泰拉角色、武器、背包与坐骑尚不能直接用于任意地图，暂不包含 1-4。

资源来源与许可见 [NOTICE](upstream/NOTICE.txt) 和 [资源说明](docs/RESOURCES.md)。第三方角色、图像与音频的权利不因源码公开而转移。
