# 结构参考与采用范围

- Phaser · Scenes：https://docs.phaser.io/phaser/concepts/scenes
  借鉴场景进入/退出和暂停的独立职责。未接入Phaser或搬运源码，仍使用既有物理。
- Phaser · Scene Events：https://docs.phaser.io/api-documentation/event/scenes-events
  参考停止、销毁的区分；本工程只有明确adapter清理，不声称等同于成熟引擎全部生命周期。
- Godot · Scene organization：https://docs.godotengine.org/en/4.4/tutorials/best_practices/scene_organization.html
  借鉴低耦合与显式依赖注入；ChapterSession不读DOM或旧全局。
- JayPavlina / super-mario-bros-crossover：https://github.com/JayPavlina/super-mario-bros-crossover
  参考角色/关卡/声音职责分类，不迁移ActionScript。上游README说明不包含图像音频；源码许可不代表原游戏素材许可。

参考为公开第一方文档。只是采用组织原则，不是通过列出参考就证明本框架已达到其成熟度。
