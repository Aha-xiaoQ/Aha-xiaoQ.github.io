/** M03 supported authoring profile; compile-time aid, runtime validation is authoritative. */
export interface Rect {x:number;y:number;w:number;h:number}
export interface Point {x:number;y:number}
export interface Chapter {
 apiVersion:1;id:string;after?:string;title:string;description:string;revision:string;draft:boolean;
 profile:'terra-surface-v1';width:number;spawn:Point;biome:'forest'|'desert'|'crimson'|'jungle'|'snow';time:number;
 requires:string[];
 surfaces:(Rect & {id:string;type:'floor'|'stone'|'tree'})[];
 enemies:{id:string;kind:'slime'|'zombie'|'caveBat'|'demonEye'|'goomba'|'koopa';x:number;surface:string}[];
 coins:(Point & {id:string})[];
 checkpoints:(Rect & {id:string;spawn:Point})[];
 hazards:(Rect & {id:string;damage:number})[];
 exits:(Rect & {id:string;type:'portal'|'return'|'complete';target?:string;reward?:{coins:number;score:number}})[];
}
