# Chapter API v1

运行时校验为 src/content/chapter-contract.mjs；chapter-api.d.ts 供编辑器提示，不能代替运行校验。未知字段会报错，不能把未实现功能写成配置后以为生效。

| 配置 | 约定 |
|---|---|
| apiVersion / profile | 1 / terra-surface-v1 |
| id / after / revision | 稳定目录ID；前驱 legacy-13 或另一章；非空文本修订（如 "1" 或 "2026-09-16"） |
| title / description / draft | 展示文本；草稿默认不进入普通主线 |
| width / spawn / time / biome | 固定240高，宽度512–8192且16倍数；出生落在支撑面；既有生态主题 |
| surfaces | id、type（floor/stone/tree）、x/y/w/h；矩形平台数据 |
| enemies | id、kind（slime/zombie/caveBat/demonEye/goomba/koopa）、x、surface引用 |
| coins | id、x、y；沿用原拾取逻辑 |
| checkpoints | id、x/y/w/h、spawn；安全重生点必须有支撑 |
| hazards | id、x/y/w/h、damage；沿用受伤保护与死亡 |
| exits | id、type、x/y/w/h；portal 需 target；complete 可有 coins/score 奖励 |
| requires | 显式所需能力；不支持的能力在构建时拒绝 |

公共对象 ID 不重复；入口引用必须可解析；after 不得成环（普通双向 portal 可以互相引用）。地形、出生、奖励、越界及数值均被检查。schema 不接收任意 CSS、DOM、文件路径或运行函数。

## 生命周期

框架 prepare(spec)→stop(old)→activate(new)。准备失败不停止原关；激活失败尝试恢复原关。tick 在原 fixed-step 内推进，暂停不触发关卡危险区、计时或奖励。原模拟仍由兼容适配器管理。

checkpoint 只更新本章检查点；portal 需要交互边沿与入场冷却，避免按住按键来回弹跳；complete 进入共享结算，同一会话中奖励按 id@revision:exit 去重；return 恢复进入前主线对象及位置。源码中的 ChapterSession adapter 是维护者接口，不是给关卡写任意脚本的插件接口。

## 进度

仅传递 ChapterProgress 白名单字段：生命、生命上限、剩余次数、分数、金币、木材、武器与有限库存/配饰、已得坐骑等。数组/字典复制，不共享跨场景引用。坐标、弹幕、局部敌人、计时器、镜头、DOM与音频节点不携带；切关主动下坐骑，保留已获得资格。

回访房间保留其本次会话地图变更和上一位置。存活时 restart 重新创建该关卡地图并保留当时便携进度；死亡/游戏结束后从共享按钮重新开始该章，会按原开局建立新一轮状态；菜单退出清空 SDK 会话缓存。不是通用存档格式，也不支持浏览器刷新后恢复跨章进度。

## 调试入口

显式 ?chapters=1 / ?chapter=id 模式暴露 window.TerraChapters：list(), enter(id), back(), restart(), state(), progress()。正常玩家模式不暴露此入口。源码可见性不是保密控制；草稿仍会存在于开发构建中。
