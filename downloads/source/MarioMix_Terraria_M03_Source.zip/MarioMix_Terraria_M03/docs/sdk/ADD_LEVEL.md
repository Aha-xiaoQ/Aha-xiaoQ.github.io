# 新增一个关卡：只增加自己的目录

本教程以 API v1 / terra-surface-v1 为界。不是从空文件实现另一个游戏，也不需要复制旧闭包。

## 1. 起点

解压 M03 源码，执行 `npm run verify`。Node.js22+，不必安装 npm 依赖。

```sh
npm run level:new -- --id community-14 --title "我的 1-4"
```

生成 levels/community-14/chapter.json、README.md、acceptance.json。现有文件不覆盖；重复 ID 和不安全路径会失败。没有要手动编辑的中央关卡登记表。

## 2. 编辑什么

只编辑 chapter.json：title/description 给玩家看；surfaces 定义地面与平台；enemies 引用支持的敌人；coins、checkpoints、hazards、exits 定义交互。id 是稳定代码标识，不因为改标题而变化。revision 是本关内容修订，影响本次会话中的奖励去重身份。

地图单位是原游戏逻辑像素，而不是屏幕 CSS 像素。默认主角碰撞盒16×32，地面208；出生点通常 y=176。width 必须是16倍数。地图高度固定240；长地图可横向滚动。高度不同的隐藏地底和旋转重力不在此 profile 内。

after="legacy-13" 表示可作为原第三期后的候选章节。它只定义顺序，不绕过 draft 和发布验收。portal target 是另一个目录的 id；return 返回进入 SDK 前的原主线，不是任意返回点脚本。

## 3. 验证与预览

```sh
npm run level:check
npm run dev
```

打开 `http://127.0.0.1:4193/play.html?chapter=community-14`。修改后重启 dev 并刷新。或者用 `?chapters=1` 查看工作台并选择关卡。它使用原游戏的移动、攻击、装备、设置、HUD和结算界面。

样例 sdk-14 是接入测试地形，不是作者未完成的城堡。sdk-room 展示支路进入/回返。实测目标：走动跳跃、攻击现有敌人、拾取金币、命中检查点、死亡重试、进出房间、碰终点结算、带着装备和奖励返回原主线。门使用“交互”动作，默认映射以设置页为准，不能把 UI 装饰文字当独立按键绑定。

## 4. 开 PR

保持 draft=true，提交自己的 levels/目录以及测试记录；不提交生成的 dist。维护者补验后才考虑 draft=false 与正式主线发布。设置 false 会使 after 满足时的下一关按钮可见，但不等于 release:check 已通过。

必读：CHAPTER_API.md、CAPABILITIES.md、ACCEPTANCE.md。验收发现需要新 Boss 或资源机制时，先提出框架接口任务，不通过修改旧全局变量绕过边界。
