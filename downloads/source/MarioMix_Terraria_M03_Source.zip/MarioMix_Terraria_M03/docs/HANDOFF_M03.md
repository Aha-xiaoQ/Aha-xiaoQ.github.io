# M03 / R11 交接

日期：2026-09-16。本地候选、未推送、未发布。以完整M02为上游，以最初第三期上传包为不变baseline。未引入城堡/R29。

## 本轮实际变化

19个独立模块（新增4个），33个compat片段；新增ChapterContract、MapCompiler、Progress、Session和一个集中bridge。关卡只需levels目录，构建自动发现；draft控制普通主线可见性，after接入结算后下一关；关卡数据改变会改变候选sourceHash。

sdk-14和sdk-room是明确标注的接入样例，沿用真实游戏系统，不是另一个toy runner，也不是正式1-4作品。第三个community-14仅在测试临时目录创建，不留在发货目录。

## 可复现证据

verify、浏览器13阶段旧游戏对照、设置25项、chapter34项。源码新增34项chapter测试，整体119项。具体证据见TEST_REPORT_M03.md与交付包validation。原版重建SHA仍为e134fdee21a6dce43585cda93c582ca2c0bf45f325f14cde81e33b80b758f19c。

## 不得误称已完成

没有通用新Boss/角色/武器插件、分章资产包、自定义物理/重力、地下大世界或持久化跨版本存档。仍有33个compat共享状态。Windows、真实HTTP/ESM与真实设备/自然通关待验收。实际外部开发者PR还未发生，模拟只新增目录实验不是网友已经完成贡献。

## 下一步

先请独立作者按ADD_LEVEL完成小图并反馈阻碍，再推进自定义行为/Boss生命周期接口，接着分章资源声明与加载失败回退、持久存档迁移。原M03-INVENTORY/M03-SCENE旧任务不自动标完成；它们覆盖比本章adapter更大的范围。新增任务在docs/TASKS.json。

## 网站

R11更新R10安装，源码下载新M03，M02历史保留。开发→混合马里奥→资料→新关卡接入指南，路径 /notes/mario-mix/docs/terra-chapters/。由主站现有模板生成，不改CSS/导航/转场，不覆盖稳定游戏。
