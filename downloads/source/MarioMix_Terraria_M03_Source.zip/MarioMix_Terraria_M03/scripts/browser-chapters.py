import os
"""Actual complete game with the M03 chapter adapter, in an offline DOM environment.
No network, authentic OS gamepad, natural full campaign or Windows claims are made.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json,hashlib,shutil,tempfile,subprocess
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'.local/chapters-browser'
OUT.mkdir(parents=True,exist_ok=True)
def source():
    return (ROOT/'dist/MarioMix_Terraria_M03.html').read_text().replace('<html lang="zh-CN">','<html lang="zh-CN" data-test="1">')
checks=[];errors=[]
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path=shutil.which('chromium'),headless=True,args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1280,'height':850})
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.route('https://**/*',lambda r:r.abort());page.route('http://**/*',lambda r:r.abort())
    def load(html):
        page.set_content(html,wait_until='domcontentloaded',timeout=25000)
        page.wait_for_function('window.__trioTest && window.TerraChapters',timeout=15000)
        page.evaluate('window.__trioTest.ready');page.evaluate('window.__trioTest.r06AssetReady');page.wait_for_timeout(300)
    load(source())
    checks=page.evaluate(r'''() => {
      const t=__trioTest,a=TerraChapters,passed=[];
      const ok=(x,n)=>{if(!x)throw Error(n);passed.push(n);};
      t.start();t.fixture({coins:11});const origin=t.state();
      a.enter('sdk-14');let s=t.state();
      ok(s.chapterId==='sdk-14'&&s.level.width===1024,'Loaded authored terrain in real game');
      ok(s.coins===11&&s.t13Weapon===origin.t13Weapon,'Inherited coins and equipped weapon');
      ok(s.pipe===null&&s.t21Deer===null,'Removed inherited 1-3-specific pipe and boss');
      ok(s.foes.length===1,'Enemy roster comes from chapter data');
      const x=s.p.x;t.step(18,{x:1});ok(t.state().p.x>x+10,'Reused actual player movement');
      const y=t.state().p.y;t.step(10,{x:1,jump:true});ok(t.state().p.y<y,'Reused actual player jump');
      t.step(30,{action:true});ok(t.state().events.some(e=>/attack|slash|shot|star|weapon/.test(e.type)),'Reused actual combat path');
      const tick=t.state().ticks,elapsed=a.state().elapsed;t.pause();t.native(30);ok(t.state().ticks===tick&&a.state().elapsed===elapsed,'Pause stops gameplay and chapter triggers');t.pause();
      t.t21.settings();let rejected=false;try{a.enter('sdk-room');}catch{rejected=true;}ok(rejected,'Settings focus blocks chapter switch');t.t21.closeSettings();
      t.player({x:174,y:176,vx:0,vy:0,grounded:true,invuln:120});t.step(21,{});t.step(1,{auxiliary:true});
      ok(a.state().current==='sdk-room','Real portal rectangle and input edge switch rooms');
      ok(t.state().coins>=11,'Portable state retained through portal');
      t.player({x:180,y:174,vx:0,vy:0,grounded:true});const c=t.state().coins;t.step(1,{});ok(t.state().coins>c,'Room coin collected by inherited system');
      t.player({x:351,y:176,vx:0,vy:0,grounded:true});t.step(22,{});t.step(1,{auxiliary:true});ok(a.state().current==='sdk-14','Back portal restores the previous chapter');
      t.player({x:552,y:144,vx:0,vy:0,grounded:true});t.step(1,{});ok(t.state().chapterCheckpoint==='midpoint','Checkpoint trigger updates respawn');
      t.player({y:310,invuln:0});t.step(90,{});ok(t.state().mode==='respawn','Real falling-death flow reaches respawn');t.primary();ok(Math.abs(t.state().p.x-558)<1,'Inherited retry uses authored checkpoint');
      t.step(22,{});t.player({x:948,y:176,vx:0,vy:0,grounded:true,invuln:120});const before=t.state().coins;t.step(1,{});
      ok(a.state().phase==='complete'&&t.state().mode==='win','Chapter goal uses shared completion mode');ok(t.state().coins===before+3,'Authored reward applied exactly once');
      document.getElementById('mainAction').click();ok(a.state().current==='legacy-13','Shared confirm button returns to original game');
      ok(t.state().p.x===origin.p.x&&t.state().level.width===origin.level.width,'Original map and player position restored');
      const carry=t.state().coins;a.enter('sdk-14');t.step(22,{});t.player({x:948,y:176,vx:0,vy:0,grounded:true,invuln:120});t.step(1,{});ok(t.state().coins===carry,'Returning to completed chapter cannot duplicate goal reward');a.back();
      t.start();t.finish();t.step(1200,{});ok(t.state().mode==='win','Original 1-3 finish flow remains reachable');
      ok(!!document.querySelector('#terraNextChapter button'),'Registered successor appears after 1-3 completion in developer mode');
      document.querySelector('#terraNextChapter button').click();ok(a.state().current==='sdk-14','Next-chapter button reaches the same adapter');
      a.back();ok(t.state().mode==='win'&&!document.getElementById('overlay').classList.contains('hidden'),'Returning to a completed origin restores its usable result screen');
      t.start();t.pause();a.enter('sdk-14');a.back();ok(t.state().mode==='paused'&&!document.getElementById('overlay').classList.contains('hidden'),'Returning to a paused origin preserves pause ownership');t.pause();
      a.enter('sdk-14');t.fixture({lives:1});t.player({y:310,invuln:0});t.step(100,{});ok(t.state().mode==='gameover','Real chapter final-life death reaches gameover');document.getElementById('mainAction').click();ok(a.state().current==='sdk-14'&&t.state().mode==='playing'&&t.state().hp>0,'Shared gameover retry starts a fresh run of the same authored chapter');a.back();
      t.start();for(let i=0;i<10;i++){a.enter('sdk-14');a.back();}
      ok(document.querySelectorAll('#terraChapters').length===1&&document.querySelectorAll('#t21Bindings').length===1,'Repeated handoffs do not duplicate UI owners');
      a.enter('sdk-14');t.step(25,{x:1});return passed;
    }''')
    page.locator('#terraChapters').evaluate('(e)=>e.open=true')
    page.screenshot(path=str(OUT/'M03-chapter-desktop.png'),full_page=True)
    for w in [390,768]:
        page.set_viewport_size({'width':w,'height':844});page.wait_for_timeout(80)
        assert page.evaluate('document.documentElement.scrollWidth <= innerWidth'),f'Overflow {w}'
        checks.append(f'No document overflow at {w}px')
    page.set_viewport_size({'width':390,'height':844});page.screenshot(path=str(OUT/'M03-chapter-mobile.png'),full_page=True)
    # A separate developer's directory is generated in a fresh source copy, not registered in core.
    with tempfile.TemporaryDirectory(prefix='terra-contributor-') as temp:
        target=Path(temp)/'project';shutil.copytree(ROOT,target,ignore=shutil.ignore_patterns('.local','dist'))
        tracked=[f for f in target.rglob('*') if f.is_file()]
        before={str(f.relative_to(target)):hashlib.sha256(f.read_bytes()).hexdigest() for f in tracked}
        author_id='community-14'
        while (target/'levels'/author_id).exists(): author_id+='-next'
        for command in [['node','scripts/chapters.mjs','new','--id',author_id,'--title','独立开发者的 1-4'],['node','scripts/build.mjs']]:
            subprocess.run(command,cwd=target,check=True,stdout=subprocess.DEVNULL)
        assert all(hashlib.sha256((target/f).read_bytes()).hexdigest()==h for f,h in before.items()),'Existing source changed during scaffolding'
        checks.append('Fresh developer added only a new level directory; existing source hashes unchanged')
        verified=subprocess.run(['npm' if os.name!='nt' else 'npm.cmd','run','verify'],cwd=target,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        assert verified.returncode==0,verified.stdout[-10000:]
        checks.append('New author chapter passes the full unchanged verify pipeline')
        page.close()
        page=browser.new_page(viewport={'width':1280,'height':850})
        page.on('pageerror',lambda e:errors.append(str(e)))
        page.route('https://**/*',lambda r:r.abort());page.route('http://**/*',lambda r:r.abort())
        load((target/'dist/MarioMix_Terraria_M03.html').read_text().replace('<html lang="zh-CN">','<html lang="zh-CN" data-test="1">'))
        page.evaluate('(id)=>window.__authorChapterID=id',author_id)
        r=page.evaluate("__trioTest.start();TerraChapters.enter(__authorChapterID);__trioTest.step(50,{x:1});({chapter:TerraChapters.state().current,x:__trioTest.state().p.x})")
        assert r['chapter']==author_id and r['x']>70
        checks.append('Independent developer chapter runs inside the real candidate game')
    browser.close()
assert not errors,errors
report={'result':'pass','checks':checks,'count':len(checks),'errors':errors,'scope':'Complete candidate game via offline set_content. Condition placement uses test hooks; not natural full playthrough, HTTP/ESM or real devices. No castle implementation included.'}
(OUT/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps(report,ensure_ascii=False,indent=2))
