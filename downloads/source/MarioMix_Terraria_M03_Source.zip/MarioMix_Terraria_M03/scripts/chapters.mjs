#!/usr/bin/env node
/** Directory discovery: new content does not edit a shared registry or the game core. */
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createChapterContract} from '../src/content/chapter-contract.mjs';
import {safe,readOptional,writeAtomic,entryStat} from './lib/safe-path.mjs';
const ROOT=fileURLToPath(new URL('../',import.meta.url));
export function loadChapters(root=ROOT) {
 const entries=[],files=[];
 const dir=safe(root,'levels');if(!entryStat(dir))throw Error('Missing levels directory');
 for(const e of fs.readdirSync(dir,{withFileTypes:true}).sort((a,b)=>a.name.localeCompare(b.name,'en'))){
  const rel='levels/'+e.name;safe(root,rel);
  if(!e.isDirectory())throw Error('Only chapter directories belong in levels/');
  const p=rel+'/chapter.json',bytes=readOptional(root,p);if(!bytes)throw Error('Missing descriptor '+p);
  if(bytes.length>200000)throw Error('Chapter exceeds 200 KB');
  const s=createChapterContract().validate(JSON.parse(bytes));if(s.id!==e.name)throw Error('Chapter ID must match directory');entries.push(s);files.push(p);
 }
 createChapterContract().registry(entries);
 return {entries,files};
}
export function scaffold(root,id,title) {
 if(!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(id)||id==='legacy-13')throw Error('Use a non-reserved lowercase ID');
 const dest='levels/'+id;if(entryStat(safe(root,dest)))throw Error('Chapter already exists; not overwriting');
 const s={apiVersion:1,after:'legacy-13',id,title,revision:'1',profile:'terra-surface-v1',draft:true,description:'新的关卡草稿；到达金色出口结束演练。',width:1024,spawn:{x:48,y:176},biome:'forest',time:300,requires:['terrain','existing-actor','shared-hud'],surfaces:[{id:'ground',type:'floor',x:0,y:208,w:1024,h:32}],enemies:[],coins:[],checkpoints:[],hazards:[],exits:[{id:'finish',type:'complete',x:944,y:160,w:32,h:48,reward:{coins:0,score:0}}]};
 createChapterContract().validate(s);
 writeAtomic(root,dest+'/chapter.json',Buffer.from(JSON.stringify(s,null,2)+'\n'));
 writeAtomic(root,dest+'/README.md',Buffer.from('# '+title+'\n\n草稿，未发布。参阅 ../../docs/sdk/CHAPTER_API.md。\n'));
 writeAtomic(root,dest+'/acceptance.json',Buffer.from(JSON.stringify({chapter:id,reviewed:false,checks:{spawn:null,jump:null,combat:null,checkpoint:null,pause:null,completion:null,return:null,devices:null},evidence:[]},null,2)+'\n'));
 return {path:dest,entry:'http://127.0.0.1:4193/play.html?chapter='+id,requiredEdits:['chapter.json'],productionPublished:false};
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 try{const mode=process.argv[2];if(mode==='new'){const flag=k=>{const n=process.argv.indexOf(k);return n<0?undefined:process.argv[n+1];};console.log(scaffold(ROOT,flag('--id'),flag('--title')));}else{const data=loadChapters();console.log(JSON.stringify(mode==='list'?data.entries.map(s=>({id:s.id,title:s.title,draft:s.draft})):({valid:true,chapters:data.entries.length}),null,2));}}
 catch(e){console.error(e.message);process.exitCode=1;}
}
