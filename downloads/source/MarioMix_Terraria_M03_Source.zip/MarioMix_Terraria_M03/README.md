# 混合马里奥 · Terraria M03

以第三期泰拉瑞亚为基础的协作工程。M03 把“怎样接入下一关”变成可运行的接口和验收样例，不是新的城堡关，也不替换线上稳定游戏。

[开始开发](START_HERE.md) · [新增关卡](docs/sdk/ADD_LEVEL.md) · [支持边界](docs/sdk/CAPABILITIES.md) · [如何贡献](CONTRIBUTING.md) · [验证结果](docs/TEST_REPORT_M03.md)

```sh
npm run verify
npm run level:new -- --id my-14 --title "我的 1-4"
npm run level:check
npm run dev
```

打开 `http://127.0.0.1:4193/play.html?chapter=my-14`。已有源码无需修改，新增定义会被构建器发现。地图使用真实游戏的角色、战斗、道具、设置和 HUD；不要编辑 dist 中的产物。

**支持范围不是任意引擎插件**：当前 API v1 / terra-surface-v1 是固定高度的横版表面关卡。已有地形、指定敌人、金币、检查点、危险区、房间门和结束目标可由数据配置；新 Boss、重力规则、完整世界编辑、分关资源包和跨版本存档还需要框架扩展。

19 个真实模块已接入，33 个兼容片段仍有旧共享状态。迁移桥接被显式登记，不冒充整个游戏已解耦。原资源与声明保留，未重新授权为 MIT。
