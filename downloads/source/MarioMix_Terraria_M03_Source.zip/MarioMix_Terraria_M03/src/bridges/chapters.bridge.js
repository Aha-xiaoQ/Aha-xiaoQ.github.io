/* One M03 adaptation boundary inside the inherited Terraria closure.
 * No castle source imported. New chapter authors do not edit this bridge.
 */
const m03Contract=__terraModules.createChapterContract();
const m03Registry=m03Contract.registry(__terraChapterDefinitions);
const m03Progress=__terraModules.createChapterProgress();
const m03Compile=__terraModules.compileChapterMap;
const m03Old={step,render,open:openGame,menu:showCharacters,primary:handlePrimary,populate:t21Populate,deer:t21MakeDeer,interact:terraInteractions,biome:t16BiomeAt};
const m03Run=__terraModules.createChapterSession({registry:m03Registry,progress:m03Progress,adapter:{
 canEnter:()=>!!state&&isTrio()&&!state.r05Arena&&!state.t11Transition&&!t21BindingBox.open&&['playing','paused','win'].includes(mode),
 isPlaying:()=>mode==='playing',
 canReturn:()=>!state?.t11Transition&&!['dying','gameover'].includes(mode),
 capture:()=>({state,mainState,mode,stageChoice,overlay:Object.fromEntries(['overlayLabel','overlayTitle','overlayText','mainAction','overlayHint'].map(id=>[id,$(id).textContent]))}),
 prepare(spec){
  const s=newState();
  s.chapterId=spec.id;s.chapterSpec=spec;s.level=m03Compile(spec);
  s.trees=[];s.pipe=null;s.t11Chest=null;s.t16MainChest=null;s.t21Deer=null;
  s.t13Drops=[];s.t21ExtraShots=[];s.t21Hostile=[];s.r06Drops=[];s.r07Loot=[];s.r06FX=[];s.t10Particles=[];s.projectiles=[];s.minions=[];s.numbers=[];s.impacts=[];s.built=[];
  s.t13World=null;s.t11Transition=null;s.t10PendingMount=null;s.t16Cart=null;s.t16CartOwned=false;
  s.t16Biome=spec.biome;s.t21Populated=true;s.finish=false;s.ending=null;s.secret=false;s.r05Arena=false;
  s.time=spec.time;s.timeTicks=0;s.cam=0;s.r07CamY=0;s.ticks=0;s.checkpoint={...spec.spawn};s.chapterCheckpoint='spawn';
  Object.assign(s.p,spec.spawn,{vx:0,vy:0,grounded:true,support:s.level.surfaces.find(q=>Math.abs(q.y-spec.spawn.y-s.p.h)<1&&q.x<=spec.spawn.x&&q.x+q.w>spec.spawn.x)?.id||null,invuln:90,attack:0,cooldown:0,hurtLock:0,drop:0});
  s.foes=spec.enemies.map((e,i)=>{
   const q=s.level.surfaces.find(q=>q.id===e.surface);
   if(!['goomba','koopa'].includes(e.kind))return {...t10MakeFoe(e.kind,q,e.x,i,'green'),id:e.id};
   const h=e.kind==='koopa'?24:16;return {id:e.id,kind:e.kind,x:e.x,y:q.y-h,w:16,h,hp:32,maxHp:32,dir:-1,vx:0,vy:0,age:0,flash:0,dead:0,hitBy:-1,grounded:true,knock:0,active:false,spawnX:e.x,spawnY:q.y-h,home:q.id};
  });
  s.notice=spec.description;s.noticeTime=280;return s;
 },
 stop(){t21CloseBindings();r05StopLocal();r06StopMusic();resetGameAudio();clearInput();},
 activate(next,spec){state=next;mainState=null;stageChoice=0;mode='playing';room='surface';hideOverlay();clearInput();r06SyncKitTools();canvas.focus({preventScroll:true});trioUI();},
 restore(saved){state=saved.state;mainState=saved.mainState;stageChoice=saved.stageChoice;r07SetMountHeight(state,false);mode=['win','paused'].includes(saved.mode)?saved.mode:'playing';clearInput();hideOverlay();if(mode!=='playing'&&saved.overlay){showOverlay('','','','','');for(const [id,text]of Object.entries(saved.overlay))$(id).textContent=text;}r06SyncKitTools();if(state.kit==='summoner')r06CreateMinions(state);trioUI();audioSync();},
 reward(r){state.coins=(state.coins||0)+r.coins;state.score=(state.score||0)+r.score;},
 checkpoint(c){state.checkpoint={...c.spawn};state.chapterCheckpoint=c.id;note('检查点已记录');},
 damage(amount){if(mode!=='playing'||state.p.invuln)return;state.hp=Math.max(0,state.hp-amount);state.p.invuln=90;terraSound('hurt');if(state.hp<=0)fail('chapter-hazard');},
 completed(spec){state.finish=true;mode='win';clearInput();stopMusic(false);stopEffects();showOverlay(spec.id.toUpperCase(),'接入关卡完成','已完成本章目标。装备与本轮奖励可带回原主线。','返回原主线 →','输入设置与操作方式保持不变');}
}});
// Disable only hard-coded 1-3 population/pipe logic in data-driven chapters.
// Movement, collision, weapons, inventory, mounts, HUD and settings still use the inherited runtime.
t21Populate=function(s){if(s?.chapterId)return;return m03Old.populate(s);};
t21MakeDeer=function(s){if(s?.chapterId)return;return m03Old.deer(s);};
terraInteractions=function(v){if(state?.chapterId)return false;return m03Old.interact(v);};
t16BiomeAt=function(x,s=state){if(s?.chapterSpec)return T16_BIOMES.find(b=>b.id===s.chapterSpec.biome)||T16_BIOMES[0];return m03Old.biome(x,s);};
step=function(v){const result=m03Old.step(v);m03Run.tick(v);return result;};
openGame=function(){if(m03Run.spec()&&state){if(['dying','respawn','gameover'].includes(mode)){const id=m03Run.spec().id;m03Run.cancel();m03Old.open();return m03Run.enter(id);}m03Run.restart();return;}return m03Old.open();};
showCharacters=function(){m03Run.cancel();return m03Old.menu();};
handlePrimary=function(){if(m03Run.spec()&&mode==='win')return m03Run.back();return m03Old.primary();};
function m03DrawMarkers(){
 const spec=m03Run.spec();if(!spec||!state||mode==='menu')return;
 ctx.save();
 for(const r of spec.hazards){ctx.fillStyle='#b74235';ctx.fillRect(r.x-state.cam,r.y,r.w,r.h);}
 for(const c of spec.checkpoints){ctx.fillStyle=state.chapterCheckpoint===c.id?'#b2da90':'#61796b';ctx.fillRect(c.x-state.cam,c.y,3,c.h);ctx.fillRect(c.x-state.cam,c.y,14,8);}
 for(const e of spec.exits){const x=e.x-state.cam;ctx.fillStyle=e.type==='complete'?'#d9bc68':'#79bec1';ctx.fillRect(x,e.y,e.w,e.h);ctx.fillStyle='#17353c';ctx.fillRect(x+4,e.y+5,Math.max(1,e.w-8),Math.max(1,e.h-5));ctx.fillStyle='#f3e8cb';ctx.font='6px sans-serif';ctx.textAlign='center';ctx.fillText(e.type==='complete'?'目标':e.type==='return'?'交互返回':'交互进入',x+e.w/2,e.y-4);}
 ctx.restore();
 $('distanceLabel').textContent=spec.id.toUpperCase()+' · '+Math.floor(Math.min(100,state.p.x/spec.width*100))+'%';
 $('stateLabel').textContent=mode==='paused'?'已暂停':spec.title;
 const kicker=document.querySelector('.panel .kicker');if(kicker)kicker.textContent=spec.id.toUpperCase();
 const badge=document.querySelector('header .offline');if(badge)badge.textContent='TERRARIA · '+spec.id.toUpperCase();
 $('progressFill').style.width=Math.min(100,state.p.x/spec.width*100)+'%';
 if(mode==='win'){$('overlayTitle').textContent=spec.title;$('overlayText').textContent='接入目标完成；可以返回原主线或继续下一关。';$('mainAction').textContent='返回原主线 →';}
 const heading=document.querySelector('.panel h2');if(heading)heading.textContent=spec.title;
 const intro=document.querySelector('.panel>.intro');if(intro&&intro.id!=='heroHelp')intro.textContent=spec.description;
 const tagline=document.querySelector('.tagline span');if(tagline)tagline.textContent='沿途探索，抵达本章目标。';
 $('relayMessage').textContent=mode==='win'?'本章完成 · 返回原主线或继续':'共享角色 / 装备 / 操作设置';
 $('heroHelp').textContent='青色门：使用交互动作进入／返回。金色门：本章目标。';
}
render=function(){const out=m03Old.render();m03DrawMarkers();m03SyncNext();return out;};
const m03API={apiVersion:1,list:()=>[...m03Registry.values()].map(s=>({id:s.id,title:s.title,draft:s.draft,profile:s.profile})),
 enter(id){if(!m03Registry.has(id))throw Error('未知关卡：'+id);if(!ready)throw Error('内嵌资源仍在解码');if(!state||!isTrio()){showCharacters();selectHero('sandboxTrio');m03Old.open();}const out=m03Run.enter(id);render();return out;},
 back(){const out=m03Run.back();render();return out;},restart(){openGame();render();return m03Run.snapshot();},state:m03Run.snapshot,
 progress:()=>state?m03Progress.capture(state):null};
// A deliberate authoring entry; no unfinished chapter is added to the normal campaign.
const m03Params=new URLSearchParams(location.search),m03Dev=m03Params.has('chapters')||m03Params.has('chapter')||document.documentElement.dataset.test==='1';
if(m03Dev){
 window.TerraChapters=Object.freeze(m03API);
 const box=document.createElement('details');box.id='terraChapters';
 const label=document.createElement('summary');label.textContent='关卡接入工作台（开发预览）';box.append(label);
 const help=document.createElement('p');help.textContent='样例不是正式 1-4；共用本作角色、战斗和设置。退出时保留本轮携带物品。';box.append(help);
 const sel=document.createElement('select');sel.id='terraChapterSelect';sel.setAttribute('aria-label','选择接入关卡');
 for(const s of m03Registry.values()){const o=document.createElement('option');o.value=s.id;o.textContent=s.title;sel.append(o);}box.append(sel);
 for(const [name,fn]of [['进入关卡',()=>m03API.enter(sel.value)],['返回原主线',()=>m03API.back()]]){const b=document.createElement('button');b.type='button';b.textContent=name;b.onclick=()=>{try{fn();}catch(e){help.textContent=e.message;}};box.append(b);}
 t15Help.after(box);
 const css=document.createElement('style');css.textContent='#terraChapters{font:inherit;font-size:12px;padding:12px;border:1px solid #6a7e87;border-radius:6px;margin:12px 0;color:#deeadc}#terraChapters select,#terraChapters button{font:inherit;margin:5px 6px 5px 0;padding:8px;background:#203640;color:#efe4be;border:1px solid #718879;max-width:100%}#terraChapters p{line-height:1.6}';document.head.append(css);
 if(m03Params.has('chapter'))readyPromise.then(()=>{try{m03API.enter(m03Params.get('chapter'));}catch(e){help.textContent=e.message;}});
}

let m03NextControl=null;
function m03SyncNext(){
 if(!isTrio()||mode!=='win'){if(m03NextControl)m03NextControl.hidden=true;return;}
 const origin=m03Run.spec()?.id||'legacy-13';
 const next=[...m03Registry.values()].filter(s=>s.after===origin&&(!s.draft||m03Dev));
 if(!next.length){if(m03NextControl)m03NextControl.hidden=true;return;}
 if(!m03NextControl){m03NextControl=document.createElement('div');m03NextControl.id='terraNextChapter';$('mainAction').after(m03NextControl);}
 if(m03NextControl.dataset.origin!==origin){m03NextControl.replaceChildren();m03NextControl.dataset.origin=origin;for(const spec of next){const b=document.createElement('button');b.type='button';b.textContent='下一关：'+spec.title;b.onclick=()=>{try{m03API.enter(spec.id);}catch(e){note(e.message);}};m03NextControl.append(b);}}
 m03NextControl.hidden=false;
}
