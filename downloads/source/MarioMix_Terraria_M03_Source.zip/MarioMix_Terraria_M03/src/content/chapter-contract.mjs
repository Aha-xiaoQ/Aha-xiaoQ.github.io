/** Versioned, data-only chapter profile. A validator is not a code sandbox. */
export function createChapterContract() {
  const profiles = ['terra-surface-v1'];
  const biomes = ['forest','desert','crimson','jungle','snow'];
  const kinds = ['floor','stone','tree'];
  const enemies = ['slime','zombie','caveBat','demonEye','goomba','koopa'];
  const capabilities = ['terrain','existing-actor','existing-weapons','checkpoints','hazards','portals','shared-hud','session-rewards'];
  const idRE = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;
  const fail = m => {throw Error('Chapter: '+m);};
  const object = (v,keys,label) => {if(!v||typeof v!=='object'||Array.isArray(v)||Object.getPrototypeOf(v)!==Object.prototype)fail(label+' must be a plain object');for(const k of Object.keys(v))if(!keys.includes(k))fail(label+' unknown field '+k);};
  const number = (n,min,max,label) => {if(!Number.isFinite(n)||n<min||n>max)fail(label+' out of range');};
  const text = (s,n,label) => {if(typeof s!=='string'||!s.trim()||s.length>n||/[\u0000-\u001f]/.test(s))fail(label+' invalid text');};
  function rect(r,width,label) {for(const k of ['x','y','w','h'])number(r[k],k==='w'||k==='h'?1:0,k==='x'||k==='w'?width:240,label+'.'+k);if(r.x+r.w>width||r.y+r.h>240)fail(label+' outside map');}
  function validate(s) {
    object(s,['apiVersion','after','id','title','revision','profile','draft','description','width','spawn','biome','time','surfaces','enemies','coins','checkpoints','hazards','exits','requires'],'descriptor');
    if(s.apiVersion!==1)fail('unsupported apiVersion');if(s.after!==undefined&&!idRE.test(s.after))fail('invalid predecessor');if(!idRE.test(s.id||'')||s.id==='legacy-13')fail('invalid/reserved ID');text(s.title,40,'title');text(s.description,200,'description');text(s.revision,40,'revision');
    if(!profiles.includes(s.profile))fail('unsupported profile '+s.profile);if(typeof s.draft!=='boolean')fail('draft must be explicit');
    number(s.width,512,8192,'width');if(s.width%16)fail('width must align to 16');number(s.time,30,999,'time');if(!biomes.includes(s.biome))fail('unknown biome');
    object(s.spawn,['x','y'],'spawn');number(s.spawn.x,0,s.width-16,'spawn.x');number(s.spawn.y,32,208-32,'spawn.y');
    if(!Array.isArray(s.requires)||s.requires.some(x=>!capabilities.includes(x))||new Set(s.requires).size!==s.requires.length)fail('unknown/duplicate required capability');
    const ids=new Set();const list=(key,max)=>{if(!Array.isArray(s[key])||s[key].length>max)fail(key+' invalid list');return s[key];};
    const unique=(r)=>{if(!idRE.test(r.id||'')||ids.has(r.id))fail('duplicate/invalid object ID '+r.id);ids.add(r.id);};
    for(const r of list('surfaces',600)){object(r,['id','type','x','y','w','h'],'surface');unique(r);rect(r,s.width,'surface');if(!kinds.includes(r.type)||r.y<40)fail('unsupported surface');}
    if(!s.surfaces.length)fail('empty terrain');
    const box={...s.spawn,w:16,h:32};
    const overlap=(a,b)=>a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y;
    if(s.surfaces.some(r=>r.type!=='tree'&&overlap(r,box)))fail('spawn intersects solid');
    if(!s.surfaces.some(r=>box.x+box.w>r.x&&box.x<r.x+r.w&&Math.abs(r.y-(box.y+box.h))<1))fail('spawn needs supporting surface');
    for(const r of list('enemies',80)){object(r,['id','kind','x','surface'],'enemy');unique(r);if(!enemies.includes(r.kind))fail('unsupported enemy '+r.kind);number(r.x,0,s.width-32,'enemy.x');if(!s.surfaces.some(q=>q.id===r.surface))fail('enemy support missing');}
    for(const r of list('coins',300)){object(r,['id','x','y'],'coin');unique(r);number(r.x,0,s.width-12,'coin.x');number(r.y,32,218,'coin.y');}
    for(const r of list('checkpoints',32)){object(r,['id','x','y','w','h','spawn'],'checkpoint');unique(r);rect(r,s.width,'checkpoint');object(r.spawn,['x','y'],'checkpoint spawn');number(r.spawn.x,0,s.width-16,'checkpoint spawn.x');number(r.spawn.y,32,176,'checkpoint spawn.y');const b={...r.spawn,w:16,h:32};if(s.surfaces.some(q=>q.type!=='tree'&&overlap(q,b))||!s.surfaces.some(q=>b.x+b.w>q.x&&b.x<q.x+q.w&&Math.abs(q.y-b.y-b.h)<1))fail('unsafe checkpoint spawn');}
    for(const r of list('hazards',80)){object(r,['id','x','y','w','h','damage'],'hazard');unique(r);rect(r,s.width,'hazard');number(r.damage,1,1000,'damage');}
    for(const r of list('exits',16)){object(r,['id','type','x','y','w','h','target','reward'],'exit');unique(r);rect(r,s.width,'exit');if(!['complete','portal','return'].includes(r.type))fail('unsupported exit type');if(r.type==='portal'){if(!idRE.test(r.target||''))fail('portal target missing');}else if(r.target!==undefined)fail('target only allowed on portal');if(r.reward!==undefined){if(r.type!=='complete')fail('reward only on completion');object(r.reward,['coins','score'],'reward');number(r.reward.coins,0,9999,'reward.coins');number(r.reward.score,0,999999,'reward.score');}}
    if(!s.exits.length)fail('chapter must have an exit');
    return JSON.parse(JSON.stringify(s));
  }
  function registry(entries) {
    if(!Array.isArray(entries)||entries.length>100)fail('invalid registry');const map=new Map();
    for(const raw of entries){const s=validate(raw);if(map.has(s.id))fail('duplicate chapter ID');map.set(s.id,s);}
    for(const s of map.values())for(const e of s.exits)if(e.type==='portal'&&!map.has(e.target))fail('unresolved portal '+s.id+' -> '+e.target);
    for(const s of map.values())if(s.after&&s.after!=='legacy-13'&&!map.has(s.after))fail('unresolved predecessor '+s.after);
    for(const s of map.values()){const seen=new Set();let q=s;while(q?.after&&q.after!=='legacy-13'){if(seen.has(q.id))fail('predecessor cycle');seen.add(q.id);q=map.get(q.after);}}
    return map;
  }
  return Object.freeze({validate,registry,capabilities:Object.freeze(capabilities),profile:'terra-surface-v1'});
}
