/** Compile the public chapter format into the existing Terraria terrain shape. */
export function compileChapterMap(spec) {
  const far=spec.width+2048;
  return {
    width:spec.width,floor:208,time:spec.time,
    surfaces:spec.surfaces.map(s=>({...s,solid:s.type!=='tree',oneWay:s.type==='tree'})),
    movers:[],enemies:[],coins:spec.coins.map(c=>({...c,w:10,h:14,taken:false})),clouds:[],
    reward:{id:'sdk-unused-reward',type:'reward',x:far,y:208,w:16,h:16,solid:true,used:true,bump:0},
    flag:{x:far,top:40,bottom:192},castle:{x:far+72,doorX:far+112,doorY:208}
  };
}
