/** Explicit portable session fields. Never copies position, world arrays or timers. */
export function createChapterProgress() {
  const scalar=['hp','maxHp','lives','score','coins','wood','mana','maxMana','ammo','manaPotions','healPotions'];
  const bools=['cloudJump','mountOwned','slimeOwned','ufoOwned','t13WeaponOverride','t24SummonActive'];
  const strings=['kit','mountType','t13Weapon','t21Axe'];
  const arrays=['t13Owned','t21OwnedAccessories'];
  function validate(data) {
    if(!data||data.schemaVersion!==1||!data.values||Array.isArray(data.values))throw Error('Unsupported progress snapshot');
    const v=data.values,out={};
    for(const k of Object.keys(v))if(![...scalar,...bools,...strings,...arrays,'t13Inventory','t13Accessories'].includes(k))throw Error('Unknown progress field '+k);
    for(const k of scalar)if(v[k]!==undefined){if(!Number.isFinite(v[k])||v[k]<0||v[k]>1e9)throw Error('Invalid progress '+k);out[k]=v[k];}
    for(const k of bools)if(v[k]!==undefined){if(typeof v[k]!=='boolean')throw Error('Invalid progress '+k);out[k]=v[k];}
    for(const k of strings)if(v[k]!==undefined){if(v[k]!==null&&(typeof v[k]!=='string'||!(/^[a-zA-Z0-9_-]{1,64}$/).test(v[k])))throw Error('Invalid progress '+k);out[k]=v[k];}
    for(const k of arrays)if(v[k]!==undefined){if(!Array.isArray(v[k])||v[k].length>100||v[k].some(x=>typeof x!=='string'||!/^[a-zA-Z0-9_-]{1,64}$/.test(x)))throw Error('Invalid progress '+k);out[k]=[...new Set(v[k])];}
    for(const k of ['t13Inventory','t13Accessories'])if(v[k]!==undefined){if(!v[k]||typeof v[k]!=='object'||Array.isArray(v[k])||Object.keys(v[k]).length>100)throw Error('Invalid inventory');out[k]={};for(const [name,n]of Object.entries(v[k])){if(!/^[a-zA-Z0-9_-]{1,64}$/.test(name)||['__proto__','constructor','prototype'].includes(name))throw Error('Invalid item key');if(k==='t13Inventory'?(!Number.isFinite(n)||n<0||n>1e9):typeof n!=='boolean')throw Error('Invalid item value');out[k][name]=n;}}
    if(out.hp!==undefined&&out.maxHp!==undefined&&out.hp>out.maxHp)throw Error('HP exceeds maxHP');
    return {schemaVersion:1,values:out};
  }
  function capture(state){const values={};for(const k of [...scalar,...bools,...strings,...arrays,'t13Inventory','t13Accessories'])if(state[k]!==undefined)values[k]=state[k];return validate({schemaVersion:1,values});}
  function apply(state,snapshot){const clean=validate(snapshot);for(const [k,v]of Object.entries(clean.values))state[k]=v&&typeof v==='object'?JSON.parse(JSON.stringify(v)):v;state.mounted=false;state.p.cloudAvailable=!!state.cloudJump;return state;}
  return Object.freeze({capture,apply,validate});
}
