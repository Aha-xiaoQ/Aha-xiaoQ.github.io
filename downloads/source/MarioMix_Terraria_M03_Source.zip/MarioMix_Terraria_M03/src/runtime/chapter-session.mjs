/** Chapter handoff uses a host adapter; gameplay/camera/DOM stay outside this module.
 * One in-memory play session. No claimed durable cross-version save or code sandbox.
 */
export function createChapterSession({registry,adapter,progress}) {
  let current=null,origin=null,busy=false,phase='idle',elapsed=0,disposed=false;
  const visits=new Map(),awarded=new Set(),events=[];
  const record=(type,data={})=>{events.push({type,...data});if(events.length>200)events.shift();};
  const need=()=>{if(disposed)throw Error('Chapter session disposed');if(busy)throw Error('Reentrant chapter transition');};
  function enter(id,{fresh=false}={}) {
    need();const spec=registry.get(id);if(!spec)throw Error('Unknown chapter '+id);
    if(!adapter.canEnter())throw Error('Cannot switch during hidden room, settings, transition or death');
    busy=true;
    const before=adapter.capture(),old={current,origin,phase,elapsed};let next,stopped=false;
    try {
      const portable=progress.capture(before.state);
      // Prepare before stopping the current level. A rejected definition leaves it playable.
      next=!fresh&&visits.has(id)?visits.get(id):adapter.prepare(spec);
      progress.apply(next,portable);
      stopped=true;adapter.stop();
      adapter.activate(next,spec);
      if(!origin)origin=before;
      if(current)visits.set(current.id,before.state);
      current=spec;phase='playing';elapsed=0;record('enter',{id});
      return snapshot();
    } catch(error) {
      ({current,origin,phase,elapsed}=old);
      if(stopped)try{adapter.restore(before);}catch(recovery){throw new AggregateError([error,recovery],'Chapter transition and recovery failed');}
      throw error;
    } finally {busy=false;}
  }

  function complete(exit) {
    need();if(!current||phase!=='playing')return false;
    const valid=current.exits.find(e=>e.id===exit.id&&e.type==='complete');if(!valid)throw Error('Completion is not registered');
    const key=current.id+'@'+current.revision+':'+valid.id;
    if(!awarded.has(key)){adapter.reward(valid.reward||{coins:0,score:0});awarded.add(key);}
    phase='complete';adapter.completed(current);record('complete',{id:current.id});return true;
  }
  function back({force=false}={}) {
    need();if(!origin)return false;if(!force&&adapter.canReturn?.()===false)throw Error('Cannot return during death or transition');busy=true;
    const before=adapter.capture(),target=origin,originalProgress=progress.capture(target.state);let stopped=false;
    try{
      const p=progress.capture(before.state);stopped=true;adapter.stop();progress.apply(target.state,p);
      adapter.restore(target);
      if(current)visits.set(current.id,before.state);
      origin=null;current=null;phase='idle';elapsed=0;record('return');return true;
    }catch(error){
      progress.apply(target.state,originalProgress);
      if(stopped)try{adapter.restore(before);}catch(recovery){throw new AggregateError([error,recovery],'Return and recovery failed');}
      throw error;
    }finally{busy=false;}
  }
  function restart(){if(!current)return false;return enter(current.id,{fresh:true});}
  function cancel(){if(origin)back({force:true});visits.clear();awarded.clear();record('session-cleared');}
  function tick(input={}) {
    if(!current||phase!=='playing'||!adapter.isPlaying())return;elapsed++;
    const state=adapter.capture().state,p=state.p;
    const hit=r=>p.x<r.x+r.w&&p.x+p.w>r.x&&p.y<r.y+r.h&&p.y+p.h>r.y;
    for(const h of current.hazards)if(hit(h))adapter.damage(h.damage);
    if(!adapter.isPlaying())return;
    for(const c of current.checkpoints)if(hit(c)&&state.chapterCheckpoint!==c.id){adapter.checkpoint(c);record('checkpoint',{id:c.id});}
    // Entry debounce prevents portal bounce; interaction is an edge, not a held key.
    if(elapsed<20)return;
    for(const e of current.exits)if(hit(e)){
      if(e.type==='complete'){complete(e);return;}
      if(input.auxEdge){if(e.type==='return')back();else enter(e.target);return;}
    }
  }
  function snapshot(){return {apiVersion:1,current:current?.id||'legacy-13',phase,elapsed,visited:[...visits.keys()],awarded:[...awarded],events:events.map(e=>({...e})),canReturn:!!origin};}
  return Object.freeze({enter,back,restart,cancel,tick,complete,snapshot,spec:()=>current,dispose(){if(disposed)return;cancel();disposed=true;}});
}
