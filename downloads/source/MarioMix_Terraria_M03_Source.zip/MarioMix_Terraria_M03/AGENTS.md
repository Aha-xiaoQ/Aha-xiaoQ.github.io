# 第三期协作工程 · 当前 M03

先读 START_HERE.md、docs/HANDOFF_M03.md、docs/TEST_REPORT_M03.md、docs/sdk/CAPABILITIES.md 和 architecture/modules.json。只以 baseline.json 指向的第三期上传底稿迁移；不引入城堡/R29、不覆盖网站或旧游戏发布文件。

M03 的验收单位是“独立作者只新增关卡目录，能在真实候选中运行并返回原主线”。不是模块总数或文档页数。

19 个独立模块，33 个兼容片段，bindings 和 chapters 两个受控桥接。不要将 compat 称为已完全解耦。M03 的一个 step 包装已在 ADR 和预算中登记；关卡作者不能添加包装链。

公开描述必须区分 terra-surface-v1 已支持能力与待实现服务。所有现有 1-3 行为先保持，对照测试与新增关卡测试分开。未实际跑的测试、设备、GitHub CI 和自然通关不能写通过。

提交前：level:check、verify、docs:build、浏览器三组按可用环境执行、源码 ZIP 真正解压再验证。文档和状态一起交付。包不得附带字体、凭据或未经审查的新素材。
