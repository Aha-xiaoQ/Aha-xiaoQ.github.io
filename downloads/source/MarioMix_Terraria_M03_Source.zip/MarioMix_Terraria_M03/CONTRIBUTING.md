# 贡献指南

欢迎提交一个边界清晰、能够复现的修改。会运行游戏并理解自己修改的代码，比一次提交很多功能更重要。

## 第一个关卡 PR

从最新维护分支运行 `npm run verify`，再用 `npm run level:new -- --id my-14 --title "我的 1-4"` 创建目录。只增加 levels/my-14，不修改运行时、构建器或默认 1-3 地图。先保持 draft=true，依据 docs/sdk/ADD_LEVEL.md 完成一次完整体验。试玩通过后提交目录、验收记录和截图；截图不能替代代码或测试。

存在多个同类关卡时，不要把个人名字硬编码进公共函数。要新增 Boss、动作或媒体包，先说明现有能力哪里不够，再针对一个公共接口开独立 PR。接口变更与关卡内容 PR 分开。

## 验证与合并

```sh
npm run level:check
npm run verify
# 已安装 Python Playwright 和 Chromium 时：
npm run test:browser
npm run test:settings-browser
npm run test:chapters-browser
```

浏览器脚本目前为离线完整游戏测试，手柄与部分流程条件是可控样例，不代表真实设备或自然通关。不能运行的检查写明原因。现有 1-3 的行为改变须另列，不能藏在结构改动中。

PR 需包含：改动类型、支持 profile、涉及模块、测试命令与结果、候选 SHA、尚未验证部分、资源来源及许可依据。一个 PR 尽量只改一种职责；AI 辅助代码也必须解释和测试。

maintainer 审阅代码及资源，验证 Windows/浏览器/设备后决定合并和发布。CODEOWNERS 是审核路由，不是文件夹访问隔离。Issue/PR 的链接只有真实创建后才写入；此工程不自动创建远端对象。

## 三个边界

- 已发布的前两期、线上第三期、未完成的城堡分支不覆盖。
- 不编辑 dist、SOURCE_SHA256SUMS.txt 或 docs/generated/MODULES.md；使用对应构建命令。
- 原始资产和源代码不是因为放进源码 ZIP 就自动获得宽松许可。沿用 upstream/NOTICE.txt 与 docs/RESOURCES.md 的限制。

后续任务源：docs/TASKS.json。认领前说明范围，等待维护者确认；命令行查看任务不等于认领。
