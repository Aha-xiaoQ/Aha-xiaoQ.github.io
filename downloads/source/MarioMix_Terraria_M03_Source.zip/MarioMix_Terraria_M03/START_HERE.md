# M03 · 从第三期进入可扩展的关卡工程

本工程以上传的 mario-mix-3.zip 为唯一底稿。M01、M02 的历史在 docs 中保留；以本页、docs/HANDOFF_M03.md 和 docs/sdk/ 为当前阅读入口。

## 你是关卡开发者

1. 阅读 docs/sdk/CAPABILITIES.md，确认新关卡使用已支持的规则。尤其不要把旋转重力、全新 Boss 或在线联机当成现成能力。
2. 执行 `npm run verify`，先确认原工程通过。
3. `npm run level:new -- --id my-14 --title "我的 1-4"`。
4. 只修改 levels/my-14/chapter.json；执行 `npm run level:check`。
5. `npm run dev`，打开 `http://127.0.0.1:4193/play.html?chapter=my-14`。
6. 按 levels/my-14/acceptance.json 和 docs/sdk/ACCEPTANCE.md 检查；带着关卡目录和实际测试说明提交小 PR。

草稿不会出现在普通主线的“下一关”。预览可用 `?chapters=1` 打开接入工作台，或者 `?chapter=id` 直接进入。正式接入仍需审阅；将 draft 改为 false 不是获得发布批准。

## 你是框架维护者

阅读 CONTRIBUTING.md → docs/ARCHITECTURE.md → docs/generated/MODULES.md → docs/sdk/LIFECYCLE.md → docs/TEST_REPORT_M03.md。关卡数据校验、地图转换、便携状态和关卡会话分别在独立模块；只有 src/bridges/chapters.bridge.js 可以接触剩余旧状态。不要让关卡作者复制此桥接或自行包裹 step/render。

## 运行与构建

Node.js 22+，无第三方 npm 依赖，不需 npm install。

```sh
npm run verify
npm run level:list
npm run dev
# 另一终端：
npm run reference
```

候选端口4193，原版对照4194。修改源码或关卡后重启 dev、刷新浏览器；尚未实现热更新。dist/play.html 是 HTTP 模块入口，dist/MarioMix_Terraria_M03.html 是单文件候选，dist/reference.html 是原底稿逐字节重建。

```sh
npm run tasks -- --task M03-FIRST-LEVEL
npm run handoff
npm run pack
```

源码 ZIP 在 .local/MarioMix_Terraria_M03_Source.zip。dist、.local、个人存档、凭据不能进入 PR。原字体文件不在源码包内；运行时仍有原可选远程资源，不声称资源完全离线。

网站更新包为 R11，源码工程为 M03。两套编号不是关卡编号。
