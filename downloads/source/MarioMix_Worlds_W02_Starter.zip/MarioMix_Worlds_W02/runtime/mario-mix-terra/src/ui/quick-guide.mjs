/** Read-only help content. Bindings are supplied by the same model used by gameplay. */
export function buildQuickGuide({bindings, device = 'keyboard', keyLabel, padLabel}) {
  const actions = bindings?.actions || {};
  const label = id => {
    const values = actions[id]?.[device === 'gamepad' ? 'pad' : 'keys'];
    if (!Array.isArray(values) || !values.length) return '未绑定';
    const format = device === 'gamepad' ? padLabel : keyLabel;
    return values.slice(0, 2).map(value => String(format(value))).join(' / ');
  };
  const rows = [
    {id:'move', title:'先走几步', keys:`${label('left')} · ${label('right')}`, text:device === 'gamepad' ? '使用十字键或左摇杆移动。' : '向左右移动，先找到舒服的节奏。'},
    {id:'jump', title:'跨过平台', keys:label('jump'), text:'跳过缺口，落地后再继续前进。'},
    {id:'tool', title:'选择并使用工具', keys:`${label('toolPrev')} · ${label('toolNext')} → ${label('attack')}`, text:device === 'gamepad' ? '切换快捷栏后按使用键；手柄会自动索敌。' : '切换快捷栏后按使用键；鼠标用于瞄准或选格。'},
    {id:'interact', title:'探索地下', keys:label('interact'), text:'站到可进入的管道口，按交互键进入。返回时也要靠近出口。'},
    {id:'mount', title:'切换坐骑状态', keys:label('mount'), text:'获得坐骑后，可骑乘或下来。'},
    {id:'pause', title:'随时停一停', keys:label('pause'), text:'暂停后再查看设置或离开页面。返回时手动继续。'}
  ];
  return rows.map(row => Object.freeze({...row}));
}

/** Only explicit, non-personal fields enter a support report; no saved data or file paths. */
export function formatPlayerReport(info = {}) {
  const clean = v => String(v ?? '未提供').replace(/[\r\n\u0000-\u001f]/g, ' ').slice(0, 96);
  return [['开发版本',info.version],['角色',info.character],['场景',info.scene],['状态',info.mode],['输入方式',info.device],['画面尺寸',info.viewport]]
    .map(([label,value]) => `${label}：${clean(value)}`).join('\n') + '\n\n问题发生前的操作：\n预期结果：\n实际结果：\n';
}
