// Browser IO is kept at the existing UI hook. No world/physics wrapper is added.
let terraDisplayStorage;try{terraDisplayStorage=localStorage;}catch{}
const terraDisplayPreferences=__terraModules.createDisplayPreferences({storage:terraDisplayStorage});
const terraPresentationLifetime=()=>__terraModules.createLifetime({scheduleInterval:(fn,ms)=>setInterval(fn,ms),cancelInterval:id=>clearInterval(id)});
const terraAdventureShell=__terraModules.createAdventureShell({document,preferences:terraDisplayPreferences,
 makeLifetime:terraPresentationLifetime,resetInput:()=>t17ResetActions(),focusGame:()=>canvas.focus({preventScroll:true}),getBindings:()=>t21Config(),keyLabel:t21KeyLabel});
const terraAdventureHelp=__terraModules.createAdventureHelp({document,makeLifetime:terraPresentationLifetime,
 getBindings:()=>t21Config(),getMode:()=>mode,togglePause:()=>togglePause(),resetInput:()=>{t17ResetActions();t21Keyboard.clear();},
 focusGame:()=>canvas.focus({preventScroll:true}),storage:terraDisplayStorage,keyLabel:t21KeyLabel,padLabel:t25PadLabel,
 makeGuide:__terraModules.buildQuickGuide,formatReport:__terraModules.formatPlayerReport,
 getContext:()=>({version:'0.4.2',terra:isTrio(),character:hero,scene:state?.r05Arena?'地下挑战':'主场景',mode,device:t20Device,viewport:innerWidth+' × '+innerHeight}),
 copyText:text=>{if(!navigator.clipboard?.writeText)throw Error('Clipboard unavailable');return navigator.clipboard.writeText(text);}});
t17Early.helpOpen=()=>terraAdventureHelp.snapshot().open;
t17Early.presentation=e=>terraAdventureHelp.handleKey(e)||terraAdventureShell.handleKey(e);
// A persisted page is frozen for back/forward cache, not destroyed. Keep its listeners.
window.addEventListener('pagehide',e=>{terraAdventureHelp.suspend();if(!e.persisted){terraAdventureHelp.dispose();terraAdventureShell.dispose();}});
if(document.documentElement.dataset.test==='1'){window.__terraPresentationTest=terraAdventureShell;window.__terraHelpTest=terraAdventureHelp;}
