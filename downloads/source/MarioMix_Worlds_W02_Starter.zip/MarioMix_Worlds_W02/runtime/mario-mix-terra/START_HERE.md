# 第三期开发源码 · 0.4.2

这是第三期泰拉瑞亚的模块化开发候选。源码包含构建、测试、当前指南和历史记录；关卡扩展仍是实验功能。

## 运行

使用 Node.js 22 或以上。在本目录运行，无需 npm install：

```sh
npm run verify
npm run prepublish:check
npm run dev
```

普通试玩：http://127.0.0.1:4193/play.html

关卡试验：http://127.0.0.1:4193/play.html?dev=1

原版对照：另一个终端运行 `npm run reference`，访问 http://127.0.0.1:4194/ 。

修改 src 后重新启动开发服务并刷新，不编辑 dist。发行 HTML 是构建产物；可以从同一源码生成单文件和模块入口。

## 从哪里开始

- `CONTRIBUTING.md`：选择任务、测试、提交 PR。
- `docs/generated/MODULES.md`：职责、依赖与测试。
- `docs/QUICK_HELP_M06.md`：操作速查与反馈说明。
- `docs/KNOWN_LIMITS.md`：实验功能及未完成验收。
- `docs/ACCEPTANCE_M06.md`：发布前实机检查。
- `docs/HANDOFF_M06.md`：当前改动与后续工作。

`prepublish:check` 只检查自动产物，不批准发布。`release:check` 需要维护者记录确切候选及人工验收。在线稳定试玩不由本工程自动覆盖。
