# 第三期协作版 M04 · 从这里开始

**当前版本：0.4.0 / M04，发布候选。** 这是基于指定第三期下载包的协作源码，不是新关卡，不替换线上游戏。尚未完成的城堡关不在范围内。

## 三条命令开始

需要 Node.js 22+，无第三方 npm 依赖，无需 npm install。

```sh
npm run verify
npm run dev
# 浏览器 http://127.0.0.1:4193/play.html
```

另一个终端 `npm run reference`：4194 原底稿对照。`npm run pack` 生成 `.local/MarioMix_Terraria_M04_Source.zip`。修改 `src/` 或 `content/` 后重启服务；不要修改 `dist/`。

关卡试验场仅在 `play.html?dev=1` 出现，避免把几何开发样例当成正式游戏。它的 platform-v1 是实验驱动；旧泰拉角色仍限于既有第三期。

## 开始贡献

[贡献流程](CONTRIBUTING.md) → [模块地图](docs/generated/MODULES.md) → [接口说明](docs/ARCHITECTURE.md)。

改一个模块，补它的测试；不改无关地图、平衡或品牌样式。新增关卡先读 [能力边界](docs/KNOWN_LIMITS.md) 和 [关卡教程](docs/stages/ADD_LEVEL.md)。

## 发布者

运行 `npm run prepublish:check` 检查版本、构建和文档一致性。运行 `npm run release:check` 检查人工证据；默认会拒绝，因为真实设备、素材与维护者审批不能由构建代签。参见 [发布清单](docs/PUBLISH.md)。

本轮记录：[M04变更](docs/CHANGELOG_M04.md) · [测试](docs/TEST_REPORT_M04.md) · [交接](docs/HANDOFF_M04.md)。`release.json` 是当前版本元数据；M01—M03 文档为历史，不应当作新的启动入口。
