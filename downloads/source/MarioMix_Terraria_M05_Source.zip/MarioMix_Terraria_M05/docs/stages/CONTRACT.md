# 地图、角色、关卡与适配层契约 v0.1

这是本项目的小型内部JSON格式，**不是Tiled完整JSON格式**。字段由 src/content/stage-catalog.mjs 严格校验，未知字段拒绝。目录自动发现，`目录名 === id`，用稳定的小写短横线 ID，不能用路径穿越。

| 清单 | 职责 | 当前格式 |
|---|---|---|
| maps/<id>/map.json | 几何、出生点、机关对象、来源 | 像素坐标，tileSize=16，geometry与objects分开 |
| characters/<id>/character.json | 能力、原型物理参数、几何造型、音频选择 | driver明确；只支持列出的capabilities |
| audio/<id>/audio.json | 逻辑声音→现有音频key | music与事件jump/attack/pickup/hurt/death/checkpoint/complete/portal |
| stages/<id>/stage.json | 房间连接、允许角色、入口、角色适配 | rooms、entryRoom/Spawn、characters、requiredCapabilities、overlays |

## 地图

geometry项：`id,x,y,w,h,collision`，collision取solid或oneway；可选motion为`axis,min,max,speed`，均为像素/每固定步。对象为spawn/checkpoint/portal/exit/coin/hazard/walker，必须有非零矩形尺寸。portal填写targetRoom/targetSpawn；checkpoint只填写本房targetSpawn。所有目标需存在，所有房间需能沿门图从入口到达。该检查只验证拓扑，不证明玩家真能跳过去。

对象层跟随当前驱动能力。没有实现的 firebar、bowser、wall-climb 等会报错；不能静默忽略后标为可玩。普通walker是几何原型敌人，不是原马里奥怪物逐帧实现。

## 基础地图与角色适配

底图是唯一事实源。`overlays.<角色ID>.rooms.<房间ID>.geometry`只能添加唯一ID的新几何，不允许替换/删除原对象。基础几何另存在plan.baseGeometry，plan深度冻结。适配层只为能力差别补路线，不用“优化”掩盖底图改动。

同一张底图可以被多个关卡方案引用。基础修订需单独版本和证据。带provenance.review=verified的标记只是提交者声明，不是系统授予许可；原版复刻须人工审核。

## 角色/音频

platform-v1仅支持jump,double-jump,attack,platform-drop；图形shape是runner或scout。旧第三期角色使用legacy-terra-v1，参数和外观为null；驱动不同的组合直接拦截，不能把角色名字改一下伪装成已迁移。

音频只引用已存在音频key，不新增音频二进制；找不到的key静音容错，审阅需核对对应资源。示例复用原底稿音乐，不表示它得到额外授权。没有做原作全角色音色资源库。

## 生命周期

start→running↔paused→complete/stop。完成事件一次，退出释放会话资源并忽略过期回调；创建失败不留下半活动场景。切换前先验证内容；创建新场景自身失败时进入安全空闲态，不保证回滚旧场景。房间内一次性拾取在本次会话保留，跨关磁盘存档未实现。


## M04补充
使用 `play.html?dev=1` 打开实验入口。legacy-terra-v1只允许原第三期固定组合，不能自定义地图；音效键需存在于游戏音频清单。当前协议仍是实验接口，不把几何角色当作真实泰拉actor。
