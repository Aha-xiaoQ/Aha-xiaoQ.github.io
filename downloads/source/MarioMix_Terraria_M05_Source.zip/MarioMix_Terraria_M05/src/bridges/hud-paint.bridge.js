// M05: same view model and hit geometry; only the canvas painter changes.
function t15DrawHUD(s){if(!isTrio()||!s||mode==='menu')return;
 const l=t15Layout(s),m=t15Model(s);
 __terraModules.paintAdventureHud({context:ctx,layout:l,model:m,
  actor:{x:s.p.x+s.p.w/2-(s.cam||0),y:s.p.y-(s.r05Arena?s.camY||0:s.r07CamY||0)},
  boss:s.phase==='battle'&&s.eye&&!s.eye.dead?s.eye:null,icon:t15Icon,text:t15Text,
  coin:ready?classicSprite('coin0'):null,highContrast:document.body.dataset.terraContrast==='high'});
 s.t15Hud={hp:m.hp,maxHp:m.maxHp,mana:m.mana,maxMana:m.maxMana,gear:m.gear.map(x=>x.name),tool:m.tool,weapon:m.weapon,rows:2,view:[l.viewW,l.viewH]};
}
