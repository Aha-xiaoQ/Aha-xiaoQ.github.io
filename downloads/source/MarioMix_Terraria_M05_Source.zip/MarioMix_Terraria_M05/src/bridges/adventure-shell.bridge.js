// All browser IO stays here; presentation modules cannot alter the simulation.
let terraDisplayStorage;try{terraDisplayStorage=localStorage;}catch{}
const terraDisplayPreferences=__terraModules.createDisplayPreferences({storage:terraDisplayStorage});
const terraAdventureShell=__terraModules.createAdventureShell({document,preferences:terraDisplayPreferences,
 makeLifetime:()=>__terraModules.createLifetime({scheduleInterval:(fn,ms)=>setInterval(fn,ms),cancelInterval:id=>clearInterval(id)}),
 resetInput:()=>t17ResetActions(),focusGame:()=>canvas.focus({preventScroll:true}),getBindings:()=>t21Config(),keyLabel:t21KeyLabel});
t17Early.presentation=e=>terraAdventureShell.handleKey(e);
window.addEventListener('pagehide',()=>terraAdventureShell.dispose(),{once:true});
if(document.documentElement.dataset.test==='1')window.__terraPresentationTest=terraAdventureShell;
