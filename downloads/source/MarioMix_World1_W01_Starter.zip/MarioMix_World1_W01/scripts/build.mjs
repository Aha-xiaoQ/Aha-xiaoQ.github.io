import fs from 'node:fs';import path from 'node:path';import {fileURLToPath}from'node:url';import{createHash}from'node:crypto';
import{safe,readOptional,writeAtomic}from'./lib/safe-path.mjs';
import{compileWorld,extensionFiles,previewAudio}from'../src/compiler.mjs';import{validateCatalog,publicProjection}from'../src/catalog.mjs';import{mapSVG}from'../src/map-svg.mjs';import{zip}from'./lib/zip.mjs';
export const ROOT=path.dirname(path.dirname(fileURLToPath(import.meta.url))),hash=b=>createHash('sha256').update(b).digest('hex'),json=x=>Buffer.from(JSON.stringify(x,null,2)+'\n');
export function plan(root=ROOT){
 const reference=JSON.parse(readOptional(root,'reference/first-world.json')),catalog=validateCatalog(JSON.parse(readOptional(root,'content/catalog.json'))),out=new Map(),worlds=[];
 for(const l of catalog.levels.filter(l=>l.template.status==='reference-draft')){
  const w=compileWorld(reference,l.id);worlds.push(w);const files=new Map();
  files.set('template.json',json(w));files.set('coverage.json',json(w.coverage));files.set('reference.json',json({...reference.source,map:reference.maps.find(m=>m.name===l.id)}));files.set('LICENSE-reference.txt',readOptional(root,'reference/LICENSE-MIT.txt'));files.set('NOTICE.md',readOptional(root,'NOTICE.md'));
  files.set('README.md',Buffer.from(`# ${l.id} 地图模板\n\n基础几何来自第一世界社区参考数据，粉色标记对应待实现机制。模板不是已完成的同人关卡，也不是官方地图导出。\n\n内容：template.json 为含标记的完整模板；extension/ 为 M06 platform-v1 数据；area-*.svg 为坐标预览；coverage.json 为机制缺口。\n\n预览：解压完整 World1 Starter 后运行 npm run dev，访问终端打印的 play.html?dev=1，选择 ${w.stage.title} 并开启开发草稿。独立小模板 ZIP 不含游戏运行时。\n\n待实现：${w.coverage.pending.join('、')}。\n`));
  for(const[p,x]of extensionFiles(w))files.set('extension/'+p,json(x));
  files.set('extension/content/extensions/audio/map-kit-silent/audio.json',json(previewAudio()));
  for(const r of w.rooms)files.set(r.roomId+'.svg',Buffer.from(mapSVG(r)));
  for(const[p,b]of files)out.set(`generated/levels/${l.id}/${p}`,b);
  out.set(`generated/downloads/MarioMix_Map_${l.id}_W01.zip`,zip([...files].map(([p,b])=>[`MarioMix_Map_${l.id}/`+p,b])));
 }
 out.set('generated/catalog-public.json',json(publicProjection(catalog)));
 out.set('generated/coverage.json',json(worlds.map(w=>({level:w.level,...w.coverage}))));
 const manifest={schemaVersion:1,files:Object.fromEntries([...out].map(([p,b])=>[p,hash(b)]))};out.set('generated/manifest.json',json(manifest));return{out,worlds,catalog};
}
export function build(root=ROOT,{check=false}={}){
 const {out,worlds}=plan(root),prev=JSON.parse(readOptional(root,'generated/manifest.json')||'{"files":{}}'),changes=[];
 for(const p of Object.keys(prev.files))if(!p.startsWith('generated/')||p==='generated/manifest.json')throw Error('Invalid generation manifest');else if(!out.has(p))throw Error('Obsolete output requires explicit migration: '+p);
 for(const[p,b]of out){const old=readOptional(root,p);if(old?.equals(b))continue;if(old&&p!=='generated/manifest.json'&&(!prev.files[p]||hash(old)!==prev.files[p]))throw Error('Generated output edited: '+p);changes.push([p,b,old]);}
 if(check&&changes.length)throw Error('Template outputs stale; run npm run build');
 if(!check){for(const[p,,old]of changes){const now=readOptional(root,p);if((now===null)!==(old===null)||(now&&!now.equals(old)))throw Error('Concurrent modification');}for(const[p,b]of changes)writeAtomic(root,p,b);}
 return{levels:worlds.length,rooms:worlds.reduce((n,w)=>n+w.maps.length,0),files:out.size,changed:changes.length};
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){try{console.log(build(ROOT,{check:process.argv.includes('--check')}));}catch(e){console.error(e.message);process.exitCode=1;}}
