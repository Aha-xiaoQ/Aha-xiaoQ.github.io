# MarioMix WorldKit W01

第一世界地图模板、关卡进度和独立适配工具。

[从这里开始](START_HERE.md) · [地图契约](docs/MAP_CONTRACT.md) · [贡献指南](CONTRIBUTING.md) · [当前缺口](docs/ROADMAP.md)

**参考地图转录稿，不是原版完整复刻或完成的奥日关卡。** 8 个区域，4 个可下载底图；其他 28 关尚无地图。
