# 第一世界地图开发包 · W01

当前：WorldKit 0.1.0。配套运行时：第三期 Terraria M06 / 0.4.2。

## 先了解范围

1-1 魂斗罗·比尔 / 洛克人、1-2 忍者龙剑传 / 坦克大战、1-3 泰拉瑞亚已有独立试玩；1-4 奥日仍在开发。这里的四份底图是**社区参考地图的转录稿**，不是这四个角色玩法的再次发布。1-4 底图不是奥日城堡成品。

四份底图包含八个区域、地形、房间入口、部分运动平台和对象标记。敌人、可顶破砖块、道具成长、循环电梯、火焰棒、Boss、桥斧结算尚未全部实现。查看各图 `coverage.json`；没有原版 ROM 对照验收。后续 28 关仅登记计划。

## 运行

需要 Node.js 22 或更新版本，无需 npm install。在本目录运行：

```sh
npm run check
npm test
npm run dev
```

完整 Starter 已带 `runtime/mario-mix-terra`。网站仓库则使用相邻的 `packages/mario-mix-terra`。也可以指定：

```sh
npm run dev -- --game "D:/Projects/mario-mix-terra"
```

打开 `http://127.0.0.1:4195/play.html?dev=1`，点击“开发工具 · 关卡试验场”，勾选“显示开发草稿”，选择 1-1 至 1-4。两种实验角色用于路线预览，不是马里奥或完整泰拉角色。模板静音，使用原型碰撞和运动时序。运行命令只在本包 `.local/` 创建候选，不改配套游戏源码。

## 开始一个适配方案

```sh
npm run new -- --base 1-4 --id my-stage --title "我的关卡" --apply
npm run dev
```

编辑 `content/adaptations/my-stage.json`。额外平台写入 `overlays`；参考底图不动。每次修改后重启服务并刷新。需要新的角色或机关时，先在对应运行时模块实现并测试，配置中的能力名称不会自动产生实现。

## 文件位置

|用途|位置|
|---|---|
|关卡进度、角色、负责人、Issue|`content/catalog.json`|
|不可随适配改写的转录底图|`reference/first-world.json`|
|模板转换规则|`src/compiler.mjs`|
|角色路线适配|`content/adaptations/`|
|生成结果、逐关模板 ZIP|`generated/`|
|运行副本|`.local/`（不提交）|
|坐标与保真范围|`docs/MAP_CONTRACT.md`|
|任务与验收|`docs/ROADMAP.md`、`docs/ACCEPTANCE.md`|

提交 PR 前运行 `npm run build`、`npm run check`、`npm test`，附地图/房间、角色、操作和结果。网站内更新目录后运行 `npm run worlds:sync`、`npm run journal:build`。授权说明见 `NOTICE.md`，第三期原声明在配套运行时中保留。
