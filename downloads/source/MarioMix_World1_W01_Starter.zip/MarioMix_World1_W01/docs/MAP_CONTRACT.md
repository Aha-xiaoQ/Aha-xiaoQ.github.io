# 地图坐标、保真与接入契约

## 来源

底图按 `umaim/Mario` 的 `Source/settings/maps.js` 手工转录，固定参考提交 `980c275358704a49f868567aeec5bdfb347c4781`，上游文件 Git blob `657d750ad65bb06c0e63a3d8958736f9236ec3c0`。记录在 reference 文件中。它是社区实现，并非任天堂公开源码。

参考：https://github.com/umaim/Mario/blob/980c275358704a49f868567aeec5bdfb347c4781/Source/settings/maps.js
结构和宏参考：https://github.com/umaim/Mario/blob/980c275358704a49f868567aeec5bdfb347c4781/Source/FullScreenMario.ts

本包不是原文件的逐字节镜像。转录保留第一世界地形/对象记录，剔除纯背景 Pattern、文字及装饰框；额外增加 `widthUnits` 作为预览边界。MIT 文本在 `reference/LICENSE-MIT.txt`，第三方底层素材权利未因该声明而获得确认。

## 坐标

上游 8 单位对应一格，输出为 16 像素一格。`x_out=2*x`；高度坐标朝上，`y_out=208-2*y`。固定预览高度240。Floor 从顶面向下延展，地图外侧截取到预览底部；Brick/Ceiling 按对象大小展开。树干只作参考标记，不因为 `solidTrunk` 就变为可碰撞障碍：上游 scenery 自身带有 nocollide。

房间位置通过 locations 与 transport 对应。数值入口仅连接当前关卡区域；跨世界出口保留标记，不链接到尚未制作的关卡。1-2 循环升降平台仅登记，不伪装成静态走道。

## 已支持的预览

地面、砖、石、管道外形、树顶平台、普通收集币、简单运动平台、熔岩区域、房间连接、实验结束点。平台速度为当前实验驱动参数，不能当成原版时序。

## 保留但未完整执行

敌人行为、隐藏顶砖/物品、成长、循环平台发生器、食人花、旋转火焰棒、Boss、桥斧触发与通关演出。这些对象在 `template.json` 的 markers 与 coverage 中可见；不能把简单标记视作实现。城堡末端的实验结束点不等于原作桥斧机制。

## 文件职责

`reference` 是转录基准；`compiler` 产生平台协议；`content/adaptations` 增加路线，不改基础对象；`content/catalog.json` 登记产品状态，不自动由模板测试推断上线状态。未知 macro/thing 导致构建失败。导出 JSON 不执行任何外部源代码。

使用 M06 的 StageSession、platform-v1 与已有选择器，不换引擎。独立预览只改工作副本内两处标题/帮助文案，保证显示正确的模板关卡；实际第三期源码字节不动。完整泰拉角色、武器、坐骑仍不能任意套用新地图。

地图模板、运行机制、正式角色、原版保真、公开发布是五项独立验收。需要逐项证据；本轮仅完成转录与实验接入，不是全项认证。
