# 模块登记（自动生成）

来源：architecture/modules.json。表中 owner 是审阅职责，不表示已有贡献者认领。注入依赖需结合测试核验；这是登记依赖图，不是动态 JavaScript 的完整分析。

| 模块 | 源码 | 层 | 注入依赖 | 测试 |
|---|---|---|---|---|
| 克苏鲁之眼基础状态机 | `src/simulation/eye-boss.mjs` | simulation | 无模块级依赖 | tests/modules.test.mjs |
| 隐藏场景平台建造 | `src/simulation/platform-builder.mjs` | simulation | 无模块级依赖 | tests/modules.test.mjs |
| 早期逻辑输入 | `src/input/logical-input.mjs` | input | 无模块级依赖 | tests/modules.test.mjs |
| 第三期地图解码 | `src/content/level-13.mjs` | content | 无模块级依赖 | tests/modules.test.mjs |
| 摇杆死区 | `src/input/stick.mjs` | input | 无模块级依赖 | tests/modules.test.mjs |
| 默认动作定义 | `src/content/actions.mjs` | content | 无模块级依赖 | tests/modules.test.mjs |
| 按键名称 | `src/ui/key-label.mjs` | ui | 无模块级依赖 | tests/modules.test.mjs |
| 固定步长时钟 | `src/runtime/fixed-step.mjs` | runtime | 无模块级依赖 | tests/modules.test.mjs |
| 坐骑按键事务 | `src/input/mount-binding.mjs` | input | 无模块级依赖 | tests/settings.test.mjs |
| 配置验证、迁移与绑定 | `src/input/bindings-model.mjs` | input | actions, mount-binding | tests/settings.test.mjs |
| 键盘逻辑映射 | `src/input/keyboard-router.mjs` | input | actions | tests/settings.test.mjs |
| 按键捕获与释放屏障 | `src/input/binding-capture.mjs` | input | 无模块级依赖 | tests/settings.test.mjs |
| 计时器与监听器清理 | `src/runtime/lifetime.mjs` | runtime | 无模块级依赖 | tests/settings.test.mjs |
| 设置窗口会话 | `src/ui/settings-session.mjs` | ui | lifetime | tests/settings.test.mjs |
| 改键表格视图 | `src/ui/bindings-view.mjs` | ui | key-label, lifetime | tests/settings.test.mjs |

33 个 compat 文件仍保留共享闭包；46 文件当前是桥接标记。bindings.bridge.js 也不算独立业务模块。
