# 1-1 地图模板

基础几何来自第一世界社区参考数据，粉色标记对应待实现机制。模板不是已完成的同人关卡，也不是官方地图导出。

内容：template.json 为含标记的完整模板；extension/ 为 M06 platform-v1 数据；area-*.svg 为坐标预览；coverage.json 为机制缺口。

预览：解压完整 World1 Starter 后运行 npm run dev，访问终端打印的 play.html?dev=1，选择 1-1 · 底图预览（实验） 并开启开发草稿。独立小模板 ZIP 不含游戏运行时。

待实现：block-contents、enemy-goomba、enemy-koopa、flagpole-finish、hidden-block。
