# 1-3 · 地图模板 K01

本包包含 M06 platform-v1 扩展数据、各房间结构预览和 Tiled 对象层。
这是本关的数据快照，先解压同版本完整 MarioMix_Levels_K01_Source.zip。以下 --level 命令读取完整工具包中的同版模板，不读取另行编辑的ZIP副本。在该工程运行：

```sh
npm run integrate -- --target "M06源码路径" --level 1-3 --check
npm run integrate -- --target "M06源码路径" --level 1-3 --apply
```

制作自己的关卡时，先运行 npm run fork -- --id my-stage --from 1-3 --apply，再编辑 content/forks/my-stage.json，使用 integrate 的 --file content/forks/my-stage.json 参数导入。不要修改 data/generated 后直接重建。

开发游戏通过 http://127.0.0.1:4193/play.html?dev=1 打开，在接入试验场中勾选开发草稿。
本模板采用原版复刻项目的坐标转录，原版逐格与机关时序待复验；不含正式角色/BGM，不替换已发布关卡。
