"""Replace only six existing stage cards; retain source YUV outside the card.

The old cards are burned in. Their otherwise empty, uniform background is
sampled from the source frame at each stage start, before its fade begins.
Only affected closed-GOP intervals are encoded; all other video is copied.
"""
from pathlib import Path
from functools import lru_cache
import argparse, json, subprocess, hashlib, os
import numpy as np
import cv2
from PIL import Image, ImageDraw, ImageFont

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT.parent/'R9_3_Final/Bad_Apple_Light_Loom_R9_3_Portrait_Final_1080x1440_60fps.mp4'
AUDIO=ROOT/'review/audio/selected_audio.m4a'
FONT=Path(os.environ.get('LOOM_FONT', 'SourceHanSansSC-Normal.otf'))
W,H,FPS,N=1080,1440,60,13230
X,Y,CW,CH=704,738,348,124
SIZE=W*H*3//2
STAGES=[
 (0,'48×36 · 黑白','芯片独奏 · 单声道'),
 (36.5,'96×72 · 黑白','8-bit复音 · 窄立体声'),
 (73,'180×135 · 黑白','电子合奏 · 立体声'),
 (109.5,'360×270 · 灰度','原声 · 窄立体声'),
 (146,'540×405 · 彩色','原声 · 立体声'),
 (182.5,'720×540 · MMD','原声 · 立体声')]

def planes(raw):
 a=np.frombuffer(raw,np.uint8)
 return (a[:W*H].reshape(H,W),a[W*H:W*H*5//4].reshape(H//2,W//2),a[W*H*5//4:].reshape(H//2,W//2))

def patches(raw):
 p=planes(raw)
 return p[0][Y:Y+CH,X:X+CW],p[1][Y//2:(Y+CH)//2,X//2:(X+CW)//2],p[2][Y//2:(Y+CH)//2,X//2:(X+CW)//2]

def one_frame(frame):
 return subprocess.check_output(['ffmpeg','-v','error','-ss',f'{frame/FPS:.12f}','-i',str(BASE),'-frames:v','1','-pix_fmt','yuv420p','-f','rawvideo','-'])

@lru_cache(None)
def clean_background(i):
 # The original cue's alpha is exactly zero on this frame.
 p=patches(one_frame(round(STAGES[i][0]*FPS)))
 assert all(float(x.std())<.6 for x in p), 'Background must remain uniform and object-free'
 return [float(np.median(x)) for x in p]

@lru_cache(None)
def card(i):
 im=Image.new('RGB',(CW,CH),(15,15,15));d=ImageDraw.Draw(im)
 d.rectangle((0,0,CW-1,CH-1),outline=(82,82,82))
 for value,size,top,tone in [(STAGES[i][1],36,17,236),(STAGES[i][2],30,72,205)]:
  f=ImageFont.truetype(str(FONT),size)
  assert f.getlength(value)<=CW-32,(value,f.getlength(value))
  d.text((16,top),value,font=f,fill=(tone,)*3,anchor='lt')
 a=cv2.cvtColor(np.asarray(im),cv2.COLOR_RGB2YUV_I420).reshape(-1)
 return (a[:CW*CH].reshape(CH,CW),a[CW*CH:CW*CH*5//4].reshape(CH//2,CW//2),a[CW*CH*5//4:].reshape(CH//2,CW//2))

def smooth(q):
 q=float(np.clip(q,0,1));return q*q*q*(q*(q*6-15)+10)

def compose(raw,frame,i):
 age=frame/FPS-STAGES[i][0]
 if not 0<=age<3.8:return raw
 alpha=smooth(age/.30)*(1-smooth((age-3.25)/.55))
 out=bytearray(raw)
 for p,b,c in zip(patches(out),clean_background(i),card(i)):
  p[:]=np.rint(b*(1-alpha)+c.astype(np.float32)*alpha).clip(0,255).astype(np.uint8)
 return out

def run(a):subprocess.run(['ffmpeg','-nostdin','-y','-v','warning',*a],check=True)

def preview():
 (ROOT/'review').mkdir(exist_ok=True)
 for i,(at,_,_) in enumerate(STAGES):
  n=round((at+1)*FPS);raw=one_frame(n);out=compose(raw,n,i)
  rgb=cv2.cvtColor(np.frombuffer(out,np.uint8).reshape(H*3//2,W),cv2.COLOR_YUV2RGB_I420)
  Image.fromarray(rgb).save(ROOT/f'review/cue_{i+1}.png')
  Image.fromarray(rgb).resize((360,480),Image.Resampling.LANCZOS).save(ROOT/f'review/cue_{i+1}_360.png')
 print('Six preview frames created',flush=True)

def encode_span(i,first,last,path):
 dec=subprocess.Popen(['ffmpeg','-v','error','-ss',f'{first/FPS:.12f}','-i',str(BASE),'-frames:v',str(last-first),'-an','-pix_fmt','yuv420p','-f','rawvideo','-'],stdout=subprocess.PIPE)
 log=path.with_suffix('.log').open('w')
 # Explicit input metadata prevents FFmpeg from auto-converting untagged raw
 # YUV through RGB when negotiating a BT.709 output. Match the source range.
 enc=subprocess.Popen(['ffmpeg','-nostdin','-y','-v','warning','-f','rawvideo','-pix_fmt','yuv420p','-s',f'{W}x{H}','-r',str(FPS),'-colorspace','bt709','-color_range','tv','-i','pipe:0','-an','-c:v','libx264','-preset','medium','-crf','14','-threads','4','-pix_fmt','yuv420p','-colorspace','bt709','-color_range','tv','-video_track_timescale','15360','-movflags','+faststart',str(path)],stdin=subprocess.PIPE,stderr=log)
 try:
  for n in range(first,last):
   raw=dec.stdout.read(SIZE)
   if len(raw)!=SIZE:raise RuntimeError(f'Short source frame {n}: {len(raw)}')
   enc.stdin.write(compose(raw,n,i))
 finally:
  enc.stdin.close();dec.stdout.close();de=dec.wait();ec=enc.wait();log.close()
 if de or ec:raise RuntimeError((de,ec))
 print(f'Encoded card {i+1}: frames {first}..{last-1}',flush=True)

def render():
 out=ROOT/'render';out.mkdir(exist_ok=True)
 k=json.loads((ROOT/'review/keyframes.json').read_text())
 spans=[(max(j for j in k if j<=round(at*FPS)),min(j for j in k+[N] if j>=round((at+3.8)*FPS))) for at,_,_ in STAGES]
 parts=[];cursor=0
 for i,(first,last) in enumerate(spans):
  if first>cursor:parts.append({'start':cursor,'end':first,'mode':'copy'})
  parts.append({'start':first,'end':last,'mode':'encode','stage':i});cursor=last
 if cursor<N:parts.append({'start':cursor,'end':N,'mode':'copy'})
 for n,p in enumerate(parts):
  path=out/f'part{n:02d}.mp4';p['file']=path.name
  if p['mode']=='copy':
   run(['-ss',f"{p['start']/FPS:.12f}",'-i',str(BASE),'-map','0:v:0','-an','-c:v','copy','-frames:v',str(p['end']-p['start']),'-video_track_timescale','15360',str(path)])
  else:encode_span(p['stage'],p['start'],p['end'],path)
 (out/'concat.txt').write_text(''.join(f"file '{p['file']}'\nduration {(p['end']-p['start'])/FPS:.12f}\n" for p in parts),encoding='utf-8')
 name='Bad_Apple_Light_Loom_R9_4_Portrait_Final_1080x1440_60fps.mp4'
 if not AUDIO.is_file():raise FileNotFoundError('Build user-selected audio with review/audio selected-master script first')
 run(['-f','concat','-safe','0','-i',str(out/'concat.txt'),'-i',str(AUDIO),'-map','0:v:0','-map','1:a:0','-c','copy','-video_track_timescale','15360','-metadata','title=Bad Apple!! · 放映室进化','-metadata','comment=Existing stage cards refined; user-selected two-second audio handover normalization.','-movflags','+faststart',str(ROOT/name)])
 plan={'baseline':str(BASE.relative_to(ROOT.parent)),'output':name,'fps':FPS,'frames':N,'duration':N/FPS,'card_rect':[X,Y,CW,CH],'font':str(FONT),'font_name':'思源黑体 Source Han Sans SC Normal','font_sizes':[36,30],'stages':STAGES,'cue_duration':3.8,'fade_in':.30,'fade_out':.55,'parts':parts,'audio':'User-selected108.5–110.5s normalization; original lossless PCM preserved elsewhere, one new AAC encoding','audio_input':AUDIO.relative_to(ROOT).as_posix(),'scope':'Existing card typography and approved bounded audio only; no opening, macro, MMD, source footage, rhythm, or outro modifications','background_samples_yuv':[clean_background(i) for i in range(6)]}
 (ROOT/'source/edit-plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf-8')
 print('Final assembled',flush=True)

if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('action',choices=['preview','render']);z=a.parse_args()
 preview() if z.action=='preview' else render()
