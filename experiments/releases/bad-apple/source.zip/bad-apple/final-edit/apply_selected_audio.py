from pathlib import Path
import subprocess,json,hashlib,re,concurrent.futures
import numpy as np
O=Path(__file__).resolve().parent;SR=44100;TOTAL=round(220.5*SR);START=107.;END=114.
MASTER=O/'embedded_original_master.flac';SELECTED=O/'selected_master.flac';AAC=O/'selected_audio.m4a'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def pcm24(p):
 raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(p),'-acodec','pcm_s32le','-f','s32le','-'])
 data=np.frombuffer(raw,'<i4').reshape(-1,2);assert not np.any(data%256)
 return (data//256).astype(np.int32)
original=pcm24(MASTER);assert len(original)==TOTAL
selected=original.copy();lo=round(START*SR);hi=round(END*SR);t=START+np.arange(hi-lo)/SR;active=(t>108.5)&(t<110.5)
u=np.clip((t-108.5)/2,0,1);b=np.sin(u*np.pi/2)**2;a=1-b;g=1/np.sqrt(a*a+b*b)
clip=original[lo:hi].copy();clip[active]=np.rint(clip[active].astype(np.float64)*g[active,None]).astype(np.int32)
audition=pcm24(O/'B_power_normalized_107-114s.wav');assert np.array_equal(clip,audition)
selected[lo:hi]=clip;assert abs(selected).max()<2**23
cmd=['ffmpeg','-nostdin','-y','-v','error','-f','s32le','-ar',str(SR),'-ac','2','-i','pipe:0','-c:a','flac','-sample_fmt','s32','-bits_per_raw_sample','24',str(SELECTED)]
p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stderr=subprocess.PIPE)
for begin in range(0,len(selected),SR):p.stdin.write((selected[begin:begin+SR]<<8).astype('<i4').tobytes())
p.stdin.close();err=p.stderr.read().decode('utf-8',errors='replace');code=p.wait();assert code==0,err
roundtrip=pcm24(SELECTED);assert np.array_equal(roundtrip,selected)
# Exactly one delivery AAC encode from the selected lossless master.
r=subprocess.run(['ffmpeg','-nostdin','-y','-v','error','-i',str(SELECTED),'-c:a','aac','-b:a','384k','-movflags','+faststart',str(AAC)],stdout=subprocess.DEVNULL,stderr=subprocess.PIPE);assert r.returncode==0,r.stderr
probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(AAC)]));(O/'selected_audio_probe.json').write_text(json.dumps(probe,indent=2),encoding='utf-8')
audio_stream=probe['streams'][0]
def loud(path,name):
 r=subprocess.run(['ffmpeg','-hide_banner','-nostats','-v','info','-xerror','-i',str(path),'-af','ebur128=peak=true','-f','null','-'],stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
 text=r.stderr.decode('utf-8',errors='replace');(O/f'{name}_full_meter.log').write_text(text,encoding='utf-8');tail=text[text.rfind('Summary:'):]
 return {'integrated_lufs':float(re.search(r'I:\s*([-\d.]+) LUFS',tail)[1]),'true_peak_dbtp':float(re.search(r'Peak:\s*([-\d.]+) dBFS',tail)[1]),'lra_lu':float(re.search(r'LRA:\s*([-\d.]+) LU',tail)[1]),'decode_exit':r.returncode}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:
 l0=ex.submit(loud,SELECTED,'selected_master');l1=ex.submit(loud,AAC,'selected_aac');meters={'lossless':l0.result(),'aac':l1.result()}
raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(AAC),'-f','f32le','-'])
decoded=np.frombuffer(raw,'<f4').reshape(-1,2);inside=decoded[:TOTAL]
packet_info=json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','a:0','-show_packets','-show_entries','packet=pts,dts,pts_time,dts_time,duration,duration_time,size,flags,data_hash,side_data_list','-show_data_hash','sha256','-of','json',str(AAC)]));(O/'selected_audio_packets.json').write_text(json.dumps(packet_info,indent=2),encoding='utf-8');packets=packet_info['packets']
source_packets=json.loads((O.parents[2]/'review/technical/polish/candidate_audio_packets.json').read_text(encoding='utf-8'))['packets']
timing_keys=['pts','dts','duration'];timing_equal=len(packets)==len(source_packets) and all(all(x[k]==y[k] for k in timing_keys) and x.get('side_data_list')==y.get('side_data_list') for x,y in zip(packets,source_packets))
start=round(108.5*SR);end=round(110.5*SR)
checks={'lossless_220_5s_samples':len(selected)==TOTAL,'lossless_write_roundtrip_exact':np.array_equal(roundtrip,selected),'selected107_114_matches_B_audition_exact':np.array_equal(roundtrip[lo:hi],audition),'outside_108_5_110_5_all_original_PCM_exact':np.array_equal(roundtrip[:start],original[:start]) and np.array_equal(roundtrip[end:],original[end:]),'original_natural111_112_exact':np.array_equal(roundtrip[111*SR:112*SR],original[111*SR:112*SR]),'no_lossless_clipping':bool(np.max(abs(roundtrip))<2**23),'no_AAC_decoded_clipping':bool(np.max(abs(inside))<1),'AAC_same_packet_timestamps_durations_priming_as_previous':timing_equal,'AAC_declared_start0_duration220_5':float(audio_stream['start_time'])==0 and float(audio_stream['duration'])==220.5,'AAC_44100_stereo':audio_stream['sample_rate']=='44100' and audio_stream['channels']==2,'full_audio_decode_success':all(v['decode_exit']==0 for v in meters.values()),'natural_final_digital_silence_retained':bool(np.max(abs(inside[219*SR:]))==0)}
report={'task_id':'badapple-cues-audio-20260929','trace_id':'BADAPPLE-CUES-AUDIO-20260929','execution_epoch':1,'expert':'Code Auditor (\u7801\u9274)','platform_agent':'collaboration /root/technical_review','decision':'User selected candidate B; adopted for audio handoff, not yet muxed by this agent','source_master_sha256':digest(MASTER),'selected_master':{'path':SELECTED.name,'sha256':digest(SELECTED),'sample_rate':SR,'channels':2,'pcm_bits':24,'samples':TOTAL},'selected_audio':{'path':AAC.name,'sha256':digest(AAC),'encode':'single AAC encode from selected lossless master, target 384 kbit/s','measured_bitrate':audio_stream.get('bit_rate'),'packet_count':len(packets),'declared_samples':int(audio_stream['duration_ts']),'decoded_samples_including_AAC_padding':len(decoded),'decoded_sample_peak_dbfs':float(20*np.log10(abs(inside).max()))},'method':'Identical bounded normalization as accepted B audition; open interval108.5..110.5s only, max+3.0103dB; no EQ/time shift/remix elsewhere.','checks':checks,'passed':all(checks.values()),'meters':meters,'AAC_lossy_boundary':'PCM exactness applies to lossless selected_master, not to AAC decoded samples; AAC is a fresh single generation and remains time aligned.','listening_performed_by_agent':False,'mux_instruction':['Use accepted stage-card video as input0 and selected_audio.m4a as input1.','Map 0:v:0 + 1:a:0; -c copy; -video_track_timescale 15360; -movflags +faststart; write a new final path.','Do not add -shortest, a silence pad, time offset, tempo change or extra AAC encode. Both streams are already220.5s.','After remux compare video packets/frame hashes unchanged, selected AAC packets/timing copied exact, and final220.5s endpoints.']}
(O/'selected_validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(report,ensure_ascii=False,indent=2),flush=True)
