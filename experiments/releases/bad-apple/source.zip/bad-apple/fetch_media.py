"""Download this release's media and verify bytes before installing each file."""
import hashlib,json,sys,urllib.request,urllib.parse
from pathlib import Path
root=Path(__file__).resolve().parent
if len(sys.argv)!=2: raise SystemExit('Usage: python fetch_media.py <animation.html URL>')
base=sys.argv[1]
if urllib.parse.urlparse(base).scheme not in ('http','https'): raise SystemExit('Expected an HTTP(S) URL')
for item in json.loads((root/'media-manifest.json').read_text(encoding='utf-8')):
 target=root/item['file']
 if target.is_file() and hashlib.sha256(target.read_bytes()).hexdigest()==item['sha256']: continue
 url=urllib.parse.urljoin(base,item['file'])
 print('Downloading',item['file'],flush=True)
 with urllib.request.urlopen(url,timeout=120) as response: data=response.read()
 if len(data)!=item['bytes'] or hashlib.sha256(data).hexdigest()!=item['sha256']: raise SystemExit('Media integrity mismatch: '+item['file'])
 target.write_bytes(data)
print('Verified. Run python -m http.server 8000 and open animation.html.')
