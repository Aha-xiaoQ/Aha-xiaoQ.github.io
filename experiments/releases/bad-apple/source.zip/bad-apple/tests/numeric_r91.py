
from pathlib import Path
import sys,ctypes as C,json,hashlib,math
import numpy as np,cv2
R=Path(__file__).resolve().parents[1];(R/'render').mkdir(exist_ok=True);sys.path.insert(0,str(R/'tools'))
from native_field import Field
from scene_r91 import Scene
checks=[]
def ck(n,ok,**d):checks.append({'name':n,'passed':bool(ok),**d})
f=Field(48,36,48,36);f.lib.set_spot(0)
rng=np.random.default_rng(91)
im=rng.integers(0,256,(36,48,3),dtype=np.uint8)
f.set_frame(im,True);f.solve();rgb=f.output[:,:,:3].copy()
planes=[]
for ch in range(3):
 a=np.zeros_like(im);a[:,:,ch]=im[:,:,ch];f.set_frame(a,True);f.solve();planes.append(f.output[:,:,:3].copy())
sumplanes=np.sum(np.array(planes,dtype=int),axis=0)
ck('RGB detector superposition (not false white-light angle colouring)',np.max(abs(sumplanes-rgb.astype(int)))<=1,maxGrayCodeError=int(np.max(abs(sumplanes-rgb.astype(int)))))

ck('Every RGB exposure channel has a complementary OFF share',np.max(abs(im.astype(float)/255 + (1-im.astype(float)/255)-1))==0)
# Every active low-resolution address is unique, genuine light support set.
for name,im in [('black',np.zeros((36,48),np.uint8)),('white',np.full((36,48),255,np.uint8)),('single',np.pad(np.full((1,1),255,np.uint8),((17,18),(23,24)))),('gray',np.full((36,48),127,np.uint8))]:
 f.set_frame(im);f.solve(); ids=np.arange(f.N);active=ids[(f.duty>0)&f.valid.any(1)]
 expected=np.flatnonzero(im.ravel()>0)
 ck(name+' low-grid active ray identifiers',np.array_equal(active,expected),active=int(len(active)))
 ck(name+' incident = ON + OFF exposure',abs(float(np.sum(f.duty)+np.sum(1-f.duty))-f.N)<.001)
 if name=='black':ck('Black source zero receiver energy',not np.any(f.output[:,:,:3]))
 if name=='single':ck('Single mirror affects one detector cell in nominal low grid',np.count_nonzero(f.output[:,:,0])==1,cells=int(np.count_nonzero(f.output[:,:,0])))
# OFF branch must reach the actual visible absorber bounds.
I=np.array([math.sin(math.pi*2/15),-math.cos(math.pi*2/15),0])
Noff=np.array([math.sin(math.pi/15),math.cos(math.pi/15),0])
Doff=I-2*np.dot(I,Noff)*Noff
p=f.centers.astype(float);end=p+Doff*((1-p[:,0])/Doff[0])[:,None]
ck('OFF rays propagate forward to the internal absorber',np.all((1-p[:,0])/Doff[0]>0))
ck('Absorber physically spans OFF intersections',end[:,1].min()>=.15 and end[:,1].max()<=1.65 and abs(end[:,2]).max()<.42,ymin=float(end[:,1].min()),ymax=float(end[:,1].max()))
# Real outgoing segments fit through the non-optical exit barrel.
h=np.column_stack([f.hits,np.full(f.N,-21.45)]);q=f.folds.astype(float)
for z,rad in [(-.63,.57),(-1.25,.53),(-1.92,.49)]:
 cross=q+(h-q)*((z-q[:,2])/(h[:,2]-q[:,2]))[:,None]
 rr=np.sqrt(cross[:,0]**2+(cross[:,1]-2.75)**2)
 ck('All central rays clear barrel at z='+str(z),rr.max()<rad,radius=float(rad),maxRayRadius=float(rr.max()))
ck('Projector and piano have disjoint depth intervals',1.03<3.32,gap=3.32-1.03)
# Screenshots do not rely on a receiver override: lamp affects the same model.
f.set_frame(np.full((36,48),255,np.uint8));f.solve(0)
ck('Power zero under RGB / geometric path also zero',not np.any(f.output[:,:,:3]))
# New keyboard geometry and overlap check in several views.
f.solve(1);sc=Scene(1080,1440)
base=np.zeros(72,np.float32)
for t in [10,99,128,159,196]:
 sc.camera(t,f);canvas=np.zeros((1440,1080,3),np.uint8)
 keys=base.copy();keys[24]=.8;sc.keyboard(canvas,keys,1)
 polygons=sc.keyPolygons
 ck(f'{t}s all 61 keys have unique physical addresses',len(polygons)==61 and len({a['index'] for a in polygons})==61)
 ck(f'{t}s all keys remain in viewport',all(np.all(sc.project(np.asarray(q))>=0) and np.all(sc.project(np.asarray(q))[:,0]<1080) and np.all(sc.project(np.asarray(q))[:,1]<1440)for q in [a['world'] for a in polygons]))
(R/'render/r91_numeric_qc.json').write_text(json.dumps({'checks':checks,'passed':all(c['passed']for c in checks)},indent=2))
print(json.dumps(checks,indent=2),flush=True)
