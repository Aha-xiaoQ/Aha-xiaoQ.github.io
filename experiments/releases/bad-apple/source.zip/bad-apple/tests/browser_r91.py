
from pathlib import Path
import sys,json,time,traceback
sys.path.insert(0,str(Path(__file__).resolve().parent))
from load_r91 import load
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];(R/'render').mkdir(exist_ok=True);checks=[];errors=[]
def ck(name,ok,detail=None):
 checks.append({'name':name,'passed':bool(ok),'detail':detail});print(name,bool(ok),detail,flush=True)
try:
 with sync_playwright() as p:
  b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
  page=b.new_page(viewport={'width':1080,'height':1440},device_scale_factor=1)
  page.on('pageerror',lambda e:errors.append(str(e)))
  load(page);page.evaluate('LOOM2.pause();LOOM2.setClean(true);LOOM2.paint()')
  ck('built-in ready',page.evaluate('LOOM2.ready'));page.evaluate('document.getElementById("play").click()');page.wait_for_function('!document.getElementById("media").paused',timeout=30000);page.evaluate('LOOM2.pause()');page.wait_for_timeout(300)
  ck('pause stops all pending media playback',page.evaluate('document.getElementById("media").paused && document.getElementById("synth-audio").paused'))
  for t,w in [(10,48),(50,96),(99,180),(128,360),(159,540),(196,720)]:
   page.evaluate('(t)=>LOOM2.seek(t)',t);page.wait_for_function('(t)=>Math.abs(document.getElementById("media").currentTime-t)<.1&&!document.getElementById("media").seeking',arg=t)
   page.wait_for_timeout(450);page.evaluate('LOOM2.captureNow();LOOM2.paint()')
   st=page.evaluate('LOOM2.stats()');ck(f'{t}s real grid',st['analysis']==[w,w*3//4],st)
   ck(f'{t}s no verification substitution',page.evaluate('!LOOM2.field.proof'))
   ck(f'{t}s colour routing',st['color']==(t>=145))
   counts=page.evaluate('({beams:LOOM2.beamIDs.length,unique:new Set(LOOM2.beamIDs).size,array:LOOM2.arrayPanel.cells,energy:LOOM2.scene.energyAudit})')
   ck(f'{t}s unique visible beam IDs',counts['beams']==counts['unique'],counts)
   ck(f'{t}s whole-array count',counts['array']==w*w*3//4)
   ea=counts['energy'];ck(f'{t}s ON + OFF = illumination',abs(ea['on']+ea['off']-ea['incident'])<.005,ea)
   page.screenshot(path=str(R/f'render/browser_{t}.png'))
  # R9.1: presentation is readable and remains connected to the actual chip.
  def seek_check(t):
   page.evaluate('(t)=>LOOM2.seek(t)',t);page.wait_for_function('!document.getElementById("media").seeking');page.wait_for_timeout(300);page.evaluate('LOOM2.captureNow();LOOM2.paint()')
  for W,H,t in [(1080,1440,1.5),(1080,1440,37.7),(1080,1440,111),(1080,1440,147.4),(1080,1440,184),(390,844,184),(1440,1000,37.7)]:
   page.set_viewport_size({'width':W,'height':H});page.evaluate('LOOM2.setClean(false)');seek_check(t)
   meta=page.evaluate('({labels:LOOM2.scene.labelBoxes,leaders:LOOM2.scene.magnifierLeaders,cue:LOOM2.scene.cueBox,closed:LOOM2.scene.closed})')
   ck(f'{W}x{H} {t}s title gutters outside image',all(a['box'][1]+a['box'][3]<=a['image'][1]+.01 for a in meta['labels']),meta['labels'])
   ck(f'{W}x{H} {t}s exactly two chip magnifier leaders',len(meta['leaders'])==2)
   cue=meta['cue'];ck(f'{W}x{H} {t}s cue outside screen',cue is not None and cue['box'][1]>=cue['screenBottom']+1,cue)
   if W==1080 or W==390:ck(f'{W}x{H} {t}s cue above array',cue['box'][1]+cue['box'][3]<cue['panelTop'])
   ck(f'{W}x{H} {t}s no late automatic shell closure',meta['closed']==0)
  page.set_viewport_size({'width':1080,'height':1440});page.evaluate('LOOM2.setClean(true)');seek_check(176)
  face=page.evaluate('LOOM2.scene.keyPolygons');old_spectrum=page.evaluate('LOOM2.spectra')
  ck('recording mode has real frequency feedback, not invented notes',sum(a['spectrum']>.03 for a in face)>0 and max(a['press'] for a in face)==0 and page.evaluate('LOOM2.scene.keyFeedback')=='原声频谱')
  seek_check(177);ck('source spectrum genuinely changes with source time',old_spectrum!=page.evaluate('LOOM2.spectra'))
  ck('source spectrum frame 177 equals packaged analysis',page.evaluate('LOOM2.spectra')==list(__import__('numpy').fromfile(R/'assets/spectrum_keys.bin',dtype='uint8').reshape(13230,72)[10620].astype('float32')/255))
  energy=page.evaluate('LOOM2.energy()');page.evaluate('LOOM2.scene.spectralValues.fill(0);LOOM2.scene.spectralMode=0;LOOM2.scene.r9Keys([],1)');ck('key feedback cannot modify optical receiver',energy==page.evaluate('LOOM2.energy()'))
  page.evaluate('LOOM2.paint()');page.screenshot(path=str(R/'render/R91_Final_Keyboard.png'))
  # Leader starts are actual chip corners in this current camera.
  exact=page.evaluate("""()=>{const s=LOOM2.scene,f=LOOM2.field,q=[[f.ow/2,0,f.oh/2],[-f.ow/2,0,f.oh/2],[-f.ow/2,0,-f.oh/2],[f.ow/2,0,-f.oh/2]].map(p=>s.project(p));return s.magnifierLeaders.every(l=>q.some(p=>Math.hypot(p[0]-l.from[0],p[1]-l.from[1])<1e-6));}""")
  ck('magnifier lines originate at actual silicon footprint',exact)
  page.evaluate('document.getElementById("housing").click();LOOM2.paint()');ck('manual shell checkbox remains functional',page.evaluate('LOOM2.scene.closed')==1);page.evaluate('document.getElementById("housing").click();LOOM2.paint()')
  page.evaluate('LOOM2.seek(13.085)');page.wait_for_timeout(400);page.evaluate('LOOM2.captureNow();LOOM2.paint()');ck('repaired 65 Hz event remains visible past former 13.6ms cutoff',max(page.evaluate('LOOM2.scoreKeys(13.085)'))>.01)
  seek_check(196)

  # Color source really modifies the solved receiver.
  ck('colour mode uses independent receiver channels',page.evaluate('LOOM2.field.sourceColor && LOOM2.field.input.some((v,i,a)=>i%4===0&&Math.abs(v-a[i+1])>10)'))
  before=page.evaluate('LOOM2.energy()');page.evaluate('document.getElementById("lamp").click()');page.evaluate('LOOM2.paint()')
  ck('lamp off zero detector energy',page.evaluate('LOOM2.energy()===0'))
  page.evaluate('document.getElementById("lamp").click()')
  page.evaluate('LOOM2.seek(10)');page.wait_for_timeout(500);page.evaluate('LOOM2.captureNow();LOOM2.paint()')
  id=page.evaluate('LOOM2.field.duty.findIndex(v=>v>.1)')
  page.evaluate('(i)=>{LOOM2.isolate(i);LOOM2.paint()}',id)
  ck('single mirror one visible bundle',page.evaluate('LOOM2.beamIDs.length===1'))
  page.evaluate('LOOM2.isolate(-1);LOOM2.setClean(false);LOOM2.paint()')
  page.set_viewport_size({'width':1440,'height':1000});page.wait_for_timeout(250);page.evaluate('LOOM2.paint()');page.screenshot(path=str(R/'render/UI_Desktop.png'))
  page.set_viewport_size({'width':390,'height':844});page.wait_for_timeout(250);page.evaluate('LOOM2.paint()');page.screenshot(path=str(R/'render/UI_Mobile.png'))
  ck('mobile no horizontal overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'))
  # import from actual user file mounted locally -- browser supports it already.
  page.set_input_files('#video-file',str(R/'tests/portrait_test.mp4'));page.wait_for_timeout(900)
  ck('local import is decoded',page.evaluate('!LOOM2.stats().isBuiltin && LOOM2.ready'),page.evaluate('LOOM2.stats()'))
  page.evaluate('LOOM2.restoreBuiltin()');page.wait_for_timeout(1500);ck('restore built-in',page.evaluate('LOOM2.stats().isBuiltin'))
  # Record audio graph flags using actual click gesture.
  page.evaluate('document.getElementById("evolution-mode").click();LOOM2.seek(150)');page.wait_for_timeout(300);page.click('#play');page.wait_for_timeout(900)
  ck('actual audio graph running',page.evaluate('LOOM2.audioState()?.state==="running"'),page.evaluate('LOOM2.audioState()'))
  ck('evolution FLAC actually running',page.evaluate('LOOM2.audioState()?.synthKind==="evolution" && !LOOM2.audioState().synthPaused'))
  ck('no master compressor',page.evaluate('LOOM2.audioState()?.compressor===false'))
  page.evaluate('LOOM2.pause()')
  page.evaluate('LOOM2.seek(30)');page.wait_for_timeout(500);page.keyboard.press('m');page.wait_for_timeout(250);page.evaluate('LOOM2.paint()')
  ck('manual optical close-up available',page.evaluate('LOOM2.stats().camera==="macro"'))
  page.screenshot(path=str(R/'render/UI_Macro.png'));page.keyboard.press('m')
  page.set_viewport_size({'width':720,'height':960})
  page.evaluate('document.getElementById("play").click()');page.wait_for_function('!document.getElementById("media").paused',timeout=30000)
  with page.expect_download(timeout=30000) as dl:
   page.evaluate('document.getElementById("record").click()');page.wait_for_timeout(2300);page.evaluate('LOOM2.stopRecording()')
  file=dl.value;file.save_as(str(R/'render/browser_record.webm'))
  ck('actual browser recording emitted media',(R/'render/browser_record.webm').stat().st_size>10000)
  page.evaluate('LOOM2.pause()')
  ck('no JS page errors',len(errors)==0,errors)
  b.close()
except Exception as e:
 errors.append(traceback.format_exc());print(errors[-1],flush=True)
(R/'render/browser_qc_r91.json').write_text(json.dumps({'checks':checks,'errors':errors,'passed':all(c['passed'] for c in checks) and not errors},ensure_ascii=False,indent=2))
