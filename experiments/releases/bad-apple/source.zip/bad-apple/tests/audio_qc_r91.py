"""Checks on actual decoded R9.1 audio; no subjective listening claims."""
from pathlib import Path
import json,subprocess,hashlib,re
import numpy as np,soundfile as sf
R=Path(__file__).resolve().parents[1];A=R/'assets';SR=44100
checks=[]
def ck(name,ok,**d):
 checks.append(dict(name=name,passed=bool(ok),**d));assert ok,(name,d)
x,sr=sf.read(A/'evolution.flac',dtype='float64',always_2d=True);old,so=sf.read(A/'old_evolution.flac',dtype='float64',always_2d=True)
ck('actual FLAC 220.5s, stereo, 44100 Hz',sr==SR and x.shape==(9724050,2),shape=list(x.shape),sampleRate=sr)
ck('all samples before 13s unchanged',np.array_equal(x[:13*SR],old[:13*SR]))
ck('all samples after 15.1s unchanged',np.array_equal(x[round(15.1*SR):],old[round(15.1*SR):]))
ck('entire solo section remains dual-identical mono until crossfade',np.array_equal(x[:round(35.5*SR),0],x[:round(35.5*SR),1]))
peak=float(np.max(abs(x)));ck('no clipping in actual PCM24 master',peak<.99,peakDBFS=float(20*np.log10(peak)))
es=json.loads((A/'chip_events.json').read_text());before=json.loads((A/'old_chip_events.json').read_text());changed=[(i,a,b)for i,(a,b)in enumerate(zip(before,es))if a!=b]
ck('exactly eight duration changes; no pitch/time changes',len(changed)==8 and all(a['f']==b['f']==65 and a['t']==b['t'] and b['d']==.1 for i,a,b in changed),notes=[dict(time=b['t'],oldDuration=a['d'],newDuration=b['d'])for i,a,b in changed])
ck('rearticulated notes do not overlap next note',all(b['t']+b['d']<es[i+1]['t'] for i,a,b in changed))
k=np.frombuffer((A/'evolution_keys.bin').read_bytes(),np.uint8).reshape(-1,72);ko=np.frombuffer((A/'old_evolution_keys.bin').read_bytes(),np.uint8).reshape(-1,72)
ck('note feedback before/after repaired interval unchanged',np.array_equal(k[:int(12.99*60)],ko[:int(12.99*60)]) and np.array_equal(k[16*60:],ko[16*60:]))
ck('repaired keys present during extended note bodies',all(k[round((b['t']+.055)*60),0]>120 for i,a,b in changed))
sp=np.frombuffer((A/'spectrum_keys.bin').read_bytes(),np.uint8).reshape(-1,72)
ck('spectrum lookup covers every movie frame',sp.shape==(13230,72))
ck('recorded-audio spectrum responds over time, not frozen',np.mean(abs(sp[176*60].astype(int)-sp[177*60].astype(int)))>1,meanFrameDifference=float(np.mean(abs(sp[176*60].astype(int)-sp[177*60].astype(int)))))
ck('spectrum stops after song; no fake notes on ending',np.all(sp[219*60:]==0))
yb=subprocess.check_output(['ffmpeg','-v','error','-i',str(A/'evolution.m4a'),'-ac','2','-ar',str(SR),'-f','f32le','pipe:1']);y=np.frombuffer(yb,'<f4').reshape(-1,2)
# AAC is lossy: compare similarity, not equality. Only this generation of encoded AAC is used.
start,end=150*SR,210*SR;a=x[start:end].ravel();b=y[start:end].ravel();corr=float(np.corrcoef(a,b)[0,1]);snr=float(10*np.log10(np.mean(a*a)/np.mean((a-b)**2)))
ck('one-generation AAC preserves original passage similarity',corr>.999,corr=corr,snrDB=snr)
ck('encoded audio contains song tail before natural silence',float(np.max(abs(y[211*SR:216*SR])))>1e-4,tailRMSdBFS=float(20*np.log10(np.sqrt(np.mean(y[211*SR:216*SR]**2)))))
ck('AAC decoded peak below full scale',float(np.max(abs(y)))<1,peakDBFS=float(20*np.log10(np.max(abs(y)))))
# Paired loudness measurements are descriptive; no claim of equal instantaneous volume.
loud=[]
for f in ['old_evolution.flac','evolution.flac']:
 for ss,dd in [(0,35),(11,4.3),(16,19)]:
  p=subprocess.run(['ffmpeg','-hide_banner','-v','info','-ss',str(ss),'-t',str(dd),'-i',str(A/f),'-af','loudnorm=I=-18:TP=-1.0:LRA=11:print_format=json','-f','null','-'],stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,text=True,check=True)
  v=json.loads(p.stderr[p.stderr.rfind('{'):p.stderr.rfind('}')+1]);loud.append(dict(file=f,start=ss,duration=dd,I=v['input_i'],TP=v['input_tp'],LRA=v['input_lra']))
report=dict(revision='R9.1',passed=len(checks),total=len(checks),checks=checks,loudness=loud,notes='PCM comparisons before13/after15.1 are exact. AAC correlations do not imply losslessness. Spectrum is an energy visualization, not a score.')
(R/'render/audio_qc_r91.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False,indent=2))
