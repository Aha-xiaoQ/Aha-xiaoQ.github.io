"""Rebuild this targeted audio edit from its supplied baseline in isolation."""
from pathlib import Path
import tempfile,shutil,subprocess,hashlib,json
R=Path(__file__).resolve().parents[1];names=['chip.flac','evolution.flac','chip_events.json','evolution_keys.bin','spectrum_keys.bin']
before={n:hashlib.sha256((R/'assets'/n).read_bytes()).hexdigest()for n in names}
with tempfile.TemporaryDirectory(prefix='r91_audio_rebuild_')as tmp:
 t=Path(tmp);(t/'assets').mkdir();(t/'render').mkdir();(t/'tools').mkdir()
 for n in ['old_chip.flac','old_chip_events.json','old_evolution.flac','old_evolution_keys.bin','original_reference.m4a']:shutil.copy2(R/'assets'/n,t/'assets'/n)
 shutil.copy2(R/'tools/audio_r91.py',t/'tools/audio_r91.py');subprocess.run(['python',str(t/'tools/audio_r91.py')],stdout=subprocess.DEVNULL,check=True)
 checks=[]
 for n in names:
  h=hashlib.sha256((t/'assets'/n).read_bytes()).hexdigest();checks.append(dict(name=n,passed=h==before[n],rebuilt=h,delivered=before[n]));assert h==before[n],n
 (R/'render/audio_rebuild_r91.json').write_text(json.dumps(dict(checks=checks,passed=True),indent=2));print(checks)
