"""Independent finite-mirror-area receiver test, using Shapely polygon intersections.
No cached C coverage weights or targets are used to compute expected images.
"""
from pathlib import Path
import sys,json,hashlib,ctypes as CT,subprocess,math
import numpy as np
from scipy.ndimage import convolve1d
from shapely.geometry import Polygon,box
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'tools'))
from native_field import Field
checks=[]
def ck(name,ok,**data):
 z={'name':name,'passed':bool(ok),**data};checks.append(z);print(z,flush=True)
def unit(a):return a/np.linalg.norm(a,axis=-1,keepdims=True)
def reflect(d,n):return d-2*np.sum(d*n,axis=-1,keepdims=True)*n
S,F,YF,SZ=2.2,2.,2.75,-21.45;theta=np.pi/15;nom=np.array([-np.sin(theta),np.cos(theta),0.]);slopes=[(0,0),(.024,0),(-.024,0),(0,.024),(0,-.024)]
def trace(f,i,k,focus=0.,tilt=0.,uv=(0.,0.),aperture=.5):
 row,col=divmod(i,f.w);u,v=uv;dp=u*f.ow/f.w;p=np.array([(.5-(col+.5)/f.w)*f.ow+dp*np.cos(theta+tilt),dp*np.sin(theta+tilt),(.5-(row+.5)/f.h)*f.oh+v*f.oh/f.h]);n=np.array([-np.sin(theta+tilt),np.cos(theta+tilt),0.]);
 if k==0 and uv==(0.,0.):p=f.centers[i].astype(float);n=unit(f.normals[i].astype(float))
 ix,iz=slopes[k];inc=reflect(unit(np.array([ix,1.,iz])),nom);r=reflect(inc,n);l=p+r*(S-p[1])/r[1];d=np.array([r[0]/r[1]-l[0]/(F+focus),1.,r[2]/r[1]-l[2]/(F+focus)]);q=l+d*(YF-S-l[2])/(1+d[2]);rr=reflect(d,np.array([0.,1.,1.])/np.sqrt(2));hit=q+rr*(SZ-q[2])/rr[2];valid=(np.hypot(l[0],l[2])<=aperture and np.linalg.norm(q-[0,YF,0])<=.5 and r[1]>.001)
 return hit,l,q,inc,r,n,valid
# Detailed propagation independent from initial source + shared float32 normals.
f=Field(48,36,48,36);f.lib.set_spot(0)
p=f.centers.astype(float);n=unit(f.normals.astype(float));q=f.collimators.astype(float);s=f.sources.astype(float);axis=np.array([np.sin(2*theta),-np.cos(2*theta),0]);CC=-axis*3
v=q-s;out=unit(axis+(v/(v@axis)[:,None]-axis)-(q-CC)/.66);inc=unit(p-q)
ck('Collimator input/source re-creates parallel incidence',np.max(np.linalg.norm(out-inc,axis=1))<2e-6,maxError=float(np.max(np.linalg.norm(out-inc,axis=1))))
r=reflect(inc,n);ang=np.max(abs(np.arccos(np.clip(abs(np.sum(inc*n,axis=1)),0,1))-np.arccos(np.clip(abs(np.sum(r*n,axis=1)),0,1))))
ck('Incidence and reflection angles agree',ang<1e-10,maxRadians=float(ang))
hh=np.array([trace(f,i,0)[0][:2] for i in range(f.N)]);err=np.linalg.norm(hh-f.hits,axis=1)
ck('Full independent vector trace agrees with stored screen hits',err.max()<1e-5,maxWorldUnits=float(err.max()))
# Content changes must not change static geometric owners.
gh=hashlib.sha256(f.hits.tobytes()+f.normals.tobytes()).hexdigest();f.set_frame(np.full((36,48),128,np.uint8));f.solve();ck('Frame content does not retarget mirrors',gh==hashlib.sha256(f.hits.tobytes()+f.normals.tobytes()).hexdigest())
a=f.output[:,:,:3].copy();f.solve();ck('Reconstruction is deterministic',np.array_equal(a,f.output[:,:,:3]));f.solve(0);ck('Power zero removes all detector energy',not f.output[:,:,:3].any())
f.solve();ck('Neutral input has identical RGB energy',np.array_equal(f.output[:,:,0],f.output[:,:,1])and np.array_equal(f.output[:,:,0],f.output[:,:,2]))
# Independent complete receiver: finite physical face (side fill=.94), five
# angular families, detector-cell intersection using a separate geometry library.
for name,focus,aperture,tilt,kind in [('gray',0,.5,0,'gray'),('cross',0,.5,0,'cross'),('single',0,.5,0,'single'),('defocus',.07,.5,0,'gray'),('pupil',0,.24,0,'gray'),('tilted',0,.5,.035,'gray')]:
 f=Field(12,9,36,27);f.lib.set_spot(.18);f.lib.set_optics(focus,aperture,tilt)
 g=np.zeros((9,12),np.uint8)
 if kind=='gray':g[:,:6]=183;g[:,6:]=67
 elif kind=='single':g[4,6]=255
 else:g[4,3:10]=255;g[1:8,6]=255
 f.set_frame(g);f.solve();actual=f.output[:,:,0].copy();acc=np.zeros((27,36),float)
 for i in np.flatnonzero(g.ravel()):
  for k in range(5):
   hit,_,_,_,_,_,valid=trace(f,int(i),k,focus,tilt,aperture=aperture)
   if not valid:continue
   corners=[trace(f,int(i),k,focus,tilt,(u,v),aperture)[0] for u,v in [(-.47,-.47),(.47,-.47),(.47,.47),(-.47,.47)]]
   poly=Polygon([((h[0]/f.ww+.5)*f.rw,(.5-(h[1]-YF)/f.wh)*f.rh) for h in corners]);x0,y0,x1,y1=poly.bounds
   for y in range(max(0,math.floor(y0)),min(f.rh,math.ceil(y1))):
    for x in range(max(0,math.floor(x0)),min(f.rw,math.ceil(x1))):acc[y,x]+=poly.intersection(box(x,y,x+1,y+1)).area/poly.area*g.ravel()[i]*f.rw*f.rh/f.N/5
 acc=convolve1d(convolve1d(acc,[.18,.64,.18],axis=1,mode='nearest'),[.18,.64,.18],axis=0,mode='nearest');expected=np.clip(np.floor(acc+.5),0,255).astype(np.uint8);d=abs(expected.astype(int)-actual.astype(int))
 ck(f'Independent finite-area detector: {name}',d.max()<=1,max8bitDifference=int(d.max()),mean=float(d.mean()))
 ck(f'No sparse coverage overflow: {name}',f.lib.get_coverage_overflow()==0,entries=f.lib.get_coverage_count())
# Uniform flat-field comparison, evaluate half-gray to avoid white saturation
# hiding artifacts. Compile the old kernel as a separate loaded library.
old=R/'tests/r8/optics_r71_reference.c.txt';so=R/'tests/r8/old_optics.so'
subprocess.run(['clang','-O3','-shared','-fPIC','-DNATIVE','-x','c',str(old),'-lm','-o',str(so)],check=True)
lib=CT.CDLL(str(so));lib.configure.argtypes=[CT.c_int]*4+[CT.c_double];lib.set_spot.argtypes=[CT.c_double];lib.solve.argtypes=[CT.c_double]
for fn in ['input_ptr','output_ptr']:getattr(lib,fn).restype=CT.c_void_p
flat=[]
for w,rw in [(48,48),(96,96),(180,540),(360,810),(720,1080)]:
 h=w*3//4;rh=rw*3//4;f=Field(w,h,rw,rh);f.lib.set_spot(0 if w<=96 else .18);f.set_frame(np.full((h,w),128,np.uint8));f.solve();new=f.output[:,:,0].copy()
 lib.configure(w,h,rw,rh,.7);lib.set_spot(0 if w<=96 else .18);arr=np.ctypeslib.as_array(CT.cast(lib.input_ptr(),CT.POINTER(CT.c_ubyte)),shape=(h,w,4));arr[:,:,:3]=128;arr[:,:,3]=255;lib.set_frame(0);lib.solve(1);oldim=np.ctypeslib.as_array(CT.cast(lib.output_ptr(),CT.POINTER(CT.c_ubyte)),shape=(rh,rw,4))[:,:,0].copy()
 item={'control':[w,h],'receiver':[rw,rh],'oldStd':float(oldim[3:-3,3:-3].std()),'newStd':float(new[3:-3,3:-3].std()),'newMin':int(new.min()),'newMax':int(new.max())};flat.append(item)
 ck(f'{w}px finite-area reconstruction does not invent coarse point spikes',item['newStd']<=item['oldStd']+1e-4,**item)
 ck(f'{w}px full-size geometry cache fits without omitted footprints',f.lib.get_coverage_overflow()==0,entries=f.lib.get_coverage_count())
# Zero duty and isolation support stay coupled to actual receiver energy.
f=Field(48,36,48,36);f.lib.set_spot(0);pattern=np.zeros((36,48),np.uint8);pattern[7,6]=255;pattern[25,38]=255;f.set_frame(pattern);f.solve();ck('Two lit control addresses give exactly two low-res detector cells',np.count_nonzero(f.output[:,:,0])==2)
f.lib.set_isolate(7*48+6);f.solve();ck('Isolate is in accumulator, not a black overlay',np.count_nonzero(f.output[:,:,0])==1 and f.output[7,6,0]>0)
f.lib.set_isolate(-1);f.set_frame(np.zeros((36,48),np.uint8));f.solve();ck('All-black frame has no phantom central dots',not f.output[:,:,:3].any())
report={'revision':'R8','checks':checks,'passed':sum(x['passed']for x in checks),'total':len(checks),'flatField':flat,'limits':'Ideal paraxial lens. Finite mirror face integration; 5 angular pupil quadrature samples; pupil edge partial-area occlusion approximate. Numerical agreement is not hardware validation.'}
(R/'tests/r8/optics.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));assert all(x['passed']for x in checks)
