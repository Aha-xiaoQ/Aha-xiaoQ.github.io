from pathlib import Path
import subprocess,json,hashlib
import cv2,numpy as np
R=Path(__file__).resolve().parents[1];P=Path('/mnt/data/Bad_Apple_Light_Loom_R9_1_Evolution_1080x1440_60fps.mp4');checks=[]
def ck(n,ok,**d):
 checks.append(dict(name=n,passed=bool(ok),**d));assert ok,(n,d)
info=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(P)]));v=[s for s in info['streams']if s['codec_type']=='video'];a=[s for s in info['streams']if s['codec_type']=='audio'];ck('one video one audio',len(v)==len(a)==1);v=v[0];a=a[0]
ck('portrait1080x1440 60fps 13230 frames',v['width']==1080 and v['height']==1440 and v['avg_frame_rate']=='60/1' and int(v['nb_frames'])==13230,stream={k:v.get(k)for k in ['width','height','avg_frame_rate','nb_frames','pix_fmt','color_space']})
ck('full220.5 second duration',abs(float(info['format']['duration'])-220.5)<.02);ck('stereoAAC delivery',a['channels']==2 and a['codec_name']=='aac')
p=subprocess.run(['ffmpeg','-v','error','-threads','2','-i',str(P),'-f','null','-'],stderr=subprocess.PIPE,stdout=subprocess.DEVNULL,text=True)
ck('complete video and audio decode',p.returncode==0 and not p.stderr.strip(),stderr=p.stderr)
def a_hash(p):return subprocess.check_output(['ffmpeg','-v','error','-i',str(p),'-map','0:a:0','-c','copy','-f','hash','-hash','sha256','-']).decode().strip()
ck('AAC elementary packets copied without extra encode',a_hash(P)==a_hash(R/'assets/evolution.m4a'),hash=a_hash(P))
cap=cv2.VideoCapture(str(P));cap.set(cv2.CAP_PROP_POS_FRAMES,13229);ok,last=cap.read();ck('last decoded frame black within one-level RGB codec rounding',ok and int(last.max())<=1,maxRGB=int(last.max()) if ok else None,meanRGB=float(last.mean()) if ok else None)
for t,n in [(37.7,'Final_Cue'),(176,'Final_Color'),(196,'Final_MMD'),(10,'Final_Early')]:
 cap.set(cv2.CAP_PROP_POS_MSEC,t*1000);ok,f=cap.read();ck(f'frame{t}s decodable',ok);cv2.imwrite(str(R/f'render/{n}.jpg'),f,[cv2.IMWRITE_JPEG_QUALITY,95])
cap.release()
rows=[]
for i in range(6):
 d=json.loads((R/f'render/part{i}.json').read_text());ck(f'part{i}complete',d.get('complete') and d['frames']==(2190 if i<5 else 2280))
 rows.extend(json.loads((R/f'render/counts{i}.json').read_text()))
# Log schema is from render_r91.py; all audit samples must remain cut away.
ck('all logged frames retain open casing',all(x.get('closed')==0 for x in rows),samples=len(rows))
ck('all logged full-stage frames have two magnifier leaders',all(x.get('leaders')==2 for x in rows if x['sourceTime']<219))
record=R/'render/browser_record.webm';p=subprocess.run(['ffmpeg','-v','error','-i',str(record),'-f','null','-'],stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,text=True);ck('actual browser recording decodes',p.returncode==0 and not p.stderr.strip())
# Render/UI revision must not silently alter the numerical physics or source composite.
old=Path('/mnt/data/r9_source/Light_Loom_R9')
for rel in ['src/optics.c','src/optics.js','assets/optics.wasm','assets/source.mp4','assets/timeline.json']:
 if (old/rel).exists():ck(f'{rel} unchanged from R9',hashlib.sha256((R/rel).read_bytes()).digest()==hashlib.sha256((old/rel).read_bytes()).digest())
res=dict(revision='R9.1',checks=checks,passed=all(x['passed']for x in checks),size=P.stat().st_size,sha256=hashlib.sha256(P.read_bytes()).hexdigest(),format=info['format'])
(R/'render/delivery_qc_r91.json').write_text(json.dumps(res,ensure_ascii=False,indent=2));print(json.dumps(res,ensure_ascii=False,indent=2))
