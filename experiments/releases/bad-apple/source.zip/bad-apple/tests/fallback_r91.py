from pathlib import Path
import json
from playwright.sync_api import sync_playwright
from load_r91 import load
R=Path(__file__).resolve().parents[1];checks=[]
def ck(n,v):
 checks.append(dict(name=n,passed=bool(v)));assert v,n
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage']);page=b.new_page(viewport={'width':960,'height':1280});errs=[];page.on('pageerror',lambda e:errs.append(str(e)))
 load(page,fallback=True);page.evaluate('LOOM2.pause();LOOM2.setClean(true);LOOM2.seek(10)');page.wait_for_timeout(350);page.evaluate('LOOM2.captureNow();LOOM2.paint()')
 st=page.evaluate('LOOM2.stats()');ck('no native WASM field in fallback',page.evaluate('!LOOM2.field.native'));ck('JS fallback at real48x36',st['analysis']==[48,36]);ck('positive computed receiver energy',page.evaluate('LOOM2.energy()>0'));ck('two same-chip leaders in fallback',page.evaluate('LOOM2.scene.magnifierLeaders.length===2'))
 i=page.evaluate('LOOM2.field.duty.findIndex(v=>v>.1)');page.evaluate('(i)=>{LOOM2.isolate(i);LOOM2.paint()}',i);ck('single address one beam in fallback',page.evaluate('LOOM2.beamIDs.length===1'));page.evaluate('document.getElementById("lamp").click();LOOM2.paint()');ck('lamp off zero receiver in fallback',page.evaluate('LOOM2.energy()===0'));ck('no fallback page errors',len(errs)==0);b.close()
(R/'render/fallback_qc_r91.json').write_text(json.dumps(dict(checks=checks,passed=all(c['passed']for c in checks),errors=errs,stats=st),ensure_ascii=False,indent=2));print(checks)
