from pathlib import Path
import re,time,base64,hashlib
R=Path(__file__).resolve().parents[1]
def load(page,fallback=False):
 t=time.time();text=(R/'Light_Loom_Studio_R9_1.html').read_text();assets={}
 def take(m):
  assets[m[1]]=m[2];return '<script id="'+m[1]+'" type="application/octet-stream"></script>'
 shell=re.sub(r'<script id="([\w-]+)" type="application/octet-stream">(.*?)</script>',take,text,flags=re.S).replace('boot();','window.__startLoom=boot;')
 if fallback:shell=shell.replace('await setupLoomWasm();','/* forced JS fallback */')
 print('set shell',len(shell),[(k,len(v))for k,v in assets.items()],flush=True)
 page.set_content(shell,timeout=15000,wait_until='domcontentloaded')
 folder=R/'tests/asset_fixtures';folder.mkdir(exist_ok=True)
 page.evaluate("""()=>{let x=document.createElement('input');x.type='file';x.id='qa-assets';x.hidden=true;document.body.append(x)}""")
 for name,data in assets.items():
  dest=folder/name;dest.write_bytes(base64.b64decode(data))
  page.set_input_files('#qa-assets',str(dest))
  page.evaluate("""(n)=>new Promise((resolve,reject)=>{
   const f=document.getElementById('qa-assets').files[0],r=new FileReader();
   r.onload=()=>{const s=r.result;document.getElementById(n).textContent=s.slice(s.indexOf(',')+1);resolve(true);};
   r.onerror=()=>reject(r.error);r.readAsDataURL(f);
  })""",name)
  print('asset ok',name,time.time()-t,flush=True)
 page.evaluate("document.getElementById('qa-assets').remove();window.__startLoom()")
 page.wait_for_function('window.LOOM2 && LOOM2.ready && LOOM2.stats().sourceFrames>0 && !document.getElementById("media").seeking',timeout=45000)
 print('ready',time.time()-t,flush=True)
