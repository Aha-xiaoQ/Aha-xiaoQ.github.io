# 素材来源与技术参考

## 影像素材

黑白、彩色和 MMD 阶段使用以下 B 站视频；灰度阶段由同一彩色视频转换。

- 黑白影绘：[BV1Wx411c7JT](https://www.bilibili.com/video/BV1Wx411c7JT/)
- 彩色重绘（含灰度阶段）：[BV1P78t68EMj](https://www.bilibili.com/video/BV1P78t68EMj/)
- MMD 动画：[BV1ce411N7Kd](https://www.bilibili.com/video/BV1ce411N7Kd/)

影绘原作：【東方】Bad Apple!! ＰＶ【影絵】（sm8628149）。
原作链接：https://www.nicovideo.jp/watch/sm8628149
MMD 的模型、动作、场景及特效署名请参阅对应视频说明和片尾。`../credits/MMD_credit_*.jpg` 保留原片署名截帧，`../credits/media_manifest.json` 记录输入文件的大小、哈希与媒体参数。

## 音乐

Bad Apple!! feat. nomico / Alstroemeria Records。
原曲作曲：ZUN；编曲：Masayoshi Minoshima；作词：Haruka；演唱：nomico。
曲目信息：https://alst.net/argm0001/

合成段落的旋律/时值参考 Online Sequencer 的 097 序列与 tugopingu 的整理：
- https://onlinesequencer.net/4140941
- https://github.com/tugopingu/badapple-picobricks

## 技术参考与字体

- DMD 微镜结构概念：https://www.ti.com/product/DLP6500FYE
- 散射方向权重：https://pbr-book.org/4ed/Volume_Scattering/Phase_Functions
- 成片字体：思源黑体、霞鹜文楷。

放映室采用简化的数值模型与艺术化的光束显示，用于观察成像关系。源代码中的投影分辨率和装置几何不对应某款实际投影设备。

## 权利说明

本片为非官方同人 MV，含 AI 辅助制作内容。音乐、角色及影像权益归相应权利人。代码许可仅覆盖可许可的项目代码，不覆盖第三方音乐、录音、影像、模型或字体；修改与再分发时须遵守各素材原有的使用约定。
