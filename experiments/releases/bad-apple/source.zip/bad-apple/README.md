# Bad Apple!! · 光织放映室

一间从黑白影绘走向彩色与 MMD 的交互放映室。这个包提供网页动画、计算源码、制作工具、测试与素材清单，以及成片阶段字幕和声音交接的修订脚本。

完整 MV：https://www.bilibili.com/video/BV15pao6iEzF/

## 运行交互动画

需要 Python 3 和支持 H.264/AAC/FLAC、Canvas、Web Audio 的现代浏览器。先从作品页面打开 HTML 动画，复制浏览器中的完整网址；把下面的 `ANIMATION_URL` 换成这个网址，在本目录运行：

```sh
python fetch_media.py "ANIMATION_URL"
python -m http.server 8000
```

第一条命令从作品所在的网站下载配套媒体并校验大小与 SHA-256。
然后在浏览器打开 http://localhost:8000/animation.html ，点击播放。

可用空格播放/暂停、H 切换纯净观看、M 查看微镜、F 进入全屏。也可导入本地视频或音轨；导入文件在浏览器内处理。

## 文件与素材

- `src/`：网页与 C/JS 光学源码。
- `tools/`：媒体处理、网页构建与离线渲染工具。
- `final-edit/`：阶段字幕与声音交接脚本。
- `media-manifest.json`：配套媒体清单与校验值。
- `original/README.md`：开发与重建说明。
- `original/THIRD_PARTY.md`：影像、音乐及技术参考。
- `credits/`：输入文件参数与 MMD 片尾署名截帧。

交互动画保留放映室主片；完整 MV 另有阶段字幕、声音交接与竖屏专属片尾。配套媒体单独下载；重新剪辑或渲染成片还需要原始素材和相应开发环境。

音乐、角色及影像权益归相应权利人；代码许可不覆盖第三方媒体。成片字体为思源黑体与霞鹜文楷，字体文件不随包提供。制作脚本可通过 `LOOM_FONT` 指定本地字体。
