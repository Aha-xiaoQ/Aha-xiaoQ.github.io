'use strict';
(()=>{
const $=id=>document.getElementById(id),video=$('media'),external=$('external-audio'),synthMedia=$('synth-audio'),scene=new LoomScene($('stage'));
let field={N:0,fw:0,fh:0,rw:0,rh:0,ready:false},ready=false,playing=false,firstPlay=true,isBuiltin=true,duration=219,sourceName='Bad Apple · 放映室进化',videoURL=null,audioURL=null,builtinURL=null;
let hasExternal=false,offset=0,mode='evolution',fault=0,lamp=true,clean=false,quality='e48',followColor=true,showReference=false,showRays=true,camera='stage',showIncident=true,showNormals=true,beamStyle='cinema',cutaway=true,haze=1;
let pixelEvolution=true,verificationShots=false,showArrayPanel=true,eightURL=null,evolutionURL=null,eightEvents=[],evolutionKeys=null,timeline=null,proofLast=null,proofSelection=null;
let stoppedAt=0,ending=false,endingClock=0,dirty=true,lastCaptureClock=-1e6,sourceTime=0,lastPaint=0,fps=60,draws=0,performanceStart=performance.now(),toastTimer;
const audioSettings=JSON.parse(document.getElementById('audio-settings').textContent);
let context=null,analyser=null,master=null,dry=null,videoSelect=null,audioSelect=null,destination=null,oscillators=[],audioData=null,liveScale=.15,externalEnabled=false;
const spectra=new Float32Array(72);let spectrumKeys=null,spectralMix=0;
const notes=new Float32Array(72),previousNotes=new Float32Array(72),attackNotes=new Float32Array(72);
let originalEnvelopes=null,builtinEnvelopes=null,legacyEnvelopes=null,chipEvents=[],lightboxEvents=[],lightboxDrums=[],crystalURL=null,legacyURL=null,synthKind=null,synthGain=null,airGain=null,triggerCount=0;
let opticalWorker=null,workerBusy=false,workerJob=0,workerEpoch=0,workerFrames=0;
function invalidateWorker(){workerEpoch++;}
function submitLiveFrame(stamp){updateEvolutionQuality(stamp);if(isBuiltin&&pixelEvolution&&verificationShots&&(probeKind(stamp)[0]||proofLast)){captureFrame(stamp);return;}if(!opticalWorker){captureFrame(stamp);return;}if(workerBusy||!ready||ending||video.readyState<2)return;try{const frame=new VideoFrame(video,{timestamp:Math.round(stamp*1e6)});workerBusy=true;workerJob++;opticalWorker.postMessage({type:'frame',id:workerJob,epoch:workerEpoch,frame,time:stamp,quality,followColor:followColor&&(!isBuiltin||stamp>=145),bass:notes[0],fault,power:lamp?1:0,focus:field.focus,aperture:field.aperture,isolate:field.isolate,spot:field.spot},[frame]);}catch(e){workerBusy=false;console.warn(e);captureFrame(stamp);}}
function acceptWorker(m){if(m.id===workerJob)workerBusy=false;if(m.epoch!==workerEpoch||!ready||ending||!playing||m.quality!==quality||Math.abs(m.aspect-field.aspect)>.001)return;
 field.setFrame(m.input,followColor&&(!isBuiltin||m.time>=145));field.image.data.set(m.pixels);field.rc.putImageData(field.image,0,0);field.rms=m.rms;field.live=m.live;if(m.reference){reference.width=m.refWidth;reference.height=m.refHeight;refCtx.putImageData(new ImageData(m.reference,m.refWidth,m.refHeight),0,0);}sourceTime=m.time;sourceFrames++;workerFrames++;lastCaptureClock=performance.now();window.__captureCost=m.cost;dirty=true;}
function workerFailure(m){console.warn('Worker stopped; continuing with main-thread solver.',m);if(opticalWorker)opticalWorker.terminate();opticalWorker=null;workerBusy=false;}
const capture=document.createElement('canvas'),captureCtx=capture.getContext('2d',{willReadFrequently:true});
const control=document.createElement('canvas'),controlCtx=control.getContext('2d',{willReadFrequently:true});
const reference=$('reference-view'),refCtx=reference.getContext('2d',{alpha:false});
let recorder=null,chunks=[],recording=false,previousClean=false,scrubbing=false,wasPlayingBeforeScrub=false,drawFPS=0,sourceFrames=0;
function notify(text,millis=4300){$('toast').textContent=text;$('toast').classList.remove('hidden');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('toast').classList.add('hidden'),millis);}
function timecode(t){if(!Number.isFinite(t))return '00:00';t=Math.max(0,t);return `${String(Math.floor(t/60)).padStart(2,'0')}:${String(Math.floor(t%60)).padStart(2,'0')}`;}
function mediaTime(){if(stoppedAt>=duration&&!playing&&!ending)return duration+1.5;return ending?duration+(performance.now()-endingClock)/1000:Math.min(duration,video.currentTime||0);}
function setClean(v){clean=v;document.body.classList.toggle('clean',v);dirty=true;}
function setDrawer(v){$('drawer').classList.toggle('hidden',!v);$('settings').setAttribute('aria-expanded',String(v));}
function positionReference(){const h=document.querySelector('.topbar').getBoundingClientRect();document.documentElement.style.setProperty('--reference-top',Math.ceil(h.bottom+16)+'px');$('reference-panel').classList.toggle('hidden',!showReference||!ready||camera==='macro');}
function updateLabels(){positionReference();if(field.ready){$('mirror-count-note').textContent=`${field.fw} × ${field.fh} = ${field.N.toLocaleString()} 个真实控制地址。每镜 5 条采样线不增加分辨率。右下角为全阵列曝光平均；M 键进入局部特写。`;$('reference-size').textContent=`${reference.width}×${reference.height}`;}const t=mediaTime();if(timeline&&mode==='evolution'){$('audio-epoch').textContent=timeline.audio.find(a=>t>=a.start&&t<a.end)?.label||'熄灯';}else $('audio-epoch').textContent='';$('time').textContent=`${timecode(Math.min(t,duration))} / ${timecode(duration)}`;if(!scrubbing)$('seek').value=Math.min(t,duration);
 $('play').innerHTML=playing?'<svg viewBox="0 0 24 24"><path d="M8 5v14M16 5v14" stroke-width="4"/></svg>':'<svg viewBox="0 0 24 24"><path d="m8 4 12 8-12 8z"/></svg>';$('play').setAttribute('aria-label',playing?'暂停':'播放');
 $('track-name').textContent=sourceName;$('track-meta').textContent=ready?`${video.videoWidth} × ${video.videoHeight} · ${isBuiltin?'内置高清原片':'本地视频'} · ${mode==='evolution'?'像素与声音逐段进化':mode==='eight'?'8-bit·脉冲与三角波':mode==='piano'?'光匣·事件联动':mode==='chip'?'芯片·同一乐谱':'原音·不伪造键谱'}`:'正在载入…';
 $('details').textContent=`${field.N.toLocaleString()} 个固定地址微镜 × 5 条孔径采样光线；${field.rw} × ${field.rh} 光斑缓冲。几何只在调焦、调光圈、偏转或换尺寸时更新；每个新解码帧重新累积光斑。`;
}
function decode64(text,type){const bin=atob(text.trim()),parts=[];for(let pos=0;pos<bin.length;pos+=1024*1024){const s=bin.slice(pos,pos+1024*1024),a=new Uint8Array(s.length);for(let i=0;i<s.length;i++)a[i]=s.charCodeAt(i);parts.push(a);}return new Blob(parts,{type});}
function onceMedia(el,event,timeout=18000){return new Promise((resolve,reject)=>{let timer;const done=()=>{clearTimeout(timer);el.removeEventListener(event,ok);el.removeEventListener('error',bad);};const ok=()=>{done();resolve();};const bad=()=>{done();reject(new Error('浏览器无法解码这个媒体文件，请使用 H.264/AAC MP4 或兼容的 WebM。'));};el.addEventListener(event,ok,{once:true});el.addEventListener('error',bad,{once:true});timer=setTimeout(()=>{done();reject(new Error('媒体载入超时。请检查文件是否完整，或换用兼容的编码。'));},timeout);});}
function stageFor(t){return Math.min(5,Math.floor(Math.max(0,Math.min(218.9999,t))/(219/6)));}
function updateEvolutionQuality(t){if(!isBuiltin||!pixelEvolution)return;const q='e'+[48,96,180,360,540,720][stageFor(t)];if(q!==quality||field.N===0){quality=q;$('quality').value=q;resetBuffers();}}
function probeKind(t){if(!verificationShots)return [null,0];if(t>=118.2&&t<120.8)return ['single',smooth(118.2,118.6,t)*(1-smooth(120.4,120.8,t))];if(t>=140.2&&t<142.8)return ['cross',smooth(140.2,140.6,t)*(1-smooth(142.4,142.8,t))];return [null,0];}
function applyProof(rgba,t){if(!isBuiltin||!pixelEvolution){field.proof=null;return;}const [kind,a]=probeKind(t);if(kind!==proofLast){invalidateWorker();proofSelection=null;}proofLast=kind;field.proof=a>.99?kind:null;field.proofID=null;if(!kind)return;
 if(kind==='single'&&proofSelection===null){const bright=[];for(let i=0;i<field.N;i++)if(rgba[i*4]>127)bright.push(i);proofSelection=bright.length?bright[Math.floor(bright.length/2)]:Math.floor(field.N/2);}
 field.proofID=kind==='single'?proofSelection:null;const cx=Math.floor(field.fw/2),cy=Math.floor(field.fh/2);
 for(let i=0;i<field.N;i++){const x=i%field.fw,y=Math.floor(i/field.fw);const on=kind==='single'?i===proofSelection:(x===cx&&Math.abs(y-cy)<=24&&(y-cy)%4===0)||(y===cy&&Math.abs(x-cx)<=24&&(x-cx)%4===0);for(let c=0;c<3;c++)rgba[i*4+c]=Math.round(rgba[i*4+c]*(1-a)+(on?255:0)*a);}
}
function resetBuffers(){invalidateWorker();const aspect=(video.videoWidth||4)/(video.videoHeight||3);field=window.LoomWasm?new NativeLightField(quality,aspect):new LightField(quality,aspect);control.width=field.fw;control.height=field.fh;
 const w=Math.max(2,Math.round(Math.min(720,video.videoWidth||1440,720*aspect)));capture.width=w;capture.height=Math.max(2,Math.min(720,Math.round(w/aspect)));reference.width=capture.width;reference.height=capture.height;sourceFrames=0;}
function captureFrame(stamp){updateEvolutionQuality(stamp);if(!ready||video.seeking||video.readyState<2||!video.videoWidth)return;
 const started=performance.now();try{
  captureCtx.drawImage(video,0,0,capture.width,capture.height);const s1=performance.now();
  // The reference and controller are derived from THIS SAME captured frame.
  controlCtx.drawImage(capture,0,0,field.fw,field.fh);refCtx.drawImage(capture,0,0,reference.width,reference.height);
  const rgba=controlCtx.getImageData(0,0,field.fw,field.fh).data,s2=performance.now();applyProof(rgba,stamp);field.setFrame(rgba,followColor&&(!isBuiltin||stamp>=145));const s3=performance.now();sourceTime=Number.isFinite(stamp)?stamp:video.currentTime;
  field.solve(sourceTime,notes[0],fault,lamp?1:0,true);window.__costParts=[s1-started,s2-s1,s3-s2,performance.now()-s3];sourceFrames++;dirty=true;lastCaptureClock=performance.now();
 }catch(err){playing=false;video.pause();external.pause();synthMedia.pause();applyAudioRouting();notify('无法读取此视频的像素。请通过“导入视频”选择本地文件。',7000);console.error(err);}
 window.__captureCost=performance.now()-started;
}
function registerFrameCallback(){if(!('requestVideoFrameCallback' in video))return;video.requestVideoFrameCallback((now,meta)=>{registerFrameCallback();window.__rvfcCount=(window.__rvfcCount||0)+1;if(ready&&!ending&&!video.seeking&&(!video.paused||dirty)){if(playing)submitLiveFrame(meta.mediaTime);else captureFrame(meta.mediaTime);}});}
function ensureAudio(){if(context)return context.resume();
 context=new (window.AudioContext||window.webkitAudioContext)();master=context.createGain();master.gain.value=+$('volume').value;
 // R8 fixed calibrated headroom, no hidden broadband compressor.
 master.connect(context.destination);destination=context.createMediaStreamDestination();master.connect(destination);
 analyser=context.createAnalyser();analyser.fftSize=8192;analyser.smoothingTimeConstant=.55;audioData=new Float32Array(analyser.frequencyBinCount);
 dry=context.createGain();analyser.connect(dry);dry.connect(master);
 videoSelect=context.createGain();audioSelect=context.createGain();context.createMediaElementSource(video).connect(videoSelect);context.createMediaElementSource(external).connect(audioSelect);videoSelect.connect(analyser);audioSelect.connect(analyser);
 // Imported-media instrument: sparse triggered, damped plucks; no 72-note drone.
 for(let n=0;n<72;n++){
   const gain=context.createGain(),strikeGain=context.createGain(),pan=context.createStereoPanner();
   gain.gain.value=0;strikeGain.gain.value=0;pan.pan.value=(n/71-.5)*.65;gain.connect(pan);pan.connect(master);
   oscillators.push({gain,strikeGain,buffer:null,lastTrigger:-100,lastAmplitude:0,held:0});
 }
 synthGain=context.createGain();synthGain.gain.value=0;context.createMediaElementSource(synthMedia).connect(synthGain);synthGain.connect(master);
 applyAudioRouting();return context.resume();
}
function pluckBuffer(n){
 const o=oscillators[n];if(o.buffer)return o.buffer;
 const sr=context.sampleRate,f=440*2**((n+36-69)/12),len=Math.round(sr*1.25),buf=context.createBuffer(1,len,sr),a=buf.getChannelData(0);let peak=0;
 for(let k=0;k<len;k++){const t=k/sr;let v=0;for(let h=1;h<=12&&f*h<15000;h++){let w=Math.sin(Math.PI*h*.18)/Math.pow(h,1.35)*(h===1?1.75:h===2?.8:1);v+=w*Math.sin(2*Math.PI*f*h*t)*Math.exp(-t/(.92/(1+.19*(h-1))));}v*=Math.min(1,t/.0032)*Math.exp(-Math.max(0,t-.20)/.20);a[k]=v;peak=Math.max(peak,Math.abs(v));}
 for(let k=0;k<len;k++)a[k]/=Math.max(peak,.00001);o.buffer=buf;return buf;
}
function livePlucks(spectral){
 const now=context.currentTime;
 const candidates=[];
 for(let n=1;n<61;n++){let a=spectral[n];if(a>.045&&a>=spectral[n-1]&&a>=spectral[n+1])candidates.push([n,a]);}
 candidates.sort((a,b)=>b[1]-a[1]);let chosen=[];
 for(const [n,a]of candidates){if(chosen.some(([k])=>Math.abs(k-n)<3||[12,19,24,28].includes(Math.abs(k-n))))continue;chosen.push([n,a]);if(chosen.length===3)break;}
 const keep=new Set(chosen.map(a=>a[0]));
 for(let n=0;n<72;n++){
  const o=oscillators[n],a=spectral[n];o.held=keep.has(n)?o.held+1:0;
  if(o.held>=2&&now-o.lastTrigger>.115&&(a-o.lastAmplitude>.07||o.held===2||now-o.lastTrigger>.32&&a>.07)){
   const src=context.createBufferSource();src.buffer=pluckBuffer(n);src.connect(o.gain);targetParam(o.gain.gain,.28*Math.sqrt(Math.min(1,a)),.004);src.start();triggerCount++;o.lastTrigger=now;o.lastVelocity=Math.min(1,a);window.__lastVoice={midi:n+36,frequency:440*2**((n+36-69)/12),time:now};
  }
  o.lastAmplitude=a;const age=now-o.lastTrigger;notes[n]=age<1.25?Math.exp(-age/.25)*(o.lastVelocity||0):0;
 }
}
function targetParam(p,value,tau=.018){if(!context)return;p.setTargetAtTime(value,context.currentTime,tau);}
function usingBuiltinSynth(){return isBuiltin&&!hasExternal&&['piano','chip','eight','evolution'].includes(mode);}
function silenceVoices(){if(!context)return;for(const o of oscillators){targetParam(o.gain.gain,0,.012);targetParam(o.strikeGain.gain,0,.012);}if(airGain)targetParam(airGain.gain,0,.012);}
function applyAudioRouting(){for(const kind of ['chip','eight','evolution'])$(kind+'-mode').disabled=!isBuiltin||hasExternal;$('chip-mode').title=(!isBuiltin||hasExternal)?'固定乐谱仅适用于内置 Bad Apple':'同一旋律 · 清晰起音与分段响度校准';if(!context)return;
 targetParam(videoSelect.gain,hasExternal?0:1);targetParam(audioSelect.gain,hasExternal&&externalEnabled?1:0);
 targetParam(dry.gain,mode==='original'&&playing?(isBuiltin&&!hasExternal?audioSettings.originalGain:1):0);targetParam(master.gain,+$('volume').value);
 targetParam(synthGain.gain,usingBuiltinSynth()&&playing?(mode==='piano'?(audioSettings.legacyLightboxGain||1):1):0);
 if(mode!=='piano'||!playing||usingBuiltinSynth())silenceVoices();
 if(!usingBuiltinSynth()||!playing)synthMedia.pause();
}
async function prepareBuiltinSynth(){if(!usingBuiltinSynth())return;const want=mode;if(synthKind!==want){
 const p=onceMedia(synthMedia,'loadeddata');synthMedia.src=({chip:legacyURL,piano:crystalURL,eight:eightURL,evolution:evolutionURL})[want];synthKind=want;await p;
}
 synthMedia.playbackRate=video.playbackRate;
 const t=Math.min(video.currentTime||0,Math.max(0,synthMedia.duration-.005));
 if(synthMedia.seeking){await onceMedia(synthMedia,'seeked',15000);}
 if(Math.abs(synthMedia.currentTime-t)>.012){const p=onceMedia(synthMedia,'seeked',15000);synthMedia.currentTime=t;await p;}
}
function syncSynth(force=false){if(!usingBuiltinSynth()||!synthKind||synthMedia.seeking||synthMedia.readyState<2)return;
 const t=video.currentTime||0;synthMedia.playbackRate=video.playbackRate;
 const drift=Math.abs(synthMedia.currentTime-t);
 if((force&&drift>.012)||drift>.10)synthMedia.currentTime=Math.min(t,Math.max(0,synthMedia.duration-.005));
 if(playing&&synthMedia.paused&&t<synthMedia.duration)synthMedia.play().catch(()=>{});
 if(!playing&&!synthMedia.paused)synthMedia.pause();
}
function syncExternal(force=false){if(!hasExternal)return;const t=(video.currentTime||0)+offset;
 if(t<0||t>=(external.duration||Infinity)){externalEnabled=false;external.pause();applyAudioRouting();return;}
 externalEnabled=true;if(force||Math.abs(external.currentTime-t)>.065)external.currentTime=t;external.playbackRate=video.playbackRate;
 if(playing&&external.paused)external.play().catch(()=>{});if(!playing&&!external.paused)external.pause();applyAudioRouting();}
function scoreKeys(events,t,out){out.fill(0);let lo=0,hi=events.length;while(lo<hi){let m=(lo+hi)>>1;if(events[m].t<=t+1/60)lo=m+1;else hi=m;}
 for(let i=lo-1;i>=0;i--){const e=events[i];if(t-e.t>3)break;let k=e.midi-36;if(k<0||k>=out.length)continue;let overlap=Math.max(0,Math.min(t+1/60,e.t+e.d)-Math.max(t,e.t))*60,release=t-(e.t+e.d),glow=release>=0&&release<.10?.13*Math.exp(-release/.035):0;out[k]=Math.max(out[k],Math.min(1,overlap+glow));}}
function updateSpectra(){
 const clock=playing&&usingBuiltinSynth()&&synthMedia.readyState>=2?synthMedia.currentTime:video.currentTime||0;
 spectralMix=mode==='original'?1:mode==='evolution'?Math.sin(clamp((clock-108.5)/2,0,1)*Math.PI/2)**2:0;
 if(!spectralMix){spectra.fill(0);return;}
 if(isBuiltin&&!hasExternal&&spectrumKeys){const i=clamp(Math.floor(clock*60),0,13229)*72;for(let k=0;k<72;k++)spectra[k]=spectrumKeys[i+k]/255;return;}
 if(!analyser||!playing){spectra.fill(0);return;}
 analyser.getFloatFrequencyData(audioData);const df=context.sampleRate/analyser.fftSize;
 for(let k=0;k<72;k++){const hz=440*2**((k+36-69)/12),b=hz/df,sd=Math.max(1,hz*.035/df);let sum=0,weight=0;for(let j=Math.max(1,Math.floor(b-3*sd));j<=Math.min(audioData.length-1,Math.ceil(b+3*sd));j++){const w=Math.exp(-.5*((j-b)/sd)**2);sum+=w*Math.pow(10,audioData[j]/10);weight+=w;}const db=10*Math.log10(sum/Math.max(weight,1e-12)+1e-15);spectra[k]=Math.pow(clamp((db+65)/40,0,1),1.35);}
}
function updateNotes(t){
 if(mode==='original'){notes.fill(0);attackNotes.fill(0);return;}
 if(isBuiltin&&!hasExternal){const clock=playing&&usingBuiltinSynth()&&synthMedia.readyState>=2?synthMedia.currentTime:video.currentTime;if(mode==='evolution'&&evolutionKeys){const frame=clamp(Math.floor(clock*60),0,13229);for(let k=0;k<72;k++)notes[k]=evolutionKeys[frame*72+k]/255;}else scoreKeys(mode==='chip'?chipEvents:mode==='eight'?eightEvents:lightboxEvents,clock,notes);return;}
 if(!playing){notes.fill(0);return;}
 if(analyser&&mode==='piano'){analyser.getFloatFrequencyData(audioData);let peak=.01;const temp=new Float32Array(72),df=context.sampleRate/analyser.fftSize;for(let n=0;n<61;n++){const f=440*2**((n+36-69)/12),bin=f/df;let sum=0,w=0;for(let j=Math.max(1,Math.floor(bin-1));j<=Math.min(audioData.length-1,Math.ceil(bin+1));j++){let ww=Math.exp(-.5*((j-bin)/.70)**2);sum+=Math.pow(10,audioData[j]/20)*ww;w+=ww;}temp[n]=sum/(w||1);peak=Math.max(peak,temp[n]);}liveScale=Math.max(.01,peak,liveScale*.996);for(let n=0;n<61;n++)temp[n]=Math.min(1,temp[n]/liveScale);livePlucks(temp);}}
let playEpoch=0;
async function play(){if(!ready)return;const ticket=++playEpoch;playing=true;updateLabels();try{await ensureAudio();if(ticket!==playEpoch)return;if(firstPlay||ending||stoppedAt>=duration||video.currentTime>=duration-.03){stoppedAt=0;video.currentTime=0;ending=false;firstPlay=false;lamp=true;$('lamp').textContent='熄灭光场';}
 playing=true;await prepareBuiltinSynth();if(ticket!==playEpoch||!playing)return;$('intro').classList.add('hidden');applyAudioRouting();await Promise.all([video.play(),...(usingBuiltinSynth()?[synthMedia.play()]:[])]);if(ticket!==playEpoch||!playing){video.pause();synthMedia.pause();return;}syncExternal(true);syncSynth(false);dirty=true;updateLabels();
 }catch(e){if(ticket!==playEpoch)return;playing=false;applyAudioRouting();notify('播放未启动，请再点击一次播放；也可以重新导入兼容格式。');console.error(e);}}
function pause(){playEpoch++;invalidateWorker();playing=false;video.pause();external.pause();synthMedia.pause();if(ready&&!ending&&stoppedAt<duration)captureFrame(video.currentTime);applyAudioRouting();for(let n=0;n<72;n++)if(context)targetParam(oscillators[n].gain.gain,0);dirty=true;updateLabels();}
function seek(t){if(!ready)return;invalidateWorker();ending=false;stoppedAt=0;firstPlay=false;t=clamp(t,0,Math.max(0,duration-.01));video.currentTime=t;dirty=true;syncExternal(true);syncSynth(true);updateLabels();}
function finish(){if(ending||stoppedAt>=duration)return;playEpoch++;invalidateWorker();captureFrame(Math.min(duration,video.currentTime));playing=false;video.pause();external.pause();synthMedia.pause();applyAudioRouting();ending=true;endingClock=performance.now();$('intro').classList.add('hidden');dirty=true;updateLabels();}
video.addEventListener('ended',finish);video.addEventListener('seeked',()=>{captureFrame(video.currentTime);syncExternal(true);syncSynth(true);dirty=true;});video.addEventListener('error',()=>{if(ready){pause();notify('媒体读取中断，请重新选择文件。',6000);}});
async function validateFile(file,kind){if(!file||file.size===0)throw new Error('文件为空。');const url=URL.createObjectURL(file),probe=document.createElement(kind);probe.preload='auto';const p=onceMedia(probe,'loadeddata',20000);probe.src=url;
 try{await p;if(!Number.isFinite(probe.duration)||probe.duration<=0)throw new Error('无法读取有效的媒体时长。');if(kind==='video'&&(!probe.videoWidth||!probe.videoHeight))throw new Error('该文件没有可用的视频轨道。');return url;}catch(e){URL.revokeObjectURL(url);throw e;}finally{probe.removeAttribute('src');probe.load();}}
async function importVideo(file){if(!file)return;notify('正在读取本地视频…',18000);let url;
 try{url=await validateFile(file,'video');if(recording)stopRecording();pause();ready=false;const old=videoURL;const p=onceMedia(video,'loadeddata');video.src=url;await p;videoURL=url;isBuiltin=false;if(['chip','eight','evolution'].includes(mode)){mode='original';for(const kind of ['chip','eight','evolution','piano'])$(kind+'-mode').classList.remove('active');$('original-mode').classList.add('active');}duration=video.duration;sourceName=file.name;ending=false;stoppedAt=0;firstPlay=false;lamp=true;fault=0;$('fault').value=0;$('fault-label').textContent='0.00°';$('lamp').textContent='熄灭光场';resetBuffers();ready=true;$('loader').classList.add('hidden');
  if(old&&old!==builtinURL)URL.revokeObjectURL(old);clearAudio(false);$('seek').max=duration;$('intro').classList.add('hidden');captureFrame(0);updateLabels();notify(`已载入：${file.name}。文件不会上传。`);dirty=true;
 }catch(e){if(url&&url!==videoURL)URL.revokeObjectURL(url);ready=!!video.videoWidth;notify(e.message||'导入失败，请换用兼容编码。',6500);console.error(e);}}
async function importAudio(file){if(!file)return;let url;
 try{url=await validateFile(file,'audio');const old=audioURL;const p=onceMedia(external,'loadeddata');external.src=url;await p;audioURL=url;hasExternal=true;if(['chip','eight','evolution'].includes(mode))switchMode('original');offset=0;$('offset').value=0;$('audio-name').textContent=file.name;$('external-audio-settings').classList.remove('hidden');await ensureAudio();syncExternal(true);if(old)URL.revokeObjectURL(old);notify('独立音轨已载入；可在设置中调整毫秒偏移。');
 }catch(e){if(url&&url!==audioURL)URL.revokeObjectURL(url);notify(e.message||'音轨导入失败。',6000);}}
async function restoreBuiltin(){if(!builtinURL)return;pause();ready=false;const old=videoURL;try{const p=onceMedia(video,'loadeddata');video.src=builtinURL;await p;videoURL=builtinURL;isBuiltin=true;sourceName='Bad Apple · 放映室进化';duration=219;ending=false;stoppedAt=0;firstPlay=false;fault=0;lamp=true;$('fault').value=0;$('fault-label').value='0.00°';$('lamp').textContent='熄灭光场';clearAudio(false);resetBuffers();ready=true;$('seek').max=duration;await prepareBuiltinSynth();captureFrame(0);if(old&&old!==builtinURL)URL.revokeObjectURL(old);updateLabels();dirty=true;notify('已恢复内置高清 Bad Apple。');}catch(e){notify(e.message);ready=!!video.videoWidth;}}
function clearAudio(message=true){hasExternal=false;externalEnabled=false;external.pause();external.removeAttribute('src');external.load();if(audioURL)URL.revokeObjectURL(audioURL);audioURL=null;offset=0;$('offset').value=0;$('audio-name').textContent='使用视频内音轨';$('external-audio-settings').classList.add('hidden');applyAudioRouting();if(message)notify('已恢复视频原音轨。');}
async function switchMode(next){
 if(['chip','eight','evolution'].includes(next)&&(!isBuiltin||hasExternal)){notify('经典芯片是内置 Bad Apple 的原版代码乐谱；导入其他媒体请用光匣或原音。',6000);return false;}
 mode=next;$('eight-mode').classList.toggle('active',next==='eight');$('evolution-mode').classList.toggle('active',next==='evolution');if(next==='evolution'){pixelEvolution=true;$('evolve-quality').checked=true;updateEvolutionQuality(video.currentTime);} $('original-mode').classList.toggle('active',next==='original');$('piano-mode').classList.toggle('active',next==='piano');$('chip-mode').classList.toggle('active',next==='chip');
 await ensureAudio();applyAudioRouting();await prepareBuiltinSynth();syncSynth(true);updateLabels();dirty=true;
 if(next==='piano')notify(usingBuiltinSynth()?'光匣：逐音符拨片、低音与木质节奏；不混入原曲。':'光匣：从当前音频选择少量音高，触发拨片；不是完整自动识谱，不套用内置乐谱。',4500);
 if(next==='chip')notify('经典芯片：固定乐谱直接驱动声音和琴键；开场低音短脉冲衔接已修复；琴键使用同一事件。',3500);return true;
}
function saveBlob(blob,name){if(!blob)return;const u=URL.createObjectURL(blob),a=document.createElement('a');a.href=u;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(u),60000);}
function saveSnapshot(){const before=clean;clean=true;paint();$('stage').toBlob(b=>{saveBlob(b,'光场织机_画面.png');clean=before;dirty=true;},'image/png');}
async function startRecording(){if(recording){stopRecording();return;}if(!window.MediaRecorder||!$('stage').captureStream){notify('当前浏览器不支持画面录制。');return;}
 try{await ensureAudio();previousClean=clean;setClean(true);recording=true;document.body.classList.add('record-active');setDrawer(false);paint();const stream=$('stage').captureStream(60);for(const tr of destination.stream.getAudioTracks())stream.addTrack(tr);
  const candidates=['video/mp4;codecs=avc1.42E01E,mp4a.40.2','video/webm;codecs=vp9,opus','video/webm;codecs=vp8,opus','video/webm'];const mime=candidates.find(x=>MediaRecorder.isTypeSupported(x));if(!mime)throw new Error('当前浏览器没有可用的录制编码器。');
  chunks=[];recorder=new MediaRecorder(stream,{mimeType:mime,videoBitsPerSecond:12_000_000,audioBitsPerSecond:192000});recorder.ondataavailable=e=>{if(e.data.size)chunks.push(e.data);};recorder.onstop=()=>{const ext=recorder.mimeType.includes('mp4')?'mp4':'webm';saveBlob(new Blob(chunks,{type:recorder.mimeType}),`光场织机_录制.${ext}`);for(const tr of stream.getVideoTracks())tr.stop();chunks=[];recording=false;document.body.classList.remove('record-active');setClean(previousClean);$('record').textContent='录制画面';$('record').classList.remove('recording');notify('录制完成，已保存纯画面视频。');};recorder.onerror=e=>{console.error(e);notify('录制中断，请降低画质或换用浏览器。');stopRecording();};
  recorder.start(1000);$('record').textContent='停止录制';$('record').classList.add('recording');if(!playing)await play();notify('正在实时录制。按 Esc 停止并保存。',2500);
 }catch(e){recording=false;document.body.classList.remove('record-active');setClean(previousClean);notify(e.message||'录制启动失败。',6000);}}
function stopRecording(){if(recorder&&recorder.state!=='inactive')recorder.stop();}
function paint(){updateSpectra();scene.spectralValues=spectra;scene.spectralMode=spectralMix;positionReference();const ts=performance.now();const transport=document.querySelector('.dock');const tr=transport?.getBoundingClientRect();const bottom=(!clean&&!recording&&tr&&tr.height>20)?(tr.top-14)*$('stage').height/innerHeight:undefined;scene.draw(field,mediaTime(),notes,{arrayPanel:showArrayPanel,arrayPanelBottom:bottom,duration,lamp,rays:showRays,comparison:showReference,reference,clean,recording,camera,incident:showIncident,normals:showNormals,beamStyle,cutaway,haze,evolution:isBuiltin&&pixelEvolution,verificationShots});updateProbe();window.__drawCost=performance.now()-ts;dirty=false;}
function loop(now){const dt=lastPaint?now-lastPaint:16.7;lastPaint=now;
 if(playing){updateNotes(video.currentTime);syncExternal(false);syncSynth(false);if(video.currentTime>=duration-.015)finish();if(now-lastCaptureClock>90&&video.readyState>=2)submitLiveFrame(video.currentTime);}
 else updateNotes(video.currentTime||0);
 if(playing||ending||dirty){paint();draws++;}
 if(ending&&now-endingClock>=1500){ending=false;stoppedAt=duration;video.currentTime=duration;scene.draw(field,duration+1.5,notes,{duration,lamp:false,comparison:false,clean,reference,camera});dirty=false;if(recording)stopRecording();}
 if(now-performanceStart>1000){drawFPS=draws*1000/(now-performanceStart);draws=0;performanceStart=now;updateLabels();}
 requestAnimationFrame(loop);
}
$('play').onclick=()=>playing?pause():play();$('start').onclick=play;$('back').onclick=()=>seek(video.currentTime-5);$('import-video').onclick=()=>$('video-file').click();$('video-file').onchange=e=>{importVideo(e.target.files[0]);e.target.value='';};$('import-audio').onclick=()=>$('audio-file').click();$('audio-file').onchange=e=>{importAudio(e.target.files[0]);e.target.value='';};$('clear-audio').onclick=()=>clearAudio();$('restore-builtin').onclick=restoreBuiltin;
$('settings').onclick=()=>setDrawer($('drawer').classList.contains('hidden'));$('close-settings').onclick=()=>setDrawer(false);$('clean').onclick=()=>setClean(!clean);$('exit-clean').onclick=()=>setClean(false);
$('original-mode').onclick=()=>switchMode('original');$('piano-mode').onclick=()=>switchMode('piano');$('chip-mode').onclick=()=>switchMode('chip');$('eight-mode').onclick=()=>switchMode('eight');$('evolution-mode').onclick=()=>switchMode('evolution');$('volume').oninput=e=>{$('volume-label').value=`${Math.round(+e.target.value*100)}%`;applyAudioRouting();};$('speed').onchange=e=>{video.playbackRate=+e.target.value;external.playbackRate=video.playbackRate;synthMedia.playbackRate=video.playbackRate;};$('offset').onchange=e=>{offset=clamp(+e.target.value||0,-600000,600000)/1000;syncExternal(true);};
$('evolve-quality').onchange=e=>{pixelEvolution=e.target.checked;updateEvolutionQuality(video.currentTime);captureFrame(video.currentTime);dirty=true;};$('verification-shots').onchange=e=>{verificationShots=e.target.checked;captureFrame(video.currentTime);dirty=true;};$('pattern-test').onclick=()=>{pause();pixelEvolution=false;$('evolve-quality').checked=false;quality='demo16';$('quality').value=quality;resetBuffers();const a=new Uint8Array(field.N*4);for(let i=0;i<field.N;i++){const x=i%field.fw,y=Math.floor(i/field.fw),on=(x===8&&Math.abs(y-6)<=3)||(y===6&&Math.abs(x-8)<=3);a.set([on?255:0,on?255:0,on?255:0,255],i*4);}field.setFrame(a,false);field.solve(0,0,0,1);dirty=true;notify('13 个亮格、13 条出射光束。点击播放恢复媒体。');};$('housing').onchange=e=>{cutaway=e.target.checked;dirty=true;};$('haze').oninput=e=>{haze=+e.target.value;$('haze-value').textContent=Math.round(haze*100)+'%';dirty=true;};
$('comparison').onchange=e=>{showReference=e.target.checked;positionReference();$('toggle-comparison').classList.toggle('active',showReference);dirty=true;};$('toggle-comparison').onclick=()=>{$('comparison').checked=!showReference;$('comparison').dispatchEvent(new Event('change'));};$('rays').onchange=e=>{showRays=e.target.checked;dirty=true;};
$('beam-style').onchange=e=>{beamStyle=e.target.value;dirty=true;};
$('incident').onchange=e=>{showIncident=e.target.checked;dirty=true;};$('normals').onchange=e=>{showNormals=e.target.checked;dirty=true;};
$('audit').onclick=()=>{const a=auditOptics(field);$('audit-result').textContent=`${a.samples.toLocaleString()} 路 · 用共享法线独立复算\n交点复算 RMS：${a.sharedNormalToStoredHitRms.toExponential(2)}\n反射角差：${a.reflectionAngleErrorDegrees.toExponential(2)}°\n接收能量：${a.receiverRgbSum.toLocaleString()} · ${a.sourceColor?'彩色加权模式':'灰度模式'}`;};
$('color').onchange=e=>{invalidateWorker();followColor=e.target.checked;captureFrame(video.currentTime);};$('camera').onchange=e=>{camera=e.target.value;scene.yaw=0;scene.zoom=1;dirty=true;};
$('array-panel').onchange=e=>{showArrayPanel=e.target.checked;dirty=true;};
$('quality').onchange=e=>{pixelEvolution=false;$('evolve-quality').checked=false;quality=e.target.value;resetBuffers();captureFrame(video.currentTime);updateLabels();notify(quality.startsWith('demo')?'已真实减少微镜数量，主幕分辨率随之下降。':'已更新真实微镜数量。');};
$('fault').oninput=e=>{invalidateWorker();fault=+e.target.value;$('fault-label').value=`${(fault*180/Math.PI).toFixed(2)}°`;field.solve(sourceTime,notes[0],fault,lamp?1:0);dirty=true;};$('calibrate').onclick=()=>{invalidateWorker();fault=0;$('fault').value=0;$('fault-label').value='0.00°';field.setOptics(0,.50,0);field.isolate=-1;$('focus-control').value=0;$('aperture-control').value=.50;$('solo-pixel').classList.remove('active');field.solve(sourceTime,notes[0],0,lamp?1:0);dirty=true;};$('lamp').onclick=()=>{invalidateWorker();lamp=!lamp;$('lamp').textContent=lamp?'熄灭光场':'点亮光场';field.solve(sourceTime,notes[0],fault,lamp?1:0);dirty=true;};
$('seek').addEventListener('pointerdown',()=>{scrubbing=true;wasPlayingBeforeScrub=playing;pause();});$('seek').oninput=e=>{firstPlay=false;seek(+e.target.value);};$('seek').addEventListener('change',()=>{scrubbing=false;if(wasPlayingBeforeScrub){wasPlayingBeforeScrub=false;play();}});
$('fullscreen').onclick=()=>{if(document.fullscreenElement)document.exitFullscreen();else document.documentElement.requestFullscreen().catch(()=>notify('当前环境不能进入全屏。'));};$('snapshot').onclick=saveSnapshot;$('record').onclick=startRecording;
$('about').onclick=()=>$('about-dialog').showModal();$('close-about').onclick=()=>$('about-dialog').close();
function updateProbe(){const box=$('pixel-inspector');const visible=scene.selected||camera==='macro';box.classList.toggle('hidden',!visible);if(!visible||!field.ready)return;const id=scene.probeID(field),r=traceRay(field,id,0,field.duty[id]>0&&(field.isolate<0||field.isolate===id)),hit=r.hit||r.absorber;
 $('pixel-title').textContent=`像素 ${r.col}, ${r.row} · 微镜 #${id}`;
 $('pixel-values').textContent=`输入灰度 / ON占空比 ${(field.duty[id]*100).toFixed(1)}%\n${r.on?'曝光平均 ON 路径':'OFF 路径 → 内部吸光腔'}\n镜面法线 ${r.n.map(x=>x.toFixed(5)).join(', ')}\n${r.hit?'屏幕交点':r.absorber?'吸收交点':'被孔径挡住'} ${hit?hit.map(x=>x.toFixed(5)).join(', '):'—'}\n投影焦距 ${(2+field.focus).toFixed(3)} · 孔径半径 ${field.aperture.toFixed(3)}`;
 $('solo-pixel').textContent=field.isolate>=0?'恢复全部像素':'只点亮这个像素';}
 $('focus-control').oninput=e=>{invalidateWorker();field.setOptics(+e.target.value,field.aperture,fault);field.solve(sourceTime,0,fault,lamp?1:0);dirty=true;};
 $('aperture-control').oninput=e=>{invalidateWorker();field.setOptics(field.focus,+e.target.value,fault);field.solve(sourceTime,0,fault,lamp?1:0);dirty=true;};
 $('solo-pixel').onclick=()=>{invalidateWorker();field.isolate=field.isolate>=0?-1:scene.probeID(field);field.solve(sourceTime,0,fault,lamp?1:0);dirty=true;};
 $('close-inspector').onclick=()=>{invalidateWorker();scene.selected=false;field.isolate=-1;if(camera==='macro'){camera='stage';$('camera').value=camera;}field.solve(sourceTime,0,fault,lamp?1:0);dirty=true;};
 $('inspect-center').onclick=()=>{scene.selected=true;setDrawer(false);dirty=true;};
 let drag=null;$('stage').onpointerdown=e=>{drag=[e.clientX,e.clientY,scene.yaw];$('stage').setPointerCapture(e.pointerId);};$('stage').onpointermove=e=>{if(!drag)return;scene.yaw=clamp(drag[2]+(e.clientX-drag[0])*.005,-4,4);dirty=true;};$('stage').onpointerup=e=>{if(drag&&Math.hypot(e.clientX-drag[0],e.clientY-drag[1])<5){const rect=$('stage').getBoundingClientRect(),i=scene.pick((e.clientX-rect.left)*$('stage').width/rect.width,(e.clientY-rect.top)*$('stage').height/rect.height,field);if(i!==null){if(field.isolate>=0){invalidateWorker();field.isolate=i;field.solve(sourceTime,0,fault,lamp?1:0);}dirty=true;}}drag=null;};$('stage').onwheel=e=>{e.preventDefault();scene.zoom=clamp(scene.zoom*Math.exp(e.deltaY*.0005),.8,1.3);dirty=true;};
let dragDepth=0;document.addEventListener('dragenter',e=>{if(e.dataTransfer.types.includes('Files')){e.preventDefault();dragDepth++;$('dropzone').classList.remove('hidden');}});document.addEventListener('dragover',e=>{if(e.dataTransfer.types.includes('Files'))e.preventDefault();});document.addEventListener('dragleave',()=>{if(--dragDepth<=0)$('dropzone').classList.add('hidden');});document.addEventListener('drop',async e=>{e.preventDefault();dragDepth=0;$('dropzone').classList.add('hidden');const a=Array.from(e.dataTransfer.files),v=a.find(f=>f.type.startsWith('video/')||/\.(mp4|webm|mkv|avi|mov|ogv|m4v)$/i.test(f.name)),au=a.find(f=>f.type.startsWith('audio/')||/\.(m4a|mp3|wav|flac|ogg|aac)$/i.test(f.name));if(v)await importVideo(v);if(au)await importAudio(au);if(!v&&!au)notify('请放入视频文件或独立音轨。');});
window.addEventListener('keydown',e=>{if(e.target.matches('input,select,textarea')||$('about-dialog').open)return;const k=e.key.toLowerCase();if(e.code==='Space'){e.preventDefault();playing?pause():play();}else if(k==='h')setClean(!clean);else if(k==='f')$('fullscreen').click();else if(k==='r')$('calibrate').click();else if(k==='m'){camera=camera==='macro'?'stage':'macro';$('camera').value=camera;scene.yaw=0;scene.zoom=1;dirty=true;}else if(e.key==='ArrowLeft')seek(video.currentTime-5);else if(e.key==='ArrowRight')seek(video.currentTime+5);else if(e.key==='Escape'){if(recording)stopRecording();else{setDrawer(false);setClean(false);}}});window.addEventListener('resize',()=>{positionReference();dirty=true;});new ResizeObserver(positionReference).observe(document.querySelector('.topbar'));
window.LOOM2={get ready(){return ready;},get timeline(){return timeline;},get audioSettings(){return audioSettings;},get arrayPanel(){return scene.arrayPanel||{visible:false};},get beamIDs(){return scene.visibleBeamIDs||[];},get evolutionKeys(){return evolutionKeys;},play,pause,seek,importVideo,importAudio,restoreBuiltin,setClean,paint,switchMode,stats:()=>({ready,playing,engine:field.native?'WebAssembly cached-geometry forward accumulation':'JavaScript forward accumulation',sourceName,sourceTime,mediaTime:video.currentTime,duration,isBuiltin,hasExternal,offset,mode,sampleCount:field.N*5,mirrorCount:field.N,geometryRebuilds:field.rebuilds,analysis:[field.fw,field.fh],receiver:[field.rw,field.rh],source:[video.videoWidth,video.videoHeight],color:field.sourceColor,rms:field.rms,coverageEntries:field.native?field.native.get_coverage_count():field.coverageIndices?.length,coverageOverflow:field.native?field.native.get_coverage_overflow():0,live:field.live,mass:field.mass,sourceFrames,worker:!!opticalWorker,workerFrames,workerBusy,videoCallbacks:window.__rvfcCount||0,drawFPS,captureCost:window.__captureCost||0,drawCost:window.__drawCost||0,costParts:window.__costParts,fault,lamp,recording,camera,showIncident,showNormals,beamStyle,cutaway,haze,canvas:[$('stage').width,$('stage').height]}),energy:()=>{let sum=0;for(let i=0;i<field.image.data.length;i+=4)sum+=field.image.data[i]+field.image.data[i+1]+field.image.data[i+2];return sum;},referencePixels:()=>Array.from(refCtx.getImageData(0,0,reference.width,reference.height).data.slice(0,16)),captureNow:()=>captureFrame(video.currentTime),endForTest:()=>{video.currentTime=duration-.02;finish();},audit:()=>auditOptics(field),audioState:()=>context?({state:context.state,compressor:false,mode,volume:master.gain.value,dry:dry.gain.value,externalEnabled,oscillators:0,pluckBankSize:oscillators.length,triggerCount,peakGain:Math.max(...oscillators.map(o=>o.gain.gain.value)),externalTime:external.currentTime,synthTime:synthMedia.currentTime,synthKind,synthPaused:synthMedia.paused,synthGain:synthGain.gain.value,builtinSynth:usingBuiltinSynth()}):null,get notes(){return Array.from(notes);},get spectra(){return Array.from(spectra);},get spectralMode(){return spectralMix;},get field(){return field;},get scene(){return scene;},scoreKeys:(t,kind='chip')=>{const a=new Float32Array(72);scoreKeys(kind==='chip'?chipEvents:kind==='eight'?eightEvents:lightboxEvents,t,a);return Array.from(a);},trace:(id,k=0,on=true)=>traceRay(field,id,k,on),setOptics:(f,a,t)=>{invalidateWorker();fault=t;field.setOptics(f,a,t);field.solve(sourceTime,0,t,lamp?1:0);dirty=true;},isolate:id=>{invalidateWorker();field.isolate=id;field.solve(sourceTime,0,fault,lamp?1:0);dirty=true;},stopRecording};
async function boot(){try{const sk=atob($('spectrum-keyframes').textContent.trim());spectrumKeys=Uint8Array.from(sk,c=>c.charCodeAt(0));$('spectrum-keyframes').remove();await setupLoomWasm();opticalWorker=await createOpticalWorker(acceptWorker,workerFailure);timeline=JSON.parse($('timeline-data').textContent);eightEvents=JSON.parse($('eight-events').textContent);const kb=atob($('evolution-keys').textContent.trim());evolutionKeys=Uint8Array.from(kb,c=>c.charCodeAt(0));$('evolution-keys').remove();eightURL=URL.createObjectURL(decode64($('eight-audio').textContent,'audio/flac'));evolutionURL=URL.createObjectURL(decode64($('evolution-audio').textContent,'audio/flac'));$('eight-audio').remove();$('evolution-audio').remove();chipEvents=JSON.parse($('chip-events').textContent);lightboxEvents=JSON.parse($('lightbox-events').textContent);lightboxDrums=JSON.parse($('lightbox-drums').textContent);
 crystalURL=URL.createObjectURL(decode64($('crystal-audio').textContent,'audio/mp4'));$('crystal-audio').remove();legacyURL=URL.createObjectURL(decode64($('legacy-audio').textContent,'audio/flac'));$('legacy-audio').remove();
 const b64=$('builtin-media').textContent.trim();if(!b64||b64==='__MEDIA_BASE64__')throw new Error('此源码模板尚未打包；请运行 build.py 或打开完整单文件版。');builtinURL=URL.createObjectURL(decode64(b64,'video/mp4'));$('builtin-media').remove();videoURL=builtinURL;
 const p=onceMedia(video,'loadeddata',30000);video.src=builtinURL;await p;resetBuffers();ready=true;duration=219;$('seek').max=duration;video.currentTime=9;await onceMedia(video,'seeked');captureFrame(9);$('loader').classList.add('hidden');$('quality').value=quality;$('housing').checked=cutaway;$('color').checked=followColor;$('comparison').checked=showReference;$('verification-shots').checked=false;$('original-mode').classList.remove('active');$('evolution-mode').classList.add('active');updateLabels();paint();registerFrameCallback();requestAnimationFrame(loop);
 }catch(e){$('load-status').textContent=e.message;$('loader').style.pointerEvents='none';$('loader').style.background='#071018b0';$('import-video').style.position='relative';$('import-video').style.zIndex=110;notify(e.message,10000);console.error(e);requestAnimationFrame(loop);}}
boot();
})();
