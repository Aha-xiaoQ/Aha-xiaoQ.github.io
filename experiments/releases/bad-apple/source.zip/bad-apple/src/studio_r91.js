/* R9.1 readability/correspondence patch. No edits to the optical accumulator. */
(()=>{
 const oldCamera=LoomScene.prototype.camera;
 LoomScene.prototype.camera=function(t,f,opts={}){oldCamera.call(this,t,f,opts);this.closed=opts.cutaway===false?1:0;};
 const fit=(c,text,size,max)=>{while(size>8){c.font=`${size}px "Noto Sans CJK SC","Microsoft YaHei",sans-serif`;if(c.measureText(text).width<=max)break;size--;}return size;};
 LoomScene.prototype.r91Layout=function(opts={}){
  const W=this.W,H=this.H,s=W/1080,scale=W/innerWidth,wide=W/H>1.1,film=opts.clean||opts.recording;
  let w=Math.round(W*.218),pad=Math.max(5,Math.round(10*s)),head=Math.max(23,Math.round(40*s)),x=Math.round(W*.027),y=Math.round(H*.635);
  if(!film&&wide){w=Math.min(Math.round(W*.145),250*scale);pad=Math.max(6,8*scale);head=Math.max(27,32*scale);x=W-w-22*scale;y=(this.r9Top||90)+14*scale;}
  if(!film&&!wide&&w<125*scale)head=Math.max(head,32*scale);
  let iw=Math.round(w-pad*2),ih=Math.round(iw*.75),h=Math.round(head+ih+pad);
  if(film)y=Math.min(y,Math.round(H*.80)-h);
  else if(!wide)y=Math.min(y,(this.r9Bottom||H*.85)-h-H*.10);
  return {x,y,w,h,pad,head,iw,ih,x2:!film&&wide?x:W-x-w,y2:!film&&wide?y+h+18*scale:y,wide,film,s,scale};
 };
 LoomScene.prototype.r9Panels=function(f,t,opts,pwr){
  const c=this.ctx,L=this.r91Layout(opts),{x,y,w,h,pad,head,iw,ih,x2,y2,s,scale}=L;
  this.labelBoxes=[];this.magnifierLeaders=[];this.panelLayout=L;
  c.save();c.textAlign='left';c.textBaseline='top';
  const titleSize=Math.max(10,Math.min(21*s,15*scale)),subSize=Math.max(9,Math.min(17*s,12*scale));
  const tile=(left,top,title,sub,texture,alpha)=>{
   c.fillStyle='#0d0d0d';c.fillRect(left,top,w,h);c.fillStyle='#181715';c.fillRect(left,top,w,head);c.strokeStyle='#5b5b5b';c.lineWidth=1;c.strokeRect(left+.5,top+.5,w-1,h-1);
   c.save();c.globalAlpha=alpha;c.drawImage(texture,left+pad,top+head,iw,ih);c.restore();
   let ss=subSize;c.font=`${ss}px ui-monospace,Consolas,monospace`;let sw=sub?c.measureText(sub).width:0;
   const stack=!!sub&&!L.film&&!L.wide&&w<125*scale;
   const fs=fit(c,title,titleSize,stack?w-pad*2:w-pad*3-sw);c.fillStyle='#dfdfdf';c.textAlign='left';c.textBaseline='middle';c.fillText(title,left+pad,top+head*(stack?.29:.5));
   if(sub){c.font=`${ss}px ui-monospace,Consolas,monospace`;c.textAlign=stack?'left':'right';c.fillStyle='#a2a2a2';c.fillText(sub,stack?left+pad:left+w-pad,top+head*(stack?.76:.5));}
   this.labelBoxes.push({text:title,box:[left,top,w,head],image:[left+pad,top+head,iw,ih],font:fs,stack});
  };
  if(opts.arrayPanel!==false){
   const corners=[[f.ow/2,0,f.oh/2],[-f.ow/2,0,f.oh/2],[-f.ow/2,0,-f.oh/2],[f.ow/2,0,-f.oh/2]],q=corners.map(p=>this.project(p));
   const near=q.slice().sort((a,b)=>a[0]-b[0]).slice(-2).sort((a,b)=>a[1]-b[1]),targets=[[x2+pad,y2+head],[x2+pad,y2+head+ih]];
   c.lineWidth=Math.max(1,1.2*s);c.strokeStyle='#929292';c.beginPath();q.forEach((p,i)=>i?c.lineTo(...p):c.moveTo(...p));c.closePath();c.stroke();
   c.strokeStyle='#6a6a6a';for(let i=0;i<2;i++){c.beginPath();c.moveTo(...near[i]);c.lineTo(...targets[i]);c.stroke();this.magnifierLeaders.push({from:near[i],to:targets[i],type:'magnifier-leader-not-light'});}
  }
  if(opts.reference)tile(x,y,'输入监看','',opts.reference,pwr);
  if(opts.arrayPanel!==false){const state=LoomArrayPanel.raster(f,iw,ih,this.r9AP||(this.r9AP={}));tile(x2,y2,'微镜阵列',`${f.fw}×${f.fh}`,state.canvas,.2+.8*pwr);this.arrayPanel={visible:true,content:[x2+pad,y2+head,iw,ih],cells:f.N,columns:f.fw,rows:f.fh,dutySum:state.sum,mode:state.mode,label:'微镜阵列',leaderCount:2};}
  else this.arrayPanel={visible:false};c.restore();
 };
 LoomScene.prototype.r9Cue=function(t,opts={}){
  this.cueText='';this.cueBox=null;if(opts.evolution===false)return;
  const stage=window.LOOM2?.timeline?.resolutions.find(s=>t>=s.start&&t<s.start+3.8);if(!stage)return;
  const c=this.ctx,W=this.W,H=this.H,L=this.panelLayout||this.r91Layout(opts),s=W/1080,sc=W/innerWidth;
  const a=smooth(stage.start,stage.start+.30,t)*(1-smooth(stage.start+3.25,stage.start+3.8,t));
  let w=W*.32,h=100*s,x=W-W*.027-w,y=Math.max(Math.max(...this.screenQuad.map(p=>p[1]))+30*s,L.y2-165*s);y=Math.min(y,L.y2-h-22*s);
  if(!L.film&&L.wide){w=L.w;h=80*sc;x=L.x;y=L.y2+L.h+16*sc;}
  if(!L.film&&!L.wide){h=Math.max(62,100*s);w=Math.max(w,168*sc);x=W-W*.027-w;y=Math.max(Math.max(...this.screenQuad.map(p=>p[1]))+10*sc,L.y2-h-12*sc);}
  const src={'黑白影绘':'黑白','灰度重绘':'灰度','彩色重绘':'彩色','MMD 终章':'MMD'}[stage.source]||stage.source,one=`${stage.w} × ${stage.h} · ${src}`,two=`${stage.timbre} · ${stage.space}`,pad=Math.max(8,15*s);
  c.save();c.globalAlpha=a;c.fillStyle='#0f0f0f';c.fillRect(x,y,w,h);c.strokeStyle='#525252';c.lineWidth=1;c.strokeRect(x+.5,y+.5,w-1,h-1);c.textAlign='left';c.textBaseline='top';
  const fs=fit(c,one,L.film?Math.max(16,29*s):Math.max(13,Math.min(26*s,19*sc)),w-pad*2);c.fillStyle='#ececec';c.fillText(one,x+pad,y+h*.15);
  fit(c,two,L.film?Math.max(12,21*s):Math.max(10,Math.min(19*s,13*sc)),w-pad*2);c.fillStyle='#adadad';c.fillText(two,x+pad,y+h*.61);
  c.restore();this.cueText=one;this.cueBox={box:[x,y,w,h],text:one,secondary:two,screenBottom:Math.max(...this.screenQuad.map(p=>p[1])),panelTop:L.y2};
 };
 LoomScene.prototype.r9Keys=function(notes,pwr){
  const add=(a,b)=>V.add(a,b),mul=(a,k)=>V.scale(a,k);this.keyPolygons=[];this.keyHighlightPolygons=[];const spec=this.spectralValues||[],mix=this.spectralMode||0;
  this.poly([[-3.02,-.11,3.32],[3.02,-.11,3.32],[3.02,-.55,5.73],[-3.02,-.55,5.73]],'#252221',95,2);
  this.poly([[-3.02,-.55,5.73],[3.02,-.55,5.73],[3.02,-.82,5.73],[-3.02,-.82,5.73]],'#1f1c1b',65);
  for(const black of [false,true])for(const [idx,kx,b]of this.keyMap){if(b!==black)continue;
   const press=notes?.[idx]||0,response=(spec[idx]||0)*mix,e=Math.max(press,response),x=(kx/this.whites-.5)*5.72,w=5.72/this.whites*(b?.58:.96),z0=3.48,z1=b?4.87:5.60,y0=b?.02:-.10,y1=(b?-.33:-.51)-press*.20;
   const q=[[x-w/2,y0,z0],[x+w/2,y0,z0],[x+w/2,y1,z1],[x-w/2,y1,z1]],front=[q[3],q[2],[q[2][0],q[2][1]-.09,q[2][2]],[q[3][0],q[3][1]-.09,q[3][2]]],tone=(b?24:163)+e*(b?167:88)*pwr;
   this.poly(front,Math.max(12,tone/2),26);this.poly(q,tone,b?10:40);this.keyPolygons.push({index:idx,midi:idx+36,energy:e,press,spectrum:response,black:b,world:q,points:q.map(v=>this.project(v))});
   if(e>.01){const cen=q.reduce((a,v)=>add(a,mul(v,.25)),[0,0,0]),qi=q.map(v=>add(cen,mul(V.sub(v,cen),.88)));this.poly(qi,null,235*e*pwr,2);this.line([add(q[3],mul(V.sub(q[0],q[3]),.035)),add(q[2],mul(V.sub(q[1],q[2]),.035))],255*e*pwr,3);this.keyHighlightPolygons.push({index:idx,points:qi.map(v=>this.project(v))});}
  }
  this.line([[-2.89,-.62,5.741],[2.89,-.62,5.741]],112);const p=this.project([-2.8,-.70,5.747]),c=this.ctx;c.save();c.textAlign='left';c.textBaseline='top';c.fillStyle='#b8b8b8';c.font=`${Math.max(9,Math.min(17*this.W/1080,13*this.W/innerWidth))}px "Noto Sans CJK SC","Microsoft YaHei",sans-serif`;this.keyFeedback=mix>.5?'原声频谱':'音符演奏';c.fillText(this.keyFeedback,p[0],p[1]);c.restore();
 };
})();
