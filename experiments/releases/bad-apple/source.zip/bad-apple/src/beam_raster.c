/* Rasterize already-traced visual ray segments, additively, in screen space.
   This is a visualization, not physical air scattering. */
#include <math.h>
#include <string.h>
static float acc[1080*1080];
void beams(const float*seg,int count,unsigned char*out,int w,int h,float exposure){
 if(w*h>1080*1080)return;memset(acc,0,w*h*sizeof(float));
 for(int k=0;k<count;k++){const float*s=seg+k*5;float dx=s[2]-s[0],dy=s[3]-s[1];int n=(int)ceilf(fmaxf(fabsf(dx),fabsf(dy)));if(n<1)n=1;if(n>10000)continue;
  for(int j=0;j<=n;j++){float x=s[0]+dx*j/n,y=s[1]+dy*j/n;int ix=(int)floorf(x),iy=(int)floorf(y);float a=x-ix,b=y-iy;
   for(int yy=0;yy<2;yy++)for(int xx=0;xx<2;xx++){int X=ix+xx,Y=iy+yy;if(X>=0&&X<w&&Y>=0&&Y<h)acc[Y*w+X]+=s[4]*(xx?a:1-a)*(yy?b:1-b);}
  }
 }
 for(int i=0;i<w*h;i++)out[i]=(unsigned char)(255*(1-expf(-acc[i]*exposure))+.5f);
}
