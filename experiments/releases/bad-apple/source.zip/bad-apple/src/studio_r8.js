/* R8: receiver data are finite mirror-area integrals. Stage graphics remain
   geometry-bound visibility aids; no synthetic detector dots or impact bursts. */
(()=>{
 const prevDraw=LoomScene.prototype.draw,prevLine=LoomScene.prototype.line;
 LoomScene.prototype.line=function(p,c,w=1){if(c===22&&p.every(v=>Math.abs(v[1]+.5)<1e-6))return;prevLine.call(this,p,c,w);};
 LoomScene.prototype.camera=function(t,f,opts={}){
  const moving=!['still','front'].includes(opts.camera),x=opts.camera==='front'?0:2.5+(moving?.5*Math.sin(t*.026):0)+this.yaw*2.3;
  this.eye=[x,23.5+(moving?.25*Math.sin(t*.037):0),118];this.f=unit(V.sub([0,2.7,-6],this.eye));this.r=unit(cross(this.f,[0,1,0]));this.u=cross(this.r,this.f);
  const ww=f.wallW,wh=f.wallH,bounds=[[-ww/2,OP.YF+wh/2,OP.SZ],[ww/2,OP.YF+wh/2,OP.SZ],[ww/2,OP.YF-wh/2,OP.SZ],[-ww/2,OP.YF-wh/2,OP.SZ],[-3.05,-.72,2.72],[3.05,-.72,2.72],[-1.8,3.8,.4]];
  const p=bounds.map(a=>{let d=V.sub(a,this.eye),z=V.dot(d,this.f);return [V.dot(d,this.r)/z,-V.dot(d,this.u)/z];});
  const mn=[0,1].map(k=>Math.min(...p.map(v=>v[k]))),mx=[0,1].map(k=>Math.max(...p.map(v=>v[k]))),film=opts.clean||opts.recording,wide=this.W/this.H>1.1;
  const scale=this.W/innerWidth,top=film?this.H*.05:Math.max(82*scale,(document.querySelector('.topbar')?.getBoundingClientRect().bottom||64)*scale+18*scale),bottom=film?this.H*.93:(opts.arrayPanelBottom??this.H*.84)-12*scale;
  const rail=!film&&wide?Math.min(240*scale,this.W*.205):0,spanW=this.W-rail;
  this.focal=Math.min(spanW*.93/(mx[0]-mn[0]),(bottom-top)/(mx[1]-mn[1]))*this.zoom;
  this.offset=[spanW*.5-(mx[0]+mn[0])*.5*this.focal,(top+bottom)*.5-(mx[1]+mn[1])*.5*this.focal];
  const pp=bounds.slice(0,4).map(v=>this.project(v)),cx=(Math.min(...pp.map(v=>v[0]))+Math.max(...pp.map(v=>v[0])))*.5;this.offset[0]+=spanW*.5-cx;
  // Screen-centering must never push the foreground piano outside a phone viewport.
  if(!film){const all=bounds.map(v=>this.project(v)),left=Math.min(...all.map(v=>v[0])),right=Math.max(...all.map(v=>v[0])),margin=10*scale;this.offset[0]+=Math.max(margin-left,Math.min(spanW-margin-right,0));}
  if(!film&&wide){const w=rail-24*scale;this.arrayLayout={x:this.W-rail+6*scale,y:top+w*.75+72*scale,w,h:w*.86};}
  else {const w=this.W*.225;this.arrayLayout={x:this.W*.96-w,y:Math.min(this.H*.646,bottom-w*.86-76*scale),w,h:w*.86};}
 };
 LoomScene.prototype.connectedRays=function(f,pwr,opts={}){
  if(!f.ready||pwr<=0||opts.rays===false){this.visibleBeamIDs=[];this.lastBeamCount=0;return;}
  const fog=opts.beamStyle==='lines'?.5:(opts.haze??1),low=f.fw<=48||!!f.proof,ids=this.ids(f),on=ids.filter(i=>f.duty[i]>0&&f.valid.subarray(i*5,i*5+5).some(v=>v>0)&&(f.isolate<0||f.isolate===i));this.visibleBeamIDs=on;this.lastBeamCount=on.length;
  const seg=[],put=(a,b,g)=>{if(g<=0)return;const P=this.project(a),Q=this.project(b);if([...P,...Q].some(x=>!Number.isFinite(x)))return;seg.push(P[0]/2,P[1]/2,Q[0]/2,Q[1]/2,g);};
  if(opts.incident!==false&&opts.cutaway!==false)for(let k=0;k<ids.length;k+=(low?1:6)){const i=ids[k];put(this.point(f,'sources',i),this.point(f,'collimators',i),.006*pwr*fog);put(this.point(f,'collimators',i),this.point(f,'centers',i),.0065*pwr*fog);}
  for(const i of on){const valid=f.valid.subarray(i*5,i*5+5),sample=valid.findIndex(v=>v>0),r=sample>0?traceRay(f,i,sample):null;const a=r?r.p:this.point(f,'centers',i),b=r?r.lens:this.point(f,'lenses',i),q=r?r.fold:this.point(f,'folds',i),hit=r?r.hit:[f.hits[i*2],f.hits[i*2+1],OP.SZ],g=f.duty[i]*pwr*(f.proof?.22:low?.090:.048)*fog*valid.reduce((s,v)=>s+v,0)/5;
   if(opts.cutaway!==false){put(a,b,g*.22);put(b,q,g*.22);}
   const start=opts.cutaway!==false?q:q.map((v,k)=>v+(hit[k]-v)*(-1.655-q[2])/(hit[2]-q[2])),v=V.sub(hit,start),direction=unit(v),len=Math.hypot(...v);
   for(let k=0;k<4;k++){const u=k/4,z=(k+1)/4,P=V.add(start,V.scale(v,u)),Q=V.add(start,V.scale(v,z)),mu=V.dot(direction,unit(V.sub(this.eye,V.scale(V.add(P,Q),.5)))),phase=(1-.24**2)/(1+.24**2-2*.24*mu)**1.5;put(P,Q,g*phase*Math.exp(-len*.010*(u+z)*.5)*1.35);}
  }
  if(opts.cutaway!==false){const off=ids.filter(i=>f.duty[i]<.015);for(let k=0;k<off.length;k+=Math.max(1,Math.floor(off.length/18))){const r=traceRay(f,off[k],0,false);if(r.absorber)put(r.p,r.absorber,.020*pwr*fog);}}
  const c=this.ctx;c.save();c.globalCompositeOperation='lighter';
  if(f.native?.draw_beams&&seg.length){const w=this.W>>1,h=this.H>>1,mem=f.native.memory.buffer;if(!this.r7Ray||this.r7Ray.width!==w||this.r7Ray.height!==h){this.r7Ray=document.createElement('canvas');this.r7Ray.width=w;this.r7Ray.height=h;this.r7RayCtx=this.r7Ray.getContext('2d',{alpha:false});}
   for(let s=0;s<seg.length;s+=100000){const a=seg.slice(s,s+100000);new Float32Array(mem,f.native.beam_segments_ptr(),a.length).set(a);f.native.draw_beams(a.length/5,w,h,1);this.r7RayCtx.putImageData(new ImageData(new Uint8ClampedArray(mem,f.native.beam_pixels_ptr(),w*h*4),w,h),0,0);c.globalAlpha=.92;c.filter=low?'blur(.55px)':'none';c.drawImage(this.r7Ray,0,0,this.W,this.H);if(opts.beamStyle!=='lines'){c.globalAlpha=.40;c.filter='blur(2.4px)';c.drawImage(this.r7Ray,0,0,this.W,this.H);}}
  }else{for(let k=0;k<seg.length;k+=5){c.strokeStyle=gray(255,Math.min(.85,seg[k+4]));c.lineWidth=low?1.8:1.0;c.beginPath();c.moveTo(seg[k]*2,seg[k+1]*2);c.lineTo(seg[k+2]*2,seg[k+3]*2);c.stroke();}}
  c.restore();this.screenImpactStampCount=0;if(this.selected)this.drawProbe(f,pwr);
 };
 LoomScene.prototype.rays=LoomScene.prototype.connectedRays;LoomScene.prototype.cinemaPaths=LoomScene.prototype.connectedRays;
 LoomScene.prototype.keys=function(notes,pwr){
  const L=5.8;this.keyPolygons=[];this.keyHighlightPolygons=[];
  this.poly([[-3.05,.14,1.01],[3.05,.14,1.01],[3.05,-.46,2.78],[-3.05,-.46,2.78]],24,96,2);this.poly([[-3.05,-.46,2.78],[3.05,-.46,2.78],[3.05,-.66,2.78],[-3.05,-.66,2.78]],33,91);this.line([[-2.96,-.45,2.79],[2.96,-.45,2.79]],136,2);
  for(const b of [false,true])for(const [idx,kx,black]of this.keyMap){if(black!==b)continue;const e=notes?.[idx]||0,x=(kx/this.whites-.5)*L,kw=L/this.whites*(black?.56:.965),z0=1.08,z1=black?2.10:2.68,y0=black?.21:.10,y1=(black?-.12:-.38)-.15*e,q=[[x-kw/2,y0,z0],[x+kw/2,y0,z0],[x+kw/2,y1,z1],[x-kw/2,y1,z1]],front=[q[3],q[2],[q[2][0],q[2][1]-.075,q[2][2]],[q[3][0],q[3][1]-.075,q[3][2]]],tone=(black?26:142)*(.30+.70*pwr)+(black?115:99)*e*pwr;
   this.poly(front,Math.max(10,tone*.5),27);this.poly(q,tone,black?13:47);this.keyPolygons.push({index:idx,midi:idx+36,black,energy:e,points:q.map(v=>this.project(v))});
   if(e>.015){const center=q.reduce((s,v)=>V.add(s,V.scale(v,.25)),[0,0,0]),inset=q.map(v=>V.add(center,V.scale(V.sub(v,center),.84)));this.poly(inset,null,235*e*pwr,2);this.line([V.add(q[3],V.scale(V.sub(q[0],q[3]),.06)),V.add(q[2],V.scale(V.sub(q[1],q[2]),.06))],255*e*pwr,3);this.keyHighlightPolygons.push({index:idx,points:inset.map(v=>this.project(v))});}
  }
 };
 LoomScene.prototype.r7Shell=function(f,pwr){
  for(const x of [-2.13,1.1])this.poly([[x,-.1,-.62],[x,-.1,.76],[x,2.31,.76],[x,2.31,-.62]],26,93);
  this.line([[-2.13,-.1,.78],[-2.13,2.32,.78],[-.92,2.32,.78]],96,3);this.line([[1.10,-.10,.78],[1.10,2.32,.78],[.69,2.32,.78]],96,3);this.line([[-2.1,-.11,.79],[1.07,-.11,.79]],152,2);
  this.line([[-1.98,2.34,.50],[-1.98,2.59,.50],[-1.11,2.59,.50],[-1.11,2.34,.50]],114,5);
  for(let y=.50;y<1.90;y+=.13)this.line([[-2.14,y,-.41],[-2.14,y,.43]],55,2);
  for(const z of [-.54,-.86,-1.18,-1.50])this.poly(this.circle([0,OP.YF,z],[0,0,1],.56),null,96);
  for(const a of [0,Math.PI/2,Math.PI,3*Math.PI/2])this.line([[.56*Math.cos(a),OP.YF+.56*Math.sin(a),-.54],[.56*Math.cos(a),OP.YF+.56*Math.sin(a),-1.50]],63);
  this.poly(this.circle([1.12,1.18,.35],[1,0,0],.18),36,151,2);
 };
 function cue(t,proof){if(proof){if(t>=117.55&&t<121.45)return [t<120.8?'单点校验':'恢复影绘',t<120.8?smooth(117.55,117.9,t):1-smooth(121.05,121.45,t)];if(t>=139.55&&t<143.45)return [t<142.8?'十字校验':'恢复影绘',t<142.8?smooth(139.55,139.9,t):1-smooth(143.05,143.45,t)];}
  for(const [at,s]of [[0,'48 × 36 · 单音'],[43.8,'96 × 72'],[73,'8-bit · 复音'],[87.6,'180 × 135'],[131.4,'360 × 270'],[146,'原声'],[175.2,'720 × 540']])if(t>=at&&t<at+2.8)return [s,smooth(at,at+.35,t)*(1-smooth(at+2.2,at+2.8,t))];return ['',0];}
 window.LoomR8Cue=cue;
 LoomScene.prototype.draw=function(f,t,notes,opts={}){this.r8Options=opts;prevDraw.call(this,f,t,notes,opts);this.cueText='';if(opts.camera==='macro'||!opts.evolution||t>=219||!this.screenQuad)return;const [s,a]=cue(t,opts.verificationShots!==false);if(!a)return;const c=this.ctx,size=clamp(this.W/1080*25,11,26),x=Math.max(12,Math.min(...this.screenQuad.map(p=>p[0]))),y=Math.max(...this.screenQuad.map(p=>p[1]))+Math.max(9,this.W/1080*19);c.save();c.font=`${size}px "Noto Sans CJK SC","Microsoft YaHei",sans-serif`;const w=c.measureText(s).width+22;c.fillStyle=gray(12,.86*a);c.fillRect(x,y,w,size+14);c.fillStyle=gray(222,a);c.textBaseline='top';c.fillText(s,x+11,y+6);c.restore();this.cueText=s;};
})();
