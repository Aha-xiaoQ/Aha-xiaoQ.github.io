/* R7: all low-grid routes use distinct controller IDs. A visible bundle is
   one address, not one copy of a fixed display sampling lattice. */
(()=>{
 const previousDraw=LoomScene.prototype.draw,previousTexture=LoomScene.prototype.texture;
 LoomScene.prototype.ids=function(f){
  if(f.isolate>=0)return [f.isolate];
  if(f.proof)return Array.from({length:f.N},(_,i)=>i).filter(i=>f.duty[i]>0);
  if(f.N<=1728)return Array.from({length:f.N},(_,i)=>i);
  const nx=Math.min(48,f.fw),ny=Math.min(36,f.fh),a=[];
  for(let y=0;y<ny;y++)for(let x=0;x<nx;x++)a.push(Math.floor((y+.5)*f.fh/ny)*f.fw+Math.floor((x+.5)*f.fw/nx));return [...new Set(a)];
 };
 LoomScene.prototype.connectedRays=function(f,pwr,opts={}){
  if(!f.ready||pwr<=0||opts.rays===false){this.visibleBeamIDs=[];return;}
  const fog=opts.haze??1,proof=!!f.proof,low=f.fw<=48||proof,ids=this.ids(f),on=ids.filter(i=>f.duty[i]>0&&f.valid[i*5]&&(f.isolate<0||i===f.isolate));this.visibleBeamIDs=on;this.lastBeamCount=on.length;
  const seg=[],put=(a,b,g)=>{const P=this.project(a),Q=this.project(b);seg.push(P[0]/2,P[1]/2,Q[0]/2,Q[1]/2,g);};
  if(opts.incident!==false&&opts.cutaway!==false){for(let k=0;k<ids.length;k+=(low?1:5)){const i=ids[k];put(this.point(f,'sources',i),this.point(f,'collimators',i),.012*pwr);put(this.point(f,'collimators',i),this.point(f,'centers',i),.014*pwr);}}
  for(const i of on){const a=this.point(f,'centers',i),b=this.point(f,'lenses',i),q=this.point(f,'folds',i),hit=[f.hits[i*2],f.hits[i*2+1],OP.SZ];const g=f.duty[i]*pwr*(proof?.30:f.fw<=24?.22:low?.12:.033)*fog;
   if(opts.cutaway!==false){put(a,b,g*.26);put(b,q,g*.26);put(q,hit,g);}else{const u=(-1.655-q[2])/(hit[2]-q[2]);put(q.map((v,k)=>v+(hit[k]-v)*u),hit,g);}
  }
  if(opts.cutaway!==false){const off=ids.filter(i=>f.duty[i]<.02);for(let k=0;k<off.length;k+=Math.max(1,Math.floor(off.length/20))){const r=traceRay(f,off[k],0,false);if(r.absorber)put(r.p,r.absorber,.021*pwr);}}
  const c=this.ctx;c.save();c.globalCompositeOperation='lighter';
  if(f.native?.draw_beams&&seg.length){
   const w=this.W>>1,h=this.H>>1,mem=f.native.memory.buffer;
   // bounded independent chunks; never silently overflow the raster input.
   if(!this.r7Ray||this.r7Ray.width!==w||this.r7Ray.height!==h){this.r7Ray=document.createElement('canvas');this.r7Ray.width=w;this.r7Ray.height=h;this.r7RayCtx=this.r7Ray.getContext('2d',{alpha:false});}
   for(let start=0;start<seg.length;start+=20000*5){const a=seg.slice(start,start+20000*5);new Float32Array(mem,f.native.beam_segments_ptr(),a.length).set(a);f.native.draw_beams(a.length/5,w,h,opts.beamStyle==='lines'?.6:1);
    this.r7RayCtx.putImageData(new ImageData(new Uint8ClampedArray(mem,f.native.beam_pixels_ptr(),w*h*4),w,h),0,0);
    c.globalAlpha=.84;c.filter=low?'blur(.55px)':'none';c.drawImage(this.r7Ray,0,0,this.W,this.H);
    if(opts.beamStyle!=='lines'){c.globalAlpha=.55;c.filter='blur(2.8px)';c.drawImage(this.r7Ray,0,0,this.W,this.H);}c.filter='none';
   }
  }else{for(let k=0;k<seg.length;k+=5){c.strokeStyle=gray(255,Math.min(.8,seg[k+4]));c.lineWidth=low?2.6:1.2;c.beginPath();c.moveTo(seg[k]*2,seg[k+1]*2);c.lineTo(seg[k+2]*2,seg[k+3]*2);c.stroke();}}
  c.globalAlpha=1;c.filter='none';
  c.restore();if(this.selected)this.drawProbe(f,pwr);
 };
 LoomScene.prototype.rays=LoomScene.prototype.connectedRays;
 LoomScene.prototype.cinemaPaths=LoomScene.prototype.connectedRays;
 LoomScene.prototype.r7Shell=function(f,pwr){
  const q=[[-2.13,-.1,-.62],[1.10,-.1,-.62],[1.10,2.31,-.62],[-2.13,2.31,-.62],[-2.13,-.1,.76],[1.10,-.1,.76],[1.10,2.31,.76],[-2.13,2.31,.76]];
  for(const [a,b]of [[0,1],[1,2],[2,3],[3,0],[4,5],[5,6],[6,7],[7,4],[0,4],[1,5],[2,6],[3,7]])this.line([q[a],q[b]],76,2);
  this.line([[-2.16,-.15,-.65],[1.13,-.15,-.65],[1.13,-.15,.79],[-2.16,-.15,.79],[-2.16,-.15,-.65]],108,2);
  this.line([[-1.95,2.34,.56],[-1.95,2.58,.56],[-.94,2.58,.56],[-.94,2.34,.56]],115,5);
  this.poly([[-2.13,-.1,-.62],[-2.13,-.1,.76],[-2.13,2.31,.76],[-2.13,2.31,-.62]],30,99);
  this.poly([[1.10,-.1,-.62],[1.10,-.1,.76],[1.10,2.31,.76],[1.10,2.31,-.62]],27,87);
  for(let y=.48;y<1.90;y+=.115)this.line([[-2.135,y,-.4],[-2.135,y,.45]],17,2);
  for(const z of [-.55,-.85,-1.15,-1.55])this.poly(this.circle([0,OP.YF,z],[0,0,1],.56),null,84,1);
  for(const a of [0,Math.PI/2,Math.PI,3*Math.PI/2])this.line([[.56*Math.cos(a),OP.YF+.56*Math.sin(a),-.55],[.56*Math.cos(a),OP.YF+.56*Math.sin(a),-1.55]],68);
  this.poly(this.circle([1.13,1.18,.35],[1,0,0],.18),31,128,2);
 };
 LoomScene.prototype.texture=function(tex,corners,gain=1,nx=6,ny=4){
  const f=this.r7Field;
  if(f&&f.N<=1728&&corners.every(p=>Math.abs(p[1])<1e-6)){
   for(let i=0;i<f.N;i++){const p=this.point(f,'centers',i),d=f.isolate<0||i===f.isolate?f.duty[i]:0,normal=unit(this.point(f,'normals',i)),tilt=Math.atan2(-normal[0],normal[1])-Math.PI/15,ang=d>0?Math.PI/15+tilt:-Math.PI/15+tilt,n=[-Math.sin(ang),Math.cos(ang),0],tx=[n[1],-n[0],0];const q=[[-1,-1],[1,-1],[1,1],[-1,1]].map(([a,b])=>V.add(p,V.add(V.scale(tx,a*f.ow/f.fw*.455),[0,0,b*f.oh/f.fh*.455])));this.poly(q,25+175*d*gain,65,.5);}return;
  }
  const c=this.ctx,old=c.imageSmoothingEnabled;if(f&&f.fw<=96&&tex===f.receiver)c.imageSmoothingEnabled=false;
  previousTexture.call(this,tex,corners,gain,nx,ny);c.imageSmoothingEnabled=old;
 };
 LoomScene.prototype.keys=function(notes,pwr){
  this.poly([[-2.52,-.07,1.08],[2.52,-.07,1.08],[2.52,-.07,2.04],[-2.52,-.07,2.04]],15,86,2);
  this.poly([[-2.52,-.07,2.04],[2.52,-.07,2.04],[2.52,-.45,2.04],[-2.52,-.45,2.04]],27,73);
  for(const b of [false,true])for(const [idx,kx,black]of this.keyMap){if(black!==b)continue;const e=notes?.[idx]||0,x=(kx/this.whites-.5)*4.72,kw=4.72/this.whites*(black?.57:.91),y=-.18+(black?.070:0),z0=1.10,z1=black?1.67:2.0,yy=y-e*.17,tone=Math.min(255,(black?24:153)*(.3+.7*pwr)+e*(black?195:102)*pwr);
   this.poly([[x-kw/2,y+.29,z0],[x+kw/2,y+.29,z0],[x+kw/2,yy,z1],[x-kw/2,yy,z1]],tone,black?25:63);
   this.poly([[x-kw/2,yy,z1],[x+kw/2,yy,z1],[x+kw/2,yy-.07,z1],[x-kw/2,yy-.07,z1]],tone*.5,45);
   if(e>.03){this.line([[x-kw*.43,yy+.008,z1-.04],[x+kw*.43,yy+.008,z1-.04]],255*e*pwr,3);this.line([[x,y+.52-e*.27,1.40],[x,y+.35-e*.27,1.55]],180*e*pwr,2);}
  }
 };
 LoomScene.prototype.microWindow=function(f,t,opts={}){LoomArrayPanel.draw(this,f,t,opts);};
 LoomScene.prototype.draw=function(f,t,notes,opts={}){
  this.r7Field=f;previousDraw.call(this,f,t,notes,opts);
  if(opts.camera!=='macro'&&opts.cutaway&&t<(opts.duration||219)+.7)this.r7Shell(f,1);
  if(opts.arrayPanel!==false&&opts.camera!=='macro'&&f.ready)this.microWindow(f,t,opts);else this.arrayPanel={visible:false};
 };
})();
