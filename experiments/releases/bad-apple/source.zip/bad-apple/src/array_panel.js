/* R7.1 whole-array inspection panel. No video texture, random animation,
   synthetic extra mirrors or fixed-size neighbourhood substitution.
   At subpixel pitch, every address contributes to an exact AREA reduction. */
(()=>{
 const caches=new Map();
 function areaAverage(input,sw,sh,dw,dh,workspace={}){
  const stride=sw+1,len=stride*(sh+1);
  if(!workspace.integral||workspace.integral.length!==len)workspace.integral=new Float64Array(len);
  const p=workspace.integral;p.fill(0,0,stride);
  for(let y=0;y<sh;y++){let sum=0,base=(y+1)*stride,prev=y*stride;p[base]=0;for(let x=0;x<sw;x++){sum+=input[y*sw+x];p[base+x+1]=p[prev+x+1]+sum;}}
  function integral(x,y){let ix=Math.min(sw-1,Math.floor(x)),iy=Math.min(sh-1,Math.floor(y)),a=x-ix,b=y-iy,k=iy*stride;return p[k+ix]*(1-a)*(1-b)+p[k+ix+1]*a*(1-b)+p[k+stride+ix]*(1-a)*b+p[k+stride+ix+1]*a*b;}
  if(!workspace.out||workspace.out.length!==dw*dh)workspace.out=new Float32Array(dw*dh);
  const out=workspace.out,sx=sw/dw,sy=sh/dh,scale=1/(sx*sy);
  for(let y=0;y<dh;y++){let y0=y*sy,y1=(y+1)*sy;for(let x=0;x<dw;x++){let x0=x*sx,x1=(x+1)*sx;out[y*dw+x]=(integral(x1,y1)-integral(x0,y1)-integral(x1,y0)+integral(x0,y0))*scale;}}
  return out;
 }
 function templates(step,nx,ny,ox,oy){
  const key=[step,nx,ny,ox,oy].map(n=>Math.round(n*1e7)/1e7).join(',');if(caches.has(key))return caches.get(key);
  const K=96,result=[];
  for(const [x,y,lit]of [[nx,ny,true],[ox,oy,false]]){const a=new Float32Array(K*K);let sum=0;
   for(let j=0;j<K;j++)for(let i=0;i<K;i++){const u=(i+.5)/K,v=(j+.5)/K,shift=-(u-.5)*x/Math.max(Math.abs(y),1e-8),edge=Math.min(.43*Math.abs(y)-Math.abs(u-.5),.35-Math.abs(v-.5-shift)),cov=clamp(edge*K+.5,0,1),b=clamp(edge*K/1.3,0,1),face=(lit?90:28)*(1-b)+(lit?205+28*u-9*v:40+12*u-5*v)*b;a[j*K+i]=13+(face-13)*cov;sum+=a[j*K+i];}
   result.push({pixels:Float32Array.from(areaAverage(a,K,K,step,step)),mean:sum/(K*K)});
  }
  if(caches.size>48)caches.clear();caches.set(key,result);return result;
 }
 function raster(f,tw,th,state){
  const w=f.fw,h=f.fh,N=f.N,normal=unit(Array.from(f.normals.subarray(0,3))),nx=normal[0],ny=normal[1],tilt=Math.atan2(-nx,ny)-Math.PI/15,ox=-Math.sin(-Math.PI/15+tilt),oy=Math.cos(-Math.PI/15+tilt),cpp=Math.min(tw/w,th/h),isolate=f.isolate??-1;
  const key=[w,h,tw,th,nx,ny,ox,oy,isolate,f.frameVersion].join('/');
  if(state.key===key&&state.owner===f)return state;state.key=key;state.owner=f;
  if(!state.effective||state.effective.length!==N)state.effective=new Float32Array(N);
  let sum=0,lit=0;for(let i=0;i<N;i++){let d=(isolate<0||i===isolate)?f.duty[i]:0;state.effective[i]=d;sum+=d;if(d>0)lit++;}
  let pixels;
  if(cpp>=2){const step=Math.max(4,Math.min(32,Math.ceil(cpp*2))),[on,off]=templates(step,nx,ny,ox,oy),sw=w*step,sh=h*step;
   if(!state.large||state.large.length!==sw*sh)state.large=new Float32Array(sw*sh);
   const a=state.large;for(let row=0;row<h;row++)for(let col=0;col<w;col++){const d=state.effective[row*w+col];for(let j=0;j<step;j++){let base=(row*step+j)*sw+col*step;for(let i=0;i<step;i++){const k=j*step+i;a[base+i]=off.pixels[k]+d*(on.pixels[k]-off.pixels[k]);}}}
   pixels=areaAverage(a,sw,sh,tw,th,state.workspace||(state.workspace={}));state.mode='resolved-exposure-faces';
  }else{const [on,off]=templates(96,nx,ny,ox,oy);pixels=areaAverage(state.effective,w,h,tw,th,state.workspace||(state.workspace={}));
   for(let i=0;i<pixels.length;i++)pixels[i]=off.mean+pixels[i]*(on.mean-off.mean);state.mode='whole-grid-area-average';
  }
  if(!state.canvas){state.canvas=document.createElement('canvas');state.ctx=state.canvas.getContext('2d',{alpha:false});}
  if(state.canvas.width!==tw||state.canvas.height!==th){state.canvas.width=tw;state.canvas.height=th;state.image=state.ctx.createImageData(tw,th);}
  for(let i=0;i<pixels.length;i++){let k=i*4,v=Math.round(clamp(pixels[i],0,255));state.image.data[k]=state.image.data[k+1]=state.image.data[k+2]=v;state.image.data[k+3]=255;}
  state.ctx.putImageData(state.image,0,0);state.sum=sum;state.lit=lit;state.cells=N;state.columns=w;state.rows=h;state.version=f.frameVersion;return state;
 }
 function draw(scene,f,t,opts={}){
  const W=scene.W,H=scene.H,L=scene.arrayLayout||{x:W*.735,y:H*.646,w:W*.225,h:W*.1935},size=Math.floor(L.w),height=Math.floor(L.h),x=Math.floor(L.x),y=Math.max(16,Math.floor(L.y)),cpp=Math.min((size-20)/f.fw,(height-34)/f.fh),tw=Math.max(2,Math.round(cpp*f.fw)),th=Math.max(2,Math.round(cpp*f.fh)),px=Math.floor((size-tw)/2),py=8,duration=opts.duration||219,fade=1-smooth(duration+.7,duration+1.5,t),pwr=(opts.lamp===false?0:1)*(1-smooth(duration,duration+1.45,t));
  const state=raster(f,tw,th,scene.r71Array||(scene.r71Array={}));const c=scene.ctx;c.save();c.globalAlpha=fade;
  // This leader refers to the complete physical array's origin, not a crop.
  const mid=scene.project([0,0,0]);c.beginPath();c.moveTo(...mid);c.lineTo(x,y+height*.5);c.strokeStyle='#3b3b3b';c.lineWidth=1;c.stroke();
  c.fillStyle='#0d0d0d';c.fillRect(x,y,size,height);c.strokeStyle='#5b5b5b';c.strokeRect(x+1,y+1,size-2,height-2);
  c.globalAlpha=fade*(.16+.84*pwr);c.drawImage(state.canvas,x+px,y+py,tw,th);c.globalAlpha=fade;c.strokeStyle='#3f3f3f';c.strokeRect(x+px-1,y+py-1,tw+2,th+2);
  c.font=`${Math.max(8,Math.min(12,size/23))}px ui-monospace,Consolas,monospace`;c.textAlign='left';c.fillStyle='#a3a3a3';c.fillText(`${f.fw} × ${f.fh}`,x+9,y+height-10);c.textAlign='right';c.fillStyle='#7f7f7f';c.fillText(f.N.toLocaleString('en-US'),x+size-9,y+height-10);c.restore();
  scene.arrayPanel={columns:f.fw,rows:f.fh,cells:f.N,mode:state.mode,visible:fade>0,x,y,size,height,content:[x+px,y+py,tw,th],dutySum:state.sum,lit:state.lit,isolated:f.isolate,version:f.frameVersion};
 }
 window.LoomArrayPanel={areaAverage,templates,raster,draw};
 const oldPick=LoomScene.prototype.pick;
 LoomScene.prototype.pick=function(x,y,f){const a=this.arrayPanel;if(!this.lastMacro&&a?.visible){const [px,py,w,h]=a.content;if(x>=px&&x<px+w&&y>=py&&y<py+h){const col=clamp(Math.floor((x-px)/w*f.fw),0,f.fw-1),row=clamp(Math.floor((y-py)/h*f.fh),0,f.fh-1);this.probeUV=[(col+.5)/f.fw,(row+.5)/f.fh];this.selected=true;return row*f.fw+col;}}return oldPick.call(this,x,y,f);};
})();
