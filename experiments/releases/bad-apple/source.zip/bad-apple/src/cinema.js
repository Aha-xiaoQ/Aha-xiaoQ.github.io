/* R6 presentation. All paths and the receiver are retained from R5's solver.
   A closed retro housing is a presentation envelope, not an extra optical lens.
   Haze is a fixed-path single-scattering-inspired display, not full volumetric RT. */
(()=>{
const oldDraw=LoomScene.prototype.draw,oldMacro=LoomScene.prototype.drawMacro;
LoomScene.prototype.solidBox=function(x0,x1,y0,y1,z0,z1,tone=38){
 this.poly([[x0,y0,z0],[x1,y0,z0],[x1,y1,z0],[x0,y1,z0]],tone-9,60);
 this.poly([[x0,y0,z0],[x0,y0,z1],[x0,y1,z1],[x0,y1,z0]],tone-5,67);
 this.poly([[x1,y0,z1],[x1,y0,z0],[x1,y1,z0],[x1,y1,z1]],tone+4,79);
 this.poly([[x0,y1,z1],[x1,y1,z1],[x1,y1,z0],[x0,y1,z0]],tone+12,97);
 const q=[[x0,y0,z1],[x1,y0,z1],[x1,y1,z1],[x0,y1,z1]],p=q.map(a=>this.project(a)),g=this.ctx.createLinearGradient(p[3][0],p[3][1],p[1][0],p[1][1]);g.addColorStop(0,gray(tone+13));g.addColorStop(.35,gray(tone));g.addColorStop(1,gray(tone-8));this.poly(q,g,88);
};
LoomScene.prototype.screw=function(p,size=.032){const q=this.circle(p,[0,0,1],size,16);this.poly(q,71,128,.7);this.line([[p[0]-size*.6,p[1],p[2]+.002],[p[0]+size*.6,p[1],p[2]+.002]],23,1);};
LoomScene.prototype.cinemaBody=function(f,pwr,opts){
 // Exit tube is hollow. Its opening is larger than the actual traced bundle.
 const rad=.61,near=this.circle([0,OP.YF,-.58],[0,0,1],rad,64),far=this.circle([0,OP.YF,-1.65],[0,0,1],rad*.9,64);
 for(let j=0;j<64;j++){let k=(j+1)%64;this.poly([near[j],near[k],far[k],far[j]],35+Math.round(38*(.5+.5*Math.cos(j*2*Math.PI/64))),null);}
 for(let z=-.7;z>=-1.6;z-=.14)this.poly(this.circle([0,OP.YF,z],[0,0,1],rad*(1-(Math.abs(z)-.58)*.09),64),null,85,1.2);
 this.poly(far,7,148,2);this.poly(this.circle([0,OP.YF,-1.655],[0,0,1],.49),null,85,1);
 // Low main enclosure plus a lamp tower and narrow optical head: the
 // forward-pointing barrel stays visible from the booth camera.
 this.solidBox(-2.1,1.07,-.1,2.30,-.61,.73,38);
 this.solidBox(-1.97,-.93,2.30,3.56,-.39,.50,34);
 this.solidBox(-.66,.68,2.30,3.20,-.54,.31,44);
 this.solidBox(-2.15,1.12,-.14,.02,-.64,.76,51);
 this.solidBox(-2.15,1.12,2.25,2.34,-.64,.76,55);
 this.solidBox(-2.00,-.90,3.52,3.62,-.42,.53,60);
 for(let y=2.56;y<3.42;y+=.11)this.line([[-1.82,y,.513],[-1.08,y,.513]],12,2.6);
 for(let y=1.24;y<1.96;y+=.115)this.line([[-1.73,y,.742],[-.47,y,.742]],12,3.0);
 this.line([[-1.85,.98,.744],[.79,.98,.744],[.79,2.12,.744],[-1.85,2.12,.744],[-1.85,.98,.744]],65,1.2);
 for(const x of [-1.95,.90])for(const y of [.19,2.10])this.screw([x,y,.75],.035);
 this.disc([.51,1.65,.77],[0,0,1],.205,pwr,false);this.poly(this.circle([.51,1.65,.81],[0,0,1],.17),49,150);this.line([[.51,1.71,.815],[.51,1.81,.815]],193,1.5);
 this.line([[-.61,2.34,.56],[-.61,2.63,.56],[.61,2.63,.56],[.61,2.34,.56]],90,5);this.line([[-.51,2.63,.56],[.51,2.63,.56]],22,4);
 if(opts.comparison!==false&&opts.reference){const x=-.84,y=.55,z=.751,w=.93,h=w/f.aspect,quad=[[x-w/2,y+h/2,z],[x+w/2,y+h/2,z],[x+w/2,y-h/2,z],[x-w/2,y-h/2,z]];this.poly(quad,0,18,7);this.texture(opts.reference,quad,pwr,2,2);this.poly(quad,null,112,1);}
 this.screw([.51,.43,.76],.05);this.line([[.38,.72,.751],[.65,.72,.751]],92,2);

};
LoomScene.prototype.cinemaPaths=function(f,pwr,opts){
 if(!f.ready||!pwr||opts.rays===false)return;const fog=opts.haze===undefined?1:opts.haze;if(fog<=0&&opts.beamStyle!=='lines')return;
 const ids=f.isolate>=0?[f.isolate]:this.ids(f),seg=[],put=(a,b,g)=>{const P=this.project(a),Q=this.project(b);seg.push(P[0]/2,P[1]/2,Q[0]/2,Q[1]/2,g);};
 // Start every external beam at the physical exit plane; never draw through
 // the opaque enclosure. The path ends at the actual computed screen hit.
 for(const i of ids){if(f.duty[i]<=.001||!f.valid[i*5]||(f.isolate>=0&&f.isolate!==i))continue;
  const q=this.point(f,'folds',i),hit=[f.hits[i*2],f.hits[i*2+1],OP.SZ],d=V.sub(hit,q),r=unit(d),u=(-1.655-q[2])/d[2],a=V.add(q,V.scale(d,u)),len=Math.hypot(...V.sub(hit,a));
  for(let k=0;k<6;k++){const s=k/6,e=(k+1)/6,P=a.map((v,j)=>v+(hit[j]-v)*s),Q=a.map((v,j)=>v+(hit[j]-v)*e),mid=P.map((v,j)=>(v+Q[j])*.5),toEye=unit(V.sub(this.eye,mid)),mu=V.dot(r,toEye),g=.24,phase=(1-g*g)/Math.pow(1+g*g-2*g*mu,1.5),atten=Math.exp(-.013*len*(s+e)/2);const w=f.duty[i]*pwr*.078*(opts.beamStyle==='lines'?.4:fog)*phase*atten;put(P,Q,w);}
 }
 const c=this.ctx;c.save();c.beginPath();c.rect(0,0,this.W,this.H);this.screenQuad.forEach((p,i)=>i?c.lineTo(...p):c.moveTo(...p));c.closePath();c.clip('evenodd');c.globalCompositeOperation='lighter';
 if(f.native?.draw_beams){const w=this.W>>1,h=this.H>>1,mem=f.native.memory.buffer;new Float32Array(mem,f.native.beam_segments_ptr(),seg.length).set(seg);f.native.draw_beams(seg.length/5,w,h,1.05);if(!this.hazeCanvas||this.hazeCanvas.width!==w||this.hazeCanvas.height!==h){this.hazeCanvas=document.createElement('canvas');this.hazeCanvas.width=w;this.hazeCanvas.height=h;this.hazeContext=this.hazeCanvas.getContext('2d',{alpha:false});}this.hazeContext.putImageData(new ImageData(new Uint8ClampedArray(mem,f.native.beam_pixels_ptr(),w*h*4),w,h),0,0);
  if(opts.beamStyle==='lines'){c.globalAlpha=.78;c.drawImage(this.hazeCanvas,0,0,this.W,this.H);}else{c.globalAlpha=.85;c.filter='blur(1.2px)';c.drawImage(this.hazeCanvas,0,0,this.W,this.H);c.globalAlpha=.46;c.filter='blur(6px)';c.drawImage(this.hazeCanvas,0,0,this.W,this.H);c.filter='none';c.globalAlpha=.20;c.drawImage(this.hazeCanvas,0,0,this.W,this.H);}
 }else{for(let i=0;i<seg.length;i+=5){c.strokeStyle=gray(255,Math.min(.22,seg[i+4]*.70));c.lineWidth=opts.beamStyle==='lines'?.7:2.6;c.beginPath();c.moveTo(seg[i]*2,seg[i+1]*2);c.lineTo(seg[i+2]*2,seg[i+3]*2);c.stroke();}}
 c.restore();
 if(this.selected){const i=this.probeID(f);if(f.valid[i*5]&&f.duty[i]>0&&(f.isolate<0||f.isolate===i)){const q=this.point(f,'folds',i),h=[f.hits[i*2],f.hits[i*2+1],OP.SZ],u=(-1.655-q[2])/(h[2]-q[2]);this.line([q.map((v,k)=>v+(h[k]-v)*u),h],gray(255,.60*pwr),1.5);}}
};
LoomScene.prototype.draw=function(f,t,notes,opts={}){
 if(opts.camera==='macro'||opts.cutaway){oldDraw.call(this,f,t,notes,opts);return;}
 this.resize();this.lastMacro=false;this.camera(t,f,opts);const c=this.ctx,W=this.W,H=this.H,pwr=(opts.lamp===false?0:1)*(1-smooth(opts.duration||219,(opts.duration||219)+1.45,t));
 c.fillStyle='#101010';c.fillRect(0,0,W,H);let g=c.createRadialGradient(W*.5,H*.5,5,W*.5,H*.5,Math.max(W,H)*.65);g.addColorStop(0,'#191919');g.addColorStop(1,'#070707');c.fillStyle=g;c.fillRect(0,0,W,H);
 // Theater surround. No grain, scratch, or vignette is baked over the source.
 const ww=f.wallW,wh=f.wallH,quad=[[-ww/2,OP.YF+wh/2,OP.SZ],[ww/2,OP.YF+wh/2,OP.SZ],[ww/2,OP.YF-wh/2,OP.SZ],[-ww/2,OP.YF-wh/2,OP.SZ]];
 this.screenQuad=quad.map(p=>this.project(p));
 this.poly([[-ww/2-.15,OP.YF+wh/2+.15,OP.SZ+.008],[ww/2+.15,OP.YF+wh/2+.15,OP.SZ+.008],[ww/2+.15,OP.YF-wh/2-.15,OP.SZ+.008],[-ww/2-.15,OP.YF-wh/2-.15,OP.SZ+.008]],18,85,1.5);
 this.poly(quad,0);if(f.ready){c.imageSmoothingEnabled=f.fw>48;this.texture(f.receiver,quad,pwr);c.imageSmoothingEnabled=true;}this.poly(quad,null,107,1);
 for(const sign of [-1,1])for(let j=0;j<18;j++){const x=sign*(ww/2+.18+j*.053),x2=x+sign*.054,col=15+Math.round(10*(.5+.5*Math.cos(j*.9)));this.poly([[x,OP.YF+wh/2+.24,OP.SZ+.06],[x2,OP.YF+wh/2+.24,OP.SZ+.06],[x2,OP.YF-wh/2-.20,OP.SZ+.06],[x,OP.YF-wh/2-.20,OP.SZ+.06]],col);}
 this.poly([[-2.65,-.20,-1.0],[2.65,-.20,-1.0],[2.65,-.20,2.00],[-2.65,-.20,2.00]],26,65);this.poly([[-2.65,-.20,2],[2.65,-.20,2],[2.65,-.55,2],[-2.65,-.55,2]],18,48);
 this.cinemaPaths(f,pwr,opts);this.cinemaBody(f,pwr,opts);this.keys(notes,pwr);
 const ambient=1-smooth((opts.duration||219)+.7,(opts.duration||219)+1.5,t);if(ambient<1){c.fillStyle=gray(0,1-ambient);c.fillRect(0,0,W,H);}
};
LoomScene.prototype.drawMacro=function(f,t,opts){
 oldMacro.call(this,f,t,opts);
 const c=this.ctx,id=this.probeID(f),x=id%f.fw,y=Math.floor(id/f.fw),W=this.W,H=this.H;
 // An actual full-chip locator makes the small visible neighbourhood explicit.
 const w=Math.min(200,W*.23),h=w/f.aspect,left=22,top=Math.max(122,(parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--reference-top'))||100)+30);
 c.fillStyle='#080808';c.fillRect(left-6,top-24,w+12,h+54);c.imageSmoothingEnabled=true;c.drawImage(this.dmdTexture(f),left,top,w,h);c.strokeStyle='#ddd';c.lineWidth=1.5;c.strokeRect(left+Math.max(0,x-10)/f.fw*w,top+Math.max(0,y-8)/f.fh*h,(Math.min(f.fw,x+11)-Math.max(0,x-10))/f.fw*w,(Math.min(f.fh,y+9)-Math.max(0,y-8))/f.fh*h);
 c.fillStyle='#e1e1dc';c.font=`${Math.max(9,Math.min(12,W/100))}px sans-serif`;c.fillText(`全芯片 ${f.fw}×${f.fh}`,left,top-8);c.fillText(`${Math.min(f.fw,x+11)-Math.max(0,x-10)}×${Math.min(f.fh,y+9)-Math.max(0,y-8)} 局部 · 全芯片 ${f.N.toLocaleString()} 镜`,left,top+h+18);
};
})();
