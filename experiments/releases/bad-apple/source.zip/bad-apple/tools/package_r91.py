from pathlib import Path
import shutil,json,zipfile,hashlib,subprocess,tempfile,time
R=Path(__file__).resolve().parents[1];OUT=Path('/mnt/data');stage=OUT/'r91_release'/'Light_Loom_R9_1'
if stage.exists():shutil.rmtree(stage)
stage.mkdir(parents=True)
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['README.md','IMPLEMENTATION.md','REFERENCES.md','THIRD_PARTY.md','BILIBILI.txt','LICENSE','requirements-dev.txt','Light_Loom_Studio_R9_1.html']:
 shutil.copy2(R/name,stage/name)
shutil.copytree(R/'src',stage/'src');shutil.copytree(R/'credits',stage/'credits')
(stage/'tools').mkdir();(stage/'tests/results').mkdir(parents=True);(stage/'tests/r8').mkdir();(stage/'assets').mkdir()
for name in ['build.py','unpack_media.py','build_wasm.sh','graphics_text.py','scene.py','scene_r9.py','scene_r91.py','array_panel.py','native_field.py','render_r91.py','assemble_r91.py','audio_r91.py','compose_sources.py','align_sources.py','audio_r9.py','package_r91.py']:
 shutil.copy2(R/'tools'/name,stage/'tools'/name)
for name in ['load_r91.py','browser_r91.py','numeric_r91.py','optics_r8.py','audio_qc_r91.py','fallback_r91.py','delivery_r91.py','reproduce_audio_r91.py','portrait_test.mp4']:
 shutil.copy2(R/'tests'/name,stage/'tests'/name)
shutil.copy2(R/'tests/r8/optics_r71_reference.c.txt',stage/'tests/r8/optics_r71_reference.c.txt')
# Embedded media are recovered by unpack_media. Keep only the supplementary
# source facts + old audio baselines needed for independently replaying this patch.
for name in ['old_chip.flac','old_chip_events.json','old_evolution.flac','old_evolution_keys.bin','original_reference.m4a','geometry.json','legacy_notes.json','poly_events.json']:
 if (R/'assets'/name).exists():shutil.copy2(R/'assets'/name,stage/'assets'/name)
parts={
 'browser':'render/browser_qc_r91.json',
 'geometry':'render/r91_numeric_qc.json',
 'independentOptics':'tests/r8/optics.json',
 'audio':'render/audio_qc_r91.json',
 'fallback':'render/fallback_qc_r91.json',
 'movie':'render/delivery_qc_r91.json',
 'audioRebuild':'render/audio_rebuild_r91.json',
 'baseline':'render/baseline_unchanged.json'}
report={'revision':'R9.1','scope':'Current revision; all tests were executed, not copied from previous release counts.','limits':'Headless Chromium; mobile viewport emulation; ideal paraxial model, not hardware verification. Frequency feedback is not note transcription. H3 and MMD original attribution still needs source links.'}
for key,p in parts.items():
 d=json.loads((R/p).read_text());report[key]=d;shutil.copy2(R/p,stage/'tests/results'/Path(p).name)
 if isinstance(d,dict):assert all(z['passed']for z in d.get('checks',[])),key
 else:assert all(z['passed']for z in d),key
report['testedHTMLSHA256']=h(R/'Light_Loom_Studio_R9_1.html')
# First archive really is extracted, then both the HTML and WASM are rebuilt.
zpath=OUT/'Light_Loom_R9_1_Source.zip'
def writezip():
 with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
  for p in sorted(stage.rglob('*')):
   if p.is_file():z.write(p,'Light_Loom_R9_1/'+p.relative_to(stage).as_posix())
writezip()
with tempfile.TemporaryDirectory(prefix='r91_unpack_verify_') as td:
 with zipfile.ZipFile(zpath)as z:
  assert z.testzip() is None;z.extractall(td)
 root=Path(td)/'Light_Loom_R9_1';before=h(root/'Light_Loom_Studio_R9_1.html')
 subprocess.run(['python',str(root/'tools/unpack_media.py')],stdout=subprocess.DEVNULL,check=True)
 subprocess.run(['python',str(root/'tools/build.py')],stdout=subprocess.DEVNULL,check=True)
 after=h(root/'Light_Loom_Studio_R9_1.html');assert before==after
 wb=h(root/'assets/optics.wasm');subprocess.run(['sh',str(root/'tools/build_wasm.sh')],stdout=subprocess.DEVNULL,check=True);wa=h(root/'assets/optics.wasm');assert wb==wa
 report['package']={'actualZIPExtracted':True,'htmlByteEqual':before==after,'htmlSHA256':after,'wasmByteEqual':wb==wa,'wasmSHA256':wa,'fontsBundled':False}
report['checkCount']=sum(len(d.get('checks',[])) for d in report.values()if isinstance(d,dict))
report['allListedChecksPassed']=True
(stage/'VERIFICATION.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));(R/'VERIFICATION.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
lines=[]
for p in sorted(stage.rglob('*')):
 if p.is_file() and p.name!='SHA256SUMS.txt':lines.append(h(p)+'  '+p.relative_to(stage).as_posix())
(stage/'SHA256SUMS.txt').write_text('\n'.join(lines)+'\n')
writezip()
with zipfile.ZipFile(zpath)as z:assert z.testzip() is None
for orig,dest in [('Light_Loom_Studio_R9_1.html','Light_Loom_Studio_R9_1.html'),('IMPLEMENTATION.md','Light_Loom_R9_1_Implementation.md'),('REFERENCES.md','Light_Loom_R9_1_References.md'),('BILIBILI.txt','Light_Loom_R9_1_Bilibili.txt'),('VERIFICATION.json','Light_Loom_R9_1_Verification.json')]:shutil.copy2(R/orig,OUT/dest)
for orig,dest in [('assets/intro_AB.flac','Light_Loom_R9_1_Intro_Comparison.flac'),('assets/intro_fixed.flac','Light_Loom_R9_1_Opening_24s.flac'),('assets/evolution.flac','Light_Loom_R9_1_Evolution_Master.flac'),('render/Final_Cue.jpg','Light_Loom_R9_1_Preview.jpg'),('render/UI_Desktop.png','Light_Loom_R9_1_UI.png'),('render/Final_MMD.jpg','Light_Loom_R9_1_Final_Stage.jpg')]:shutil.copy2(R/orig,OUT/dest)
summary={'file':str(zpath),'size':zpath.stat().st_size,'sha256':h(zpath),'HTML':report['testedHTMLSHA256'],'checks':report['checkCount'],'package':report['package']}
(R/'render/package_qc_r91.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2),flush=True)
