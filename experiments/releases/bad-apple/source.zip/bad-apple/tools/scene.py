"""Neutral-white, physically connected projection stage. Native export counterpart
of src/scene.js. All illuminated output paths use the solver's shared arrays.
"""
import numpy as np,cv2,math,ctypes as CT
from pathlib import Path
_beam=CT.CDLL(str(Path(__file__).resolve().parents[1]/"assets/beam_raster.so"))
_beam.beams.argtypes=[CT.c_void_p,CT.c_int,CT.c_void_p,CT.c_int,CT.c_int,CT.c_float]
YF=2.75;SZ=-21.45;S=2.2;I=np.array([.4067366430758002,-.9135454576426009,0.]);C=-I*3;LAMP=C-I*.66

def smooth(a,b,t):
 q=max(0.,min(1.,(t-a)/(b-a)));return q*q*q*(q*(q*6-15)+10)
def unit(v):
 a=np.asarray(v,float);return a/np.maximum(1e-15,np.linalg.norm(a,axis=-1,keepdims=True))
def power(t):return 1-smooth(219,220.45,t)
class Scene:
 def __init__(self,w=1080,h=1440):
  self.W=w;self.H=h;self.aspect=w/h;self.x=-.0;self.zoom=1.
  yy,xx=np.mgrid[:h,:w];r=((xx-w*.50)/(w*.78))**2+((yy-h*.63)/(h*.8))**2
  bg=np.clip(10+7*np.exp(-r*2),0,255).astype(np.uint8);self.background=np.repeat(bg[...,None],3,axis=2)
  self.keys=[];white=0
  for midi in range(36,97):
   black=midi%12 in [1,3,6,8,10]
   if black:self.keys.append((midi-36,white-.03,True))
   else:self.keys.append((midi-36,white+.5,False));white+=1
  self.nwhite=white
 def camera(self,t,field):
  # Long-lens view: less perspective shrinking, small continuous moves only.
  self.eye=np.array([6.5+1.5*math.sin(t*.038),34.5+.32*math.sin(t*.052),118.])
  at=np.array([0.,2.7,-6.]);f=unit(at-self.eye);r=unit(np.cross(f,[0,1,0]));u=np.cross(r,f)
  self.basis=np.stack([r,u,f],axis=1)
  ww,wh=field.ww,field.wh
  bounds=np.array([[-ww/2,YF+wh/2,SZ],[ww/2,YF+wh/2,SZ],[ww/2,YF-wh/2,SZ],[-ww/2,YF-wh/2,SZ],[-2.6,-.4,1.8],[2.6,-.4,1.8],[-1.8,3.8,.4]])
  p=(bounds-self.eye)@self.basis;z=p[:,:2]/p[:,2:];z[:,1]*=-1
  span=z.max(0)-z.min(0);self.focal=min((self.W*.89)/span[0],(self.H*.86)/span[1])*self.zoom
  self.offset=np.array([self.W*.5,self.H*.50])-(z.max(0)+z.min(0))*.5*self.focal
 def project(self,pts):
  p=(np.asarray(pts,float)-self.eye)@self.basis
  return np.stack([p[...,0]/np.maximum(p[...,2],.01),-p[...,1]/np.maximum(p[...,2],.01)],axis=-1)*self.focal+self.offset
 def poly(self,im,p,c,edge=None,width=1):
  q=np.rint(self.project(p)).astype(np.int32)
  if np.any(abs(q)>20000):return
  if c is not None:cv2.fillConvexPoly(im,q,(c,c,c) if isinstance(c,int) else c,cv2.LINE_AA)
  if edge is not None:cv2.polylines(im,[q],True,(edge,edge,edge),width,cv2.LINE_AA)
 def line(self,im,p,c,width=1):
  q=np.rint(self.project(p)).astype(np.int32)
  if np.any(abs(q)>20000):return
  cv2.polylines(im,[q],False,(int(c),)*3,width,cv2.LINE_AA)
 def circle(self,center,normal,rad,n=80):
  normal=unit(normal);t=unit(np.cross(normal,[0,0,1] if abs(normal[2])<.9 else [0,1,0]));v=np.cross(normal,t);a=np.arange(n)*2*np.pi/n
  return np.asarray(center)+rad*(np.cos(a)[:,None]*t+np.sin(a)[:,None]*v)
 def disc(self,im,center,normal,rad,pwr=1,glass=True):
  normal=unit(normal);center=np.asarray(center)
  front=self.circle(center+normal*.028,normal,rad+.047)
  back=self.circle(center-normal*.072,normal,rad+.047)
  for j in range(len(front)):
   k=(j+1)%len(front);tone=int(28+40*(.5+.5*math.cos(j*2*math.pi/len(front)-.7)))
   self.poly(im,[back[j],back[k],front[k],front[j]],tone)
  if glass:
   lay=im.copy();self.poly(lay,self.circle(center,normal,rad),36,None);cv2.addWeighted(lay,.24,im,.76,0,dst=im)
  self.poly(im,back,None,52,2)
  self.poly(im,front,None,int(75+32*pwr),2)
  self.poly(im,self.circle(center,normal,rad),None,int(68+47*pwr),1)
  self.line(im,front[8:26],int(130+38*pwr),2)
  # Knurled precision mount: these markings belong to the fixed lens cell.
  if rad>.3:
   for j in range(0,len(front),5):self.line(im,[back[j],front[j]],65,1)
 def warp(self,im,tex,corners,gain=1):
  dst=self.project(corners).astype(np.float32);left=max(0,int(dst[:,0].min())-2);right=min(self.W,int(dst[:,0].max())+3);top=max(0,int(dst[:,1].min())-2);bottom=min(self.H,int(dst[:,1].max())+3)
  if right<=left or bottom<=top:return dst
  h,w=tex.shape[:2];T=cv2.getPerspectiveTransform(np.float32([[0,0],[w,0],[w,h],[0,h]]),(dst-[left,top]).astype(np.float32))
  v=cv2.warpPerspective(tex,T,(right-left,bottom-top),flags=cv2.INTER_LINEAR)
  if v.ndim==2:v=np.repeat(v[...,None],3,2)
  if gain!=1:v=(v.astype(np.float32)*gain).astype(np.uint8)
  mask=np.zeros((bottom-top,right-left),np.uint8);cv2.fillConvexPoly(mask,np.rint(dst-[left,top]).astype(np.int32),255)
  reg=im[top:bottom,left:right];reg[mask>0]=v[mask>0];return dst
 def render(self,t,field,source,keys=None,original=False):
  self.camera(t,field);pwr=power(t);im=self.background.copy();ww,wh=field.ww,field.wh
  # Restrained physical bench; the receiver is above it in this long-lens view.
  for z in np.arange(-22,3,2.):self.line(im,[[-5,-.5,z],[5,-.5,z]],22)
  for x in [-4,-2,0,2,4]:self.line(im,[[x,-.5,-22],[x,-.5,2]],22)
  screen=np.array([[-ww/2,YF+wh/2,SZ],[ww/2,YF+wh/2,SZ],[ww/2,YF-wh/2,SZ],[-ww/2,YF-wh/2,SZ]])
  self.poly(im,screen,None,47,5);self.screenQuad=self.warp(im,field.output[...,:3],screen,pwr)
  self.poly(im,screen,None,85,1)
  # Rim and ground contact; no floating explanation panels.
  self.poly(im,[[-2.55,-.18,-.95],[2.55,-.18,-.95],[2.55,-.18,1.8],[-2.55,-.18,1.8]],28,60)
  self.poly(im,[[-2.55,-.18,1.8],[2.55,-.18,1.8],[2.55,-.44,1.8],[-2.55,-.44,1.8]],18,35)
  self.line(im,[[-2.45,-.22,1.81],[2.45,-.22,1.81]],72)
  for x in [-2.38,2.38]:
   for z in [-.75,1.55]:
    xy=np.rint(self.project([[x,-.17,z]])[0]).astype(int);cv2.circle(im,tuple(xy),3,(100,)*3,1,cv2.LINE_AA)
  # Mounting struts to one side of each optical aperture.
  self.line(im,[[.78,-.13,0],[.78,2.2,0],[.55,2.2,0]],70,3)
  self.line(im,[[.46,-.13,-.12],[.46,YF,-.12],[.22,YF,-.12]],55,2)
  self.line(im,[[C[0]-.63,-.14,C[2]],[C[0]-.63,C[1],C[2]],[C[0]-.47,C[1],C[2]]],65,3)
  # LED housing and collimator. The emitter is uniform, NOT a tiny video image.
  self.disc(im,LAMP,I,.115,pwr,False)
  pp=np.rint(self.project([LAMP])[0]).astype(int)
  if pwr>0:cv2.circle(im,tuple(pp),max(1,int(4*pwr)),(int(225*pwr),)*3,-1,cv2.LINE_AA)
  self.disc(im,C,I,.58,pwr)
  self.disc(im,[0,S,0],[0,1,0],.56,pwr)
  # A matte internal OFF-state absorber, not a separate image frame.
  self.poly(im,[[1.0,.50,-.40],[1.0,1.45,-.40],[1.0,1.45,.40],[1.0,.50,.40]],10,37)
  self.poly(im,[[1.0,.50,.40],[1.2,.50,.40],[1.2,1.45,.40],[1.0,1.45,.40]],17,32)
  # Silicon package and exposed mirror array: texture is source duty at FIXED IDs.
  ow,oh=field.ow,field.oh
  self.poly(im,[[-ow*.64,-.02,-oh*.7],[ow*.64,-.02,-oh*.7],[ow*.64,-.02,oh*.7],[-ow*.64,-.02,oh*.7]],12,112)
  chip=[[ow/2,0,oh/2],[-ow/2,0,oh/2],[-ow/2,0,-oh/2],[ow/2,0,-oh/2]]
  chipTex=np.clip(source.astype(float)*.68+24,0,255).astype(np.uint8)
  self.warp(im,chipTex,chip,.3+.7*pwr);self.poly(im,chip,None,135)
  # Electronic input monitor: wires carry data; light does not originate here.
  x,y,z=-1.62,.63,.70;mw=.92;mh=mw*source.shape[0]/source.shape[1]
  corners=[[x-mw/2,y+mh/2,z],[x+mw/2,y+mh/2,z],[x+mw/2,y-mh/2,z],[x-mw/2,y-mh/2,z]]
  self.poly(im,[[x-mw/2-.045,y+mh/2+.045,z+.01],[x+mw/2+.045,y+mh/2+.045,z+.01],[x+mw/2+.045,y-mh/2-.045,z+.01],[x-mw/2-.045,y-mh/2-.045,z+.01]],21,85)
  self.warp(im,source,corners,pwr)
  self.line(im,[[x,y-mh/2,z],[x,-.13,z]],65,3)
  self.line(im,[[x,-.12,z],[x+.5,-.12,z],[x+.7,-.12,.65],[-.38,-.08,.35]],58,2)
  # Sampled light paths. Their geometry is not chosen by the art renderer.
  # draw paths after reflective surface
  # The folding mirror is an actual y+z=3.8 surface, sized to the traced beam.
  n=np.array([0,1,1])/np.sqrt(2);center=np.array([0,YF,0])
  self.disc(im,center,n,.50,pwr,False)
  self.poly(im,self.circle(center,n,.483),46,130,1)
  self.draw_paths(im,field,pwr)
  self.draw_keyboard(im,keys if not original else None,pwr)
  # Real decoded source ends at 219 s. Shut light first, ambient last.
  ambient=1-smooth(219.7,220.5,t)
  if ambient<1:im=(im.astype(np.float32)*ambient).astype(np.uint8)
  return im
 def rayids(self,f):
  if not hasattr(self,'cachedIds') or self.cacheShape!=(f.w,f.h):
   x=(np.arange(38)+.5)/38*f.w;y=(np.arange(27)+.5)/27*f.h
   self.cachedIds=(y[:,None].astype(int)*f.w+x[None,:].astype(int)).ravel();self.cacheShape=(f.w,f.h)
  return self.cachedIds
 def draw_paths(self,im,f,pwr):
  if pwr<=0:return
  ids=self.rayids(f);sparse=ids[::3];segments=[]
  # Input rays are a constant-irradiance illumination field; image content does
  # not dim the LED. Output path radiance is modulated by the pixel's duty.
  for a,b in [(f.sources[sparse],f.collimators[sparse]),(f.collimators[sparse],f.centers[sparse])]:
   P=self.project(a)/2;Q=self.project(b)/2;weight=np.full((len(P),1),.023*pwr)
   segments.append(np.concatenate([P,Q,weight],axis=1))
  active=ids[(f.duty[ids]>.012)&(f.valid[ids,0]>0)]
  H=np.column_stack([f.hits[active],np.full(len(active),SZ)])
  throughput=f.duty[active]*pwr
  # Representative bright routes retain an exact source address for their full
  # journey. Other traced routes contribute to the same continuous white bundle.
  weight=throughput*(.024+.06*(np.arange(len(active))%17==0))
  for a,b in [(f.centers[active],f.lenses[active]),(f.lenses[active],f.folds[active]),(f.folds[active],H)]:
   P=self.project(a)/2;Q=self.project(b)/2
   segments.append(np.column_stack([P,Q,weight]))
  seg=np.ascontiguousarray(np.concatenate(segments),dtype=np.float32)
  buf=np.zeros((self.H//2,self.W//2),np.uint8)
  _beam.beams(seg.ctypes.data,len(seg),buf.ctypes.data,buf.shape[1],buf.shape[0],.62)
  buf=cv2.GaussianBlur(buf,(0,0),.36)
  lay=cv2.resize(buf,(self.W,self.H),interpolation=cv2.INTER_LINEAR)
  halo=cv2.GaussianBlur(lay,(0,0),2.3)
  # The view plane is opaque; background bundles never wash over the image.
  mask=np.rint(self.screenQuad).astype(np.int32);cv2.fillConvexPoly(lay,mask,0);cv2.fillConvexPoly(halo,mask,0)
  layer=cv2.addWeighted(lay,1,halo,.22,0)
  cv2.add(im,np.repeat(layer[...,None],3,axis=2),dst=im)
 def draw_keyboard(self,im,keys,pwr):
  if keys is None:keys=np.zeros(72)
  self.poly(im,[[-2.32,-.09,1.25],[2.32,-.09,1.25],[2.32,-.09,1.7],[-2.32,-.09,1.7]],13,75)
  for isBlack in [False,True]:
   for idx,kx,black in self.keys:
    if black!=isBlack:continue
    e=float(keys[idx]);x=(kx/self.nwhite-.5)*4.44;kw=4.44/self.nwhite*(.57 if black else .91)
    yy=-.27+(.058 if black else 0)-e*.023;z0=1.15;z1=1.52 if black else 1.78
    color=int((22 if black else 137)*(0.25+.75*pwr)+e*(135 if black else 80)*pwr)
    self.poly(im,[[x-kw/2,yy+.28,z0],[x+kw/2,yy+.28,z0],[x+kw/2,yy,z1],[x-kw/2,yy,z1]],color,43 if not black else 29)
    if e>.05:self.line(im,[[x-kw*.34,yy+.002,z1-.015],[x+kw*.34,yy+.002,z1-.015]],int(220*e*pwr),2)
if __name__=='__main__':
 from native_field import Field
 from pathlib import Path
 R=Path(__file__).resolve().parents[1];f=Field();s=Scene();v=cv2.VideoCapture(str(R/'assets/source.mp4'));keys=np.load(R/'assets/chip_keys.npy')
 for t in [10,20,60,90,150]:
  v.set(cv2.CAP_PROP_POS_MSEC,t*1000);ok,im=v.read();g=cv2.resize(cv2.cvtColor(im,cv2.COLOR_BGR2GRAY),(f.w,f.h),interpolation=cv2.INTER_AREA);f.set_frame(g);f.solve();out=s.render(t,f,g,keys[int(t*60)]);cv2.imwrite(str(R/f'render/proto_{t}.jpg'),out)
