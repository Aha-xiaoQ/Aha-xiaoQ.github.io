"""Recover exact embedded assets from this release's HTML, without a network call."""
from pathlib import Path
import re,base64,argparse
R=Path(__file__).resolve().parents[1]
def unpack(html):
    text=html.read_text(encoding='utf-8');dest=R/'assets';dest.mkdir(exist_ok=True)
    for marker,name in [('spectrum-keyframes','spectrum_keys.bin'),('builtin-media','source.mp4'),('builtin-wasm','optics.wasm'),('crystal-audio','lightbox.m4a'),('legacy-audio','chip.flac'),('eight-audio','eight.flac'),('evolution-audio','evolution.flac'),('evolution-keys','evolution_keys.bin')]:
        pattern=r'<script\s+id="'+re.escape(marker)+r'"[^>]*>(.*?)</script>'
        m=re.search(pattern,text,re.S)
        if not m:raise ValueError(f'Missing embedded asset: {marker}')
        raw=base64.b64decode(m[1].strip(),validate=True);(dest/name).write_bytes(raw);print(name,len(raw))
    for marker,name in [('chip-events','chip_events.json'),('lightbox-events','lightbox_events.json'),('lightbox-drums','lightbox_drums.json'),('eight-events','eight_events.json'),('timeline-data','timeline.json'),('audio-settings','audio_r8_settings.json')]:
        m=re.search(r'<script\s+id="'+marker+r'"[^>]*>(.*?)</script>',text,re.S)
        if not m:raise ValueError(f'Missing score: {marker}')
        (dest/name).write_text(m[1],encoding='utf-8');print(name,len(m[1]))
    (R/'render').mkdir(exist_ok=True);(R/'tests').mkdir(exist_ok=True)
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('html',type=Path,nargs='?',default=R/'Light_Loom_Studio_R9_1.html');args=a.parse_args();unpack(args.html)
