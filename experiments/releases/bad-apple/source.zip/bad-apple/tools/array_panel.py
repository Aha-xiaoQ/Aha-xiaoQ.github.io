"""Whole-chip inset for R7.1. All cells read the solver's duty array.
Resolved cells show exposure-weighted ON/OFF faces, not a grey-dependent fake
intermediate angle. Sub-pixel cells are AREA averaged, never subsampled into
an unrelated 9x9 patch. This is an inspection view, not another image source.
"""
import math
from functools import lru_cache
import numpy as np
import cv2

@lru_cache(maxsize=64)
def face_templates(step, nx, ny, off_nx, off_ny):
    k=96
    yy,xx=np.mgrid[:k,:k].astype(np.float32);xx=(xx+.5)/k;yy=(yy+.5)/k
    out=[]
    for x,y,lit in [(nx,ny,True),(off_nx,off_ny,False)]:
        hw=.43*abs(y); shift=-(xx-.5)*x/max(abs(y),1e-8)
        edge=np.minimum(hw-np.abs(xx-.5), .35-np.abs(yy-.5-shift))
        cover=np.clip(edge*k+.5,0,1)
        # Neutral metal. Geometry follows normals; intensity is exposure duty.
        face=(205+28*xx-9*yy) if lit else (40+12*xx-5*yy)
        border=np.clip(edge*k/1.3,0,1)
        face=(90 if lit else 28)*(1-border)+face*border
        img=13+(face-13)*cover
        out.append(cv2.resize(img,(step,step),interpolation=cv2.INTER_AREA))
    return tuple(out)

def array_texture(duty,w,h,tw,th,nx,ny,off_nx,off_ny,isolate=-1):
    d=np.asarray(duty,np.float32).reshape(h,w)
    if isolate>=0:
        a=np.zeros_like(d);a.flat[isolate]=d.flat[isolate];d=a
    cpp=min(tw/w,th/h)
    if cpp>=2:
        step=max(4,min(32,math.ceil(cpp*2)))
        on,off=face_templates(step,round(nx,7),round(ny,7),round(off_nx,7),round(off_ny,7))
        # Every (row,col) owns one independent face, and is represented once.
        tex=off[None,:,None,:]+d[:,None,:,None]*(on-off)[None,:,None,:]
        tex=tex.reshape(h*step,w*step)
        small=cv2.resize(tex,(tw,th),interpolation=cv2.INTER_AREA)
        method='resolved-exposure-faces'
    else:
        on,off=face_templates(96,round(nx,7),round(ny,7),round(off_nx,7),round(off_ny,7))
        # All cells participate. Area resampling integrates the complete grid.
        energy=np.float32(off.mean())+d*np.float32(on.mean()-off.mean())
        small=cv2.resize(energy,(tw,th),interpolation=cv2.INTER_AREA)
        method='whole-grid-area-average'
    return np.clip(np.rint(small),0,255).astype(np.uint8),method

def draw_array_panel(scene,im,f,t,power=1.,visible=True):
    if not visible:return
    size=max(32,int(min(scene.W*.26,scene.H*.27)))
    x=int(scene.W*.97)-size;y=min(int(scene.H*.69),scene.H-int(scene.H*.055)-size)
    w,h=f.w,f.h;cpp=min((size-24)/w,(size-44)/h)
    tw=max(2,int(round(cpp*w)));th=max(2,int(round(cpp*h)))
    px=(size-tw)//2;py=(size-24-th)//2
    nn=f.normals[0].astype(float);nn/=max(1e-12,np.linalg.norm(nn))
    tilt=math.atan2(-nn[0],nn[1])-math.pi/15
    onx,ony=float(nn[0]),float(nn[1]);offx=-math.sin(-math.pi/15+tilt);offy=math.cos(-math.pi/15+tilt)
    tex,method=array_texture(f.duty,w,h,tw,th,onx,ony,offx,offy,getattr(f,'isolate',-1))
    tile=np.full((size,size,3),13,np.uint8)
    # Power changes illumination, not commanded mirror angles.
    tex=np.rint(13+(tex.astype(np.float32)-13)*(.16+.84*power)).clip(0,255).astype(np.uint8)
    tile[py:py+th,px:px+tw]=tex[...,None]
    cv2.rectangle(tile,(1,1),(size-2,size-2),(91,)*3,1,cv2.LINE_AA)
    cv2.rectangle(tile,(px-1,py-1),(px+tw,py+th),(63,)*3,1,cv2.LINE_AA)
    fs=max(.19,min(.37,size/750));base=size-10
    label=f'{w} x {h}';count=f'{w*h:,}'
    cv2.putText(tile,label,(9,base),cv2.FONT_HERSHEY_SIMPLEX,fs,(163,)*3,1,cv2.LINE_AA)
    sw=cv2.getTextSize(count,cv2.FONT_HERSHEY_SIMPLEX,fs,1)[0][0]
    cv2.putText(tile,count,(size-sw-9,base),cv2.FONT_HERSHEY_SIMPLEX,fs,(127,)*3,1,cv2.LINE_AA)
    # A bracket and one leader locate the ENTIRE physical chip, not a fake 9x9 crop.
    mean=f.centers.mean(axis=0,dtype=np.float64)
    q=scene.project([mean])[0];cv2.line(im,tuple(np.rint(q).astype(int)),(x,y+size//2),(59,)*3,1,cv2.LINE_AA)
    from scene import smooth
    fade=1-smooth(219.7,220.5,t)
    roi=im[y:y+size,x:x+size]
    cv2.addWeighted(tile,fade,roi,1-fade,0,dst=roi)
    scene.arrayPanel={'columns':w,'rows':h,'cells':w*h,'mode':method,'visible':fade>0,'x':x,'y':y,'size':size,'content':[x+px,y+py,tw,th],'dutySum':float(f.duty.sum(dtype=np.float64)),'isolated':int(getattr(f,'isolate',-1))}
