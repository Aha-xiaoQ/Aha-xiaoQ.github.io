
from pathlib import Path
import cv2,numpy as np,subprocess,json,time
R=Path(__file__).resolve().parents[1];D=Path('/mnt/data');cv2.setNumThreads(1)
cfg=json.loads((R/'assets/timeline.json').read_text());a=cfg['mmdClock']['slope'];b=cfg['mmdClock']['intercept']
def smooth(x):x=np.clip(x,0,1);return x*x*(3-2*x)
class Reader:
 def __init__(self,path):
  self.cap=cv2.VideoCapture(str(path));self.fps=self.cap.get(cv2.CAP_PROP_FPS);self.i=-1;self.im=None
 def get(self,t):
  idx=max(0,round(t*self.fps))
  if idx<self.i or idx-self.i>150:self.cap.set(cv2.CAP_PROP_POS_FRAMES,idx);self.i=idx-1
  while self.i<idx:
   ok,im=self.cap.read()
   if not ok:raise RuntimeError('Missing video frame '+str(idx))
   self.im=im;self.i+=1
  return self.im
bw=Reader(R/'assets/bw_original.mp4');co=Reader(D/'Bad Apple H3!!!.mp4');md=Reader(D/'MMD重现Bad Apple.mp4')
W,H=1440,1080
enc=subprocess.Popen(['ffmpeg','-y','-v','error','-f','rawvideo','-pix_fmt','bgr24','-s',f'{W}x{H}','-r','30','-i','pipe:0','-an','-c:v','libx264','-preset','fast','-crf','17','-threads','2','-pix_fmt','yuv420p','-g','60','-movflags','+faststart',str(R/'assets/source_r9_silent.mp4')],stdin=subprocess.PIPE)
start=time.time()
for i in range(6570):
 t=i/30
 if t<110.3:out=cv2.resize(bw.get(t),(W,H),interpolation=cv2.INTER_AREA)
 if t>=108.7:
  col=cv2.resize(co.get(t),(W,H),interpolation=cv2.INTER_CUBIC)
  g=cv2.cvtColor(col,cv2.COLOR_BGR2GRAY);g=cv2.cvtColor(g,cv2.COLOR_GRAY2BGR)
  sat=smooth((t-145)/2)
  col=cv2.addWeighted(g,1-sat,col,sat,0) if sat<1 else col
  p=smooth((t-108.7)/1.6)
  out=cv2.addWeighted(out,1-p,col,p,0) if p<1 else col
 if t>=181.7:
  st=a*t+b
  if st<215.14:
   m=md.get(st);ratio=min(W/m.shape[1],H/m.shape[0]);ww=round(m.shape[1]*ratio);hh=round(m.shape[0]*ratio)
   m=cv2.resize(m,(ww,hh),interpolation=cv2.INTER_AREA);mdim=np.zeros((H,W,3),np.uint8);mdim[(H-hh)//2:(H-hh)//2+hh,(W-ww)//2:(W-ww)//2+ww]=m
  else:mdim=np.zeros((H,W,3),np.uint8)
  p=smooth((t-181.7)/1.6);out=cv2.addWeighted(out,1-p,mdim,p,0) if p<1 else mdim
 enc.stdin.write(out.tobytes())
 if i%300==0:
  (R/'render/source_build_status.json').write_text(json.dumps({'frame':i,'of':6570,'elapsed':round(time.time()-start,1)}))
  print(i,round(time.time()-start,1),flush=True)
enc.stdin.close()
if enc.wait():raise RuntimeError('source encode failed')
subprocess.run(['ffmpeg','-y','-v','error','-i',str(R/'assets/source_r9_silent.mp4'),'-i',str(R/'assets/original_reference.m4a'),'-map','0:v:0','-map','1:a:0','-c','copy','-bsf:v','h264_metadata=colour_primaries=1:transfer_characteristics=1:matrix_coefficients=6','-t','219','-movflags','+faststart',str(R/'assets/source.mp4')],check=True)
(R/'render/source_build_done.json').write_text(json.dumps({'frames':6570,'duration':219,'complete':True,'mmd_credits_excluded_at':215.14,'mmd_preserve_full_aspect':True}))
