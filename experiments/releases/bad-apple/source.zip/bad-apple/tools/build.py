"""Build offline single HTML. Requires only the included source + media.
No downloaded fonts, CDN scripts, telemetry, or remote media dependencies."""
from pathlib import Path
import re,base64,hashlib,argparse
R=Path(__file__).resolve().parents[1]
def build(out):
 a=R/'assets';files={'__SPECTRUM_KEYS__':base64.b64encode((a/'spectrum_keys.bin').read_bytes()).decode(),'__R9_JS__':(R/'src/studio_r9.js').read_text(encoding='utf-8')+'\n'+(R/'src/studio_r91.js').read_text(encoding='utf-8'),
 '__EIGHT_BASE64__':base64.b64encode((a/'eight.flac').read_bytes()).decode(),
 '__EVOLUTION_BASE64__':base64.b64encode((a/'evolution.flac').read_bytes()).decode(),
 '__EVOLUTION_KEYS__':base64.b64encode((a/'evolution_keys.bin').read_bytes()).decode(),
 '__EIGHT_EVENTS__':(a/'eight_events.json').read_text(),
 '__AUDIO_SETTINGS__':(a/'audio_r8_settings.json').read_text(),
 '__TIMELINE__':(a/'timeline.json').read_text(),
 '__MEDIA_BASE64__':base64.b64encode((a/'source.mp4').read_bytes()).decode(),
 '__WASM_BASE64__':base64.b64encode((a/'optics.wasm').read_bytes()).decode(),
 '__CRYSTAL_BASE64__':base64.b64encode((a/'lightbox.m4a').read_bytes()).decode(),
 '__LEGACY_BASE64__':base64.b64encode((a/'chip.flac').read_bytes()).decode(),
 '__CHIP_EVENTS__':(a/'chip_events.json').read_text(encoding="utf-8"),
 '__LIGHTBOX_EVENTS__':(a/'lightbox_events.json').read_text(encoding="utf-8"),
 '__LIGHTBOX_DRUMS__':(a/'lightbox_drums.json').read_text(encoding="utf-8"),
 '__OPTICS_JS__':(R/'src/optics.js').read_text(encoding="utf-8"),
 '__SCENE_JS__':(R/'src/scene.js').read_text(encoding="utf-8")+'\n'+(R/'src/cinema.js').read_text(encoding="utf-8")+'\n'+(R/'src/evolution_scene.js').read_text(encoding="utf-8")+'\n'+(R/'src/array_panel.js').read_text(encoding="utf-8")+'\n'+(R/'src/studio_r8.js').read_text(encoding="utf-8"),
 '__APP_JS__':(R/'src/app.js').read_text(encoding="utf-8")}
 s=(R/'src/index.template.html').read_text(encoding="utf-8");pat='|'.join(re.escape(k) for k in files);s=re.sub(pat,lambda m:files[m.group()],s);out.write_bytes(s.encode("utf-8"))
 print(str(out),out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=R/'Light_Loom_Studio_R9_1.html');args=p.parse_args();build(args.output)
