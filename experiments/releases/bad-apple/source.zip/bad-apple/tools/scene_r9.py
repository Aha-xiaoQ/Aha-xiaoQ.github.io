
"""R9 cinematic booth. Shared finite-mirror optics. Native export scene.
Colour paths use per-address RGB exposure; non-colour paths remain neutral.
A housing cutaway is a visualization; OFF ports terminate in an absorber."""
from pathlib import Path
import math,json,ctypes as CT
import cv2,numpy as np
from scene import Scene as Base,unit,smooth,power,YF,SZ,S,I,C,LAMP,_beam
from array_panel import array_texture
from graphics_text import stamp,text_mask
R=Path(__file__).resolve().parents[1]
TL=json.loads((R/'assets/timeline.json').read_text())
STAGES=TL['resolutions']
class Scene(Base):
 def __init__(self,w=1080,h=1440):
  super().__init__(w,h)
  self.keys=[];n=0
  for midi in range(36,97):
   black=midi%12 in [1,3,6,8,10]
   self.keys.append((midi-36,n if black else n+.5,black))
   if not black:n+=1
  self.nwhite=n;self.t=0;self.closed=0
 def camera(self,t,f):
  self.t=t;self.closed=smooth(151,166,t)
  self.eye=np.array([4.0+1.6*math.sin(t*.020),22.0+.8*math.sin(t*.027),104.])
  at=np.array([0.,2.3,-6]);fw=unit(at-self.eye);r=unit(np.cross(fw,[0,1,0]));u=np.cross(r,fw);self.basis=np.stack([r,u,fw],1)
  ww,wh=f.ww,f.wh
  bounds=np.array([[-ww/2,YF+wh/2,SZ],[ww/2,YF+wh/2,SZ],[ww/2,YF-wh/2,SZ],[-ww/2,YF-wh/2,SZ],[-3.15,-.9,5.7],[3.15,-.9,5.7],[-3.5,1.2,1.],[-1.8,3.7,.5]])
  p=(bounds-self.eye)@self.basis;q=p[:,:2]/p[:,2:];q[:,1]*=-1;sp=q.max(0)-q.min(0)
  self.focal=min(self.W*.91/sp[0],self.H*.89/sp[1])*self.zoom
  self.offset=np.array([self.W*.5,self.H*.49])-(q.max(0)+q.min(0))*.5*self.focal
 def room(self,im,f):
  # Two dark acoustic walls, recessed ceiling and a platform: no schematic grid.
  self.poly(im,[[-5,-.62,-23.5],[-5,7,-23.5],[-5,7,7],[-5,-.62,7]],(15,16,18))
  self.poly(im,[[5,-.62,-23.5],[5,7,-23.5],[5,7,7],[5,-.62,7]],(16,17,19))
  self.poly(im,[[-5,-.62,-23.5],[5,-.62,-23.5],[5,-.62,7],[-5,-.62,7]],(18,19,21))
  for x in [-4.85,4.85]:
   for z in [-18,-10,-2,6]:self.line(im,[[x,-.60,z],[x,5.9,z]],28,1)
  self.line(im,[[-4.98,-.58,-22],[-4.98,-.58,6.9]],48,1);self.line(im,[[4.98,-.58,-22],[4.98,-.58,6.9]],48,1)
  ww,wh=f.ww,f.wh
  corners=[[-ww/2,YF+wh/2,SZ],[ww/2,YF+wh/2,SZ],[ww/2,YF-wh/2,SZ],[-ww/2,YF-wh/2,SZ]]
  rim=[[-ww/2-.12,YF+wh/2+.12,SZ+.035],[ww/2+.12,YF+wh/2+.12,SZ+.035],[ww/2+.12,YF-wh/2-.12,SZ+.035],[-ww/2-.12,YF-wh/2-.12,SZ+.035]]
  self.poly(im,rim,7,82,2)
  out=f.output[...,:3][...,::-1].copy()
  if f.w<=96:out=cv2.resize(out,(f.w*10,f.h*10),interpolation=cv2.INTER_NEAREST)
  self.screenQuad=self.warp(im,out,corners,power(self.t))
  self.poly(im,corners,None,105,1)
 def bench(self,im):
  self.poly(im,[[-2.12,-.16,-.68],[1.25,-.16,-.68],[1.25,-.16,1.03],[-2.12,-.16,1.03]],28,85,1)
  self.poly(im,[[-2.12,-.16,1.03],[1.25,-.16,1.03],[1.25,-.42,1.03],[-2.12,-.42,1.03]],23,65,1)
  for x in [-1.93,1.06]:
   self.poly(im,[[x-.09,-.42,.55],[x+.09,-.42,.55],[x+.09,-.65,.55],[x-.09,-.65,.55]],22,39,1)
 def internals(self,im,f,pwr):
  self.line(im,[[-1.95,-.10,0],[-1.95,C[1],0],[C[0]-.50,C[1],0]],92,3)
  self.line(im,[[.78,-.10,0],[.78,S,0],[.53,S,0]],96,3)
  self.disc(im,LAMP,I,.14,pwr,False);self.poly(im,self.circle(LAMP,I,.093),int(230*pwr),125,1)
  self.disc(im,C,I,.58,pwr)
  self.disc(im,[0,S,0],[0,1,0],.50,pwr)
  # OFF absorber x=1, large enough for all ON-complement centre rays.
  self.poly(im,[[1,.15,-.5],[1,1.65,-.5],[1,1.65,.5],[1,.15,.5]],6,52,2)
  for yy in np.arange(.2,1.65,.09):self.line(im,[[1.002,yy,-.5],[1.002,yy,.5]],24,1)
  self.poly(im,[[-f.ow*.62,-.014,-f.oh*.7],[f.ow*.62,-.014,-f.oh*.7],[f.ow*.62,-.014,f.oh*.7],[-f.ow*.62,-.014,f.oh*.7]],13,123,1)
  d=f.duty.reshape(f.h,f.w);a=(24+173*d).astype(np.uint8)
  self.warp(im,a,[[f.ow/2,0,f.oh/2],[-f.ow/2,0,f.oh/2],[-f.ow/2,0,-f.oh/2],[f.ow/2,0,-f.oh/2]],pwr)
  self.disc(im,[0,YF,0],[0,1,1],.50,pwr,False);self.poly(im,self.circle([0,YF,0],[0,1,1],.48),65,135,1)
  # A source module supports time-sequential RGB. Three windows are status lamps,
  # not independent flying colours or extra light sources in the traced model.
  if self.t>=145:
   pt=self.project([LAMP+np.array([-.2,.07,0])])[0]
   for k,col in enumerate([(64,70,218),(70,193,90),(218,117,68)]):
    q=(round(pt[0])+k*8,round(pt[1]));cv2.rectangle(im,q,(q[0]+5,q[1]+3),col,-1)
 def housing(self,im,f,pwr):
  # Coherent one-piece optical head. Back face from camera side; an open
  # inspection window progressively closes. Exit points along -Z toward screen.
  layer=im.copy()
  x0,x1=-2.02,1.18;y0,y1=-.12,3.43;z0,z1=-.57,.79
  self.poly(layer,[[x0,y0,z0],[x0,y1,z0],[x0,y1,z1],[x0,y0,z1]],(42,44,48),94,2)
  self.poly(layer,[[x1,y0,z0],[x1,y1,z0],[x1,y1,z1],[x1,y0,z1]],(31,33,37),76,2)
  self.poly(layer,[[x0,y1,z0],[x1,y1,z0],[x1,y1,z1],[x0,y1,z1]],(43,45,49),105,1)
  # Camera-facing panel: cutaway window is truly omitted before closure.
  face=[[x0,y0,z1],[x1,y0,z1],[x1,y1,z1],[x0,y1,z1]]
  if self.closed>0:
   shut=layer.copy();self.poly(shut,face,(30,32,36),111,2);cv2.addWeighted(shut,self.closed,layer,1-self.closed,0,dst=layer)
  else:self.poly(layer,face,None,94,2)
  # Permanent slim housing edges retain the silhouette while cut open.
  self.line(layer,[[x0+.08,y0,z1],[x0+.08,y1,z1],[x1-.08,y1,z1],[x1-.08,y0,z1]],106,3)
  # Passive exit barrel, no unmodelled lens. It is sized from the actual rays.
  sections=[(-.63,.57),(-1.25,.53),(-1.92,.49)]
  for k in range(2):
   za,ra=sections[k];zb,rb=sections[k+1]
   ca=self.circle([0,YF,za],[0,0,1],ra,48);cb=self.circle([0,YF,zb],[0,0,1],rb,48)
   if self.closed>.01:
    temp=layer.copy()
    for j in range(48):
     j1=(j+1)%48;tone=int(32+29*(.5+.5*math.cos(j*math.pi/24)))
     self.poly(temp,[ca[j],ca[j1],cb[j1],cb[j]],tone)
    cv2.addWeighted(temp,self.closed,layer,1-self.closed,0,dst=layer)
   self.poly(layer,ca,None,100,1);self.poly(layer,cb,None,124,2)
  # Handle and ventilation are outside ray space, not little floating shapes.
  self.line(layer,[[-1.82,3.44,.48],[-1.82,3.70,.48],[-.91,3.70,.48],[-.91,3.44,.48]],120,5)
  if self.closed>.2:
   for x in np.arange(-1.82,.35,.17):self.line(layer,[[x,.40,z1+.006],[x,.65,z1+.006]],62,2)
   p=self.project([[-1.78,1.25,z1+.01]])[0];stamp(layer,'LIGHT LOOM',p[0],p[1],max(8,round(self.W/1080*14)),155,self.closed)
  # Ambient shells don't pump with the music.
  im[:]=layer
 def rayids(self,f):
  if f.N<=1728:return np.arange(f.N,dtype=np.int32)
  if getattr(self,'idshape',None)!=(f.w,f.h):
   nx=min(48,f.w);ny=min(36,f.h);x=((np.arange(nx)+.5)*f.w/nx).astype(int);y=((np.arange(ny)+.5)*f.h/ny).astype(int)
   self.cachedIds=np.unique((y[:,None]*f.w+x[None,:]).ravel());self.idshape=(f.w,f.h)
  return self.cachedIds
 def paths(self,im,f,pwr):
  ids=self.rayids(f);valid=f.valid.any(axis=1);active=ids[(f.duty[ids]>0)&valid[ids]]
  if getattr(f,'isolate',-1)>=0:active=active[active==f.isolate]
  self.beamIDs=active;self.counts={'mirrors':f.N,'lit':int(np.count_nonzero((f.duty>0)&valid)),'bundles':len(active),'duplicates':len(active)-len(np.unique(active))}
  self.energyAudit={'incident':float(len(ids)),'on':float(f.duty[ids].sum()),'off':float((1-f.duty[ids]).sum())}
  if pwr<=0:return
  seg=[];low=f.w<=48
  # Every RGB group uses the same path index and exact source RGB weights.
  def put(a,b,g,rgb=None):
   if not len(a):return
   P=self.project(a)/2;Q=self.project(b)/2;gg=np.broadcast_to(g,len(a))
   rgb=np.ones((len(a),3)) if rgb is None else rgb
   seg.append((np.column_stack([P,Q]),gg,rgb))
  base=.0095 if low else .0085
  internal=(1-self.closed)
  if internal>.002:
   # Same normalization for illumination, ON and complement-OFF, before
   # angle-dependent atmosphere gain. This is not an assertion of photometry.
   use=ids[::max(1,len(ids)//400)]
   put(f.sources[use],f.collimators[use],base*internal*pwr*1.5)
   put(f.collimators[use],f.centers[use],base*internal*pwr*1.5)
   # OFF exists for every duty<1, not only completely black cells.
   off=use[f.duty[use]<.999]
   p=f.centers[off].astype(float);n=np.array([math.sin(math.pi/15),math.cos(math.pi/15),0]);rr=I-2*np.dot(I,n)*n
   end=p+rr*((1-p[:,0])/rr[0])[:,None]
   if getattr(f,'color',False):
    offRGB=1-f.input.reshape(-1,4)[off,:3].astype(float)/255
    put(p,end,base*internal*pwr*1.5,offRGB)
   else:put(p,end,base*(1-f.duty[off])*internal*pwr*1.5)
  if len(active):
   rgb=f.input.reshape(-1,4)[active,:3].astype(float)/255
   gray=f.duty[active]
   if not getattr(f,'color',False):rgb=np.repeat(gray[:,None],3,axis=1)
   hit=np.column_stack([f.hits[active],np.full(len(active),SZ)])
   a=f.centers[active];b=f.lenses[active];q=f.folds[active]
   if internal>.002:
    put(a,b,base*internal*pwr,rgb);put(b,q,base*internal*pwr,rgb)
   starts=q.copy()
   # As housing closes, remove the portion inside the real exit mouth.
   zexit=-1.94
   mouth=q+(hit-q)*((zexit-q[:,2])/(hit[:,2]-q[:,2]))[:,None]
   starts=q*(1-self.closed)+mouth*self.closed
   v=hit-starts;direc=unit(v);length=np.linalg.norm(v,axis=1)
   for k in range(4):
    a0=k/4;a1=(k+1)/4;P=starts+v*a0;Q=starts+v*a1
    mu=np.sum(direc*unit(self.eye-(P+Q)*.5),axis=1)
    phase=(1-.24**2)/(1+.24**2-2*.24*mu)**1.5
    put(P,Q,(.076 if low else .045)*pwr*phase*np.exp(-length*.008*(a0+a1)/2),rgb)
  if not seg:return
  shape=(self.H//2,self.W//2);channels=[]
  mono=not getattr(f,'color',False)
  for cc in ([0] if mono else [2,1,0]):
   data=np.ascontiguousarray(np.concatenate([np.column_stack([xy,g*col[:,cc]]) for xy,g,col in seg]),np.float32)
   raster=np.zeros(shape,np.uint8);_beam.beams(data.ctypes.data,len(data),raster.ctypes.data,shape[1],shape[0],CT.c_float(1.0))
   layer=cv2.resize(raster,(self.W,self.H),interpolation=cv2.INTER_LINEAR)
   # Visible radiance from these segments only. No stamped circles at screen.
   halo=cv2.GaussianBlur(layer,(0,0),2.2)
   channels.append(cv2.addWeighted(layer,.91,halo,.39,0))
  glow=np.repeat(channels[0][...,None],3,2) if mono else np.stack(channels,axis=2)
  cv2.add(im,glow,dst=im)
 def keyboard(self,im,keys,pwr):
  # Independent console. Device ends at z=1.03; keys start at z=3.42.
  keys=np.zeros(72) if keys is None else keys
  self.poly(im,[[-3.02,-.11,3.32],[3.02,-.11,3.32],[3.02,-.55,5.73],[-3.02,-.55,5.73]],(33,34,37),95,2)
  self.poly(im,[[-3.02,-.55,5.73],[3.02,-.55,5.73],[3.02,-.82,5.73],[-3.02,-.82,5.73]],(27,28,31),65,1)
  self.keyPolygons=[]
  for black in [False,True]:
   for idx,kx,b in self.keys:
    if b!=black:continue
    e=float(keys[idx]);x=(kx/self.nwhite-.5)*5.72;kw=5.72/self.nwhite*(.58 if black else .96)
    z0=3.48;z1=4.87 if black else 5.60
    y0=.02 if black else -.10;y1=(-.33 if black else -.51)-e*.20
    q=np.array([[x-kw/2,y0,z0],[x+kw/2,y0,z0],[x+kw/2,y1,z1],[x-kw/2,y1,z1]])
    front=q[[3,2,2,3]].copy();front[2:,1]-=.09
    tone=int((24 if black else 163)+e*(167 if black else 88)*pwr)
    self.poly(im,front,max(12,tone//2),26,1);self.poly(im,q,tone,10 if black else 40,1)
    self.keyPolygons.append((idx,q.tolist(),e))
    if e>.01:
     cen=q.mean(0);inset=cen+(q-cen)*.88
     self.poly(im,inset,None,int(235*e*pwr),2)
     self.line(im,[q[3]+(q[0]-q[3])*.035,q[2]+(q[1]-q[2])*.035],int(255*e*pwr),3)
  self.line(im,[[-2.89,-.62,5.741],[2.89,-.62,5.741]],112,1)
 def panels(self,im,f,source,pwr):
  # Two calm, deliberately separated instrument monitors. No floating overlays
  # cross the machine silhouette or the keyboard surface.
  W,H=self.W,self.H;w=round(W*.21);h=round(w*.75+33);x=round(W*.027);y=round(H*.635)
  if y+h>H*.875:y=round(H*.875)-h
  tile=np.full((h,w,3),14,np.uint8);tex=cv2.resize(source,(w-12,h-34),interpolation=cv2.INTER_AREA)
  if tex.ndim==2:tex=np.repeat(tex[...,None],3,2)
  tile[6:h-28,6:w-6]=np.rint(tex*pwr).astype(np.uint8)
  cv2.rectangle(tile,(0,0),(w-1,h-1),(74,)*3,1);stamp(tile,'输入监看',8,h-23,max(9,round(W/1080*12)),145)
  im[y:y+h,x:x+w]=tile
  x2=W-x-w;d=f.duty;nn=unit(f.normals[0]);tilt=math.atan2(-nn[0],nn[1])-math.pi/15
  tex,mode=array_texture(d,f.w,f.h,w-12,h-34,float(nn[0]),float(nn[1]),-math.sin(-math.pi/15+tilt),math.cos(-math.pi/15+tilt),getattr(f,'isolate',-1))
  tile[:]=14;tile[6:h-28,6:w-6]=np.rint(tex[...,None]*(.20+.80*pwr)).astype(np.uint8)
  cv2.rectangle(tile,(0,0),(w-1,h-1),(74,)*3,1);stamp(tile,f'{f.w} × {f.h}',8,h-23,max(9,round(W/1080*12)),175)
  im[y:y+h,x2:x2+w]=tile
  self.arrayPanel={'content':[x2+6,y+6,w-12,h-34],'cells':f.N,'columns':f.w,'rows':f.h,'mode':mode}
 def macro(self,im,f,t):
  # An optical magnifier uses the actual active field, not an independent image.
  alpha=smooth(90,94,t)*(1-smooth(104,109,t))
  if alpha<=0:return
  W,H=self.W,self.H;x=round(W*.16);y=round(H*.505);w=round(W*.68);h=round(H*.30)
  tile=np.full((h,w,3),12,np.uint8)
  old=(self.eye.copy(),self.basis.copy(),self.focal,self.offset.copy())
  col=round(f.w*.47);row=round(f.h*.44);idx=row*f.w+col;pitch=f.ow/f.w;m=f.centers[idx].astype(float)
  approach=smooth(90,97,t)
  eye=m+np.array([10*(1-approach)+4,17,24])*pitch
  at=m+np.array([0,2*(1-approach),0])*pitch
  fw=unit(at-eye);r=unit(np.cross(fw,[0,1,0]));u=np.cross(r,fw)
  self.eye=eye;self.basis=np.stack([r,u,fw],1);self.focal=w*1.6;self.offset=np.array([w*.48,h*.56])
  for dy in range(-4,5):
   for dx in range(-6,7):
    X=col+dx;Y=row+dy
    if not(0<=X<f.w and 0<=Y<f.h):continue
    i=Y*f.w+X;p=f.centers[i].astype(float);d=float(f.duty[i])
    for on,weight in [(False,1-d),(True,d)]:
     if weight<.001:continue
     a=(1 if on else -1)*math.pi/15;n=np.array([-math.sin(a),math.cos(a),0]);tx=np.array([n[1],-n[0],0]);tz=np.array([0,0,1])
     q=np.array([p+tx*A*pitch*.46+tz*B*(f.oh/f.h)*.46 for A,B in [(-1,-1),(1,-1),(1,1),(-1,1)]])
     temp=tile.copy();self.poly(temp,q,170 if on else 27,210 if i==idx else 75,2 if i==idx else 1)
     cv2.addWeighted(temp,weight,tile,1-weight,0,dst=tile)
  d=float(f.duty[idx]);n=unit(f.normals[idx]);rx=I-2*np.dot(I,n)*n
  a=m-I*pitch*10;b=m+rx*pitch*11
  self.line(tile,[a,m],225,3);self.line(tile,[m,b],int(255*d),3)
  offn=np.array([math.sin(math.pi/15),math.cos(math.pi/15),0]);off=I-2*np.dot(I,offn)*offn
  self.line(tile,[m,m+off*pitch*9],int(230*(1-d)),2)
  self.eye,self.basis,self.focal,self.offset=old
  cv2.rectangle(tile,(0,0),(w-1,h-1),(150,)*3,1)
  stamp(tile,'沿光路 · 微镜曝光',14,12,max(12,round(W/1080*18)),210)
  stamp(tile,f'#{idx}   ON {d*100:.0f}%   OFF {(1-d)*100:.0f}%',14,h-30,max(11,round(W/1080*15)),170)
  roi=im[y:y+h,x:x+w];cv2.addWeighted(tile,alpha,roi,1-alpha,0,dst=roi)
 def cue(self,im,t,f):
  for i,stage in enumerate(STAGES):
   at=stage['start']
   if at<=t<at+3.2:
    alpha=smooth(at,at+.35,t)*(1-smooth(at+2.6,at+3.2,t))
    msg=f"{stage['w']} × {stage['h']}   /   {stage['source']}"
    msg2=f"{stage['timbre']} · {stage['space']}"
    sz=max(13,round(self.W/1080*24));y=round(max(self.screenQuad[:,1])+14)
    tw=text_mask(msg,sz).shape[1];stamp(im,msg,(self.W-tw)//2,y,sz,225,alpha)
    sz2=max(10,round(self.W/1080*17));tw=text_mask(msg2,sz2).shape[1];stamp(im,msg2,(self.W-tw)//2,y+sz+8,sz2,152,alpha)
    break
 def render(self,t,field,source,keys=None,original=False):
  self.field=field;self.camera(t,field);pwr=power(t);im=self.background.copy()
  self.room(im,field);self.bench(im);self.internals(im,field,pwr);self.housing(im,field,pwr);self.paths(im,field,pwr);self.keyboard(im,keys,pwr);self.panels(im,field,source,pwr);self.macro(im,field,t);self.cue(im,t,field)
  fade=1-smooth(219.5,220.5,t)
  if fade<1:im=np.rint(im.astype(np.float32)*fade).astype(np.uint8)
  if t>=220.45:im[:]=0
  return im
