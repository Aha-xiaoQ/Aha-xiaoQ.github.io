#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
clang src/optics.c --target=wasm32 -O3 -fno-builtin -nostdlib -Wl,--no-entry -Wl,--export-dynamic -Wl,--export-memory -Wl,--allow-undefined -Wl,--initial-memory=268435456 -Wl,--max-memory=536870912 -o assets/optics.wasm
clang -DNATIVE -O3 -fPIC -shared src/optics.c -lm -o assets/optics_native.so

clang -O3 -fPIC -shared src/beam_raster.c -lm -o assets/beam_raster.so
