from pathlib import Path
import ctypes as C,numpy as np
R=Path(__file__).resolve().parents[1]
class Field:
 def __init__(self,w=720,h=540,rw=1080,rh=810):
  self.w=w;self.h=h;self.rw=rw;self.rh=rh;self.N=w*h;self.ow=min(.70,.525*w/h);self.oh=self.ow*h/w;self.ww=self.ow*10;self.wh=self.oh*10
  f=self.lib=C.CDLL(str(R/'assets/optics_native.so'))
  f.configure.argtypes=[C.c_int]*4+[C.c_double];f.configure.restype=C.c_int
  f.set_optics.argtypes=[C.c_double]*3;f.set_spot.argtypes=[C.c_double];f.solve.argtypes=[C.c_double];f.set_isolate.argtypes=[C.c_int]
  f.get_mass.restype=C.c_double;f.get_rms.restype=C.c_double
  assert f.configure(w,h,rw,rh,self.ow)==0
  def arr(name,ty,shape):
   fn=getattr(f,name+'_ptr');fn.restype=C.c_void_p
   return np.ctypeslib.as_array(C.cast(fn(),C.POINTER(ty)),shape=(int(np.prod(shape)),)).reshape(shape)
  self.input=arr('input',C.c_ubyte,(h,w,4));self.output=arr('output',C.c_ubyte,(rh,rw,4))
  for s in ['centers','normals','sources','collimators','lenses','folds']:setattr(self,s,arr(s,C.c_float,(self.N,3)))
  self.hits=arr('hits',C.c_float,(self.N,2));self.duty=arr('duty',C.c_float,(self.N,));self.mapx=arr('mapx',C.c_float,(self.N,5));self.mapy=arr('mapy',C.c_float,(self.N,5));self.valid=arr('valid',C.c_ubyte,(self.N,5))
 def set_frame(self,im,color=False):
  if im.ndim==2:self.input[:,:,:3]=im[...,None]
  else:self.input[:,:,:3]=im[...,:3]
  self.input[:,:,3]=255;self.lib.set_frame(int(color))
 def solve(self,power=1.):self.lib.solve(power);return self.output[...,:3]
 @property
 def mass(self):return self.lib.get_mass()
