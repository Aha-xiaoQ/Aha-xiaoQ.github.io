from pathlib import Path
import subprocess,argparse
R=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=R/'Light_Loom_R9_1_Final.mp4');args=p.parse_args()
(R/'render/concat.txt').write_text(''.join("file '"+str(R/f'render/part{i}.mp4')+"'\n" for i in range(6)))
if not (R/'assets/evolution.m4a').exists():
 subprocess.run(['ffmpeg','-y','-v','error','-i',str(R/'assets/evolution.flac'),'-c:a','aac','-b:a','320k','-movflags','+faststart',str(R/'assets/evolution.m4a')],check=True)
cmd=['ffmpeg','-y','-v','warning','-f','concat','-safe','0','-i',str(R/'render/concat.txt'),'-i',str(R/'assets/evolution.m4a'),'-map','0:v:0','-map','1:a:0','-vf','scale=in_color_matrix=bt601:out_color_matrix=bt709:in_range=tv:out_range=tv,format=yuv420p,drawbox=color=black:t=fill:enable=gte(n\\,13229)','-c:v','libx264','-crf','18','-preset','fast','-threads','2','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709','-c:a','copy','-t','220.5','-movflags','+faststart',str(args.output)]
subprocess.run(cmd,check=True)
