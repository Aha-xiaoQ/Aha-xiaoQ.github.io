
from pathlib import Path
import cv2,numpy as np,json,subprocess,argparse,time,os
from native_field import Field
from scene_r91 import Scene,STAGES
R=Path(__file__).resolve().parents[1];cv2.setNumThreads(1)
FPS=60;COUNT=13230
def render(part):
 first=part*2190;last=first+2190 if part<5 else COUNT
 cfg=STAGES[part];w,h=cfg['w'],cfg['h'];rw=w if w<=96 else min(1080,w*3);rh=rw*3//4
 f=Field(w,h,rw,rh);f.isolate=-1;f.proof=None
 v=cv2.VideoCapture(str(R/'assets/source.mp4'));v.set(cv2.CAP_PROP_POS_FRAMES,first//2)
 keys=np.fromfile(R/'assets/evolution_keys.bin',np.uint8).reshape(COUNT,72)
 spec=np.fromfile(R/'assets/spectrum_keys.bin',np.uint8).reshape(COUNT,72)
 sc=Scene(1080,1440);outdir=R/'render';outdir.mkdir(exist_ok=True)
 fferr=open(outdir/f'part{part}.fflog','w')
 enc=subprocess.Popen(['ffmpeg','-y','-v','error','-f','rawvideo','-pix_fmt','bgr24','-s','1080x1440','-r','60','-i','pipe:0','-an','-c:v','libx264','-preset','veryfast','-crf','18','-threads','1','-pix_fmt','yuv420p','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-movflags','+faststart',str(outdir/f'part{part}.mp4')],stdin=subprocess.PIPE,stderr=fferr)
 start=time.time();previous=-1;log=[]
 try:
  for i in range(first,last):
   t=i/60;fi=min(6569,i//2)
   if fi!=previous:
    ok,src=v.read()
    if not ok:raise RuntimeError(f'Cannot read input {fi}')
    rgb=cv2.cvtColor(cv2.resize(src,(w,h),interpolation=cv2.INTER_AREA),cv2.COLOR_BGR2RGB)
    levels=cfg['levels'];rgb=np.rint(np.rint(rgb.astype(np.float32)/255*(levels-1))*255/(levels-1)).astype(np.uint8)
    f.color=t>=145.;f.set_frame(rgb,color=f.color);f.solve();previous=fi
   sc.spectralValues=spec[i].astype(np.float32)/255;sc.spectralMode=float(np.sin(np.clip((t-108.5)/2,0,1)*np.pi/2)**2)
   image=sc.render(t,f,src,keys[i].astype(np.float32)/255)
   enc.stdin.write(image.tobytes())
   if i%60==0:log.append({'frame':i,'stage':w,**sc.counts,'sourceTime':fi/30,'energy':sc.energyAudit,'closed':sc.closed,'leaders':len(sc.leaders),'cue':sc.cueBox,'feedback':sc.keyFeedback})
   if (i-first)%120==0:
    stat={'part':part,'frame':i,'done':i-first,'of':last-first,'elapsed':round(time.time()-start,1)}
    (outdir/f'part{part}.json').write_text(json.dumps(stat));print(stat,flush=True)
 finally:
  enc.stdin.close();code=enc.wait();fferr.close();v.release()
 if code:raise RuntimeError(f'ffmpeg {code}')
 (outdir/f'counts{part}.json').write_text(json.dumps(log))
 (outdir/f'part{part}.json').write_text(json.dumps({'part':part,'complete':True,'frames':last-first,'elapsed':time.time()-start}))
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--worker',type=int,required=True);args=a.parse_args()
 for part in range(args.worker,6,3):render(part)
