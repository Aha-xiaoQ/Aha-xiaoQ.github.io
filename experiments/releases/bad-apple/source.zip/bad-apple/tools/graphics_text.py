import numpy as np
import os
from pathlib import Path
from functools import lru_cache
from PIL import Image,ImageFont,ImageDraw
FONT=os.environ.get('LOOM_FONT','/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
if not Path(FONT).is_file():
 raise FileNotFoundError('Install a CJK font or set LOOM_FONT to your local font path; fonts are not bundled.')
@lru_cache(maxsize=160)
def text_mask(text,size):
 font=ImageFont.truetype(FONT,size);box=font.getbbox(text);im=Image.new('L',(box[2]-box[0]+6,box[3]-box[1]+6));ImageDraw.Draw(im).text((3-box[0],3-box[1]),text,font=font,fill=255);return np.array(im)
def stamp(im,text,x,y,size=23,tone=190,opacity=1):
 mask=text_mask(text,size);h,w=mask.shape;x=int(x);y=int(y)
 if x<0 or y<0 or x+w>im.shape[1] or y+h>im.shape[0]:return
 a=mask.astype(np.float32)/255*opacity;r=im[y:y+h,x:x+w];r[:]=np.rint(r*(1-a[...,None])+tone*a[...,None]).astype(np.uint8)
