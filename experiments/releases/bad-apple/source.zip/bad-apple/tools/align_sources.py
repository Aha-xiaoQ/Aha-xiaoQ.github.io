
import subprocess, numpy as np, json
from pathlib import Path
D=Path('/mnt/data');R=D/'light_loom_r9'
sources={'bw':R/'assets/source.mp4','color':D/'Bad Apple H3!!!.mp4','mmd':D/'MMD重现Bad Apple.mp4'}
for key,p in sources.items():
 vf=('crop=1440:1080:240:0,' if key=='mmd' else '')+'fps=12,scale=64:48:flags=area,format=gray'
 data=subprocess.check_output(['ffmpeg','-v','error','-i',str(p),'-vf',vf,'-f','rawvideo','-pix_fmt','gray','-threads','1','pipe:1'])
 arr=np.frombuffer(data,np.uint8).reshape(-1,48,64);np.save(R/'assets'/f'desc_{key}.npy',arr)
 print(key,len(arr),flush=True)
