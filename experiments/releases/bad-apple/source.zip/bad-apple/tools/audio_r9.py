
"""R9 coherent timbral family, independent sound-field width, one original AAC decode.
No mastering compressor, no EQ or dynamics on original. FLAC mother, single AAC encode."""
from pathlib import Path
import numpy as np,soundfile as sf,subprocess,json
from scipy.ndimage import gaussian_filter1d
import pyloudnorm as pyln
R=Path(__file__).resolve().parents[1];A=R/'assets';SR=44100;T=220.5;L=round(T*SR);N=13230
meter=pyln.Meter(SR);target=-18.;events=json.loads((A/'chip_events.json').read_text());report={'revision':'R9','SR':SR,'targetLUFS':target,'masterCompressor':False,'originalEQ':False}
times=np.arange(L,dtype=np.float64)/SR;ft=np.arange(N)/60
def read(p):
 x,sr=sf.read(p,dtype='float32',always_2d=True);assert sr==SR
 out=np.zeros((L,2),np.float32);out[:min(L,len(x))]=x[:L];return out
chip=read(A/'chip.flac');chip[:]=chip.mean(1)[:,None]
# Recompose from the same score: core pulse lead with a quiet triangle octave.
def instrument(width,complexity):
 out=np.zeros((L,2),np.float32);es=[]
 for e in events:
  t,d,f=float(e['t']),float(e['d']),float(e['f']);s=round(t*SR);n=min(round(d*SR),L-s)
  if n<=0:continue
  v=np.arange(n)/SR;p=2*np.pi*f*v
  env=np.minimum(1,v/.004)*np.minimum(1,np.maximum(0,d-v)/.010)*(.48+.52*np.exp(-4*v))
  core=.58*np.sin(p)+.24*np.sin(2*p)+.11*np.sin(3*p)+.05*np.sin(5*p)
  pulse=np.zeros(n)
  for h in range(1,min(15,int(10000/f))+1,2):pulse+=np.sin(h*p)/h
  lead=(.77*core+.23*pulse)*env*.44
  # Pan follows score/register, not a random oscillator; mono-compatible sum.
  pan=np.clip((e['midi']-66)/32,-.65,.65)*width
  out[s:s+n,0]+=lead*(1-pan*.4);out[s:s+n,1]+=lead*(1+pan*.4)
  es.append(dict(e,voice='pulse-core'))
  if d>.065 and 130<=f<=1050:
   tri=sum((-1)**((h-1)//2)/h**2*np.sin(p*.5*h) for h in [1,3,5,7,9])
   bass=tri*env*(.11+.02*complexity)
   out[s:s+n,0]+=bass*(1+width*.24);out[s:s+n,1]+=bass*(1-width*.24)
   es.append(dict(e,f=f/2,midi=e['midi']-12,voice='triangle'))
  if complexity and d>.12:
   bell=(np.sin(p*2)*np.exp(-v*10)+.12*np.sin(p*4)*np.exp(-v*20))*env*.036
   out[s:s+n,0]+=bell*(1-width*.45);out[s:s+n,1]+=bell*(1+width*.45)
   # octave timbre does not imply a separate played key
 lag=round(.108695*SR);out[lag:]+=out[:-lag].copy()*.055
 return out,es
narrow,e1=instrument(.3,0);wide,e2=instrument(1.,1)
def loud(x,a,b):return float(meter.integrated_loudness(x[round(a*SR):round(b*SR)]))
def match(x,span,kind):
 db=target-loud(x,*span);x*=10**(db/20);report[kind]={'gainDB':db,'measuredLUFS':loud(x,*span)};return x
# Slow phrase gain for synthesized channels only.
def phrases(x):
 ts=np.arange(4,215,3);lev=np.array([loud(x,t-3,t+3) for t in ts]);valid=np.isfinite(lev)&(lev>-50)
 med=float(np.median(lev[valid]));db=np.clip(np.where(valid,med-lev,0),-3,5)
 db=gaussian_filter1d(db,1.5);x*=10**(np.interp(times,ts,db)/20)[:,None];return x
chip=match(chip,(3,35),'chip');narrow=match(phrases(narrow),(38,71),'narrow');wide=match(phrases(wide),(75,107),'wide')
raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(A/'original_reference.m4a'),'-t','219','-ac','2','-ar',str(SR),'-f','f32le','pipe:1'])
original=np.zeros((L,2),np.float32);x=np.frombuffer(raw,'<f4').reshape(-1,2);original[:min(len(x),L)]=x[:L]
original=match(original,(112,215),'original')
# Width changes retain mid; pure final section is exactly the scaled source.
mid=original.mean(1);side=(original[:,0]-original[:,1])*.5
width=.68+.32*np.clip((times-145)/2,0,1)
rec=np.column_stack([mid+side*width,mid-side*width]).astype(np.float32)
tracks=[chip,narrow,wide,rec]
bounds=[0,36.5,73,109.5,219];weights=[]
for i in range(4):
 w=np.ones(L,np.float32)
 if i: w*=np.sin(np.clip((times-(bounds[i]-1))/2,0,1)*np.pi/2)**2
 if i<3:w*=np.cos(np.clip((times-(bounds[i+1]-1))/2,0,1)*np.pi/2)**2
 w[times>=219]=0;weights.append(w)
out=np.zeros((L,2),np.float32)
for x,w in zip(tracks,weights):out+=x*w[:,None]
# No peak limiter. A common safety trim applies only if genuinely needed.
peak=float(abs(out).max());safety=min(1,.87/peak);out*=safety
for x in tracks:x*=safety
report['safetyDB']=float(20*np.log10(safety));report['peakDBFS']=float(20*np.log10(abs(out).max()))
keys=np.zeros((N,72),np.float32)
for j,es in enumerate([events,e1,e2]):
 arr=np.zeros_like(keys)
 for e in es:
  k=int(e['midi'])-36
  if k<0 or k>=72:continue
  ov=np.maximum(0,np.minimum(ft+1/60,e['t']+e['d'])-np.maximum(ft,e['t']))*60
  rel=ft-e['t']-e['d'];val=np.clip(ov+np.where((rel>=0)&(rel<.12),.12*np.exp(-np.maximum(rel,0)/.045),0),0,1)
  arr[:,k]=np.maximum(arr[:,k],val)
 keys=np.maximum(keys,arr*np.interp(ft,times,weights[j])[:,None])
(A/'evolution_keys.bin').write_bytes(np.rint(keys*255).astype(np.uint8).tobytes())
(A/'eight_events.json').write_text(json.dumps(sorted(e1,key=lambda a:a['t']),separators=(',',':')))
(A/'poly_events.json').write_text(json.dumps(sorted(e2,key=lambda a:a['t']),separators=(',',':')))
for name,x in [('chip',chip),('eight',narrow),('poly',wide),('evolution',out)]:
 sf.write(A/f'{name}.flac',x,SR,subtype='PCM_24')
# exactly ONE lossy encoding for final video's master
subprocess.run(['ffmpeg','-y','-v','error','-i',str(A/'evolution.flac'),'-c:a','aac','-b:a','320k','-movflags','+faststart',str(A/'evolution.m4a')],check=True)
report['stages']=[]
for i in range(6):
 a=i*36.5+2;b=min(216,(i+1)*36.5-2);piece=out[round(a*SR):round(b*SR)]
 report['stages'].append({'span':[a,b],'LUFS':loud(out,a,b),'LRCorrelation':float(np.corrcoef(piece.T)[0,1]),'sideRMS':float(np.sqrt(np.mean(((piece[:,0]-piece[:,1])*.5)**2)))})
report['pureOriginalMaxErrorAfter147']=float(np.max(abs(out[147*SR:219*SR]-original[147*SR:219*SR]*safety)))
report['finalIsNativeStereo']=True;report['audioInNewVideoReferences']=False
(A/'audio_r8_settings.json').write_text(json.dumps({'originalGain':10**(report['original']['gainDB']/20)*safety,'unityOriginalGain':1,'evolutionFormat':'audio/flac','standaloneFormat':'audio/flac'}))
(R/'render/audio_qc.json').write_text(json.dumps(report,indent=2))
# Optional 5.1 spatial UP-MIX, never mixed into the main two-channel film.
# L/R + reduced correlated centre allow front downmix recovery; LFE is filtered.
from scipy.signal import butter,sosfilt
sur=np.zeros((L,6),np.float32)
M=out.mean(1);S=(out[:,0]-out[:,1])*.5
g=np.clip((times-109.5)/73,0,1)
sur[:,0]=out[:,0]-.2*g*M;sur[:,1]=out[:,1]-.2*g*M
sur[:,2]=.2*np.sqrt(2)*g*M
sur[:,3]=sosfilt(butter(2,80,fs=SR,output='sos'),M)*.12*g
for ch,lag,sign in [(4,round(.022*SR),1),(5,round(.031*SR),-1)]:
 sur[lag:,ch]=S[:-lag]*(.30*g[lag:])*sign
sf.write(A/'optional_5_1_upmix.flac',sur,SR,subtype='PCM_24')
# Audition four representative positions, with short edge fades.
parts=[]
for a in [8,50,88,151,190]:
 p=out[round(a*SR):round((a+6)*SR)].copy();n=round(.10*SR);p[:n]*=np.linspace(0,1,n)[:,None];p[-n:]*=np.linspace(1,0,n)[:,None];parts.append(p)
sf.write(A/'audition.flac',np.concatenate(parts),SR,subtype='PCM_24')
print(json.dumps(report,indent=2),flush=True)
