"""Repair the 13-second articulation boundary, retain all other mastered audio.
The original recording is NEVER resynthesized. Spectrum display is a separate
analysis product, not a claimed transcription or extra audio voice.
"""
from pathlib import Path
import json,subprocess,hashlib
import numpy as np,soundfile as sf
from scipy.ndimage import gaussian_filter1d
R=Path(__file__).resolve().parents[1];A=R/'assets';SR=44100;END=220.5;L=round(SR*END);N=13230
old,sr=sf.read(A/'old_evolution.flac',dtype='float32',always_2d=True)
chip,sr=sf.read(A/'old_chip.flac',dtype='float32',always_2d=True)
assert sr==SR and len(old)==L and len(chip)==L
es=json.loads((A/'old_chip_events.json').read_text());report={'revision':'R9.1','changedNotes':[], 'noNewEQCompressorLimiter':True}
# Only the unfinished tail of the same 65 Hz introduction is rearticulated.
# End at the first actual bass phrase (15.212969 s), not an arbitrary 13 s gate.
newes=[dict(e) for e in es]
for j,e in enumerate(newes):
 if 13<=e['t']<15.2 and e['f']==65 and e['d']<.03:
  oldd=e['d'];e['d']=min(.100,es[j+1]['t']-e['t']-.008)
  report['changedNotes'].append({'t':e['t'],'frequency':65,'oldDuration':oldd,'newDuration':e['d']})
# Recover the slowly varying existing gain from its known synthesis basis.
# This avoids re-leveling the whole film or changing any unrequested passage.
def raw_intro(score):
 out=np.zeros(round(SR*16.0),np.float32)
 for e in score:
  if e['t']>=15.3:break
  s=round(e['t']*SR);d=e['d'];n=min(round(d*SR),len(out)-s)
  v=np.arange(n,dtype=np.float64)/SR;p=2*np.pi*e['f']*v
  env=np.minimum(1,v/.004)*np.minimum(1,np.maximum(0,d-v)/.010)*(.48+.52*np.exp(-4*v))
  y=(.58*np.sin(p)+.24*np.sin(2*p)+.11*np.sin(3*p)+.05*np.sin(5*p))*env*.55
  out[s:s+n]+=y.astype(np.float32)
 lag=round(.108695*SR);out[lag:]+=out[:-lag].copy()*.065
 return out
raw=raw_intro(es);fixed=raw_intro(newes);hop=220;gt=[];gv=[]
for s in range(0,len(raw)-hop,hop):
 v=raw[s:s+hop];a=chip[s:s+hop,0];en=float(v@v)
 if en>.002:
  g=float(v@a/en)
  if .001<g<10:gt.append((s+hop/2)/SR);gv.append(g)
gain=np.interp(np.arange(len(raw))/SR,gt,gv)
delta=(fixed-raw)*gain
newchip=chip.copy();newchip[:len(delta)]+=delta[:,None]
master=old.copy();master[:len(delta)]+=delta[:,None]
assert np.max(abs(master))<.95
report['before13MaxDelta']=float(np.max(abs(master[:13*SR]-old[:13*SR])))
report['after15_1MaxDelta']=float(np.max(abs(master[round(15.1*SR):]-old[round(15.1*SR):])))
report['monoMaxLRDifferenceBefore35_5']=float(np.max(abs(master[:round(35.5*SR),0]-master[:round(35.5*SR),1])))
report['peakDBFS']=float(20*np.log10(abs(master).max()))
report['gainRecoveryRange']=[float(min(gv)),float(max(gv))]
for name,a in [('chip',newchip),('evolution',master)]:sf.write(A/(name+'.flac'),a,SR,subtype='PCM_24')
(A/'chip_events.json').write_text(json.dumps(newes,separators=(',',':')))
keys=np.frombuffer((A/'old_evolution_keys.bin').read_bytes(),np.uint8).copy().reshape(N,72)
ft=np.arange(N)/60
for change in report['changedNotes']:
 t=change['t'];d=change['newDuration'];k=0
 ov=np.maximum(0,np.minimum(ft+1/60,t+d)-np.maximum(ft,t))*60
 rel=ft-t-d;vals=np.clip(ov+np.where((rel>=0)&(rel<.12),.12*np.exp(-np.maximum(0,rel)/.045),0),0,1)
 keys[:,k]=np.maximum(keys[:,k],np.rint(vals*255).astype(np.uint8))
(A/'evolution_keys.bin').write_bytes(keys.tobytes())
# ORIGINAL spectrum: semitone-centred windowed RMS energies (not MIDI events).
pcm=subprocess.check_output(['ffmpeg','-v','error','-i',str(A/'original_reference.m4a'),'-ac','2','-ar',str(SR),'-f','f32le','pipe:1'])
x=np.frombuffer(pcm,'<f4').reshape(-1,2);fft=8192;hop=735;win=np.hanning(fft).astype(np.float32)
freqs=np.fft.rfftfreq(fft,1/SR).astype(np.float32);centers=440*2**((np.arange(72)+36-69)/12)
weights=np.exp(-.5*((freqs[None,:]-centers[:,None])/np.maximum(SR/fft,centers[:,None]*.035))**2).astype(np.float32)
weights/=weights.sum(1,keepdims=True)
padded=np.pad(x,((fft//2,fft+round(1.5*SR)),(0,0)))
amp=np.zeros((N,72),np.float32)
for start in range(0,N,128):
 frames=np.arange(start,min(N,start+128));ix=frames[:,None]*hop+np.arange(fft)[None,:]
 block=padded[ix]*win[None,:,None]
 spectrum=np.fft.rfft(block,axis=1);pwr=(abs(spectrum)**2).mean(axis=2).astype(np.float32)*(2/win.sum())**2
 amp[start:start+len(frames)]=np.sqrt(pwr@weights.T)
ref=float(np.percentile(amp[:219*60,:61],99.5));db=20*np.log10(np.maximum(amp,1e-9)/ref)
v=np.clip((db+34)/34,0,1)**1.35
v=gaussian_filter1d(v,.8,axis=0,mode='nearest');v[219*60:]=0
spec=np.rint(v*255).astype(np.uint8);(A/'spectrum_keys.bin').write_bytes(spec.tobytes())
report['spectrum']={'frames':N,'bands':72,'visibleBands':61,'midiCentres':[36,107],'window':8192,'hop':735,'method':'Hann-window power; Gaussian frequency-band RMS; common fixed 34 dB display range','referenceAmplitude':ref,'isTranscription':False,'mutatesAudio':False,'source':'original_reference.m4a','meanVisibleActiveKeysAfter150':float(np.count_nonzero(spec[150*60:210*60,:61]>15,axis=1).mean())}
# Latest delivery AAC is encoded once and muxed without re-encoding.
subprocess.run(['ffmpeg','-y','-v','error','-i',str(A/'evolution.flac'),'-c:a','aac','-b:a','320k','-movflags','+faststart',str(A/'evolution.m4a')],check=True)
# actual comparable before/after excerpts, same time window with fades on edges only
parts=[]
for a in [old,master]:
 y=a[round(11*SR):round(15.3*SR)].copy();fade=round(.04*SR);y[:fade]*=np.linspace(0,1,fade)[:,None];y[-fade:]*=np.linspace(1,0,fade)[:,None];parts.extend([y,np.zeros((round(.4*SR),2),np.float32)])
sf.write(A/'intro_AB.flac',np.concatenate(parts),SR,subtype='PCM_24')
sf.write(A/'intro_fixed.flac',master[:24*SR],SR,subtype='PCM_24')
(R/'render/audio_r91.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps(report,ensure_ascii=False,indent=2),flush=True)
