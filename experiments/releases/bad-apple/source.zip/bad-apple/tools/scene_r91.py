"""R9.1: separated caption gutters, source-bound magnifier leaders, permanent
cutaway, and explicitly labelled source-spectrum keyboard feedback. The optical
kernel and all media alignment remain R9; no detector data are modified here."""
from scene_r9 import Scene as OldScene,STAGES
from scene import unit,smooth,power
from graphics_text import stamp,text_mask
from array_panel import array_texture
import numpy as np,cv2,math

class Scene(OldScene):
 def __init__(self,w=1080,h=1440):
  super().__init__(w,h);self.spectralValues=np.zeros(72);self.spectralMode=0
  self.labelBoxes=[];self.leaders=[]
 def camera(self,t,f):
  super().camera(t,f);self.closed=0 # full film is a cutaway, no automatic closure
 def layout(self):
  W,H=self.W,self.H;s=W/1080
  w=round(W*.218);pad=max(5,round(10*s));head=max(23,round(40*s));iw=w-2*pad;ih=round(iw*.75);h=head+ih+pad
  x=round(W*.027);y=min(round(H*.635),round(H*.80)-h)
  return x,y,w,h,pad,head,iw,ih
 def panels(self,im,f,source,pwr):
  W,H=self.W,self.H;s=W/1080;x,y,w,h,pad,head,iw,ih=self.layout();x2=W-x-w
  self.labelBoxes=[]
  # The two leaders locate the actual silicon footprint. They are inspection
  # outlines, not extra beams or sources. They leave the nearest whole-chip edge.
  corners=np.array([[f.ow/2,0,f.oh/2],[-f.ow/2,0,f.oh/2],[-f.ow/2,0,-f.oh/2],[f.ow/2,0,-f.oh/2]])
  q=self.project(corners);nearest=np.argsort(q[:,0])[-2:];near=q[nearest];near=near[np.argsort(near[:,1])]
  dest=np.array([[x2+pad,y+head],[x2+pad,y+head+ih]])
  self.leaders=[]
  cv2.polylines(im,[np.rint(q).astype(np.int32)],True,(145,)*3,max(1,round(1.1*s)),cv2.LINE_AA)
  for P,Q in zip(near,dest):
   self.leaders.append({'from':P.tolist(),'to':Q.tolist(),'type':'magnifier-leader-not-light'})
   cv2.line(im,tuple(np.rint(P).astype(int)),tuple(np.rint(Q).astype(int)),(106,)*3,max(1,round(1.2*s)),cv2.LINE_AA)
  def tile(title,sub,image,left):
   p=np.full((h,w,3),13,np.uint8);p[:head]=(21,22,24)
   p[head:head+ih,pad:pad+iw]=image
   cv2.rectangle(p,(0,0),(w-1,h-1),(91,)*3,1,cv2.LINE_AA)
   fs=max(10,round(20*s));ss=max(9,round(17*s))
   while sub and text_mask(title,fs).shape[1]+text_mask(sub,ss).shape[1]>w-3*pad:
    if ss>10:ss-=1
    else:fs-=1
   stamp(p,title,pad,(head-text_mask(title,fs).shape[0])//2,fs,223)
   if sub:
    sw=text_mask(sub,ss).shape[1];stamp(p,sub,w-pad-sw,(head-text_mask(sub,ss).shape[0])//2,ss,160)
   im[y:y+h,left:left+w]=p
   self.labelBoxes.append({'text':title,'box':[left,y,w,head],'image':[left+pad,y+head,iw,ih]})
  # independent reference monitor, with an actual opaque header gutter
  tx=cv2.resize(source,(iw,ih),interpolation=cv2.INTER_AREA)
  if tx.ndim==2:tx=np.repeat(tx[...,None],3,2)
  tile('输入监看','',np.rint(tx*pwr).clip(0,255).astype(np.uint8),x)
  nn=unit(f.normals[0]);tilt=math.atan2(-nn[0],nn[1])-math.pi/15
  tx,how=array_texture(f.duty,f.w,f.h,iw,ih,float(nn[0]),float(nn[1]),-math.sin(-math.pi/15+tilt),math.cos(-math.pi/15+tilt),getattr(f,'isolate',-1))
  tx=np.repeat(np.rint(tx*(.2+.8*pwr)).astype(np.uint8)[...,None],3,2)
  tile('微镜阵列',f'{f.w}×{f.h}',tx,x2)
  self.arrayPanel={'content':[x2+pad,y+head,iw,ih],'cells':f.N,'columns':f.w,'rows':f.h,'mode':how,'label':'微镜阵列','leaderCount':2}
 def cue(self,im,t,f):
  self.cueBox=None
  for st in STAGES:
   at=st['start']
   if not at<=t<at+3.8:continue
   a=smooth(at,at+.30,t)*(1-smooth(at+3.25,at+3.8,t));W,H=self.W,self.H;s=W/1080
   # This is the unused area ABOVE the array panel and OUTSIDE the image.
   _,py,_,_,_,_,_,_=self.layout();cw=round(W*.32);x=W-round(W*.027)-cw;ch=round(100*s)
   y=max(round(max(self.screenQuad[:,1])+30*s),round(py-165*s))
   y=min(y,py-ch-round(22*s))
   src={'黑白影绘':'黑白','灰度重绘':'灰度','彩色重绘':'彩色','MMD 终章':'MMD'}[st['source']]
   one=f"{st['w']} × {st['h']} · {src}";two=f"{st['timbre']} · {st['space']}"
   p=np.full((ch,cw,3),15,np.uint8);cv2.rectangle(p,(0,0),(cw-1,ch-1),(82,)*3,1,cv2.LINE_AA)
   fs=max(16,round(29*s));ss=max(12,round(21*s));pad=round(15*s)
   while text_mask(one,fs).shape[1]>cw-pad*2:fs-=1
   while text_mask(two,ss).shape[1]>cw-pad*2:ss-=1
   stamp(p,one,pad,round(15*s),fs,236);stamp(p,two,pad,round(59*s),ss,173)
   roi=im[y:y+ch,x:x+cw];cv2.addWeighted(p,a,roi,1-a,0,dst=roi)
   self.cueBox={'box':[x,y,cw,ch],'text':one,'secondary':two,'screenBottom':float(max(self.screenQuad[:,1])),'panelTop':py}
   break
 def keyboard(self,im,keys,pwr):
  keys=np.zeros(72) if keys is None else keys;spec=np.asarray(self.spectralValues);mix=float(self.spectralMode)
  self.poly(im,[[-3.02,-.11,3.32],[3.02,-.11,3.32],[3.02,-.55,5.73],[-3.02,-.55,5.73]],(33,34,37),95,2)
  self.poly(im,[[-3.02,-.55,5.73],[3.02,-.55,5.73],[3.02,-.82,5.73],[-3.02,-.82,5.73]],(27,28,31),65,1)
  self.keyPolygons=[]
  for black in [False,True]:
   for idx,kx,b in self.keys:
    if b!=black:continue
    press=float(keys[idx]);response=float(spec[idx])*mix;light=max(press,response)
    x=(kx/self.nwhite-.5)*5.72;kw=5.72/self.nwhite*(.58 if b else .96)
    z0=3.48;z1=4.87 if b else 5.60;y0=.02 if b else -.10;y1=(-.33 if b else -.51)-press*.20
    q=np.array([[x-kw/2,y0,z0],[x+kw/2,y0,z0],[x+kw/2,y1,z1],[x-kw/2,y1,z1]])
    front=q[[3,2,2,3]].copy();front[2:,1]-=.09
    tone=int((24 if b else 163)+light*(167 if b else 88)*pwr)
    self.poly(im,front,max(12,tone//2),26,1);self.poly(im,q,tone,10 if b else 40,1)
    self.keyPolygons.append({'index':idx,'world':q.tolist(),'press':press,'spectrum':response,'light':light})
    if light>.01:
     cen=q.mean(0);qi=cen+(q-cen)*.88;self.poly(im,qi,None,int(235*light*pwr),2)
     self.line(im,[q[3]+(q[0]-q[3])*.035,q[2]+(q[1]-q[2])*.035],int(255*light*pwr),3)
  self.line(im,[[-2.89,-.62,5.741],[2.89,-.62,5.741]],112,1)
  # Name the change in representation. Spectral bands light real key faces,
  # but do not invent a transcription or depressed keys from a full recording.
  p=self.project([[-2.8,-.70,5.747]])[0];label='原声频谱' if mix>.5 else '音符演奏'
  sz=max(10,round(self.W/1080*17));stamp(im,label,p[0],p[1],sz,184)
  self.keyFeedback=label
