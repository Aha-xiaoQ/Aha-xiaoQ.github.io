import { SCENES, INTRO, OUTRO, DURATION } from '../src/beat/index.js';

// D–F–A–G, passed between voices. Times inside a chapter are written in seconds.
const MOTIF = [0, 3, 7, 5];
export const FULL_CUES = Object.freeze({
  beforeBicycle: 3,
  saharaPause: 7.45,
  saharaHooves: Object.freeze([7.93, 8.13]),
  songHarmonic: 32,
  shadowPowerOn: 89,
  scopeTuning: Object.freeze([91.5, 92.2]),
  pixelCoin: 98,
  chatTyping: Object.freeze([103.5, 105.2]),
  chatMessage: 105.2,
  vaporStutter: Object.freeze([109.5, 109.75, 110, 110.25]),
  verticalComment: 115.6,
  verticalReturn: 116,
  verticalLock: 118.97,
  outroFlashes: Object.freeze([130, 131, 132]),
  outroBell: 136.5,
});

const event = (voice, at, amp, options = {}) => ({ voice, at, amp, ...options });
const note = (voice, at, pitch, amp, length, options = {}) => event(voice, at, amp, { note: pitch, length, ...options });
const phrase = (voice, rows, options) => rows.map(([at, pitch, amp, length]) => note(voice, at, pitch, amp, length, options));
const hits = (voice, rows, options) => rows.map(([at, amp, low = false]) => event(voice, at, amp, { low, ...options }));
const theme = (voice, root, rows, options) => phrase(voice, rows.map(([at, amp, length], i) => [at, root + MOTIF[i], amp, length]), options);
const room = (seconds, wet, seed, damping = 0.17) => ({ seconds, wet, seed, damping });
const beginning = Object.fromEntries(SCENES.map(({ id, start }) => [id, start]));
const cue = (id, time) => Math.round((time - beginning[id]) * 10000) / 10000;

const intro = {
  color: 'grave strings',
  gain: 1.68,
  room: room(1.38, 0.96, 819),
  events: [
    ...phrase('bow', [[0, 26, 0.30, 3.35], [0.11, 38, 0.20, 2.21], [0.44, 45, 0.105, 2.08]], { pan: -0.18, attack: 0.40 }),
    ...theme('bow', 50, [[0.34, 0.12, 0.72], [0.97, 0.145, 0.76], [1.56, 0.17, 0.78], [2.05, 0.145, 0.92]], { pan: 0.20, attack: 0.17 }),
    note('bow', 2.07, 41, 0.15, 1.20, { pan: -0.28, attack: 0.46 }),
    event('drum', FULL_CUES.beforeBicycle, 0.36, { low: true }),
    note('metal', FULL_CUES.beforeBicycle, 30, 0.21, 1.29, { model: 'gong', pan: 0.15 }),
    ...phrase('bow', [[3, 26, 0.31, 1.74], [3.005, 38, 0.23, 1.6], [3.025, 53, 0.205, 1.09], [3.125, 57, 0.165, 1.15]], { attack: 0.025, pan: -0.12 }),
    note('string', 3.52, 69, 0.105, 1.28, { model: 'harp', pan: 0.25 }),
    event('atmosphere', 4.04, 0.036, { length: 1.06, tone: 580, pan: -0.16 }),
  ],
};

const sahara = {
  color: 'skin drum and syllabic chant',
  gain: 3.49,
  room: room(0.64, 0.48, 4938),
  levels: [[0, 1], [2.39, 1], [cue('sahara', FULL_CUES.saharaPause), 0.11], [2.75, 0.11], [2.89, 1]],
  events: [
    event('atmosphere', 0, 0.022, { length: 5.60, tone: 520 }),
    ...hits('drum', [[0.005, 0.29, true], [0.738, 0.15], [1.005, 0.11], [1.496, 0.245, true], [1.856, 0.135], [2.12, 0.12]], { pan: -0.11 }),
    ...theme('breathChoir', 50, [[0.095, 0.30, 0.39], [0.601, 0.28, 0.39], [1.072, 0.37, 0.41], [1.578, 0.33, 0.57]], { pan: 0.12 }),
    note('breathChoir', 0.04, 38, 0.17, 0.91, { vowel: 'u', harmony: true, pan: -0.21 }),
    note('breathChoir', 1.57, 45, 0.13, 0.58, { vowel: 'u', harmony: true, pan: -0.21 }),
    event('wood', cue('sahara', FULL_CUES.saharaHooves[0]), 0.21, { tone: 345, pan: -0.24, dry: true }),
    event('wood', cue('sahara', FULL_CUES.saharaHooves[1]), 0.18, { tone: 395, pan: 0.21, dry: true }),
    ...hits('drum', [[3.51, 0.265, true], [4.247, 0.145], [4.742, 0.155, true], [4.986, 0.16], [5.50, 0.275, true]], { pan: -0.07 }),
    ...theme('breathChoir', 50, [[3.515, 0.27, 0.35], [3.987, 0.25, 0.28], [4.242, 0.34, 0.40], [4.76, 0.34, 0.56]], { vowel: 'u', pan: 0.08 }),
    note('breathChoir', 5.475, 50, 0.26, 0.46, { harmony: true }),
  ],
};

const egypt = {
  color: 'arched harp',
  gain: 2.49,
  room: room(1.21, 0.79, 1361),
  events: [
    ...phrase('string', [[0.01, 38, 0.225, 1.33], [0.49, 45, 0.108, 0.91], [1.48, 36, 0.17, 1.26], [2.23, 43, 0.125, 1.05], [3.17, 38, 0.21, 1.21], [4.40, 45, 0.13, 0.98], [5.36, 38, 0.16, 0.69]], { model: 'harp', pan: -0.23 }),
    ...theme('string', 62, [[0.19, 0.17, 0.93], [0.76, 0.16, 0.96], [1.24, 0.18, 0.91], [1.79, 0.15, 0.72]], { model: 'harp', pan: 0.18 }),
    ...phrase('string', [[2.56, 60, 0.15, 0.76], [2.79, 65, 0.13, 0.53], [3.05, 69, 0.15, 0.54], [3.57, 72, 0.18, 0.77], [4.25, 69, 0.17, 0.59], [4.74, 67, 0.138, 0.72], [5.18, 65, 0.125, 0.51], [5.65, 62, 0.17, 0.82]], { model: 'harp', pan: 0.11 }),
    event('atmosphere', 0.11, 0.026, { tone: 359, length: 5.23, pan: -0.1 }),
    ...hits('wood', [[1.52, 0.053], [3.50, 0.057], [5.52, 0.046]], { tone: 278, length: 0.23, pan: -0.31 }),
  ],
};

const han = {
  color: 'tuned bronze bells with two strike pitches',
  gain: 2.69,
  room: room(1.19, 0.69, 7568),
  events: [
    ...phrase('metal', [[0.005, 38, 0.25, 1.64], [1.50, 43, 0.18, 1.01], [2.99, 38, 0.25, 1.44], [4.49, 45, 0.20, 1.18], [5.52, 38, 0.19, 0.88]], { pan: -0.30 }),
    ...theme('metal', 62, [[0.28, 0.14, 0.93], [0.77, 0.125, 0.81], [1.27, 0.155, 0.86], [1.99, 0.13, 1.02]], { pan: 0.13 }),
    ...phrase('metal', [[2.53, 65, 0.09, 0.68], [3.26, 74, 0.116, 0.75], [3.75, 77, 0.125, 0.58], [4.24, 81, 0.143, 0.76], [4.75, 79, 0.104, 0.67], [5.29, 74, 0.123, 0.81]], { pan: 0.31, cents: -8 }),
    note('metal', 3.315, 77, 0.06, 0.59, { pan: 0.12, cents: 9 }),
    ...hits('drum', [[0.99, 0.115, true], [2.25, 0.108], [4.01, 0.118, true], [5.75, 0.071]], { pan: -0.28 }),
  ],
};

const tang = {
  color: 'pipa plectrum and tremolo',
  gain: 2.73,
  room: room(0.82, 0.61, 816),
  events: [
    ...theme('string', 62, [[0.01, 0.151, 0.56], [0.39, 0.140, 0.43], [0.78, 0.18, 0.61], [1.51, 0.16, 0.59]], { model: 'pipa', pan: 0.13, slide: -21 }),
    ...phrase('string', [[0.02, 45, 0.136, 0.79], [1.26, 50, 0.10, 0.66], [2.51, 45, 0.12, 0.74], [4.0, 43, 0.11, 1.02], [5.54, 50, 0.127, 0.64]], { model: 'pipa', pan: -0.24 }),
    ...[1.78, 1.9, 2.025, 2.14, 2.25, 2.355, 2.46, 2.55, 2.65, 2.745].map((at, i) => note('string', at, 67, 0.082 + i * 0.004, 0.22, { slide: i * 2, model: 'pipa', pan: 0.14 })),
    ...phrase('string', [[2.95, 69, 0.15, 0.52], [3.18, 72, 0.14, 0.48], [3.46, 74, 0.15, 0.57], [3.99, 69, 0.15, 0.54], [4.35, 67, 0.13, 0.31], [4.64, 65, 0.133, 0.45], [5.12, 67, 0.114, 0.34], [5.58, 62, 0.154, 0.65]], { model: 'pipa', pan: 0.13, slide: -29 }),
    ...hits('wood', [[0.75, 0.094], [1.51, 0.064], [3.03, 0.086], [3.78, 0.062], [4.27, 0.073], [5.5, 0.091]], { tone: 485, pan: -0.21 }),
  ],
};

const song = {
  color: 'guqin harmonics and finger slides',
  gain: 2.03,
  room: room(1.31, 0.92, 653, 0.10),
  events: [
    event('atmosphere', 0, 0.023, { length: 5.60, tone: 362, pan: -0.24 }),
    note('qin', 0.02, 38, 0.22, 1.51, { touch: 0.23, pan: -0.17 }),
    ...theme('qin', 62, [[0.15, 0.17, 0.8], [0.69, 0.16, 0.65], [1.26, 0.22, 0.76], [1.81, 0.175, 1.20]], { pan: 0.12, slide: -17 }),
    note('qin', 1.49, 43, 0.078, 0.87, { touch: 0.31, pan: -0.18 }),
    event('wood', 2.4, 0.043, { tone: 275, length: 0.15, pan: -0.12 }),
    note('qin', cue('song', FULL_CUES.songHarmonic), 57, 0.31, 1.16, { touch: 0.25, harmonic: true, pan: 0.16 }),
    ...phrase('qin', [[3.58, 55, 0.175, 0.93], [4.1, 53, 0.165, 0.91]], { touch: 0.22, harmonic: true, pan: -0.10 }),
    note('qin', 4.63, 48, 0.139, 0.93, { slide: -32, pan: -0.15 }),
    note('qin', 5.12, 50, 0.173, 1.08, { touch: 0.27, pan: -0.10 }),
    note('qin', 5.62, 62, 0.123, 0.45, { touch: 0.22, pan: 0.13 }),
  ],
};

const riverside = {
  color: 'dizi, small gong and drum',
  gain: 2.80,
  room: room(0.71, 0.42, 2215),
  events: [
    ...theme('flute', 74, [[0.04, 0.153, 0.48], [0.52, 0.13, 0.38], [0.99, 0.17, 0.48], [1.5, 0.13, 0.59]], { model: 'dizi', pan: 0.12 }),
    ...phrase('flute', [[2.19, 76, 0.115, 0.20], [2.45, 77, 0.13, 0.26], [2.79, 81, 0.138, 0.40], [3.29, 86, 0.12, 0.31], [3.7, 84, 0.10, 0.31], [4.05, 81, 0.126, 0.44], [4.55, 79, 0.114, 0.22], [4.84, 77, 0.126, 0.22], [5.21, 74, 0.143, 0.66]], { model: 'dizi', pan: 0.15 }),
    ...hits('drum', [[0.01, 0.18, true], [0.75, 0.107], [1.25, 0.121], [1.75, 0.155, true], [2.26, 0.132], [3.02, 0.18, true], [3.50, 0.10], [4.00, 0.174, true], [4.75, 0.11], [5.25, 0.147], [5.75, 0.169, true]], { pan: -0.17 }),
    ...phrase('metal', [[0, 48, 0.082, 0.69], [2.49, 51, 0.09, 0.71], [4.49, 48, 0.086, 0.64], [5.76, 50, 0.095, 0.75]], { model: 'gong', pan: -0.30 }),
  ],
};

const maya = {
  color: 'ceramic flute and wood drum',
  gain: 2.52,
  room: room(0.91, 0.57, 1727),
  events: [
    ...theme('flute', 74, [[0.23, 0.22, 0.47], [0.99, 0.20, 0.33], [1.26, 0.22, 0.38], [1.77, 0.23, 0.59]], { model: 'ceramic', pan: 0.16 }),
    ...phrase('flute', [[2.82, 62, 0.20, 0.51], [3.52, 65, 0.18, 0.44], [4.04, 69, 0.20, 0.36], [4.50, 67, 0.19, 0.46], [5.28, 74, 0.213, 0.57]], { model: 'ceramic', pan: -0.10, cents: -14 }),
    ...hits('wood', [[0.01, 0.21], [0.47, 0.124], [0.73, 0.17], [1.47, 0.19], [2.145, 0.13], [2.73, 0.16], [3.24, 0.16], [3.75, 0.19], [4.23, 0.127], [4.48, 0.17], [4.98, 0.22], [5.72, 0.16]], { tone: 295, length: 0.22, pan: -0.20 }),
    ...hits('wood', [[0.25, 0.12], [1.04, 0.11], [2.0, 0.14], [2.23, 0.11], [3.27, 0.10], [3.97, 0.136], [4.83, 0.114], [5.48, 0.122]], { tone: 510, length: 0.13, pan: 0.28 }),
    ...hits('drum', [[0.015, 0.17, true], [1.475, 0.093, true], [2.765, 0.16, true], [4.98, 0.14, true]]),
  ],
};

const mughal = {
  color: 'sitar sympathetic strings and tabla',
  gain: 2.13,
  room: room(1.0, 0.67, 8871),
  events: [
    ...phrase('string', [[0.01, 38, 0.112, 1.42], [0.285, 45, 0.07, 1.33], [0.5, 50, 0.077, 1.34], [2.04, 38, 0.111, 1.57], [3.52, 45, 0.087, 1.43], [4.71, 38, 0.110, 1.40]], { model: 'harp', pan: -0.18 }),
    ...theme('string', 62, [[0.16, 0.16, 0.85], [0.72, 0.14, 0.62], [1.24, 0.178, 0.91], [1.78, 0.159, 0.96]], { model: 'sitar', pan: 0.18, slide: -76 }),
    ...phrase('string', [[2.39, 64, 0.13, 0.70], [2.99, 62, 0.139, 0.67], [3.28, 69, 0.149, 0.63], [3.77, 72, 0.154, 0.64], [4.21, 74, 0.159, 0.68], [4.73, 69, 0.147, 0.65], [5.21, 67, 0.153, 0.62], [5.70, 62, 0.154, 0.73]], { model: 'sitar', pan: 0.17, slide: -112 }),
    ...hits('tabla', [[0.008, 0.183, true], [0.52, 0.13], [0.76, 0.117], [1.02, 0.142, true], [1.26, 0.11], [1.51, 0.16], [1.81, 0.17, true], [2.04, 0.127], [2.53, 0.15, true], [2.805, 0.128], [3.04, 0.14], [3.42, 0.17, true], [3.64, 0.128], [3.89, 0.112], [4.10, 0.19, true], [4.51, 0.136], [4.77, 0.123], [5.01, 0.171, true], [5.25, 0.139], [5.51, 0.156], [5.735, 0.16, true]], { pan: -0.16 }),
  ],
};

const bada = {
  color: 'xiao breath and open space',
  gain: 1.55,
  room: room(1.39, 0.86, 1871, 0.12),
  events: [
    ...theme('flute', 62, [[0.34, 0.264, 0.68], [1.03, 0.223, 0.56], [1.69, 0.263, 0.75], [2.39, 0.232, 0.78]], { model: 'xiao', pan: 0.14 }),
    ...phrase('flute', [[3.75, 57, 0.205, 0.54], [4.42, 60, 0.213, 0.35], [4.95, 62, 0.260, 0.94]], { model: 'xiao', pan: 0.08, fall: -48 }),
    note('qin', 0.02, 38, 0.10, 1.33, { touch: 0.34, pan: -0.24 }),
    note('qin', 3.52, 45, 0.083, 1.18, { harmonic: true, touch: 0.24, pan: -0.14 }),
    event('atmosphere', 0.02, 0.031, { length: 5.86, tone: 294, pan: -0.21 }),
  ],
};

const wayang = {
  color: 'layered gamelan gong cycle',
  gain: 2.06,
  room: room(1.03, 0.65, 7812),
  events: [
    ...phrase('metal', [[0.01, 30, 0.22, 2.26], [1.99, 38, 0.121, 1.26], [4.0, 33, 0.166, 1.35], [5.64, 30, 0.214, 1.32]], { model: 'gong', pan: -0.20 }),
    ...phrase('metal', [[0.04, 50, 0.16, 0.66], [0.53, 53.13, 0.14, 0.57], [1.04, 57.17, 0.15, 0.54], [1.52, 55.22, 0.164, 0.60], [2.05, 60.23, 0.14, 0.59], [2.51, 57.17, 0.138, 0.57], [3.01, 55.22, 0.152, 0.53], [3.51, 53.13, 0.16, 0.6], [4.01, 50, 0.16, 0.66], [4.52, 55.22, 0.141, 0.57], [5.02, 53.13, 0.165, 0.55], [5.52, 50, 0.178, 0.59]], { model: 'saron', pan: -0.12 }),
    ...[62, 67.22, 65.13, 69.17, 67.22, 72.23, 69.17, 67.22, 65.13, 69.17, 67.22, 65.13, 62, 65.13, 67.22, 69.17, 74, 72.23, 69.17, 67.22, 65.13, 62].map((pitch, i) =>
      note('metal', 0.26 + i * 0.25, pitch, i % 2 ? 0.075 : 0.091, 0.36, { model: 'bonang', pan: i % 2 ? -0.33 : 0.31, cents: i % 3 - 1 })),
    ...hits('drum', [[0.52, 0.113, true], [1.28, 0.086], [1.76, 0.107], [2.72, 0.115, true], [3.23, 0.088], [3.76, 0.115], [4.52, 0.125, true], [5.485, 0.102]], { pan: -0.12 }),
  ],
};

const ukiyo = {
  color: 'shamisen bachi and sawari',
  gain: 2.44,
  room: room(0.82, 0.43, 3431),
  events: [
    ...phrase('string', [[0.02, 38, 0.172, 0.99], [1.72, 45, 0.11, 0.61], [2.76, 38, 0.16, 0.72], [4.5, 45, 0.132, 0.56], [5.61, 38, 0.175, 0.72]], { model: 'shamisen', pan: -0.20 }),
    ...theme('string', 62, [[0.14, 0.179, 0.59], [0.76, 0.155, 0.53], [1.29, 0.20, 0.69], [1.78, 0.167, 0.66]], { model: 'shamisen', pan: 0.18, slide: -42 }),
    ...phrase('string', [[2.36, 62, 0.168, 0.42], [2.62, 67, 0.16, 0.35], [2.97, 69, 0.177, 0.56], [3.51, 74, 0.155, 0.48], [3.79, 72, 0.15, 0.51], [4.25, 69, 0.173, 0.59], [4.76, 65, 0.154, 0.58], [5.29, 62, 0.161, 0.70]], { model: 'shamisen', pan: 0.11, slide: -96 }),
    ...hits('wood', [[0.52, 0.095], [1.51, 0.075], [2.54, 0.115], [3.22, 0.09], [4.02, 0.11], [4.53, 0.083], [5.48, 0.097]], { tone: 502, pan: -0.23 }),
  ],
};

const starry = {
  color: 'legato string section',
  gain: 2.14,
  room: room(1.58, 0.97, 6897, 0.12),
  events: [
    ...theme('bow', 62, [[0.08, 0.217, 1.1], [0.89, 0.215, 0.92], [1.53, 0.24, 1.22], [2.41, 0.188, 1.22]], { attack: 0.17, pan: 0.24 }),
    ...phrase('bow', [[0.005, 38, 0.223, 1.95], [1.5, 41, 0.216, 1.54], [2.74, 43, 0.213, 1.47], [3.97, 36, 0.215, 1.43], [5.02, 38, 0.195, 1.23]], { attack: 0.25, pan: -0.32 }),
    ...phrase('bow', [[0.14, 53, 0.133, 1.91], [1.55, 57, 0.134, 1.49], [2.79, 58, 0.125, 1.40], [4.01, 55, 0.11, 1.35], [5.05, 53, 0.135, 1.22]], { attack: 0.24, pan: -0.08 }),
    ...phrase('bow', [[3.31, 72, 0.185, 0.86], [4.05, 74, 0.20, 0.91], [4.81, 77, 0.21, 0.72], [5.42, 81, 0.157, 0.92]], { attack: 0.16, pan: 0.22 }),
    ...phrase('string', [[0.12, 69, 0.084, 0.95], [0.74, 74, 0.071, 0.81], [1.38, 77, 0.078, 0.71], [2.25, 84, 0.079, 0.84], [3.28, 81, 0.087, 0.78], [4.02, 84, 0.066, 0.71], [5.05, 86, 0.079, 0.86]], { model: 'harp', pan: -0.13 }),
  ],
};

const scream = {
  color: 'detuned upper strings and descending glissando',
  gain: 2.15,
  room: room(1.21, 0.77, 7177),
  events: [
    ...phrase('bow', [[0.01, 38, 0.20, 2.35], [2.19, 37, 0.21, 1.81], [3.57, 31, 0.225, 2.60]], { attack: 0.16, pan: -0.28, slide: -31 }),
    ...phrase('bow', [[0.05, 74, 0.14, 1.23], [0.56, 77, 0.154, 1.42], [1.27, 81, 0.171, 1.66], [2.34, 79, 0.17, 1.54]], { attack: 0.13, pan: 0.24, tense: true, slide: 43 }),
    ...phrase('bow', [[0.41, 75, 0.137, 1.30], [1.51, 80, 0.181, 1.83], [2.81, 85, 0.152, 1.36], [3.52, 91, 0.204, 1.15]], { attack: 0.16, pan: -0.12, tense: true, slide: -164 }),
    note('bow', 3.72, 92, 0.12, 1.36, { tense: true, pan: 0.33, slide: -159, attack: 0.07 }),
    note('bow', 4.63, 74, 0.093, 1.5, { tense: true, pan: 0.10, slide: -106, attack: 0.21 }),
    event('drum', 3.48, 0.21, { low: true }),
  ],
};

const shadow = {
  color: 'silent-film piano and pipe organ',
  gain: 1.91,
  room: room(1.22, 0.74, 1919),
  fade: [5.73, 6.0],
  events: [
    note('organ', 0.004, 26, 0.239, 2.51, { pan: -0.13 }),
    ...phrase('organ', [[0.02, 38, 0.14, 1.94], [0.33, 45, 0.103, 1.71], [2.11, 32, 0.179, 1.72], [2.48, 44, 0.133, 2.06], [4.16, 37, 0.172, 1.68], [4.41, 50, 0.12, 1.21]], { pan: -0.24, reed: true }),
    ...theme('string', 62, [[0.12, 0.15, 0.61], [0.76, 0.14, 0.58], [1.25, 0.185, 0.71], [1.75, 0.148, 0.69]], { model: 'piano', pan: 0.23 }),
    ...phrase('string', [[0.15, 41, 0.11, 0.87], [2.13, 44, 0.14, 1.03], [2.46, 64, 0.136, 0.57], [2.72, 68, 0.146, 0.56], [3.02, 71, 0.151, 0.69], [3.77, 70, 0.138, 0.52], [4.21, 62, 0.151, 0.63], [4.47, 61, 0.146, 0.66], [4.92, 57, 0.15, 0.88], [5.54, 50, 0.15, 0.52]], { model: 'piano', pan: 0.22 }),
  ],
};

const scope = {
  color: 'sine pairs and tube power hum',
  gain: 1.93,
  room: room(0.46, 0.34, 1951),
  fade: [5.81, 5.999],
  events: [
    event('wood', cue('scope', FULL_CUES.shadowPowerOn), 0.202, { tone: 890, length: 0.082, pan: -0.12, dry: true }),
    event('sine', cue('scope', FULL_CUES.shadowPowerOn) + 0.007, 0.093, { tone: 182, to: 60, length: 0.27, attack: 0.009 }),
    event('tube', cue('scope', FULL_CUES.shadowPowerOn) + 0.008, 0.108, { length: 5.89, pan: -0.07 }),
    ...theme('sine', 62, [[0.15, 0.187, 0.64], [0.77, 0.172, 0.54], [1.25, 0.198, 0.58], [1.79, 0.194, 0.64]], { pan: 0.26, attack: 0.015 }),
    event('sine', 0.31, 0.082, { tone: 146.83, length: 2.03, pan: -0.32, attack: 0.13 }),
    event('sine', cue('scope', FULL_CUES.scopeTuning[0]), 0.245, { tone: 183, to: 440, length: 0.78, pan: -0.33, attack: 0.045, sustain: 0.94 }),
    event('sine', cue('scope', FULL_CUES.scopeTuning[0]), 0.211, { tone: 381, to: 660, length: 0.78, pan: 0.33, attack: 0.059, sustain: 0.94 }),
    event('sine', cue('scope', FULL_CUES.scopeTuning[1]), 0.103, { tone: 440, length: 1.22, pan: -0.32, sustain: 0.91 }),
    event('sine', cue('scope', FULL_CUES.scopeTuning[1]), 0.095, { tone: 660, length: 1.22, pan: 0.32, sustain: 0.91 }),
    ...phrase('sine', [[4.55, 69, 0.14, 0.37], [4.99, 67, 0.166, 0.33], [5.39, 62, 0.19, 0.56]], { pan: 0.16 }),
  ],
};

export const CHIP_CHANNELS = Object.freeze(['square1', 'square2', 'triangle', 'noise']);
const chipRows = {
  square1: [
    [0.00, 74, 0.098, 0.31], [0.49, 77, 0.093, 0.34], [1.00, 81, 0.109, 0.33], [1.49, 79, 0.097, 0.40],
    [2.03, 77, 0.105, 0.20], [2.28, 74, 0.097, 0.18], [2.53, 69, 0.096, 0.34],
    [3, 86, 0.148, 0.075], [3.079, 93, 0.153, 0.183], [3.269, 91, 0.11, 0.13],
    [3.51, 84, 0.101, 0.20], [3.78, 81, 0.106, 0.20], [4.02, 79, 0.108, 0.39], [4.50, 77, 0.099, 0.37],
    [5.02, 79, 0.108, 0.37], [5.50, 74, 0.121, 0.43],
  ],
  square2: [
    [0.15, 65, 0.061, 0.19], [0.39, 69, 0.061, 0.18], [0.68, 65, 0.058, 0.18], [0.87, 69, 0.064, 0.18],
    [1.149, 72, 0.060, 0.16], [1.39, 69, 0.060, 0.18], [1.638, 72, 0.067, 0.20], [1.894, 70, 0.061, 0.18],
    [2.14, 65, 0.064, 0.19], [2.41, 67, 0.067, 0.20], [2.66, 69, 0.064, 0.29],
    [3.083, 81, 0.069, 0.12], [3.269, 84, 0.079, 0.13], [3.66, 77, 0.065, 0.18], [3.92, 74, 0.066, 0.19],
    [4.17, 70, 0.071, 0.16], [4.41, 74, 0.062, 0.17], [4.68, 69, 0.067, 0.16], [4.91, 67, 0.067, 0.17],
    [5.18, 70, 0.066, 0.15], [5.41, 69, 0.065, 0.17], [5.68, 65, 0.075, 0.25],
  ],
  triangle: [
    [0, 38, 0.238, 0.43], [0.5, 38, 0.187, 0.24], [0.76, 45, 0.163, 0.22], [1, 41, 0.205, 0.44],
    [1.5, 43, 0.193, 0.45], [2.02, 36, 0.201, 0.41], [2.5, 45, 0.189, 0.42], [3.00, 50, 0.195, 0.40],
    [3.5, 45, 0.179, 0.44], [4, 43, 0.214, 0.45], [4.5, 41, 0.204, 0.45], [5, 43, 0.199, 0.45], [5.5, 38, 0.235, 0.46],
  ],
  noise: Array.from({ length: 24 }, (_, i) => [i * 0.25, 0, i % 4 === 0 ? 0.116 : i % 2 === 0 ? 0.14 : 0.060, i % 2 === 0 ? 0.125 : 0.059]),
};

export function pixelEvents() {
  return CHIP_CHANNELS.flatMap((channel, index) => chipRows[channel].map(([at, pitch, amp, length], i, rows) => {
    const end = Math.min(at + length, (rows[i + 1]?.[0] ?? 6) - 0.001);
    return note('chip', at, pitch, amp, end - at, { channel, pan: [0.17, -0.24, 0, -0.07][index], period: i % 4 === 0 ? 19 : i % 2 === 0 ? 12 : 4 });
  }));
}

const pixel = {
  color: 'two pulse channels, triangle and LFSR noise',
  gain: 2.15,
  fade: [5.973, 6],
  events: pixelEvents(),
};

const chat = {
  color: 'desktop MIDI tones, keystrokes and message chime',
  gain: 2.52,
  room: room(0.42, 0.27, 20988),
  events: [
    ...theme('fm', 62, [[0.04, 0.178, 0.35], [0.52, 0.157, 0.34], [1.00, 0.191, 0.39], [1.53, 0.17, 0.56]], { pan: 0.21 }),
    ...phrase('bass', [[0.005, 38, 0.23, 0.74], [0.76, 36, 0.16, 0.51], [1.5, 43, 0.18, 0.66], [2.19, 38, 0.124, 0.35], [4.25, 38, 0.19, 0.67], [5.02, 43, 0.174, 0.43], [5.51, 38, 0.205, 0.48]]),
    ...hits('wood', [[0.13, 0.09], [0.69, 0.066], [1.48, 0.095], [2.15, 0.079], [3.44, 0.145], [4.52, 0.073], [5.57, 0.102]], { tone: 755, pan: -0.27 }),
    ...[2.50, 2.638, 2.732, 2.861, 3.06, 3.235, 3.31, 3.64, 3.739, 3.861, 4.07].map((at, i) =>
      event('wood', at, 0.075 + (i % 4) * 0.011, { tone: [1100, 1310, 935][i % 3], length: 0.072, pan: i % 2 ? 0.12 : -0.16, dry: true })),
    ...phrase('fm', [[cue('chat', FULL_CUES.chatMessage), 81, 0.215, 0.19], [4.34, 77, 0.173, 0.21], [4.53, 86, 0.157, 0.38], [5.27, 72, 0.131, 0.20], [5.53, 74, 0.158, 0.40]], { pan: 0.13 }),
    event('wood', cue('chat', FULL_CUES.chatMessage), 0.148, { tone: 610, length: 0.115, pan: 0.05, dry: true }),
  ],
};

const vapor = {
  color: 'varispeed Rhodes, fretless bass, sax and gated drums',
  tape: true,
  gain: 0.84,
  room: room(4.25, 1.86, 86437, 0.10),
  fade: [5.94, 6.49],
  events: [],
};

const short = {
  color: 'syncopated electronic pop',
  gain: 1.53,
  room: room(0.42, 0.32, 21518, 0.33),
  levels: [[0, 1], [2.41, 1], [2.55, 0.15], [2.95, 0.15], [cue('short', FULL_CUES.verticalReturn), 1]],
  events: [
    ...hits('kick', [[0.01, 0.34, true], [0.757, 0.30], [1.24, 0.295, true], [1.99, 0.30], [cue('short', FULL_CUES.verticalReturn), 0.435, true], [3.74, 0.315], [4.02, 0.336, true], [4.76, 0.31], [5.26, 0.328, true]]),
    ...hits('clap', [[0.506, 0.234], [1.497, 0.276], [3.512, 0.261], [4.497, 0.242], [5.511, 0.270]], { pan: 0.12 }),
    ...[0.263, 0.522, 0.751, 1.013, 1.266, 1.783, 2.259, 3.26, 3.517, 3.769, 4.25, 4.512, 4.758, 5.012, 5.27, 5.75].map((at, i) =>
      event('hat', at, [0.12, 0.066, 0.134, 0.084][i % 4], { length: i % 4 === 2 ? 0.096 : 0.058, pan: i % 2 ? 0.24 : -0.18 })),
    ...theme('pluckKeys', 62, [[0.073, 0.127, 0.38], [0.56, 0.13, 0.33], [1.07, 0.15, 0.41], [1.554, 0.134, 0.51]], { pan: -0.13 }),
    ...theme('pluckKeys', 62, [[3.07, 0.128, 0.40], [3.552, 0.134, 0.37], [4.078, 0.144, 0.42], [4.554, 0.128, 0.49]], { pan: 0.15 }),
    ...phrase('bass', [[0.025, 38, 0.25, 0.52], [0.79, 38, 0.215, 0.45], [1.51, 41, 0.22, 0.42], [1.99, 43, 0.22, 0.44], [3.03, 38, 0.25, 0.55], [3.74, 38, 0.22, 0.21], [4.04, 48, 0.207, 0.39], [4.76, 45, 0.225, 0.40], [5.27, 38, 0.235, 0.49]]),
    ...phrase('fm', [[cue('short', FULL_CUES.verticalComment), 81, 0.103, 0.188], [2.683, 77, 0.098, 0.14]], { pan: 0.18, bypass: true }),
    ...phrase('pluckKeys', [[5.16, 60, 0.091, 0.24], [5.48, 62, 0.124, 0.46], [5.76, 69, 0.070, 0.20]], { pan: -0.15 }),
    event('wood', cue('short', FULL_CUES.verticalLock), 0.139, { tone: 910, length: 0.139, pan: 0.12, bypass: true }),
  ],
};

const code = {
  color: 'piano and FM synth',
  gain: 2.07,
  room: room(1.06, 0.66, 1261),
  events: [
    ...phrase('string', [[0.02, 38, 0.217, 1.22], [1.02, 45, 0.13, 0.63], [1.53, 41, 0.166, 0.88], [2.52, 43, 0.166, 1.0], [3.49, 36, 0.194, 0.98], [4.47, 45, 0.152, 1.06], [5.42, 38, 0.211, 1.16]], { model: 'piano', pan: -0.24 }),
    ...theme('string', 62, [[0.099, 0.179, 0.64], [0.60, 0.176, 0.60], [1.13, 0.197, 0.61], [1.64, 0.179, 0.97]], { model: 'piano', pan: 0.16 }),
    ...phrase('fm', [[0.035, 50, 0.13, 1.21], [1.53, 53, 0.11, 1.19], [2.54, 55, 0.116, 1.17], [3.53, 60, 0.107, 1.20], [4.58, 57, 0.106, 0.97], [5.45, 50, 0.13, 0.99]], { model: 'code', pan: 0.06, hold: true }),
    ...phrase('fm', [[2.28, 74, 0.104, 0.27], [2.53, 77, 0.105, 0.28], [3.01, 81, 0.109, 0.40], [3.54, 79, 0.109, 0.61], [4.22, 74, 0.11, 0.38], [4.76, 77, 0.11, 0.42], [5.28, 72, 0.116, 0.38], [5.59, 74, 0.111, 0.72]], { model: 'code', pan: -0.23 }),
    ...hits('noiseNote', [[0.5, 0.10], [0.742, 0.09], [1.24, 0.10], [1.754, 0.08], [2.52, 0.087], [2.775, 0.11], [3.532, 0.08], [3.75, 0.103], [4.14, 0.076], [4.99, 0.103], [5.49, 0.103]], { length: 0.085, tone: 1970, pan: 0.23 }),
  ],
};

const outro = {
  color: 'all 20 chapter palettes, three shutters, then one bell',
  gain: 1.88,
  room: room(1.27, 0.86, 8719),
  fade: [11.86, 12],
  levels: [[0, 1], [6.94, 1], [8.30, 0.81], [9.43, 0.52], [10.54, 0.19], [11.23, 0]],
  events: [
    ...phrase('bow', [[0.006, 38, 0.216, 2.2], [1.53, 41, 0.149, 1.65], [3.08, 43, 0.16, 1.73], [4.56, 38, 0.186, 2.76], [6.94, 38, 0.17, 2.65], [8.79, 38, 0.121, 2.27]], { attack: 0.15, pan: -0.22 }),
    ...theme('string', 62, [[0.15, 0.12, 0.87], [0.67, 0.142, 0.81], [1.15, 0.15, 0.88], [1.66, 0.137, 1.14]], { model: 'harp', pan: 0.25 }),
    ...theme('qin', 50, [[1.78, 0.125, 0.81], [2.23, 0.14, 0.74], [2.76, 0.15, 0.78], [3.24, 0.143, 1.04]], { pan: -0.25 }),
    ...theme('flute', 74, [[3.19, 0.123, 0.52], [3.72, 0.13, 0.49], [4.19, 0.141, 0.59], [4.75, 0.14, 0.86]], { model: 'dizi', pan: 0.24 }),
    ...phrase('string', [[3.83, 57, 0.086, 0.85], [4.38, 60, 0.094, 0.84], [4.79, 62, 0.109, 1.32], [5.25, 65, 0.109, 0.81], [5.55, 67, 0.104, 0.81], [6.0, 69, 0.116, 0.94], [6.61, 65, 0.105, 0.88]], { model: 'sitar', pan: -0.14 }),
    ...hits('drum', [[1.51, 0.097, true], [2.52, 0.11, true], [3.51, 0.129, true], [4.52, 0.135, true], [5.52, 0.17, true], [6.52, 0.16, true], [7.52, 0.147, true], [8.52, 0.099, true]], { pan: -0.09 }),
    // Painting and film voices answer the harp and strings under their first statement.
    note('organ', 0.30, 45, 0.068, 0.98, { pan: -0.28 }),
    note('bow', 0.98, 77, 0.057, 0.84, { tense: true, slide: -103, pan: 0.28, attack: 0.11 }),
    note('string', 1.26, 69, 0.076, 0.47, { model: 'piano', pan: -0.13 }),
    ...phrase('string', [[1.98, 62, 0.091, 0.46], [2.38, 65, 0.078, 0.34], [2.60, 69, 0.074, 0.42]], { model: 'pipa', pan: 0.24, slide: -27 }),
    note('metal', 2.86, 55.22, 0.082, 0.55, { model: 'saron', pan: -0.31 }),
    // Wood, clay, bamboo and plucked strings interleave without doubling the lead.
    note('flute', 3.30, 62, 0.089, 0.40, { model: 'ceramic', pan: -0.27 }),
    event('wood', 3.53, 0.105, { tone: 295, length: 0.18, pan: -0.24 }),
    note('flute', 4.01, 57, 0.092, 0.81, { model: 'xiao', pan: -0.34 }),
    ...phrase('string', [[4.30, 67, 0.088, 0.46], [4.63, 69, 0.082, 0.34]], { model: 'shamisen', slide: -48, pan: 0.30 }),
    event('tabla', 5.34, 0.111, { low: true, pan: -0.18 }),
    event('tabla', 5.73, 0.098, { pan: 0.16 }),
    ...FULL_CUES.outroFlashes.flatMap((time, index) => {
      const at = time - OUTRO;
      const pan = [-0.16, 0.18, -0.06][index];
      return [
        event('noiseNote', at, 0.22, { tone: 3450, q: 0.60, length: 0.024, attack: 0.0015, sustain: 0.21, pan, dry: true }),
        event('noiseNote', at + 0.027, 0.13, { tone: 1930, q: 0.95, length: 0.052, attack: 0.0019, sustain: 0.13, pan, dry: true }),
      ];
    }),
    note('metal', FULL_CUES.outroFlashes[0] - OUTRO, 48, 0.223, 1.94, { model: 'gong', pan: -0.22 }),
    note('metal', FULL_CUES.outroFlashes[1] - OUTRO, 69, 0.172, 1.12, { model: 'bronze', pan: 0.25 }),
    note('metal', FULL_CUES.outroFlashes[2] - OUTRO, 62, 0.203, 2.36, { model: 'bonang', pan: -0.07 }),
    ...phrase('breathChoir', [[5.10, 50, 0.148, 0.72], [6.035, 53, 0.158, 0.84], [6.91, 57, 0.156, 0.87], [7.76, 55, 0.133, 1.24]], { vowel: 'u', harmony: true, pan: 0.16 }),
    ...phrase('bow', [[5.05, 53, 0.125, 1.12], [6.02, 57, 0.125, 1.12], [7.03, 65, 0.133, 1.51], [8.36, 62, 0.11, 2.01]], { attack: 0.16, pan: 0.16 }),
    // The electronic colors pass the same pitches from sine to pulse to FM.
    event('tube', 6.79, 0.050, { length: 0.84, pan: -0.18 }),
    event('sine', 7.10, 0.066, { tone: 440, to: 349.23, length: 0.29, pan: 0.29 }),
    note('chip', 7.35, 74, 0.075, 0.10, { channel: 'square1', pan: 0.17, dry: true }),
    note('chip', 7.42, 65, 0.052, 0.12, { channel: 'square2', pan: -0.23, dry: true }),
    note('chip', 7.45, 50, 0.080, 0.16, { channel: 'triangle', dry: true }),
    note('chip', 7.48, 0, 0.066, 0.056, { channel: 'noise', period: 11, dry: true }),
    event('wood', 7.66, 0.080, { tone: 1080, length: 0.065, pan: -0.19, dry: true }),
    note('fm', 7.705, 77, 0.084, 0.16, { model: 'screen', pan: -0.09 }),
    ...[53, 57, 60, 64].map((pitch, i) => note('fm', 7.88 + 0.009 * i, pitch, 0.036, 0.65, { model: 'road', hold: true, pan: i % 2 ? 0.23 : -0.24 })),
    note('fm', 7.92, 45, 0.080, 0.43, { model: 'fretless', slide: -55 }),
    event('kick', 8.22, 0.107, { low: true, dry: true }),
    event('clap', 8.46, 0.096, { pan: 0.19, dry: true }),
    note('string', 8.55, 62, 0.089, 0.60, { model: 'piano', pan: -0.22 }),
    note('fm', 8.70, 69, 0.077, 0.53, { model: 'code', pan: 0.25 }),
    note('qin', 9.70, 57, 0.14, 1.30, { harmonic: true, touch: 0.25, pan: 0.12 }),
    note('metal', FULL_CUES.outroBell - OUTRO, 74, 0.24, 0.49, { model: 'finalBell', bypass: true }),
  ],
};

const chapters = { sahara, egypt, han, tang, song, riverside, maya, mughal, bada, wayang, ukiyo, starry, scream, shadow, scope, pixel, chat, vapor, short, code };

export const fullArrangement = [
  { id: 'intro', start: 0, duration: INTRO, ...intro },
  ...SCENES.map(({ id, start }) => ({ id, start, duration: 6, ...chapters[id] })),
  { id: 'outro', start: OUTRO, duration: DURATION - OUTRO, ...outro },
];
