import { makeInstruments, roomImpulse } from './synthesis.js';

export const STUDY_SCENES = Object.freeze(['sahara', 'song', 'vertical']);
export const SCENE_SECONDS = 6;
export const STUDY_TAIL = 0.25;
export const STUDY_BPM = 120;
const STUDY_MASTER_GAIN = 1.38;

export const STUDY_CUES = Object.freeze({
  sahara: Object.freeze({ herdStops: 2.45, trackTaps: Object.freeze([2.93, 3.13]) }),
  song: Object.freeze({ revealsRider: 3.0 }),
  vertical: Object.freeze({ comment: 2.60, beatReturns: 3.0, progressClick: 5.97, progressLocks: 6.0 }),
});

// D–F–A–G: a small ascending question that falls a step instead of resolving.
const MOTIF = Object.freeze([0, 3, 7, 5]);
const event = (voice, at, amp, options = {}) => ({ voice, at, amp, ...options });
const note = (voice, at, pitch, amp, length, options = {}) => event(voice, at, amp, { note: pitch, length, ...options });

function motif(voice, root, placements, options = {}) {
  return placements.map(([at, length, amp], index) =>
    note(voice, at, root + MOTIF[index], amp, length, options));
}

const sahara = {
  room: { seconds: 0.56, damping: 0.17, wet: 0.32, seed: 4938 },
  volume: 1.64,
  levels: [[0, 1], [2.39, 1], [STUDY_CUES.sahara.herdStops, 0.18], [2.76, 0.18], [2.89, 1], [5.72, 1], [6.22, 0]],
  events: [
    event('atmosphere', 0, 0.014, { length: 3.75, tone: 530 }),
    event('drum', 0.002, 0.30, { low: true, pan: -0.15 }),
    event('drum', 0.727, 0.172, { shift: -4, pan: 0.23 }),
    event('drum', 1.009, 0.105, { pan: -0.25 }),
    event('drum', 1.487, 0.25, { low: true, shift: 4, pan: -0.11 }),
    event('drum', 1.872, 0.16, { shift: 10, pan: 0.28 }),
    event('drum', 2.111, 0.113, { shift: -9, pan: 0.02 }),
    ...motif('breathChoir', 50, [[0.11, 0.33, 0.34], [0.58, 0.41, 0.29], [1.071, 0.39, 0.40], [1.564, 0.47, 0.37]], { pan: -0.09 }),
    note('breathChoir', 0.025, 38, 0.15, 0.92, { vowel: 'u', harmony: true, pan: 0.22 }),
    note('breathChoir', 1.06, 45, 0.105, 0.47, { vowel: 'u', pan: 0.27 }),
    note('breathChoir', 1.59, 48, 0.145, 0.68, { vowel: 'u', pan: 0.19 }),
    event('wood', STUDY_CUES.sahara.trackTaps[0], 0.18, { tone: 345, pan: -0.26, close: true }),
    event('wood', STUDY_CUES.sahara.trackTaps[1], 0.151, { tone: 395, pan: 0.20, close: true }),
    event('drum', 3.51, 0.257, { low: true, pan: -0.11 }),
    event('drum', 4.244, 0.133, { shift: 5, pan: 0.28 }),
    event('drum', 4.75, 0.168, { low: true, shift: -3, pan: -0.18 }),
    event('drum', 5.001, 0.158, { shift: 12, pan: 0.26 }),
    event('drum', 5.49, 0.24, { low: true, pan: -0.06 }),
    ...motif('breathChoir', 50, [[3.52, 0.35, 0.24], [3.975, 0.28, 0.26], [4.248, 0.40, 0.33], [4.747, 0.57, 0.30]], { vowel: 'u', pan: 0.06 }),
    note('breathChoir', 4.38, 48, 0.061, 0.38, { harmony: true, pan: -0.26 }),
    note('breathChoir', 5.195, 45, 0.1, 0.29, { vowel: 'u', pan: 0.24 }),
    note('breathChoir', 5.52, 50, 0.235, 0.37, { harmony: true }),
  ],
};

const song = {
  room: { seconds: 1.24, damping: 0.095, wet: 0.67, seed: 653 },
  volume: 0.76,
  levels: [[0, 1], [5.83, 1], [6.38, 0]],
  events: [
    event('atmosphere', 0, 0.023, { length: 4.11, tone: 344, pan: -0.23 }),
    note('qin', 0.01, 38, 0.21, 1.23, { touch: 0.23, pan: -0.17 }),
    ...motif('qin', 62, [[0.11, 0.64, 0.18], [0.691, 0.48, 0.16], [1.267, 0.67, 0.22], [1.782, 1.12, 0.18]], { pan: 0.12, slide: -13 }),
    note('qin', 1.49, 43, 0.065, 0.87, { touch: 0.31, pan: -0.18 }),
    event('wood', 2.40, 0.037, { tone: 275, length: 0.16, pan: -0.12 }),
    note('qin', STUDY_CUES.song.revealsRider, 57, 0.32, 1.03, { touch: 0.25, harmonic: true, pan: 0.16 }),
    note('qin', 3.576, 55, 0.18, 0.91, { touch: 0.22, harmonic: true, pan: -0.07 }),
    note('qin', 4.106, 53, 0.184, 0.86, { touch: 0.20, harmonic: true, pan: 0.08 }),
    note('qin', 4.533, 48, 0.12, 0.83, { slide: -21, pan: -0.13 }),
    event('atmosphere', 4.37, 0.018, { length: 1.65, tone: 508, pan: 0.18 }),
    note('qin', 5.108, 50, 0.19, 1.13, { touch: 0.27, pan: -0.08 }),
    note('qin', 5.52, 62, 0.10, 0.69, { touch: 0.22, pan: 0.16 }),
  ],
};

const vertical = {
  room: { seconds: 0.30, damping: 0.37, wet: 0.24, seed: 21518 },
  volume: 1.11,
  levels: [[0, 1], [2.44, 1], [2.54, 0.19], [2.93, 0.19], [STUDY_CUES.vertical.beatReturns, 1], [6.11, 1], [6.25, 0]],
  events: [
    ...[0, 0.768, 1.25, 1.997, 3, 3.737, 4.017, 4.76, 5.258].map((at, index) =>
      event('kick', at, index === 0 || at === 3 ? 0.40 : 0.31, { low: index % 2 === 0 })),
    ...[0.504, 1.496, 3.512, 4.497, 5.512].map((at, index) =>
      event('clap', at, 0.22 + (index % 2) * 0.042, { pan: 0.10 })),
    ...[0.263, 0.522, 0.751, 1.013, 1.266, 1.783, 2.259, 3.26, 3.517, 3.769, 4.25, 4.512, 4.758, 5.012, 5.27, 5.75].map((at, index) =>
      event('hat', at, [0.10, 0.059, 0.122, 0.067][index % 4], { length: index % 4 === 2 ? 0.09 : 0.051, pan: index % 2 === 0 ? -0.18 : 0.24 })),
    ...motif('pluckKeys', 62, [[0.076, 0.385, 0.084], [0.56, 0.32, 0.087], [1.076, 0.385, 0.11], [1.558, 0.49, 0.103]], { pan: -0.11 }),
    ...motif('pluckKeys', 62, [[3.071, 0.40, 0.098], [3.554, 0.36, 0.087], [4.077, 0.42, 0.12], [4.547, 0.29, 0.10]], { pan: 0.10 }),
    ...[[0.035, 38, 0.55], [0.797, 38, 0.46], [1.522, 41, 0.36], [1.982, 43, 0.44], [3.033, 38, 0.49], [3.74, 38, 0.24],
      [4.04, 48, 0.43], [4.771, 45, 0.40], [5.29, 38, 0.47]].map(([at, pitch, length]) => note('bass', at, pitch, 0.176, length)),
    note('pluckKeys', 0.582, 57, 0.05, 0.32, { pan: 0.22 }),
    note('pluckKeys', 1.558, 60, 0.046, 0.37, { pan: 0.24 }),
    note('pluckKeys', STUDY_CUES.vertical.comment, 81, 0.033, 0.174, { pan: 0.16, cue: true }),
    note('pluckKeys', STUDY_CUES.vertical.comment + 0.075, 77, 0.033, 0.153, { pan: 0.05, cue: true }),
    note('pluckKeys', 5.154, 60, 0.074, 0.24, { pan: -0.17 }),
    note('pluckKeys', 5.471, 62, 0.122, 0.43, { pan: 0.08 }),
    note('pluckKeys', 5.76, 69, 0.054, 0.23, { pan: -0.16 }),
    event('wood', STUDY_CUES.vertical.progressClick, 0.138, { tone: 920, length: 0.153, pan: 0.11, cue: true }),
  ],
};

const scores = { sahara, song, vertical };

export function createStudyPlan({ scenes = STUDY_SCENES, tail = STUDY_TAIL } = {}) {
  if (!Array.isArray(scenes) || scenes.length < 1 || scenes.some((id) => !STUDY_SCENES.includes(id))) {
    throw new Error(`Select study scenes from ${STUDY_SCENES.join(', ')}.`);
  }
  if (!Number.isFinite(tail) || tail < 0 || tail > 1) throw new Error('Use a tail from 0 to 1 second.');
  return {
    bpm: STUDY_BPM,
    duration: scenes.length * SCENE_SECONDS + tail,
    segments: scenes.map((id, index) => ({ id, start: index * SCENE_SECONDS, duration: SCENE_SECONDS, cues: STUDY_CUES[id] })),
  };
}

export function scheduleStudy(ctx, { destination = ctx.destination, start = ctx.currentTime, ...options } = {}) {
  if (!Number.isFinite(start) || start < 0) throw new Error('Study start must be a nonnegative time.');
  const plan = createStudyPlan(options);
  const instruments = makeInstruments(ctx);
  const finish = start + plan.duration;
  const master = ctx.createGain();
  const trim = ctx.createBiquadFilter();
  trim.type = 'highpass';
  trim.frequency.value = 31;
  trim.Q.value = 0.4;
  trim.connect(master);
  master.connect(destination);
  master.gain.setValueAtTime(STUDY_MASTER_GAIN, start);
  const finalFade = options.tail === 0 ? 0.008 : 0.036;
  master.gain.setValueAtTime(STUDY_MASTER_GAIN, finish - finalFade);
  master.gain.linearRampToValueAtTime(0, finish);

  for (const segment of plan.segments) {
    const { room, levels, volume, events } = scores[segment.id];
    const at = start + segment.start;
    const mix = ctx.createGain();
    const input = ctx.createGain();
    const reverb = ctx.createConvolver();
    const wet = ctx.createGain();
    mix.connect(trim);
    input.connect(mix);
    input.connect(reverb);
    reverb.normalize = false;
    reverb.buffer = roomImpulse(ctx, room);
    reverb.connect(wet);
    wet.gain.value = room.wet;
    wet.connect(mix);
    mix.gain.setValueAtTime(levels[0][1] * volume, at);
    for (const [time, factor] of levels.slice(1)) mix.gain.linearRampToValueAtTime(factor * volume, at + time);

    for (const sound of events) {
      const position = ctx.createStereoPanner();
      position.pan.value = sound.pan ?? 0;
      position.connect(sound.cue ? trim : sound.close ? mix : input);
      instruments[sound.voice](position, at + sound.at, sound);
    }
  }
  return plan;
}

export async function renderStudyAudio({ sampleRate = 48000, ...options } = {}) {
  const { duration } = createStudyPlan(options);
  const context = new OfflineAudioContext(2, Math.round(duration * sampleRate), sampleRate);
  const plan = scheduleStudy(context, { ...options, start: 0 });
  return { plan, buffer: await context.startRendering() };
}

export function encodeStudyWav(buffer) {
  const channels = buffer.numberOfChannels;
  const block = channels * 3;
  const payload = buffer.length * block;
  const bytes = new Uint8Array(44 + payload);
  const view = new DataView(bytes.buffer);
  bytes.set([82, 73, 70, 70], 0);
  view.setUint32(4, payload + 36, true);
  bytes.set([87, 65, 86, 69, 102, 109, 116, 32], 8);
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, channels, true);
  view.setUint32(24, buffer.sampleRate, true);
  view.setUint32(28, buffer.sampleRate * block, true);
  view.setUint16(32, block, true);
  view.setUint16(34, 24, true);
  bytes.set([100, 97, 116, 97], 36);
  view.setUint32(40, payload, true);

  const audio = Array.from({ length: channels }, (_, index) => buffer.getChannelData(index));
  let offset = 44;
  for (let sample = 0; sample < buffer.length; sample += 1) {
    for (const data of audio) {
      const value = Math.round(Math.max(-1, Math.min(0.999999881, data[sample])) * 8388608);
      bytes[offset++] = value & 255;
      bytes[offset++] = (value >> 8) & 255;
      bytes[offset++] = (value >> 16) & 255;
    }
  }
  return bytes;
}
