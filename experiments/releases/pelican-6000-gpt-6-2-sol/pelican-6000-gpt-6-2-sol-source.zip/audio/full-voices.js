import { makeInstruments } from './synthesis.js';

const FLOOR = 0.000002;
export const hz = (note) => 440 * 2 ** ((note - 69) / 12);

export function noiseGenerator(seed) {
  let state = seed >>> 0;
  return () => {
    state = (Math.imul(state, 1664525) + 1013904223) >>> 0;
    return state / 2147483648 - 1;
  };
}

export function stageGain(ctx, output, amount = 1) {
  const stage = ctx.createGain();
  stage.gain.value = amount;
  stage.connect(output);
  return stage;
}

export function stageFilter(ctx, output, type, frequency, q = 0.6) {
  const stage = ctx.createBiquadFilter();
  stage.type = type;
  stage.frequency.value = frequency;
  stage.Q.value = q;
  stage.connect(output);
  return stage;
}

function oscillator(ctx, output, type, frequency, time, duration) {
  const tone = ctx.createOscillator();
  tone.type = type;
  tone.frequency.value = frequency;
  tone.connect(output);
  tone.start(time);
  tone.stop(time + duration);
  return tone;
}

function contour(param, at, duration, attack, amp, sustain, decay = 0.4) {
  const rise = Math.min(duration * 0.22, attack);
  const settle = Math.max(rise + 0.0001, duration * decay);
  param.setValueAtTime(FLOOR, at);
  param.linearRampToValueAtTime(amp, at + rise);
  param.exponentialRampToValueAtTime(Math.max(FLOOR, amp * sustain), at + settle);
  param.exponentialRampToValueAtTime(FLOOR, at + duration);
}

const stringModels = {
  harp: { ratios: [1, 2.0002, 3.0011, 4.003, 5.007, 6.012], weights: [1, 0.57, 0.37, 0.18, 0.072, 0.036], decay: 0.78, click: 0.12, body: 320 },
  pipa: { ratios: [1, 2.0006, 3.0024, 4.006, 5.013, 6.024, 7.038, 8.062], weights: [0.84, 0.76, 0.49, 0.43, 0.32, 0.18, 0.15, 0.10], decay: 0.56, click: 0.62, body: 740 },
  sitar: { ratios: [1, 2.002, 3.010, 4.018, 5.041, 6.05, 7.06, 8.08], weights: [0.79, 0.86, 0.57, 0.49, 0.34, 0.24, 0.19, 0.13], decay: 0.72, click: 0.40, body: 1350 },
  shamisen: { ratios: [1, 1.998, 3.008, 4.05, 5.10, 6.1, 7.15], weights: [0.78, 0.57, 0.50, 0.41, 0.25, 0.21, 0.11], decay: 0.49, click: 0.92, body: 1650 },
  piano: { ratios: [1, 2.0004, 3.0022, 4.007, 5.018, 6.041, 7.064, 8.081], weights: [1, 0.58, 0.40, 0.27, 0.17, 0.12, 0.069, 0.053], decay: 0.69, click: 0.30, body: 490 },
};

const metalModels = {
  bronze: { ratios: [1, 2, 2.76, 3.94, 5.39, 7.2], weights: [0.76, 0.29, 0.54, 0.22, 0.14, 0.067], lowpass: 7200 },
  gong: { ratios: [1, 1.45, 2.10, 2.64, 3.68, 5.12, 8.24], weights: [0.96, 0.36, 0.44, 0.27, 0.22, 0.12, 0.085], lowpass: 4700 },
  saron: { ratios: [1, 2.78, 5.36, 8.21], weights: [1, 0.60, 0.35, 0.18], lowpass: 6600 },
  bonang: { ratios: [1, 1.94, 3.28, 4.02, 6.62], weights: [0.83, 0.39, 0.44, 0.28, 0.18], lowpass: 6200 },
  finalBell: { ratios: [0.50, 1, 1.193, 1.494, 2, 2.516], weights: [0.22, 1, 0.34, 0.37, 0.2, 0.09], lowpass: 4700 },
};

const fluteModels = {
  dizi: { weights: [0.78, 0.45, 0.19, 0.13, 0.092, 0.057], air: 0.31, airHz: 3400, bend: -69, attack: 0.037, drive: 4.8 },
  ceramic: { weights: [1, 0.091, 0.035, 0.022], air: 0.37, airHz: 2650, bend: -94, attack: 0.058, drive: 5.2 },
  xiao: { weights: [1, 0.17, 0.093, 0.039, 0.012], air: 0.42, airHz: 1430, bend: -42, attack: 0.105, drive: 3.9 },
};

export function makeFullVoices(ctx) {
  const study = makeInstruments(ctx);
  const rand = noiseGenerator(0xa8bd977);
  const noiseBuffer = ctx.createBuffer(1, 2 * ctx.sampleRate, ctx.sampleRate);
  const noiseData = noiseBuffer.getChannelData(0);
  for (let i = 0; i < noiseData.length; i += 1) noiseData[i] = rand();
  const bowedWave = ctx.createPeriodicWave(new Float32Array(16), Float32Array.from({ length: 16 }, (_, n) =>
    n ? (n % 2 ? 1 : -0.82) / n ** 1.16 : 0));

  function noise(output, at, length, offset = 0, loop = false) {
    const source = ctx.createBufferSource();
    source.buffer = noiseBuffer;
    source.loop = loop;
    source.connect(output);
    source.start(at, offset % 1);
    source.stop(at + length);
  }

  function noiseNote(output, at, event) {
    const { amp, length = 0.13, tone = 910, attack = 0.003, sustain = 0.16, q = 1.2 } = event;
    const env = stageGain(ctx, output, 0);
    contour(env.gain, at, length, attack, amp, sustain);
    const filtered = stageFilter(ctx, env, 'bandpass', tone, q);
    noise(filtered, at, length, at * 0.15, length > 0.9);
  }

  function string(output, at, event) {
    const { model = 'harp', note, amp, length = 0.8, slide = 0, cents = 0 } = event;
    const { ratios, weights, decay, click, body } = stringModels[model];
    const root = hz(note);
    const board = stageFilter(ctx, output, 'peaking', body, 1.15);
    board.gain.value = model === 'harp' ? 1.9 : 3.1;
    for (const [index, ratio] of ratios.entries()) {
      if (root * ratio > ctx.sampleRate * 0.46) break;
      const modeLength = length * (0.34 + decay / (1 + index * 0.37));
      const env = stageGain(ctx, board, 0);
      contour(env.gain, at, modeLength, 0.0028, amp * weights[index], 0.23, 0.29);
      const tone = oscillator(ctx, env, 'sine', root * ratio, at, modeLength + 0.005);
      tone.detune.setValueAtTime(cents + slide, at);
      tone.detune.linearRampToValueAtTime(cents + (model === 'sitar' ? 11 : 2), at + Math.min(0.084, modeLength * 0.33));
      tone.detune.linearRampToValueAtTime(cents, at + modeLength);
      if ((model === 'sitar' || model === 'shamisen') && index < 4) {
        const jawari = stageGain(ctx, tone.frequency, 0);
        const strength = model === 'sitar' ? 0.22 : 0.10;
        jawari.gain.setValueAtTime(root * strength, at);
        jawari.gain.exponentialRampToValueAtTime(root * strength * 0.1, at + modeLength * 0.76);
        oscillator(ctx, jawari, 'sine', root * 1.006, at, modeLength + 0.005);
      }
    }
    if (model === 'sitar') {
      for (const [index, sympathetic] of [50, 57, 62, 69, 74].entries()) {
        const offset = 0.012 + 0.009 * index;
        const env = stageGain(ctx, board, 0);
        const ring = length * (1.10 - index * 0.061);
        const strength = sympathetic % 12 === note % 12 ? 0.18 : 0.051;
        contour(env.gain, at + offset, ring, 0.048, amp * strength, 0.40);
        oscillator(ctx, env, 'sine', hz(sympathetic) * 1.0018, at + offset, ring);
      }
    }
    noiseNote(output, at, { amp: amp * click, length: model === 'shamisen' ? 0.065 : 0.037, tone: body * 2.2, q: 1.3 });
  }

  function metal(output, at, event) {
    const { note, amp, length = 1, model = 'bronze', cents = 0 } = event;
    const { ratios, weights, lowpass } = metalModels[model];
    const root = hz(note) * 2 ** (cents / 1200);
    const resonator = stageFilter(ctx, output, 'lowpass', lowpass);
    for (const [index, ratio] of ratios.entries()) {
      if (root * ratio > ctx.sampleRate * 0.47) continue;
      const modeLength = length * (0.45 + 0.55 / (1 + index * 0.31));
      const env = stageGain(ctx, resonator, 0);
      const swell = model === 'gong' ? 0.07 / (1 + index * 0.34) : 0.004;
      contour(env.gain, at, modeLength, swell, amp * weights[index], 0.53, 0.27);
      const tone = oscillator(ctx, env, 'sine', root * ratio, at, modeLength + 0.004);
      if (model === 'gong') {
        tone.detune.setValueAtTime(index * 7, at);
        tone.detune.linearRampToValueAtTime(-index * 2, at + modeLength * 0.75);
      }
    }
    noiseNote(resonator, at, { amp: amp * 0.27, length: 0.052, tone: Math.min(4350, root * 5.1), q: 1.1 });
  }

  function flute(output, at, event) {
    const { note, amp, length, model = 'xiao', bend, fall = -27, cents = 0 } = event;
    const { weights, air, airHz, bend: intake, attack, drive } = fluteModels[model];
    const root = hz(note);
    const env = stageGain(ctx, output, 0);
    const end = length + 0.105;
    contour(env.gain, at, end, attack, amp, 0.73, 0.72);
    const wind = stageGain(ctx, env, air);
    const airBand = stageFilter(ctx, wind, 'bandpass', airHz, 1.05);
    noise(airBand, at, end, (at * 0.4) % 1, end > 1.05);
    const ratioShiver = ctx.createOscillator();
    ratioShiver.frequency.value = drive + (note % 5) * 0.14;
    for (const [index, weight] of weights.entries()) {
      const partial = oscillator(ctx, stageGain(ctx, env, weight), 'sine', root * (index + 1), at, end + 0.003);
      partial.detune.setValueAtTime(cents + (bend ?? intake), at);
      partial.detune.linearRampToValueAtTime(cents + 3, at + Math.min(attack * 1.2, length * 0.28));
      partial.detune.linearRampToValueAtTime(cents + fall, at + end - 0.006);
      const depth = stageGain(ctx, partial.detune, 0.05);
      depth.gain.linearRampToValueAtTime(model === 'dizi' ? 11 : 6, at + length * 0.58);
      ratioShiver.connect(depth);
    }
    ratioShiver.start(at);
    ratioShiver.stop(at + end + 0.003);
    if (model === 'dizi') {
      oscillator(ctx, stageGain(ctx, env, 0.054), 'triangle', root * 4.019, at, end);
    }
  }

  function bow(output, at, event) {
    const { note, amp, length, attack = 0.36, cents = 0, tense = false, slide = 0 } = event;
    const route = stageFilter(ctx, output, 'lowpass', tense ? 4600 : (note < 48 ? 1100 : 2300));
    const delays = tense ? [-16, 5, 24] : [-7, 0, 8];
    for (const [index, detune] of delays.entries()) {
      const time = at + index * 0.014;
      const env = stageGain(ctx, route, 0);
      contour(env.gain, time, length, attack + index * 0.065, amp * [0.32, 0.42, 0.27][index], 0.86, 0.69);
      const wave = oscillator(ctx, env, 'sine', hz(note), time, length + 0.005);
      wave.setPeriodicWave(bowedWave);
      wave.detune.setValueAtTime(detune + cents - 13, time);
      wave.detune.linearRampToValueAtTime(detune + cents, time + length * 0.26);
      wave.detune.linearRampToValueAtTime(detune + cents + slide, time + length * 0.88);
      const tremble = stageGain(ctx, wave.detune, 0.02);
      tremble.gain.linearRampToValueAtTime(tense ? 17 : 5.2, time + length * 0.36);
      oscillator(ctx, tremble, 'sine', 4.6 + index * 0.85, time, length + 0.005);
    }
    noiseNote(route, at + 0.013, { amp: amp * 0.075, length: length * 0.95, tone: note < 48 ? 725 : 1735, attack, sustain: 0.55 });
  }

  function organ(output, at, event) {
    const { note, amp, length, reed = false } = event;
    const coupler = reed ? [0.70, 0.43, 0.32, 0.12, 0.18, 0.068] : [0.92, 0.25, 0.14, 0.08];
    const env = stageGain(ctx, stageFilter(ctx, output, 'lowpass', reed ? 3800 : 1740), 0);
    const end = length + 0.19;
    contour(env.gain, at, end, reed ? 0.045 : 0.137, amp, 0.85, 0.79);
    const pitch = hz(note);
    for (const [i, stop] of coupler.entries()) {
      const voice = oscillator(ctx, stageGain(ctx, env, stop), 'sine', pitch * (i + 1), at, end);
      voice.detune.value = (i - 2) * 1.87;
    }
    noiseNote(env, at, { amp: 0.07, length: 0.16, tone: 830, attack: 0.03 });
  }

  function tabla(output, at, event) {
    const { amp, low = false, length = low ? 0.39 : 0.22, slide = 0 } = event;
    const root = low ? 83 : 237;
    const parts = low ? [[1, 1], [1.82, 0.33], [2.66, 0.21], [4.16, 0.09]]
      : [[1, 0.77], [1.99, 0.54], [3.04, 0.26], [4.19, 0.16], [5.04, 0.047]];
    for (const [index, [ratio, weight]] of parts.entries()) {
      const duration = length / (1 + index * 0.33);
      const env = stageGain(ctx, output, 0);
      contour(env.gain, at, duration, 0.002, amp * weight, 0.19, 0.28);
      const source = oscillator(ctx, env, 'sine', root * ratio, at, duration + 0.003);
      source.detune.setValueAtTime(low ? 192 + slide : 26 + slide, at);
      source.detune.exponentialRampToValueAtTime(1, at + duration * 0.75);
    }
    noiseNote(output, at, { amp: amp * (low ? 0.33 : 0.73), length: 0.042, tone: low ? 610 : 1870, q: 1.75 });
  }

  function fm(output, at, event) {
    const { note, amp, length, model = 'screen', slide = 0, hold = false } = event;
    const pitch = hz(note);
    const models = {
      road: [1, 0.42, 0.095, 0.006, 0.30],
      sax: [1, 2.45, 0.75, 0.032, 0.76],
      fretless: [2.005, 0.46, 0.19, 0.016, 0.61],
      screen: [2, 0.69, 0.049, 0.006, 0.34],
      code: [2.003, 0.94, 0.085, 0.018, 0.52],
    };
    const [ratio, bright, mellow, attack, sustain] = models[model];
    const full = length + (hold ? 0.14 : 0.03);
    const envelope = stageGain(ctx, output, 0);
    contour(envelope.gain, at, full, attack, amp, sustain, model === 'sax' ? 0.77 : 0.44);
    const carrier = oscillator(ctx, envelope, 'sine', pitch, at, full + 0.004);
    carrier.detune.setValueAtTime(slide, at);
    carrier.detune.linearRampToValueAtTime(0, at + Math.min(0.15, full * 0.65));
    const modDepth = stageGain(ctx, carrier.frequency, 0);
    modDepth.gain.setValueAtTime(pitch * bright, at);
    modDepth.gain.exponentialRampToValueAtTime(pitch * mellow, at + full * (model === 'sax' ? 0.9 : 0.61));
    oscillator(ctx, modDepth, 'sine', pitch * ratio, at, full + 0.004);
    if (model === 'sax') {
      const vibrato = stageGain(ctx, carrier.detune, 0);
      vibrato.gain.linearRampToValueAtTime(14, at + full * 0.60);
      oscillator(ctx, vibrato, 'sine', 5.2, at, full + 0.005);
      noiseNote(envelope, at, { amp: 0.18, length, tone: 1420, attack: 0.025, sustain: 0.27 });
    }
    if (model === 'road') {
      const tine = stageGain(ctx, envelope, 0);
      contour(tine.gain, at, full * 0.32, 0.003, 0.25, 0.16);
      oscillator(ctx, tine, 'sine', pitch * 7.01, at, full * 0.33);
    }
  }

  function sine(output, at, event) {
    const { note, amp, length, tone = hz(note), type = 'sine', to = tone, attack = 0.022, sustain = 0.72 } = event;
    const env = stageGain(ctx, output, 0);
    contour(env.gain, at, length, attack, amp, sustain, 0.72);
    const voice = oscillator(ctx, env, type, tone, at, length);
    voice.frequency.setValueAtTime(tone, at);
    voice.frequency.exponentialRampToValueAtTime(to, at + length * 0.86);
  }

  function tube(output, at, event) {
    const { amp, length } = event;
    sine(output, at, { tone: 60, amp, length, attack: 0.10, sustain: 0.83 });
    sine(output, at + 0.01, { tone: 120.1, amp: amp * 0.36, length: length - 0.02, attack: 0.07, sustain: 0.68 });
    noiseNote(output, at, { amp: amp * 0.48, length, tone: 350, attack: 0.09, sustain: 0.41 });
  }

  function chip(output, at, event) {
    const { note, amp, length, channel, bend = 0, period = 7, wide = false } = event;
    const env = stageGain(ctx, output, 0);
    const rise = Math.min(length * 0.19, 0.0028);
    const end = at + length;
    env.gain.setValueAtTime(0, at);
    env.gain.linearRampToValueAtTime(amp, at + rise);
    env.gain.linearRampToValueAtTime(amp * (channel === 'noise' ? 0.05 : 0.75), end - Math.min(0.008, length * 0.21));
    env.gain.linearRampToValueAtTime(0, end);
    if (channel === 'noise') {
      const step = Math.max(1, Math.round(period * ctx.sampleRate / 48000));
      const buffer = ctx.createBuffer(1, Math.ceil(length * ctx.sampleRate), ctx.sampleRate);
      const samples = buffer.getChannelData(0);
      let shift = 0x4c59;
      for (let i = 0; i < samples.length; i += 1) {
        if (i % step === 0) shift = (shift >> 1) | (((shift ^ (shift >> 1)) & 1) << 14);
        samples[i] = (shift & 1) * 2 - 1;
      }
      const source = ctx.createBufferSource();
      source.buffer = buffer;
      source.connect(stageFilter(ctx, env, 'highpass', period > 12 ? 430 : 1900, 0.6));
      source.start(at);
      return;
    }
    const tone = oscillator(ctx, env, channel === 'triangle' ? 'triangle' : 'square', hz(note), at, length);
    if (channel === 'square2' || wide) {
      const pulse = Float32Array.from({ length: 25 }, (_, n) => n ? Math.sin(n * Math.PI * 0.25) / n : 0);
      tone.setPeriodicWave(ctx.createPeriodicWave(new Float32Array(pulse.length), pulse));
    }
    tone.detune.setValueAtTime(0, at);
    tone.detune.linearRampToValueAtTime(bend, end - 0.001);
  }

  return { ...study, string, metal, flute, bow, organ, tabla, fm, sine, tube, chip, noiseNote };
}
