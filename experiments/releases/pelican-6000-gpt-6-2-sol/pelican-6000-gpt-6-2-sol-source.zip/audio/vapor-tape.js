import { makeFullVoices, noiseGenerator, stageFilter, stageGain } from './full-voices.js';

export const VAPOR_RATE = 0.793700526;
export const VAPOR_SOURCE_BPM = 120 / VAPOR_RATE;
export const VAPOR_SEMITONES = 4;
export const VAPOR_WOW_HZ = 0.5;
export const VAPOR_SPLICES = Object.freeze([2.5, 2.75, 3, 3.25]);
const SPEED_SPLICE = 0.007;

async function renderDemoTape(sampleRate) {
  const context = new OfflineAudioContext(2, Math.ceil(sampleRate * (6.34 * VAPOR_RATE)), sampleRate);
  const { fm, kick, clap, hat, noiseNote } = makeFullVoices(context);

  function place(voice, at, amp, pan, options = {}) {
    const position = context.createStereoPanner();
    position.pan.value = pan;
    position.connect(context.destination);
    voice(position, at * VAPOR_RATE, {
      amp,
      ...options,
      ...(options.note === undefined ? {} : { note: options.note + VAPOR_SEMITONES }),
      ...(options.length === undefined ? {} : { length: options.length * VAPOR_RATE }),
    });
  }

  // Fmaj7, Dm9, Bbmaj7, and a Dm9 inversion. Attacks are played ahead of or behind the grid.
  for (const [at, group, amp] of [
    [0.015, [53, 57, 60, 64, 69], 0.064],
    [1.253, [53, 57, 60, 64], 0.047],
    [2.0, [53, 57, 60, 64, 69], 0.060],
    [2.5, [53, 57, 60, 64, 76], 0.068],
    [3.5, [58, 62, 65, 69, 77], 0.058],
    [4.02, [50, 53, 57, 69], 0.060],
    [4.744, [53, 57, 62, 64, 69], 0.048],
    [5.18, [50, 53, 57, 60, 64, 69], 0.055],
  ]) {
    group.forEach((note, i) => place(fm, at + i * 0.0045, amp * (i === 0 ? 1.17 : 1), i % 2 ? 0.28 : -0.27,
      { note, length: 0.73 + (i % 2) * 0.14, model: 'road', hold: true }));
  }
  for (const [at, note, length] of [[0.02, 41, .43], [.53, 48, .43], [1.01, 45, .68], [1.742, 43, .22], [2.0, 38, .53],
    [2.5, 45, .25], [3.5, 41, .39], [4.025, 46, .68], [4.74, 48, .39], [5.23, 38, .74]]) {
    place(fm, at, 0.208, -0.08, { note, length, model: 'fretless', slide: -97, hold: true });
  }
  for (const [at, note, length] of [[0.25, 62, .43], [0.766, 65, .38], [1.219, 69, .57], [1.89, 67, .55], [2.50, 74, .39],
    [3.52, 77, .37], [4.00, 76, .52], [4.545, 72, .38], [5.05, 69, .54], [5.62, 65, .40]]) {
    place(fm, at, 0.153, 0.20, { note, length, model: 'sax', slide: -60 });
  }
  for (const at of [0.012, 0.758, 1.0, 2.005, 2.503, 3.504, 4.001, 4.749, 5.021, 5.75]) {
    place(kick, at, 0.235, 0, { low: at % 1 < 0.1 });
  }
  for (const at of [.502, 1.505, 2.506, 3.5, 4.502, 5.501]) {
    const gate = stageGain(context, context.destination, 0);
    const start = at * VAPOR_RATE;
    gate.gain.setValueAtTime(1, start);
    gate.gain.setValueAtTime(1, start + 0.060);
    gate.gain.linearRampToValueAtTime(0, start + 0.067);
    const pan = context.createStereoPanner();
    pan.pan.value = 0.16;
    pan.connect(gate);
    clap(pan, start, { amp: 0.198 });
    place(noiseNote, at, 0.10, -0.13, { length: 0.077, tone: 910, q: 0.83 });
  }
  for (let i = 0; i < 24; i += 1) {
    place(hat, i * .25 + .012 * (i % 2), [0.064, 0.098, 0.049][i % 3], i % 2 ? 0.22 : -0.17, { length: 0.051 });
  }
  return context.startRendering();
}

function speedCurve(time) {
  const settling = Math.max(0, 1 - time / 0.46);
  const pullOut = Math.max(0, (time - 5.43) / 0.57);
  return VAPOR_RATE * (1 + 0.16 * settling ** 2 + 0.18 * pullOut ** 2 + 0.0085 * Math.sin(2 * Math.PI * VAPOR_WOW_HZ * time));
}

function varispeed(ctx, source) {
  const samples = ctx.sampleRate * 6;
  const positions = new Float64Array(samples + 1);
  for (let i = 1; i <= samples; i += 1) positions[i] = positions[i - 1] + speedCurve(i / ctx.sampleRate);
  const buffer = ctx.createBuffer(2, samples, ctx.sampleRate);
  for (let channel = 0; channel < 2; channel += 1) {
    const rendered = source.getChannelData(channel);
    const treated = buffer.getChannelData(channel);
    const seek = (index, offset) => {
      const position = positions[index] + offset;
      const whole = Math.floor(position);
      const fraction = position - whole;
      return rendered[whole] * (1 - fraction) + rendered[whole + 1] * fraction;
    };
    let splice = 0;
    let offset = 0;
    let lastOffset = 0;
    let crossfadeStart = -ctx.sampleRate;
    const resumeTime = VAPOR_SPLICES.at(-1) + 0.25;
    const boundaries = [...VAPOR_SPLICES, resumeTime].map((time) => Math.round(time * ctx.sampleRate));
    const halfBeat = boundaries[0];
    for (let i = 0; i < samples; i += 1) {
      if (i === boundaries[splice]) {
        lastOffset = offset;
        offset = splice < VAPOR_SPLICES.length ? positions[halfBeat] - positions[i] : 0;
        crossfadeStart = i;
        splice += 1;
      }
      const x = Math.min(1, (i - crossfadeStart) / (SPEED_SPLICE * ctx.sampleRate));
      treated[i] = seek(i, offset) * x + seek(i, lastOffset) * (1 - x);
    }
  }
  return buffer;
}

export async function loadVaporTape(ctx, output) {
  const source = await renderDemoTape(ctx.sampleRate);
  const tape = ctx.createBufferSource();
  tape.buffer = varispeed(ctx, source);
  const deck = stageFilter(ctx, output, 'lowpass', 4050, 0.52);
  tape.connect(deck);
  tape.start(0);

  const noise = noiseGenerator(0x95d71);
  const buffer = ctx.createBuffer(1, ctx.sampleRate * 6, ctx.sampleRate);
  const samples = buffer.getChannelData(0);
  let dc = 0;
  for (let i = 0; i < samples.length; i += 1) {
    const white = noise();
    dc = 0.96 * dc + 0.04 * white;
    const modulation = 0.81 + 0.13 * Math.sin(i / ctx.sampleRate * Math.PI * 1.04);
    samples[i] = (white - dc) * modulation;
  }
  const hiss = ctx.createBufferSource();
  hiss.buffer = buffer;
  const leadIn = stageGain(ctx, deck, 0);
  leadIn.gain.linearRampToValueAtTime(0.017, 0.10);
  leadIn.gain.setValueAtTime(0.017, 5.89);
  leadIn.gain.linearRampToValueAtTime(0, 6);
  hiss.connect(stageFilter(ctx, leadIn, 'highpass', 890));
  hiss.start();
}
