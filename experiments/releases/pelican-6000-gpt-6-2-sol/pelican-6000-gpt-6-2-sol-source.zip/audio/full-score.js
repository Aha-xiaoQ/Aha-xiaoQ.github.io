import { DURATION, BPM } from '../src/beat/index.js';
import { roomImpulse } from './synthesis.js';
import { CHIP_CHANNELS, FULL_CUES, fullArrangement, pixelEvents } from './full-arrangement.js';
import { makeFullVoices, stageFilter, stageGain } from './full-voices.js';
import { loadVaporTape, VAPOR_RATE, VAPOR_SEMITONES, VAPOR_SOURCE_BPM, VAPOR_SPLICES, VAPOR_WOW_HZ } from './vapor-tape.js';

export { FULL_CUES };
export const FULL_SCORE_SECONDS = DURATION;
export const FULL_SCORE_MASTER_PEAK_DB = -4.75;

export function fullScorePlan() {
  const pixel = pixelEvents();
  return {
    duration: DURATION,
    bpm: BPM,
    segments: fullArrangement.map(({ id, start, duration, color }) => ({ id, start, duration, color })),
    cues: FULL_CUES,
    pixel: CHIP_CHANNELS.map((id) => ({
      id,
      events: pixel.filter(({ channel }) => channel === id).map(({ at, length, note }) => ({ at, end: at + length, note })),
    })),
    vapor: {
      sourceBpm: VAPOR_SOURCE_BPM,
      sourceSemitones: VAPOR_SEMITONES,
      baseRate: VAPOR_RATE,
      wowHz: VAPOR_WOW_HZ,
      repeatStarts: VAPOR_SPLICES,
      lowPassHz: 4050,
      roomSeconds: 4.25,
    },
  };
}

async function renderChapter(segment, sampleRate) {
  const { duration, start, gain = 1, room, levels = [[0, 1]], fade = [duration - 0.02, duration + 0.38], events } = segment;
  const finish = Math.min(DURATION - start, fade[1]);
  const context = new OfflineAudioContext(2, Math.round(finish * sampleRate), sampleRate);
  const voices = makeFullVoices(context);
  const trim = stageFilter(context, context.destination, 'highpass', segment.id === 'scope' ? 29 : 32, 0.45);
  const tail = stageGain(context, trim, gain);
  tail.gain.setValueAtTime(gain, Math.min(fade[0], finish));
  tail.gain.linearRampToValueAtTime(0, finish);

  const sceneMix = stageGain(context, tail, levels[0][1]);
  for (const [time, amount] of levels.slice(1)) sceneMix.gain.linearRampToValueAtTime(amount, time);
  const ensemble = stageGain(context, sceneMix);
  if (room) {
    const verb = context.createConvolver();
    verb.normalize = false;
    verb.buffer = roomImpulse(context, room);
    ensemble.connect(verb);
    verb.connect(stageGain(context, sceneMix, room.wet));
  }
  for (const sound of events) {
    const position = context.createStereoPanner();
    position.pan.value = sound.pan ?? 0;
    position.connect(sound.bypass ? tail : sound.dry ? sceneMix : ensemble);
    voices[sound.voice](position, sound.at, sound);
  }
  if (segment.tape) await loadVaporTape(context, ensemble);
  return context.startRendering();
}

export async function renderFullAudio({ sampleRate = 48000 } = {}) {
  const master = new AudioBuffer({ length: FULL_SCORE_SECONDS * sampleRate, sampleRate, numberOfChannels: 2 });
  const channels = [master.getChannelData(0), master.getChannelData(1)];
  for (const segment of fullArrangement) {
    const rendered = await renderChapter(segment, sampleRate);
    const start = Math.round(segment.start * sampleRate);
    for (const [channel, track] of channels.entries()) {
      const chapter = rendered.getChannelData(channel);
      for (let i = 0; i < chapter.length; i += 1) track[start + i] += chapter[i];
    }
  }
  let peak = 0;
  for (const track of channels) {
    for (const sample of track) peak = Math.max(peak, Math.abs(sample));
  }
  if (!Number.isFinite(peak) || peak < 0.001) throw new Error('The score rendered without a valid signal.');
  const scale = 10 ** (FULL_SCORE_MASTER_PEAK_DB / 20) / peak;
  for (const track of channels) {
    for (let i = 0; i < track.length; i += 1) track[i] *= scale;
  }
  return master;
}
