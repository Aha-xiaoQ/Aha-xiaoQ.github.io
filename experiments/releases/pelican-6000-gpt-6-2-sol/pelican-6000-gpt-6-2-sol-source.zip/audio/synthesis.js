const TAU = 2 * Math.PI;
const FLOOR = 0.00003;
const frequency = (midi) => 440 * 2 ** ((midi - 69) / 12);

function seededNoise(seed) {
  let state = seed >>> 0;
  return () => {
    state = (Math.imul(state, 1664525) + 1013904223) >>> 0;
    return state / 2147483648 - 1;
  };
}

function gain(ctx, value, output) {
  const stage = ctx.createGain();
  stage.gain.value = value;
  stage.connect(output);
  return stage;
}

function filter(ctx, type, hz, q, output) {
  const stage = ctx.createBiquadFilter();
  stage.type = type;
  stage.frequency.value = hz;
  stage.Q.value = q;
  stage.connect(output);
  return stage;
}

function oscillator(ctx, output, type, hz) {
  const source = ctx.createOscillator();
  source.type = type;
  source.frequency.value = hz;
  source.connect(output);
  return source;
}

function envelope(param, time, attack, peak, decay, level, end) {
  param.setValueAtTime(FLOOR, time);
  param.linearRampToValueAtTime(peak, time + attack);
  param.exponentialRampToValueAtTime(Math.max(FLOOR, level), time + decay);
  param.exponentialRampToValueAtTime(FLOOR, time + end);
}

export function roomImpulse(ctx, config) {
  const { seconds, damping, seed } = config;
  const length = Math.round(ctx.sampleRate * seconds);
  const buffer = ctx.createBuffer(2, length, ctx.sampleRate);
  for (let channel = 0; channel < 2; channel += 1) {
    const samples = buffer.getChannelData(channel);
    const noise = seededNoise(seed + 133 * channel);
    let dark = 0;
    const predelay = 0.013 + 0.004 * channel;
    for (let i = Math.floor(predelay * ctx.sampleRate); i < length; i += 1) {
      const x = (i / ctx.sampleRate - predelay) / (seconds - predelay);
      dark += damping * (noise() - dark);
      const swell = Math.min(1, x * 31);
      samples[i] = 0.017 * dark * swell * (1 - x) ** 3.2;
    }
    for (const [time, reflection] of [[0.021, 0.16], [0.035, -0.094], [0.055, 0.083], [0.069, -0.035]]) {
      samples[Math.round((time + channel * 0.003) * ctx.sampleRate)] += reflection;
    }
  }
  return buffer;
}

export function makeInstruments(ctx) {
  const noiseBuffer = ctx.createBuffer(1, 3 * ctx.sampleRate, ctx.sampleRate);
  const samples = noiseBuffer.getChannelData(0);
  const random = seededNoise(763841);
  for (let index = 0; index < samples.length; index += 1) samples[index] = random();

  function noiseVoice(output, time, startOffset, length) {
    const voice = ctx.createBufferSource();
    voice.buffer = noiseBuffer;
    voice.connect(output);
    voice.start(time, startOffset, length);
  }

  function partial(output, time, pitch, amp, attack, body, release, drift = 0) {
    const node = gain(ctx, 0, output);
    envelope(node.gain, time, attack, amp, body, amp * 0.24, release);
    const wave = oscillator(ctx, node, 'sine', pitch);
    wave.detune.setValueAtTime(drift, time);
    wave.detune.linearRampToValueAtTime(0, time + body);
    wave.start(time);
    wave.stop(time + release + 0.003);
  }

  function drum(output, time, event) {
    const { amp, low = false, shift = 0 } = event;
    const modes = low
      ? [[60, 44, 1, 0.44], [126, 95, 0.24, 0.23], [211, 173, 0.14, 0.135], [309, 281, 0.09, 0.08]]
      : [[127, 91, 0.68, 0.19], [216, 171, 0.25, 0.126], [323, 257, 0.22, 0.089], [445, 397, 0.11, 0.065]];
    for (const [initial, settled, weight, length] of modes) {
      const skin = gain(ctx, 0, output);
      envelope(skin.gain, time, 0.003, amp * weight, length * 0.25, amp * weight * 0.32, length);
      const tone = oscillator(ctx, skin, 'sine', initial + shift);
      tone.frequency.setValueAtTime(initial + shift, time);
      tone.frequency.exponentialRampToValueAtTime(settled + shift, time + length * 0.18);
      tone.start(time);
      tone.stop(time + length + 0.003);
    }
    const surface = gain(ctx, 0, output);
    envelope(surface.gain, time, 0.002, amp * (low ? 0.6 : 1.18), 0.024, amp * 0.12, 0.085);
    const fiber = filter(ctx, 'bandpass', low ? 540 : 1220, low ? 1.25 : 2.2, surface);
    noiseVoice(fiber, time, (time * 1.43) % 1, 0.091);
  }

  const glottal = Float32Array.from({ length: 18 }, (_, harmonic) =>
    harmonic === 0 ? 0 : Math.sin(1.38 * harmonic) / harmonic ** 1.34);
  const vowelWave = ctx.createPeriodicWave(new Float32Array(glottal.length), glottal);

  function breathChoir(output, time, event) {
    const { note, length, amp, vowel = 'a', harmony = false } = event;
    const pitch = frequency(note);
    const parts = harmony ? [[0, 0, 0.65], [-8, 0.028, 0.4], [11, 0.05, 0.27]] : [[0, 0, 0.79], [-9, 0.023, 0.3]];
    for (const [cents, lag, weight] of parts) {
      const begin = time + lag;
      const attack = Math.min(length * 0.25, 0.115 + lag);
      const held = gain(ctx, 0, output);
      envelope(held.gain, begin, attack, amp * weight, length * 0.67, amp * weight * 0.66, length + 0.132);
      const source = ctx.createOscillator();
      source.setPeriodicWave(vowelWave);
      source.frequency.setValueAtTime(pitch, begin);
      source.detune.setValueAtTime(cents - 31, begin);
      source.detune.linearRampToValueAtTime(cents + 3, begin + attack * 0.84);
      source.detune.linearRampToValueAtTime(cents - 7, begin + length);
      const vibration = gain(ctx, 4.0 + lag * 34, source.detune);
      const lfo = oscillator(ctx, vibration, 'sine', 4.4 + lag * 14);
      const warm = filter(ctx, 'lowpass', 680, 0.25, gain(ctx, 0.32, held));
      source.connect(warm);
      const formants = vowel === 'u'
        ? [[405, 490, 3.4, 0.88], [780, 840, 4.4, 0.47], [2235, 2170, 6.5, 0.15]]
        : [[570, 630, 3.6, 1.0], [1110, 1270, 4.9, 0.62], [2320, 2210, 6.4, 0.13]];
      for (const [from, to, q, volume] of formants) {
        const resonance = filter(ctx, 'bandpass', from, q, gain(ctx, volume, held));
        resonance.frequency.setValueAtTime(from, begin);
        resonance.frequency.linearRampToValueAtTime(to, begin + attack * 1.3);
        source.connect(resonance);
      }
      noiseVoice(filter(ctx, 'bandpass', 1320, 0.85, gain(ctx, 0.11, held)), begin, (0.5 + begin) % 1.6, length + 0.15);
      [source, lfo].forEach((voice) => {
        voice.start(begin);
        voice.stop(begin + length + 0.14);
      });
    }
  }

  // The finger lightly touches the string's node in fan (harmonic) notes.
  // Each mode has its own decay, plus a short noise excitation from the string and soundboard.
  function qin(output, time, event) {
    const { note, amp, length = 0.72, harmonic = false, touch = 0.19, slide = 0 } = event;
    const root = frequency(note);
    const waveform = filter(ctx, 'lowpass', harmonic ? 4200 : 3200, 0.15, output);
    const body = filter(ctx, 'peaking', 580, 0.9, waveform);
    body.gain.value = harmonic ? 1.8 : 3.3;
    for (let i = 1; i <= 10; i += 1) {
      const n = harmonic ? i * 2 : i;
      const weight = Math.abs(Math.sin(Math.PI * n * touch)) / i ** (harmonic ? 1.52 : 0.82);
      if (weight < 0.018) continue;
      const ring = gain(ctx, 0, body);
      const hold = length * (0.21 + 0.19 / i);
      const release = length * (0.65 + 0.43 / i);
      const peak = amp * weight;
      envelope(ring.gain, time, 0.0035, peak, hold, peak * (0.30 + 0.17 / i), release);
      const wave = oscillator(ctx, ring, 'sine', root * n * Math.sqrt(1 + 0.000018 * n * n));
      wave.detune.setValueAtTime(slide * 0.24, time);
      wave.detune.linearRampToValueAtTime(slide, time + 0.028);
      wave.detune.linearRampToValueAtTime(0, time + Math.min(0.25, release * 0.75));
      wave.start(time);
      wave.stop(time + release + 0.004);
    }
    const finger = gain(ctx, 0, output);
    envelope(finger.gain, time, 0.0015, amp * (harmonic ? 0.26 : 0.71), 0.02, amp * 0.11, 0.087);
    noiseVoice(filter(ctx, 'bandpass', harmonic ? 1940 : 1050, 1.3, finger), time, (time * 1.19) % 1.4, 0.092);
    if (!harmonic) partial(output, time, 181, amp * 0.1, 0.004, 0.032, 0.11, 2);
  }

  function atmosphere(output, time, event) {
    const { amp, length, tone = 350 } = event;
    const air = gain(ctx, 0, output);
    envelope(air.gain, time, length * 0.22, amp, length * 0.58, amp * 0.73, length);
    const breeze = filter(ctx, 'bandpass', tone, 0.42, air);
    const noise = ctx.createBufferSource();
    noise.buffer = noiseBuffer;
    noise.loop = true;
    noise.connect(breeze);
    noise.start(time, (time * 1.7) % 2);
    noise.stop(time + length);
  }

  function wood(output, time, event) {
    const { amp, tone = 405, length = 0.132 } = event;
    const tap = gain(ctx, 0, output);
    envelope(tap.gain, time, 0.0018, amp * 0.76, 0.023, amp * 0.072, length);
    noiseVoice(filter(ctx, 'bandpass', tone * 2.8, 2.4, tap), time, (time * 1.73) % 1.5, length);
    partial(output, time, tone, amp * 0.66, 0.002, 0.021, length, 3);
    partial(output, time, tone * 1.87, amp * 0.31, 0.0017, 0.021, length * 0.65, 8);
  }

  function kick(output, time, event) {
    const { amp, low = false } = event;
    const node = gain(ctx, 0, output);
    envelope(node.gain, time, 0.004, amp, 0.093, amp * 0.27, 0.255);
    const wave = oscillator(ctx, node, 'sine', low ? 101 : 150);
    wave.frequency.setValueAtTime(low ? 101 : 150, time);
    wave.frequency.exponentialRampToValueAtTime(49, time + 0.057);
    wave.frequency.exponentialRampToValueAtTime(43, time + 0.22);
    wave.start(time);
    wave.stop(time + 0.26);
    partial(output, time, 816, amp * 0.085, 0.002, 0.009, 0.035, 3);
  }

  function clap(output, time, event) {
    const { amp } = event;
    const burst = gain(ctx, 0, output);
    burst.gain.setValueAtTime(FLOOR, time);
    for (const [offset, strength] of [[0, 0.62], [0.012, 0.8], [0.023, 1]]) {
      burst.gain.linearRampToValueAtTime(amp * strength, time + offset + 0.003);
      burst.gain.exponentialRampToValueAtTime(amp * 0.10, time + offset + 0.01);
    }
    burst.gain.exponentialRampToValueAtTime(FLOOR, time + 0.143);
    noiseVoice(filter(ctx, 'bandpass', 1690, 0.8, burst), time, time % 1.5, 0.155);
    partial(output, time + 0.017, 232, amp * 0.40, 0.003, 0.028, 0.12, 13);
  }

  function hat(output, time, event) {
    const { amp, length = 0.083 } = event;
    const brush = gain(ctx, 0, output);
    envelope(brush.gain, time, 0.002, amp, length * 0.32, amp * 0.18, length);
    noiseVoice(filter(ctx, 'highpass', 4600, 0.16, brush), time, (time * 1.31) % 1.7, length);
  }

  function bass(output, time, event) {
    const { note, amp, length } = event;
    const pitch = frequency(note);
    const held = gain(ctx, 0, output);
    envelope(held.gain, time, 0.023, amp, length * 0.70, amp * 0.52, length + 0.10);
    const warm = filter(ctx, 'lowpass', 305, 0.55, held);
    const foundation = oscillator(ctx, warm, 'sine', pitch);
    const round = oscillator(ctx, gain(ctx, 0.25, warm), 'triangle', pitch * 2);
    [foundation, round].forEach((source) => {
      source.start(time);
      source.stop(time + length + 0.11);
    });
  }

  function pluckKeys(output, time, event) {
    const { note, amp, length = 0.37 } = event;
    const pitch = frequency(note);
    const body = gain(ctx, 0, output);
    envelope(body.gain, time, 0.011, amp, length * 0.32, amp * 0.39, length);
    const carrier = oscillator(ctx, body, 'sine', pitch);
    const index = gain(ctx, 0, carrier.frequency);
    index.gain.setValueAtTime(pitch * 0.46, time);
    index.gain.exponentialRampToValueAtTime(Math.max(0.5, pitch * 0.034), time + length * 0.83);
    const modulator = oscillator(ctx, index, 'sine', pitch * 2.008);
    [carrier, modulator].forEach((source) => {
      source.start(time);
      source.stop(time + length + 0.004);
    });
    partial(output, time, pitch * 2, amp * 0.21, 0.005, 0.057, length * 0.51, 10);
  }

  return { drum, breathChoir, qin, atmosphere, wood, kick, clap, hat, bass, pluckKeys };
}
