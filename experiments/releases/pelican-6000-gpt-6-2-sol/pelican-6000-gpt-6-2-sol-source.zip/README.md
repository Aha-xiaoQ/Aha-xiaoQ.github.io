# 鹈鹕骑车六千年 · GPT-6.2 Sol

一只鹈鹕骑车穿过二十种艺术风格。片长 2 分 17 秒。

## 播放

解压后用浏览器打开 pelican.html。点击播放可听到原创配乐，也可以拖动进度条或全屏观看。

## 重建播放器

安装 Node.js 20 或更新版本，在当前目录运行下列命令。

    npm ci
    npm run build

src/ 是画面与播放器源码，audio/ 是乐谱与音色。需要导出成片时，准备 Chrome、FFmpeg 和 ffprobe，依次运行 node tools/audio-master.mjs 和 node tools/export-film.mjs。

第三方组件和许可见 [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md)。
