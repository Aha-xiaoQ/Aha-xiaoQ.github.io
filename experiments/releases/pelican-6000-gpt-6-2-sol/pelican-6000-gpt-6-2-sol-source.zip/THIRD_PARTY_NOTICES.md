# 来源与第三方组件

## 用户提供的基线

`Pelican_PureCode_R6_Source.zip` 的 SHA-256 为 `DFCBD9363F44B802F98047A9B61D486CD3D55E67D787DC532AF69FF6B4EE5B3B`。本地制作复用了 R6 的骑行接触点、双连杆腿部解算与链条外公切线方法，范围见 `src/rig/geometry.js`。新时间轴、图层合成、场景占位美术和分媒介造型在 Sol_R7 中独立实现。来源范围不涉及另一版 R7。

## 随包组件

- [p5.js](https://github.com/processing/p5.js) 2.4.0。`vendor/p5.min.js` 和 `vendor/lib/p5.js` 保留所用上游构建和源码形式，许可文本在 `vendor/license.txt`。生成的离线 HTML 依 R6 的做法关闭可选的错误文案翻译下载，绘图运行时沿用上游实现。
- Puppeteer Core 用于导出，采用 Apache-2.0。esbuild 用于本地构建，采用 MIT。依赖由包管理器安装，各自的许可文本随各自包提供。
- Chrome 和 FFmpeg 作为系统工具调用。预览使用系统字体。完整 HTML 不包含外部字体、图像或音频文件。水墨与画笔通过本项目自编 Canvas 绘图实现。

## 参考

《67：一部藝術史》提供场景组织和逐帧检查的方法参考。源码 MIT，媒体权利另行保留。Sol_R7 未引入其源码、媒体和文案。 [Tunai-0511 仓库](https://github.com/Tunai-0511/meme67-art-history) · [媒体许可](https://github.com/Tunai-0511/meme67-art-history/blob/main/LICENSE-MEDIA.md)

Opus 5.5、Gemini 4 Carbon 和 Hydrogen 的同题作品用于前期构图与节奏研究。参考视频素材未进入 Sol_R7 程序和导出。 [Opus 5.5](https://www.bilibili.com/video/BV1pLnw6YEzq/) · [Gemini 4 Carbon](https://www.bilibili.com/video/BV1SsWy6TEKx/) · [Hydrogen](https://www.bilibili.com/video/BV1DTWi62Ewy/)

星空、桥上人物与默片楼梯以历史作品的表现手法为出发点。场景中的构图、笔触、剪影及位移由代码重新绘制。 [MoMA《星月夜》](https://www.moma.org/collection/works/79802) · [挪威国家博物馆《呐喊》](https://www.nasjonalmuseet.no/en/collection/object/NG.M.00939) · [美国国会图书馆默片资料](https://blogs.loc.gov/copyright/2020/10/copyright-horror-stories/) · [配器参考](audio/FULL_SCORE.md)
