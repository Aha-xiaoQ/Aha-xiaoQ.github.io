import { createFilm } from './main.js';
import {renderFullAudio} from '../audio/full-score.js';

const el = (id) => document.getElementById(id);
const canvas = el('film');
const stage = el('stage');
const play = el('play');
const seek = el('seek');
const fullscreen = el('fullscreen');
const sound = el('sound');
const status = el('status');

function timecode(seconds) {
  const whole = Math.floor(seconds);
  return `${Math.floor(whole / 60)}:${String(whole % 60).padStart(2, '0')}`;
}

function showError(error) {
  status.hidden = false;
  status.textContent = `画面初始化失败。${error.message ?? error}`;
  console.error(error);
}

function mountPlayer(film) {
  let time = 0;
  let playing = false;
  let anchor = 0;
  let frame = null;
  let muted = false;
  let audioContext;
  let score;
  let source;
  let audioOffset;
  let audioAnchor;
  let generation = 0;
  const featured = [...document.querySelectorAll('[data-jump]')];

  seek.max = String(film.duration);
  el('total').textContent = timecode(film.duration);
  for (const start of film.sceneStarts) {
    const marker = document.createElement('span');
    marker.style.left = `${100 * start / film.duration}%`;
    el('markers').append(marker);
  }

  function draw() {
    film.renderAt(time);
    seek.value = String(time);
    seek.style.setProperty('--progress', `${100 * time / film.duration}%`);
    const label = film.labelAt(time);
    const title = typeof label === 'string' ? label : label?.title ?? label?.name ?? '';
    const currentTime = timecode(time);
    if (el('elapsed').textContent !== currentTime) el('elapsed').textContent = currentTime;
    if (el('chapter').textContent !== title) el('chapter').textContent = title;
    const spokenTime = `${currentTime}，${title}`;
    if (seek.getAttribute('aria-valuetext') !== spokenTime) seek.setAttribute('aria-valuetext', spokenTime);
    for (const button of featured) {
      const selected = time >= Number(button.dataset.jump) && time < Number(button.dataset.until);
      if (selected) {
        if (button.getAttribute('aria-current') !== 'true') button.setAttribute('aria-current', 'true');
      } else if (button.hasAttribute('aria-current')) {
        button.removeAttribute('aria-current');
      }
    }
  }

  function stopClock() {
    if (frame !== null) cancelAnimationFrame(frame);
    frame = null;
    if (source) {
      source.stop();
      source.disconnect();
      source = undefined;
    }
  }

  function startClock() {
    const ticket = ++generation;
    stopClock();
    status.hidden = true;
    if (!playing) return;
    if (muted) {
      anchor = performance.now() - time * 1000;
      frame = requestAnimationFrame(tick);
      return;
    }
    status.textContent = '正在合成配乐…';
    status.hidden = false;
    (async () => {
      audioContext ??= new AudioContext({latencyHint: 'playback'});
      const resume = audioContext.resume();
      score ??= renderFullAudio({sampleRate: 48000});
      const [buffer] = await Promise.all([score, resume]);
      if (ticket !== generation) return;
      if (Math.abs(buffer.duration - film.duration) > .001) throw Error('配乐与影片时长不一致');
      source = audioContext.createBufferSource();
      source.buffer = buffer;
      source.connect(audioContext.destination);
      audioOffset = time;
      audioAnchor = audioContext.currentTime + .025;
      source.start(audioAnchor, audioOffset);
      status.hidden = true;
      frame = requestAnimationFrame(tick);
    })().catch(error => {
      if (ticket !== generation) return;
      console.error(error);
      score = undefined;
      muted = true;
      syncSoundButton();
      startClock();
      status.textContent = '配乐未能启动，点击声音按钮可重试。';
      status.hidden = false;
    });
  }

  function setPlaying(value) {
    playing = value;
    if (playing && time >= film.duration) time = 0;
    play.dataset.playing = String(playing);
    const label = playing ? '暂停' : '播放';
    play.setAttribute('aria-label', label);
    play.title = `${label}（空格）`;
    startClock();
  }

  function tick(now) {
    frame = null;
    const elapsed = source ? audioOffset + Math.max(0, audioContext.currentTime - audioAnchor) : (now - anchor) / 1000;
    time = Math.min(film.duration, elapsed);
    draw();
    if (time >= film.duration) setPlaying(false);
    if (playing) frame = requestAnimationFrame(tick);
  }

  function moveTo(seconds) {
    time = Math.min(film.duration, Math.max(0, seconds));
    draw();
    if (time >= film.duration) setPlaying(false);
    else if (playing) startClock();
  }

  function syncSoundButton() {
    sound.textContent = muted ? '已静音' : '声音';
    sound.setAttribute('aria-pressed', String(!muted));
    sound.title = muted ? '打开声音' : '静音';
  }

  play.addEventListener('click', () => setPlaying(!playing));
  sound.addEventListener('click', () => {
    muted = !muted;
    syncSoundButton();
    if (playing) startClock();
  });
  for (const button of featured) {
    button.addEventListener('click', () => moveTo(Number(button.dataset.jump)));
    button.disabled = false;
  }
  seek.addEventListener('input', () => moveTo(Number(seek.value)));
  fullscreen.addEventListener('click', () => stage.requestFullscreen?.().catch(console.error));
  document.addEventListener('keydown', (event) => {
    if (event.altKey || event.ctrlKey || event.metaKey || event.target.closest?.('input')) return;
    if (event.code === 'Space') {
      if (event.target.closest?.('button')) return;
      event.preventDefault();
      if (!event.repeat) setPlaying(!playing);
    }
    if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') {
      event.preventDefault();
      moveTo(time + (event.key === 'ArrowLeft' ? -.5 : .5));
    }
  });

  const initial = new URLSearchParams(location.search).get('t');
  if (initial !== null && Number.isFinite(Number(initial))) moveTo(Number(initial));
  else draw();
  play.disabled = false;
  sound.disabled = false;
  syncSoundButton();
  seek.disabled = false;
  fullscreen.disabled = !document.fullscreenEnabled;
  status.hidden = true;
  window.SOL_R7 = film;
}

try {
  new window.p5((sketch) => {
    sketch.setup = () => {
      try {
        sketch.pixelDensity(1);
        sketch.createCanvas(1920, 1080, sketch.P2D, canvas);
        sketch.noLoop();
        mountPlayer(createFilm(canvas));
      } catch (error) {
        showError(error);
      }
    };
  }, stage);
} catch (error) {
  showError(error);
}
