export const INTRO = 5;
export const BPM = 120;
export const BEAT = 60 / BPM;
export const SCENE_DURATION = BEAT * 12;
export const PANEL = 1000;

const sceneRows = [
  ['sahara', '撒哈拉岩画', 'Saharan Rock Art', '约公元前 4000 年', '#823f2c', '#dfae7e'],
  ['egypt', '埃及壁画', 'Egyptian Mural', '约公元前 1300 年', '#044d59', '#ead6a1'],
  ['han', '汉画像石拓片', 'Han Stone Rubbing', '约公元 100 年', '#252a2d', '#cdc9b7'],
  ['tang', '唐代白描', 'Tang Line Drawing', '约公元 750 年', '#5d493f', '#efe1c6'],
  ['song', '宋代山水', 'Song Landscape', '约公元 1000 年', '#344a44', '#d9d5bb'],
  ['riverside', '清明上河图', 'Along the River', '约公元 1100 年', '#546864', '#e8d6af'],
  ['maya', '玛雅抄本', 'Maya Codex', '约公元 1200 年', '#a74934', '#edc892'],
  ['mughal', '莫卧儿细密画', 'Mughal Miniature', '约公元 1600 年', '#235c55', '#d9ba66'],
  ['bada', '八大山人写意', 'Bada Shanren', '约公元 1690 年', '#38404b', '#e9e2ce'],
  ['wayang', '爪哇皮影戏', 'Wayang Kulit', '约公元 1800 年', '#522c2e', '#eeac61'],
  ['ukiyo', '浮世绘', 'Ukiyo-e', '1830 年代', '#21516d', '#dfb686'],
  ['starry', '星月夜', 'The Starry Night', '1889 年', '#1b3971', '#f1ce65'],
  ['scream', '呐喊', 'The Scream', '1893 年', '#753e54', '#ef9b57'],
  ['shadow', '诺斯费拉图', 'Nosferatu', '1922 年', '#24242d', '#aa9675'],
  ['scope', '示波器矢量图', 'Oscilloscope', '1950 年代', '#12342c', '#6cffa3'],
  ['pixel', '8-bit 像素游戏', '8-bit Game', '1980 年代', '#253c6a', '#dcbc74'],
  ['chat', '早期聊天窗口', 'Early Instant Messaging', '2000 年代', '#496d9a', '#c1d9de'],
  ['vapor', '蒸汽波', 'Vaporwave', '2010 年代', '#402962', '#f4a8bc'],
  ['short', '竖屏短视频', 'Vertical Video', '2020 年代', '#143c49', '#83e0ba'],
  ['code', '代码美学', 'Code Art', '2020 年代', '#28323f', '#b4d9a7'],
];

export const SCENES = Object.freeze(sceneRows.map(([id, zh, en, era, ink, paper], index) => Object.freeze({
  id, zh, en, era, ink, paper, index, start: INTRO + SCENE_DURATION * index,
})));
export const SCENE_STARTS = Object.freeze(SCENES.map(({start}) => start));
export const OUTRO = INTRO + SCENES.length * SCENE_DURATION;
export const DURATION = OUTRO + BEAT * 24;

export function sceneAt(time) {
  return SCENES[Math.floor((time - INTRO) / SCENE_DURATION)];
}
