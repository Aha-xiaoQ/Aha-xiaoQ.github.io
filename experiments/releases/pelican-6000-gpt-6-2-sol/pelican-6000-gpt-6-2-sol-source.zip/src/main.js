import {BEAT, DURATION, INTRO, OUTRO, PANEL, SCENES, SCENE_DURATION, SCENE_STARTS, sceneAt} from './beat/index.js';
import {clamp, clipRect, fade, FONT, line, mix, SANS, surface, TAU, text} from './kit/index.js';
import {drawRider, rigLandmarks} from './rig/index.js';
import {paintIntroPage, paintPanelTitle, paintPress, paintPressForeground} from './scenes/index.js';
import {paintSahara, paintSaharaForeground, paintSong, paintSongForeground} from './scenes/stage2-historical.js';
import {paintPortrait, paintPortraitUi} from './scenes/stage2-portrait.js';
import {HISTORIC} from './scenes/full-historic/index.js';
import {MODERN} from './scenes/full-modern/index.js';
import {paintCodeExit, paintCodeScene, paintCodeTitle} from './scenes/full-code.js';
import {arcLift, getPerformance, paintSceneRider, scopeSignal, travelledTime} from './main/performance.js';

const WIDTH = 1600;
const HEIGHT = 900;
const FLOOR = 760;
const SCALE = 0.66;
const SPEED = PANEL / SCENE_DURATION;
const GEAR_RATIO = SPEED / (77 * SCALE * TAU / (2 * BEAT));
const INTRO_STYLE = 3;
const PORTRAIT = SCENES[18];
const GALLERY_WIDTH = WIDTH * 0.9;
const MAX_TIME = DURATION - 1e-6;
const ROAD_AMPLITUDE = [0, -10, 0, 8, 32, -104, 0, -10, 12, 0, 24, 0, -8, -105, 0, 0, 0, 0, 0, 0];
const SKETCH_ROLLS = 3.65;
const SONG = SCENES[4];
const WORLD = new Map([
  ...HISTORIC,
  ...MODERN,
  [0, {background: paintSahara, foreground: paintSaharaForeground}],
  [4, {background: paintSong, foreground: paintSongForeground}],
  [18, {background: paintPortrait}],
  [19, {background: paintCodeScene, title: paintCodeTitle}],
]);

// The height and first derivative are the same on both sides of every frame.
function elevation(x) {
  const block = Math.floor(x / PANEL);
  if (block < 0 || block >= SCENES.length) return FLOOR;
  const u = (x - block * PANEL) / PANEL;
  return FLOOR + ROAD_AMPLITUDE[block] * Math.sin(Math.PI * u) ** 2;
}

function routeArc() {
  const arcs = new Float64Array(PANEL * SCENES.length + 1);
  for (let x = 1; x < arcs.length; x += 1) {
    arcs[x] = arcs[x - 1] + Math.hypot(1, elevation(x) - elevation(x - 1));
  }
  return x => {
    if (x < 0) return x;
    if (x >= arcs.length - 1) return arcs.at(-1) + x - arcs.length + 1;
    const lo = Math.floor(x);
    return mix(arcs[lo], arcs[lo + 1], x - lo);
  };
}

const routeDistance = routeArc();

function introX(time) {
  const span = INTRO - SKETCH_ROLLS;
  const u = clamp((time - SKETCH_ROLLS) / span);
  return -250 * (2 * u ** 3 - 3 * u ** 2 + 1) + SPEED * span * (u ** 3 - u ** 2);
}

function scaleAt(time) {
  if (time < INTRO) return mix(0.44, SCALE, fade(time, SKETCH_ROLLS, INTRO));
  const local = time - SONG.start;
  const depth = fade(local, 0.23, 0.99) * (1 - fade(local, 1.65, 3.2));
  return mix(SCALE, 0.127, depth);
}

function sketchWheel() {
  // The illustration grows as it leaves the paper. Integrate travelled
  // distance against its changing radius, then pin zero to the first seam.
  const segments = 160;
  const dt = (INTRO - SKETCH_ROLLS) / segments;
  const angle = new Float64Array(segments + 1);
  for (let index = segments - 1; index >= 0; index -= 1) {
    const t = SKETCH_ROLLS + index * dt;
    angle[index] = angle[index + 1] - (introX(t + dt) - introX(t)) / (77 * scaleAt(t + dt / 2));
  }
  return time => {
    const step = clamp((time - SKETCH_ROLLS) / dt, 0, segments - 1e-9);
    const lo = Math.floor(step);
    return mix(angle[lo], angle[lo + 1], step - lo);
  };
}

const sketchWheelAngle = sketchWheel();

function apparentWheelCorrection() {
  const n = 360;
  const angles = new Float64Array(n + 1);
  for (let i = 1; i <= n; i += 1) {
    const time = SONG.start + (i - .5) / 60;
    const x = (SONG.start - INTRO + i / 60) * SPEED;
    const dx = routeDistance(x) - routeDistance(x - SPEED / 60);
    angles[i] = angles[i - 1] + dx * (1 / scaleAt(time) - 1 / SCALE) / 77;
  }
  return time => {
    const u = (time - SONG.start) * 60;
    if (u <= 0) return 0;
    if (u >= n) return angles[n];
    const j = Math.floor(u);
    return mix(angles[j], angles[j + 1], u - j);
  };
}

const perspectiveWheelAngle = apparentWheelCorrection();

export function roadPose(time) {
  const travelled = travelledTime(time);
  const x = time < INTRO ? introX(time) : (travelled - INTRO) * SPEED;
  const scale = scaleAt(time);
  const rise = offset => elevation(x + scale * (offset * Math.cos(tilt) - 25 * Math.sin(tilt)));
  let tilt = 0;
  for (let step = 0; step < 4; step += 1) {
    tilt = Math.asin((rise(150) - rise(-130)) / (280 * scale));
  }
  const lift = arcLift(time);
  const y = rise(-130) + scale * (130 * Math.sin(tilt) - 25 * Math.cos(tilt) - 77) - lift;
  // In the book the sketch starts to pedal only when it rolls off the page.
  const wheelAngle = time < INTRO ? sketchWheelAngle(time) : routeDistance(x) / (77 * SCALE) + perspectiveWheelAngle(time);
  const phase = time < INTRO ? wheelAngle / GEAR_RATIO : TAU * (travelled - INTRO) / (2 * BEAT);
  return {x, y, time, scale, tilt, phase, wheelAngle, lift, gearRatio: GEAR_RATIO, ...getPerformance(time, phase, sceneAt(time))};
}

function cameraAt(time, pose) {
  const afterIntro = fade(time, 3.3, INTRO);
  const songLocal = time - SONG.start;
  const portraitLocal = time - PORTRAIT.start;
  const rockLocal = time - SCENES[0].start;
  const active = sceneAt(time);
  const t = time - (active?.start ?? 0);
  const actionZoom = [1, 5, 9, 12, 13, 14, 15, 19].includes(active?.index)
    ? fade(t, .38, 1.87) * (1 - fade(t, 4.54, 5.86)) : 0;
  const rockInspection = fade(rockLocal, 0.64, 2.02) * (1 - fade(rockLocal, 4.37, 5.67));
  const findRider = fade(songLocal, 1.13, 2.76) * (1 - fade(songLocal, 4.20, 5.64));
  const revealScale = 0.245 * findRider;
  const cropDrift = fade(portraitLocal, 1.27, 2.52) * (1 - fade(portraitLocal, 2.77, 3.69));
  const lead = 103 - 57 * findRider - 224 * cropDrift - 41 * rockInspection;
  const travel = time < INTRO ? mix(-500, pose.x + lead, afterIntro) : pose.x + lead;
  const nearest = INTRO + Math.round((time - INTRO) / SCENE_DURATION) * SCENE_DURATION;
  const seamOffset = (time - nearest) / 0.29;
  const push = nearest >= INTRO ? Math.exp(-(seamOffset ** 2)) : 0;
  const baseZoom = mix(0.88, 0.90, afterIntro);
  return {
    x: travel,
    y: mix(505, 515, afterIntro) + findRider * 95 + rockInspection * 55 - 15 * viewportAt(time).openness
      + 38 * actionZoom + (pose.y - 690) * (active?.index === 13 ? .18 : 0),
    z: baseZoom + 0.045 * push + revealScale + 0.225 * rockInspection + .13 * actionZoom,
  };
}

function localInfo(time, scene, extra = {}) {
  return {time, local: clamp(time - scene.start, 0, SCENE_DURATION), ...extra};
}

function drawFrame(ctx, index, time) {
  const next = SCENES[index];
  const x = PANEL * index;
  const footing = elevation(x);
  ctx.fillStyle = '#211e1a';
  ctx.fillRect(x - 5, 0, 10, footing - 22);
  ctx.fillRect(x - 5, footing + 17, 10, PANEL - footing - 17);
  ctx.fillStyle = next?.paper ?? '#c1ab78';
  ctx.fillRect(x - 2, 0, 1.5, footing - 26);
  ctx.fillRect(x + 1, footing + 22, 1.1, PANEL - footing - 22);
  ctx.save();
  ctx.translate(x, footing + 3);
  ctx.beginPath();
  ctx.moveTo(-14, 0);
  ctx.lineTo(0, -3);
  ctx.lineTo(14, 0);
  ctx.lineTo(0, 3);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
  if (index === 14 && time >= 88.91 && time <= 89.42) {
    const charge = fade(time, 88.91, 89) * (1 - fade(time, 89.02, 89.42));
    ctx.save();
    ctx.globalAlpha *= charge;
    ctx.shadowColor = '#6affa0';
    ctx.shadowBlur = 22;
    line(ctx, [[x, 205], [x, footing - 26]], '#90f3a9', 2.5);
    line(ctx, [[x - 17, footing + 3], [x + 17, footing + 3]], '#c9ffc5', 2.5);
    ctx.restore();
  }
}

function drawRoom(ctx, index, time, pose, camera) {
  const origin = index * PANEL;
  const scene = SCENES[index];
  const featured = WORLD.get(index);
  const info = scene && localInfo(time, scene, {
    scene,
    title: false,
    riderX: pose.x - origin,
    riderY: pose.y,
    poseScale: pose.scale,
    phase: pose.phase,
    wheelAngle: pose.wheelAngle,
    signalAmount: index === 14 ? scopeSignal(time) : 0,
    cameraX: camera.x - origin,
    floorY: elevation(pose.x),
    floorAt: x => elevation(x + origin),
  });
  ctx.save();
  clipRect(ctx, origin, 0, PANEL, PANEL);
  ctx.save();
  ctx.translate(origin, 0);
  if (index === -1) {
    paintIntroPage(ctx, {time, local: clamp(time, 0, INTRO)});
  } else if (scene && time >= 3.25) {
    ctx.fillStyle = '#e8dbc0';
    ctx.fillRect(0, 0, PANEL, PANEL);
    ctx.globalAlpha = fade(time, 3.25, 3.70);
    if (!featured) throw Error(`Missing scene ${scene.id}`);
    featured.background(ctx, info);
  } else {
    if (index >= SCENES.length) paintCodeExit(ctx);
    else {
      ctx.fillStyle = '#e8dbc0';
      ctx.fillRect(0, 0, PANEL, PANEL);
    }
  }
  ctx.restore();
  if (index >= -1 && Math.abs(origin + PANEL / 2 - pose.x) < PANEL / 2 + 275 * pose.scale) {
    ctx.save();
    if (index === SONG.index) ctx.globalAlpha *= mix(0.62, 1, fade(pose.scale, .127, .51));
    const style = scene?.index ?? (index >= SCENES.length ? 19 : INTRO_STYLE);
    paintSceneRider(ctx, pose, style, info?.local ?? (style === 19 ? 6 : 0));
    ctx.restore();
  }
  if (featured?.foreground && time >= 3.25) {
    ctx.translate(origin, 0);
    featured.foreground(ctx, info);
  }
  ctx.restore();
}

function viewportAt(time) {
  const openness = fade(time, PORTRAIT.start, PORTRAIT.start + 0.72) * (1 - fade(time, PORTRAIT.start + 5.5, PORTRAIT.start + 6.27));
  const width = mix(WIDTH, HEIGHT * 9 / 16, openness);
  return {width, left: (WIDTH - width) / 2, openness};
}

function drawRoadFilm(ctx, time) {
  const pose = roadPose(time);
  const camera = cameraAt(time, pose);
  const viewport = viewportAt(time);
  ctx.fillStyle = viewport.openness > 0 ? '#070a0c' : '#d5c3a1';
  ctx.fillRect(0, 0, WIDTH, HEIGHT);
  ctx.save();
  clipRect(ctx, viewport.left, 0, viewport.width, HEIGHT);
  ctx.translate(WIDTH / 2, HEIGHT / 2);
  ctx.scale(camera.z, camera.z);
  ctx.translate(-camera.x, -camera.y);
  const halfView = viewport.width / (2 * camera.z);
  const left = Math.floor((camera.x - halfView) / PANEL);
  const right = Math.floor((camera.x + halfView) / PANEL);
  for (let index = left; index <= right; index += 1) {
    drawRoom(ctx, index, time, pose, camera);
  }
  ctx.globalAlpha = fade(time, 3.25, 3.70);
  for (let index = Math.max(0, left + 1); index <= right; index += 1) drawFrame(ctx, index, time);
  ctx.restore();
  const scene = sceneAt(time);
  if (scene && scene.index !== PORTRAIT.index) {
    const info = localInfo(time, scene, {scene, titleX: 0, titleY: 0});
    const frameLeft = WIDTH / 2 + (scene.index * PANEL - camera.x) * camera.z;
    const titleX = Math.min(viewport.left + viewport.width - 315, Math.max(72, viewport.left + 42, frameLeft + 49));
    ctx.save();
    ctx.globalAlpha = fade(info.local, -0.04, 0.19) * (1 - fade(info.local, 5.66, 6));
    ctx.translate(titleX, 135);
    ctx.scale(0.89, 0.89);
    const styled = WORLD.get(scene.index)?.title;
    if (scene.index === 0 || scene.index === SONG.index) drawHistoricTitle(ctx, scene);
    else if (styled) styled(ctx, info);
    else paintPanelTitle(ctx, scene, info);
    ctx.restore();
  }
  if (viewport.openness > 0) {
    paintPortraitUi(ctx, PORTRAIT, {...viewport, local: time - PORTRAIT.start});
  }
}

function drawHistoricTitle(ctx, scene) {
  if (scene.index === SONG.index) {
    const silk = ctx.createLinearGradient(0, 0, 320, 112);
    silk.addColorStop(0, '#f2ead5');
    silk.addColorStop(1, '#e0d4b9');
    ctx.fillStyle = silk;
    ctx.fillRect(0, 0, 284, 125);
    ctx.strokeStyle = '#ab9a73';
    ctx.strokeRect(5, 5, 274, 115);
    text(ctx, scene.zh, 23, 54, {size: 45, weight: 600, color: '#27332d'});
    text(ctx, scene.en, 24, 81, {size: 18, color: '#394c3d'});
    text(ctx, scene.era, 24, 107, {size: 17, color: '#424b38'});
    ctx.fillStyle = '#92472f';
    ctx.fillRect(236, 81, 22, 22);
    ctx.strokeStyle = '#e3c49a';
    ctx.strokeRect(239, 84, 16, 16);
    line(ctx, [[242, 88], [252, 88], [245, 94], [252, 97]], '#f1d0aa', 1.15);
    return;
  }
  ctx.beginPath();
  ctx.moveTo(0, 7);
  ctx.lineTo(320, 0);
  ctx.lineTo(334, 16);
  ctx.lineTo(327, 128);
  ctx.lineTo(12, 136);
  ctx.closePath();
  ctx.fillStyle = '#e4b780';
  ctx.fill();
  ctx.strokeStyle = '#6f3d2e';
  ctx.stroke();
  text(ctx, scene.zh, 22, 54, {size: 45, weight: 650, color: '#452820'});
  line(ctx, [[23, 66], [303, 62]], '#996348', 1.3);
  text(ctx, scene.en, 23, 92, {size: 18, color: '#563125'});
  text(ctx, scene.era, 23, 115, {size: 17, color: '#532f24'});
}

const galleryLayout = {
  gap: 14, x: (WIDTH - GALLERY_WIDTH) / 2, y: 116,
  tileWidth: (GALLERY_WIDTH - 14 * 6) / 7, tileHeight: 160,
};

function cell(index) {
  const {x, y, tileWidth, tileHeight, gap} = galleryLayout;
  return {x: x + (index % 7) * (tileWidth + gap), y: y + Math.floor(index / 7) * (tileHeight + gap), w: tileWidth, h: tileHeight};
}

function thumbnail(scene) {
  const canvas = surface(320, 266);
  const ctx = canvas.getContext('2d');
  ctx.scale(0.32, 0.32);
  ctx.translate(-scene.index * PANEL, -84);
  const local = scene.index === 14 ? 3.8 : 3.05;
  const pose = roadPose(scene.start + local);
  const extra = pose.scale * .15;
  drawRoom(ctx, scene.index, scene.start + local, {...pose, scale: pose.scale + extra, y: pose.y - extra * 102}, {x: pose.x});
  return canvas;
}

function drawPressRoom(ctx, elapsed) {
  const poseTime = OUTRO + elapsed;
  paintPress(ctx, {time: poseTime, local: elapsed});
  if (elapsed >= 11.24 && elapsed < 11.79) {
    const fraction = (elapsed - 11.24) / 0.55;
    drawRider(ctx, {x: mix(-250, 1240, fraction), y: 685, scale: 0.49, tilt: 0, time: poseTime, phase: TAU * elapsed, wheelAngle: TAU * elapsed, gearRatio: 1}, 19);
  }
  paintPressForeground(ctx, {time: poseTime, local: elapsed});
  for (const at of [5.0, 6.0, 7.0]) {
    const age = elapsed - at;
    if (age >= 0 && age < 0.20) {
      ctx.fillStyle = `rgba(255,245,224,${0.63 * (1 - age / 0.20) ** 2})`;
      ctx.fillRect(0, 0, 1000, 1000);
    }
  }
}

function drawGallery(ctx, elapsed, thumbnails, editorFreeze) {
  const press = cell(20);
  const finalPanel = cell(19);
  const pullBack = 1 - fade(elapsed, 0.0, 1.53);
  const angled = fade(elapsed, 3.0, 8.4);
  const zoom = mix(mix(1, WIDTH / finalPanel.w, pullBack), 4.55, angled);
  const centreX = mix(mix(WIDTH / 2, finalPanel.x + finalPanel.w / 2, pullBack), press.x + press.w / 2, angled);
  const centreY = mix(mix(HEIGHT / 2, finalPanel.y + finalPanel.h / 2, pullBack), press.y + press.h / 2 + 8, angled);
  ctx.fillStyle = '#211e19';
  ctx.fillRect(0, 0, WIDTH, HEIGHT);
  ctx.save();
  ctx.translate(WIDTH / 2, HEIGHT / 2 - 24 * angled);
  ctx.scale(zoom, zoom);
  ctx.translate(-centreX, -centreY);
  const grad = ctx.createLinearGradient(0, 0, 0, HEIGHT);
  grad.addColorStop(0, '#343026');
  grad.addColorStop(1, '#161613');
  ctx.fillStyle = grad;
  ctx.fillRect(-300, -300, WIDTH + 600, HEIGHT + 600);
  for (let index = 0; index < 21; index += 1) {
    const box = cell(index);
    ctx.fillStyle = '#100f0c';
    ctx.fillRect(box.x - 2, box.y - 2, box.w + 4, box.h + 5);
    if (index === 20) {
      ctx.save();
      clipRect(ctx, box.x, box.y, box.w, box.h);
      ctx.translate(box.x, box.y);
      ctx.scale(box.w / PANEL, box.h / PANEL);
      drawPressRoom(ctx, elapsed);
      ctx.restore();
    } else if (index === 19) {
      const height = box.w * HEIGHT / WIDTH;
      ctx.fillStyle = '#142330';
      ctx.fillRect(box.x, box.y, box.w, box.h);
      ctx.drawImage(editorFreeze, box.x, box.y + (box.h - height) / 2, box.w, height);
    } else {
      ctx.drawImage(thumbnails[index], box.x, box.y, box.w, box.h);
    }
    ctx.lineWidth = index === 20 ? 1.35 : 1.0;
    ctx.strokeStyle = index === 20 ? '#d9b97e' : '#907f5d';
    ctx.strokeRect(box.x, box.y, box.w, box.h);
  }
  ctx.restore();

  const first = fade(elapsed, 1.1, 1.62) * (1 - fade(elapsed, 3.15, 3.65));
  const last = fade(elapsed, 8.55, 9.05) * (1 - fade(elapsed, 11.05, 11.45));
  for (const [caption, alpha] of [['截至目前，人类共提交了 20 份答卷。', first], ['鹈鹕本人对此尚未发表评论。', last]]) {
    if (alpha <= 0) continue;
    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.shadowColor = '#090907';
    ctx.shadowBlur = 5;
    text(ctx, caption, WIDTH / 2, 818, {size: 38, weight: 600, align: 'center'});
    ctx.restore();
  }
}

function drawStudy(ctx) {
  ctx.fillStyle = '#eee8d8';
  ctx.fillRect(0, 0, WIDTH, HEIGHT);
  text(ctx, '同一姿势，三种画法', 75, 123, {color: '#292721', size: 58, weight: 700});
  text(ctx, '轮轴、踏板、座垫与握把对齐', 78, 175, {color: '#584c39', size: 27, font: SANS});
  for (const [column, index] of [0, 4, 18].entries()) {
    const scene = SCENES[index];
    const x = 77 + column * 486;
    ctx.fillStyle = scene.paper;
    ctx.fillRect(x, 234, 459, 526);
    ctx.strokeStyle = scene.ink;
    ctx.strokeRect(x + 12, 246, 435, 502);
    const pose = {x: x + 222, y: 622, scale: 0.90, tilt: 0, time: 0.25, phase: TAU * 0.25, wheelAngle: 0.63, gearRatio: GEAR_RATIO};
    const anchors = rigLandmarks(pose);
    line(ctx, [[x + 26, anchors.frontContact.y], [x + 433, anchors.frontContact.y]], scene.ink, 1.3);
    drawRider(ctx, pose, index);
    text(ctx, scene.zh, x + 28, 306, {color: '#1c211e', size: 39, weight: 700});
    text(ctx, scene.en, x + 29, 339, {color: '#242e22', size: 20, font: SANS});
  }
  text(ctx, '鹈鹕骑车六千年', 79, 823, {color: '#5d5443', size: 23, font: SANS});
}

export function createFilm(canvas) {
  const ctx = canvas.getContext('2d', {alpha: false});
  if (!ctx) throw new Error('Canvas 2D is unavailable');
  let thumbnails;
  let lastEditorView;
  function prepareFrame() {
    ctx.setTransform(canvas.width / WIDTH, 0, 0, canvas.height / HEIGHT, 0, 0);
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = 'source-over';
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
  }
  return Object.freeze({
    duration: DURATION,
    sceneStarts: SCENE_STARTS,
    labelAt(seconds) {
      return sceneAt(seconds)?.zh ?? (seconds < INTRO ? '序 · 图一' : '尾声 · 新闻发布会');
    },
    factsAt(seconds) {
      const pose = roadPose(seconds);
      const landmarks = rigLandmarks(pose);
      const contactError = [landmarks.rearContact, landmarks.frontContact].map(wheel => wheel.y + pose.lift - elevation(wheel.x));
      return {pose, camera: cameraAt(seconds, pose), landmarks, contactError, scene: sceneAt(seconds)?.id ?? null};
    },
    renderAt(seconds) {
      const time = clamp(Number.isFinite(seconds) ? seconds : 0, 0, MAX_TIME);
      prepareFrame();
      if (time >= OUTRO) {
        thumbnails ??= SCENES.map(scene => scene.index === 19 ? null : thumbnail(scene));
        if (!lastEditorView) {
          lastEditorView = surface(canvas.width, canvas.height);
          const bridge = lastEditorView.getContext('2d');
          bridge.scale(canvas.width / WIDTH, canvas.height / HEIGHT);
          drawRoadFilm(bridge, OUTRO - 1e-6);
        }
        drawGallery(ctx, time - OUTRO, thumbnails, lastEditorView);
      } else {
        drawRoadFilm(ctx, time);
      }
    },
    renderStudy() {
      prepareFrame();
      drawStudy(ctx);
    },
  });
}
