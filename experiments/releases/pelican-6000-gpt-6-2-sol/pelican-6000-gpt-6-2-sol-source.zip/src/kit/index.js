export const TAU = Math.PI * 2;
export const FONT = '"Noto Serif CJK SC", "Songti SC", SimSun, serif';
export const SANS = '"Microsoft YaHei", "PingFang SC", sans-serif';
export const clamp = (n, min = 0, max = 1) => Math.max(min, Math.min(max, n));
export const mix = (a, b, t) => a + (b - a) * t;

export function smooth(value) {
  const t = clamp(value);
  return t * t * t * (10 + t * (6 * t - 15));
}

export function fade(time, from, to) {
  return smooth((time - from) / (to - from));
}

export function line(ctx, points, color, width = 1) {
  ctx.beginPath();
  ctx.moveTo(...points[0]);
  for (const point of points.slice(1)) ctx.lineTo(...point);
  ctx.strokeStyle = color;
  ctx.lineWidth = width;
  ctx.stroke();
}

export function clipRect(ctx, x, y, width, height) {
  ctx.beginPath();
  ctx.rect(x, y, width, height);
  ctx.clip();
}

export function text(ctx, content, x, y, {size = 22, color = '#e9ddbc', align = 'left', font = FONT, weight = 400} = {}) {
  ctx.fillStyle = color;
  ctx.textAlign = align;
  ctx.textBaseline = 'alphabetic';
  ctx.font = `${weight} ${size}px ${font}`;
  ctx.fillText(content, x, y);
}

export function surface(width, height) {
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  return canvas;
}
