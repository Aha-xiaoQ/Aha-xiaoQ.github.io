import {INTRO, SCENES} from '../beat/index.js';
import {clamp, fade, line, mix, surface, TAU} from '../kit/index.js';
import {drawRider} from '../rig/index.js';
import {paintCodeRider} from '../scenes/full-code.js';

const local = (time, index) => time - SCENES[index].start;
const sceneCue = (t, a, b, c, d) => fade(t, a, b) * (1 - fade(t, c, d));

function hermite(t, a, b, from, to, incoming, outgoing) {
  const u = clamp((t - a) / (b - a));
  const u2 = u * u;
  const u3 = u2 * u;
  return from * (2 * u3 - 3 * u2 + 1) + incoming * (b - a) * (u3 - 2 * u2 + u)
    + to * (-2 * u3 + 3 * u2) + outgoing * (b - a) * (u3 - u2);
}

export function travelledTime(time) {
  const t = local(time, 1);
  if (t <= 1.19 || t >= 5.68) return time;
  const held = 2.17;
  const position = t < 2.12 ? hermite(t, 1.19, 2.12, 1.19, held, 1, 0)
    : t < 3.21 ? held : hermite(t, 3.21, 5.68, held, 5.68, 0, 1);
  return SCENES[1].start + position;
}

export function arcLift(time) {
  const t = local(time, 15);
  const u = clamp((t - 2.06) / 1.93);
  return u > 0 && u < 1 ? 136 * Math.sin(u * Math.PI) ** 1.23 : 0;
}

export function getPerformance(time, phase, scene) {
  const t = time - (scene?.start ?? 0);
  const holds = {
    sahara: [2.38, 2.87, 3.42, 3.94, .10], egypt: [1.65, 2.13, 3.26, 4.01, -.095],
    han: [2.02, 2.53, 3.54, 4, .085], tang: [2.02, 2.55, 3.51, 4.2, -.08],
    song: [2.58, 3.02, 3.55, 4.08, -.11], riverside: [1.8, 2.52, 3.4, 4, .09],
    maya: [2.12, 2.47, 3.31, 3.88, .13], mughal: [2.04, 2.66, 3.54, 4.04, -.10],
    bada: [1.81, 2.48, 3.51, 4, -.14], wayang: [1.82, 2.64, 3.42, 4.13, .12],
    ukiyo: [2.10, 2.77, 3.57, 4.32, -.06], starry: [2.07, 2.66, 3.49, 4.03, -.12],
    scream: [2.33, 2.68, 3.12, 3.56, .19], shadow: [2.22, 2.72, 3.54, 4.25, -.11],
    scope: [2.26, 2.60, 3.08, 3.4, .16], pixel: [1.41, 2.43, 3.58, 4.33, -.085],
    chat: [1.79, 2.42, 3.52, 4.18, .11], vapor: [2.01, 2.49, 3.09, 3.58, -.12],
    short: [2.31, 2.66, 3.11, 3.65, .11], code: [3.91, 4.33, 4.95, 5.53, .088],
  }[scene?.id];
  const cue = holds ? sceneCue(t, ...holds.slice(0, 4)) : 0;
  return {headAngle: mix(Math.sin(phase) * .015, holds?.[4] ?? 0, cue), lean: -.07 * cue, gaze: mix(.53, -.90, cue)};
}

export function scopeSignal(time) {
  return sceneCue(local(time, 14), 2.39, 2.63, 3.02, 3.39);
}

function signalRider(ctx, pose) {
  const signal = scopeSignal(pose.time);
  if (signal < 1) {
    ctx.save();
    ctx.globalAlpha *= 1 - signal;
    drawRider(ctx, pose, 14);
    ctx.restore();
  }
  if (signal === 0) return;
  ctx.save();
  ctx.translate(pose.x + 5, pose.y - pose.scale * 85);
  ctx.scale(pose.scale, pose.scale);
  ctx.globalCompositeOperation = 'lighter';
  ctx.globalAlpha *= signal;
  const wave = pose.time * 11.2;
  const field = [];
  for (let j = 0; j <= 160; j += 1) {
    const f = j / 160 * TAU;
    field.push([161 * Math.sin(f * 3 + wave), 135 * Math.sin(f * 2 + .21 * Math.sin(wave))]);
  }
  ctx.shadowBlur = 13;
  ctx.shadowColor = '#57ffa9';
  line(ctx, field, '#3d9f735b', 11);
  line(ctx, field, '#78ffac', 3.5);
  line(ctx, field, '#f0ffe1', 1.1);
  ctx.restore();
}

let sprite;
let spriteKey;
function retroRaster(ctx, pose, medium) {
  const pixel = medium === 15;
  const updates = pixel ? 10 : 8;
  const tick = Math.floor((pose.time - INTRO) * updates);
  const time = INTRO + tick / updates;
  const tact = TAU * tick / updates;
  const wheelAngle = Math.round(1e7 * (pose.wheelAngle + (time - pose.time) * TAU * pose.gearRatio)) / 1e7;
  const key = `${medium}:${tick}:${wheelAngle}`;
  sprite ??= surface(130, 114);
  if (spriteKey !== key) {
    const pc = sprite.getContext('2d', {willReadFrequently: true});
    pc.setTransform(1, 0, 0, 1, 0, 0);
    pc.clearRect(0, 0, 130, 114);
    pc.setTransform(.268, 0, 0, .268, 64, 83);
    const acting = getPerformance(time, tact, SCENES[medium]);
    drawRider(pc, {...pose, ...acting, time, phase: tact, wheelAngle, x: 0, y: 0, scale: 1, tilt: 0}, medium);
    const raster = pc.getImageData(0, 0, 130, 114);
    for (let index = 0; index < raster.data.length; index += 4) {
      const pos = index / 4;
      if (raster.data[index + 3] < (pixel ? 102 : 61)) raster.data[index + 3] = 0;
      else if (pixel) raster.data[index + 3] = 255;
      const dither = !pixel && ((pos + Math.floor(pos / 130)) % 2) ? 6 : 0;
      for (let c = index; c < index + 3; c += 1) {
        raster.data[c] = Math.round(clamp(raster.data[c] + dither, 0, 255) / (pixel ? 34 : 18)) * (pixel ? 34 : 18);
      }
    }
    pc.putImageData(raster, 0, 0);
    spriteKey = key;
  }
  ctx.save();
  ctx.translate(pose.x, pose.y);
  ctx.rotate(pose.tilt);
  ctx.scale(pose.scale / .268, pose.scale / .268);
  ctx.imageSmoothingEnabled = false;
  ctx.drawImage(sprite, -64, -83);
  ctx.restore();
}

export function paintSceneRider(ctx, pose, index, chapterTime) {
  if (index === 13) {
    const approach = fade(pose.time, 88.24, 89);
    const merge = fade(pose.time, 88.91, 89);
    const shadowPose = {...pose, y: pose.y - 11 * (1 - approach), scale: pose.scale * (1 + .23 * (1 - approach))};
    ctx.save();
    ctx.globalAlpha *= (1 - merge) * .88;
    drawRider(ctx, shadowPose, 13);
    ctx.restore();
    if (merge > 0) {
      ctx.save();
      ctx.globalAlpha *= merge;
      drawRider(ctx, shadowPose, 14);
      ctx.restore();
    }
  } else if (index === 14) signalRider(ctx, pose);
  else if (index === 15 || index === 16) retroRaster(ctx, pose, index);
  else if (index === 19) paintCodeRider(ctx, pose, chapterTime);
  else if (index === 9) {
    const hold = Math.floor(chapterTime * 10) / 10 - chapterTime;
    drawRider(ctx, {...pose, phase: pose.phase + hold * TAU, wheelAngle: pose.wheelAngle + hold * TAU * pose.gearRatio}, index);
  } else drawRider(ctx, pose, index);
}
