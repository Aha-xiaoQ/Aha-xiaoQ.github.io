import { bike, landmarks, localPose, TAU, traceChain } from './geometry.js';
import { treatmentFor } from './plates.js';

const commands = new Map();
const staticPaths = new Map();

function staticPath(data) {
  if (!staticPaths.has(data)) staticPaths.set(data, new Path2D(data));
  return staticPaths.get(data);
}

function posedPath(data, map) {
  if (!commands.has(data)) {
    commands.set(data, data.split(/ +(?=[MCLQZ](?:$| ))/g).map(part => {
      const [operation, ...args] = part.split(' ');
      return { operation, args: args.map(Number) };
    }));
  }

  const path = new Path2D();
  for (const { operation, args } of commands.get(data)) {
    const coords = [];
    for (let index = 0; index < args.length; index += 2) {
      coords.push(...map(args[index], args[index + 1]));
    }
    switch (operation) {
      case 'M': path.moveTo(...coords); break;
      case 'L': path.lineTo(...coords); break;
      case 'C': path.bezierCurveTo(...coords); break;
      case 'Q': path.quadraticCurveTo(...coords); break;
      case 'Z': path.closePath(); break;
    }
  }
  return path;
}

function paint(ctx, path, fill, stroke, width = 1) {
  if (fill) {
    ctx.fillStyle = fill;
    ctx.fill(path);
  }
  if (stroke) {
    ctx.strokeStyle = stroke;
    ctx.lineWidth = width;
    ctx.stroke(path);
  }
}

function line(ctx, points, color, width) {
  ctx.beginPath();
  ctx.moveTo(...points[0]);
  for (const point of points.slice(1)) ctx.lineTo(...point);
  ctx.strokeStyle = color;
  ctx.lineWidth = width;
  ctx.stroke();
}

function circle(ctx, x, y, radius, fill, stroke, width = 1) {
  const path = new Path2D();
  path.arc(x, y, radius, 0, TAU);
  paint(ctx, path, fill, stroke, width);
}

function gradient(ctx, start, end, stops) {
  const fill = ctx.createLinearGradient(...start, ...end);
  for (const [offset, color] of stops) fill.addColorStop(offset, color);
  return fill;
}

function isOutline(plate) {
  return plate.medium === 'scope';
}

function bikeWheel(ctx, center, angle, plate) {
  const { rimWeight, tire, hubRadius, ink, metal, spokes, medium, accent } = plate;
  const rimCenter = bike.radius - rimWeight / 2;
  const outline = isOutline(plate);
  ctx.save();
  ctx.translate(...center);
  circle(ctx, 0, 0, rimCenter, null, tire, rimWeight);
  if (medium === 'vertical') {
    circle(ctx, 0, 0, rimCenter - 3, null, '#cca073', 2.65);
    circle(ctx, 0, 0, rimCenter - 6.3, null, '#5d7671', 3.8);
    circle(ctx, 0, 0, rimCenter - 6.3, null, '#a7b6a5', .8);
  } else if (!['ochre', 'shadow'].includes(medium)) {
    circle(ctx, 0, 0, rimCenter - 6, null, metal, 1.3);
  }

  ctx.rotate(angle);
  const chippedSpokes = medium === 'ochre' ? [0, -.14, .19, -.08] : [];
  for (let index = 0; index < spokes; index++) {
    const theta = index * TAU / spokes + (chippedSpokes[index] ?? 0);
    const inner = theta + (medium === 'vertical' ? (index % 2 ? -.42 : .42) : 0);
    const innerRadius = hubRadius - 2;
    const shortSpoke = center === bike.front && index === Math.min(3, spokes - 1);
    const outerRadius = rimCenter - (shortSpoke ? 3 : 2);
    const spokeWidth = medium === 'ochre' ? 4.6 : medium === 'shadow' ? 2.4 : 1.4;
    line(ctx, [
      [Math.cos(inner) * innerRadius, Math.sin(inner) * innerRadius],
      [Math.cos(theta) * (outerRadius - (medium === 'vertical' ? 4.6 : 0)), Math.sin(theta) * (outerRadius - (medium === 'vertical' ? 4.6 : 0))],
    ], medium === 'vertical' ? (index % 2 ? '#bac1ad' : '#63837c') : ink, spokeWidth);
  }

  // A valve and contrasting marks make wheel phases visible at common speeds.
  if (medium !== 'shadow' && !outline) {
    const valve = medium === 'ochre' ? -.98 : .43;
    line(ctx, [
      [Math.cos(valve) * (rimCenter - 9), Math.sin(valve) * (rimCenter - 9)],
      [Math.cos(valve) * (rimCenter - 1), Math.sin(valve) * (rimCenter - 1)],
    ], accent, medium === 'ochre' ? 3.6 : 2.4);
  }
  if (medium === 'ochre' || medium === 'ink') {
    ctx.save();
    ctx.globalAlpha *= medium === 'ochre' ? .67 : .57;
    ctx.beginPath();
    ctx.arc(0, 0, rimCenter, -.7, .5);
    ctx.setLineDash(medium === 'ochre' ? [1.8, 3.4, 7.8, 5.5] : [7, 3, 2, 4]);
    ctx.strokeStyle = medium === 'ochre' ? accent : plate.wash;
    ctx.lineWidth = 1.7;
    ctx.stroke();
    ctx.restore();
  }
  if (medium === 'ochre') {
    // Oxide remains concentrated around shallow incisions; each ring is made
    // from asymmetric hand marks rather than identical stamped geometry.
    const seed = center === bike.front ? 17 : 73;
    for (let j = 0; j < 51; j++) {
      const angle = (j * 97 + seed) % 239 / 239 * TAU;
      const radius = rimCenter + ((j * 19 + seed) % 13 - 6) * .49;
      ctx.fillStyle = j % 3 ? '#aa5932' : '#d18348';
      ctx.fillRect(radius * Math.cos(angle), radius * Math.sin(angle), j % 6 ? 1.6 : 2.8, .95);
    }
  }
  if (medium === 'vertical' && center === bike.front) {
    circle(ctx, 0, 0, 16.8, null, '#9eaea1', 2.1);
    circle(ctx, 0, 0, 13.6, null, '#667772', 1.6);
    for (let j = 0; j < 6; j++) {
      const theta = j * TAU / 6;
      line(ctx, [[Math.cos(theta) * 8, Math.sin(theta) * 8], [Math.cos(theta + .28) * 15, Math.sin(theta + .28) * 15]], '#819b91', 2.3);
    }
  }
  circle(ctx, 0, 0, hubRadius, outline ? null : metal, ink, outline ? 1 : 2.3);
  circle(ctx, 0, 0, hubRadius * .37, outline ? null : ink, ink, 1.3);
  ctx.restore();
}

function bikeFrame(ctx, plate) {
  const { medium, ink, tubeWidth, metal, accent, tip } = plate;
  const outline = isOutline(plate);
  const frame = staticPath(plate.frame);
  paint(ctx, frame, null, ink, tubeWidth);
  if (medium === 'vertical') {
    const enamel = gradient(ctx, [-72, -107], [-64, 15], [[0, '#a8c7a8'], [.24, '#438879'], [.63, accent], [1, '#243a34']]);
    paint(ctx, frame, null, enamel, tubeWidth * .73);
    paint(ctx, staticPath('M -61 -89 C -12 -88 45 -73 88 -81 M 87 -68 Q 36 -23 6 -5 M 101 -75 Q 100 -26 131 5'), null, '#a0bda8', 1.35);
    paint(ctx, staticPath('M 68 -79 L 74 -82 L 80 -80 L 74 -77 Z'), '#efc789', null);
    circle(ctx, 97, -83, 6.2, accent, ink, 1.35);
  } else if (medium !== 'shadow' && !outline) {
    paint(ctx, frame, null, medium === 'vertical' ? accent : metal, tubeWidth * .48);
  }

  const seat = staticPath(medium === 'vertical'
    ? 'M -99 -113 Q -88 -117 -74 -113 Q -66 -110 -48 -112 Q -36 -111 -39 -104 Q -44 -97 -65 -100 L -91 -103 Q -101 -106 -99 -113 Z'
    : 'M -91 -111 Q -74 -113 -49 -111 Q -42 -109 -50 -104 L -84 -104 Q -91 -106 -91 -111 Z');
  line(ctx, [[-65, -91], bike.seat], ink, outline ? 1.8 : 5);
  paint(ctx, seat, outline ? null : ink, ink, outline ? 1.35 : 1.8);
  if (medium === 'vertical') {
    paint(ctx, staticPath('M -92 -107 Q -71 -103 -51 -105'), null, '#c98362', 2.05);
    // Half fenders keep the fast wheel profile visible. The little waxed
    // pannier hangs on the rear rack in the same vehicle coordinates.
    const fenders = staticPath('M -211 17 A 81 81 0 0 1 -69 -27 M 88 -26 A 81 81 0 0 1 222 -12');
    paint(ctx, fenders, null, ink, 5.1);
    paint(ctx, fenders, null, '#879e91', 2.1);
    paint(ctx, staticPath('M -191 -66 L -113 -66 M -169 -65 L -130 25 M -117 -66 L -130 25 M 212 -19 L 150 25'), null, '#314c43', 2.4);
    const pannier = staticPath('M -178 -70 Q -175 -80 -161 -81 L -140 -79 Q -132 -76 -134 -67 L -139 -45 Q -148 -38 -173 -44 Q -179 -47 -178 -70 Z');
    paint(ctx, pannier, gradient(ctx, [-170, -79], [-157, -40], [[0, '#bf986a'], [.62, '#7e5339'], [1, '#543a2e']]), ink, 1.5);
    paint(ctx, staticPath('M -175 -69 Q -163 -66 -136 -67 M -165 -77 L -166 -48 M -146 -77 L -151 -47'), null, '#d1b180', 1.35);
    paint(ctx, staticPath('M 119 -40 Q 134 -41 134 -34 L 132 -30 L 116 -30 Z'), '#f0c37d', ink, 2);
  }

  const handlebar = staticPath(medium === 'ochre'
    ? 'M 93 -79 L 99 -123 L 113 -130 L 137 -130'
    : medium === 'vertical'
    ? 'M 97 -84 Q 99 -102 101 -119 L 113 -130 Q 125 -133 141 -128 C 150 -125 150 -117 147 -110 C 144 -103 137 -101 130 -104'
    : 'M 95 -81 Q 99 -104 100 -120 Q 101 -130 113 -130 L 136 -130 Q 144 -129 145 -119 Q 145 -113 139 -111');
  paint(ctx, handlebar, null, ink, outline ? 1.8 : medium === 'ochre' ? 5.8 : 6);
  if (medium === 'vertical') {
    paint(ctx, staticPath('M 113 -130 Q 125 -133 141 -128 C 150 -125 150 -117 147 -110 C 144 -103 137 -101 130 -104'), null, tip, 8.2);
    paint(ctx, staticPath('M 137 -130 Q 145 -133 150 -127 M 142 -123 Q 143 -115 136 -111'), null, '#b3c0a7', 1.55);
    circle(ctx, 124, -138, 7.2, '#e2ad59', ink, 2);
    paint(ctx, staticPath('M 126 -143 Q 130 -142 129 -138'), null, '#ffde8f', 1.8);
  } else if (medium !== 'shadow' && !outline && medium !== 'ochre') {
    circle(ctx, 124, -136, 4.7, plate.upperBill, ink, 1.65);
  }
}

function sprocket(ctx, center, radius, angle, teeth, plate) {
  const isDetailed = plate.medium === 'vertical' || plate.medium === 'engraving';
  if (!isDetailed) {
    circle(ctx, ...center, radius - 1, null, plate.ink, 1.6);
    circle(ctx, ...center, 3.0, plate.ink);
    return;
  }
  const path = new Path2D();
  for (let index = 0; index < teeth * 4; index++) {
    const r = radius + (index % 4 === 1 || index % 4 === 2 ? .8 : -1.4);
    const theta = angle + TAU * index / (teeth * 4);
    const x = center[0] + Math.cos(theta) * r;
    const y = center[1] + Math.sin(theta) * r;
    if (index === 0) path.moveTo(x, y);
    else path.lineTo(x, y);
  }
  path.closePath();
  if (plate.medium === 'vertical') {
    const holes = radius > 21 ? 7 : 4;
    const holeR = radius * .145;
    for (let index = 0; index < holes; index++) {
      const theta = angle + index * TAU / holes;
      const dx = center[0] + Math.cos(theta) * radius * .56;
      const dy = center[1] + Math.sin(theta) * radius * .56;
      path.moveTo(dx + Math.cos(theta + 1.1) * holeR * 1.38, dy + Math.sin(theta + 1.1) * holeR * 1.38);
      path.ellipse(dx, dy, holeR * 1.38, holeR, theta + 1.1, 0, TAU);
      path.closePath();
    }
    const face = gradient(ctx, [center[0] - radius, center[1] - radius], [center[0] + radius, center[1] + radius], [[0, '#89988a'], [.38, '#c1be9e'], [1, '#667a70']]);
    ctx.fillStyle = face;
    ctx.fill(path, 'evenodd');
    paint(ctx, path, null, plate.ink, 1.4);
    circle(ctx, ...center, radius * .30, '#687e71', plate.ink, 1.4);
    circle(ctx, ...center, 4.5, '#c1b794', plate.ink, 1.25);
    return;
  }
  paint(ctx, path, plate.metal, plate.ink, 1.6);
  const innerRadius = radius - 5;
  circle(ctx, ...center, innerRadius, null, plate.ink, 1.3);
  for (let index = 0; index < 5; index++) {
    const theta = angle + index * TAU / 5;
    line(ctx, [center, [center[0] + Math.cos(theta) * innerRadius, center[1] + Math.sin(theta) * innerRadius]], plate.ink, 1.15);
  }
}

function transmission(ctx, pose, plate) {
  const { chainringRadius, chainringTeeth } = bike;
  const { rearRadius, rearTeeth } = pose.drive;
  const outline = isOutline(plate);
  ctx.save();
  sprocket(ctx, bike.rear, rearRadius, pose.sprocketAngle, rearTeeth, plate);
  sprocket(ctx, [0, 0], chainringRadius, pose.phase, chainringTeeth, plate);
  traceChain(ctx, pose.drive);
  ctx.strokeStyle = plate.ink;
  ctx.lineWidth = outline ? 1.2 : 2.45;
  ctx.stroke();
  if (plate.medium !== 'shadow' && plate.medium !== 'ochre' && !outline) {
    const pitch = TAU * chainringRadius / chainringTeeth;
    ctx.setLineDash([pitch * .3, pitch * .7]);
    ctx.lineDashOffset = -pose.phase * chainringRadius;
    ctx.strokeStyle = plate.upperBill;
    ctx.lineWidth = 1.2;
    ctx.stroke();
  }
  ctx.restore();
}

function leg(ctx, solved, plate, far) {
  const { hip, knee, pedal } = solved;
  const [x, y] = pedal;
  const outline = isOutline(plate);
  const colored = far ? plate.farLeg : plate.nearLeg;
  ctx.save();
  if (far) ctx.globalAlpha *= .78;

  line(ctx, [[0, 0], pedal], far ? plate.metal : plate.ink, outline ? 1.25 : 4);
  const taperedProfile = Boolean(plate.gripFeather);
  const shin = [knee, [x - 4, y - 3]];
  if (taperedProfile) {
    line(ctx, [hip, knee], plate.ink, plate.medium === 'vertical' ? 12 : 6.5);
    line(ctx, shin, plate.ink, plate.medium === 'vertical' ? 8.1 : 5.5);
  } else {
    line(ctx, [hip, ...shin], plate.ink, outline ? 1.75 : 8.9);
  }
  if (!outline && plate.medium !== 'shadow') {
    line(ctx, [hip, ...shin], colored, plate.medium === 'ink' ? 2.6 : 5.45);
    if (plate.medium === 'vertical') {
      const [kx, ky] = knee;
      for (const fraction of [.67, .77, .87]) {
        const mx = kx + (x - 4 - kx) * fraction;
        const my = ky + (y - 3 - ky) * fraction;
        line(ctx, [[mx - 1.8, my], [mx + 2, my - .5]], '#9d694b', 1.1);
      }
    }
  }
  circle(ctx, x, y, outline ? 2 : 3, outline ? null : plate.ink, plate.ink, 1.25);

  ctx.translate(x, y);
  const foot = staticPath(taperedProfile
    ? 'M -8 -7 Q -9 -3 -12 -1 L -8 2 L -1 1 L 5 3 L 13 2 L 18 1 L 20 -2 L 13 -3 L 16 -5 L 11 -6 L 6 -5 L 2 -6 Z'
    : 'M -7 -6 Q -11 -2 -7 3 L 13 3 L 16 1 L 9 -2 L 12 -4 L 3 -5 L -7 -6 Z');
  paint(ctx, foot, outline ? null : colored, plate.ink, outline ? 1.1 : 1.5);
  line(ctx, [[-10, 4.5], [17, 4.5]], plate.ink, outline ? 1.4 : 3.4);
  if (plate.medium === 'vertical') {
    line(ctx, [[1, -3], [4, 1]], plate.ink, 1.15);
    line(ctx, [[6, -3], [8, 1]], plate.ink, 1.15);
  }
  ctx.restore();
}

function engravingWash(ctx, clip, plate) {
  ctx.save();
  ctx.clip(clip);
  ctx.globalAlpha *= .78;
  ctx.fillStyle = gradient(ctx, [-48, -238], [-31, -112], [[0, plate.feather], [.47, plate.feather], [1, plate.wash]]);
  ctx.fillRect(-182, -316, 285, 217);
  ctx.restore();
}

function mineralGrain(ctx, body, plate) {
  ctx.save();
  ctx.clip(body);
  const opacity = ctx.globalAlpha;
  // Slightly different coppery deposits on either side of the incisions.
  // The irregular field stays put in body space through stance changes.
  for (let index = 0; index < 380; index++) {
    const u = ((index * 313 + index % 7 * 43) % 503) / 503;
    const v = ((index * 227 + index % 11 * 101) % 433) / 433;
    const patch = Math.sin(u * 19 + v * 13) + Math.cos(v * 29 - u * 6);
    const size = .5 + (index * 103 % 19) / 10 + Math.max(0, patch) * .56;
    ctx.globalAlpha = opacity * (index % 6 === 0 ? .58 : .25);
    ctx.fillStyle = index % 3 === 0 ? plate.wash : plate.accent;
    ctx.fillRect(-187 + u * 287, -301 + v * 194, size + 1.14, size);
  }
  ctx.restore();
}

function ochrePelican(ctx, pose, plate, paths) {
  ctx.save();
  ctx.globalAlpha *= .9;
  const pigment = gradient(ctx, [-118, -223], [26, -136], [[0, '#cc7445'], [.37, plate.feather], [1, '#8c2e17']]);
  paint(ctx, paths.grip, '#8d351d', plate.ink, 1.2);
  paint(ctx, paths.body, pigment, null);
  const wornEdge = 'M -183 -143 L -168 -148 Q -147 -172 -136 -183 Q -112 -205 -92 -207 M 14 -252 L 19 -272 L 34 -283 L 49 -280 M -91 -113 L -70 -112 L -44 -120 Q -1 -138 21 -160';
  paint(ctx, posedPath(wornEdge, pose.bodyPoint), null, '#63250f', 2);
  paint(ctx, paths.wing, '#a34d2b', null);
  mineralGrain(ctx, paths.body, plate);
  paint(ctx, paths.wingAccent, null, '#672714', 3.9);
  const incision = 'M -135 -167 Q -92 -166 -54 -150 M -123 -177 Q -94 -178 -59 -160 M -110 -188 Q -82 -185 -56 -172';
  paint(ctx, posedPath(incision, pose.wingPoint), null, '#d88a57', 1.1);
  paint(ctx, paths.pouch, '#bc7442', '#8c4123', 1.2);
  paint(ctx, paths.bill, plate.upperBill, '#652916', 1.65);
  paint(ctx, posedPath('M 73 -251 Q 114 -252 152 -244', pose.bodyPoint), null, '#e2a263', 1.4);
  ctx.restore();
}

function inkPelican(ctx, pose, plate, paths) {
  if (plate.whiteEye) {
    paint(ctx, paths.grip, '#393e32', null);
    paint(ctx, paths.body, gradient(ctx, [-77, -287], [-57, -104], [[0, '#34392e'], [.54, '#53564a'], [1, '#242922']]), null);
    paint(ctx, paths.wing, '#353d35', null);
    paint(ctx, paths.wingAccent, null, '#878774', 2.4);
    paint(ctx, paths.pouch, '#a8a08a', null);
    paint(ctx, paths.bill, '#6c6a56', '#32362b', 2.7);
    return;
  }
  paint(ctx, paths.grip, '#9b997a', '#687661', 1.1);
  const wash = gradient(ctx, [-33, -250], [-52, -119], [[0, '#f0e8cc'], [.47, '#e5dbc0'], [.8, '#b5b79a'], [1, '#768771']]);
  paint(ctx, paths.body, wash, null);
  paint(ctx, paths.wing, gradient(ctx, [-97, -195], [-70, -127], [[0, '#eddfba'], [.52, '#d4d0ad'], [1, '#7d8b74']]), null);

  // Separate brush strokes leave air between the crest, tail and upper wing.
  // The wash fills the body, while dark ink is reserved for directional marks.
  const bodyInk = 'M -185 -135 Q -166 -146 -153 -167 C -132 -188 -106 -205 -77 -206 Q -57 -206 -41 -201 M -18 -191 Q 5 -197 17 -232 M 16 -256 C 8 -281 40 -299 59 -288 Q 74 -284 79 -268 M 56 -226 Q 64 -201 43 -172 C 20 -139 -17 -117 -69 -112';
  paint(ctx, posedPath(bodyInk, pose.bodyPoint), null, '#465b4b', 2.45);
  paint(ctx, posedPath('M -176 -136 Q -153 -141 -141 -146 M -142 -145 Q -112 -129 -87 -133 Q -56 -127 -39 -134 M -147 -154 Q -131 -155 -119 -156 Q -138 -160 -154 -158', pose.wingPoint), null, '#35483d', 3.35);
  paint(ctx, paths.wingAccent, null, '#6a795f', 2.3);
  ctx.save();
  ctx.globalAlpha *= .38;
  ctx.setLineDash([4.3, 1.8, 2.1, 3.6]);
  paint(ctx, posedPath('M -135 -172 Q -99 -184 -64 -165 M -123 -146 Q -94 -144 -76 -142 M -116 -128 Q -96 -121 -78 -121', pose.wingPoint), null, '#405445', 1.18);
  ctx.restore();
  paint(ctx, paths.pouch, plate.pouch, null);
  paint(ctx, posedPath('M 58 -240 Q 67 -211 92 -212 C 125 -210 160 -220 188 -234', pose.bodyPoint), null, '#866e52', 1.55);
  paint(ctx, paths.bill, plate.upperBill, '#655d43', 1.48);
  paint(ctx, posedPath('M 73 -253 C 104 -255 131 -251 151 -249', pose.bodyPoint), null, '#ebe0ba', 1.5);
}

function sculptedPelican(ctx, pose, plate, paths) {
  const light = '#fff6e1';
  const reflected = '#7dbab0';
  const cool = '#6b968d';
  const darkWing = '#35544d';
  const anatomicalWash = gradient(ctx, [-82, -275], [35, -112], [[0, '#fff6dd'], [.33, '#f9edd8'], [.69, '#dfd9c7'], [.88, '#aabcb0'], [1, '#679b91']]);
  const gripShade = gradient(ctx, [41, -165], [69, -125], [[0, '#e6dfc7'], [.56, '#aabda9'], [1, '#4e8076']]);
  paint(ctx, paths.grip, gripShade, '#58796a', 1.75);
  paint(ctx, paths.body, anatomicalWash, '#869e88', 1.45);

  const neckPlane = 'M 24 -264 Q 19 -250 25 -237 C 35 -223 37 -200 19 -173 Q 1 -143 -44 -131 Q -12 -126 17 -140 Q 53 -158 58 -188 Q 64 -216 53 -230 L 47 -238 Q 32 -246 24 -264 Z';
  const bounce = gradient(ctx, [35, -256], [-12, -123], [[0, 'rgba(236,216,178,.44)'], [.34, 'rgba(160,184,160,.41)'], [1, 'rgba(64,129,115,.7)']]);
  paint(ctx, posedPath(neckPlane, pose.bodyPoint), bounce, null);
  const litEdge = 'M -159 -158 C -136 -191 -109 -203 -82 -209 Q -56 -211 -34 -202 M 1 -201 Q 18 -211 22 -234 M 25 -267 Q 33 -288 51 -287 Q 65 -285 74 -275';
  paint(ctx, posedPath(litEdge, pose.bodyPoint), null, light, 2.7);
  const underbelly = 'M -141 -132 Q -110 -113 -72 -115 C -40 -113 -22 -120 -10 -125 M 11 -130 Q 37 -146 50 -161';
  paint(ctx, posedPath(underbelly, pose.bodyPoint), null, reflected, 2.5);

  const wingShade = gradient(ctx, [-79, -201], [-69, -129], [[0, '#f9ead0'], [.36, '#d9d3bc'], [.64, '#a2b2a0'], [.82, '#6d9589'], [1, '#4e776b']]);
  paint(ctx, paths.wing, wingShade, '#617c6e', 1.5);
  ctx.save();
  ctx.clip(paths.wing);
  const foldedPrimaries = 'M -168 -164 Q -113 -169 -87 -147 Q -69 -136 -38 -135 L -41 -128 L -107 -129 L -157 -140 Z';
  paint(ctx, posedPath(foldedPrimaries, pose.wingPoint), gradient(ctx, [-108, -165], [-90, -135], [[0, '#5c7462'], [.56, darkWing], [1, '#203c38']]), null);
  for (let index = 0; index < 7; index++) {
    const y = -173 + index * 4.4;
    const feather = `M ${-126 + index * 6} ${y} Q ${-98 + index * 4} ${y - 8.3} ${-78 + index * 5.1} ${y + 5.7} Q ${-56 + index * 4} ${y + 17.2} ${-37 + index * 4.6} ${y + 12.9}`;
    paint(ctx, posedPath(feather, pose.wingPoint), null, index < 3 ? '#fff2d6' : cool, index < 3 ? 1.75 : 1.4);
  }
  ctx.restore();
  paint(ctx, paths.wingAccent, null, '#efe4ca', 1.22);

  const fleshy = gradient(ctx, pose.bodyPoint(103, -248), pose.bodyPoint(112, -211), [[0, '#c96c46'], [.24, '#dd8254'], [.58, '#eb9c6d'], [1, '#da8c54']]);
  const ivoryBill = gradient(ctx, pose.bodyPoint(124, -260), pose.bodyPoint(123, -235), [[0, '#ffdda0'], [.24, '#ffc873'], [.59, '#e9a75c'], [1, '#c57847']]);
  paint(ctx, paths.pouch, fleshy, '#ab684b', 1.1);
  paint(ctx, posedPath('M 73 -224 Q 90 -215 114 -216 C 147 -220 165 -228 180 -233', pose.bodyPoint), null, '#f7b885', 1.5);
  paint(ctx, paths.bill, ivoryBill, '#936043', 1.15);
  const glint = 'M 73 -253 Q 96 -258 120 -254 M 151 -250 Q 174 -248 185 -245';
  paint(ctx, posedPath(glint, pose.bodyPoint), null, '#ffe5ae', 1.32);
  paint(ctx, posedPath('M 83 -249 Q 87 -250 92 -248 M 190 -236 Q 196 -238 199 -240', pose.bodyPoint), null, '#82503b', 1.3);
}

function pelicanEye(ctx, pose, plate) {
  if (plate.medium === 'shadow') return;
  const [x, y] = pose.bodyPoint(plate.gripFeather ? 54 : 50, -259);
  if (plate.whiteEye) {
    circle(ctx, x, y, 9, '#eeead4', '#a39a82', 1.25);
    circle(ctx, x + 2.1, y + pose.gaze * 5, 3.54, '#282b23');
    return;
  }
  if (plate.medium === 'ochre' || plate.medium === 'ink') {
    circle(ctx, x, y, plate.medium === 'ochre' ? 3.7 : 3.3, plate.ink);
    circle(ctx, x - .6, y - .75, 1.02, plate.medium === 'ochre' ? '#e7b379' : '#f5e9ca');
    return;
  }
  const adult = plate.medium === 'vertical';
  const baseRadius = adult ? 6.3 : 5.7;
  const blinkCycle = (pose.time + .21) % 4.9;
  const blink = Math.min(1, Math.abs(blinkCycle - 2.7) / .094);
  const outline = isOutline(plate);
  const opening = new Path2D();
  opening.ellipse(x, y, baseRadius, Math.max(.6, baseRadius * blink * (adult ? .81 : 1)), 0, 0, TAU);
  paint(ctx, opening, outline ? null : adult ? '#dfb77f' : '#fff4dd', plate.ink, adult ? 1.5 : 1.7);
  if (outline) return;

  ctx.save();
  ctx.clip(opening);
  const irisX = x + pose.gaze * (baseRadius * .31);
  circle(ctx, irisX, y + baseRadius * .04, baseRadius * .59, adult ? '#8e6540' : plate.tip);
  circle(ctx, irisX + .24, y, baseRadius * .38, plate.ink);
  circle(ctx, irisX - baseRadius * .15, y - baseRadius * .22, baseRadius * .20, '#fff9ee');
  ctx.restore();
}

function bird(ctx, pose, plate) {
  const { medium, ink, feather, tip, upperBill, pouch } = plate;
  const outline = isOutline(plate);
  if (plate.gripFeather) {
    const paths = {
      grip: posedPath(plate.gripFeather, pose.wingPoint),
      body: posedPath(plate.body, pose.bodyPoint),
      wing: posedPath(plate.wing, pose.wingPoint),
      wingAccent: posedPath(plate.wingAccent, pose.wingPoint),
      bill: posedPath(plate.bill, pose.bodyPoint),
      pouch: posedPath(plate.billPouch, pose.bodyPoint),
    };
    if (medium === 'ochre') ochrePelican(ctx, pose, plate, paths);
    else if (medium === 'ink') inkPelican(ctx, pose, plate, paths);
    else sculptedPelican(ctx, pose, plate, paths);
    pelicanEye(ctx, pose, plate);
    return;
  }

  const strokeWidth = 1.9;
  const body = posedPath(plate.body, pose.bodyPoint);
  paint(ctx, body, outline ? null : feather, null);
  if (!outline && medium !== 'shadow') engravingWash(ctx, body, plate);
  paint(ctx, body, null, ink, strokeWidth);

  const wing = posedPath(plate.wing, pose.wingPoint);
  paint(ctx, wing, outline ? null : feather, ink, strokeWidth * .92);
  if (medium === 'wayang') {
    const embroidery = 'M -115 -178 Q -91 -188 -61 -172 Q -34 -150 29 -136 M -98 -166 Q -63 -155 -47 -146 M 13 -219 Q 36 -232 55 -225 M 6 -205 Q 32 -207 46 -203';
    paint(ctx, posedPath(embroidery, pose.bodyPoint), null, plate.accent, 2.8);
  }
  if (medium !== 'shadow' && !outline) {
    paint(ctx, posedPath(plate.wingAccent, pose.wingPoint), null, tip, 1.7);
  }

  paint(ctx, posedPath(plate.billPouch, pose.bodyPoint), outline ? null : pouch, ink, strokeWidth * .8);
  paint(ctx, posedPath(plate.bill, pose.bodyPoint), outline ? null : upperBill, ink, strokeWidth * .8);
  if (!outline && medium !== 'shadow') {
    const highlight = 'M 78 -254 Q 101 -257 118 -253 M 172 -244 Q 180 -242 186 -242';
    paint(ctx, posedPath(highlight, pose.bodyPoint), null, '#e0c294', 1.65);
    const nostril = 'M 95 -253 Q 98 -254 102 -253';
    paint(ctx, posedPath(nostril, pose.bodyPoint), null, ink, 1.2);
  }
  pelicanEye(ctx, pose, plate);
}

export function rigLandmarks(pose) {
  return landmarks(localPose(pose));
}

export function drawRider(ctx, pose, style) {
  const local = localPose(pose);
  const plate = treatmentFor(style);
  ctx.save();
  try {
    ctx.translate(local.x, local.y);
    ctx.rotate(local.tilt);
    ctx.scale(local.scale, local.scale);
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.setLineDash([]);
    if (isOutline(plate)) {
      ctx.shadowBlur = 4.5;
      ctx.shadowColor = '#78ffb2';
    }
    if (plate.medium === 'wayang') {
      const leather = new Path2D();
      leather.rect(-260, -350, 575, 550);
      for (const [x, y, radius] of [[-120,-169,4],[-105,-166,5],[-88,-159,5],[-70,-151,4],[-51,-144,3],[-89,-181,3.5],[-70,-178,3],[-52,-168,3],[-28,-157,3.5],[25,-210,4],[36,-223,3],[42,-234,2.5]]) {
        const [px, py] = local.bodyPoint(x, y);
        leather.moveTo(px + radius, py);
        leather.arc(px, py, radius, 0, TAU);
      }
      ctx.clip(leather, 'evenodd');
    }

    bikeWheel(ctx, bike.rear, local.wheelAngle, plate);
    bikeWheel(ctx, bike.front, local.wheelAngle, plate);
    leg(ctx, local.farLeg, plate, true);
    bikeFrame(ctx, plate);
    transmission(ctx, local, plate);
    leg(ctx, local.nearLeg, plate, false);
    bird(ctx, local, plate);
  } finally {
    ctx.restore();
  }
}
