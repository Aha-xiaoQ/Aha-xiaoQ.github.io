// Each treatment keeps the saddle, grip and axle stations. The outlines and
// frame paths are authored for the medium so the pose can pass through a seam.

const engraving = {
  medium: 'engraving',
  ink: '#302b29', feather: '#f7edda', wash: '#c4b5a4', tip: '#6b5b50',
  upperBill: '#d39b5f', pouch: '#bc7148', metal: '#82706a', tire: '#3e322c',
  farLeg: '#ac7954', nearLeg: '#cc8c53', accent: '#b57453',
  rimWeight: 6, spokes: 14, tubeWidth: 7, hubRadius: 8,
  frame: 'M -130 25 L -65 -91 L 0 0 Z M -65 -91 L 95 -81 L 0 0 M 95 -81 Q 108 -19 150 25',
  body: 'M -173 -153 C -146 -165 -144 -183 -128 -196 C -102 -223 -70 -224 -45 -209 C -29 -200 -24 -190 -9 -203 C 6 -217 7 -233 7 -248 C 7 -277 24 -291 43 -291 C 65 -291 78 -272 77 -252 C 75 -233 61 -228 52 -227 C 48 -182 13 -117 -70 -111 C -96 -114 -117 -132 -128 -148 Q -145 -135 -173 -145 L -156 -153 Z',
  wing: 'M -114 -184 C -100 -200 -86 -198 -64 -184 C -29 -160 0 -142 36 -137 Q 75 -137 113 -130 Q 72 -121 28 -126 C -38 -124 -92 -145 -114 -184 Z',
  bill: 'M 60 -253 Q 122 -267 174 -250 L 203 -240 Q 206 -237 199 -236 Q 135 -237 66 -243 Z',
  billPouch: 'M 65 -246 Q 129 -240 197 -237 Q 172 -219 119 -220 Q 78 -225 65 -246 Z',
  wingAccent: 'M -100 -184 Q -64 -170 -44 -155 Q -23 -143 6 -136 M -92 -174 Q -65 -152 -44 -148 M -86 -160 Q -64 -145 -50 -140',
};

const ochre = {
  medium: 'ochre',
  ink: '#531a0e', feather: '#a93e21', wash: '#6b2313', tip: '#702a16',
  upperBill: '#c67438', pouch: '#dc8d4d', metal: '#9a4021', tire: '#732d1b',
  farLeg: '#923c22', nearLeg: '#c77741', accent: '#efbf7e',
  rimWeight: 9.4, spokes: 4, tubeWidth: 7.8, hubRadius: 8.2,
  frame: 'M -130 25 L -97 -16 Q -73 -52 -65 -91 M -130 25 Q -66 15 0 0 M -65 -91 Q -44 -35 0 0 Q 71 -56 95 -81 M -65 -91 Q 15 -55 95 -81 Q 116 -4 150 25',
  body: 'M -185 -143 L -171 -154 Q -157 -171 -144 -187 Q -117 -210 -92 -211 Q -58 -211 -38 -203 L -18 -194 L -4 -202 L 12 -228 L 17 -245 L 13 -258 L 19 -274 L 34 -284 L 48 -282 L 61 -274 L 74 -259 L 70 -247 L 61 -235 L 54 -233 L 53 -219 L 46 -201 L 31 -177 L 14 -156 L -10 -137 L -44 -119 L -70 -111 L -98 -115 L -122 -124 L -144 -142 L -165 -136 Z',
  wing: 'M 22 -182 Q 24 -169 12 -156 Q -13 -130 -44 -130 L -72 -136 L -91 -145 L -132 -154 L -155 -150 L -139 -164 L -156 -162 L -136 -177 Q -109 -194 -83 -197 L -57 -197 L -34 -189 L -17 -181 L 3 -178 Z',
  gripFeather: 'M 10 -178 Q 34 -174 46 -161 Q 56 -154 74 -145 L 113 -130 L 88 -129 L 59 -138 L 34 -144 L 14 -154 Z',
  bill: 'M 55 -258 L 79 -260 Q 105 -260 149 -251 L 193 -244 L 203 -240 L 196 -231 L 188 -230 L 187 -235 L 86 -240 L 62 -242 Z',
  billPouch: 'M 55 -249 L 195 -236 Q 177 -225 142 -216 L 107 -211 Q 85 -210 65 -222 L 54 -233 Z',
  wingAccent: 'M -140 -165 Q -92 -164 -54 -148 M -127 -174 Q -94 -176 -59 -158 M -112 -185 Q -84 -183 -56 -170 M -52 -176 L -39 -167',
};

const ink = {
  medium: 'ink',
  ink: '#25352e', feather: '#f3eed7', wash: '#878d75', tip: '#3c4c42',
  upperBill: '#af9263', pouch: '#cfb993', metal: '#6c775f', tire: '#47584a',
  farLeg: '#73806a', nearLeg: '#8b7a5c', accent: '#9c6543',
  rimWeight: 4.4, spokes: 7, tubeWidth: 4.1, hubRadius: 6,
  frame: 'M -130 25 Q -85 -29 -65 -91 Q -51 -33 0 0 Q -76 13 -130 25 M -65 -91 C -19 -84 38 -56 95 -81 C 71 -65 38 -20 0 0 M 95 -81 Q 94 -24 150 25',
  body: 'M -189 -135 C -168 -147 -162 -170 -144 -184 C -128 -202 -104 -209 -80 -208 C -55 -208 -30 -189 -17 -191 C -8 -190 7 -212 17 -232 C 20 -244 9 -258 15 -270 C 19 -286 37 -295 51 -291 C 69 -288 81 -275 81 -261 C 81 -245 70 -233 55 -228 C 60 -211 58 -190 41 -169 C 28 -150 9 -138 -14 -125 Q -40 -112 -70 -111 C -111 -110 -134 -128 -143 -144 Q -166 -136 -189 -135 Z',
  wing: 'M 29 -180 C 22 -158 3 -146 -14 -138 C -49 -126 -82 -139 -113 -146 Q -136 -146 -155 -151 L -136 -157 L -151 -158 C -143 -177 -119 -185 -100 -187 C -80 -190 -55 -191 -36 -182 C -18 -174 7 -174 29 -180 Z',
  gripFeather: 'M 33 -158 C 50 -160 68 -152 78 -142 Q 90 -136 113 -130 Q 86 -128 69 -136 Q 52 -140 36 -144 Z',
  bill: 'M 59 -258 C 97 -259 142 -254 174 -249 Q 196 -246 203 -240 Q 201 -230 193 -231 L 191 -235 C 139 -237 91 -240 60 -245 Z',
  billPouch: 'M 55 -247 C 98 -247 159 -241 194 -237 Q 169 -220 142 -215 C 112 -209 81 -207 64 -220 Q 58 -225 55 -247 Z',
  wingAccent: 'M -135 -166 C -105 -173 -82 -154 -51 -147 C -29 -142 -12 -153 1 -159 M -127 -158 Q -97 -159 -72 -149 M -97 -176 Q -79 -178 -64 -169',
};

const vertical = {
  medium: 'vertical',
  ink: '#172d2b', feather: '#fff3dc', wash: '#719d95', tip: '#274c48',
  upperBill: '#ffc35c', pouch: '#ef8c5b', metal: '#a3a28b', tire: '#263936',
  farLeg: '#a3664b', nearLeg: '#e4a065', accent: '#206455',
  rimWeight: 7.5, spokes: 16, tubeWidth: 9.3, hubRadius: 9.2,
  frame: 'M -130 25 Q -94 -35 -65 -91 L 0 0 Q -52 8 -130 25 M -65 -91 C -16 -93 48 -72 97 -84 C 71 -65 37 -26 0 0 M 97 -84 C 94 -48 118 7 150 25',
  body: 'M -184 -134 Q -168 -147 -157 -163 C -145 -190 -115 -210 -82 -215 C -57 -219 -30 -203 -7 -198 Q 9 -199 18 -225 C 23 -238 20 -247 17 -256 C 13 -274 30 -289 45 -291 C 64 -294 75 -284 82 -271 Q 88 -263 84 -252 C 80 -239 72 -235 61 -231 C 68 -216 71 -198 64 -183 C 56 -158 36 -141 11 -128 C -10 -116 -38 -111 -70 -111 C -113 -110 -140 -122 -152 -137 Q -166 -132 -184 -134 Z',
  wing: 'M 25 -189 C 27 -178 18 -157 -5 -146 C -25 -132 -56 -127 -84 -136 L -108 -142 Q -133 -143 -158 -151 L -138 -158 L -159 -159 Q -141 -175 -119 -183 C -91 -195 -63 -196 -37 -187 C -16 -180 4 -171 25 -189 Z',
  gripFeather: 'M 32 -164 C 44 -168 59 -163 67 -155 Q 77 -146 91 -140 Q 105 -137 113 -130 C 110 -123 97 -122 85 -125 C 64 -128 53 -136 42 -139 L 23 -144 Z',
  bill: 'M 57 -256 C 85 -260 108 -257 133 -253 L 177 -246 Q 196 -245 203 -240 Q 202 -231 193 -229 L 190 -236 C 140 -237 106 -234 78 -238 Q 61 -240 58 -244 Z',
  billPouch: 'M 54 -245 C 103 -245 152 -238 194 -236 C 179 -223 162 -218 143 -214 C 114 -208 88 -207 73 -218 Q 59 -224 54 -245 Z',
  wingAccent: 'M -128 -171 C -90 -181 -60 -157 -27 -151 Q -10 -148 4 -156 M -120 -164 Q -99 -170 -74 -156 M -96 -177 Q -79 -178 -64 -170',
};

const shadow = {
  ...engraving,
  medium: 'shadow',
  ink: '#1c1717', feather: '#1c1717', wash: '#1c1717', tip: '#1c1717',
  upperBill: '#1c1717', pouch: '#1c1717', metal: '#1c1717', tire: '#1c1717',
  farLeg: '#1c1717', nearLeg: '#1c1717', rimWeight: 7, spokes: 8,
};

const scope = {
  ...shadow,
  medium: 'scope',
  ink: '#78ffb2', metal: '#9afcbe', tire: '#6afa9f', rimWeight: 2.5, tubeWidth: 2.2,
};

function painted(base, fields) { return {...base, ...fields}; }

const brace = 'M -130 25 L -65 -92 L 0 0 Z M -65 -92 Q 15 -75 95 -81 L 0 0 M 95 -81 Q 100 -20 150 25';
const reed = 'M -130 25 C -102 -6 -77 -56 -65 -91 C -58 -67 -23 -16 0 0 C -44 11 -93 22 -130 25 M -65 -91 Q 27 -101 95 -81 Q 68 -42 0 0 M 95 -81 Q 96 -32 150 25';
const tall = 'M -130 25 L -65 -92 L 0 0 Z M -65 -92 L 82 -102 L 0 0 M 82 -102 Q 100 -86 95 -81 Q 117 -28 150 25';
const templeBody = 'M -169 -144 L -143 -173 Q -126 -208 -88 -219 Q -55 -224 -26 -198 L -9 -192 L 14 -226 L 18 -251 Q 10 -268 28 -284 Q 51 -297 76 -276 L 77 -254 L 62 -234 L 54 -232 L 47 -200 Q 32 -164 2 -135 L -67 -111 Q -105 -113 -133 -145 L -149 -139 Z';
const paintedBill = 'M 59 -258 L 114 -258 Q 155 -251 203 -239 L 199 -232 L 172 -233 L 67 -242 Z';
const friezeWing = `${ochre.wing} M 4 -174 Q 37 -171 61 -151 L 113 -130 L 93 -127 Q 62 -135 27 -145 L 6 -151 Z`;
const blot = 'M -194 -140 C -164 -173 -157 -178 -146 -191 Q -121 -224 -92 -224 Q -71 -224 -47 -200 C -26 -176 -7 -193 5 -218 C 14 -235 19 -244 20 -257 Q 20 -280 40 -292 Q 63 -300 77 -286 Q 91 -271 77 -250 L 59 -234 Q 61 -210 44 -177 C 24 -140 -23 -111 -70 -111 C -127 -110 -136 -132 -194 -140 Z';

const egypt = painted(ochre, {medium: 'engraving', ink: '#2a4341', feather: '#4f998c', wash: '#285c64', tip: '#d8b268', upperBill: '#e7ad55', pouch: '#bc6a39', metal: '#c39957', tire: '#4a6055', farLeg: '#8c6c55', nearLeg: '#c88d4e', accent: '#f1d27f', rimWeight: 7, spokes: 7, frame: tall, body: templeBody, wing: friezeWing, bill: paintedBill, gripFeather: undefined});
const han = painted(engraving, {ink: '#ebe2cb', feather: '#353832', wash: '#171e1e', tip: '#c8c8b3', upperBill: '#b2b1a1', pouch: '#696a5d', metal: '#a4a395', tire: '#d4ccb4', farLeg: '#90948a', nearLeg: '#d7cdb4', accent: '#fff3cf', rimWeight: 4.5, tubeWidth: 4, spokes: 9, frame: brace, body: templeBody});
const tang = painted(engraving, {ink: '#433934', feather: '#f7eed87a', wash: '#e3d7c202', tip: '#706057', upperBill: '#d8bd8b', pouch: '#e9dbc399', metal: '#958478', tire: '#645b50', farLeg: '#bfa88b', nearLeg: '#c4a17b', accent: '#96614c', rimWeight: 3.5, tubeWidth: 3.9, spokes: 11, frame: reed, body: ink.body, wingAccent: 'M -103 -184 Q -68 -167 -29 -156 Q 5 -144 27 -142 M -92 -173 Q -64 -151 -40 -149'});
const riverside = painted(ink, {ink: '#384943', feather: '#eee7ce', wash: '#91a192', tip: '#677d72', upperBill: '#ba9d5f', pouch: '#d9a776', metal: '#617b74', tire: '#536965', rimWeight: 4.9, tubeWidth: 5.4, spokes: 10, accent: '#964c35', frame: reed});
const maya = painted(ochre, {medium: 'engraving', ink: '#683521', feather: '#b85544', wash: '#754f42', tip: '#e9bf7e', upperBill: '#c38d46', pouch: '#bd774e', metal: '#956f47', tire: '#745448', farLeg: '#805046', nearLeg: '#d19053', accent: '#e7b16c', spokes: 5, rimWeight: 8.9, frame: brace, body: templeBody, wing: friezeWing, bill: paintedBill, gripFeather: undefined});
const mughal = painted(engraving, {ink: '#4a392f', feather: '#f4e8b7', wash: '#cfac7e', tip: '#9b6e43', upperBill: '#e0b664', pouch: '#bc784c', metal: '#4e7663', tire: '#5a4236', accent: '#d8b363', spokes: 16, rimWeight: 5.3, frame: reed, body: vertical.body});
const bada = painted(ink, {ink: '#262921', feather: '#46483a', wash: '#242920', tip: '#141d1a', upperBill: '#575141', pouch: '#777666', tire: '#2c3129', metal: '#757366', nearLeg: '#5b5341', farLeg: '#6c6252', accent: '#9e7250', spokes: 5, rimWeight: 5.9, frame: reed, body: blot, whiteEye: true});
const wayang = painted(engraving, {medium: 'wayang', ink: '#321e16', feather: '#6d351f', wash: '#482219', tip: '#d9a050', upperBill: '#aa6837', pouch: '#754427', tire: '#532c1d', metal: '#b97944', nearLeg: '#a75d35', farLeg: '#783719', accent: '#eba667', rimWeight: 6.3, spokes: 6, frame: tall, body: templeBody});
const ukiyo = painted(engraving, {ink: '#303d53', feather: '#e9e2bd', wash: '#a6a99e', tip: '#679198', upperBill: '#c39356', pouch: '#b96642', metal: '#6d8f97', tire: '#3a5267', farLeg: '#987555', nearLeg: '#b78152', accent: '#c56f3f', rimWeight: 5.7, spokes: 12, frame: tall, body: ink.body});
const oils = painted(engraving, {ink: '#244976', feather: '#edda7b', wash: '#7fa3a7', tip: '#6e84a3', upperBill: '#f1c65f', pouch: '#bc815c', metal: '#5b82ad', tire: '#486b97', farLeg: '#7d7489', nearLeg: '#c39560', accent: '#ffdc96', rimWeight: 6.5, spokes: 12, frame: brace, body: vertical.body});
const scream = painted(engraving, {ink: '#3a3850', feather: '#e6b28a', wash: '#b87778', tip: '#844e68', upperBill: '#ed9b60', pouch: '#a65555', metal: '#615474', tire: '#5c415c', accent: '#fc9a5e', spokes: 8, frame: reed, body: blot});
const pixels = painted(engraving, {ink: '#16243d', feather: '#fbddaa', wash: '#b58e85', tip: '#781756', upperBill: '#ffb43e', pouch: '#e97754', metal: '#62d59c', tire: '#231e43', farLeg: '#9d626e', nearLeg: '#f5a963', accent: '#afe5b1', rimWeight: 12, tubeWidth: 11, spokes: 4, frame: brace, body: templeBody, bill: paintedBill});
const gif = painted(engraving, {ink: '#314995', feather: '#fff4bd', wash: '#b2c5cc', tip: '#7981a7', upperBill: '#fcc051', pouch: '#ce885b', metal: '#83b2cc', tire: '#38435d', accent: '#fcd177', spokes: 9, frame: tall, body: vertical.body});
const neon = painted(engraving, {ink: '#261849', feather: '#9ad5d9', wash: '#6050b8', tip: '#ec82d2', upperBill: '#f3a3c5', pouch: '#dc6b9f', metal: '#9595ef', tire: '#8d54b5', nearLeg: '#c07bb3', farLeg: '#795ebc', accent: '#6ef0e6', rimWeight: 7.4, spokes: 7, frame: reed, body: blot});

const treatments = new Map([
  [0, ochre], [1, egypt], [2, han], [3, tang], [4, ink], [5, riverside], [6, maya], [7, mughal], [8, bada], [9, wayang],
  [10, ukiyo], [11, oils], [12, scream], [13, shadow], [14, scope], [15, pixels], [16, gif], [17, neon], [18, vertical],
]);

export function treatmentFor(style) {
  return treatments.get(style) ?? engraving;
}
