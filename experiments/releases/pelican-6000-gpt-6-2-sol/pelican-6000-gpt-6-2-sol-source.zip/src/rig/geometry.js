// Anchor locations, the two-link leg solve and the external-tangent chain
// construction are adapted from src/rider.js in Pelican_PureCode_R6_Source.zip.

export const TAU = 2 * Math.PI;

export const bike = Object.freeze({
  rear: Object.freeze([-130, 25]),
  front: Object.freeze([150, 25]),
  radius: 77,
  pedalRadius: 31,
  seat: Object.freeze([-70, -111]),
  hip: Object.freeze([-56, -112]),
  grip: Object.freeze([113, -130]),
  shoulder: Object.freeze([-59, -178]),
  head: Object.freeze([44, -252]),
  beak: Object.freeze([203, -240]),
  thigh: 88,
  shin: 77,
  chainringRadius: 17,
  chainringTeeth: 24,
});

export const clamp = (value, lo, hi) => Math.max(lo, Math.min(hi, value));

function pointOnCircle([x, y], radius, angle) {
  return [x + radius * Math.cos(angle), y + radius * Math.sin(angle)];
}

function legAt(phase) {
  const { hip, pedalRadius, thigh, shin } = bike;
  const pedal = pointOnCircle([0, 0], pedalRadius, phase);
  const dx = pedal[0] - hip[0];
  const dy = pedal[1] - hip[1];
  const length = Math.hypot(dx, dy);
  const projection = (thigh ** 2 - shin ** 2 + length ** 2) / (2 * length);
  const height = Math.sqrt(Math.max(0, thigh ** 2 - projection ** 2));
  const knee = [
    hip[0] + (projection * dx + height * dy) / length,
    hip[1] + (projection * dy - height * dx) / length,
  ];
  return { hip, knee, pedal };
}

function smoothstep(value) {
  const t = clamp(value, 0, 1);
  return t * t * (3 - 2 * t);
}

export function localPose(options = {}) {
  const { x = 0, y = 0, scale = 1, tilt = 0, time = 0 } = options;
  const phase = options.phase ?? time * TAU;
  const drive = drivetrain(options.gearRatio ?? 1.6);
  const sprocketAngle = phase * drive.ratio;
  const wheelAngle = options.wheelAngle ?? sprocketAngle;
  const nod = clamp(options.headAngle ?? Math.sin(phase) * .018, -.3, .3);
  const lean = clamp(options.lean ?? 0, -.16, .16);
  const cosine = Math.cos(nod);
  const sine = Math.sin(nod);

  function headPoint(px, py) {
    const dx = px - bike.head[0];
    const dy = py - bike.head[1];
    return [
      bike.head[0] + dx * cosine - dy * sine + nod * 12,
      bike.head[1] + dx * sine + dy * cosine + Math.abs(nod) * 6,
    ];
  }

  function bodyPoint(px, py) {
    const weight = smoothstep((-py - 178) / 46) * smoothstep((px + 46) / 45);
    const [hx, hy] = headPoint(px, py);
    const targetY = py + (hy - py) * weight;
    return [px + (hx - px) * weight + lean * (targetY - bike.hip[1]), targetY];
  }

  function wingPoint(px, py) {
    const weight = smoothstep((bike.grip[0] - px) / 150);
    const lift = Math.sin(phase - 1.15) * 2.5 * weight;
    return [px + lean * (py - bike.hip[1]) * weight, py + lift];
  }

  return {
    x, y, scale, tilt, time, phase, wheelAngle, sprocketAngle, drive,
    bodyPoint, wingPoint,
    nearLeg: legAt(phase), farLeg: legAt(phase + Math.PI),
    gaze: clamp(options.gaze ?? .6, -1, 1),
  };
}

export function landmarks(pose) {
  const { x, y, scale, tilt, nearLeg, farLeg, bodyPoint } = pose;
  const cosine = Math.cos(tilt);
  const sine = Math.sin(tilt);
  function world([px, py]) {
    return {
      x: x + scale * (px * cosine - py * sine),
      y: y + scale * (px * sine + py * cosine),
    };
  }

  const frontWheel = world(bike.front);
  const rearWheel = world(bike.rear);
  const wheelRadius = scale * bike.radius;
  const roadContact = center => ({x: center.x, y: center.y + wheelRadius});
  return {
    crank: world([0, 0]),
    frontWheel, rearWheel,
    frontContact: roadContact(frontWheel), rearContact: roadContact(rearWheel),
    nearPedal: world(nearLeg.pedal), farPedal: world(farLeg.pedal),
    saddle: world(bike.seat), grip: world(bike.grip),
    shoulder: world(bodyPoint(...bike.shoulder)), beak: world(bodyPoint(...bike.beak)),
    wheelRadius,
  };
}

// Both runs are tangent to the tooth pitch circles. The chain advances by
// crank radians times pitch radius, so a pause or seek cannot move it alone.
const rearAxis = Math.atan2(bike.rear[1], bike.rear[0]);
const axleDistance = Math.hypot(...bike.rear);
const drives = new Map();

function drivetrain(requestedRatio) {
  // Integer tooth count keeps the spacing identical on both circles. The
  // rear hub has a freewheel, so it can roll slightly faster than the cog.
  const rearTeeth = Math.ceil(bike.chainringTeeth / clamp(requestedRatio, .35, 2.5));
  if (!drives.has(rearTeeth)) {
    const ratio = bike.chainringTeeth / rearTeeth;
    const rearRadius = bike.chainringRadius / ratio;
    const tangentOffset = Math.acos((bike.chainringRadius - rearRadius) / axleDistance);
    const topAngle = rearAxis + tangentOffset;
    const bottomAngle = rearAxis - tangentOffset;
    drives.set(rearTeeth, {
      ratio, rearRadius, rearTeeth, topAngle, bottomAngle,
      rearTop: pointOnCircle(bike.rear, rearRadius, topAngle),
      rearBottom: pointOnCircle(bike.rear, rearRadius, bottomAngle),
      frontTop: pointOnCircle([0, 0], bike.chainringRadius, topAngle),
    });
  }
  return drives.get(rearTeeth);
}

export function traceChain(ctx, drive) {
  const { rearTop, rearBottom, frontTop, rearRadius, topAngle, bottomAngle } = drive;
  ctx.beginPath();
  ctx.moveTo(...rearTop);
  ctx.lineTo(...frontTop);
  ctx.arc(0, 0, bike.chainringRadius, topAngle, bottomAngle + TAU);
  ctx.lineTo(...rearBottom);
  ctx.arc(...bike.rear, rearRadius, bottomAngle, topAngle);
  ctx.closePath();
}
