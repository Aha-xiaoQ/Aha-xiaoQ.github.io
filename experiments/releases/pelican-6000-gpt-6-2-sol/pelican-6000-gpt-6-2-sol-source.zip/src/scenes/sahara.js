import { clamp, ellipse, path, rect, smooth, verticalGradient } from './drawing.js';
import { cachedLayer, groundTrace, opacityWindow, plot, scratch, seeded } from './historical-paint.js';

const PIGMENT = '#783925';
const MINERAL = '#994b2d';
const LIGHT = '#e1ab73';
const floor = () => 760;
const cattleBody = 'M-80 -57 Q-82 -75 -69 -82 Q-48 -91 -24 -84 Q-5 -79 21 -89 Q33 -95 48 -84 L59 -64 Q50 -52 29 -45 Q1 -39 -26 -41 Q-51 -37 -67 -44Z';
let cattleGrain;

function lattice(x, y) {
  let z = Math.imul(x, 374761393) ^ Math.imul(y, 668265263);
  z = Math.imul(z ^ (z >>> 13), 1274126177);
  return ((z ^ (z >>> 16)) >>> 0) / 4294967296;
}

function noise(x, y) {
  const ix = Math.floor(x);
  const iy = Math.floor(y);
  const u = smooth(x - ix);
  const v = smooth(y - iy);
  const a = lattice(ix, iy) * (1 - u) + lattice(ix + 1, iy) * u;
  const b = lattice(ix, iy + 1) * (1 - u) + lattice(ix + 1, iy + 1) * u;
  return a * (1 - v) + b * v;
}

function mineralTexture(ctx) {
  if (typeof OffscreenCanvas === 'undefined') return;
  const pixels = 620;
  const tile = new OffscreenCanvas(pixels, pixels);
  const sample = tile.getContext('2d');
  const texture = sample.createImageData(pixels, pixels);
  const rgba = texture.data;
  for (let y = 0; y < pixels; y++) {
    for (let x = 0; x < pixels; x++) {
      const i = (y * pixels + x) * 4;
      const coarse = noise(x * .018, y * .046);
      const pockets = noise(x * .088 + 731, y * .125);
      const stone = noise(x * .24 + 271, y * .26);
      const grit = lattice(x + 18, y + 619);
      const stratum = Math.sin(y * .25 + 7 * noise(x * .019, y * .023));
      const density = 0.46 * coarse + 0.24 * pockets + 0.15 * stone + 0.15 * grit + stratum * .032;
      const v = Math.round(clamp(.50 + (density - .50) * 2.7) * 255);
      rgba[i] = v;
      rgba[i + 1] = Math.max(0, v - 9);
      rgba[i + 2] = Math.max(0, v - 21);
      rgba[i + 3] = 255;
    }
  }
  sample.putImageData(texture, 0, 0);
  ctx.save();
  ctx.globalAlpha = .86;
  ctx.globalCompositeOperation = 'soft-light';
  ctx.drawImage(tile, 0, 0, 1000, 1000);
  ctx.restore();
}

function plane(ctx, trace, stops) {
  path(ctx, trace, verticalGradient(ctx, stops));
}

function fracture(ctx, knots, seed, width) {
  const random = seeded(seed);
  const points = [knots[0]];
  for (let i = 1; i < knots.length; i++) {
    const [x0, y0] = knots[i - 1];
    const [x1, y1] = knots[i];
    const subdivisions = Math.ceil(Math.hypot(x1 - x0, y1 - y0) / 12);
    for (let n = 1; n < subdivisions; n++) {
      const t = n / subdivisions;
      points.push([x0 + (x1 - x0) * t + (random() - .5) * 12, y0 + (y1 - y0) * t + (random() - .5) * 8]);
    }
    points.push(knots[i]);
  }
  plot(ctx, points.map(([x, y]) => [x + 1.5, y - 2]), 'rgba(246,182,111,.32)', width + 3.4);
  plot(ctx, points, 'rgba(57,33,28,.57)', width);
  plot(ctx, points.map(([x, y]) => [x - 2, y + 1]), 'rgba(101,58,35,.5)', width * .62);
}

function wall(ctx) {
  rect(ctx, 0, 0, 1000, 1000, verticalGradient(ctx, [[0, '#6f4a38'], [.32, '#c5956c'], [.55, '#c78f60'], [.71, '#b58159'], [1, '#7c5342']]));
  plane(ctx, 'M0 0 H498 L438 159 362 241 246 275 198 321 92 356 0 334Z',
    [[0, '#443331'], [.38, '#856045'], [.69, '#734b39'], [1, '#533938']]);
  plane(ctx, 'M0 257 L102 289 181 263 253 234 381 214 468 120 497 0 H1000 V176 L905 205 865 242 736 274 633 306 546 275 414 312 362 348 273 353 224 385 106 409 0 364Z',
    [[0, '#936246'], [.24, '#9d6d48'], [.36, '#d6a879'], [.49, '#bd8254'], [1, '#6d4133']]);
  plane(ctx, 'M0 418 L108 443 224 422 277 388 371 382 410 348 544 310 633 338 741 309 877 278 912 238 1000 204 V593 L897 626 779 636 623 672 530 651 448 694 309 682 235 717 105 707 0 725Z',
    [[0, '#be936f'], [.37, '#d1a47a'], [.55, '#d7a575'], [.71, '#bc8758'], [1, '#aa754c']]);
  plane(ctx, 'M0 779 L111 767 241 781 318 752 432 764 554 719 647 747 747 724 838 742 1000 705 V1000 H0Z',
    [[0, '#d1ab84'], [.70, '#b27f58'], [.82, '#986544'], [1, '#68443a']]);
  plane(ctx, 'M705 874 L803 823 852 823 925 775 1000 772 V1000 H658Z',
    [[0, '#a27455'], [.76, '#9c694a'], [1, '#6d4237']]);
  plane(ctx, 'M0 567 L36 556 89 594 116 629 106 687 57 739 0 759Z',
    [[0, '#a77554'], [.56, '#9d6b4b'], [.77, '#865640'], [1, '#70483b']]);

  mineralTexture(ctx);
  for (const [knots, seed, width] of [
    [[[0, 326], [104, 374], [219, 351], [272, 321], [368, 308], [407, 270], [543, 237], [621, 264], [752, 220], [882, 199], [1000, 156]], 43, 3.8],
    [[[0, 415], [106, 441], [224, 417], [284, 388], [371, 381], [411, 351], [541, 313], [635, 333], [756, 303], [880, 276], [1000, 212]], 371, 4.8],
    [[[0, 780], [118, 769], [245, 782], [328, 751], [431, 762], [546, 716], [649, 738], [748, 718], [842, 733], [1000, 703]], 55, 3.1],
    [[[871, 224], [854, 285], [885, 333], [857, 424], [894, 471], [863, 517], [888, 579]], 691, 2.6],
    [[[113, 440], [143, 473], [131, 537], [158, 588], [131, 654], [109, 691], [112, 762]], 990, 3.1],
    [[[513, 751], [478, 823], [491, 878], [466, 968], [469, 1000]], 829, 2.6],
  ]) fracture(ctx, knots, seed, width);

  const random = seeded(6617);
  ctx.save();
  for (let i = 0; i < 1700; i++) {
    const x = random() * 1000;
    const y = random() * 1000;
    const w = .3 + random() ** 3 * 13;
    const h = .35 + random() * 2.8;
    ctx.fillStyle = i % 3 ? 'rgba(85,51,38,.135)' : 'rgba(255,223,163,.27)';
    ctx.fillRect(x, y, w, h);
  }
  ctx.restore();

  const restingPlane = ctx.createRadialGradient(531, 631, 24, 531, 631, 283);
  restingPlane.addColorStop(0, 'rgba(207,154,105,.27)');
  restingPlane.addColorStop(0.7, 'rgba(207,154,105,.13)');
  restingPlane.addColorStop(1, 'rgba(207,154,105,0)');
  rect(ctx, 240, 360, 584, 555, restingPlane);

  ctx.save();
  ctx.globalAlpha = .23;
  cattle(ctx, {x: 280, y: 501, scale: .59, turn: 1, look: .47, color: '#754e36'});
  cattle(ctx, {x: 390, y: 479, scale: .48, turn: -1, look: .14, color: '#814934'});
  cattle(ctx, {x: 464, y: 460, scale: .28, turn: 1, look: .5, color: '#6b4431'});
  path(ctx, 'M938 409 q-15 -39 -27 -15 l2 8 7 31 q3 20 -1 30 q1 13 9 11 q9 -12 8 -30Z', PIGMENT);
  path(ctx, 'M942 420 l6 -54 M950 431 l12 -30 M919 450 l-21 -15', null, PIGMENT, 2.2);
  ctx.restore();

  const shade = ctx.createRadialGradient(544, 564, 245, 544, 548, 710);
  shade.addColorStop(0, 'rgba(85,40,28,0)');
  shade.addColorStop(.58, 'rgba(85,40,28,.07)');
  shade.addColorStop(1, 'rgba(39,25,25,.53)');
  rect(ctx, 0, 0, 1000, 1000, shade);
}

const paintWall = cachedLayer(wall);

function cattle(ctx, {x, y, scale, turn = 1, look = 0, color = PIGMENT, walking = 0}) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale * turn, scale);
  const nearLeg = walkLeg(walking * 6);
  const farLeg = walkLeg(-walking * 7);
  scratch(ctx, `M-54 -45 Q-62 -26 ${-63 + farLeg} -5 L${-67 + farLeg} -3 M36 -53 Q33 -29 ${29 + farLeg} -4 L${34 + farLeg} -2`, color, 4.1, .64);
  path(ctx, cattleBody, color);
  path(ctx, 'M-68 -81 Q-37 -87 -13 -80 Q12 -77 37 -88 L26 -74 Q22 -61 8 -63 Q-9 -65 -18 -75 Q-43 -75 -54 -67Z', 'rgba(215,144,96,.55)');
  path(ctx, 'M-18 -70 C-6 -62 2 -66 13 -56 C6 -49 -2 -44 -14 -48 Q-31 -49 -32 -60Z M43 -76 Q35 -71 39 -62 Q48 -61 50 -67Z', 'rgba(234,175,114,.44)');
  if (!cattleGrain) {
    const random = seeded(31407);
    cattleGrain = new Path2D();
    for (let i = 0; i < 149; i++) {
      const x = -80 + random() * 138;
      const y = -90 + random() * 52;
      cattleGrain.rect(x, y, .36 + random() * 1.8, .3 + random() * 1.5);
    }
  }
  ctx.save();
  ctx.clip(new Path2D(cattleBody));
  ctx.fillStyle = 'rgba(231,175,119,.43)';
  ctx.fill(cattleGrain);
  ctx.restore();
  scratch(ctx, `M-66 -48 Q-54 -32 ${-53 + nearLeg} -7 L${-61 + nearLeg} -1 M39 -49 Q51 -29 ${49 + nearLeg} -6 L${55 + nearLeg} -2`, color, 5.4);
  scratch(ctx, 'M-73 -73 Q-91 -64 -94 -48 Q-98 -42 -102 -47', color, 3.8);
  ellipse(ctx, -101, -47, 4.1, 3.4, color);

  ctx.translate(45, -78);
  ctx.rotate(look * .74);
  path(ctx, 'M-14 -7 Q7 -16 19 -8 L34 1 44 15 42 23 27 25 11 13 1 11Z', color);
  path(ctx, 'M9 -7 Q12 -23 1 -41 Q20 -36 22 -18 L21 -7Z M23 -6 Q32 -19 32 -44 Q41 -36 39 -23 Q37 -12 29 -3Z', color);
  path(ctx, 'M21 -5 q9 -3 18 -7 q-4 8 -11 9Z', color);
  ellipse(ctx, 27, 3, 2.2, 1.5, '#e4a578');
  ellipse(ctx, 40, 18, 2.4, 1.35, '#e4a578');
  ctx.restore();
}

function walkLeg(amount) {
  return Math.max(-7, Math.min(7, amount));
}

function herder(ctx, local) {
  const bend = opacityWindow(local, 2.13, 2.9, 4.05, 4.83);
  const track = opacityWindow(local, 2.19, 2.93, 3.82, 4.41);
  const handX = 27 + 56 * track;
  const handY = -44 + 43 * track;
  ctx.save();
  ctx.translate(738, 720);
  ctx.scale(-1, 1);
  scratch(ctx, 'M-9 -49 L-27 -20 -32 -4 -41 1 M-7 -45 L15 -24 11 -7 23 -7', PIGMENT, 6.6);
  path(ctx, 'M-17 -52 Q-9 -59 4 -56 L7 -37 Q-4 -32 -18 -43Z', '#693721');
  ctx.save();
  ctx.translate(-7, -49);
  ctx.rotate(.15 + .74 * bend);
  path(ctx, 'M-11 4 Q-8 -15 -8 -35 Q0 -49 7 -39 Q11 -29 5 -17 L8 6 Q2 13 -11 4Z', PIGMENT);
  ellipse(ctx, 0, -53, 8.1, 9.8, PIGMENT);
  path(ctx, 'M-9 -54 Q-9 -67 5 -64 L10 -60 7 -55Z', '#66351f');
  path(ctx, 'M7 -53 l5 5 -7 4Z', PIGMENT);
  scratch(ctx, 'M-1 -35 Q-12 -20 -15 -12 Q-20 -6 -24 -5', PIGMENT, 4.7);
  path(ctx, 'M-6 -30 Q-4 -12 -2 -8 M-4 -35 L5 -26 M1 -25 L5 -20', null, 'rgba(235,174,114,.48)', 1.7);
  ctx.restore();
  const elbowX = 13 + 20 * bend;
  const elbowY = -65 - 4 * bend;
  scratch(ctx, `M${-1 + 19 * bend} ${-79 + 17 * bend} Q${elbowX} ${elbowY} ${handX} ${handY}`, PIGMENT, 5.2);
  ellipse(ctx, handX, handY, 3.6, 3.1, PIGMENT);
  scratch(ctx, `M${handX - 2} ${handY - 4} l${11 + 5 * track} ${13 + 15 * track}`, '#784826', 2.5);
  ctx.restore();
}

function hoof(ctx, x, y, scale, opacity) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(-.22);
  ctx.scale(scale, scale);
  ctx.globalAlpha *= opacity;
  path(ctx, 'M-8 7 Q-15 -10 -7 -12 Q-1 -10 -1 5 L-3 10Z M2 8 Q0 -7 6 -12 Q13 -9 10 3 L7 9Z', MINERAL);
  ctx.restore();
}

export function paintSahara(ctx, info = {}) {
  paintWall(ctx);
  const t = info.local ?? 0;
  const floorAt = info.floorAt ?? floor;
  const riderX = Math.max(-150, Math.min(1150, info.riderX ?? t * 1000 / 6));
  const notice = opacityWindow(t, 1.67, 2.44, 3.77, 4.54);
  const gust = opacityWindow(t, .7, 1.75, 4.6, 5.85);

  // The painterly trail meets neighboring local panels precisely at the rolling height.
  groundTrace(ctx, floorAt, {offset: 3, ink: 'rgba(109,63,44,.36)', width: 11});
  groundTrace(ctx, floorAt, {ink: 'rgba(67,40,31,.55)', width: 2.2});
  groundTrace(ctx, floorAt, {offset: -2.1, ink: 'rgba(242,182,119,.66)', width: 2.2});

  for (const [x, y, scale, turn, look, color, approach] of [
    [154, 665, .70, 1, .14, '#a05938', .32],
    [273, 695, .91, 1, .6, '#934d32', .14],
    [842, 660, .90, -1, .54, '#985436', .25],
    [842, 735, .58, -1, 1.26, '#995336', .05],
    [943, 571, .48, -1, .29, '#a76442', .45],
  ]) {
    const displaced = x + turn * (8 * Math.sin(t * 1.5 + approach) * (1 - notice));
    const head = look * notice - .19 * (1 - notice) + .035 * Math.sin(t * 3.7 + x);
    cattle(ctx, {x: displaced, y, turn, scale, look: head, walking: Math.sin(t * 4.6 + x * .01) * (1 - notice), color});
  }
  herder(ctx, t);

  for (let i = 0; i < 7; i++) {
    const x = 692 + i * 18;
    hoof(ctx, x, 746 - i * 4, .47 + i * .03, .54);
  }
  for (let i = 0; i < 3; i++) {
    const x = 637 + i * 17;
    hoof(ctx, x, 744 + (i % 2) * 8, .57, smooth((t - 2.86 - i * .10) / .20) * .85);
  }
  const tail = clamp((riderX - 406) / 330) * 330 + 406;
  groundTrace(ctx, floorAt, {from: 406, to: tail, offset: 8, ink: '#825035', width: 1.65});
  groundTrace(ctx, floorAt, {from: 406, to: tail, offset: 12, ink: 'rgba(127,70,42,.72)', width: 1.4});

  const flare = ctx.createRadialGradient(354 + t * 76, 530, 5, 354 + t * 76, 530, 480);
  flare.addColorStop(0, `rgba(255,200,137,${(.17 + .09 * gust).toFixed(4)})`);
  flare.addColorStop(1, 'rgba(255,192,122,0)');
  ctx.save();
  ctx.globalCompositeOperation = 'soft-light';
  rect(ctx, 0, 0, 1000, 1000, flare);
  ctx.restore();
}

export function paintSaharaForeground(ctx, info = {}) {
  const t = info.local ?? 0;
  const x = info.riderX ?? t * 1000 / 6;
  const air = opacityWindow(t, .42, .8, 5.23, 5.74);
  const random = seeded(501);
  for (let n = 0; n < 32; n++) {
    const weight = random();
    const drift = (t * (8 + random() * 31) + random() * 1000) % 1000;
    const y = 395 + random() * 557;
    const alpha = air * (.12 + weight * .37) * smooth(Math.abs(x - drift) / 37);
    if (alpha <= .025) continue;
    ellipse(ctx, drift, y, .5 + 1.1 * weight, .4 + weight * .7, `rgba(239,181,117,${alpha})`);
  }
  scratch(ctx, 'M877 954 l29 -33 32 -17 35 -43 27 -8', LIGHT, 1.8, .35);
}
