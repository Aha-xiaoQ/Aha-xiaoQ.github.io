import { path, smooth } from './drawing.js';

export function seeded(seed) {
  let state = seed >>> 0;
  return () => {
    state = (Math.imul(state, 1664525) + 1013904223) >>> 0;
    return state / 4294967296;
  };
}

export function cachedLayer(draw, size = 1200) {
  let layer;
  return ctx => {
    if (!layer && typeof OffscreenCanvas !== 'undefined') {
      layer = new OffscreenCanvas(size, size);
      const drawing = layer.getContext('2d');
      drawing.scale(size / 1000, size / 1000);
      draw(drawing);
    }
    if (layer) ctx.drawImage(layer, 0, 0, 1000, 1000);
    else draw(ctx);
  };
}

export function opacityWindow(t, inStart, inEnd, outStart, outEnd) {
  return smooth((t - inStart) / (inEnd - inStart))
    * (1 - smooth((t - outStart) / (outEnd - outStart)));
}

export function plot(ctx, points, stroke, width = 1, fill = null) {
  ctx.beginPath();
  ctx.moveTo(...points[0]);
  for (const point of points.slice(1)) ctx.lineTo(...point);
  if (fill) {
    ctx.closePath();
    ctx.fillStyle = fill;
    ctx.fill();
  }
  if (stroke) {
    ctx.strokeStyle = stroke;
    ctx.lineWidth = width;
    ctx.stroke();
  }
}

export function scratch(ctx, trace, color, width, alpha = 1) {
  ctx.save();
  ctx.globalAlpha *= alpha;
  ctx.lineCap = 'round';
  path(ctx, trace, null, color, width);
  ctx.restore();
}

export function groundTrace(ctx, position, {from = 0, to = 1000, offset = 0, ink, width = 1}) {
  if (to <= from) return;
  const points = [];
  for (let x = from; x < to; x += 7) points.push([x, position(x) + offset]);
  points.push([to, position(to) + offset]);
  plot(ctx, points, ink, width);
}
