import {clamp, fade, line, SANS, surface, TAU, text} from '../kit/index.js';

function random(seed) {
  return () => {
    seed = (Math.imul(1664525, seed) + 1013904223) >>> 0;
    return seed / 4294967296;
  };
}

function fill(ctx, color, x, y, width, height) {
  ctx.fillStyle = color;
  ctx.fillRect(x, y, width, height);
}

function gradient(ctx, top, bottom, stops) {
  const color = ctx.createLinearGradient(0, top, 0, bottom);
  for (const [point, shade] of stops) color.addColorStop(point, shade);
  return color;
}

function shape(ctx, coordinates, color) {
  ctx.beginPath();
  ctx.moveTo(...coordinates[0]);
  for (const next of coordinates.slice(1)) ctx.lineTo(...next);
  ctx.closePath();
  ctx.fillStyle = color;
  ctx.fill();
}

let city;
function cityLayer() {
  if (city) return city;
  city = surface(1350, 702);
  const ctx = city.getContext('2d');
  const rng = random(7038908);
  fill(ctx, gradient(ctx, 0, 648, [[0, '#192741'], [0.4, '#374564'], [0.67, '#796572'], [0.87, '#cb896e'], [1, '#edb188']]), 0, 0, 1350, 702);
  const glow = ctx.createRadialGradient(695, 531, 4, 695, 603, 420);
  glow.addColorStop(0, '#ffdb9dbd');
  glow.addColorStop(1, '#eeb28100');
  fill(ctx, glow, 0, 210, 1350, 492);
  ctx.fillStyle = '#ffe3ab';
  ctx.beginPath();
  ctx.arc(735, 485, 26, 0, TAU);
  ctx.fill();
  for (let i = 0; i < 420; i += 1) {
    const y = 64 + rng() * 505;
    const x = rng() * 1370;
    fill(ctx, `rgba(255,201,173,${rng() * (y > 470 ? 0.14 : 0.07)})`, x, y, 7 + rng() * 111, rng() * 3 + 0.55);
  }
  for (let level = 0; level < 3; level += 1) {
    const y = 592 + 18 * level;
    let x = -50 - level * 13;
    while (x < 1350) {
      const width = 24 + rng() * 47;
      const height = 22 + rng() ** 2 * (116 + level * 42);
      const right = 8 + rng() * 11;
      const rise = y - height;
      fill(ctx, ['#9b767e', '#52607a', '#334860'][level], x, rise, width, height + 10);
      shape(ctx, [[x + width, rise], [x + width + right, rise + 6], [x + width + right, y + 6], [x + width, y + 10]], ['#a78083', '#796f83', '#263a50'][level]);
      if (height > 64) fill(ctx, '#b68983a4', x + 3, rise - 3, width - 6, 2);
      for (let col = 7; col < width - 4; col += 8) {
        for (let row = 9; row < height - 7; row += 10) {
          const lit = rng();
          if (lit > 0.42) fill(ctx, lit > 0.86 ? '#f4c187a2' : '#bca7914a', x + col, rise + row, 2 + level / 2, 3);
        }
      }
      x += width + right + 5 + rng() * 17;
    }
  }
  fill(ctx, gradient(ctx, 616, 702, [[0, '#475b6f'], [0.5, '#38495f'], [1, '#2a454f']]), 0, 616, 1350, 86);
  for (let i = 0; i < 260; i += 1) {
    const x = rng() * 1370;
    const y = 617 + rng() * 86;
    const color = Math.abs(x - 710) < 200 ? '#d9a78246' : '#9cbcc131';
    fill(ctx, color, x, y, 4 + rng() * 31, 0.7 + rng() * 1.1);
  }
  return city;
}

export function paintPortrait(ctx, info) {
  const {cameraX, local, floorAt} = info;
  ctx.save();
  ctx.drawImage(cityLayer(), -155 + clamp(cameraX, -250, 1250) * 0.09, 0);

  fill(ctx, gradient(ctx, 700, 1000, [[0, '#42656b'], [0.2, '#304c58'], [0.55, '#263b49'], [1, '#182d3c']]), 0, 700, 1000, 300);
  const wet = ctx.createRadialGradient(663, 740, 2, 533, 736, 299);
  wet.addColorStop(0, '#a8dbd145');
  wet.addColorStop(0.58, '#81c2c82a');
  wet.addColorStop(1, '#99d2ce00');
  fill(ctx, wet, 0, 700, 1000, 255);

  for (let x = -46; x <= 1000; x += 96) {
    const shift = (x * 29) % 31;
    shape(ctx, [[x, 665], [x + 7, 665], [x + 13, 704], [x + 5, 704]], '#1b2d3e');
    line(ctx, [[x + 2, 667], [x + 7, 700]], '#d0ad926b', 1.4);
    line(ctx, [[x + 16, 740 + shift], [x + 59, 738 + shift]], '#78b6bb39', 1.7);
  }
  for (const y of [662, 679, 698]) line(ctx, [[0, y], [1000, y]], '#233448', 4.2);
  line(ctx, [[0, 660], [1000, 660]], '#ebae8763', 1.6);

  const surfaceEdge = floorAt(500);
  line(ctx, [[0, surfaceEdge + 1], [1000, surfaceEdge + 1]], '#172d37', 2.8);
  line(ctx, [[0, surfaceEdge + 8], [1000, surfaceEdge + 8]], '#9bbdb76b', 1.3);
  const randomDeck = random(530);
  for (let i = 0; i < 160; i += 1) {
    const x = randomDeck() * 1000;
    const y = 713 + randomDeck() * 222;
    const light = randomDeck();
    fill(ctx, light > 0.58 ? '#b2d2c22b' : '#14273248', x, y, 1 + randomDeck() * 7, 0.7 + randomDeck() * 1.5);
  }
  for (const x of [107, 357, 647, 880]) {
    line(ctx, [[x + 10, 715], [x - 42, 999]], '#1c334167', 2);
    fill(ctx, '#c6ba9160', x + 43, 818, 43, 3);
  }

  const previousBreeze = 0.5 + 0.5 * Math.cos(local * 1.6);
  for (let i = 0; i < 30; i += 1) {
    const x = (31 + i * 73) % 1000;
    const y = 710 + i * 2.2;
    fill(ctx, `rgba(192,182,139,${0.025 + previousBreeze * 0.048})`, x, y, 4 + (i * 13) % 21, 0.9);
  }
  ctx.restore();
}

function heart(ctx, x, y, size, color) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(size, size);
  ctx.beginPath();
  ctx.moveTo(0, 0.72);
  ctx.bezierCurveTo(-1.5, -0.22, -0.55, -1.01, 0, -0.5);
  ctx.bezierCurveTo(0.55, -1.01, 1.5, -0.22, 0, 0.72);
  ctx.fillStyle = color;
  ctx.fill();
  ctx.restore();
}

function bubble(ctx, x, y, width, height, color) {
  ctx.beginPath();
  ctx.roundRect(x, y, width, height, height / 2);
  ctx.fillStyle = color;
  ctx.fill();
}

export function paintPortraitUi(ctx, scene, {left, width, local, openness}) {
  const ready = fade(openness, 0.55, 0.95);
  const progress = clamp(local / 6);
  if (ready <= 0) return;
  ctx.save();
  ctx.translate(left, 0);
  ctx.globalAlpha = ready;
  fill(ctx, gradient(ctx, 0, 252, [[0, '#081729da'], [0.55, '#101c2d91'], [1, '#15233a00']]), 0, 0, width, 252);
  fill(ctx, gradient(ctx, 744, 900, [[0, '#172b3900'], [1, '#081b2cd9']]), 0, 744, width, 156);
  text(ctx, scene.zh, 33, 92, {size: 35, font: SANS, weight: 700, color: '#f8e9db'});
  text(ctx, `${scene.en}  ·  ${scene.era}`, 34, 123, {size: 15, font: SANS, color: '#f3ded3'});
  const statusX = width - 109;
  bubble(ctx, statusX, 59, 76, 29, '#142a44b8');
  ctx.beginPath();
  ctx.arc(statusX + 16, 73.5, 3.8, 0, TAU);
  ctx.fillStyle = '#ff9b8b';
  ctx.fill();
  text(ctx, '实况', statusX + 27, 79, {size: 13, font: SANS, color: '#ffd5c3', weight: 700});

  for (const [index, time] of [1.63, 2.0, 3.22, 3.61, 4.04, 4.25, 4.71].entries()) {
    const age = (local - time) / 1.15;
    if (age < 0 || age >= 1) continue;
    ctx.globalAlpha = ready * fade(age, 0, 0.12) * (1 - fade(age, 0.57, 1));
    const x = width - 36 - age * 28 + 8 * Math.sin(age * 5 + index);
    heart(ctx, x, 719 - 190 * age, 11 + (index % 3) * 3.0, index % 2 ? '#ffb2a9' : '#ffa7c5');
  }

  const read = fade(local, 2.47, 2.72) * (1 - fade(local, 4.33, 4.66));
  if (read > 0) {
    ctx.globalAlpha = ready * read;
    const rise = (1 - read) * 23;
    bubble(ctx, 24, 751 + rise, 190, 46, '#10283aee');
    text(ctx, '能横屏吗？', 45, 781 + rise, {size: 24, color: '#ffeacb', font: SANS, weight: 650});
  }
  ctx.globalAlpha = ready;
  fill(ctx, '#88aeb75e', 25, 860, width - 50, 3);
  fill(ctx, '#ffbb9a', 25, 860, (width - 50) * progress, 3);
  ctx.restore();
}
