import { MONO, SANS, ellipse, grain, path, rect, round, smooth, text, verticalGradient } from './drawing.js';

function fadeText(ctx, opacity, value, x, y, options) {
  ctx.save();
  ctx.globalAlpha *= opacity;
  text(ctx, value, x, y, options);
  ctx.restore();
}

export function paintIntroPage(ctx, info = {}) {
  const t = info.local ?? info.time ?? 0;
  const ink = '#2d211b';
  const brown = '#6f5544';
  const red = '#944c38';
  ctx.save();
  rect(ctx, 0, 0, 1000, 1000, verticalGradient(ctx, [[0, '#e9dabb'], [0.45, '#f3ead3'], [1, '#ddc6a4']]));
  const edges = ctx.createRadialGradient(500, 490, 250, 500, 490, 710);
  edges.addColorStop(0, 'rgba(104,68,37,0)');
  edges.addColorStop(1, 'rgba(104,68,37,.36)');
  rect(ctx, 0, 0, 1000, 1000, edges);
  grain(ctx, 314159, 'rgba(80,56,39,.13)', 'rgba(255,248,230,.30)', 840);
  path(ctx, 'M84 203 H922 V915 H84Z M97 216 H909 V902 H97Z', null, '#aa8961', 1);
  path(ctx, 'M116 337 H884 M116 543 H570', null, '#977e66', 1.3);
  path(ctx, 'M126 592 H226 M126 605 H203 M126 618 H239', null, '#c3a98d', 1);
  rect(ctx, 124, 273, 5, 45, red);
  text(ctx, '鹈鹕测试', 142, 307, { size: 33, weight: 600, fill: ink });
  text(ctx, 'THE PELICAN TEST', 882, 305, { size: 19, fill: brown, align: 'right', face: MONO });

  fadeText(ctx, smooth((t - .35) / .48), '人类自古以来就痴迷于画鹈鹕骑自行车。', 123, 409,
    { size: 40, maxWidth: 754, weight: 600, fill: ink });
  fadeText(ctx, smooth((t - 2.86) / .14), '——早在自行车被发明之前。', 123, 476,
    { size: 39, maxWidth: 751, weight: 600, fill: red });
  fadeText(ctx, smooth((t - 3.0) / .25), '——《鹈鹕骑行艺术通史》，卷一（虚构书名）', 122, 519,
    { size: 21, maxWidth: 640, fill: brown });

  // The compositor places the live pen-and-ink bicycle within this plate.
  path(ctx, 'M593 595 l14 -14 h280 l13 13 v198 l-13 13 H607 l-13 -13Z', '#eee1c7', '#a18161', 1.1);
  path(ctx, 'M607 596 H886 V790 H607Z M616 763 Q731 751 875 763', null, '#bda183', 0.95);
  for (let i = 0; i < 21; i++) {
    const x = 621 + i * 12;
    const y = 765 + (i * 7) % 12;
    path(ctx, `M${x} ${y} l-8 8`, null, 'rgba(124,89,58,.35)', 1.1);
  }
  text(ctx, '图一 鹈鹕骑行图（摹本）', 746, 832, { size: 22, fill: brown, align: 'center' });
  ctx.restore();
}

export function paintPress(ctx, info = {}) {
  const flash = Math.max(0, Math.min(1, info.flash ?? 0));
  ctx.save();
  rect(ctx, 0, 0, 1000, 1000, verticalGradient(ctx, [[0, '#17252a'], [0.53, '#2b4143'], [1, '#101c22']]));
  for (let x = 0; x < 1000; x += 77) {
    path(ctx, `M${x} 0 L${x + 22} 1000`, null, 'rgba(106,134,132,.18)', 2);
    path(ctx, `M${x + 4} 0 L${x + 26} 1000`, null, 'rgba(8,25,29,.23)', 6);
  }
  const overhead = ctx.createRadialGradient(507, 355, 40, 507, 485, 552);
  overhead.addColorStop(0, '#6a7f75');
  overhead.addColorStop(.37, 'rgba(120,141,123,.44)');
  overhead.addColorStop(1, 'rgba(37,56,58,0)');
  rect(ctx, 0, 110, 1000, 783, overhead);
  path(ctx, 'M0 269 H1000 M0 286 H1000', null, 'rgba(153,172,159,.35)', 2);
  round(ctx, 376, 419, 248, 305, 35, '#1e282c', '#a0987f', 4);
  round(ctx, 389, 431, 222, 278, 27, '#354344', '#515b50', 2);
  path(ctx, 'M409 465 L409 665 M591 465 V665 M422 447 H578 M399 551 Q500 565 601 551', null, '#57645c', 2);
  path(ctx, 'M331 639 Q357 619 385 632 L403 649 H597 L616 632 Q643 619 669 639 L648 666 H354Z', '#354344', '#8b8771', 2);
  if (flash > 0) rect(ctx, 0, 0, 1000, 1000, `rgba(245,241,213,${flash * .56})`);
  ctx.restore();
}

function microphone(ctx, x, scale, tilt, fill) {
  ctx.save();
  ctx.translate(x, 678);
  ctx.scale(scale, scale);
  ellipse(ctx, 0, 0, 36, 10, '#131d22', '#65716a', 2);
  ellipse(ctx, -1, -4, 27, 6, '#405057');
  ctx.rotate(tilt);
  path(ctx, 'M0 -4 V-67 Q0 -93 20 -114 L38 -137', null, '#182328', 8);
  path(ctx, 'M2 -5 V-64 Q2 -91 23 -111 L40 -135', null, '#69777a', 1.8);
  ctx.translate(42, -139);
  ctx.rotate(.68);
  round(ctx, -13, -28, 25, 52, 12, fill, '#101a1f', 2.4);
  for (let y = -21; y < 0; y += 4) path(ctx, `M-9 ${y} h17`, null, '#89928d', 1.1);
  ctx.restore();
}

export function paintPressForeground(ctx, info = {}) {
  const flash = Math.max(0, Math.min(1, info.flash ?? 0));
  ctx.save();
  path(ctx, 'M93 681 L167 633 H833 L907 681 904 750 H96Z', '#536263', '#929787', 2.8);
  path(ctx, 'M96 705 H904 V1000 H96Z', verticalGradient(ctx, [[0, '#303d42'], [.19, '#25343a'], [1, '#101c22']], 705, 1000));
  path(ctx, 'M96 704 H904 M110 720 H890 M108 729 H892', null, '#718079', 2.5);
  for (const [x, scale, tilt, fill] of [[250, .83, -.1, '#495760'], [387, .97, .12, '#725747'], [627, 1.02, -.68, '#46545b'], [762, .83, -.37, '#585765']]) {
    microphone(ctx, x, scale, tilt, fill);
  }
  path(ctx, 'M411 704 L435 629 H565 L589 704Z', '#c8b997', '#544638', 2.5);
  path(ctx, 'M420 695 L440 638 H560 L580 695Z', '#eaddba', '#958564', 1.4);
  text(ctx, '鹈鹕（本人）', 500, 677, { fill: '#27251f', size: 24, maxWidth: 136, face: SANS, weight: 600, align: 'center' });
  if (flash > 0) {
    path(ctx, 'M93 681 L167 633 H833 L907 681 904 750 H96Z', `rgba(250,244,215,${flash * .25})`);
  }
  ctx.restore();
}
