export { paintSahara, paintSaharaForeground } from './sahara.js';
export { paintSong, paintSongForeground } from './song.js';
