import { ellipse, path, rect, smooth, verticalGradient } from './drawing.js';
import { cachedLayer, groundTrace, opacityWindow, plot, scratch, seeded } from './historical-paint.js';

const PAPER = '#e6dfcc';
const DARK = '#282d27';
const floor = x => 760 + 32 * Math.sin(Math.PI * x / 1000) ** 2;

const westernPeak = 'M0 656 L0 479 Q48 425 91 367 L109 324 136 311 151 271 161 242 189 213 212 165 239 178 255 144 286 124 303 143 331 143 350 169 365 165 405 197 418 224 453 239 465 274 490 301 487 343 523 365 545 415 563 419 589 483 645 557 674 624 Q534 695 390 685Z';
const easternPeak = 'M334 659 L382 558 437 529 453 483 483 461 500 409 530 375 554 312 571 298 576 258 599 223 616 194 655 209 670 171 699 152 724 162 752 156 775 186 817 196 835 220 864 234 886 264 904 308 926 331 949 394 980 417 1000 477 V740Z';
const nearRock = 'M0 834 L53 813 104 793 137 766 157 752 173 739 190 753 215 780 242 788 271 819 299 821 324 857 351 877 336 898 234 910 173 898 111 923 53 905 0 930Z';
const rightRock = 'M692 929 L739 863 777 849 829 817 851 797 898 818 928 797 967 806 1000 788 V1000 H669Z';

function wash(ctx, outline, top, bottom, seed, map, density, strength) {
  const tone = ctx.createLinearGradient(...map);
  tone.addColorStop(0, top);
  tone.addColorStop(.69, bottom);
  tone.addColorStop(1, '#c6bfaa');
  path(ctx, outline, tone);
  const random = seeded(seed);
  const [x0, y0, x1, y1] = map;
  ctx.save();
  ctx.clip(new Path2D(outline));
  ctx.lineCap = 'round';
  for (let j = 0; j < 4; j++) {
    ctx.fillStyle = ['#242923', '#686957', '#d4c6aa', '#f1e9d3'][j];
    ctx.globalAlpha = strength * [0.54, .72, .45, .72][j];
    ctx.beginPath();
    for (let i = 0; i < density; i++) {
      const x = Math.min(x0, x1) + random() * Math.max(Math.abs(x1 - x0), 20);
      const y = Math.min(y0, y1) + random() * Math.max(Math.abs(y1 - y0), 20);
      const branch = Math.sin(x * .042 + y * .015) * 6;
      const height = .8 + random() ** 1.4 * (j === 0 ? 14 : 18);
      const width = .30 + random() * (j === 0 ? 2 : 2.8);
      ctx.moveTo(x, y);
      ctx.quadraticCurveTo(x + branch * .1 - width, y + height * .3, x + branch, y + height);
      ctx.quadraticCurveTo(x + branch * .25 + width * 1.42, y + height * .21, x, y);
    }
    ctx.fill();
  }
  ctx.restore();
}

function paper(ctx) {
  rect(ctx, 0, 0, 1000, 1000, verticalGradient(ctx, [[0, '#d7ccb0'], [.32, '#eee5d0'], [.61, PAPER], [1, '#c4bb9f']]));
  const vignette = ctx.createRadialGradient(492, 525, 316, 492, 530, 756);
  vignette.addColorStop(0, 'rgba(110,92,55,0)');
  vignette.addColorStop(1, 'rgba(80,68,47,.28)');
  rect(ctx, 0, 0, 1000, 1000, vignette);
  const random = seeded(5916);
  ctx.save();
  for (let i = 0; i < 5400; i++) {
    const x = random() * 1000;
    const y = random() * 1000;
    ctx.fillStyle = i % 4 ? 'rgba(86,72,50,.087)' : 'rgba(254,245,216,.36)';
    ctx.fillRect(x, y, .28 + 3.2 * random() ** 2, .22 + random() * .91);
  }
  ctx.restore();
}

function contour(ctx, trace, accent, width = 2) {
  scratch(ctx, trace, '#344238', width + 2.8, .14);
  scratch(ctx, trace, accent, width, .65);
}

function ridgeForest(ctx, x, y, spread, count, size, seed, color) {
  const random = seeded(seed);
  ctx.save();
  ctx.translate(x, y);
  ctx.fillStyle = color;
  for (let i = 0; i < count; i++) {
    const offset = random() * spread;
    const base = (random() - .5) * 19 + offset * .11;
    const trunk = size * (.08 + random() ** 2 * .59);
    const lean = (random() - .5) * trunk;
    const px = offset - spread / 2;
    ctx.beginPath();
    ctx.moveTo(px - 2.35, base + 1.5);
    ctx.quadraticCurveTo(px + lean * .37 - 1.2, base - trunk * .43, px + lean, base - trunk);
    ctx.quadraticCurveTo(px + lean * .38 + 1, base - trunk * .33, px + 1.9, base + 1.2);
    ctx.quadraticCurveTo(px, base + trunk * .2, px - 2.35, base + 1.5);
    ctx.fill();
    for (let leaf = 1; leaf < 4; leaf++) {
      const radius = 3 + random() * trunk * .39;
      const at = base - trunk * (.2 + leaf * .20);
      ellipse(ctx, px + lean * .5 + (random() - .5) * radius, at, radius, 1 + radius * .21, color);
    }
  }
  ctx.restore();
}

function massif(ctx) {
  path(ctx, 'M0 586 V416 Q76 440 121 386 T225 354 Q252 374 301 335 T379 349 Q441 350 478 398 T598 429 Q665 454 704 450 T795 518 Q863 551 1000 528 V642Z', '#c3c0ac');
  path(ctx, 'M648 579 Q686 485 741 467 T826 423 Q879 402 906 396 Q953 412 1000 385 V614Z', '#aeaf9c');
  ctx.save();
  ctx.translate(0, 27);
  wash(ctx, easternPeak, '#7f8476', '#b5b3a0', 53922, [330, 155, 1000, 724], 1220, .31);
  for (const [trace, width] of [
    ['M591 350 Q607 328 620 288 Q621 248 651 215 L671 219 674 192 700 165 723 170', 2.6],
    ['M830 236 Q817 265 820 305 L809 318 815 363 791 401 783 461 756 526', 1.8],
    ['M941 411 Q928 441 938 481 L917 501 912 541 884 574 882 615', 2.05],
    ['M608 398 L592 434 594 455 570 474 566 500 528 528 517 563', 1.3],
  ]) contour(ctx, trace, '#4d554b', width);
  ridgeForest(ctx, 697, 194, 101, 34, 16, 380, 'rgba(75,85,73,.42)');
  ridgeForest(ctx, 861, 364, 116, 40, 18, 383, 'rgba(66,77,69,.27)');
  ctx.restore();
  wash(ctx, westernPeak, '#454d40', '#767b69', 701, [0, 122, 679, 686], 1640, .65);
  const ribs = [
    ['M219 172 L242 184 251 154 282 140 307 156 329 153 347 179 365 177 397 207 414 235', 5.3],
    ['M159 252 Q173 289 156 326 L157 351 124 387 118 419 95 446 102 485 61 522', 4.2],
    ['M275 152 L278 178 302 219 288 255 306 290 294 317 317 355 314 402 352 436', 3.5],
    ['M336 190 L350 231 345 260 369 277 367 301 383 328 373 361 396 391 391 434 411 471 404 509 446 567', 5],
    ['M414 244 L424 275 443 293 445 329 471 355 465 379 495 399 504 434 527 451 532 477 575 511', 3.4],
    ['M219 249 Q244 274 227 302 L238 329 218 361 226 386 211 420 200 426 188 480 160 508 162 531', 3.3],
    ['M81 420 L68 463 47 509 56 545 39 571 L38 620 56 649', 2.1],
  ];
  for (const [trace, width] of ribs) contour(ctx, trace, '#2c392f', width);
  path(ctx, 'M26 478 L61 453 88 448 96 468 82 511 60 517 37 563 16 557 0 581 V522Z M104 427 L132 391 160 376 150 430 124 463 99 475Z M304 264 L329 245 340 276 347 315 358 323 353 367 348 397 327 359 311 334Z', 'rgba(211,204,169,.21)');
  for (const [x, y, count, size, seed] of [[147, 341, 77, 17, 881], [263, 176, 85, 18, 801], [357, 243, 53, 17, 862], [316, 427, 91, 14, 865], [502, 527, 86, 16, 867], [149, 558, 121, 17, 869]]) {
    ridgeForest(ctx, x, y, 118, count, size, seed, 'rgba(49,62,50,.51)');
  }
}

function waterfall(ctx, t) {
  const falling = 'M471 343 Q465 374 480 395 Q484 406 476 438 Q476 464 480 475 Q483 493 474 521 Q461 573 491 618 Q471 613 466 590 Q458 572 460 551 Q458 527 467 508 Q474 484 467 459 Q459 427 472 401 Q459 381 466 359Z';
  path(ctx, falling, '#e8e0c7');
  scratch(ctx, 'M469 354 Q464 388 477 399 Q473 427 470 446 M477 460 Q481 492 468 524 Q458 562 468 583', '#f4ead2', 2.1, .93);
  scratch(ctx, 'M474 373 Q474 394 479 409 Q471 448 475 481 Q478 513 466 552', '#919580', 1.1, .65);
  for (let i = 0; i < 9; i++) {
    const y = 440 + (i * 26 + t * 56) % 162;
    const x = 469 - Math.max(0, y - 555) * .022 + Math.sin(y / 22) * 2.5;
    const size = 4 + (i % 3) * 2;
    plot(ctx, [[x, y], [x - .7, y + size]], 'rgba(252,241,213,.67)', 1);
  }
  const plume = ctx.createRadialGradient(478, 621, 0, 478, 621, 66);
  plume.addColorStop(0, 'rgba(231,225,207,.76)');
  plume.addColorStop(1, 'rgba(231,225,207,0)');
  rect(ctx, 410, 565, 142, 113, plume);
}

function middleground(ctx) {
  path(ctx, 'M0 721 Q82 660 136 653 T256 671 Q344 650 398 666 Q472 668 531 624 Q593 587 639 613 Q693 639 724 599 Q759 573 788 600 Q858 631 906 596 Q968 556 1000 575 V1000 H0Z',
    verticalGradient(ctx, [[0, '#878e7b'], [.65, '#bab79f'], [.82, '#777e68'], [1, '#9b957b']]));
  path(ctx, 'M0 744 Q113 699 242 718 Q382 727 474 684 Q543 653 581 662 Q684 689 756 639 Q841 614 900 674 Q924 705 1000 706 V805 Q944 845 851 816 Q737 797 682 836 Q593 888 491 861 Q372 811 246 852 T0 860Z',
    '#b6b39b');
  path(ctx, 'M0 791 Q144 751 289 810 Q410 837 473 798 Q528 772 601 772 Q676 762 708 794 Q752 830 853 805 Q942 782 1000 799 V880 Q954 885 875 851 Q765 873 658 818 Q595 787 511 839 Q387 915 264 863 Q78 814 0 885Z',
    '#d0c5a9');
  for (const [trace, width] of [
    ['M0 745 Q99 710 174 716 Q254 701 305 729 Q359 755 431 708', 1.7],
    ['M69 811 Q133 798 192 815 Q263 827 291 850 Q344 868 393 867', 1.4],
    ['M505 816 Q587 764 665 782 Q708 803 741 815 Q803 836 862 817', 1.35],
    ['M566 651 Q611 621 654 646 Q690 654 713 642 Q749 613 799 634', 3.4],
  ]) contour(ctx, trace, '#646c5a', width);
  const random = seeded(9503);
  for (let i = 0; i < 668; i++) {
    const x = random() * 1000;
    const y = 625 + random() * 321;
    if (Math.abs(y - floor(x)) < 37) continue;
    const len = 1.2 + random() ** 2 * 25;
    plot(ctx, [[x, y], [x + len * .4, y - random() * 3], [x + len, y + random() * 2.5]], i % 3 ? 'rgba(67,78,62,.19)' : 'rgba(228,214,175,.55)', 0.65 + random() * 1.1);
  }
  for (const [x, y, spread, count, size, seed] of [[763, 656, 122, 57, 28, 821], [580, 673, 121, 84, 28, 822], [80, 686, 156, 72, 29, 823], [899, 712, 170, 88, 20, 824]]) {
    ridgeForest(ctx, x, y, spread, count, size, seed, 'rgba(75,86,69,.70)');
  }
}

function fog(ctx, t, lower) {
  ctx.save();
  const amount = lower ? .26 : .72;
  const y0 = lower ? 703 : 522;
  const height = lower ? 114 : 149;
  const color = [230, 224, 204];
  for (let i = 0; i < 5; i++) {
    const x = 115 + i * 203 + Math.sin(i + t * .37) * 58;
    const y = y0 + 19 * Math.sin(t * .51 + i);
    ctx.save();
    ctx.translate(x, y);
    ctx.scale(2.9 + .2 * (i % 2), 1);
    const cloud = ctx.createRadialGradient(0, 0, 0, 0, 0, height * .81);
    cloud.addColorStop(0, `rgba(${color.join(',')},${amount})`);
    cloud.addColorStop(.42, `rgba(${color.join(',')},${amount * .48})`);
    cloud.addColorStop(1, `rgba(${color.join(',')},0)`);
    rect(ctx, -height, -height, height * 2, height * 2, cloud);
    ctx.restore();
  }
  ctx.restore();
}

const paintMassif = cachedLayer(ctx => {
  paper(ctx);
  massif(ctx);
});

const paintMiddle = cachedLayer(middleground);

function pine(ctx, x, y, scale, mirror, seed, ink = DARK) {
  const random = seeded(seed);
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale * mirror, scale);
  const shape = 'M-31 67 Q-5 22 -2 -44 Q-3 -91 18 -135 Q32 -155 24 -179 Q46 -199 67 -238 Q65 -213 50 -194 Q37 -182 45 -157 Q50 -142 31 -122 Q20 -96 18 -69 Q21 -26 10 41 L24 67Z';
  path(ctx, shape, ink);
  for (const [trace, width] of [
    ['M2 41 Q22 7 11 -38 Q5 -74 23 -104 L30 -123 39 -144 36 -166 53 -206', 2.9],
    ['M-5 52 Q-3 35 7 22 M0 -23 q15 -24 10 -40 M18 -112 q-2 -12 10 -22', 1.2],
    ['M17 -95 Q-9 -117 -31 -125 Q-58 -134 -84 -129', 6.2],
    ['M23 -113 Q47 -137 73 -139 Q94 -138 143 -155', 5],
    ['M38 -156 Q12 -170 -2 -185 L-67 -192', 3.8],
    ['M46 -177 Q69 -180 85 -192 L120 -214', 4.2],
    ['M56 -194 Q85 -215 67 -235 L79 -246', 3.9],
  ]) scratch(ctx, trace, width < 3 ? '#b1a384' : ink, width, width < 3 ? .56 : 1);
  for (const [nx, ny, radius] of [[-83, -130, 49], [-58, -140, 49], [100, -145, 53], [137, -157, 36], [-35, -191, 48], [0, -172, 43], [84, -197, 43], [120, -217, 38], [72, -232, 37], [63, -249, 27], [32, -138, 32]]) {
    for (let i = 0; i < 37; i++) {
      const angle = random() * Math.PI * 2;
      const r = radius * Math.sqrt(random());
      const px = nx + Math.cos(angle) * r;
      const py = ny + Math.sin(angle) * r * .23;
      const length = 2 + random() * 11;
      const tint = i % 4 ? ink : '#6e7059';
      plot(ctx, [[px - length, py], [px, py - 1.4 - random() * 3.5], [px + length, py + random() * 1.9]],
        tint, .56 + random() * 1.38);
    }
  }
  ctx.restore();
}

function nearLayer(ctx) {
  wash(ctx, nearRock, '#343d32', '#595a47', 3981, [0, 625, 355, 1000], 345, .66);
  wash(ctx, rightRock, '#555d4d', '#686653', 3982, [665, 654, 1000, 1000], 412, .57);
  contour(ctx, 'M0 834 Q44 825 57 815 L103 790 136 769 172 744 190 754 Q232 795 244 790 L275 820 303 823', '#292f28', 3.8);
  contour(ctx, 'M5 871 L38 858 68 871 90 840 132 828 162 796 195 804 219 786 M759 884 L778 853 817 842 848 804 890 821 927 804 954 812', '#31392e', 3.65);
  pine(ctx, 117, 789, .96, 1, 522);
  pine(ctx, 39, 801, .62, 1, 531, '#505346');
  pine(ctx, 987, 790, .71, -1, 549, '#505649');
  const random = seeded(389821);
  for (let i = 0; i < 164; i++) {
    const x = random() * 1000;
    if (x > 280 && x < 801) continue;
    const y = 825 + random() * 175;
    scratch(ctx, `M${x} ${y} q1 -4 ${1 + random() * 9} ${-5 - random() * 8}`, '#2f3a30', .65 + random() * 2.4, .63);
  }
}

const paintNear = cachedLayer(nearLayer, 1300);

function porter(ctx, t, x, y) {
  const noticed = opacityWindow(t, 2.48, 3.06, 4.05, 4.58);
  ctx.save();
  ctx.translate(x, y);
  const scale = .84;
  ctx.scale(scale, scale);
  const xHead = -9 - 6 * noticed;
  const yHead = -75 + 1.9 * noticed;
  ellipse(ctx, 0, 0, 15, 3.2, 'rgba(49,56,44,.30)');
  path(ctx, 'M-11 -38 L-17 -10 -23 -4 -10 -3 -4 -22 1 -34 6 -27 10 -7 13 -1 24 -1 18 -7 14 -33 8 -43Z', '#373e34');
  path(ctx, 'M-19 -54 Q-16 -64 -8 -65 Q5 -61 13 -52 L16 -35 Q5 -29 -4 -34 L-14 -31 -24 -37Z', '#677261', DARK, 1.4);
  path(ctx, 'M-16 -50 Q-24 -47 -23 -38 L-18 -34 -10 -43 M-12 -62 L-7 -47 2 -51 11 -56 M-9 -45 L-3 -33', null, '#a69f83', 1.5);
  path(ctx, 'M15 -52 Q23 -46 22 -35 Q21 -30 16 -34 L9 -44Z', '#4c574a', DARK, 1);
  scratch(ctx, 'M-48 -56 Q-8 -76 66 -70', '#55503e', 3.3);
  scratch(ctx, 'M-42 -58 l4 23 M-30 -60 l-3 24 M53 -70 l5 27 M62 -70 l9 26', '#4b523f', 1.35);
  path(ctx, 'M-46 -38 h21 l-4 13 -14 3Z M54 -47 h21 l-4 13 -15 2Z', '#8d8060', '#4e513f', 1.3);
  path(ctx, 'M-43 -35 l14 2 M-42 -30 l12 1 M57 -44 l15 1 M58 -39 l13 2', null, '#cab794', .9);
  ctx.translate(xHead, yHead);
  ellipse(ctx, -1, 1.5, 6.9, 7.1, '#b7a283');
  path(ctx, 'M-7 -3 Q-8 -8 0 -9 Q7 -8 7 -3 L3 -2 -7 0Z', '#4e5040');
  path(ctx, noticed > .48 ? 'M-6 1 l-3 3 3 2 M-6 -1 l3 1' : 'M5 0 l3 3 -2 3 M1 0 h3', null, '#454638', .95);
  path(ctx, 'M-13 -3 Q0 -8 12 -4 M-10 -6 Q-3 -15 9 -6 L11 -4 -13 -3Z', '#8e8769', '#454c3e', 1.06);
  ctx.restore();
}

export function paintSong(ctx, info = {}) {
  const t = info.local ?? 0;
  const floorAt = info.floorAt ?? floor;
  paintMassif(ctx);
  waterfall(ctx, t);
  fog(ctx, t, false);
  paintMiddle(ctx);
  fog(ctx, t, true);
  groundTrace(ctx, floorAt, {offset: 6.5, ink: 'rgba(134,122,92,.23)', width: 22});
  groundTrace(ctx, floorAt, {offset: 3.5, ink: 'rgba(218,202,157,.70)', width: 10.5});
  groundTrace(ctx, floorAt, {ink: 'rgba(77,80,65,.64)', width: 1.55});
  for (let x = 13; x < 1000; x += 17) {
    const y = floorAt(x) + 3.3 + (x * 7) % 11;
    const len = 2.6 + x % 5;
    plot(ctx, [[x, y], [x + len * .55, y - .86], [x + len, y - .29]], 'rgba(61,74,60,.49)', .8);
  }
  porter(ctx, t, 681, floorAt(681) - 74);
}

export function paintSongForeground(ctx) {
  paintNear(ctx);
}
