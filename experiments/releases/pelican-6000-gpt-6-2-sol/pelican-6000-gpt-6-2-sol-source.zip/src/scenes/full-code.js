import {clamp, fade, line, surface, TAU, text} from '../kit/index.js';
import {bike, localPose} from '../rig/geometry.js';

const MONO = 'Consolas, "Liberation Mono", monospace';
const ASSET = {
  rim: 'M -207 25 a77 77 0 1 0 154 0 a77 77 0 1 0 -154 0 M 73 25 a77 77 0 1 0 154 0 a77 77 0 1 0 -154 0',
  frame: 'M-130 25 L-65-93 L0 0 Z M-65-93 Q23-91 95-82 L0 0 M95-82 Q102-12 150 25 M-65-93 L-70-111 M95-82 L113-130',
  body: 'M -183 -137 Q -160 -153 -148 -178 C -120 -218 -71 -224 -34 -204 C -3 -183 10 -204 20 -224 Q 27 -245 18 -262 C 13 -283 36 -298 58 -290 Q 96 -278 83 -250 Q 78 -230 58 -230 C 68 -175 23 -113 -67 -111 Q -118 -110 -154 -140 Z',
  wing: 'M 27 -183 Q 23 -157 -13 -140 C -51 -123 -101 -141 -143 -151 Q -117 -180 -84 -188 Q -57 -196 -26 -177 Q 1 -165 27 -183 Z',
  bill: 'M 66 -253 Q 122 -262 199 -242 L 204 -236 Q 158 -210 114 -213 Q 81 -218 62 -235 Z',
  grip: 'M 21 -163 C 41 -171 62 -155 81 -144 Q 95 -136 113 -130 Q 96 -125 76 -130 L 45 -142 Z',
};
const paths = new Map(Object.entries(ASSET).map(([key, data]) => [key, new Path2D(data)]));
const sourcePath = key => `<path id="${key}" d="${ASSET[key]}"/>`;

// The text reveal and geometry reveal are driven by the same rows.
const rows = [
  {time: .17, show: '<svg viewBox="-240 -320 480 440">', color: '#d1b2f1'},
  {time: .65, key: 'rim', show: sourcePath('rim'), color: '#80cfd7'},
  {time: 1.10, key: 'frame', show: sourcePath('frame'), color: '#8cd9c5'},
  {time: 1.56, key: 'drive', show: '<g id="pedals" data-phase="t / beat"/>', color: '#b0c9ed'},
  {time: 2.04, key: 'body', show: sourcePath('body'), color: '#e6d9c3'},
  {time: 2.59, key: 'wing', show: sourcePath('wing'), color: '#b5c9bb'},
  {time: 3.05, key: 'bill', show: sourcePath('bill'), color: '#e9ae83'},
  {time: 3.52, key: 'grip', show: sourcePath('grip'), color: '#a8d4be'},
  {time: 3.93, key: 'touch', show: '<circle cx="65" cy="-263" r="4.5"/>', color: '#e8d6ac'},
  {time: 4.40, show: '</svg>', color: '#d1b2f1'},
];

const sdf = new Map(rows.filter(row => row.key).map(row => [row.key, row.time]));
function visible(local, key) { return fade(local, sdf.get(key) + .10, sdf.get(key) + .50); }

let editor;
function editorPlate() {
  if (editor) return editor;
  editor = surface(1000, 1000);
  const c = editor.getContext('2d');
  const base = c.createLinearGradient(0, 0, 1000, 1000);
  base.addColorStop(0, '#101c28');
  base.addColorStop(.57, '#101e2b');
  base.addColorStop(1, '#233b47');
  c.fillStyle = base;
  c.fillRect(0, 0, 1000, 1000);
  const light = c.createRadialGradient(635, 702, 10, 635, 702, 415);
  light.addColorStop(0, '#c5f3ce24');
  light.addColorStop(.65, '#78b7ba14');
  light.addColorStop(1, '#78b7ba00');
  c.fillStyle = light;
  c.fillRect(0, 180, 1000, 820);
  for (let x = 8; x < 1000; x += 18) {
    for (let y = 20; y < 1000; y += 18) {
      c.fillStyle = x % 90 === 8 || y % 90 === 20 ? '#93b5c348' : '#93b5c322';
      c.fillRect(x, y, 1.3, 1.3);
    }
  }
  c.fillStyle = '#182b37';
  c.fillRect(0, 0, 1000, 51);
  line(c, [[0, 51], [1000, 51]], '#7594a24d', 1.2);
  line(c, [[45, 613], [956, 613]], '#83aeba27', 1);
  line(c, [[45, 841], [956, 841]], '#83aeba30', 1);
  return editor;
}

export function paintCodeScene(ctx, info) {
  ctx.drawImage(editorPlate(), 0, 0);
  text(ctx, 'pelican.svg', 25, 33, {size: 20, font: MONO, color: '#d8e5df'});
  text(ctx, 'SVG 1.1', 973, 33, {size: 15, font: MONO, color: '#a8bfbc', align: 'right'});
  const origin = 220;
  ctx.fillStyle = '#0c1724e0';
  ctx.fillRect(49, origin - 24, 480, 334);
  ctx.strokeStyle = '#8faeb947';
  ctx.strokeRect(49.5, origin - 23.5, 480, 334);
  const local = info.local;
  for (const [index, row] of rows.entries()) {
    const amount = clamp((local - row.time) / .47);
    const y = origin + 22 + 28 * index;
    text(ctx, String(index + 1).padStart(2, '0'), 70, y, {size: 12, font: MONO, color: '#739198'});
    const painted = Math.ceil(Math.min(row.show.length, 45) * amount);
    const preview = row.show.slice(0, painted) + (painted === 45 && row.show.length > 45 ? '…' : '');
    text(ctx, preview, 108, y, {size: 15, font: MONO, color: row.color});
    if (amount > 0 && amount < 1 && painted < 45) {
      ctx.fillStyle = '#d8f1d6';
      ctx.fillRect(108 + painted * 8.4, y - 16, 2, 18);
    }
  }
  line(ctx, [[0, 760], [1000, 760]], '#9dd5c854', 1.5);
  for (let x = 0; x < 1000; x += 50) line(ctx, [[x, 765], [x, x % 100 === 0 ? 775 : 770]], '#9dd5c855', 1.1);
  ctx.save();
  ctx.globalAlpha *= fade(local, 4.55, 4.90);
  text(ctx, '✓  轮辐偏移 1 像素　已保留', 76, 917, {size: 20, color: '#9fd0bb'});
  ctx.restore();
}

export function paintCodeTitle(ctx, {scene}) {
  ctx.fillStyle = '#172831';
  ctx.fillRect(0, 0, 325, 94);
  ctx.fillStyle = '#81ccbc';
  ctx.fillRect(0, 0, 5, 94);
  text(ctx, scene.zh, 20, 44, {size: 36, weight: 600, color: '#e4eee5'});
  text(ctx, `${scene.en} · ${scene.era}`, 21, 72, {size: 17, font: MONO, color: '#bcddcf'});
}

export function paintCodeExit(ctx) {
  ctx.drawImage(editorPlate(), 0, 0);
  ctx.save();
  const falloff = ctx.createLinearGradient(0, 0, 910, 0);
  falloff.addColorStop(0, '#11192300');
  falloff.addColorStop(1, '#111923ee');
  ctx.fillStyle = falloff;
  ctx.fillRect(0, 0, 1000, 1000);
  line(ctx, [[0, 760], [1000, 760]], '#9dd5c854', 1.5);
  ctx.restore();
}

function vector(ctx, path, stroke, weight, fill, alpha) {
  if (alpha <= 0) return;
  ctx.save();
  ctx.globalAlpha *= alpha;
  if (fill) {
    ctx.fillStyle = fill;
    ctx.fill(path);
  }
  ctx.strokeStyle = stroke;
  ctx.lineWidth = weight;
  ctx.stroke(path);
  ctx.restore();
}

function gradient(ctx, top, bottom, first, last) {
  const grad = ctx.createLinearGradient(0, top, 0, bottom);
  grad.addColorStop(0, first);
  grad.addColorStop(1, last);
  return grad;
}

export function paintCodeRider(ctx, pose, local) {
  ctx.save();
  ctx.translate(pose.x, pose.y);
  ctx.rotate(pose.tilt);
  ctx.scale(pose.scale, pose.scale);
  const blended = fade(local, 0.02, 0.62);
  const state = localPose(pose);
  const rim = Math.max(1 - blended, visible(local, 'rim'));
  vector(ctx, paths.get('rim'), '#85c8c2', 5, null, rim);
  ctx.save();
  ctx.globalAlpha *= rim * .68;
  for (const [cx, cy] of [bike.rear, bike.front]) {
    for (let i = 0; i < 14; i += 1) {
      const angle = i / 14 * TAU + state.wheelAngle;
      const length = i === 3 ? 69 : 74;
      const bend = i === 3 ? .035 : 0;
      line(ctx, [[cx, cy], [cx + Math.cos(angle + bend) * length, cy + Math.sin(angle + bend) * length]], i === 3 ? '#d1b683' : '#8fc8cc', 1.45);
    }
  }
  ctx.restore();
  const frame = Math.max((1 - blended) * .77, visible(local, 'frame'));
  vector(ctx, paths.get('frame'), '#74c6b0', 6, null, frame);
  vector(ctx, paths.get('frame'), '#d7e1c8', 1.2, null, frame);
  const drive = visible(local, 'drive');
  ctx.save();
  ctx.globalAlpha *= drive;
  line(ctx, [[-90, -111], [-48, -111]], '#b7caca', 6.5);
  line(ctx, [[99, -130], [130, -130]], '#abcac5', 5);
  for (const leg of [state.farLeg, state.nearLeg]) {
    line(ctx, [leg.hip, leg.knee, leg.pedal], '#d2a277', 6.4);
    line(ctx, [[0, 0], leg.pedal, [leg.pedal[0] + 17, leg.pedal[1]]], '#a8cbce', 3.9);
  }
  ctx.restore();
  const body = Math.max((1 - blended) * .93, visible(local, 'body'));
  vector(ctx, paths.get('body'), '#cbddc8', 1.65, gradient(ctx, -285, -120, '#e9e7ca', '#5d9f97'), body);
  vector(ctx, paths.get('wing'), '#9ac1a7', 1.8, gradient(ctx, -188, -135, '#adc2a8', '#4a7e79'), visible(local, 'wing'));
  vector(ctx, paths.get('wing'), '#accdb83d', 6.8, null, visible(local, 'wing'));
  vector(ctx, paths.get('bill'), '#e4a57a', 2.1, gradient(ctx, -255, -211, '#eac995', '#ba765b'), Math.max((1 - blended) * .8, visible(local, 'bill')));
  vector(ctx, paths.get('grip'), '#8fb7a7', 1.4, '#719a88', visible(local, 'grip'));
  ctx.save();
  ctx.globalAlpha *= visible(local, 'touch');
  ctx.beginPath();
  ctx.arc(65, -263, 5.0, 0, TAU);
  ctx.fillStyle = '#dce8cf';
  ctx.fill();
  ctx.beginPath();
  ctx.arc(66, -263, 2.5, 0, TAU);
  ctx.fillStyle = '#153c42';
  ctx.fill();
  ctx.restore();
  ctx.restore();
}
