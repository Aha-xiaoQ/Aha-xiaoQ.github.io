export const PAGE_SIZE = 1000;

export const SERIF = '"Noto Serif CJK SC", "Songti SC", SimSun, Georgia, serif';
export const SANS = '"Noto Sans CJK SC", "Microsoft YaHei", "PingFang SC", sans-serif';
export const MONO = '"Cascadia Mono", Consolas, monospace';

const shapes = new Map();

export function path(ctx, data, fill = null, stroke = null, width = 1) {
  if (!shapes.has(data)) shapes.set(data, new Path2D(data));
  const shape = shapes.get(data);
  if (fill) {
    ctx.fillStyle = fill;
    ctx.fill(shape);
  }
  if (stroke) {
    ctx.strokeStyle = stroke;
    ctx.lineWidth = width;
    ctx.stroke(shape);
  }
}

export function ellipse(ctx, x, y, rx, ry, fill = null, stroke = null, width = 1) {
  ctx.beginPath();
  ctx.ellipse(x, y, rx, ry, 0, 0, Math.PI * 2);
  if (fill) {
    ctx.fillStyle = fill;
    ctx.fill();
  }
  if (stroke) {
    ctx.strokeStyle = stroke;
    ctx.lineWidth = width;
    ctx.stroke();
  }
}

export function rect(ctx, x, y, w, h, fill) {
  ctx.fillStyle = fill;
  ctx.fillRect(x, y, w, h);
}

export function round(ctx, x, y, w, h, radius, fill, stroke = null, width = 1) {
  ctx.beginPath();
  ctx.roundRect(x, y, w, h, radius);
  if (fill) {
    ctx.fillStyle = fill;
    ctx.fill();
  }
  if (stroke) {
    ctx.lineWidth = width;
    ctx.strokeStyle = stroke;
    ctx.stroke();
  }
}

export function text(ctx, value, x, y, {
  size = 22, fill = '#231e1b', face = SERIF, weight = 400, align = 'left', maxWidth,
} = {}) {
  ctx.font = `${weight} ${size}px ${face}`;
  ctx.fillStyle = fill;
  ctx.textBaseline = 'alphabetic';
  ctx.textAlign = align;
  if (maxWidth === undefined) {
    ctx.fillText(value, x, y);
  } else {
    ctx.fillText(value, x, y, maxWidth);
  }
}

export function verticalGradient(ctx, stops, y0 = 0, y1 = PAGE_SIZE) {
  const gradient = ctx.createLinearGradient(0, y0, 0, y1);
  for (const [stop, color] of stops) gradient.addColorStop(stop, color);
  return gradient;
}

function sequence(seed) {
  let state = seed >>> 0;
  return () => {
    state = (Math.imul(1664525, state) + 1013904223) >>> 0;
    return state / 4294967296;
  };
}

export function grain(ctx, seed, shadow, light, density = 360, bounds = [0, 0, 1000, 1000]) {
  const random = sequence(seed);
  const [x, y, w, h] = bounds;
  ctx.save();
  for (let tone = 0; tone < 2; tone++) {
    ctx.fillStyle = tone ? light : shadow;
    for (let n = 0; n < density / 2; n++) {
      ctx.fillRect(x + w * random(), y + h * random(), 0.6 + 3.7 * random(), 0.65 + 1.5 * random());
    }
  }
  ctx.restore();
}

export function clamp(value) {
  return Math.max(0, Math.min(1, value));
}

export function smooth(value) {
  const u = clamp(value);
  return u * u * (3 - 2 * u);
}
