import { MONO, SANS, SERIF, ellipse, grain, path, rect, round, text, verticalGradient } from './drawing.js';

const palettes = [
  ['#ddad7b', '#a6714c', '#fbe3c2', '#4a2d1e', '#9b4c30'],
  ['#edd6a2', '#9a7852', '#f7e8c0', '#372a24', '#286663'],
  ['#373b39', '#171d1d', '#242a29', '#f0e9da', '#b9c2af'],
  ['#f1e8d6', '#cfc2a8', '#fbf3e4', '#2e332c', '#7a4334'],
  ['#ebe8d7', '#99a090', '#f4efdb', '#293b33', '#7a503e'],
  ['#eadcc0', '#be9e65', '#f3e5c9', '#342c25', '#825238'],
  ['#e6c68f', '#96543e', '#f6deaf', '#43241c', '#a23b32'],
  ['#40616a', '#213a42', '#223e42', '#f7e3a7', '#c9994a'],
  ['#efe9df', '#d3ccba', '#f8f2e6', '#343b37', '#954837'],
  ['#a96129', '#492726', '#532d25', '#fff0bd', '#e2ae53'],
  ['#9cbdc3', '#456d83', '#e8e5cb', '#243f4c', '#994737'],
  ['#233b69', '#151e44', '#222e57', '#fff0ba', '#ebc870'],
  ['#ce754f', '#56384a', '#552f3c', '#fff0cb', '#f2a761'],
  ['#626461', '#1d2626', '#252b2b', '#eeeadd', '#c8c5b7'],
  ['#1d3930', '#0a1714', '#11291f', '#cbffc2', '#73d583'],
  ['#30597e', '#173453', '#183452', '#fff1b9', '#edb86c'],
  ['#6e8795', '#354862', '#edf0df', '#203648', '#a25443'],
  ['#82477f', '#35275d', '#412b5d', '#ffe7f2', '#ff90d2'],
  ['#383975', '#171834', '#241e43', '#f7e9ff', '#f78cda'],
  ['#253b4c', '#0d1d2b', '#172c3a', '#e0f6f5', '#75ccb6'],
];

function rock(ctx, accent) {
  path(ctx, 'M0 321 L178 262 272 192 431 243 548 165 758 209 1000 159 V0 H0Z', '#a06a47');
  path(ctx, 'M0 636 L136 599 277 638 412 581 520 631 708 577 1000 592 V1000 H0Z', '#af7950');
  path(ctx, 'M0 660 L136 626 275 656 412 608 521 651 707 603 1000 619', null, '#e3ad79', 4);
  path(ctx, 'M0 202 L172 249 92 410 119 494 31 620 M737 156 L685 327 769 405 723 524 M866 535 L910 637 840 780 877 946', null, '#925d3e', 13);
  path(ctx, 'M4 198 L176 246 97 411 122 491 34 620 M740 162 L692 325 774 405 727 525 M871 535 L915 637 847 780 882 946', null, '#f3bd85', 2);
  // Pigment fragments sit on the wall surface and leave the ride path open.
  ctx.save();
  ctx.globalAlpha = 0.72;
  for (const [x, y, s] of [[619, 521, 1], [740, 476, 0.78], [824, 527, 0.65]]) {
    ctx.save();
    ctx.translate(x, y);
    ctx.scale(s, s);
    path(ctx, 'M-38 10 Q-26 -15 6 -13 L38 -9 49 -22 61 -21 55 -10 42 3 23 10 H-33Z', accent);
    path(ctx, 'M-33 4 L-35 34 M-18 6 L-16 31 M23 6 L29 35 M34 4 L38 31 M-34 3 L-45 14', null, accent, 5);
    ctx.restore();
  }
  ctx.restore();
}

function egypt(ctx, accent) {
  ctx.save();
  ctx.globalAlpha = 0.21;
  for (let x = 45; x < 1000; x += 42) path(ctx, `M${x} 130 V730`, null, '#6d4639');
  for (let y = 130; y < 730; y += 42) path(ctx, `M0 ${y} H1000`, null, '#6d4639');
  ctx.restore();
  for (const [y, color] of [[175, accent], [190, '#a34434'], [636, '#9e583b'], [649, accent]]) {
    rect(ctx, 0, y, 1000, 5, color);
  }
  for (let x = 42; x < 1000; x += 66) {
    path(ctx, `M${x - 21} 613 q21 -37 42 0 q-21 -11 -42 0Z M${x} 612 v19`, null, accent, 2.5);
  }
}

function han(ctx, accent) {
  for (const y of [180, 497, 657]) path(ctx, `M0 ${y} l370 -2 287 5 343 -2`, null, '#b9b7a2', 2.5);
  ctx.save();
  ctx.globalAlpha = 0.68;
  for (let x = 34; x < 1000; x += 50) {
    path(ctx, `M${x} 555 q18 54 45 11 l-10 41 -28 -13Z M${x + 4} 530 l34 -12 11 14 -34 13`, null, accent, 1.8);
  }
  ctx.restore();
}

function tang(ctx, accent) {
  for (let row = 0; row < 7; row++) {
    const y = row * 16;
    path(ctx, `M0 ${545 + y} C240 ${426 + y} 305 ${693 + y} 579 ${564 + y} Q823 ${476 + y} 1000 ${451 + y}`, null, row % 3 ? '#8b8876' : accent, row % 3 ? 1.3 : 2);
  }
  path(ctx, 'M679 553 Q700 470 808 434 Q771 497 679 553Z M734 503 Q780 543 865 505 Q811 558 734 503Z', null, '#55594d', 2.3);
}

function song(ctx) {
  // Three ink values make a spatial study, with exposed paper at ridgeline and mist.
  path(ctx, 'M0 617 L81 508 123 513 243 347 278 354 332 308 407 429 474 390 530 551 587 596Z', '#bbc0ac');
  path(ctx, 'M330 678 L420 575 445 519 511 449 538 384 568 367 588 301 618 272 646 299 674 232 708 211 747 222 770 207 815 264 849 277 869 332 877 399 909 426 932 506 1000 573 V674Z', '#748478');
  path(ctx, 'M467 649 Q537 573 549 481 L604 426 622 372 677 304 709 272 732 291 754 228 783 272 760 322 766 375 799 414 788 463 828 513 901 607 1000 650Z', '#586f62');
  path(ctx, 'M698 303 L684 349 690 372 670 447 676 488 635 579 629 616 L641 617 658 581 687 498 688 440 703 386 698 351 713 307Z', '#d7dccb');
  for (let i = 0; i < 21; i++) {
    const x = 531 + i * 19;
    const y = 450 + (i * 41) % 135;
    path(ctx, `M${x} ${y} l-10 21 -3 25 -9 12`, null, 'rgba(36,62,53,.32)', 1.5 + (i % 3) * 0.5);
  }
  rect(ctx, 0, 571, 1000, 152, verticalGradient(ctx, [[0, 'rgba(236,232,213,0)'], [0.61, 'rgba(236,232,213,.88)'], [1, 'rgba(236,232,213,0)']], 571, 723));
  path(ctx, 'M922 688 Q921 638 951 607 L956 608 Q940 654 938 688Z M930 648 Q886 629 869 617 Q908 624 934 641Z M941 629 Q961 610 1000 604 V612 Q969 622 941 635Z', '#40554b');
  for (const [x, y, w] of [[876, 615, 41], [911, 625, 38], [955, 616, 49], [970, 605, 62]]) {
    path(ctx, `M${x - w / 2} ${y} q17 -11 ${w} -4 l-11 2 q15 -1 19 2Z`, '#3b5148');
  }
}

function riverside(ctx) {
  path(ctx, 'M0 578 Q284 530 533 591 T1000 523 V685 Q797 726 562 670 T0 690Z', '#93a194');
  for (let x = 20; x < 1000; x += 52) {
    const y = 505 + (x * 7) % 61;
    path(ctx, `M${x - 21} ${y + 4} l20 -20 28 20Z M${x - 13} ${y + 5} v22 h31 v-22`, null, '#725742', 1.7);
  }
  path(ctx, 'M402 654 Q538 519 677 579 L685 591 Q538 545 413 670Z', '#a9744a', '#72533a', 2);
  for (let x = 435; x < 661; x += 24) path(ctx, `M${x} ${564 + (x - 609) ** 2 * 0.0018} v23`, null, '#785638', 2.6);
}

function maya(ctx, accent) {
  for (const x of [33, 333, 668, 962]) rect(ctx, x, 133, 2.5, 551, accent);
  rect(ctx, 0, 166, 1000, 5, accent);
  rect(ctx, 0, 627, 1000, 4, accent);
  for (let x = 36; x < 985; x += 80) {
    const y = 601;
    path(ctx, `M${x} ${y} h43 M${x} ${y + 8} h43`, null, accent, 4.2);
    for (let n = 0; n < 1 + (x % 3); n++) ellipse(ctx, x + n * 10 + 7, y - 12, 3.5, 3.5, accent);
  }
}

function mughal(ctx, accent) {
  const gold = 'rgba(225,194,109,.64)';
  for (const y of [171, 202, 654, 681]) path(ctx, `M28 ${y} H972`, null, gold, 1.9);
  for (let x = 34; x < 970; x += 34) {
    const yy = 185 + (x % 4) * 3;
    path(ctx, `M${x - 15} ${yy} q10 -12 15 0 q5 12 15 0 M${x - 15} 670 q10 -12 15 0 q5 12 15 0`, null, gold, 1.3);
  }
  for (const [x, y, s] of [[650, 608, 1.05], [763, 616, 0.82], [859, 621, 0.96]]) {
    ctx.save();
    ctx.translate(x, y);
    ctx.scale(s, s);
    path(ctx, 'M-20 0 Q-13 -59 0 -123 Q16 -72 20 0Z', '#406a59', accent, 1.1);
    path(ctx, 'M0 -111 V0 M-11 -48 Q0 -41 10 -53 M-16 -16 Q-1 -12 15 -24', null, gold, 1.4);
    ctx.restore();
  }
}

function freehand(ctx, accent) {
  path(ctx, 'M687 569 Q768 495 874 499 Q749 524 720 580 L681 639 666 644Z', '#536158');
  path(ctx, 'M827 519 Q866 446 910 453 Q874 483 825 530Z M780 547 Q896 531 964 563 Q876 564 779 558Z', '#879184');
  path(ctx, 'M606 677 Q684 660 738 663 Q707 674 640 679Z', '#a5a592');
  rect(ctx, 936, 589, 21, 21, accent);
  path(ctx, 'M940 605 v-11 h13 v11Z M946 595 v8 M941 600 h12', null, '#ecd9ba', 1.1);
}

function shadowPuppet(ctx, accent) {
  const glow = ctx.createRadialGradient(544, 550, 9, 544, 550, 574);
  glow.addColorStop(0, '#edbd61');
  glow.addColorStop(0.45, '#b26d39');
  glow.addColorStop(1, 'rgba(72,37,30,0)');
  rect(ctx, 0, 96, 1000, 755, glow);
  path(ctx, 'M0 184 Q473 231 1000 184 M0 646 Q474 620 1000 646', null, accent, 2);
  for (let x = 21; x < 1000; x += 37) ellipse(ctx, x, 652 + Math.sin(x / 185) * 9, 2, 2, '#efbe5e');
}

function woodblock(ctx, accent) {
  path(ctx, 'M0 553 Q145 537 271 487 L372 373 430 342 500 394 575 414 699 532 1000 554 V619 H0Z', '#557a87');
  path(ctx, 'M369 379 L430 342 504 396 483 390 466 398 449 383 433 393 404 378 385 384Z', '#e7e6cf');
  path(ctx, 'M0 562 Q130 522 289 573 T652 568 T1000 549 V675 H0Z', '#75979a', '#304f61', 2);
  for (let y = 587; y < 688; y += 17) path(ctx, `M0 ${y} Q289 ${y - 69} 544 ${y - 7} T1000 ${y - 21}`, null, '#c6d6c5', 1);
  ellipse(ctx, 803, 445, 47, 47, accent);
}

function night(ctx, accent) {
  for (let n = 0; n < 13; n++) {
    const x = 57 + n * 73;
    const y = 413 + (n * 27) % 151;
    for (let r = 9; r < 37; r += 9) ellipse(ctx, x, y, r * 1.2, r, null, r < 14 ? accent : '#57799a', 2);
  }
  for (let j = 0; j < 6; j++) {
    const y = 529 + j * 13;
    path(ctx, `M0 ${y} Q277 ${y + 120} 508 ${y - 27} T1000 ${y - 7}`, null, j % 2 ? '#315f89' : '#486786', 4.2);
  }
  path(ctx, 'M530 695 Q511 647 534 619 L551 539 576 590 613 637 620 693Z M637 686 H973 L949 648 926 653 895 635 869 652 817 650 793 621 769 651 740 646 715 664Z', '#182a48');
}

function scream(ctx) {
  const stripe = ['#f1ac6f', '#bd5c49', '#8a4252', '#d98555', '#702f43'];
  for (let i = 0; i < stripe.length; i++) {
    const y = 361 + i * 50;
    path(ctx, `M0 ${y} C205 ${y - 69} 345 ${y + 97} 527 ${y + 21} S772 ${y + 8} 1000 ${y - 36}`, null, stripe[i], 31);
  }
  path(ctx, 'M0 683 L1000 565 M0 717 L1000 581 M0 738 L1000 594', null, '#4b333d', 6);
}

function cinema(ctx, accent) {
  path(ctx, 'M0 168 H1000 V687 H0Z', '#3c4442');
  path(ctx, 'M416 666 L533 397 926 208 1000 219 V652 L766 766Z', '#70716a');
  path(ctx, 'M452 680 L661 538 H736 V502 H811 V466 H886 V430 H961 V394 H1000', null, '#222b2b', 13);
  for (let x = 10; x < 1000; x += 40) {
    round(ctx, x, 186, 20, 15, 2, accent);
    round(ctx, x, 648, 20, 15, 2, accent);
  }
}

function scope(ctx, accent) {
  const x = 704;
  const y = 513;
  ellipse(ctx, x, y, 151, 151, '#0b2118', '#263f30', 14);
  ctx.save();
  ctx.beginPath();
  ctx.arc(x, y, 149, 0, Math.PI * 2);
  ctx.clip();
  ctx.globalAlpha = 0.30;
  for (let i = -6; i <= 6; i++) {
    path(ctx, `M${x + i * 24} ${y - 151} v302 M${x - 151} ${y + i * 24} h302`, null, accent, i === 0 ? 1.7 : 0.7);
  }
  ctx.restore();
  path(ctx, 'M565 513 H843 M704 374 V652', null, '#5c9165', 1);
}

function pixel(ctx, accent) {
  for (const [x, y, w] of [[78, 511, 142], [341, 481, 106], [677, 447, 177]]) {
    rect(ctx, x, y, w, 14, '#8cb4c4');
    rect(ctx, x + 19, y - 14, w - 36, 14, '#a9cbd6');
  }
  for (let n = 0; n < 12; n++) {
    const x = n * 96;
    const h = 30 + (n * 49) % 96;
    rect(ctx, x, 694 - h, 82, h, '#355a58');
    rect(ctx, x + 8, 700 - h, 66, 7, '#638065');
  }
  for (let n = 0; n < 4; n++) {
    rect(ctx, 694 + n * 36, 559, 17, 23, accent);
    rect(ctx, 697 + n * 36, 561, 4, 17, '#fff4b6');
  }
}

function desktop(ctx) {
  round(ctx, 505, 326, 419, 317, 7, '#d2d9cd', '#385268', 3);
  rect(ctx, 509, 329, 411, 24, '#596c9a');
  for (let n = 0; n < 3; n++) rect(ctx, 871 + n * 15, 335, 9, 9, '#d6ddda');
  rect(ctx, 519, 399, 389, 202, '#e4e9dd');
  for (let row = 0; row < 4; row++) rect(ctx, 532 + row * 8, 422 + row * 30, 104 + row * 24, 5, '#94a5ae');
  for (let y = 470; y < 581; y += 5) {
    for (let x = 735; x < 845; x += 5) {
      if ((x * 11 + y * 17) % 13 < 6) rect(ctx, x, y, 2, 2, '#71849b');
    }
  }
}

function vapor(ctx) {
  const neon = verticalGradient(ctx, [[0, 'rgba(246,112,195,0)'], [0.54, '#db74b6'], [1, '#6a5398']], 381, 633);
  rect(ctx, 0, 382, 1000, 252, neon);
  ellipse(ctx, 771, 534, 104, 104, '#f39bb3');
  for (let y = 542; y < 632; y += 15) rect(ctx, 665, y, 214, 5 + (y - 542) / 21, '#714581');
  for (let x = -800; x < 1900; x += 137) path(ctx, `M558 626 L${x} 1000`, null, 'rgba(176,142,224,.65)', 1.2);
  for (let n = 0; n < 8; n++) {
    const y = 642 + n * n * 7;
    path(ctx, `M0 ${y} H1000`, null, '#9f78cc', 1.2);
  }
}

function portrait(ctx, accent) {
  // Abstract feed light around a portrait guide. Camera/compositor own the crop.
  const glow = ctx.createRadialGradient(500, 501, 0, 500, 501, 504);
  glow.addColorStop(0, '#5563a2');
  glow.addColorStop(0.48, '#383376');
  glow.addColorStop(1, 'rgba(18,19,43,0)');
  rect(ctx, 0, 0, 1000, 1000, glow);
  rect(ctx, 0, 667, 1000, 202, '#222848');
  path(ctx, 'M0 681 Q397 620 530 703 T1000 672', null, '#5868a5', 2.4);
  ctx.save();
  ctx.globalAlpha = 0.46;
  for (const [x, y, direction] of [[306, 241, 1], [694, 241, -1], [306, 638, 1], [694, 638, -1]]) {
    const yDir = y < 400 ? 1 : -1;
    path(ctx, `M${x + direction * 25} ${y} H${x} v${25 * yDir}`, null, accent, 2.6);
  }
  ctx.restore();
  for (const [x, y, r] of [[748, 580, 19], [780, 529, 9], [840, 514, 23], [171, 591, 13], [110, 506, 32]]) {
    ellipse(ctx, x, y, r, r, '#5962a3');
    ellipse(ctx, x - 3, y - 4, r * .55, r * .55, null, '#8386b8', 1);
  }
}

function code(ctx, accent) {
  for (let n = 0; n < 8; n++) {
    const y = 431 + n * 27;
    const x = 572 + (n % 3) * 15;
    rect(ctx, 545, y + 3, 7, 3, '#567887');
    rect(ctx, x, y, n % 2 ? 24 : 35, 3, accent);
    rect(ctx, x + 42, y, 35 + (n * 17) % 91, 3, n % 2 ? '#7f87a9' : '#a5876a');
    rect(ctx, x + 139, y, 50 - (n * 7) % 38, 3, '#5b7c87');
  }
  path(ctx, 'M508 376 V666 M0 680 H1000', null, '#315467', 2);
}

const motifs = [
  rock, egypt, han, tang, song, riverside, maya, mughal, freehand, shadowPuppet,
  woodblock, night, scream, cinema, scope, pixel, desktop, vapor, portrait, code,
];

export function paintPanelTitle(ctx, scene, info = {}) {
  const [, , card, ink, accent] = palettes[scene.index];
  const x = info.titleX ?? 132;
  const y = info.titleY ?? 295;
  const width = Math.min(420, Math.max(311, scene.en.length * 9 + 40));
  const digital = scene.index >= 14;
  ctx.save();
  ctx.translate(x, y);
  if (digital) {
    round(ctx, 0, 0, width, 123, 9, card, accent, 1.5);
  } else {
    path(ctx, `M3 2 L${width - 11} 0 ${width} 10 ${width - 1} 120 11 124 0 115Z`, card, accent, 1.2);
  }
  text(ctx, scene.zh, 19, 48, { size: 40, fill: ink, weight: 600, face: digital ? SANS : SERIF });
  path(ctx, `M20 64 H${width - 20}`, null, accent, 1.3);
  text(ctx, scene.en, 20, 86, { size: 16, fill: ink, face: digital ? MONO : SERIF, maxWidth: width - 40 });
  text(ctx, scene.era, 20, 108, { size: 17, fill: ink, face: SANS });
  ctx.restore();
}

export function paintPanel(ctx, scene, info = {}) {
  const [sky, base, , , accent] = palettes[scene.index];
  ctx.save();
  rect(ctx, 0, 0, 1000, 1000, verticalGradient(ctx, [[0, sky], [0.54, sky], [1, base]]));
  motifs[scene.index](ctx, accent);
  if (scene.index <= 13 && scene.index !== 10) {
    grain(ctx, 2287 + 149 * scene.index, 'rgba(31,28,23,.13)', 'rgba(255,245,221,.20)', 560);
  }
  if (info.title !== false) paintPanelTitle(ctx, scene, info);
  ctx.restore();
}
