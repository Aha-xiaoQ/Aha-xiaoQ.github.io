import { cachedLayer, ellipse, grain, mulberry, opacityWindow, path, plot, rect, seeded, titlePlate, verticalGradient } from './common.js';

const PAPER = '#efe8d7';
const INK = '#33342e';

const page = cachedLayer(ctx => {
  rect(ctx, 0, 0, 1000, 1000, verticalGradient(ctx, [[0, '#e3dac4'], [.36, '#f3eddf'], [.68, '#f0e9d9'], [1, '#e5dac2']]));
  const paper = ctx.createRadialGradient(463, 498, 155, 463, 498, 775);
  paper.addColorStop(0, 'rgba(201,181,139,0)');
  paper.addColorStop(1, 'rgba(146,123,84,.15)');
  rect(ctx, 0, 0, 1000, 1000, paper);
  const stone = 'M704 788 Q717 726 767 706 Q801 693 824 703 Q842 714 829 732 Q825 747 847 752 Q876 749 884 770 Q840 778 786 784Z';
  path(ctx, stone, '#67685c');
  ctx.save();
  ctx.clip(new Path2D(stone));
  path(ctx, 'M691 786 Q753 772 772 737 Q786 700 840 695 Q838 714 812 720 Q809 744 779 773Z', '#343831');
  path(ctx, 'M754 793 Q784 770 803 738 L822 716 Q833 729 820 746 Q805 761 825 787Z', '#9a9683');
  mulberry(ctx, [701, 693, 184, 102], 741, 157, ['rgba(224,210,173,.50)', 'rgba(47,49,42,.65)']);
  ctx.restore();
  path(ctx, 'M732 758 C739 718 732 673 740 637 C746 606 769 568 800 543 Q766 595 759 630 Q749 686 753 721 L747 755Z', '#424741');
  path(ctx, 'M738 671 Q708 649 695 617 Q721 634 744 654Z M748 641 Q762 606 804 597 Q786 619 751 649Z M742 708 Q764 686 804 685 Q785 699 746 717Z', '#3e453f');
  path(ctx, 'M131 836 Q173 817 220 817 Q266 825 289 809 Q265 833 230 835 Q179 831 137 844Z', 'rgba(83,83,66,.28)');
  path(ctx, 'M831 804 Q886 802 922 781 Q900 800 870 806Z', 'rgba(75,77,62,.36)');
  grain(ctx, 9431, 'rgba(102,91,67,.12)', 'rgba(254,248,223,.47)', 1070);
  mulberry(ctx, [0, 0, 1000, 1000], 2347, 1541, ['rgba(111,97,67,.07)', 'rgba(255,252,237,.34)']);
});

function riceInk(ctx, info) {
  const floor = info.floorAt ?? (() => 760);
  const random = seeded(7270);
  for (let x = 0; x < 1000; x += 26) {
    const y = floor(x);
    const shiver = random() * 5;
    plot(ctx, [[x, y + shiver], [x + 12, floor(x + 12) + shiver * .4], [x + 23, floor(x + 23) + shiver]], 'rgba(72,71,60,.51)', .48 + random());
  }
}

export const bada = {
  background(ctx, info) {
    page(ctx);
    riceInk(ctx, info);
    const t = info.local;
    const shimmer = opacityWindow(t, 2.22, 2.69, 3.98, 4.48);
    ctx.save();
    ctx.globalAlpha *= shimmer * .42;
    ellipse(ctx, 716, 710, 16 + 4 * shimmer, 1.5 + shimmer, null, '#636b5a', 1.13);
    ellipse(ctx, 727, 714, 25 + 8 * shimmer, 2.18 + shimmer, null, '#77785f', .71);
    ctx.restore();
  },
  title: titlePlate({paper: PAPER, ink: INK, frame: '#929077', lines: false, mark(ctx, x, y) {
    rect(ctx, x - 11, y - 13, 21, 21, '#8c4139');
    path(ctx, `M${x - 6} ${y + 3} v-12 h12 v12Z m3 -2 7 -7 m-7 1 h7`, null, '#efe1c4', .9);
  }}),
};
