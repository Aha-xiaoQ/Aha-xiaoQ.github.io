import { cachedLayer, ellipse, grain, mulberry, opacityWindow, path, plot, rect, register, road, round, seeded, titlePlate, verticalGradient } from './common.js';

const UMBER = '#39221a';
const GOLD = '#ce9451';

function perforatedLeaf(ctx, x, y, scale, mirror, seed) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale * mirror, scale);
  const form = 'M-55 11 Q-78 -21 -77 -70 Q-78 -106 -60 -140 Q-30 -177 0 -233 Q25 -177 68 -137 Q82 -96 78 -64 Q78 -26 56 11Z';
  path(ctx, form, '#613520', '#3c251d', 4.1);
  path(ctx, 'M-48 3 Q-69 -32 -69 -74 Q-70 -104 -51 -137 Q-30 -163 0 -217 Q32 -162 60 -132 Q73 -91 67 -61 Q66 -24 49 4Z', '#a36235', '#e5a75a', 1.25);
  path(ctx, 'M0 1 V-186 M0 -149 Q-21 -143 -41 -120 M0 -122 Q24 -117 47 -90 M0 -91 Q-36 -90 -59 -49 M0 -62 Q29 -60 56 -27 M0 -32 Q-25 -29 -43 -11', null, '#562b1d', 4.1);
  ctx.save();
  ctx.clip(new Path2D(form));
  const random = seeded(seed);
  for (let i = 0; i < 116; i++) {
    const py = -200 + 205 * random();
    const px = (random() - .5) * (16 + (1 - Math.abs((py + 100) / 117)) * 125);
    const radius = .8 + random() ** 1.8 * 2.2;
    ellipse(ctx, px, py, radius * .85, radius, '#e1a35b');
  }
  ctx.restore();
  plot(ctx, [[0, 7], [2, 71]], '#523019', 3);
  ctx.restore();
}

function buttonhole(ctx) {
  path(ctx, 'M-12 3 l7 -6 6 6 6 -6 6 6 M-11 -5 l6 -6 6 6 6 -6 6 6', null, '#bc774e', 1.3);
}

const stage = cachedLayer(ctx => {
  rect(ctx, 0, 0, 1000, 1000, '#2e211c');
  const scrim = 'M0 211 Q125 193 222 211 Q452 244 654 210 Q836 185 1000 215 V795 Q765 808 596 804 Q312 792 0 819Z';
  path(ctx, scrim, verticalGradient(ctx, [[0, '#9e592e'], [.29, '#b0703e'], [.59, '#d39451'], [.77, '#b1723e'], [1, '#6a3d29']]));
  ctx.save();
  ctx.clip(new Path2D(scrim));
  for (let x = 3; x < 1000; x += 4) plot(ctx, [[x, 190], [x + Math.sin(x / 111) * 9, 830]], 'rgba(72,43,27,.13)', .51);
  for (let y = 218; y < 829; y += 5) plot(ctx, [[0, y], [1000, y + Math.sin(y * .06) * 5]], 'rgba(250,198,123,.14)', .67);
  mulberry(ctx, [0, 196, 1000, 622], 4114, 1000, ['rgba(106,65,41,.20)', 'rgba(230,168,98,.20)']);
  ctx.restore();
  const surround = ctx.createRadialGradient(475, 581, 85, 475, 552, 668);
  surround.addColorStop(0, 'rgba(55,31,22,0)');
  surround.addColorStop(.64, 'rgba(52,28,22,.11)');
  surround.addColorStop(1, 'rgba(36,23,21,.59)');
  rect(ctx, 0, 0, 1000, 1000, surround);
  register(ctx, 187, 31, ['#4c2a22', '#8d5240'], 29, buttonhole);
  register(ctx, 818, 39, ['#44291e', '#87513a'], 33, buttonhole);
  grain(ctx, 4911, 'rgba(12,5,3,.24)', 'rgba(246,174,112,.16)', 1310);
});

function lamp(ctx, t) {
  const jitter = Math.sin(t * 38.7) * 2.2 + Math.sin(t * 79.5) * 1.9;
  const glow = ctx.createRadialGradient(470 + 1.4 * jitter, 594, 15, 470, 591, 514);
  glow.addColorStop(0, 'rgba(255,219,137,.70)');
  glow.addColorStop(.28, 'rgba(244,172,93,.31)');
  glow.addColorStop(1, 'rgba(238,149,71,0)');
  rect(ctx, 0, 216, 1000, 592, glow);
  ctx.save();
  ctx.translate(71, 848);
  plot(ctx, [[-25, 15], [-5, 12], [-2, -53], [-4, -69]], '#36231c', 5.3);
  path(ctx, 'M-29 -68 Q0 -46 28 -68 Q34 -78 8 -76 Q-13 -79 -29 -68Z', '#895f38', '#472e20', 1.8);
  path(ctx, 'M-17 -69 Q0 -63 23 -71', null, '#c8a061', .95);
  const flame = ctx.createRadialGradient(jitter * .5, -86, 1.3, 0, -84, 25);
  flame.addColorStop(0, '#fff0b2');
  flame.addColorStop(.43, '#eeb85b');
  flame.addColorStop(1, 'rgba(244,128,58,0)');
  rect(ctx, -28, -118, 58, 52, flame);
  ctx.translate(jitter, 0);
  path(ctx, 'M-5 -76 Q-12 -87 3 -98 Q0 -90 8 -84 Q12 -76 4 -75Z', '#f5cb76', null);
  ctx.restore();
}

function fingers(ctx, x, y, scale, turn, grip) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale * turn, scale);
  ctx.rotate(.19 * grip);
  path(ctx, 'M-18 43 L-21 18 Q-22 2 -16 -8 Q-11 -14 -7 -8 L-2 2 -5 -14 Q-3 -26 3 -19 L5 -4 8 -19 Q13 -26 15 -17 L15 -3 18 -13 Q24 -19 25 -10 L25 9 Q31 4 35 9 Q32 20 24 30 L19 44Z', '#442a20', '#2b211a', 2);
  path(ctx, 'M-14 11 Q-8 14 -6 3 M4 0 v17 m11 -17 2 11 m9 -7 1 6 m-34 20 q18 -2 30 -5', null, '#885938', 1.1);
  ctx.restore();
}

export const wayang = {
  background(ctx, info) {
    stage(ctx);
    const t = info.local;
    lamp(ctx, t);
    const tilt = .06 * opacityWindow(t, 2.32, 2.45, 3.75, 4.08);
    ctx.save();
    ctx.translate(182, 739);
    ctx.rotate(-tilt);
    perforatedLeaf(ctx, 0, 0, .89, 1, 3892);
    ctx.restore();
    ctx.save();
    ctx.translate(849, 728);
    ctx.rotate(tilt);
    perforatedLeaf(ctx, 0, 0, .77, -1, 8173);
    ctx.restore();
    road(ctx, info, {base: 'rgba(109,63,38,.32)', edge: '#806044', rim: '#cb8950', width: 12});

    const discrete = Math.floor(t * 10) / 10;
    const x = info.riderX ?? discrete * 1000 / 6;
    const yy = info.riderY ?? 693;
    const scale = info.poseScale ?? .66;
    const gait = Math.sin(discrete * Math.PI * 2);
    const trunkEnd = [x - 66 + gait * 6, 915];
    const pedalEnd = [x + 136 - gait * 4, 936];
    if (x > -170 && x < 1170) {
      plot(ctx, [[x - 16 * scale, yy - 191 * scale], trunkEnd], '#583422', 3.9);
      plot(ctx, [[x + 50 * scale, yy - 107 * scale], pedalEnd], '#643c26', 2.75);
      plot(ctx, [[x - 17 * scale, yy - 188 * scale], [trunkEnd[0] + 1.4, trunkEnd[1]]], '#bc7f4c', 1.04);
      fingers(ctx, trunkEnd[0], trunkEnd[1], 1.08, 1, gait);
      fingers(ctx, pedalEnd[0], pedalEnd[1], .79, -1, -gait);
    }
  },
  foreground(ctx) {
    path(ctx, 'M0 955 Q180 946 273 958 Q609 933 810 956 L1000 965 V1000 H0Z', '#2e221c', '#6a402a', 1.55);
  },
  title: titlePlate({paper: '#522d22', ink: '#ffdda2', frame: GOLD, lines: true, mark(ctx, x, y) {
    round(ctx, x - 7, y - 12, 13, 17, 4, null, GOLD, 1.1);
    ellipse(ctx, x, y - 6, 1.7, 1.7, GOLD);
  }}),
};
