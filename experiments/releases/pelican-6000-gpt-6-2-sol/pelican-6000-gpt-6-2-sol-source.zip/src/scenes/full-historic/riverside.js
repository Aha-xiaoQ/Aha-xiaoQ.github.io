import { cachedLayer, ellipse, grain, mulberry, path, plot, rect, road, seeded, titlePlate, verticalGradient } from './common.js';

const OUTLINE = '#5a4d3c';
const RIVER = '#8d9b85';

function roof(ctx, x, y, width, wall, tile, depth) {
  ctx.save();
  ctx.translate(x, y);
  const eave = width / 2;
  plot(ctx, [[-eave + 10, -2], [eave - 8, -2], [eave - 8, 58], [-eave + 10, 58]], OUTLINE, 1.12, wall);
  plot(ctx, [[-eave + 5, 52], [eave - 4, 51], [eave + 4, 60], [-eave, 63]], null, 0, 'rgba(105,94,67,.23)');
  const yRidge = -depth;
  plot(ctx, [[-eave - 7, 5], [-eave * .69, -4], [-eave * .49, yRidge + 2], [eave * .45, yRidge], [eave * .76, -1], [eave + 13, 4], [eave * .26, 10], [-eave * .72, 9]], OUTLINE, 1.42, tile);
  for (let n = -eave * .44; n < eave * .43; n += 5) plot(ctx, [[n, yRidge + 4], [n * 1.7, 7]], 'rgba(60,56,46,.49)', .72);
  for (let n = -eave + 17; n < eave - 15; n += 21) {
    rect(ctx, n, 22, 15, 25, '#8c7460');
    for (let a = 3; a < 13; a += 4) plot(ctx, [[n + a, 22], [n + a, 48]], '#574d42', .62);
  }
  ctx.restore();
}

function willow(ctx, x, y, scale, seed) {
  const random = seeded(seed);
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale, scale);
  path(ctx, 'M-8 0 Q-1 -55 -3 -93 Q-19 -123 -35 -142 Q-7 -127 1 -107 Q4 -135 26 -158 Q14 -130 10 -105 Q17 -146 51 -155 Q29 -136 19 -101 Q9 -77 10 0Z', '#75654e');
  for (let i = 0; i < 84; i++) {
    const px = -64 + random() * 138;
    const py = -161 + random() * 41;
    const l = 5 + random() * 27;
    plot(ctx, [[px - l * .2, py], [px - 3, py + l * .75], [px + l * .17, py + l]], i % 3 ? 'rgba(97,109,76,.70)' : 'rgba(93,105,81,.46)', .64 + random() * .7);
  }
  ctx.restore();
}

const paintedBanks = cachedLayer(ctx => {
  rect(ctx, 0, 0, 1000, 1000, verticalGradient(ctx, [[0, '#d6c7a1'], [.42, '#ede2c4'], [.69, '#dad0af'], [1, '#c9b693']]));
  path(ctx, 'M0 622 Q69 615 118 651 Q231 769 388 753 Q481 748 563 723 Q717 672 866 601 L1000 567 V918 Q883 983 755 1000 H285 Q164 974 120 880 Q96 824 0 794Z', RIVER);
  path(ctx, 'M0 620 Q69 613 119 652 Q239 764 391 750 Q500 744 559 725 Q718 671 865 601 L1000 569', null, 'rgba(88,96,72,.63)', 2.1);
  path(ctx, 'M0 694 Q102 670 218 649 Q290 628 370 659 L283 711 Q157 738 0 739Z M789 692 Q876 601 1000 618 V767 Q892 732 790 744Z', '#b3a480', '#84775b', 1.65);
  for (const [x, y, w, wall, tile, h] of [
    [-17, 464, 100, '#c4a586', '#656655', 34], [64, 477, 96, '#c5b491', '#626256', 37], [142, 494, 109, '#c1a784', '#75684e', 28],
    [226, 495, 100, '#c7b295', '#786c52', 28], [306, 515, 78, '#d1b890', '#6b6654', 34], [376, 530, 83, '#c9b48d', '#736c59', 24],
    [595, 489, 90, '#c3b491', '#7c775c', 26], [670, 498, 81, '#baa785', '#6f6f54', 27], [748, 486, 90, '#cbb48f', '#686953', 27],
    [822, 471, 87, '#a48f71', '#5a6657', 40], [897, 489, 92, '#c0ab88', '#776b51', 31], [974, 470, 112, '#c2ad88', '#6c6a54', 33],
    [26, 606, 119, '#d2b286', '#766351', 62], [114, 633, 94, '#d1b28c', '#706049', 35], [987, 638, 117, '#bea181', '#6b6352', 67],
  ]) roof(ctx, x, y, w, wall, tile, h);
  for (const tree of [[190, 605, .73, 904], [376, 677, .83, 905], [589, 591, .78, 906], [931, 627, 1, 907], [983, 659, 1.09, 908]]) willow(ctx, ...tree);
  mulberry(ctx, [0, 0, 1000, 1000], 7214, 2048, ['rgba(121,102,70,.13)', 'rgba(245,232,195,.49)']);
  grain(ctx, 4651, 'rgba(91,71,50,.12)', 'rgba(246,225,182,.39)', 720);
});

function person(ctx, x, y, scale, t, riderX, color, role) {
  const gaze = 1 / (1 + Math.exp((riderX - x + 20) * .037));
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale, scale);
  path(ctx, 'M-11 -31 L-8 -48 0 -52 11 -48 17 -31 11 -19 10 -4 2 -2 -2 -16 -4 -6 -14 -5 -13 -19Z', color, OUTLINE, 1.5);
  path(ctx, 'M-8 -42 L2 -32 9 -40 M-2 -28 L1 -15 M-8 -20 L10 -20 M-9 -4 h-7 m25 0 h7', null, OUTLINE, 1.1);
  const arm = Math.exp(-(((riderX - x) / 109) ** 2));
  plot(ctx, [[-9, -42], [-16 - arm * 4, -31], [-20 - arm * 14, -35 - arm * 13]], OUTLINE, 2.7);
  ctx.save();
  ctx.translate(5 - 10 * gaze, -59);
  ctx.scale(1 - gaze * 2 < 0 ? -1 : 1, 1);
  ellipse(ctx, 0, 0, 8.1, 7.8, '#b6966c', OUTLINE, 1.22);
  path(ctx, role === 2 ? 'M-18 -3 Q1 -16 17 -3Z M-13 -2 H18' : 'M-9 -4 l1 -9 12 -1 5 10Z', role === 2 ? '#957953' : '#4f4a40', OUTLINE, .9);
  path(ctx, 'M3 -1 h3 m1 2 2 1 -2 2', null, OUTLINE, .9);
  ctx.restore();
  if (role === 1) {
    plot(ctx, [[10, -35], [17, -24], [31, -29 + Math.sin(t * 3) * 1.75]], OUTLINE, 1.3);
    path(ctx, 'M22 -30 Q40 -35 42 -29 L36 -11 H26Z', '#9d835f', OUTLINE, 1);
  }
  ctx.restore();
}

function pulseWater(ctx, t) {
  for (let n = 0; n < 29; n++) {
    const x = (n * 199 + t * (4 + n % 4)) % 1000;
    const y = 815 + (n * 56) % 174;
    plot(ctx, [[x, y], [x + 15, y - 1.6], [x + 38 + n % 12, y]], 'rgba(237,227,186,.51)', 1.24);
  }
  ctx.save();
  ctx.translate(620 - t * 14, 839 + 2 * Math.sin(t * 4));
  path(ctx, 'M-98 6 Q-32 18 97 4 L60 22 Q-31 30 -81 19Z', '#715a41', OUTLINE, 1.9);
  path(ctx, 'M-24 7 Q-14 -25 10 -27 Q42 -26 62 7Z M-20 7 Q-8 -14 10 -14 Q26 -15 52 6', '#b8a479', OUTLINE, 1.65);
  path(ctx, 'M-76 9 H84 M-82 15 Q1 25 72 15', null, '#ae936d', .98);
  person(ctx, -57, 4, .68, t, 580 - t * 2, '#726e58', 2);
  plot(ctx, [[-57, -31], [-28, -1], [-9, 44]], '#675640', 1.9);
  ctx.restore();
}

function bridge(ctx, floor, front) {
  const top = [];
  const span = [];
  for (let x = 183; x <= 826; x += 9) {
    const y = floor(x);
    top.push([x, y + 4]);
    span.push([x, y + 31 + 97 * ((x - 505) / 323) ** 2]);
  }
  if (!front) {
    plot(ctx, top.concat(span.toReversed()), '#5a493a', 1.9, '#a17c59');
    plot(ctx, span, '#57483b', 3.8);
    for (let i = 1; i < top.length - 1; i += 3) {
      const [x, y] = top[i];
      plot(ctx, [[x + 11, y], [x - 11, span[i][1]]], '#6f5641', 2.2);
      plot(ctx, [[x - 9, y], [x + 8, span[i][1]]], '#bc9570', 1.2);
    }
  }
  const height = front ? 9.6 : 24;
  const ticks = front ? 22 : 35;
  const rail = top.map(([x, y]) => [x, y - height]);
  plot(ctx, rail, '#634f3c', front ? 1.9 : 2.45);
  for (let x = 187; x <= 819; x += ticks) {
    plot(ctx, [[x, floor(x) + 4], [x, floor(x) + 3 - height]], '#765f48', front ? 1.4 : 1.95);
  }
}

export const riverside = {
  background(ctx, info) {
    const t = info.local;
    const floor = info.floorAt ?? (() => 760);
    const rider = info.riderX ?? t * 1000 / 6;
    paintedBanks(ctx);
    pulseWater(ctx, t);
    bridge(ctx, floor, false);
    road(ctx, info, {base: '#b19367', edge: '#826648', rim: '#c4a47c', width: 9});
    for (const [x, z, scale, ink, role] of [[151, 24, .88, '#8e745b', 1], [271, 36, .91, '#677865', 0], [403, 24, 1.05, '#947058', 1], [676, 28, .91, '#697655', 0], [749, 32, 1, '#a4825f', 2], [876, 40, .96, '#8b715d', 1]]) {
      person(ctx, x, floor(x) - z, scale, t, rider, ink, role);
    }
  },
  foreground(ctx, info) {
    bridge(ctx, info.floorAt ?? (() => 760), true);
  },
  title: titlePlate({paper: '#e4d0ab', ink: '#513e35', frame: '#9b684e', lines: true}),
};
