import { egypt } from './egypt.js';
import { han } from './han.js';
import { tang } from './tang.js';
import { riverside } from './riverside.js';
import { maya } from './maya.js';
import { mughal } from './mughal.js';
import { bada } from './bada.js';
import { wayang } from './wayang.js';
import { ukiyo } from './ukiyo.js';

export const HISTORIC = new Map([
  [1, egypt],
  [2, han],
  [3, tang],
  [5, riverside],
  [6, maya],
  [7, mughal],
  [8, bada],
  [9, wayang],
  [10, ukiyo],
]);
