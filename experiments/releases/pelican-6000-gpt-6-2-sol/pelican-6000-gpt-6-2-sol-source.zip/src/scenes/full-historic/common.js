export { ellipse, grain, path, rect, round, text, verticalGradient } from '../drawing.js';
export { cachedLayer, groundTrace, opacityWindow, plot, scratch, seeded } from '../historical-paint.js';
import { SANS, SERIF, path, rect, text } from '../drawing.js';
import { groundTrace, plot, seeded } from '../historical-paint.js';

export function road(ctx, info, {base = '#c7b594', edge = '#544b35', rim = null, width = 17} = {}) {
  const y = info.floorAt ?? (() => 760);
  groundTrace(ctx, y, {offset: width / 2 - 1, ink: base, width});
  groundTrace(ctx, y, {ink: edge, width: 1.9});
  if (rim) groundTrace(ctx, y, {offset: 4.2, ink: rim, width: 1.45});
}

export function mulberry(ctx, box, seed, count, tones) {
  const random = seeded(seed);
  const [x0, y0, w, h] = box;
  ctx.save();
  for (const tone of tones) {
    ctx.strokeStyle = tone;
    ctx.lineCap = 'round';
    ctx.lineWidth = .74;
    ctx.beginPath();
    for (let i = 0; i < count; i++) {
      const x = x0 + random() * w;
      const y = y0 + random() * h;
      const length = .35 + random() ** 3 * 17;
      ctx.moveTo(x, y);
      ctx.quadraticCurveTo(x + length * .64, y + (random() - .5) * 3.7, x + length, y + random() * 1.4);
    }
    ctx.stroke();
  }
  ctx.restore();
}

export function register(ctx, y, height, palette, pitch, draw) {
  rect(ctx, 0, y, 1000, height, palette[0]);
  rect(ctx, 0, y, 1000, 2, palette[1]);
  rect(ctx, 0, y + height - 2, 1000, 2, palette[1]);
  ctx.save();
  for (let x = pitch / 2; x < 1000; x += pitch) {
    ctx.save();
    ctx.translate(x, y + height / 2);
    draw(ctx, palette);
    ctx.restore();
  }
  ctx.restore();
}

export function titlePlate(options) {
  const {paper, ink, frame, mark, lines = false, face = SERIF} = options;
  return (ctx, info) => {
    const {scene, titleX: x = 132, titleY: y = 295} = info;
    const width = Math.max(252, Math.min(363, scene.en.length * 9 + 41));
    ctx.save();
    ctx.translate(x, y);
    path(ctx, `M2 1 H${width - 8} l8 9 V115 l-9 4 H5 l-5 -8 V8Z`, paper, frame, 1.5);
    if (lines) path(ctx, `M7 11 l6 -5 H${width - 11} M7 110 H${width - 9}`, null, frame, .85);
    text(ctx, scene.zh, 16, 45, {size: 38, fill: ink, weight: 600, face});
    plot(ctx, [[16, 56], [width - 18, 56]], frame, 1.1);
    text(ctx, scene.en, 17, 78, {size: 18, fill: ink, face, maxWidth: width - 30});
    text(ctx, scene.era, 17, 100, {size: 16, fill: ink, face: SANS});
    mark?.(ctx, width - 28, 90);
    ctx.restore();
  };
}
