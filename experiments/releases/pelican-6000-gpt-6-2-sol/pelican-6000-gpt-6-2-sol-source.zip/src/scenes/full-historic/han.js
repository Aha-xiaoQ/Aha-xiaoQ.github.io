import { cachedLayer, ellipse, grain, mulberry, opacityWindow, path, plot, rect, register, road, titlePlate, verticalGradient } from './common.js';

const WHITE = '#e1dbcb';
const FAINT = '#b6b5a8';
const BLACK = '#262b28';

function wheel(ctx, x, y, radius, theta, ink) {
  ellipse(ctx, x, y, radius, radius, null, ink, 2.4);
  ellipse(ctx, x, y, radius * .85, radius * .85, null, ink, 1);
  for (let n = 0; n < 8; n++) {
    const a = theta + n * Math.PI / 4;
    plot(ctx, [[x + 3.1 * Math.cos(a), y + 3.1 * Math.sin(a)], [x + radius * .845 * Math.cos(a), y + radius * .845 * Math.sin(a)]], ink, 1.35);
  }
  ellipse(ctx, x, y, 3.8, 3.8, ink);
}

function horse(ctx, x, y, theta, ink) {
  ctx.save();
  ctx.translate(x, y);
  path(ctx, 'M-20 -28 Q-31 -36 -20 -47 Q-5 -54 15 -46 Q25 -46 28 -62 L38 -75 47 -74 59 -65 55 -58 40 -60 36 -44 28 -34 Q13 -25 -20 -28Z M36 -74 l-2 -10 6 3 2 6 M50 -68 l4 2 M33 -70 q-14 14 -13 30 M-23 -42 q-24 3 -22 26 l9 -8', null, ink, 2.8);
  for (let n = 0; n < 4; n++) {
    const flip = n % 2 ? -1 : 1;
    const dx = Math.sin(theta + n * 2.3) * flip * 12;
    const start = n > 1 ? 19 + n * 3 : -20 + n * 6;
    plot(ctx, [[start, -31], [start + dx * .62, -15], [start + dx, -3 + Math.min(0, dx * .45)], [start + dx + 5, -2 + Math.min(0, dx * .45)]], ink, 2.8);
  }
  path(ctx, 'M-5 -45 l6 11 m7 -11 5 8 m11 -14 9 3 m4 -16 8 -2', null, ink, 1.2);
  ctx.restore();
}

function cart(ctx, x, y, scale, phase, notice, ink) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale, scale);
  horse(ctx, 66, 3, phase, ink);
  wheel(ctx, -14, -24, 23.5, phase * .43, ink);
  path(ctx, 'M-46 -25 l13 -14 h48 l46 1 7 -6 M-37 -40 L-31 -72 H14 V-37 M-42 -72 Q-22 -91 27 -79 L34 -73z M-27 -69 h5 v22 h-5Z M-40 -38 l-4 12 12 1 M-30 -44 h41 M-34 -53 h48', null, ink, 2.15);
  const headAngle = -.17 - notice * .50;
  ctx.save();
  ctx.translate(-3, -61);
  ctx.rotate(headAngle);
  path(ctx, 'M-5 8 L-6 -3 Q-4 -10 3 -9 L9 -5 8 2 11 5 6 9 5 14 M-9 -9 h19 M-4 -10 l1 -6 h8 l1 6', null, ink, 1.8);
  ctx.restore();
  plot(ctx, [[1, -46], [21 + notice * 7, -48 - notice * 7], [88, -59]], ink, 1.5);
  ctx.restore();
}

function cloud(ctx) {
  path(ctx, 'M-21 4 Q-24 -2 -16 -4 Q-22 -13 -10 -14 Q-1 -14 -1 -7 Q9 -11 12 -4 Q22 -6 23 1 Q22 7 16 9 H-13 Q-20 9 -21 4Z M-13 1 Q-6 -6 -1 0 Q4 4 12 1', null, FAINT, 1.3);
}

const stone = cachedLayer(ctx => {
  rect(ctx, 0, 0, 1000, 1000, verticalGradient(ctx, [[0, '#282c29'], [.33, '#202522'], [.58, '#383c35'], [.88, '#242922'], [1, '#171c18']]));
  path(ctx, 'M18 146 L123 137 301 143 424 129 699 134 924 145 981 132 V883 L916 886 838 870 610 892 485 876 271 889 127 883 23 896Z', null, '#9e9d8e', 2.6);
  register(ctx, 165, 38, ['#34352d', '#77786d'], 58, cloud);
  register(ctx, 816, 41, ['#282c26', '#9e9b8a'], 53, cloud);
  for (const y of [232, 444, 474, 786, 883]) {
    path(ctx, `M0 ${y} l181 3 247 -6 288 5 284 -4`, null, '#a8a496', 1.8);
  }
  for (const [x, y, s] of [[98, 389, .77], [286, 385, .9], [527, 385, .83], [748, 390, .92], [935, 390, .76]]) {
    cart(ctx, x, y, s, .8, .02, '#969c8d');
  }
  for (const [x, y, scale] of [[261, 910, .93], [348, 908, .87], [899, 932, .92], [802, 922, .74]]) {
    ctx.save();
    ctx.translate(x, y);
    ctx.scale(scale, scale);
    path(ctx, 'M-47 10 q10 -20 36 -13 q1 -16 12 -8 L13 1 32 3 46 14 13 12 8 20 H-37Z M-26 18 l-3 13 m24 -16 v16 m16 -16 4 16', null, '#777c70', 1.65);
    ctx.restore();
  }
  for (const fracture of ['M22 211 l21 46 -19 27 23 56 -16 27', 'M773 800 l46 17 -18 29 43 22', 'M981 403 l-32 19 8 17 -26 41 21 30']) path(ctx, fracture, null, '#696e61', 2.6);
  mulberry(ctx, [0, 0, 998, 1000], 4091, 2700, ['rgba(5,13,11,.23)', 'rgba(212,213,189,.21)']);
  grain(ctx, 5200, 'rgba(3,7,5,.53)', 'rgba(205,207,185,.39)', 2350);
});

export const han = {
  background(ctx, info) {
    const t = info.local;
    stone(ctx);
    const shift = t * 30;
    const see = opacityWindow(t, 1.65, 2.55, 3.48, 4.52);
    for (const [x, y, s, pose] of [[-116, 724, 1.42, 1], [151, 724, 1.39, -.45], [688, 724, 1.46, .85]]) {
      cart(ctx, x + shift, y, s, t * 6 + pose, see, WHITE);
    }
    road(ctx, info, {base: '#43463c', edge: '#c3bdad', rim: '#676c5f', width: 13});
  },
  title: titlePlate({paper: '#272c29', ink: '#ece5d7', frame: '#a3a293', lines: true}),
};
