import { cachedLayer, mulberry, opacityWindow, path, plot, rect, road, titlePlate, verticalGradient } from './common.js';

const INK = '#3d3b35';
const PAPER = '#efe5ce';

function wetLine(ctx, shape, tone = INK, weight = 2.0) {
  path(ctx, shape, null, 'rgba(75,66,53,.15)', weight + 1.65);
  path(ctx, shape, null, tone, weight);
}

function figure(ctx, x, y, scale, mirror) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale * mirror, scale);
  const contours = [
    ['M-25 -88 Q-39 -52 -62 -24 Q-29 -18 -20 -26 Q-16 -33 -12 -14 Q-3 -19 8 -18 Q17 -28 34 -17 Q53 -29 56 -38 Q24 -53 19 -96Z', 2.25],
    ['M-22 -121 Q-45 -113 -47 -98 Q-43 -79 -25 -76 Q-15 -83 -20 -100 M17 -122 Q47 -118 57 -99 Q55 -82 49 -74 Q39 -93 19 -91', 2.8],
    ['M-9 -128 Q-25 -131 -30 -148 Q-29 -171 -7 -175 Q16 -176 22 -158 Q32 -150 19 -139 Q13 -126 -9 -128Z', 2.45],
    ['M-30 -148 Q-41 -157 -33 -171 Q-26 -183 -9 -180 Q-12 -191 3 -193 Q17 -187 19 -177 Q36 -165 22 -155 M-12 -145 l7 1 m11 -3 6 1 m-13 11 q8 3 13 -1', 1.63],
    ['M-8 -126 Q-1 -119 6 -126 L18 -120 Q12 -100 4 -88 Q-3 -99 -24 -121 M-24 -87 Q-2 -79 20 -87 M-21 -80 Q-5 -72 18 -80', 1.75],
    ['M-28 -64 Q-28 -46 -49 -29 M-19 -64 Q-23 -36 -33 -29 M-8 -63 Q-8 -52 -15 -25 M4 -74 Q2 -52 8 -22 M18 -74 Q21 -42 37 -28 M28 -62 Q34 -45 49 -35', 1.21],
    ['M-54 -24 Q-58 -13 -71 -10 Q-58 -4 -43 -17 M35 -18 Q39 -8 59 -8 Q62 -12 53 -24', 1.4],
    ['M-48 -94 Q-39 -86 -38 -87 M56 -98 Q46 -99 43 -94 M-34 -119 Q-44 -111 -45 -107 M41 -115 Q53 -109 55 -103', 1.23],
  ];
  for (const [shape, weight] of contours) wetLine(ctx, shape, INK, weight);
  ctx.restore();
}

const silk = cachedLayer(ctx => {
  rect(ctx, 0, 0, 1000, 1000, verticalGradient(ctx, [[0, '#ded2b6'], [.30, '#f2e9d3'], [.70, '#f0e5ce'], [1, '#d7c8aa']]));
  for (const seam of [139, 932]) {
    path(ctx, `M${seam} 0 Q${seam - 2} 559 ${seam + 2} 1000`, null, '#caba9b', 2);
    path(ctx, `M${seam + 4} 0 Q${seam + 1} 559 ${seam + 4} 1000`, null, '#f9edd1', 1);
  }
  mulberry(ctx, [0, 0, 1000, 1000], 3387, 2430, ['rgba(107,92,67,.11)', 'rgba(252,246,221,.55)']);
  figure(ctx, 190, 744, 1.16, 1);
  figure(ctx, 826, 742, 1.37, -1);
  figure(ctx, 934, 735, .86, -1);
  for (const line of [
    'M-11 538 C71 577 119 524 151 472 C181 421 145 380 101 395 Q76 408 100 432',
    'M-11 544 C71 583 118 529 155 476 C189 425 152 378 121 389 Q91 388 88 408',
    'M724 547 C692 500 728 475 766 499 C851 550 917 430 1008 467',
    'M722 553 C684 506 724 465 766 493 C849 545 919 424 1008 473',
    'M185 705 C227 674 226 635 254 611 Q301 583 311 634 Q312 661 277 668',
  ]) wetLine(ctx, line, '#767064', 1.07);
});

function flyingSilk(ctx, x, y, extent, t, phase, ink, weight) {
  const points = [];
  const margin = [];
  for (let n = 0; n <= 41; n++) {
    const u = n / 41;
    const wave = (33 + Math.sin(t * 4 + phase) * 8) * Math.sin(9 * u + t * 4 + phase);
    const px = x - u * extent;
    const py = y - u * 41 + wave * Math.sqrt(u);
    points.push([px, py]);
    margin.push([px - 2 * u, py + (5 + Math.sin(u * 6 + t * 3) * 2.9) * Math.sin(Math.PI * u)]);
  }
  plot(ctx, points.concat(margin.reverse()), null, 0, 'rgba(222,211,183,.67)');
  plot(ctx, points, ink, weight);
  plot(ctx, margin, ink, weight * .58);
}

export const tang = {
  background(ctx, info) {
    silk(ctx);
    const local = info.local;
    const gust = 0.74 + .26 * opacityWindow(local, 1.65, 2.4, 3.72, 4.57);
    const p = info.poseScale ?? .66;
    const x = (info.riderX ?? 500) - p * 26;
    const y = (info.riderY ?? 690) - p * 138;
    flyingSilk(ctx, x, y, 188 * gust, local, .17, '#4a473d', 2.1);
    flyingSilk(ctx, x + 12, y + 17, 155 * gust, local, 1.36, '#645d4c', 1.32);
    road(ctx, info, {base: 'rgba(151,135,111,.15)', edge: '#706759', width: 7});
  },
  title: titlePlate({paper: PAPER, ink: INK, frame: '#8e7a5c', lines: false}),
};
