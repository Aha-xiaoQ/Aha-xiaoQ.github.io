import { cachedLayer, ellipse, grain, opacityWindow, path, plot, rect, road, seeded, titlePlate, verticalGradient } from './common.js';

const GOLD = '#c6a463';
const DARK = '#22372c';

function flower(ctx, x, y, scale, color, lean = 0) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale, scale);
  ctx.rotate(lean);
  path(ctx, 'M0 18 V-8 M0 12 Q-10 6 -11 -1 Q-3 0 0 7 M0 7 Q6 -2 13 -2 Q10 5 0 12', null, '#587352', 1.8);
  for (let i = 0; i < 5; i++) {
    const a = i * Math.PI * 2 / 5;
    ellipse(ctx, Math.cos(a) * 5.7, -10 + Math.sin(a) * 5.5, 3.9, 3.45, color, '#7d6947', .71);
  }
  ellipse(ctx, 0, -10, 2.2, 2, '#e3c56f');
  ctx.restore();
}

function cypress(ctx, x, y, scale, seed) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale, scale);
  const shape = 'M-23 0 Q-32 -23 -19 -60 Q-17 -91 -8 -118 L0 -144 Q11 -118 14 -90 Q31 -48 26 -12 Q12 8 -23 0Z';
  path(ctx, shape, '#435b48', '#313b31', 1.6);
  ctx.clip(new Path2D(shape));
  const random = seeded(seed);
  for (let i = 0; i < 280; i++) {
    const x = -26 + random() * 54;
    const y = -145 + random() * 152;
    const arc = 1 + random() * 5.6;
    plot(ctx, [[x - arc, y], [x, y - 2.3], [x + arc * .8, y]], i % 3 ? '#6e8360' : '#253f34', .58 + random() * .4);
  }
  path(ctx, 'M0 4 L1 -119 M0 -28 L-10 -47 M0 -60 L8 -78', null, '#6a7953', .98);
  ctx.restore();
}

const garden = cachedLayer(ctx => {
  rect(ctx, 0, 0, 1000, 1000, verticalGradient(ctx, [[0, '#254b50'], [.43, '#629095'], [.55, '#9db6a1'], [1, '#375749']]));
  path(ctx, 'M35 179 H964 V929 H35Z', null, GOLD, 2.4);
  path(ctx, 'M47 194 H955 V915 H47Z M59 207 H943 V903 H59Z', null, '#e1bc72', 1.55);
  for (let i = 0; i < 32; i++) {
    const x = 38 + i * 30;
    flower(ctx, x, 158, .55, i % 4 ? '#b87c5b' : '#d7b968', i % 2 ? .71 : -.71);
    flower(ctx, x, 940, .61, i % 3 ? '#b48067' : '#d9ad63', (i % 2 ? -1 : 1) * 2.4);
    path(ctx, `M${x - 14} 176 q7 -10 14 -4 q7 6 14 -4 M${x - 14} 923 q7 9 14 3 q7 -6 14 3`, null, GOLD, .86);
  }
  path(ctx, 'M47 622 H954 V913 H47Z M46 550 Q245 417 447 490 Q552 518 646 480 Q779 429 955 498 V672Z', '#7b8f68', '#53634d', 1.55);
  path(ctx, 'M47 576 L330 508 486 535 461 690 51 699Z M551 543 L821 505 943 553 942 681 550 690Z', '#4e784f', '#344a38', 2.1);
  path(ctx, 'M64 597 L331 532 465 550 442 667 65 680Z M575 561 L820 530 921 568 920 666 583 668Z', '#718c59', '#beaa72', 1.3);
  path(ctx, 'M487 532 L551 541 569 710 633 903 H412 L458 716Z', '#65908a', '#cfb57f', 3.0);
  path(ctx, 'M487 549 L540 553 554 693 480 686Z M474 717 L562 717 607 892 H438Z', '#6c9e94', '#e4c88b', 1.55);
  for (let y = 563; y < 882; y += 16) {
    const x = 511 + Math.sin(y / 39) * 19;
    plot(ctx, [[x - 14, y], [x - 2, y - 2.5], [x + 16, y]], 'rgba(226,218,164,.72)', .9);
  }
  path(ctx, 'M215 474 H785 V411 H215Z M238 411 Q255 370 292 349 Q314 328 329 293 Q356 335 381 351 Q423 384 427 411Z M572 411 Q590 375 616 352 Q643 333 657 301 Q675 332 704 352 Q746 377 760 411Z', '#d3b384', '#5e5139', 1.95);
  path(ctx, 'M219 414 H781 V426 H219Z M259 427 V471 M279 427 V471 M362 427 V470 M393 427 V470 M603 427 V472 M636 427 V471 M702 427 V470 M724 427 V472', null, '#6a5b47', 2.1);
  for (const [x, y, s, n] of [[102, 570, .72, 57], [161, 548, .93, 58], [324, 550, .92, 59], [412, 535, .62, 60], [614, 557, .79, 61], [799, 538, .93, 62], [894, 561, .82, 63], [970, 560, .76, 64]]) cypress(ctx, x, y, s, n);
  const random = seeded(1512);
  for (let i = 0; i < 95; i++) {
    const x = 61 + random() * 873;
    const y = 575 + random() * 308;
    if (y > 694 && y < 815 || Math.abs(x - 508) < 65) continue;
    flower(ctx, x, y, .25 + random() * .36, ['#9e644f', '#d4ad66', '#d5c5a0'][i % 3], (random() - .5) * .8);
  }
  grain(ctx, 734, 'rgba(44,52,31,.16)', 'rgba(234,217,165,.35)', 1300);
});

function courtier(ctx, x, y, scale, viewpoint, tunic, see) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale, scale);
  const sides = viewpoint === 0 ? [-13, 16] : viewpoint === 1 ? [-17, 13] : [-22, 17];
  const [a, b] = sides;
  plot(ctx, [[a + 2, -47], [a - 6, -21], [a - 7, -7], [b + 4, -7], [b + 7, -23], [b - 2, -48], [4, -65], [-8, -64]], '#413b2b', 1.25, tunic);
  for (let n = -9; n <= 12; n += 6) plot(ctx, [[n * .6, -45], [n, -24], [n * 1.65, -9]], GOLD, .83);
  plot(ctx, [[a - 4, -9], [a, 0], [b - 2, 0], [b + 3, -9]], '#443b2d', 2.1);
  plot(ctx, [[-8, -57], [-21, -38], [-22 + see * 17, -26 - see * 12]], '#514234', 2.35);
  ellipse(ctx, -22 + see * 17, -26 - see * 12, 2.2, 2.2, '#c09470');
  ctx.translate(viewpoint === 2 ? 0 : viewpoint === 1 ? 3 - see * 9 : -2 + see * 9, -70);
  if (viewpoint === 1) ctx.scale(-1, 1);
  ellipse(ctx, 0, 0, 7, 8.4, viewpoint === 2 ? '#544637' : '#b88761', '#5d4d37', 1.15);
  path(ctx, 'M-9 -6 Q-7 -17 2 -17 Q12 -16 11 -8 L5 -5Z M-7 -11 L7 -8 M-2 -14 L8 -11', '#d0a86c', '#594d34', 1.05);
  if (viewpoint !== 2) path(ctx, 'M3 -2 h4 l2 4 -3 1 m-1 2 l3 1', null, '#4d3b2b', .86);
  ctx.restore();
}

export const mughal = {
  background(ctx, info) {
    garden(ctx);
    const see = opacityWindow(info.local, 1.55, 2.58, 3.56, 4.82);
    for (const [x, y, scale, view, dress, note] of [[196, 688, .97, 0, '#9e6552', .78], [337, 711, 1.12, 0, '#566a6b', 1], [741, 672, 1, 1, '#b17b49', 1], [837, 696, 1.08, 1, '#977d58', .82], [678, 590, .65, 2, '#6a8073', .53]]) {
      courtier(ctx, x, y, scale, view, dress, see * note);
    }
    road(ctx, info, {base: '#aa9267', edge: '#e7c985', rim: '#6c6b48', width: 19});
  },
  foreground(ctx, info) {
    courtier(ctx, 120, 838, 1, 2, '#686448', 0);
    courtier(ctx, 923, 830, 1.1, 2, '#a76b56', .6 * opacityWindow(info.local, 2.3, 2.98, 4.11, 4.93));
  },
  title: titlePlate({paper: '#294a47', ink: '#eed6a0', frame: GOLD, lines: true, mark(ctx, x, y) { flower(ctx, x, y, .68, '#c68569'); }}),
};
