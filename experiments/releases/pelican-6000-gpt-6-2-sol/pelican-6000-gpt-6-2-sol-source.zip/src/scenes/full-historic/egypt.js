import { cachedLayer, ellipse, grain, mulberry, opacityWindow, path, plot, rect, register, road, round, text, titlePlate, verticalGradient } from './common.js';

const TEAL = '#365a53';
const RED = '#9c4f37';
const DARK = '#47362b';
const PLASTER = '#e2c89b';

function lotus(ctx) {
  path(ctx, 'M0 12 Q-16 2 -18 -11 Q-8 1 0 -7 Q8 1 18 -11 Q16 2 0 12Z', TEAL);
  path(ctx, 'M-3 -8 L0 -15 3 -8 M-20 13 H20', null, '#e2c792', 1);
}

function glyph(ctx, type, ink = DARK) {
  const glyphs = [
    'M-14 0 Q0 -15 14 0 Q2 13 -14 0Z M-4 2 q6 4 11 -3 M13 1 l5 5',
    'M-15 8 q9 -14 19 -13 q6 -1 6 -7 q6 -3 8 0 l-4 6 v10 l-10 2 -3 6 m5 -7 7 6',
    'M-16 10 q12 -24 31 -15 l-3 10 -12 -2 -9 8Z M-4 10 h16',
    'M-14 5 l7 -4 7 4 7 -4 7 4 m-27 5 6 -3 7 3 7 -3 7 3 m-19 -12 v-10 m5 -1 v12',
    'M0 -13 v26 m-3 -13 q-10 -3 -12 -11 q10 0 12 8 m6 4 q10 -3 12 -11 q-10 1 -12 8',
  ];
  path(ctx, glyphs[type % glyphs.length], null, ink, 2.35);
}

const paintPlaster = cachedLayer(ctx => {
  rect(ctx, 0, 0, 1000, 1000, verticalGradient(ctx, [[0, '#b4895d'], [.32, '#e9cfa0'], [.70, '#e2c396'], [1, '#bb925e']]));
  path(ctx, 'M0 571 L0 0 H390 L371 216 306 370 179 485 83 514Z M691 1000 L755 811 829 792 920 712 1000 698 V1000Z', 'rgba(169,109,64,.12)');
  for (let x = 2; x < 1000; x += 36) plot(ctx, [[x, 187], [x + 4, 749]], 'rgba(150,53,32,.20)', 1.15);
  for (let y = 192; y < 758; y += 36) plot(ctx, [[0, y], [1000, y + 2]], 'rgba(150,53,32,.20)', 1.2);
  for (const [x, y] of [[94, 178], [498, 184], [923, 181], [136, 782], [710, 783]]) {
    path(ctx, `M${x - 8} ${y} h17 M${x} ${y - 9} v17`, null, RED, 1.7);
  }
  register(ctx, 141, 41, ['#cba464', TEAL], 51, lotus);
  register(ctx, 791, 34, ['#bf8b55', RED], 45, lotus);
  for (const y of [204, 469, 891]) {
    plot(ctx, [[0, y], [1000, y]], TEAL, 2.25);
    plot(ctx, [[0, y + 6], [1000, y + 6]], RED, 1.5);
  }
  for (const [x, y, count] of [[564, 297, 8], [817, 382, 4], [137, 533, 6], [721, 875, 7]]) {
    for (let i = 0; i < count; i++) {
      ctx.save();
      ctx.translate(x + i * 33, y);
      ctx.scale(.72, .72);
      glyph(ctx, i + x, i % 4 === 0 ? RED : DARK);
      ctx.restore();
    }
  }
  mulberry(ctx, [0, 0, 997, 1000], 833, 1400, ['rgba(118,81,47,.12)', 'rgba(250,228,181,.37)']);
  grain(ctx, 893, 'rgba(119,72,39,.19)', 'rgba(255,228,173,.37)', 1120);
  for (const fracture of ['M83 230 l24 51 -13 14 20 43 -23 31', 'M780 822 l38 18 -10 23 50 23 19 54', 'M968 518 l-23 21 -9 29 18 30 -9 17']) {
    path(ctx, fracture, null, 'rgba(133,90,51,.32)', 1.9);
  }
});

function attendant(ctx, x, y, scale, mirror, notice, garment) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale * mirror, scale);
  path(ctx, 'M-12 -69 L-13 -28 -26 -18 -13 -15 -4 -21 1 -64 M7 -66 L13 -28 29 -20 29 -14 15 -14 5 -21 -4 -57', RED, DARK, 2);
  path(ctx, 'M-24 -109 Q-17 -118 3 -119 Q21 -117 20 -107 L10 -76 -8 -75 -13 -91 -22 -86Z', '#a3593f', DARK, 1.7);
  path(ctx, 'M-11 -91 Q-1 -82 12 -90 L18 -58 H-29 L-18 -74Z', garment, DARK, 1.8);
  for (let xLine = -19; xLine < 13; xLine += 5) plot(ctx, [[xLine / 2, -85], [xLine, -60]], 'rgba(73,59,40,.55)', .87);
  path(ctx, 'M-18 -109 L-33 -82 -24 -76 -6 -91', null, DARK, 2.8);
  const handX = 41 + 17 * notice;
  const handY = -88 - 13 * notice;
  plot(ctx, [[15, -110], [26, -93], [handX, handY]], DARK, 6);
  plot(ctx, [[15, -110], [26, -93], [handX, handY]], '#b26348', 3.8);
  ctx.save();
  ctx.translate(.5, -127);
  ctx.rotate(-.12 * notice);
  path(ctx, 'M-10 15 L-9 1 Q-9 -18 4 -16 Q14 -16 13 -5 L18 1 12 4 11 12 2 12 3 17Z', '#a55b40', DARK, 1.5);
  path(ctx, 'M-12 13 Q-19 -3 -12 -15 Q1 -25 15 -14 L12 -5 6 -10 -1 -6 -4 3 -4 14Z', DARK);
  path(ctx, 'M5 -3 h6 m-6 0 1 2', null, DARK, 1.3);
  ctx.restore();
  ctx.restore();
}

function cartouche(ctx, t) {
  ctx.save();
  ctx.translate(709, 425);
  round(ctx, -90, -33, 182, 67, 33, '#d1ab6e', TEAL, 2.7);
  round(ctx, -83, -27, 169, 55, 27, '#e3c28a', RED, .95);
  for (const [x, g] of [[-54, 1], [-15, 4], [23, 0], [59, 3]]) {
    ctx.save();
    ctx.translate(x, -7);
    ctx.scale(.67, .67);
    glyph(ctx, g);
    ctx.restore();
  }
  text(ctx, '鹈鹕测试', 0, 18, {size: 17, fill: DARK, align: 'center', weight: 600});
  const ink = opacityWindow(t, 2.14, 2.45, 3.35, 3.82);
  if (ink > .01) {
    ctx.globalAlpha *= ink;
    path(ctx, 'M-101 -6 h-13 v13 M99 -6 h13 v13', null, RED, 2.1);
  }
  ctx.restore();
}

export const egypt = {
  background(ctx, info) {
    paintPlaster(ctx);
    cartouche(ctx, info.local);
    const t = info.local;
    const notice = opacityWindow(t, 1.55, 2.22, 3.46, 4.19);
    attendant(ctx, 207, 727, 1.16, 1, notice * .53, '#d6b982');
    attendant(ctx, 786, 720, 1.3, -1, notice, '#cdb979');
    attendant(ctx, 917, 717, .91, -1, notice * .37, '#97a290');
    const grid = opacityWindow(t, 1.88, 2.33, 3.36, 3.94);
    if (grid > .01) {
      ctx.save();
      ctx.globalAlpha *= grid;
      const x = info.riderX ?? 505;
      for (let i = -3; i <= 3; i++) plot(ctx, [[x + i * 34, 490], [x + i * 34, 748]], 'rgba(142,65,37,.44)', .92);
      for (let i = 0; i < 8; i++) plot(ctx, [[x - 111, 497 + i * 34], [x + 112, 497 + i * 34]], 'rgba(142,65,37,.42)', .92);
      ctx.restore();
    }
    road(ctx, info, {base: '#b58a61', edge: '#734936', rim: '#e3bd86', width: 17});
  },
  title: titlePlate({paper: PLASTER, ink: DARK, frame: TEAL, lines: true, mark(ctx, x, y) {
    ctx.save(); ctx.translate(x, y); ctx.scale(.65, .65); lotus(ctx); ctx.restore();
  }}),
};
