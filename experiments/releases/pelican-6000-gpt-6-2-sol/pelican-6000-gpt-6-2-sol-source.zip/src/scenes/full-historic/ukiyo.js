import { cachedLayer, ellipse, grain, opacityWindow, path, plot, rect, seeded, titlePlate, verticalGradient } from './common.js';

const KEY = '#2c4951';
const INDIGO = '#416982';
const PAPER = '#e7ddba';

function pine(ctx, x, y, scale, mirror, seed) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale * mirror, scale);
  path(ctx, 'M-15 25 Q-6 -23 -15 -56 Q-24 -91 -8 -118 Q-8 -158 18 -181 Q9 -158 10 -130 Q13 -114 4 -96 Q-4 -74 3 -53 Q14 -18 8 25Z', '#6c6549', KEY, 2.35);
  path(ctx, 'M-5 16 Q4 -23 -8 -54 Q-17 -75 -7 -98 M-7 -105 Q-30 -126 -56 -120 M-4 -98 Q35 -127 61 -126 M-2 -130 Q15 -146 49 -154 M0 -141 Q-4 -166 -36 -175', null, KEY, 2.18);
  const random = seeded(seed);
  for (const [x, y, span, height] of [[-45, -170, 39, 10], [-10, -150, 43, 12], [44, -157, 55, 18], [51, -128, 49, 15], [-47, -122, 38, 16]]) {
    for (let n = 0; n < 14; n++) {
      const dx = (random() - .5) * span;
      const dy = (random() - .5) * height;
      const rx = 9 + 11 * random();
      ellipse(ctx, x + dx, y + dy, rx, 2.8 + random() * 3, n % 3 ? '#416156' : '#547268');
      plot(ctx, [[x + dx - rx, y + dy], [x + dx, y + dy - 2.2], [x + dx + rx * .84, y + dy]], KEY, .65);
    }
  }
  ctx.restore();
}

const print = cachedLayer(ctx => {
  rect(ctx, 0, 0, 1000, 1000, verticalGradient(ctx, [[0, '#53768a'], [.34, '#98abb0'], [.49, '#e2d9af'], [.7, '#e8d9ae'], [1, '#b7b889']]));
  path(ctx, 'M0 544 Q74 485 141 471 L197 429 233 421 287 366 336 349 389 376 440 394 489 451 554 459 623 491 684 522 1000 524 V662 H0Z', '#7e9eab');
  path(ctx, 'M0 548 Q73 490 141 476 L196 437 235 429 287 368 339 347 389 376 440 396 488 454 554 465 624 496 684 525', null, 'rgba(57,91,104,.53)', 1.55);
  path(ctx, 'M0 547 Q191 614 375 580 Q537 552 660 566 Q857 591 1000 549 V827 H0Z', '#62899d', '#395e74', 2.55);
  path(ctx, 'M0 612 Q166 652 371 604 Q521 573 670 591 Q894 620 1000 584 M0 617 Q166 657 371 610 Q521 578 670 596 Q894 625 1000 590', null, '#bfc5ac', 1.42);
  path(ctx, 'M0 512 L58 467 95 506 147 529 202 596 264 620 300 667 362 690 418 750 391 848 217 895 0 887Z', '#79907b', KEY, 2.35);
  path(ctx, 'M0 578 L63 537 114 570 158 575 203 631 248 669 283 706 324 730 260 832 42 881 H0Z', '#5c7c72', KEY, 2);
  path(ctx, 'M793 704 L848 658 918 639 945 605 1000 585 V929 L956 955 891 937 855 884 792 840 750 816Z', '#91a17b', KEY, 2.25);
  path(ctx, 'M0 830 Q208 700 371 738 Q496 776 668 729 Q845 686 1000 737 V934 Q864 909 748 937 Q590 968 427 908 Q225 853 0 967Z', '#a8a77d', '#5b6a5a', 1.55);
  for (const [x, y, s, mirror, seed] of [[82, 760, 1.24, -1, 972], [167, 720, .86, -1, 946], [273, 756, .63, -1, 988], [926, 728, .50, 1, 928], [958, 692, .67, 1, 981]]) pine(ctx, x, y, s, mirror, seed);
  const random = seeded(58);
  for (let i = 0; i < 700; i++) {
    const x = random() * 1000;
    const y = 499 + random() * 501;
    if (y > 737 && y < 799 || x > 371 && x < 815 && y < 895) continue;
    const l = 2 + random() ** 2 * 19;
    plot(ctx, [[x - l * .4, y + 2], [x, y - random() * 4], [x + l, y + .5]], i % 3 ? 'rgba(46,70,66,.26)' : 'rgba(222,222,179,.40)', .55 + random() * .55);
  }
  grain(ctx, 594, 'rgba(57,71,66,.16)', 'rgba(253,233,176,.36)', 1810);
});

function boat(ctx, x, y, scale) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale, scale);
  path(ctx, 'M-51 1 Q-3 12 47 0 Q24 19 -27 17Z', '#9a8b65', KEY, 1.85);
  path(ctx, 'M-6 4 L-8 -51 M-7 -49 Q-27 -20 -41 0 H-8Z M0 -45 Q32 -18 32 2 L2 4Z', '#e1c898', KEY, 1.4);
  path(ctx, 'M-36 -5 L-13 -13 M11 -25 L24 -5 M-40 14 Q-5 27 35 16', null, '#9ab8ad', 1.18);
  ctx.restore();
}

function traveler(ctx, x, y, scale, t) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale, scale);
  path(ctx, 'M-17 -11 l-9 9 12 2 9 -11 m19 -3 12 7 -2 8 -14 -1 -11 -10', '#57665c', KEY, 1.45);
  const shag = 'M-22 -63 Q-6 -74 11 -60 Q30 -36 34 -20 Q15 -11 -13 -12 Q-20 -20 -33 -23Z';
  path(ctx, shag, '#b49d6d', KEY, 2);
  for (let i = 0; i < 13; i++) {
    const px = -18 + i * 3.4;
    plot(ctx, [[px / 2, -55], [px - (i < 3 ? 5 : 0), -31], [px, -20 + i % 4]], '#7b755b', .9);
  }
  ellipse(ctx, -3, -68, 8.5, 8.0, '#aa8563', KEY, 1.3);
  const flutter = opacityWindow(t, 2.25, 2.80, 3.22, 3.62);
  ctx.save();
  ctx.translate(-6 - 9 * flutter, -78 - 14 * flutter);
  ctx.rotate(-.15 - .58 * flutter);
  path(ctx, 'M-31 3 Q-12 -17 4 -14 Q22 -11 37 3 Q13 9 -31 3Z M-17 2 L3 -12 23 2', '#c8af76', KEY, 1.3);
  ctx.restore();
  plot(ctx, [[-3, -56], [13, -55], [4 - 10 * flutter, -77 - 8 * flutter]], KEY, 2.75);
  ctx.restore();
}

export const ukiyo = {
  background(ctx, info) {
    const t = info.local;
    print(ctx);
    boat(ctx, 697 - 8 * t, 632, .74);
    boat(ctx, 556 - 5.5 * t, 595, .43);
    const floor = info.floorAt ?? (() => 760);
    const top = [];
    const base = [];
    for (let x = 0; x <= 1000; x += 8) {
      top.push([x, floor(x)]);
      base.push([x, floor(x) + 33 + 11 * Math.sin(x * .013) ** 2]);
    }
    plot(ctx, top.concat(base.toReversed()), null, 0, '#c3ad78');
    plot(ctx, top, KEY, 1.95);
    plot(ctx, base, KEY, 1.3);
    for (let x = 21; x < 1000; x += 31) {
      const y = floor(x) + 23 + Math.sin(x * .031) * 7;
      plot(ctx, [[x, y], [x + 8, y - 2], [x + 15, y - .5]], '#948d6c', .92);
    }
    traveler(ctx, 803, floor(803) - 37, 1.17, t);
    traveler(ctx, 215, floor(215) - 25, .73, t + .24);
  },
  foreground(ctx, info) {
    const t = info.local;
    const storm = opacityWindow(t, 1.95, 2.76, 4.73, 5.52);
    if (storm <= .01) return;
    ctx.save();
    ctx.globalAlpha *= storm;
    const random = seeded(695);
    for (let i = 0; i < 92; i++) {
      const x = (i * 89.139 + t * (29 + i % 17)) % 1000;
      const y = 293 + (i * 101.41 + t * (81 + i % 11)) % 680;
      const length = 13 + random() * 38;
      plot(ctx, [[x, y], [x + length * .29, y + length]], i % 4 ? 'rgba(55,86,100,.34)' : 'rgba(231,221,168,.59)', .65 + random() * .58);
    }
    ctx.restore();
  },
  title: titlePlate({paper: PAPER, ink: KEY, frame: INDIGO, lines: true, mark(ctx, x, y) {
    rect(ctx, x - 9, y - 12, 17, 20, '#a45240');
    path(ctx, `M${x - 5} ${y - 7} h9 v10 h-9Z m2 -2 4 -6 m0 2 v5`, null, '#ecd7ad', .82);
  }}),
};
