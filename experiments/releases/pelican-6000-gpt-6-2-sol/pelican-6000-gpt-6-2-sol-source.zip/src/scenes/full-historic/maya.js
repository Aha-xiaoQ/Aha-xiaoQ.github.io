import { cachedLayer, ellipse, grain, mulberry, path, plot, rect, road, round, titlePlate, verticalGradient } from './common.js';

const RED = '#8b4031';
const BLACK = '#463024';
const PARCHMENT = '#e7cb94';

function token(ctx, x, y, scale, design) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale, scale);
  const sign = [
    'M-12 4 l5 -15 15 1 6 11 -6 9 h-14Z m6 -7 q7 -4 14 0 m-13 4 h11',
    'M-14 9 q11 -6 11 -17 L3 -13 9 -9 8 -3 14 3 12 10Z m-10 -6 l5 -4 4 3',
    'M-10 10 q-6 -4 -6 -13 q6 -9 21 -9 q12 3 10 14 L8 11Z M-11 -1 q12 -8 20 1 q-8 7 -20 1Z M-5 1 q5 -4 10 0',
    'M-15 -9 H14 V11 H-15Z m5 16 V-4 h21 m-3 11 v-6 h-14 m7 6 q-3 -4 0 -7',
  ];
  round(ctx, -20, -18, 41, 37, 6, design % 3 === 0 ? 'rgba(164,82,52,.14)' : 'rgba(233,209,154,.39)', RED, 1.45);
  path(ctx, sign[design % sign.length], null, design % 3 === 0 ? BLACK : RED, 1.92);
  ctx.restore();
}

function quetzal(ctx, x, y, scale, mirror) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(scale * mirror, scale);
  path(ctx, 'M-32 29 Q-39 7 -19 0 L-7 -15 Q5 -29 24 -22 L41 -16 27 -11 27 1 19 10 6 10 -3 26Z', '#467169', BLACK, 2.2);
  path(ctx, 'M-27 24 q-23 7 -28 43 l10 -10 11 -19 11 -7 m-6 4 q-13 11 -8 36 l11 -14 7 -22', '#8b4837', BLACK, 2.1);
  path(ctx, 'M-19 0 q12 7 12 19 l-9 6 m-2 -17 l2 10 m28 -39 7 -12 9 11 m-5 13 8 1', null, '#d3a76f', 1.45);
  ellipse(ctx, 18, -14, 3.9, 3.1, '#e5c183', BLACK, 1.2);
  path(ctx, 'M-14 26 l4 14 14 1 m-5 -16 10 14 10 -1', null, BLACK, 1.85);
  ctx.restore();
}

const codex = cachedLayer(ctx => {
  rect(ctx, 0, 0, 1000, 1000, verticalGradient(ctx, [[0, '#b28f58'], [.28, '#e9cf9c'], [.70, '#e6c891'], [1, '#b58e54']]));
  for (const x of [37, 247, 502, 752, 962]) {
    rect(ctx, x - 8, 132, 19, 793, x % 2 ? 'rgba(146,89,52,.19)' : 'rgba(219,169,100,.24)');
    rect(ctx, x, 138, 1.3, 787, 'rgba(139,66,43,.49)');
    rect(ctx, x + 2, 138, 1, 787, 'rgba(252,235,169,.73)');
  }
  for (const y of [176, 269, 485, 803, 904]) {
    path(ctx, `M0 ${y} l171 -2 211 3 214 -1 404 -2`, null, RED, 3.8);
    path(ctx, `M0 ${y + 6} H1000`, null, '#b37048', 1.6);
  }
  for (let n = 0; n < 22; n++) {
    token(ctx, 18 + n * 47, 219 + (n % 2) * 1.5, .74, n + 3);
    token(ctx, 21 + n * 47, 850 + (n % 3) * 1.1, .68, n);
  }
  for (const [x, y, scale, flip] of [[120, 625, .85, 1], [216, 637, .55, -1], [859, 649, .86, -1], [928, 599, .56, -1]]) quetzal(ctx, x, y, scale, flip);
  path(ctx, 'M0 714 Q62 685 261 699 M763 699 Q892 662 1000 708 M28 715 v15 h153 v-10 M799 710 v19 h173 v-9', null, RED, 2.1);
  mulberry(ctx, [0, 0, 1000, 1000], 6667, 1970, ['rgba(135,87,50,.21)', 'rgba(251,230,170,.48)']);
  grain(ctx, 819, 'rgba(110,61,32,.17)', 'rgba(250,227,171,.36)', 1850);
});

function countPanel(ctx, t) {
  const count = Math.min(6, Math.max(0, Math.floor(t + 1e-6)));
  ctx.save();
  ctx.translate(690, 449);
  path(ctx, 'M0 -68 H151 L159 -60 V50 L148 58 H0Z', '#d7a872', RED, 2.2);
  path(ctx, 'M7 -59 H147 V46 H7Z', '#ebd29c', RED, 1);
  path(ctx, 'M4 -24 Q45 -28 52 -11 T121 -19 Q141 -26 152 -17', null, '#d8af76', 2.2);
  if (!count) {
    path(ctx, 'M54 14 Q62 -19 83 -18 Q106 -15 109 10 Q96 31 61 20Z M58 10 q20 -9 46 -8 m-30 16 4 -15 m12 -3 -2 16', null, BLACK, 2.65);
  }
  if (count >= 5) round(ctx, 52, 17, 53, 8.5, 3.8, BLACK);
  const dots = count % 5;
  for (let i = 0; i < dots; i++) {
    const pop = i === dots - 1 ? Math.exp(-((t - count) * 7.8)) : 0;
    ellipse(ctx, 78 + (i - (dots - 1) / 2) * 18, 2 - 5 * pop, 5.3 + pop, 5.17 + pop, i === dots - 1 ? RED : BLACK);
  }
  ctx.restore();
}

export const maya = {
  background(ctx, info) {
    codex(ctx);
    const t = info.local;
    countPanel(ctx, t);
    road(ctx, info, {base: 'rgba(150,77,47,.43)', edge: '#7e402e', rim: '#d3a265', width: 15});
  },
  title: titlePlate({paper: PARCHMENT, ink: BLACK, frame: RED, lines: true, mark(ctx, x, y) {
    token(ctx, x, y, .56, 3);
  }}),
};
