import {
  blob, ellipse, fade, gradient, plate, radial, rect, road, rng, stroke, TAU, title,
} from './paint.js';

function palm(ctx,x,y,scale,direction) {
  ctx.save();
  ctx.translate(x,y);
  ctx.scale(scale*direction,scale);
  blob(ctx, 'M-12 0 L13 0 25 -74 36 -147 58 -223 48 -229 21 -165 4 -97Z', '#332748');
  blob(ctx, 'M-5 -6 L10 -88 28 -160 53 -224 M-7 -18 L18 -20 M-4 -43 L24 -49 M2 -70 L29 -79 M16 -104 L36 -112 M24 -138 L43 -147 M33 -170 L49 -179', null, '#806185', 2.3);
  for (const [d,fill] of [
    ['M48 -224 L72 -269 100 -286 129 -270 158 -231 111 -253 83 -250Z','#58426d'],
    ['M48 -224 L71 -245 121 -237 150 -212 162 -164 120 -203 101 -211Z','#3f3a66'],
    ['M48 -224 L87 -216 129 -193 140 -153 137 -123 100 -172 83 -177Z','#49416f'],
    ['M54 -224 L24 -262 -23 -275 -69 -254 -80 -213 -36 -239 23 -240Z','#49385f'],
    ['M48 -224 L3 -241 -41 -224 -57 -181 -26 -195 10 -209Z','#283855'],
    ['M56 -223 L33 -220 -14 -192 -18 -171 -40 -142 -12 -200 25 -226Z','#4a547f'],
  ]) blob(ctx,d,fill,'#3c365b',1.3);
  ctx.restore();
}

function statue(ctx) {
  ctx.save();
  ctx.translate(739, 709);
  ctx.scale(1.14,1.14);
  const stone=gradient(ctx,-67,-308,86,-103,[[0,'#ffebdb'],[.44,'#f3d9d5'],[.68,'#c1b9d7'],[1,'#7894b5']]);
  const shade='#8e86b0';
  const light='#ffe2d3';
  ellipse(ctx,0,27,123,12,'#2f245f69');
  blob(ctx,'M-90 -9 L83 -12 94 17 -97 19Z','#9b89bd','#503c71',3);
  blob(ctx,'M-76 -47 L70 -45 76 -8 -82 -8Z','#a49fcb','#6d5986',2);
  blob(ctx,'M-95 -47 L88 -49 84 -38 -92 -34Z','#e1bccf','#786e99',2);
  blob(ctx,'M-47 -132 Q-71 -116 -85 -99 L-68 -64 Q-36 -55 84 -69 Q98 -88 60 -119 L33 -125 29 -170 -19 -194 -26 -147Z',stone,'#795e8e',3.6);
  blob(ctx,'M-73 -93 Q-37 -82 -18 -108 Q-3 -94 9 -88 Q45 -83 73 -93 M-10 -113 L-26 -150 M29 -139 Q35 -121 48 -116 M42 -74 Q61 -69 75 -70',null,'#c89db9',3.1);
  blob(ctx,'M18 -144 L-14 -151 -43 -187 -41 -235 -33 -266 11 -290 61 -267 67 -224 56 -210 70 -197 55 -191 51 -174 41 -157Z',stone,'#746290',3.3);
  blob(ctx,'M46 -244 L61 -245 66 -232 60 -218 67 -202 64 -195 54 -196 50 -180 37 -172 27 -186 33 -216Z',shade);
  blob(ctx,'M-10 -172 Q-31 -194 -28 -214 L-16 -216 -9 -204 -16 -190 7 -176Z','#af98b5','#8b729b',2.4);
  blob(ctx,'M-14 -216 q-16 -1 -13 11 q1 8 8 6 M-7 -229 q12 -4 22 -19 M42 -223 q11 -9 17 -4 M45 -220 q7 2 11 -1 M50 -197 l10 1 M44 -184 l10 -2',null,'#7e628c',2.4);
  blob(ctx,'M-41 -204 Q-58 -212 -58 -230 Q-67 -241 -50 -252 Q-53 -270 -32 -276 Q-34 -307 -11 -306 Q3 -321 27 -309 Q50 -312 61 -292 Q79 -279 67 -258 L48 -252 43 -268 Q34 -270 29 -256 L12 -261 Q6 -247 -8 -250 L-10 -231 -24 -229 -34 -208Z',stone,'#77628c',3.3);
  for(const [x,y,r] of [[-35,-266,10],[-16,-280,13],[4,-294,13],[28,-294,11],[49,-285,11],[-41,-245,10],[-23,-253,12],[13,-271,10],[52,-265,7],[-44,-224,7]]){
    ellipse(ctx,x,y,r,r*.76,null,'#a88aad',1.8);
    blob(ctx,`M${x-r*.7} ${y+r*.2} q${r*.5} ${-r} ${r*1.2} ${-r*.5} q${r*.55} ${r*.4} ${r*.15} ${r*.75}`,null,light,1.55);
  }
  blob(ctx,'M-67 -90 L-54 -102 -37 -111 M-58 -78 L-48 -94 M-31 -195 L-22 -179 M-20 -225 L-5 -228 M18 -257 L34 -257 M-16 -141 Q-4 -132 6 -132',null,'#e2b2c5',1.9);
  ctx.restore();
}

const vaporField = plate(ctx => {
  rect(ctx,0,0,1000,1000,gradient(ctx,0,265,0,980,[[0,'#221d4c'],[.22,'#493660'],[.49,'#b7588e'],[.66,'#f394a4'],[.74,'#66c4bc'],[.87,'#373c72'],[1,'#201b4b']]));
  rect(ctx,0,0,1000,1000,radial(ctx,545,468,506,[[0,'#ffbaab33'],[.43,'#ff9c9b24'],[1,'#92259d00']]));
  ctx.save();
  ctx.beginPath();
  ctx.arc(488,473,152,0,TAU);
  ctx.clip();
  rect(ctx,323,316,340,320,gradient(ctx,0,314,0,631,[[0,'#ffe4a4'],[.55,'#f7ae98'],[1,'#fa80b1']]));
  for(let i=0;i<15;i++){
    const height=i*7 + .45*i*i;
    rect(ctx,322,429+height,347,2+.58*i,'#6a427c');
  }
  ctx.restore();
  blob(ctx,'M0 658 L73 629 116 668 180 641 242 676 278 665 324 694 389 687 441 717 547 693 568 672 626 685 691 648 744 665 814 640 883 658 945 638 1000 652 V763 H0Z','#59527e','#ac7fa5',3);
  blob(ctx,'M0 711 L92 668 152 692 205 716 283 701 345 733 402 718 504 736 572 709 635 723 716 701 772 720 834 674 892 715 935 696 1000 723 V772 H0Z','#535e86');
  palm(ctx,148,753,1.53,1);
  palm(ctx,273,742,1.0,1);
  palm(ctx,992,751,1.51,-1);
  palm(ctx,912,749,.86,-1);
  const random=rng(12217);
  for(let i=0;i<1050;i++){
    const x=random()*1000,y=200+random()*800;
    rect(ctx,x,y,random()*4.1+1,random()*1.1+.33,i%5?'#f2bcd714':'#5999bb24');
  }
  statue(ctx);
});

export const vapor = {
  background(ctx,info) {
    vaporField(ctx);
    const anchor=700;
    const horizon=info.floorAt(0);
    rect(ctx,0,horizon+2,1000,260,gradient(ctx,0,horizon,0,1000,[[0,'#584c7c'],[1,'#331754']]));
    const progress=info.local;
    const stuck=fade(progress,2.12,2.31)*(1-fade(progress,3.11,3.3));
    const motion=(progress*.35 + Math.sin(progress*26)*stuck*.13)%1;
    for(let i=-12;i<14;i++){
      stroke(ctx,[anchor,horizon+2],[anchor+i*89+motion*89,1000],i%3===0?'#d385b1':'#9d75b0',i%3===0?1.8:1.05);
    }
    for(let i=0;i<12;i++){
      const y = horizon+((i+motion)**1.47)*7.75;
      stroke(ctx,[0,y],[1000,y],i%3===0?'#ee99bf':'#ad70ac',i%3===0?1.8:1.1);
    }
    road(ctx,info,'#9ed7bf',4.4,2);
  },
  foreground(ctx,info) {
    const age=info.local;
    const awoke=fade(age,2.19,2.37)*(1-fade(age,3.1,3.42));
    if(awoke<=0)return;
    const y=760-23;
    ctx.save();
    ctx.globalAlpha*=.54*awoke;
    for(let i=0;i<7;i++){
      const step=Math.floor(age*13)%4;
      const x=248+132*i + 18*step;
      rect(ctx,x,y+9*(i%3),34+(i%4)*10,1.3,'#feb8d3');
      rect(ctx,x-4,y+9*(i%3)+3,21+(i%4)*10,1.3,'#8debc8');
    }
    ctx.restore();
  },
  title(ctx,info){
    title(ctx,info,{paper:'#462951',edge:'#e4a3bb',ink:'#ffe0d4',width:294});
    const t=info.local;
    const r=.55+.45*Math.sin(t*8);
    rect(ctx,248,18,25,8,'#1d2345');
    rect(ctx,250,20,21*r,4,'#8ae4bf');
  },
};
