import {
  fade, gradient, MONO, plate, rect, rng, TAU, text, title,
} from './paint.js';

const grid = 6;
const snap = x => Math.round(x / grid) * grid;
const pixelColors = {
  night: '#171d37', blue: '#253250', violet: '#444365', rose: '#9e617b', pink: '#d08c8d',
  dark: '#272a42', rock: '#48384f', clay: '#895459', sand: '#cb885d', light: '#edb87b',
  gold: '#f3ce6e', white: '#ffe4a6', mist: '#817c9e', city: '#685978',
};

const hills = plate(ctx => {
  const p = pixelColors;
  for (const [y0,y1,c] of [[0,156,p.night],[156,306,p.blue],[306,426,p.violet],[426,516,'#635071'],[516,610,p.rose],[610,706,p.pink],[706,1000,p.dark]]) {
    rect(ctx, 0, y0, 1000, y1-y0, c);
  }
  const random = rng(823206);
  for (let i=0; i<72; i++) {
    const x=snap(random()*1000), y=snap(241+random()*404);
    const v = i % 7 === 0 ? 6 : 3;
    rect(ctx, x, y, v, v, i % 5 ? '#ab94a2' : p.white);
  }
  for (let xi=0; xi<1000; xi+=grid) {
    const x=xi/grid;
    const shapeA = 622 + Math.sin(x*.069)*43+Math.sin(x*.21+.93)*27 + Math.cos(x*.39)*11;
    const shapeB = 680 + Math.sin(x*.084+2.04)*33+Math.sin(x*.26-.32)*20;
    const shapeC = 713 + Math.sin(x*.044+1.21)*11+Math.sin(x*.34-.21)*12;
    rect(ctx, xi, snap(shapeA), grid, 1000-snap(shapeA), p.city);
    rect(ctx, xi, snap(shapeB), grid, 1000-snap(shapeB), p.violet);
    rect(ctx, xi, snap(shapeC), grid, 1000-snap(shapeC), p.blue);
  }
  for (let i=0; i<28; i++) {
    const x=snap(random()*1000), y=snap(641+random()*91);
    const w = grid*(1+(i%4));
    rect(ctx,x,y,w,grid,p.mist);
    if (i%3===0) rect(ctx,x+grid,y-grid,w,grid,'#a08ba0');
  }
});

function cliff(ctx, left, right) {
  const p=pixelColors;
  const random=rng(2508+left);
  for (let x=left; x<right; x+=grid) {
    const y=760;
    rect(ctx,x,y,grid,1000-y,p.rock);
    rect(ctx,x,y,grid,grid,p.light);
    rect(ctx,x,y+grid,grid,grid,p.sand);
    rect(ctx,x,y+2*grid,grid,3*grid,p.clay);
    for (let row=0; row<29; row++) {
      const lowerY=y+(row+3)*grid;
      if (random()<.20) rect(ctx,x,lowerY,grid,grid,row<5 ? p.sand : p.clay);
      else if (random()<.48) rect(ctx,x,lowerY,grid,grid,p.dark);
    }
  }
}

const pixelCourse = plate(ctx => {
  cliff(ctx,0,450);
  cliff(ctx,558,1000);
  const p=pixelColors;
  for (const x of [0,105,208,347,639,743,860,983]) {
    rect(ctx,x-3,781,21,9,p.clay);
    rect(ctx,x+3,790,12,9,p.clay);
    rect(ctx,x+3,776,6,25,p.sand);
  }
  for (const x of [450, 552]) {
    rect(ctx,x,756,6,93,p.clay);
    rect(ctx,x+2,758,3,87,p.sand);
  }
});

const DIGITS = {
  '1': ['010','110','010','010','111'],
  U: ['10001','10001','10001','10001','01110'],
  P: ['11110','10001','11110','10000','10000'],
};

function bitmap(ctx, value, x, y, scale, color) {
  for (const letter of value) {
    const shape=DIGITS[letter];
    for (const [row, line] of shape.entries()) for (let col=0;col<line.length;col++) {
      if (line[col]==='1') rect(ctx,x+col*scale,y+row*scale,scale,scale,color);
    }
    x+=(shape[0].length+1)*scale;
  }
}

function coin(ctx, x, y, time) {
  const w = Math.floor(Math.abs(Math.sin(Math.floor(time * 10)*.83)) * 2.99)*6+6;
  const p=pixelColors;
  rect(ctx,x-w-5,y-15,w*2+10,30,p.dark);
  rect(ctx,x-w,y-20,w*2,40,p.sand);
  rect(ctx,x-w,y-14,w*2,28,p.gold);
  rect(ctx,x-w+4,y-18,Math.max(3,w*.6),31,p.white);
  rect(ctx,x+w-6,y-12,6,24,'#ae7c52');
}

export const pixel = {
  background(ctx, info) {
    hills(ctx);
    pixelCourse(ctx);
    const p=pixelColors;
    const collect = 3;
    if (info.local < collect) coin(ctx, 506, 464, info.local);
    const age=info.local-collect;
    if (age>=0 && age<.58) {
      const tick=Math.floor(age*10);
      for (let i=0;i<10;i++) {
        const a=i*TAU/10;
        rect(ctx, snap(506+Math.cos(a)*(13+tick*8)),snap(464+Math.sin(a)*(13+tick*8)),6,6,i%3 ? p.gold : p.white);
      }
    }
    ctx.save();
    ctx.globalAlpha*=fade(info.local,.12,.38)*(1-fade(info.local,5.56,5.9));
    rect(ctx, 694, 410, 227, 36, '#21213bcc');
    text(ctx, info.local < collect ? 'COIN  00    PX-06' : 'COIN  01    PX-06', 711, 435, {size:18, face:MONO, fill:'#e7c88e', weight:700});
    ctx.restore();
  },
  foreground(ctx, info) {
    const age=info.local-3;
    if(age<0 || age>1.65) return;
    const y=420 - snap(Math.min(age,.78)*51);
    ctx.save();
    ctx.globalAlpha*=1-fade(age,1.04,1.65);
    bitmap(ctx,'1UP',472+3,y+3,7,'#4e3857');
    bitmap(ctx,'1UP',472,y,7,'#ffe2a1');
    ctx.restore();
  },
  title(ctx, info) {
    title(ctx, info, {paper:'#2b2343',edge:'#e4a86b',ink:'#ffe3a6',face:MONO,squared:true,width:302});
  },
};
