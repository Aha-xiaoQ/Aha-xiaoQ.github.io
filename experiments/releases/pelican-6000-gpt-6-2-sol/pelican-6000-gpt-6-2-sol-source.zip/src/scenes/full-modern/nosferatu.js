import {
  blob, clamp, gradient, mix, plate, radial, rect, road, rng, stroke, title,
} from './paint.js';

const stairs = plate(ctx => {
  rect(ctx, 0, 0, 1000, 1000, gradient(ctx, 0, 0, 1000, 830, [[0,'#211e20'], [.55,'#302929'], [1,'#1a2020']]));
  blob(ctx, 'M124 737 L233 344 701 183 1000 270 1000 685 742 823 347 824Z', '#55534b', '#222124', 10);
  blob(ctx, 'M126 737 L233 345 701 183 1000 271 1000 382 692 314 305 463 263 698Z', '#383635');
  blob(ctx, 'M89 460 L302 428 834 111 946 157 946 670 174 892Z', gradient(ctx, 89, 460, 1000, 600, [[0,'#60584d'], [.38,'#9c9277'], [.61,'#827965'], [1,'#474840']]));
  ctx.save();
  ctx.clip(new Path2D('M89 460 L302 428 834 111 946 157 946 670 174 892Z'));
  for (let row = 0; row < 12; row++) {
    const y = 268 + row * 59;
    stroke(ctx, [26,y], [1010,y - 166], '#c3b29132', 1.8);
    for (let i = 0; i < 5; i++) {
      const x = row % 2 * 106 + i * 218;
      stroke(ctx, [x,y - .167 * x], [x,y - .167 * x + 59], '#2a28274f', 1.7);
    }
  }
  const random = rng(192239);
  for (let i = 0; i < 2490; i++) {
    const x = random() * 1000;
    const y = 168 + random() * 722;
    const color = i % 3 ? '#1b1b1828' : '#eee3c739';
    rect(ctx, x, y, .7 + random() * 6, .55 + random() * 2.6, color);
  }
  ctx.restore();
  for (let i = 0; i < 10; i++) {
    const x = i * 107;
    const y = 831 - i * 24;
    blob(ctx, `M${x} ${y} l108 -23 27 23 -104 32Z`, i % 2 ? '#514c45' : '#63594c', '#28282a', 2);
    blob(ctx, `M${x+31} ${y+32} l104 -32 v25 l-105 34Z`, '#393332', '#26252a', 2.2);
  }
  blob(ctx, 'M0 398 L63 399 121 516 169 897 0 942Z M931 169 L1000 172 V1000 L938 927 944 690Z', '#1b1d20');
  blob(ctx, 'M146 857 L146 759 938 457 938 561 M140 799 L940 490', null, '#2b292a', 11);
  for (let i = 0; i < 7; i++) {
    const u = i / 6;
    stroke(ctx, [mix(145,941,u), mix(759,457,u)], [mix(145,941,u), mix(857,561,u)], '#25282a', 4.8);
  }
  blob(ctx, 'M0 915 L1000 655 V1000 H0Z', gradient(ctx, 185, 800, 958, 768, [[0,'#41403d'], [.48,'#272930'], [1,'#3a3f36']]));
  blob(ctx, 'M0 916 L1000 658 M0 921 L1000 662', null, '#847a5b', 3);
});

const filmGrain = Array.from({length: 7}, (_, i) => plate(ctx => {
  const random = rng(1937 + i * 773);
  for (let n = 0; n < 900; n++) {
    const x = random() * 1000;
    const y = random() * 1000;
    const w = random() * 2.2 + .7;
    rect(ctx, x, y, w, w * .8, n % 3 ? '#161a1b35' : '#f3dfaa81');
  }
}, 900));

export const shadow = {
  background(ctx, info) {
    stairs(ctx);
    const target = clamp(info.riderX ?? 500, 0, 1000);
    const beam = radial(ctx, target + 35, 500, 547, [[0,'#dcd09546'], [.48,'#c8bb7a38'], [.83,'#ceba7d03'], [1,'#d8bf8b00']]);
    rect(ctx, 0, 0, 1000, 1000, beam);
    road(ctx, info, '#c1b494', 3.4, 2.6);
    road(ctx, info, '#352f31', 7, 8);
  },
  foreground(ctx, info) {
    ctx.save();
    const flicker = .5 + .5 * Math.sin(Math.floor(info.local * 18) * 3.44);
    ctx.globalAlpha *= .45 + .20 * flicker;
    filmGrain[Math.floor(info.local * 17) % filmGrain.length](ctx);
    const vignette = radial(ctx, 502, 558, 716, [[0,'#100e1400'], [.5,'#100e1400'], [.82,'#100e1461'], [1,'#100e14cc']]);
    rect(ctx, 0, 0, 1000, 1000, vignette);
    ctx.restore();
  },
  title(ctx, info) {
    title(ctx, info, {paper:'#272825', edge:'#b9ac87', ink:'#e5d2ac', squared:true});
  },
};
