import {
  fade, gradient, MONO, plate, rect, rng, stroke, text, title,
} from './paint.js';

const gui = {
  dark:'#234361', deep:'#11314f', border:'#7796a3', medium:'#9fb9bf', light:'#d0dfd6', white:'#edf0d9',
  field:'#dbe7d3', tint:'#597e81', yellow:'#f6cc74', gray:'#61747b', green:'#86aa7b',
};

function pane(ctx, x, y, w, h, color) {
  const p=gui;
  rect(ctx,x,y,w,h,p.deep);
  rect(ctx,x+2,y+2,w-4,h-4,p.border);
  rect(ctx,x+4,y+4,w-8,h-8,color);
  stroke(ctx,[x+5,y+5],[x+w-5,y+5],p.white,1.2);
  stroke(ctx,[x+5,y+5],[x+5,y+h-5],p.white,1.2);
}

const avatar = {
  snail: ['00011000','00122100','01232210','01223210','00122110','00111013','01222131','01111110'],
  receiver: ['00011100','00122210','01222231','01222321','00122210','00011100','01122210','11122211'],
};
function icon(ctx, name, x, y) {
  for (const [row,line] of avatar[name].entries()) for (let col=0;col<line.length;col++) {
    const value=Number(line[col]);
    if(value) rect(ctx,x+col*3.5,y+row*3.5,3.5,3.5,['', '#46646e','#e3bc72','#fff1b2'][value]);
  }
}

const chatDesktop = plate(ctx => {
  const p=gui;
  rect(ctx,0,0,1000,1000,gradient(ctx,0,0,0,1000,[[0,'#38566e'],[.60,'#83a098'],[1,'#557679']]));
  for(let i=0;i<107;i++){
    const x=i*24-780;
    stroke(ctx,[x,180],[x+810,1000], i%3 ? '#d5e2c725' : '#e4eaca43',i%2 ? 5 : .8);
  }
  pane(ctx, 18, 272, 964, 612, p.light);
  rect(ctx, 26, 280, 948, 50, gradient(ctx, 34, 282, 972, 350, [[0,'#264764'], [.68,'#526e89'], [1,'#6d8995']]));
  icon(ctx,'snail',40,292);
  text(ctx, '纸鹤来信', 86, 314, {face:MONO, weight:700, size:25, fill:'#eef4da'});
  stroke(ctx,[251,292],[251,318],'#a2b2ab',1);
  text(ctx,'远行组',267,312,{face:MONO,size:17, fill:'#d8e4db'});
  for(const [i,symbol] of ['_','□','×'].entries()){
    pane(ctx,861+35*i,290,28,29,p.medium);
    text(ctx,symbol,874+35*i,311,{size:19,align:'center',face:MONO,fill:p.dark});
  }
  rect(ctx,33,337,934,44,p.field);
  for(const [i,label] of ['会话','联系','选项'].entries()) text(ctx,label,52+i*94,367,{size:17,face:MONO,fill:p.dark});
  rect(ctx,36,387,928,425,p.white);
  stroke(ctx,[35,388],[35,813],p.gray,2);
  stroke(ctx,[965,388],[965,813],p.gray,2);
  stroke(ctx,[34,818],[967,818],p.tint,1.8);
  pane(ctx,42,832,790,37,'#e8edda');
  pane(ctx,842,832,111,37,p.medium);
  text(ctx,'发送',899,856,{size:17,face:MONO,fill:p.dark,align:'center'});
  rect(ctx,0,916,1000,49,'#314e68');
  pane(ctx,15,924,148,31,p.medium);
  text(ctx,'纸鹤工作台',89,945,{size:18,face:MONO,align:'center',fill:p.deep});
  text(ctx,'14:25',935,946,{size:17,face:MONO,align:'right',fill:'#e7efd4'});
});

const gifArt=plate(ctx=>{
  const random=rng(121993);
  rect(ctx,0,555,1000,211,'#adbd8a');
  for(let x=0;x<1000;x+=5){
    const y=Math.floor((645+31*Math.sin(x*.008)+12*Math.cos(x*.017))/5)*5;
    rect(ctx,x,y,5,783-y,'#87a579');
    const z=Math.floor((714+12*Math.sin(x*.016)+11*Math.cos(x*.007))/5)*5;
    rect(ctx,x,z,5,787-z,'#688b68');
  }
  rect(ctx,0,764,1000,27,'#c6af82');
  for(let y=559;y<792;y+=3){
    for(let x=0;x<1000;x+=5){
      if(random() < .22)rect(ctx,x+(y%2)*2,y,1.4,1.1,y<=670?'#e4df9b6e':'#d6cb917e');
    }
  }
});

export const chat={
  background(ctx,info){
    chatDesktop(ctx);
    const t=info.local, p=gui;
    const landed = fade(t,1.65,2.12);
    const nudge = fade(t,2.97,3.02)*(1-fade(t,3.12,3.33));
    const jiggle = nudge*Math.cos(t*69)*13;
    ctx.save();
    ctx.translate(jiggle,0);
    icon(ctx,'receiver',63,420);
    text(ctx,'小栖',107,442,{size:19,weight:700,face:MONO,fill:p.dark});
    text(ctx,'（发送了一个动图）',170,442,{size:17,face:MONO,fill:p.gray});
    pane(ctx,50,458,443,47,'#eff1d7');
    text(ctx,'这个会一直骑下去吗？',70,490,{size:21,face:MONO,fill:p.dark});
    if(landed>0){
      ctx.globalAlpha*=landed;
      pane(ctx,54,517,889,289,'#638468');
      ctx.save();
      ctx.beginPath();
      ctx.rect(60,552,877,238);
      ctx.clip();
      gifArt(ctx);
      ctx.restore();
      rect(ctx,60,522,877,28,p.dark);
      text(ctx,'wings_on_wheels.gif',79,543,{size:16,face:MONO,fill:'#e1e3c8'});
      text(ctx,'256 色',918,543,{size:15,face:MONO,align:'right',fill:'#d0ddc6'});
    }
    ctx.restore();
    if(t>2.4 && t<4.30){
      ctx.save();
      ctx.globalAlpha*=fade(t,2.4,2.64)*(1-fade(t,4.02,4.3));
      const dots='.'.repeat(Math.floor((t-2.4)*4)%4);
      text(ctx,'对方正在输入…'+dots,69,857,{size:20,face:MONO,fill:p.dark,weight:650});
      ctx.restore();
    }
    if(t>=4.16){
      ctx.save();
      ctx.globalAlpha*=fade(t,4.16,4.55);
      text(ctx,'小栖：好吧，它真的没有停。',69,857,{size:19,face:MONO,fill:p.dark,weight:650});
      ctx.restore();
    }
  },
  title(ctx,info){title(ctx,info,{paper:'#e7edde',edge:'#466c7b',ink:'#213f58',face:MONO,squared:true,width:315});},
};
