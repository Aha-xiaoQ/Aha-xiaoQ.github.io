import {
  blob, ellipse, fade, gradient, MONO, plate, radial, rect, road, round, stroke, TAU, text, title,
} from './paint.js';

const FACE_X = 484;
const FACE_Y = 607;
const FACE_W = 467;
const FACE_H = 358;

const scopePlate = plate(ctx => {
  rect(ctx, 0, 0, 1000, 1000, gradient(ctx, 0, 0, 0, 1000, [[0,'#151e21'], [.56,'#22312e'], [1,'#101817']]));
  round(ctx, 5, 222, 990, 754, 41, gradient(ctx, 0, 210, 970, 930, [[0,'#394341'], [.37,'#5d665c'], [.66,'#323e3b'], [1,'#202d2c']]), '#10191b', 8);
  round(ctx, 18, 234, 964, 729, 37, null, '#7a7e65', 1.6);
  round(ctx, 34, 252, 936, 698, 27, null, '#242f31', 4);
  ellipse(ctx, FACE_X, FACE_Y, FACE_W + 12, FACE_H + 12, '#182322', '#828373', 3);
  ellipse(ctx, FACE_X, FACE_Y, FACE_W, FACE_H, gradient(ctx, 95, 260, 748, 961, [[0,'#0a1c1a'], [.59,'#102f25'], [1,'#081915']]), '#111b1a', 7);
  ctx.save();
  ctx.beginPath();
  ctx.ellipse(FACE_X, FACE_Y, FACE_W, FACE_H, 0, 0, TAU);
  ctx.clip();
  rect(ctx, 0, 220, 1000, 780, radial(ctx, 523, 641, 484, [[0,'#86ff6e17'], [.65,'#54ba5b08'], [1,'#8afd7c00']]));
  for (let x = 4; x < 1000; x += 47) stroke(ctx, [x,250], [x,964], x === 474 ? '#8ca96761' : '#7aa76438', x === 474 ? 1.6 : .85);
  for (let y = 273; y <= 944; y += 43) stroke(ctx, [14,y], [966,y], y === 617 ? '#8ca96761' : '#7aa76438', y === 617 ? 1.7 : .85);
  for (let i = 0; i < 104; i++) stroke(ctx, [i*9.4+11,615.2], [i*9.4+11,619.8], '#78b07570', .7);
  for (let i = 0; i < 77; i++) stroke(ctx, [471,274+i*8.5], [478,274+i*8.5], '#75a66c50', .7);
  ctx.restore();
  ellipse(ctx, FACE_X, FACE_Y, FACE_W - 5, FACE_H - 5, null, '#66856a57', 4);
  for (const [x, y] of [[47,266],[948,264],[47,925],[947,925]]) {
    ellipse(ctx, x, y, 10.5, 10.5, '#303733', '#a4a18d', 2);
    stroke(ctx, [x - 6,y - 2], [x + 6,y + 2], '#141d1a', 2.8);
  }
  round(ctx, 659, 261, 274, 125, 10, '#333c37', '#7f816a', 2);
  for (let i = 0; i < 9; i++) {
    const x = 706 + i * 18.5;
    stroke(ctx, [x,281], [x+12,281], '#171b1a', 2.8);
  }
  text(ctx, 'X–Y', 820, 366, {size:13, fill:'#cbc293', face:MONO, align:'center'});
  text(ctx, 'GAIN', 894, 366, {size:13, fill:'#cbc293', face:MONO, align:'center'});
  text(ctx, '相位检波', 761, 311, {size:15, fill:'#cec4a2', face:MONO, align:'center'});
});

function dial(ctx, x, y, radians) {
  ellipse(ctx, x, y, 23, 23, '#232b27', '#777d6e', 2);
  const material = gradient(ctx, x - 17, y - 22, x + 16, y + 18, [[0,'#aeb09a'], [.47,'#515e53'], [1,'#26322c']]);
  ellipse(ctx, x, y, 17, 17, material, '#171d1c', 1.7);
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(radians);
  stroke(ctx, [0,-7], [0,-15], '#ffdc8f', 2.8);
  ctx.restore();
}

function adjustHand(ctx, info) {
  const v = info.local;
  const reach = fade(v, 1.69, 2.26) * (1 - fade(v, 3.35, 4.01));
  if (reach <= 0) return;
  const wrench = fade(v, 2.40, 2.63) * (1 - fade(v, 3.02, 3.36));
  ctx.save();
  ctx.translate(-28 + (1 - reach) * 209, (1 - reach) * -87);
  const hand = gradient(ctx, 830, 286, 929, 382, [[0,'#c8b390'], [.52,'#ab9278'], [1,'#675951']]);
  blob(ctx, 'M944 129 L1012 163 971 224 962 255 913 263 899 230Z', '#3f6156', '#242d2a', 3);
  blob(ctx, 'M920 220 L969 247 954 279 908 261Z', '#a9a58c', '#574e45', 2.8);
  blob(ctx, `M917 246 C907 256 897 258 884 273 L868 294 Q859 298 846 ${317 + wrench * 7} Q839 328 848 331 Q855 333 868 317 L881 314 Q887 318 886 324 L873 ${337 + wrench * 5} Q867 348 879 350 Q887 347 897 339 L917 333 Q935 322 941 297 L954 269Z`, hand, '#4e443e', 2.9);
  blob(ctx, 'M889 295 Q900 282 913 279 M886 324 Q894 328 900 321 M914 315 Q924 306 925 294', null, '#776257', 1.45);
  ctx.restore();
}

export const scope = {
  background(ctx, info) {
    scopePlate(ctx);
    const power = .45 + .55 * fade(info.local, 0, .52);
    const signal = info.signalAmount ?? fade(info.local, 2.42, 2.63) * (1 - fade(info.local, 3.02, 3.36));
    const scanY = 281 + ((info.local * 91 + 277) % 638);
    ctx.save();
    ctx.beginPath();
    ctx.ellipse(FACE_X, FACE_Y, FACE_W - 4, FACE_H - 4, 0, 0, TAU);
    ctx.clip();
    rect(ctx, 0, scanY + Math.sin(Math.floor(info.local * 53)) * 1.4, 981, 2.6, '#8ef8a635');
    ctx.globalAlpha *= .28 * power;
    road(ctx, info, '#46d68e', 3.6);
    ctx.restore();
    const lampColor = signal > .32 ? '#efa658' : '#92f4a7';
    ellipse(ctx, 702, 337, 10.25, 10.25, radial(ctx, 702, 337, 10.25, [[0,lampColor], [.61,lampColor + '49'], [1,lampColor + '00']]));
    ellipse(ctx, 702, 337, 4.2, 4.2, lampColor);
    dial(ctx, 817, 332, -.26 + 1.59 * signal);
    dial(ctx, 893, 332, -.5);
  },
  foreground(ctx, info) { adjustHand(ctx, info); },
  title(ctx, info) {
    title(ctx, info, {paper:'#111e1d', edge:'#7baf8c', ink:'#b8ffc4', face:MONO, squared:true, width:294});
  },
};
