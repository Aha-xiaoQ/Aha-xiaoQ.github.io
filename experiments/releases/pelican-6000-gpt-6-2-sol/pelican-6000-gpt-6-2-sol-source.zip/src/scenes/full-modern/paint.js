import { ellipse, rect, round, text, MONO, SERIF } from '../drawing.js';
import { clamp, fade, mix, TAU } from '../../kit/index.js';

export { ellipse, rect, round, text, MONO, SERIF, clamp, fade, mix, TAU };

export function rng(seed) {
  let state = seed >>> 0;
  return () => ((state = (Math.imul(1664525, state) + 1013904223) >>> 0) / 4294967296);
}

export function plate(paint, resolution = 1000) {
  let canvas;
  return ctx => {
    if (!canvas) {
      canvas = document.createElement('canvas');
      canvas.width = canvas.height = resolution;
      const layer = canvas.getContext('2d');
      layer.scale(resolution / 1000, resolution / 1000);
      paint(layer);
    }
    ctx.drawImage(canvas, 0, 0, 1000, 1000);
  };
}

export function blob(ctx, d, color, border, width = 1) {
  const path = typeof d === 'string' ? new Path2D(d) : d;
  if (color) {
    ctx.fillStyle = color;
    ctx.fill(path);
  }
  if (border) {
    ctx.strokeStyle = border;
    ctx.lineWidth = width;
    ctx.stroke(path);
  }
}

export function stroke(ctx, a, b, color, width) {
  ctx.beginPath();
  ctx.moveTo(...a);
  ctx.lineTo(...b);
  ctx.strokeStyle = color;
  ctx.lineWidth = width;
  ctx.stroke();
}

export function bristle(ctx, x, y, angle, length, width, color) {
  const dx = Math.cos(angle) * length;
  const dy = Math.sin(angle) * length;
  ctx.save();
  ctx.lineCap = 'round';
  stroke(ctx, [x, y], [x + dx, y + dy], color, width);
  ctx.globalAlpha *= .47;
  stroke(ctx,
    [x - dy * .048, y + dx * .048],
    [x + dx * .75 - dy * .048, y + dy * .75 + dx * .048],
    '#eacba0', width * .24);
  ctx.restore();
}

export function gradient(ctx, x0, y0, x1, y1, stops) {
  const g = ctx.createLinearGradient(x0, y0, x1, y1);
  for (const [offset, color] of stops) g.addColorStop(offset, color);
  return g;
}

export function radial(ctx, x, y, radius, stops) {
  const g = ctx.createRadialGradient(x, y, 0.01, x, y, radius);
  for (const [offset, color] of stops) g.addColorStop(offset, color);
  return g;
}

export function road(ctx, info, color, width = 2, y = 0, from = 0, to = 1000) {
  ctx.beginPath();
  ctx.moveTo(from, info.floorAt(from) + y);
  for (let x = from + 8; x < to; x += 8) ctx.lineTo(x, info.floorAt(x) + y);
  ctx.lineTo(to, info.floorAt(to) + y);
  ctx.lineWidth = width;
  ctx.strokeStyle = color;
  ctx.stroke();
}

export function title(ctx, info, style) {
  const { scene } = info;
  const { paper, ink, edge, width = 282, squared = false, face = SERIF } = style;
  ctx.save();
  round(ctx, 0, 0, width, 119, squared ? 0 : 4, paper, edge, 2);
  stroke(ctx, [17, 67], [width - 17, 67], edge, 1);
  text(ctx, scene.zh, 17, 50, {size: 35, fill: ink, face, weight: 700, maxWidth: width - 34});
  text(ctx, scene.en, 17, 87, {size: 16, fill: ink, face, maxWidth: width - 34});
  text(ctx, scene.era, 17, 108, {size: 16, fill: ink, face, maxWidth: width - 34});
  ctx.restore();
}
