import {
  blob, bristle, ellipse, fade, gradient, plate, radial, rect, road, rng, TAU, title,
} from './paint.js';

const skyTones = ['#174669', '#285a7c', '#295c8d', '#346d9a', '#4e91a8', '#638ea1', '#173860', '#427692'];

const starField = plate(ctx => {
  rect(ctx, 0, 0, 1000, 1000, gradient(ctx, 0, 0, 0, 850, [[0,'#102d51'], [.43,'#1d4b83'], [.67,'#243f73'], [1,'#141e40']]));
  const random = rng(82629);
  for (let i = 0; i < 4050; i++) {
    const x = random() * 1000;
    const y = random() * 711;
    const a = .37 * Math.sin(x * .009 - y * .009) + .17 * Math.cos(y * .017) + .3;
    bristle(ctx, x, y, a + (random() - .5) * .19, 8 + random() * 28, 1.25 + random() * 3.4, skyTones[i % skyTones.length]);
  }
});

const village = plate(ctx => {
  blob(ctx, 'M0 669 C122 578 251 649 309 599 C381 569 396 644 491 600 C607 535 645 584 750 539 Q912 519 1000 625 V1000 H0Z', '#304f74');
  blob(ctx, 'M0 684 C154 624 196 683 342 643 S507 651 597 598 S839 654 1000 578 V1000 H0Z', '#172c56');
  const random = rng(81196);
  for (let i = 0; i < 690; i++) {
    const x = random() * 1000;
    const y = 660 + random() * 340;
    bristle(ctx, x, y, Math.sin(x * .012) * .19 - .07, 7 + random() * 19, 1 + random() * 3, ['#2b456a', '#173853', '#2c4f69', '#315574', '#314965'][i % 5]);
  }
  for (let i = 0; i < 32; i++) {
    const x = 39 + i * 31 + (random() - .5) * 26;
    const y = 695 + 22 * random() + 11 * Math.sin(i * .5);
    const w = 14 + random() * 23;
    const h = 12 + random() * 23;
    blob(ctx, `M${x} ${y} l${w * .56} ${-h * .65} ${w * .57} ${h * .67} v${h} h${-w}Z`, ['#162647','#27395b','#42617a'][i % 3], '#7e827e', .9);
    if (i % 4) rect(ctx, x + w * .38, y + h * .31, 3.5, h * .35, '#d9a65f');
    if (i % 5 === 1) rect(ctx, x + w * .65, y + h * .43, 3, h * .28, '#efd67d');
  }
  blob(ctx, 'M845 712 L846 682 854 681 855 657 860 654 863 623 868 655 873 657 875 684 884 684 885 716Z', '#16283e', '#395671', 1.5);
  rect(ctx, 859, 680, 4, 10, '#fab86b');
});

function paintHalo(ctx, radius) {
  ellipse(ctx, 0, 0, radius * 1.58, radius * 1.58, radial(ctx, 0, 0, radius * 1.58, [[0,'#f8de85c4'], [.42,'#ead37c84'], [1,'#dbc66700']]));
  for (let row = 0; row < 6; row++) {
    const r = radius * (.3 + row * .21);
    const count = Math.max(7, Math.round(r * .96));
    for (let i = 0; i < count; i++) {
      const a = TAU * i / count + row * .17;
      const wobble = 1 + .075 * Math.sin(a * 5 + row * 2.7);
      bristle(ctx, Math.cos(a) * r * wobble, Math.sin(a) * r, a + 1.57, 4 + r * .08, 2.1 + row * .33, ['#ffe59a','#eac974','#d0b687','#b7b79a','#73a0a8','#597eae'][row]);
    }
  }
  ellipse(ctx, 0, 0, radius * .23, radius * .24, '#fff0a8');
}

const halos = new Map();

function halo(ctx, x, y, radius, angle, size) {
  if (!halos.has(radius)) {
    const canvas = document.createElement('canvas');
    canvas.width = canvas.height = Math.ceil(radius * 3.5);
    const g = canvas.getContext('2d');
    g.translate(canvas.width / 2, canvas.height / 2);
    paintHalo(g, radius);
    halos.set(radius, canvas);
  }
  const canvas = halos.get(radius);
  const span = canvas.width * size;
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(angle);
  ctx.drawImage(canvas, -span / 2, -span / 2, span, span);
  ctx.restore();
}

const whorls = plate(ctx => {
  ctx.translate(500, 500);
  for (let arm = 0; arm < 3; arm++) {
    for (let stream = 0; stream < 13; stream++) {
      for (let i = 0; i < 48; i++) {
        const u = i / 48;
        const a = u * 5.5 + arm * TAU / 3 + stream * .025;
        const r = 11 + u * 202 + stream * (1 + u * 2.2);
        const x = r * Math.cos(a);
        const y = r * Math.sin(a) * .82;
        bristle(ctx, x, y, a + 1.19, 8 + 10 * u, 2.8 + u * 2.1, ['#5381a4','#7b9faa','#6297b8','#99b7a6','#3a70a1','#376497','#b3b997'][stream % 7]);
      }
    }
  }
});

function windWhorls(ctx, angle) {
  ctx.save();
  ctx.translate(577, 493);
  ctx.rotate(angle);
  ctx.scale(1.44, .73);
  ctx.translate(-500, -500);
  whorls(ctx);
  ctx.restore();
}

const cypressOutline = 'M0 1000 V656 Q42 598 47 552 Q66 574 79 502 Q93 407 139 369 Q120 423 126 458 Q144 450 171 392 Q179 463 163 507 Q190 483 204 456 Q216 517 185 563 Q212 533 229 537 Q241 615 199 653 Q239 620 250 658 Q263 719 215 774 Q237 766 256 771 Q279 856 246 907 L278 1000Z';
const trees = plate(ctx => {
  blob(ctx, cypressOutline, '#111e35', '#314557', 6);
  ctx.save();
  ctx.clip(new Path2D(cypressOutline));
  const random = rng(589);
  for (let i = 0; i < 553; i++) {
    const x = random() * 285;
    const y = 399 + random() * 600;
    bristle(ctx, x, y, -1.29 + .24 * Math.sin(x * .14 + y * .034), 19 + random() * 51, 1.4 + random() * 4.6, ['#20354a','#29434b','#354650','#26394b','#47605d'][i % 5]);
  }
  ctx.restore();
});

export const starry = {
  background(ctx, info) {
    starField(ctx);
    const wheel = info.wheelAngle ?? 0;
    const bloom = fade(info.local, 1.35, 2.27) * (1 - fade(info.local, 4.28, 5.54));
    windWhorls(ctx, wheel * .154 + bloom * .37);
    for (const [x,y,r,direction] of [[128,506,36,1],[278,471,25,-1],[396,427,39,1],[527,556,21,-1],[753,429,31,1],[864,372,56,1],[932,527,28,-1],[74,381,21,1]]) {
      halo(ctx, x, y, r, wheel * direction * .44, 1 + .08 * bloom * Math.sin(wheel));
    }
    village(ctx);
    road(ctx, info, '#28486c', 27, 7);
    road(ctx, info, '#597e89', 6, 2.7);
    road(ctx, info, '#999988', 2);
  },
  foreground(ctx) { trees(ctx); },
  title(ctx, info) {
    title(ctx, info, {paper:'#16294b', edge:'#d6bc76', ink:'#fff0b5'});
  },
};
