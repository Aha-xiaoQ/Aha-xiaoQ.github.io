import { starry } from './starry-night.js';
import { scream } from './the-scream.js';
import { shadow } from './nosferatu.js';
import { scope } from './oscilloscope.js';
import { pixel } from './pixel.js';
import { chat } from './chat.js';
import { vapor } from './vapor.js';

export const MODERN = new Map([
  [11, starry],
  [12, scream],
  [13, shadow],
  [14, scope],
  [15, pixel],
  [16, chat],
  [17, vapor],
]);
