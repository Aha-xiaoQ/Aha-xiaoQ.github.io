import {
  blob, bristle, ellipse, fade, gradient, plate, rect, road, rng, stroke, title,
} from './paint.js';

const skyRibbon = ['#f1b16d','#f18755','#d35c49','#d38b59','#eeb580','#b04c48','#d57867'];

function skyY(x, y, wave) {
  const roll = 28 * Math.sin(x * .0058 - y * .007) + 10 * Math.cos(x * .015 + y * .035);
  return y + roll + wave * (26 * Math.sin(x * .024 - y * .014) + 11 * Math.sin(x * .042 + y * .018));
}

function screamSky(ctx, wave) {
  rect(ctx, 0, 0, 1000, 1000, '#db8b65');
  for (let i = 0; i < 32; i++) {
    ctx.beginPath();
    const base = i * 19 - 19;
    ctx.moveTo(0, skyY(0, base, wave));
    for (let x = 17; x <= 1020; x += 17) ctx.lineTo(x, skyY(x, base, wave));
    ctx.strokeStyle = skyRibbon[i % skyRibbon.length];
    ctx.lineWidth = 27;
    ctx.stroke();
    ctx.strokeStyle = '#702d3980';
    ctx.lineWidth = .9 + i % 4 * .4;
    ctx.stroke();
  }
}

const fjord = plate(ctx => {
  blob(ctx, 'M0 582 C120 499 240 588 337 553 C483 447 546 591 679 522 C791 454 905 486 1000 440 V820 H0Z', '#32394c', '#504159', 5);
  blob(ctx, 'M0 617 Q44 567 159 571 Q235 599 365 576 Q452 541 584 593 Q679 642 788 564 Q886 490 1000 532 V846 H0Z', '#516273', '#50475b', 7);
  blob(ctx, 'M0 642 C180 574 263 635 374 639 S565 583 705 641 S880 558 1000 575 V813 H0Z', '#526d82', '#273e55', 5);
  const random = rng(19631);
  for (let i = 0; i < 400; i++) {
    const x = random() * 1000;
    const bottomY = 608 + random() * 191;
    const y = bottomY + 12 * Math.sin(x * .008);
    bristle(ctx, x, y, -.2 + Math.cos(x * .007) * .15, 9 + random() * 24, 1.2 + random() * 3, ['#627b83','#315166','#766772','#996d73','#4f586c'][i % 5]);
  }
  blob(ctx, 'M121 658 q11 5 27 -2 q-8 13 -19 11Z M846 613 q12 4 27 -1 q-7 9 -17 9Z', '#414258', '#b79176', 1.6);
});

function bridge(ctx, info) {
  blob(ctx, 'M0 740 Q252 663 488 670 L1000 704 V1000 H0Z', gradient(ctx, 0, 690, 0, 1000, [[0,'#a36d59'], [.28,'#8e554d'], [1,'#4f303a']]), '#4b3845', 8);
  const random = rng(1991);
  for (let i = 0; i < 125; i++) {
    const x = 1000 * random();
    const y = 775 + random() * 240;
    stroke(ctx, [x,y], [x + 31 + random() * 69, y + (x - 390) * .048], '#c7896760', .6 + random() * 3);
  }
  for (let i = 0; i < 11; i++) {
    const x = 26 + i * 103;
    const y = 712 - .075 * x + .000071 * x ** 2;
    stroke(ctx, [x,y], [x+13,y+84], '#472f3e', 9.3);
    stroke(ctx, [x-4,y], [x+9,y+83], '#d19874', 2.8);
  }
  blob(ctx, 'M-10 726 Q363 609 1004 704 M-6 752 Q313 656 1008 721', null, '#42273c', 8.5);
  blob(ctx, 'M-10 723 Q363 606 1004 701 M-6 750 Q313 653 1008 719', null, '#ba7d62', 3.1);
  road(ctx, info, '#a37564', 4, 3);
}

function witness(ctx, shock) {
  const recoil = shock * 13;
  ctx.save();
  ctx.translate(587 + recoil, 706);
  ctx.rotate(shock * .17 - .065);
  blob(ctx, 'M-5 -99 Q-29 -83 -44 -39 L-54 40 Q-16 55 10 40 Q23 50 33 29 L33 -10 Q22 -59 14 -102Z', '#45374e', '#352c43', 5);
  blob(ctx, 'M-36 -55 q17 14 28 88 M15 -61 q-1 56 19 82 M-20 -51 l-19 78 M-17 -15 l11 60', null, '#695669', 3.3);
  const handBob = 24 * (1 - shock);
  blob(ctx, `M-40 -20 Q-50 -66 -32 ${-106 + handBob} l12 -10 9 6 -10 17 Q-30 -49 -23 -33Z M31 -20 Q46 -75 29 ${-108 + handBob} l-11 -10 -8 4 8 16 Q29 -52 14 -30Z`, '#db9e78', '#633e48', 3.2);
  blob(ctx, 'M-26 -118 Q-36 -151 -17 -174 Q1 -189 21 -172 Q42 -161 29 -131 Q15 -111 11 -94 Q-2 -75 -14 -96Z', '#dfb589', '#694649', 4);
  blob(ctx, 'M-23 -161 q14 -17 35 -12 q12 2 17 13 M-27 -135 q8 7 11 18 M23 -139 q-2 14 -9 25', null, '#965847', 3);
  for (const x of [-13, 14]) {
    ellipse(ctx, x, -144, 7 + shock * 2, 3.1 + shock * 5.5, '#f8d7a2', '#643f48', 1.4);
    ellipse(ctx, x - 1.5, -144, 2.5, 2.4 + shock, '#412e40');
  }
  blob(ctx, 'M-4 -146 L-8 -132 -1 -129 3 -133', null, '#94524d', 2.1);
  ellipse(ctx, -1, -113, 3.5 + shock * 7.2, 2 + shock * 13.7, '#5c3043', '#b3675a', 2);
  ctx.restore();
}

export const scream = {
  background(ctx, info) {
    const shock = fade(info.local, 2.12, 2.46) * (1 - fade(info.local, 3.73, 4.92));
    screamSky(ctx, shock);
    fjord(ctx);
    bridge(ctx, info);
    witness(ctx, shock);
  },
  foreground(ctx, info) {
    const age = info.local - 2.52;
    if (age < 0 || age > 1.25) return;
    ctx.save();
    ctx.globalAlpha *= .44 * (1 - age / 1.25);
    for (let i = 0; i < 4; i++) {
      const r = 21 + 58 * age + i * 15;
      ctx.beginPath();
      ctx.ellipse(586, 567, r, r * 1.27, .21, 2.16, 5.87);
      ctx.strokeStyle = i % 2 ? '#902d49' : '#ffd096';
      ctx.lineWidth = 2.35;
      ctx.stroke();
    }
    ctx.restore();
  },
  title(ctx, info) {
    title(ctx, info, {paper:'#5b354c', edge:'#e5a76f', ink:'#ffe4b1'});
  },
};
