import { mkdir, writeFile } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { parseArgs } from 'node:util';
import { browserOptions, framePng, openFilm, projectRoot } from './browser.mjs';

const { values } = parseArgs({ options: {
  ...browserOptions,
  times: { type: 'string' },
  study: { type: 'boolean' },
  output: { type: 'string', default: join(projectRoot, 'exports', 'stills') },
  force: { type: 'boolean' },
  help: { type: 'boolean' },
} });

if (values.help) {
  console.log('npm run stills -- --times 1.8,4.35,5,7.2,32,116,127.1,135.7 --study [--output exports/stills] [--force]\nOptional: --html path --chrome path');
} else {
  const times = values.times ? values.times.split(',').map((value) => value.trim() === '' ? NaN : Number(value)) : [];
  if (times.some((time) => !Number.isFinite(time) || time < 0) || (!times.length && !values.study)) {
    throw new Error('Provide comma-separated times in seconds or --study.');
  }
  const output = resolve(values.output);
  await mkdir(output, { recursive: true });
  const { browser, page } = await openFilm(values);
  try {
    const duration = await page.evaluate(() => window.SOL_R7.duration);
    if (times.some((time) => time > duration)) throw new Error('Still time is outside the film.');
    for (const time of new Set(values.study ? [...times, null] : times)) {
      const name = time === null ? 'Sol_R7_study.png' : `Sol_R7_${String(time).padStart(3, '0')}s.png`;
      const file = join(output, name);
      await writeFile(file, await framePng(page, time), { flag: values.force ? 'w' : 'wx' });
      console.log(file);
    }
  } finally {
    await browser.close();
  }
}
