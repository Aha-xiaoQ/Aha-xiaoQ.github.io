import { createHash, randomUUID } from 'node:crypto';
import { open, link, rename, unlink, writeFile } from 'node:fs/promises';
import { extname, join } from 'node:path';
import { parseArgs } from 'node:util';
import { build } from 'esbuild';
import puppeteer from 'puppeteer-core';
import { prepareOutput, projectRoot } from './browser.mjs';

const sampleRate = 48000;
const channels = 2;
const bytesPerSample = 3;
const chunkFrames = 196608;
const { values } = parseArgs({ options: {
  output: { type: 'string', default: join(projectRoot, 'exports', 'final', 'Sol_R7_Original_Score.wav') },
  receipt: { type: 'string' },
  chrome: { type: 'string' },
  force: { type: 'boolean' },
  help: { type: 'boolean' },
} });

function header(frames) {
  const block = channels * bytesPerSample;
  const payload = frames * block;
  const bytes = Buffer.alloc(44);
  bytes.write('RIFF', 0);
  bytes.writeUInt32LE(payload + 36, 4);
  bytes.write('WAVEfmt ', 8);
  bytes.writeUInt32LE(16, 16);
  bytes.writeUInt16LE(1, 20);
  bytes.writeUInt16LE(channels, 22);
  bytes.writeUInt32LE(sampleRate, 24);
  bytes.writeUInt32LE(sampleRate * block, 28);
  bytes.writeUInt16LE(block, 32);
  bytes.writeUInt16LE(bytesPerSample * 8, 34);
  bytes.write('data', 36);
  bytes.writeUInt32LE(payload, 40);
  return bytes;
}

function verifyPlan(plan, frames) {
  if (frames !== 137 * sampleRate || plan.bpm !== 120 || plan.segments.length !== 22) {
    throw new Error('The score should cover 137 seconds and have 22 sections at 120 BPM.');
  }
  for (const [index, row] of plan.segments.entries()) {
    const expected = index === 0 ? 0 : 5 + (index - 1) * 6;
    if (row.start !== expected) throw new Error(`${row.id} begins at ${row.start} instead of ${expected}.`);
  }
  const voices = plan.pixel.map(({ id }) => id).join(',');
  if (voices !== 'square1,square2,triangle,noise') throw new Error(`Unexpected pixel channels ${voices}.`);
  for (const { id, events } of plan.pixel) {
    if (events.some(({ at, end }, i) => !(at >= 0 && at < end && end <= (events[i + 1]?.at ?? 6)))) {
      throw new Error(`The ${id} channel contains overlapping or out-of-range events.`);
    }
  }
}

function signalWindows(plan) {
  const cue = plan.cues;
  return [
    ...plan.segments.map(({ id, start, duration }) => [id, start, start + duration]),
    ['intro.emphasis', cue.beforeBicycle, cue.beforeBicycle + 0.17],
    ['sahara.prePause', 7.01, 7.27],
    ['sahara.pause', cue.saharaPause, 7.76],
    ...cue.saharaHooves.map((time, i) => [`sahara.hoof${i + 1}`, time, time + 0.041]),
    ['song.harmonic', cue.songHarmonic, cue.songHarmonic + 0.125],
    ['scope.powerOn', cue.shadowPowerOn, cue.shadowPowerOn + 0.083],
    ['scope.tuning', ...cue.scopeTuning],
    ['pixel.coin', cue.pixelCoin, cue.pixelCoin + 0.26],
    ['chat.typing', ...cue.chatTyping],
    ['chat.message', cue.chatMessage, cue.chatMessage + 0.52],
    ['vapor.stutter', cue.vaporStutter[0], cue.vaporStutter.at(-1) + 0.25],
    ['vertical.breath', 115.52, 115.59],
    ['vertical.comment', cue.verticalComment, cue.verticalReturn],
    ['vertical.beatReturn', cue.verticalReturn, cue.verticalReturn + 0.21],
    ...cue.outroFlashes.map((time, i) => [`outro.flash${i + 1}`, time, time + 0.125]),
    ['outro.beforeBell', 136.29, cue.outroBell],
    ['outro.bell', cue.outroBell, cue.outroBell + 0.30],
    ['outro.lastFrame', 137 - 0.0167, 137],
  ].map(([id, start, end]) => ({ id, start, end, from: Math.round(start * sampleRate), to: Math.round(end * sampleRate), sum: 0, peak: 0 }));
}

function measureChunk(bytes, start, windows) {
  const end = start + bytes.length / (channels * bytesPerSample);
  for (const window of windows) {
    const from = Math.max(start, window.from);
    const to = Math.min(end, window.to);
    for (let frame = from; frame < to; frame += 1) {
      const offset = (frame - start) * channels * bytesPerSample;
      const left = bytes.readIntLE(offset, 3) / 8388608;
      const right = bytes.readIntLE(offset + 3, 3) / 8388608;
      window.sum += left * left + right * right;
      window.peak = Math.max(window.peak, Math.abs(left), Math.abs(right));
    }
  }
}

const decibels = (v) => Number((20 * Math.log10(Math.max(v, 1e-10))).toFixed(2));

async function render() {
  const file = await prepareOutput(values.output);
  if (extname(file).toLowerCase() !== '.wav') throw new Error('Use a WAV output path.');
  const script = await build({
    absWorkingDir: projectRoot,
    entryPoints: ['audio/full-score.js'],
    bundle: true,
    format: 'iife',
    globalName: 'SolR7FullScore',
    platform: 'browser',
    write: false,
  });
  const executablePath = values.chrome || process.env.CHROME_PATH || process.env.CHROMIUM;
  const browser = await puppeteer.launch({ ...(executablePath ? { executablePath } : { channel: 'chrome' }), headless: true });
  const temporary = `${file}.${randomUUID()}.part`;
  try {
    const page = await browser.newPage();
    await page.setOfflineMode(true);
    await page.addScriptTag({ content: script.outputFiles[0].text });
    const { plan, frames } = await page.evaluate(async (rate) => {
      const { renderFullAudio, fullScorePlan } = window.SolR7FullScore;
      const buffer = await renderFullAudio({ sampleRate: rate });
      window.scoreChannels = [buffer.getChannelData(0), buffer.getChannelData(1)];
      return { plan: fullScorePlan(), frames: buffer.length };
    }, sampleRate);
    verifyPlan(plan, frames);
    const windows = signalWindows(plan);
    const wav = await open(temporary, 'wx');
    const hash = createHash('sha256');
    try {
      const write = async (bytes) => {
        await wav.writeFile(bytes);
        hash.update(bytes);
      };
      await write(header(frames));
      for (let start = 0; start < frames; start += chunkFrames) {
        const count = Math.min(chunkFrames, frames - start);
        const base64 = await page.evaluate((from, length) => {
          const bytes = new Uint8Array(length * 6);
          let offset = 0;
          for (let i = from; i < from + length; i += 1) {
            for (const channel of window.scoreChannels) {
              const value = Math.round(channel[i] * 8388608);
              bytes[offset++] = value & 255;
              bytes[offset++] = (value >> 8) & 255;
              bytes[offset++] = (value >> 16) & 255;
            }
          }
          let raw = '';
          for (let i = 0; i < bytes.length; i += 16384) raw += String.fromCharCode(...bytes.subarray(i, i + 16384));
          return btoa(raw);
        }, start, count);
        const bytes = Buffer.from(base64, 'base64');
        if (bytes.length !== count * 6) throw new Error(`Invalid byte count near frame ${start}.`);
        measureChunk(bytes, start, windows);
        await write(bytes);
      }
    } finally {
      await wav.close();
    }
    const peak = Math.max(...windows.map(({ peak }) => peak));
    if (decibels(peak) > -4.5 || decibels(peak) < -5) throw new Error(`Unexpected master peak of ${decibels(peak)} dBFS.`);
    const intervals = windows.map(({ id, start, end, from, to, peak, sum }) => ({
      id, start, end, peakDbfs: decibels(peak), rmsDbfs: decibels(Math.sqrt(sum / ((to - from) * channels))),
    }));
    const measured = Object.fromEntries(intervals.map((v) => [v.id, v]));
    if (measured['sahara.pause'].rmsDbfs > measured['sahara.prePause'].rmsDbfs - 8
      || measured['vertical.breath'].rmsDbfs > measured['vertical.beatReturn'].rmsDbfs - 13
      || measured['outro.beforeBell'].peakDbfs > -65
      || measured['outro.lastFrame'].peakDbfs > -55) throw new Error(`The PCM failed a pause or fade check. ${JSON.stringify(intervals.slice(22))}`);
    if (intervals.slice(0, 22).some(({ rmsDbfs }) => rmsDbfs < -42)
      || intervals.slice(22).filter(({ id }) => !/pause|breath|beforeBell|lastFrame/.test(id)).some(({ peakDbfs }) => peakDbfs < -38)) {
      throw new Error(`The PCM has an unexpectedly quiet cue or segment. ${JSON.stringify(intervals)}`);
    }
    if (values.force) await rename(temporary, file);
    else await link(temporary, file);
    const result = {
      file, sha256: hash.digest('hex'), format: 'PCM signed 24-bit little-endian WAV', channels, sampleRate,
      frames, peakDbfs: decibels(peak), plan, intervals,
    };
    if (values.receipt) await writeFile(await prepareOutput(values.receipt), JSON.stringify(result, null, 2) + '\n', { flag: values.force ? 'w' : 'wx' });
    console.log(JSON.stringify({ file, sha256: result.sha256, duration: frames / sampleRate, frames, peakDbfs: result.peakDbfs, intervals }, null, 2));
  } finally {
    await browser.close();
    await unlink(temporary).catch((error) => { if (error.code !== 'ENOENT') throw error; });
  }
}

if (values.help) {
  console.log('node tools/audio-master.mjs [--output path.wav] [--receipt path.json] [--chrome path] [--force]');
} else {
  await render();
}
