import { createHash, randomUUID } from 'node:crypto';
import { link, rename, unlink, writeFile } from 'node:fs/promises';
import { extname, join } from 'node:path';
import { parseArgs } from 'node:util';
import { build } from 'esbuild';
import puppeteer from 'puppeteer-core';
import { prepareOutput, projectRoot } from './browser.mjs';

const { values } = parseArgs({ options: {
  scene: { type: 'string', multiple: true },
  tail: { type: 'string', default: '0.25' },
  output: { type: 'string', default: join(projectRoot, 'exports', 'stage2', 'Sol_R7_音乐试奏.wav') },
  chrome: { type: 'string' },
  force: { type: 'boolean' },
  help: { type: 'boolean' },
} });

if (values.help) {
  console.log('node tools/audio-study.mjs [--scene sahara --scene song --scene vertical] [--tail .25] [--output path.wav] [--chrome path] [--force]');
} else {
  const file = await prepareOutput(values.output);
  if (extname(file).toLowerCase() !== '.wav') throw new Error('Output must use the .wav extension.');
  const script = await build({
    absWorkingDir: projectRoot,
    entryPoints: ['audio/study-score.js'],
    bundle: true,
    format: 'iife',
    globalName: 'SolR7MusicStudy',
    platform: 'browser',
    write: false,
  });
  const executablePath = values.chrome || process.env.CHROME_PATH || process.env.CHROMIUM;
  const browser = await puppeteer.launch({
    ...(executablePath ? { executablePath } : { channel: 'chrome' }),
    headless: true,
  });
  let result;
  try {
    const page = await browser.newPage();
    await page.setOfflineMode(true);
    await page.addScriptTag({ content: script.outputFiles[0].text });
    result = await page.evaluate(async (options) => {
      const { renderStudyAudio, encodeStudyWav } = window.SolR7MusicStudy;
      const { buffer, plan } = await renderStudyAudio(options);
      const bytes = encodeStudyWav(buffer);
      const db = (n) => 20 * Math.log10(Math.max(1e-10, n));

      function measure(start, end) {
        const from = Math.round(start * buffer.sampleRate);
        const until = Math.min(buffer.length, Math.round(end * buffer.sampleRate));
        let sum = 0;
        let peak = 0;
        for (let channel = 0; channel < buffer.numberOfChannels; channel += 1) {
          const channelData = buffer.getChannelData(channel);
          for (let index = from; index < until; index += 1) {
            const sample = channelData[index];
            if (!Number.isFinite(sample)) throw new Error(`Nonfinite sample in channel ${channel} at ${index}.`);
            peak = Math.max(peak, Math.abs(sample));
            sum += sample * sample;
          }
        }
        return { peak, peakDb: db(peak), rmsDb: db(Math.sqrt(sum / ((until - from) * buffer.numberOfChannels))) };
      }

      const total = measure(0, buffer.duration);
      if (total.peak >= 1 || total.peak < 0.01) throw new Error(`Unexpected master peak ${total.peak}.`);
      const segments = plan.segments.map((segment) => ({ ...segment, ...measure(segment.start, segment.start + segment.duration) }));
      let raw = '';
      for (let index = 0; index < bytes.length; index += 16384) {
        raw += String.fromCharCode(...bytes.subarray(index, index + 16384));
      }
      return { base64: btoa(raw), plan: { ...plan, segments }, total, frames: buffer.length, channels: buffer.numberOfChannels, sampleRate: buffer.sampleRate };
    }, { ...(values.scene ? { scenes: values.scene } : {}), tail: Number(values.tail) });
  } finally {
    await browser.close();
  }

  const { base64, ...receipt } = result;
  const bytes = Buffer.from(base64, 'base64');
  const temporary = `${file}.${randomUUID()}.part`;
  try {
    await writeFile(temporary, bytes, { flag: 'wx' });
    if (values.force) await rename(temporary, file);
    else await link(temporary, file);
  } finally {
    await unlink(temporary).catch((error) => { if (error.code !== 'ENOENT') throw error; });
  }
  const sha256 = createHash('sha256').update(bytes).digest('hex');
  console.log(JSON.stringify({ file, sha256, ...receipt }, null, 2));
}
