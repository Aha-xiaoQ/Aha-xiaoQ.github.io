import {execFile} from 'node:child_process';
import {createHash, randomUUID} from 'node:crypto';
import {mkdir, open, readFile, rename, unlink, writeFile} from 'node:fs/promises';
import {dirname, join, resolve} from 'node:path';
import {promisify, parseArgs} from 'node:util';
import {browserOptions, openFilm, projectRoot} from './browser.mjs';

const run = promisify(execFile);
const {values} = parseArgs({options: {
  ...browserOptions,
  audio: {type: 'string'},
  output: {type: 'string', default: join(projectRoot, 'exports', 'final', 'Sol_R7_1080p60.mp4')},
  workers: {type: 'string', default: '3'},
  bitrate: {type: 'string', default: '20000000'},
  ffmpeg: {type: 'string', default: 'ffmpeg'},
  ffprobe: {type: 'string', default: 'ffprobe'},
  segment: {type: 'string'},
  'video-only': {type: 'boolean'},
  force: {type: 'boolean'},
  help: {type: 'boolean'},
}});

const FPS = 60;
const CHUNK_FRAMES = 36;
const CODEC = 'avc1.64002A';
const digest = bytes => createHash('sha256').update(bytes).digest('hex');
const commandOptions = {windowsHide: true, maxBuffer: 1024 * 1024};

function quoteForConcat(path) {
  return `'${path.replaceAll('\\', '/').replaceAll("'", "'\\''")}'`;
}

async function probe(path) {
  const {stdout} = await run(values.ffprobe, ['-v', 'error', '-show_entries',
    'stream=codec_type,codec_name,width,height,duration,nb_frames,avg_frame_rate', '-of', 'json', path], commandOptions);
  return JSON.parse(stdout).streams;
}

async function cachedClip(clip, file, stamp, key) {
  try {
    const saved = JSON.parse(await readFile(stamp, 'utf8'));
    const bytes = await readFile(file);
    return saved.key === key && saved.start === clip.start && saved.frames === clip.frames && saved.sha256 === digest(bytes);
  } catch {
    return false;
  }
}

async function configureEncoder(page, bitrate) {
  await page.evaluate(async ({codec, fps, rate}) => {
    const config = {codec, width: 1920, height: 1080, framerate: fps, bitrate: rate,
      latencyMode: 'realtime', hardwareAcceleration: 'prefer-software', avc: {format: 'annexb'}};
    if (!globalThis.VideoEncoder || !(await VideoEncoder.isConfigSupported(config)).supported) {
      throw Error('The selected Chrome does not support software H.264 with WebCodecs. Use the PNG renderer for this platform.');
    }
    const canvas = document.querySelector('#film');
    let error;
    let pieces = [];
    const encoder = new VideoEncoder({
      output(chunk) {
        const bytes = new Uint8Array(chunk.byteLength);
        chunk.copyTo(bytes);
        pieces.push({bytes, timestamp: chunk.timestamp});
      },
      error(reason) { error = reason.message; },
    });
    encoder.configure(config);
    window.encodeFilmFrames = async (start, first, count) => {
      pieces = [];
      const microseconds = n => Math.round(n * 1_000_000 / fps);
      for (let frameIndex = first; frameIndex < first + count; frameIndex += 1) {
        if (error) throw Error(error);
        window.SOL_R7.renderAt(start + frameIndex / fps);
        const time = microseconds(frameIndex);
        const frame = new VideoFrame(canvas, {timestamp: time, duration: microseconds(frameIndex + 1) - time, alpha: 'discard'});
        encoder.encode(frame, {keyFrame: frameIndex % (2 * fps) === 0});
        frame.close();
        if (encoder.encodeQueueSize > 9) await encoder.flush();
      }
      await encoder.flush();
      if (error) throw Error(error);
      if (pieces.length !== count || pieces.some((p, i) => p.timestamp !== microseconds(first + i))) {
        throw Error(`Unexpected H.264 frame count or order in batch ${first}`);
      }
      const buffer = new Uint8Array(pieces.reduce((total, item) => total + item.bytes.length, 0));
      let offset = 0;
      for (const {bytes} of pieces) {
        buffer.set(bytes, offset);
        offset += bytes.length;
      }
      let portable = '';
      for (let i = 0; i < buffer.length; i += 16384) portable += String.fromCharCode(...buffer.subarray(i, i + 16384));
      return btoa(portable);
    };
    window.closeFilmEncoder = () => encoder.close();
  }, {codec: CODEC, fps: FPS, rate: bitrate});
}

async function renderClip(page, clip, directory, key, bitrate) {
  const stem = String(clip.index).padStart(2, '0');
  const file = join(directory, `${stem}.mp4`);
  const stamp = join(directory, `${stem}.json`);
  if (await cachedClip(clip, file, stamp, key)) {
    console.log(`Reuse ${stem} · ${clip.start}s · ${clip.frames} frames`);
    return file;
  }
  const nonce = randomUUID();
  const elementary = join(directory, `${stem}.${nonce}.h264`);
  const wrapped = join(directory, `${stem}.${nonce}.mp4`);
  let handle;
  try {
    handle = await open(elementary, 'wx');
    await configureEncoder(page, bitrate);
    for (let from = 0; from < clip.frames; from += CHUNK_FRAMES) {
      const count = Math.min(CHUNK_FRAMES, clip.frames - from);
      const data = await page.evaluate((...args) => window.encodeFilmFrames(...args), clip.start, from, count);
      await handle.writeFile(Buffer.from(data, 'base64'));
    }
    await page.evaluate(() => window.closeFilmEncoder());
    await handle.close();
    handle = undefined;
    const timestamps = `setts=pts=N/(TB_OUT*${FPS}):dts=N/(TB_OUT*${FPS}):duration=1/(TB_OUT*${FPS})`;
    await run(values.ffmpeg, ['-hide_banner', '-v', 'error', '-xerror', '-r', String(FPS), '-f', 'h264', '-i', elementary,
      '-map', '0:v:0', '-c:v', 'copy', '-bsf:v', timestamps, '-video_track_timescale', '60000', '-n', wrapped], commandOptions);
    const [video] = await probe(wrapped);
    if (Number(video.nb_frames) !== clip.frames || video.avg_frame_rate !== `${FPS}/1`
      || Math.abs(Number(video.duration) - clip.frames / FPS) > 1e-6) throw Error(`Frame check failed for segment ${stem}`);
    const sha256 = digest(await readFile(wrapped));
    await rename(wrapped, file);
    await writeFile(stamp, `${JSON.stringify({key, start: clip.start, frames: clip.frames, sha256}, null, 2)}\n`);
    console.log(`Done ${stem} · ${clip.start}s · ${clip.frames} frames`);
    return file;
  } finally {
    if (handle) await handle.close();
    await Promise.all([elementary, wrapped].map(path => unlink(path).catch(() => {})));
  }
}

async function renderAll() {
  const output = resolve(values.output);
  const base = dirname(output);
  const workers = Number(values.workers);
  const bitrate = Number(values.bitrate);
  if (!output.toLowerCase().endsWith('.mp4') || !Number.isInteger(workers) || workers < 1 || workers > 6 || !(bitrate > 1_000_000)) {
    throw Error('Provide an MP4 destination, 1–6 workers, and a bitrate above 1 Mbps.');
  }
  const audio = values['video-only'] ? null : resolve(values.audio ?? join(base, 'Sol_R7_Original_Score.wav'));
  if (audio && !(await probe(audio)).some(track => track.codec_type === 'audio' && Number(track.duration) === 137)) {
    throw Error('The score must be an exact 137-second audio file.');
  }
  const html = resolve(values.html ?? join(projectRoot, 'pelican.html'));
  const cache = digest(await readFile(html));
  const directory = join(base, 'segments');
  await mkdir(directory, {recursive: true});
  // The same config, Chrome build and HTML must bind any resumable segment.
  const seed = await openFilm({...values, html});
  let ends;
  let key;
  try {
    const metadata = await seed.page.evaluate(() => ({duration: window.SOL_R7.duration, starts: window.SOL_R7.sceneStarts}));
    if (metadata.duration !== 137 || metadata.starts.length !== 20) throw Error('Expected the complete Sol_R7 timeline.');
    ends = [0, ...metadata.starts, 125, metadata.duration];
    const version = await seed.browser.version();
    key = digest(JSON.stringify({v: 2, cache, codec: CODEC, fps: FPS, bitrate, version}));
  } finally {
    await seed.browser.close();
  }
  const clips = ends.slice(0, -1).map((start, index) => ({start, index, frames: Math.round((ends[index + 1] - start) * FPS)}));
  if (values.segment !== undefined) {
    const clip = clips[Number(values.segment)];
    if (!clip) throw Error(`Choose a segment from 0 to ${clips.length - 1}.`);
    const {page, browser} = await openFilm({...values, html});
    try {
      await renderClip(page, clip, directory, key, bitrate);
    } finally {
      await browser.close();
    }
    return;
  }
  const files = new Array(clips.length);
  let cursor = 0;
  const crew = Array.from({length: workers}, async () => {
    const {page, browser} = await openFilm({...values, html});
    try {
      while (cursor < clips.length) {
        const clip = clips[cursor++];
        files[clip.index] = await renderClip(page, clip, directory, key, bitrate);
      }
    } finally {
      await browser.close();
    }
  });
  const results = await Promise.allSettled(crew);
  const failed = results.find(result => result.status === 'rejected');
  if (failed) throw failed.reason;
  const nonce = randomUUID();
  const listing = join(directory, `concat-${nonce}.txt`);
  const candidate = join(base, `render-${nonce}.mp4`);
  try {
    await writeFile(listing, files.map(file => `file ${quoteForConcat(file)}`).join('\n') + '\n', {flag: 'wx'});
    const args = ['-hide_banner', '-v', 'error', '-xerror', '-f', 'concat', '-safe', '0', '-i', listing];
    if (audio) args.push('-i', audio, '-map', '0:v:0', '-map', '1:a:0', '-c:a', 'aac', '-b:a', '320k');
    else args.push('-map', '0:v:0', '-an');
    args.push('-c:v', 'copy', '-metadata', 'title=鹈鹕测试 · Sol_R7', '-movflags', '+faststart', '-n', candidate);
    await run(values.ffmpeg, args, commandOptions);
    const tracks = await probe(candidate);
    if (Number(tracks[0].nb_frames) !== 137 * FPS || Number(tracks[0].duration) !== 137
      || (audio && Number(tracks.find(track => track.codec_type === 'audio')?.duration) !== 137)) {
      throw Error(`Unexpected encoded duration or frame count: ${JSON.stringify(tracks)}`);
    }
    if (values.force) await rename(candidate, output);
    else {
      const {link} = await import('node:fs/promises');
      await link(candidate, output);
    }
    console.log(JSON.stringify({output, htmlSha256: cache, sha256: digest(await readFile(output)), tracks}, null, 2));
  } finally {
    await Promise.all([listing, candidate].map(path => unlink(path).catch(() => {})));
  }
}

if (values.help) console.log('node tools/export-film.mjs --html pelican.html --audio exports/final/Sol_R7_Original_Score.wav [--workers 3] [--force]\nRender only a chapter cache entry with --segment 0–21.');
else await renderAll();
