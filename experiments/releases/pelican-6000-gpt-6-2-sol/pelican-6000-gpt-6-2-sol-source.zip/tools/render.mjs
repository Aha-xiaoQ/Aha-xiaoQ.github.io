import { spawn } from 'node:child_process';
import { randomUUID } from 'node:crypto';
import { once } from 'node:events';
import { link, rename, unlink } from 'node:fs/promises';
import { extname, join } from 'node:path';
import { parseArgs } from 'node:util';
import { browserOptions, framePng, openFilm, prepareOutput, projectRoot } from './browser.mjs';

const { values } = parseArgs({ options: {
  ...browserOptions,
  start: { type: 'string', default: '3.5' },
  duration: { type: 'string', default: '5' },
  fps: { type: 'string', default: '30' },
  output: { type: 'string' },
  ffmpeg: { type: 'string', default: 'ffmpeg' },
  force: { type: 'boolean' },
  help: { type: 'boolean' },
} });

if (values.help) {
  console.log('npm run render -- --start 3.5 --duration 5 --fps 60 [--output exports/shot.mp4] [--force]\nOptional: --html path --chrome path --ffmpeg path');
} else {
  await render(values);
}

async function render(options) {
  const start = Number(options.start);
  const duration = Number(options.duration);
  const fps = Number(options.fps);
  if (!Number.isFinite(start) || start < 0 || !Number.isFinite(duration) || duration <= 0
      || !Number.isInteger(fps) || fps < 1 || fps > 120) {
    throw new Error('Use start ≥ 0, duration > 0, and an integer FPS from 1 to 120.');
  }
  const frameCount = Math.round(duration * fps);
  if (frameCount < 1 || Math.abs(frameCount - duration * fps) > 1e-7) {
    throw new Error('Duration must select a whole number of frames.');
  }

  const output = await prepareOutput(options.output ?? join(projectRoot, 'exports', `Sol_R7_${fps}fps.mp4`));
  if (extname(output).toLowerCase() !== '.mp4') throw new Error('The output must use the .mp4 extension.');
  const temporary = `${output}.${randomUUID()}.partial.mp4`;
  const { browser, page } = await openFilm(options);
  let encoder;
  let encoded;
  let abort = false;
  const cancel = () => {
    abort = true;
    encoder?.kill();
  };
  process.on('SIGINT', cancel);
  process.on('SIGTERM', cancel);

  try {
    const filmDuration = await page.evaluate(() => window.SOL_R7.duration);
    if (start + duration > filmDuration + 1e-7) throw new Error(`Clip ends beyond the ${filmDuration}s film.`);

    encoder = spawn(options.ffmpeg, [
      '-hide_banner', '-loglevel', 'error', '-f', 'image2pipe', '-framerate', String(fps), '-c:v', 'png', '-i', 'pipe:0',
      '-an', '-c:v', 'libx264', '-preset', 'fast', '-crf', '16', '-pix_fmt', 'yuv420p',
      '-vf', 'scale=out_color_matrix=bt709', '-color_primaries', 'bt709', '-color_trc', 'bt709', '-colorspace', 'bt709',
      '-movflags', '+faststart', '-n', temporary,
    ], { windowsHide: true, stdio: ['pipe', 'ignore', 'inherit'] });
    encoder.stdin.on('error', () => {});
    encoded = once(encoder, 'close');
    encoded.catch(() => {});
    for (let index = 0; index < frameCount; index++) {
      if (abort) throw new Error('Render cancelled.');
      const time = start + index / fps;
      const png = await framePng(page, time);
      await new Promise((resolve, reject) => {
        encoder.stdin.write(png, (error) => error ? reject(error) : resolve());
      });
      if ((index + 1) % fps === 0 || index + 1 === frameCount) console.log(`${index + 1}/${frameCount} frames`);
    }
    encoder.stdin.end();
    const [code] = await encoded;
    if (abort || code !== 0) throw new Error(`FFmpeg did not finish (exit ${code}).`);
    if (options.force) await rename(temporary, output);
    else await link(temporary, output);
    console.log(JSON.stringify({ output, start, duration, fps, frames: frameCount }, null, 2));
  } finally {
    process.off('SIGINT', cancel);
    process.off('SIGTERM', cancel);
    if (encoder && encoder.exitCode === null && encoder.signalCode === null) encoder.kill();
    try { await encoded; } catch { /* FFmpeg launch error already propagated. */ }
    await unlink(temporary).catch((error) => { if (error.code !== 'ENOENT') throw error; });
    await browser.close();
  }
}
