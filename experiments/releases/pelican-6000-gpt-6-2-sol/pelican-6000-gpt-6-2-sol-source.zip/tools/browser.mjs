import { access, mkdir } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import puppeteer from 'puppeteer-core';

export const projectRoot = dirname(dirname(fileURLToPath(import.meta.url)));

export async function openFilm({ html = join(projectRoot, 'pelican.html'), chrome } = {}) {
  const file = resolve(html);
  try { await access(file); }
  catch { throw new Error(`Preview is missing at ${file}. Run npm run build.`); }

  const executablePath = chrome || process.env.CHROME_PATH || process.env.CHROMIUM;
  const browser = await puppeteer.launch({
    ...(executablePath ? { executablePath } : { channel: 'chrome' }),
    headless: true,
    args: ['--disable-background-timer-throttling', '--disable-renderer-backgrounding'],
  });
  try {
    const page = await browser.newPage();
    await page.setViewport({ width: 1440, height: 960, deviceScaleFactor: 1 });
    await page.goto(pathToFileURL(file).href);
    const ready = await page.waitForFunction(() => window.SOL_R7 || document.querySelector('#status').textContent.includes('失败'));
    await ready.dispose();
    if (await page.evaluate(() => !window.SOL_R7)) {
      throw new Error(await page.$eval('#status', (status) => status.textContent));
    }
    await page.evaluate(() => document.fonts.ready.then(() => true));
    return { browser, page };
  } catch (error) {
    await browser.close();
    throw error;
  }
}

export async function prepareOutput(file) {
  const output = resolve(file);
  await mkdir(dirname(output), { recursive: true });
  return output;
}

export async function framePng(page, time) {
  const base64 = await page.evaluate((t) => {
    const film = window.SOL_R7;
    if (t === null) film.renderStudy();
    else film.renderAt(t);
    return document.querySelector('#film').toDataURL('image/png').slice('data:image/png;base64,'.length);
  }, time);
  return Buffer.from(base64, 'base64');
}

export const browserOptions = {
  html: { type: 'string' },
  chrome: { type: 'string' },
};
