import { writeFile } from 'node:fs/promises';
import { extname, join } from 'node:path';
import { parseArgs } from 'node:util';
import { browserOptions, openFilm, prepareOutput, projectRoot } from './browser.mjs';

const { values } = parseArgs({ options: {
  ...browserOptions,
  times: { type: 'string' },
  caption: { type: 'string', default: '逐幕接触表' },
  output: { type: 'string', default: join(projectRoot, 'exports', 'Sol_R7_contact.jpg') },
  force: { type: 'boolean' },
  help: { type: 'boolean' },
} });

if (values.help) {
  console.log('npm run contact -- [--times 1.5,5,7,125,132,136.9] [--caption 逐幕接触表] [--output exports/contact.jpg] [--force]\nOptional: --html path --chrome path');
} else {
  const output = await prepareOutput(values.output);
  if (!['.jpg', '.jpeg'].includes(extname(output).toLowerCase())) throw new Error('The contact sheet must use the .jpg extension.');
  const times = values.times?.split(',').map((value) => value.trim() === '' ? NaN : Number(value));
  if (times?.some((time) => !Number.isFinite(time) || time < 0)) throw new Error('Provide comma-separated times in seconds.');
  const { page, browser } = await openFilm(values);
  try {
    const result = await page.evaluate((selectedTimes, captionLine) => {
      const film = window.SOL_R7;
      const frames = selectedTimes ?? [2.5, ...film.sceneStarts.map((start) => start + 3), film.duration - 9];
      if (frames.some((time) => time > film.duration)) throw new Error('Contact sheet time is outside the film.');

      const source = document.querySelector('#film');
      const sheet = document.createElement('canvas');
      const cols = Math.min(4, frames.length);
      const rows = Math.ceil(frames.length / cols);
      const margin = 28;
      const gutter = 18;
      const top = 82;
      const width = 384;
      const height = 216;
      const caption = 32;
      const stride = height + caption + gutter;
      sheet.width = margin * 2 + cols * width + (cols - 1) * gutter;
      sheet.height = top + rows * stride + margin - gutter;
      const ctx = sheet.getContext('2d');
      ctx.fillStyle = '#211d18';
      ctx.fillRect(0, 0, sheet.width, sheet.height);
      ctx.fillStyle = '#f2e7d0';
      ctx.font = '600 28px "Microsoft YaHei", sans-serif';
      ctx.fillText('鹈鹕测试 · Sol R7', margin, 34);
      ctx.fillStyle = '#beae93';
      ctx.font = '14px "Microsoft YaHei", sans-serif';
      ctx.fillText(captionLine, margin, 58);

      for (let index = 0; index < frames.length; index++) {
        const time = frames[index];
        const x = margin + (index % cols) * (width + gutter);
        const y = top + Math.floor(index / cols) * stride;
        film.renderAt(time);
        ctx.drawImage(source, x, y, width, height);
        ctx.strokeStyle = '#655746';
        ctx.strokeRect(x + .5, y + .5, width - 1, height - 1);
        const label = film.labelAt(time);
        const title = typeof label === 'string' ? label : label?.title ?? label?.name ?? '';
        ctx.font = '15px "Microsoft YaHei", sans-serif';
        ctx.fillStyle = '#f2e7d0';
        ctx.fillText(title, x, y + height + 21, width - 75);
        ctx.font = '13px Consolas, monospace';
        ctx.fillStyle = '#c5aa7a';
        const sec = time % 60;
        const code = `${Math.floor(time / 60)}:${sec.toFixed(2).padStart(5, '0')}`;
        ctx.fillText(code, x + width - ctx.measureText(code).width, y + height + 21);
      }
      return { frames, jpg: sheet.toDataURL('image/jpeg', .94).slice('data:image/jpeg;base64,'.length) };
    }, times ?? null, values.caption);
    await writeFile(output, Buffer.from(result.jpg, 'base64'), { flag: values.force ? 'w' : 'wx' });
    console.log(JSON.stringify({ output, frames: result.frames }, null, 2));
  } finally {
    await browser.close();
  }
}
