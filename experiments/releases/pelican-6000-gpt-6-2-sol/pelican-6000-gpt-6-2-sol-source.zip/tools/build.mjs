import { createHash, randomUUID } from 'node:crypto';
import { readFile, rename, unlink, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { parseArgs } from 'node:util';
import { build } from 'esbuild';

const root = dirname(dirname(fileURLToPath(import.meta.url)));
const { values: { output: outputName } } = parseArgs({ options: {
  output: { type: 'string', default: 'pelican.html' },
} });
if (!/^[\w-]+\.html$/.test(outputName)) throw new Error('Provide an HTML filename in the project root.');
const output = join(root, outputName);
const [template, upstream, bundle] = await Promise.all([
  readFile(join(root, 'src', 'player.html'), 'utf8'),
  readFile(join(root, 'vendor', 'p5.min.js'), 'utf8'),
  build({
    absWorkingDir: root,
    entryPoints: ['src/player.js'],
    bundle: true,
    write: false,
    platform: 'browser',
    format: 'iife',
    target: 'es2022',
    legalComments: 'inline',
  }),
]);

// Skip p5 2.4.0's optional error-message translations in the built offline file.
// The unmodified dependency, its readable source and license stay in vendor/.
function offlineP5(source) {
  if (!/p5(?:\.js)?\s+v?2\.4\.0/i.test(source.slice(0, 1000))) throw new Error('Expected vendored p5.js 2.4.0.');
  const start = source.indexOf(',Qa=new Promise(async t=>{');
  const end = source.indexOf(');var $a=class', start) + 1;
  if (start < 0 || end <= start || !source.slice(start, end).includes('cdn.jsdelivr.net/npm/p5@')) {
    throw new Error('The pinned p5 translation initializer changed. Review the offline patch.');
  }
  return `${source.slice(0, start)},Qa=Promise.resolve()${source.slice(end)}`;
}

function insertScript(html, marker, source) {
  if (html.split(marker).length !== 2) throw new Error(`Expected one template marker: ${marker}`);
  return html.replace(marker, () => source.replaceAll(/<\/script/gi, '<\\/script'));
}

const p5 = offlineP5(upstream);
const html = insertScript(insertScript(template, '/*__P5_CODE__*/', p5), '/*__PLAYER_CODE__*/', bundle.outputFiles[0].text);
const temporary = `${output}.${randomUUID()}.part`;
try {
  await writeFile(temporary, html, { encoding: 'utf8', flag: 'wx' });
  await rename(temporary, output);
} finally {
  await unlink(temporary).catch((error) => { if (error.code !== 'ENOENT') throw error; });
}
const sha256 = (value) => createHash('sha256').update(value).digest('hex');
console.log(JSON.stringify({ file: output, bytes: Buffer.byteLength(html), sha256: sha256(html),
  p5UpstreamSha256: sha256(upstream), p5OfflineSha256: sha256(p5) }, null, 2));
