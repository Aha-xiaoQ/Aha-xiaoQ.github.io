"""Offline CFR master: fresh workers, absolute clock, WebCodecs visual stream.
FFmpeg remuxes the sequential Annex B pictures with the separately synthesized
48kHz score. The offline HTML remains the canonical self-contained renderer."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
from playwright.sync_api import sync_playwright
import hashlib,subprocess,base64,time
from browser_path import chromium_path
ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'exports'
HTML=ROOT/'pelican.html'
RATE=60; W=1920; H=1080
SEG=[0,11,22,36,51,63,76,90,104,113,128,145,160,170,186]
JS="""async ([a,b,n,rate])=>{
const p=window.pelicanFilm;await p.ready;const cv=document.getElementById('film'),cx=cv.getContext('2d');
let blocks=[],bad=null,total=0;const enc=new VideoEncoder({output(c){let z=new Uint8Array(c.byteLength);c.copyTo(z);blocks.push(z);total++},error(e){bad=String(e)}});
enc.configure({codec:'avc1.64002a',width:cv.width,height:cv.height,framerate:rate,bitrate:18000000,latencyMode:'realtime',avc:{format:'annexb'}});
for(let j=a;j<b;j++){
 if(bad)throw Error(bad);p.P.renderAt(cx,j/rate);
 const vf=new VideoFrame(cv,{timestamp:Math.round(1000000*j/rate),duration:Math.round(1000000/rate)});
 enc.encode(vf,{keyFrame:j===a||j%(rate*2)===0});vf.close();
 if(enc.encodeQueueSize>6)await new Promise(r=>enc.addEventListener('dequeue',r,{once:true}));
}
await enc.flush();enc.close();if(bad||total!==b-a)throw Error(bad||'Dropped frames: '+total);
let blob=new Blob(blocks);return await new Promise((ok,no)=>{let f=new FileReader;f.onerror=no;f.onload=()=>ok(f.result.split(',')[1]);f.readAsDataURL(blob)});
}"""
def main():
 OUT.mkdir(exist_ok=True);key=hashlib.sha256(HTML.read_bytes()+JS.encode()).hexdigest()[:14]
 dest=OUT/('render-'+key);dest.mkdir(exist_ok=True)
 def worker(i):
  a,b=SEG[i:i+2];f=dest/f'{i:02}.h264';need=(b-a)*RATE
  if f.exists() and f.with_suffix('.ok').exists():return f.name+' cached'
  with sync_playwright() as pw:
   br=pw.chromium.launch(executable_path=chromium_path(),headless=True,args=['--enable-unsafe-swiftshader','--disable-renderer-backgrounding','--disable-background-timer-throttling'])
   pg=br.new_page();pg.goto(HTML.as_uri()+f'?render=1&w={W}&h={H}');pg.evaluate('pelicanFilm.ready');now=time.monotonic()
   raw=pg.evaluate(JS,[a*RATE,b*RATE,i,RATE]);f.write_bytes(base64.b64decode(raw));br.close()
  f.with_suffix('.ok').write_text(str(need));return f'{i:02}: {a}-{b}s in {time.monotonic()-now:.1f}s'
 with ThreadPoolExecutor(max_workers=3) as pool:
  for f in as_completed([pool.submit(worker,i) for i in range(len(SEG)-1)]):print(f.result(),flush=True)
 video=dest/'roll.h264'
 import shutil
 with video.open('wb') as o:
  for i in range(len(SEG)-1):
   with (dest/f'{i:02}.h264').open('rb') as h:shutil.copyfileobj(h,o)
 names='开篇 撒哈拉岩画 埃及壁画 汉画像石 唐代白描 宋代山水 汴河虹桥 玛雅抄本 莫卧儿细密画 八大山人 爪哇皮影 浮世绘 星月夜 呐喊 默片 示波器 像素游戏 群聊 蒸汽波 竖屏直播 代码美学 发布会'.split()
 bounds=[0,6,11,17,22,29,36,46,51,58,63,70,76,84,90,96,104,113,145,151,160,170,186]
 meta=dest/'chapters.txt';meta.write_text(';FFMETADATA1\n'+''.join(f'[CHAPTER]\nTIMEBASE=1/1000\nSTART={a*1000}\nEND={b*1000}\ntitle={n}\n' for n,a,b in zip(names,bounds,bounds[1:])),encoding='utf8')
 final=OUT/'Pelican_6000_R7_1080p60.mp4'
 subprocess.run(['ffmpeg','-v','error','-y','-r',str(RATE),'-i',str(video),'-i',str(OUT/'Pelican_PureCode_R7_Original_Score.wav'),'-f','ffmetadata','-i',str(meta),'-map','0:v','-map','1:a','-map_chapters','2','-c:v','copy','-c:a','aac','-b:a','256k','-movflags','+faststart','-t','186',str(final)],check=True)
 print(final,flush=True)
if __name__=='__main__': main()
