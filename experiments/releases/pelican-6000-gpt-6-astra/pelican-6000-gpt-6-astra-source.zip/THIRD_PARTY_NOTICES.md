# 第三方组件与创作参考

## 随包组件

`vendor/p5.min.js`、`vendor/lib/p5.js`、`vendor/license.txt` 保留了基线所用 p5.js 2.4.0 的上游文件与 LGPL-2.1 许可文本。内嵌到 HTML 时，仅去掉可选错误文案翻译的网络初始化；完整补丁与理由记录于 `docs/OFFLINE_VENDOR_PATCH.md`，构建脚本公开保留。

本次播放器使用 p5 建立绘图表面，画面由 Canvas 2D 绘制，声音由浏览器原生 Web Audio 合成。导出使用 Python Playwright、Chromium 与 FFmpeg；这些工具的二进制及环境依赖不随源码包分发。未使用或捆绑系统字体。

本包不依赖旧说明中出现过的 Node 原生 Canvas、node-web-audio-api、Puppeteer 或 p5.brush。它们不应被列为本批交付实际必需组件。

## 用户指定的参考

- Bilibili：BV1pLnw6YEzq。
- Bilibili：BV1SsWy6TEKx；对应网页版 https://pelican.orbitoo.top/ 。

艺术史骑行命题、开头的荒诞表述和部分长卷结构延续用户指定参考。我们继续在已确认的纯代码工程上重绘与改编；不把原命题和全部场景母题声称为全新原创。没有把参考视频帧、原片配乐、生成插画或人物 GIF 作为本版运行资产。

群聊、直播为虚构界面和剧情；角色昵称与台词不表示相关品牌的官方声明或合作。预览图和 MP4 是本工程的输出，不是运行素材输入。

