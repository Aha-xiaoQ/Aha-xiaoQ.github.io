/* Pelican Test — original score, R6 / 186 s / 120 BPM reference.
 * Composition, instrument models and cues authored for this film.
 * No recordings, sound fonts, external audio URLs or sampled instruments.
 * The browser and offline export use this same event graph.
 */
(function(root){
  'use strict';
  const TAU=Math.PI*2, DURATION=186, BPM=120, SAMPLE_RATE=48000, MASTER_GAIN=2.08;
  const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x));
  const hz=n=>440*Math.pow(2,(n-69)/12);
  const events=[], waveCache=new Map(), contextBuffers=new WeakMap();
  let tape=null, preparing=null;
  const chapterNames=['撒哈拉·手鼓与吟唱','埃及·竖琴','汉·编钟','唐·琵琶','宋·古琴','汴京·笛与锣鼓','玛雅·陶笛木鼓','莫卧儿·西塔琴塔布拉','八大·箫','爪哇·甘美兰','浮世绘·三味线','星月夜·弦乐','呐喊·失谐弦乐','默片·钢琴管风琴','示波器·正弦与电子管','像素·四声道芯片','叮咚·MIDI 铃音','蒸汽波·商场磁带','顺路·流行节拍','代码·钢琴合成器'];
  // Three bars. The rests and descending answer keep the recurring tune light.
  const theme=[[0,74,.43],[.5,77,.20],[.75,81,.43],[1.25,79,.20],[1.5,77,.20],[1.75,76,.20],[2,74,.43],[2.5,72,.20],[2.75,74,.20],[3,77,.43],[3.5,69,.42],[4,67,.43],[4.5,69,.20],[4.75,73,.20],[5,76,.43],[5.5,74,.43]];
  const chords=[[50,57,60,65],[43,55,58,62],[45,57,61,64]];
  const cues=[
    {time:2,name:'intro_second_line'},
    {time:79.35,name:'scream_reaction'},
    {time:89,name:'shadow_electrifies'},
    {time:90.91,name:'scope_reference'},
    {time:91.15,name:'scope_lissajous'},
    {time:92.6,name:'scope_locked'},
    {time:97.1,name:'pixel_spring'},
    {time:97.6,name:'pixel_collect_1'},
    {time:98.1,name:'pixel_collect_2'},
    {time:98.6,name:'pixel_collect_3_1up'},
    {time:99.5,name:'pixel_landing'},
    {time:99.65,name:'pixel_checkpoint'},
    {time:103.25,name:'chat_message'},
    {time:103.48,name:'chat_window_nudge'},
    {time:104.02,name:'chat_reply'},
    {time:104.18,name:'chat_saved'},
    {time:109,name:'tape_half_beat_loop'},
    {time:112.5,name:'tape_speed_up'},
    {time:115.95,name:'live_gift'},
    {time:116.18,name:'gift_attaches'},
    {time:122.1,name:'code_breakpoint'},
    {time:122.42,name:'code_step'},
    {time:122.5,name:'code_bell'},
    {time:122.65,name:'code_resume'},
    {time:130.55,name:'press_flash_1'},
    {time:131.35,name:'press_flash_2'},
    {time:131.62,name:'press_flash_3'},
    {time:136.1,name:'last_bicycle_bell'}
  ];
  function event(time,kind,n,dur,amp=.1,pan=0,extra={}){
    events.push({time,kind,n,dur,amp,pan,...extra});
  }
  function melodic(kind,start,amp=.16,octave=0,options={}){
    for(let i=0;i<theme.length;i++){
      const [t,n,d]=theme[i];
      if(options.sparse && ![0,2,6,9,11,14,15].includes(i))continue;
      event(start+t,kind,n+octave,options.sparse?Math.max(.65,d*1.5):d+(options.tail||.24),amp*(i%3===0?1:.87),options.pan||-.12,options.channel?{channel:options.channel}:{});
    }
  }
  function chord(kind,time,notes,dur,amp=.045,spread=.55){
    notes.forEach((n,i)=>event(time+i*.018,kind,n,dur,amp,spread*(i/(notes.length-1)-.5)*2));
  }
  function drums(start,style,amp=.1){
    for(let b=0;b<12;b++){
      const at=start+b*.5;
      if(style==='hand'){
        event(at,b%4===0?'djembe':'rim',b%4===0?43:63,b%4===0?.33:.13,amp*(b%4===0?1:.55),b%2?-.28:.18);
        if(b%2===1)event(at+.25,'shaker',0,.07,amp*.18,.48);
      }else if(style==='wood'){
        event(at,b%4===0?'woodLow':'wood',b%4===0?49:66,.22,amp*(b%4===0?1:.58),b%2?-.35:.25);
        if(b%3===2)event(at+.25,'wood',72,.15,amp*.35,.38);
      }else if(style==='tabla'){
        event(at,b%3===0?'tablaLow':'tabla',b%3===0?41:62,.28,amp,-.32);
        if(b%2===1)event(at+.25,'tabla',67,.19,amp*.57,.3);
      }else if(style==='pop'){
        if(b%4===0||b%4===2)event(at,'kick',0,.34,amp*1.2,0);
        if(b%4===1||b%4===3)event(at,'clap',0,.19,amp*.65,.12);
        event(at+.25,'hat',0,.075,amp*.19,.5);
      }else if(style==='brush'){
        if(b%4===0)event(at,'kick',0,.3,amp*.65,0);
        if(b%2===1)event(at,'brush',0,.16,amp*.34,-.18);
        event(at+.25,'shaker',0,.07,amp*.14,.4);
      }
    }
  }
  function bass(start,kind='bass',amp=.1){
    [38,43,45].forEach((n,b)=>{
      event(start+b*2,kind,n,1.05,amp,-.04);
      event(start+b*2+1.25,kind,n+7,.52,amp*.64,.04);
    });
  }
  // Documentary introduction. The second line has a dry pizzicato answer.
  chord('strings',0,[38,50,57,62,65],4.9,.042,.6);
  event(0,'lowGong',38,4.3,.075,0);
  event(2,'pizz',62,.75,.16,-.08);event(2,'wood',74,.18,.075,.18);
  [62,65,69,72].forEach((n,i)=>event(3.75+i*.25,'harp',n,.6,.085,(i-1.5)*.12));
  for(let sc=0;sc<20;sc++){
    const st=5+sc*6;
    // A soft shared frame accent: four harmonically related metal partials.
    if(sc!==17&&sc!==15)event(st,'frame',62,.65,sc===14?.06:.055,.03);
    switch(sc){
      case 0:
        melodic('chant',st,.18,-24,{sparse:true,tail:.1});
        chord('chant',st,[38,45],5.8,.037,.6);drums(st,'hand',.15);
        event(st+2.35,'woodLow',48,.28,.065,-.55);break;
      case 1:
        melodic('harp',st,.18,-12,{tail:.7});
        chords.forEach((ns,b)=>ns.forEach((n,k)=>event(st+b*2+k*.25,'harp',n+12,1.7,.063,.3)));
        event(st+2,'wood',74,.13,.057,0);break;
      case 2:
        melodic('bronze',st,.14,-12,{tail:.9});
        event(st,'lowGong',38,4,.07,-.2);
        [0,1.5,2.5,4,5.5].forEach((b,i)=>event(st+b,'woodLow',50+i%2*7,.24,.075,.26));break;
      case 3:
        melodic('pipa',st,.18,-12,{tail:.27});
        chords.forEach((ns,b)=>ns.slice(1).forEach((n,k)=>event(st+b*2+.45+k*.07,'pipa',n,1.1,.047,.28)));
        [2.5,2.625,2.75,2.875].forEach(t=>event(st+t,'pipa',74,.35,.067,.32));
        drums(st,'wood',.038);break;
      case 4:
        melodic('guqin',st,.19,-24,{sparse:true,tail:.8});
        event(st,'guqin',38,4.8,.095,-.32);
        event(st+2.6,'air',0,2.3,.018,.55);break;
      case 5:
        melodic('flute',st,.15,-12,{tail:.14});drums(st,'hand',.052);
        event(st,'gong',50,2.3,.075,-.3);event(st+3,'gong',57,1.6,.039,.35);
        [1,3,5].forEach(t=>event(st+t,'wood',76,.14,.049,.2));break;
      case 6:
        melodic('ocarina',st,.15,-12,{tail:.1});drums(st,'wood',.09);
        event(st,'ocarina',50,1.6,.042,.38);break;
      case 7:
        melodic('sitar',st,.17,-12,{tail:.55});drums(st,'tabla',.092);
        chord('tanpura',st,[38,45,50],5.8,.034,.65);break;
      case 8:
        melodic('xiao',st,.15,-24,{sparse:true,tail:.25});
        event(st+2.45,'guqin',50,1.8,.063,.3);break;
      case 9:
        melodic('gamelan',st,.14,-12,{tail:.7});drums(st,'wood',.047);
        [0,2,4].forEach((t,i)=>event(st+t,'gong',[38,43,45][i],2.1,.075,-.1));break;
      case 10:
        melodic('shamisen',st,.15,-12,{tail:.25});drums(st,'wood',.045);
        event(st+.7,'rain',0,4.8,.054,.15);break;
      case 11:
        melodic('strings',st,.14,-12,{tail:.2});
        chords.forEach((ns,b)=>chord('strings',st+b*2,ns,2.2,.043,.7));bass(st,'pizz',.12);
        theme.filter((_,i)=>i%2===0).forEach(([t,n])=>event(st+t+.25,'harp',n-12,.65,.038,.5));break;
      case 12:
        melodic('strings',st,.12,-12,{tail:.18});
        chords.forEach((ns,b)=>chord('strings',st+b*2,ns,2.1,.042,.75));bass(st,'pizz',.1);
        event(st+2.35,'scream',78,.64,.11,.12);event(st+2.35,'bell',0,.65,.09,-.06);break;
      case 13:
        melodic('piano',st,.17,-12,{tail:.35});bass(st,'piano',.13);
        chord('organ',st,[38,45,53,62],2,.037,.7);
        chord('organ',st+2,[43,50,58,64],2,.037,.7);
        chord('organ',st+4,[45,52,61,67],2,.037,.7);break;
      case 14:
        melodic('sine',st,.135,-12,{tail:.07});
        event(st,'tube',0,5.9,.021,0);
        event(st,'power',0,.65,.07,0);
        event(st+1.91,'switch',0,.08,.07,-.3);
        event(st+2.15,'scopeWarp',0,1.45,.14,0);
        event(st+3.6,'sine',81,.3,.08,.18);
        event(st+3.7,'bell',0,.72,.085,.1);break;
      case 15:
        // Exactly four monophonic lanes: pulse A, pulse B, triangle and noise.
        melodic('chipLead',st,.08,-12,{tail:0,channel:'chipA'});
        for(let q=0;q<24;q++){
          const t=q*.25,b=Math.min(2,Math.floor(t/2)),n=chords[b][1+q%3];
          if(t<2.05||t>4.95)event(st+t,'chipArp',n,.19,.039,.26,{channel:'chipB'});
        }
        for(let b=0;b<12;b++)event(st+b*.5,'chipBass',[38,43,45][Math.floor(b/4)],.39,.105,0,{channel:'chipC'});
        for(let b=0;b<24;b++)event(st+b*.25,'chipNoise',0,b%4===2?.12:.05,b%4===2?.046:.017,-.22,{channel:'chipD'});
        event(st+2.1,'chipJump',0,.28,.068,.2,{channel:'chipB'});
        [2.6,3.1,3.6].forEach((t,i)=>{event(st+t,'chipArp',86+i*2,.12,.085,.2,{channel:'chipB'});event(st+t+.12,'chipArp',93+i*2,.16,.063,.2,{channel:'chipB'});});
        [0,4,7,12].forEach((n,i)=>event(st+4.65+i*.07,'chipArp',74+n,.11,.064,.2,{channel:'chipB'}));
        event(st+4.5,'chipNoise',0,.14,.07,-.1,{channel:'chipD'});break;
      case 16:
        melodic('midi',st,.12,-12,{tail:.3});bass(st,'fmBass',.09);
        chords.forEach((ns,b)=>chord('electric',st+b*2,ns,1.4,.037,.55));drums(st,'brush',.055);
        [2.25,3.02].forEach(t=>{event(st+t,'message',81,.2,.11,.18);event(st+t+.105,'message',86,.3,.095,.18);});
        event(st+2.48,'nudge',0,.2,.075,0);event(st+3.18,'message',93,.32,.054,.35);break;
      case 17: break; // Separate, truly slowed OfflineAudioContext FM source.
      case 18:
        melodic('electric',st,.16,-12,{tail:.2});bass(st,'fmBass',.13);drums(st,'pop',.13);
        chords.forEach((ns,b)=>chord('pad',st+b*2,ns,2,.033,.85));
        [0,1,2].forEach(i=>event(st+2.95+i*.055,'message',[81,86,93][i],.23,.07,.32));
        event(st+3.18,'bell',0,.65,.09,.08);break;
      case 19:
        melodic('piano',st,.17,-12,{tail:.65});bass(st,'sine',.065);
        chords.forEach((ns,b)=>chord('pad',st+b*2,ns,2.1,.034,.75));
        for(let k=0;k<9;k++)event(st+2.35+k*.085,'key',0,.045,.023,k%2?.2:-.2);
        event(st+3.1,'key',0,.06,.05,-.1);event(st+3.42,'key',0,.06,.055,.1);
        event(st+3.5,'bell',0,.73,.11,.12);event(st+3.65,'key',0,.05,.04,-.1);break;
    }
  }
  // Small historical actions use the material of the picture as percussion.
  for(const [time,name]of [[13.5,'egypt_stamp'],[19.5,'han_stamp'],[37,'bridge_bell'],[44.116515703,'maya_fifth_dot'],[56.1,'ink_drop'],[56.18,'ink_fish_jump'],[56.88,'ink_fish_splash'],[61,'wayang_rod_lift'],[61.72,'wayang_gate_open'],[64.25,'wayang_rod_close']])cues.push({time,name});
  event(13.5,'woodLow',49,.22,.071,-.2);
  event(19.5,'wood',59,.16,.064,.15);
  event(37,'bell',0,.74,.09,.12);
  event(44.116515703,'wood',69,.15,.058,.24);
  event(56.1,'droplet',91,.21,.12,.28);
  event(56.18,'air',0,.39,.024,.15);
  event(56.88,'splash',0,.24,.067,.28);
  event(61,'woodLow',49,.19,.046,-.3);
  event(61.72,'wood',69,.14,.044,.32);
  event(64.25,'woodLow',55,.22,.06,-.23);
  // Outro: return of the melody in a small ensemble, then leave the empty chair quiet.
  for(const [kind,amp,oct,pan]of [['strings',.10,-12,-.28],['harp',.10,-12,.28],['flute',.058,-12,.12],['gamelan',.045,-12,-.38],['piano',.10,-12,0]])melodic(kind,125,amp,oct,{pan,tail:.45});
  // Earlier colors rejoin quietly, sharing the theme rather than competing solos.
  ['chant','bronze','pipa','guqin','ocarina','sitar','xiao','shamisen','organ','sine','chipLead','midi','fmSax','electric','pad'].forEach((kind,i)=>{
    const [t,n,d]=theme[i];event(125+t,kind,n-12,d+.32,kind==='chipLead'?.022:.038,(i%5-2)*.22);
  });
  bass(125,'pizz',.115);drums(125,'hand',.05);
  chord('strings',129,[38,50,57,62,65],3.7,.04,.8);
  chord('piano',130.5,[38,50,57,62],2.5,.045,.7);
  [130.55,131.35,131.62].forEach((t,i)=>event(t,'shutter',0,.17,.1,[-.6,.55,-.15][i]));
  event(136.1,'bell',0,.9,.19,.12);

  // R3: each room has its own phrase, register, articulation and accompanimental gesture.
  // These are newly composed miniature cues, not quotations or recordings.
  const R3phrases = [
   [[0,50,1.1],[1.5,53,.55],[2.25,55,.7],[3.5,50,.9],[5,48,.8]],
   [[0,62,.8],[.5,69,.6],[1,74,.8],[2,77,.8],[2.75,74,.6],[3.5,69,.7],[4.25,65,.9],[5,62,1.1]],
   [[0,50,1.4],[1.5,57,1.2],[3,62,1.4],[4.5,57,1.3],[5.5,50,1.3]],
   [[0,62,.55],[.5,65,.3],[.75,69,.45],[1.25,74,.6],[2,72,.3],[2.25,69,.4],[2.75,65,.6],[3.5,62,.6],[4.25,65,.3],[4.5,69,.3],[4.75,65,.3],[5.25,62,1]],
   [[0,50,1.8],[1.9,57,1.4],[3.4,62,1.8],[5.1,50,1.6]],
   [[0,74,.35],[.5,77,.22],[.75,79,.35],[1.25,81,.55],[2,79,.35],[2.5,77,.2],[2.75,74,.5],[3.5,72,.25],[4,74,.7],[5,69,.7]],
   [[0,62,.6],[.75,65,.35],[1.5,69,.8],[2.75,67,.3],[3.25,65,.65],[4.5,62,.6],[5.25,60,.5]],
   [[0,50,.9],[.75,57,.65],[1.5,62,.55],[2.25,63,.35],[2.75,62,.8],[3.75,57,.7],[4.75,53,.4],[5.25,50,1]],
   [[.15,57,1.7],[2.5,53,1.3],[4.6,50,1.2]],
   [[0,62,.55],[.5,69,.7],[1,65,.5],[1.5,72,.7],[2,69,.5],[2.5,74,.7],[3,65,.5],[3.5,72,.7],[4,62,.5],[4.5,69,.7],[5,57,.5],[5.5,62,.8]],
   [[0,62,.6],[.75,63,.3],[1.5,69,.6],[2.25,70,.3],[3,69,.65],[4.25,63,.4],[5,62,1]],
   [[0,62,1.1],[1,65,.6],[1.667,69,.95],[2.667,74,1.1],[3.667,72,.6],[4.333,69,.65],[5,65,.9]],
   [[0,62,.7],[.75,65,.7],[1.5,69,.7],[2.3,70,.2],[2.55,71,.2],[2.8,72,.2],[3.1,73,.3],[3.75,69,.65],[4.5,65,.5],[5.25,62,.6]],
   [[0,74,.26],[.333,77,.2],[.5,81,.28],[1,79,.27],[1.333,77,.2],[1.5,74,.4],[2.25,72,.25],[2.5,74,.3],[3,77,.3],[3.333,74,.2],[3.5,69,.38],[4.25,72,.25],[4.5,73,.25],[5,74,.7]],
   [[0,62,.65],[.75,69,.4],[1.5,74,.4]],
   [[0,72,.19],[.25,76,.19],[.5,79,.28],[1,77,.19],[1.25,76,.19],[1.75,72,.32],[2.25,74,.19],[2.5,77,.19],[3,81,.32],[3.5,79,.19],[3.75,77,.19],[4.25,74,.3],[4.75,76,.19],[5,79,.19],[5.5,84,.3]],
   [[0,74,.5],[.75,77,.38],[1.5,81,.5],[3.65,79,.4],[4.5,77,.4],[5.25,74,.55]],
   [],
   [[0,74,.35],[.75,77,.32],[1.25,81,.45],[2,79,.45],[3.5,77,.4],[4.25,74,.32],[4.75,72,.28],[5.25,74,.65]],
   [[0,62,.5],[.375,69,.5],[.75,74,.5],[1.125,77,.5],[1.5,74,.5],[1.875,69,.5],[2.25,65,.65],[3.75,62,.4],[4.125,69,.4],[4.5,74,.4],[4.875,77,.4],[5.25,81,.6]]
  ];
  const R3lead=['chant','harp','bronze','pipa','guqin','flute','ocarina','sitar','xiao','gamelan','shamisen','strings','strings','piano','sine','chipLead','midi','fmSax','electric','piano'];
  const R3gain=[.17,.16,.14,.165,.20,.13,.14,.17,.13,.14,.16,.12,.115,.15,.105,.071,.10,0,.145,.145];
  for(let sc=0;sc<20;sc++){
    if(sc===17)continue;
    const st=5+sc*6,kind=R3lead[sc];
    for(let j=events.length-1;j>=0;j--){const e=events[j];if(e.time>=st&&e.time<st+6&&(e.kind===kind||sc===11&&['harp','pizz'].includes(e.kind)||sc===13&&e.kind==='organ')&&!(sc===14&&e.time>=st+3.6))events.splice(j,1);}
    R3phrases[sc].forEach(([u,n,d],j)=>event(st+u,kind,n,d,R3gain[sc]*(.87+.13*Math.cos(j*1.7)),sc===9?(j%2?.34:-.34):-.12,sc===15?{channel:'chipA'}:{space:[4,8,14,16].includes(sc)?'close':sc===11?'wide':'normal'}));
    if(sc===1)for(let j=0;j<12;j++)event(st+j*.5,'harp',[50,57,62,65][j%4],1.4,.048,.35);
    if(sc===3){[.91,1.03,3.1,3.22].forEach((u,j)=>event(st+u,'pipa',j<2?72:64,.22,.059,.2));for(let j=0;j<8;j++)event(st+4.68+j*.073,'pipa',69,.2,.032+(j%2)*.012,.25);}
    if(sc===4){event(st+2.7,'guqin',69,1.4,.057,.31);event(st+.25,'air',0,5.3,.008,.5);}
    if(sc===7){event(st+2.13,'sitar',61,.23,.055,-.15);event(st+4.62,'sitar',55,.25,.05,-.15);}
    if(sc===9)for(let j=0;j<8;j++)event(st+.25+j*.75,'gamelan',[74,77,81,77][j%4],.45,.052,j%2?-.5:.5);
    if(sc===11){
      [[50,57,65,69],[48,55,62,67],[45,52,60,64]].forEach((ns,b)=>{chord('strings',st+b*2,ns,2.35,.036,.72);for(let k=0;k<6;k++)event(st+b*2+k/3,'harp',ns[k%4]+12,.8,.044,k%2?.4:.2);});
      event(st,'pizz',38,1,.09,-.15);event(st+2,'pizz',36,1,.08,-.15);event(st+4,'pizz',33,1,.09,-.15);
    }
    if(sc===12)for(let j=0;j<12;j++)event(st+2.25+j*.105,'strings',j%2?70:69,.13,.035,j%2?.4:-.4);
    if(sc===13)for(let j=0;j<6;j++){event(st+j,'piano',[38,43,45][j%3],.42,.12,-.3);chord('piano',st+j+.5,[[57,62,65],[55,58,62],[57,61,64]][j%3],.3,.045,.2);}
    if(sc===14){event(st+.1,'sine',50,1.1,.05,.3,{space:'close'});event(st+.85,'sine',57,.7,.04,.3,{space:'close'});}
    if(sc===19)for(let j=0;j<16;j++){let u=j*.1875;if(u>2.6)continue;event(st+u,'electric',[62,69,74,77][j%4],.34,.029,.4);}
  }
  const melodicKinds=new Set(['piano','harp','pipa','guqin','sitar','shamisen','flute','xiao','ocarina','strings','midi','electric','bronze','gamelan']);
  for(let j=0;j<events.length;j++){
    const e=events[j],sc=Math.floor((e.time-5)/6);
    if(melodicKinds.has(e.kind)&&e.time>=5&&e.time<125){
      e.amp*=.97+.045*Math.sin(j*7.13); // deterministic, restrained performance dynamics
      if(!e.channel&&![14,15,19].includes(sc))e.time+=.005*Math.sin(j*11.7);
      if(sc===16&&[103.25,104.02,104.18].some(t=>e.time<t+.45&&e.time+e.dur>t-.08))e.amp*=.66;
      if(sc===19&&e.time<122.65&&e.time+e.dur>122.1)e.dur=Math.max(.045,122.09-e.time);
      if(sc===19&&e.time>=122.1&&e.time<122.65)e.amp=0;
    }
    if(sc===14||sc===16)e.space='close';
  }
  cues.push({time:25.75,name:'R3_tang_fan_unfurl'},{time:49.25,name:'R3_court_welcome'});
  event(25.75,'shaker',0,.18,.018,-.3);
  event(49.25,'droplet',86,.32,.042,.36);


  // R5: re-orchestrate on the editorial clock. Note onsets and event cues are
  // placed in output seconds; no PCM recording is sped up or slowed globally.
  const sceneLengths=[5,6,5,7,7,10,5,7,5,7,6,8,6,6,8,9,32,6,9,10];
  const sceneStarts=[];let chapterStart=6;for(const d of sceneLengths){sceneStarts.push(chapterStart);chapterStart+=d;}
  const outputTime=t=>t<5?t*6/5:t>=125?170+(t-125)*16/12:(()=>{const i=Math.min(19,Math.floor((t-5)/6));return sceneStarts[i]+(t-5-i*6)*sceneLengths[i]/6;})();
  const oldEvents=events.splice(0),oldCues=cues.splice(0);
  const gainByScene=[.94,.95,.94,.92,1.08,.88,.94,.94,.72,.90,.98,1.03,.72,.92,.83,.90,0,1,.91,.94];
  const silenceKinds=new Set(['bell','message','nudge','key','shutter']);
  for(const old of oldEvents){
    const i=old.time<5?-1:old.time>=125?20:Math.floor((old.time-5)/6);
    if(i===16||i===20)continue;
    // One genuine point of quiet. Avoid the old 'fish jump' splashes in the
    // ink scene, whose joke is now the decision not to press the bell.
    if(i===8&&['droplet','splash','air','bell'].includes(old.kind))continue;
    if(i===5&&old.kind==='bell')continue;
    const ratio=i<0?1.2:sceneLengths[i]/6,tm=outputTime(old.time),remaining=i<0?6-tm:sceneStarts[i]+sceneLengths[i]-tm;
    let dur=Math.min(old.dur*Math.min(1.24,Math.max(.9,ratio)),remaining+Math.min(.45,old.dur*.3));
    let amp=old.amp*(i<0?.95:gainByScene[i]);
    if(i===8&&old.time>55&&old.time<57)amp*=.35;
    // Speak with a prop first, then let the melody answer.
    if(i===5&&old.time>37.1&&old.time<38.8)amp*=.58;
    if(i===14&&old.time>91&&old.time<92.6&&!['scopeWarp','switch'].includes(old.kind))amp*=.60;
    event(tm,old.kind,old.n,Math.max(.02,dur),amp,old.pan,{...old,time:tm,dur:Math.max(.02,dur),amp});
  }
  for(const cue of oldCues){if(cue.time>=101&&cue.time<107||cue.time>=125||cue.time===37||cue.time>56&&cue.time<57)continue;cues.push({...cue,time:outputTime(cue.time)});}
  function cue(scene,u,id,kind='bell',n=0,amp=.09,dur=.45){const time=sceneStarts[scene]+u/6*sceneLengths[scene];cues.push({time,name:id});event(time,kind,n,dur,amp,.12,{space:'close'});}
  cue(0,2.5,'herd_make_way','rim',63,.045,.12);
  cue(1,3.55,'scribe_leaves_exit','wood',62,.055,.16);
  cue(2,3.5,'anonymous_stamp','woodLow',47,.04,.15);
  cue(3,2.75,'ribbon_gives_way','shaker',0,.015,.18);
  cue(5,2.45,'basket_touches_front_tyre','woodLow',49,.10,.22);
  cue(5,3.52,'bridge_thanks_bell_1','bell',0,.13,.60);
  cue(5,3.72,'bridge_thanks_bell_2','bell',0,.11,.55);
  cue(7,3.3,'garden_fountain_answer','droplet',86,.034,.30);
  cue(10,3.15,'traveller_catches_hat','shaker',0,.018,.16);
  cue(11,3.86,'star_reaches_clock','bronze',74,.06,.62);
  cue(14,3.6,'scope_calibrated','switch',0,.07,.09);
  cue(15,3.05,'bill_hits_question_block','chipArp',84,.075,.12);
  cue(15,3.48,'coin_on_bell','chipArp',93,.065,.18);
  cue(18,3.32,'rice_delivery_arrived','message',81,.07,.20);
  cue(19,3.65,'road_choice_committed','key',0,.04,.045);
  // The long messenger scene is an intimate, gently syncopated chamber cue.
  // 4-bar phrases breathe between messages instead of looping a loud jingle.
  const chat=sceneStarts[16],progression=[[50,57,62,65],[48,55,60,64],[46,53,58,62],[45,52,57,61]];
  for(let bar=0;bar<16;bar++){
    const tm=chat+bar*2,ns=progression[Math.floor(bar/2)%4];
    chord('electric',tm,ns,1.70,.025,.42);
    event(tm,'fmBass',ns[0]-12,.9,.064,0,{space:'close'});
    event(tm+1.25,'fmBass',ns[0]-5,.42,.035,0,{space:'close'});
    if(bar%2===0)event(tm+.50,'brush',0,.12,.016,-.22);
    if(bar%2)event(tm+1.5,'shaker',0,.06,.012,.36);
    if(bar%4!==3)for(let j=0;j<3;j++){const n=ns[[2,3,1][j]]+(bar%8<4?12:0);event(tm+.25+j*.5,'midi',n,.44,.033*(j===0?1:.8),.2,{space:'close'});}
  }
  // Two contrasting answers: the same four-note identity, first incomplete,
  // then harmonically resolved when the actual file opens.
  [[.2,74],[.95,77],[1.7,81],[2.4,79]].forEach(([u,n])=>event(chat+u,'midi',n,.6,.065,-.15));
  [[17.0,74],[17.75,77],[18.5,81],[19.25,86]].forEach(([u,n])=>event(chat+u,'piano',n,.85,.065,-.15));
  const messageTimes=[.5,3.5,7.8,12,15.8,19,22];
  messageTimes.forEach((u,j)=>{const tm=chat+3+u;cues.push({time:tm,name:'chat_'+['fish_rice','gpt_qualification','doubao_long_intro','claude_opens_file','doubao_answer','fish_two_bowls','gpt_verified'][j]});event(tm,'message',[79,74,81,86,81,79,74][j],.19,.09,.20,{space:'close'});});
  event(chat+3+12.6,'key',0,.04,.04,.18,{space:'close'});
  chord('electric',chat+3+13.8,[50,57,62,69],.9,.043,.6);
  event(chat+3+17.6,'bell',0,.58,.12,.14,{space:'close'});event(chat+3+17.81,'bell',0,.52,.10,.14,{space:'close'});
  for(const e of events){if(e.time>=chat&&e.time<chat+32&&['midi','electric','piano'].includes(e.kind)&&messageTimes.some(u=>e.time<chat+3+u+.65&&e.time+e.dur>chat+3+u-.1))e.amp*=.63;}
  // The curtain call deliberately gets out of the way of the last exchange.
  const end=170;
  [[0,62,1.1],[1,65,.65],[1.75,69,1.05],[3,74,1.5],[5,72,.7],[6,69,1.2],[7.5,65,1.2],[8.8,62,1.5]].forEach(([u,n,d],j)=>{
    event(end+u,'piano',n,d,.10,-.13);
    if(j<6)event(end+u+.04,'strings',n-12,d+.35,.05,.22);
  });
  [[0,[38,50,57,62]],[3,[36,48,55,60]],[6,[33,45,52,57]]].forEach(([u,ns])=>chord('strings',end+u,ns,3,.026,.7));
  event(end+6.95,'shutter',0,.14,.07,-.4);event(end+7.65,'shutter',0,.14,.06,.4);
  [10.65,10.92].forEach((u,j)=>{event(end+u,'bell',0,.8,.17-j*.025,.1,{space:'close'});cues.push({time:end+u,name:'press_borrow_bell_'+j});});
  event(end+11.15,'brush',0,.4,.018,.5);
  // A quiet, complete cadence lets the bird leave instead of a loud end-card.
  chord('piano',end+12.2,[38,50,57,62,65],2.9,.035,.55);
  event(end+13.0,'harp',69,1.7,.052,.26);event(end+13.65,'piano',62,1.7,.065,-.2);
  for(const e of events){if(e.time+e.dur>DURATION)e.dur=Math.max(.012,DURATION-e.time);}

  // R6: tactile, softer voices and an actual musical response to the new
  // picture events. Original compositions; no instrument recordings/samples.
  const previous=events.splice(0),removedTimes=[40.083333333,41.866666667,42.2,14.55];
  for(const e of previous){
    const sc=e.time<6?-1:e.time>=170?20:sceneStarts.findIndex((a,i)=>e.time<a+sceneLengths[i]);
    if(removedTimes.some(t=>Math.abs(e.time-t)<.015)&&['woodLow','bell','wood'].includes(e.kind))continue;
    if(sc===12&&e.kind==='scream')continue;
    if(e.kind==='piano'&&[4,11,16,19,20].includes(sc)){e.kind='felt';e.amp*=1.05;}
    if(e.kind==='flute'&&[3,5,10].includes(sc)){e.kind='bamboo';e.amp*=.92;}
    if(e.kind==='midi'&&sc===16){e.kind='celesta';e.amp*=.83;}
    if(e.kind==='gamelan'&&sc===9){e.kind='softMallet';e.amp*=.90;}
    if(sc===5&&e.time>39.7&&e.time<42.1&&['bamboo','flute','harp','pipa'].includes(e.kind))e.amp*=.36;
    if(sc===5&&['wood','woodLow','rim','djembe'].includes(e.kind))e.amp*=.64;
    if(sc===12&&['strings','sine'].includes(e.kind))e.amp*=.67;
    if(sc===1&&e.time>13.10&&e.time<13.55&&e.kind!=='frame')e.amp*=.45;
    if(sc===20&&e.kind==='strings')e.amp*=.68;
    events.push(e);
  }
  for(let i=cues.length-1;i>=0;i--)if(['basket_touches_front_tyre','bridge_thanks_bell_1','bridge_thanks_bell_2','scribe_leaves_exit','scream_reaction'].includes(cues[i].name))cues.splice(i,1);
  cue(1,2.18,'wall_pigment_contact','brush',0,.036,.30);
  cue(1,3.66,'wall_living_exit','harp',74,.074,.85);
  cue(5,2.32,'fish_leaves_river','splash',0,.078,.34);
  cue(5,3.62,'fish_lands_beyond_bridge','splash',0,.088,.48);
  cue(5,3.96,'fish_right_of_way','bell',0,.105,.65);
  const leap=36+2.32/6*10,land=36+3.62/6*10;
  [[0,69],[.20,74],[.43,77],[.72,81],[1.03,86]].forEach(([u,n],j)=>event(leap+u,'softMallet',n,.47,.055*(1-j*.055),-.32+j*.16));
  [[.03,81],[.28,77],[.66,74]].forEach(([u,n],j)=>event(land+u,'bamboo',n,.56,.055-j*.006,.25));
  // Breath and harmonic answer measure the depth of the mountain; do not fill
  // every gap. The two sustained notes answer, rather than double, the qin.
  event(30.35,'bamboo',74,1.50,.040,-.27);
  event(33.40,'bamboo',69,1.25,.036,.25);
  event(34.90,'airyHarm',74,.65,.035,.22);
  event(53.8,'softMallet',81,.54,.038,.3);
  event(55.1,'softMallet',86,.62,.032,-.2);
  // The favourite night scene retains its existing phrase and timing.
  event(76+3.86/6*8,'celesta',86,1.10,.038,.38);
  cue(12,2.22,'scream_space_wave','bowSweep',69,.075,1.12);
  cue(12,3.32,'pelican_soft_answer','bowSweep',62,.053,.86);
  event(88.6,'felt',62,.72,.052,-.1);
  for(const e of events)if(e.kind==='shutter'&&e.time>=170)e.space='close';
  // Slow attacks are bounded by short notes, preventing a flute onset from
  // being cut off while still retaining natural air and a delayed vibrato.
  root.PelicanScoreTimeline={starts:sceneStarts,lengths:sceneLengths,intro:6,outro:16,duration:186,chatMessageTimes:messageTimes.map(u=>chat+3+u)};

  // R7: one ascending interval changes its physical source as the gallery turns.
  // Leave silence around the exposed stone, the interrupted breath and the
  // final answer; never double each visual gesture with percussion.
  const shade=(a,b,amount,kinds)=>{for(const e of events){if(e.time<a||e.time>=b||!kinds.includes(e.kind))continue;let u=(e.time-a)/(b-a);e.amp*=1-amount*Math.sin(u*Math.PI)**2;}};
  shade(18.65,20.6,.53,['bronze','strings','gong','frame']); // paper lifts from stone
  event(19.22,'brush',0,.31,.035,-.38); event(19.52,'woodLow',38,.26,.042,-.30);
  event(19.84,'bronze',57,1.04,.036,.08);
  shade(30.35,34.8,.35,['strings','harp','felt','bamboo']);
  shade(78.40,81.75,.32,['strings','piano','felt']); // star on a spoke → tower → village
  event(78.23,'airyHarm',74,.68,.031,-.42);
  event(80.95,'celesta',81,.64,.045,.23);event(81.42,'felt',74,.82,.035,.48);
  shade(93.62,97.22,.43,['piano','organ','strings','felt']);
  event(94.16,'sine',50,.48,.033,-.49);event(95.06,'sine',57,.63,.032,-.16);
  event(96.03,'sine',62,.74,.037,.27);  // optical shadow hands the motif to voltage
  shade(180.1,182.15,.67,['strings','felt','celesta','piano','organ','bamboo']);
  // Clip chip notes to the next note in their lane, so cues borrow channel B.
  for(const lane of ['chipA','chipB','chipC','chipD']){
    const es=events.filter(e=>e.channel===lane).sort((a,b)=>a.time-b.time);
    for(let i=0;i<es.length-1;i++)es[i].dur=Math.max(.012,Math.min(es[i].dur,es[i+1].time-es[i].time-.003));
  }
  events.sort((a,b)=>a.time-b.time);cues.sort((a,b)=>a.time-b.time);


  // Fractional-delay plucked strings: pick position, bridge losses, body color.
  function stringWave(kind,n,dur,sr){
    const f=hz(n),len=Math.ceil(dur*sr),a=new Float32Array(len),delay=sr/f-.18,N=Math.ceil(delay)+3,ring=new Float64Array(N);
    let seed=(n*7283+kind.length*1889)>>>0;const rand=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/2147483648-1;};
    const bright=['pipa','shamisen','sitar'].includes(kind),t60=kind==='guqin'?2.7:kind==='harp'?2.4:kind==='tanpura'?5.5:kind==='sitar'?2.3:1.25;
    const loss=Math.exp(-3.2/(t60*f)),blend=bright?.12:.24;
    for(let i=0;i<N;i++)ring[i]=rand()*.7;let dc=0,peak=0;
    for(let i=0;i<len;i++){
      let rp=(i-delay)%N;if(rp<0)rp+=N;const k=Math.floor(rp),u=rp-k,v=ring[k]*(1-u)+ring[(k+1)%N]*u,prev=ring[(k+N-1)%N];
      let feedback=(v*(1-blend)+prev*blend)*loss;ring[i%N]=feedback;
      const t=i/sr,phase=TAU*f*t;
      let x=v*.78+.24*Math.sin(phase)*Math.exp(-t*(kind==='tanpura'?.6:1.6));
      if(kind==='guqin')x+=.10*Math.sin(phase*2.002+.018*Math.sin(t*21))*Math.exp(-t*1.9);
      if(kind==='sitar'||kind==='tanpura')x+=.13*Math.tanh(v*3)*Math.sin(phase*2.003)*Math.exp(-t*1.6);
      if(kind==='shamisen')x+=.05*rand()*Math.exp(-t*95);
      dc+=.002*(x-dc);x=(x-dc)*Math.min(1,t/.003)*Math.min(1,(dur-t)/.085);a[i]=x;peak=Math.max(peak,Math.abs(x));
    }
    const gain=Math.min(1.3,.85/Math.max(.2,peak));for(let i=0;i<len;i++)a[i]*=gain;return a;
  }

  function wave(kind,n,dur,sr){
    const key=[kind,n,dur.toFixed(4),sr].join(':');
    if(waveCache.has(key))return waveCache.get(key);
    if(['harp','pipa','guqin','shamisen','sitar','tanpura'].includes(kind)){const a=stringWave(kind,n,dur,sr);waveCache.set(key,a);return a;}
    const length=Math.max(4,Math.ceil(dur*sr)),data=new Float32Array(length),f=hz(n||62);
    let seed=(0x6a09e667+Math.round(n*389)+kind.length*901)>>>0,noiseLow=0,noisePrev=0;
    const random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/2147483648-1;};
    const pluck=['harp','pipa','guqin','shamisen','sitar','tanpura','pizz','bass'].includes(kind);
    const pad=['strings','pad','organ','chant'].includes(kind);
    let phase=0;
    for(let i=0;i<length;i++){
      const t=i/sr,p=TAU*f*t,vib=Math.sin(TAU*5.3*t),rn=random();
      noiseLow+=.13*(rn-noiseLow);const high=rn-noisePrev;noisePrev=rn;
      let x=0,attack=.007,release=.04;
      if(pluck){
        const decay=kind==='guqin'?1.5:kind==='harp'?1.9:kind==='sitar'?1.65:kind==='tanpura'?.55:kind==='bass'?2.9:3.2;
        const bright=kind==='pipa'||kind==='shamisen';
        x=Math.sin(p)*Math.exp(-t*decay);
        for(let h=2;h<7;h++)x+=Math.sin(p*h+.025*Math.sin(t*17)*h)*Math.exp(-t*(decay+h*.72))/(bright?Math.pow(h,1.1):Math.pow(h,1.85));
        if(kind==='sitar'||kind==='tanpura')x+=.16*Math.sin(p*2.007)*Math.exp(-t*1.2)+.095*Math.sin(p*3.012)*Math.exp(-t*1.5);
        if(bright)x+=.09*high*Math.exp(-t*90);
        if(kind==='guqin')x+=.07*Math.sin(p*7.02)*Math.exp(-t*5);
        x*=.68;attack=kind==='bass'?.006:.002;release=.07;
      }else switch(kind){

        case 'felt':
          x=(Math.sin(p)+.24*Math.sin(p*2.0007)*Math.exp(-t*3.0)+.09*Math.sin(p*3.003)*Math.exp(-t*5.5)+.025*Math.sin(p*5.008)*Math.exp(-t*8))*.78*Math.exp(-t*1.65);
          x+=noiseLow*.012*Math.exp(-t*42);attack=.009;release=.16;break;
        case 'bamboo':
          {const swell=Math.min(1,t/.22),v=swell*.0032*Math.sin(TAU*5.1*t);
          phase+=TAU*f*(1+v+.007*Math.exp(-t*26))/sr;
          x=(Math.sin(phase)+.12*Math.sin(phase*2)+.035*Math.sin(phase*3)+.035*noiseLow)*.79*(1-.18*t/dur);
          attack=Math.min(.060,dur*.18);release=Math.min(.14,dur*.25);}break;
        case 'celesta':
          x=(Math.sin(p)*Math.exp(-t*2.6)+.24*Math.sin(p*2.012)*Math.exp(-t*6.8)+.075*Math.sin(p*3.97)*Math.exp(-t*9.6))*.70;attack=.0035;release=.12;break;
        case 'softMallet':
          x=(Math.sin(p)*Math.exp(-t*4.3)+.18*Math.sin(p*3.996)*Math.exp(-t*16)+.055*Math.sin(p*9.9)*Math.exp(-t*26))*.80;attack=.004;release=.10;break;
        case 'airyHarm':
          x=(Math.sin(p)+.26*Math.sin(p*2.0008)+.09*Math.sin(p*3.002)+.012*noiseLow)*.63*Math.exp(-t*.9);attack=.11;release=.19;break;
        case 'bowSweep':
          {const bend=2.2*Math.sin(Math.PI*Math.min(1,t/dur));phase+=TAU*f*Math.pow(2,bend/12)/sr;x=(Math.sin(phase)+.23*Math.sin(phase*2)+.07*Math.sin(phase*3))*.66;attack=.065;release=.19;}break;
        case 'piano':case 'electric':case 'midi':
          if(kind==='electric')x=(Math.sin(p+2.1*Math.sin(p*2)*Math.exp(-t*5))+.23*Math.sin(p*.999))*Math.exp(-t*1.8)*.7;
          else if(kind==='midi')x=(Math.sin(p)+.33*Math.sin(p*2.002)*Math.exp(-t*7)+.18*Math.sin(p*4.01)*Math.exp(-t*9))*Math.exp(-t*2.6)*.72;
          else x=(Math.sin(p)+.44*Math.sin(p*2.0009)*Math.exp(-t*2.7)+.23*Math.sin(p*3.006)*Math.exp(-t*4)+.13*Math.sin(p*4.016)*Math.exp(-t*6))*Math.exp(-t*1.65)*.6;
          attack=.004;release=.12;break;
        case 'fmBass':x=Math.sin(p+.8*Math.sin(p*2)*Math.exp(-t*12))*Math.exp(-t*2.8);attack=.008;break;
        case 'fretless':phase+=TAU*f*(1+.032*Math.exp(-t*24))/sr;x=(Math.sin(phase+.5*Math.sin(2*phase)*Math.exp(-t*9))+.12*Math.sin(2*phase))*Math.exp(-t*2.5)*.85;attack=.012;release=.08;break;
        case 'fmSax':
          x=(Math.sin(p+.08*vib+1.05*Math.sin(p)*Math.exp(-t*.6))+.24*Math.sin(p*2)+.1*noiseLow)*.58;
          x*=1-.38*t/dur;attack=.037;release=.08;break;
        case 'bronze':case 'gamelan':case 'gong':case 'lowGong':case 'frame':case 'bell':
          {const bf=kind==='bell'?1420:kind==='frame'?hz(n+12):f;
          const ratios=kind==='gamelan'?[1,2.73,5.17,6.66]:kind==='gong'||kind==='lowGong'?[1,1.43,2.09,2.73,3.41]:kind==='bell'?[1,1.501,2.037,2.91]:[1,2.756,5.405,8.931];
          const decay=kind==='bell'?5.9:kind==='frame'?6.8:kind==='lowGong'?1.15:kind==='gong'?1.8:2.8;
          ratios.forEach((r,j)=>{if(bf*r<sr*.42)x+=Math.sin(TAU*bf*r*t)*Math.exp(-t*(decay+j*1.7))/(1+j*1.9);});
          if(kind==='gamelan')x+=.28*Math.sin(TAU*bf*1.012*t)*Math.exp(-t*3.2);
          x*=.7;attack=kind==='lowGong'?.06:.0015;release=.055;}break;
        case 'flute':case 'xiao':case 'ocarina':
          x=Math.sin(p+.017*vib)+.13*Math.sin(2*p)+.04*Math.sin(3*p);
          if(kind==='xiao')x+=noiseLow*.28;else if(kind==='flute')x+=noiseLow*.12;
          x*=.76*(1-.22*t/dur);attack=kind==='ocarina'?.018:.042;release=.065;break;
        case 'chant':
          x=Math.sin(p)*.42+Math.sin(p*2)*.32+Math.sin(p*3+.018*vib)*.4+Math.sin(p*5)*.12+Math.sin(p*7)*.055;
          x*=.7*(.94+.06*Math.sin(t*TAU*4));attack=.1;release=.16;break;
        case 'strings':
          for(let h=1;h<8;h++)x+=(Math.sin(h*(p+.013*vib))+.33*Math.sin(h*(p*1.0019+.012*Math.sin(TAU*4.8*t))))/Math.pow(h,1.55);
          x*=.48;attack=.07;release=.14;break;
        case 'pad':x=(Math.sin(p)+.32*Math.sin(p*1.002)+.16*Math.sin(p*2.001))*.62;attack=.14;release=.22;break;
        case 'organ':x=(Math.sin(p)+.38*Math.sin(2*p)+.24*Math.sin(3*p)+.12*Math.sin(4*p))*.65;attack=.02;release=.1;break;
        case 'sine':x=Math.sin(p)*Math.exp(-t*2.7);attack=.008;release=.035;break;
        case 'tube':x=.65*Math.sin(TAU*60*t)+.19*Math.sin(TAU*120*t)+.12*noiseLow;attack=.2;release=.3;break;
        case 'power':phase+=TAU*(80+540*(1-Math.exp(-t*12)))/sr;x=(Math.sin(phase)+.25*high)*Math.exp(-t*8);attack=.004;break;
        case 'scopeWarp':
          phase+=TAU*(190+110*Math.sin(t*TAU*1.6)+310*Math.sin(t*2.4))/sr;
          x=Math.sin(phase+4.1*Math.sin(TAU*(9+t*8)*t))*.64;attack=.035;release=.15;break;
        case 'scream':
          phase+=TAU*(hz(78)+480*Math.sin(Math.min(1,t/.45)*Math.PI*.8))/sr;
          x=(Math.sin(phase)+.23*Math.sin(phase*1.044)+.13*Math.sin(phase*2.013))*.59;attack=.025;release=.15;break;
        case 'kick':phase+=TAU*(44+104*Math.exp(-t*34))/sr;x=Math.sin(phase)*Math.exp(-t*15)+.1*high*Math.exp(-t*100);attack=.001;release=.035;break;
        case 'djembe':case 'tablaLow':
          phase+=TAU*(f+(kind==='tablaLow'?52:79)*Math.exp(-t*24))/sr;
          x=(Math.sin(phase)+.22*Math.sin(phase*1.72))*Math.exp(-t*13)+.12*high*Math.exp(-t*65);attack=.001;break;
        case 'tabla':x=(Math.sin(p)+.42*Math.sin(p*1.52)+.2*Math.sin(p*2.67))*Math.exp(-t*19)+.18*high*Math.exp(-t*80);attack=.001;break;
        case 'wood':case 'woodLow':case 'rim':case 'key':
          {const fq=kind==='key'?1620:kind==='rim'?960:f*2;
          x=(Math.sin(TAU*fq*t)+.37*Math.sin(TAU*fq*1.48*t))*Math.exp(-t*(kind==='woodLow'?24:55))*.62+high*.22*Math.exp(-t*115);attack=.0005;release=.012;}break;
        case 'clap':
          {const env=Math.exp(-t*28)+.6*Math.exp(-Math.max(0,t-.013)*38)*(t>.013)+.5*Math.exp(-Math.max(0,t-.027)*40)*(t>.027);
          x=(rn-noiseLow)*env*.56;attack=.0005;release=.025;}break;
        case 'hat':case 'shaker':case 'brush':case 'switch':case 'chipNoise':
          x=(rn-noiseLow)*Math.exp(-t*(kind==='brush'?24:kind==='switch'?70:kind==='chipNoise'?34:65))*.67;attack=.0005;release=.018;
          if(kind==='chipNoise')x=Math.sign(x)*Math.exp(-t*40)*.55;break;
        case 'shutter':
          x=(rn-noiseLow)*(Math.exp(-t*105)+.64*Math.exp(-Math.max(0,t-.047)*95)*(t>=.047))*.8+.12*Math.sin(TAU*1730*t)*Math.exp(-t*65);attack=.0004;release=.012;break;
        case 'nudge':phase+=TAU*(290+170*Math.sin(t*TAU*7))/sr;x=Math.sin(phase)*Math.exp(-t*14)*.63;attack=.002;release=.02;break;
        case 'droplet':phase+=TAU*(f+f*.7*Math.exp(-t*37))/sr;x=Math.sin(phase+1.2*Math.sin(phase*2)*Math.exp(-t*28))*Math.exp(-t*20)*.68;attack=.001;release=.028;break;
        case 'splash':x=(noiseLow*1.3+rn*.17)*Math.exp(-t*19)+.12*Math.sin(TAU*(260*t-240*t*t))*Math.exp(-t*28);attack=.001;release=.04;break;
        case 'message':x=(Math.sin(p)+.22*Math.sin(p*2.76))*Math.exp(-t*13)*.8;attack=.0015;release=.035;break;
        case 'rain':case 'air':case 'tapeHiss':
          x=kind==='rain'?(rn-noiseLow)*(.66+.16*Math.sin(TAU*.35*t)):kind==='air'?noiseLow*2.2:(rn-noiseLow)*.4;
          attack=kind==='tapeHiss'?.02:.6;release=.55;break;
        case 'chipLead':case 'chipArp':
          {const duty=kind==='chipLead'?.25:.5,ph=(f*t)%1; // Band-limit the discontinuity with a short Fourier sum.
          for(let h=1;h<12;h++)if(h*f<sr*.4)x+=Math.sin(Math.PI*h*duty)*Math.cos(TAU*h*(ph-duty/2))/h;
          x*=.9*Math.exp(-t*.8);attack=.0015;release=.02;}break;
        case 'chipBass':for(let h=1;h<12;h+=2)x+=(h%4===1?1:-1)*Math.sin(p*h)/(h*h);x*=.78;attack=.003;release=.02;break;
        case 'chipJump':phase+=TAU*(180+1300*t)/sr;x=Math.sin(phase)+.22*Math.sin(phase*3);x*=Math.exp(-t*6)*.6;attack=.001;release=.025;break;
        default:x=Math.sin(p)*Math.exp(-t*3);
      }
      const a=Math.min(1,t/attack),r=Math.min(1,(dur-t)/Math.min(release,dur*.38));
      data[i]=Math.max(-1.8,Math.min(1.8,x))*a*Math.max(0,r);
    }
    waveCache.set(key,data);return data;
  }
  function bufferFor(ctx,e){
    let cache=contextBuffers.get(ctx);if(!cache){cache=new Map();contextBuffers.set(ctx,cache);}
    const key=[e.kind,e.n,e.dur.toFixed(4),ctx.sampleRate].join(':');if(cache.has(key))return cache.get(key);
    const a=wave(e.kind,e.n,e.dur,ctx.sampleRate),b=ctx.createBuffer(1,a.length,ctx.sampleRate);b.copyToChannel(a,0);cache.set(key,b);return b;
  }
  function noiseImpulse(ctx,seconds,seed=821){
    const b=ctx.createBuffer(2,Math.ceil(ctx.sampleRate*seconds),ctx.sampleRate);
    for(let ch=0;ch<2;ch++){
      let s=(seed+ch*991)>>>0,low=0;const a=new Float32Array(b.length);
      for(let i=0;i<a.length;i++){s=(Math.imul(s,1664525)+1013904223)>>>0;low+=.38*((s/2147483648-1)-low);const t=i/ctx.sampleRate;a[i]=low*Math.exp(-t*6.4/seconds)*(t<.015?t/.015:1);}
      // Sparse early reflections precede a diffuse, deterministic synthetic room.
      for(const [d,g]of [[.021,.28],[.037,.18],[.059,.12]])a[Math.floor((d+ch*.003)*ctx.sampleRate)]+=g;
      b.copyToChannel(a,ch);
    }return b;
  }
  // Chapter balance is applied after the common compressor. A short ramp at
  // each doorway avoids the much louder tape/phone abruptly following the chat.
  const programStarts=[0,6,11,17,22,29,36,46,51,58,63,70,76,84,90,96,104,113,145,151,160,170];
  const programDb=[-1.4,-1.2,3.8,1.4,3.3,2.0,1.4,-1.9,2.5,-2.8,-.2,2.6,-1.0,1.8,-1.5,-1.2,-2.8,1.3,-5.4,-2.6,-1.8,.5];
  const programLevel=t=>{let i=programStarts.length-1;while(i>0&&t<programStarts[i])i--;for(let k=Math.max(1,i);k<=Math.min(i+1,programStarts.length-1);k++){const u=(t-programStarts[k]+.35)/.7;if(u>=0&&u<=1)return Math.pow(10,((1-u)*programDb[k-1]+u*programDb[k])/20);}return Math.pow(10,programDb[i]/20);};
  function makeBus(ctx,destination,volume,rate){
    const input=ctx.createGain(),out=ctx.createGain(),hp=ctx.createBiquadFilter(),comp=ctx.createDynamicsCompressor(),program=ctx.createGain();
    out.gain.value=volume*MASTER_GAIN;hp.type='highpass';hp.frequency.value=31;hp.Q.value=.5;
    comp.threshold.value=-15;comp.knee.value=14;comp.ratio.value=2.5;comp.attack.value=.008;comp.release.value=.18;
    input.connect(hp);hp.connect(comp);comp.connect(program);program.connect(out);out.connect(destination);
    const rev=ctx.createConvolver(),send=ctx.createGain(),wet=ctx.createGain();
    rev.buffer=noiseImpulse(ctx,1.35/rate);send.gain.value=.16;wet.gain.value=.64;
    input.connect(send);send.connect(rev);rev.connect(wet);wet.connect(hp);
    return{input,dryInput:hp,out,program,nodes:[input,out,hp,comp,program,rev,send,wet]};
  }
  async function prepare(options={}){
    const sr=options.sampleRate||SAMPLE_RATE;
    if(tape&&tape.sampleRate===sr)return {sampleRate:sr,tapeSeconds:tape.duration};
    if(preparing)return preparing;
    const Offline=options.OfflineAudioContext||root.OfflineAudioContext||root.webkitOfflineAudioContext;
    if(!Offline)throw Error('OfflineAudioContext is required to synthesize the original vaporwave tape.');
    preparing=(async()=>{
      // Source performance is 151.2 BPM and four semitones above the main key.
      // No audio file is decoded. The AudioBuffer is born in this graph.
      const c=new Offline(2,Math.ceil(sr*6.3),sr),out=c.createGain();out.gain.value=.88;out.connect(c.destination);
      // A short synthetic drum room with an explicit gate, before the tape pass.
      const drumRoom=c.createConvolver(),drumWet=c.createGain(),drumIR=c.createBuffer(2,Math.ceil(sr*.18),sr);
      for(let ch=0;ch<2;ch++){
        const a=new Float32Array(drumIR.length);let seed=9871+ch*719;
        for(let i=0;i<a.length;i++){seed=(Math.imul(seed,1664525)+1013904223)>>>0;const t=i/sr;a[i]=(seed/2147483648-1)*Math.exp(-t*9)*Math.min(1,t/.002)*Math.min(1,(.18-t)/.018);}
        drumIR.copyToChannel(a,ch);
      }
      drumRoom.buffer=drumIR;drumWet.gain.value=.27;drumRoom.connect(drumWet);drumWet.connect(out);
      const sourceEvents=[], push=(time,kind,n,dur,amp,pan=0)=>sourceEvents.push({time,kind,n:n+4,dur,amp,pan});
      const speed=151.2/120, beat=60/151.2;
      const jazzChords=[[50,57,60,65,69],[43,54,57,62,66],[45,55,59,60,64]];
      for(let bar=0;bar<4;bar++){
        const ns=jazzChords[bar%3],at=bar*4*beat;
        ns.forEach((n,k)=>push(at+k*.012,'electric',n,1.7/speed,.065,(k-2)*.24));
        ns.forEach((n,k)=>push(at+2.5*beat+k*.013,'electric',n,1.05/speed,.035,(k-2)*.22));
        push(at,'fretless',[38,43,45][bar%3],1.2/speed,.15,-.05);
        push(at+1.5*beat,'fretless',[45,50,52][bar%3],.48/speed,.085,.04);
        push(at+3*beat,'fretless',[41,42,49][bar%3],.62/speed,.09,.02);
      }
      for(const [t,n,d]of theme)push(t/speed,'fmSax',n-12,(d+.2)/speed,.13,-.18);
      for(let b=0;b<16;b++){
        const at=b*beat;
        push(at,b%2===0?'kick':'clap',0,b%2===0?.28:.16,b%2===0?.115:.06,0);
        push(at+beat*.5,'hat',0,.07,.02,.5);
      }
      for(const e of sourceEvents){
        if(e.time>=6.3)continue;
        const s=c.createBufferSource(),g=c.createGain(),p=c.createStereoPanner();
        s.buffer=bufferFor(c,e);g.gain.value=e.amp;p.pan.value=e.pan;s.connect(g);g.connect(p);p.connect(out);if(e.kind==='clap')p.connect(drumRoom);s.start(e.time);
      }
      tape=await c.startRendering();preparing=null;return {sampleRate:sr,tapeSeconds:tape.duration};
    })();
    try{return await preparing;}catch(e){preparing=null;throw e;}
  }
  function schedule(ctx,options={}){
    const offset=clamp(options.offset||0,0,DURATION),rate=clamp(options.rate||1,.25,3);
    let when=options.when===undefined?ctx.currentTime+.12:options.when;
    const offline=!!options.offline, destination=options.destination||ctx.destination;
    // Prepare only the first lookahead window before the transport clock starts.
    // A cold instrument must not steal the first note's attack or desync the film.
    if(!offline){
      for(const e of events)if(e.time+e.dur>offset&&e.time<=offset+2.5*rate)bufferFor(ctx,e);
      when=Math.max(when,ctx.currentTime+.12);
    }
    const bus=makeBus(ctx,destination,options.volume===undefined?.92:options.volume,rate),sources=[],otherNodes=[];
    const nodes=bus.nodes, early=offset>0?.016:.004;
    bus.out.gain.setValueAtTime(0,Math.max(0,when));bus.out.gain.linearRampToValueAtTime((options.volume===undefined?.92:options.volume)*MASTER_GAIN,when+early);
    bus.program.gain.setValueAtTime(programLevel(offset),Math.max(0,when));
    const programTimes=programStarts.slice(1).flatMap(t=>[t-.35,t+.35]).filter(t=>t>offset);
    for(const t of programTimes)bus.program.gain.linearRampToValueAtTime(programLevel(t),when+(t-offset)/rate);
    let cursor=0,stopped=false,stoppedAt=null,timer=null,tapeScheduled=false;
    while(cursor<events.length&&events[cursor].time+events[cursor].dur<offset)cursor++;
    const map=t=>when+(t-offset)/rate;
    function launch(e){
      if(e.time+e.dur<=offset||e.time>=DURATION)return;
      const noteBuffer=bufferFor(ctx,e);
      let skip=Math.max(0,offset-e.time),start=map(e.time+skip);
      if(start<ctx.currentTime&&!offline){const late=ctx.currentTime-start;skip+=late*rate;start=ctx.currentTime;}
      if(skip>=e.dur-.002)return;
      const s=ctx.createBufferSource(),g=ctx.createGain(),p=ctx.createStereoPanner();
      s.buffer=noteBuffer;s.playbackRate.value=rate;g.gain.value=e.amp;p.pan.value=e.pan;
      s.connect(g);g.connect(p);p.connect(e.channel||e.space==='close'?bus.dryInput:bus.input);
      if(e.time>=170&&e.time<180){const fade=clamp((180-e.time)/7);g.gain.value=e.amp*(.22+.78*fade);}
      s.start(Math.max(0,start),skip);s.stop(Math.min(map(DURATION),start+(e.dur-skip)/rate+.004));
      sources.push(s);nodes.push(g,p);
    }
    function launchTape(){
      if(tapeScheduled||offset>=151.65)return;tapeScheduled=true;
      if(!tape)throw Error('Call and await PelicanScore.prepare() before playback.');
      const localTape=ctx.createBuffer(2,tape.length,tape.sampleRate);
      for(let ch=0;ch<2;ch++){const a=new Float32Array(tape.length);tape.copyFromChannel(a,ch);localTape.copyToChannel(a,ch);}
      const filt=ctx.createBiquadFilter(),dry=ctx.createGain(),send=ctx.createGain(),conv=ctx.createConvolver(),wet=ctx.createGain(),tapeOut=ctx.createGain();
      filt.type='lowpass';filt.frequency.value=4000;filt.Q.value=.6;dry.gain.value=.75;send.gain.value=.7;wet.gain.value=.72;
      conv.buffer=noiseImpulse(ctx,4/rate,4921);filt.connect(dry);dry.connect(tapeOut);filt.connect(send);send.connect(conv);conv.connect(wet);wet.connect(tapeOut);tapeOut.connect(bus.input);
      const end=map(151.65);tapeOut.gain.setValueAtTime(1,Math.max(ctx.currentTime,map(145)));tapeOut.gain.setValueAtTime(1,Math.max(ctx.currentTime,map(150.88)));tapeOut.gain.linearRampToValueAtTime(0,Math.max(ctx.currentTime+.005,end));
      otherNodes.push(filt,dry,send,conv,wet,tapeOut);
      const sourcePhase=local=>local<=.5?local-(1-.7937)*local*local: .448425+(local-.5)*.7937;
      const segments=[{a:0,b:2,from:0,entry:true},...Array.from({length:4},(_,i)=>({a:2+i*.25,b:2.25+i*.25,from:sourcePhase(2)})),{a:3,b:6.02,from:sourcePhase(2.25),exit:true}];
      for(const seg of segments){
        const absolute=145+seg.a,absoluteEnd=145+seg.b;if(absoluteEnd<=offset)continue;
        const skip=Math.max(0,offset-absolute),start=map(absolute+skip),s=ctx.createBufferSource(),g=ctx.createGain(),lfo=ctx.createOscillator(),depth=ctx.createGain();
        s.buffer=localTape;
        const startRate=seg.entry&&skip<.5?1-(1-.7937)*skip/.5:seg.exit&&seg.a+skip>5.5?.7937+(1-.7937)*(seg.a+skip-5.5)/.5:.7937;
        s.playbackRate.setValueAtTime(startRate*rate,Math.max(0,start));
        if(seg.entry&&skip<.5)s.playbackRate.linearRampToValueAtTime(.7937*rate,map(145.5));
        if(seg.exit){if(offset<150.5)s.playbackRate.setValueAtTime(.7937*rate,map(150.5));s.playbackRate.linearRampToValueAtTime(rate,map(151));}
        lfo.frequency.value=.5*rate;depth.gain.value=6.5;lfo.connect(depth);depth.connect(s.detune);
        const stop=map(absoluteEnd),fade=Math.min(.006,(stop-start)*.15);g.gain.setValueAtTime(0,Math.max(0,start));g.gain.linearRampToValueAtTime(1,start+fade);g.gain.setValueAtTime(1,stop-fade);g.gain.linearRampToValueAtTime(0,stop);
        s.connect(g);g.connect(filt);
        const u=Math.max(0,seg.a+skip-5.5),exitPhase=seg.exit?.2063*Math.min(u,.5)**2+.2063*Math.max(0,u-.5):0;
        const bufferOffset=seg.from+(seg.entry?sourcePhase(skip):skip*.7937+exitPhase);
        s.start(Math.max(0,start),bufferOffset);s.stop(stop);lfo.start(Math.max(0,start));lfo.stop(stop);sources.push(s,lfo);otherNodes.push(g,depth);
      }
      launch({time:145,kind:'tapeHiss',n:0,dur:6,amp:.012,pan:0});
    }
    function tick(){
      if(stopped)return;
      const until=offline?DURATION:Math.min(DURATION,offset+Math.max(0,ctx.currentTime-when)*rate+2.5*rate);
      while(cursor<events.length&&events[cursor].time<=until)launch(events[cursor++]);
      if(until>=145&&!tapeScheduled)launchTape();
      if(!offline&&ctx.currentTime>map(DURATION)+.15){clearInterval(timer);timer=null;}
    }
    tick();if(!offline)timer=setInterval(tick,120);
    return{
      startTime:when,endTime:map(DURATION),gain:bus.out,
      currentTime:()=>stoppedAt===null?clamp(offset+Math.max(0,ctx.currentTime-when)*rate,0,DURATION):stoppedAt,
      setVolume(v){const now=ctx.currentTime;bus.out.gain.cancelScheduledValues(now);bus.out.gain.setTargetAtTime(clamp(v,0,1.4)*MASTER_GAIN,now,.018);},
      stop(){if(stopped)return;stoppedAt=clamp(offset+Math.max(0,ctx.currentTime-when)*rate,0,DURATION);stopped=true;if(timer)clearInterval(timer);const now=ctx.currentTime;bus.out.gain.cancelScheduledValues(now);bus.out.gain.setTargetAtTime(0,now,.006);for(const s of sources)try{s.stop(now+.025);}catch(_){}if(!offline)setTimeout(()=>{for(const n of [...nodes,...otherNodes])try{n.disconnect();}catch(_){}},60);},
      eventCount:events.length
    };
  }
  async function renderOffline(Offline,options={}){
    const sr=options.sampleRate||SAMPLE_RATE,offset=options.offset||0,duration=options.duration||DURATION-offset;
    await prepare({sampleRate:sr,OfflineAudioContext:Offline});
    const ctx=new Offline(2,Math.ceil(sr*duration),sr);
    schedule(ctx,{offset,when:0,rate:1,offline:true,volume:options.volume===undefined?.92:options.volume});
    return ctx.startRendering();
  }
  root.PelicanScore={duration:DURATION,bpm:BPM,sampleRate:SAMPLE_RATE,theme,events,cues,chapterNames,prepare,schedule,renderOffline,
    info:()=>({original:true,revision:"R7 — paper, travelling star, shadow to voltage; space around the bell",externalAudioAssets:0,eventCount:events.length,generatedVoiceBuffers:waveCache.size,tapePrepared:!!tape,tapeSourceBpm:151.2,tapeSemitones:4,tapePlaybackRate:.7937,tapeStutter:[147,147.25,147.5,147.75]})};
  if(typeof module!=='undefined'&&module.exports)module.exports=root.PelicanScore;
})(typeof globalThis!=='undefined'?globalThis:this);
