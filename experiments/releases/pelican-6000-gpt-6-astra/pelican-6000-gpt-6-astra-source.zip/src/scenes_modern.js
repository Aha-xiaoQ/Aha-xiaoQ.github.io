/* Modern tableaux: procedural scenery and anchored, style-matched character cels. */
const M={
 bg(c,key,fn){c.drawImage(K.cached('modern-'+key,fn),0,0);},
 wave(c,x,y,w,h,col,lw=3,phase=0){c.beginPath();for(let i=0;i<=100;i++){let xx=x+i*w/100, yy=y+Math.sin(i*.15+phase)*h;i?c.lineTo(xx,yy):c.moveTo(xx,yy);}c.strokeStyle=col;c.lineWidth=lw;c.stroke();},
 hills(c,y,col,seed=1){let pts=[[0,900],[0,y]];for(let x=0;x<=1600;x+=40)pts.push([x,y+65*Math.sin(x*.006+seed)+30*Math.cos(x*.013+seed*2)]);pts.push([1600,900]);K.line(c,pts,null,1,true,col);},
 pine(c,x,y,s=1,col='#263c3e'){c.save();c.translate(x,y);c.scale(s,s);K.path(c,'M-7 0 L-3 -181 L7 -183 L10 0Z',col);for(let i=0;i<7;i++){let yy=-35-i*23,ww=90-i*9;K.path(c,`M2 ${yy-32} Q${-ww*.3} ${yy-7} ${-ww} ${yy+2} Q${-ww*.4} ${yy+12} 2 ${yy+6} Q${ww*.7} ${yy+14} ${ww} ${yy-1} Q${ww*.3} ${yy-14} 2 ${yy-32}Z`,col);}c.restore();},
 heart(c,x,y,s,col){c.save();c.translate(x,y);c.scale(s,s);K.path(c,'M0 9 C-20 -3 -19 -20 -8 -20 Q-2 -20 0 -13 Q4 -22 13 -19 C29 -11 17 2 0 15Z',col);c.restore();},
 strokeSky(c,seed,bg,palette){K.rect(c,0,0,1600,900,bg);for(let i=0;i<2650;i++){let x=K.rnd(i*2+seed)*1600,y=K.rnd(i*2+seed+1)*650,dx=(x-690)/1.8,dy=(y-300)*1.8,r=Math.hypot(dx,dy),a=Math.atan2(dy,dx)+Math.PI/2+.35*Math.sin(r*.014),len=11+K.rnd(i+52)*27;c.beginPath();c.moveTo(x,y);c.quadraticCurveTo(x+Math.cos(a+.15)*len*.5,y+Math.sin(a+.15)*len*.5,x+Math.cos(a)*len,y+Math.sin(a)*len);c.strokeStyle=palette[i%palette.length];c.lineWidth=2+K.rnd(i+104)*3.8;c.lineCap='round';c.stroke();}},
 traveller(c,x,y,s,dir,bow,coat,step=0){c.save();c.translate(x,y);c.scale(s,s);
 const lf=-13-step*3,rf=12+step*3;K.path(c,`M-10 -29 L${lf} -7 M7 -28 L${rf} -7`,null,'#334a43',5);K.path(c,`M${lf} -12 L${lf} -3 M${rf} -12 L${rf} -3`,null,'#d7d8bf',3.2);
 K.path(c,`M${lf-3} -4 L${lf-10} -1 L${lf-10} 1 L${lf+4} 1 L${lf+4} -3Z`,'#a79666','#3c5545',.9);K.path(c,`M${rf-3} -4 L${rf-3} 1 L${rf+11} 1 L${rf+11} -1 L${rf+3} -4Z`,'#a79666','#3c5545',.9);K.line(c,[[lf-4,-2],[lf,-4],[lf+2,0]],'#e3d8ae',.65);K.line(c,[[rf,-2],[rf+3,-4],[rf+7,0]],'#e3d8ae',.65);
 K.path(c,'M-13 -66 L10 -66 L20 -27 L-20 -27Z',coat,'#354d49',2);K.path(c,'M-10 -65 L3 -34 L10 -66 M-17 -34 L16 -34',null,'#e5d4a9',2);
 K.path(c,'M-12 -62 L-28 -48 L-24 -36 L-16 -43 L-11 -54 M10 -60 L24 -50 L29 -35 L20 -32 L14 -48',coat,'#354d49',1.1);K.path(c,'M-23 -39 L-18 -29 M25 -34 L29 -29',null,'#c9b180',3);K.ellipse(c,-18,-28,2.6,3.5,'#c9b180','#3c5145',.65);K.ellipse(c,29,-29,2.5,3.7,'#c9b180','#3c5145',.65);
 K.path(c,'M-7 -52 L-10 -37 M8 -47 L14 -29 M-5 -31 L-7 -28',null,'rgba(225,222,179,.65)',.8);K.rect(c,-17,-35,34,5,'#d6c69a','#4c5c46',.7);K.path(c,'M13 -34 L23 -38 L24 -31 L16 -32 L23 -24',null,'#e0d2a5',1.1);
 for(let j=0;j<3;j++){let yy=-53+j*7;K.path(c,`M-5 ${yy} l2 -2 l2 2 l-2 2Z`,null,'rgba(229,220,174,.55)',.65);}K.rect(c,-33,-43,17,16,'#ad8356','#354d49',1.1);K.line(c,[[-30,-39],[-18,-39]],'#d6bc83',.8);K.line(c,[[-26,-42],[-26,-28]],'#856e4d',.7);K.path(c,'M-30 -43 Q-25 -49 -20 -43',null,'#405246',.8);
 c.save();c.translate(0,-71);c.rotate(bow*.32);K.ellipse(c,0,0,10,12,'#d3b781','#3b5148',1.4);K.path(c,`M${dir*7} -3 L${dir*14} 1 L${dir*7} 4`,'#d3b781','#3b5148',1.1);K.circle(c,dir*5,-2,1.6,'#243e3b');K.path(c,'M-21 -7 Q0 -30 21 -7 L11 -3 L-13 -3Z','#b79e65','#344d45',2);for(let j=-14;j<=14;j+=7)K.line(c,[[0,-21],[j,-6]],'#8a794f',.8);c.restore();
 K.path(c,'M-14 -75 L-8 -62 L8 -62 L14 -75',null,'#a49c76',.65);K.line(c,[[30,-49],[37,0]],'#6d6245',2);K.line(c,[[31,-47],[36,-8]],'#c6b787',.7);c.restore();},
 starBurst(c,x,y,u,col='#ffe29d',pixel=false){if(u<0||u>1)return;for(let j=0;j<9;j++){let a=j*Math.PI*2/9,r=12+u*53,xx=x+Math.cos(a)*r,yy=y+Math.sin(a)*r+u*u*18;c.save();c.globalAlpha=1-u;if(pixel)K.rect(c,xx,yy,8,8,col);else K.line(c,[[xx,yy],[xx+Math.cos(a)*9,yy+Math.sin(a)*9]],col,3);c.restore();}},
 frame(c,x,y,w,h,col='#bb9556',lw=10){K.rect(c,x,y,w,h,null,col,lw);K.rect(c,x+lw,y+lw,w-lw*2,h-lw*2,null,col,1);},
 caption(c,s,x,y,col='#4c473c'){K.text(c,s,x,y,23,col,'center','sans');}
};
// Precision props and vector traces used by the electronic and game chapters.
M.round=function(c,x,y,w,h,r,fill,stroke,lw=1){c.beginPath();c.roundRect(x,y,w,h,r);if(fill){c.fillStyle=fill;c.fill();}if(stroke){c.lineWidth=lw;c.strokeStyle=stroke;c.stroke();}};
M.screw=function(c,x,y,r=5){K.circle(c,x,y,r,K.gradient(c,[x-r,y-r],[x+r,y+r],[[0,'#d2d4c6'],[.45,'#81928d'],[1,'#3a4c4d']]),'#1c2c2d',1);K.line(c,[[x-r*.55,y+r*.32],[x+r*.55,y-r*.32]],'#283c3d',1.3);};
M.knob=function(c,x,y,r,angle,label,small=false){
 K.ellipse(c,x+3,y+5,r+3,r+3,'rgba(0,0,0,.35)');
 K.circle(c,x,y,r+6,'#b8b9a7','#e7e7d5',1);K.circle(c,x,y,r,K.gradient(c,[x-r,y-r],[x+r,y+r],[[0,'#536066'],[.45,'#293a3d'],[1,'#132126']]),'#122329',2);
 for(let k=0;k<36;k++){let a=k*Math.PI/18;K.line(c,[[x+Math.cos(a)*(r-4),y+Math.sin(a)*(r-4)],[x+Math.cos(a)*(r-1),y+Math.sin(a)*(r-1)]],'#6d7977',1);}
 K.circle(c,x,y,r*.74,'#344447','#73817b',1);K.circle(c,x-4,y-5,r*.42,'rgba(193,205,185,.035)');
 K.line(c,[[x+Math.sin(angle)*r*.24,y-Math.cos(angle)*r*.24],[x+Math.sin(angle)*r*.66,y-Math.cos(angle)*r*.66]],'#eee6bc',3);
 for(let k=0;k<=10;k++){let a=-2.32+k*.464;K.line(c,[[x+Math.sin(a)*(r+12),y-Math.cos(a)*(r+12)],[x+Math.sin(a)*(r+17),y-Math.cos(a)*(r+17)]],'#526364',1.3);if(!small&&k%2===0)K.text(c,['.1','.2','.5','1','2','5'][k/2],x+Math.sin(a)*(r+28),y-Math.cos(a)*(r+28)+4,9,'#53615e','center','mono');}
 if(label)K.text(c,label,x,y+r+(small?26:39),small?10:13,small?'#c3d1b8':'#304849','center','mono','600');
};
M.socket=function(c,x,y,label,col='#c5ba6a'){K.circle(c,x,y,14,'#828e83','#415b5a',2);K.circle(c,x,y,10,col,'#162c2f',2);K.circle(c,x,y,5,'#18272b','#cfcdaf',1);K.text(c,label,x,y-23,11,'#3e5657','center','mono','700');};
M.sampleSvg=function(s){
 const tok=s.match(/[A-Za-z]|-?(?:\d*\.)?\d+(?:e[-+]?\d+)?/g),out=[];let j=0,cmd='',p=[0,0],first=[0,0],cur=[];
 const num=()=>Number(tok[j++]);
 while(j<tok.length){if(/[A-Za-z]/.test(tok[j]))cmd=tok[j++];
 if(cmd==='M'){if(cur.length)out.push(cur);p=[num(),num()];first=p;cur=[p];cmd='L';}
 else if(cmd==='L'){p=[num(),num()];cur.push(p);}
 else if(cmd==='Q'){const a=p,b=[num(),num()],d=[num(),num()];for(let n=1;n<=14;n++){let u=n/14,v=1-u;cur.push([v*v*a[0]+2*v*u*b[0]+u*u*d[0],v*v*a[1]+2*v*u*b[1]+u*u*d[1]]);}p=d;}
 else if(cmd==='C'){const a=p,b=[num(),num()],d=[num(),num()],e=[num(),num()];for(let n=1;n<=18;n++){let u=n/18,v=1-u;cur.push([v*v*v*a[0]+3*v*v*u*b[0]+3*v*u*u*d[0]+u*u*u*e[0],v*v*v*a[1]+3*v*v*u*b[1]+3*v*u*u*d[1]+u*u*u*e[1]]);}p=e;}
 else if(cmd==='Z'){cur.push(first);p=first;cmd='';}
 else break;
 }if(cur.length)out.push(cur);return out;
};
M.traceContours=function(p){
 if(!M.birdContours){
 const g=P.riderGeometry.paths;
 const paths=P.characterSkin?[P.characterSkin.path,P.characterSkin.wing,g.pouch,g.bill]:['tail','body','neck','wing','pouch','bill'].map(k=>g[k]);
 M.birdContours=paths.flatMap(s=>M.sampleSvg(s));
 }
 const phase=Number.isFinite(p.crankAngle)?p.crankAngle:(p.phaseTime===undefined?0:p.phaseTime*Math.PI*2),rot=p.wheelAngle||0;
 const skinPose=P.characterSkin&&P.characterSkin.pose(p.phaseTime||0,phase,p,14);
 const lines=M.birdContours.map((line,i)=>line.map(([x,y])=>{
 if(!skinPose)return[x,y];
 if(i===0)return skinPose.local(x,y);
 if(i===1){const q=K.smoother((100-x)/155);return[x+skinPose.lean*(y+112)*q,y];}
 const a=skinPose.head(x,y);return[a[0]+skinPose.lean*(a[1]+112),a[1]];
 }));
 for(const x of [-130,150]){let line=[];for(let n=0;n<=64;n++){let a=n*Math.PI/32;line.push([x+77*Math.cos(a),25+77*Math.sin(a)]);}lines.push(line);for(let k=0;k<12;k++){let a=rot+k*Math.PI/6;lines.push([[x,25],[x+69*Math.cos(a),25+69*Math.sin(a)]]);}}
 lines.push([[-130,25],[-66,-92],[0,0],[-130,25]],[[-66,-92],[94,-80],[0,0]],[[94,-80],[150,25]],[[94,-80],[96,-119],[109,-132],[135,-132],[144,-120],[136,-109]],[[-93,-111],[-45,-110]]);
 for(let k=0;k<2;k++){let a=phase+k*Math.PI,h=[-56,-112],f=[31*Math.cos(a),31*Math.sin(a)],dx=f[0]-h[0],dy=f[1]-h[1],dist=Math.hypot(dx,dy),u=dx/dist,v=dy/dist,d=(88*88-77*77+dist*dist)/(2*dist),b=Math.sqrt(Math.max(0,88*88-d*d));lines.push([h,[h[0]+d*u+b*v,h[1]+d*v-b*u],f,[f[0]+18,f[1]+5]]);}
 // R4: X/Y acquisition includes the actual closed drivetrain, not a substitute.
 const ch=P.chainGeometry(),run=[];for(let k=0;k<=100;k++)run.push(ch.at(ch.length*k/100));lines.push(run);
 const ring=[];for(let k=0;k<=36;k++){let a=k*Math.PI/18;ring.push([24*Math.cos(a),24*Math.sin(a)]);}lines.push(ring);
 return lines;
};
M.traceSamples=function(lines,n=400){const seg=[];let total=0;for(const line of lines)for(let j=1;j<line.length;j++){const a=line[j-1],b=line[j],len=Math.hypot(b[0]-a[0],b[1]-a[1]);if(len>.001){seg.push({a,b,from:total,len});total+=len;}}let idx=0,out=[];for(let k=0;k<n;k++){let d=total*k/n;while(idx<seg.length-1&&seg[idx].from+seg[idx].len<d)idx++;const q=seg[idx],u=K.clamp((d-q.from)/q.len);out.push([K.lerp(q.a[0],q.b[0],u),K.lerp(q.a[1],q.b[1],u)]);}return out;};
M.tracePortion=function(c,lines,from,to,color,lw){let total=0;for(const line of lines)for(let j=1;j<line.length;j++)total+=Math.hypot(line[j][0]-line[j-1][0],line[j][1]-line[j-1][1]);let pos=0,head=null;c.beginPath();for(const line of lines){for(let j=1;j<line.length;j++){let a=line[j-1],b=line[j],len=Math.hypot(b[0]-a[0],b[1]-a[1]),s=Math.max(0,(from*total-pos)/len),e=Math.min(1,(to*total-pos)/len);if(s<=e&&s<=1&&e>=0){c.moveTo(K.lerp(a[0],b[0],s),K.lerp(a[1],b[1],s));c.lineTo(K.lerp(a[0],b[0],e),K.lerp(a[1],b[1],e));head=[K.lerp(a[0],b[0],e),K.lerp(a[1],b[1],e)];}pos+=len;}}c.lineWidth=lw;c.strokeStyle=color;c.stroke();return head;};
M.pixelTile=function(c,x,y,type=0){const green=type?'#7ca35a':'#90bb63';K.rect(c,x,y,40,38,'#536844');K.rect(c,x,y,40,9,green);K.rect(c,x+2,y+9,36,5,'#4d794b');for(let q=0;q<4;q++){K.rect(c,x+q*10,y+7,6,7,q%2?'#a1c970':'#76a957');}K.rect(c,x+1,y+17,38,21,'#926a47');K.rect(c,x+7,y+20,13,5,'#ad8455');K.rect(c,x+25,y+29,11,5,'#604d3a');};
M.pixelChime=function(c,x,y,t){const w=15,glint=Math.floor(t*3)%3;K.rect(c,x-3,y-23,6,6,'#425d66');K.rect(c,x-9,y-17,18,6,'#f2d992');K.rect(c,x-12,y-11,24,24,'#b47b43');K.rect(c,x-15,y-5,30,18,'#d8a34f');K.rect(c,x-w-3,y+13,w*2+6,6,'#7c563d');K.rect(c,x-w,y+10,w*2,6,'#f3cd75');K.rect(c,x-9,y-9,6,18,'#fff0ba');K.rect(c,x+6,y-5,3,15,'#a16a3c');K.rect(c,x-3,y+19,6,6,'#fff0b4');K.rect(c,x-3,y-5,9,9,'#75bcb0');if(glint===1)K.rect(c,x+8,y-13,4,4,'#fff9d5');};
M.pixelSpringT=2.1;M.pixelLandT=4.5;
M.pixelPose=function(t){const u=K.clamp((t-M.pixelSpringT)/(M.pixelLandT-M.pixelSpringT)),jump=Math.sin(u*Math.PI)*155;return{x:1600*t/6,y:730-102*.72-jump,scale:.72,style:15,tilt:-.075*Math.sin(u*Math.PI),headNod:-.05*Math.sin(u*Math.PI),gazeX:1,gazeY:-.12,shadow:false};};
M.pixelCoinPoint=function(hit){const p=M.pixelPose(hit),s=p.scale,a=p.tilt;return{x:p.x+s*(150*Math.cos(a)+52*Math.sin(a)),y:p.y+s*(150*Math.sin(a)-52*Math.cos(a))-21};};
M.codeFloor=function(x){if(x<=1110||x>=1460)return 728;const u=(x-1110)/350;return 728-168*u*(1-u);};
M.codePathLength=function(u=1){let sum=174,prev=[1110,728];for(let j=1;j<=100;j++){let q=u*j/100,x=1110+350*q,y=M.codeFloor(x);sum+=Math.hypot(x-prev[0],y-prev[1]);prev=[x,y];}return sum;};
M.groundPose=function(x,s,floor){let a=0;for(let n=0;n<4;n++){const co=Math.cos(a),si=Math.sin(a),rx=x+s*(-130*co-25*si),fx=x+s*(150*co-25*si);a=Math.atan2(floor(fx)-floor(rx),fx-rx);}const co=Math.cos(a),si=Math.sin(a),rx=x+s*(-130*co-25*si),fx=x+s*(150*co-25*si);return{x,y:(floor(rx)-77*s-s*(-130*si+25*co)+floor(fx)-77*s-s*(150*si+25*co))/2,scale:s,tilt:a};};
M.codeTokenLine=function(c,s,x,y,size=16.5){const tokens=s.match(/"[^"]*"|'[^']*'|\/\/.*|\b(?:const|new|return|debugger)\b|\b\d+(?:\.\d+)?\b|[A-Za-z_$][\w$]*(?=\()|[^"'\w]+|\w+/g)||[s];let dx=x;for(const token of tokens){let color=/^\/\//.test(token)?'#6e8c84':/^["']/.test(token)?'#c7d793':/^(const|new|return|debugger)$/.test(token)?'#d9a9d0':/^\d/.test(token)?'#e6c38d':/^(moveTo|lineTo|quadraticCurveTo|follow|find|bell|next|Path2D|requestAnimationFrame)$/.test(token)?'#a6d7e2':'#c6d6d7';K.text(c,token,dx,y,size,color,'left','mono');dx+=c.measureText(token).width;}return dx;};

// R4: every material is built from its structure — roof tiles, carved flutes,
// needles, ripples and cloth seams — in the same flat colour / fine line language.
M.woodPine=function(c,x,y,s=1,flip=1,wind=0){c.save();c.translate(x,y);c.scale(s*flip,s);
 K.path(c,'M-19 0 Q5 -87 -5 -151 Q-15 -205 19 -261 L34 -261 Q4 -187 13 -139 Q28 -66 2 0Z','#685e42','#304b43',2);
 K.path(c,'M-9 -7 Q14 -94 3 -149 Q-4 -203 25 -253 M-15 -14 Q4 -64 4 -101 M8 -153 L14 -174 M1 -188 L15 -210',null,'#a39365',1.4);
 const branches=[[-2,-91,-90,-124], [8,-134,103,-151], [6,-170,-65,-203], [12,-205,78,-232], [24,-252,-20,-278], [13,-143,40,-183]];
 for(const [ax,ay,bx,by]of branches){const drift=wind*(.7-by/220),ex=bx+drift,ey=by+Math.sin(bx*.02)*drift*.17;K.path(c,`M${ax} ${ay} Q${(ax+ex)*.5} ${ey+18} ${ex} ${ey}`,null,'#3d5142',6);K.path(c,`M${ax} ${ay-2} Q${(ax+ex)*.5} ${ey+15} ${ex} ${ey-1}`,null,'#b09e70',1);}
 const crowns=[[-87,-127,53,20],[91,-152,65,23],[-61,-202,63,22],[73,-235,54,19],[-10,-280,55,23],[28,-183,55,20],[-123,-112,31,14]];
 crowns.forEach(([cx,cy,rx,ry],k)=>{const drift=wind*(.7-cy/220);c.save();c.translate(drift,Math.sin(cx*.02)*drift*.17);K.path(c,`M${cx-rx} ${cy+6} Q${cx-rx*.82} ${cy-ry*.4} ${cx-rx*.48} ${cy-ry*.42} Q${cx-rx*.38} ${cy-ry*1.2} ${cx} ${cy-ry*.81} Q${cx+rx*.38} ${cy-ry*1.25} ${cx+rx*.55} ${cy-ry*.45} Q${cx+rx*.85} ${cy-ry*.55} ${cx+rx} ${cy+3} Q${cx+rx*.1} ${cy+ry*.57} ${cx-rx} ${cy+6}Z`,k%2?'#315b51':'#234e48','#254a43',1.2);
  for(let j=0;j<9;j++){let xx=cx-rx*.8+j*rx*.19,yy=cy-4+Math.sin(j*.8+k)*4;K.path(c,`M${xx-6} ${yy+5} L${xx} ${yy-7} L${xx+5} ${yy+4} M${xx} ${yy-7} L${xx+12} ${yy-1}`,null,j%2?'#6e8b68':'#88a081',.8);}
  K.path(c,`M${cx-rx*.8} ${cy+7} Q${cx} ${cy+ry*.32} ${cx+rx*.81} ${cy+5}`,null,'#9aa77f',.9);c.restore();
 });c.restore();
};
M.teaHouse=function(c,x,y,s=1){c.save();c.translate(x,y);c.scale(s,s);
 K.path(c,'M-31 8 L252 8 L273 23 L-45 23Z','#a2946d','#5b654f',1.5);
 K.path(c,'M0 -119 L228 -119 L228 5 L0 5Z','#ceb78a','#425b4d',2);K.path(c,'M228 -117 L253 -134 L253 -9 L228 5Z','#8c9471','#425b4d',1.5);
 K.rect(c,7,-103,211,101,'#b09e71');K.rect(c,9,-100,63,88,'#d7ceaa','#5c6b52',1);K.rect(c,83,-100,64,88,'#b9c5a4','#5c6b52',1);K.rect(c,158,-100,57,88,'#d7ceaa','#5c6b52',1);
 for(let k=0;k<3;k++){let lx=[10,84,159][k],w=[61,62,55][k];for(let i=1;i<6;i++)K.line(c,[[lx+i*w/6,-99],[lx+i*w/6,-15]],'#71816b',.85);for(let j=1;j<5;j++)K.line(c,[[lx,-100+j*17],[lx+w,-100+j*17]],'#71816b',.85);K.rect(c,lx,-42,w,27,'#b8aa7e');for(let q=0;q<4;q++)K.line(c,[[lx+3,-39+q*6],[lx+w-3,-39+q*6]],'#8b8a65',.7);}
 K.rect(c,104,-67,23,55,'#4b6253');K.line(c,[[108,-63],[108,-16]],'#879b75',1.2);K.circle(c,124,-41,1.3,'#d8c79c');
 for(const xx of [0,76,151,225]){K.rect(c,xx-3,-123,7,133,'#4f644e','#354e43',.8);K.line(c,[[xx-1,-119],[xx-1,7]],'#b7ab7e',1.1);}
 K.path(c,'M-29 -119 Q18 -136 39 -161 L210 -149 Q231 -129 263 -123 L261 -112 L-33 -110Z','#475d51','#2f4c43',2.4);
 K.path(c,'M-26 -122 Q9 -136 40 -157 L209 -146 Q235 -129 258 -124',null,'#9bac8b',2);
 c.save();c.clip(new Path2D('M-29 -119 Q18 -136 39 -161 L210 -149 Q231 -129 263 -123 L261 -112 L-33 -110Z'));for(let i=0;i<31;i++){let xx=-37+i*10;K.path(c,`M${xx} -110 Q${xx+6} -130 ${48+(xx+37)*.63} -158`,null,i%3?'#6f8168':'#adba93',.9);}for(let j=0;j<4;j++)K.path(c,`M-32 ${-114-j*10} Q98 ${-118-j*11} 264 ${-114-j*4}`,null,'#263f3c',.8);c.restore();
 K.line(c,[[37,-163],[213,-150]],'#2a4540',4);K.line(c,[[40,-164],[212,-151]],'#adc099',1);
 for(let i=0;i<13;i++){let xx=-25+i*23;K.path(c,`M${xx} -112 q3 5 7 0`,null,'#bed0a8',1);}
 K.rect(c,-13,-7,260,9,'#6f785a','#3c5546',1.2);K.line(c,[[-13,-5],[247,-5]],'#d7c49a',1.1);K.rect(c,-9,3,8,17,'#58664a');K.rect(c,235,3,8,17,'#58664a');
 K.rect(c,8,-20,67,5,'#7f7652','#405441',.8);for(const xx of [15,62])K.line(c,[[xx,-18],[xx-2,-3]],'#53634c',3);
 K.ellipse(c,32,-23,9,3,'#eee0b2','#6c7657',.8);K.path(c,'M26 -30 L28 -23 L36 -23 L38 -30Z','#cad2b4','#69785b',.8);K.ellipse(c,32,-30,6,2,'#eee3b8','#6b7b5b',.6);
 K.line(c,[[245,-114],[273,-118],[273,-26]],'#495b49',2);K.path(c,'M255 -109 L279 -109 L279 -54 L255 -54Z','#ae5141','#663f33',1);K.text(c,'茶',267,-75,19,'#f2dfaf','center','serif');K.line(c,[[258,-105],[258,-59]],'#df9a69',1);
 K.ellipse(c,235,-78,10,16,'#d8b65f','#5f6549',1);for(let j=-1;j<=1;j++)K.path(c,`M${235+j*4} -93 Q${238+j*4} -78 ${235+j*4} -63`,null,'#ad8648',.7);K.line(c,[[226,-87],[244,-87]],'#735d3e',1);K.line(c,[[226,-69],[244,-69]],'#735d3e',1);
 c.restore();
};
M.nightHouse=function(c,x,y,w,h,kind=0,depth=0){const ink=depth?'#1b3564':'#0b2148',wall=['#234b83','#315c92','#143b75','#3a6093'][kind%4],roof=['#0b2049','#193b6e','#102955'][kind%3],eave=y-h;
 K.path(c,`M${x} ${eave} L${x+w} ${eave} L${x+w} ${y} L${x} ${y}Z`,wall,ink,1.2);K.path(c,`M${x+w} ${eave} L${x+w+10} ${eave+8} L${x+w+10} ${y-4} L${x+w} ${y}Z`,'#183561',ink,.8);
 const peak=eave-16-w*.16;K.path(c,`M${x-6} ${eave+2} L${x+w*.43} ${peak} L${x+w+6} ${eave+3}Z`,roof,'#6292b5',1.1);K.path(c,`M${x+w*.43} ${peak} L${x+w+14} ${peak+7} L${x+w+15} ${eave+9} L${x+w+6} ${eave+3}Z`,'#102850','#365d8c',.8);
 for(let r=1;r<4;r++)K.line(c,[[x-4+r*5,eave-r*4],[x+w+3-r*5,eave-r*4]],'#3e6b98',.65);
 if(kind%3!==1){K.rect(c,x+w*.72,peak-6,6,17,'#315886',ink,.8);K.rect(c,x+w*.72-1,peak-7,8,3,'#7295b0');}
 const cols=w>60?3:2,ww=6.5;for(let r=0;r<(h>64?2:1);r++)for(let k=0;k<cols;k++){let wx=x+9+k*(w-18-ww)/(cols-1),wy=eave+12+r*22;K.rect(c,wx-2,wy-2,ww+4,14,'#112b52','#527b9e',.65);K.rect(c,wx,wy,ww,10,'#314965');K.line(c,[[wx+ww/2,wy],[wx+ww/2,wy+10]],'#243e57',.65);K.line(c,[[wx,wy+5],[wx+ww,wy+5]],'#243e57',.65);K.line(c,[[wx-3,wy+13],[wx+ww+3,wy+13]],'#718b97',.8);M.nightWindows.push({x:wx,y:wy,w:ww,depth,seed:x+r*4+k});}
 let dx=x+w*.52-5;K.path(c,`M${dx} ${y-1} L${dx} ${y-22} Q${dx+5} ${y-28} ${dx+10} ${y-22} L${dx+10} ${y-1}Z`,'#0b224a','#66899c',.8);K.circle(c,dx+8,y-11,.8,'#efd678');K.line(c,[[x+1,y-1],[x+w-1,y-1]],'#476a88',1);for(let r=0;r<3;r++)K.line(c,[[x+4+r*10,y-6],[x+9+r*10,y-7]],'#456d98',.65);
};
M.palmFrond=function(c,ex,ey,cx,cy,col,light){K.path(c,`M0 -260 Q${cx} ${cy} ${ex} ${ey}`,null,light,1.5);for(let j=1;j<12;j++){let u=j/12,v=1-u,x=2*v*u*cx+u*u*ex,y=v*v*-260+2*v*u*cy+u*u*ey,dx=2*v*cx+2*u*(ex-cx),dy=2*v*(cy+260)+2*u*(ey-cy),len=Math.hypot(dx,dy),nx=-dy/len,ny=dx/len,sz=(18+22*Math.sin(u*Math.PI))*(1-u*.4);for(const side of [-1,1]){const tx=x+nx*sz*side+dx/len*13,ty=y+ny*sz*side+dy/len*13;K.path(c,`M${x-2} ${y} Q${x+nx*sz*.45*side} ${y+ny*sz*.45*side} ${tx} ${ty} Q${x+nx*sz*.22*side+dx/len*11} ${y+ny*sz*.22*side+dy/len*11} ${x+3} ${y+3}Z`,col);K.line(c,[[x,y],[tx,ty]],light,.55);}}};
M.palmFine=function(c,x,y,s=1,flip=1,far=false){c.save();c.translate(x,y);c.scale(s*flip,s);const trunk=far?'#56236f':'#100d35',leaf=far?'#54206d':'#0c0d2c',light=far?'#a44b93':'#4b3d7e';K.path(c,'M-8 0 Q10 -109 -8 -197 L-5 -260 L5 -260 L11 -196 Q31 -93 7 0Z',trunk,'#231041',1.2);for(let i=0;i<18;i++){let yy=-10-i*13,xx=4+10*Math.sin((yy+260)/260*Math.PI);K.path(c,`M${xx-9} ${yy} Q${xx} ${yy+4} ${xx+8} ${yy-2}`,null,light,.7);}for(const f of [[-131,-208,-75,-297],[-144,-260,-75,-315],[-96,-327,-45,-335],[-36,-350,-23,-357],[38,-341,15,-353],[118,-298,57,-331],[142,-236,76,-296],[101,-184,58,-280],[-63,-178,-35,-277]])M.palmFrond(c,...f,leaf,light);K.ellipse(c,0,-254,9,12,'#211241','#78509a',.8);K.ellipse(c,10,-253,6,9,'#271440','#78509a',.8);c.restore();};
M.classicColumn=function(c,x,y,h,w,col='#9873ba'){const top=y-h;K.rect(c,x-w*.57,top+12,w*1.14,h-23,col,'#4a397e',1);for(let i=0;i<7;i++){let xx=x-w*.42+i*w*.14;K.path(c,`M${xx} ${top+18} Q${xx-2} ${(top+y)/2} ${xx} ${y-16}`,null,i%2?'#e7a4ce':'#8b5eaa',1.1);}K.rect(c,x-w*.78,top,w*1.56,6,'#ffb8d8','#5f3a82',.8);K.path(c,`M${x-w*.71} ${top+6} L${x-w*.5} ${top+14} L${x+w*.5} ${top+14} L${x+w*.71} ${top+6}Z`,col,'#69438e',.7);K.rect(c,x-w*.66,y-13,w*1.32,7,'#c38bcc','#5d3984',.7);K.rect(c,x-w*.8,y-6,w*1.6,6,'#efadd2','#5d3984',.7);};
// R5: a self-calibrating instrument replaces the operator entirely.
// One physical route carries the reference pulse into the gain dial.
M.scopeAutoCal=function(c,t,gain){
 const armed=K.ease((t-1.72)/.18),locked=K.ease((t-3.60)/.18),pulse=K.clamp((t-1.91)/.24);
 const route=[[636,756],[636,743],[682,743],[695,752],[716,752]];
 M.round(c,615,751,42,29,4,'#667b6b','#3b5851',1);K.circle(c,636,765,8,'#314e3d','#b0bd9b',1);
 K.circle(c,636,765,5.2,locked>.5?'#bee9a4':armed>.3?'#efd17d':'#79896c');K.circle(c,634.5,763.6,1.5,armed>.3?'#fff2b7':'#b4ba95');
 K.text(c,'CAL',636,795,10,'#36584a','center','mono','700');
 K.line(c,route,'#83957a',3);K.line(c,route,'#415f50',1.1);
 for(const [x,y]of [[636,743],[682,743],[716,752]]){K.circle(c,x,y,2.2,'#c2cba6','#566f55',.7);}
 if(t>=1.91&&t<=2.21){c.save();c.shadowColor='#e9dd87';c.shadowBlur=5;M.tracePortion(c,[route],Math.max(0,pulse-.31),Math.min(1,pulse+.03),'#f9e7a0',3);c.restore();}
 if(armed>.01){c.save();c.globalAlpha=armed*(1-locked*.75);c.shadowColor='#e6c975';c.shadowBlur=6;K.circle(c,636,765,9.8,null,'rgba(245,222,132,.58)',1.4);c.restore();}
 // The reference arrives before the existing 2.15–3.60 gain sweep begins.
 const phase=t<1.72?'STANDBY':t<2.15?'REFERENCE':t<2.5?'SYNC TEST':t<3.15?'MEASURING':t<3.6?'SETTLING':'CAL LOCK';
 M.round(c,791,749,81,34,3,'#556f60','#91a183',.9);K.rect(c,797,755,69,7,'#294a3c');
 const level=t<1.72?.12:t<2.15?pulse*.75:t<3.6?.25+gain*.65:1;
 for(let i=0;i<12;i++)K.rect(c,799+i*5.4,756,3.5,5,i<Math.round(level*12)?(locked>.5?'#b9d79a':'#dbcb7e'):'#45634d');
 K.text(c,phase,832,777,8.1,locked>.5?'#dfedb3':'#ece0ad','center','mono','700');
 if(t>=2.15&&t<3.72){c.save();c.globalAlpha=.35+gain*.4;c.beginPath();c.arc(740,766,28,-1.57+.34,-1.57+.34+Math.max(.04,gain*.55));c.strokeStyle='#dfc57d';c.lineWidth=2;c.stroke();c.restore();}
 if(t>3.6){const q=K.clamp((t-3.6)/.3);K.path(c,`M${816} 791 L${820} 795 L${827} 787`,null,`rgba(60,103,65,${q})`,1.6);K.text(c,'1.000',852,796,8.5,'#46674f','center','mono');}
};
// A few broad, shaped strokes follow a fixed flow field. Marks are distributed
// along the painted path, rather than sprayed as a screen-space texture.
M.flowTracks={};
M.flowTrack=function(path){if(M.flowTracks[path])return M.flowTracks[path];const pts=M.sampleSvg(path).flat(),dist=[0];for(let i=1;i<pts.length;i++)dist.push(dist[i-1]+Math.hypot(pts[i][0]-pts[i-1][0],pts[i][1]-pts[i-1][1]));return M.flowTracks[path]={pts,dist,total:dist[dist.length-1]};};
M.flowPoint=function(track,q,off=0){q=K.clamp(q,0,track.total);let lo=1,hi=track.dist.length-1;while(lo<hi){const mid=(lo+hi)>>1;if(track.dist[mid]<q)lo=mid+1;else hi=mid;}const a=track.pts[lo-1],b=track.pts[lo],len=Math.max(.001,track.dist[lo]-track.dist[lo-1]),u=(q-track.dist[lo-1])/len,nx=-(b[1]-a[1])/len,ny=(b[0]-a[0])/len;return{x:K.lerp(a[0],b[0],u)+nx*off,y:K.lerp(a[1],b[1],u)+ny*off,nx,ny};};
M.flowBrush=function(c,path,palette,width=4.2,lanes=5,seed=0){
 const tr=M.flowTrack(path);if(tr.total<1)return;
 for(let lane=0;lane<lanes;lane++){const off=(lane-(lanes-1)*.5)*width*.88;let start=K.rnd(seed+lane*53)*24,n=0;
  while(start<tr.total){const len=14+K.rnd(seed+lane*91+n*7)*64,end=Math.min(tr.total,start+len),upper=[],lower=[],shine=[],w=width*(.68+K.rnd(seed+lane*21+n)*.72);
   for(let k=0;k<=8;k++){const u=k/8,q=K.lerp(start,end,u),v=M.flowPoint(tr,q,off+Math.sin(q*.014+lane*.9)*width*.62),th=w*(.82+.17*Math.sin(u*Math.PI)+K.rnd(seed+n*73+lane*29+k)*.19);upper.push([v.x+v.nx*th*.5,v.y+v.ny*th*.5]);lower.push([v.x-v.nx*th*.5,v.y-v.ny*th*.5]);shine.push([v.x+v.nx*th*.24,v.y+v.ny*th*.24]);}
   const index=(lane+(K.rnd(seed+n*11+lane)>.82?1:0))%palette.length;K.line(c,upper.concat(lower.reverse()),null,1,true,palette[index]);if(n%3===1&&w>3){c.save();c.globalAlpha=.38;K.line(c,shine.slice(1,7),palette[Math.min(palette.length-1,index+1)],.72);c.restore();}start=end+2+K.rnd(seed+n*37+lane)*8;n++;
  }
 }
};
M.starryStreams=[['M-25 390 C198 305 290 460 505 401 C813 319 773 165 548 199 C346 230 356 361 530 356 C656 352 703 278 611 267 C566 263 535 288 568 305',7.8,8,317],['M790 474 C945 404 1059 477 1219 407 C1358 345 1314 273 1195 295 C1092 315 1115 381 1197 372 C1245 367 1255 340 1218 336',6.5,7,461]];
M.flowGlints=function(c,path,wheelAngle,width,lanes,seed){const tr=M.flowTrack(path);c.save();c.globalAlpha=.56;for(let j=0;j<9;j++){const start=((wheelAngle*31+j*tr.total/9+seed)%tr.total+tr.total)%tr.total,len=21+(j%3)*13,end=Math.min(tr.total,start+len),off=(j%lanes-(lanes-1)*.5)*width*.88,pts=[];for(let k=0;k<=8;k++){const p=M.flowPoint(tr,K.lerp(start,end,k/8),off+Math.sin(K.lerp(start,end,k/8)*.014+(j%lanes)*.9)*width*.62);pts.push([p.x,p.y]);}K.line(c,pts,j%3?'#f9d84f':'#fff1b3',j%3?1.7:2.5);}c.restore();};
// A brush-star borrows the physical front wheel, then lends its light to town.
// These are event-time functions, so a seek gives the same painting every time.
M.bezierPoint=function(a,b,c,d,u){const v=1-u;return{x:v*v*v*a.x+3*v*v*u*b.x+3*v*u*u*c.x+u*u*u*d.x,y:v*v*v*a.y+3*v*v*u*b.y+3*v*u*u*c.y+u*u*u*d.y};};
M.starryWheel=function(t,p){
 const s=p&&p.scale||1.12,tilt=p&&p.tilt||0,co=Math.cos(tilt),si=Math.sin(tilt),x=p&&Number.isFinite(p.x)?p.x:1600*t/6,y=p&&Number.isFinite(p.y)?p.y:751-102*s;
 const motion=p&&Number.isFinite(p.wheelAngle)?p:P.motionAt?P.motionAt(71+t):{wheelAngle:t*1600/6/(77*s)};
 const first=P.motionAt?P.motionAt(72.65).wheelAngle:1.65*1600/6/(77*s),angle=motion.wheelAngle-first-Math.PI/2,r=77*s;
 return{x:x+s*(150*co-25*si),y:y+s*(150*si+25*co),r,angle};
};
M.starryBeat=function(t,p){
 const home={x:735,y:196},clock={x:1100,y:573},contact=M.starryWheel(1.65),release=M.starryWheel(3.50),inlet={x:contact.x,y:contact.y-contact.r},outlet={x:release.x+Math.cos(release.angle)*release.r,y:release.y+Math.sin(release.angle)*release.r};
 if(t<.75)return{...home,stage:'sky',r:11};
 if(t<1.65){const u=K.smoother((t-.75)/.90);return{...M.bezierPoint(home,{x:794,y:291},{x:432,y:439},inlet,u),stage:'fall',r:11+4*Math.sin(u*Math.PI)};}
 if(t<3.50){const w=M.starryWheel(t,p);return{x:w.x+Math.cos(w.angle)*w.r,y:w.y+Math.sin(w.angle)*w.r,stage:'wheel',r:14,wheel:w};}
 if(t<3.86){const u=K.smoother((t-3.50)/.36);return{...M.bezierPoint(outlet,{x:outlet.x+32,y:outlet.y-53},{x:1118,y:533},clock,u),stage:'clock-flight',r:14-3*u};}
 if(t<4.24)return{...clock,stage:'clock',r:11};
 if(t<5.34){const u=K.smoother((t-4.24)/1.10);return{...M.bezierPoint(clock,{x:1181,y:399},{x:984,y:133},home,u),stage:'return',r:11};}
 return{...home,stage:'sky',r:11};
};
M.starryBrushStar=function(c,x,y,r,turn=0){
 c.save();c.translate(x,y);c.rotate(turn);K.circle(c,0,0,r*1.9,'rgba(240,212,80,.10)');
 for(let j=0;j<7;j++){const a=j*Math.PI*2/7;K.path(c,`M${Math.cos(a)*(r+5)} ${Math.sin(a)*(r+5)} q${Math.cos(a+.5)*6} ${Math.sin(a+.5)*6} ${Math.cos(a+1)*5} ${Math.sin(a+1)*5}`,null,j%2?'#b8cda0':'#edcd50',2.4);}
 K.ellipse(c,0,0,r,r*.9,'#e8bd36');K.path(c,`M${-r*.62} ${r*.22} Q${-r*.7} ${-r*.73} ${r*.43} ${-r*.54}`,null,'#ffe788',Math.max(2,r*.28));K.circle(c,-1,-1,r*.30,'#fff3bd');c.restore();
};
M.starryAction=function(c,t,p,front=false){
 const q=M.starryBeat(t,p);
 if(front){
  if(q.stage==='wheel'){const w=q.wheel;c.save();c.lineCap='round';for(let j=0;j<3;j++){c.beginPath();c.arc(w.x,w.y,w.r+j-1,w.angle-.85-j*.10,w.angle-.08);c.strokeStyle=['#c6942d','#ffe279','#b2d2bd'][j];c.lineWidth=j===1?4:1.25;c.stroke();}c.restore();}
  if(q.stage!=='clock')M.starryBrushStar(c,q.x,q.y,q.r,q.stage==='wheel'?q.wheel.angle*.12:0);
  return;
 }
 if(['fall','clock-flight','return'].includes(q.stage)){
  const pts=[];for(let j=0;j<=15;j++){const s=Math.max(t-.19+j*.19/15,0),v=M.starryBeat(s);pts.push([v.x,v.y]);}K.line(c,pts,'#466e9a',10);K.line(c,pts,'#e4ca58',4.8);K.line(c,pts.map(([x,y])=>[x+1,y-1]),'#fff0ad',1.3);
 }
 // The receiver is a clock, not a particle burst. Its hands complete one turn.
 const wind=K.ease((t-3.86)/.52),turn=wind*Math.PI*2,pulse=Math.sin(Math.PI*K.clamp((t-3.70)/.90));
 if(t>3.64){K.circle(c,1100,573,13+Math.max(0,pulse)*14,'rgba(244,214,79,.16)');K.circle(c,1100,573,10,'#e7cb5b','#7197af',1);K.circle(c,1100,573,7.5,null,'#356297',.7);c.save();c.translate(1100,573);c.rotate(turn);K.line(c,[[0,-6],[0,0],[5,3]],'#15356d',1.3);c.restore();if(q.stage==='clock')M.starryBrushStar(c,1100,573,7.8,turn*.3);}
};
// Projected bill-tip uses the same head pivot, lean, slope and wall projection
// as drawRider; the cord can meet it without an invented human hand.
M.silentShadow=function(t,a){
 const stopped=Math.min(t,3.55),ahead=K.ease((stopped-.7)/.9)*(1-K.ease((stopped-3.6)/1.2)),sx=762+stopped*60+ahead*36,sp=M.groundPose(sx,.95,x=>784-(x-420)*.324),at=a-t+stopped+.25,motion=P.motionAt?P.motionAt(at):{},pull=K.ease((t-3.62)/.36),headNod=-.08-ahead*.05+pull*.24,brakeLean=.08+ahead*.12;
 const phase=Number.isFinite(motion.crankAngle)?motion.crankAngle:(motion.phaseTime||0)*Math.PI*2,theta=Math.sin(phase)*.014+headNod,bob=Math.sin(phase)*1.8,dx=219,dy=-81+bob;
 let lx=-18+dx*Math.cos(theta)-dy*Math.sin(theta),ly=-160+dx*Math.sin(theta)+dy*Math.cos(theta);lx+=K.clamp(brakeLean)*.16*(ly+112);
 const co=Math.cos(sp.tilt),si=Math.sin(sp.tilt),px=sp.x+sp.scale*(lx*co-ly*si),py=sp.y+sp.scale*(lx*si+ly*co),foot=sp.y+102*sp.scale;
 return{sp,at,motion,headNod,brakeLean,foot,beak:{x:px-.095*(py-foot),y:foot+1.20*(py-foot)},off:K.ease((t-3.98)/.12)};
};
M.silentCord=function(c,t,a,data){
 const rest=M.silentShadow(3.55,a-t+3.55).beak,anchor={x:rest.x+4,y:72};let end={x:rest.x+4,y:rest.y};
 if(t>=3.55&&t<4.10)end={x:data.beak.x+4,y:data.beak.y};
 else if(t>=4.10){const pulled=M.silentShadow(4.10,a-t+4.10).beak,u=t-4.10,decay=Math.exp(-u*3.0);end={x:rest.x+4+(pulled.x-rest.x)*decay+Math.sin(u*10)*12*decay,y:rest.y+(pulled.y-rest.y)*decay};}
 K.path(c,`M${anchor.x} ${anchor.y} Q${anchor.x-4} ${(anchor.y+end.y)*.5} ${end.x} ${end.y-7}`,null,'#d4ccb0',2);K.path(c,`M${anchor.x+1.3} ${anchor.y} Q${anchor.x-2.7} ${(anchor.y+end.y)*.5} ${end.x+1.3} ${end.y-7}`,null,'#515e59',.7);
 K.circle(c,end.x,end.y,7,null,'#d5ccb0',2.1);K.circle(c,end.x,end.y,4.3,null,'#5d6860',.8);
 M.round(c,anchor.x-15,anchor.y-24,30,26,4,'#515e58','#b7b99c',1.3);K.circle(c,anchor.x,anchor.y-11,5,data.off>.9?'#8fc997':'#e3c77d','#293b36',1);
 K.line(c,[[anchor.x,anchor.y-24],[anchor.x,40],[1516,40],[1516,596]],'#343f3a',3);K.line(c,[[anchor.x,anchor.y-24],[anchor.x,40],[1516,40],[1516,596]],'#8c9c86',.8);
 if(t>4.12){const u=K.clamp((t-4.12)/1.25),route=[[anchor.x,anchor.y-24],[anchor.x,40],[1516,40],[1516,596]];M.tracePortion(c,[route],Math.max(0,u-.09),u,'#8fd4a1',2.2);if(u>=1){K.circle(c,1516,596,5,'#a3dfae');K.circle(c,1516,596,10,'rgba(145,231,167,.13)');}}
};
M.nightCypress=function(c,sway){c.save();c.translate(108,790);c.rotate(sway);c.translate(-108,-790);
 K.path(c,'M40 789 C69 711 40 657 64 596 C34 541 63 494 87 461 C64 411 93 344 106 274 C125 327 155 375 142 424 C174 466 151 504 169 550 C200 594 161 645 178 691 L207 790Z','#081c29','#283c31',2.3);
 const limbs=[[70,761,93,642,74,585],[100,768,121,618,111,530],[131,773,151,641,150,566],[82,591,110,467,96,418],[119,566,140,441,125,367],[97,442,108,357,106,293]];
 for(const [x,y,cx,cy,ex,ey]of limbs)for(let j=0;j<4;j++)K.path(c,`M${x+j*5} ${y} Q${cx+j*3} ${cy} ${ex+j*2} ${ey}`,null,['#163932','#314c33','#3d4831','#16323c'][j],2.1+j%2*.9);
 for(let k=0;k<17;k++){let yy=381+k*23,x=90+Math.sin(k*.75)*22;K.path(c,`M${x-14} ${yy+23} q5 -22 16 -36 M${x+8} ${yy+19} q9 -15 13 -29`,null,k%3?'#385739':'#675439',1.3);}K.path(c,'M108 301 C118 382 88 420 103 473 Q72 545 87 606 C62 682 89 723 68 780',null,'#6b5030',1.7);c.restore();
};
M.woodWave=function(c,x,y,s=1,flip=1){c.save();c.translate(x,y);c.scale(s*flip,s);
 const body='M-168 42 C-112 32 -75 7 -37 -39 C-4 -82 30 -136 76 -145 C124 -157 166 -130 172 -92 C174 -77 170 -65 166 -57 C154 -91 127 -109 105 -98 C66 -81 64 -29 22 6 C63 -13 105 -30 147 -17 C179 -7 210 19 224 48 L224 66 L-168 66Z';
 K.path(c,body,'#155883','#153953',2.6);c.save();c.clip(new Path2D(body));
 for(let j=0;j<10;j++)K.path(c,`M-178 ${47+j*5} C-73 ${24+j*5} -25 ${-62+j*5} 39 ${-102+j*8} C85 ${-140+j*8} 135 ${-129+j*7} 161 ${-79+j*6}`,null,j%2?'#cbded9':'#498ba9',1.1);
 for(let j=0;j<5;j++)K.path(c,`M-30 ${40+j*6} C55 ${-7+j*8} 128 ${2+j*8} 230 ${48+j*5}`,null,j%2?'#73adc0':'#e8e4c9',1.2);c.restore();
 K.path(c,'M-37 -39 C-3 -85 31 -141 75 -147 C116 -158 153 -138 168 -108 Q179 -81 166 -57 Q165 -81 150 -83 Q158 -98 140 -103 Q143 -118 125 -116 Q123 -132 108 -125 Q100 -141 88 -129 Q72 -139 65 -123 Q50 -129 44 -111 Q29 -114 27 -94 Q12 -97 9 -78 Q-7 -80 -12 -61 Q-28 -62 -37 -39Z','#f1e7cf','#28536b',1.55);
 for(const [xx,yy,dx,dy]of [[150,-106,10,20],[135,-122,6,19],[116,-132,-1,20],[96,-137,-9,22],[76,-133,-12,21],[57,-119,-13,19],[38,-101,-15,17],[20,-79,-14,15]])K.path(c,`M${xx} ${yy} q${dx} ${dy} ${dx-5} ${dy+7}`,null,'#fff0d3',3.1);
 for(let j=0;j<7;j++){let xx=-85+j*34,yy=56+Math.sin(j)*3;K.path(c,`M${xx} ${yy} q9 -5 25 -2`,null,'#f2ead1',1.5);}c.restore();
};
M.pixelSprite=function(c,rows,palette,x,y,size=4){for(let r=0;r<rows.length;r++)for(let q=0;q<rows[r].length;q++){const col=palette[rows[r][q]];if(col)K.rect(c,Math.round(x+q*size),Math.round(y+r*size),size,size,col);}};
M.pixelBrick=function(c,x,y,w=40,h=40){K.rect(c,x,y,w,h,'#763e2c');K.rect(c,x+2,y+2,w-4,h-4,'#bd6e3b');K.rect(c,x+4,y+4,w-8,3,'#edac68');K.rect(c,x+4,y+7,3,h-12,'#d58c4c');K.rect(c,x+3,y+h-6,w-6,3,'#904b2d');K.rect(c,x+w-6,y+7,3,h-13,'#a45430');K.rect(c,x+13,y+15,8,4,'#d38345');};
M.pixelChimeTower=function(c,x,y,w,h){const top=y-h;K.rect(c,x+8,top+25,10,h-25,'#376d73');K.rect(c,x+w-18,top+25,10,h-25,'#376d73');K.rect(c,x+11,top+29,3,h-32,'#b9d5b4');K.rect(c,x+w-15,top+29,3,h-32,'#b9d5b4');K.rect(c,x,top+20,w,8,'#365a68');K.rect(c,x+8,top+12,w-16,8,'#bd8554');K.rect(c,x+20,top+4,w-40,8,'#e1bb72');K.rect(c,x+4,y-6,w-8,6,'#4d7f77');for(let i=0;i<3;i++){const xx=x+24+i*(w-48)/2,yy=top+47+i%2*13;K.rect(c,xx-1,top+28,3,yy-top-28,'#557c75');K.rect(c,xx-5,yy,10,15,'#e9c579');K.rect(c,xx-8,yy+12,16,5,'#b17846');K.rect(c,xx-1,yy+17,3,5,'#f3df9a');}};
M.pixelBlockHit=2.6;
M.pixelBlockAnchor=function(){if(M.pixelAnchor)return M.pixelAnchor;const p=M.pixelPose(M.pixelBlockHit),motion=P.motionAt?P.motionAt(95+M.pixelBlockHit):{phaseTime:0},phase=motion.phaseTime*Math.PI*2,bob=Math.sin(phase)*1.8,head=Math.sin(phase)*.014+p.headNod,x0=19+18,y0=-302+160+bob,lx=-18+x0*Math.cos(head)-y0*Math.sin(head),ly=-160+x0*Math.sin(head)+y0*Math.cos(head);M.pixelAnchor={x:Math.round((p.x+p.scale*(lx*Math.cos(p.tilt)-ly*Math.sin(p.tilt)))/2)*2,y:Math.round((p.y+p.scale*(lx*Math.sin(p.tilt)+ly*Math.cos(p.tilt))+2)/2)*2};return M.pixelAnchor;};
M.pixelRelay=function(c,x,y,used){K.rect(c,x,y,48,48,'#315463');K.rect(c,x+4,y+4,40,40,used?'#6d8e8b':'#7fbca5');K.rect(c,x+5,y+5,38,4,used?'#abc6ac':'#ddedba');K.rect(c,x+5,y+9,4,32,'#b7d7b0');K.rect(c,x+40,y+9,4,35,'#467779');K.rect(c,x+9,y+40,31,4,'#41646d');for(const [xx,yy]of [[x+7,y+8],[x+37,y+8],[x+7,y+36],[x+37,y+36]])K.rect(c,xx,yy,3,3,'#d6bf7e');if(!used)M.pixelSprite(c,['..#..','#####','#.#.#','#.#.#','#...#','.....'],{'#':'#fff1b0'},x+14,y+12,4);else{K.rect(c,x+17,y+18,14,12,'#455f69');K.rect(c,x+20,y+21,8,6,'#e4d395');}};
M.pixelSeedLantern=function(c,x,y,size=2){M.pixelSprite(c,['......kk......','.....kwwk.....','....kgwwgk....','...kggwwggk...','..kgggwwgggk..','..kgggwwgggk..','...kggwwggk...','....kgwwgk....','.....kwwk.....','......kk......','.....kwwk.....','....kkkkkk....'],{g:'#76baad',w:'#f3d798',k:'#365b68'},x,y,size);};
M.pixelCourierDrone=function(c,x,y,t,size=3){const flap=Math.floor(t*6)%2;M.pixelSprite(c,[flap?'..ww........ww..':'................',flap?'.wwww..kk..wwww.':'wwww...kk...wwww',flap?'..www.kaak.www..':'.wwww.kaak.wwww.','.....kaggaak....','....kaggwggak...','....kaggwggak...','.....kaaaak.....','......kkkk......','......k..k......'],{a:'#c58e54',g:'#78b7ad',w:'#f4dfaa',k:'#315765'},x,y,size);};

M.screamFigure=function(c,shock,notice,recover){
 c.save();c.translate(1217+shock*19,699-shock*11);c.rotate(-notice*.055+shock*.13+recover*.035);
 K.path(c,'M-65 114 C-52 56 -71 12 -52 -49 C-43 -81 -29 -111 -15 -120 L19 -122 C42 -111 57 -76 44 -38 C34 -3 65 53 60 114Z','#202a35','#182735',3.8);
 K.path(c,'M-56 109 C-38 51 -62 5 -42 -51 Q-31 -83 -15 -107 L-6 -73 C-24 -29 -21 14 -26 52 Q-19 81 -27 113Z','#3f3a3b');
 K.path(c,'M18 -105 Q46 -71 31 -34 C18 7 52 63 43 114 L21 113 C27 67 -6 37 2 -6 Q14 -53 18 -105Z','#253748');
 for(const [path,col,w]of [['M-49 106 C-34 54 -48 25 -37 -21 Q-26 -68 -15 -87','#785c42',2.6],['M-34 110 C-13 57 -32 35 -17 -9 Q-8 -43 -4 -66','#4a5660',3.4],['M-13 112 C10 74 -9 36 8 2 Q24 -43 22 -67','#a07746',2.1],['M9 112 Q28 62 23 27 Q16 3 32 -29','#495264',3.5],['M35 108 Q47 70 37 46','#866044',2.2]])K.path(c,path,null,col,w);
 K.path(c,'M-24 -119 Q-21 -92 -7 -81 Q11 -79 23 -106 L17 -132Z','#cba76d','#4c503b',1.6);
 c.save();c.translate(-8,-164);c.rotate(-notice*.07+shock*.05);
 const face='M-37 -63 C-35 -90 -12 -104 9 -96 C40 -91 54 -65 47 -31 C43 -3 25 8 20 40 C18 68 1 77 -13 62 C-26 46 -25 23 -37 4 C-53 -19 -53 -42 -37 -63Z';
 K.path(c,face,'#d9bd82','#514d36',3.2);K.path(c,'M-37 -63 Q-24 -84 -9 -86 Q-31 -60 -29 -35 C-34 -2 -15 9 -18 33 L-10 61 Q-26 38 -29 19 C-45 -6 -48 -40 -37 -63Z','#8c9261');K.path(c,'M9 -91 Q40 -80 43 -53 C43 -16 18 2 15 35 Q13 56 4 66 L14 61 Q27 27 28 9 C49 -18 55 -55 31 -79Z','#b49b67');
 K.path(c,'M-14 -83 Q6 -94 24 -73 Q32 -59 27 -44 Q7 -57 -12 -42 Q-31 -46 -25 -62Z','#ecd199');
 K.path(c,'M-34 -58 C-25 -76 -8 -77 2 -66 M4 -66 Q22 -77 34 -57',null,'#a6a267',3.6);K.path(c,'M-35 -56 Q-41 -20 -22 -2 Q-21 16 -12 21 M35 -50 Q41 -18 24 -4 Q20 13 17 24',null,'#7b8456',2.5);
 K.path(c,`M-29 -44 Q-20 ${-57-shock*4} -9 -44 Q-4 ${-33+shock*5} -14 -27 Q-28 -25 -29 -44Z`,'#3d473b');K.path(c,`M9 -45 Q20 ${-57-shock*3} 31 -44 Q34 ${-30+shock*4} 22 -27 Q9 -28 9 -45Z`,'#40483c');
 K.path(c,'M-25 -42 Q-19 -48 -13 -41 M13 -43 Q22 -49 28 -42',null,'#b0ad77',1.3);K.path(c,'M1 -40 Q-4 -22 -3 -12 L7 -6 L12 -14',null,'#6d754a',2.5);K.path(c,'M-10 -7 Q-5 -12 -1 -7 M8 -8 Q14 -11 17 -4',null,'#6b6c43',1.3);
 const mouth=17+shock*16-recover*11;K.ellipse(c,2,28,8.5+shock*4-recover*2,mouth,'#303c35','#7b7147',2);K.path(c,`M-7 ${28-mouth+2} Q1 ${24-mouth} 9 ${27-mouth+3}`,null,'#ddbc78',1.2);K.path(c,'M-13 46 Q-9 65 5 63 Q16 58 17 48',null,'#a69d61',1.8);K.path(c,'M-34 -73 Q-14 -97 13 -88',null,'#efcc8b',1.6);
 c.restore();
 const lift=-shock*6+recover*27;
 c.save();c.translate(shock*2,lift);K.path(c,'M-69 -17 C-66 -60 -63 -112 -54 -146 C-50 -164 -53 -189 -45 -210 Q-41 -219 -36 -209 L-37 -180 Q-36 -158 -42 -137 C-49 -104 -44 -61 -51 -21 Q-57 -3 -69 -17Z','#d5b57c','#57573e',2.2);K.path(c,'M-62 -19 C-57 -62 -58 -113 -48 -144 Q-41 -175 -42 -202',null,'#e5c48d',3);K.path(c,'M-46 -182 Q-42 -169 -44 -156 M-55 -105 Q-57 -70 -55 -51',null,'#9f9462',1.1);c.restore();
 c.save();c.translate(-shock*2,lift+3);K.path(c,'M46 -17 C42 -69 47 -103 42 -137 C39 -155 34 -176 39 -204 Q43 -216 48 -208 L54 -166 C62 -134 61 -94 61 -58 L61 -21 Q56 -7 46 -17Z','#ceb17c','#58583f',2.2);K.path(c,'M52 -21 Q50 -77 54 -108 Q53 -155 44 -201',null,'#e4c18b',3);K.path(c,'M43 -185 Q44 -166 49 -152 M57 -99 L56 -58',null,'#928c5f',1.1);c.restore();
 c.restore();
};
// These cel clocks follow the existing bell and bow beats. The sprites carry
// actual articulated poses; their common floor/shoulder anchors do not bob.
M.screamCel=function(t){
 if(t<1.65)return 0;
 if(t<2.35)return Math.round(3*K.ease((t-1.65)/.7));
 if(t<2.58)return Math.round(4+4*K.ease((t-2.35)/.23));
 if(t<3.55)return Math.round(9+2*K.ease((t-2.58)/.97));
 return Math.round(12+3*K.ease((t-3.55)/1.25));
};
M.ukiyoTravellerCel=function(t,i){
 const noticeAt=1.75+i*.18,bowAt=2.5+i*.1;
 if(t<noticeAt)return 0;
 if(t<bowAt)return Math.round(3*K.ease((t-noticeAt)/.55));
 return Math.round(3+12*K.ease((t-bowAt)/1.15));
};
M.ukiyoRainAmount=function(t){return K.ease((t-.7)/1)*(.25+.75*K.ease((t-1.7)/1.3))*(1-K.ease((t-4.7)/.8));};
M.ukiyoPuddles=[[644,742,48,5],[952,742,65,6],[1110,783,38,5],[1391,802,53,7],[333,806,61,7],[547,861,73,9],[1060,853,84,10]];
M.ukiyoWeather=function(c,t,front=false,rider=null){
 const rain=M.ukiyoRainAmount(t),wet=K.ease((t-1.05)/1.8)*(1-.45*K.ease((t-5.15)/.85));
 if(!front){
  if(rain>.001){
   // Thin rear rain lies behind Fuji and the teahouse. The mountain silhouette
   // stays a clean block of ink, rather than receiving a full-screen filter.
   c.save();c.globalAlpha=rain*.33;c.lineCap='round';
   const rear=new Path2D('M0 118 L1600 118 L1600 651 L968 648 L885 692 L248 690 L0 690Z M521 550 L678 438 L809 359 L904 292 L1021 217 L1126 304 L1247 397 L1384 550Z');c.clip(rear,'evenodd');
   c.clip(new Path2D('M0 0 L1600 0 L1600 900 L0 900Z M244 481 L576 481 L576 681 L244 681Z'),'evenodd');
   for(let j=0;j<178;j++){
    const seed=j*31+367,fall=(K.rnd(seed+1)*548+t*(175+K.rnd(seed+2)*75))%548,x=-70+((K.rnd(seed)*1740-fall*.34+1740)%1740),y=112+fall,len=10+K.rnd(seed+3)*11;
    K.line(c,[[x,y],[x-len*.34,y+len]],j%3?'#446d79':'#e1e8d0',.55+(j%4)*.08);
   }
   c.restore();
  }
  // Broken woodblock reflections and very flat rings belong to the road plane.
  if(wet>.001)for(let j=0;j<M.ukiyoPuddles.length;j++){
   const[x,y,rx,ry]=M.ukiyoPuddles[j];c.save();c.globalAlpha=wet*.24;
   K.path(c,`M${x-rx} ${y} Q${x-rx*.58} ${y-ry*.7} ${x-rx*.1} ${y-ry} Q${x+rx*.6} ${y-ry*.65} ${x+rx} ${y} Q${x+rx*.48} ${y+ry*.55} ${x-rx*.3} ${y+ry} Q${x-rx*.82} ${y+ry*.4} ${x-rx} ${y}Z`,'#76978e');
   K.path(c,`M${x-rx*.76} ${y-1} Q${x-rx*.19} ${y-ry*.55} ${x+rx*.66} ${y-1}`,null,'#f5ecd0',1);
   c.restore();
   if(rain>.001)for(let k=0;k<3;k++){
    const u=(t*(1.4+k*.17)+j*.213+k*.31)%1,px=x+(k-1)*rx*.48,py=y+(k%2?1:-1)*ry*.13;
    c.save();c.globalAlpha=rain*(1-u)*.48;K.ellipse(c,px,py,2+u*(8+ry),.6+u*ry*.42,null,k%2?'#476e6c':'#eee8c8',.8);c.restore();
   }
  }
  return;
 }
 if(rain<=.001)return;
 // A few longer, thicker foreground cuts establish distance. Their own scene
 // clip is supplied by roomPass, and the travellers' faces remain unobscured.
 c.save();c.globalAlpha=rain*.46;c.lineCap='round';
 for(let j=0;j<54;j++){
  const seed=j*43+1013,fall=(K.rnd(seed+1)*1040+t*(390+K.rnd(seed+2)*115))%1040,x=-70+((K.rnd(seed)*1740-fall*.36+1740)%1740),y=-70+fall,len=19+K.rnd(seed+3)*18;
  if(x>1080&&x-len*.36<1364&&y<746&&y+len>563)continue;
  K.line(c,[[x,y],[x-len*.36,y+len]],j%4?'#dce5c7':'#294f61',1.15+(j%3)*.28);
 }
 c.restore();
 // Contact splashes originate at the actual moving wheel circumferences.
 if(rider){const a=rider.tilt||0,co=Math.cos(a),si=Math.sin(a),s=rider.scale;
  for(const wheel of [-130,150]){
   const wx=rider.x+s*(wheel*co-25*si),wy=rider.y+s*(wheel*si+25*co+77);
   if(!M.ukiyoPuddles.some(([x,y,rx])=>Math.abs(wx-x)<rx*.76&&Math.abs(wy-y)<10))continue;
   const u=(t*3.8+(wheel<0?.4:0))%1;c.save();c.globalAlpha=rain*(1-u)*.66;
   K.path(c,`M${wx-8} ${wy+2} Q${wx-17-u*9} ${wy-7-u*5} ${wx-24-u*12} ${wy+1} M${wx+5} ${wy+2} Q${wx+11+u*7} ${wy-5-u*4} ${wx+20+u*9} ${wy+3}`,null,'#e9e6c9',1.3);
   K.ellipse(c,wx,wy+3,7+u*13,1.3+u*1.8,null,'#477775',1);c.restore();
  }
 }
};
M.screamResonance=function(c,t){
 if(t<2.35||t>3.62)return;
 // The bell's response travels through the boards and out onto the fjord.
 // This is painted motion in the environment, separate from the critic cels.
 c.save();c.clip(new Path2D('M0 900 L0 590 L600 428 L1300 900Z'));
 for(let j=0;j<3;j++){
  const u=(t-2.35-j*.11)/.92;if(u<0||u>1)continue;
  const rx=12+u*435,ry=4+u*115,points=[];
  for(let k=0;k<=48;k++){const a=k*Math.PI/24;points.push([1195+Math.cos(a)*rx,860+Math.sin(a)*ry+Math.sin(a*3+j)*3*(1-u)]);}
  c.save();c.globalAlpha=(1-u)*.56;K.line(c,points,j%2?'#77553b':'#e9b76e',2.1-j*.25);c.restore();
 }
 c.restore();
 for(let j=0;j<3;j++){
  const u=(t-2.43-j*.09)/.8;if(u<0||u>1)continue;
  const x=1313+u*70,y=593+j*42,w=26+u*130;c.save();c.globalAlpha=(1-u)*.52;
  K.path(c,`M${x-w} ${y+8} C${x-w*.34} ${y-12-u*7} ${x+w*.38} ${y+25+u*8} ${x+w} ${y+5}`,null,j%2?'#b2ac71':'#718b79',2.5-j*.3);c.restore();
 }
};
P.scenes[10]={title:'浮世绘',en:'THE FLOATING WORLD',date:'1830s',style:10,dark:false,accent:'#bb4338',
 draw(c,t){M.bg(c,'ukiyo-r8-sunshower',d=>{
 K.rect(d,0,0,1600,900,'#f0e5ca');K.rect(d,0,0,1600,525,K.gradient(d,[0,0],[0,525],[[0,'#4c88a7'],[.55,'#b4cdd1'],[1,'#eee2c6']]));
 for(const [x,y,w]of [[178,224,204],[469,189,157],[1164,343,271]]){K.path(d,`M${x-w*.5} ${y} Q${x-w*.23} ${y-9} ${x} ${y-6} Q${x+w*.22} ${y-14} ${x+w*.5} ${y-6}`,null,'#d4ddc6',2);K.path(d,`M${x-w*.41} ${y+7} Q${x} ${y+2} ${x+w*.38} ${y+5}`,null,'#a7bdaf',.8);}
 K.circle(d,1272,204,68,'#c74b31');for(let j=0;j<6;j++)K.line(d,[[1232-j*2,176+j*10],[1291+j*5,176+j*10]],'rgba(231,161,119,.15)',.9);
 K.path(d,'M521 550 L678 438 L809 359 L904 292 L1021 217 L1126 304 L1247 397 L1384 550Z','#4981a1','#214f6b',2.3);
 K.path(d,'M1021 219 L1046 310 L1095 385 L1116 464 L1181 550 L1072 550 L1042 440 L994 364 L1005 278Z','#77a0b1');K.path(d,'M806 366 L926 306 L899 373 L856 431 L814 493 L747 550 L670 550Z','#3e7197');K.path(d,'M1102 311 L1121 371 L1193 440 L1238 550 L1323 550 L1250 427Z','#2c6087');
 K.path(d,'M899 300 L1021 217 L1130 315 L1083 300 L1053 319 L1024 281 L1008 300 L989 284 L971 315 L950 297 L930 319Z','#fff1d8','#6e8490',1.3);
 for(const a of [[943,319,891,414,837,483],[1013,309,987,381,1003,468],[1052,334,1077,403,1101,471],[1115,340,1170,421,1226,497],[889,358,847,416,781,492]]){const[x,y,cx,cy,ex,ey]=a;K.path(d,`M${x} ${y} Q${cx} ${cy} ${ex} ${ey}`,null,'#b3c3bd',1.1);K.path(d,`M${x+7} ${y+11} Q${cx+10} ${cy+9} ${ex+10} ${ey+7}`,null,'#536f7e',.75);}
 K.path(d,'M0 577 Q139 489 259 540 Q329 553 420 522 Q535 503 690 572 Q790 610 950 574 L985 682 L0 706Z','#285c61','#3b5d60',1.3);
 for(let j=0;j<7;j++)K.path(d,`M${22+j*5} ${582+j*8} Q210 ${535+j*9} 365 ${565+j*9} Q565 ${525+j*13} 825 ${593+j*9}`,null,j%2?'#779486':'#9eaf91',.9);
 K.path(d,'M934 503 Q1205 470 1600 518 L1600 650 Q1312 607 981 651Z','#98c4c8','#396e88',1.4);
 for(let row=0;row<12;row++){const y=514+row*10;for(let col=0;col<7;col++){let x=971+col*97+(row%2)*24,w=40+(col*13+row*7)%47;K.path(d,`M${x} ${y} q${w*.27} ${-3-row*.1} ${w} 0`,null,row%3?'#dce0c3':'#678f8a',.8+row*.025);if(row>5)K.path(d,`M${x+6} ${y+3} q${w*.3} 3 ${w*.7} 0`,null,'#8aa9a0',.65);}}
 // Near water is cut into indigo ridges and hooked foam; distant water stays pale.
 K.path(d,'M935 599 Q1108 574 1241 597 Q1427 612 1600 585 L1600 649 Q1379 625 1210 644 L968 648Z','#72a8b9','#356a82',1.1);
 for(let j=0;j<5;j++){let yy=611+j*7;K.path(d,`M954 ${yy} C1101 ${yy-22} 1183 ${yy+12} 1310 ${yy-4} C1437 ${yy-20} 1503 ${yy+9} 1620 ${yy-12}`,null,j%2?'#ced9bd':'#205d82',1.1);}
 M.woodWave(d,1089,579,.63,1);M.woodWave(d,1370,582,.83,1);M.woodWave(d,1569,604,.58,1);
 K.path(d,'M601 518 Q823 476 972 511 Q1107 499 1285 521 L1285 540 Q1098 518 976 535 Q804 509 601 539Z','rgba(204,211,181,.36)');
 K.path(d,'M219 636 Q447 535 748 591 Q888 607 1038 671 L885 746 L248 703Z','#bfc08c','#6a805f',1.4);
 for(let row=0;row<7;row++){let y=574+row*15;K.path(d,`M${270-row*5} ${y+52} Q493 ${y-5} ${870+row*21} ${y+50}`,null,row%2?'#899c70':'#dce0ac',1.5);}
 for(let j=0;j<8;j++){let x=334+j*73;K.path(d,`M${x} ${600+Math.sin(j)*9} Q${x-21} 638 ${x-25} 671`,null,'#6d875f',.8);}
 for(const [x,y,sc]of [[1180,548,.86],[1330,518,.67],[1466,558,.92]]){d.save();d.translate(x,y);d.scale(sc,sc);K.path(d,'M-35 0 Q-7 12 34 0 L26 10 Q-2 21 -26 10Z','#526f6b','#32565b',1);K.line(d,[[-26,6],[24,6]],'#ced1ac',1);for(let j=0;j<5;j++)K.line(d,[[-19+j*9,6],[-16+j*8,13]],'#859b82',.65);K.line(d,[[0,7],[0,-49]],'#435e58',1.4);K.path(d,'M3 -48 Q19 -29 29 -8 L3 -6Z','#e6dfbe','#5a7975',1);for(let j=1;j<5;j++)K.path(d,`M3 ${-47+j*8} Q${4+j*4} ${-42+j*8} ${6+j*4} ${-41+j*8}`,null,'#b5c0a5',.6);K.path(d,'M-39 17 Q-10 20 36 15',null,'#dce1c2',1);d.restore();}
 K.path(d,'M0 690 Q388 649 746 682 Q1092 730 1600 688 L1600 900 L0 900Z','#dec18a','#697558',1.6);
 K.path(d,'M0 797 Q389 746 810 780 Q1181 804 1600 765',null,'#b7a578',1.6);K.path(d,'M0 810 Q375 757 808 792 Q1194 815 1600 778',null,'#e5d4a2',1.1);
 for(let g=0;g<18;g++){let x=73+g*86,y=796+(g%4)*21;for(let j=0;j<3;j++)K.path(d,`M${x+j*8} ${y+j*2} q8 -2 ${13+j*3} -1`,null,g%3?'#a6986e':'#b7a273',.75);}
 M.teaHouse(d,289,652,.99);
 K.path(d,'M0 781 Q99 731 215 763 L262 900 L0 900Z','#7a8054','#536443',1.7);
 for(let i=0;i<19;i++){let x=17+i*11,y=784+(i%5)*18;K.path(d,`M${x} ${y+15} q1 -14 7 -21 M${x} ${y+13} q-3 -10 -9 -13 M${x+3} ${y+11} q8 -10 11 -9`,null,i%2?'#a8ae75':'#4b6547',.9);}
 K.path(d,'M1350 778 Q1479 739 1600 759 L1600 900 L1429 900Z','#9da374','#687b52',1.3);for(let i=0;i<15;i++){let x=1458+i*11,y=801+(i%4)*17;K.path(d,`M${x} ${y+14} l4 -16 l3 7 M${x+3} ${y+6} l-8 -10`,null,'#60784f',.8);}
 M.frame(d,34,32,1532,836,'#526b67',1.3);M.frame(d,40,38,1520,824,'rgba(223,227,193,.6)',.7);
 });
 M.ukiyoWeather(c,t,false);
 // Footfalls stop one after another; faces follow the bell, then the nearest traveller bows.
 const travellerReady=P.hasCharacterAsset&&P.hasCharacterAsset('ukiyo_traveller');
 for(let i=0;i<3;i++){
  const react=K.ease((t-1.75-i*.18)/.55),bow=Math.sin(K.clamp((t-2.5-i*.1)/1.15)*Math.PI),step=(1-react)*Math.sin(t*5+i),x=1128+i*74+react*(i-1)*12;
  const y=(P.hasArtAsset&&P.hasArtAsset(10)?P.scenes[10].ground(x)-15:735)-i*5,scale=1.04-i*.035;
  if(travellerReady)P.drawCharacter(c,'ukiyo_traveller',t,{x,y,height:112*scale,frame:M.ukiyoTravellerCel(t,i)});
  else M.traveller(c,x,y,scale,1-2*react,bow,['#2c697b','#ae6a3c','#2a526b'][i],step);
 }
 // A tea-shop banner and a little migration of swallows share the same wind.
 if(!(P.hasArtAsset&&P.hasArtAsset(10))){const flutter=Math.sin(t*3)*7;K.path(c,`M541 600 Q${554+flutter} 609 541 619`,null,'#ae5141',3);}
 for(let j=0;j<3;j++){let x=1050+j*37+t*14,y=364+j*10;K.path(c,`M${x-9} ${y-3} Q${x-3} ${y-7-Math.sin(t*8+j)*3} ${x} ${y} Q${x+4} ${y-6} ${x+12} ${y-1}`,null,'#4e7073',1.7);}
 if(t>2.9&&t<4.8){c.save();c.globalAlpha=K.ease((t-2.9)/.3)*K.ease((4.8-t)/.3);K.rect(c,1124,578,232,36,'#e8e2c8','#6b8174',.75);K.line(c,[[1128,581],[1352,581]],'#faf0d1',.65);K.text(c,'お先にどうぞ。',1240,605,22,'#374f50','center','serif');c.restore();}
 },pose(t){const bell=Math.sin(K.clamp((t-2.05)/.45)*Math.PI),p=P.hasArtAsset&&P.hasArtAsset(10)?M.groundPose(720+t*26,1.08,P.scenes[10].ground):{x:720+t*26,y:625+Math.sin(t*.5)*3,scale:1.08};return Object.assign(p,{style:10,gazeX:1,headNod:Math.sin(K.clamp((t-2.6)/.7)*Math.PI)*.09,bellPress:bell});},
 foreground(c,t,a,p){
  const wind=.23*Math.sin(t*.8)+M.ukiyoRainAmount(t)*(-1.1+Math.sin(t*2.2)*1.15+Math.sin(t*4.3)*.35);
  M.woodPine(c,126,726,1.29,1,wind);M.woodPine(c,1513,716,.93,-1,-wind*.83);
  M.ukiyoWeather(c,t,true,p);
 },
 ground(x){return P.hasArtAsset&&P.hasArtAsset(10)?815-65*K.ease((x-850)/750):735+8*Math.sin((x-260)/620);},roadColor:'#d4bb83',roadInk:'#776e51'

};
P.scenes[11]={title:'星月夜',en:'A SKY THAT PEDALS',date:'1889',style:11,dark:true,accent:'#f4d65f',
 draw(c,t){M.bg(c,'starry-r7-borrowed-light',d=>{
 if(M.paintR7Night){M.paintR7Night(d)}else{
 K.rect(d,0,0,1600,900,'#092769');K.path(d,'M0 205 Q390 98 789 180 Q1210 239 1600 121 L1600 450 Q1189 511 824 425 Q420 349 0 467Z','#123f87');
 // Broad impasto marks bend with the sky's currents, with dark channels between them.
 for(let j=0;j<10;j++){let yy=48+j*50;const path=`M-45 ${yy} C199 ${yy-54-j%3*8} 389 ${yy+48} 581 ${yy+4} C808 ${yy-56} 1090 ${yy-31} 1645 ${yy+8}`;M.flowBrush(d,path,['#164590','#225cac','#2c6eb7','#387fae'],3.9,3,114+j*61);}
 for(const [path,w,n,seed]of M.starryStreams){K.path(d,path,null,'#18559b',w*n*1.2);M.flowBrush(d,path,['#19467f','#26639d','#4387ba','#70a9c4','#9ec4cb','#c1d4bf','#95b9c6','#3d81ad'],w,n,seed);}
 for(let k=0;k<22;k++){let x=21+k*76,y=520+17*Math.sin(k*.39);K.path(d,`M${x} ${y} q18 -11 44 -6`,null,k%3?'#3b81b3':'#a6bd8b',3.1);K.path(d,`M${x+2} ${y-2} q17 -8 28 -5`,null,'#e9d976',.85);}
 K.circle(d,1340,204,86,'#ddb739');K.circle(d,1340,204,77,'#f4d148');
 for(let j=0;j<11;j++)K.path(d,`M${1307-j*1.8} ${139+j*3.1} C${1253+j*1.6} ${176+j*4.7} ${1272+j*2.9} ${242-j*.4} ${1334+j*3.2} ${268-j*1.3}`,null,j%3?'#ffe67c':'#c59c2b',2.4+j%2*1.4);
 K.circle(d,1365,177,67,'#123f87');
 for(let i=0;i<22;i++){let a=i*Math.PI*2/22,r=96+(i%3)*5;K.path(d,`M${1340+Math.cos(a)*r} ${204+Math.sin(a)*r} Q${1340+Math.cos(a+.09)*(r+3)} ${204+Math.sin(a+.09)*(r+3)} ${1340+Math.cos(a+.19)*r} ${204+Math.sin(a+.19)*r}`,null,i%3?'#4598bf':'#d6d66a',2.2+i%3*.7);}
 }
 K.path(d,'M0 638 Q119 550 233 593 Q338 543 469 590 Q632 521 789 587 Q912 538 1065 592 Q1245 528 1410 580 Q1513 544 1600 591 L1600 771 L0 771Z','#13376d','#3b6a9a',1.5);
 for(let j=0;j<9;j++)K.path(d,`M0 ${632+j*7} Q165 ${586+j*8} 318 ${615+j*8} Q498 ${569+j*8} 709 ${626+j*6} Q940 ${591+j*7} 1191 ${626+j*6} T1600 ${609+j*6}`,null,['#22528b','#5085ad','#1e4788'][j%3],.95);
 M.nightWindows=[];for(let i=0;i<17;i++){let x=187+i*76,y=669+Math.sin(i*.71)*10,w=31+(i*13)%20,h=39+(i*17)%20;M.nightHouse(d,x,y,w,h,i,1);}
 for(let i=0;i<12;i++){let x=242+i*102,y=725+Math.sin(i*.68)*6,w=54+(i*11)%23,h=57+(i*13)%26;M.nightHouse(d,x,y,w,h,i+2,0);}
 // The church is an actual little building, with stone courses, tracery and a clock.
 K.path(d,'M1032 718 L1032 640 L1089 604 L1150 641 L1150 718Z','#244d86','#092752',1.4);K.path(d,'M1020 642 L1089 593 L1161 641 L1150 648 L1089 608 L1032 651Z','#102a56','#75a2bd',1.2);
 K.path(d,'M1081 647 L1084 540 L1099 507 L1115 541 L1119 647Z','#143773','#82a8b5',1.3);K.path(d,'M1080 542 L1099 477 L1119 542Z','#0b2155','#72978b',1.1);K.line(d,[[1099,479],[1099,463]],'#d6cf7c',1);K.line(d,[[1093,470],[1105,470]],'#d6cf7c',.8);
 K.circle(d,1100,573,10,'#e7cb5b','#7197af',1);K.circle(d,1100,573,7.5,null,'#356297',.7);K.line(d,[[1100,567],[1100,573],[1105,576]],'#15356d',1.3);
 for(let j=0;j<7;j++)K.line(d,[[1086,600+j*6],[1115,600+j*6]],'#4c77a0',.55);
 for(const x of [1049,1080,1124]){K.path(d,`M${x} 689 L${x} 662 Q${x+6} 651 ${x+12} 662 L${x+12} 689Z`,'#d8bb62','#0d2952',1);K.line(d,[[x+6,657],[x+6,688]],'#535b3c',.8);K.line(d,[[x,672],[x+12,672]],'#535b3c',.7);}
 K.path(d,'M1086 718 L1086 698 Q1098 684 1110 698 L1110 718Z','#102854','#7b9b9d',1);K.line(d,[[1098,694],[1098,717]],'#3b6799',.8);
 K.path(d,'M0 751 Q342 730 685 750 Q1064 728 1600 751 L1600 900 L0 900Z','#112d60');K.line(d,[[170,751],[1430,751]],'#8f9c6d',1);
 for(let j=0;j<8;j++)K.path(d,`M-20 ${776+j*18} Q376 ${751+j*18} 829 ${779+j*17} T1620 ${772+j*18}`,null,j%2?'#284b77':'#3a607a',.9);
 for(let g=0;g<25;g++){let x=27+g*65,y=782+(g%4)*24;for(let j=0;j<3;j++)K.path(d,`M${x+j*8} ${y+j*2} q10 -5 22 -4`,null,g%4?'#3e706d':'#94a466',.8);}
 });
 const motion=P.sceneContext&&P.sceneContext.rider||{},wheel=motion.wheelAngle||0,crank=(motion.phaseTime||0)*Math.PI*2;
 for(const [path,w,n,seed]of M.starryStreams)M.flowGlints(c,path,wheel,w,n,seed);
 M.starryAction(c,t,motion,false);
 for(const [i,x,y,r]of [[0,272,300,12],[1,450,461,15],[2,735,196,11],[3,912,252,13],[4,1165,192,10],[5,1450,395,15],[6,292,497,9]]){if(i===2)continue;let pulse=1+.025*Math.sin(crank+i);K.circle(c,x,y,r*2.6,'rgba(231,200,48,.11)');for(let ring=0;ring<3;ring++)for(let k=0;k<11;k++){const a=k*Math.PI*2/11+ring*.16+(i%3)*.07,rr=r+7+ring*6+(k%3-1)*1.2;K.path(c,`M${x+Math.cos(a)*rr} ${y+Math.sin(a)*rr} Q${x+Math.cos(a+.16)*(rr+2.8)} ${y+Math.sin(a+.16)*(rr+2.8)} ${x+Math.cos(a+.34)*rr} ${y+Math.sin(a+.34)*rr}`,null,['#edce4b','#c9d39a','#599cbc'][ring],ring===0?4.6:3.2);}K.ellipse(c,x,y,r*pulse,r*.92,'#e5bc35');K.path(c,`M${x-r*.5} ${y+r*.34} Q${x-r*.83} ${y-r*.69} ${x+r*.39} ${y-r*.59}`,null,'#ffe987',4.8);K.circle(c,x-1,y-1,r*.31,'#fff1b2');}

 // Light follows the rider through real windows, including their fixed muntins.
 for(let i=0;i<(M.nightWindows||[]).length;i++){const w=M.nightWindows[i],lit=K.ease((t-3.88-Math.abs(w.x-1100)/850)/.34);if(lit>0){c.save();c.globalAlpha=lit*(w.depth?.55:.92);K.rect(c,w.x-2,w.y-2,w.w+4,14,'rgba(244,201,80,.12)');K.rect(c,w.x,w.y,w.w,10,'#ffd561');K.line(c,[[w.x+w.w/2,w.y],[w.x+w.w/2,w.y+10]],'#6c672f',.65);K.line(c,[[w.x,w.y+5],[w.x+w.w,w.y+5]],'#6c672f',.65);c.restore();}}
 for(let j=0;j<3;j++){let x=1350+t*9+j*8,y=607-j*9;K.path(c,`M${x} ${y} q-10 -12 0 -24`,null,'rgba(147,171,157,.17)',1.4);}
 },pose(t){return{x:720+t*27,y:637,scale:1.12,style:11,gazeX:.45,gazeY:-.65,headNod:-.05,bellPress:Math.sin(K.clamp((t-1.35)/.45)*Math.PI)};},
 foreground(c,t,a,p){M.starryAction(c,t,p,true);const crank=(p.phaseTime||0)*Math.PI*2;M.nightCypress(c,Math.sin(crank)*.008);},
 ground(){return 751;},roadColor:'#112d60',roadInk:'#8f9c6d'
};
P.scenes[12]={title:'呐喊',en:'AN UNEXPECTED CRITIC',date:'1893',style:12,dark:false,accent:'#8c3829',
 draw(c,t){M.bg(c,'scream-r6-expression',d=>{
 K.rect(d,0,0,1600,900,'#df8a37');
 // Unequal, wavering ribbons compress toward the fjord, as if the sky is sounding.
 const skyColours=['#a63b2b','#d65b2d','#f0a146','#b7482c','#e47c32','#f5b956','#8c352d'];
 for(let band=0;band<12;band++){const top=[],bottom=[],mid=[];for(let x=-40;x<=1640;x+=24){const yy=17+band*43+52*Math.sin(x*.0039+.18+band*.12)+22*Math.sin(x*.0091+band*.18),th=27+9*Math.sin(x*.0047+band*.72)+band*.7;top.push([x,yy-th*.55]);bottom.push([x,yy+th*.55]);mid.push([x,yy-th*.28]);}K.line(d,top.concat(bottom.reverse()),null,1,true,skyColours[band%skyColours.length]);if(band%2===0)K.line(d,mid,'rgba(246,190,119,.43)',2.1);else K.line(d,top,'rgba(111,62,45,.31)',1.4);}
 K.path(d,'M-20 145 C159 96 310 195 471 168 C633 138 735 105 910 162 C1135 238 1333 143 1630 178',null,'#653537',3.7);
 K.path(d,'M-20 161 C159 113 310 210 473 185 C635 154 737 124 912 178 C1135 256 1333 162 1630 197',null,'#ffbd59',2.1);
 K.path(d,'M-25 345 C185 291 326 389 521 355 C742 310 908 426 1095 386 C1323 337 1462 389 1630 363',null,'#f0ac48',4.8);
 K.path(d,'M566 464 Q833 377 971 405 Q1137 352 1296 435 Q1474 487 1600 445 L1600 900 L684 900Z','#273e65','#20314d',2.7);
 K.path(d,'M792 461 Q975 395 1147 453 Q1348 520 1600 484 L1600 546 Q1417 571 1238 512 Q994 444 864 498Z','#93975f','#3f626a',1.2);
 d.save();d.clip(new Path2D('M566 464 Q833 377 971 405 Q1137 352 1296 435 Q1474 487 1600 445 L1600 900 L684 900Z'));for(let i=0;i<8;i++){let y=476+i*32;const path=`M${748+i*11} ${y} C${957+i*8} ${y-104} ${1203+i*9} ${y+18} 1620 ${y+23}`;K.path(d,path,null,['#a59f64','#1b3159','#c4ab63','#3c6875'][i%4],13+i%3*4);K.path(d,path,null,i%2?'#648b8b':'#d3ba75',1.6);}K.path(d,'M873 540 C1100 468 1287 592 1630 557',null,'#172a51',4);d.restore();

 K.path(d,'M1520 617 Q1477 603 1435 638 Q1460 687 1419 732 Q1457 785 1427 900 L1600 900 L1600 584Z','#264b48','#1a383b',1.8);K.path(d,'M1491 654 Q1488 710 1467 751 Q1499 815 1485 881',null,'#6f8765',2);
 for(const [x,y,sc]of [[1027,493,.7],[1158,516,.84],[1310,514,.59],[1422,544,.68]]){d.save();d.translate(x,y);d.scale(sc,sc);K.path(d,'M-25 0 Q0 12 27 0 L17 10 L-13 10Z','#294b52','#223e47',1);K.line(d,[[-18,4],[18,4]],'#a7a77e',.8);K.line(d,[[0,5],[2,-36]],'#304d54',1.5);K.path(d,'M4 -34 L21 -6 L4 -5Z','#ccb781','#536f69',.7);K.line(d,[[4,-20],[14,-17]],'#a49870',.6);K.path(d,'M-33 15 Q-5 19 29 12',null,'#a0ad8a',.9);d.restore();}
 K.path(d,'M0 900 L0 590 L600 428 L1300 900Z','#a86e41','#513e35',2.6);
 K.path(d,'M0 626 L581 470 L1210 900 L1258 900 L594 449 L0 607Z','#d29453');
 // Deck boards and their knots converge on the bridge instead of crossing the whole canvas.
 d.save();d.clip(new Path2D('M0 900 L0 590 L600 428 L1300 900Z'));
 for(let i=0;i<19;i++){let x=-140+i*86;K.line(d,[[x,902],[573+(x-600)*.11,448]],i%3?'#765e48':'#ccb080',1.05);}
 for(let row=0;row<9;row++){let y=528+row*row*5.8;K.path(d,`M-40 ${y+43} L${601+(y-428)*.88} ${y-11}`,null,'#685746',.8);}
 for(let j=0;j<28;j++){let x=80+(j*149)%1020,y=622+(j%5)*41;K.path(d,`M${x} ${y} q6 -11 11 -1 q-2 9 -8 4 M${x-5} ${y-18} q-2 -12 -4 -19 M${x+12} ${y+4} q4 11 6 25`,null,j%2?'rgba(92,74,54,.42)':'rgba(213,181,132,.5)',.7);}
 d.restore();
 // A rail has a top, a shaded underside, joined posts and iron fasteners.
 K.line(d,[[0,592],[612,431],[1372,900]],'#4c4036',9);K.line(d,[[0,588],[612,427],[1378,896]],'#e6a25c',2);K.line(d,[[0,641],[584,491],[1204,900]],'#ecad65',9);K.line(d,[[0,647],[582,497],[1199,902]],'#72563e',2);
 for(let i=0;i<9;i++){let u=i/8,x=53+u*565,y=578-u*146;K.line(d,[[x,y],[x-8,y+59]],'#5b4b3b',6);K.line(d,[[x-2,y],[x-10,y+57]],'#aa865d',1.3);K.circle(d,x,y+5,1.5,'#413d32');K.circle(d,x-6,y+50,1.2,'#413d32');}
 for(let i=1;i<6;i++){let x=612+i*122,y=431+i*75;K.line(d,[[x,y],[x-19,y+70]],'#69513c',7);K.line(d,[[x-2,y+1],[x-21,y+68]],'#c59b6c',1.4);K.circle(d,x-2,y+8,1.8,'#443d31');}
 // A narrow front board is the continuous route through the expressionist perspective.
 K.rect(d,230,747,1140,12,'#9d7e59');K.line(d,[[230,747],[1370,747]],'#d6b184',1.6);K.line(d,[[230,759],[1370,759]],'#655442',1.4);for(let i=0;i<26;i++){let x=243+i*43;K.line(d,[[x,750],[x+20,752]],'#b79a70',.7);if(i%3===0)K.circle(d,x+7,754,1,'#594d3d');}
 for(let i=0;i<15;i++){let x=1511+i*6,y=751+(i%3)*19;K.path(d,`M${x} ${y+38} Q${x-17} ${y+7} ${x-9} ${y-14} M${x-3} ${y+19} Q${x+16} ${y+4} ${x+18} ${y-9}`,null,i%3?'#859276':'#b0ae7e',.9);}
 });
 M.screamResonance(c,t);
 const echo=Math.sin(K.clamp((t-2.35)/1.2)*Math.PI);if(echo>0){c.save();c.globalAlpha=echo*.55;for(let j=0;j<3;j++){const yy=153+j*103,dy=echo*(9-j*2);K.path(c,`M-20 ${yy} C159 ${yy-49+dy} 310 ${yy+50-dy} 471 ${yy+23} C633 ${yy-7-dy} 735 ${yy-40+dy} 910 ${yy+17} C1135 ${yy+93-dy} 1333 ${yy-2+dy} 1630 ${yy+33}`,null,['#e9a34b','#a5362e','#ed9442'][j],4.8-j*.7);}c.restore();}
 // Anticipation → recoil → recovery. Hands travel to cheeks rather than popping between poses.
 const notice=K.ease((t-1.65)/.6),shock=K.ease((t-2.35)/.17)*(1-K.ease((t-3.55)/.7)),recover=K.ease((t-4)/.8);
 const walkerReady=P.hasCharacterAsset&&P.hasCharacterAsset('scream_walker');
 for(let i=0;i<2;i++){
  if(walkerReady){
   const stop=K.clamp((t-1.65)/.6),walkTime=Math.min(t,1.65)+.3*(1-(1-stop)**2),travel=walkTime*11;
   P.drawCharacter(c,'scream_walker',t,{x:228+i*65+travel,y:570-i*18-travel*.37,height:82*(.95-i*.1),frame:(Math.floor(walkTime*8)+i)%16});
  }else{
   c.save();c.translate(228+i*65,570-i*18);c.scale(.95-i*.1,.95-i*.1);K.path(c,'M-13 -52 Q1 -62 12 -49 L16 -15 L7 -11 L5 0 L-1 0 L-3 -16 L-10 -1 L-17 -1 L-12 -19Z','#213333','#4a4b39',1.3);K.ellipse(c,-1,-64,7,11,'#223737','#4d5140',1);K.path(c,'M-11 -70 Q-4 -83 5 -75 L9 -70 L13 -68 L-14 -66Z','#1b3032');K.path(c,'M-11 -45 L-16 -23 M10 -44 L14 -24 M-4 -47 L1 -19',null,'#4b5744',1.6);K.line(c,[[5-9*notice,-65],[7-9*notice,-64]],'#bfa879',1.5);c.restore();
  }
 }
 if(t>2.35&&t<3.4){c.save();c.globalAlpha=K.ease((t-2.35)/.2)*K.ease((3.4-t)/.3);M.caption(c,'叮。',1003,315,'#533d35');for(let j=0;j<3;j++)K.path(c,`M${1028+j*20} ${313-j*20} Q${1065+j*20} 345 ${1028+j*20} ${374+j*20}`,null,'#683d32',2.7);c.restore();}
 if(t>4.2)M.caption(c,'……',1361,434,'#3f4e44');
 },pose(t){const shock=Math.sin(K.clamp((t-2.35)/1.2)*Math.PI);return{x:630+t*28,y:637,scale:1.08,tilt:.015,style:12,expression:t>2.35&&t<3.6?'surprised':'calm',gazeX:1,gazeY:shock*.25,headNod:-shock*.08,bellPress:Math.sin(K.clamp((t-2.35)/.45)*Math.PI)};},
 foreground(c,t){
  // The critic's feet stand on the near bridge, below the cyclist's route.
  // During the departure the bicycle therefore passes behind the whole figure.
  if(P.hasCharacterAsset&&P.hasCharacterAsset('scream_figure'))P.drawCharacter(c,'scream_figure',t,{x:1195,y:860,height:420,frame:M.screamCel(t)});
  else{
   const notice=K.ease((t-1.65)/.6),shock=K.ease((t-2.35)/.17)*(1-K.ease((t-3.55)/.7)),recover=K.ease((t-4)/.8);
   c.save();c.translate(1195,860);c.scale(1.11,1.11);c.translate(-1217,-813);M.screamFigure(c,shock,notice,recover);c.restore();
  }
 },
 ground(){return 747;},roadColor:'#917554',roadInk:'#d0ad7c'

};
P.scenes[13]={title:'默片与影子',en:'THE SHADOW TAKES THE STAIRS',date:'1922',style:13,dark:false,accent:'#243c38',
 draw(c,t,a){M.bg(c,'silent-r7-shadow-switch',d=>{
 K.rect(d,0,0,1600,900,'#34353a');
 K.path(d,'M0 0 L750 0 L1450 900 L0 900Z','#bfb69e');
 K.path(d,'M0 0 L442 0 L955 745 L761 745Z','rgba(226,222,190,.13)');K.path(d,'M0 0 L53 0 L53 744 L0 744Z','#464b49');K.path(d,'M53 0 L72 0 L72 744 L53 744Z','#999b86');K.line(d,[[71,0],[71,744]],'#d9ceb0',1.2);
 // Plaster courses sit behind the set; the mortar never becomes a noise overlay.
 for(let row=0;row<12;row++){let y=191+row*45;K.line(d,[[46,y],[973,y]],'rgba(89,98,83,.19)',.7);for(let j=0;j<7;j++){let x=61+j*144+(row%2)*72;if(x<972)K.line(d,[[x,y],[x,y+44]],'rgba(103,110,91,.16)',.6);}}
 K.path(d,'M473 229 L481 261 L474 279 L487 295 M734 470 L724 487 L731 511 M71 571 L89 583 L84 603',null,'rgba(87,94,78,.28)',.9);
 K.path(d,'M1020 192 L1460 150 L1460 574 L1020 620Z','#1d242c','#0b1119',12);
 for(let x=1100;x<=1400;x+=100)K.line(d,[[x,184-(x-1020)*.1],[x,610-(x-1020)*.1]],'#626d72',12);
 K.line(d,[[1020,400],[1460,360]],'#737b7b',14);
 K.path(d,'M1007 189 L1472 143 L1474 581 L1010 631Z',null,'#4e585d',3);K.path(d,'M1026 197 L1453 157 L1453 569 L1026 613Z',null,'#b2b8a7',1.4);
 for(let i=0;i<4;i++){let x=1058+i*101;K.path(d,`M${x} ${220-i*9} L${x+23} ${214-i*9} L${x-3} ${365-i*9} L${x-17} ${367-i*9}Z`,'rgba(176,187,164,.08)');K.line(d,[[x+28,424-i*9],[x+32,552-i*9]],'rgba(179,191,170,.15)',.8);}
 K.path(d,'M0 900 L0 784 L420 784 L420 744 L555 744 L555 702 L690 702 L690 658 L825 658 L825 614 L960 614 L960 570 L1095 570 L1095 526 L1230 526 L1230 482 L1365 482 L1365 438 L1500 438 L1500 394 L1600 394 L1600 900Z','#4d5356');
 for(let i=0;i<9;i++){let x=420+i*135,y=784-i*43.7;K.line(d,[[x,y],[x+135,y]],'#bfc2ac',2.4);K.line(d,[[x+1,y+4],[x+134,y+4]],'#303d43',1.2);K.line(d,[[x+7,y+7],[x+7,y+36]],'#828c84',.7);K.path(d,`M${x+24} ${y+18} l17 1 m38 -1 l23 1`,null,'rgba(181,184,159,.25)',.65);}
 K.line(d,[[450,660],[1510,316]],'#0f1922',8);
 for(let i=0;i<9;i++){let x=450+i*129,y=660-i*42;K.line(d,[[x,y],[x,y+116]],'#26343b',6);K.line(d,[[x-1,y+4],[x-1,y+111]],'#8b9b94',1);K.circle(d,x,y+8,2.8,'#212f2d','#9ba78e',.55);K.rect(d,x-6,y+110,12,5,'#596b5b','#2e4138',.7);}
 // Painted window-light bars cross the plaster, separate from the solid stair silhouette.
 for(let i=0;i<5;i++)K.path(d,`M${1030+i*81} 213 L${1049+i*81} 211 L${585+i*101} 719 L${536+i*102} 731Z`,'rgba(224,220,184,.12)');
 for(let i=0;i<13;i++){let y=239+i*37;K.line(d,[[45,y],[410+(i%3)*53,y+1]],'rgba(76,86,76,.1)',1);}
 K.path(d,'M310 605 L1418 185 L1452 582 L314 625Z','rgba(245,222,167,.15)');
 K.path(d,'M208 661 L191 741 M252 661 L279 741 M233 663 L235 743',null,'#3c4c41',5);K.path(d,'M209 662 L194 737 M252 663 L276 737',null,'#aab095',1);
 M.round(d,181,578,112,88,7,'#536050','#253b33',2);M.round(d,187,585,99,74,4,'#727c64','#98a18b',1);K.rect(d,197,598,38,40,'#3e5143','#8b9982',1);for(let j=0;j<7;j++)K.line(d,[[201,603+j*4],[230,603+j*4]],'#91a087',1);
 K.path(d,'M289 600 L308 604 L308 628 L289 632Z','#263d35','#9baa90',1.4);K.ellipse(d,310,616,7,14,'#c4c8a4','#526550',1.1);K.ellipse(d,312,616,3,8,'#e1dbb3');
 K.circle(d,260,616,12,'#354c3d','#a3b094',1);K.circle(d,260,616,6,'#7b8d70','#253e33',1);K.line(d,[[252,610],[267,622]],'#c8ccb0',1);
 // Sprocketed film follows a continuous route from the feed reel through the gate.
 K.path(d,'M222 534 L248 546 L250 586 L242 598 L242 639 L267 650 L278 575',null,'#263d31',6);K.path(d,'M222 534 L248 546 L250 586 L242 598 L242 639 L267 650 L278 575',null,'#a6af8e',3.1);for(let yy=551;yy<584;yy+=5)K.rect(d,246,yy,2,2,'#22382e');for(let yy=602;yy<638;yy+=5)K.rect(d,239.5,yy,2,2,'#22382e');
 K.rect(d,236,606,13,18,'#b9baa0','#2b4234',1);K.rect(d,239,610,7,10,'#223c31');K.circle(d,272,632,5,'#c4c5a6','#324d3b',.8);K.line(d,[[272,632],[282,640],[286,637]],'#a9b794',2);
 for(let xx=296;xx<=307;xx+=4)K.ellipse(d,xx,616,5,12,null,'#72896c',.85);K.rect(d,201,644,31,6,'#435744','#a0ab89',.7);K.text(d,'24 fps',216,649,4.2,'#c3c7a0','center','mono');
 K.path(d,'M210 581 L210 550 L256 550 L270 584 M227 578 L230 558 L256 560 L259 578',null,'#384d3c',2.2);K.path(d,'M223 666 Q192 714 141 730',null,'#304539',3);
 for(const [x,y]of [[191,589],[280,589],[191,652],[280,652]]){K.circle(d,x,y,2.4,'#b8c0a1','#425846',.6);K.line(d,[[x-1,y-1],[x+1,y+1]],'#415741',.6);}
 // The stairs belong to the projected shadow; the cyclist crosses the set in front.
 K.rect(d,0,745,1600,155,K.gradient(d,[0,745],[0,900],[[0,'#a39e8c'],[1,'#515458']]));
 K.line(d,[[0,745],[1600,745]],'#ddd0ad',3);K.line(d,[[0,751],[1600,751]],'#4d5456',2);
 for(let i=0;i<12;i++){const x=i*147-65;K.line(d,[[x,752],[x-105,900]],'rgba(55,64,54,.18)',1);}
 K.path(d,'M997 211 L1007 626 L1030 619 L1020 209Z','#102029');K.path(d,'M1026 615 L1456 573 L1474 591 L1007 637Z','#15222a');K.line(d,[[1008,637],[1472,592]],'#9ba48b',1.3);
 K.rect(d,15,15,1570,870,null,'#0a1018',30);for(let yy=48;yy<866;yy+=48){M.round(d,6,yy,13,21,2,'#b9b49e');M.round(d,1581,yy,13,21,2,'#b9b49e');}K.line(d,[[29,36],[29,866]],'#3f494b',1);K.line(d,[[1571,36],[1571,866]],'#3f494b',1);

 });
 // The projected actor reaches the landing first, then switches off its own light.
 const projected=M.silentShadow(t,a),off=projected.off;
 if(off>0){c.save();c.globalAlpha=off*.52;K.rect(c,31,31,1538,713,'#111d29');c.restore();}
 const shutter=(.10+.025*Math.sin(t*Math.PI*48))*(1-off);K.path(c,'M314 604 L1420 183 L1450 581 L314 628Z',`rgba(230,225,191,${shutter})`);K.ellipse(c,313,616,5.5,11,`rgba(245,235,188,${.55*(1-off)})`);

 for(const [x,y,r]of [[206,550,33],[269,557,24]]){K.circle(c,x,y,r,'#929e83','#2f473b',1.7);K.circle(c,x,y,r-4,null,'#bbc0a0',1);for(let j=0;j<5;j++){let aa=t*.7+j*Math.PI*2/5;K.circle(c,x+Math.cos(aa)*r*.58,y+Math.sin(aa)*r*.58,r*.19,'#405444','#667961',.8);}K.circle(c,x,y,4,'#30483c','#b9c4a2',1);}
 if(P.drawRider&&off<1){const {sp,motion,foot}=projected;c.save();c.beginPath();c.rect(430,97,1092,632);c.clip();c.translate(sp.x,foot);c.transform(1,0,-.095,1.20,0,0);c.translate(-sp.x,-foot);P.drawRider(c,projected.at,Object.assign({},motion,sp,{style:13,alpha:.53*(1-off),shadow:false,headNod:projected.headNod,brakeLean:projected.brakeLean,bellPress:Math.sin(K.clamp((t-1.75)/.45)*Math.PI)}));c.restore();}
 M.silentCord(c,t,a,projected);
 if(t>1.8&&t<2.5){c.save();c.globalAlpha=Math.sin((t-1.8)/.7*Math.PI)*.4;K.path(c,'M1370 286 Q1393 301 1370 322 M1385 274 Q1418 303 1386 336',null,'#25322d',4);c.restore();}
 // The stair-rail shadow bends like an expressionist set.
 const flick=1+Math.sin(t*37)*.025;
 c.save();c.globalAlpha=.055*flick*(1-off);K.rect(c,0,0,1600,900,'#fff');c.restore();
 for(let i=0;i<3;i++){let x=K.rnd(i+138)*1600;K.path(c,`M${x+(t*7)%23} 26 Q${x+4+(t*7)%23} 481 ${x+2+(t*7)%23} 873`,null,'rgba(238,235,210,.10)',.55);}
 if(t>2&&t<3.55){K.rect(c,77,250,358,113,'#111820','#b4b8a6',2);K.text(c,'影子先到了。',256,317,31,'#e9dec1','center','serif');}
 },pose(t){return{x:1600*t/6,y:745-102*1.18,scale:1.18,tilt:0,style:13,headNod:-Math.sin(K.clamp((t-2.2)/1.5)*Math.PI)*.13,bellPress:Math.sin(K.clamp((t-2.5)/.4)*Math.PI)};},
 ground(){return 745;},roadColor:'#a39e8c',roadInk:'#ddd0ad',
 over(c,t){if(t>5.2){c.save();c.globalAlpha=(t-5.2)*.13;K.rect(c,0,0,1600,900,'#9cffa7');c.restore();}}
};
// A real circular CRT is set into a wide, machined laboratory cabinet.
// The narrow input/output conduits turn the traveller into a travelling voltage
// at the screen edge, rather than allowing a wireframe bird to cross the knobs.
M.scopeTravel=function(t){const v=1600/6,a=2.35,b=3.75,x=800;function h(u,p0,p1,m0,m1,d){return(2*u*u*u-3*u*u+1)*p0+(u*u*u-2*u*u+u)*d*m0+(-2*u*u*u+3*u*u)*p1+(u*u*u-u*u)*d*m1;}if(t<a)return h(K.clamp(t/a),0,x,v,0,a);if(t<=b)return x;return h(K.clamp((t-b)/(6-b)),x,1600,0,v,6-b);};
M.scopeGlass={x:800,y:480,r:258};
// The signal road rises gently inside the round glass. Its centre is level so
// calibration does not move the parked bicycle, and both complete rims fit.
M.scopeFloor=x=>710-30*K.ease((x-430)/150)*(1-K.ease((x-1020)/150));
M.scopeBase=function(c){c.drawImage(K.cached('scope-r2-round-crt',d=>{
 K.rect(d,0,0,1600,900,K.gradient(d,[0,0],[1600,900],[[0,'#14232b'],[.52,'#101e24'],[1,'#1c3032']]));
 for(let j=0;j<16;j++)K.line(d,[[0,824+j*6],[1600,824+j*6]],'rgba(137,170,157,.045)',1);
 K.ellipse(d,800,831,742,29,'rgba(0,0,0,.48)');
 M.round(d,61,176,1478,650,17,K.gradient(d,[61,176],[61,826],[[0,'#79938c'],[.08,'#304b50'],[.9,'#263d45'],[1,'#162930']]),'#78958d',2);
 M.round(d,80,194,1440,607,8,K.gradient(d,[80,194],[1520,801],[[0,'#c9ccba'],[.5,'#d5d4bf'],[1,'#99ada0']]),'#2b4547',2);
 for(let j=0;j<148;j++)K.line(d,[[88,203+j*4],[1511,203+j*4]],j%3?'rgba(240,241,218,.09)':'rgba(28,50,48,.025)',.7);
 for(const x of [38,1545]){M.round(d,x,315,18,340,7,'#254047','#79998d',1.2);K.line(d,[[x+5,327],[x+5,643]],'#97aaa0',1);for(let y=341;y<640;y+=17)K.line(d,[[x+8,y],[x+14,y]],'#112b32',2);}
 K.text(d,'示波器',113,232,27,'#294848','left','serif','700');K.text(d,'X–Y OSCILLOSCOPE',237,230,14,'#3b5753','left','mono','700');K.text(d,'P—60  ·  1950s',1483,230,15,'#3b5753','right','mono');
 // Concentric metal lip, bakelite gasket and deep curved glass.
 K.circle(d,800,480,281,'#274448','#9daea0',2);K.circle(d,800,480,274,'#1c3036','#708d79',2);K.circle(d,800,480,265,'#061b18','#4a6956',1.5);
 const glass=d.createRadialGradient(775,443,20,800,480,272);glass.addColorStop(0,'#0d392b');glass.addColorStop(.65,'#082a22');glass.addColorStop(1,'#031614');K.circle(d,800,480,258,glass,'#32583f',1);
 d.save();d.beginPath();d.arc(800,480,258,0,Math.PI*2);d.clip();
 for(let x=530;x<1075;x+=43)K.line(d,[[x,220],[x,740]],'rgba(104,162,109,.20)',.8);for(let y=222;y<740;y+=43)K.line(d,[[540,y],[1060,y]],'rgba(104,162,109,.20)',.8);
 K.line(d,[[542,480],[1058,480]],'#407d53',1);K.line(d,[[800,222],[800,738]],'#407d53',1);
 for(let x=551;x<1059;x+=8.6)K.line(d,[[x,477],[x,483]],'#3d704c',.65);for(let y=230;y<738;y+=8.6)K.line(d,[[797,y],[803,y]],'#3d704c',.65);
 for(let y=225;y<739;y+=3)K.line(d,[[542,y],[1058,y]],'rgba(133,192,129,.027)',.55);
 K.path(d,'M584 323 Q658 224 789 236 Q674 254 600 352Z','rgba(220,240,200,.035)');d.restore();
 for(let j=0;j<8;j++){const a=j*Math.PI/4+Math.PI/8;M.screw(d,800+Math.cos(a)*273,480+Math.sin(a)*273,3.5);}
 for(const [x,y]of [[93,207],[1506,207],[93,786],[1506,786]])M.screw(d,x,y,4.7);
 // Separate waveform channel windows show the voltages that draw the bird.
 for(const [x,label]of [[122,'CH 1  →  X'],[1142,'CH 2  →  Y']]){M.round(d,x,316,336,184,7,'#607b6d','#38584f',1);M.round(d,x+9,325,318,148,4,'#132d27','#9ba88d',1);for(let xx=x+17;xx<x+320;xx+=31)K.line(d,[[xx,330],[xx,468]],'#254a37',.7);for(let yy=334;yy<471;yy+=22)K.line(d,[[x+14,yy],[x+322,yy]],'#254a37',.7);K.text(d,label,x+16,492,12,'#325649','left','mono','700');K.text(d,'1 V / DIV',x+318,492,10,'#486454','right','mono');}
 K.text(d,'两个电压，一只不太听话的鸟。',800,153,22,'#e5dfbd','center','serif');
 // Side routes are sockets cut through the case, so the road itself is never cut.
 for(const [x,w]of [[80,484],[1036,484]]){M.round(d,x,684,w,43,7,'#142e2b','#5f7c64',2);K.line(d,[[x+2,710],[x+w-2,710]],'#65a86e',.9);K.line(d,[[x+5,690],[x+w-5,690]],'#244c36',1);}
 for(const x of [125,405,1195,1475]){K.rect(d,x-3,700,6,20,'#385c42','#a5b388',.7);}
 K.text(d,'输入  /  影子通电',124,672,12,'#4b6657','left','sans');K.text(d,'输出  /  继续骑行',1476,672,12,'#4b6657','right','sans');
 M.round(d,124,533,334,91,5,'#b5c0a9','#637c65',1);K.text(d,'BEAM POSITION',140,555,10,'#486252','left','mono');K.text(d,'X   −5         0         +5',291,613,9,'#56705b','center','mono');
 M.round(d,1143,533,334,91,5,'#b8c1ac','#68816a',1);K.text(d,'CALIBRATION',1160,555,10,'#486252','left','mono');K.text(d,'让每一根羽毛，回到自己的位置。',1310,610,13,'#506c58','center','serif');
 K.rect(d,122,751,79,28,'#71856d','#35584b',1);K.rect(d,128,757,29,16,'#304d40','#aeb799',1);K.text(d,'ON',181,771,11,'#33594c','center','mono');K.circle(d,217,765,6,'#284636','#8c9f76',1);K.text(d,'POWER',165,796,10,'#3b5b4f','center','mono');
 M.socket(d,296,767,'INPUT X','#b8c579');M.socket(d,403,767,'INPUT Y','#d7ba72');K.text(d,'1 MΩ / 20 pF',350,799,10,'#4a6657','center','mono');
 K.path(d,'M296 781 C295 835 160 812 161 847 C166 883 442 842 403 781',null,'#101f24',8);K.path(d,'M296 781 C295 835 160 812 161 847',null,'#a4b260',2.5);K.path(d,'M403 781 C435 829 375 844 306 847',null,'#c3a25c',2.5);K.rect(d,291,762,10,27,'#b8c3a0','#506b62',1);K.rect(d,398,762,10,27,'#d4b884','#587369',1);
 K.text(d,'SERIAL 006000',1479,780,11,'#425e53','right','mono');K.text(d,'PHOSPHOR / PERSISTENCE',1479,797,9,'#5a7060','right','mono');
 }),0,0);};
M.scopeFace=function(c,t,p){
 const gain=K.ease((t-2.15)/.35)*(1-K.ease((t-3.15)/.45));M.knob(c,563,766,19,-.45,'TIME / DIV',true);M.knob(c,740,766,19,.34+gain*1.9,'X / Y SYNC',true);M.knob(c,916,766,19,.3,'FOCUS',true);K.circle(c,217,765,4,'#b5ed93');
 const samples=M.traceSamples(M.traceContours(p)),count=samples.length;
 for(let ch=0;ch<2;ch++){const xx=ch?1155:135,pts=[];for(let j=0;j<=150;j++){const u=j/150,q=samples[Math.floor(((t*.9+u*.8)%1)*count)],v=ch?(q[1]+90)/220:q[0]/215;pts.push([xx+u*307,399+v*55]);}c.save();c.shadowColor=ch?'#ebd692':'#94eda0';c.shadowBlur=4;K.line(c,pts,ch?'#e0c77e':'#99df98',1.2);c.restore();K.circle(c,pts[pts.length-1][0],pts[pts.length-1][1],2,ch?'#fff0b3':'#c9ffb9');}
 const pointer=K.clamp((p.x-542)/516);K.line(c,[[146,578],[435,578]],'#6b8566',1);for(let j=0;j<11;j++)K.line(c,[[147+j*28.7,573],[147+j*28.7,583]],'#6a8165',1);K.path(c,`M${147+pointer*287} 565 l-5 -8 h10Z`,'#426e50');
 const status=t<1.9?'REFERENCE READY':t<2.15?'AUTO CAL':t<3.6?'SYNC LOST · 3:2':'CALIBRATED ✓';K.text(c,status,1310,582,17,t<3.6?'#7d6535':'#426b47','center','mono','700');
 M.scopeAutoCal(c,t,gain);
 // The beam follows the path while the cabinet hides the off-screen drawing.
 for(const [a,b]of [[80,548],[1052,1520]]){const pts=[];for(let x=a;x<=b;x+=5){const dist=Math.abs(x-p.x),pulse=Math.exp(-dist*dist/14000);pts.push([x,710+Math.sin(x*.11-t*19)*10*pulse]);}c.save();c.shadowColor='#70e889';c.shadowBlur=4;K.line(c,pts,'#8fdc9c',1.1);c.restore();}
 // In the two narrow guideways the very same outline is compressed into a
 // readable carrier. It expands into the CRT instead of disappearing behind it.
 if(p.x<570||p.x>1030){c.save();c.beginPath();c.rect(80,685,468,41);c.rect(1052,685,468,41);c.clip();c.translate(p.x,705);c.scale(.095,.095);c.translate(0,90);c.shadowColor='#79ff9b';c.shadowBlur=9;M.tracePortion(c,M.traceContours(p),0,1,'#d5ffbc',5.5);c.restore();}
 if(t>3.6){K.text(c,'一只鸟。不是三个圈。',800,280,15,'#83b890','center','serif');}
};
P.scenes[14]={title:'示波器',en:'X–Y OSCILLOSCOPE',date:'1950s',style:14,dark:true,accent:'#a5f2b7',uiNativeLabels:true,
 riderClip:{x:80,y:222,w:1440,h:516},travelX(t){return M.scopeTravel(t);},ground(x){return M.scopeFloor(x);},roadColor:'#0c3025',roadInk:'#61a87b',
 draw(c,t){M.scopeBase(c);},
 pose(t){const s=.82,x=this.travelX(t);return{x,y:this.ground(x)-102*s,scale:s,style:14,alpha:.4,headNod:-.02,bellPress:Math.sin(K.clamp((t-3.7)/.4)*Math.PI),shadow:false};},
 foreground(c,t,a,p){const pose=p||this.pose(t),s=pose.scale||.82;
 // Inverse circle mask: behind the round glass, the instrument physically occludes the signal.
 c.save();c.beginPath();c.rect(0,0,1600,900);c.moveTo(1058,480);c.arc(800,480,258,0,Math.PI*2,true);c.closePath();c.clip('evenodd');M.scopeBase(c);c.restore();
 c.save();c.beginPath();c.arc(800,480,258,0,Math.PI*2);c.clip();c.translate(pose.x,pose.y);c.rotate(pose.tilt||0);c.scale(s,s);c.lineJoin='round';c.lineCap='round';const paths=M.traceContours(pose),head=(t*1.5)%1;c.shadowColor='#64ff93';c.shadowBlur=8;M.tracePortion(c,paths,0,1,'rgba(145,234,132,.22)',1.2);const ranges=head<.24?[[0,head],[1+head-.24,1]]:[[head-.24,head]];let dot;for(const [lo,hi]of ranges){M.tracePortion(c,paths,lo,hi,'rgba(132,255,153,.5)',3.2);dot=M.tracePortion(c,paths,lo,hi,'#e0ffc2',1.1)||dot;}if(dot)K.circle(c,dot[0],dot[1],2.7,'#efffca');c.restore();
 M.scopeFace(c,t,pose);
 }
};

P.scenes[15]={title:'像素风铃',en:'CHIME COURIER',date:'1980s',style:15,dark:true,accent:'#ffdd7f',
 ground(){return 730;},roadOffset(t){return 0;},roadColor:'#83b765',roadInk:'#c1d882',
 draw(c,t){M.bg(c,'pixel-r8-chime-courier',d=>{
 // CHIME COURIER is an original pixel delivery game: wind towers, lantern seeds and resonant relays.
 K.rect(d,0,0,1600,900,'#72b6e0');K.rect(d,0,438,1600,205,'#86c4e4');K.rect(d,0,566,1600,164,'#9ed3df');
 for(const [x,w,h]of [[-48,319,179],[347,236,129],[655,356,212],[1160,305,165],[1489,265,124]]){const y=665;K.path(d,`M${x} ${y} L${x} ${y-24} L${x+24} ${y-24} L${x+24} ${y-58} L${x+52} ${y-58} L${x+52} ${y-96} L${x+83} ${y-96} L${x+83} ${y-h+24} L${x+112} ${y-h+24} L${x+112} ${y-h} L${x+w-112} ${y-h} L${x+w-112} ${y-h+24} L${x+w-83} ${y-h+24} L${x+w-83} ${y-96} L${x+w-52} ${y-96} L${x+w-52} ${y-58} L${x+w-24} ${y-58} L${x+w-24} ${y-24} L${x+w} ${y-24} L${x+w} ${y}Z`,'#65ac75','#4a9468',2);K.rect(d,x+111,y-h+23,10,31,'#a9d68a');}
 // The small post office and open chime towers sit behind the courier route.
 K.rect(d,1212,576,152,103,'#83afa5');K.rect(d,1200,568,176,8,'#3e6973');K.rect(d,1216,556,144,12,'#b68e62');K.rect(d,1232,544,112,12,'#d9bc83');K.rect(d,1248,536,80,8,'#f0dba2');
 K.rect(d,1220,581,136,5,'#c7d6b3');K.rect(d,1220,672,136,7,'#42777b');for(const xx of [1229,1272]){K.rect(d,xx,597,31,27,'#3e6b75');K.rect(d,xx+4,601,23,19,'#ccdec0');K.rect(d,xx+13,601,4,19,'#628e89');}
 K.rect(d,1322,611,29,68,'#3f6973');K.rect(d,1327,617,19,54,'#b9c7a7');K.rect(d,1330,635,10,3,'#425c65');K.rect(d,1241,638,58,29,'#365d6b');K.rect(d,1247,644,46,17,'#e4d8ac');K.line(d,[[1247,644],[1270,655],[1293,644]],'#7c8e83',3);
 K.rect(d,0,677,1600,53,'#83bd70');K.rect(d,0,681,1600,5,'#b9d994');K.rect(d,0,703,1600,27,'#76ae61');
 M.pixelChimeTower(d,160,684,80,129);M.pixelChimeTower(d,1439,684,88,106);K.rect(d,152,684,96,7,'#4b9154');K.rect(d,1431,684,104,7,'#4b9154');
 for(let i=0;i<7;i++){let x=335+i*193,y=677;K.rect(d,x-28,y-20,88,20,'#419e5f');K.rect(d,x-16,y-36,65,16,'#5bb76c');K.rect(d,x,y-48,31,12,'#79c77a');K.rect(d,x-18,y-20,10,7,'#a4d68a');K.rect(d,x+30,y-35,9,7,'#a4d68a');}
 for(const x of [74,294,1114,1548]){K.rect(d,x,701,4,20,'#3b8553');K.rect(d,x-4,695,12,8,'#fff1b0');K.rect(d,x,695,4,4,'#e4a14d');K.rect(d,x+4,710,8,4,'#4c9a53');}
 M.pixelSeedLantern(d,281,677,1.5);M.pixelSeedLantern(d,1198,677,1.5);
 });
 // Distant clouds scroll at their own speed; every edge stays on the pixel grid.
 for(let i=0;i<6;i++){let x=Math.floor((((i*315-t*9+1900)%1900)-180)/4)*4,y=266+i%3*44;K.rect(c,x,y,132,20,'#f6f3d6');K.rect(c,x+16,y-20,100,20,'#f6f3d6');K.rect(c,x+40,y-40,52,20,'#f6f3d6');K.rect(c,x+12,y+20,108,8,'#c7e4da');}
 const delivery=K.ease((t-4.65)/.7),droneX=1537-Math.round(delivery*53)*4,droneY=652-Math.round(Math.sin(delivery*Math.PI)*7)*4;M.pixelCourierDrone(c,droneX+Math.round(Math.sin(t*1.3)*4)*4,droneY,t,2.5);
 if(t>=4.65){const seal=K.ease((t-4.85)/.45),mailX=Math.round(K.lerp(droneX,1270,seal)/4)*4,mailY=Math.round(K.lerp(droneY+15,651,seal)/4)*4;if(t<5.35){K.rect(c,mailX-12,mailY-8,24,16,'#fff0bd','#455d62',2);K.line(c,[[mailX-10,mailY-6],[mailX,mailY+1],[mailX+10,mailY-6]],'#d7a963',2);}else{K.rect(c,1249,645,43,15,'#f5dda1');K.text(c,'OK',1270,657,11,'#4c715c','center','mono','700');K.rect(c,1367,541,4,36,'#57715f');K.rect(c,1371,541,25,15,'#efaa70');K.rect(c,1375,545,13,4,'#ffe8b2');}}
 // The same 730px contact surface now has brick courses, grass caps and root pockets.
 K.rect(c,-40,730,2300,170,'#8c4c30');for(let x=-40;x<2300;x+=40){if(x+40>710&&x<1070)continue;for(let y=730;y<900;y+=40)M.pixelBrick(c,x+(Math.floor((y-730)/40)%2)*-20,y);K.rect(c,x,730,40,8,'#99c767');for(let q=0;q<4;q++)K.rect(c,x+q*10,738,6,q%2?5:9,q%2?'#82b760':'#6d9e51');}
 K.rect(c,710,730,360,170,'#24546a');K.rect(c,718,758,344,142,'#357fa0');K.rect(c,718,754,344,8,'#b2e1cc');K.rect(c,718,762,344,5,'#5baeb9');for(let j=0;j<6;j++){let yy=778+j*20;for(let k=0;k<7;k++){let xx=724+Math.floor(((k*47+t*17+j*11)%322)/4)*4;K.rect(c,xx,yy,20,4,j%2?'#6cbcc3':'#92d0cb');}}
 K.rect(c,700,730,10,170,'#633f2c');K.rect(c,1070,730,10,170,'#633f2c');for(let q=0;q<4;q++){let yy=744+q*37;K.rect(c,688,yy,20,26,q%2?'#b57a45':'#d79b5b');K.rect(c,1072,yy,20,26,q%2?'#d79b5b':'#b57a45');K.rect(c,690,yy,15,4,'#e7b573');K.rect(c,1075,yy,15,4,'#e7b573');}
 for(const x of [720,1054]){K.rect(c,x,768,4,24,'#87a65b');K.rect(c,x+(x<800?4:-4),784,4,24,'#698f54');}const fishX=773+Math.round(Math.sin(t*1.4)*17)*4;K.rect(c,fishX,829,20,8,'#f0c282');K.rect(c,fishX-8,825,8,16,'#c58b60');K.rect(c,fishX+16,829,4,4,'#27495b');
 // The spring plate compresses at the original take-off time; the route itself is unchanged.
 K.rect(c,571,657,8,73,'#774e30');K.rect(c,534,630,90,42,'#d4a45d','#66452d',4);K.rect(c,542,638,74,26,'#b37e40');K.line(c,[[558,653],[596,653],[584,642],[596,653],[584,664]],'#fff0a5',4);
 const press=Math.sin(K.clamp((t-1.91)/.4)*Math.PI),sy=708+press*18;K.rect(c,640,725,53,5,'#496443');const sh=(724-sy)/3;for(let j=0;j<3;j++){K.rect(c,647,sy+1+j*sh,37,3,'#f0d39a');K.rect(c,j%2?647:679,sy+j*sh,5,sh+1,'#a78b5f');}K.rect(c,634,sy-5,65,8,'#d96343','#77472f',2);K.rect(c,640,sy-5,49,3,'#ffc16d');
 // The feather-tip grazes this block while rising. It is fixed at that real rig contact.
 const contact=M.pixelBlockAnchor(),age=t-M.pixelBlockHit,bump=age>=0&&age<.34?18*Math.sin(age/.34*Math.PI):0,bx=contact.x-24,by=contact.y-48-bump;
 if(age>.05){const rise=K.ease((age-.05)/.45);M.pixelSeedLantern(c,bx+8,by+4-rise*32,2);}M.pixelRelay(c,bx,by,age>=0);M.pixelBrick(c,bx-48,contact.y-48,48,48);M.pixelBrick(c,bx-96,contact.y-48,48,48);
 if(age>=0&&age<.42){const u=age/.42;for(let j=0;j<5;j++)K.rect(c,contact.x+(j-2)*12*u,contact.y-4-u*(10+j%2*12),4,4,'#fff2a5');}
 // Landing activates the original three-note wind-chime checkpoint.
 const checkpoint=K.ease((t-4.65)/.28);K.rect(c,1342,577,8,153,'#477681');K.rect(c,1408,577,8,153,'#477681');K.rect(c,1336,569,88,9,'#d4b87e');K.rect(c,1339,566,82,4,'#f4e1aa');K.rect(c,1333,725,92,7,'#41666b');
 for(let i=0;i<3;i++){const xx=1359+i*20,yy=608+(i%2)*12-checkpoint*13,ring=checkpoint*Math.round(Math.sin((t-4.65)*12+i)*2);K.rect(c,xx-1,578,3,yy-578,'#7c9587');K.rect(c,xx-6+ring,yy,12,21,checkpoint>.2?'#f3cc77':'#86a79a');K.rect(c,xx-9+ring,yy+17,18,5,'#9f774c');K.rect(c,xx-1+ring,yy+22,4,6,'#f4e2ab');}
 K.rect(c,1354,686,52,24,'#355e70');K.text(c,checkpoint>.2?'GO':'…',1380,704,14,checkpoint>.2?'#ffe29b':'#a4c8bc','center','mono','700');
 // A squared, readable HUD uses the vocabulary of the game, not a floating UI card.
 K.rect(c,81,179,1438,61,'#183b49','#b5dbba',3);K.rect(c,85,183,1430,4,'#426e70');K.text(c,'CHIME COURIER',105,216,20,'#fff0bd','left','mono','700');K.text(c,'ROUTE 01',375,216,17,'#bad6bb','left','mono');
 const collected=[2.6,3.1,3.6].filter(h=>t>=h).length;K.text(c,'SCORE',551,202,10,'#a7c5ac','left','mono');K.text(c,String(1900+collected*100).padStart(6,'0'),551,222,18,'#f7d680','left','mono');for(let i=0;i<3;i++){c.save();c.translate(790+i*35,210);c.scale(.52,.52);c.globalAlpha=i>=collected?.25:1;M.pixelChime(c,0,0,0);c.restore();}K.text(c,collected+'/3',919,216,18,'#f3d287','left','mono');K.text(c,'LIFE',1120,211,13,'#c2d8b6','left','mono');for(let i=0;i<3;i++){let x=1188+i*36,bright=i<2||collected===3;K.line(c,[[x,208],[x,201],[x+7,201],[x+10,205],[x+13,201],[x+20,201],[x+20,208],[x+10,219]],null,1,true,bright?'#ef9672':'#4f7866');}K.text(c,t>=4.65?'ROUTE CLEAR':'TIME '+String(Math.max(0,6-Math.floor(t))).padStart(2,'0'),1479,216,17,t>=4.65?'#ffe49c':'#dce4b6','right','mono');
 },pose(t){return M.pixelPose(t);},
 foreground(c,t,a,p){const scroll=0;for(const hit of [2.6,3.1,3.6]){const q=M.pixelCoinPoint(hit),x=q.x-scroll,y=q.y;if(t<hit)M.pixelChime(c,x,y,t+hit);else{const u=(t-hit)/.65;M.starBurst(c,x,y,u,'#fff0a8',true);if(u<1){c.save();c.globalAlpha=1-u;K.text(c,'100',x+2,y-28-u*27+2,18,'#6e4a32','center','mono','700');K.text(c,'100',x,y-28-u*27,18,'#fff0a8','center','mono','700');c.restore();}}}
 if(t>3.6&&t<4.65){const u=(t-3.6)/1.05,q=M.pixelCoinPoint(3.6);c.save();c.globalAlpha=1-K.ease((u-.65)/.35);K.text(c,'1UP',q.x-scroll,q.y-32-u*40,27,'#f9efb9','center','mono','700');c.restore();}
 if(t>2.1&&t<2.48){const u=(t-2.1)/.38;for(let i=0;i<7;i++)K.rect(c,665-scroll+(i-3)*13*u,718-u*28,6,6,'#f6e1a0');}
 if(t>4.5&&t<5){const pose=p||M.pixelPose(t),u=(t-4.5)/.5;for(let i=0;i<10;i++){const x=pose.x+(i<5?-130:150)*pose.scale+(i%5-2)*15*u;K.rect(c,x,729-u*(5+i%3*5),8-u*4,5-u*2,'#d7d2a4');}}
 if(t>4.68){const u=(t-4.68)/.8;for(let i=0;i<16;i++){const age=u+i*.015;if(age>1)continue;const an=i*Math.PI*2/16;K.rect(c,1351-scroll+Math.cos(an)*age*95,589+Math.sin(an)*age*66+age*age*35,5,7,['#f3d68c','#d99e81','#a7ce8e'][i%3]);}}
 // Foreground grass is confined to the bottom edge so the bicycle and collisions stay legible.
 for(let j=0;j<16;j++){let x=j*112;if(x>682&&x<1090)continue;K.rect(c,x+8,738,4,12,'#759c4e');K.rect(c,x+12,742,4,4,'#91ba59');}
 }
};

P.scenes[16]={title:'聊天时代',en:'SOMEONE IS TYPING…',date:'2000s',style:16,dark:false,accent:'#2d6689',
 riderClip:{x:631,y:341,w:599,h:364},ground(){return 675;},roadColor:'#e4e9df',roadInk:'#a6b49f',
 draw(c,t){M.bg(c,'chat-r4',d=>{
 K.rect(d,0,0,1600,900,K.gradient(d,[0,0],[1600,900],[[0,'#c8d8cd'],[.4,'#cee0df'],[1,'#a0b9cb']]));
 for(let i=0;i<3;i++){let x=59+i*68,y=718+i*7;K.rect(d,x,y,38,33,'#e8df8a','#6f8b97',1);K.rect(d,x+3,y-7,18,10,'#e8df8a','#6f8b97',1);K.path(d,`M${x-2} ${y+7} L${x+40} ${y+7} L${x+34} ${y+34} L${x-5} ${y+34}Z`,'#eee5a0','#8c9d8a',.8);K.line(d,[[x+8,y+13],[x+28,y+13]],'#b9b57b',.8);K.text(d,['画稿','旅途','留声'][i],x+17,y+54,11,'#527580','center');}
 K.rect(d,118,265,95,80,'#dde8db','#8ca4b0',2);K.rect(d,124,272,82,58,'#7899a0','#486c84',2);K.rect(d,154,346,21,8,'#7f98a1');K.rect(d,138,355,53,7,'#cbd9d6','#7f98a1',1);K.text(d,'我的电脑',164,387,16,'#41606b','center');
 K.line(d,[[119,266],[212,266]],'#f4f5df',1);K.line(d,[[119,266],[119,343]],'#f4f5df',1);K.rect(d,129,277,72,48,'#73959c','#385e73',.8);K.path(d,'M129 304 L143 293 L154 299 L172 285 L201 307 L201 325 L129 325Z','#668c81');K.rect(d,143,282,42,31,'#d1ded7','#466d80',.7);K.rect(d,144,283,40,6,'#7f9ead');K.line(d,[[150,295],[177,295]],'#98b3ad',1);K.line(d,[[150,300],[169,300]],'#98b3ad',1);K.circle(d,199,337,1.8,'#6c996e');
 K.circle(d,164,463,27,'#a1c7c4','#6a959f',1.3);K.ellipse(d,164,463,12,27,null,'#6f9ca1',.8);K.ellipse(d,164,463,27,10,null,'#6f9ca1',.8);K.line(d,[[137,463],[191,463]],'#6f9ca1',.8);K.path(d,'M146 447 L157 440 L167 447 L160 454 L166 464 L157 473 L150 464 L144 462Z','#bdd7ba','#83a797',.7);K.path(d,'M176 468 L187 470 L180 482 L173 480Z','#bdd7ba','#83a797',.7);K.text(d,'网上邻居',164,508,15,'#537885','center');
 K.rect(d,278,207,1110,602,'rgba(52,83,104,.18)');
 K.rect(d,0,865,1600,35,'#b7c8c5','#88a4ac',1);K.line(d,[[0,867],[1600,867]],'#edf1df',1);K.rect(d,14,873,88,22,'#dce5d5','#70929a',1);K.path(d,'M23 879 L29 876 L29 883 L23 886Z M31 875 L37 877 L37 884 L31 882Z M23 888 L29 885 L29 892 L23 895Z M31 884 L37 886 L37 893 L31 891Z','#6a99a3');K.text(d,'开始',53,890,13,'#355e70');K.rect(d,116,873,184,22,'#d4dfd4','#73939d',1);K.text(d,'飞鸽传书',147,890,12,'#3c6275');K.rect(d,127,880,13,9,'#91b5b4','#537f8b',.7);K.path(d,'M127 880 L133.5 885 L140 880',null,'#f0f1d7',.7);
 K.rect(d,1436,873,148,22,'#a8bebf','#839fa8',.8);K.circle(d,1453,884,4,'#75a078','#4d7d73',.7);K.path(d,'M1468 883 l4 0 l4 -4 l0 11 l-4 -4 l-4 0Z',null,'#66838d',1);K.text(d,'20:00',1530,890,12,'#3e6371','center','mono');
 });
 const jig=(t>2.5&&t<2.82)||(t>3.45&&t<3.72)?Math.sin(t*110)*9:0,typing=t>2.85&&t<4.55;
 c.save();c.translate(jig,-jig*.45);K.rect(c,258,191,1110,609,'#e9ece8','#71899a',2);K.rect(c,262,195,1102,45,K.gradient(c,[0,195],[1100,240],[[0,'#2f5f8d'],[1,'#73a5be']]));
 K.line(c,[[260,193],[1366,193]],'#eef2e2',1);K.line(c,[[260,193],[260,382]],'#eef2e2',1);K.line(c,[[1365,241],[1365,381]],'#506e82',1);K.line(c,[[261,797],[1365,797]],'#a8b8b8',1);
 K.rect(c,274,208,22,15,'#c5ddd4','#315c79',.8);K.path(c,'M274 208 L285 216 L296 208 M274 223 L282 216 M296 223 L288 216',null,'#f0f4dc',1);
 K.text(c,typing?'飞鸽传书  /  对方正在输入…':'飞鸽传书  /  骑车的朋友',310,225,22,'#fff','left','sans','500');
 for(let i=0;i<3;i++){K.rect(c,1250+i*34,204,26,25,i===2?'#d38471':'#bad2db','#2c5e80',1);K.text(c,['–','□','×'][i],1263+i*34,223,20,'#244a62','center');}
 K.rect(c,275,253,190,531,'#d8e4e6','#a9c3cc',1);K.rect(c,298,277,144,144,'#d0c89e','#899e9b',1);
 K.ellipse(c,367,341,41,29,'#f6f4dc','#8a9c92',2);K.path(c,'M347 331 Q374 340 386 350 Q355 361 342 343Z','#c4d4cd','#829a93',1.3);K.circle(c,389,320,20,'#f6f4dc','#8a9c92',2);K.path(c,'M400 317 L441 325 L399 332Z','#d9aa55');K.circle(c,396,315,2,'#394548');
 K.text(c,'骑车的朋友',370,453,20,'#325368','center');K.text(c,'在线 · 6,000年',370,483,15,'#65838e','center');K.circle(c,321,513,5,'#69a66d');K.text(c,'正在穿越',337,518,16,'#65838e');
 K.line(c,[[290,546],[449,546]],'#b0c2c4',1);K.text(c,'最近联系人',295,572,14,'#79929a');for(let i=0;i<3;i++){const y=592+i*46;K.rect(c,299,y,25,25,['#bdd1ac','#d0bfa8','#b4c9cf'][i],'#829ca2',1);if(i===0){K.ellipse(c,311,y+13,9,7,'#e4d2a5','#8b9e89',.6);for(let k=0;k<3;k++)K.circle(c,307+k*4,y+11,1.6,['#ad7d66','#7495a5','#8aa770'][k]);K.line(c,[[307,y+21],[320,y+4]],'#6d8077',1.3);}else if(i===1){K.path(c,`M302 ${y+21} L306 ${y+14} L315 ${y+14} L319 ${y+21}Z`,'#8c9f84');K.ellipse(c,311,y+10,4,5,'#e4d4b1','#8b9275',.6);K.path(c,`M303 ${y+7} Q311 ${y-1} 319 ${y+7}Z`,'#b0a77e','#7f876d',.7);}else{K.rect(c,303,y+7,17,12,'#e6ece0','#7e9da7',.6);K.path(c,`M303 ${y+7} L311.5 ${y+13} L320 ${y+7}`,null,'#7e9da7',.7);}K.text(c,['画师朋友','一位牧人','未读消息'][i],334,609+i*46,15,'#63818b');}
 K.rect(c,483,253,866,464,'#fbfbf4','#becbd1',1);
 K.rect(c,1337,256,9,457,'#e5e9df','#c1ceca',.6);K.rect(c,1339,275,5,85,'#c6d4cd','#9eb5b3',.6);K.path(c,'M1339 263 L1341.5 259 L1344 263Z M1339 706 L1341.5 710 L1344 706Z','#8ba6aa');
 K.text(c,'骑车的朋友  20:00:00',506,284,17,'#519b66');K.text(c,t>4.55?'路还在，先不聊。':'出发的时候，还没有自行车。',506,318,22,'#37556b');
 if(t>2.18){K.rect(c,1118,282,206,48,'#e5eddd','#c3d2c8',1);K.path(c,'M1324 296 L1330 302 L1324 308Z','#e5eddd','#c3d2c8',.8);K.line(c,[[1324,297],[1324,307]],'#e5eddd',1.5);K.text(c,'怎么还没到？',1221,313,19,'#53737c','center');}
 K.rect(c,629,340,603,365,'#e4e9df','#c2d2d2',1);K.line(c,[[651,675],[1211,675]],'#b0bca9',2);K.text(c,'pelican.gif',648,365,14,'#73919b','left','mono');
 K.text(c,t<.8?'接收中… '+Math.floor(40+t*75)+'%':'[ 动态图片 · 无限循环 ]',1211,365,13,'#829b99','right');if(t<.8)K.rect(c,649,688,561*K.clamp((t+.5)/1.3),3,'#87b0a1');
 K.rect(c,483,728,866,55,'#fff','#becbd1',1);K.rect(c,1236,739,91,33,'#d4e3dd','#8baba9',1);K.text(c,'发送',1282,762,17,'#527777','center');
 K.line(c,[[1238,741],[1325,741]],'#f3f5e7',1);K.line(c,[[1238,741],[1238,769]],'#f3f5e7',1);K.line(c,[[1326,741],[1326,770]],'#96b1ae',1);K.line(c,[[1239,770],[1326,770]],'#96b1ae',1);K.path(c,'M1334 752 L1339 757 L1344 752Z','#6e9095');
 const question='怎么还没到？',reply='路还在，先不聊。';let input=t<2.18?question.slice(0,Math.floor(K.clamp((t-.65)/1.4)*question.length)):typing?reply.slice(0,Math.floor(K.clamp((t-2.85)/1.65)*reply.length)):'';K.text(c,input+(Math.floor(t*3)%2?'│':''),504,762,22,'#668291');
 if(t>2.5&&t<4.2)K.text(c,t>3.45?'你又收到了一次窗口抖动。':'你收到了一次窗口抖动。',916,708,14,'#967d78','center');
 if(t>4.55)K.text(c,'消息已送达。对方继续骑行中。',914,708,14,'#77977c','center');
 if(typing)for(let i=0;i<3;i++)K.circle(c,1056+i*13,222,2.5+Math.max(0,Math.sin(t*6+i))*1.4,'#d3e8e7');
 // The attachment has open sides: its little road can escape onto the desktop.
 K.rect(c,255,383,6,292,'#c9dcda');K.rect(c,1366,383,6,292,'#a9c2ce');
 K.line(c,[[252,383],[264,383]],'#7d9a9f',2);K.line(c,[[1361,383],[1374,383]],'#7d9a9f',2);
 c.restore();
 // Keep the physical road steady while the chat window jiggles behind it.
 K.rect(c,170,678,1260,12,'rgba(57,81,73,.14)');K.rect(c,170,675,1260,9,K.gradient(c,[0,675],[0,684],[[0,'#dce5d7'],[1,'#b5c3b1']]));K.line(c,[[170,675],[1430,675]],'#8ca08b',1.7);K.line(c,[[170,684],[1430,684]],'#afc0ab',.8);
 for(let x=179;x<1417;x+=39)K.line(c,[[x,680],[x+12,680]],'rgba(118,142,118,.24)',.8);
 },pose(t){const shaking=(t>2.5&&t<2.82)||(t>3.45&&t<3.72);return{x:1600*t/6,y:675-102*.79,scale:.79,style:16,expression:t>2.5&&t<3.9?'surprised':'calm',gazeX:t>4.5?1:-.4,headNod:Math.sin(K.clamp((t-4.55)/.7)*Math.PI)*.1+(shaking?Math.sin(t*110)*.025:0)};}
};
// Four quarter-second tape repeats: exactly one half-beat per repeat at 120 BPM.
M.vaporClock=function(t){const f=u=>u<=.5?u-.2063*u*u:.448425+(u-.5)*.7937;if(t<2)return f(t);if(t<3)return f(2)+((t-2)%.25)*.7937;if(t<=5.5)return f(t)-.75*.7937;const u=t-5.5;return f(5.5)-.75*.7937+.7937*u+.2063*u*u;};
M.vaporRate=t=>t<.5?1-.4126*t:t>5.5?.7937+.4126*(t-5.5):.7937;
P.scenes[17]={title:'蒸汽波',en:'PLEASE DO NOT ADJUST YOUR TAPE',date:'2010s',style:17,dark:true,accent:'#ffb1e1',
 draw(c,t){const bustReady=P.hasCharacterAsset&&P.hasCharacterAsset('vapor_bust');M.bg(c,bustReady?'vapor-r8-bust-stage':'vapor-r6-sunset',d=>{
 const dusk=K.gradient(d,[0,0],[0,565],[[0,'#111051'],[.34,'#52218c'],[.70,'#d62a95'],[1,'#ff8d78']]);K.rect(d,0,0,1600,900,dusk);const halo=d.createRadialGradient(1045,328,100,1045,328,295);halo.addColorStop(0,'rgba(255,160,103,.32)');halo.addColorStop(1,'rgba(255,97,143,0)');K.rect(d,735,20,620,615,halo);
 K.path(d,'M0 462 C115 437 172 467 278 442 C393 408 430 455 528 434 C677 396 752 444 848 414 C958 386 1065 433 1168 412 C1338 379 1441 437 1600 399 L1600 542 L0 542Z','#b52c91');
 K.path(d,'M0 495 C135 466 236 497 335 472 C509 434 610 489 762 459 C903 436 1000 473 1151 451 C1360 412 1483 461 1600 445 L1600 553 L0 553Z','#ec4a99');
 for(let i=0;i<8;i++){let y=478+i*8;K.path(d,`M-20 ${y} C178 ${y-18} 279 ${y+8} 433 ${y-13} S773 ${y+6} 979 ${y-12} S1390 ${y+2} 1615 ${y-11}`,null,i%2?'#ff9cac':'#bd3e96',.8);}
 K.circle(d,1045,328,144,K.gradient(d,[1045,184],[1045,472],[[0,'#fff299'],[.42,'#ffdb4d'],[1,'#ffae50']]));
 d.save();d.beginPath();d.arc(1045,328,144,0,Math.PI*2);d.clip();for(let i=0;i<9;i++)K.rect(d,894,330+i*18,304,4+i,dusk);d.restore();K.path(d,'M946 223 Q1029 166 1126 213',null,'rgba(255,250,188,.58)',1.4);
 K.path(d,'M0 551 L0 529 L80 529 L80 517 L127 517 L127 535 L182 535 L182 525 L228 525 L228 551 L1600 551 L1600 535 L1520 535 L1520 523 L1478 523 L1478 544 L1426 544 L1426 533 L1373 533 L1373 552Z','#562367');
 // A colonnade is drawn as stone courses, cornices and open arches.
 K.rect(d,340,531,486,16,'#8150a9','#482867',1);K.rect(d,350,523,466,8,'#eda6cd','#7c438e',.8);
 for(let i=0;i<6;i++)M.classicColumn(d,369+i*83,523,104,17,i%2?'#9c70c0':'#bc83c9');
 for(let i=0;i<5;i++){let x=369+i*83;K.path(d,`M${x+11} 463 L${x+11} 441 Q${x+41.5} 395 ${x+72} 441 L${x+72} 463 L${x+66} 463 L${x+66} 443 Q${x+41.5} 409 ${x+17} 443 L${x+17} 463Z`,'#d68fc5','#653a83',1);for(let j=0;j<5;j++){let aa=Math.PI+j*Math.PI/4;K.line(d,[[x+41.5+Math.cos(aa)*32,444+Math.sin(aa)*39],[x+41.5+Math.cos(aa)*38,444+Math.sin(aa)*46]],'#9553a3',.7);}}
 K.rect(d,349,407,467,8,'#ffb3d3','#7a458d',.8);K.rect(d,344,401,478,5,'#a36fb9','#5e3281',.8);for(let i=0;i<35;i++)K.rect(d,354+i*13,415,5,5,'#f0a1cd');
 M.palmFine(d,287,550,.58,-1,true);M.palmFine(d,849,550,.48,1,true);M.palmFine(d,1127,550,.59,-1,true);
 K.rect(d,0,550,1600,350,'#0d123c');
 // Each polished stone tile is projected to the same vanishing point as its grout.
 for(let row=0;row<11;row++){const f0=(row/11)**1.85,f1=((row+1)/11)**1.85,y0=550+f0*350,y1=550+f1*350;for(let col=0;col<19;col++){const xa=-1040+col*220,xb=xa+220,pts=[[800+(xa-800)*f0,y0],[800+(xb-800)*f0,y0],[800+(xb-800)*f1,y1],[800+(xa-800)*f1,y1]];K.line(d,pts,null,1,true,(row+col)%2?'#1d1447':'#12143c');if(row>3&&(row+col)%4===0){const yy=y0+(y1-y0)*.63,ff=f0+(f1-f0)*.63;K.line(d,[[800+(xa-776)*ff,yy],[800+(xb-826)*ff,yy]],'rgba(155,122,164,.12)',1.2);}}}
 K.line(d,[[0,550],[1600,550]],'#ffa0cf',1.6);K.line(d,[[0,557],[1600,557]],'#6f3bad',1);

 const horizon=[800,550];for(let i=0;i<19;i++){let x=-1040+i*220;K.line(d,[horizon,[x,900]],i%2?'#367ce1':'#344eb3',1.05);K.line(d,[[800,551],[x+2,900]],'rgba(107,201,255,.24)',.5);}
 for(let i=1;i<12;i++){let y=550+(i/11)**1.85*350;K.line(d,[[0,y],[1600,y]],i%2?'#385bc9':'#666fe6',1.05);K.line(d,[[0,y+2],[1600,y+2]],'rgba(9,10,39,.7)',.7);}
 // Narrow broken reflections keep the floor quiet enough for the bike silhouette.
 const sunFloor=K.gradient(d,[1045,552],[1045,820],[[0,'rgba(255,114,157,.25)'],[1,'rgba(240,62,160,0)']]);K.path(d,'M981 552 L1109 552 L1288 820 L811 820Z',sunFloor);for(let i=0;i<15;i++){let y=562+i*11,w=139+i*9;K.line(d,[[1045-w*.5,y],[1045+w*.5,y]],`rgba(255,${175-i*3},${96+i*4},${.34-i*.017})`,3.2-i*.1);}
 for(let i=0;i<6;i++){let x=369+i*83;K.path(d,`M${x-5} 554 L${x-10} 590 L${x+8} 590 L${x+5} 554Z`,'rgba(181,139,175,.09)');K.line(d,[[x-10,573],[x+8,573]],'#382060',1);}
 // Foreground palms now meet the floor at their visible roots; their reflections
 // are compressed below that contact, not pasted into the sky or the cyclist's lane.
 for(const [x,y,sc,fl]of [[64,642,1.18,1],[1565,638,1.08,-1]]){d.save();d.beginPath();d.rect(0,y,1600,900-y);d.clip();d.globalAlpha=.16;d.transform(1,0,0,-.48,0,y*1.48);M.palmFine(d,x,y,sc,fl);d.restore();K.ellipse(d,x,y+3,55*sc,7,'rgba(13,15,41,.31)');M.palmFine(d,x,y,sc,fl);}
 // The arcade leaves a faint complete reflection between the first few grout lines.
 d.save();d.globalAlpha=.08;d.transform(1,0,0,-.52,0,550*1.52);for(let i=0;i<6;i++)M.classicColumn(d,369+i*83,523,104,17,'#d291e1');d.restore();
 // Marble pedestal: a cap, entasis, deep flutes, base mouldings and a few fissures.
 K.ellipse(d,1337,796,152,13,'rgba(10,17,39,.28)');K.path(d,'M1210 791 L1241 610 L1430 610 L1461 791Z','#b7d7e4','#577bad',1.8);K.path(d,'M1210 791 L1241 610 L1270 610 L1241 791Z','#7eaad2');K.path(d,'M1410 611 L1430 610 L1461 791 L1433 791Z','#c784c6');
 for(let i=0;i<10;i++){let x=1250+i*18,y=619,bx=1228+i*23;K.path(d,`M${x} ${y} Q${x-5} 697 ${bx} 783`,null,i%2?'#7899c3':'#fff0da',3.1);K.path(d,`M${x+3} ${y} Q${x-1} 697 ${bx+4} 783`,null,'#9cb9d7',.9);}
 K.path(d,'M1229 607 L1440 607 L1450 618 L1218 618Z','#abdce5','#5276aa',1.4);K.rect(d,1225,598,220,10,'#ffefd6','#6b8fb3',1.1);K.path(d,'M1201 792 L1469 792 L1478 803 L1193 803Z','#b2bfe2','#697db3',1.2);K.rect(d,1202,784,266,7,'#ffe6d4','#7b94b9',.8);K.line(d,[[1198,798],[1471,798]],'#efdbf2',1);
 K.path(d,'M1295 640 L1290 670 L1296 681 L1287 706 M1407 738 L1412 752 L1408 769',null,'#91a6b7',.75);
 // Overlapping carved folds follow the shoulder and the weight of the draped cloth.
 if(!bustReady){
 K.path(d,'M1189 597 Q1199 550 1230 530 L1287 502 L1292 456 L1372 456 L1378 497 Q1418 514 1443 534 Q1471 561 1482 597Z','#afd8e4','#5b79b2',2.1);
 K.path(d,'M1290 484 L1293 454 L1368 455 L1377 495 Q1351 520 1322 517Z','#fff0d9','#83afcb',1.1);K.path(d,'M1294 462 L1311 488 Q1340 505 1372 483 L1377 496 Q1333 532 1290 496Z','#81b6d5');
 K.path(d,'M1200 589 Q1237 547 1294 516 Q1313 524 1328 526 Q1265 559 1240 595Z','#83b1d9','#587bb3',1.2);
 K.path(d,'M1251 596 Q1296 546 1379 503 Q1416 511 1439 533 Q1389 549 1357 596Z','#f2dfdc','#6f9ac3',1.1);
 K.path(d,'M1360 598 Q1394 559 1440 540 Q1462 565 1476 597Z','#abd7df','#5b80b8',1.1);
 const folds=['M1209 588 Q1255 539 1287 529','M1223 592 Q1265 551 1306 531','M1258 593 Q1299 552 1349 525','M1276 595 Q1327 550 1372 517','M1310 596 Q1353 560 1402 537','M1345 596 Q1361 572 1417 546','M1393 590 Q1426 560 1446 553','M1411 594 Q1439 574 1456 568'];
 folds.forEach((path,i)=>{K.path(d,path,null,i%2?'#79abd0':'#fff1d7',2.1);K.path(d,path,null,i%2?'#7097c6':'#e8e3e5',.7);});
 K.path(d,'M1205 579 Q1224 559 1241 555 M1436 521 L1446 535 L1440 543',null,'#ffabd4',1.3);K.path(d,'M1248 533 Q1268 522 1282 519',null,'#74edec',1.4);
 // Branching veins belong to the marble block and stop at its carved silhouette.
 d.save();d.clip(new Path2D('M1189 597 Q1199 550 1230 530 L1287 502 L1292 456 L1372 456 L1378 497 Q1418 514 1443 534 Q1471 561 1482 597Z'));
 K.path(d,'M1178 553 C1220 544 1228 572 1263 561 Q1294 556 1317 577 L1341 583 M1263 561 L1279 541 L1295 538 M1393 503 Q1401 533 1426 540 Q1442 548 1435 572 L1448 594 M1426 540 L1445 531',null,'rgba(110,151,173,.41)',1.05);K.path(d,'M1183 551 C1220 542 1230 570 1263 559 Q1294 554 1317 575',null,'rgba(242,239,218,.7)',.75);d.restore();
 }
 K.path(d,'M1237 618 Q1241 650 1227 678 Q1239 698 1222 727 M1227 678 L1252 687 M1418 622 Q1403 657 1422 682 Q1432 706 1427 732 M1422 682 L1406 694',null,'#86a6b9',.85);
 K.ellipse(d,1337,709,23,17,'#c6d4d3','#8ca8b7',1);K.ellipse(d,1337,709,19,13,null,'#e8e8db',.8);K.path(d,'M1322 714 Q1323 701 1332 698 M1352 714 Q1351 701 1342 698 M1325 710 l-5 -3 m7 -2 l-4 -5 M1349 710 l5 -3 m-7 -2 l4 -5',null,'#8aa8b3',.8);K.path(d,'M1333 715 L1337 703 L1341 715 M1335 710 L1339 710',null,'#7497aa',.85);
 // The plinth is reflected only below its own contact plane.
 K.path(d,'M1193 804 L1478 804 L1455 883 L1217 883Z','rgba(187,196,214,.095)');for(let i=0;i<8;i++)K.line(d,[[1220+i*31,810],[1232+i*27,878]],'rgba(212,211,218,.12)',1.1);

 });
 if(bustReady){
  P.drawCharacter(c,'vapor_bust',t,{x:1336,y:598,height:342,phase:K.ease((t-1.8)/1.35)});
 }else if(!(P.hasArtAsset&&P.hasArtAsset(17))){
 c.save();c.translate(1338,478);const tapeTime=M.vaporClock(t),loop=t>=2&&t<3,loopPhase=loop?((t-2)%.25)/.25:0,stoneNod=loop?Math.sin(loopPhase*Math.PI)*.028:Math.sin(K.clamp((t-3)/.6)*Math.PI)*-.035;c.rotate(stoneNod);c.translate(0,-80);const turn=K.ease((tapeTime-1.0)/1.1);c.scale(1-turn*.13,1);c.translate(-turn*9,0);
 // Asymmetric silhouette, broad planes, brows, eyelids and curls are all drawn.
 K.path(c,'M-55 -63 Q-68 -19 -51 17 Q-54 46 -28 67 L-7 80 Q21 83 46 56 L65 11 L68 -46 Q65 -93 21 -110 Q-27 -122 -55 -63Z','#e8e5e1','#5b80b8',2.1);
 K.path(c,'M-55 -63 Q-66 -20 -51 17 Q-49 40 -30 61 L-6 75 L6 55 Q-24 38 -25 4 L-17 -55 L-4 -97 Q-38 -94 -55 -63Z','#8cb9da');K.path(c,'M21 -104 Q59 -90 63 -49 L54 -9 L48 34 L24 62 L6 70 L27 70 L46 53 L65 11 L68 -46 Q62 -92 21 -104Z','#dcb4d6');
 K.path(c,'M-26 -57 Q-8 -80 16 -71 L34 -48 L16 -29 L-5 -32Z','#fff2da');K.path(c,'M-17 2 Q-13 27 7 36 L-10 48 L-29 26 L-29 4Z','#b0c9e0');K.path(c,'M23 -16 L45 -29 L52 -9 L40 16 L24 18Z','#ffead5');
 K.ellipse(c,-55,-7,11,24,'#a5c2cc','#557caf',1.2);K.path(c,'M-56 -23 Q-66 -10 -53 3 Q-60 14 -50 14 M-57 -13 Q-47 -16 -49 -4',null,'#7195a7',1.1);K.path(c,'M-61 -20 Q-63 0 -57 8',null,'#d6e3db',1);
 const curls=[[-54,-78,17,20,-.3],[-58,-103,18,17,.3],[-39,-118,21,18,-.2],[-11,-124,20,17,.2],[16,-125,20,17,-.1],[40,-117,20,18,.2],[61,-101,17,19,.3],[70,-77,16,19,.2],[-38,-91,16,16,0],[-13,-99,19,17,-.1],[13,-98,17,17,.2],[39,-91,18,17,-.2],[55,-70,14,18,.4],[-51,-56,12,17,-.2]];
 curls.forEach(([x,y,rx,ry,a],i)=>{K.ellipse(c,x,y,rx,ry,['#a6cadd','#ebe7dd','#99bdd8','#d2dbe1'][i%4],'#7194bd',1,a);K.path(c,`M${x-rx*.5} ${y+ry*.4} C${x-rx*.85} ${y-ry*.3} ${x-rx*.15} ${y-ry*.8} ${x+rx*.35} ${y-ry*.4} Q${x+rx*.76} ${y+ry*.1} ${x+rx*.1} ${y+ry*.3} Q${x-rx*.25} ${y+ry*.3} ${x-rx*.2} ${y-ry*.15}`,null,'#537db4',.9);K.path(c,`M${x-rx*.45} ${y-ry*.42} Q${x} ${y-ry*.75} ${x+rx*.48} ${y-ry*.1}`,null,'#fff0db',1.1);});
 const nx=-turn*13;K.path(c,`M${5+nx} -40 Q${-1+nx} -10 ${-5+nx} 11 L${11+nx} 16 L${23+nx} 7`,null,'#7f9eae',2);K.path(c,`M${8+nx} -37 L${9+nx} 7 L${17+nx} 10`,null,'#fff1d3',1.6);K.path(c,`M${-1+nx} 14 Q${5+nx} 8 ${8+nx} 15 M${17+nx} 13 L${22+nx} 10`,null,'#688ea3',1);
 K.path(c,'M-41 -34 Q-25 -44 -9 -35 M19 -35 Q35 -47 49 -35',null,'#7e9eaf',3);K.path(c,'M-41 -29 Q-26 -37 -12 -29 Q-25 -22 -39 -27 M20 -30 Q35 -38 49 -31 Q37 -23 22 -27',null,'#6f91a6',1.2);K.circle(c,-25-turn*4,-29,2.3,'#829ba9');K.circle(c,35-turn*4,-30,2.3,'#829ba9');K.line(c,[[-27-turn*4,-31],[-25-turn*4,-31]],'#d3e4dc',.7);K.path(c,'M-39 -20 Q-27 -15 -16 -20 M24 -20 Q38 -17 48 -22',null,'#aec5cd',.85);
 K.path(c,'M-10 37 Q-1 31 6 35 Q15 33 27 36 Q12 44 -4 41Z','#a3bac4','#859eac',.85);K.path(c,'M-9 37 Q8 39 27 36',null,'#6d8d9f',1.1);K.path(c,'M-1 46 Q12 49 23 43 M-16 63 Q4 72 25 61',null,'#e9ece0',1.3);K.path(c,'M-38 8 Q-32 14 -27 25 M45 13 Q37 25 32 30',null,'#a3bec7',.9);
 K.path(c,'M-46 -45 Q-31 -51 -17 -44 M18 -46 Q34 -55 49 -44',null,'#f0eddf',1.4);K.path(c,'M-43 4 Q-36 14 -35 29 L-28 36 M31 21 Q24 29 21 35',null,'#95b5c1',1.2);K.path(c,'M-18 57 Q-3 62 11 56 M14 -74 L18 -62 L10 -54',null,'#9bb8c1',.75);
 K.path(c,'M-42 -7 L-36 4 L-40 16 M37 -67 L42 -57',null,'#93aebb',.65);K.path(c,'M-52 -15 Q-49 25 -27 50',null,'#6fe7ef',1);K.path(c,'M57 -30 Q57 12 42 36',null,'#f18fc7',1.1);c.restore();
 }else{
 const shine=.12+.06*Math.sin(t*2);K.ellipse(c,1354,285,2.2,1.2,`rgba(194,255,242,${shine})`);K.ellipse(c,1407,285,2.2,1.2,`rgba(255,221,243,${shine})`);
 }
 const rp=P.sceneContext&&P.sceneContext.rider;if(rp){c.save();c.beginPath();c.rect(0,745,1600,155);c.clip();c.transform(1,0,0,-.33,0,745*1.33);P.drawRider(c,P.sceneContext.absolute,Object.assign({},rp,{style:17,alpha:.14,shadow:false}));c.restore();}
 // The reels, soundtrack and rider share the same tape hiccup.
 const tape=M.vaporClock(t);
 M.round(c,78,655,245,139,5,'#2a1649','#ba8be0',2);K.line(c,[[83,659],[317,659]],'#f4b8e2',1);K.line(c,[[81,660],[81,787]],'#8c739c',1);K.rect(c,91,669,219,42,'#d99bc8','#6e5a88',1);K.rect(c,96,673,209,3,'#ffd2df');K.text(c,'SIDE A  /  FOREVER',200,695,15,'#302b4e','center','mono');K.text(c,'NORMAL · TYPE I',96,707,5.5,'#56466f','left','mono');K.text(c,'C—60',303,707,6,'#56466f','right','mono');M.round(c,105,719,192,49,3,'#211c3d','#8c7ca8',1.4);K.rect(c,111,723,180,6,'#3f3458');
 for(const [sx,sy]of [[86,663],[315,663],[86,786],[315,786]]){K.circle(c,sx,sy,2.8,'#c1afc4','#4b3c64',.8);K.line(c,[[sx-1.4,sy],[sx+1.4,sy]],'#504269',.6);}K.rect(c,169,724,63,38,'#372d50','#6f6288',.7);K.rect(c,174,728,53,30,'#161c35');K.line(c,[[176,730],[225,730]],'#85708f',.6);

 for(const x of [144,258]){K.circle(c,x,743,20,'#a8a4bd','#4c416b',2);K.circle(c,x,743,7,'#342b50');for(let i=0;i<5;i++){let a=tape*3+i*Math.PI*2/5;K.line(c,[[x+Math.cos(a)*10,743+Math.sin(a)*10],[x+Math.cos(a)*17,743+Math.sin(a)*17]],'#4c416b',3);}}
 K.line(c,[[164,743],[238,743]],'#7c8eae',3);K.path(c,'M120 785 L139 768 L267 768 L286 785Z','#827b9f','#b2a8bc',1);
 K.line(c,[[126,782],[280,782]],'#c7b5c5',.75);for(const xx of [145,260]){K.circle(c,xx,776,3.5,'#211d3b','#a194b2',.7);K.circle(c,xx,776,1.2,'#9fa4ba');}for(let j=0;j<8;j++){const xx=178+j*6;K.rect(c,xx,752,3,3,'#5c5278');}
 const slip=t>=2&&t<3?.35+.65*Math.sin(((t-2)%.25)/.25*Math.PI):Math.sin(K.clamp((t-3)/.4)*Math.PI)*.28;if(slip>0){K.path(c,`M258 766 C${282+slip*54} ${776+slip*10} ${289+slip*21} ${802+slip*29} 243 794 C222 785 224 777 235 774`,null,'#9e779f',2.4);K.path(c,`M258 767 C${282+slip*54} ${777+slip*10} ${289+slip*21} ${803+slip*29} 243 795`,null,'#d1a1bb',.6);}

 // A tiny, believable transport shows the repeated half-beat, not a generic glitch overlay.
 M.round(c,92,608,216,37,4,'#24203e','#9477aa',1);K.circle(c,108,626,3,t>=2&&t<3?'#ffae94':'#91dcd1');K.text(c,t>=2&&t<3?'LOOP '+(1+Math.floor((t-2)/.25))+'/4':'PLAY  '+M.vaporRate(t).toFixed(4)+'×',121,631,12,'#e4c5db','left','mono');
 for(let j=0;j<10;j++){const peak=.5+.5*Math.sin(tape*8+j*.66),h=4+peak*13;K.rect(c,252+j*4.1,636-h,2.8,h,j<7?'#8bd8cc':'#e7b0cf');}
 if(t>=2&&t<3){const u=((t-2)%.25)/.25;c.save();c.globalAlpha=.4*(1-u);K.path(c,'M1367 270 q17 -13 27 2 M1373 275 q10 -7 17 1',null,'#c2e7e5',1.2);c.restore();}
 const scan=(t*110)%900;K.rect(c,0,scan,1600,2,'rgba(213,236,243,.13)');
 for(let i=0;i<5;i++){let y=559+((t*32+i*61)%286);K.line(c,[[0,y],[1160,y]],'rgba(177,113,179,.12)',1);}
 K.text(c,t>2.7&&t<3.5?'REPEAT  REPEAT  REPEAT':'PLAY  ▷  00:00:0'+Math.floor(t),1515,807,17,'#ffbce7','right','mono');
 },pose(t){let slowed=t<2.7?t*.8:t<3.5?2.16+((t-2.7)%.2)*.8:t*.8-.64;return{x:692+t*28,y:627,scale:1.15,style:17,phaseTime:slowed,gazeX:1,gazeY:-.15,headNod:-Math.sin(K.clamp((t-1.95)/1.2)*Math.PI)*.09};},
 ground(){return 745;},roadColor:'#181442',roadInk:'#6974d8'
};

P.scenes[18]={title:'竖屏时代',en:'SIX THOUSAND YEARS IN SIX SECONDS',date:'2020s',style:18,dark:true,accent:'#b8fcbb',
 riderClip:{x:585,y:114,w:430,h:623},ground(){return 703;},roadColor:'#ccb996',roadInk:'#8a9b7b',
 draw(c,t){M.bg(c,'short-r3-through-road',d=>{
 K.rect(d,0,0,1600,900,'#10131b');for(let i=7;i>0;i--)K.ellipse(d,1120,500,i*55,i*50,'rgba(114,81,149,.022)');for(let i=7;i>0;i--)K.ellipse(d,470,640,i*50,i*40,'rgba(76,138,117,.018)');
 K.rect(d,582,62,436,772,'#778f86','#c3cfc1',2);K.rect(d,584,64,432,768,K.gradient(d,[584,64],[584,831],[[0,'#b3d2cf'],[.5,'#d9d8b3'],[.51,'#b5bf8e'],[1,'#8b9f7f']]));K.circle(d,899,240,62,'#f2e5b5');
 d.save();d.beginPath();d.rect(584,64,432,768);d.clip();for(let i=0;i<6;i++){let x=610+i*100;K.path(d,`M${x-70} 496 L${x} ${350+i%2*30} L${x+98} 496Z`,i%2?'#8ba99d':'#93b4a8');}
 for(let j=0;j<6;j++){let y=540+j*25;K.path(d,`M576 ${y} Q760 ${y-24} 1028 ${y+16}`,null,j%2?'#9fab7e':'#c4c898',4);}
 for(let i=0;i<5;i++){let x=568+i*122,y=606;K.line(d,[[x,y],[x-3,y-92]],'#6d8366',7);K.ellipse(d,x,y-99,35,50,'#7f9b70');K.ellipse(d,x-17,y-89,27,35,'#8fa877');for(let j=0;j<4;j++)K.circle(d,x+Math.cos(j*2)*19,y-99+Math.sin(j*2)*28,3,'#d3b77e');}
 K.path(d,'M584 703 L1016 703 L1016 832 L584 832Z','#ccb996');for(let i=0;i<40;i++){let x=584+K.rnd(i+47)*432,y=730+K.rnd(i+991)*94;K.ellipse(d,x,y,1.5+K.rnd(i)*4,1,'#9da581');}d.restore();
 K.text(d,'画面已旋转',1116,400,29,'#b3c1bc');K.text(d,'耐心没有。',1116,447,29,'#b3c1bc');K.text(d,'6000 年',158,553,52,'#e5e8db','left','serif','600');K.text(d,'浓缩成 6 秒',160,598,24,'#7f948e');
 K.line(d,[[1116,477],[1361,477]],'#2a3e3b',1);K.text(d,'等一下，他好像看镜头了。',1116,509,17,'#6f9587');
 // Open the phone's side rails at the rider's height, and carry its path through.
 K.rect(d,580,390,5,313,'#10131b');K.rect(d,1015,390,5,313,'#10131b');
 K.line(d,[[577,390],[586,390]],'#9cbca3',2);K.line(d,[[1014,390],[1023,390]],'#9cbca3',2);
 K.rect(d,170,703,1260,12,K.gradient(d,[0,703],[0,715],[[0,'#b8b58d'],[.28,'#89936e'],[1,'#303c36']]));
 K.line(d,[[170,703],[1430,703]],'#c0c29b',1.4);K.line(d,[[170,716],[1430,716]],'rgba(92,126,104,.35)',1);
 for(let x=178;x<1417;x+=43)K.line(d,[[x,708],[x+12,708]],'rgba(61,81,63,.22)',.8);
 });
 c.save();c.beginPath();c.rect(585,114,430,623);c.clip();for(let i=0;i<3;i++){let x=655+i*140-t*7,y=286+(i%2)*34;K.cloud(c,x,y,.4,'rgba(239,240,211,.48)');}c.restore();
 K.text(c,'飞羽  /  正在直播历史',602,106,17,'#f9fbef','left','sans','600');K.rect(c,588,810,424*K.clamp(t/6),4,'#c9f9b5');
 M.heart(c,982,655,.7,t>2.4?'#ed9e9e':'#fff4ed');const likes=12+Math.floor(Math.max(0,t-2.4)**2*487);K.text(c,likes.toLocaleString(),982,700,17,'#fff7e7','center');
 K.text(c,'@骑了很久',604,752,19,'#f7f9ee','left','sans','700');K.text(c,t>3.8?'这一眼，晚了六千年。':'建议从公元前开始看。',604,782,17,'#f7f9ee');
 if(t>2.4&&t<3.35){c.save();c.globalAlpha=K.ease((t-2.4)/.13)*K.ease((3.35-t)/.15);K.rect(c,671,290,258,59,'#f4f8cd');K.text(c,'他看镜头了',800,330,30,'#263d3b','center','sans','700');K.rect(c,914,144,83,27,'#2e514b');K.text(c,t<2.9?'0.25×':'1.00×',956,163,15,'#dfedce','center','mono');c.restore();}
 },pose(t){const nod=Math.sin(K.clamp((t-2.25)/.95)*Math.PI),phase=t<2.4?t:t<2.9?2.4+(t-2.4)*.25:t-.375;return{x:786+t*6,y:625,scale:.76,style:18,phaseTime:phase,gazeX:1-1.6*nod,gazeY:.15*nod,headNod:.12*nod,bellPress:Math.sin(K.clamp((t-2.4)/.42)*Math.PI),brakeLean:nod*.18};},
 foreground(c,t,a,p){c.save();c.beginPath();c.rect(586,117,427,619);c.clip();
 // Hearts are a consequence of the glance and bell, rather than a constant unrelated particle stream.
 for(let i=0;i<29;i++){let born=2.45+i*.105,age=t-born;if(age<0||age>2.5)continue;let x=973+Math.sin(age*2.3+i*.8)*14,y=643-age*143;c.save();c.globalAlpha=K.clamp(1-age/2.5);M.heart(c,x,y,.34+i%3*.1,['#f09a9d','#fff3cb','#dfb2de'][i%3]);c.restore();}
 if(t>2.25&&t<3.5){const pose=p||this.pose(t,a),sc=pose.scale||.76,x=pose.x+48*sc,y=pose.y-259*sc,r=38,u=K.ease((t-2.25)/.2)*K.ease((3.5-t)/.3);c.globalAlpha=u*.65;for(const [sx,sy] of [[-1,-1],[1,-1],[-1,1],[1,1]])K.line(c,[[x+sx*r,y+sy*(r-11)],[x+sx*r,y+sy*r],[x+sx*(r-11),y+sy*r]],'#f5f3cd',1.6);}
 c.restore();}
};
P.scenes[19]={title:'代码写到这里',en:'WRITE THE ROAD. THEN RIDE IT.',date:'NOW',style:19,dark:true,accent:'#9ee7c2',
 riderClip:{x:112,y:469,w:1420,h:284},ground(x){return M.codeFloor(x);},roadColor:'#294453',roadInk:'#8fd4bf',
 travelX(t){const q=t<3.1?t:t<3.65?3.1:t-.55;return 1600*q/5.45;},
 draw(c,t){M.bg(c,'code-r3-wide',d=>{
 K.rect(d,0,0,1600,900,K.gradient(d,[0,0],[1600,900],[[0,'#17262f'],[.6,'#101d27'],[1,'#22373a']]));M.round(d,52,178,1500,635,11,'#0e1922','#5d7779',1.5);M.round(d,53,179,1498,42,10,'#243844');K.rect(d,54,210,1496,12,'#243844');for(let i=0;i<3;i++)K.circle(d,78+i*19,199,5,['#d98c81','#d5bb7d','#8eb493'][i]);K.text(d,'pelican — art-history',796,205,13,'#9bb6b7','center','mono');K.circle(d,1495,198,6,null,'#abc4c0',1.3);K.line(d,[[1500,203],[1505,208]],'#abc4c0',1.3);
 K.rect(d,54,222,47,555,'#172833');K.rect(d,102,222,162,217,'#1a2c37');K.line(d,[[264,222],[264,439]],'#36505b',1);K.rect(d,265,222,1284,42,'#1a2b36');K.rect(d,265,222,166,42,'#12222c');K.line(d,[[265,222],[431,222]],'#9bd4ba',2);K.text(d,'JS',280,248,15,'#e7c486','left','mono','700');K.text(d,'motion.js',311,248,14,'#c6dad5','left','mono');K.text(d,'×',414,248,15,'#7f9b9f','center','mono');K.text(d,'◇  road.svg',448,248,14,'#7c9ca0','left','mono');K.text(d,'src  ›  motion.js  ›  ride',719,247,12,'#7f9fa2','left','mono');
 K.text(d,'EXPLORER',117,249,11,'#a8bebc','left','mono','600');K.text(d,'⌄  PELICAN',116,285,12,'#b8ccbd','left','mono','700');K.rect(d,103,312,160,26,'#29414c');const files=[['⌄ src','#87a7a6'],['  JS motion.js','#e5c17d'],['  ◇ road.svg','#8cc9bd'],['  ◇ rider.svg','#8cc9bd'],['› assets','#87a7a6']];for(let i=0;i<files.length;i++)K.text(d,files[i][0],122,308+i*26,12,files[i][1],'left','mono');
 K.rect(d,68,245,18,22,null,'#bdd1c6',1.6);K.rect(d,73,240,18,22,null,'#bdd1c6',1.6);K.rect(d,55,236,2,37,'#a5d2bc');K.circle(d,78,302,9,null,'#68878c',1.8);K.line(d,[[84,308],[90,316]],'#68878c',2);K.circle(d,72,350,3,null,'#68878c',1.6);K.circle(d,86,366,3,null,'#68878c',1.6);K.circle(d,71,378,3,null,'#68878c',1.6);K.path(d,'M72 353 L72 375 M72 359 Q87 359 86 363',null,'#68878c',1.6);K.line(d,[[71,410],[87,422],[71,434],[71,410]],'#68878c',1.6);K.circle(d,78,739,9,null,'#68878c',1.6);for(let j=0;j<8;j++){let a=j*Math.PI/4;K.line(d,[[78+Math.cos(a)*9,739+Math.sin(a)*9],[78+Math.cos(a)*13,739+Math.sin(a)*13]],'#68878c',2);}
 K.line(d,[[874,267],[874,438]],'#263d47',1);for(let i=0;i<21;i++){let y=282+i*7,w=13+(i*17)%29;K.rect(d,1490,y,w,2,['#6e9c9a','#9ca879','#a381a2','#8d9cb3'][i%4]);}K.rect(d,1485,277,52,103,'rgba(120,160,156,.07)','#4b6d70',.7);
 K.rect(d,102,440,1447,31,'#213740');K.text(d,'LIVE PREVIEW',121,461,11,'#aecdc3','left','mono','700');K.text(d,'road.svg  /  1600 × 900',1480,461,11,'#749e98','right','mono');K.circle(d,1520,454,3.5,'#92d0a6');
 K.rect(d,112,472,1420,281,K.gradient(d,[112,472],[1532,753],[[0,'#17323c'],[1,'#10242c']]),'#304d57',1);for(let x=131;x<1532;x+=25)K.line(d,[[x,473],[x,752]],'rgba(136,176,167,.05)',1);for(let y=489;y<753;y+=25)K.line(d,[[113,y],[1531,y]],'rgba(136,176,167,.05)',1);
 K.path(d,'M112 728 L1110 728 L1090 753 L112 753Z','#294b4b');K.path(d,'M1460 728 L1531 728 L1531 753 L1487 753Z','#294b4b');for(let i=0;i<68;i++){let x=123+i*14;K.line(d,[[x,738],[x+7,750]],'#3a5f58',.8);}K.line(d,[[112,728],[1110,728]],'#82b49e',2);K.line(d,[[1460,728],[1531,728]],'#82b49e',2);
 K.rect(d,102,754,1447,23,'#162b33');K.text(d,'DEBUG CONSOLE',121,769,10,'#7caaa0','left','mono');K.rect(d,54,778,1496,33,'#2c4c54');K.text(d,'⑂  main*',73,800,12,'#b8d8c8','left','mono');K.text(d,'0 errors / 0 warnings',213,800,12,'#accab7','left','mono');K.text(d,'JavaScript    UTF-8    LF',1255,800,12,'#a1c4b8','right','mono');K.text(d,'60 fps',1493,800,12,'#a4d2b8','right','mono');
 });
 const typing=K.clamp((t-2.35)/.7),paused=t>=3.1&&t<3.65;
 const src=['// A road is just a path.','const rider = scene.find("pelican");','const road = new Path2D();','road.moveTo(936, 728);','road.lineTo(1110, 728);','road.quadraticCurveTo(1285, 644, 1460, 728);','rider.follow(road);','debugger;','rider.bell();','requestAnimationFrame(next);'];const active=t<2.35?4:t<3.05?5:t<3.1?6:paused?7:t<4.1?8:9;
 for(let i=0;i<src.length;i++){const right=i>=6,col=right?902:284,y=290+(right?i-6:i)*26,x=col+31;let line=src[i];if(i===5)line=line.slice(0,Math.floor(typing*line.length));if(i>5&&t<2.7)continue;if(i===active)K.rect(c,x-5,y-20,right?551:554,25,paused?'rgba(211,162,86,.15)':'rgba(102,161,151,.1)');K.text(c,String(i+1).padStart(2,'0'),col,y,12,i===active?'#bed2bd':'#4f727d','left','mono');const end=M.codeTokenLine(c,line,x,y,15.3);if(i===5&&t>=2.35&&t<3.05)K.rect(c,end+2,y-15,1.5,18,'#e4e8bb');}
 K.circle(c,888,311,4.4,paused?'#eab771':'#aa6d65');if(paused)K.path(c,'M925 308 L932 314 L925 320Z','#e6c18c');
 // The curve on the source line and the curve under the tires share one equation.
 const endX=1110+350*typing,pts=[];for(let x=1110;x<=endX;x+=3)pts.push([x,M.codeFloor(x)]);if(pts.length>1){c.save();c.shadowColor='#83ddbb';c.shadowBlur=5;K.line(c,pts,'#8bd5b6',3);c.shadowBlur=0;K.line(c,pts.map(([x,y])=>[x,y+6]),'#335e5d',7);K.line(c,pts,'#b4e5bd',1.2);c.restore();}
 if(typing>0&&typing<1){const y=M.codeFloor(endX);K.circle(c,endX,y,4,'#eff1bc');K.line(c,[[1110,728],[1285,644],[1460,728]],'rgba(104,178,160,.35)',1);for(const [x,y]of [[1110,728],[1285,644],[1460,728]])K.rect(c,x-3,y-3,6,6,'#9cc9b2','#203f42',1);K.text(c,'Q',1285,636,12,'#97cdb0','center','mono');const al=Math.sin(Math.PI*typing);c.save();c.globalAlpha=al*.6;K.path(c,`M847 421 C963 435 965 ${y-40} ${endX} ${y}`,null,'#a4ceb3',1);c.restore();}
 K.text(c,t<3.05?'› compiling road.svg…':paused?'II paused at motion.js:8':'▶ running · requestAnimationFrame',272,769,11,paused?'#e4bf81':'#9ec9b4','left','mono');K.text(c,'path.length = '+M.codePathLength(typing).toFixed(1),1040,769,11,'#6d9990','right','mono');K.text(c,paused?'velocity = 0':'velocity = 293.58 px/s',1481,769,11,paused?'#d1b385':'#6d9990','right','mono');
 M.round(c,1157,228,170,30,5,paused?'#4b4b3b':'#244746',paused?'#b99d68':'#5d9e88',1);K.text(c,paused?'II  BREAKPOINT':'▶  RUNNING',1242,249,12,paused?'#f4d3a0':'#c0e6c6','center','mono','700');if(paused){M.round(c,1343,228,84,30,5,'#304f50','#a7c6ad',1);K.text(c,'F10 →',1385,248,12,'#d7e7bc','center','mono');const u=(t-3.1)/.55;K.path(c,`M${1415-u*29} ${267-u*9} l7 14 l4 -7 l8 -2 Z`,'#f0e5bf','#172e34',1.1);}
 if(t>3.65&&t<4.15){c.save();c.globalAlpha=1-(t-3.65)/.5;K.text(c,'STEP OVER',1385,282,11,'#bddcba','center','mono');c.restore();}if(t>4.3){c.save();c.globalAlpha=K.ease((t-4.3)/.4);K.text(c,'路写好了。接着骑。',1240,531,23,'#d7e8d4','center','serif');c.restore();}
 },pose(t){const x=this.travelX(t),p=M.groundPose(x,.62,M.codeFloor),paused=t>=3.1&&t<3.65;return Object.assign(p,{style:19,alpha:1,build:1,shadow:false,gazeX:paused?-.3:1,gazeY:paused?-.8:0,headNod:paused?-.07:0,bellPress:Math.sin(K.clamp((t-4.05)/.38)*Math.PI)});},
 foreground(c,t,a,p){if(t>4.05&&t<4.8){const pose=p||this.pose(t),u=(t-4.05)/.75,sc=pose.scale,x=pose.x+108*sc,y=pose.y-137*sc;c.save();c.globalAlpha=1-u;for(let j=0;j<2;j++){c.beginPath();c.arc(x,y,10+j*8+u*24,-.8,.8);c.lineWidth=1;c.strokeStyle='#d6e6b3';c.stroke();}c.restore();}}
};

