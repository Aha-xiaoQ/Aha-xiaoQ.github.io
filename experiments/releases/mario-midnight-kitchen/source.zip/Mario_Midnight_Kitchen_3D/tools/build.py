from pathlib import Path
r=Path(__file__).resolve().parents[1]
s=(r/'src/shell.html').read_text(encoding='utf-8')
for f in (r/'src').glob('*.js'):s=s.replace('/*__'+f.name+'__*/',f.read_text(encoding='utf-8'))
(r/'Mario_Midnight_Kitchen_3D.html').write_text(s,encoding='utf-8',newline='')
print('Built 3D standalone HTML')
