/* Original, offline sound for Night Kitchen. No sampled or copyrighted music.
 * The final soft limiter and 0.24 master gain keep output comfortably bounded.
 * `stream` carries exactly the same mix as the speakers for actual-game capture.
 */
(function (root) {
  'use strict';

  class KitchenAudio {
    constructor() {
      this.ctx = null;
      this.muted = false;
      this.started = false;
      this._capture = null;
      this._nodes = [];
      this._voices = new Set();
      this._recent = Object.create(null);
      this._targets = new WeakMap();
      this._beatClock = 0;
      this._scoreClock = 0;
      this._roomClock = 0;
      this._chainClock = 0;
      this._chainBeat = 0;
      this._beat = 0;
      this._score = 0;
      this._threat = 0;
      this._state = { mode: 'menu', chase: false, threat: 0, chefDistance: 9999, time: 0, escapeAction: 'latched', pipe: null };
    }

    get stream() { return this._capture ? this._capture.stream : null; }
    get audioState() { return this.ctx ? this.ctx.state : 'locked'; }

    async start() {
      try {
        if (!this.ctx || this.ctx.state === 'closed') this._build();
        if (this.ctx.state !== 'running') await this.ctx.resume();
        this.started = this.ctx.state === 'running';
        this._smooth(this.master.gain, this.muted ? 0 : 0.24, 0.10);
        return this.started;
      } catch (err) {
        this.error = String(err && err.message || err);
        return false;
      }
    }

    _build() {
      const AudioContextClass = root.AudioContext || root.webkitAudioContext;
      if (!AudioContextClass) throw new Error('WebAudio is unavailable');
      const ctx = this.ctx = new AudioContextClass({ latencyHint: 'interactive' });
      this._nodes = [];
      this._voices.clear();
      this._targets = new WeakMap();
      this._recent = Object.create(null);
      this._beatClock = this._scoreClock = this._roomClock = 0;
      this._chainClock = this._chainBeat = 0;
      this._beat = this._score = 0;
      const compressor = ctx.createDynamicsCompressor();
      compressor.threshold.value = -18;
      compressor.knee.value = 20;
      compressor.ratio.value = 5;
      compressor.attack.value = 0.005;
      compressor.release.value = 0.20;
      const limiter = ctx.createWaveShaper();
      const curve = new Float32Array(4096);
      for (let i = 0; i < curve.length; i++) {
        const x = i / (curve.length - 1) * 2 - 1;
        curve[i] = Math.tanh(x * 1.35) / Math.tanh(1.35);
      }
      limiter.curve = curve;
      limiter.oversample = '2x';
      this.master = ctx.createGain();
      this.master.gain.value = 0;
      compressor.connect(limiter);
      limiter.connect(this.master);
      this.master.connect(ctx.destination);
      if (ctx.createMediaStreamDestination) {
        this._capture = ctx.createMediaStreamDestination();
        this.master.connect(this._capture);
      }
      this.ambience = ctx.createGain();
      this.music = ctx.createGain();
      this.effects = ctx.createGain();
      this.ambience.gain.value = 0.45;
      this.music.gain.value = 0.24;
      this.effects.gain.value = 0.82;
      this.ambience.connect(compressor);
      this.music.connect(compressor);
      this.effects.connect(compressor);

      // A short, dark room reflection. Feedback is deliberately very small.
      this.echo = ctx.createDelay(1);
      this.echo.delayTime.value = 0.163;
      const echoFilter = ctx.createBiquadFilter();
      echoFilter.type = 'lowpass';
      echoFilter.frequency.value = 1700;
      const feedback = ctx.createGain();
      feedback.gain.value = 0.18;
      const wet = ctx.createGain();
      wet.gain.value = 0.11;
      this.echo.connect(echoFilter);
      echoFilter.connect(feedback);
      feedback.connect(this.echo);
      echoFilter.connect(wet);
      wet.connect(compressor);

      const length = ctx.sampleRate * 4;
      this.noiseBuffer = ctx.createBuffer(1, length, ctx.sampleRate);
      const data = this.noiseBuffer.getChannelData(0);
      let seed = 0x714a7, slow = 0;
      for (let i = 0; i < length; i++) {
        seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
        const white = seed / 0x80000000 - 1;
        slow = slow * 0.984 + white * 0.016;
        data[i] = white * 0.22 + slow * 2.8;
      }
      // Continuous fridge motor, pipe overtone, and ventilation; no loop seams
      // matter after lowpass filtering, and oscillators never restart per frame.
      this.fridge = ctx.createGain();
      this.fridge.gain.value = 0.30;
      this.fridge.connect(this.ambience);
      this._continuousTone(54.4, 0.13, 'sine', this.fridge);
      this._continuousTone(108.9, 0.038, 'sine', this.fridge);
      this._continuousTone(163.5, 0.018, 'triangle', this.fridge);
      const lfo = ctx.createOscillator();
      const depth = ctx.createGain();
      lfo.frequency.value = 0.087;
      depth.gain.value = 0.045;
      lfo.connect(depth);
      depth.connect(this.fridge.gain);
      lfo.start();
      this._nodes.push(lfo, depth);
      const air = ctx.createBufferSource();
      air.buffer = this.noiseBuffer;
      air.loop = true;
      const airFilter = ctx.createBiquadFilter();
      airFilter.type = 'lowpass';
      airFilter.frequency.value = 820;
      const airGain = ctx.createGain();
      airGain.gain.value = 0.047;
      air.connect(airFilter);
      airFilter.connect(airGain);
      airGain.connect(this.ambience);
      air.start();
      this._nodes.push(air, airFilter, airGain);
      this.tension = ctx.createGain();
      this.tension.gain.value = 0;
      this.tension.connect(this.music);
      this._continuousTone(73.42, 0.11, 'sine', this.tension);
      this._continuousTone(77.78, 0.035, 'sine', this.tension);

      // A close chef has moving air and cloth around his weight. This is
      // filtered original noise, not a sampled voice. A continuous envelope
      // avoids switching or restarting a breath every rendered frame.
      this.chefBody = ctx.createGain();
      this.chefBody.gain.value = 0;
      this.chefBody.connect(this.effects);
      const breath = ctx.createBufferSource();
      breath.buffer = this.noiseBuffer;
      breath.loop = true;
      const chest = ctx.createBiquadFilter();
      chest.type = 'bandpass';
      chest.frequency.value = 285;
      chest.Q.value = 0.66;
      const mouth = ctx.createBiquadFilter();
      mouth.type = 'lowpass';
      mouth.frequency.value = 760;
      const breathEnvelope = ctx.createGain();
      breathEnvelope.gain.value = 0.52;
      this.breathLFO = ctx.createOscillator();
      this.breathLFO.frequency.value = 0.34;
      const breathDepth = ctx.createGain();
      breathDepth.gain.value = 0.40;
      this.breathLFO.connect(breathDepth);
      breathDepth.connect(breathEnvelope.gain);
      breath.connect(chest);
      chest.connect(mouth);
      mouth.connect(breathEnvelope);
      breathEnvelope.connect(this.chefBody);
      breath.start();
      this.breathLFO.start();
      this._nodes.push(breath, chest, mouth, breathEnvelope, this.breathLFO, breathDepth);

      // The conveyor motor stays underneath individual link contacts. Idle
      // power is quieter than a loaded, moving chain; no looping sample seam.
      this.chainMotor = ctx.createGain();
      this.chainMotor.gain.value = 0;
      this.chainMotor.connect(this.effects);
      this._continuousTone(61.5, 0.075, 'sine', this.chainMotor);
      this._continuousTone(123.8, 0.018, 'triangle', this.chainMotor);
    }

    _continuousTone(frequency, volume, type, bus) {
      const oscillator = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      oscillator.type = type;
      oscillator.frequency.value = frequency;
      gain.gain.value = volume;
      oscillator.connect(gain);
      gain.connect(bus);
      oscillator.start();
      this._nodes.push(oscillator, gain);
    }

    _smooth(param, value, seconds) {
      if (!this.ctx || !param) return;
      if (Math.abs((this._targets.get(param) ?? -99) - value) < 0.002) return;
      const t = this.ctx.currentTime;
      if (param.cancelAndHoldAtTime) param.cancelAndHoldAtTime(t);
      else { param.cancelScheduledValues(t); param.setValueAtTime(param.value, t); }
      param.setTargetAtTime(value, t, seconds);
      this._targets.set(param, value);
    }

    setMuted(muted) {
      this.muted = !!muted;
      if (this.master) this._smooth(this.master.gain, this.muted ? 0 : 0.24, 0.055);
    }

    update(dt, state) {
      this._state = Object.assign({}, this._state, state || {});
      if (!this.ctx || this.ctx.state !== 'running') return;
      dt = Math.max(0, Math.min(0.1, Number(dt) || 0));
      const s = this._state;
      const playing = s.mode === 'play';
      const threat = playing ? Math.max(0, Math.min(1, Number(s.threat) || 0)) : 0;
      this._threat += (threat - this._threat) * (1 - Math.exp(-dt * 4));
      this._smooth(this.ambience.gain, s.mode === 'won' ? 0.25 : playing ? 0.65 : 0.36, 0.8);
      this._smooth(this.music.gain, s.mode === 'dead' ? 0.035 : s.mode === 'won' ? 0.19 : playing ? (s.pipe?.warning ? 0.30 : 0.48) : 0.18, 0.30);
      this._smooth(this.tension.gain, playing ? (s.chase ? 0.95 : this._threat * 0.70) : 0, 0.35);
      const reportedDistance = Number(s.chefDistance);
      const distance = Number.isFinite(reportedDistance) ? Math.max(0, reportedDistance) : 9999;
      const proximity = Math.max(0, Math.min(1, (1000 - distance) / 880));
      this._smooth(this.chefBody.gain, playing ? proximity * proximity * (0.13 + this._threat * 0.30) : 0, 0.28);
      this._smooth(this.breathLFO.frequency, s.chase ? 0.59 : 0.34, 0.45);
      const chainMoving = playing && ['hanging', 'released'].includes(s.escapeAction);
      const chainPowered = playing && s.escapeAction === 'powered';
      this._smooth(this.chainMotor.gain, chainMoving ? 0.48 : chainPowered ? 0.065 : 0, 0.16);
      if (!playing) { this._beatClock = 0; return; }

      if (chainMoving) {
        this._chainClock += dt;
        if (this._chainClock >= 0.175) {
          this._chainClock -= 0.175;
          this._chainBeat++;
          this._metal(this._chainBeat % 3 ? 325 : 208, 0.024, 0.16, this.effects, 0.14);
          this._noise(0.07, 0.047, 570, 'bandpass', this.effects, 0, 0.14);
        }
      } else this._chainClock = 0;

      // Tick clocks follow the game clock. A suspended tab cannot produce a
      // burst of queued percussion on return.
      this._scoreClock += dt;
      this._roomClock += dt;
      if (this._roomClock > 5.2) {
        this._roomClock = 0;
        this._metal(285 + (this._score % 3) * 58, 0.017, 2.2, this.ambience, -0.55);
      }
      if (!s.chase && this._scoreClock >= 2.35) {
        this._scoreClock = 0;
        // An original sparse five-note kitchen motif, played like soft glass.
        const notes = [146.83, 220, 155.56, 130.81, 196, 146.83, 110, 164.81];
        const n = notes[this._score++ % notes.length];
        this._tone(n, n * 0.997, 1.85, 0.065, 'sine', this.music, 0, (this._score % 2 ? -1 : 1) * 0.22);
        if (this._score % 4 === 0) this._tone(n * 2, n * 2, 1.3, 0.025, 'sine', this.music, 0.18, 0.3);
      }
      if (s.chase || this._threat > 0.34) {
        this._beatClock += dt;
        const interval = s.chase ? 0.31 : 0.60 - this._threat * 0.15;
        if (this._beatClock >= interval) {
          this._beatClock -= interval;
          const strong = this._beat++ % 4 === 0;
          const amount = s.chase ? (s.pipe?.warning ? 0.073 : 0.12) : this._threat * 0.10;
          this._tone(strong ? 89 : 71, 38, 0.20, amount, 'sine', this.music);
          this._noise(0.06, amount * (strong ? 0.22 : 0.12), 950, 'highpass', this.music);
          if (s.chase && this._beat % 2 === 0) {
            const notes = [146.83, 155.56, 146.83, 130.81, 110, 130.81, 155.56, 164.81];
            this._tone(notes[(this._beat / 2 | 0) % notes.length], 110, 0.26, 0.055, 'triangle', this.music, 0.025);
          }
        }
      } else this._beatClock = 0;
    }

    _voice(source, nodes, endTime) {
      this._voices.add(source);
      source.onended = () => {
        this._voices.delete(source);
        for (const node of nodes) { try { node.disconnect(); } catch (_) {} }
      };
      source.stop(endTime);
    }

    _output(node, bus, pan, reflection) {
      if (this.ctx.createStereoPanner && pan) {
        const panner = this.ctx.createStereoPanner();
        panner.pan.value = Math.max(-0.85, Math.min(0.85, pan));
        node.connect(panner);
        panner.connect(bus || this.effects);
        if (reflection) panner.connect(this.echo);
        return panner;
      }
      node.connect(bus || this.effects);
      if (reflection) node.connect(this.echo);
      return null;
    }

    _tone(from, to, duration, volume, type, bus, delay, pan) {
      if (this._voices.size > 72) return;
      const t = this.ctx.currentTime + (delay || 0);
      const source = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      source.type = type || 'sine';
      source.frequency.setValueAtTime(Math.max(15, from), t);
      source.frequency.exponentialRampToValueAtTime(Math.max(15, to || from), t + duration);
      gain.gain.setValueAtTime(0.0001, t);
      gain.gain.exponentialRampToValueAtTime(Math.max(0.0002, volume), t + Math.min(0.016, duration * 0.08));
      gain.gain.exponentialRampToValueAtTime(0.0001, t + duration);
      source.connect(gain);
      const panner = this._output(gain, bus, pan || 0, duration > 0.35);
      source.start(t);
      this._voice(source, [source, gain, panner].filter(Boolean), t + duration + 0.04);
    }

    _noise(duration, volume, frequency, type, bus, delay, pan) {
      if (this._voices.size > 72) return;
      const t = this.ctx.currentTime + (delay || 0);
      const source = this.ctx.createBufferSource();
      source.buffer = this.noiseBuffer;
      source.loop = true;
      const filter = this.ctx.createBiquadFilter();
      filter.type = type || 'lowpass';
      filter.frequency.value = frequency;
      filter.Q.value = 0.7;
      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.0001, t);
      gain.gain.exponentialRampToValueAtTime(Math.max(0.0002, volume), t + Math.min(0.012, duration * 0.08));
      gain.gain.exponentialRampToValueAtTime(0.0001, t + duration);
      source.connect(filter);
      filter.connect(gain);
      const panner = this._output(gain, bus, pan || 0, duration > 0.25);
      source.start(t, (this._beat % 7) * 0.23);
      this._voice(source, [source, filter, gain, panner].filter(Boolean), t + duration + 0.04);
    }

    _metal(frequency, volume, duration, bus, pan) {
      [1, 2.756, 4.21, 6.38].forEach((ratio, i) => {
        this._tone(frequency * ratio, frequency * ratio * 0.996, duration / (1 + i * 0.55), volume / (1 + i * 1.5), 'sine', bus, 0, pan);
      });
    }

    _strain(from, to, duration, volume, pan) {
      if (this._voices.size > 72) return;
      const t = this.ctx.currentTime;
      const source = this.ctx.createOscillator();
      const filter = this.ctx.createBiquadFilter();
      const gain = this.ctx.createGain();
      source.type = 'triangle';
      source.frequency.setValueAtTime(from, t);
      source.frequency.exponentialRampToValueAtTime(to, t + duration);
      filter.type = 'lowpass';
      filter.frequency.value = 1050;
      gain.gain.setValueAtTime(0.0001, t);
      gain.gain.exponentialRampToValueAtTime(volume * 0.22, t + 0.14);
      gain.gain.exponentialRampToValueAtTime(volume, t + duration * 0.80);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + duration);
      source.connect(filter);
      filter.connect(gain);
      const panner = this._output(gain, this.effects, pan, false);
      source.start(t);
      this._voice(source, [source, filter, gain, panner].filter(Boolean), t + duration + 0.04);
    }

    fx(name, value) {
      if (!this.ctx || this.ctx.state !== 'running') return;
      const options = value && typeof value === 'object' ? value : {};
      const intensity = Math.max(0.12, Math.min(1.6, typeof value === 'number' ? value : (options.volume ?? 1)));
      const pan = Number(options.pan) || 0;
      const cooldown = { footstep: 0.08, chefStep: 0.15, push: 0.20, alert: 0.8, grab: 0.4, pipeWarning: 0.9, pipeSlam: 0.65, chainStart: 0.5, hookCatch: 0.25, hookEnd: 0.35 }[name] || 0.015;
      const now = this.ctx.currentTime;
      if (now - (this._recent[name] ?? -99) < cooldown) return;
      this._recent[name] = now;
      const tone = (a, b, d, v, type, delay) => this._tone(a, b, d, v * intensity, type, this.effects, delay, pan);
      const noise = (d, v, f, type, delay) => this._noise(d, v * intensity, f, type, this.effects, delay, pan);
      const metal = (f, v, d) => this._metal(f, v * intensity, d, this.effects, pan);
      switch (name) {
        case 'jump':
          tone(205, 355, 0.12, 0.14, 'triangle');
          noise(0.065, 0.055, 1300, 'highpass');
          break;
        case 'landWood':
          tone(145, 48, 0.15, 0.20, 'sine');
          noise(0.075, 0.16, 720, 'lowpass');
          break;
        case 'landMetal':
          tone(110, 45, 0.10, 0.17, 'sine');
          metal(395, 0.19, 0.70);
          noise(0.035, 0.12, 3200, 'highpass');
          break;
        case 'landCloth':
          tone(80, 35, 0.09, 0.065, 'sine');
          noise(0.10, 0.080, 350, 'lowpass');
          break;
        case 'bell':
          metal(430, 0.31, 2.25);
          noise(0.035, 0.12, 2600, 'highpass');
          break;
        case 'push':
          noise(0.20, 0.13, 450, 'bandpass');
          tone(85, 62, 0.16, 0.06, 'triangle');
          break;
        case 'gate':
          noise(0.95, 0.27, 980, 'bandpass');
          tone(93, 73, 0.68, 0.10, 'triangle');
          tone(65, 35, 0.19, 0.24, 'sine', 0.73);
          metal(242, 0.09, 0.60);
          break;
        case 'footstep':
          tone(105, 60, 0.045, 0.075, 'sine');
          noise(0.035, 0.055, 800, 'lowpass');
          break;
        case 'chefStep':
          // Heel contact, a slower body settling behind it, and cloth moving.
          // More physical low-mid detail, rather than a louder sharp transient.
          tone(74, 33, 0.24, 0.32, 'sine');
          tone(46, 35, 0.39, 0.13, 'sine', 0.035);
          noise(0.18, 0.13, 225, 'lowpass');
          noise(0.31, 0.058, 265, 'bandpass', 0.08);
          metal(127, 0.017, 0.43);
          break;
        case 'pipeWarning':
          // The rising envelope and falling pitch are the .95s deformation,
          // preceding the hand impact. They do not schedule the impact itself.
          this._strain(208, 93, 0.95, 0.15 * intensity, pan);
          this._strain(314, 187, 0.91, 0.047 * intensity, pan);
          noise(0.78, 0.043, 465, 'bandpass', 0.10);
          break;
        case 'pipeSlam':
          tone(91, 32, 0.44, 0.39, 'sine');
          tone(47, 35, 0.62, 0.14, 'sine', 0.025);
          noise(0.19, 0.24, 310, 'lowpass');
          metal(126, 0.115, 1.65);
          tone(684, 645, 0.58, 0.026, 'sine', 0.045);
          noise(0.25, 0.065, 820, 'bandpass', 0.05);
          break;
        case 'chainStart':
          tone(98, 74, 0.45, 0.090, 'triangle');
          noise(0.43, 0.10, 780, 'bandpass');
          metal(208, 0.060, 0.35);
          tone(382, 375, 0.16, 0.038, 'sine', 0.12);
          tone(334, 322, 0.19, 0.031, 'sine', 0.25);
          break;
        case 'hookCatch':
          tone(96, 51, 0.19, 0.14, 'sine');
          metal(596, 0.068, 0.44);
          tone(341, 323, 0.11, 0.11, 'triangle', 0.025);
          noise(0.18, 0.091, 760, 'bandpass', 0.025);
          break;
        case 'hookEnd':
          tone(82, 48, 0.28, 0.10, 'sine');
          noise(0.35, 0.080, 520, 'bandpass');
          metal(222, 0.039, 0.54);
          break;
        case 'alert':
          tone(88, 142, 0.75, 0.20, 'triangle');
          tone(93, 146, 0.70, 0.12, 'sine');
          noise(0.32, 0.16, 1200, 'bandpass');
          break;
        case 'grab':
          noise(0.28, 0.28, 1000, 'lowpass');
          tone(175, 72, 0.32, 0.24, 'triangle');
          break;
        case 'death':
          tone(150, 29, 0.68, 0.23, 'triangle');
          noise(0.28, 0.18, 550, 'lowpass');
          metal(103, 0.10, 1.0);
          break;
        case 'checkpoint':
          tone(293.66, 293.66, 0.52, 0.11, 'sine');
          tone(440, 440, 0.68, 0.09, 'sine', 0.13);
          tone(587.33, 587.33, 0.85, 0.055, 'sine', 0.25);
          break;
        case 'win':
          // A small settling breath of harmony on the service ledge, while
          // the kitchen motor remains audible. This is temporary safety.
          [196, 155.56, 146.83].forEach((n, i) => tone(n, n, 0.85, 0.068, 'sine', i * 0.27));
          tone(97.99, 97.99, 1.75, 0.080, 'sine');
          tone(220, 220, 1.60, 0.027, 'sine', 0.22);
          break;
      }
    }

    // Optional cleanup for hosts which replace the whole game without a reload.
    async dispose() {
      if (!this.ctx || this.ctx.state === 'closed') return;
      this.setMuted(true);
      for (const source of this._voices) { try { source.stop(); } catch (_) {} }
      for (const node of this._nodes) { try { if (node.stop) node.stop(); node.disconnect(); } catch (_) {} }
      await this.ctx.close();
      this.started = false;
    }
  }

  root.KitchenAudio = KitchenAudio;
})(typeof window !== 'undefined' ? window : globalThis);
