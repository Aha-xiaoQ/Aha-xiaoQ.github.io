/* Genuine R13 Six geometry adapter.
 * Provenance: tools/six-model/model.js child(), hood/face/hair surfaces;
 * engine-transparent.js math and primitive generators only. No old renderer,
 * canvas, sprite, texture card, UI, audio, camera, or external asset is used.
 * Contract: group origin at soles; idle height = 1; forward = local -X.
 * Caller positions/scales group. update(timeSeconds,{beckon}) keeps feet planted.
 */
(()=>{'use strict';
globalThis.createSixModel3D=function(THREE){
 const R={mesh(data){
  const values=new Float32Array(data), count=values.length/8;
  const positions=new Float32Array(count*3), normals=new Float32Array(count*3), uvs=new Float32Array(count*2);
  for(let i=0;i<count;i++){positions.set(values.subarray(i*8,i*8+3),i*3);normals.set(values.subarray(i*8+3,i*8+6),i*3);uvs.set(values.subarray(i*8+6,i*8+8),i*2);}
  // Original renderer did not cull. Reconcile winding to its authored normals
  // so THREE's front/back normal handling and shared shadows remain coherent.
  for(let i=0;i<count;i+=3){
   const a=i*3,b=a+3,c=a+6,ux=positions[b]-positions[a],uy=positions[b+1]-positions[a+1],uz=positions[b+2]-positions[a+2],vx=positions[c]-positions[a],vy=positions[c+1]-positions[a+1],vz=positions[c+2]-positions[a+2];
   const dot=(uy*vz-uz*vy)*(normals[a]+normals[b]+normals[c])+(uz*vx-ux*vz)*(normals[a+1]+normals[b+1]+normals[c+1])+(ux*vy-uy*vx)*(normals[a+2]+normals[b+2]+normals[c+2]);
   if(dot<0){for(const [arr,stride] of [[positions,3],[normals,3],[uvs,2]])for(let k=0;k<stride;k++){const j=(i+1)*stride+k,l=(i+2)*stride+k,tmp=arr[j];arr[j]=arr[l];arr[l]=tmp;}}
  }
  const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.BufferAttribute(positions,3));geometry.setAttribute('normal',new THREE.BufferAttribute(normals,3));geometry.setAttribute('uv',new THREE.BufferAttribute(uvs,2));geometry.computeBoundingSphere();
  return {geometry,data:values};
 },updateMesh(){throw Error('Six adapter only supports fixed idle/beckon coat');}};
const M={
 id:()=>new Float32Array([1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]),
 mul:(a,b)=>{let o=new Float32Array(16);for(let c=0;c<4;c++)for(let r=0;r<4;r++)o[c*4+r]=a[r]*b[c*4]+a[4+r]*b[c*4+1]+a[8+r]*b[c*4+2]+a[12+r]*b[c*4+3];return o},
 trs:(x=0,y=0,z=0,rx=0,ry=0,rz=0,sx=1,sy=sx,sz=sx)=>{let a=Math.cos(rx),b=Math.sin(rx),c=Math.cos(ry),d=Math.sin(ry),e=Math.cos(rz),f=Math.sin(rz);return new Float32Array([(c*e)*sx,(a*f+b*d*e)*sx,(b*f-a*d*e)*sx,0,(-c*f)*sy,(a*e-b*d*f)*sy,(b*e+a*d*f)*sy,0,d*sz,-b*c*sz,a*c*sz,0,x,y,z,1])},
 point:(m,p)=>[m[0]*p[0]+m[4]*p[1]+m[8]*p[2]+m[12],m[1]*p[0]+m[5]*p[1]+m[9]*p[2]+m[13],m[2]*p[0]+m[6]*p[1]+m[10]*p[2]+m[14]],
 vector:(m,p)=>[m[0]*p[0]+m[4]*p[1]+m[8]*p[2],m[1]*p[0]+m[5]*p[1]+m[9]*p[2],m[2]*p[0]+m[6]*p[1]+m[10]*p[2]],
 ortho:(l,r,b,t,n,f)=>new Float32Array([2/(r-l),0,0,0,0,2/(t-b),0,0,0,0,-2/(f-n),0,-(r+l)/(r-l),-(t+b)/(t-b),-(f+n)/(f-n),1]),
 perspective:(fovy,asp,n,f)=>{let q=1/Math.tan(fovy/2);return new Float32Array([q/asp,0,0,0,0,q,0,0,0,0,(f+n)/(n-f),-1,0,0,2*f*n/(n-f),0])},
 look:(eye,at,up=[0,1,0])=>{let z=V.norm(V.sub(eye,at)),x=V.norm(V.cross(up,z)),y=V.cross(z,x);return new Float32Array([x[0],y[0],z[0],0,x[1],y[1],z[1],0,x[2],y[2],z[2],0,-V.dot(x,eye),-V.dot(y,eye),-V.dot(z,eye),1])},
 inv:(a)=>{let o=new Float32Array(16),a00=a[0],a01=a[1],a02=a[2],a03=a[3],a10=a[4],a11=a[5],a12=a[6],a13=a[7],a20=a[8],a21=a[9],a22=a[10],a23=a[11],a30=a[12],a31=a[13],a32=a[14],a33=a[15];let b00=a00*a11-a01*a10,b01=a00*a12-a02*a10,b02=a00*a13-a03*a10,b03=a01*a12-a02*a11,b04=a01*a13-a03*a11,b05=a02*a13-a03*a12,b06=a20*a31-a21*a30,b07=a20*a32-a22*a30,b08=a20*a33-a23*a30,b09=a21*a32-a22*a31,b10=a21*a33-a23*a31,b11=a22*a33-a23*a32;let det=b00*b11-b01*b10+b02*b09+b03*b08-b04*b07+b05*b06;det=1/(det||1e-12);o[0]=(a11*b11-a12*b10+a13*b09)*det;o[1]=(a02*b10-a01*b11-a03*b09)*det;o[2]=(a31*b05-a32*b04+a33*b03)*det;o[3]=(a22*b04-a21*b05-a23*b03)*det;o[4]=(a12*b08-a10*b11-a13*b07)*det;o[5]=(a00*b11-a02*b08+a03*b07)*det;o[6]=(a32*b02-a30*b05-a33*b01)*det;o[7]=(a20*b05-a22*b02+a23*b01)*det;o[8]=(a10*b10-a11*b08+a13*b06)*det;o[9]=(a01*b08-a00*b10-a03*b06)*det;o[10]=(a30*b04-a31*b02+a33*b00)*det;o[11]=(a21*b02-a20*b04-a23*b00)*det;o[12]=(a11*b07-a10*b09-a12*b06)*det;o[13]=(a00*b09-a01*b07+a02*b06)*det;o[14]=(a31*b01-a30*b03-a32*b00)*det;o[15]=(a20*b03-a21*b01+a22*b00)*det;return o;}
};
const V={add:(a,b)=>a.map((x,i)=>x+b[i]),sub:(a,b)=>a.map((x,i)=>x-b[i]),mul:(a,s)=>a.map(x=>x*s),len:a=>Math.hypot(...a),dot:(a,b)=>a.reduce((s,x,i)=>s+x*b[i],0),cross:(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]],norm:a=>{let l=Math.hypot(...a)||1;return a.map(x=>x/l)}};

function tri(out,a,b,c,na,nb,nc,ta=[0,0],tb=[1,0],tc=[0,1]){for(let [p,n,u]of [[a,na,ta],[b,nb,tb],[c,nc,tc]])out.push(...p,...n,...u);}
function sphereData(n=20,m=14){let o=[];const p=(i,j)=>{let a=i/n*Math.PI*2,b=j/m*Math.PI;return[Math.sin(b)*Math.cos(a),Math.cos(b),Math.sin(b)*Math.sin(a)]};for(let j=0;j<m;j++)for(let i=0;i<n;i++){let a=p(i,j),b=p(i+1,j),c=p(i+1,j+1),d=p(i,j+1);tri(o,a,b,c,a,b,c,[i/n,1-j/m],[(i+1)/n,1-j/m],[(i+1)/n,1-(j+1)/m]);tri(o,a,c,d,a,c,d,[i/n,1-j/m],[(i+1)/n,1-(j+1)/m],[i/n,1-(j+1)/m]);}return o;}
function cylinderData(n=16,top=1){let o=[];for(let i=0;i<n;i++){let a=i/n*Math.PI*2,b=(i+1)/n*Math.PI*2;let p=[Math.cos(a),-.5,Math.sin(a)],q=[Math.cos(b),-.5,Math.sin(b)],r=[Math.cos(b)*top,.5,Math.sin(b)*top],s=[Math.cos(a)*top,.5,Math.sin(a)*top],na=V.norm([p[0],1-top,p[2]]),nb=V.norm([q[0],1-top,q[2]]);tri(o,p,q,r,na,nb,nb,[i/n,0],[(i+1)/n,0],[(i+1)/n,1]);tri(o,p,r,s,na,nb,na,[i/n,0],[(i+1)/n,1],[i/n,1]);tri(o,[0,.5,0],s,r,[0,1,0],[0,1,0],[0,1,0]);tri(o,[0,-.5,0],q,p,[0,-1,0],[0,-1,0],[0,-1,0]);}return o;}
function boxData(){let out=[];for(let ax=0;ax<3;ax++)for(let sign of [-1,1]){let u=(ax+1)%3,v=(ax+2)%3,n=[0,0,0];n[ax]=sign;let pp=[[-.5,-.5],[.5,-.5],[.5,.5],[-.5,.5]].map(([i,j])=>{let p=[0,0,0];p[ax]=sign*.5;p[u]=i;p[v]=j;return p;});tri(out,pp[0],pp[1],pp[2],n,n,n,[0,0],[1,0],[1,1]);tri(out,pp[0],pp[2],pp[3],n,n,n,[0,0],[1,1],[0,1]);}return out;}
function latheData(rings,n=28){let out=[];for(let j=0;j<rings.length-1;j++)for(let i=0;i<n;i++){function v(i,j){let a=i/n*Math.PI*2,[y,rx,rz]=rings[j],prev=rings[Math.max(0,j-1)],next=rings[Math.min(rings.length-1,j+1)],slope=(next[1]-prev[1])/Math.max(.01,next[0]-prev[0]);return{p:[rx*Math.cos(a),y,rz*Math.sin(a)],n:V.norm([Math.cos(a),-slope,Math.sin(a)*rx/Math.max(.001,rz)]),uv:[i/n,j/(rings.length-1)]};}let a=v(i,j),b=v(i+1,j),c=v(i+1,j+1),d=v(i,j+1);for(let t of [[a,b,c],[a,c,d]])tri(out,...t.map(x=>x.p),...t.map(x=>x.n),...t.map(x=>x.uv));}return out;}
function torusData(R=1,r=.1,n=32,m=8){let out=[];const v=(i,j)=>{let a=i/n*Math.PI*2,b=j/m*Math.PI*2;return{p:[(R+r*Math.cos(b))*Math.cos(a),r*Math.sin(b),(R+r*Math.cos(b))*Math.sin(a)],n:[Math.cos(b)*Math.cos(a),Math.sin(b),Math.cos(b)*Math.sin(a)],uv:[i/n,j/m]};};for(let i=0;i<n;i++)for(let j=0;j<m;j++){let a=v(i,j),b=v(i+1,j),c=v(i+1,j+1),d=v(i,j+1);for(let t of [[a,b,c],[a,c,d]])tri(out,...t.map(x=>x.p),...t.map(x=>x.n),...t.map(x=>x.uv));}return out;}
function planeData(){let out=[];tri(out,[-.5,-.5,0],[.5,-.5,0],[.5,.5,0],[0,0,1],[0,0,1],[0,0,1],[0,0],[1,0],[1,1]);tri(out,[-.5,-.5,0],[.5,.5,0],[-.5,.5,0],[0,0,1],[0,0,1],[0,0,1],[0,0],[1,1],[0,1]);return out;}
function triangleData(){let out=[],p=[[-.46,-.48,0],[-.46,.48,0],[.48,0,0]];for(let sign of [-1,1])tri(out,...p.map(a=>[a[0],a[1],sign*.085]),...[0,0,0].map(()=>[0,0,sign]));for(let i=0;i<3;i++){let a=p[i],b=p[(i+1)%3],n=V.norm([b[1]-a[1],a[0]-b[0],0]);tri(out,[a[0],a[1],-.085],[b[0],b[1],-.085],[b[0],b[1],.085],n,n,n);tri(out,[a[0],a[1],-.085],[b[0],b[1],.085],[a[0],a[1],.085],n,n,n);}return out;}

const PI=Math.PI,TAU=PI*2,clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x)),mix=(a,b,t)=>a+(b-a)*t,ease=x=>{x=clamp(x);return x*x*(3-2*x)},p=(t,a,b)=>clamp((t-a)/(b-a)),smooth=(t,a,b)=>ease(p(t,a,b)),vecmix=(a,b,t)=>a.map((v,i)=>mix(v,b[i],t));

const rgb=h=>[1,3,5].map(i=>parseInt(h.slice(i,i+2),16)/255),mat=(name,c,kind=0,roughness=.8,opacity=1)=>({name,color:rgb(c),kind,roughness,opacity});
const C={yellow:mat('yellow oilskin','#c2a124',2,.78),yellowHi:mat('yellow coat seams','#cfad38',2,.91),yellowDark:mat('ochre seam stitching','#a58624',2,.93),skin:mat('small hands','#aa9179',1,.86),bare:mat('bare feet','#887966',1),black:mat('deep shadow','#101b21'),hair:mat('dark hair','#292622',2),nome:mat('nomes cloth','#a09e86',2),nomeHat:mat('nomes hat','#c4c1a4',2),wall:mat('damp wall','#394a4c',6),wall2:mat('wall trim','#293b3e',5),wood:mat('aged oak','#665444',4),woodLight:mat('worn wood','#82705a',4),woodDark:mat('dark wood','#443d33',4),metal:mat('iron','#344044',5,.38),rim:mat('frame edges','#596366',5,.3),darkMetal:mat('dark metal','#202b32',5,.55),rust:mat('rust','#765948',5,.68),paper:mat('dusty paper','#9a9680',2),flesh:mat('old hands','#737162',1,.94),fleshDark:mat('skin creases','#53594f',1),nail:mat('old nails','#929181',1,.8),coat:mat('caretaker coat','#333e40',2),hat:mat('caretaker hat','#282e2e',2),red:mat('timeline','#e45c43',7),redDim:mat('dark timeline','#552827',0,.5),ivory:mat('icons','#d8dccb',7),gold:mat('lamp','#f3bd66',7),pale:mat('fog light','#567183',7,.8,.035),floor:mat('outside floor','#18252d',5,.44)};
C.chef=mat('chef smock','#837f6f',2,.96);C.chefShade=mat('stained apron','#555c51',2,.96);C.chefFace=mat('chef wax face','#92846f',1,.94);C.coal=mat('coal rubbed cloth','#696b5d',2,.94);C.coalHat=mat('coal hat','#95907c',2,.97);C.porcelain=mat('porcelain','#b4aca0',0,.36);C.bag=mat('paper bag','#8d7453',2);C.sausage=mat('tied sausage','#704032',1);C.chrome=mat('polished hinge','#88938e',5,.28);
C.face=mat('Six continuous sculpt','#998272',3,.98);
C.faceShade=mat('eyelid creases','#4d4038',3,1);
C.lip=mat('subtle lower lip','#86665a',3,1);
C.eye=mat('recessed pupils','#1c1b19',3,1);
C.sixHair=mat('matte layered hair','#23201d',2,1);
C.hoodInside=mat('yellow hood interior','#bd9a22',2,.95);
C.brass=mat('brass lighter','#b09552',5,.35);
C.flame=mat('lighter flame','#ffd08b',7,1,.94);
C.warmTrace=mat('soot and chalk','#6a6657',2,1);
C.torch=mat('worn flashlight','#687578',5,.58);C.lens=mat('torch glass','#e0e2cf',7);C.water=mat('bilge water','#24393a',5,.18);C.beam=mat('flashlight dust','#c8d5d1',8,1,.11);C.umber=mat('rubber scuff','#534b36',2,1);

const meshes={sphere:R.mesh(sphereData()),small:R.mesh(sphereData(12,8)),cyl:R.mesh(cylinderData()),cone:R.mesh(cylinderData(24,0)),taper:R.mesh(cylinderData(16,.72)),box:R.mesh(boxData()),plane:R.mesh(planeData()),torus:R.mesh(torusData(1,.1)),triangle:R.mesh(triangleData()),coat:R.mesh(latheData([[.4,.33,.30],[.43,.37,.34],[.56,.32,.29],[.8,.27,.25],[1.05,.27,.23],[1.19,.22,.19],[1.23,.13,.12]],32))};
let list=[],parent=M.id();function obj(mesh,m,ma,noShadow=false){list.push({mesh,m:M.mul(parent,m),mat:ma,noShadow});}
function box(x,y,z,w,h,d,ma,rx=0,ry=0,rz=0){obj(meshes.box,M.trs(x,y,z,rx,ry,rz,w,h,d),ma);}
function ball(x,y,z,sx,sy,sz,ma,rx=0,ry=0,rz=0){obj(Math.max(sx,sy,sz)>.31?meshes.sphere:meshes.small,M.trs(x,y,z,rx,ry,rz,sx,sy,sz),ma);}
function cyl(x,y,z,r,h,ma,rx=0,ry=0,rz=0,top=false){obj(top?meshes.taper:meshes.cyl,M.trs(x,y,z,rx,ry,rz,r,h,r),ma);}
function rod(a,b,r,ma,top=false){let y=V.norm(V.sub(b,a)),x=V.norm(V.cross(Math.abs(y[2])>.95?[1,0,0]:[0,0,1],y)),z=V.cross(x,y),len=V.len(V.sub(b,a)),mid=vecmix(a,b,.5);let m=new Float32Array([x[0]*r,x[1]*r,x[2]*r,0,y[0]*len,y[1]*len,y[2]*len,0,z[0]*r,z[1]*r,z[2]*r,0,...mid,1]);obj(top?meshes.taper:meshes.cyl,m,ma);}
function ring(x,y,z,r,ma,rx=PI/2,ry=0,rz=0){obj(meshes.torus,M.trs(x,y,z,rx,ry,rz,r,r,r),ma);}
function group(m,fn){let old=parent;parent=M.mul(parent,m);fn();parent=old;}

// Reusable ring-shaped hood with an open, shadowed face, not a painted face card.
function sculptSurface(fn,n=64,m=36){
 const out=[];function vv(i,j){let u=i/n,v=clamp(j/m,.00005,.99995),q=fn(u,v),du=V.sub(fn(u+.00012,v),fn(u-.00012,v)),dv=V.sub(fn(u,clamp(v+.00012,.00001,.99999)),fn(u,clamp(v-.00012,.00001,.99999))),normal=V.norm(V.cross(du,dv));if(V.dot(normal,[q[0],q[1],q[2]-.07])<0)normal=V.mul(normal,-1);return{p:q,n:normal,uv:[u,1-v]};}
 for(let j=0;j<m;j++)for(let i=0;i<n;i++){let a=vv(i,j),b=vv(i+1,j),c=vv(i+1,j+1),d=vv(i,j+1);for(let f of [[a,b,c],[a,c,d]])tri(out,...f.map(v=>v.p),...f.map(v=>v.n),...f.map(v=>v.uv));}return out;
}
function hoodPoint(u,v,inner=false){
 let a=u*TAU,theta=.89+v*(PI-.89),ss=Math.sin(theta),top=Math.max(0,Math.sin(a)),front=Math.exp(-v*6),fold=.007*Math.cos(a*7+.5)*Math.sin(v*PI);
 let x=ss*Math.cos(a)*(.318+fold),y=ss*Math.sin(a)*.377,z=Math.cos(theta)*.375;
 y+=Math.pow(Math.max(0,y)/.377,4)*.098;
 z+=Math.pow(top,3)*front*.057;
 if(inner){x*=.949;y*=.949;z*=.949;}
 return[x,y,z];
}
function hoodData(){return sculptSurface((u,v)=>hoodPoint(u,v),64,30);}
meshes.hood=R.mesh(hoodData());
const innerHoodData=sculptSurface((u,v)=>hoodPoint(u,v,true),64,30);
for(let i=0;i<innerHoodData.length;i+=8){innerHoodData[i+3]*=-1;innerHoodData[i+4]*=-1;innerHoodData[i+5]*=-1;}
meshes.hoodLining=R.mesh(innerHoodData);
// The rim is actual connected thickness rather than two independently floating surfaces.
const hoodRimData=[];for(let i=0;i<96;i++){
 const a=hoodPoint(i/96,0),b=hoodPoint((i+1)/96,0),c=hoodPoint((i+1)/96,0,true),d=hoodPoint(i/96,0,true),n=[0,0,1];
 tri(hoodRimData,a,b,c,n,n,n);tri(hoodRimData,a,c,d,n,n,n);
}meshes.hoodRim=R.mesh(hoodRimData);
function facePoint(u,v){
 const a=u*TAU,b=v*PI,st=Math.sin(b),yy=Math.cos(b),front=Math.max(0,Math.sin(a)),chin=1-.30*(1-smooth(yy,-.95,-.20));
 let x=st*Math.cos(a)*.196*chin,y=yy*.235-.044,z=st*Math.sin(a)*.157+.064;
 const G=(x0,y0,sx,sy)=>Math.exp(-(((x-x0)/sx)**2+((y-y0)/sy)**2));
 if(front>0){
  const nose=.019*G(0,-.098,.038,.070)+.030*G(0,-.126,.037,.029);
  const cheeks=.012*(G(-.103,-.119,.06,.071)+G(.103,-.119,.06,.071));
  const sockets=-.018*(G(-.073,-.058,.045,.033)+G(.073,-.058,.045,.033));
  const brow=.007*(G(-.068,-.025,.048,.013)+G(.068,-.026,.048,.013));
  const mouth=-.0045*G(0,-.184,.043,.008)+.008*G(0,-.197,.05,.016);
  z+=(nose+cheeks+sockets+brow+mouth)*front**3;
 }
 return[x,y,z];
}
meshes.sixFace=R.mesh(sculptSurface(facePoint,72,44));
function ribbon(points,widths,ma){for(let i=0;i<points.length-1;i++){let a=points[i],b=points[i+1],wa=widths[i],wb=widths[i+1],n=[0,0,1],d=[];tri(d,[a[0]-wa,a[1],a[2]],[a[0]+wa,a[1],a[2]],[b[0]+wb,b[1],b[2]],n,n,n);tri(d,[a[0]-wa,a[1],a[2]],[b[0]+wb,b[1],b[2]],[b[0]-wb,b[1],b[2]],n,n,n);return d;}}
function hairStripData(x0,endX,endY,width){
 const out=[],steps=12,cols=6;const pos=(u,v)=>{let t=u,w=width*(1-.93*Math.pow(t,2.6)),x=mix(x0,endX,t)+v*w,y=mix(.222,endY,t),z=.099+.128*Math.sin(t*PI*.78)+.024*(1-v*v);return[x,y,z];};
 for(let j=0;j<steps;j++)for(let k=0;k<cols;k++){let u=j/steps,un=(j+1)/steps,v=-1+2*k/cols,vn=-1+2*(k+1)/cols,a=pos(u,v),b=pos(u,vn),c=pos(un,vn),d=pos(un,v),n=V.norm(V.cross(V.sub(b,a),V.sub(c,a)));if(n[2]<0)n=V.mul(n,-1);tri(out,a,b,c,n,n,n);tri(out,a,c,d,n,n,n);}return out;
}
const hairLocks=[[-.150,-.175,-.155,.041],[-.116,-.122,-.092,.047],[-.075,-.077,-.078,.049],[-.032,-.018,-.048,.046],[.013,.033,-.061,.046],[.056,.093,-.065,.048],[.103,.141,-.106,.046],[.146,.177,-.163,.036]].map(v=>R.mesh(hairStripData(...v)));
function sixHead(opts,phase,lean,move){
 const gaze=opts.look||0,lag=move?Math.sin(phase-.50)*.012:0;
 group(M.trs(0,1.465,0,(opts.nod||0)-lean*.36,gaze,lag),()=>{
  obj(meshes.hood,M.id(),{...C.yellow,name:'uniform hood shell',receive:false});obj(meshes.hoodLining,M.id(),C.hoodInside,true);obj(meshes.hoodRim,M.id(),{...C.yellow,name:'uniform hood rim',receive:false});
  // Matte scalp sits behind the sculpt, not as a glossy bubble in front of it.
  ball(0,.029,-.011,.198,.248,.172,C.sixHair);
  obj(meshes.sixFace,M.id(),C.face);
  for(let sign of [-1,1]){
   let x=sign*.074;
   // Narrow eyes under the fringe; no bright whites, no round cartoon sockets.
   ball(x,-.061,.203,.027,.007,.008,C.faceShade);
   ball(x+clamp(gaze,-.5,.5)*.01,-.062,.211,.010,.008,.007,C.eye);
   for(let i=0;i<7;i++){let u=-1+2*i/7,v=-1+2*(i+1)/7;rod([x+u*.033,-.060+.009*(1-u*u),.210],[x+v*.033,-.060+.009*(1-v*v),.210] , .0020,C.face);}
  }
  // A small crease and lower lip; the nose belongs to the continuous mesh above.
  for(let i=0;i<8;i++){let u=-1+2*i/8,v=-1+2*(i+1)/8;rod([u*.031,-.187-.002*(1-u*u),.176+.007*(1-u*u)],[v*.031,-.187-.002*(1-v*v),.176+.007*(1-v*v)],.0026,C.faceShade);}
  for(let m of hairLocks)obj(m,M.id(),C.sixHair);
  // Edge and facing share the actual hood opening, closing the old floating-ring gap.
  for(let i=0;i<64;i++){let a=hoodPoint(i/64,0),b=hoodPoint((i+1)/64,0);rod(a,b,.0045,C.yellowHi);}
 });
}
function knee(a,b,l1,l2,bend=[0,0,1]){let dvec=V.sub(b,a),len=clamp(V.len(dvec),Math.abs(l1-l2)+.0001,l1+l2-.0001),dir=V.norm(dvec),v=V.norm(V.sub(bend,V.mul(dir,V.dot(dir,bend)))),along=(l1*l1-l2*l2+len*len)/(2*len),h=Math.sqrt(Math.max(0,l1*l1-along*along));return V.add(a,V.add(V.mul(dir,along),V.mul(v,h)));}

const modelAudit={hero:null,buddy:null};
function organicHeadData(){let out=[],n=32,m=22;function v(i,j){let a=i/n*TAU,b=j/m*PI,st=Math.sin(b),yy=Math.cos(b),jaw=1-.17*smooth(yy,-.8,-.2),x=st*Math.cos(a)*.73*jaw,z=st*Math.sin(a)*.60;let front=Math.max(0,Math.sin(a));z+=front*front*(.035*Math.sin(b*8)+.026*Math.sin(a*5));x+=.045*Math.sin(b*3);return{p:[x,yy*.77,z],n:V.norm([st*Math.cos(a)/.73,yy/.77,st*Math.sin(a)/.60]),uv:[i/n,j/m]};}for(let j=0;j<m;j++)for(let i=0;i<n;i++){let a=v(i,j),b=v(i+1,j),c=v(i+1,j+1),d=v(i,j+1);for(let t of [[a,b,c],[a,c,d]])tri(out,...t.map(v=>v.p),...t.map(v=>v.n),...t.map(v=>v.uv));}return out;}
meshes.head=R.mesh(organicHeadData());
meshes.mantle=R.mesh(latheData([[.90,.67,.44],[1.02,.77,.49],[1.55,.86,.57],[2.35,.96,.64],[2.94,1.05,.67],[3.24,.96,.57],[3.44,.53,.39]],32));
meshes.coat=R.mesh(latheData([[.46,.365,.35],[.49,.385,.375],[.63,.34,.29],[.85,.27,.235],[1.08,.265,.225],[1.22,.225,.19],[1.255,.12,.115]],40));
const slideCoats=Array.from({length:17},(_,i)=>{let k=i/16;return R.mesh(latheData([[mix(.46,.59,k),mix(.365,.22,k),mix(.35,.235,k)],[mix(.49,.62,k),mix(.385,.24,k),mix(.375,.25,k)],[.70,.28,.245],[.85,.27,.235],[1.08,.265,.225],[1.22,.225,.19],[1.255,.12,.115]],40));});
const coatMorph=R.mesh(slideCoats[0].data),coatMorphData=new Float32Array(coatMorph.data.length);let lastFold=-1;
function blendedCoat(fold){
 const k=clamp(fold),f=k*16,i=Math.min(15,Math.floor(f)),a=slideCoats[i].data,b=slideCoats[i+1].data,u=f-i;
 if(Math.abs(k-lastFold)>.000001){for(let j=0;j<a.length;j++)coatMorphData[j]=mix(a[j],b[j],u);R.updateMesh(coatMorph,coatMorphData);lastFold=k;}
 return coatMorph;
}
meshes.nomeBody=R.mesh(latheData([[.18,.215,.16],[.25,.25,.185],[.40,.225,.19],[.64,.19,.155],[.72,.13,.12]],28));
meshes.nomeHat=R.mesh(latheData([[.66,.34,.31],[.71,.33,.30],[.91,.245,.235],[1.10,.155,.15],[1.28,.083,.08],[1.48,.005,.005]],36));
function hand(pos,ma=C.skin,size=1,grip=0,axis=null,roll=0){
 let yaw=axis?Math.atan2(axis[0],axis[2]):0;group(M.trs(...pos,0,yaw,roll,size,size,size),()=>{
  ball(0,0,0,.066,.087,.049,ma,0,0,-.05);for(let i=0;i<4;i++){let x=(i-1.5)*.029,L=[.080,.100,.095,.073][i],a=[x,-.045,.006],b=[x,-.045-L*.56,.012+grip*.055],c=[x,-.045-L*(1-grip*.42),.022+grip*.075];rod(a,b,.0145,ma,true);ball(...b,.016,.017,.016,ma);rod(b,c,.013,ma,true);ball(...c,.014,.015,.014,ma);}rod([-.054,-.003,.016],[-.082,-.054,.032],.026,ma,true);rod([-.082,-.054,.032],[-.043,-.088,.047+grip*.022],.021,ma,true);
 });
}
function child(pos,heading,pose,phase=0,opts={}){
 const move=opts.moving??(['run','walk','carry'].includes(pose)),run=pose==='run',air=opts.air||0;
 const gait=opts.gait;let moveWeight=move?smooth(gait?.speed??1,.025,.32):0;let bounce=!air?moveWeight*(.011+(1-Math.cos(phase*2))*.010):0;
 let breathe=pose==='idle'||pose==='fear'?Math.sin(phase*1.8)*.006:0;
 let crouch=opts.crouch??(pose==='rescue'?.31:['crouch','push'].includes(pose)?.24:pose==='sit'?.31:0);
 let lean=(opts.lean??(run?.20:pose==='pull'?-.16:pose==='rescue'?.50:pose==='push'?.24:0));
 let base=M.mul(M.trs(...pos,0,0,opts.roll||0,1,1,opts.depth??1),M.trs(0,0,0,0,heading,0));
 let torsoLocal=M.mul(M.trs(0,.76+bounce+breathe-crouch,0,lean,0,0),M.trs(0,-.76,0));
 let torsoWorld=M.mul(base,torsoLocal),invBody=M.inv(torsoWorld),invBase=M.inv(base);
 let wrists=pose==='run'?[[-.31,.89+Math.sin(phase)*.14,Math.sin(phase)*.28],[.31,.89-Math.sin(phase)*.14,-Math.sin(phase)*.28]]:pose==='pull'?[[-.20,1.14,.51],[.20,1.14,.51]]:pose==='rescue'?[[-.20,.88,.56],[.20,.88,.56]]:pose==='fear'?[[-.30,1.04,.24],[.30,1.14,.26]]:pose==='beckon'?[[-.32,.78,.03],[.29,1.16,.46+Math.sin(phase)*.065]]:pose==='carry'?[[-.19,.96,.39],[.19,.96,.39]]:pose==='sit'?[[-.30,.68,.24],[.30,.68,.24]]:[[-.30,.75,move?Math.sin(phase)*.18:.025],[.30,.75,move?-Math.sin(phase)*.18:.025]];
 if(['run','walk','carry'].includes(pose)&&pose!=='carry'){
  const rw=smooth(gait?.speed??(run?2:1),.65,1.8),amp=mix(.14,.25,rw)*moveWeight;
  wrists=[[-.30,mix(.68,.87,rw)+Math.sin(phase-.13)*.10*moveWeight,Math.sin(phase-.18)*amp],[.30,mix(.68,.87,rw)-Math.sin(phase-.13)*.10*moveWeight,-Math.sin(phase-.18)*amp]];
 }
 if(air)wrists=[[-.38,1.1,.24],[.38,1.17,.26]];
 if(opts.wrists)wrists=opts.wrists.map(x=>[...x]);
 if(opts.slideBlend){
  const k=opts.slideBlend,q=opts.slideStage||0,invTorso=M.inv(torsoLocal);
  // Left palm brushes the support; right forearm guards the head. Only the skeleton bends.
  const palm=M.point(invTorso,[-.315,.161,-.12]);
  wrists[0]=vecmix(wrists[0],palm,k);wrists[1]=vecmix(wrists[1],[.235,1.255,.20],k);
 }
 if(opts.autoPair&&opts.handTargets&&opts.handTargets[0]&&opts.handTargets[1]){
  const a=M.point(invBody,opts.handTargets[0]),b=M.point(invBody,opts.handTargets[1]),sa=[-.245,1.16,0],sb=[.245,1.16,0];
  if(V.len(V.sub(a,sa))+V.len(V.sub(b,sb))>V.len(V.sub(a,sb))+V.len(V.sub(b,sa)))opts.handTargets.reverse();
 }
 if(opts.handTargets)for(let i=0;i<2;i++)if(opts.handTargets[i])wrists[i]=vecmix(wrists[i],M.point(invBody,opts.handTargets[i]),opts.handTargetWeights?opts.handTargetWeights[i]:1);
 if(opts.worldGrip){wrists=opts.worldGrip.map(v=>M.point(invBody,v));const a=[-.245,1.16,0],b=[.245,1.16,0];if(V.len(V.sub(wrists[0],a))+V.len(V.sub(wrists[1],b))>V.len(V.sub(wrists[1],a))+V.len(V.sub(wrists[0],b)))wrists.reverse();}
 const shoulders=[[-.245,1.16+(opts.shoulderLift||0),0],[.245,1.16+(opts.shoulderLift||0),0]],handWorld=wrists.map(w=>M.point(torsoWorld,w)),footWorld=[];
 group(base,()=>{
  group(torsoLocal,()=>{
   // The hem remains above the knees at full crouch; long frontal gait no longer cuts through a rigid cone.
   const fold=Math.max(opts.slideBlend||0,clamp((crouch-.12)/.32));obj(fold>0?blendedCoat(fold):meshes.coat,M.id(),C.yellow);
   rod([0,.58,.323],[0,1.15,.232],.005,C.yellowHi);
   for(let y of [.77,.94,1.11]){ball(.027,y,.241,.022,.025,.015,C.yellowHi);ball(.028,y,.255,.009,.012,.004,C.yellowDark);}
   for(let side of [-1,1]){rod([side*.07,1.21,.19],[side*.20,1.08,.22],.009,C.yellowHi);box(side*.205,.77,.234,.14,.09,.012,C.yellow,0,side*.14,side*.17);rod([side*.139,.82,.244],[side*.266,.80,.204],.012,C.yellowHi);}
   // Sparse seam geometry reads as tailored oilskin, not a stack of spheres.
   for(let i=0;i<40;i++){let a=i/40*TAU,b=(i+1)/40*TAU,k=fold,y=mix(.48,.61,k),rx=mix(.373,.23,k),rz=mix(.363,.241,k);rod([Math.cos(a)*rx,y,Math.sin(a)*rz],[Math.cos(b)*rx,y,Math.sin(b)*rz],.007,C.yellowHi);}
   sixHead(opts,phase,lean,move);
   for(let i=0;i<2;i++){
    let sign=i?1:-1,a=shoulders[i],b=wrists[i],el=knee(a,b,.365,.37,opts.relaxedArms?[sign*.22,-.45,-.8]:[sign*.75,-.5,-.35]);
    ball(...a,.108,.11,.105,C.yellow);rod(a,el,.09,C.yellow,true);ball(...el,.076,.077,.074,C.yellow);rod(el,b,.070,C.yellow,true);
    let cuff=vecmix(el,b,.90);rod(cuff,b,.073,C.yellow);
    hand(b,C.skin,.91,opts.gripHands?.[i]??(opts.worldGrip||pose==='carry'||(opts.lighter&&i===1)?1:0),(opts.worldGrip||opts.handTargets?.[i])?V.sub(b,el):null,opts.handRoll?.[i]||0);
   }
   if(opts.lighter){
    const lp=wrists[1],lid=opts.lighterOpen??1,lighterLocal=M.trs(lp[0],lp[1]-.055,lp[2]+.049,0,0,-.06);
    group(lighterLocal,()=>{
     box(0,0,0,.060,.092,.035,C.brass);box(0,.048,0,.051,.014,.030,C.darkMetal);
     cyl(-.018,.060,.003,.012,.016,C.chrome,0,0,PI/2);
     group(M.trs(-.032,.046,0,0,0,lid*2.02),()=>box(.030,.020,0,.061,.040,.037,C.brass));
     if(opts.flame>0){const tt=opts.effectTime||0,fl=opts.flame;ball(.008+Math.sin(tt*11)*.002,.080+fl*.014,.005,.010,fl*(.035+.003*Math.sin(tt*17)),.007,C.flame,0,0,Math.sin(tt*13)*.06);}
    });
    modelAudit.lighterTip=M.point(M.mul(torsoWorld,lighterLocal),[.008+Math.sin((opts.effectTime||0)*11)*.002,.080+(opts.flame||0)*.014,.005]);
   }
   if(opts.torchBelt){group(M.trs(-.305,.86,-.02,0,0,-.06,.85,.85,.85),()=>flashlightModel(false));}
   if(opts.key){group(M.trs(0,.94,.435,.1,0,-.12,.48,.48,.48),()=>obj(meshes.triangle,M.id(),C.gold));}
  });
  for(let i=0;i<2;i++){
   let side=i?1:-1,foot;
   if(gait&&!air)foot=M.point(invBase,gait.feet[i]);else foot=[side*.15,.071,pose==='sit'?.36:pose==='rescue'?(i?.10:-.13):.025];
   if(air)foot=[side*.17,.10+(i?.10:0),i?-.12:.23];
   if(opts.slideBlend){
  const q=opts.slideStage||0,k=opts.slideBlend;
  const target=i?[.15,.074,.69-.04*smooth(q,.7,1)]:[-.16,.074,.16+.14*smooth(q,.52,.91)];
  foot=vecmix(foot,target,k);
 }
   if(opts.climbBlend)foot=vecmix(foot,[side*.15,.11,-.16],opts.climbBlend);
   if(opts.slideBlend){const sole=M.point(base,[foot[0],foot[1]-.073,foot[2]+.11]);const correction=Math.max(0,pos[1]+.004-sole[1]);foot[1]+=correction/Math.max(.9,base[5]);}
   let hip=M.point(torsoLocal,[side*.145,.65,-.02]),k=knee(hip,foot,.325,.335,[side*.08,0,1]);
   rod(hip,k,.058,C.bare);ball(...k,.060,.061,.059,C.skin);rod(k,foot,.044,C.skin,true);
   let flex=air?-.20:0;ball(foot[0],foot[1]-.022,foot[2]+.041,.061,.045,.126,C.bare,flex);
   for(let j=0;j<4;j++)ball(foot[0]+(j-1.5)*.023,foot[1]-.029,foot[2]+.135,.019,.025,.031,C.skin);
   footWorld.push(M.point(base,[foot[0],foot[1]-.067,foot[2]]));
  }
 });
 const headMatrix=M.mul(torsoWorld,M.trs(0,1.465,0,(opts.nod||0)-lean*.36,opts.look||0,move?Math.sin(phase-.50)*.012:0)),hood=[];
 for(let u=0;u<16;u++)for(let v=0;v<=8;v++)hood.push(M.point(headMatrix,hoodPoint(u/16,v/8)));
 modelAudit.hero={hands:handWorld,feet:footWorld,reach:wrists.map((w,i)=>V.len(V.sub(w,shoulders[i]))),grip:opts.worldGrip||null,targets:opts.handTargets||null,targetWeights:opts.handTargetWeights||null,hoodBounds:{min:[0,1,2].map(i=>Math.min(...hood.map(p=>p[i]))),max:[0,1,2].map(i=>Math.max(...hood.map(p=>p[i])))},pose};
}


 const root=new THREE.Group(), pivot=new THREE.Group();root.name='Six_R13_true_geometry';pivot.name='Six_normalized_feet';root.add(pivot);
 const materials=new Map(), parts=[];
 function material(m){const key=m.name+'|'+m.color.join(',');if(!materials.has(key)){const color=new THREE.Color().setRGB(...m.color);materials.set(key,new THREE.MeshStandardMaterial({name:m.name,color,roughness:m.roughness??.9,metalness:m.kind===5?.1:0,side:THREE.DoubleSide}));}return materials.get(key);}
 function pose(time,beckon,grip=0){list=[];parent=M.id();
 const k=Math.max(0,Math.min(1,grip));
 child([0,0,0],-Math.PI/2,beckon?'beckon':'idle',time*2,{moving:false,depth:1,look:0,relaxedArms:k===0,
 handTargets:[null,[-.22,1.90,.32]],handTargetWeights:[0,k],shoulderLift:.12*k,gripHands:[0,k],air:k});
 }
 pose(0,false);
 for(const item of list){const part=new THREE.Mesh(item.mesh.geometry,material(item.mat));part.name=item.mat.name;part.matrixAutoUpdate=false;part.matrix.fromArray(item.m);part.castShadow=!item.noShadow;part.receiveShadow=true;pivot.add(part);parts.push(part);}
 root.updateMatrixWorld(true);const bounds=new THREE.Box3().setFromObject(root), height=bounds.max.y-bounds.min.y;
 pivot.scale.setScalar(1/height);pivot.position.y=-bounds.min.y/height;
 root.userData.six={provenance:'actual R13 child mesh data',forward:[-1,0,0],normalizedHeight:1,meshCount:parts.length,sourceHeight:height};
 function update(time=0,options={}){pose(Number.isFinite(time)?time:0,!!options.beckon,options.grip||0);if(list.length!==parts.length)throw Error('Six pose topology changed');for(let i=0;i<parts.length;i++){parts[i].matrix.fromArray(list[i].m);parts[i].matrixWorldNeedsUpdate=true;}root.userData.gripAudit={grip:options.grip||0,hands:modelAudit.hero.hands,targets:modelAudit.hero.targets};}
 update(0,{beckon:false});return {group:root,update,gripHeight:(1.90-bounds.min.y)/height};
};
})();
