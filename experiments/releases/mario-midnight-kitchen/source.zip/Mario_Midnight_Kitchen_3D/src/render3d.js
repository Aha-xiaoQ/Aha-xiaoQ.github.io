/* Midnight Kitchen 1.1 — true 2.5D geometry, common light and real depth.
 * Physics remains in pixels; this renderer maps 100px to one scene unit.
 * No landscape billboards or pre-rendered actor planes are used here. */
'use strict';
(()=>{
const S=.01,FLOOR=620,clamp=(v,a,b)=>Math.max(a,Math.min(b,v)),mix=(a,b,t)=>a+(b-a)*t;
let world=null,initError=null,captureCanvas=null,captureContext=null;
function random(seed){let a=seed|0;return()=>{a^=a<<13;a^=a>>>17;a^=a<<5;return(a>>>0)/4294967296;};}
function available(key){const i=globalThis.KitchenAssets?.images?.[key];return i&&i.complete&&i.naturalWidth?i:null;}
function buildWorld(view){
 const T=globalThis.THREE;if(!T)throw new Error('THREE vendor has not loaded');
 const canvas=document.getElementById('game');if(!canvas)throw new Error('Game WebGL canvas is missing');
 const renderer=new T.WebGLRenderer({canvas,antialias:false,alpha:false,powerPreference:'high-performance',preserveDrawingBuffer:false});
 const mobile=matchMedia('(pointer:coarse)').matches;
 const gl=renderer.getContext(),debug=gl.getExtension('WEBGL_debug_renderer_info'),gpu=debug?gl.getParameter(debug.UNMASKED_RENDERER_WEBGL):'';
 const software=/swiftshader|llvmpipe|software/i.test(gpu);const resolution=software?.64:mobile?.8:1;
 renderer.setPixelRatio(1);renderer.setSize(Math.round(view.w*resolution),Math.round(view.h*resolution),false);
 renderer.outputEncoding=T.sRGBEncoding;renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.18;
 renderer.shadowMap.enabled=true;renderer.shadowMap.type=T.BasicShadowMap;
 const scene=new T.Scene();scene.background=new T.Color(0x070b0c);scene.fog=new T.FogExp2(0x111c1b,.044);
 const camera=new T.PerspectiveCamera(38,view.w/view.h,.08,95);
 const colors={wood:0x554638,metal:0x44504c,cloth:0x8a8670,wall:0x747660,tile:0x535b54,iron:0x202a29,brass:0x76623d};
 const mats={},textures={},geos={},chunks=[],dynamic=new T.Group();scene.add(dynamic);
 const r=random(514811);
 function texture(kind){
  const c=document.createElement('canvas');c.width=c.height=256;const ct=c.getContext('2d');
  const img=ct.createImageData(256,256),rand=random(({wood:813,metal:619,cloth:715,wall:231,tile:393,iron:82,brass:165})[kind]||97);
  const base={wood:[84,70,56],metal:[84,92,88],cloth:[148,146,125],wall:[114,119,98],tile:[96,105,96],iron:[53,62,57],brass:[141,117,74]}[kind]||[90,90,90];
  for(let y=0;y<256;y++)for(let x=0;x<256;x++){
   const i=(y*256+x)*4;let n=(rand()-.5)*30;
   if(kind==='wood')n+=Math.sin(x*.3+Math.sin(y*.017)*4)*3+Math.sin(x*.85+y*.05)*1.3;
   if(kind==='cloth')n+=((x%3===0?1:-1)+(y%3===0?1:-1))*8;
   if(kind==='wall'||kind==='tile')n+=Math.sin(x*.059)*Math.cos(y*.045)*11;
   if(kind==='metal')n+=Math.sin(y*.67)*3;
   img.data[i]=base[0]+n;img.data[i+1]=base[1]+n;img.data[i+2]=base[2]+n;img.data[i+3]=255;
  }
  ct.putImageData(img,0,0);
  // Original LN scene crops only supply surface grain, never a room-wide photograph.
  const source=available('ln-'+(kind==='cloth'?'fabric':kind));
  if(source){ct.globalAlpha=kind==='tile'?.2:.16;ct.globalCompositeOperation='soft-light';ct.drawImage(source,0,0,256,256);ct.globalAlpha=1;ct.globalCompositeOperation='source-over';}
  if(kind==='wood'){
   ct.strokeStyle='rgba(18,13,9,.6)';ct.lineWidth=2;for(let x=0;x<256;x+=64){ct.beginPath();ct.moveTo(x,0);ct.bezierCurveTo(x+2,92,x-2,150,x,256);ct.stroke();}
   for(let k=0;k<8;k++){const x=rand()*256,y=rand()*256;ct.strokeStyle='rgba(25,18,12,.28)';ct.beginPath();ct.ellipse(x,y,2+rand()*3,12+rand()*15,.03,0,Math.PI*2);ct.stroke();}
  }
  if(kind==='tile'){
   ct.strokeStyle='rgba(25,38,34,.8)';ct.lineWidth=5;ct.strokeRect(0,0,128,128);ct.strokeRect(128,128,128,128);ct.strokeRect(128,0,128,128);ct.strokeRect(0,128,128,128);
   ct.fillStyle='rgba(10,18,15,.12)';ct.fillRect(0,0,128,128);ct.fillRect(128,128,128,128);
   ct.strokeStyle='rgba(31,36,29,.38)';ct.lineWidth=1;for(let k=0;k<6;k++){ct.beginPath();const x=rand()*256,y=rand()*256;ct.moveTo(x,y);ct.lineTo(x+12,y+8);ct.lineTo(x+21,y+4);ct.stroke();}
  }
  for(let k=0;k<45;k++){ct.fillStyle='rgba(17,26,20,'+(rand()*.1+.025)+')';ct.beginPath();ct.ellipse(rand()*256,rand()*256,rand()*18+2,rand()*12+1,rand()*3,0,Math.PI*2);ct.fill();}
  const tex=new T.CanvasTexture(c);tex.wrapS=tex.wrapT=T.RepeatWrapping;tex.anisotropy=1;tex.minFilter=T.LinearMipmapNearestFilter;tex.encoding=T.sRGBEncoding;tex.repeat.set(1,1);textures[kind]=tex;return tex;
 }
 for(const kind of Object.keys(colors)){
  const tex=texture(kind);mats[kind]=['metal','brass','iron'].includes(kind)?new T.MeshPhongMaterial({color:0xffffff,map:tex,shininess:kind==='brass'?32:11,specular:kind==='brass'?0x83745b:0x4a635e}):new T.MeshLambertMaterial({color:0xffffff,map:tex});
 }
 mats.dark=new T.MeshLambertMaterial({color:0x151c19});
 mats.black=new T.MeshLambertMaterial({color:0x080c0a});
 mats.ceramic=new T.MeshPhongMaterial({color:0xb0ad8c,shininess:38,specular:0x636550});
 mats.green=new T.MeshLambertMaterial({color:0x455949});
 mats.red=new T.MeshLambertMaterial({color:0x6e3527});
 mats.glass=new T.MeshPhongMaterial({color:0x46716c,shininess:35,specular:0x223a3b});
 mats.gold=new T.MeshPhongMaterial({color:0xd9ab36,shininess:54,specular:0xa48946,emissive:0x6d3605,emissiveIntensity:.27});
 mats.hot=new T.MeshLambertMaterial({color:0xff9e3b,emissive:0xff6b18,emissiveIntensity:2});
 mats.lamp=new T.MeshLambertMaterial({color:0xffd3a0,emissive:0xffb15e,emissiveIntensity:2.2});
 mats.water=new T.MeshPhongMaterial({color:0x153831,shininess:72,specular:0x4b7269});
 const haloMat=new T.MeshBasicMaterial({color:0xe5c37b,transparent:true,opacity:.095,depthWrite:false,side:T.DoubleSide,blending:T.AdditiveBlending});
 const warningMat=new T.MeshBasicMaterial({color:0xe3a96a,transparent:true,opacity:0,depthWrite:false,side:T.DoubleSide});
 geos.box=new T.BoxGeometry(1,1,1);geos.sphere=new T.SphereGeometry(1,12,9);geos.cyl=new T.CylinderGeometry(1,1,1,16);geos.torus=new T.TorusGeometry(1,.12,6,20);geos.plane=new T.PlaneGeometry(1,1);
 function mesh(parent,geo,mat,x,y,z,sx=1,sy=1,sz=1,rot=null){const o=new T.Mesh(geo,typeof mat==='string'?mats[mat]:mat);o.position.set(x,y,z);o.scale.set(sx,sy,sz);if(rot)o.rotation.set(...rot);o.castShadow=true;o.receiveShadow=true;parent.add(o);return o;}
 const box=(p,m,x,y,z,w,h,d,rot)=>mesh(p,geos.box,m,x,y,z,w,h,d,rot);
 const ball=(p,m,x,y,z,sx,sy,sz)=>mesh(p,geos.sphere,m,x,y,z,sx,sy,sz);
 const cyl=(p,m,x,y,z,rad,h,rz,rot)=>mesh(p,geos.cyl,m,x,y,z,rad,h,rz===undefined?rad:rz,rot);
 const ring=(p,m,x,y,z,rad,rot)=>mesh(p,geos.torus,m,x,y,z,rad,rad,rad,rot);
 function rod(p,m,a,b,rad){const d=new T.Vector3().subVectors(b,a),o=cyl(p,m,(a.x+b.x)/2,(a.y+b.y)/2,(a.z+b.z)/2,rad,d.length());o.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),d.normalize());return o;}
 const v=(x,y,z)=>new T.Vector3(x,y,z);
 function lathe(p,m,points,x,y,z,size=1){const key=JSON.stringify(points);let geo=geos[key];if(!geo)geo=geos[key]=new T.LatheGeometry(points.map(q=>new T.Vector2(q[0],q[1])),18);return mesh(p,geo,m,x,y,z,size,size,size);}
 function pot(p,x,y,z,scale=1,style=0){
  const grp=new T.Group();grp.position.set(x,y,z);grp.scale.setScalar(scale);p.add(grp);
  lathe(grp,style?'iron':'metal',[[.14,0],[.34,.02],[.38,.12],[.42,.52],[.41,.6],[.37,.63],[.35,.58],[.35,.15],[.18,.09]],0,0,0);
  ring(grp,'metal',0,.59,0,.39,[-Math.PI/2,0,0]);
  for(const s of [-1,1]){ring(grp,'iron',s*.45,.4,0,.19,[0,Math.PI/2,0]);box(grp,'iron',s*.37,.4,0,.1,.13,.13);}
  cyl(grp,'black',0,.112,0,.34,.012);
  return grp;
 }
 function pan(p,x,y,z,s=1,hang=false){
  const group=new T.Group();p.add(group);group.position.set(x,y,z);group.scale.setScalar(s);
  lathe(group,'iron',[[0,0],[.37,.025],[.42,.09],[.44,.14],[.38,.15],[.34,.075],[0,.06]],0,0,0);
  rod(group,'iron',v(.39,.12,0),v(1,.16,0),.065);ring(group,'iron',1.01,.16,0,.06,[-Math.PI/2,0,0]);
  if(hang)group.rotation.z=Math.PI/2;return group;
 }
 function plate(p,x,y,z,s=1){lathe(p,'ceramic',[[0,0],[.19,.005],[.27,.03],[.35,.04],[.37,.06],[.34,.075],[.21,.04],[0,.032]],x,y,z,s);}
 function hangingCloth(p,x,top,bottom,z,width,seed=1){
  const geometry=new T.PlaneGeometry(width,top-bottom,24,10),pos=geometry.attributes.position,rand=random(seed);
  for(let i=0;i<pos.count;i++){const px=pos.getX(i),py=pos.getY(i),fall=1-(py/(top-bottom)+.5);pos.setZ(i,Math.sin(px*15+seed)*(.04+.065*fall)+Math.sin(px*5)*.032);if(fall>.95)pos.setY(i,py+.018*Math.sin(px*31)+.018*rand());}
  geometry.computeVertexNormals();const material=mats.cloth.clone();material.side=T.DoubleSide;
  const o=mesh(p,geometry,material,x,(top+bottom)/2,z);return o;
 }
 function cabinet(p,x,y,z,w=2.3,h=2.2,d=1.2,open=false){
  box(p,'wood',x,y+h/2,z,w,h,d);box(p,'dark',x,y+.1,z+d*.52,w+.02,.18,.05);
  box(p,'wood',x,y+h+.08,z,w+.13,.16,d+.12);
  const doors=Math.max(1,Math.round(w/1.04)),dw=(w-.15)/doors;
  for(let j=0;j<doors;j++){
   const dx=x-w/2+.075+dw*(j+.5);
   box(p,'dark',dx,y+h*.51,z+d/2+.025,dw-.025,h*.86,.018);
   box(p,'wood',dx,y+h*.51,z+d/2+.07,dw-.09,h*.82,.055);
   box(p,'wood',dx,y+h*.51,z+d/2+.109,dw-.22,h*.64,.025);
   rod(p,'iron',v(dx+.2,y+h*.55,z+d/2+.15),v(dx+.2,y+h*.64,z+d/2+.15),.026);
   for(const yy of [y+.32,y+h-.33])box(p,'iron',dx-dw*.37,yy,z+d/2+.12,.06,.12,.025);
  }
 }
 function shelf(p,x,y,z,w){box(p,'wood',x,y,z,w,.13,.65);for(const xx of [x-w*.35,x+w*.35]){rod(p,'iron',v(xx,y-.05,z-.1),v(xx,y-.45,z-.25),.036);rod(p,'iron',v(xx,y-.45,z-.25),v(xx,y-.45,z-.42),.036);}}
 function stove(p,x,z,scale=1){
  const group=new T.Group();group.position.set(x,0,z);group.scale.setScalar(scale);p.add(group);
  box(group,'iron',0,1.05,0,2.8,2.1,1.35);box(group,'metal',0,2.12,0,2.94,.16,1.46);
  for(const xx of [-.72,.72]){ring(group,'black',xx,2.24,0,.47,[-Math.PI/2,0,0]);ring(group,'metal',xx,2.25,0,.35,[-Math.PI/2,0,0]);}
  for(const xx of [-.84,.84]){box(group,'black',xx,.94,.69,1.15,1.28,.06);box(group,'iron',xx,.94,.73,1.02,1.1,.03);rod(group,'metal',v(xx-.31,1.27,.8),v(xx+.31,1.27,.8),.035);}
  box(group,'black',0,.3,.77,2.56,.25,.035);
  for(let j=0;j<12;j++)box(group,'iron',-1.17+j*.21,.3,.79,.05,.24,.04);
  for(const xx of [-.9,-.6,-.3,.3,.6,.9])cyl(group,'black',xx,1.85,.76,.08,.07,.08,[Math.PI/2,0,0]);
  return group;
 }
 function bareLamp(p,x,y,z){
  rod(p,'iron',v(x,y+.75,z),v(x,y+.16,z),.025);
  lathe(p,'green',[[.08,.23],[.14,.2],[.36,.08],[.39,0],[.31,-.04],[.13,.15]],x,y,z);
  ball(p,'lamp',x,y-.035,z,.1,.13,.1);
  const halo=mesh(p,geos.sphere,haloMat,x,y-.03,z,.19,.23,.19);halo.castShadow=halo.receiveShadow=false;
 }
 function pipes(p,x,w){
  for(const y of [4.74,5.21]){rod(p,'metal',v(x,y,-5.05),v(x+w,y,-5.05),.065);for(let a=x+.6;a<x+w;a+=1.8){cyl(p,'iron',a,y,-5.05,.085,.075,.085,[0,0,Math.PI/2]);box(p,'iron',a,y,-5.24,.09,.27,.12);}}
  rod(p,'metal',v(x+w-.55,.25,-5.02),v(x+w-.55,5.2,-5.02),.082);
 }
 // Draw-call batching preserves material/normal/shadow detail without hundreds of per-frame meshes.
 function mergeStatic(group,split=false){
  group.updateMatrixWorld(true);const buckets=new Map();
  group.traverse(o=>{if(o.isMesh&&!Array.isArray(o.material)){const segment=split?Math.floor(o.getWorldPosition(new T.Vector3()).x/8):0,key=o.material.uuid+'|'+segment;let b=buckets.get(key);if(!b){b={mat:o.material,position:[],normal:[],uv:[],cast:false,segment};buckets.set(key,b);}const geo=o.geometry,pos=geo.attributes.position,no=geo.attributes.normal,uv=geo.attributes.uv,ind=geo.index;const nm=new T.Matrix3().getNormalMatrix(o.matrixWorld);const pv=new T.Vector3(),nv=new T.Vector3();const count=ind?ind.count:pos.count;for(let k=0;k<count;k++){const i=ind?ind.getX(k):k;pv.fromBufferAttribute(pos,i).applyMatrix4(o.matrixWorld);nv.fromBufferAttribute(no,i).applyMatrix3(nm).normalize();b.position.push(pv.x,pv.y,pv.z);b.normal.push(nv.x,nv.y,nv.z);if(geo===geos.box&&o.material.map){const ny=Math.abs(nv.y),nx=Math.abs(nv.x),nz=Math.abs(nv.z);if(ny>nx&&ny>nz)b.uv.push(pv.x,pv.z);else if(nx>nz)b.uv.push(pv.z,pv.y);else b.uv.push(pv.x,pv.y);}else b.uv.push(uv?uv.getX(i):0,uv?uv.getY(i):0);}b.cast=b.cast||o.castShadow;}});
  group.clear();const sections=new Map();for(const b of buckets.values()){const geo=new T.BufferGeometry();geo.setAttribute('position',new T.Float32BufferAttribute(b.position,3));geo.setAttribute('normal',new T.Float32BufferAttribute(b.normal,3));geo.setAttribute('uv',new T.Float32BufferAttribute(b.uv,2));geo.computeBoundingSphere();const o=new T.Mesh(geo,b.mat);o.castShadow=b.cast;o.receiveShadow=true;if(split){let section=sections.get(b.segment);if(!section){section=new T.Group();scene.add(section);sections.set(b.segment,section);chunks.push({group:section,center:b.segment*8+4,kind:'routebay'});}section.add(o);}else group.add(o);}
 }
 // The room is a sequence of real bays, each with deep cabinets and separate front/back props.
 for(let bay=0;bay<8;bay++){
  const p=new T.Group(),start=bay*8,rand=random(791+bay*537);scene.add(p);chunks.push({group:p,center:start+4,kind:'bay'});
  box(p,'wall',start+4,3.25,-5.6,8,6.5,.38);
  box(p,'dark',start+4,.28,-5.34,8,.56,.18);
  box(p,'dark',start+4,6.2,-3.45,8,.28,4.3);for(const xx of [start+.45,start+4.2,start+7.6])box(p,'wood',xx,5.98,-3.38,.2,.42,4.35);
  for(let col=0;col<4;col++){
   const xx=start+.85+col*2.04;
   box(p,'iron',xx,3.7,-5.35,.032,5.8,.03);
   if((bay<2&&col===(bay?1:3))||(bay===5&&col===0)){box(p,'dark',xx,4.14,-5.33,1.47,1.62,.16);for(let k=0;k<4;k++)box(p,'glass',xx-.54+k*.36,4.14,-5.23,.32,1.43,.035);box(p,'wood',xx,4.14,-5.14,1.56,.06,.12);box(p,'wood',xx,3.32,-5.13,1.61,.12,.45);}
  }
  pipes(p,start,8);
  // No complete cabinet occupies the gameplay lane: the giants work behind it.
  for(let j=0;j<3;j++){
   const xx=start+1.3+j*2.65;
   if(bay===5||(bay===3&&j===1))stove(p,xx,-3.7,1.04);
   else if(bay===4||bay===7){box(p,'iron',xx,1.1,-4.06,2.43,2.2,1.12);for(let k=0;k<6;k++)box(p,'metal',xx-1+k*.39,1.2,-3.475,.055,1.54,.035);box(p,'metal',xx,2.25,-4.05,2.52,.13,1.28);}
   else if(bay===2&&j===1){box(p,'iron',xx,1.12,-4,2.5,2.24,1.25);box(p,'metal',xx,2.28,-4,2.66,.14,1.5);box(p,'black',xx,2.36,-3.8,2.18,.035,1.05);box(p,'metal',xx,2.4,-4.35,2.4,.12,.075);box(p,'metal',xx,2.4,-3.26,2.4,.12,.075);for(const a of [-1.16,1.16])box(p,'metal',xx+a,2.4,-3.8,.075,.12,1.12);const points=[[xx,2.37,-4.55],[xx,3.1,-4.55],[xx,3.23,-4.32],[xx,3.15,-3.97],[xx,2.93,-3.91]].map(q=>v(...q));mesh(p,new T.TubeGeometry(new T.CatmullRomCurve3(points),15,.057,7,false),'metal',0,0,0);ring(p,'brass',xx+.31,2.53,-4.42,.11,[-Math.PI/2,0,0]);}
   else if(bay===6&&j===1){box(p,'wood',xx,1.6,-4,2.2,3.2,1.1);for(const yy of [.4,1.35,2.2,3.1]){box(p,'wood',xx,yy,-3.55,2.08,.09,.4);for(let k=0;k<4;k++)cyl(p,k%2?'ceramic':'glass',xx-.72+k*.48,yy+.27,-3.65,.145,.47);}}
   else cabinet(p,xx,0,-4.02,2.32+rand()*.2,2.05+rand()*.32,1.19+rand()*.14);
   if(j===1&&bay!==2&&bay!==6){pot(p,xx-.24,2.34,-3.78,.93+rand()*.45,j%2);for(let k=0;k<3;k++)plate(p,xx+.61,2.35+k*.035,-3.86,1.2);}
   else if(bay!==6){const tilt=pot(p,xx+.12,2.34,-3.8,.6+rand()*.8,j%2);tilt.rotation.z=(rand()-.5)*.08;ball(p,'ceramic',xx-.67,2.46,-3.83,.17,.2,.17);}
  }
  shelf(p,start+3.35,4.38+rand()*.4,-4.89,4.15+rand()*.6);
  for(let j=0;j<5;j++){const xx=start+1.2+j*.83;const n=Math.floor(rand()*7)+2;for(let k=0;k<n;k++)plate(p,xx+Math.sin(k*2+j)*.015,4.64+k*.023,-4.66,.65+rand()*.15);}
  rod(p,'iron',v(start+.65,5.6,-2.7),v(start+7.55,5.6,-2.7),.065);
  for(let j=0;j<3;j++){
   const xx=start+.9+j*2.2+rand()*.25;rod(p,'iron',v(xx,5.65,-2.7),v(xx,5.05,-2.7),.032);
   if(j%2===0)pan(p,xx,4.54,-2.7,.65+rand()*.28,true);
   else{ring(p,'metal',xx,4.68,-2.7,.33,[0,0,0]);rod(p,'iron',v(xx,4.99,-2.7),v(xx,5.21,-2.7),.026);}
  }
  bareLamp(p,start+3.3,4.88,-1.1);
  if(bay===3||bay===4){rod(p,'iron',v(start+.4,3.9,-2.85),v(start+7.4,3.9,-2.85),.32);for(let k=0;k<5;k++)ring(p,'metal',start+.7+k*1.54,3.9,-2.85,.334,[0,Math.PI/2,0]);rod(p,'metal',v(start+6.8,3.9,-2.85),v(start+6.8,.6,-2.85),.17);ring(p,'brass',start+6.8,1.62,-2.58,.27,[0,0,0]);for(const a of [0,Math.PI/2])rod(p,'brass',v(start+6.8-Math.cos(a)*.25,1.62-Math.sin(a)*.25,-2.57),v(start+6.8+Math.cos(a)*.25,1.62+Math.sin(a)*.25,-2.57),.02);}
  if(bay===5){box(p,'iron',start+4,4.01,-3.05,6.9,.18,2.0);const hood=mesh(p,new T.CylinderGeometry(.7,1.65,1.6,4,1,false),'metal',start+4,4.88,-3.27,1.8,1,.85,[0,Math.PI/4,0]);rod(p,'iron',v(start+4,5.65,-3.27),v(start+4,6.4,-3.27),.34);for(let k=0;k<10;k++)box(p,'dark',start+1.07+k*.65,3.83,-2.06,.4,.055,.035);}
  if(bay===7){box(p,'iron',start+3.8,3.55,-5.23,6.6,4.55,.12);for(let k=0;k<13;k++)box(p,'dark',start+.93+k*.45,3.55,-5.13,.23,3.81,.025);for(const yy of [2,5.12])box(p,'metal',start+3.8,yy,-5.05,6.79,.13,.08);}
  // Crooked shelves, chipped plaster edges and stains give each room bay a different silhouette.
  for(let k=0;k<6;k++){const xx=start+rand()*7.5,yy=.7+rand()*4.7;box(p,'dark',xx,yy,-5.38,.025+rand()*.095,.16+rand()*.53,.014,[0,0,(rand()-.5)*.1]);}

  // Foreground intrusions make Mario's corridor feel like the bottom of a huge room.
  if(bay===0){cabinet(p,1.08,0,-2.5,2.1,2.7,1.3);hangingCloth(p,1.24,2.9,.94,-1.76,1.76,581);}
  if([2,4,6].includes(bay)){box(p,'wood',start+7.2,1.17,-3.25,1.2,2.34,1.15);pot(p,start+7.15,2.37,-3.25,1.2,1);}
  // Surface crumbs and chipped tile lips are actual mesh scatter, not a painted overlay.
  for(let k=0;k<11;k++){const xx=start+rand()*7.8;if(xx>44.35&&xx<46.25)continue;box(p,k%3===0?'ceramic':'dark',xx,.009,-.9+rand()*2.2,.025+rand()*.06,.012,.03+rand()*.06,[0,rand()*5,0]);}
  p.position.z=-.55;mergeStatic(p);p.traverse(o=>{if(o.isMesh)o.castShadow=false;});
 }
 // Ground geometry has a genuinely open fissure, and an open abyss after the final wall.
 const floors=new T.Group();scene.add(floors);chunks.push({group:floors,center:32,kind:'floor'});
 for(const [a,b] of [[0,44.5],[46.1,58.2]]){
  box(floors,'tile',(a+b)/2,-.15,-.6,b-a,.3,5.8);
  box(floors,'iron',(a+b)/2,-.29,2.26,b-a,.21,.11);
  for(let x=a+.45;x<b;x+=1.28){box(floors,'dark',x,-.006,2.23,.025,.015,.2);}
 }
 box(floors,'black',45.3,-3.2,-.5,1.58,6.2,5.8);
 for(const xx of [44.46,46.14])box(floors,'metal',xx,-.028,-.58,.08,.13,5.86);
 // Grates glow underneath the split; the route edge remains dark and legible.
 for(let k=0;k<6;k++)box(floors,'hot',44.73+k*.21,-1.6,-1.9,.08,.025,1.2);
 mergeStatic(floors);floors.traverse(o=>{if(o.isMesh)o.castShadow=false;});
 const props=new T.Group();scene.add(props);chunks.push({group:props,center:22,kind:'route'});
 // The low stretcher is the physical roof. The tall table/cloth sits in the front depth plane.
 for(const [xx,ww,seed] of [[9,3.6,902],[15.4,2.6,1540]]){
  const cx=xx+ww/2;
  box(props,'wood',cx,2.24,1.98,ww+.3,.2,1.6);
  box(props,'wood',cx,2.07,2.74,ww+.28,.25,.16);
  for(const lx of [xx+.14,xx+ww-.14])for(const zz of [1.28,2.65]){
   box(props,'wood',lx,1.11,zz,.19,2.21,.2);box(props,'iron',lx,.22,zz,.235,.22,.25);
  }
  box(props,'wood',cx,.43,.12,ww,.14,.4);
  hangingCloth(props,cx,2.36,.575,1.14,ww+.15,seed);
  hangingCloth(props,cx,2.36,1.34,2.82,ww+.13,seed+3);
  pot(props,cx-.65,2.38,1.85,1.37,1);for(let k=0;k<5;k++)plate(props,cx+.68,2.37+k*.035,2.03,1.4);
  box(props,'black',cx,.012,.12,ww-.12,.015,.46);
 }
 // Readable teaching surfaces are actual sacks and an overturned tin, at their exact collision bounds.
 function obstacle(x,y,w,h,kind){const cx=(x+w/2)*S,cy=(FLOOR-y-h/2)*S;box(props,kind,cx,cy,.12,w*S,h*S,.4);}
 obstacle(285,585,100,35,'cloth');
 ball(props,'cloth',3.34,.25,.12,.43,.175,.19);box(props,'cloth',3.34,.324,.12,.14,.025,.4);
 obstacle(525,565,115,55,'metal');const teachingTinRim=ring(props,'iron',5.83,.56,.12,.45,[-Math.PI/2,0,0]);teachingTinRim.scale.y*=.45;
 obstacle(3000,554,80,66,'wood');box(props,'wood',30.4,.67,.12,.93,.08,.44);
 for(const x of [30.14,30.65])box(props,'iron',x,.34,.345,.06,.61,.035);
 obstacle(3970,587,70,33,'cloth');ball(props,'cloth',40.05,.24,.12,.32,.14,.18);
 obstacle(4050,540,180,80,'wood');box(props,'wood',41.4,.81,.12,1.92,.08,.44);
 for(const x of [40.64,41.25,41.85])rod(props,'iron',v(x-.12,.53,.35),v(x+.12,.53,.35),.029);
 obstacle(4970,560,120,60,'wood');box(props,'wood',50.3,.61,.12,1.31,.08,.44);rod(props,'iron',v(50.12,.38,.35),v(50.46,.38,.35),.04);
 obstacle(5250,575,85,45,'metal');
 box(props,'metal',54.525,.79,.12,2.35,.22,.4);for(const xx of [53.5,55.5]){rod(props,'iron',v(xx,.04,-.04),v(xx,.73,-.04),.05);rod(props,'iron',v(xx,.04,.29),v(xx,.73,.29),.05);}
 // The final wall is an actual thick iron bulkhead, not a warm portal.
 box(props,'iron',56.17,.5,.1,.34,1,.7);for(let z=-.19;z<.42;z+=.2)box(props,'metal',56.17,.96,z,.43,.08,.035);
 for(let k=0;k<6;k++)cyl(props,'brass',55.97,.12+k*.15,.465,.023,.035,.023,[0,0,Math.PI/2]);
 // The hook's approach rail and power mechanism share the exit module's rail height.
 rod(props,'metal',v(54.53,2.22,-.02),v(59.5,2.22,-.02),.035);
 for(const xx of [54.55,56.32,58.33]){box(props,'iron',xx,2.36,-.32,.055,.28,.56);rod(props,'iron',v(xx,2.51,-.55),v(xx,4.15,-.55),.026);}
 box(props,'iron',55.45,1.095,-.15,.34,.34,.34);box(props,'metal',55.45,1.095,.035,.255,.26,.045);
 rod(props,'metal',v(55.58,1.04,-.12),v(55.78,1.34,-.12),.035);ball(props,'brass',55.78,1.34,-.12,.065,.06,.06);
 ring(props,'metal',55.45,1.115,.09,.065,[0,0,0]);
 rod(props,'iron',v(55.32,1.3,-.16),v(55.32,2.22,-.16),.012);
 // The landing platform uses exactly the final collider, 6120/515/210/28.
 box(props,'metal',62.25,.91,0,2.1,.28,1.18);box(props,'iron',62.25,.77,.58,2.14,.05,.065);
 // Gate's fixed counterweight machine and pressure plate.
 box(props,'iron',22.33,1.65,-1.45,.4,3.3,.31);box(props,'iron',22.33,1.65,1.35,.4,3.3,.31);box(props,'metal',22.33,3.31,-.05,.46,.23,3.24);
 for(const zz of [-1.45,1.35]){ring(props,'brass',22.33,3.45,zz,.16,[0,Math.PI/2,0]);}
 box(props,'brass',20.9,.035,0,.99,.07,.8);box(props,'dark',20.9,.008,0,1.1,.018,.94);
 rod(props,'iron',v(21.35,.02,-.35),v(22.08,.02,-.35),.017);rod(props,'iron',v(22.08,.02,-.35),v(22.08,3.3,-1.35),.017);
 // A giant spoon in the second chase bay can swing over the entire miniature route.
 const spoon=new T.Group();dynamic.add(spoon);spoon.position.set(39.15,5.8,.7);
 rod(spoon,'metal',v(0,0,0),v(0,-3.16,0),.052);
 ball(spoon,'metal',0,-3.45,0,.39,.51,.105);ball(spoon,'dark',0,-3.43,.082,.28,.39,.023);
 ring(spoon,'iron',0,.05,0,.12,[0,0,0]);
 // Giant oven/fire physically behind the gap. The glow is part of the same scene lighting.
 const oven=stove(props,45.15,-4.6,1.68);box(props,'hot',45.15,.38,-3.29,3.7,.21,.035);
 const fireFill=new T.PointLight(0xf18630,1.6,8,2);fireFill.position.set(45.15,1,-2.95);scene.add(fireFill);
 mergeStatic(props,true);
 // Dynamically deformable low pipe: its visual top follows the real collision roof.
 const duct=new T.Group();dynamic.add(duct);duct.position.set(35.7,0,0);
 const pipeRoof=box(duct,'metal',0,.43,.12,2.4,.14,.4);
 for(const x of [-1.2,1.2]){box(duct,'iron',x,.16,-.04,.085,.32,.08);box(duct,'iron',x,.16,.29,.085,.32,.08);}
 for(let k=0;k<11;k++){box(duct,'iron',-.98+k*.196,.515,.12,.035,.022,.44);}
 const dent=box(duct,'iron',-.25,.54,.12,.32,.05,.39);dent.visible=false;
 // True moving crate and portcullis.
 const crate=new T.Group();dynamic.add(crate);crate.scale.z=.5;crate.position.z=.12;box(crate,'wood',0,.32,0,.7,.64,.8);box(crate,'wood',0,.66,0,.78,.05,.87);
 for(const x of [-.28,.28]){box(crate,'iron',x,.32,.415,.05,.61,.026);box(crate,'iron',x,.32,-.415,.05,.61,.026);box(crate,'iron',x,.664,0,.05,.02,.86);}
 for(const z of [-.29,.29])box(crate,'wood',0,.31,z,.705,.065,.055);
 const gate=new T.Group();dynamic.add(gate);gate.position.set(22.33,0,0);
 for(let z=-1.18;z<=1.21;z+=.26){box(gate,'iron',0,1.15,z,.26,2.3,.054);ball(gate,'iron',0,.08,z,.13,.14,.06);}
 for(const yy of [.18,1.03,1.94,2.25])box(gate,'metal',0,yy,.015,.27,.11,2.62);
 const hook=new T.Group();dynamic.add(hook);
 cyl(hook,'metal',0,.32,-.015,.095,.07,.095,[Math.PI/2,0,0]);ring(hook,'iron',0,.32,.04,.067,[0,0,0]);
 rod(hook,'iron',v(0,.29,0),v(0,.07,0),.017);
 const hookMetal=mesh(hook,new T.TorusGeometry(.083,.025,7,20,Math.PI*1.64),'metal',.032,.001,0,1,1,1,[0,0,.28]);
 ball(hook,'metal',-.041,.065,0,.025,.029,.025);
 // A short grab bar on the returning hook carries both characters.
 const escapeBar=new T.Group();dynamic.add(escapeBar);escapeBar.name='shared-hook-grab-bar';
 rod(escapeBar,'iron',v(-.53,0,0),v(.53,0,0),.019);
 rod(escapeBar,'iron',v(-.53,0,-.08),v(-.53,0,.08),.012);
 rod(escapeBar,'iron',v(.53,0,-.08),v(.53,0,.08),.012);
 rod(escapeBar,'metal',v(.276,0,-.02),v(.276,0,.12),.015);
 // Mario's short arms hold a lower ring, keeping the main bar clear of his cap.
 rod(escapeBar,'brass',v(-.48,0,0),v(-.48,-.08,0),.009);
 mesh(escapeBar,new T.TorusGeometry(.05,.012,8,20),'brass',-.48,-.13,0);
 escapeBar.visible=false;
 const hookTether=box(dynamic,'iron',0,0,0,.018,1,.018);hookTether.visible=false;
 const hookLamp=ball(dynamic,'lamp',55.45,1.15,.07,.033,.045,.024);
 const bells=[];for(const x of [7.9,16]){
  const p=new T.Group();dynamic.add(p);p.position.set(x,.07,.45);p.rotation.z=-.12;
  lathe(p,'metal',[[0,0],[.32,.01],[.36,.05],[.28,.11],[.15,.19],[0,.2]],0,0,0);
  ring(p,'iron',0,.215,0,.085,[0,0,0]);box(p,'wood',0,-.025,0,.52,.065,.45);bells.push(p);
 }
 const coinObjects=[];for(let i=0;i<3;i++){const p=new T.Group();dynamic.add(p);const coin=cyl(p,'gold',0,0,0,.12,.045,.12,[Math.PI/2,0,0]);ring(p,'gold',0,0,.027,.09,[0,0,0]);box(p,'gold',0,0,.058,.024,.125,.02);coinObjects.push(p);}
 const checkpoints=[];for(const x of [14.2,23.2]){
  const p=new T.Group();dynamic.add(p);p.position.set(x,0,-.62);box(p,'iron',0,.18,0,.16,.36,.16);box(p,'glass',0,.22,.092,.11,.19,.025);const b=ball(p,'lamp',0,.21,.105,.045,.07,.025);checkpoints.push({group:p,bulb:b});
 }
 // Sparse light shafts are shallow translucent volumes, not full-frame gradient passes.
 const shaftGeo=new T.ConeGeometry(1,1,20,1,true);
 for(let i=0;i<8;i++){const shaftMat=new T.MeshBasicMaterial({color:0xa9a077,opacity:.018,transparent:true,depthWrite:false,side:T.FrontSide});const o=mesh(scene,shaftGeo,shaftMat,i*8+3.3,2.39,-1.1,1.5,4.8,1.5);o.castShadow=o.receiveShadow=false;}
 const hemi=new T.HemisphereLight(0x89afaa,0x151b12,.36);scene.add(hemi);
 const keyLight=new T.SpotLight(0xffbd76,4.3,19,.91,.58,1.0);keyLight.position.set(4,6,4);keyLight.target.position.set(4,0,-1);scene.add(keyLight,keyLight.target);keyLight.castShadow=true;
 keyLight.shadow.mapSize.set(512,512);keyLight.shadow.camera.near=.5;keyLight.shadow.camera.far=21;keyLight.shadow.bias=-.00045;keyLight.shadow.normalBias=.032;keyLight.shadow.radius=2;
 const rim=new T.DirectionalLight(0x628d93,.34);rim.position.set(-2,4,-5);scene.add(rim);
 const followLight=new T.PointLight(0xc1995f,.38,13,1.4);scene.add(followLight);
 const dangerCone=mesh(dynamic,new T.ConeGeometry(.62,3.9,20,1,true),warningMat,0,0,0);dangerCone.castShadow=dangerCone.receiveShadow=false;
 // A low route-local impact decal announces the palm's contact area before the hit.
 const impactMat=new T.MeshBasicMaterial({color:0xa96638,transparent:true,opacity:0,side:T.DoubleSide,depthWrite:false});
 const impact=mesh(dynamic,new T.RingGeometry(.28,.43,24),impactMat,35.2,.013,0,1,1,1,[-Math.PI/2,0,0]);impact.castShadow=impact.receiveShadow=false;
 const steamMat=new T.MeshBasicMaterial({color:0xa8b6a9,transparent:true,opacity:.055,depthWrite:false});
 const motes=new T.InstancedMesh(geos.sphere,steamMat,12);motes.castShadow=motes.receiveShadow=false;scene.add(motes);const matrix=new T.Matrix4(),quat=new T.Quaternion(),scale=new T.Vector3();
 let marioRig=null,chefRig=null,sixRig=null,ending=null,lastTime=0,lastChefX=14.8,lastSig='',lampSmooth=3.3,lastShadowTime=-99,lastGLMs=0,lastCopyMs=0;
 function safeRigMetadata(value,depth=0){
  if(value==null||typeof value==='string'||typeof value==='boolean')return value;
  if(typeof value==='number')return Number.isFinite(value)?value:null;
  if(depth>4||typeof value!=='object'||value.isObject3D||value.isMaterial||value.isTexture)return undefined;
  if(Array.isArray(value))return value.slice(0,100).map(v=>safeRigMetadata(v,depth+1)).filter(v=>v!==undefined);
  const result={};for(const [key,v]of Object.entries(value)){const safe=safeRigMetadata(v,depth+1);if(safe!==undefined)result[key]=safe;}return result;
 }
 function actorInfo(rig){
  const metadata=rig?.modelInfo||rig?.group?.userData?.modelRig||rig?.group?.userData?.modelInfo||{};
  const rawSource=rig?.sourceModel||rig?.group?.userData?.sourceModel||null;
  const sourceModel=typeof rawSource==='string'?rawSource:rawSource?(rawSource.identity||rawSource.id||rawSource.name||rawSource.path||'imported model'):null;
  const info={rootPosition:rig?.group?.position?.toArray()||null,heading:rig?.group?.rotation?.toArray()?.slice(0,3)||null,sourceModel,identity:metadata.identity||sourceModel,source:metadata.source||null,rigInfo:safeRigMetadata(metadata),meshes:0,meshCount:0,skinnedMeshes:0,skeletons:0,bones:0,nodeBoneCount:0,skeletonBoneCount:0,rigBoneCount:0,boneAttachedMeshCount:0,skinningVertices:0,materials:0,materialCount:0,triangles:0,textureCount:0,mapCount:0,mapsBySlot:{},textures:[],skinned:false,boneAttached:false,clips:[],actions:[],action:rig?.group?.userData?.action||rig?.group?.userData?.animation||rig?.currentAction||metadata.action||null,animationTime:null,clip:null,clipTime:null,clipDuration:null,ready:false};
  const skeletons=new Set(),skeletonBones=new Set(),nodeBones=new Set(),materials=new Map(),textures=new Map(),mapsBySlot=new Map();
  const declaredBones=rig?.bones instanceof Map?[...rig.bones.values()]:Object.values(rig?.bones||{}),rigBones=new Set(declaredBones.filter(b=>b?.isObject3D));
  const slots=['map','normalMap','bumpMap','roughnessMap','metalnessMap','aoMap','emissiveMap','alphaMap','displacementMap','lightMap','envMap','specularMap'];
  rig?.group?.traverse(o=>{
   if(o.isBone)nodeBones.add(o);if(!o.isMesh)return;info.meshes++;
   const geo=o.geometry;if(geo)info.triangles+=Math.floor((geo.index?.count||geo.attributes.position?.count||0)/3);
   for(const mat of(Array.isArray(o.material)?o.material:[o.material]))if(mat)materials.set(mat.uuid,mat);
   if(o.isSkinnedMesh&&o.skeleton){info.skinnedMeshes++;skeletons.add(o.skeleton);for(const b of o.skeleton.bones||[])skeletonBones.add(b);if(geo?.attributes.skinIndex&&geo?.attributes.skinWeight)info.skinningVertices+=geo.attributes.skinWeight.count;}
   for(let ancestor=o.parent;ancestor&&ancestor!==rig.group;ancestor=ancestor.parent){if(ancestor.isBone||rigBones.has(ancestor)){info.boneAttachedMeshCount++;break;}}
  });
  for(const mat of materials.values())for(const slot of slots){const map=mat[slot];if(!map?.isTexture)continue;textures.set(map.uuid,map);if(!mapsBySlot.has(slot))mapsBySlot.set(slot,new Set());mapsBySlot.get(slot).add(map.uuid);info.mapCount++;}
  info.textures=[...textures.values()].map(tex=>{const img=tex.source?.data||tex.image;return{name:tex.name||'',width:img?.naturalWidth||img?.width||0,height:img?.naturalHeight||img?.height||0,encoding:tex.encoding};});
  for(const [slot,maps]of mapsBySlot)info.mapsBySlot[slot]=maps.size;
  const actualActions=new Set(rig?.mixer?._actions||[]);for(const action of Object.values(rig?.actions||{}))if(action?.getClip)actualActions.add(action);
  const actualClips=new Map();for(const clip of [...(Array.isArray(rig?.clips)?rig.clips:[]),...(Array.isArray(rig?.animations)?rig.animations:[])])if(clip?.tracks&&Number.isFinite(clip.duration))actualClips.set(clip.uuid||clip.name,clip);
  for(const action of actualActions){const clip=action.getClip?.()||action._clip;if(!clip)continue;actualClips.set(clip.uuid||clip.name,clip);info.actions.push({name:clip.name,time:Number.isFinite(action.time)?action.time:null,duration:clip.duration,weight:action.getEffectiveWeight?.()??action.weight,enabled:!!action.enabled,paused:!!action.paused,running:action.isRunning?.()??false});}
  info.clips=[...actualClips.values()].map(clip=>({name:clip.name,duration:clip.duration,tracks:clip.tracks?.length||0}));
  const active=info.actions.find(a=>a.running&&a.weight>.001)||info.actions.find(a=>a.enabled&&a.weight>.001);if(active){info.clip=active.name;info.clipTime=active.time;info.clipDuration=active.duration;}
  info.animationTime=Number.isFinite(rig?.mixer?.time)?rig.mixer.time:Number.isFinite(rig?.group?.userData?.animationTime)?rig.group.userData.animationTime:null;
  info.skeletons=skeletons.size;info.skeletonBoneCount=skeletonBones.size;info.nodeBoneCount=nodeBones.size;info.rigBoneCount=rigBones.size;info.bones=new Set([...skeletonBones,...nodeBones,...rigBones]).size;info.boneCount=info.bones;
  info.materials=info.materialCount=materials.size;info.textureCount=textures.size;info.meshCount=info.meshes;info.skinned=info.skinnedMeshes>0&&info.skeletonBoneCount>0&&info.skinningVertices>0;info.boneAttached=info.boneAttachedMeshCount>0;info.ready=!!sourceModel&&info.meshes>0&&(info.skinned||info.boneAttached);
  const sample=[...new Set([...skeletonBones,...rigBones])].filter(b=>/hips|spine|head|hand|foot/i.test(b.name)).slice(0,12);const rounded=n=>Math.round(n*10000)/10000;
  info.bonePose=sample.map(b=>({name:b.name,position:b.position.toArray().map(rounded),quaternion:b.quaternion.toArray().map(rounded)}));return info;
 }
 function ensureImportedShadows(rig,receive=true){if(rig._kitchenShadowsReady)return;let meshes=0;rig.group.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=receive;meshes++;}});if(meshes&&rig.sourceModel)rig._kitchenShadowsReady=true;}
 function addRigs(){if(!globalThis.createMarioRig3D||!globalThis.createChefRig3D)throw new Error('3D actor modules are missing');if(!marioRig){marioRig=globalThis.createMarioRig3D(T);dynamic.add(marioRig.group);}if(!chefRig){chefRig=globalThis.createChefRig3D(T);dynamic.add(chefRig.group);}if(!sixRig&&globalThis.createSixModel3D){sixRig=globalThis.createSixModel3D(T);sixRig.group.name='Six-waiting-at-service-exit';sixRig.group.scale.setScalar(.56);sixRig.group.position.set(62.48,1.05,0);dynamic.add(sixRig.group);}if(!ending&&globalThis.createKitchenEnding3D)ending=globalThis.createKitchenEnding3D(T,scene);}
 addRigs();
 const baseCamera={position:new T.Vector3(),target:new T.Vector3()};
 function update(g,view){
  const time=view.time||g.time||0,dt=clamp(time-lastTime,0,.05);lastTime=time;const cx=(view.camX+view.w/2)*S;
  baseCamera.position.set(cx+.3,1.38,10.65);baseCamera.target.set(cx,2.54,0);
  camera.position.copy(baseCamera.position);camera.lookAt(baseCamera.target);
  const lampTarget=3.3+Math.round((cx-3.3)/8)*8;lampSmooth=mix(lampSmooth,lampTarget,1-Math.exp(-dt*1.9));const lampX=lampSmooth;keyLight.position.set(lampX,4.72,.75);keyLight.target.position.set(lampX+.4,0,-.5);keyLight.target.updateMatrixWorld();
  followLight.position.set(lampX+8,4.7,-1.25);
  const p=g.player||{x:130,y:572,w:32,h:48,face:1},ch=g.chef||{x:1480,y:620,face:1,state:'patrol',attack:'none'};
  addRigs();
  marioRig.group.position.set((p.x+p.w/2)*S,(FLOOR-p.y-p.h)*S,0);if(!g.finished||time-g.wonAt<=1.7)marioRig.update(p,g,time,dt);ensureImportedShadows(marioRig);
  // The full imported body needs a separate rear walking lane; x/y physics stays unchanged.
  // Its measured lower vertices lead by ~1.50m in Z, so a narrow Mario rail clears it.
  const ease=t=>{t=clamp(t,0,1);return t*t*(3-2*t);};
  let chefZ=-1.8;
  if(ch.x>3350&&ch.x<3720&&ch.ductPassed)chefZ-=Math.sin(clamp((ch.x-3350)/370,0,1)*Math.PI)*.15;
  if(ch.attack==='windup')chefZ=mix(-1.8,-.9,ease((ch.attackAge||0)/.55));
  else if(ch.attack==='impact')chefZ=-.9;
  else if(ch.attack==='recover')chefZ=mix(-.9,-1.8,ease((ch.attackAge||0)/.65));
  if(ch.state==='grab')chefZ=mix(-1.8,-.66,ease((ch.grabTimer||0)/.4));
  if(ch.x>5460)chefZ=mix(chefZ,-.66,ease((ch.x-5460)/140));
  // A continuous visual stop accounts for the original model's 1.175m shoe/body leading extent.
  // The AI still stops at x=5600; only the mesh center stops earlier at the same bulkhead.
  const chefPhysicalX=ch.x*S,chefRenderX=chefPhysicalX<=54.4?chefPhysicalX:54.4+.375*(1-Math.exp(-(chefPhysicalX-54.4)/.375));
  chefRig.group.position.set(chefRenderX,0,chefZ);chefRig.update(ch,g,time,dt);ensureImportedShadows(chefRig,false);
  lastChefX=ch.x*S;chefRig.group.visible=Math.abs(ch.x*S-cx)<10.2;
  crate.position.x=(g.crate?.x||1830)*S+.35;gate.position.y=(g.gateAmount||0)*2.38;
  const slam=Math.max(0,g.pipeSlamAge??-1),shake=g.pipeSlamAge>=0?Math.sin(slam*36)*Math.exp(-slam*5)*.035:0;
  pipeRoof.position.y=g.pipeCrushed?.37:.43;pipeRoof.rotation.z=shake;dent.visible=!!g.pipeCrushed;dent.position.y=.435;
  spoon.rotation.z=Math.sin(time*.75)*.105+Math.sin(time*.19)*.025;
  const e=g.escape||{};hook.position.set((e.hookX||5670)*S,(FLOOR-(e.hookY||430))*S,0);hook.rotation.z=Math.sin(time*2.8)*((e.attached||e.returning)?.035:.008);hookLamp.visible=!!e.powered;
  bells.forEach((b,i)=>{const x=i?1600:790;b.visible=Math.abs(x*S-cx)<9;const age=g.sounds?.filter(s=>Math.abs(s.x-x)<50).map(s=>s.age).sort((a,b)=>a-b)[0];b.rotation.z=-.12+(age===undefined?0:Math.sin(age*38)*Math.exp(-age*4)*.14);});
  coinObjects.forEach((o,i)=>{const c=g.coins?.[i];o.visible=!!c&&!c.taken;if(c){o.position.set(c.x*S,(FLOOR-c.y)*S+.02,0);o.rotation.y=time*2+i;o.position.y+=Math.sin(time*3+i)*.035;}});
  checkpoints.forEach((o,i)=>{o.bulb.visible=g.checkpoint>=i+1;});
  const suspicious=!g.chase&&ch.alert>.05&&ch.state!=='patrol';warningMat.opacity=suspicious?.023+ch.alert*.036:0;
  const dir=ch.face||1;dangerCone.position.set(ch.x*S+dir*1.83,.83,-.2);dangerCone.rotation.z=-dir*Math.PI/2;dangerCone.scale.set(.6,1,1.1);
  impactMat.opacity=ch.attack==='windup'?.12+Math.sin(ch.attackAge*9)*.06:ch.attack==='impact'?.25:0;impact.position.x=(ch.attackX||3520)*S;impact.scale.setScalar(ch.attack==='windup'?.85+ch.attackAge*.35:1.18);
  for(let i=0;i<12;i++){const xx=cx-6.7+((i*1.933+time*(.045+i%3*.012))%13.4),yy=.9+((i*.733+time*.06)%4.6),zz=-4.3+(i%7)*.81;scale.setScalar(.014+(i%4)*.007);matrix.compose(v(xx,yy,zz),quat,scale);motes.setMatrixAt(i,matrix);}motes.instanceMatrix.needsUpdate=true;
  crate.visible=Math.abs(crate.position.x-cx)<9;gate.visible=Math.abs(22.33-cx)<9;duct.visible=Math.abs(35.7-cx)<9;spoon.visible=Math.abs(39.15-cx)<9;hook.visible=Math.abs(hook.position.x-cx)<10;hookLamp.visible=hookLamp.visible&&Math.abs(55.45-cx)<9;dangerCone.visible=Math.abs(ch.x*S-cx)<10;impact.visible=Math.abs(35.2-cx)<9;
  if(sixRig){
   sixRig.group.visible=p.x>4900;sixRig.group.position.set(62.48,1.05,0);
   const age=g.finished?Math.max(0,time-g.wonAt):-1;
   const grip=ease((age-1.7)/.6),travel=ease((age-2.6)/9.0);
   const hx=mix(61.9,62.22,ease((age-.3)/1.2))+travel*7.0;
   const hy=mix(1.9,1.05+sixRig.gripHeight*.56,ease((age-.4)/1.2));
   // Both bodies stay anchored to the same moving bar after hands close.
   if(age>=0){
     hook.visible=true;hook.position.set(hx,hy+.05,0);hook.rotation.z=0;
     escapeBar.visible=true;escapeBar.position.set(hx,hy,0);
     const lower=hy+.37;hookTether.visible=true;hookTether.position.set(hx,(2.22+lower)/2,0);hookTether.scale.y=Math.max(.02,2.22-lower);
     if(grip>0){
       const mx=mix((p.x+p.w/2)*S,hx-.34,grip);
       const my=mix((FLOOR-p.y-p.h)*S,hy-.68,grip);
       marioRig.group.position.set(mx,my,0);
       marioRig.update({...p,face:1,grounded:false,vx:0}, {...g,escape:{...e,attached:true,hookX:(mx-.14)*100,hookY:(620-(hy-.155)*100)}},time,dt);
       sixRig.group.position.set(mix(62.48,hx+.34,grip),hy-sixRig.gripHeight*.56,0);
     }
     // Rendering-only cinematic state; gameplay finish and physics are untouched.
     g.departureView={age,grip,travel,hook:[hx,hy],mario:marioRig.group.position.toArray(),six:sixRig.group.position.toArray()};
   }else{escapeBar.visible=false;hookTether.visible=false;}
   if(sixRig.group.visible)sixRig.update(time,{beckon:p.x>5800&&(age<0||age<1.4),grip});
  }
  const endActive=!!(g.escape?.attached||g.finished||g.exitTransitionAge>0);if(ending){ending.group.visible=endActive||cx>49;ending.update(g,time,camera,baseCamera);}
  const activeX=endActive?Math.max(cx,59):cx;
  for(const c of chunks)c.group.visible=c.kind==='floor'||c.kind==='route'||Math.abs(c.center-activeX)<13.4;
  // Keep the shader's light count stable across the level; only vary radiance.
  fireFill.visible=true;fireFill.intensity=(Math.abs(cx-45)<12||endActive)?1.6:0;
  renderer.shadowMap.autoUpdate=false;if(time-lastShadowTime>(software?1/12:1/30)||time<lastShadowTime||lastShadowTime<0){renderer.shadowMap.needsUpdate=true;lastShadowTime=time;}
  const started=performance.now();renderer.render(scene,camera);lastGLMs=performance.now()-started;
 }
 return{renderer,canvas,scene,camera,update,baseCamera,setCopyMs(ms){lastCopyMs=ms;},dispose(){renderer.dispose();},getInfo(){const importedActors={mario:actorInfo(marioRig),chef:actorInfo(chefRig)};return{importedActors,sixGeometryMeshes:sixRig?sixRig.group.userData.six.meshCount:0,importedActorsReady:importedActors.mario.ready&&importedActors.chef.ready,type:'webgl-2.5d',revision:T.REVISION,glMs:lastGLMs,copyMs:lastCopyMs,directCanvas:true,captureMs:lastCopyMs,drawCalls:renderer.info.render.calls,triangles:renderer.info.render.triangles,geometries:renderer.info.memory.geometries,textures:renderer.info.memory.textures,resolution:renderer.domElement.width+'x'+renderer.domElement.height,softwareGPU:software,gpu,compactLighting:false,LNsurfaceSamples:['wood','metal','tile','cloth'].filter(k=>available('ln-'+(k==='cloth'?'fabric':k))).length};}};
}
globalThis.renderKitchen=function renderKitchen(ctx,g,view){
 if(!world&&globalThis.KitchenAssets?.loaded===false){ctx.fillStyle='#101917';ctx.fillRect(0,0,view.w,view.h);return;}
 if(!world&&!initError){try{world=buildWorld(view);globalThis.KitchenRenderer3D={getInfo:()=>world.getInfo(),getScene:()=>world.scene,getCamera:()=>world.camera,getRenderer:()=>world.renderer,captureFrame(type='image/png',quality=.92){
   const started=performance.now();world.renderer.render(world.scene,world.camera);
   if(!captureCanvas){captureCanvas=document.createElement('canvas');captureCanvas.width=1280;captureCanvas.height=720;captureContext=captureCanvas.getContext('2d');}const c=captureContext;c.clearRect(0,0,1280,720);c.drawImage(world.canvas,0,0,1280,720);const hud=document.getElementById('hud');if(hud)c.drawImage(hud,0,0,1280,720);
   const data=captureCanvas.toDataURL(type,quality);world.setCopyMs(performance.now()-started);return data;
  }};}catch(e){initError=e;globalThis.KitchenRenderer3D={getError:()=>String(e),getInfo:()=>({type:'failed',error:String(e)})};console.error('[Kitchen 3D renderer]',e);throw e;}}
 if(world){world.update(g,view);}
 else{ctx.fillStyle='#111b1a';ctx.fillRect(0,0,view.w,view.h);ctx.fillStyle='#e5d4a2';ctx.font='16px system-ui';ctx.textAlign='center';ctx.fillText('3D 场景尚未就绪，请使用支持 WebGL 的浏览器。',view.w/2,view.h/2);ctx.textAlign='left';}
};
})();
