'use strict';
(()=>{
const canvas=document.getElementById('game'),hud=document.createElement('canvas'),$=id=>document.getElementById(id),audio=new KitchenAudio(),key=new Set();
hud.id='hud';hud.width=1280;hud.height=720;hud.setAttribute('aria-hidden','true');Object.assign(hud.style,{position:'absolute',inset:'0',width:'100%',height:'100%',pointerEvents:'none',zIndex:'1'});canvas.insertAdjacentElement('afterend',hud);const ctx=hud.getContext('2d');
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v)),approach=(a,b,d)=>a+clamp(b-a,-d,d),overlap=(a,b)=>a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y;
let presses=new Set(),padOld={},paused=false,muted=false,last=0,acc=0,toastTime=0,hintText='',introTime=0;
let hudSignature=null,chapterSignature=null;
const config={version:'1.3.1-contact-actions',workshop:'1.10.34',width:6400,gravity:2400,runSpeed:315,walkSpeed:196,crawlSpeed:119};
const g={config,mode:'menu',time:0,phase:0,camX:0,camY:0,zoom:1,finished:false,chase:false,checkpoint:0,gateOpen:false,gateAmount:0,liftActivated:false,sounds:[],coins:[],bellCD:0,seenHints:new Set(),stats:{deaths:0,bells:0,hides:0,pushDistance:0,coins:0},playTime:0};
function platform(x,y,w,h,kind='wood'){return{x,y,w,h,kind,solid:true}}
function buildWorld(){
 g.plats=[platform(0,620,4450,160,'wood'),platform(4610,620,1210,160,'wood'),platform(285,585,100,35,'cloth'),platform(525,565,115,55,'metal'),platform(900,570,360,14,'wood'),platform(1540,570,260,14,'wood'),platform(3000,554,80,66,'wood'),platform(3450,570,240,14,'metal'),platform(3970,587,70,33,'cloth'),platform(4050,540,180,80,'wood'),platform(4970,560,120,60,'wood'),platform(5250,575,85,45,'metal'),platform(5335,530,235,22,'metal'),platform(5600,520,34,100,'metal'),platform(6120,515,210,28,'metal')];
 g.plats[7].id='pipe';g.plats[13].id='exitWall';g.plats[14].id='serviceLedge';
 g.hides=[{x:900,y:584,w:360,h:36},{x:1540,y:584,w:260,h:36},{x:3450,y:584,w:240,h:36}];
 g.coins=[{x:560,y:503,taken:false},{x:1190,y:604,taken:false},{x:5500,y:492,taken:false}];g.crate={x:1838,y:556,w:70,h:64};
 g.chef={x:1480,y:620,face:1,state:'patrol',alert:0,target:1480,rememberX:0,memory:0,timer:0,grabTimer:0,stepTimer:0,speed:0,pursuit:false,pursuitDelay:0,grace:0,attack:'none',attackAge:0,attackX:3520,ductPassed:false,wallReached:false};
 g.player={x:130,y:572,w:32,h:48,vx:0,vy:0,face:1,crouch:false,grounded:false,coyote:0,buffer:0,land:0,walkT:0,surface:'wood',jumpG:950,stun:0};
 g.pipeCrushed=false;g.pipeSlamAge=-1;g.lastHidden=false;g.chainStraining=false;
 g.escape={powered:false,attached:false,used:false,hookX:5670,hookY:430,progress:0,travelAge:0,speed:0,returning:false,delivered:false,catchCooldown:0,switchX:5545,wallX:5600};g.escapeAction='latched';g.exitTransitionAge=0;
}
function begin(){buildWorld();Object.assign(g,{mode:'play',time:0,playTime:0,phase:0,camX:0,finished:false,chase:false,checkpoint:0,gateOpen:false,gateAmount:0,liftActivated:false,sounds:[],bellCD:0,wonAt:0,shake:0});g.stats={deaths:0,bells:0,hides:0,pushDistance:0,coins:0,slamHits:0,hookGrabs:0};g.seenHints.clear();paused=false;key.clear();presses.clear();for(const id of ['intro','death','paused','ending'])$(id).hidden=true;audio.start();say('轻一点。这里的一切都太大了。',3);}
function say(s,t=2.3){g.toast=s;$('toast').textContent=s;toastTime=t;$('toast').style.opacity=1}
function setHint(s){g.hint=s;if(s!==hintText){hintText=s;$('hint').textContent=s;$('hint').style.opacity=s?1:0}}
function checkPoint(n){if(g.checkpoint<n){g.checkpoint=n;audio.fx('checkpoint');say('暖光记住了你的脚步 · 检查点',2.2)}}
function die(reason){if(g.mode!=='play')return;g.mode='dead';g.stats.deaths++;audio.fx('death');$('deathtext').textContent=reason;$('death').hidden=false;g.shake=4;key.clear();}
function retry(){const cp=g.checkpoint,stats={...g.stats},coins=g.coins.map(c=>c.taken);buildWorld();g.coins.forEach((c,i)=>c.taken=coins[i]);Object.assign(g,{mode:'play',chase:false,finished:false,sounds:[],gateOpen:false,gateAmount:0,liftActivated:false,bellCD:0,shake:0,phase:cp===0?0:cp===1?2:3});g.checkpoint=cp;g.stats=stats;if(cp===1){g.player.x=1410;g.chef.x=1920;g.chef.face=1;g.chef.target=2050;}if(cp===2){g.player.x=2320;g.chef.x=2130;g.chef.face=1;g.chef.grace=1.2;g.crate.x=2060;g.gateOpen=true;g.gateAmount=1;g.liftActivated=true;}g.player.y=572;g.camX=clamp(g.player.x-430,0,5120);paused=false;$('paused').hidden=true;$('death').hidden=true;$('ending').hidden=true;key.clear();presses.clear();say('再试一次。',1.5)}
function noise(x,y,kind='bell',power=1){g.sounds.push({x,y,age:0,power});audio.fx(kind);const c=g.chef;if(!g.chase&&Math.abs(c.x-x)<1450*power&&c.state!=='grab'){c.target=x;c.timer=.65;c.state='suspect';c.face=Math.sign(x-c.x)||c.face;c.alert=Math.max(c.alert,.2);}}
function hidden(){const p=g.player;return p.crouch&&g.hides.some(r=>p.x+p.w/2>r.x+8&&p.x+p.w/2<r.x+r.w-8&&p.y+p.h>r.y+6)}
function occluded(from,to){if(hidden())return true;const p=g.player,box=g.crate;const min=Math.min(from,to),max=Math.max(from,to);return box.x>min&&box.x+box.w<max&&p.y+p.h>box.y+12;}
function solids(){const s=[...g.plats,g.crate];if(!g.gateOpen)s.push(platform(2220,390,26,230,'metal'));return s}
function move(dt,input){const p=g.player,s=solids(),wasGround=p.grounded,axis=p.stun>0?0:input.x;p.stun=Math.max(0,p.stun-dt);p.coyote=wasGround?.1:Math.max(0,p.coyote-dt);p.buffer=Math.max(0,p.buffer-dt);if(input.jumpPress&&!p.stun)p.buffer=.12;
 const wantsPush=input.action&&p.grounded&&axis&&Math.abs((p.x+p.w/2)-(g.crate.x+35))<85&&p.y+p.h>g.crate.y+15;
 const nh=input.down&&!wantsPush?28:48;if(nh!==p.h){const candidate={...p,y:p.y+p.h-nh,h:nh};if(nh<p.h||!s.some(q=>overlap(candidate,q))){p.y=candidate.y;p.h=nh;}}p.crouch=p.h===28;p.pushing=false;
 const max=p.crouch?config.crawlSpeed:input.run?config.runSpeed:config.walkSpeed;
 if(!p.stun)p.vx=approach(p.vx,axis*max,(axis?Math.sign(p.vx)&&Math.sign(p.vx)!==axis?768:421:550)*dt);if(axis)p.face=axis;
 if(p.buffer&&p.coyote&&!p.crouch){const run=Math.abs(p.vx)>250;p.vy=run?-651:-521;p.jumpG=run?1181:945;p.grounded=false;p.coyote=0;p.buffer=0;audio.fx('jump');}
 p.vy=Math.min(670,p.vy+(p.vy<0&&input.jump?p.jumpG:config.gravity)*dt);p.land=Math.max(0,p.land-dt);
 const contact=axis>0?Math.abs(p.x+p.w-g.crate.x):Math.abs(p.x-g.crate.x-g.crate.w);
 const pushing=wantsPush&&!p.crouch&&contact<3;
 if(pushing){const next=g.crate.x+axis*112*dt;if(next>=1805&&next<=2100){p.pushing=true;g.crate.x=next;g.stats.pushDistance+=112*dt;p.vx=axis*112;if(g.time% .24<dt)audio.fx('push');if(g.crate.x>1834&&!g.chainStraining&&!g.liftActivated){g.chainStraining=true;noise(g.crate.x,590,'push',1.4);g.chef.pursuit=true;g.chef.pursuitDelay=.1;g.chef.grace=.9;say('木箱刮响了。快把它压到踏板上！',2);}}}
 p.x+=p.vx*dt;for(const q of s){if(overlap(p,q)){if(p.vx>0)p.x=q.x-p.w;else if(p.vx<0)p.x=q.x+q.w;p.vx=0;}}
 p.x=clamp(p.x,0,config.width-p.w);const bottom=p.y+p.h,top=p.y;p.y+=p.vy*dt;p.grounded=false;
 for(const q of s.sort((a,b)=>a.y-b.y)){if(p.x+p.w<=q.x+.01||p.x>=q.x+q.w-.01)continue;if(p.vy>=0&&bottom<=q.y+1.5&&p.y+p.h>=q.y){p.y=q.y-p.h;p.vy=0;p.grounded=true;p.surface=q.kind||'wood';break;}if(p.vy<0&&top>=q.y+q.h-.5&&p.y<q.y+q.h){p.y=q.y+q.h;p.vy=40;}}
 if(!wasGround&&p.grounded){p.land=.13;audio.fx(p.surface==='metal'?'landMetal':p.surface==='cloth'?'landCloth':'landWood');if(p.surface==='metal'&&!g.chase)noise(p.x,620,'landMetal',.7);}
 if(p.grounded&&Math.abs(p.vx)>60){p.walkT+=dt;if(p.walkT>(p.crouch?.42:.29)){p.walkT=0;if(!p.crouch)audio.fx('footstep');}}
 if(p.y>790)die(p.x>5800?'吊钩之外是深渊。启动墙链，起跳时按住 E 抓稳吊钩。':'餐具之间的缝隙很深。助跑，再按住跳跃跨过去。');
}
function underPipe(){const p=g.player;return p.crouch&&p.x+p.w/2>3458&&p.x+p.w/2<3682&&p.y+p.h>590;}
function handBlocked(){const p=g.player,c=g.chef;return underPipe()||(!g.gateOpen&&c.x<2220&&p.x>2250)||(c.x<=5600&&p.x+p.w/2>5634);}
function slamPipe(){
 const p=g.player,c=g.chef;g.pipeCrushed=true;g.pipeSlamAge=0;g.plats.find(q=>q.id==='pipe').y=576;g.shake=5;audio.fx('pipeSlam');
 if(p.x+p.w/2>3430&&p.x+p.w/2<3610&&p.y+p.h>550&&!underPipe()){
  p.vx=-170;p.vy=-280;p.grounded=false;p.stun=.28;g.stats.slamHits++;c.grace=.65;say('手掌落下前，钻进管道下面！',2);
 }
}
function chef(dt){
 const c=g.chef,p=g.player,dx=p.x+p.w/2-c.x,dist=Math.abs(dx),hid=hidden();c.memory=Math.max(0,c.memory-dt);c.grace=Math.max(0,c.grace-dt);
 if(c.state==='grab'){
  c.grabTimer+=dt;
  if(c.grabTimer>.85){if(dist<112&&!handBlocked()&&(!hid||c.memory>0))die(g.chase?'手掌抬起时仍有逃开的时间。跳箱、钻管，别停在他面前。':'厨师记住了你藏进去的位置。先诱走他的视线，再进桌底。');c.state=g.chase||c.pursuit?'chase':'search';c.timer=2.3;c.target=c.rememberX;c.grabTimer=0;c.grace=.3;}
  return;
 }
 if(['windup','impact','recover'].includes(c.attack)){
  c.attackAge+=dt;c.state=c.attack;c.speed=0;
  if(c.attack==='windup'&&c.attackAge>=.95){c.attack='impact';c.attackAge=0;slamPipe();}
  else if(c.attack==='impact'&&c.attackAge>=.15){c.attack='recover';c.attackAge=0;}
  else if(c.attack==='recover'&&c.attackAge>=.65){c.attack='none';c.attackAge=0;c.ductPassed=true;c.state='chase';c.grace=.3;}
  return;
 }
 const pursuing=g.chase||c.pursuit;
 if(pursuing){
  c.alert=1;c.rememberX=p.x;c.memory=2;c.face=Math.sign(dx)||1;
  if(c.pursuitDelay>0){c.pursuitDelay=Math.max(0,c.pursuitDelay-dt);c.state='suspect';c.speed=approach(c.speed,0,dt*700);}
  else if(c.x>=5600){c.x=5600;c.speed=0;c.wallReached=true;c.state='reach';c.attack='reach';c.attackAge+=dt;c.face=1;}
  else {
   c.state='chase';const speed=dx>500?390:dx>220?335:285;c.speed=approach(c.speed,speed,dt*650);
   let next=c.x+c.face*c.speed*dt;
   if(g.chase&&!c.ductPassed&&c.face>0&&next>=3320){next=3320;c.attack='windup';c.attackAge=0;c.attackX=3520;c.state='windup';c.speed=0;audio.fx('pipeWarning');say('他要压扁管道。蹲进去！',1.5);}
   c.x=clamp(next,0,5600);
  }
 }else{
  const visible=!hid&&!occluded(c.x,p.x)&&dist<500&&Math.sign(dx)===c.face&&p.x>780;
  if(visible){c.alert=Math.min(1,c.alert+dt*1.35);c.rememberX=p.x;c.memory=2.6;if(c.alert>=1)c.state='chase';else if(c.state!=='investigate')c.state='suspect';}
  else{c.alert=Math.max(0,c.alert-dt*.35);if(c.state==='chase'){c.state='search';c.target=c.rememberX;c.timer=2.4;}}
  if(c.state==='suspect'){c.timer-=dt;if(c.timer<=0)c.state=visible&&c.alert>.75?'chase':'investigate';}
  if(c.state==='patrol'){c.timer+=dt;if(Math.abs(c.target-c.x)<8){c.target=c.x<1750?2100:1460;c.timer=-1;}if(c.timer>=0){c.face=Math.sign(c.target-c.x)||c.face;c.x+=c.face*65*dt;}}
  if(c.state==='investigate'){const d=c.target-c.x;c.face=Math.sign(d)||c.face;if(Math.abs(d)>15)c.x+=Math.sign(d)*150*dt;else{c.state='search';c.timer=4.6;}}
  if(c.state==='search'){const d=c.target-c.x;if(Math.abs(d)>18){c.face=Math.sign(d);c.x+=c.face*165*dt;}else{c.timer-=dt;if(c.timer<0){c.state='patrol';c.target=c.x<1750?2100:1460;c.alert=0;}}}
  if(c.state==='chase'){c.face=Math.sign(dx)||c.face;c.x+=c.face*240*dt;}
 }
 const threatening=(pursuing||c.state==='chase'||c.memory>0)&&dist<108&&!handBlocked()&&c.grace===0&&c.attack==='none';
 if(threatening&&(!hid||c.memory>0)){c.state='grab';c.grabTimer=0;c.face=Math.sign(dx)||1;c.speed=0;audio.fx('grab');g.shake=2;}
 c.stepTimer+=dt;if(c.stepTimer>(c.state==='chase'?.32:.65)&&['patrol','investigate','chase','search'].includes(c.state)){c.stepTimer=0;if(Math.abs(c.x-p.x)<1100)audio.fx('chefStep',clamp(1-Math.abs(c.x-p.x)/1200,.05,1));}
}
function inputs(){let x=(key.has('ArrowRight')||key.has('KeyD')?1:0)-(key.has('ArrowLeft')||key.has('KeyA')?1:0),down=key.has('ArrowDown')||key.has('KeyS'),jump=key.has('Space')||key.has('KeyZ'),run=key.has('ShiftLeft')||key.has('ShiftRight'),action=key.has('KeyE')||key.has('KeyX'),jumpPress=presses.has('Space')||presses.has('KeyZ'),actPress=presses.has('KeyE')||presses.has('KeyX');
 for(const pad of navigator.getGamepads?.()||[]){if(!pad)continue;const ax=pad.axes[0]||0;x=Math.abs(ax)>.2?Math.sign(ax):x;down=down||pad.buttons[1]?.pressed||pad.buttons[13]?.pressed;jump=jump||pad.buttons[0]?.pressed;run=run||pad.buttons[7]?.pressed||pad.buttons[5]?.pressed;action=action||pad.buttons[2]?.pressed;jumpPress=jumpPress||(pad.buttons[0]?.pressed&&!padOld.jump);actPress=actPress||(pad.buttons[2]?.pressed&&!padOld.action);padOld={jump:pad.buttons[0]?.pressed,action:pad.buttons[2]?.pressed};break;}
 return{x,down,jump,run,action,jumpPress,actPress};}
function finish(){if(g.finished)return;g.finished=true;g.mode='won';g.phase=4;g.wonAt=g.time;g.escape.delivered=true;g.escape.returning=false;g.escape.speed=0;g.escapeAction='escaped';audio.fx('win');setHint('');say('出口的黄雨衣，一直在等你。',4);setTimeout(()=>{if(g.mode==='won'){$('ending').hidden=false;$('endstats').textContent=`${Math.floor(g.playTime/60)}:${String(Math.floor(g.playTime%60)).padStart(2,'0')}　·　${g.stats.coins}/3 金币`; }},16000);}
function escapeMovement(dt,input){
 const e=g.escape,p=g.player;e.catchCooldown=Math.max(0,e.catchCooldown-dt);if(e.attached){
  if(input.jumpPress){e.attached=false;e.returning=true;e.catchCooldown=.45;e.speed=0;g.escapeAction='released';p.vx=input.x*150;p.vy=-210;p.buffer=0;say('吊钩会返回。还在厨房里就能再抓一次。',2);return false;}
  e.speed=approach(e.speed,205,dt*320);e.hookX=Math.min(6190,e.hookX+e.speed*dt);e.progress=(e.hookX-5670)/520;e.travelAge+=dt;g.exitTransitionAge+=dt;
  p.x=e.hookX-p.w/2;p.y=e.hookY+12;p.h=48;p.crouch=false;p.grounded=false;p.coyote=0;p.vx=e.speed;p.vy=0;p.face=1;
  if(e.hookX>=6190){e.attached=false;e.delivered=true;e.speed=0;g.escapeAction='releasing';p.vx=0;p.vy=0;audio.fx('hookEnd');return false;}
  return true;
 }
 if(e.returning){e.speed=approach(e.speed,-180,dt*450);e.hookX=Math.max(5670,e.hookX+e.speed*dt);e.progress=(e.hookX-5670)/520;if(e.hookX<=5670){e.returning=false;e.speed=0;g.escapeAction='powered';}}
 if(e.delivered)g.exitTransitionAge+=dt;
 return false;
}
function interactions(dt,input){const p=g.player;g.bellCD=Math.max(0,g.bellCD-dt);if(input.actPress&&g.bellCD===0){for(const bx of [790,1600])if(Math.abs(p.x+16-bx)<93){noise(bx,590,'bell',1.4);g.bellCD=2;g.stats.bells++;say('他听见的是锅盖，不是你。',2);break;}}
 const open=g.crate.x+35>=2044&&g.crate.x+35<=2130;if(open&&!g.gateOpen){audio.fx('gate');say('闸链响了。他正沿着声音追来。',2.5);noise(2220,500,'gate',1.4);g.liftActivated=true;if(!g.chef.pursuit){g.chef.pursuit=true;g.chef.pursuitDelay=.75;g.chef.grace=.95;}}g.gateOpen=open;g.gateAmount=approach(g.gateAmount,open?1:0,dt*1.4);
 const h=hidden();if(h&&!g.lastHidden){g.stats.hides++;if(!g.chase&&g.chef.memory===0)say('桌布遮住了你。保持蹲伏。',2);}g.lastHidden=h;
 g.coins.forEach(c=>{if(!c.taken&&Math.hypot(c.x-(p.x+16),c.y-(p.y+p.h/2))<32){c.taken=true;g.stats.coins++;audio.fx('checkpoint');}});
 if(p.x>1390&&g.checkpoint<1)checkPoint(1);if(p.x>2290&&g.gateOpen&&g.checkpoint<2)checkPoint(2);
 if(p.x>2500&&!g.chase){g.chase=true;g.phase=3;g.chef.state='chase';g.chef.face=1;g.chef.ductPassed=false;g.chef.grace=Math.max(g.chef.grace,.8);audio.fx('alert');say('他找到你了。跑！',2.8);g.shake=3;}
 const e=g.escape;
 if(!e.powered&&input.actPress&&p.grounded&&Math.abs(p.x+p.w/2-e.switchX)<88&&Math.abs(p.y+p.h-530)<8){e.powered=true;g.escapeAction='powered';audio.fx('chainStart');say('输送链转起来了。起跳时按住 E 抓住吊钩。',3);}
 const hand={x:p.x+p.w/2,y:p.y+12};
 if(e.powered&&!e.attached&&!e.delivered&&e.catchCooldown===0&&input.action&&!p.grounded&&Math.hypot(hand.x-e.hookX,hand.y-e.hookY)<=70){e.attached=true;e.used=true;e.returning=false;e.speed=Math.max(0,e.speed);g.escapeAction='hanging';g.stats.hookGrabs++;p.buffer=0;p.coyote=0;audio.fx('hookCatch');say('抓稳。下面没有地板。',2);}
 if(e.used&&p.grounded&&p.x>6090&&p.x<6325&&Math.abs(p.y+p.h-515)<2)finish();
 if(!g.chase)g.phase=p.x<800?0:p.x<1390?1:2;
 let hint='';if(g.chase){if(e.attached)hint='抓稳吊钩　·　空格可松手';else if(p.x>5340&&p.x<5660&&!e.powered)hint='台面上的墙链：E 启动输送轨道';else if(p.x>5300&&e.powered&&!e.delivered)hint='从台边起跳，同时按住 E 抓钩';else if(p.x>2810&&p.x<3070)hint='按住跳跃，越过面包箱';else if(p.x>3290&&p.x<3650)hint='手要落下了：↓ 钻进管道底下';else if(p.x>4270&&p.x<4520)hint='助跑 + 按住跳跃，跨过灶缝';}
 else if(p.x<250)hint='← → 移动　·　Shift 跑　·　空格跳';else if(p.x<660)hint='按住跳得更高，松开落得更快';else if(Math.abs(p.x+16-790)<110)hint='E 敲响锅盖，把厨师引向这里';else if(p.x>850&&p.x<1300)hint='↓ 蹲着穿过桌底。桌布会遮住你';else if(p.x>1390&&p.x<1690)hint='E 敲响第二只锅盖，再绕到箱子旁边';else if(p.x>1690&&p.x<2160&&!open)hint='按住 E + → 推箱子，压住门前踏板';else if(p.x>2140&&!open)hint='踏板需要箱子的重量';else if(p.x>2160)hint='门开了，穿过去';setHint(hint);
}
function tick(dt){g.time+=dt;introTime+=dt;if(toastTime>0){toastTime-=dt;if(toastTime<=0)$('toast').style.opacity=0}g.toastRemaining=toastTime;if(g.pipeSlamAge>=0)g.pipeSlamAge+=dt;if(g.mode==='play'&&!paused){g.playTime+=dt;const input=inputs();if(!escapeMovement(dt,input))move(dt,input);if(g.mode==='play'){interactions(dt,input);chef(dt);}presses.clear();}else presses.clear();if(g.mode==='won')g.exitTransitionAge+=dt;g.sounds=g.sounds.filter(s=>(s.age+=dt)<2);g.shake=Math.max(0,(g.shake||0)-dt*12);const anchor=g.chase||g.chef.pursuit?520:430,target=clamp(g.player.x-anchor,0,5120);g.camX=approach(g.camX,target,dt*(Math.abs(target-g.camX)*5+20));audio.update(dt,{mode:paused?'menu':g.mode,chase:g.chase||g.chef.pursuit,threat:g.chef.alert,chefDistance:Math.abs(g.chef.x-g.player.x),time:g.time,escapeAction:g.escapeAction,pipe:{warning:g.chef.attack==='windup',warningProgress:clamp(g.chef.attackAge/.95,0,1),slammed:g.pipeCrushed}});}
function canvasUI(){}
function frame(t){let delta=last?Math.min((t-last)/1000,.05):.016;last=t;acc+=delta;while(acc>=1/120){tick(1/120);acc-=1/120;}const nextHUD=JSON.stringify([matchMedia('(pointer:coarse)').matches,g.mode,g.phase,hintText,toastTime>0?g.toast:'',!!globalThis.KitchenAssets?.loaded]),redrawHUD=nextHUD!==hudSignature;if(redrawHUD)ctx.clearRect(0,0,1280,720);renderKitchen(ctx,g,{w:1280,h:720,camX:g.camX,camY:0,zoom:1,time:g.time});if(redrawHUD){ctx.save();canvasUI();ctx.restore();hudSignature=nextHUD;}const nextChapter=g.mode+'|'+g.phase;if(nextChapter!==chapterSignature){$('chapter').textContent='';$('touch').hidden=g.mode==='won';chapterSignature=nextChapter;}requestAnimationFrame(frame);}
function pause(){if(!['play','won'].includes(g.mode))return;paused=!paused;$('paused').hidden=!paused;$('resume').hidden=g.mode==='won';key.clear();}
window.addEventListener('keydown',e=>{if(['Space','ArrowLeft','ArrowRight','ArrowDown','ArrowUp'].includes(e.code))e.preventDefault();if(!key.has(e.code))presses.add(e.code);key.add(e.code);if(e.code==='Escape')pause();if(e.code==='KeyR'&&!e.repeat&&g.mode!=='menu'&&g.mode!=='won')retry();if(e.code==='Enter'&&['menu','won'].includes(g.mode))begin();});window.addEventListener('keyup',e=>key.delete(e.code));window.addEventListener('blur',()=>{key.clear();if(g.mode==='play'&&!paused)pause()});
for(const b of document.querySelectorAll('[data-key]')){b.addEventListener('pointerdown',e=>{e.preventDefault();b.setPointerCapture(e.pointerId);const k=b.dataset.key;if(!key.has(k))presses.add(k);key.add(k);});const up=()=>key.delete(b.dataset.key);b.addEventListener('pointerup',up);b.addEventListener('pointercancel',up);b.addEventListener('lostpointercapture',up);}
$('start').onclick=begin;$('retry').onclick=retry;$('restart').onclick=begin;$('reset').onclick=begin;$('pause').onclick=pause;$('resume').onclick=pause;$('mute').onclick=()=>{muted=!muted;audio.setMuted(muted);$('mute').textContent=muted?'声音 关':'声音 开'};
buildWorld();window.game={getState:()=>JSON.parse(JSON.stringify({...g,seenHints:undefined,config,paused})),getAudioStream:()=>audio.stream,getAudioState:()=>audio.ctx?.state||'locked',getVideoFrame:(type,quality)=>KitchenRenderer3D.captureFrame(type,quality),version:config.version};requestAnimationFrame(frame);
})();
