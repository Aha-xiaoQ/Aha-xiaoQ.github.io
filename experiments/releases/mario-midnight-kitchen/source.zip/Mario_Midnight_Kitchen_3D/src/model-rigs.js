/* Mario mesh and animation integration. Asset use: free non-profit fan game.
   Source: HelloFangaming/HelloMarioFramework a0cb680379a83b11d7f67dc7ecc265364ad7b96f.
   Original character assets retain Nintendo rights; the upstream MIT is code only. */
(function(global){
'use strict';
const SOURCE='HelloFangaming/HelloMarioFramework';
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
function createMarioRig3D(T){
 const asset=global.KitchenAssets?.models?.mario;
 if(!asset?.scene||!asset.animations?.length)throw new Error('Mario GLB with original skeletal clips has not loaded');
 const group=new T.Group();group.name='MarioImportedRig';
 const pose=new T.Group();pose.name='MarioPhysicalPose';group.add(pose);
 const model=asset.scene;model.name='MarioSourceModel';pose.add(model);
 const bones={},meshes=[],skeletons=new Set(),oldMaterials=new Map();
 model.traverse(o=>{
  if(o.isBone)bones[o.name]=o;
  if(!o.isMesh)return;
  o.frustumCulled=false;o.castShadow=true;o.receiveShadow=true;meshes.push(o);
  if(o.isSkinnedMesh&&o.skeleton)skeletons.add(o.skeleton);
  const convert=m=>{
   if(oldMaterials.has(m))return oldMaterials.get(m);
   const nm=new T.MeshPhongMaterial({name:m.name,color:m.color.clone(),map:m.map,alphaMap:m.alphaMap,alphaTest:m.alphaTest,transparent:m.transparent,opacity:m.opacity,side:m.side,shininess:14,specular:new T.Color(.09,.08,.075)});
   oldMaterials.set(m,nm);return nm;
  };
  o.material=Array.isArray(o.material)?o.material.map(convert):convert(o.material);
 });
 const mixer=new T.AnimationMixer(model),actions={};
 for(const clip of asset.animations){const a=mixer.clipAction(clip);a.setLoop(T.LoopRepeat,Infinity);actions[clip.name]=a;}
 let current='Wait';actions.Wait.reset().play();mixer.update(0);
 const v=new T.Vector3(),box=new T.Box3(),local=new T.Matrix4(),q1=new T.Quaternion(),q2=new T.Quaternion(),axis=new T.Vector3(),p1=new T.Vector3(),p2=new T.Vector3(),p3=new T.Vector3(),temp=new T.Vector3();
 function matrices(){group.updateMatrixWorld(true);for(const s of skeletons)s.update();}
 function vertexPoint(mesh,i,out){out.fromBufferAttribute(mesh.geometry.attributes.position,i);if(mesh.isSkinnedMesh)mesh.boneTransform(i,out);out.applyMatrix4(mesh.matrixWorld).applyMatrix4(local);return out;}
 function actualBounds(){matrices();local.copy(group.matrixWorld).invert();box.makeEmpty();for(const m of meshes){const n=m.geometry.attributes.position.count;for(let i=0;i<n;i++)box.expandByPoint(vertexPoint(m,i,v));}return box.clone();}
 const standing=actualBounds();const standingHeight=standing.max.y-standing.min.y;
 if(!(standingHeight>.7&&standingHeight<2.5))throw new Error('Mario skin bind bounds failed: '+standingHeight);
 const scale=.48/standingHeight;model.scale.setScalar(scale);model.position.set(-(standing.min.x+standing.max.x)*.5*scale,-standing.min.y*scale,-(standing.min.z+standing.max.z)*.5*scale);
 // Sample the real shoe skin after each pose, keeping the lowest sole on the collision foot line.
 const soles=[];
 for(const mesh of meshes.filter(m=>m.name.includes('Shoes'))){const a=mesh.geometry.attributes.position,seen=new Set();for(let i=0;i<a.count;i++){const key=[a.getX(i),a.getY(i),a.getZ(i)].map(x=>Math.round(x*1e6)).join(',');if(!seen.has(key)){seen.add(key);soles.push([mesh,i]);}}}
 function soleHeight(){matrices();local.copy(group.matrixWorld).invert();let y=Infinity;for(const [mesh,i] of soles)y=Math.min(y,vertexPoint(mesh,i,v).y);return Number.isFinite(y)?y:0;}
 let yaw=Math.PI/2,lastGround=true,landAge=0,airAge=0,lastClip=current,crouchBlend=0,pushBlend=0,headingSet=false;
 const modelInfo={source:SOURCE,identity:'Mario / Super Mario 3D World asset',sourceCommit:'a0cb680379a83b11d7f67dc7ecc265364ad7b96f',clipNames:asset.animations.map(c=>c.name),clips:asset.animations.map(c=>({name:c.name,duration:c.duration,tracks:c.tracks.length})),authoredProceduralActions:['two-bone hook grip IK','shoe skin sole alignment','heading and landing blending'],standingHeight:.48,crouchingHeight:.28,importedStandingHeight:standingHeight,triangles:9304,meshCount:meshes.length,boneCount:Object.keys(bones).length,license:'free non-profit fan game assets; code MIT only'};
 group.userData={actorKind:'Mario',sourceModel:SOURCE,sourceAsset:'assets/models/mario.glb',standingHeight:.48,crouchingHeight:.28,modelInfo};
 function select(name,rate=1){if(!actions[name])name='Wait';if(current!==name){const old=actions[current],a=actions[name];if(name==='Crouch'){if(old)old.stop();a.reset().setEffectiveWeight(1).play();}else{a.reset().setEffectiveWeight(1).fadeIn(.10).play();if(old)old.fadeOut(.10);}current=name;}actions[current].timeScale=rate;lastClip=current;}
 function setWorldQuaternion(bone,wq){if(!bone)return;if(bone.parent)bone.parent.getWorldQuaternion(q2).invert();else q2.identity();bone.quaternion.copy(q2.multiply(wq));}
 function rotateJoint(bone,from,to){if(!bone||from.lengthSq()<1e-10||to.lengthSq()<1e-10)return;axis.copy(from).normalize();temp.copy(to).normalize();q1.setFromUnitVectors(axis,temp);bone.getWorldQuaternion(q2);q1.multiply(q2);setWorldQuaternion(bone,q1);group.updateMatrixWorld(true);}
 function hookIK(side,target){
  const upper=bones['Arm'+side+'1'],lower=bones['Arm'+side+'2'],hand=bones['Hand'+side];if(!upper||!lower||!hand)return;
  upper.getWorldPosition(p1);lower.getWorldPosition(p2);hand.getWorldPosition(p3);
  const l1=p1.distanceTo(p2),l2=p2.distanceTo(p3),d=clamp(p1.distanceTo(target),Math.abs(l1-l2)+.001,l1+l2-.002);
  const dir=target.clone().sub(p1).normalize(),pole=new T.Vector3(0,0,side==='L'?.07:-.07).add(new T.Vector3(.065,0,0));
  pole.add(p1).sub(p1).addScaledVector(dir,-pole.dot(dir)).normalize();
  const a=(l1*l1-l2*l2+d*d)/(2*d),h=Math.sqrt(Math.max(0,l1*l1-a*a));const elbow=p1.clone().addScaledVector(dir,a).addScaledVector(pole,h);
  rotateJoint(upper,p2.clone().sub(p1),elbow.clone().sub(p1));lower.getWorldPosition(p2);hand.getWorldPosition(p3);rotateJoint(lower,p3.clone().sub(p2),target.clone().sub(p2));
 }
 function update(p={},g={},time=0,dt=1/60){
  dt=clamp(Number.isFinite(dt)?dt:1/60,0,.06);
  const speed=Math.abs(p.vx||0),crouch=!!p.crouch||p.h===28,hanging=!!g.escape?.attached,pushing=!!p.pushing,air=p.grounded===false&&!hanging;
  if(!headingSet){yaw=(p.face||1)>0?Math.PI/2:-Math.PI/2;headingSet=true;}
  const targetYaw=(p.face||1)>0?Math.PI/2:-Math.PI/2;let delta=targetYaw-yaw;while(delta>Math.PI)delta-=Math.PI*2;while(delta<-Math.PI)delta+=Math.PI*2;yaw+=delta*(1-Math.exp(-dt*18));group.rotation.y=yaw;
  if(air)airAge+=dt;else airAge=0;if(p.grounded&&!lastGround)landAge=.11;landAge=Math.max(0,landAge-dt);lastGround=p.grounded;
  if(hanging)select('Air',.18);
  else if(pushing)select('Push',clamp(speed/100,.7,1.4));
  else if(crouch)select('Crouch',speed>15?.8:.25);
  else if(air)select((p.vy||0)<-70&&airAge<.34?'Jump':'Air',.8);
  else if(landAge>0&&speed<70)select('Land',1.25);
  else if(speed>185)select('Run',clamp(speed/280,.72,1.3));
  else if(speed>15)select('Walk',clamp(speed/130,.45,1.6));
  else select('Wait',1);
  mixer.update(dt);pushBlend+=(Number(pushing)-pushBlend)*(1-Math.exp(-dt*24));pose.position.set(0,0,.07*pushBlend);pose.scale.set(1,1,1);
  // Native crouch is a folded skeleton. The small envelope correction matches the 28px tunnel clearance.
  crouchBlend+=(Number(crouch)-crouchBlend)*(1-Math.exp(-dt*28));
  // The source crouch folds limbs to approximately .28m without flattening the head or torso.
  if(hanging){
   pose.position.y=.16;matrices();const hook=g.escape;
   for(const side of ['L','R'])hookIK(side,new T.Vector3(hook.hookX*.01,(620-hook.hookY)*.01-.025,side==='L'?.023:-.023));
  }else{pose.position.y-=soleHeight();
   if(pushing&&g.crate){
    const face=(p.face||1)>0?g.crate.x*.01:(g.crate.x+g.crate.w)*.01;
    matrices();for(const side of ['L','R'])hookIK(side,new T.Vector3(face-(p.face||1)*.016,group.position.y+.26,side==='L'?-.065:.065));
   }
  }
  matrices();group.userData.animation=current;group.userData.hookIK=hanging;
 }
 update({face:1,grounded:true,vx:0,h:48},{},0,0);
 return {group,update,sourceModel:SOURCE,modelInfo,bones,mixer,actions,getInfo(){return{...modelInfo,animation:current,hookIK:group.userData.hookIK,soleHeight:soleHeight()};}};
}
global.createMarioRig3D=createMarioRig3D;
})(globalThis);

/* Night Kitchen: standalone actual textured, skinned Chef model adapter. */
(function (global) {
  'use strict';
  const PI = Math.PI, TAU = PI * 2;
  const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
  const lerp = (a, b, t) => a + (b - a) * t;
  const ease = v => { v = clamp(v, 0, 1); return v * v * (3 - 2 * v); };
  const damp = (a, b, dt, rate) => lerp(a, b, 1 - Math.exp(-dt * rate));
  const finite = (v, fallback = 0) => Number.isFinite(v) ? v : fallback;

  function createChefRig3D(T) {
    const asset = global.KitchenAssets && global.KitchenAssets.models && global.KitchenAssets.models.chef;
    if (!asset || !asset.scene) throw new Error('Chef GLB must finish parsing before creating the world');
    const group = new T.Group(), yaw = new T.Group(), normalization = new T.Group();
    group.name = 'Twin Chef: original textured skinned model';
    yaw.name = 'Chef heading'; normalization.name = 'Chef display normalization';
    group.add(yaw); yaw.add(normalization); normalization.add(asset.scene);
    const bones = {}, meshes = [], materials = new Map();
    asset.scene.traverse(o => {
      if (o.isBone) bones[o.name.replace(/[^a-zA-Z0-9]/g, '').replace(/^mixamorig/, '')] = o;
      if (!o.isMesh) return;
      meshes.push(o); o.castShadow = true; o.receiveShadow = true; o.frustumCulled = false;
      const convert = source => {
        if (materials.has(source)) return materials.get(source);
        // glTFLoader has already assigned linear colors and sRGB diffuse maps.
        // Do not gamma-convert those colors a second time.
        const m = new T.MeshPhongMaterial({
          color: source.color ? source.color.clone() : 0xffffff,
          map: source.map || null, normalMap: source.normalMap || null,
          normalScale: source.normalScale ? source.normalScale.clone() : new T.Vector2(1, 1),
          aoMap: source.aoMap || null, aoMapIntensity: source.aoMapIntensity == null ? 1 : source.aoMapIntensity,
          emissive: source.emissive ? source.emissive.clone() : 0x000000,
          emissiveMap: source.emissiveMap || null, emissiveIntensity: source.emissiveIntensity == null ? 1 : source.emissiveIntensity,
          specular: 0x11100d, shininess: 3, side: source.side,
          transparent: !!source.transparent, opacity: source.opacity == null ? 1 : source.opacity,
          alphaTest: source.alphaTest || 0, depthWrite: source.depthWrite !== false
        });
        m.name = 'Chef original diffuse / low-cost lit skin'; materials.set(source, m); return m;
      };
      o.material = Array.isArray(o.material) ? o.material.map(convert) : convert(o.material);
    });
    for (const name of ['Hips', 'Spine', 'Spine1', 'Spine2', 'Head', 'LeftArm', 'LeftForeArm', 'LeftHand', 'RightArm', 'RightForeArm', 'RightHand', 'LeftUpLeg', 'LeftLeg', 'LeftFoot', 'RightUpLeg', 'RightLeg', 'RightFoot']) {
      if (!bones[name]) throw new Error('Chef skeleton is missing ' + name);
    }
    const mixer = new T.AnimationMixer(asset.scene), clip = asset.animations && asset.animations[0];
    if (clip) mixer.clipAction(clip).play();
    mixer.setTime(0); group.updateMatrixWorld(true);
    for (const mesh of meshes) if (mesh.isSkinnedMesh) mesh.skeleton.update();
    const v = new T.Vector3(), q = new T.Quaternion(), q2 = new T.Quaternion();
    const bounds = new T.Box3();
    function vertexWorld(mesh, i, target) {
      target.fromBufferAttribute(mesh.geometry.attributes.position, i);
      if (mesh.isSkinnedMesh) mesh.boneTransform(i, target);
      return target.applyMatrix4(mesh.matrixWorld);
    }
    for (const mesh of meshes) for (let i = 0; i < mesh.geometry.attributes.position.count; i++) bounds.expandByPoint(vertexWorld(mesh, i, v));
    const height = bounds.max.y - bounds.min.y, scale = 3.9 / height;
    const leftFoot = bones.LeftFoot.getWorldPosition(new T.Vector3());
    const rightFoot = bones.RightFoot.getWorldPosition(new T.Vector3());
    const footMid = leftFoot.clone().add(rightFoot).multiplyScalar(.5);
    normalization.scale.setScalar(scale);
    normalization.position.set(-footMid.x * scale, -bounds.min.y * scale, -footMid.z * scale);
    group.updateMatrixWorld(true);

    const sourcePose = new Map();
    for (const bone of Object.values(bones)) sourcePose.set(bone, {
      position: bone.position.clone(), quaternion: bone.quaternion.clone(), scale: bone.scale.clone()
    });
    const hipsOrigin = bones.Hips.position.clone();
    const controls = {
      leftArm: [bones.LeftArm, bones.LeftForeArm, bones.LeftHand],
      rightArm: [bones.RightArm, bones.RightForeArm, bones.RightHand],
      leftReach: [bones.LeftShoulder, bones.LeftArm, bones.LeftForeArm, bones.LeftHand],
      rightReach: [bones.RightShoulder, bones.RightArm, bones.RightForeArm, bones.RightHand],
      leftLeg: [bones.LeftUpLeg, bones.LeftLeg, bones.LeftFoot],
      rightLeg: [bones.RightUpLeg, bones.RightLeg, bones.RightFoot]
    };
    const baseline = {};
    for (const name of ['LeftFoot', 'RightFoot', 'LeftHand', 'RightHand']) {
      baseline[name] = {
        position: yaw.worldToLocal(bones[name].getWorldPosition(new T.Vector3())),
        quaternion: bones[name].getWorldQuaternion(new T.Quaternion())
      };
    }
    // Samples are chosen from actual lower mesh vertices, not a loose bounding box.
    const floorCandidates = [];
    for (const mesh of meshes) {
      if (!mesh.isSkinnedMesh) continue;
      mesh.skeleton.update();
      for (let i = 0; i < mesh.geometry.attributes.position.count; i++) {
        vertexWorld(mesh, i, v);
        if (v.y < 2.0) floorCandidates.push({mesh, i});
      }
    }
    const floorSamples = [];
    const step = Math.max(1, Math.floor(floorCandidates.length / 3200));
    for (let i = 0; i < floorCandidates.length; i += step) floorSamples.push(floorCandidates[i]);

    const up = new T.Vector3(0, 1, 0), right = new T.Vector3(1, 0, 0), front = new T.Vector3(0, 0, 1);
    const tempA = new T.Vector3(), tempB = new T.Vector3(), tempC = new T.Vector3();
    const parentQ = new T.Quaternion(), oldQ = new T.Quaternion(), deltaQ = new T.Quaternion();
    function setWorldQuaternion(bone, requested, weight = 1) {
      bone.parent.getWorldQuaternion(parentQ).invert();
      q.copy(parentQ).multiply(requested);
      if (weight < 1) bone.quaternion.slerp(q, clamp(weight, 0, 1)); else bone.quaternion.copy(q);
      bone.updateWorldMatrix(false, true);
    }
    function rotateBoneWorld(bone, axis, angle) {
      if (!bone || !angle) return;
      bone.getWorldQuaternion(oldQ); deltaQ.setFromAxisAngle(axis, angle);
      setWorldQuaternion(bone, deltaQ.multiply(oldQ));
    }
    function aimBone(bone, child, target) {
      bone.getWorldPosition(tempA); child.getWorldPosition(tempB);
      tempB.sub(tempA).normalize(); tempC.copy(target).sub(tempA).normalize();
      bone.getWorldQuaternion(oldQ); deltaQ.setFromUnitVectors(tempB, tempC);
      setWorldQuaternion(bone, deltaQ.multiply(oldQ));
    }
    function solveLimb(chain, target, hint, weight = 1) {
      const [upper, lower, end] = chain;
      const a = upper.getWorldPosition(new T.Vector3()), b = lower.getWorldPosition(new T.Vector3()), c = end.getWorldPosition(new T.Vector3());
      const l1 = a.distanceTo(b), l2 = b.distanceTo(c);
      const destination = c.clone().lerp(target, clamp(weight, 0, 1));
      const direction = destination.clone().sub(a), distance = clamp(direction.length(), Math.abs(l1 - l2) + .002, l1 + l2 - .002);
      direction.normalize();
      const along = (l1 * l1 + distance * distance - l2 * l2) / (2 * distance);
      const bend = hint.clone().addScaledVector(direction, -hint.dot(direction));
      if (bend.lengthSq() < .00001) bend.set(0, 0, 1).addScaledVector(direction, -direction.z);
      bend.normalize();
      const elbow = a.clone().addScaledVector(direction, along).addScaledVector(bend, Math.sqrt(Math.max(0, l1 * l1 - along * along)));
      const reachable = a.clone().addScaledVector(direction, distance);
      aimBone(upper, lower, elbow); aimBone(lower, end, reachable);
      return reachable;
    }
    function solveArm(chain, target, hint, weight = 1) {
      const end = chain[3];
      const requested = end.getWorldPosition(new T.Vector3()).lerp(target, clamp(weight, 0, 1));
      // Seed a natural elbow plane, then use the original clavicle as the third
      // joint. The Chef's short arm cannot honestly span the pipe without it.
      solveLimb(chain.slice(1), requested, hint, 1);
      for (let iteration = 0; iteration < 10; iteration++) {
        for (let joint = 2; joint >= 0; joint--) {
          const bone = chain[joint];
          bone.getWorldPosition(tempA); end.getWorldPosition(tempB);
          tempB.sub(tempA).normalize(); tempC.copy(requested).sub(tempA).normalize();
          deltaQ.setFromUnitVectors(tempB, tempC);
          const turn = 2 * Math.acos(clamp(Math.abs(deltaQ.w), 0, 1));
          if (turn > .38) deltaQ.slerp(new T.Quaternion(), 1 - .38 / turn);
          bone.getWorldQuaternion(oldQ);
          setWorldQuaternion(bone, deltaQ.multiply(oldQ));
        }
        if (end.getWorldPosition(tempA).distanceToSquared(requested) < .000025) break;
      }
      return end.getWorldPosition(new T.Vector3());
    }
    function localTarget(x, y, z) { return yaw.localToWorld(new T.Vector3(x, y, z)); }
    function modelDirection(x, y, z) { return new T.Vector3(x, y, z).applyQuaternion(yaw.getWorldQuaternion(q2)).normalize(); }
    function translateBoneWorld(bone, amount) {
      const p = bone.getWorldPosition(new T.Vector3()).add(amount);
      bone.position.copy(bone.parent.worldToLocal(p)); bone.updateWorldMatrix(false, true);
    }
    function orientHand(hand, direction, palmNormal, weight) {
      const y = direction.clone().normalize(), z = palmNormal.clone().addScaledVector(y, -palmNormal.dot(y)).normalize();
      const x = y.clone().cross(z).normalize(); z.crossVectors(x, y).normalize();
      const matrix = new T.Matrix4().makeBasis(x, y, z);
      setWorldQuaternion(hand, new T.Quaternion().setFromRotationMatrix(matrix), weight);
    }
    function footPlacement(phase, moving, stride) {
      const contact = .64, half = stride * contact * .5;
      if (phase < contact) return {forward: (half - stride * phase) * moving, lift: 0};
      const a = (phase - contact) / (1 - contact);
      return {forward: lerp(-half, half, ease(a)) * moving, lift: Math.sin(PI * a) * .105 * moving};
    }
    const memory = {x: null, phase: 0, moving: 0, bend: 0, pelvis: 0, arm: 0, active: '', correction: 0};
    const info = {
      identity: 'Little Nightmares Chef01 textured skinned model',
      source: 'zombow/LittleNightMare_Copy@219a7f285ab7b91f2f12530f57b168e8cb81bd74',
      originalModel: true, skinned: true, displayHeight: 3.9, sourceHeight: height,
      clip: clip ? clip.name : null, authoredProceduralActions: ['walk', 'run', 'inspect', 'grab', 'pipe-windup', 'pipe-impact', 'pipe-recover', 'wall-reach'],
      material: 'Phong preserving original diffuse UV texture', boneCount: Object.keys(bones).length,
      meshCount: meshes.length,
      runtimeVertexCount: meshes.reduce((n, mesh) => n + mesh.geometry.attributes.position.count, 0),
      triangleCount: meshes.reduce((n, mesh) => n + (mesh.geometry.index ? mesh.geometry.index.count : mesh.geometry.attributes.position.count) / 3, 0)
    };
    group.userData.actorKind = 'Chef'; group.userData.sourceModel = info.identity;
    group.userData.modelRig = info; group.userData.standingHeight = 3.9;
    yaw.rotation.y = PI / 2 - .27;

    function update(c = {}, g = {}, time = 0, dt = 1 / 60) {
      dt = clamp(finite(dt, 1 / 60), .001, .08); time = finite(time);
      const face = c.face < 0 ? -1 : 1;
      const desiredYaw = face > 0 ? PI / 2 - .27 : -PI / 2 + .27;
      let angle = desiredYaw - yaw.rotation.y;
      while (angle > PI) angle -= TAU; while (angle < -PI) angle += TAU;
      yaw.rotation.y += angle * (1 - Math.exp(-dt * 18));
      normalization.position.y = -bounds.min.y * scale;
      // SetTime replaces every animated transform before any authored correction.
      for (const [bone, pose] of sourcePose) {
        bone.position.copy(pose.position); bone.quaternion.copy(pose.quaternion); bone.scale.copy(pose.scale);
      }
      if (clip) mixer.setTime(time % clip.duration);
      // The downloaded breathing clip is in place; physical root belongs to renderer.
      bones.Hips.position.x = hipsOrigin.x; bones.Hips.position.z = hipsOrigin.z;
      group.updateMatrixWorld(true);
      const dx = memory.x == null ? 0 : (finite(c.x) - memory.x) * .01; memory.x = finite(c.x);
      const distance = Math.abs(dx) < 1 ? Math.abs(dx) : 0;
      const movingTarget = distance > .00002 && c.state !== 'grab' && c.state !== 'reach' && !['windup', 'impact', 'recover'].includes(c.attack) ? 1 : 0;
      memory.moving = damp(memory.moving, movingTarget, dt, 10);
      const running = c.state === 'chase' || c.pursuit, stride = running ? .88 : .66;
      if (distance > .000001) memory.phase = (memory.phase + distance / stride) % 1;
      const attack = c.attack || 'none', age = Math.max(0, finite(c.attackAge));
      const grab = c.state === 'grab', wall = attack === 'reach' || c.state === 'reach';
      const inspecting = c.state === 'search' || c.state === 'investigate';
      let bend = inspecting ? .16 : running ? .045 : 0, pelvis = 0, arm = 0;
      if (attack === 'windup') { const a = ease(age / .60); bend = lerp(.12, 1.60, ease((age - .60) / .27)); arm = a; pelvis = .20 * ease((age - .60) / .27); }
      else if (attack === 'impact') { bend = 1.64; pelvis = .20; arm = 1; }
      else if (attack === 'recover') { const a = ease(age / .65); bend = lerp(1.64, .08, a); pelvis = .20 * (1 - a); arm = 1 - a; }
      else if (grab) { arm = ease(finite(c.grabTimer) / .40); bend = 1.49 * arm; pelvis = .20 * arm; }
      else if (wall) { arm = ease(age / .45); bend = .55 * arm; pelvis = .06 * arm; }
      memory.bend = damp(memory.bend, bend, dt, attack === 'impact' ? 40 : 14);
      memory.pelvis = damp(memory.pelvis, pelvis, dt, 14);
      memory.arm = damp(memory.arm, arm, dt, attack === 'impact' ? 40 : 18);
      if (memory.pelvis) translateBoneWorld(bones.Hips, new T.Vector3(face * memory.pelvis * 1.40, -memory.pelvis, 0));
      const axis = modelDirection(1, 0, 0);
      // Distribute flexion through real spine joints. Feet/pelvis remain separate.
      rotateBoneWorld(bones.Spine, axis, memory.bend * .48);
      rotateBoneWorld(bones.Spine1, axis, memory.bend * .34);
      rotateBoneWorld(bones.Spine2, axis, memory.bend * .18);
      rotateBoneWorld(bones.Head, axis, -memory.bend * .24 + (inspecting ? .09 : 0));

      // Stance feet cancel root travel; only the swing foot rises. Original shoe mesh
      // and its bone orientation remain intact instead of scaling legs or the model.
      for (const [side, chain, name] of [[0, controls.leftLeg, 'LeftFoot'], [1, controls.rightLeg, 'RightFoot']]) {
        const phase = (memory.phase + side * .5) % 1, stepPose = footPlacement(phase, memory.moving, stride);
        const base = baseline[name].position;
        const target = localTarget(base.x, base.y + stepPose.lift, base.z + stepPose.forward);
        solveLimb(chain, target, modelDirection(0, .1, 1));
        const rotation = yaw.getWorldQuaternion(new T.Quaternion()).multiply(baseline[name].quaternion);
        setWorldQuaternion(chain[2], rotation);
      }
      if (memory.moving > .01 && memory.arm < .05) {
        for (const [side, chain, name] of [[1, controls.leftArm, 'LeftHand'], [-1, controls.rightArm, 'RightHand']]) {
          const b = baseline[name].position, swing = Math.sin(memory.phase * TAU) * .18 * side * memory.moving;
          solveLimb(chain, localTarget(b.x, b.y + Math.abs(swing) * .08, b.z + swing), modelDirection(side, -.12, -.45), .85);
        }
      }

      let handTarget = null, fingerDirection = null, palmNormal = null;
      const nearArm = face > 0 ? controls.rightArm : controls.leftArm;
      const farArm = face > 0 ? controls.leftArm : controls.rightArm;
      const nearReach = face > 0 ? controls.rightReach : controls.leftReach;
      const farReach = face > 0 ? controls.leftReach : controls.rightReach;
      if (['windup', 'impact', 'recover'].includes(attack)) {
        const root = group.getWorldPosition(new T.Vector3());
        const strike = new T.Vector3(finite(c.attackX, 3520) * .01 - face * .22, .56, .04);
        const raised = new T.Vector3(root.x + face * .63, 2.97, root.z + .73);
        if (attack === 'windup') {
          const rise = ease(age / .52), descend = ease((age - .70) / .23);
          const idleHand = nearArm[2].getWorldPosition(new T.Vector3());
          handTarget = idleHand.lerp(raised, rise).lerp(strike, descend);
        } else if (attack === 'impact') handTarget = strike;
        else handTarget = strike.clone().lerp(raised, ease(age / .52));
        fingerDirection = new T.Vector3(face, -.68, 0).normalize(); palmNormal = new T.Vector3(0, -1, 0);
        solveArm(farReach, new T.Vector3(root.x + face * .65, 1.32, root.z - .23), new T.Vector3(-face, .1, -.6), memory.arm * .80);
      } else if (grab) {
        const p = g.p || g.player || {}, root = group.getWorldPosition(new T.Vector3());
        handTarget = new T.Vector3(finite(p.x, finite(c.x) + face * 85) * .01 + finite(p.w, 32) * .005, Math.max(.34, (620 - finite(p.y, 540) - finite(p.h, 48) * .50) * .01), .045);
        // Keep the capture gesture in the fair, forward telegraph range.
        handTarget.x = clamp(handTarget.x, root.x - 1.75, root.x + 1.75);
        fingerDirection = new T.Vector3(face, -.30, 0).normalize(); palmNormal = new T.Vector3(0, -1, .1);
      } else if (wall) {
        const root = group.getWorldPosition(new T.Vector3());
        handTarget = new T.Vector3(root.x + face * 1.39, 1.78 + Math.sin(time * 3) * .035, .08);
        fingerDirection = new T.Vector3(face, .22, 0).normalize(); palmNormal = new T.Vector3(0, -.2, 1);
        solveArm(farReach, new T.Vector3(root.x + face * .63, 1.3, root.z - .18), new T.Vector3(-face, .1, -.5), memory.arm * .60);
      } else if (inspecting) {
        const b = baseline[face > 0 ? 'RightHand' : 'LeftHand'].position;
        handTarget = localTarget(b.x * .72, .79, .90);
        fingerDirection = modelDirection(0, -.9, .4); palmNormal = modelDirection(0, 0, 1);
      }
      if (handTarget) {
        const weight = inspecting ? .55 : Math.max(memory.arm, attack === 'impact' ? 1 : 0);
        const reached = solveArm(nearReach, handTarget, new T.Vector3(-face * .28, .14, .85), weight);
        orientHand(nearArm[2], fingerDirection, palmNormal, weight);
        group.userData.handTarget = handTarget.toArray(); group.userData.handReached = reached.toArray();
      } else { group.userData.handTarget = null; group.userData.handReached = null; }
      group.updateMatrixWorld(true);
      for (const mesh of meshes) if (mesh.isSkinnedMesh) mesh.skeleton.update();
      // Small correction guards real shoe/apron vertices against the kitchen floor.
      let floor = Infinity;
      for (const sample of floorSamples) floor = Math.min(floor, vertexWorld(sample.mesh, sample.i, v).y);
      const groundY = group.getWorldPosition(tempA).y;
      if (Number.isFinite(floor) && floor < groundY) {
        const lift = Math.min(.16, groundY - floor + .009);
        normalization.position.y += lift;
        group.updateMatrixWorld(true);
        for (const mesh of meshes) if (mesh.isSkinnedMesh) mesh.skeleton.update();
        group.userData.floorCorrection = lift;
      } else group.userData.floorCorrection = 0;
      if (handTarget) group.userData.handReached = nearArm[2].getWorldPosition(new T.Vector3()).toArray();
      group.userData.action = wall ? 'wall-reach' : grab ? 'grab' : attack !== 'none' ? 'pipe-' + attack : inspecting ? 'inspect' : memory.moving > .20 ? running ? 'run' : 'walk' : 'breathing-idle';
    }
    update({x: 1480, face: 1, state: 'idle'}, {}, 0, 1 / 60);
    return {group, update, sourceModel: info.identity, modelInfo: info, bones, mixer};
  }
  global.createChefModelRig3D = createChefRig3D;
  global.createChefRig3D = createChefRig3D;
})(globalThis);
