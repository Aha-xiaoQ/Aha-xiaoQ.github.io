/* Authored industrial escape space, based on LN kitchen/service-space references.
 * This is a continuous part of the level, not a screenshot or an original map rip. */
(()=>{
  'use strict';
  globalThis.createKitchenEnding3D=function(T,scene){
    const root=new T.Group();root.name='continuous-service-exit';scene.add(root);
    const steel=new T.MeshPhongMaterial({color:0x24332f,shininess:9,specular:0x37483f});
    const trim=new T.MeshPhongMaterial({color:0x394c46,shininess:19,specular:0x56615a});
    const dark=new T.MeshLambertMaterial({color:0x101b1d});
    const rust=new T.MeshLambertMaterial({color:0x4d3b2b});
    const black=new T.MeshLambertMaterial({color:0x071113});
    const bulb=new T.MeshLambertMaterial({color:0xc2a16b,emissive:0xbb7130,emissiveIntensity:.7});
    const fixed=new T.Group();root.add(fixed);
    const boxGeometry=new T.BoxGeometry(1,1,1),cylinderGeometry=new T.CylinderGeometry(1,1,1,10);
    function box(x,y,z,w,h,d,m){const a=new T.Mesh(boxGeometry,m);a.position.set(x,y,z);a.scale.set(w,h,d);a.castShadow=true;a.receiveShadow=true;fixed.add(a);return a;}
    function cylinder(x,y,z,r,h,m,axis){const a=new T.Mesh(cylinderGeometry,m);a.position.set(x,y,z);a.scale.set(r,h,r);if(axis==='x')a.rotation.z=Math.PI/2;if(axis==='z')a.rotation.x=Math.PI/2;a.castShadow=true;a.receiveShadow=true;fixed.add(a);return a;}
    // A deep wall reveals the industrial scale rather than a bright dining backdrop.
    box(63.7,4.6,-3.3,8.4,12.6,.46,steel);
    for(let i=0;i<7;i++){
      box(59.7+i*1.12,4.6,-3.02,.09,12.5,.12,trim);
      for(let j=0;j<9;j++)cylinder(59.7+i*1.12,-.7+j*1.23,-2.94,.044,.05,rust,'z');
    }
    for(let j=0;j<5;j++)box(63.7,.9+j*2.2,-2.99,8.4,.13,.12,dark);
    // The kitchen wall continues around a tight maintenance opening.
    box(59.55,4.97,-.54,.48,5.14,3.6,dark);
    box(59.55,.42,-.54,.48,.84,3.6,dark);
    for(const z of [-1.9,.86])box(59.55,1.62,z,.5,1.56,.85,dark);
    box(59.58,2.4,1.69,.18,.18,.12,trim);
    // Fixed brackets below the actual landing ledge (game.plats owns its surface).
    for(const x of [61.4,62.2,63.1]){
      box(x,.72,-.07,.13,.17,1.6,trim);
      const brace=box(x,.16,-.3,.1,1.25,.13,steel);brace.rotation.x=-.52;
    }
    // One broken rail lets the player remain visible on the tiny service ledge.
    for(const x of [61.22,63.15])cylinder(x,1.25,-.45,.026,.75,trim);
    cylinder(62.2,1.57,-.45,.027,1.97,trim,'x');
    // A very large extraction duct and cable bundles recede into unlit space.
    cylinder(66.25,3.1,-2.57,.63,6.1,dark);
    const ductRingGeometry=new T.TorusGeometry(.648,.029,5,24);
    for(let j=0;j<7;j++){const r=new T.Mesh(ductRingGeometry,trim);r.rotation.x=Math.PI/2;r.position.set(66.25,.5+j*.86,-2.57);fixed.add(r);}
    for(let k=0;k<4;k++)cylinder(60.3+k*.085,4.8,-2.72,.018,7.1,black);
    // Guarded maintenance bulb: light falls on steel, never on a victory card.
    cylinder(61.53,2.5,-2.72,.16,.15,dark);cylinder(61.53,2.39,-2.72,.077,.15,bulb);
    for(let k=0;k<5;k++){const a=k*Math.PI*2/5;cylinder(61.53+Math.cos(a)*.11,2.39,-2.72+Math.sin(a)*.11,.012,.22,trim);}
    // Keep these bounded lights in the scene even while far architecture is hidden.
    // Toggling a parent light count used to compile new shader variants mid-run.
    const warm=new T.PointLight(0xce914e,.38,6,2);warm.position.set(61.5,2.35,-1.8);scene.add(warm);
    const cold=new T.PointLight(0x526c78,.38,16,2);cold.position.set(62.5,-1.8,2);scene.add(cold);
    // The darkness below has real depth and low glints; no scenic window or stars.
    const sea=new T.Mesh(new T.PlaneGeometry(35,24,6,4),new T.MeshPhongMaterial({color:0x101f25,shininess:34,specular:0x263c43}));
    sea.rotation.x=-Math.PI/2;sea.position.set(64,-5.4,-1);sea.receiveShadow=true;fixed.add(sea);
    const waves=[],waveMatrix=new T.Matrix4(),wavePosition=new T.Vector3(),waveScale=new T.Vector3(),waveRotation=new T.Quaternion();
    const waveMesh=new T.InstancedMesh(new T.BoxGeometry(1,.015,.08),new T.MeshBasicMaterial({color:0x263c43,transparent:true,opacity:.2,depthWrite:false}),15);root.add(waveMesh);
    for(let i=0;i<15;i++){
      waves.push({x:58+i*.73,z:-5+(i%4)*2.3,width:1.1+(i%5)*.25});
    }
    // The conveyor continues physically over the narrow service opening.
    cylinder(64.7,2.22,-.02,.035,10.75,trim,'x');
    // The conveyor passes through a dark bulkhead; both riders disappear behind its edge.
    box(69.25,2.9,.5,2.4,7.0,.8,dark);
    box(67.98,2.9,.52,.15,7.0,.95,steel);
    for(const x of [60.15,61.65,63.1]){box(x,2.37,-.34,.06,.29,.54,steel);cylinder(x,2.7,-.42,.025,.6,dark);}
    // Batch architectural detail by material so the distant wall and its rivets
    // cost a handful of draws, while preserving real normals and cast shadows.
    fixed.updateMatrixWorld(true);
    const buckets=new Map(),point=new T.Vector3(),normal=new T.Vector3();
    fixed.traverse(mesh=>{
      if(!mesh.isMesh)return;
      let bucket=buckets.get(mesh.material.id);
      if(!bucket){bucket={material:mesh.material,positions:[],normals:[],uvs:[],shadow:false};buckets.set(mesh.material.id,bucket);}
      const geometry=mesh.geometry,p=geometry.attributes.position,n=geometry.attributes.normal,uv=geometry.attributes.uv,indices=geometry.index;
      const normalMatrix=new T.Matrix3().getNormalMatrix(mesh.matrixWorld),count=indices?indices.count:p.count;
      for(let j=0;j<count;j++){
        const k=indices?indices.getX(j):j;
        point.fromBufferAttribute(p,k).applyMatrix4(mesh.matrixWorld);normal.fromBufferAttribute(n,k).applyMatrix3(normalMatrix).normalize();
        bucket.positions.push(point.x,point.y,point.z);bucket.normals.push(normal.x,normal.y,normal.z);bucket.uvs.push(uv?uv.getX(k):0,uv?uv.getY(k):0);
      }
      bucket.shadow=bucket.shadow||mesh.castShadow;
    });
    fixed.clear();
    for(const bucket of buckets.values()){
      const geometry=new T.BufferGeometry();geometry.setAttribute('position',new T.Float32BufferAttribute(bucket.positions,3));geometry.setAttribute('normal',new T.Float32BufferAttribute(bucket.normals,3));geometry.setAttribute('uv',new T.Float32BufferAttribute(bucket.uvs,2));geometry.computeBoundingSphere();
      const mesh=new T.Mesh(geometry,bucket.material);mesh.castShadow=bucket.shadow;mesh.receiveShadow=true;fixed.add(mesh);
    }
    let lastAge=0;
    const originalTarget=new T.Vector3(),target=new T.Vector3(),position=new T.Vector3();
    return {group:root,update(g,t,camera,baseCamera){
      for(let i=0;i<waves.length;i++){
        const wave=waves[i];wavePosition.set(wave.x,-5.35+Math.sin(t*.61+i*.77)*.042,wave.z);waveScale.set(wave.width*(1+Math.sin(t*.32+i)*.17),1,1);waveMatrix.compose(wavePosition,waveRotation,waveScale);waveMesh.setMatrixAt(i,waveMatrix);
      }
      waveMesh.instanceMatrix.needsUpdate=true;
      const active=!!(g.escape?.attached||g.escapeAction==='releasing'||g.escapeAction==='escaped'||g.finished);
      if(!active){lastAge=0;return false;}
      const age=Math.max(0,Number(g.exitTransitionAge)||t-(g.wonAt||t));lastAge=age;
      const u=T.MathUtils.smoothstep(age,0,4.9);
      // Start from the real gameplay camera and widen continuously around Mario.
      originalTarget.copy(baseCamera.target);
      const px=(g.player.x+g.player.w*.5)*.01;
      const py=(620-g.player.y-g.player.h)*.01;
      target.set(T.MathUtils.lerp(originalTarget.x,px+1.35,u),T.MathUtils.lerp(originalTarget.y,1.18,u),T.MathUtils.lerp(originalTarget.z,-.6,u));
      position.copy(baseCamera.position);position.x=T.MathUtils.lerp(position.x,px+1.25,u);position.y=T.MathUtils.lerp(position.y,2.75,u);position.z=T.MathUtils.lerp(position.z,17.2,u);
      if(g.finished){
        // Stay in the original industrial service space; move closer so the meeting reads.
        const meetingAge=Math.max(0,t-g.wonAt),near=T.MathUtils.smoothstep(meetingAge,0,1.1),ride=T.MathUtils.smoothstep(meetingAge,2.6,11.6);
        const closeTarget=new T.Vector3(62.18+ride*3.7,1.36,-.05),closePosition=new T.Vector3(62.2+ride*3.3,2.15,5.8+ride*2.0);
        target.lerp(closeTarget,near);position.lerp(closePosition,near);
      }
      camera.position.copy(position);camera.lookAt(target);
      cold.intensity=.38+u*.2;warm.intensity=.38+Math.sin(t*2.7)*.012;
      return true;
    }};
  };
})();
