# 配套声音文件

本目录是本关离线构建实际读取的Mario音效，原文件字节保持不变。它们来自已有项目的Nintendo游戏音频资料，声音权利不因代码许可而转移。原上游来源标识及MIT软件许可适用范围见 ../../CLASSIC_ART_NOTICE.txt；MIT不授予这些游戏声音的新增使用或分发权。

检查点WAV的原素材来源、格式转换与权利说明见 CHECKPOINT_AUDIO_NOTICE.txt。
三首CC BY-SA 3.0替代配乐、作者、来源和文件SHA见 ../voxel-music/manifest.json 与 MUSIC_CREDITS.md。
本包保留原音频，不包括新的剪辑、改速、变调或追加配乐。
