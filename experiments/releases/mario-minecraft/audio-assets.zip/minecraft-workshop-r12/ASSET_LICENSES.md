# 素材与许可

本包提供关卡源码和构建资料，不为角色、美术、录音、旋律或商标新增授权。
代码适用范围见 LICENSE-CODE.md；其中的MIT正文只适用于其原本涵盖的已有软件。

- Mario及共享运行时中的Nintendo游戏图像/音效：见 atlas/CLASSIC_ART_NOTICE.txt、RECOVERED_ASSET_NOTICE.txt、BOWSER_JR_ART_NOTICE.txt 和模块内来源记录。
- Minecraft风格环境、人物与效果为程序绘制的同人改编，没有将Minecraft原版纹理作为该场景图像打包；见 atlas/MINECRAFT_ART_NOTICE.txt。名称、角色及商标权利仍属各自权利人。
- 游戏字体：寒蝉点阵体。原字体作者、来源及完整许可见 atlas/CHILL_FONT_LICENSE.txt。
- 三首替代配乐：Dark Reaven Music 的 Magic of the Forest、Deep Mining、Traitor，来自 VoxeLibre，CC BY-SA 3.0；并非Minecraft原声。完整署名、来源和混音说明见 ../minecraft-project-r12/MUSIC_CREDITS.md。
- 红石音符盒引用 Koji Kondo / Nintendo《Super Mario Bros.》主题开头，使用本地合成而非原声录音；不对该第三方旋律声明原创或开放许可。
- 检查点原声音频及PCM封装说明见 atlas/assets/classic-audio/CHECKPOINT_AUDIO_NOTICE.txt。

第三方素材的公开分发和商业用途仍需自行核对适用权利；本包不是清权证明。
