# 自制马里奥第4关：方块奇遇 R12

这份源码可重建马里奥与Minecraft风格方块世界的2D同人关卡。它不是Minecraft Java/Bedrock移植版，战斗数值、金币交易和护盾规则属于跨界改编。

## 运行与构建

1. 将源码包和音乐音效包解压到同一个目录，合并 minecraft-workshop-r12 文件夹。
2. 安装 Node.js 22 或更新版本。
3. 在 minecraft-workshop-r12 目录运行 `npm run build`，或 `node scripts/build-minecraft-adventure.mjs`。无需 npm install，也无需联网构建。
4. 双击打开 minecraft-project-r12/blast-trail.html，即可离线试玩。构建同时写出 blast-trail.qmap.json。

源码包已有构建所需模块、角色数据、关卡构建脚本和场景预览图；音频包提供单独存放的声音文件。编辑 scripts/build-minecraft-adventure.mjs 后重新构建可调整关卡。该精简包提供本关源码与离线构建，不包含完整地图工坊编辑器或视频录制输入带。

## 操作

方向键/WASD移动，空格跳跃，Shift加速，↓蹲伏；E/↑进门或打开商店，Esc暂停。
L/鼠标右键举盾；获得三叉戟后K/鼠标左键投掷；H使用药水。商店先选择商品，再确认购买。

## 署名和权利

制图：dots。工具：马里奥地图工坊。游戏字体为寒蝉点阵体。三首替代配乐由Dark Reaven Music创作，源自VoxeLibre，适用CC BY-SA 3.0；不是Minecraft原声。
完整音乐署名见 minecraft-project-r12/MUSIC_CREDITS.md；代码与第三方素材的不同权利范围见 minecraft-workshop-r12/LICENSE-CODE.md 和 ASSET_LICENSES.md。本同人项目与Nintendo、Mojang或Microsoft无关联。
