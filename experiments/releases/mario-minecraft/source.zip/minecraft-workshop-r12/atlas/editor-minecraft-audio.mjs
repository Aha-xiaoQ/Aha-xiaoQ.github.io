/** Locally synthesized effects and Trailward music; no game recordings or
 * external audio assets. The separate, explicitly triggered redstone score
 * quotes a credited Mario passage. Browser and video synthesize the same PCM. */
export const MINECRAFT_AUDIO_VERSION = 3;
export const MINECRAFT_AUDIO_THEME = 'mc-ambience';
export const MINECRAFT_MUSIC_CROSSFADE = .65;
/** A literal ten-note hook: D A F E D | G A C A D. The descending F-E-D
 * answer to the opening fifth and the 3+3+2 percussion give it an identity.
 * B answers the same rhythm higher; A returns at the end of every arrangement. */
export const MINECRAFT_MUSIC_MOTIF=Object.freeze({
 title:'Trailward',pitches:Object.freeze([62,69,65,64,62,67,69,72,69,74]),
 beats:Object.freeze([0,.5,1.5,2,3,4,4.5,5.5,6,7]),
 lengths:Object.freeze([.38,.78,.38,.78,.82,.38,.78,.38,.78,.92]),
 answer:Object.freeze([65,72,69,67,65,64,67,69,72,74]),
 form:Object.freeze(['A','A','B','A']),rhythm:'short-long-short-long-long; 3+3+2 bass/drum accents'
});
export const MINECRAFT_MUSIC_THEMES = Object.freeze({
 'mc-ambience':Object.freeze({title:'Trailward: Woodland',bpm:96,beats:32,duration:20,mood:'exploration',key:'D minor / Dorian colour',lead:'woody mallet and recorder'}),
 'mc-nether-music':Object.freeze({title:'Trailward: Emberforge',bpm:120,beats:32,duration:16,mood:'nether',key:'D minor',lead:'hammered metal and low reed'}),
 'mc-boss-music':Object.freeze({title:'Trailward: Last Stand',bpm:144,beats:32,duration:40/3,mood:'boss',key:'D minor',lead:'octave horn and reed'})
});
export const MINECRAFT_LICENSED_MUSIC=Object.freeze({
 forest:Object.freeze({title:'Magic of the Forest',file:'DarkReaven-magic_of_the_forest.ogg',duration:170.171896}),
 mining:Object.freeze({title:'Deep Mining',file:'DarkReaven-deep_mining.ogg',duration:105.796583}),
 traitor:Object.freeze({title:'Traitor',file:'DarkReaven-traitor.ogg',duration:60.877563})
});
export const MINECRAFT_LICENSED_MUSIC_CREDIT='Magic of the Forest, Deep Mining and Traitor by Dark Reaven Music (https://soundcloud.com/dark-reaven-music), from VoxeLibre commit 4492ce6ff8d856daa4567abe2ea689f4e7a39842 (https://github.com/VoxeLibre/VoxeLibre/blob/4492ce6ff8d856daa4567abe2ea689f4e7a39842/CREDITS.md#music). CC BY-SA 3.0: https://creativecommons.org/licenses/by-sa/3.0/. OGG recordings unchanged; playback volume, fades and ducking are applied at runtime. Alternative soundtrack, not Minecraft original music.';
export const minecraftLicensedMusicId=key=>key==='mc-mining-music'?'mining':key==='mc-nether-music'||key==='mc-boss-music'?'traitor':'forest';
export const isMinecraftMusic=key=>Object.hasOwn(MINECRAFT_MUSIC_THEMES,key)||key==='mc-mining-music';
export function minecraftMusicTheme(biome='forest',{musicMode='synth'}={}){
 const name=String(biome).replace(/^Minecraft[-\s]*/i,'').toLowerCase();
 return /nether/.test(name)?'mc-nether-music':/^(end|boss|dragon)(\b|-)/.test(name)?'mc-boss-music':musicMode==='licensed'&&/cave|mine|stronghold|burrow/.test(name)?'mc-mining-music':MINECRAFT_AUDIO_THEME;
}
const midiFrequency=note=>440*2**((note-69)/12);
/** A/A/B/A, not random note generation. Melody, rhythm and the return phrase
 * stay literal between biomes; harmony, register, articulation and band change. */
export function minecraftMusicScore(key=MINECRAFT_AUDIO_THEME){
 const theme=MINECRAFT_MUSIC_THEMES[key];if(!theme)return null;const notes=[];
 const put=(pitch,beat,length,instrument,gain,role='accompaniment',section='')=>notes.push({pitch,beat,length,instrument,gain,role,section});
 const exploration=key===MINECRAFT_AUDIO_THEME,nether=key==='mc-nether-music',transpose=exploration||nether?0:12;
 const chords=exploration?[[50,57,62,65],[55,62,67,69],[50,57,62,65],[48,55,60,64],[53,60,65,69],[55,62,67,70],[46,53,58,62],[45,52,57,62]]:
  nether?[[38,45,50,53],[36,43,48,52],[38,45,50,53],[34,41,46,50],[34,41,46,50],[36,43,48,52],[38,45,50,53],[33,40,45,50]]:
  [[38,45,50,53],[34,41,46,50],[38,45,50,53],[36,43,48,52],[41,48,53,57],[34,41,46,50],[43,50,55,58],[33,40,45,50]];
 for(let bar=0;bar<8;bar++){
  const chord=chords[bar],b=bar*4;
  for(const pitch of chord.slice(1))put(pitch,b,4.35,'pad',exploration?.012:nether?.013:.014);
  // The recurring 3+3+2 eighth-note grouping underlines the melodic hook.
  for(const [n,off]of [0,1.5,3].entries()){
   put(chord[0]+(n===1?7:n===2?12:0),b+off,n===2?.7:1.1,'bass',exploration?.058:nether?.071:.074,'rhythm');
   put(exploration?45:nether?38:33,b+off,exploration?.42:.62,'drum',exploration?.026:nether?.068:.082,'rhythm');
  }
  // Two voiced chord responses per bar leave space around the front-and-centre
  // tune; this is a fixed rhythmic accompaniment, not an arpeggio generator.
  for(const off of [.75,2.5])for(const [voice,pitch]of chord.slice(1).entries())put(pitch+12,b+off+voice*.025,.44,'pluck',exploration?.014:nether?.019:.018,'chord');
  for(const off of [.5,1.5,2.5,3.5])put(0,b+off,.16,'hat',exploration?.008:nether?.011:.015,'rhythm');
  if(!exploration)for(const off of [1,3])put(0,b+off,.25,'snare',nether?.022:.037,'rhythm');
 }
 for(let phrase=0;phrase<4;phrase++){
  const section=MINECRAFT_MUSIC_MOTIF.form[phrase],pitches=section==='B'?MINECRAFT_MUSIC_MOTIF.answer:MINECRAFT_MUSIC_MOTIF.pitches;
  for(let n=0;n<pitches.length;n++){
   const pitch=pitches[n]+transpose,beat=phrase*8+MINECRAFT_MUSIC_MOTIF.beats[n],length=MINECRAFT_MUSIC_MOTIF.lengths[n];
   put(pitch,beat,length,exploration?'felt':nether?'bell':'lead',exploration?.115:nether?.112:.100,'melody',section);
   put(pitch+(nether?-12:0),beat+.015,length*.94,exploration?'recorder':'reed',exploration?.036:nether?.035:.037,'melody-colour',section);
   if(phrase===3)put(pitch+(exploration?12:-12),beat+.012,length*.82,exploration?'bell':'recorder',exploration?.015:.021,'return-harmony',section);
  }
 }
 return{...theme,motif:MINECRAFT_MUSIC_MOTIF.title,form:[...MINECRAFT_MUSIC_MOTIF.form],transpose,notes};
}
function synthesizeMinecraftMusic(key,{sampleRate=48000,intensity=1}={}){
 const score=minecraftMusicScore(key),length=Math.ceil(score.duration*sampleRate),pcm=new Float32Array(length),beat=60/score.bpm;
 for(const [index,note]of score.notes.entries()){
  const start=Math.round(note.beat*beat*sampleRate),duration=note.length*beat,count=Math.ceil(duration*sampleRate),frequency=midiFrequency(note.pitch),random=rng(hash(key+':note:'+index));let low=0;
  const echo=note.role==='melody',tap1=Math.round(.115*sampleRate),tap2=Math.round(.235*sampleRate);
  for(let i=0;i<count;i++){
   const t=i/sampleRate,p=TAU*frequency*t,noise=random();low+=.2*(noise-low);let voice=0,envelope=1;
   if(note.instrument==='pad'){envelope=fade(t,duration,.24,.45);voice=Math.sin(p)*.65+Math.sin(p*1.0013)*.2+Math.sin(p*2)*.11+Math.sin(p*3)*.04;}
   else if(note.instrument==='bass'){envelope=fade(t,duration,.009,.09)*Math.exp(-t*2.2);voice=Math.sin(p)*.8+Math.sin(p*2)*.16+Math.sin(p*3)*.04;}
   else if(note.instrument==='felt'){envelope=fade(t,duration,.005,.07)*Math.exp(-t*1.8);voice=Math.sin(p+.65*Math.exp(-t*21)*Math.sin(p*2))+.2*Math.sin(p*2)+.08*Math.sin(p*3);}
   else if(note.instrument==='bell'){envelope=fade(t,duration,.004,.075)*Math.exp(-t*2.1);voice=Math.sin(p)*.9+.23*Math.sin(p*2.002)+.1*Math.sin(p*3.998)*Math.exp(-t*5);}
   else if(note.instrument==='pluck'){envelope=fade(t,duration,.004,.045)*Math.exp(-t*9);voice=Math.sin(p)+.24*Math.sin(p*2)+.1*Math.sin(p*3);}
   else if(note.instrument==='recorder'){envelope=fade(t,duration,.025,.075)*(.88+.12*Math.exp(-t*4));const q=p+.018*Math.sin(TAU*5.4*t);voice=Math.sin(q)+.12*Math.sin(q*2)+.06*Math.sin(q*3)+low*.025;}
   else if(note.instrument==='reed'){envelope=fade(t,duration,.017,.07)*(.82+.18*Math.exp(-t*7));const q=p+.014*Math.sin(TAU*5.2*t);voice=Math.sin(q)*.85+.3*Math.sin(q*2)+.17*Math.sin(q*3)+.06*Math.sin(q*5);}
   else if(note.instrument==='lead'){envelope=fade(t,duration,.009,.065)*(.85+.15*Math.exp(-t*8));voice=Math.sin(p)*.78+Math.sin(p*1.0015)*.16+.28*Math.sin(p*2)+.13*Math.sin(p*3)+.04*Math.sin(p*4);}
   else if(note.instrument==='drum'){envelope=fade(t,duration,.003,.025)*Math.exp(-t*15);voice=Math.sin(TAU*(frequency*t+1.8*(1-Math.exp(-t*32))))*.86+low*.14;}
   else{envelope=fade(t,duration,.002,.02)*Math.exp(-t*(note.instrument==='hat'?45:24));voice=(noise-low)*(note.instrument==='hat'?.65:.8)+low*.25;}
   const sample=voice*envelope*note.gain*intensity;pcm[(start+i)%length]+=sample;
   if(echo){pcm[(start+i+tap1)%length]+=sample*.10;pcm[(start+i+tap2)%length]+=sample*.055;}
  }
 }
 return{pcm,sampleRate,duration:length/sampleRate,score:{title:score.title,motif:score.motif,form:score.form,bpm:score.bpm,bars:8,notes:score.notes.length}};
}
export function minecraftNoteOptions(options={}){
 const baseBlock=String(options.baseBlock??'dirt').toLowerCase().replace(/^minecraft:/,'').replaceAll('-','_');
 let instrument=options.instrument;
 if(!instrument){
  if(/gold/.test(baseBlock))instrument='bell';else if(/iron/.test(baseBlock))instrument='iron_xylophone';
  else if(/bone/.test(baseBlock))instrument='xylophone';else if(/packed_ice/.test(baseBlock))instrument='chime';
  else if(/soul_sand/.test(baseBlock))instrument='cow_bell';else if(/sand|gravel|concrete_powder/.test(baseBlock))instrument='snare';
  else if(/glass/.test(baseBlock))instrument='hat';else if(/wool/.test(baseBlock))instrument='guitar';
  else if(/clay/.test(baseBlock))instrument='flute';else if(/pumpkin/.test(baseBlock))instrument='didgeridoo';
  else if(/emerald/.test(baseBlock))instrument='bit';else if(/hay/.test(baseBlock))instrument='banjo';
  else if(/glowstone/.test(baseBlock))instrument='pling';else if(/wood|plank|log|stem|bamboo/.test(baseBlock))instrument='bass';
  else if(/stone|ore|brick|obsidian|netherrack|deepslate|blackstone/.test(baseBlock))instrument='basedrum';else instrument='harp';
 }
 const note=Math.round(clamp(finite(options.note,0),0,24)),octave={bass:-12,guitar:-12,flute:12,bell:12,chime:12,xylophone:12}[instrument]||0;
 return{baseBlock,instrument,note,frequency:midiFrequency(54+note+octave)};
}
/** A complete sixteen-bar miniature: recognizable pickup, contrasting continuation,
 * rising development, dominant preparation and a resolved tonic with release.
 * Locally synthesized arrangement, never an original Nintendo recording. */
export const MINECRAFT_REDSTONE_TUNE=(()=>{
 const bpm=144,secondsPerBeat=60/bpm,bars=16,beatsPerBar=2,duration=bars*beatsPerBar*secondsPerBeat+.45,events=[];
 const melody=[
  [[0,64,.2],[.25,64,.2],[.75,64,.2],[1.25,60,.2],[1.5,64,.3]],
  [[0,67,.65],[1,55,.65]],
  [[0,60,.35],[.75,55,.35],[1.5,64,.35]],
  [[0,69,.3],[.5,71,.3],[1,70,.2],[1.25,69,.4]],
  [[0,67,.3],[.5,64,.3],[1,67,.3],[1.5,69,.3]],
  [[0,65,.3],[.5,67,.3],[1,64,.3],[1.5,60,.3]],
  [[0,62,.3],[.5,59,.3],[1.25,67,.5]],
  [[0,64,.3],[.5,60,.3],[1,62,.3],[1.5,59,.4]],
  [[0,60,.3],[.5,64,.3],[1,67,.3],[1.5,72,.4]],
  [[0,74,.3],[.5,72,.2],[.75,71,.2],[1.25,69,.45]],
  [[0,65,.3],[.5,69,.3],[1,72,.3],[1.5,76,.4]],
  [[0,74,.3],[.5,71,.3],[1,67,.65]],
  [[0,69,.2],[.25,71,.2],[.75,72,.3],[1.25,76,.4]],
  [[0,77,.3],[.5,74,.3],[1,71,.3],[1.5,67,.4]],
  [[0,64,.3],[.5,62,.3],[1,59,.3],[1.5,67,.3]],
  [[0,72,1.85]]
 ];
 const sections=['opening','opening','continuation','continuation','continuation','continuation','continuation','continuation','development','development','development','development','climax','dominant','cadence','resolution'];
 function put(bar,offset,pitch,length,baseBlock,instrument,role,volume){
  const beat=bar*beatsPerBar+offset,octave=instrument==='bell'?12:0;
  events.push(Object.freeze({event:'mc-note',time:beat*secondsPerBeat,frame:Math.round(beat*secondsPerBeat*60),beat,bar,step:offset*4,pitch,note:pitch-54-octave,baseBlock,instrument,role,beatLength:length,duration:Math.max(.08,length*secondsPerBeat),volume,section:sections[bar]}));
 }
 for(let bar=0;bar<bars;bar++){
  for(const [offset,pitch,length]of melody[bar])put(bar,offset,pitch,length,'dirt','harp','melody',1.15);
  if(bar>=2&&bar<15){put(bar,0,60,.20,'stone','basedrum','kick',.42);if(bar<14)put(bar,1,60,.14,'sand','snare','snare',.22);}
 }
 put(1,0,79,.50,'gold_block','bell','accent',.18);
 put(15,0,72,1.85,'gold_block','bell','cadence',.25);
 events.sort((a,b)=>a.time-b.time||(a.role==='melody'?-1:1));
 return Object.freeze({id:'mario-redstone-complete-r12',title:'Redstone Adventure · Complete Passage',bpm,bars,meter:'2/4',beatsPerBar,duration,loop:false,form:Object.freeze(sections),credits:'Opening and continuation reference Koji Kondo / Nintendo; development and cadence are a new local note-block arrangement. no original recording. Underlying composition rights remain with their owners.',events:Object.freeze(events)});
})();
/** Times are absolute seconds; frame is rounded once at the requested FPS.
 * Controllers should schedule these events on simulation time, not timers.
 * Recalling this function returns fresh events safe for per-run pan/seed data. */
export function minecraftRedstoneSequence({startTime=0,fps=60}={}){
 const start=Math.max(0,finite(startTime,0)),rate=Math.max(1,finite(fps,60));
 return{...MINECRAFT_REDSTONE_TUNE,startTime:start,endTime:start+MINECRAFT_REDSTONE_TUNE.duration,events:MINECRAFT_REDSTONE_TUNE.events.map(event=>({...event,time:start+event.time,frame:Math.round((start+event.time)*rate)}))};
}
/** Convert ordinary captured room changes to the same themes chosen in HTML. */
export function minecraftMusicIntervals(changes=[],{fps=60,endFrame=0,musicMode='synth'}={}){
 const intervals=[];
 for(const change of [...changes].sort((a,b)=>(a.frame??0)-(b.frame??0))){
  const frame=Math.max(0,finite(change.frame,0)),key=isMinecraftMusic(change.key)?change.key:minecraftMusicTheme(change.biome??change.minecraft?.biome,{musicMode:change.minecraft?.musicMode??musicMode});
  if(intervals.at(-1)?.key===key)continue;
  if(intervals.length)intervals.at(-1).endFrame=frame;
  intervals.push({key,startFrame:frame,endFrame});
 }
 return intervals;
}
export const MINECRAFT_SOUND_DURATIONS = Object.freeze({
 'mc-enderman-warning':.38,'mc-enderman-stare':1.15,'mc-enderman-aggro':.48,'mc-enderman-attack':.3,
 'mc-shield-raise':.18,'mc-shield-block':.36,'mc-shield-parry':.56,'mc-shield-break':.72,'mc-shield-ready':.4,'mc-channeling-thunder':1.65,'mc-trident-enchant':1.1,
 'mc-fuse':1.5,'mc-explosion':1.35,'mc-sand':.46,'mc-sand-settle':.24,
 'mc-sword-swing':.22,'mc-bow-release':.28,'mc-gear-pickup':.55,'mc-trident-throw':.4,'mc-trident-return':.45,'mc-trident-catch':.25,'mc-footstep':.14,'mc-portal':1.1,'mc-portal-ambience':1.8,
 'mc-ambience':20,'mc-mining-music':20,'mc-nether-music':16,'mc-boss-music':40/3,'mc-note':.85,'mc-furnace-ignite':.5,'mc-furnace-smelt':.65,'mc-furnace-done':.7,'mc-jump':.2,'mc-hurt':.3,'mc-pickup':.32,
 'mc-cow':.85,'mc-sheep':.65,'mc-llama':.6,'mc-flag':.85,'mc-complete':2.1,'mc-ui':.07,
 'mc-apple-drop':.32,'mc-apple-pickup':.46,'mc-pig':.45,'mc-pig-scared':.54,
 'mc-secret':1.25,'mc-cart-start':.45,'mc-cart-stop':.36,'mc-cart-rattle':.29,
 'mc-ore':.42,'mc-mine-lights':1.15,'mc-enderman-lift':.5,'mc-enderman-teleport':.65,'mc-villager':.5,'mc-villager-greet':.62,'mc-villager-success':.68,'mc-villager-disagree':.82,'mc-golem-uppercut':.68,'mc-golem-rose':.82,'mc-ghast-charge':.8,'mc-ghast-fire':.4,'mc-fireball-return':.35,'mc-ghast-hit':.8,'mc-magma-jump':.3,'mc-magma-stomp':.35,'mc-bastion-break':.8,'mc-bastion-reward':.9,'mc-nether-impact':.4,'mc-dragon-warn':.9,'mc-dragon-swoop':.65,'mc-dragon-breath':1.2,'mc-crystal-break':.65,'mc-dragon-hit':.5,'mc-dragon-defeat':2.1,'mc-ghast-defeat':1.2,'mc-crystal-energy':.75,'mc-dragon-dissolve':1.1,'mc-end-portal-open':1.2,'mc-trident-ready':.18,'mc-slime-bounce':.42,'mc-slime-suppress':.22,'mc-honey-stick':.38,'mc-amethyst-chime':.9
});
const TAU=Math.PI*2,clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const finite=(value,fallback)=>Number.isFinite(Number(value))?Number(value):fallback;
const hash=text=>{let n=2166136261;for(const char of String(text)){n^=char.charCodeAt(0);n=Math.imul(n,16777619);}return n>>>0;};
const rng=seed=>{let n=(seed>>>0)||1;return()=>{n^=n<<13;n^=n>>>17;n^=n<<5;return(n>>>0)/4294967296*2-1;};};
const fade=(t,d,attack=.004,release=.035)=>Math.min(1,t/attack,Math.max(0,(d-t)/release));
export const isMinecraftSound=key=>Object.hasOwn(MINECRAFT_SOUND_DURATIONS,key)||key==='mc-fuse-stop';
/** Map only when the active room is the authored Minecraft adventure. */
export function minecraftEventFor(key){return({flag:'mc-flag',jump:'mc-jump',jump_super:'mc-jump',hurt:'mc-hurt',death:'mc-hurt',gameover:'mc-hurt',pickup:'mc-pickup',powerup:'mc-pickup',checkpoint:'mc-pickup',life:'mc-pickup',portal:'mc-portal',complete:'mc-complete',world_clear:'mc-complete',pause:'mc-ui',bump:'mc-footstep',stomp:'mc-sand-settle',break:'mc-sand',kick:'mc-sand-settle'})[key]||key;}

/** A mono Float32 PCM clip. Options: seed, duration (seconds), intensity.
 * Timing, pan, and volume belong to the event mixer, never the oscillator. */
export function synthesizeMinecraftSound(key,options={}){
 const sampleRate=Math.round(clamp(finite(options.sampleRate,48000),8000,96000));
 if(isMinecraftMusic(key))return synthesizeMinecraftMusic(key==='mc-mining-music'?MINECRAFT_AUDIO_THEME:key,{sampleRate,intensity:clamp(finite(options.intensity,1),0,1.5)});
 const duration=clamp(finite(options.duration,MINECRAFT_SOUND_DURATIONS[key]||0),0,30);
 const pcm=new Float32Array(Math.ceil(duration*sampleRate));
 if(!isMinecraftSound(key)||key==='mc-fuse-stop')return{pcm,sampleRate,duration:0};
 const random=rng(hash(key+':'+(options.seed??0))),intensity=clamp(finite(options.intensity,1),0,1.5);
 const note=key==='mc-note'?minecraftNoteOptions(options):null;
 let low=0,mid=0,phase=0;
 for(let i=0;i<pcm.length;i++){
  const t=i/sampleRate,u=t/duration,noise=random();low+=.018*(noise-low);mid+=.21*(noise-mid);let value=0;
  if(key==='mc-fuse'){
   const grain=.56+.44*Math.sin(TAU*(19*t+5*t*t))**2;
   const crack=Math.max(0,Math.sin(TAU*37*t))**18;
   value=((noise-mid)*.14+mid*.12)*( .35+.65*u)*grain+noise*crack*.055;
  }else if(key==='mc-explosion'){
   phase+=TAU*(33+68*Math.exp(-t*15))/sampleRate;
   const punch=Math.sin(phase)*.6*Math.exp(-t*6),debris=(noise-mid)*.27*Math.exp(-t*8);
   value=punch+low*3.7*Math.exp(-t*3.8)+mid*.75*Math.exp(-t*7)+debris;
  }else if(key==='mc-sand'){
   const grain=(.2+Math.sin(TAU*(27*t+13*t*t))**10+.55*Math.sin(TAU*61*t)**16)*Math.exp(-t*4.5);
   value=((noise-mid)*.15+mid*.34)*grain+low*.26;
  }else if(key==='mc-sand-settle'){
   value=(mid*.5+(noise-mid)*.12)*Math.exp(-t*23)+Math.sin(TAU*104*t)*.1*Math.exp(-t*31);
  }else if(key==='mc-sword-swing'){
   value=((noise-mid)*.22+mid*.11)*Math.sin(Math.PI*u)**1.4+Math.sin(TAU*(820*t-1100*t*t))*.065*Math.exp(-t*20);
  }else if(key==='mc-bow-release'){
   value=Math.sin(TAU*(680*t-180*t*t))*.18*Math.exp(-t*30)+(noise-mid)*.09*Math.exp(-t*18);
  }else if(key==='mc-trident-throw'||key==='mc-trident-return'){
   const back=key==='mc-trident-return';value=(noise-mid)*.09*Math.sin(Math.PI*u)+Math.sin(TAU*((back?360:740)*t+(back?420:-420)*t*t))*.09*Math.exp(-t*4)+Math.sin(TAU*1760*t)*.035*Math.exp(-t*8);
  }else if(key==='mc-trident-catch'||key==='mc-gear-pickup'){
   value=(Math.sin(TAU*660*t)+.5*Math.sin(TAU*990*t)+.3*Math.sin(TAU*1320*t))*.085*Math.exp(-t*9);
  }else if(key==='mc-shield-raise'){
   value=(mid*.18+(noise-mid)*.035)*Math.exp(-t*22)+Math.sin(TAU*(168-100*t)*t)*.105*Math.exp(-t*20);
  }else if(key==='mc-shield-block'){
   value=(Math.sin(TAU*147*t)*.19+Math.sin(TAU*353*t)*.085+Math.sin(TAU*811*t)*.025)*Math.exp(-t*16)+(mid*.3+(noise-mid)*.11)*Math.exp(-t*35);
  }else if(key==='mc-shield-parry'){
   // A hard metallic transient and low stopped impact are followed by a
   // rising two-tone answer. Blocking stays short, wooden and low-pitched.
   phase+=TAU*(72+155*Math.exp(-t*45))/sampleRate;
   value=Math.sin(phase)*.28*Math.exp(-t*27)+(noise-mid)*.19*Math.exp(-t*65)+mid*.21*Math.exp(-t*34);
   value+=(Math.sin(TAU*1174.659*t)*.18+Math.sin(TAU*1760*t)*.09+Math.sin(TAU*2849.318*t)*.045)*Math.exp(-t*8);
   const age=t-.075;if(age>=0)value+=(Math.sin(TAU*1567.982*age)*.105+Math.sin(TAU*2351.97*age)*.035)*Math.exp(-age*8)*Math.min(1,age/.003);
  }else if(key==='mc-shield-break'){
   for(const at of [0,.045,.105]){const age=t-at;if(age>=0)value+=(mid*.28+(noise-mid)*.11+Math.sin(TAU*(108-70*age)*age)*.14)*Math.exp(-age*19)*Math.min(1,age/.002);}
   value+=low*.7*Math.exp(-t*6);
  }else if(key==='mc-shield-ready'){
   for(let n=0;n<2;n++){const age=t-n*.1;if(age>=0)value+=(Math.sin(TAU*[440,659.255][n]*age)*.085+Math.sin(TAU*[880,1318.51][n]*age)*.018)*Math.exp(-age*9)*Math.min(1,age/.004);}
  }else if(key==='mc-channeling-thunder'){
   const crack=(noise-mid)*.21*Math.exp(-t*34),rumble=low*1.35*Math.exp(-t*3.2)+mid*.24*Math.exp(-t*5);
   phase+=TAU*(39+60*Math.exp(-t*18))/sampleRate;value=crack+rumble+Math.sin(phase)*.28*Math.exp(-t*5);
   for(const at of [.12,.27]){const age=t-at;if(age>=0)value+=mid*.2*Math.exp(-age*12)*Math.min(1,age/.006);}
  }else if(key==='mc-trident-enchant'){
   // The same D-A-F-E-D identity becomes the enchantment's short fanfare.
   for(let n=0;n<5;n++){const age=t-[0,.08,.25,.33,.5][n];if(age>=0){const f=midiFrequency([74,81,77,76,74][n]);value+=(Math.sin(TAU*f*age)*.085+Math.sin(TAU*f*2.002*age)*.027)*Math.exp(-age*6)*Math.min(1,age/.005);}}
   value+=mid*.035*Math.sin(Math.PI*u);
  }else if(key==='mc-footstep'){
   const crunch=Math.exp(-t*48)+.45*Math.exp(-Math.max(0,t-.035)*70)*(t>.035?1:0);
   value=(mid*.32+(noise-mid)*.09)*crunch+Math.sin(TAU*83*t)*.075*Math.exp(-t*42);
  }else if(key==='mc-note'){
   const ratio=2**((note.note-12)/12),p=TAU*note.frequency*t,kind=note.instrument,env=fade(t,duration,.004,.07)*Math.exp(-t*(kind==='flute'?2:kind==='hat'||kind==='snare'?20:5));
   if(kind==='basedrum')value=Math.sin(TAU*(60*ratio*t+1.5*(1-Math.exp(-t*35*ratio))))*.25*Math.exp(-t*15);
   else if(kind==='snare'||kind==='hat')value=((noise-mid)*(kind==='hat'?.12:.2)+mid*.08)*(.65+.35*Math.sin(TAU*2400*ratio*t))*Math.exp(-t*ratio*2);
   else if(kind==='bell'||kind==='chime'||kind==='cow_bell'||kind==='iron_xylophone')value=Math.sin(p)*.16+Math.sin(p*(kind==='cow_bell'?1.48:2.003))*.06+Math.sin(p*3.99)*.025;
   else if(kind==='harp')value=Math.sin(p)*.20+Math.sin(p*2.001)*.075*Math.exp(-t*12)+Math.sin(p*3.002)*.036*Math.exp(-t*20)+Math.sin(p*4.003)*.018*Math.exp(-t*30)+mid*.035*Math.exp(-t*95);
   else if(kind==='flute')value=Math.sin(p)*.17+Math.sin(p*2)*.018+mid*.01;
   else if(kind==='bit')value=(Math.sin(p)+Math.sin(p*3)/3+Math.sin(p*5)/5)*.12;
   else if(kind==='didgeridoo')value=(Math.sin(p)*.16+Math.sin(p*2)*.08+Math.sin(p*5)*.025)*(.75+.25*Math.sin(TAU*12*t));
   else value=Math.sin(p)*.17+Math.sin(p*2)*(kind==='bass'?.06:.035)+Math.sin(p*3)*(kind==='banjo'?.07:.018);
   value*=env;
  }else if(key==='mc-furnace-ignite'||key==='mc-furnace-smelt'){
   const ignite=key==='mc-furnace-ignite',crackle=Math.max(0,Math.sin(TAU*(43*t+12*t*t)))**18;
   value=(low*.8+mid*.15+(noise-mid)*(.02+crackle*.18))*(ignite?Math.exp(-t*4):Math.sin(Math.PI*u)**.4);
   if(ignite)value+=Math.sin(TAU*(82-35*u)*t)*.12*Math.exp(-t*11);
  }else if(key==='mc-furnace-done'){
   for(let n=0;n<3;n++){const age=t-n*.13;if(age>=0)value+=(Math.sin(TAU*[392,493.883,587.33][n]*age)+.14*Math.sin(TAU*[784,987.766,1174.66][n]*age))*.075*Math.exp(-age*6)*Math.min(1,age/.005);}
  }else if(key==='mc-portal'||key==='mc-portal-ambience'){
   const swell=Math.sin(Math.PI*u)**1.4,base=key==='mc-portal'?92:66;
   phase+=TAU*(base+38*u*u)/sampleRate;
   value=(Math.sin(phase)*.11+Math.sin(phase*1.498)*.065+Math.sin(phase*2.006+Math.sin(TAU*5*t))*.035+mid*.04)*swell;
  }else if(key==='mc-jump'){
   phase+=TAU*(170+740*u**.65)/sampleRate;
   value=(Math.sin(phase)+Math.sin(phase*3)/3+Math.sin(phase*5)/5)*.075*Math.sin(Math.PI*u)**.6;
  }else if(key==='mc-hurt'){
   phase+=TAU*(180-100*u)/sampleRate;
   value=(Math.sin(phase)*.15+mid*.16)*Math.exp(-t*9);
  }else if(key==='mc-flag'){
   const f=880*Math.pow(.25,u);phase+=TAU*f/sampleRate;value=(Math.sin(phase)+Math.sin(phase*3)/3)*.15*Math.sin(Math.PI*u)**.4;
  }else if(key==='mc-pickup'||key==='mc-complete'){
   const notes=key==='mc-complete'?[196,261.6256,329.6276,391.9954,523.2511,659.2551,587.3295,523.2511]:[587.3295,880],spacing=key==='mc-complete'?.21:.095;
   for(let n=0;n<notes.length;n++){const age=t-n*spacing;if(age>=0)value+=(Math.sin(TAU*notes[n]*age)+.25*Math.sin(TAU*notes[n]*2*age))*.065*Math.exp(-age*7)*Math.min(1,age/.004);}
  }else if(['mc-cow','mc-sheep','mc-llama'].includes(key)){
   const f=key==='mc-cow'?92:key==='mc-sheep'?190:145,vibrato=key==='mc-sheep'?Math.sin(TAU*15*t)*12:Math.sin(TAU*4*t)*5;phase+=TAU*(f+vibrato+24*Math.sin(Math.PI*u))/sampleRate;value=(Math.sin(phase)*.15+Math.sin(phase*2)*.08+Math.sin(phase*4)*.035+mid*.035)*Math.sin(Math.PI*u)**.65;
  }else if(key==='mc-pig'||key==='mc-pig-scared'){
   // Two soft nasal grunts; the startled call stretches into a high squeak.
   const scared=key==='mc-pig-scared',pulseAge=scared?t:t<.20?t:t-.24;
   const envelope=scared?Math.sin(Math.PI*u)**.7:pulseAge>=0&&pulseAge<.18?Math.sin(Math.PI*pulseAge/.18):0;
   phase+=TAU*((scared?235:117)+(scared?220:36)*Math.sin(Math.PI*u)+13*Math.sin(TAU*22*t))/sampleRate;
   value=(Math.sin(phase)*.085+Math.sin(phase*2)*.04+Math.sin(phase*5)*.021+mid*.085)*envelope;
  }else if(key==='mc-apple-drop'){
   const plop=Math.max(0,t-.12);value=(noise-mid)*.045*Math.exp(-t*13)+mid*.11*Math.exp(-t*9)+(t>.12?Math.sin(TAU*(164-110*plop)*plop)*.11*Math.exp(-plop*27):0);
  }else if(key==='mc-apple-pickup'||key==='mc-secret'||key==='mc-mine-lights'){
   const notes=key==='mc-apple-pickup'?[659.255,987.767]:key==='mc-secret'?[261.626,329.628,391.995,523.251]:[146.832,220,293.665,440];
   const spacing=key==='mc-apple-pickup'?.09:key==='mc-secret'?.15:.13;
   for(let n=0;n<notes.length;n++){const age=t-n*spacing;if(age>=0)value+=(Math.sin(TAU*notes[n]*age)+.28*Math.sin(TAU*notes[n]*3.003*age))*.065*Math.exp(-age*(key==='mc-apple-pickup'?10:4.6))*Math.min(1,age/.006);}
   if(key==='mc-mine-lights')value+=Math.sin(TAU*73.416*t)*.022*Math.sin(Math.PI*u);
  }else if(key==='mc-cart-rattle'||key==='mc-cart-start'||key==='mc-cart-stop'){
   const start=key==='mc-cart-start',stop=key==='mc-cart-stop',speed=start?14+u*28:stop?35-u*24:32;
   const pulses=Math.max(0,Math.sin(TAU*speed*t))**14,roll=(mid*.18+(noise-mid)*.035)*(.4+pulses);
   const envelope=start?.4+.6*u:stop?1-u:Math.sin(Math.PI*u)**.3;
   value=roll*envelope+Math.sin(TAU*76*t)*.04*pulses*envelope;
   if(start||stop)value+=Math.sin(TAU*132*t)*.12*Math.exp(-t*29)+mid*.21*Math.exp(-t*35);
  }else if(key==='mc-ore'){
   value=(Math.sin(TAU*1174.659*t)*.075+Math.sin(TAU*1759.99*t)*.035+Math.sin(TAU*2701*t)*.018)*Math.exp(-t*10)+mid*.18*Math.exp(-t*45);
  }else if(key==='mc-enderman-warning'){
   phase+=TAU*(170+155*u)/sampleRate;value=(Math.sin(phase)*.055+Math.sin(phase*1.503)*.035+mid*.035)*Math.sin(Math.PI*u);
  }else if(key==='mc-enderman-stare'){
   phase+=TAU*(125+125*Math.sin(Math.PI*u)+28*Math.sin(TAU*15*t))/sampleRate;
   value=(Math.sin(phase)*.095+Math.sin(phase*2.017)*.047+Math.sin(phase*3.031)*.025+mid*.17)*(Math.sin(Math.PI*u)**.65)*(.72+.28*Math.sin(TAU*24*t)**2);
  }else if(key==='mc-enderman-aggro'){
   phase+=TAU*(380-255*u)/sampleRate;value=(Math.sin(phase)*.11+Math.sin(phase*1.512)*.045+mid*.12)*Math.sin(Math.PI*u)*Math.exp(-t*2);
  }else if(key==='mc-enderman-attack'){
   value=(Math.sin(TAU*(115*t-75*t*t))*.16+mid*.28+(noise-mid)*.055)*Math.exp(-t*19);
  }else if(key==='mc-enderman-lift'){
   value=(mid*.17+(noise-mid)*.035)*Math.exp(-t*7)+Math.sin(TAU*(76+18*u)*t)*.065*Math.sin(Math.PI*u);
  }else if(key==='mc-enderman-teleport'){
   phase+=TAU*(430*Math.exp(-u*2.7)+74)/sampleRate;
   value=(Math.sin(phase)*.11+Math.sin(phase*1.512)*.05+mid*.14)*Math.sin(Math.PI*u)**.8;
  }else if(key==='mc-villager'||key==='mc-villager-greet'||key==='mc-villager-success'||key==='mc-villager-disagree'){
   // Original source/filter-style voiced interjections, not speech, TTS,
   // recordings or a copied actor. Each context has its own timing/contour.
   const success=key==='mc-villager-success',disagree=key==='mc-villager-disagree',greet=key==='mc-villager-greet';
   const split=success?.32:disagree?.40:greet?.36:1,age=t<split?t:t-split,span=t<split?split-.055:duration-split-.035;
   const vowel=success&&t<split,progress=Math.max(0,Math.min(1,age/Math.max(.01,span))),env=age>=0&&age<span?Math.sin(Math.PI*progress)**(vowel?.64:.9):0;
   const base=success?126:disagree?112:103,contour=success?34*Math.sin(Math.PI*progress*.6):disagree?-24*progress:18*progress;
   const frequency=base+contour+2.3*Math.sin(TAU*6*t),formant1=vowel?620:330,formant2=vowel?1230:1040;
   phase+=TAU*frequency/sampleRate;let voice=0;
   for(let harmonic=1;harmonic<=12;harmonic++){
    const f=harmonic*frequency,weight=(.22+1.45*Math.exp(-(((f-formant1)/185)**2))+.74*Math.exp(-(((f-formant2)/290)**2)))/harmonic;
    voice+=Math.sin(phase*harmonic+.05*harmonic)*weight;
   }
   value=(voice*(success?.118:.125)+mid*(vowel?.105:.028)+(noise-mid)*(vowel?.014:.004))*env;
  }else if(key==='mc-golem-uppercut'){
   // Iron-arm lift, low contact thump, then a brief body-sized metal ring.
   const wind=Math.sin(Math.PI*Math.min(1,t/.14))**1.3;
   value=(noise-mid)*.13*wind*(t<.14?1:0)+mid*.10*wind;
   const age=t-.10;if(age>=0){const impact=fade(age,duration-.10,.002,.045);value+=impact*(Math.sin(TAU*(74*age+1.3*(1-Math.exp(-age*28))))*.34*Math.exp(-age*13)+mid*.46*Math.exp(-age*28)+(noise-mid)*.16*Math.exp(-age*49)+(Math.sin(TAU*311*age)*.10+Math.sin(TAU*773*age)*.05)*Math.exp(-age*7));}
  }else if(key==='mc-golem-rose'){
   // A quiet joint movement and a gentle, original two-note offering.
   value=mid*.09*Math.exp(-t*24);
   for(let n=0;n<2;n++){const age=t-[.06,.25][n];if(age>=0){const f=[392,523.251][n];value+=(Math.sin(TAU*f*age)*.07+Math.sin(TAU*f*2.002*age)*.021)*Math.exp(-age*6)*Math.min(1,age/.008);}}
  }else if(key==='mc-ghast-charge'||key==='mc-ghast-hit'){
   phase+=TAU*(key==='mc-ghast-charge'?140+210*u:350-240*u)/sampleRate;value=(Math.sin(phase)*.085+Math.sin(phase*1.013)*.045+mid*.08)*Math.sin(Math.PI*u);
  }else if(key==='mc-ghast-fire'||key==='mc-nether-impact'||key==='mc-bastion-break'){
   value=(mid*.5+(noise-mid)*.14+Math.sin(TAU*(90-40*u)*t)*.14)*Math.exp(-t*(key==='mc-bastion-break'?5:12));
  }else if(key==='mc-fireball-return'||key==='mc-bastion-reward'){
   phase+=TAU*(key==='mc-fireball-return'?300+650*u:520+180*Math.floor(u*4))/sampleRate;value=(Math.sin(phase)*.095+Math.sin(phase*2)*.03)*Math.sin(Math.PI*u)*Math.exp(-t*2);
  }else if(key==='mc-magma-jump'||key==='mc-magma-stomp'){
   phase+=TAU*(key==='mc-magma-jump'?70+140*u:180-120*u)/sampleRate;value=(Math.sin(phase)*.1+mid*.14)*Math.exp(-t*8);
  }else if(key==='mc-dragon-warn'||key==='mc-dragon-swoop'||key==='mc-dragon-breath'){
   const breath=key==='mc-dragon-breath';phase+=TAU*(breath?58:92-44*u)/sampleRate;
   value=(Math.sin(phase)*.13+Math.sin(phase*.503)*.07+mid*(breath?.38:.2)+(noise-mid)*.04)*Math.sin(Math.PI*u)**.6;
  }else if(key==='mc-crystal-break'){
   value=(Math.sin(TAU*1397*t)*.09+Math.sin(TAU*2093*t)*.06+Math.sin(TAU*3136*t)*.03)*Math.exp(-t*6)+mid*.12*Math.exp(-t*16);
  }else if(key==='mc-dragon-hit'){
   phase+=TAU*(170-125*u)/sampleRate;value=(Math.sin(phase)*.2+mid*.25)*Math.exp(-t*7);
  }else if(key==='mc-slime-bounce'||key==='mc-slime-suppress'){
   phase+=TAU*(key==='mc-slime-bounce'?90+320*Math.exp(-u*5):65+55*(1-u))/sampleRate;value=(Math.sin(phase)*.16+Math.sin(phase*1.9)*.045+mid*.05)*Math.exp(-u*5);
  }else if(key==='mc-honey-stick'){
   phase+=TAU*(120-65*u)/sampleRate;value=(Math.sin(phase)*.07+mid*.11)*Math.sin(Math.PI*u)*Math.exp(-u*2);
  }else if(key==='mc-amethyst-chime'){
   value=(Math.sin(TAU*880*t)*.09+Math.sin(TAU*1320*t)*.065+Math.sin(TAU*1760*t)*.035)*Math.exp(-t*4);
  }else if(key==='mc-trident-ready'){
   phase+=TAU*(180+600*u)/sampleRate;value=(Math.sin(phase)*.07+mid*.025)*Math.sin(Math.PI*u);
  }else if(key==='mc-ghast-defeat'){
   phase+=TAU*(380*(1-u)+45)/sampleRate;value=(Math.sin(phase)*.12+Math.sin(phase*1.025)*.07+mid*.18)*Math.sin(Math.PI*u)*Math.exp(-u*1.8);
  }else if(key==='mc-crystal-energy'||key==='mc-dragon-dissolve'||key==='mc-end-portal-open'){
   const f=key==='mc-end-portal-open'?196:key==='mc-crystal-energy'?740:98;phase+=TAU*f*(1+u*.6)/sampleRate;value=(Math.sin(phase)*.1+Math.sin(phase*1.5)*.06+Math.sin(phase*2)*.04+mid*.06)*Math.sin(Math.PI*u)*Math.exp(-u);
  }else if(key==='mc-dragon-defeat'){
   for(let n=0;n<5;n++){const age=t-n*.23;if(age>=0)value+=Math.sin(TAU*[196,246.942,293.665,391.995,493.883][n]*age)*.075*Math.exp(-age*3)*Math.min(1,age/.008);}value+=low*.8*Math.exp(-t*4);
  }else if(key==='mc-ui')value=Math.sin(TAU*440*t)*.055*Math.sin(Math.PI*u);
  pcm[i]=clamp(value*intensity*(key==='mc-ambience'?1:fade(t,duration)), -.95,.95);
 }
 return{pcm,sampleRate,duration:pcm.length/sampleRate};
}

/** R7 local-only music. Selected files stay in this page's memory. No network,
 * upload, URL, storage, or export path receives the user's audio. */
export const MINECRAFT_LOCAL_REALMS=Object.freeze([{key:'mc-ambience',label:'主世界'},{key:'mc-nether-music',label:'下界'},{key:'mc-boss-music',label:'末地'}]);
export function createMinecraftLocalMusicLibrary(){
 const records=new Map(),listeners=new Set();let serial=0,enabled=true;
 const keyFor=realm=>{const key=isMinecraftMusic(realm)?realm:minecraftMusicTheme(realm);return key==='mc-mining-music'?MINECRAFT_AUDIO_THEME:key;};
 const notify=(kind,key=null)=>{for(const listener of [...listeners])listener({kind,key});};
 return{
  get(realm){return records.get(keyFor(realm));},get enabled(){return enabled;},
  setFile(realm,file){
   const key=keyFor(realm);if(!file||typeof file.arrayBuffer!=='function'||typeof file.name!=='string')throw Error('请选择本机音频文件');
   if(!/^audio\//i.test(file.type||'')&&!/\.(mp3|wav|ogg|oga|m4a|aac|flac|opus)$/i.test(file.name))throw Error('请选择 MP3、WAV、OGG 或浏览器支持的音频');
   if(Number(file.size)>50*1024*1024)throw Error('每个音频文件请小于 50 MB');
   records.set(key,{id:++serial,file,name:file.name,status:'selected',buffer:null,pending:null,error:''});enabled=true;notify('file',key);return true;
  },
  clear(realm){const key=keyFor(realm);records.delete(key);notify('file',key);},
  setEnabled(value){enabled=!!value;notify('enabled');return enabled;},
  subscribe(listener){listeners.add(listener);return()=>listeners.delete(listener);},
  changed(key){notify('status',key);},
  snapshot(){return{enabled,tracks:Object.fromEntries(MINECRAFT_LOCAL_REALMS.map(({key})=>{const r=records.get(key);return[key,r?{name:r.name,status:r.status,error:r.error}:null];}))};}
 };
}
export const minecraftLocalMusicLibrary=createMinecraftLocalMusicLibrary();
/** Shared start/pause controls. Selection never starts playback by itself. */
export function mountMinecraftLocalMusic(host,{library=minecraftLocalMusicLibrary,bundled=false}={}){
 const root=document.createElement('details'),summary=document.createElement('summary'),hint=document.createElement('p'),toggle=document.createElement('button');
 root.className='minecraft-local-music';root.style.cssText='font:12px/1.45 system-ui;max-width:100%;padding:8px;border:1px solid #777;border-radius:6px;text-align:left';
 summary.textContent='本地 BGM · 默认仅音效';summary.style.cursor='pointer';hint.textContent=bundled?'已包含 Dark Reaven Music 的 CC BY-SA 3.0 配乐。可用有权使用的本地文件覆盖对应世界；本地文件仅留在当前页面，不上传、不写入 HTML。':'可选择您有权使用的本地音频。只在当前页面播放，不上传、不写入 HTML；未选择的世界保持无 BGM。';hint.style.cssText='margin:6px 0';toggle.type='button';toggle.style.cssText='font:inherit;min-height:30px;margin:4px 0;padding:4px 8px';
 root.append(summary,hint,toggle);const rows=[];
 for(const {key,label}of MINECRAFT_LOCAL_REALMS){
  const row=document.createElement('div'),name=document.createElement('label'),input=document.createElement('input'),clear=document.createElement('button'),status=document.createElement('span');
  row.style.cssText='display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin:5px 0';name.textContent=label;input.type='file';input.accept='audio/*,.mp3,.wav,.ogg,.m4a,.flac,.opus';input.setAttribute('aria-label',label+'本地 BGM');input.dataset.musicRealm=key;input.style.cssText='font:11px system-ui;max-width:210px;min-height:28px';clear.type='button';clear.textContent='移除';clear.style.cssText='font:11px system-ui;min-height:28px;padding:3px 6px';status.style.cssText='font:11px system-ui;color:inherit;opacity:.85;overflow-wrap:anywhere';status.setAttribute('role','status');
  input.onchange=()=>{const file=input.files?.[0];if(!file)return;try{library.setFile(key,file);}catch(error){status.textContent=error.message;}input.value='';};clear.onclick=()=>library.clear(key);
  name.append(input);row.append(name,clear,status);root.append(row);rows.push({key,clear,status});
 }
 function refresh(){const state=library.snapshot(),count=Object.values(state.tracks).filter(Boolean).length;summary.textContent=count?'本地 BGM · '+count+(bundled?' / 3 个世界已覆盖':' / 3 个世界已选择'):bundled?'BGM · 已内置授权配乐':'本地 BGM · 默认仅音效';toggle.disabled=!count&&!bundled;toggle.textContent=!count&&!bundled?'BGM：未选择':state.enabled?'暂停 BGM（保留音效）':bundled?'启用 BGM':'启用已选 BGM';toggle.setAttribute('aria-pressed',String(state.enabled&&(!!count||bundled)));for(const row of rows){const q=state.tracks[row.key];row.clear.disabled=!q;row.status.textContent=!q?(bundled?'使用内置配乐':'未选择，仅音效'):q.status==='error'?q.name+' · '+q.error:q.name+(q.status==='loading'?' · 正在读取':q.status==='ready'?' · 已就绪':' · 开始游戏后读取');}}
 toggle.onclick=()=>library.setEnabled(!library.enabled);root.addEventListener('keydown',e=>e.stopPropagation());root.addEventListener('keyup',e=>e.stopPropagation());const unsubscribe=library.subscribe(refresh);refresh();host.append(root);
 return{root,destroy(){unsubscribe();root.remove();}};
}

/** A shared piecewise-linear duck envelope. Quiet footsteps only trim 12%;
 * explosions and boss cries make room without silencing the musical phrase. */
function duckFor(event,time=0){
 const key=event.event||event.key||'',light=/footstep|cart-rattle|furnace-smelt/.test(key),strong=/explosion|dragon-|ghast-|bastion-break|channeling-thunder|shield-break/.test(key);
 if(key==='mc-note'&&event.passageDuration)return{start:time,attack:.012,hold:event.passageDuration,release:.28,depth:.16};
 if(key==='mc-note'&&event.role)return{start:time,attack:.012,hold:Math.max(.80,finite(event.duration,.20)+.06),release:.28,depth:.16};
 if(key==='mc-shield-parry')return{start:time,attack:.008,hold:.34,release:.38,depth:.23};
 const depth=light?.88:strong?.43:.68,hold=clamp(finite(event.duration,MINECRAFT_SOUND_DURATIONS[key]||.2)*.45,.07,.42);
 return{start:time,attack:.015,hold,release:strong?.42:.26,depth};
}
function duckValue(e,t){const age=t-e.start;if(age<0||age>=e.attack+e.hold+e.release)return 1;if(age<e.attack)return 1+(e.depth-1)*age/e.attack;if(age<e.attack+e.hold)return e.depth;return e.depth+(1-e.depth)*(age-e.attack-e.hold)/e.release;}
function duckAt(events,t){let value=1;for(const e of events)value=Math.min(value,duckValue(e,t));return value;}
function duckCurve(events,from=0){
 const times=[from];for(const e of events)for(const time of [e.start,e.start+e.attack,e.start+e.attack+e.hold,e.start+e.attack+e.hold+e.release])if(time>from)times.push(time);
 const boundaries=[...new Set(times)].sort((a,b)=>a-b),points=[];
 for(let n=0;n<boundaries.length;n++){
  const a=boundaries[n],b=boundaries[n+1];points.push({time:a,value:duckAt(events,a)});if(b===undefined)break;
  // Between event corners each envelope is linear. Include crossings so the
  // same minimum envelope is exact in AudioParam ramps and offline samples.
  const lines=events.filter(e=>e.start<b&&e.start+e.attack+e.hold+e.release>a).map(e=>[duckValue(e,a),duckValue(e,b)]),crossings=[];
  for(let i=0;i<lines.length;i++)for(let j=i+1;j<lines.length;j++){const d0=lines[i][0]-lines[j][0],d1=lines[i][1]-lines[j][1];if(d0*d1<0){const time=a+(b-a)*d0/(d0-d1);crossings.push({time,value:duckAt(events,time)});}}
  points.push(...crossings.sort((x,y)=>x.time-y.time));
 }
 return points;
}
function setGain(parameter,value,time){if(parameter.setValueAtTime)parameter.setValueAtTime(value,time);else parameter.value=value;}
function rampGain(parameter,value,time){if(parameter.linearRampToValueAtTime)parameter.linearRampToValueAtTime(value,time);else parameter.value=value;}
/** Construct only inside unlock, reached from the existing keyboard/start UI.
 * No queued SFX, timers, interval callbacks or downloaded audio assets. */
export function createMinecraftSound({contextFactory,musicMode='synth',localLibrary=minecraftLocalMusicLibrary,musicMedia={},fetchAudio=globalThis.fetch?.bind(globalThis)}={}){
 let context=null,unlocked=false,enabled=true,suspended=false,track='',loop=null,blocked=false,lastError='',pending=null,attempt=0,musicBus=null,cursor=0,pausedDuckTime=0,pausedDucks=[];
 const sources=new Set(),musicSources=new Set(),events=[],cache=new Map(),ducks=[],recordings=new Map();let disposed=false;const localOwner={},recorded=musicMode==='local'||musicMode==='licensed';
 const musicRecord=key=>localLibrary.get(key)||(musicMode==='licensed'?recordings.get(minecraftLicensedMusicId(key)):null);
 const loopDuration=source=>finite(source?.buffer?.duration,MINECRAFT_MUSIC_THEMES[track]?.duration||1);
 const now=()=>finite(context?.currentTime,0),log=key=>{events.push(key);if(events.length>30)events.shift();};
 function cleanup(source){if(!source)return;sources.delete(source);musicSources.delete(source);try{source.disconnect();}catch{}for(const node of source.mcNodes||[])try{node.disconnect();}catch{}if(source===loop)loop=null;}
 function stopSource(source){if(!source)return;try{source.stop();}catch{}cleanup(source);}
 function haltEffects(){for(const source of [...sources])if(!musicSources.has(source))stopSource(source);}
 function haltLoop(preserve=false){if(preserve&&loop)cursor=(now()-loop.mcStarted+loop.mcOffset)%loopDuration(loop);for(const source of [...musicSources])stopSource(source);loop=null;}
 function bufferFor(key,options){
  const cacheKey=JSON.stringify([key,options.seed??0,options.duration??null,options.intensity??1,options.note??0,options.baseBlock??'dirt',options.instrument??'']);
  if(cache.has(cacheKey))return cache.get(cacheKey);
  const clip=synthesizeMinecraftSound(key,{...options,sampleRate:context.sampleRate}),buffer=context.createBuffer(1,clip.pcm.length,clip.sampleRate);buffer.getChannelData(0).set(clip.pcm);
  if(cache.size>=64)cache.delete(cache.keys().next().value);cache.set(cacheKey,buffer);return buffer;
 }
 function play(key,options={},repeat=false){
  if(disposed||!enabled||!unlocked||!context||context.state!=='running')return false;
  const buffer=repeat&&recorded?musicRecord(key)?.buffer:bufferFor(key,options);if(!buffer)return false;
  const source=context.createBufferSource();source.buffer=buffer;source.loop=repeat;source.effectKey=key;
  const gain=context.createGain();gain.gain.value=clamp(finite(options.volume,1),0,1.5);source.connect(gain);source.mcGain=gain.gain;source.mcNodes=[gain];let destination=gain;
  if(typeof context.createStereoPanner==='function'){const pan=context.createStereoPanner();pan.pan.value=clamp(finite(options.pan,0),-1,1);gain.connect(pan);destination=pan;source.mcNodes.push(pan);}
  destination.connect(repeat?musicBus:context.destination);sources.add(source);if(repeat)musicSources.add(source);
  source.onended=()=>cleanup(source);source.mcStarted=now();source.mcOffset=finite(options.offset,0);source.start(0,source.mcOffset);log(key);return source;
 }
 function fadeOut(source){if(!source)return;const time=now();source.mcGain.cancelScheduledValues?.(time);setGain(source.mcGain,finite(source.mcGain.value,1),time);rampGain(source.mcGain,0,time+MINECRAFT_MUSIC_CROSSFADE);try{source.stop(time+MINECRAFT_MUSIC_CROSSFADE);}catch{stopSource(source);}}
 function prepareLocal(key){
  const record=localLibrary.get(key);if(!record||record.buffer||record.pending||record.status==='error'||!context||!unlocked||disposed)return;
  const decoder=context;record.owner=localOwner;record.status='loading';localLibrary.changed(key);
  record.pending=Promise.resolve().then(()=>record.file.arrayBuffer()).then(bytes=>{if(disposed||record.owner!==localOwner||localLibrary.get(key)!==record)return null;if(typeof decoder.decodeAudioData!=='function')throw Error('DecodeUnavailable');return decoder.decodeAudioData(bytes.slice(0));}).then(decoded=>{
   if(!decoded||disposed||record.owner!==localOwner||localLibrary.get(key)!==record)return;
   if(!decoded.length||!decoded.numberOfChannels)throw Error('EmptyAudio');
   const channels=Math.min(2,decoded.numberOfChannels),buffer=decoder.createBuffer(channels,decoded.length,decoded.sampleRate),edge=Math.min(Math.round(.012*decoded.sampleRate),Math.floor(decoded.length/2));
   for(let ch=0;ch<channels;ch++){const data=buffer.getChannelData(ch);data.set(decoded.getChannelData(ch));for(let i=0;i<edge;i++){const gain=i/edge;data[i]*=gain;data[data.length-1-i]*=gain;}}
   record.buffer=buffer;record.pending=null;record.status='ready';record.error='';localLibrary.changed(key);if(track===key)startLoop(true);
  }).catch(()=>{if(disposed||record.owner!==localOwner||localLibrary.get(key)!==record)return;record.pending=null;record.status='error';record.error='浏览器无法读取，请换用 MP3 / WAV';lastError='LocalMusicDecodeError';localLibrary.changed(key);});
 }
 function prepareBundled(key){
  if(musicMode!=='licensed'||!context||!unlocked||disposed)return;
  const id=minecraftLicensedMusicId(key),meta=MINECRAFT_LICENSED_MUSIC[id];if(recordings.has(id))return;
  const record={...meta,id,name:meta.title,status:'loading',buffer:null,error:'',licensed:true};recordings.set(id,record);
  const decoder=context;let url;try{url=musicMedia[id]||new URL('./assets/voxel-music/'+meta.file,import.meta.url).href;}catch{record.status='error';record.error='BundledMusicUnavailable';lastError=record.error;return;}
  record.pending=Promise.resolve().then(async()=>{if(typeof fetchAudio!=='function')throw Error('FetchUnavailable');const response=await fetchAudio(url);if(!response.ok)throw Error('BundledMusicUnavailable');return response.arrayBuffer();}).then(bytes=>decoder.decodeAudioData(bytes.slice(0))).then(buffer=>{
   if(disposed)return;if(!buffer?.length||!buffer.numberOfChannels)throw Error('EmptyAudio');record.buffer=buffer;record.pending=null;record.status='ready';record.error='';if(minecraftLicensedMusicId(track)===id&&!localLibrary.get(track))startLoop(true);
  }).catch(()=>{if(disposed)return;record.pending=null;record.status='error';record.error='BundledMusicDecodeError';lastError=record.error;});
 }
 function startLoop(fadeIn=false){
  if(disposed||suspended||!track||loop||musicMode==='off'||recorded&&!localLibrary.enabled)return;
  if(recorded&&!musicRecord(track)?.buffer){if(localLibrary.get(track))prepareLocal(track);else prepareBundled(track);return;}
  const volume=recorded?.35:1;loop=play(track,{offset:cursor,volume:fadeIn?0:volume},true)||null;
  if(loop&&fadeIn){setGain(loop.mcGain,0,now());rampGain(loop.mcGain,volume,now()+MINECRAFT_MUSIC_CROSSFADE);}
 }
 const unsubscribeLocal=recorded?localLibrary.subscribe(change=>{if(disposed||change.kind==='status'||change.key&&change.key!==(track==='mc-mining-music'?MINECRAFT_AUDIO_THEME:track))return;if(change.kind==='enabled'){if(!localLibrary.enabled)haltLoop(true);else startLoop(true);return;}const previous=loop;loop=null;cursor=0;fadeOut(previous);startLoop(true);}):()=>{};
 function applyDuck(key,options={}){
  if(!musicBus)return;const time=now();for(let n=ducks.length-1;n>=0;n--)if(duckValue(ducks[n],time)===1&&ducks[n].start<time-.02)ducks.splice(n,1);
  ducks.push(duckFor({...options,event:key},time));const curve=duckCurve(ducks,time),parameter=musicBus.gain;parameter.cancelScheduledValues?.(time);setGain(parameter,curve[0]?.value??1,time);for(const point of curve.slice(1))rampGain(parameter,point.value,point.time);
 }
 function resetDuck(){ducks.length=0;if(musicBus){musicBus.gain.cancelScheduledValues?.(now());setGain(musicBus.gain,1,now());}}
 function unlock(){
  if(disposed||!enabled)return Promise.resolve(false);
  if(globalThis.navigator?.userActivation&&!globalThis.navigator.userActivation.hasBeenActive){blocked=true;lastError='UserGestureRequired';return Promise.resolve(false);}
  blocked=false;lastError='';
  if(!context){try{const Factory=globalThis.AudioContext||globalThis.webkitAudioContext;context=contextFactory?contextFactory():Factory?new Factory():null;if(context){musicBus=context.createGain();musicBus.connect(context.destination);}}catch(error){lastError=error?.name||'AudioContextError';}}
  if(!context){blocked=true;lastError||='AudioContextUnavailable';return Promise.resolve(false);}
  unlocked=true;const id=++attempt;let result;try{result=context.state==='running'?undefined:context.resume();}catch(error){result=Promise.reject(error);}
  if(context.state==='running')startLoop();
  pending=Promise.resolve(result).then(()=>{if(id!==attempt)return false;pending=null;blocked=context.state!=='running';if(blocked)lastError='AudioContextSuspended';else startLoop();return !blocked;},error=>{if(id!==attempt)return false;pending=null;blocked=true;lastError=error?.name||'AudioContextError';return false;});return pending;
 }
 function background(key=MINECRAFT_AUDIO_THEME){
  if(!isMinecraftMusic(key))return;
  if(track!==key){
   const previous=loop;loop=null;track=key;cursor=0;startLoop(!!previous);
   fadeOut(previous);
  }else startLoop();
 }
 function resumeMusic(key=track||MINECRAFT_AUDIO_THEME,gesture=false){if(suspended&&pausedDucks.length){const shift=now()-pausedDuckTime;ducks.push(...pausedDucks.map(e=>({...e,start:e.start+shift})));pausedDucks=[];if(musicBus){const curve=duckCurve(ducks,now());musicBus.gain.cancelScheduledValues?.(now());setGain(musicBus.gain,curve[0]?.value??1,now());for(const point of curve.slice(1))rampGain(musicBus.gain,point.value,point.time);}}suspended=false;background(key);return gesture?unlock():undefined;}
 function pauseMusic(){if(!suspended){pausedDuckTime=now();pausedDucks=ducks.filter(e=>e.start+e.attack+e.hold+e.release>pausedDuckTime).map(e=>({...e}));}suspended=true;attempt++;pending=null;haltLoop(true);resetDuck();}
 function stopMusic(){pauseMusic();pausedDucks=[];track='';cursor=0;}
 function stop(){stopMusic();haltEffects();}
 function effect(key,options={}){
  if(key==='mc-fuse-stop'||key==='mc-explosion')for(const source of [...sources])if(source.effectKey==='mc-fuse')stopSource(source);
  if(key==='mc-fuse-stop')return true;
  if(!isMinecraftSound(key)||isMinecraftMusic(key))return false;
  const source=play(key,options);if(source)applyDuck(key,options);return!!source;
 }
 return{background,resumeMusic,unlock,effect,pauseMusic,stopMusic,stop,pause(){pauseMusic();haltEffects();},dispose(){stop();disposed=true;unsubscribeLocal();recordings.clear();if(recorded)for(const {key}of MINECRAFT_LOCAL_REALMS){const record=localLibrary.get(key);if(record?.owner===localOwner&&record.pending){record.owner=null;record.pending=null;record.status='selected';localLibrary.changed(key);}}try{context?.close?.()?.catch?.(()=>{});}catch{}},
  setEnabled(value){enabled=!!value;if(!enabled){attempt++;pending=null;haltLoop(true);haltEffects();resetDuck();}else if(unlocked)startLoop();},
  snapshot(){const record=track&&recorded?musicRecord(track):null;return{enabled,blocked,track,playing:!!loop&&context?.state==='running',suspended,pending:!!pending||record?.status==='loading',lastError,events:[...events],procedural:true,unlocked,activeEffects:[...sources].filter(s=>!musicSources.has(s)).length,music:track?(recorded?(record?{title:record.name,local:!record.licensed,licensed:!!record.licensed,status:record.status,credit:record.licensed?MINECRAFT_LICENSED_MUSIC_CREDIT:undefined}:null):musicMode==='off'?null:MINECRAFT_MUSIC_THEMES[track]):null,musicMode,localMusic:recorded?localLibrary.snapshot():null,musicSources:musicSources.size,musicCursor:loop?(now()-loop.mcStarted+loop.mcOffset)%loopDuration(loop):cursor,duckGain:duckAt(ducks,now())};},
  get blocked(){return blocked;},get enabled(){return enabled;}
 };
}

function tapeEvent(item,index,fps){
 const data=item.data&&typeof item.data==='object'?{...item,...item.data}:item;
 const event=minecraftEventFor(data.event||data.key||'');
 const time=finite(data.time,finite(data.seconds,finite(data.frame,finite(data.tick,0))/fps));
 return{...data,event,time,index};
}
/** Render captured events to stereo PCM using the exact browser score buffers.
 * musicIntervals carry {key,startFrame,endFrame}; adjacent theme changes use
 * the same 650 ms transition, and sound events drive the same gain envelope. */
export function renderMinecraftAudioPCM(tape=[],options={}){
 const sampleRate=Math.round(clamp(finite(options.sampleRate,48000),8000,96000)),fps=Math.max(1,finite(options.fps,60));
 const events=tape.filter(e=>!e.type||e.type==='sound').map((e,i)=>tapeEvent(e,i,fps)).filter(e=>isMinecraftSound(e.event)).sort((a,b)=>a.time-b.time||a.index-b.index);
 const inferredDuration=events.reduce((end,e)=>Math.max(end,e.time+(e.duration??MINECRAFT_SOUND_DURATIONS[e.event]??0)),0);
 const duration=Math.max(0,finite(options.duration,inferredDuration)),frames=Math.ceil(duration*sampleRate),pcm=new Float32Array(frames*2),rendered=[];
 const master=clamp(finite(options.masterGain,1),0,1.5),duckEvents=events.filter(e=>e.event!=='mc-fuse-stop'&&!isMinecraftMusic(e.event)).map(e=>duckFor(e,e.time)),duckPoints=duckCurve(duckEvents);
 function mix(clip,start,end,gain=1,pan=0,repeat=false,music=null,clipChannels=1){
  const startSample=Math.round(start*sampleRate),from=Math.max(0,startSample),to=Math.min(frames,Math.round(end*sampleRate));
  const clipFrames=Math.floor(clip.length/clipChannels);if(!clipFrames)return;
  const p=clamp(pan,-1,1),left=Math.sqrt((1-p)/2),right=Math.sqrt((1+p)/2);let point=0;
  for(let i=from;i<to;i++){
   const offset=i-startSample;if(!repeat&&offset>=clipFrames)break;let envelope=1;
   if(music){
    const time=i/sampleRate;while(point+1<duckPoints.length&&duckPoints[point+1].time<=time)point++;
    const a=duckPoints[point],b=duckPoints[point+1];envelope=b?a.value+(b.value-a.value)*(time-a.time)/(b.time-a.time):a?.value??1;
    if(music.fadeIn)envelope*=clamp((time-start)/MINECRAFT_MUSIC_CROSSFADE,0,1);
    if(music.fadeOut)envelope*=clamp(1-(time-music.end)/MINECRAFT_MUSIC_CROSSFADE,0,1);
   }
   const at=(offset%clipFrames)*clipChannels,multiplier=gain*master*envelope;
   if(clipChannels===2){pcm[i*2]+=clip[at]*multiplier;pcm[i*2+1]+=clip[at+1]*multiplier;}
   else{const sample=clip[at]*multiplier;pcm[i*2]+=sample*left;pcm[i*2+1]+=sample*right;}
  }
 }
 const intervals=(options.musicMode==='off'?[]:options.musicIntervals||(options.ambience?[{startFrame:0,endFrame:duration*fps,key:MINECRAFT_AUDIO_THEME}]:[])).filter(e=>isMinecraftMusic(e.key)).map(segment=>({...segment,start:finite(segment.start,finite(segment.startFrame,0)/fps),end:finite(segment.end,finite(segment.endFrame,duration*fps)/fps)})).sort((a,b)=>a.start-b.start),musicClips=new Map(),missingRecordings=[];
 for(let n=0;n<intervals.length;n++){
  const segment=intervals[n],previous=intervals[n-1],next=intervals[n+1],fadeIn=previous&&Math.abs(previous.end-segment.start)<1/fps&&previous.key!==segment.key,fadeOut=next&&Math.abs(next.start-segment.end)<1/fps&&next.key!==segment.key;
  if(!musicClips.has(segment.key)){
   const supplied=options.musicBuffers?.[segment.key]||options.musicBuffers?.[minecraftLicensedMusicId(segment.key)];
   if(supplied){if(supplied.sampleRate!==sampleRate)throw Error('Recorded music PCM sample rate must match render sample rate');musicClips.set(segment.key,{pcm:supplied.pcm,channels:supplied.channels===2?2:1,recorded:true});}
   else if(options.musicMode==='licensed'){missingRecordings.push(segment.key);continue;}
   else musicClips.set(segment.key,{pcm:synthesizeMinecraftSound(segment.key,{sampleRate}).pcm,channels:1,recorded:false});
  }
  const clip=musicClips.get(segment.key);
  mix(clip.pcm,segment.start,segment.end+(fadeOut?MINECRAFT_MUSIC_CROSSFADE:0),finite(segment.volume,options.musicMode==='licensed'?.35:1)*clamp(finite(options.musicGain,1),0,1.5),0,true,{fadeIn,fadeOut,end:segment.end},clip.channels);
 }
 for(let n=0;n<events.length;n++){
  const event=events[n];if(event.event==='mc-fuse-stop'||isMinecraftMusic(event.event))continue;
  const clip=synthesizeMinecraftSound(event.event,{...event,sampleRate});let end=event.time+clip.duration;
  if(event.event==='mc-fuse'){const cut=events.slice(n+1).find(e=>e.event==='mc-fuse-stop'||e.event==='mc-explosion');if(cut)end=Math.min(end,cut.time);}
  mix(clip.pcm,event.time,end,clamp(finite(event.volume,1),0,1.5),finite(event.pan,0));rendered.push({event:event.event,time:event.time,end,seed:event.seed??0,...(event.event==='mc-note'?minecraftNoteOptions(event):{})});
 }
 let peak=0,sum=0,clippedSamples=0;for(let i=0;i<pcm.length;i++){if(Math.abs(pcm[i])>1)clippedSamples++;pcm[i]=clamp(pcm[i],-1,1);peak=Math.max(peak,Math.abs(pcm[i]));sum+=pcm[i]*pcm[i];}
 return{pcm,sampleRate,channels:2,duration:frames/sampleRate,report:{version:MINECRAFT_AUDIO_VERSION,frames,eventCount:rendered.length,events:rendered,peak,rms:Math.sqrt(sum/Math.max(1,pcm.length)),clippedSamples,ambience:intervals.some(e=>e.key===MINECRAFT_AUDIO_THEME),music:{composed:[...musicClips.values()].some(c=>!c.recorded),recorded:[...musicClips.values()].some(c=>c.recorded),tracks:[...musicClips.keys()],missingRecordings:[...new Set(missingRecordings)],intervals,crossfadeSeconds:MINECRAFT_MUSIC_CROSSFADE,ducking:true}}};
}
/** WAV bytes (16-bit PCM stereo), ready for fs.writeFile and ffmpeg muxing. */
export function renderMinecraftAudioTape(tape=[],options={}){
 const {pcm,sampleRate,channels}=renderMinecraftAudioPCM(tape,options),bytes=new Uint8Array(44+pcm.length*2),view=new DataView(bytes.buffer);
 const word=(at,text)=>{for(let n=0;n<text.length;n++)bytes[at+n]=text.charCodeAt(n);};
 word(0,'RIFF');view.setUint32(4,bytes.length-8,true);word(8,'WAVE');word(12,'fmt ');view.setUint32(16,16,true);view.setUint16(20,1,true);view.setUint16(22,channels,true);view.setUint32(24,sampleRate,true);view.setUint32(28,sampleRate*channels*2,true);view.setUint16(32,channels*2,true);view.setUint16(34,16,true);word(36,'data');view.setUint32(40,pcm.length*2,true);
 for(let n=0;n<pcm.length;n++)view.setInt16(44+n*2,Math.round(pcm[n]*(pcm[n]<0?32768:32767)),true);
 return bytes;
}
