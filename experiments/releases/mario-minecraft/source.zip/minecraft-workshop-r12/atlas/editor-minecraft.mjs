import {createVillageShop} from './editor-minecraft-shop.mjs';
import {validateGrotto,createGrottoController} from './editor-minecraft-grotto.mjs';
import {validateWildEnderman,createWildEndermanController} from './editor-minecraft-enderman.mjs';
import {validateStorm,createStormController} from './editor-minecraft-storm.mjs';
import {validateGear,createGearController} from './editor-minecraft-gear.mjs';
import {validateWorkshop,createWorkshopController} from './editor-minecraft-workshop.mjs';
import {validateDragon,createDragonController} from './editor-minecraft-dragon.mjs';
import {validateNether,createNetherController} from './editor-minecraft-nether.mjs';
/** Original opt-in voxel adventure mechanics. Authored timing, not a Minecraft
 * simulation: hostile approach -> cancellable visible fuse -> real blast, and
 * unsupported 16 px sand cells that sweep, settle and remain native solids. */
const copy=value=>JSON.parse(JSON.stringify(value));
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
const finite=(n,a,b)=>Number.isFinite(n)&&n>=a&&n<=b;
const EPS=1e-6;
const horizontal=(a,b)=>a.x+a.w>b.x+EPS&&a.x<b.x+b.w-EPS;
const overlap=(a,b)=>horizontal(a,b)&&a.y+a.h>b.y+EPS&&a.y<b.y+b.h-EPS;
const liveSolid=q=>!q.hidden&&q.collision==='solid';
const distanceToRect=(x,y,q)=>Math.hypot(x-clamp(x,q.x,q.x+q.w),y-clamp(y,q.y,q.y+q.h));
const unsafe=id=>['__proto__','constructor','prototype'].includes(id);
function object(value,keys,label){if(!value||typeof value!=='object'||Array.isArray(value)||![Object.prototype,null].includes(Object.getPrototypeOf(value)))throw Error('Invalid Minecraft '+label);for(const key of Object.keys(value))if(unsafe(key)||!keys.includes(key))throw Error('Unknown Minecraft '+label+' field: '+key);}
function list(value,label,max){if(!Array.isArray(value)||value.length>max)throw Error('Invalid Minecraft '+label+' list');}
export const MINECRAFT_CREEPER_DEFAULTS=Object.freeze({w:16,h:28,detectionRadius:176,triggerRadius:48,fuseTicks:90,blastRadius:80,speed:.62});
const creeperRule=q=>({...MINECRAFT_CREEPER_DEFAULTS,...q});

/** Validate author records and actual stable solid references without mutating. */
export function validateMinecraftRoom(room){
 const spec=room?.minecraft;if(spec===undefined)return;
 object(spec,['version','biome','groundY','creepers','destructibleIds','sandIds','scenery','labels','signs','exploration','dragon','nether','workshop','gear','hero','storm','wildEnderman','musicMode','grotto'],'room');
 if(spec.musicMode!==undefined&&!['licensed','local'].includes(spec.musicMode))throw Error('Invalid Minecraft music mode');
 if(spec.hero!==undefined){object(spec.hero,['alwaysBig','maxHealth','parryFeedback'],'hero');if(spec.hero.alwaysBig!==true||spec.hero.maxHealth!==3||spec.hero.parryFeedback!==undefined&&typeof spec.hero.parryFeedback!=='boolean')throw Error('Invalid Minecraft hero');}
 if(spec.version!==1)throw Error('Unknown Minecraft room version');
 if(spec.biome!==undefined&&!['forest','cave','nether','stronghold','end'].includes(spec.biome))throw Error('Invalid Minecraft biome');
 const map=room.map;if(!map||!finite(map.width,16,32768)||!finite(map.height,32,4096)||!Array.isArray(map.geometry)||!Array.isArray(map.objects))throw Error('Minecraft needs a native room map');
 if(spec.groundY!==undefined&&!finite(spec.groundY,0,map.height))throw Error('Invalid Minecraft groundY');
 if(room.mechanics!==undefined||room.devices?.length)throw Error('Minecraft does not support echo rewind');
 for(const key of ['creepers','destructibleIds','sandIds'])if(spec[key]!==undefined)list(spec[key],key,key==='creepers'?32:2048);
 const ids=new Set([...map.geometry,...map.objects,...(room.markers||[]),...(room.decorations||[])].map(q=>q.id));
 for(const authored of spec.creepers||[]){
  object(authored,['id','x','y',...Object.keys(MINECRAFT_CREEPER_DEFAULTS)],'creeper');const q=creeperRule(authored);
  if(typeof q.id!=='string'||!q.id.length||q.id.length>100||unsafe(q.id)||ids.has(q.id))throw Error('Invalid or duplicate Minecraft creeper ID');ids.add(q.id);
  if(q.w!==16||q.h!==28||!finite(q.x,0,map.width-q.w)||!finite(q.y,0,map.height-q.h)||!finite(q.detectionRadius,48,512)||!finite(q.triggerRadius,16,96)||q.triggerRadius>q.detectionRadius||!Number.isInteger(q.fuseTicks)||!finite(q.fuseTicks,30,240)||!finite(q.blastRadius,32,160)||!finite(q.speed,0,2))throw Error('Invalid Minecraft creeper bounds or authored timing');
  if(map.geometry.some(g=>liveSolid(g)&&overlap(q,g)))throw Error('Minecraft creeper starts inside a solid');
 }
 for(const key of ['destructibleIds','sandIds']){
  const seen=new Set();for(const id of spec[key]||[]){const q=map.geometry.find(g=>g.id===id);if(typeof id!=='string'||unsafe(id)||seen.has(id)||!q||!liveSolid(q)||q.motion||q.liftSpeed)throw Error('Minecraft '+key+' requires unique existing static solid IDs');seen.add(id);if(key==='sandIds'&&(q.w!==16||q.h!==16))throw Error('Minecraft sand requires individual 16 × 16 solids');}
 }
 if(spec.grotto!==undefined)validateGrotto(spec.grotto,room);
 if(spec.wildEnderman!==undefined)validateWildEnderman(spec.wildEnderman,room);if(spec.storm)validateStorm(spec.storm,room);if(spec.gear)validateGear(spec.gear,room);if(spec.workshop)validateWorkshop(spec.workshop,room);if(spec.dragon)validateDragon(spec.dragon,room);if(spec.nether)validateNether(spec.nether,room);
 // Discoveries are authored against actual stable colliders, never art alone.
 if(spec.exploration!==undefined){
  const e=spec.exploration;object(e,['appleTree','pig','hiddenPortalId','cart','ores','oresCompletionGateId','lockedPortals','fleePigs','redstone','enderman','villager','villagers','golem'],'exploration');const owned=new Set();
  const ownSolid=(id,label)=>{const q=map.geometry.find(g=>g.id===id);if(typeof id!=='string'||unsafe(id)||!q||!liveSolid(q)||q.motion||q.liftSpeed||owned.has(id)||(spec.sandIds||[]).includes(id)||(spec.destructibleIds||[]).includes(id))throw Error('Minecraft '+label+' needs a unique static solid');owned.add(id);return q;};
  if(e.appleTree){const a=e.appleTree;object(a,['branchId','x','y'],'apple tree');ownSolid(a.branchId,'apple branch');if(!finite(a.x,0,map.width-10)||!finite(a.y,0,map.height-10)||map.geometry.some(g=>liveSolid(g)&&overlap({x:a.x,y:a.y,w:10,h:10},g)))throw Error('Invalid Minecraft apple drop position');}
  if(e.pig){const q=e.pig;object(q,['id','x','y','gateId'],'pig');if(!e.appleTree||typeof q.id!=='string'||!q.id.length||q.id.length>100||unsafe(q.id)||ids.has(q.id)||!finite(q.x,0,map.width-26)||!finite(q.y,0,map.height-22)||map.geometry.some(g=>liveSolid(g)&&overlap({...q,w:26,h:22},g)))throw Error('Invalid Minecraft pig');ids.add(q.id);ownSolid(q.gateId,'pig gate');}
  if(e.fleePigs!==undefined){list(e.fleePigs,'flee pigs',16);for(const q of e.fleePigs){object(q,['id','x','y'],'flee pig');if(typeof q.id!=='string'||!q.id.length||q.id.length>100||unsafe(q.id)||ids.has(q.id)||!finite(q.x,0,map.width-26)||!finite(q.y,0,map.height-22)||map.geometry.some(g=>liveSolid(g)&&overlap({...q,w:26,h:22},g)))throw Error('Invalid Minecraft flee pig');ids.add(q.id);}}
  if(e.oresCompletionGateId!==undefined){ownSolid(e.oresCompletionGateId,'ore completion gate');if(!e.ores||e.ores.length<3)throw Error('Minecraft ore gate needs at least three ore discoveries');}
  if(e.lockedPortals!==undefined){list(e.lockedPortals,'locked portals',16);const seen=new Set();for(const q of e.lockedPortals){object(q,['portalId','gateId'],'locked portal');if(seen.has(q.portalId)||!map.objects.some(o=>o.id===q.portalId&&o.kind==='portal')||!([e.pig?.gateId,e.oresCompletionGateId].filter(Boolean).includes(q.gateId)))throw Error('Minecraft locked portal needs a unique real portal and an unlockable gate');seen.add(q.portalId);}}
  if(e.hiddenPortalId!==undefined&&(!e.pig||!map.objects.some(o=>o.id===e.hiddenPortalId&&o.kind==='portal')))throw Error('Minecraft hidden portal needs the pig gate and a real portal');
  if(e.cart){const q=e.cart;object(q,['geometryId','endX','speed'],'minecart');const g=ownSolid(q.geometryId,'minecart');if(!finite(q.endX,0,map.width-g.w)||q.endX===g.x||!finite(q.speed??1.2,.1,2.5)||g.w<24||g.w>96||g.h<8||g.h>24)throw Error('Invalid Minecraft minecart route');const swept={...g,x:Math.min(g.x,q.endX),w:Math.abs(g.x-q.endX)+g.w};if(map.geometry.some(other=>other.id!==g.id&&other.id!==e.enderman?.blockId&&liveSolid(other)&&overlap(swept,other)))throw Error('Minecraft minecart route crosses a solid');}
  if(e.ores!==undefined){list(e.ores,'ore discoveries',64);for(const q of e.ores){object(q,['id','coins'],'ore discovery');ownSolid(q.id,'ore discovery');if(q.coins!==undefined&&(!Number.isInteger(q.coins)||!finite(q.coins,1,10)))throw Error('Invalid Minecraft ore reward');}}
  const helper=(q,w,h,label)=>{if(typeof q.id!=='string'||!q.id.length||q.id.length>100||unsafe(q.id)||ids.has(q.id)||!finite(q.x,0,map.width-w)||!finite(q.y,0,map.height-h)||map.geometry.some(g=>liveSolid(g)&&overlap({...q,w,h},g))||!map.geometry.some(g=>liveSolid(g)&&q.x+w/2>=g.x&&q.x+w/2<=g.x+g.w&&Math.abs(q.y+h-g.y)<EPS))throw Error('Invalid or unsupported Minecraft '+label);ids.add(q.id);};
  if(e.enderman){
   const q=e.enderman;object(q,['id','x','y','blockId','targetX','targetY'],'enderman');helper(q,16,48,'enderman');const g=ownSolid(q.blockId,'enderman block'),c=e.cart&&map.geometry.find(g=>g.id===e.cart.geometryId),target={...g,x:q.targetX,y:q.targetY};
   if(!c||g.w!==16||g.h!==16||!finite(q.targetX,28,map.width-g.w)||!finite(q.targetY,32,map.height-g.h)||!overlap(g,{...c,x:Math.min(c.x,e.cart.endX),w:Math.abs(c.x-e.cart.endX)+c.w})||overlap(target,{...c,x:Math.min(c.x,e.cart.endX),w:Math.abs(c.x-e.cart.endX)+c.w})||!map.geometry.some(other=>other.id!==g.id&&liveSolid(other)&&horizontal(g,other)&&Math.abs(other.y-g.y-g.h)<EPS)||map.geometry.some(other=>other.id!==g.id&&liveSolid(other)&&overlap(target,other))||!map.geometry.some(other=>liveSolid(other)&&horizontal(target,other)&&Math.abs(other.y-target.y-target.h)<EPS))throw Error('Invalid Minecraft enderman block transfer');
   const arrival={x:q.targetX-28,y:q.targetY+g.h-48,w:16,h:48};if(map.geometry.some(other=>other.id!==g.id&&liveSolid(other)&&overlap(arrival,other))||!map.geometry.some(other=>liveSolid(other)&&horizontal(arrival,other)&&Math.abs(other.y-arrival.y-arrival.h)<EPS))throw Error('Invalid Minecraft enderman landing');
  }
  if(e.golem){const q=e.golem;object(q,['id','x','y','zombie'],'golem');helper(q,24,48,'golem');if(!e.cart||!q.zombie)throw Error('Golem needs rail threat');object(q.zombie,['id','x','y'],'rail zombie');helper(q.zombie,18,32,'rail zombie');}
  if(e.villagers!==undefined)list(e.villagers,'villagers',16);
  for(const q of [e.villager,...(e.villagers||[])].filter(Boolean)){object(q,['id','x','y','role'],'villager');if(q.role!==undefined&&!['resident','worker','farmer','trader'].includes(q.role))throw Error('Invalid Minecraft villager role');helper(q,16,24,'villager');}
  if(e.redstone){
   const q=e.redstone;object(q,['bridgeId','extendedWidth','cartRequired'],'redstone circuit');const g=ownSolid(q.bridgeId,'redstone bridge');
   if(!e.ores||e.ores.length<3||!finite(q.extendedWidth,g.w+16,1024)||g.x+q.extendedWidth>map.width||g.h<8||g.h>24||q.cartRequired!==undefined&&typeof q.cartRequired!=='boolean'||q.cartRequired&&!e.cart)throw Error('Invalid Minecraft redstone bridge circuit');
   if(map.geometry.some(other=>other.id!==g.id&&liveSolid(other)&&overlap({...g,w:q.extendedWidth},other)))throw Error('Minecraft redstone bridge route crosses a solid');
  }
 }
 // Visual records are plain, bounded, non-executable art metadata. They never
 // grant a collider, pickup, enemy, or portal; those remain explicit above.
 for(const key of ['scenery','labels','signs'])if(spec[key]!==undefined){list(spec[key],key,512);for(const q of spec[key]){
  object(q,key==='scenery'?['id','kind','x','y','w','h','scale','facing','color','text','variant']:['id','x','y','w','h','text'],'visual '+key);
  if(q.id!==undefined&&(typeof q.id!=='string'||!q.id.length||unsafe(q.id))||!Number.isFinite(q.x)||!Number.isFinite(q.y)||q.w!==undefined&&!finite(q.w,1,4096)||q.h!==undefined&&!finite(q.h,1,4096)||q.scale!==undefined&&!finite(q.scale,.1,8)||q.facing!==undefined&&![-1,1].includes(q.facing)||q.text!==undefined&&(typeof q.text!=='string'||q.text.length>240)||q.color!==undefined&&(typeof q.color!=='string'||!/^#[0-9a-f]{3,8}$/i.test(q.color))||q.kind!==undefined&&(typeof q.kind!=='string'||q.kind.length>40)||q.variant!==undefined&&(typeof q.variant!=='string'||q.variant.length>40))throw Error('Invalid Minecraft visual record');
  if(key==='scenery'&&['cow','sheep','llama'].includes(q.kind)){const [w,h]=q.kind==='cow'?[30,26]:q.kind==='sheep'?[26,22]:[22,38],body={x:q.x,y:q.y-h,w,h};if(map.geometry.some(g=>liveSolid(g)&&overlap(body,g))||!map.geometry.some(g=>liveSolid(g)&&q.x>=g.x&&q.x+w<=g.x+g.w&&Math.abs(q.y-g.y)<.01))throw Error('Minecraft farm animal requires clear grounded placement');}
 }}
}

export function createMinecraftController(room,{emit=()=>{},hurtPlayer=()=>{},rewardCoins=()=>{},restoreHealth=()=>{},grantHealthUpgrade=()=>false,tradeHealing=()=>({ok:false,reason:'poor'}),shopTransaction=tradeHealing,usePotion=()=>({ok:false,reason:'empty'}),inventory={}}={}){
 validateMinecraftRoom(room);if(!room.minecraft)return null;
 const spec=copy(room.minecraft),destructible=new Set(spec.destructibleIds||[]),sandIds=new Set(spec.sandIds||[]);
 let creepers,sand,effects,destroyed,lastTick=-1,currentTick=0,lastFallSound=-99,lastLandSound=-99,walkFrames=0,lastPortalSound=-999,paused=false,disposed=false,apple,pig,cart,ores,treeShake,mineLights,fleePigs,nearPortal,redstone,enderman,villager,villagers,golem,railZombie,lastVillagerSound,animals,capacityRewards,trade;
 const grotto=spec.grotto?createGrottoController(room,{emit,rewardCoins,restoreHealth,grantHealthUpgrade}):null;
 const gear=spec.gear?createGearController(room,{emit,restoreHealth,inventory}):null;
 const workshop=spec.workshop?createWorkshopController(room,{emit,inventory}):null;
 const defend=hit=>gear?.guardHit(hit)||{damage:hit.damage??1,parried:false,blocked:false};
 const wildEnderman=spec.wildEnderman?createWildEndermanController(room,{emit,hurtPlayer,defend}):null;
 const storm=spec.storm?createStormController(room,{emit,hurtPlayer,defend}):null;
 const dragon=spec.dragon?createDragonController(room,{emit,hurtPlayer,rewardCoins,defend}):null,nether=spec.nether?createNetherController(room,{emit,hurtPlayer,rewardCoins,defend,grantTrident:options=>{grantHealthUpgrade(room.roomId+':bastion');return gear?.grantTrident(options);}}):null;
 const discovery=spec.exploration||{};
 const shop=createVillageShop({inventory,transaction:shopTransaction,usePotion,onResult:result=>{const trader=villagers?.find(q=>q.role==='trader');if(trader&&result.item!=='use-potion')queueVillagerVoice(trader,result.ok?'mc-villager-success':'mc-villager-disagree',result.ok?'trade':'trade-declined',4);if(result.ok&&result.healed)gear?.notifyHealing(result.healed);diagnostic(result.item==='use-potion'?'potion-use-result':'villager-trade-result',{actorId:trader?.id,...result});}});
 const diagnostic=(event,data={})=>emit('minecraft',{event,roomId:room.roomId,tick:currentTick,...data});
 const sound=(event,options={})=>emit('sound',{event,...options});
 function reset(){disposed=false;trade=null;shop.reset();capacityRewards=[];animals=(spec.scenery||[]).filter(q=>['cow','sheep','llama'].includes(q.kind)).map((q,i)=>{const [w,h]=q.kind==='cow'?[30,26]:q.kind==='sheep'?[26,22]:[22,38];return {id:q.id||'farm-'+q.kind+'-'+i,kind:q.kind,x:q.x,y:q.y-h,w,h,homeX:q.x,facing:q.facing||1,state:'idle',age:0,speakTicks:0,cooldown:0,near:false};});grotto?.reset();wildEnderman?.reset();storm?.reset();gear?.reset();workshop?.reset();dragon?.reset();nether?.reset();creepers=(spec.creepers||[]).map(q=>({...creeperRule(q),vx:0,vy:0,state:'idle',fuse:0,flash:false,dead:false,grounded:false,support:null,age:0,hp:2,respawnTicks:0,hitFlash:0}));sand=new Map((spec.sandIds||[]).map(id=>{const q=room.map.geometry.find(q=>q.id===id);return [id,{id,x:q.x,y:q.y,w:q.w,h:q.h,vy:0,state:'stable',support:null,dead:false}];}));effects=[];destroyed=new Set();lastTick=-1;currentTick=0;lastFallSound=lastLandSound=-99;walkFrames=0;lastPortalSound=-999;paused=false;
  const a=discovery.appleTree;apple=a?{x:a.x,y:a.y,w:10,h:10,vy:0,state:'hanging'}:null;treeShake=0;mineLights=false;nearPortal=null;
  fleePigs=(discovery.fleePigs||[]).map(q=>({...q,w:26,h:22,vx:0,vy:0,facing:1,state:'idle',warning:0,age:0,dead:false,grounded:false,support:null}));
  pig=discovery.pig?{...discovery.pig,w:26,h:22,vx:0,vy:0,facing:1,state:'idle',sniffTicks:0,gateOpen:false,warning:0,age:0,dead:false,grounded:false,support:null}:null;
  const c=discovery.cart,g=c&&room.map.geometry.find(q=>q.id===c.geometryId);cart=c?{...c,x:g.x,y:g.y,w:g.w,h:g.h,dx:0,state:'waiting',age:0,...(discovery.redstone?.cartRequired?{cargo:'redstone-cell',delivered:false,deliveryTicks:0}:{})}:null;
  ores=(discovery.ores||[]).map(q=>{const g=room.map.geometry.find(g=>g.id===q.id);return {...q,coins:q.coins??1,x:g.x,y:g.y,w:g.w,h:g.h,used:false,bump:0};});
  const r=discovery.redstone,b=r&&room.map.geometry.find(q=>q.id===r.bridgeId);redstone=r?{...r,charge:0,required:ores.length,cartDelivered:false,powered:false,state:'waiting',progress:0,pulse:0,bridge:{id:b.id,x:b.x,y:b.y,w:b.w,h:b.h,baseWidth:b.w,extendedWidth:r.extendedWidth}}:null;
  const n=discovery.enderman,block=n&&room.map.geometry.find(q=>q.id===n.blockId);enderman=n?{...n,w:16,h:48,facing:-1,state:'idle',age:0,visible:true,cargo:null,block:{...copy(block),state:'source'}}:null;
  golem=discovery.golem?{...copy(discovery.golem),w:24,h:48,state:'idle',age:0,armLift:0,rose:false,poppyGiven:false,offerTicks:0,facing:-1}:null;railZombie=golem?{...copy(golem.zombie),w:18,h:32,vx:0,vy:0,state:'idle',dead:false,age:0,hitCooldown:0,grounded:true}:null;
  villagers=[discovery.villager,...(discovery.villagers||[])].filter(Boolean).map(q=>({...q,w:16,h:24,role:q.role||'resident',facing:-1,state:'idle',age:0,celebrateTicks:0,sawDelivery:false,sawBridge:false,sawSecret:false,greeted:false,voiceCooldown:0,speakTicks:0,voiceKind:null,pendingVoice:null,contactArmed:true,awayTicks:0,near:false,lookUp:false,poppy:false,grounded:true,warnedStormIds:[],relievedStormIds:[]}));villager=discovery.villager?villagers[0]:null;lastVillagerSound=-999;trade=villagers.some(q=>q.role==='trader')?shop.view():null;
 }
 reset();
 function filteredGeometry(geometry){return geometry.filter(q=>!destroyed.has(q.id)&&!destroyed.has(q.sourceId));}
 function lineVisible(a,b,geometry){
  const x=a.x+a.w/2,y=a.y+a.h/2,dx=b.x+b.w/2-x,dy=b.y+b.h/2-y,steps=Math.ceil(Math.max(Math.abs(dx),Math.abs(dy))/4);
  for(let n=1;n<steps;n++){const px=x+dx*n/steps,py=y+dy*n/steps;if(geometry.some(q=>liveSolid(q)&&px>q.x+EPS&&px<q.x+q.w-EPS&&py>q.y+EPS&&py<q.y+q.h-EPS))return false;}return true;
 }
 function advanceBody(q,geometry,kind='creeper'){
  const oldX=q.x,nextX=clamp(q.x+q.vx,0,room.map.width-q.w);q.x=nextX;
  for(const g of geometry)if(liveSolid(g)&&overlap(q,g)){if(q.vx>0&&oldX+q.w<=g.x+EPS)q.x=Math.min(q.x,g.x-q.w);else if(q.vx<0&&oldX>=g.x+g.w-EPS)q.x=Math.max(q.x,g.x+g.w);q.vx=0;}
  q.vy=Math.min(5,q.vy+.24);const oldBottom=q.y+q.h,newBottom=oldBottom+q.vy;
  const hit=geometry.filter(g=>liveSolid(g)&&horizontal(q,g)&&g.y>=oldBottom-EPS&&g.y<=newBottom+EPS).sort((a,b)=>a.y-b.y)[0];
  q.grounded=!!hit;q.support=hit?.id||null;if(hit){q.y=hit.y-q.h;q.vy=0;}else q.y+=q.vy;
  if(q.y>room.map.height+48){q.dead=true;q.state='fallen';diagnostic(kind+'-fell',{actorId:q.id});}
 }
 function explode(q,geometry,player){
  q.dead=true;q.state='exploded';q.fuse=0;q.flash=false;q.vx=q.vy=0;
  const x=q.x+q.w/2,y=q.y+q.h/2,removed=[];
  for(const g of geometry)if((destructible.has(g.id)||destructible.has(g.sourceId))&&distanceToRect(x,y,g)<=q.blastRadius){destroyed.add(g.id);if(g.sourceId&&destructible.has(g.sourceId))destroyed.add(g.sourceId);removed.push(g.id);if(sand.has(g.id))sand.get(g.id).dead=true;for(let n=0;n<4;n++)effects.push({kind:'block-debris',x:g.x+g.w*(n%2+.5)/2,y:g.y+g.h*(Math.floor(n/2)+.5)/2,w:4,h:4,vx:(n%2?1:-1)*(1.1+n*.2),vy:-2.2-Math.floor(n/2),age:0,life:36,color:sandIds.has(g.id)?'#d8c17a':'#8b8170'});}
  effects.push({kind:'explosion',id:q.id+'-blast',x:x-q.blastRadius,y:y-q.blastRadius,w:q.blastRadius*2,h:q.blastRadius*2,cx:x,cy:y,radius:q.blastRadius,age:0,life:24});
  const hit=player&&!player.dying&&distanceToRect(x,y,player)<=q.blastRadius&&lineVisible(q,player,geometry);
  const defense=hit?defend({player,sourceX:x,kind:'creeper-explosion',damage:1,reflectable:false}):null;diagnostic('creeper-exploded',{actorId:q.id,x,y,radius:q.blastRadius,destroyedIds:removed,playerHit:!!hit,...(defense?{damage:defense.damage,blocked:!!defense.blocked,parried:!!defense.parried}:{})});sound('mc-explosion');if(hit&&defense.damage>0)hurtPlayer({kind:'explosion',actorId:q.id,x,y,radius:q.blastRadius,damage:defense.damage});
  return filteredGeometry(geometry);
 }
 function stepSand(geometry,player){
  let started=0,landed=0;
  const active=[...sand.values()].filter(q=>!q.dead).sort((a,b)=>b.y-a.y||a.x-b.x);
  for(const q of active){
   const body=geometry.find(g=>g.id===q.id);if(!body){q.dead=true;continue;}body.mcSand=true;body.dx=body.dy=0;
   const oldY=q.y,oldBottom=q.y+q.h,obstacles=geometry.filter(g=>g.id!==q.id&&liveSolid(g));
   const support=obstacles.find(g=>horizontal(q,g)&&Math.abs(g.y-oldBottom)<EPS);
   if(support&&sand.get(support.id)?.state!=='falling'){q.vy=0;q.support=support.id;if(q.state==='falling'){q.state='settled';landed++;diagnostic('sand-settled',{actorId:q.id,x:q.x,y:q.y,supportId:support.id});}body.y=q.y;continue;}
   if(q.state!=='falling'){q.state='falling';started++;diagnostic('sand-started',{actorId:q.id,x:q.x,y:q.y});}
   q.support=null;q.vy=Math.min(6,q.vy+.22);const nextBottom=oldBottom+q.vy;
   const hit=obstacles.filter(g=>horizontal(q,g)&&g.y>=oldBottom-EPS&&g.y<=nextBottom+EPS).sort((a,b)=>a.y-b.y)[0];
   if(hit){q.y=hit.y-q.h;q.support=hit.id;const movingSupport=sand.get(hit.id);if(movingSupport?.state==='falling'){q.vy=movingSupport.vy;q.state='falling';}else{q.vy=0;q.state='settled';landed++;diagnostic('sand-settled',{actorId:q.id,x:q.x,y:q.y,supportId:hit.id});effects.push({kind:'sand-dust',x:q.x-4,y:q.y+q.h-4,w:q.w+8,h:8,age:0,life:18});}}else q.y+=q.vy;
   body.y=q.y;body.dy=q.y-oldY;body.mcSand=true;
   // Falling onto a head is a genuine swept hazard. A rider on top instead
   // uses the same native moving-solid dy contact used by ordinary platforms.
   if(player&&!player.dying&&horizontal(q,player)&&oldBottom<=player.y+EPS&&q.y+q.h>=player.y-EPS&&body.dy>0)hurtPlayer({kind:'falling-sand',actorId:q.id});
   if(q.y>room.map.height+32){q.dead=true;destroyed.add(q.id);diagnostic('sand-lost',{actorId:q.id});}
  }
  if(started&&currentTick-lastFallSound>=12){sound('mc-sand');lastFallSound=currentTick;}
  if(landed&&currentTick-lastLandSound>=12){sound('mc-sand-settle');lastLandSound=currentTick;}
  return filteredGeometry(geometry);
 }
 function burst(kind,x,y,color,count=8){for(let n=0;n<count;n++)effects.push({kind,x:x+(n%3-1)*3,y:y+Math.floor(n/3)*2,w:3,h:3,vx:(n%2?1:-1)*(.4+n*.12),vy:-1.5-(n%3)*.4,age:0,life:kind==='heart'?48:34,color});}
 function allowsObject(id){if(dragon?.allowsObject(id)===false||nether?.allowsObject(id)===false)return false;return (id!==discovery.hiddenPortalId||!!pig?.gateOpen)&&!(discovery.lockedPortals||[]).some(q=>q.portalId===id&&!destroyed.has(q.gateId));}
 function syncPlayer(player){carriedApple(player);nearPortal=player&&!player.dead&&!player.dying?room.map.objects.filter(q=>q.kind==='portal'&&allowsObject(q.id)&&distanceToRect(player.x+player.w/2,player.y+player.h/2,q)<=30).map(q=>({id:q.id,x:q.x,y:q.y,w:q.w,h:q.h}))[0]||null:null;}
 function carriedApple(player){if(apple?.state==='carried'&&player){apple.x=player.x+(player.facing<0?-7:player.w-1);apple.y=player.y+Math.max(2,player.h*.36);}}
 // Preserve one owned block identity across pickup, teleport and replacement.
 function syncHelperBlock(geometry){
  if(!enderman)return geometry;
  const block=enderman.block,others=geometry.filter(q=>q.id!==block.id&&q.sourceId!==block.id);
  if(block.state==='carried')return others;
  const source=room.map.geometry.find(q=>q.id===block.id);return [...others,{...copy(source),x:block.x,y:block.y,dx:0,dy:0,mcEndermanBlock:true}];
 }
 function stepHelpers(geometry,player,actors){
  const q=enderman;if(!q)return geometry;q.age++;
  const block=q.block,target={x:q.targetX,y:q.targetY,w:block.w,h:block.h},arrival={x:q.targetX-28,y:q.targetY+block.h-q.h,w:q.w,h:q.h};
  const occupied=body=>[player,...actors,pig,...fleePigs,...creepers,...villagers].some(a=>a&&!a.dead&&!a.dying&&overlap(a,body))||geometry.some(g=>g.id!==block.id&&liveSolid(g)&&overlap(g,body));
  if(q.state==='idle'&&cart&&['riding','blocked'].includes(cart.state)){
   const distance=cart.endX>cart.x?block.x-cart.x-cart.w:cart.x-block.x-block.w;
   if(distance<=28&&distance>=-EPS){q.state='lifting';q.age=0;diagnostic('enderman-lift-started',{actorId:q.id,blockId:block.id});sound('mc-enderman-lift');}
  }else if(q.state==='lifting'&&q.age>=40){
   block.state='carried';q.cargo='dirt';q.state='teleporting';q.age=0;q.visible=false;diagnostic('enderman-block-lifted',{actorId:q.id,blockId:block.id});burst('ore-spark',q.x+q.w/2,q.y+24,'#be86e6',12);sound('mc-enderman-teleport');geometry=syncHelperBlock(geometry);
  }else if(q.state==='teleporting'&&q.age>=12&&!occupied(arrival)){
   q.x=arrival.x;q.y=arrival.y;q.facing=1;q.visible=true;q.state='carrying';q.age=0;diagnostic('enderman-teleported',{actorId:q.id,x:q.x,y:q.y});sound('mc-enderman-teleport');burst('ore-spark',q.x+q.w/2,q.y+24,'#be86e6',12);
  }else if(['carrying','placing'].includes(q.state)&&q.age>=24){
   if(occupied(target)){q.state='placing';}
   else{block.x=target.x;block.y=target.y;block.state='placed';q.cargo=null;q.state='placed';q.age=0;geometry=syncHelperBlock(geometry);diagnostic('enderman-block-placed',{actorId:q.id,blockId:block.id,x:block.x,y:block.y});sound('mc-sand-settle');burst('sand-dust',block.x+block.w/2,block.y+block.h-2,'#9b7653',5);}
  }else if(q.state==='placed'&&q.age>=24){q.visible=false;q.state='departed';q.age=0;burst('ore-spark',q.x+q.w/2,q.y+24,'#be86e6',10);}
  return geometry;
 }
 function stepGolem(geometry,player){
  if(!golem||!railZombie)return;const q=golem,z=railZombie;q.age++;z.age++;if(z.hitCooldown)z.hitCooldown--;
  if(z.state==='launched'){q.armLift=Math.max(0,1-q.age/20);if(q.age>20&&q.x<discovery.golem.x){const next={...q,x:Math.min(discovery.golem.x,q.x+.7)};if(!geometry.some(g=>liveSolid(g)&&overlap(next,g))&&!(player&&overlap(next,player)))q.x=next.x;}const oldX=z.x;z.x=clamp(z.x+z.vx,0,room.map.width-z.w);for(const g of geometry)if(liveSolid(g)&&overlap(z,g)){if(z.vx<0&&oldX>=g.x+g.w-EPS)z.x=g.x+g.w;else if(z.vx>0&&oldX+z.w<=g.x+EPS)z.x=g.x-z.w;z.vx=0;}z.vy=Math.min(5,z.vy+.24);const oldY=z.y,nextY=z.y+z.vy;let hit=null;if(z.vy<0){hit=geometry.filter(g=>liveSolid(g)&&horizontal(z,g)&&g.y+g.h<=oldY+EPS&&g.y+g.h>=nextY-EPS).sort((a,b)=>b.y+b.h-a.y-a.h)[0];z.y=hit?hit.y+hit.h:nextY;}else{hit=geometry.filter(g=>liveSolid(g)&&horizontal(z,g)&&g.y>=oldY+z.h-EPS&&g.y<=nextY+z.h+EPS).sort((a,b)=>a.y-b.y)[0];z.y=hit?hit.y-z.h:nextY;if(hit){z.dead=true;z.state='defeated';burst('sand-dust',z.x+9,z.y+z.h,'#a0a18f',7);diagnostic('rail-zombie-defeated',{actorId:z.id,supportId:hit.id});}}if(hit)z.vy=0;if(z.y>room.map.height+48){z.dead=true;z.state='defeated';}return;}
  if(z.dead){
   const offer=!!cart?.delivered&&!q.poppyGiven;
   if(offer&&!q.rose){diagnostic('golem-offers-poppy',{actorId:q.id});if(playerNear(q,player,176,geometry))sound('mc-golem-rose',{volume:.7});}
   q.state=offer?'rose':'recover';q.rose=offer;q.armLift=0;const desired=discovery.golem.x;
   if(q.x<desired){const next={...q,x:Math.min(desired,q.x+.7)};if(!geometry.some(g=>liveSolid(g)&&overlap(next,g))&&!(player&&overlap(next,player)))q.x=next.x;}
   // A flower changes hands only when both friends really stand together and
   // the player can witness it. No remote reward, invented support or collider.
   const recipient=villagers.filter(v=>!v.poppy&&Math.hypot(v.x+8-q.x-12,v.y+24-q.y-48)<=64&&lineVisible(q,v,geometry)).sort((a,b)=>Math.abs(a.x-q.x)-Math.abs(b.x-q.x))[0];
   if(offer&&recipient&&playerNear(q,player,176,geometry)){q.facing=Math.sign(recipient.x+8-q.x-12)||q.facing;q.offerTicks++;if(q.offerTicks>=48){q.poppyGiven=true;q.rose=false;q.state='recover';recipient.poppy=true;recipient.celebrateTicks=90;queueVillagerVoice(recipient,'mc-villager-success','poppy',3);burst('heart',recipient.x+8,recipient.y-8,'#efaaa2',3);diagnostic('golem-poppy-received',{actorId:q.id,villagerId:recipient.id});}}
   return;
  }
  if(q.state==='idle'&&cart?.state==='blocked'){q.state='approach';q.age=0;diagnostic('golem-protect-worker',{actorId:q.id,targetId:z.id});for(const v of villagers)if(Math.abs(v.x-q.x)<160&&playerNear(v,player,176,geometry))queueVillagerVoice(v,'mc-villager-disagree','rail-threat',2);}
  if(q.state==='approach'){const dx=z.x+z.w/2-q.x-q.w/2;q.facing=Math.sign(dx)||-1;const next={...q,x:q.x+q.facing*.65};if(Math.abs(dx)<=34&&lineVisible(q,z,geometry)){q.state='windup';q.age=0;}else if(Math.abs(dx)>34&&!geometry.some(g=>liveSolid(g)&&overlap(next,g))&&geometry.some(g=>liveSolid(g)&&next.x>=g.x&&next.x+next.w<=g.x+g.w&&Math.abs(next.y+next.h-g.y)<1))q.x=next.x;}
  if(q.state==='windup'){q.armLift=-Math.min(1,q.age/18);if(q.age>=18){if(Math.abs(z.x+z.w/2-q.x-q.w/2)>34||!lineVisible(q,z,geometry)){q.state='approach';q.age=0;q.armLift=0;return;}q.state='uppercut';q.age=0;q.armLift=1;z.state='launched';z.age=0;z.vx=q.facing*2.2;z.vy=-5.8;diagnostic('golem-uppercut',{actorId:q.id,targetId:z.id,x:z.x,y:z.y,vx:z.vx,vy:z.vy});sound('mc-golem-uppercut');burst('ore-spark',z.x+9,z.y+12,'#d6d9bf',9);}}
  if(q.state==='uppercut'){q.armLift=Math.max(0,1-q.age/20);if(q.age>24){q.state='recover';q.armLift=0;}}
  if(player&&!player.dead&&!player.dying&&z.state!=='launched'&&!z.hitCooldown&&overlap(player,z)){const d=defend({player,sourceX:z.x+9,kind:'rail-zombie',damage:1});if(d.damage>0)hurtPlayer({kind:'rail-zombie',actorId:z.id,damage:d.damage});z.hitCooldown=60;}
 }
 // Voices belong to the visible actor that makes them. Shared spacing prevents
 // a village chorus; per-actor contact latches prevent a held overlap grunting.
 function playerNear(q,player,radius,geometry){return !!(player&&!player.dead&&!player.dying&&distanceToRect(player.x+player.w/2,player.y+player.h/2,q)<=radius&&lineVisible(q,player,geometry));}
 function queueVillagerVoice(q,event,context,priority=1){
  if(!q.pendingVoice||priority>=q.pendingVoice.priority)q.pendingVoice={event,context,priority,expires:currentTick+180};
  if(priority>=3)q.voiceCooldown=Math.min(q.voiceCooldown,60);
 }
 function stepVillagers(geometry,player){
  const weather=storm?.view();
  for(const q of villagers){
   q.age++;if(q.voiceCooldown>0)q.voiceCooldown--;if(q.speakTicks>0)q.speakTicks--;if(q.celebrateTicks>0)q.celebrateTicks--;
   const near=playerNear(q,player,160,geometry),wasNear=q.near;q.near=near;
   const touching=near&&overlap(q,player),away=q.awayTicks;if(near)q.awayTicks=0;else q.awayTicks++;
   if(near&&!wasNear&&(!q.greeted||away>=600)){q.greeted=true;queueVillagerVoice(q,'mc-villager-greet',away>=600?'return':'approach');}
   if(!near||distanceToRect(player.x+player.w/2,player.y+player.h/2,q)>40)q.contactArmed=true;
   if(touching&&q.contactArmed){q.contactArmed=false;queueVillagerVoice(q,'mc-villager-disagree','contact',2);yieldPig(q,player,geometry);}
   if(cart?.delivered&&!q.sawDelivery){q.sawDelivery=true;diagnostic('villager-cell-received',{actorId:q.id});if(Math.abs(q.x-cart.endX)<224){q.celebrateTicks=100;burst('heart',q.x+8,q.y-8,'#e6bb69',3);if(near)queueVillagerVoice(q,'mc-villager-success','cell-delivery',3);}}
   if(redstone?.state==='extended'&&!q.sawBridge){q.sawBridge=true;diagnostic('villager-bridge-celebration',{actorId:q.id});if(Math.abs(q.x-redstone.bridge.x)<256){q.celebrateTicks=120;burst('heart',q.x+8,q.y-8,'#e6bb69',4);if(near)queueVillagerVoice(q,'mc-villager-success','bridge',3);}}
   if(near&&pig?.gateOpen&&!q.sawSecret){q.sawSecret=true;q.celebrateTicks=80;queueVillagerVoice(q,'mc-villager-success','pig-secret',3);}
   for(const threat of weather?.zombies||[]){
    const local=Math.hypot(threat.x+9-q.x-8,threat.y+16-q.y-12)<=176&&lineVisible(q,threat,geometry);
    if(near&&local&&!threat.dead&&Math.abs(threat.vx||0)>0&&!q.warnedStormIds.includes(threat.id)){q.warnedStormIds.push(threat.id);queueVillagerVoice(q,'mc-villager-disagree','storm-threat',3);diagnostic('villager-storm-warning',{actorId:q.id,targetId:threat.id});}
    if(threat.dead&&local&&!q.relievedStormIds.includes(threat.id)){q.relievedStormIds.push(threat.id);if(near){const channeling=weather.lightning.some(flash=>flash.targetId===threat.id);q.celebrateTicks=100;queueVillagerVoice(q,'mc-villager-success',channeling?'channeling-rescue':'storm-rescue',4);burst('heart',q.x+8,q.y-8,'#efaaa2',3);diagnostic('villager-storm-relief',{actorId:q.id,targetId:threat.id,channeling});}}
   }
   if(q.pendingVoice&&(q.pendingVoice.expires<currentTick||!near))q.pendingVoice=null;
   if(q.pendingVoice&&near&&!q.voiceCooldown&&currentTick-lastVillagerSound>=60){
    const voice=q.pendingVoice;q.pendingVoice=null;q.voiceCooldown=150;q.speakTicks=voice.event==='mc-villager-disagree'?46:36;q.voiceKind=voice.event;lastVillagerSound=currentTick;
    const dx=q.x+8-player.x-player.w/2,distance=distanceToRect(player.x+player.w/2,player.y+player.h/2,q);
    sound(voice.event,{actorId:q.id,context:voice.context,volume:clamp(1-distance/240,.38,.9),pan:clamp(dx/220,-.65,.65)});diagnostic(voice.event==='mc-villager-greet'?'villager-greet':'villager-voice',{actorId:q.id,context:voice.context,voice:voice.event});
   }
   q.state=q.celebrateTicks?'celebrate':q.speakTicks&&q.voiceKind==='mc-villager-disagree'?'react':['worker','farmer'].includes(q.role)&&!q.near?'work':cart&&['riding','blocked'].includes(cart.state)&&Math.abs(q.x-cart.x)<224?'watch':'idle';
   const target=q.near?player:q.state==='watch'?cart:q.poppy&&golem?golem:null;
   if(target)q.facing=Math.sign(target.x+target.w/2-q.x-q.w/2)||q.facing;
   q.lookUp=!!(q.near&&player.y+player.h<q.y+6);
  }
 }
 // The moving edge stops before bodies instead of materializing inside them.
 function stepRedstone(geometry,player,actors){
  if(!redstone)return;
  const r=redstone,b=r.bridge,body=geometry.find(q=>q.id===b.id);if(!body)return;
  r.charge=ores.filter(q=>q.used).length;r.cartDelivered=!!cart?.delivered;if(r.pulse>0)r.pulse--;
  if(!r.powered&&r.charge===r.required&&(!r.cartRequired||r.cartDelivered)){
   r.powered=true;r.state='extending';r.pulse=60;diagnostic('redstone-powered',{bridgeId:b.id,charge:r.charge,cartDelivered:r.cartDelivered});sound('mc-mine-lights');
   burst('ore-spark',b.x+b.baseWidth-4,b.y-4,'#f56b55',12);
  }
  if(r.powered&&b.w<r.extendedWidth){
   const nextWidth=Math.min(r.extendedWidth,b.w+2),edge={x:b.x+b.w,y:b.y,w:nextWidth-b.w,h:b.h};
   const bodies=[player,...actors,pig,...fleePigs,...creepers,enderman,...villagers].filter(q=>q&&!q.dead&&!q.dying&&q.visible!==false);
   const blocked=bodies.some(q=>overlap(edge,q))||geometry.some(q=>q.id!==b.id&&liveSolid(q)&&overlap(edge,q));
   if(blocked){if(r.state!=='blocked')diagnostic('redstone-bridge-blocked',{bridgeId:b.id});r.state='blocked';}
   else{b.w=nextWidth;r.state=b.w===r.extendedWidth?'extended':'extending';
    if(r.state==='extended'){if(!(inventory.healthUpgrades||[]).includes(room.roomId+':bridge'))capacityRewards.push({id:room.roomId+':bridge',kind:'heart-container',x:b.x+24,y:b.y-12,w:12,h:12,age:0,collected:false});r.pulse=45;diagnostic('redstone-bridge-extended',{bridgeId:b.id,x:b.x,y:b.y,w:b.w});sound('mc-cart-stop');burst('ore-spark',b.x+b.w-4,b.y-3,'#f7b26a',8);}
   }
  }
  r.progress=(b.w-b.baseWidth)/(r.extendedWidth-b.baseWidth);body.w=b.w;body.dx=body.dy=0;body.mcRedstoneBridge=true;body.mcPowered=r.powered;
 }
 // Friendly pigs yield to a player who walks into them. They are never a
 // player collider, and can only sidestep onto real support through clear space.
 function yieldPig(q,player,geometry){
  if(!q.grounded||!player||player.dead||player.dying||!overlap(q,player)||Math.abs(q.y+q.h-player.y-player.h)>24)return;
  const positions=[player.x-q.w-5,player.x+player.w+5].sort((a,b)=>Math.abs(a-q.x)-Math.abs(b-q.x));
  for(const x of positions){
   if(x<0||x+q.w>room.map.width)continue;
   const swept={...q,x:Math.min(x,q.x),w:q.w+Math.abs(x-q.x)},candidate={...q,x};
   if(geometry.some(g=>liveSolid(g)&&overlap(swept,g)))continue;
   if(!geometry.some(g=>liveSolid(g)&&candidate.x+candidate.w/2>=g.x&&candidate.x+candidate.w/2<=g.x+g.w&&Math.abs(g.y-candidate.y-candidate.h)<1))continue;
   q.facing=Math.sign(x-q.x)||q.facing;q.x=x;q.vx=0;return;
  }
 }
 function stepDiscoveries(geometry,player,actors=[]){
  const livePlayer=player&&!player.dead&&!player.dying;
  if(treeShake>0)treeShake--;
  if(apple?.state==='hanging'&&livePlayer&&player.headHit===discovery.appleTree.branchId){apple.state='falling';treeShake=24;diagnostic('apple-dropped',{branchId:discovery.appleTree.branchId});sound('mc-apple-drop');burst('leaf-burst',apple.x,apple.y,'#7aa541');}
  if(apple&&['falling','resting'].includes(apple.state)){
   apple.vy=Math.min(4.5,apple.vy+.18);const bottom=apple.y+apple.h;
   const support=geometry.filter(g=>liveSolid(g)&&horizontal(apple,g)&&g.y>=bottom-EPS&&g.y<=bottom+apple.vy+EPS).sort((a,b)=>a.y-b.y)[0];
   if(support){apple.y=support.y-apple.h;apple.vy=0;apple.state='resting';}else{apple.y+=apple.vy;apple.state='falling';}
   if(livePlayer&&overlap(apple,player)){apple.state='carried';apple.vy=0;diagnostic('apple-collected');sound('mc-apple-pickup');burst('heart',player.x+player.w/2,player.y-8,'#e896a3',3);}
   if(apple.y>room.map.height+24)apple.state='lost';
  }
  carriedApple(player);
  geometry=stepHelpers(geometry,player,actors);stepGolem(geometry,player);
  if(cart){const body=geometry.find(q=>q.id===cart.geometryId);if(body){cart.age++;cart.dx=0;if(cart.deliveryTicks>0)cart.deliveryTicks--;
   if(cart.state==='waiting'&&livePlayer&&player.grounded&&player.support===body.id){cart.state='riding';diagnostic('cart-started',{actorId:body.id});sound('mc-cart-start');}
   if(['riding','blocked'].includes(cart.state)){
    const old=cart.x,dir=Math.sign(cart.endX-cart.x),candidate={...cart,x:cart.x+dir*Math.min(cart.speed??1.2,Math.abs(cart.endX-cart.x))};
    for(const g of geometry)if(g.id!==body.id&&liveSolid(g)&&overlap(candidate,g))candidate.x=dir>0?Math.min(candidate.x,g.x-cart.w):Math.max(candidate.x,g.x+g.w);
    if(railZombie&&!railZombie.dead&&overlap(candidate,railZombie))candidate.x=dir>0?Math.min(candidate.x,railZombie.x-cart.w):Math.max(candidate.x,railZombie.x+railZombie.w);
    cart.x=candidate.x;cart.dx=cart.x-old;
    if(!cart.dx&&cart.x!==cart.endX){if(cart.state!=='blocked')diagnostic('cart-blocked',{actorId:body.id});cart.state='blocked';}else cart.state='riding';
    if(cart.x===cart.endX){cart.state='arrived';diagnostic('cart-arrived',{actorId:body.id});sound('mc-cart-stop');if(cart.cargo){cart.cargo=null;cart.delivered=true;cart.deliveryTicks=60;redstone.pulse=60;diagnostic('redstone-cell-delivered',{actorId:body.id,bridgeId:redstone.bridgeId});burst('ore-spark',cart.x+cart.w-4,cart.y-4,'#f66d55',10);}}
   }
   if(cart.state==='riding'&&currentTick%20===0)sound('mc-cart-rattle');body.x=cart.x;body.dx=cart.dx;body.dy=0;body.mcCart=true;
  }}
  for(const q of ores){if(q.bump>0)q.bump--;const body=geometry.find(g=>g.id===q.id);if(!body)continue;
   if(!q.used&&livePlayer&&player.headHit===q.id){q.used=true;q.bump=18;rewardCoins(q.coins);diagnostic('ore-discovered',{actorId:q.id,coins:q.coins});sound('mc-ore');burst('ore-spark',q.x+q.w/2,q.y,'#a6eecc');effects.push({kind:'reward-coin',x:q.x+q.w/2-4,y:q.y-12,w:8,h:12,vx:0,vy:-2,age:0,life:38});}
   body.mcOreUsed=q.used;
  }
  if(!mineLights&&ores.filter(q=>q.used).length>=(redstone?.required??3)){mineLights=true;if(discovery.oresCompletionGateId){const gate=geometry.find(q=>q.id===discovery.oresCompletionGateId);destroyed.add(discovery.oresCompletionGateId);if(gate)burst('ore-spark',gate.x+gate.w/2,gate.y+gate.h/2,'#bdecd0',16);geometry=filteredGeometry(geometry);diagnostic('ore-shortcut-opened',{gateId:discovery.oresCompletionGateId,portalIds:(discovery.lockedPortals||[]).filter(q=>q.gateId===discovery.oresCompletionGateId).map(q=>q.portalId)});}diagnostic('mine-lights-lit');if(!redstone)sound('mc-mine-lights');for(const q of ores)burst('ore-spark',q.x+q.w/2,q.y-12,'#ffde84',5);}
  if(pig&&!pig.dead){pig.age++;if(pig.warning>0)pig.warning--;const danger=creepers.filter(q=>!q.dead&&q.state==='fuse').map(q=>({q,d:distanceToRect(q.x+q.w/2,q.y+q.h/2,pig)})).filter(({q,d})=>d<q.blastRadius+64).sort((a,b)=>a.d-b.d)[0];
   if(danger){if(pig.state!=='flee'){diagnostic('pig-fled',{actorId:pig.id,creeperId:danger.q.id});sound('mc-pig-scared');}pig.state='flee';pig.warning=30;pig.sniffTicks=0;pig.vx=(Math.sign(pig.x+pig.w/2-danger.q.x-danger.q.w/2)||-1)*1.8;}
   else if(pig.state==='celebrate'&&pig.celebrateTicks>0){pig.celebrateTicks--;pig.vx=0;}
   else if(livePlayer&&apple?.state==='carried'){
    const gate=geometry.find(q=>q.id===pig.gateId),nearGate=gate&&!pig.gateOpen&&distanceToRect(player.x+player.w/2,player.y+player.h/2,gate)<=32&&distanceToRect(pig.x+pig.w/2,pig.y+pig.h/2,gate)<=50&&Math.abs(player.y+player.h-pig.y-pig.h)<32;
    if(nearGate){pig.state='sniff';pig.vx=0;pig.facing=Math.sign(gate.x+gate.w/2-pig.x-pig.w/2)||1;pig.sniffTicks++;
     if(pig.sniffTicks===1)sound('mc-pig');
     if(pig.sniffTicks>=45){pig.gateOpen=true;pig.state='celebrate';pig.celebrateTicks=70;destroyed.add(pig.gateId);apple.state='given';burst('leaf-burst',gate.x+gate.w/2,gate.y+gate.h/2,'#75a34a',14);burst('heart',pig.x+pig.w/2,pig.y-10,'#f7a7b5',5);diagnostic('pig-secret-opened',{actorId:pig.id,gateId:pig.gateId,portalId:discovery.hiddenPortalId});sound('mc-secret');geometry=filteredGeometry(geometry);}
    }else{pig.sniffTicks=0;const dx=player.x+player.w/2-pig.x-pig.w/2;const space=(pig.w+player.w)/2+14;pig.vx=Math.abs(dx)>space?Math.sign(dx)*Math.min(.88,Math.abs(dx)-space):0;pig.state=pig.vx?'follow':'idle';}
   }else{pig.sniffTicks=0;pig.vx=0;pig.state='idle';}
   if(pig.vx){pig.facing=Math.sign(pig.vx);const front=pig.vx>0?pig.x+pig.w+2:pig.x-2;if(pig.grounded&&!geometry.some(g=>liveSolid(g)&&front>=g.x&&front<=g.x+g.w&&g.y>=pig.y+pig.h-1&&g.y<=pig.y+pig.h+10))pig.vx=0;}
   advanceBody(pig,geometry,'pig');yieldPig(pig,player,geometry);
  }
  for(const q of fleePigs){if(q.dead)continue;q.age++;if(q.warning>0)q.warning--;const danger=creepers.filter(c=>!c.dead&&c.state==='fuse'&&distanceToRect(c.x+c.w/2,c.y+c.h/2,q)<140).sort((a,b)=>Math.abs(a.x-q.x)-Math.abs(b.x-q.x))[0];
   if(danger){if(q.state!=='flee'){diagnostic('pig-fled',{actorId:q.id,creeperId:danger.id});sound('mc-pig-scared');}q.state='flee';q.warning=30;q.vx=(Math.sign(q.x+q.w/2-danger.x-danger.w/2)||-1)*1.8;}
   else{q.vx=0;q.state='idle';}
   if(q.vx){q.facing=Math.sign(q.vx);const front=q.vx>0?q.x+q.w+2:q.x-2;if(q.grounded&&!geometry.some(g=>liveSolid(g)&&front>=g.x&&front<=g.x+g.w&&g.y>=q.y+q.h-1&&g.y<=q.y+q.h+10))q.vx=0;}
   advanceBody(q,geometry,'pig');yieldPig(q,player,geometry);
  }
  stepRedstone(geometry,player,actors);stepVillagers(geometry,player);syncPlayer(player);return geometry;
 }
 function stepAnimals(player,geometry){for(const q of animals){q.age++;q.speakTicks=Math.max(0,q.speakTicks-1);q.cooldown=Math.max(0,q.cooldown-1);const near=player&&!player.dead&&!player.dying&&Math.abs(player.x+player.w/2-q.x-q.w/2)<88&&Math.abs(player.y+player.h-(q.y+q.h))<48&&lineVisible(q,player,geometry);if(near&&!q.near&&!q.cooldown){q.speakTicks=30;q.cooldown=300;sound('mc-'+q.kind);diagnostic('farm-animal-greet',{actorId:q.id,kind:q.kind});}q.near=!!near;let dx=0;if(near){q.facing=Math.sign(player.x-q.x)||q.facing;q.state='look';if(Math.abs(player.x+player.w/2-q.x-q.w/2)<28)dx=-q.facing*.22;}else{q.state=q.age%240<150?'graze':'wander';if(q.state==='wander'){q.facing=q.age%480<240?1:-1;dx=q.facing*.13;}}const next={...q,x:Math.max(q.homeX-20,Math.min(q.homeX+20,q.x+dx))};const supported=geometry.some(g=>liveSolid(g)&&next.x>=g.x&&next.x+next.w<=g.x+g.w&&Math.abs(q.y+q.h-g.y)<.01);if(supported&&!geometry.some(g=>liveSolid(g)&&overlap(next,g))&&!(player&&overlap(next,player)))q.x=next.x;}}
 const encounter={rangedTargets(){return [...creepers.filter(q=>!q.dead).map(q=>({id:q.id,kind:'creeper',x:q.x,y:q.y,w:q.w,h:q.h})),...(wildEnderman?.rangedTargets?.()||[])];},meleeTargets(){return this.rangedTargets();},receiveRangedHit(hit){const q=creepers.find(q=>q.id===hit.targetId&&!q.dead);if(!q)return wildEnderman?.receiveRangedHit?.(hit)||false;if(!['sword','loyalty-trident'].includes(hit.kind))return false;q.hp=Math.max(0,q.hp-(hit.kind==='sword'?.5:1));q.hitFlash=12;sound('mc-hurt');diagnostic('creeper-weapon-hit',{actorId:q.id,weapon:hit.kind,hp:q.hp});if(!q.hp){q.dead=true;q.state='defeated';q.fuse=0;q.flash=false;q.respawnTicks=[...destructible].some(id=>!destroyed.has(id))?180:0;sound('mc-fuse-stop');for(const other of creepers)if(other!==q&&!other.dead&&other.state==='fuse')sound('mc-fuse',{duration:other.fuse/60});burst('block-debris',q.x+q.w/2,q.y+q.h/2,'#79a85e',12);diagnostic('creeper-defeated',{actorId:q.id,replacementTicks:q.respawnTicks});}return true;}};
 function step({tick,input={},player,geometry=[],actors=[]}={}){
  if(paused)return {geometry:syncHelperBlock(filteredGeometry(geometry))};const next=Number.isInteger(tick)?tick:lastTick+1;if(next===lastTick)return {geometry:syncHelperBlock(filteredGeometry(geometry))};lastTick=currentTick=next;
  effects=effects.filter(q=>++q.age<q.life);for(const q of effects)if(['block-debris','leaf-burst','heart','ore-spark','reward-coin'].includes(q.kind)){q.x+=q.vx;q.y+=q.vy;q.vy+=q.kind==='heart'?.025:.12;}
  let live=syncHelperBlock(filteredGeometry(geometry));
  gear?.prepareGuard({tick:currentTick,input,player});
  for(const q of creepers){if(q.dead){if(q.state==='defeated'&&q.respawnTicks>0&&--q.respawnTicks===0){const source=spec.creepers.find(a=>a.id===q.id),spawn={...q,x:source.x,y:source.y};if([...destructible].some(id=>!destroyed.has(id))&&!live.some(g=>liveSolid(g)&&overlap(spawn,g))&&!(player&&overlap(spawn,player))){Object.assign(q,spawn,{dead:false,hp:2,state:'idle',fuse:0,flash:false,vx:0,vy:0});burst('ore-spark',q.x+q.w/2,q.y+q.h/2,'#9ccb76',8);diagnostic('creeper-replaced',{actorId:q.id});}else if([...destructible].some(id=>!destroyed.has(id)))q.respawnTicks=30;}continue;}q.hitFlash=Math.max(0,(q.hitFlash||0)-1);q.age++;const livePlayer=player&&!player.dead&&!player.dying;
   if(q.state==='fuse'){q.vx=0;advanceBody(q,live);if(q.dead)continue;const distance=livePlayer?Math.hypot(player.x+player.w/2-q.x-q.w/2,player.y+player.h/2-q.y-q.h/2):Infinity;if(!livePlayer||distance>96||!lineVisible(q,player,live)){q.state='idle';q.fuse=0;q.flash=false;diagnostic('creeper-disarmed',{actorId:q.id,reason:!livePlayer?'target-lost':distance>96?'distance':'occluded'});sound('mc-fuse-stop');for(const other of creepers)if(other!==q&&!other.dead&&other.state==='fuse')sound('mc-fuse',{duration:other.fuse/60});continue;}q.fuse--;q.flash=Math.floor((q.fuseTicks-q.fuse)/Math.max(2,Math.ceil(q.fuse/14)))%2===1;if(q.fuse<=0)live=explode(q,live,player);continue;}
   const dx=livePlayer?player.x+player.w/2-(q.x+q.w/2):Infinity,dy=livePlayer?player.y+player.h/2-(q.y+q.h/2):Infinity,distance=Math.hypot(dx,dy),visible=livePlayer&&distance<=q.detectionRadius&&lineVisible(q,player,live);
   q.state=visible?'chase':'idle';q.vx=visible?Math.sign(dx)*q.speed:0;advanceBody(q,live);
   if(!q.dead&&visible&&Math.hypot(player.x+player.w/2-q.x-q.w/2,player.y+player.h/2-q.y-q.h/2)<=q.triggerRadius){q.state='fuse';q.fuse=q.fuseTicks;q.vx=0;q.flash=false;diagnostic('creeper-armed',{actorId:q.id,fuseTicks:q.fuseTicks,x:q.x,y:q.y});sound('mc-fuse',{duration:q.fuseTicks/60});}
  }
  stepAnimals(player,live);
  live=stepSand(live,player);
  live=stepDiscoveries(live,player,actors);for(const item of capacityRewards){item.age++;if(!item.collected&&player&&!player.dead&&!player.dying&&overlap(player,item)){item.collected=true;item.age=0;grantHealthUpgrade(item.id);diagnostic('heart-container-collected',{upgradeId:item.id});}}
  if(wildEnderman)live=wildEnderman.step({tick:currentTick,input,player,geometry:live}).geometry;
  if(storm)live=storm.step({tick:currentTick,player,geometry:live}).geometry;
  if(workshop)live=workshop.step({tick:currentTick,player,geometry:live,actors}).geometry;
  if(nether)live=nether.step({tick:currentTick,player,geometry:live,actors}).geometry;if(dragon)live=dragon.step({tick:currentTick,player,geometry:live,actors}).geometry;
  if(gear)live=gear.step({tick:currentTick,input,player,geometry:live,dragon,nether,storm,encounter,actors}).geometry;
  if(player&&!player.dying&&player.grounded&&Math.abs(player.vx||0)>.25){if(++walkFrames%18===0)sound('mc-footstep',{seed:Math.floor(currentTick/18)});}else walkFrames=0;
  if(player&&!player.dying&&currentTick-lastPortalSound>=120&&(spec.scenery||[]).some(q=>q.kind==='portal'&&Math.abs(player.x+player.w/2-q.x-(q.w||40)/2)<100&&Math.abs(player.y+player.h-q.y)<110)){sound('mc-portal-ambience');lastPortalSound=currentTick;}
  return {geometry:live};
 }
 function stepShop({input={},player,geometry=room.map.geometry,tick}={}){if(paused||disposed)return shop.view().open;if(Number.isInteger(tick))currentTick=tick;const wasOpen=shop.view().open,trader=villagers.find(q=>q.role==='trader'),state=shop.step({near:!!(trader&&playerNear(trader,player,48,filteredGeometry(geometry))),input,alive:!!player&&!player.dead&&!player.dying});if(trade)trade=state;return wasOpen||state.open;}
 function view(){return {shop:shop.view(),capacityRewards:copy(capacityRewards),animals:copy(animals),...(grotto?{grotto:grotto.view()}:{}),...(wildEnderman?{wildEnderman:wildEnderman.view()}:{}),...(storm?{storm:storm.view()}:{}),...(gear?{gear:gear.view()}:{}),...(workshop?{workshop:workshop.view()}:{}),...(dragon?{dragon:dragon.view()}:{}),...(nether?{nether:nether.view()}:{}),...(spec.exploration?{exploration:copy({apple,pig,cart,ores,treeShake,mineLights,fleePigs,nearPortal,redstone,enderman,villager,villagers,golem,railZombie,trade})}:{}),version:1,biome:spec.biome,creepers:copy(creepers),sand:copy([...sand.values()].filter(q=>!q.dead)),effects:copy(effects),destroyedIds:[...destroyed]};}
 return Object.freeze({step,stepShop,view,reset,stepMusic:tick=>{if(!paused&&!disposed)workshop?.advanceMusic(tick);},captureImpactInput:input=>gear?.captureImpactInput(input),beforePlayer:(p,input,geometry,tick)=>grotto?.beforePlayer(p,input,geometry,tick),afterPlayer:(p,input,geometry)=>grotto?.afterPlayer(p,input,geometry),leaveRoom(){shop.reset();grotto?.leave();gear?.cancelProjectiles?.();},ownsGeometry:q=>workshop?.ownsGeometry(q)||dragon?.ownsGeometry(q)||nether?.ownsGeometry(q)||sandIds.has(q.id)||q.id===cart?.geometryId||q.id===redstone?.bridgeId||q.id===enderman?.blockId,allowsObject,syncPlayer,pause(value=true){grotto?.pause(value);wildEnderman?.pause(value);storm?.pause(value);gear?.pause(value);workshop?.pause(value);dragon?.pause(value);nether?.pause(value);const was=paused;paused=!!value;if(was&&!paused)for(const q of creepers)if(!q.dead&&q.state==='fuse')sound('mc-fuse',{duration:q.fuse/60});},dispose(){disposed=true;shop.reset();grotto?.leave();wildEnderman?.dispose();storm?.dispose();gear?.dispose();workshop?.dispose();dragon?.dispose();nether?.dispose();sound('mc-fuse-stop');effects=[];}});
}
