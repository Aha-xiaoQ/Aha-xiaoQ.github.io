import {readFile} from 'node:fs/promises';
export async function readCharacterProfile(){return JSON.parse(await readFile(new URL('../atlas/runtime/character.json',import.meta.url),'utf8'));}
