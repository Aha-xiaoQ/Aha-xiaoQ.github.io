"""Render deterministic review stills and a labelled contact sheet."""
import argparse,base64,json,time
from pathlib import Path
from playwright.sync_api import sync_playwright
from PIL import Image,ImageDraw
p=argparse.ArgumentParser();p.add_argument('html',type=Path);p.add_argument('--out',type=Path,required=True);p.add_argument('--times',default='0.5,2.3,42.7,45,46.7,53,72,107.8,108.3,111.3,114.8,117.9,135,140,146,148.2,149.6,151.8,153.2,156.6,176,199,208');a=p.parse_args()
a.out.mkdir(parents=True,exist_ok=True);times=[float(x) for x in a.times.split(',')];stats=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=r'C:\Program Files\Google\Chrome\Application\chrome.exe',headless=True)
 pg=b.new_page(viewport={'width':1920,'height':1080});errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
 html=a.html.read_text(encoding='utf-8').replace('<head>','<head><script>window.__EXPORT__=true;</script>');pg.set_content(html);pg.wait_for_function('window.__filmReady');pg.evaluate('document.fonts.ready')
 for t in times:
  start=time.time();st=pg.evaluate('(t)=>renderFrame(t)',t);raw=pg.evaluate('document.getElementById("film").toDataURL().split(",")[1]');(a.out/f'{t:07.3f}.png').write_bytes(base64.b64decode(raw));stats.append({'t':t,'ms':round((time.time()-start)*1000),'state':st})
 b.close()
sheet=Image.new('RGB',(1600,mathrows:=((len(times)+3)//4)*250),'#142b2a');d=ImageDraw.Draw(sheet)
for i,t in enumerate(times):
 im=Image.open(a.out/f'{t:07.3f}.png').resize((400,225));x=(i%4)*400;y=(i//4)*250;sheet.paste(im,(x,y+25));d.text((x+8,y+5),f'{t:.3f}s',fill='white')
sheet.save(a.out/'contact.jpg',quality=92);(a.out/'frames.json').write_text(json.dumps({'errors':errors,'frames':stats},ensure_ascii=False,indent=2),encoding='utf-8');print({'frames':len(stats),'errors':errors,'average_ms':round(sum(s['ms'] for s in stats)/len(stats))});assert not errors
