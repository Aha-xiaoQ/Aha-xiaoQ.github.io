"""Package the editable public source and technical guide."""
from pathlib import Path
import hashlib, json, zipfile

source = Path(__file__).resolve().parents[1]
root = source.parent
archive = root / 'World_Execute_B05_Source.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for path in sorted(source.rglob('*')):
        rel = path.relative_to(source)
        if path.is_symlink() or not path.is_file() or any(p in {'.git', '__pycache__', 'render_work', 'render-work', 'ending-work'} for p in rel.parts):
            continue
        if path.suffix == '.pyc' or rel == Path('audio.m4a'):
            continue
        z.write(path, path.relative_to(root).as_posix())
    guide = root / 'World_Execute_B05_电路核对.md'
    if guide.is_file() and not guide.is_symlink():
        z.write(guide, guide.name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert 'World_Execute_B05_Source/index.html' in z.namelist()
print(json.dumps({'archive': archive.name, 'bytes': archive.stat().st_size,
                  'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()}))
