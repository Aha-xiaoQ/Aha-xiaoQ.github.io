#!/usr/bin/env python3
"""Deterministic export of the actual HTML through lossless PNG frames.
Requires Playwright, Chromium, FFmpeg. AAC audio is copied, never replaced.
"""
from __future__ import annotations
import argparse,asyncio,base64,json,math,shutil,time,hashlib,sys
from pathlib import Path
from playwright.async_api import async_playwright

async def export(args):
    source=args.html.resolve();html=source.read_text(encoding='utf-8')
    audio=args.audio.resolve();output=args.output.resolve();output.parent.mkdir(parents=True,exist_ok=True)
    work=args.work.resolve();work.mkdir(parents=True,exist_ok=True)
    duration=args.duration;fps=args.fps;frames=math.ceil(duration*fps);workers=min(args.workers,frames)
    html=html.replace('<head>','<head><script>window.__EXPORT__=true;</script>',1)
    chromium=args.chromium or shutil.which('chromium') or shutil.which('chromium-browser') or shutil.which('google-chrome')
    if not shutil.which('ffmpeg'):raise RuntimeError('FFmpeg is required on PATH.')
    partitions=[(math.floor(i*frames/workers),math.floor((i+1)*frames/workers)) for i in range(workers)]
    begin=time.time();progress={};errors=[]
    async with async_playwright() as p:
        async def chunk(i,start,end):
            target=work/f'part_{i:02d}.mp4';log=work/f'part_{i:02d}_ffmpeg.log'
            kwargs={'headless':True,'args':['--no-sandbox','--disable-dev-shm-usage','--disable-background-timer-throttling','--disable-renderer-backgrounding']}
            if chromium:kwargs['executable_path']=chromium
            browser=await p.chromium.launch(**kwargs)
            page=await browser.new_page(viewport={'width':1920,'height':1080},device_scale_factor=1)
            page.on('pageerror',lambda err:errors.append(f'chunk {i}: {err}'))
            await page.set_content(html,wait_until='load');await page.evaluate('document.fonts.ready');await page.wait_for_function('window.__filmReady===true')
            cmd=['ffmpeg','-hide_banner','-loglevel','warning','-y','-f','image2pipe','-vcodec','png','-framerate',str(fps),'-i','pipe:0','-an','-c:v','libx264','-preset',args.preset,'-crf',str(args.crf),'-pix_fmt','yuv420p','-threads','2','-r',str(fps),'-g',str(fps*2),'-movflags','+faststart',str(target)]
            with log.open('wb') as logf:
                proc=await asyncio.create_subprocess_exec(*cmd,stdin=asyncio.subprocess.PIPE,stderr=logf)
                assert proc.stdin is not None
                try:
                    for frame in range(start,end):
                        raw=await page.evaluate('(t)=>{renderFrame(t,{captions:2});return document.getElementById("film").toDataURL("image/png").split(",")[1]}',frame/fps)
                        proc.stdin.write(base64.b64decode(raw));await proc.stdin.drain()
                        if (frame-start)%120==0 or frame==end-1:
                            progress[str(i)]={'frame':frame,'completed':frame-start+1,'total':end-start,'time_s':round(frame/fps,3),'elapsed_s':round(time.time()-begin,1)}
                            (work/'progress.json').write_text(json.dumps(progress,indent=2))
                            print(f"part {i}: {frame-start+1}/{end-start} | t={frame/fps:.2f} | elapsed {time.time()-begin:.1f}s",flush=True)
                        if errors:raise RuntimeError('; '.join(errors))
                    proc.stdin.close();await proc.stdin.wait_closed();code=await proc.wait()
                    if code:raise RuntimeError(f'FFmpeg failed ({code}); see {log}')
                except BaseException:
                    if proc.returncode is None:proc.kill();await proc.wait()
                    raise
                finally:await browser.close()
            return target
        parts=await asyncio.gather(*(chunk(i,a,b) for i,(a,b) in enumerate(partitions)))
    concat=work/'concat.txt';concat.write_text(''.join("file '"+f.as_posix().replace("'","'\\''")+"'\n" for f in parts),encoding="utf-8")
    cmd=['ffmpeg','-hide_banner','-loglevel','warning','-y','-f','concat','-safe','0','-i',str(concat),'-i',str(audio),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','copy','-t',str(duration),'-movflags','+faststart','-metadata','title=world.execute(me); — 坐标之外','-metadata','comment=Unofficial AI-generated fan music film. Music: Mili. Visuals: procedural HTML/Canvas. Original user-supplied audio.',str(output)]
    proc=await asyncio.create_subprocess_exec(*cmd);code=await proc.wait()
    if code:raise RuntimeError(f'Audio mux failed ({code}).')
    manifest={'source_html':source.name,'html_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'audio_sha256':hashlib.sha256(audio.read_bytes()).hexdigest(),'output':output.name,'width':1920,'height':1080,'fps':fps,'duration_target':duration,'frames_rendered':frames,'render_method':'absolute-time browser Canvas -> lossless PNG frames -> H.264','audio_method':'AAC stream copy, no processing','encoder':f'libx264 / {args.preset} / CRF {args.crf} / yuv420p','elapsed_s':round(time.time()-begin,2),'errors':errors}
    (work/'render_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(manifest,ensure_ascii=False,indent=2),flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('html',type=Path);ap.add_argument('--audio',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);ap.add_argument('--work',type=Path,default=Path('render_work'));ap.add_argument('--duration',type=float,default=211.925333);ap.add_argument('--fps',type=int,default=60);ap.add_argument('--workers',type=int,default=2);ap.add_argument('--crf',type=int,default=18);ap.add_argument('--preset',default='medium');ap.add_argument('--chromium');a=ap.parse_args()
    if not a.html.is_file() or not a.audio.is_file():ap.error('HTML and audio must exist.')
    if a.fps<1 or a.fps>120 or a.workers<1:ap.error('Invalid fps/workers.')
    try:asyncio.run(export(a))
    except KeyboardInterrupt:sys.exit(130)
