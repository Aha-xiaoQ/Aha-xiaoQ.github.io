#!/usr/bin/env python3
"""Recover the already embedded, unmodified user-supplied AAC file for rebuilding."""
import argparse,base64,re,hashlib
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('html',type=Path);p.add_argument('--output',type=Path,default=Path('audio.m4a'));a=p.parse_args()
s=a.html.read_text(encoding='utf-8');m=re.search(r'data:audio/[^;]+;base64,([A-Za-z0-9+/=]+)',s)
if not m:raise SystemExit('No embedded audio was found.')
b=base64.b64decode(m.group(1),validate=True);a.output.write_bytes(b);print(a.output, len(b),'bytes; SHA-256',hashlib.sha256(b).hexdigest())
