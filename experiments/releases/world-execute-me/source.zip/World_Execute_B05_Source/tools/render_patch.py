"""Render changed absolute frame ranges and losslessly rejoin an audited core.

The base must be a core without the sidebar. Its unchanged decoded YUV frames
are retained by a lossless H.264 join. Final delivery is encoded by ending_b05.
Ranges are zero-based and end-exclusive. Never use this for a global change.
"""
import argparse, asyncio, base64, hashlib, json, subprocess, time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from playwright.async_api import async_playwright

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def probe(p):
    return json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(p)]))
def frame_hashes(p):
    raw=subprocess.check_output(['ffmpeg','-v','error','-threads','2','-i',str(p),'-map','0:v:0','-an','-pix_fmt','yuv420p','-f','framemd5','pipe:1'],text=True,encoding='utf-8')
    return [line.rsplit(',',1)[1].strip() for line in raw.splitlines() if line and not line.startswith('#')]

async def main(a):
    start=time.time();a.work.mkdir(parents=True,exist_ok=True)
    assert a.base.resolve()!=a.output.resolve()
    old=json.loads(a.base_manifest.read_text(encoding='utf-8'))
    assert sha(a.base_html)==old['html_sha256']
    assert sha(a.audio)==old['audio_sha256']
    meta=probe(a.base);v=next(s for s in meta['streams'] if s['codec_type']=='video')
    assert (v['width'],v['height'],v['r_frame_rate'],int(v['nb_frames']))==(1920,1080,'60/1',12716)
    spans=sorted(tuple(map(int,s.split(':'))) for s in a.ranges)
    assert all(0<=x<y<=12716 for x,y in spans)
    assert all(p[1]<=q[0] for p,q in zip(spans,spans[1:]))
    input_hash=sha(a.html)
    html=a.html.read_text(encoding='utf-8').replace('<head>','<head><script>window.__EXPORT__=true;</script>',1)
    errors=[];clips=[]
    async with async_playwright() as p:
        b=await p.chromium.launch(executable_path=a.chromium,headless=True)
        page=await b.new_page(viewport={'width':1920,'height':1080})
        page.on('pageerror',lambda e:errors.append(str(e)))
        await page.set_content(html);await page.wait_for_function('window.__filmReady');await page.evaluate('document.fonts.ready')
        for i,(first,end) in enumerate(spans):
            clip=a.work/f'patch_{i:02d}.mp4';clips.append(clip)
            with (a.work/f'patch_{i:02d}.log').open('wb') as log:
                proc=await asyncio.create_subprocess_exec('ffmpeg','-v','error','-y','-f','image2pipe','-vcodec','png','-framerate','60','-i','pipe:0','-an','-c:v','libx264','-preset','medium','-crf','18','-pix_fmt','yuv420p','-threads','2',str(clip),stdin=asyncio.subprocess.PIPE,stderr=log)
                try:
                    for n in range(first,end):
                        raw=await page.evaluate('(t)=>{renderFrame(t,{captions:2});return document.getElementById("film").toDataURL().split(",")[1]}',n/60)
                        proc.stdin.write(base64.b64decode(raw));await proc.stdin.drain()
                        if (n-first)%120==0:print(f'patch {i}: {n-first}/{end-first}',flush=True)
                    proc.stdin.close();await proc.stdin.wait_closed();assert await proc.wait()==0
                finally:
                    if proc.returncode is None:proc.kill();await proc.wait()
        await b.close()
    assert not errors,errors
    graph=[];order=[];cursor=0
    for i,(first,end) in enumerate(spans):
        if first>cursor:
            tag=f'b{i}';graph.append(f'[0:v]trim=start_frame={cursor}:end_frame={first},setpts=PTS-STARTPTS[{tag}]');order.append(f'[{tag}]')
        tag=f'p{i}';graph.append(f'[{i+1}:v]setpts=PTS-STARTPTS[{tag}]');order.append(f'[{tag}]');cursor=end
    if cursor<12716:
        graph.append(f'[0:v]trim=start_frame={cursor}:end_frame=12716,setpts=PTS-STARTPTS[last]');order.append('[last]')
    graph.append(''.join(order)+f'concat=n={len(order)}:v=1:a=0[v]')
    cmd=['ffmpeg','-v','error','-y','-i',str(a.base)]
    for clip in clips:cmd+=['-i',str(clip)]
    cmd+=['-filter_complex',';'.join(graph),'-map','[v]','-map','0:a:0','-c:v','libx264','-preset','ultrafast','-crf','0','-pix_fmt','yuv420p','-threads','4','-r','60','-frames:v','12716','-c:a','copy','-movflags','+faststart',str(a.output)]
    with (a.work/'lossless-join.log').open('wb') as log:subprocess.run(cmd,stderr=log,check=True)
    result=probe(a.output);vv=next(s for s in result['streams'] if s['codec_type']=='video');assert int(vv['nb_frames'])==12716
    with ThreadPoolExecutor(max_workers=2) as pool:
        before,after=list(pool.map(frame_hashes,[a.base,a.output]))
    assert len(before)==len(after)==12716
    changed=set(n for x,y in spans for n in range(x,y))
    assert all(before[n]==after[n] for n in range(12716) if n not in changed),'Unchanged frame shifted or recompressed'
    for clip,(first,end) in zip(clips,spans):
        assert frame_hashes(clip)==after[first:end],'Patch frame order changed during join'
    report={'source_html':a.html.name,'html_sha256':sha(a.html),'audio_sha256':sha(a.audio),'output':a.output.name,'width':1920,'height':1080,'fps':60,'duration_target':211.925333,'frames_total':12716,'frames_rendered':sum(y-x for x,y in spans),'frames_reused':12716-sum(y-x for x,y in spans),'base_sha256':sha(a.base),'base_html_sha256':sha(a.base_html),'ranges_end_exclusive':spans,'render_method':'Absolute-time Canvas patches; unchanged base frames retained in lossless YUV420 H.264 join','audio_method':'AAC stream copy','encoder':'patches CRF18 medium; intermediate join CRF0 ultrafast','elapsed_s':round(time.time()-start,2),'errors':errors}
    assert sha(a.html)==input_hash,'HTML changed during export; do not attribute output to changed source'
    report.update(all_reused_frames_identical=True,reused_frame_hashes_checked=12716-len(changed),all_patch_frames_identical=True)
    (a.work/'render_manifest.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report,indent=2),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for name in ['html','base','base-html','base-manifest','audio','output','work']:p.add_argument('--'+name,type=Path,required=True)
    p.add_argument('--ranges',nargs='+',required=True);p.add_argument('--chromium',required=True)
    asyncio.run(main(p.parse_args()))
