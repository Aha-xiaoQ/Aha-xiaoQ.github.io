#!/usr/bin/env python3
"""Build the offline HTML. Music bytes are embedded unchanged; fonts are not bundled."""
from pathlib import Path
import argparse, base64, hashlib, json
p=argparse.ArgumentParser();p.add_argument('--audio',type=Path,required=True);p.add_argument('--output',type=Path,default=Path('World_Execute_B05.html'));args=p.parse_args()
root=Path(__file__).resolve().parents[1];src=root/'src'
if not args.audio.is_file():raise SystemExit('Audio file does not exist: '+str(args.audio))
html=(src/'shell.html').read_text(encoding='utf-8')
for tag,name in [('STYLE','style.css'),('SCORE','score.js'),('FEATURES','features.js'),('ENGINE','engine.js'),('FILM','film.js'),('REFINEMENT','refinement.js'),('CIRCUIT_MODEL','circuit_model.js'),('CIRCUIT_FILM','circuit_film.js'),('CLASSIC_MODEL','classic_model.js'),('CLASSIC_FILM','classic_film.js'),('PLAYER','player.js')]:html=html.replace('/*'+tag+'*/',(src/name).read_text(encoding='utf-8'))
audio=args.audio.read_bytes();html=html.replace('/*AUDIO*/','data:audio/mp4;base64,'+base64.b64encode(audio).decode())
args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(html,encoding='utf-8',newline='\n')
manifest={'audio_source':'user-provided GPT6-Astra眼中的world.execute(me).m4a','audio_sha256':hashlib.sha256(audio).hexdigest(),'audio_bytes':len(audio),'audio_transcoded_in_HTML':False,'duration':211.925333,'html_sha256':hashlib.sha256(html.encode()).hexdigest(),'html_bytes':len(html.encode()),'font_files':0,'generated_images':0,'external_runtime_requests':0,'reference':'user-provided corresponding captioned MP4 / BV1Jwhy6BEMJ','subtitle_alignment':'Read from supplied captioned reference at 12 fps, grouped into clauses, with editorial subdivision of repeated phrases; not automated forced word alignment.'}
(root/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8');print(args.output,len(html.encode()))
