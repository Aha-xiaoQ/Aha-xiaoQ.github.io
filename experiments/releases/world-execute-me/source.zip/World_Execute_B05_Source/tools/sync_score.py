#!/usr/bin/env python3
"""Make JS and subtitle exports from the single score.json source of truth."""
from pathlib import Path
import json
root=Path(__file__).resolve().parents[1]
score=json.loads((root/'score.json').read_text(encoding='utf-8'))
prev=0.0
for i,c in enumerate(score['cues']):
    if not (prev<=c['start']<c['end']<=score['duration']):raise SystemExit(f'Invalid or overlapping cue {i+1}')
    if not c['en'] or not c['zh']:raise SystemExit(f'Empty cue {i+1}')
    prev=c['end']
(root/'src/score.js').write_text('window.MV_SCORE='+json.dumps(score,ensure_ascii=False,separators=(',',':'))+';\n',encoding='utf-8')

def stamp(t,sep=','):
    ms=round(t*1000);s,ms=divmod(ms,1000);m,s=divmod(s,60);h,m=divmod(m,60)
    return f'{h:02d}:{m:02d}:{s:02d}{sep}{ms:03d}'
(root/'subtitles').mkdir(exist_ok=True)
for ext,header,sep in [('srt','',','),('vtt','WEBVTT\n\n','.')]:
    parts=[f'{i+1}\n{stamp(c["start"],sep)} --> {stamp(c["end"],sep)}\n{c["en"]}\n{c["zh"]}' for i,c in enumerate(score['cues'])]
    (root/'subtitles'/f'World_Execute_B04_中英字幕.{ext}').write_text(header+'\n\n'.join(parts)+'\n',encoding='utf-8-sig' if ext=='srt' else 'utf-8')
print(f'Synchronized {len(score["cues"])} cues.')
