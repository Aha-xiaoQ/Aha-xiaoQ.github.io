"""Render the user-selected 47.15 s AC-to-DC frame as two cover ratios.

Requirements: Python 3, Pillow, Playwright, installed Google Chrome.
The 16:9 cover is the native film canvas. The 4:3 cover contains the entire
same canvas at uniform 0.75 scale, centered without cropping or rearranging.
No font or drawing is added to the film's own scene.
"""
from pathlib import Path
import base64
import hashlib
import json

from PIL import Image
from playwright.sync_api import sync_playwright

SOURCE = Path(__file__).resolve().parents[1]
PROJECT = SOURCE.parent
OUT = PROJECT / '投稿材料'
REVIEW = PROJECT / 'review' / 'ac-cover'
TIME = 47.15
CHROME = r'C:\Program Files\Google\Chrome\Application\chrome.exe'


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    OUT.mkdir(exist_ok=True)
    REVIEW.mkdir(parents=True, exist_ok=True)
    html_path = SOURCE / 'index.html'
    html = html_path.read_text(encoding='utf-8').replace(
        '<head>', '<head><script>window.__EXPORT__=true;</script>')
    errors = []
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path=CHROME, headless=True)
        page = browser.new_page(viewport={'width': 1920, 'height': 1080})
        page.on('pageerror', lambda e: errors.append(str(e)))
        page.set_content(html)
        page.wait_for_function('window.__filmReady')
        page.evaluate('document.fonts.ready')
        state = page.evaluate('(t) => renderFrame(t)', TIME)
        images = page.evaluate('''() => {
            const original = document.getElementById('film');
            const compact = document.createElement('canvas');
            compact.width = 1440;
            compact.height = 1080;
            const ctx = compact.getContext('2d');
            ctx.fillStyle = PressEngine.PAL.night.bg;
            ctx.fillRect(0, 0, 1440, 1080);
            ctx.drawImage(original, 0, 135, 1440, 810);
            return {
                '16x9': original.toDataURL('image/png').split(',')[1],
                '4x3': compact.toDataURL('image/png').split(',')[1]
            };
        }''')
        browser.close()
    assert not errors, errors
    artifacts = []
    for ratio, encoded in images.items():
        png = OUT / f'封面_{ratio}.png'
        png.write_bytes(base64.b64decode(encoded))
        im = Image.open(png).convert('RGB')
        jpg = OUT / f'封面_{ratio}.jpg'
        im.save(jpg, quality=95, subsampling=0)
        thumb = OUT / f'封面_{ratio}_缩略检查.png'
        im.thumbnail((360, 270), Image.Resampling.LANCZOS)
        im.save(thumb)
        for path in (png, jpg, thumb):
            with Image.open(path) as check:
                artifacts.append({'path': str(path.relative_to(PROJECT)),
                                  'size': list(check.size), 'sha256': sha256(path)})
    manifest = {
        'task_id': 'world-execute-ac-cover-20260929',
        'trace_id': 'WORLD-EXECUTE-AC-COVER-20260929',
        'time_s': TIME,
        'html_sha256': sha256(html_path),
        'method': 'Native production Canvas, same frame and model state in both ratios',
        'latest_user_correction': '4:3 compact adaptation only; preserve horizontal AC-bridge-DC; no reconstruction or crop',
        'four_by_three': {'uniform_scale': 0.75, 'source_rect': [0, 0, 1920, 1080],
                          'destination_rect': [0, 135, 1440, 810],
                          'crop': False, 'rearrangement': False},
        'extra_text': False, 'extra_font': False,
        'render_errors': errors, 'render_state': state, 'artifacts': artifacts
    }
    (REVIEW / 'cover-manifest.json').write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({'time_s': TIME, 'html_sha256': manifest['html_sha256'],
                      'artifacts': artifacts, 'errors': errors}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
