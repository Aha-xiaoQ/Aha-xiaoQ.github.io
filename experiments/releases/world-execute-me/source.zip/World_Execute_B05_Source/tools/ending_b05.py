"""B05 episode ending: original v12 sidebar artwork/timing over the whole film.

Runtime: Python 3.10+, Pillow, NumPy, FFmpeg/FFprobe on PATH; installed LXGW
WenKai Regular font (or --font). No template-project imports or bundled fonts.

Preview: python tools/ending_b05.py --input core.mp4 --output preview.mp4 --tail-only
Final:   python tools/ending_b05.py --input core.mp4 --output final.mp4

The final video has 12716 frames. The last 642 are composited. Full-export AAC
packets are stream copied, and their byte hash is checked against the input.
"""
from __future__ import annotations

import argparse
from functools import lru_cache
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import xml.etree.ElementTree as ET

import numpy as np
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'assets' / 'ending'
W, H, FPS = 1920, 1080, 60
TOTAL_FRAMES, START_FRAME, TAIL_FRAMES = 12716, 12074, 642
START_S, DURATION = START_FRAME / FPS, TAIL_FRAMES / FPS
PW, PH, PANEL_X, PANEL_Y = 672, 992, 1224, 44
ENTRY, OPEN_TIME = .85, .9
TRIGGERS = [3.1, 3.62, 4.14]
LABELS = ['点赞', '投币', '收藏']
BG, END_BG = '#091b2c', '#142b2a'
P = {'ink': '#173b59', 'blue': '#009FE8', 'cyan': '#85d5ff',
     'white': '#fff5dd', 'copper': '#b48836', 'gold': '#F2C43E',
     'lemon': '#fff0b1'}
TITLE, SUBTITLE = '坐标之外', 'world.execute(me);'
CREDITS = [
    ['策划、审校', '在下_小Q'],
    ['视觉、程序与剪辑', 'GPT-6 · Codex'],
    ['原曲', 'Mili · world.execute(me);'],
    ['片尾字体', '霞鹜文楷'],
    ['更多作品', 'aha-xiaoq.github.io'],
]
CTA = '喜欢这个脑洞，欢迎三连'


def ease(t):
    t = max(0., min(1., t))
    return t * t * (3 - 2 * t)


def probe(path):
    return json.loads(subprocess.check_output([
        'ffprobe', '-v', 'error', '-show_streams', '-show_format', '-of', 'json', str(path)]))


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def audio_packet_hash(path):
    return subprocess.check_output([
        'ffmpeg', '-v', 'error', '-i', str(path), '-map', '0:a:0',
        '-c:a', 'copy', '-f', 'hash', '-hash', 'sha256', '-']).decode().strip()


def find_font(explicit=None):
    candidates = [Path(explicit)] if explicit else []
    local = os.environ.get('LOCALAPPDATA')
    if local:
        candidates.append(Path(local) / 'Microsoft/Windows/Fonts/LXGWWenKai-Regular.ttf')
    candidates += [Path(os.environ.get('WINDIR', 'C:/Windows')) / 'Fonts/LXGWWenKai-Regular.ttf',
                   Path.home() / '.local/share/fonts/LXGWWenKai-Regular.ttf',
                   Path('/usr/share/fonts/truetype/lxgw/LXGWWenKai-Regular.ttf')]
    for path in candidates:
        if path.is_file():
            face = ImageFont.truetype(str(path), 32)
            family = face.getname()[0]
            if 'WenKai' not in family and '文楷' not in family:
                raise ValueError(f'Expected LXGW WenKai, found {family}')
            return path.resolve()
    raise FileNotFoundError('Install LXGW WenKai Regular or pass --font /path/to/font.ttf')


def stepped_box(d, box, cut, color):
    # Exact authored v8 stepped contour, exported at 4x nearest-neighbor.
    x0, y0, x1, y1 = box
    c, k = cut, cut // 2
    pts = [(x0+c,y0),(x1-c,y0),(x1-c,y0+k),(x1-k,y0+k),(x1-k,y0+c),(x1,y0+c),
           (x1,y1-c),(x1-k,y1-c),(x1-k,y1-k),(x1-c,y1-k),(x1-c,y1),
           (x0+c,y1),(x0+c,y1-k),(x0+k,y1-k),(x0+k,y1-c),(x0,y1-c),
           (x0,y0+c),(x0+k,y0+c),(x0+k,y0+k),(x0+c,y0+k)]
    d.polygon(pts, fill=color)


def mini_coin(d, cx, cy):
    # Original brand-v7 thumb accent, on the native 40px action cell.
    w, h = 3, 4
    d.polygon([(cx-w+1,cy-h),(cx+w-1,cy-h),(cx+w,cy-h+1),
               (cx+w,cy+h-1),(cx+w-1,cy+h),(cx-w+1,cy+h),
               (cx-w,cy+h-1),(cx-w,cy-h+1)], fill=P['copper'])
    d.rectangle((cx-w+1,cy-h+1,cx+w-1,cy+h-1), fill=P['gold'])
    d.line([(cx-1,cy-h+1),(cx-1,cy+h-2)], fill=P['lemon'])


class Sidebar:
    def __init__(self, font_path):
        self.font_path = font_path
        self.frames = {key: [Image.open(ASSETS/f'{key}-{i:02}.png').convert('RGBA')
                            for i in range(count)]
                       for key, count in [('like',3),('coin',6),('star',3)]}
        self.text_checks = []
        im = Image.new('RGBA', (168,248))
        d = ImageDraw.Draw(im)
        stepped_box(d, (0,0,167,247), 6, P['blue'])
        stepped_box(d, (2,2,165,245), 6, '#0c2941')
        d.rectangle((8,10,159,46), fill='#103d5e')
        d.line([(10,49),(157,49)], fill='#2d6282')
        d.line([(10,157),(157,157)], fill='#2d6282')
        d.rectangle((8,160,159,235), fill='#103751')
        self.base = im.resize((PW,PH), Image.Resampling.NEAREST)
        logo = Image.new('RGBA', (9,9)); ld = ImageDraw.Draw(logo)
        svg = ET.parse(ASSETS/'q-logo-pixel-core.svg').getroot()
        for group in svg.iter('{http://www.w3.org/2000/svg}g'):
            if group.get('fill'):
                for rect in group.findall('{http://www.w3.org/2000/svg}rect'):
                    ld.point((int(rect.get('x')),int(rect.get('y'))),fill=group.get('fill'))
        self.base.alpha_composite(logo.resize((72,72), Image.Resampling.NEAREST),(44,66))
        title_size = self.fit(TITLE,46,480,36)
        box = self.font(title_size).getbbox(TITLE,anchor='lt')
        self.text(self.base,(140,round(66+36-(box[3]-box[1])/2-box[1])),TITLE,title_size)
        self.text(self.base,(46,150),SUBTITLE,self.fit(SUBTITLE,29,576,25),P['cyan'])
        self.text(self.base,(336,657),CTA,self.fit(CTA,32,592,28),center=True)
        self.credit_sheet = Image.new('RGBA',(576,116*len(CREDITS)+80))
        for j,(role,name) in enumerate(CREDITS):
            self.text(self.credit_sheet,(0,j*116),role,self.fit(role,27,568,24),'#8ca9bb')
            self.text(self.credit_sheet,(0,j*116+45),name,self.fit(name,36,568,27))

    @lru_cache(maxsize=64)
    def font(self, size):
        return ImageFont.truetype(str(self.font_path), size)

    def fit(self, text, size, width, minimum):
        while self.font(size).getlength(text)>width and size>minimum:
            size -= 1
        measured = self.font(size).getlength(text)
        if measured>width:
            raise ValueError(f'Text exceeds safe width: {text}')
        self.text_checks.append({'text':text,'font_px':size,'width_px':measured,'safe_px':width})
        return size

    def text(self, im, xy, text, size, color='#fff4d0', center=False):
        ImageDraw.Draw(im).text(xy,text,font=self.font(size),fill=color,
                               anchor='mt' if center else 'lt')

    def native_icon(self, i, age):
        key = ['like','coin','star'][i]
        if age<0:
            im = self.frames[key][2 if i==0 else 0].copy()
            a=np.asarray(im); mask=a[:,:,3]>0; b=np.zeros_like(a)
            b[mask,:3]=[45,75,94]; b[mask,3]=255
            return Image.fromarray(b)
        if i==0:
            f = 0 if age<.12 else 1 if age<.24 else 2
        elif i==1:
            f = int(max(0,age-.08)/.065)%6 if age<.86 else 0
        else:
            f = 1 if age<.12 else 2 if .3<age<.5 else 0
            if age>1.9 and 2.5<age%3.3<2.65:
                f=1
        im=self.frames[key][f].copy()
        if age<.62:
            y=round(-3*math.sin(min(1,age/.62)*math.pi))
            shifted=Image.new('RGBA',(40,40));shifted.alpha_composite(im,(0,y));im=shifted
        d=ImageDraw.Draw(im)
        if .24<age<.88:
            k=int((age-.24)/.16)
            for sx,sy in [(5,6),(34,6),(36,28)][:2+(i==2)]:
                if k%2==0:
                    d.line([(sx-1,sy),(sx+1,sy)],fill=P['white'])
                    d.line([(sx,sy-1),(sx,sy+1)],fill=P['gold'])
                else:
                    d.point((sx,sy),fill=P['gold'])
        if i==0 and .24<age<1.14:
            mini_coin(ImageDraw.Draw(im),31,8-round((age-.24)*3))
        return im

    def panel(self,t):
        im=self.base.copy()
        offset=50-round(max(0,t-1.8)*42)
        area=Image.new('RGBA',(576,398))
        area.alpha_composite(self.credit_sheet,(0,offset))
        im.alpha_composite(area,(48,220))
        for i in range(3):
            age=t-TRIGGERS[i];cx=128+i*208
            icon=self.native_icon(i,age).resize((160,160),Image.Resampling.NEAREST)
            im.alpha_composite(icon,(cx-80,729))
            self.text(im,(cx,905),LABELS[i],30,P['white'] if age>=0 else '#69899b',True)
        return im

    def scene(self,source,t):
        e=ease((t-ENTRY)/OPEN_TIME)
        if e<=0:
            return source
        im=Image.new('RGB',(W,H),BG)
        # Preserve every part of the 16:9 frame. Source and destination have
        # equal aspect ratio; this replaces the old game's 1152x1080 crop.
        scale=1-.4*e
        sw,sh=round(W*scale),round(H*scale)
        sx,sy=round(24*e),round((H-sh)/2)
        im.paste(source.resize((sw,sh),Image.Resampling.LANCZOS),(sx,sy))
        panel=self.panel(t)
        px=round(W+(PANEL_X-W)*e)
        im.paste(panel,(px,PANEL_Y),panel)
        # Existing B04/B05 narrative fade runs 210.78–211.89. Bring the whole
        # composite, including sidebar, to that same endpoint without audio edits.
        fade=ease((START_S+t-210.78)/(211.89-210.78))
        if fade:
            im=Image.blend(im,Image.new('RGB',(W,H),END_BG),fade)
        return im


def read_exact(stream, count):
    chunks=[]; remaining=count
    while remaining:
        data=stream.read(remaining)
        if not data:
            raise RuntimeError(f'Short raw frame; missing {remaining} bytes')
        chunks.append(data); remaining-=len(data)
    return b''.join(chunks)


def render_tail(source, target, work, sidebar):
    log_path=work/'tail-render.log'
    with log_path.open('w',encoding='utf-8') as log:
        decoder=subprocess.Popen(['ffmpeg','-nostdin','-v','error','-ss',str(START_S),
            '-i',str(source),'-frames:v',str(TAIL_FRAMES),'-an','-pix_fmt','rgb24',
            '-f','rawvideo','pipe:1'],stdout=subprocess.PIPE,stderr=log)
        writer=subprocess.Popen(['ffmpeg','-nostdin','-v','error','-y','-f','rawvideo',
            '-pixel_format','rgb24','-video_size','1920x1080','-framerate','60','-i','pipe:0',
            '-an','-c:v','libx264','-preset','fast','-crf','16','-pix_fmt','yuv420p',
            '-threads','4','-frames:v',str(TAIL_FRAMES),'-movflags','+faststart',str(target)],
            stdin=subprocess.PIPE,stderr=log)
        try:
            for n in range(TAIL_FRAMES):
                source_frame=Image.frombytes('RGB',(W,H),read_exact(decoder.stdout,W*H*3))
                writer.stdin.write(sidebar.scene(source_frame,n/FPS).tobytes())
                if n%120==0:
                    print(f'tail frames {n}/{TAIL_FRAMES}',flush=True)
            writer.stdin.close();decoder.stdout.close()
            dr=decoder.wait();wr=writer.wait()
            if dr or wr:
                raise RuntimeError(f'Tail render failed; see {log_path}')
        finally:
            if decoder.poll() is None: decoder.kill()
            if writer.poll() is None: writer.kill()


def write_review_frames(output,work,tail_only):
    times=[0,1.30,2.00,4.14,6.00,8.70,10.20,10.683333]
    sheet=Image.new('RGB',(1920,592),BG)
    for i,t in enumerate(times):
        frame=work/f'export_tail_{t:05.2f}.png'
        subprocess.run(['ffmpeg','-v','error','-y','-ss',str(t if tail_only else START_S+t),
            '-i',str(output),'-frames:v','1','-update','1',str(frame)],check=True)
        image=Image.open(frame).convert('RGB').resize((480,270),Image.Resampling.LANCZOS)
        x,y=(i%4)*480,(i//4)*296
        sheet.paste(image,(x,y+26));ImageDraw.Draw(sheet).text((x+8,y+5),f'TAIL {t:.2f}s',fill='white')
    sheet.save(work/'ending-contact.jpg',quality=95)


def main():
    parser=argparse.ArgumentParser(description=__doc__,formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--input',required=True,type=Path)
    parser.add_argument('--output',required=True,type=Path)
    parser.add_argument('--work-dir',type=Path)
    parser.add_argument('--font',type=Path)
    parser.add_argument('--tail-only',action='store_true',help='Export the 642-frame preview only')
    parser.add_argument('--reuse-tail',type=Path,help='Reuse an already rendered tail for this exact core input')
    args=parser.parse_args()
    source=args.input.resolve(); output=args.output.resolve()
    if source==output: raise ValueError('Input and output must differ')
    for tool in ['ffmpeg','ffprobe']:
        if not shutil.which(tool): raise RuntimeError(f'{tool} is required on PATH')
    work=(args.work_dir or output.parent/(output.stem+'-ending-review')).resolve()
    work.mkdir(parents=True,exist_ok=True);output.parent.mkdir(parents=True,exist_ok=True)
    meta=probe(source);video=next(s for s in meta['streams'] if s['codec_type']=='video')
    assert (video['width'],video['height'],video['r_frame_rate'])==(1920,1080,'60/1'),video
    assert int(video['nb_frames'])==TOTAL_FRAMES,video
    if not any(s['codec_type']=='audio' for s in meta['streams']):
        raise ValueError('Source must contain the original song audio')
    font_path=find_font(args.font);sidebar=Sidebar(font_path)
    tail=args.reuse_tail.resolve() if args.reuse_tail else work/'ending-tail-silent.mp4'
    input_hash=sha(source)
    binding=tail.with_suffix('.source.json')
    if not args.reuse_tail:
        render_tail(source,tail,work,sidebar)
        binding.write_text(json.dumps({'input_sha256':input_hash,'tail_sha256':sha(tail),
            'source_file':source.name,'start_frame':START_FRAME,'tail_frames':TAIL_FRAMES},
            ensure_ascii=False,indent=2),encoding='utf-8')
    else:
        saved=json.loads(binding.read_text(encoding='utf-8'))
        if saved['input_sha256']!=input_hash or saved['tail_sha256']!=sha(tail):
            raise ValueError('Tail belongs to different source bytes; render the current core again')
    tail_meta=next(s for s in probe(tail)['streams'] if s['codec_type']=='video')
    assert int(tail_meta['nb_frames'])==TAIL_FRAMES
    if args.tail_only:
        cmd=['ffmpeg','-v','error','-y','-ss',str(START_S),'-i',str(source),'-i',str(tail),
             '-map','1:v:0','-map','0:a:0','-c','copy','-t',str(DURATION),
             '-movflags','+faststart',str(output)]
    else:
        graph=f'[0:v]trim=end_frame={START_FRAME},setpts=PTS-STARTPTS[p];[1:v]setpts=PTS-STARTPTS[t];[p][t]concat=n=2:v=1:a=0[v]'
        cmd=['ffmpeg','-v','error','-y','-i',str(source),'-i',str(tail),'-filter_complex',graph,
             '-map','[v]','-map','0:a:0','-c:v','libx264','-preset','fast','-crf','16',
             '-pix_fmt','yuv420p','-threads','4','-r','60','-frames:v',str(TOTAL_FRAMES),
             '-c:a','copy','-movflags','+faststart',str(output)]
    with (work/'final-compose.log').open('w',encoding='utf-8') as log:
        subprocess.run(cmd,stderr=log,check=True)
    final=probe(output);fv=next(s for s in final['streams'] if s['codec_type']=='video')
    expected=TAIL_FRAMES if args.tail_only else TOTAL_FRAMES
    assert int(fv['nb_frames'])==expected,fv
    packet_equality=None
    if not args.tail_only:
        packet_equality=audio_packet_hash(source)==audio_packet_hash(output)
        assert packet_equality,'Original encoded audio packets changed'
    decoded=subprocess.run(['ffmpeg','-v','error','-i',str(output),'-f','null','-'],capture_output=True)
    assert decoded.returncode==0 and not decoded.stderr,decoded.stderr.decode(errors='replace')
    write_review_frames(output,work,args.tail_only)
    sidebar.panel(6).convert('RGB').save(work/'sidebar-at-6s.png')
    manifest={'input_file':source.name,'input_sha256':input_hash,'output_file':output.name,
              'output_sha256':sha(output),'font_family':sidebar.font(32).getname(),
              'font_installed_path':str(font_path),'font_bundled':False,
              'rendered_frames':expected,'fps':60,'resolution':[1920,1080],
              'duration_s':float(final['format']['duration']),
              'tail_start_frame':START_FRAME,'tail_frames':TAIL_FRAMES,'tail_start_s':START_S,
              'sidebar':[PANEL_X,PANEL_Y,PW,PH],'final_picture':[24,216,1152,648],
              'whole_picture_preserved':True,'picture_crop':None,
              'template':'v12 visuals / v8 clean panel / v7 blue native icons',
              'entry_s':ENTRY,'open_time_s':OPEN_TIME,'icon_triggers_s':TRIGGERS,
              'credit_scroll_px_per_s':42,'credits':CREDITS,'title':TITLE,'subtitle':SUBTITLE,
              'text_fit_checks':sidebar.text_checks,'full_decode':'pass',
              'audio_policy':'copy original song packets; no voice/music/ducking additions',
              'audio_packet_equality':packet_equality,
              'preview_audio_note':'tail-only remux cuts at AAC packet boundaries' if args.tail_only else None,
              'actual_listening':'not performed','visual_review':'inspect ending-contact.jpg',
              'command':cmd}
    (work/'ending-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'output':str(output),'frames':expected,'work':str(work),
                      'audio_packet_equality':packet_equality},ensure_ascii=True),flush=True)


if __name__=='__main__':
    main()
