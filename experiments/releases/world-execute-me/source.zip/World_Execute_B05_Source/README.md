# 坐标之外 · world.execute(me); · B05

Mili《world.execute(me);》非官方同人程序动画 MV。朱红的 `me`、青绿的 `you`，从创建、回应，到离开与不断重复的执行。纸张与字符版画风格结合经典电路和几何变化，讲述一段关系。

## 观看

完整 MV：[哔哩哔哩 BV1vkaW6CE8W](https://www.bilibili.com/video/BV1vkaW6CE8W/)。1920×1080、60 fps，约 3 分 32 秒，含同步侧栏片尾。

双击本目录的 `index.html`，点「播放 MV」即可离线观看交互主片；「观察与验证」可拖动电路时刻或几何视角。HTML 已内嵌音频，无须先构建。成片侧栏片尾由 `tools/ending_b05.py` 合成。

## 本版镜头

- 00:00–00:04：开关、限流电阻、LED，通电与保护。
- 00:44–00:48：桥式整流与电容滤波。
- 01:10–01:14：同一模拟世界里的两位玩家。
- 01:50–01:58：P2 已离开，I²C 第九拍没有应答。
- 02:14–02:28：调用栈向深处增长，没有返回。
- 02:28–02:39：NE555 电容充放电与输出脉冲，继而成为执行的栏杆。
- 03:21–结束：蓝色像素侧栏、滚动署名、三连动画；原曲与画面同时结束。

电路参数和简化边界见 `CIRCUITS.md`。情感、角色与栏杆是艺术表达。

## 编辑与导出

主片使用 Canvas 2D，无外部图形库。源文件按 `tools/build.py` 的顺序组合；`classic_model.js` 与 `classic_film.js` 为 B05 扩展。旧层保留用于回溯，由最后加载的同名方法决定实际画面。封面取 47.15 秒 AC→DC 画面，按比例完整适配；`tools/create_covers.py` 可重建两种比例。

需要 Python、Playwright/Chromium、FFmpeg/ffprobe；数值核对另用 Node.js、NumPy、SciPy。Python 依赖见 `requirements.txt`。

```text
python tools/extract_audio.py index.html --output audio.m4a
python tools/build.py --audio audio.m4a --output index.html
python tools/render.py index.html --audio audio.m4a --output ../World_Execute_B05_1080p60_core.mp4 --fps 60 --workers 3 --crf 18 --preset medium --work ../render-work --chromium <Chrome路径>
python tools/ending_b05.py --input ../World_Execute_B05_1080p60_core.mp4 --output ../World_Execute_B05_1080p60.mp4 --work-dir ../ending-work
```

侧栏使用霞鹜文楷。主片及 AC→DC 封面使用系统字体：中文为微软雅黑，等宽字符为 Consolas，西文标题和符号使用 Arial、Georgia；其他系统可能回退到不同字形。本包不附字体文件。

导出环境为 Windows、Chrome 153、Python 3.12、FFmpeg。`tests/baseline_b04` 是 B04 的历史记录；执行与 B04 的逐像素比较需要另行准备 B04 源码，它不影响独立重建 B05。模型和技术边界见 `CIRCUITS.md` 与上一层的 `World_Execute_B05_电路核对.md`。

## 素材与署名

音乐：Mili《world.execute(me);》。歌曲和歌词权益归相应权利人。策划、审校：在下_小Q；视觉、程序与剪辑：GPT-6 · Codex。本片为非官方同人作品，含 AI 生成内容。原曲和字体链接见 `REFERENCES.md`。
