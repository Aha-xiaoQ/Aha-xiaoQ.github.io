'use strict';
(() => {
const $=id=>document.getElementById(id),canvas=$('film'),audio=$('music');
let film;
try{film=new window.Film(canvas)}catch(e){$('begin').textContent='此浏览器未提供 Canvas 2D';throw e}
window.film=film;let playing=false,started=false,time=0,captionMode=2,inspecting=false,inspectKind='helix',yaw=0,pitch=0,drag=null,serial=0,raf=0,lastUI=-99,lastRender=-99,idle=performance.now(),frozen=false;
const EXPORT=!!window.__EXPORT__||new URLSearchParams(location.search).has('render');
const format=t=>`${String(Math.floor(t/60)).padStart(2,'0')}:${String(Math.floor(t%60)).padStart(2,'0')}`;
function toast(s){$('toast').textContent=s;$('toast').classList.add('show');clearTimeout(toast.timer);toast.timer=setTimeout(()=>$('toast').classList.remove('show'),3500)}
function resize(){if(EXPORT){canvas.width=1920;canvas.height=1080;return;}let r=$('stage').getBoundingClientRect(),w=Math.min(1920,Math.max(640,Math.round(Math.min(r.width,r.height*16/9)*Math.min(devicePixelRatio||1,1.5))));w=Math.round(w/16)*16;canvas.width=w;canvas.height=w/16*9;redraw();}
function isLab(){return ['power','rectifier','hold','xy','bus','clock'].includes(inspectKind)}
function redraw(){if(inspecting)film.inspect(inspectKind,yaw,pitch);else film.render(started?time:20.7,{captions:captionMode});}
function icon(){let path=playing?'<path d="M8 5v14M16 5v14"/>':'<path d="M8 5l11 7-11 7Z"/>';$('playicon').innerHTML=path;$('play').setAttribute('aria-label',playing?'暂停':'播放');}
function updateUI(force=false){if(!force&&Math.abs(time-lastUI)<.10)return;lastUI=time;$('scrub').value=String(time);$('scrub').style.setProperty('--fill',(100*time/film.duration)+'%');$('now').textContent=format(time);let ch=window.MV_SCORE.chapters.filter(c=>c.start<=time).at(-1);$('chaptertitle').textContent=ch?.title||'坐标之外';document.querySelectorAll('[data-chapter]').forEach(b=>b.classList.toggle('active',b.dataset.chapter===ch?.id));}
function leaveInspect(){if(!inspecting)return;inspecting=false;$('inspector').classList.remove('open');$('inspect').classList.remove('active');redraw()}
async function play(){leaveInspect();if(audio.ended||time>=film.duration-.03){time=0;audio.currentTime=0}started=true;$('start').classList.add('hidden');const n=++serial;try{await audio.play();if(n!==serial){audio.pause();return}playing=true;icon();}catch(e){playing=false;icon();toast('音频未能播放，请再次点击播放，或换用支持 AAC 的浏览器。')}}
function pause(){serial++;playing=false;audio.pause();time=Math.min(film.duration,audio.currentTime||time);icon();updateUI(true);redraw()}
function seek(t){leaveInspect();started=true;$('start').classList.add('hidden');time=Math.max(0,Math.min(film.duration,Number(t)||0));audio.currentTime=time;updateUI(true);redraw()}
function togglePlay(){playing?pause():play()}
function wake(){idle=performance.now();document.body.classList.remove('sleep')}
async function cinema(){wake();if(document.body.classList.contains('cinema')){document.body.classList.remove('cinema');if(document.fullscreenElement)await document.exitFullscreen().catch(()=>{});}else{document.body.classList.add('cinema');try{await document.documentElement.requestFullscreen()}catch(e){/* CSS theatre fallback */}}setTimeout(resize,40)}
function loop(now){if(EXPORT||frozen)return;if(playing&&!inspecting){let t=audio.currentTime;if(Number.isFinite(t))time=Math.min(film.duration,t);film.render(time,{captions:captionMode});updateUI();}if(document.body.classList.contains('cinema')&&playing&&now-idle>1900)document.body.classList.add('sleep');raf=requestAnimationFrame(loop)}
$('play').onclick=togglePlay;$('begin').onclick=play;$('restart').onclick=()=>{seek(0);play()};$('scrub').oninput=e=>seek(e.target.value);$('mute').onclick=()=>{audio.muted=!audio.muted;$('mute').setAttribute('aria-pressed',String(audio.muted));$('mute').style.opacity=audio.muted?'.48':'1';toast(audio.muted?'已静音':'声音已开启')};$('cc').onclick=()=>{captionMode=(captionMode+2)%3;$('cc').textContent=['字幕关','English','中英字幕'][captionMode];redraw()};$('fullscreen').onclick=cinema;
$('inspect').onclick=()=>{if(inspecting){leaveInspect();return;}pause();started=true;$('start').classList.add('hidden');inspecting=true;yaw=0;pitch=0;$('inspector').classList.add('open');$('inspect').classList.add('active');redraw();};
for(const b of document.querySelectorAll('[data-kind]'))b.onclick=()=>{inspectKind=b.dataset.kind;$('labtime').hidden=!isLab();$('front').hidden=isLab();$('side').hidden=isLab();document.querySelectorAll('[data-kind]').forEach(x=>x.classList.toggle('active',x===b));redraw()};
$('labslider').oninput=e=>{film.labU=Number(e.target.value)/1000;redraw()};
$('front').onclick=()=>{yaw=0;pitch=0;redraw()};$('side').onclick=()=>{yaw=Math.PI/2;pitch=0;redraw()};$('return').onclick=leaveInspect;
canvas.addEventListener('pointerdown',e=>{if(!inspecting||isLab())return;drag=[e.clientX,e.clientY,yaw,pitch];canvas.setPointerCapture(e.pointerId)});canvas.addEventListener('pointermove',e=>{if(!drag||!inspecting)return;yaw=drag[2]+(e.clientX-drag[0])*.006;pitch=Math.max(-1.0,Math.min(1,drag[3]+(e.clientY-drag[1])*.004));redraw()});canvas.addEventListener('pointerup',()=>drag=null);canvas.addEventListener('pointercancel',()=>drag=null);
const names={boot:'通电',overture:'初见',geometry:'圆与切线',switch:'切换',bloom:'共振',gifts:'亲昵',roles:'互换',resonance:'完整',absence:'缺席',erasure:'删改',argument:'异议',recursion:'递归',execute:'执行',reprise:'复原',reveal:'侧转',love:'爱的表达式',coda:'片尾'};
for(const ch of window.MV_SCORE.chapters){const b=document.createElement('button');b.textContent=names[ch.id]||ch.title;b.dataset.chapter=ch.id;b.onclick=()=>seek(ch.start);$('chapters').appendChild(b)}
$('srt').onclick=()=>{function stamp(t){let ms=Math.round(t*1000),s=Math.floor(ms/1000),m=Math.floor(s/60);return `00:${String(m).padStart(2,'0')}:${String(s%60).padStart(2,'0')},${String(ms%1000).padStart(3,'0')}`};let data=window.MV_SCORE.cues.map((c,i)=>`${i+1}\n${stamp(c.start)} --> ${stamp(c.end)}\n${c.en}\n${c.zh}`).join('\n\n');let url=URL.createObjectURL(new Blob(['\ufeff'+data],{type:'text/plain;charset=utf-8'})),a=document.createElement('a');a.href=url;a.download='World_Execute_B05_中英字幕.srt';a.click();setTimeout(()=>URL.revokeObjectURL(url),3000)};
window.addEventListener('keydown',e=>{if(e.key==='Escape'){if(inspecting)leaveInspect();document.body.classList.remove('cinema','sleep');setTimeout(resize,60);return}if(['INPUT','TEXTAREA','SELECT'].includes(e.target.tagName))return;if(e.code==='Space'){e.preventDefault();togglePlay()}else if(e.key.toLowerCase()==='f')cinema();else if(e.key==='ArrowLeft'){e.preventDefault();seek(time-5)}else if(e.key==='ArrowRight'){e.preventDefault();seek(time+5)}else if(e.key.toLowerCase()==='m')$('mute').click();else if(e.key.toLowerCase()==='r'){seek(0);play()}});
window.addEventListener('pointermove',wake);window.addEventListener('resize',resize);document.addEventListener('fullscreenchange',()=>{if(!document.fullscreenElement)document.body.classList.remove('cinema','sleep');setTimeout(resize,60)});document.addEventListener('visibilitychange',()=>{if(document.hidden&&playing)pause()});
audio.addEventListener('ended',()=>{playing=false;time=film.duration;icon();updateUI(true);redraw()});audio.addEventListener('error',()=>{playing=false;icon();toast('内嵌音轨未能解码。请用 Chrome、Edge 或 Safari 打开。')});
window.renderFrame=(t,opts={})=>{frozen=true;cancelAnimationFrame(raf);if(canvas.width!==(opts.width||1920))canvas.width=opts.width||1920;if(canvas.height!==(opts.height||1080))canvas.height=opts.height||1080;time=t;return film.render(t,{captions:opts.captions??2})};
window.setFilmTime=t=>seek(t);
window.__filmReady=true;
$('total').textContent=format(Math.round(film.duration));$('scrub').max=film.duration;
if(EXPORT){document.body.classList.add('export');canvas.width=1920;canvas.height=1080;film.render(0);}else{resize();updateUI(true);requestAnimationFrame(loop)}
})();
