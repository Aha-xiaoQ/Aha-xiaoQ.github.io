/* B04 circuit models. Pure absolute-time functions; no frame-to-frame integration.
 * SI units unless explicitly called `musicTime`. See CIRCUITS.md for assumptions.
 */
'use strict';
(function(root){
const TAU=2*Math.PI, clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
const R=Object.freeze({rms:6,f:50,rs:22,rl:470,c:100e-6,vd:.65,dt:2.5e-6,connect:.030,slow:50,start:44.4});
const BRIDGE=Object.freeze({
 nodes:{A:[800,484],P:[952,304],B:[1104,484],N:[952,664]},
 diodes:[{id:'D1',a:'A',k:'P'},{id:'D2',a:'B',k:'P'},{id:'D3',a:'N',k:'A'},{id:'D4',a:'N',k:'B'}],
 branches:[['P','RL','N'],['P','S2','C1','N'],['A','RS','V1','B']]
});
function source(t){return R.rms*Math.SQRT2*Math.sin(TAU*R.f*t)}
function unfiltered(t){return Math.max(0,Math.abs(source(t))-2*R.vd)/(1+R.rs/R.rl)}
function slope(t,v){return (Math.max(0,(Math.abs(source(t))-2*R.vd-v)/R.rs)-v/R.rl)/R.c}
function createRectifier(dt=R.dt,end=.09){
 const n=Math.ceil((end-R.connect)/dt)+1,tab=new Float64Array(n);let v=0;
 for(let i=1;i<n;i++){const t=R.connect+(i-1)*dt,k1=slope(t,v),k2=slope(t+dt/2,v+dt*k1/2),k3=slope(t+dt/2,v+dt*k2/2),k4=slope(t+dt,v+dt*k3);v=Math.max(0,v+dt*(k1+2*k2+2*k3+k4)/6);tab[i]=v;}
 function at(te){const connected=te>=R.connect;let vc=0;
  if(connected){const q=clamp((te-R.connect)/dt,0,n-1),i=Math.floor(q),k=Math.min(n-1,i+1);vc=tab[i]+(tab[k]-tab[i])*(q-i);}
  const vin=source(te),vload=connected?vc:unfiltered(te),id=Math.max(0,(Math.abs(vin)-2*R.vd-vload)/R.rs),il=vload/R.rl,ic=connected?id-il:0;
  const pair=id>1e-7?(vin>=0?['D1','D4']:['D2','D3']):[];
  return {te,vin,raw:unfiltered(te),vload,vc,id,il,ic,connected,positive:vin>=0,pair,charging:ic>1e-7,discharging:ic<-1e-7,sourceCurrent:Math.sign(vin)*id};
 }
 return {at,params:R,table:tab,dt};
}
const powerParams=Object.freeze({vdd:3.3,threshold:2.9,tau:.01,delay:.020,on:.0032,slow:50,cd:100e-9,rpull:10000});
function power(musicTime){const P=powerParams,te=musicTime/P.slow,d=Math.max(0,te-P.on),v=te<P.on?0:P.vdd*(1-Math.exp(-d/P.tau)),cross=P.on-P.tau*Math.log(1-P.threshold/P.vdd),released=te>=cross+P.delay;
 return {te,v,released,reset:released?v:0,cross,release:cross+P.delay,clockEnabled:released,idec:te<P.on?0:P.cd*P.vdd/P.tau*Math.exp(-d/P.tau)};
}
const I2C=Object.freeze({vdd:3.3,rp:4700,cb:50e-12,frequency:100000,byte:0xA2,address:0x51,period:1e-5,end:11.5});
function busEvents(ack=false){
 const scl=[[0,1],[1,0]],sda=[[0,1],[.5,0]];
 for(let i=0;i<9;i++){if(i>0)scl.push([1+i,0]);scl.push([1.5+i,1]);const bit=i<8?(I2C.byte>>(7-i))&1:ack?0:1;sda.push([1.1+i,bit]);}
 scl.push([10,0],[10.5,1]);sda.push([10.1,0],[10.95,1]);
 return {scl,sda};
}
function logical(events,x){let state=1;for(const e of events){if(e[0]>x)break;state=e[1];}return state;}
function voltage(events,units){let state=1,last=0,edgeFrom=I2C.vdd,voltage=I2C.vdd;const tau=I2C.rp*I2C.cb/I2C.period;
 for(let i=1;i<events.length&&events[i][0]<=units;i++){const e=events[i];voltage=state?I2C.vdd-(I2C.vdd-edgeFrom)*Math.exp(-(e[0]-last)/tau):0;if(e[1]===state)continue;edgeFrom=voltage;last=e[0];state=e[1];}
 return state?I2C.vdd-(I2C.vdd-edgeFrom)*Math.exp(-(units-last)/tau):0;
}
const eventsN=busEvents(false),eventsA=busEvents(true);
function bus(units,ack=false){const e=ack?eventsA:eventsN;return {units,scl:voltage(e.scl,units),sda:voltage(e.sda,units),sclLogic:logical(e.scl,units),sdaLogic:logical(e.sda,units),bit:units>=1&&units<10?Math.floor(units-1):-1,ack,ackSample:units>=9.75,stopped:units>=10.95,word:I2C.byte};}
const XY=Object.freeze({f1:100,f2start:200,ramp:.075,amp:2.5,slow:50,start:103.48});
function xyAt(te){const P=XY,q=clamp(te/P.ramp),area=q*q*q-.5*q*q*q*q;let cycles;
 if(te<0)cycles=P.f2start*te;else if(te<=P.ramp)cycles=200*te-100*P.ramp*area;else cycles=150*P.ramp+100*(te-P.ramp);
 const phi0=Math.PI/2-TAU*50*P.ramp,px=TAU*100*te,py=TAU*cycles+phi0,fy=te<0?200:te>P.ramp?100:200-100*(q*q*(3-2*q));
 return {te,x:P.amp*Math.sin(px),y:P.amp*Math.sin(py),phaseX:px,phaseY:py,fy,fx:100,locked:te>=P.ramp,delta:py-px};
}
const HOLD=Object.freeze({start:47.65,open:49.57,f:100,amp:2.5,c:1e-9,slow:50});
function trackHold(musicTime){const te=(musicTime-HOLD.start)/HOLD.slow,ts=(HOLD.open-HOLD.start)/HOLD.slow,vin=HOLD.amp*Math.cos(TAU*HOLD.f*(te-ts)),closed=musicTime<HOLD.open;return {te,vin,vc:closed?vin:HOLD.amp,closed,ic:closed?-HOLD.c*HOLD.amp*TAU*HOLD.f*Math.sin(TAU*HOLD.f*(te-ts)):0};}
const rises=[];const anchors=[147.65,151.36,155.07,158.90];for(let j=0;j<3;j++)for(let k=0;k<4;k++)rises.push(anchors[j]+(anchors[j+1]-anchors[j])*k/4);
function counter(t){let n=0,last=-Infinity;for(const a of rises){if(a>t)break;n++;last=a;}const index=n%6,q=Array.from({length:6},(_,i)=>i===index?1:0),previous=Array.from({length:6},(_,i)=>i===(n+5)%6?1:0);return {edges:n,last,index,q,previous,clk:t>=last&&t<last+.18?1:0,since:t-last};}
const Model={rectifierParams:R,bridge:BRIDGE,source,unfiltered,createRectifier,power,powerParams,I2C,bus,busEvents,logical,voltage,XY,xyAt,trackHold,HOLD,counter,rises};
root.CircuitModel=Model;if(typeof module!=='undefined'&&module.exports)module.exports=Model;
})(typeof window!=='undefined'?window:globalThis);
