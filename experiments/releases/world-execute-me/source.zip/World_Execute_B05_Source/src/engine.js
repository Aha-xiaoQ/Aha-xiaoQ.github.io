/*
 * B02 / Coordinate Press
 * Deterministic drawing primitives. No external assets, image frames, or GPU libraries.
 * The same parametric helix and derivative used by the B baseline are preserved.
 */
'use strict';
(() => {
const TAU=2*Math.PI,PI=Math.PI;
const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
const lerp=(a,b,q)=>a+(b-a)*q;
const smooth=(a,b,x)=>{const q=clamp((x-a)/(b-a));return q*q*(3-2*q)};
const ease=q=>{q=clamp(q);return q*q*q*(10+q*(-15+6*q))};
const phase=(t,a,b)=>clamp((t-a)/(b-a));
const fract=v=>v-Math.floor(v);
const hash=(x,y=0,s=0)=>fract(Math.sin(x*127.1+y*311.7+s*74.7)*43758.5453123);
const V=(x=0,y=0,z=0)=>[x,y,z];
const add=(a,b)=>a.map((x,i)=>x+b[i]);
const sub=(a,b)=>a.map((x,i)=>x-b[i]);
const mul=(a,k)=>a.map(x=>x*k);
const dot=(a,b)=>a.reduce((s,v,i)=>s+v*b[i],0);
const cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
const norm=a=>mul(a,1/(Math.hypot(...a)||1));
const vmix=(a,b,q)=>a.map((x,i)=>lerp(x,b[i],q));
const samples=(fn,n=160)=>Array.from({length:n+1},(_,i)=>fn(i/n));
const rotZ=(p,a)=>[p[0]*Math.cos(a)-p[1]*Math.sin(a),p[0]*Math.sin(a)+p[1]*Math.cos(a),p[2]];
const H=s=>[1.5*Math.cos(4*PI*s),1.5*Math.sin(4*PI*s),6.8*(s-.5)];
const Hd=s=>[-6*PI*Math.sin(4*PI*s),6*PI*Math.cos(4*PI*s),6.8];
const tangent=(s=.625)=>{const p=H(s),d=norm(Hd(s));const n=norm(sub([0,1,0],mul(d,d[1])));return {p,d,n}};
const PAL={
 paper:{key:'paper',bg:'#f0ead9',ink:'#193732',red:'#bd4935',teal:'#267c73',gold:'#a78245',faint:'#bbbca9',muted:'#637169',wash:'#e6dfcb'},
 night:{key:'night',bg:'#142b2a',ink:'#efe6ce',red:'#ed795e',teal:'#91cbbb',gold:'#d3b678',faint:'#4e6960',muted:'#b3bdac',wash:'#203b34'},
 red:{key:'red',bg:'#b74432',ink:'#f4e9d1',red:'#f1c7a0',teal:'#143f39',gold:'#e8c999',faint:'#c96d55',muted:'#f2d9bf',wash:'#ab3d2f'}
};
const MONO='"DejaVu Sans Mono", "Liberation Mono", Consolas, monospace';
const SANS='"Noto Sans CJK SC", "Microsoft YaHei", "PingFang SC", Arial, sans-serif';
const DISPLAY='"DejaVu Sans", "Arial Black", Arial, sans-serif';
const SERIF='Georgia, "Times New Roman", serif';
function trace(ctx,pts,closed=false){if(!pts.length)return;ctx.beginPath();ctx.moveTo(pts[0][0],pts[0][1]);for(let i=1;i<pts.length;i++)ctx.lineTo(pts[i][0],pts[i][1]);if(closed)ctx.closePath()}
function arcPoints(x,y,r,a0=0,a1=TAU,n=160,ry=r){return samples(s=>[x+Math.cos(lerp(a0,a1,s))*r,y+Math.sin(lerp(a0,a1,s))*ry],n)}
function starPoints(x,y,r,rot=0,petals=4,roundness=.34,n=88){return samples(u=>{let a=u*TAU+rot,q=roundness+(1-roundness)*Math.pow(Math.abs(Math.cos(petals*u*PI)),1.55);return [x+Math.cos(a)*r*q,y+Math.sin(a)*r*q]},n)}
function bezier(a,b,c,d,n=100){return samples(t=>{let s=1-t;return [s*s*s*a[0]+3*s*s*t*b[0]+3*s*t*t*c[0]+t*t*t*d[0],s*s*s*a[1]+3*s*s*t*b[1]+3*s*t*t*c[1]+t*t*t*d[1]]},n)}
function maskColor(id,shade=1){let v=Math.round(clamp(shade,.06,1)*255);return id==='red'?`rgb(${v},0,0)`:id==='teal'?`rgb(0,${v},0)`:id==='gold'?`rgb(${v},${v},0)`:`rgb(0,0,${v})`}
class GlyphSurface{
 constructor(){this.dx=10;this.dy=14;this.w=192;this.h=78;this.c=document.createElement('canvas');this.c.width=this.w;this.c.height=this.h;this.ctx=this.c.getContext('2d',{willReadFrequently:true});this.atlases=new Map();this.chars=['.',':',';','+','=','o','O','#','@','M'];this.tone=document.createElement('canvas');this.tone.width=this.w;this.tone.height=this.h;this.tc=this.tone.getContext('2d');}
 clear(){this.ctx.setTransform(1,0,0,1,0,0);this.ctx.clearRect(0,0,this.w,this.h);this.ctx.setTransform(1/this.dx,0,0,1/this.dy,0,0);this.ctx.globalAlpha=1;this.ctx.globalCompositeOperation='source-over';}
 atlas(p){if(this.atlases.has(p.key))return this.atlases.get(p.key);let c=document.createElement('canvas');c.width=12*10;c.height=18*4;let x=c.getContext('2d');x.textAlign='center';x.textBaseline='middle';x.font=`700 14px ${MONO}`;for(let k=0;k<4;k++){x.fillStyle=p[['red','teal','ink','gold'][k]];this.chars.forEach((s,i)=>x.fillText(s,i*12+6,k*18+9));}this.atlases.set(p.key,c);return c}
 poly(pts,id='ink',shade=1){trace(this.ctx,pts,true);this.ctx.fillStyle=maskColor(id,shade);this.ctx.fill()}
 line(pts,width=10,id='ink',shade=1){trace(this.ctx,pts);this.ctx.lineWidth=width;this.ctx.lineCap='round';this.ctx.lineJoin='round';this.ctx.strokeStyle=maskColor(id,shade);this.ctx.stroke()}
 circle(x,y,r,id='red',shade=1){this.ctx.beginPath();this.ctx.arc(x,y,Math.max(0,r),0,TAU);this.ctx.fillStyle=maskColor(id,shade);this.ctx.fill()}
 text(s,x,y,size,id='ink',opts={}){const c=this.ctx;c.save();c.translate(x,y);c.scale(opts.sx||1,1);c.textBaseline=opts.baseline||'middle';c.textAlign=opts.align||'center';c.font=`${opts.weight||900} ${size}px ${opts.font||DISPLAY}`;c.fillStyle=maskColor(id,opts.shade||1);c.fillText(s,0,0);c.restore()}
 flush(ctx,p,alpha=1){const data=this.ctx.getImageData(0,0,this.w,this.h).data,atlas=this.atlas(p);ctx.save();ctx.globalAlpha=alpha;
 const tone=this.tc.createImageData(this.w,this.h),colors=['red','teal','ink','gold'].map(k=>[1,3,5].map(i=>parseInt(p[k].slice(i,i+2),16)));
 for(let i=0;i<data.length;i+=4){let a=data[i+3];if(a<20)continue;let r=data[i],g=data[i+1],b=data[i+2],v=Math.max(r,g,b),k=(r>g*.8&&g>r*.8&&r>b*1.25)?3:r>g&&r>b?0:g>b?1:2,cc=colors[k];tone.data[i]=cc[0];tone.data[i+1]=cc[1];tone.data[i+2]=cc[2];tone.data[i+3]=a*(p.key==='paper'?(.17+.28*v/255):(.12+.25*v/255));}
 this.tc.putImageData(tone,0,0);ctx.imageSmoothingEnabled=true;ctx.drawImage(this.tone,0,0,this.w*this.dx,this.h*this.dy);
 for(let y=0;y<this.h;y++){for(let x=0;x<this.w;x++){let i=(y*this.w+x)*4,a=data[i+3];if(a<36)continue;let r=data[i],g=data[i+1],b=data[i+2];let v=Math.max(r,g,b);if(v<18)continue;let k=(r>g*.8&&g>r*.8&&r>b*1.25)?3:r>g&&r>b?0:g>b?1:2;let density=clamp((v/255)*(.5+.5*a/255));let j=Math.min(9,Math.floor(density*9.5+(hash(x,y)*.55)));ctx.drawImage(atlas,j*12,k*18,12,18,x*this.dx-1,y*this.dy-2,12,18)}}ctx.restore();}
}
class Press{
 constructor(canvas){this.canvas=canvas;this.ctx=canvas.getContext('2d',{alpha:false});if(!this.ctx)throw Error('Canvas 2D unavailable');this.g=new GlyphSurface();this.p=PAL.paper;this.faces=[];this.fore=[];this.cam={};this.paper=this.makePaper();this.lastStats={};this.captionMode=2;}
 makePaper(){let c=document.createElement('canvas');c.width=320;c.height=320;let x=c.getContext('2d');let d=x.createImageData(320,320);for(let i=0;i<320*320;i++){let h=hash(i%320,Math.floor(i/320),16);let v=h>.52?255:0;d.data[i*4]=d.data[i*4+1]=d.data[i*4+2]=v;d.data[i*4+3]=h>.9?15:h>.35?6:0;}x.putImageData(d,0,0);return c}
 begin(p='paper',t=0){this.p=PAL[p];this.t=t;this.ctx.setTransform(this.canvas.width/1920,0,0,this.canvas.height/1080,0,0);this.ctx.globalAlpha=1;this.ctx.globalCompositeOperation='source-over';this.ctx.setLineDash([]);this.ctx.fillStyle=this.p.bg;this.ctx.fillRect(0,0,1920,1080);this.faces=[];this.fore=[];this.g.clear();this.camera();}
 camera(o={}){this.cam={yaw:0,pitch:0,roll:0,scale:170,cx:960,cy:472,depth:0,...o}}
 project(p){let c=this.cam,co=Math.cos(c.yaw),si=Math.sin(c.yaw);let x=p[0]*co+p[2]*si,z=-p[0]*si+p[2]*co;let y=p[1]*Math.cos(c.pitch)-z*Math.sin(c.pitch);z=p[1]*Math.sin(c.pitch)+z*Math.cos(c.pitch);let xx=x*Math.cos(c.roll)-y*Math.sin(c.roll);y=x*Math.sin(c.roll)+y*Math.cos(c.roll);let ss=c.scale*(c.depth?c.depth/Math.max(.2,c.depth-z):1);return [c.cx+xx*ss,c.cy-y*ss,z,ss]}
 rotateNormal(p){const c=this.cam,x=p[0]*Math.cos(c.yaw)+p[2]*Math.sin(c.yaw),z=-p[0]*Math.sin(c.yaw)+p[2]*Math.cos(c.yaw);return [x,p[1]*Math.cos(c.pitch)-z*Math.sin(c.pitch),p[1]*Math.sin(c.pitch)+z*Math.cos(c.pitch)]}
 face(points,id='red',shade=1){const ps=points.map(p=>this.project(p));this.faces.push({ps,id,shade,z:ps.reduce((s,p)=>s+p[2],0)/ps.length})}
 tube(points,r=.13,id='red',opts={}){const sides=opts.sides||7,N=points.length,closed=opts.closed||false,rings=[];for(let i=0;i<N;i++){const a=points[Math.max(0,i-1)],b=points[Math.min(N-1,i+1)],d=norm(sub(b,a));let reference=Math.abs(d[2])<.88?[0,0,1]:[0,1,0],n=norm(cross(d,reference)),bin=norm(cross(d,n));rings.push(Array.from({length:sides},(_,j)=>add(points[i],mul(add(mul(n,Math.cos(j*TAU/sides)),mul(bin,Math.sin(j*TAU/sides))),typeof r==='function'?r(i/(N-1)):r))));}
  for(let i=0;i<N-1;i++){if(opts.gap&&i/(N-1)>opts.gap[0]&&i/(N-1)<opts.gap[1])continue;for(let j=0;j<sides;j++){let a=rings[i][j],b=rings[i][(j+1)%sides],cc=rings[i+1][(j+1)%sides],d=rings[i+1][j];let n=this.rotateNormal(norm(cross(sub(b,a),sub(d,a))));let shade=clamp(.43+.47*Math.max(0,dot(n,norm([-.4,.65,1])))+.12*(i/(N-1)),.26,1);this.face([a,b,cc,d],id,shade)}}}
 ribbon(fn,halfWidth=.35,id='red',N=150){for(let i=0;i<N;i++){let s=i/N,ss=(i+1)/N;const pts=[fn(s,-halfWidth),fn(s,halfWidth),fn(ss,halfWidth),fn(ss,-halfWidth)];let n=this.rotateNormal(norm(cross(sub(pts[1],pts[0]),sub(pts[3],pts[0]))));this.face(pts,id,clamp(.33+.62*Math.abs(dot(n,norm([-.35,.7,1]))),.25,1))}}
 solid(pts,id='red',shade=1){this.g.poly(pts,id,shade)}
 after(fn){this.fore.push(fn)}
 line(pts,color='ink',w=2,a=1,dash=[]){const c=this.ctx;c.save();c.globalAlpha*=a;c.strokeStyle=this.p[color]||color;c.lineWidth=w;c.lineJoin='round';c.lineCap='round';c.setLineDash(dash);trace(c,pts);c.stroke();c.restore()}
 circle(x,y,r,color='ink',w=2,a=1,dash=[]){this.line(arcPoints(x,y,r),color,w,a,dash)}
 flat(pts,color='ink',a=1){const c=this.ctx;c.save();c.globalAlpha*=a;c.fillStyle=this.p[color]||color;trace(c,pts,true);c.fill();c.restore()}
 label(s,x,y,size=20,color='ink',opts={}){let c=this.ctx;c.save();c.translate(x,y);if(opts.rotation)c.rotate(opts.rotation);c.scale(opts.sx||1,opts.sy||1);c.globalAlpha*=opts.alpha??1;c.fillStyle=this.p[color]||color;c.strokeStyle=this.p[color]||color;c.textAlign=opts.align||'center';c.textBaseline=opts.baseline||'middle';c.font=`${opts.weight||400} ${size}px ${opts.font||MONO}`;if(opts.stroke){c.lineWidth=opts.stroke;c.strokeText(s,0,0)}else if(opts.tracking){const widths=[...s].map(ch=>c.measureText(ch).width+opts.tracking),total=widths.reduce((a,b)=>a+b,0)-opts.tracking;let pos=opts.align==='left'?0:opts.align==='right'?-total:-total/2;c.textAlign='left';[...s].forEach((ch,i)=>{c.fillText(ch,pos,0);pos+=widths[i]})}else{c.fillText(s,0,0)}c.restore()}
 rule(x1,y1,x2,y2,a=.32){this.line([[x1,y1],[x2,y2]],'ink',1,a)}
 cross(x,y,size=9,color='ink',alpha=.35){this.line([[x-size,y],[x+size,y]],color,1.3,alpha);this.line([[x,y-size],[x,y+size]],color,1.3,alpha)}
 dot(x,y,r=3,color='ink',a=1){let c=this.ctx;c.save();c.globalAlpha*=a;c.fillStyle=this.p[color]||color;c.beginPath();c.arc(x,y,Math.max(.01,r),0,TAU);c.fill();c.restore()}
 me(x,y,r=65,rot=0,gap=.85,opts={}){const points=arcPoints(x,y,r,rot+gap,rot+TAU-gap,112,r*(opts.sy||1));this.g.line(points,opts.width||r*.30,'red',opts.shade||.92);if(opts.edges!==false)this.after(()=>{this.line(points,'red',1.8,.85);let a=points[0],b=points.at(-1);this.dot(...a,Math.max(2,r*.045),'red');this.dot(...b,Math.max(2,r*.045),'red')});}
 star(x,y,r=30,rot=0,opts={}){let pts=starPoints(x,y,r,rot,4,opts.roundness||.30);if(opts.hollow){this.after(()=>this.line(pts,opts.color||'muted',opts.width||1.8,opts.alpha??.75));return}this.g.poly(pts,opts.color||'teal',.9);this.after(()=>{this.line(pts,opts.color||'teal',1.5,opts.alpha??1);this.dot(x-r*.12,y-r*.1,Math.max(1.4,r*.04),'bg',.85)});}
 ringText(s,x,y,r,start=-PI/2,color='ink',size=14,tracking=.07,alpha=.65){let c=this.ctx;c.save();c.fillStyle=this.p[color];c.globalAlpha=alpha;c.font=`${size}px ${MONO}`;c.textAlign='center';c.textBaseline='middle';[...s].forEach((ch,i)=>{let a=start+i*tracking;c.save();c.translate(x+Math.cos(a)*r,y+Math.sin(a)*r);c.rotate(a+PI/2);c.fillText(ch,0,0);c.restore()});c.restore()}
 rings(x,y,r,count=4,spacing=16,color='ink',alpha=.25){for(let i=0;i<count;i++)this.circle(x,y,r+i*spacing,color,i===0?1.5:.8,alpha*(1-i/(count+1)))}
 grid(x,y,w,h,step=40,alpha=.22){for(let xx=x;xx<=x+w;xx+=step)for(let yy=y;yy<=y+h;yy+=step){this.cross(xx,yy,2,'faint',alpha)}}
 glyphField(x,y,w,h,t=0,id='ink',density=.14,fade=1){const c=this.ctx;c.save();c.font=`13px ${MONO}`;c.textAlign='center';c.fillStyle=this.p[id];const chars=['.','+','0','1',':','/',';'];for(let yy=y;yy<y+h;yy+=26)for(let xx=x;xx<x+w;xx+=20){let q=hash(xx,yy);if(q<density){c.globalAlpha=(.16+.34*q)*fade;c.fillText(chars[Math.floor(hash(xx,yy,2)*chars.length)],xx,yy)}}c.restore()}
 finishGlyph(){this.faces.sort((a,b)=>a.z-b.z);for(const f of this.faces)this.g.poly(f.ps,f.id,f.shade);this.g.flush(this.ctx,this.p);for(const fn of this.fore)fn();this.fore=[];this.lastStats.faces=this.faces.length;}
 printGrain(){const c=this.ctx;c.save();c.globalAlpha=.62;c.fillStyle=c.createPattern(this.paper,'repeat');c.fillRect(0,0,1920,1080);c.restore()}
 margins(chapter='',n=''){const c=this.ctx;this.rule(80,83,220,83,.5);this.label('MILI  /  WORLD.EXECUTE(ME);',80,54,13,'muted',{align:'left',tracking:1.4});if(chapter)this.label(chapter.toUpperCase(),1840,54,13,'muted',{align:'right',tracking:2});this.cross(80,840,7,'muted',.35);this.cross(1840,840,7,'muted',.35);if(n)this.label(n,80,808,13,'muted',{rotation:-PI/2,alpha:.6});}
 caption(t,mode=2){if(!mode)return null;let cue=window.MV_SCORE.cues.find(c=>t>=c.start&&t<c.end);if(!cue)return null;const c=this.ctx;let fade=Math.min(1,(t-cue.start)/.085,(cue.end-t)/.07);fade=clamp(fade);c.save();c.globalAlpha=fade;const p=this.p;let gg=c.createLinearGradient(0,872,0,916);gg.addColorStop(0,p.bg+'00');gg.addColorStop(1,p.bg);c.fillStyle=gg;c.fillRect(0,872,1920,48);c.fillStyle=p.bg;c.fillRect(0,920,1920,160);let en=cue.en;let size=32;c.font=`${size}px ${MONO}`;if(c.measureText(en).width>1530)size*=1530/c.measureText(en).width;this.rule(898,906,930,906,.38);this.dot(960,906,2.5,'red',.85);this.rule(990,906,1022,906,.38);this.label(en,960,946,size,'ink',{font:MONO,weight:400});if(mode===2)this.label(cue.zh,960,993,29,'ink',{font:SANS,weight:400,alpha:.94});c.restore();this.lastStats.subtitle=cue.en;return cue}
}
window.PressEngine={Press,TAU,PI,clamp,lerp,smooth,ease,phase,fract,hash,V,add,sub,mul,dot,cross,norm,vmix,samples,rotZ,H,Hd,tangent,PAL,MONO,SANS,DISPLAY,SERIF,trace,arcPoints,starPoints,bezier};
})();
