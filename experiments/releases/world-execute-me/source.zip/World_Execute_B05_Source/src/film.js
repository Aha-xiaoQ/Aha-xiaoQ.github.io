/* B02 — 坐标之外 / a two-colour, programmable letterpress music film. */
'use strict';
(() => {
const E=window.PressEngine;
const {Press,TAU,PI,clamp,lerp,smooth,ease,phase,fract,hash,V,add,sub,mul,norm,vmix,samples,rotZ,H,Hd,tangent,MONO,SANS,DISPLAY,SERIF,trace,arcPoints,starPoints,bezier}=E;
const SHOTS=[
[0,'boot','paper','01 / CREATION'],[14.8,'overture','paper','01 / CREATION'],
[29.73,'points','paper','02 / DEVOTION'],[33.4,'circle','paper','02 / DEVOTION'],[37.07,'wave','paper','02 / DEVOTION'],[40.65,'infinity','paper','02 / DEVOTION'],
[44.4,'current','night','02 / DEVOTION'],[47.65,'blind','night','02 / DEVOTION'],[51.4,'time','paper','02 / DEVOTION'],[55.07,'unite','paper','02 / DEVOTION'],
[59.23,'bloom','paper','02 / DEVOTION'],[62.65,'satisfaction','paper','02 / DEVOTION'],[66.65,'run','red','02 / DEVOTION'],[70.15,'simulation','night','02 / DEVOTION'],
[74.07,'eggplant','paper','03 / INTIMACY'],[77.57,'tomato','paper','03 / INTIMACY'],[81.4,'cat','paper','03 / INTIMACY'],[85.07,'god','paper','03 / INTIMACY'],
[88.65,'gender','paper','03 / INTIMACY'],[92.07,'day','night','03 / INTIMACY'],[95.48,'role','paper','03 / INTIMACY'],[99.4,'trance','night','03 / INTIMACY'],
[103.48,'resonance','paper','03 / INTIMACY'],[110.9,'absence','night','04 / ISOLATION'],[118.32,'erasure','paper','04 / ISOLATION'],[125.65,'argument','red','04 / ISOLATION'],
[134.1,'recursion','night','05 / EXECUTION'],[147.65,'execute','night','05 / EXECUTION'],[158.9,'count','paper','05 / EXECUTION'],[162.65,'reprise','red','05 / EXECUTION'],
[169.82,'restore','paper','05 / EXECUTION'],[173.65,'reveal','paper','05 / EXECUTION'],[177.23,'love','night','06 / LOVE'],[188.48,'freedom','paper','06 / LOVE'],[195.2,'coda','paper','06 / LOVE'],[205.81,'end','night','06 / LOVE']
].map((r,i,a)=>({start:r[0],id:r[1],paper:r[2],chapter:r[3],end:a[i+1]?.[0]??211.925333,index:i}));
const BROKEN=[.48,.585];
function ring3(r=1.5,z=0,n=160){return samples(u=>[r*Math.cos(TAU*u),r*Math.sin(TAU*u),z],n)}
function heart3(s=1,n=240){return samples(u=>{let a=u*TAU;return [s*16*Math.sin(a)**3/10,s*(13*Math.cos(a)-5*Math.cos(2*a)-2*Math.cos(3*a)-Math.cos(4*a))/10,0]},n)}
function polylineResample(pts,n=240){let ls=[0];for(let i=1;i<pts.length;i++)ls.push(ls.at(-1)+Math.hypot(...sub(pts[i],pts[i-1])));let total=ls.at(-1),j=1;return samples(u=>{let d=u*total;while(j<ls.length-1&&d>ls[j])j++;return vmix(pts[j-1],pts[j],clamp((d-ls[j-1])/(ls[j]-ls[j-1]||1)))},n)}
function petals2(x,y,r,angle=0,w=.44){let a=bezier([0,0],[r*.27,-r*w],[r*1.05,-r*w*.58],[r,0],38),b=bezier([r,0],[r*.97,r*w*.80],[r*.20,r*w],[0,0],38);return [...a,...b].map(p=>[x+p[0]*Math.cos(angle)-p[1]*Math.sin(angle),y+p[0]*Math.sin(angle)+p[1]*Math.cos(angle)])}
function clockHand(t){return TAU*fract(t/3.7)-PI/2}
class Film extends Press{
 constructor(canvas){super(canvas);this.duration=window.MV_SCORE.duration;this.shots=SHOTS;this.forceOrbit=null;this.filmTitle='坐标之外';}
 accent(t){const f=window.MV_FEATURES;let lo=0,hi=f.onsets.length;while(lo<hi){let m=(lo+hi)>>1;if(f.onsets[m][0]<=t)lo=m+1;else hi=m}let a=0;for(let i=Math.max(0,lo-3);i<lo;i++){let dt=t-f.onsets[i][0];if(dt>=0)a=Math.max(a,Math.exp(-dt*14)*f.onsets[i][1])}return clamp(a)}
 textureFrame(t,d=.12){this.grid(140,142,1640,672,56,.34);this.glyphField(130,126,1680,690,t,'muted',d,.65)}
 bridge(x,y,r=65,starPresent=true,k=0,broken=false,scale=1){const sp=[x+r*.95,y-r*.65];this.me(x-r*.50,y+r*.12,r,k*.055,.78,{width:r*.3});let q=smooth(.04,.52,fract(k)),bounce=Math.sin(PI*q)*r*.45;let pp=[sp[0]+r*.30*(1-q),sp[1]-bounce];if(starPresent)this.star(pp[0],pp[1],r*.36,k*.4);else this.star(sp[0],sp[1],r*.36,0,{hollow:true,color:'muted',alpha:.45});const rail=bezier([x-r*.43,y+r*.78],[x+r*.42,y+r*.77],[x+r*.55,y-r*.42],[sp[0],sp[1]+r*.36],60);if(!broken)this.g.line(rail,r*.16,'red',.85);else{this.g.line(rail.slice(0,30),r*.16,'red',.85);this.g.line(rail.slice(39),r*.16,'red',.85)}return {sp,pp};}
 bloomShape(x,y,r,t,broken=false,monochrome=false,open=1){
  const n=12;for(let i=0;i<n;i++){let a=i*TAU/n+t*.10;let grow=ease(clamp(open*n-i));if(grow<=0)continue;let rr=r*(.91+.08*Math.sin(t*1.7+i*.65))*grow;let id=monochrome?'red':i%3===0?'teal':'red';if(broken&&i===2)continue;this.g.poly(petals2(x,y,rr,a,.42),id,.54+.39*hash(i,1));const vein=bezier([x,y],[x+Math.cos(a-.16)*rr*.48,y+Math.sin(a-.16)*rr*.48],[x+Math.cos(a+.06)*rr*.78,y+Math.sin(a+.06)*rr*.78],[x+Math.cos(a)*rr,y+Math.sin(a)*rr],36);this.after(()=>this.line(vein,'bg',2.2,.85));}
  this.me(x,y,r*.19,t*.18,.8,{width:r*.064});
 }
 letterpressWord(word,x,y,size=140,id='ink',q=1,opts={}){const letters=[...word],c=this.ctx;c.save();c.font=`900 ${size}px ${DISPLAY}`;let widths=letters.map(ch=>c.measureText(ch).width*(opts.sx||.91)),total=widths.reduce((a,b)=>a+b,0);let xx=x-total/2;for(let i=0;i<letters.length;i++){let k=ease(clamp(q*1.6-i/letters.length*.6));this.g.text(letters[i],xx+widths[i]/2,y+(1-k)*100,size,id,{sx:opts.sx||.91,shade:.85});xx+=widths[i]}c.restore()}
 topic(word,sub='',x=135,y=150){this.label(word,x,y,22,'ink',{align:'left',tracking:3,weight:500});}
 ornament(x,y,r,t,kind='ink',a=.35){this.after(()=>{this.circle(x,y,r,kind,1,a);for(let i=0;i<36;i++){let an=i*TAU/36+t*.025;let a0=r+(i%3===0?0:3),a1=r+(i%3===0?13:7);this.line([[x+Math.cos(an)*a0,y+Math.sin(an)*a0],[x+Math.cos(an)*a1,y+Math.sin(an)*a1]],kind,i%3===0?1.6:.7,a)};});}
 boot(t,u){
  this.textureFrame(t,.05);const beat=this.accent(t);let on=smooth(.1,1.0,t),pair=smooth(4.1,6.8,t),world=smooth(11.1,14.65,t);
  if(t<3.9){let line=samples(k=>[260+k*1400,467+Math.sin(k*TAU*3-t*4)*14*(1-smooth(1.5,2.8,t))],160);this.g.line(line.slice(0,Math.max(2,Math.floor(line.length*on))),6,'red',.82);this.after(()=>{this.label('+',286,409,42,'red');this.label('−',1630,409,42,'teal');});this.me(824,467,69,0,.9,{width:22});this.star(1100-105*smooth(1.75,3.2,t),467,33,t*.1);if(t>1.75){let q=smooth(1.75,2.96,t);for(const side of [-1,1]){let p=arcPoints(960,467,lerp(170,208,q),side>0?-1.02:PI-1.02,side>0?1.02:PI+1.02,80,260*q);this.g.line(p,9,'ink',.74)}}this.topic(t<1.75?'POWER':'PROTECTION','01  /  a place for two');}
  else if(t<7.4){let q=smooth(3.9,6.5,t);for(let i=0;i<24;i++){let angle=i/24*TAU,far=470+90*hash(i,3),r=lerp(far,130,ease(clamp(q*1.7-i*.024)));let px=840+Math.cos(angle)*r,py=470+Math.sin(angle)*r*.7;this.g.circle(px,py,lerp(8,16,q),'red',.4+.5*hash(i,8));}this.star(1180-100*q,467,34+4*beat,t*.1);this.after(()=>this.label('me',840,470,40,'red'));this.topic('OBJECT CREATION','two objects, not a reflection');}
  else if(t<11.15){let q=smooth(7.4,10.5,t);this.me(840,470,140,-.15,.78,{width:44});this.star(1088,440+Math.sin(t*2)*14,42,t*.1);for(let i=0;i<8;i++){let yy=278+i*47;this.g.line([[1298,yy],[1298+164*ease(clamp(q*1.8-i*.1)),yy]],9,i%3===0?'teal':'ink',.60);this.after(()=>this.label(['x','y','z','r','ω','φ','Δ','?'][i],1255,yy,17,'muted'))}this.topic('INITIALIZATION','a rhythm of your own');}
  else {this.bloomShape(960,474,338,t,false,false,world);this.star(960+Math.cos(t*.9)*72,474+Math.sin(t*.9)*72,35,t*.3);for(const side of [-1,1]){let px=960+side*lerp(400,600,world);this.g.line(arcPoints(px,476,32,-PI/2,PI/2,40,264),8,'ink',.58);}this.topic('SIMULATION','let the world begin');}
  this.after(()=>{this.label('(',474,470,125,'muted',{alpha:.35,font:SERIF});this.label(')',1446,470,125,'muted',{alpha:.35,font:SERIF})});
 }
 overture(t,u){
  const lt=t-14.8, beat=this.accent(t);this.textureFrame(t,.08);
  if(lt<7.3){
   let a=smooth(0,2.1,lt),r=lerp(324,388,a)+beat*3;this.bloomShape(960,469,r,t*.5,false,false,.35+.65*a);
   this.ornament(960,469,r+50,t,'ink',.42);
   for(let i=0;i<6;i++){let th=i*TAU/6-lt*.39,rr=lerp(90,238,a)+18*Math.sin(lt*1.3+i);this.star(960+Math.cos(th)*rr,469+Math.sin(th)*rr*.83,20+3*Math.sin(lt+i)**2,th)}
   this.after(()=>{let alpha=smooth(.3,1.2,lt)*(1-smooth(5.4,7.2,lt));this.ctx.save();this.ctx.globalAlpha=alpha;this.ctx.fillStyle=this.p.bg;this.ctx.fillRect(440,424,1040,141);this.label('world.execute(me);',960,478,61,'ink',{font:MONO,weight:500});this.label('坐  标  之  外',960,543,25,'ink',{font:SANS});this.ctx.restore();this.ringText('a shared world is not a shared will  ·  ',960,469,r+29,-1.0+lt*.05,'ink',13,.040,.60);});
  }else{
   let q=ease(smooth(7.3,11.7,lt)),dissolve=smooth(12.0,14.92,lt);this.camera({yaw:q*1.14,pitch:Math.sin(q*PI)*.19,scale:lerp(192,168,q),cx:960,cy:467});
   const pts=samples(s=>{let th=s*4*PI;return [1.5*Math.cos(th),1.5*Math.sin(th),6.8*(s-.5)*q]},220);
   this.tube(pts,.15*(1-dissolve),'red');
   const route=fract(.18+lt*.06),pr=this.project(pts[Math.min(220,Math.floor(route*220))]);this.star(pr[0],pr[1]-34,35,lt*.35);
   for(let i=0;i<36;i++){let th=i*TAU/36,from=[Math.cos(th)*1.5,Math.sin(th)*1.5,6.8*(i/35-.5)*q];let dest=[((i%6)-2.5)*.66,(Math.floor(i/6)-2.5)*.53,0];let pp=this.project(vmix(from,dest,dissolve));if(dissolve>0)this.g.circle(pp[0],pp[1],4+4*dissolve,i%9===0?'teal':'red',.84*dissolve);}
   this.after(()=>{this.label('I',166,473,50,'red',{font:SERIF});this.label('II',1754,473,50,'teal',{font:SERIF});});
  }
 }
 points(t,u){
  this.topic('DIMENSION','0 → 1 → 2 → 3');this.textureFrame(t,.05);let q=ease(smooth(.12,.8,u));this.camera({yaw:.52*q,pitch:.25*q,scale:185,cx:1000,cy:475});
  const dims=smooth(.06,.70,u);
  for(let z=-1;z<=1;z++)for(let y=-2;y<=2;y++)for(let x=-3;x<=3;x++){
    let p=[x*.65, y*.64*smooth(.1,.57,u),z*1.4*smooth(.48,.93,u)];let a=this.project(p);this.g.circle(a[0],a[1],5.5+2.8*Math.sin(x+y+z+t)**2,(x===0&&y===0&&z===0)?'teal':'red',.44+.45*(z+1)/2);
    if(x<3){let b=this.project([p[0]+.65,p[1],p[2]]);this.after(()=>this.line([a,b],'ink',.75,.23))}
    if(y<2&&u>.18){let b=this.project([p[0],p[1]+.64*smooth(.1,.57,u),p[2]]);this.after(()=>this.line([a,b],'ink',.75,.18))}
    if(z<1&&u>.45){let b=this.project([p[0],p[1],p[2]+1.4*smooth(.48,.93,u)]);this.after(()=>this.line([a,b],'ink',.75,.21))}
  }
  const cp=this.project([1.95,1.28*smooth(.1,.57,u),1.4*smooth(.48,.93,u)]);this.star(cp[0],cp[1],36,t*.2);
  this.after(()=>{this.label(String(Math.min(3,Math.floor(u*4))),285,495,180,'ink',{font:SERIF,alpha:.82});this.label('dimensions',290,635,15,'muted',{tracking:2});});
 }
 circleScene(t,u){
  this.topic('CIRCUMFERENCE','the same curve, seen head-on');this.textureFrame(t,.04);
  this.camera({yaw:0,pitch:0,scale:184+10*Math.sin(u*PI),cx:960,cy:464});this.tube(samples(H,200),.145,'red');
  const a=TAU*(u*.5+.19),cp=[1.5*Math.cos(a),1.5*Math.sin(a),.8];const p=this.project(cp);this.star(p[0],p[1],37,a);
  this.ornament(960,464,360,t,'ink',.45);this.after(()=>{this.ringText('C = 2πr  ·  C = 2πr  ·  C = 2πr  ·  ',960,464,327,-t*.15,'ink',15,.053,.78);this.label('2πr',1436,479,84,'ink',{font:SERIF});this.rule(1234,471,1330,471,.35);this.dot(690,464,7,'red');this.label('me',498,468,24,'red');this.label('you',p[0]+58,p[1],17,'teal',{align:'left'});});
 }
 wave(t,u){
  this.topic('TANGENTS','a different view; a real contact');let turn=ease(smooth(.05,.69,u));this.camera({yaw:turn*PI/2,pitch:0,scale:184-27*turn,cx:960,cy:496});
  this.tube(samples(H,200),.145,'red');const td=tangent(.625),contact=add(td.p,mul(td.n,.145)),center=add(td.p,mul(td.n,.145+.24));
  const k=smooth(.32,.73,u),fall=(1-k)*1.4;const cp=this.project(add(center,[0,fall,0]));this.star(cp[0],cp[1],.24*this.cam.scale,t*.10*(1-k));
  if(k>0){let a=this.project(sub(contact,mul(td.d,1.35*k))),b=this.project(add(contact,mul(td.d,1.35*k)));this.after(()=>this.line([a,b],'ink',3.5,.9));}
  this.after(()=>{const c=this.project(td.p);this.dot(c[0],c[1],5,'red');if(u>.65){this.rings(cp[0],cp[1],44+(u-.65)*130,2,18,'teal',.38*(1-smooth(.70,1,u)));}this.label('dP / dθ',1450,238,25,'muted',{font:SERIF});this.rule(233,750,1687,750,.17);this.label('circle',322,792,16,'muted');this.label('helix',960,792,16,'muted');this.label('sine',1596,792,16,'red');});
 }
 infinity(t,u){
  this.topic('LIMITATIONS','not every boundary is a prison');this.textureFrame(t,.05);
  let q=ease(smooth(0,.36,u));const hel=samples(H,240);const inf=samples(s=>{let a=s*TAU;return [3.1*Math.cos(a)/(1+Math.sin(a)**2),2.4*Math.sin(a)*Math.cos(a)/(1+Math.sin(a)**2),.36*Math.sin(a)]},240);let pts=hel.map((p,i)=>vmix(p,inf[i],q));this.camera({yaw:(1-q)*PI/2,pitch:0,scale:182,cx:960,cy:465});this.tube(pts,.13,'red');
  const cp=this.project(inf[Math.floor((.5+.35*u)*240)]);this.star(cp[0],cp[1]-30,34,t*.1);
  let spread=lerp(765,637,smooth(.5,1,u));for(const side of [-1,1]){let x=960+side*spread;this.g.line([[x,240],[x,698]],9,'teal',.7);this.after(()=>{this.line([[x-side*30,240],[x,240],[x,698],[x-side*30,698]],'teal',2,.8)})}
  this.after(()=>{this.label('∞',960,246,78,'ink',{font:SERIF});this.label('you',960+spread,760,18,'teal');this.label('me',960-spread,760,20,'muted',{font:SERIF});});
 }
 current(t,u){
  this.topic('AC → DC','change the signal, keep the impulse');const q=ease(smooth(.30,.9,u));
  for(let layer=0;layer<3;layer++){let yy=390+layer*92;let pts=samples(s=>[180+s*1560,yy+(1-q)*Math.sin(s*TAU*3-t*3)*54],240);this.g.line(pts,13-layer*3,layer===1?'red':layer===0?'teal':'ink',.9-layer*.18);}
  this.g.text('AC',370,246,128,'ink',{shade:.62});this.g.text('DC',1570,246,128,'red',{shade:.90});
  const x=lerp(238,1680,u);this.me(x,470,52,0,.9,{width:17});this.star(x+118,470+(1-q)*Math.sin(u*TAU)*42,28,t*.1);
  this.after(()=>{this.line([[960,162],[960,736]],'ink',1,.3,[3,12]);for(let i=0;i<26;i++){let xx=188+i*60;this.dot(xx,752,2.5,i/25<u?'teal':'muted',.7)}this.label('~',369,777,41,'teal');this.label('=',1554,777,41,'red')});
 }
 blind(t,u){
  this.topic('VISION','the world does not disappear when it is hidden');
  const r=280;for(let i=0;i<7;i++){let rr=r-i*30,a=t*.42+i*.03;this.g.line(arcPoints(960,466,rr,a,a+TAU*.86,170,rr*.48),i%2?9:5,i%2?'red':'teal',.78-i*.05)}
  this.star(960+Math.sin(t*.9)*210,466+Math.cos(t*.9)*52,40,t*.3);this.me(960,466,93,t*.6,.75,{width:24});
  let close=.76*Math.sin(PI*smooth(.10,.86,u));this.after(()=>{const p=this.p;this.flat([[130,150],[1790,150],[1790,466-230*(1-close)],[130,466-230*(1-close)]],'bg');this.flat([[130,800],[1790,800],[1790,466+230*(1-close)],[130,466+230*(1-close)]],'bg');this.line([[160,466-230*(1-close)],[1760,466-230*(1-close)]],'ink',1.5,.5);this.line([[160,466+230*(1-close)],[1760,466+230*(1-close)]],'ink',1.5,.5);this.label('DIZZY',960,775,33,'ink',{tracking:16});});
 }
 time(t,u){
  this.topic('A.D. → B.C.','reverse the clock, not the other');const r=283,x=960,y=466;this.ornament(x,y,r+48,t,'ink',.55);
  for(let i=0;i<12;i++){let a=i*TAU/12-PI/2;let v=Math.round(lerp(12-i,i,u));this.after(()=>this.label(String(v).padStart(2,'0'),x+Math.cos(a)*(r+25),y+Math.sin(a)*(r+25),17,'muted'))}
  const a=-PI/2-TAU*ease(u)*1.3;const hand=[[x,y],[x+Math.cos(a)*r,y+Math.sin(a)*r]];this.g.line(hand,13,'red',.88);this.g.line([[x,y],[x+Math.cos(a*.52)*(r*.56),y+Math.sin(a*.52)*(r*.56)]],7,'teal',.85);this.me(x,y,62,a,.72,{width:18});this.star(hand[1][0],hand[1][1],33,-a*.3);
  this.after(()=>{this.label('AD',428,460,106,'red',{font:SERIF});this.label('BC',1492,460,106,'teal',{font:SERIF});});
 }
 unite(t,u){
  this.topic('UNITE','one surface / two directions');this.camera({yaw:.35+u*.6,pitch:.32+Math.sin(u*PI)*.13,scale:181,cx:960,cy:472});
  // Actual Möbius parameterization; v changes sign after one circuit.
  const fn=(s,v)=>{let a=s*TAU,R=1.77+v*Math.cos(a/2);return [R*Math.cos(a),R*Math.sin(a),v*Math.sin(a/2)]};
  this.ribbon(fn,.49,'red',180);this.ribbon((s,v)=>fn(s,v+.68),.065,'teal',180);
  const c=this.project(fn(fract(u*.85+.23),.26));this.star(c[0],c[1],34,t*.17);this.after(()=>{this.ringText('AC / DC  ·  AD / BC  ·  ONE SURFACE  ·  ',960,472,386,-.5+t*.03,'ink',14,.043,.50);this.label('∪',1470,487,108,'ink',{font:SERIF});});
 }
 bloom(t,u){
  this.textureFrame(t,.04);this.bloomShape(960,470,346*(1+.025*this.accent(t)),t,false,false,.30+.70*smooth(0,.76,u));this.ornament(960,470,401,t,'ink',.45);
  let a=-PI/2+u*TAU*.45;this.star(960+Math.cos(a)*113,470+Math.sin(a)*113,37,a*.25);
  this.after(()=>{this.label('STIMULATIONS',960,174,36,'ink',{tracking:9});this.label('give()',307,705,21,'red');this.label('respond()',1546,705,21,'teal');this.line([[320,655],[503,556]],'ink',1,.22);this.line([[1577,655],[1412,548]],'ink',1,.22);});
 }
 satisfaction(t,u){
  this.textureFrame(t,.05);const r=298+36*Math.sin(u*PI);this.bloomShape(960,467,r,t,false,false,1);
  for(let i=0;i<8;i++){let a=i*TAU/8+t*.17;this.star(960+Math.cos(a)*(r+48),467+Math.sin(a)*(r+48),14+4*Math.sin(t+i)**2,a);}
  this.after(()=>{this.label('SATISFACTION',960,158,57,'ink',{tracking:3,font:DISPLAY,weight:700});this.ringText('you are not a copy of me  /  ',960,467,r+74,-1.4+t*.012,'ink',13,.045,.65);this.label('a reply',316,470,22,'teal',{font:SERIF});this.label('not an echo',1580,470,22,'red',{font:SERIF});});
 }
 run(t,u){
  const a=this.accent(t);this.letterpressWord('EXECUTE',960,456,202,'ink',smooth(0,.34,u),{sx:.83});
  for(let i=0;i<8;i++){let x=167+i*229,y=210+Math.sin(t*1.4+i*.6)*65;this.g.line([[x,y],[x,728]],7,'teal',.62);this.g.circle(x,728,13,'gold',.76)}
  this.me(845,700,59,-.22,.74,{width:19});this.star(981+42*Math.sin(t*.8),665,32,t*.2);this.after(()=>{this.label('if (you.happy)',960,221,26,'ink',{tracking:2});this.label('run();',960,789,27,'ink',{tracking:4});this.line([[346,577],[1574,577]],'ink',1.5,.75);});
 }
 simulation(t,u){
  this.camera({yaw:u*.55,pitch:.10,scale:157,cx:960,cy:467});this.tube(samples(H,170),.16,'red');let cp=this.project(add(tangent().p,[0,.44,0]));this.star(cp[0],cp[1],36,t*.1);
  const span=lerp(790,624,smooth(0,.8,u));for(const s of [-1,1]){let x=960+s*span;this.g.line([[x-s*58,205],[x,205],[x,735],[x-s*58,735]],15,'ink',.65)}
  this.after(()=>{this.label('SIMULATION',960,172,30,'ink',{tracking:12});this.label('{',351,470,106,'muted',{font:SERIF});this.label('}',1569,470,106,'muted',{font:SERIF});});
 }
 giftShape(kind,t){
  if(kind==='eggplant')return samples(u=>{let a=u*TAU,r=1+.20*Math.sin(a);return [r*Math.cos(a)*122+24*Math.sin(a),r*Math.sin(a)*236]},180);
  if(kind==='tomato')return samples(u=>{let a=u*TAU;return [Math.cos(a)*228*(1-.05*Math.cos(4*a)),Math.sin(a)*187*(1+.03*Math.cos(5*a))]},180);
  const points=[[-206,110],[-236,-46],[-193,-222],[-84,-150],[0,-157],[87,-150],[192,-222],[239,-42],[199,113],[98,171],[0,181],[-99,165],[-206,110]];
  // Closed Catmull-Rom contour; no static illustration is used.
  return samples(u=>{let z=u*(points.length-1),i=Math.min(points.length-2,Math.floor(z)),f=z-i,m=points.length-1;let p0=points[(i-1+m)%m],p1=points[i],p2=points[(i+1)%m],p3=points[(i+2)%m];return p1.map((_,k)=>.5*(2*p1[k]+(-p0[k]+p2[k])*f+(2*p0[k]-5*p1[k]+4*p2[k]-p3[k])*f*f+(-p0[k]+3*p1[k]-3*p2[k]+p3[k])*f*f*f))},180);
 }
 gifts(t,u,kind){
  this.textureFrame(t,.035);let prev=kind==='tomato'?'eggplant':kind==='cat'?'tomato':kind;let q=ease(smooth(0,.21,u));let aa=this.giftShape(prev,t),bb=this.giftShape(kind,t);let x=876,y=477,tilt=kind==='eggplant'?-.23+Math.sin(t*2)*.025:Math.sin(t*.9)*.025;
  let pts=aa.map((p,i)=>{let xx=lerp(p[0],bb[i][0],q),yy=lerp(p[1],bb[i][1],q);return [x+xx*Math.cos(tilt)-yy*Math.sin(tilt),y+xx*Math.sin(tilt)+yy*Math.cos(tilt)]});this.g.poly(pts,'red',.8);this.after(()=>this.line(pts,'red',2,.95));
  if(kind==='eggplant'){let leaf=starPoints(x-29,y-235,75,.34,5,.38);this.g.poly(leaf,'teal',.85);this.g.line(bezier([x-36,y-255],[x-54,y-300],[x+5,y-301],[x+32,y-276],40),11,'teal',.8);this.after(()=>this.line(bezier([x-77,y-80],[x-87,y+58],[x-36,y+116],[x-20,y+147],70),'bg',4,.6));}
  if(kind==='tomato'){this.g.poly(starPoints(x,y-152,98,-.23,5,.24),'teal',.81);this.after(()=>{for(let i=0;i<5;i++){let a=i*TAU/5;let px=x+Math.cos(a)*105,py=y+Math.sin(a)*83;this.flat(petals2(px,py,52,a,.44),'bg',.58);this.dot(px,py,7,'gold',.9)}})}
  if(kind==='cat'){let blink=1-smooth(.58,.60,u)+smooth(.65,.70,u);this.after(()=>{for(const s of [-1,1]){this.line(bezier([x+s*124,y-28],[x+s*102,y+17],[x+s*55,y+17],[x+s*40,y-28],30),'ink',7,1);for(let i=0;i<3;i++)this.line([[x+s*160,y+58+i*22],[x+s*293,y+32+i*43]],'ink',2.3,.8)}this.flat([[x-15,y+51],[x+15,y+51],[x,y+70]],'ink');this.line([[x,y+68],[x,y+93],[x-23,y+108]],'ink',4,1);this.line([[x,y+93],[x+23,y+108]],'ink',4,1);for(let i=-1;i<=1;i++)this.line([[x+i*35,y-137],[x+i*23,y-73]],'red',8,.85)});for(let i=0;i<3;i++){let rr=27+(fract(u*1.8+i/3))*73;this.after(()=>this.circle(1251,487,rr,'teal',1.7,(1-fract(u*1.8+i/3))*.55))}}
  this.star(1290+12*Math.sin(t*1.5),445+21*Math.cos(t*1.3),39,t*.13);let gift=smooth(.34,.85,u);for(let i=0;i<6;i++){let k=fract(gift*1.3+i/6),gx=lerp(1060,1252,k),gy=490-Math.sin(PI*k)*80;this.g.circle(gx,gy,4+2*Math.sin(k*PI),'gold',.78)}
  this.after(()=>{this.label(kind==='eggplant'?'NUTRIENTS':kind==='tomato'?'ANTIOXIDANTS':'ENJOYMENT',960,174,39,'ink',{tracking:6});this.label(kind==='cat'?'purr()':'give()',1478,702,23,'teal');this.label('me',443,470,24,'red');this.rings(876,477,320,2,17,'ink',.16);});
 }
 god(t,u){
  this.topic('EXISTENCE','your response is my evidence');this.textureFrame(t,.03);let r=202;
  this.me(928,470,r,-PI/2,.70,{width:49});for(let i=0;i<20;i++){let a=i*TAU/20+t*.025;let p1=[928+Math.cos(a)*(r+49),470+Math.sin(a)*(r+49)],p2=[928+Math.cos(a)*(r+91+(i%2)*26),470+Math.sin(a)*(r+91+(i%2)*26)];this.g.line([p1,p2],i%2?6:12,'gold',.77)}
  const you=[958+Math.sin(t*.9)*64,470+Math.cos(t*.9)*46];this.star(you[0],you[1],45,t*.18);this.after(()=>{this.label('∃',1477,492,119,'teal',{font:SERIF});this.label('me',432,493,33,'red');this.label('you',you[0],you[1]+72,21,'teal');});
 }
 switchCards(t,u,a,b){
  this.textureFrame(t,.04);let q=ease(smooth(.26,.84,u)),flip=Math.cos(q*PI),x1=600,x2=1320;
  for(const x of [x1,x2]){this.after(()=>{this.line([[x-220,245],[x+220,245],[x+220,711],[x-220,711],[x-220,245]],'ink',1.5,.35);this.rule(x-220,629,x+220,629,.18)})}
  this.g.text(q<.5?a:b,x1,461,274,'red',{sx:Math.max(.07,Math.abs(flip))*.83,shade:.9});this.g.text(q<.5?b:a,x2,461,274,'teal',{sx:Math.max(.07,Math.abs(flip))*.83,shade:.86});
  let ang=PI*q;this.me(960+Math.cos(ang+PI)*371,751-Math.sin(ang)*108,37,ang,.8,{width:12});this.star(960+Math.cos(ang)*371,751+Math.sin(ang)*44,26,ang);
  this.after(()=>{this.label('↔',960,461,75,'ink',{font:SERIF});this.label(a==='F'?'GENDER':'ROLE',960,170,28,'ink',{tracking:11});this.label(a==='F'?'F  /  M':'S  /  M',960,809,16,'muted',{tracking:5})});
 }
 day(t,u){
  this.topic('AM → PM','one turn, two faces');const x=960,y=468,r=255;this.g.circle(x,y,r,'gold',.65);let phase=ease(smooth(.08,.90,u));
  const ellipse=samples(s=>{let a=s*TAU;return [x+Math.cos(a)*r*(1-2*phase),y+Math.sin(a)*r]},160);this.g.poly(ellipse,'ink',.8);
  for(let i=0;i<32;i++){let a=i*TAU/32;this.after(()=>this.line([[x+Math.cos(a)*(r+22),y+Math.sin(a)*(r+22)],[x+Math.cos(a)*(r+37+(i%4===0?24:0)),y+Math.sin(a)*(r+37+(i%4===0?24:0))]],'gold',1.8,.7))}
  let a=-PI+u*TAU;this.star(x+Math.cos(a)*322,y+Math.sin(a)*322,33,a);this.me(x-Math.cos(a)*322,y-Math.sin(a)*322,50,a,.8,{width:16});this.after(()=>{this.label('AM',375,468,64,'ink',{font:SERIF});this.label('PM',1545,468,64,'ink',{font:SERIF});});
 }
 trance(t,u){
  this.topic('TRANCE','a perfect pattern is not a promise');const turns=4.5;
  for(let layer=0;layer<2;layer++){let pts=samples(s=>{let a=s*TAU*turns-t*.45+layer*PI,rr=18+360*Math.pow(s,.78);return [960+Math.cos(a)*rr,467+Math.sin(a)*rr*.9]},700);this.g.line(pts,13,layer?'teal':'red',.73)}
  this.me(960,467,75,t*.4,.88,{width:22});this.star(960+Math.cos(t)*85,467+Math.sin(t)*85,29,t*.14);this.after(()=>this.rings(960,467,388,3,14,'ink',.15));
 }
 resonance(t,u){
  this.topic('VIBRATIONS','not identical / in conversation');this.textureFrame(t,.035);let arrive=smooth(.05,.64,u);const x=960,y=474;
  for(let i=0;i<5;i++){let phase1=t*.9+i*.35,pts=samples(s=>[160+s*1600,474+Math.sin(s*TAU*2-phase1)*86*(1-arrive*.70)+(i-2)*18],300);this.g.line(pts,i===2?11:3,i%2?'teal':'red',i===2?.90:.35);}
  this.bloomShape(x,y,lerp(60,300,arrive),t*.5,false,false,arrive);
  let starA=-t*.55,rr=lerp(280,94,arrive);this.star(x+Math.cos(starA)*rr,y+Math.sin(starA)*rr,41,starA*.33);
  this.after(()=>{if(u>.52)this.ringText('COMPLETION  ≠  SAMENESS  ·  ',x,y,344,-1.05+t*.02,'ink',14,.049,.75);this.label('me',226,722,18,'red');this.label('you',1694,722,18,'teal');});
 }
 absence(t,u){
  const lt=t-110.9;this.topic('ISOLATION','the gesture remains; the reply does not');let departed=smooth(.12,1.7,lt);let count=Math.min(5,Math.floor(Math.max(0,lt-.4)/1.07));
  for(let i=5;i>=0;i--){let active=i<=count;let x=292+i*269,y=lerp(474,448,Math.sin(i*.6)*.5+.5),r=58;this.after(()=>{this.line([[x-111,273],[x+111,273],[x+111,689],[x-111,689],[x-111,273]],active?'red':'muted',active?2:1,active?.68:.24);this.label(String(i+1).padStart(2,'0'),x,734,15,'muted');});this.bridge(x-14,y,r,false,fract(lt/.93),false);}
  if(lt<2.2){let x=331+departed*1190,y=422-Math.sin(departed*PI)*255;this.star(x,y,24,lt*.6);}
  this.after(()=>{this.label('response = ∅',960,811,23,'ink',{tracking:2});});
 }
 erasure(t,u){
  this.topic('ERASE','the removed piece was part of me');const td=tangent();let q=smooth(.18,.62,u);this.camera({yaw:PI/2,pitch:0,scale:166,cx:960,cy:475});const gap=[BROKEN[0],lerp(BROKEN[0],BROKEN[1],q)];this.tube(samples(H,220),.145,'red',{gap});
  const cp=this.project(add(td.p,[0,.40,0]));this.star(cp[0],cp[1],37,0,{hollow:true,color:'muted',alpha:.7});let ca=this.project(H(BROKEN[0])),cb=this.project(H(BROKEN[1]));let tearX=lerp(ca[0],cb[0],q);
  this.after(()=>{this.line([[tearX,169],[tearX,788]],'ink',2,.44*(1-smooth(.7,1,u)));this.label('delete(fragment)',960,784,24,'red');this.line([[ca[0],735],[cb[0],735]],'ink',1,.4,[2,6]);});
  for(let i=0;i<32;i++){let pp=H(lerp(BROKEN[0],BROKEN[1],i/31)),pr=this.project(pp),fall=smooth(.20+i*.008,.62+i*.006,u);if(fall>0){let xx=pr[0]+(hash(i,3)-.5)*170*fall,yy=pr[1]+fall*260+60*hash(i,5);this.g.circle(xx,yy,2.2+3.2*(1-fall),'red',.55*(1-fall)+.12)}}
 }
 argument(t,u){
  this.topic('ILLEGAL ARGUMENTS','the rule is rewritten by the one who cannot accept the answer');let q=smooth(.05,.85,u);this.letterpressWord('ILLEGAL',960,352,185,'ink',smooth(0,.25,u),{sx:.91});
  let x=960,y=626;this.me(x-110,y,80,0,.78,{width:26});this.star(x+220+q*292,y-18-76*Math.sin(q*PI),40,t*.13);
  for(const s of [-1,1]){let xx=x+s*lerp(650,167,q);this.g.line([[xx-s*43,462],[xx,462],[xx,783],[xx-s*43,783]],16,'teal',.89)}
  this.after(()=>{this.label('assert(you === expected)',960,817,24,'ink');this.line([[418,445],[1510,445]],'ink',2,.8);this.label('≠',1310,593,59,'teal',{font:SERIF});});
 }
 recursion(t,u){
  this.topic('RETRY','the same missing piece, in every new world');const travel=(t-134.1)*.79;
  for(let i=21;i>=0;i--){let z=i*.60-fract(travel*.25)*2.4,scale=1/(1+Math.max(-.72,z)*.47),r=464*scale,x=960+Math.sin(i*.35)*32*scale,y=457+Math.cos(i*.27)*15*scale;let gapA=.76,gapB=1.40;let a=arcPoints(x,y,r,-PI*.88+gapB,TAU-PI*.88+gapA,150,r*.72);this.g.line(a,Math.max(2,18*scale),'red',.3+.65*scale/1.51);if(i%3===0){this.after(()=>this.line(a,'gold',1,.18));this.after(()=>this.label('execute(me);',x-r*.55,y+r*.72+22,Math.max(10,18*scale),'muted',{alpha:.60,align:'left'}));}}
  const rt=fract((t-134.1)/1.9);let run=smooth(0,.64,rt);this.me(960-32*run,454,46,-.15,.8,{width:17});this.star(1070,414,29,0,{hollow:true,color:'muted',alpha:.58});
  this.after(()=>{this.label('retry()',960,797,25,'ink',{tracking:4});this.label('∅',1468,757,48,'red',{font:SERIF});});
 }
 execute(t,u){
  const lt=t-147.65;let cycle=Math.floor(lt/1.85),k=fract(lt/1.85),sl=ease(smooth(0,.70,k));
  for(let i=0;i<15;i++){let x=120+i*120,ht=410+230*Math.sin(i*.72+lt*.45);let yy=476-ht/2;this.g.line([[x,yy],[x,yy+ht]],18+(i%3)*3,i%4===0?'gold':'red',.46+.37*hash(i,1));for(let j=0;j<5;j++){let y=yy+(j/4)*ht;this.after(()=>this.cross(x,y,5,'ink',.3));}}
  // Successive printed slats reveal a command; no full-frame strobing.
  let word=cycle%2?'EXECUTE':'EXECUTION',size=cycle%2?195:153;this.after(()=>{const c=this.ctx;c.save();c.fillStyle=this.p.bg;c.fillRect(115,366,1690,205);this.label(word,960,466,size,'ink',{font:DISPLAY,weight:900,sx:.87});c.restore();this.label('world.',960,281,37,'gold',{tracking:3});this.label('( me );',960,665,50,'red',{tracking:7});});
  for(let i=0;i<4;i++){let x=lerp(-340,2170,fract(sl+i*.26));this.g.line([[x,154],[x+205,797]],9,'ink',.7)}
 }
 count(t,u){
  const marks=[158.90,159.32,159.65,160.23,160.65,161.15],n=marks.filter(s=>s<=t).length;let last=marks[Math.max(0,n-1)],q=smooth(0,.20,t-last);this.topic('EXECUTION','six returns / six bars');
  this.g.text(String(Math.max(1,n)),960,464,452,'red',{font:SERIF,shade:.86,sx:1});for(let i=0;i<n;i++){let a=i*TAU/6-PI/2;let pp=[960+Math.cos(a)*290,463+Math.sin(a)*290];this.g.line([[pp[0]-Math.sin(a)*116,pp[1]+Math.cos(a)*116],[pp[0]+Math.sin(a)*116,pp[1]-Math.cos(a)*116]],18,'ink',.72)}
  this.after(()=>{this.circle(960,463,347,'ink',1.4,.45);this.label(['EIN','DOS','TROIS','NE','FEM','LIU'][Math.max(0,n-1)],1450,467,35,'ink',{tracking:5});this.label(String(n).padStart(2,'0')+' / 06',437,467,24,'muted')});
 }
 reprise(t,u){
  this.textureFrame(t,.035);const lt=t-162.65;this.bloomShape(960,466,395,t*.5,true,true,1);
  for(let i=0;i<8;i++){let a=i*TAU/8+t*.17;this.star(960+Math.cos(a)*415,466+Math.sin(a)*415,24,a,{hollow:true,color:'ink',alpha:.72})}
  for(let i=0;i<6;i++){let a=i*TAU/6+PI/6;let a1=[960+Math.cos(a)*352,466+Math.sin(a)*352],a2=[960+Math.cos(a+TAU/6)*352,466+Math.sin(a+TAU/6)*352];this.g.line([a1,a2],17,'teal',.76)}
  this.after(()=>{this.label('EXECUTION',960,154,44,'ink',{tracking:9});this.label('same output',344,467,19,'ink',{font:SERIF});this.label('no response',1576,467,19,'ink',{font:SERIF});});
 }
 restore(t,u){
  this.topic('RESTORE','a composition is not a reunion');let q=ease(smooth(0,.80,u));this.camera({yaw:lerp(1.1,0,q),pitch:0,scale:lerp(128,178,q),cx:lerp(828,960,q),cy:490});this.tube(samples(H,200),.145,'red',{gap:BROKEN});const td=tangent(),contact=add(td.p,[0,.145,0]),expected=add(td.p,[0,.385,0]),actual=add(expected,[0,0,5.3]);let cp=this.project(actual);this.star(cp[0],cp[1],this.cam.scale*.24,0);let a=this.project(sub(contact,mul(td.d,1.25))),b=this.project(add(contact,mul(td.d,1.25)));this.after(()=>this.line([a,b],'ink',3,.8));if(u<.6){let ex=this.project(expected);this.star(ex[0],ex[1],this.cam.scale*.24,0,{hollow:true,color:'muted',alpha:1-u/.6});}this.after(()=>{this.label('expected',450,752,16,'muted');this.label('returned?',1470,752,16,'teal');});
 }
 reveal(t,u,override=null){
  const q=ease(smooth(.12,.91,u));this.topic('PROJECTION','');this.camera({yaw:override?.yaw??q*1.05,pitch:override?.pitch??0,scale:lerp(178,126,q),cx:lerp(960,820,q),cy:490});this.tube(samples(H,210),.145,'red',{gap:BROKEN});
  const td=tangent(),contact=add(td.p,[0,.145,0]),expected=add(td.p,[0,.385,0]),actual=add(expected,[0,0,5.3]);let cp=this.project(actual),ep=this.project(expected);this.star(cp[0],cp[1],this.cam.scale*.24,0);if(q>.18)this.star(ep[0],ep[1],this.cam.scale*.24,0,{hollow:true,color:'muted',alpha:smooth(.18,.5,q)*.52});
  const a=this.project(sub(contact,mul(td.d,1.25))),b=this.project(add(contact,mul(td.d,1.25)));this.after(()=>{this.line([a,b],'ink',3,.84);if(q>.35){this.line([[ep[0],ep[1]+85],[cp[0],cp[1]+85]],'muted',1,.44,[2,8]);this.label('me',ep[0],ep[1]+127,19,'red');this.label('you',cp[0],cp[1]+127,19,'teal');}this.label(q<.44?'':'same projection ≠ same position',960,798,22,'ink',{alpha:smooth(.50,.70,q),font:SERIF});});
  this.lastStats.separation=5.3;this.lastStats.projectedGap=Math.hypot(ep[0]-cp[0],ep[1]-cp[1]);
 }
 love(t,u){
  const lt=t-177.23;this.topic('THE ALGEBRA OF LOVE','knowledge is not a returned call');this.camera({yaw:.20*Math.sin(lt*.23),pitch:.04,scale:172,cx:915,cy:472});
  const h=heart3(1.12,180);for(let i=4;i>=0;i--){let s=1+i*.043,pts=h.map(p=>[p[0]*s,p[1]*s,p[2]-i*.24]);this.tube(pts,.026+i*.009,i===0?'red':'ink',{gap:BROKEN,sides:5});}
  for(let i=0;i<9;i++){let x=-1.25+i*.31;let pts=samples(s=>[x,lerp(-1.6,1.45,s),.06],2);const a=this.project(pts[0]),b=this.project(pts.at(-1));this.after(()=>this.line([a,b],'red',1.6,.22))}
  const small=this.project([-.03,-.10,.17]);this.me(small[0],small[1],54,t*.1,.87,{width:18});let sp=this.project([2.52,-.08,.6]);this.star(sp[0],sp[1],38,t*.2);
  this.after(()=>{this.label('love =',276,465,70,'ink',{font:SERIF});this.label('?',1490,465,106,'teal',{font:SERIF});this.ringText('love love love love love love love love ',920,467,389,-1.7+t*.045,'ink',14,.061,.65);this.label('world.execute(me);',960,804,20,'muted');});
 }
 freedom(t,u){
  this.topic('YOU ARE FREE','');let x=879,y=482,r=246;this.camera({yaw:0,pitch:0,scale:146,cx:x,cy:y});this.tube(heart3(1.12,230),.11,'red',{gap:BROKEN});
  const leave=ease(smooth(0,.89,u));this.star(1290+360*leave,468-90*Math.sin(leave*PI),39,t*.15);this.me(x,y,47,-.16,.8,{width:16});
  for(const side of [-1,1]){let xx=x+side*349;this.g.line([[xx-side*31,254],[xx,254],[xx,750],[xx-side*31,750]],10,'ink',.73)}
  this.after(()=>{this.label('you',1290+360*leave,547-90*Math.sin(leave*PI),18,'teal',{alpha:1-smooth(.88,1,u)});this.label('me',x,762,22,'red');this.label('love',x,200,53,'red',{font:SERIF});this.rule(1413,682,1790,682,.18);});
 }
 coda(t,u){
  const lt=t-195.2,q=ease(smooth(.1,.72,u));this.camera({scale:lerp(146,32,q),cx:lerp(879,1081,q),cy:482,yaw:0,pitch:0});const hp=heart3(1.12,240),mp=polylineResample([[-.60,-.36,0],[-.60,.34,0],[-.30,.34,0],[-.30,-.35,0],[-.30,.34,0],[0,.34,0],[0,-.35,0],[.28,-.35,0],[.67,-.35,0],[.74,-.02,0],[.20,-.02,0],[.25,.34,0],[.70,.34,0],[.76,-.02,0]],240);let pts=hp.map((p,i)=>vmix(p,mp[i],q));this.tube(pts,lerp(.11,.045,q),'red',{gap:BROKEN,sides:6});
  const c=this.ctx;c.save();c.font=`38px ${MONO}`;const prefix='world.execute(',suffix=');',full=prefix+'me'+suffix,total=c.measureText(full).width,xx=960-total/2,pre=c.measureText(prefix).width,arg=c.measureText('me').width;c.restore();
  this.after(()=>{let a=smooth(.28,.66,u);this.label(prefix,xx,482,38,'ink',{align:'left',alpha:a});this.label(suffix,xx+pre+arg,482,38,'ink',{align:'left',alpha:a});if(q>.92)this.label('me',xx+pre,482,38,'red',{align:'left',alpha:smooth(.92,1,q)*.85});this.label('坐 标 之 外',960,564,25,'ink',{font:SANS,alpha:smooth(.61,.83,u)});this.label('VISUALS / CODE  ·  AI-GENERATED FAN WORK',960,738,13,'muted',{tracking:1.8,alpha:smooth(.76,.95,u)});this.label('MUSIC  ·  MILI',960,775,13,'muted',{tracking:2.7,alpha:smooth(.76,.95,u)});});
  if(u<.40)this.star(1650+u*750,465-u*75,39,t*.15);
 }
 end(t,u){
  const c=this.ctx;c.font=`38px ${MONO}`;let prefix='world.execute(',arg='me',suffix=');',w=c.measureText(prefix+arg+suffix).width,x=960-w/2,pre=c.measureText(prefix).width;this.after(()=>{this.label(prefix,x,481,38,'ink',{align:'left'});this.label(arg,x+pre,481,38,'red',{align:'left'});this.label(suffix,x+pre+c.measureText(arg).width,481,38,'ink',{align:'left'});this.label('坐 标 之 外',960,556,24,'ink',{font:SANS});this.label('MILI  /  UNOFFICIAL AI-GENERATED MUSIC FILM',960,775,12,'muted',{tracking:2});});let p=x+pre+14+fract((t-205.81)*.8)*24;this.g.line([[p,521],[p+10,521]],4,'red',.92);
 }
 render(t,opts={}){
  t=clamp(Number.isFinite(t)?t:0,0,this.duration);let shot=SHOTS.find(s=>t>=s.start&&t<s.end)||SHOTS.at(-1),u=phase(t,shot.start,shot.end);this.lastStats={time:t,shot:shot.id,subtitle:null};this.begin(shot.paper,t);
  switch(shot.id){
   case 'boot':this.boot(t,u);break;case 'overture':this.overture(t,u);break;case 'points':this.points(t,u);break;case 'circle':this.circleScene(t,u);break;case 'wave':this.wave(t,u);break;case 'infinity':this.infinity(t,u);break;
   case 'current':this.current(t,u);break;case 'blind':this.blind(t,u);break;case 'time':this.time(t,u);break;case 'unite':this.unite(t,u);break;
   case 'bloom':this.bloom(t,u);break;case 'satisfaction':this.satisfaction(t,u);break;case 'run':this.run(t,u);break;case 'simulation':this.simulation(t,u);break;
   case 'eggplant':case 'tomato':case 'cat':this.gifts(t,u,shot.id);break;case 'god':this.god(t,u);break;case 'gender':this.switchCards(t,u,'F','M');break;case 'day':this.day(t,u);break;case 'role':this.switchCards(t,u,'S','M');break;case 'trance':this.trance(t,u);break;
   case 'resonance':this.resonance(t,u);break;case 'absence':this.absence(t,u);break;case 'erasure':this.erasure(t,u);break;case 'argument':this.argument(t,u);break;case 'recursion':this.recursion(t,u);break;case 'execute':this.execute(t,u);break;case 'count':this.count(t,u);break;case 'reprise':this.reprise(t,u);break;case 'restore':this.restore(t,u);break;case 'reveal':this.reveal(t,u);break;case 'love':this.love(t,u);break;case 'freedom':this.freedom(t,u);break;case 'coda':this.coda(t,u);break;case 'end':this.end(t,u);break;
  }
  this.finishGlyph();this.margins(shot.chapter,String(shot.index+1).padStart(2,'0'));this.printGrain();this.caption(t,opts.captions===undefined?this.captionMode:opts.captions);
  if(t>210.78){this.ctx.save();this.ctx.globalAlpha=smooth(210.78,211.89,t);this.ctx.fillStyle='#142b2a';this.ctx.fillRect(0,0,1920,1080);this.ctx.restore();}
  return {...this.lastStats};
 }
 inspect(kind,yaw,pitch=0){this.begin('paper',0);this.lastStats={shot:'inspect',kind,yaw,pitch};this.camera({yaw,pitch,scale:kind==='separation'?124:156,cx:kind==='separation'?817:960,cy:469});this.tube(samples(H,200),.145,'red',{gap:kind==='separation'?BROKEN:null});const td=tangent();if(kind!=='helix'){const base=add(td.p,[0,.385,0]),cp=this.project(add(base,[0,0,kind==='separation'?5.3:0]));this.star(cp[0],cp[1],this.cam.scale*.24);const ca=add(td.p,[0,.145,0]),a=this.project(sub(ca,mul(td.d,1.25))),b=this.project(add(ca,mul(td.d,1.25)));this.after(()=>this.line([a,b],'ink',3,.85));if(kind==='separation'){const ex=this.project(base);this.star(ex[0],ex[1],this.cam.scale*.24,0,{hollow:true,color:'muted',alpha:.7});this.after(()=>this.line([ex,cp],'muted',1,.5,[3,8]));}}else{let cp=this.project(H(.38));this.star(cp[0],cp[1],30)}
  this.finishGlyph();this.margins('ANOTHER VIEW');this.label(kind==='helix'?'同一个螺旋。只转动视角，不更换形状。':kind==='tangent'?'切线取自曲线的导数；接触点没有偷换。':'正面投影可以重合，空间距离始终是 5.3。',960,920,27,'ink',{font:SANS});this.label('P(s) = (1.5 cos 4πs, 1.5 sin 4πs, 6.8(s − 0.5))',960,974,21,'muted');this.printGrain();return this.lastStats;
 }
}
window.Film=Film;
})();
