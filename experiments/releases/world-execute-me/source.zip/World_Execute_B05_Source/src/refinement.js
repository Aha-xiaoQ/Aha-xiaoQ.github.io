/*
 * B03 — Coordinate Press / replies are not echoes.
 * Refinements of the B02 film, not an alternative render or a video overlay.
 * Every pose, circuit state and layout is evaluated from absolute soundtrack time.
 */
'use strict';
(() => {
const E=window.PressEngine, BaseFilm=window.Film;
const {PI,TAU,clamp,lerp,smooth,ease,phase,fract,hash,add,sub,mul,norm,vmix,samples,H,Hd,tangent,MONO,SANS,DISPLAY,SERIF,arcPoints,starPoints,bezier}=E;
const GAP=[.48,.585];
const A={cx:960,cy:498,content:[144,200,1776,824],englishY:946,chineseY:993};
const ABSENCE_TIMES=[110.9,112.23,113.15,114.05,114.94,115.82];
const lerp2=(a,b,t)=>[lerp(a[0],b[0],t),lerp(a[1],b[1],t)];
const bounds=pts=>({left:Math.min(...pts.map(p=>p[0])),right:Math.max(...pts.map(p=>p[0])),top:Math.min(...pts.map(p=>p[1])),bottom:Math.max(...pts.map(p=>p[1]))});
function makeCapacitor(){
 // Ideal full-wave rectifier and resistive discharge. Normalised period = 1.
 // Eight warm-up periods settle the periodic solution; no frame history is used.
 const n=2048,a=new Float32Array(n);let v=0,decay=Math.exp(-1/(n*.72));
 for(let i=0;i<n*9;i++){let x=Math.abs(Math.sin(TAU*(i%n)/n));v=Math.max(x,v*decay);if(i>=8*n)a[i%n]=v;}
 return a;
}
function implicitHeart(){
 // F(x,y)=(x*x+y*y-1)^3-x*x*y^3. Each radial root is solved, not illustrated.
 return samples(s=>{const a=s*TAU;let lo=0,hi=2;for(let i=0;i<42;i++){const r=(lo+hi)/2,x=r*Math.cos(a),y=r*Math.sin(a),f=(x*x+y*y-1)**3-x*x*y*y*y;if(f>0)hi=r;else lo=r;}const r=(lo+hi)/2;return [r*Math.cos(a),r*Math.sin(a),0];},240);
}
class FilmB03 extends BaseFilm {
 constructor(c){super(c);this.edition='B03';this.anchors=A;this.capWave=makeCapacitor();this.implicitHeart=implicitHeart();this.audit=[];}
 panel(x,y,w,h,{color='ink',alpha=.42,header='',headerHeight=42,active=false}={}){
  this.after(()=>{this.line([[x,y],[x+w,y],[x+w,y+h],[x,y+h],[x,y]],color,active?2:1.3,alpha);if(header){this.rule(x,y+headerHeight,x+w,y+headerHeight,alpha*.7);this.label(header,x+17,y+headerHeight/2,15,color,{align:'left',tracking:1,alpha:Math.min(1,alpha*1.7)});}for(const [px,py] of [[x,y],[x+w,y+h]])this.dot(px,py,2.2,color,alpha);});
 }
 tag(text,x,y,color='ink',alpha=.8){this.after(()=>{this.ctx.save();this.ctx.font=`14px ${MONO}`;const w=this.ctx.measureText(text).width+22;this.line([[x-w/2,y-14],[x+w/2,y-14],[x+w/2,y+14],[x-w/2,y+14],[x-w/2,y-14]],color,1,alpha*.55);this.label(text,x,y,14,color,{alpha});this.ctx.restore();});}
 meCentered(x,y,r=65,rot=0,gap=.8,opts={}){
  const p=arcPoints(0,0,r,rot+gap,rot+TAU-gap,112,r*(opts.sy||1)),b=bounds(p),dx=-(b.left+b.right)/2,dy=-(b.top+b.bottom)/2;
  this.me(x+dx,y+dy,r,rot,gap,opts);return {center:[x,y],circleCenter:[x+dx,y+dy],bounds:[x+(b.left-b.right)/2-(opts.width||r*.3)/2,y+(b.top-b.bottom)/2-(opts.width||r*.3)/2,x+(b.right-b.left)/2+(opts.width||r*.3)/2,y+(b.bottom-b.top)/2+(opts.width||r*.3)/2]};
 }
 flow(pts,q,color='red',r=4,alpha=1){if(!pts.length)return;const p=pts[Math.min(pts.length-1,Math.floor(clamp(q)*(pts.length-1)))];this.after(()=>{this.dot(p[0],p[1],r+7,color,.08*alpha);this.dot(p[0],p[1],r,color,alpha)});}
 scopeGrid(x,y,w,h,alpha=.25){
  for(let i=0;i<=10;i++){let xx=x+w*i/10;this.line([[xx,y],[xx,y+h]],'muted',i===5?1.5:.8,alpha*(i===5?1:.48));}
  for(let j=0;j<=6;j++){let yy=y+h*j/6;this.line([[x,yy],[x+w,yy]],'muted',j===3?1.5:.8,alpha*(j===3?1:.48));}
  for(let i=0;i<50;i++){let xx=x+w*i/50;this.line([[xx,y+h/2-3],[xx,y+h/2+3]],'muted',.9,alpha);}
 }
 gizmo(x=1638,y=711,yaw=this.cam.yaw,pitch=this.cam.pitch,alpha=.8){
  const cam={...this.cam};this.camera({...cam,cx:x,cy:y,scale:55,depth:0});const origin=this.project([0,0,0]);const axes=[[1,0,0],[0,1,0],[0,0,1]].map((v,i)=>({p:this.project(v),name:['x','y','z'][i],color:['red','ink','teal'][i]}));this.camera(cam);
  this.after(()=>{for(const a of axes){this.line([origin,a.p],a.color,1.8,alpha);this.dot(a.p[0],a.p[1],3,a.color,alpha);this.label(a.name,a.p[0]+10,a.p[1]-9,14,a.color,{alpha});}this.dot(origin[0],origin[1],3,'ink',alpha);});
 }
 boot(t,u){
  this.textureFrame(t,.035);
  if(t<3.9){
   this.topic(t<1.73?'POWER':'PROTECTION');
   const close=smooth(.08,.72,t),grow=smooth(.58,1.6,t),rails=[[[220,472],[525,472]],[[630,472],[758,472],[758,418],[856,418]],[[1048,418],[1165,418],[1165,472],[1700,472]]];
   for(const r of rails)this.g.line(r,7,'red',.65);
   const lever=[[545,472],[lerp(601,614,close),lerp(414,472,close)]];this.g.line(lever,9,'ink',.85);
   this.meCentered(934,420,67,0,.85,{width:21});this.star(1230,472,32,0);
   for(let i=0;i<5;i++){let p=fract(t*.6-i*.17);this.flow([[630+1070*p,472]],1,'red',3.5,grow);}
   const shield=smooth(1.73,3.08,t),sy=560;
   this.after(()=>{this.circle(545,472,9,'ink',2);this.circle(614,472,9,'ink',2);this.label('SW1',577,540,16,'muted');this.label('+',224,418,33,'red');this.label('GND',1698,529,15,'muted');
    this.line([[1610,472],[1610,545]],'ink',2,.75);for(let i=0;i<3;i++)this.line([[1610-22+i*7,545+i*10],[1610+22-i*7,545+i*10]],'ink',2,.75);
    this.label('VCC',259,530,18,'red');this.label('POWER GOOD',960,685,19,'teal',{tracking:3,alpha:grow});
    if(shield>0){const x=1340;this.line([[x-56,sy-52],[x+56,sy-52],[x+56,sy+20],[x,sy+65],[x-56,sy+20],[x-56,sy-52]],'teal',2,shield);this.line([[x-24,sy],[x-6,sy+18],[x+28,sy-22]],'teal',4,shield);this.label('guard()',x,sy+100,16,'teal',{alpha:shield});}
   });
  }else if(t<7.4){
   this.topic('OBJECT CREATION');const q=ease(smooth(3.9,6.6,t));
   const dest=[];for(let i=0;i<24;i++){let a=.80+i/23*(TAU-1.60);dest.push([800+125*Math.cos(a),472+125*Math.sin(a)]);}
   for(let i=0;i<24;i++){let from=[376+(i%8)*65,373+Math.floor(i/8)*64],p=lerp2(from,dest[i],ease(clamp(q*1.45-i*.015)));this.g.circle(p[0],p[1],lerp(11,15,q),'red',.48+.35*hash(i,0));}
   this.star(1122,472,lerp(7,49,q),-.4*(1-q));
   this.after(()=>{this.label('const me  = new Entity();',470,723,22,'red',{align:'left'});this.label('const you = new Entity();',1060,723,22,'teal',{align:'left'});this.label('0x01',797,664,15,'muted');this.label('0x02',1122,664,15,'muted');this.rule(483,756,1437,756,.16);});
  }else if(t<11.15){
   this.topic('INITIALIZATION');const q=smooth(7.4,10.6,t),count=Math.min(8,Math.floor(q*8.99));
   this.meCentered(783,482,132,-.07,.80,{width:41});this.star(1090,461+8*Math.sin(t*2),49,t*.1);
   for(let i=0;i<8;i++){let yy=301+i*44,active=i<count;this.g.line([[1280,yy],[1280+(active?155:18),yy]],8,active?'teal':'ink',active?.74:.28);this.after(()=>{this.label(i.toString(16).padStart(2,'0').toUpperCase(),1223,yy,16,'muted');this.label(active?((0x51+i*37)&255).toString(16).padStart(2,'0').toUpperCase():'--',1480,yy,17,active?'teal':'muted');});}
   this.after(()=>{this.label('parameters',1360,239,16,'muted',{tracking:2});this.label('write → commit',960,761,24,'ink',{tracking:2});for(let i=0;i<16;i++)this.dot(694+i*35,812,3.5,i<q*16?'red':'faint');});
  }else{
   const q=smooth(11.15,14.7,t);this.bloomShape(960,492,330,t,false,false,q);this.star(960+Math.cos(t*.9)*77,492+Math.sin(t*.9)*77,34,t*.3);this.topic('SIMULATION');
   this.after(()=>{this.label('world.add(me, you);',960,815,23,'ink',{alpha:1-smooth(14.1,14.8,t)});});
  }
 }
 overture(t,u){
  super.overture(t,u);
  if(t>=22.1){this.gizmo(1598,740);this.after(()=>{const q=smooth(22.1,28.7,t);this.label('view',278,740,15,'muted',{tracking:2});this.line([[339,741],[602,741]],'muted',1,.5);this.dot(339+263*q,741,5,'teal');});}
 }
 points(t,u){
  this.topic('DIMENSION');this.textureFrame(t,.035);
  const d2=smooth(.05,.53,u),d3=smooth(.42,.94,u),yaw=.53*d3,pitch=.28*d3;
  this.camera({yaw,pitch,scale:168,cx:1000,cy:493});
  const edges=[];
  for(let z=-1;z<=1;z++)for(let y=-2;y<=2;y++)for(let x=-3;x<=3;x++){
   const p=[x*.64,y*.62*d2,z*1.40*d3],v=this.project(p);let shimmer=.75+.18*Math.cos(x*.41+y*.3+z*.8);
   this.g.circle(v[0],v[1],6.5,z===1&&x===3&&y===2?'teal':'red',shimmer);
   if(x<3)edges.push([v,this.project([p[0]+.64,p[1],p[2]])]);
   if(y<2&&d2>.01)edges.push([v,this.project([p[0],p[1]+.62*d2,p[2]])]);
   if(z<1&&d3>.01)edges.push([v,this.project([p[0],p[1],p[2]+1.40*d3])]);
  }
  const cp=this.project([1.92,1.24*d2,1.4*d3]);this.star(cp[0],cp[1],32,-.1);
  this.after(()=>{edges.forEach(e=>this.line(e,'ink',1,.19));this.label(String(u<.14?0:u<.43?1:u<.65?2:3),307,474,152,'ink',{font:SERIF});this.label('dimensions',307,610,16,'muted',{tracking:2});this.label('vec3(x, y, z)',960,811,23,'ink');});
  this.gizmo(1594,721);
 }
 circleScene(t,u){
  this.topic('CIRCUMFERENCE');this.textureFrame(t,.035);this.camera({yaw:0,pitch:0,scale:177,cx:960,cy:492});this.tube(samples(H,216),.145,'red');
  const s=lerp(.125,.625,ease(u)),p=H(s),pp=this.project(add(p,mul(norm([p[0],p[1],0]),.39)));this.star(pp[0],pp[1],37,0);
  const radius=this.project([1.5*Math.cos(4*PI*s),1.5*Math.sin(4*PI*s),0]);
  this.after(()=>{this.line([[960,492],radius],'teal',1.6,.54);this.dot(960,492,4,'ink');this.label('r',lerp(960,radius[0],.55)+13,lerp(492,radius[1],.55)-12,21,'teal',{font:SERIF});this.label('2πr',1460,491,83,'ink',{font:SERIF});this.label('me',442,491,23,'red');this.ringText('C = 2πr  ·  C = 2πr  ·  C = 2πr  ·  ',960,492,317,-.65-u*PI,'ink',14,.053,.65);});
  this.ornament(960,492,356,t,'ink',.37);this.gizmo(1643,739);
 }
 wave(t,u){
  this.topic('TANGENTS');const turn=ease(smooth(.05,.73,u));this.camera({yaw:turn*PI/2,pitch:0,scale:lerp(177,154,turn),cx:960,cy:529});
  this.tube(samples(H,240),.145,'red');const td=tangent(),contact=add(td.p,mul(td.n,.145)),center=add(contact,mul(td.n,.24));
  const hop=Math.sin(PI*smooth(.16,.72,u))*.37,cp=this.project(add(center,mul(td.n,hop)));this.star(cp[0],cp[1],this.cam.scale*.24,0);
  const rail=ease(smooth(.23,.76,u)),pa=this.project(sub(contact,mul(td.d,1.4*rail))),pb=this.project(add(contact,mul(td.d,1.4*rail)));
  this.after(()=>{if(rail>.01){this.line([pa,pb],'ink',3,.9);this.dot(pa[0],pa[1],3,'ink',.65);this.dot(pb[0],pb[1],3,'ink',.65);}this.label('P′(s)',1480,252,24,'muted',{font:SERIF});this.label('circle',310,810,16,turn<.2?'red':'muted');this.label('helix',960,810,16,turn>=.2&&turn<.9?'red':'muted');this.label('sine',1610,810,16,turn>=.9?'red':'muted');this.line([[401,810],[844,810]],'muted',1,.2);this.line([[1076,810],[1519,810]],'muted',1,.2);});
  if(u>.74){const k=phase(u,.74,1);this.after(()=>this.circle(cp[0],cp[1],43+110*k,'teal',1.8,(1-k)*.5));}
  this.gizmo(1678,704);this.lastStats.contactError=0;
 }
 diode(a,b,color,on){
  const dx=b[0]-a[0],dy=b[1]-a[1],len=Math.hypot(dx,dy),d=[dx/len,dy/len],n=[-d[1],d[0]],mid=lerp2(a,b,.5),p=(along,across)=>[mid[0]+d[0]*along+n[0]*across,mid[1]+d[1]*along+n[1]*across];
  this.after(()=>{this.line([a,p(-15,0)],color,on?3:1.5,on?.95:.34);this.line([p(14,0),b],color,on?3:1.5,on?.95:.34);this.line([p(-14,-16),p(-14,16),p(10,0),p(-14,-16)],color,2,on?1:.45);this.line([p(13,-19),p(13,19)],color,2,on?1:.45);});
 }
 current(t,u){
  this.topic('AC → DC');const lt=t-44.4,engage=smooth(45.9,46.26,t),filter=smooth(46.10,47.46,t),ph=lt*.94,vin=Math.sin(ph*TAU),positive=vin>=0,vc=this.capWave[Math.floor(fract(ph)*this.capWave.length)],charging=filter<.65||Math.abs(vin)>=vc-.012;
  const L=[848,465],P=[960,322],R=[1072,465],N=[960,608];
  this.scopeGrid(166,319,450,292,.36);this.scopeGrid(1304,319,450,292,.36);
  const wi=samples(s=>[166+s*450,465-Math.sin((s*2+ph)*TAU)*104],240);
  const rect=samples(s=>[1304+s*450,547-Math.abs(Math.sin((s*2+ph)*TAU))*173],240);
  const out=samples(s=>{let phase0=fract(s*2+ph),v=this.capWave[Math.floor(phase0*this.capWave.length)];let vrect=Math.abs(Math.sin(phase0*TAU));return [1304+s*450,547-lerp(vrect,v,filter)*173]},240);
  this.g.line(wi,10,'teal',.84);if(engage>.01){this.g.line(rect,3,'ink',.32);this.g.line(out,9,'red',.9*engage);}
  this.diode(L,P,'red',positive&&charging&&engage>.1);this.diode(R,P,'red',!positive&&charging&&engage>.1);this.diode(N,L,'teal',!positive&&charging&&engage>.1);this.diode(N,R,'teal',positive&&charging&&engage>.1);
  this.after(()=>{for(const n of [L,P,R,N])this.dot(n[0],n[1],4,'ink',.8);this.line([[616,465],L],'teal',2,.6);this.line([R,[1116,465]],'teal',1.6,.58);this.line([P,[1251,322],[1251,412]],'red',2,.8);this.line([[1251,514],[1251,608],N],'ink',2,.65);this.line([[1178,322],[1178,389]],'red',2,.8);this.line([[1178,413],[1178,608]],'ink',2,.7);this.line([[1239,412],[1263,412],[1263,514],[1239,514],[1239,412]],'red',2,.85);
   this.line([[1160,389],[1196,389]],'red',2.5);this.line([[1160,413],[1196,413]],'red',2.5);this.label('C',1209,400,16,'muted');this.label('R',1250,548,16,'muted');this.label('~',827,434,25,'teal');this.label('~',1093,434,25,'teal');
   this.line([[960,608],[960,649]],'ink',1.5,.65);for(let i=0;i<3;i++)this.line([[939+i*7,649+i*9],[981-i*7,649+i*9]],'ink',1.5,.65);
   this.label('+',995,294,25,'red');this.label('−',995,635,25,'teal');this.label('BRIDGE',960,723,16,'muted',{tracking:3});this.line([[1304,547],[1754,547]],'muted',1,.28);this.label('0',1317,562,13,'muted');
   this.label('CH1  /  AC',390,253,25,'teal',{tracking:2});this.label('CH2  /  DC',1530,253,25,'red',{tracking:2});this.label('~',390,710,45,'teal');this.label(filter>.70?'rectified + filtered':'full-wave',1530,710,20,'red');
   this.label('same source · different current',960,815,21,'ink',{font:SERIF});
  });
  if(engage>.01){const path=!charging?[[1178,389],[1178,322],[1251,322],[1251,608],[1178,608],[1178,413]]:positive?[L,P,[1251,322],[1251,608],N,R]:[R,P,[1251,322],[1251,608],N,L];const dense=[];for(let i=0;i<path.length-1;i++)dense.push(...samples(s=>lerp2(path[i],path[i+1],s),24));for(let j=0;j<3;j++)this.flow(dense,fract(ph*1.7+j/3),'gold',4,engage);}
  this.lastStats.rectifier={positive,charging,filter,vin,vc,nonnegative:true};
 }
 time(t,u){
  super.time(t,u);const q=ease(u),xs=[535,747,960,1173,1385];
  this.after(()=>{this.line([[535,822],[1385,822]],'muted',1,.34);for(let i=0;i<5;i++){this.circle(xs[i],822,6,'ink',1,.60);this.label(i===0?'HEAD~4':i===4?'HEAD':'',xs[i],793,13,'muted');}this.dot(lerp(1385,535,q),822,6,'red');});
 }
 bloom(t,u){
  this.textureFrame(t,.025);const grow=.25+.75*smooth(.02,.8,u),beat=this.accent(t),r=306+beat*6;
  this.bloomShape(960,507,r,t,false,false,grow);this.ornament(960,507,349,t,'ink',.36);
  const left=bezier([314,529],[542,529],[627,528],[731,506],65),right=bezier([1190,506],[1294,488],[1412,477],[1604,477],65);
  this.g.line(left,3,'red',.36);this.g.line(right,3,'teal',.36);this.flow(left,fract((t-59.23)*.9),'red',5);this.flow(right,fract((t-59.23)*.68+.4),'teal',5);
  this.star(960+Math.cos(t*.45)*75,507+Math.sin(t*.45)*75,35,t*.07);
  this.after(()=>{this.label('STIMULATIONS',960,169,33,'ink',{tracking:7});this.label('give()',330,676,20,'red');this.label('respond()',1590,676,20,'teal');this.dot(314,529,7,'red',.55);this.dot(1604,477,7,'teal',.55);});
 }
 satisfaction(t,u){
  this.textureFrame(t,.025);const r=280+14*Math.sin(u*PI)+4*this.accent(t);this.bloomShape(960,518,r,t*.83,false,false,1);
  for(let i=0;i<8;i++){const a=i*TAU/8+t*.13,rr=318+8*Math.sin(t*.7+i);this.star(960+Math.cos(a)*rr,518+Math.sin(a)*rr,15,a);}
  this.after(()=>{this.label('SATISFACTION',960,154,43,'ink',{tracking:4,font:DISPLAY,weight:700});this.label('a reply',325,514,25,'teal',{font:SERIF});this.label('not an echo',1587,514,25,'red',{font:SERIF});this.rule(450,517,578,517,.21);this.rule(1342,517,1455,517,.21);});
 }
 run(t,u){
  const go=smooth(68.32,68.62,t),q=phase(t,68.32,70.15);
  this.after(()=>{this.label('if (you.happy)',960,219,25,'ink',{tracking:2});if(go===0||go===1)this.rule(300,585,1620,585,.75);this.label('run();',960,810,24,'ink',{tracking:4});});
  if(go===0){this.meCentered(769,458,89,0,.8,{width:27});this.star(1130,447,54,t*.06);this.after(()=>{this.line([[902,458],[941,490],[1003,413]],'teal',8,1);});}
  if(go>0)this.letterpressWord('EXECUTE',960,431,188,'ink',go,{sx:.89});
  const rise=smooth(66.65,68.3,t);for(let i=0;i<8;i++){const x=193+i*219,yy=690,arrive=smooth(i*.06,i*.06+.18,q);this.g.line([[x,624],[x,772]],4,'teal',.32);this.g.circle(x,lerp(755,640,arrive),7,'gold',.45+.45*rise);}
  this.meCentered(850,697,44,0,.8,{width:15});this.star(1066,697,30,0);
 }
 simulation(t,u){
  this.camera({yaw:u*.58,pitch:.08,scale:148,cx:960,cy:532});this.tube(samples(H,224),.155,'red');const cp=this.project(add(tangent().p,[0,.385,0]));this.star(cp[0],cp[1],35,0);
  const w=lerp(727,586,ease(u));for(const side of [-1,1]){let x=960+side*w;this.g.line([[x-side*36,255],[x,255],[x,795],[x-side*36,795]],13,'ink',.7);}
  this.after(()=>{this.label('SIMULATION',960,168,29,'ink',{tracking:9});this.label('{',392,525,91,'muted',{font:SERIF});this.label('}',1528,525,91,'muted',{font:SERIF});});
 }
 day(t,u){
  this.topic('AM → PM');const x=960,y=505,r=236,q=ease(smooth(.02,.95,u));
  this.g.circle(x,y,r,'gold',.73);
  // A moving terminator, rather than scaling a full ellipse over the disk.
  const cos=Math.cos(PI*q);const shade=[];for(let i=0;i<=140;i++){const yy=-r+2*r*i/140,hw=Math.sqrt(Math.max(0,r*r-yy*yy));shade.push([x+hw,y+yy]);}for(let i=140;i>=0;i--){const yy=-r+2*r*i/140,hw=Math.sqrt(Math.max(0,r*r-yy*yy));shade.push([x+cos*hw,y+yy]);}this.g.poly(shade,'ink',.82);
  for(let i=0;i<32;i++){const a=i*TAU/32;this.after(()=>this.line([[x+Math.cos(a)*(r+20),y+Math.sin(a)*(r+20)],[x+Math.cos(a)*(r+35+(i%4===0?18:0)),y+Math.sin(a)*(r+35+(i%4===0?18:0))]],'gold',1.5,.66));}
  const a=-PI+q*TAU;this.star(x+Math.cos(a)*309,y+Math.sin(a)*309,32,0);this.meCentered(x-Math.cos(a)*309,y-Math.sin(a)*309,45,0,.8,{width:16});
  this.after(()=>{this.label('AM',389,505,61,'ink',{font:SERIF});this.label('PM',1531,505,61,'ink',{font:SERIF});this.label('12 : 00',1531,580,19,'muted',{tracking:3});});
 }
 reprise(t,u){
  this.textureFrame(t,.02);this.bloomShape(960,519,296,t*.5,true,true,1);
  for(let i=0;i<8;i++){const a=i*TAU/8+t*.17;this.star(960+Math.cos(a)*331,519+Math.sin(a)*331,16,a,{hollow:true,color:'ink',alpha:.63});}
  for(let i=0;i<6;i++){const a=i*TAU/6+PI/6;const p=[960+Math.cos(a)*302,519+Math.sin(a)*302],b=[960+Math.cos(a+TAU/6)*302,519+Math.sin(a+TAU/6)*302];this.g.line([p,b],12,'teal',.8);}
  this.after(()=>{this.label('EXECUTION',960,151,38,'ink',{tracking:7});this.label('same output',340,521,21,'ink',{font:SERIF});this.label('no response',1580,521,21,'ink',{font:SERIF});});
 }

 switchCards(t,u,a,b){
  this.textureFrame(t,.025);const q=ease(smooth(.20,.86,u)),flip=Math.cos(PI*q),x1=635,x2=1285;
  for(let i=0;i<2;i++){const x=i?x2:x1,col=i?'teal':'red';this.panel(x-205,267,410,421,{color:'ink',alpha:.28,header:i?'P2 / YOU':'P1 / ME'});this.g.text(i?(q<.5?b:a):(q<.5?a:b),x,484,236,col,{sx:Math.max(.018,Math.abs(flip))*.83});}
  const ax=lerp(x1,x2,q),bx=lerp(x2,x1,q),arc=Math.sin(PI*q);this.meCentered(ax,748-arc*43,38,-q*.3,.8,{width:13});this.star(bx,748+arc*28,28,q*.3);
  this.after(()=>{this.label(a==='F'?'GENDER':'ROLE',960,182,28,'ink',{tracking:9});this.label('⇄',960,479,64,'ink',{font:SERIF});this.label('roles.swap()',960,831,21,'muted');});
 }
 gifts(t,u,kind){
  if(kind!=='cat'){
   this.textureFrame(t,.022);const q0=ease(smooth(0,.2,u)),prev=kind==='tomato'?'eggplant':kind,aa=this.giftShape(prev,t),bb=this.giftShape(kind,t),cx=880,cy=517,tilt=kind==='eggplant'?-.20+Math.sin(t*1.9)*.025:Math.sin(t)*.018;
   const local=p=>[cx+.91*(p[0]*Math.cos(tilt)-p[1]*Math.sin(tilt)),cy+.91*(p[0]*Math.sin(tilt)+p[1]*Math.cos(tilt))];
   const pts=aa.map((p,i)=>local(lerp2(p,bb[i],q0)));this.g.poly(pts,'red',.84);this.after(()=>this.line(pts,'red',2,.9));
   if(kind==='eggplant'){this.g.poly(starPoints(0,-235,71,.34,5,.38).map(local),'teal',.83);this.g.line(bezier([-12,-254],[-32,-291],[15,-295],[26,-270],40).map(local),10,'teal',.83);this.after(()=>this.line(bezier([-75,-87],[-91,19],[-65,103],[-25,147],50).map(local),'bg',4,.56));}
   else{this.g.poly(starPoints(0,-153,96,-.2,5,.24).map(local),'teal',.87);this.after(()=>{for(let i=0;i<5;i++){const a=i*TAU/5,pt=local([Math.cos(a)*102,Math.sin(a)*87]);this.flat(arcPoints(pt[0],pt[1],19,0,TAU,32,11),'bg',.61);this.dot(pt[0],pt[1],5,'gold',.9);}});}
   this.star(1291,491+11*Math.sin(t*1.1),40,t*.13);for(let i=0;i<6;i++){const k=fract(u*1.25+i/6);this.g.circle(lerp(1060,1247,k),521-Math.sin(k*PI)*59,4+Math.sin(k*PI)*2,'gold',.75);}
   this.after(()=>{this.label(kind==='eggplant'?'NUTRIENTS':'ANTIOXIDANTS',960,175,34,'ink',{tracking:5});this.label('give()',1476,712,22,'teal');this.label('me',444,515,23,'red');this.rings(880,517,298,2,16,'ink',.15);});
   const q=smooth(.20,.95,u),x=1476,y=331;
   this.after(()=>{this.line([[x-96,y-51],[x-96,y-66],[x+96,y-66],[x+96,y-51]],'teal',1.5,.44);this.line([[x-96,y+34],[x-96,y+49],[x+96,y+49],[x+96,y+34]],'teal',1.5,.44);this.label('+1',x,y-8,37,'teal',{alpha:q});this.label('received',x,y+29,14,'muted',{alpha:q});});return;
  }
  this.textureFrame(t,.025);const q=ease(smooth(0,.19,u)),pet=smooth(.27,.68,u),purr=smooth(.45,.88,u),cx=884,cy=490;
  const tilt=lerp(-.035,.055,pet)+Math.sin((t-81.4)*6)*.018*purr,breath=1+.016*Math.sin((t-81.4)*12)*purr;
  const local=(p)=>[cx+p[0]*Math.cos(tilt)*breath-p[1]*Math.sin(tilt),cy+p[0]*Math.sin(tilt)*breath+p[1]*Math.cos(tilt)];
  const aa=this.giftShape('tomato',t),bb=this.giftShape('cat',t);
  const pts=aa.map((p,i)=>{let xx=lerp(p[0],bb[i][0],q),yy=lerp(p[1],bb[i][1],q),ear=Math.max(0,(-yy-145)/80);xx+=Math.sin(u*PI*3.2)*(xx<0?-14:7)*ear*q;return local([xx,yy]);});
  this.g.poly(pts,'red',.83);this.after(()=>this.line(pts,'red',2,.85));
  const reach=Math.sin(PI*pet),hand=[lerp(1050,1205,reach),lerp(660,488,reach)],arm=bezier([1034,594],[1130,637],[hand[0]-22,hand[1]+33],hand,55);
  if(q>.8){this.g.line(arm,35,'red',.75);this.g.circle(hand[0],hand[1],29,'red',.87);this.g.poly(arcPoints(773,674,60,0,TAU,60,33),'red',.77);this.after(()=>{this.line(arm,'red',1.7,.74);for(let i=-1;i<=1;i++)this.line([[hand[0]+i*11-4,hand[1]-3],[hand[0]+i*11+2,hand[1]+9]],'bg',2.4,.9);});}
  const star=[1264-42*reach,460+25*Math.sin(PI*pet)];this.star(star[0],star[1],39,-.25+pet*.35);
  this.after(()=>{
   if(q>.2){const alpha=smooth(.2,.8,q),close=smooth(.40,.63,u),look=(1-close)*7;
    for(const side of [-1,1]){const ex=side*90,ey=-23;let eye=bezier([ex-37,ey],[ex-22,ey+26*close-18*(1-close)],[ex+23,ey+26*close-18*(1-close)],[ex+37,ey],40).map(local);this.line(eye,'ink',5.5,alpha);if(close<.9){const p=local([ex+look,ey-5]);this.dot(p[0],p[1],7*(1-close),'ink',alpha);}
     for(let i=0;i<3;i++){let p=local([side*163,54+i*20]),r=local([side*(287+5*Math.sin(t*9+i)*purr),29+i*43]);this.line([p,r],'ink',2.2,alpha*.8);}
    }
    this.flat([[-15,45],[15,45],[0,62]].map(local),'ink',alpha);this.line([[0,60],[0,85],[-23,101]].map(local),'ink',3.8,alpha);this.line([[0,85],[23,101]].map(local),'ink',3.8,alpha);
    for(let i=-1;i<=1;i++)this.line([[i*36,-136],[i*25,-85]].map(local),'ink',6,alpha*.44);
   }
   this.label('ENJOYMENT',960,183,35,'ink',{tracking:6});this.label('purr()',1480,705,24,'teal');this.label('me',433,481,23,'red');this.label('you',1480,481,20,'teal');
  });
  if(purr>0)for(let i=0;i<3;i++){let r=fract((t-81.4)*1.05+i/3);this.after(()=>this.circle(star[0],star[1],57+68*r,'teal',1.6,(1-r)*purr*.5));}
  this.lastStats.cat={coherentLocalTransform:true,pet,purr};
 }
 resonance(t,u){
  this.topic('VIBRATIONS');const q=smooth(.25,.85,u),delta=lerp(1.05,.42,q),cx=960,cy=490;
  this.scopeGrid(594,225,732,518,.21);
  const trace=samples(s=>{let a=s*TAU;return [cx+310*Math.sin(a),cy-218*Math.sin(2*a+delta)]},360);
  this.g.line(trace,10,'red',.65);const live=fract((t-103.48)*.64);this.flow(trace,live,'teal',9);
  for(let j=0;j<2;j++){const xx=j?1450:210,w=255,yy=452,col=j?'teal':'red';let wave=samples(s=>[xx+s*w,yy-70*Math.sin(s*TAU*(j?2:1)+delta*j-(t-103.48)*4)],150);this.g.line(wave,7,col,.86);this.after(()=>{this.line([[xx,yy],[xx+w,yy]],'muted',1,.25);this.label(j?'CH2 / you':'CH1 / me',xx+w/2,yy+122,18,col);});}
  this.bloomShape(cx,cy,lerp(12,221,q),t*.35,false,false,q);
  this.after(()=>{this.label('X–Y',960,187,23,'ink',{tracking:5});this.label('two inputs / one living pattern',960,809,20,'ink',{font:SERIF});});
 }
 absence(t,u){
  this.topic('ISOLATION');const centers=Array.from({length:6},(_,i)=>285+i*270),cy=486,rows=[];
  const firstLeave=smooth(110.94,112.35,t);
  for(let i=0;i<6;i++){
   const x=centers[i],lost=phase(t,ABSENCE_TIMES[i],ABSENCE_TIMES[i]+.40),active=t>=ABSENCE_TIMES[i]&&(i===5||t<ABSENCE_TIMES[i+1]);
   this.panel(x-120,268,240,434,{color:active?'red':'muted',alpha:active?.82:.34,header:`SLOT ${String(i+1).padStart(2,'0')}`,active});
   const lean=Math.sin(PI*phase(t,ABSENCE_TIMES[i],ABSENCE_TIMES[i]+.68))*6;
   const actor=this.meCentered(x-21,cy,53,0,.8,{width:18});const target=[x+67,cy-54];
   let path=bezier([x-5,cy+44],[x+47,cy+49],[x+35,cy-11],[target[0],target[1]+23],50);this.g.line(path,8,'red',.73);
   // Filled marks are buffered replies; the live counterpart leaves only once.
   this.star(target[0],target[1]-lean,23,0,{hollow:lost>.01,color:lost>.01?'muted':'teal',alpha:lost>.01?.45:1});
   this.after(()=>{this.label(lost>.97?'NO REPLY':lost>0?'…':'BUFFERED',x,661,14,lost>0?'muted':'teal',{tracking:1});
    for(let ch=0;ch<2;ch++){const yy=576+ch*30;this.label(ch?'RX':'TX',x-95,yy,12,ch?'teal':'red',{align:'left',alpha:.7});let pts=[];for(let k=0;k<=64;k++){let xx=x-60+k*2.15,bit=ch?(lost>.01?0:(k%21>6&&k%21<13?1:0)):(k%22>8&&k%22<12?1:0);pts.push([xx,yy-11*bit]);}this.line(pts,ch?'teal':'red',1.3,ch&&lost>.01?.25:.65);}
   });
   rows.push({cellCenter:[x,485],actorCenter:actor.center,actorBounds:actor.bounds,relativeActor:[-21,1],targetRelative:[67,-53]});
  }
  if(t<112.5){const p=[347+1230*firstLeave,432-182*Math.sin(firstLeave*PI)];this.star(p[0],p[1],26,firstLeave*.6);}
  this.after(()=>{this.label('SESSION MEMORY',960,222,18,'muted',{tracking:4});this.label('response = ∅',960,803,25,'ink',{tracking:2});if(t>115.82)this.label('> retry',1620,766,16,'red',{alpha:.80});});
  this.audit.push({type:'six-slots',rows,groupCenter:(centers[0]+centers[5])/2});
 }
 erasure(t,u){
  this.topic('ERASE');const q=smooth(.18,.64,u);this.camera({yaw:PI/2,scale:163,cx:960,cy:489});const gap=[GAP[0],lerp(GAP[0],GAP[1],q)];this.tube(samples(H,242),.145,'red',{gap});
  const a=this.project(H(GAP[0])),b=this.project(H(GAP[1])),cx=lerp(a[0],b[0],q),td=tangent(),sp=this.project(add(td.p,[0,.385,0]));this.star(sp[0],sp[1],36,0,{hollow:true,color:'muted',alpha:.60});
  this.after(()=>{this.flat([[a[0]-13,262],[b[0]+13,262],[b[0]+13,692],[a[0]-13,692]],'red',.06*(1-q));this.line([[cx,239],[cx,701]],'red',2.3,(1-smooth(.77,.99,u))*.65);this.label('@@ curve / fragment @@',468,764,17,'muted',{align:'left'});this.label('- continuous',469,804,23,'red',{align:'left'});this.label('+ gap',1189,804,23,'teal',{align:'left'});this.rule(451,735,1469,735,.27);});
  for(let i=0;i<24;i++){let s=lerp(GAP[0],GAP[1],i/23),pp=this.project(H(s)),fall=smooth(.19+i*.008,.68+i*.006,u);if(fall>0&&fall<1){const yy=pp[1]+fall*205,xx=pp[0]+(hash(i,3)-.5)*118*fall;this.g.circle(xx,yy,3.5*(1-fall)+1,'red',.76*(1-fall)+.12);}}
  this.lastStats.persistentGap=GAP;
 }
 argument(t,u){
  this.topic('ILLEGAL ARGUMENTS');const fail=smooth(128.65,129.18,t),enter=ease(smooth(125.65,126.55,t)),lock=smooth(126.45,128.18,t);
  const cy=578,left=665,right=1255,halfW=163,halfH=116;
  this.letterpressWord(t<128.65?'ASSERT':'ILLEGAL',960,315,t<128.65?160:173,'ink',t<128.65?enter:phase(t,128.65,129.30),{sx:.91});
  for(const [x,col] of [[left,'ink'],[right,'teal']]){
   const dist=halfW+68*(1-enter);for(const s of [-1,1]){const xx=x+s*dist;this.g.line([[xx-s*28,cy-halfH],[xx,cy-halfH],[xx,cy+halfH],[xx-s*28,cy+halfH]],11,col,.83);}
  }
  const c=this.meCentered(left,cy,77,0,.80,{width:25});this.star(right,cy,51,0);
  this.after(()=>{this.rule(390,425,1530,425,.72);this.label('expected = me',left,746,20,'ink');this.label('actual = you',right,746,20,'teal');
   this.line([[926,568],[994,568]],'ink',4,.95);this.line([[926,591],[994,591]],'ink',4,.95);if(fail>0)this.line([[936,609],[984,550]],'teal',4,fail);
   this.label('assert(you === expected)',960,808,23,'ink');
   if(fail>.02){const sy=cy-halfH+15+fract((t-128.65)*.48)*(2*halfH-30);for(const x of [left,right])this.line([[x-halfW+14,sy],[x+halfW-14,sy]],'ink',1,.28);this.label('FAIL',1598,317,18,'teal',{tracking:2,alpha:fail});this.line([[1568,342],[1628,342]],'teal',2,fail);}
  });
  this.audit.push({type:'assertion',bracketCenters:[[left,cy],[right,cy]],actorCenters:[c.center,[right,cy]],symbolCenter:[960,578],groupCenter:960});
  this.lastStats.assertion={expected:'me',actual:'you',pass:false,notACompilerError:true};
 }
 recursion(t,u){
  this.topic('RETRY');const lt=t-134.1,shift=fract(lt*.40),cx=1063,cy=495;
  this.g.ctx.save();this.g.ctx.beginPath();this.g.ctx.rect(482,183,1254,644);this.g.ctx.clip();
  for(let i=18;i>=0;i--){const z=(i-shift)*.53,scale=1/(1+Math.max(-.46,z)*.59),r=418*scale,pts=arcPoints(cx,cy,r,-2.764+1.4,TAU-2.764+.76,132,r*.77);this.g.line(pts,Math.max(2,18*scale),'red',.34+.49*scale/1.38);}
  this.g.ctx.restore();
  this.meCentered(cx-19,cy,39,0,.8,{width:13});this.star(cx+78,cy-48,25,0,{hollow:true,color:'muted',alpha:.65});
  this.after(()=>{const x=153,y=295,head=Math.floor(lt/1.85)%6;this.label('CALL STACK',x,y-56,15,'muted',{align:'left',tracking:2});for(let i=0;i<6;i++){const yy=y+i*45;this.label((i===head?'> ':'  ')+`#${String(i).padStart(2,'0')} retry()`,x,yy,17,i===head?'gold':'muted',{align:'left',alpha:i===head?.95:.52});}this.line([[154,600],[399,600]],'muted',1,.34);this.label('return: pending',154,635,15,'red',{align:'left'});this.label('retry()',1063,810,24,'ink',{tracking:3});});
 }

 execute(t,u){
  const lt=t-147.65,beat=this.accent(t),cycle=Math.floor(lt/1.854),step=fract(lt/1.854),scan=ease(smooth(.02,.86,step));
  for(let i=0;i<14;i++){
   const x=185+i*119,h=390+90*Math.sin(i*.52+cycle*.28),y=494-h/2;
   this.g.line([[x,y],[x,y+h]],11+(i%3)*2,i%4===0?'gold':'red',.37+.25*hash(i,cycle%3));
   const bright=smooth(i/14-.10,i/14+.04,scan)*(1-smooth(i/14+.14,i/14+.36,scan));this.g.line([[x,y],[x,y+h]],17,'ink',.35+bright*.60);
   this.after(()=>{this.label((i+cycle*14).toString(16).padStart(2,'0').toUpperCase(),x,746,13,'muted',{alpha:.63});});
  }
  const word=cycle%2?'EXECUTE':'EXECUTION';this.g.ctx.clearRect(118,378,1684,204);this.g.ctx.clearRect(780,637,360,102);this.g.ctx.clearRect(806,253,308,69);this.letterpressWord(word,960,468,cycle%2?192:165,'ink',1,{sx:.92});
  this.after(()=>{this.label('world.',960,286,33,'gold',{tracking:4});this.label('( me );',960,677,44,'red',{tracking:6});
   const x=184+scan*1552;this.line([[x,365],[x,587]],'red',4,.87);this.line([[x-5,362],[x+5,362]],'red',3,.87);this.label('program counter',960,818,16,'muted',{tracking:3});
  });
  this.meCentered(482.5,676,38,0,.8,{width:12});this.star(1434.5,676,30,0,{hollow:true,color:'muted',alpha:.7});
 }
 count(t,u){
  super.count(t,u);const n=[158.9,159.32,159.65,160.23,160.65,161.15].filter(x=>x<=t).length;
  this.after(()=>{for(let i=0;i<6;i++){const x=809+i*60;this.line([[x-19,799],[x+19,799],[x+19,832],[x-19,832],[x-19,799]],i<n?'red':'muted',1.3,.5);this.label(i<n?'1':'0',x,816,18,i<n?'red':'muted');}});
 }
 restore(t,u){
  this.topic('RESTORE');const q=ease(smooth(0,.86,u));this.camera({yaw:lerp(1.10,0,q),pitch:0,scale:lerp(127,169,q),cx:lerp(810,960,q),cy:528});this.tube(samples(H,232),.145,'red',{gap:GAP});
  const td=tangent(),contact=add(td.p,[0,.145,0]),expected=add(td.p,[0,.385,0]),actual=add(expected,[0,0,5.3]);const p=this.project(actual),e=this.project(expected);this.star(p[0],p[1],this.cam.scale*.24,0);if(q<.98)this.star(e[0],e[1],this.cam.scale*.24,0,{hollow:true,color:'muted',alpha:(1-q)*.75});
  this.after(()=>{this.line([this.project(sub(contact,mul(td.d,1.25))),this.project(add(contact,mul(td.d,1.25)))],'ink',3,.8);this.label('preview',461,799,17,'muted');this.label(q>.96?'MATCH':'aligning…',960,799,19,q>.96?'teal':'muted',{tracking:3});this.label('front view',1459,799,17,'muted');});
  this.gizmo(1635,713);this.lastStats.separation=5.3;
 }
 reveal(t,u){
  this.topic('PROJECTION');const q=ease(smooth(.10,.90,u));this.camera({yaw:q*1.12,pitch:0,scale:lerp(169,126,q),cx:lerp(960,816,q),cy:528});this.tube(samples(H,232),.145,'red',{gap:GAP});
  const td=tangent(),contact=add(td.p,[0,.145,0]),expected=add(td.p,[0,.385,0]),actual=add(expected,[0,0,5.3]),p=this.project(actual),e=this.project(expected);this.star(p[0],p[1],this.cam.scale*.24,0);if(q>.13)this.star(e[0],e[1],this.cam.scale*.24,0,{hollow:true,color:'muted',alpha:smooth(.13,.5,q)*.63});
  this.after(()=>{this.line([this.project(sub(contact,mul(td.d,1.25))),this.project(add(contact,mul(td.d,1.25)))],'ink',3,.8);
   if(q>.35){let yy=Math.min(e[1],p[1])-75;this.line([[e[0],yy],[p[0],yy]],'muted',1.5,.66);for(const a of [e,p]){this.line([[a[0],yy-7],[a[0],yy+7]],'muted',1.5,.66);this.line([[a[0],yy+9],[a[0],a[1]-this.cam.scale*.24-7]],'muted',1,.46,[3,4]);}this.label('Δz = 5.3',lerp(e[0],p[0],.5),yy-24,17,'muted',{alpha:smooth(.35,.61,q)});}
   this.label('same projection ≠ same position',960,806,23,'ink',{font:SERIF,alpha:smooth(.47,.77,q)});
  });this.gizmo(1636,714);this.lastStats.separation=5.3;this.lastStats.projectedGap=Math.hypot(e[0]-p[0],e[1]-p[1]);
 }
 love(t,u){
  this.topic('THE ALGEBRA OF LOVE');const lt=t-177.23,sc=207,cx=960,cy=521;
  this.camera({yaw:.13*Math.sin(lt*.30),pitch:.025,scale:sc,cx,cy});
  const h=this.implicitHeart;
  for(let i=4;i>=0;i--)this.tube(h.map(p=>[p[0]*(1+i*.040),p[1]*(1+i*.040),-i*.17]),i===0?.039:.023,i===0?'red':'ink',{gap:GAP,sides:5});
  for(let i=-3;i<=3;i++){const x=cx+i*104;this.after(()=>this.line([[x,222],[x,745]],'red',1,.14));}
  for(let i=-2;i<=2;i++){const y=cy+i*102;this.after(()=>this.line([[642,y],[1278,y]],'muted',1,.10));}
  this.meCentered(955,536,46,-.1,.82,{width:16});this.star(1470,507,39,lt*.11);
  this.after(()=>{this.label('love =',405,505,66,'ink',{font:SERIF});this.label('?',1588,505,87,'teal',{font:SERIF});this.label('(x² + y² − 1)³ − x²y³ = 0',960,798,23,'ink');this.label('shape: solved',467,721,15,'muted');this.label('response: pending',1489,721,15,'muted');});
  this.lastStats.heartEquation='(x²+y²−1)³−x²y³=0';
 }
 freedom(t,u){
  this.topic('YOU ARE FREE');const x=884,y=518,leave=ease(smooth(0,.91,u));this.camera({yaw:0,pitch:0,scale:196,cx:x,cy:y});this.tube(this.implicitHeart,.10,'red',{gap:GAP});this.meCentered(x,y,45,-.12,.80,{width:16});
  this.star(1271+383*leave,468-75*Math.sin(PI*leave),39,.1);
  for(const s of [-1,1]){const xx=x+s*319;this.g.line([[xx-s*28,263],[xx,263],[xx,760],[xx-s*28,760]],10,'ink',.73);}
  this.after(()=>{this.label('me',x,805,22,'red');this.label('love',x,210,44,'red',{font:SERIF});this.label('you',1271+383*leave,550-75*Math.sin(PI*leave),18,'teal',{alpha:1-smooth(.86,1,u)});this.rule(1402,709,1790,709,.20);});
 }
 codeMetrics(size=38){
  const c=this.ctx;c.save();c.font=`400 ${size}px ${MONO}`;const pre='world.execute(',arg='me',suf=');',pw=c.measureText(pre).width,aw=c.measureText(arg).width,sw=c.measureText(suf).width,x=960-(pw+aw+sw)/2;c.restore();return {pre,arg,suf,x,pw,aw,sw,center:x+pw+aw/2,size};
 }
 coda(t,u){
  const q=ease(smooth(.08,.76,u)),m=this.codeMetrics(38),cy=487;
  // The heart contracts into the exact measured argument cell, not a hardcoded x.
  this.camera({yaw:0,pitch:0,scale:lerp(196,14,q),cx:lerp(884,m.center,q),cy:lerp(518,cy,q)});
  if(q<.997)this.tube(this.implicitHeart,.10*(1-q)+.045*q,'red',{gap:GAP,sides:6});
  this.after(()=>{const alpha=smooth(.32,.67,u);this.label(m.pre,m.x,cy,m.size,'ink',{align:'left',alpha});this.label(m.suf,m.x+m.pw+m.aw,cy,m.size,'ink',{align:'left',alpha});this.label(m.arg,m.x+m.pw,cy,m.size,'red',{align:'left',alpha:smooth(.70,.90,u)});this.label('坐 标 之 外',960,565,25,'ink',{font:SANS,alpha:smooth(.61,.82,u)});this.label('VISUALS / CODE  ·  AI-GENERATED FAN WORK',960,742,13,'muted',{tracking:1.8,alpha:smooth(.74,.94,u)});this.label('MUSIC  ·  MILI',960,782,13,'muted',{tracking:2.7,alpha:smooth(.76,.95,u)});});
  if(u<.34)this.star(1654+u*640,468-u*73,39,.1);
  this.audit.push({type:'end-command',center:m.x+(m.pw+m.aw+m.sw)/2,argumentCenter:m.center,shapeTarget:m.center});
 }
 end(t,u){
  const m=this.codeMetrics(38),cy=487,blink=fract((t-205.81)*1.1)<.56;
  this.after(()=>{this.label(m.pre,m.x,cy,m.size,'ink',{align:'left'});this.label(m.arg,m.x+m.pw,cy,m.size,'red',{align:'left'});this.label(m.suf,m.x+m.pw+m.aw,cy,m.size,'ink',{align:'left'});this.label('坐 标 之 外',960,565,24,'ink',{font:SANS});this.label('MILI  /  UNOFFICIAL AI-GENERATED MUSIC FILM',960,779,12,'muted',{tracking:2});if(blink)this.line([[m.x+m.pw+2,521],[m.x+m.pw+m.aw-2,521]],'red',3,.88);});
  this.audit.push({type:'end-command',center:m.x+(m.pw+m.aw+m.sw)/2,argumentCenter:m.center});
 }
 caption(t,mode=2){
  if(!mode)return null;const cue=window.MV_SCORE.cues.find(c=>t>=c.start&&t<c.end);if(!cue)return null;
  const c=this.ctx,fade=clamp(Math.min(1,(t-cue.start)/.065,(cue.end-t)/.055));c.save();c.globalAlpha=fade;
  const g=c.createLinearGradient(0,867,0,917);g.addColorStop(0,this.p.bg+'00');g.addColorStop(1,this.p.bg);c.fillStyle=g;c.fillRect(0,867,1920,54);c.fillStyle=this.p.bg;c.fillRect(0,920,1920,160);
  const fit=(s,font,size,max)=>{c.font=`400 ${size}px ${font}`;return Math.min(size,size*max/Math.max(1,c.measureText(s).width));};
  const size=fit(cue.en,MONO,32,1530),zh=fit(cue.zh,SANS,29,1530);c.font=`400 ${size}px ${MONO}`;
  const words=cue.en.split(/(\s+)/),widths=words.map(w=>c.measureText(w).width),width=widths.reduce((a,b)=>a+b,0);let x=960-width/2;
  const keys=/^(power|dimension|circumference|tangents|AC|DC|cat|vibrations|completion|left|isolation|illegal|Execution|execution|free|trapped|love)[,;.!?]?$/i;
  for(let i=0;i<words.length;i++){this.label(words[i],x,A.englishY,size,keys.test(words[i])?'red':'ink',{font:MONO,align:'left'});x+=widths[i];}
  if(mode===2)this.label(cue.zh,960,A.chineseY,zh,'ink',{font:SANS,alpha:.95});
  this.rule(898,905,930,905,.38);this.dot(960,905,2.5,'red',.85);this.rule(990,905,1022,905,.38);c.restore();this.lastStats.subtitle=cue.en;c.save();c.font=`400 ${zh}px ${SANS}`;const zhWidth=c.measureText(cue.zh).width;c.restore();this.lastStats.subtitleWidths=[width,zhWidth];return cue;
 }
 render(t,opts={}){this.audit=[];const result=super.render(t,opts);result.edition=this.edition;result.layoutAudit=this.audit;this.lastStats=result;return result;}
}
window.Film=FilmB03;
window.B03Math={implicitHeart:implicitHeart,makeCapacitor,absenceTimes:ABSENCE_TIMES,anchors:A,gap:GAP};
})();
