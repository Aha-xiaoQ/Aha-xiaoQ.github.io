/* B04 — The circuit is part of the relationship.
 * Film rendering consumes CircuitModel states. It never invents an independent
 * phase for a trace, diode, cursor or logic output. No bitmap/video artwork.
 */
'use strict';
(()=>{
const E=window.PressEngine,M=window.CircuitModel,Base=window.Film;
const {TAU,PI,clamp,lerp,smooth,ease,phase,fract,samples,arcPoints,bezier,MONO,SANS,SERIF,DISPLAY}=E;
const v2=(a,b,q)=>[lerp(a[0],b[0],q),lerp(a[1],b[1],q)];
function along(pts,q){let total=0,ds=[];for(let i=1;i<pts.length;i++){let d=Math.hypot(pts[i][0]-pts[i-1][0],pts[i][1]-pts[i-1][1]);ds.push(d);total+=d;}let distance=fract(q)*total;for(let i=0;i<ds.length;i++){if(distance<=ds[i]||i===ds.length-1){const p=v2(pts[i],pts[i+1],ds[i]?distance/ds[i]:0);return {p,a:Math.atan2(pts[i+1][1]-pts[i][1],pts[i+1][0]-pts[i][0])};}distance-=ds[i];}return {p:pts[0],a:0};}
class CircuitInk{
 constructor(f){this.f=f;}
 translated(dx,dy,draw){
  // Move the complete schematic, including glyph ink and deferred vector ink.
  const f=this.f,g=f.g,line=g.line,after=f.after;
  g.line=function(pts,...args){return line.call(this,pts.map(p=>[p[0]+dx,p[1]+dy]),...args);};
  f.after=function(fn){return after.call(this,()=>{const ctx=this.ctx;ctx.save();ctx.translate(dx,dy);try{fn();}finally{ctx.restore();}});};
  try{draw();}finally{g.line=line;f.after=after;}
 }
 label(s,x,y,col='muted',size=15,align='center',alpha=1){this.f.after(()=>this.f.label(s,x,y,size,col,{align,alpha}));}
 wire(pts,col='ink',on=false,alpha=1){const f=this.f;if(on)f.g.line(pts,9,col,.43*alpha);f.after(()=>f.line(pts,col,on?2.8:2,alpha*(on?.98:.53)));}
 node(p,col='ink',alpha=1){this.f.after(()=>this.f.dot(p[0],p[1],3.8,col,alpha));}
 ground(x,y,col='ink',alpha=.65){const f=this.f;f.after(()=>{f.line([[x,y-12],[x,y]],col,2,alpha);for(let i=0;i<3;i++)f.line([[x-18+6*i,y+8*i],[x+18-6*i,y+8*i]],col,2,alpha);});}
 component(a,b,kind,col='ink',on=false){const f=this.f,d=[b[0]-a[0],b[1]-a[1]],l=Math.hypot(...d),u=[d[0]/l,d[1]/l],n=[-u[1],u[0]],c=v2(a,b,.5),pt=(x,y)=>[c[0]+x*u[0]+y*n[0],c[1]+x*u[1]+y*n[1]];
  const half=kind==='cap'?9:kind==='diode'?19:27;
  this.wire([a,pt(-half,0)],col,on);this.wire([pt(half,0),b],col,on);
  f.after(()=>{const w=2.3,al=on?1:.72;
   if(kind==='resistor'||kind==='fuse'){f.line([pt(-27,-9),pt(27,-9),pt(27,9),pt(-27,9),pt(-27,-9)],col,w,al);if(kind==='fuse')f.line([pt(-27,0),pt(27,0)],col,1.5,al);}
   if(kind==='cap'){f.line([pt(-9,-21),pt(-9,21)],col,w,al);f.line([pt(9,-21),pt(9,21)],col,w,al);}
   if(kind==='diode'){f.line([pt(-19,-19),pt(-19,19),pt(12,0),pt(-19,-19)],col,w,al);f.line([pt(18,-22),pt(18,22)],col,w,al);}
  });
 }
 switch(a,b,closed,col='ink',alpha=1){const f=this.f,ang=Math.atan2(b[1]-a[1],b[0]-a[0])-(1-closed)*.58,len=Math.hypot(b[0]-a[0],b[1]-a[1]);f.after(()=>{f.circle(a[0],a[1],4,col,2,alpha);f.circle(b[0],b[1],4,col,2,alpha);f.line([a,[a[0]+len*Math.cos(ang),a[1]+len*Math.sin(ang)]],col,2.5,alpha);});}
 arrows(path,q,col='gold',count=3,alpha=1){if(alpha<.01)return;const f=this.f;f.after(()=>{for(let i=0;i<count;i++){let {p,a}=along(path,q+i/count),d=[Math.cos(a),Math.sin(a)],n=[-d[1],d[0]];f.line([[p[0]-d[0]*8+n[0]*4,p[1]-d[1]*8+n[1]*4],p,[p[0]-d[0]*8-n[0]*4,p[1]-d[1]*8-n[1]*4]],col,2.5,alpha);}});}
 frame(x,y,w,h,title,col='ink'){const f=this.f;f.after(()=>{f.line([[x,y],[x+w,y],[x+w,y+h],[x,y+h],[x,y]],'muted',1.2,.29);f.label(title,x+16,y-24,17,col,{align:'left',tracking:1});for(const p of [[x,y],[x+w,y+h]]){f.line([[p[0]-7,p[1]],[p[0]+7,p[1]]],'muted',1,.5);f.line([[p[0],p[1]-7],[p[0],p[1]+7]],'muted',1,.5);}});}
 grid(x,y,w,h,nx=10,ny=8){const f=this.f;f.after(()=>{for(let i=1;i<nx;i++)f.line([[x+i*w/nx,y],[x+i*w/nx,y+h]],'muted',.8,i===nx/2?.35:.14);for(let i=1;i<ny;i++)f.line([[x,y+i*h/ny],[x+w,y+i*h/ny]],'muted',.8,i===ny/2?.35:.14);});}
 trace(pts,col='red',width=8,live=true){const f=this.f;f.g.line(pts,width,col,.85);f.after(()=>{f.line(pts,col,1.6,.80);if(live&&pts.length){const p=pts.at(-1);f.dot(p[0],p[1],4.5,col,.95);}});}
}
class FilmB04 extends Base{
 constructor(c){super(c);this.edition='B04';this.circuit=new CircuitInk(this);this.rectifier=M.createRectifier();this.labU=.66;}
 boot(t,u){
  if(t>=3.9){super.boot(t,u);return;}
  const c=this.circuit,s=M.power(t),go=s.released,on=t>=.16;
  this.topic(t<1.73?'POWER':'PROTECTION');
  c.label('3.3 V / POWER-ON SEQUENCE',1730,150,'muted',15,'right');
  const rail=[[250,392],[250,326],[420,326]],bus=[[484,326],[545,326]],afterFuse=[[655,326],[1480,326]];
  c.wire(rail,'red',on);c.wire(bus,'red',on);c.switch([420,326],[484,326],smooth(.04,.16,t),'red');c.label('SW1',451,283);
  c.component([545,326],[655,326],'fuse','red',on);c.label('F1',600,277);c.label('100 mA',600,303,'muted',13);
  c.wire(afterFuse,'red',on);c.wire([[250,476],[250,620],[1480,620]],'ink',on);c.wire([[1480,326],[1480,417]],'red',on);c.component([1480,417],[1480,533],'resistor','red',on);c.wire([[1480,533],[1480,620]],'ink',on);
  c.label('RL',1545,464);c.label('1 kΩ',1545,489,'muted',14);c.ground(1480,637);c.node([1480,620]);
  this.after(()=>{this.circle(250,434,42,'ink',2.3,.82);this.label('+',250,417,23,'red');this.label('−',250,450,23,'ink');this.label('V1',169,420,18,'muted');this.label('3.3 V',169,448,17,'red');});
  c.component([743,326],[743,620],'cap','teal',on);c.node([743,326],'red');c.node([743,620]);c.label('C1',794,464);c.label('100 nF',794,490,'teal',15);
  // Generic open-drain supervisor; the pull-up returns to VDD, NOT ground.
  c.wire([[915,326],[915,402]],'red',on);c.node([915,326],'red');c.wire([[915,552],[915,620]],'ink',on);c.node([915,620]);
  this.panel(847,402,136,150,{alpha:.57,header:'U2 / POR',headerHeight:35});c.label('2.9 V',915,465,'teal',22);c.label('tD 20 ms',915,511,'muted',14);
  c.wire([[983,488],[1130,488]],'teal',go);c.component([1046,326],[1046,488],'resistor','teal',!go&&on);c.node([1046,326],'red');c.node([1046,488],'teal');c.label('RPU',1091,386,'muted',13);c.label('10 kΩ',1091,408,'muted',13);
  this.panel(1130,388,244,194,{color:go?'teal':'ink',alpha:.61,header:'U1 / MCU',headerHeight:37,active:go});c.wire([[1252,326],[1252,388]],'red',on);c.node([1252,326],'red');c.wire([[1252,582],[1252,620]],'ink',on);c.node([1252,620]);
  this.meCentered(1252,496,50,0,.80,{width:18});c.label('/RESET',1109,463,'teal',14,'right');c.label(go?'RUN':'HELD IN RESET',1252,563,go?'teal':'muted',13);
  if(on)c.arrows([[275,326],[420,326],[484,326],[655,326],[1480,326],[1480,620],[275,620]],t*.22,'red',5,.7);
  const x=482,w=1210,xx=x+w*clamp(t/3.9),vpts=samples(q=>{let tt=q*t;return [x+w*tt/3.9,742-M.power(tt).v/3.3*64]},240),rpts=samples(q=>{let tt=q*t;return [x+w*tt/3.9,827-(M.power(tt).released?40:0)]},240);
  c.grid(x,665,w,162,13,4);c.trace(vpts,'red',7);c.trace(rpts,'teal',6);c.label('VDD',309,710,'red',20);c.label('/RESET',309,800,'teal',20);
  this.after(()=>{this.line([[x,742-64*2.9/3.3],[x+w,742-64*2.9/3.3]],'muted',1,.50,[5,6]);this.label('2.9 V',x-20,683,13,'muted',{align:'right'});this.line([[xx,665],[xx,835]],'ink',1,.40);this.label(`${s.v.toFixed(2)} V`,1716,709,18,'red',{align:'right'});this.label(go?'RELEASED':'LOW',1716,802,16,'teal',{align:'right'});});
  if(t>1.4){const a=x+w*s.cross*50/3.9,b=x+w*s.release*50/3.9;c.wire([[a,764],[b,764]],'gold');c.label('20 ms',lerp(a,b,.5),782,'gold',13);}
  this.lastStats.power=s;
 }
 current(t,u){
  const c=this.circuit,te=(t-M.rectifierParams.start)/50,s=this.rectifier.at(te),{A,P,B,N}=M.bridge.nodes;
  this.topic('AC → DC');c.label('FULL-WAVE BRIDGE / SHARED TIMEBASE',1750,150,'muted',15,'right');
  // Two plots are measurements, not grounded probe connections to a floating source.
  const lx=158,rx=1372,yy=318,w=392,h=278,vinY=v=>457-v*13.9,voutY=v=>596-v*34.75;
  c.frame(lx,yy,w,h,'V1 · AC [DIFFERENTIAL]','teal');c.grid(lx,yy,w,h,10,8);c.frame(rx,yy,w,h,'VLOAD · DC','red');c.grid(rx,yy,w,h,10,8);
  const history=q=>te-.040+.040*q;
  const inPts=samples(q=>[lx+q*w,vinY(M.source(history(q)))],280),outPts=samples(q=>[rx+q*w,voutY(this.rectifier.at(history(q)).vload)],280);
  c.trace(inPts,'teal',9);c.trace(outPts,'red',10);
  c.label('50 Hz · 6 Vrms',lx+w/2,238,'teal',22);c.label(s.connected?'FILTERED DC':'PULSATING DC',rx+w/2,238,'red',22);
  c.label('4 ms/div   2.5 V/div',lx+w/2,629,'muted',14);c.label('4 ms/div   1 V/div',rx+w/2,629,'muted',14);
  c.label(`${(Math.abs(s.vin)<.005?0:s.vin).toFixed(2)} V`,lx+w/2,675,'teal',32);c.label(`${s.vload.toFixed(2)} V`,rx+w/2,675,'red',32);
  c.label('0',lx-15,457,'muted',13);c.label('0',rx-15,596,'muted',13);
  c.translated(-88,0,()=>{
  for(const d of M.bridge.diodes){const a=M.bridge.nodes[d.a],b=M.bridge.nodes[d.k],on=s.pair.includes(d.id);c.component(a,b,'diode',on?'red':'ink',on);const mid=v2(a,b,.5),off=d.id==='D1'?[-33,-11]:d.id==='D2'?[34,-11]:d.id==='D3'?[-33,14]:[34,14];c.label(d.id,mid[0]+off[0],mid[1]+off[1],on?'red':'muted',15);}
  for(const p of [A,P,B,N])c.node(p);
  // Source lies AC-to-AC. The resistor is in series, not shunting either diode.
  c.component(A,[908,484],'resistor','teal',s.id>1e-7);c.wire([[908,484],[924,484]],'teal',s.id>1e-7);c.wire([[980,484],B],'teal',s.id>1e-7);
  this.after(()=>{this.circle(952,484,28,'teal',2.1,.86);this.label('~',952,484,26,'teal');});
  c.label('RS 22 Ω',853,523,'muted',13);c.label('V1',952,542,'muted',14);c.label('A',774,484,'teal',15);c.label('B',1130,484,'teal',15);
  // Parallel load and filter. C1 top connects ONLY through S2.
  c.wire([P,[1280,304],[1280,424]],'red',s.id>1e-7);c.component([1280,424],[1280,544],'resistor','red',s.il>1e-7);c.wire([[1280,544],[1280,664],N],'ink',s.il>1e-7);
  c.wire([[1184,304],[1184,360]],'red',s.connected&&s.id>1e-7);c.switch([1184,360],[1184,408],s.connected?1:0,'teal');c.wire([[1184,408],[1184,459]],'teal',s.connected&&Math.abs(s.ic)>1e-7);c.component([1184,459],[1184,509],'cap','teal',s.connected);c.wire([[1184,509],[1184,664]],'teal',s.connected);c.node([1184,304]);c.node([1184,664]);
  c.label('S2',1218,386,'teal',13);c.label('C1',1128,548,'teal',15);c.label('100 µF',1128,572,'muted',13);c.label('RL',1310,459,'muted',14);c.label('470 Ω',1310,489,'muted',13);
  c.label('+',985,276,'red',25);c.ground(952,676);c.label('0 V',993,692,'muted',13);
  this.after(()=>{this.line([[1159,460],[1159,459-79*clamp(s.vc/7.2)]],'teal',5,s.connected?.65:0);this.label('+',1160,469,16,'teal');});
  if(s.pair.length){const part=s.positive?[A,P]:[B,P],ret=s.positive?[N,B]:[N,A];c.arrows([...part,[1280,304],[1280,664],...ret],te*26,'gold',5,.95);c.arrows(s.positive?[[924,484],A]:[A,[924,484]],te*26,'gold',1,.85);}
  if(s.il>1e-7)c.arrows([[1280,407],[1280,553]],te*26,'red',1,.9);
  if(s.connected&&Math.abs(s.ic)>1e-6){const path=s.ic>0?[[1184,304],[1184,459]]:[[1184,459],[1184,304],[1280,304]];c.arrows(path,te*26,'teal',2,.88);}
  });
  const mode=!s.connected?'C1 DISCONNECTED':s.pair.length?(s.charging?'BRIDGE → C1 + RL':'BRIDGE + C1 → RL'):'C1 → RL';
  c.label(mode,960,739,'ink',18);c.label(s.pair.length?s.pair.join(' + ')+' ON':'DIODES OFF',960,773,s.pair.length?'red':'muted',15);
  // Current pulses are calculated from the same state; they are NOT a sine decoration.
  const ix=170,iy=826,iw=465;const ip=samples(q=>[ix+q*iw,iy-this.rectifier.at(history(q)).id/.16*60],240);c.trace(ip,'gold',5,false);c.label('I(BRIDGE)',170,736,'gold',14,'left');c.label(`${(s.id*1000).toFixed(1)} mA`,635,736,'gold',16,'right');
  c.label(`IC ${s.ic>=0?'+':''}${(s.ic*1000).toFixed(1)} mA`,1569,748,'teal',22);c.label('CURRENT ARROWS: CONVENTIONAL',1569,792,'muted',12);c.label('time expanded ×50',960,838,'muted',13);
  this.lastStats.rectifier=s;
 }
 blind(t,u){
  const c=this.circuit,s=M.trackHold(t),closed=s.closed,stop=smooth(49.30,49.57,t),a=clamp((t-47.65)/3.75);
  this.topic('VISION');c.label('TRACK → HOLD / BUFFERED MEMORY',1750,150,'muted',15,'right');
  // The eye is an abstract graphic; the actual electrical state is below it.
  const aperture=lerp(92,4,ease(stop)),eye=arcPoints(960,290,354,0,TAU,240,aperture);
  this.g.line(eye,12,'red',.85);this.g.line(arcPoints(960,290,309,PI,TAU,160,aperture*.74),6,'teal',.64);
  if(!closed){this.g.line([[606,290],[1314,290]],10,'red',.9);}else this.star(960+s.vin*35,290,34,0);
  c.label(closed?'TRACK':'HOLD',960,410,closed?'teal':'red',30);c.label(closed?'connected to the present':'still holding the last value',960,442,'muted',17);
  // An ideal analog switch, storage capacitor and unity buffer. Capacitor is
  // across the reference, not in series. A1 has explicit negative feedback.
  this.after(()=>{this.circle(250,557,32,'teal',2,.85);this.label('~',250,557,30,'teal');});
  c.wire([[250,525],[250,492],[539,492]],'teal',closed);c.switch([539,492],[617,492],closed?1:0,'red');c.wire([[617,492],[944,492]],'red',closed);
  c.label('S3',577,459,'muted',14);c.label('V2',193,555,'muted',15);c.wire([[250,589],[250,668]],'ink');c.ground(250,680);
  c.component([785,492],[785,659],'cap','red',!closed);c.node([785,492],'red');c.ground(785,671);c.label('CH',842,565,'muted',14);c.label('1 nF',842,590,'muted',14);
  this.after(()=>{this.line([[944,461],[944,613],[1088,537],[944,461]],'ink',2.3,.85);this.label('+',963,491,19,'teal');this.label('−',963,580,22,'ink');this.label('A1',994,536,16,'muted');});
  c.wire([[1088,537],[1400,537]],'red',true);c.node([1169,537],'red');c.wire([[1169,537],[1169,654],[903,654],[903,580],[944,580]],'ink');
  // Small rail stubs document buffer headroom without connecting a power rail
  // to the signal feedback net.
  c.wire([[991,486],[991,463]],'ink');c.wire([[991,588],[991,617]],'ink');c.label('+5',1026,468,'muted',12);c.label('−5',1026,616,'muted',12);
  c.label(`${s.vc.toFixed(2)} V`,1497,533,'red',43);c.label('VOUT = VC',1497,589,'muted',15);c.label('HIGH-Z BUFFER',1210,484,'muted',14);
  const px=310,pw=1360,base=805,gain=20;const ptsIn=samples(q=>{const tt=t-.020*50+.020*50*q;return [px+q*pw,base-M.trackHold(tt).vin*gain]},320);const ptsOut=samples(q=>{const tt=t-1+q;return [px+q*pw,base-M.trackHold(tt).vc*gain]},320);
  c.frame(px,727,pw,133,'20 ms window · input / held output');c.grid(px,727,pw,133,10,4);c.trace(ptsIn,'teal',5,false);c.trace(ptsOut,'red',8);
  c.label('V2',211,771,'teal',17);c.label('VOUT',211,816,'red',17);this.lastStats.sampleHold=s;
 }
 resonance(t,u){
  const c=this.circuit,te=(t-103.48)/50,s=M.xyAt(te),lock=te>=M.XY.ramp+.02;
  this.topic('VIBRATIONS');c.label('X–Y / ONE SAMPLE PAIR',1750,150,'muted',15,'right');
  const cx=960,cy=490,scale=96,xx=640,yy=194,w=640,h=608;
  c.frame(xx,yy,w,h,'X = CH1     Y = CH2');c.grid(cx-288,cy-288,576,576,6,6);
  // Every dot on the X–Y trace is (CH1(τ), CH2(τ)), from a shared physical τ.
  const trail=samples(q=>{const a=M.xyAt(te-.02+.02*q);return [cx+a.x*scale,cy-a.y*scale]},420);
  for(let j=0;j<10;j++){const a=Math.floor(j/10*420),b=Math.ceil((j+1)/10*420);this.g.line(trail.slice(a,b+1),lerp(4,16,j/9),j>7?'teal':'red',lerp(.28,.92,j/9));}
  c.trace(trail.slice(-33),'teal',10);const pos=trail.at(-1);
  this.after(()=>{this.line([[cx-288,pos[1]],[pos[0],pos[1]],[pos[0],cy+288]],'teal',1,.42,[4,6]);this.dot(pos[0],pos[1],7,'teal');});
  for(let k=0;k<2;k++){const x=k?1430:185,tw=300,y=422,th=166,col=k?'teal':'red';c.frame(x,y,tw,th,k?'CH2 / YOU':'CH1 / ME',col);c.grid(x,y,tw,th,6,4);const pts=samples(q=>{const a=M.xyAt(te-.02+.02*q);return [x+q*tw,y+th/2-(k?a.y:a.x)*27]},220);c.trace(pts,col,7);c.label(`${Math.round(k?s.fy:s.fx)} Hz`,x+tw/2,352,col,32);c.label('20 ms window',x+tw/2,620,'muted',14);c.label(`${(k?s.y:s.x).toFixed(2)} V`,x+tw/2,661,col,22);}
  c.label(lock?'QUADRATURE':'FREQUENCY SWEEP',960,832,lock?'teal':'ink',21);
  c.label(lock?'100 : 100 Hz   Δφ = 90°':'200 → 100 Hz   /   continuous phase',960,860,'muted',15);
  if(lock){const pulse=Math.exp(-Math.max(0,t-108.23)*1.2);this.after(()=>this.circle(cx,cy,240+22*(1-pulse),'teal',1.8,pulse*.7));}
  this.lastStats.xy={...s,tip:[pos[0],pos[1]],expectedTip:[cx+s.x*scale,cy-s.y*scale],lockedCircle:lock};
 }
 absence(t,u){
  const c=this.circuit,starts=window.B03Math.absenceTimes;let attempt=0;for(let i=0;i<6;i++)if(t>=starts[i])attempt=i;
  const end=attempt<5?starts[attempt+1]:118.32,q=clamp((t-starts[attempt])/(end-starts[attempt])),units=Math.min(M.I2C.end,q*14.2),s=M.bus(units,false);
  this.topic('ISOLATION');c.label('I²C / THE NINTH CLOCK',1750,150,'muted',15,'right');
  // Six memories retain the original layout rhythm. Only the live bus is probed.
  const centers=Array.from({length:6},(_,i)=>285+i*270);
  centers.forEach((x,i)=>{const active=i===attempt,done=i<attempt||(active&&s.ackSample);this.panel(x-116,227,232,113,{color:active?'red':'muted',alpha:active?.8:.27,header:`${String(i+1).padStart(2,'0')} / 0x51 W`,headerHeight:33,active});this.meCentered(x-59,291,23,0,.8,{width:8});this.star(x-3,279,13,0,{hollow:true,color:'muted',alpha:.4});c.label(done?'NACK':active?'SEND':'—',x+57,292,done?'red':'muted',18);});
  // SCL and SDA have their own pull-up. The disconnected target cannot pull SDA low.
  this.panel(177,403,196,145,{alpha:.58,header:'CONTROLLER',headerHeight:31});this.meCentered(265,480,29,0,.8,{width:10});
  this.panel(1547,403,196,145,{alpha:.24,header:'TARGET / 0x51',headerHeight:31});this.star(1645,484,26,0,{hollow:true,color:'muted',alpha:.36});
  const x0=373,x1=1440,x2=1547,y0=458,y1=515;
  c.wire([[x0,y0],[1075,y0]],'red',s.scl>2);c.wire(arcPoints(1092,y0,17,PI,TAU,24),'red',s.scl>2);c.wire([[1109,y0],[x1,y0]],'red',s.scl>2);c.wire([[x0,y1],[x1,y1]],'teal',s.sda>2);
  c.wire([[1497,y0],[x2,y0]],'muted');c.wire([[1497,y1],[x2,y1]],'muted');c.switch([1440,y0],[1497,y0],0,'muted',.5);c.switch([1440,y1],[1497,y1],0,'muted',.5);
  c.label('disconnected',1639,575,'muted',14);c.label('SCL',416,435,'red',14);c.label('SDA',416,551,'teal',14);
  c.wire([[829,365],[1092,365]],'ink');c.label('3.3 V',960,386,'ink',15);
  c.component([829,365],[829,y0],'resistor','red',s.scl<1);c.component([1092,365],[1092,435],'resistor','teal',s.sda<1);c.wire([[1092,435],[1092,y1]],'teal',s.sda<1);c.node([829,y0],'red');c.node([1092,y1],'teal');
  c.label('RP1',774,394,'muted',12);c.label('4.7 kΩ',774,415,'muted',12);c.label('RP2',1153,389,'muted',12);c.label('4.7 kΩ',1153,412,'muted',12);c.ground(275,565);c.ground(1645,565);
  // The dot is the observed voltage, not a packet allegedly crossing an open contact.
  c.label(s.ackSample?'NO ACKNOWLEDGE':'ADDRESS + W',630,392,s.ackSample?'red':'ink',19);c.label('OPEN DRAIN',1342,570,'muted',13);
  const px=301,pw=1318,top=631,step=pw/M.I2C.end,xof=a=>px+pw*a/M.I2C.end;
  c.frame(px,top,pw,157,'LOGIC ANALYSER / 100 kHz','ink');
  const ackLeft=xof(9),ackRight=xof(10);this.after(()=>this.flat([[ackLeft,top],[ackRight,top],[ackRight,top+157],[ackLeft,top+157]],s.ackSample?'red':'teal',.09));
  for(let ch=0;ch<2;ch++){const low=ch?762:687,height=35,pts=samples(z=>{let zt=z*units;const a=M.bus(zt,false);return [xof(zt),low-(ch?a.sda:a.scl)/3.3*height]},800);c.trace(pts,ch?'teal':'red',6);c.label(ch?'SDA':'SCL',238,low-17,ch?'teal':'red',17);}
  for(let i=0;i<9;i++){const x=xof(1.75+i);c.label(i===8?'ACK':String((M.I2C.byte>>(7-i))&1),x,813,i===8?'red':'muted',i===8?17:14);this.after(()=>this.line([[x,632],[x,788]],i===8?'red':'muted',1,i===8?.38:.12,[3,5]));}
  c.label('S',xof(.5),813,'teal',15);c.label('P',xof(10.95),813,'teal',15);
  this.after(()=>{const cx=xof(units);this.line([[cx,620],[cx,792]],'ink',1.2,.55);if(s.ackSample){const ay=762-35;this.circle(xof(9.75),ay,17,'red',2.2,.88);this.label('1',xof(9.75),598,30,'red');}});
  c.label(s.ackSample?'NACK · no target acknowledged clock 9.':'8 data bits. One place left for your reply.',960,856,'ink',18);
  this.lastStats.bus={...s,attempt,byte:0xA2,address:0x51,riseTime30to70:M.I2C.rp*M.I2C.cb*Math.log(7/3),txComplete:s.ackSample};
 }
 execute(t,u){
  const c=this.circuit,s=M.counter(t),centers=[285,555,825,1095,1365,1635],y=503,stage=Math.min(2,Math.floor((t-147.65)/3.71));
  if(t>=151.36){this.executeCrescendo(t,u,s);return;}
  this.topic('EXECUTION');c.label('D FLIP-FLOPS / Q5 → D0',1750,150,'muted',15,'right');
  // A clocked ring: all six next states read OLD Q simultaneously.
  const pulse=Math.exp(-Math.max(0,s.since)*12);this.after(()=>{this.label('posedge CLK · INIT 000001',960,211,20,'muted',{tracking:2});});
  centers.forEach((x,i)=>{const active=!!s.q[i];this.panel(x-104,368,208,253,{color:active?'red':'muted',alpha:active?.90:.35,header:`U${i+3} / DFF`,active});this.g.text(String(s.q[i]),x,503,133,active?'red':'ink',{shade:active?.95:.21,sx:.91});c.label('D',x-87,456,'muted',16);c.label('Q',x+86,456,'muted',16);
   this.after(()=>{this.line([[x-11,621],[x,605],[x+11,621]],'gold',2,.85);});c.wire([[x,621],[x,719]],'gold',s.clk===1);c.node([x,719],'gold');
   if(i<5){c.wire([[x+104,458],[centers[i+1]-104,458]],active?'red':'ink',active);if(active)c.arrows([[x+104,458],[centers[i+1]-104,458]],s.since*.7,'red',1,.8);}
  });
  const back=[[1739,458],[1781,458],[1781,280],[139,280],[139,458],[181,458]];
  c.wire(back,s.q[5]?'red':'ink',!!s.q[5]);if(s.q[5])c.arrows(back,s.since*.32,'red',7,.85);
  for(let j=0;j<stage;j++)this.after(()=>this.line([[1768-j*13,358-j*22],[1768-j*13,302-j*11],[156+j*12,302-j*11],[156+j*12,355-j*22]],'muted',1,.18+j*.06));
  c.wire([[145,719],[1769,719]],'gold',s.clk===1);c.label('CLK',188,763,'gold',18);c.label(`Q[5:0]  ${[...s.q].reverse().join('')}`,960,806,'ink',26);c.label('one bit · six states · no exit',960,849,'muted',18);
  this.after(()=>{const pts=[];for(let k=0;k<=400;k++){const tt=t-3.6+3.6*k/400;pts.push([300+k*3.66,765-28*M.counter(tt).clk]);}this.line(pts,'gold',2.5,.72);if(pulse>.05)this.line([[centers[s.index]-103,365],[centers[s.index]+103,365]],'red',4,pulse);});
  this.lastStats.counter=s;
 }
 executeCrescendo(t,u,s){
  const c=this.circuit,third=t>=155.07,local=t-(third?155.07:151.36),q=ease(smooth(0,.29,local)),beat=Math.exp(-Math.max(0,s.since)*11),centers=[285,555,825,1095,1365,1635];
  this.topic('EXECUTION');c.label('CLOCKED FEEDBACK / Q5 → D0',1750,150,'muted',15,'right');
  const word='EXECUTION',size=174+(third?18:0)+beat*3;
  // Six registered states become six bars around the call. Typography is an
  // artistic transformation, while the small circuit retains literal state.
  for(let i=0;i<6;i++){
   const x=centers[i],active=!!s.q[i],bottom=lerp(621,693,q),top=lerp(368,266,q);
   this.g.line([[x-100,top],[x-100,bottom]],active?18:9,active?'red':'ink',active?.81:.23);
   this.g.line([[x+100,top],[x+100,bottom]],active?18:9,active?'red':'ink',active?.81:.23);
   this.g.line([[x-100,top],[x+100,top]],6,'ink',.20);
  }
  this.g.ctx.clearRect(161,350,1598,211);this.g.ctx.clearRect(728,594,464,83);this.g.ctx.clearRect(788,249,344,68);this.letterpressWord(word,960,452,size,'ink',1,{sx:.89});
  if(third){const sweep=centers[s.index];this.g.ctx.save();this.g.ctx.beginPath();this.g.ctx.rect(sweep-112,348,224,212);this.g.ctx.clip();this.letterpressWord(word,960,452,size,'red',1,{sx:.89});this.g.ctx.restore();}
  this.after(()=>{this.label('world.',960,280,36,'gold',{tracking:5});this.label('( me );',960,630,50,'red',{tracking:8});});
  const yy=747;
  centers.forEach((x,i)=>{const active=!!s.q[i];this.panel(x-65,709,130,71,{color:active?'red':'muted',alpha:active?.87:.29});c.label('D',x-48,732,'muted',12);c.label('Q',x+48,732,'muted',12);this.g.text(String(s.q[i]),x,745,40,active?'red':'ink',{shade:active?.95:.38});this.after(()=>this.line([[x-7,780],[x,770],[x+7,780]],'gold',1.8,.8));c.wire([[x,780],[x,811]],'gold',s.clk===1);c.node([x,811],'gold');if(i<5)c.wire([[x+65,732],[centers[i+1]-65,732]],active?'red':'ink',active);});
  c.wire([[1700,732],[1782,732],[1782,217],[138,217],[138,732],[220,732]],s.q[5]?'red':'ink',!!s.q[5]);c.wire([[153,811],[1768,811]],'gold',s.clk===1);c.label('CLK',165,848,'gold',15);c.label(`Q[5:0]  ${[...s.q].reverse().join('')}`,960,853,'ink',18);
  if(s.q[5])c.arrows([[1700,732],[1782,732],[1782,217],[138,217],[138,732],[220,732]],s.since*.45,'red',9,.85);
  this.lastStats.counter=s;
 }
 inspect(kind,yaw,pitch=0){
  const map={power:[0,3.89],rectifier:[44.4,47.649],hold:[47.65,51.399],xy:[103.48,110.899],bus:[110.9,118.319],clock:[147.65,158.899]};
  if(!map[kind])return super.inspect(kind,yaw,pitch);
  const [a,b]=map[kind],t=lerp(a,b,clamp(this.labU)),st=this.render(t,{captions:0});
  const text={power:'上电复位：VDD 越过门限并保持 20 ms 后，才释放 /RESET。',rectifier:'二极管、负载、电容和波形共用同一个模型时刻；箭头表示约定电流方向。',hold:'理想采样保持：断开开关后，输入继续变化，缓冲输出保持断开瞬间的电容电压。',xy:'X 与 Y 取自同一时刻的两路输入；频率相等并相差 90° 时形成圆。',bus:'8 位地址字节之后的第 9 拍：释放 SDA，却没有接收方将它拉低。',clock:'所有 D 触发器在同一上升沿读取旧 Q；不是逐级瞬间穿透。'};
  this.label(text[kind],960,958,23,'ink',{font:SANS});this.label(`B05 · 简化电路／时序模型 · MV ${t.toFixed(3)} s · 拖动下方时间滑块检查`,960,1014,16,'muted',{font:SANS});return st;
 }
}
window.Film=FilmB04;
window.CircuitInk=CircuitInk;
})();
