/* B05: deliberately small, idealized classic circuits. Absolute-time states. */
'use strict';
(function(root){
const P=Object.freeze({vcc:5,ra:10000,rb:20000,c:1e-6,controlC:10e-9,decoupleC:100e-9,start:147.65,slow:50});
const high=Math.LN2*(P.ra+P.rb)*P.c,low=Math.LN2*P.rb*P.c,period=high+low;
function timer(t){
 const te=(t-P.start)/P.slow,cycle=Math.floor(te/period),phase=((te%period)+period)%period,on=phase<high;
 const vc=on?P.vcc-(P.vcc-P.vcc/3)*Math.exp(-phase/((P.ra+P.rb)*P.c)):(2*P.vcc/3)*Math.exp(-(phase-high)/(P.rb*P.c));
 const since=on?phase:phase-high;
 return {te,cycle,phase,high:on,out:on?1:0,vc,discharge:!on,thresholdLow:P.vcc/3,thresholdHigh:2*P.vcc/3,frequency:1/period,duty:high/period,highSeconds:high,lowSeconds:low,period,edgeAge:since*P.slow};
}
const LED=Object.freeze({vcc:5,r:1000,vf:2,close:.16});
function led(t){const on=t>=LED.close;return {on,current:on?(LED.vcc-LED.vf)/LED.r:0,voltage:on?LED.vf:0};}
const model={timer,params:P,high,low,period,led,LED};root.ClassicModel=model;
if(typeof module!=='undefined'&&module.exports)module.exports=model;
})(typeof window!=='undefined'?window:globalThis);
