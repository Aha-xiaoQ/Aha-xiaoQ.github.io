/* B05: one legible action per scene. Literal circuits and emotional metaphor
 * share timing, but artistic rings/bars are not presented as physical devices. */
'use strict';
(()=>{
const Base=window.Film,E=window.PressEngine,M=window.CircuitModel,C=window.ClassicModel;
const {PI,TAU,clamp,lerp,smooth,ease,fract,hash,samples,arcPoints,MONO,SANS,DISPLAY}=E;
class FilmB05 extends Base{
 constructor(c){super(c);this.edition='B05';}
 boot(t,u){
  if(t>=3.9)return super.boot(t,u);
  const c=this.circuit,s=C.led(t),on=s.on,shield=smooth(1.73,2.45,t);
  this.topic(t<1.73?'POWER':'PROTECTION');
  c.label('ONE SWITCH. ONE LIGHT.',1744,150,'muted',17,'right');
  c.wire([[307,450],[307,332],[534,332]],'red',on);
  c.switch([534,332],[617,332],smooth(.04,.16,t),'red');
  c.wire([[617,332],[746,332]],'red',on);c.component([746,332],[966,332],'resistor','red',on);
  c.wire([[966,332],[1375,332],[1375,438]],'red',on);
  c.component([1375,438],[1375,575],'diode','red',on);
  c.wire([[1375,575],[1375,691],[307,691],[307,544]],'ink',on);
  c.ground(307,703);c.node([307,691]);
  c.label('SW1',575,275,'muted',17);c.label('R1 · 1 kΩ',856,270,'red',26);
  c.label('CURRENT LIMIT',856,390,'teal',19);
  c.label('D1 / RED LED',1550,509,'red',23);c.label('5 V',216,497,'red',34);
  this.after(()=>{this.circle(307,497,47,'ink',2.7,.9);this.label('+',307,479,26,'red');this.label('−',307,516,26,'ink');
   for(let i=0;i<2;i++){let a=[1410+i*18,466+i*26],b=[1446+i*18,435+i*26];this.line([a,b],'red',2.4,on?.95:.23);this.line([[b[0]-9,b[1]+2],b,[b[0]-1,b[1]+10]],'red',2.4,on?.95:.23);}
  });
  if(on){c.arrows([[307,332],[534,332],[617,332],[1375,332],[1375,691],[307,691]],t*.16,'gold',6,.7);
   for(let i=0;i<4;i++){const q=fract((t-.16)*.57+i/4),r=52+q*131;this.after(()=>this.circle(1375,506,r,'red',1.3,(1-q)*.27));}
  }
  this.meCentered(838,537,88,0,.8,{width:28,shade:on?.9:.2});this.star(1096,527,45,0,{hollow:!on,color:on?'teal':'muted'});
  this.after(()=>{this.label(on?'3 mA':'0 mA',848,778,38,'red');this.label('a little resistance keeps the light alive',960,832,22,'ink',{font:E.SERIF});
   if(shield>0){this.line([[731,226],[731,405],[856,443],[981,405],[981,226]],'teal',2,shield*.72);}
  });
  this.lastStats.led=s;
 }
 absence(t,u){
  const starts=window.B03Math.absenceTimes,c=this.circuit;let attempt=0;for(let i=0;i<6;i++)if(t>=starts[i])attempt=i;
  const end=attempt<5?starts[attempt+1]:118.32,q=clamp((t-starts[attempt])/(end-starts[attempt])),units=Math.min(M.I2C.end,q*14.2),s=M.bus(units,false);
  this.topic('PLAYER TWO HAS LEFT');
  const gone=ease(smooth(110.9,112.18,t)),cx=1220,cy=461;
  this.meCentered(585,466,136,0,.8,{width:43});
  this.star(cx,cy,102,0,{hollow:true,color:'muted',alpha:.5});
  if(gone<1)this.star(cx+gone*363,cy-gone*178,102*(1-.55*gone),gone*.6,{alpha:1-gone});
  this.after(()=>{this.label('P1 / ME',585,234,28,'red');this.label('P2 / YOU',cx,234,28,'teal');
   this.label('CONNECTED',585,661,21,'red');this.label('DISCONNECTED',cx,661,21,'muted');
   this.line([[767,461],[874,461]],'red',4,.8);this.line([[963,461],[1043,461]],'muted',4,.3);
   this.line([[880,446],[880,475],[900,475],[900,446]],'red',2,.75);this.line([[949,446],[949,475],[929,475],[929,446]],'muted',2,.45);
   this.label(s.ackSample?'NO REPLY':'…',915,553,s.ackSample?32:42,'red');
  });
  // A single observed SDA line, explicitly clock-indexed; bit 9 has no ACK.
  const px=367,pw=1160,y=755,xof=a=>px+pw*a/M.I2C.end;
  c.label('I²C · 0x51 WRITE',199,741,'muted',14,'center');
  c.label('SDA',199,774,'teal',19);
  const pts=samples(z=>{const a=M.bus(z*units,false);return [xof(z*units),y+38-a.sda/3.3*40]},550);c.trace(pts,'teal',7);
  for(let i=0;i<9;i++){let x=xof(1.75+i);this.after(()=>{this.line([[x,742],[x,800]],i===8?'red':'muted',1,i===8?.65:.18);this.label(i===8?'9 / ACK':String(i+1),x,824,i===8?19:13,i===8?'red':'muted');});}
  if(s.ackSample)this.after(()=>{this.circle(xof(9.75),y-2,20,'red',2.5,.95);this.label('NACK',1683,772,35,'red');});
  for(let i=0;i<6;i++){let x=756+i*81;this.after(()=>{this.circle(x,191,8,i<=attempt?'red':'muted',2,i<=attempt?.85:.3);if(i<attempt||(i===attempt&&s.ackSample))this.line([[x-4,187],[x+4,195]],'red',2,.9);});}
  this.lastStats.bus={...s,attempt,byte:0xA2,address:0x51,txComplete:s.ackSample};
 }
 timerName(x,y){
  // A local 5x7 character matrix stays legible at this chip's scale. The
  // scene-wide 10x14 sampling grid would leave only four rows in this title.
  const shapes={N:['10001','11001','11001','10101','10011','10011','10001'],E:['11111','10000','10000','11110','10000','10000','11111'],'5':['11111','10000','10000','11110','00001','00001','11110']};
  const word='NE555',step=7.5,left=x-28*step/2,top=y-6*step/2;
  this.after(()=>{const ctx=this.ctx;ctx.save();ctx.fillStyle=this.p.ink;
   [...word].forEach((ch,i)=>shapes[ch].forEach((row,r)=>[...row].forEach((v,k)=>{if(v!=='1')return;
    const xx=left+(i*6+k)*step,yy=top+r*step;
    ctx.globalAlpha=.18;ctx.fillRect(xx-3.1,yy-3.1,6.2,6.2);ctx.globalAlpha=1;
    this.label((r+k)%3===0?'#':'+',xx,yy,10,'ink',{font:MONO,weight:700});
   })));ctx.restore();
  });
 }
 timerSchematic(t){
  const c=this.circuit,s=C.timer(t),hi=s.high;
  this.topic('THE CLOCK KEEPS GOING');c.label('NE555 / ASTABLE',1750,150,'gold',24,'right');
  const top=249,bottom=719,xr=489,dis=402,timing=555;
  // Pins 8 and 4 go to +5 V; 7 is the resistor junction; 2/6 share C1.
  c.wire([[291,top],[1109,top]],'red',true);c.label('+5 V',294,209,'red',23,'left');
  const valueLeft=352;
  c.component([xr,top],[xr,dis],'resistor','red',true);c.label('RA 10 kΩ',valueLeft,(top+dis)/2,'muted',18,'left');
  c.component([xr,dis],[xr,timing],'resistor',hi?'red':'teal',true);c.label('RB 20 kΩ',valueLeft,(dis+timing)/2,'muted',18,'left');
  c.component([xr,timing],[xr,bottom],'cap','teal',true);c.label('C1 1 µF',valueLeft,(timing+bottom)/2,'teal',18,'left');
  c.node([xr,dis]);c.node([xr,timing]);
  this.panel(710,317,368,326,{color:'gold',alpha:.78});
  this.timerName(894,487);
  c.label('OSCILLATOR',894,556,'gold',16);
  c.wire([[xr,dis],[710,dis]],hi?'red':'teal',true);c.label('7 DISCH',727,dis,'muted',16,'left');
  c.wire([[xr,timing],[650,timing],[650,526],[710,526]],'teal',true);c.wire([[650,timing],[650,583],[710,583]],'teal',true);c.node([650,timing]);
  c.label('6 THRES',727,526,'muted',16,'left');c.label('2 TRIG',727,583,'muted',16,'left');
  for(const [x,pin] of [[824,'8 VCC'],[1014,'4 RESET']]){c.wire([[x,top],[x,317]],'red',true);c.node([x,top]);c.label(pin,x,338,'muted',14);}
  c.wire([[812,643],[812,bottom]],'ink');c.label('1 GND',812,620,'muted',14);
  c.wire([[974,643],[974,658]],'ink');c.component([974,658],[974,bottom],'cap','ink');c.label('5 CONT',974,620,'muted',14);c.label('10 nF',1051,690,'muted',15);
  c.wire([[291,bottom],[1110,bottom]],'ink');c.node([xr,bottom]);c.node([812,bottom]);c.node([974,bottom]);c.ground(812,bottom+12);
  c.component([291,top],[291,bottom],'cap','ink');c.label('100 nF',209,490,'muted',15);
  c.wire([[1078,448],[1223,448]],'gold',hi);c.label('3 OUT',1061,448,'gold',16,'right');
  // Output level is logical H/L, not a rail-to-rail voltage claim.
  const px=1285,pw=455,py=308,h=365;c.frame(px,py,pw,h,'CAPACITOR / OUTPUT','ink');c.grid(px,py,pw,h,8,6);
  const tspan=C.period*C.params.slow*1.85,hist=z=>t-tspan+tspan*z;
  const voltage=samples(z=>[px+pw*z,492-C.timer(hist(z)).vc*43],250);
  const out=samples(z=>[px+pw*z,634-C.timer(hist(z)).out*67],330);c.trace(voltage,'teal',8);c.trace(out,'gold',8);
  this.after(()=>{for(const v of [5/3,10/3]){const yy=492-v*43;this.line([[px,yy],[px+pw,yy]],'muted',1,.43,[4,5]);this.label(v<2?'⅓ VCC':'⅔ VCC',px-14,yy,15,'muted',{align:'right'});}this.label('H',px-14,567,16,'gold',{align:'right'});this.label('L',px-14,634,16,'gold',{align:'right'});});
  c.label(hi?'CHARGE':'DISCHARGE',894,779,hi?'red':'teal',33);c.label('28.85 Hz · HIGH 60% · time ×50',960,839,'muted',19);
  c.label('steady-state ideal timing',1513,713,'muted',15);
  if(hi)c.arrows([[xr,top],[xr,dis],[xr,timing]],t*.22,'red',3,.95);
  else c.arrows([[xr,timing],[xr,dis],[710,dis]],t*.22,'teal',3,.95);
  this.lastStats.timer=s;
 }
 execute(t,u){
  if(t<151.36){this.timerSchematic(t);return;}
  const s=C.timer(t),third=t>=155.07,lt=t-(third?155.07:151.36),hit=Math.exp(-s.edgeAge*8),q=ease(smooth(0,.55,lt));
  this.topic('EXECUTION');const size=(third?195:178)+hit*5;
  for(let i=0;i<12;i++){let x=204+i*138,delay=i*.13,near=fract((t-151.36)*.22+delay),h=340+near*221;
   this.g.line([[x,479-h/2],[x,479+h/2]],(third?11:7)+near*9,i%3===s.cycle%3?'red':'ink',.17+near*.4);
  }
  for(let i=0;i<(third?5:3);i++){const k=fract(lt*.33+i/5),w=760+690*k,h=232+365*k;this.after(()=>this.line([[960-w/2,453-h/2],[960+w/2,453-h/2],[960+w/2,453+h/2],[960-w/2,453+h/2],[960-w/2,453-h/2]],'red',1.5,(1-k)*.35));}
  this.g.ctx.clearRect(107,347,1706,218);this.letterpressWord('EXECUTION',960,450,size,'ink',q,{sx:.89});
  this.g.ctx.clearRect(737,586,446,99);this.after(()=>{this.label('world.',960,263,35,'gold',{tracking:6});this.label('( me );',960,629,49,'red',{tracking:7});});
  this.meCentered(548,652,37,0,.8,{width:13});this.star(1372,649,30,0,{hollow:true,color:'muted',alpha:.7});
  const px=381,pw=1150,pts=samples(z=>[px+z*pw,794-45*C.timer(t-2.6+z*2.6).out],320);this.circuit.trace(pts,'gold',6);
  this.after(()=>{this.label('NE555',249,770,26,'gold');this.label(s.high?'HIGH':'LOW',1674,770,27,'gold');this.label('clock running · nobody returning',960,848,21,'muted');});
  this.lastStats.timer=s;
 }
 recursion(t,u){
  const lt=t-134.1,stage=Math.min(2,Math.floor(lt/4.51)),speed=.19+stage*.075,travel=lt*.19+(Math.max(0,lt-4.51)+Math.max(0,lt-9.02))*.075;
  this.topic(stage===0?'RETRY':stage===1?'NO RETURN':'NO BASE CASE');
  const cx=1038+Math.sin(lt*.39)*29*stage,cy=469;
  this.g.ctx.save();this.g.ctx.beginPath();this.g.ctx.rect(435,203,1367,602);this.g.ctx.clip();
  for(let i=21;i>=0;i--){let z=fract(i/22-travel/9),scale=.11+Math.pow(z,2.4)*2.23,r=379*scale,rot=smooth(3,12,lt)*(z*1.7+.18*Math.sin(lt*.42));
   const pts=arcPoints(cx,cy,r,-2.03+rot,3.46+rot,118,r*.76);this.g.line(pts,Math.max(2,15*scale),i%5===0&&stage===0?'gold':'red',.2+.7*z);
  }
  this.g.ctx.restore();this.meCentered(cx-18,cy,40,0,.8,{width:14});this.star(cx+86,cy-51,28,0,{hollow:true,color:'muted',alpha:.65});
  const depth=1+Math.floor(lt*(1.65+stage*1.3)),head=depth%6;
  this.after(()=>{this.label('CALL STACK',153,238,18,'muted',{align:'left',tracking:2});for(let i=0;i<6;i++){const n=Math.max(0,depth-5+i);this.label(`#${String(n).padStart(3,'0')} retry()`,153,300+i*48,20,i===5?'gold':'muted',{align:'left',alpha:i===5?1:.35+i*.07});}
   this.line([[151,590],[399,590]],'muted',1,.3);this.label('return: pending',153,627,17,'red',{align:'left'});this.label(stage===2?'no base case':'retry() calls retry()',1038,837,26,stage===2?'red':'ink');
   this.label(String(depth).padStart(3,'0'),275,738,78,'red',{font:DISPLAY,weight:700});
  });
  this.lastStats.recursion={depth,stage,metaphor:true};
 }
 simulation(t,u){
  // A two-player wireframe arena: it is a simulation metaphor, not a game UI.
  const beat=this.accent(t),van=[960,434],floor=785;
  this.after(()=>{for(let i=-8;i<=8;i++)this.line([van,[960+i*151,floor]],'teal',1,.19);for(let i=0;i<9;i++){let z=fract(i/9+u*.55),y=434+Math.pow(z,2)*351;this.line([[lerp(887,131,z),y],[lerp(1033,1789,z),y]],'teal',1,.17);}
   const bracketHalf=lerp(727,586,ease(u));this.label('P1',960-bracketHalf+18,213,24,'red');this.label('P2',960+bracketHalf-18,213,24,'teal');this.label('TWO PLAYERS / ONE WORLD',960,830,20,'muted',{tracking:2});
  });
  super.simulation(t,u);this.lastStats.arena={players:2,metaphor:true};
 }
 inspect(kind,yaw,pitch=0){
  if(kind==='power'||kind==='clock'){
   const t=kind==='power'?this.labU*3.89:147.65+this.labU*3.70,st=this.render(t,{captions:0});
   this.label(kind==='power'?'5 V → 开关 → 1 kΩ → 红色 LED：按 Vf = 2 V 简化，电流约 3 mA。':'NE555 无稳态：电容在 ⅓ VCC 与 ⅔ VCC 之间充放电；OUT 显示逻辑高低。',960,951,24,'ink',{font:SANS});
   this.label(`B05 · ${kind==='power'?'限流保护':'稳态理想时序；RA 10 kΩ / RB 20 kΩ / C 1 µF'} · ${t.toFixed(3)} s`,960,1010,17,'muted',{font:SANS});return st;
  }
  return super.inspect(kind,yaw,pitch);
 }
}
window.Film=FilmB05;
})();
