# 素材与参考

- 原曲：Mili《world.execute(me);》。官方视频：https://www.youtube.com/watch?v=ESx_hy1n7HA
- 本地音乐输入：用户提供、已内嵌于B04的48 kHz双声道AAC；B05保留此音轨。SHA-256：40e902c06dd2f5eee367ccc2fb9060a5e72d93870674ff7e3c8b63160e75f409。
- 字幕：81条中英字幕，采用句级时间。来源为用户提供的带字幕参考视频。
- 片尾：霞鹜文楷，https://github.com/lxgw/LxgwWenKai ，SIL Open Font License 1.1。字体文件不随包分发。
- 主片及AC→DC场景封面系统字体：微软雅黑、Consolas、Arial、Georgia。成片为栅格化画面，HTML在其他系统可能回退。
- 视觉：用户提供B04的Canvas程序几何与B05新增镜头；片尾为既有蓝色像素侧栏和动作图标，本期重新署名。
- TI NE555：https://www.ti.com/lit/ds/symlink/ne555.pdf
- NXP UM10204：https://www.nxp.com/docs/en/user-guide/UM10204.pdf
- Node.js Assert：https://nodejs.org/api/assert.html#assertokvalue-message
- AD/BC纪年：https://dictionaryblog.cambridge.org/2017/10/04/1066-and-all-that-how-to-say-years/

以上素材使用说明不代替音乐与歌词的相关授权。非官方同人作品，音乐及歌词权益归相应权利人。
