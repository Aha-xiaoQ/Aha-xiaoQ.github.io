#!/usr/bin/env python3
"""Independent circuit/timing checks for B04. Python/SciPy references vs JS model.
Requires Python 3, numpy, scipy and Node.js. Does not certify component-level hardware.
"""
from __future__ import annotations
import argparse, json, math, subprocess
from pathlib import Path
import numpy as np
from scipy.integrate import solve_ivp

ROOT=Path(__file__).resolve().parents[1]
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=ROOT/'tests/circuit_validation.json');a=ap.parse_args()
 # Export actual production-model samples, including off-grid interpolation times.
 code=r'''const M=require(process.argv[1]),r=M.createRectifier();
 const lin=(a,b,n)=>Array.from({length:n},(_,i)=>a+(b-a)*i/(n-1));
 const rt=lin(.030000123,.0649807,2001), pre=lin(-.04,.02999,801);
 console.log(JSON.stringify({R:M.rectifierParams,bridge:M.bridge,rect:rt.map(t=>r.at(t)),pre:pre.map(t=>r.at(t)),
 power:lin(0,3.9,781).map(t=>({...M.power(t),t})),PP:M.powerParams,
 busN:lin(0,11.5,2301).map(t=>M.bus(t,false)),busA:lin(0,11.5,2301).map(t=>M.bus(t,true)),
 events:M.busEvents(false),I2C:M.I2C,
 xy:lin(-.02,.15,1701).map(t=>M.xyAt(t)),hold:lin(47.2,51.399,901).map(t=>({...M.trackHold(t),t})),
 edges:M.rises,counter:M.rises.flatMap(t=>[t-1e-7,t+1e-7,t+.179,t+.181,t+.5]).map(t=>({...M.counter(t),t}))}));'''
 data=json.loads(subprocess.run(['node','-e',code,str(ROOT/'src/circuit_model.js')],check=True,capture_output=True,text=True).stdout)
 checks={};metrics={}
 def check(name,val):checks[name]=bool(val)
 R=data['R']; times=np.array([s['te'] for s in data['rect']]); got=np.array([s['vc'] for s in data['rect']])
 # Independent adaptive Dormand–Prince 8 reference. Not the JS fixed-step RK4.
 def rhs(t,y):
  source=R['rms']*math.sqrt(2)*math.sin(2*math.pi*R['f']*t)
  i=max(0,(abs(source)-2*R['vd']-y[0])/R['rs'])
  return [(i-y[0]/R['rl'])/R['c']]
 ref=solve_ivp(rhs,(.03,.065),[0.0],method='DOP853',rtol=1e-11,atol=1e-12,max_step=2e-5,dense_output=True)
 error=float(np.max(np.abs(got-ref.sol(times)[0])));metrics['independent_voltage_max_error_V']=error
 check('independent_DOP853_voltage_error_below_50uV',ref.success and error<50e-6)
 check('rectifier_output_nonnegative',all(s['vload']>=0 for s in data['rect']+data['pre']))
 check('rectifier_peak_limited',float(got.max())<=R['rms']*math.sqrt(2)-2*R['vd']+1e-7)
 residual=max(abs(s['id']-s['il']-s['ic']) for s in data['rect']);metrics['KCL_max_residual_A']=residual
 check('KCL_at_capacitor_load_node',residual<1e-12)
 check('unfiltered_load_KCL',max(abs(s['id']-s['il']) for s in data['pre'])<1e-12)
 check('unfiltered_capacitor_disconnected',all(not s['connected'] and s['vc']==0 and s['ic']==0 for s in data['pre']))
 expected_pairs=lambda s:(['D1','D4'] if s['vin']>=0 else ['D2','D3']) if s['id']>1e-7 else []
 check('conduction_pair_follows_current_not_merely_sine_sign',all(s['pair']==expected_pairs(s) for s in data['rect']+data['pre']))
 check('charging_flag_follows_net_capacitor_current',all(s['charging']==(s['ic']>1e-7) and s['discharging']==(s['ic']<-1e-7) for s in data['rect']))
 check('both_charging_and_discharge_occur',any(s['ic']>0.05 for s in data['rect']) and any(s['id']==0 and s['ic']<-.005 for s in data['rect']))
 check('finite_source_resistance_limits_surge',max(s['id'] for s in data['rect'])<(.001+R['rms']*math.sqrt(2)-2*R['vd'])/R['rs'])
 graph={d['id']:(d['a'],d['k']) for d in data['bridge']['diodes']}
 check('bridge_diode_polarities',graph=={'D1':('A','P'),'D2':('B','P'),'D3':('N','A'),'D4':('N','B')})
 check('bridge_load_and_capacitor_parallel',data['bridge']['branches'][:2]==[['P','RL','N'],['P','S2','C1','N']])
 # Separate analytic check of a source-off capacitor interval.
 s0=next(s for s in data['rect'] if s['te']>.0398);s1=next(s for s in data['rect'] if s['te']>.0402)
 exponential=s0['vc']*math.exp(-(s1['te']-s0['te'])/(R['rl']*R['c']))
 metrics['source_off_exponential_error_V']=abs(s1['vc']-exponential)
 check('source_off_capacitor_exponential',s0['id']==0 and s1['id']==0 and abs(s1['vc']-exponential)<1e-6)
 P=data['PP'];cross=P['on']-P['tau']*math.log(1-P['threshold']/P['vdd']);release=cross+P['delay']
 check('reset_held_until_threshold_plus_delay',all(s['released']==(s['t']/P['slow']>=release) for s in data['power']))
 check('reset_pullup_follows_rail',all(abs(s['reset']-(s['v'] if s['released'] else 0))<1e-12 for s in data['power']))
 check('reset_never_runs_below_threshold',all(not s['clockEnabled'] or s['v']>=P['threshold'] for s in data['power']))
 metrics['reset_release_music_seconds']=release*P['slow']
 # I2C logical semantics. SCL high data stability excludes intentional START/STOP.
 ev=data['events'];SCL=ev['scl'];SDA=ev['sda']
 def state(events,t):
  result=1
  for at,val in events:
   if at>t:break
   result=val
  return result
 changes=[];prior=1
 for at,val in SDA[1:]:
  if val!=prior:changes.append((at,val))
  prior=val
 check('SDA_changes_only_with_SCL_low_except_start_stop',all(state(SCL,t)==0 or (abs(t-.5)<1e-8 and v==0) or (abs(t-10.95)<1e-8 and v==1) for t,v in changes))
 bits=[state(SDA,1.75+i) for i in range(8)];byte=sum(v<<(7-i) for i,v in enumerate(bits))
 check('MSB_first_address_0x51_write',byte==0xA2 and byte>>1==0x51 and byte&1==0)
 check('ninth_clock_NACK_high',all(s['sda']>3.3*.7 for s in data['busN'] if 9.55<=s['units']<=9.99))
 check('ninth_clock_ACK_low',all(s['sda']<3.3*.3 for s in data['busA'] if 9.55<=s['units']<=9.99))
 check('exactly_9_data_ack_rises_before_stop',len([t for t,v in SCL if v==1 and 1<t<10])==9)
 I=data['I2C'];rise=I['rp']*I['cb']*math.log(7/3);to70=-I['rp']*I['cb']*math.log(.3)
 metrics['I2C_30_70_rise_ns']=rise*1e9
 check('standard_mode_rise_below_1000ns',rise<1e-6)
 stopsetup=(10.95-10.5)*I['period']-to70;metrics['STOP_setup_us']=stopsetup*1e6
 check('STOP_setup_above_4us',stopsetup>=4e-6)
 check('SCL_low_above_4p7us',.5*I['period']>=4.7e-6)
 check('SCL_high_above_4us',.5*I['period']-to70>=4e-6)
 check('idle_bus_both_high',all(s['scl']>3 and s['sda']>3 for s in data['busN'] if s['units']>11.4))
 # Two sinusoids use the same time, continuous phase and equal final amplitudes.
 check('XY_sample_identity',all(abs(s['x']-2.5*math.sin(s['phaseX']))<1e-12 and abs(s['y']-2.5*math.sin(s['phaseY']))<1e-12 for s in data['xy']))
 circleerr=max(abs(s['x']**2+s['y']**2-2.5**2) for s in data['xy'] if s['te']>.075)
 metrics['XY_circle_radius_squared_error']=circleerr
 check('XY_quadrature_circle_after_sweep',circleerr<1e-10)
 check('XY_frequency_settles_200_to_100',all(100<=s['fy']<=200 for s in data['xy']))
 check('hold_tracks_while_connected',all(abs(s['vc']-s['vin'])<1e-12 for s in data['hold'] if s['closed']))
 check('hold_retains_aperture_voltage_while_input_moves',all(s['vc']==2.5 and s['ic']==0 for s in data['hold'] if not s['closed']) and len({round(s['vin'],2) for s in data['hold'] if not s['closed']})>50)
 # Compare to independent sequential old-Q update, not production modulo index.
 for s in data['counter']:
  old=[1,0,0,0,0,0]
  for edge in data['edges']:
   if edge>s['t']:break
   old=[old[-1]]+old[:-1]
  if old!=s['q']:
   check('DFF_parallel_old_Q_update',False);break
 else:check('DFF_parallel_old_Q_update',True)
 check('DFF_one_hot',all(sum(s['q'])==1 for s in data['counter']))
 check('DFF_unchanged_at_falling_edge',all(data['counter'][i+2]['q']==data['counter'][i+3]['q'] for i in range(0,len(data['counter']),5)))
 report={'edition':'B04','passed':all(checks.values()),'checks':checks,'checks_count':len(checks),'metrics':metrics,'scope':'Simplified fixed-drop diode/ideal switch/generic supervisor/logic behavioral models. Independent ODE reference is not SPICE or physical bench validation.'}
 a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False,indent=2))
 raise SystemExit(0 if report['passed'] else 1)
if __name__=='__main__':main()
