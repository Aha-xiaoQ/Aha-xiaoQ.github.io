#!/usr/bin/env python3
"""Verify the exported MV against its self-contained HTML and original AAC audio.
Requires ffmpeg/ffprobe on PATH. No source or output files are modified.
"""
from __future__ import annotations
import argparse, base64, hashlib, json, math, re, shutil, subprocess, sys
from pathlib import Path
from typing import Any


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def probe(path: Path) -> dict[str, Any]:
    result = subprocess.run(['ffprobe', '-v', 'error', '-show_format', '-show_streams',
                             '-of', 'json', str(path)], capture_output=True, text=True, encoding='utf-8', check=True)
    return json.loads(result.stdout)


def aac_hash(path: Path) -> str:
    # ADTS normalizes the container, not the encoded AAC payload.
    result = subprocess.run(['ffmpeg', '-v', 'error', '-i', str(path), '-map', '0:a:0',
                             '-c:a', 'copy', '-f', 'adts', 'pipe:1'], capture_output=True, check=True)
    return hashlib.sha256(result.stdout).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('movie', type=Path)
    parser.add_argument('--html', type=Path, required=True)
    parser.add_argument('--audio', type=Path, required=True)
    parser.add_argument('--render-manifest', type=Path, required=True)
    parser.add_argument('--output', type=Path, default=Path('media_validation.json'))
    args = parser.parse_args()
    for command in ['ffmpeg', 'ffprobe']:
        if not shutil.which(command):
            parser.error(f'{command} is required on PATH')
    for path in [args.movie, args.html, args.audio, args.render_manifest]:
        if not path.is_file():
            parser.error(f'File not found: {path}')
    info = probe(args.movie)
    v = next(s for s in info['streams'] if s['codec_type'] == 'video')
    a = next(s for s in info['streams'] if s['codec_type'] == 'audio')
    original = probe(args.audio)
    original_audio = next(s for s in original['streams'] if s['codec_type'] == 'audio')
    manifest = json.loads(args.render_manifest.read_text(encoding='utf-8'))
    html_text = args.html.read_text(encoding='utf-8')
    match = re.search(r'data:audio/[^;,\s]+;base64,([A-Za-z0-9+/=]+)', html_text)
    if not match:
        raise ValueError('No embedded audio data URL found in HTML')
    embedded_hash = hashlib.sha256(base64.b64decode(match.group(1), validate=True)).hexdigest()
    input_hash = sha(args.audio)
    output_audio_hash, input_audio_hash = aac_hash(args.movie), aac_hash(args.audio)
    decode = subprocess.run(['ffmpeg', '-v', 'error', '-i', str(args.movie), '-map', '0:v:0',
                             '-map', '0:a:0', '-f', 'null', '-'], capture_output=True, text=True, encoding='utf-8')
    # Check presented frame times across the chunk splice as well as across the whole film.
    packets = subprocess.run(['ffprobe', '-v', 'error', '-select_streams', 'v:0',
                              '-show_packets', '-show_entries', 'packet=pts_time',
                              '-of', 'json', str(args.movie)], capture_output=True, text=True, encoding='utf-8', check=True)
    pts = sorted(float(p['pts_time']) for p in json.loads(packets.stdout)['packets'])
    fps = int(manifest['fps'])
    expected_frames = math.ceil(float(manifest['duration_target']) * fps)
    cadence_error = max((abs((y-x) - 1/fps) for x, y in zip(pts, pts[1:])), default=0)
    checks = {
        'video_1920x1080': (v['width'], v['height']) == (1920, 1080),
        'video_60fps': v['r_frame_rate'] == '60/1',
        'video_h264_yuv420p': v['codec_name'] == 'h264' and v['pix_fmt'] == 'yuv420p',
        'frame_count_matches_render': int(v['nb_frames']) == expected_frames == len(pts),
        'frame_cadence_continuous': cadence_error < 0.00001,
        'video_starts_at_zero': bool(pts) and abs(pts[0]) < 0.00001,
        'audio_format_preserved': a['codec_name'] == original_audio['codec_name'] == 'aac'
            and a['sample_rate'] == original_audio['sample_rate'] == '48000'
            and a['channels'] == original_audio['channels'] == 2,
        'audio_encoded_stream_identical': output_audio_hash == input_audio_hash,
        'html_audio_bytes_identical': embedded_hash == input_hash,
        'render_html_hash_matches': manifest['html_sha256'] == sha(args.html),
        'render_audio_hash_matches': manifest['audio_sha256'] == input_hash,
        'duration_within_one_frame': abs(float(info['format']['duration']) - float(manifest['duration_target'])) <= 1/fps,
        'full_audio_video_decode_clean': decode.returncode == 0 and not decode.stderr.strip(),
        'no_browser_export_errors': manifest.get('errors') == [],
    }
    report = {
        'pass': all(checks.values()), 'checks': checks,
        'movie': args.movie.name, 'movie_bytes': args.movie.stat().st_size,
        'movie_sha256': sha(args.movie), 'html_sha256': sha(args.html),
        'input_audio_sha256': input_hash, 'aac_adts_sha256': input_audio_hash,
        'width': v['width'], 'height': v['height'], 'fps': v['r_frame_rate'],
        'frames': int(v['nb_frames']), 'duration_seconds': float(info['format']['duration']),
        'video_duration_seconds': float(v['duration']), 'audio_duration_seconds': float(a['duration']),
        'maximum_frame_cadence_error_seconds': cadence_error,
        'decode_returncode': decode.returncode, 'decode_stderr': decode.stderr,
        'scope': 'Automated media verification, not a claim of human listening to every syllable.',
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False, indent=2))
    if not report['pass']:
        sys.exit(1)

if __name__ == '__main__':
    main()
