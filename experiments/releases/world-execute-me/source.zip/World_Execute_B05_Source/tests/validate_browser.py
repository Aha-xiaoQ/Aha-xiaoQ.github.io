#!/usr/bin/env python3
"""Chromium checks for the actual self-contained HTML; no network dependencies."""
import argparse,asyncio,json,hashlib,time,base64,statistics,shutil
from pathlib import Path
from playwright.async_api import async_playwright

async def validate(html_path:Path,output:Path):
 result={'html':str(html_path),'checks':{},'errors':[],'network_requests':[],'environment':'Linux / installed Chromium / Playwright; other browsers not executed'}
 html=html_path.read_text(encoding='utf-8')
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path=shutil.which('chromium'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--autoplay-policy=no-user-gesture-required'])
  page=await browser.new_page(viewport={'width':1440,'height':1080})
  page.on('pageerror',lambda e:result['errors'].append(str(e)))
  page.on('request',lambda r:result['network_requests'].append(r.url) if r.url.startswith(('http:','https:')) else None)
  try:
   await page.goto(html_path.resolve().as_uri(),wait_until='load')
  except Exception as exc:
   result['file_navigation_restriction']=str(exc).split('Call log:')[0].strip()
   result['tested_load_method']='set_content with exact self-contained HTML, no external assets'
   await page.set_content(html,wait_until='load')
  await page.wait_for_function('window.__filmReady === true');await page.evaluate('document.fonts.ready')
  await page.wait_for_function('document.getElementById("music").readyState >= 1')
  result['checks']['audio']=await page.evaluate('()=>{let a=document.getElementById("music");return {duration:a.duration,readyState:a.readyState,format:a.canPlayType("audio/mp4"),paused:a.paused}}')
  await page.screenshot(path=str(output.parent/'player_desktop.png'))
  await page.click('#begin');await page.wait_for_timeout(700)
  t1=await page.evaluate('document.getElementById("music").currentTime');await page.wait_for_timeout(400)
  t2=await page.evaluate('document.getElementById("music").currentTime')
  result['checks']['play_advances']=t2>t1>0
  await page.click('#play');ta=await page.evaluate('document.getElementById("music").currentTime');await page.wait_for_timeout(250);tb=await page.evaluate('document.getElementById("music").currentTime')
  result['checks']['pause_stops']=abs(tb-ta)<.03
  await page.evaluate('window.setFilmTime(83.3)');await page.wait_for_timeout(150)
  result['checks']['seek_correct']=await page.evaluate('Math.abs(document.getElementById("music").currentTime-83.3)<.02 && film.lastStats.shot==="cat"')
  labels=[]
  for _ in range(3):await page.click('#cc');labels.append(await page.locator('#cc').inner_text())
  result['checks']['captions_cycle']=labels==['English','字幕关','中英字幕']
  await page.click('#inspect');await page.click('[data-kind="separation"]');await page.click('#side')
  result['checks']['inspector_pauses']=await page.evaluate('document.getElementById("music").paused && film.lastStats.kind==="separation" && Math.abs(film.lastStats.yaw-Math.PI/2)<1e-8')
  await page.screenshot(path=str(output.parent/'inspector.png'))
  await page.click('#return');result['checks']['inspector_returns']=await page.evaluate('film.lastStats.shot==="cat"')
  await page.click('#mute');result['checks']['mute']=await page.evaluate('document.getElementById("music").muted')
  # Geometric claims checked numerically, not by a text label.
  result['checks']['geometry']=await page.evaluate('''()=>{const E=PressEngine, f=film;f.camera({yaw:0,pitch:0,scale:1,cx:0,cy:0});let radial=0;for(let i=0;i<=100;i++){let p=f.project(E.H(i/100));radial=Math.max(radial,Math.abs(Math.hypot(p[0],p[1])-1.5))}f.camera({yaw:Math.PI/2,pitch:0,scale:1,cx:0,cy:0});let sine=0;for(let i=0;i<=100;i++){let s=i/100,p=f.project(E.H(s));sine=Math.max(sine,Math.abs(p[0]-6.8*(s-.5)),Math.abs(p[1]+1.5*Math.sin(4*Math.PI*s)))}let eps=1e-6,sd=.625,exact=E.Hd(sd),derivative=E.mul(E.sub(E.H(sd+eps),E.H(sd-eps)),1/(2*eps)),err=Math.hypot(...E.sub(exact,derivative));const a=E.add(E.H(sd),[0,.385,0]),b=E.add(a,[0,0,5.3]);f.camera({yaw:0,pitch:0});let p=f.project(a),q=f.project(b),front=Math.hypot(p[0]-q[0],p[1]-q[1]);return {circle_max_error:radial,sine_max_error:sine,derivative_max_error:err,separation:Math.hypot(...E.sub(a,b)),front_projected_gap:front};}''')
  # all shots, boundary windows and caption starts, random access repeatability
  data=await page.evaluate('''()=>{let times=film.shots.flatMap(s=>[s.start+.015,(s.start+s.end)/2,s.end-.015]);let durations=[],bad=[];for(const t of times){let a=performance.now();let st=renderFrame(t);durations.push(performance.now()-a);if(!st.shot||!Number.isFinite(st.faces))bad.push(st)};let widths=MV_SCORE.cues.map(c=>{film.ctx.font='29px "Noto Sans CJK SC"';return film.ctx.measureText(c.zh).width});return {frames:times.length,durations,bad,maxChineseWidth:Math.max(...widths),cues:MV_SCORE.cues.length,chapters:MV_SCORE.chapters.length,shots:film.shots.length}}''')
  result['checks']['sweep']={k:v for k,v in data.items() if k!='durations'}
  result['render_time_ms']={'median':statistics.median(data['durations']),'p95':sorted(data['durations'])[int(.95*(len(data['durations'])-1))]}
  hashes=[]
  for t in [57.1,175.9,83.3,57.1]:
   encoded=await page.evaluate('(t)=>{renderFrame(t);return document.getElementById("film").toDataURL().split(",")[1]}',t)
   hashes.append(hashlib.sha256(base64.b64decode(encoded)).hexdigest())
  result['checks']['deterministic_random_access']=hashes[0]==hashes[-1]
  # Portrait layout from a fresh player, not export state.
  mobile=await browser.new_page(viewport={'width':390,'height':844},device_scale_factor=1)
  mobile.on('pageerror',lambda e:result['errors'].append('mobile: '+str(e)))
  await mobile.set_content(html,wait_until='load');await mobile.wait_for_function('window.__filmReady===true')
  await mobile.screenshot(path=str(output.parent/'player_mobile.png'))
  result['checks']['mobile_no_horizontal_overflow']=await mobile.evaluate('document.documentElement.scrollWidth<=innerWidth')
  await browser.close()
 result['success']=not result['errors'] and not result['network_requests'] and all(result['checks'].get(k,False) for k in ['play_advances','pause_stops','seek_correct','captions_cycle','inspector_pauses','inspector_returns','mute','deterministic_random_access','mobile_no_horizontal_overflow']) and not result['checks']['sweep']['bad']
 output.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps(result,ensure_ascii=False,indent=2))
 return result['success']
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('html',type=Path);ap.add_argument('--output',type=Path,default=Path('browser_validation.json'));args=ap.parse_args();args.output.parent.mkdir(parents=True,exist_ok=True);raise SystemExit(0 if asyncio.run(validate(args.html,args.output)) else 1)
