#!/usr/bin/env python3
"""Bounded actual desktop/mobile interaction + supplemental literal circuit draw checks."""
import asyncio,hashlib,json
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT.parent/'review/code'

async def main():
 html=(ROOT/'index.html').read_text(encoding='utf-8');checks={};errors=[];requests=[]
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='C:/Program Files/Google/Chrome/Application/chrome.exe',headless=True,args=['--autoplay-policy=no-user-gesture-required'])
  pg=await b.new_page(viewport={'width':1440,'height':1080});pg.on('pageerror',lambda e:errors.append(str(e)));pg.on('request',lambda r:requests.append(r.url) if r.url.startswith(('http:','https:')) else None)
  await pg.set_content(html,wait_until='load');await pg.wait_for_function('window.__filmReady');await pg.evaluate('document.fonts.ready')
  await pg.wait_for_function('document.getElementById("music").readyState>=1')
  duration=await pg.evaluate('document.getElementById("music").duration');checks['audio_duration_matches_211_925333']=abs(duration-211.925333)<.03
  await pg.click('#begin');await pg.wait_for_timeout(250);t0=await pg.evaluate('document.getElementById("music").currentTime');await pg.wait_for_timeout(350);t1=await pg.evaluate('document.getElementById("music").currentTime');checks['play_advances']=t1>t0>0
  await pg.click('#play');t0=await pg.evaluate('document.getElementById("music").currentTime');await pg.wait_for_timeout(200);t1=await pg.evaluate('document.getElementById("music").currentTime');checks['pause_stops']=abs(t1-t0)<.02
  await pg.evaluate('window.setFilmTime(83.3)');checks['seek_to_cat']=await pg.evaluate('film.lastStats.shot==="cat"&&Math.abs(document.getElementById("music").currentTime-83.3)<.02')
  labels=[]
  for _ in range(3):await pg.click('#cc');labels.append(await pg.locator('#cc').inner_text())
  checks['caption_modes_cycle']=labels==['English','字幕关','中英字幕']
  await pg.click('#inspect');await pg.click('[data-kind="power"]');checks['power_inspector_new_LED']=await pg.evaluate('!!film.lastStats.led&&film.lastStats.led.current===.003&&document.getElementById("music").paused')
  await pg.evaluate('let el=document.getElementById("labslider");el.value=0;el.dispatchEvent(new Event("input",{bubbles:true}));');checks['LED_inspector_slider_open']=await pg.evaluate('film.lastStats.led.on===false&&film.lastStats.led.current===0')
  await pg.click('[data-kind="clock"]');checks['clock_inspector_new_555']=await pg.evaluate('!!film.lastStats.timer&&film.lastStats.timer.vc>=5/3-1e-9')
  await pg.evaluate('let el=document.getElementById("labslider");el.value=340;el.dispatchEvent(new Event("input",{bubbles:true}));');checks['clock_inspector_slider_reaches_discharge']=await pg.evaluate('film.lastStats.timer.discharge===true')
  await pg.screenshot(path=str(OUT/'desktop_clock_inspector.png'))
  await pg.click('#return');checks['inspector_returns_to_cat']=await pg.evaluate('film.lastStats.shot==="cat"')
  await pg.click('#mute');checks['mute_toggles']=await pg.evaluate('document.getElementById("music").muted')
  extra=await pg.evaluate(r'''()=>{
   const c=film.circuit,old={},methods=['component','wire','ground','switch','trace'],checks={};let rec;
   for(const k of methods){old[k]=c[k];c[k]=function(...args){rec[k].push(args);return old[k].apply(this,args)}}
   const eq=(a,b)=>Math.hypot(a[0]-b[0],a[1]-b[1])<1e-7;
   function shot(t){rec=Object.fromEntries(methods.map(k=>[k,[]]));return {state:renderFrame(t),calls:rec};}
   for(const t of [49,49.56999,49.57001,50.4]){const {state:s,calls:a}=shot(t),h=s.sampleHold;
    checks['hold switch plus traces '+t]=a.switch[0][2]===(h.closed?1:0)&&eq(a.trace[0][0].at(-1),[1670,805-h.vin*20])&&eq(a.trace[1][0].at(-1),[1670,805-h.vc*20]);
    checks['hold feedback same output to minus '+t]=a.wire.some(x=>JSON.stringify(x[0])===JSON.stringify([[1169,537],[1169,654],[903,654],[903,580],[944,580]]));
    checks['hold supply rails explicit '+t]=a.wire.some(x=>JSON.stringify(x[0])===JSON.stringify([[991,486],[991,463]]))&&a.wire.some(x=>JSON.stringify(x[0])===JSON.stringify([[991,588],[991,617]]));
    checks['hold grounds touch actual leads '+t]=a.ground.some(x=>x[0]===250&&x[1]-12===668)&&a.ground.some(x=>x[0]===785&&x[1]-12===659);
   }
   let a=shot(147.8).calls;checks['555 ground stem touches bus']=a.ground.some(x=>x[0]===812&&x[1]-12===719);
   a=shot(2.5).calls;checks['LED ground stem touches return']=a.ground.some(x=>x[0]===307&&x[1]-12===691);
   checks['LED anode above cathode and resistor serial']=a.component.some(x=>x[2]==='diode'&&eq(x[0],[1375,438])&&eq(x[1],[1375,575]))&&a.component.some(x=>x[2]==='resistor'&&eq(x[0],[746,332])&&eq(x[1],[966,332]));
   a=shot(46.4).calls;checks['rectifier ground stem touches N']=a.ground.some(x=>x[0]===952&&x[1]-12===664);
   for(const k of methods)c[k]=old[k];return checks;
  }''');checks.update(extra)
  await pg.set_viewport_size({'width':390,'height':844});await pg.set_content(html,wait_until='load');await pg.wait_for_function('window.__filmReady');await pg.evaluate('document.fonts.ready')
  checks['mobile_no_horizontal_overflow']=await pg.evaluate('document.documentElement.scrollWidth<=innerWidth')
  await pg.click('#begin');await pg.wait_for_timeout(200);await pg.click('#play');await pg.click('#inspect');await pg.click('[data-kind="clock"]');checks['mobile_clock_button_works']=await pg.evaluate('!!film.lastStats.timer')
  await pg.screenshot(path=str(OUT/'mobile_clock_inspector.png'),full_page=True)
  checks['mobile_control_button_min_size']=await pg.locator('#inspect').evaluate('(e)=>{let r=e.getBoundingClientRect();return r.width>=44&&r.height>=30}')
  await b.close()
 checks['no_browser_errors']=not errors;checks['no_external_requests']=not requests
 result={'passed':all(checks.values()),'checks':checks,'errors':errors,'network_requests':requests,'audio_duration':duration,'html_sha256':hashlib.sha256((ROOT/'index.html').read_bytes()).hexdigest(),'loaded_html_text_sha256':hashlib.sha256(html.encode()).hexdigest(),'environment':'Windows Chrome headless; desktop1440x1080, mobile390x844'}
 (OUT/'player_validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(result,ensure_ascii=False,indent=2));return result['passed']
if __name__=='__main__':raise SystemExit(0 if asyncio.run(main()) else 1)
