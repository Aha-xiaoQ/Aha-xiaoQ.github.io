#!/usr/bin/env python3
"""Independent B05 acceptance: ODE, production draw calls, random seek, B04 pixels.
Does not build or mutate production files. Windows Chrome is the default browser.
"""
import argparse, asyncio, base64, hashlib, io, json, math, subprocess, time
from pathlib import Path
import numpy as np
from scipy.integrate import solve_ivp
from playwright.async_api import async_playwright
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
CHROME = Path('C:/Program Files/Google/Chrome/Application/chrome.exe')

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def production_samples():
    code = r'''const C=require(process.argv[1]);const ts=[];
    for(let i=0;i<=2400;i++)ts.push(144.31+i*17.02/2400);
    for(let k=-2;k<=8;k++)for(const phase of [0,C.high])for(const e of [-1e-7,1e-7])ts.push(C.params.start+50*(k*C.period+phase)+e);
    console.log(JSON.stringify({params:C.params,LED:C.LED,samples:ts.map(t=>({t,...C.timer(t)})),led:[-.1,.039,.15999999,.16,.16000001,3.89].map(t=>({t,...C.led(t)}))}));'''
    return json.loads(subprocess.run(['node', '-e', code, str(ROOT/'src/classic_model.js')], check=True, capture_output=True, text=True).stdout)

def waveform_check(data):
    """Evaluate every actual captured point using independent fixed constants."""
    wave_errors=[];logic_ok=True;point_count=0
    period=math.log(2)*.05;high=math.log(2)*.03
    for shot in data['shots']:
        t=shot['t']
        if 'timer' not in shot['state']:continue
        traces=shot['calls']['trace']
        if t<151.36:
            for ch,tr in enumerate(traces):
                xy=np.array(tr[0]);point_count+=len(xy);tt=t-period*50*1.85+np.linspace(0,period*50*1.85,len(xy));phase=np.mod((tt-147.65)/50,period);hi=phase<high
                if ch==0:
                    v=np.where(hi,5-(10/3)*np.exp(-phase/.03),(10/3)*np.exp(-(phase-high)/.02));wave_errors.append(float(np.max(np.abs(xy[:,1]-(492-43*v)))))
                else:logic_ok=logic_ok and bool(np.all(np.abs(xy[:,1]-(634-67*hi))<1e-8))
        else:
            xy=np.array(traces[0][0]);point_count+=len(xy);phase=np.mod((t-2.6+np.linspace(0,2.6,len(xy))-147.65)/50,period)
            logic_ok=logic_ok and bool(np.all(np.abs(xy[:,1]-(794-45*(phase<high)))<1e-8))
    return {'checks':{'every_drawn_VC_point_independent_closedform':max(wave_errors)<1e-8,'every_drawn_OUT_point_independent_timing':logic_ok},'waveform_max_pixel_error':max(wave_errors),'drawn_points_checked':point_count}

DRAW_JS = r'''()=>{
 const c=film.circuit, methods=['component','trace','arrows','switch','wire','node','ground','label'],old={},checks=[],shots=[];let rec;
 for(const k of methods){old[k]=c[k];c[k]=function(...args){rec[k].push(args);return old[k].apply(this,args)}}
 const oldLabel=film.label;film.label=function(...args){rec.text.push(args);return oldLabel.apply(this,args)};
 const eq=(a,b)=>Math.hypot(a[0]-b[0],a[1]-b[1])<1e-7, check=(name,pass)=>checks.push({name,pass});
 function shot(t){rec=Object.fromEntries([...methods,'text'].map(k=>[k,[]]));const state=renderFrame(t,{captions:0});return {t,state,calls:rec};}
 for(const t of [.039,.15999999,.16,.25,2.5]){
  const a=shot(t),on=t>=.16;shots.push(a);
  check('LED switched by same state '+t,a.state.led.on===on&&a.calls.switch.length===1&&(on?a.calls.switch[0][2]===1:a.calls.switch[0][2]<1));
  check('LED displayed current '+t,a.calls.text.some(x=>x[0]===(on?'3 mA':'0 mA')));
 }
 for(const t of [147.65,147.8,148.68971,148.68973,149.37,149.4,150.6,151.35,151.36,153.9,156.2,158.89]){
  const a=shot(t),s=a.state.timer;shots.push(a);
  check('timer stats exist '+t,!!s);
  if(t<151.36){
   check('VC live endpoint '+t,eq(a.calls.trace[0][0].at(-1),[1740,492-43*s.vc]));
   check('OUT live endpoint '+t,eq(a.calls.trace[1][0].at(-1),[1740,634-67*s.out]));
   check('OUT pin highlight '+t,a.calls.wire.some(x=>eq(x[0][0],[1078,448])&&eq(x[0].at(-1),[1223,448])&&x[2]===s.high));
   check('same-time charge label '+t,a.calls.text.some(x=>x[0]===(s.high?'CHARGE':'DISCHARGE')));
   check('RA remains active during discharge '+t,a.calls.component.some(x=>eq(x[0],[489,249])&&eq(x[1],[489,402])&&x[4]===true));
  }else{
   check('crescendo OUT live endpoint '+t,eq(a.calls.trace[0][0].at(-1),[1531,794-45*s.out]));
   check('crescendo level text '+t,a.calls.text.some(x=>x[0]===(s.high?'HIGH':'LOW')));
  }
 }
 for(const t of [110.9,111.1,111.7,112.17,113.82,117.7,118.319]){
  const a=shot(t),s=a.state.bus;shots.push(a);const x=367+1160*s.units/CircuitModel.I2C.end;
  check('one actual SDA waveform '+t,a.calls.trace.length===1&&eq(a.calls.trace[0][0].at(-1),[x,793-s.sda/3.3*40]));
  check('SDA label and nine clock labels '+t,a.calls.text.some(x=>x[0]==='SDA')&&[1,2,3,4,5,6,7,8].every(i=>a.calls.text.some(x=>x[0]===String(i)))&&a.calls.text.some(x=>x[0]==='9 / ACK'));
  check('NACK follows ninth sample '+t,a.calls.text.some(x=>x[0]==='NACK')===s.ackSample);
  check('target explicitly disconnected '+t,a.calls.text.some(x=>x[0]==='DISCONNECTED'));
 }
 for(const t of [108.22999,108.23001,109.8]){const a=shot(t);shots.push(a);check('XY lock waits full history '+t,a.state.xy.lockedCircle===(t>=108.23));}
 for(const t of [44.52,44.65,45.15,45.75,46.08,46.3,46.52,46.9,47.32]){
  const a=shot(t),r=a.state.rectifier,d=a.calls.component.filter(x=>x[2]==='diode'),ds=CircuitModel.bridge.diodes,N=CircuitModel.bridge.nodes;
  check('bridge actual diode directions and active pair '+t,d.length===4&&d.every((x,i)=>eq(x[0],N[ds[i].a])&&eq(x[1],N[ds[i].k])&&x[4]===r.pair.includes(ds[i].id)));
  check('bridge actual trace endpoints '+t,eq(a.calls.trace[0][0].at(-1),[550,457-r.vin*13.9])&&eq(a.calls.trace[1][0].at(-1),[1764,596-r.vload*34.75]));
 }
 // Sweep real render dispatch at each shot's boundaries and midpoint.
 const sweep=[];for(const sh of film.shots)for(const t of [sh.start+.0001,(sh.start+sh.end)/2,sh.end-.0001]){const a=shot(t);sweep.push({t,shot:a.state.shot,faces:a.state.faces});}
 check('all dispatch frames valid',sweep.every(a=>a.shot&&Number.isFinite(a.faces)));
 for(const k of methods)c[k]=old[k];film.label=oldLabel;
 return {checks,shots,sweep};
}'''

async def browser_checks(html, baseline, out):
    result={'checks':{},'errors':[],'network_requests':[], 'environment':'Windows / installed Google Chrome / Playwright'}
    async with async_playwright() as p:
        browser=await p.chromium.launch(executable_path=str(CHROME),headless=True,args=['--disable-dev-shm-usage'])
        async def page_for(path):
            pg=await browser.new_page(viewport={'width':1920,'height':1080})
            pg.on('pageerror',lambda e:result['errors'].append(str(e)))
            pg.on('request',lambda r:result['network_requests'].append(r.url) if r.url.startswith(('http:','https:')) else None)
            await pg.set_content(path.read_text(encoding='utf-8').replace('<head>','<head><script>window.__EXPORT__=true;</script>'),wait_until='load')
            await pg.wait_for_function('window.__filmReady===true');await pg.evaluate('document.fonts.ready')
            return pg
        page=await page_for(html)
        data=await page.evaluate(DRAW_JS)
        (out/'draw_calls.json').write_text(json.dumps(data,ensure_ascii=False),encoding='utf-8')
        result['checks'].update({c['name']:c['pass'] for c in data['checks']})
        wave=waveform_check(data);result['checks'].update(wave['checks']);result['waveform_max_pixel_error']=wave['waveform_max_pixel_error'];result['drawn_points_checked']=wave['drawn_points_checked']
        result['frames_swept']=len(data['sweep'])
        async def pixels(pg,t):
            enc=await pg.evaluate('(t)=>{renderFrame(t,{captions:2});return document.getElementById("film").toDataURL().split(",")[1]}',t)
            return base64.b64decode(enc)
        hashes=[]
        for t in [148.21,111.78,156.2,147.65,72,148.21]: hashes.append(hashlib.sha256(await pixels(page,t)).hexdigest())
        result['checks']['backward_seek_repeat_exact_pixels']=hashes[0]==hashes[-1]
        result['random_seek_hashes']=hashes
        for name,t in [('led',2.5),('555_high',147.8),('555_low',148.9),('nack',111.8),('execution',156.2),('recursion',142.3),('time',53.0),('infinity',42.5)]:
            (out/f'{name}.png').write_bytes(await pixels(page,t))
        # Same browser and font resolution, original B04 HTML is never edited.
        old=await page_for(baseline);preserved=[]
        for t in [44.4001,44.52,44.65,45.15,45.75,46.08,46.3,46.52,46.9,47.32,47.6499,30.5,35,38.8,83.3,84.8,170.5,174.2,175.9,176.9]:
            before=await pixels(old,t);after=await pixels(page,t)
            arr0=np.array(Image.open(io.BytesIO(before)));arr1=np.array(Image.open(io.BytesIO(after)))
            diff=np.any(arr0!=arr1,axis=2)
            if 44.4<=t<47.65:diff[663:713,925:999]=False
            preserved.append({'t':t,'equal':before==after,'outside_authorized_ground_fix_equal':not bool(np.any(diff)),'different_pixels_outside_mask':int(np.count_nonzero(diff)),'baseline_sha256':hashlib.sha256(before).hexdigest(),'candidate_sha256':hashlib.sha256(after).hexdigest()})
        result['preserved_frames']=preserved
        result['checks']['AC_DC_11_frames_exact_outside_ground_symbol_fix']=all(a['outside_authorized_ground_fix_equal'] for a in preserved[:11])
        result['checks']['geometry_cat_restore_reveal_9_frames_exact_pixels']=all(a['equal'] for a in preserved[11:])
        # Pin network inferred from actual wire geometry; component bodies are gaps.
        calls=next(s['calls'] for s in data['shots'] if s['t']==147.8)
        segments=[(a,b) for w in calls['wire'] for a,b in zip(w[0],w[0][1:])]
        pts={tuple(p) for s in segments for p in s}
        pins={'vcc8':(824,317),'reset4':(1014,317),'gnd1':(812,643),'cont5':(974,643),'dis7':(710,402),'thres6':(710,526),'trig2':(710,583),'out3':(1078,448)}
        pts.update(pins.values());pts=list(pts);parent=list(range(len(pts)))
        def find(i):
            while parent[i]!=i: i=parent[i]
            return i
        def onseg(p,a,b):
            return abs((p[0]-a[0])*(b[1]-a[1])-(p[1]-a[1])*(b[0]-a[0]))<1e-7 and min(a[0],b[0])-1e-7<=p[0]<=max(a[0],b[0])+1e-7 and min(a[1],b[1])-1e-7<=p[1]<=max(a[1],b[1])+1e-7
        for a,b in segments:
            ids=[i for i,p in enumerate(pts) if onseg(p,a,b)]
            for i in ids[1:]:parent[find(i)]=find(ids[0])
        def same(a,b):return find(pts.index(tuple(a)))==find(pts.index(tuple(b)))
        result['checks'].update({
            'drawn_pin8_pin4_RA_high_decouple_share_vcc':all(same((489,249),p) for p in [pins['vcc8'],pins['reset4'],(291,249)]),
            'drawn_RA_low_RB_high_pin7_shared':same((489,402),pins['dis7']),
            'drawn_RB_low_C_high_pin2_pin6_shared':all(same((489,555),p) for p in [pins['thres6'],pins['trig2']]),
            'drawn_C_low_pin1_decouple_low_control_low_shared':all(same((489,719),p) for p in [pins['gnd1'],(291,719),(974,719)]),
            'drawn_control_pin5_cap_high':same(pins['cont5'],(974,658)),
            'drawn_vcc_discharge_timing_ground_separate':len({find(pts.index(p)) for p in [(489,249),(489,402),(489,555),(489,719)]})==4,
            'drawn_output_not_directly_joined_to_rails':all(not same(pins['out3'],p) for p in [(489,249),(489,402),(489,555),(489,719)]),
        })
        await browser.close()
    result['checks']['no_browser_errors']=not result['errors'];result['checks']['no_external_network_requests']=not result['network_requests']
    return result

async def main():
    ap=argparse.ArgumentParser();ap.add_argument('--html',type=Path,default=ROOT/'index.html');ap.add_argument('--baseline',type=Path,default=ROOT.parents[1]/'World_Execute_B04/World_Execute_B04_Source/index.html');ap.add_argument('--output',type=Path,default=ROOT.parent/'review/code');a=ap.parse_args();a.output.mkdir(parents=True,exist_ok=True)
    files=[*sorted((ROOT/'src').glob('*')),a.html,a.baseline];hashes={str(p):sha(p) for p in files if p.is_file()}
    report={'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'hashes_before':hashes,'checks':{},'metrics':{}}
    def check(k,v):report['checks'][k]=bool(v)
    data=production_samples();params=data['params'];h=math.log(2)*.03;l=math.log(2)*.02;period=h+l
    check('parameters_independently_expected',params=={'vcc':5,'ra':10000,'rb':20000,'c':1e-6,'controlC':1e-8,'decoupleC':1e-7,'start':147.65,'slow':50})
    te=np.array([(s['t']-147.65)/50 for s in data['samples']]);phase=np.mod(te,period);hi=phase<h
    vc=np.where(hi,5-(10/3)*np.exp(-phase/.03),(10/3)*np.exp(-(phase-h)/.02))
    got=np.array([s['vc'] for s in data['samples']]);err=float(np.max(np.abs(vc-got)));report['metrics']['independent_closedform_max_V_error']=err
    report['metrics']['model_sample_count']=len(data['samples']);check('closed_form_voltage_all_samples',err<2e-11)
    check('logical_high_60percent_and_discharge_inverse',all(s['high']==bool(b) and s['out']==int(b) and s['discharge']==(not b) and abs(s['duty']-.6)<1e-14 for s,b in zip(data['samples'],hi)))
    check('steady_state_thresholds_and_frequency',all(5/3-1e-10<=s['vc']<=10/3+1e-10 and abs(s['frequency']-1/period)<1e-11 for s in data['samples']))
    # Independent adaptive ODE integration over charge and discharge, not modulo formula.
    charge=solve_ivp(lambda t,y:[(5-y[0])/.03],(0,h),[5/3],rtol=1e-11,atol=1e-12,dense_output=True,method='DOP853')
    discharge=solve_ivp(lambda t,y:[-y[0]/.02],(0,l),[10/3],rtol=1e-11,atol=1e-12,dense_output=True,method='DOP853')
    ode=np.array([charge.sol(p)[0] if b else discharge.sol(p-h)[0] for p,b in zip(phase,hi)])
    err=float(np.max(np.abs(ode-got)));report['metrics']['independent_DOP853_max_V_error']=err;check('independent_ODE_voltage',charge.success and discharge.success and err<1e-8)
    check('LED_expected_series_current',all(s['on']==(s['t']>=.16) and abs(s['current']-(.003 if s['t']>=.16 else 0))<1e-14 for s in data['led']))
    check('LED_Vf_explicit_assumption_params',data['LED']['vf']==2 and data['LED']['r']==1000 and data['LED']['vcc']==5)
    htmltext=a.html.read_text(encoding='utf-8');check('built_HTML_contains_current_source',all(p.read_text(encoding='utf-8') in htmltext for p in (ROOT/'src').glob('*.js')))
    report['browser']=await browser_checks(a.html,a.baseline,a.output)
    report['hashes_after']={p:sha(Path(p)) for p in hashes};check('inputs_stable_during_test',report['hashes_after']==hashes)
    report['passed']=all(report['checks'].values()) and all(report['browser']['checks'].values())
    report['scope']='Independent ideal RC reference plus actual production draw calls and same-browser pixel preservation. No SPICE, physical bench, encoded video or final ending validation.'
    (a.output/'validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'passed':report['passed'],'model_checks':report['checks'],'browser_checks_count':len(report['browser']['checks']),'failed_browser_checks':[k for k,v in report['browser']['checks'].items() if not v],'metrics':report['metrics'],'errors':report['browser']['errors'],'report':str(a.output/'validation.json')},ensure_ascii=False,indent=2))
    return report['passed']
if __name__=='__main__': raise SystemExit(0 if asyncio.run(main()) else 1)
