#!/usr/bin/env python3
"""Compare selected decoded presentation frames against their HTML source frames."""
from __future__ import annotations
import argparse,asyncio,base64,json,math,shutil,subprocess
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw,ImageFont
from playwright.async_api import async_playwright
FRAMES=sorted(set([48,168,1836,2706,2784,2858,2973,2974,2975,3042,4300,5028,6258,6357,6358,6359,6434,6494,6654,6911,7062,8268,8652,8760,8874,8910,8934,8952,8994,9080,9097,9322,9474,10518,12000,12073]))
FRAMES=sorted(set(FRAMES+[3305,3420,3553,4100,4107,4117,4140,4208,4320,5220,5640,6120,10560,10633]))
async def run(a):
 a.work.mkdir(parents=True,exist_ok=True)
 sel='+'.join(f'eq(n,{n})' for n in FRAMES)
 cmd=['ffmpeg','-v','error','-y','-threads','2','-i',str(a.movie),'-vf',f"select='{sel}'",'-fps_mode','vfr','-compression_level','2',str(a.work/'frame_%03d.png')]
 subprocess.run(cmd,check=True)
 html=a.html.read_text(encoding='utf-8').replace('<head>','<head><script>window.__EXPORT__=true;</script>');checks=[];contact=[]
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=a.chromium or shutil.which('chromium'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
  pg=await b.new_page(viewport={'width':1920,'height':1080});await pg.set_content(html,wait_until='load');await pg.wait_for_function('window.__filmReady');await pg.evaluate('document.fonts.ready')
  for i,n in enumerate(FRAMES,1):
   raw=await pg.evaluate('(t)=>{renderFrame(t);return document.getElementById("film").toDataURL().split(",")[1]}',n/60)
   expected=a.work/f'expected_{n}.png';expected.write_bytes(base64.b64decode(raw))
   actual=Image.open(a.work/f'frame_{i:03d}.png').convert('RGB');target=Image.open(expected).convert('RGB');x=np.asarray(actual,dtype=np.float32);y=np.asarray(target,dtype=np.float32)
   mse=float(np.mean((x-y)**2));mae=float(np.mean(np.abs(x-y)));psnr=99.0 if not mse else 10*math.log10(255**2/mse)
   checks.append({'frame':n,'time':n/60,'mae_RGB':mae,'psnr_dB':psnr,'pass':mae<4 and psnr>30})
   if i%2==1:contact.append((n/60,actual.resize((480,270),Image.Resampling.LANCZOS)))
  await b.close()
 canvas=Image.new('RGB',(480*3,300*math.ceil(len(contact)/3)),(235,229,209));draw=ImageDraw.Draw(canvas)
 for i,(t,im) in enumerate(contact):
  x=(i%3)*480;y=(i//3)*300;canvas.paste(im,(x,y));draw.text((x+12,y+278),f'{t:.3f}s',fill=(25,50,43))
 canvas.save(a.work/'encoded_review.jpg',quality=90)
 report={'passed':all(c['pass'] for c in checks),'frames':checks,'frames_checked':len(checks),'minimum_psnr_dB':min(c['psnr_dB'] for c in checks),'maximum_mae_RGB':max(c['mae_RGB'] for c in checks),'scope':'B05 selected decoded presentation frames before sidebar composition starts at frame 12074, against exact HTML time. Covers classic circuits, corrected XY trace, P2 loss, recursion, and last full-screen frame. The composed ending is reviewed separately. H.264 is lossy; numeric thresholds are explicit.'}
 a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(report,ensure_ascii=False,indent=2));return report['passed']
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('movie',type=Path);p.add_argument('--html',type=Path,required=True);p.add_argument('--work',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--chromium');a=p.parse_args();raise SystemExit(0 if asyncio.run(run(a)) else 1)
