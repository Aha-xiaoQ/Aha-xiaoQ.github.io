#!/usr/bin/env python3
"""Record actual drawing calls, not just status text, to verify circuit coupling."""
import argparse,asyncio,json,shutil
from pathlib import Path
from playwright.async_api import async_playwright
async def run(path,out):
 html=path.read_text().replace('<head>','<head><script>window.__EXPORT__=true;</script>')
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage']);pg=await b.new_page(viewport={'width':1920,'height':1080});await pg.set_content(html,wait_until='load');await pg.wait_for_function('window.__filmReady');await pg.evaluate('document.fonts.ready')
  data=await pg.evaluate('''()=>{
   const f=film,c=f.circuit,checks=[],eps=1e-7;let recorded;
   const methods=['component','trace','arrows','switch'];
   const old={};for(const k of methods){old[k]=c[k];c[k]=function(...args){recorded[k].push(args);return old[k].apply(this,args)}}
   const oldText=f.g.text;f.g.text=function(...args){recorded.text.push(args);return oldText.apply(this,args)};
   function shot(t){recorded={component:[],trace:[],arrows:[],switch:[],text:[]};let state=renderFrame(t);return {calls:recorded,state};}
   const eq=(a,b)=>Math.hypot(a[0]-b[0],a[1]-b[1])<eps,check=(name,pass)=>checks.push({name,pass});
   for(const t of [44.52,44.65,45.15,45.75,46.08,46.30,46.52,46.90,47.32]){
    let {calls:a,state:s}=shot(t),r=s.rectifier,d=a.component.filter(x=>x[2]==='diode'),ds=CircuitModel.bridge.diodes,N=CircuitModel.bridge.nodes;
    check('diode direction / highlight @ '+t,d.length===4&&d.every((x,i)=>eq(x[0],N[ds[i].a])&&eq(x[1],N[ds[i].k])&&x[4]===r.pair.includes(ds[i].id)));
    check('scope endpoints @ '+t,eq(a.trace[0][0].at(-1),[550,457-r.vin*13.9])&&eq(a.trace[1][0].at(-1),[1764,596-r.vload*34.75]));
    check('filter switch @ '+t,a.switch[0][2]===(r.connected?1:0));
    if(!r.pair.length)check('source not in discharge arrow loop @ '+t,a.arrows.every(x=>x[0].every(p=>!eq(p,N.A)&&!eq(p,N.B))));
   }
   for(const t of [48,49.56,49.57,50.4]){
    const {calls:a,state:s}=shot(t),h=s.sampleHold;
    check('hold switch + drawn input/output @ '+t,a.switch[0][2]===(h.closed?1:0)&&eq(a.trace[0][0].at(-1),[1670,805-h.vin*20])&&eq(a.trace[1][0].at(-1),[1670,805-h.vc*20]));
   }
   for(const t of [103.5,105.3,107.5,109.8]){
    const {calls:a,state:s}=shot(t),h=s.xy;
    check('XY + side scope endpoint identity @ '+t,eq(a.trace[0][0].at(-1),[960+h.x*96,490-h.y*96])&&eq(a.trace[1][0].at(-1),[485,505-h.x*27])&&eq(a.trace[2][0].at(-1),[1730,505-h.y*27]));
   }
   for(const t of [111.1,111.7,113.82,117.7]){
    const {calls:a,state:s}=shot(t),h=s.bus,x=301+1318*h.units/CircuitModel.I2C.end;
    check('SCL/SDA drawn analog endpoints @ '+t,eq(a.trace[0][0].at(-1),[x,687-h.scl/3.3*35])&&eq(a.trace[1][0].at(-1),[x,762-h.sda/3.3*35]));
   }
   for(const t of [147.7,148.65,150.5,152.3,156.2,158.2]){
    const {calls:a,state:s}=shot(t);const nums=a.text.filter(x=>['0','1'].includes(x[0])).sort((a,b)=>a[1]-b[1]);
    check('all six DFF rendered values @ '+t,nums.length===6&&nums.every((x,i)=>Number(x[0])===s.counter.q[i]));
   }
   for(const t of [.159,.16,.25]){let {calls:a}=shot(t);check('power switch closes by rail-on @ '+t,t<.16?a.switch[0][2]<1:a.switch[0][2]===1);}
   for(const k of methods)c[k]=old[k];f.g.text=oldText;
   return {passed:checks.every(c=>c.pass),checks,checks_count:checks.length,scope:'Production drawing calls captured from actual Film/CircuitInk; no alternate renderer.'};
  }''')
  await b.close()
 out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(data,ensure_ascii=False,indent=2));print(json.dumps(data,ensure_ascii=False,indent=2));return data['passed']
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('html',type=Path);p.add_argument('--output',type=Path,required=True);a=p.parse_args();raise SystemExit(0 if asyncio.run(run(a.html,a.output)) else 1)
