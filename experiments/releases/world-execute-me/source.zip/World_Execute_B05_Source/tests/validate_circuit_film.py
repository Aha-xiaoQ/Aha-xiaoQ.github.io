#!/usr/bin/env python3
"""Check the actual B04 HTML's circuit-to-picture coupling and inspection UI."""
from __future__ import annotations
import argparse,asyncio,base64,hashlib,json,shutil
from pathlib import Path
from playwright.async_api import async_playwright

async def run(html_path:Path,output:Path):
 html=html_path.read_text(encoding='utf-8'); report={'edition':'B04','checks':{},'errors':[],'network':[]}
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
  pg=await b.new_page(viewport={'width':1440,'height':1080});pg.on('pageerror',lambda e:report['errors'].append(str(e)))
  pg.on('request',lambda r:report['network'].append(r.url) if r.url.startswith(('http:','https:')) else None)
  await pg.set_content(html,wait_until='load');await pg.wait_for_function('window.__filmReady===true');await pg.evaluate('document.fonts.ready')
  await pg.evaluate('setFilmTime(46.4)');await pg.click('#inspect')
  cases={'power':('power',.0032),'rectifier':('rectifier',0),'hold':('sampleHold',0),'xy':('xy',0),'bus':('bus',0),'clock':('counter',0)}
  for kind,(key,_) in cases.items():
   await pg.click(f'[data-kind="{kind}"]')
   low=await pg.evaluate("()=>{let x=document.getElementById('labslider');x.value='50';x.dispatchEvent(new Event('input',{bubbles:true}));return film.lastStats}")
   high=await pg.evaluate("()=>{let x=document.getElementById('labslider');x.value='950';x.dispatchEvent(new Event('input',{bubbles:true}));return film.lastStats}")
   ok=await pg.evaluate("!document.getElementById('labtime').hidden && document.getElementById('music').paused")
   report['checks'][f'inspector_{kind}_uses_live_model']=ok and key in low and key in high and low[key]!=high[key]
  await pg.screenshot(path=str(output.parent/'circuit_inspector.png'))
  await pg.click('#return');report['checks']['return_preserves_MV_time']=await pg.evaluate('Math.abs(document.getElementById("music").currentTime-46.4)<.01 && film.lastStats.shot==="current"')
  # Source-time sweep includes every current frame at 60 fps, every bit/clock,
  # transition boundaries and the held-memory interval.
  data=await pg.evaluate('''()=>{let bad=[],counts={};let ts=[];
   for(const [a,b] of [[0,3.9],[44.4,51.4],[103.48,118.32],[147.65,158.9]])for(let t=a+.0001;t<b-.0001;t+=1/60)ts.push(t);
   for(const t of ts){const st=renderFrame(t,{captions:2}),M=CircuitModel;counts[st.shot]=(counts[st.shot]||0)+1;
    if(st.rectifier){let r=st.rectifier,te=(t-44.4)/50,e=film.rectifier.at(te);if(Math.abs(r.vc-e.vc)>1e-10||r.pair.join()!=e.pair.join())bad.push({t,reason:'bridge'});}
    if(st.xy&&Math.hypot(st.xy.tip[0]-st.xy.expectedTip[0],st.xy.tip[1]-st.xy.expectedTip[1])>1e-7)bad.push({t,reason:'xy'});
    if(st.sampleHold&&Math.abs(st.sampleHold.vc-M.trackHold(t).vc)>1e-10)bad.push({t,reason:'hold'});
    if(st.counter&&st.counter.q.join()!=M.counter(t).q.join())bad.push({t,reason:'clock'});
    if(st.bus&&st.bus.ackSample&&st.bus.units<10&&st.bus.sda<.7*3.3)bad.push({t,reason:'nack'});
   }return {frames:ts.length,counts,bad};}''')
  report['sweep']=data;report['checks']['picture_state_matches_circuit_state']=not data['bad']
  # Random seeks must not re-initialize or alter simulated capacitor charge.
  times=[46.47,50.22,106.71,113.72,152.82,46.47,50.22,106.71,113.72,152.82]
  hashes=[]
  for t in times:
   encoded=await pg.evaluate('(t)=>{renderFrame(t);return document.getElementById("film").toDataURL().split(",")[1]}',t)
   hashes.append(hashlib.sha256(base64.b64decode(encoded)).hexdigest())
  report['checks']['random_seek_determinism_all_circuit_types']=hashes[:5]==hashes[5:]
  # Reset, calibration notes and circuit labels must stay above the subtitle area.
  labels=await pg.evaluate('''()=>{const f=film,original=f.label,issues=[];let current=0,count=0;
   f.label=function(str,x,y,size,col,opt={}){count++;if(size>=13&&y<900&&(!Number.isFinite(x)||!Number.isFinite(y)||x<50||x>1870||y+size/2>894))issues.push({current,str,x,y,size});return original.call(this,str,x,y,size,col,opt)};
   for(const t of [2.8,46.3,49.2,50.6,104.4,108.6,113.82,148.8,152.8,157.2]){current=t;renderFrame(t)}f.label=original;return {labels:count,issues};}''')
  report['labels']=labels;report['checks']['label_baselines_keep_caption_safe_area']=not labels['issues']
  mobile=await b.new_page(viewport={'width':390,'height':844});await mobile.set_content(html,wait_until='load');await mobile.wait_for_function('window.__filmReady===true')
  await mobile.click('#inspect');await mobile.click('[data-kind="rectifier"]');await mobile.screenshot(path=str(output.parent/'circuit_inspector_mobile.png'))
  report['checks']['mobile_inspector_no_horizontal_overflow']=await mobile.evaluate('document.documentElement.scrollWidth<=innerWidth')
  await b.close()
 report['passed']=all(report['checks'].values()) and not report['errors'] and not report['network'];output.parent.mkdir(parents=True,exist_ok=True);output.write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False,indent=2));return report['passed']
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('html',type=Path);p.add_argument('--output',type=Path,required=True);a=p.parse_args();a.output.parent.mkdir(parents=True,exist_ok=True);raise SystemExit(0 if asyncio.run(run(a.html,a.output)) else 1)
