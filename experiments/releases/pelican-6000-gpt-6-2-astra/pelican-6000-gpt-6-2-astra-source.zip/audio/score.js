/* A brass bell and two wheels — original motion-picture score, R8.
 * All notes use the final picture clock. No sound recordings are loaded.
 * The same synthesis and event list drive playback, seeking, and export.
 */
(function(root){
  'use strict';
  const TAU=Math.PI*2, DURATION=186, BPM=120, SAMPLE_RATE=48000, MASTER_GAIN=1.82;
  const clamp=(x,a=0,b=1)=>Math.max(a,Math.min(b,x));
  const hz=n=>440*Math.pow(2,(n-69)/12);
  const events=[], cues=[], waveCache=new Map(), contextBuffers=new WeakMap();
  let tape=null, preparing=null;
  const chapterNames=['岩鼓与低吟','双手竖琴','石磬与编钟','拨弦轮指','山谷泛音','桥头吹打','陶笛与木鼓','拨弦与塔布拉','独箫','影幕铜锣','雨中的三味线','夜行圆舞曲','减五度回声','默片追影','电子对位','四轨芯片乐','两端的通话','磁带慢摇','切分放克','钢琴赋格'];
  const sceneStarts=[6,11,17,22,29,36,46,51,58,63,70,76,84,90,96,104,113,145,151,160];
  const sceneLengths=sceneStarts.map((s,i)=>(sceneStarts[i+1]??170)-s);
  const chatTimes=[116.5,119.5,123.8,128,131.8,135,138];
  root.PelicanScoreTimeline={starts:sceneStarts,lengths:sceneLengths,intro:6,outro:16,duration:DURATION,chatMessageTimes:chatTimes};

  function event(time,kind,n,dur,amp=.1,pan=0,extra={}){
    if(time>=DURATION)return;
    events.push({time,kind,n,dur:Math.min(dur,DURATION-time),amp,pan,...extra});
  }
  function line(at,kind,notes,gain=.18,pan=-.12,pace=1,transpose=0){
    notes.forEach(([beat,note,length,accent=1])=>
      event(at+beat*pace,kind,note+transpose,length*pace,gain*accent,pan));
  }
  function chord(at,kind,notes,dur,gain,spread=.5){
    notes.forEach((n,i)=>event(at+.009*i,kind,n,dur,gain,
      notes.length===1?0:spread*(2*i/(notes.length-1)-1)));
  }
  function mark(at,name,kind,n,dur,amp,pan=0){
    cues.push({time:at,name});
    if(kind)event(at,kind,n,dur,amp,pan,{space:'close'});
  }
  // Two short upbeats (D E), arrival on G, half a breath, leap to B.
  // B is withheld several times. The answer E–D is the vehicle's bell figure.
  const theme=[[0,62,.18,.76],[.25,64,.19,.86],[.5,67,.83,1],[1.65,71,.52,1.02],
    [2.25,69,.30,.86],[2.75,64,.48,.91],[3.5,62,.72,.88]];
  const head=theme.slice(0,4),answer=theme.slice(4);

  // Copperplate prelude. Viola, bass clarinet and fingerboard speak in turns.
  chord(0,'viola',[43,50,59],2.60,.085,.50);
  line(.22,'reed',head,.25,-.11,.97,-12);
  mark(2.4,'intro_second_line','upright',43,.46,.29,-.08);
  line(2.84,'wire',[[0,76,.46],[.53,74,.81],[1.43,71,.35],[1.78,69,.25],[2.12,67,.62]],.165,.28);
  event(5.34,'skin',43,.42,.21,-.22);event(5.76,'skin',55,.21,.13,.32);

  // 1 · Painted herd. A five-beat procession alternates heel and palm.
  line(6.11,'chant',[[0,50,.46],[.63,52,.27],[1.03,55,.94],[2.53,59,.42],[3.03,57,.35],[3.66,52,.68]],.21,-.12);
  for(const [u,n,a] of [[0,40,.25],[.76,52,.14],[1.25,40,.20],[2.01,55,.11],[2.51,42,.24],[3.25,51,.14],[4.01,45,.17]]){
    event(6+u,'skin',n,.44,a,n<46?-.18:.34);
  }
  mark(8.083,'herd_make_way','rim',62,.10,.085,.35);
  line(9.81,'reed',[[0,55,.38],[.53,57,.60]],.11,.38);

  // 2 · Papyrus; two hands play around a held silhouette, then a descending gliss.
  line(11.04,'harp',[[0,50,1.3],[.24,57,.85],[.53,62,.83],[1,64,.65],[1.24,67,1.18],
    [2.88,71,.89],[3.75,69,.75],[4.23,64,.78],[5.03,62,.92]],.215,-.12);
  for(const [u,n] of [[0,38],[1.51,45],[3,43],[4.51,38]])event(11+u,'wire',n,1.27,.13,.34);
  mark(13.18,'wall_pigment_contact','brush',0,.22,.08,-.32);
  mark(14.66,'wall_living_exit','softMallet',79,.66,.075,.32);
  [79,76,74,71,67].forEach((n,i)=>event(16.34+.084*i,'harp',n,.62,.115-i*.008,.4-i*.15));

  // 3 · A chord is uncovered in two materials: laid-on paper, stone underneath.
  line(17.06,'bronze',[[0,55,1.35],[.64,62,1],[1.12,67,1.23],[3.32,64,1],[4.12,62,.83]],.19,-.27);
  event(17.15,'lowGong',43,2.12,.115,.28);
  mark(19.22,'paper_lifts','brush',0,.34,.115,-.35);
  mark(19.53,'stone_exposed','woodLow',50,.22,.17,-.23);
  event(19.73,'vibes',71,1.14,.20,.26);
  mark(19+11/12,'anonymous_stamp','wood',54,.13,.094,.17);

  // 4 · One hand plucks a long-short-long figure; the other catches the ribbon.
  line(22.03,'pipa',[[0,62,.38],[.23,64,.29],[.52,67,.88],[1.43,74,.55],[2.14,71,.43],
    [2.68,69,.37],[3.03,67,.57],[3.9,62,.59],[4.54,64,.48],[5.04,69,.83],[6.13,67,.72]],.23,-.18);
  line(22.24,'wire',[[0,43,.82],[1.48,50,.88],[3,47,.72],[4.49,50,.73],[5.97,43,.59]],.135,.29);
  [0,.093,.182,.268,.358,.451].forEach((u,i)=>event(25.11+u,'pipa',i===5?71:69,.37,.12+i*.013,.18));
  mark(25.21,'ribbon_gives_way','shaker',0,.16,.043,.30);

  // 5 · Qin left alone at the edge of the sound stage. The high answer arrives late.
  event(29.09,'guqin',43,2.78,.26,-.23);
  line(29.68,'qinSlide',[[0,50,1.69],[2.19,52,1],[3.47,55,1.24]],.19,-.15);
  event(31.34,'airyHarm',74,1.03,.085,.53);
  event(33.92,'bamboo',71,1.32,.16,.33);event(35.37,'guqin',50,.66,.16,-.19);

  // 6 · Crossing the bridge. The flautist leaves a full bar for the leaping fish.
  line(36.03,'bamboo',[[0,74,.23],[.27,76,.22],[.50,79,.52],[1.3,83,.42],[1.76,81,.3],
    [2.08,79,.44],[2.68,76,.27],[3.03,74,.4],[3.48,71,.31]],.215,-.13);
  for(const [u,n] of [[0,43],[.72,50],[1.51,43],[2.25,55],[3,47],[6.65,50],[7.5,43],[8.25,50],[9,43]])event(36+u,'skin',n,.34,.15,-.25);
  const fishUp=36+2.32*10/6, fishDown=36+3.62*10/6;
  mark(fishUp,'fish_leaves_river','splash',0,.27,.105,-.31);
  line(fishUp+.1,'wire',[[0,67,.35],[.21,71,.32],[.42,74,.38],[.68,79,.52]],.134,-.06);
  mark(fishDown,'fish_lands_beyond_bridge','splash',0,.49,.12,.35);
  mark(42.60,'fish_right_of_way','bell',0,.53,.09,.24);
  line(42.86,'bamboo',[[0,83,.46],[.55,81,.28],[.9,76,.48],[1.55,74,.35],[2.06,71,.76]],.20,.08);

  // 7 · The pedal counter articulates a 3+3+2 wood pattern.
  line(46.09,'ocarina',[[0,62,.33],[.38,64,.28],[.75,67,.60],[1.63,71,.68],[2.57,69,.37],[3.02,64,.39],[3.74,62,.77]],.20,-.1);
  for(let i=0;i<2;i++)for(const [u,n] of [[0,48],[.75,55],[1.5,60]])event(46+i*2+u,'woodLow',n,.27,.14,i?.28:-.24);
  mark(48.597,'maya_fifth_dot','softMallet',79,.49,.14,.36);

  // 8 · Court: drone and a single decorated line; tabla arrive as the fans open.
  chord(51,'tanpura',[43,50,55],5.9,.095,.62);
  line(51.22,'sitar',[[0,62,.67],[.82,64,.41],[1.36,67,.88],[2.28,69,.28],[2.61,70,.19],
    [2.84,71,.81],[3.84,69,.54],[4.52,64,.55],[5.28,62,1.24]],.225,-.18);
  for(const [u,n] of [[.06,43],[1,62],[1.71,65],[2.75,43],[3.49,63],[3.73,67],[4.48,43],[5.22,63],[6.0,57],[6.24,63]]){
    event(51+u,n<50?'tablaLow':'tabla',n,.32,n<50?.19:.105,.23);
  }
  mark(54.85,'garden_fountain_answer','droplet',83,.30,.072,.42);

  // 9 · Silence is the joke. Leave a gap on either side of the unused bell.
  event(58.08,'xiao',64,1.28,.215,-.19);
  event(59.71,'xiao',62,.95,.16,-.10);event(61.56,'guqin',43,1.30,.165,.24);

  // 10 · Bronze hocket between the two hands of the puppeteer.
  const hocket=[55,62,67,64,71,69,64,62,55,62,67,74,71,69,67,62];
  hocket.forEach((n,i)=>event(63.09+i*.40,i%2?'gamelan':'vibes',n,i%4===0?.96:.72,
    i%4===0?.21:.165,i%2?.38:-.38));
  [0,2.4,4.8].forEach((u,i)=>event(63+u,'gong',[43,40,43][i],1.59,.15,0));
  mark(65+1/3,'wayang_rod_lift','woodLow',51,.21,.12,-.35);
  mark(66+13/75,'wayang_gate_open','wood',60,.16,.09,.33);
  mark(69.125,'wayang_rod_close','woodLow',53,.24,.10,.12);

  // 11 · The rain arrives off the beat. Dry plectrum and muted answers.
  line(70.12,'shamisen',[[0,62,.61],[.76,63,.30],[1.12,67,.82],[2.25,70,.46],
    [2.78,69,.35],[3.34,63,.47],[4.12,62,.77],[5.2,55,.64]],.247,-.18);
  line(70.19,'wire',[[0,43,.86],[1.48,50,.84],[3.03,46,.78],[4.52,43,.81]],.14,.31);
  event(70.90,'rain',0,3.56,.013,.46);
  mark(73.15,'traveller_catches_hat','brush',0,.18,.073,.24);

  // 12 · Waltz in 3/4, four bars. Sway in the bass; new high-register B section.
  const waltz=[[43,55,59,62],[40,55,59,64],[48,55,64,71],[38,54,62,69],[43,55,59,62]];
  for(let i=0;i<5;i++){
    const at=76+i*1.5, ns=waltz[i];
    event(at,'upright',ns[0],.78,.245,-.15);
    chord(at+.50,'viola',ns.slice(1),.58,.075,.62);
    chord(at+1,'wire',ns.slice(1),.52,.071,.46);
  }
  line(76.13,'lyric',[[0,71,.81],[.97,74,.43],[1.5,78,.97],[2.61,79,.31],[3.03,83,.82],
    [3.97,81,.40],[4.5,79,.87],[5.49,76,.51],[6.10,74,.66],[6.96,71,.88]],.213,-.17);
  mark(78.23,'star_takes_a_ride','vibes',86,.80,.15,-.40);
  mark(81.147,'star_reaches_clock','celesta',90,.91,.19,.22);
  event(81.60,'vibes',83,1.18,.11,.47);

  // 13 · The bridge buckles; a tritone interrupts an otherwise familiar answer.
  line(84.1,'viola',[[0,55,.94],[1.04,59,.63],[1.85,61,.34],[4.03,57,.53],[4.76,55,.78]],.24,-.15);
  chord(84,'viola',[40,47,54],1.85,.095,.76);
  mark(86.22,'scream_space_wave','bowSweep',66,1.11,.225,-.28);
  event(86.37,'bowSweep',72,1.10,.16,.29);
  mark(87.32,'pelican_soft_answer','reed',57,.72,.204,.16);
  event(88.70,'felt',50,.95,.175,-.08);

  // 14–15 · A minor, crooked stride turns into the identical long electrical pitch.
  for(let i=0;i<5;i++){
    event(90+i*.75,'piano',[40,47,44,45,43][i],.40,.24,-.23);
    chord(90.38+i*.75,'piano',[[55,59],[54,60],[55,59],[57,60],[55,59]][i],.28,.119,.35);
  }
  line(90.08,'reed',[[0,59,.32],[.36,62,.35],[.83,65,.55],[1.56,64,.61],[2.43,60,.43],[3.19,59,.64]],.19,.13);
  event(93.57,'organ',55,1.75,.14,-.25);
  mark(94.16,'shadow_bill_glows','glass',67,1.92,.18,-.10);
  event(95.55,'glass',62,1.30,.16,.18);
  mark(96,'shadow_electrifies');
  line(96.10,'glass',[[0,67,.65],[.88,71,.48],[1.49,69,.67]],.185,-.23);
  event(96.13,'tube',0,7.24,.025,0);
  mark(98.867,'scope_lissajous','scopeWarp',0,1.55,.17,.05);
  mark(100.80,'scope_calibrated','switch',0,.10,.105,-.18);
  line(100.94,'glass',[[0,69,.54],[.71,64,.59],[1.50,62,.88]],.18,.24);

  // 16 · Four monophonic lanes; the coin borrows the countervoice's lane.
  const lanes=['chipA','chipB','chipC','chipD'];
  function chip(u,lane,kind,n,dur,amp,pan=0){event(104+u,kind,n,dur,amp,pan,{channel:lanes[lane]});}
  for(const [u,n,d] of [[0,74,.18],[.25,76,.18],[.50,79,.55],[1.25,83,.31],[1.75,81,.19],
    [2,76,.32],[2.5,74,.37],[3,71,.3],[3.5,74,.33],[4,79,.72],[5,81,.4],
    [5.75,83,.37],[6.25,86,.52],[7,83,.29],[7.5,79,.30],[8,74,.66]])chip(u,0,'chipLead',n,d,.126,-.1);
  for(let i=0;i<36;i++){
    const u=i*.25, ch=Math.floor(u/2)%4, notes=[[55,59,62],[55,59,64],[55,60,64],[54,57,62]][ch];
    if(u<4.4||u>5.7)chip(u,1,'chipArp',notes[i%3],.16,.074,.22);
    if(i%2===0)chip(u,2,'chipBass',[43,40,48,38][ch]+(i%4===2?7:0),.32,.185);
    chip(u,3,'chipNoise',0,i%4===2?.12:.047,i%4===2?.070:.019,-.2);
  }
  mark(108.575,'bill_hits_question_block');chip(4.575,1,'chipJump',0,.30,.12,.22);
  mark(109.22,'coin_on_bell');
  [83,90,95].forEach((n,i)=>chip(5.22+i*.10,1,'chipArp',n,.105,.115,.23));
  mark(110.75,'pixel_landing');chip(6.75,3,'chipNoise',0,.15,.101,-.17);

  // 17 · Eight measures ask, eight answer. The joke can be read during the rests.
  const chatChords=[
    [43,55,59,62],[47,54,59,62],[40,55,59,64],[38,54,57,62],
    [48,55,59,64],[45,55,60,64],[38,54,57,64],[38,54,57,62],
    [43,54,59,62],[42,54,57,62],[40,55,59,62],[47,55,59,62],
    [48,55,59,64],[45,52,55,60],[38,54,57,64],[43,55,59,62]];
  chatChords.forEach((ns,i)=>{
    const at=113+2*i, rootNote=ns[0], upper=ns.slice(1);
    event(at,'upright',rootNote,i%4===3?1.1:.75,.205,-.12);
    if(i%4!==3)event(at+1.30,'upright',rootNote+7,.40,.125,-.07);
    chord(at+(i%2?.67:.34),'electric',upper,i%4===3?1.0:.72,.079,.5);
    if(i%4!==3)chord(at+1.62,'wire',upper.slice(0,2),.35,.052,.38);
    if(i<6||i>10)event(at+1,'brush',0,.19,.046,.25);
    if(i>7&&i<14)event(at+.66,'shaker',0,.075,.035,-.36);
  });
  line(113.32,'reed',head,.174,-.26,.91);
  line(118.05,'vibes',[[0,71,.63],[.78,69,.42],[1.37,64,.68]],.14,.37);
  line(121.20,'felt',[[0,67,.53],[.74,69,.42],[1.37,71,.91]],.149,-.14);
  line(125.42,'reed',[[0,67,.59],[.72,64,.48],[1.38,62,.80]],.149,-.26);
  line(128.72,'wire',head,.17,.25,.75,12);
  line(133.67,'reed',answer,.157,-.21,.81);
  line(137.18,'vibes',[[0,76,.58],[.67,74,.41],[1.22,71,.67]],.15,.28);
  line(139.94,'reed',[[0,62,.21],[.26,64,.19],[.51,67,.71],[1.52,71,.53],[2.32,69,.36],[2.81,67,.89]],.174,-.17);
  const senders=['fish_rice','gpt_qualification','doubao_long_intro','claude_opens_file','doubao_answer','fish_two_bowls','gpt_verified'];
  chatTimes.forEach((t,i)=>mark(t,'chat_'+senders[i],'message',[83,76,79,86,79,83,76][i],.23,.116,[.35,-.34,.13][i%3]));

  // 18 · Original FM trio is performed fast/high and replayed by the tape transport below.
  [147,147.25,147.5,147.75].forEach((t,i)=>mark(t,'tape_half_beat_'+i));
  // 19 · Offbeat keys, a syncopated bass and a displaced version of the theme.
  const funk=[[43,55,59,62,66],[40,55,59,64,66],[48,55,59,62,64],[38,54,57,60,64]];
  funk.forEach((ns,i)=>{
    const at=151+2*i;
    for(const [u,k] of [[0,0],[.76,7],[1.38,12],[1.76,7]])event(at+u,'fmBass',ns[0]+k,.30,.237*(u===0?1:.76),0);
    for(const u of [.26,1.02,1.64])chord(at+u,'electric',ns.slice(1),.28,.092,.57);
    for(const u of [0,.8,1.25])event(at+u,'kick',0,.28,.24);
    for(const u of [.50,1.5])event(at+u,'clap',0,.14,.10,.16);
    for(let k=0;k<8;k++)event(at+k*.25+.003,'hat',0,k%2?.082:.048,k%2?.043:.023,.40);
  });
  line(151.36,'fmSax',head,.195,-.20,.82,12);
  line(155.70,'vibes',[[0,83,.4],[.47,81,.37],[1.03,76,.48],[1.73,74,.73]],.163,.24);
  mark(155.98,'rice_delivery_arrived','message',91,.29,.107,.36);
  line(158.82,'fmSax',[[0,74,.22],[.28,76,.23],[.55,79,.55]],.154,-.22);

  // 20 · A two-part invention built from the anacrusis. One voice yields at the breakpoint.
  line(160.05,'felt',theme,.23,-.25,.84,12);
  line(160.91,'wire',head,.16,.31,.86,0);
  line(163.20,'felt',[[0,71,.24],[.29,74,.21],[.56,78,.60],[1.30,76,.52]],.197,-.23);
  chord(160,'viola',[43,50,59],2.0,.066,.51);
  chord(162.12,'viola',[40,55,62],2.26,.064,.47);
  mark(165+1/6,'code_breakpoint','key',0,.06,.096,-.24);
  mark(166.08,'road_choice_committed','key',0,.06,.10,.25);
  line(166.24,'felt',[[0,74,.29],[.35,76,.30],[.75,79,.58],[1.45,83,.51],[2.06,81,.36],[2.53,76,.50],[3.09,74,.57]],.21,-.15);
  line(166.62,'wire',[[0,50,.35],[.44,52,.33],[.85,55,.79],[1.82,59,.57],[2.50,57,.58]],.134,.32);

  // Coda: the melody gets its longest breath, then the photographer takes the rest.
  chord(170.02,'viola',[43,50,59,66],2.45,.092,.7);
  chord(172.55,'viola',[40,55,59,64],2.10,.082,.63);
  chord(175.03,'viola',[48,55,59,64],1.76,.070,.57);
  line(170.21,'lyric',theme,.21,-.18,1.22,12);
  line(171.58,'wire',head,.17,.29,1.09,0);
  line(175.47,'reed',[[0,71,.72],[.90,69,.52],[1.61,64,.86],[2.76,62,.77]],.175,-.14);
  mark(176.95,'press_flash_1','shutter',0,.13,.114,-.40);
  mark(177.65,'press_flash_2','shutter',0,.13,.106,.43);
  event(179.08,'felt',43,1.24,.13,-.10);
  mark(180.65,'press_borrow_bell_0','bell',0,.85,.195,.04);
  mark(180.92,'press_borrow_bell_1','bell',0,1.17,.14,.20);
  chord(182.44,'felt',[43,50,59,64],1.60,.058,.48);
  event(183.18,'vibes',67,1.15,.097,.20);
  mark(184.70,'rider_leaves_photograph','bell',0,1.20,.078,.58);
  events.sort((a,b)=>a.time-b.time);
  for(const lane of lanes){
    const part=events.filter(e=>e.channel===lane);
    part.forEach((e,i)=>{if(part[i+1])e.dur=Math.min(e.dur,Math.max(.012,part[i+1].time-e.time-.003));});
  }
  cues.sort((a,b)=>a.time-b.time);

  // The chamber band has three acoustic bodies. String stops and reed formants
  // stay in absolute frequency while a player's finger or tongue moves the note.
  const chamberKinds=new Set(['reed','upright','wire','viola','lyric','vibes','qinSlide','skin','glass']);
  function chamberWave(kind,n,dur,sr){
    const f=hz(n), out=new Float32Array(Math.max(8,Math.ceil(dur*sr)));
    const bowed=kind==='viola'||kind==='lyric', reeds=kind==='reed';
    const formant=(freq,centre,width)=>Math.exp(-.5*Math.pow(Math.log2(freq/centre)/width,2));
    const partials=[];
    if(bowed||reeds){
      for(let h=1;h<=11&&h*f<sr*.42;h++){
        const fq=h*f;
        const colour=reeds?((h%2?.90:.16)+.74*formant(fq,710,.51)+.29*formant(fq,1310,.35)):
          .52+.66*formant(fq,520,.38)+.70*formant(fq,1210,.47)+(kind==='lyric'?.31:.15)*formant(fq,2340,.34);
        partials.push(colour/Math.pow(h,reeds?1.18:1.30));
      }
    }
    let seed=((n*251+kind.charCodeAt(0)*413)|0)>>>0, low=0, slow=0,phase=0;
    for(let i=0;i<out.length;i++){
      const t=i/sr, left=dur-t, p=TAU*f*t;
      seed=(Math.imul(seed,1664525)+1013904223)>>>0;
      const noise=seed/2147483648-1;
      low+=.18*(noise-low);slow+=.034*(noise-slow);
      let x=0,attack=.004,release=.09;
      if(bowed||reeds){
        const ramp=clamp((t-.07)/.24), vib=kind==='lyric'?.0048:bowed?.0027:.0014;
        phase+=TAU*f/sr*(1+vib*ramp*Math.sin(TAU*(5.12+.08*t)*t)
          -(reeds?.006:.003)*Math.exp(-t*22)+.0007*Math.sin(t*11));
        for(let k=0;k<partials.length;k++)x+=partials[k]*Math.sin((k+1)*phase+.016*k*Math.sin(t*8));
        if(bowed)x+=.30*Math.sin(1.0012*phase+.035*Math.sin(31*t))+.10*Math.sin(2.0035*phase);
        x=(x*(reeds?.64:.54)+(low-slow)*(reeds?.056:.095)*(.45+Math.exp(-t*18)))
          *(.83+.16*Math.sin(Math.PI*clamp(t/dur))+.025*Math.sin(t*9));
        attack=Math.min(dur*.21,reeds?.032:kind==='lyric'?.078:.11);
        release=Math.min(dur*.33,reeds?.08:.16);
      }else if(kind==='upright'){
        const bend=.010*(1-Math.exp(-t*35))/35;
        const q=TAU*f*(t+bend);
        x=.70*Math.sin(q)*Math.exp(-t*3.1)+.30*Math.sin(2.002*q+.3)*Math.exp(-t*5.4)+
          .17*Math.sin(3.007*q+.65)*Math.exp(-t*8.1)+.10*Math.sin(5.016*q)*Math.exp(-t*12.2)+
          .09*(low-slow)*Math.exp(-t*49);
        attack=.007;release=.10;
      }else if(kind==='wire'){
        x=.62*Math.sin(p)*Math.exp(-t*2.2)+.30*Math.sin(1.0015*p)*Math.exp(-t*2.7)+
          .24*Math.sin(1.9991*p+.12)*Math.exp(-t*5.2)+.17*Math.sin(3.0035*p)*Math.exp(-t*5.8)+
          .082*Math.sin(5.009*p+.16)*Math.exp(-t*9.8)+.047*(noise-low)*Math.exp(-t*110);
      }else if(kind==='vibes'){
        x=(.73*Math.sin(p)*Math.exp(-t*1.45)+.27*Math.sin(p*3.984)*Math.exp(-t*4.4)+
          .08*Math.sin(p*10.07)*Math.exp(-t*12))*(.91+.09*Math.cos(t*TAU*4.1));
        attack=.005;release=.13;
      }else if(kind==='qinSlide'){
        const glide=.028*Math.exp(-t*7)-.007*Math.exp(-((t-.49)**2)/.017);
        phase+=TAU*f*(1+glide)/sr;
        x=(Math.sin(phase)*.67+Math.sin(2.001*phase)*.24*Math.exp(-t*1.5)+
          Math.sin(3.003*phase)*.16*Math.exp(-t*2.7))*Math.exp(-t*1.7)+
          .058*(low-slow)*Math.exp(-t*37);
        attack=.009;release=.18;
      }else if(kind==='skin'){
        phase+=TAU*f*(1+.22*Math.exp(-t*24))/sr;
        x=.76*Math.sin(phase)*Math.exp(-t*10)+.26*Math.sin(1.59*phase)*Math.exp(-t*17)+
          .13*Math.sin(2.13*phase)*Math.exp(-t*23)+.34*(low-slow)*Math.exp(-t*49);
        attack=.002;release=.035;
      }else{
        x=(Math.sin(p)+.18*Math.sin(2*p+.44*Math.sin(p)*Math.exp(-t*3.8)))*.77;
        attack=.036;release=.12;
      }
      out[i]=x*clamp(t/attack)*clamp(left/release);
    }
    return out;
  }

  // Fractional-delay plucked strings: pick position, bridge losses, body color.
  function stringWave(kind,n,dur,sr){
    const f=hz(n),len=Math.ceil(dur*sr),a=new Float32Array(len),delay=sr/f-.18,N=Math.ceil(delay)+3,ring=new Float64Array(N);
    let seed=(n*7283+kind.length*1889)>>>0;const rand=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/2147483648-1;};
    const bright=['pipa','shamisen','sitar'].includes(kind),t60=kind==='guqin'?2.7:kind==='harp'?2.4:kind==='tanpura'?5.5:kind==='sitar'?2.3:1.25;
    const loss=Math.exp(-3.2/(t60*f)),blend=bright?.12:.24;
    for(let i=0;i<N;i++)ring[i]=rand()*.7;let dc=0,peak=0;
    for(let i=0;i<len;i++){
      let rp=(i-delay)%N;if(rp<0)rp+=N;const k=Math.floor(rp),u=rp-k,v=ring[k]*(1-u)+ring[(k+1)%N]*u,prev=ring[(k+N-1)%N];
      let feedback=(v*(1-blend)+prev*blend)*loss;ring[i%N]=feedback;
      const t=i/sr,phase=TAU*f*t;
      let x=v*.78+.24*Math.sin(phase)*Math.exp(-t*(kind==='tanpura'?.6:1.6));
      if(kind==='guqin')x+=.10*Math.sin(phase*2.002+.018*Math.sin(t*21))*Math.exp(-t*1.9);
      if(kind==='sitar'||kind==='tanpura')x+=.13*Math.tanh(v*3)*Math.sin(phase*2.003)*Math.exp(-t*1.6);
      if(kind==='shamisen')x+=.05*rand()*Math.exp(-t*95);
      dc+=.002*(x-dc);x=(x-dc)*Math.min(1,t/.003)*Math.min(1,(dur-t)/.085);a[i]=x;peak=Math.max(peak,Math.abs(x));
    }
    const gain=Math.min(1.3,.85/Math.max(.2,peak));for(let i=0;i<len;i++)a[i]*=gain;return a;
  }

  function wave(kind,n,dur,sr){
    const key=[kind,n,dur.toFixed(4),sr].join(':');
    if(waveCache.has(key))return waveCache.get(key);
    if(chamberKinds.has(kind)){const a=chamberWave(kind,n,dur,sr);waveCache.set(key,a);return a;}
    if(['harp','pipa','guqin','shamisen','sitar','tanpura'].includes(kind)){const a=stringWave(kind,n,dur,sr);waveCache.set(key,a);return a;}
    const length=Math.max(4,Math.ceil(dur*sr)),data=new Float32Array(length),f=hz(n||62);
    let seed=(0x6a09e667+Math.round(n*389)+kind.length*901)>>>0,noiseLow=0,noisePrev=0;
    const random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/2147483648-1;};
    const pluck=['harp','pipa','guqin','shamisen','sitar','tanpura','pizz','bass'].includes(kind);
    const pad=['strings','pad','organ','chant'].includes(kind);
    let phase=0;
    for(let i=0;i<length;i++){
      const t=i/sr,p=TAU*f*t,vib=Math.sin(TAU*5.3*t),rn=random();
      noiseLow+=.13*(rn-noiseLow);const high=rn-noisePrev;noisePrev=rn;
      let x=0,attack=.007,release=.04;
      if(pluck){
        const decay=kind==='guqin'?1.5:kind==='harp'?1.9:kind==='sitar'?1.65:kind==='tanpura'?.55:kind==='bass'?2.9:3.2;
        const bright=kind==='pipa'||kind==='shamisen';
        x=Math.sin(p)*Math.exp(-t*decay);
        for(let h=2;h<7;h++)x+=Math.sin(p*h+.025*Math.sin(t*17)*h)*Math.exp(-t*(decay+h*.72))/(bright?Math.pow(h,1.1):Math.pow(h,1.85));
        if(kind==='sitar'||kind==='tanpura')x+=.16*Math.sin(p*2.007)*Math.exp(-t*1.2)+.095*Math.sin(p*3.012)*Math.exp(-t*1.5);
        if(bright)x+=.09*high*Math.exp(-t*90);
        if(kind==='guqin')x+=.07*Math.sin(p*7.02)*Math.exp(-t*5);
        x*=.68;attack=kind==='bass'?.006:.002;release=.07;
      }else switch(kind){

        case 'felt':
          x=(Math.sin(p)+.24*Math.sin(p*2.0007)*Math.exp(-t*3.0)+.09*Math.sin(p*3.003)*Math.exp(-t*5.5)+.025*Math.sin(p*5.008)*Math.exp(-t*8))*.78*Math.exp(-t*1.65);
          x+=noiseLow*.012*Math.exp(-t*42);attack=.009;release=.16;break;
        case 'bamboo':
          {const swell=Math.min(1,t/.22),v=swell*.0032*Math.sin(TAU*5.1*t);
          phase+=TAU*f*(1+v+.007*Math.exp(-t*26))/sr;
          x=(Math.sin(phase)+.12*Math.sin(phase*2)+.035*Math.sin(phase*3)+.035*noiseLow)*.79*(1-.18*t/dur);
          attack=Math.min(.060,dur*.18);release=Math.min(.14,dur*.25);}break;
        case 'celesta':
          x=(Math.sin(p)*Math.exp(-t*2.6)+.24*Math.sin(p*2.012)*Math.exp(-t*6.8)+.075*Math.sin(p*3.97)*Math.exp(-t*9.6))*.70;attack=.0035;release=.12;break;
        case 'softMallet':
          x=(Math.sin(p)*Math.exp(-t*4.3)+.18*Math.sin(p*3.996)*Math.exp(-t*16)+.055*Math.sin(p*9.9)*Math.exp(-t*26))*.80;attack=.004;release=.10;break;
        case 'airyHarm':
          x=(Math.sin(p)+.26*Math.sin(p*2.0008)+.09*Math.sin(p*3.002)+.012*noiseLow)*.63*Math.exp(-t*.9);attack=.11;release=.19;break;
        case 'bowSweep':
          {const bend=2.2*Math.sin(Math.PI*Math.min(1,t/dur));phase+=TAU*f*Math.pow(2,bend/12)/sr;x=(Math.sin(phase)+.23*Math.sin(phase*2)+.07*Math.sin(phase*3))*.66;attack=.065;release=.19;}break;
        case 'piano':case 'electric':case 'midi':
          if(kind==='electric')x=(Math.sin(p+2.1*Math.sin(p*2)*Math.exp(-t*5))+.23*Math.sin(p*.999))*Math.exp(-t*1.8)*.7;
          else if(kind==='midi')x=(Math.sin(p)+.33*Math.sin(p*2.002)*Math.exp(-t*7)+.18*Math.sin(p*4.01)*Math.exp(-t*9))*Math.exp(-t*2.6)*.72;
          else x=(Math.sin(p)+.44*Math.sin(p*2.0009)*Math.exp(-t*2.7)+.23*Math.sin(p*3.006)*Math.exp(-t*4)+.13*Math.sin(p*4.016)*Math.exp(-t*6))*Math.exp(-t*1.65)*.6;
          attack=.004;release=.12;break;
        case 'fmBass':x=Math.sin(p+.8*Math.sin(p*2)*Math.exp(-t*12))*Math.exp(-t*2.8);attack=.008;break;
        case 'fretless':phase+=TAU*f*(1+.032*Math.exp(-t*24))/sr;x=(Math.sin(phase+.5*Math.sin(2*phase)*Math.exp(-t*9))+.12*Math.sin(2*phase))*Math.exp(-t*2.5)*.85;attack=.012;release=.08;break;
        case 'fmSax':
          x=(Math.sin(p+.08*vib+1.05*Math.sin(p)*Math.exp(-t*.6))+.24*Math.sin(p*2)+.1*noiseLow)*.58;
          x*=1-.38*t/dur;attack=.037;release=.08;break;
        case 'bronze':case 'gamelan':case 'gong':case 'lowGong':case 'frame':case 'bell':
          {const bf=kind==='bell'?1420:kind==='frame'?hz(n+12):f;
          const ratios=kind==='gamelan'?[1,2.73,5.17,6.66]:kind==='gong'||kind==='lowGong'?[1,1.43,2.09,2.73,3.41]:kind==='bell'?[1,1.501,2.037,2.91]:[1,2.756,5.405,8.931];
          const decay=kind==='bell'?5.9:kind==='frame'?6.8:kind==='lowGong'?1.15:kind==='gong'?1.8:2.8;
          ratios.forEach((r,j)=>{if(bf*r<sr*.42)x+=Math.sin(TAU*bf*r*t)*Math.exp(-t*(decay+j*1.7))/(1+j*1.9);});
          if(kind==='gamelan')x+=.28*Math.sin(TAU*bf*1.012*t)*Math.exp(-t*3.2);
          x*=.7;attack=kind==='lowGong'?.06:.0015;release=.055;}break;
        case 'flute':case 'xiao':case 'ocarina':
          x=Math.sin(p+.017*vib)+.13*Math.sin(2*p)+.04*Math.sin(3*p);
          if(kind==='xiao')x+=noiseLow*.28;else if(kind==='flute')x+=noiseLow*.12;
          x*=.76*(1-.22*t/dur);attack=kind==='ocarina'?.018:.042;release=.065;break;
        case 'chant':
          x=Math.sin(p)*.42+Math.sin(p*2)*.32+Math.sin(p*3+.018*vib)*.4+Math.sin(p*5)*.12+Math.sin(p*7)*.055;
          x*=.7*(.94+.06*Math.sin(t*TAU*4));attack=.1;release=.16;break;
        case 'strings':
          for(let h=1;h<8;h++)x+=(Math.sin(h*(p+.013*vib))+.33*Math.sin(h*(p*1.0019+.012*Math.sin(TAU*4.8*t))))/Math.pow(h,1.55);
          x*=.48;attack=.07;release=.14;break;
        case 'pad':x=(Math.sin(p)+.32*Math.sin(p*1.002)+.16*Math.sin(p*2.001))*.62;attack=.14;release=.22;break;
        case 'organ':x=(Math.sin(p)+.38*Math.sin(2*p)+.24*Math.sin(3*p)+.12*Math.sin(4*p))*.65;attack=.02;release=.1;break;
        case 'sine':x=Math.sin(p)*Math.exp(-t*2.7);attack=.008;release=.035;break;
        case 'tube':x=.65*Math.sin(TAU*60*t)+.19*Math.sin(TAU*120*t)+.12*noiseLow;attack=.2;release=.3;break;
        case 'power':phase+=TAU*(80+540*(1-Math.exp(-t*12)))/sr;x=(Math.sin(phase)+.25*high)*Math.exp(-t*8);attack=.004;break;
        case 'scopeWarp':
          phase+=TAU*(190+110*Math.sin(t*TAU*1.6)+310*Math.sin(t*2.4))/sr;
          x=Math.sin(phase+4.1*Math.sin(TAU*(9+t*8)*t))*.64;attack=.035;release=.15;break;
        case 'scream':
          phase+=TAU*(hz(78)+480*Math.sin(Math.min(1,t/.45)*Math.PI*.8))/sr;
          x=(Math.sin(phase)+.23*Math.sin(phase*1.044)+.13*Math.sin(phase*2.013))*.59;attack=.025;release=.15;break;
        case 'kick':phase+=TAU*(44+104*Math.exp(-t*34))/sr;x=Math.sin(phase)*Math.exp(-t*15)+.1*high*Math.exp(-t*100);attack=.001;release=.035;break;
        case 'djembe':case 'tablaLow':
          phase+=TAU*(f+(kind==='tablaLow'?52:79)*Math.exp(-t*24))/sr;
          x=(Math.sin(phase)+.22*Math.sin(phase*1.72))*Math.exp(-t*13)+.12*high*Math.exp(-t*65);attack=.001;break;
        case 'tabla':x=(Math.sin(p)+.42*Math.sin(p*1.52)+.2*Math.sin(p*2.67))*Math.exp(-t*19)+.18*high*Math.exp(-t*80);attack=.001;break;
        case 'wood':case 'woodLow':case 'rim':case 'key':
          {const fq=kind==='key'?1620:kind==='rim'?960:f*2;
          x=(Math.sin(TAU*fq*t)+.37*Math.sin(TAU*fq*1.48*t))*Math.exp(-t*(kind==='woodLow'?24:55))*.62+high*.22*Math.exp(-t*115);attack=.0005;release=.012;}break;
        case 'clap':
          {const env=Math.exp(-t*28)+.6*Math.exp(-Math.max(0,t-.013)*38)*(t>.013)+.5*Math.exp(-Math.max(0,t-.027)*40)*(t>.027);
          x=(rn-noiseLow)*env*.56;attack=.0005;release=.025;}break;
        case 'hat':case 'shaker':case 'brush':case 'switch':case 'chipNoise':
          x=(rn-noiseLow)*Math.exp(-t*(kind==='brush'?24:kind==='switch'?70:kind==='chipNoise'?34:65))*.67;attack=.0005;release=.018;
          if(kind==='chipNoise')x=Math.sign(x)*Math.exp(-t*40)*.55;break;
        case 'shutter':
          x=(rn-noiseLow)*(Math.exp(-t*105)+.64*Math.exp(-Math.max(0,t-.047)*95)*(t>=.047))*.8+.12*Math.sin(TAU*1730*t)*Math.exp(-t*65);attack=.0004;release=.012;break;
        case 'nudge':phase+=TAU*(290+170*Math.sin(t*TAU*7))/sr;x=Math.sin(phase)*Math.exp(-t*14)*.63;attack=.002;release=.02;break;
        case 'droplet':phase+=TAU*(f+f*.7*Math.exp(-t*37))/sr;x=Math.sin(phase+1.2*Math.sin(phase*2)*Math.exp(-t*28))*Math.exp(-t*20)*.68;attack=.001;release=.028;break;
        case 'splash':x=(noiseLow*1.3+rn*.17)*Math.exp(-t*19)+.12*Math.sin(TAU*(260*t-240*t*t))*Math.exp(-t*28);attack=.001;release=.04;break;
        case 'message':x=(Math.sin(p)+.22*Math.sin(p*2.76))*Math.exp(-t*13)*.8;attack=.0015;release=.035;break;
        case 'rain':case 'air':case 'tapeHiss':
          x=kind==='rain'?(rn-noiseLow)*(.66+.16*Math.sin(TAU*.35*t)):kind==='air'?noiseLow*2.2:(rn-noiseLow)*.4;
          attack=kind==='tapeHiss'?.02:.6;release=.55;break;
        case 'chipLead':case 'chipArp':
          {const duty=kind==='chipLead'?.25:.5,ph=(f*t)%1; // Band-limit the discontinuity with a short Fourier sum.
          for(let h=1;h<12;h++)if(h*f<sr*.4)x+=Math.sin(Math.PI*h*duty)*Math.cos(TAU*h*(ph-duty/2))/h;
          x*=.9*Math.exp(-t*.8);attack=.0015;release=.02;}break;
        case 'chipBass':for(let h=1;h<12;h+=2)x+=(h%4===1?1:-1)*Math.sin(p*h)/(h*h);x*=.78;attack=.003;release=.02;break;
        case 'chipJump':phase+=TAU*(180+1300*t)/sr;x=Math.sin(phase)+.22*Math.sin(phase*3);x*=Math.exp(-t*6)*.6;attack=.001;release=.025;break;
        default:x=Math.sin(p)*Math.exp(-t*3);
      }
      const a=Math.min(1,t/attack),r=Math.min(1,(dur-t)/Math.min(release,dur*.38));
      data[i]=Math.max(-1.8,Math.min(1.8,x))*a*Math.max(0,r);
    }
    waveCache.set(key,data);return data;
  }
  function bufferFor(ctx,e){
    let cache=contextBuffers.get(ctx);if(!cache){cache=new Map();contextBuffers.set(ctx,cache);}
    const key=[e.kind,e.n,e.dur.toFixed(4),ctx.sampleRate].join(':');if(cache.has(key))return cache.get(key);
    const a=wave(e.kind,e.n,e.dur,ctx.sampleRate),b=ctx.createBuffer(1,a.length,ctx.sampleRate);b.copyToChannel(a,0);cache.set(key,b);return b;
  }
  function noiseImpulse(ctx,seconds,seed=821){
    const b=ctx.createBuffer(2,Math.ceil(ctx.sampleRate*seconds),ctx.sampleRate);
    for(let ch=0;ch<2;ch++){
      let s=(seed+ch*991)>>>0,low=0;const a=new Float32Array(b.length);
      for(let i=0;i<a.length;i++){s=(Math.imul(s,1664525)+1013904223)>>>0;low+=.38*((s/2147483648-1)-low);const t=i/ctx.sampleRate;a[i]=low*Math.exp(-t*6.4/seconds)*(t<.015?t/.015:1);}
      // Sparse early reflections precede a diffuse, deterministic synthetic room.
      for(const [d,g]of [[.021,.28],[.037,.18],[.059,.12]])a[Math.floor((d+ch*.003)*ctx.sampleRate)]+=g;
      b.copyToChannel(a,ch);
    }return b;
  }
  // Chapter balance is applied after the common compressor. A short ramp at
  // each doorway avoids the much louder tape/phone abruptly following the chat.
  const programStarts=[0,6,11,17,22,29,36,46,51,58,63,70,76,84,90,96,104,113,145,151,160,170];
  const programDb=[.9,.3,2.1,1.5,1.9,2.1,.3,.5,1.0,.6,-.4,1.5,.0,-.1,.1,.8,-1.3,.9,-1.0,-.6,1.3,1.1];
  const programLevel=t=>{let i=programStarts.length-1;while(i>0&&t<programStarts[i])i--;for(let k=Math.max(1,i);k<=Math.min(i+1,programStarts.length-1);k++){const u=(t-programStarts[k]+.35)/.7;if(u>=0&&u<=1)return Math.pow(10,((1-u)*programDb[k-1]+u*programDb[k])/20);}return Math.pow(10,programDb[i]/20);};
  function makeBus(ctx,destination,volume,rate){
    const input=ctx.createGain(),out=ctx.createGain(),hp=ctx.createBiquadFilter(),comp=ctx.createDynamicsCompressor(),program=ctx.createGain();
    out.gain.value=volume*MASTER_GAIN;hp.type='highpass';hp.frequency.value=31;hp.Q.value=.5;
    comp.threshold.value=-15;comp.knee.value=14;comp.ratio.value=2.5;comp.attack.value=.008;comp.release.value=.18;
    input.connect(hp);hp.connect(comp);comp.connect(program);program.connect(out);out.connect(destination);
    const rev=ctx.createConvolver(),send=ctx.createGain(),wet=ctx.createGain();
    rev.buffer=noiseImpulse(ctx,1.35/rate);send.gain.value=.16;wet.gain.value=.64;
    input.connect(send);send.connect(rev);rev.connect(wet);wet.connect(hp);
    return{input,dryInput:hp,out,program,nodes:[input,out,hp,comp,program,rev,send,wet]};
  }
  async function prepare(options={}){
    const sr=options.sampleRate||SAMPLE_RATE;
    if(tape&&tape.sampleRate===sr)return {sampleRate:sr,tapeSeconds:tape.duration};
    if(preparing)return preparing;
    const Offline=options.OfflineAudioContext||root.OfflineAudioContext||root.webkitOfflineAudioContext;
    if(!Offline)throw Error('OfflineAudioContext is required to synthesize the original vaporwave tape.');
    preparing=(async()=>{
      // Source performance is 151.2 BPM and four semitones above the main key.
      // No audio file is decoded. The AudioBuffer is born in this graph.
      const c=new Offline(2,Math.ceil(sr*6.3),sr),out=c.createGain();out.gain.value=.88;out.connect(c.destination);
      // A short synthetic drum room with an explicit gate, before the tape pass.
      const drumRoom=c.createConvolver(),drumWet=c.createGain(),drumIR=c.createBuffer(2,Math.ceil(sr*.18),sr);
      for(let ch=0;ch<2;ch++){
        const a=new Float32Array(drumIR.length);let seed=9871+ch*719;
        for(let i=0;i<a.length;i++){seed=(Math.imul(seed,1664525)+1013904223)>>>0;const t=i/sr;a[i]=(seed/2147483648-1)*Math.exp(-t*9)*Math.min(1,t/.002)*Math.min(1,(.18-t)/.018);}
        drumIR.copyToChannel(a,ch);
      }
      drumRoom.buffer=drumIR;drumWet.gain.value=.27;drumRoom.connect(drumWet);drumWet.connect(out);
      const sourceEvents=[], push=(time,kind,n,dur,amp,pan=0)=>sourceEvents.push({time,kind,n:n+4,dur,amp,pan});
      const speed=151.2/120, beat=60/151.2;
      const jazzChords=[[43,54,59,62,69],[40,50,55,59,66],[48,55,59,62,64],[38,54,60,64,69]];
      for(let bar=0;bar<4;bar++){
        const ns=jazzChords[bar%4],at=bar*4*beat;
        ns.forEach((n,k)=>push(at+k*.012,'electric',n,1.7/speed,.065,(k-2)*.24));
        ns.forEach((n,k)=>push(at+2.5*beat+k*.013,'electric',n,1.05/speed,.035,(k-2)*.22));
        push(at,'fretless',[43,40,48,38][bar%4],1.2/speed,.15,-.05);
        push(at+1.5*beat,'fretless',[50,47,55,45][bar%4],.48/speed,.085,.04);
        push(at+3*beat,'fretless',[42,47,43,42][bar%4],.62/speed,.09,.02);
      }
      for(const [t,n,d]of theme)push((t+.12)/speed,'fmSax',n+5,(d+.13)/speed,.20,-.18);
      for(const [t,n]of [[3.97,74],[4.52,71],[5.14,69],[5.76,67]])push(t/speed,'fmSax',n,.42/speed,.16,-.1);
      for(let b=0;b<16;b++){
        const at=b*beat;
        push(at,b%2===0?'kick':'clap',0,b%2===0?.28:.16,b%2===0?.115:.06,0);
        push(at+beat*.5,'hat',0,.07,.02,.5);
      }
      for(const e of sourceEvents){
        if(e.time>=6.3)continue;
        const s=c.createBufferSource(),g=c.createGain(),p=c.createStereoPanner();
        s.buffer=bufferFor(c,e);g.gain.value=e.amp;p.pan.value=e.pan;s.connect(g);g.connect(p);p.connect(out);if(e.kind==='clap')p.connect(drumRoom);s.start(e.time);
      }
      tape=await c.startRendering();preparing=null;return {sampleRate:sr,tapeSeconds:tape.duration};
    })();
    try{return await preparing;}catch(e){preparing=null;throw e;}
  }
  function schedule(ctx,options={}){
    const offset=clamp(options.offset||0,0,DURATION),rate=clamp(options.rate||1,.25,3);
    let when=options.when===undefined?ctx.currentTime+.12:options.when;
    const offline=!!options.offline, destination=options.destination||ctx.destination;
    // Prepare only the first lookahead window before the transport clock starts.
    // A cold instrument must not steal the first note's attack or desync the film.
    if(!offline){
      for(const e of events)if(e.time+e.dur>offset&&e.time<=offset+2.5*rate)bufferFor(ctx,e);
      when=Math.max(when,ctx.currentTime+.12);
    }
    const bus=makeBus(ctx,destination,options.volume===undefined?.92:options.volume,rate),sources=[],otherNodes=[];
    const nodes=bus.nodes, early=offset>0?.016:.004;
    bus.out.gain.setValueAtTime(0,Math.max(0,when));bus.out.gain.linearRampToValueAtTime((options.volume===undefined?.92:options.volume)*MASTER_GAIN,when+early);
    bus.program.gain.setValueAtTime(programLevel(offset),Math.max(0,when));
    const programTimes=programStarts.slice(1).flatMap(t=>[t-.35,t+.35]).filter(t=>t>offset);
    for(const t of programTimes)bus.program.gain.linearRampToValueAtTime(programLevel(t),when+(t-offset)/rate);
    let cursor=0,stopped=false,stoppedAt=null,timer=null,tapeScheduled=false;
    while(cursor<events.length&&events[cursor].time+events[cursor].dur<offset)cursor++;
    const map=t=>when+(t-offset)/rate;
    function launch(e){
      if(e.time+e.dur<=offset||e.time>=DURATION)return;
      const noteBuffer=bufferFor(ctx,e);
      let skip=Math.max(0,offset-e.time),start=map(e.time+skip);
      if(start<ctx.currentTime&&!offline){const late=ctx.currentTime-start;skip+=late*rate;start=ctx.currentTime;}
      if(skip>=e.dur-.002)return;
      const s=ctx.createBufferSource(),g=ctx.createGain(),p=ctx.createStereoPanner();
      s.buffer=noteBuffer;s.playbackRate.value=rate;g.gain.value=e.amp;p.pan.value=e.pan;
      s.connect(g);g.connect(p);p.connect(e.channel||e.space==='close'?bus.dryInput:bus.input);
      s.start(Math.max(0,start),skip);s.stop(Math.min(map(DURATION),start+(e.dur-skip)/rate+.004));
      sources.push(s);nodes.push(g,p);
    }
    function launchTape(){
      if(tapeScheduled||offset>=151.65)return;tapeScheduled=true;
      if(!tape)throw Error('Call and await PelicanScore.prepare() before playback.');
      const localTape=ctx.createBuffer(2,tape.length,tape.sampleRate);
      for(let ch=0;ch<2;ch++){const a=new Float32Array(tape.length);tape.copyFromChannel(a,ch);localTape.copyToChannel(a,ch);}
      const filt=ctx.createBiquadFilter(),dry=ctx.createGain(),send=ctx.createGain(),conv=ctx.createConvolver(),wet=ctx.createGain(),tapeOut=ctx.createGain();
      filt.type='lowpass';filt.frequency.value=4000;filt.Q.value=.6;dry.gain.value=.75;send.gain.value=.7;wet.gain.value=.72;
      conv.buffer=noiseImpulse(ctx,4/rate,4921);filt.connect(dry);dry.connect(tapeOut);filt.connect(send);send.connect(conv);conv.connect(wet);wet.connect(tapeOut);tapeOut.connect(bus.input);
      const end=map(151.65);tapeOut.gain.setValueAtTime(1,Math.max(ctx.currentTime,map(145)));tapeOut.gain.setValueAtTime(1,Math.max(ctx.currentTime,map(150.88)));tapeOut.gain.linearRampToValueAtTime(0,Math.max(ctx.currentTime+.005,end));
      otherNodes.push(filt,dry,send,conv,wet,tapeOut);
      const sourcePhase=local=>local<=.5?local-(1-.7937)*local*local: .448425+(local-.5)*.7937;
      const segments=[{a:0,b:2,from:0,entry:true},...Array.from({length:4},(_,i)=>({a:2+i*.25,b:2.25+i*.25,from:sourcePhase(2)})),{a:3,b:6.02,from:sourcePhase(2.25),exit:true}];
      for(const seg of segments){
        const absolute=145+seg.a,absoluteEnd=145+seg.b;if(absoluteEnd<=offset)continue;
        const skip=Math.max(0,offset-absolute),start=map(absolute+skip),s=ctx.createBufferSource(),g=ctx.createGain(),lfo=ctx.createOscillator(),depth=ctx.createGain();
        s.buffer=localTape;
        const startRate=seg.entry&&skip<.5?1-(1-.7937)*skip/.5:seg.exit&&seg.a+skip>5.5?.7937+(1-.7937)*(seg.a+skip-5.5)/.5:.7937;
        s.playbackRate.setValueAtTime(startRate*rate,Math.max(0,start));
        if(seg.entry&&skip<.5)s.playbackRate.linearRampToValueAtTime(.7937*rate,map(145.5));
        if(seg.exit){if(offset<150.5)s.playbackRate.setValueAtTime(.7937*rate,map(150.5));s.playbackRate.linearRampToValueAtTime(rate,map(151));}
        lfo.frequency.value=.5*rate;depth.gain.value=6.5;lfo.connect(depth);depth.connect(s.detune);
        const stop=map(absoluteEnd),fade=Math.min(.006,(stop-start)*.15);g.gain.setValueAtTime(0,Math.max(0,start));g.gain.linearRampToValueAtTime(1,start+fade);g.gain.setValueAtTime(1,stop-fade);g.gain.linearRampToValueAtTime(0,stop);
        s.connect(g);g.connect(filt);
        const u=Math.max(0,seg.a+skip-5.5),exitPhase=seg.exit?.2063*Math.min(u,.5)**2+.2063*Math.max(0,u-.5):0;
        const bufferOffset=seg.from+(seg.entry?sourcePhase(skip):skip*.7937+exitPhase);
        s.start(Math.max(0,start),bufferOffset);s.stop(stop);lfo.start(Math.max(0,start));lfo.stop(stop);sources.push(s,lfo);otherNodes.push(g,depth);
      }
      launch({time:145,kind:'tapeHiss',n:0,dur:6,amp:.012,pan:0});
    }
    function tick(){
      if(stopped)return;
      const until=offline?DURATION:Math.min(DURATION,offset+Math.max(0,ctx.currentTime-when)*rate+2.5*rate);
      while(cursor<events.length&&events[cursor].time<=until)launch(events[cursor++]);
      if(until>=145&&!tapeScheduled)launchTape();
      if(!offline&&ctx.currentTime>map(DURATION)+.15){clearInterval(timer);timer=null;}
    }
    tick();if(!offline)timer=setInterval(tick,120);
    return{
      startTime:when,endTime:map(DURATION),gain:bus.out,
      currentTime:()=>stoppedAt===null?clamp(offset+Math.max(0,ctx.currentTime-when)*rate,0,DURATION):stoppedAt,
      setVolume(v){const now=ctx.currentTime;bus.out.gain.cancelScheduledValues(now);bus.out.gain.setTargetAtTime(clamp(v,0,1.4)*MASTER_GAIN,now,.018);},
      stop(){if(stopped)return;stoppedAt=clamp(offset+Math.max(0,ctx.currentTime-when)*rate,0,DURATION);stopped=true;if(timer)clearInterval(timer);const now=ctx.currentTime;bus.out.gain.cancelScheduledValues(now);bus.out.gain.setTargetAtTime(0,now,.006);for(const s of sources)try{s.stop(now+.025);}catch(_){}if(!offline)setTimeout(()=>{for(const n of [...nodes,...otherNodes])try{n.disconnect();}catch(_){}},60);},
      eventCount:events.length
    };
  }
  async function renderOffline(Offline,options={}){
    const sr=options.sampleRate||SAMPLE_RATE,offset=options.offset||0,duration=options.duration||DURATION-offset;
    await prepare({sampleRate:sr,OfflineAudioContext:Offline});
    const ctx=new Offline(2,Math.ceil(sr*duration),sr);
    schedule(ctx,{offset,when:0,rate:1,offline:true,volume:options.volume===undefined?.92:options.volume});
    return ctx.startRendering();
  }
  root.PelicanScore={duration:DURATION,bpm:BPM,sampleRate:SAMPLE_RATE,theme,events,cues,chapterNames,prepare,schedule,renderOffline,
    info:()=>({original:true,revision:"R8 · A brass bell and two wheels / original score",externalAudioAssets:0,eventCount:events.length,generatedVoiceBuffers:waveCache.size,tapePrepared:!!tape,tapeSourceBpm:151.2,tapeSemitones:4,tapePlaybackRate:.7937,tapeStutter:[147,147.25,147.5,147.75]})};
  if(typeof module!=='undefined'&&module.exports)module.exports=root.PelicanScore;
})(typeof globalThis!=='undefined'?globalThis:this);
