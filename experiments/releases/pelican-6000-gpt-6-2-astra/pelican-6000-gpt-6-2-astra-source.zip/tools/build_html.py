#!/usr/bin/env python3
"""Build the offline procedural p5 + Web Audio player. No external image/audio assets."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil

ROOT = Path(__file__).resolve().parent.parent
P5_VERSION = "2.4.0"
MODULES = (
    "kit.js", "rider.js", "scenes_historic.js", "scenes_modern.js",
    "cast_R5.js", "scenes_interfaces.js", "art_assets.js", "character_assets.js",
    "scene_notes.js", "portals.js", "film.js", "presentation.js", "enhance_R3.js", "chat_frame_R5.js", "cast_study.js", "story_R5.js", "director_R5.js", "refine_R6.js", "night_R7.js", "historical_R7.js", "modern_R7.js", "performance_R7.js", "print_R7.js", "rider_R8.js", "history_R8.js", "modern_R8.js", "digital_R8.js",
)
VENDOR_FILES = (
    ("lib/p5.min.js", "p5.min.js"),
    ("lib/p5.js", "lib/p5.js"),
    ("license.txt", "license.txt"),
)

def ensure_vendor() -> None:
    source = ROOT / "node_modules" / "p5"
    for original, local in VENDOR_FILES:
        target = ROOT / "vendor" / local
        if target.is_file():
            continue
        if not (source / original).is_file():
            raise FileNotFoundError(
                f"Missing vendor/{local}. Install p5 {P5_VERSION}, then build again."
            )
        version = json.loads((source / "package.json").read_text())["version"]
        if version != P5_VERSION:
            raise ValueError(f"Expected p5 {P5_VERSION}, found {version}.")
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source / original, target)

def inline_script(code: str) -> str:
    return re.sub(r"</script", r"<\/script", code, flags=re.IGNORECASE)

def assert_procedural(code: str) -> None:
    forbidden = (
        r"\bnew\s+(?:window\.)?Image\s*\(",
        r"\bnew\s+(?:window\.)?Audio\s*\(",
        r"\bloadImage\s*\(",
        r"data:(?:image|audio)/",
        r"<(?:img|audio|video)\b",
        r"__AUDIO_DATA__|__CHARACTER_ASSETS__",
    )
    for pattern in forbidden:
        if re.search(pattern, code, flags=re.IGNORECASE):
            raise ValueError(f"Image/audio loading is not permitted: {pattern}")

def offline_vendor(code: str) -> str:
    """Avoid p5's optional error-message translation fetch in the offline file.
    The untouched upstream source stays in vendor/. Only this documented block
    is changed in the embedded copy; the drawing/runtime code is unchanged.
    """
    start = code.index(",Qa=new Promise(async t=>{")
    end = code.index(");var $a=class", start) + 1
    if "cdn.jsdelivr.net/npm/p5@" not in code[start:end]:
        raise ValueError("Pinned p5 translation block changed; review patch.")
    return code[:start] + ",Qa=Promise.resolve()" + code[end:]

def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "pelican.html")
    args = parser.parse_args()
    ensure_vendor()
    template = (ROOT / "src" / "player.html").read_text(encoding="utf-8")
    sources = {name: (ROOT / "src" / name).read_text(encoding="utf-8") for name in MODULES}
    film = "\n\n".join("/* src/" + name + " */\n" + code for name, code in sources.items())
    score = (ROOT / "audio" / "score.js").read_text(encoding="utf-8")
    assert_procedural(template + "\n" + film + "\n" + score)
    vendor = (ROOT / "vendor" / "p5.min.js").read_text(encoding="utf-8")
    if not re.search(r"p5(?:\.js)?\s+v?" + re.escape(P5_VERSION), vendor[:1000], re.IGNORECASE):
        raise ValueError("Bundled p5 version does not match the pinned build.")
    upstream_vendor_sha = hashlib.sha256(vendor.encode()).hexdigest()
    vendor = offline_vendor(vendor)
    meta = {
        "p5Version": P5_VERSION, "silent": False, "audioEngine": "Web Audio", "originalScore": True, "duration": 186,
        "moduleOrder": list(MODULES),
        "sourceSha256": hashlib.sha256(film.encode()).hexdigest(),
        "scoreSha256": hashlib.sha256(score.encode()).hexdigest(),
        "p5Sha256": hashlib.sha256(vendor.encode()).hexdigest(),
        "p5UpstreamSha256": upstream_vendor_sha, "p5OfflinePatch": "skip optional translation fetch",
    }
    replacements = {
        "/*__P5_CODE__*/": inline_script(vendor),
        "/*__FILM_CODE__*/": inline_script(film),
        "/*__SCORE_CODE__*/": inline_script(score),
        "__BUILD_META__": json.dumps(meta, ensure_ascii=False, separators=(",", ":")),
    }
    for token, value in replacements.items():
        if template.count(token) != 1:
            raise ValueError(f"Expected one template marker: {token}")
        template = template.replace(token, value)
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(template.replace("\n", "\r\n").encode("utf-8"))
    print(json.dumps({
        "file": str(output), "bytes": output.stat().st_size,
        "sha256": hashlib.sha256(output.read_bytes()).hexdigest(),
        "p5Version": P5_VERSION, "modules": len(MODULES),
        "imageAssets": 0, "externalAudioAssets": 0, "proceduralScore": True,
    }, ensure_ascii=False))

if __name__ == "__main__":
    main()
