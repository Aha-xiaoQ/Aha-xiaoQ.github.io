"""Package the offline film and verify that a clean extraction rebuilds it."""
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
from zipfile import ZIP_DEFLATED, ZipFile

from build_html import MODULES, VENDOR_FILES


ROOT = Path(__file__).resolve().parent.parent
PLAYER = "pelican.html"
TARGET = ROOT / "exports" / "Pelican_6000_R8_Source.zip"
TOOL_FILES = ("browser_path.py", "build_html.py", "render_audio_browser.py",
              "export_r8.py", "package_source.py")


def checksum(data):
    return sha256(data).hexdigest()


def main():
    if "digital_R8.js" not in MODULES:
        raise RuntimeError("The R8 digital scenes are absent from the build.")
    source_files = [
        "README.md", "THIRD_PARTY_NOTICES.md", "requirements.txt",
        "docs/OFFLINE_VENDOR_PATCH.md", PLAYER, "audio/score.js", "src/player.html",
        *(f"src/{module}" for module in MODULES),
        *(f"vendor/{local_name}" for _, local_name in VENDOR_FILES),
        *(f"tools/{name}" for name in TOOL_FILES),
    ]
    TARGET.parent.mkdir(exist_ok=True)
    with TemporaryDirectory(dir=TARGET.parent) as work:
        folder = Path(work)
        archive = folder / TARGET.name
        digest = {}
        with ZipFile(archive, "w", compression=ZIP_DEFLATED, compresslevel=9) as output:
            for name in source_files:
                payload = (ROOT / name).read_bytes()
                output.writestr(name, payload)
                digest[name] = checksum(payload)
            manifest = {"model": "GPT-6.2 Astra", "algorithm": "sha256", "files": digest}
            output.writestr("SOURCE_MANIFEST.json", json.dumps(manifest, indent=2) + "\n")
        extraction = folder / "clean"
        with ZipFile(archive) as source:
            if source.testzip():
                raise RuntimeError("The source archive failed CRC verification.")
            source.extractall(extraction)
        for name, expected in digest.items():
            if checksum((extraction / name).read_bytes()) != expected:
                raise RuntimeError(f"Archive member does not match its manifest: {name}")
        subprocess.run([sys.executable, "tools/build_html.py"], cwd=extraction, check=True)
        if checksum((extraction / PLAYER).read_bytes()) != digest[PLAYER]:
            raise RuntimeError("Extracted sources do not reproduce the shipped player.")
        archive.replace(TARGET)
    print(json.dumps({"archive": TARGET.name, "members": len(source_files) + 1,
                      "bytes": TARGET.stat().st_size, "htmlSha256": digest[PLAYER],
                      "archiveSha256": checksum(TARGET.read_bytes())}, indent=2))


if __name__ == "__main__":
    main()
