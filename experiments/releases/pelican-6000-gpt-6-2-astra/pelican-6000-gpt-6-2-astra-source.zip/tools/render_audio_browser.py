from pathlib import Path
from playwright.sync_api import sync_playwright
import base64,json,time
from browser_path import chromium_path
root=Path(__file__).resolve().parent.parent;out=root/'exports';out.mkdir(exist_ok=True)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=chromium_path(),headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 page=b.new_page();page.set_content('<html></html>');page.add_script_tag(content=(root/'audio/score.js').read_text(encoding='utf-8'));start=time.monotonic()
 print('Web Audio rendering',flush=True)
 result=page.evaluate('''async()=>{const score=PelicanScore,b=await score.renderOffline(OfflineAudioContext,{sampleRate:48000});window.audioResult=b;let peak=0,sum=0,bad=0;for(let c=0;c<2;c++){let a=b.getChannelData(c);for(let i=0;i<a.length;i++){if(!Number.isFinite(a[i]))bad++;peak=Math.max(peak,Math.abs(a[i]));sum+=a[i]*a[i];}}return {duration:b.duration,frames:b.length,sampleRate:b.sampleRate,channels:b.numberOfChannels,peak,peakDb:20*Math.log10(peak),rmsDb:20*Math.log10(Math.sqrt(sum/(b.length*2))),badSamples:bad,info:score.info(),events:score.events.length,cues:score.cues}}''')
 print(json.dumps(result),flush=True)
 # Transfer bounded PCM chunks to avoid duplicating a long base64 string in memory.
 import wave
 with wave.open(str(out/'Pelican_PureCode_R8_Original_Score.wav'),'wb') as wav:
  wav.setnchannels(2);wav.setsampwidth(2);wav.setframerate(result['sampleRate'])
  for start_sample in range(0,result['frames'],48000):
   data=page.evaluate("""start=>{const b=audioResult,n=Math.min(48000,b.length-start),ab=new ArrayBuffer(n*4),v=new DataView(ab),a=[b.getChannelData(0),b.getChannelData(1)];for(let i=0;i<n;i++)for(let c=0;c<2;c++)v.setInt16(i*4+c*2,Math.round(Math.max(-1,Math.min(1,a[c][start+i]))*32767),true);let z=new Uint8Array(ab),ss=[];for(let i=0;i<z.length;i+=8192)ss.push(String.fromCharCode(...z.subarray(i,i+8192)));return btoa(ss.join(''));}""",start_sample)
   wav.writeframesraw(base64.b64decode(data))
 result['renderSeconds']=time.monotonic()-start
 (out/'audio_validation_R8.json').write_text(json.dumps(result,ensure_ascii=False,indent=2), encoding='utf-8');b.close();print('AUDIO_COMPLETE',flush=True)
