"""Select a browser for rendering, preserving Playwright's managed fallback."""
from pathlib import Path
import os
import shutil
import sys


def chromium_path():
    override = os.environ.get("CHROMIUM")
    if override:
        executable = Path(override).expanduser()
        if not executable.is_file():
            raise FileNotFoundError(f"CHROMIUM points to a missing executable: {executable}")
        return str(executable)

    for name in ("google-chrome", "google-chrome-stable", "chromium", "chromium-browser"):
        executable = shutil.which(name)
        if executable:
            return executable
    candidates = []
    if sys.platform == "win32":
        for folder in ("ProgramFiles", "ProgramFiles(x86)", "LOCALAPPDATA"):
            if os.environ.get(folder):
                candidates.append(Path(os.environ[folder]) / "Google/Chrome/Application/chrome.exe")
    elif sys.platform == "darwin":
        candidates.append(Path("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"))
    return next((str(executable) for executable in candidates if executable.is_file()), None)
