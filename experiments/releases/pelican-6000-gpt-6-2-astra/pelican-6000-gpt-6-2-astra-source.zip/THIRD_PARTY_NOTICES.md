# 第三方组件与创作参考

## p5.js

`vendor/p5.min.js`、`vendor/lib/p5.js` 与 `vendor/license.txt` 为 p5.js 2.4.0 的上游文件。p5.js 按 LGPL-2.1 许可分发。播放器构建时仅替换可选的错误信息翻译初始化，详情见 `docs/OFFLINE_VENDOR_PATCH.md`。

## 影片与声音

艺术史骑行命题、开头的虚构考据与穿越二十幅画的结构延续《鹈鹕测试》及同题创作。R8 基于《借过一下 · 鹈鹕的六千年》原有纯代码工程重新绘制角色、车辆、场景与音画。片内画面由程序生成，配乐由浏览器原生 Web Audio 合成。群聊和直播为虚构界面与剧情。

创作参考包括[《鹈鹕测试》](https://www.bilibili.com/video/BV1pLnw6YEzq/)与[同题版本](https://www.bilibili.com/video/BV1SsWy6TEKx/)。源码包中的运行素材不包含这些参考影片的画面或录音。

## 导出工具

导出脚本依赖 Python Playwright、兼容的 Chromium 浏览器和 FFmpeg。其可执行文件与系统字体由运行环境提供。
