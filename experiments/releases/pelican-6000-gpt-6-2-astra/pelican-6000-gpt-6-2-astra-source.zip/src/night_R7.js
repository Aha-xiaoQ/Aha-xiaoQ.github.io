/* A painted sky, not a picture: two streams of viscous pigment wind through an
   undercoat. Stroke order and the light-facing edge of each ridge are fixed. */
M.paintR7Night=function(g){
 let state=924731;function rnd(){state=(Math.imul(1664525,state)+1013904223)>>>0;return state/4294967296}
 const tau=Math.PI*2;
 const under=g.createLinearGradient(0,0,100,621);under.addColorStop(0,'#101f51');under.addColorStop(.49,'#174477');under.addColorStop(1,'#5988a1');g.fillStyle=under;g.fillRect(0,0,1600,900);
 const eddies=[[592,294,260,116,1],[1100,363,153,77,-1],[1340,201,102,101,1]];
 function heading(x,y){let h=-.095-.21*Math.cos(x*.0063+y*.004)+.19*Math.sin(y*.022+x*.003),vx=Math.cos(h),vy=Math.sin(h);
  for(let [cx,cy,sx,sy,spin] of eddies){let dx=(x-cx)/sx,dy=(y-cy)/sy,rr=dx*dx+dy*dy,q=1.85*Math.exp(-rr*.67);vx+=(-dy*spin)*q*3.2;vy+=(dx*spin)*(sy/sx)*q*3.2}return Math.atan2(vy,vx)}
 function dab(x,y,a,l,w,clr,curve,edge){let dx=Math.cos(a),dy=Math.sin(a),nx=-dy,ny=dx,sx=x+dx*l*.4+nx*curve,sy=y+dy*l*.4+ny*curve,ex=x+dx*l,ey=y+dy*l;
  g.beginPath();g.moveTo(x,y);g.quadraticCurveTo(sx+nx*w,sy+ny*w,ex,ey);g.quadraticCurveTo(sx-nx*w*.66,sy-ny*w*.66,x,y);g.fillStyle=clr;g.fill();
  if(edge){g.beginPath();g.moveTo(x+dx*l*.15,y+dy*l*.15);g.quadraticCurveTo(sx+nx*w*.55,sy+ny*w*.55,ex-dx*l*.19,ey-dy*l*.19);g.strokeStyle=edge;g.lineWidth=Math.max(.65,w*.14);g.stroke()}}
 const blues=['#19396a','#112e61','#255684','#346b97','#3573a2','#234677','#315a89','#43789e','#173561','#2d527c','#507fa0'];
 for(let i=0;i<15500;i++){let x=-34+rnd()*1670,y=-10+rnd()*646,a=heading(x,y)+(rnd()-.5)*.27;let b=.5+.5*Math.sin(y*.08+3*Math.sin(x*.009+y*.011)),n=Math.min(10,Math.floor(rnd()*8+b*2));dab(x,y,a,6+15*rnd(),1.1+2.4*rnd(),blues[n],(rnd()-.4)*2,rnd()<.14?'#6c95a8':null)}
 // Two hand-laid currents, sampled by arclength; the highlights can run
 // along these exact same paths on the wheel clock without texture swimming.
 for(const [idx,[d,w,lanes,seed]] of M.starryStreams.entries()){let el=document.createElementNS('http://www.w3.org/2000/svg','path');el.setAttribute('d',d);let len=el.getTotalLength();
  const pals=['#254e85','#346a9c','#4188b3','#70acc1','#b5d3cc','#e1dbab','#94bfce','#507fa6','#2e6293'];
  for(let lane=-10;lane<=10;lane++){let dist=rnd()*16,lp=(lane+10)/20;while(dist<len){let p=el.getPointAtLength(dist),p1=el.getPointAtLength(Math.min(len,dist+2)),a=Math.atan2(p1.y-p.y,p1.x-p.x);
    let width=(idx?24:37)*(.76+.24*Math.sin(dist*.002+.3));let shift=((lp-.5)*2)*width+2.7*Math.sin(.014*dist+lane*.4)+(rnd()-.5)*3,dx=Math.cos(a),dy=Math.sin(a);
    let pi=Math.max(0,Math.min(8,Math.floor(4.2+(Math.abs(lp-.47)-.24)*12+1.1*Math.sin(dist*.009+lane*.21)+(rnd()-.5)*2.1)));
    dab(p.x-dy*shift,p.y+dx*shift,a+.04*Math.sin(dist*.04),11+rnd()*17,2+rnd()*3,pals[pi],Math.sin(dist*.025)*2.3,rnd()<.38?'rgba(228,226,183,.55)':null);dist+=11+rnd()*10;
  }}}
 const stars=[[272,300,13],[450,461,13],[912,252,14],[1165,192,11],[1450,395,14],[292,497,8],[1340,201,32]];
 for(const [x,y,r] of stars){for(let n=0;n<400;n++){let a=rnd()*tau,rad=(1.28+Math.sqrt(rnd())*3.1)*r;let oval=1+.07*Math.sin(a*3);let X=x+Math.cos(a)*rad*oval,Y=y+Math.sin(a)*rad;let col=rad<r*2.3?['#fdda56','#edc743','#c1b960']:['#77a4a6','#82ada7','#b1c59e','#72a2ae'];dab(X,Y,a+Math.PI/2,r*(.19+rnd()*.44),.8+r*.10*rnd(),col[Math.floor(rnd()*col.length)],.85,null)}}
 // Thin ochre scumbles on the illuminated crescent stop at its silhouette.
 g.save();let moon=new Path2D('M1370 122 C1302 106 1250 157 1256 211 C1262 271 1319 302 1375 273 Q1321 270 1306 226 C1287 179 1318 136 1370 122Z');g.clip(moon);
 g.fillStyle='#e7ad43';g.fillRect(1240,100,163,205);
 for(let j=0;j<1350;j++){let x=1245+rnd()*150,y=110+rnd()*188;dab(x,y,Math.atan2(y-193,x-1351)+Math.PI/2,7+12*rnd(),1+3*rnd(),['#f4cf61','#fce3a1','#c18b3f','#ffe081','#dfaf43'][j%5],1,'rgba(255,228,158,.6)')}g.restore();
};
