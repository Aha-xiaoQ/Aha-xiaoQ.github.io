/* Cut new scenic plates in the coordinate system of the animated road.
 * Static ink is cached once. Moving practicals inherit each scene's clock. */
(()=>{
'use strict';
const {circle,rect,line,path,ellipse}=K;
const TAU=Math.PI*2;
const gradient=(c,y1,y2,stops)=>K.gradient(c,[0,y1],[0,y2],stops);
const poly=(c,pts,fill,edge,w=1)=>line.call(K,c,pts,edge||null,w,true,fill);
function rng(seed){return ()=>((seed=(Math.imul(seed,1664525)+1013904223)>>>0)/4294967296);}
function hatch(c,contour,n,draw){
  c.save();c.clip(new Path2D(contour));for(let i=0;i<n;i++)draw(i);c.restore();
}
function etch(c,x,y,length,angle,width,col){
  c.strokeStyle=col;c.lineWidth=width;c.beginPath();c.moveTo(x,y);
  c.quadraticCurveTo(x+Math.cos(angle+.12)*length*.42,y+Math.sin(angle+.12)*length*.42,x+Math.cos(angle)*length,y+Math.sin(angle)*length);c.stroke();
}
function matte(c,x,y,r,stops){const g=c.createRadialGradient(x,y,0,x,y,r);for(const [pos,val] of stops)g.addColorStop(pos,val);return g;}

// A two-colour relief-printed book jacket and its die-cut specimen aperture.
P.introRoom=function(c,t){
 c.drawImage(K.cached('r8-edition-cover',d=>{
  const rnd=rng(61008),ink='#102d33',brass='#d5ae67',paper='#f2e4bf';
  rect(d,0,0,1600,900,ink);
  const feather='M-48 818 Q94 554 216 260 Q245 164 241 42 Q166 102 105 214 Q14 411 -48 818Z';
  path(d,feather,'#1f4143');hatch(d,feather,100,i=>{
   path(d,'M-24 '+(917-i*9)+' Q72 '+(730-i*8)+' 245 '+(637-i*8),null,'#526254',1.5);});
  for(let j=0;j<9000;j++){const x=rnd()*1600,y=rnd()*900;etch(d,x,y,1+rnd()*8,-.28,.5+rnd()*.5,j%5?'#233d3e':'#43514c');}
  rect(d,30,30,1540,840,null,'#ae8c58',1.8);rect(d,39,39,1522,822,null,'#69745f',.8);
  const opening='M682 765 L682 418 C682 199 869 83 1117 83 C1354 83 1550 222 1550 431 L1550 765Z';
  path(d,opening,paper,brass,4);
  d.save();d.clip(new Path2D(opening));rect(d,675,80,890,714,gradient(d,83,780,[[0,'#f7edd1'],[.6,'#edddb4'],[1,'#d0b98e']]));
  for(let j=0;j<1800;j++){let x=675+rnd()*890,y=84+rnd()*720;etch(d,x,y,1+rnd()*9,-.17,.65,'rgba(120,95,55,.17)');}
  for(let j=0;j<21;j++){d.beginPath();d.ellipse(1116,447,359+j*4.1,285+j*3.1,0,3.5,5.98);d.lineWidth=j%5===0?1.7:.75;d.strokeStyle=j%5===0?'#a58b66':'#beab80';d.stroke();}
  for(let j=0;j<78;j++){let a=Math.PI*(1.05+j/86),co=Math.cos(a),si=Math.sin(a),short=j%5?5:12;line(d,[[1116+co*374,447+si*304],[1116+co*(374+short),447+si*(304+short)]],'#9d8865',j%5?.6:1.1);}
  d.restore();
  rect(d,95,108,55,4,'#c85b42');K.text(d,'骑 行 艺 术 通 史',94,92,22,brass,'left','serif');
  K.text(d,'鹈鹕',86,315,153,paper,'left','serif','700');K.text(d,'六千年',97,438,100,paper,'left','serif','600');
  K.text(d,'A PELICAN ON THE ROAD',102,493,19,brass,'left','mono');
  line(d,[[98,543],[522,543]],'#ae8e59',1);K.text(d,'卷 一',100,809,24,brass,'left','serif');
  K.text(d,'图一　骑行摹本',1120,814,21,'#d9bc83','center','serif');
  for(let j=0;j<28;j++){const x=759+j*29;line(d,[[x,762],[x,754-(j%5?0:5)]],'#99825b',1);}
 }),0,0);
 c.save();c.globalAlpha=K.ease((t-.12)/.36);K.text(c,'人类自古以来就痴迷于',99,606,33,'#f0e1bf','left','serif');K.text(c,'画鹈鹕骑自行车。',99,656,39,'#f6e8c9','left','serif','600');c.restore();
 c.save();c.globalAlpha=K.ease((t-1.82)/.32);K.text(c,'早在自行车被发明之前。',99,723,27,'#e8b26f','left','serif');c.restore();
 c.save();c.beginPath();c.rect(684,400,918,365);c.clip();
 const road=[];for(let x=682;x<=1600;x+=8)road.push([x,P.longFloor(x-1600,t)]);line(c,road,'#927e60',1.6);c.restore();
};

// The pixel chapter is a playable-looking harbour at the end of the mail run.
// Compose on a 400 x 225 lattice, including the water's genuine reflection.
function harbour(c){
 const art=P.makeCanvas(400,225),g=art.getContext('2d'),r=rng(3571);
 const R=(x,y,w,h,col)=>{g.fillStyle=col;g.fillRect(Math.round(x),Math.round(y),Math.round(w),Math.round(h));};
 function pixLine(x,y,ex,ey,col,width=1){let n=Math.max(Math.abs(ex-x),Math.abs(ey-y),1);for(let k=0;k<=n;k++)R(x+(ex-x)*k/n,y+(ey-y)*k/n,width,width,col);}
 const bands=['#383660','#53406e','#754777','#995179','#bd607b','#da757d','#ed9887','#ffd09b'];
 for(let j=0;j<8;j++)R(0,j*16,400,16,bands[j]);
 for(let iy=-25;iy<=25;iy++){let half=Math.floor(Math.sqrt(625-iy*iy));R(263-half,93+iy,half*2,1,iy%7===0?'#ffcc94':'#ffdda0');}
 function cloud(x,y,w){
  for(let j=0;j<5;j++){let h=1+Math.floor(r()*4);R(x+j*w*.12,y-j*.8,w*(.61-j*.07),h,'#d78a93');R(x+j*w*.12,y-j*.8,w*(.53-j*.07),1,'#efae9e');}
 }
 for(let j=0;j<16;j++)cloud(r()*410,22+r()*84,18+r()*62);
 function skyline(base,span,fill,detail){
  for(let x=-7;x<407;){let w=3+Math.floor(r()*12),h=2+Math.floor(r()*span);R(x,base-h,w,h,fill);
   if(h>span*.6){R(x+1,base-h-2,w-2,2,fill);if(w>5)R(x+3,base-h-4,2,2,fill);}
   if(detail)for(let j=2;j<h-2;j+=4)for(let k=1;k<w-1;k+=3){if(r()>.55)R(x+k,base-h+j,1,1,'#d49489');}
   x+=w+Math.floor(r()*3);
  }
 }
 skyline(125,26,'#975a76',false);skyline(128,19,'#655474',true);
 function gantry(x,y,s){
  const G=(a,b,u,v,col,w=1)=>pixLine(x+a*s,y+b*s,x+u*s,y+v*s,col,w);
  for(const [dx,dy,ex,ey] of [[0,0,8,-36],[11,0,8,-36],[0,0,12,0],[6,-32,38,-46],[5,-29,38,-45],[-11,-37,8,-32],[7,-36,39,-47]])G(dx,dy,ex,ey,'#3c4963');
  for(let i=0;i<6;i++)G(8+i*5,-32-i*2,11+i*5,-33-i*2,'#e2a187');
  G(38,-46,38,-25,'#534963');G(38,-25,41,-25,'#534963');R(x+4*s,y-34*s,7*s,4*s,'#55566c');
 }
 gantry(79,128,.99);gantry(124,128,.68);gantry(320,128,.8);
 R(0,127,400,42,'#447086');
 const shore=g.getImageData(0,82,400,45);g.save();g.beginPath();g.rect(0,129,400,42);g.clip();
 let reflected=P.makeCanvas(400,45),rc=reflected.getContext('2d');rc.putImageData(shore,0,0);g.globalAlpha=.39;
 for(let j=0;j<37;j++){let drift=Math.round(2*Math.sin(j*1.8));g.drawImage(reflected,0,44-j,400,1,drift,128+j,400,1);}g.restore();
 for(let i=0;i<900;i++){const y=130+r()*37,x=r()*400;R(x,y,1+(y-127)*r()*.32,1,(x>237&&x<287&&r()>.4)?'#efb68d':r()>.57?'#82a8a5':'#557a8b');}
 // Lighthouse with gallery, keeper's cottage and seaward rivet pier.
 const lx=348;for(let j=0;j<37;j++){let w=3+Math.floor(j/9);R(lx-w,110+j,w*2,1,Math.floor(j/9)%2?'#be655e':'#ead7b4');R(lx+w-2,110+j,2,1,'#946b78');}
 R(lx-6,106,12,2,'#343953');R(lx-4,101,8,5,'#ffe295');R(lx-5,99,10,2,'#343953');R(lx-2,97,4,2,'#343953');R(lx,94,1,4,'#343953');R(lx,118,2,3,'#40526a');R(lx+10,140,20,7,'#b2aba0');for(let j=0;j<7;j++)R(lx+8+j,139-j,23-j*2,1,'#764f61');
 for(let k=0;k<9;k++){let x=308+k*11;R(x,149,2,19,'#3e5265');pixLine(x,164,x+11,150,'#49556d');}R(304,148,96,3,'#655768');R(303,146,97,2,'#dfac85');
 for(let k=0;k<22;k++){let x=k*22;R(x,168,18,9,'#374957');R(x+1,167,15,2,'#746979');for(let n=0;n<4;n++)R(x+2+n*4,171,1,4,'#b48b77');}
 for(let k=0;k<30;k++){let x=k*15;R(x,179,13,2,'#cfa68c');}R(0,181,400,44,'#363f58');
 c.save();c.imageSmoothingEnabled=false;c.drawImage(art,0,0,1600,900);c.restore();
}

// East-coast woodblock. Cut every crest and sail into a small set of blocks.
function coast(c){
 const r=rng(6002),sky=gradient(c,0,524,[[0,'#193f63'],[.18,'#66999e'],[.46,'#d1c7a7'],[.80,'#edbc97'],[1,'#f6ddae']]);
 rect(c,0,0,1600,900,'#e8d5af');rect(c,0,0,1600,545,sky);
 circle.call(K,c,376,299,89,'#d46748');hatch(c,'M287 299a89 89 0 1 0 178 0a89 89 0 1 0 -178 0',66,i=>{
  let y=219+i*2.6;line(c,[[261+r()*50,y],[331+r()*94,y-.2]],'#df9977',.75);});
 const mountain='M381 526 Q535 494 674 424 Q787 359 869 262 L944 159 L966 153 L986 158 Q1082 293 1231 387 Q1382 471 1600 502 L1600 553 H381Z';
 path(c,mountain,'#b77967','#4d6670',1.7);
 hatch(c,mountain,800,()=>{
  let x=348+r()*1310,y=166+r()*393,dx=(x-963)*.105;
  line(c,[[x,y],[x+dx*.42,y+16],[x+dx,y+20+r()*43]],r()>.51?'#cc9378':'#9d6a69',.7+r()*2);
 });
 path(c,'M823 313 Q888 234 944 159 L966 153 L986 158 L1073 267 L1023 236 L1033 260 L1000 222 L1003 247 L970 200 L957 226 L949 216 L914 260 L923 231Z','#f6e3bb','#776e69',.9);
 path(c,'M0 484 Q117 415 246 462 T540 459 Q494 511 435 524 H0Z','#5a7d79');
 rect(c,0,502,1600,201,gradient(c,501,704,[[0,'#c8cead'],[.16,'#9ebcb1'],[.56,'#5b969e'],[1,'#2e6c7f']]));
 for(let j=0;j<1250;j++){let x=r()*1650,y=502+r()*201,length=(y-495)*(.10+r()*.25);path(c,'M'+x+' '+y+' q'+length*.42+' -2 '+length+' -.2',null,j%4?'rgba(220,220,177,.53)':'rgba(48,99,115,.60)',.7+r()*.9);}
 for(const [x,y,s] of [[171,550,.81],[551,538,.48],[1040,563,.95],[1212,533,.32]]){c.save();c.translate(x,y);c.scale(s,s);
  path(c,'M-40 2 Q6 8 49 0 Q31 17 -21 17Z','#465654');line(c,[[2,5],[2,-77]],'#4b5758',2);
  path(c,'M7 -74 Q26 -54 45 -12 Q30 -8 7 -10Z','#f4deaf','#7a8173',1.4);
  for(let j=1;j<8;j++){let yy=-74+j*8.7;line(c,[[8,yy],[9+j*4.5,yy+1]],'#bdab8b',.9);}
  path(c,'M-39 21 q43 -3 85 -1',null,'#e0d8ad',2);c.restore();}
 // A close, overhanging, stratified sea cliff creates a strong diagonal.
 const cliff='M0 278 Q94 281 162 343 L194 395 L271 411 L294 461 L357 476 L380 538 L417 547 L461 614 L0 724Z';
 path(c,cliff,'#315d64','#224952',3);
 hatch(c,cliff,128,i=>{let y=293+i*3;path(c,'M-16 '+y+' Q75 '+(y-23)+' 148 '+(y+18)+' T299 '+(y+76)+' Q368 '+(y+95)+' 476 '+(y+127),null,i%5?'#427277':'#77918b',i%5?1:2);});
 path(c,'M0 681 Q198 645 386 654 Q673 702 931 675 Q1224 646 1600 678 L1600 900 H0Z','#c9ae80','#546961',2);
 for(let j=0;j<1050;j++){let x=r()*1600,y=709+r()*199;etch(c,x,y,2+r()*13,-.08,.65,j%5?'#b7a27c':'#deca9d');}
 M.teaHouse(c,192,668,.71);
}

// A black-and-white light well, built as a set the film projector can light.
function cinema(c,base){
 base(c);
 const light='M302 700 L309 581 L903 29 Q1097 80 1324 210 L1305 550 L657 745Z';
 c.save();c.beginPath();c.rect(325,20,1254,719);c.clip();
 rect(c,325,20,1254,719,gradient(c,20,743,[[0,'#11171e'],[.65,'#37404a'],[1,'#697174']]));
 path(c,light,gradient(c,50,720,[[0,'#afa99b'],[.43,'#d4cbb5'],[1,'#87938d']]));
 hatch(c,light,42,i=>{let y=25+i*17.4;line(c,[[321,y],[1580,y-121]],'rgba(67,72,77,.17)',1);
  for(let j=0;j<8;j++){let x=340+j*158+(i%2)*77;line(c,[[x,y-(x-325)*.096],[x+2,y+17-(x-325)*.096]],'rgba(67,72,77,.12)',.8);}});
 function arch(x,y,s){
  c.save();c.translate(x,y);c.transform(s,-.13*s,0,s,0,0);
  const gothic='M-77 5 V-145 Q-76 -206 0 -247 Q74 -204 77 -145 V5Z';
  path(c,gothic,'#26343b','#171d25',19);path(c,gothic,null,'#cdc4ad',3);
  c.save();c.clip(new Path2D(gothic));rect(c,-77,-247,154,251,gradient(c,-247,5,[[0,'#d8d6bd'],[.52,'#91a5a0'],[1,'#587178']]));
  for(let j=-9;j<10;j++){line(c,[[j*25,-255],[j*25+122,10]],'#687a78',1.6);line(c,[[j*25,-255],[j*25-127,10]],'#687a78',1.3);}
  for(const col of [-50,0,50]){path(c,'M'+(col-23)+' 6 V-116 Q'+(col-23)+' -160 '+col+' -180 Q'+(col+23)+' -159 '+(col+23)+' -116 V6',null,'#46595a',5);}
  circle.call(K,c,0,-191,22,null,'#455756',5);for(let i=0;i<5;i++)circle.call(K,c,Math.sin(i*TAU/5)*9,-191-Math.cos(i*TAU/5)*9,8.5,null,'#546866',2.4);
  c.restore();path(c,'M-90 5 H90 L99 13 H-100Z','#bac0aa','#26353a',2);c.restore();
 }
 arch(530,331,.75);arch(952,323,1.30);arch(1405,360,1.65);
 path(c,'M349 761 L1513 341 L1585 337 L1584 742Z','#353e46');
 for(let j=0;j<10;j++){let x=365+j*133,y=747-j*45;poly(c,[[x,y],[x+137,y-44],[x+137,y-26],[x,y+19]],'#78827e','#39464a',1);line(c,[[x,y],[x+137,y-44]],'#c5c2ac',2.2);}
 // A handrail silhouettes the vanishing direction, below the shadow's head.
 path(c,'M337 616 L1532 227',null,'#293337',5);
 for(let j=0;j<10;j++){let x=362+j*129,y=609-j*42;line(c,[[x,y],[x,y+124]],'#39464a',3.4);}
 c.restore();
}

// A painted 1980s shopping arcade seen from the tiled atrium, with a real
// reflection of its skylight and kiosk in the lower half.
function mall(c,base){
 base(c);
 const cloth=P.makeCanvas(305,240),clothInk=cloth.getContext('2d');
 clothInk.drawImage(c.canvas,1182,374,305,240,0,0,305,240);
 c.save();c.beginPath();c.rect(0,0,1600,550);c.clip();
 rect(c,0,0,1600,551,gradient(c,0,550,[[0,'#141738'],[.27,'#59416f'],[.62,'#c77999'],[1,'#ffc294']]));
 const rnd=rng(706);for(let i=0;i<135;i++){let x=rnd()*1600,y=rnd()*370;circle.call(K,c,x,y,.5+rnd()*1.2,'#e9d4d2');}
 circle.call(K,c,956,329,116,gradient(c,213,445,[[0,'#ffedc1'],[.5,'#f6b58f'],[1,'#de7796']]));
 for(let z=0;z<12;z++){let x=730+z*42,y=432-(z%5)*14;rect(c,x,y,26+(z%3)*6,550-y,'#895682');}
 const vp=[920,429];
 for(const left of [true,false]){
  c.save();if(!left){c.translate(1600,0);c.scale(-1,1);}
  path(c,'M0 51 L746 373 V516 L0 665Z','#665074');
  for(const [s,e,col,w] of [[42,369,'#c19ba5',17],[77,387,'#f1c1b4',6],[206,422,'#322f58',13],[225,432,'#edb29e',4],[410,477,'#382f59',11],[446,488,'#f8bea6',5],[522,509,'#503758',12]])line(c,[[0,s],[749,e]],col,w);
  for(let j=0;j<12;j++){let u=1-Math.exp(-j*.226),x=765*u,y=72+(379-72)*u,bottom=619+(512-619)*u,w=49*(1-u)+3;
   rect(c,x-w*.3,y,w,bottom-y,gradient(c,y,bottom,[[0,'#efbaa9'],[.6,'#bf87a1'],[1,'#9b7597']]));rect(c,x+w*.32,y,w*.32,bottom-y,'#926c8f');
   let gap=(765*(1-Math.exp(-(j+1)*.226))-x)-w;
   if(gap>5){let xx=x+w*.65,yt=284+144*u,yb=488+7*u;rect(c,xx,yt,gap,yb-yt,'#333856');rect(c,xx+1,yt+2,gap*.22,yb-yt-4,'#7a7595');rect(c,xx+3,yt+4,gap*.05,yb-yt-10,'#bbb1b0');line(c,[[xx,yt-4],[xx+gap,yt+gap*.16-4]],'#ffa6ae',4);}
  }
  c.restore();
 }
 // Curved greenhouse glazing overhead in perspective.
 for(let j=0;j<9;j++){let u=1-Math.exp(-j*.31),x=K.lerp(-180,713,u),x2=K.lerp(1830,1070,u),y=K.lerp(66,358,u),cy=K.lerp(-396,264,u);
  path(c,'M'+x+' '+y+' Q'+((x+x2)/2)+' '+cy+' '+x2+' '+y,null,'#573f68',Math.max(2,16*(1-u)));
  path(c,'M'+x+' '+(y+5)+' Q'+((x+x2)/2)+' '+(cy+5)+' '+x2+' '+(y+5),null,'#edb3ae',Math.max(.8,3.5*(1-u)));}
 for(const x of [32,411,825,1170,1556])line(c,[[x,-20],vp],'rgba(79,66,100,.73)',4);
 M.palmFine(c,369,547,.84,-1);M.palmFine(c,752,551,.41,1);
 c.restore();
 c.save();c.clip(new Path2D('M1189 597 Q1199 550 1230 530 L1287 502 L1292 456 L1372 456 L1378 497 Q1418 514 1443 534 Q1471 561 1482 597Z'));c.drawImage(cloth,1182,374);c.restore();
}

// Build the night town around the actual star destination. Windows below
// are handed back to the original light cue, so the town answers in sequence.
function hillTown(c,base){
 base(c);const r=rng(1889),dark='#122d49';
 const land='M-20 637 Q99 590 242 608 Q358 555 460 574 Q551 552 666 592 Q832 568 956 595 Q1081 568 1259 594 Q1411 545 1620 582 V912 H-20Z';
 path(c,land,'#253f64');
 hatch(c,land,5100,()=>{let x=r()*1650,y=558+r()*352;etch(c,x,y,5+r()*21,-.36+.43*Math.sin(x*.007+y*.032),1.4+r()*2.2,['#344e73','#406380','#1c3859','#57758a'][Math.floor(r()*4)]);});
 M.nightWindows=[];
 function house(x,y,w,h,depth){
  const roof=h*(.36+r()*.26),dx=w*.21,hi=['#8c8b88','#929595','#70939b','#9b8d82','#748699'][Math.floor(r()*5)];
  const shadow=['#405d72','#485570','#53617c'][Math.floor(r()*3)];
  poly(c,[[x,y],[x,y-h],[x+w*.43,y-h-roof],[x+w*.8,y-h],[x+w*.8,y]],hi,dark,1.8);
  poly(c,[[x+w*.8,y],[x+w*.8,y-h],[x+w+dx,y-h-14],[x+w+dx,y-12]],shadow,dark,1.5);
  const left=x-5,right=x+w*.83,peak=x+w*.43;
  poly(c,[[left,y-h],[peak,y-h-roof-4],[peak+dx+w*.2,y-h-roof-15],[right+dx+w*.18,y-h-12],[right,y-h+3],[peak,y-h-roof+3]],'#784f53','#213a53',2.4);
  for(let j=0;j<22;j++){let u=r(),v=r(),a=peak+u*(right-peak)+v*(dx+w*.19),b=y-h-roof+u*roof-v*12;etch(c,a,b,3+r()*9,.87,1+r()*1.3,j%3?'#a06f60':'#c59a71');}
  line(c,[[left,y-h],[peak,y-h-roof-4],[peak+dx+w*.2,y-h-roof-15]],'#d0ac80',1.4);
  for(let k=0;k<2;k++){let xx=x+w*(.2+k*.30),yy=y-h*.65;
   rect(c,xx,yy,Math.max(3,w*.107),Math.max(5,h*.18),k%2?'#dfb966':'#1e3c56');line(c,[[xx-1,yy+h*.18],[xx+w*.13,yy+h*.18]],dark,1);
   if(!k)M.nightWindows.push({x:xx,y:yy,w:w*.107,depth});
  }
  if(w>44){rect(c,x+w*.39,y-h*.44,w*.14,h*.44,'#34465d');rect(c,x+w*.52,y-h*.44,1.7,h*.44,'#b1a78c');}
 }
 for(const [count,baseY,scale,seed] of [[33,636,.44,4],[25,670,.61,16],[19,711,.9,22],[12,747,1.1,36]]){
  let x=-56;for(let j=0;j<count;j++){const w=(53+r()*30)*scale,h=(45+r()*27)*scale;let yy=baseY-11*Math.sin(x*.0103+seed);
   if(Math.abs(x-1095)>53||baseY<665)house(x,yy,w,h,scale<.85);x+=1665/count;}
 }
 // Façade, lancets, clock and uneven slate spire fit the original landing point.
 path(c,'M1030 710 V646 L1077 614 L1080 543 L1100 471 L1123 541 L1125 627 L1165 650 V710Z','#6c777c',dark,2.4);
 path(c,'M1074 547 L1100 469 L1126 542 L1113 538 L1099 531Z','#1d3759','#879091',1.3);
 path(c,'M1100 469 L1101 451 M1094 459 H1108',null,'#cab581',1.4);
 path(c,'M1020 649 L1074 609 L1080 619 L1028 655Z','#273f56','#b09a7e',1.4);
 for(const [xx,y,w] of [[1042,650,13],[1062,651,13],[1130,647,12],[1147,653,9],[1092,604,13]]){path(c,'M'+xx+' '+(y+29)+' V'+(y+7)+' q'+(w*.48)+' -14 '+w+' 0 v22Z','#e0bd72',dark,1.5);line(c,[[xx+w*.5,y],[xx+w*.5,y+29]],'#766d58',1.3);}
 circle.call(K,c,1100,573,15,'#dbb36a','#1f3952',2);circle.call(K,c,1100,573,11,'#edcf88','#68665e',1);
 for(let i=0;i<12;i++){let a=i*TAU/12;line(c,[[1100+9*Math.sin(a),573+9*Math.cos(a)],[1100+11*Math.sin(a),573+11*Math.cos(a)]],dark,.9);}
 line(c,[[1100,565],[1100,573],[1106,576]],dark,1.6);
 path(c,'M-10 762 Q247 728 601 749 Q841 763 1072 739 Q1374 724 1610 745 V905 H-10Z','#263d4d');
 for(let j=0;j<1400;j++){let x=r()*1625,y=762+r()*145;etch(c,x,y,5+r()*22,-.14+.3*Math.sin(x*.009+y*.032),1+r()*2.2,['#3c5357','#575d52','#748067','#213b4b'][j%4]);}
}

function bridgePromenade(c){
 const r=rng(1779);rect(c,0,0,1600,900,gradient(c,0,711,[[0,'#465d89'],[.28,'#ba90a4'],[.48,'#f4b389'],[.68,'#fae1b3'],[1,'#829a99']]));
 circle.call(K,c,735,303,56,matte(c,735,303,56,[[0,'#ffefd0'],[.78,'#ffe8b5'],[1,'#fad6a8']]));
 for(let layer=0;layer<2;layer++){let x=-20,level=475-layer*16;while(x<1640){let w=18+r()*45,h=12+r()*83;rect(c,x,level-h,w,h,layer?'#9b8494':'#ab97a2');if(r()>.42)rect(c,x+w*.19,level-h-5,w*.67,6,'#aaa0a4');x+=w*.86;}}
 rect(c,0,466,1600,227,gradient(c,466,700,[[0,'#a5a8ab'],[.25,'#c1b3a8'],[1,'#507d88']]));
 for(let j=0;j<1850;j++){let x=r()*1600,y=469+r()*214,len=4+r()*(y-435)*.17;
   etch(c,x,y,len,-.01,.8+r()*2,Math.abs(x-735)<(y-465)*.73&&r()>.3?'#f8cfa3':j%3?'#a9b5b1':'#879da4');}
 for(const x of [130,1020]){const y=278;path(c,'M'+(x-61)+' 538 L'+(x-39)+' '+y+' L'+(x+40)+' '+y+' L'+(x+64)+' 538Z','#677480');
  rect(c,x-23,y+45,48,153,'#d3a7a0');rect(c,x-34,y-24,69,27,'#5c6979');rect(c,x-21,y-45,44,22,'#717385');
  for(let j=0;j<7;j++)line(c,[[x-36,y+9+j*27],[x+34,y+9+j*27]],'#a49498',2);}
 path(c,'M-80 370 Q35 371 130 268 Q575 586 1020 266 Q1330 494 1620 338',null,'#657181',6);
 for(let j=1;j<35;j++){let u=j/35,x=130+890*u,y=268+(586-268)*2*(1-u)*u;line(c,[[x,y],[x,485-x*.016]],'#858390',1.4);}
 poly(c,[[-10,487],[1610,460],[1610,481],[-10,509]],'#4e636f','#89908c',2.3);
 for(let j=0;j<50;j++){let x=j*32;line(c,[[x,503-x*.016],[x+16,484-x*.016],[x+32,503-x*.016]],'#ac9a95',1.3);}
 path(c,'M0 669 H1600 V900 H0Z',gradient(c,669,900,[[0,'#ceab90'],[.32,'#ba9883'],[1,'#8a8190']]));
 for(let j=0;j<8;j++)line(c,[[0,710+j*j*3.3],[1600,710+j*j*3.3]],'#a78a7c',1.1);
 for(let j=0;j<18;j++){let x=j*140-300;line(c,[[x,902],[800+(x-800)*.33,701]],'#a99184',1.2);}
 for(let j=0;j<17;j++){let x=j*100;rect(c,x,619,5,83,'#344f60');rect(c,x-2,615,9,6,'#d4a98c');}
 line(c,[[0,622],[1600,622]],'#455c69',3);line(c,[[0,646],[1600,646]],'#737c81',2);line(c,[[0,703],[1600,703]],'#dbc3a1',2);
}

// A fjord at red hour, painted on coarse card. Distort the very same card
// and bicycle later when the sound wave crosses the bridge.
function fjord(c){
 const r=rng(735),warm=['#c74e38','#9c3341','#e46d42','#e99558','#eaad77','#a94845','#673448','#ed824b'];
 rect(c,0,0,1600,900,'#ae4a40');
 const pulse=(x,k)=>-120+k*11+75*Math.sin(x*.0035+k*.062)+24*Math.cos(x*.007-k*.13);
 for(let j=0;j<70;j++){const upper=[],lower=[];for(let x=-20;x<1650;x+=22){const y=pulse(x,j);upper.push([x,y]);lower.push([x,y+15+4*Math.sin(j+x*.005)]);}
  poly(c,upper.concat(lower.reverse()),warm[Math.floor((j%13)*.55)%8]);}
 for(let j=0;j<31000;j++){
  let x=r()*1610-5,k=r()*71,y=pulse(x,k),a=Math.atan((pulse(x+3,k)-y)/3);
  const s=.09+r()*.36;c.globalAlpha=s;etch(c,x,y,3+r()*20,a,.7+r()*2.3,j%4?'#ffbd80':'#502a43');
 }c.globalAlpha=1;
 const shore='M-30 547 Q153 441 300 465 Q502 490 666 425 Q788 371 922 403 Q1126 462 1243 382 Q1395 324 1620 348 V900 H-30Z';
 path(c,shore,'#39596a','#353e55',4);
 hatch(c,shore,680,()=>{let y=406+r()*510,x=r()*1620;
  path(c,'M'+x+' '+y+' q31 -17 93 -5 t105 -2',null,['#809185','#596e72','#425977','#586e77'][Math.floor(r()*4)],2+r()*4);});
 const water='M895 457 Q1090 455 1186 436 Q1298 410 1380 409 Q1568 401 1604 427 V900 H540 Q653 693 1047 598 Q1206 539 1124 504 Q1103 483 895 457Z';
 path(c,water,'#153f58','#a5aa82',3);
 hatch(c,water,7500,()=>{let x=540+r()*1070,y=409+r()*500;const angle=-.22*Math.cos(x*.005+y*.023)+.11;
  etch(c,x,y,4+r()*54,angle,.8+r()*3.3,['#305968','#7c8d79','#b09e76','#1e475d','#3b6471'][Math.floor(r()*5)]);});
 for(let j=0;j<8;j++){const x=1000+r()*480,y=460+r()*90,s=.4+r()*.62;poly(c,[[x-26*s,y],[x+26*s,y-2],[x+12*s,y+6],[x-13*s,y+7]],'#263f4c');line(c,[[x,y],[x-1,y-30*s]],'#455766',1.4);poly(c,[[x+1,y-29*s],[x+17*s,y-3],[x+2,y-5]],'#c5b08c');}
 const deck='M-10 906 V585 L557 428 L1294 908Z';path(c,deck,'#a97555','#704d49',3);
 hatch(c,deck,5200,()=>{let x=r()*1320,y=430+r()*490,a=Math.atan2(y-422,x-569);
  etch(c,x,y,6+r()*28,a,1+r()*3.2,jitterColour(r));});
 function jitterColour(rand){return ['#98664e','#c98d62','#77544d','#b17d59','#d49b6f'][Math.floor(rand()*5)];}
 for(let k=0;k<18;k++){let end=-730+k*156;line(c,[[561,429],[end,914]],'#795949',1.7);}
 for(const [y0,y1,w,col] of [[603,428,8,'#5b4845'],[670,439,9,'#684c43'],[737,446,7,'#795247']])line(c,[[-12,y0],[564,y1]],col,w);
 for(let k=0;k<9;k++){let u=k/9,x=590*u,y=599-u*175;line(c,[[x,y],[x+1,y+126*(1-u)+11]],'#715349',4.3-2*u);}
}

// Mahogany cheeks, hammered enamel and a deep brass eyepiece surround a
// working X/Y tube. Auxiliary waveforms remain registered to the voltages.
function instrument(c){
 const r=rng(507);rect(c,0,0,1600,900,gradient(c,0,900,[[0,'#141a21'],[.49,'#293239'],[1,'#13181c']]));
 // Bench and wall are deliberately darker than the face.
 for(let j=0;j<230;j++){let y=834+r()*67;etch(c,r()*1600,y,13+r()*124,0,.5+r()*.95,'#38332f');}
 M.round(c,40,123,1520,710,25,gradient(c,123,833,[[0,'#807060'],[.02,'#313643'],[.96,'#141a22'],[1,'#4e4840']]),'#101820',5);
 M.round(c,66,143,1468,667,14,gradient(c,143,810,[[0,'#516062'],[.23,'#404c50'],[.61,'#304044'],[1,'#29383c']]),'#87908a',2);
 for(let i=0;i<23000;i++){let x=73+r()*1457,y=150+r()*649;rect(c,x,y,1+r()*2,1,r()>.5?'rgba(191,193,166,.075)':'rgba(13,22,26,.18)');}
 for(const x of [35,1513]){rect(c,x,159,50,634,gradient(c,159,791,[[0,'#6d463c'],[.3,'#995c44'],[.8,'#683f35'],[1,'#492e2b']]));
  for(let j=0;j<85;j++){let xx=x+2+r()*45,yy=162+r()*590;etch(c,xx,yy,9+r()*47,1.57,.8,j%2?'#795040':'#ab6b49');}}
 for(const x of [98,1502])for(const y of [172,776])M.screw(c,x,y,7);
 for(const [x,n] of [[122,'X'],[1142,'Y']]){
  M.round(c,x-13,306,360,187,15,'#1b282b','#a99b78',1.5);M.round(c,x,321,334,150,5,'#0f241f','#536459',2);
  for(let j=0;j<13;j++)line(c,[[x+12+j*25,330],[x+12+j*25,463]],'#24453a',.8);
  for(let j=0;j<6;j++)line(c,[[x+8,335+j*25],[x+325,335+j*25]],'#29473c',.8);
  K.text(c,'输入电压　/　'+n,x+2,292,18,'#d6c8a1','left','serif');
  rect(c,x,510,334,119,'#c5bda2','#786f5a',2);rect(c,x+9,519,316,101,null,'#9c957d',1);
 }
 K.text(c,'横向偏转',141,548,15,'#585e50','left','serif');K.text(c,'同步校验',1160,548,15,'#585e50','left','serif');
 for(const x of [153,380,1168,1384]){for(let j=0;j<11;j++)M.round(c,x+j*8,187,4,58,2,'#263235','#5e6861',.6);}
 const ring=K.gradient(c,[540,205],[1023,733],[[0,'#5e6056'],[.20,'#dbbf87'],[.31,'#a18968'],[.48,'#484b46'],[.74,'#9b8463'],[1,'#cfb383']]);
 circle.call(K,c,800,480,291,'#172124','#949684',2);circle.call(K,c,800,480,284,ring,'#c8b388',2);circle.call(K,c,800,480,268,'#162725','#544f46',6);
 circle.call(K,c,800,480,258,matte(c,800,480,258,[[0,'#174937'],[.72,'#0b3228'],[1,'#041e1a']]),'#76806b',1.5);
 c.save();c.beginPath();c.arc(800,480,257,0,TAU);c.clip();
 for(let j=-6;j<=6;j++){const q=j*43;line(c,[[800+q,221],[800+q,739]],j?'#26523d':'#57845c',j?.8:1);line(c,[[541,480+q],[1059,480+q]],j?'#26523d':'#57845c',j?.8:1);}
 for(let j=-28;j<29;j++){let dd=j*8.6;line(c,[[800+dd,477],[800+dd,483]],'#487354',.8);line(c,[[796,480+dd],[804,480+dd]],'#487354',.8);}
 path(c,'M549 385 Q601 223 770 218 Q616 251 581 377Z','rgba(206,225,177,.055)');c.restore();
 for(let j=0;j<16;j++){let a=j*TAU/16;M.screw(c,800+275*Math.cos(a),480+275*Math.sin(a),3.3);}
 for(const x of [96,1068]){M.round(c,x,689,437,41,7,'#162a26','#a69c7a',1);line(c,[[x+2,710],[x+435,710]],'#468465',1);}
 K.text(c,'阴极射线描迹仪',127,118,36,'#ddd0af','left','serif','700');K.text(c,'X / Y   ·   1950s',1480,115,19,'#c1b398','right','mono');
 M.socket(c,335,767,'X INPUT','#c6b975');M.socket(c,412,767,'Y INPUT','#c69864');
 circle.call(K,c,217,765,7,'#173b2d','#a08f65',2);K.text(c,'POWER',160,771,13,'#d2c29b','left','mono');
 for(let j=0;j<17;j++)M.round(c,1172+j*14,749,5,36,2,'#1c2b2f','#677169',.8);
}

function gallery(c){
 const rand=rng(211);rect(c,0,0,1600,900,gradient(c,0,900,[[0,'#15383d'],[.55,'#21464b'],[1,'#102c33']]));
 const plate=matte(c,805,372,685,[[0,'rgba(215,194,136,.34)'],[.7,'rgba(207,183,142,.09)'],[1,'rgba(207,183,142,0)']]);rect(c,0,0,1600,900,plate);
 // Tall oxblood velvet with individually shaded folds, brass pelmet above.
 for(const [x,w] of [[0,237],[1363,237]]){
  rect(c,x,0,w,694,'#4e343a');for(let j=0;j<10;j++){let xx=x+j*w/10;
   const g=K.gradient(c,[xx,0],[xx+w/10,0],[[0,'#462e35'],[.31,'#79464a'],[.62,'#975b57'],[1,'#50353b']]);path(c,'M'+xx+' 0 H'+(xx+w/10)+' Q'+(xx+w/10-6)+' 435 '+(xx+w/10+1)+' 680 Q'+(xx+w/20)+' 699 '+xx+' 679Z',g);}
 }
 rect(c,42,46,1516,7,'#b49964');rect(c,42,55,1516,2,'#e2c388');
 for(let j=0;j<22;j++){let x=271+j*51.2;rect(c,x,80,1,575,'rgba(218,196,147,.075)');}
 rect(c,260,129,1080,300,'#173d42','#c3a570',4);rect(c,272,142,1056,274,null,'#718078',1.5);
 K.text(c,'骑 行 艺 术 通 史',800,207,19,'#cfb37e','center','serif');
 K.text(c,'鹈鹕到场了吗？',800,286,59,'#f4e7c9','center','serif','600');
 K.text(c,'媒 体 见 面 会',800,358,23,'#cbbfa2','center','serif');
 for(const x of [250,1350]){path(c,'M'+x+' 451 v214',null,'#ac9266',3);}
 rect(c,0,680,1600,220,gradient(c,680,900,[[0,'#88745d'],[.45,'#b59875'],[1,'#5e564e']]));
 for(let j=0;j<1300;j++){let x=rand()*1640,y=683+rand()*220;etch(c,x,y,4+rand()*28,-.026,rand()*.6+.4,'rgba(65,46,41,.24)');}
 line(c,[[0,774],[1600,774]],'#d1b482',3);
}

const baseModern=M.bg;
M.bg=function(c,key,paint){
 if(key==='ukiyo-r8-sunshower')return baseModern(c,'r8-coastal-cut',coast);
 if(key==='pixel-r8-chime-courier')return baseModern(c,'r8-mail-harbour',harbour);
 if(key==='silent-r7-shadow-switch')return baseModern(c,'r8-light-well',g=>cinema(g,paint));
 if(key==='starry-r7-borrowed-light')return baseModern(c,'r8-village-lamplight',g=>hillTown(g,paint));
 if(key==='scream-r6-expression')return baseModern(c,'r8-vermilion-fjord',fjord);
 if(key==='vapor-r6-sunset'||key==='vapor-r8-bust-stage')return baseModern(c,'r8-tape-atrium',g=>mall(g,paint));
 return baseModern(c,key,paint);
};
const cached=K.cached;
K.cached=function(key,render){
 if(key==='interfaces-r8-portrait-lakeside')return cached.call(K,'r8-city-bridge',bridgePromenade);
 if(key==='press-room-r4-paper')return cached.call(K,'r8-exhibition-theatre',gallery);
 if(key==='scope-r2-round-crt')return cached.call(K,'r8-bench-oscillograph',instrument);
 return cached.call(K,key,render);
};
const caption=P.drawSceneNote;
const imprints={
  0:['塔西里岩画','SAHARAN ROCK ART','前 4000','#582c20','#bc7350'],
  2:['画像石','HAN STONE RUBBING','约 100','#ebe6c9','#aeb39b'],
  11:['星月夜','A SKY THAT PEDALS','1889','#f5da83','#e9d797'],
  12:['呐喊','THE SCREAM','1893','#f9d29f','#e8b77c'],
  13:['影子上楼','SILENT CINEMA','1922','#e1d9c3','#d6cbb1'],
  17:['磁带中庭','AFTER HOURS','2010s','#f8d3dc','#dfacc4']
};
P.drawSceneNote=function(c,i,a){if(i!==15&&!imprints[i])return caption.call(P,c,i,a);};
function imprint(c,i,l){
 const desc=imprints[i];if(!desc)return;
 const alpha=K.smoother((l-.27)/.85)*(1-K.smoother((l-3.35)/1.18));if(alpha<=0)return;
 c.save();c.globalAlpha=alpha;
 const [cn,en,date,fg,sub]=desc;let x=86,y=120;
 if(i>=11){
  const shadow=K.gradient(c,[0,0],[540,0],[[0,'rgba(16,28,37,.62)'],[.74,'rgba(16,28,37,.34)'],[1,'rgba(16,28,37,0)']]);rect(c,0,42,551,141,shadow);
 }
 if(i===2){line(c,[[x-12,68],[x-12,164]],sub,3);x+=12;}
 if(i===13){line(c,[[x-18,62],[x+186,62]],sub,1);line(c,[[x-18,171],[x+186,171]],sub,1);}
 K.text(c,cn,x,y,i===17?42:52,fg,'left','serif','600');
 K.text(c,en+'   /   '+date,x+2,y+35,17,sub,'left','mono');c.restore();
}
// Fit the date on the existing game header, leaving the wide sky to the action.
const chapter=P.scenes[15].draw;
P.scenes[15].draw=function(c,t,a){chapter.call(this,c,t,a);
 rect(c,97,186,247,48,'#183b49');
 K.text(c,'海港风铃',108,213,25,'#ffdfac','left','sans','700');K.text(c,'CHIME COURIER / 1980s',109,230,11,'#b0c1bb','left','mono');
 const lx=1391,ly=418,angle=Math.sin(t*.97)*.18;
 c.save();c.globalAlpha=.27;c.translate(lx,ly);c.rotate(angle);
 path(c,'M-4 -1 L-311 -34 L-314 4 L-4 2Z',K.gradient(c,[-312,0],[0,0],[[0,'rgba(255,221,147,0)'],[1,'#ffe2ab']]));c.restore();
};
// Open on a mechanical detail and pull back to the jacket before the punchline.
const director=P.finalDirector,renderRoad=director.renderRoad;
director.renderRoad=function(c,t){
 if(t>=1.65){renderRoad.call(director,c,t);const i=director.locate(t);imprint(c,i,director.local(i,t));return;}
 const u=K.smoother((t-.24)/1.41),zoom=K.lerp(2.55,1,u);
 const cx=K.lerp(1134,800,u),cy=K.lerp(541,450,u);
 c.save();c.translate(800,450);c.scale(zoom,zoom);c.translate(-cx,-cy);renderRoad.call(director,c,t);c.restore();
};
P.edition='r8-the-travelling-print';P.version='R8';
})();
