/* One articulated rider, twenty independently styled drawing treatments. */
(()=>{
  const TAU=Math.PI*2;
  const paints=[
    ['#69341e','#a74727','#743821','#b8592e','#c88047','#854124','#673b28'],
    ['#342a21','#f7e7b7','#dbb56d','#d48f2d','#c66f35','#397475','#3e4137'],
    ['#e6ddc2','#dbd3b9','#8e8978','#e4dcc1','#aaa693','#e0d7bb','#d0c7ac'],
    ['#282822','#f7f0dd','#d8d4c8','#f4e4c6','#e6c8a0','#282822','#34322d'],
    ['#363b32','#f0e8d2','#b6b8a5','#d4c29b','#b7ab8e','#41453a','#383e34'],
    ['#514732','#f0e7cc','#c5c1a0','#c99451','#d9ad69','#6b7161','#565346'],
    ['#332b25','#eed6a4','#bf9c70','#bd4e36','#d7914f','#923f31','#41372b'],
    ['#263b53','#fff0ce','#a6b1ae','#d3a24f','#dfb76b','#a54d43','#324452'],
    ['#202724','#f2eee2','#a9aea0','#887557','#b8a580','#252d29','#282d2a'],
    ['#361e19','#502a1b','#9a6232','#b18136','#6b4220','#512e1c','#4c2c1d'],
    ['#173c58','#f4e6c6','#8caaa8','#d39942','#d8ae6d','#285a71','#193b56'],
    ['#13284d','#f3d984','#729ba6','#ffd651','#d7923d','#6cafc2','#15254b'],
    ['#292c3c','#dfc79e','#87958e','#e49647','#bd6048','#62454e','#232f3d'],
    ['#29282c','#29282c','#29282c','#29282c','#29282c','#29282c','#29282c'],
    ['#7effb2',null,null,null,null,'#7effb2','#7effb2'],
    ['#233349','#fff2cf','#9fb8bb','#ffbb39','#e67e32','#e95465','#22394a'],
    ['#3d3a5d','#fff8d7','#c1c8de','#efa13c','#e7bd69','#7d72b9','#403b5c'],
    ['#322452','#fff0e0','#84c9dd','#ffce76','#ed8ab0','#85e6f0','#281f55'],
    ['#183843','#fff9df','#c6ddd6','#f2b644','#df9140','#ed7152','#25434a'],
    ['#cce8ed','#f4f1df','#97b8bf','#ffbf66','#ec9372','#72e1d2','#7298ad']
  ];
  const names=['sahara','egypt','han','tang','song','riverside','maya','mughal','bada','wayang','ukiyo','starry','scream','nosferatu','scope','pixel','chat','vaporwave','short','code'];
  function sty(v){if(typeof v==='number')return Math.max(0,Math.min(19,v));const n=names.indexOf(v);return n<0?18:n;}
  const shape={
    tail:'M-116 -178 Q-147 -178 -170 -162 Q-155 -157 -148 -143 L-159 -135 Q-140 -130 -117 -146Z',
    body:'M-129 -165 C-142 -203 -108 -229 -67 -219 C-40 -218 -22 -202 -11 -184 C8 -161 1 -132 -24 -118 C-43 -108 -68 -105 -89 -113 C-109 -121 -122 -140 -129 -165Z',
    neck:'M-32 -182 C-5 -190 10 -209 10 -239 C9 -263 18 -278 39 -281 C61 -285 75 -270 76 -252 C76 -233 63 -226 48 -225 C43 -201 39 -185 27 -169 C11 -148 -6 -144 -21 -147Z',
    wing:'M-112 -183 C-86 -207 -49 -193 -29 -175 C-6 -154 23 -147 58 -146 C38 -136 10 -130 -13 -135 C-43 -132 -84 -145 -112 -183Z',
    pouch:'M65 -250 Q101 -245 198 -239 C159 -215 107 -211 77 -230 Q69 -235 65 -250Z',
    bill:'M65 -262 C106 -261 158 -255 201 -241 Q203 -238 196 -238 L67 -246Z'
  };
  // The pose/contacts are shared, but each study has its own silhouette.
  // These authored paths are not traced from an input image.
  const forms={
    0:{
      tail:'M-114 -180 L-169 -171 L-149 -155 L-176 -146 L-121 -136Z',
      body:'M-135 -170 Q-139 -210 -105 -224 L-64 -218 L-30 -198 L-9 -163 L-24 -119 L-64 -107 L-100 -124Z',
      neck:'M-33 -185 L-8 -198 L8 -234 L12 -263 L28 -281 L56 -281 L74 -265 L76 -244 L56 -231 L43 -230 L28 -185 L10 -156 L-19 -147Z',
      wing:'M-115 -190 L-87 -197 L-53 -181 L-27 -157 L51 -143 L15 -133 L-33 -139 L-84 -160Z',
      pouch:'M66 -250 L188 -239 L144 -215 L102 -219 L78 -229Z',
      bill:'M65 -264 L121 -260 L205 -240 L194 -237 L68 -246Z'
    },
    4:{
      tail:'M-117 -174 Q-151 -172 -167 -153 L-138 -151 L-155 -137 Q-132 -137 -117 -146Z',
      body:'M-132 -163 C-146 -197 -108 -219 -72 -214 C-39 -209 -21 -194 -11 -170 Q8 -139 -31 -118 Q-65 -107 -91 -123 Q-117 -139 -132 -163Z',
      neck:'M-33 -180 C-8 -190 12 -213 12 -240 Q11 -273 34 -284 Q59 -291 76 -270 Q85 -246 62 -232 L46 -230 Q42 -193 25 -171 Q7 -151 -21 -149Z',
      wing:'M-112 -183 C-79 -194 -48 -178 -22 -159 Q11 -141 54 -144 Q17 -127 -16 -137 Q-79 -147 -112 -183Z',
      pouch:'M66 -251 Q116 -246 192 -239 Q145 -216 105 -223 Q81 -228 66 -251Z',
      bill:'M67 -262 Q125 -260 201 -240 L192 -237 L69 -246Z'
    },
    18:{
      tail:'M-119 -178 Q-149 -176 -171 -158 L-151 -151 L-165 -137 Q-140 -127 -117 -146Z',
      body:'M-132 -167 C-139 -208 -102 -233 -61 -218 C-33 -208 -14 -186 -10 -165 C0 -132 -29 -114 -58 -112 Q-113 -108 -132 -167Z',
      neck:'M-30 -185 C-3 -195 11 -210 9 -242 C7 -268 25 -289 49 -284 C72 -282 81 -264 75 -247 Q69 -231 48 -228 Q43 -188 26 -170 Q7 -148 -21 -148Z',
      wing:'M-115 -184 C-86 -208 -48 -191 -25 -171 Q13 -147 58 -146 Q29 -128 -11 -134 Q-70 -132 -115 -184Z',
      pouch:'M66 -251 Q117 -248 198 -239 Q160 -207 110 -215 Q78 -219 66 -251Z',
      bill:'M67 -264 Q123 -262 201 -242 Q211 -237 196 -236 L68 -246Z'
    }
  };
  // Authored period silhouettes; joint locations remain unchanged so a figure
  // crossing a frame changes material without losing its saddle or pedals.
  Object.assign(forms,{
    1:{tail:'M-118 -174 L-166 -185 L-149 -169 L-171 -167 L-145 -148 L-123 -145Z',body:'M-131 -168 Q-140 -203 -103 -217 Q-66 -226 -34 -204 L-13 -172 L-23 -121 Q-66 -103 -97 -122Z',neck:'M-32 -185 L-1 -203 Q9 -214 10 -242 L13 -267 Q31 -291 53 -282 Q78 -276 76 -252 Q72 -232 48 -230 L40 -184 L22 -161 L-20 -147Z',wing:'M-115 -184 Q-89 -207 -55 -185 L-28 -164 L48 -145 L6 -135 Q-48 -141 -82 -158Z',pouch:'M66 -250 L193 -240 Q152 -216 111 -220 L80 -230Z',bill:'M66 -262 L122 -261 L201 -242 L197 -237 L67 -246Z'},
    2:{tail:'M-123 -173 Q-168 -195 -176 -173 Q-166 -169 -153 -169 L-175 -149 L-150 -155 L-158 -135 L-120 -145Z',body:'M-132 -168 Q-145 -199 -116 -218 Q-76 -238 -37 -204 L-12 -170 Q-1 -137 -29 -121 Q-64 -106 -96 -121Z',neck:'M-33 -186 Q-2 -202 3 -233 Q0 -269 28 -283 Q53 -294 73 -272 Q88 -247 62 -231 L47 -229 Q40 -194 25 -173 Q7 -151 -20 -147Z',wing:'M-117 -188 Q-86 -213 -55 -186 Q-24 -151 58 -145 L15 -131 Q-19 -138 -43 -143 Q-91 -153 -117 -188Z',pouch:'M66 -251 Q124 -251 196 -240 Q151 -216 113 -220 L80 -231Z',bill:'M65 -264 Q131 -262 207 -239 L194 -237 L67 -246Z'},
    3:{tail:'M-116 -174 Q-153 -183 -182 -157 Q-158 -164 -143 -154 Q-164 -141 -181 -138 Q-144 -129 -117 -148Z',body:'M-132 -164 C-144 -200 -112 -223 -74 -219 Q-37 -217 -18 -186 Q5 -150 -27 -124 Q-58 -105 -89 -119 Q-119 -133 -132 -164Z',neck:'M-34 -185 C-3 -199 14 -219 10 -246 Q7 -278 35 -286 Q64 -290 77 -269 Q84 -247 62 -232 L47 -231 Q42 -194 26 -172 Q5 -150 -19 -148Z',wing:'M-114 -185 Q-90 -207 -60 -186 Q-23 -153 57 -145 Q20 -131 -12 -135 Q-53 -140 -87 -162Z',pouch:'M66 -251 Q122 -248 203 -239 Q159 -216 110 -224 L78 -232Z',bill:'M66 -263 Q126 -263 209 -239 L197 -237 L67 -246Z'},
    5:{tail:'M-119 -177 Q-156 -179 -169 -159 L-147 -153 L-160 -136 Q-138 -133 -118 -147Z',body:'M-133 -167 Q-141 -207 -105 -222 Q-65 -235 -32 -201 Q-8 -180 -11 -152 Q-18 -120 -57 -113 Q-110 -112 -133 -167Z',neck:'M-33 -184 Q-2 -201 8 -232 Q6 -267 25 -280 Q47 -295 67 -279 Q86 -259 70 -239 L48 -229 Q39 -191 25 -172 Q7 -151 -20 -148Z',wing:'M-114 -185 Q-83 -204 -54 -184 Q-18 -151 55 -145 Q22 -128 -14 -137 Q-72 -145 -114 -185Z',pouch:'M66 -250 Q130 -250 198 -239 Q148 -209 104 -221 Q79 -228 66 -250Z',bill:'M66 -262 Q127 -261 203 -241 Q207 -237 195 -238 L67 -246Z'},
    6:{tail:'M-120 -177 L-168 -182 L-168 -169 L-151 -162 L-174 -151 L-158 -143 L-137 -146 L-120 -138Z',body:'M-132 -170 L-129 -202 L-109 -220 L-71 -222 L-42 -207 L-13 -175 L-15 -143 L-35 -121 L-68 -113 L-100 -127Z',neck:'M-32 -188 L-4 -203 L8 -237 L5 -260 L20 -281 L43 -287 L66 -278 L79 -258 L72 -237 L49 -229 L39 -192 L18 -164 L-19 -147Z',wing:'M-115 -187 L-91 -203 L-65 -194 L-43 -177 L-29 -159 L48 -145 L12 -131 L-32 -143 L-67 -152Z',pouch:'M65 -250 L190 -240 L165 -222 L126 -216 L95 -222 L77 -231Z',bill:'M66 -265 L116 -261 L152 -251 L196 -243 L202 -235 L67 -246Z'},
    7:{tail:'M-119 -174 Q-155 -181 -173 -160 Q-163 -163 -148 -153 L-165 -139 Q-140 -128 -118 -147Z',body:'M-132 -166 C-140 -199 -118 -224 -85 -225 Q-52 -225 -30 -200 Q-9 -178 -10 -154 C-12 -130 -37 -113 -62 -113 Q-116 -117 -132 -166Z',neck:'M-33 -185 Q-6 -199 8 -232 C4 -262 16 -282 37 -286 Q63 -292 76 -269 Q86 -246 63 -232 L47 -231 Q43 -192 26 -172 Q7 -150 -20 -148Z',wing:'M-113 -185 Q-91 -203 -63 -191 C-42 -183 -30 -162 -4 -153 Q25 -143 57 -145 Q31 -130 -6 -135 Q-74 -144 -113 -185Z',pouch:'M66 -251 Q126 -250 198 -240 Q166 -217 132 -217 Q93 -218 76 -231Z',bill:'M67 -264 Q129 -264 204 -241 L198 -237 L68 -246Z'},
    8:{tail:'M-117 -171 Q-149 -178 -167 -159 Q-157 -150 -148 -149 L-171 -135 Q-137 -134 -118 -145Z',body:'M-134 -171 Q-147 -214 -102 -226 Q-60 -237 -26 -202 Q-5 -179 -11 -149 Q-15 -121 -56 -112 Q-115 -108 -134 -171Z',neck:'M-33 -185 Q-5 -191 12 -214 Q18 -228 14 -248 Q9 -272 29 -284 Q52 -295 73 -274 Q86 -255 67 -237 L47 -231 Q43 -195 28 -175 Q9 -151 -21 -148Z',wing:'M-116 -189 Q-83 -214 -51 -183 Q-22 -153 59 -145 Q27 -125 -17 -136 Q-83 -145 -116 -189Z',pouch:'M66 -250 Q123 -248 186 -240 Q144 -216 102 -225 L78 -233Z',bill:'M65 -262 Q116 -265 201 -239 L190 -237 L66 -246Z'},
    9:{tail:'M-119 -176 Q-165 -207 -180 -173 Q-161 -186 -151 -169 Q-185 -160 -174 -143 Q-156 -158 -143 -147 L-153 -132 L-121 -143Z',body:'M-133 -172 Q-146 -206 -112 -223 Q-76 -240 -41 -208 L-15 -179 Q4 -150 -22 -127 Q-57 -105 -89 -116 Q-122 -133 -133 -172Z',neck:'M-33 -186 Q-5 -199 7 -232 Q1 -253 9 -271 L31 -291 Q57 -301 75 -273 Q87 -252 65 -233 L49 -230 Q42 -193 25 -170 Q6 -151 -21 -148Z',wing:'M-116 -189 Q-89 -210 -61 -190 Q-34 -169 -16 -159 L57 -145 L32 -136 L9 -139 L-2 -132 L-29 -143 L-49 -143 L-76 -159Z',pouch:'M66 -251 Q123 -253 202 -241 Q176 -213 137 -217 Q99 -218 78 -232Z',bill:'M66 -265 Q137 -269 210 -238 L198 -236 L68 -245Z'},
    10:{tail:'M-119 -177 Q-147 -184 -170 -162 L-150 -153 L-171 -140 Q-142 -134 -118 -146Z',body:'M-133 -169 Q-145 -211 -102 -224 Q-61 -229 -31 -201 Q-8 -180 -10 -151 Q-18 -124 -53 -114 Q-110 -113 -133 -169Z',neck:'M-34 -184 Q-3 -196 7 -230 Q3 -263 23 -280 Q46 -299 70 -277 Q88 -257 69 -238 L48 -231 Q42 -194 26 -173 Q9 -152 -20 -148Z',wing:'M-115 -187 Q-85 -204 -58 -186 Q-25 -158 55 -145 Q21 -129 -17 -138 Q-77 -146 -115 -187Z',pouch:'M66 -251 L197 -240 Q158 -214 113 -220 Q89 -223 77 -232Z',bill:'M67 -263 Q128 -261 206 -240 L194 -237 L68 -246Z'},
    11:{tail:'M-118 -177 Q-153 -190 -176 -166 Q-155 -164 -149 -153 L-172 -141 Q-144 -126 -118 -146Z',body:'M-134 -170 C-145 -209 -107 -236 -67 -222 C-36 -215 -20 -195 -11 -174 Q7 -140 -28 -121 Q-66 -102 -95 -121 Q-119 -136 -134 -170Z',neck:'M-35 -185 C-7 -198 10 -221 7 -241 Q0 -273 28 -285 Q52 -295 72 -276 Q90 -257 70 -236 L49 -230 Q44 -190 26 -171 Q4 -147 -22 -148Z',wing:'M-117 -190 Q-86 -212 -54 -186 Q-28 -159 1 -151 Q26 -141 59 -145 Q33 -126 -6 -134 Q-74 -140 -117 -190Z',pouch:'M66 -252 Q126 -250 202 -239 Q156 -208 113 -218 Q87 -223 77 -232Z',bill:'M66 -264 Q137 -266 207 -240 L198 -236 L67 -246Z'},
    12:{tail:'M-118 -178 Q-151 -185 -172 -167 L-155 -153 Q-171 -144 -165 -135 Q-141 -129 -117 -146Z',body:'M-133 -171 Q-145 -208 -110 -222 Q-71 -238 -37 -207 Q-5 -183 -12 -153 Q-19 -120 -55 -112 Q-112 -110 -133 -171Z',neck:'M-33 -186 Q-8 -202 6 -232 Q1 -260 17 -280 Q41 -301 66 -281 Q87 -263 74 -243 L51 -232 Q44 -198 25 -174 Q8 -151 -20 -148Z',wing:'M-116 -186 Q-85 -208 -59 -186 Q-32 -166 -4 -153 Q20 -144 55 -146 Q23 -127 -15 -135 Q-80 -149 -116 -186Z',pouch:'M66 -252 Q134 -253 204 -237 Q165 -214 119 -218 Q89 -219 77 -231Z',bill:'M66 -265 Q135 -267 209 -238 L199 -236 L68 -245Z'},
    13:{tail:'M-120 -178 L-175 -189 L-152 -168 L-187 -152 L-152 -146 L-170 -128 L-119 -144Z',body:'M-134 -172 Q-149 -215 -103 -229 Q-61 -235 -30 -204 Q-8 -179 -11 -151 Q-16 -122 -56 -111 Q-117 -109 -134 -172Z',neck:'M-35 -184 Q-12 -207 1 -240 Q-4 -279 29 -289 Q58 -298 76 -274 Q91 -252 67 -234 L48 -229 Q41 -194 24 -171 Q6 -150 -22 -147Z',wing:'M-118 -190 Q-88 -218 -55 -190 Q-25 -160 64 -145 L30 -134 L6 -140 L-10 -131 L-35 -144 L-52 -142 L-84 -163Z',pouch:'M66 -251 L218 -239 Q165 -210 113 -219 L78 -232Z',bill:'M65 -266 Q144 -267 225 -238 L212 -234 L67 -245Z'},
    15:{tail:'M-120 -180 H-165 V-165 H-150 V-150 H-165 V-135 H-135 V-145 H-120Z',body:'M-135 -170 V-200 H-120 V-215 H-90 V-225 H-60 V-215 H-40 V-200 H-25 V-185 H-10 V-155 H-20 V-135 H-40 V-120 H-70 V-110 H-95 V-125 H-115 V-145Z',neck:'M-35 -185 H-10 V-205 H5 V-240 H10 V-265 H25 V-280 H55 V-275 H70 V-260 H80 V-245 H65 V-235 H45 V-205 H35 V-185 H20 V-165 H0 V-150 H-20Z',wing:'M-115 -185 V-195 H-90 V-200 H-65 V-185 H-50 V-170 H-30 V-160 H-5 V-150 H55 V-140 H25 V-130 H-10 V-135 H-45 V-145 H-75 V-160 H-100Z',pouch:'M65 -250 H105 V-245 H150 V-240 H195 V-230 H170 V-220 H120 V-215 H100 V-220 H80 V-235Z',bill:'M65 -265 H110 V-260 H145 V-255 H175 V-250 H200 V-240 H195 V-235 H150 V-240 H105 V-245 H65Z'},
    16:{tail:'M-116 -177 Q-150 -187 -165 -163 L-148 -152 L-165 -137 Q-136 -131 -116 -146Z',body:'M-134 -173 C-151 -212 -114 -240 -72 -228 Q-38 -220 -18 -191 Q2 -159 -21 -132 Q-48 -107 -83 -117 Q-116 -129 -134 -173Z',neck:'M-33 -185 Q-5 -199 8 -228 Q1 -256 17 -276 Q36 -298 63 -283 Q87 -269 77 -244 Q66 -231 49 -229 Q43 -192 27 -171 Q6 -150 -20 -148Z',wing:'M-114 -186 Q-88 -208 -55 -183 Q-21 -152 55 -145 Q24 -127 -14 -135 Q-73 -142 -114 -186Z',pouch:'M67 -250 Q127 -250 187 -239 Q153 -207 112 -216 Q85 -220 77 -232Z',bill:'M67 -264 Q128 -262 197 -242 Q205 -237 191 -236 L68 -246Z'},
    17:{tail:'M-119 -178 L-174 -167 L-151 -153 L-165 -135 L-117 -145Z',body:'M-134 -169 Q-140 -210 -103 -225 L-64 -220 L-30 -201 L-11 -172 Q3 -140 -29 -122 Q-62 -105 -92 -122Z',neck:'M-34 -185 Q-3 -201 8 -231 L10 -264 Q29 -293 53 -283 Q78 -276 77 -253 L64 -234 L48 -231 L36 -188 L24 -169 L-20 -148Z',wing:'M-115 -188 L-87 -200 L-57 -186 L-28 -160 L57 -145 L18 -131 L-18 -138 L-78 -159Z',pouch:'M66 -251 L199 -240 L162 -220 L120 -215 L94 -223 L78 -232Z',bill:'M66 -264 L123 -261 L167 -251 L206 -240 L195 -236 L67 -246Z'},
    19:{tail:'M-119 -176 C-141 -180 -160 -171 -174 -157 L-150 -150 L-165 -135 Q-140 -130 -117 -146Z',body:'M-133 -168 C-142 -207 -108 -231 -72 -222 C-38 -216 -17 -192 -10 -167 Q1 -137 -29 -120 Q-62 -106 -93 -121 Q-120 -137 -133 -168Z',neck:'M-33 -185 C-4 -199 12 -218 9 -242 C6 -269 22 -288 44 -286 C68 -285 81 -266 76 -249 Q69 -233 49 -230 C43 -199 40 -187 25 -171 Q7 -150 -21 -148Z',wing:'M-115 -186 C-88 -208 -54 -189 -29 -167 Q4 -146 59 -145 Q28 -128 -11 -134 C-58 -138 -91 -157 -115 -186Z',pouch:'M66 -251 Q126 -250 201 -240 C172 -220 145 -213 119 -218 Q88 -223 77 -232Z',bill:'M67 -264 C114 -264 160 -255 204 -241 Q210 -237 197 -237 L68 -246Z'}
  });
  const formFor=st=>forms[st]||shape;
  const fineArt=st=>st===3||st===4||st===7||st===8||st===10;
  // Sparse contour details share the same flat drawing language as the scenery.
  // Every mark belongs to its joint-local path; no raster textures or frame noise.
  function surfaceDetails(c,st,part){
    if(![3,4,7,8,10,11,12,17].includes(st))return;
    const shape=formFor(st),pa=paints[st],ink=pa[0],localPath=part==='body'?shape.body+shape.tail:shape[part];
    c.save();c.clip(new Path2D(localPath));
    if(st===3||st===7||st===10){
      const col=st===7?'#617993':st===10?'#416b81':'#777768';
      c.globalAlpha=.6;
      if(part==='body'){
        for(let j=0;j<7;j++){let x=-118+j*15,y=-209+Math.sin(j*.42)*8;K.path(c,`M${x} ${y} q-3 7 5 12 q5 2 10 -2`,null,col,.72);}
        K.path(c,'M-142 -164 l15 8 M-149 -151 l18 2 M-104 -128 q19 11 37 9',null,col,.8);
      }
      if(part==='neck'){
        K.path(c,'M27 -276 Q18 -242 26 -226 Q22 -193 2 -178 M33 -271 Q27 -248 33 -237',null,col,.75);
        K.path(c,'M-17 -159 q14 -3 22 -12',null,col,.8);
      }
      if(part==='wing')for(let j=0;j<7;j++){
        let y=-193+j*7;K.path(c,`M-102 ${y} C-75 ${y-1} -44 ${-151+j*1.4} ${-5+j*5} ${-140+j*.9}`,null,col,.75);
      }
      if(part==='bill')K.path(c,'M82 -257 Q129 -254 179 -245',null,st===7?'#f0d78f':pa[1],.85);
      if(part==='pouch')for(let j=0;j<3;j++)K.path(c,`M${79+j*5} ${-242+j*4} Q123 ${-220+j} ${169-j*11} ${-233+j}`,null,st===7?'#a17e40':'#a39a7a',.68);
      if(st===7&&part==='wing'){
        c.globalAlpha=.8;for(let j=0;j<5;j++){let x=-91+j*15,y=-174+Math.sin(j*.5)*10;K.path(c,`M${x-3} ${y} q3 -5 6 0 q-3 5 -6 0Z`,null,'#ae8c3e',.8);}
      }
    }else if(st===4||st===8){
      // Broad transparent washes and a few broken strokes, like the ink landscape.
      c.globalAlpha=st===8?.15:.12;
      if(part==='body')K.path(c,'M-137 -189 Q-105 -174 -74 -157 Q-36 -136 -15 -129 L-32 -108 L-106 -116Z',ink);
      if(part==='neck')K.path(c,'M14 -267 Q20 -227 6 -205 Q-2 -181 -21 -166 L-6 -155 Q22 -183 28 -212 Q33 -246 25 -272Z',ink);
      if(part==='wing')K.path(c,'M-109 -186 Q-75 -171 -44 -151 Q-13 -135 42 -138 L13 -127 L-68 -143Z',ink);
      c.globalAlpha=st===8?.45:.33;c.setLineDash([8,2.5,3,1.5]);
      if(part==='wing')for(let j=0;j<4;j++)K.path(c,`M-105 ${-187+j*9} Q-56 ${-171+j*7} ${7+j*10} ${-139+j*1.4}`,null,ink,st===8?1.35:.9);
      if(part==='body')K.path(c,'M-123 -200 q18 -14 35 -11 M-117 -190 q18 -13 28 -9 M-123 -153 q11 20 30 27',null,ink,st===8?1.3:.8);
      if(part==='pouch')K.path(c,'M82 -240 Q111 -222 156 -229',null,ink,.8);
      c.setLineDash([]);
    }else if(st===17){
      // The sunset lights the upper bill and feathers; the grid casts a cool
      // reflected light on their underside. These marks stay on the anatomy.
      c.globalAlpha=.37;
      if(part==='body')K.path(c,'M-130 -209 Q-71 -239 -20 -192 L-32 -170 Q-92 -190 -126 -179Z','#ffc8ae');
      if(part==='neck')K.path(c,'M29 -282 Q59 -291 75 -262 L58 -237 Q48 -221 42 -198 L32 -205 Q50 -252 29 -282Z','#ffc9bd');
      if(part==='wing')K.path(c,'M-111 -187 Q-54 -191 -13 -156 L33 -142 L4 -135 Q-67 -153 -111 -187Z','#ea9cda');
      c.globalAlpha=.9;
      const rims={body:'M-128 -190 Q-121 -214 -89 -218 Q-60 -220 -38 -207',neck:'M33 -277 Q58 -281 68 -264 M46 -220 Q40 -191 26 -175',wing:'M-105 -183 Q-77 -196 -47 -184',pouch:'M83 -236 Q118 -214 167 -231',bill:'M82 -258 Q130 -255 184 -244'};
      K.path(c,rims[part],null,part==='pouch'?'#ffd0bd':'#fff8db',1.65);
      if(part==='wing')for(let j=0;j<5;j++)K.path(c,`M${-97+j*7} ${-178+j*7} Q-48 ${-164+j*5} ${-2+j*8} ${-139+j*.9}`,null,j%2?'#c1f3f4':'#648cba',.9);
    }else{
      // Curved, tapered paint marks follow the breast, neck and folded wing.
      // Irregular intervals avoid the former evenly spaced hatch grid.
      const cols=st===11?['#ffe681','#fff0b9','#c5c268','#4776a5','#9fd0c3']:['#ebc68e','#cf9563','#849b9a','#4a5964','#f0d7aa'];
      const strokes={
        body:[['M-124 -198 Q-111 -216 -88 -215',3.6,1],['M-91 -216 Q-62 -215 -43 -201',4.4,0],['M-119 -186 Q-109 -200 -91 -199',3.2,0],['M-124 -171 Q-113 -145 -91 -135',4.8,3],['M-112 -168 Q-100 -148 -82 -143',2.4,4],['M-82 -130 Q-56 -117 -32 -132',4.3,3],['M-72 -121 Q-48 -119 -29 -131',2.1,4],['M-47 -204 Q-25 -190 -20 -170',2.8,1],['M-140 -161 Q-149 -155 -155 -151',2.3,0]],
        neck:[['M23 -265 Q15 -245 22 -229',3.9,0],['M30 -272 Q24 -255 29 -241',2.2,1],['M27 -222 Q25 -199 7 -180',3.3,3],['M35 -223 Q31 -198 16 -182',2.4,4],['M40 -277 Q55 -280 64 -268',3,1],['M3 -170 Q-6 -158 -17 -157',2.7,0]],
        wing:[['M-106 -183 Q-83 -193 -61 -183',3.9,0],['M-96 -179 Q-75 -169 -54 -164',4.8,3],['M-73 -176 Q-48 -164 -29 -150',2.4,4],['M-84 -163 Q-65 -149 -43 -144',3,1],['M-36 -150 Q-9 -137 20 -140',4.1,0],['M-44 -142 Q-18 -132 1 -136',2.1,3],['M-103 -184 Q-86 -186 -79 -183',1.1,1]],
        pouch:[['M82 -237 Q105 -220 132 -224',3.4,0],['M112 -227 Q137 -226 164 -232',1.8,1]],
        bill:[['M83 -258 Q114 -255 136 -251',2.2,1],['M146 -250 L181 -243',1.3,0]]
      };
      for(const [path,w,col]of strokes[part]||[]){c.globalAlpha=col===3?.75:.88;K.path(c,path,null,cols[col],st===12?w*.88:w);}
      if(st===11){c.globalAlpha=.35;const fibres={body:'M-116 -198 Q-107 -205 -96 -207 M-119 -172 Q-113 -153 -99 -143',neck:'M26 -262 Q23 -249 26 -239 M32 -219 Q27 -199 17 -186',wing:'M-93 -178 Q-76 -171 -59 -166 M-33 -149 Q-12 -141 10 -141'};if(fibres[part])K.path(c,fibres[part],null,'#fff2b1',.8);}
    }
    c.restore();
  }
  function nativePlumage(c,st,part){
    if(![1,2,6,7,9,15,16,19].includes(st))return;
    const shape=formFor(st),ink=paints[st][0];c.save();c.clip(new Path2D(part==='body'?shape.body:shape[part]));
    if(st===1&&part==='neck'){
      K.path(c,'M-13 -193 Q10 -178 40 -191',null,'#bd8a36',11);
      K.path(c,'M-13 -193 Q10 -178 40 -191',null,'#3b7876',5);
      for(let j=0;j<6;j++){const x=-5+j*7,y=-187+Math.sin(j/5*Math.PI)*4;K.line(c,[[x,y-5],[x+1,y+2]],'#f3dc99',1.5);}
    }
    if(st===2&&(part==='body'||part==='wing')){
      for(let row=0;row<3;row++)for(let j=0;j<5;j++){const x=-118+j*14+row*5,y=-199+row*15;K.path(c,`M${x} ${y} q4 7 10 3`,null,'#485042',1.1);}
      K.path(c,'M-115 -154 q14 21 33 25 M-106 -153 q8 13 20 15',null,'#e8e4cc',.85);
    }
    if(st===6&&part==='wing'){
      K.path(c,'M-111 -184 L-85 -169 L-56 -160 L-29 -147 L-1 -140',null,'#3f8172',7);
      for(let j=0;j<5;j++){const x=-103+j*20,y=-178+j*8;K.path(c,`M${x} ${y-4} l5 4 -5 4 -5 -4Z`,'#d3a14f',ink,.7);}
    }
    if(st===7&&part==='neck'){
      for(let j=0;j<6;j++)K.path(c,`M${20+j*3} ${-258+j*3} q-2 6 1 10`,null,'#939e96',.5);
    }
    if(st===9){
      const holes=part==='body'?Array.from({length:16},(_,j)=>[-117+(j%4)*18,-201+Math.floor(j/4)*17]):part==='neck'?[[24,-263],[22,-253],[25,-242],[22,-222],[17,-209],[8,-193]]:part==='wing'?Array.from({length:9},(_,j)=>[-105+j*13,-182+Math.sin(j/8*Math.PI/2)*37]):[];
      for(const [x,y]of holes){K.path(c,`M${x} ${y-3.4} q4 3.4 0 6.8 q-4 -3.4 0 -6.8Z`,'#e2b773');K.circle(c,x+5,y+3,.85,'#efce91');}
      if(part==='wing')K.path(c,'M-109 -188 Q-64 -179 -24 -148 Q9 -138 42 -142',null,'#d5a455',1.2);
      if(part==='bill'){K.path(c,'M83 -256 Q125 -257 180 -243',null,'#e4bd76',1.1);for(let j=0;j<7;j++)K.circle(c,88+j*12,-252+j*.9,1.1,'#ddb170');}
    }
    if(st===15&&part==='body'){K.path(c,'M-90 -220 L-64 -180 L-48 -116',null,'#b16b40',9);K.rect(c,-71,-187,11,13,'#e5bf5b',ink,2);}
    if(st===16&&part==='neck')K.ellipse(c,58,-246,5,2.6,'#e8abbe');
    if(st===19&&(part==='body'||part==='wing')){
      K.path(c,part==='body'?'M-125 -179 Q-106 -205 -81 -202 M-91 -124 Q-62 -112 -39 -128':'M-103 -182 Q-79 -193 -56 -177 Q-29 -152 12 -142',null,'#94bcbf',1.1);
      if(part==='wing')for(let j=0;j<5;j++)K.path(c,`M${-95+j*10} ${-178+j*5} Q-49 ${-161+j*4} ${-9+j*7} ${-141+j*.7}`,null,'#b2cfcd',.65);
    }
    c.restore();
  }
  // R4: one immutable drivetrain, in the bicycle's local coordinates.
  // Camera/scene scale never changes the sprocket radii or the selected gear.
  const driveRig=Object.freeze({front:[0,0],rear:[-130,25],frontRadius:24,
    rearRadius:15,frontTeeth:32,rearTeeth:20,ratio:24/15,pedalRadius:31});
  P.drivetrain=driveRig;
  function chainGeometry(){
    const F=driveRig.front,B=driveRig.rear,R=driveRig.frontRadius,r=driveRig.rearRadius;
    const dx=B[0]-F[0],dy=B[1]-F[1],d=Math.hypot(dx,dy);
    const axis=Math.atan2(dy,dx),delta=Math.acos((R-r)/d);
    const top=axis+delta,bottom=axis-delta;
    const at=(C,rad,a)=>[C[0]+rad*Math.cos(a),C[1]+rad*Math.sin(a)];
    const ft=at(F,R,top),fb=at(F,R,bottom),rt=at(B,r,top),rb=at(B,r,bottom);
    const straight=Math.sqrt(d*d-(R-r)*(R-r));
    const frontSweep=TAU-2*delta,rearSweep=2*delta;
    const segments=[
      {type:'line',a:rt,b:ft,length:straight},
      {type:'arc',center:F,radius:R,start:top,sweep:frontSweep,length:R*frontSweep},
      {type:'line',a:fb,b:rb,length:straight},
      {type:'arc',center:B,radius:r,start:bottom,sweep:rearSweep,length:r*rearSweep}
    ];
    const length=segments.reduce((s,q)=>s+q.length,0);
    return {front:F,rear:B,frontRadius:R,rearRadius:r,ratio:driveRig.ratio,
      frontTop:ft,frontBottom:fb,rearTop:rt,rearBottom:rb,
      topAngle:top,bottomAngle:bottom,frontSweep,rearSweep,segments,length,
      at(s){s=((s%length)+length)%length;for(const q of segments){
        if(s<=q.length){const u=s/q.length;if(q.type==='line')return [
          K.lerp(q.a[0],q.b[0],u),K.lerp(q.a[1],q.b[1],u)];
          return at(q.center,q.radius,q.start+q.sweep*u);}
        s-=q.length;
      }return rt.slice();}
    };
  }
  const chainRig=chainGeometry();
  P.chainGeometry=()=>chainRig;
  function chainPath(){
    // Explicit centres remove SVG's ambiguous large-arc flag selection.
    const q=chainRig,p=new Path2D();p.moveTo(...q.rearTop);p.lineTo(...q.frontTop);
    p.arc(0,0,q.frontRadius,q.topAngle,q.topAngle+q.frontSweep,false);
    p.lineTo(...q.rearBottom);
    p.arc(-130,25,q.rearRadius,q.bottomAngle,q.bottomAngle+q.rearSweep,false);
    p.closePath();return p;
  }
  const drivePath=chainPath();
  function sprocket(c,centre,radius,teeth,angle,ink,metal,st,front){
    const [x,y]=centre,outline=st===14,shadow=st===13;
    c.save();c.translate(x,y);c.rotate(angle);
    const tooth=new Path2D();
    for(let n=0;n<teeth*4;n++){
      const a=n*TAU/(teeth*4),r=radius+(n%4===1||n%4===2?.55:-1.15);
      n?tooth.lineTo(Math.cos(a)*r,Math.sin(a)*r):tooth.moveTo(Math.cos(a)*r,Math.sin(a)*r);
    }tooth.closePath();
    if(!outline){c.fillStyle=metal;c.fill(tooth);}c.lineWidth=outline?.9:1;c.strokeStyle=ink;c.stroke(tooth);
    // Five-arm spider, a clear axle, and restrained material detail.
    K.circle(c,0,0,radius-4,outline?null:shadow?ink:metal,ink,.8);
    for(let n=0;n<5;n++){
      const a=n*TAU/5;
      K.line(c,[[Math.cos(a)*4.4,Math.sin(a)*4.4],
        [Math.cos(a)*(radius-4),Math.sin(a)*(radius-4)]],ink,front?1.8:1.3);
    }
    K.circle(c,0,0,front?4.4:3.8,outline?null:metal,ink,1);
    c.restore();
  }
  function chain(c,phase,ink,metal,st,gearRatio,rearAngle){
    c.save();c.setLineDash([]);
    // The near-side drivetrain is above the frame, below the near crank/foot.
    // Its rear sprocket uses the rear wheel's LOCAL angle (frame pitch removed).
    const rear=Number.isFinite(rearAngle)?rearAngle:phase*driveRig.ratio;
    sprocket(c,driveRig.rear,driveRig.rearRadius,driveRig.rearTeeth,rear,ink,metal,st,false);
    sprocket(c,driveRig.front,driveRig.frontRadius,driveRig.frontTeeth,phase,ink,metal,st,true);
    c.lineCap='round';c.lineJoin='round';c.strokeStyle=ink;c.lineWidth=st===14?1.65:2.5;c.stroke(drivePath);
    // Path order is top rear→front, clockwise front wrap, bottom front→rear.
    // Distance = crank angle × pitch radius: no independent "marching ants".
    const pitch=TAU*driveRig.frontRadius/driveRig.frontTeeth;
    c.setLineDash([pitch*.30,pitch*.70]);c.lineDashOffset=-phase*driveRig.frontRadius;
    c.strokeStyle=metal;c.lineWidth=st===14?.85:1.05;c.stroke(drivePath);
    c.setLineDash([]);c.restore();
  }
  // One side-view avian eye. Colour/line treatment varies; its anatomy does not.
  // The iris is mechanically constrained and clipped to the blinking aperture.
  P.riderEyeState=function(t,opts={},st=18){
    const ex=opts.expression||'',start=2.12,span=.22;
    const b=((t%4.7)+4.7)%4.7,u=(b-start)/span;
    let open=(u>0&&u<1)?1-Math.sin(Math.PI*u)**2:1;
    if(ex==='blink')open=0;
    const startled=ex==='surprised',s=startled?1.07:1;
    const rx=(st===15?6.2:st===8?5.5:5.6)*s,ry=(st===15?6.0:st===8?5.0:5.9)*s;
    let gx=Number.isFinite(opts.gazeX)?K.clamp(opts.gazeX,-1,1):.8;
    let gy=Number.isFinite(opts.gazeY)?K.clamp(opts.gazeY,-1,1):0;
    if(st===8||ex==='eye-roll'){gy=Math.max(gy,-.35);open*=.88;}
    const mag=Math.hypot(gx,gy);if(mag>1){gx/=mag;gy/=mag;}
    const irisR=(st===15?3.7:3.65)*s,pupilR=(st===15?2.8:2.55)*s;
    const maxTravel=Math.max(0,Math.min(rx,ry)-irisR-.85);
    return {cx:48,cy:-260,rx,ry,open,irisR,pupilR,
      px:48+gx*maxTravel,py:-260+gy*maxTravel,
      visible:st!==13,outline:st===14,
      palette:st===2?'rubbing':st===14?'phosphor':st===8?'ink':'paint'};
  };
  P.riderEyePath=function(e){const p=new Path2D();
    p.ellipse(e.cx,e.cy,e.rx,Math.max(.06,e.ry*e.open),0,0,TAU);return p;};
  function eye(c,t,opts,st,ink){
    const e=P.riderEyeState(t,opts,st);if(!e.visible)return;
    const eyeInk=st===2?'#394334':st===19?'#26494f':ink;
    const whites=st===0?'#b77f4e':st===2?'#ddd6b9':st===9?'#d5b16c':st===11?'#ecd589':st===12?'#d3b991':'#ebe5cf';
    const iris=st===0?'#975c33':st===2?'#969d84':st===3||st===4||st===8?'#a49d77':st===7?'#af9152':st===11?'#b39d57':st===19?'#92b2ac':'#bf9d58';
    c.save();c.setLineDash([]);if(st===14)c.shadowBlur=3;
    // Also guard against future changes to the head silhouette.
    c.clip(new Path2D(formFor(st).neck));
    if(e.open<.08){
      K.path(c,`M${e.cx-e.rx} ${e.cy} Q${e.cx} ${e.cy+1.2} ${e.cx+e.rx} ${e.cy}`,
        null,eyeInk,st===14?1.1:1.05);c.restore();return;
    }
    const aperture=P.riderEyePath(e);
    if(st!==14){c.fillStyle=whites;c.fill(aperture);}
    c.save();c.clip(aperture);
    if(st!==14)K.circle(c,e.px,e.py,e.irisR,iris);
    K.circle(c,e.px,e.py,e.pupilR,eyeInk);
    if(![0,2,8,9,14,15].includes(st))K.circle(c,e.px-.55,e.py-.8,.54,whites);
    c.restore();c.lineWidth=st===15?1.3:st===14?1.1:.8;c.strokeStyle=eyeInk;c.stroke(aperture);
    // The eyelid is part of the socket, not a detached human eyebrow.
    c.beginPath();c.ellipse(e.cx,e.cy,e.rx,e.ry*e.open,0,Math.PI*1.10,Math.PI*1.91);
    c.lineWidth=st===14?1.0:1.1;c.stroke();
    if(st===1)K.path(c,`M${e.cx-e.rx} ${e.cy-1} l-4 -1`,null,eyeInk,1.1);
    c.restore();
  }
  const stage=(v,a,b)=>K.clamp((v-a)/(b-a));
  function reveal(c,p,bounds,draw,vertical=true){
    if(p<=0)return;c.save();
    if(p<1){const [x,y,w,h]=bounds;c.beginPath();if(vertical)c.rect(x,y+h-h*p,w,h*p+.01);else c.rect(x,y,w*p+.01,h);c.clip();}
    draw();c.restore();
  }
  function traceReveal(c,p,length,draw){
    if(p<=0)return;c.save();if(p<1)c.setLineDash([length*p,100000]);draw();c.restore();
  }
  function traceLines(c,parts,p,col,lw){
    let total=0;for(const seg of parts)for(let j=1;j<seg.length;j++)total+=Math.hypot(seg[j][0]-seg[j-1][0],seg[j][1]-seg[j-1][1]);
    let remain=total*K.clamp(p);c.beginPath();
    for(const seg of parts){c.moveTo(...seg[0]);for(let j=1;j<seg.length;j++){const a=seg[j-1],b=seg[j],len=Math.hypot(b[0]-a[0],b[1]-a[1]),u=Math.min(1,remain/len);if(remain>0)c.lineTo(a[0]+(b[0]-a[0])*u,a[1]+(b[1]-a[1])*u);remain-=len;}}
    c.strokeStyle=col;c.lineWidth=lw;c.stroke();
  }
  function wheel(c,x,angle,pa,st,progress=1){
    if(progress<=0)return;
    const [ink,bird,shade,bill,pouch,frame,tyre]=pa;
    const arc=(r,col,lw)=>{if(progress>=.999){K.circle(c,x,25,r,null,col,lw);return;}c.beginPath();c.arc(x,25,r,-Math.PI/2,-Math.PI/2+TAU*progress);c.strokeStyle=col;c.lineWidth=lw;c.stroke();};
    c.save();
    if(st===0&&progress>=.999){
      const pts=[];for(let j=0;j<=80;j++){const a=j*TAU/80,r=76.6+.8*Math.sin(a*7+angle)+.5*Math.sin(a*13);pts.push([x+Math.cos(a)*r,25+Math.sin(a)*r]);}
      K.line(c,pts,tyre,4.7);c.globalAlpha=.44;K.line(c,pts,bird,2.2);c.globalAlpha=1;
    }else if(st===4||st===8){
      arc(77,tyre,st===8?4.8:3.4);c.setLineDash(st===8?[19,4,3,2]:[17,2,4,1]);arc(75,bird,1.4);c.setLineDash([]);
    }else if(st===1){arc(77,ink,5.5);arc(73,'#bb8c3e',6);arc(67,'#397475',1.4);}
    else if(st===2){arc(77,ink,4);arc(71,ink,1.2);}
    else if(st===9){arc(77,ink,7);arc(72,'#b78c49',2);arc(66,ink,1.5);}
    else if(st===15){arc(77,tyre,8);arc(69,'#7bd8cf',3);}
    else if(st===17){arc(77,tyre,6);arc(74,'#94e7ee',2.8);arc(68,'#b87bd3',1.5);}
    else if(st===19){arc(77,'#1d3c4a',6.3);arc(74,'#8ae3df',2.5);arc(69,'#406d7e',1.3);}
    else{arc(77,tyre,st===14?2:fineArt(st)?5.1:7);if(st!==13)arc(70,st===14?ink:shade||ink,st===14?1:1.8);}
    const ns=st===0?8:st===1?8:st===2?6:st===6?8:st===7?12:st===9?8:st===12?10:st===15?8:st===16?6:st===17?3:st===4||st===8?8:st===18?12:st===19?18:16;
    c.translate(x,25);c.rotate(angle);
    for(let k=0;k<Math.ceil(ns*progress);k++){
      const a=k*TAU/ns;c.save();c.rotate(a);
      if(st===1){
        K.path(c,'M8 -2 L54 -4 Q61 -8 68 0 Q61 8 54 4 L8 2Z','#c49a50',ink,1.1);
        K.path(c,'M49 0 L62 0 M57 -4 L57 4',null,'#397475',1.5);
      }else if(st===2){
        K.path(c,'M8 -3 L65 -5 L70 0 L65 5 L8 3Z',ink);
        K.path(c,'M19 0 H58',null,'#363d34',.8);
      }else if(st===6){
        K.path(c,'M6 0 H19 V-7 H34 V0 H48 V7 H62 V0 H68',null,ink,3);
        K.circle(c,56,-7,2.3,bill);
      }else if(st===7){
        K.path(c,'M6 0 Q31 -15 66 0 Q35 15 6 0Z',null,'#a98334',1.1);
        K.line(c,[[11,0],[67,0]],ink,.85);K.circle(c,56,0,2.3,'#d9be67',ink,.6);
      }else if(st===9){
        K.path(c,'M9 0 Q26 -22 62 -10 L68 0 L62 10 Q26 22 9 0Z',ink,'#af8143',1.2);
        K.path(c,'M25 0 Q40 -9 57 0 Q40 9 25 0Z','#dfb66f');
        K.circle(c,65,0,2.2,'#e4bf79');
      }else if(st===11){
        K.path(c,'M5 0 Q35 -21 68 0',null,k%2?'#c8d798':'#72b4cf',2.1);
        K.path(c,'M13 0 Q37 -12 65 2',null,'#4879a7',.8);
      }else if(st===12){
        K.path(c,'M5 0 C24 -5 31 9 45 0 Q58 -7 69 0',null,k%2?'#699098':ink,1.8);
      }else if(st===13){
        K.path(c,'M3 -2 L69 -1 L52 3 L4 3Z',ink);
      }else if(st===15){
        K.path(c,'M5 0 H19 V-5 H37 V0 H56 V5 H69',null,'#4ea49d',3);
      }else if(st===16){
        K.path(c,'M7 0 Q38 -14 68 0',null,'#8d8bc2',2.2);K.circle(c,57,0,3.2,'#cbdaf0',ink,.8);
      }else if(st===17){
        K.path(c,'M5 -8 C28 -21 55 -19 70 -5 L67 6 C42 -1 25 7 8 11Z','#81c5da',ink,1.4);
        K.path(c,'M16 -5 Q37 -13 62 -7',null,'#ebf7f1',2.6);
        K.path(c,'M15 8 Q38 -1 60 2',null,'#b378d1',2.4);
      }else if(st===19){
        K.line(c,[[5,0],[68,k%2?3:-3]],k%3?'#78aab6':'#dbf4ec',.95);K.circle(c,66,0,1.1,'#f8cf9b');
      }else K.line(c,[[0,0],[69,0]],st===11?'#9ac4a9':ink,st===0?2.5:st===14?1:st===5?1.6:1.1);
      c.restore();
    }
    if(st===6||st===9)for(let k=0;k<16*progress;k++){const a=k*TAU/16;K.circle(c,Math.cos(a)*73,Math.sin(a)*73,st===9?1.5:1.8,st===9?'#dfb66f':bill);}
    if(st===11)for(let k=0;k<24*progress;k++){const a=k*TAU/24;c.beginPath();c.arc(0,0,74,a,a+.13);c.strokeStyle=k%3?'#75aec3':'#e6d17a';c.lineWidth=2.8;c.stroke();}
    if(st===19)for(let k=0;k<36*progress;k++){const a=k*TAU/36;K.line(c,[[Math.cos(a)*71,Math.sin(a)*71],[Math.cos(a)*74,Math.sin(a)*74]],k%3?'#4f8e9d':'#d1eee0',.8);}
    if(progress>.72){
      K.circle(c,0,0,st===1||st===2||st===9?10:6,st===14?null:st===17?'#d6eee5':shade||ink,ink,st===14?1:1.3);
      if(st!==0&&st!==13&&st!==14){K.circle(c,0,0,st===1?5:2.6,bill,ink,.7);K.line(c,[[-2,-1],[2,1]],ink,.7);}
    }
    // A valve/reflector exposes the actual road-derived rotation, even when
    // repeating spokes would produce a wagon-wheel alias at a low frame rate.
    if(progress>.99&&st!==0&&st!==13){const a=-.45,col=st===14?'#d1ffe0':st===17?'#ffaccd':bill||ink;K.line(c,[[Math.cos(a)*62,Math.sin(a)*62],[Math.cos(a)*70,Math.sin(a)*70]],col,st===15?3:2.5);}
    c.restore();
    if(st===17&&progress>.99){c.beginPath();c.arc(x,25,77,-2.7,-.45);c.strokeStyle='#e3f5ee';c.lineWidth=1.7;c.stroke();}
  }
  const bicyclePaths={
    0:['M-130 25 L-66 -92 L0 0Z','M-66 -92 L94 -80 L0 0','M94 -80 L150 25'],
    1:['M-130 25 L-66 -92 L0 0Z','M-66 -92 L94 -80 L0 0','M94 -80 L150 25'],
    2:['M-130 25 Q-91 -23 -66 -92 L0 0Z','M-66 -92 Q14 -105 94 -80 L0 0','M94 -80 Q124 -36 150 25'],
    3:['M-130 25 Q-91 -30 -66 -92 L0 0Z','M-66 -92 Q8 -68 94 -80 L0 0','M94 -80 Q114 -25 150 25'],
    5:['M-130 25 L-66 -92 L0 0Z','M-66 -92 Q2 -83 94 -80 L0 0','M94 -80 L150 25'],
    6:['M-130 25 L-106 -13 L-94 -13 L-94 -38 L-80 -38 L-66 -92 L0 0Z','M-66 -92 L-40 -92 L-40 -84 L38 -84 L38 -80 L94 -80 L0 0','M94 -80 L111 -48 L122 -48 L122 -24 L150 25'],
    7:['M-130 25 Q-100 -27 -66 -92 L0 0Z','M-66 -92 C-6 -117 36 -69 94 -80 Q46 -51 0 0','M94 -80 Q98 -10 150 25'],
    8:['M-130 25 Q-99 -28 -66 -92 L0 0Z','M-66 -92 Q9 -74 94 -80 Q39 -45 0 0','M94 -80 Q108 -24 150 25'],
    9:['M-130 25 Q-104 -44 -66 -92 Q-49 -36 0 0Z','M-66 -92 Q-2 -119 94 -80 Q36 -55 0 0','M94 -80 Q108 -18 150 25'],
    10:['M-130 25 L-66 -92 L0 0Z','M-66 -92 L94 -80 L0 0','M94 -80 Q111 -18 150 25'],
    11:['M-130 25 Q-107 -38 -66 -92 Q-54 -31 0 0Z','M-66 -92 Q9 -117 94 -80 Q57 -31 0 0','M94 -80 Q102 -8 150 25'],
    12:['M-130 25 C-115 -17 -82 -47 -66 -92 Q-56 -46 0 0Z','M-66 -92 C-10 -108 31 -63 94 -80 C56 -57 42 -10 0 0','M94 -80 C121 -59 108 -5 150 25'],
    13:['M-130 25 L-66 -92 L0 0Z','M-66 -92 L94 -80 L0 0','M94 -80 L150 25'],
    15:['M-130 25 L-65 -90 L0 0Z','M-65 -90 H35 V-80 H95 L0 0','M95 -80 L150 25'],
    16:['M-130 25 L-66 -92 Q-34 -17 0 0Z','M-66 -92 Q-12 -23 38 -51 L94 -80 L0 0','M94 -80 Q108 -12 150 25'],
    17:['M-130 25 Q-104 -32 -66 -92 Q-61 -32 0 0Z','M-66 -92 Q-10 -18 38 -39 Q71 -53 94 -80 Q66 -10 0 0','M94 -80 Q94 -13 150 25'],
    18:['M-130 25 L-66 -92 Q-57 -29 0 0Z','M-66 -92 Q-12 -27 26 -37 L94 -80 Q54 -24 0 0','M94 -80 Q104 -17 150 25'],
    19:['M-130 25 L-66 -92 Q-48 -41 0 0Z','M-66 -92 Q10 -103 94 -80 Q65 -37 0 0','M94 -80 Q105 -13 150 25']
  };
  function bicycleFrame(c,st,pa,progress){
    const [ink,bird,shade,bill,pouch,frame]=pa,paths=bicyclePaths[st]||bicyclePaths[0];
    const w=st===14?2.4:st===0?5.5:st===2?4.2:fineArt(st)?5.1:st===9?8.5:7.5;
    c.save();if(progress<1)c.setLineDash([650*progress,100000]);
    for(const p of paths)K.path(c,p,null,ink,w);
    if(![0,2,13,14].includes(st))for(const p of paths)K.path(c,p,null,frame,st===3?1.5:fineArt(st)?2.7:4.4);
    c.restore();
    if(progress<.999)return;
    if([1,3,5,6,7,9,10].includes(st))for(const [x,y]of[[-66,-92],[94,-80],[0,0]]){
      K.circle(c,x,y,st===9?5:3.8,st===1||st===7||st===9?bill:shade||bird,ink,.8);K.circle(c,x,y,1,ink);
      if(st===3||st===5)for(let k=-1;k<=1;k++)K.line(c,[[x-4,y-7+k*3],[x+4,y-6+k*3]],ink,.9);
    }
    if(st===1){
      K.path(c,'M-35 -86 Q-20 -100 -5 -84 Q9 -95 24 -84',null,'#b58a38',2.3);
      K.path(c,'M3 -88 L4 -100 M-5 -98 L4 -104 L12 -98',null,'#397475',2);
    }
    if(st===2)K.path(c,'M-57 -76 l8 2 -4 8 10 3 -3 8 M25 -85 l8 3 7 -3 7 3 7 -3',null,ink,1.2);
    if(st===7){
      K.path(c,'M-41 -88 Q-22 -107 -6 -91 Q10 -75 28 -88 Q45 -103 63 -86',null,'#d6b96d',1.5);
      for(const [x,y]of[[-27,-94],[17,-88],[51,-89]]){K.circle(c,x,y,3.2,'#e6c97b',ink,.6);K.circle(c,x,y,1.2,'#a95c50');}
    }
    if(st===9)for(const [x,y]of[[-100,-24],[-78,-65],[-24,-53],[30,-89],[62,-84],[121,-23]]){K.circle(c,x,y,2.1,'#ddae6a');}
    if(st===10||st===18||st===16){
      // Mudguards, stays and a rack form an everyday city cycle, below the wings.
      c.beginPath();c.arc(-130,25,84,Math.PI*1.02,Math.PI*1.98);c.strokeStyle=ink;c.lineWidth=3;c.stroke();
      c.beginPath();c.arc(150,25,84,Math.PI*1.08,Math.PI*1.97);c.strokeStyle=st===18?'#e9c79e':ink;c.lineWidth=3;c.stroke();
      K.line(c,[[-201,-60],[-83,-60]],ink,3);K.line(c,[[-190,-59],[-130,25],[-99,-59]],ink,1.4);
    }
    if(st===5||st===10){
      K.path(c,'M-190 -64 L-190 -85 Q-165 -93 -138 -85 L-138 -64Z',st===10?'#9c7855':'#d0ba83',ink,1.4);
      for(let k=0;k<5;k++)K.line(c,[[-184+k*9,-85],[-184+k*9,-64]],ink,.8);
      K.path(c,'M-192 -73 Q-166 -68 -136 -73',null,ink,1);
    }
    if(st===15){K.rect(c,-181,-61,43,24,'#f2c56f',ink,3);K.rect(c,-172,-54,25,9,'#e96358');}
    if(st===16){K.path(c,'M-175 -79 Q-188 -96 -200 -85 Q-210 -73 -176 -55 Q-142 -76 -155 -87 Q-168 -97 -175 -79Z','#d5c3ec',ink,1.4);}
    if(st===19){
      K.path(c,'M-40 -84 Q3 -93 45 -85 M111 -21 L139 18',null,'#d9fcf1',1.2);
      for(const [x,y]of[[-66,-92],[94,-80],[0,0]]){K.rect(c,x-2,y-2,4,4,'#ffc982',null);}
    }
  }
  function leg(c,phase,pa,st,far){
    const [ink,bird,shade,bill,pouch]=pa;
    const h={x:-56,y:-112},p={x:31*Math.cos(phase),y:31*Math.sin(phase)};
    const dx=p.x-h.x,dy=p.y-h.y,d=Math.hypot(dx,dy),u=dx/d,v=dy/d,l1=88,l2=77;
    const a=(l1*l1-l2*l2+d*d)/(2*d),b=Math.sqrt(Math.max(0,l1*l1-a*a));
    const knee={x:h.x+a*u+b*v,y:h.y+a*v-b*u};
    c.save();if(far)c.globalAlpha*=st===14?.42:.67;
    const col=st===13?ink:st===14?ink:far?(shade||bill):bill;
    K.line(c,[[h.x,h.y],[knee.x,knee.y],[p.x-3,p.y-3]],ink,st===14?2:fineArt(st)?6.4:9);
    if(st!==14&&st!==13)K.line(c,[[h.x,h.y],[knee.x,knee.y],[p.x-3,p.y-3]],col,fineArt(st)?4.2:5.5);
    K.circle(c,knee.x,knee.y,st===14?2:4,st===14?null:col,ink,1);
    K.path(c,`M${p.x-10} ${p.y-5} Q${p.x-13} ${p.y+4} ${p.x-6} ${p.y+6} L${p.x+18} ${p.y+6} L${p.x+11} ${p.y+1} L${p.x+15} ${p.y-2} L${p.x+4} ${p.y-5}Z`,st===14?null:col,ink,st===14?1.5:1.7);
    if(st!==0&&st!==13&&st!==14){K.line(c,[[p.x+2,p.y-2],[p.x+8,p.y+3]],ink,.6);K.line(c,[[p.x+7,p.y-1],[p.x+13,p.y+4]],ink,.6);}
    K.line(c,[[p.x-11,p.y+8],[p.x+18,p.y+8]],ink,st===14?2:5);
    c.restore();
  }
  function roughen(c,st,pa){
    if(st===0||st===2){
      c.save();const clip=new Path2D(formFor(st).body);c.clip(clip);
      c.fillStyle=st===0?'rgba(237,192,125,.34)':st===2?'rgba(38,39,35,.42)':'rgba(250,246,229,.6)';
      for(let j=0;j<95;j++){let x=-143+K.rnd(j+511)*148,y=-229+K.rnd(j+133)*124;c.fillRect(x,y,st===8?10:K.rnd(j+933)*5+1,st===4?1.3:K.rnd(j+233)*2+1);}c.restore();
    }
  }
  /* R5-A: one continuous torso/neck/head/tail skin.
     No closed neck insert, no second sleeve-shaped gripping arm.
     R4 drivetrain, feet, eye aperture and view transforms remain unchanged. */
  const skinOutline=[
    ['M',-173,-153],
    ['C',-154,-162,-142,-174,-133,-184],
    ['C',-140,-211,-109,-231,-77,-224],
    ['C',-52,-220,-43,-199,-29,-197],
    ['C',-15,-195,6,-226,6,-246],
    ['C',5,-269,18,-286,39,-287],
    ['C',61,-289,77,-274,77,-254],
    ['C',77,-237,66,-230,53,-230],
    ['C',48,-230,47,-218,43,-200],
    ['C',39,-182,28,-152,7,-136],
    ['C',-9,-123,-24,-116,-39,-113],
    ['C',-49,-111,-59,-111,-70,-111],
    ['C',-94,-111,-113,-130,-126,-149],
    ['C',-139,-140,-154,-137,-170,-142],
    ['L',-154,-153],['Q',-164,-150,-173,-153],['Z']
  ];
  const wingContour=[
    ['M',-113,-183],
    ['C',-100,-201,-73,-201,-51,-183],
    ['C',-35,-167,-18,-154,5,-147],
    ['C',35,-140,70,-137,105,-135],
    ['Q',111,-139,116,-135],['Q',121,-130,115,-126],
    ['C',90,-124,61,-127,34,-130],
    ['C',8,-132,-13,-137,-34,-143],
    ['Q',-42,-142,-47,-147],['Q',-55,-145,-62,-151],
    ['C',-84,-157,-103,-170,-111,-178]
  ];
  function skinPose(t,phase,opts={},st=18){
    const ex=opts.expression||'',lean=K.clamp(opts.brakeLean||0)*.16;
    const nod=K.clamp(opts.headNod||0,-.30,.30)+(ex==='surprised'?-.04:0);
    const theta=nod+([1,13].includes(st)?0:Math.sin(phase)*.006);
    const ct=Math.cos(theta),sn=Math.sin(theta),hx=40,hy=-251;
    const tx=nod*16,ty=Math.abs(nod)*8+([1,13].includes(st)?0:Math.sin(phase)*.9);
    const H=[ct,sn,-sn,ct,hx-ct*hx+sn*hy+tx,hy-sn*hx-ct*hy+ty];
    const head=(x,y)=>[H[0]*x+H[2]*y+H[4],H[1]*x+H[3]*y+H[5]];
    function neckWeight(x,y){
      // The head is rigid; deformation fades out along the neck into the shoulder.
      // Back, abdomen and saddle anchor never inherit the head transform.
      return K.smoother((-y-174)/57)*K.smoother((x+48)/45);
    }
    function deform(x,y){let w=neckWeight(x,y),p=head(x,y);return[x+(p[0]-x)*w,y+(p[1]-y)*w];}
    const local=(x,y)=>{const p=deform(x,y);return[p[0]+lean*(p[1]+112),p[1]];};
    return{lean,H,head,deform,local,theta,nod,press:K.clamp(opts.bellPress||0)};
  }
  function makeSkinPath(commands,pose,deform=true,close=false){
    const p=new Path2D(),map=(x,y)=>deform?pose.deform(x,y):[x,y];
    for(const [op,...q] of commands){
      const a=[];for(let j=0;j<q.length;j+=2)a.push(...map(q[j],q[j+1]));
      if(op==='M')p.moveTo(...a);else if(op==='L')p.lineTo(...a);
      else if(op==='C')p.bezierCurveTo(...a);else if(op==='Q')p.quadraticCurveTo(...a);else if(op==='Z')p.closePath();
    }
    if(close)p.closePath();return p;
  }
  const svgSkin=commands=>commands.map(q=>q[0]+q.slice(1).join(' ')).join(' ');
  const canonicalSkin=svgSkin(skinOutline),canonicalWing=svgSkin(wingContour)+' Z';
  function paintPath(c,p,fill,ink,lw=1){if(fill){c.fillStyle=fill;c.fill(p);}if(ink){c.strokeStyle=ink;c.lineWidth=lw;c.stroke(p);}}
  function featherStroke(c,cmd,pose,col,lw=1,alpha=1){c.save();c.globalAlpha*=alpha;paintPath(c,makeSkinPath(cmd,pose),null,col,lw);c.restore();}
  function unifiedSurface(c,pose,st,pa,skin){
    const [ink,bird,shade]=pa;
    c.save();c.clip(skin);
    if(![0,2,3,4,8,9,13,14,15,19].includes(st)){
      // Continuous light across the breast and neck, not separately shaded pieces.
      const wash=c.createLinearGradient(-90,-237,31,-111);
      wash.addColorStop(0,bird);wash.addColorStop(.55,bird);wash.addColorStop(1,shade||bird);
      c.globalAlpha=.5;c.fillStyle=wash;c.fill(skin);c.globalAlpha=1;
    }
    if([0,2].includes(st)){
      c.fillStyle=st===0?'rgba(240,197,139,.25)':'rgba(29,38,28,.28)';
      for(let j=0;j<170;j++){const x=-177+K.rnd(j+511)*263,y=-288+K.rnd(j+133)*177;c.fillRect(x,y,1+K.rnd(j+911)*2.3,.7+K.rnd(j+233));}
    }
    if(![0,13,14,15].includes(st)){
      const faint=st===2?'#58624a':st===11?'#f4e9a4':st===19?'#92b9ba':ink;
      const w=[3,7,10,19].includes(st)?.55:st===11?1.3:.8;
      // All strokes follow curvature; nothing caps the neck or shoulder.
      [
        [['M',-127,-186],['Q',-117,-209,-91,-213]],
        [['M',-105,-215],['Q',-82,-218,-63,-207]],
        [['M',-122,-155],['Q',-108,-131,-88,-124]],
        [['M',-115,-155],['Q',-102,-137,-88,-132]],
        [['M',-32,-189],['C',-5,-203,19,-220,20,-243]],
        [['M',-20,-182],['C',6,-195,29,-218,29,-237]],
        [['M',-8,-169],['C',15,-181,30,-204,35,-222]],
        [['M',22,-268],['Q',18,-255,21,-246]],
        [['M',30,-277],['Q',38,-281,46,-279]]
      ].forEach(q=>featherStroke(c,q,pose,faint,w,st===3?.32:st===8?.45:.37));
      // Tail coverts lead out from the rump without a closed tail-root line.
      featherStroke(c,[['M',-132,-158],['Q',-144,-153,-157,-149]],pose,faint,w,.45);
      featherStroke(c,[['M',-130,-165],['Q',-145,-163,-159,-158]],pose,faint,w,.4);
    }
    if(st===7){
      for(let j=0;j<28;j++){
        const x=-124+(j%7)*12,y=-206+Math.floor(j/7)*18;
        featherStroke(c,[['M',x,y],['Q',x+3,y+6,x+8,y+7]],pose,'#a4966e',.45,.48);
      }
    }
    if(st===11||st===12){
      const col=st===11?['#f4e39b','#c4bc76','#79a4ad']:['#e1c28d','#bb9065','#8b9b97'];
      [
        [['M',-121,-196],['Q',-107,-215,-90,-215]],
        [['M',-111,-200],['Q',-97,-211,-76,-208]],
        [['M',-106,-137],['Q',-90,-119,-73,-119]],
        [['M',1,-172],['Q',25,-191,31,-217]],
        [['M',15,-248],['Q',13,-266,29,-277]],
        [['M',39,-282],['Q',57,-283,67,-269]]
      ].forEach((q,j)=>featherStroke(c,q,pose,col[j%3],2+j%2,.75));
    }
    if(st===9){
      for(let row=0;row<5;row++)for(let j=0;j<7;j++){
        const x=-119+j*13,y=-208+row*16,p=pose.deform(x,y);
        K.path(c,`M${p[0]} ${p[1]-2} q3 2 0 4 q-3 -2 0 -4Z`,'#e7be7d');
      }
      for(let j=0;j<7;j++){const p=pose.deform(20,-258+j*11);K.circle(c,...p,1.8,'#e8c380');}
    }
    refinedPlumage(c,pose,st,pa,'body');
    c.restore();
  }

  // R6: layered coverts follow the continuous skin rather than partition it.
  // Each style gets a different mark vocabulary; the repaired skeleton is untouched.
  function refinedPlumage(c,pose,st,pa,region){
    if([0,13,14,16].includes(st))return;
    const [ink,bird,shade,bill]=pa,oil=st===11||st===12,wood=st===10,mini=st===7;
    const base=st===2?'#65715b':oil?(st===11?'#7d9692':'#927c65'):mini?'#9e8b61':ink;
    const light=oil?(st===11?'#fff1ad':'#eed6a1'):mini?'#ead59a':bird||'#dfedda';
    const alpha=oil?.68:mini?.55:st===3?.25:st===4||st===8?.30:.31;
    const width=oil?1.75:st===15?3:mini?.46:wood?.62:.52;
    function mark(x,y,dx,dy,w=1){
      const d=[['M',x,y],['Q',x+dx*.16-dy*.28,y+dy*.16+dx*.28,x+dx,y+dy]];
      featherStroke(c,d,pose,base,width*w,alpha);
      if(oil)featherStroke(c,[['M',x+.7,y-1.1],['Q',x+dx*.25,y+dy*.35-1.1,x+dx-.7,y+dy-.7]],pose,light,.8,alpha*.75);
    }
    if(region==='body'){
      // Scapular and rump feathers grow away from the shoulder; breast tapers downward.
      for(let row=0;row<4;row++)for(let k=0;k<6;k++){
        const x=-128+k*10+row*2,y=-202+row*11+Math.sin(k*.6)*3;
        mark(x,y,9+row,5.3+k*.24);
      }
      for(let k=0;k<12;k++){
        const x=-124+k*5.4,y=-150+Math.sin(k/11*Math.PI)*23;
        mark(x,y,8.5,5.4-k*.28,.9);
      }
      for(let row=0;row<5;row++)for(let k=0;k<3;k++){
        const x=4+k*5+row*2.6,y=-225+row*11-k*1.5;
        mark(x,y,4.6-row*.6,9.4,.8);
      }
      // Tail quills are rooted in the rump and never closed at their base.
      for(let j=0;j<4;j++)mark(-133,-171+j*5,-21-j*2,11-j*3,1.1);
      if(st===1||st===6){
        for(let j=0;j<7;j++)featherStroke(c,[['M',-124+j*12,-207+j%2*2],['L',-119+j*12,-201],['L',-115+j*12,-205]],pose,st===1?'#ae8a43':'#637f62',.7,.6);
      }
    }else{
      for(let row=0;row<3;row++)for(let k=0;k<7;k++){
        const x=-104+k*7.8+row*1.5,y=-190+row*7+k*2.5;
        mark(x,y,11,6.8,.95);
      }
      for(let j=0;j<5;j++){
        const y=-171+j*4.3;
        featherStroke(c,[['M',-85+j*4,y],['C',-58+j*5,y+8,-37+j*4,-145+j*.9,19+j*8,-135+j*.45]],pose,base,width,alpha);
      }
      if(mini){
        for(let j=0;j<8;j++){
          const q=pose.deform(-94+j*11,-176+j*3.35);
          K.circle(c,q[0],q[1],1.4,'#b99d54');K.circle(c,q[0]-.35,q[1]-.4,.35,'#fff0bb');
        }
      }
      if(st===9){
        for(let j=0;j<8;j++){
          const q=pose.deform(-99+j*10,-183+j*3);
          K.path(c,`M${q[0]} ${q[1]-3} q5 3 0 6 q-5 -3 0 -6Z`,'#e6b76e');
        }
      }
      if(wood){for(let j=0;j<8;j++)mark(-89+j*6,-165+j*2,10,3,.65);}
    }
  }

  function body(c,t,phase,pa,st,opts){
    const f=formFor(st),[ink,bird,shade,bill,pouch]=pa;
    const outline=st===14,shadow=st===13,lineart=st===3||st===19;
    const lw=st===3?1.45:st===7?1.45:st===4?1.8:st===10?1.75:st===8?2.45:st===0?2.2:outline?1.65:st===2?1.2:1.9;
    const build=st===19?K.clamp(opts.build===undefined?1:opts.build):1;
    const skinP=stage(build,.48,.88),wingP=stage(build,.78,1);
    const pose=skinPose(t,phase,opts,st),skin=makeSkinPath(skinOutline,pose);
    const bfill=outline?null:bird;
    // Torso leaning is around the seated pelvis. The belly anchor is unchanged.
    c.save();c.transform(1,0,pose.lean,1,112*pose.lean,0);
    traceReveal(c,skinP,920,()=>{
      paintPath(c,skin,skinP>=1?bfill:null,ink,lw);
      if(skinP>=1&&!outline&&!shadow)unifiedSurface(c,pose,st,pa,skin);
    });
    // Features use exactly the same rigid end transform as the skin's head.
    if(skinP>.65){
      c.save();c.transform(...pose.H);
      if(![0,6,9,13,14].includes(st)){
        // One small swept tuft, not three disconnected hair spikes.
        K.path(c,'M24 -283 Q14 -295 10 -294 Q23 -292 33 -285 M33 -285 Q27 -298 22 -298 Q35 -294 41 -286',null,ink,st===8?2:1.1);
      }
      if(st===6){K.path(c,'M22 -282 L13 -303 L24 -296 L30 -311 L38 -294 L49 -302 L49 -282Z','#3d8172',ink,1.3);K.circle(c,32,-284,3.3,'#cb9549',ink,.8);}
      if(st===9){K.path(c,'M20 -282 Q0 -305 19 -310 Q33 -310 29 -297 L36 -314 L43 -299 L51 -312 L57 -281Z',bird,ink,1.3);}
      const ex=opts.expression||'',gape=(ex==='shout'||ex==='scream')?Math.max(0,Math.sin(t*TAU*3))*9:ex==='surprised'?2:0;
      c.save();c.translate(65,-249);c.rotate(gape*.012);c.translate(-65,249);
      K.path(c,f.pouch,outline||skinP<1?null:pouch,ink,lw);
      if(skinP>=1)surfaceDetails(c,st,'pouch');c.restore();
      K.path(c,f.bill,outline||skinP<1?null:bill,ink,lw);
      if(skinP>=1){surfaceDetails(c,st,'bill');nativePlumage(c,st,'bill');}
      if(skinP>=1&&![0,2,8,9,13,14,15,16].includes(st)){
        c.save();c.clip(new Path2D(f.bill));c.globalAlpha=.42;
        K.path(c,'M85 -256 Q91 -258 97 -255',null,ink,.7);
        for(let j=0;j<5;j++)K.path(c,`M${104+j*12} ${-255+j*1.7} l${10-j*.7} ${.7+j*.1}`,null,st===11?'#fff0a8':'#f5ddaa',st===11?1.1:.5);
        c.restore();c.save();c.clip(new Path2D(f.pouch));c.globalAlpha=.22;
        for(let j=0;j<7;j++)K.path(c,`M${85+j*13} ${-244+j*.5} Q${88+j*13} -226 ${95+j*11} -219`,null,ink,.55);
        c.restore();
      }

      if(st!==13&&skinP>.82){
        K.path(c,'M75 -249 Q129 -246 189 -240',null,ink,.85);
        if(!outline&&st!==0)K.path(c,'M84 -255 Q129 -253 170 -246',null,st===2?'#fff4d3':'rgba(255,248,213,.65)',1.1);
        eye(c,t,opts,st,ink);
      }
      c.restore();
    }
    c.restore();
    // Near wing: ONE shoulder-to-grip surface. The wrist remains on the bar;
    // the shoulder follows the leaning torso with a smooth spatial weight.
    const wp={deform(x,y){let q=K.smoother((100-x)/155);return[x+pose.lean*(y+112)*q,y];}};
    const wing=makeSkinPath(wingContour,wp,true,true),wingStroke=makeSkinPath(wingContour,wp);
    traceReveal(c,wingP,560,()=>{
      paintPath(c,wing,outline||wingP<1?null:bird,null);
      paintPath(c,wingStroke,null,ink,lw); // No closing line across the wing root.
      if(wingP>=1&&!shadow){
        c.save();c.clip(wing);
        if(!outline&&!lineart&&![0,2,8].includes(st)){
          const wash=c.createLinearGradient(-65,-194,-40,-136);wash.addColorStop(0,bird);wash.addColorStop(1,shade||bird);
          c.globalAlpha=.48;c.fillStyle=wash;c.fill(wing);c.globalAlpha=1;
        }
        const strokes=[
          [['M',-104,-180],['C',-79,-179,-68,-163,-43,-156],['Q',3,-138,63,-132]],
          [['M',-100,-173],['C',-75,-169,-61,-155,-39,-150],['Q',3,-136,49,-131]],
          [['M',-92,-165],['Q',-63,-154,-47,-151]],
          [['M',-106,-186],['Q',-91,-195,-77,-189]],
          [['M',-87,-187],['Q',-75,-186,-66,-177]],
          [['M',-70,-180],['Q',-58,-175,-52,-166]],
          [['M',36,-139],['Q',72,-133,105,-131]]
        ];
        strokes.forEach((q,j)=>featherStroke(c,q,wp,outline?ink:st===11?(j%2?'#8eaaab':'#f7e29a'):ink,outline?.8:st===11?1.6:[3,7].includes(st)?.6:.85,outline?.8:.42));
        if(st===7||st===9||st===1){
          for(let j=0;j<8;j++){
            const p=wp.deform(-96+j*12,-177+j*3.3);
            K.circle(c,p[0],p[1],st===9?2.3:1.6,st===9?'#e7bc74':'#c4a353');
          }
        }
        if(st===6)featherStroke(c,[['M',-104,-181],['L',-84,-169],['L',-64,-160],['L',-42,-151]],wp,'#488676',3,.8);
        refinedPlumage(c,wp,st,pa,'wing');
        c.restore();
      }
      // A small leading primary presses the bell; it grows from the wingtip.
      if(pose.press>0){const y=-135-13*pose.press;
        K.path(c,`M102 -130 Q99 ${y-1} 105 ${y} Q110 ${y+2} 108 ${y+5} L112 -128`,outline?null:bird,ink,lw*.8);
      }
    });
  }
  P.characterSkin={revision:'R6-continuous-layered-plumage',path:canonicalSkin,wing:canonicalWing,commands:skinOutline,
    pose:skinPose,pathAt(t,phase,opts={},st=18){return makeSkinPath(skinOutline,skinPose(t,phase,opts,st));},
    mapAt(x,y,t,phase,opts={},st=18){return skinPose(t,phase,opts,st).local(x,y);},
    grip:[113,-130],seat:[-70,-111],headLocal:[48,-260],closedPartCount:1};

  function render(c,t,opts,st){
    const pa=paints[st], [ink,bird,shade,bill,pouch,frame,tyre]=pa;
    // Pixel/puppet surface styles must not quantize the physical drivetrain.
    let qt=t;
    if(opts.phaseTime!==undefined)qt=opts.phaseTime;
    const phase=Number.isFinite(opts.crankAngle)?opts.crankAngle:qt*TAU;
    const wheelRatio=Number.isFinite(opts.gearRatio)?opts.gearRatio:Number.isFinite(opts.wheelRatio)?opts.wheelRatio:P.drive?P.drive.ratio:2.25;
    const wheelAngle=Number.isFinite(opts.wheelAngle)?opts.wheelAngle:phase*wheelRatio;
    const build=st===19?K.clamp(opts.build===undefined?1:opts.build):1;
    const frameP=stage(build,.17,.40),driveP=stage(build,.31,.47),legP=stage(build,.40,.60);
    c.lineJoin='round';c.lineCap='round';
    if(st===14){c.shadowColor=`rgba(75,255,164,${opts.scopeVisibility===undefined?1:opts.scopeVisibility})`;c.shadowBlur=11;}
    if(build>.99&&opts.shadow!==false&&![0,2,3,4,8,9,13,14,15].includes(st)){K.ellipse(c,10,106,205,10,st===17?'rgba(26,14,72,.3)':'rgba(35,39,32,.14)');}
    wheel(c,-130,Number.isFinite(opts.rearWheelAngle)?opts.rearWheelAngle:wheelAngle,pa,st,stage(build,0,.18));wheel(c,150,Number.isFinite(opts.frontWheelAngle)?opts.frontWheelAngle:wheelAngle,pa,st,stage(build,.08,.26));
    // Far crank and far leg go behind the bicycle frame.
    reveal(c,driveP,[-40,-40,80,80],()=>K.line(c,[[0,0],[-31*Math.cos(phase),-31*Math.sin(phase)]],ink,st===14?1.6:3.5));
    reveal(c,legP,[-72,-119,175,173],()=>leg(c,phase+Math.PI,pa,st,true));
    bicycleFrame(c,st,pa,frameP);
    reveal(c,frameP,[-100,-150,260,65],()=>{
      K.line(c,[[-66,-92],[-70,-111]],ink,st===14?2:6);
      K.path(c,'M-94 -111 Q-73 -116 -44 -110 Q-38 -103 -51 -102 L-88 -105Z',st===14?null:ink,ink,st===14?1.5:1);
      K.path(c,'M94 -80 L96 -118 Q97 -131 109 -132 L133 -132 Q146 -131 144 -118 L136 -109',null,ink,st===14?2:5.6);
      if(st!==13&&st!==14)K.path(c,'M96 -115 L98 -124 Q99 -129 107 -129',null,shade||bird,2);
      K.line(c,[[122,-132],[139,-131]],st===14?ink:tyre,st===14?2:8);
      K.circle(c,108,-137,6,st===14?null:bill,ink,1.3);
    },false);
    reveal(c,driveP,[-151,-36,190,93],()=>{
      chain(c,phase,ink,st===14?ink:shade||bird,st,opts.gearRatio,opts.rearWheelAngle);
      K.line(c,[[0,0],[31*Math.cos(phase),31*Math.sin(phase)]],ink,st===14?2:4.5);
    },false);
    reveal(c,legP,[-72,-119,175,173],()=>leg(c,phase,pa,st,false));
    if(driveP>.9)K.circle(c,0,0,5,st===14?null:bill,ink,1.3);
    body(c,t,phase,pa,st,opts);
    if(st===9){
      c.shadowBlur=0;K.line(c,[[-62,-154],[-73,188]],'#69452a',3);K.line(c,[[106,-130],[160,190]],'#69452a',2.5);
      K.circle(c,-62,-154,4,'#d9b670',ink,1);K.circle(c,106,-130,4,'#d9b670',ink,1);
    }
    if(st===14){
      c.shadowBlur=0;c.globalAlpha*=.25;K.path(c,'M-150 100 Q-40 106 135 103',null,'#56ffc0',1);
    }
  }
  P.drawRider=function(c,t,opts={}){
    const st=sty(opts.style===undefined?18:opts.style),x=opts.x===undefined?800:opts.x,y=opts.y===undefined?600:opts.y,s=opts.scale===undefined?1.2:opts.scale;
    if(st===14&&P.scopeSignalAmount){const visibility=1-P.scopeSignalAmount(t-89);if(visibility<.00001)return;opts=Object.assign({},opts,{scopeVisibility:visibility});}
    if(opts.lookTarget){
      const tx=Array.isArray(opts.lookTarget)?opts.lookTarget[0]:opts.lookTarget.x,ty=Array.isArray(opts.lookTarget)?opts.lookTarget[1]:opts.lookTarget.y;
      if(Number.isFinite(tx)&&Number.isFinite(ty)){
        const a=-(opts.tilt||0),dx=(tx-x)/s,dy=(ty-y)/s,lx=dx*Math.cos(a)-dy*Math.sin(a)-48,ly=dx*Math.sin(a)+dy*Math.cos(a)+259,n=Math.max(1,Math.hypot(lx,ly));
        opts=Object.assign({},opts,{gazeX:lx/n,gazeY:ly/n});
      }
    }
    c.save();c.globalAlpha*=opts.alpha===undefined?1:opts.alpha;
    if(st===14&&P.scopeSignalAmount)c.globalAlpha*=1-P.scopeSignalAmount(t-89);
    c.translate(x,y);c.rotate(opts.tilt||0);c.scale(s,s);
    if(st===15||st===16){
      const pix=st===15?5:2.6,key='rig-pixel-'+st;
      let surface=P.cache.get(key);if(!surface){surface=P.makeCanvas(Math.ceil(500/pix),Math.ceil(440/pix));P.cache.set(key,surface);}
      const b=surface.getContext('2d');b.setTransform(1,0,0,1,0,0);b.clearRect(0,0,surface.width,surface.height);b.scale(1/pix,1/pix);b.translate(230,315);render(b,t,opts,st);
      c.imageSmoothingEnabled=false;c.drawImage(surface,-230,-315,500,440);
    }else render(c,t,opts,st);
    c.restore();
  };
  P.riderGeometry={
    crank:[0,0],rearWheel:[-130,25],frontWheel:[150,25],wheelRadius:77,
    pedalRadius:31,hip:[-56,-112],saddle:[-70,-111],handlebar:[113,-130],
    limbLengths:[88,77],paths:shape,forms,bicyclePaths,palettes:paints,styleNames:names,
    buildRanges:{rearWheel:[0,.18],frontWheel:[.08,.26],frame:[.17,.40],chain:[.31,.47],legs:[.40,.60],body:[.48,.70],head:[.61,.91],wings:[.78,1]},
    footAt(t,far=false){const a=t*TAU+(far?Math.PI:0);return [31*Math.cos(a),31*Math.sin(a)];},
    wheelAngleAt(phaseTime,ratio=driveRig.ratio){return phaseTime*TAU*ratio;}
  };
})();
