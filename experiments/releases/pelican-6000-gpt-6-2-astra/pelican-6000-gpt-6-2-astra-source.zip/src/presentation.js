/* Original brief: 5 + 20 × 6 + 12 = 137 seconds. All clocks use story seconds. */
P.timelineSpec={intro:5,chapterSeconds:Array(20).fill(6),outro:12};
P.storyDuration=137;
P.duration=137;
P.journeyEnd=125;
P.chapterStarts=Array.from({length:20},(_,i)=>5+i*6);
P.storyTimeAt=t=>K.clamp(t,0,P.duration);
P.outputTimeAt=t=>K.clamp(t,0,P.duration);
P.storyRateAt=()=>1;
P.chapterAtOutput=t=>t<5?-1:t>=125?20:Math.min(19,Math.floor((t-5)/6));
P.presentationRate=1;
P.renderStoryAt=P.renderAt;
P.renderAt=function(c,t){
  P.outputTime=K.clamp(t,0,P.duration-.001);
  P.renderStoryAt(c,P.outputTime);
};
