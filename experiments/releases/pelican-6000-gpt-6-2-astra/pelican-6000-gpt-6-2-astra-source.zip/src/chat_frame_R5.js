/* R5-A viewport contract: the card, clipping and rider all use the same rectangle.
   A visible exit, not accidental overflow, is the only state that opens its edge. */
(()=>{
 const reference={left:-220,right:232,top:-326,bottom:114,contact:102};
 function fit(view,{scale=.70,ground,margin=18}={}){
  const safe=Math.min(scale,(view.w-2*margin)/(reference.right-reference.left),(view.h-2*margin)/(reference.bottom-reference.top));
  const floor=ground===undefined?view.y+view.h-margin-(reference.bottom-reference.contact)*safe:ground;
  const maxForTop=(floor-view.y-margin)/(reference.contact-reference.top),s=Math.min(safe,maxForTop);
  const xMin=view.x+margin-reference.left*s,xMax=view.x+view.w-margin-reference.right*s;
  if(!(s>0&&xMax>=xMin))throw new Error('Media viewport is too small for the rider.');
  return Object.freeze({view:Object.freeze({...view}),scale:s,ground:floor,y:floor-reference.contact*s,xMin,xMax,margin,reference});
 }
 function bounds(p){return {x:p.x+reference.left*p.scale,y:p.y+reference.top*p.scale,w:(reference.right-reference.left)*p.scale,h:(reference.bottom-reference.top)*p.scale};}
 function contained(b,v,eps=.01){return b.x>=v.x-eps&&b.y>=v.y-eps&&b.x+b.w<=v.x+v.w+eps&&b.y+b.h<=v.y+v.h+eps;}
 P.mediaViewport={fit,bounds,contained,reference};
 if(!P.scenes[16])return;
 const original=P.scenes[16],v={x:549,y:416,w:588,h:271},layout=fit(v,{scale:.54,ground:675,margin:10});
 function h(u,p0,p1,m0,m1,d){return(2*u*u*u-3*u*u+1)*p0+(u*u*u-2*u*u+u)*d*m0+(-2*u*u*u+3*u*u)*p1+(u*u*u-u*u)*d*m1;}
 function xAt(t){const v=1600/6;if(t<2.6)return h(K.clamp(t/2.6),0,850,v,0,2.6);if(t<=3.6)return 850;return h(K.clamp((t-3.6)/2.4),850,1600,0,v,2.4);}
 function state(t){const age=t-2.48,dx=age>0&&age<.34?Math.sin(age*82)*4*(1-K.ease(age/.34)):0;return {dx,dy:-dx*.35,entry:1-K.smoother((t-2.15)/.30),exit:K.smoother((t-3.56)/.38),opened:t>=3.94,x:xAt(t),layout};}
 function rounded(c,x,y,w,h,r,fill,stroke){c.beginPath();c.roundRect(x,y,w,h,r);if(fill){c.fillStyle=fill;c.fill();}if(stroke){c.strokeStyle=stroke;c.lineWidth=1;c.stroke();}}
 function label(c,s,x,y,size=13,col='#52768a',align='left'){K.text(c,s,x,y,size,col,align,'sans');}
 function frame(c,t,front=false){
  const q=state(t),x=v.x,y=v.y,r=x+v.w,b=y+v.h;c.save();c.translate(q.dx,q.dy);
  if(!front){
   rounded(c,548,383,590,317,5,'#f1f8fc','#9ebfd1');
   K.rect(c,x,y,v.w,v.h,K.gradient(c,[x,y],[x,b],[[0,'#d8e9e5'],[.52,'#ecf1de'],[1,'#c9d9bd']]));
   c.save();c.beginPath();c.rect(x,y,v.w,v.h);c.clip();
   K.circle(c,1074,450,17,'#f0dea5');
   K.path(c,'M549 592 Q625 503 712 576 Q796 490 883 570 Q987 510 1137 582 V690 H549Z','#b5cbbd');
   K.path(c,'M549 631 Q659 578 774 625 Q887 567 996 624 Q1064 599 1137 626 V690 H549Z','#cad7ba');
   for(let j=0;j<4;j++){const xx=591+j*147;K.line(c,[[xx,671],[xx,639]],'#819a7b',1.1);K.path(c,`M${xx} 651 q-12 -23 -19 -13 q-2 14 19 17 q14 -18 20 -9 q-2 12 -20 10Z`,'#a0ba8e');}
   K.rect(c,x,675,v.w,12,'#d2c7a4');K.line(c,[[x,675],[r,675]],'#99a38b',1.2);
   for(let j=0;j<13;j++)K.line(c,[[x+12+j*45,682],[x+24+j*45,682]],'#b9ae8e',.7);
   c.restore();
   label(c,q.opened?'pelican.html · 原文件':'鹈鹕骑行.gif',561,405,14,'#426d84');
   if(!q.opened)label(c,'预览',740,405,12,'#8299a5');
   rounded(c,1003,388,125,24,4,q.opened?'#deeee2':'#f6fcff',q.opened?'#8bb69a':'#a3c5d6');
   label(c,q.opened?'已打开 ✓':'打开原文件',1066,405,12,q.opened?'#4b7b60':'#477f9d','center');
   label(c,q.opened?'出口已打开 →':'表情框内播放',562,696,10,'#79928c');
   // Cover the old "saved" toast; it must not compete with the actual opening cue.
   rounded(c,1148,384,190,98,5,'#f7fbff','#dbe7ed');
   label(c,'文件信息',1160,406,12,'#6c8c9e');
   label(c,q.opened?'类型：原文件':'类型：动态表情',1160,431,12,'#88a0ac');
   label(c,q.opened?'播放：继续前进':'播放：框内预览',1160,457,12,'#88a0ac');
   if(t>=3.20&&t<3.95){const u=K.smoother((t-3.20)/.30),px=K.lerp(1220,1068,u),py=K.lerp(486,403,u);K.path(c,`M${px} ${py} l3 17 5 -5 7 -1Z`,'#fff','#416c82',1.1);if(t>=3.50&&t<3.68){const a=(t-3.50)/.18;c.save();c.globalAlpha=1-a;K.circle(c,1069,404,6+15*a,null,'#c9a359',1.3);c.restore();}}
   // An authored short bridge grows before the front wheel reaches the frame.
   if(q.exit>0){const extent=170*q.exit;K.rect(c,r,675,extent,9,'#d2c7a4');K.line(c,[[r,675],[r+extent,675]],'#99a38b',1.2);}
  }else{
   // Foreground frame rails stay in front of the rider. The opening is explicit.
   K.line(c,[[x-1,y],[r+1,y]],'#c5dce6',1);
   const rail=(xx,op)=>{const top=y+(b-y)*op;K.line(c,[[xx,y],[xx,Math.max(y, b-(b-y)*op)]],'#9bbfce',3);if(op>.001&&op<.999)K.rect(c,xx-4,b-(b-y)*op-2,8,5,'#d0e1df','#91b5c1');};
   rail(x-1,q.entry);rail(r+1,q.exit);
   if(q.exit>.99){K.path(c,'M1144 656 h18 l-5 -4 M1162 656 l-5 4',null,'#729c82',1.4);}
  }
  c.restore();
 }
 P.scenes[16]=Object.assign({},original,{
  travelX:xAt,
  pose(t){const p=original.pose(t);return Object.assign(p,{x:xAt(t),scale:layout.scale,elevation:0,gestureTilt:0});},
  riderScreenClip(t){const q=state(t);if(t<.75)return null;if(q.exit>.985)return{x:v.x,y:0,w:1600-v.x,h:900};const l=q.entry>.02?0:v.x,r=q.exit>.985?1600:v.x+v.w;return{x:l+q.dx,y:v.y+q.dy,w:r-l,h:v.h};},
  riderScreenPose(p,t){const q=state(t);return Object.assign({},p,{x:p.x+q.dx,y:p.y+q.dy});},
  draw(c,t){original.draw.call(this,c,t);frame(c,t,false);},
  foreground(c,t,a,p){frame(c,t,true);},
  mediaViewport:v,mediaState:state
 });
 if(P.interfaceTiming)P.interfaceTiming.chat=Object.assign(P.interfaceTiming.chat,{open:3.56,gateReady:3.94,viewport:v});
 P.chatFrameContract={layout,state,xAt,revision:'R5A-frame-fit'};
 if(P.invalidateMotion)P.invalidateMotion();
})();
