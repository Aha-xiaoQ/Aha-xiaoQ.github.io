/* The travelling naturalist. Parts are drawn in crank coordinates. The two
   axles, pedal pins and bell are the same landmarks used by the whole film.
   The artist changes plates and tools; the courier keeps her machine. */
(()=>{
'use strict';
const tau=2*Math.PI, C=K.clamp;
const plates=[
// ink, sunlit feather, flight feathers, bill ridge, pouch, enamel, trim, luggage
 ['#562e22','#c67b4d','#713a2d','#d79859','#a65134','#723729','#daac76','#a65b3c'],
 ['#283d3a','#f0dd9e','#21595a','#efc360','#b85c39','#217b77','#e9bb54','#9e4c36'],
 ['#dedbc8','#272f2a','#c4c7ad','#d9d5bb','#444d40','#687561','#e3dcc2','#38433b'],
 ['#39382d','#f7f0db','#515449','#d8bb89','#c5aa89','#6b6c56','#e3d7b5','#978b73'],
 ['#34483e','#e4dec8','#495949','#c7b789','#97a28a','#506449','#c5c0a1','#92866a'],
 ['#3d443b','#f2e7c7','#4c5d60','#e2b163','#ce8451','#366854','#dcc181','#936846'],
 ['#3f3632','#eadab2','#374c4b','#d29c53','#b45c42','#347368','#e4bd6d','#974d39'],
 ['#2e3d45','#ffedc6','#365b68','#e7af50','#d88a68','#236c61','#d9b36a','#a45040'],
 ['#303728','#eee8d5','#414638','#c5b38c','#a79c85','#555844','#c6c0a6','#898875'],
 ['#472a1d','#c29555','#633b23','#e7b652','#b37637','#7a4928','#f3ce81','#925b31'],
 ['#233e51','#ece4bf','#3a5668','#d4a14d','#bf7557','#306365','#d0b777','#945d45'],
 ['#1b3556','#efc76c','#2c536e','#ffe398','#cd8052','#317d7f','#e9c46b','#a35442'],
 ['#3b3847','#e6ba79','#55526a','#edb55b','#ba6345','#486a6a','#d7ae62','#965647'],
 ['#262329','#262329','#262329','#262329','#262329','#262329','#262329','#262329'],
 ['#ace9ad','#8ecb9d','#63c497','#b2edb2','#83d5ad','#82d7a5','#c0f0bd','#8ac498'],
 ['#293747','#fff0c0','#485975','#f7bc56','#da7952','#3a967e','#edcf89','#a85e52'],
 ['#383654','#fff0c8','#5d5c78','#e9b75f','#d38c65','#6b6793','#e2c390','#a17072'],
 ['#39304c','#f6d9cf','#575a83','#fed2a2','#e48ea6','#4c8e9a','#f2afc0','#935b83'],
 ['#293d46','#ffefd5','#455969','#f7b960','#de8660','#276f69','#edcf82','#ad6151'],
 ['#31585b','#edebcd','#56767d','#f9c47a','#d79371','#52948c','#f1ce94','#986b60']
];
const paths={
 body:'M -193 -165 Q -203 -175 -216 -184 Q -184 -186 -175 -190 L -212 -204 Q -183 -207 -159 -203 L -190 -219 Q -153 -217 -122 -236 C -93 -257 -64 -254 -41 -241 Q -25 -234 -11 -239 C -2 -242 4 -252 4 -259 Q 0 -262 -12 -258 Q -7 -267 2 -272 L -20 -269 Q -10 -280 7 -284 L -16 -282 Q -1 -294 17 -295 Q 31 -307 49 -302 C 67 -300 76 -286 77 -272 L 62 -246 Q 43 -238 40 -218 C 41 -205 61 -190 55 -164 C 52 -139 24 -119 -2 -112 Q -23 -104 -58 -105 Q -112 -108 -138 -130 Q -162 -141 -193 -165 Z',
 wing:'M -45 -230 C -63 -243 -91 -243 -114 -233 Q -131 -225 -146 -217 Q -168 -208 -194 -207 Q -180 -198 -163 -199 Q -178 -189 -195 -187 Q -182 -178 -159 -181 Q -164 -170 -183 -167 Q -167 -159 -144 -166 Q -150 -155 -166 -151 Q -148 -146 -125 -157 Q -127 -146 -145 -139 C -117 -138 -89 -150 -67 -161 C -46 -171 -25 -191 -25 -207 Q -24 -222 -45 -230 Z',
 pouch:'M 59 -260 Q 112 -260 200 -241 C 184 -233 168 -227 151 -213 C 136 -199 111 -182 85 -184 C 60 -185 48 -199 46 -219 Q 44 -238 59 -260 Z',
 bill:'M 59 -276 C 96 -278 154 -265 201 -248 Q 211 -244 205 -236 Q 203 -231 198 -232 L 200 -240 Q 144 -246 99 -249 Q 76 -249 59 -253 Q 53 -260 59 -276 Z',
 crown:'M -12 -282 Q 7 -293 17 -293 Q 40 -309 62 -292 Q 72 -285 74 -277 Q 58 -284 46 -280 Q 29 -277 18 -267 Q 22 -278 26 -282 Q 9 -278 -4 -271 Q 5 -280 12 -285 Z',
 bib:'M 38 -247 Q 32 -223 45 -206 Q 69 -178 42 -150 Q 46 -165 37 -175 Q 39 -161 31 -148 Q 34 -173 22 -183 Q 26 -168 21 -157 Q 19 -180 9 -186 C 4 -196 9 -213 19 -225 Q 28 -233 38 -247 Z',
 gripWing:'M -38 -203 C -2 -209 24 -189 40 -176 Q 54 -160 66 -151 C 81 -144 101 -141 111 -141 Q 116 -141 117 -138 Q 111 -134 101 -134 Q 106 -131 108 -129 Q 95 -128 84 -134 Q 87 -131 89 -128 Q 66 -132 55 -141 Q 57 -136 56 -135 Q 26 -144 1 -158 L -42 -175 Z',
 step:'M -66 -94 C -52 -56 -43 -14 -2 -17 C 31 -20 64 -63 89 -92',
 beam:'M -4 -2 C 35 -12 67 -52 98 -87',
 rearStay:'M -130 25 L -66 -94 M -130 25 L 0 0 L -66 -94',
 fork:'M 94 -97 C 103 -62 122 -3 137 15 Q 141 22 150 25',
 backMud:'M -210 41 C -220 -24 -167 -73 -109 -57 Q -71 -46 -52 -9',
 frontMud:'M 69 55 C 46 -15 104 -74 167 -57 Q 194 -51 216 -28',
 rack:'M -212 -58 L -90 -58 M -199 -57 L -132 25 L -99 -57',
 bag:'M -203 -54 L -141 -55 Q -135 -52 -136 -43 L -141 -6 Q -144 1 -153 2 L -194 1 Q -201 0 -202 -8 Z',
 lamp:'M 111 -103 L 117 -113 Q 127 -121 144 -117 L 147 -114 L 147 -99 Q 132 -95 120 -97 Z'
};
// One cached list of authored Bézier commands drives print, screen and X/Y.
const commandCache=new Map(),pathCache=new Map(),sampleCache=new Map();
function commands(svg){
 if(!commandCache.has(svg)){
  const result=[],pieces=svg.match(/[MLQCZ][^MLQCZ]*/g);
  for(const piece of pieces)result.push([piece[0],...(piece.slice(1).match(/-?\d+(?:\.\d+)?/g)||[]).map(Number)]);
  commandCache.set(svg,result);
 }
 return commandCache.get(svg);
}
function shape(svg){if(!pathCache.has(svg))pathCache.set(svg,new Path2D(svg));return pathCache.get(svg);}
function deformed(svg,pose){
 const path=new Path2D();
 for(const [op,...points] of commands(svg)){
  const a=[];for(let j=0;j<points.length;j+=2)a.push(...pose.local(points[j],points[j+1]));
  if(op==='M')path.moveTo(...a);else if(op==='L')path.lineTo(...a);else if(op==='Q')path.quadraticCurveTo(...a);else if(op==='C')path.bezierCurveTo(...a);else path.closePath();
 }
 return path;
}
function draw(c,svg,fill,stroke,w=1){
 const s=typeof svg==='string'?shape(svg):svg;
 if(fill){c.fillStyle=fill;c.fill(s);}
 if(stroke){c.strokeStyle=stroke;c.lineWidth=w;c.stroke(s);}
}
function sampled(id){if(!sampleCache.has(id))sampleCache.set(id,M.sampleSvg(paths[id]));return sampleCache.get(id);}
function circle(c,x,y,r,fill,edge,w=1){K.circle(c,x,y,r,fill,edge,w);}
function line(c,a,col,w){K.line(c,a,col,w);}
function tube(c,s,p,w){draw(c,s,null,p[0],w+2.5);draw(c,s,null,p[5],w);if(w>5)draw(c,s,null,p[6],1.1);}
const oldPose=P.characterSkin.pose;
function poseAt(t,a,o,st){
 const p=oldPose(t,a,o,st);
 // Ink meets the pouch at the cheek. Pouch, bill and eye rotate as one solid
 // head; the neck softness fades into the breast before it reaches the saddle.
 const local=(x,y)=>{
  const q=p.head(x,y),w=Math.max(K.smoother((-y-169)/71)*K.smoother((x+32)/37),K.smoother((x-39)/15)*K.smoother((-y-158)/35));
  const yy=y+(q[1]-y)*w;return[x+(q[0]-x)*w+p.lean*(yy+112),yy];
 };
 return{...p,local};
}
Object.assign(P.characterSkin,{revision:'R8-naturalist-courier',path:paths.body,wing:paths.wing,pose:poseAt,
 pathAt(t,a,o={},st=18){return deformed(paths.body,poseAt(t,a,o,st));},mapAt(x,y,t,a,o={},st=18){return poseAt(t,a,o,st).local(x,y);}});
Object.assign(P.riderGeometry.paths,{body:paths.body,wing:paths.wing,bill:paths.bill,pouch:paths.pouch});
const feathers=[
 'M -45 -227 C -76 -233 -105 -203 -165 -202 C -140 -185 -81 -193 -45 -217 Z',
 'M -43 -215 C -74 -214 -116 -187 -166 -181 C -127 -167 -72 -186 -43 -209 Z',
 'M -43 -205 C -75 -195 -102 -173 -145 -166 Q -98 -157 -42 -197 Z',
 'M -44 -193 Q -73 -179 -113 -153 Q -81 -151 -44 -185 Z'
];
const pad='M -46 -231 C -62 -240 -84 -235 -98 -220 Q -109 -207 -117 -200 Q -107 -198 -99 -203 Q -102 -196 -109 -191 Q -96 -191 -86 -201 Q -85 -194 -90 -190 Q -69 -194 -55 -205 Q -40 -212 -40 -223 Z';
const scallops=[];
for(let row=0;row<3;row++)for(let i=0;i<5;i++){
 const x=-54-i*8-row*7,y=-227+row*8+i*2;
 scallops.push('M '+x+' '+y+' Q '+(x-5)+' '+(y+11)+' '+(x-13)+' '+(y+12)+' Q '+(x-9)+' '+(y+7)+' '+(x-9)+' '+(y+4));
}
const wingRibs=['M -153 -199 Q -99 -202 -55 -222','M -155 -181 Q -101 -189 -58 -210','M -134 -164 Q -91 -177 -54 -199','M -103 -152 Q -76 -165 -53 -185'];
const wash=(c,a,b,colors)=>K.gradient(c,a,b,colors);
const painterly=new Set([5,7,10,11,12,16,17,18,19]);
const hatch=[];
for(let i=0;i<24;i++){
 const j=i%8,row=Math.floor(i/8),x=-126+j*10-5*row,y=-229+(j-3.4)**2*.37+row*7;
 hatch.push('M '+x+' '+y+' Q '+(x-2)+' '+(y+3.6)+' '+(x-7)+' '+(y+4.8));
}
function featherPen(c,pose,st,p){
 const [ink,white,black,,,frame,trim]=p;
 if(st===8){ // Dry-brush breaches in three broad washes.
  for(const s of ['M -171 -197 Q -110 -202 -82 -221','M -158 -183 Q -105 -187 -67 -212','M -139 -168 Q -108 -174 -81 -185']){
   draw(c,deformed(s,pose),null,white,1.9);
  }return;
 }
 if(st===9){
  for(let row=0;row<3;row++)for(let i=0;i<7;i++){
   const x=-64-i*13-row*2,y=-222+row*9+i*3.1;
   c.save();const a=pose.local(x,y);c.translate(...a);c.rotate(-.43);
   draw(c,'M -4 0 Q 0 -5 5 0 Q 0 5 -4 0 Z',trim);c.restore();
  }return;
 }
 if(st===0||st===2||st===6){
  c.save();c.globalAlpha=st===2?.75:.63;
  for(let i=0;i<13;i++){const x=-165+i*8,y=-180-i*2.8;
   let s='M '+x+' '+y+' L '+(x-5)+' '+(y+6)+' L '+(x+3)+' '+(y+3);
   draw(c,deformed(s,pose),null,st===2?p[1]:trim,st===0?1.7:1.15);}
  c.restore();return;
 }
 if(st===1||st===7){
  for(let i=0;i<7;i++){const x=-152+i*12,y=-182-i*3.8;
   const s='M '+x+' '+y+' Q '+(x-2)+' '+(y+8)+' '+(x-10)+' '+(y+8)+' Q '+(x-9)+' '+(y+1)+' '+x+' '+y+' Z';
   draw(c,deformed(s,pose),st===1?trim:p[3],ink,.65);
  }
 }
 c.save();c.globalAlpha=st===3?.64:st===11?.78:.41;
 for(let i=0;i<hatch.length;i++){draw(c,deformed(hatch[i],pose),null,i%4===0?trim:black,st===11?2.5:st===3?.7:1.05);}
 c.restore();
}
function breastStrokes(c,pose,st,p){
 if([0,13,15].includes(st))return;
 const [ink,white,black,,,,trim]=p;
 const breast=['M 17 -218 Q 12 -199 23 -190','M 14 -210 Q 12 -194 26 -183','M 22 -207 Q 20 -193 32 -183',
 'M 32 -187 Q 44 -175 40 -162','M 35 -184 Q 42 -175 40 -167','M 13 -153 Q 9 -139 -6 -132',
 'M 18 -157 Q 18 -146 5 -138','M 11 -147 Q 5 -136 -13 -132','M -12 -133 Q -27 -124 -43 -124',
 'M -20 -129 Q -39 -120 -53 -121','M -50 -118 Q -66 -116 -81 -124'];
 c.save();c.globalAlpha=st===3?.56:st===2?.72:.46;
 breast.forEach((s,i)=>draw(c,deformed(s,pose),null,st===2?white:i%3===0?trim:black,st===11?2.0:1.05));c.restore();
}
function headBasis(c,p){
 const H=p.H,l=p.lean;c.transform(H[0]+l*H[1],H[1],H[2]+l*H[3],H[3],H[4]+l*(H[5]+112),H[5]);
}
function drawBird(c,t,a,o,st,p,build){
 const pose=poseAt(t,a,o,st),[ink,white,black,bill,pouch]=p,shadow=st===13;
 c.save();
 if(build<.99){c.beginPath();c.rect(-224,-320,460*C((build-.42)/.54),221);c.clip();}
 // The far wing rests on the handlebar. The breast occludes the shoulder and
 // elbow; only a short fan of primary tips is visible beyond the breast.
 draw(c,deformed(paths.gripWing,pose),shadow?ink:black,ink,1.5);
 if(!shadow){
  draw(c,deformed('M 23 -174 Q 42 -145 107 -137 Q 88 -137 68 -142 Q 36 -147 24 -159 Z',pose),p[6]);
  draw(c,deformed('M 44 -149 Q 71 -138 104 -135 M 57 -142 Q 82 -135 104 -133',pose),null,white,1);
 }
 const body=deformed(paths.body,pose);
 const modelled=painterly.has(st);
 const down=modelled?wash(c,[-98,-231],[36,-121],[[0,white],[.48,white],[.83,p[6]],[1,pouch]]):white;
 draw(c,body,down,ink,st===0?2.7:1.7);
 if(!shadow){
  c.save();c.clip(body);
  c.globalAlpha=st===2?.72:st===8?.67:.40;
  draw(c,deformed('M -169 -190 Q -131 -130 -57 -123 Q -9 -119 37 -150 C 20 -111 -13 -99 -68 -100 L -147 -123 Z',pose),black);
  c.globalAlpha=.62;draw(c,deformed(paths.bib,pose),st===2?ink:st===3||st===8?p[6]:pouch);
  c.restore();
  breastStrokes(c,pose,st,p);
 }
 const wing=deformed(paths.wing,pose);draw(c,wing,modelled?wash(c,[-78,-234],[-124,-152],[[0,p[6]],[.46,black],[1,ink]]):black,ink,1.5);
 if(!shadow){
  c.save();c.clip(wing);
  for(let i=0;i<feathers.length;i++){
   c.save();c.globalAlpha=[.64,.52,.45,.45][i];draw(c,deformed(feathers[i],pose),i%2?p[5]:p[6]);c.restore();
   draw(c,deformed(wingRibs[i],pose),null,ink,st===11?2:1.05);
  }
  draw(c,deformed(pad,pose),modelled?wash(c,[-83,-239],[-69,-190],[[0,white],[.65,p[6]],[1,black]]):white,ink,.85);
  if(st!==0&&st!==8&&st!==9){c.save();c.globalAlpha=.52;for(const s of scallops)draw(c,deformed(s,pose),null,black,st===11?1.2:.7);c.restore();}
  featherPen(c,pose,st,p);
  c.restore();
 }
 c.save();headBasis(c,pose);
 draw(c,paths.pouch,modelled?wash(c,[93,-258],[108,-184],[[0,p[7]],[.21,pouch],[.67,bill],[1,pouch]]):pouch,ink,1.7);
 if(!shadow){
  c.save();c.clip(shape(paths.pouch));
  draw(c,'M 48 -234 Q 59 -186 92 -190 C 123 -191 157 -224 184 -230 Q 148 -201 120 -185 Q 61 -166 46 -208 Z',st===3||st===8?p[7]:p[7]);
  for(let j=0;j<12;j++){
   const x=61+j*10,y=-248+j*.55,tx=62+j*8,ty=-197-Math.abs(j-4)*2;
   c.globalAlpha=.41;draw(c,'M '+x+' '+y+' Q '+(x-9)+' '+(y+17)+' '+tx+' '+ty,null,j%3?ink:p[6],j%3?.7:1.4);
  }c.restore();
 }
 draw(c,paths.bill,modelled?wash(c,[84,-279],[84,-247],[[0,pouch],[.42,bill],[.76,white],[1,bill]]):bill,ink,1.7);
 if(!shadow){
  draw(c,'M 73 -270 C 108 -271 164 -256 194 -247 Q 152 -255 113 -259 L 76 -260 Z',white);
  draw(c,'M 64 -254 Q 121 -252 199 -241',null,ink,1.55);
  draw(c,'M 189 -251 Q 207 -249 207 -241 Q 208 -236 199 -232 L 201 -241 Z',st===2?ink:p[7]);
  draw(c,paths.crown,st===2?ink:p[6]);draw(c,'M -1 -284 Q 14 -291 27 -290 M 7 -281 Q 19 -287 30 -286 M 31 -295 Q 44 -298 52 -294',null,white,1.25);
  draw(c,'M 35 -262 C 37 -274 47 -279 57 -278 Q 69 -277 75 -271 L 71 -254 Q 61 -253 54 -249 Q 46 -245 42 -254 Z',st===2?black:pouch,ink,1.05);
  const e=P.riderEyeState(t,o,st);let open=e.open;
  K.ellipse(c,49,-262,7.9,Math.max(.7,7.6*open),white,ink,1.65);
  if(open>.19){
   const ex=49+C((e.px-48)*1.8,-2.5,2.5),ey=-262+C((e.py+260)*1.8,-1.7,1.7);
   c.save();c.beginPath();c.ellipse(49,-262,7.1,Math.max(1,6.7*open),0,0,tau);c.clip();
   circle(c,ex,ey,4.8,st===8?white:p[5],ink,1.1);circle(c,ex+.15,ey,2.65,ink);circle(c,ex+.85,ey-1.15,1.05,white);c.restore();
  }
  draw(c,'M 37 -268 Q 45 -275 55 -274 M 61 -268 Q 64 -270 70 -268',null,ink,1.25);
 }c.restore();c.restore();
}
const wood=[0,1,2,6,7,9],minimal=[0,2,4,8,13];
function drawWheel(c,x,theta,st,p){
 const [ink,white,black,, ,frame,trim]=p,shadow=st===13,carved=wood.includes(st);
 c.save();c.translate(x,25);c.rotate(theta);
 circle(c,0,0,72,null,ink,10);
 if(!shadow){circle(c,0,0,72.1,null,trim,5.2);circle(c,0,0,68.2,null,frame,2);}
 const count=st===0?5:st===1?6:st===6?4:st===7?12:st===9?10:carved?8:16,w=carved?6.2:1.7;
 for(let j=0;j<count;j++){
  c.save();c.rotate(tau*j/count);
  if(st===1||st===6||st===7||st===9){
   // The silhouette of the wheel is cut by its maker. The openings let the
   // background show through as the wheel turns about its actual bearing.
   const petal=st===1?'M-3 -8 Q-21 -40 -12 -61 L0 -70 L12 -61 Q20 -43 3 -8 Q9 -38 0 -52 Q-8 -35 -3 -8Z'
    :st===6?'M-8 -6 L-12 -26 L-4 -27 L-4 -57 L-16 -57 L-16 -65 L10 -65 L10 -18 L3 -6Z'
    :st===7?'M-3 -9 C-14 -33 -8 -53 0 -67 C8 -55 12 -39 4 -24 Q7 -45 0 -55 Q-5 -34 -3 -9Z'
    :'M-4 -8 C-1 -28 -14 -40 -12 -55 Q-10 -63 -1 -68 Q-5 -55 3 -51 Q17 -40 8 -27 Q4 -34 0 -35 Q5 -22 2 -8Z';
   draw(c,petal,frame,ink,1.1);
   if(st===1||st===7)circle(c,0,-60,2.5,trim);
  }else if(carved){
   draw(c,'M -4 -8 Q -10 -30 -4 -64 L -1 -69 L 4 -67 Q 1 -36 5 -12 Z',shadow?ink:frame,ink,1.25);
   if(!shadow)draw(c,'M -1 -18 Q -4 -40 0 -64',null,trim,1.3);
  }else {line(c,[[6,-6],[0,-68]],shadow?ink:black,w);line(c,[[-5,-6],[12,-66]],shadow?ink:frame,1);}
  c.restore();
 }
 circle(c,0,0,carved?12:8.5,shadow?ink:trim,ink,2);circle(c,0,0,4.2,shadow?ink:frame);
 c.restore();
}
function baggage(c,st,p){
 const [ink,white,,bill,,,trim,bag]=p,shadow=st===13;
 // The same dispatch tube moves from reed basket, to pierced leather, to
 // stitched leather and finally a lacquered hard case. Its clasp travels.
 draw(c,paths.rack,null,ink,4.1);
 if(st<=8){
  const wicker='M -209 -55 Q -174 -66 -136 -55 L -146 -10 Q -167 1 -192 -6 Z';draw(c,wicker,bag,ink,2);
  c.save();c.clip(shape(wicker));
  for(let j=0;j<8;j++){const x=-218+j*12;draw(c,'M '+x+' -62 Q '+(x+10)+' -38 '+(x+13)+' 0',null,trim,2);}
  for(let j=0;j<7;j++){const y=-54+j*7;draw(c,'M -216 '+y+' Q -171 '+(y+6)+' -130 '+(y-3),null,st===2?ink:p[6],1.6);}
  c.restore();draw(c,'M -209 -55 Q -174 -66 -136 -55',null,ink,3.4);
  if(st===7||st===1){draw(c,'M -175 -59 L -162 -59 L -162 -14 L -169 -9 L -175 -14 Z',p[5],ink,1);circle(c,-168.5,-30,2.8,trim);}
 }else if(st===9){
  draw(c,'M -205 -55 Q -180 -62 -138 -54 L -142 -26 Q -147 -15 -159 -13 L -172 -1 L -181 -12 Q -199 -12 -203 -24 Z',bag,ink,2);
  for(let j=0;j<5;j++)for(let k=0;k<2;k++){let x=-194+j*10,y=-43+k*11;draw(c,'M '+(x-3)+' '+y+' Q '+x+' '+(y-5)+' '+(x+3)+' '+y+' Q '+x+' '+(y+5)+' '+(x-3)+' '+y+' Z',trim);}
 }else{
 draw(c,paths.bag,bag,ink,2.4);
 draw(c,'M -205 -55 Q -173 -61 -136 -56 L -138 -38 Q -168 -30 -201 -37 Z',shadow?ink:trim,ink,1.6);
 if(!shadow){
  draw(c,'M -195 -55 L -189 -55 L -188 -5 L -194 -5 Z M -158 -55 L -152 -55 L -155 -5 L -160 -5 Z',bag,ink,1.05);
  for(const x of [-193,-158]){K.rect(c,x-2,-33,9,7,trim,ink,1);K.rect(c,x,-31,5,3,bag);}
  draw(c,'M -197 -11 Q -174 -6 -146 -11',null,trim,1);
 }
 }
 draw(c,'M -209 -66 Q -209 -72 -204 -73 L -143 -72 Q -138 -71 -139 -66 Q -138 -61 -144 -61 L -206 -61 Z',shadow?ink:white,ink,1.6);
 for(const x of [-195,-155])line(c,[[x,-72],[x+1,-61]],shadow?ink:bag,3.2);
 if(st===5){
  // Three parcels go to market with the rider: sloping lid, twine, two jars.
  draw(c,'M-214 -74 L-214 -91 Q-227 -100 -218 -110 Q-214 -116 -216 -118 H-210 Q-213 -114 -207 -110 Q-198 -100 -202 -96 L-204 -74Z',bag,ink,1.4);
  draw(c,'M-201 -74 V-99 H-177 V-74Z',white,ink,1.4);draw(c,'M-190 -99 V-74 M-201 -90 H-177',null,bag,2);
 }else if(st===7){
  // Palace courier's little fringed awning. Its silhouette survives even
  // when the gilt fabric pattern has disappeared at small scale.
  draw(c,'M-215 -53 L-219 -122 M-150 -60 L-153 -119',null,ink,2.9);
  draw(c,'M-234 -116 Q-212 -119 -192 -147 Q-176 -125 -137 -121 Q-151 -108 -163 -116 Q-177 -106 -190 -115 Q-209 -105 -216 -115 Q-224 -109 -234 -116Z',p[5],trim,2);
  for(let j=0;j<7;j++){let x=-228+j*14;line(c,[[x,-115],[x+1,-108]],trim,1.4);circle(c,x+1,-107,1.8,bill);}
 }else if(st===10){
  draw(c,'M-199 -71 L-212 -123 M-191 -70 L-204 -126',null,ink,2.2);
  draw(c,'M-232 -116 Q-224 -127 -205 -132 Q-188 -130 -176 -118 Q-199 -115 -232 -116Z',p[3],ink,1.3);
  for(let j=0;j<6;j++)line(c,[[-205,-131],[-228+j*9,-117]],trim,.7);
 }
}
function drawBike(c,st,p){
 const [ink,white,black,bill,pouch,frame,trim,bag]=p,shadow=st===13;
 for(const s of [paths.backMud,paths.frontMud]){draw(c,s,null,ink,6.7);draw(c,s,null,shadow?ink:trim,3.4);}
 for(const s of ['M -130 25 L -209 12 M -130 25 L -185 -39','M 150 25 L 75 43 M 150 25 L 208 -33'])draw(c,s,null,ink,1.6);
 tube(c,paths.rearStay,p,3.7);tube(c,paths.beam,p,8.5);tube(c,paths.step,p,7.8);tube(c,paths.fork,p,5.8);
 draw(c,'M -66 -94 L -71 -108 M 89 -98 L 99 -77',null,ink,9);
 draw(c,'M -70 -108 Q -86 -105 -97 -110 Q -100 -121 -84 -121 Q -65 -121 -54 -116 L -40 -113 Q -38 -108 -47 -107 Z',shadow?ink:bag,ink,1.8);
 draw(c,'M 91 -95 L 88 -108 Q 85 -121 103 -127 L 114 -131 L 130 -130 Q 142 -127 138 -118',null,ink,5.2);
 draw(c,'M 115 -131 L 132 -129',null,shadow?ink:bag,7.2);
 draw(c,'M 130 -128 C 158 -107 100 -85 112 -61',null,ink,1.2);
 circle(c,108,-137,6,shadow?ink:trim,ink,1.8);draw(c,'M 106 -130 L 104 -125 M 112 -139 L 118 -141',null,ink,1.3);
 line(c,[[113,-84],[122,-102]],ink,3.6);
 draw(c,paths.lamp,shadow?ink:frame,ink,1.8);K.ellipse(c,146,-108,3.2,8,trim,ink,1.1);
 if(!shadow){draw(c,'M 120 -111 Q 129 -117 141 -114',null,white,1.7);draw(c,'M 95 -93 L 99 -86 M -62 -83 L -60 -77',null,trim,2.4);
  draw(c,'M 141 -116 L 142 -100',null,trim,2);draw(c,'M 118 -104 Q 129 -101 139 -103',null,ink,1);}
 baggage(c,st,p);
}
const chain=P.chainGeometry(),chainLine=Array.from({length:84},(_,i)=>chain.at(chain.length*i/83));
function chainset(c,a,st,p){
 const [ink,white,black,bill,,,trim]=p;
 line(c,chainLine,ink,3.8);
 if(st!==13){c.save();c.setLineDash([2.6,4.2]);c.lineDashOffset=-a*24;line(c,chainLine,trim,1.35);c.restore();}
 circle(c,0,0,21.8,null,ink,4.1);
 c.save();c.rotate(a);for(let j=0;j<5;j++){c.rotate(tau/5);draw(c,'M -3 0 Q -7 -10 -2 -20 L 4 -20 L 3 -4 Z',st===13?ink:trim,ink,.8);}c.restore();
 circle(c,0,0,5,st===13?ink:bill,ink,1.1);
}
function joints(a){
 const f=[31*Math.cos(a),31*Math.sin(a)],h=[-56,-112],dx=f[0]-h[0],dy=f[1]-h[1],d=Math.hypot(dx,dy),u=dx/d,v=dy/d;
 const m=(88*88-77*77+d*d)/(2*d),n=Math.sqrt(Math.max(0,88*88-m*m));
 return[h,[h[0]+m*u+n*v,h[1]+m*v-n*u],f];
}
function leg(c,a,st,p,far){
 const [hip,knee,foot]=joints(a),[x,y]=foot,[ink,white,black,bill,pouch,,,bag]=p;
 const col=st===13?ink:far?bag:pouch;
 line(c,[hip,knee,[x-3,y-5]],ink,far?7:9);line(c,[hip,knee,[x-3,y-5]],col,far?4.6:6.3);
 const dx=knee[0]-hip[0],dy=knee[1]-hip[1];
 c.save();c.translate(...hip);c.rotate(Math.atan2(dy,dx));
 draw(c,'M -8 -11 Q 15 -14 42 -5 L 38 -2 L 44 0 L 37 2 L 40 5 Q 19 12 -10 11 Z',st===13?ink:far?black:white,ink,1.15);
 c.restore();
 if(st!==13&&st!==0){for(let i=1;i<6;i++){const u=i/7,px=knee[0]*(1-u)+(x-3)*u,py=knee[1]*(1-u)+(y-5)*u;line(c,[[px-1.8,py-1.1],[px+1.8,py+.3]],far?ink:bag,.8);}}
 c.save();c.translate(x,y);
 draw(c,'M -7 -11 Q -4 -10 1 -6 L 21 -1 Q 23 1 17 2 L 26 6 L 15 7 L 21 11 Q 10 11 2 8 L -12 6 Q -16 2 -10 -4 Z',far?col:st===13?ink:p[3],ink,1.5);
 if(st!==13){draw(c,'M -3 -3 L 17 5 M -4 0 L 12 8',null,ink,1.1);}
 draw(c,'M -12 8 L 19 8',null,ink,3.6);c.restore();
}
function appearing(c,value,start,end,drawPart){
 if(value<=start)return;c.save();
 const f=C((value-start)/(end-start));if(f<1){c.beginPath();c.rect(-231,-320,466*f,446);c.clip();}
 drawPart();c.restore();
}
function traces(o){
 const phase=o.crankAngle??(o.phaseTime||0)*tau;
 const pose=poseAt(o.phaseTime||0,phase,o,14),res=[];
 for(const id of ['body','wing','gripWing','pouch','bill'])for(const line of sampled(id)){
  if(id==='pouch'||id==='bill'){res.push(line.map(([x,y])=>{const v=pose.head(x,y);return[v[0]+pose.lean*(v[1]+112),v[1]];}));}
  else res.push(line.map(([x,y])=>pose.local(x,y)));
 }
 for(const id of ['step','beam','fork','rearStay','backMud','frontMud','rack','bag','lamp'])res.push(...sampled(id));
 for(const [x,theta]of [[-130,o.rearWheelAngle??o.wheelAngle??0],[150,o.frontWheelAngle??o.wheelAngle??0]]){
  res.push(Array.from({length:53},(_,i)=>[x+77*Math.cos(tau*i/52),25+77*Math.sin(tau*i/52)]));
  for(let j=0;j<8;j++){let a=theta+tau*j/8;res.push([[x,25],[x+67*Math.cos(a),25+67*Math.sin(a)]]);}
 }
 res.push([[-66,-94],[-71,-110],[-93,-114],[-45,-112]],[[92,-96],[89,-114],[110,-130],[134,-130]],chainLine);
 for(const a of [phase,phase+Math.PI]){const [h,k,f]=joints(a);res.push([h,k,f,[f[0]+17,f[1]+5]],[f,[0,0]]);}return res;
}
P.touringRig={revision:'R8',paths,plates,traces,joints};
const spriteColors=plates[15].map(col=>[1,3,5].map(k=>parseInt(col.slice(k,k+2),16))),spriteLUT=new Map();
function inkPixels(ctx,w,h){
 const im=ctx.getImageData(0,0,w,h),d=im.data;
 for(let i=0;i<d.length;i+=4){
  if(d[i+3]<108){d[i+3]=0;continue;}
  const key=(d[i]>>3)*1024+(d[i+1]>>3)*32+(d[i+2]>>3);
  let rgb=spriteLUT.get(key);
  if(!rgb){let nearest=Infinity;
   const red=(d[i]&248)+4,green=(d[i+1]&248)+4,blue=(d[i+2]&248)+4;
   for(const col of spriteColors){let e=(col[0]-red)**2+1.4*(col[1]-green)**2+.8*(col[2]-blue)**2;
    if(e<nearest){nearest=e;rgb=col;}}
   spriteLUT.set(key,rgb);
  }
  d[i]=rgb[0];d[i+1]=rgb[1];d[i+2]=rgb[2];d[i+3]=255;
 }
 ctx.putImageData(im,0,0);
}
function render(c,t,o,st){
 let p=plates[st],a=o.crankAngle??(o.phaseTime??t)*tau,rot=o.wheelAngle??a*(o.gearRatio??P.drivetrain.ratio),q=st===19?(o.build??1):1;
 if(st===1&&P.riderGeometry.palettes[1][0]==='#9f6841')p=['#8b6847','#c4a477','#a5855e','#bc9768','#ac8258','#ac8a62','#caac7e','#9c7955'];
 c.lineJoin='round';c.lineCap='round';
 if(st===14){const acq=1-(P.scopeSignalAmount?.(t-89)||0);if(acq<.001)return;c.globalAlpha*=acq;
  let rays=M.traceContours(o);c.shadowBlur=6;c.shadowColor='#8cfaad';c.beginPath();for(const poly of rays){c.moveTo(...poly[0]);for(let k=1;k<poly.length;k++)c.lineTo(...poly[k]);}c.strokeStyle='#99efab';c.lineWidth=1.5;c.stroke();return;}
 if(q>.99&&o.shadow!==false&&!minimal.includes(st)&&st!==3&&st!==9){K.ellipse(c,3,105,197,7,'rgba(30,37,33,.12)');}
 appearing(c,q,0,.2,()=>drawWheel(c,-130,o.rearWheelAngle??rot,st,p));appearing(c,q,.08,.27,()=>drawWheel(c,150,o.frontWheelAngle??rot,st,p));
 appearing(c,q,.32,.59,()=>{line(c,[[0,0],joints(a+Math.PI)[2]],p[0],4);leg(c,a+Math.PI,st,p,true);});
 appearing(c,q,.17,.43,()=>drawBike(c,st,p));
 appearing(c,q,.31,.53,()=>{chainset(c,a,st,p);line(c,[[0,0],joints(a)[2]],p[0],5);});
 appearing(c,q,.4,.60,()=>leg(c,a,st,p,false));
 if(q>.42)drawBird(c,t,a,o,st,p,q);
 if(st===9){line(c,[[-63,-173],[-79,180]],p[0],3.4);line(c,[[111,-130],[154,181]],p[0],2.5);circle(c,-63,-173,3.7,p[6],p[0],1.4);}
}
P.drawRider=function(c,t,o={}){
 const st=typeof o.style==='number'?o.style:Math.max(0,P.riderGeometry.styleNames.indexOf(o.style??'short'));
 if(!(o.alpha??1))return;
 if(o.lookTarget){
  const [tx,ty]=Array.isArray(o.lookTarget)?o.lookTarget:[o.lookTarget.x,o.lookTarget.y],s=o.scale??1.2,r=-(o.tilt||0);
  if(Number.isFinite(tx)&&Number.isFinite(ty)){const dx=(tx-(o.x??800))/s,dy=(ty-(o.y??600))/s;
   const x=dx*Math.cos(r)-dy*Math.sin(r)-49,y=dx*Math.sin(r)+dy*Math.cos(r)+262,len=Math.max(1,Math.hypot(x,y));o={...o,gazeX:x/len,gazeY:y/len};}
 }
 c.save();c.translate(o.x??800,o.y??600);c.rotate(o.tilt||0);c.scale(o.scale??1.2,o.scale??1.2);
 if(st===15||st===16||st===13){
  // Single composited transparent shadow, so overlapping feather polygons
  // cannot create darker joints. Pixel plates get their own sampling pitch.
  const k=st===15?4.5:st===16?2.6:1.4,key='R8-rider-plate-'+st;
  let cv=P.cache.get(key);if(!cv){cv=P.makeCanvas(Math.ceil(480/k),Math.ceil(448/k));P.cache.set(key,cv);}
  const ctx=cv.getContext('2d',{willReadFrequently:st===15});ctx.setTransform(1,0,0,1,0,0);ctx.clearRect(0,0,cv.width,cv.height);
  ctx.save();ctx.scale(1/k,1/k);ctx.translate(237,320);render(ctx,t,o,st);ctx.restore();
  if(st===15)inkPixels(ctx,cv.width,cv.height);
  c.globalAlpha*=o.alpha??1;c.imageSmoothingEnabled=(st===13);c.drawImage(cv,-237,-320,cv.width*k,cv.height*k);
 }else{c.globalAlpha*=o.alpha??1;render(c,t,o,st);}
 c.restore();
};
})();
