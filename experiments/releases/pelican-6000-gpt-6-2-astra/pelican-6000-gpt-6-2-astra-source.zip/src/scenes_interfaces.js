/* R8: connected interface scenes. A fictional 2009 chat desktop, a genuine portrait live
   viewport, and the original Pelican Studio workbench share one rider and one road clock. */
(()=>{
 const old={16:P.scenes[16],18:P.scenes[18],19:P.scenes[19]},I={};
 I.round=(c,x,y,w,h,r,fill,stroke,lw=1)=>{c.beginPath();c.roundRect(x,y,w,h,r);if(fill){c.fillStyle=fill;c.fill();}if(stroke){c.strokeStyle=stroke;c.lineWidth=lw;c.stroke();}};
 I.icon=function(c,type,x,y,s=1,col='#777'){
  c.save();c.translate(x,y);c.scale(s,s);c.lineCap='round';c.lineJoin='round';
  const p=d=>K.path(c,d,null,col,1.7);
  if(type==='chat'){I.round(c,-11,-8,22,16,5,null,col,1.7);p('M-5 8 l-4 5 1 -7');K.circle(c,-5,0,1,col);K.circle(c,0,0,1,col);K.circle(c,5,0,1,col);}
  else if(type==='contacts'){K.circle(c,-2,-5,5,null,col,1.6);p('M-12 10 Q-11 1 -2 1 Q7 1 8 10 M9 -8 Q15 -7 14 -2 M11 2 Q17 4 17 10');}
  else if(type==='folder')p('M-11 -7 H-3 L0 -3 H12 V10 H-11Z');
  else if(type==='search'){K.circle(c,-2,-2,7,null,col,1.8);p('M3 3 L10 10');}
  else if(type==='smile'){K.circle(c,0,0,10,null,col,1.5);K.circle(c,-3,-2,1,col);K.circle(c,3,-2,1,col);p('M-5 3 Q0 8 5 3');}
  else if(type==='video')p('M-11 -7 H5 V8 H-11Z M5 -3 L13 -7 V8 L5 4');
  else if(type==='phone')p('M-6 -10 Q-13 -8 -8 2 Q-1 13 8 9 L11 5 L5 1 L2 5 Q-5 1 -5 -5 L-2 -6Z');
  else if(type==='more'){for(let j=-1;j<=1;j++)K.circle(c,j*6,0,1.6,col);}
  else if(type==='settings'){K.circle(c,0,0,6,null,col,1.8);K.circle(c,0,0,2,null,col,1.5);for(let j=0;j<8;j++){let a=j*Math.PI/4;K.line(c,[[Math.cos(a)*6,Math.sin(a)*6],[Math.cos(a)*10,Math.sin(a)*10]],col,2.3);}}
  else if(type==='thumb')p('M-9 1 H-4 L1 -9 Q5 -10 4 -4 L3 0 H10 Q13 0 11 5 L9 11 H-4 V1 M-9 0 V11 H-5');
  else if(type==='play')K.path(c,'M-6 -10 L10 0 L-6 10Z',col);
  else if(type==='pause'){K.rect(c,-6,-8,4,16,col);K.rect(c,3,-8,4,16,col);}
  else if(type==='fullscreen')p('M-11 -4 V-10 H-5 M5 -10 H11 V-4 M11 4 V10 H5 M-5 10 H-11 V4');
  else if(type==='speaker')p('M-10 -4 H-5 L2 -9 V9 L-5 4 H-10Z M6 -5 Q12 0 6 5');
  else if(type==='file')p('M-8 -11 H3 L9 -5 V11 H-8Z M3 -11 V-5 H9');
  else if(type==='branch'){K.circle(c,-5,-7,3,null,col,1.4);K.circle(c,6,1,3,null,col,1.4);K.circle(c,-5,10,3,null,col,1.4);p('M-5 -4 V7 M-5 -1 Q6 -1 6 -2');}
  else if(type==='extensions'){p('M-10 -10 H-1 V-1 H-10Z M1 -10 H10 V-1 H1Z M-10 1 H-1 V10 H-10Z M2 3 L8 -1 L12 5 L6 10Z');}
  c.restore();
 };
 I.avatar=function(c,x,y,size,id=0){
  const cols=['#bedbcc','#d9c5b0','#c9d8e8','#dfc9da','#c6d0a6'];c.save();c.beginPath();c.roundRect(x,y,size,size,4);c.clip();K.rect(c,x,y,size,size,cols[id%5]);
  c.translate(x+size/2,y+size/2);c.scale(size/48,size/48);
  if(id===0){K.path(c,'M-19 20 Q-18 8 -5 5 Q4 2 2 -10 Q2 -21 12 -19 Q22 -18 20 -8 Q19 -3 12 -1 L9 18Z','#fff8e1','#719284',1.2);K.path(c,'M15 -12 L34 -7 L15 -5Z','#dba94b','#8d8059',.8);K.circle(c,13,-13,1.7,'#47635b');}
  else if(id===1){K.circle(c,5,-5,12,'#ece0bf');K.path(c,'M-27 24 L-8 -5 L11 14 L25 -2 L31 25Z','#809387');K.path(c,'M-22 24 L-4 7 L15 24Z','#637f79');}
  else if(id===2){K.circle(c,12,-11,6,'#f7e1aa');K.path(c,'M-25 24 L-13 -4 L1 10 L11 -6 L28 24Z','#73949d');K.path(c,'M-25 23 Q1 8 28 21 V26 H-25Z','#a9c1a4');}
  else if(id===3){K.ellipse(c,0,0,17,13,'#efe3cb');K.circle(c,-7,-4,4,'#b7846c');K.circle(c,2,-6,3,'#7e9c91');K.circle(c,9,1,3,'#a699b3');K.circle(c,-5,6,3,'#cbb067');}
  else{K.path(c,'M-14 -9 H14 V12 H-14Z','#edf3da','#709477',1.3);K.path(c,'M-14 -9 L0 2 L14 -9',null,'#709477',1.3);}
  c.restore();
 };

 // Original vector portraits. The recovered character artwork informs identity
 // cues only; this renderer never loads or composites an image asset.
 I.cast=P.castArt.cast;
 I.castAvatar=(c,x,y,size,id)=>P.castArt.draw(c,x,y,size,id,P.sceneContext?P.sceneContext.local:0);
 I.castGroup=function(c,x,y,size){I.round(c,x,y,size,size,5,'#d8dfd6');const gap=size*.07,w=(size-gap*3)/2;['fish','gpt','claude','doubao'].forEach((id,j)=>I.castAvatar(c,x+gap+(j%2)*(w+gap),y+gap+Math.floor(j/2)*(w+gap),w,id));};
 I.giftPoint=function(p){const s=p.scale||1,a=p.tilt||0,x=137*s,y=-110*s;return{x:p.x+x*Math.cos(a)-y*Math.sin(a),y:p.y+x*Math.sin(a)+y*Math.cos(a)};};
 I.carriedHeart=function(c,p,t=0){
  if(!p)return;c.save();c.translate(p.x,p.y);c.rotate(p.tilt||0);c.scale(p.scale||1,p.scale||1);
  K.path(c,'M113 -130 Q124 -136 135 -124 L137 -119',null,'#f0d5b3',2.2);K.path(c,'M124 -132 q-10 -8 -9 -1 q3 6 9 1 q5 -10 9 -4 q1 5 -9 4',null,'#d6a282',1.1);
  M.heart(c,137,-108,.64,'#ec83a0');K.path(c,'M131 -116 Q134 -119 137 -115',null,'#ffe4e8',1.8);c.restore();
 };
 P.drawCarriedHeart=I.carriedHeart;
 I.bubble=function(c,x,y,w,h,text,green=false,side='left',size=20){const fill=green?'#95ec69':'#fff';I.round(c,x,y,w,h,5,fill,green?'#87d45f':'#e7e7e7',.9);K.path(c,side==='right'?`M${x+w} ${y+16} l7 6 -7 6Z`:`M${x} ${y+16} l-7 6 7 6Z`,fill);if(text)K.text(c,text,x+17,y+h/2+size*.36,size,'#222');};
 I.road=function(c,y,fill,ink,end=1430){K.rect(c,170,y,Math.max(0,end-170),9,fill);K.line(c,[[170,y],[end,y]],ink,1.6);for(let x=183;x<end-9;x+=42)K.line(c,[[x,y+5],[x+12,y+5]],'rgba(75,105,83,.18)',.7);};
 I.holdTravel=function(t,a,b,x=740){const v=1600/6;function h(u,p0,p1,m0,m1,d){return(2*u*u*u-3*u*u+1)*p0+(u*u*u-2*u*u+u)*d*m0+(-2*u*u*u+3*u*u)*p1+(u*u*u-u*u)*d*m1;}if(t<a)return h(K.clamp(t/a),0,x,v,0,a);if(t<=b)return x;return h(K.clamp((t-b)/(6-b)),x,1600,0,v,6-b);};
 I.rider=(scene,t)=>P.sceneContext&&P.sceneContext.rider||scene.pose(t);
 I.bell=function(c,p,u,col){if(u<0||u>1)return;c.save();c.globalAlpha=1-u;const s=p.scale||1,x=p.x+124*s,y=p.y-137*s;for(let j=0;j<2;j++){c.beginPath();c.arc(x,y,10+j*8+u*27,-.9,.7);c.strokeStyle=col;c.lineWidth=1.5;c.stroke();}c.restore();};

 I.ddText=function(c,s,x,y,size=16,col='#234c69',align='left',weight='400'){
  c.save();c.fillStyle=col;c.textAlign=align;c.textBaseline='alphabetic';c.font=`${weight} ${size}px "SimSun", "Noto Sans CJK SC", sans-serif`;c.fillText(s,x,y);c.restore();
 };
 I.ddBell=function(c,x,y,s=1){
  c.save();c.translate(x,y);c.scale(s,s);
  K.path(c,'M14 -3 L23 -10',null,'#3c8fac',3);K.circle(c,24,-11,3.5,'#83cee1','#3989a5',.8);
  K.circle(c,0,-19,3.4,'#f3d58c','#a77832',.9);K.path(c,'M-17 10 Q-13 5 -13 -4 Q-13 -17 0 -17 Q13 -17 13 -4 Q13 5 17 10Z',K.gradient(c,[-12,-14],[12,12],[[0,'#fff1b8'],[.4,'#efc268'],[1,'#cf913e']]),'#9d6e2e',1.1);
  K.path(c,'M-9 -5 Q-9 -11 -3 -12',null,'#fff9d9',2);I.round(c,-18,8,36,6,3,'#f6d58a','#a77832',.9);K.circle(c,0,18,3.8,'#dca453','#9d6e2e',.7);
  K.circle(c,-4.5,-1,1.2,'#77562f');K.circle(c,4.5,-1,1.2,'#77562f');K.path(c,'M-3 3 Q0 6 4 3',null,'#966935',.9);
  K.path(c,'M-23 -14 q-4 5 -3 10 M-19 -11 q-2 3 -1 6',null,'#6ebcd2',1.3);c.restore();
 };
 I.ddButton=function(c,x,y,w,h,label,active=false){
  I.round(c,x,y,w,h,3,K.gradient(c,[x,y],[x,y+h],active?[[0,'#f5fcff'],[.5,'#cbe9fb'],[1,'#8cc7ed']]:[[0,'#fff'],[.48,'#edf6fc'],[1,'#cbdfe9']]),active?'#4a9ac5':'#8eaabe',1);
  K.line(c,[[x+3,y+2],[x+w-3,y+2]],'#fff',1);I.ddText(c,label,x+w*.5,y+h*.5+5.5,14,'#275477','center');
 };
 I.ddTool=function(c,x,y,type,label,col='#3a86b0'){
  if(type==='smile'){K.circle(c,x,y,9,'#ffd34a','#b98d24',1);K.circle(c,x-3,y-2,1.2,'#6a4a26');K.circle(c,x+3,y-2,1.2,'#6a4a26');K.path(c,`M${x-5} ${y+2} Q${x} ${y+8} ${x+5} ${y+2}`,null,'#966132',1.2);}
  else if(type==='shake'){K.path(c,`M${x-8} ${y-7} h16 v13 h-16Z`,'#bfe5f9','#437f9f',1);K.line(c,[[x-12,y-5],[x-15,y],[x-12,y+5]],'#e39836',1.7);K.line(c,[[x+12,y-5],[x+15,y],[x+12,y+5]],'#e39836',1.7);}
  else if(type==='scissors'){K.circle(c,x-5,y+5,3,null,'#4c88aa',1.5);K.circle(c,x+4,y+5,3,null,'#4c88aa',1.5);K.line(c,[[x-4,y+2],[x+6,y-9]],'#668da0',1.6);K.line(c,[[x+3,y+2],[x-7,y-9]],'#668da0',1.6);}
  else if(type==='font'){I.ddText(c,'A',x,y+7,23,col,'center','700');K.line(c,[[x-8,y+9],[x+8,y+9]],'#d85d5a',2);}
  else if(type==='gift'){K.rect(c,x-9,y-3,18,14,'#f4b057','#ba7f35',.8);K.rect(c,x-10,y-7,20,5,'#ffd17d','#ba7f35',.8);K.rect(c,x-2,y-7,4,18,'#e95c67');K.path(c,`M${x} ${y-7} q-14 -12 -12 -2 q4 5 12 2 q13 -12 12 -2 q-4 5 -12 2`,null,'#dc6575',1.4);}
  else I.icon(c,type,x,y,.74,col);
  if(label)I.ddText(c,label,x+19,y+5,14,'#285473');
 };

 P.scenes[16]=Object.assign({},old[16],{
  title:'叮咚在线',en:'YOU RECEIVED AN ANIMATED EMOTICON',date:'2009',dark:false,accent:'#1688cb',uiNativeLabels:true,
  riderClip:{x:0,y:270,w:1600,h:433},travelX(t){return I.holdTravel(t,2.6,3.6);},
  draw(c,t){
   const shakeAge=t-2.48,shake=P.chatFrameContract?P.chatFrameContract.state(t).dx:(shakeAge>0&&shakeAge<.34?Math.sin(shakeAge*82)*4*(1-K.ease(shakeAge/.34)):0);
   const desktop=K.cached('interfaces-r8-dingdong2009-desktop',d=>{
    K.rect(d,0,0,1600,900,K.gradient(d,[0,0],[0,900],[[0,'#8ebedc'],[.56,'#cce4eb'],[1,'#8fb6ce']]));
    K.path(d,'M-60 814 C254 583 371 671 613 496 C821 334 1151 374 1658 106',null,'rgba(255,255,255,.22)',54);
    K.path(d,'M-60 822 C298 613 438 700 655 529 C862 370 1174 402 1658 134',null,'rgba(231,251,255,.3)',2);
    K.path(d,'M0 745 Q234 692 458 738 Q819 648 1111 699 Q1385 645 1600 687 V868 H0Z','#84acbf');
    for(let j=0;j<3;j++)K.cloud(d,1140+j*130,34+j*22,.8+j*.12,'rgba(238,250,255,.2)');

    // The contact panel and conversation are separate windows, in an original early desktop messenger.
    I.round(d,43,91,321,746,7,'rgba(35,66,93,.2)');I.round(d,35,81,321,746,7,'#dff2fc','#6b9fbe',1.2);
    I.round(d,36,82,319,176,6,K.gradient(d,[36,82],[36,258],[[0,'#f1fbff'],[.16,'#ccecff'],[.54,'#b8def6'],[1,'#d5edfc']]));
    K.path(d,'M40 96 Q184 60 350 105 L350 157 Q182 110 40 143Z','rgba(255,255,255,.3)');
    I.ddBell(d,56,104,.56);I.ddText(d,'叮咚2009',75,110,15,'#235b7c','left','700');I.ddText(d,'—   ×',340,105,18,'#6999b5','right');
    I.round(d,53,133,71,71,5,'#fff','#89b4ca',1);I.avatar(d,57,137,63,0);
    I.ddText(d,'骑了很久',138,154,22,'#1e4d69','left','700');K.circle(d,144,174,4,'#66b524','#3d8e24',.6);I.ddText(d,'我在线上',156,179,14,'#416e86');K.path(d,'M226 172 l6 0 -3 4Z','#557c93');
    K.star(d,146,198,6,'#ffbf35');K.star(d,162,198,6,'#ffbf35');K.path(d,'M184 190 A8 8 0 1 0 186 205 Q177 204 179 196Z','#f3c74d');I.ddText(d,'Lv.6000',198,202,12,'#7e8b72');
    I.ddText(d,'从岩画上线，一直没舍得下线。',56,228,14,'#62849b');
    I.round(d,51,242,290,27,3,'rgba(255,255,255,.75)','#adcddd',.8);I.icon(d,'search',66,255,.5,'#7ea2b7');I.ddText(d,'搜索：联系人、群、讨论组',82,260,12,'#8aa5b5');
    K.rect(d,36,280,319,42,K.gradient(d,[0,280],[0,322],[[0,'#e8f6ff'],[1,'#c2e3f6']]));K.line(d,[[36,322],[355,322]],'#8ab8d1',1);
    for(let j=0;j<3;j++){let x=88+j*105;if(j===0){I.round(d,x-41,286,83,35,3,'#f4fbff','#98c6df',.8);}I.icon(d,['contacts','chat','folder'][j],x,304,.79,j===0?'#287ca9':'#7d9eb4');}
    K.path(d,'M51 335 l8 0 -4 5Z','#56859f');I.ddText(d,'我的群  [1/1]',66,344,14,'#345f78');
    I.round(d,42,355,307,57,2,K.gradient(d,[0,355],[0,412],[[0,'#e9f8ff'],[1,'#c3e3f7']]),'#a4cce3',.8);
    I.castGroup(d,54,364,40);I.ddText(d,'鹈鹕围观群',105,383,17,'#1e5378');I.ddText(d,'大家都在等你发下一张表情',105,402,12,'#7394a9');K.circle(d,332,371,7,'#f89b38');I.ddText(d,'1',332,375,10,'#fff','center');
    K.path(d,'M51 426 l8 0 -4 5Z','#56859f');I.ddText(d,'AI好友  [4/4]',66,435,14,'#345f78');
    const ids=['fish','gpt','claude','doubao'],sign=['今天也想吃一大碗白饭','先确认前提，再给结论。','先解决问题，再把它做好看。','最简单、最直接、不绕弯子。'];
    for(let j=0;j<4;j++){let y=449+j*67;K.rect(d,43,y,305,66,j%2?'rgba(235,248,255,.5)':'rgba(255,255,255,.48)');I.ddText(d,I.cast[ids[j]].name,108,y+25,17,'#234d67');I.ddText(d,sign[j],108,y+47,12,'#859da9');}
    K.rect(d,36,724,319,37,'#d6edfa');K.path(d,'M52 737 l5 4 -5 4Z M52 772 l5 4 -5 4Z','#7897aa');I.ddText(d,'陌生人',66,748,14,'#577d94');I.ddText(d,'黑名单',66,783,14,'#7c9bad');
    K.line(d,[[36,798],[355,798]],'#abc9d9',1);I.ddBell(d,56,813,.4);I.ddText(d,'主菜单',72,818,12,'#476d85');I.icon(d,'settings',191,813,.53,'#7b9daf');I.icon(d,'speaker',221,813,.51,'#7b9daf');I.ddText(d,'查找',279,818,12,'#476d85');K.text(d,'+',328,820,23,'#6b92aa','center');

    I.round(d,393,91,1165,746,7,'rgba(35,65,94,.22)');I.round(d,384,81,1165,746,6,'#edf8ff','#699fbd',1.2);
    I.round(d,385,82,1163,36,5,K.gradient(d,[385,82],[385,118],[[0,'#eefaff'],[.5,'#bfdef3'],[1,'#9ccce9']]));
    I.ddBell(d,405,100,.5);I.ddText(d,'鹈鹕围观群  ·  EARLY CHAT / 2000s',426,107,16,'#174b70','left','700');I.ddText(d,'—    □    ×',1531,105,17,'#5483a3','right');
    K.rect(d,385,118,1163,106,K.gradient(d,[0,118],[0,224],[[0,'#e5f6ff'],[1,'#cbe8f9']]));
    I.castGroup(d,407,130,54);I.ddText(d,'鹈鹕围观群（5）',477,150,23,'#224e6f','left','700');I.ddText(d,'6000年没下线 · 群里突然多了一只会骑车的表情',477,175,14,'#6d91a9');
    I.ddTool(d,418,204,'video','视频','#4c9bc8');I.ddTool(d,515,204,'phone','语音','#68a476');I.ddTool(d,612,204,'folder','发送文件','#d8a03c');I.ddTool(d,744,204,'scissors','截图');I.ddTool(d,842,204,'shake','窗口抖动');I.ddTool(d,973,204,'gift','礼物');I.ddTool(d,1073,204,'settings','设置');
    K.line(d,[[386,224],[1547,224]],'#9ac3db',1);
    K.rect(d,399,225,953,468,'#fff');K.rect(d,1353,225,182,468,'#edf8ff');K.line(d,[[1353,225],[1353,693]],'#b4d1e2',1);
    I.ddText(d,'群公告',1367,250,14,'#497c9c','left','700');K.line(d,[[1366,260],[1522,260]],'#c8dfec',1);
    I.ddText(d,'一路围观到发布会。',1367,284,13,'#5d8094');I.ddText(d,'请为骑行的表情让路。',1367,305,13,'#5d8094');
    I.ddText(d,'群成员  [5/5]',1367,343,14,'#497c9c','left','700');
    I.avatar(d,1367,357,25,0);I.ddText(d,'骑了很久',1402,376,14,'#315f7b');
    for(let j=0;j<4;j++){let y=396+j*47;I.castAvatar(d,1367,y,25,ids[j]);I.ddText(d,I.cast[ids[j]].name,1402,y+18,14,'#4e7489');K.circle(d,1388,y+23,3.2,'#6fbb47','#fff',.7);}
    I.round(d,1366,607,157,65,3,'#f8fcff','#c7dfed',.8);I.ddText(d,'群文件',1376,628,13,'#5a849c');I.ddText(d,'旅途笔记.txt',1376,651,13,'#227cb3');I.icon(d,'file',1506,642,.6,'#71a4bb');
    K.rect(d,398,694,1137,34,K.gradient(d,[0,694],[0,728],[[0,'#f6fbff'],[1,'#dceffa']]));K.line(d,[[398,694],[1535,694]],'#b4d4e5',1);
    I.ddTool(d,417,711,'font');I.ddTool(d,454,711,'smile');I.ddTool(d,491,711,'folder');I.ddTool(d,530,711,'scissors');I.ddTool(d,571,711,'shake');I.ddTool(d,611,711,'gift');I.ddText(d,'消息记录',1440,717,13,'#4784a6');K.path(d,'M1521 707 l5 0 -2.5 4Z','#6b94ad');
    K.rect(d,399,729,1135,62,'#fff');K.rect(d,398,792,1137,28,'#eaf6fd');I.ddText(d,'按 Alt+S 发送消息',414,811,12,'#8ba4b2');
    // The GIF's sides remain open to the common road, not an image zoom.
    K.rect(d,382,360,4,315,'#c6e2f1');K.rect(d,1546,360,4,315,'#bcdae9');

    K.rect(d,0,866,1600,34,K.gradient(d,[0,866],[0,900],[[0,'#2c8ace'],[.16,'#71b2e0'],[.3,'#2c85c9'],[1,'#1b62a3']]));
    I.round(d,0,867,108,32,6,K.gradient(d,[0,867],[0,899],[[0,'#68b85f'],[.5,'#3e9748'],[1,'#2d7639']]),'#2d6e3c',.8);I.ddBell(d,28,883,.48);I.ddText(d,'菜单',49,890,18,'#fff','left','700');
    I.round(d,117,871,191,25,3,'#3888c7','#75b2dc',.8);I.ddBell(d,133,883,.34);I.ddText(d,'叮咚2009',150,889,13,'#fff');
    I.round(d,315,871,240,25,3,'#2677b7','#85b9df',.8);I.ddBell(d,331,883,.34);I.ddText(d,'鹈鹕围观群',349,889,13,'#fff');
    K.rect(d,1440,867,160,33,'#2d94cf','#83c0e3',.7);I.icon(d,'speaker',1460,883,.5,'#dff5ff');K.circle(d,1486,883,4,'#9bdc7f');I.ddText(d,'20:00',1539,889,13,'#fff','center');
   });c.drawImage(desktop,0,0);
   if(shake)c.drawImage(desktop,383,80,1167,748,383+shake,80-shake*.35,1167,748);

   // Unread avatars flash; the drawings themselves are never regenerated.
   const ids=['fish','gpt','claude','doubao'];
   for(let j=0;j<4;j++){const y=449+j*67,blink=(j===0&&t<.65)||(j===3&&t>=2.6&&t<3.18);c.save();c.globalAlpha=blink&&Math.floor(t*7)%2?.28:1;I.castAvatar(c,56,y+10,42,ids[j]);K.circle(c,94,y+49,4.3,'#6fbc48','#fff',1);c.restore();}
   c.save();c.translate(shake,-shake*.35);
   const typing=t>=1.15&&t<2.25,saved=t>=3.18,scroll=90*K.ease((t-2.15)/.68);
   const messages=[[-.2,'fish','骑了六千年，下一站吃大白饭？'],[.55,'gpt','严谨地说：轮子在转，不等于在前进。'],[1.25,'claude','点开原文件，顺便把出口留好。']];
   c.save();c.beginPath();c.rect(402,225,943,156);c.clip();
   for(let j=0;j<messages.length;j++){
    const [born,id,msg]=messages[j];if(t<born)continue;const y=240+j*51-scroll;I.castAvatar(c,412,y-7,27,id);
    I.ddText(c,I.cast[id].name+'  20:00:0'+j,449,y+3,12,j===0?'#2b8b52':j===1?'#2478af':'#a26b49');
    I.round(c,445,y+10,j===2?450:423,29,3,j===0?'#f2f9fe':'#f7fbff','#dceaf2',.7);I.ddText(c,msg,455,y+31,17,'#263b48');
   }
   if(t>=3.02){const y=396-scroll;I.castAvatar(c,412,y-7,27,'doubao');I.ddText(c,'豆包  20:00:03',449,y+3,12,'#b46d7b');I.round(c,445,y+10,454,58,3,'#f5faff','#c4dce9',.8);I.ddText(c,'直播见，给你留了一颗小心心～',456,y+32,17,'#32536a');K.line(c,[[455,y+40],[884,y+40]],'#d6e7f1',.7);K.circle(c,461,y+52,4,'#f174a0');I.ddText(c,'直播邀请 · 骑了很久的鹈鹕  ›',475,y+57,13,'#3687b4');}
   c.restore();
   if(t>=2.25){I.round(c,1052,311,281,43,4,'#ebf7ff','#aacfe5',.8);I.ddText(c,'不聊啦，下一站见。',1065,340,19,'#215a80');K.path(c,'M1333 324 l7 6 -7 6Z','#ebf7ff','#aacfe5',.8);}
   if(t>=2.6&&t<3.02){I.ddText(c,'豆包正在输入…',1115,174,13,'#6d97b2');for(let j=0;j<3;j++)K.circle(c,1251+j*8,169,1.5+Math.max(0,Math.sin(t*6+j)), '#70a8c6');}

   if(t>=2.48&&t<2.96){c.save();c.globalAlpha=K.ease((t-2.48)/.08)*(1-K.ease((t-2.78)/.18));I.round(c,1153,491,180,55,4,'#f7fbff','#bdd7e6',.8);I.ddBell(c,1175,520,.44);I.ddText(c,'大肥鱼发送了',1192,513,13,'#6487a0');I.ddText(c,'一次窗口抖动',1192,533,13,'#6487a0');c.restore();}
   I.round(c,548,383,590,304,4,'#f1f8fc','#a9cadc',1);K.rect(c,549,416,588,259,'#e8f2ed');for(let j=0;j<96;j++){const xx=555+(j*61)%576,yy=424+(j*43)%244;K.rect(c,xx,yy,1,1,'rgba(101,135,123,.14)');}K.line(c,[[549,415],[1137,415]],'#d3e4ed',1);
   I.ddText(c,'鹈鹕骑行.gif',563,405,14,'#4b88a8');I.ddText(c,'[ 动态表情 · 10 fps ]',715,405,12,'#8aa6b8');
   I.ddButton(c,1006,388,117,24,saved?'已添加 ✓':'添加到表情',saved);K.star(c,1017,400,5,saved?'#dcb758':'#ebcb7b');
   K.rect(c,546,426,5,249,'#fff');K.rect(c,1136,426,5,249,'#fff');K.line(c,[[544,425],[553,425]],'#a8c9d6',1.2);K.line(c,[[1134,425],[1143,425]],'#a8c9d6',1.2);
   if(t>2.72&&t<3.5){const u=K.ease((t-2.72)/.4),x=K.lerp(1181,1080,u),y=K.lerp(454,404,u);K.path(c,'M'+x+' '+y+' l3 17 5 -5 7 -1Z','#fff','#3f6d8c',1.2);if(t>3.14&&t<3.25)K.circle(c,1080,401,16,null,'#e5be50',1.4);}
   if(saved&&t<5.75){const a=K.ease((t-3.18)/.12)*K.ease((5.75-t)/.18);c.save();c.globalAlpha=a;I.round(c,1153,389,180,88,4,'#fffdeb','#dfcb8b',.8);K.star(c,1174,411,8,'#e6b54c');I.ddText(c,'表情收藏成功',1190,416,14,'#9b7739');K.line(c,[[1164,430],[1322,430]],'#eee2bd',.8);I.ddText(c,t<3.62?'已加入「我的收藏」':'可是…它还在骑？',1164,454,14,'#a08d62');c.restore();}
   const message='不聊啦，下一站见。',input=typing?message.slice(0,Math.floor(K.clamp((t-1.15)/.95)*message.length)):'';
   I.ddText(c,input+(typing&&Math.floor(t*6)%2?'│':''),416,764,21,'#273d4b');
   I.ddButton(c,1298,788,97,30,'关闭(C)');I.ddButton(c,1406,788,127,30,'发送(S)',typing);K.line(c,[[1507,791],[1507,815]],'#a7c6d8',1);K.path(c,'M1515 801 l8 0 -4 5Z','#5e88a0');
   if(t>3.62)I.ddText(c,'大肥鱼：我也去直播间！',696,811,13,'#6f9ab2');
   c.restore();
   if(t>=2.6&&t<3.18&&Math.floor(t*6)%2){I.round(c,315,871,240,25,3,'#e8ab47','#ffdb78',.8);I.ddBell(c,331,883,.34);I.ddText(c,'豆包发来新消息',349,889,13,'#664714');}
   I.road(c,675,'#dbe8de','#96b2a4');
  },
  pose(t){const p=old[16].pose(t);return Object.assign(p,{x:this.travelX(t),expression:'calm',headNod:t>=2.6&&t<=3.6?-.035:0,gazeX:.8,gazeY:t>=2.6&&t<=3.6?-.35:0,bellPress:0});},
  foreground(c,t,a,p){if(t>=3.18&&t<3.62){const u=(t-3.18)/.44;c.save();c.globalAlpha=1-u;for(let j=0;j<5;j++)K.star(c,1080+Math.cos(j*1.25)*u*33,401+Math.sin(j*1.25)*u*22,2.6,'#e3bd55',j);c.restore();}}
 });


 P.scenes[18]=Object.assign({},old[18],{
  title:'竖屏直播',en:'A HEART GOES ALONG FOR THE RIDE',date:'2020s',dark:true,accent:'#ff6d9d',uiNativeLabels:true,
  portraitViewport:{x:524,y:48,w:432,h:768},
  portraitFocus(t){return K.ease((t-1.65)/.75)*(1-K.ease((t-3.85)/.75));},
  riderScreenClip(t){return this.portraitFocus(t)>.985?this.portraitViewport:{x:0,y:285,w:1600,h:449};},
  riderClip:{x:0,y:285,w:1600,h:449},travelX(t){return I.holdTravel(t,2.4,3.6);},
  draw(c,t){
   const screen=this.portraitViewport,focus=this.portraitFocus(t);
   const landscape=K.cached('interfaces-r8-portrait-lakeside',d=>{
    K.rect(d,0,0,1600,900,K.gradient(d,[0,0],[0,900],[[0,'#7fa8ba'],[.34,'#c2d5d2'],[.62,'#e4dfbd'],[1,'#647b60']]));
    const sun=d.createRadialGradient(859,226,7,859,226,123);sun.addColorStop(0,'#fff7cd');sun.addColorStop(.48,'#f4e8b5');sun.addColorStop(.51,'rgba(242,225,173,.48)');sun.addColorStop(1,'rgba(242,225,173,0)');K.rect(d,730,95,260,262,sun);
    K.path(d,'M0 414 Q121 345 232 381 Q331 300 441 361 Q538 325 639 380 Q712 311 789 349 Q874 281 973 341 Q1070 302 1172 364 Q1386 291 1600 348 V528 H0Z','#a1bbb6');
    K.path(d,'M0 463 Q155 394 298 432 Q443 350 591 408 Q735 379 896 433 Q1016 367 1168 399 Q1392 337 1600 418 V552 H0Z','#7f9e98');
    K.path(d,'M0 487 Q206 451 401 480 Q538 425 686 459 Q843 430 1020 475 Q1220 405 1600 457 V568 H0Z','#648b81');
    K.rect(d,0,493,1600,210,K.gradient(d,[0,493],[0,703],[[0,'#a5c5be'],[.46,'#90b7ad'],[1,'#bfd0ae']]));
    for(let j=0;j<19;j++){const y=501+j*10;K.path(d,'M-20 '+y+' Q240 '+(y-5)+' 477 '+(y+3)+' T937 '+(y-2)+' T1625 '+(y+1),null,j%3?'rgba(221,230,192,.35)':'rgba(88,137,125,.27)',.7+j*.025);}
    for(let j=0;j<14;j++){const y=496+j*8,half=7+j*3.9;K.line(d,[[859-half,y],[859+half,y]],'rgba(251,237,180,'+(.3-j*.012)+')',2);}
    // A distant pavilion, shoreline lights and reeds build depth without actors.
    K.rect(d,1084,443,64,14,'#496f67');K.path(d,'M1071 444 L1091 431 L1116 420 L1141 431 L1161 444 Q1115 437 1071 444Z','#41655e');K.path(d,'M1085 428 L1101 420 L1116 407 L1131 420 L1146 428 Q1116 423 1085 428Z','#3f665d');for(let x=1091;x<=1141;x+=25)K.line(d,[[x,441],[x,458]],'#476b62',3);K.line(d,[[1076,460],[1157,460]],'#698f7b',3);
    K.path(d,'M0 655 Q155 606 329 636 Q466 578 585 631 Q715 619 862 645 Q1050 601 1183 622 Q1416 581 1600 635 L1600 719 H0Z','#a9ba88');
    for(let j=0;j<40;j++){let x=17+j*43,y=643+Math.sin(j*1.2)*18;K.path(d,'M'+x+' '+y+' q-4 -23 1 -44 M'+x+' '+(y-14)+' q-14 -13 -19 -12 M'+x+' '+(y-7)+' q10 -15 19 -14',null,j%2?'#76915d':'#8fa46e',1.4);if(j%5===0)K.ellipse(d,x+2,y-46,3,9,'#b69f65',null,1,-.1);}
    K.path(d,'M0 703 H1600 V900 H0Z',K.gradient(d,[0,703],[0,900],[[0,'#d7c7a1'],[.04,'#c5b48f'],[1,'#9b9179']]));
    K.line(d,[[0,703],[1600,703]],'#f1dfb1',1.6);K.line(d,[[0,707],[1600,707]],'#9ca782',1);
    for(let j=0;j<135;j++){let x=K.rnd(j+340)*1600,y=713+K.rnd(j+971)*180;K.ellipse(d,x,y,1.5+K.rnd(j+40)*3.5,.6,'rgba(92,102,76,.23)');}
    for(const x of [158,1243,1510]){K.line(d,[[x,703],[x,610]],'#6a7d68',5);K.line(d,[[x-20,611],[x+21,611]],'#5a7161',3);K.rect(d,x-13,596,26,15,'#e4d4a0','#728773',1);K.path(d,'M'+(x-18)+' 596 Q'+x+' 583 '+(x+18)+' 596Z','#5c7565');K.rect(d,x-4,601,8,9,'#f4e5b7');}
   });
   c.drawImage(landscape,0,0);
   // The surroundings fall away as the vertical broadcast takes over.
   c.save();c.globalAlpha=.34+.66*focus;K.rect(c,0,0,1600,900,'#000');c.restore();
   c.save();c.beginPath();c.rect(screen.x,screen.y,screen.w,screen.h);c.clip();c.drawImage(landscape,0,0);
   for(let j=0;j<3;j++)K.cloud(c,620+j*132-t*6,256+(j%2)*44,.44,'rgba(255,250,224,.32)');
   c.restore();
   c.save();c.globalAlpha=.58+.42*focus;I.round(c,512,36,456,792,20,null,'#252c34',12);I.round(c,519,43,442,778,14,null,'#a6afb0',1.2);c.restore();
   // The phone rails open at road height during entry and exit, rather than
   // cutting to a second pelican inside the video.
   if(focus<.985){c.save();c.globalAlpha=1-focus;K.rect(c,506,348,19,355,'#152029');K.rect(c,956,348,19,355,'#152029');K.line(c,[[507,349],[526,349]],'#748c87',1.3);K.line(c,[[955,349],[974,349]],'#748c87',1.3);c.restore();}
   c.save();c.globalAlpha=1-focus;I.road(c,703,'#c3bc98','#b1b795');c.restore();
  },
  pose(t){const p=old[18].pose(t);delete p.phaseTime;const look=K.ease((t-2.32)/.18)*K.ease((3.6-t)/.25);return Object.assign(p,{x:this.travelX(t),scale:.76,gazeX:1-1.65*look,gazeY:.13*look,headNod:.08*look,brakeLean:0,bellPress:Math.sin(Math.PI*K.clamp((t-3.02)/.32))});},
  foreground(c,t,a,p){
   p=p||this.pose(t);const screen=this.portraitViewport,focus=this.portraitFocus(t);
   c.save();c.beginPath();c.rect(screen.x,screen.y,screen.w,screen.h);c.clip();
   K.rect(c,524,48,432,155,K.gradient(c,[0,48],[0,203],[[0,'rgba(13,22,30,.48)'],[1,'rgba(13,22,30,0)']]));
   K.rect(c,524,656,432,160,K.gradient(c,[0,656],[0,816],[[0,'rgba(13,22,30,0)'],[.36,'rgba(13,22,30,.32)'],[1,'rgba(13,22,30,.82)']]));
   K.text(c,'20:00',543,70,12,'#fff','left','sans','600');I.ddBell(c,738,64,.23);K.text(c,'顺路 LIVE',751,69,10,'#fff','left','sans','500');for(let j=0;j<4;j++)K.rect(c,875+j*4,68-j*2,2,3+j*2,'#fff');K.path(c,'M898 62 Q905 55 912 62 M901 65 Q905 61 909 65',null,'#fff',1.2);K.circle(c,905,68,1,'#fff');I.round(c,920,59,22,10,2,null,'#fff',1);K.rect(c,922,61,16,6,'#fff');K.rect(c,943,62,2,4,'#fff');
   I.round(c,538,83,231,46,23,'rgba(22,29,34,.35)');I.avatar(c,542,88,36,0);K.text(c,'骑了很久',587,103,15,'#fff','left','sans','600');K.text(c,'6.0万 本场点赞',587,120,10,'#e4eded');
   I.round(c,705,91,55,28,14,'#ff507d');K.text(c,'关注',732,110,12,'#fff','center','sans','500');
   ['fish','gpt','claude'].forEach((id,j)=>{c.save();c.beginPath();c.arc(793+j*23,106,14,0,Math.PI*2);c.clip();I.castAvatar(c,779+j*23,92,28,id);c.restore();K.circle(c,793+j*23,106,14,null,'rgba(255,255,255,.7)',1);});
   I.round(c,861,93,49,26,13,'rgba(22,29,34,.35)');K.text(c,'1.2万',885,111,11,'#fff','center');K.path(c,'M927 99 l13 13 M940 99 l-13 13',null,'#fff',1.7);
   I.round(c,540,141,61,22,4,'rgba(231,59,104,.9)');K.circle(c,551,152,3,'#fff');K.text(c,'直播中',578,157,11,'#fff','center');
   I.round(c,608,141,132,22,11,'rgba(27,48,49,.36)');K.text(c,'竖屏短视频 · 2020s',674,157,11,'#f6f4df','center');K.text(c,'00:00:0'+Math.min(5,Math.floor(t)),937,157,11,'#ecf6ef','right','mono');
   c.save();c.shadowColor='rgba(21,41,39,.6)';c.shadowBlur=2;K.text(c,'建议从公元前开始看。',543,188,16,'#fffdf1','left','sans','500');c.restore();

   if(t<2.9||t>4.22)K.text(c,'SHORT VIDEO / 2020s',544,209,13,'#f5f4df','left','mono');
   // Narrow, recognisable mobile action rail; the rider keeps the centre.
   const liked=t>=3.02;
   M.heart(c,928,331,.75,liked?'#ff527f':'#fff');K.text(c,liked?(60000+Math.floor(K.clamp((t-3.02)/1.1)*320)).toLocaleString():'6.0万',928,361,11,'#fff','center');
   I.icon(c,'chat',928,400,1.03,'#fff');K.text(c,String(26+Math.floor(Math.max(0,t-2.45)*12)),928,427,11,'#fff','center');
   K.path(c,'M916 476 Q917 459 934 457 L934 448 L945 462 L934 476 L934 468 Q923 468 916 476Z','#fff');K.text(c,'分享',928,498,11,'#fff','center');
   K.star(c,928,540,12,'#fff1c0');K.text(c,'收藏',928,569,11,'#fff','center');
   if(t>=2.45&&t<3.6){const x=p.x+48*p.scale,y=p.y-259*p.scale,r=27;c.save();c.globalAlpha=K.ease((t-2.45)/.2)*.54;for(const [sx,sy]of [[-1,-1],[1,-1],[-1,1],[1,1]])K.line(c,[[x+sx*r,y+sy*(r-9)],[x+sx*r,y+sy*r],[x+sx*(r-9),y+sy*r]],'#fff4cf',1.2);c.restore();}
   if(t>=2.95&&t<4.22){const u=K.ease((t-2.95)/.14)*K.ease((4.22-t)/.22);c.save();c.globalAlpha=u;I.round(c,542,207,351,43,22,'rgba(54,27,56,.72)');I.castAvatar(c,550,214,28,'doubao');K.text(c,t<3.18?'豆包 送出 小心心':'小心心已挂上车把',588,235,14,'#fff1f6');M.heart(c,846,229,.58,'#ff95b5');K.text(c,'×1',875,234,16,'#ffe6ae','center','sans','700');c.restore();}

   const list=[[0,'gpt','已确认：不是原地踏步。'],[.45,'claude','竖屏也要给长喙留位置。'],[1.1,'fish','两碗白饭，已经下单。'],[2.45,'doubao','来啦！接稳我的小心心。'],[2.95,'doubao','送出 小心心 ×1'],[3.28,'gpt','挂件已固定，可以继续。'],[4.15,'fish','白饭到了！别光收爱心呀。']];
   let scroll=0;for(let j=3;j<list.length;j++)scroll+=23*K.ease((t-list[j][0])/.22);
   c.save();c.beginPath();c.rect(538,704,363,73);c.clip();
   for(let j=0;j<list.length;j++){const [born,id,msg]=list[j];if(t<born)continue;const y=720+j*23-scroll;if(y<690||y>802)continue;const col={fish:'#a9d5f5',gpt:'#b8e6cf',claude:'#f5d9ac',doubao:'#ffbacf'}[id];c.save();c.globalAlpha=K.ease((t-born)/.13);I.castAvatar(c,541,y-15,18,id);const nx=565;K.text(c,I.cast[id].name,nx,y,13,col,'left','sans','600');c.font='600 13px \"Noto Sans CJK SC\", sans-serif';const nameW=c.measureText(I.cast[id].name).width;K.text(c,': '+msg,nx+nameW+3,y,13,j===4?'#ffd4e5':'#fff');c.restore();}
   c.restore();
   I.round(c,539,784,267,28,14,'rgba(255,255,255,.13)');K.text(c,'说点什么，陪它骑一段…',552,803,13,'#e8edee');I.icon(c,'smile',788,798,.55,'#fff');
   I.ddTool(c,849,798,'gift');I.icon(c,'more',930,798,.75,'#fff');K.path(c,'M885 805 Q886 790 898 789 L898 783 L907 794 L898 804 L898 798 Q890 799 885 805Z','#fff');
   if(t>2.75&&t<2.98){const q=K.ease((t-2.75)/.2),x=K.lerp(914,849,q),y=K.lerp(854,799,q);K.path(c,'M'+x+' '+y+' l3 15 5 -5 6 -1Z','#fff','#98677e',1);}
   if(t>=3.18)for(let j=0;j<13;j++){const born=3.18+j*.095,age=t-born;if(age<0||age>1.6)continue;const x=922+Math.sin(age*3+j)*11,y=665-age*128;c.save();c.globalAlpha=K.clamp(1-age/1.6);M.heart(c,x,y,.28+(j%3)*.045,['#ff91b5','#fff0be','#f3c4e0'][j%3]);c.restore();}
   c.restore();

   // One gift leaves the interface and remains attached to the same bicycle.
   I.bell(c,p,(t-3.02)/.6,'#ffe3a4');
   if(t>=2.95&&t<3.18){const u=K.ease((t-2.95)/.23),q=I.giftPoint(p),v=1-u,x=v*v*849+2*v*u*888+u*u*q.x,y=v*v*798+2*v*u*497+u*u*q.y;for(let j=0;j<4;j++){const z=K.clamp(u-j*.04),w=1-z,xx=w*w*849+2*w*z*888+z*z*q.x,yy=w*w*798+2*w*z*497+z*z*q.y;c.save();c.globalAlpha=(4-j)*.14;M.heart(c,xx,yy,.6,'#f1acc0');c.restore();}M.heart(c,x,y,.84-.2*u,'#ec83a0');}
   if(t>=3.18){I.carriedHeart(c,p);const q=I.giftPoint(p),age=t-3.18;if(age<.52){c.save();c.globalAlpha=1-age/.52;K.circle(c,q.x,q.y,12+age*40,null,'#ffe7b4',1.6);for(let j=0;j<6;j++)K.circle(c,q.x+Math.cos(j*Math.PI/3)*age*51,q.y+Math.sin(j*Math.PI/3)*age*40,2.1,'#f6d8a3');c.restore();}}
   // Large, slow foreground hearts echo mobile reactions in the dark side panels.
   if(t>=3.18)for(let j=0;j<3;j++){const age=t-(3.18+j*.22);if(age<0||age>1.55)continue;c.save();c.globalAlpha=focus*K.ease(age/.18)*K.ease((1.55-age)/.4)*(.25-j*.035);c.translate(1031+j*68,705-age*(101+j*21));c.rotate(-.13+j*.14+Math.sin(age*2)*.08);M.heart(c,0,0,2.4+j*.55,['#ff8cb0','#f6b0c9','#ffe2c4'][j]);c.restore();}
  }
 });


 I.syntax=function(c,text,x,y,size=17){
  const tokens=text.match(/\/\/.*|"[^"]*"|'[^']*'|\b(?:const|new|return|debugger)\b|\b\d+(?:\.\d+)?\b|[A-Za-z_$][\w$]*(?=\()|[^"'\w]+|\w+/g)||[text];let dx=x;
  for(const token of tokens){const col=/^\/\//.test(token)?'#6a9955':/^["']/.test(token)?'#ce9178':/^(const|new)$/.test(token)?'#569cd6':/^(return|debugger)$/.test(token)?'#c586c0':/^\d/.test(token)?'#b5cea8':/^(moveTo|lineTo|quadraticCurveTo|follow|find|bell|Path2D|requestAnimationFrame)$/.test(token)?'#dcdcaa':/^(road|rider|scene|ride)$/.test(token)?'#9cdcfe':'#d4d4d4';K.text(c,token,dx,y,size,col,'left',/[\u3400-\u9fff]/.test(token)?'sans':'mono');dx+=c.measureText(token).width;}return dx;
 };
 I.pathLength=(()=>{let len=0,prev=[0,old[19].ground(0)];for(let x=2;x<=1600;x+=2){const y=old[19].ground(x);len+=Math.hypot(x-prev[0],y-prev[1]);prev=[x,y];}return len;})();
 I.xmlSyntax=function(c,text,x,y,size){
  const tokens=text.match(/<!--[\s\S]*?-->|"[^"]*"|<\/?[a-zA-Z]+|[a-zA-Z][\w.-]*(?==)|[^"<a-zA-Z]+|[a-zA-Z]+|[\s\S]/g)||[text];let dx=x;
  for(const token of tokens){const col=token.startsWith('<!--')?'#739a72':token.startsWith('"')?'#dca887':token.startsWith('<')?'#70bada':/^[a-zA-Z][\w.-]*$/.test(token)?'#a0d9dc':'#a5c5bb';K.text(c,token,dx,y,size,col,'left','mono');dx+=c.measureText(token).width;}return dx;
 };
 I.svgBlueprint=function(c,t,p){
  const q=K.clamp((t-.35)/2.5),x=1108,y=237,w=311,h=194;
  I.round(c,x,y,w,h,5,'#142b31','#47716f',1);K.rect(c,x+1,y+1,w-2,27,'#223d42');
  K.text(c,'rider.svg',x+13,y+19,12,'#a9d6d0','left','mono');K.text(c,Math.round(q*100)+'%',x+w-13,y+19,12,q<1?'#d8be83':'#87dfb4','right','mono');
  c.save();c.beginPath();c.rect(x+2,y+29,w-4,h-31);c.clip();
  for(let xx=x+16;xx<x+w;xx+=20)K.line(c,[[xx,y+29],[xx,y+h]],'rgba(133,192,186,.1)',.65);for(let yy=y+36;yy<y+h;yy+=20)K.line(c,[[x+2,yy],[x+w-2,yy]],'rgba(133,192,186,.1)',.65);
  const bx=x+148,by=y+150,scale=.32;
  K.line(c,[[x+23,by+102*scale],[x+w-23,by+102*scale]],'#4e8f84',.8);
  if(P.drawRider)P.drawRider(c,(P.sceneContext&&P.sceneContext.absolute)||119+t,Object.assign({},p,{x:bx,y:by,scale,style:19,build:q,alpha:1,shadow:false,tilt:0}));
  if(q<1){const yy=y+31+(h-34)*q;K.line(c,[[x+3,yy],[x+w-3,yy]],'rgba(141,234,213,.4)',.8);K.circle(c,x+w-8,yy,2,'#b4f1dc');}
  c.restore();
  if(t>=2.85){K.circle(c,x+15,y+179,3.1,'#87dfa8');K.text(c,'1 skin · 2 wheels · 1 rider',x+26,y+183,10,'#8db7ab','left','mono');}
 };
 I.svgLines=function(){
  const skin=P.characterSkin.path,wing=P.characterSkin.wing;
  return ['<svg viewBox="-220 -320 470 440">',
   '  <defs> <!-- one continuous body -->',
   '    <path id="skin" d="'+skin+'"/>',
   '    <path id="wing" d="'+wing+'"/>',
   '  </defs>',
   '  <use href="#skin" fill="#fff8e8"/>',
   '  <use href="#wing" fill="#fff8e8"/>',
   '  <g stroke="#76e2d4" fill="none">',
   '    <circle cx="-130" cy="25" r="77"/>',
   '    <circle cx="150" cy="25" r="77"/>',
   '  </g>', '</svg>'];
 };
 P.scenes[19]=Object.assign({},old[19],{
  title:'代码美学',en:'DRAW. COMPILE. RIDE.',date:'2020s',dark:true,accent:'#007acc',uiNativeLabels:true,
  riderClip:{x:0,y:461,w:1600,h:293},
  draw(c,t){
   c.drawImage(K.cached('interfaces-r2-pelican-studio',d=>{
    K.rect(d,0,0,1600,900,K.gradient(d,[0,0],[1600,900],[[0,'#172129'],[1,'#242e33']]));I.round(d,42,60,1523,779,6,'rgba(0,0,0,.25)');I.round(d,35,53,1529,779,5,'#1e1e1e','#4b5054',1);
    K.rect(d,36,54,1527,34,'#3c3c3c');K.path(d,'M54 62 L47 70 L54 78 M70 62 L77 70 L70 78',null,'#7edfd0',2);K.circle(d,62,70,5,null,'#b7e8de',1.2);K.line(d,[[62,65],[62,75]],'#6cb6b0',.8);
    K.text(d,'File  Edit  Selection  View  Go  Run  Terminal  Help',88,76,12,'#d5d5d5','left','sans');K.text(d,'鹈鹕工坊 · 代码美学 / CODE AESTHETICS · 2020s',1020,77,16,'#dfdfdf','center','sans');K.text(d,'—   □   ×',1537,77,14,'#ccc','right','mono');
    K.rect(d,36,88,48,723,'#333333');K.rect(d,36,100,3,41,'#f0f0f0');I.icon(d,'file',61,121,1.05,'#ececec');I.icon(d,'search',61,178,1.05,'#9d9d9d');I.icon(d,'branch',61,237,1.05,'#9d9d9d');I.icon(d,'play',61,293,.85,'#9d9d9d');I.icon(d,'extensions',61,350,.95,'#9d9d9d');I.icon(d,'contacts',59,752,.8,'#9d9d9d');I.icon(d,'settings',61,791,1.05,'#9d9d9d');
    K.rect(d,84,88,202,365,'#252526');K.text(d,'EXPLORER',104,115,12,'#bbb','left','sans');I.icon(d,'more',264,111,.75,'#aaa');K.text(d,'⌄  PELICAN',100,147,12,'#ccc','left','mono','700');
    K.text(d,'⌄ src',114,176,14,'#ccc','left','mono');K.rect(d,85,186,200,27,'#37373d');K.text(d,'◇',133,204,13,'#78d1ce','left','mono','700');K.text(d,'rider.svg',162,204,14,'#eee','left','mono');K.text(d,'◇',135,233,15,'#8bc3e5','left','mono');K.text(d,'road.svg',162,233,14,'#ccc','left','mono');K.text(d,'◇',135,261,15,'#8bc3e5','left','mono');K.text(d,'motion.js',162,261,14,'#ccc','left','mono');
    K.rect(d,85,286,200,25,'#303031');K.text(d,'⌄ CALL STACK',99,304,12,'#bbb','left','mono','700');K.text(d,'ride',112,335,13,'#c8c8c8','left','mono');K.text(d,'motion.js',168,335,11,'#929292','left','mono');
    K.rect(d,286,88,1277,36,'#252526');K.rect(d,286,88,173,36,'#1e1e1e');K.rect(d,286,88,173,2,'#007acc');K.text(d,'◇',300,111,14,'#78d1ce','left','mono','700');K.text(d,'rider.svg',328,111,14,'#ddd','left','mono');K.text(d,'×',441,111,15,'#aaa','center');K.text(d,'JS  motion.js',475,111,14,'#929292','left','mono');K.text(d,'×',611,111,15,'#747474','center');
    K.text(d,'src  ›  rider.svg  ›  pelican',305,144,13,'#999','left','mono');I.icon(d,'play',1490,106,.6,'#a5be9b');K.rect(d,1521,98,15,15,null,'#a4a4a4',1);K.line(d,[[1529,98],[1529,113]],'#a4a4a4',1);I.icon(d,'more',1551,106,.6,'#999');
    K.line(d,[[351,155],[351,438]],'#303030',1);K.line(d,[[377,155],[377,438]],'#292929',1);
    K.rect(d,1452,155,93,275,'#202020');for(let j=0;j<37;j++){let y=163+j*6.8;K.rect(d,1461,y,19+(j*17)%59,2.1,['#59734c','#6b89a3','#a38a70','#8a7995'][j%4]);}K.rect(d,1455,159,87,103,'rgba(147,147,147,.08)','#454545',.6);K.rect(d,1552,155,8,275,'#232323');K.rect(d,1553,163,6,142,'#494949');
    K.rect(d,84,453,1479,29,'#252526');K.text(d,'◉  pelican.canvas',106,473,13,'#c5c5c5','left','mono');K.rect(d,105,480,141,2,'#007acc');K.text(d,'PREVIEW',1517,473,11,'#737d83','right','mono');
    K.rect(d,85,483,1477,270,K.gradient(d,[85,483],[1562,753],[[0,'#142b35'],[1,'#102029']]));for(let x=99;x<1561;x+=25)K.line(d,[[x,483],[x,752]],'rgba(114,159,169,.07)',1);for(let y=499;y<753;y+=25)K.line(d,[[85,y],[1562,y]],'rgba(114,159,169,.07)',1);
    K.rect(d,84,754,1479,57,'#1e1e1e');K.line(d,[[84,754],[1563,754]],'#3c3c3c',1);K.text(d,'PROBLEMS   OUTPUT   DEBUG CONSOLE   TERMINAL   PORTS',104,775,11,'#939393','left','mono');K.rect(d,383,781,64,1,'#ddd');K.text(d,'bash',1455,775,11,'#a5a5a5','left','mono');K.text(d,'+  ⌄  □  ×',1544,775,12,'#a5a5a5','right','mono');
    // Side rails leave the road open for the same rider to enter and leave.
    K.rect(d,34,463,4,265,'#172d35');K.rect(d,1561,463,4,265,'#16282f');K.line(d,[[31,463],[41,463]],'#638a8e',1.3);K.line(d,[[1558,463],[1568,463]],'#638a8e',1.3);
   }),0,0);
   const paused=t>=3.1&&t<3.65,stepped=t>=3.42,typing=K.clamp((t-1.92)/.96),p=I.rider(this,t),context=P.sceneContext||{},speed=paused?0:Number.isFinite(context.speed)?context.speed:1600/5.45;
   const motionSrc=['// 把路写出来，把心意带下去。','const road = new Path2D();','road.moveTo(0, 728);','road.lineTo(1110, 728);','road.quadraticCurveTo(1285, 644, 1460, 728);','road.lineTo(1600, 728);','','const rider = scene.find("pelican");','rider.follow(road);','// 小心心 ×1，下一站：发布会。','rider.bell();','requestAnimationFrame(ride);'];
   const svgMode=t<2.9,src=svgMode?I.svgLines():motionSrc,svgProgress=K.clamp((t-.35)/2.5),active=svgMode?Math.min(11,Math.floor(svgProgress*12)):t<3.1?8:paused?(stepped?11:10):11;
   if(!svgMode){K.rect(c,286,88,173,36,'#252526');K.text(c,'◇  rider.svg',300,111,14,'#929292','left','mono');K.rect(c,459,88,177,36,'#1e1e1e');K.rect(c,459,88,177,2,'#6dd7c8');K.text(c,'JS  motion.js',475,111,14,'#ddd','left','mono');K.rect(c,299,128,500,22,'#1e1e1e');K.text(c,'src  ›  motion.js  ›  ride',305,144,13,'#999','left','mono');}
   c.save();c.beginPath();c.rect(309,151,782,290);c.clip();
   for(let j=0;j<src.length;j++){const y=172+j*22;if(svgMode&&j>active)continue;let text=src[j];if(svgMode&&j===active&&svgProgress<1)text=text.slice(0,Math.floor((svgProgress*12-active)*text.length));K.text(c,String(j+1),331,y,14,j===active?'#d4e8dd':'#777','right','mono');if(j===active)K.rect(c,348,y-17,740,22,paused?'rgba(201,166,64,.17)':'rgba(121,160,190,.1)');const end=svgMode?I.xmlSyntax(c,text,367,y,15.7):I.syntax(c,text,367,y,16.3);if(svgMode&&j===active&&svgProgress<1)K.rect(c,Math.min(end+2,1080),y-16,1.5,19,'#e2e2e2');}
   c.restore();
   K.circle(c,299,386,5.2,paused?'#f3b44d':'#da5555');if(paused)K.path(c,`M307 ${stepped?402:380} l8 6 -8 6Z`,'#e8c46c');
   I.svgBlueprint(c,t,p);
   K.rect(c,89,350,193,97,'#222a2a');K.text(c,'WATCH',104,368,11,'#7a9f96','left','mono');K.text(c,'x: '+p.x.toFixed(1),104,391,12,'#a7d3c6','left','mono');K.text(c,'v: '+speed.toFixed(1),104,413,12,paused?'#edc783':'#a7d3c6','left','mono');K.text(c,'gift.heart: 1',104,435,12,'#dca3ad','left','mono');
   I.round(c,1123,158,277,35,4,'#333333','#515151',1);I.icon(c,'play',1144,176,.63,paused?'#75beff':'#9cba90');K.path(c,'M1177 177 q0 -11 13 -8 l4 4 M1187 163 l8 10 -12 1',null,'#75beff',1.6);K.line(c,[[1186,179],[1186,186]],'#75beff',1.5);K.path(c,'M1225 164 v15 l-5 -5 M1225 179 l5 -5',null,'#75beff',1.6);K.path(c,'M1264 183 v-15 l-5 5 M1264 168 l5 5',null,'#75beff',1.6);K.path(c,'M1297 170 a7 7 0 1 1 -1 11 M1297 164 v8 h8',null,'#85bf9b',1.5);K.rect(c,1334,169,12,12,'#e78484');
   K.text(c,'F5',1144,207,11,paused?'#b2c8d9':'#6b7781','center','mono');K.text(c,'F10',1188,207,11,paused?'#b2c8d9':'#6b7781','center','mono');
   if(paused){const click=K.clamp((t-3.12)/.3),x=t<3.48?K.lerp(1242,1188,click):K.lerp(1188,1144,K.clamp((t-3.48)/.17));K.path(c,`M${x} 191 l4 17 5 -5 6 -1Z`,'#eee','#303030',1);if((t>3.42&&t<3.49)||(t>3.6&&t<3.65)){K.circle(c,x+2,185,13,null,'rgba(222,198,113,.55)',1.5);}}
   // The source curve and the rolling road use exactly the same control point.
   const floor=x=>old[19].ground(x),segments=[[[170,728],[1110,728]],[[1460,728],[1470,728]]];for(const pts of segments){K.line(c,pts.map(([x,y])=>[x,y+6]),'#335357',9);K.line(c,pts,'#8abdb1',1.7);}
   const end=1110+350*typing,arc=[];for(let x=1110;x<=end;x+=3)arc.push([x,floor(x)]);if(end>1110)arc.push([end,floor(end)]);
   if(arc.length>1){K.line(c,arc.map(([x,y])=>[x,y+7]),'#31565c',10);c.save();c.shadowColor=paused?'#eccb75':'#66dbd5';c.shadowBlur=paused?7:11;K.line(c,arc,paused?'#d6c586':'#7fe4d6',2.8);c.restore();K.line(c,arc,'#d3f4db',.9);}
   if(typing>0&&typing<1){K.line(c,[[1110,728],[1285,644],[1460,728]],'rgba(131,205,207,.5)',1);for(const [x,y]of [[1110,728],[1285,644],[1460,728]]){K.circle(c,x,y,4,'#76bfcd','#c8e6de',1);}K.text(c,'(1285, 644)',1285,629,12,'#8ec9d1','center','mono');K.circle(c,end,floor(end),5,'#fff0bc');c.save();c.setLineDash([3,6]);K.path(c,`M1007 257 C1150 321 1070 568 ${end} ${floor(end)-12}`,null,'rgba(101,194,205,.32)',1.2);c.restore();}
   if(paused){I.round(c,1137,492,380,32,4,'rgba(83,72,38,.8)','#9f8d59',.8);K.text(c,stepped?'单步：车铃响了。下一步，继续。':'暂停于断点 · 等一个继续。',1327,514,16,'#e1ce9e','center');}
   else if(t>=3.65){const a=K.ease((t-3.65)/.25);c.save();c.globalAlpha=a;K.text(c,'路写好了。带着心意，继续。',1266,228,15,'#bddbd4','center');c.restore();}
   K.text(c,'$ node motion.js',105,801,12,'#c9c9c9','left','mono');K.text(c,t<2.88?'svg: drawing path '+Math.min(6,Math.floor(K.clamp((t-.35)/2.5)*6)+1)+'/6…':paused?(stepped?'bell: ding!':'paused: motion.js:11'):'road ready · gift.heart = 1 · riding on',320,801,12,paused?'#d7ba7d':'#a0cfa0','left','mono');
   K.rect(c,36,811,1527,21,paused?'#b85b34':'#007acc');K.text(c,'⑂ main   ○ 0   △ 0',52,827,12,'#fff','left','mono');K.text(c,'Ln '+String(active+1)+', Col 1     UTF-8   LF   '+(svgMode?'SVG':'JavaScript'),1226,827,12,'#fff','right','mono');K.text(c,paused?'Debugger attached':'Go Live',1505,827,12,'#fff','right','mono');
  },
  pose(t){const p=old[19].pose.call(this,t);return Object.assign(p,{bellPress:Math.sin(Math.PI*K.clamp((t-3.42)/.16)),gazeX:t>=3.1&&t<3.65?-.25:1,gazeY:t>=3.1&&t<3.65?-.6:0});},
  foreground(c,t,a,p){p=p||this.pose(t);I.bell(c,p,(t-3.42)/.6,'#e5d391');I.carriedHeart(c,p);if(t>=3.1&&t<3.65){const q=I.giftPoint(p);c.save();c.globalAlpha=.76;c.setLineDash([3,5]);K.path(c,`M258 431 C395 464 524 511 ${q.x-18} ${q.y-7}`,null,'#d3a785',1);c.setLineDash([]);K.circle(c,q.x,q.y,15,null,'#e6c78b',1.3);c.restore();}}

 });
 P.interfaceStory={cast:['大肥鱼','GPT','Claude','豆包'],avatarMode:'original vector portraits; no raster assets',chatInterface:'叮咚2009 · fictional desktop messenger',liveInterface:'顺路 LIVE · fictional portrait broadcast',liveFormat:'9:16 portrait',chatSave:3.18,liveGiftAttach:3.18,carriedGift:'heart',note:'Fictional dialogue and staged UI interactions; a single visible gift persists into the code scene.'};
 P.interfaceTiming={scope:{hold:[2.35,3.75],reference:1.91,warp:[2.15,3.6],lock:3.6,bell:3.7},pixel:{spring:2.1,collect:[2.6,3.1,3.6],land:4.5,checkpoint:4.65,delivery:5.35},vapor:{stutter:[2,3],repeats:4,repeatSeconds:.25,speedup:5.5},chat:{hold:[2.6,3.6],send:2.25,reply:3.02,shake:[2.48,2.82]},live:{hold:[2.4,3.6],gift:2.95,bell:3.18},code:{hold:[3.1,3.65],step:3.42,bell:3.5,resume:3.65}};
})();
