/* Travelling through ten materials. Stage painters own the static architecture;
   characters, their painted afterimages, numbering, and the actual wheel contact
   remain on the director's live clock. All pigment/grain is generated locally. */
(()=>{
'use strict';
const H=P.historic, TAU=Math.PI*2, rnd=K.rnd;
const path=K.path.bind(K), ellipse=K.ellipse.bind(K), rect=K.rect.bind(K);
const line=(g,d,col,w=1)=>path(g,d,null,col,w);
const seg=(g,a,b,c,d,col,w=1)=>K.line(g,[[a,b],[c,d]],col,w);
function at(g,x,y,s,paint,sy=s){g.save();g.translate(x,y);g.scale(s,sy);paint(g);g.restore()}
function crop(g,d,paint){g.save();g.clip(new Path2D(d));paint();g.restore()}
function grad(g,x1,y1,x2,y2,colors){return K.gradient(g,[x1,y1],[x2,y2],colors)}
function clamp(x){return Math.max(0,Math.min(1,x))}
function smooth(x){return x*x*(3-2*x)}
function noise(x,y,seed){
 const xx=Math.floor(x),yy=Math.floor(y),fx=smooth(x-xx),fy=smooth(y-yy);
 const hash=(a,b)=>{let k=Math.imul(a,374761393)+Math.imul(b,668265263)+Math.imul(seed,144269);k=Math.imul(k^k>>>13,1274126177);return ((k^k>>>16)>>>0)/4294967295};
 const a=hash(xx,yy),b=hash(xx+1,yy),c=hash(xx,yy+1),d=hash(xx+1,yy+1);
 return (a+(b-a)*fx)*(1-fy)+(c+(d-c)*fx)*fy;
}
// Value fields and fine dry pigment are anchored to the substrate. Generate only
// once in a new cache surface instead of shifting a random screen-space overlay.
function paper(g,col,amount,seed,width=690){
 const h=Math.round(width*9/16),cv=P.makeCanvas(width,h),cx=cv.getContext('2d'),im=cx.createImageData(width,h);
 for(let y=0;y<h;y++)for(let x=0;x<width;x++){
   const i=(y*width+x)*4,n=(noise(x/105,y/72,seed)-.5)*.7+(noise(x/29,y/16,seed+1)-.5)*.37+(noise(x/4.5,y/2.3,seed+2)-.5)*.32+(rnd(i+seed)-.5)*.44;
   for(let k=0;k<3;k++)im.data[i+k]=col[k]+n*amount[k];im.data[i+3]=255;
 }cx.putImageData(im,0,0);g.drawImage(cv,0,0,1600,900)
}
function relief(g,color,seed,count){for(let j=0;j<count;j++){const x=rnd(j*3+11+seed)*1600,y=rnd(j*3+12+seed)*900,w=.5+2*rnd(j*3+13+seed);g.fillStyle=color;g.fillRect(x,y,w,w*.69)}}
function cloth(g,pts,under,over){K.line(g,pts,under,3.2);K.line(g,pts.map(([x,y])=>[x,y-1]),over,1)}
function lotusFlower(g,x,y,s,light,mid,dark){
 at(g,x,y,s,c=>{for(let k=-3;k<=3;k++){c.save();c.rotate(k*.26);path(c,'M0 5 Q-20 -2 -8 -24 Q-4 -38 -2 -44 Q12 -38 14 -22 Q20 0 0 5Z',k%2?light:mid,dark,1.3);line(c,'M0 2 Q6 -13 0 -31',dark,.85);c.restore()}path(c,'M-20 0 Q0 14 21 0 Q12 12 0 14 Q-10 12 -20 0Z',dark)});
}
function bull(g,x,y,s,dir,fill,ink){
 at(g,x,y,s*dir,c=>{
  const body='M-120 -18 Q-129 -51 -102 -68 Q-76 -85 -46 -77 Q-12 -77 29 -90 Q57 -104 73 -79 L90 -54 Q102 -59 114 -45 L131 -32 L127 -23 Q106 -20 92 -32 L75 -34 L66 -15 L60 27 L72 53 L64 55 L45 34 L39 -2 Q19 8 -4 6 Q-26 12 -43 3 L-61 32 L-81 59 L-92 60 L-78 30 L-74 -6 L-94 11 L-115 38 L-128 45 L-119 26 L-106 -1Z';
  path(c,body,fill,ink,1.5);line(c,'M100 -44 Q73 -52 63 -81 Q60 -102 35 -105 Q52 -114 67 -95 Q76 -69 103 -56 M112 -44 Q140 -53 147 -83 Q150 -104 166 -112 Q155 -91 156 -77 Q150 -45 119 -35',ink,3.6);
  path(c,'M80 -51 Q74 -71 58 -66 Q67 -48 82 -46Z',fill,ink,1.2);ellipse(c,109,-38,2.7,2.1,ink);
  line(c,'M-116 -47 Q-137 -43 -144 -21 Q-153 7 -165 6 M-162 8 l-17 5',ink,2.9);
  crop(c,body,()=>{for(let j=0;j<36;j++){let xx=-135+j*8;line(c,`M${xx} -110 q12 49 -7 72 q-19 35 12 68`,'rgba(244,178,111,.36)',1.6+(j%4)*.45)}});
 },s);
}
function sahara(g){
 paper(g,[186,114,70],[124,119,99],31,850);
 const outcrop='M-60 74 Q183 89 293 36 Q490 -30 611 24 L734 13 Q988 -30 1189 26 L1650 0 V637 L1532 622 L1443 679 L1255 637 L1112 664 L900 630 L732 691 L540 649 L323 677 L175 637 L-60 672Z';
 path(g,outcrop,grad(g,0,35,1280,743,[[0,'#ba8355'],[.46,'#d7a06b'],[.81,'#d1a174'],[1,'#b2764b']]));
 crop(g,outcrop,()=>{for(let row=0;row<185;row++){let pts=[];let sy=row*4.1;for(let x=-10;x<1640;x+=9){const y=sy+24*Math.sin(x*.005+sy*.003)+13*Math.cos(x*.012-sy*.012)+11*(noise(x/83,sy/65,31)-.5);pts.push([x,y])}K.line(g,pts,row%7===0?'rgba(102,50,33,.19)':'rgba(244,204,150,.115)',row%7===0?1.7:1.1)}
  for(let i=0;i<700;i++){let x=1600*rnd(i*7),y=650*rnd(i*7+2),h=8+rnd(i*7+4)*33;line(g,`M${x} ${y} l-6 ${h*.34} 2 ${h*.2} -5 ${h*.4}`,'rgba(95,52,33,.17)',.7+rnd(i+7)*1.5)}
 });
 path(g,'M0 754 Q198 713 386 729 T768 731 Q991 696 1257 727 T1600 706 V900 H0Z','#a76946'); 
 line(g,'M0 751 Q198 715 386 729 T768 731 Q991 696 1257 727 T1600 706','#e1ac75',4);
 // One monumental bovine was painted first. The later procession is small by
 // comparison, as though another generation chose a different scale.
 bull(g,498,452,2.0,1,'#873f2c','#653826');bull(g,1247,409,.93,-1,'#7d432d','#663a27');bull(g,1400,529,.57,-1,'#91563a','#633f29');
 H.ochreHerder(g,165,623,1.59,'#783724',0,1,0);H.ochreHerder(g,1385,627,1.19,'#743c29',0,-1,1);
 for(const [x,y,s] of [[132,238,.77],[225,278,.43],[1438,170,.65],[1508,224,.5]])at(g,x,y,s,c=>{let a=c.createRadialGradient(0,0,8,0,0,47);a.addColorStop(0,'#965333');a.addColorStop(1,'rgba(120,53,30,0)');rect(c,-49,-49,98,98,a);H.hand(c,0,8,.83,'#d5a47b',-.13)});
 relief(g,'rgba(250,224,167,.25)',123,17000);
}
function egypt(g){
 paper(g,[220,181,120],[48,51,40],46);
 const navy='#174c59',lapis='#226477',gold='#dfb35f',red='#9e4836';
 rect(g,0,0,1600,36,navy);rect(g,0,36,1600,7,gold);rect(g,0,186,1600,11,red);
 rect(g,0,205,1600,227,'#426f76');rect(g,0,211,1600,210,grad(g,0,211,0,421,[[0,'#305968'],[1,'#628d8b']]));
 for(let j=0;j<82;j++){let x=14+(j%28)*61+(Math.floor(j/28)%2)*26,y=230+Math.floor(j/28)*55;K.star(g,x,y,2.1+(j%3)*.8,'#cbb579')}
 // An unpainted plaster niche follows the reserved figure field. The hard edge
 // of the blue frieze never runs through the afterimage on the ochre plaster.
 const plaster='M508 750 V333 Q528 240 625 226 Q792 204 977 229 Q1066 242 1096 330 V750Z';
 path(g,plaster,grad(g,506,238,1080,726,[[0,'#dcbe82'],[.42,'#e1c590'],[1,'#d7b880']]),'#ae8a58',1.5);
 // Papyrus boat frieze and paired lotus columns frame the live mural painter.
 for(const [x,dir] of [[432,1],[1168,-1]])at(g,x,352,dir,c=>{
  path(c,'M-180 -62 Q-138 8 -53 8 L89 8 Q141 7 177 -36 Q152 30 99 35 L-68 35 Q-126 32 -160 -4Z',gold,navy,2.6);
  line(c,'M-164 -42 Q-139 16 -51 17 L88 17 Q139 16 162 -12',red,3);
  rect(c,-43,-42,82,51,'#e2b862',navy,2);path(c,'M-52 -42 L-40 -56 L43 -56 L51 -42Z',red,navy,2);
  for(let k=0;k<6;k++)seg(c,-36+k*13,-40,-36+k*13,8,navy,1.5);
  for(let j=0;j<4;j++){let xx=-112+j*21;ellipse(c,xx,-26,5,7,'#88452c');line(c,`M${xx} -20 q-6 6 -9 21 h16 M${xx} -15 l10 11 9 -10 M${xx+15} -17 l-33 52`,navy,3)}
 },1);
 for(const x of [161,1439])at(g,x,754,1,c=>{
  path(c,'M-43 0 L-32 -436 Q-26 -468 -53 -496 L-57 -514 H57 L53 -496 Q26 -468 32 -436 L43 0Z','#c6a059',navy,3);
  for(let k=-2;k<=2;k++){path(c,`M${k*9} -440 Q${k*19} -458 ${k*24} -507 Q${k*24+14} -489 ${k*9+7} -440Z`,k%2?lapis:'#8d9b72',navy,1.5);seg(c,k*13,-421,k*15,-10,'#a6844b',2)}
  rect(c,-39,-436,78,11,red,navy,1);rect(c,-45,-11,90,13,lapis,navy,2);
 });
 // One outsized seated scribe anchors the lower register. Its lifted split nib
 // points to the central blank where the live cyclist will leave an imprint.
 at(g,376,735,1.04,c=>{
  const skin='#a35f40',outline='#674c3a',white='#e9d6a5';
  path(c,'M-67 -15 H81 V-3 H-99 V-49 H-66Z',navy,outline,2);
  path(c,'M-18 -171 Q-36 -172 -37 -148 L-43 -79 Q-32 -55 -2 -57 L14 -56 Q42 -73 43 -65 L63 -34 L95 -25 L99 -19 L59 -18 L23 -41 Q16 -49 -1 -43 L-44 -26 L-86 -24 L-86 -32 L-59 -43 L-71 -75 L-65 -132 Q-59 -163 -44 -177Z',skin,outline,2);
  path(c,'M-66 -79 Q-47 -82 -17 -69 L9 -60 L-35 -29 L-90 -27 L-91 -34 L-70 -46Z',white,outline,2);
  for(let j=0;j<10;j++)line(c,`M${-62+j*5} -66 l${-10-j} 27`,'#aa9875',1.15);
  path(c,'M-46 -177 Q-49 -200 -39 -211 L-9 -209 L-7 -176 L6 -155 Q0 -146 -18 -145 L-45 -161Z',skin,outline,2);
  path(c,'M-54 -212 Q-52 -246 -27 -252 Q-8 -256 8 -242 Q23 -226 32 -215 L53 -196 Q71 -184 85 -162 Q60 -179 33 -188 L0 -192 Q-12 -188 -32 -172 L-58 -177Z','#516e70',navy,2.2);
  path(c,'M13 -221 Q42 -201 59 -190 Q77 -177 85 -162 Q58 -189 30 -192 L5 -199Z','#c2a163',outline,1.9);
  ellipse(c,9,-220,8.5,5.7,white,outline,1.1);ellipse(c,12,-220,2.8,3.6,navy);
  for(let j=0;j<5;j++)line(c,`M${-44+j*6} -217 q-10 12 -11 31`,'#839491',1.4);
  path(c,'M-46 -171 Q-28 -148 -10 -152 L10 -164 Q15 -154 6 -139 Q-13 -125 -29 -138 Q-47 -147 -51 -162Z',lapis,outline,1.6);
  line(c,'M-29 -127 Q-18 -97 -1 -91 L47 -112 Q58 -119 63 -118 L57 -108 L3 -74 Q-17 -73 -40 -111',skin,10);
  seg(c,49,-108,89,-148,outline,2.8);path(c,'M64 -122 Q59 -143 75 -161 Q84 -162 82 -151 Q78 -132 64 -122Z','#657d69',outline,1.1);
  path(c,'M-3 -65 L51 -84 L83 -77 L24 -54Z','#e9cd8a',outline,2.1);
 });
 for(let i=0;i<5;i++)for(const x of [230+i*19,1370-i*19]){const y=745;line(g,`M${x} ${y} q3 -39 ${i*1.6-4} -64`,'#587762',2);lotusFlower(g,x+i*1.6-4,y-64-(i%2)*8,.42,'#65939a','#597d80',navy)}
 rect(g,0,752,1600,9,navy);for(let x=0;x<1600;x+=34){rect(g,x,762,30,18,[lapis,red,'#bca75f'][Math.floor(x/34)%3],navy,.7)}
 relief(g,'rgba(233,209,155,.24)',269,21000);
}
function han(g,old){
 old(g);
 // New upper register: rubbing of two running horses and the serrated sun.
 rect(g,40,243,1514,212,'#242c28');
 for(let j=0;j<18;j++){let x=j*91-18,y=251;line(g,`M${x} ${y} q24 0 39 18 q19 24 41 6 q13 -13 1 -19 q-12 -6 -13 7`,'#929989',2.5)}
 function horse(x,y,s,dir){at(g,x,y,dir*s,c=>{path(c,'M-87 -6 Q-97 -31 -78 -46 Q-61 -59 -36 -49 Q-7 -44 19 -49 Q40 -56 54 -89 L66 -106 L68 -94 L81 -104 L79 -87 Q93 -79 103 -68 L107 -57 L101 -53 L78 -65 L71 -59 L63 -35 Q56 -10 36 -1 L68 25 L93 19 L101 24 L68 38 L22 16 L13 10 L-18 14 L-38 9 L-58 30 L-93 47 L-107 45 L-93 37 L-70 19 L-55 -3 Q-75 6 -86 38 L-103 70 L-113 70 L-107 57 L-98 31 L-91 5Z','#d7d5ad');path(c,'M-84 -34 Q-111 -53 -124 -47 Q-147 -36 -162 -53 Q-151 -25 -129 -33 Q-108 -39 -87 -21Z','#d7d5ad');line(c,'M41 -57 Q63 -98 76 -84 M-67 -32 Q-40 -21 2 -31 M29 -11 Q44 -18 55 -37','#3a4035',2.8);ellipse(c,83,-78,2,2,'#343d32')},s)}
 horse(569,381,.94,1);horse(1026,381,1.03,-1);horse(182,382,.79,1);horse(1420,382,.76,-1);
 at(g,806,321,1,c=>{for(let j=0;j<23;j++){c.rotate(TAU/23);path(c,'M-2 -31 L0 -48 L3 -31Z','#c8c5a3')}ellipse(c,0,0,32,32,'#c1bf9f');ellipse(c,0,0,24,24,'#2e3830')});
 // A pair of stone gate towers forms a passage in the printed scene. Reserve
 // the pale rock on the roofs and cut the timber lines out of that pale mass.
 for(const [x,dir] of [[335,1],[1367,-1]])at(g,x,731,dir,c=>{
  const pale='#c2c1a1',ink='#303b32';
  path(c,'M-85 5 L-84 -10 L-64 -21 L-63 -35 H62 L65 -21 L85 -11 V5Z',pale,ink,2);
  path(c,'M-51 -33 L-41 -137 H40 L49 -33Z',pale,ink,2.4);
  path(c,'M-62 -136 L-63 -159 L-53 -158 L-54 -170 L-42 -170 V-181 H44 V-170 L55 -171 L55 -158 H63 V-136Z',pale,ink,2.2);
  rect(c,-59,-215,118,39,pale,ink,2);for(let j=-2;j<=2;j++)rect(c,j*22-7,-207,14,23,ink);
  path(c,'M-115 -214 Q-85 -224 -72 -241 L-41 -248 L-39 -267 Q-25 -284 -22 -292 Q-3 -286 15 -292 Q27 -274 42 -265 L43 -247 L75 -240 Q90 -222 117 -218 L112 -211 L0 -216 L-113 -207Z',pale,ink,2);
  for(let j=-7;j<=7;j++)line(c,`M${j*8} -242 l${j*3} 19`,ink,1.3);
  for(let j=0;j<7;j++){line(c,`M-38 ${-126+j*13} l21 -4 18 6 25 -3`,ink,1.3);line(c,`M-58 ${-156+j%3*5} h116`,ink,.85)}
 },1);
 relief(g,'rgba(204,204,180,.26)',89,32000);
}
function tang(g,old){
 // Freestanding six-leaf silk screen. Its oblique alternating leaves give the
 // painter six silk surfaces to continue the same river across. The actual
 // dancers remain live on the floor in front of it.
 paper(g,[233,223,193],[29,23,16],201);
 const heights=[233,199,220,190,212,187,214],width=224,start=117;
 for(let j=0;j<6;j++){
  let x=start+j*width,ya=heights[j],yb=heights[j+1],a=649+(j%2)*12,b=649+((j+1)%2)*12;
  const panel=`M${x} ${ya} L${x+width} ${yb} V${b} L${x} ${a}Z`;
  path(g,panel,grad(g,x,0,x+width,0,[[0,j%2?'#c9b58e':'#e0cda5'],[.14,j%2?'#dbcaab':'#eee0be'],[1,j%2?'#e3d1ad':'#d4bf99']]),'#82775c',2.1);
  crop(g,panel,()=>{for(let n=0;n<27;n++){const yy=ya+16+n*17;line(g,`M${x+3} ${yy} L${x+width-3} ${yy+yb-ya}`,'rgba(160,144,108,.14)',.65)}
    for(let row=0;row<5;row++){let pts=[];for(let xx=x-2;xx<x+width+5;xx+=5){let yy=457+row*19+23*Math.sin(xx*.013+row*.11)+28*Math.sin(xx*.009-row*.3)-32*Math.sin(xx*.004+1.4);pts.push([xx,yy])}K.line(g,pts,row===0?'#88846c':'rgba(130,125,97,.55)',row===0?1.7:.85)}
    if(j%2===0){const xx=x+92,yy=541;line(g,`M${xx} ${yy} q42 11 94 -3 q-10 18 -63 15Z`,'#81785d',1.7);line(g,`M${xx+36} ${yy+4} q9 -24 26 -22 q15 3 18 20 M${xx+72} ${yy} l23 -26`,'#82775f',1.2)}
  });
  line(g,`M${x+7} ${ya+12} L${x+width-7} ${yb+12} V${b-11} L${x+7} ${a-11}Z`,'#ac9876',1.3);
  rect(g,x-3,a,8,21,'#84785f');if(j===5)rect(g,x+width-3,b,8,20,'#84785f');
 }
 line(g,'M0 748 H1600','#8a8063',2.2);
 for(let j=0;j<64;j++){let xx=rnd(j+15)*1600,yy=754+rnd(j+81)*100;seg(g,xx,yy,xx+9+rnd(j+3)*37,yy-1,'rgba(146,135,108,.34)',.7)}
 const ink='#696551';
 // A winding opening in the silk screen is articulated by three layers of line.
 for(const [xx,sy,sz,dir] of [[40,444,1.1,1],[1543,496,1.17,-1]])at(g,xx,sy,sz*dir,c=>{
  for(let j=0;j<8;j++){let y=j*14;line(c,`M-90 ${y} Q20 ${y-33} 82 ${y-10} Q134 ${y+11} 186 ${y-29} Q249 ${y-84} 290 ${y-78} Q348 ${y-75} 369 ${y-113} Q400 ${y-177} 466 ${y-157}`,j===0?'#8e8c78':'rgba(139,136,108,.35)',j===0?1.9:1.1)}
 },sz);
 // Two cranes spiral through opposite ends of one continuous cloud ribbon.
 for(const [x,y,s,flip] of [[485,366,1.32,1],[1108,314,1.04,-1]])at(g,x,y,s*flip,c=>{
  path(c,'M-45 12 Q-54 -12 -85 -46 Q-48 -39 -27 -24 Q-37 -71 -82 -89 Q-14 -91 8 -33 Q22 -20 33 -20 Q52 -18 66 -34 Q76 -43 90 -38 L111 -35 L90 -32 Q82 -34 75 -25 Q56 0 33 0 L1 7 L-37 28 L-72 29Z','#eee7d3',ink,2.3);
  for(let j=0;j<7;j++){line(c,`M${-15+j*6} ${-21+j*2} Q${-30-j*4} ${-53-j*.7} ${-68+j*4} ${-82+j*.8}`,ink,.95);line(c,`M${-30+j*3} ${-5+j} l${-38+j*2} ${-33+j*3}`,ink,.85)}
  ellipse(c,86,-38,3,1.6,'#a66a55');line(c,'M-38 11 l-66 18 -10 -2 M-31 16 l-59 26 -11 -1',ink,2);
 },s);
}
function maya(g,old){
 old(g);
 // Facing jaguar and plumed-serpent bookends occupy two full leaves.
 for(const [x,dir,animal] of [[229,1,0],[1371,-1,1]])at(g,x,488,dir,c=>{
  path(c,'M-163 -156 Q-75 -167 162 -155 L161 147 Q51 159 -160 147Z',animal?'#bd5941':'#477b72','#503d30',3);
  for(let j=-145;j<=145;j+=17){line(c,`M${j} -146 l5 9 -6 8 M${j} 138 l5 -8 -5 -8`,'#e7bf82',2)}
  if(!animal){
   path(c,'M-95 -20 Q-112 -46 -83 -63 L-61 -67 Q-84 -106 -61 -113 Q-35 -119 -31 -79 Q-2 -97 25 -90 Q48 -110 64 -96 Q73 -88 58 -64 Q87 -57 96 -30 L123 -21 L126 -4 L90 0 L114 24 L105 35 L66 16 Q42 46 7 42 Q-53 39 -83 59 L-111 48 L-79 16Z','#d89c4d','#51382a',4);
   for(let j=0;j<31;j++){let xx=-65+rnd(j+3)*100,yy=-52+rnd(j+8)*69;ellipse(c,xx,yy,4.5+rnd(j)*3,3.5,'#805537')};ellipse(c,49,-47,15,12,'#f2d996','#573f2d',3);ellipse(c,54,-47,4,7,'#593c28');path(c,'M92 -1 L100 16 L106 -1Z','#f3dfb0','#51382a',2);
  }else{
   for(let j=0;j<12;j++){c.save();c.translate(-20,-3);c.rotate(-2.74+j*.21);path(c,'M-1 0 Q-14 -37 0 -103 Q12 -110 17 -93 Q7 -59 3 1Z',j%2?'#377a72':'#7c9d6d','#574832',2);c.restore()}
   path(c,'M-111 68 Q-57 25 -82 0 Q-108 -25 -77 -44 Q-47 -67 -13 -49 Q24 -77 47 -66 L57 -46 L89 -31 L99 -16 L125 -16 L121 1 L57 1 L77 29 L111 23 L100 42 L58 46 L36 16 Q6 29 -13 18 Q-32 -10 -56 0 Q-27 29 -45 52 Q-74 83 -111 68Z','#85a17a','#503e30',4);ellipse(c,51,-36,12,9,'#eacd7b','#563d2f',2.5);ellipse(c,54,-36,4,7,'#583c2d');path(c,'M81 0 l5 18 7 -18Z','#f0dcb1','#553a2c',1.3);
  }
  line(c,'M-108 93 h203 m-173 10 h142','#efd09b',2.2);
 },1);
}
function garden(g,old){
 old(g); const ink='#573d3d',gold='#dcb567';
 path(g,'M110 237 H1490 V574 H110Z',grad(g,0,230,0,578,[[0,'#59777e'],[1,'#d9b895']]));
 for(let j=0;j<26;j++){let x=j*64,y=493+14*Math.sin(j*1.6);path(g,`M${x-34} 535 Q${x+8} ${y-7} ${x+45} ${y-40} Q${x+76} ${y+10} ${x+111} 535Z`,j%2?'#afab8f':'#8f9e91')}
 function pavilion(x,y,s,side){at(g,x,y,s,c=>{
  const wall=side?'#a95f52':'#be7562',lite='#e4a17c';rect(c,-152,-116,304,116,wall,ink,2);
  for(let j=-2;j<=2;j++){let xx=j*54;path(c,`M${xx-20} -3 V-70 Q${xx-23} -87 ${xx-11} -90 Q${xx-10} -99 ${xx} -106 Q${xx+10} -100 ${xx+13} -90 Q${xx+22} -86 ${xx+20} -70 V-3Z`,'#394e59',gold,2);rect(c,xx-22,-32,44,29,'#d39876',ink,.9);for(let k=0;k<3;k++)line(c,`M${xx-20} ${-24+k*8} l9 -6 10 6 10 -6 10 6`,'#efd0a1',1)}
  path(c,'M-162 -117 L-146 -129 H146 L164 -117 L161 -111 H-160Z',lite,ink,2);
  path(c,'M-91 -128 Q-97 -158 -64 -176 Q-31 -193 0 -226 Q25 -195 66 -176 Q96 -156 91 -128Z',side?'#ba8777':'#d9b19a',ink,2);
  for(let j=-3;j<=3;j++){line(c,`M0 -224 Q${j*31} -171 ${j*27} -129`,'#a36d5e',1.1)}
  seg(c,0,-227,0,-252,gold,2.7);ellipse(c,0,-244,4,5,gold);rect(c,-153,-4,306,9,lite,ink,1.4);
 })}
 pavilion(800,524,1.18,0);pavilion(360,519,.88,1);pavilion(1240,519,.88,1);
 for(const [x,s] of [[134,1.23],[508,.55],[1089,.58],[1460,1.21]])at(g,x,605,s,c=>{path(c,'M0 -222 Q-9 -192 -15 -164 Q-25 -147 -20 -129 Q-36 -103 -29 -89 Q-46 -42 -34 -20 Q-20 2 2 -5 Q40 4 38 -27 Q40 -50 27 -77 Q39 -98 18 -132 Q24 -144 12 -173Z','#305f58','#2e4f4e',1.4);line(c,'M1 -214 Q-1 -154 0 -60 V6 M-1 -109 Q-17 -122 -18 -145 M0 -73 Q15 -94 18 -116','#73936c',1.5)});
 for(const xx of [69,1530])for(let j=0;j<21;j++){let y=217+j*25;H.flower(g,xx,y,6.2,j%2?'#a95645':'#69836a',gold,6)}
}
function lotus(g){
 paper(g,[237,233,210],[23,24,17],103);
 const ink='#343e36'; 
 // Wet ink deposits at the leaf margins, with dry brush splitting at the ends.
 function leaf(x,y,rx,ry,rot,seed,colors){g.save();g.translate(x,y);g.rotate(rot);const points=[];let d='';for(let j=0;j<=120;j++){let a=TAU*j/120,rr=.91+.1*Math.sin(a*5.5+.7)+.07*Math.sin(a*9-1)+.09*(noise(Math.cos(a)*3+8,Math.sin(a)*3+9,seed)-.5);let xx=rx*rr*Math.cos(a),yy=ry*rr*Math.sin(a);points.push([xx,yy]);d+=(j?'L':'M')+xx+' '+yy}d+='Z';
  path(g,d,grad(g,-rx,-ry,rx,ry,[[0,colors[0]],[.62,colors[1]],[1,colors[2]]]));crop(g,d,()=>{for(let k=0;k<1340;k++){let xx=(rnd(k*4+seed)-.5)*rx*2.3,yy=(rnd(k*4+seed+1)-.5)*ry*2.3,v=noise(xx/33,yy/21,seed);if(v>.50)ellipse(g,xx,yy,1.9+v*7,1.1+v*4,'rgba(222,222,190,.10)')};
  for(let j=0;j<points.length;j+=8){let [xx,yy]=points[j];line(g,`M-5 8 Q${xx*.55-9} ${yy*.35+14} ${xx} ${yy}`,'rgba(205,209,178,.42)',1.8)}});g.restore()
 }
 path(g,'M-80 866 Q110 794 141 684 Q148 604 205 479 Q175 583 157 692 Q143 817 8 890Z','#454b3c');line(g,'M10 881 Q175 778 255 657 Q296 595 292 513',ink,3.2);
 leaf(145,527,194,97,-.27,72,['#838873','#515d4d','#344b40']);leaf(311,482,126,62,-.55,50,['#848b73','#747c62','#555e4c']);
 line(g,'M1269 767 Q1302 585 1410 418 Q1436 362 1451 319','#4f5b47',4);lotusFlower(g,1452,324,1.13,'#ead8c6','#d9b9a7','#776e5d');
 path(g,'M1271 774 Q1362 703 1383 630 Q1418 556 1473 532 Q1427 577 1416 653 Q1386 718 1271 774Z','#666e55');leaf(1460,559,108,55,-.42,9,['#a0a58a','#787f66','#495b49']);
 for(let j=0;j<16;j++){let x=33+rnd(j+8)*285,y=667+rnd(j+45)*167;ellipse(g,x,y,2.3+rnd(j+75)*4.5,1.8+rnd(j+31)*3.1,'rgba(57,66,48,.49)')}
 line(g,'M20 814 Q148 806 249 810 M274 811 q31 -2 78 -1 M1236 794 q118 -8 243 -4','rgba(97,115,88,.53)',1.4);
}
function wayang(g){
 paper(g,[62,38,31],[53,42,30],131);
 const lamp=g.createRadialGradient(781,436,40,800,493,810);lamp.addColorStop(0,'#ffe9a4');lamp.addColorStop(.31,'#edba72');lamp.addColorStop(.65,'#ad653b');lamp.addColorStop(1,'#4f302b');rect(g,55,161,1490,602,lamp);
 for(let x=58;x<1540;x+=4)seg(g,x,162,x,764,'rgba(94,51,31,.055)',.7);
 for(const x of [140,1460]){g.save();g.translate(x,742);g.scale(x<200?1:-1,1);
  const tree='M0 -510 Q-15 -463 -44 -433 Q-89 -378 -90 -336 Q-119 -280 -112 -233 Q-140 -172 -126 -132 Q-135 -90 -111 -45 L-121 -8 Q-60 16 3 0 Q63 16 124 -10 L111 -46 Q139 -96 127 -148 Q141 -187 113 -240 Q124 -278 95 -331 Q100 -373 52 -422 Q20 -468 0 -510Z';
  path(g,tree,'#533329','#dfae63',3.2);crop(g,tree,()=>{for(let q=0;q<15;q++){let yy=-459+q*30,w=clamp((yy+510)/320)*103;for(let j=-3;j<=3;j++){let xx=j/3*w;if(Math.abs(xx)<7)continue;path(g,`M${xx} ${yy} q-8 -6 -4 -14 q10 -7 11 2 q0 6 -7 12Z`,'#df9b54');line(g,`M${xx} ${yy+7} q11 4 14 -3`,'#bf7645',1)}}});line(g,'M0 7 Q-6 -223 0 -473 M0 -92 Q38 -133 73 -150 M0 -139 Q-49 -176 -87 -207 M0 -236 Q27 -267 59 -283','#e6ac60',3.1);g.restore()}
 rect(g,0,754,1600,21,'#63382c','#da9e51',2);rect(g,0,780,1600,90,'#55352e');for(let x=0;x<1600;x+=39){path(g,`M${x} 796 q11 -16 22 0 q12 16 20 0 M${x+8} 808 l11 -7 10 7 -10 8Z`,null,'#c18b51',1.4)}
 for(let j=0;j<58;j++){let xx=j*29-12;path(g,`M${xx} 154 q13 32 27 0Z`,j%2?'#8b4c3a':'#aa633b','#e3a85d',1.1)}
 // The top proscenium is carved in deep layers, with a pierced line of curls.
 for(const [x,dir] of [[0,1],[1600,-1]])at(g,x,166,dir,c=>{
  path(c,'M0 -34 H577 Q494 -22 416 5 Q319 40 260 56 Q174 86 120 135 Q71 181 45 225 L0 224Z','#63392e','#d99a51',2.2);
  for(let j=0;j<14;j++){let xx=37+j*29,yy=184*Math.exp(-xx/151)-7;line(c,`M${xx-24} ${yy+10} q18 -29 34 -22 q9 4 3 13 q-7 8 -15 1 q2 -5 8 -4`,'#bf864b',2.4)}
 },1);
}
function serpentShadow(g,l){
 const u=K.smoother((l-1.3)/1.1)*(1-K.smoother((l-4.4)/1.35)),qt=Math.floor(l*12)/12;
 const x=1510-134*u,y=523-97*u+Math.sin(qt*1.5)*2;g.save();
 g.beginPath();g.rect(55,163,1490,590);g.clip();
 at(g,x,y,1,c=>{c.rotate(.18-.12*u);
  line(c,'M-95 -58 L55 279','#72422c',3.2);
  const hide='M179 150 Q75 173 42 99 Q25 50 -6 40 Q-58 26 -76 -4 Q-90 -23 -105 -24 L-169 -21 L-143 -33 L-98 -41 Q-106 -54 -124 -54 L-178 -48 L-187 -58 Q-174 -73 -141 -76 Q-125 -83 -122 -97 Q-125 -123 -106 -120 Q-93 -116 -91 -93 Q-78 -93 -72 -104 Q-71 -132 -52 -145 Q-57 -118 -45 -114 L-13 -144 Q-16 -123 -32 -107 Q-8 -119 -1 -111 Q-8 -94 -30 -83 Q4 -71 17 -39 Q27 -10 36 8 Q69 47 90 96 Q118 152 181 138Z';
  const holes=new Path2D(hide);for(let j=0;j<36;j++){let f=j/35,px=-56+f*164,py=-66+f*186+19*Math.sin(f*4);holes.moveTo(px+3.6,py);holes.ellipse(px,py,3.5,2.5,-.45,0,TAU)}
  holes.moveTo(-97,-77);holes.ellipse(-104,-77,7.2,4.9,-.3,0,TAU);
  c.fillStyle='#80503b';c.fill(holes,'evenodd');line(c,hide,'#603e31',2);ellipse(c,-105,-78,2.1,2.5,'#70442f');
  for(let j=0;j<5;j++){let xx=-153+j*9.4;path(c,`M${xx} -49 l3 7 4 -7Z`,'#714734')}
 });g.restore();
}
// Northern Song: a split gorge of granite with hanging pines, pass, and a fine
// white cataract. Broken contour, progressive ink loads and clusters follow the
// changing strata of each face. The painter's main reserved white is the ravine.
function ridge(g,vertices,seed,light,mid,dark,dry,detail=1){
 const outline=[];for(let k=0;k<vertices.length-1;k++){let [x,y]=vertices[k],[u,v]=vertices[k+1],steps=Math.max(2,Math.round(Math.hypot(u-x,v-y)/9));for(let j=0;j<steps;j++){
  const f=j/steps,jit=Math.sin(Math.PI*f)*(noise(k*7+f*5,1,seed)-.5)*10;outline.push([x+(u-x)*f+jit*.62,y+(v-y)*f+jit]);}}
 outline.push(vertices.at(-1));const d='M'+outline.map(p=>p.join(' ')).join('L')+'Z';
 const xs=outline.map(p=>p[0]),ys=outline.map(p=>p[1]),min=Math.min(...xs),max=Math.max(...xs),top=Math.min(...ys),bottom=Math.max(...ys);
 path(g,d,grad(g,min,top,max,bottom,[[0,light],[.3,mid],[.72,dark],[1,mid]]));
 crop(g,d,()=>{
  // Creased planes share the cliff silhouette; alternating warm and cool ink
  // gives a broad light/shadow statement before any of the fine brushwork.
  for(let k=0;k<9;k++){
   const left=min+(max-min)*k/9-8,right=left+(max-min)*.13;
   let a=[],b=[];for(let j=0;j<=18;j++){
    let v=j/18,y=top+(bottom-top)*v,base=38*Math.sin(v*3.8+seed*.03)+19*Math.sin(v*8.5+k*.37);
    a.push([left+base+13*(noise(k*4,v*12,seed)-.5),y]);b.unshift([right+base+21*Math.sin(v*4+k*.8),y]);
   }
   const ridgePath='M'+a.concat(b).map(v=>v.join(' ')).join('L')+'Z';
   path(g,ridgePath,grad(g,left,top,right+13,top+5,[[0,'rgba(238,226,184,.29)'],[.42,'rgba(210,214,174,.06)'],[.65,'rgba(35,61,49,.08)'],[1,'rgba(20,45,38,.41)']]));
   if(k%2===1)K.line(g,a.slice(3,16),'rgba(50,67,51,.36)',1.65);
  }
  // Local vertical axes drift around diagonal rock joints. Broad diluted strokes
  // are emitted first, together with the fine forked axe-cuts on their edges.
  for(let i=0;i<175*detail;i++){let x=min+(max-min)*rnd(i*7+seed),y=top+(bottom-top)*rnd(i*7+seed+1),h=30+125*rnd(i+seed),w=8+30*rnd(i*5+seed);
   path(g,`M${x} ${y} q${-w*.37} ${h*.29} ${-w} ${h*.58} l${-w*.13} ${h*.42} q${w*.4} ${-h*.42} ${w*.91} ${-h*.52}Z`,'rgba(28,48,45,.115)')}
  for(let i=0;i<6000*detail;i++){let x=min+(max-min)*rnd(seed+i*3),y=top+(bottom-top)*rnd(seed+i*3+1),rr=rnd(seed+i*3+2),b=noise(x/65,y/141,seed+3),vein=Math.sin(x*.050+y*.023+4*b+.7*Math.sin(y*.024));let t=(b*.6+(vein*.5+.5)*.4),len=3+(rr**2)*22,w=.4+1.6*rr,drift=2+8*b;
   if(t>.52){g.strokeStyle=t>.72?'rgba(26,45,41,.43)':'rgba(39,57,48,.25)';g.lineWidth=w;g.beginPath();g.moveTo(x,y);g.quadraticCurveTo(x-drift*.2,y+len*.45,x-drift,y+len);g.stroke()}
   else if(t<.45){g.strokeStyle=dry;g.lineWidth=.5+rr;g.beginPath();g.moveTo(x,y);g.lineTo(x-drift*.66,y+len*.62);g.stroke()}
  }
  for(let i=0;i<85*detail;i++){let x=min+(max-min)*rnd(i*5+seed+136),y=top+(bottom-top)*rnd(i*5+seed+137),l=15+70*rnd(i+seed+133);line(g,`M${x} ${y} l-6 ${l*.21} 3 ${l*.12} -9 ${l*.26} -3 ${l*.27}`,'rgba(29,44,37,.41)',.95)}
 });
 // Rock-top moss follows the profile, rather than sitting in the sky.
 for(let i=2;i<outline.length-2;i+=2){const [x,y]=outline[i];if(y>bottom-100||rnd(i+seed)<.38)continue;for(let j=0;j<4;j++)ellipse(g,x+8*(rnd(i*7+j)-.5),y+5+rnd(i+j)*7,1+2.3*rnd(i+j+40),1+3*rnd(i*3+j+70),'rgba(39,59,47,.43)')}
 return d;
}
function pine(g,x,y,s,seed){at(g,x,y,s,c=>{
 const ink='#34483e';path(c,'M-4 0 Q2 -37 -6 -66 Q-15 -90 -3 -111 Q7 -128 5 -158 Q15 -124 4 -100 Q-1 -82 5 -64 Q13 -35 4 0Z',ink);
 for(let j=0;j<12;j++){let u=j/12,yy=-36-u*108,w=(1-u*.70)*(31+22*rnd(j+seed)),dir=j%2?1:-1,xx=w*dir;line(c,`M1 ${yy+6} Q${xx*.56} ${yy+1} ${xx*.78} ${yy-12} l${xx*.23} -8`,ink,2.5-u);
  for(let t=0;t<4;t++){let bx=xx*(.4+t*.19),by=yy-2-t*4;for(let n=0;n<19;n++){let a=-2.91+n*.146,r=6+7*rnd(n+j*35+seed);seg(c,bx,by,bx+Math.cos(a)*r,by+Math.sin(a)*r,ink,.75)}}}
 },s)}
function songBack(g){paper(g,[226,226,201],[21,23,21],221);
 // Distant granite is visible through a veil, without a convenient skyline line.
 for(let row=0;row<2;row++){let pts=[[-170,687]];for(let x=-170;x<=1790;x+=22){let a=100+80*row,y=510+35*row-a*noise(x/106,row,32)-138*noise(x/270,row,22);pts.push([x,y])}pts.push([1800,720],[-170,720]);K.line(g,pts,null,1,true,row?'#b4c0ab':'#c4c9b5')}
 rect(g,0,319,1600,411,grad(g,0,318,0,730,[[0,'rgba(227,229,206,0)'],[.65,'rgba(227,229,206,.30)'],[1,'#e0e1cb']]));
}
function mountains(g){
 ridge(g,[[-110,659],[-54,549],[43,454],[78,369],[123,358],[177,286],[204,188],[245,177],[262,140],[295,149],[318,176],[360,175],[390,248],[405,292],[450,327],[482,432],[536,488],[564,595],[633,666],[570,742],[-110,744]],44,'#b2baa3','#889986','#536e61','rgba(216,219,184,.57)',.75);
 ridge(g,[[310,616],[357,547],[409,491],[449,424],[460,342],[485,317],[493,260],[523,219],[529,161],[553,125],[565,66],[608,43],[656,59],[676,30],[717,51],[743,64],[762,111],[782,123],[800,200],[815,243],[855,277],[871,355],[914,404],[929,483],[974,572],[1001,626],[1010,722],[332,724]],68,'#acae94','#768a76','#415c51','rgba(224,221,183,.56)',1.18);
 ridge(g,[[794,660],[839,617],[868,548],[917,503],[939,432],[968,406],[990,332],[1024,304],[1042,251],[1081,230],[1092,167],[1138,144],[1174,154],[1206,123],[1247,144],[1265,193],[1300,212],[1320,284],[1359,325],[1390,412],[1476,501],[1498,563],[1568,615],[1700,675],[1720,742],[807,734]],114,'#afb6a0','#849782','#4e6a5c','rgba(217,221,191,.51)',1);
 for(const [x,y,s] of [[555,155,.17],[664,66,.14],[700,49,.12],[740,79,.12],[522,222,.14],[985,356,.16],[1105,175,.13],[1159,158,.16],[1211,141,.16],[861,362,.22],[467,373,.23],[244,179,.12]])pine(g,x,y,s,Math.floor(x));
 // Ribbon of reserved silk in a dark gully, widening to spray at each drop.
 path(g,'M751 163 Q723 187 740 226 Q754 249 739 281 Q724 305 731 332 Q738 351 754 353 Q741 393 745 433 Q747 454 759 460 Q737 508 731 544 Q723 577 700 601 Q744 588 763 549 Q771 513 795 450 Q772 434 776 399 Q779 366 798 336 Q770 345 761 321 Q763 302 778 276 Q785 249 768 218 Q751 189 762 168Z','rgba(32,56,46,.29)');
 path(g,'M752 166 Q745 193 758 219 Q773 251 757 281 L747 314 Q747 329 757 336 Q770 340 784 336 Q768 354 765 383 Q759 420 767 440 Q776 451 786 448 Q771 469 762 501 L750 548 Q737 579 708 593 Q743 562 749 536 L753 495 Q757 468 769 451 Q751 450 752 432 L755 379 Q756 361 766 345 Q744 346 739 334 L739 317 Q742 299 752 275 Q765 247 753 222 Q738 195 752 166Z','#dae0c9');
 line(g,'M752 171 Q742 191 758 224 M751 281 L741 318 M765 377 Q756 413 761 438 M750 507 Q744 564 714 590','#f5eed7',2.6);
 // Cottony mist is made of thin travelling blankets, not one hard gradient line.
 for(let j=0;j<40;j++){let x=-120+(j%10)*210+(Math.floor(j/10)%2)*89,y=566+Math.floor(j/10)*38+21*Math.sin(j*.7),w=160+90*rnd(j+123),hh=50+30*rnd(j+379);g.save();g.translate(x,y);g.scale(w,hh);let v=g.createRadialGradient(0,0,0,0,0,1);v.addColorStop(0,'rgba(225,227,203,.40)');v.addColorStop(.59,'rgba(225,227,203,.23)');v.addColorStop(1,'rgba(225,227,203,0)');rect(g,-1,-1,2,2,v);g.restore()}
 rect(g,0,578,1600,195,grad(g,0,578,0,773,[[0,'rgba(228,229,209,0)'],[.52,'rgba(226,228,207,.72)'],[1,'#e1e2cb']]));
}
function songDraw(g,l){
 let px=P.sceneContext?.rider?.x??800;g.drawImage(K.cached('R8-song-ground',songBack),0,0);g.save();g.translate((px-800)*.19,0);
 g.drawImage(K.cached('R8-painted-gorge',mountains),0,0);g.restore();
 g.drawImage(K.cached('R8-song-donkey-road',c=>{let top=[];for(let x=0;x<=1600;x+=8)top.push([x,P.scenes[4].ground(x)]);
 K.line(c,[...top,[1600,900],[0,900]],'#7d846c',1,true,grad(c,0,708,0,900,[[0,'#d3cdb1'],[.40,'#b6bea4'],[1,'#a2ae91']]));
 for(let j=0;j<450;j++){let x=rnd(j*3+12)*1600,y=P.scenes[4].ground(x)+3+rnd(j*3+13)*151;line(c,`M${x} ${y} q6 -2 15 -2`,'rgba(83,102,76,.33)',.82)}
 // The hamlet stands on a wooded bank, joined to the trail by a footpath.
 path(c,'M953 734 Q1004 723 1039 709 Q1080 695 1112 699 Q1139 686 1170 698 Q1215 697 1252 716 Q1288 724 1336 743 Q1265 753 1196 743 Q1120 731 1033 742Z','#a7b198');
 for(let k=0;k<45;k++){let x=1037+rnd(108+k*3)*211,y=701+rnd(203+k*3)*21;ellipse(c,x,y,1.4+rnd(k+143)*4.4,1.2+rnd(k+633)*2.4,'rgba(78,98,76,.28)')}
 line(c,'M1140 707 Q1120 716 1144 719 Q1173 723 1138 733','#c7c5a8',3.4);
 // A monastic roof broken into three overlapping wings beside the little road.
 for(const [x,y,s] of [[1134,707,.37],[1184,709,.27],[1086,707,.22]])at(c,x,y,s,h=>{rect(h,-52,-53,104,51,'#aaab8d','#596553',2);path(h,'M-69 -41 Q-43 -49 -26 -84 Q0 -90 32 -81 Q47 -53 71 -43 Q-4 -51 -69 -41Z','#4a5d51','#415649',2);for(let j=-2;j<=2;j++){seg(h,j*17,-44,j*17,-3,'#65735f',2.5)}});
 }),0,0);
 // Three pinpricks of white wings glide behind the near ridge, then clear it.
 for(let j=0;j<6;j++){let x=202+l*75-j*21,y=366-j%3*5-j*2.7;if(x>408&&x<589)continue;let f=3*Math.sin(l*5.5+j);line(g,`M${x-7} ${y+f} q4 0 7 3 q3 -4 7 ${-3-f}`,'#586d60',1.65)}
}
function songNear(g,l){let px=P.sceneContext?.rider?.x??800;g.save();g.translate((800-px)*.085,0);g.drawImage(K.cached('R8-song-near',c=>{
 ridge(c,[[-110,700],[-5,591],[62,559],[113,590],[163,605],[177,657],[224,684],[278,738],[321,806],[182,821],[-110,824]],15,'#7b8973','#586b59','#3e544a','rgba(179,183,146,.5)',.45);
 ridge(c,[[1296,836],[1341,767],[1393,723],[1435,659],[1510,632],[1544,594],[1617,574],[1730,673],[1730,862]],20,'#809078','#5f7763','#495f53','rgba(190,195,157,.4)',.35);
 pine(c,89,649,1.03,771);pine(c,36,638,1.35,15);pine(c,1524,700,.83,33);pine(c,1472,707,.61,26);
 }),0,0);g.restore()}
function waterfrontBuilding(g,x,y,s,kind,seed){
 const ink='#615744',wood=kind%3===0?'#9f5a42':'#946f53',wall=kind%2?'#d4b68b':'#cfba96',roof=kind%3===1?'#778783':'#667d79';
 at(g,x,y,s,c=>{
 const w=86+(seed%4)*11,h=kind%3===0?112:78,z=34,sl=19;
 path(c,`M${-w*.5} 0 v${-h} h${w} v${h}Z`,wall,ink,1.6);
 path(c,`M${w*.5} 0 l${z} ${-sl} v${-h} l${-z} ${sl}Z`,'#b99873',ink,1.6);
 for(let j=0;j<4;j++){let xx=-w*.40+j*w*.255;rect(c,xx,-h+8,w*.20,h*.32,'#6f7469',ink,1);for(let k=1;k<4;k++)seg(c,xx+k*w*.05,-h+10,xx+k*w*.05,-h+h*.32+8,'#c0ab8a',1);seg(c,xx,-h+h*.19,xx+w*.2,-h+h*.19,'#ccb48d',1);rect(c,xx,-h*.40,w*.19,h*.40,'#6c6656',ink,.9)}
 for(let j=0;j<5;j++){const xx=-w*.46+j*w*.23;seg(c,xx,-h+4,xx,.4,wood,3.4)} 
 for(let j=0;j<3;j++){let xx=w*.5+6+j*11;seg(c,xx,-7-j*6,xx,-h+11-j*6,'#8b7258',1.9)}
 function tiledRoof(yy,depth){
  path(c,`M${-w*.64} ${yy+6} Q${-w*.34} ${yy+6} ${-w*.43+z*.6} ${yy-depth} L${w*.45+z*.6} ${yy-depth} Q${w*.53} ${yy} ${w*.65} ${yy+3} L${w*.67+z} ${yy-sl-1} Q${w*.58+z*.7} ${yy-sl-4} ${w*.45+z*.6} ${yy-depth-3} L${-w*.43+z*.6} ${yy-depth-3} L${-w*.64} ${yy+6}Z`,roof,ink,2);
  for(let j=0;j<=23;j++){let f=j/23;let a=-w*.43+z*.6+f*w*.88,b=-w*.60+f*w*1.22;line(c,`M${a} ${yy-depth+2} Q${(a*.54+b*.46)} ${yy-3} ${b} ${yy+3-3*Math.sin(Math.PI*f)}`,j%3?'#97a29a':'#a6aca0',.8)}
  line(c,`M${-w*.64} ${yy+7} Q0 ${yy+1} ${w*.65} ${yy+4} l${z} ${-sl-4}`,'#504e43',2);line(c,`M${-w*.44+z*.6-5} ${yy-depth-7} q4 7 13 4 h${w*.85} q7 0 10 -6`,'#6b6755',2);
 }
 tiledRoof(-h,31+(kind%2)*5);if(kind%3===0)tiledRoof(-h*.46,12);
 if(kind%3!==0){const tint=kind%2?'#ad795b':'#a8ac88';path(c,`M${-w*.48} ${-h*.43} l${w*.88} 0 9 17 h${-w*1.05}Z`,tint,ink,1.1);for(let j=0;j<7;j++){let xx=-w*.47+j*w*.14;seg(c,xx,-h*.42,xx-2,-h*.42+15,'#c7b28c',1)}}
 });}
function vessel(g,x,y,s,t,dir,sail){at(g,x,y,s*dir,c=>{
 const ink='#5b5949';path(c,'M-113 -20 Q-57 -7 6 -8 Q70 -6 114 -30 Q100 -2 68 8 Q-23 24 -89 3Z','#8f7859',ink,2);
 line(c,'M-106 -17 Q-10 8 97 -20','#d4b381',2.4);line(c,'M-90 0 Q-10 18 69 3',ink,1.1);for(let j=0;j<11;j++){let xx=-74+j*13;seg(c,xx,-9,xx+3,2,'#715d47',1)}
 if(sail){seg(c,1,-10,1,-164,ink,3);path(c,'M-2 -151 Q-34 -139 -48 -124 Q-45 -76 -71 -31 Q-40 -43 15 -39 Q33 -90 26 -145Z','#d6bf91','#766e57',1.6);for(let j=0;j<8;j++){let yy=-137+j*12;line(c,`M${-44-j*2} ${yy+11} Q-15 ${yy} ${27-j*.8} ${yy+1}`,'#9f8d70',1)}line(c,'M3 -160 L83 -16 M4 -160 L-93 -17',ink,1.35)}else{path(c,'M-53 -13 Q-50 -57 -18 -58 H25 Q48 -54 53 -13Z','#ac9d74',ink,1.5);for(let x=-42;x<49;x+=10)line(c,`M${x} -14 q-4 -26 7 -39`,'#817961',1)}
 at(c,-72,-14,.65,h=>{ellipse(h,0,-37,6,7,'#8d6e54',ink,.8);path(h,'M-7 -29 Q-2 -33 7 -29 L12 -9 L5 -3 H-10Z','#788c79',ink,1.2);line(h,'M-1 -22 l13 11 14 -4 M3 -3 l11 7 12 -1',ink,2.5)});
 let ang=Math.sin(t*2.4)*.18;c.save();c.translate(-53,-19);c.rotate(ang);line(c,'M20 -28 L-42 49',ink,2.3);path(c,'M-36 36 l-13 18 -3 -2 8 -19Z','#8e7960',ink,.8);c.restore();
 for(let j=0;j<3;j++){line(c,`M-72 ${19+j*5} q55 4 106 0 m9 0 l20 -3`,'rgba(96,117,105,.44)',1.4)}
 },s)}
function market(g){
 paper(g,[226,214,178],[48,42,31],302);
 const river=grad(g,0,343,0,900,[[0,'#b2bc9f'],[.47,'#9aaf9a'],[1,'#849f94']]);rect(g,0,329,1600,571,river);
 for(let j=0;j<330;j++){const x=rnd(j*3+41)*1600,y=329+rnd(j*3+42)*571,w=5+54*(y/900)*rnd(j*3+43);line(g,`M${x} ${y} q${w*.32} -2 ${w} -1`,'rgba(229,221,179,.5)',.8)}
 // The river turns behind a S-bend and its distant tree-lined towpath.
 path(g,'M0 342 Q258 301 532 294 Q859 281 1181 319 L1610 277 V379 Q1271 397 1028 364 Q835 340 590 355 Q224 373 0 424Z','#b2b393','#939c83',1);
 for(let j=0;j<45;j++){let x=-33+j*39,y=327-32*Math.sin(j*.25),s=.23+.15*rnd(j+40);waterfrontBuilding(g,x,y,s,j%4,j)}
 for(let j=0;j<47;j++){let x=-13+j*35,y=316-30*Math.sin(j*.25),s=.4+rnd(j+2)*.37;ellipse(g,x,y-51*s,15*s,23*s,'#a6b093');seg(g,x,y-50*s,x+1,y,'#93977a',1)}
 // Market streets run obliquely across the bank. Unequal roof heights and
 // visible gables read as a dense port town even at thumbnail size.
 path(g,'M-70 371 L151 322 L387 334 L599 373 L781 360 L1004 387 L1210 369 L1650 365 V462 L1344 472 L1139 508 L939 480 L689 495 L511 475 L231 514 L0 574Z','#c7b48b','#857e63',2);
 const buildings=[[-25,448,1.02,0],[93,425,.88,1],[200,398,.72,2],[298,378,.63,3],[390,400,.75,2],[512,405,.69,0],[611,428,.61,1],[707,420,.57,3],[806,428,.72,2],[899,439,.64,1],[1009,447,.81,0],[1127,438,.73,2],[1262,425,.80,1],[1367,404,.91,3],[1501,408,1.07,0],[1615,402,1.12,2]];
 for(let j=0;j<buildings.length;j++)waterfrontBuilding(g,...buildings[j],j*11+4);
 path(g,'M-20 494 Q277 421 443 420 L595 453 L475 494 L333 504 L142 544 L-20 604Z','#ccba90','#947f61',1.5);
 for(const [j,a] of [[0,[-22,529,1.17,1]],[1,[117,497,1.06,3]],[2,[273,469,.88,2]],[3,[390,455,.71,1]],[4,[1549,463,1.18,3]],[5,[1424,477,.92,1]]])waterfrontBuilding(g,...a,j+19);
 for(let i=0;i<66;i++){let x=rnd(i*3+81)*1590,y=471+Math.sin(x*.006)*14+14*rnd(i+3);H.scrollFolk(g,x,y,.16+.12*rnd(i+49),['#668275','#a16953','#bfad86','#828477'][i%4],i%7,i%3?1:-1)}
 // Curving wharf, projecting steps and planted mooring posts sit in the water.
 for(const [x,y,w] of [[56,557,178],[266,508,117],[1260,479,145],[1444,471,144]]){path(g,`M${x} ${y} l${w} -18 31 10 -${w} 20Z`,'#a18b68','#796b56',1);for(let k=0;k<4;k++)seg(g,x+28+k*w*.25,y+6-k*4,x+29+k*w*.25,y+30-k*4,'#766e55',3.1)}
}
function bridgeDeck(g){
 const road=P.scenes[5].ground,ink='#6f5940';
 for(const [x,dir] of [[340,-1],[1340,1]])at(g,x,750,dir,c=>{path(c,'M0 0 H390 V155 H0 Q19 88 0 0Z','#b8a47d',ink,2);for(let y=7;y<151;y+=15)for(let xx=-10+(y%3)*11;xx<399;xx+=34){line(c,`M${xx} ${y} h31 l1 9`,'#938465',1)}},1);
 // Massive woven spars span the river. Each crossing uses the real arch height.
 for(let j=0;j<14;j++){const x=345+j*69,xx=Math.min(x+175,1340),y=road(x)+87,yy=road(xx)+15;seg(g,x,y,xx,yy,'#786349',9.8);seg(g,x,y-2,xx,yy-2,'#b6a07b',4.4);seg(g,x,y-63,xx,yy+62,'#82694a',8.2);seg(g,x,y-64,xx,yy+61,'#c0a37b',3.5)}
 const chords=[];for(let x=317;x<=1361;x+=6){let u=clamp((x-340)/1000);chords.push([x,road(x)+86-10*Math.sin(Math.PI*u)])}
 K.line(g,chords,'#6b5945',13);K.line(g,chords.map(([x,y])=>[x,y-2.7]),'#ad9771',6.6);
 for(let x=350;x<1340;x+=69){let u=clamp((x-340)/1000),y=road(x)+85-10*Math.sin(Math.PI*u);ellipse(g,x,y,4.8,4.8,'#887754','#604f3e',1.1);ellipse(g,x-.4,y-.5,1.5,1.5,'#bfa580')}
 let top=[],bot=[];for(let x=340;x<=1340;x+=5){top.push([x,road(x)]);bot.unshift([x,road(x)+20])}
 K.line(g,[...top,...bot],ink,1.6,true,'#bba17c');K.line(g,top,'#cdb58b',3);for(let x=342;x<1340;x+=15){const y=road(x);seg(g,x,y+2,x+3,y+19,'#9b805e',1.2)}
 for(let x=352;x<1340;x+=37){let y=road(x)-2;seg(g,x,y-1,x,y-29,'#8d7658',3.2);ellipse(g,x,y-30,2.7,2.7,'#a58b65');if(x<1290)seg(g,x,y-23,x+37,road(x+37)-25,'#8c7456',2)}
}
function bridgeDraw(g,l){
 g.drawImage(K.cached('R8-city',market),0,0);
 vessel(g,597+l*12,551,.64,l,1,1);vessel(g,1079-l*17,589,.54,l+.7,-1,0);
 vessel(g,702+l*34,835,.94,l+.4,1,0);vessel(g,163+l*21,686,.79,l,-1,1);
 g.drawImage(K.cached('R8-wood-bridge',bridgeDeck),0,0);
 const road=P.scenes[5].ground,actor=H.hero(5,l);
 for(const [x,s,id,dir] of [[226,.44,3,1],[281,.39,1,1],[467,.45,4,-1],[530,.39,7,1],[1040,.42,3,1],[1104,.37,5,-1],[1243,.46,1,-1],[1310,.39,2,1],[1450,.43,5,-1]]){
  const phase=H.responsePhase(x,actor,550);if(!H.scrollCharacter(g,x,road(x)-6,s,id,dir,phase))H.scrollFolk(g,x,road(x)-6,s,'#88795e',id,dir)
 }
}
// Substitute just the painted grounds on the original cache keys. The Han
// incisions and the lifted paper sample this exact same 'h-han' surface.
const painters=new Map([['h-sahara-pure',sahara],['h-egypt',egypt],['h-han',han],['h-tang',tang],['h-maya',maya],['h-mughal',garden],['h-bada',lotus],['h-wayang',wayang]]);
const cached=K.cached;
K.cached=function(key,paint){const painter=painters.get(key);return cached.call(this,key,painter?g=>painter(g,paint):paint)};
// The wall receives one layer of pigment. Mixing each subpath independently
// would reveal the internal overlaps between feathers and spokes through the
// surface. Fix the specimen pose first, then print the complete painted plate.
const movingRider=P.drawRider;
P.drawRider=function(g,t,o={}){
 if(o.style===1 && P.riderGeometry.palettes[1][0]==='#9f6841' && g.globalCompositeOperation==='multiply'){
  const plate=K.cached('R8-egypt-opaque-portrait',back=>movingRider.call(this,back,t,{...o,alpha:1}));
  g.save();g.globalCompositeOperation='source-over';g.drawImage(plate,0,0);g.restore();return;
 }
 return movingRider.call(this,g,t,o);
};
P.scenes[4].draw=songDraw;P.scenes[4].over=songNear;P.scenes[5].draw=bridgeDraw;
const theatre=P.scenes[9].draw;
P.scenes[9].draw=function(g,l,a){theatre.call(this,g,l,a);serpentShadow(g,l)};
// The R7 summit-specific clipping layer used the previous mountain outline.
// Keep other period acting, and use the new gorge's own flying geese instead.
const details=P.storyDetails;
P.storyDetails=function(g,i,l,t,p,front){if(i!==4)details.call(this,g,i,l,t,p,front)};
P.historicalR8={revision:'ten-painting-grounds',scenes:10};
})();
