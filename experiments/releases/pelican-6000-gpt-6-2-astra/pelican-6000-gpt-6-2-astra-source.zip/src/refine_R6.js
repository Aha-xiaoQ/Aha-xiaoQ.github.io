/* R6 • the medium participates in the story.
   All marks below are original code. Physical contacts, anatomical skin and
   transmission remain the R4/R5 shared rig; no generated image/audio inputs. */
(()=>{
'use strict';
const E=K.ease,S=K.smoother,TAU=Math.PI*2,D=P.finalDirector,H=P.historic;
const path=(c,d,f,s,w=1)=>K.path(c,d,f,s,w),line=(c,p,col,w=1)=>K.line(c,p,col,w);
const io=(t,a,b,c,d)=>S((t-a)/(b-a))*(1-S((t-c)/(d-c)));
const ctxTime=()=>P.sceneContext?.local||0;
const V=P.refinementR6={revision:'R6',wall:{contact:2.18,release:3.66},fish:{launch:2.32,land:3.62},scream:{onset:2.22,answer:3.32,settle:5.15},depthLayers:{far:.22,massif:.58,shore:.82,foreground:1.16}};
function hold(t,a,b,x=740){return t<a?D.hermite(t/a,0,x,1600/6,0,a):t<b?x:D.hermite((t-b)/(6-b),x,1600,0,1600/6,6-b);}
// Shared source-of-truth routes. The physical integrator follows these, so a
// stop never leaves the wheels pedalling under an otherwise stationary bird.
P.scenes[1].travelX=t=>hold(t,2.18,3.66,750);
P.scenes[5].travelX=t=>hold(t,2.26,3.72,760);
P.scenes[4].ground=x=>778-70*Math.sin(Math.PI*K.clamp(x/1600))**2;
const oldPose=P.nativePose;
P.nativePose=function(i,l,t){const p=oldPose(i,l,t);
 if(i===1){p.x=P.scenes[1].travelX(l);p.scale=1.03;p.y=752-102*p.scale;p.headNod=0;p.bellPress=0;p.gazeX=.72;p.gazeY=0;}
 if(i===4){p.x=1600*l/6;p.scale=1.10-.90*io(l,.25,1.65,4.35,5.80);p.y=P.scenes[4].ground(p.x)-102*p.scale;p.gazeY=-.35;p.headNod=-.035;}
 if(i===5){p.x=P.scenes[5].travelX(l);const duck=io(l,2.44,2.70,3.00,3.32);p.headNod=.235*duck;p.brakeLean=.08*duck;p.gazeX=.7;p.gazeY=-.65*io(l,2.32,2.6,3.4,3.8);p.bellPress=Math.sin(Math.PI*K.clamp((l-3.9)/.25));}
 return p;
};
// No camera zoom masquerading as mountain depth. The painterly layers below
// translate independently; the traveller changes size along a depth route.
const oldCamera=P.storyCamera;
P.storyCamera=t=>(t>=29&&t<35)?{z:1,fx:800,fy:450,dx:0,dy:0}:oldCamera(t);
function filmLocalPose(i,u){const t=D.starts[i]+u/6*D.lengths[i],q=D.geometry(t);return {...q.p,...D.motionAt(t),x:q.worldX-D.origins[i],style:i};}
function smallFish(c,x,y,scale,angle,tailPhase=0){
 c.save();c.translate(x,y);c.rotate(angle);c.scale(scale,scale);
 const tw=Math.sin(tailPhase)*6;
 path(c,`M-24 -3 L${-44+tw*.3} ${-18+tw} Q-35 0 ${-44-tw*.2} ${18+tw*.5} L-24 4Z`,'#967c53','#5f705f',1.2);
 path(c,'M-30 0 C-22 -19 5 -22 28 -6 Q35 -1 28 6 C7 23 -18 18 -30 0Z',K.gradient(c,[0,-18],[0,18],[[0,'#617f76'],[.48,'#b0bea0'],[1,'#ece0af']]),'#4c685e',1.3);
 path(c,'M-13 -15 L-6 -26 L8 -16 M-9 14 L-2 23 L10 13Z','#aa9670','#617262',.7);
 path(c,'M13 -10 Q6 0 13 11',null,'#718472',1.0);K.circle(c,22,-3,2.5,'#eee6c4','#4c6255',.6);K.circle(c,22.6,-3,1.3,'#2c504b');
 for(let row=0;row<3;row++)for(let k=0;k<5;k++)path(c,`M${-22+k*6} ${-7+row*6} q4 -3 6 0`,null,'rgba(58,94,78,.32)',.65);
 path(c,'M-18 -9 Q-2 -17 11 -11',null,'#ddd9a5',1.1);path(c,'M27 3 l5 -1',null,'#526957',.7);c.restore();
}
V.fishAt=function(l){const u=K.clamp((l-V.fish.launch)/(V.fish.land-V.fish.launch));const x=340+1010*u,y=826-2700*u*(1-u);return{x,y,u,angle:Math.atan2(-2700+5400*u,1010),visible:l>=V.fish.launch&&l<V.fish.land};};
function splash(c,x,y,age,scale=1,col='#8cae9e'){
 if(age<0||age>1.2)return;c.save();c.globalAlpha=(1-age/1.2)*.85;
 for(let j=0;j<8;j++){const a=-2.85+j*.37,v=40+(j%3)*17,xx=x+Math.cos(a)*v*age*scale,yy=y+Math.sin(a)*v*age*scale+58*age*age*scale;K.ellipse(c,xx,yy,1.7*scale,3.2*scale,col,null,1,a+.9);}
 for(let j=0;j<3;j++)K.ellipse(c,x,y+2+j*3,(12+age*48+j*5)*scale,(2+age*6+j)*scale,null,col,.7);c.restore();
}
function fishSeller(c,x,y,l){
 // One stable seated figure. Short neck, skull and robe share one posture;
 // the fish performs the action, so there is no unconvincing reaching hand.
 c.save();c.translate(x,y);const ink='#645f49',robe='#899680',skin='#bca17b';
 path(c,'M-25 -65 Q-33 -30 -35 -7 L-8 0 L2 -29 L22 -4 L39 -5 L17 -64Z','#b5b093',ink,1);
 path(c,'M-29 -9 L-41 -3 L-39 1 L-10 1 L-10 -6 M18 -8 L22 0 H45 L45 -3 L34 -8Z','#6c6350',ink,.8);
 path(c,'M-15 -126 Q-35 -121 -32 -97 L-22 -57 Q0 -50 24 -61 L29 -101 Q26 -121 12 -127Z',robe,ink,1.1);
 path(c,'M-11 -128 L-7 -138 H9 L13 -125 L3 -116Z',skin,ink,.85);
 path(c,'M-12 -143 Q-15 -161 -3 -164 Q13 -167 17 -151 L22 -144 L16 -139 Q17 -129 5 -129 Q-6 -129 -12 -143Z',skin,ink,.9);
 path(c,'M-13 -143 Q-21 -164 -4 -172 Q13 -170 17 -154 L8 -156 L-4 -158 L-7 -141Z','#4f5547',ink,.8);
 path(c,'M-20 -165 Q-1 -179 20 -164 L17 -157 Q-1 -163 -16 -157Z','#64735a',ink,.8);
 const look=io(l,2.25,2.6,3.65,4.1);line(c,[[8,-147],[13,-148-look]],ink,.8);K.circle(c,11+look,-145,1,ink);
 path(c,'M-15 -124 L1 -108 L14 -125 M1 -108 L-2 -60 M-23 -88 Q-14 -74 -16 -61 M20 -90 Q10 -72 12 -59',null,'#d3c6a4',.9);
 path(c,'M-25 -111 Q-36 -97 -26 -79 L-6 -74 L-4 -84 L-20 -88 L-13 -108Z',robe,ink,1);
 path(c,'M-6 -84 Q3 -87 11 -82 L11 -76 L-5 -74Z',skin,ink,.65);
 path(c,'M23 -110 Q35 -99 29 -79 L9 -73 L6 -83 L22 -89 L15 -108Z',robe,ink,1);
 path(c,'M7 -83 Q0 -88 -5 -82 L-4 -76 L9 -73Z',skin,ink,.65);
 // A wicker creel has an oval opening, coherent weave and a moving tiny fin.
 path(c,'M-38 -41 Q0 -51 42 -39 L34 -12 Q-1 0 -34 -13Z','#ae9462','#77694a',1.2);
 K.ellipse(c,2,-40,40,8,'#6d795e','#6a624b',1);for(let j=-3;j<=3;j++)path(c,`M${j*10} -39 L${j*8} -12`,null,'#d2be8f',.7);
 for(let j=0;j<3;j++)path(c,`M${-35+j} ${-32+j*8} Q0 ${-23+j*8} ${38-j} ${-31+j*8}`,null,'#847750',.65);
 path(c,`M-14 -41 l${-4-Math.sin(l*5)*3} -9 l13 5 l5 -5 l-2 10Z`,'#a0b4a0','#617d6c',.65);c.restore();
}
// Keep the actual miniature wall painting, and leave a registered pigment
// impression when the traveller comes out of it: a visible cause and an afterimage.
const eg=P.scenes[1],egDraw=eg.draw;
eg.draw=function(c,l,a){egDraw.call(this,c,l,a);
 const pigment=io(l,2.18,2.48,3.58,3.95),memory=S((l-3.62)/.38)*.57;
 const fixed=filmLocalPose(1,2.18),live=P.sceneContext?.rider;
 V.lastWall={pigment,memory,fixedX:fixed.x};
 if(pigment+memory>0){c.save();c.globalCompositeOperation='multiply';c.globalAlpha=Math.min(.93,pigment+memory);const palette=P.riderGeometry.palettes[1];P.riderGeometry.palettes[1]=['#9f6841','#cead79','#b58d5b','#ad7949','#b78959','#9c6e45','#9a6c44'];try{P.drawRider(c,5+6+2.18,{...fixed,alpha:1,shadow:false,headNod:0});}finally{P.riderGeometry.palettes[1]=palette;}c.restore();
  c.save();c.globalAlpha=(pigment*.32+memory*.2);for(let j=0;j<56;j++){const x=fixed.x-205+K.rnd(j+81)*490,y=fixed.y-345+K.rnd(j+19)*410;if(j%4===0)line(c,[[x,y],[x+9,y+2]],'#e5c994',.7);}c.restore();}
 if(l>2.12&&l<2.8){const u=(l-2.12)/.68;c.save();c.globalAlpha=Math.sin(u*Math.PI)*.52;for(let j=0;j<22;j++){const x=fixed.x-180+j*19,y=fixed.y+107+Math.sin(j*1.6)*3-u*(16+K.rnd(j)*25);K.circle(c,x,y,1.4,'#a87046');}c.restore();}
 if(l>3.85){c.save();c.globalAlpha=S((l-3.85)/.3);path(c,'M485 782 H982',null,'#a16c42',1.4);K.text(c,'来过。留影。不留下本人。',735,846,22,'#855e3f','center','serif');c.restore();}
};
eg.riderScreenPose=(p,l)=>({...p,alpha:(p.alpha??1)*(1-io(l,2.18,2.48,3.58,3.95)),shadow:!io(l,2.18,2.48,3.58,3.95)});

// Three genuinely independent pictorial depths. These are cached original
// vector marks, not one bitmap zoomed in and out. Foreground pines occlude the
// traveller; the far cliff and its waterfall move more slowly than the road.
const song=P.scenes[4];
song.draw=function(c,l){
 const px=P.sceneContext?.rider?.x??800,far=(px-800)*.78,mid=(px-800)*.42;
 c.drawImage(K.cached('R6-song-paper',g=>{H.paper(g,'#eee3ca','rgba(76,63,42,.045)',3400);}),0,0);
 c.save();c.translate(far,0);c.drawImage(K.cached('R6-song-distance',g=>{

      K.path(g,'M0 471 Q84 379 164 410 Q242 339 319 373 Q370 293 434 347 Q485 309 542 370 Q608 321 690 369 Q747 302 808 360 Q874 293 926 342 Q1010 279 1084 345 Q1161 283 1243 368 Q1326 325 1402 378 Q1490 347 1600 408 L1600 654 L0 654Z','rgba(153,148,128,.18)');
      H.stroke(g,'M33 445 Q139 408 219 425 Q320 382 411 415 M1139 407 Q1310 377 1500 427','rgba(127,119,97,.19)',.85);
      H.songPeak(g,'M339 613 Q369 562 385 509 Q397 466 422 459 L452 446 Q468 437 476 397 Q485 354 513 328 Q535 312 562 322 Q586 328 604 297 Q625 253 639 238 Q660 225 685 244 Q705 246 720 253 Q750 299 761 343 Q767 376 796 385 Q822 383 841 419 Q864 471 872 521 Q879 559 906 589 L940 632Z',[339,238,601,394],['#ddd5bf','#c2bea9','#acae98','rgba(85,79,60,.10)','rgba(246,235,210,.30)'],1);
      H.songPeak(g,'M810 642 Q838 558 842 485 Q841 443 871 424 L901 405 Q920 373 930 333 Q943 285 966 263 Q986 252 1007 276 L1039 287 Q1062 270 1069 230 Q1073 192 1086 183 Q1106 172 1122 192 L1140 203 Q1159 236 1158 280 Q1155 314 1170 327 L1205 348 Q1222 349 1238 381 Q1269 434 1279 485 Q1285 535 1308 570 L1350 630Z',[810,183,540,459],['#d4ccba','#b6b49f','#989b86','rgba(67,63,48,.12)','rgba(246,235,211,.30)'],2);
 }),0,0);c.restore();
 c.save();c.translate(mid,0);c.drawImage(K.cached('R6-song-massif',g=>{
      H.songPeak(g,'M244 675 Q265 627 290 598 L310 566 Q319 546 341 533 L362 520 Q378 505 388 481 Q400 453 402 415 L410 389 L417 340 Q429 321 431 294 Q437 266 452 255 L461 226 Q469 199 486 203 Q500 196 511 214 L528 224 Q539 248 531 280 L539 307 Q541 330 564 343 L583 350 Q604 370 602 401 L610 452 Q603 480 622 517 L621 563 Q636 592 651 612 L687 653 L711 675Z',[244,200,467,475],['#bdb5a0','#8e907b','#606a59','rgba(34,34,28,.29)','rgba(245,232,204,.37)'],3);
      // One monumental mass dominates the hanging-scroll composition. Its
      // broken crown and long cliff planes are different from the lower hills.
      H.songPeak(g,'M656 718 Q677 679 693 650 L690 618 L711 586 L709 551 L735 530 L747 487 L743 452 L766 423 L775 363 L767 330 L778 285 L773 244 L791 213 L798 174 L813 153 L802 111 L829 94 L844 60 L872 68 L900 42 L931 55 L947 40 L974 58 L999 46 L1033 72 L1067 66 L1089 98 L1095 139 L1117 170 L1128 228 L1119 285 L1141 334 L1131 395 L1160 448 L1168 503 L1190 561 L1217 608 L1210 657 L1240 718Z',[656,40,584,678],['#a0a18b','#6d7563','#3e4c40','rgba(20,25,22,.34)','rgba(238,227,200,.35)'],4);
      H.songPeak(g,'M1116 710 Q1136 641 1156 596 L1170 554 Q1164 522 1187 508 L1213 488 Q1228 466 1231 427 Q1238 382 1260 350 Q1291 317 1315 332 Q1327 319 1344 334 Q1366 347 1378 380 L1393 401 Q1406 438 1398 470 Q1395 510 1409 554 Q1431 604 1453 627 L1484 662 Q1541 689 1600 705Z',[1116,325,484,385],['#b0aa91','#848b72','#56664f','rgba(33,37,28,.29)','rgba(239,227,197,.32)'],5);
      K.path(g,'M1017 197 Q1000 242 1006 279 L1001 317 L1014 318 L1018 281 Q1010 244 1025 199Z','#eee7d0');
      H.stroke(g,'M1021 206 Q1006 249 1012 280 L1007 315','rgba(252,243,224,.76)',1.5);
      K.path(g,'M1000 310 Q981 397 1010 476 Q1020 511 997 568 L1009 569 Q1032 511 1021 474 Q992 386 1015 313Z','#f5ecd8');
      for(let i=0;i<9;i++)H.stroke(g,`M${996+i*2} 324 Q${979+i*2} 393 ${1006+i*2} 473 Q${1024+i} 526 ${1001+i} 567`,'rgba(251,242,222,.65)',1);
      // A few calligraphic shrubs gather on authored shelves, leaving wash planes legible.
      for(const [x,y,n] of [[456,315,6],[531,388,5],[841,415,5],[927,279,5],[1047,461,4],[1244,461,4],[1370,507,6]]){for(let j=0;j<n;j++)K.path(g,`M${x+j*6} ${y+Math.sin(j)*3} q-4 -7 -2 -12 q8 0 9 10Z`,'rgba(35,39,30,.50)');}


      H.stroke(g,'M447 275 l19 25 l-11 39 l21 13 l-14 61 l27 17 M475 236 l-8 48 l23 23 l-7 54 M893 329 l20 27 l-14 52 l20 39 l-8 57 M957 210 l-9 61 l22 28 l-13 44 l24 56','rgba(42,43,31,.42)',1.4);
      H.pine(g,478,316,.18,'#384b34','rgba(47,72,48,.12)');H.pine(g,951,277,.16,'#384b34','rgba(47,72,48,.12)');
      H.pine(g,829,401,.24,'#4c6042','rgba(47,72,48,.09)');H.pine(g,1268,411,.3,'#596a4c','rgba(47,72,48,.08)');
      for(const [x,y,s] of [[851,80,.13],[913,63,.11],[998,68,.12],[1061,91,.14],[1118,319,.15]])H.pine(g,x,y,s,'#3e503d','rgba(43,65,42,.12)');
      K.path(g,'M1066 406 l16 -7 l23 1 l25 7 l-14 5 l-41 -1Z','#74806a','#505f48',.65);
      K.rect(g,1082,391,23,13,'#b1b196','#59654c',.65);H.roof(g,1093,392,36,12,'#5c6b55','#475a43');
      K.rect(g,1091,395,5,9,'#485940');H.stroke(g,'M1078 406 h31 M1081 409 h30','rgba(44,61,39,.58)',.65);
 }),0,0);
 for(let j=0;j<21;j++){const u=(l*.19+j/21)%1,y=324+u*240,x=1005-11*Math.sin(u*TAU);path(c,`M${x} ${y} q-2 9 1 17`,null,'rgba(255,248,224,.63)',.9);}
 for(let j=0;j<3;j++){const x=1185-l*34+j*33,y=282+j*9+Math.sin(l+j)*4;path(c,`M${x-8} ${y-3} Q${x-3} ${y-8} ${x} ${y} Q${x+4} ${y-8} ${x+9} ${y-3}`,null,'#4e5c49',1.1);}
 c.restore();
 K.rect(c,0,568,1600,186,K.gradient(c,[0,568],[0,754],[[0,'rgba(238,229,207,0)'],[.52,'rgba(238,229,207,.86)'],[1,'#eee5cf']]));
 for(let j=0;j<3;j++){const drift=Math.sin(l*.34+j)*25;path(c,`M${200+drift} ${618+j*27} Q650 ${586+j*34} 1250 ${612+j*24} Q1100 ${648+j*28} 500 ${647+j*26}Z`,'rgba(247,239,220,.20)');}
 c.save();c.translate((px-800)*.18,0);c.drawImage(K.cached('R6-song-shore',g=>{
      // A tiny riverside hermitage establishes the immense landscape scale.
      for(let i=0;i<26;i++){let x=377+K.rnd(i+111)*816,y=729+K.rnd(i+49)*27;H.stroke(g,`M${x} ${y} h${14+K.rnd(i)*55}`,'rgba(116,111,86,.18)',1);}
      for(let j=0;j<32;j++){let x=1074+j*2.4,y=738+Math.sin(j*.36)*3;K.ellipse(g,x,y,2.8,1.3,'rgba(45,53,33,.50)');}
      for(let j=0;j<17;j++){let x=340+j*9,y=772-j*.38;H.stroke(g,`M${x} ${y} q3 -8 6 -2`,'rgba(53,62,39,.46)',.7);}
      // A ledge temple is small enough to measure the cliff, not compete with it.
      // Shore contours, small stone steps and the hermitage's recessed windows.
      K.rect(g,1054,689,66,41,'#c6baa0','#736d51',1);H.roof(g,1087,692,94,29,'#5a6049','#3a4736');K.rect(g,1082,707,13,23,'#394333');
      H.lattice(g,1061,701,12,16,'#8a8566',6);H.lattice(g,1100,701,12,16,'#8a8566',6);
      for(let j=0;j<6;j++)K.line(g,[[1073-j*2,732+j*2],[1108+j*2,732+j*2]],'rgba(107,100,73,.44)',.65);
      H.stroke(g,'M400 717 Q608 700 793 719 T1185 720 M537 734 Q697 726 850 737 M880 749 Q1000 755 1183 740','rgba(112,112,84,.18)',.7);
      for(let j=0;j<11;j++){const x=345+j*71,y=749+Math.sin(j*1.7)*5;H.stroke(g,`M${x} ${y} q13 -2 29 0 M${x+9} ${y+3} h16`,'rgba(96,100,72,.20)',.65);}
      for(const [x,y,h] of [[49,802,23],[303,800,25],[1243,808,20],[1530,798,29]])H.reeds(g,x,y,h,'rgba(48,63,37,.57)');

 }),0,0);
 const bx=480-l*9,by=743+Math.sin(l)*.7;path(c,`M${bx-25} ${by} Q${bx} ${by+13} ${bx+25} ${by-2} L${bx+16} ${by+9} L${bx-16} ${by+9}Z`,'#64715a','#4f5c48',.7);
 const hand=H.inkBoatman(c,bx-4,by,25.4,l),pole=bx+24+Math.sin(l*1.2)*6;line(c,[hand,[pole,by+12]],'#67715a',.9);H.ripple(c,pole,by+12,(l*.35)%1,'#b1b096',18);c.restore();
 const pts=[];for(let x=0;x<=1600;x+=8)pts.push([x,song.ground(x)]);
 K.line(c,pts.concat([[1600,900],[0,900]]),null,1,true,K.gradient(c,[0,709],[0,900],[[0,'#cec4a9'],[1,'#e6ddc6']]));line(c,pts,'#939175',1.35);
 c.save();c.beginPath();pts.forEach(([x,y],i)=>i?c.lineTo(x,y):c.moveTo(x,y));c.lineTo(1600,900);c.lineTo(0,900);c.closePath();c.clip();
 c.drawImage(K.cached('R6-song-bank-texture',g=>{for(let j=0;j<6800;j++){const x=K.rnd(j+470)*1600,y=710+K.rnd(j+128)*190;K.rect(g,x,y,.8+K.rnd(j+8)*2.6,.6,'rgba(98,93,66,.09)');}for(let j=0;j<22;j++){const x=37+j*73,y=825+(j%3)*16;path(g,`M${x} ${y} q16 -4 39 0`,null,'rgba(105,108,77,.16)',.65);}}),0,0);c.restore();
 for(let j=0;j<68;j++){const x=j*24,y=song.ground(x)+6+(j%3)*8;line(c,[[x,y],[x+9+(j%4)*3,y-.9]],'rgba(94,101,71,.27)',.55);}
 // A traveler casts a very small rooted shadow only on the path, not on the sky.
};
song.over=function(c,l){const px=P.sceneContext?.rider?.x??800;c.save();c.translate(-(px-800)*.16,0);c.drawImage(K.cached('R6-song-near-pine',g=>{
      K.path(g,'M0 789 L0 654 Q31 644 58 619 Q82 623 105 645 L137 656 Q159 634 180 628 Q201 642 223 667 L272 693 Q297 718 341 748 L420 799Z','#4c5141','#2f392e',1.5);
      K.path(g,'M0 650 Q23 682 14 724 L51 753 Q105 739 146 792 L226 800 Q155 739 147 711 Q109 675 60 632Z','rgba(19,27,22,.23)');
      K.path(g,'M1170 793 Q1237 747 1286 714 Q1303 675 1333 656 Q1361 653 1394 674 Q1420 665 1444 644 Q1462 621 1480 638 L1512 651 L1540 655 Q1572 634 1600 626 L1600 793Z','#626b51','#34452f',1.4);
      K.path(g,'M1328 658 Q1337 697 1290 737 L1254 774 L1370 800 Q1337 741 1392 678Z','rgba(23,34,24,.24)');
      for(const [x,y,w] of [[31,690,39],[107,718,29],[196,736,34],[1323,713,29],[1424,694,32],[1517,713,34]]){H.stroke(g,`M${x} ${y} l${w*.4} -7 l${w*.6} 8 M${x+w*.7} ${y+4} q-11 15 -7 34`,'rgba(29,39,27,.48)',1.2);H.stroke(g,`M${x+9} ${y+4} q-6 13 -3 24`,'rgba(34,42,29,.35)',.8);}
      H.pine(g,199,733,1.64,'#283d2c','rgba(31,45,30,.28)');H.pine(g,89,705,1.15,'#374735','rgba(31,45,30,.25)');H.pine(g,1401,710,.77,'#2e412b','rgba(31,45,30,.25)');

 }),0,0);c.restore();
 for(const [x,y,w]of[[34,809,43],[1537,807,48]]){path(c,`M${x-w} ${y+17} L${x-w*.75} ${y-3} L${x-w*.23} ${y-14} L${x+w*.42} ${y-5} L${x+w} ${y+17}Z`,'#716d51','#434c35',1);H.reeds(c,x+w*.65,y+12,28,'#4b5638',l);}
};

// Fish has its own articulated arc and lands in the river. No sliding basket,
// no invisible collision, no moving a painted merchant as a rigid sticker.
const oldStory=P.storyDetails;
P.storyDetails=function(c,i,l,t,p,front){
 if(i!==5&&i!==4&&i!==1&&i!==12)oldStory(c,i,l,t,p,front);
 if(i===5){const f=V.fishAt(l);
  if(!front){fishSeller(c,1160,P.scenes[5].ground(1160)-8,l);splash(c,340,826,(l-V.fish.launch)*1.30,1.2);splash(c,1350,826,(l-V.fish.land)*1.4,1.05);}
  else {if(f.visible){smallFish(c,f.x,f.y,1.32,f.angle,l*18);for(let j=0;j<4;j++){const u=f.u-.025*(j+1);if(u<0)continue;const x=340+1010*u,y=826-2700*u*(1-u);K.ellipse(c,x-7,y+10,1.4,2.6,'#b9c9aa',null,1,-.4);}}
   if(l>3.86&&l<4.7){const a=io(l,3.86,4,4.35,4.7);c.save();c.globalAlpha=a;K.text(c,'这次，轮到我让路。',1020,430,23,'#756b4e','center','serif');c.restore();}
  }
 }
 if(i===12&&front&&l>4.35&&l<5.4){c.save();c.globalAlpha=io(l,4.35,4.5,5.1,5.4);K.text(c,'声浪平了。路还在。',1135,501,22,'#f5dab1','center','serif');c.restore();}
 if(!front)return;
 // Small consequences: deliberately bounded, clear, not wall-to-wall particles.
 if(i===0&&l>2.6){const u=E((l-2.6)/.6);c.save();c.globalAlpha=.42*u;path(c,'M1085 577 q-25 -31 -54 -15 q-22 11 -13 34 q19 25 41 3 M1074 565 l17 -13 l11 12 M1017 609 l-8 11',null,'#955332',2.2);c.restore();}
 if(i===2&&l>3.2&&l<4.35){splash(c,1249,555,(l-3.2)*1.2,.32,'#c4c4a1');}
 if(i===3&&l>2.4&&l<4.9){const u=K.clamp((l-2.4)/2.5),x=1065+178*u,y=518+125*u-72*Math.sin(Math.PI*u);c.save();c.translate(x,y);c.rotate(-.7+u*2);path(c,'M-8 0 Q0 -7 13 0 Q1 5 -8 0Z','#afa778','#777d62',.55);c.restore();if(l>4.25)splash(c,1243,643,(l-4.25),.38,'#b8b99a');}
 if(i===6){const turn=Math.floor(P.sceneContext?.crankAngle/TAU||0);c.save();c.globalAlpha=.5;for(let j=0;j<Math.min(4,((turn%5)+5)%5);j++)K.circle(c,1255+j*14,456,3.0,'#a05c3c');c.restore();}
 if(i===7){const u=io(l,1.8,2.7,4.4,5.1);for(let j=0;j<4;j++){const tt=l*1.6+j*.73,x=635+j*86,y=564-38*u+Math.sin(tt)*7;c.save();c.translate(x,y);c.globalAlpha=.6*u;const w=6*Math.abs(Math.sin(tt*4));K.ellipse(c,-w*.5,0,w,2,'#c5b37a',null,1,-.5);K.ellipse(c,w*.5,0,w,2,'#b3a270',null,1,.5);c.restore();}}
 if(i===8&&l>2.0&&l<4.5){const u=(l-2)/2.5;K.ellipse(c,1125,748,9+u*29,2+u*3,null,`rgba(75,90,67,${.3*(1-u)})`,.75);}
 if(i===9){const u=io(l,2.2,2.8,3.9,4.4);c.save();c.globalAlpha=u*.32;path(c,'M1187 737 L1280 621 L1390 737Z','#e6b96e');path(c,`M1252 731 Q1284 ${704-u*35} 1316 731`,null,'#f0c37d',1.4);c.restore();}
 if(i===10&&l>3.15&&l<4.4){const u=(l-3.15)/1.25;c.save();c.globalAlpha=1-u;path(c,`M1210 ${641+u*12} q13 -7 26 0`,null,'#83977a',.8);c.restore();}
 if(i===13){const v=io(l,2.8,3.1,4.1,4.6);c.save();c.globalAlpha=v*.75;path(c,'M1322 268 L1328 258 L1334 268Z','#c9c5a3');line(c,[[1328,267],[1328,289]],'#6c7e73',1);c.restore();}
 if(i===14&&l>=3.6){const a=E((l-3.6)/.3);c.save();c.globalAlpha=a*.5;K.ellipse(c,803,442,94,94,null,'#9df3b7',.6);K.text(c,'X = Y',803,569,13,'#a7dfb4','center','mono');c.restore();}
 if(i===15&&l>4.55){const pp=P.sceneContext?.rider||p;if(pp){c.save();c.globalAlpha=io(l,4.55,4.68,5.2,5.55);K.text(c,'NO FISH WERE EATEN',1136,486,16,'#fff1ba','center','mono','700');c.restore();}}
 if(i===17){const u=io(l,3.4,3.65,4.8,5.3);c.save();c.globalAlpha=u*.72;K.text(c,'SIDE B / 还是这条路',1190,795,15,'#b9eeed','center','mono');c.restore();}
 if(i===19&&l>4.2){c.save();c.globalAlpha=E((l-4.2)/.25);K.text(c,'✓ chain  ✓ eyes  ✓ whole bird',487,430,12,'#89b7a0','left','mono');c.restore();}
};
// The typographic object belongs to the medium, with its own entrance, rhythm
// and safe area. Notes are short enough to read while the rider acts below.
P.sceneNotes=['借一条路，留一道轮印。','画可以留下。本人继续。','车马有编制，来客无编号。','风借衣带，鸟借一条路。','近松，远山，一位行者。','鱼跃长桥。让它先过。','踩过的路，都有数。','喷泉让出一道水门。','此处无声，胜过车铃。','一束灯光，另一种出口。','风把帽子送回主人。','一颗星搭了半圈便车。','一声惊呼，山海共振。','主人赶路，影子先下班。','把失真调回自己。','长喙也是一种控制器。','不是表情，是朋友。','磁带重播，晚饭不等人。','两碗白饭，一颗心意。','路径由代码绘制，方向由自己选。'];
const oldNote=P.drawSceneNote;
P.drawSceneNote=function(c,i,alpha=1){const l=D.local(i,P.outputTime||0);c.save();
 if([0,1,2,6].includes(i)&&l>.1&&l<.82){c.beginPath();c.rect(0,0,1600*S((l-.1)/.72),900);c.clip();}
 if(i===5){c.translate(-100,0);const a=Math.sin(l*1.7)*.004;c.translate(505,20);c.rotate(a);c.translate(-505,-20);}
 if(i===9){c.globalAlpha=alpha*(.96+.04*Math.sin(l*5));alpha=1;}
 oldNote(c,i,alpha);c.restore();
};
// Press room: a complete seated upper body, not an oversized head on a stock
// torso. Every hand is attached to the rigid camera with an articulated sleeve.
function sleeve(c,sh,wrist,bend,coat,ink){
 const dx=wrist[0]-sh[0],dy=wrist[1]-sh[1],d=Math.max(1,Math.hypot(dx,dy)),L=61,R=59;
 const aa=Math.min(L,Math.max(0,(L*L-R*R+d*d)/(2*d))),bb=Math.sqrt(Math.max(0,L*L-aa*aa));
 const e=[sh[0]+dx/d*aa-dy/d*bb*bend,sh[1]+dy/d*aa+dx/d*bb*bend];
 line(c,[sh,e,wrist],ink,19);line(c,[sh,e,wrist],coat,16);line(c,[[e[0]-3,e[1]-4],[e[0]+4,e[1]+1]],'#a8b3a2',.65);
 const vx=(wrist[0]-e[0])/Math.max(1,Math.hypot(wrist[0]-e[0],wrist[1]-e[1])),vy=(wrist[1]-e[1])/Math.max(1,Math.hypot(wrist[0]-e[0],wrist[1]-e[1]));line(c,[[wrist[0]-vy*7,wrist[1]+vx*7],[wrist[0]+vy*7,wrist[1]-vx*7]],'#dce0cc',6);return e;
}
V.pressAim=(v,t)=>Math.max(io(t,129.7,130.4,132.2,133),io(t,135.15,135.65,136.6,137));
P.pressFlashTimes=[130.2125,130.7375];
P.pressFlashPoint=(t,k)=>{const v=k%2?2:0,dir=v>1?-1:1,aim=V.pressAim(v,t);return[(v?1417:153)+dir*34,(v?858:857)-2-35-aim*56-26];};
P.pressReporter=function(c,x,y,v,t=125){
 const cam=v%2===0,dir=v>1?-1:1,coat=['#3b6670','#8e8b72','#58677a','#967b65'][v],ink='#304f50',skin=v===2?'#bb9e7d':'#d7b99b',hair=v===2?'#788179':v===3?'#51493f':'#384743';
 const aim=V.pressAim(v,t),nod=cam?-.045*aim:.07+.018*Math.sin(t*2.4+v),cx=26,cy=-35-aim*56;
 c.save();c.translate(x,y-2);c.scale(dir,1);
 path(c,'M-59 75 L-56 -18 Q-54 -44 -32 -52 L-15 -57 H16 Q38 -52 49 -31 L61 75Z',coat,ink,1.3);
 path(c,'M-55 -18 Q-42 -47 -30 -49 L-20 -24 Q-29 19 -28 69 H-57Z','rgba(20,45,48,.24)');path(c,'M18 -54 Q40 -47 46 -27 L47 69 H25 Q27 12 18 -54Z','rgba(227,232,204,.10)');
 // The nape remains rooted in the collar through the head nod.
 path(c,'M-11 -80 L-10 -56 L1 -47 L15 -57 L11 -79Z',skin,ink,.8);
 path(c,'M-22 -52 L-13 -62 L0 -50 L14 -62 L27 -50 L14 -28 L1 -44 L-9 -27Z','#dce0c9',ink,.7);
 path(c,'M-25 -48 L-13 -13 L-8 -28 M27 -49 L20 -15 L14 -28 M2 -42 L7 64',null,ink,.85);
 for(let j=0;j<4;j++)K.circle(c,9,-9+j*18,1.3,'#bac6b3',ink,.4);
 path(c,'M-42 17 q10 6 15 4 M30 12 q9 5 15 0 M-20 56 q15 -4 29 0',null,'rgba(225,228,202,.35)',.7);
 c.save();c.translate(0,-93);c.rotate(nod);
 path(c,'M-17 -16 Q-12 -32 5 -29 Q22 -25 21 -11 L27 -2 Q27 1 21 3 L21 12 Q18 22 5 22 Q-7 20 -12 11 L-18 4Z',skin,ink,.95);
 path(c,'M11 -25 Q23 -19 19 -8 L24 0 L19 4 L18 13 Q14 21 5 22 Q20 21 22 12 L22 3 L27 0 L21 -11 Q21 -25 11 -25Z','rgba(103,76,55,.17)');
 path(c,'M-17 7 Q-28 -9 -20 -26 Q-13 -36 1 -34 Q19 -37 23 -22 L20 -12 Q9 -17 2 -24 Q-3 -12 -10 -8 L-11 9Z',hair,ink,.9);
 if(v===3)path(c,'M-22 -19 Q-43 -29 -40 -8 Q-36 2 -21 -3Z',hair,ink,.8);
 path(c,'M-19 -22 Q-8 -33 7 -28 M-21 -12 Q-13 -22 -5 -23',null,v===2?'#b4b6a3':'#75887b',.7);
 K.ellipse(c,-9,2,3.6,5.2,skin,ink,.6);path(c,'M-10 0 q5 -3 3 6',null,'#947f69',.5);
 path(c,'M6 -10 Q11 -13 16 -10 M7 -6 Q11 -8 16 -6 M17 2 l-3 1 M16 11 l6 -1',null,ink,.7);K.circle(c,12,-6,1.05,ink);
 if(v===2){path(c,'M2 -9 H19 V0 H3Z',null,'#68796d',.8);line(c,[[-8,-7],[2,-5]],'#68796d',.8);}c.restore();
 if(cam){
  sleeve(c,[32,-46],[cx+33,cy+13],-1,coat,ink);sleeve(c,[-32,-47],[cx-13,cy+6],1,coat,ink);
  path(c,`M-8 -57 Q-21 7 ${cx-12} ${cy+16} M12 -58 Q48 13 ${cx+25} ${cy+15}`,null,'#203d42',1.8);
  c.save();c.translate(cx,cy);c.rotate(-.06);
  path(c,'M-13 -14 H20 L25 -9 V14 H-13 Q-17 11 -17 6 V-9Z','#26434c','#9ab0a3',1.0);path(c,'M-8 -14 L-3 -21 H10 L14 -14Z','#4d696b',ink,.7);
  K.rect(c,-11,-9,22,15,'#668481','#18383e',.6);K.rect(c,-8,-6,16,10,'#aec1af');path(c,'M-6 1 l7 -6 l6 4',null,'#496e64',.7);
  path(c,'M22 -11 L43 -8 V10 L22 13Z','#223f48','#94aea0',.8);for(let k=0;k<5;k++)line(c,[[25+k*3,-9],[25+k*3,10]],'#55777b',.5);K.ellipse(c,44,1,4,9,'#2d5963','#a3beb0',.7);K.ellipse(c,45,1,2.2,6.4,'#102e3c','#628c90',.55);
  path(c,'M-13 10 Q-21 8 -20 -3 L-17 -12 Q-14 -17 -9 -13 L-6 -10 L-12 -8 L-10 4 L-3 6 L-4 12Z',skin,ink,.7);
  path(c,'M29 11 Q31 18 38 16 L46 11 L45 6 Q42 3 40 7 L37 10 L32 9Z',skin,ink,.7);path(c,'M-17 -5 l7 1 M-17 -1 l7 1 M34 14 l7 -4',null,'#9a7b61',.45);
  K.rect(c,0,-30,17,9,'#bcc9b7',ink,.7);K.rect(c,2,-28,13,5,'#f2eed0');K.circle(c,16,-14,1.8,'#c9ad72');c.restore();
 }else{
  const k=Math.sin(t*5+v),wx=8+k*.9,wy=7+Math.cos(t*4)*.7;
  sleeve(c,[-32,-44],[-13,19],1,coat,ink);sleeve(c,[31,-43],[wx+8,wy+6],-1,coat,ink);
  path(c,'M-30 4 L9 -5 L29 37 L-16 42Z','#eae2c8',ink,.8);for(let j=0;j<5;j++)line(c,[[-22+j*2,10+j*5],[8+j*2,3+j*5]],'#a5ac92',.55);
  path(c,'M-20 18 Q-13 12 -6 16 L-5 22 L-14 28 L-20 24Z',skin,ink,.65);
  path(c,`M${wx} ${wy} Q${wx+6} ${wy-5} ${wx+13} ${wy+2} L${wx+9} ${wy+10} L${wx+2} ${wy+11}Z`,skin,ink,.65);line(c,[[wx+5,wy-5],[wx-3,wy+18]],ink,1.35);
 }
 path(c,'M-64 69 Q-8 54 63 68 L66 77 H-65Z','#365956','#869e8a',1.1);c.restore();
};
// Scream is an expressionist change of the whole space, not a camera shake.
// A continuous displacement field is evaluated per pixel with an inverse displacement shader. The
// identical map affects road, wheels, bird, background and shadows together.
V.screamAmplitude=l=>38*io(l,2.22,2.42,2.94,3.55)+24*io(l,3.32,3.52,3.95,4.65);

function createWaveSurface(){
 const cv=P.makeCanvas(1920,1080),gl=cv.getContext('webgl',{alpha:false,antialias:false,preserveDrawingBuffer:true});
 if(!gl)return null;
 const vs=`attribute vec2 p;varying vec2 uv;void main(){uv=p*.5+.5;gl_Position=vec4(p,0.,1.);}`;
 const fs=`precision highp float;varying vec2 uv;uniform sampler2D img;uniform float amp;uniform float tm;
 vec2 disp(vec2 p){float edge=sin(3.14159265*clamp(p.x/1600.,0.,1.))*.9+.1;float env=sin(3.14159265*clamp((p.y-180.)/720.,0.,1.));float q=(p.x-1080.)*.010+(p.y-440.)*.006-(tm-2.22)*5.5;return vec2(amp*.32*sin(q*.73),amp*sin(q))*env*edge;}
 void main(){vec2 target=vec2(uv.x*1600.,(1.-uv.y)*900.);vec2 src=target;for(int j=0;j<4;j++)src=target-disp(src);gl_FragColor=texture2D(img,vec2(src.x/1600.,1.-src.y/900.));}`;
 function compile(type,code){const sh=gl.createShader(type);gl.shaderSource(sh,code);gl.compileShader(sh);if(!gl.getShaderParameter(sh,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(sh));return sh;}
 const program=gl.createProgram();gl.attachShader(program,compile(gl.VERTEX_SHADER,vs));gl.attachShader(program,compile(gl.FRAGMENT_SHADER,fs));gl.linkProgram(program);if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(program));gl.useProgram(program);
 const buffer=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,buffer);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,1,1]),gl.STATIC_DRAW);const loc=gl.getAttribLocation(program,'p');gl.enableVertexAttribArray(loc);gl.vertexAttribPointer(loc,2,gl.FLOAT,false,0,0);
 const tex=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,tex);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,true);gl.uniform1i(gl.getUniformLocation(program,'img'),0);
 const ampLoc=gl.getUniformLocation(program,'amp'),timeLoc=gl.getUniformLocation(program,'tm');
 return{canvas:cv,render(src,amp,t){gl.viewport(0,0,1920,1080);gl.bindTexture(gl.TEXTURE_2D,tex);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,src);gl.uniform1f(ampLoc,amp);gl.uniform1f(timeLoc,t);gl.drawArrays(gl.TRIANGLE_STRIP,0,4);return cv;}};
}
const oldRender=D.render;
D.render=function(c,t){
 const i=D.locate(t),l=D.local(i,t),amp=i===12?V.screamAmplitude(l):0;
 if(amp<.01)return oldRender(c,t);
 if(!V.warp){V.warp=P.makeCanvas(1920,1080);V.warpCtx=V.warp.getContext('2d');V.waveGPU=createWaveSurface();}
 oldRender(V.warpCtx,t);const surface=V.waveGPU?V.waveGPU.render(V.warp,amp,l):V.warp;
 c.save();c.setTransform(c.canvas.width/1600,0,0,c.canvas.height/900,0,0);c.drawImage(surface,0,0,1600,900);c.restore();
};
P.renderAt=D.render;
// Replace obsolete basket cue in the visual event ledger. Audio carries the
// same native times and is tested against this ledger at export.
P.storyEvents=P.storyEvents.filter(e=>e.scene!==5&&e.scene!==1);
P.storyEvents.push({scene:1,u:2.18,id:'wall_pigment_contact',kind:'brush'},{scene:1,u:3.66,id:'wall_living_exit',kind:'harp'},{scene:5,u:2.32,id:'fish_leaves_river',kind:'splash'},{scene:5,u:3.62,id:'fish_lands_beyond_bridge',kind:'splash'},{scene:5,u:3.96,id:'fish_right_of_way',kind:'bell'});
P.version='R6';P.edition='pure-code-R6-living-media';P.storyRevision='R6 — imprint, parallax, fish flight, expressionist resonance';P.invalidateMotion();
})();
