/* A small journey through art. All frames are deterministic functions of time. */
P.captions = [
 '还没有自行车的年代，已经有人围观。',
 '请保持侧脸。这里的画师有一点职业习惯。',
 '车马出行，混进了一位不在编制的骑士。',
 '吴带当风。今天的风，也吹到了羽毛上。',
 '山很大，路很长。他只是画里的一个小点。',
 '汴京今日路况：虹桥上有一只鹈鹕。',
 '用最古老的计数法，记录最认真的踩踏。',
 '宫廷里的每双眼睛，都在追着同一辆车。',
 '看什么？没见过赶路的鸟吗。',
 '换了一双皮影翅膀，踏板依旧要自己踩。',
 '富士山不会动。车轮会。',
 '今晚，星星和车轮转在同一个节拍里。',
 '有人在呐喊，有鸟想借过。',
 '影子先上了楼，主人还在找路。',
 '两个电压，描出一只鸟。',
 '人生第一次骑车，还顺便多了一条命。',
 '对方发来了一只骑车的鹈鹕。',
 '磁带慢了一点，日落就多停留一会儿。',
 '弹幕路过，主角不停播。',
 '最后一幅画，正在写出自己。'
];

// The twenty paintings live beside one another. Camera movement exposes the next
// room; a single articulated rider crosses the actual seam and continuous road.
P.version="R4";
P.edition="pure-code-R4-drivetrain-eyes";
// A brief X/Y calibration excursion deforms the very same sampled contours
// used by the phosphor trace and the two channel monitors. The instrument locks
// back onto the rider without an operator, a cut, or a change to wheel timing.
P.scopeSignalAmount=local=>K.ease((local-2.15)/.42)*(1-K.ease((local-3.10)/.5));
(()=>{
 const originalContours=M.traceContours;
 M.traceContours=function(p){
  const lines=originalContours(p),local=P.sceneContext?P.sceneContext.local:0,a=P.scopeSignalAmount(local);
  if(a<=.000001)return lines;
  let total=0;for(const line of lines)for(let j=1;j<line.length;j++)total+=Math.hypot(line[j][0]-line[j-1][0],line[j][1]-line[j-1][1]);
  let pos=0;const phase=(local-2.15)*1.55,out=[];
  for(const line of lines){const dest=[];for(let j=1;j<line.length;j++){
   const l=line[j-1],r=line[j],len=Math.hypot(r[0]-l[0],r[1]-l[1]),steps=Math.max(1,Math.ceil(len/5));
   for(let k=j===1?0:1;k<=steps;k++){const u=k/steps,q=(pos+len*u)/total*Math.PI*2,px=K.lerp(l[0],r[0],u),py=K.lerp(l[1],r[1],u);dest.push([K.lerp(px,213*Math.sin(q*3+phase),a),K.lerp(py,-90+176*Math.sin(q*2+phase*.65),a)]);}
   pos+=len;
  }if(dest.length)out.push(dest);}
  return out;
 };
})();
P.transHalf=1.2;
P.nativePose=function(i,local,t){
 if(i<0)return P.introPose(local);
 const s=P.scenes[i];return Object.assign({x:740+24*local,y:625,scale:1.15,tilt:0,alpha:1,style:i},s.pose?s.pose(K.clamp(local,0,6),t):{});
};
P.roomCamera=function(i,local){
 return {z:1,x:0,y:0};
};
P.basePose=function(i,local,t){const p=P.nativePose(i,local,t),v=P.roomCamera(i,local);return Object.assign({},p,{x:p.x*v.z+v.x,y:p.y*v.z+v.y,scale:p.scale*v.z});};
P.nativeGround=function(i,x,local){
 if(i<0){const u=K.clamp((x-1368)/232);return 668+84*K.smoother(u);}
 const s=P.scenes[i];if(s.ground)return s.ground(x,K.clamp(local,0,6));
 const p=P.nativePose(i,3,8+i*6);return p.y+102*p.scale;
};
P.floorAt=function(i,x,local){const v=P.roomCamera(i,local);return v.y+v.z*P.nativeGround(i,(x-v.x)/v.z,local);};
P.chapterLabel=function(c,i,alpha=1,caption=true){
 if(P.drawSceneNote)P.drawSceneNote(c,i,alpha);
};
P.unprojectPose=function(p,v,offset=0){return Object.assign({},p,{x:(p.x-offset-v.x)/v.z,y:(p.y-v.y)/v.z,scale:p.scale/v.z});};
P.roomPass=function(c,i,local,t,offset=0,front=false,rider=null,transition=false){
 const v=P.roomCamera(i,local),nativeRider=rider?P.unprojectPose(rider,v,offset):P.nativePose(i,local,t);
 c.save();c.beginPath();c.rect(Math.max(0,offset),0,Math.min(1600,offset+1600)-Math.max(0,offset),900);c.clip();c.translate(offset+v.x,v.y);c.scale(v.z,v.z);
 P.sceneContext=Object.assign({rider:nativeRider,local:K.clamp(local,0,6),absolute:t,transition},P.motionAt(t));
 if(i<0){if(front)P.introFront(c,local);else P.introRoom(c,local);}else{
  const s=P.scenes[i],lt=K.clamp(local,0,6);if(!front)s.draw(c,lt,t);else{if(s.over)s.over(c,lt,t);if(s.foreground)s.foreground(c,lt,t,nativeRider);}
 }
 P.sceneContext=null;c.restore();
};
P.renderScene=function(c,i,local,t,override,labels=true){
 const p=Object.assign(P.basePose(i,local,t),override||{},P.motionAt(t));
 P.roomPass(c,i,local,t,0,false,p,false);
 c.save();const clip=i>=0&&P.scenes[i].riderClip;if(clip){const v=P.roomCamera(i,local);c.beginPath();c.rect(v.x+clip.x*v.z,v.y+clip.y*v.z,clip.w*v.z,clip.h*v.z);c.clip();}
 P.drawRider(c,t,Object.assign({},p,{style:i<0?3:i}));c.restore();
 P.roomPass(c,i,local,t,0,true,p,false);if(labels)P.chapterLabel(c,i);
};
P.roadColors=[['#bc9471','#85543a'],['#cbb281','#846844'],['#30382f','#a8b69d'],['#e0d8c2','#8a8973'],['#b4aa88','#656952'],['#c8ad79','#8f7047'],['#dec798','#985c3d'],['#d9c29a','#a4865a'],['#e5e5d3','#7e8a72'],['#8e602e','#513720'],['#d4bb83','#8f815e'],['#17355d','#81acc5'],['#907253','#deb27e'],['#626d64','#c0c3ad'],['#122e26','#6ef4a2'],['#86965d','#d5e8a0'],['#b8cbb8','#708d82'],['#33234b','#9fe0df'],['#a4b989','#e6f3b1'],['#254653','#93ddc9']];
P.joinGeometry=function(oldI,newI,oldLocal,newLocal,pan){
 const seam=1600-pan,oc=oldI>=0?P.scenes[oldI].riderClip:null,nc=P.scenes[newI].riderClip,ov=P.roomCamera(oldI,oldLocal),nv=P.roomCamera(newI,newLocal);
 const leftSpan=oc?Math.max(370,1600-((oc.x+oc.w)*ov.z+ov.x)+42):370;
 const rightSpan=nc?Math.max(370,nc.x*nv.z+nv.x+42):370;
 const L=seam-leftSpan,R=seam+rightSpan;
 const oldF=x=>P.floorAt(oldI,x+pan,oldLocal),newF=x=>P.floorAt(newI,x+pan-1600,newLocal);
 const yl=oldF(L),yr=newF(R),m0=K.clamp((oldF(L+4)-oldF(L-4))/8,-.6,.6),m1=K.clamp((newF(R+4)-newF(R-4))/8,-.6,.6);
 function floor(x){if(x<L)return oldF(x);if(x>R)return newF(x);const u=(x-L)/(R-L),u2=u*u,u3=u2*u,w=R-L;return(2*u3-3*u2+1)*yl+(u3-2*u2+u)*w*m0+(-2*u3+3*u2)*yr+(u3-u2)*w*m1;}
 return{seam,L,R,yl,yr,floor};
};
P.drawJoinRoad=function(c,g,oldI,newI){
 const a=oldI<0?['#d6c6a5','#a18c66']:P.roadColors[oldI],b=P.roadColors[newI];
 for(let side=0;side<2;side++){c.save();c.beginPath();c.rect(side?g.seam:-20,175,side?1640-g.seam:g.seam+20,660);c.clip();const palette=side?b:a;
  const pts=[];for(let x=g.L;x<=g.R+1;x+=10)pts.push([x,g.floor(x)]);
  const band=pts.concat([...pts].reverse().map(([x,y])=>[x,y+22]));K.line(c,band,null,1,true,palette[0]);K.line(c,pts,palette[1],2.2);
  for(let x=g.L+10;x<g.R;x+=33){let y=g.floor(x);K.line(c,[[x,y+9],[x+15,y+7]],palette[1],.65);}
  c.restore();
 }
};
P.gate=function(c,g,oldI,newI){
 const x=g.seam,y=g.floor(x);if(x<-50||x>1650)return;
 const col=newI>=14?'#6faaa0':'#a28c62',light=newI>=14?'#cae0c4':'#dec799';
 c.save();c.shadowColor='rgba(17,24,21,.2)';c.shadowBlur=9;K.rect(c,x-7,180,14,Math.max(30,y-180),col);c.shadowBlur=0;K.rect(c,x-4,183,3,Math.max(30,y-184),light);
 K.path(c,`M${x-19} 188 L${x} 170 L${x+19} 188Z`,col,light,1.5);
 K.rect(c,x-15,y-4,30,7,col);K.circle(c,x,198,3,light);c.restore();
};
P.supportPose=function(x,s,floor){
 let tilt=Math.atan2(floor(x+150*s)-floor(x-130*s),280*s);
 for(let n=0;n<3;n++){
  const co=Math.cos(tilt),si=Math.sin(tilt),rx=x+s*(-130*co-25*si),fx=x+s*(150*co-25*si);
  tilt=Math.atan2(floor(fx)-floor(rx),Math.max(1,fx-rx));
 }
 const co=Math.cos(tilt),si=Math.sin(tilt),rx=x+s*(-130*co-25*si),fx=x+s*(150*co-25*si);
 const ry=floor(rx)-77*s-s*(-130*si+25*co),fy=floor(fx)-77*s-s*(150*si+25*co);
 return{x,y:(ry+fy)/2,scale:s,tilt};
};
P.transitionGeometry=function(newI,t){
 const boundary=5+newI*6,oldI=newI-1,dt=t-boundary,raw=(dt+P.transHalf)/(2*P.transHalf),u=K.smoother(raw),pan=1600*u;
 const oldLocal=oldI<0?t:6+dt,newLocal=dt;
 const a=P.basePose(oldI,oldLocal,t),b=P.basePose(newI,newLocal,t),x=K.lerp(a.x,b.x,u),s=K.lerp(a.scale,b.scale,u);
 const g=P.joinGeometry(oldI,newI,oldLocal,newLocal,pan),p=P.supportPose(x,s,g.floor);
 const aa=P.supportPose(a.x,a.scale,g.floor),bb=P.supportPose(b.x,b.scale,g.floor);
 // Respect endpoint gestures and jumps while the road itself supplies the middle of the crossing.
 const wa=1-K.smoother(raw/.35),wb=K.smoother((raw-.65)/.35);
 p.y+=(a.y-aa.y)*wa+(b.y-bb.y)*wb;p.tilt+=(a.tilt-aa.tilt)*wa+(b.tilt-bb.tilt)*wb;
 p.expression=raw<.5?a.expression:b.expression;p.gazeX=K.lerp(a.gazeX||0,b.gazeX||0,u);p.headNod=K.lerp(a.headNod||0,b.headNod||0,u);p.bellPress=K.lerp(a.bellPress||0,b.bellPress||0,u);
 p.alpha=1;p.build=1;
 return{oldI,newI,oldLocal,newLocal,raw,u,pan,g,p};
};
P.transitionState=function(newI,t){const q=P.transitionGeometry(newI,t);Object.assign(q.p,P.motionAt(t));return q;};
P.renderTransition=function(c,newI,t){
 const {oldI,oldLocal,newLocal,raw,u,pan,g,p}=P.transitionState(newI,t);
 P.roomPass(c,oldI,oldLocal,t,-pan,false,p,true);P.roomPass(c,newI,newLocal,t,1600-pan,false,p,true);
 const edgeOpacity=K.ease(raw/.12)*(1-K.ease((raw-.88)/.12));
 c.save();c.globalAlpha=edgeOpacity;P.drawJoinRoad(c,g,oldI,newI);c.restore();
 for(let side=0;side<2;side++){c.save();c.beginPath();c.rect(side?g.seam:-50,-50,side?1700-g.seam:g.seam+50,1000);c.clip();P.drawRider(c,t,Object.assign({},p,{style:side?newI:oldI<0?3:oldI}));c.restore();}
 P.roomPass(c,oldI,oldLocal,t,-pan,true,p,true);P.roomPass(c,newI,newLocal,t,1600-pan,true,p,true);c.save();c.globalAlpha=edgeOpacity;P.gate(c,g,oldI,newI);c.restore();
 if(oldI>=0)P.chapterLabel(c,oldI,1-K.ease((raw-.18)/.18));P.chapterLabel(c,newI,K.ease((raw-.66)/.18));
};

// Rolling is measured against the road, not the movie clock. A common travelled
// distance drives both tyres, the chain and the feet. Camera translation is
// removed inside a room; the real distance across a room seam is retained.
// Physical rolling is kept independent of the musical clock. Different-sized
// drawings now share fixed sprockets. Cadence follows local rear-wheel rotation
// through the visible 32:20 gear, and stops with the bicycle.
P.drive={wheelRadius:77,chainringRadius:P.drivetrain.frontRadius,
 rearSprocketRadius:P.drivetrain.rearRadius,nominalTravelSpeed:1600/6,
 ratio:P.drivetrain.ratio};
P.drive.cadenceHz=P.drive.nominalTravelSpeed/(2*Math.PI*P.drive.wheelRadius*P.drive.ratio);
P.drive.ratioForRadius=()=>P.drive.ratio; // camera/figure scale is NOT a gear change.

P.longLocal=(i,t)=>i<0?t:K.clamp(t-5-i*6,0,6);
P.longTimeline=function(t){
 if(t<5){const u=K.clamp((t-2.4)/2.6),u2=u*u,u3=u2*u,worldX=(2*u3-3*u2+1)*(-452)+(u3-u2)*(1600/6)*2.6,screenX=K.lerp(1148,760,K.smoother(u));return{worldX,screenX,cameraX:worldX-screenX,scene:-1,local:t};}
 const i=Math.min(19,Math.floor((t-5)/6)),local=K.clamp(t-5-i*6,0,6),s=P.scenes[i],x=typeof s.travelX==='function'?s.travelX(local):1600*local/6,worldX=i*1600+x;
 return{worldX,screenX:760,cameraX:worldX-760,scene:i,local};
};
P.longNativeFloor=function(i,x,t){if(i>19)return 774;if(i< -1)return 668;return P.nativeGround(i,x,P.longLocal(i,t));};
P.scrollJoinHalf=k=>k===20?130:k===14?300:k>=15?170:230;
P.longFloor=function(x,t){
 const i=Math.floor(x/1600),seam=Math.round(x/1600)*1600,half=P.scrollJoinHalf(seam/1600);
 if(seam>=0&&seam<=32000&&Math.abs(x-seam)<half){
  const k=seam/1600,L=seam-half,R=seam+half,yl=P.longNativeFloor(k-1,1600-half,t),yr=P.longNativeFloor(k,half,t);
  const ml=(P.longNativeFloor(k-1,1600-half+2,t)-P.longNativeFloor(k-1,1600-half-2,t))/4,mr=(P.longNativeFloor(k,half+2,t)-P.longNativeFloor(k,half-2,t))/4,u=(x-L)/(R-L),u2=u*u,u3=u2*u;
  return(2*u3-3*u2+1)*yl+(u3-2*u2+u)*(R-L)*ml+(-2*u3+3*u2)*yr+(u3-u2)*(R-L)*mr;
 }
 return P.longNativeFloor(i,x-i*1600,t);
};
P.longFeatures=function(i,t){
 if(i>19)return{scale:1.04,elevation:0,extraTilt:0,gazeX:.8};
 const local=P.longLocal(i,t),p=P.nativePose(i,local,t),f=x=>P.longNativeFloor(i,x,t),support=P.supportPose(p.x,p.scale,f);
 return Object.assign({},p,{elevation:Number.isFinite(p.elevation)?p.elevation:i===15?p.y-support.y:0,extraTilt:Number.isFinite(p.gestureTilt)?p.gestureTilt:i===15?(p.tilt||0)-support.tilt:0});
};
P.longGeometry=function(t){
 const state=P.longTimeline(t),x=state.worldX,idx=Math.max(-1,Math.min(20,Math.floor(x/1600))),seam=Math.round(x/1600)*1600,half=230;
 let features=P.longFeatures(idx,t);
 if(seam>=0&&seam<=32000&&Math.abs(x-seam)<half){
  const k=seam/1600,a=P.longFeatures(k-1,t),b=P.longFeatures(k,t),u=K.smoother((x-seam+half)/(half*2));features=Object.assign({},u<.5?a:b);
  for(const key of ['scale','elevation','extraTilt','headNod','gazeX','gazeY','bellPress','brakeLean'])features[key]=K.lerp(a[key]||0,b[key]||0,u);
 }
 const p=P.supportPose(x,features.scale,w=>P.longFloor(w,t));p.y+=features.elevation||0;p.tilt+=features.extraTilt||0;
 Object.assign(p,{expression:features.expression,gazeX:features.gazeX,gazeY:features.gazeY,headNod:features.headNod,bellPress:features.bellPress,brakeLean:features.brakeLean,alpha:1,build:1});
 p.x=state.screenX;return Object.assign(state,{p});
};
P.drawScrollJoin=function(c,k,camera,t){
 const seam=k*1600,half=P.scrollJoinHalf(k),L=seam-half,R=seam+half,oldI=k-1,newI=k;
 const a=oldI<0?['#d6c6a5','#a18c66']:P.roadColors[Math.min(19,oldI)],b=newI>19?['#d6c6a5','#a18c66']:P.roadColors[newI];
 c.save();c.translate(-camera,0);
 for(let side=0;side<2;side++){
  const pts=[],start=side?seam:L,end=side?R:seam,palette=side?b:a;
  for(let x=start;x<=end+.1;x+=5)pts.push([x,P.longFloor(x,t)]);
  if(pts[pts.length-1][0]<end)pts.push([end,P.longFloor(end,t)]);
  const color=(hex,alpha)=>{let n=parseInt(hex.slice(1),16);return`rgba(${n>>16},${n>>8&255},${n&255},${alpha})`;};
  const band=c.createLinearGradient(start,0,end,0),edge=c.createLinearGradient(start,0,end,0),opacity=k>=14?.78:.62;
  band.addColorStop(0,color(palette[0],side?opacity:0));band.addColorStop(1,color(palette[0],side?0:opacity));
  edge.addColorStop(0,color(palette[1],side?.72:0));edge.addColorStop(1,color(palette[1],side?0:.72));
  K.line(c,pts.concat([...pts].reverse().map(([x,y])=>[x,y+(k>=14?5:7)])),null,1,true,band);K.line(c,pts,edge,.9);
 }
 c.restore();
};
P.exitScrollWall=function(c){P.pressBackground(c,125);};
P.renderLongScroll=function(c,t){
 const q=P.longGeometry(t),p=Object.assign(q.p,P.motionAt(t)),first=Math.floor(q.cameraX/1600),last=Math.floor((q.cameraX+1600)/1600),visible=[];
 for(let i=Math.max(-1,first);i<=Math.min(20,last);i++){
  const offset=i*1600-q.cameraX;visible.push([i,offset]);
  if(i===20){c.save();c.translate(offset,0);P.exitScrollWall(c);c.restore();}
  else P.roomPass(c,i,P.longLocal(i,t),t,offset,false,p,true);
 }
 for(let k=0;k<=20;k++)if(k*1600+P.scrollJoinHalf(k)>q.cameraX&&k*1600-P.scrollJoinHalf(k)<q.cameraX+1600)P.drawScrollJoin(c,k,q.cameraX,t);
 const portals=[];for(let k=0;k<=20;k++)if(k*1600+P.scrollPortalMargin>q.cameraX&&k*1600-P.scrollPortalMargin<q.cameraX+1600)portals.push(k);
 for(const k of portals)P.drawScrollPortal(c,k,q.cameraX,t,false);
 // The same geometric rider straddles the actual artwork edge. There is no
 // cross-faded duplicate and no screen-sized slide or scale reset.
 for(const [i,offset]of visible){
  const local=P.longLocal(i,t),scene=i>=0&&i<20?P.scenes[i]:null,authored=scene?P.nativePose(i,local,t):{};
  c.save();c.beginPath();c.rect(offset,-50,1600,1000);c.clip();
  const clip=scene&&scene.riderScreenClip?scene.riderScreenClip(local):null;
  if(clip){c.beginPath();c.rect(offset+clip.x,clip.y,clip.w,clip.h);c.clip();}
  let displayPose=Object.assign({},p,{style:i<0?3:i>19?18:i,alpha:authored.alpha===undefined?1:authored.alpha});if(scene&&scene.riderScreenPose)displayPose=scene.riderScreenPose(displayPose,local);P.drawRider(c,t,displayPose);c.restore();
 }
 for(const [i,offset]of visible){
  if(i<20)P.roomPass(c,i,P.longLocal(i,t),t,offset,true,p,true);
  else{c.save();c.beginPath();c.rect(offset,0,1600,900);c.clip();c.translate(offset,0);P.pressForeground(c,125);c.restore();}
 }
 for(const k of portals)P.drawScrollPortal(c,k,q.cameraX,t,true);
 for(const [i,offset]of visible)if(i>=0&&i<20){c.save();c.beginPath();c.rect(offset,0,1600,900);c.clip();c.translate(offset,0);P.chapterLabel(c,i,1,false);c.restore();}
 // A portrait screen has real black margins across the entire composition,
 // including neighbouring rooms and doorway layers. The same rider stays inside.
 for(const [i,offset]of visible)if(i===18){
  const scene=P.scenes[18],local=P.longLocal(18,t),a=scene.portraitFocus?scene.portraitFocus(local):0,v=scene.portraitViewport;
  if(a>0&&v){const x=offset+v.x;c.save();c.globalAlpha=a;c.fillStyle='#000';c.fillRect(0,0,Math.max(0,x),900);c.fillRect(x+v.w,0,Math.max(0,1600-x-v.w),900);c.fillRect(x,0,v.w,v.y);c.fillRect(x,v.y+v.h,v.w,900-v.y-v.h);c.restore();}
 }
 // Notes now live in each medium: seals, inscriptions, UI messages and HUD text.
};
P.pressPose=function(t){
 const scale=.95,x=-420+1300*Math.max(0,t-134.75);
 return{x,y:774-102*scale,scale,tilt:0,style:18,gazeX:1,gazeY:0,bellPress:Math.sin(Math.PI*K.clamp((t-136.1)/.30))};
};
P.rollingState=function(t){
 let p,floor,origin,segment='journey';
 if(t>=125&&t<134.75)return{active:false,segment:'overview'};
 if(t>=134.75){p=P.pressPose(t);floor=()=>774;origin=p.x;segment='press';}
 else{
  const q=P.longGeometry(t);p=q.p;origin=q.worldX;floor=x=>P.longFloor(x-p.x+q.worldX,t);
 }
 const s=p.scale,co=Math.cos(p.tilt||0),si=Math.sin(p.tilt||0),rearOffset=s*(-130*co-25*si),frontOffset=s*(150*co-25*si);
 const slope=x=>K.clamp((floor(x+1)-floor(x-1))/2,-2,2);
 return{active:true,segment,rearX:origin+rearOffset,frontX:origin+frontOffset,rearSlope:slope(p.x+rearOffset),frontSlope:slope(p.x+frontOffset),radius:P.drive.wheelRadius*s,tilt:p.tilt||0};
};
P.invalidateMotion=function(){P._rollingMotion=null;};
P.prepareMotion=function(){
 if(P._rollingMotion)return;
 const hz=240,N=Math.ceil((P.storyDuration||P.duration)*hz)+1,rows=new Array(N);let rear=0,front=0,travel=0,crank=0,prev=P.rollingState(0);
 rows[0]={rear,front,travel,crank,gear:P.drive.ratioForRadius(prev.radius||77),tilt:prev.tilt||0,speed:0,wheelSpeed:0};
 for(let j=1;j<N;j++){
  const q=P.rollingState(j/hz);let dr=0,df=0,distance=0,gear=P.drive.ratioForRadius(q.radius||prev.radius||77);
  if(q.active&&prev.active&&q.segment===prev.segment){
   const r=(q.radius+prev.radius)/2,mr=(q.rearSlope+prev.rearSlope)/2,mf=(q.frontSlope+prev.frontSlope)/2;
   const sr=(q.rearX-prev.rearX)*Math.hypot(1,mr),sf=(q.frontX-prev.frontX)*Math.hypot(1,mf);
   dr=sr/r;df=sf/r;distance=(sr+sf)/2;gear=P.drive.ratioForRadius(r);crank+=dr/gear;rear+=dr;front+=df;travel+=distance;
  }
  rows[j]={rear,front,travel,crank,gear,tilt:Number.isFinite(q.tilt)?q.tilt:(prev.tilt||0),speed:distance*hz,wheelSpeed:(dr+df)*hz/2};prev=q;
 }
 P._rollingMotion={hz,rows};
};
P.motionAt=function(t){
 P.prepareMotion();const {hz,rows}=P._rollingMotion,u=K.clamp(t,0,P.storyDuration||P.duration)*hz,j=Math.min(rows.length-2,Math.floor(u)),f=u-j,a=rows[j],b=rows[j+1];
 const lerp=k=>K.lerp(a[k],b[k],f),rear=lerp('rear'),front=lerp('front'),angle=(rear+front)/2,tilt=lerp('tilt'),crankAngle=(rear-tilt)/P.drive.ratio;
 return{wheelAngle:angle-tilt,rearWheelAngle:rear-tilt,frontWheelAngle:front-tilt,crankAngle,phaseTime:crankAngle/(2*Math.PI),travel:lerp('travel'),speed:lerp('speed')*(P.presentationRate||1),wheelSpeed:lerp('wheelSpeed')*(P.presentationRate||1),gearRatio:lerp('gear')};
};

// Opening: paper, a short explanation, and one sketch that keeps riding.
P.introPose=function(t){return{x:1148,y:558,scale:1.08,tilt:0,style:3,gazeX:.85,gazeY:0,headNod:t<2.4?-.025*Math.sin(t*2):0};};
P.introRoom=function(c,t){
 c.drawImage(K.cached('intro-pure-code-summary-paper',d=>{
  K.grain(d,'#eee7d6','rgba(99,70,35,.07)',3200);
  K.line(d,[[98,103],[518,103]],'#baa88b',1);
  K.text(d,'一 段 路  /  二 十 种 画 法',100,84,18,'#80684e','left','sans');
  K.text(d,'借过一下',98,162,43,'#342d26','left','serif','700');
  K.text(d,'A PELICAN, ON HIS WAY',101,195,14,'#91765b','left','sans');
  K.text(d,'——《鹈鹕骑行艺术通史》，卷一（虚构书名）',101,526,18,'#8a755c','left','serif');
  K.line(d,[[106,782],[1490,782]],'#bcab8e',1);
  const xs=[146,458,770,1082,1410],labels=['岩壁','石刻','纸墨','像素','代码'];
  for(let j=0;j<5;j++){const x=xs[j];K.circle(d,x,782,3,'#9d8667');K.text(d,labels[j],x,822,18,'#7a654d','center','serif');}
  K.path(d,'M128 743 l7 -22 30 -3 15 14 -10 25 -35 -2Z',null,'#9b7c59',1.2);K.circle(d,140,741,6,null,'#a5714e',1.4);K.circle(d,161,741,6,null,'#a5714e',1.4);K.line(d,[[140,741],[150,728],[161,741],[140,741]],'#a5714e',1.2);
  K.rect(d,441,720,35,37,null,'#8b7c65',1.2);K.path(d,'M448 730 h20 M448 738 h14 M448 746 h20',null,'#8b7c65',1.1);
  K.path(d,'M751 750 Q765 728 786 724 M756 750 Q770 733 789 730',null,'#697868',2.1);K.path(d,'M748 754 q18 -7 35 -3',null,'#697868',1);
  for(let j=0;j<9;j++)if(j!==2&&j!==6)K.rect(d,1065+(j%3)*12,721+Math.floor(j/3)*12,9,9,j%2?'#9b8a69':'#718b86');
  K.text(d,'< >',1410,751,32,'#6c7e7e','center','mono');
  K.text(d,'c. 4000 BCE',100,863,13,'#9a8467','left','mono');K.text(d,'NOW',1495,863,13,'#9a8467','right','mono');
 }),0,0);
 c.save();c.globalAlpha=K.ease((t-.25)/.55);K.text(c,'人类自古以来就痴迷于',100,290,43,'#44392e','left','serif','600');K.text(c,'画鹈鹕骑自行车。',100,354,47,'#44392e','left','serif','700');c.restore();
 const reveal=K.ease((t-2)/.28);c.save();c.globalAlpha=reveal;K.text(c,'——早在自行车被发明之前。',100,440,32,'#9b503a','left','serif');K.path(c,'M135 457 Q355 469 577 456',null,'rgba(155,80,58,.3)',1);c.restore();
 const road=[];for(let x=0;x<=1600;x+=5)road.push([x,P.longFloor(x-1600,t)]);K.line(c,road,'#9b896c',2);
 K.text(c,'图一 鹈鹕骑行图（摹本）',1148,716,15,'#8a755c','center','serif');
 K.path(c,'M1266 705 l19 -23 -5 0 M1285 682 l-1 8',null,'#9c8c71',.8);
};
P.introFront=function(c,t){};
P.intro=function(c,t){P.renderScene(c,-1,t,t,null,false);};
P.makeThumbs=function(){
 if(P.thumbs)return;P.thumbs=[];for(let i=0;i<20;i++){const cv=P.makeCanvas(320,180),d=cv.getContext('2d');d.scale(.2,.2);P.renderScene(d,i,3.6,8.6+i*6,null,false);P.thumbs.push(cv);}
};

// The twenty paintings lead to a twenty-first image: a press seat waiting for
// its guest. The bicycle passes behind that empty seat, then keeps going.
P.pressFlashTimes=[130.55,131.35,131.62,136.15];
P.pressBackground=function(c,t){
 c.drawImage(K.cached('press-room-r4-paper',d=>{
  K.grain(d,'#e9e4d5','rgba(78,78,60,.045)',2200);
  K.rect(d,0,0,1600,92,'#d1d7cd');K.line(d,[[0,91],[1600,91]],'#7d8b80',1.4);
  K.rect(d,81,100,139,584,'#667e79','#4f6965',1.4);K.rect(d,1380,100,139,584,'#667e79','#4f6965',1.4);
  for(let j=0;j<8;j++){const x=89+j*17;K.path(d,`M${x} 102 Q${x-6} 365 ${x+4} 684`,null,j%2?'#80948a':'#536e69',1.6);K.path(d,`M${x+1302} 102 Q${x+1294} 365 ${x+1306} 684`,null,j%2?'#80948a':'#536e69',1.6);}
  K.path(d,'M82 100 Q290 141 476 100 M1125 100 Q1310 141 1518 100',null,'#516c68',3);
  K.rect(d,250,143,1100,283,'#344d50','#839b91',3);K.rect(d,263,156,1074,257,null,'#6d8b81',1);
  K.text(d,'鹈鹕骑行计划',800,236,45,'#f0ead8','center','serif','700');
  K.text(d,'媒 体 见 面 会',800,281,25,'#ccd9cb','center','serif');
  K.text(d,'PRESS BRIEFING',800,315,14,'#9db5a8','center','mono');
  K.line(d,[[470,350],[1130,350]],'#7a9489',1);
  for(let j=0;j<20;j++)K.circle(d,482+j*33.5,350,j===19?4:2.3,j===19?'#d8b96d':'#98ad9c');
  K.text(d,'6,000 YEARS',444,385,12,'#aabbaa','left','mono');K.text(d,'20 STYLES · ONE RIDER',1150,385,12,'#aabbaa','right','mono');
  K.line(d,[[290,426],[290,676]],'#b0b6a6',1);K.line(d,[[1310,426],[1310,676]],'#b0b6a6',1);
  K.rect(d,0,679,1600,95,'#bdc3ad');
  for(let j=0;j<12;j++){let x=j*150-40;K.line(d,[[x,774],[x+84,680]],'rgba(95,112,91,.16)',1);}
  K.line(d,[[0,680],[1600,680]],'#9aa58f',1.2);
  K.rect(d,0,774,1600,66,'#819184');K.rect(d,0,774,1600,9,'#586e65');K.line(d,[[0,774],[1600,774]],'#d5d5bd',2);
  for(let j=0;j<9;j++)K.line(d,[[j*200,787],[j*200,839]],'#6d8276',1);
  K.rect(d,0,840,1600,60,'#d1d2bf');
  K.text(d,'MEDIA',92,59,15,'#60736a','left','mono');K.text(d,'21 / 21',1508,59,15,'#60736a','right','mono');
 }),0,0);
 const arrived=t>=135.08,ongoing=t>=136.35;
 K.circle(c,289,179,3.2,Math.floor(t*2)%2?'#c96a52':'#a95142');K.text(c,'REC',302,183,11,'#c2bfb0','left','mono');
 K.rect(c,1170,452,180,55,'#e4e5d6','#91a18e',1);K.circle(c,1186,476,4,arrived?'#6f917a':'#bd9b59');
 K.text(c,ongoing?'仍在骑行':arrived?'本人已到场':'席位已就绪',1201,483,18,'#536b5e','left','serif');
};
P.pressReporter=function(c,x,y,variant,t=125){
  if((variant===1||variant===3)&&P.hasCharacterAsset&&P.hasCharacterAsset('press_notetaker')){
   const phase=K.clamp((t-(variant===1?130.7:131.4))/3.5);
   P.drawCharacter(c,'press_notetaker',t,{x,y:y+191,height:300,flip:variant===3?-1:1,phase});
   return;
  }
  if((variant===0||variant===2)&&P.hasCharacterAsset&&P.hasCharacterAsset('press_photographer')){
   const start=variant===0?129.9:135.4,phase=K.clamp((t-start)/1.4);
   P.drawCharacter(c,'press_photographer',t,{x,y:y+221,height:333,flip:variant===2?-1:1,phase});
   return;
  }
 const coats=['#38585d','#76806e','#495268','#8b7665'],coat=coats[variant],ink='#344a4c',skin=variant===2?'#b29473':'#cbb18d',light='#ead1a6',hair=['#2e363a','#4d4840','#77756b','#493f3b'][variant];
 const camera=variant%2===0;c.save();c.translate(x,y);c.scale(variant>1?-1:1,1);if(variant===3)c.rotate(-.035);
 // Tailored backs and turned shoulders make these seated people, not icons.
 K.path(c,'M-61 62 L-56 17 Q-53 -2 -29 -10 L-15 -19 L14 -20 Q30 -11 43 1 Q59 16 59 62Z',coat,ink,1.8);
 K.path(c,'M-55 24 Q-45 -1 -25 -7 L-17 12 Q-28 34 -28 62 H-60Z',variant===3?'#726455':'#344f55');
 K.path(c,'M13 -17 Q37 -8 48 10 L44 60 H22 Q22 26 13 -17Z','rgba(231,224,190,.12)');
 K.path(c,'M-16 -22 L-13 -44 L8 -43 L16 -18 L5 -8Z',skin,ink,1.1);
 K.path(c,'M-13 -34 Q-2 -28 10 -34 L12 -21 L-4 -15 L-14 -22Z','#9c8c71');
 K.path(c,'M-26 -10 L-16 -24 L2 -12 L16 -24 L28 -11 L14 7 L3 -8 L-9 10Z','#c9cbb5',ink,1);
 K.path(c,'M-26 -10 L-16 23 L-8 10 M28 -10 L24 19 L14 7 M-24 32 Q-18 40 -19 60 M4 7 L8 62',null,ink,1.1);
 K.path(c,'M-48 13 Q-42 7 -33 5 M-49 23 L-41 28 M32 30 L40 34 M-13 52 L-9 57',null,'rgba(222,224,195,.35)',1);
 for(let j=0;j<3;j++)K.circle(c,10,24+j*15,1.4,'#b8bba5',ink,.5);
 // Three-quarter profile, with a nape, cheek plane and a single readable eye.
 c.save();if(!camera){c.translate(-1,-30);c.rotate(.17);c.translate(1,30);}
 K.path(c,'M-18 -67 Q-9 -78 6 -73 Q22 -69 23 -57 L29 -48 L24 -44 Q26 -33 15 -29 L2 -29 Q-8 -31 -13 -40 L-22 -44Z',skin,ink,1.25);
 K.path(c,'M9 -71 Q23 -62 19 -51 L25 -46 L20 -42 Q20 -33 13 -32 L19 -31 Q28 -34 25 -45 L29 -48 L23 -58 Q21 -69 9 -71Z','#aa9477');
 K.path(c,'M-20 -43 Q-32 -61 -18 -75 Q-4 -85 15 -73 Q24 -69 23 -58 Q15 -61 5 -65 L-2 -52 L-8 -46 L-8 -33 Q-18 -36 -20 -43Z',hair,ink,1.2);
 if(variant===3){K.path(c,'M-26 -58 C-50 -74 -46 -38 -26 -42 Q-35 -53 -26 -58Z',hair,ink,1.2);K.path(c,'M-36 -60 Q-44 -51 -34 -45',null,'#847466',1);}
 K.path(c,'M-21 -66 Q-9 -76 6 -71 M-24 -58 Q-17 -67 -9 -67 M-15 -42 L-16 -35',null,variant===2?'#aba795':'#69685d',1);
 K.ellipse(c,-7,-45,4.3,6.7,skin,ink,.85);K.path(c,'M-8 -48 Q-3 -51 -5 -42',null,'#8b7b63',.75);
 K.path(c,'M12 -55 L19 -54 M13 -50 L17 -50 M19 -37 L23 -38',null,ink,.9);K.circle(c,16,-50,1,ink);
 c.restore();
 if(camera){
  // Elbows, cuffs and palms connect to the camera body on both sides.
  K.path(c,'M-31 -5 Q-45 -9 -39 -29 L-12 -48 L-4 -37 L-22 -21 L-15 -2Z',coat,ink,1.25);
  K.path(c,'M-13 -48 L-4 -52 L4 -39 L-4 -35Z','#d1d4c1',ink,.8);
  K.path(c,'M-5 -51 Q4 -57 12 -53 L17 -46 L10 -40 L3 -41Z',skin,ink,.9);
  K.path(c,'M29 -8 Q42 -8 47 1 L53 -28 L66 -26 L65 10 Q63 25 51 25 Q34 21 24 10Z',coat,ink,1.2);
  K.path(c,'M51 -34 L66 -32 L66 -24 L53 -25Z','#cdd1bf',ink,.8);
  K.path(c,'M52 -34 L51 -43 Q50 -49 55 -50 L60 -46 L67 -46 L71 -41 L66 -32Z',skin,ink,.85);
  K.path(c,'M54 -44 L62 -42 M55 -40 L65 -38 M57 -36 L65 -35',null,'#907a60',.65);
  K.path(c,'M2 -49 Q-14 -18 3 -2 Q20 5 37 -34',null,'#233c41',2.1);
  K.path(c,'M11 -66 H53 L58 -60 V-35 H13 L8 -40 V-60Z','#2a3e47','#859b95',1.3);
  K.rect(c,15,-60,25,18,'#466563','#193037',1);K.rect(c,18,-57,18,12,'#8baca0');K.path(c,'M18 -45 L25 -54 L36 -51 V-45Z','#4f7870');
  K.path(c,'M53 -59 L68 -56 V-38 L53 -35Z','#142f37','#738d86',1);K.ellipse(c,69,-47,4,10,'#214450','#a1b5a8',1);K.ellipse(c,70,-47,2,7,'#0f242d','#607f7d',.5);
  K.rect(c,26,-71,13,6,'#354b4f',ink,.8);K.rect(c,34,-81,18,11,'#c7d1bb','#5c7970',1);K.rect(c,37,-79,12,6,'#f2ebcf');K.circle(c,48,-61,2.2,'#caa86b','#425a55',.6);
  K.line(c,[[19,-38],[33,-38]],'#7b938b',.7);K.circle(c,43,-40,1.3,'#9db6a3');
  K.path(c,'M40 7 L48 11 M-35 -20 L-28 -18',null,'#95a99a',.8);
 }else{
  K.path(c,'M-31 -7 Q-45 -2 -47 17 L-18 24 L-15 13 L-29 7 L-20 -3Z',coat,ink,1.2);
  K.path(c,'M31 -6 Q43 -2 44 13 L12 26 L6 15 L27 5 L21 -4Z',coat,ink,1.2);
  c.save();c.translate(-4,6);c.rotate(-.19);K.path(c,'M-25 -22 H17 L22 27 H-21Z','#dedbc1',ink,1);K.rect(c,-23,-20,41,3,'#526e68');for(let j=0;j<5;j++)K.line(c,[[-17,-10+j*6],[11-(j%2)*7,-10+j*6]],'#8a9d8a',.8);for(let j=0;j<5;j++)K.circle(c,-15+j*7,-20,1.2,'#a7b4a0',ink,.4);c.restore();
  K.path(c,'M-21 14 Q-14 8 -8 14 L-6 19 L-14 24 L-21 22Z',skin,ink,.9);K.path(c,'M8 13 Q7 3 14 4 L20 11 L16 17 L10 21Z',skin,ink,.9);
  K.line(c,[[10,13],[2,-2]],'#304d52',2);K.line(c,[[2,-2],[0,-7]],'#c7b98e',1.1);K.path(c,'M11 7 L16 11 M-17 16 L-10 17',null,'#947e63',.7);
 }
 K.path(c,'M-65 58 Q-7 42 63 57 L66 64 H-65Z','#344c4e','#6b8278',1.5);
 c.restore();
};
P.pressForeground=function(c,t){
 // An empty chair stays in front of the passing rider, with both feet on stage.
 K.line(c,[[732,602],[715,774]],'#65756a',7);K.line(c,[[868,602],[884,774]],'#65756a',7);
 K.path(c,'M716 463 Q716 446 736 446 H864 Q884 446 884 463 V604 Q884 617 866 617 H734 Q716 617 716 604Z','#75877d','#425e58',2.5);
 K.path(c,'M729 461 Q729 457 740 457 H860 Q871 457 871 469 V597 Q871 606 861 606 H741 Q729 606 729 594Z',null,'#9dac97',1);
 K.path(c,'M713 612 Q800 602 887 612 L899 632 H701Z','#647c72','#425e58',2.5);
 // The table, stems and name card occlude the bicycle in a stable foreground layer.
 K.path(c,'M294 601 H1306 L1330 620 H270Z','#d4cab0','#7b846f',2);
 K.rect(c,278,620,1044,123,'#a6b39e','#6d806e',2);K.rect(c,278,620,1044,12,'#84977f');
 K.rect(c,291,743,14,31,'#607969');K.rect(c,1295,743,14,31,'#607969');K.line(c,[[305,743],[1295,743]],'#c6cfb6',1.2);
 for(let j=0;j<12;j++)K.line(c,[[305+j*84,641],[305+j*84,733]],'rgba(101,126,103,.16)',.8);
 const mics=[{x:478,y:569,a:-.28,col:'#687f72'},{x:580,y:545,a:.18,col:'#b9ad83'},{x:687,y:565,a:-.08,col:'#647c79'},{x:911,y:550,a:-.18,col:'#98775b'},{x:1011,y:567,a:.2,col:'#566b71'},{x:1111,y:578,a:-.2,col:'#8a967d'}];
 for(let j=0;j<mics.length;j++){const m=mics[j];K.ellipse(c,m.x+10,604,21,5,'#596f62','#425d53',1);K.path(c,`M${m.x+10} 602 Q${m.x+16} ${m.y+20} ${m.x} ${m.y}`,null,'#425a51',3);c.save();c.translate(m.x,m.y);c.rotate(m.a);K.path(c,'M-18 -8 Q-22 -8 -22 0 Q-22 8 -18 8 H17 Q23 8 23 0 Q23 -8 17 -8Z','#50655c','#344f47',1.2);for(let k=0;k<4;k++)K.line(c,[[-14+k*5,-6],[-14+k*5,6]],'#83978a',.7);K.rect(c,-7,8,22,15,m.col,'#52685b',1);c.restore();}
 K.path(c,'M659 644 H941 L949 705 H651Z','#eee8d4','#7b8a74',1.5);K.line(c,[[659,644],[941,644]],'#fff6de',2);
 K.text(c,'鹈鹕（本人）',800,684,30,'#3b534a','center','serif','700');
 K.rect(c,1003,661,101,29,'#849b83','#637c66',1);K.circle(c,1017,675,3,'#d1d6ad');K.text(c,'录音中',1060,682,15,'#edf0d7','center','serif');
 P.pressReporter(c,153,857,0,t);P.pressReporter(c,435,883,1,t);P.pressReporter(c,1090,883,3,t);P.pressReporter(c,1417,858,2,t);
 // The fixed press camera stands BETWEEN reporters, never through a handheld lens.
 K.line(c,[[318,815],[298,900]],'#587267',3);K.line(c,[[318,815],[341,900]],'#587267',3);K.line(c,[[318,815],[320,900]],'#587267',2);
 K.rect(c,291,780,57,35,'#4b6860','#81988c',1.5);K.rect(c,345,788,17,19,'#344f48');K.rect(c,303,771,19,9,'#c7cfb7','#5f7d6e',1);K.circle(c,297,790,2,'#c67052');
 const a=Math.max(0,...P.pressFlashTimes.map(mark=>1-Math.abs(t-mark)/.095));
 if(a>0){
  const k=P.pressFlashTimes.reduce((best,mark,j)=>Math.abs(t-mark)<Math.abs(t-P.pressFlashTimes[best])?j:best,0),pos=P.pressFlashPoint?P.pressFlashPoint(t,k):[[226,777],[1456,818],[191,818],[226,777]][k];
  c.save();c.globalAlpha=a;K.star(c,pos[0],pos[1],22,'#fff9dd');K.circle(c,pos[0],pos[1],7,'#fffef2');c.restore();
  K.rect(c,0,0,1600,900,`rgba(255,253,235,${a*.29})`);
 }
};
P.drawPressScene=function(c,t,withRider=true){
 P.pressBackground(c,t);
 if(withRider&&t>=134.75&&t<136.65){
  const p=Object.assign(P.pressPose(t),P.motionAt(t));P.drawRider(c,t,p);
  if(P.drawCarriedHeart)P.drawCarriedHeart(c,p);
  if(t>136.1&&t<136.5){const u=(t-136.1)/.4;c.save();c.globalAlpha=1-u;for(let j=0;j<2;j++){c.beginPath();c.arc(p.x+125*p.scale,p.y-135*p.scale,18+u*36+j*11,-.9,.45);c.strokeStyle='#a38c56';c.lineWidth=1.5;c.stroke();}c.restore();}
 }
 P.pressForeground(c,t);
};
P.overviewCell=function(i){const w=202,h=w*9/16;return{x:51+(i%7)*216,y:204+Math.floor(i/7)*184,w,h};};
P.gallery=function(c,t){
 P.makeThumbs();c.drawImage(K.cached('overview-r4-paper',d=>{K.grain(d,'#eae4d5','rgba(86,68,43,.05)',2500);K.text(d,'二十种画法，同一段路。',800,85,40,'#3e463c','center','serif','700');K.text(d,'每一幅都准备好了。还有一个席位。',800,132,22,'#7a7d69','center','serif');K.line(d,[[52,169],[1548,169]],'#bdbea8',1);K.text(d,'截至目前，人类共提交了 20 份答卷。',800,839,24,'#737965','center','serif');}),0,0);
 for(let i=0;i<21;i++){
  const q=P.overviewCell(i);K.rect(c,q.x-3,q.y-3,q.w+6,q.h+6,'#d5d4be','#8e9a82',1.1);
  if(i===20){c.save();c.beginPath();c.rect(q.x,q.y,q.w,q.h);c.clip();c.translate(q.x,q.y);c.scale(q.w/1600,q.h/900);P.drawPressScene(c,t,true);c.restore();}
  else{const thumb=i===19?K.cached('closing-long-scroll-picture-r2',d=>{const v=P.storyCamera(125);d.save();d.translate(800+v.dx,450+v.dy);d.scale(v.z,v.z);d.translate(-v.fx,-v.fy);P.renderLongScroll(d,125);d.restore();}):P.thumbs[i];c.drawImage(thumb,q.x,q.y,q.w,q.h);}
  K.text(c,String(i+1).padStart(2,'0'),q.x,q.y+q.h+25,12,'#7d8872','left','mono');K.text(c,i===20?'发布会 · 空席':P.scenes[i].title,q.x+31,q.y+q.h+25,16,'#4e5e4c','left','serif');
 }
};
P.outro=function(c,t){
 // The entire pull-back and push-in use one gallery coordinate system.
 // The press scene is never swapped for a differently framed full-screen copy.
 const absolute=125+t,a=P.overviewCell(19),b=P.overviewCell(20),zoom=1600/a.w;
 let cx=800,cy=450,z=1;
 if(t<1.9){const u=K.smoother(t/1.9);cx=K.lerp(a.x+a.w/2,800,u);cy=K.lerp(a.y+a.h/2,450,u);z=Math.exp(K.lerp(Math.log(zoom),0,u));}
 else if(t>2.7){const u=K.smoother((t-2.7)/3.3);cx=K.lerp(800,b.x+b.w/2,u);cy=K.lerp(450,b.y+b.h/2,u);z=Math.exp(K.lerp(0,Math.log(zoom),u));}
 c.save();c.translate(800,450);c.scale(z,z);c.translate(-cx,-cy);P.gallery(c,absolute);c.restore();
 if(t>=6.6){c.save();c.globalAlpha=K.ease((t-6.6)/.45);K.rect(c,270,839,1060,45,'rgba(233,230,213,.94)');K.text(c,'鹈鹕本人对此尚未发表评论。',800,872,27,'#3d544a','center','serif');c.restore();}
};
P.storyCamera=function(t){
 let z=1,fx=800,fy=450,dx=0,dy=0;
 if(t>=29&&t<35){
  const local=t-29,a=K.smoother((local-1.55)/1.15)*(1-K.smoother((local-3.45)/1.20));
  z=1+1.8*a;fx=K.lerp(800,760,a);fy=K.lerp(450,625,a);
 }
 // A tiny lens response marks an actual threshold; it never changes the rig.
 if(t>=4.75&&t<=125){const boundary=5+Math.round((t-5)/6)*6,near=Math.abs(t-boundary);z*=1+.012*Math.max(0,1-near/.25)**2;}
 if(t>79.35&&t<79.73){const u=(t-79.35)/.38,a=Math.sin(Math.PI*u)*3.1;dx=Math.sin(u*27)*a;dy=Math.cos(u*31)*a*.45;}
 return{z,fx,fy,dx,dy};
};
P.renderAt=function(c,t){
 t=K.clamp(t,0,(P.storyDuration||P.duration)-.001);c.save();c.setTransform(1,0,0,1,0,0);c.clearRect(0,0,c.canvas.width,c.canvas.height);c.scale(c.canvas.width/1600,c.canvas.height/900);
 c.beginPath();c.rect(0,0,1600,900);c.clip();
 if(t>=125)P.outro(c,t-125);else{const v=P.storyCamera(t);c.save();c.translate(800+v.dx,450+v.dy);c.scale(v.z,v.z);c.translate(-v.fx,-v.fy);P.renderLongScroll(c,t);c.restore();}
 c.restore();
};
