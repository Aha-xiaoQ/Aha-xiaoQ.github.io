/* Historical rooms, R7. The chapter clock belongs to the R6 director. These
   two passes keep the road and the actual bike rig in front of the wall art
   and behind nearby objects. All marks are native paths, seeded locally. */
(()=>{
 'use strict';
 const D=P.finalDirector,S=K.smoother,wash=K.gradient,R=K.rnd,TAU=2*Math.PI;
 const pt=(c,d,f,s=null,w=1)=>K.path(c,d,f,s,w);
 const st=(c,d,s,w=1)=>pt(c,d,null,s,w);
 function pose(c,x,y,s,r,fn){c.save();c.translate(x,y);c.scale(s,s);c.rotate(r);fn(c);c.restore()}
 function baked(c,key,paint){c.drawImage(K.cached('historical-r7-'+key,paint),0,0)}
 function clip(c,d,fn){c.save();c.clip(new Path2D(d));fn();c.restore()}
 const soft=(x,a,b,d,e)=>S((x-a)/(b-a))*(1-S((x-d)/(e-d)));
 function gazelle(c,x,y,s,tilt){pose(c,x,y,s,0,g=>{
  const ink='#87462e',red='#a35938';pt(g,'M-75 -23 Q-81 -13 -83 -8 L-89 -21 Q-89 -27 -78 -30 Q-57 -41 -27 -38 Q1 -39 18 -45 L34 -63 Q45 -68 45 -57 L23 -29 Q15 -14 -11 -12 Q-32 -8 -49 -13 L-61 -4 L-71 -4Z',red);
  st(g,'M-59 -11 L-69 11 L-86 33 M-47 -13 L-53 13 L-44 34 M10 -20 L17 6 L35 30 M22 -26 L34 -3 L55 10',ink,4);
  pose(g,38,-58,1,tilt,h=>{pt(h,'M-7 3 Q1 -12 14 -12 L24 -8 L46 -4 L51 1 L29 4 L10 5 L-2 12Z',ink);
   st(h,'M7 -7 Q-6 -21 -3 -31 Q1 -45 -13 -56 M12 -9 Q9 -28 16 -39 Q20 -48 13 -61',ink,3);pt(h,'M5 -5 L-11 -18 L-9 -9Z',ink);K.circle(h,20,-4,1.6,'#e5ba85')});
 })}
 function sandstone(c){
  const ld=wash(c,[0,0],[920,900],[[0,'rgba(48,20,12,.25)'],[.4,'rgba(119,63,29,.01)'],[.7,'rgba(255,210,143,.055)'],[1,'rgba(69,29,15,.18)']]);K.rect(c,0,0,1600,900,ld);
  for(let i=0;i<42;i++){let x=R(i+9)*1840-120,y=R(i+327)*850,w=40+124*R(i+478),h=4+R(i+192)*13;
   let d='M'+x+' '+y+' q'+w*.22+' '+(-h)+' '+w*.45+' '+(-h*.62)+' l'+w*.3+' '+(-h*.87)+' l'+w*.25+' '+h*.08+' q'+(-w*.17)+' '+h*.63+' '+(-w*.39)+' '+h*.68+' l'+(-w*.26)+' '+h+'Z';
   pt(c,d,'rgba(125,70,38,.115)');st(c,'M'+x+' '+y+' q'+w*.11+' '+(-h*.5)+' '+w*.28+' '+(-h*.63),'rgba(255,221,165,.32)',.93)}
  // Weathering follows fracture fields instead of applying white noise to
  // the whole lens; several seams pass behind the older painted animals.
  for(let j=0;j<4;j++){let x=154+j*392,y=63+R(j+18)*135,pts=[[x,y]];for(let n=0;n<13;n++){x+=R(n+j*77+8)*32-14;y+=18+R(j+n*99)*24;pts.push([x,y]);if(n%4===1)st(c,'M'+x+' '+y+' l-12 8 -3 13 -8 4','rgba(93,49,31,.27)',1)}K.line(c,pts,'rgba(83,48,29,.23)',1.4);K.line(c,pts.map(([x,y])=>[x+2.6,y+1.4]),'rgba(255,207,145,.31)',1)}
  // A continuous palaeo-herd runs along the natural lip of the rock.
  for(let i=0;i<6;i++){let x=465+i*106,y=266-27*Math.sin(i*.72);c.save();c.globalAlpha=.63-i*.045;gazelle(c,x,y,.68+i%3*.12,(i%3-1)*.15);c.restore()}
  for(let n=0;n<11500;n++){let x=R(n*3+807)*1600,y=R(n*3+808)*900,a=R(n*3+809);
    c.fillStyle=a>.63?'rgba(255,223,170,.17)':'rgba(91,44,23,.13)';c.fillRect(x,y,.65+(a*a)*3,1.1+a)}
 }
 function sahara(c,l,p,front){if(!front){baked(c,'rock-deposits',sandstone);let watch=S((p.x-620)/260)*(1-S((p.x-1210)/270));gazelle(c,970,443,1.19,-.13-.46*watch);gazelle(c,1065,460,.56,.24-.28*watch)}}
 function egypt(c,l,p,front){if(front)return;
  baked(c,'plaster',g=>{
   const grid='M485 319 L1027 319 L1027 746 L485 746Z';clip(g,grid,()=>{
    for(let j=0;j<16;j++){let x=476+j*39;st(g,`M${x} 312 q-3 226 2 439`,'rgba(159,64,40,.20)',1.15)}
    for(let j=0;j<12;j++){let y=324+j*39;st(g,`M480 ${y} q315 -2 555 1`,'rgba(159,64,40,.18)',1.05)}});
   // Trowel drag and granular losses; no fictitious text or glyphs.
   for(let j=0;j<400;j++){let x=R(j*19+73)*1580,y=158+R(j*13+78)*627;st(g,`M${x} ${y} q${3+3*R(j)} -1 ${3+9*R(j+1)} -0.8`,'rgba(139,114,71,.17)',.65)}
  });
  const v=soft(l,1.6,2.2,3.61,4.2);if(v>0){c.save();c.globalAlpha=v;let pend=Math.sin((l-1.6)*4.2)*11*Math.exp(-1.3*Math.max(0,l-1.6)),x=493+pend;
   st(c,`M493 318 L${x} 695`,'#79523c',1.9);pt(c,`M${x-5} 695 Q${x} 682 ${x+5} 695 L${x+7} 705 L${x} 719 L${x-7} 705Z`,'#8d7452','#654e38',1);c.restore()}
 }
 // Lift one corner of the upper rubbing. The relief below is made from the
 // very same generated incision field: subtract horizontally displaced
 // luminances once, to light the carved sidewalls from the upper left.
 // In particular the horse cannot jump to a different position on peeling.
 let relief;
 function lift(c,l){let u=soft(l,1.25,2.55,3.72,5.22);if(u<.002)return;
  if(!relief){const source=P.cache.get('h-han');if(!source)return;
   const cv=P.makeCanvas(692,298),g=cv.getContext('2d');g.drawImage(source,387,184,692,298,0,0,692,298);
   const im=g.getImageData(0,0,692,298),a=im.data,v=new Uint8Array(692*298);for(let j=0;j<v.length;j++)v[j]=a[j*4+1];
   for(let j=0;j<v.length;j++){const x=j%692,y=Math.floor(j/692),idx=j*4;
    let s=v[j],edge=(v[Math.max(0,j-693)]-v[Math.min(v.length-1,j+693)])*.31,bed=8*Math.sin(x*.012+y*.046)+4*Math.sin(x*.032-y*.018),n=3*Math.sin(j*27.334);
    a[idx]=154+s*.061+edge+bed+n;a[idx+1]=148+s*.057+edge+bed+n;a[idx+2]=124+s*.06+edge+bed+n;a[idx+3]=255;
   }g.putImageData(im,0,0);relief=cv;
  }
  let k=1050,y=192,w=u*397,h=u*212,d=`M${k} ${y} h${-w} Q${k-w*.53} ${y+h*.63} ${k} ${y+h}Z`;
  clip(c,d,()=>{c.drawImage(relief,387,184);let grad=c.createLinearGradient(k-w*.7,y+h*.85,k,y);grad.addColorStop(0,'rgba(38,35,27,.42)');grad.addColorStop(.47,'rgba(61,56,38,.06)');grad.addColorStop(1,'rgba(214,207,172,.18)');K.rect(c,k-w,y,w,h,grad)});
  let a=k-w,b=y+h,lip=Math.min(26,w*.14);
  pt(c,`M${a} ${y} Q${k-w*.47} ${y+h*.70} ${k} ${b} Q${k-w*.36} ${b+lip} ${a+lip*.48} ${y+lip*.41}Z`,'#c8c2a5','#777863',1);
  st(c,`M${a+2} ${y+1} Q${k-w*.47} ${y+h*.70} ${k} ${b}`,'#e1ddbf',2);
 }
 function han(c,l,p,front){if(front)return;baked(c,'stone-pore',g=>{
  // Depressions reject ink along the bedding plane; scraped tips stay white.
  for(let j=0;j<82;j++){let x=R(j*37+85)*1600,y=192+R(j*91+88)*593;let w=4+R(j+54)*29;
   st(g,`M${x} ${y} l${w*.42} -1.7 l${w*.27} .7 l${w*.3} -1.1`,'rgba(223,220,191,.32)',.8)}
  for(let i=0;i<16500;i++){let x=R(i*3+51)*1535+32,y=184+R(i*3+52)*603,cluster=.5+.5*Math.sin(x/49+y/22)*Math.sin(x/21-y/63),v=R(i*3+53);if(v<cluster*.58)continue;g.fillStyle=v>.88?'rgba(229,224,197,.32)':'rgba(216,214,188,.12)';g.fillRect(x,y,.5+v*1.8,.6+v)}
  // Along the lower margin one stone edge has lost its smooth face.
  pt(g,'M75 785 L147 782 L184 790 L334 788 L359 794 L431 790 L401 800 L281 802 L253 796 L136 801Z','#333c33');
  st(g,'M75 785 L147 782 L184 790 L334 788 L359 794 L431 790','rgba(219,220,193,.56)',1)});
  lift(c,l);
  // The anonymous visitor leaves a shallow, broken tyre impression which
  // slowly closes into the reserved decoration, without a graphic label.
  const xfront=p.x-130*(p.scale||1);c.save();c.beginPath();c.rect(35,740,Math.max(0,Math.min(1495,xfront-35)),45);c.clip();for(let j=0;j<64;j++){let x=52+j*24;st(c,`M${x} 751 l7 -2 5 1`,'rgba(229,225,197,.62)',1.6)}c.restore();
 }
 function willow(c,l,p,front){if(!front)return;
  // Brush starts on a twig, narrows, hesitates at a joint, and lifts on the
  // final leaf. The pulse from the passing wheel travels OUT along the twig.
  const speed=K.clamp((p.x-390)/1050),gust=Math.sin(speed*Math.PI),X=200-(p.x-800)*.085;
  c.save();c.translate(X,0);
  pt(c,'M-305 176 Q-174 154 -118 179 Q-45 199 13 190 Q98 177 171 139 Q92 188 13 196 Q-81 210 -133 184 Q-186 166 -305 185Z','#726e58');
  for(let j=0;j<17;j++){let u=j/16,x=-159+u*302,y=175+26*Math.sin(u*3.55),len=142+113*R(j+55),a=[];
   for(let n=0;n<=12;n++){let v=n/12,xn=x+31*v+58*v*v+Math.sin(l*1.65-v*4+j*.79)*(4+9*gust)*v*v+72*gust*v*v,yn=y+len*v;
    a.push([xn,yn]);if(n>1&&n%2===j%2){let sign=n%4<2?-1:1;
     pt(c,`M${xn} ${yn} q${sign*12} -3 ${sign*20+8} 21 q${-sign*10} -6 ${-sign*20-8} -21Z`,j%3?'rgba(108,115,82,.52)':'rgba(120,125,93,.38)')}}K.line(c,a,'rgba(87,92,65,.72)',1.25)}
  c.restore();
 }
 const summit='M656 718 Q677 679 693 650 L690 618 L711 586 L709 551 L735 530 L747 487 L743 452 L766 423 L775 363 L767 330 L778 285 L773 244 L791 213 L798 174 L813 153 L802 111 L829 94 L844 60 L872 68 L900 42 L931 55 L947 40 L974 58 L999 46 L1033 72 L1067 66 L1089 98 L1095 139 L1117 170 L1128 228 L1119 285 L1141 334 L1131 395 L1160 448 L1168 503 L1190 561 L1217 608 L1210 657 L1240 718Z';
 function crags(g){clip(g,summit,()=>{
   // 斧劈皴 in narrow broken wedges: direction changes by cliff face. Draw
   // on the same cached massif translation as the R6 substrate.
   for(let i=0;i<3700;i++){let x=675+R(i*3+1)*560,y=27+R(i*3+2)*620,rr=R(i*3+3);
    if(x>991&&x<1033&&y>184&&y<578)continue;
    let seam=Math.abs(Math.sin(x*.023+Math.sin(y*.017)*.8+y*.004)),dx=x>989?6+14*rr:-7-10*rr,h=5+rr*18;
    if(seam>.78){g.fillStyle='rgba(222,217,183,.20)';g.beginPath();g.moveTo(x,y);g.lineTo(x+dx*.56,y+h*.83);g.lineTo(x+dx*.4+rr*2.4,y+h*.64);g.fill()}
    else if(seam<.68){g.fillStyle=seam<.31?'rgba(26,37,31,.24)':'rgba(29,39,31,.12)';g.beginPath();g.moveTo(x,y);g.lineTo(x+dx,y+h);g.lineTo(x+dx+rr*3,y+h*.76);g.lineTo(x+2,y+h*.16);g.fill()}
   }
   for(let i=0;i<72;i++){let x=731+R(i*2+870)*431,y=69+R(i*2+871)*442;let h=5+R(i+870)*20;
    st(g,`M${x} ${y} q-2 ${h*.4} -7 ${h} l1 ${h*.6}`,'rgba(30,40,33,.29)',1.1)}
  });
  // The R6 foothills disappear into paper mist; preserve the same depth.
  g.save();g.globalCompositeOperation='destination-in';K.rect(g,0,0,1600,900,wash(g,[0,0],[0,900],[[0,'#000'],[.60,'#000'],[.70,'rgba(0,0,0,.12)'],[.742,'rgba(0,0,0,0)'],[1,'rgba(0,0,0,0)']]));g.restore()}
 function song(c,l,p,front){if(front)return;
  c.save();c.translate((p.x-800)*.42,0);baked(c,'crag-ink',crags);c.restore();
  // A flock passes behind the main cliff; we clip it away against the very
  // same profile, not a dissolve. Its scale gives the mountain a measure.
  c.save();let z=new Path2D();z.rect(-1000,-100,3700,790);z.addPath(new Path2D(summit),new DOMMatrix().translate((p.x-800)*.42,0));c.clip(z,'evenodd');
  for(let j=0;j<7;j++){let v=l*34-60,x=685+v-j*21,y=257+j*5-22*Math.sin(l*.68),flap=Math.sin(l*6.8-j*.58);
   st(c,`M${x-6} ${y-2-flap*3} q3 0 6 ${2+flap*3} q3 -3 6 ${-2-flap*3}`,'#666854',1.28)}c.restore();
 }
 function merchant(c,x,y,s,angle,variant){pose(c,x,y,s,0,g=>{
  let ink='#625644',robe=variant?'#8d9b80':'#a98161';pt(g,'M-11 -36 Q-5 -45 4 -42 Q13 -40 13 -28 L19 -3 Q9 0 -14 -3Z',robe,ink,1.3);st(g,'M-6 -3 l-3 5 -7 1 M9 -3 l3 5 7 1',ink,2);st(g,'M-6 -33 q4 9 12 15 l17 -4',ink,2.3);
  pose(g,1,-49,1,angle,h=>{pt(h,'M-7 -10 Q0 -16 8 -10 L10 -5 L15 -1 L10 1 Q8 10 1 10 Q-8 7 -7 -10Z','#c29c7b',ink,1);pt(h,'M-12 -8 Q-6 -17 3 -18 Q10 -16 12 -9 L17 -7 L-15 -6Z','#5c6050');K.circle(h,7,-4,1.15,ink)});
 })}
 function riverside(c,l,p,front){if(!front){
  for(let j=0;j<5;j++){let x=360+j*63,y=P.scenes[5].ground(x),tic=soft(l,2.16+j*.085,2.52+j*.09,3.68,4.35);merchant(c,x,y-1,.65+j%2*.09,-.12-.52*tic,j%2)}
  return}
  // Real oversailing roof in the very near corner; the silk fringe shows
  // wind first. Keep the leaping fish and the entire arch in open space.
  c.save();c.translate((800-p.x)*.11,0);pt(c,'M-80 72 Q38 121 169 126 L233 138 Q147 147 41 143 L-80 116Z','#635f4f','#57554c',1.6);
  for(let i=0;i<12;i++){let x=-6+i*17,y=129+8*Math.sin(i/8);st(c,`M${x-12} ${y-20} q6 16 17 18 l11 -1`,'#b2a788',1.3)}
  const y=157,x=140;st(c,'M139 133 q0 15 1 25','#665644',1.6);
  pose(c,x,y,1,Math.sin(l*1.75)*.055,h=>{pt(h,'M-12 0 Q-29 12 -23 43 Q-20 51 -11 54 L12 54 Q24 47 25 26 Q25 6 11 0Z','#b67750','#735c43',1.3);
   for(let j=0;j<5;j++){let x=-10+j*5;st(h,`M${x} 1 Q${x*1.85} 27 ${x} 53`,'#996644',1)}
   K.rect(h,-13,-1,26,3,'#6a6048');K.rect(h,-13,53,26,3,'#6a6048');st(h,'M0 56 v14 m-4 0 l-1 7 m6 -8 l1 7','#a16d42',1.7)});
  c.restore();
 }
 function codex(c,l,p,front){if(front)return;
  baked(c,'amatl',g=>{
   // The fibres are long, joined strands of a pounded sheet. Patches of
   // missing lime ground reveal a warm, uneven inner layer at the hinges.
   for(const [fold,dr] of [[426,1],[1186,-1]]){const gr=wash(g,[fold-13,0],[fold+14,0],[[0,'rgba(89,57,33,0)'],[.37,'rgba(97,55,32,.08)'],[.5,'rgba(100,63,32,.23)'],[.68,'rgba(251,229,181,.35)'],[1,'rgba(239,214,166,0)']]);K.rect(g,fold-13,192,27,558,gr);
    for(let n=0;n<58;n++){let y=210+n*9.1+R(n)*4,x=fold+(R(n+103)-.5)*9;
     st(g,`M${x} ${y} q${dr*(5+R(n+42)*8)} 4 ${dr*(4+R(n+32)*13)} 11`,'rgba(121,78,47,.35)',.9)}}
  });
  // Fold-cast shadow breathes as the bicycle approaches each hinge.
  for(const x of [426,1186]){let q=Math.exp(-(((p.x-x)/143)**2));if(q<.005)continue;let w=q*34;
   K.rect(c,x,278,w,475,wash(c,[x,0],[x+w,0],[[0,`rgba(98,63,37,${q*.16})`],[1,'rgba(98,63,37,0)']]))}
 }
 function peacock(c,x,y,s,spread,dir){c.save();c.translate(x,y);c.scale(s*dir,s);
  // Feathers fan about the same articulated tail base, eyes point radially
  // outwards. The asymmetry travels from the tail to its painted twin.
  for(let j=0;j<13;j++){let u=j/12,ang=-2.78+u*.55+spread*(u*1.93-.38),len=86-u*10+12*Math.sin(Math.PI*u);
   c.save();c.translate(-14,-23);c.rotate(ang+Math.PI/2);pt(c,`M0 0 Q-8 -23 -6 ${-len+8} Q-5 ${-len-5} 0 ${-len-9} Q8 ${-len+1} 5 ${-len+15} Q6 -17 0 0Z`,j%2?'#688975':'#486d61','#3b6059',.85);
   st(c,`M0 -3 Q2 -36 0 ${-len+1}`,'#c2ac6d',.8);K.ellipse(c,0,-len+3,3.8,5.4,'#c1ac60');K.ellipse(c,0,-len+2,2.4,3.3,'#426b7c');c.restore()}
  pt(c,'M-26 -24 Q-13 -37 7 -28 Q16 -25 17 -41 Q17 -58 25 -58 Q32 -57 31 -51 Q29 -47 26 -50 Q25 -38 27 -29 Q31 -12 12 -8 Q-4 -6 -26 -24Z','#446971','#405955',1.5);
  pt(c,'M-22 -27 Q-3 -31 9 -22 Q-1 -10 -17 -17Z','#70876a','#3f665d',.9);
  pt(c,'M29 -56 L40 -53 L30 -51Z','#b89655');K.circle(c,27,-55,1.2,'#f0deab');st(c,'M23 -58 l-4 -7 m6 6 l1 -8 m1 8 l5 -5 M-2 -10 l-4 12 -7 1 M11 -9 l3 11 6 -1','#796f4b',1.25);c.restore()}
 function garden(c,l,p,front){if(front)return;peacock(c,409,673,.72,soft(l,1.35,2.6,3.95,5.25),1);peacock(c,1167,673,.72,soft(l,2.66,3.84,4.67,5.87),-1)}
 function quiet(c,l,p,front){if(front)return;
  // A single water strider listens to a drop, then skates away. No texture
  // field here: silence means preserving actual untouched paper.
  let leap=S((l-3.20)/.49),settle=S((l-3.78)/1.24),x=414+69*leap+17*settle,y=791-7*leap;
  c.save();c.globalAlpha=.78;pose(c,x,y,1,0,g=>{K.ellipse(g,0,0,5.4,1.6,'#4e5647');for(let i of [-1,1]){st(g,`M-2 0 l-5 ${3*i} -10 ${2*i} M1 0 l7 ${2*i} 11 ${-3*i}`,'#636b56',.9)}});c.restore();
  if(leap>.001&&settle<.99){c.save();c.globalAlpha=(1-settle)*.43;st(c,`M${x-10} ${y+1} Q${x-29} ${y+2} ${x-44} ${y-2} M${x-11} ${y+4} Q${x-32} ${y+7} ${x-46} ${y+6}`,'#75836e',.85);c.restore()}
 }
 function leather(c,l,p,front){if(front)return;
  // Cast pool of light on the kelir: a broad change of feathery edge and
  // an articulated shadow of the operator just below the stage apron.
  let swing=soft(l,1.55,2.92,3.85,5.0),x=789+66*swing,y=476;
  let g=c.createRadialGradient(x,y,44,x,y,455);g.addColorStop(0,'rgba(255,235,175,.27)');g.addColorStop(.5,'rgba(254,215,144,.13)');g.addColorStop(1,'rgba(255,210,124,0)');K.rect(c,186,187,1230,564,g);
  const xx=825+31*swing;pose(c,xx,764,1,-.04-.13*swing,h=>{pt(h,'M-67 4 L-51 -18 Q-45 -24 -35 -33 L-19 -54 Q-16 -60 -12 -57 Q-10 -55 -13 -50 L-20 -37 L-4 -52 Q1 -57 4 -54 Q6 -50 2 -46 L-5 -37 L11 -49 Q15 -54 18 -50 Q20 -47 16 -42 L5 -29 L20 -36 Q25 -38 26 -34 Q27 -30 23 -28 L8 -14 Q3 -7 -1 2Z','rgba(94,57,30,.40)');st(h,'M-8 -45 L23 -127','rgba(104,63,32,.40)',3.2)});
 }
 const rooms=[sahara,egypt,han,willow,song,riverside,codex,garden,quiet,leather],prev=P.storyDetails;
 P.storyDetails=function(c,i,l,t,p,front){prev.call(this,c,i,l,t,p,front);if(i>=0&&i<rooms.length&&p){c.save();try{rooms[i](c,l,p,front)}finally{c.restore()}}};
 P.historicalR7={scenes:rooms.length,revision:'material-reactions-1'};
})();
