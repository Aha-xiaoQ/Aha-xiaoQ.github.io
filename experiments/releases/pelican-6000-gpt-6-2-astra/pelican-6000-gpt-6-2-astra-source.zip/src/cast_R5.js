/* R5 original procedural cast portraits; user-defined fictional characterisations. */
(()=>{const I={};
 I.cast={fish:{name:'大肥鱼',color:'#4289b6',bg:'#cfeaf3'},gpt:{name:'GPT',color:'#7583b9',bg:'#e7e9f6'},claude:{name:'Claude',color:'#c27b42',bg:'#f4e4cf'},doubao:{name:'豆包',color:'#c56876',bg:'#f5e2dd'}};
 I.portraitEyes=function(c,iris,ink='#413947',calm=false,blink=false){
  for(const x of [-12,12]){
   if(blink){K.path(c,'M'+(x-6.5)+' 5 Q'+x+' 10 '+(x+6.5)+' 5',null,ink,1.4);K.path(c,'M'+(x-4.7)+' -5 Q'+x+' -7 '+(x+4.7)+' -5.4',null,ink,.85);continue;}
   K.path(c,'M'+(x-6.4)+' 5 Q'+x+' '+(calm?'0':'-1.4')+' '+(x+6.4)+' 5 Q'+x+' 13 '+(x-6.4)+' 5Z','#fffaf3',ink,.65);
   K.ellipse(c,x,6.1,3.7,4.9,iris,ink,.45);K.ellipse(c,x,5.7,1.8,3.1,ink);K.circle(c,x-1.3,3.2,1.4,'#fff');K.circle(c,x+1.5,8.2,.6,'#f3f8ff');
   K.path(c,'M'+(x-6.3)+' 4.6 Q'+x+' '+(calm?'-.1':'-1.9')+' '+(x+6.5)+' 4.6',null,ink,1.35);
   const sign=x<0?-1:1;K.line(c,[[x+sign*5.4,4],[x+sign*7.8,1.8]],ink,.85);
   K.path(c,'M'+(x-4.7)+' -5 Q'+x+' -7 '+(x+4.7)+' -5.4',null,ink,.85);
  }
  K.ellipse(c,-20,15,5.2,2.3,'rgba(235,143,151,.22)');K.ellipse(c,20,15,5.2,2.3,'rgba(235,143,151,.22)');
  K.path(c,'M0 12 l-1 3 2 .4',null,'#cfa19b',.65);
 };
 I.portraitFace=function(c){
  K.path(c,'M-25 -17 Q-29 0 -24 15 Q-20 26 0 32 Q20 26 24 15 Q29 0 25 -17Z','#fff0df','#ad7d82',.8);
  K.path(c,'M-7 28 L-7 39 Q0 43 7 39 L7 28','#f5d8c7','#c6948b',.6);
 };
 I.castAvatar=function(c,x,y,size,id){
  I.active=id;const a=I.cast[id]||I.cast.fish,clock=Number.isFinite(P.castClock)?P.castClock:(P.sceneContext?P.sceneContext.local:0),born={fish:2.48,gpt:2.04,claude:3.85,doubao:3.18}[id]||0,blink=clock>=born&&clock<born+(id==='doubao'?.27:.11);c.save();c.beginPath();c.roundRect(x,y,size,size,Math.max(4,size*.12));c.clip();
  K.rect(c,x,y,size,size,K.gradient(c,[x,y],[x+size,y+size],[[0,'#fffdf5'],[.15,a.bg],[1,a.bg]]));
  c.translate(x+size*.5,y+size*.55);c.scale(size/120,size/120);
  K.circle(c,0,-3,46,'rgba(255,255,255,.28)');K.circle(c,36,-32,3,'rgba(255,255,255,.7)');K.circle(c,-37,34,2,'rgba(255,255,255,.7)');
  if(id==='fish'){
   const hair=K.gradient(c,[0,-43],[0,54],[[0,'#284879'],[.5,'#3c6dae'],[1,'#7fc4d6']]);
   K.path(c,'M-39 53 Q-47 34 -41 8 Q-44 -17 -29 -36 Q-13 -50 10 -44 Q37 -45 42 -15 Q47 9 39 30 L47 50 Q26 57 19 44 L-23 46Z',hair,'#254375',1.3);
   K.path(c,'M-34 -4 Q-47 -11 -50 1 Q-39 12 -31 8 M33 -4 Q47 -11 50 2 Q39 13 31 8','#689dc8','#365e91',.8);K.path(c,'M-46 2 L-35 6 M35 6 L46 2',null,'#dceef5',1.2);
   K.path(c,'M-37 -23 Q-31 -43 -21 -40 Q-17 -52 -8 -44 Q0 -55 8 -44 Q18 -51 23 -39 Q35 -42 38 -22 L31 -17 Q0 -34 -31 -17Z','#fcfbf5','#90a6c8',.95);
   for(let j=-3;j<=3;j++)K.path(c,'M'+j*10+' -39 q-2 7 1 13',null,'#d1d7e6',1.2);
   I.portraitFace(c);K.path(c,'M-27 48 L-18 34 L0 39 L18 34 L29 48 L31 58 H-31Z','#254c80','#1e3d65',1);
   K.path(c,'M-19 34 L-10 41 L-7 34 L0 41 L7 34 L10 41 L19 34 L14 50 H-14Z','#fff8ed','#b4c3d6',.7);
   K.path(c,'M-31 -16 Q-32 -42 -4 -42 Q26 -44 33 -17 Q28 -2 28 13 L23 21 L24 -7 Q19 -17 12 -22 Q14 -4 4 4 Q3 -13 -3 -20 Q-6 -9 -13 -3 L-13 -19 Q-17 -6 -26 2 L-25 22 L-32 15Z',hair,'#254375',1.1);
   K.path(c,'M-21 -31 Q-14 -37 -7 -35 M4 -34 Q15 -34 23 -24 M-32 26 Q-36 42 -27 48 M30 26 Q36 43 27 50',null,'#a4c8e4',1.1);
   K.path(c,'M-1 -43 Q-15 -61 0 -64 Q16 -66 12 -54 Q6 -47 -1 -43Z','#477cb4','#294d82',1);K.path(c,'M0 -45 Q9 -51 9 -57',null,'#a0c8de',1);
   I.portraitEyes(c,'#5dadda','#253e68',false,blink);K.path(c,'M-5 21 Q0 24 7 20 Q5 30 -1 28 Q-5 27 -5 21Z','#bd6a7c','#96556a',.55);K.path(c,'M1 23 l3 -1 -1 3Z','#fff9ed');
   K.path(c,'M0 44 Q-13 34 -17 43 Q-13 52 0 47 Q12 54 17 44 Q14 35 0 44Z','#315c98','#24467c',.8);K.circle(c,0,45,3.3,'#6fbad5','#d3eafa',.65);
   for(let j=0;j<5;j++){const an=j*Math.PI*2/5;K.ellipse(c,34+Math.cos(an)*4.2,-20+Math.sin(an)*4.2,3,4,'#b7e4eb','#5e9dbd',.4,an);}K.circle(c,34,-20,2.2,'#fff7d9');
  }else if(id==='gpt'){
   const hair=K.gradient(c,[0,-44],[0,54],[[0,'#fffdf8'],[.6,'#e4e1f2'],[1,'#bfb9dd']]);
   K.path(c,'M-41 53 Q-48 24 -38 -8 Q-42 -35 -18 -43 Q5 -52 29 -36 Q43 -22 39 7 Q49 33 41 54 L24 47 L-27 49Z',hair,'#9c97b8',1);
   K.path(c,'M-24 -30 Q-42 -32 -37 -56 Q-30 -45 -23 -44 Q-16 -40 -16 -32Z M24 -30 Q43 -31 37 -56 Q30 -45 24 -44 Q17 -40 16 -32Z','#f5f2e9','#a2a0b8',1.1);
   K.path(c,'M-32 -45 l5 7 M30 -45 l-5 7',null,'#d4d2df',1);I.portraitFace(c);
   K.path(c,'M-31 54 Q-25 38 -13 35 L0 41 L13 35 Q26 38 31 54Z','#fcfaf6','#a4a1bd',.8);K.path(c,'M-11 36 L-4 49 L0 44 L4 49 L11 36',null,'#c1b9d5',1);K.path(c,'M0 42 l5 5 -5 7 -5 -7Z','#b7a6d5','#8d87b1',.7);
   K.path(c,'M-31 -12 Q-30 -43 -3 -43 Q25 -46 32 -18 L27 10 L23 19 Q23 -5 17 -16 Q12 -9 8 -8 Q8 -25 1 -29 Q0 -14 -10 -5 L-10 -23 Q-17 -10 -25 -7 L-25 21 L-31 28Z',hair,'#aaa1c0',.85);
   K.path(c,'M-19 -33 Q-10 -39 -3 -36 M9 -34 Q18 -32 23 -23 M-34 10 Q-43 25 -35 36 Q-26 46 -38 50 M34 12 Q44 30 35 39 Q26 47 38 50',null,'#fdfbff',1.3);
   I.portraitEyes(c,'#b1a6d1','#6d608c',true,blink);K.path(c,'M-4 23 Q0 26 5 22',null,'#ad7d92',.85);
   for(let j=0;j<5;j++){const an=j*Math.PI*2/5;K.ellipse(c,29+Math.cos(an)*4,-23+Math.sin(an)*4,2.5,3.9,'#eeecf8','#aba1c4',.5,an);}K.circle(c,29,-23,2.2,'#b3a5ce');
  }else if(id==='claude'){
   const hair=K.gradient(c,[0,-44],[0,54],[[0,'#d56834'],[.45,'#e98a43'],[1,'#f3ba6c']]);
   K.path(c,'M-41 54 Q-48 39 -41 25 Q-50 7 -39 -4 Q-44 -31 -22 -42 Q0 -51 25 -39 Q45 -28 39 -2 Q51 11 42 27 Q49 40 40 55Z',hair,'#a65d39',1.1);I.portraitFace(c);
   K.path(c,'M-33 55 Q-29 37 -16 33 L0 39 L16 33 Q30 38 33 55Z','#3f4148','#765745',1);K.path(c,'M-21 35 L-14 45 L-8 36 L0 45 L8 36 L14 45 L21 35 L14 54 H-14Z','#fff5e8','#c5a68b',.8);
   K.path(c,'M-30 -11 Q-33 -35 -13 -42 Q9 -48 27 -34 L32 -9 L28 17 L23 22 L24 -5 Q14 -8 5 -26 Q2 -18 -7 -9 L-9 -25 Q-15 -15 -25 -9 L-24 19 L-30 26Z',hair,'#aa623e',1);
   K.path(c,'M-22 -31 Q-14 -38 -7 -36 M4 -37 Q15 -38 23 -27',null,'#ffd6a1',1.3);
   for(const side of [-1,1]){K.path(c,'M'+side*32+' -1 Q'+side*44+' 12 '+side*32+' 22 Q'+side*23+' 30 '+side*36+' 37 Q'+side*44+' 42 '+side*33+' 49',null,'#9e583a',1.4);K.path(c,'M'+side*35+' 0 Q'+side*42+' 11 '+side*31+' 22 M'+side*30+' 30 Q'+side*44+' 41 '+side*35+' 48',null,'#ffd39b',1);}
   I.portraitEyes(c,'#d5a15e','#80523e',true,blink);K.path(c,'M-4 23 Q1 26 5 22',null,'#b67b79',.85);
   K.path(c,'M0 43 Q-11 35 -13 42 L-4 48 L0 45 L4 48 L13 42 Q10 35 0 43Z','#7c4f3b','#563d35',.7);K.circle(c,0,44,2.6,'#d9af5c','#f8e3ac',.6);
   for(let j=0;j<7;j++){const an=j*Math.PI*2/7;K.ellipse(c,30+Math.cos(an)*4.2,-31+Math.sin(an)*4.2,2.3,4.2,'#f0b15e','#bc7c42',.5,an);}K.circle(c,30,-31,2.8,'#9e603d');K.path(c,'M31 -25 L38 -10 L31 -14 L28 -9 L26 -25Z','#463d39','#ad7846',.6);
  }else{
   const hair=K.gradient(c,[0,-43],[0,35],[[0,'#5e4039'],[.55,'#735047'],[1,'#332e31']]);
   K.path(c,'M-36 33 Q-43 13 -35 -17 Q-33 -42 -9 -44 Q18 -49 33 -29 Q45 -11 36 33 Q26 41 17 34 L-18 35 Q-26 42 -36 33Z',hair,'#3e3336',1.2);I.portraitFace(c);
   K.path(c,'M-30 55 Q-26 38 -12 34 L0 39 L12 34 Q27 39 30 55Z','#353b40','#292e35',1);K.path(c,'M-10 30 L-11 42 Q0 49 11 42 L10 30Z','#3a3c41','#262f36',.7);
   K.path(c,'M-30 -13 Q-29 -38 -7 -42 Q20 -46 31 -22 Q24 -25 17 -31 Q1 -19 -13 -10 Q-19 -5 -25 -5 L-25 25 L-33 30 L-34 3Z',hair,'#46373b',1.1);
   K.path(c,'M17 -31 Q31 -21 30 3 L29 25 L34 30 Q39 10 34 -12',hair,'#46373b',1);K.path(c,'M-22 -26 Q-7 -40 10 -36 M-29 -12 Q-14 -25 -3 -25 M31 6 L31 23',null,'#a27b68',1.1);
   I.portraitEyes(c,'#8b6952','#4e3d37',false,blink);K.path(c,'M-5 22 Q0 24 6 21 Q5 28 0 28 Q-4 27 -5 22Z','#b47479','#a66b72',.55);K.path(c,'M-3 23 Q0 24 4 22',null,'#fff3e9',1);
   K.path(c,'M-20 35 Q0 44 21 34 L20 43 Q3 53 -19 43Z','#cc5661','#a84350',.9);K.path(c,'M8 43 L20 43 L24 59 L12 59Z','#d5616b','#a84350',.8);K.path(c,'M-13 39 Q0 44 13 39 M14 48 L20 48 M15 52 L21 52',null,'#eb9294',.8);
   K.path(c,'M-26 -17 L-17 -22',null,'#de6870',3);K.path(c,'M-25 -18 L-18 -22',null,'#ffc4b4',.7);
  }
  c.restore();
 };


 // Each face has its own contour. No shared silhouette with a colour swap.
 I.portraitFace=function(c){
  const shapes={
   fish:'M-25 -18 Q-30 0 -25 16 Q-20 29 0 32 Q21 29 25 16 Q29 0 25 -18Z',
   gpt:'M-24 -19 Q-27 -1 -22 15 Q-15 28 0 34 Q15 28 22 15 Q26 -2 24 -19Z',
   claude:'M-24 -19 Q-27 -1 -23 13 Q-18 25 1 32 Q19 25 24 11 Q28 -5 23 -19Z',
   doubao:'M-24 -16 Q-28 2 -23 17 Q-17 29 0 31 Q18 29 23 17 Q28 2 24 -16Z'
  };
  K.path(c,shapes[I.active]||shapes.doubao,'#fff0df','#ad7d82',.85);
  K.path(c,'M-7 28 L-7 39 Q0 43 7 39 L7 28','#f5d8c7','#c6948b',.65);
 };
 I.portraitEyes=function(c,iris,ink,calm,unused){
  const id=I.active,clock=P.castClock||0,blink=(clock+(id==='fish'?.6:id==='gpt'?1.9:id==='claude'?3.1:0))%5.1;
  const shut=blink>4.91;
  const conf={fish:[11,6.0,5.5,5.5,0],gpt:[11.8,7.0,3.9,4.5,.7],claude:[11.4,6.5,3.9,4.1,1.0],doubao:[11,5.8,4.8,6,0]}[id];
  const [dx,rx,ry,cy,gaze]=conf;
  for(const side of [-1,1]){
   const x=side*dx;
   if(shut){K.path(c,`M${x-rx} ${cy} Q${x} ${cy+2} ${x+rx} ${cy}`,null,ink,1.1);}
   else{
    const eye=new Path2D();eye.moveTo(x-rx,cy);eye.quadraticCurveTo(x,cy-ry*1.3,x+rx,cy-.4);eye.quadraticCurveTo(x,cy+ry*1.7,x-rx,cy);eye.closePath();
    c.fillStyle='#fffaf3';c.fill(eye);c.save();c.clip(eye);
    K.ellipse(c,x+gaze,cy+1.2,3.3,4.5,iris);K.ellipse(c,x+gaze,cy+1.6,1.55,2.9,ink);
    K.circle(c,x+gaze-1,cy-.2,1.1,'#fff');c.restore();c.strokeStyle=ink;c.lineWidth=.65;c.stroke(eye);
    K.path(c,`M${x-rx} ${cy} Q${x} ${cy-ry*1.3} ${x+rx} ${cy-.4}`,null,ink,1.15);
   }
   const browY=id==='gpt'?-4.5:id==='claude'?-5:-3.5;
   K.path(c,`M${x-4.8} ${browY} Q${x} ${browY-(id==='gpt'?.5:2.1)} ${x+4.8} ${browY+(id==='gpt'?.6:0)}`,null,ink,.85);
  }
  K.path(c,'M0 12 l-1 3 2 .4',null,'#cfa19b',.65);
  if(id==='fish'||id==='doubao'){K.ellipse(c,-20,16,4.8,2.1,'rgba(235,143,151,.2)');K.ellipse(c,20,16,4.8,2.1,'rgba(235,143,151,.2)');}
 };
 I.riceBowl=function(c,x,y,s=1){c.save();c.translate(x,y);c.scale(s,s);
  K.path(c,'M-20 0 Q-19 19 0 21 Q19 19 20 0Z','#fbfcf3','#54779a',1.2);
  K.ellipse(c,0,0,20,5,'#dce8ec','#54779a',1.1);
  K.path(c,'M-19 -1 Q-18 -9 -11 -10 Q-7 -17 0 -13 Q9 -17 13 -9 Q20 -8 19 -1Z','#fffef1','#cad5d6',.7);
  for(let j=0;j<14;j++){const x=-13+(j*9)%27,y=-3-(j*7)%9;K.path(c,`M${x} ${y} l2 -1.5`,null,'#d4d6bf',.7);}
  K.path(c,'M-17 7 Q0 13 17 7',null,'#6b9bbd',1.4);K.path(c,'M-11 17 H11',null,'#7ba7c2',1);
  K.path(c,'M11 -9 L28 -27 M14 -7 L32 -22',null,'#8b633e',1.9);c.restore();
 };
 const baseAvatar=I.castAvatar;
 I.castAvatar=function(c,x,y,size,id,clock){
  const previous=P.castClock;if(Number.isFinite(clock))P.castClock=clock;
  baseAvatar(c,x,y,size,id);
  if(size>=40){c.save();c.beginPath();c.roundRect(x,y,size,size,Math.max(4,size*.12));c.clip();c.translate(x+size*.5,y+size*.55);c.scale(size/120,size/120);
   if(id==='fish')I.riceBowl(c,19,43,.70);
   if(id==='gpt'){
    c.save();c.translate(25,38);c.rotate(-.12);K.path(c,'M-13 -13 H14 V21 H-13Z','#eef0f7','#8e89aa',.9);K.rect(c,-5,-16,10,5,'#b4adc8','#8e89aa',.7);
    for(let k=0;k<3;k++){K.path(c,`M-9 ${-5+k*8} l2 2 4 -5`,null,'#8073a8',1.4);K.line(c,[[0,-5+k*8],[9,-5+k*8]],'#b2a6cc',.8);}c.restore();
   }
   if(id==='claude'){
    K.path(c,'M18 29 L43 37 L34 57 L10 49Z','#faf2df','#b28e63',.8);
    for(let k=0;k<3;k++)K.path(c,`M${20+k*6} ${33+k*2} l4 1 -4 10 -4 -1Z`,['#ce7645','#e9d6b5','#3f5150'][k]);
    K.line(c,[[15,56],[42,30]],'#6a4738',1.4);K.path(c,'M39 33 L44 27 L44 33Z','#c59968');
   }
   c.restore();
  }
  if(Number.isFinite(clock))P.castClock=previous;
 };
 P.castArt={draw:I.castAvatar,cast:I.cast,riceBowl:I.riceBowl,revision:'R5-personality-20261117',
  traits:{fish:'喜欢吃大白饭；活泼但不只会起哄',gpt:'严谨，必要时严谨过头；给出可用诊断',claude:'能力强，审美在线；用实际操作解决问题',doubao:'亲切；以冗长的「最简单最直接」开场形成反差'},
  exactDoubao:'我将用最简单最直接最不绕弯子的方式告诉你'};
})();
