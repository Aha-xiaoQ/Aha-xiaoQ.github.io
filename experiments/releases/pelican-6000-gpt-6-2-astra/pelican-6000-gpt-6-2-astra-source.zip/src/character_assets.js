/* This edition accepts no image assets. Every actor is drawn from code.
   The false predicates retain compatibility with earlier procedural fallbacks;
   the drawing guard makes an accidental bitmap integration fail loudly. */
P.installCharacterAssets=function(images={},manifest={}){
  if(Object.keys(images).length||Object.keys(manifest).length)throw new Error('Pure-code edition: character images are not permitted.');
  return 0;
};
P.hasCharacterAsset=()=>false;
P.characterAssetCount=()=>0;
P.characterFrameCount=()=>0;
P.characterFrameIndex=()=>0;
P.drawCharacter=function(){throw new Error('Pure-code edition: draw the actor with paths.');};
