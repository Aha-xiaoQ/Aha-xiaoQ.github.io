/* A travelling wheelwright's mark. It lives in the wheel, not on a HUD;
 * carved bronze, kingfisher enamel, tooled hide, chipped varnish and phosphor
 * do not catch light in the same way. No history buffers: time alone suffices. */
(()=>{
const face=P.drawRider,TAU=Math.PI*2;
const finishes={1:['#8e572a','#f4c65b','#31726c',8],2:['#696a58','#d8d3b6','#b4ab8d',4],5:['#72543a','#dec690','#64775e',8],6:['#8b4631','#dbbc79','#587c6d',4],7:['#92712e','#f3d486','#336f81',12],9:['#5d351e','#edbb71','#91562b',8],10:['#566459','#d9c79e','#558191',6],11:['#36638a','#f1cf6d','#a4c5b9',7],17:['#654976','#ffb6d7','#70e2df',6],18:['#526170','#ebb26c','#82aba8',6],19:['#498e91','#b6f2cf','#83b9ce',4]};
P.drawRider=function(c,t,o){
 o=o||{};face(c,t,o);let f=finishes[o.style];
 if(!f||!(o.scale>.34)||(o.build??1)<1||(o.alpha??1)<.18||o.silhouette||o.style===1&&P.riderGeometry.palettes[1][0]==='#9f6841')return;
 c.save();c.globalAlpha*=o.alpha??1;c.translate(o.x,o.y);c.rotate(o.tilt||0);c.scale(o.scale,o.scale);
 for(const [x,a] of [[-130,o.rearWheelAngle],[150,o.frontWheelAngle]]){if(!Number.isFinite(a))continue;
  c.save();c.translate(x,25);c.rotate(a);let n=f[3],r=10;
  K.circle(c,0,0,r,f[0],f[1],1.1);
  for(let j=0;j<n;j++){c.rotate(TAU/n);K.path(c,'M2 0 Q5 -3 9 0 Q5 3 2 0Z',j%2?f[1]:f[2]);}
  K.circle(c,0,0,2.2,f[1]);c.restore();
 }
 c.restore();
};
// Never add another block of explanatory text. Replace the inherited captions
// in their native cartouches. The vertical pair is set directly in scene_notes.
Object.assign(P.sceneNotes,{
 0:'牛群忽然少嚼了一口草。',1:'他走了，墙上还有一个。',2:'车马之间，添一骑。',3:'风从袖口借了条路。',
 5:'一尾过桥，不走桥面。',6:'又一圈，点成了横。',7:'园中有客，屏后有眼。',8:'何事按铃？',9:'灯近，门远。',
 11:'今夜，有颗星搭便车。',12:'回声先弯了腰。',13:'影已上楼。',15:'一铃，一命。',17:'这一拍，昨天来过。'});
P.version='R7';P.edition='pure-code-r7-the-moving-impression';P.invalidateMotion();
})();
