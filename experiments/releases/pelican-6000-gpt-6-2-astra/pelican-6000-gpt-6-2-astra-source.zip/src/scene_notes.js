/* Each chapter speaks in its own material: inscriptions, seals, cartouches,
   intertitles and HUD lettering. Interface chapters write inside their UI. */
(()=>{
 const N={};
 P.sceneNotes=['赭石留痕，岩壁记事。','侧面造型，平列叙事。','刀刻成像，墨拓留白。','以线传神，衣带当风。','浓淡为山，留白作水。','一城烟火，尽入长卷。','折页成书，符号记时。','细笔设色，花叶描金。','寥寥数笔，留白有声。','镂皮透光，竹杆成戏。','刻版叠色，浪线成风。','笔触旋动，星光成流。','色带起伏，情绪外溢。','光影说话，无声有戏。','两个电压，描出一只鸟。','铜铃送达，像素世界多一条命。','消息送达，画面也在动。','霓虹与网格，一场旧未来。','弹幕路过，主角不停播。','路径是画，运行即成片。'];
 N.text=(c,s,x,y,size,col,align='left',font='serif',weight='400')=>K.text(c,s,x,y,size,col,align,font,weight);
 N.vert=(c,s,x,y,size,col)=>{[...s].forEach((ch,i)=>N.text(c,ch,x,y+i*(size+6),size,col,'center'));};
 N.seal=(c,x,y,size=25,label='行',col='#a64a38')=>{c.save();c.translate(x,y);c.rotate(-.035);K.rect(c,-size/2,-size/2,size,size,col);K.rect(c,-size/2+2,-size/2+2,size-4,size-4,null,'#e9d1ae',.7);N.text(c,label,0,size*.27,size*.65,'#f0dcbb','center');c.restore();};
 N.date=(c,i,x,y,col='#82735c')=>N.text(c,P.scenes[i].date,x,y,14,col,'left','sans');
 N.lotus=(c,x,y,col)=>{for(let j=-2;j<=2;j++){c.save();c.translate(x,y);c.rotate(j*.35);K.path(c,'M0 6 Q-10 -5 0 -22 Q10 -5 0 6Z',null,col,1.1);c.restore();}K.line(c,[[x-24,y+7],[x+24,y+7]],col,1.4);};
 P.drawSceneNote=function(c,i,alpha=1){
  if(i<0||[14,16,18,19].includes(i))return;
  const s=P.scenes[i],note=P.sceneNotes[i];c.save();c.globalAlpha=alpha;
  switch(i){
   case 0:{
    K.path(c,'M244 60 L333 47 L555 57 L765 49 L811 80 L794 175 L565 183 L316 169 L235 142Z','rgba(204,160,115,.60)');
    K.path(c,'M249 63 L340 51 L552 61 L765 54',null,'rgba(244,209,157,.7)',2.2);
    for(let j=0;j<9;j++)K.ellipse(c,258+j*62,174+(j%3)*3,1.4,1.1,'#9d6846');
    N.text(c,s.title,274,122,36,'#815038','left','serif','700');N.text(c,note,278,157,20,'#8d593d');
    N.text(c,'SAHARA ROCK ART',278,77,14,'#845237','left','mono');N.date(c,i,660,81,'#996846');break;
   }
   case 1:{
    const x=272,y=51,w=568,h=131;K.path(c,`M${x+28} ${y} H${x+w-28} Q${x+w} ${y} ${x+w} ${y+29} V${y+h-29} Q${x+w} ${y+h} ${x+w-28} ${y+h} H${x+28} Q${x} ${y+h} ${x} ${y+h-29} V${y+29} Q${x} ${y} ${x+28} ${y}Z`,'#e7cb93','#376c70',2.6);
    K.rect(c,x+35,y+7,w-70,4,'#b67443');K.rect(c,x+35,y+h-11,w-70,4,'#b67443');N.lotus(c,x+44,y+78,'#39827e');N.lotus(c,x+w-44,y+78,'#39827e');
    N.text(c,s.title,x+w/2,y+52,35,'#305e66','center','serif','700');N.text(c,note,x+w/2,y+89,21,'#8b4d34','center');N.text(c,'EGYPTIAN MURAL · '+s.date,x+w/2,y+114,13,'#8f7248','center','sans');break;
   }
   case 2:{
    K.path(c,'M260 46 L790 44 L809 61 L803 163 L777 181 L267 175 L250 154 L254 66Z','#202b24','#849078',1.4);
    K.path(c,'M268 58 H787 V161 L775 175 H267Z',null,'#bdc3a1',.8);for(let j=0;j<16;j++){let x=271+j*32;K.path(c,`M${x} 47 l4 6 -7 3`,null,'#65715b',.9);}
    N.text(c,s.title,285,103,37,'#e3dfc3','left','serif','700');N.text(c,note,287,144,23,'#bac5a6');N.text(c,'HAN STONE RUBBING',287,169,13,'#a3b092','left','mono');N.date(c,i,640,169,'#8e9d82');break;
   }
   case 3:{
    N.text(c,s.title,285,102,43,'#4f5144');K.path(c,'M282 119 Q413 125 571 117 L571 120 Q402 129 282 120Z','#6d705c');
    N.text(c,note,289,160,25,'#747463');N.date(c,i,292,187,'#96917b');N.text(c,'TANG LINE DRAWING',412,187,13,'#85856f','left','mono');N.seal(c,587,151,24,'唐','#a46952');break;
   }
   case 4:{
    N.vert(c,'宋代山水',1429,77,32,'#3d4236');N.vert(c,'山静一程',1377,83,22,'#6e725c');N.vert(c,'雁过无痕',1337,83,22,'#6e725c');
    N.text(c,'SONG LANDSCAPE',1305,302,16,'#5f6b55','left','mono');N.text(c,'c. 1000 CE',1305,326,15,'#75806a','left','mono');N.seal(c,1428,245,27,'山','#a65b49');K.path(c,'M1324 49 Q1382 39 1451 47',null,'rgba(92,119,92,.25)',1.2);break;
   }
   case 5:{
    K.line(c,[[295,18],[295,65]],'#86714f',2);K.line(c,[[713,18],[713,65]],'#86714f',2);
    K.path(c,'M271 66 L738 66 L728 132 L279 132Z','#655d43','#b7a579',2);K.rect(c,284,75,440,47,null,'#a99c70',1);
    N.text(c,s.title,505,112,33,'#e8d7a6','center');K.path(c,'M313 147 Q497 138 692 147 L685 184 L319 187Z','#e5dbc0','#b7aa86',.8);N.text(c,note,505,174,22,'#766345','center');N.text(c,'RIVERSIDE SCROLL · c. 1100 CE',505,209,14,'#8b7855','center','serif');break;
   }
   case 6:{
    K.path(c,'M251 48 H797 L813 63 L803 182 H266 L247 169Z','#f0d8a4','#913e30',2.2);K.rect(c,263,59,530,8,'#aa4633');K.rect(c,263,164,530,7,'#aa4633');
    for(let j=0;j<10;j++){let x=275+j*51;K.rect(c,x,57,13,12,j%2?'#ae4a32':'#dfb878');}
    K.circle(c,295,117,21,null,'#a24c33',2);K.path(c,'M282 119 h27 M295 103 v27 M281 105 l27 24',null,'#a24c33',1.4);
    N.text(c,s.title,340,105,32,'#81382c','left','serif','700');N.text(c,note,340,153,19,'#a14c32');N.date(c,i,635,104,'#976c45');N.text(c,'MAYA CODEX',340,128,14,'#9c4936','left','mono');break;
   }
   case 7:{
    K.path(c,'M276 77 L292 61 H460 L565 42 L670 61 H827 L844 77 V163 L827 179 H293 L276 163Z','#213e65','#bd9b55',2.3);
    K.path(c,'M287 80 L301 71 H460 L565 53 L669 71 H818 L833 80 V156 L818 168 H301 L287 156Z',null,'#d2b66d',.8);
    for(let j=0;j<11;j++){let x=301+j*49;K.path(c,`M${x-5} 169 q5 -10 10 0 q-5 -4 -10 0`,null,'#d3b36b',.8);}
    for(const x of [312,807]){N.lotus(c,x,119,'#cfb875');K.path(c,`M${x} 130 q-12 7 -8 20 M${x} 130 q12 7 8 20`,null,'#d2af68',.8);}
    N.text(c,s.title,565,111,35,'#f1deaa','center','serif','700');N.text(c,note,565,148,21,'#cbbd87','center');N.text(c,'MUGHAL MINIATURE · c. 1600 CE',565,208,14,'#8b733d','center','serif');break;
   }
   case 8:{
    K.path(c,'M277 65 Q360 55 441 66 L439 70 Q353 66 277 68Z','rgba(40,57,45,.17)');N.text(c,s.title,285,119,40,'#2c3a30');N.text(c,note,290,165,26,'#68755f');N.seal(c,603,158,29,'意','#a5493a');
    N.date(c,i,292,198,'#9b9a81');N.text(c,'BADA SHANREN / FREEHAND INK',414,198,13,'#8d9480','left','serif');break;
   }
   case 9:{
    const x=274,y=51,w=541,h=135;K.path(c,`M${x+16} ${y} H${x+w-16} L${x+w} ${y+20} V${y+h-20} L${x+w-16} ${y+h} H${x+16} L${x} ${y+h-20} V${y+20}Z`,'#8c5729','#d9ac60',2);
    for(let j=0;j<29;j++){K.circle(c,x+18+j*18,y+9,2.4,'#e5bd72');K.circle(c,x+18+j*18,y+h-9,2.4,'#e5bd72');}for(let j=0;j<5;j++){K.circle(c,x+9,y+28+j*20,2.4,'#e5bd72');K.circle(c,x+w-9,y+28+j*20,2.4,'#e5bd72');}
    N.text(c,s.title,x+w/2,y+52,34,'#f0d18d','center');N.text(c,note,x+w/2,y+85,21,'#e2b971','center');N.text(c,'WAYANG KULIT · c. 1800 CE',x+w/2,y+113,13,'#eed196','center','serif');break;
   }
   case 10:{
    K.path(c,'M293 43 H371 V206 H293Z','#c96c4d','#344f56',1.6);K.rect(c,299,49,66,151,null,'#f1d7a0',1);N.vert(c,'浮世绘',332,88,33,'#f0e2bd');
    N.vert(c,'前轮知雨',413,76,24,'#2f535a');N.vert(c,'后轮知晴',454,76,24,'#2f535a');N.seal(c,500,177,25,'風','#a85038');N.date(c,i,398,223,'#5c746a');N.text(c,'UKIYO-E / TOKAIDO',296,251,14,'#365b62','left','serif');break;
   }
   case 11:{
    for(let j=0;j<8;j++)K.path(c,`M${264+j*5} ${65+j*13} C397 ${30+j*12} 560 ${105+j*8} ${785-j*4} ${59+j*12}`,null,j%3===0?'rgba(62,112,145,.75)':'rgba(41,78,117,.9)',9-j*.25);
    K.path(c,'M265 101 C246 64 273 45 294 55 C317 70 293 94 278 79',null,'#d8c37c',2.5);K.star(c,278,72,8,'#ecd893');
    c.shadowColor='rgba(221,196,107,.25)';c.shadowBlur=5;N.text(c,s.title,323,104,40,'#ffe383','left','serif','700');c.shadowBlur=0;N.text(c,note,321,148,24,'#d0dcae');N.date(c,i,654,100,'#99c3d2');N.text(c,'THE STARRY NIGHT',323,178,15,'#a9c8d0','left','serif');break;
   }
   case 12:{
    c.save();c.translate(278,55);c.rotate(-.022);K.path(c,'M-8 7 L511 -5 L544 126 L22 143Z','rgba(95,56,53,.87)','#d3854f',1.5);K.path(c,'M4 13 Q230 -4 508 10 M20 133 Q267 143 532 119',null,'#e7a867',2.3);
    N.text(c,s.title,28,64,45,'#f4d6a3','left','serif','700');N.text(c,note,31,108,24,'#e8c18c');N.text(c,s.date,360,62,14,'#cfa07e','left','sans');N.text(c,'THE SCREAM',32,133,14,'#e3ad78','left','serif');c.restore();break;
   }
   case 13:{
    K.rect(c,267,48,558,137,'#202826','#aab6a2',1);K.rect(c,276,57,540,119,null,'#c4cab6',.9);for(const x of [284,807]){K.path(c,`M${x} 69 q-8 0 -8 9 q0 8 8 8 M${x} 163 q-8 0 -8 -9 q0 -8 8 -8`,null,'#9ca993',1);}
    N.text(c,s.title,546,104,34,'#e9e8d8','center');N.text(c,note,546,150,23,'#bfc9b4','center');K.line(c,[[345,119],[748,119]],'#778779',.7);N.text(c,'SILENT EXPRESSIONISM · 1922',546,175,13,'#a2afa1','center','serif');break;
   }
   case 15:{
    K.rect(c,270,43,686,113,'#153b6c');K.rect(c,276,49,674,101,null,'#d1e9ff',3);K.rect(c,281,54,664,8,'#2d5890');
    N.text(c,'CHIME COURIER',294,88,19,'#fff4c4','left','mono','700');N.text(c,'像素风铃',928,89,26,'#fff5cb','right','sans','700');N.text(c,note,296,132,20,'#e5f2ff','left','sans');
    for(let j=0;j<4;j++)K.rect(c,913+j*7,113,4,14-j*2,'#ffdd71');N.text(c,'8-BIT / 1980s',278,177,14,'#244b69','left','mono');break;
   }
   case 17:{
    K.path(c,'M281 55 H321 M281 55 V87 M818 55 H778 M818 55 V87 M281 177 V146 M281 177 H321 M818 177 H778 M818 177 V146',null,'#a2e7df',1.4);
    N.text(c,'蒸汽波',308,112,43,'#ee93c9','left','serif','700');N.text(c,'蒸汽波',306,110,43,'#d9e9e2','left','serif','700');N.text(c,'VAPORWAVE / 2010s',793,89,13,'#97e2dc','right','mono');N.text(c,note,309,154,23,'#f3c0de');break;
   }
  }
  c.restore();
 };
})();
