/* R5: consequences, not decorative reactions. Every authored event uses the
   scene's local clock and the very same rider/contact geometry as the renderer. */
(()=>{
'use strict';
const E=K.ease,S=K.smoother,TAU=Math.PI*2,H=P.historic;
const path=(c,d,f,s,w=1)=>K.path(c,d,f,s,w),line=(c,p,col,w=1)=>K.line(c,p,col,w);
function bellWave(c,p,u,col){if(u<=0||u>=1)return;const co=Math.cos(p.tilt||0),si=Math.sin(p.tilt||0),x=p.x+p.scale*(108*co+137*si),y=p.y+p.scale*(108*si-137*co);c.save();c.globalAlpha=(1-u)*.65;for(let j=0;j<2;j++){c.beginPath();c.arc(x,y,(13+u*24+j*10)*p.scale,-1.2,.4);c.strokeStyle=col;c.lineWidth=1;c.stroke();}c.restore();}
function inOut(t,a,b,c,d){return E((t-a)/(b-a))*(1-E((t-c)/(d-c)));}
function fish(c,x,y,s,col='#819c93',r=0){c.save();c.translate(x,y);c.scale(s,s);c.rotate(r);path(c,'M-16 0 Q-8 -11 13 -5 L22 -12 L19 0 L23 10 L12 5 Q-9 13 -16 0Z',col,'#596f65',1);K.circle(c,-9,-1,1.3,'#3f554e');path(c,'M-2 -5 Q2 0 -2 6',null,'#d0cbb2',.6);c.restore();}
function basket(c,x,y,s=1){c.save();c.translate(x,y);c.scale(s,s);path(c,'M-29 -24 Q0 -36 29 -24 L23 0 Q0 8 -23 0Z','#b69962','#78684b',1.3);for(let j=-2;j<=2;j++)path(c,`M${j*10} -25 L${j*8} 1`,null,'#dbc596',.7);for(let j=0;j<3;j++)path(c,`M${-28+j*2} ${-22+j*7} Q0 ${-15+j*7} ${28-j*2} ${-22+j*7}`,null,'#8d784d',.8);K.ellipse(c,0,-25,29,7,'#847555','#6f6148',1);fish(c,-5,-28,.88);fish(c,13,-27,.65,'#b4b5a2',.2);c.restore();}
function note(c,txt,x,y,col='#615840',size=17){K.text(c,txt,x,y,size,col,'center','serif');}
function merchant(c,x,y,reach,t,target){
 // Bent legs carry a leaning torso; one coherent sleeve/elbow/wrist reaches the handle.
 const ink='#665b45',robe='#8b9b7e',skin='#c0a57a';c.save();c.translate(x,y);
 path(c,'M-14 -63 L-30 -8 L-18 1 L-3 -39 L15 -2 L30 -2 L10 -65Z','#b5b092',ink,1.2);
 path(c,'M-31 -8 L-40 -3 L-38 2 L-17 2 L-18 -5 M15 -5 L15 2 H37 Q39 -2 27 -7Z','#756b51',ink,1);
 path(c,'M-12 -129 Q15 -127 28 -99 L17 -58 Q-3 -50 -24 -67 L-28 -108Z',robe,ink,1.2);
 path(c,'M-10 -123 L-2 -101 L11 -126 M-1 -99 L-6 -61 M-22 -70 Q-2 -80 18 -72',null,'#d3c7a4',1.2);
 const lean=.2+reach*.20;c.save();c.translate(-9,-134);c.rotate(-lean);
 path(c,'M-9 -18 Q-7 -28 5 -25 Q18 -20 14 -7 L20 -4 L14 0 L14 10 Q7 17 -3 10 L-9 2Z',skin,ink,1);
 path(c,'M-11 -2 Q-19 -24 -2 -30 Q17 -31 20 -18 L8 -20 L0 -7 L-6 2Z','#5c5f49',ink,.8);path(c,'M2 -13 L9 -12 M9 4 L14 3',null,ink,.8);K.circle(c,7,-9,.9,ink);c.restore();
 const contact=target?E((t-2.25)/.60):0;
 const hx=K.lerp(-15,target?target.x-x+16:-63,contact),hy=K.lerp(-90,target?target.y-y-1:-32,contact),ex=K.lerp(-23,(hx-21)*.50-9,contact),ey=K.lerp(-83,(-117+hy)*.5-4,contact);
 path(c,`M-21 -117 Q-33 -111 ${ex-7} ${ey} L${hx-7} ${hy-4} L${hx+2} ${hy+5} L${ex+8} ${ey+7} Q-8 -99 -11 -116Z`,robe,ink,1.2);
 path(c,`M${hx-7} ${hy-4} Q${hx-12} ${hy-8} ${hx-16} ${hy-1} L${hx-19} ${hy+8} Q${hx-13} ${hy+11} ${hx-10} ${hy+4} L${hx+2} ${hy+5}Z`,skin,ink,.8);
 path(c,`M${hx-16} ${hy+1} l5 4 M${hx-14} ${hy-2} l5 4`,null,ink,.6);
 path(c,'M14 -113 Q30 -92 30 -71 L13 -57 L6 -66 L16 -80 L7 -106Z',robe,ink,1);c.restore();
}
function h(u,a,b,va,vb,d){u=K.clamp(u);return(2*u*u*u-3*u*u+1)*a+(u*u*u-2*u*u+u)*d*va+(-2*u*u*u+3*u*u)*b+(u*u*u-u*u)*d*vb;}
// Briefly stop at the slipping fish basket; actual position stops, therefore the
// existing rolling integrator stops wheels, pedals and chain without an overlay.
P.scenes[5].travelX=t=>t<2.45?h(t/2.45,0,720,267,0,2.45):t<3.65?720:h((t-3.65)/2.35,720,1600,0,267,2.35);
const previousPose=P.nativePose;
P.nativePose=function(i,l,t){const p=previousPose(i,l,t);
 if(i===5){p.x=P.scenes[5].travelX(l);const look=inOut(l,1.9,2.4,3.45,3.8);p.headNod=.10*look;p.gazeY=.6*look;p.brakeLean=.12*look;p.bellPress=Math.sin(Math.PI*K.clamp((l-3.45)/.22));}
 if(i===8){p.gazeX=1;p.gazeY=-.20*inOut(l,2,2.4,3.3,3.8);p.bellPress=0;p.expression='calm';p.headNod=-.025*inOut(l,2,2.4,3.3,3.8);}
 if(i===3){p.headNod=.095*inOut(l,2.2,2.5,3.2,3.7);p.gazeY=.24*inOut(l,2.2,2.5,3.2,3.7);}
 if(i===1){p.headNod=0;p.gazeX=.7;p.expression='calm';}
 if(i===19){p.gazeX=l>=3.1&&l<=3.65?.5:1;p.headNod=l>=3.1&&l<=3.65?-.06:0;}
 return p;};
P.sceneNotes=['先借一条路，再留一道轮印。','画师留白处，恰好是出口。','车马有编制，来客无编号。','衣带借风，也为来客让路。','山很大。赶路的朋友很小。','先拦住鱼篮，再继续赶路。','五个点，合成一横。','对称的花园，来了不对称的客人。','这里安静，铃声就先欠着。','灯一挪，影子也有了出口。','帽子借风，旅人借路。','一颗星搭了半圈便车。','不是争吵。只是声音有点大。','主人赶路，影子先下班。','先校准，再看清自己。','长喙也是一种游戏控制器。','不是表情包，是一位赶路的朋友。','磁带可以回放，路还要向前。','两碗白饭，一颗心意。','代码能画路，方向自己选。'];
// Short, physical event ledger shared with audio/QA. Times below are the native
// six-second scene parameter; the director maps them to actual output seconds.
P.storyEvents=[
 {scene:0,u:2.5,id:'herd_make_way',kind:'rim'},
 {scene:1,u:3.55,id:'scribe_leaves_exit',kind:'wood'},
 {scene:2,u:3.5,id:'anonymous_stamp',kind:'woodLow'},
 {scene:3,u:2.75,id:'ribbon_gives_way',kind:'shaker'},
 {scene:5,u:2.45,id:'basket_touches_front_tyre',kind:'woodLow'},
 {scene:5,u:3.52,id:'bridge_thanks_bell_1',kind:'bell'},
 {scene:5,u:3.72,id:'bridge_thanks_bell_2',kind:'bell'},
 {scene:7,u:3.3,id:'garden_fountain_answer',kind:'droplet'},
 {scene:10,u:3.15,id:'traveller_catches_hat',kind:'shaker'},
 {scene:11,u:3.86,id:'star_reaches_clock',kind:'bell'},
 {scene:14,u:3.6,id:'scope_calibrated',kind:'switch'},
 {scene:15,u:3.05,id:'bill_hits_question_block',kind:'chipArp'},
 {scene:15,u:3.48,id:'coin_on_bell',kind:'chipArp'},
 {scene:18,u:3.32,id:'rice_delivery_arrived',kind:'message'},
 {scene:19,u:3.65,id:'road_choice_committed',kind:'key'}
];
function bridgeState(l,p){const stopPose=P.supportPose(720,p.scale,x=>P.scenes[5].ground(x)),co=Math.cos(stopPose.tilt),si=Math.sin(stopPose.tilt),touch=720+stopPose.scale*(150*co-25*si+77)+25,base=touch+88,approach=S((l-1.6)/.85),pickup=S((l-2.85)/.65),x=K.lerp(1122,touch,approach)+pickup*70,y=P.scenes[5].ground(x)-2-pickup*31;return{x,y,touch,pickup,approach,merchantX:touch+89};}
P.bridgeStoryState=bridgeState;
// Source-of-truth contact points, in the chapter's own coordinate system.
P.storyPoint=function(i,u,landmark){
 const D=P.finalDirector,t=D.starts[i]+u/6*D.lengths[i],q=D.geometry(t),p=q.p,m=D.motionAt(t);
 const xy=landmark==='bill'?P.characterSkin.mapAt(200,-240,D.legacy(t),m.crankAngle,p,i):landmark==='crest'?P.characterSkin.mapAt(22,-286,D.legacy(t),m.crankAngle,p,i):[108,-137];
 const co=Math.cos(p.tilt||0),si=Math.sin(p.tilt||0);
 return{x:q.worldX-D.origins[i]+p.scale*(xy[0]*co-xy[1]*si),y:p.y+p.scale*(xy[0]*si+xy[1]*co)};
};
P.pixelStoryContact=function(l){
 const hit=3.05,land=3.48,a=P.storyPoint(15,hit,'bill'),b=P.storyPoint(15,land,'bell');
 const bx=a.x,by=a.y-24,knock=92*E((l-hit)/.18)*(1-E((l-4.3)/.45));
 const u=K.clamp((l-hit)/(land-hit)),launch={x:bx+24,y:by-12};
 const coin={x:K.lerp(launch.x,b.x,u),y:K.lerp(launch.y,b.y-6,u)-95*4*u*(1-u)};
 return{hit,land,bx,by,knock,bill:a,bell:b,coin,launch};
};
P.storyDetails=function(c,i,l,t,p,front){
 if(!p)return;
 switch(i){
 case 0: if(!front){
  // Small hoof prints bend around the bicycle's approach, not a whole-wall shake.
  for(let j=0;j<7;j++){const born=1+j*.27;if(l<born)continue;const x=670+j*42,y=756+Math.sin(j*.7)*8;K.ellipse(c,x,y,3,1.3,'rgba(113,63,32,.43)',null,1,.35);}
  if(l>3.1)path(c,'M1170 546 l17 -20 22 2 M1174 539 l-6 16 M1196 527 l10 21',null,'#a25c31',2);
 }break;
 case 1: if(front){const e=E((l-2.8)/.75);c.save();c.globalAlpha=e;path(c,'M1307 710 V523 Q1348 487 1387 523 V710',null,'#387b7c',3);path(c,'M1310 710 H1384',null,'#b96a39',2);K.text(c,'留 白',1347,551,18,'#99653d','center','serif');path(c,`M1321 683 H${1321+43*e} l-8 -6 M${1321+43*e} 683 l-8 6`,null,'#b47740',1.6);c.restore();}break;
 case 2: if(front&&l>2.8){const a=E((l-2.8)/.2);c.save();c.globalAlpha=a;K.rect(c,1228,500,120,55,'#26342a','#b2bda2',1);K.text(c,'未 编 号',1288,533,21,'#d4d7b8','center','serif');if(l<3.55)for(let j=0;j<10;j++){let age=(l-2.8),xx=1235+j*11;K.rect(c,xx,557+age*74+(j%3)*6,2,2,'#a3b394');}c.restore();}break;
 case 3: if(!front){const lift=inOut(l,1.8,2.4,3.25,4.1);c.save();c.globalAlpha=.66;path(c,`M1009 556 C1090 ${547-65*lift} 1137 ${508-48*lift} 1194 549`,null,'#b4b79c',3);path(c,`M1010 561 C1090 ${557-65*lift} 1137 ${518-48*lift} 1195 554`,null,'#d0ccb5',2);for(let j=0;j<3;j++){let u=(l*.23+j/3)%1,x=1092+u*218,y=500-u*135;path(c,`M${x-5} ${y} q6 -6 13 0 q-7 6 -13 0Z`,'rgba(161,164,127,.45)');}c.restore();}break;
 case 4: if(front){const drift=(p.x-800)*.1;path(c,`M${34-drift} 899 Q${62-drift} 785 ${136-drift} 697`,null,'rgba(58,72,52,.42)',4);for(let j=0;j<12;j++){let x=80-drift+j*5,y=810-j*9;path(c,`M${x} ${y} l-27 -9 M${x} ${y} l25 -14`,null,'rgba(62,79,53,.45)',1);}}break;
 case 5: {
   const b=bridgeState(l,p);
   if(!front){const reach=inOut(l,2.25,2.85,3.55,4.0);merchant(c,b.merchantX,P.scenes[5].ground(b.merchantX)-3,reach,l,{x:b.x,y:b.y-25});}
   else{basket(c,b.x,b.y,1);if(l>2.43&&l<2.66){let u=(l-2.43)/.23;for(let j=0;j<4;j++)K.circle(c,b.touch-23+(j-2)*u*8,b.y+u*5,1,'#b9ad7d');}bellWave(c,p,(l-3.52)/.55,'#927b4c');if(l>3.2&&l<4.3)note(c,'鱼还在，路也还在。',b.merchantX-30,P.scenes[5].ground(b.merchantX)-184,'#81775c',17);}
 }break;
 case 6: if(front&&l>4.5){K.text(c,'每一圈，都算数。',1228,468,20,'#925834','center','serif');}break;
 case 7: if(!front){const a=inOut(l,2.0,2.65,3.6,4.35);c.save();c.globalAlpha=a*.56;for(let j=0;j<3;j++){const x=705+j*58;path(c,`M${x} 681 Q${x+36} ${570-j*16} ${x+82} 681`,null,'#c8e1ce',1.2);for(let n=0;n<5;n++){const u=(l*.7+n/5+j*.13)%1;K.circle(c,x+82*u,681-4*(53+j*8)*u*(1-u),1.2,'#e7ecda');}}c.restore();}break;
 case 8: if(front&&l>2&&l<4){const a=inOut(l,2,2.3,3.4,4);c.save();c.globalAlpha=a*.7;note(c,'（轻一点。）',1098,514,'#68725e',19);c.restore();}break;
 case 9: if(front){const a=inOut(l,1.8,2.4,4.2,4.7);c.save();c.globalAlpha=.5*a;path(c,`M1328 744 L${1328-125*a} 448 L${1348-125*a} 448 L1348 744Z`,'#4a291e');K.circle(c,1300-125*a,438,9,'#f4cd87');c.restore();}break;
 case 10: if(front){const u=K.clamp((l-2.45)/1.1),x=1184-90*Math.sin(u*Math.PI),y=630-87*Math.sin(u*Math.PI);if(l>=2.45&&l<3.55){c.save();c.translate(x,y);c.rotate(-.3+u*.5);path(c,'M-24 0 L0 -14 L27 0 Q3 8 -24 0Z','#c9b580','#335b61',1.1);for(let j=-2;j<=2;j++)line(c,[[j*9,1],[0,-12]],'#93845f',.7);c.restore();}}break;
 case 11: if(front){const a=inOut(l,3.8,4.1,5.3,5.9);if(a>0){c.save();c.globalAlpha=a*.65;K.circle(c,1100,573,17,null,'#e8d27b',1.1);c.restore();}}break;
 case 12: if(front&&l>4.15&&l<5.2){c.save();c.globalAlpha=inOut(l,4.15,4.3,4.9,5.2);note(c,'……借过。',1150,503,'#ead6aa',24);c.restore();}break;
 case 13: if(front&&l>4.15){c.save();c.globalAlpha=E((l-4.15)/.3);K.rect(c,1126,224,282,74,'#20292b','#9caa9e',1);note(c,'影子先下班了。',1267,271,'#c5c8af',24);c.restore();}break;
 case 14: if(front){const locked=l>=3.6;K.rect(c,675,789,260,30,'#cad7bd','#819c88',.8);K.circle(c,692,804,3.5,locked?'#39764e':'#a59754');K.text(c,locked?'X / Y 校准通过 · 继续前进':'先校准，再看清自己。',811,811,14,'#345f4b','center','mono');}break;
 case 15: {
   const z=P.pixelStoryContact(l),{hit,bx,by,knock}=z;
   if(!front){
    K.rect(c,bx,by-knock,48,48,l>=hit?'#bd9962':'#e6b657','#6d6a45',4);
    K.rect(c,bx+6,by+6-knock,36,4,'#f6d790');K.text(c,l<hit?'?':'·',bx+24,by+35-knock,33,'#fff3c4','center','mono','700');
   }else{
    if(l>hit&&l<z.land){K.rect(c,z.coin.x-5,z.coin.y-9,10,18,'#ffe38a','#c9963e',2);K.rect(c,z.coin.x-2,z.coin.y-5,3,10,'#fff7c9');}
    if(l>=z.land&&l<4.25){const bell=P.storyPoint(15,l,'bell'),u=(l-z.land)/.77;c.save();c.globalAlpha=1-u;K.circle(c,bell.x,bell.y-6,7,null,'#ffe28b',2);K.text(c,'DING! +100',bell.x+28,bell.y-38-u*25,21,'#fff3bd','center','mono','700');c.restore();}
   }
 }break;
 case 17: if(front&&l>3){const a=inOut(l,3,3.3,5.2,5.7);c.save();c.globalAlpha=a;K.text(c,'磁带可以重播。晚饭不等人。',950,281,20,'#f2c2da','center','mono');c.restore();}break;
 case 18: if(front&&l>3.20&&l<4.7){const a=inOut(l,3.2,3.42,4.4,4.7);c.save();c.beginPath();c.rect(524,48,432,768);c.clip();c.globalAlpha=a;K.rect(c,546,257,342,52,'rgba(45,36,33,.82)');P.castArt.riceBowl(c,568,282,.7);K.text(c,'大肥鱼：白饭到了，两碗都热！',595,280,12,'#fff0ce');K.text(c,'豆包：留一碗，它还要赶路。',595,299,11,'#e5d6c4');c.restore();}break;
 case 19: if(front&&l>3.1){const chosen=E((l-3.42)/.30);K.rect(c,1124,254,293,87,'#1d3034','#43666b',1);K.text(c,'destination:',1140,277,14,'#8daeb0','left','mono');K.text(c,chosen>.6?'"自己选的下一站"':'"展示区"',1140,303,19,chosen>.6?'#e6d093':'#c6d8d3');K.text(c,chosen>.6?'✓ 路已延长。无需重新画你。':'等待一次选择…',1140,326,12,'#87b6ac');}
 break;
 }
};
// More specific voices in the live chat; the four avatars are the same as the
// approved messenger scene, and the meal has an on-screen delivery payoff.
const live=P.scenes[18].foreground;
P.scenes[18].foreground=function(c,l,a,p){live.call(this,c,l,a,p);};
M.pixelBlockAnchor=function(){const a=P.storyPoint(15,M.pixelBlockHit,'crest');return a;};
P.storyRevision='R5 — shared consequences / 20 authored media';
})();
