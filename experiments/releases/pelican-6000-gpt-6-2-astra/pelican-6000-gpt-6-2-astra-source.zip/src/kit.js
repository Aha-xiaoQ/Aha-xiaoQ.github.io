/* Independent procedural animation. Shared, deterministic drawing primitives. */
const P = { W:1600, H:900, duration:137, scenes:[], cache:new Map() };
const K = {
  clamp:(v,a=0,b=1)=>Math.max(a,Math.min(b,v)),
  lerp:(a,b,t)=>a+(b-a)*t,
  ease:t=>{t=Math.max(0,Math.min(1,t));return t*t*(3-2*t);},
  smoother:t=>{t=Math.max(0,Math.min(1,t));return t*t*t*(t*(t*6-15)+10);},
  rnd:n=>{const v=Math.sin(n*127.1+311.7)*43758.5453;return v-Math.floor(v);},
  rect(c,x,y,w,h,fill,stroke,lw=1){if(fill){c.fillStyle=fill;c.fillRect(x,y,w,h);}if(stroke){c.strokeStyle=stroke;c.lineWidth=lw;c.strokeRect(x,y,w,h);}},
  line(c,pts,col='#222',lw=2,close=false,fill){c.beginPath();pts.forEach((p,i)=>i?c.lineTo(p[0],p[1]):c.moveTo(p[0],p[1]));if(close)c.closePath();if(fill){c.fillStyle=fill;c.fill();}if(col){c.strokeStyle=col;c.lineWidth=lw;c.lineCap='round';c.lineJoin='round';c.stroke();}},
  path(c,d,fill,stroke,lw=2){const p=new Path2D(d);if(fill){c.fillStyle=fill;c.fill(p);}if(stroke){c.strokeStyle=stroke;c.lineWidth=lw;c.lineCap='round';c.lineJoin='round';c.stroke(p);}},
  ellipse(c,x,y,rx,ry,fill,stroke,lw=2,rot=0){c.beginPath();c.ellipse(x,y,rx,ry,rot,0,Math.PI*2);if(fill){c.fillStyle=fill;c.fill();}if(stroke){c.strokeStyle=stroke;c.lineWidth=lw;c.stroke();}},
  circle(c,x,y,r,fill,stroke,lw=2){this.ellipse(c,x,y,r,r,fill,stroke,lw);},
  text(c,s,x,y,size=24,color='#222',align='left',family='sans',weight='400'){c.fillStyle=color;c.textAlign=align;c.textBaseline='alphabetic';c.font=`${weight} ${size}px ${family==='serif'?'"Noto Serif CJK SC", "Songti SC", SimSun, serif':family==='mono'?'"DejaVu Sans Mono", monospace':'"Noto Sans CJK SC", "Microsoft YaHei", sans-serif'}`;c.fillText(s,x,y);},
  gradient(c,a,b,stops){const g=c.createLinearGradient(...a,...b);stops.forEach(([p,col])=>g.addColorStop(p,col));return g;},
  grain(c,bg='#eee6d2',ink='rgba(70,45,18,.07)',count=1600){this.rect(c,0,0,1600,900,bg);c.fillStyle=ink;for(let j=0;j<count;j++){let x=this.rnd(j*3+1)*1600,y=this.rnd(j*3+2)*900,r=this.rnd(j*3+3)*2.5+.4;c.fillRect(x,y,r,r*.65);}},
  person(c,x,y,s=1,col='#40362e',look=1){c.save();c.translate(x,y);c.scale(s,s);this.circle(c,0,-43,8,col);this.line(c,[[0,-34],[2,-12],[-9,0]],col,4);this.line(c,[[2,-12],[12,0]],col,4);this.line(c,[[0,-29],[look*15,-20]],col,3);c.restore();},
  cloud(c,x,y,s,col){c.save();c.translate(x,y);c.scale(s,s);this.path(c,'M-60 10 Q-65 -12 -42 -16 Q-37 -49 -5 -34 Q15 -56 35 -29 Q65 -31 64 -6 Q85 18 50 22 L-40 22 Q-61 26 -60 10Z',col);c.restore();},
  cached(key,paint){if(!P.cache.has(key)){const density=key==='h-song-pure'?3:1,cvs=P.makeCanvas(1600*density,900*density),ctx=cvs.getContext('2d');ctx.scale(density,density);paint(ctx);P.cache.set(key,cvs);}return P.cache.get(key);},
  label(c,s,x,y,color='#463726'){this.text(c,s,x,y,22,color,'left','serif');},
  star(c,x,y,r,color,rot=0){let pts=[];for(let j=0;j<10;j++){let a=rot+j*Math.PI/5-Math.PI/2,rr=j%2?r*.42:r;pts.push([x+Math.cos(a)*rr,y+Math.sin(a)*rr]);}this.line(c,pts,null,1,true,color);}
};
