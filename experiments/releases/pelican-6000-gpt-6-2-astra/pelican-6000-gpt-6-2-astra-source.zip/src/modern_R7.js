/* Six thousand years: late rooms, the rider leaves a physical consequence.
   All effects are evaluated from the existing editorial/drive clock; no frame history. */
(()=>{
'use strict';
const D=P.finalDirector, TAU=Math.PI*2, E=K.smoother, L=K.lerp;
const gate=(u,a,b,c,d)=>E((u-a)/(b-a))*(1-E((u-c)/(d-c)));
// Work on the actual pasted pastel board, below the actors and framing.
// Grain direction is the tangent of each meandering ribbon, not a global filter.
const modernBg=M.bg;M.bg=function(c,key,paint){
 if(key!=='scream-r6-expression')return modernBg.call(M,c,key,paint);
 return modernBg.call(M,c,'r7-scream-oil-pastel',d=>{
  paint(d);d.save();d.clip(new Path2D('M-5 -5H1605V415 Q1390 474 1260 415 Q1108 362 975 405 Q819 386 581 455 L0 573Z'));
  const washes=['#742a38','#bf402b','#d76c2d','#e99548','#78313c','#f0ac5a','#94332f','#c46131','#e3a755'];
  const wax=['#e1993b','#edaf69','#ffd78b','#8a3345','#ae4837','#f5b77b','#e77e34','#e5ae75'];
  // 22 uneven pigment seams and strokes drawn by hand over their interstices.
  function wave(x,k){return -27+k*24.5+43*Math.sin(x*.0042+k*.112)+20*Math.sin(x*.0091+k*.16)+9*Math.sin(x*.0019+k*.48)}
  for(let k=0;k<24;k++){let top=[],btm=[];for(let x=-80;x<=1695;x+=22){let y=wave(x,k),h=12+9*Math.sin(x*.003+k*.65);top.push([x,y]);btm.push([x,y+h])}K.line(d,top.concat(btm.reverse()),null,1,true,washes[(k*5+2)%washes.length]);}
  d.lineCap='round';for(let j=0;j<7000;j++){let x=K.rnd(j*7+1)*1640-20,k=K.rnd(j*7+2)*23.5-1,y=wave(x,k)+2.6*Math.sin(j*12.2),len=3+22*K.rnd(j*7+3)**2,dy=wave(x+len,k)-wave(x,k),br=K.rnd(j*7+4);
   d.globalAlpha=.12+.41*br;d.strokeStyle=wax[(j*3+Math.floor(k+3))%wax.length];d.lineWidth=.45+K.rnd(j*7+5)*1.8;d.beginPath();d.moveTo(x,y);d.quadraticCurveTo(x+len*.53,y+dy*.48+(br-.5)*1.9,x+len,y+dy);d.stroke();
  }d.restore();
 });};
function stroke(c,lines,color,w){c.strokeStyle=color;c.lineWidth=w;c.beginPath();for(const pl of lines){if(pl.length<2)continue;c.moveTo(pl[0][0],pl[0][1]);for(let j=1;j<pl.length;j++)c.lineTo(pl[j][0],pl[j][1]);}c.stroke();}
function clipped(c,draw){c.save();try{draw()}finally{c.restore()}}
function wheel(p,dx){let s=p.scale||1,co=Math.cos(p.tilt||0),si=Math.sin(p.tilt||0);return{x:p.x+s*(dx*co-25*si),y:p.y+s*(dx*si+25*co),r:77*s}}
// Two stains in the paper. As the wheel passes through them its ink is printed
// upside down in broken horizontal keys, *before* the wheel breaks the water.
function onTheRoad(c,l,p){if(l<.8)return;let wet=E((l-.8)/1.7);for(const [x,y,w,h] of [[595,748,127,10],[991,747,102,9]]){
 clipped(c,()=>{c.translate(x,y);c.beginPath();c.moveTo(-w,0);c.bezierCurveTo(-w*.7,-h*.9,-w*.32,-h*.45,-w*.13,-h*.85);c.bezierCurveTo(w*.13,-h*1.6,w*.87,-h*.6,w,0);c.bezierCurveTo(w*.7,h*.6,-w*.2,h*.9,-w,0);c.clip();c.globalAlpha=.28*wet;K.rect(c,-w,-h*2,w*2,h*4,'#557c85');c.globalAlpha=.8*wet;for(let j=0;j<8;j++){let yy=j*2-h,ofs=3*Math.sin(l*5+j*.8);c.save();c.beginPath();c.rect(-w,yy,w*2,1.3);c.clip();c.translate(-x+ofs,0);c.scale(1,-.17);c.translate(0,-y);for(const dx of [-130,150]){let z=wheel(p,dx);K.circle(c,z.x,z.y,z.r,null,'#294f61',5);for(let k=0;k<6;k++){const a=p.wheelAngle+k*TAU/6;K.line(c,[[z.x,z.y],[z.x+z.r*Math.cos(a),z.y+z.r*Math.sin(a)]],'#325a65',1.8)}}c.restore()}});
 let front=wheel(p,150),behind=front.x-x;
 if(behind>-w&&behind<w+95){let k=E((behind+w)/32)*(1-E((behind-w)/90));clipped(c,()=>{c.globalAlpha=k*.85;for(let z=0;z<3;z++){let u=(behind+w+z*13)%64/64;let gx=Math.min(x+w,front.x)-u*64;K.path(c,`M${gx-5-u*15} ${y+1} q${8+u*10} ${-2-u*8} ${19+u*20} 0`,null,'#f3e8c7',1.6*(1-u)+.5)}});}
 }}
// The star that reached the clock is reflected in three distant roof planes.
function night(c,l){if(l<3.8)return;for(const [x,y,w] of [[1098,587,51],[1193,632,29],[1278,650,24]]){let u=(l-3.83-(x-1098)/340)/.8;if(u<=0||u>=1)continue;clipped(c,()=>{c.globalAlpha=Math.sin(u*Math.PI)*.75;c.lineCap='round';for(let k=0;k<6;k++){let bx=x+u*w-k*4;K.line(c,[[bx,y+u*13+k*1.5],[bx+5+k,y+u*13-1+k*1.5]],k%2?'#f3cd62':'#91aeb4',1.4)}})}}
// Hide old typography saying what the wall itself now shows? No image erasure:
// the scene owns its original title and switch. Work in the same local space
// as its silhouette. Spatially ordered re-ignition goes from bill to tail.
function wall(c,l){if(l<3.88)return;let a=83+l,q=M.silentShadow(Math.min(l,4.03),a),f=q.sp,u=E((l-3.88)/.76);
 let lines=M.traceContours({...q.motion,...f,headNod:q.headNod,brakeLean:q.brakeLean});
 let relay=E((l-4.84)/1.16),size=L(1,.082,relay),cx=f.x,cy=f.y-65;
 clipped(c,()=>{c.beginPath();c.rect(390,72,1210,674);c.clip();
 c.translate(L(cx,1600,relay),L(cy,705,relay)-54*Math.sin(relay*Math.PI));c.scale(size,size);c.translate(-cx,-cy);
 c.translate(f.x,q.foot);c.transform(1,0,-.095,1.2,0,0);c.translate(0,f.y-q.foot);c.rotate(f.tilt||0);c.scale(f.scale,f.scale);
 const min=259-u*532;c.beginPath();c.rect(min,-340,570,465);c.clip();c.lineJoin='round';c.lineCap='round';c.globalAlpha=.65+.24*E((l-4.34)/.76);
 stroke(c,lines,'rgba(44,198,132,.26)',8);stroke(c,lines,'#98e4ae',2.45);stroke(c,lines,'rgba(228,254,195,.8)',.84);
 if(u<.999){c.beginPath();c.rect(min-1,-320,12,447);c.clip();stroke(c,lines,'#eeffe1',4.3)}});
 // Current follows a single copper cable at the exit, no arbitrary particles.
 let v=E((l-4.50)/1.4);if(v>0){let wire=[[1245,416],[1378,416],[1404,443],[1404,578],[1530,705],[1600,705]];clipped(c,()=>{c.globalAlpha=.58;stroke(c,[wire],'#719a8b',1.4);M.tracePortion(c,[wire],0,v,'#91e2b0',2.1);if(v<.99){let light=M.tracePortion(c,[wire],Math.max(0,v-.09),v,'#f0ffd2',3.4);if(light)K.circle(c,...light,2.9,'#fcffe2')}})}
}
// Sample from a continuous-time phosphor, not random glow: for each earlier
// age reconstruct both wheel phase and deflection, then clip against the glass.
function phosphor(c,l,t,p){if(l<.12||l>5.7||p.x<378||p.x>1190)return;let original=P.sceneContext, traces=[];
 try{for(const age of [.099,.052,.021]){let prev=t-age,pl=D.local(14,prev),dp={...D.geometry(prev).p,...D.motionAt(prev)};let world=D.geometry(prev).worldX;dp.x=world-D.origins[14];
   P.sceneContext={...original,rider:dp,local:pl};traces.push({age,dp,lines:M.traceContours(dp)})}}
 finally{P.sceneContext=original}
 clipped(c,()=>{c.beginPath();c.arc(800,480,257,0,TAU);c.clip();c.globalCompositeOperation='screen';c.lineJoin='round';c.lineCap='round';
 for(const {age,dp,lines}of traces)clipped(c,()=>{c.translate(dp.x,dp.y);c.rotate(dp.tilt||0);c.scale(dp.scale,dp.scale);let alpha=age>.08?.085:age>.03?.135:.20;
 stroke(c,lines,'rgba(83,209,131,'+alpha+')',age>.08?1.5:.85)});
 });}
// Springboard rebound and landing live on the ground, independently of the
// vanishing score bubbles. Four cels spread from the tyre's actual touchdown.
function turf(c,l){let land=M.pixelLandT,u=(l-land)/.88;if(u<=0||u>=1)return;
 let hit=D.fromLegacy(5+15*6+land),x=D.geometry(hit).worldX-D.origins[15]+150*D.geometry(hit).p.scale;
 const frame=Math.floor(u*10);for(let k=0;k<6;k++){let start=frame-k;if(start<0)continue;let col=k%3?'#b8d786':'#f0d99d',hop=Math.max(0,1-Math.pow((start-2)/2,2));if(!hop)continue;let xx=Math.round((x+k*17)/4)*4,y=726-4*Math.round(hop*(6-k)*.65);K.rect(c,xx-8,y,16,4,col);K.rect(c,xx-4,y+4,12,4,'#53905d');K.rect(c,xx+4,y-4,4,4,'#e3e39b')}}
// The capstan pulls a loose ribbon out of the cassette on a repeat. It
// unspools in the same four 0.25 s units as the printed wheels and score.
function tape(c,l){let a=gate(l,.8,1.5,4.15,4.8);if(!a)return;
 let k=l>=2&&l<3?Math.floor((l-2)*4):l>=3?4:0,stroke=l>=2&&l<3?((l-2)*4)%1:0,slack=11+k*15+Math.sin(stroke*Math.PI)*7;
 slack*=1-E((l-3.05)/1.15);
 clipped(c,()=>{c.globalAlpha=a*.96;let d=`M219 775 C242 783 237 ${781+slack} 264 ${782+slack} S321 783 299 767 Q286 756 271 765`;K.path(c,d,null,'#181338',5.6);K.path(c,d,null,'#d992b9',2.8);K.path(c,d,null,'#f5b6cd',.8);});
}
const prevDetails=P.storyDetails;P.storyDetails=function(c,i,l,t,p,front){prevDetails(c,i,l,t,p,front);if(!p||i<10)return;
 if(!front){if(i===10)onTheRoad(c,l,p);else if(i===11)night(c,l);else if(i===13)wall(c,l);else if(i===17)tape(c,l);}
 else if(i===14)phosphor(c,l,t,p);else if(i===15)turf(c,l);
};
// During the animated attachment loop the chat janitor folds the lower-right
// corner of the image into a door. It opens exactly when the raw file opens.
const prevChat=D.drawChat;D.drawChat=function(c,t,front,p){prevChat(c,t,front,p);if(!front)return;let sec=t-D.starts[16],u=sec-3;if(u<10.25||u>15.65)return;
 const v=D.chatState(sec).viewport,w=E((u-10.25)/2.9)*(1-E((u-14.35)/1.3)),n=w*(20+12*E((u-13)/1.1));if(n<.05)return;
 let x=v.x+v.w-2,y=v.y+v.h-2;K.path(c,`M${x-n} ${y} Q${x-1} ${y-4} ${x} ${y-n} L${x} ${y}Z`,'#8396a4');
 K.path(c,`M${x-n} ${y} Q${x-n*.46} ${y-n*.48} ${x} ${y-n} Q${x-n*.72} ${y-n*.83} ${x-n} ${y}Z`,'#e8f4f7','#7894a4',.85)
};
// Two focal distances. The optical move is an absolute-time function, not an
// eased simulation: scrubbing and nonsequential render workers agree.
const oldRoad=D.renderRoad;D.renderRoad=function(c,t){let i=D.locate(t),l=D.local(i,t),z=1,x=800,y=450;
 if(i===11){let e=gate(l,.24,1.68,3.72,5.82);z+=.19*e;x=746;y=530}
 if(i===13){let e=gate(l,.65,2.72,4.54,5.88);z+=.21*e;x=860;y=474}
 if(i===15){let e=gate(l,.95,2.72,3.72,5.50);z+=.13*e;x=790;y=480}
 if(i===19){let e=gate(l,2.80,3.30,3.66,4.36);z+=.09*e;x=770;y=528}
 clipped(c,()=>{c.translate(x,y);c.scale(z,z);c.translate(-x,-y);oldRoad(c,t)})
};
})();
