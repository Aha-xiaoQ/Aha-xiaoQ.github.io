/* R7 · the sitter leaves the plate. Everything is drawn from the live rig;
   never sample a frame of an external film. Host coordinate space: 1600 × 900. */
(()=>{
'use strict';
const D=P.finalDirector, TAU=Math.PI*2, E=K.smoother, L=K.lerp;
const w=(x,a,b,c,d)=>E((x-a)/(b-a))*(1-E((x-c)/(d-c)));
const stroke=(c,d,k,n=1)=>K.path(c,d,null,k,n);
// A glance leads a turn of the head. Transfer weight at the pelvis (the R6
// rig shears about y=-112); never spin a wheel or move either foot by hand.
// Individual cues rather than a perpetual sinusoid through all twenty works.
const beats={
 0:[[1.30,1.79,2.17,2.82,-.105,-.72,-.28,.00],[2.7,2.98,3.14,3.58,.105,1,.36,.13]],
 2:[[2.77,3.05,3.35,3.8,.09,-.65,.75,.12]],
 3:[[1.36,1.77,2,2.4,-.095,.63,-.9,.12],[3.27,3.54,3.85,4.25,-.07,.8,-.6,0]],
 4:[[.35,.94,1.38,2.25,-.095,.62,-.75,0]],
 5:[[1.58,1.94,2.20,2.43,.12,-.04,.97,.25],[3.17,3.38,3.68,4.05,-.09,-.75,-.58,.17]],
 6:[[1.66,1.93,2.39,2.80,.125,.13,.96,.14]],
 7:[[1.36,1.70,2.06,2.47,-.1,.72,-.75,0],[3.43,3.66,3.82,4.23,.14,.86,.36,.07]],
 8:[[2.05,2.38,3.14,3.67,-.12,-.86,-.68,0]],
 9:[[2.4,2.72,2.95,3.37,.12,.7,-.63,.22]],
 10:[[1.62,2.05,2.31,2.65,-.12,.64,-.89,.08],[3.46,3.73,4.02,4.52,.105,-.48,.54,.04]],
 11:[[2.56,2.86,3.24,3.77,.14,-.05,.96,.14],[3.91,4.12,4.31,4.61,-.09,.78,-.75,0]],
 12:[[1.93,2.2,2.41,2.69,.11,.7,-.8,.25],[3.01,3.21,3.43,3.83,-.1,-.46,-.7,.21]],
 15:[[1.18,1.62,1.85,2.30,.11,.53,.64,.38],[3.57,3.78,4.0,4.22,.10,.55,.74,.27]],
 18:[[2.80,3.17,3.57,4.01,.16,.2,.91,.19]],
 19:[[1.75,2.16,2.67,3.00,-.08,-.74,-.44,0],[3.69,3.94,4.13,4.45,.08,.93,.15,.12]]
};
const poseBefore=P.nativePose;
P.nativePose=function(i,l,t){
 const q=poseBefore(i,l,t);if(!beats[i])return q;
 let h=q.headNod||0,x=q.gazeX??.75,y=q.gazeY||0,lean=q.brakeLean||0;
 for(const [a,b,c,d,n,gx,gy,m] of beats[i]){const u=w(l,a,b,c,d),v=w(l,a-.14,b-.13,c-.05,d-.11);h+=n*u;x=L(x,gx,v);y=L(y,gy,v);lean+=m*w(l,a+.065,b+.08,c+.09,d+.13);}
 q.headNod=K.clamp(h,-.3,.30);q.gazeX=x;q.gazeY=y;q.brakeLean=K.clamp(lean);return q;
};
const pressPoseBefore=D.pressPose;
D.pressPose=function(u){const q=pressPoseBefore(u),cable=w(u,8.59,9.18,10.17,10.73),thanks=w(u,11.23,11.46,11.54,11.90);q.headNod=(q.headNod||0)+.185*cable+.16*thanks;q.gazeY=.79*cable-.22*thanks;q.gazeX=L(1,.49,cable);q.brakeLean=.29*w(u,9.05,9.55,10.12,10.58);return q};
// Feather groups form one overlapping fan, not a field of equally spaced
// strokes. The last three primaries can flex several units behind the wrist,
// which remains anchored on the grip. A matrix follows the R6 shoulder drag.
const baseRider=P.drawRider;
const paint={
 0:['#955031','#ce8752','#6e3926'],1:['#28736f','#d6b25c','#3c534b'],
 2:['#41473b','#c6c4a9','#70725d'],3:['#b9b5a6','#f2ead4','#605f54'],
 4:['#868e7c','#e2ddca','#515d4f'],5:['#979a79','#ded7ae','#686c53'],
 6:['#4f8075','#e9c37d','#784932'],7:['#6c969e','#ddbe78','#596e75'],
 8:['#646b5b','#d8d7c7','#373f35'],9:['#925c34','#eac787','#744825'],
 10:['#557a83','#cdbf9d','#355b6c'],11:['#527596','#f3d580','#365982'],
 12:['#9a795f','#d5a178','#745e59'],17:['#7775a7','#edb7ce','#5f638d'],
 18:['#77959a','#f5d9a8','#4e6c74'],19:['#7fada8','#dfedde','#69908e']};
const wingPath=new Path2D(P.characterSkin.wing);
const featherTypes=[[-94,-179,36,19,5.9],[-84,-184,44,22,6.8],[-72,-183,51,25,7],[-61,-178,56,24,6.6],[-48,-173,58,22,5.6],[-32,-165,57,17,5.0],[-14,-156,55,13,3.8],[5,-148,53,10,3.1]];
function vane(c,x,y,dx,dy,bend,width,cs,j,i){
 const k=dy+ bend;
 c.beginPath();c.moveTo(x,y);c.bezierCurveTo(x+dx*.17,y+width*.95,x+dx*.6,y+k*.90+width*.74,x+dx,y+k);
 c.bezierCurveTo(x+dx*.55,y+k*.67-width*.5,x+dx*.18,y-width*.85,x,y);c.fillStyle=cs[0];c.globalAlpha*= i===3?.22:i===8?.42:.72;c.fill();
 c.beginPath();c.moveTo(x+2,y+.4);c.quadraticCurveTo(x+dx*.53,y+k*.80,x+dx-1.2,y+k-.25);c.strokeStyle=cs[2];c.lineWidth=i===8?1.5:i===11?1.45:.85;c.stroke();
 if([1,6,7,9,10,11,17,18,19].includes(i)){c.beginPath();c.moveTo(x+dx*.28,y+k*.28);c.quadraticCurveTo(x+dx*.68,y+k*.83,x+dx*.92,y+k);c.strokeStyle=cs[1];c.lineWidth=i===11?2:1.3;c.stroke();}
}
P.drawRider=function(c,t,opts={}){
 baseRider(c,t,opts);
 const i=typeof opts.style==='number'?opts.style:P.riderGeometry.styleNames.indexOf(opts.style??'short');
 if(!paint[i]||!(opts.scale>.27)||!((opts.alpha??1)>.025)||(opts.build??1)<.999)return;
 const phase=opts.crankAngle??t*TAU, flow=i===1?0:Math.min(1,Math.abs(opts.speed||0)*.004);let a=opts.alpha??1;
 // A fixed Egypt imprint uses a temporary pigment palette, and must stay a
 // single-tone trace after the living rider has moved on.
 if(i===1&&P.riderGeometry.palettes[1][0]==='#9f6841')return;
 const cs=paint[i],lean=K.clamp(opts.brakeLean||0)*.16;
 c.save();c.globalAlpha*=a;c.translate(opts.x??800,opts.y??600);c.rotate(opts.tilt||0);c.scale(opts.scale,opts.scale);
 c.save();c.transform(1,0,lean*.7,1,112*lean*.7,0);c.clip(wingPath);
 for(let j=0;j<featherTypes.length;j++){let [x,y,dx,dy,b]=featherTypes[j];let sw=(.5+.5*j/7)*(.65+flow)*Math.sin(phase-j*.24)*1.5;
  c.save();vane(c,x,y,dx,dy,sw,b,cs,j,i);c.restore();}
 if(i===1||i===6||i===7||i===9){for(let j=0;j<9;j++){const x=-94+j*8.3,y=-185+j*3.86;
   c.save();c.translate(x,y);c.rotate(.42);if(i===9){c.beginPath();c.moveTo(0,-2.5);c.quadraticCurveTo(4.5,0,0,2.5);c.quadraticCurveTo(-4.5,0,0,-2.5);c.fillStyle=cs[1];c.fill();}
   else if(i===1||i===6){K.path(c,'M-2.5 -1.5 L2.5 -1.5 L1.1 1.6 L-3.4 1.4Z',cs[1]);}else{K.circle(c,0,0,1.3,cs[1]);}c.restore();}}
 c.restore();c.restore();
};
// The "documentary evidence" is an actual engraved leaf with deckled edges,
// guide lines and a burnished blank under the illustration. After the sketch
// rolls away, the traveller has left two slightly misregistered pigment marks.
// The plate and tyre traces have paper coordinates, not coordinates on the bird.
P.introRoom=function(c,t){
 const key='r7-naturalists-leaf';c.drawImage(K.cached(key,d=>{
 const bg=d.createLinearGradient(0,0,1550,880);bg.addColorStop(0,'#f3eddf');bg.addColorStop(.48,'#e9dfca');bg.addColorStop(1,'#d9c8a8');K.rect(d,0,0,1600,900,bg);
 for(let i=0;i<9300;i++){const x=K.rnd(i*7+39)*1600,y=K.rnd(i*5+96)*900,v=K.rnd(i+403);K.line(d,[[x,y],[x+1.2+v*5,y-.1-v*.75]],i%7?'rgba(111,87,52,.055)':'rgba(254,250,223,.30)',.45+v*.4);}
 for(const [pad,alpha] of [[49,.42],[55,.24]])K.rect(d,pad,54+pad/14,1600-2*pad,786,null,'rgba(94,74,50,'+alpha+')',1);
 K.line(d,[[111,142],[648,142]],'#a98a62',1);K.text(d,'借过一下',107,122,40,'#41372a','left','serif','600');
 K.text(d,'A PELICAN, ON HIS WAY',110,174,14,'#807054','left','mono');
 const x0=817,y0=137,X=1461,Y=716;
 K.path(d,'M818 138 L1462 136 L1464 712 L826 719Z','rgba(108,82,45,.16)');
 K.path(d,'M816 136 L1460 133 L1461 708 L823 715Z','#efe7d3','#b3a48b',1.3);
 for(let j=0;j<1000;j++){const x=x0+5+K.rnd(j*17)*631,y=y0+5+K.rnd(j*19)*552;K.line(d,[[x,y],[x+4,y-2]],'rgba(111,90,65,.075)',.65);}
 for(let j=0;j<17;j++){let e=j%2?4:2;K.line(d,[[872+j*31,654],[872+j*31,654+e]],'#b4aa90',.7);}
 for(const [x,y,sgn] of [[x0+14,y0+15,1],[X-16,y0+13,-1]]){K.line(d,[[x,y+12],[x,y],[x+sgn*12,y]],'#ad9d80',.7);}
 K.line(d,[[109,732],[683,732]],'#ac9675',1);
 K.text(d,'《鹈鹕骑行艺术通史》卷一 · 虚构',110,771,18,'#8a795b','left','serif');
 K.text(d,'图一　鹈鹕骑行图（摹本）',1139,754,18,'#6b604e','center','serif');
 K.text(d,'PL.  I',847,176,12,'#9e8c6d','left','mono');
 for(const [x,y] of [[110,813],[1492,96]]){K.circle(d,x,y,2,'#b29a75');K.circle(d,x,y,6,null,'#b29a75',.5);}
 }),0,0);
 c.save();c.globalAlpha=E((t-.06)/.52);K.text(c,'人类自古以来就痴迷于',109,304,41,'#443729','left','serif','600');
 K.text(c,'画鹈鹕骑自行车。',106,378,57,'#302b22','left','serif','700');c.restore();
 c.save();c.globalAlpha=E((t-1.93)/.24);K.text(c,'——早在自行车被发明之前。',108,480,34,'#934c3c','left','serif');c.restore();
 const road=[];for(let x=0;x<=1600;x+=7)road.push([x,P.longFloor(x-1600,t)]);c.save();c.beginPath();c.rect(820,130,790,640);c.clip();K.line(c,road,'#827254',1.3);
 const run=E((t-2.4)/1.95);if(run>0){const q=K.lerp(998,1484,run);for(let x=1000;x<q;x+=10.6){let y=P.longFloor(x-1600,t)+1;K.line(c,[[x,y+1],[x+5.4,y+.5]],'rgba(70,52,37,.38)',1.5);}}
 c.restore();
};
// A positive print develops on the camera's own paper. Its picture is sampled
// from this exact press set at the first exposure (only our program's drawing);
// unlike a hard-coded icon it contains the correct chair, desk, and lens angles.
const oldFront=P.pressForeground;let negative=null;
function positive(){
 if(negative)return negative;
 const cv=P.makeCanvas(1280,686),g=cv.getContext('2d');g.translate(-160,-150);
 P.pressBackground(g,P.pressFlashTimes[0]-.13);oldFront(g,P.pressFlashTimes[0]-.13);
 negative=cv;return cv;
}
P.pressForeground=function(c,t){
 oldFront(c,t);const u=(t-125)*4/3;if(u<=12.05)return;
 const e=E((u-12.05)/1.30),settle=E((u-13.35)/.44),x=259,y=781;
 // The paper stays in the physical slot next to the fixed camera. Never let
 // a paper or a disembodied hand float over the middle of the conference.
 c.save();c.translate(x,y);c.rotate(-.055*(1-settle));const zoom=1.18;c.scale(zoom,zoom);
 const height=76*e;c.save();c.beginPath();c.rect(0,-height,131,height);c.clip();
 c.translate(0,-height);
 K.rect(c,2,2,129,75,'rgba(30,46,38,.27)');K.rect(c,0,0,128,74,'#f4ebd2','#a39b85',.85);
 K.rect(c,5,4,118,62,'#eee2c9');c.save();c.globalAlpha=.88*E((u-12.25)/1.38);c.drawImage(positive(),5,4,118,62);c.restore();
 K.line(c,[[11,69],[22,69]],'#827b68',.7);c.restore();
 K.path(c,'M0 1 L3 -2 H128 L132 1 L127 6 H4Z','#5b746c','#3d5653',.9);
 c.restore();
};
// Match cut after the actual rider has passed the edge (not a second rider
// or a replay). The only "documentary" photograph of her is the empty chair.
// The first plate said "copy"; the second says "photograph". No separate
// explanation is needed. Maintain >1 s of legibility at the end of the roll.
const oldOutro=D.outroDraw;
D.outroDraw=function(c,u){
 if(u<14.73){oldOutro(c,u);return;}
 c.save();K.rect(c,0,0,1600,900,'#313c38');
 const lift=E((u-14.73)/.44);c.translate(800,450);c.rotate(L(-.067,-.056,lift));
 const z=L(.949,1,lift);c.scale(z,z);K.rect(c,-638,-385,1304,802,'rgba(15,23,22,.38)');
 K.rect(c,-651,-399,1300,798,'#eee5ce','#b5ae98',1.7);
 c.drawImage(positive(),-618,-365,1233,661);
 for(let j=0;j<13;j++){const xx=-604+j*96;K.line(c,[[xx,301],[xx+15,301]],'rgba(112,106,83,.22)',.55);}
 K.text(c,'图二　鹈鹕骑行图（实拍）',-610,359,25,'#695e4c','left','serif');
 K.text(c,'PL.  XXI',608,359,16,'#82765f','right','mono');c.restore();
};
P.performanceR7={beats,physicalBase:'R6 two-wheel arclength; original two-link legs, crank and saddle',proofExposure:P.pressFlashTimes[0]};
})();
