/* Two changes of medium: a GIF projected in a harbour dispatch office,
   followed by the machine which draws its own engineering print. */
(()=>{
'use strict';
const D=P.finalDirector, rect=K.rect.bind(K),ln=K.line.bind(K),path=K.path.bind(K),txt=K.text.bind(K),circ=K.circle.bind(K),ell=K.ellipse.bind(K);
const clip=(c,x,y,w,h)=>{c.beginPath();c.rect(x,y,w,h);c.clip();};
const mono=(c,s,x,y,n,col,align='left')=>txt(c,s,x,y,n,col,align,'mono');
const face=(c,s,x,y,n,col,align='left')=>txt(c,s,x,y,n,col,align,'sans','600');
const times=P.castStudy.messages;
const names={fish:'大肥鱼',gpt:'GPT',claude:'Claude',doubao:'豆包'};
const hues={fish:'#62aeac',gpt:'#b399c9',claude:'#d19769',doubao:'#ce7c71'};
function rounded(c,x,y,w,h,r,fill,edge,lw=1){
 c.beginPath();c.roundRect(x,y,w,h,r);if(fill){c.fillStyle=fill;c.fill();}if(edge){c.strokeStyle=edge;c.lineWidth=lw;c.stroke();}
}
function gradient(c,y,Y,colors){return K.gradient(c,[0,y],[0,Y],colors);}
function screw(c,x,y){circ(c,x,y,5,'#a39e8a','#504d42',1);ln(c,[[x-2.7,y+2],[x+2.7,y-2]],'#47473e',1.3);}
function print(c,x,y,text,size,color,width){const rows=[];let row='';c.font='600 '+size+'px "Microsoft YaHei",sans-serif';
 for(const ch of text){if(row&&c.measureText(row+ch).width>width){rows.push(row);row='';}row+=ch;}if(row)rows.push(row);
 rows.forEach((s,j)=>face(c,s,x,y+size*1.5*j,size,color));return rows.length;
}
const icons={
 fish:['...aa........aa.','..aaaa......aaaa','.aaacccaaaacccaa','..accccbcccccca.','..acbccbbcbbcca.','..acdddccdddcca.','...ddabddabddc..','...dddddddddca..','..ccdddeedddcca.','.cccaddddddaacca','..aaeggddggeaa..','..eefggggggfee..','..efffgffgfffe..','....ffffffff....'],
 gpt:['b............b..','.ba.........ab..','.bcbaabbbbabcb..','..bcccccccccb...','..bcbcccccbcb...','...cddcbccddc...','..cddabddbadcc..','..cdddddddddcc..','..ccdddeeddcc...','..ccaaddddaacc..','....aggbbgga....','...agbbbbbbga...','..gggggggggggg..','...bbbbbbbbbb...'],
 claude:['.....aaaaaa.....','...aabbabbaba...','..abbbabbbbaba..','.abbbabddbababa.','..abdddddabbaaa.','..bbdadddadbba..','...bddbddbddb...','..abddddedddba..','...abaddddabaa..','.....abddba.....','...afggeeggfa...','..aaffgeegffaa..','..fffffggfffff..','...gggggggggg...'],
 doubao:['......aaaaa.....','...aaabbbbbbaa..','..abbbbbbebbbba.','.abbbbaaeebbbba.','.abbbadddabbbba.','..bcddddddddbc..','..bddabddbadba..','..abdddddddda...','...aaddeeddaa...','.....adddda.....','....geeeeeeeg...','..ggeeegeeeegg..','..ggggeggeeggg..','...gggggggegg...']
};
function portrait(c,x,y,id,s){
 const cols={a:'#342f3c',b:id==='gpt'?'#bdb7d1':id==='claude'?'#af664b':'#5c627a',c:hues[id],d:'#f0b78e',e:'#bd624f',f:'#f3dfac',g:'#4a6974'};
 const rows=icons[id];for(let j=0;j<rows.length;j++)for(let i=0;i<rows[j].length;i++){let v=cols[rows[j][i]];if(v)rect(c,x+i*s,y+j*s,s,s,v);}
}
function bodyOfTerminal(c){
 rect(c,0,0,1600,900,gradient(c,0,900,[[0,'#172b35'],[.68,'#263c42'],[.72,'#65533f'],[1,'#332820']]));
 // Evening light falling through the office blinds.
 for(let i=0;i<12;i++){let y=20+i*55;path(c,'M0 '+y+' L1600 '+(y-84)+' v13 L0 '+(y+27)+'Z','rgba(218,172,107,.095)');}
 for(let i=0;i<10;i++){let y=724+i*20;ln(c,[[0,y],[615,y-4],[1060,y+4],[1600,y-7]],'#514334',1);}
 rounded(c,20,64,1028,638,36,'#121d23');
 rounded(c,12,47,1027,637,34,gradient(c,47,684,[[0,'#e2d2a9'],[.045,'#c9b793'],[.62,'#ada181'],[1,'#827b68']]),'#514e42',3);
 rounded(c,37,74,978,512,27,'#726f5c','#eee2bb',2);rounded(c,48,84,957,486,22,'#28312c','#5d6253',4);
 rounded(c,64,101,927,451,16,gradient(c,101,552,[[0,'#182b27'],[.55,'#22352a'],[1,'#172923']]));
 for(let y=111;y<549;y+=5)ln(c,[[73,y],[981,y]],'rgba(163,189,132,.035)',1);
 for(const x of [39,1012])for(const y of [71,661])screw(c,x,y);
 for(let j=0;j<12;j++)rounded(c,68+j*12,606,6,22,2,'#635f50');
 rect(c,271,603,109,25,'#6c6756');rect(c,276,608,99,15,'#8c8971');mono(c,'W / 204',285,620,11,'#e9d9ab');
 rounded(c,843,603,94,33,5,'#897d63','#4e4d42',1.5);circ(c,959,618,5,'#e5a74a');circ(c,958,616,1.8,'#f9dc89');
 // Workstation base, patch cords and the glazed keys on the table.
 path(c,'M249 682 H774 L798 725 H229Z','#8b816c','#5b584a',2);
 path(c,'M20 755 L737 744 L810 838 L47 863Z','#c1ad8a','#514c40',3);
 for(let j=0;j<4;j++)for(let k=0;k<15;k++){let x=46+k*46+j*5,y=767+j*20-k*.45;path(c,'M'+x+' '+y+' l37 -1 5 13 -38 2Z',j===3&&k>2&&k<10?'#b8996c':'#d7c6a4','#776d58',1);}
 path(c,'M808 831 Q874 804 834 772 Q800 738 883 726 Q937 723 932 680',null,'#252e2a',5);
 rounded(c,843,797,75,57,24,'#b9a984','#504a3d',2);ln(c,[[876,799],[877,821]],'#807860',1.4);
 // Separate enamel-cased attachment projector houses the openable right edge.
 rounded(c,1055,142,507,611,15,'#161f25','#334247',3);
 rounded(c,1046,127,510,616,16,gradient(c,127,745,[[0,'#797e71'],[.08,'#59716c'],[.7,'#455d59'],[1,'#344844']]),'#262d2a',3);
 for(const x of [1060,1538])for(const y of [144,730])screw(c,x,y);
 mono(c,'PORT  /  02',1077,164,16,'#efe0b2');face(c,'附件放映机',1525,164,17,'#dfdfc2','right');
 rect(c,1065,178,483,512,'#232c2b','#a3a389',1.5);
}
function docks(c,x,y,w,h){
 c.save();clip(c,x,y,w,h);c.translate(x,y);
 rect(c,0,0,w,h,gradient(c,0,h,[[0,'#1e3449'],[.47,'#4c6d77'],[.69,'#bd9379'],[.72,'#5b7979'],[1,'#2a5358']]));
 const moonX=w*.79;circ(c,moonX,74,22,'#f3cf90');circ(c,moonX-7,69,19,'#334c5c');
 for(let i=0;i<32;i++){const xx=K.rnd(i+75)*w,yy=K.rnd(i+319)*156;rect(c,xx,yy,i%4===0?2.5:1.3,1.5,'#d1ccac');}
 const floor=321;
 for(let j=0;j<20;j++){
  let xx=j*26-9,ww=18+Math.floor(K.rnd(j+76)*24),hh=19+Math.floor(K.rnd(j+22)*72);
  rect(c,xx,floor-hh,ww,hh,'#415b62');path(c,'M'+(xx-3)+' '+(floor-hh)+' l'+(ww*.54)+' -12 '+(ww*.54)+' 12Z','#384f58');
  if(j%2)for(let k=0;k<2;k++)rect(c,xx+5+k*8,floor-hh+11,3,5,'#c5b48b');
 }
 for(let k=0;k<3;k++){
  const xx=36+k*170,yy=316,cc=['#344c52','#405a5c','#334e54'][k];
  path(c,'M'+xx+' '+yy+' v-93 l9 -12 8 108 M'+(xx+5)+' '+(yy-90)+' l57 -34 43 9 -91 28',null,cc,3);
  ln(c,[[xx+61,yy-119],[xx+62,yy-68]],cc,1);ln(c,[[xx-15,yy+1],[xx+24,yy+1]],cc,3);
 }
 rect(c,0,319,w,5,'#6a7670');
 for(let i=0;i<210;i++){let xx=K.rnd(i+839)*w,yy=327+K.rnd(i+149)*133;
  rect(c,xx,yy,2+K.rnd(i+935)*22,1.1,i%4?'rgba(208,186,149,.23)':'#819b93');}
 // foreground bollards imply the scale of the miniature harbour
 for(let j=0;j<5;j++){let xx=24+j*111;rect(c,xx,431,6,34,'#31494b');rect(c,xx-2,429,10,5,'#c39e72');
  if(j<4)path(c,'M'+(xx+3)+' 434 q56 23 111 0',null,'#4b5d56',1.3);}
 c.restore();
}
function ticket(c,t){
 const latest=times.reduce((v,m)=>m.at<=t?m:v,null),i=latest?times.indexOf(latest):-1;
 face(c,'港口通信室',99,164,42,'#e4d6a1');mono(c,'PACKET RADIO  /  2009',968,157,16,'#a6b48e','right');
 ln(c,[[97,184],[958,184]],'#627a5c',1.2);
 const ids=['fish','gpt','doubao','claude'];
 ids.forEach((id,k)=>{let x=108+k*209,selected=latest?.id===id;
  rect(c,x,202,195,39,selected?'#465948':'#243c32');circ(c,x+15,222,3.5,selected?'#f2c475':'#86a37b');
  face(c,names[id],x+28,228,17,selected?'#f0dca0':'#9cae90');});
 if(latest){
  const y=285,age=t-latest.at,pulse=K.ease(age/.15);c.save();c.globalAlpha=pulse;
  rect(c,102,y,113,115,'#3a4c40','#708065',1);
  portrait(c,109,y+14,latest.id,6.2);
  face(c,names[latest.id],244,310,24,'#e2c17e');mono(c,'RX '+String(i+1).padStart(2,'0'),937,307,17,'#9dad8c','right');
  const n=print(c,244,365,latest.text,30,'#f4e6b0',685);
  if(latest.detail)txt(c,latest.detail,246,371+n*41,18,'#a4b695','left','sans');
  c.restore();
 }else{
  for(let i=0;i<6;i++)rect(c,107+i*22,326,13,13,i<=Math.floor(t*12)%7?'#d9b674':'#405643');
  face(c,'收到一个骑车的附件。',113,401,30,'#e7d8a0');
 }
 ln(c,[[100,489],[952,489]],'#5d7459',1);
 const typing=t>=6.6&&t<7.8?'豆包正在输入…':t>=11&&t<12?'Claude 正在取原文件…':t>=21&&t<22?'GPT 正在复核…':'鹈鹕围观群';
 txt(c,typing,103,523,18,'#aec198');mono(c,'20:00:'+String(Math.floor(t)).padStart(2,'0'),954,522,17,'#8f9e7f','right');
}
function shortRoad(c,x1,x2){
 rect(c,x1,652,x2-x1,28,'#776757');rect(c,x1,651,x2-x1,4,'#d1b998');
 for(let x=x1+8;x<x2;x+=26){ln(c,[[x,656],[x-6,677]],'#514b42',1.25);}
}
function mealStand(c){
 rect(c,1600,0,800,900,gradient(c,0,900,[[0,'#172c3f'],[.55,'#466778'],[.72,'#677476'],[1,'#333e3f']]));
 docks(c,1600,160,800,497);
 const x=1780;path(c,'M1690 486 L1728 440 H2238 L2290 486Z','#94473c','#3f3935',3);
 for(let j=0;j<14;j++){let xx=1695+j*42;path(c,'M'+xx+' 487 h40 v15 q-16 15 -39 0Z',j%2?'#e9c99b':'#aa5545','#694d3e',1);}
 for(let xx of [1712,2256])rect(c,xx,497,9,156,'#5e5144');
 rect(c,1712,599,552,9,'#d6b48c','#594c3f',2);rect(c,1722,608,535,45,'#80624f');
 rect(c,x+28,509,189,47,'#ece0be','#6c6652',2);face(c,'深夜饭档',x+121,543,25,'#5d5141','center');
 for(let i=0;i<2;i++){let xx=2058+i*80;path(c,'M'+(xx-28)+' 579 q26 -26 53 0 q-2 20 -26 22 q-23 -2 -27 -22Z','#e3c8a2','#6a5e4c',2);
  ell(c,xx,578,26,8,'#f1e7c8','#9f8a69',1.3);for(let j=0;j<7;j++)ell(c,xx-14+j*5,576-(j%3)*2,4,1.8,'#fff2d0');}
 shortRoad(c,1598,2400);
}
function media(c,t,s){
 const v=s.viewport;docks(c,v.x,v.y,v.w,v.h);shortRoad(c,v.x,v.x+v.w);
 // The harbour lamp and launch repeat the same 2.4-second loop as the GIF.
 // Opening the source gives them the same continuing clock as the courier.
 const clock=s.opened?t:t%P.castStudy.loopPeriod;
 c.save();clip(c,v.x,v.y,v.w,v.h);
 const lampX=v.x+52,lampY=v.y+233;
 path(c,'M'+(lampX-7)+' '+(lampY+66)+' l3 -65 h8 l4 65Z','#e1bb88','#4e6360',1.2);
 rect(c,lampX-6,lampY-8,13,11,'#e0b77e','#394f54',1);
 path(c,'M'+(lampX-10)+' '+(lampY-8)+' l10 -7 12 7Z','#935948');
 const wave=Math.cos(clock*2*Math.PI/P.castStudy.loopPeriod);
 c.save();c.translate(lampX,lampY-3);c.scale(wave,1);
 path(c,'M0 0 L232 -13 L232 12 Z',K.gradient(c,[0,0],[232,0],[[0,'rgba(255,221,151,.62)'],[1,'rgba(255,220,158,0)']]));c.restore();
 const boatX=v.x+231+52*(s.opened?Math.sin((clock-13.8)*.41+.73):clock/P.castStudy.loopPeriod),boatY=v.y+362;
 path(c,'M'+boatX+' '+boatY+' h43 l-7 9 h-27Z','#31494d');rect(c,boatX+22,boatY-9,13,9,'#d6b283');rect(c,boatX+21,boatY-11,16,3,'#815c4d');
 for(let j=0;j<3;j++)ln(c,[[boatX-8-j*8,boatY+8+j*2],[boatX+9-j*8,boatY+8+j*2]],'#b4b69b',1);
 c.restore();
 mono(c,s.opened?'ORIGINAL / 01':'REPEAT / '+String(s.loop).padStart(2,'0'),1094,215,15,'#e8d7a7');
 const bx=1338,by=696;rounded(c,bx,by,191,31,3,s.opened?'#bbcb9f':'#e7c489','#2e3933',1.2);
 face(c,s.opened?'原文件已打开':'打开原文件',bx+96,by+22,17,'#37443d','center');
 face(c,s.opened?'courier.html':'courier.gif',1080,719,16,'#ebddb5');
 if(t>=12&&t<14.35){let u=K.ease((t-12)/.58),x=K.lerp(1518,1437,u),y=K.lerp(767,710,u);
  path(c,'M'+x+' '+y+' l2 19 5 -6 6 9 4 -3 -6 -9 9 -1Z','#f8ebc8','#34473d',1.4);}
 if(t>=12.6&&t<13.8){rect(c,1110,253,390,14,'#344340','#718372',1);rect(c,1113,256,384*K.clamp((t-12.6)/1.2),8,'#d2bd82');}
}
let stand=null;
function backdrop(c,t,s){
 c.drawImage(K.cached('r8-dispatch-office',bodyOfTerminal),0,0);
 if(!stand){stand=P.makeCanvas(800,900);let g=stand.getContext('2d');g.translate(-1600,0);mealStand(g);}
 c.drawImage(stand,1600,0);
 // The desk backs onto a real service hatch; the opened file meets the quay
 // at that sill. The vertical division is a physical window frame.
 rect(c,1572,0,29,900,'#243438');rect(c,1581,0,7,900,'#65736a');rect(c,1594,0,4,900,'#a5a183');
 ticket(c,t);media(c,t,s);
 if(s.gate){shortRoad(c,1544,1601);}
}
D.drawChat=function(c,t,front){
 const sec=K.clamp(t-D.starts[16],0,32),s=D.chatState(sec),u=s.study;
 if(!front){backdrop(c,u,s);if(sec<3){c.save();c.globalAlpha=1-K.smoother((sec-2.55)/.45);shortRoad(c,0,1077);c.restore();}return;}
 const threshold=1545,masked=s.gate<1,sill=683-(683-327)*s.gate;
 if(sec>=3&&masked){
  rect(c,threshold-1,184,11,Math.max(0,sill-184),'#425b58');rect(c,threshold,184,2,Math.max(0,sill-184),'#b3bea1');
  for(let y=194;y<sill-7;y+=17)rect(c,threshold+1,y,7,2,'#8fa48f');
 }
 if(s.opened&&u>=17){for(let j=0;j<2;j++){const x=2058+80*j,q=(u*.42+j*.45)%1;c.save();c.globalAlpha=(1-q)*.4;
  path(c,'M'+x+' '+(570-q*15)+' q-10 -9 0 -18 q8 -8 1 -17',null,'#f1e3bc',2.4);c.restore();}}
 if(u>=22&&sec<29.8){const x=s.camera+99;c.save();c.globalAlpha=K.ease((u-22)/.3)*(1-K.ease((sec-28.5)/1.3));
  // The last message survives the camera following the cyclist off the desk.
  rounded(c,x,108,594,98,5,'#263c32','#a9b292',2);portrait(c,x+16,120,'gpt',3.9);
  face(c,'GPT',x+94,143,17,'#cfb78b');face(c,'已复核：现在确实在前进。',x+94,181,27,'#f2e6b4');c.restore();}
};
P.castStudy.paintScene=(c,t)=>backdrop(c,t,P.castStudy.state(t));
P.castStudy.render=function(c,t){
 t=K.clamp(t,0,26);const s=P.castStudy.state(t);c.save();c.setTransform(c.canvas.width/1600,0,0,c.canvas.height/900,0,0);c.translate(-s.camera,0);
 backdrop(c,t,s);c.save();c.beginPath();c.rect(s.viewport.x,s.viewport.y,s.viewport.w,s.viewport.h);if(s.gate>=1)c.rect(1545,328,855,355);c.clip();
 P.drawRider(c,t,{x:s.x,y:s.y,scale:s.scale,style:s.opened?18:16,crankAngle:s.crank,wheelAngle:s.angle});c.restore();c.restore();
};

// A full-size cyanotype on a portable drawing board. Its pen reads the same
// ordered contour list as the actual courier and therefore cannot sketch the
// inherited bicycle while the new bicycle is riding out below.
const chalk='#daead7',lineBlue='#7eaeb3',paper='#214c66',navy='#14364f',red='#d9876a';
function measure(c,x,y,X,Y,label){
 ln(c,[[x,y],[X,Y]],lineBlue,1);const horiz=y===Y;
 for(const [u,v] of [[x,y],[X,Y]])ln(c,horiz?[[u,v-6],[u,v+6]]:[[u-6,v],[u+6,v]],chalk,1);
 mono(c,label,(x+X)/2+(horiz?0:8),(y+Y)/2-5,12,chalk,horiz?'center':'left');
}
function blueprint(c){
 rect(c,0,0,1600,900,'#8c6d50');
 for(let i=0;i<820;i++){let x=K.rnd(i+742)*1600,y=K.rnd(i+96)*900;ln(c,[[x,y],[x+5+K.rnd(i+721)*52,y+.8]],i%2?'rgba(51,43,35,.19)':'rgba(238,196,135,.14)',1.2);}
 path(c,'M29 29 L1578 17 L1582 835 L37 866Z','#594e44');
 path(c,'M20 22 L1570 13 L1577 829 L29 854Z',paper,'#b5bbc0',2);
 c.save();clip(c,45,39,1501,771);
 for(let x=53;x<1555;x+=22)ln(c,[[x,34],[x,825]],(x-53)%110===0?'#416981':'#305a71',.8);
 for(let y=44;y<830;y+=22)ln(c,[[40,y],[1555,y]],(y-44)%110===0?'#416981':'#305a71',.8);
 c.restore();rect(c,52,47,1490,758,null,'#b7d0c4',1.5);rect(c,58,53,1478,746,null,'#638b99',.7);
 face(c,'代码制图室',88,128,49,chalk);mono(c,'COURIER  /  CYANOTYPE No. 20  /  2020s',91,161,17,'#a5bbc0');
 ln(c,[[86,181],[1514,181]],lineBlue,1.3);
 // Panel of an actual plotter, retaining only three readable instructions.
 rect(c,94,208,501,206,'#1b3e55','#97b6b6',1.5);
 mono(c,'SOURCE  /  rider.plot',115,238,15,'#b5ceca');ln(c,[[111,251],[580,251]],'#527c8b',1);
 for(let j=0;j<3;j++)mono(c,String(j+1).padStart(2,'0'),119,288+j*46,15,'#809ba8');
 // Small engineering study of the ringing bell in section; hatched cut metal.
 c.save();c.translate(1356,350);ln(c,[[-97,0],[105,0]],lineBlue,1);ln(c,[[0,-123],[0,105]],lineBlue,1);
 path(c,'M-65 7 Q-64 -50 0 -56 Q62 -49 65 7 L57 7 Q54 -40 0 -46 Q-53 -42 -56 7Z',chalk);
 path(c,'M-71 8 H73 V15 H-71Z M-5 14 H6 V54 H-5Z',lineBlue);
 for(let j=-4;j<5;j++)ln(c,[[j*14,-20],[j*13+7,-33]],lineBlue,.9);circ(c,0,-58,7,chalk);measure(c,-68,58,69,58,'Ø  36');
 mono(c,'BELL / B-B',0,92,14,chalk,'center');c.restore();
 for(const x of [54,1515]){path(c,'M'+x+' 24 h30 v32 h-30Z','#b5aa8e','#5c665e',2);screw(c,x+15,37);}
 // A brass divider rests beyond the bottom edge of the working area.
 path(c,'M1331 842 L1470 806 L1341 851 L1293 872Z','#d3ac69','#5e5746',1.4);
 path(c,'M1336 845 L1489 863 L1355 855 L1293 872Z','#b99256','#62533c',1.4);circ(c,1336,845,6,'#e3c78c','#776649',1);
}
const plate=P.scenes[19];
let drawing=null;
function plotted(){
 if(drawing)return drawing;
 let parts=P.touringRig.traces({crankAngle:1.1,wheelAngle:.74}),edges=[],sum=0;
 for(const points of parts){for(let i=1;i<points.length;i++){const a=points[i-1],b=points[i],len=Math.hypot(b[0]-a[0],b[1]-a[1]);if(len>0){edges.push([a,b,sum,len]);sum+=len;}}}
 return drawing={edges,sum};
}
function plot(c,u){
 const {edges,sum}=plotted(),max=K.clamp(u)*sum,ox=924,oy=404,scale=.66;let cursor=[0,0];
 c.save();c.translate(ox,oy);c.scale(scale,scale);c.lineWidth=2;c.strokeStyle=chalk;c.beginPath();
 for(const [a,b,start,len] of edges){if(start>max)break;const f=K.clamp((max-start)/len);cursor=[K.lerp(a[0],b[0],f),K.lerp(a[1],b[1],f)];
  c.moveTo(...a);c.lineTo(...cursor);if(f<1)break;}
 c.stroke();c.restore();const x=ox+cursor[0]*scale,y=oy+cursor[1]*scale;
 if(u<1){
  rect(c,x-2,183,4,Math.max(0,y-183),'#9eb2ae');rect(c,x-10,185,20,9,'#cccbb4','#5b7d84',1);
  path(c,'M'+(x-5)+' '+(y-15)+' h10 l-4 13 -1 3 -2 -3Z','#e6be78','#6c7976',1);
 }
 measure(c,ox-86,494,ox+99,494,'280');mono(c,'A — A',710,225,14,lineBlue);mono(c,'1 : 12',1150,488,13,lineBlue);
}
const codeStrings=['wheel(77).roll(phase);','pelican.draw(contour);','road.to(nextStop);'];
plate.draw=function(c,u){
 c.drawImage(K.cached('r8-cyanotype-plate',blueprint),0,0);
 const progress=K.clamp((u-.22)/3);plot(c,progress);
 for(let j=0;j<codeStrings.length;j++){let str=codeStrings[j],n=Math.floor(str.length*K.clamp((u-j*.95)/.63));
  mono(c,str.slice(0,n),158,289+j*46,23,j===2?'#f0bd85':chalk);
  if(n>0&&n<str.length)rect(c,159+n*13.8,269+j*46,2,23,red);}
 const floor=x=>M.codeFloor(x),advance=K.smoother((u-3.4)/.93),end=1070+530*advance,pts=[];
 for(let x=0;x<end;x+=8)pts.push([x,floor(x)]);pts.push([end,floor(end)]);ln(c,pts,chalk,3.4);
 if(end<1600){const ghost=[];for(let x=end;x<1600;x+=8)ghost.push([x,floor(x)]);ghost.push([1600,floor(1600)]);
  c.save();c.setLineDash([8,11]);ln(c,ghost,lineBlue,1.15);c.restore();}
 for(let x=6;x<end;x+=26){let y=floor(x);ln(c,[[x,y+2],[x-9,y+11]],lineBlue,1.2);}
 if(advance>0&&advance<1){
  const y=floor(end);circ(c,end,y,8,null,'#efbb83',1);ln(c,[[end-12,y],[end+12,y]],'#efbb83',.8);ln(c,[[end,y-13],[end,y+13]],'#efbb83',.8);
 }
 if(u>2.75){let q=K.smoother((u-3)/.55);c.save();c.translate(1298,117);c.rotate(-.045);c.globalAlpha=K.smoother((u-2.75)/.35);
  rect(c,-150,-34,300,54,navy,q>.5?'#e3b282':lineBlue,2);face(c,q>.5?'下一站　自行决定':'终点　待签发',0,2,25,q>.5?'#e8c094':chalk,'center');c.restore();}
};
plate.foreground=function(c,u,at,rider){if(rider&&P.drawCarriedHeart)P.drawCarriedHeart(c,rider);};
plate.over=null;plate.riderScreenClip=undefined;plate.riderClip=undefined;
const story=P.storyDetails;P.storyDetails=function(c,i,...rest){if(i!==19)return story.call(P,c,i,...rest);};
const title=P.drawSceneNote;P.drawSceneNote=function(c,i,a){if(i!==19)return title.call(P,c,i,a);};
})();
