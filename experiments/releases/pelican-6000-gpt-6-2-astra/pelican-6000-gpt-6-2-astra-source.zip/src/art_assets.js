/* All scenery, people, materials and rider silhouettes are program-drawn.
   Offscreen canvases cache our own paths; no image inputs are accepted. */
P.visualMode='procedural';
P.artAssets=Object.create(null);
P.hasArtAsset=()=>false;
P.paintedSceneCount=()=>0;
P.paintArtBackground=()=>false;
P.paintRiderMaterial=()=>false;
P.installArtAssets=function(images={}){
  if(Object.keys(images).length)throw new Error('This edition uses program-drawn scenery.');
  P.thumbs=null;
  if(P.invalidateMotion)P.invalidateMotion();
  return 0;
};
