/* R3 • authored vector acting, silhouette, and depth pass. Zero bitmap inputs.
   All local geometry stays attached to the same 137-second R2 world/ground rig. */
(()=>{
'use strict';
const H=P.historic, TAU=Math.PI*2, E=K.ease;
const path=(c,d,f,s,w=1)=>K.path(c,d,f,s,w);
const line=(c,d,s,w=1)=>path(c,d,null,s,w);
const now=()=>P.sceneContext?P.sceneContext.local:0;
const blink=(t,seed=0)=>{const u=(t+seed)%4.7;return 1-.94*Math.exp(-Math.pow((u-2.9)/.085,2));};
// A tapered profile, an actual brow/eyelid, ear, lip and jaw, rather than a circle.
function face(c,x,y,s,dir,t,ink,skin,hair,variant=0,nod=0){
 c.save();c.translate(x,y);c.scale(s*dir,s);c.rotate(nod);
 path(c,'M-7 17 L-7 26 Q0 30 8 24 L7 12Z',skin,ink,.65);
 path(c,'M-13 -12 C-14 -25 -4 -29 7 -25 Q17 -20 15 -9 L19 -2 Q21 0 16 1 L16 7 Q17 15 7 18 Q-3 21 -9 11 L-14 2Z',skin,ink,.85);
 path(c,'M7 -23 Q17 -18 14 -7 L18 -1 L14 2 L14 8 Q13 15 5 18 Q16 16 17 8 L17 2 L20 0 L15 -10 Q16 -20 7 -23Z','rgba(111,73,43,.12)');
 path(c,'M-13 3 Q-20 -9 -15 -23 Q-5 -34 9 -27 Q20 -23 16 -15 Q7 -16 2 -22 Q-1 -11 -10 -7 L-11 5Z',hair,ink,.7);
 K.ellipse(c,-9,1,3,4.5,skin,ink,.55);line(c,'M-10 0 Q-6 -3 -7 4',ink,.4);
 line(c,'M5 -10 Q9 -12 13 -10',ink,.7);
 const b=blink(t,variant*.71);path(c,`M5 -6 Q9 ${-9*b-3*(1-b)} 13 -6 Q9 ${-4+1.2*b} 5 -6Z`,b>.18?'#f1e7c9':null,ink,.55);
 if(b>.18)K.ellipse(c,10,-6,1.1,b*1.65,ink);
 line(c,'M13 -2 L12 1 L15 2 M11 8 Q14 7 16 8 M11 10 L14 10',ink,.45);
 K.ellipse(c,3,4,3,1.3,'rgba(170,93,64,.08)');
 if(variant===7||variant===8){path(c,'M-7 7 Q-2 14 4 13 L8 7 Q12 6 16 8 L13 13 Q10 22 2 23 Q-4 19 -8 11Z',hair,ink,.5);line(c,'M6 6 Q11 3 16 6',hair,1.2);for(let j=0;j<7;j++)line(c,`M${-5+j*2} ${13+j%2} l1 ${5-j%3}`,variant===8?'#92927d':'#655244',.4);}
 c.restore();
}
function hand(c,x,y,s,angle,ink,skin){
 c.save();c.translate(x,y);c.rotate(angle);c.scale(s,s);
 path(c,'M-4 -3 Q1 -4 5 -2 L13 -3 Q16 -3 15 -1 L7 1 L16 1 Q19 2 16 3 L7 4 L14 5 Q17 7 13 7 L5 6 Q0 7 -2 3 L-5 2Z',skin,ink,.6);
 line(c,'M0 1 Q2 -3 5 -5 Q7 -6 7 -4 L5 0 M7 2 L13 2 M7 4 L12 5',ink,.4);c.restore();
}
function flower(c,x,y,s,ink,gold){for(let j=0;j<5;j++){let a=j*TAU/5;K.ellipse(c,x+Math.cos(a)*s,y+Math.sin(a)*s,s*.5,s*.25,gold,null,1,a);}K.circle(c,x,y,s*.3,ink);}
H.dancer=function(c,x,y,flip=1,variant=0){
 const t=now(),r=P.sceneContext?.rider||{x:800},g=E((460-Math.abs(r.x-x))/350),dir=flip<0?-1:1;
 const ink='#696350',light='#f3ead8',shade='#d7c8aa',accent=variant?'#8a957d':'#af9275';
 c.save();c.translate(x,y);c.scale(Math.abs(flip)*dir,1.06);
 // Feet carry the weight. Pelvis and hem do not slide with the gesture.
 path(c,'M-20 -3 Q-27 3 -32 3 L-35 6 Q-22 9 -12 4 M9 -1 Q19 0 25 4 L25 6 Q15 8 7 4',shade,ink,.7);
 const skirt='M-12 -135 Q-13 -101 -26 -66 C-26 -39 -39 -14 -41 -5 Q-28 0 -18 -4 Q-4 4 8 -2 Q23 3 36 -6 C28 -31 20 -52 18 -84 L12 -134Z';
 path(c,skirt,K.gradient(c,[-35,-90],[37,-70],[[0,'#e3d7bd'],[.27,light],[.62,'#eee3cd'],[1,'#d8ccb1']]),ink,.95);
 c.save();c.clip(new Path2D(skirt));
 for(let j=-3;j<=3;j++){const a=j*4;line(c,`M${a} -129 C${a*1.2} -82 ${a*1.9+Math.sin(t*.7+j)*1.2} -43 ${a*2.7} -4`,j%2?'#c3b69b':'#8e846d',j%2?.5:.65);}
 for(let j=0;j<9;j++){let yy=-115+j*12;line(c,`M-22 ${yy} q16 -3 31 -1`,'rgba(147,130,100,.13)',.4);}
 c.restore();
 path(c,'M-10 -177 Q-20 -177 -23 -166 L-16 -142 Q-14 -131 -8 -128 L14 -129 Q19 -146 13 -164 Q8 -176 -10 -177Z',light,ink,.85);
 path(c,'M-10 -177 L1 -151 L11 -172 M-6 -174 L2 -157 L6 -170',null,ink,.65);
 const shoulder=[-17,-167],wx=-14-g*9,wy=-132-g*5;
 path(c,`M-18 -171 Q-39 -165 -37 -144 Q-44 -122 -21 -116 Q-10 -118 ${wx+4} ${wy+5} L${wx-5} ${wy-4} Q-24 -139 -19 -150Z`,light,ink,.85);
 hand(c,wx,wy,.65,-.35,ink,light);
 const hx=48+g*17,hy=-151-g*18+Math.sin(t*1.3+variant)*1.1;
 path(c,`M10 -172 Q26 -169 30 -153 Q${hx-12} ${hy+6} ${hx-4} ${hy-4} L${hx+1} ${hy+6} C${hx-7} ${hy+32} 39 -101 25 -117 Q16 -131 10 -151Z`,light,ink,.95);
 line(c,`M17 -163 Q23 -143 31 -137 Q${hx-10} ${hy+16} ${hx-1} ${hy+2} M18 -148 Q21 -129 29 -124 Q37 -121 ${hx-3} ${hy+8}`,ink,.55);
 hand(c,hx,hy,.72,-.28-g*.18,ink,light);
 // Continuous gauze runs from the rear arm to the near wrist, with delayed sway.
 const sway=Math.sin(t*1.4+variant)*4+g*9;
 path(c,`M-31 -158 C-51 -127 -66 -104 -56 -70 Q-42 -79 -30 -104 C-17 -130 21 -96 ${hx-5} ${hy+8} L${hx-8} ${hy+4} C21 -114 -16 -140 -34 -108 Q-48 -82 -53 -80 C-53 -102 -38 ${-128+sway} -27 -155Z`,'rgba(228,220,198,.66)',accent,.65);
 path(c,'M-15 -136 Q-2 -132 15 -137 L16 -130 Q1 -127 -15 -130Z',accent,ink,.6);
 path(c,'M3 -132 Q13 -117 8 -98 Q2 -80 17 -60 L11 -56 Q-2 -78 2 -99 Q8 -118 -2 -130Z','#ded0b0',accent,.5);
 face(c,-2,-196,.82,1,t,ink,light,'#484a3d',variant,-.045-g*.045);
 // Tang coiffure and tiny jewellery, sculpted in line not stacked circles.
 path(c,'M-13 -213 Q-25 -225 -17 -235 Q-8 -244 3 -238 Q18 -238 13 -225 L8 -215Z','#484a3d',ink,.6);
 path(c,'M-12 -226 Q-23 -240 -9 -249 Q5 -254 12 -244 Q18 -232 8 -226Z','#505142',ink,.65);
 for(let j=0;j<4;j++)line(c,`M${-14+j*3} -235 Q-6 -249 ${6+j} -237`,'#969079',.45);
 line(c,'M-18 -232 L18 -236','#b5a076',1.1);flower(c,14,-235,2.3,ink,'#baaa83');
 K.circle(c,-9,-192,1.2,'#b29b70');line(c,'M-9 -191 L-9 -186','#b29b70',.5);
 // A small fan is handled by its pivot, with ribs opening in response to the bird.
 if(variant===0){c.save();c.translate(wx-1,wy);c.rotate(-.7+g*.2);const open=.28+g*.5;for(let j=0;j<9;j++){const a=-1.35+open*(j-4)/4;line(c,`M0 0 L${Math.cos(a)*24} ${Math.sin(a)*24}`,'#96866a',.5);}c.beginPath();c.arc(0,0,24,-1.35-open,-1.35+open);c.strokeStyle=accent;c.lineWidth=1;c.stroke();c.restore();}
 c.restore();
};
H.mughalCourtier=function(c,x,y,s,robe,variant=0,dir=1,gesture=0){
 const t=now(),g=E(gesture),ink='#654b38',gold='#bf9650',skin=variant===1?'#be9068':'#d2ab80',hair=variant===1?'#3d3f37':'#343b34';
 c.save();c.translate(x,y);c.scale(s*(dir<0?-1:1),s);
 const cream=variant!==1,light=cream?'#eeddb1':'#ba5960';
 path(c,'M-10 -8 Q-23 -2 -25 2 Q-11 7 0 2 L2 -6 M5 -7 L7 2 Q25 6 29 -4 Q24 1 15 -6Z','#b68b40',ink,.65);
 path(c,'M-10 -37 L-10 -5 L1 -4 L4 -40 M7 -38 L7 -6 L17 -7 L16 -40Z','#e5d8b5',ink,.65);
 for(let j=0;j<4;j++)line(c,`M-9 ${-27+j*5} q5 2 10 0 M8 ${-27+j*5} l7 -1`,'#b3a489',.45);
 const d='M-14 -127 Q-26 -124 -25 -111 L-17 -78 Q-22 -52 -32 -16 Q-5 -6 29 -16 Q23 -43 17 -78 L17 -115 Q11 -129 -14 -127Z';
 path(c,d,K.gradient(c,[-30,-90],[30,-90],[[0,robe],[.45,light],[1,robe]]),ink,.9);
 c.save();c.clip(new Path2D(d));for(let j=0;j<11;j++)for(let k=0;k<5;k++){let xx=-23+k*11+(j%2)*5,yy=-118+j*9;flower(c,xx,yy,1.5,cream?'#a98850':'#bb944b',cream?'#bca267':'#c59e58');}
 for(const [a,b]of [[-13,-26],[-5,-11],[4,8],[11,23]])line(c,`M${a} -74 Q${a*1.5} -37 ${b} -17`,cream?'rgba(106,77,42,.25)':'rgba(63,38,37,.30)',.6);c.restore();
 line(c,'M-29 -20 Q0 -12 27 -20 M-27 -23 Q0 -16 26 -23',gold,.85);
 // Standing hips, asymmetric arms, anatomically connected cuffs.
 path(c,'M-17 -122 Q-30 -115 -30 -98 Q-26 -83 -6 -85 L-5 -94 Q-20 -94 -17 -106Z',robe,ink,.8);line(c,'M-26 -104 Q-22 -97 -12 -95',gold,.55);
 hand(c,-6,-89,.64,-.15,ink,skin);
 const hx=32+g*13,hy=-89-g*19;
 path(c,`M12 -122 Q24 -117 24 -103 L${hx-5} ${hy-4} L${hx-3} ${hy+5} Q22 -88 15 -97 L10 -112Z`,robe,ink,.8);
 line(c,`M${hx-8} ${hy-6} L${hx-6} ${hy+5} M${hx-10} ${hy-7} L${hx-8} ${hy+5}`,gold,.7);
 hand(c,hx,hy,.76,-.23-g*.18,ink,skin);
 // Patka is a fabric strip following the torso, not a painted line.
 path(c,'M-17 -80 Q0 -75 18 -81 L19 -74 Q0 -69 -17 -75Z',cream?'#a94f50':'#e0d0a7',gold,.7);
 path(c,'M1 -77 Q9 -67 6 -49 L8 -22 L18 -24 L14 -51 Q16 -68 11 -77Z',cream?'#a8494b':'#e1cda3',ink,.45);
 for(let j=0;j<7;j++)flower(c,11,-69+j*6,1.25,gold,cream?'#d2b275':'#587887');for(let j=0;j<5;j++)line(c,`M${8+j*2} -23 l0 ${3+j%2}`,gold,.55);
 face(c,0,-146,.72,1,t,ink,skin,hair,variant===1?8:7,g*.045);
 // Wound turban, feather, jewel and a fine edge of embroidered collar.
 path(c,'M-14 -155 Q-23 -166 -14 -174 Q-1 -184 15 -174 Q20 -166 15 -155Z',cream?'#e8d7ad':'#344d65',ink,.7);
 for(let j=0;j<5;j++)line(c,`M${-15+j*3} -172 Q${-10+j*3} -161 ${7+j*2} -157`,gold,.55);
 line(c,'M-14 -162 Q1 -165 16 -160',gold,.75);path(c,'M9 -170 l3 -4 l3 4 l-3 5Z',cream?'#376d7e':'#be6b55',gold,.6);K.circle(c,12,-171,1,'#f0dfb0');
 if(variant===1){path(c,'M7 -172 Q-1 -187 8 -193 Q12 -182 10 -172Z','#d9d7bb',gold,.55);line(c,'M9 -173 L7 -189',gold,.4);}
 path(c,'M-8 -129 L-5 -135 L7 -134 L11 -128 L4 -124Z',light,gold,.7);line(c,'M4 -125 L8 -85',gold,.7);for(let j=0;j<6;j++)K.circle(c,7,-121+j*6,.85,gold);
 c.restore();
};
// Replace small street figures with weighted silhouettes, distinct hats and sleeves.
const han=H.hanFigure;
H.liveFigure=function(c,x,y,s,robe,ink='#5e5846',skin='#cfba92',look=1,gesture=0,hat=0){
 if(hat===3)return han(c,x,y,s,ink,robe,look,gesture);
 const t=now(),dir=look<0?-1:1,g=K.clamp(gesture);c.save();c.translate(x,y);c.scale(s*dir,s);
 path(c,'M-11 -8 L-14 2 L-22 5 L-21 7 L-6 7 L-2 -7 M5 -8 L8 4 L18 6 L20 3 L12 -1 L12 -8Z','#514f42',ink,.7);
 path(c,'M-11 -68 Q-19 -66 -20 -53 L-15 -35 L-21 -8 Q0 -2 20 -8 L14 -34 L13 -61 Q7 -70 -11 -68Z',robe,ink,.75);
 path(c,'M-5 -63 Q-8 -37 -12 -11 L-18 -9 Q-12 -38 -14 -58Z','rgba(37,43,34,.10)');
 line(c,'M-9 -66 L2 -49 L10 -66 M-15 -33 Q0 -29 16 -34 M1 -48 L-1 -9 M-10 -27 L-13 -10 M9 -29 L14 -11',ink,.6);
 path(c,'M-16 -62 Q-28 -54 -25 -38 L-10 -32 L-7 -37 L-19 -44 L-8 -57Z',robe,ink,.7);hand(c,-9,-35,.4,.25,ink,skin);
 const hx=24+g*8,hy=-38-g*17;path(c,`M10 -63 Q20 -58 20 -48 L${hx-4} ${hy-3} L${hx-3} ${hy+4} Q15 -38 12 -47 L6 -55Z`,robe,ink,.7);hand(c,hx,hy,.43,-.3,ink,skin);
 face(c,0,-79,.44,1,t,ink,skin,'#44473d',hat,Math.sin(t*.7+x)*.025);
 if(hat===2){path(c,'M-18 -86 Q-6 -99 0 -101 Q9 -98 20 -85 L17 -82 Q0 -87 -17 -82Z','#b8a178',ink,.75);for(let j=-3;j<=3;j++)line(c,`M0 -99 L${j*5} -85`,'#867959',.35);}
 else if(hat===1){path(c,'M-9 -88 Q-14 -97 -4 -99 Q10 -101 12 -88Z','#b8ae8f',ink,.7);line(c,'M-9 -94 Q0 -97 10 -90',ink,.4);}
 c.restore();
};
M.traveller=function(c,x,y,s,dir,bow,coat,step=0){
 const t=now(),ink='#355853',skin='#d5bc8d';c.save();c.translate(x,y);c.scale(s*(dir<0?-1:1),s);
 const l=-10-step*3,r=11+step*3;
 path(c,`M-10 -28 L${l-1} -8 L${l+5} -7 L-1 -28 M6 -27 L${r-2} -8 L${r+5} -7 L15 -29Z`,'#e3d7b6',ink,.85);
 path(c,`M${l-1} -8 L${l-9} -1 Q${l-2} 3 ${l+8} -1 L${l+5} -7 M${r-2} -8 L${r-5} 0 L${r+12} 1 L${r+13} -2 L${r+5} -7Z`,'#b49762',ink,.8);
 line(c,`M${l-4} -2 l5 -4 l3 5 M${r-2} -1 l5 -5 l5 5`,'#f0dfba',.7);
 path(c,'M-12 -75 Q-20 -71 -20 -62 L-15 -48 L-20 -26 Q-8 -20 0 -26 Q11 -20 19 -27 L13 -50 L14 -69 Q5 -78 -12 -75Z',coat,ink,1);
 path(c,'M-11 -72 L3 -49 L10 -74 M-8 -71 L1 -55',null,'#e1d5ae',1.1);
 path(c,'M-17 -44 Q0 -40 16 -45 L17 -39 Q0 -33 -17 -38Z','#cbbd96',ink,.7);
 line(c,'M-10 -34 L-14 -26 M0 -34 L0 -27 M9 -34 L13 -25',ink,.65);
 for(let j=0;j<5;j++)flower(c,-8+j%2*15,-64+Math.floor(j/2)*8,1.1,'#d2c59f','#d2c59f');
 path(c,'M-15 -70 Q-31 -59 -27 -48 L-14 -44 L-10 -49 L-20 -55 L-7 -65Z',coat,ink,.85);
 path(c,'M11 -71 Q23 -65 27 -51 L32 -33 L25 -31 L17 -51 L7 -61Z',coat,ink,.85);hand(c,29,-33,.5,.6,ink,skin);
 line(c,'M32 -48 L38 1',ink,2);line(c,'M33 -46 L38 -5','#a69970',.7);
 // The head/hat bow together around the neck; no separate floating hat.
 c.save();c.translate(0,-78);c.rotate(bow*.18);face(c,0,-5,.49,1,t,ink,skin,'#334941',3);
 path(c,'M-24 -14 Q-6 -30 0 -32 Q8 -29 24 -13 L18 -9 Q0 -14 -20 -9Z','#baa477',ink,1.1);
 for(let j=-4;j<=4;j++)line(c,`M0 -31 L${j*5} -13`,'#897957',.45);
 line(c,'M-18 -14 Q0 -20 19 -13','#e4d1a5',.7);line(c,'M-14 -10 L-8 10 L7 11 L15 -10',ink,.5);c.restore();
 path(c,'M-28 -54 L-18 -52 L-20 -35 L-31 -37Z','#ad8256',ink,.85);line(c,'M-31 -51 L-20 -48 M-29 -45 L-21 -42',ink,.5);
 c.restore();
};
// Seated journalists: torso, neck, articulated elbows, hands and rigid camera share one pose.
P.pressReporter=function(c,x,y,v,t=125){
 const cam=v%2===0,dir=v>1?-1:1,ink='#344d4c',coat=['#345d65','#777e6b','#4a5770','#866a58'][v],skin=v===2?'#bd9f80':'#d8b698';
 const rise=E((t-(v===0?129.65:130.15))/.72)*(1-E((t-132.2)/.7)),again=E((t-135.25)/.55)*(1-E((t-136.65)/.25)),aim=Math.max(rise,again),write=.5+.5*Math.sin(t*3+v),nod=cam?-.035-aim*.11:.12+.035*Math.sin(t*2.1);
 c.save();c.translate(x,y);c.scale(dir,1);
 path(c,'M-60 70 L-58 20 Q-54 -2 -34 -10 L-18 -18 L16 -19 Q43 -10 51 11 L62 70Z',coat,ink,1.4);
 path(c,'M-53 16 Q-41 0 -30 -5 L-22 13 Q-31 40 -30 67 L-56 67Z','rgba(17,36,41,.22)');
 path(c,'M14 -15 Q38 -5 43 20 L46 68 L25 68 Q29 26 14 -15Z','rgba(227,230,203,.11)');
 path(c,'M-17 -18 L-13 -31 L8 -31 L18 -18 L3 -4Z','#e0dec5',ink,.7);
 path(c,'M-29 -10 L-15 20 L-8 8 L3 -5 L15 8 L24 19 L30 -9',null,ink,.9);line(c,'M-15 20 L-18 59 M15 18 L19 60 M-45 28 Q-34 31 -29 37 M34 37 L43 33','#9aa69a',.65);
 for(let j=0;j<3;j++)K.circle(c,8,24+j*15,1.4,'#c3c5a8',ink,.5);
 c.save();c.translate(-1,-56);c.rotate(nod);
 face(c,0,-1,1,1,t,ink,skin,v===2?'#77796b':v===3?'#4b4039':'#303c3b',v);
 // A substantial swept hairstyle, with a few selected strands, not uniform hatching.
 path(c,'M-14 -5 Q-28 -14 -19 -29 Q-11 -40 3 -32 Q18 -33 17 -20 Q8 -23 1 -27 Q-2 -14 -12 -10Z',v===2?'#74766c':'#35433f',ink,.7);
 line(c,'M-19 -22 Q-9 -34 6 -28 M-17 -17 Q-9 -24 -2 -25',v===2?'#afad9a':'#718074',.7);
 if(v===3){path(c,'M-19 -21 Q-39 -32 -40 -16 Q-39 -4 -24 -5Z','#4b4039',ink,.7);line(c,'M-35 -19 Q-27 -25 -23 -14','#8a7865',.6);}
 c.restore();
 if(cam){
  const cx=24+aim*1,cy=-14-aim*46;
  // Back arm supports the underside of the lens; near arm reaches the shutter grip.
  path(c,`M29 -5 Q44 1 48 18 Q53 20 58 10 L${cx+39} ${cy+17} L${cx+31} ${cy+13} L47 5 Q38 -5 29 -9Z`,coat,ink,1);
  path(c,`M-31 -6 Q-47 -4 -40 16 Q-33 29 -20 15 L${cx-10} ${cy+1} L${cx-17} ${cy-5} L-27 8 L-20 -4Z`,coat,ink,1);
  path(c,`M${cx-17} ${cy-6} l7 -3 l7 9 l-7 5Z`,'#d4d6c0',ink,.65);
  // Neck strap follows the camera, with lower sling slack.
  line(c,`M-10 -22 Q-22 16 ${cx-9} ${cy+18} M10 -24 Q37 7 ${cx+28} ${cy+16}`,'#283c3d',1.5);
  c.save();c.translate(cx,cy);c.rotate(-.08-aim*.07);
  path(c,'M-12 -15 H20 L25 -10 V12 L-12 12 Q-16 9 -16 5 V-10Z','#263e46','#819b94',1.1);
  path(c,'M-7 -16 L-3 -22 H10 L14 -16Z','#405962',ink,.75);
  K.rect(c,-10,-10,20,15,'#627d7b','#172c32',.7);K.rect(c,-7,-7,14,9,'#a3bdb3');line(c,'M-6 0 L-1 -5 L6 -1','#4a726b',.7);
  path(c,'M20 -11 L40 -9 V9 L20 11Z','#1f3b43','#82988d',.8);
  K.ellipse(c,41,0,4,9,'#224954','#98b8aa',.8);K.ellipse(c,42,-1,2,6,'#0a232e','#4e8c94',.55);
  for(let j=0;j<4;j++)line(c,`M${24+j*3} -9 v18`,'#526c6c',.5);
  // Both hands wrap around solid camera geometry rather than crossing its lens.
  path(c,'M-11 8 Q-18 7 -18 -1 L-16 -11 Q-15 -16 -10 -15 L-5 -13 L-5 -10 L-12 -10 L-10 3 L-4 5 L-6 10Z',skin,ink,.6);
  path(c,'M29 10 Q29 16 35 16 L44 11 L44 6 Q42 3 40 5 L37 10 L33 9Z',skin,ink,.6);
  line(c,'M-15 -6 L-10 -5 M-14 -2 L-10 -1 M34 12 L40 9','#9a7f65',.45);
  K.circle(c,15,-14,1.8,'#c6a56e');K.rect(c,1,-28,15,8,'#b9c6b5',ink,.65);K.rect(c,3,-26,11,4,'#eae7ca');c.restore();
 }else{
  const hx=7+Math.sin(t*9+v)*1.1,hy=14+Math.sin(t*7)*.5;
  path(c,'M-31 -5 Q-43 -1 -43 15 L-17 23 L-11 15 L-29 8 L-21 -3Z',coat,ink,1);
  path(c,`M28 -6 Q42 -1 43 13 L${hx+9} ${hy+7} L${hx+3} ${hy-3} L27 5 L20 -5Z`,coat,ink,1);
  path(c,'M-27 -3 L8 -9 L24 30 L-15 34Z','#e5dfc4',ink,.8);line(c,'M-22 3 L8 -2 M-19 9 L7 4 M-17 15 L12 10 M-14 21 L8 17','#a8ac91',.6);
  for(let j=0;j<6;j++)K.circle(c,-23+j*5,-4-j*.8,.8,'#708274');hand(c,-17,22,.65,-.1,ink,skin);hand(c,hx,hy,.64,-1,ink,skin);
  line(c,`M${hx+2} ${hy-7} L${hx-7} ${hy+13}`,ink,1.4);line(c,`M${hx-7} ${hy+13} l-1 3`,'#a89364',.8);
 }
 path(c,'M-64 65 Q-8 50 63 64 L66 72 H-64Z','#405d59','#8b9e8c',1);c.restore();
};
// Layer helpers preserve all original doors, rider clips and contact geometry.
function add(i,layer,draw){const old=P.scenes[i][layer];P.scenes[i][layer]=function(c,t,a,p){if(old)old.call(this,c,t,a,p);draw(c,t,a,p||P.sceneContext?.rider);};}
function willow(c,x,y,scale,t,ink,leaf){c.save();c.translate(x,y);c.scale(scale,scale);const w=Math.sin(t*.7+x)*2.8;line(c,`M0 0 Q${45+w} 17 82 48 M20 9 Q${26+w} 43 26 84 M43 20 Q${52+w} 57 56 109 M64 34 Q${76+w} 60 76 87`,ink,1.2);for(let j=0;j<18;j++){let xx=17+j%3*21+w,yy=26+Math.floor(j/3)*11;path(c,`M${xx} ${yy} q-17 5 -11 15 q12 -4 11 -15Z`,leaf,ink,.35);}c.restore();}
add(3,'foreground',(c,t,a,p)=>{const drift=(p.x-800)*.075;willow(c,1510-drift,230,.9,t,'#92957a','rgba(170,174,137,.28)');});
add(5,'foreground',(c,t,a,p)=>{const drift=(p.x-800)*.1;willow(c,1473-drift,370,1.3,t,'#61734e','#a5ad77');});
add(7,'draw',(c,t,a,p)=>{
 const approach=E((490-Math.abs(p.x-825))/360),phase=t*1.4;
 // Low, transparent droplets remain behind the cyclist, anchored to the basin.
 c.save();c.globalAlpha=.28+approach*.16;
 for(let j=0;j<5;j++){let x0=704+j*43,peak=18+approach*25+j%2*8;line(c,`M${x0} 685 Q${x0+13} ${685-peak*2} ${x0+26} 685`,'#d0e6cf',1);for(let k=0;k<3;k++){let u=(phase+k/3+j*.13)%1;K.circle(c,x0+26*u,685-4*peak*u*(1-u),.8,'#e7ead2');}}
 c.restore();
});
add(10,'foreground',(c,t,a,p)=>{const wind=M.ukiyoRainAmount(t);for(let j=0;j<6;j++){const u=(t*.27+j*.17)%1,x=1640-u*1780,y=275+j*83+Math.sin(u*5+j)*15;c.save();c.translate(x,y);c.rotate(-.5+u*3);path(c,'M-5 0 Q0 -3 7 0 Q0 4 -5 0Z',wind>.3?'#8b8e60':'#c8ba83');c.restore();}});
add(11,'draw',(c,t,a,p)=>{
 // Window lights travel through the village, rather than twinkling randomly.
 for(let j=0;j<20;j++){let x=340+j*59,near=E((p.x-x+90)/80)*(1-E((p.x-x-180)/320)),y=695-j%3*13;c.save();c.globalAlpha=.28+near*.55;K.rect(c,x,y,3,7,'#f8d47a');if(j%2)K.rect(c,x+7,y,3,7,'#dcb965');c.restore();}
});
add(14,'foreground',(c,t,a,p)=>{if(t<1.6||t>4.2)return;const a1=E((t-1.6)/.3)*(1-E((t-3.8)/.4));c.save();c.globalAlpha=a1*.6;line(c,'M688 278 L688 606 M914 278 L914 606','rgba(164,240,170,.25)',.7);K.text(c,t>3.6?'LOCKED':'Δφ  3 : 2',803,646,12,'#9cdaa3','center','mono');c.restore();});
// Feather and head motion remain local to the rider's articulated rig.
const nativePose=P.nativePose;
P.nativePose=function(i,local,t){const p=nativePose(i,local,t);if([1,3,5,7,10].includes(i)){const beat=Math.sin(Math.PI*K.clamp((local-2.0)/1.5));p.gazeY=(p.gazeY||0)-.18*beat;p.headNod=(p.headNod||0)-.023*beat;}return p;};
P.edition='pure-code-R5A-unified-character';P.revision='Pure Code R5-A';
})();

P.version='R5A'; P.edition='pure-code-R5A-character-and-frame-study';
