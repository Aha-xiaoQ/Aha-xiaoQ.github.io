/* Ten independently drawn historical worlds. All marks are deterministic. */
(()=>{
  const H={}; P.historic=H;
  const tau=Math.PI*2;
  H.paper=(c,bg,ink,n=3100)=>{K.grain(c,bg,ink,n);for(let i=0;i<120;i++){c.strokeStyle=ink;c.lineWidth=.5;let y=K.rnd(i+888)*900;c.beginPath();c.moveTo(0,y);c.bezierCurveTo(530,y+K.rnd(i)*3,980,y-3,1600,y+1);c.stroke();}};
  H.stroke=(c,d,col,lw=2)=>K.path(c,d,null,col,lw);
  H.flower=(c,x,y,r,col,core='#e5bd6e',n=8)=>{for(let j=0;j<n;j++){let a=j*tau/n;K.ellipse(c,x+Math.cos(a)*r*.62,y+Math.sin(a)*r*.62,r*.43,r*.22,col,null,1,a);}K.circle(c,x,y,r*.22,core);};
  H.meander=(c,y,col,scale=1)=>{c.save();c.translate(0,y);c.scale(scale,scale);for(let x=0;x<1600/scale;x+=42)H.stroke(c,`M${x} 4 h32 v24 h-22 v-14 h12`,col,2.5);c.restore();};
  H.hatch=(c,x,y,w,h,col,n=24,seed=1)=>{for(let i=0;i<n;i++){let xx=x+K.rnd(seed+i*5)*w,yy=y+K.rnd(seed+i*7+1)*h;K.line(c,[[xx,yy],[xx+4+K.rnd(i+3)*11,yy+K.rnd(i+88)*3]],col,.6+K.rnd(i+9));}};
  H.hand=(c,x,y,s,col,rot=0)=>{c.save();c.translate(x,y);c.rotate(rot);c.scale(s,s);K.ellipse(c,0,0,14,19,col);for(let j=0;j<4;j++){let xx=-11+j*7;K.line(c,[[xx,-9],[xx-3,-29-(j===1?5:0)]],col,6);}K.line(c,[[-10,4],[-24,-8]],col,6);c.restore();};
  H.cow=(c,x,y,s,col,outline=false)=>{c.save();c.translate(x,y);c.scale(s,s);K.path(c,'M-49 -4 Q-44 -27 -12 -24 L28 -21 Q38 -34 48 -23 L58 -9 L47 -5 L36 -12 L29 7 L27 40 L21 40 L18 11 L-10 13 L-25 40 L-31 40 L-28 5 L-43 7 L-49 32 L-55 31 L-51 1Z',outline?null:col,col,2.4);H.stroke(c,'M43 -24 Q31 -55 26 -42 M48 -25 Q57 -46 60 -40 M-48 -12 Q-65 -29 -62 -7',col,2.5);if(outline){H.stroke(c,'M-37 -17 Q-7 -7 22 -17 M-31 -7 Q-5 4 22 -9',col,1.4);}else {for(let j=0;j<12;j++){c.globalAlpha=.25;K.circle(c,-39+K.rnd(j)*60,-17+K.rnd(j+80)*23,1.5,'#e9c29c');}c.globalAlpha=1;}c.restore();};
  // Authored pigment contours, not a raster trace. Tapered limbs, separate
  // thumb/fingers and three different stances stay legible as rock paintings.
  H.ochreHerder=(c,x,y,s,col,notice=0,flip=1,variant=0)=>{
    c.save();c.translate(x,y);c.scale(s*flip,s);
    const a=K.clamp(notice),hx=30-a*2,hy=-44-a*22,ey=-43-a*8;
    const torso='M-5 -61 Q-12 -54 -8 -42 L-5 -28 Q-1 -23 7 -27 L8 -41 Q12 -52 5 -61Z';
    const neck='M-3 -68 L4 -68 L5 -58 L-4 -58Z';
    const head=variant===1?'M-7 -70 Q-9 -78 -1 -80 Q7 -81 9 -74 L14 -69 L9 -66 Q7 -60 1 -62 L-5 -65Z':'M-7 -69 Q-10 -77 -2 -80 Q6 -82 9 -75 L10 -72 L15 -68 L9 -66 L7 -61 Q0 -59 -4 -65Z';
    const backLeg=variant===1?'M-5 -30 L2 -27 Q-3 -15 -3 -5 L-7 0 L-15 1 L-16 -1 L-10 -4 L-10 -16Z':'M-5 -30 L2 -24 L-7 -13 L-17 -1 L-24 1 L-25 -1 L-20 -4 L-13 -17Z';
    const frontLeg=variant===2?'M3 -28 L9 -29 Q11 -17 16 -10 L17 -1 L24 0 L25 2 L14 2 L11 -9 L5 -16Z':'M3 -28 L9 -29 L11 -14 L19 -2 L26 0 L26 2 L16 2 L6 -11Z';
    const staffArm='M-7 -57 Q-16 -54 -20 -45 L-30 -43 L-32 -39 L-18 -39 Q-10 -42 -3 -51Z';
    const greetingArm=`M6 -58 Q17 -56 21 ${ey-1} L${hx-1} ${hy-1} L${hx+2} ${hy+3} L18 ${ey+5} Q13 -47 3 -51Z`;
    const palm=`M${hx-2} ${hy-2} L${hx+3} ${hy-4} L${hx+8} ${hy-8} L${hx+9} ${hy-7} L${hx+6} ${hy-3} L${hx+11} ${hy-6} L${hx+12} ${hy-4} L${hx+6} ${hy} L${hx+10} ${hy-1} L${hx+10} ${hy+1} L${hx+4} ${hy+4} L${hx-1} ${hy+3}Z`;
    const silhouette=[backLeg,frontLeg,torso,neck,head,staffArm,greetingArm,palm].join(' ');
    K.path(c,silhouette,col);
    K.path(c,'M-7 -33 Q0 -29 9 -34 L12 -25 Q2 -20 -7 -25Z',variant===1?'#a05b3a':'#82472e');
    H.stroke(c,'M-31 -66 Q-29 -31 -36 3',col,1.65);
    K.path(c,'M-31 -43 q-4 -2 -5 1 l0 4 l5 1 l2 -2 l-4 -1Z',col);
    if(variant===1)H.stroke(c,'M-5 -78 Q-15 -85 -17 -77 M-2 -79 Q-8 -88 -12 -84',col,1.3);
    if(variant===2)K.path(c,'M-7 -76 L-12 -79 L-13 -73 L-7 -70Z',col);
    K.circle(c,7,-71,.68,'#c59b72');
    // Dry pigment skips over pits in the rock. All marks are deterministic
    // and clipped to this hand-authored figure, including the moving arm.
    c.save();c.clip(new Path2D(silhouette));
    for(let j=0;j<54;j++){const xx=-28+K.rnd(j*19+variant*131)*70,yy=-82+K.rnd(j*23+variant*77)*86;K.ellipse(c,xx,yy,.32+K.rnd(j+60)*.65,.18+K.rnd(j+81)*.35,j%4?'rgba(213,168,119,.29)':'rgba(95,43,27,.20)',null,1,-.3);}
    H.stroke(c,'M-6 -52 l8 3 M-3 -44 l6 2 M-4 -30 l7 2','rgba(219,172,120,.27)',.55);c.restore();c.restore();
  };
  H.rockPatina=c=>c.drawImage(K.cached('h-sahara-patina-pure',g=>{
    for(let j=0;j<820;j++){const x=K.rnd(j*29+804)*1600,y=170+K.rnd(j*37+910)*625,w=.7+K.rnd(j*43+61)*2.1;K.ellipse(g,x,y,w,.35+K.rnd(j*13)*.65,j%5?'rgba(231,188,143,.17)':'rgba(94,54,31,.12)',null,1,-.18);}
    H.stroke(g,'M646 301 l7 31 l-4 27 l13 15 l-15 45 l7 22 l15 37 l-13 45 M1011 568 l-6 29 l14 16 l-7 26 l11 17','rgba(104,61,37,.22)',1.1);
    H.stroke(g,'M647 301 l7 31 l-4 27 l13 15 l-15 45 l7 22 l15 37 l-13 45 M1012 568 l-6 29 l14 16 l-7 26 l11 17','rgba(235,194,153,.29)',.55);
    H.stroke(g,'M344 690 q32 -6 60 1 M941 375 q25 -7 46 -2 M1219 714 q22 -4 41 1','rgba(230,188,142,.24)',1.7);
  }),0,0);
  H.fig=(c,x,y,s,robe,ink='#443c35',face='#dfbd87',flip=1)=>H.hanFigure(c,x,y,s,ink,robe,flip,0);
  H.arch=(c,x,y,w,h,fill,stroke,lw=2)=>K.path(c,`M${x-w/2} ${y} V${y-h*.55} Q${x-w/2} ${y-h*.82} ${x} ${y-h} Q${x+w/2} ${y-h*.82} ${x+w/2} ${y-h*.55} V${y}Z`,fill,stroke,lw);
  H.cypress=(c,x,y,s,col='#315345')=>{c.save();c.translate(x,y);c.scale(s,s);K.path(c,'M0 0 C-35 -32 -32 -113 0 -190 C32 -113 35 -32 0 0Z',col,'#224435',1.6);for(let k=0;k<18;k++){let yy=-8-k*9;let ww=Math.sin((k+1)/20*Math.PI)*19;H.stroke(c,`M${-ww} ${yy-8} L0 ${yy} L${ww} ${yy-8}`,'rgba(210,200,127,.24)',1);}c.restore();};
  H.mountain=(c,pts,fill,stroke,seed=0,details=100)=>{
    const xs=pts.map(p=>p[0]),ys=pts.map(p=>p[1]),minx=Math.min(...xs),maxx=Math.max(...xs),miny=Math.min(...ys),maxy=Math.max(...ys),w=maxx-minx,h=maxy-miny,edge=[];
    // Small shelves and broken shoulders follow the large authored landform.
    for(let i=0;i<pts.length;i++){const a=pts[i],b=pts[(i+1)%pts.length],dx=b[0]-a[0],dy=b[1]-a[1],len=Math.hypot(dx,dy),steps=Math.max(1,Math.ceil(len/29));for(let j=0;j<steps;j++){const u=j/steps,rough=(a[1]>maxy-13&&b[1]>maxy-13)?0:(K.rnd(seed+i*41+j*7)-.5)*Math.min(20,h*.075)*Math.sin(Math.PI*u);edge.push([a[0]+dx*u-dy/Math.max(1,len)*rough,a[1]+dy*u+dx/Math.max(1,len)*rough]);}}
    c.save();c.beginPath();edge.forEach((p,i)=>{const prev=edge[(i+edge.length-1)%edge.length],next=edge[(i+1)%edge.length],a=[K.lerp(p[0],prev[0],.18),K.lerp(p[1],prev[1],.18)],b=[K.lerp(p[0],next[0],.18),K.lerp(p[1],next[1],.18)];if(i)c.lineTo(...a);else c.moveTo(...a);c.quadraticCurveTo(p[0],p[1],b[0],b[1]);});c.closePath();c.fillStyle=fill;c.fill();c.strokeStyle=stroke;c.lineWidth=1.4;c.stroke();c.clip();
    K.rect(c,minx,miny,w,h,K.gradient(c,[minx,miny],[maxx,maxy],[[0,'rgba(235,241,220,.13)'],[.48,'rgba(90,120,95,0)'],[1,'rgba(35,64,44,.11)']]));
    K.path(c,`M${minx+w*.15} ${maxy} Q${minx+w*.32} ${miny+h*.45} ${minx+w*.36} ${miny-35} L${minx+w*.56} ${miny-35} Q${minx+w*.44} ${miny+h*.4} ${minx+w*.60} ${maxy}Z`,'rgba(225,234,211,.17)');
    K.path(c,`M${minx+w*.61} ${miny-20} Q${minx+w*.53} ${miny+h*.28} ${minx+w*.74} ${miny+h*.55} L${maxx+20} ${maxy} L${minx+w*.64} ${maxy} Q${minx+w*.51} ${miny+h*.49} ${minx+w*.46} ${miny-20}Z`,'rgba(30,62,43,.08)');
    const groups=Math.max(9,Math.floor(details/23));
    for(let j=0;j<groups;j++){const x=minx+(.08+K.rnd(seed+j*13)*.83)*w,y=miny+(.06+K.rnd(seed+j*17)*.78)*h,ww=15+K.rnd(seed+j*19)*38,hh=26+K.rnd(seed+j*23)*64;K.path(c,`M${x} ${y} l${ww*.55} -7 l${ww*.45} 3 l${-ww*.12} ${hh*.33} l${ww*.22} ${hh*.3} l${-ww*.38} ${hh*.36} l${-ww*.7} 9 q12 ${-hh*.5} 0 ${-hh}Z`,j%3===0?'rgba(222,232,209,.075)':'rgba(43,73,51,.035)');H.stroke(c,`M${x} ${y} l${ww*.55} -7 l${ww*.45} 3 M${x+ww*.83} ${y-2} q-9 ${hh*.42} 3 ${hh*.71} l-8 ${hh*.26}`,stroke,1.1);for(let k=0;k<4;k++){const dx=k*ww*.19;H.stroke(c,`M${x+dx} ${y+3+k%2*4} q-3 ${hh*.28} ${-4-k%2*3} ${hh*.55} l${2+k%2*3} ${hh*.25}`,stroke,.46+k%2*.15);}}
    for(let j=0;j<Math.min(60,details/5);j++){const x=minx+K.rnd(seed+j*31)*w,y=miny+K.rnd(seed+j*37)*h;H.stroke(c,`M${x} ${y} q8 -3 18 -2 m-10 4 l8 -1`,stroke,.48);}c.restore();
  };
  // The same restrained ink vocabulary is used for architecture, plants and
  // figures. Details follow the object surfaces instead of becoming noise.
  H.lattice=(c,x,y,w,h,ink,step=13)=>{c.save();c.beginPath();c.rect(x,y,w,h);c.clip();for(let d=-h;d<w+h;d+=step){K.line(c,[[x+d,y],[x+d+h,y+h]],ink,.65);K.line(c,[[x+d,y+h],[x+d+h,y]],ink,.65);}c.restore();K.rect(c,x,y,w,h,null,ink,.9);};
  H.roof=(c,x,y,w,h,fill,ink='#645447',levels=1)=>{c.save();c.translate(x,y);for(let z=0;z<levels;z++){const yy=-z*h*.65,ww=w*(1-z*.18),shape=`M${-ww*.5} ${yy} Q${-ww*.36} ${yy+4} ${-ww*.23} ${yy-h*.72} Q0 ${yy-h*.9} ${ww*.23} ${yy-h*.72} Q${ww*.36} ${yy+4} ${ww*.5} ${yy} L${ww*.37} ${yy+10} L${-ww*.37} ${yy+10}Z`;K.path(c,shape,fill,ink,1.5);c.save();c.clip(new Path2D(shape));K.rect(c,-ww/2,yy-h,ww,h+12,K.gradient(c,[0,yy-h],[0,yy+10],[[0,'rgba(248,243,216,.13)'],[.7,'rgba(108,101,75,.02)'],[1,'rgba(86,79,56,.17)']]));const count=Math.max(12,Math.floor(ww/12));for(let j=-count/2;j<=count/2;j++){const dx=j*ww/count;H.stroke(c,`M${dx*.62} ${yy-h*.75} Q${dx*.79} ${yy-h*.18} ${dx} ${yy+5}`,ink,.62);}for(let j=1;j<5;j++){const u=j/5,y1=yy-h*.7*(1-u),span=ww*(.24+.25*u);H.stroke(c,`M${-span} ${y1} Q0 ${y1-h*.13*(1-u)} ${span} ${y1}`,ink,.55);}c.restore();H.stroke(c,`M${-ww*.49} ${yy+1} Q0 ${yy+12} ${ww*.49} ${yy+1}`,ink,1.1);for(let xx=-ww*.36;xx<=ww*.36;xx+=12){K.path(c,`M${xx} ${yy+8} q4 6 8 0`,null,ink,.6);}H.stroke(c,`M${-ww*.22} ${yy-h*.74} Q0 ${yy-h*.9} ${ww*.22} ${yy-h*.74}`,ink,2);for(const d of [-1,1])H.stroke(c,`M${d*ww*.47} ${yy} q${d*7} -4 ${d*9} -11`,ink,1.2);}c.restore();};
  H.pine=(c,x,y,s,col='#303f39',wash='rgba(40,55,48,.17)')=>{c.save();c.translate(x,y);c.scale(s,s);K.path(c,'M-4 0 Q3 -65 -13 -128 Q-19 -166 6 -199 L11 -197 Q-9 -161 -5 -131 Q14 -68 4 0Z',wash,col,1.5);H.stroke(c,'M-2 -2 Q8 -60 -9 -128 M-7 -103 Q-30 -114 -54 -138 M-8 -130 Q19 -140 47 -155 M-9 -159 L-33 -172',col,2.4);for(let j=0;j<11;j++){const yy=-12-j*13;H.stroke(c,`M${j%2?-3:1} ${yy} q-5 -6 -1 -10`,col,.7);}for(const [k,xx,yy,rr] of [[0,-6,-185,27],[1,-40,-151,30],[2,35,-159,29],[3,-13,-139,28],[4,28,-121,25],[5,-45,-132,27],[6,11,-173,28],[7,52,-148,23],[8,-30,-172,21]]){K.ellipse(c,xx,yy-2,rr,8,wash);H.stroke(c,`M${xx-rr*.75} ${yy+2} Q${xx} ${yy-6} ${xx+rr*.74} ${yy}`,col,1);for(let j=0;j<13;j++){let a=.12+j*Math.PI/13,dx=Math.cos(a)*rr,dy=-Math.sin(a)*(12+k%3*2);K.line(c,[[xx,yy+2],[xx+dx,yy+dy]],col,.75);K.line(c,[[xx+dx*.73,yy+dy*.67],[xx+dx+2,yy+dy-3]],col,.52);}}c.restore();};
  H.lotus=(c,x,y,s,ink='#725c43',fill='#d8cba6')=>{c.save();c.translate(x,y);c.scale(s,s);H.stroke(c,'M0 0 Q-12 -54 1 -95 M-2 -30 Q-26 -43 -40 -38',ink,1.4);K.path(c,'M-39 -38 Q-70 -58 -86 -39 Q-64 -19 -39 -38Z',fill,ink,.85);for(let j=0;j<4;j++)H.stroke(c,`M-40 -38 Q${-49-j*7} ${-43-j*3} ${-58-j*8} ${-37+j*2}`,ink,.5);for(let j=-2;j<=2;j++){c.save();c.translate(0,-92);c.rotate(j*.32);K.path(c,'M0 4 Q-24 -15 0 -43 Q24 -15 0 4Z',fill,ink,1);H.stroke(c,'M0 0 Q-5 -17 0 -35 M-4 -3 Q-15 -17 -5 -29',ink,.48);c.restore();}K.path(c,'M-15 -91 Q0 -85 15 -91',null,ink,1);for(let j=0;j<5;j++)K.circle(c,-6+j*3,-91+(j%2),.8,ink);c.restore();};
  // Court-figure line work: a continuous sleeve contour, high coiffure and
  // weight carried by one foot replace the interchangeable little-figure rig.
  H.dancer=(c,x,y,flip=1,variant=0)=>{const ink='#5d5849',light='#f0e7d3',shade='#d9c9ac',accent='#a58b6d';c.save();c.translate(x,y);c.scale(flip,1);
    const skirt=variant?'M-10 -85 Q-18 -61 -10 -45 Q1 -23 25 -5 Q-4 7 -39 5 Q-56 2 -66 -7 Q-37 -40 -30 -77Z':'M-10 -84 Q-14 -56 -36 -32 Q-55 -15 -58 -4 Q-35 8 -8 6 Q21 11 43 0 Q16 -25 12 -51 Q5 -73 12 -85Z';
    K.path(c,skirt,light,ink,1.38);K.path(c,variant?'M-24 -78 Q-23 -44 -44 -11 L-58 -7 Q-36 -45 -30 -77Z':'M-9 -78 Q-16 -47 -41 -8 L-22 2 Q-13 -25 2 -75Z','rgba(124,104,77,.10)');
    K.path(c,variant?'M-18 -142 Q-6 -147 6 -135 Q13 -118 7 -101 Q2 -90 -9 -82 L-29 -78 Q-19 -98 -27 -117 Q-33 -136 -18 -142Z':'M-19 -140 Q-7 -150 7 -140 Q20 -123 12 -109 Q3 -98 13 -84 Q4 -75 -11 -82 Q-20 -94 -23 -114 Q-31 -132 -19 -140Z',light,ink,1.3);
    // Both palms retain the authored ribbon anchors. The sleeve hangs below
    // the arm and returns to the wrist instead of becoming a single line.
    K.path(c,variant?'M-20 -140 Q-38 -141 -51 -122 Q-64 -128 -78 -144 L-84 -137 Q-71 -109 -56 -101 Q-39 -92 -26 -106 Q-19 -115 -20 -140Z':'M-19 -139 Q-34 -139 -49 -121 Q-61 -127 -77 -144 L-84 -137 Q-74 -111 -58 -99 Q-44 -82 -31 -95 Q-20 -107 -19 -139Z',light,ink,1.15);
    K.path(c,variant?'M2 -137 Q21 -143 38 -134 L68 -150 L75 -144 Q59 -124 51 -111 Q40 -95 28 -101 Q13 -109 5 -117Z':'M5 -139 Q28 -134 43 -121 L68 -150 L75 -144 Q62 -116 52 -101 Q41 -87 29 -96 Q21 -102 14 -116Z',light,ink,1.15);
    H.stroke(c,'M-77 -138 Q-66 -115 -48 -105 Q-36 -99 -27 -116 M-68 -135 Q-57 -122 -48 -120 M68 -143 Q55 -117 45 -111 Q33 -108 23 -122 M60 -136 Q52 -127 45 -125',ink,.72);
    H.stroke(c,variant?'M-19 -139 Q-13 -118 -10 -113 L2 -134 M-12 -110 Q-13 -96 -24 -86':'M-19 -138 L-7 -115 L6 -137 M-7 -115 Q-9 -99 -5 -88',ink,.85);
    K.path(c,variant?'M-27 -88 Q-11 -84 2 -94 L0 -83 Q-13 -73 -31 -79Z':'M-13 -91 Q-2 -85 10 -92 L14 -83 Q2 -75 -14 -82Z',shade,ink,.85);
    K.path(c,variant?'M-5 -84 Q13 -61 4 -40 Q-2 -25 16 -8 L6 -8 Q-12 -30 -5 -45 Q1 -66 -14 -80Z':'M5 -83 Q24 -61 17 -42 Q9 -21 30 -5 L21 -2 Q1 -23 9 -45 Q15 -63 -3 -81Z','rgba(174,137,92,.15)',accent,.65);
    const folds=variant?[[-28,-46,-61],[-21,-29,-36],[-13,-12,-18],[-7,4,18]]:[[-10,-35,-51],[-6,-20,-30],[1,-5,-11],[5,13,24],[10,21,37]];
    for(const [aa,bb,dd] of folds)H.stroke(c,`M${aa} -76 Q${bb} -29 ${dd} -2`,ink,.65);
    H.stroke(c,variant?'M-61 -6 Q-24 5 20 -3 M-37 -29 Q-17 -17 2 -23':'M-51 -3 Q-16 7 36 -1 M-30 -31 Q-7 -18 21 -31',ink,.72);
    K.path(c,variant?'M-46 3 q-14 -1 -17 4 q13 4 27 1 M10 2 q12 -3 20 4 l-16 1':'M-31 3 q-13 -1 -17 5 q12 3 25 0 M17 3 q10 -2 18 4 l-18 1',shade,ink,.85);
    c.save();c.translate(variant?-9:-3,-148);c.rotate(variant?-.13:.11);
    K.path(c,'M-4 2 L-6 -9 L5 -12 L7 1Z',light,ink,.65);
    K.path(c,'M-12 -28 Q-12 -43 0 -45 Q13 -45 13 -30 L17 -23 L13 -21 Q14 -11 4 -8 Q-8 -11 -12 -28Z',light,ink,.95);
    K.path(c,'M-12 -25 Q-20 -44 -10 -54 Q-3 -65 10 -56 Q21 -48 16 -31 Q11 -34 6 -40 Q-2 -30 -12 -25Z',ink);K.path(c,'M-7 -55 Q-21 -67 -6 -75 Q8 -82 16 -67 Q17 -60 10 -56Z',ink);
    H.stroke(c,'M-12 -46 Q-2 -52 10 -46 M-8 -65 Q0 -70 8 -65','#b3a58a',.78);K.line(c,[[-13,-61],[20,-64]],'#b5a079',1.1);H.flower(c,16,-64,3.4,'#b5a079','#e8dbc0',5);
    H.stroke(c,'M1 -30 q5 -3 10 0 M7 -24 l2 6 l4 -1 M5 -13 q4 2 8 -1',ink,.68);K.ellipse(c,6,-29,1.3,.75,ink);K.ellipse(c,-9,-24,2,3,null,ink,.55);K.circle(c,-9,-18,1.6,accent);c.restore();
    K.path(c,'M-79 -143 L-84 -145 L-89 -154 Q-91 -156 -90 -151 L-87 -144 L-93 -149 Q-95 -149 -92 -145 L-85 -138 L-81 -137Z',light,ink,.72);
    K.path(c,'M68 -148 L70 -156 Q72 -159 72 -154 L72 -150 L77 -156 Q79 -157 78 -153 L75 -146 L72 -143Z',light,ink,.72);
    H.stroke(c,'M-78 -140 l-4 3 M66 -148 l6 4',ink,.8);c.restore();};
  H.reeds=(c,x,y,h,col,t=0)=>{for(let j=0;j<5;j++){const xx=x+j*4,hh=h*(.63+j%3*.16),sway=Math.sin(t*.7+j+x)*1.4;H.stroke(c,`M${xx} ${y} Q${xx-3+sway} ${y-hh*.55} ${xx+2+sway} ${y-hh}`,col,.8);H.stroke(c,`M${xx} ${y-6} q${j%2?11:-10} -8 ${j%2?13:-12} -18`,col,.65);}};
  const basePose=(t,style,scale=1.18,ground=752)=>({x:690+32*t,y:ground-102*scale,scale,style});
  H.hero=(i,t,a)=>P.sceneContext&&P.sceneContext.rider||P.scenes[i].pose(t,a);
  H.look=(x,r)=>Math.tanh((r.x-x)/120);
  H.notice=(x,r,reach=500)=>K.ease((reach-Math.abs(r.x-x))/(reach*.62));
  H.characterId=(preferred,fallback=preferred)=>P.hasCharacterAsset&&P.hasCharacterAsset(preferred)?preferred:P.hasCharacterAsset&&P.hasCharacterAsset(fallback)?fallback:null;
  // A single response advances with the passing rider; revisiting a frame never
  // restarts a loop or changes a figure's grounded position.
  H.greetingPhase=(x,r)=>K.clamp((r.x-(x-310))/430);
  H.responsePhase=(x,r,reach=540)=>K.clamp((r.x-x+reach)/(reach*2));
  H.scrollCharacterId=role=>H.characterId(role===1?'song_porter':role===7?'song_scholar':'song_worker');
  // Match the old occupation-specific ground contact, not the atlas cell's
  // bounding box. Every pose keeps one scale and one stable pair of feet.
  H.scrollCharacter=(c,x,y,s,role=0,flip=1,phase=0)=>{
    const id=H.scrollCharacterId(role);if(!id)return false;
    const measures={0:[90,6],1:[107,10],2:[85,5],3:[83,5],4:[90,5],5:[93,9],7:[97,6]},[height,feet]=measures[role]||measures[0];
    const u=K.clamp(phase),options={x,y:y+feet*s,height:height*s,flip};
    if(role===1||role===7)options.phase=u;
    else if(role===2||role===3||role===4)options.frame=4+Math.round(u*3);
    else options.frame=u<.12?Math.round(u/.12*3):u<.76?8+Math.round((u-.12)/.64*3):12+Math.round((u-.76)/.24*3);
    return P.drawCharacter(c,id,0,options);
  };
  // The Han register uses carved, angular profiles, layered cross-collars and
  // long trailing sleeves. It intentionally does not share the Song boatman's
  // rounded head and garment silhouette.
  H.hanFigure=(c,x,y,s,ink,stone,dir=1,gesture=0)=>{
    c.save();c.translate(x,y);c.scale(s*(dir<0?-1:1),s);
    const a=K.clamp(gesture),hx=22+a*23,hy=-29-a*31;
    const robe='M-13 -55 L-4 -61 L11 -55 Q13 -35 27 -8 L21 -1 L-1 -5 L-18 1 L-29 -6 Q-18 -32 -13 -55Z';
    K.path(c,'M-18 -5 L-23 5 L-11 7 L-3 5 L-2 2 L-12 1 M12 -4 L15 4 L27 7 L33 5 L31 2 L23 1',stone,ink,1.4);
    K.path(c,robe,stone,ink,1.45);
    K.path(c,'M-10 -52 L2 -35 L12 -53 M-9 -49 L-1 -39 L9 -52 M1 -36 L-1 -9 M-12 -32 L-20 -7 M10 -31 L20 -7 M-23 -7 L-8 -5 L0 -9 L19 -4',null,ink,.75);
    K.path(c,'M-15 -52 Q-27 -46 -28 -30 L-16 -22 L-2 -27 L-3 -33 L-16 -32 L-9 -43Z',stone,ink,1.2);
    K.path(c,`M10 -53 Q27 -47 23 -36 L${hx} ${hy} L${hx+2} ${hy+7} Q13 -18 5 -36Z`,stone,ink,1.2);
    K.path(c,`M${hx-1} ${hy+1} l6 -2 l4 -5 l2 1 l-2 4 l6 0 l1 2 l-6 2 l-8 2Z`,stone,ink,.8);
    K.path(c,'M-1 -61 L0 -67 L8 -67 L9 -57Z',stone,ink,1);
    K.path(c,'M-7 -70 L-8 -77 Q-6 -84 2 -83 L9 -79 L10 -73 L15 -68 L10 -66 L10 -61 L5 -58 L-1 -61 L-5 -66Z',stone,ink,1.35);
    K.path(c,'M-8 -78 L-11 -91 L-6 -96 L7 -96 L13 -89 L10 -78Z',stone,ink,1.4);
    K.path(c,'M-7 -91 L5 -91 L9 -86 L-6 -86 M-10 -82 L-19 -84 L-23 -82 M12 -82 L22 -85',null,ink,.85);
    K.path(c,'M2 -74 h5 M10 -65 h-4 M-4 -71 l2 6',null,ink,.8);K.circle(c,6,-72,.9,ink);
    K.path(c,'M-25 -9 l5 -1 M-17 -15 l5 -1 M12 -18 l4 4 M15 -12 l3 4',null,ink,.55);
    c.restore();
  };
  H.liveFigure=(c,x,y,s,robe,ink,face,look=1,gesture=0,hat=0)=>{
    if(hat===3){H.hanFigure(c,x,y,s,ink,robe,look,gesture);return;}
    c.save();c.translate(x,y);c.scale(s,s);
    K.path(c,'M-12 -54 Q-22 -34 -24 -2 Q-3 9 23 -2 L13 -54Z',robe,ink,1.4);
    H.stroke(c,'M-7 -49 Q-11 -27 -12 0 M7 -49 Q10 -20 14 1 M-17 -14 Q-3 -8 17 -14',ink,.8);
    H.stroke(c,'M-11 -53 L1 -36 L13 -53 M0 -35 L-2 -8 M-19 -6 Q0 2 19 -5',ink,.62);
    c.save();c.globalAlpha=.15;K.path(c,'M9 -47 Q4 -26 12 -4 L20 -2 Q11 -28 13 -50Z',ink);c.restore();
    if(hat===1){H.stroke(c,'M-14 -30 Q0 -22 14 -30 M-17 -7 Q0 0 19 -6','#c6a568',1.3);for(let j=0;j<5;j++){let xx=-10+j*5;K.path(c,`M${xx} -17 l2 -3 l2 3 l-2 3Z`,null,'#c6a568',.65);}K.path(c,'M-2 -34 l10 3 l-3 26 l-6 -1Z','#b48e5c',ink,.6);}
    K.line(c,[[-11,3],[-15,7],[-5,7]],ink,2.2);K.line(c,[[9,3],[10,7],[18,7]],ink,2.2);
    c.save();c.scale(look<0?-1:1,1);
    K.path(c,'M-12 -49 Q-27 -37 -29 -20 L-20 -17 L-6 -38Z',robe,ink,1.2);
    K.ellipse(c,-24,-18,3.3,4,face,ink,.8);
    const elbowX=19+gesture*10,elbowY=-30-gesture*7,handX=24+gesture*22,handY=-24-gesture*33;
    K.path(c,`M11 -50 Q${elbowX+4} -45 ${elbowX+4} ${elbowY} L${elbowX-4} ${elbowY+4} Q12 -34 5 -42Z`,robe,ink,1.2);
    K.line(c,[[elbowX,elbowY],[handX,handY]],face,5);K.line(c,[[handX,handY],[handX+7,handY-2]],ink,1);
    c.restore();
    K.ellipse(c,look*1.7,-69,9.3,12.5,face,ink,1);
    K.path(c,`M${look*1.7-9} -71 Q-12 -85 0 -84 Q13 -83 ${look*1.7+9} -71 L${look*4+4} -77 L${look*4-3} -76Z`,ink);
    K.path(c,`M${look*7.6} -71 l${look*3} 4 l${-look*3} 1`,face,ink,.8);
    K.circle(c,look*5.5,-71,1.1,ink);K.line(c,[[look*4-2,-62],[look*4+2,-62]],ink,.65);
    H.stroke(c,`M${look*5.5-2} -74 q2 -1 4 0 M${look*5} -67 l${look*2} 2`,ink,.55);K.ellipse(c,-look*6,-68,2.2,3.3,null,ink,.5);
    if(hat===1){K.path(c,'M-13 -79 Q-18 -92 -2 -94 Q15 -93 15 -80Z','#d7c59a',ink,1.1);H.stroke(c,'M-12 -84 Q0 -87 13 -83 M-6 -91 Q-3 -85 4 -81',ink,.7);K.circle(c,5,-85,2.2,'#a76145');}
    if(hat===2){K.path(c,'M-18 -80 Q-5 -98 0 -99 Q8 -91 19 -80Z','#a99a72',ink,1);H.stroke(c,'M-15 -81 Q0 -85 15 -81',ink,.8);}
    if(hat===3){K.path(c,'M-11 -80 L-13 -94 L10 -94 L13 -81Z',ink);K.line(c,[[-13,-86],[-23,-88]],ink,2);K.line(c,[[11,-86],[22,-88]],ink,2);}
    c.restore();
  };
  H.ripple=(c,x,y,u,col,r=28)=>{if(u<0||u>1)return;c.save();c.globalAlpha=(1-u)*.6;K.ellipse(c,x,y,r*(.15+.85*u),r*(.15+.85*u)*.15,null,col,1.1);if(u>.3)K.ellipse(c,x,y,r*(u-.22),r*(u-.22)*.15,null,col,.7);c.restore();};
  H.dust=(c,p,t,col,amount=12)=>{const ground=p.y+102*p.scale;for(let j=0;j<amount;j++){let age=((t*1.7+j*.31)%1+1)%1;let x=p.x-140*p.scale-age*(56+j%3*16),y=ground-3-Math.sin(age*Math.PI)*(7+j%4*3);c.save();c.globalAlpha=(1-age)*.22;K.ellipse(c,x,y,2+age*6,1+age*2,col);c.restore();}};
  H.boat=(c,x,y,s,t,flip=1)=>{
    c.save();c.translate(x,y+Math.sin(t*1.7)*1.2);c.scale(s*flip,s);
    K.path(c,'M-111 -6 Q-79 35 60 25 L107 -14 Q31 8 -111 -6Z','#b59a68','#796d4c',1.8);
    H.stroke(c,'M-97 2 Q-17 20 94 -5 M-77 16 Q0 26 68 13','#8c7950',1);
    K.path(c,'M-46 -11 Q-37 -73 25 -64 Q63 -57 61 -9Z','#d9c89f','#8d7c58',1.6);
    for(let j=0;j<7;j++)H.stroke(c,`M${-40+j*15} -10 Q${-37+j*13} -49 ${-20+j*10} -62`,'#a39266',1);
    for(let j=0;j<9;j++)H.stroke(c,`M-36 ${-13-j*5} Q12 ${-22-j*5} ${56-j*3} ${-12-j*5}`,'rgba(128,104,63,.25)',.7);
    K.rect(c,-8,-34,17,20,'#a5936d','#8c7852',.8);K.line(c,[[0,-34],[0,-15]],'#cdb78c',1);
    if(H.characterId('song_worker'))P.drawCharacter(c,'song_worker',t,{x:-77,y:-.24,height:72.08,frame:4+Math.round((.5+.5*Math.sin(t*1.7))*3)});
    else H.liveFigure(c,-77,-5,.68,'#766f55','#77664a','#c5b18b',1,.2+.18*Math.sin(t*1.7),2);
    const ox=-117+Math.sin(t*1.7)*18,oy=38+Math.cos(t*1.7)*5;K.line(c,[[-66,-31],[ox,oy]],'#7a694b',2.4);K.ellipse(c,ox,oy,7,2.5,'#9f8b61','#796d4c',.8,.5);
    K.line(c,[[85,0],[98,-29]],'#8f7952',1.2);K.circle(c,90,2,4,null,'#856e48',1.1);
    c.restore();
  };
  H.cutStone=(c,x,y,w,h,ink)=>{K.rect(c,x,y,w,h,null,ink,.8);H.stroke(c,`M${x+3} ${y+h-3} L${x+w-3} ${y+h-3} L${x+w-3} ${y+3}`,ink,.5);};
  H.basket=(c,x,y,w=20,h=18)=>{K.path(c,`M${x-w/2} ${y-h} L${x-w*.4} ${y} Q${x} ${y+4} ${x+w*.4} ${y} L${x+w/2} ${y-h}Z`,'#c3ab7b','#8e7c57',.75);K.ellipse(c,x,y-h,w/2,3,'#ad966d','#8e7c57',.65);for(let j=1;j<4;j++)K.line(c,[[x-w*.44,y-h+j*h/4],[x+w*.44,y-h+j*h/4]],'#a38b60',.55);for(let j=-2;j<=2;j++)K.line(c,[[x+j*w/6,y-h+2],[x+j*w/7,y]],'#a38b60',.55);};
  H.partialLine=(c,pts,u,col,lw=2)=>{let q=K.clamp(u)*(pts.length-1),n=Math.floor(q),f=q-n,end=pts[Math.min(n+1,pts.length-1)],cur=pts[n],p=[K.lerp(cur[0],end[0],f),K.lerp(cur[1],end[1],f)];K.line(c,[...pts.slice(0,n+1),p],col,lw);return p;};
  H.alertCow=(c,x,y,s,t,notice)=>{c.save();c.translate(x,y);c.scale(s,s);const ink='#945035';
    K.ellipse(c,-4,-9,48,22,ink);for(let j=0;j<4;j++){let xx=-35+(j%2)*61+(j>1?7:0),swing=Math.sin(t*4+j*Math.PI*.6)*5*(1-notice);K.line(c,[[xx,1],[xx+swing*.6,20],[xx+swing,42]],ink,j>1?4:5);K.line(c,[[xx+swing,42],[xx+swing+6,42]],ink,3);}
    c.save();c.translate(37,-14);c.rotate(-notice*.19);K.path(c,'M-10 7 L4 -24 Q20 -32 28 -14 L42 -6 L39 4 L23 1 L11 15Z',ink);H.stroke(c,'M8 -24 Q-1 -49 -10 -35 M17 -26 Q24 -49 29 -35',ink,2.5);K.circle(c,24,-11,2.3,'#d6b08a');c.restore();
    H.stroke(c,`M-49 -12 Q-65 ${-34+Math.sin(t*2)*7} -68 ${-9+Math.sin(t*2)*11}`,ink,2.5);c.restore();};


  H.vine=(c,x,y,w,h,ink,leaf,gold,flip=1)=>{c.save();c.translate(x,y);c.scale(flip,1);H.stroke(c,`M0 ${h} C${w*.8} ${h*.74} ${-w*.55} ${h*.37} 0 0`,ink,1.15);for(let j=0;j<7;j++){const u=(j+.7)/7,yy=h*(1-u),xx=Math.sin(u*tau)*w*.12,d=j%2?1:-1;K.path(c,`M${xx} ${yy} q${d*w*.22} ${-h*.075} ${d*w*.47} ${-h*.06} q${-d*w*.13} ${h*.11} ${-d*w*.47} ${h*.06}Z`,leaf,gold,.7);H.stroke(c,`M${xx} ${yy} q${d*w*.22} ${-h*.045} ${d*w*.38} ${-h*.048}`,gold,.55);if(j%3===1)H.flower(c,xx-d*w*.22,yy-h*.06,w*.12,gold,ink,5);}c.restore();};
  H.papyrus=(c,x,y,h,ink='#2b7071',leaf='#689888')=>{for(let j=-1;j<=1;j++){const xx=x+j*17,hh=h*(j===0?1:.72);H.stroke(c,`M${x} ${y} Q${xx-8} ${y-hh*.55} ${xx} ${y-hh}`,ink,1.7);K.path(c,`M${xx} ${y-hh+5} Q${xx-30} ${y-hh-4} ${xx-25} ${y-hh-22} Q${xx} ${y-hh-12} ${xx+25} ${y-hh-22} Q${xx+30} ${y-hh-4} ${xx} ${y-hh+5}Z`,leaf,ink,1);for(let k=-2;k<=2;k++)H.stroke(c,`M${xx} ${y-hh+2} L${xx+k*10} ${y-hh-16-Math.abs(k)*2}`,ink,.75);K.path(c,`M${x} ${y-19} Q${x+j*27+23} ${y-60} ${x+j*31+31} ${y-50} Q${x+14} ${y-21} ${x} ${y-19}Z`,leaf,ink,.65);}};
  H.egyptGlyph=(c,x,y,k,s=1,blue='#2f747b',red='#ae5336')=>{c.save();c.translate(x,y);c.scale(s,s);const col=k%3===0?red:blue;switch(k%6){case 0:K.ellipse(c,0,-10,7,10,null,col,2.1);K.line(c,[[0,0],[0,23]],col,2.5);K.line(c,[[-13,9],[13,9]],col,2.5);break;case 1:K.path(c,'M-21 0 Q-1 -18 21 0 Q1 13 -21 0Z',null,col,2);K.circle(c,1,0,4.6,col);H.stroke(c,'M-13 7 l9 15 l13 -6 M-17 -6 q15 -15 33 0',col,1.6);break;case 2:H.stroke(c,'M-22 -6 l10 -7 l10 7 l10 -7 l10 7 M-22 5 l10 -7 l10 7 l10 -7 l10 7 M-22 16 l10 -7 l10 7 l10 -7 l10 7',col,2.2);break;case 3:K.path(c,'M-15 12 Q-20 -7 -5 -7 L3 -22 L9 -21 L7 -9 Q19 -8 23 -2 L9 0 Q8 15 -15 12Z',col);K.path(c,'M-14 0 Q-1 -10 4 4 Q-4 9 -14 0Z','#d8b36e');K.line(c,[[-6,12],[-10,24],[0,24]],col,1.7);K.line(c,[[4,13],[8,23],[15,23]],col,1.7);K.circle(c,7,-16,1.3,'#e6d2a6');break;case 4:K.path(c,'M-20 -10 Q-22 17 0 20 Q23 17 20 -10Z',null,col,2.1);H.stroke(c,'M-19 -5 h38 M-17 3 h34 M-13 11 h26 M-9 -9 v25 M2 -9 v29 M12 -9 v24',col,1.2);break;default:H.stroke(c,'M0 25 V-8 M-12 25 V8 M12 25 V8',col,2);K.path(c,'M0 -6 Q-18 -17 -19 -26 Q-7 -24 0 -15 Q8 -26 20 -27 Q18 -16 0 -6Z',col);K.path(c,'M-12 9 q-14 -13 -22 -10 q6 16 22 10 M12 9 q14 -13 22 -10 q-6 16 -22 10',col);};c.restore();};
  H.hanHorse=(c,x,y,s,ink)=>{c.save();c.translate(x,y);c.scale(s,s);K.path(c,'M-52 -10 Q-42 -35 -14 -31 L20 -27 Q23 -56 44 -64 L50 -57 L61 -49 L66 -29 L54 -25 L45 -39 Q35 -12 27 1 L34 33 L25 38 L16 6 L-10 9 L-29 39 L-39 37 L-23 3 L-43 0 L-49 31 L-57 29 L-53 3Z',null,ink,2.4);H.stroke(c,'M39 -62 l-2 -14 l8 13 M48 -59 l6 -13 l1 19 M-50 -20 Q-73 -36 -70 -1 L-64 9 M-35 -24 Q-8 -14 21 -20 M-39 -15 Q-14 -5 14 -11 M-27 1 L-11 -6 M22 -25 L34 -42',ink,1.1);for(let j=0;j<7;j++)K.line(c,[[24+j*2,-32-j*4],[31+j*2,-32-j*4]],ink,1.25);K.circle(c,53,-44,1.8,ink);H.stroke(c,'M58 -29 L27 -2 L-11 -8 M-27 39 h-12 M26 38 h12',ink,1.6);c.restore();};
  H.inkStroke=(c,pts,width,ink)=>{const left=[],right=[];for(let j=0;j<pts.length;j++){const prev=pts[Math.max(0,j-1)],next=pts[Math.min(pts.length-1,j+1)],dx=next[0]-prev[0],dy=next[1]-prev[1],len=Math.max(1,Math.hypot(dx,dy)),p=pts[j],pressure=width*(.23+.77*Math.sin(Math.PI*(j+.7)/(pts.length+.3)));left.push([p[0]-dy/len*pressure,p[1]+dx/len*pressure]);right.unshift([p[0]+dy/len*pressure,p[1]-dx/len*pressure]);}K.line(c,[...left,...right],null,1,true,ink);};
  H.songPeak=(c,d,box,tones,variant=0)=>{const [x,y,w,h]=box,far=variant<3;c.save();const land=new Path2D(d);c.fillStyle=K.gradient(c,[x,y],[x+w*.83,y+h],[[0,tones[0]],[.46,tones[1]],[1,tones[2]]]);c.fill(land);c.clip(land);c.translate(x,y);c.scale(w/400,h/500);
    // Rock volume is built from a light reserve, two washes and a dark ridge.
    const ridge=variant%2?'M198 -20 Q153 58 171 132 Q190 178 157 233 Q144 281 175 343 Q183 397 146 520 L292 520 Q231 418 239 355 Q213 284 237 222 Q257 153 238 86 L274 -20Z':'M157 -20 Q121 53 139 111 Q157 160 123 228 Q118 288 153 340 Q164 410 129 520 L248 520 Q215 414 224 348 Q209 275 236 212 Q254 145 230 90 L264 -20Z';
    c.save();c.shadowColor=far?'rgba(65,60,45,.06)':'rgba(31,30,24,.12)';c.shadowBlur=7;K.path(c,ridge,K.gradient(c,[130,30],[280,460],[[0,'rgba(39,37,29,.02)'],[.4,tones[3]],[1,'rgba(33,32,27,.06)']]));c.restore();
    K.path(c,'M44 520 Q82 421 79 348 Q74 280 116 225 Q108 171 141 131 Q141 68 186 -15 L224 -20 Q184 72 185 111 Q164 159 183 194 Q148 256 153 306 Q132 355 171 411 L172 520Z',K.gradient(c,[114,20],[199,480],[[0,tones[4]],[.6,'rgba(244,233,209,.20)'],[1,'rgba(244,233,209,0)']]));
    K.path(c,`M${257+variant%3*8} 85 q-27 64 -11 110 q-25 70 -6 113 q-28 60 -12 125 l34 69 l38 0 q-35 -112 -10 -158 q-26 -75 -4 -127 q-18 -65 7 -132Z`,far?'rgba(68,61,46,.055)':'rgba(27,28,24,.11)');
    // Dry cun strokes are concentrated on the ridge and under six rocky ledges.
    const ledges=[[143,88,32,58],[211,147,42,88],[174,227,39,70],[106,320,35,62],[257,330,43,57],[168,416,49,63]];
    ledges.forEach(([xx0,yy0,ww0,hh0],j)=>{const xx=xx0+Math.sin(variant*1.3+j)*16,yy=yy0+Math.sin(variant*.9+j*1.7)*18,ww=ww0*(.75+K.rnd(variant*41+j*13)*.5),hh=hh0*(.6+K.rnd(variant*47+j*17)*.7);K.path(c,`M${xx-5} ${yy+6} l${ww*.34} -13 l${ww*.53} 2 l${ww*.32} 14 l${-ww*.4} -3 q-17 18 -9 ${hh*.53} l-9 20 q-11 -26 0 -47Z`,far?'rgba(71,65,50,.04)':'rgba(29,30,25,.08)');if(!far||j%2===0)H.inkStroke(c,[[xx-6,yy+3],[xx+ww*.3,yy-7],[xx+ww*.75,yy-3],[xx+ww,yy+8]],far?.55:.8,far?'rgba(72,67,52,.18)':'rgba(36,36,29,.32)');
      for(let k=0;k<(far?3:6);k++){const x1=xx-5+k*ww*.17,y1=yy+10+(k%3)*4,len=hh*(.32+k%3*.13);H.inkStroke(c,[[x1,y1],[x1-4-k%2*3,y1+len*.27],[x1-5,y1+len*.59],[x1-2+k%2*3,y1+len]],far?.55:.8+k%3*.32,far?'rgba(73,66,51,.14)':'rgba(42,41,32,.34)');}
    });
    const ridgeCount=far?8:17;for(let j=0;j<ridgeCount;j++){const yy=40+j*24,xx=184+Math.sin(j*.63+variant)*38;for(let k=0;k<(far?2:4);k++){const px=xx+k*12,py=yy+(k%2)*8,len=10+(j+k)%4*5;H.inkStroke(c,[[px,py],[px-6,py+5],[px-7,py+11],[px-3,py+len]],far?.45:.65+(j+k)%3*.38,far?'rgba(71,64,49,.11)':'rgba(42,40,31,.26)');}}
    for(const [xx,yy,hh] of [[147,28,115],[238,127,112],[121,285,91]])H.inkStroke(c,[[xx,yy],[xx-12,yy+hh*.28],[xx-5,yy+hh*.6],[xx-13,yy+hh],[xx-9,yy+hh*1.16]],far?.6:1.35,far?'rgba(73,65,49,.12)':'rgba(36,35,28,.25)');
    // Small broken cun strokes follow each cliff's grain. Their scale is
    // independent of the few major ledges, avoiding a repeated branch motif.
    for(let j=0;j<(far?45:170);j++){
      const py=25+K.rnd(variant*233+j*19)*458,axis=187+Math.sin(py*.016+variant*.7)*37,px=axis+(K.rnd(variant*127+j*31)-.5)*(far?153:190),len=7+K.rnd(j*43+variant*71)*30,lean=2+K.rnd(j*17+variant*83)*6;
      K.path(c,`M${px} ${py} q${-lean} ${len*.28} ${-lean*.7} ${len*.51} l${-lean*.7} ${len*.32} l2 ${len*.13} q${lean*.4} ${-len*.39} ${lean*.7} ${-len*.54} L${px+1.1} ${py+1}Z`,far?'rgba(64,65,48,.045)':'rgba(30,43,31,.085)');
      if(j%3!==0)H.stroke(c,`M${px+.8} ${py+2} q${-lean*.55} ${len*.3} ${-lean*.35} ${len*.58}`,far?'rgba(80,79,58,.07)':'rgba(38,49,34,.17)',.28+K.rnd(j+551)*.35);
    }
    // Opaque cliff washes still show the paper tooth. The grain is clipped to
    // the landform and becomes quieter with distance, like diluted ink.
    for(let j=0;j<(far?650:1500);j++){
      const px=K.rnd(j*53+variant*379)*400,py=K.rnd(j*67+variant*503)*500,light=j%4!==0;
      K.ellipse(c,px,py,.14+K.rnd(j*71+variant)*.38,.16+K.rnd(j*79+variant)*.55,light?(far?'rgba(243,233,205,.07)':'rgba(230,225,195,.10)'):(far?'rgba(61,65,46,.04)':'rgba(30,44,31,.09)'),null,1,-.35);
    }
    c.restore();c.save();c.strokeStyle=far?'rgba(94,84,61,.23)':'rgba(49,47,36,.56)';c.lineWidth=far?.7:1.15;c.stroke(land);c.restore();
  };
  // Two miniature inhabitants provide scale in the Song landscape. Their
  // sleeves, hat and brush edges are authored paths; no image assets are used.
  H.inkBoatman=(c,x,y,height,t)=>{
    const s=height/100,handY=-39+Math.sin(t)*2,ink='#424e38',robe='#72765b';
    c.save();c.translate(x,y);c.scale(s,s);
    K.path(c,'M-8 -62 Q-15 -45 -11 -23 L-17 -5 Q-2 1 15 -4 L9 -26 L10 -60Z',robe,ink,1.5);
    K.path(c,'M-10 -5 L-12 1 L-3 2 L0 -4 M8 -4 L12 1 L21 1 L20 -2 L14 -5',ink);
    K.path(c,'M-1 -66 L0 -76 L8 -75 L8 -63Z','#b6ad88',ink,1);
    K.path(c,'M-7 -78 Q-6 -88 3 -88 Q11 -87 11 -78 L16 -74 L10 -71 Q8 -65 1 -67 L-5 -72Z','#b9ae89',ink,1.3);
    K.path(c,'M-20 -81 Q-5 -96 1 -100 Q11 -93 23 -82 Q4 -78 -20 -81Z','#a39d75',ink,1.25);
    H.stroke(c,'M-17 -82 Q2 -86 19 -83 M-7 -87 L2 -96 M4 -87 L3 -96',ink,.7);
    K.path(c,`M6 -60 Q16 -52 15 ${handY-5} L25 ${handY-4} L27 ${handY+3} L11 ${handY+3} Q4 -44 -2 -52Z`,robe,ink,1.3);
    K.path(c,`M-8 -58 Q-18 -46 -13 -33 L7 -31 L19 ${handY+4} L17 ${handY-1} L3 -39 L-5 -40 L0 -52Z`,robe,ink,1.2);
    K.ellipse(c,26,handY,3.5,2.5,'#b9ae89',ink,.8);K.ellipse(c,18,handY+1,3,2.2,'#b9ae89',ink,.7);
    H.stroke(c,'M-5 -58 L3 -46 L8 -57 M-5 -31 Q-8 -15 -12 -8 M4 -31 L8 -8 M-12 -7 Q0 -3 12 -6','rgba(46,58,35,.65)',.8);
    K.circle(c,9,-77,.8,ink);c.restore();return[x+26*s,y+handY*s];
  };
  H.inkScholar=(c,x,y,height,look=1,notice=0)=>{
    const s=height/100,flip=look<0?-1:1,ink='#596048',robe='#a4a084';
    c.save();c.translate(x,y);c.scale(s*flip,s);
    K.path(c,'M-10 -63 Q-17 -50 -12 -29 L-19 -4 Q-1 4 21 -4 Q14 -30 12 -60 L2 -67Z',robe,ink,1.25);
    K.path(c,'M-10 -4 L-12 1 L-2 1 L0 -3 M9 -4 L13 1 L23 1 L20 -3',ink);
    K.path(c,'M-3 -65 L-1 -75 L8 -75 L9 -64Z','#c5b998',ink,.8);
    c.save();c.translate(2,-74);c.rotate(-notice*.07);K.path(c,'M-9 -9 Q-8 -19 2 -19 Q11 -18 11 -8 L16 -4 L11 -2 Q9 6 1 5 Q-7 2 -9 -9Z','#c7ba98',ink,1.1);K.path(c,'M-10 -10 Q-15 -23 -1 -24 Q12 -24 13 -12 L7 -16 L-2 -13Z',ink);K.path(c,'M-8 -21 L-9 -28 L6 -29 L9 -22Z',ink);K.circle(c,9,-7,.8,ink);c.restore();
    K.path(c,'M-9 -59 Q-25 -43 -16 -29 Q-6 -24 10 -33 L9 -40 L-4 -39 L2 -50Z',robe,ink,1.15);
    K.path(c,'M10 -59 Q25 -46 21 -32 L10 -28 L-1 -32 L0 -39 L12 -39 L6 -48Z',robe,ink,1.15);
    K.path(c,'M8 -38 l8 -1 l2 3 l-8 3 l-4 -2Z','#c4b794',ink,.65);
    H.stroke(c,'M-8 -61 L1 -47 L11 -60 M-8 -25 L-13 -7 M2 -27 L1 -5 M11 -24 L17 -6 M-16 -5 Q0 0 19 -5','rgba(72,79,53,.70)',.75);
    c.restore();
  };
  // Song street figures are drawn by occupation and weight, at scroll scale.
  H.scrollFolk=(c,x,y,s,robe,role=0,flip=1,gesture=0)=>{c.save();c.translate(x,y);c.scale(s*flip,s);const ink='#635b49',skin='#c9ad83';
    const head=(xx,yy,hat=0)=>{K.path(c,`M${xx-7} ${yy-7} Q${xx-7} ${yy-16} ${xx+1} ${yy-16} Q${xx+8} ${yy-14} ${xx+7} ${yy-5} l4 4 l-4 2 q-1 7 -7 7 q-7 -1 -7 -13Z`,skin,ink,.85);K.path(c,`M${xx-8} ${yy-7} Q${xx-12} ${yy-22} ${xx+2} ${yy-21} Q${xx+9} ${yy-20} ${xx+8} ${yy-8} L${xx+3} ${yy-13}Z`,ink);K.circle(c,xx+5,yy-5,.9,ink);if(hat===1){K.path(c,`M${xx-19} ${yy-14} Q${xx-5} ${yy-34} ${xx+18} ${yy-14}Z`,'#b09c72',ink,.9);H.stroke(c,`M${xx-15} ${yy-15} Q${xx} ${yy-20} ${xx+14} ${yy-15}`,ink,.6);}if(hat===2){K.path(c,`M${xx-8} ${yy-19} l-3 -9 l16 1 l3 10Z`,ink);}};
    if(role===2){K.path(c,'M-14 -48 Q-27 -31 -17 -16 L8 -15 L25 -3 L39 -1 L39 5 L20 5 L1 -6 L-12 -5 L-23 1 L-29 -5 L-22 -27Z',robe,ink,1.15);K.path(c,'M-13 -45 Q-1 -54 9 -43 L13 -27 L29 -23 L29 -17 L5 -20 L-2 -35Z',robe,ink,1);head(-7,-59);H.stroke(c,'M-16 -34 L-10 -17 L6 -12 M-4 -45 L2 -28 L18 -24',ink,.7);}
    else if(role===3||role===4){const lean=role===4?9:2;K.path(c,`M${-12+lean} -49 Q${-17+lean} -30 -25 -8 L-11 -3 L1 -10 L15 -2 L23 -8 Q${13+lean} -26 ${14+lean} -47 L${5+lean} -55Z`,robe,ink,1.1);K.path(c,`M${2+lean} -52 Q${21+lean} -46 25 -32 L37 -25 L34 -19 L18 -25 L${3+lean} -37Z`,robe,ink,1);K.ellipse(c,35,-23,3,2,skin,ink,.65);K.path(c,`M${-8+lean} -49 Q${-4+lean} -31 7 -25 L22 -24 L21 -18 L5 -19 L${-12+lean} -34Z`,robe,ink,.9);K.ellipse(c,22,-22,3,2,skin,ink,.6);head(lean+9,-57,role===4?2:0);H.stroke(c,'M-10 -29 Q-14 -15 -19 -7 M4 -24 L10 -7',ink,.7);K.path(c,'M-15 -5 l-6 10 l15 0 l0 -4 M13 -4 l3 8 l15 0 l-3 -4',ink);}
    else{const porter=role===1,walk=role===5,lean=porter?7:walk?4:0,hem=walk?-16:-8;
      K.path(c,`M${lean-11} -52 Q${lean-19} -35 -23 ${hem} L-5 ${hem+5} L4 ${hem} L21 ${hem+4} Q${lean+15} -32 ${lean+12} -52Z`,robe,ink,1.15);
      H.stroke(c,`M${lean-9} -49 L${lean} -37 L${lean+10} -50 M${lean-6} -35 Q-12 -18 -16 ${hem} M${lean+2} -36 L11 ${hem+1} M-19 ${hem} Q1 ${hem+9} 18 ${hem+3}`,ink,.7);
      K.path(c,walk?'M-11 -12 L-23 5 L-19 9 L-4 1 L1 -10 M10 -11 L18 6 L31 7 L31 3 L22 0 L18 -14':porter?'M-11 -5 L-23 5 L-20 9 L-5 4 L0 -4 M12 -5 L17 8 L29 10 L29 6 L22 3 L20 -7':'M-12 -5 L-16 6 L-3 6 L-4 2 L-8 1 M10 -4 L12 6 L25 6 L23 2 L17 1',ink);
      head(lean+1,-63,porter?1:role===7?2:0);
      if(porter){K.path(c,'M0 -49 Q-14 -42 -12 -31 L-4 -31 L7 -45 M16 -48 Q28 -47 29 -58 L23 -61 L13 -42Z',robe,ink,1);K.ellipse(c,25,-59,3.5,3,skin,ink,.6);K.line(c,[[-50,-56],[53,-62]],ink,1.7);K.line(c,[[-44,-56],[-42,-11]],ink,.8);K.line(c,[[47,-62],[48,-16]],ink,.8);H.basket(c,-42,1,25,18);H.basket(c,48,-4,24,19);}
      else if(role===7){K.path(c,'M-9 -49 Q-26 -37 -19 -27 L6 -28 L10 -33 L-10 -35 M10 -49 Q26 -38 18 -27 L-6 -27 L-9 -33 L12 -35Z',robe,ink,1);K.ellipse(c,-6,-30,3,2,skin,ink,.6);}
      else{const hx=29+gesture*14,hy=-29-gesture*21;K.path(c,`M11 -49 Q28 -43 25 -33 L${hx} ${hy} L${hx+3} ${hy+5} L22 -25 Q13 -27 4 -39Z`,robe,ink,1);K.ellipse(c,hx+2,hy+2,3,2.5,skin,ink,.6);K.path(c,'M-10 -49 Q-25 -38 -23 -22 L-16 -19 Q-10 -31 -5 -38Z',robe,ink,.9);K.ellipse(c,-19,-19,2.5,3,skin,ink,.6);}
    }c.restore();};
  // Formal miniature portraits keep a true profile, a wrapped turban, the
  // flared jama, patterned patka and curved slippers seen in album painting.
  H.mughalCourtier=(c,x,y,s,robe,variant=0,dir=1,gesture=0)=>{c.save();c.translate(x,y);c.scale(s*(dir<0?-1:1),s*1.14);const ink='#614637',gold='#c59b45',skin=variant===1?'#b98057':'#c49a70',pale='#eddfb9';
    K.ellipse(c,0,2,25,3,'rgba(44,45,31,.13)');K.path(c,'M-13 -20 L-11 -2 L-2 0 L-1 -20 M9 -19 L13 0 L23 1 L20 -19',variant===1?'#294a69':'#873c43',ink,.8);
    K.path(c,'M-12 -4 Q-14 2 -8 5 Q5 8 10 1 Q3 4 -3 -3Z',gold,ink,.8);K.path(c,'M13 -2 Q12 5 21 6 Q35 7 36 -1 Q29 3 23 -3Z',gold,ink,.8);
    const coat='M-13 -91 Q-23 -75 -17 -61 Q-16 -44 -35 -20 Q-7 -9 33 -19 Q18 -44 16 -61 L16 -90Z';K.path(c,coat,robe,ink,1.2);
    K.path(c,'M-8 -61 Q-4 -37 -20 -18 L-31 -21 Q-15 -43 -17 -61Z','rgba(50,36,30,.13)');K.path(c,'M8 -61 Q5 -41 21 -18 L29 -20 Q15 -44 16 -61Z','rgba(255,239,198,.13)');
    H.stroke(c,'M-12 -88 L6 -65 L15 -88 M5 -64 Q-1 -45 -4 -18 M-11 -55 Q-11 -32 -19 -20 M14 -53 Q12 -37 22 -20 M-30 -21 Q0 -12 29 -20',ink,.65);
    K.path(c,'M-17 -66 Q-1 -60 17 -66 L18 -59 Q1 -54 -17 -60Z',pale,ink,.75);K.path(c,'M-2 -62 L9 -61 L9 -18 L1 -13 L-3 -17Z',pale,gold,.9);K.path(c,'M8 -61 L16 -60 L22 -22 L15 -18Z',variant===1?'#d6aa52':'#8e3741',gold,.8);
    for(let yy=-56;yy<-19;yy+=8){K.path(c,`M1 ${yy} l3 -3 l3 3 l-3 3Z`,null,gold,.6);K.line(c,[[14,yy+1],[19,yy+1]],gold,.55);}
    for(let yy=-83;yy<-25;yy+=13){for(let xx=-15;xx<22;xx+=12){if(yy>-60&&xx>-5&&xx<13)continue;K.path(c,`M${xx} ${yy} q-3 -2 0 -4 q3 2 0 4Z`,null,gold,.48);K.circle(c,xx,yy-2,.65,gold);}}
    const hx=variant===2?27:variant===1?32+gesture*10:16,hy=variant===2?-78:variant===1?-67-gesture*12:-58;
    K.path(c,`M14 -88 Q29 -83 25 -72 L${hx} ${hy} L${hx+1} ${hy+7} Q17 -61 8 -70Z`,robe,ink,1);K.path(c,`M${hx-1} ${hy} l9 -2 l5 -3 q3 0 1 2 l-4 3 l6 1 q2 3 -2 4 l-13 2Z`,skin,ink,.65);
    K.path(c,'M-13 -88 Q-29 -78 -24 -64 Q-18 -56 1 -57 L2 -64 L-15 -68 L-9 -78Z',robe,ink,1);K.path(c,'M0 -64 l12 -2 l5 3 l-5 3 l-12 2Z',skin,ink,.65);
    H.stroke(c,'M-24 -68 Q-19 -64 -15 -65 M19 -75 l5 3',gold,.7);
    // The outline itself carries the brow, nose and chin, rather than an oval
    // face with a line placed on top of it.
    c.save();c.translate(0,-90);c.scale(.70,.70);c.translate(0,90);
    K.path(c,'M-4 -90 L-3 -101 L9 -105 L12 -90Z',skin,ink,.65);K.path(c,'M-10 -111 Q-12 -126 2 -128 Q15 -128 14 -116 L18 -110 L23 -107 L17 -104 L17 -98 L11 -93 L0 -94 Q-9 -99 -10 -111Z',skin,ink,.9);
    K.path(c,'M-9 -114 Q-14 -125 -1 -131 Q12 -131 15 -119 L12 -113 L7 -119 L-2 -116Z','#44352a');H.stroke(c,'M8 -114 l6 0 M14 -103 q-6 -3 -9 -1',ink,.8);K.circle(c,12,-113,.9,ink);K.ellipse(c,-5,-108,2.6,4,null,ink,.65);K.circle(c,-5,-103,1.2,gold);
    if(variant!==2){K.path(c,'M2 -100 Q10 -99 16 -101 Q16 -94 8 -90 L0 -95Z',variant===1?'#3e3027':'#69523c');H.stroke(c,'M5 -99 l3 6 M10 -99 l1 5',gold,.4);}
    K.path(c,'M-14 -120 Q-19 -136 -3 -139 Q15 -139 20 -128 L16 -118Z',variant===1?'#394f66':'#e1cea0',ink,.9);H.stroke(c,'M-13 -127 Q0 -131 17 -125 M-8 -135 Q-3 -126 8 -122 M0 -138 Q4 -131 15 -128',gold,.9);K.path(c,'M7 -128 l3 -6 l4 5 l-4 5Z',variant===1?'#b43e44':'#2f7280',gold,.6);K.circle(c,11,-130,1.3,pale);
    if(variant===1){K.path(c,'M10 -136 Q0 -150 9 -159 Q13 -148 12 -136Z',pale,gold,.6);H.stroke(c,'M11 -139 L8 -154',gold,.5);}c.restore();c.restore();};
  H.mayaGlyph=(c,x,y,k,s=1)=>{c.save();c.translate(x,y);c.scale(s,s);const ink='#49372b',red='#b7402b',jade='#367e70';K.path(c,'M-29 -21 Q-33 -12 -30 12 Q-27 25 -12 24 L15 24 Q31 22 30 7 L29 -16 Q24 -25 8 -24Z','#e9d4a5',red,2.2);if(k%4===0){K.path(c,'M-22 -11 h20 l5 8 h14 v12 h-20 l-7 9 h-13Z',red,ink,1);K.ellipse(c,-8,-7,7,5,'#ead8ac',ink,1.3);K.circle(c,-6,-7,2,ink);H.stroke(c,'M4 3 v13 M11 3 v13 M18 3 v9 M-23 13 h13',ink,1.2);}else if(k%4===1){K.path(c,'M-21 -14 Q-4 -26 16 -16 L21 9 L9 19 L-15 15Z',jade,ink,1.1);K.ellipse(c,-4,-6,8,5,'#e5d4a3',ink,1);K.circle(c,-2,-6,2,ink);H.stroke(c,'M-20 4 h17 l6 6 h13 M-8 10 v10 M2 11 v8',ink,1.4);K.circle(c,16,-13,3,'#dcb65f');}else if(k%4===2){K.path(c,'M-20 -11 L-12 -21 L-3 -14 L10 -18 L20 -9 L18 12 L5 20 L-18 13Z',red,ink,1.2);K.circle(c,-8,-4,5,'#e9d4a5');K.circle(c,10,-4,5,'#e9d4a5');K.circle(c,-8,-4,2,ink);K.circle(c,10,-4,2,ink);H.stroke(c,'M-12 9 h25 M-8 10 v7 M0 10 v8 M8 10 v7',ink,1.3);}else{K.path(c,'M0 -19 L8 -8 L22 -6 L12 4 L14 18 L0 11 L-14 18 L-12 4 L-22 -6 L-8 -8Z',jade,ink,1.1);K.circle(c,0,-1,7,'#e7be66',ink,1.2);K.circle(c,0,-1,2.5,red);for(const xx of [-22,22])K.circle(c,xx,17,2,ink);}c.restore();};
  H.mughalTree=(c,x,y,s=1)=>{c.save();c.translate(x,y);c.scale(s,s);H.stroke(c,'M-2 0 Q8 -56 -3 -101 Q-9 -139 4 -172 M1 -66 Q-35 -87 -53 -115 M-2 -94 Q34 -115 56 -145 M-3 -121 Q-27 -140 -37 -158 M1 -146 Q21 -161 29 -183','#7c704c',2.2);for(const [xx,yy,rr] of [[-54,-115,24],[-36,-151,24],[0,-176,29],[30,-180,25],[56,-146,27],[-16,-122,22],[23,-120,26],[-19,-84,21],[30,-91,20]]){for(let j=0;j<6;j++){const a=j*tau/6,ex=xx+Math.cos(a)*rr*.6,ey=yy+Math.sin(a)*rr*.43;c.save();c.translate(ex,ey);c.rotate(a);K.path(c,'M-9 0 Q-2 -7 11 0 Q-2 7 -9 0Z',j%2?'#557b5b':'#6e8960','#c0b37a',.45);c.restore();}H.flower(c,xx,yy,5.3,'#d5a084','#b86a50',5);}c.restore();};
  H.mayaCounter=(c,x,y,pulse)=>{
    const ink='#49372b',red='#ac5134',jade='#317b69',paper='#e8d2a3',gold='#cfa64e';
    c.save();c.translate(x,y);c.scale(1.04,1.04);
    // Profile figure with folded calves, a woven belt and carved jade jewellery.
    // The stylus rises once for a completed physical crank turn.
    K.path(c,'M-14 -48 Q-34 -40 -31 -23 L-45 -6 L-29 0 L10 -1 L25 -6 L24 -15 L-5 -19 L2 -40Z',jade,ink,1.7);
    K.path(c,'M-21 -26 Q-10 -23 3 -17 L27 -15 L34 -10 L35 -6 L20 -4 L-7 -10 L-25 -10Z',red,ink,1.5);
    K.path(c,'M-36 -7 L-44 -3 L-48 -3 L-48 -7 M23 -9 l7 0 M23 -6 l9 0',null,ink,.7);
    K.path(c,'M-14 -89 Q-29 -78 -22 -57 L-15 -42 L8 -45 L11 -64 L3 -88Z',red,ink,1.7);
    K.path(c,'M-23 -53 Q-8 -47 9 -53 L12 -45 L2 -39 L-18 -43Z',paper,ink,1.2);
    for(let j=0;j<5;j++)K.path(c,`M${-18+j*6} -50 l3 4 l-3 3 l-3 -3Z`,null,red,.7);
    K.path(c,'M-20 -83 Q-34 -75 -35 -62 Q-34 -51 -17 -54 L4 -57 L3 -63 L-22 -63 L-14 -73Z',red,ink,1.4);
    K.path(c,'M-1 -89 L1 -97 L11 -99 L14 -87Z',red,ink,1.4);
    c.save();c.translate(1,-91);c.rotate(-pulse*.09);
    K.path(c,'M-16 -17 Q-20 -32 -11 -39 Q1 -46 13 -36 L15 -27 L25 -18 L18 -15 L18 -8 L12 -2 L2 -3 L-7 -9Z',red,ink,1.6);
    K.path(c,'M-17 -17 Q-27 -26 -19 -40 Q-11 -50 5 -48 L16 -37 L13 -28 L3 -34 L-9 -26 L-9 -14Z',ink);
    K.path(c,'M-19 -40 L-24 -51 L-8 -55 L12 -50 L17 -39 L8 -35 L-6 -41Z',jade,ink,1.2);
    for(let j=0;j<5;j++){const xx=-19+j*8,yy=-48-Math.sin(j*.7)*3;K.circle(c,xx,yy,2.8,gold,ink,.6);}
    for(let j=0;j<4;j++){const xx=-16+j*9;K.path(c,`M${xx} -52 Q${xx-28+j*5} -83 ${xx-20+j*8} -105 Q${xx+4} -84 ${xx+5} -54Z`,j%2?jade:'#4d8e75',ink,.85);H.stroke(c,`M${xx+2} -56 Q${xx-9+j*3} -80 ${xx-18+j*8} -100`,paper,.65);}
    K.path(c,'M1 -24 q6 -3 12 1 M6 -21 l6 0 M17 -10 l-8 0',null,ink,1);K.circle(c,9,-22,1.5,ink);
    K.circle(c,-10,-15,6.2,jade,ink,1.2);K.circle(c,-10,-15,2.3,paper,ink,.75);K.path(c,'M-12 -8 l1 9 l6 0 l0 -9Z',jade,ink,.85);c.restore();
    const hx=39-pulse*6,hy=-92-pulse*14;
    K.path(c,`M5 -85 Q21 -83 22 -69 L${hx} ${hy} L${hx+5} ${hy+4} L26 -56 Q19 -52 12 -64 L1 -72Z`,red,ink,1.45);
    K.path(c,`M${hx} ${hy} l3 -6 l5 -1 l5 4 l-2 4 l-5 -2 l-4 4Z`,red,ink,.85);
    K.path(c,`M${hx+7} ${hy-5} L${hx+32} ${hy-34}`,null,ink,1.65);K.path(c,`M${hx+31} ${hy-33} l4 -7 l-1 8Z`,'#ad4932');
    K.path(c,'M-12 -86 Q-6 -77 7 -81',null,paper,3.2);for(let j=0;j<5;j++)K.circle(c,-11+j*4,-81+Math.sin(j*.65)*4,1.8,gold,ink,.4);
    K.rect(c,-44,2,77,6,'#c7975e',ink,1.2);for(let j=0;j<7;j++)K.path(c,`M${-39+j*10} 4 l3 -2 l3 2 l-3 2Z`,null,ink,.5);
    c.restore();
  };

  P.scenes[0]={title:'撒哈拉岩画',en:'SAHARAN ROCK ART',date:'约公元前 4000 年',style:0,dark:false,accent:'#9c452c',
    draw(c,t){c.drawImage(K.cached('h-sahara-pure',g=>{
      H.paper(g,'#cca17a','rgba(96,48,29,.09)',2600);
      const grad=K.gradient(g,[0,0],[1600,900],[[0,'rgba(247,220,176,.5)'],[.5,'rgba(185,129,88,.08)'],[1,'rgba(93,61,41,.24)']]);K.rect(g,0,0,1600,900,grad);
      K.path(g,'M0 137 Q172 105 286 156 Q410 186 550 138 Q714 99 871 155 Q1015 206 1208 152 Q1425 88 1600 136 L1600 218 Q1398 181 1240 231 Q1081 270 907 213 Q727 167 559 212 Q385 243 231 201 Q124 177 0 211Z','rgba(146,81,49,.17)');
      K.path(g,'M0 424 Q116 367 257 408 Q381 448 515 404 Q676 355 844 401 Q1082 476 1239 407 Q1431 358 1600 411 L1600 459 Q1420 414 1268 467 Q1081 525 841 449 Q677 414 526 449 Q373 495 231 455 Q103 421 0 469Z','rgba(238,202,157,.20)');
      K.path(g,'M0 650 Q160 614 329 671 Q501 714 697 650 Q855 597 1068 655 Q1311 718 1600 646 L1600 736 Q1326 774 1112 711 Q902 655 718 705 Q506 768 309 724 Q134 677 0 714Z','rgba(133,77,43,.10)');
      H.stroke(g,'M0 210 Q128 180 248 208 Q376 244 520 216 M890 212 Q1056 262 1210 223 Q1433 170 1600 216','rgba(108,61,37,.20)',1.4);
      H.stroke(g,'M24 455 Q113 423 233 456 M1134 486 Q1356 437 1509 445','rgba(247,214,173,.31)',2.3);
      H.stroke(g,'M0 277 L107 293 L162 274 L208 311 L258 297 L281 344 M1600 172 L1508 204 L1480 248 L1446 254 L1459 296 M1017 0 L1023 112 L995 163 L1008 214 M355 900 L383 831 L369 799 L402 763 M1358 899 L1338 822 L1356 787','rgba(93,50,33,.31)',2);
      H.stroke(g,'M0 697 Q270 671 501 720 T1054 699 T1600 710','rgba(133,75,44,.25)',2);
      H.stroke(g,'M0 751 Q448 749 820 752 T1600 752','#85543a',2.5);
      H.stroke(g,'M0 772 Q460 765 900 776 T1600 768','rgba(134,83,49,.32)',1.5);
      for(let i=0;i<45;i++){let x=i*37,y=785+K.rnd(i+320)*37;K.line(g,[[x,y],[x+8,y-4],[x+20,y-2]],'rgba(121,75,47,.3)',1);}
      // Ochre strata and short fracture seams remain drawn marks on the wall.
      K.path(g,'M0 132 Q123 95 243 146 L279 226 Q129 193 0 247Z','rgba(156,111,72,.07)');K.path(g,'M1268 86 Q1429 42 1600 104 L1600 173 Q1434 121 1298 165Z','rgba(244,209,160,.12)');
      for(const [x,y,dir] of [[51,279,1],[311,603,1],[842,208,1],[1440,559,-1],[1564,294,-1]]){H.stroke(g,`M${x} ${y} l${dir*29} -7 l${dir*17} 13 l${dir*26} -3 m${-dir*26} 3 l${dir*12} 17`,'rgba(119,73,44,.28)',.9);H.stroke(g,`M${x+2} ${y+2} l${dir*28} -6 l${dir*17} 12`,'rgba(238,202,155,.35)',.65);}
      for(let j=0;j<8;j++){const x=14+j*196,y=686+Math.sin(j)*14;H.stroke(g,`M${x} ${y} q27 -5 57 0 m-43 5 q24 -3 39 0`,'rgba(134,83,49,.14)',.8);}
      H.cow(g,255,421,1.45,'#91482f');H.cow(g,426,452,.94,'#a55837');H.cow(g,1212,427,1.45,'#90462f');H.cow(g,1371,468,.95,'#a35432');
      H.cow(g,1174,316,.63,'#9d5438',true);H.cow(g,1333,342,.73,'#aa5a3b',true);
      H.ochreHerder(g,190,562,1.3,'#91472c',0,1,0);H.ochreHerder(g,1330,605,1.12,'#955033',0,1,1);
      H.hand(g,1427,217,.75,'rgba(148,61,36,.54)',-.27);H.hand(g,1501,280,.59,'rgba(144,67,40,.42)',.3);
      H.hand(g,95,625,.57,'rgba(149,63,38,.35)',-.4);
      K.circle(g,1110,226,25,null,'rgba(143,63,38,.55)',3);for(let j=0;j<12;j++){let a=j*tau/12;K.line(g,[[1110+Math.cos(a)*32,226+Math.sin(a)*32],[1110+Math.cos(a)*43,226+Math.sin(a)*43]],'rgba(143,63,38,.55)',2);}
      H.stroke(g,'M83 370 l28 -5 l20 7 l34 -9 M1471 344 l-26 14 l-22 -1 l-15 11 M701 571 l19 -7 l24 6 M538 633 l41 -3 l17 7','rgba(94,51,30,.23)',1.1);
      // Layered pigment deposits, old pecked spirals and small chipped flint.
      H.stroke(g,'M528 261 q43 -26 55 9 q8 27 -20 31 q-25 1 -21 -18 q2 -12 15 -9','rgba(138,68,39,.52)',2.4);
      for(let j=0;j<6;j++)H.hand(g,139+j*21,330+j%2*8,.12,'rgba(148,61,36,.24)',j*.2);
      [[114,772],[474,776],[1116,778],[1421,770]].forEach(([x,y],j)=>{K.path(g,`M${x-11} ${y+5} L${x-2} ${y-5} L${x+11} ${y} L${x+6} ${y+7}Z`,'#ac805a','#966c48',.8);});
    }),0,0);
      const r=H.hero(0,t),notice=H.notice(1110,r,580);
      H.ochreHerder(c,1160,630,.94,'#8a402a',notice,-1,2);
      H.alertCow(c,432-9*notice,703,.97,t,notice);
      // The herder notices the visitor, then the calf freezes with one hoof lifted.
      if(notice>.15){c.globalAlpha=notice*.65;K.line(c,[[1122,538],[1108,524]],'#8a402a',2);K.line(c,[[1119,554],[1099,550]],'#8a402a',2);c.globalAlpha=1;}
      for(let j=0;j<4;j++){let x=259+j*31+Math.sin(t*.7+j)*3,y=724;H.stroke(c,`M${x} ${y} q${Math.sin(t+j)*4} -18 9 -26 M${x} ${y} q-8 -13 -11 -19`,'rgba(127,82,46,.42)',1);}
    },pose:t=>basePose(t,0,.66,752),foreground(c,t,a,p){H.dust(c,p||H.hero(0,t,a),t,'#aa7950',14);H.rockPatina(c);}};

  P.scenes[1]={title:'埃及壁画',en:'EGYPTIAN MURAL',date:'约公元前 1300 年',style:1,dark:false,accent:'#226b77',
    draw(c,t){c.drawImage(K.cached('h-egypt',g=>{
      H.paper(g,'#e6d0a3','rgba(112,70,33,.065)',2400);
      K.rect(g,181,213,79,548,'rgba(186,130,70,.08)','#b98a54',.9);K.rect(g,1305,213,79,548,'rgba(64,121,121,.07)','#b98a54',.9);
      K.path(g,'M309 218 L1298 218 L1298 282 L309 282Z','#d3ba82','#ae8650',1);K.line(g,[[309,281],[1298,281]],'#337782',2);
      for(let j=0;j<15;j++)H.egyptGlyph(g,340+j*65,249,j,.64);

      K.rect(g,0,190,1600,9,'#b86b43');K.rect(g,0,203,1600,4,'#275e70');K.rect(g,0,795,1600,8,'#275e70');K.rect(g,0,809,1600,12,'#b4643d');
      for(let x=0;x<1600;x+=40){K.rect(g,x,177,17,8,x%80?'#267886':'#bc693f');K.rect(g,x,782,18,7,x%80?'#b87147':'#267886');}
      for(let x=330;x<1300;x+=64)K.line(g,[[x,217],[x,748]],'rgba(160,74,50,.18)',.7);for(let y=236;y<755;y+=64)K.line(g,[[315,y],[1300,y]],'rgba(160,74,50,.18)',.7);
      [112,1474].forEach((x,j)=>{K.rect(g,x-31,260,62,479,'#d6be82','#6b6e58',2);for(let k=-2;k<=2;k++)K.line(g,[[x+k*10,283],[x+k*10,723]],'rgba(65,107,98,.35)',2);K.path(g,`M${x-47} 250 Q${x-49} 296 ${x-31} 301 L${x+31} 301 Q${x+49} 296 ${x+47} 250Z`,'#4b8e87','#6a6650',2);for(let k=-3;k<=3;k++)H.lotus(g,x+k*10,265,.34,'#99623d',k%2?'#ba824e':'#74a49b');K.rect(g,x-40,733,80,14,'#aa683f','#685f47',2);});
      K.circle(g,1020,310,53,'#c47b36','#9b5a36',2);K.circle(g,1020,310,43,null,'rgba(232,184,100,.7)',1);
      for(const d of [-1,1]){g.save();g.translate(1020,310);g.scale(d,1);K.path(g,'M53 4 Q93 6 124 22 Q171 3 245 2 L222 28 Q167 21 130 49 Q87 35 55 22Z','#1f687e','#7a593c',1.6);K.path(g,'M56 15 Q94 14 130 34 Q177 15 233 15 L221 26 Q168 24 131 48 Q94 33 56 24Z','#b96d40','#7b5636',.9);for(let j=0;j<15;j++){let xx=65+j*11,yy=xx<132?18+(xx-65)*.26:35-(xx-132)*.15;K.path(g,`M${xx} ${yy} l9 -4 l-6 18 l-8 3Z`,j%2?'#c8974d':'#397f8a','#e2bd75',.65);}g.restore();}
      K.path(g,'M393 647 L500 501 L627 647Z','rgba(185,142,83,.23)','#ae9669',1.2);K.path(g,'M500 501 L540 647 L627 647Z','rgba(159,125,76,.16)');
      K.line(g,[[170,752],[1433,752]],'#846844',3);
      [221,1345].forEach((x,i)=>{for(let j=0;j<6;j++){let yy=270+j*68;K.rect(g,x-28,yy-21,55,48,null,'#a17b4e',1);if(j%3===0){K.ellipse(g,x,yy,17,7,null,'#3c7575',2);K.circle(g,x,yy,3,'#3c7575');H.stroke(g,`M${x-12} ${yy+7} l9 7 l11 -3`,'#3c7575',2);}else if(j%3===1){H.stroke(g,`M${x-13} ${yy-12} h23 v10 h-14 v11 h-9 Z`,'#b46942',2);K.circle(g,x+10,yy+10,3,'#b46942');}else {K.ellipse(g,x,yy-5,6,9,null,'#3c7575',2);K.line(g,[[x,yy+3],[x,yy+17]],'#3c7575',2);K.line(g,[[x-10,yy+9],[x+10,yy+9]],'#3c7575',2);}}});
      // Profile head / frontal shoulder / profile legs form one painted figure.
      if(!H.characterId('egypt_painter')){
      K.path(g,'M351 693 Q339 706 333 727 L356 734 L391 731 L405 735 L414 731 L401 724 L383 708 L377 696Z','#eee0bb','#78553a',1.55);
      K.path(g,'M353 653 Q368 646 379 654 L383 669 L375 684 L379 700 Q365 706 351 695 L355 676Z','#af653c','#714b33',1.6);
      K.path(g,'M354 658 Q344 672 345 690 L360 704 L366 699 L355 685 L363 669Z','#af653c','#714b33',1.25);
      K.path(g,'M358 649 L359 641 L373 638 L375 654Z','#b87446','#714b33',1);
      K.path(g,'M354 632 Q355 620 367 621 Q376 621 377 633 L382 639 L377 641 L378 648 L371 652 Q359 649 355 642Z','#b87446','#714b33',1.25);
      K.path(g,'M354 638 Q348 621 361 615 Q377 616 379 632 L372 630 L365 629 L363 644 L357 648Z','#283b39','#263733',1);
      K.path(g,'M352 654 Q366 662 379 654 L380 664 Q364 675 352 663Z','#276d7c','#755538',.85);
      H.stroke(g,'M354 658 Q366 666 378 659','#d2af5e',1.8);for(let j=0;j<6;j++)K.line(g,[[356+j*4,660],[356+j*4,665+(j%2)]],j%2?'#b44832':'#dcc27c',1.25);
      K.path(g,'M350 693 Q365 699 379 696 L382 703 Q366 707 347 700Z','#bd874a','#745535',.9);
      for(let j=0;j<6;j++){const xx=351+j*5;H.stroke(g,`M${xx} 703 L${339+j*11} ${728+j%2*3}`,'#9c8256',.8);}H.stroke(g,'M350 725 Q369 730 390 726 M336 730 L353 735 M398 732 l12 3','#78553a',1);
      H.stroke(g,'M369 632 q5 -3 9 0 M376 643 h-4 M359 633 l-1 5','#714b33',.7);
      }
      K.ellipse(g,329,723,13,5,'#9a6841');
      for(let j=0;j<5;j++){K.ellipse(g,289+j*16,741,6,3.5,'#b18e57','#896d44',.7);K.ellipse(g,289+j*16,738,5,2,['#a7543a','#4d8078','#d0ae67','#5c6049','#b48559'][j]);}
      // Fine faience inlays and painted feather vanes retain the ruled-wall character.
      for(let x=315;x<1302;x+=32){K.path(g,`M${x} 219 l12 18 l12 -18`,'rgba(88,126,107,.17)','#a98658',.55);}
      for(let k=0;k<20;k++){let x=791+k*23;K.line(g,[[x,319],[x+7,334]],'rgba(214,171,100,.65)',.7);}
      for(let j=0;j<7;j++){H.cutStone(g,302+j*143,705,137,42,'rgba(153,110,65,.13)');}
      K.path(g,'M300 727 q8 -7 14 0 l-3 9 h-10Z','#c7a05b','#8a6c43',.7);H.stroke(g,'M304 728 v6 M309 728 v6','#8a6c43',.55);K.line(g,[[316,731],[324,716]],'#6e6750',1.2);
      // A compact band of varied symbolic forms replaces empty ruled squares.
      for(let j=0;j<8;j++)H.egyptGlyph(g,680+j*75,409,j,.9);
      H.papyrus(g,282,747,174,'#346f70','#60917d');H.papyrus(g,1402,747,163,'#346f70','#60917d');
      for(const [x,y] of [[557,692],[1275,706]]){H.lotus(g,x,y,.67,'#8f633c','#71a7a0');K.ellipse(g,x,y+3,30,4,'rgba(63,122,119,.13)');}
      for(const x of [112,1474]){K.rect(g,x-27,308,54,26,'#34767b','#8a693d',1);for(let k=-2;k<=2;k++)K.path(g,`M${x+k*10} 314 l4 7 l-4 7 l-4 -7Z`,'#d9b15d');}
      for(const x of [112,1474])for(let k=0;k<6;k++){let yy=335+k*54;K.path(g,`M${x-18} ${yy} l18 -12 l18 12 l-18 12Z`,null,'rgba(104,121,81,.34)',.75);K.line(g,[[x-19,yy+16],[x+19,yy+16]],'rgba(173,122,66,.35)',.7);}

    }),0,0);
      const r=H.hero(1,t),p=K.clamp((t-1.1)/3.6),pts=[];
      for(let j=0;j<=32;j++){let a=j*tau/32;pts.push([437+13*Math.cos(a),686+13*Math.sin(a)]);}for(let j=0;j<=32;j++){let a=j*tau/32;pts.push([480+13*Math.cos(a),686+13*Math.sin(a)]);}
      pts.push([464,665],[451,686],[437,686],[450,667],[464,665],[480,686],[451,686],[447,660],[453,660]);
      const tip=H.partialLine(c,pts,p,'#a35f42',1.35),hand=[tip[0]-43,tip[1]-13];
      if(H.characterId('egypt_painter'))P.drawCharacter(c,'egypt_painter',t,{x:367,y:735,height:120,phase:p});
      else {
        K.path(c,`M377 661 Q391 665 402 677 L${hand[0]-2} ${hand[1]-3} L${hand[0]+1} ${hand[1]+3} L398 685 Q385 677 375 668Z`,'#b57749','#755138',1.1);
        c.save();c.translate(hand[0],hand[1]);c.rotate(.293);
        K.path(c,'M-4 -3 L4 -4 L9 -2 L10 1 L6 3 L1 3 L-2 1 L-5 1Z','#b57749','#755138',.75);
        H.stroke(c,'M3 -1 l5 1 M2 1 l4 1','#755138',.5);K.path(c,'M-5 -4 L-2 -4 L-1 3 L-4 3Z','#327780','#755138',.5);c.restore();
        K.ellipse(c,374,634,2.3,1.2,'#283e3c');
      }
      K.line(c,[hand,tip],'#4d5847',1.8);K.circle(c,tip[0],tip[1],1.8,'#a75e3c');
      // A tiny painted ibis echoes the living rider; its eye follows the motion.
      K.path(c,'M1154 665 Q1150 646 1167 643 Q1189 644 1182 664 L1175 680 L1168 680 L1171 662Z','#a96a45','#876846',1);
      H.stroke(c,'M1180 649 Q1206 646 1207 655 M1166 678 L1162 697 M1176 679 L1184 697','#876846',1.7);K.circle(c,1180+H.look(1180,r)*.7,650,1.5,'#355d59');
    },pose:t=>({...basePose(t,1,1.19,752),expression:t>2&&t<3.5?'proud':'normal'})};

  P.scenes[2]={title:'汉画像石拓片',en:'HAN STONE RUBBING',date:'约公元 100 年',style:2,dark:true,accent:'#e9debc',
    draw(c,t){c.drawImage(K.cached('h-han',g=>{
      H.paper(g,'#1c231f','rgba(231,231,211,.058)',2900);const ink='#d5d5bd';
      K.path(g,'M26 188 L549 185 L539 270 L548 301 L539 361 L549 469 L34 470Z','#202923');K.path(g,'M550 185 L1049 185 L1056 270 L1052 319 L1060 397 L1051 468 L550 469Z','#28312a');K.path(g,'M1063 188 L1569 186 L1572 468 L1062 468 L1064 402 L1058 319 L1062 271Z','#202823');
      K.path(g,'M29 473 L1569 473 L1570 788 L34 789 L36 720 L30 692Z','#202a22');

      K.rect(g,28,184,1544,606,null,'#737f70',3);H.meander(g,198,'#a9b19b');H.meander(g,758,'#a9b19b');
      for(let j=0;j<8;j++){let x=75+j*203;H.stroke(g,`M${x} 329 q-32 -20 -10 -38 q24 -22 39 0 q12 23 -10 25 q-19 -1 -7 -13 M${x+38} 303 q31 -33 59 -8 q21 23 -6 36 q-20 9 -26 -7`,'#899582',2);}
      K.line(g,[[60,469],[1542,469]],'#8e9d85',2);K.line(g,[[60,740],[1542,740]],'#adb79d',3);
      const chariot=(x,y,flip)=>{g.save();g.translate(x,y);g.scale(flip,1);K.circle(g,-27,32,38,null,ink,3);for(let j=0;j<12;j++){let a=j*tau/12;K.line(g,[[-27,32],[-27+Math.cos(a)*35,32+Math.sin(a)*35]],ink,1.5);}K.path(g,'M-74 -38 L17 -38 L11 17 L-68 17Z',null,ink,3);K.line(g,[[14,-8],[100,3]],ink,3);H.stroke(g,'M-70 -38 L-70 -106 L-38 -137 L5 -108 L5 -37 M-83 -106 Q-30 -119 19 -106',ink,3);if(!H.characterId('han_attendant'))H.fig(g,-33,-40,.7,'#343d31',ink,'#bdc6b1');H.hanHorse(g,135,-13,.91,ink);H.stroke(g,'M-67 -30 h77 M-64 -22 h70 M-60 -13 h61 M-53 -4 h48 M-65 -89 h63 M-65 -82 h62',ink,.75);for(let k=0;k<5;k++){let xx=-61+k*14;H.stroke(g,`M${xx} -28 l9 18 l7 -18`,ink,.7);}K.circle(g,-27,32,31,null,ink,.7);K.circle(g,-27,32,5,ink);g.restore();};
      chariot(233,391,1);chariot(1335,391,-1);
      for(let j=0;j<4;j++){if(!H.characterId('han_attendant'))H.fig(g,85+j*71,675,1.05,'#303a2f',ink,'#303a2f',1);K.line(g,[[85+j*71+22,654],[85+j*71+29,540]],ink,1.8);}
      // Scratchy recessed stone pattern and ancient ornamental birds.
      for(let i=0;i<110;i++){let x=K.rnd(i+400)*1500+50,y=486+K.rnd(i+900)*240;H.stroke(g,`M${x} ${y} l${4+K.rnd(i)*16} -2`,'rgba(215,222,201,.12)',.8);}
      H.stroke(g,'M662 369 Q633 348 658 331 Q677 320 690 338 L736 330 L692 347 Q682 382 654 383 L629 409 M663 373 L650 411 M678 371 L680 410',ink,2.2);
      H.stroke(g,'M927 370 Q957 348 932 331 Q914 320 900 338 L854 330 L898 347 Q908 382 937 383 L961 409 M927 373 L939 411 M912 371 L910 410',ink,2.2);
      K.rect(g,1100,508,165,100,null,'#899581',1.6);
      for(const d of [-1,1]){g.save();g.translate(d<0?567:1025,0);g.scale(d,1);K.path(g,'M0 716 Q35 675 52 679 L68 661 Q93 651 93 674 L124 681 L91 688 Q72 708 54 701 L31 719Z',null,'#aab69e',1.9);H.stroke(g,'M33 706 q18 -21 34 -16 M30 711 q20 -17 34 -15 M52 701 l-9 21 M71 698 l9 22 M40 681 q-21 -9 -31 8', '#aab69e',1.1);K.circle(g,85,671,1.8,'#bfc8af');g.restore();}
      for(const [x,y,w,h] of [[29,184,51,19],[361,190,45,13],[1530,185,40,28],[30,755,54,35],[1077,768,37,21],[1547,693,24,44]]){K.path(g,`M${x} ${y} l${w*.7} 0 l${-w*.14} ${h*.3} l${w*.44} ${h*.22} l${-w*.3} ${h*.48} h${-w*.7}Z`,'#1c231f');H.stroke(g,`M${x+w*.7} ${y} l${-w*.14} ${h*.3} l${w*.44} ${h*.22} l${-w*.3} ${h*.48}`,'#788671',1.2);}

      // Two levels of carving: deep structural seams and fine repeated tool marks.
      H.stroke(g,'M546 184 l-9 78 l8 39 l-7 60 l9 108 M1051 184 l9 87 l-7 47 l6 76 l-8 75 M25 712 l189 -4 l91 5','rgba(14,18,14,.6)',5);
      H.stroke(g,'M548 184 l-9 78 l8 39 l-7 60 l9 108 M1053 184 l9 87 l-7 47 l6 76 l-8 75','rgba(180,192,167,.2)',.8);
      for(let j=0;j<30;j++){let x=43+j*50;H.stroke(g,`M${x} 243 l12 7 l12 -7 M${x+7} 253 l12 7 l12 -7`,'rgba(179,193,164,.34)',.9);}
      for(let j=0;j<18;j++){let x=602+j*24;K.circle(g,x,443,2,'#899582');K.line(g,[[x-6,450],[x+6,450]],'#73836f',.8);}
      // Recessed borders have a second tool edge; ornaments stay in their register.
      K.rect(g,34,190,1532,594,null,'rgba(189,202,173,.28)',.75);for(let j=0;j<31;j++){let x=48+j*49;H.stroke(g,`M${x} 720 q8 -9 16 0 q8 9 16 0 M${x+4} 726 h24`,'rgba(185,199,168,.25)',.6);}
      for(const [x,y] of [[362,525],[741,513],[939,680],[1476,705]]){H.stroke(g,`M${x} ${y} l19 -6 l11 9 l22 -2 m-22 2 l5 18`,'rgba(10,17,12,.52)',2.1);H.stroke(g,`M${x+1} ${y+1} l18 -6 l11 9 l22 -2`,'rgba(182,195,163,.28)',.6);}
      if(!H.characterId('han_attendant'))for(let j=0;j<4;j++){let x=85+j*71;H.stroke(g,`M${x-11} 621 l11 14 l11 -14 M${x-9} 642 l-3 27 M${x+4} 641 l8 28 M${x-17} 669 q17 5 34 0`,'#9aa68e',.8);}

    }),0,0);
      const r=H.hero(2,t),han=H.characterId('han_attendant');
      if(han){
        for(const [x,flip] of [[200,1],[1368,-1]]){
          c.save();c.beginPath();c.rect(x-39,254,78,99);c.clip();
          P.drawCharacter(c,han,t,{x,y:356.6,height:63.7,flip,phase:H.responsePhase(x,r,790)});c.restore();
        }
        for(let j=0;j<4;j++){const x=85+j*71;P.drawCharacter(c,han,t,{x,y:683.4,height:95.55,phase:H.responsePhase(x,r,790)});}
      }
      for(let j=0;j<3;j++){let x=1335+j*69,notice=H.notice(x,r,790);if(han)P.drawCharacter(c,han,t,{x,y:678.65,height:95.95,flip:H.look(x,r),phase:H.responsePhase(x,r,790)});else H.liveFigure(c,x,672,.95,'#303a2f','#c5cab3','#303a2f',H.look(x,r),j===0?.8*notice:.12*notice,3);}
      if(t>1.8){c.save();c.beginPath();c.rect(1105,510,155*K.ease((t-1.8)/1.8),98);c.clip();K.text(c,'借 道',1183,571,43,'#cfd4be','center','serif');c.restore();}
      if(han)P.drawCharacter(c,han,t,{x:1290,y:628.11,height:73.73,flip:-1,phase:K.clamp((t-1.8)/2.3)});
      else H.liveFigure(c,1290,623,.73,'#303a2f','#bcc6b0','#303a2f',-1,.5+.16*Math.sin(t*11),3);
      const a=K.ease((t-2.2)/.6);if(a){K.line(c,[[1284,552],[1266+Math.sin(t*12)*3,551]],'#bcc6b0',2.6);}
      if(t>1.8&&t<4.1)for(let j=0;j<5;j++){let u=(t*3+j*.21)%1;K.line(c,[[1264+u*16+j,557+u*u*43],[1267+u*16+j,559+u*u*43]],`rgba(192,204,179,${.7-u*.6})`,1);}
      const gate=H.notice(1125,r,560);if(han)P.drawCharacter(c,han,t,{x:1125,y:735.09,height:87.87,flip:-1,phase:H.responsePhase(1125,r,560)});else H.liveFigure(c,1125,729,.87,'#303a2f','#c5cab3','#303a2f',-1,gate*.75,3);
      const poleTop=[1114+gate*13,619-gate*65];K.line(c,[[1146,700],poleTop],'#b7c4ad',2);K.path(c,`M${poleTop[0]} ${poleTop[1]} l${-61+gate*18} ${9+Math.sin(t*2)*3} l10 20 l${51-gate*18} -8Z`,null,'#b7c4ad',1.8);
    },pose:t=>basePose(t,2,1.19,740)};

  P.scenes[3]={title:'唐代白描',en:'TANG LINE DRAWING',date:'约公元 750 年',style:3,dark:false,accent:'#6b7667',
    draw(c,t){c.drawImage(K.cached('h-tang',g=>{
      H.paper(g,'#f2ead7','rgba(86,77,57,.06)',3000);const ink='#6d705a';
      H.stroke(g,'M0 410 Q99 351 204 371 Q313 343 418 398 Q489 351 558 369 Q646 400 720 358 Q810 315 894 351 Q975 286 1039 328 Q1123 298 1183 344 Q1274 307 1345 360 Q1494 333 1600 376','rgba(115,124,106,.38)',1.4);
      H.stroke(g,'M0 433 Q159 394 289 421 Q458 395 603 428 M1035 387 Q1205 359 1383 403 L1600 414','rgba(115,124,106,.25)',1);
      H.stroke(g,'M0 749 Q360 742 750 750 Q1100 751 1600 746',ink,1.7);
      H.roof(g,1351,394,332,80,'#eee7d5',ink);K.rect(g,1239,406,224,132,'#ede6d6',ink,1.2);for(let x=1254;x<1458;x+=43)K.line(g,[[x,408],[x,530]],ink,2);K.line(g,[[1234,539],[1472,539]],ink,3);K.line(g,[[1263,507],[1442,507]],ink,1.4);
      // Timber joints, lattice bays, curved tile courses and a shallow terrace.
      K.path(g,'M1222 540 L1484 540 L1500 554 L1206 554Z','#e4dcc7',ink,1);
      for(let yy=544;yy<554;yy+=4)K.line(g,[[1218,yy],[1488,yy]],'#a7a18b',.6);
      for(let xx=1254;xx<1458;xx+=43){K.rect(g,xx-3,410,6,120,'#e5ddc8',ink,.75);K.path(g,`M${xx-10} 414 h20 v6 h-6 v6 h-8 v-6 h-6Z`,'#e6dec8',ink,.7);K.rect(g,xx-6,528,12,6,'#d7cfb6',ink,.6);}
      for(let xx=1264;xx<1428;xx+=43)H.lattice(g,xx,434,24,62,'rgba(115,110,88,.58)',10);
      for(let xx=1227;xx<1480;xx+=24){K.line(g,[[xx,542],[xx,522]],ink,.9);K.circle(g,xx,521,1.5,'#a49a7e');}K.line(g,[[1227,528],[1476,528]],ink,1);
      // A pale open gallery sits behind the dance, leaving the riding plane clear.
      g.save();g.globalAlpha=.49;K.rect(g,55,438,211,62,'#ece4d0','#99967f',.8);H.roof(g,162,438,261,50,'#ece5d1','#99967f');for(let xx=72;xx<260;xx+=35){K.line(g,[[xx,448],[xx,499]],'#96927b',1);K.line(g,[[xx,457],[xx+26,457]],'#aaa58a',.6);}K.path(g,'M43 501 L282 501 L298 510 L29 510Z','#ddd9c2','#a4a087',.7);g.restore();
      // A shallow garden terrace anchors the figures behind the riding path.
      K.path(g,'M180 696 Q775 671 1294 686 L1322 702 Q773 690 170 714Z','#ebe3cf','#b7af95',.65);
      H.stroke(g,'M190 700 Q776 678 1303 691','rgba(255,249,229,.58)',1.2);
      for(const x of [328,571,837,1083])H.stroke(g,`M${x} ${695-(x-180)*.009} l-4 13`,'rgba(152,148,121,.25)',.65);
      H.pine(g,1457,619,1.12,'#7d8069','rgba(124,133,109,.08)');
      for(const [x,y,r] of [[78,727,34],[174,719,42],[1490,732,49]]){K.ellipse(g,x,y,r,r*.17,'rgba(128,139,111,.10)','#aaa98f',.65);H.stroke(g,`M${x-r} ${y+6} q${r} 5 ${r*2} 0`,'rgba(137,148,118,.28)',.6);}
      for(let j=0;j<8;j++){const x=67+j*34,y=585+Math.sin(j*.8)*8;K.path(g,`M${x} ${y} q8 -16 17 -2 q-8 13 -17 2Z`,'rgba(157,162,130,.12)','#b4b39b',.6);}

      // Garments are ribbons of ink rather than solid silhouettes.
      // R3: articulated figures are drawn in the moving layer.
      
      H.lotus(g,118,746,1.2,'#8a8671','#eee6d2');H.lotus(g,183,746,.73,'#8a8671','#eee6d2');
      for(let i=0;i<4;i++){let x=45+i*41;H.stroke(g,`M${x} 744 Q${x-12} 698 ${x+3} 670`,ink,1.3);}
      H.stroke(g,'M304 242 Q349 224 366 245 Q379 221 401 237 Q420 251 448 245 M1062 228 Q1108 218 1113 239 Q1125 212 1148 232 Q1171 243 1200 234','rgba(111,119,103,.45)',1.3);
      for(let x=1259;x<1451;x+=20){K.line(g,[[x,430],[x+18,450],[x,470],[x+18,490]],'rgba(119,115,95,.43)',.8);K.line(g,[[x+18,430],[x,450],[x+18,470],[x,490]],'rgba(119,115,95,.43)',.8);}
      for(let j=0;j<6;j++){let x=1213+j*54;H.stroke(g,`M${x} 400 v11 h13 v-7 h13`,'#aaa18a',.9);}
      H.stroke(g,'M207 675 q14 -12 25 -8 M222 676 q13 -14 24 -9 M1203 664 q16 -15 25 -9','rgba(119,115,95,.55)',.7);
    }),0,0);
      const r=H.hero(3,t),gust=.5+.5*H.notice(1040,r,510),leftCharacter=H.characterId('tang_greeting'),rightCharacter=H.characterId('tang_greeting_alt','tang_greeting');
      H.dancer(c,267,692,1,0); H.dancer(c,1190,684,-.93,1);
      if(rightCharacter)P.drawCharacter(c,rightCharacter,t,{x:1190,y:684,height:206,flip:-1,phase:H.greetingPhase(1190,r)});
      const wind=(x,y,a)=>H.stroke(c,`M${x} ${y} C${x+95} ${y-25+a} ${x+145} ${y+25-a} ${x+223} ${y-8} S${x+344} ${y-25+a} ${x+410} ${y-5}`,'rgba(112,123,105,.46)',1.2);
      wind(190+t*15,287,Math.sin(t*2)*20);wind(920+t*10,576,Math.sin(t*2+.6)*15);
      for(let j=0;j<4;j++){let xx=(260+j*315+t*26)%1500,yy=296+(j*71+t*9)%230;c.save();c.globalAlpha=.55;c.translate(xx,yy);c.rotate(t*.35+j);K.path(c,'M0 0 Q-11 -6 -18 2 Q-8 9 0 0Z',j%2?'#c9b588':'#aab29a');c.restore();}
      // The opening sleeve sends one leaf from the gallery rail into the pond.
      // Its entire flight is tied to the rider's passage, including the landing.
      const leafProgress=K.clamp((r.x-1045)/400),leafU=K.smoother(leafProgress),v=1-leafU;
      const leafX=v*v*v*1263+3*v*v*leafU*1410+3*v*leafU*leafU*1472+leafU*leafU*leafU*1490;
      const leafY=v*v*v*529+3*v*v*leafU*405+3*v*leafU*leafU*515+leafU*leafU*leafU*732;
      const sleeveWind=Math.sin(Math.PI*K.clamp((r.x-1000)/340));
      if(sleeveWind>0){c.save();c.globalAlpha=sleeveWind*.38;H.stroke(c,'M1119 565 C1178 548 1194 507 1263 529','#8d967a',1.1);H.stroke(c,'M1133 576 C1190 564 1210 520 1256 537','#a4a889',.75);c.restore();}
      c.save();c.translate(leafX,leafY);c.rotate(-.6+leafU*4.1);K.path(c,'M-11 0 Q-1 -9 13 -1 Q2 10 -11 0Z','#b6a06a','#8a8869',.65);H.stroke(c,'M-9 0 L11 -1','#837f5d',.6);c.restore();
      if(leafProgress>=1){const ripple=K.clamp((r.x-1445)/155);H.ripple(c,1490,734,ripple,'rgba(128,140,107,.55)',40);}
      const flit=K.ease((t-2.1)/1.9),bx=1062+flit*115,by=566-flit*122;K.ellipse(c,bx-4,by,3+Math.abs(Math.sin(t*15))*5,5,'#b6a782',null,1,-.4);K.ellipse(c,bx+4,by,3+Math.abs(Math.sin(t*15))*5,5,'#b6a782',null,1,.4);K.line(c,[[bx,by-4],[bx,by+5]],'#8c8970',.8);
      for(let x of [1218,1485]){let dx=Math.sin(t*2+x)*4;K.line(c,[[x,407],[x+dx,428]],'#96927a',.8);K.ellipse(c,x+dx,431,3,5,'#c3ad85','#96927a',.8);}
    },pose:t=>({...basePose(t,3,1.16,748),expression:'calm',headNod:-.05*Math.sin(Math.PI*K.clamp((t-1.5)/2)),gazeY:-.25}),over(c,t){
      // Close reeds cross the path edge while the distant garden stays pale.
      H.reeds(c,31,788,79,'rgba(101,112,83,.78)',t);H.reeds(c,123,800,56,'rgba(115,124,93,.63)',t);
      H.reeds(c,1539,789,83,'rgba(101,112,83,.78)',t);
      for(const [x,y,flip] of [[76,789,1],[1573,791,-1]]){c.save();c.translate(x,y);c.scale(flip,1);K.path(c,'M-30 0 Q-5 -25 30 -9 Q13 9 -30 0Z','#d8d7ba','#7d8767',1);H.stroke(c,'M-27 -1 Q-1 -10 27 -9 M-8 -7 l-6 -9 M8 -9 l6 7','#8e9575',.65);c.restore();}
    }};

  P.scenes[4]={title:'宋代山水',en:'SONG INK LANDSCAPE',date:'约公元 1000 年',style:4,dark:false,accent:'#4d4a3b',
    draw(c,t){c.drawImage(K.cached('h-song-pure',g=>{
      H.paper(g,'#eee3ca','rgba(76,63,42,.055)',3400);
      K.path(g,'M0 471 Q84 379 164 410 Q242 339 319 373 Q370 293 434 347 Q485 309 542 370 Q608 321 690 369 Q747 302 808 360 Q874 293 926 342 Q1010 279 1084 345 Q1161 283 1243 368 Q1326 325 1402 378 Q1490 347 1600 408 L1600 654 L0 654Z','rgba(153,148,128,.18)');
      H.stroke(g,'M33 445 Q139 408 219 425 Q320 382 411 415 M1139 407 Q1310 377 1500 427','rgba(127,119,97,.19)',.85);

      H.songPeak(g,'M339 613 Q369 562 385 509 Q397 466 422 459 L452 446 Q468 437 476 397 Q485 354 513 328 Q535 312 562 322 Q586 328 604 297 Q625 253 639 238 Q660 225 685 244 Q705 246 720 253 Q750 299 761 343 Q767 376 796 385 Q822 383 841 419 Q864 471 872 521 Q879 559 906 589 L940 632Z',[339,238,601,394],['#ddd5bf','#c2bea9','#acae98','rgba(85,79,60,.10)','rgba(246,235,210,.30)'],1);
      H.songPeak(g,'M810 642 Q838 558 842 485 Q841 443 871 424 L901 405 Q920 373 930 333 Q943 285 966 263 Q986 252 1007 276 L1039 287 Q1062 270 1069 230 Q1073 192 1086 183 Q1106 172 1122 192 L1140 203 Q1159 236 1158 280 Q1155 314 1170 327 L1205 348 Q1222 349 1238 381 Q1269 434 1279 485 Q1285 535 1308 570 L1350 630Z',[810,183,540,459],['#d4ccba','#b6b49f','#989b86','rgba(67,63,48,.12)','rgba(246,235,211,.30)'],2);
      H.songPeak(g,'M244 675 Q265 627 290 598 L310 566 Q319 546 341 533 L362 520 Q378 505 388 481 Q400 453 402 415 L410 389 L417 340 Q429 321 431 294 Q437 266 452 255 L461 226 Q469 199 486 203 Q500 196 511 214 L528 224 Q539 248 531 280 L539 307 Q541 330 564 343 L583 350 Q604 370 602 401 L610 452 Q603 480 622 517 L621 563 Q636 592 651 612 L687 653 L711 675Z',[244,200,467,475],['#bdb5a0','#8e907b','#606a59','rgba(34,34,28,.29)','rgba(245,232,204,.37)'],3);
      // One monumental mass dominates the hanging-scroll composition. Its
      // broken crown and long cliff planes are different from the lower hills.
      H.songPeak(g,'M656 718 Q677 679 693 650 L690 618 L711 586 L709 551 L735 530 L747 487 L743 452 L766 423 L775 363 L767 330 L778 285 L773 244 L791 213 L798 174 L813 153 L802 111 L829 94 L844 60 L872 68 L900 42 L931 55 L947 40 L974 58 L999 46 L1033 72 L1067 66 L1089 98 L1095 139 L1117 170 L1128 228 L1119 285 L1141 334 L1131 395 L1160 448 L1168 503 L1190 561 L1217 608 L1210 657 L1240 718Z',[656,40,584,678],['#a0a18b','#6d7563','#3e4c40','rgba(20,25,22,.34)','rgba(238,227,200,.35)'],4);
      H.songPeak(g,'M1116 710 Q1136 641 1156 596 L1170 554 Q1164 522 1187 508 L1213 488 Q1228 466 1231 427 Q1238 382 1260 350 Q1291 317 1315 332 Q1327 319 1344 334 Q1366 347 1378 380 L1393 401 Q1406 438 1398 470 Q1395 510 1409 554 Q1431 604 1453 627 L1484 662 Q1541 689 1600 705Z',[1116,325,484,385],['#b0aa91','#848b72','#56664f','rgba(33,37,28,.29)','rgba(239,227,197,.32)'],5);
      K.path(g,'M1017 197 Q1000 242 1006 279 L1001 317 L1014 318 L1018 281 Q1010 244 1025 199Z','#eee7d0');
      H.stroke(g,'M1021 206 Q1006 249 1012 280 L1007 315','rgba(252,243,224,.76)',1.5);
      K.path(g,'M1000 310 Q981 397 1010 476 Q1020 511 997 568 L1009 569 Q1032 511 1021 474 Q992 386 1015 313Z','#f5ecd8');
      for(let i=0;i<9;i++)H.stroke(g,`M${996+i*2} 324 Q${979+i*2} 393 ${1006+i*2} 473 Q${1024+i} 526 ${1001+i} 567`,'rgba(251,242,222,.65)',1);
      // A few calligraphic shrubs gather on authored shelves, leaving wash planes legible.
      for(const [x,y,n] of [[456,315,6],[531,388,5],[841,415,5],[927,279,5],[1047,461,4],[1244,461,4],[1370,507,6]]){for(let j=0;j<n;j++)K.path(g,`M${x+j*6} ${y+Math.sin(j)*3} q-4 -7 -2 -12 q8 0 9 10Z`,'rgba(35,39,30,.50)');}
      // Low mist softens the vertical mountains into a continuous journey.
      let mist=K.gradient(g,[0,564],[0,740],[[0,'rgba(237,228,207,0)'],[.45,'rgba(237,228,207,.82)'],[.73,'rgba(237,228,207,.98)'],[1,'rgba(237,228,207,1)']]);K.rect(g,0,564,1600,176,mist);
      K.path(g,'M0 789 L0 654 Q31 644 58 619 Q82 623 105 645 L137 656 Q159 634 180 628 Q201 642 223 667 L272 693 Q297 718 341 748 L420 799Z','#4c5141','#2f392e',1.5);
      K.path(g,'M0 650 Q23 682 14 724 L51 753 Q105 739 146 792 L226 800 Q155 739 147 711 Q109 675 60 632Z','rgba(19,27,22,.23)');
      K.path(g,'M1170 793 Q1237 747 1286 714 Q1303 675 1333 656 Q1361 653 1394 674 Q1420 665 1444 644 Q1462 621 1480 638 L1512 651 L1540 655 Q1572 634 1600 626 L1600 793Z','#626b51','#34452f',1.4);
      K.path(g,'M1328 658 Q1337 697 1290 737 L1254 774 L1370 800 Q1337 741 1392 678Z','rgba(23,34,24,.24)');
      for(const [x,y,w] of [[31,690,39],[107,718,29],[196,736,34],[1323,713,29],[1424,694,32],[1517,713,34]]){H.stroke(g,`M${x} ${y} l${w*.4} -7 l${w*.6} 8 M${x+w*.7} ${y+4} q-11 15 -7 34`,'rgba(29,39,27,.48)',1.2);H.stroke(g,`M${x+9} ${y+4} q-6 13 -3 24`,'rgba(34,42,29,.35)',.8);}
      H.pine(g,199,733,1.64,'#283d2c','rgba(31,45,30,.28)');H.pine(g,89,705,1.15,'#374735','rgba(31,45,30,.25)');H.pine(g,1401,710,.77,'#2e412b','rgba(31,45,30,.25)');
      K.path(g,'M0 799 Q340 787 481 767 Q805 752 1058 778 Q1299 804 1600 782 L1600 826 L0 826Z','#b6ac8b');
      H.stroke(g,'M0 787 Q324 784 477 770 Q815 758 1058 778 Q1294 798 1600 783','#817e62',2);
      H.stroke(g,'M314 811 Q562 788 849 796 T1300 813','rgba(82,77,53,.34)',1.2);
      for(const [x,y,w] of [[105,808,31],[323,801,24],[622,805,37],[1011,807,26],[1231,817,33],[1492,803,29]]){K.path(g,`M${x-w} ${y+5} l${w*.5} -12 l${w*.7} -3 l${w*.8} 10 l-4 7Z`,'#b1a787','rgba(76,81,53,.48)',.75);H.stroke(g,`M${x-w*.5} ${y-7} l${w*.2} 10 l${w*.6} -4 M${x-w*.8} ${y+3} l${w*.6} -1`,'rgba(76,81,53,.30)',.7);H.reeds(g,x+w+3,y+5,13,'rgba(77,102,69,.43)');}

      // A tiny riverside hermitage establishes the immense landscape scale.
      K.rect(g,1054,689,66,41,'#c6baa0','#736d51',1);H.roof(g,1087,692,94,29,'#5a6049','#3a4736');K.rect(g,1082,707,13,23,'#394333');
      for(let i=0;i<26;i++){let x=377+K.rnd(i+111)*816,y=729+K.rnd(i+49)*27;H.stroke(g,`M${x} ${y} h${14+K.rnd(i)*55}`,'rgba(116,111,86,.18)',1);}
      H.stroke(g,'M447 275 l19 25 l-11 39 l21 13 l-14 61 l27 17 M475 236 l-8 48 l23 23 l-7 54 M893 329 l20 27 l-14 52 l20 39 l-8 57 M957 210 l-9 61 l22 28 l-13 44 l24 56','rgba(42,43,31,.42)',1.4);
      for(let j=0;j<32;j++){let x=1074+j*2.4,y=738+Math.sin(j*.36)*3;K.ellipse(g,x,y,2.8,1.3,'rgba(45,53,33,.50)');}
      for(let j=0;j<17;j++){let x=340+j*9,y=772-j*.38;H.stroke(g,`M${x} ${y} q3 -8 6 -2`,'rgba(53,62,39,.46)',.7);}
      H.pine(g,478,316,.18,'#384b34','rgba(47,72,48,.12)');H.pine(g,951,277,.16,'#384b34','rgba(47,72,48,.12)');
      H.pine(g,829,401,.24,'#4c6042','rgba(47,72,48,.09)');H.pine(g,1268,411,.3,'#596a4c','rgba(47,72,48,.08)');
      for(const [x,y,s] of [[851,80,.13],[913,63,.11],[998,68,.12],[1061,91,.14],[1118,319,.15]])H.pine(g,x,y,s,'#3e503d','rgba(43,65,42,.12)');
      // A ledge temple is small enough to measure the cliff, not compete with it.
      K.path(g,'M1066 406 l16 -7 l23 1 l25 7 l-14 5 l-41 -1Z','#74806a','#505f48',.65);
      K.rect(g,1082,391,23,13,'#b1b196','#59654c',.65);H.roof(g,1093,392,36,12,'#5c6b55','#475a43');
      K.rect(g,1091,395,5,9,'#485940');H.stroke(g,'M1078 406 h31 M1081 409 h30','rgba(44,61,39,.58)',.65);
      // Shore contours, small stone steps and the hermitage's recessed windows.
      H.lattice(g,1061,701,12,16,'#8a8566',6);H.lattice(g,1100,701,12,16,'#8a8566',6);
      for(let j=0;j<6;j++)K.line(g,[[1073-j*2,732+j*2],[1108+j*2,732+j*2]],'rgba(107,100,73,.44)',.65);
      H.stroke(g,'M400 717 Q608 700 793 719 T1185 720 M537 734 Q697 726 850 737 M880 749 Q1000 755 1183 740','rgba(112,112,84,.18)',.7);
      for(let j=0;j<11;j++){const x=345+j*71,y=749+Math.sin(j*1.7)*5;H.stroke(g,`M${x} ${y} q13 -2 29 0 M${x+9} ${y+3} h16`,'rgba(96,100,72,.20)',.65);}
      for(const [x,y,h] of [[49,802,23],[303,800,25],[1243,808,20],[1530,798,29]])H.reeds(g,x,y,h,'rgba(48,63,37,.57)');

    }),0,0,1600,900);
      const d=t*24;for(let j=0;j<3;j++){let x=1150+j*34-d,y=247+j*9+Math.sin(t*1.4+j)*4;H.stroke(c,`M${x-7} ${y-3} Q${x-3} ${y-7} ${x} ${y} Q${x+4} ${y-7} ${x+8} ${y-3}`,'#555a43',1.1);}
      for(let j=0;j<16;j++){const u=((t*.16+j*.063)%1+1)%1,y=330+u*228,x=1005-11*Math.sin(u*tau);H.stroke(c,`M${x} ${y} q-2 9 1 16`,'rgba(254,247,230,.49)',.75);}
      for(let j=0;j<3;j++){let shift=Math.sin(t*.24+j)*22;K.path(c,`M${348+shift} ${597+j*31} Q650 ${572+j*35} 949 ${598+j*28} Q1111 ${604+j*31} 1277 ${590+j*35} Q969 ${623+j*27} 682 ${617+j*30} Q441 ${616+j*30} ${348+shift} ${597+j*31}Z`,'rgba(241,232,211,.10)');}
      const boatX=473-t*4.1,boatY=744+Math.sin(t)*.4;K.path(c,`M${boatX-23} ${boatY} Q${boatX} ${boatY+10} ${boatX+23} ${boatY-2} Q${boatX+9} ${boatY+13} ${boatX-18} ${boatY+5}Z`,'#60664b');
      const boatHand=H.inkBoatman(c,boatX-4,boatY,25.4,t),poleX=boatX+27+Math.sin(t)*5;
      K.line(c,[boatHand,[poleX,boatY+8]],'#626548',.9);H.ripple(c,poleX,boatY+9,(t*.4)%1,'#aaa58a',17);
      H.inkScholar(c,1130,742,26.5,H.look(1130,H.hero(4,t)),H.notice(1130,H.hero(4,t),550));
    },pose(t){let x=620+t*37,s=.13,ground=H.songRoad?H.songRoad(x):766+(x-700)*.018;return{x,y:ground-102*s,scale:s,style:4,expression:'calm',headNod:.035*Math.sin(t),gazeY:-.15};},over(c,t){
      for(const [x,y,w] of [[34,809,43],[1537,807,48]]){K.path(c,`M${x-w} ${y+17} L${x-w*.75} ${y-3} L${x-w*.23} ${y-14} L${x+w*.42} ${y-5} L${x+w} ${y+17}Z`,'#716d51','#434c35',1);H.inkStroke(c,[[x-w*.7,y-2],[x-w*.2,y-8],[x+w*.25,y+1]],1.05,'rgba(37,44,29,.48)');H.reeds(c,x+w*.65,y+12,28,'#4b5638',t);}
    }};

  const bridgeY=x=>750-112*Math.sin(Math.PI*K.clamp((x-340)/1000));
  H.bridgeRail=(c,fg=false)=>{const col=fg?'#795c3c':'#a88555',base=fg?15:-9;let pts=[];for(let x=340;x<=1340;x+=10)pts.push([x,bridgeY(x)+base-38]);K.line(c,pts,col,fg?4:3);for(let x=355;x<1340;x+=38){let y=bridgeY(x)+base;K.line(c,[[x,y],[x,y-43]],col,fg?4:3);K.circle(c,x,y-45,3,col);} };
  P.scenes[5]={title:'汴河虹桥',en:'RIVERSIDE SCROLL',date:'约公元 1100 年',style:5,dark:false,accent:'#8d7958',
    draw(c,t){c.drawImage(K.cached('h-riverside',g=>{
      H.paper(g,'#e8dfc4','rgba(91,79,53,.07)',3600);
      // Two unequal banks open a river into the distance. Roof scale follows
      // those banks; the scroll retains distributed viewpoints instead of a grid.
      K.path(g,'M0 424 Q350 414 754 396 L781 449 Q633 505 533 562 Q355 601 0 637Z','#c9bd96');
      K.path(g,'M846 397 Q1179 391 1600 424 L1600 638 Q1311 592 1091 546 Q939 502 826 449Z','#d1c29a');
      K.path(g,'M754 396 Q791 401 846 397 L826 449 Q937 501 1091 546 Q1312 592 1600 638 L1600 825 L0 825 L0 637 Q354 601 533 562 Q633 505 781 449Z','#aebfb1');
      K.path(g,'M786 420 Q735 491 641 542 Q495 608 348 640 L579 640 Q724 530 809 455Z','rgba(229,223,193,.24)');
      H.stroke(g,'M754 396 L781 449 Q633 505 533 562 Q355 601 0 637 M846 397 L826 449 Q939 502 1091 546 Q1311 592 1600 638','#9a9d7f',1.1);
      for(let row=0;row<12;row++){const yy=455+row*25,span=35+row*59;for(let j=0;j<4;j++){const xx=791-span+j*span*.49+(j%2)*13;H.stroke(g,`M${xx} ${yy+Math.sin(j+row)*5} q${13+row*2} -2 ${24+row*4} 0`,'rgba(75,112,102,.19)',.7+row*.035);}}
      const distantHouse=(x,y,w,h,col)=>{const ink='#8d8d74';K.path(g,`M${x-w*.35} ${y} h${w*.70} v${h} h${-w*.7}Z`,col,ink,.6);H.roof(g,x,y,w,w*.27,'#8c9b91',ink);K.rect(g,x-w*.12,y+h*.38,w*.2,h*.62,'rgba(77,88,71,.18)',ink,.5);if(w>53)K.rect(g,x+w*.16,y+h*.31,w*.12,h*.31,null,ink,.6);};
      g.save();g.globalAlpha=.56;
      [[60,354,112,76],[174,370,102,66],[282,384,94,60],[385,399,83,53],[478,414,71,46],[557,428,60,39],[625,439,48,31],[684,445,39,26],[729,443,28,20]].forEach(([x,y,w,h],j)=>distantHouse(x,y,w,h,j%2?'#ddc7a0':'#cfc5a6'));
      [[889,433,30,23],[932,437,41,30],[992,431,52,36],[1061,419,64,44],[1140,406,76,53],[1231,389,90,65],[1335,374,106,72],[1453,356,124,86],[1581,345,129,91]].forEach(([x,y,w,h],j)=>distantHouse(x,y,w,h,j%2?'#d6c5a2':'#e0d1ac'));g.restore();
      // A distant ferry is deliberately much smaller than the two near boats.
      K.path(g,'M783 485 Q804 493 831 482 Q819 497 793 491Z','#7d8169','#737a64',.7);K.path(g,'M798 484 Q800 470 812 471 Q823 472 824 484Z','#cfc2a0','#8b876a',.65);K.line(g,[[794,480],[789,468]],'#6b725c',.65);
      // Fine, stacked roofs and open shops build a bustling river town.
      const shop=(x,y,w,h,roof,wall)=>{const ink='#736b56';K.rect(g,x-w*.38,y,w*.76,h,wall,ink,1.2);const tall=h>125;H.roof(g,x,y,w,tall?55:39,roof,ink);for(let j=-2;j<=2;j++){const xx=x+j*w*.13;K.line(g,[[xx,y+8],[xx,y+h]],ink,1.5);if(j<2){K.rect(g,xx+4,y+(tall?57:22),w*.13-8,h-(tall?65:30),'rgba(88,86,57,.21)',ink,.7);if(j%2===0)H.lattice(g,xx+6,y+18,w*.13-12,tall?31:18,'#a38f65',8);}}K.line(g,[[x-w*.38,y+h*.55],[x+w*.38,y+h*.55]],'#a28c66',1);if(tall){K.path(g,`M${x-w*.40} ${y+53} h${w*.8} l12 11 h${-w*.8-24}Z`,'#bfac7c',ink,.8);for(let j=-3;j<=3;j++)K.line(g,[[x+j*w*.10,y+37],[x+j*w*.10,y+55]],ink,1);K.line(g,[[x-w*.33,y+40],[x+w*.33,y+40]],ink,1.3);}K.rect(g,x-w*.40,y+h-8,w*.8,8,'#afa57b',ink,.7);};
      shop(120,454,210,134,'#7f9489','#d2bb91');shop(308,439,178,145,'#6e877f','#d8c39d');shop(477,480,208,113,'#859389','#e0c9a1');shop(1416,440,251,149,'#657e78','#cfb68d');shop(1254,487,160,100,'#7b8d80','#ddc7a0');
      shop(104,351,154,91,'#a1aa91','#ded6b6');shop(260,330,179,100,'#8a9d8c','#e5d8b6');shop(1399,333,165,91,'#8d9c8c','#e5d8b6');
      K.rect(g,16,579,520,27,'#bcb58b');K.rect(g,1177,582,423,25,'#b8af83');
      // Painted stone approaches make the bridge a continuous traversable lane.
      for(const side of [0,1]){g.save();if(side){g.translate(1600,0);g.scale(-1,1);}K.path(g,'M0 750 L342 750 L342 791 Q160 815 0 799Z','#d0c29b','#9d8e68',1.1);K.line(g,[[0,750],[342,750]],'#8a704c',1.4);for(let row=0;row<3;row++)for(let j=0;j<6;j++){let xx=j*65-(row%2)*33,yy=758+row*15;K.path(g,`M${xx} ${yy} h58 v12 h-58Z`,null,'rgba(133,124,89,.24)',.6);}K.path(g,'M323 753 L345 753 L345 820 L322 820Z','#aaa37c','#8c8963',.7);g.restore();}

      for(let x=51;x<551;x+=39)K.line(g,[[x,603],[x,653]],'#9b8a62',4);
      let top=[],bottom=[];for(let x=340;x<=1340;x+=10){top.push([x,bridgeY(x)]);bottom.unshift([x,bridgeY(x)+31]);}K.line(g,[...top,...bottom],'#8a704c',2,true,'#c4ab79');
      for(let x=352;x<1340;x+=25){let y=bridgeY(x);K.line(g,[[x,y+3],[x+2,y+29]],'#a88c5c',1);}
      // Interlocked timber under the rainbow arch.
      for(let j=0;j<16;j++){let x=379+j*57,y=bridgeY(x);K.line(g,[[x,y+28],[x+66,bridgeY(x+66)+77]],'#a28b5b',6);K.line(g,[[x,y+76],[x+66,bridgeY(x+66)+28]],'#a28b5b',6);}
      H.bridgeRail(g,false);
      H.pine(g,1511,586,.86,'#83916d','rgba(90,108,72,.12)');
      K.rect(g,288,481,39,61,'#ead9af','#b29b6b',1);K.text(g,'茶',308,522,27,'#8c7756','center','serif');
      // Window screens, roof finials, shop wares and hanging shop curtains.
      for(let j=0;j<8;j++){let x=48+j*56;K.rect(g,x,485,26,39,'rgba(91,82,57,.16)','#9a8662',.8);for(let k=1;k<4;k++)K.line(g,[[x+k*6.5,485],[x+k*6.5,524]],'#a08d69',.7);K.line(g,[[x,501],[x+26,501]],'#a08d69',.7);}
      for(let j=0;j<6;j++){let x=1245+j*43;K.rect(g,x,478,21,35,'rgba(77,82,59,.18)','#9c8864',.8);K.line(g,[[x,489],[x+21,489]],'#a8946e',.7);}
      K.path(g,'M61 546 L196 546 L210 567 L48 567Z','#c5ad7d','#8f7c56',1.2);for(let x=68;x<190;x+=17)K.line(g,[[x,548],[x+1,566]],'#b79969',1);
      K.line(g,[[59,565],[59,599]],'#8f7b56',2);K.line(g,[[199,565],[199,599]],'#8f7b56',2);
      for(let j=0;j<7;j++){let x=69+j*18;K.ellipse(g,x,592,8,4,'#b2925f','#8d7650',.8);for(let k=0;k<3;k++)K.circle(g,x-4+k*4,587-k%2*3,3,['#b68d57','#bf9c66','#d1ac71'][k]);}
      for(let j=0;j<12;j++){let x=1310+j*14;K.line(g,[[x,549],[x,577]],'#aa9570',.7);}
      for(let x=384;x<1310;x+=57){let y=bridgeY(x)+27;K.circle(g,x,y,2.1,'#8b6f45');K.circle(g,x+16,y+8,1.2,'#aa8a58');}
      H.stroke(g,'M569 393 Q657 364 711 382 Q755 358 829 373 Q918 340 997 376 L1120 395','rgba(134,143,107,.35)',1.2);
      // Individual shop goods and carpentry; line density stays behind the rider.
      for(const [x,y] of [[224,549],[408,555],[1261,550],[1464,553]]){K.rect(g,x-24,y,48,27,'#c9b68c','#99815c',.7);for(let k=0;k<5;k++){let xx=x-18+k*9;K.path(g,`M${xx-3} ${y+1} q-5 -6 0 -11 h5 q5 5 0 11Z`,'#bfa376','#8e7958',.65);K.ellipse(g,xx+2,y-10,3,1,null,'#8e7958',.55);}K.line(g,[[x-22,y+27],[x-22,y+39],[x-17,y+39]],'#8e7958',1);K.line(g,[[x+20,y+27],[x+20,y+39]],'#8e7958',1);}
      // Four small activities interrupt the street rhythm, each with a purpose.
      if(!H.scrollCharacterId(3))H.scrollFolk(g,106,598,.53,'#718b76',3,1);if(!H.scrollCharacterId(7))H.scrollFolk(g,164,599,.42,'#c3b08b',7,-1);H.basket(g,187,602,23,17);
      if(!H.scrollCharacterId(1))H.scrollFolk(g,371,598,.56,'#a59a73',1,1);if(!H.scrollCharacterId(5))H.scrollFolk(g,436,598,.38,'#879a86',5,-1);
      K.rect(g,1251,587,26,6,'#ac9469','#8b7856',.7);K.line(g,[[1254,593],[1253,603]],'#8b7856',1);K.line(g,[[1274,593],[1275,603]],'#8b7856',1);if(!H.scrollCharacterId(2)){H.scrollFolk(g,1264,585,.48,'#7b9582',2,1);K.line(g,[[1261,586],[1270,598],[1282,598]],'#8b8061',1.2);}H.basket(g,1295,603,28,24);H.basket(g,1321,603,19,15);
      if(!H.scrollCharacterId(0))H.scrollFolk(g,1502,599,.54,'#a07954',0,-1);if(!H.scrollCharacterId(7))H.scrollFolk(g,1544,599,.34,'#879a86',7,-1);K.rect(g,1470,584,19,19,'#bdaa7f','#8b8061',.7);K.line(g,[[1472,586],[1487,601],[1487,586],[1472,601]],'#96815d',.6);
      for(let j=0;j<16;j++){const x=379+j*57,y=bridgeY(x),xe=x+66,ye=bridgeY(xe);K.line(g,[[x,y+28],[xe,ye+77]],'#c4b084',1);K.line(g,[[x,y+76],[xe,ye+28]],'#c4b084',1);K.circle(g,x,y+28,1.2,'#796749');K.circle(g,xe,ye+28,1.2,'#796749');}

    }),0,0);
      const r=H.hero(5,t),people=[[370,5,.54],[445,7,.53],[507,4,.57],[1084,0,.53],[1135,3,.55],[1205,1,.51],[1291,5,.54],[294,0,.47],[1430,7,.47]];
      for(const [x,y,ss,role,dir] of [[106,598,.53,3,1],[164,599,.42,7,-1],[371,598,.56,1,1],[436,598,.38,5,-1],[1264,585,.48,2,1],[1502,599,.54,0,-1],[1544,599,.34,7,-1]])H.scrollCharacter(c,x,y,ss,role,dir,H.responsePhase(x,r,540));
      people.forEach(([x,role,ss],j)=>{const y=x>335&&x<1340?bridgeY(x)-6:604,noticed=H.notice(x,r,540),dir=role===1?-1:H.look(x,r);if(!H.scrollCharacter(c,x,y,ss,role,dir,H.responsePhase(x,r,540)))H.scrollFolk(c,x,y,ss,['#6b8274','#b09873','#968267','#c0ac87'][j%4],role,dir,noticed*(j%3===0?.75:.15));});
      // One bent observer, one answering gesture and a walking child make a
      // legible gathering beside the arch instead of a repeated row of faces.
      if(!H.scrollCharacter(c,550,bridgeY(550)-7,.57,4,1,H.responsePhase(550,r,540)))H.scrollFolk(c,550,bridgeY(550)-7,.57,'#899782',4,1);
      if(!H.scrollCharacter(c,580,bridgeY(580)-7,.55,0,-1,H.responsePhase(580,r,540)))H.scrollFolk(c,580,bridgeY(580)-7,.55,'#b7a07a',0,-1,.3+.35*H.notice(580,r,540));
      if(!H.scrollCharacter(c,613,bridgeY(613)-7,.34,5,1,H.responsePhase(613,r,540)))H.scrollFolk(c,613,bridgeY(613)-7,.34,'#bcae8a',5,1);
      const bx=170+t*8,by=697,rx=1453-t*6,ry=692;
      for(let j=0;j<8;j++){let yy=by+24+j*4,ww=66-j*5;H.stroke(c,`M${bx-ww+Math.sin(t*2+j)*6} ${yy} q${ww} ${Math.sin(j+t)*2} ${ww*2} 0`,'rgba(125,117,77,.16)',2);H.stroke(c,`M${rx-ww+Math.sin(t*1.6+j)*6} ${ry+25+j*4} h${ww*2}`,'rgba(125,117,77,.14)',2);}
      H.boat(c,bx,by,.77,t,1);H.boat(c,rx,ry,.75,t+.6,-1);
      for(let j=0;j<6;j++){let phase=(t*.21+j*.17)%1;H.ripple(c,bx-101-j*3,by+31+j*3,phase,'#9aac94',24+j*5);H.ripple(c,rx+96+j*3,ry+31+j*3,phase,'#9aac94',22+j*4);}
      // A pair of ducks leaves V-shaped wakes below the bridge.
      for(let j=0;j<2;j++){let x=101+t*13-j*26,y=806+j*7;K.ellipse(c,x,y,7,3.6,'#a8ad8c','#778d72',.6);K.circle(c,x+6,y-4,3,'#839878');K.line(c,[[x+8,y-4],[x+13,y-3]],'#b19460',1.5);H.stroke(c,`M${x-8} ${y} l-23 -3 M${x-8} ${y+2} l-23 5`,'rgba(100,131,111,.35)',.8);}
      let sway=Math.sin(t*2)*5;K.path(c,`M331 478 Q348 ${479+sway} 361 ${477+sway} L361 ${506+sway} Q346 ${508+sway} 331 505Z`,'#d9c69d','#9c8561',.9);H.stroke(c,`M338 488 q7 ${sway*.3} 15 0 M338 495 q8 ${sway*.3} 15 0`,'#9c8561',1.1);
    },pose(t){
      const x=657+t*37,s=1.02;
      let tilt=Math.atan2(bridgeY(x+150*s)-bridgeY(x-130*s),280*s);
      // Support the rigid wheelbase at both contact points on the curved deck.
      // A tangent at the crank leaves both tyres hovering over a convex bridge.
      for(let j=0;j<3;j++){
        const cs=Math.cos(tilt),sn=Math.sin(tilt);
        const rearX=x+s*(-130*cs-25*sn),frontX=x+s*(150*cs-25*sn);
        tilt=Math.atan2(bridgeY(frontX)-bridgeY(rearX),frontX-rearX);
      }
      const cs=Math.cos(tilt),sn=Math.sin(tilt);
      const rearX=x+s*(-130*cs-25*sn),frontX=x+s*(150*cs-25*sn);
      const rearY=bridgeY(rearX)-s*(-130*sn+25*cs+77);
      const frontY=bridgeY(frontX)-s*(150*sn+25*cs+77);
      const wave=Math.sin(Math.PI*K.clamp((t-1.6)/1.35));
      return{x,y:(rearY+frontY)/2,scale:s,tilt,style:5,bellPress:wave,headNod:.035*wave,gazeX:.2};
    },
    over(c,t){H.bridgeRail(c,true);for(const [x,y,h] of [[18,801,31],[286,800,21],[1457,798,28],[1550,802,36]])H.reeds(c,x,y,h,'rgba(99,118,76,.66)',t);}};

  P.scenes[6]={title:'玛雅抄本',en:'MAYA FOLDED CODEX',date:'约公元 1200 年',style:6,dark:false,accent:'#ab493a',
    draw(c,t){c.drawImage(K.cached('h-maya',g=>{
      H.paper(g,'#ead9b2','rgba(78,51,31,.1)',4600);const ink='#49372b',red='#b7402b';
      K.rect(g,26,190,1548,593,null,red,8);K.rect(g,42,207,1516,559,null,ink,1.8);K.rect(g,422,208,3,557,'rgba(102,73,45,.34)');K.rect(g,1185,208,3,557,'rgba(102,73,45,.34)');K.rect(g,429,208,13,557,'rgba(255,248,216,.25)');K.rect(g,1171,208,13,557,'rgba(104,68,39,.06)');
      K.rect(g,45,208,376,557,'rgba(203,155,81,.08)');K.rect(g,1189,208,366,557,'rgba(203,155,81,.06)');
      for(let j=0;j<14;j++)H.mayaGlyph(g,101+j*107,241,j,.90);
      for(const x of [423,1186]){K.path(g,`M${x-13} 210 L${x-1} 210 L${x-1} 765 L${x-13} 765Z`,'rgba(107,69,34,.11)');K.path(g,`M${x+2} 211 L${x+13} 211 L${x+13} 764 L${x+2} 764Z`,'rgba(252,239,205,.46)');}

      const temple=(x,y,w,levels)=>{for(let j=0;j<levels;j++){let ww=w*(1-j/(levels+1)),yy=y-j*31;K.rect(g,x-ww*.5,yy,ww,31,(j%2?'#c5a86f':'#b69a66'),ink,1.5);K.rect(g,x-ww*.5+2,yy+23,ww-4,7,'rgba(96,77,50,.11)');K.line(g,[[x-ww*.5+2,yy+3],[x+ww*.5-2,yy+3]],'#d5c59a',.9);for(let k=0;k<5;k++){let xx=x-ww*.4+k*ww*.2;K.rect(g,xx,yy+8,ww*.1,12,null,'rgba(92,73,54,.5)',.8);if(k%2)H.stroke(g,`M${xx+3} ${yy+11} h${ww*.1-6} v5 h${-ww*.06}`,'#8d7654',.7);else K.circle(g,xx+ww*.05,yy+14,2.2,'#ab714e');}}
        K.path(g,`M${x-14} ${y-levels*31+21} L${x+14} ${y-levels*31+21} L${x+26} ${y+30} L${x-26} ${y+30}Z`,'#c9ba91',ink,.9);for(let j=0;j<levels*3;j++){const yy=y-levels*31+25+j*10,ww=15+j*.67;K.line(g,[[x-ww,yy],[x+ww,yy]],'#8c7854',.7);}
        K.rect(g,x-28,y-levels*31-21,56,51,'#b88b62',ink,1.4);K.rect(g,x-12,y-levels*31-13,24,37,ink);K.rect(g,x-32,y-levels*31-26,64,7,'#c3a374',ink,.9);K.rect(g,x-21,y-levels*31-16,42,42,null,'#ddc58e',.9);for(const d of [-1,1])for(let k=0;k<4;k++)K.line(g,[[x+d*23,y-levels*31-11+k*10],[x+d*17,y-levels*31-11+k*10]],ink,.65);
      };
      temple(235,694,270,5);temple(1375,687,259,4);
      for(const [x,y,w] of [[235,726,293],[1375,719,281]]){K.path(g,`M${x-w/2} ${y} h${w} l-7 10 h${-w+14}Z`,red,ink,1.2);for(let j=0;j<9;j++){const xx=x-w*.42+j*w*.105;K.path(g,`M${xx} ${y+4} l5 -3 l5 3 l-5 4Z`,'#e5cb8e',ink,.5);}}
      // Flattened decorative birds and dotted calendrical medallions.
      g.save();g.translate(239,413);K.path(g,'M-82 12 Q-59 -51 -10 -25 Q20 -76 42 -45 L68 -31 L104 -28 L60 -15 Q61 13 30 27 L-31 31Z','#bd482f',ink,2.5);K.path(g,'M-23 -5 Q-72 -29 -89 -3 Q-56 42 -13 19Z','#367f70',ink,2);K.circle(g,44,-32,9,'#e7d5a9',ink,2);K.circle(g,46,-32,3,ink);for(let j=0;j<6;j++)H.stroke(g,`M${-63+j*9} 0 q5 17 19 20`,ink,1.6);K.line(g,[[9,28],[2,57],[20,59]],ink,3);K.line(g,[[30,28],[31,55],[47,59]],ink,3);g.restore();
      [627,827,1027].forEach((x,j)=>{K.circle(g,x,348,44,null,red,3);K.circle(g,x,348,35,null,ink,2);for(let k=0;k<8;k++){let a=k*tau/8;K.circle(g,x+Math.cos(a)*25,348+Math.sin(a)*25,2.5,ink);}K.line(g,[[x-16,348],[x+16,348]],ink,5);for(let k=0;k<=j;k++)K.circle(g,x-9+j*-2+k*10,335,3.3,ink);});
      K.line(g,[[444,746],[1168,746]],red,3);H.meander(g,788,'#aa5141',.9);
      // The numeral register sits above the passing beak, in the codex margin.
      K.rect(g,1260,43,232,137,null,ink,2);K.rect(g,1268,51,216,121,null,red,1.5);
      for(let i=0;i<6;i++)K.line(g,[[453+i*118,708],[467+i*118,708]],'rgba(92,73,54,.28)',1.5);
      for(let j=0;j<26;j++){let x=64+j*58;K.line(g,[[x,762],[x+18,751],[x+36,762]],'#a65a45',1.1);K.circle(g,x+18,761,2.1,'#6b553b');}
      for(let y=293;y<738;y+=34){K.line(g,[[57,y],[67,y+10],[57,y+20]],'#aa6450',1.1);K.line(g,[[1545,y],[1535,y+10],[1545,y+20]],'#aa6450',1.1);}
      // Paint gathers at panel edges; the paper field remains open.
      for(const x of [40,425,1187,1554])H.stroke(g,`M${x} 293 q3 104 0 179 q-2 109 1 264`,'rgba(115,70,36,.18)',1.2);
      for(let j=0;j<7;j++){let y=489+j*28;H.stroke(g,`M111 ${y} l11 -5 l11 5 l-11 5 Z`,'rgba(100,79,50,.5)',.7);}
      for(let j=0;j<14;j++){const x=62+j*107;H.stroke(g,`M${x+5} 223 h72 M${x+5} 261 h72`,'rgba(170,81,65,.30)',.6);if(j%3===1)H.stroke(g,`M${x+30} 228 l-5 6 l5 6 l-5 6`,'#8d6b48',.7);if(j%3===2){K.circle(g,x+60,255,1.4,red);K.circle(g,x+67,255,1.4,red);}}
      for(const x of [423,1186]){K.rect(g,x-2,211,5,550,K.gradient(g,[x-2,0],[x+3,0],[[0,'rgba(77,55,35,.09)'],[.5,'rgba(246,230,189,.25)'],[1,'rgba(77,55,35,.06)']]));}

    }),0,0);
      const counterRider=H.hero(6,t),startPhase=P.motionAt?P.motionAt(41).phaseTime:0;
      const turns=Math.max(0,(Number.isFinite(counterRider.phaseTime)?counterRider.phaseTime:t)-startPhase);
      // Four earlier marks await the passing rider. One actual complete crank
      // revolution adds the fifth: the dots gather into a single five-bar.
      const completed=Math.floor(turns+1e-8),n=4+completed,bars=Math.floor(n/5),dots=n%5,pulse=completed?1-K.ease((turns%1)/.12):0;
      const carry=completed===1?K.ease((turns-1)/.10):1;
      if(completed===1&&carry<1){
        for(let j=0;j<5;j++){const yy=K.lerp(98,147,carry),xx=K.lerp(1336+j*20,1324+j*22,carry);K.ellipse(c,xx,yy,K.lerp(j===4?5.8+pulse*2.2:5.8,14,carry),K.lerp(5.8,3.5,carry),'#5c4936');}
      }else{
        for(let j=0;j<bars;j++)K.line(c,[[1318,147-j*17],[1434,147-j*17]],'#5c4936',7);
        for(let j=0;j<dots;j++){const rr=5.8+(j===dots-1?pulse*2.2:0);K.circle(c,1336+j*20,98-bars*4,rr,'#5c4936');}
      }
      // The manuscript's seated counter answers that same mechanical event.
      const ink='#5c4936',skin='#b25b3c';
      if(H.characterId('maya_counter'))P.drawCharacter(c,'maya_counter',t,{x:1233,y:546,height:94,phase:completed?K.clamp((turns%1)/.32):0});
      else {
        // A stepped glyph plinth gives the seated counter a register and a
        // grounded base, as opposed to a sprite floating beside the temple.
        K.path(c,'M1204 552 H1301 V562 H1290 V574 H1215 V562 H1204Z','#c09d64',ink,1.4);
        K.path(c,'M1212 556 H1293 M1221 563 H1284 M1225 569 H1280',null,'#965f43',1.2);
        H.mayaCounter(c,1253,546,pulse);
      }
      K.text(c,'踏 板 圈 数',1376,75,15,'#936144','center','serif');
      K.circle(c,282+H.look(239,H.hero(6,t))*1.2,381,2.8,ink);
    },pose:t=>basePose(t,6,1.07,746)};

  P.scenes[7]={title:'莫卧儿细密画',en:'MUGHAL MINIATURE',date:'约公元 1600 年',style:7,dark:false,accent:'#bb873d',
    draw(c,t){c.drawImage(K.cached('h-mughal',g=>{
      H.paper(g,'#efe0b5','rgba(114,78,37,.05)',2200);
      K.rect(g,19,179,1562,633,'#923d45','#bf9854',3);K.rect(g,43,202,1514,588,'#d8ceb0','#f0d49a',2);K.rect(g,63,220,1474,552,'#b9cbbd','#8e7350',2);
      for(let x=36;x<1580;x+=39){H.flower(g,x,190,7,'#e4bd7e','#f5dfaa',6);H.flower(g,x,802,7,'#e4bd7e','#f5dfaa',6);}for(let y=228;y<792;y+=39){H.flower(g,31,y,7,'#e4bd7e','#f5dfaa',6);H.flower(g,1569,y,7,'#e4bd7e','#f5dfaa',6);}
      K.rect(g,75,474,1450,277,'#285d4c');
      K.rect(g,18,176,1564,35,'#183d62','#d8b263',1.1);K.rect(g,18,782,1564,38,'#183d62','#d8b263',1.1);
      for(let j=0;j<28;j++){const x=45+j*56;H.flower(g,x,194,6.5,'#d6ad59','#a64b42',8);H.stroke(g,`M${x+9} 194 q16 -10 31 0 q-16 9 -31 0`,'#80a394',.8);H.flower(g,x,800,6.5,'#d6ad59','#a64b42',8);H.stroke(g,`M${x+9} 800 q16 -10 31 0 q-16 9 -31 0`,'#80a394',.8);}
      for(const x of [19,1543]){K.rect(g,x,214,38,565,'#1c4468','#d2ad63',1);for(let j=0;j<4;j++)H.vine(g,x+19,224+j*133,27,126,'#ba9958','#4d8279','#d1ab64');}
      for(const x of [105,1474]){K.rect(g,x-18,296,36,258,'#e9d7af','#b99b61',.8);H.vine(g,x,316,25,217,'#567b61','#5f896e','#ba9858');}

      // White marble pavilion and delicately nested cusped arches.
      K.rect(g,478,310,649,243,'#f0dfba','#a68c64',2);K.rect(g,457,530,690,23,'#dfc79b','#a68c64',2);K.rect(g,470,300,666,15,'#d4b98c','#997747',1.4);
      for(let x=548;x<=1056;x+=126){H.arch(g,x,530,91,175,'#204c68','#a78b60',2);H.arch(g,x,530,75,159,null,'#e6c991',2);for(let k=0;k<7;k++){let a=k*Math.PI/6;K.ellipse(g,x+Math.cos(a)*35,399-Math.sin(a)*35,8,12,'#e6d2ad',null,1,a);}}
      K.path(g,'M626 300 Q622 243 686 225 Q736 220 768 191 Q796 219 846 225 Q908 244 906 300Z','#ede0bb','#a68b60',2);
      K.path(g,'M739 223 Q765 205 768 184 Q771 204 799 224','#dfc797','#aa8855',1.2);K.line(g,[[768,186],[768,171]],'#b28f4a',3);K.circle(g,768,169,4,'#b28f4a');
      for(let x=495;x<1114;x+=27)K.path(g,`M${x} 294 l8 -11 l8 11Z`,'#ebd8b2','#ac9063',1);
      [369,1215,186,1416].forEach((x,j)=>H.cypress(g,x,594,.88+(j%2)*.1));
      H.mughalTree(g,272,589,.83);H.mughalTree(g,1317,589,.83);
      // Formal garden parterres: tiny individual blooms at miniature scale.
      const beds=[[102,589,255,78],[1200,589,255,78],[102,685,279,61],[1194,685,279,61]];
      beds.forEach(([x,y,w,h],j)=>{K.rect(g,x,y,w,h,'#204a44','#ceac57',3);for(let a=0;a<12;a++)for(let b=0;b<3;b++){let xx=x+14+a*(w-25)/12,yy=y+13+b*(h-18)/3;H.flower(g,xx,yy,3.5,['#b93442','#d7a340','#efe0ad'][b], '#debe76',5);K.line(g,[[xx,yy+3],[xx,yy+8]],'#b2ba83',.6);}});
      K.rect(g,398,611,781,140,'#d9c29a','#a78c63',2);for(let y=625;y<751;y+=20)K.line(g,[[398,y],[1179,y]],'rgba(153,118,75,.21)',1);for(let x=414;x<1178;x+=39)K.line(g,[[x,612],[x,751]],'rgba(153,118,75,.16)',1);
      K.line(g,[[399,752],[1178,752]],'#a4865a',2.5);
      K.rect(g,420,567,734,31,'#d2c6a0','#a38960',2);for(let x=433;x<1147;x+=26){H.arch(g,x,592,14,18,'#347e82','#a38960',1);}
      for(let k=0;k<9;k++){let x=87+k*172;H.flower(g,x,240,7,'#e9d6a8','#b88852',6);}
      for(let x=548;x<=1056;x+=126){g.save();g.beginPath();g.rect(x-30,420,60,109);g.clip();for(let j=-7;j<15;j++){K.line(g,[[x-40,421+j*12],[x+40,501+j*12]],'rgba(223,203,156,.53)',.8);K.line(g,[[x-40,501+j*12],[x+40,421+j*12]],'rgba(223,203,156,.53)',.8);}g.restore();}
      for(let j=0;j<9;j++){let xx=637+j*32;H.stroke(g,`M${xx} 297 Q${K.lerp(xx,768,.68)} 249 768 201`,'rgba(163,130,79,.34)',.85);}
      for(let x=477;x<1130;x+=63){H.flower(g,x,326,5.2,'#bb845e','#ddbc7d',6);K.line(g,[[x,334],[x,349]],'#8c9a6b',.8);H.stroke(g,`M${x} 345 q-12 -9 -14 -5 M${x} 340 q12 -9 14 -5`,'#8c9a6b',.8);}
      for(let j=0;j<12;j++){let x=423+j*62;K.path(g,`M${x} 636 l7 7 l-7 7 l-7 -7Z`,null,'rgba(162,123,75,.34)',.8);K.path(g,`M${x+30} 677 l6 6 l-6 6 l-6 -6Z`,null,'rgba(162,123,75,.28)',.7);}
      // Nested marble panels, jali screens and floral inlays share one fine line.
      for(let x=478;x<1128;x+=126){K.rect(g,x+5,357,17,162,null,'#bba274',.75);H.stroke(g,`M${x+9} 511 v-145 h9`,'#cfbb90',.65);for(let y=368;y<516;y+=29){H.flower(g,x+13,y,3.1,'#b58a68','#d9bc82',5);K.line(g,[[x+13,y+3],[x+13,y+13]],'#8c9b70',.55);}}
      for(const [x,y,w] of [[92,670,287],[1192,670,287]]){K.rect(g,x,y,w,8,'#d1bd88','#967d51',.7);for(let j=0;j<24;j++){const xx=x+5+j*12;K.path(g,`M${xx} ${y+4} l3 -2 l3 2 l-3 2Z`,null,'#9d885b',.55);}}
      for(let row=0;row<5;row++)for(let j=0;j<18;j++){let x=410+j*42,y=619+row*25;if((row+j)%2===0){K.path(g,`M${x} ${y} l5 5 l-5 5 l-5 -5Z`,'rgba(184,146,95,.10)','rgba(158,121,75,.19)',.55);K.circle(g,x,y+5,1,'rgba(129,140,100,.35)');}}
      for(const x of [185,369,1215,1416]){K.ellipse(g,x,597,25,5,'rgba(32,66,47,.12)');}
      for(const x of [495,1120]){K.rect(g,x-8,345,16,182,'#20476a','#d1af66',.8);for(let j=0;j<6;j++){H.flower(g,x,361+j*29,4.7,'#d2b169','#8c4e46',6);}}
      for(let j=0;j<5;j++){const x=548+j*126;K.path(g,`M${x-43} 379 Q${x-41} 346 ${x-12} 340 L${x} 331 L${x+12} 340 Q${x+41} 346 ${x+43} 379`,'#ead5a8','#bb995c',1);H.flower(g,x,350,5.5,'#a43a43','#c5a353',8);H.stroke(g,`M${x-30} 371 q13 -25 23 -13 M${x+30} 371 q-13 -25 -23 -13`,'#668a72',1.1);}
      for(let j=0;j<14;j++){const x=451+j*49;K.path(g,`M${x} 547 l7 -8 l7 8 l-7 8Z`,'#285f6a','#d9b565',.7);K.circle(g,x+7,547,2.1,'#c66b4f');}
      K.ellipse(g,803,608,176,14,'#bdab7f','#a58e63',1.3);K.ellipse(g,803,606,173,12,'#2e8393','#c9b88a',1.5);K.ellipse(g,803,606,153,7,'#55a2a4','#246e7e',.8);H.stroke(g,'M662 607 Q802 614 945 607','rgba(226,223,180,.55)',.7);

    }),0,0);
      const r=H.hero(7,t);[275,1317].forEach((x,j)=>{const notice=H.notice(x,r,780),id=H.characterId(j?'mughal_greeting_red':'mughal_greeting','mughal_greeting');if(id)P.drawCharacter(c,id,t,{x,y:655,height:180,flip:j?-1:1,phase:H.greetingPhase(x,r)});else H.mughalCourtier(c,x,655,1.08,j?'#a63243':'#dfc584',j,j?-1:1,notice);});
      // A third portrait belongs to the upper loggia, behind its stone rail.
      c.save();c.beginPath();c.rect(1021,385,62,144);c.clip();K.rect(c,1021,385,62,144,'#214b62');const upperCharacter=H.characterId('mughal_greeting');if(upperCharacter)P.drawCharacter(c,upperCharacter,t,{x:1052,y:529,height:130,flip:-1,phase:H.greetingPhase(1052,r)});else H.mughalCourtier(c,1052,529,.72,'#e7d8ad',2,-1,.2);K.rect(c,1021,493,62,36,'#cdbb90','#b59658',.6);for(let j=0;j<5;j++)H.arch(c,1027+j*12,524,7,23,'#315c69','#ac935e',.65);K.rect(c,1020,492,65,4,'#e5d3a3','#a98a50',.7);c.restore();
      // Petals drift across the meticulously ordered garden.
      for(let j=0;j<12;j++){let x=320+(j*83+t*24)%1000,y=430+(j*47+t*17)%234;c.save();c.translate(x,y);c.rotate(j+t*.6);K.ellipse(c,0,0,4,1.8,j%2?'#d8b888':'#c55053');c.restore();}
      const waterGate=K.ease((r.x-420)/360)*(1-K.ease((r.x-990)/340));
      // The small garden jets rise into a water arch while the guest passes.
      // Matching drops and landing rings follow each jet's same parabola.
      for(let j=0;j<3;j++){
        const xx=746+j*57,span=24+waterGate*(j===1?143:32),control=531-waterGate*(j===1?400:94),flow=(t*.55+j*.21)%1;
        H.stroke(c,`M${xx-span} 604 Q${xx} ${control} ${xx+span} 604`,'rgba(211,234,216,.84)',j===1?1.65:1.05);
        for(let k=0;k<7;k++){const u=(flow+k/7)%1,x=xx-span+2*span*u,y=(1-u)*(1-u)*604+2*(1-u)*u*control+u*u*604;K.ellipse(c,x,y,j===1?1.35:.85,j===1?1.9:1.35,'rgba(243,244,217,.82)');}
        H.ripple(c,xx+span,606,flow,'#b3c7b1',18+waterGate*18);
      }
      // Near blossoms partially cover the ankles; the loggia portrait remains
      // behind a separate stone rail rather than floating on the pavilion wall.
      for(const x of [275,1317])for(let j=0;j<5;j++){const xx=x-37+j*18,yy=646+(j%2)*7;K.line(c,[[xx,yy+3],[xx,665]],'#a2b174',.85);H.flower(c,xx,yy,3.9,j%2?'#d9ad55':'#b44b4e','#e0c07b',5);}
      // A peacock opens its fan as the unfamiliar visitor approaches the garden.
      const fan=.22+.72*H.notice(1190,r,620),px=1227,py=714;
      for(let j=0;j<13;j++){let a=-Math.PI*.85+j*Math.PI*.095,rr=20+fan*40,xx=px+Math.cos(a)*rr,yy=py+Math.sin(a)*rr;c.save();c.translate(px,py);c.rotate(a);K.ellipse(c,rr*.51,0,rr*.52,3.4,'#607a53','#b3a66b',.6);c.restore();K.ellipse(c,xx,yy,3.2,4.6,'#d3af4e',null,1,a);K.ellipse(c,xx,yy,1.8,2.7,'#237e9a',null,1,a);K.circle(c,xx,yy,1,'#284d55');}
      K.ellipse(c,1209,716,17,8,'#246d86','#365f60',.9);K.path(c,'M1200 717 Q1183 699 1191 687 Q1197 682 1200 690 Q1194 700 1209 713Z','#237d89','#355f60',.8);K.circle(c,1196,688,1.5,'#e3cc8e');K.line(c,[[1190,691],[1182,693]],'#b9a469',1.6);K.line(c,[[1200,723],[1198,731]],'#7f744d',1.1);K.line(c,[[1215,723],[1216,731]],'#7f744d',1.1);
    },pose:t=>basePose(t,7,1.1,751)};

  P.scenes[8]={title:'八大山人写意',en:'BADA SHANREN · INK',date:'约公元 1690 年',style:8,dark:false,accent:'#bc4d3a',
    draw(c,t){c.drawImage(K.cached('h-bada',g=>{
      H.paper(g,'#f2efdf','rgba(59,59,45,.052)',3100);
      // Broad wet ink has ragged edges, with fine dry strokes for contrast.
      g.save();g.translate(199,603);g.rotate(-.17);const leaf='M-126 35 Q-146 -15 -113 -47 Q-103 -77 -74 -81 Q-44 -116 -12 -110 Q20 -110 51 -90 Q84 -92 99 -66 Q124 -59 136 -30 Q106 16 77 27 Q62 48 34 42 Q4 68 -32 59 Q-85 65 -126 35Z';
      K.path(g,leaf,K.gradient(g,[-50,-105],[78,52],[[0,'#2a3e31'],[.5,'#3d503d'],[1,'rgba(58,78,56,.68)']]));g.save();g.clip(new Path2D(leaf));K.path(g,'M-105 -36 Q-43 -104 38 -78 Q6 -36 -5 7 Q-69 -1 -105 -36Z','rgba(9,30,20,.18)');K.path(g,'M-116 32 Q-25 54 61 18 Q37 57 -13 56 L-96 51Z','rgba(176,188,153,.13)');H.stroke(g,'M2 11 Q-21 -25 -53 -76 M3 12 Q24 -18 73 -57 M3 13 Q-47 7 -106 -3','rgba(220,226,198,.23)',2.5);H.stroke(g,'M-115 -17 l17 -8 M-98 31 l21 4 M41 -86 l18 5 M103 -40 l14 7','rgba(234,237,209,.28)',1.2);g.restore();g.restore();
      H.stroke(g,'M201 600 Q270 665 240 781','#4d5d49',3);H.stroke(g,'M277 783 Q318 702 364 677 Q393 660 373 610','#59654d',2.4);
      K.path(g,'M336 627 Q363 588 386 615 Q406 638 374 646Z','rgba(43,57,43,.78)');
      H.stroke(g,'M1120 712 Q1206 609 1251 427 Q1268 362 1320 290','#4b5546',5);H.stroke(g,'M1233 479 Q1339 476 1416 415','#56604d',3);H.stroke(g,'M1256 399 Q1218 371 1214 337','#58604d',2);
      [[1260,435,-.5],[1282,397,-.9],[1229,491,.2],[1335,462,-.2],[1367,443,-.4],[1218,363,1.4]].forEach(([x,y,r],j)=>{g.save();g.translate(x,y);g.rotate(r);K.path(g,'M0 0 Q23 -17 67 -3 Q42 15 0 0Z',j%2?'#76806a':'#4c5848');g.restore();});
      K.path(g,'M1251 753 Q1282 686 1355 697 Q1416 682 1461 738 L1510 777 L1228 784Z','rgba(73,87,66,.34)','#87917a',1.6);
      K.path(g,'M1259 751 Q1295 695 1341 708 Q1316 740 1344 768 L1439 776 Q1363 789 1254 779Z','rgba(47,69,45,.13)');
      H.stroke(g,'M1272 749 q19 -27 47 -31 M1355 711 q41 1 73 38 M1284 763 q63 -8 127 0','rgba(38,61,39,.28)',2.2);

      H.stroke(g,'M78 785 Q387 770 545 780 M1075 781 Q1280 786 1509 781','rgba(75,90,65,.4)',1.6);
      K.rect(g,1450,315,44,46,'#b65343');K.text(g,'墨',1472,348,30,'#e9d9ba','center','serif');
      // A perched observer, drawn with just a few convincing brush marks.
      K.ellipse(g,1350,425,39,25,'#424e40',null,1,-.2);K.ellipse(g,1382,408,23,23,'#414b3d');K.path(g,'M1396 403 L1438 410 L1397 415Z','#797b61');K.path(g,'M1317 431 L1271 444 L1298 412Z','#58614c');K.line(g,[[1344,447],[1340,467]],'#4e5946',2);K.line(g,[[1360,445],[1358,466]],'#4e5946',2);
      H.stroke(g,'M1326 430 q18 6 34 -4 M1331 435 q11 4 20 0','rgba(220,224,201,.17)',.9);
      H.stroke(g,'M343 791 q27 -4 55 0 M331 797 q39 3 76 -1','rgba(94,114,83,.26)',.8);
      for(let j=0;j<7;j++){let x=107+j*13;H.stroke(g,`M${x} 780 q${j%2?8:-8} -19 ${j%2?4:-4} -29`,'rgba(88,104,76,.45)',.7);}
      // Deliberate dry edges and three feather marks keep the central paper open.
      H.stroke(g,'M1261 430 Q1289 424 1313 407 M1287 395 l20 -12 M1334 460 l24 -6','rgba(224,228,205,.32)',.75);
      H.stroke(g,'M1314 424 q25 20 54 1 M1319 430 q17 14 39 4 M1328 437 q13 7 23 2','rgba(225,229,208,.21)',.8);
      H.stroke(g,'M1259 756 q20 -14 38 -11 l-12 -18 M1364 712 q28 6 41 27 l-24 -5','rgba(44,63,43,.24)',1.05);

    }),0,0);
      const r=H.hero(8,t),blink=K.clamp(Math.exp(-Math.pow((t-2.65)/.11,2))+.8*Math.exp(-Math.pow((t-4.95)/.10,2))),eh=Math.max(.65,11*(1-blink));
      K.ellipse(c,1385,405,9,eh,'#e9ebd8');if(blink<.8)K.ellipse(c,1385+H.look(1385,r)*4.3,402-2.2*Math.sin(Math.PI*K.clamp((t-2.8)/1.5)),3.3,Math.min(3.3,eh),'#26372b');
      H.stroke(c,'M1378 392 q8 -3 14 1','#293c2f',1.2);
    },pose:t=>({...basePose(t,8,1.1,781),expression:t>2.65&&t<4.1?'eye-roll':'calm',headNod:.06*Math.sin(Math.PI*K.clamp((t-2.3)/1.8)),gazeX:.7,gazeY:-.2}),
    foreground(c,t){
      // One falling drop is enough movement for this otherwise spare ink painting.
      const u=K.clamp((t-2.05)/1.05);if(t<3.10){let y=647+u*u*144;K.path(c,`M373 ${y-5} Q365 ${y+4} 373 ${y+7} Q380 ${y+4} 373 ${y-5}Z`,'rgba(81,110,88,.58)');}
      if(t>=3.1){H.ripple(c,373,793,(t-3.1)/2.35,'#7c9276',53);H.ripple(c,373,793,(t-3.32)/1.92,'#8b9d7e',37);}
    }};

  H.gunungan=(c,x,y,s,flip=1)=>{c.save();c.translate(x,y);c.scale(s*flip,s);const gold='#bdb668',shape='M0 -350 C-20 -302 -39 -268 -70 -220 C-102 -174 -155 -145 -147 -83 C-143 -40 -94 -16 0 0 C94 -16 143 -40 147 -83 C155 -145 102 -174 70 -220 C39 -268 20 -302 0 -350Z';let holes='';const ring=[];
    for(let j=0;j<6;j++){const yy=-66-j*42,len=[79,98,86,67,45,24][j];for(const d of [-1,1])for(let k=0;k<4;k++){const xx=d*(15+k*(len-15)/4),y1=yy-8-k*6;holes+=`M${xx} ${y1} q${d*-5} -13 ${d*4} -21 q${d*11} 11 ${d*-4} 21Z`;ring.push([xx,y1]);}}
    for(let j=0;j<12;j++){const yy=-310+j*23,ww=(yy+350)*.30;for(const d of [-1,1]){const xx=d*ww;holes+=`M${xx-2.2} ${yy} a2.2 2.2 0 1 0 4.4 0 a2.2 2.2 0 1 0 -4.4 0Z`;}}
    for(const [xx,yy,rr] of [[-101,-89,15],[101,-89,15],[-57,-185,12],[57,-185,12]]){for(let k=0;k<8;k++){const a=k*tau/8,px=xx+Math.cos(a)*rr*.65,py=yy+Math.sin(a)*rr*.65;holes+=`M${px-2.1} ${py} a2.1 2.1 0 1 0 4.2 0 a2.1 2.1 0 1 0 -4.2 0Z`;}holes+=`M${xx-3} ${yy} a3 3 0 1 0 6 0 a3 3 0 1 0 -6 0Z`;}
    c.save();c.clip(new Path2D(shape));c.globalAlpha=.87;c.fillStyle=K.gradient(c,[-120,-300],[140,-10],[[0,'#4c231b'],[.48,'#8b4625'],[1,'#65281c']]);c.fill(new Path2D(shape+holes),'evenodd');c.restore();H.stroke(c,shape,'#332319',1.8);c.save();c.scale(.94,.96);H.stroke(c,shape,'#b3a359',.9);c.restore();
    H.stroke(c,'M0 -26 V-315',gold,2.6);for(let j=0;j<6;j++){const yy=-66-j*42,len=[79,98,86,67,45,24][j];for(const d of [-1,1])H.stroke(c,`M0 ${yy} Q${d*len*.45} ${yy-3} ${d*len} ${yy-32}`,'#b7aa62',1.4);}
    for(const [xx,yy] of ring)H.stroke(c,`M${xx} ${yy+1} l0 -6`,'#b29d54',.6);
    for(const [xx,yy,rr] of [[-101,-89,15],[101,-89,15],[-57,-185,12],[57,-185,12]])K.circle(c,xx,yy,rr,null,'#b7a45d',.7);
    K.path(c,'M-27 -66 Q-39 -25 0 -17 Q39 -25 27 -66Z','#8d522b','#b7aa62',1.2);H.stroke(c,'M-21 -57 Q-14 -30 0 -25 Q14 -30 21 -57 M-15 -58 Q0 -42 15 -58','#e1b56e',1);H.flower(c,0,-47,10,'#c8b867','#704022',6);
    H.stroke(c,'M-112 -61 Q-65 -24 -9 -14 M112 -61 Q65 -24 9 -14','#a19b52',1);c.restore();};
  H.puppet=(c,x,y,s,flip=1,wave=0)=>{
    c.save();c.translate(x,y);c.scale(s*flip,s);const ink='#372019',gold='#c8b469';
    const body='M-16 -137 Q-42 -113 -26 -66 L-50 -11 Q-23 7 27 -5 L22 -65 Q52 -102 15 -135Z';let pierce='';for(let j=0;j<10;j++){const yy=-124+j*11;for(const xx of [-12,0,12]){const rr=xx===0?2.5:1.6;pierce+=`M${xx-rr} ${yy+(xx?4:0)} a${rr} ${rr} 0 1 0 ${rr*2} 0 a${rr} ${rr} 0 1 0 ${-rr*2} 0Z`;}}c.fillStyle=K.gradient(c,[-25,-130],[29,0],[[0,'#4d221b'],[.6,'#763421'],[1,'#8d4927']]);c.fill(new Path2D(body+pierce),'evenodd');H.stroke(c,body,'#30251c',1.1);
    c.save();c.translate(0,-139);c.rotate(-wave*.07);c.translate(0,139);
    K.path(c,'M-13 -139 Q-28 -160 -8 -186 Q5 -206 29 -195 L35 -181 L73 -168 L32 -163 Q26 -137 3 -133Z',ink);
    K.path(c,'M-11 -188 L-17 -224 L3 -205 L6 -238 L20 -209 L35 -222 L31 -192Z',ink);K.path(c,'M-8 -195 l-3 -17 l11 12 l6 -23 l11 22 l11 -9 l-2 17Z',null,gold,.9);K.circle(c,25,-178,3.5,gold);
    H.stroke(c,'M5 -181 q-9 6 0 14 M10 -157 q14 9 24 -2',gold,1.2);K.circle(c,3,-179,2.5,gold);c.restore();
    const ex=48+wave*5,ey=-112-wave*15,hx=95-wave*20,hy=-162-wave*13;
    K.path(c,`M12 -137 Q35 -133 ${ex+4} ${ey-3} L${ex+2} ${ey+5} Q33 -122 13 -128Z`,ink,gold,.65);
    K.path(c,`M${ex-3} ${ey-2} L${hx-4} ${hy-3} L${hx+3} ${hy+2} L${ex+4} ${ey+4}Z`,ink,gold,.6);
    K.path(c,'M-23 -135 Q-61 -137 -81 -100 L-80 -92 L-73 -91 Q-52 -123 -20 -127Z',ink,gold,.65);
    K.path(c,'M-80 -95 L-70 -62 L-61 -64 L-73 -98Z',ink,gold,.65);
    H.stroke(c,`M19 -132 Q36 -129 ${ex} ${ey} M${ex} ${ey} L${hx-3} ${hy+2}`,gold,.75);
    for(let j=0;j<4;j++){const u=(j+.5)/4;K.circle(c,ex+(hx-ex)*u,ey+(hy-ey)*u,1.1,'#e8be70');}
    K.path(c,`M${hx-5} ${hy} l3 -9 l4 -5 l2 1 l-3 7 l6 -4 l2 1 l-4 7 l-7 5Z`,ink,gold,.65);
    K.circle(c,13,-132,3,gold);K.circle(c,ex,ey,2.6,gold);K.circle(c,-77,-96,2.6,gold);
    K.line(c,[[hx,hy],[104+wave*14,65]],'#291f17',2);K.line(c,[[-65,-65],[-60,65]],'#291f17',2);K.line(c,[[0,-50],[0,91]],'#291f17',3);
    H.stroke(c,'M-22 -121 Q-13 -100 -18 -75 M23 -120 Q14 -99 18 -77','#b3a45f',.8);
    c.save();c.clip(new Path2D('M-16 -137 Q-42 -113 -26 -66 L-50 -11 Q-23 7 27 -5 L22 -65 Q52 -102 15 -135Z'));for(let j=0;j<4;j++){const yy=-110+j*26;H.stroke(c,`M-24 ${yy} q12 -14 24 0 q12 14 24 0 M-25 ${yy+7} q12 -14 24 0 q12 14 24 0`,gold,.65);for(const xx of [-20,20])K.path(c,`M${xx} ${yy-5} l3 -4 l3 4 l-3 4Z`,null,gold,.6);}c.restore();
    H.stroke(c,`M${hx-2} ${hy+1} l4 -10 l3 1 l-2 10 M-65 -65 l5 -8 l3 3 l-4 8`,ink,2);
    H.stroke(c,'M-36 -15 Q-15 -35 23 -17',gold,1.4);
    for(let j=0;j<6;j++){let xx=-27+j*9;K.ellipse(c,xx,-19,3.5,1.7,gold,null,1,-.5);}
    c.restore();
  };
  // Wrist locations were read from the sixteen original cels. Rods are drawn
  // behind the leather: they emerge from the hands without replacing an arm.
  H.puppetJoints={
    wayang_noble:{anchor:[128,362],reference:338,spine:111,hands:[
      [[151,239],[120,240]],[[149,225],[120,241]],[[151,202],[122,243]],[[148,191],[122,242]],
      [[145,182],[122,242]],[[151,166],[122,242]],[[152,153],[122,242]],[[151,148],[122,244]],
      [[153,138],[122,245]],[[153,139],[122,245]],[[152,145],[122,246]],[[151,164],[122,246]],
      [[141,183],[122,246]],[[139,202],[122,246]],[[146,226],[122,249]],[[148,246],[117,251]]
    ]},
    wayang_guard:{anchor:[140,365],reference:348,spine:130,hands:[
      [[89,233],[177,259]],[[91,225],[179,259]],[[94,220],[181,259]],[[106,210],[183,259]],
      [[118,201],[181,259]],[[170,189],[181,259]],[[181,185],[183,259]],[[177,181],[183,259]],
      [[181,176],[182,258]],[[188,176],[184,256]],[[184,187],[184,256]],[[177,200],[183,255]],
      [[161,225],[179,258]],[[164,235],[180,259]],[[104,230],[183,258]],[[100,234],[183,258]]
    ]}
  };
  H.puppetCharacter=(c,id,x,y,height,flip,phase)=>{
    if(!H.characterId(id))return false;
    const spec=H.puppetJoints[id],frame=P.characterFrameIndex(id,0,{phase}),s=height/spec.reference;
    const at=([px,py])=>[x+(px-spec.anchor[0])*s*flip,y+(py-spec.anchor[1])*s];
    const shaft=at([spec.spine,290]),bottom=y+107;
    K.line(c,[shaft,[shaft[0],bottom]],'#2d2118',2.6);
    spec.hands[frame].forEach((joint,j)=>{const wrist=at(joint);K.line(c,[wrist,[wrist[0]+flip*(j?-1:1)*height*.08,bottom-5]],'#302219',1.65);});
    return P.drawCharacter(c,id,0,{x,y,height,flip,frame});
  };
  P.scenes[9]={title:'爪哇皮影戏',en:'WAYANG KULIT',date:'约公元 1800 年',style:9,dark:true,accent:'#f0cb83',
    draw(c,t){c.drawImage(K.cached('h-wayang',g=>{
      H.paper(g,'#8a542c','rgba(74,43,22,.045)',1900);
      const sun=g.createRadialGradient(800,466,26,800,466,709);sun.addColorStop(0,'#ffd992');sun.addColorStop(.39,'#edb05a');sun.addColorStop(.62,'#c7853c');sun.addColorStop(.81,'#87522c');sun.addColorStop(1,'#59321f');K.rect(g,0,0,1600,900,sun);g.save();g.beginPath();g.rect(0,181,1600,585);g.clip();const lamp=g.createRadialGradient(800,466,140,800,466,476);lamp.addColorStop(0,'rgba(255,220,147,.09)');lamp.addColorStop(.87,'rgba(255,220,147,.11)');lamp.addColorStop(.98,'rgba(245,193,104,.12)');lamp.addColorStop(1,'rgba(255,220,147,0)');K.circle(g,800,466,476,lamp);g.restore();
      // Woven screen threads and a carved theatre canopy.
      for(let y=183;y<799;y+=7)K.line(g,[[0,y],[1600,y]],'rgba(72,43,23,.055)',.6);
      K.rect(g,0,0,1600,179,'#41251e');K.rect(g,0,166,1600,15,'#2f211a');for(let x=0;x<1600;x+=65){K.path(g,`M${x} 178 q32 57 64 0Z`,'#5b2e22','#b5aa5d',1);H.flower(g,x+32,174,14,'#c0b16a','#623326',7);}
      K.rect(g,0,766,1600,64,'#48281e');K.rect(g,0,767,1600,8,'#2b2118');for(let x=0;x<1600;x+=40){K.circle(g,x+20,797,7,null,'#ada359',1.5);K.line(g,[[x+5,813],[x+34,813]],'#9c904b',1.2);}
      H.gunungan(g,133,746,1.12);H.gunungan(g,1467,746,1.12,-1);
      K.line(g,[[305,752],[1295,752]],'#5c3b21',2.5);
      for(let j=0;j<34;j++){let x=415+j*23;K.path(g,`M${x} 754 q6 -14 12 0`,'#704923');}
      for(let x=4;x<1600;x+=11)K.line(g,[[x,183],[x,763]],'rgba(73,43,23,.028)',.55);
      for(let j=0;j<26;j++){let x=16+j*62;H.stroke(g,`M${x} 784 q15 -10 29 0 q-14 10 -29 0 M${x+14} 784 v23`,'rgba(199,151,80,.45)',.8);}
      for(let j=0;j<25;j++){let x=j*65+32;for(let k=0;k<7;k++){let a=(k+.5)*Math.PI/7;K.circle(g,x+23*Math.cos(a),180+19*Math.sin(a),1.4,'#b3a45d');}H.stroke(g,`M${x-14} 167 q14 -8 28 0`,'#a09250',.65);}
      for(let j=0;j<26;j++){let x=16+j*62;K.path(g,`M${x+6} 822 l9 -4 l9 4 l-9 4Z`,null,'#ab9a52',.6);}
      K.line(g,[[800,181],[800,239]],'#75502e',1.5);K.path(g,'M780 249 Q800 263 820 249 L815 240 L786 240Z','#62442a','#b78643',1.2);K.line(g,[[791,239],[793,231],[806,231],[809,239]],'#725332',1);
    }),0,0);
      // Lamplight breathes; exposed control rods tell how the performance works.
      const r=H.hero(9,t),qt=Math.floor(t*12)/12,n=H.notice(1244,r,690);
      if(!H.puppetCharacter(c,'wayang_noble',356,741,281,1,K.clamp((qt-.2)/2.6)))H.puppet(c,356,741,1.18,1,.28+.2*Math.sin(qt*2));
      if(!H.puppetCharacter(c,'wayang_guard',1244,741,281,-1,K.clamp((qt-1.2)/2.6)))H.puppet(c,1244,741,1.18,-1,n*(.48+.38*Math.sin(qt*2.8)));
      K.line(c,[[r.x-20*r.scale,r.y-160*r.scale],[r.x-28+Math.sin(qt)*8,799]],'#2d2118',2.8);K.line(c,[[r.x+113*r.scale,r.y-130*r.scale],[r.x+160,799]],'rgba(40,29,20,.89)',2.1);
      let flame=Math.sin(t*9)*2;K.path(c,`M798 240 Q786 228 ${800+flame} 214 Q807 228 803 240Z`,'#edc57f');K.path(c,'M799 239 Q795 231 800 227 Q804 233 802 239Z','#f8ddb0');
      c.globalAlpha=.035+.02*Math.sin(t*7);K.ellipse(c,800,465,380,276,'#ffe9ab');c.globalAlpha=1;
    },pose:t=>basePose(t,9,1.15,752)};

  // Native road geometry is shared with the panorama compositor. The thin
  // approach ramps can therefore join worlds without lifting the wheel rig.
  H.quadY=(x,p0,p1,p2)=>{let lo=0,hi=1;for(let j=0;j<18;j++){const u=(lo+hi)/2,xx=(1-u)*(1-u)*p0[0]+2*(1-u)*u*p1[0]+u*u*p2[0];if(xx<x)lo=u;else hi=u;}const u=(lo+hi)/2;return(1-u)*(1-u)*p0[1]+2*(1-u)*u*p1[1]+u*u*p2[1];};
  H.songRoad=x=>x<477?H.quadY(K.clamp(x,0,1600),[0,787],[324,784],[477,770]):x<1058?H.quadY(x,[477,770],[815,758],[1058,778]):H.quadY(K.clamp(x,0,1600),[1058,778],[1294,798],[1600,783]);
  const roads=[
    [752,'#c49b71','#85543a'],[752,'#ddc395','#846844'],[740,'#2c342a','#adb79d'],[748,'#ede4ce','#77735f'],
    [H.songRoad,'#b6ac8b','#817e62'],[bridgeY,'#c4ab79','#8a704c'],[746,'#dfc99f','#aa5141'],[751,'#d9c29a','#a4865a'],
    [781,'#eeebda','#7b8a6f'],[752,'#af8047','#5c3b21']
  ];
  roads.forEach(([ground,color,ink],i)=>Object.assign(P.scenes[i],{ground:typeof ground==='function'?ground:()=>ground,roadColor:color,roadInk:ink}));

  // R2: small, causally linked performances inside the historical materials.
  // These wrappers add only drawing layers; road geometry and travel remain
  // untouched, so the shared physical wheel/contact solution stays valid.
  const enrich=(i,layer,fn)=>{const old=P.scenes[i][layer];P.scenes[i][layer]=function(c,t,a,r){if(old)old.call(this,c,t,a,r);fn(c,t,a,r);};};
  enrich(1,'draw',(c,t)=>{
    const r=H.hero(1,t),ink='#93623b',blue='#2f7078';
    // A deliberately anachronistic inspection is painted as a real cartouche.
    K.path(c,'M1056 466 H1261 Q1284 466 1284 490 Q1284 520 1261 520 H1056 Q1033 520 1033 493 Q1033 466 1056 466Z','#debf80',blue,1.7);
    K.path(c,'M1057 473 H1259 Q1275 473 1275 491 Q1275 512 1259 512 H1057 Q1042 512 1042 493 Q1042 473 1057 473Z',null,ink,.8);
    K.text(c,'鹈 鹕 测 试',1158,503,27,'#355f67','center','serif');
    const focus=K.ease((t-1.75)/.35)*(1-K.ease((t-3.25)/.35));
    if(focus){
      c.save();c.globalAlpha=focus*.43;c.setLineDash([3,5]);
      const s=r.scale,cy=r.y+25*s;
      for(const xx of [r.x-130*s,r.x+150*s]){K.circle(c,xx,cy,77*s,null,'#ad6546',1.1);K.line(c,[[xx-90*s,cy],[xx+90*s,cy]],'#a55e43',.85);K.line(c,[[xx,cy-104*s],[xx,752]],'#a55e43',.85);}
      c.setLineDash([]);c.restore();
    }
    const approved=K.ease((t-2.5)/.18);
    if(approved){c.save();c.globalAlpha=approved;c.translate(1219,571);c.rotate(-.065);K.rect(c,-27,-27,54,54,null,'#a45436',2.3);K.rect(c,-22,-22,44,44,null,'#a45436',.9);K.text(c,'准',0,14,36,'#a45436','center','serif','700');c.restore();}
    // A measuring cord, knotted every unit, belongs to the artist's kit.
    K.line(c,[[1082,555],[1082,694]],ink,1.1);for(let j=0;j<8;j++)K.circle(c,1082,563+j*16,1.5,ink);
    K.path(c,'M1082 693 l-5 10 l5 9 l5 -9Z','#a77943','#7b6240',.9);
    K.path(c,'M1061 555 h42 M1067 558 h30',null,blue,1.2);
  });
  enrich(2,'draw',(c,t)=>{
    // The stone clerk cuts one small admission seal after carving 借道.
    const ready=K.ease((t-2.5)/.25);if(!ready)return;c.save();c.globalAlpha=ready;
    K.rect(c,1212,616,44,43,null,'#bbc4ad',1.4);K.rect(c,1217,621,34,33,null,'#8a9b82',.7);K.text(c,'通',1234,648,25,'#cbd0b7','center','serif');
    for(let j=0;j<7;j++){const u=K.clamp((t-2.5-j*.018)/.8);if(u>0&&u<1){const x=1253+u*(18+j*3),y=646+u*u*44;c.globalAlpha=(1-u)*.6;K.path(c,`M${x} ${y} l3 -2 l2 4 l-3 2Z`,'#aebca4');}}
    c.restore();
  });
  H.scrollSparrow=(c,x,y,s,wing)=>{c.save();c.translate(x,y);c.scale(s,s);const ink='#746c51';K.path(c,'M-13 1 Q-7 -7 2 -3 Q5 -10 10 -6 L12 -3 L19 -1 L12 1 Q8 8 -3 6 L-16 10Z','#a39d7b',ink,.8);K.path(c,`M-7 0 Q${-11-wing*9} ${-7-wing*16} ${4-wing*5} ${-10-wing*14} Q2 -2 6 2Z`,'#c9bd94',ink,.75);K.circle(c,10,-3,.9,ink);K.path(c,'M-3 6 l-1 4 M4 6 l1 3',null,ink,.6);c.restore();};
  enrich(5,'draw',(c,t)=>{
    // A bicycle bell disturbs two sparrows resting on the far railing. Their
    // wings open only after the same local beat; the boat and bridge stay still.
    for(let j=0;j<2;j++){
      const u=K.clamp((t-2-j*.10)/1.45),xx=1041+j*25+u*(132+j*24),yy=bridgeY(1041+j*25)-45-160*Math.sin(u*Math.PI*.7),wing=u>0&&u<1?.55+.45*Math.sin(u*27+j):.07;
      H.scrollSparrow(c,xx,yy,.68,wing);
    }
  });
  H.inkFish=(c,x,y,angle)=>{c.save();c.translate(x,y);c.rotate(angle);K.path(c,'M-20 0 Q-3 -12 17 -3 L24 0 L17 4 Q-2 12 -20 0Z','#63745d');K.path(c,'M-17 0 L-33 -9 L-28 1 L-33 10Z','rgba(67,90,64,.67)');K.path(c,'M-4 -5 Q-1 -14 6 -12 L7 -6 M-2 5 Q3 14 9 8','rgba(74,91,64,.75)');K.path(c,'M-14 -1 Q0 -7 14 -2',null,'rgba(222,226,203,.38)',1.2);K.ellipse(c,15,-2,4.2,3.9,'#eeedda');K.circle(c,16,-3,1.5,'#324331');H.stroke(c,'M9 -6 Q4 0 10 6','#3c513a',.7);c.restore();};
  const fishState=t=>{const u=(t-3.18)/.70;return{u,x:1032+124*u,y:793-98*Math.sin(Math.PI*u),angle:Math.atan2(-98*Math.PI*Math.cos(Math.PI*u),124)};};
  enrich(8,'draw',(c,t)=>{const f=fishState(t);if(f.u>.5&&f.u<1)H.inkFish(c,f.x,f.y,f.angle);});
  enrich(8,'foreground',(c,t)=>{
    const f=fishState(t);if(f.u>=0&&f.u<=.5)H.inkFish(c,f.x,f.y,f.angle);
    if(t>=3.88){H.ripple(c,1156,793,(t-3.88)/1.35,'#7d9275',49);H.ripple(c,1156,793,(t-4.02)/1.05,'#8b9e7c',29);}
    if(t>=3.18&&t<3.6){const u=(t-3.18)/.42;for(let j=0;j<3;j++)K.ellipse(c,1030-(j+1)*7*u,792-25*Math.sin(u*Math.PI)+j*3,1.3,2.5,'rgba(97,124,95,.55)');}
  });
  enrich(9,'draw',(c,t)=>{
    const qt=Math.floor(t*12)/12,open=K.ease((qt-2.0)/.72),close=K.ease((qt-5.25)/.55),a=(-Math.PI/2)*open*(1-close),px=1280,py=615;
    // The guard visibly works a pierced leather barrier through a bamboo link.
    // It rises before the approaching wheel reaches it, then closes behind.
    const r=H.hero(9,t),n=H.notice(1244,r,690),wave=n*(.48+.38*Math.sin(qt*2.8)),wrist=[1244-(95-wave*20)*1.18,741+(-162-wave*13)*1.18],tip=[px-230*Math.cos(a),py+230*Math.sin(a)];
    K.line(c,[wrist,tip],'#513322',1.4);
    c.save();c.translate(px,py);c.rotate(-a);const shape='M-239 -8 Q-250 0 -239 8 H-5 Q9 8 9 0 Q9 -8 -5 -8Z';let cut='';for(let j=0;j<15;j++){const xx=-227+j*15;cut+=`M${xx-2.4} 0 a2.4 2.4 0 1 0 4.8 0 a2.4 2.4 0 1 0 -4.8 0Z`;}c.fillStyle='#5d2c20';c.fill(new Path2D(shape+cut),'evenodd');H.stroke(c,shape,'#a99855',.9);H.stroke(c,'M-237 -5 H-7 M-237 5 H-7','#bba45d',.6);c.restore();
    K.circle(c,px,py,7,'#6b3d24','#c0ac61',1.1);K.circle(c,px,py,2.5,'#d4bc71');K.line(c,[[px,py+7],[px,762]],'#493020',2.4);
  });
})();
