/* R5 editorial clock, shared physical route, and one continuous rider.
   Old scenes keep a six-second animation parameter, NOT a fixed running time.
   All physics is integrated on the real 186-second clock. */
(()=>{
'use strict';
const D={intro:6,lengths:[5,6,5,7,7,10,5,7,5,7,6,8,6,6,8,9,32,6,9,10],outro:16};
D.starts=[];let at=D.intro;for(const d of D.lengths){D.starts.push(at);at+=d;}D.end=at;D.duration=at+D.outro;
D.widths=D.lengths.map((_,i)=>i===16?2400:1600);D.origins=[0];for(const w of D.widths)D.origins.push(D.origins.at(-1)+w);
D.locate=t=>t<D.intro?-1:t>=D.end?20:D.starts.findIndex((s,i)=>t<s+D.lengths[i]);
D.local=(i,t)=>i<0?K.clamp(t/D.intro*5,0,5):i>=20?K.clamp((t-D.end)/D.outro*12,0,12):K.clamp((t-D.starts[i])/D.lengths[i]*6,0,6);
D.legacy=t=>{const i=D.locate(t);return i<0?t*5/D.intro:i>=20?125+(t-D.end)/D.outro*12:5+i*6+D.local(i,t);};
D.fromLegacy=t=>t<5?t/5*D.intro:t>=125?D.end+(t-125)/12*D.outro:(()=>{const i=Math.min(19,Math.floor((t-5)/6));return D.starts[i]+(t-5-i*6)/6*D.lengths[i];})();
D.hermite=(u,a,b,va,vb,d)=>{u=K.clamp(u);return (2*u*u*u-3*u*u+1)*a+(u*u*u-2*u*u+u)*d*va+(-2*u*u*u+3*u*u)*b+(u*u*u-u*u)*d*vb;};
D.chatState=function(seconds){
 const base=P.castStudy.state(K.clamp(seconds-3,0,26));let x,camera,phase,clip;
 if(seconds<3){const first=P.castStudy.state(0),u=seconds/3;x=D.hermite(u,0,first.x,285,36,3);camera=K.lerp(x-760,0,K.smoother((seconds-1.0)/1.7));phase='enter';clip=null;}
 else if(seconds<=29){x=base.x;camera=base.camera;phase=base.phase;clip=base.gate>.999?{x:1076,y:186,w:1324,h:497}:base.viewport;}
 else{const last=P.castStudy.state(26),u=(seconds-29)/3;x=D.hermite(u,last.x,2400,0,1600/6,3);camera=K.lerp(last.camera,x-760,K.smoother(u));phase='leave';clip={x:1076,y:186,w:1324,h:497};}
 return{...base,x,camera,phase,clip,seconds,study:K.clamp(seconds-3,0,26),scale:base.scale,y:base.y};
};
D.roomIndex=x=>{if(x<0)return-1;for(let i=0;i<20;i++)if(x<D.origins[i+1])return i;return 20;};
D.origin=i=>i<0?-1600:D.origins[i];
D.floorNative=function(i,x,t){if(i===20)return 774;if(i<0){const u=K.clamp((x-1368)/232);return 668+84*K.smoother(u);}if(i===16)return 652;const s=P.scenes[i];return s.ground?s.ground(x,D.local(i,t)):P.nativeGround(i,x,D.local(i,t));};
D.half=k=>k===20?130:k===14?300:k>=15?170:230;
D.floor=function(x,t){const i=D.roomIndex(x);let seamIndex=-1;for(let k=Math.max(0,i);k<=Math.min(20,i+1);k++)if(Math.abs(x-D.origins[k])<D.half(k)){seamIndex=k;break;}
 if(seamIndex>=0){const k=seamIndex,w=D.half(k),seam=D.origins[k],L=seam-w,R=seam+w,ow=k?D.widths[k-1]:1600,yl=D.floorNative(k-1,ow-w,t),yr=D.floorNative(k,w,t),ml=(D.floorNative(k-1,ow-w+2,t)-D.floorNative(k-1,ow-w-2,t))/4,mr=(D.floorNative(k,w+2,t)-D.floorNative(k,w-2,t))/4;return D.hermite((x-L)/(R-L),yl,yr,ml,mr,R-L);}
 return D.floorNative(i,x-D.origin(i),t);
};
D.features=function(i,t){if(i===20)return {scale:.95,elevation:0,gestureTilt:0,gazeX:1};if(i===16){const q=D.chatState(t-D.starts[16]);return{...P.nativePose(i,D.local(i,t),D.legacy(t)),x:q.x,y:q.y,scale:q.scale,elevation:0,gestureTilt:0,gazeX:q.phase==='loop'?.7:1,headNod:q.study>=8.6&&q.study<10?-.10*Math.sin((q.study-8.6)/1.4*Math.PI):0};}
 const l=D.local(i,t),p=P.nativePose(i,l,D.legacy(t)),sup=P.supportPose(p.x,p.scale,x=>D.floorNative(i,x,t));return {...p,elevation:Number.isFinite(p.elevation)?p.elevation:i===15?p.y-sup.y:0,gestureTilt:Number.isFinite(p.gestureTilt)?p.gestureTilt:i===15?(p.tilt||0)-sup.tilt:0};};
// C1 speed blend at every editorial seam; holds and contact beats inside
// the rooms retain their authored timing. The new world path drives wheels too.
D.rawX=function(t){const i=D.locate(t);if(i<0){const l=t/D.intro*5;return D.hermite(K.clamp((l-2.4)/2.6),-452,0,0,1600/6,2.6);}if(i>=20)return D.origins[20];if(i===16)return D.origins[i]+D.chatState(t-D.starts[i]).x;const l=D.local(i,t),s=P.scenes[i];return D.origins[i]+(s.travelX?s.travelX(l):1600*l/6);};
D.smoothX=function(t,x){const w=.40,e=.0001;for(let k=0;k<20;k++){const b=D.starts[k];if(Math.abs(t-b)>=w)continue;const mid=D.origins[k],vl=(mid-D.rawX(b-e))/e,vr=(D.rawX(b+e)-mid)/e,v=(vl+vr)/2;if(t<b){const u=(t-b+w)/w;x+=(v-vl)*w*(u*u*u-u*u);}else{const u=(t-b)/w;x+=(v-vr)*w*(u*u*u-2*u*u+u);}break;}return x;};
D.geometry=function(t){const i=D.locate(t);let worldX,screenX=760,cameraX,f;
 if(i<0){const l=t/D.intro*5,u=K.clamp((l-2.4)/2.6);worldX=D.hermite(u,-452,0,0,1600/6,2.6);screenX=K.lerp(1148,760,K.smoother(u));f=D.features(-1,t);}
 else if(i===20){const p=D.pressPose(t-D.end);return {i,worldX:D.origins[20]+p.x,cameraX:D.origins[20],p};}
 else if(i===16){const q=D.chatState(t-D.starts[i]);worldX=D.origins[i]+q.x;screenX=q.x-q.camera;f=D.features(i,t);}
 else{const l=D.local(i,t),s=P.scenes[i];worldX=D.origins[i]+(s.travelX?s.travelX(l):1600*l/6);f=D.features(i,t);}
 worldX=D.smoothX(t,worldX);
 const room=D.roomIndex(worldX);for(let k=Math.max(0,room);k<=Math.min(20,room+1);k++){const seam=D.origins[k],half=190;if(Math.abs(worldX-seam)<half){const a=D.features(k-1,t),b=D.features(k,t),u=K.smoother((worldX-seam+half)/(2*half));f={...(u<.5?a:b)};for(const key of ['scale','elevation','gestureTilt','headNod','gazeX','gazeY','bellPress','brakeLean'])f[key]=K.lerp(a[key]||0,b[key]||0,u);}}
 cameraX=worldX-screenX;const p=P.supportPose(worldX,f.scale,x=>D.floor(x,t));p.y+=f.elevation||0;p.tilt+=f.gestureTilt||0;Object.assign(p,{x:screenX,expression:f.expression,gazeX:f.gazeX,gazeY:f.gazeY,headNod:f.headNod,bellPress:f.bellPress,brakeLean:f.brakeLean,alpha:1,build:1});return{i,worldX,screenX,cameraX,p};};
D.pressPose=function(u){const x=u<6.6?-360:u<9.6?D.hermite((u-6.6)/3,-360,770,0,0,3):u<11.9?770:D.hermite((u-11.9)/3.8,770,1990,0,330,3.8),scale=.95;return{x,y:774-102*scale,scale,tilt:0,style:18,gazeX:1,headNod:u>9.6&&u<11.9?-.06:0,bellPress:Math.sin(Math.PI*K.clamp((u-10.65)/.22))+Math.sin(Math.PI*K.clamp((u-10.92)/.22))};};
D.sample=function(t){const q=D.geometry(t);if(t>=D.end&&t<D.end+6.6)return{active:false};const p=q.p,r=77*p.scale,co=Math.cos(p.tilt),si=Math.sin(p.tilt),rx=q.worldX+p.scale*(-130*co-25*si),fx=q.worldX+p.scale*(150*co-25*si),floor=x=>t>=D.end?774:D.floor(x,t),slope=x=>K.clamp((floor(x+1)-floor(x-1))/2,-2,2);return{active:true,rx,fx,r,rs:slope(rx),fs:slope(fx),tilt:p.tilt,segment:t>=D.end?'press':q.i===16?'chat':'road'};};
D.prepare=function(){if(D.motion)return;const hz=240,N=Math.ceil(D.duration*hz)+1,rows=[];let rear=0,front=0,dist=0,chatBase=null,prev=D.sample(0);rows.push({rear,front,dist,tilt:0,speed:0});for(let n=1;n<N;n++){const t=n/hz,q=D.sample(t);let dr=0,df=0,dd=0;if(q.active&&prev.active&&(q.segment===prev.segment||(q.segment!=='press'&&prev.segment!=='press'))){const r=(q.r+prev.r)/2;dd=(q.rx-prev.rx)*Math.hypot(1,(q.rs+prev.rs)/2);dr=dd/r;df=(q.fx-prev.fx)*Math.hypot(1,(q.fs+prev.fs)/2)/r;
 // GIF reset is an authored loop, not reverse wheel motion.
 if(q.segment==='chat'&&dd< -5){dr=0;df=0;dd=0;}}
 rear+=dr;front+=df;dist+=dd;
 // The GIF owns a deliberately repeating local clock. Opening the original
 // continues exactly that orientation; subsequent rooms inherit its final phase.
 if(t>=D.starts[16]+3&&t<=D.starts[16]+29){
  const st=D.chatState(t-D.starts[16]);
  if(chatBase===null)chatBase={rear:rear-st.angle,front:front-st.angle};
  rear=chatBase.rear+st.angle;front=chatBase.front+st.angle;
 }
 rows.push({rear,front,dist,tilt:q.tilt||0,speed:dd*hz});prev=q;}D.motion={hz,rows};};
D.motionAt=function(t){D.prepare();const{hz,rows}=D.motion,u=K.clamp(t,0,D.duration-.001)*hz,j=Math.floor(u),a=rows[j],b=rows[j+1]||a,f=u-j,L=k=>K.lerp(a[k],b[k],f),rear=L('rear')-L('tilt'),front=L('front')-L('tilt'),crank=rear/P.drivetrain.ratio;return{wheelAngle:(rear+front)/2,rearWheelAngle:rear,frontWheelAngle:front,crankAngle:crank,phaseTime:crank/(2*Math.PI),travel:L('dist'),speed:L('speed'),wheelSpeed:L('speed')/77,gearRatio:P.drivetrain.ratio};};
D.drawJoin=function(c,k,camera,t){const seam=D.origins[k],w=D.half(k);if(seam+w<camera||seam-w>camera+1600)return;const a=k?P.roadColors[k-1]:['#d6c6a5','#a18c66'],b=k<20?P.roadColors[k]:['#bdc3ad','#9aa58f'];c.save();c.translate(-camera,0);if(k===16){c.beginPath();c.rect(seam-w,-50,w+16,1000);c.clip();}for(let side=0;side<2;side++){const L=side?seam:seam-w,R=side?seam+w:seam,pa=side?b:a,pts=[];for(let x=L;x<=R;x+=5)pts.push([x,D.floor(x,t)]);c.save();c.globalAlpha=.54;K.line(c,pts.concat(pts.slice().reverse().map(([x,y])=>[x,y+7])),null,1,true,pa[0]);K.line(c,pts,pa[1],.8);c.restore();}c.restore();};
D.drawChat=function(c,t,front=false,p){const sec=K.clamp(t-D.starts[16],0,32),q=D.chatState(sec),v=q.viewport;
 if(!front){P.castStudy.paintScene(c,q.study);
  if(sec<3){const door=1-K.smoother((sec-2.55)/.45);c.save();c.globalAlpha=door;K.rect(c,0,614,1076,65,'#e7eee2');K.rect(c,0,652,1076,23,'#c8bb94');K.line(c,[[0,652],[1076,652]],'#7d8d78',1.2);for(let x=24;x<1050;x+=56)K.line(c,[[x,663],[x+24,663]],'#aa9f7f',1);K.text(c,'正在接收一位赶路的朋友…',470,637,17,'#6e8e83','center');c.restore();}
 }else{
  if(sec>=3&&q.gate<.999){K.line(c,[[v.x-1,v.y],[v.x-1,v.y+v.h]],'#9fb8c3',2);K.line(c,[[v.x+v.w+7,v.y],[v.x+v.w+7,v.y+v.h-(v.y+v.h-328)*q.gate]],'#92afbc',5);}
  if(q.study>=22){const camera=q.camera,a=K.ease((q.study-22)/.35);c.save();c.globalAlpha=a;c.beginPath();c.roundRect(camera+953,102,590,106,8);c.fillStyle='#f8fbfd';c.fill();c.strokeStyle='#b4cbd8';c.lineWidth=1;c.stroke();P.castArt.draw(c,camera+971,122,57,'gpt',q.study);K.text(c,'GPT · 复核完成',camera+1042,133,15,'#8175a3');K.text(c,'已复核：现在确实在前进。',camera+1042,161,21,'#344b5a');K.text(c,'这次只说一句。',camera+1042,188,14,'#8798a7');c.restore();}
 }
};
D.roomPass=function(c,i,t,offset,front,p){const width=i<0?1600:i===20?1600:D.widths[i];if(offset>=1600||offset+width<=0)return;const l=D.local(i,t),legacy=i<0?l:5+i*6+l,np={...p,x:p.x-offset};
 c.save();c.beginPath();c.rect(offset,0,width,900);c.clip();c.translate(offset,0);
 P.sceneContext={rider:np,local:l,absolute:legacy,realTime:t,localSeconds:i<0?t:t-D.starts[i],transition:true,...D.motionAt(t)};
 if(i<0){if(!front)P.introRoom(c,l);else P.introFront(c,l);}
 else if(i===20){if(front)P.pressForeground(c,125);else P.pressBackground(c,125);}
 else if(i===16)D.drawChat(c,t,front,np);
 else{const s=P.scenes[i];if(front){if(s.over)s.over(c,l,legacy);if(s.foreground)s.foreground(c,l,legacy,np);if(P.storyDetails)P.storyDetails(c,i,l,t,np,true);}else{s.draw(c,l,legacy);if(P.storyDetails)P.storyDetails(c,i,l,t,np,false);}}
 P.sceneContext=null;c.restore();};
D.renderRoad=function(c,t){const q=D.geometry(t),p={...q.p,...D.motionAt(t)},visible=[];
 for(let i=-1;i<=20;i++){const offset=D.origin(i)-q.cameraX,width=i<0||i===20?1600:D.widths[i];if(offset<1600&&offset+width>0){visible.push([i,offset]);D.roomPass(c,i,t,offset,false,p);}}
 for(let k=0;k<=20;k++)D.drawJoin(c,k,q.cameraX,t);
 for(let k=0;k<=20;k++)if(Math.abs(D.origins[k]-q.cameraX-800)<1100)P.drawScrollPortal(c,k,q.cameraX,t,false);
 for(const[i,offset]of visible){const l=D.local(i,t),s=i>=0&&i<20?P.scenes[i]:null,a=s?P.nativePose(i,l,D.legacy(t)):{};c.save();c.beginPath();c.rect(offset,-50,i===16?2400:1600,1000);c.clip();let clip=i===16?D.chatState(t-D.starts[16]).clip:s?.riderScreenClip?.(l);if(clip){c.beginPath();c.rect(offset+clip.x,clip.y,clip.w,clip.h);c.clip();}
  let dp={...p,style:i<0?3:i>19?18:i,alpha:a.alpha===undefined?1:a.alpha};
  if(i===16){const qs=D.chatState(t-D.starts[16]);dp.style=qs.study<13.8?16:18;dp.bellPress=Math.sin(Math.PI*K.clamp((qs.study-17.6)/.25));}
  else if(s?.riderScreenPose)dp=s.riderScreenPose(dp,l);
  P.drawRider(c,D.legacy(t),dp);c.restore();}
 for(const[i,offset]of visible)D.roomPass(c,i,t,offset,true,p);
 for(let k=0;k<=20;k++)if(Math.abs(D.origins[k]-q.cameraX-800)<1100)P.drawScrollPortal(c,k,q.cameraX,t,true);
 for(const[i,offset]of visible)if(i>=0&&i<20&&i!==16){c.save();c.beginPath();c.rect(offset,0,1600,900);c.clip();c.translate(offset,0);P.chapterLabel(c,i,1,false);c.restore();}
 for(const[i,offset]of visible)if(i===18){const s=P.scenes[18],a=s.portraitFocus(D.local(18,t)),v=s.portraitViewport;if(a>0){const x=offset+v.x;c.save();c.globalAlpha=a;K.rect(c,0,0,Math.max(0,x),900,'#000');K.rect(c,x+v.w,0,Math.max(0,1600-x-v.w),900,'#000');K.rect(c,x,0,v.w,v.y,'#000');K.rect(c,x,v.y+v.h,v.w,900-v.y-v.h,'#000');c.restore();}}
};
D.drawPress=function(c,u){const legacy=125+u*12/16;P.pressBackground(c,legacy);const p={...D.pressPose(u),...D.motionAt(D.end+u)};
 // The cable visibly obstructs the route until the two polite bell taps.
 const pull=K.smoother((u-11.0)/.75),cx=K.lerp(1020,1435,pull),cy=K.lerp(774,790,pull);
 K.path(c,`M1111 584 C1155 619 1010 666 ${cx} ${cy} Q${cx+40} ${cy+10} 1380 786`,null,'#39514e',3);
 if(u>=6.6&&u<15.9){P.drawRider(c,legacy,p);if(P.drawCarriedHeart)P.drawCarriedHeart(c,p);}
 P.pressForeground(c,legacy);
 if(u>=10.55){c.save();c.globalAlpha=K.ease((u-10.55)/.35);K.rect(c,430,322,740,76,'#344d50');K.line(c,[[472,332],[1128,332]],'#779b8e',.8);K.text(c,u<11.8?'（叮，叮。）':'鹈鹕首次回应：借过，谢谢。',800,373,28,'#f0e6c9','center','serif');c.restore();}
 if(u>=11.0){K.rect(c,1170,452,180,55,'#e4e5d6','#91a18e',1);K.circle(c,1186,476,4,'#6f917a');K.text(c,u<11.8?'正在让路':'道路已让开',1201,483,18,'#536b5e','left','serif');}
 if(u>12.5){K.text(c,'END OF TEST. NOT THE JOURNEY.',800,405,11,'#aabbaa','center','mono');}
};
D.thumbs=function(){if(D.pictures)return;D.pictures=[];for(let i=0;i<20;i++){const cv=P.makeCanvas(320,180),c=cv.getContext('2d');c.scale(.2,.2);const tt=D.starts[i]+D.lengths[i]*(i===16?.63:.54);D.renderRoad(c,tt);D.pictures.push(cv);}const cv=P.makeCanvas(1600,900);D.renderRoad(cv.getContext('2d'),D.end-.0001);D.lastPicture=cv;};
D.gallery=function(c,t){D.thumbs();K.grain(c,'#eae4d5','rgba(86,68,43,.035)',1200);K.text(c,'二十种画法，同一位赶路的朋友。',800,85,37,'#3e463c','center','serif','700');K.text(c,'大家准备了很多问题。他只准备了两声车铃。',800,132,21,'#7a7d69','center','serif');K.line(c,[[52,169],[1548,169]],'#bdbea8',1);for(let i=0;i<21;i++){const q=P.overviewCell(i);K.rect(c,q.x-3,q.y-3,q.w+6,q.h+6,'#d5d4be','#8e9a82',1.1);if(i===20){c.save();c.beginPath();c.rect(q.x,q.y,q.w,q.h);c.clip();c.translate(q.x,q.y);c.scale(q.w/1600,q.h/900);D.drawPress(c,t);c.restore();}else c.drawImage(i===19?D.lastPicture:D.pictures[i],q.x,q.y,q.w,q.h);K.text(c,String(i+1).padStart(2,'0'),q.x,q.y+q.h+25,12,'#7d8872','left','mono');K.text(c,i===20?'发布会 · 借过':P.scenes[i].title,q.x+31,q.y+q.h+25,16,'#4e5e4c','left','serif');}K.text(c,'关于六千年的问题，留给人类。下一段路，留给自己。',800,839,22,'#737965','center','serif');};
D.outroDraw=function(c,u){const a=P.overviewCell(19),b=P.overviewCell(20),zoom=1600/a.w;let cx=800,cy=450,z=1;if(u<2.2){const q=K.smoother(u/2.2);cx=K.lerp(a.x+a.w/2,800,q);cy=K.lerp(a.y+a.h/2,450,q);z=Math.exp(K.lerp(Math.log(zoom),0,q));}else if(u>3.6){const q=K.smoother((u-3.6)/3);cx=K.lerp(800,b.x+b.w/2,q);cy=K.lerp(450,b.y+b.h/2,q);z=Math.exp(K.lerp(0,Math.log(zoom),q));}c.save();c.translate(800,450);c.scale(z,z);c.translate(-cx,-cy);D.gallery(c,u);c.restore();};
D.render=function(c,t){t=K.clamp(t,0,D.duration-.00001);P.outputTime=t;const i=D.locate(t);c.save();c.setTransform(c.canvas.width/1600,0,0,c.canvas.height/900,0,0);c.clearRect(0,0,1600,900);c.beginPath();c.rect(0,0,1600,900);c.clip();if(i===20)D.outroDraw(c,t-D.end);else{let v={z:1,fx:800,fy:450,dx:0,dy:0};if(i===4)v=P.storyCamera(D.legacy(t));c.save();c.translate(800+v.dx,450+v.dy);c.scale(v.z,v.z);c.translate(-v.fx,-v.fy);D.renderRoad(c,t);c.restore();}c.restore();};
P.portalContentInset={chat:16};
P.finalDirector=D;P.roomStarts=D.origins;P.version='R5';P.edition='pure-code-R5-complete-story';P.duration=D.duration;P.storyDuration=137;P.journeyEnd=D.end;P.chapterStarts=D.starts;P.timelineSpec={intro:D.intro,chapterSeconds:D.lengths,outro:D.outro};P.chapterAtOutput=D.locate;P.storyTimeAt=D.legacy;P.outputTimeAt=D.fromLegacy;P.storyRateAt=t=>{const i=D.locate(t);return i<0?5/6:i>=20?12/16:6/D.lengths[i];};P.motionAt=t=>D.motionAt(D.fromLegacy(t));P.motionAtOutput=D.motionAt;P.longFloor=D.floor;P.renderAt=D.render;P.invalidateMotion=()=>{D.motion=null;D.pictures=null;};
})();
