/* R5 cast rehearsal. Separate from the 137-second film until the editorial pass. */
(()=>{
 const duration=26, A=P.castArt;
 const messages=[
  {at:.5,id:'fish',text:'骑了这么久，下一站有大白饭吗？',h:96},
  {at:3.5,id:'gpt',text:'先严谨一点：轮子在转，位移却每一轮都归零。',detail:'补充：不等于车坏了。先检查播放循环。',h:123},
  {at:7.8,id:'doubao',text:'我将用最简单最直接最不绕弯子的方式告诉你——',h:112},
  {at:12,id:'claude',text:'先打开原文件。再给它留一条路。',h:102},
  {at:15.8,id:'doubao',text:'……对，点「打开原文件」。我在下一站等你。',h:107},
  {at:19,id:'fish',text:'那我先点两碗大白饭，给它也留一碗。',h:108},
  {at:22,id:'gpt',text:'已复核：现在确实在前进。',detail:'这次只说一句。',h:119}
 ];
 const R=(c,x,y,w,h,r,fill,stroke=null,lw=1)=>{c.beginPath();c.roundRect(x,y,w,h,r);if(fill){c.fillStyle=fill;c.fill();}if(stroke){c.strokeStyle=stroke;c.lineWidth=lw;c.stroke();}};
 const text=(c,s,x,y,size=18,col='#273b43',weight='400',align='left')=>K.text(c,s,x,y,size,col,align,'sans',weight);
 const ease=K.ease;
 function wrap(c,s,width,size){c.font=`${size}px "Noto Sans CJK SC",sans-serif`;let lines=[],line='';for(const ch of s){if(c.measureText(line+ch).width>width&&line){lines.push(line);line=ch;}else line+=ch;}if(line)lines.push(line);return lines;}
 function button(c,x,y,w,h,label,active=false){R(c,x,y,w,h,5,active?'#d7eadd':'#f5fbff',active?'#87ac99':'#91b2c3');text(c,label,x+w/2,y+h*.67,16,active?'#3d6e57':'#356d8e','500','center');}
 function envelope(c,x,y,s,col){c.save();c.translate(x,y);c.scale(s,s);R(c,-11,-8,22,16,4,col);K.path(c,'M-6 8 l-4 4 1 -6Z',col);for(let j=-1;j<=1;j++)K.circle(c,j*5,0,1.1,'#fff');c.restore();}
 function pointer(c,x,y){K.path(c,`M${x} ${y} l2 21 6 -6 5 10 4 -2 -6 -10 8 -2Z`,'#fff','#345368',1.4);}
 function field(c,t){
  K.rect(c,0,0,1600,900,K.gradient(c,[0,0],[0,900],[[0,'#a3c9d9'],[1,'#d4e8e9']]));
  for(let j=0;j<4;j++){K.cloud(c,110+j*480-t*1.2,80+(j%2)*55,2.0,'rgba(255,255,255,.24)');}
  K.path(c,'M0 790 Q250 620 585 740 Q840 630 1170 740 Q1420 700 1600 747 V900 H0Z','#91b4aa');
  K.path(c,'M0 830 Q440 740 780 820 Q1260 710 1600 820 V900 H0Z','#7ea79b');
 }

 const viewport={x:1076,y:186,w:469,h:497};
 const layout=P.mediaViewport.fit(viewport,{scale:.70,ground:652,margin:20});
 const loopPeriod=2.4,loopRange=Math.min(88,layout.xMax-layout.xMin-4),loopSpeed=loopRange/loopPeriod,openAt=13.8;
 const initialX=layout.xMin+2,openDistance=(openAt%loopPeriod)*loopSpeed,coastDuration=.65;
 function state(t){
  t=K.clamp(t,0,duration);const opened=t>=openAt,exit=K.smoother((t-17)/8),gate=opened?K.smoother((t-openAt)/1.0):0;
  let localDistance,x;
  if(!opened){localDistance=(t%loopPeriod)*loopSpeed;x=initialX+localDistance;}
  else{const dt=Math.min(coastDuration,t-openAt),coast=loopSpeed*(dt-dt*dt/(2*coastDuration));localDistance=openDistance+coast+exit*680;x=initialX+localDistance;}
  const angle=localDistance/(77*layout.scale),advance=opened?Math.max(0,x-(initialX+openDistance+loopSpeed*coastDuration*.5)):0;
  const camera=advance>0?advance*advance/(advance+35):0;
  const phase=!opened?'loop':gate<1?'opening':t<17?'ready':'exit';
  return{opened,exit,gate,phase,x,y:layout.y,scale:layout.scale,angle,crank:angle/P.drivetrain.ratio,localDistance,camera,viewport,layout,loop:Math.floor(t/loopPeriod)+1};
 }
 function media(c,t,s){
  const opened=s.opened,v=viewport,right=v.x+v.w,bottom=v.y+v.h;
  // The destination exists beyond the window. Camera tracking reveals it;
  // it is not a second bird pasted over the application chrome.
  if(opened){
   K.path(c,'M1545 652 H2240 V674 H1545Z','#c8bb94');K.line(c,[[1545,652],[2240,652]],'#7d8d78',1.3);
   for(let j=0;j<19;j++)K.line(c,[[1570+j*36,662],[1586+j*36,662]],'#afa282',.9);
   K.path(c,'M1557 651 V484 Q1660 420 1760 494 Q1860 424 1980 496 Q2110 433 2240 487 V652Z','#b2cbb2');
   K.path(c,'M1557 651 V571 Q1690 518 1800 574 Q1920 520 2040 575 Q2140 540 2240 565 V652Z','#99bb9a');
   for(let j=0;j<5;j++){const xx=1609+j*130;K.line(c,[[xx,650],[xx,614]],'#6e947e',1.7);K.path(c,`M${xx} 628 q-17 -25 -22 -10 q-2 12 22 15 q15 -24 26 -11 q-5 17 -26 15Z`,'#81a98a');}
   K.line(c,[[1858,651],[1858,305]],'#658375',5);R(c,1776,295,260,50,8,'#e9f1df','#88a48e');text(c,'下一站  ·  日落之后见  →',1906,327,19,'#4c725d','500','center');
  }
  R(c,1070,142,493,644,8,'#c5d9e1','#7e9fac',1.1);R(c,1064,136,493,644,7,'#f8fcfd','#91aebf',1.1);
  R(c,1065,137,491,40,7,K.gradient(c,[0,137],[0,177],[[0,'#f0faff'],[1,'#c3ddea']]));
  envelope(c,1084,156,.5,'#6998af');text(c,opened?'pelican.html  ·  原文件':'鹈鹕骑行.gif  ·  动态表情',1103,163,16,'#315e75','500');text(c,'—  □  ×',1543,163,16,'#628296','400','right');
  K.rect(c,v.x,v.y,v.w,v.h,'#e7eee2');
  c.save();c.beginPath();c.rect(v.x,v.y,v.w,v.h);c.clip();
  K.rect(c,v.x,v.y,v.w,v.h,K.gradient(c,[0,v.y],[0,bottom],[[0,'#d4e7e8'],[.52,'#ecf0df'],[1,'#d1dfc1']]));
  K.circle(c,1470,250,27,'#f5df9c');
  K.path(c,'M1060 470 Q1160 340 1260 451 Q1350 330 1470 445 Q1540 381 1580 450 V700 H1060Z','#a1bbb0');
  K.path(c,'M1060 500 Q1190 431 1310 500 Q1430 426 1570 512 V700 H1060Z','#c0d0b6');
  K.path(c,'M1060 552 Q1200 478 1320 553 Q1450 496 1590 563 V700 H1060Z','#a8c29b');
  for(let j=0;j<5;j++){const x=1090+j*104;K.line(c,[[x,layout.ground],[x,611]],'#648979',1.6);K.path(c,`M${x} 623 q-18 -26 -21 -3 q5 20 21 14 q20 -22 25 -5 q-1 17 -25 9Z`,'#88ab8b');}
  // Contact is inset from the actual viewport edge, not on the clipped border.
  K.rect(c,v.x,layout.ground,v.w,22,'#c7b98d');K.line(c,[[v.x,layout.ground],[right,layout.ground]],'#788875',1.4);
  for(let j=0;j<12;j++)K.line(c,[[1090+j*43,layout.ground+11],[1105+j*43,layout.ground+11]],'#a29474',1);
  K.rect(c,v.x,674,v.w,9,'#bfcead');
  c.restore();
  if(!opened){R(c,1091,201,143,30,15,'#eef7ee','#b7cbbb',.8);text(c,'循环 '+s.loop+' 次',1162,222,14,'#5e8172','400','center');}
  else text(c,s.gate<.99?'打开出口…':t<17?'出口准备好了':'下一站  →',1305,222,17,'#567567','500','center');
  // A shutter visibly rises before the path is opened. Its exact progress also
  // controls clipping, so the rider cannot escape through still-solid chrome.
  const gateTop=bottom-(bottom-328)*s.gate;
  if(s.gate>0){
   c.save();c.beginPath();c.rect(right,gateTop,18,bottom-gateTop);c.clip();
   K.rect(c,right,gateTop,18,bottom-gateTop,'#b3cbb1');K.rect(c,right,layout.ground,18,22,'#c7b98d');K.line(c,[[right,layout.ground],[right+18,layout.ground]],'#788875',1.4);c.restore();
  }
  c.save();c.beginPath();c.rect(v.x,v.y,v.w,v.h);
  if(s.gate>.999)c.rect(right,328,740,bottom-328);
  c.clip();
  const riderOpts={x:s.x,y:s.y,scale:s.scale,style:opened?18:16,shadow:true,crankAngle:s.crank,wheelAngle:s.angle,rearWheelAngle:s.angle,frontWheelAngle:s.angle,headNod:t>=8.6&&t<10?-.10*Math.sin((t-8.6)/1.4*Math.PI):0,gazeX:opened?1:t>=8.6&&t<10?-.3:.7,gazeY:t>=8.6&&t<10?-.15:0,bellPress:opened&&t>=17.6&&t<17.85?Math.sin((t-17.6)/.25*Math.PI):0};
  if(!P.castStudyOmitRider)P.drawRider(c,t,riderOpts);c.restore();
  // Real foreground rails; the lower wheel never covers buttons or text.
  K.line(c,[[v.x-1,v.y],[v.x-1,bottom]],'#9fb8c3',1.4);K.line(c,[[v.x,v.y],[right,v.y]],'#b9d0d8',1);
  K.line(c,[[right+7,v.y],[right+7,gateTop]],'#92afbc',5);
  if(s.gate>0&&s.gate<.999)R(c,right+1,gateTop-5,13,10,2,'#dae5df','#98b3b8');
  K.line(c,[[v.x,bottom],[right,bottom]],'#cbdcda',1.1);
  K.rect(c,1076,701,469,65,'#f7fbfc');K.line(c,[[1077,700],[1544,700]],'#d3e1e6',1);
  if(!opened){text(c,'已收藏  ·  循环播放',1093,727,16,'#71868e');button(c,1359,713,169,37,t>=12.6?'正在打开…':'打开原文件',false);}
  else{text(c,s.gate<.999?'正在准备出口…':'原文件已打开 ✓',1093,727,16,'#548773','500');button(c,1359,713,169,37,s.gate<.999?'展开出口':'继续骑行 →',s.gate>.999);}
  const label=opened?(s.phase==='exit'?'原文件 · 继续前进':'原文件 · 非循环播放'):'表情预览 · 循环播放';text(c,label,1093,752,13,'#8d9b9f');
  if(t>=12.0&&t<14.5){let u=ease((t-12.1)/.5);pointer(c,K.lerp(1510,1442,u),K.lerp(810,731,u));if(t>12.6&&t<12.85){c.save();c.globalAlpha=1-(t-12.6)/.25;K.circle(c,1444,732,12+(t-12.6)*45,null,'#ddad5e',2);c.restore();}}
  if(t>=12.6&&t<13.8){const progress=K.clamp((t-12.6)/1.2);R(c,1139,364,352,78,7,'#fcfcf5','#a5b8b0');text(c,'正在读取原文件…',1156,393,17,'#526d70');R(c,1156,411,318,8,4,'#e0e9e5');R(c,1156,411,318*progress,8,4,'#81b29a');}
  if(t>=19.5){const a=ease((t-19.5)/.5);c.save();c.globalAlpha=a;R(c,1073,792,482,63,6,'#fff8e7','#d7b87e');A.riceBowl(c,1107,819,.82);text(c,'大肥鱼送出「大白饭」× 2',1140,818,18,'#8b6b43','500');text(c,'一碗给自己，一碗给赶路的鹈鹕。',1140,842,14,'#a08c6c');for(let j=0;j<2;j++){const yy=798+(t*9+j*6)%12;K.path(c,`M${1102+j*9} ${yy} q-3 -5 0 -9`,null,'rgba(171,153,113,.45)',.8);}c.restore();}
 }
 function contacts(c,t){
  K.rect(c,43,89,247,750,'#eaf4f7');text(c,'AI 好友  ·  4 / 4',61,124,17,'#5c7c8d','500');
  const labels=['今天想吃大白饭','先确认，再下结论','能做，也要做好看','最简单，最直接'];
  ['fish','gpt','claude','doubao'].forEach((id,j)=>{const y=151+j*151;
   R(c,53,y-8,226,135,6,j%2?'#e2eff4':'#f4f9fb');
   A.draw(c,67,y,68,id,t);K.circle(c,130,y+63,4.1,'#73b47b','#f4f9fb',1.1);
   text(c,A.cast[id].name,146,y+24,20,'#3b6074','500');text(c,'在线',146,y+49,12,'#93a5a9');text(c,labels[j],68,y+102,15,'#718b98');
  });
  K.line(c,[[61,773],[269,773]],'#ccdee6',1);text(c,'鹈鹕围观群',67,801,15,'#637f8e');text(c,'从岩画上线，一直没舍得下线。',67,823,11,'#90a3aa');
 }

 function conversation(c,t){
  const shaped=messages.map(m=>{const lines=wrap(c,m.text,590,21),bubble=lines.length*30+22+(m.detail?31:0);return{...m,lines,bubble,block:Math.max(m.h,bubble+45)};});
  const shown=shaped.filter(m=>t>=m.at),latest=shown[shown.length-1];let sum=shown.reduce((a,m)=>a+m.block,0),old=shown.slice(0,-1).reduce((a,m)=>a+m.block,0);
  const scroll0=Math.max(0,old-500),scroll1=Math.max(0,sum-500),scroll=K.lerp(scroll0,scroll1,latest?ease((t-latest.at)/.65):0);
  c.save();c.beginPath();c.rect(312,173,727,522);c.clip();let y=185-scroll;
  for(const m of shown){
   const enter=ease((t-m.at)/.24);c.save();c.globalAlpha=enter;
   A.draw(c,329,y+3,47,m.id,t);text(c,A.cast[m.id].name,392,y+17,15,A.cast[m.id].color,'500');text(c,'20:00:'+String(Math.floor(m.at)).padStart(2,'0'),1005,y+17,12,'#a0afb6','400','right');
   R(c,387,y+28,627,m.bubble,6,m.id==='doubao'?'#f7f3ee':'#f7fbfd','#dce8ee',1);K.path(c,`M387 ${y+38} l-7 6 7 6Z`,m.id==='doubao'?'#f7f3ee':'#f7fbfd');
   m.lines.forEach((line,k)=>text(c,line,404,y+55+k*30,21,'#2b414c'));
   if(m.detail){const yy=y+28+m.lines.length*30+6;K.line(c,[[405,yy],[990,yy]],'#e0e9ee',.7);text(c,m.detail,405,yy+23,14,'#7e909c');}
   c.restore();y+=m.block;
  }
  c.restore();
  const track={x:1030,y:181,h:503},thumb=Math.max(82,track.h*Math.min(1,500/Math.max(500,sum))),thumbY=track.y+(track.h-thumb)*K.clamp(scroll/Math.max(1,sum-500));
  K.rect(c,track.x,track.y,4,track.h,'#f1f5f6');R(c,track.x,thumbY,4,thumb,2,'#b8cbd5');
  K.rect(c,309,698,733,128,'#fff');K.line(c,[[309,698],[1042,698]],'#d3e4ec',1);
  text(c,'☺    ▧    ⤴    …',328,732,24,'#7493a3');text(c,'消息记录',1015,729,14,'#6d8b9e','400','right');
  let typing=t>=6.5&&t<7.8?'豆包正在输入…':t>=14.1&&t<15.8?'豆包正在输入…':t>=11.2&&t<12?'Claude 正在打开原文件…':t>=21&&t<22?'GPT 正在复核…':'';
  if(typing)text(c,typing,328,775,18,'#7d95a1');else text(c,'消息会留下，故事继续往前。',328,775,17,'#a3b3bb');
  button(c,916,784,105,32,'发送(S)');text(c,'剧情化群聊 · 非真实聊天记录',329,811,12,'#a4b4bd');
  P.castStudyLastLayout={scroll,contentHeight:sum,thumbY,thumbHeight:thumb,track,messages:shown.map(m=>({id:m.id,lines:m.lines,height:m.block,bubble:m.bubble}))};
 }
 function render(ctx,t){
  t=K.clamp(Number(t)||0,0,duration);const w=ctx.canvas.width,h=ctx.canvas.height;ctx.save();ctx.setTransform(w/1600,0,0,h/900,0,0);P.castClock=t;
  field(ctx,t);const s=state(t);ctx.save();ctx.translate(-s.camera,0);R(ctx,33,35,1540,812,9,'rgba(28,55,67,.18)');R(ctx,25,27,1540,812,8,'#f5fafc','#7da0b5',1.1);
  R(ctx,26,28,1538,51,8,K.gradient(ctx,[0,28],[0,79],[[0,'#f7fcff'],[.5,'#d4e8f3'],[1,'#b8d7ea']]));
  envelope(ctx,52,53,.70,'#68a1be');text(ctx,'叮咚2009',76,61,19,'#315e7e','500');text(ctx,'—    □    ×',1540,61,20,'#6489a1','400','right');
  contacts(ctx,t);K.line(ctx,[[296,83],[296,832]],'#cbdee8',1);
  text(ctx,'鹈鹕围观群（5）',324,116,25,'#2c536c','500');text(ctx,'同一只鹈鹕，四种接话方式。',325,145,15,'#8da3af');
  text(ctx,'···',1021,116,24,'#7593a5','500','right');K.line(ctx,[[309,162],[1041,162]],'#d9e7ee',1);
  conversation(ctx,t);media(ctx,t,s);ctx.restore();
  if(t>=22){const a=K.ease((t-22)/.35);ctx.save();ctx.globalAlpha=a;const yy=102+(1-a)*12;R(ctx,953,yy,590,106,8,'#f8fbfd','#b4cbd8');A.draw(ctx,971,yy+20,57,'gpt',t);text(ctx,'GPT  ·  复核完成',1042,yy+31,15,'#8175a3','500');text(ctx,'已复核：现在确实在前进。',1042,yy+59,21,'#344b5a');text(ctx,'这次只说一句。',1042,yy+86,14,'#8798a7');ctx.restore();}

  K.rect(ctx,0,866,1600,34,K.gradient(ctx,[0,866],[0,900],[[0,'#69acd0'],[.4,'#347eaf'],[1,'#28688f']]));
  R(ctx,0,867,100,33,5,'#6ba477','#447d5d');text(ctx,'开始',50,890,18,'#fff','500','center');
  R(ctx,110,870,225,27,4,'#417fa9','#89b6d1');envelope(ctx,129,883,.45,'#dbeef6');text(ctx,'鹈鹕围观群',149,890,14,'#f0f8fb');
  text(ctx,'20:00',1553,890,15,'#fff','400','right');ctx.restore();
 }
 function portraits(c,t=0){
  const w=c.canvas.width,h=c.canvas.height;c.setTransform(w/1600,0,0,h/900,0,0);K.rect(c,0,0,1600,900,'#e9eee9');
  text(c,'同一个群，不同的性格',63,82,32,'#263c3d','500');text(c,'四位角色的纯代码头像与演出方向',64,117,18,'#7e9291');
  const ids=['fish','gpt','claude','doubao'],sub=['大白饭要热的','先把前提说清楚','问题解决，画面也好看','最直接的答案，最长的开场'];
  ids.forEach((id,j)=>{const x=58+j*386;R(c,x,160,354,611,13,'#f8faf6','#d2dfd7');A.draw(c,x+30,190,294,id,t);text(c,A.cast[id].name,x+28,542,31,'#354d4e','500');text(c,sub[j],x+28,582,18,'#7f9290');
   const tags={fish:['蓝渐变长发 · 鲸耳鳍','女仆头饰 · 白饭碗'],gpt:['银白龙角 · 紫瞳','克制表情 · 检查笔记'],claude:['橙色卷发 · 礼服','从容眼神 · 配色卡'],doubao:['短发 · 小红发卡','红围巾 · 亲切笑意']}[id];tags.forEach((s,k)=>text(c,s,x+28,657+k*34,17,'#607d7d'));
  });
  text(c,'R5 人设样段  /  全部矢量绘制，无生图素材',64,833,16,'#869b96');
 }

 function paintScene(c,t){
  P.castClock=t;field(c,t);const s=state(t);
  K.rect(c,1600,0,800,900,K.gradient(c,[0,0],[0,900],[[0,'#a3c9d9'],[1,'#d4e8e9']]));
  K.path(c,'M1550 651 V484 Q1660 420 1760 494 Q1860 424 1980 496 Q2110 433 2400 487 V900 H1550Z','#b2cbb2');
  K.path(c,'M1550 651 V571 Q1690 518 1800 574 Q1920 520 2040 575 Q2220 530 2400 565 V900 H1550Z','#99bb9a');
  K.rect(c,1550,652,850,22,'#c8bb94');K.line(c,[[1550,652],[2400,652]],'#7d8d78',1.3);
  R(c,33,35,1540,812,9,'rgba(28,55,67,.18)');R(c,25,27,1540,812,8,'#f5fafc','#7da0b5',1.1);
  R(c,26,28,1538,51,8,K.gradient(c,[0,28],[0,79],[[0,'#f7fcff'],[.5,'#d4e8f3'],[1,'#b8d7ea']]));
  envelope(c,52,53,.70,'#68a1be');text(c,'叮咚2009',76,61,19,'#315e7e','500');text(c,'—    □    ×',1540,61,20,'#6489a1','400','right');
  contacts(c,t);K.line(c,[[296,83],[296,832]],'#cbdee8',1);
  text(c,'鹈鹕围观群（5）',324,116,25,'#2c536c','500');text(c,'一只鹈鹕，四种接话方式。',325,145,15,'#8da3af');
  text(c,'···',1021,116,24,'#7593a5','500','right');K.line(c,[[309,162],[1041,162]],'#d9e7ee',1);
  conversation(c,t);P.castStudyOmitRider=true;media(c,t,s);P.castStudyOmitRider=false;
  K.rect(c,0,866,1600,34,K.gradient(c,[0,866],[0,900],[[0,'#69acd0'],[.4,'#347eaf'],[1,'#28688f']]));
  R(c,0,867,100,33,5,'#6ba477','#447d5d');text(c,'开始',50,890,18,'#fff','500','center');
  R(c,110,870,225,27,4,'#417fa9','#89b6d1');envelope(c,129,883,.45,'#dbeef6');text(c,'鹈鹕围观群',149,890,14,'#f0f8fb');text(c,'20:00',1553,890,15,'#fff','400','right');
 }
 P.castStudy={duration,messages,render,paintScene,portraits,state,viewport,layout,loopPeriod,cues:messages.map(m=>({at:m.at,id:m.id})).concat([{at:12.6,id:'click'},{at:13.8,id:'open'},{at:17.6,id:'bell'},{at:17.81,id:'bell'},{at:19.5,id:'rice'}])};
})();
