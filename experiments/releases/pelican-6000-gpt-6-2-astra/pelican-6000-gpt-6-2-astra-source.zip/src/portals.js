/* Material-specific thresholds for the uninterrupted panorama.
   Geometry is decorative: the common longFloor remains the sole contact plane. */
(()=>{
  const Q={};const TAU=Math.PI*2;
  const path=(c,d,f,s,w=1)=>K.path(c,d,f,s,w);
  const line=(c,pts,col,w=1)=>K.line(c,pts,col,w);
  const rect=(c,x,y,w,h,f,s,l=1)=>K.rect(c,x,y,w,h,f,s,l);
  const dot=(c,x,y,r,f,s,l=1)=>K.circle(c,x,y,r,f,s,l);
  Q.shade=(c,x,y,w,h,col='rgba(12,22,19,.20)')=>rect(c,x,y,w,h,K.gradient(c,[x,0],[x+w,0],[[0,col],[1,'rgba(12,22,19,0)']]));
  Q.face=(c,x,y,w,h,base,light,dark,ink)=>{rect(c,x,y,w,h,K.gradient(c,[x,y],[x+w,y],[[0,dark],[.22,base],[.67,light],[1,base]]),ink,1.2);line(c,[[x+5,y+3],[x+5,y+h-3]],light,.9);};
  Q.foot=(c,f,w,col,ink)=>{path(c,`M${-w*.62} ${f-8} H${w*.58} L${w*.72} ${f+15} H${-w*.78}Z`,col,ink,1);};
  Q.flower=(c,x,y,r,col,core)=>{for(let j=0;j<6;j++){let a=j*TAU/6;K.ellipse(c,x+Math.cos(a)*r*.56,y+Math.sin(a)*r*.56,r*.35,r*.17,col,null,1,a);}dot(c,x,y,r*.18,core);};
  Q.lattice=(c,x,y,w,h,col,step=21)=>{c.save();c.beginPath();c.rect(x,y,w,h);c.clip();for(let d=-h;d<w+h;d+=step){line(c,[[x+d,y],[x+d+h,y+h]],col,.85);line(c,[[x+d,y+h],[x+d+h,y]],col,.85);}c.restore();};
  Q.bolt=(c,x,y,col,ink)=>{dot(c,x,y,3.5,col,ink,.75);line(c,[[x-2,y],[x+2,y]],ink,.75);};
  Q.neon=(c,pts,col,width=4)=>{c.save();c.shadowColor=col;c.shadowBlur=12;line(c,pts,col,width);c.shadowBlur=0;line(c,pts,'rgba(246,241,255,.72)',1);c.restore();};
  Q.meander=(c,x,y,n,col,step=27)=>{for(let j=0;j<n;j++)path(c,`M${x} ${y+j*step} h20 v18 h-13 v-10 h6`,null,col,1.25);};
  Q.reed=(c,x,y,s,col)=>{path(c,`M${x} ${y} Q${x-5*s} ${y-70*s} ${x+4*s} ${y-148*s}`,null,col,1.4);for(let j=-2;j<=2;j++)path(c,`M${x+4*s} ${y-146*s} Q${x+j*15*s} ${y-168*s} ${x+j*18*s} ${y-172*s}`,null,col,.9);};
  const names=['砂岩洞口','埃及莲花柱','汉画像石门','唐代格扇','山水卷轴','市井木坊','抄本折脊','白石花拱','竹笔卷边','皮影帘沿','木版浪脊','星夜画架','曲面油画框','胶片银幕边','CRT机壳','像素风铃塔门','聊天窗口边','霓虹拱门','直播竖屏框','编辑器侧框','发布会幕帘'];
  P.scrollPortalMargin=360;
  P.scrollPortalNames=names;
  P.drawScrollPortal=function(c,k,camera,t,front){
    if(k<0||k>20)return;const wx=P.roomStarts?P.roomStarts[k]:k*1600,x=wx-camera;if(x< -P.scrollPortalMargin||x>1680)return;
    const f=typeof P.longFloor==='function'?P.longFloor(wx,t):752;
    c.save();c.translate(x,0);c.lineCap='round';c.lineJoin='round';
    // The messenger is a real content viewport, not a wall for the doorway.
    // Keep its threshold on the outer 16 px edge: the lintel and side rail
    // must never cover the sidebar portraits or readable messages.
    if(k===16){c.beginPath();c.rect(-90,-50,106,1000);c.clip();}
    const top=170,edge='#514b3b';
    switch(k){
      case 0: { // A battered stone lip, with the road passing behind its near face.
        if(!front){path(c,`M-58 -40 L55 -40 L49 83 L83 145 L191 157 L249 198 L231 227 L129 207 L68 214 L51 ${f+16} L-59 ${f+28}Z`,'#af825b','#77543b',1.4);path(c,`M48 133 L192 157 L249 198 L231 227 L152 199 L70 202Z`,'#c09a6e');Q.shade(c,47,207,41,f-198);}
        else{path(c,`M-47 -30 L28 -30 L36 97 L24 181 L46 266 L32 383 L40 493 L29 608 L43 ${f-25} L28 ${f+18} L-52 ${f+20} L-42 582 L-52 444 L-42 307 L-53 174Z`,K.gradient(c,[-45,0],[47,0],[[0,'#9a6a49'],[.45,'#c19a6d'],[1,'#a97b53']]),'#805b3d',1.2);path(c,'M-27 91 l18 43 l-8 36 l15 32 M29 290 l-19 39 l9 61 M-37 510 l24 -23 l21 12',null,'rgba(105,71,45,.55)',1.3);for(const yy of [232,429,637])path(c,`M-44 ${yy} q30 -12 78 -2`,null,'rgba(221,182,129,.42)',1.6);Q.foot(c,f,74,'#ac8157','#805c3d');}
        break;}
      case 1: { // Lotus capital, painted shaft and a projecting lintel.
        if(!front){rect(c,-50,0,100,181,'#d5b779','#927143',1);path(c,'M-65 162 H224 L249 195 H-65Z','#b17b45','#785e3e',1.2);rect(c,-59,180,301,17,'#286f78','#856340',1);for(let j=0;j<11;j++){rect(c,-52+j*26,181,11,13,j%2?'#d9b15f':'#ae5736');}Q.face(c,230,197,20,f-197,'#d2b77c','#e3cc91','#b49056','#8c6d42');Q.shade(c,32,255,35,f-247);}
        else{Q.face(c,-32,0,64,f+5,'#cbb076','#e3ca8c','#ad8953','#82643f');for(let j=-2;j<=2;j++)line(c,[[j*10,282],[j*10,f-22]],'rgba(52,117,116,.65)',1.4);path(c,'M-47 214 Q-45 258 -29 274 H29 Q45 258 47 214Z','#3b7d7f','#765b3c',1.1);for(let j=-3;j<=3;j++){path(c,`M${j*11} 230 q-13 -21 0 -43 q13 22 0 43Z`,j%2?'#cc9a51':'#649b8d','#85643d',.7);}rect(c,-34,277,68,19,'#39777a','#957442',.8);for(let j=-2;j<=2;j++)path(c,`M${j*12} 281 l4 5 l-4 5 l-4 -5Z`,'#ddb25c');Q.foot(c,f,67,'#a96d40','#765a38');}
        break;}
      case 2: { // Broken stone rubbing stele; pale incisions, dark chipped edge.
        if(!front){path(c,`M-58 -20 H57 V160 L94 174 H233 L252 214 H62 V${f+19} H-58Z`,'#28332b','#a5b29a',1.2);path(c,'M53 166 H228 L246 199 H66Z','#354034','#a5b29a',1);for(let j=0;j<7;j++)path(c,`M${66+j*25} 178 h17 v12 h-10 v-6`,null,'#b3bda4',1);Q.shade(c,37,220,27,f-215,'rgba(8,15,10,.35)');}
        else{path(c,`M-39 -30 H34 L29 113 L42 140 L32 182 L40 311 L28 351 L37 503 L30 538 L38 ${f+22} H-42 L-34 612 L-41 436 L-33 402 L-42 265 L-34 223Z`,'#202b23','#b4c0a7',1.5);line(c,[[-27,15],[-27,f-13]],'#778e75',.9);Q.meander(c,-16,214,Math.floor((f-224)/29),'#c1c6ad',29);path(c,'M-36 162 l28 7 l-5 15 l17 7 M26 502 l-24 19 l5 21',null,'#0f1912',4);path(c,'M-34 162 l28 7 l-5 15 l17 7 M28 502 l-24 19 l5 21',null,'#7e927a',.8);Q.foot(c,f,73,'#2c382d','#9bab91');}
        break;}
      case 3: { // An open folding lattice screen, rather than an enclosing arch.
        if(!front){Q.face(c,-45,0,72,f+19,'#b9ac87','#d7cbae','#958b6d','#6c6b55');path(c,`M28 154 L230 193 L230 ${f-24} L28 ${f-5}Z`,'rgba(230,222,199,.88)','#8b8970',1.4);path(c,`M43 179 L211 210 L211 ${f-46} L43 ${f-31}Z`,null,'#aaa187',1);c.save();path(c,`M44 179 L211 211 L211 ${f-46} L44 ${f-31}Z`);c.clip(new Path2D(`M44 179 L211 211 L211 ${f-46} L44 ${f-31}Z`));Q.lattice(c,38,185,183,f-216,'rgba(114,119,95,.42)',27);c.restore();for(let y=240;y<f-35;y+=96)line(c,[[42,y],[213,y+10]],'#b4ad91',1.2);Q.shade(c,27,173,21,f-170);}
        else{Q.face(c,-29,0,55,f+12,'#c2b897','#e4dbc2','#a49d7e','#797963');rect(c,-35,166,68,13,'#b0a789','#7d7b64',.9);rect(c,-35,f-11,69,20,'#b4aa8a','#7d7b64',.9);for(const y of [232,474,664]){rect(c,18,y,17,18,'#b6a882','#79715a',.8);dot(c,27,y+9,2,'#77694c');}path(c,'M-13 214 v229 M-8 478 v160',null,'rgba(248,244,223,.62)',.9);}
        break;}
      case 4: { // A hanging scroll roller; curled silk hides the painted boundary.
        if(!front){path(c,`M-54 -30 H36 V142 Q114 157 221 143 L233 175 Q132 197 35 177 V${f+12} H-54Z`,'#c9c8ae','#7f8a70',1);path(c,`M29 176 Q71 220 60 300 Q29 339 58 400 Q76 445 44 519 Q24 574 45 ${f+10} L3 ${f+13} V176Z`,K.gradient(c,[7,0],[65,0],[[0,'#d0d5ba'],[.55,'#ececda'],[1,'#bbc7ad']]),'#8b9a7e',.75);Q.shade(c,45,189,29,f-180,'rgba(37,65,47,.14)');}
        else{Q.face(c,-23,-25,44,f+66,'#978965','#c0b28c','#6d7053','#5b674e');for(let j=0;j<4;j++)line(c,[[-16+j*8,0],[-16+j*8,f+42]],'rgba(226,216,177,.23)',.6);for(const y of [158,f+18]){K.ellipse(c,0,y,32,9,'#718168','#4a614a',1);rect(c,-25,y-5,50,14,'#a59c76','#63785a',1);K.ellipse(c,0,y+9,25,7,'#85926b','#586e51',1);}path(c,'M9 215 q-13 54 -4 109 q-11 65 -4 97',null,'rgba(57,77,54,.27)',1.2);}
        break;}
      case 5: { // Street gateway with curved timber eave, shop flag and open span.
        if(!front){Q.face(c,-47,0,82,f+15,'#ae976a','#d3c395','#8a7854','#786343');path(c,'M-83 189 Q-17 178 1 142 H169 Q195 179 253 188 L236 204 H-64Z','#8e9d7c','#6d775b',1.3);for(let j=0;j<15;j++){let xx=-47+j*18;line(c,[[xx*.65+19,154],[xx,195]],'#b5bea0',.8);}rect(c,-49,207,285,19,'#a58b5b','#776345',1.3);Q.face(c,224,220,17,f-219,'#ad9569','#c7b78c','#907b58','#786a4d');line(c,[[181,225],[181,290]],'#806f50',1.3);path(c,'M159 251 H205 V318 L181 307 L159 318Z','#d9c294','#9b8358',1);K.text(c,'市',181,290,24,'#8b704b','center','serif');}
        else{Q.face(c,-27,0,53,f+12,'#aa9264','#c8b58a','#887551','#756245');for(const y of [216,253,f-25]){rect(c,-36,y,72,11,'#a68b58','#77623e',1);Q.bolt(c,-15,y+5,'#c8ac71','#79623e');Q.bolt(c,15,y+5,'#c8ac71','#79623e');}path(c,'M-12 301 q5 63 -2 104 M7 435 q-8 75 1 147',null,'rgba(87,66,40,.25)',1.1);Q.foot(c,f,65,'#b2a67b','#86724d');}
        break;}
      case 6: { // The accordion codex has a fold valley and two painted facets.
        if(!front){path(c,`M-57 -30 H38 L33 165 L125 188 L230 164 L236 209 L129 237 L35 211 V${f+23} H-57Z`,'#b64530','#713e2c',1.4);path(c,'M33 165 L125 188 L230 164 L231 187 L127 214 L35 190Z','#e2c38b','#b14d33',1);for(let j=0;j<8;j++){const xx=42+j*24;dot(c,xx,196+Math.sin(j/7*Math.PI)*15,2.4,'#493a28');}Q.shade(c,36,213,26,f-205,'rgba(79,50,23,.18)');}
        else{path(c,`M-43 -30 H3 L21 25 L8 113 L25 190 L8 271 L25 358 L8 442 L25 528 L8 615 L25 ${f-15} L8 ${f+22} H-43Z`,'#e4cda0','#a74d34',1.2);path(c,`M8 -30 H32 V${f+24} H8 L25 ${f-15} L8 615 L25 528 L8 442 L25 358 L8 271 L25 190 L8 113 L21 25Z`,'#c5a671','#7b5335',.9);line(c,[[-35,0],[-35,f+15]],'#bb3e29',5);for(let y=234;y<f-18;y+=66){path(c,`M-23 ${y} h22 v27 h-22Z`,null,'#a8462e',1.2);K.ellipse(c,-12,y+10,6,5,'#347c6b','#5a4932',.7);line(c,[[-19,y+21],[-6,y+21]],'#513e2c',2);}}
        break;}
      case 7: { // Marble jamb and a cusped, jewel-toned garden arch.
        if(!front){rect(c,-49,0,85,170,'#cbb682','#896b3d',1);path(c,`M-52 ${f+12} V215 Q-52 185 -20 184 H18 Q40 117 79 135 Q113 102 147 135 Q187 117 205 184 H242 V${f+12} H221 V220 Q194 217 191 196 Q171 201 159 178 Q141 185 132 162 Q113 181 97 162 Q83 185 64 178 Q53 202 31 196 Q25 217 1 220 V${f+12}Z`,'#e5d1a6','#a1844e',1.3);path(c,'M4 189 Q34 149 63 157 Q93 121 118 145 Q152 121 175 158 Q201 152 224 189',null,'#2d6774',5);Q.shade(c,30,224,33,f-215);}
        else{Q.face(c,-31,0,62,f+12,'#ddc69a','#f1e0ba','#bea374','#927347');rect(c,-20,220,40,f-260,'#254e61','#c4a15a',.8);for(let y=241;y<f-38;y+=47){Q.flower(c,0,y,8.7,'#d4ab5c','#b85949');path(c,`M0 ${y+9} v24 M0 ${y+20} q-10 -10 -14 -4 M0 ${y+16} q10 -10 14 -4`,null,'#80a089',.9);}rect(c,-39,194,78,23,'#e9d4a8','#a0834a',1);Q.foot(c,f,77,'#d9bf8c','#957442');}
        break;}
      case 8: { // Bamboo and a brush-painted paper curl: a spare threshold.
        if(!front){path(c,`M-50 -30 H29 V161 Q106 182 225 157 L232 177 Q110 212 31 183 V${f+14} H-50Z`,'#e5e5cf','#8b967c',.8);path(c,`M23 176 Q69 215 46 292 Q20 334 43 388 Q68 439 43 504 Q28 569 43 ${f+18} H6 V176Z`,'#eeecd9','#8b9b7e',.8);Q.shade(c,41,200,20,f-191,'rgba(38,65,41,.12)');path(c,'M60 193 Q109 176 162 185 M80 186 q-10 25 -31 30 M117 182 q12 19 28 20',null,'#52674e',2.2);}
        else{Q.face(c,-18,-25,36,f+48,'#7e8a67','#a8b28a','#566a4e','#50624a');for(let y=87;y<f+30;y+=117){K.ellipse(c,0,y,22,5,'#53694d');line(c,[[-16,y+5],[16,y+5]],'#c4caae',1);}path(c,'M3 218 Q-37 196 -47 175 Q-14 180 3 218 M-1 345 Q38 315 50 281 Q12 301 -1 345Z','#52674b');line(c,[[-8,12],[-8,f+34]],'rgba(219,225,196,.38)',.7);}
        break;}
      case 9: { // Folded theatre cloth, scalloped fringe and a narrow near curtain.
        if(!front){rect(c,-51,0,90,191,'#4f3423','#2d241b',1);path(c,'M-65 166 H248 V199 Q217 239 187 199 Q155 239 124 199 Q93 238 61 199 Q29 238 -3 199 Q-34 237 -65 199Z','#674127','#bc8a48',1.2);for(let j=0;j<5;j++){Q.flower(c,-32+j*63,188,12,'#d2a35e','#744729');}Q.face(c,235,201,20,f-193,'#81532e','#a0713e','#57391f','#3b2b1d');Q.shade(c,34,216,37,f-200,'rgba(30,16,8,.31)');}
        else{path(c,`M-49 -30 H36 Q30 211 32 291 Q21 381 3 ${f-206} Q13 ${f-127} 46 ${f+15} H-56 Q-41 ${f-102} -29 ${f-210} Q-50 359 -49 -30Z`,K.gradient(c,[-50,0],[42,0],[[0,'#412b1e'],[.26,'#7b4a29'],[.52,'#9b6234'],[.79,'#643c25'],[1,'#38281d']]),'#2e251b',1.2);for(const dx of [-28,-10,10,24])path(c,`M${dx} 0 Q${dx-6} 309 -8 ${f-208} Q${dx+3} ${f-106} ${dx+10} ${f+7}`,null,'rgba(226,175,96,.34)',.9);path(c,`M-30 ${f-211} Q-3 ${f-196} 22 ${f-211}`,null,'#d0a25c',5);line(c,[[20,f-207],[39,f-149]],'#c89c54',2);for(let j=0;j<5;j++)line(c,[[35+j*2,f-151],[34+j*3,f-134]],'#c89c54',1.2);}
        break;}
      case 10: { // The carved edge of a printing block carries the wave's white crest.
        if(!front){Q.face(c,-52,0,91,f+15,'#956e45','#bc9865','#775333','#6b4e35');path(c,'M-54 164 H236 L254 192 H-54Z','#325e75','#244357',1.2);for(let j=0;j<7;j++)path(c,`M${-30+j*39} 184 q8 -21 26 -17 q-13 4 -14 15 l8 -4 q-3 15 -20 6Z`,'#e4e3cc','#6b897d',.6);Q.shade(c,38,198,28,f-184);}
        else{Q.face(c,-32,0,64,f+24,'#9d794e','#c5a477','#785436','#674b32');path(c,`M-20 195 H22 V${f-15} H-20Z`,'#3b6f81','#c5b998',.8);for(let j=0;j<5;j++){const yy=231+j*100;path(c,`M-19 ${yy+46} Q-5 ${yy+13} 19 ${yy+19} Q31 ${yy+31} 12 ${yy+44} Q22 ${yy+18} 3 ${yy+31} L10 ${yy+32} Q-2 ${yy+51} -19 ${yy+46}Z`,'#dce1c9','#8caa99',.7);path(c,`M-15 ${yy+61} q16 -13 33 -5`,null,'#a2c2bc',1);}Q.foot(c,f,76,'#a17e52','#695038');}
        break;}
      case 11: { // A paint-stained wooden stretcher and a cobalt, gilded canvas lip.
        if(!front){Q.face(c,-49,0,87,f+17,'#8a7a4b','#c0a66b','#5b603e','#4a523a');path(c,'M-54 151 H244 V195 H-54Z','#193a58','#b3a063',1.2);path(c,'M-38 161 H231 V183 H-38Z',null,'#c8b56b',2);for(let j=0;j<5;j++){let xx=19+j*43;K.star(c,xx,173,5.5,'#d9cc84',j*.2);}Q.shade(c,36,199,33,f-192,'rgba(8,25,40,.28)');}
        else{Q.face(c,-29,0,58,f+29,'#1d3d5e','#315771','#102d49','#c2af6c');for(let y=209;y<f-20;y+=70){path(c,`M-13 ${y} q37 -28 32 5 q-4 17 -23 10 q-13 -8 -1 -16`,null,'#839f9a',1.4);path(c,`M-11 ${y+2} q25 -19 26 0`,null,'#dbcd8c',.8);}line(c,[[-21,4],[-21,f+19]],'#cfbc72',1.6);line(c,[[21,4],[21,f+19]],'#acaa79',1.2);Q.foot(c,f,71,'#6d754b','#354c3f');}
        break;}
      case 12: { // A deliberately bent expressionist frame with visible paint ridges.
        if(!front){path(c,`M-53 -30 H43 Q31 71 47 153 Q139 121 247 172 L233 216 Q126 165 37 201 Q54 344 36 ${f+22} H-52Z`,'#a85d36','#553e2c',1.3);path(c,'M37 169 Q141 142 236 191',null,'#d59a52',8);path(c,'M41 183 Q145 155 233 204',null,'#81472d',3);Q.shade(c,32,215,31,f-206,'rgba(72,39,24,.23)');}
        else{path(c,`M-34 -30 H31 Q10 117 29 242 Q40 372 18 482 Q7 606 34 ${f+22} H-37 Q-18 587 -32 461 Q-47 330 -26 205 Q-12 80 -34 -30Z`,K.gradient(c,[-38,0],[34,0],[[0,'#85432d'],[.3,'#bf7944'],[.58,'#dc9b57'],[1,'#965135']]),'#6a422d',1.1);path(c,`M-16 -10 Q5 130 -11 249 Q-20 365 -5 486 Q5 611 -11 ${f+9}`,null,'#e4af63',3.2);path(c,`M18 -10 Q-2 150 13 258 Q21 364 8 482 Q-3 596 18 ${f+6}`,null,'#89452e',2.1);for(let j=0;j<7;j++)path(c,`M-25 ${213+j*71} q21 13 49 0`,null,'rgba(224,167,93,.36)',1.6);}
        break;}
      case 13: { // Celluloid perforations and a silver cinema screen corner.
        if(!front){rect(c,-53,0,91,f+28,'#2d3433','#0c1213',1.2);path(c,`M-52 160 H252 V202 H38 V${f+16} H-52Z`,'#7e8880','#222c2b',1.4);path(c,'M45 180 H235 V213',null,'#c0c8b9',2.1);for(let j=0;j<7;j++)rect(c,55+j*25,169,13,9,'#242e2b','#98a18e',.6);Q.shade(c,37,206,31,f-192,'rgba(1,9,11,.32)');}
        else{Q.face(c,-32,0,64,f+32,'#28302f','#48514c','#121c1b','#101918');rect(c,-18,0,36,f+30,'#0d1818','#88938a',.7);for(let y=11;y<f+25;y+=37){rect(c,-28,y,7,16,'#bbc4b1','#222c27',.6);rect(c,21,y,7,16,'#bbc4b1','#222c27',.6);line(c,[[-17,y+22],[17,y+22]],'#526459',.7);}path(c,'M-11 213 h23 v73 h-23Z',null,'#526457',.9);K.text(c,'24',0,258,14,'#839789','center','mono');}
        break;}
      case 14: { // A thick CRT shell; knobs and vent slots belong to its near side.
        if(!front){Q.face(c,-61,0,112,f+28,'#687b71','#a0ad9b','#374d46','#233c34');path(c,`M-58 139 Q-58 122 -35 122 H234 Q260 122 264 147 V195 H56 V${f+24} H-58Z`,'#7a8b7e','#243e36',1.4);path(c,'M63 167 H241 V199',null,'#132f28',9);line(c,[[65,156],[241,156]],'#b1bca5',1);for(let j=0;j<10;j++)rect(c,65+j*15,135,8,3,'#42594e');Q.shade(c,48,203,37,f-190,'rgba(1,20,15,.36)');}
        else{Q.face(c,-42,0,84,f+29,'#687c6e','#a0ad96','#38564a','#284135');rect(c,-30,201,59,f-241,'#657a69','#b5bfa6',.7);for(let j=0;j<9;j++)line(c,[[-18,222+j*7],[18,222+j*7]],'#344f42',2);for(const yy of [f-223,f-117]){dot(c,0,yy,20,'#b3b9a3','#334e41',1.4);dot(c,0,yy,15,'#788d77','#465e4e',.9);line(c,[[0,yy],[7,yy-10]],'#e3e5cd',2.2);for(let j=0;j<9;j++){const a=(j/8)*Math.PI*1.5+Math.PI*.75;line(c,[[Math.cos(a)*24,yy+Math.sin(a)*24],[Math.cos(a)*27,yy+Math.sin(a)*27]],'#345243',.8);}}for(const yy of [184,f+9])Q.bolt(c,0,yy,'#bdc4ad','#46604d');rect(c,-26,f-58,52,13,'#183d2c','#9eaf8f',.8);dot(c,16,f-52,2.8,'#8fd39a');}
        break;}
      case 15: { // Original copper-chime relay tower, with a pixel grid silhouette.
        if(!front){
          rect(c,-49,-20,88,f+46,'#283e55','#112b41',2);
          for(let row=0;row<Math.ceil((f+42)/36);row++){const yy=row*36;rect(c,-45,yy,80,4,'#4a6671');rect(c,-42,yy+8,6,19,'#719293');}
          rect(c,-42,145,290,18,'#4ca2a1','#163b50',3);rect(c,-42,145,290,5,'#9fddd2');
          for(let j=0;j<5;j++){const xx=55+j*39,yy=185+(j%2)*19;rect(c,xx,161,4,yy-161,'#e1bb76');rect(c,xx-9,yy,22,25,'#c58c55','#644c3c',2);rect(c,xx-14,yy+23,32,7,'#e8c37e','#644c3c',2);rect(c,xx-4,yy+30,13,6,'#9c6843');}
          Q.shade(c,39,232,28,f-225,'rgba(15,41,54,.26)');
        }else{
          rect(c,-31,-20,62,f+43,'#355e70','#142e45',3);rect(c,-22,-20,9,f+43,'#78aeae');rect(c,20,-20,7,f+43,'#213e57');
          for(let y=30;y<f-20;y+=74){rect(c,-18,y,35,37,'#234455','#102b43',2);path(c,`M0 ${y+5} l11 13 l-11 13 l-11 -13Z`,'#69c1bb','#b8e4c6',2);}
          rect(c,-43,f-24,86,18,'#5f9b9f','#153a50',2);rect(c,-50,f-5,100,25,'#345468','#17364b',2);rect(c,-38,f,76,5,'#b7d2be');
        }
        break;}
      case 16: { // A familiar desktop messenger window in solid, layered chrome.
        if(!front){Q.face(c,-51,0,91,f+28,'#b7c6bf','#e1e8dd','#9bafa7','#768e84');rect(c,-50,143,307,59,'#dce6dd','#8ca49a',1);rect(c,43,158,198,28,'#f1f4e9','#c0cfc3',.8);dot(c,62,173,5,'#86aa94');path(c,'M67 178 l5 5',null,'#86aa94',1.3);for(let j=0;j<3;j++)dot(c,181+j*20,173,3,['#9aaea0','#8da897','#64a785'][j]);Q.shade(c,38,208,30,f-197,'rgba(41,79,60,.20)');}
        else{Q.face(c,-32,0,64,f+28,'#b9ccc0','#d9e4d7','#96b19f','#799684');rect(c,-25,210,50,f-245,'#c8d9cb','#a7bdac',.7);for(let j=0;j<5;j++){const yy=244+j*84;path(c,`M-17 ${yy} h31 q6 0 6 6 v19 q0 6 -6 6 h-18 l-8 7 v-7 h-5Z`,j%2?'#93bd8b':'#e8eee1','#a1baa2',.6);for(let k=0;k<3;k++)dot(c,-8+k*8,yy+15,1.5,'#7a9e7d');}dot(c,0,174,13,'#3c9e66');K.ellipse(c,-3,172,8,6,'#eef3df');path(c,'M-6 176 l-4 4 l1 -7Z','#eef3df');}
        break;}
      case 17: { // One asymmetric neon arch with a deep violet structural spine.
        if(!front){rect(c,-54,0,90,f+32,'#201b3c','#6f4684',1);path(c,`M-53 ${f+22} V191 L79 117 L257 176 V218 L87 164 L-14 217 V${f+22}Z`,'#32244a','#89529a',1.3);Q.neon(c,[[-29,f+13],[-29,201],[83,139],[240,191]],'#bd68c6',4);Q.neon(c,[[-18,f+13],[-18,210],[85,152],[235,202]],'#75c9c5',2.7);Q.shade(c,35,224,36,f-210,'rgba(19,7,36,.35)');}
        else{Q.face(c,-31,0,62,f+31,'#342748','#49315f','#211d37','#9e63b2');Q.neon(c,[[-20,0],[-20,f+17]],'#db80cc',3.4);Q.neon(c,[[22,0],[22,f+17]],'#83c8d2',2);for(let j=0;j<6;j++)path(c,`M-10 ${240+j*78} l19 -10 v25 l-19 10Z`,'#4b3766','#876599',.65);path(c,`M-42 ${f-2} H40 L55 ${f+25} H-55Z`,'#352947','#a870bc',1.2);}
        break;}
      case 18: { // The physical lip of a portrait live-stream screen.
        if(!front){Q.face(c,-53,0,95,f+31,'#242c36','#4a5260','#111c28','#08131d');path(c,`M-51 17 Q-51 0 -25 0 H226 Q259 0 259 22 V46 H40 V${f+26} H-51Z`,'#252d39','#0a1621',1.5);rect(c,48,7,194,30,'#172733','#425563',.8);dot(c,65,22,5,'#dc7185');K.text(c,'LIVE',81,29,15,'#e7a0b0','left','mono');for(let j=0;j<3;j++)rect(c,176+j*16,14,8,16,'#5e8494');Q.shade(c,42,202,32,f-188,'rgba(4,11,22,.38)');}
        else{Q.face(c,-34,0,68,f+31,'#273440','#475867','#101f2c','#071823');line(c,[[-26,0],[-26,f+20]],'#5b7f8e',1.2);for(let j=0;j<4;j++){const yy=292+j*96;dot(c,0,yy,15,'#3a4f5d','#6c8795',.7);if(j%2===0)path(c,`M0 ${yy+7} Q-15 ${yy-1} -9 ${yy-7} Q-3 ${yy-12} 0 ${yy-5} Q4 ${yy-12} 10 ${yy-7} Q16 ${yy-1} 0 ${yy+7}Z`,'#d5859a');else{path(c,`M-8 ${yy-7} h17 v13 h-6 l-6 5 v-5 h-5Z`,null,'#c5dbdc',1.4);}}rect(c,-22,f-44,44,8,'#152832','#5e7d89',.7);}
        break;}
      case 19: { // Editor chrome and a visibly bracket-shaped inner edge.
        if(!front){Q.face(c,-53,0,94,f+28,'#233b47','#3f5863','#122b37','#102530');rect(c,-52,144,310,58,'#253d49','#0b2531',1.2);rect(c,47,153,142,39,'#1b3441','#3c5661',.7);K.text(c,'road.js',64,178,16,'#b8c9c3','left','mono');dot(c,174,172,3,'#77a28b');for(let j=0;j<3;j++)dot(c,205+j*15,172,3,['#bd7e7d','#c2b071','#73a691'][j]);Q.shade(c,40,209,32,f-193,'rgba(4,24,36,.34)');}
        else{Q.face(c,-35,0,70,f+30,'#213b49','#315260','#122d3b','#0c2734');rect(c,-29,209,58,f-243,'#193442','#47636a',.7);path(c,`M19 241 H-7 V${f-72} H19`,null,'#6596ab',5);for(let j=0;j<9;j++){const yy=267+j*42;line(c,[[-22,yy],[-14,yy]],j%3?'#527786':'#d3bd79',1.5);if(j%3===0)dot(c,22,yy,3,'#ae787c');}path(c,`M6 304 l-9 11 l9 11 M10 304 l9 11 l-9 11`,null,'#86af9e',1.8);line(c,[[-28,0],[-28,f+19]],'#608692',.8);}
        break;}
      case 20: { // The press-room drape has a gathered waist and weighted hem.
        if(!front){rect(c,-55,0,98,f+27,'#6b827b','#405b54',1);path(c,'M-70 158 Q45 210 150 170 Q213 146 264 167 L264 210 Q203 188 146 213 Q42 245 -70 199Z','#758e84','#4a665b',1.2);path(c,'M-67 171 Q45 221 147 184 Q214 158 257 181',null,'#a3b3a0',1.3);line(c,[[-53,145],[258,145]],'#a5a78a',3);for(let j=0;j<6;j++)dot(c,-23+j*48,147,5,null,'#9eab91',1.2);Q.shade(c,35,218,39,f-204,'rgba(29,58,48,.27)');}
        else{path(c,`M-50 -30 H39 Q39 249 28 339 Q18 425 3 ${f-217} Q10 ${f-115} 47 ${f+19} H-60 Q-40 ${f-101} -27 ${f-219} Q-53 315 -50 -30Z`,K.gradient(c,[-50,0],[46,0],[[0,'#49675d'],[.24,'#789184'],[.45,'#91a495'],[.69,'#627f70'],[1,'#425f52']]),'#3d5b4e',1.1);for(const dx of [-30,-11,11,26])path(c,`M${dx} 0 Q${dx-4} 310 -6 ${f-219} Q${dx+5} ${f-91} ${dx+11} ${f+9}`,null,'rgba(194,207,180,.45)',1.1);path(c,`M-31 ${f-222} Q-2 ${f-207} 25 ${f-222}`,null,'#c7b97e',5);path(c,`M23 ${f-219} q28 14 24 39 l-7 26`,null,'#b6a86f',2.2);for(let j=0;j<6;j++)line(c,[[36+j*2,f-159],[33+j*3,f-143]],'#bfae74',1.4);}
        break;}
    }
    c.restore();
  };
})();
