# 鹈鹕骑车六千年 · GPT-6.2 Astra

一只鹈鹕骑车穿过二十种艺术风格。片长 3 分 06 秒。

## 播放

解压后用浏览器打开 pelican.html。点击播放可听到原创配乐，也可以拖动进度条或全屏观看。

## 重建播放器

需要 Python 3.10 或更新版本。运行以下命令可在当前目录生成 pelican.html。

    python tools/build_html.py

src/ 是画面与播放器源码，audio/score.js 是乐谱。

第三方组件和许可见 [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md)。
