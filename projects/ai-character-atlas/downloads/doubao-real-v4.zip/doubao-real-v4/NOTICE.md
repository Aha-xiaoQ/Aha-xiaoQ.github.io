# 来源与使用条件 / Source and reuse

红围巾豆包 · 授权请询原作者

造型参考豆包头像与青时晚的红围巾演出。目前未找到公开授权说明，使用前请向相关作者确认。

[查看原作与使用说明 / Original work and usage terms](https://www.bilibili.com/video/BV1stsZ6iESz/)

- 豆包：产品头像参考
- 青时晚：红围巾真人二创参考

本站制作：在下_小Q，AI 辅助同人设定。补充归档保留所收录的原图。

- https://www.doubao.com/
- https://www.bilibili.com/video/BV1stsZ6iESz/

Character artwork only; excludes website code, music, video and trademarks.
