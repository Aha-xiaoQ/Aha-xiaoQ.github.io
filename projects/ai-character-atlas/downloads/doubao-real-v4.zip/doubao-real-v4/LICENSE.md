# 红围巾豆包 · 授权请询原作者

造型参考豆包头像与青时晚的红围巾演出。目前未找到公开授权说明，使用前请向相关作者确认。

https://www.bilibili.com/video/BV1stsZ6iESz/

Character artwork only; excludes website code, music, video and trademarks.
