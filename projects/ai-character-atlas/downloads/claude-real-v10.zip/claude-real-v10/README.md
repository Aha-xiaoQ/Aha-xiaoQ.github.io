# Claude · 真人版

素材编号：claude-real-v10

橙色长发、日芒花饰、黑白缎带、金链与书册；真人版采用白手套。

## 文件

- `main.png`：主形象，1312 × 1199
- `fullbody.png`：全身与服装，1024 × 1536
- `views.png`：正侧背视图，1536 × 1024
- `expressions.png`：面部表情，1448 × 1086

## 使用方法

1. 以 main.png 锁定面部身份，以 fullbody.png 锁定全身服装、比例与持书姿态；按镜头需要选加视角或表情。
2. 每次只引用同一角色、同一形态、同一版本的文件。不要混入其他候选脸或另一形态。
3. 组合设定图中的人物是同一个角色的不同视角；生成单人画面时需明确说明，避免把整张图当成多人场景。
4. 多视角和表情图是设计参考，不是精密正交建模图。细小饰品与左右关系以主图为准。
5. 这些图片尚不构成经连续视频验证的角色模型；做长镜头前先检查单镜头转头、遮挡和配件稳定性。
6. main.png 单独锁定面部；fullbody.png 定义全身服装与持书姿态；views.png 展示不持书的转身视角；expressions.png 仅补充表情，不改变脸型。

## 来源与权利

见 [NOTICE.md](NOTICE.md) 和 [LICENSE.md](LICENSE.md)。请按本角色的说明使用。

## Quick use

Use main.png as the identity anchor, then add the relevant view/expression sheet. Keep character, interpretation and version consistent. Sheets contain multiple views of one character, not multiple people. They are design references, not exact orthographic blueprints or video-validated identities.
