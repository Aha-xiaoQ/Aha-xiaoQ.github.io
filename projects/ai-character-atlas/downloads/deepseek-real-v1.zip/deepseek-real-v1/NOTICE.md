# 来源与使用条件 / Source and reuse

CC BY-NC-SA 4.0 · 署名／非商业／相同方式共享

使用时请注明作者、来源和改动，附上协议链接。仅限非商业用途，改编作品沿用同一协议。

[查看原作与使用说明 / Original work and usage terms](https://creativecommons.org/licenses/by-nc-sa/4.0/)

- 上善无形：鲸鱼娘原设定
- ZipZipPipe：DeepSeek 女仆二次设计
- Small-tailqwq：图鉴所引素材加工（仅适用于该来源链）

本站制作：在下_小Q，AI 辅助同人设定。补充归档保留所收录的原图。

- https://www.bilibili.com/opus/1231977657712771073
- https://www.pixiv.net/artworks/148186519
- https://selinlee.github.io/ai-moe-atlas/zh/characters/deep-whale-maid/

Character artwork only; excludes website code, music, video and trademarks.
