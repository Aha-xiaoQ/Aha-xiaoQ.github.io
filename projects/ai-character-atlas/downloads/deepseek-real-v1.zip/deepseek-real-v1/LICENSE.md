# CC BY-NC-SA 4.0 · 署名／非商业／相同方式共享

使用时请注明作者、来源和改动，附上协议链接。仅限非商业用途，改编作品沿用同一协议。

https://creativecommons.org/licenses/by-nc-sa/4.0/

Character artwork only; excludes website code, music, video and trademarks.
