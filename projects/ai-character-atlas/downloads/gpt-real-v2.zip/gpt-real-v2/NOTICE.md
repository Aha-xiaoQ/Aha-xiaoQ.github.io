# 来源与使用条件 / Source and reuse

ZipZipPipe · 原作使用说明

据来源图鉴，原图须署名 ZipZipPipe，仅限非商业用途。本站二创设定的改编授权尚待确认，请先联系原作者。

[查看原作与使用说明 / Original work and usage terms](https://www.pixiv.net/artworks/148186519)

- ZipZipPipe：社区拟人设计

本站制作：在下_小Q，AI 辅助同人设定。补充归档保留所收录的原图。

- https://www.pixiv.net/artworks/148186519
- https://selinlee.github.io/ai-moe-atlas/zh/characters/zipzippipe-chatgpt/

Character artwork only; excludes website code, music, video and trademarks.
