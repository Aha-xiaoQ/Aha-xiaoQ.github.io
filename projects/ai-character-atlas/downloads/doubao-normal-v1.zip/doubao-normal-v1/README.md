# 豆包 · 常规版

素材编号：doubao-normal-v1

偏分短发、红围巾、黑色衣裤；真人面容以本套主图为准，气质温柔、亲切、从容。

## 文件

- `main.png`：主形象，1024 × 1536
- `views-expressions.png`：多视角与表情，1536 × 1024

## 使用方法

1. 先用 main.png 锁定脸部、服装、配色和比例，再按镜头需要附加多视角或表情参考。
2. 每次只引用同一角色、同一形态、同一版本的文件。不要混入其他候选脸或另一形态。
3. 组合设定图中的人物是同一个角色的不同视角；生成单人画面时需明确说明，避免把整张图当成多人场景。
4. 多视角和表情图是设计参考，不是精密正交建模图。细小饰品与左右关系以主图为准。
5. 这些图片尚不构成经连续视频验证的角色模型；做长镜头前先检查单镜头转头、遮挡和配件稳定性。

## 来源与权利

见 [NOTICE.md](NOTICE.md) 和 [LICENSE.md](LICENSE.md)。请按本角色的说明使用。

## Quick use

Use main.png as the identity anchor, then add the relevant view/expression sheet. Keep character, interpretation and version consistent. Sheets contain multiple views of one character, not multiple people. They are design references, not exact orthographic blueprints or video-validated identities.
