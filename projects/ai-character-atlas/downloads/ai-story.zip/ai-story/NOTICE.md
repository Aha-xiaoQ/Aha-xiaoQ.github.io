# 来源与使用条件 / Source and reuse

ZipZipPipe · 原作使用说明

据来源图鉴，原图须署名 ZipZipPipe，仅限非商业用途。本站二创设定的改编授权尚待确认，请先联系原作者。

[查看原作与使用说明 / Original work and usage terms](https://www.pixiv.net/artworks/148186519)

- ZipZipPipe：社区拟人设计

本站制作：在下_小Q，AI 辅助同人设定。补充归档保留所收录的原图。

- https://www.pixiv.net/artworks/148186519
- https://selinlee.github.io/ai-moe-atlas/zh/characters/zipzippipe-claude/

Character artwork only; excludes website code, music, video and trademarks.


# 来源与使用条件 / Source and reuse

CC BY-NC-SA 4.0 · 署名／非商业／相同方式共享

使用时请注明作者、来源和改动，附上协议链接。仅限非商业用途，改编作品沿用同一协议。

[查看原作与使用说明 / Original work and usage terms](https://creativecommons.org/licenses/by-nc-sa/4.0/)

- 上善无形：鲸鱼娘原设定
- ZipZipPipe：DeepSeek 女仆二次设计
- Small-tailqwq：图鉴所引素材加工（仅适用于该来源链）

本站制作：在下_小Q，AI 辅助同人设定。补充归档保留所收录的原图。

- https://www.bilibili.com/opus/1231977657712771073
- https://www.pixiv.net/artworks/148186519
- https://selinlee.github.io/ai-moe-atlas/zh/characters/deep-whale-maid/

Character artwork only; excludes website code, music, video and trademarks.


# 来源与使用条件 / Source and reuse

红围巾豆包 · 授权请询原作者

造型参考豆包头像与青时晚的红围巾演出。目前未找到公开授权说明，使用前请向相关作者确认。

[查看原作与使用说明 / Original work and usage terms](https://www.bilibili.com/video/BV1stsZ6iESz/)

- 豆包：产品头像参考
- 青时晚：红围巾真人二创参考

本站制作：在下_小Q，AI 辅助同人设定。补充归档保留所收录的原图。

- https://www.doubao.com/
- https://www.bilibili.com/video/BV1stsZ6iESz/

Character artwork only; excludes website code, music, video and trademarks.
