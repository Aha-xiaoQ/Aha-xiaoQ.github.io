# 角色素材 / Character references

PNG 为提供文件的原始字节，未缩放或改色。角色、版本、尺寸、透明状态与来源见 catalog.json；使用条件见 NOTICE.md。本包收录采用造型及必要配套视角。按角色与服装版本选择，不将不同造型混为同一个身份。
