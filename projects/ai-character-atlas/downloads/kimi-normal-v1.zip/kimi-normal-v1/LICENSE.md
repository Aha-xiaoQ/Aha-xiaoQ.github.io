# ZipZipPipe · 原作使用说明

据来源图鉴，原图须署名 ZipZipPipe，仅限非商业用途。本站二创设定的改编授权尚待确认，请先联系原作者。

https://www.pixiv.net/artworks/148186519

Character artwork only; excludes website code, music, video and trademarks.
