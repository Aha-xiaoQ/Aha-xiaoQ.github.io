# 混合马里奥在下_小Q版

九位角色在经典马里奥关卡中冒险，包含角色专属隐藏关、彩蛋和本地成就。版本：0.8.12 r3。

## 直接游玩

使用同目录的游戏下载包，解压后用近期版本 Chrome 或 Edge 打开 play.html。按键、声音、暂停与存档选项见游戏内菜单。浏览器首次播放声音需要点击页面或按键。

## 从源码运行

需要 Node.js 22 或更新版本。在源码目录执行：

```sh
npm ci
npm run build
npm run dev
```

打开终端显示的本地地址，默认 http://127.0.0.1:4194/play.html 。构建产物为 dist/play.html，可单独离线打开。更换端口：npm run dev -- --port 4195。

src 保存游戏程序与数据，assets 保存图像和音频，content 保存关卡源文件，manifest.json 固定编译顺序与素材摘要。npm run check 执行编译结构与素材完整性检查；npm run pack 导出同样范围的源码包。

源码包提供运行与构建所需内容；素材许可与来源见 NOTICE.md。角色、美术、音乐及音效权利归原权利人。
