import {createEnemyRegistry,createEnemyResolver} from '../engine/enemy-contract.mjs';
import {enemyDefinition as sharedEnemyDefinition} from '../content/enemies.mjs';
import {ORIGINAL_BOSS_SOURCE as SOURCE} from '../content/original-bosses.mjs';
import {CHALLENGE_TUNING} from '../content/challenge-tuning.mjs';
/** Original indoor aiming fixes target Y at $b0, even during a jump.
 * bank7.asm:10520-10666, 10058-10074, 10159-10170. */
export function contraBaseProjectileVelocity(from,playerX){
 const x=Math.floor(from.x),y=Math.floor(from.y),px=Math.floor(playerX),py=SOURCE.base1.indoorAimY;
 const dx=Math.min(255,Math.abs(px-x)),dy=Math.min(255,Math.abs(py-y));
 const packed=SOURCE.base1.quadrantAim[dy>>>5][dx>>>6];
 const aimDirection=((dx&32)?packed:packed>>>4)&15;
 const [fy,fx]=SOURCE.base1.velocityFractions[aimDirection];
 const speed6=n=>(n+(n>>>1)+(n>>>2))/256;
 return {vx:(px<x?-1:1)*speed6(fx),vy:(py<y?-1:1)*speed6(fy),aimDirection,quadrant:(py<y?1:0)|(px<x?2:0)};
}
export function contraBaseWeaponStrength(weapon='N'){
 const key=weapon??'N';if(!Object.hasOwn(SOURCE.base1.weaponStrength,key))throw new TypeError('Unknown Contra weapon strength');
 return SOURCE.base1.weaponStrength[key];
}
const rows=[
 ['mm1','cutman',SOURCE.cutman.source,'run/jump/throw/return','solid',5000],
 ['mm1','rolling-cutter',SOURCE.cutman.source,'original-outbound/return','projectile',0],
 ['contra-nes','base1-eye',SOURCE.base1.source,'plating-gated-horizontal-eye','scripted',5000],
 ['contra-nes','wall-plating',SOURCE.base1.source,'stationary-wall-plating','scripted',200],
 ['contra-nes','wall-cannon',SOURCE.base1.source,'original-open-fire-close','scripted',500],
 ['contra-nes','cannon-shot',SOURCE.base1.source,'original-three-fixed-point-fan','projectile',0],
 ['contra-nes','fire-ring',SOURCE.base1.source,'small-to-large-aimed-ring','projectile',0],
].map(([origin,kind,source,model,collision,score])=>({id:origin+':'+kind,origin,owner:'foe-port',source,
 movement:{model,collision},contact:{stomp:'hurt',...(origin==='mm1'?{healthDamage:kind==='cutman'?SOURCE.cutman.contactDamage:SOURCE.cutman.cutterDamage}:{})},hurt:{handler:'foe-port',animation:'original-hit-flash',sound:origin==='mm1'?'mm1_boss_hit':'contra_boss_hit'},
 death:{handler:'foe-port',animation:'original-source-explosion',sound:origin==='mm1'?'mm1_boss_explode':kind==='base1-eye'?'contra_boss_explode':'contra_wall_explode',retire:'effect-complete'},score,starKill:false,targetable:!['rolling-cutter','cannon-shot'].includes(kind)}));
const registry=createEnemyRegistry(rows),resolve=createEnemyResolver({registry});
export function originalBossEnemyDefinition(e){return rows.some(r=>r.id===e.contractId)?resolve(e):sharedEnemyDefinition(e);}

/** All encounter state is on checkpointed entities. This port owns no clock,
 * life counter, selected hero, carry ledger or reward receipt. */
export function createOriginalBossEnemies(hero,{draw=()=>false,sound=()=>{},playerBulletContact=null}={}){
 const valid=hero==='megaman'?new Set(['mm1:cutman','mm1:rolling-cutter']):new Set(['contra-nes:base1-eye','contra-nes:wall-plating','contra-nes:wall-cannon','contra-nes:cannon-shot','contra-nes:fire-ring']);
 function prepare(w){
  for(const e of w.enemies){if(!valid.has(e.contractId))throw new TypeError('Foreign entity in original Boss encounter');
   if(e.originalBossInitialized)continue;
   e.originalBossInitialized=true;e.type=e.contractId.split(':')[1];e.foeSource=e.contractId.split(':')[0];e.nativeOwner='foe-port';e.vx=e.vy=0;e.bossAge=0;e.flash=0;e.dir=-1;
   if(e.type==='cutman'){e.hp=e.maxHp=SOURCE.cutman.hp;e.ai='compare';e.aiAge=0;e.seed=1;e.grounded=true;e.invuln=0;e.cutterSerial=0;}
   else if(e.type==='base1-eye'){e.hp=e.maxHp=SOURCE.base1.hp;e.wait=SOURCE.base1.startDelay;e.ai='platings';e.shotWait=32;e.vx=SOURCE.base1.speed;e.ringSerial=0;e.eyeFrame=0;e.animationDelay=0;}
   else if(e.type==='wall-plating'){e.hp=e.maxHp=SOURCE.base1.platingHp;e.deployWait=SOURCE.base1.platingDelay;e.sourceTileFrame=0;e.vulnerable=false;}
   else if(e.type==='wall-cannon'){e.hp=e.maxHp=SOURCE.base1.cannonHp;e.ai='opening';e.phaseWait=SOURCE.base1.cannonDelay;e.frame=0;e.sourceTileFrame=0;e.vulnerable=false;e.ringSerial=0;}
  }
 }
 const center=e=>({x:e.x+e.w/2,y:e.y+e.h/2});
 function shot(w,owner,type,box,vx,vy){const origin=owner.foeSource;
  const e={id:owner.id+'-'+type+'-'+(type==='rolling-cutter'?++owner.cutterSerial:++owner.ringSerial),kind:'walker',type,contractId:origin+':'+type,nativeOwner:'foe-port',foeSource:origin,
   ...box,vx,vy,hp:type==='fire-ring'?SOURCE.base1.fireRingHp:1,dead:false,originalBossInitialized:true,bossAge:0,owner:owner.id,returning:false,dir:owner.dir,safe:type==='fire-ring'?2:0};w.enemies.push(e);return e;
 }
 function aim(from,to,speed){const dx=to.x-from.x,dy=to.y-from.y,d=Math.hypot(dx,dy)||1;return {vx:dx/d*speed,vy:dy/d*speed};}
 function throwCutter(e,w,p){if(w.enemies.some(q=>q.owner===e.id&&q.type==='rolling-cutter'&&!q.dead))return;
  const a={x:e.x+e.w/2+e.dir*8,y:e.y+2},v=aim(a,{x:p.x+p.w/2,y:p.y+p.h/2},SOURCE.cutman.cutterSpeed);
  shot(w,e,'rolling-cutter',{x:a.x-8,y:a.y-8,w:16,h:16},v.vx,v.vy);sound('mm1_rolling_cutter');e.lastShotTick=w.tick;
 }
 function cutman(e,w,p){
  if(e.invuln>0)e.invuln--;
  const c=center(e),pc=center(p),dx=pc.x-c.x;
  if(e.ai==='compare'){e.dir=dx<0?-1:1;e.aiAge=0;e.ai=Math.abs(dx)>=64?'run':'throw';e.vx=e.ai==='run'?e.dir*SOURCE.cutman.runSpeed:0;}
  e.aiAge++;
  if(e.ai==='run'){
   e.dir=dx<0?-1:1;e.vx=e.dir*SOURCE.cutman.runSpeed;
   if(Math.abs(dx)<64||e.aiAge>=48){e.seed=(e.seed*5+1)&255;e.ai='jump';e.aiAge=0;e.vy=-SOURCE.cutman.jumpSpeed;e.vx=e.dir*Math.min(2.375,Math.max(.75,Math.abs(dx)/50));e.grounded=false;}
  }else if(e.ai==='throw'){
   e.vx=0;if(e.aiAge===16)throwCutter(e,w,p);if(e.aiAge>=32){e.ai='jump';e.aiAge=0;e.vy=-SOURCE.cutman.jumpSpeed;e.vx=e.dir*.75;e.grounded=false;}
  }else if(e.ai==='jump'){
   if(e.aiAge===18)throwCutter(e,w,p);
  }else if(e.ai==='knockback'){
   if(e.invuln<31)e.ai='compare';
  }
  const result=w.moveEnemy(e,e.vx,e.vy);
  if(result.x)e.vx=0;
  if(result.y)e.vy=0;
  if(e.grounded&&e.ai==='jump'&&e.aiAge>3){e.ai='compare';e.vx=0;}
  if(!e.grounded)e.vy=Math.min(12,e.vy+SOURCE.cutman.gravity);
  e.sourceFrame=e.ai==='throw'&&e.aiAge<16?'26':e.ai==='throw'?'27':!e.grounded?'28':['2a','2e','2c','2e'][Math.floor(e.aiAge/6)%4];
  const cutter=w.enemies.some(q=>q.owner===e.id&&q.type==='rolling-cutter'&&!q.dead);
  if(cutter)e.sourceFrame=({26:'27',28:'29','2a':'2b','2c':'2d','2e':'2f'})[e.sourceFrame]||e.sourceFrame;
 }
 function cutter(e,w){const owner=w.enemies.find(q=>q.id===e.owner&&!q.dead);if(!owner){e.dead=true;return;}
  const c=center(e),target=center(owner);
  if(!e.returning&&(c.x<24||c.x>(w.width||256)-24||c.y<24||c.y>216)){e.returning=true;e.returnSpeed=SOURCE.cutman.cutterSpeed;e.vx=-e.vx;e.vy=-e.vy;}
  if(e.returning&&w.tick%4===0){e.returnSpeed+=4/256;Object.assign(e,aim(c,target,e.returnSpeed));}
  e.x+=e.vx;e.y+=e.vy;e.sourceFrame=['69','6a','6b','6c'][Math.floor(e.bossAge/4)%4];
  if(e.returning&&Math.abs(center(e).x-target.x)<8&&Math.abs(center(e).y-target.y)<8)e.dead=true;
 }
 function eye(e,w,p){
  if(e.ai==='platings'){
   if(w.enemies.some(q=>q.type==='wall-plating'&&!q.dead))return;
   if(--e.wait>0)return;e.ai='active';e.shotWait=32;e.eyeFrame=0;e.animationDelay=SOURCE.base1.appearanceRedTicks;
    // routine_01 only enables the Eye. Sprite, movement and first attack
    // countdown begin on the next routine_02 step.
    return;
  }
  const red=e.animationDelay>0;if(red)e.animationDelay--;
   e.eyeFrame=(e.eyeFrame||0)+1;
   e.sourceFrame=SOURCE.base1.frames[((e.eyeFrame>>>3)&3)+(red&&(w.tick&4)?4:0)];
  e.x+=e.vx;
  // The NES branches on the integer position after its fractional move.
  // It reverses only the current travel direction, without clamping position.
  const sourceX=Math.floor(e.x+e.w/2);
  const offset=((w.width||256)-256)/2;
  if(e.vx>=0?sourceX>=SOURCE.base1.right+offset:sourceX<SOURCE.base1.left+offset)e.vx=-e.vx;
  if(--e.shotWait<=0){
   e.shotWait=SOURCE.base1.attackDelays[contraBaseWeaponStrength(p.weapon)];
   // The six-ring crossover limit remains; a refused emission still reloads.
   if(w.enemies.filter(q=>q.type==='fire-ring'&&!q.dead).length<SOURCE.base1.ringLimit){
    const c={x:e.x+e.w/2,y:SOURCE.base1.eyeOriginY},v=contraBaseProjectileVelocity(c,p.x+p.w/2);
    shot(w,e,'fire-ring',{x:c.x-7,y:c.y-7,w:14,h:14},v.vx,v.vy); // Original Eye emission is silent.
   }
  }
 }
 function plating(e){
  if(e.vulnerable)return;
  if(--e.deployWait>0)return;
  if(e.sourceTileFrame===0){e.sourceTileFrame=3;e.deployWait=SOURCE.base1.platingFrameDelay;}
  else {e.sourceTileFrame=4;e.vulnerable=true;}
 }
 function cannon(e,w,p){
  // A dead Eye shuts the original defence system down, including live bullets.
  if(!w.enemies.some(q=>q.type==='base1-eye'&&!q.dead)){e.vx=e.vy=0;e.vulnerable=false;return;}
  if(e.ai==='opening'){
   if(--e.phaseWait>0)return;e.sourceTileFrame=e.frame;
   if(e.frame<2){e.frame++;e.phaseWait=SOURCE.base1.cannonFrameDelay;}
   else {e.ai='open';e.vulnerable=true;e.phaseWait=SOURCE.base1.cannonOpen;e.shotWait=SOURCE.base1.cannonShotDelay;}
  }else if(e.ai==='open'){
   if(e.shotWait>0&&--e.shotWait===0){const c={x:e.x+e.w/2,y:SOURCE.base1.cannonOriginY};
    // bank7 speed7 fixed-point additions, preserving original rounding.
    for(const [ox,vx,vy]of [[-8,-240/256,413/256],[0,0,476/256],[8,240/256,413/256]])
     shot(w,e,'cannon-shot',{x:c.x+ox-4,y:c.y+4,w:8,h:8},vx,vy);
    // Original wall cannon emits without a shot sound.
   }
   if(--e.phaseWait<=0){e.ai='closing';e.vulnerable=false;e.phaseWait=SOURCE.base1.cannonFrameDelay;}
  }else if(e.ai==='closing'){
   if(--e.phaseWait>0)return;e.sourceTileFrame=e.frame;
   if(e.frame>0){e.frame--;e.phaseWait=SOURCE.base1.cannonFrameDelay;}
   else {e.ai='opening';e.phaseWait=SOURCE.base1.cannonRest[contraBaseWeaponStrength(p.weapon)>=2?1:0];}
  }
 }
 function step(e,w,p){if(!valid.has(e.contractId))return false;if(e.dead)return true;e.bossAge++;if(e.flash>0)e.flash--;
  if(e.type==='cutman')cutman(e,w,p);
  else if(e.type==='rolling-cutter')cutter(e,w);
  else if(e.type==='base1-eye')eye(e,w,p);
  else if(e.type==='wall-plating')plating(e);
  else if(e.type==='wall-cannon')cannon(e,w,p);
  else if(e.type==='fire-ring'){
   if(!w.enemies.some(q=>q.type==='base1-eye'&&!q.dead)){e.dead=true;return true;}
   const c=center(e);if(e.h===14&&c.y>=72){e.x=c.x-15.5;e.y=c.y-15.5;e.w=e.h=31;}
   e.safe=e.h===14?2:0;
   e.sourceMirror=SOURCE.base1.mirrorAttributes[(w.tick>>>2)&3];
    e.x+=e.vx;e.y+=e.vy;e.sourceFrame=e.h===14?'63':'64';if(e.y>240||e.x<-32||e.x>(w.width||256)+32||e.bossAge>300)e.dead=true;
  }else if(e.type==='cannon-shot'){
   if(!w.enemies.some(q=>q.type==='base1-eye'&&!q.dead)){e.dead=true;return true;}
   e.x+=e.vx;e.y+=e.vy;if(e.y>240||e.x<-16||e.x>(w.width||256)+16||e.bossAge>180)e.dead=true;
  }
  if(playerBulletContact&&!e.dead)playerBulletContact(e,w,p);
  return true;
 }
 function hurt(e,amount,event,w){if(!valid.has(e.contractId)||e.dead||['cannon-shot','rolling-cutter'].includes(e.type))return false;
  if(['wall-plating','wall-cannon'].includes(e.type)&&!e.vulnerable)return false;
  if(e.type==='fire-ring'&&e.h===14)return false;
  if(e.type==='base1-eye'&&(e.ai!=='active'||w.enemies.some(q=>q.type==='wall-plating'&&!q.dead)))return false;
  if(e.type==='cutman'&&e.invuln>0)return false;
  const damage=e.type==='cutman'?(event.kind==='super-arm'?SOURCE.cutman.superArmDamage:event.kind==='megaman-shot'?CHALLENGE_TUNING.megaman.busterDamage:amount):e.type==='base1-eye'?1:amount;
  e.hp-=damage;e.flash=e.type==='base1-eye'?SOURCE.base1.hitRedTicks:8;if(e.type==='base1-eye')e.animationDelay=SOURCE.base1.hitRedTicks;
  if(e.type==='cutman'){e.invuln=SOURCE.cutman.invulnerability;e.ai='knockback';e.aiAge=0;e.vx=-e.dir*SOURCE.cutman.runSpeed;e.vy=-1.25;e.grounded=false;}
  // Original damage cue occurs on a surviving hit; defeat owns its sound.
  if(e.hp>0)sound(e.foeSource==='mm1'?'mm1_boss_hit':'contra_boss_hit');return true;
 }
 function death(e,tick){if(!valid.has(e.contractId))return null;if(['wall-plating','wall-cannon'].includes(e.type))e.sourceTileFrame=5;sound(e.foeSource==='mm1'?'mm1_boss_explode':e.type==='base1-eye'?'contra_boss_explode':'contra_wall_explode');if(['cutman','base1-eye'].includes(e.type))sound(e.type==='cutman'?'mm1_victory':'contra_victory');
  return {kind:'original-boss-explosion',flat:true,vx:0,vy:0,life:['wall-plating','wall-cannon','fire-ring'].includes(e.type)?24:64,deathTick:tick};}
 // A fixed, defeated nametable projection has no independent HP/alive state.
 function defeatBackground(declaration){
  if(!valid.has(declaration.contractId)||!['contra-nes:wall-plating','contra-nes:wall-cannon'].includes(declaration.contractId))return null;
  return {...declaration,type:declaration.contractId.split(':')[1],foeSource:'contra-nes',kind:'original-boss-background',sourceTileFrame:5};
 }
 return Object.freeze({prepare,step,hurt,death,defeatBackground,draw:(g,e,tick)=>draw(g,e,tick)});
}
