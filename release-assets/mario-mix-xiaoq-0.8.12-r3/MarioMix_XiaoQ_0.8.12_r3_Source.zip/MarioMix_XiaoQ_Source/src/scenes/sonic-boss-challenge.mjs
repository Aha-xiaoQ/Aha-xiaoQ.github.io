import {createPlatformStage} from '../campaign/stage.mjs';
import {createCharacterMotor} from '../campaign/character-motor.mjs';
import {nativeArenaWidth} from '../engine/viewport.mjs';
import {nativeSceneHealth,copySceneCheckpoint} from '../engine/scene-state.mjs';
import {SONIC_BOSS_ROOM,sonicBossRoom,sonicBossPlan,sonicBossDefinition,createSonicBossEnemies} from '../content/sonic-boss.mjs';
import {beginHiddenDeparture,stepHiddenDeparture,hiddenDepartureFrame,validateHiddenDeparture} from './hidden-departures.mjs';

export function createSonicBossChallenge({character,rule,createActor,viewport,render,sound,syncAudio=null,debug=false,createStage=createPlatformStage}){
 const arenaWidth=()=>Math.max(SONIC_BOSS_ROOM.width,nativeArenaWidth(viewport())),def=sonicBossRoom(arenaWidth());
 let plan=sonicBossPlan(character,def);const visualRooms=[{roomId:def.id,setting:'Native',map:{geometry:def.geometry},markers:[],semantics:[]}];
 let stage=null,actor=null,foes=null,baseline=null,rewardSpawned=false,rewardClaimed=false,exited=false,paused=false;
 let departure=null;
 const width=()=>Math.min(def.width,nativeArenaWidth(viewport()));
 function syncArena(savedWidth=null){
  if(!stage)return;
  const nextWidth=arenaWidth(),from=savedWidth??def.width;
  if(nextWidth!==from||nextWidth!==def.width){
   const next=sonicBossRoom(nextWidth),mapX=x=>x+(nextWidth-from)/2,privateFrom=def.width,privateMapX=x=>x+(nextWidth-privateFrom)/2;
   stage.resizeNativeArena({width:nextWidth,geometry:next.geometry,objects:[{id:'entry',kind:'spawn',...next.spawn},...next.objects],mapX,privateMapX});
   foes.remapSceneX(mapX);Object.assign(def,next);
   if(departure){departure.origin.x=mapX(departure.origin.x);departure.endX=mapX(departure.endX);departure.landingX=mapX(departure.landingX);}
  }
  stage.setViewportWidth(width());
 }
 function enter({carry,retry,rewardReceipt}){
  if(rewardReceipt&&(rewardReceipt.version!==1||rewardReceipt.id!=='hidden-clear:sonic'||typeof rewardReceipt.claimed!=='boolean'))throw new TypeError('Invalid Sonic room receipt');
  Object.assign(def,sonicBossRoom(arenaWidth()));plan=sonicBossPlan(character,def);visualRooms[0].map.geometry=def.geometry;
  baseline=structuredClone(carry);departure=null;rewardSpawned=false;rewardClaimed=rewardReceipt?.claimed===true;exited=paused=false;
  if(retry&&baseline.native?.nativeVitals)baseline.native.nativeVitals=nativeSceneHealth(rule,baseline.native.nativeVitals,{retry:true});
  actor=createActor('sonic');foes=createSonicBossEnemies({room:def,sound:event=>sound(actor,event)});
  stage=createStage({plan,motor:createCharacterMotor(),actorPort:actor,enemyPort:foes,enemyDefinition:sonicBossDefinition,visualRooms,
   initialState:{...baseline,hero:'sonic'},sceneHealth:rule,backtracking:true,manualDeath:true,lifeOwner:'campaign',debug,viewportWidth:width(),
   emit:(type,data)=>{
    if(type==='sound')sound(actor,data.event);
    if(type==='item-collected'&&rewardSpawned&&data.entityId===def.reward.id)rewardClaimed=true;
   }});
  if(syncAudio)syncAudio(true);else actor.audio(true);return true;
 }
 function step(input){syncArena();if(paused||exited)return;
  if(departure){foes.advanceRetreat();exited=stepHiddenDeparture(departure);return;}
  stage.setViewportWidth(width());stage.step({...input,x:input.x??Number(input.right)-Number(input.left)});
  let v=stage.view();if(v.p.dying)return;foes.advanceRetreat();
  if(foes.view().defeated&&!rewardSpawned&&!rewardClaimed){stage.spawnReward({...def.reward,kind:'native-supply'});rewardSpawned=true;}
 }
 function beginDeparture(){
  syncArena();
  if(departure||exited)return true;if(!stage||paused||!rewardClaimed)return false;
  const v=stage.view(),boss=foes.view();
  if(v.p.dying||!v.p.grounded||!boss.defeated||boss.retreat&&boss.retreat.phase!=='escape')return false;
  departure=beginHiddenDeparture('run',v.p,{endX:Math.max(def.width+48,v.p.x+288)});return true;
 }
 function view(){syncArena();const v=stage?.view();if(!v)return {};const boss=foes.view(),cleared=boss.defeated&&rewardClaimed;return {
  hero:'sonic',id:def.id,title:def.title,mode:paused?'paused':'playing',area:def.id,cleared,exited,exitReady:cleared,departure:departure?hiddenDepartureFrame(departure):null,failed:!!v.p.dying,
  logicalWidth:width(),logicalHeight:240,healthMode:rule.health,hp:v.health,maxHp:rule.initialHealth||1,
  carry:{score:v.score,coins:v.coins,lives:v.lives},nativeCarry:v.native,protection:(v.native?.upgradeTier||0)>0?1:0,
  nativeReward:rewardClaimed?{kind:'native-equipment',id:'lightning-shield'}:null,rewardClaimed,
  progress:{x:v.p.x,y:v.p.y,tick:v.tick,bossHp:v.enemies.find(e=>e.id==='ghz-eggman')?.hp||0,bossDefeated:boss.defeated},body:v.p};}
 function snapshotScene(){syncArena();return {schema:'sonic-ghz-scene-v1',arenaWidth:def.width,id:def.id,departure:departure?structuredClone(departure):null,rewardSpawned,rewardClaimed,exited,boss:foes.snapshot(),stage:stage.checkpointScene()};}
 function migrateCheckpoint(checkpoint){
  const next=copySceneCheckpoint('sonic',checkpoint),data=next.data;
  if(data.schema==='native-platform-scene-v1'&&data.id==='sonic-ring-run')return null;
  if(data.schema==='sonic-ghz-scene-v1'&&data.id===def.id)return next;
  throw new TypeError('Unknown Sonic scene checkpoint');
 }
 function restoreScene(data){const d=copySceneCheckpoint('sonic',{version:1,hero:'sonic',data}).data;
  const savedWidth=d.arenaWidth??SONIC_BOSS_ROOM.width;sonicBossRoom(savedWidth);
  if(d?.schema!=='sonic-ghz-scene-v1'||d.id!==def.id||['rewardSpawned','rewardClaimed','exited'].some(k=>typeof d[k]!=='boolean')||d.exited&&(!d.rewardClaimed||!d.boss?.defeated)||d.rewardSpawned&&!d.boss?.defeated)throw new TypeError('Invalid Sonic boss scene state');
  if(d.departure!=null){validateHiddenDeparture(d.departure);if(d.departure.kind!=='run'||!d.rewardClaimed||!d.boss?.defeated||d.exited!==hiddenDepartureFrame(d.departure).complete)throw new TypeError('Invalid Sonic departure');}
  const item=d.stage?.items?.find(i=>i.id===def.reward.id&&!i.dead);
  if(d.rewardSpawned&&!d.rewardClaimed&&!item||d.rewardClaimed&&item)throw new TypeError('Invalid Sonic reward collectible state');
  foes.validate(d.boss);
  stage.restoreScene(d.stage);foes.restore(d.boss);departure=d.departure?structuredClone(d.departure):null;({rewardSpawned,rewardClaimed,exited}=d);syncArena(savedWidth);
 }
 return {chapter:14,rules:rule,enter,step,view,beginDeparture,snapshotScene,restoreScene,migrateCheckpoint,grantCompletionBonus:award=>stage.grantCompletionBonus(award),
  ...(debug?{diagnostics:()=>({state:stage.view(),...stage.diagnostics})}:{}),
  draw(){syncArena();render({def,view:stage.view(),stage,actor,foes,boss:foes.view(),cleared:foes.view().defeated&&rewardClaimed,departure:departure?hiddenDepartureFrame(departure):null,width:width()});},
  audio(){if(syncAudio)syncAudio(!paused&&!exited);else actor?.audio(!paused&&!exited);},
  pause(){paused=true;stage.pause();syncAudio?.(false);},resume(){paused=false;stage.resume();syncAudio?.(true);},
  leave(){syncAudio?.(false);stage?.dispose();stage=null;actor=null;foes=null;},
 };
}
