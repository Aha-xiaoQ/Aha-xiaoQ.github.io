import {createRelayDeparture,validateRelayDeparture} from '../../characters/ryu/departure.mjs';
export const TANK_DEFENSE_EXIT=Object.freeze({x:192,y:192,bottom:232});

/** Pickup and defense/return transactions; audio and presentation are explicit ports. */
export function createTankRewards({state:s,viewport,motion,ports:p}){
  function give(type,{enemyEffect}={}){
    const tank=s.scene.tank;let clip='pickup';
    if(type==='star'||type==='power'){tank.power=Math.min(3,tank.power+1);s.scene.rankFlash=32;clip='upgrade';p.event('tank-form',{rank:tank.power,sprite:'pack06-'+s.palette+'-'+tank.power});}
    else if(type==='helmet'||type==='health')tank.shield=600;
    else if(type==='timer'){tank.freeze=360;enemyEffect?.('freeze');}
    else if(type==='life'){s.lives++;clip='life';}
    else if(type==='grenade'){
      if(enemyEffect)enemyEffect('defeat-visible');
      else for(const e of s.actor.foes)if(!e.dead&&e.x>=s.camera-20&&e.x<s.camera+viewport.view().width+20)p.kill(e,true);
      s.scene.shake=8;clip='grenade';
    }
    else if(type==='shovel'){
      tank.shovel=900;
      if(s.scene.area==='defense'){
        const left=s.challenge.base.x-8,right=s.challenge.base.x+s.challenge.base.w;
        for(let x=left;x<=right;x+=8)for(let y=208;y<=224;y+=8){
          if(x>left&&x<right&&y>208)continue;
          let block=s.challenge.blocks.find(b=>b.x===x&&b.y===y);
          if(!block){block={x,y,w:8,h:8,type:'brick',dead:false};s.challenge.blocks.push(block);}
          block.type='steel';block.dead=false;block.shovelGuard=true;
        }
      }else tank.shield=Math.max(tank.shield,240);
    }
    p.addScore(500,s.player.x,s.player.y);p.sound(clip);
    p.message(({star:'火力升级 · 车体已变化',power:'火力升级',helmet:'护盾已开启',health:'护盾已开启',timer:'敌军暂停',grenade:'清除当前区域敌军',life:'生命 +1',shovel:s.scene.area==='defense'?'基地临时钢墙':'主路铁铲：短时护盾'})[type]||'补给',140);
    p.event('pickup',{item:type,points:500});p.updateUI();
    if(type==='shovel')motion.clearFortifications();
  }
  function beginDeparture(){
    const c=s.challenge;
    if(s.scene?.area!=='defense'||!c?.won||!s.rewards?.tank||!c.tally08)return false;
    if(c.departure){validateRelayDeparture(c.departure,'tank-results');return true;}
    c.departure=createRelayDeparture('tank-results');c.departure.age=c.tally08.clock;
    return true;
  }
  function winDefense(){
    const c=s.challenge;if(!c||c.won)return;
    c.won=true;c.wonAt=s.frame;s.scene.r08IntroPending=false;
    if(!s.rewards.tank){s.rewards.tank=true;s.scene.tank.power=3;s.scene.tank.shield=600;p.event('secret-reward',{kind:'tank',reward:'max-power-shield'});}
    s.actor.projectiles=[];s.player.vx=s.player.vy=0;p.clearCommands();
    const rows=['basic','fast','power','armor'].map(type=>({type,count:c.ledger08?.[type]?.count??s.actor.foes.filter(e=>e.dead&&e.tankKind===type).length,points:c.ledger08?.[type]?.points??0,shown:0,shownPoints:0}));
    c.tally08={active:true,clock:0,duration:330,rows,total:0,points:0,totalFlash:0,releaseSeen:false,lastTick:-1,scoreAtWin:s.score};
    beginDeparture();c.exitPipe=null;s.pipes=[];s.scene.message='';s.scene.messageTime=0;p.stopEngine();p.stopEffects();p.detachCue(false);p.sound('tally',{volume:.7});
    p.event('defense-tally-start',{kills:rows.reduce((a,b)=>a+b.count,0),earned:rows.reduce((a,b)=>a+b.points,0)});
  }
  function openExit(){
    const c=s.challenge;if(!c?.won||!c.tally08||c.tally08.active||c.tally08.clock<330||c.departure?.complete)return;
    if(!beginDeparture())return;
    c.departure.phase='complete';c.departure.complete=true;c.departure.age=c.tally08?.clock||0;
    // Compatibility with a saved 0.8.4 victory: remove its generated exit only.
    c.blocks=c.blocks.filter(b=>b.type!=='pipe');c.exitPipe=null;s.pipes=[];
    p.clearCommands();s.player.vx=s.player.vy=0;
    p.event('defense-departure-complete');
  }
  function tryExit(input){
    // Native results complete automatically; no Mario pipe or button gate.
    return false;
  }
  return Object.freeze({give,winDefense,beginDeparture,openExit,tryExit});
}
