import {nativeArenaWidth} from '../../engine/viewport.mjs';
import {overlap} from '../../engine/geometry.mjs';

/** The defense board, its actors and the right HUD rail share this extent. */
export function tankDefenseLayout(width=256){
  width=nativeArenaWidth(width);
  return {width,offset:(width-256)/2,playfield:{l:24,r:width-24,t:24,b:232},
    base:{x:width/2-8,y:216,w:16,h:16},spawnX:[24,width/2-4,width-36],respawnX:width/2-38};
}

/** Resize live native state once, preserving damage, clocks and reward facts.
 * Extra lanes use the same 8px bricks, not stretched copies of the old board.
 * Hidden side-lane destruction is retained when temporarily returning to 4:3.
 */
export function syncTankDefenseArena(s,viewportWidth){
  const room=s.scene,c=s.challenge;
  if(room?.area!=='defense'||!c?.base)return false;
  const next=tankDefenseLayout(viewportWidth),old=c.arenaWidth??256;
  room.def={...room.def,width:next.width};room.playfield={...next.playfield};
  if(old===next.width){c.arenaWidth=next.width;return false;}
  const delta=(next.width-old)/2,dead=new Set(c.wideDamage||[]);
  for(const b of c.blocks)if(b.arenaSide&&b.dead)dead.add(b.arenaSide);
  c.wideDamage=[...dead];c.blocks=c.blocks.filter(b=>!b.arenaSide);
  for(const b of c.blocks)b.x+=delta;
  if(next.width>256){
    for(const [side,x] of [['left',56],['right',next.width-64]])for(const y of [64,72,80,88,152,160,168,176]){
      const key=side+':'+y;c.blocks.push({x,y,w:8,h:8,type:'brick',dead:dead.has(key),arenaSide:key});
    }
  }
  c.base.x+=delta;c.arenaWidth=next.width;
  const shifted=new Set(),shift=q=>{if(q&&Number.isFinite(q.x)&&!shifted.has(q)){q.x+=delta;shifted.add(q);}};
  shift(s.player);
  for(const list of [s.actor.foes,s.actor.drops,s.actor.lanterns,s.actor.projectiles,s.actor.fx,s.effects,s.defeatEffects,s.particles,s.floaters,s.pipes])for(const q of list||[])shift(q);
  shift(c.exitPipe);
  const field=next.playfield,solids=c.blocks.filter(b=>!b.dead).concat(c.base),placed=[];
  const free=b=>b.x>=field.l&&b.x+b.w<=field.r&&b.y>=field.t&&b.y+b.h<=field.b&&!solids.some(q=>overlap(b,q))&&!placed.some(q=>overlap(b,q));
  for(const body of [s.player,...s.actor.foes.filter(e=>!e.dead),...s.actor.drops]){
    const origin={...body,x:Math.max(field.l,Math.min(field.r-body.w,body.x)),y:Math.max(field.t,Math.min(field.b-body.h,body.y))};
    let chosen=free(origin)?origin:null;
    for(let radius=2;radius<=next.width+240&&!chosen;radius+=2)for(let dx=-radius;dx<=radius&&!chosen;dx+=2){
      const dy=radius-Math.abs(dx);
      for(const sign of dy?[1,-1]:[1]){const q={...origin,x:origin.x+dx,y:origin.y+dy*sign};if(free(q)){chosen=q;break;}}
    }
    if(chosen){body.x=chosen.x;body.y=chosen.y;}placed.push(body);
  }
  s.actor.projectiles=s.actor.projectiles.filter(q=>q.x>=field.l&&q.x+q.w<=field.r&&q.y>=field.t&&q.y+q.h<=field.b);
  return true;
}
