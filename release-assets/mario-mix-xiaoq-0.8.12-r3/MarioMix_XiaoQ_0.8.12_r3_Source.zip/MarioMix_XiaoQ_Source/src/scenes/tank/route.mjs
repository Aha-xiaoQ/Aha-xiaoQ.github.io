import {createTankMotion} from '../../characters/tank/motion.mjs';
import {createTankRewards} from './rewards.mjs';
import {overlap} from '../../engine/geometry.mjs';
import {CHALLENGE_TUNING} from '../../content/challenge-tuning.mjs';
import {tankDefenseLayout,syncTankDefenseArena} from './arena.mjs';
const BALANCE=CHALLENGE_TUNING.tank;
/** Tank route owner. Legacy world queries and art enter only through named ports.
 * No DOM, global variables, Canvas resizing or independent timers in simulation.
 */
export function createTankRoute({state:s,input,simulation:p,geometry,rewardPorts,audio,render,viewport,canvas,ctx}) {
  const motion=createTankMotion({state:s,geometry,actions:{shoot:p.shoot,commonPlayer:p.commonPlayer,event:p.event}});
  const rewards=createTankRewards({state:s,viewport,motion,ports:{...rewardPorts,event:p.event,clearCommands:input.clearCommands,travel}});
  let current=null,generation=0,steps=0,frames=0;
  function syncArena(){return syncTankDefenseArena(s,viewport.view().width);}
  function synchronize(){syncArena();if(current!==s.scene){current=s.scene;generation++;}}
  function leave(){if(!current)return;current=null;generation++;input.releaseSnapshot();}
  function travel(target,spawn=null,kind='pipe'){
    const room=s.scene;if(!room||room.transition||s.mode!=='playing')return false;
    if(target==='alley'){target='bar';kind='region';}
    if(target==='bonus'){target='defense';spawn=null;}
    p.saveGeometry();const actor=s.player,side=room.def.sidePipe;
    const horizontal=side&&Math.abs(actor.x+actor.w-side.x*2)<7;
    s.transit={kind,from:room.area,target,x:actor.x,y:actor.y,dx:kind==='pipe'&&horizontal?1:0,dy:kind==='pipe'&&!horizontal?1:0};
    room.transition=42;room.target=target;room.transitionSpawn=spawn;input.clearCommands();
    if(kind==='pipe')audio.oneShot('pipe');
    p.event(kind==='pipe'?'pipe':'region-transition',{target});return true;
  }
  function tickTally(value){
    const room=s.scene,t=s.challenge.tally08;t.clock++;s.frame++;room.ticks++;
    if(s.challenge.departure)s.challenge.departure.age=t.clock;
    if(room.shake>0)room.shake--;p.updateParticles();
    for(const f of s.actor.fx){f.x+=f.vx;f.y+=f.vy;f.life--;}
    s.actor.fx=s.actor.fx.filter(f=>f.life>0);s.player.vx=s.player.vy=0;
    if(!value.run&&!value.jump)t.releaseSeen=true;
    const skip=t.clock>60&&t.releaseSeen&&(value.runPressed||value.jumpPressed);
    for(let i=0;i<4;i++){
      const row=t.rows[i],elapsed=t.clock-30-i*54;
      const shown=skip?row.count:Math.max(0,Math.min(row.count,Math.floor(elapsed/16)));
      if(shown!==row.shown){row.shown=shown;row.shownPoints=row.count?Math.round(row.points*shown/row.count):0;row.flash=10;audio.tally();}
      if(row.flash>0)row.flash--;
    }
    if(t.clock>=246||skip){
      if(!t.totalShown){t.totalShown=true;t.totalFlash=18;audio.oneShot('tank_clear');}
      t.total=t.rows.reduce((n,r)=>n+r.count,0);t.points=t.rows.reduce((n,r)=>n+r.points,0);
    }
    if(t.totalFlash>0)t.totalFlash--;
    // Button presses may reveal the numbers early, but never truncate the
    // 330-tick result or its original result recording.
    if(t.clock>=t.duration&&(audio.resultDone?.()??true)){
      t.active=false;for(const row of t.rows){row.shown=row.count;row.shownPoints=row.points;}
      rewards.openExit();p.event('defense-tally-end',{skipped:skip,scoreUnchanged:s.score===t.scoreAtWin});
    }
  }
  function defense(value){
    syncArena();
    if(s.challenge?.tally08?.active)return tickTally(value);
    const c=s.challenge,room=s.scene,t=room.tank,n=s.actor;c.clock++;s.frame++;room.ticks++;
    if(room.messageTime)room.messageTime--;if(room.shake>0)room.shake--;
    if(c.failed)return;
    if(c.baseDestroyed){
      s.player.vx=s.player.vy=0;
      if(++c.baseDestroyed.age>=BALANCE.baseExplosionTicks){c.failed=true;s.mode='gameover';audio.gameOver();}
      return;
    }
    if(c.won){s.player.vx=s.player.vy=0;rewards.openExit();p.updateParticles();return;}
    if(c.spawned<c.total&&n.foes.filter(e=>!e.dead).length<BALANCE.concurrent&&c.spawnClock--<=0){
      const x=tankDefenseLayout(c.arenaWidth).spawnX[c.spawned%3],spawn={x,y:24,w:12,h:12};
      if(!overlap(spawn,s.player)&&!n.foes.some(e=>!e.dead&&overlap(spawn,e))){
        n.foes.push({kind:'tank',tankKind:BALANCE.fastEnemies.includes(c.spawned)?'fast':'basic',bonus:BALANCE.carriers.includes(c.spawned),bonusSpent:false,id:700+c.spawned,x,y:24,w:12,h:12,dir:1,t:0,cool:100,hp:1,maxHp:1,dead:false,spawn:BALANCE.spawnGrace,turn:0});c.spawned++;c.spawnClock=BALANCE.spawnInterval;
      }
    }
    motion.stepPlayer(value);
    for(const d of n.drops)if(!d.gone&&!d.emerge&&overlap(s.player,d)){rewards.give(d.type);d.gone=true;}
    n.drops=n.drops.filter(d=>!d.gone);
    if(!t.freeze)for(const e of n.foes){
      if(e.dead)continue;if(e.spawn){e.spawn--;continue;}e.t++;if(e.cool)e.cool--;if(e.flash)e.flash--;
      if(e.t%70===1)e.dir=e.y>190?(e.x<c.base.x-6?0:e.x>c.base.x+18?2:1):e.t%210<140?1:((e.id%2)?0:2);
      if(!motion.move(e,e.dir,e.tankKind==='fast'?1:.55)&&e.t%40===0)e.dir=(e.dir+1)%4;
      if(!e.cool){p.shoot(e,false);e.cool=100;}
    }
    p.projectiles(true);c.kills=n.foes.filter(e=>e.dead).length;p.updateParticles();
    for(const f of n.fx){f.x+=f.vx;f.y+=f.vy;f.life--;}
    n.fx=n.fx.filter(f=>f.life>0);
    if(s.mode==='playing'&&c.spawned===c.total&&c.kills===c.total&&!c.failed)rewards.winDefense();
  }
  function core(){
    const room=s.scene;
    if(room.area==='defense'&&s.mode==='playing'&&!room.transition){defense(input.read());audio.sync();return;}
    input.pollPad();if(!s.scene)return;
    if(['menu','paused','win','gameover'].includes(s.mode)){audio.sync();return;}
    s.frame++;room.ticks++;if(room.messageTime)room.messageTime--;if(room.shake)room.shake--;
    if(s.mode==='dying'){
      s.deathTick++;if(s.deathTick>=90){if(s.lives>0)p.resetLife();else{s.mode='gameover';p.gameOver(false);}}
      audio.sync();return;
    }
    if(room.transition){
      room.transition--;
      if(room.target==='handoff'){if(room.transition===0)p.handoff();}
      else if(room.transition===21){const target=room.target,spawn=room.transitionSpawn;p.load(target,true,spawn);s.scene.transition=20;s.scene.target=null;}
      audio.sync();return;
    }
    p.updateLifts();motion.stepPlayer(input.read());
    if(s.mode==='playing'&&!s.scene.transition){p.enemies();p.combat();if(++s.timerTicks>=60){s.timerTicks=0;if(--s.timeLeft<=0)p.die();}}
    audio.sync();
  }
  function withInput(){
    if(s.scene.area==='defense')input.pollPad();
    const sample=input.sample();
    if(s.mode!=='playing'||s.scene.transition){sample.jumpPressed=false;sample.runPressed=false;sample.specialPressed=false;sample.cyclePressed=false;}
    input.beginSnapshot(sample);const seen={...sample};try{core();}finally{input.endSnapshot(seen);}
  }
  function progression(){
    const room=s.scene;
    if(s.mode==='flag'){p.finishTick();return;}
    if(s.mode==='playing'&&!room.transition&&room.spawnFrames>0){
      room.spawnFrames--;s.frame++;
      if(room.spawnFromY!==undefined)s.player.y=room.spawnToY+(room.spawnFromY-room.spawnToY)*room.spawnFrames/26;
      if(!room.spawnFrames){s.player.vy=0;input.clearCommands();}audio.sync();return;
    }
    const before=s.frame;withInput();
    if(s.scene&&s.frame!==before){
      if(s.scene.pipeCooldown>0)s.scene.pipeCooldown--;if(s.scene.rankFlash>0)s.scene.rankFlash--;
      if(s.mode==='playing'&&!s.scene.transition)for(const d of s.actor.drops)if(d.emerge>0){d.emerge--;d.y=d.targetY+d.emerge*.5;}
    }
  }
  function presentationTick(){
    if(s.mode==='dying'&&s.death){
      s.frame++;s.scene.ticks++;s.deathTick++;p.tickEffects();
      if(s.deathTick>=80){if(s.lives>0)p.resetLife();else{s.mode='gameover';p.gameOver(true);audio.gameOver();}}
      audio.sync();return;
    }
    const before=s.frame;progression();if(!s.scene||!s.actor||s.frame===before)return;
    p.tickEffects();p.markEnemies();
    if(s.mode==='playing'&&!s.scene.transition){
      for(const d of s.actor.drops)if(d.fromCarrier&&d.ttl>0)d.ttl--;
      s.actor.drops=s.actor.drops.filter(d=>!d.fromCarrier||d.ttl>0);
      if(s.scene.tank.shovel>0&&!--s.scene.tank.shovel&&s.scene.area==='defense')for(const b of s.challenge.blocks)if(b.shovelGuard){b.type='brick';b.dead=false;b.shovelGuard=false;}
    }
  }
  function step(){
    if(!s.scene)return;synchronize();steps++;
    const isDefense=s.scene.area==='defense',oldShovel=isDefense?s.scene.tank.shovel:0,before=s.frame;
    if(s.scene.transition>21&&s.transit?.kind==='pipe'){
      const k=42-s.scene.transition;s.player.x=s.transit.x+s.transit.dx*k*1.15;s.player.y=s.transit.y+s.transit.dy*k*1.15;
    }
    presentationTick();if(s.frame!==before)p.tickDefeat();
    if(isDefense&&s.scene?.area==='defense'&&oldShovel>0&&!s.scene.tank.shovel)motion.clearFortifications();
    synchronize();
  }
  function draw(){
    if(!s.scene)return;synchronize();frames++;viewport.prepare(canvas,ctx);
    render.base();
    const room=s.scene,offset=['defense','bar'].includes(room.area)?viewport.centeredOffset(room.def.width):0;
    if(room.area!=='defense')viewport.withWorld(ctx,{top:48,bottom:208},()=>{
      for(const patch of s.terrain)if(patch.kind==='grass')for(let x=patch.x;x<patch.x+patch.w;x+=16)for(let y=patch.y;y<patch.y+patch.h;y+=16)if(!render.tileAt(x/16,y/16))render.tile('grass',x-s.camera,y);
    });
    render.audioPanel();
    viewport.withWorld(ctx,{top:room.area==='defense'?24:31,bottom:232,offsetX:offset,shakeX:room.shake?((s.frame%2)*2-1):0},()=>{
      const im=render.images['tank-explosion06'];if(im)for(const e of s.effects){
        if(e.area!==room.area)continue;
        const seq=[0,1,2,3,2,1],i=seq[Math.min(5,Math.floor(e.age*6/e.life))],sz=e.big?40:20;
        ctx.drawImage(im,i*64,0,64,64,Math.round(e.x-s.camera-sz/2),Math.round(e.y-room.camY-sz/2),sz,sz);
      }
    });
    render.audioPanel();
    viewport.withWorld(ctx,{top:room.area==='defense'?24:31,bottom:room.area==='defense'?232:228,offsetX:offset},()=>{
      for(const f of s.defeatEffects){
        if(f.age<0)continue;const x=f.x-s.camera,y=f.y-room.camY;
        if(f.kind==='mario'){const im=render.classicSprite(f.sprite,f.under?'under':'normal');render.sprite(f.sprite,x-im.width/2,y-im.height/2,false,true,f.under?'under':'normal');}
        else{const im=render.images['ng-explosion07'];if(im)ctx.drawImage(im,Math.min(2,Math.floor(f.age/6))*48,0,48,48,Math.round(x-16),Math.round(y-16),32,32);}
      }
    });
    drawTally();
  }
  function drawTally(){
    const t=s.challenge?.tally08;if(s.scene?.area!=='defense'||!t?.active)return;
    viewport.withPanel(canvas,ctx,()=>{
      const {rect,text,tank}=render;
      rect(36,31,188,188,'#000');rect(38,33,184,1,'#8d8061');rect(38,217,184,1,'#8d8061');
      text('STAGE 01 CLEAR',128,43,'#f6d589',.9,true);text('I-PLAYER',53,64,'#f27b68',.8);
      text(String(t.scoreAtWin).padStart(6,'0'),164,64,'#f5e7a3',.8,false);
      const labels=['BASIC','FAST','POWER','ARMOR'];
      for(let i=0;i<4;i++){
        const r=t.rows[i],y=88+i*24,e={tankKind:r.type,hp:1,bonus:false,r06Track:0};tank(ctx,51,y+1,3,true,0,r.type==='armor',e);
        const col=r.flash>0?(r.flash>5?'#fff8d5':'#f4c862'):'#e8e8dc';text(labels[i],74,y+1,'#9d9e98',.62);
        if(t.clock>=30+i*54){text(String(r.shown).padStart(2,'0'),120,y+1,col,.85);text(String(r.shownPoints).padStart(4,'0'),151,y+1,col,.85);}
      }
      rect(50,187,156,1,'#b7ac8b');text('TOTAL',52,198,'#ede7d4',.8);
      if(t.totalShown){text(String(t.total).padStart(2,'0'),120,198,t.totalFlash>9?'#fff8d5':'#f3cd6d',.85);text(String(t.points).padStart(4,'0'),151,198,'#f3cd6d',.85);}
    });
  }
  return Object.freeze({step,render:draw,travel,stepDefense:defense,tickTally,drawTally,leave,syncArena,
    move:motion.move,collides:motion.collides,player:motion.stepPlayer,clearFortifications:motion.clearFortifications,
    give:rewards.give,winDefense:rewards.winDefense,beginDeparture:rewards.beginDeparture,openDefenseExit:rewards.openExit,defenseExit:rewards.tryExit,
    view:()=>({route:'tank-world-1-2',area:current?.area??null,generation,steps,frames,mode:s.mode})});
}
