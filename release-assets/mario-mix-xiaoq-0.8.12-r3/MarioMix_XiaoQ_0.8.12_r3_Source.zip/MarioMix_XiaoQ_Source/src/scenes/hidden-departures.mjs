/** Scene-owned exit lifecycle. Legacy optical presentations are projections;
 * target approaches delegate the real body to its installed movement port.
 * Neither path owns equipment, rewards, lives or the destination scene. */
const durations=Object.freeze({teleport:84,run:96,helicopter:132,'light-gate':132});
function motionContract(motion){
 if(!motion||!['walk','drive'].includes(motion.kind)||![2,4,8].includes(motion.directions)||!Number.isFinite(motion.arrivalTolerance)||motion.arrivalTolerance<=0||motion.arrivalTolerance>1||typeof motion.step!=='function')throw new TypeError('Invalid departure movement capability');
 return {kind:motion.kind,directions:motion.directions,arrivalTolerance:motion.arrivalTolerance};
}
export function beginHiddenDeparture(kind,body,{endX=0,landingX=256,landingY=188,motion=null}={}){
 if(!Object.hasOwn(durations,kind))throw new TypeError('Unknown departure presentation');
 const value={schema:'hidden-departure-v1',kind,age:0,origin:{x:body.x,y:body.y,w:body.w,h:body.h},endX,landingX,landingY};
 if(motion){if(kind!=='helicopter')throw new TypeError('This departure has no target approach');Object.assign(value,{schema:'hidden-departure-v2',phase:'approach',phaseAge:0,distance:0,approach:motionContract(motion)});}
 validateHiddenDeparture(value);return value;
}
export function validateHiddenDeparture(value){
 if(value?.schema==='hidden-departure-v2'){
  const a=value.approach;
  if(value.kind!=='helicopter'||!['approach','settle','board','takeoff','complete'].includes(value.phase)||!Number.isSafeInteger(value.age)||value.age<0||value.age>36000||!Number.isSafeInteger(value.phaseAge)||value.phaseAge<0||value.phaseAge>value.age||
   !['walk','drive'].includes(a?.kind)||![2,4,8].includes(a?.directions)||!Number.isFinite(a?.arrivalTolerance)||a.arrivalTolerance<=0||a.arrivalTolerance>1||!Number.isFinite(value.distance)||value.distance<0||value.distance>100000||
   ![value.origin?.x,value.origin?.y,value.origin?.w,value.origin?.h,value.endX,value.landingX,value.landingY].every(n=>Number.isFinite(n)&&Math.abs(n)<100000)||value.origin.w<=0||value.origin.h<=0||
   value.phase==='settle'&&value.phaseAge>=6||value.phase==='board'&&value.phaseAge>=28||value.phase==='takeoff'&&value.phaseAge>=72||value.phase==='complete'&&value.phaseAge!==72)throw new TypeError('Invalid controlled departure checkpoint');
  return true;
 }
 if(!value||value.schema!=='hidden-departure-v1'||!Object.hasOwn(durations,value.kind)||!Number.isSafeInteger(value.age)||value.age<0||value.age>durations[value.kind]||
  ![value.origin?.x,value.origin?.y,value.origin?.w,value.origin?.h,value.endX,value.landingX,value.landingY].every(n=>Number.isFinite(n)&&Math.abs(n)<100000)||value.origin.w<=0||value.origin.h<=0)throw new TypeError('Invalid departure checkpoint');
 return true;
}
export function stepHiddenDeparture(value,context=null){
 validateHiddenDeparture(value);
 if(value.schema==='hidden-departure-v2')return stepApproach(value,context);
 value.age=Math.min(durations[value.kind],value.age+1);return value.age===durations[value.kind];
}
function readBody(body){if(!body||!['x','y','w','h','vx','vy'].every(k=>Number.isFinite(body[k]))||body.w<=0||body.h<=0)throw new TypeError('Departure requires the live motion body');return body;}
function stepApproach(value,{body,motion,world}={}){
 readBody(body);const contract=motionContract(motion);
 if(Object.keys(contract).some(k=>contract[k]!==value.approach[k]))throw new TypeError('Departure movement capability changed');
 if(value.phase==='complete')return true;
 value.age=Math.min(36000,value.age+1);value.phaseAge=Math.min(36000,value.phaseAge+1);
 const target={x:value.landingX-body.w/2,y:value.landingY-body.h},near=()=>Math.abs(target.x-body.x)<=contract.arrivalTolerance&&Math.abs(target.y-body.y)<=contract.arrivalTolerance;
 let x=0,y=0;
 if(value.phase==='approach'){
  x=Math.abs(target.x-body.x)>contract.arrivalTolerance?Math.sign(target.x-body.x):0;
  y=Math.abs(target.y-body.y)>contract.arrivalTolerance?Math.sign(target.y-body.y):0;
  if(contract.directions===2)y=0;
  else if(contract.directions===4&&x&&y){if(Math.abs(target.x-body.x)>=Math.abs(target.y-body.y))y=0;else x=0;}
 }
 const prior={x:body.x,y:body.y},result=motion.step(body,{x,y},world);
 if(result&&typeof result.then==='function'){Promise.resolve(result).catch(()=>{});throw new TypeError('Departure movement must be synchronous');}
 readBody(body);const dx=body.x-prior.x,dy=body.y-prior.y;
 if(Math.abs(body.vx-dx)>1e-6||Math.abs(body.vy-dy)>1e-6)throw new TypeError('Departure velocity must describe actual motion');
 value.distance+=Math.hypot(dx,dy);
 const stopped=Math.abs(dx)+Math.abs(dy)<1e-6,next=phase=>{value.phase=phase;value.phaseAge=0;};
 if(value.phase==='approach'){if(near()&&stopped)next('settle');}
 else if(value.phase==='settle'){if(!near()||!stopped)next('approach');else if(value.phaseAge>=6)next('board');}
 else if(value.phase==='board'){if(!near()||!stopped)throw new Error('Boarding body left its arrival');if(value.phaseAge>=28)next('takeoff');}
 else if(value.phase==='takeoff'&&value.phaseAge>=72)value.phase='complete';
 return value.phase==='complete';
}
// Old saves contain only the optical track. Promote the position actually
// displayed at that age once, then continue with the installed controller.
export function migrateHiddenDeparture(value,body,motion){
 validateHiddenDeparture(value);if(value.schema==='hidden-departure-v2')return value;
 if(value.kind!=='helicopter')throw new TypeError('Cannot migrate another departure kind');
 const frame=hiddenDepartureFrame(value),next=beginHiddenDeparture(value.kind,body,{...value,motion});
 Object.assign(body,{x:frame.body.x,y:frame.body.y,vx:0,vy:0,grounded:true});
 next.origin={...value.origin};next.age=value.age;next.distance=frame.distance;
 if(value.age>=60){next.phase=value.age===132?'complete':'takeoff';next.phaseAge=value.age-60;}
 else if(value.age>=32){next.phase='board';next.phaseAge=value.age-32;}
 else next.phaseAge=value.age;
 validateHiddenDeparture(next);return next;
}
function departurePose(value){
 const {kind,age,origin:p}=value,body={...p},complete=age===durations[kind];
 if(kind==='teleport'){
  const launch=Math.max(0,age-36);
  return {kind,age,phase:age<24?'stand':age<36?'charge':'ascend',complete,body,bodyVisible:age<36,
   beam:age<24?null:{x:p.x+p.w/2,y:p.y+p.h-launch*8,width:age<36?Math.max(4,p.w*(36-age)/12):4,height:age<36?p.h:44}};
 }
 if(kind==='run'){
  const time=Math.max(0,age-12),distance=Math.max(32,value.endX-p.x),duration=durations.run-12;
  body.x=p.x+distance*Math.min(1,time/duration);body.facing=1;
  return {kind,age,phase:age<12?'ready':'run',complete,body,bodyVisible:true,animation:time*.75};
 }
 if(kind==='light-gate'){
  const walk=Math.min(1,age/108);body.x=p.x+(value.landingX-p.w/2-p.x)*walk;body.y=p.y+(value.landingY-p.h-p.y)*Math.min(1,age/12);
  return {kind,age,phase:age<108?'walk':'fade',complete,body,bodyVisible:age<132,alpha:age<108?1:Math.max(0,(132-age)/24),animation:age*.75};
 }
 const align=Math.min(1,age/32),t=align*align*(3-2*align),lift=Math.max(0,age-60);
 body.x=p.x+(value.landingX-p.w/2-p.x)*t;body.y=p.y+(value.landingY-p.h-p.y)*t;
 return {kind,age,phase:age<32?'approach':age<60?'board':'takeoff',complete,body,bodyVisible:age<48,
  helicopter:{x:value.landingX+Math.max(0,lift-18)*1.4,y:value.landingY-lift*3.6}};
}
export function hiddenDepartureFrame(value,body=null){
 validateHiddenDeparture(value);
 if(value.schema==='hidden-departure-v2'){
  const p={...readBody(body)},flight=['takeoff','complete'].includes(value.phase),lift=flight?value.phaseAge:0;
  return {kind:value.kind,age:value.age,phase:value.phase,phaseAge:value.phaseAge,complete:value.phase==='complete',body:p,
   bodyVisible:value.phase==='approach'||value.phase==='settle'||value.phase==='board'&&value.phaseAge<16,
   moving:Math.abs(p.vx)+Math.abs(p.vy)>1e-6,distance:value.distance,animation:value.distance/1.5,
   helicopter:{x:value.landingX+Math.max(0,lift-18)*1.4,y:value.landingY-lift*3.6}};
 }
 const frame=departurePose(value),prior=departurePose({...value,age:Math.max(0,value.age-1)}),p=frame.body;
 const vx=p.x-prior.body.x,vy=p.y-prior.body.y,moving=Math.abs(vx)+Math.abs(vy)>1e-6;
 const horizontal=Math.abs(p.x-value.origin.x),distance=frame.kind==='helicopter'?Math.hypot(p.x-value.origin.x,p.y-value.origin.y):horizontal;
 const direction=frame.kind==='run'?1:Math.sign(value.landingX-p.w/2-value.origin.x)||1;
 Object.assign(p,{vx,vy,facing:Math.abs(vx)>1e-6?Math.sign(vx):direction,grounded:Math.abs(vy)<1e-6});
 // Source walk cycles measure travel: Sonic's native clock is 0.09 frames/px;
 // Ori's presentation clock is divided by four by its final source renderer.
 return {...frame,moving,distance,animation:frame.kind==='run'?distance*.09:frame.kind==='light-gate'?distance*4/10.8:distance/1.5};
}
