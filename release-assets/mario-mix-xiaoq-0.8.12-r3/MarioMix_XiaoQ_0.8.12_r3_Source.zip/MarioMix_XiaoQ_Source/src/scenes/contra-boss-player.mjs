import {CONTRA_BOSS_PLAYER_SOURCE as S} from '../content/contra-boss-player-data.mjs';
const signed=n=>n<128?n:n-256;
const velocity=(table,i)=>[signed(table[i*4])*256+table[i*4+1],signed(table[i*4+2])*256+table[i*4+3]];
const anchor=p=>({x:p.x+8,y:p.y+24});
const pointIn=(point,origin,box)=>point.x>=origin.x+box[1]&&point.x<origin.x+box[1]+box[3]&&point.y>=origin.y+box[0]&&point.y<origin.y+box[0]+box[2];
function entityAnchor(e){return {x:e.x+e.w/2,y:e.type==='base1-eye'?64:['wall-plating','wall-cannon'].includes(e.type)?e.y+16:e.y+e.h/2};}
export function contraBossAim(raw,jumping=false){const bits=(raw.x>0?1:0)|(raw.x<0?2:0)|(raw.down?4:0)|(raw.up?8:0);return S.aim[(jumping?3:2)*16+bits];}
export function contraBossMuzzle(p,aim=contraBossAim({},!p.grounded)){const t=p.grounded?S.muzzleStanding:S.muzzleJump,i=aim*2,a=anchor(p);return {x:a.x+signed(t[i]),y:a.y+signed(t[i+1])};}
export function contraBossPlayerContact(p,e){
 if(['wall-plating','wall-cannon','base1-eye'].includes(e.type)||e.type==='fire-ring'&&e.h===14)return false;
 if(!['fire-ring','cannon-shot'].includes(e.type))return null;
 const jumping=!p.grounded,box=e.type==='fire-ring'?(jumping?[-22,-18,36,36]:[-29,-18,57,36]):(jumping?[-22,-8,30,16]:[-13,-8,36,16]);
 return pointIn(anchor(p),entityAnchor(e),box);
}
function initialState(){return {schema:'contra-boss-player-v1',prevJump:false,prevAttack:false,jumpDirection:0,jumpFacing:1,vy256:0,yFraction:0,animation:0,jumpAnimation:0,recoil:0,mTime:0,heldFireTicks:0,serial:0,aim:0,frame:'50',flipX:false,flipY:false,shots:Array(10).fill(null)};}
export function validateContraBossPlayer(p){
 const q=p.contraBoss,integer=(v,lo,hi)=>Number.isSafeInteger(v)&&v>=lo&&v<=hi,frames=new Set(['50','02','03','04','05','06','0d','0e','0f','10','11','12','13','14','15','08','09','55','56','91']);
 if(p.w!==16||p.h!==48||!Number.isFinite(p.x)||!Number.isFinite(p.y)||!q||q.schema!=='contra-boss-player-v1'||!frames.has(q.frame)||![-1,0,1].includes(q.jumpDirection)||![-1,1].includes(q.jumpFacing)||!integer(q.vy256,-1040,4096)||!integer(q.yFraction,0,255)||!integer(q.aim,0,11)||!integer(q.heldFireTicks??0,0,28)||!integer(q.mTime,0,255)||!integer(q.recoil,0,15)||!integer(q.serial,0,Number.MAX_SAFE_INTEGER)||!integer(q.animation,0,Number.MAX_SAFE_INTEGER)||!integer(q.jumpAnimation,0,Number.MAX_SAFE_INTEGER)||['prevJump','prevAttack','flipX','flipY'].some(k=>typeof q[k]!=='boolean')||!Array.isArray(q.shots)||q.shots.length!==10)throw new TypeError('Invalid Contra Boss player checkpoint');
 for(let i=0;i<10;i++){const b=q.shots[i];if(!b)continue;
  if(b.slot!==i||typeof b.id!=='string'||!b.id.startsWith('contra-boss-shot-')||!['N','M','F','S','L'].includes(b.weapon)||!integer(b.aim,0,11)||!['1e','1f','20','21','22','23','24','25','47'].includes(b.frame)||!integer(b.routine,0,2)||!integer(b.age,0,Number.MAX_SAFE_INTEGER)||!integer(b.delay,0,10)||!Number.isSafeInteger(b.x)||!Number.isSafeInteger(b.y)||!Number.isSafeInteger(b.vx256)||!Number.isSafeInteger(b.vy256)||!integer(b.xFraction,0,255)||!integer(b.yFraction,0,255)||b.routine===2&&!integer(b.timer,1,6)||b.weapon==='F'&&(!integer(b.phase,0,255)||!Number.isSafeInteger(b.cx)||!Number.isSafeInteger(b.cy)))throw new TypeError('Invalid Contra Boss bullet checkpoint');
 }
 return true;
}
function state(p){if(!p.contraBoss)p.contraBoss=initialState();if(p.contraBoss.schema!=='contra-boss-player-v1')throw new TypeError('Unknown Contra Boss player state');return p.contraBoss;}
function edge(raw,name,previous){return typeof raw[name+'Pressed']==='boolean'?raw[name+'Pressed']:!!raw[name]&&!previous;}
function moveFraction(q,key,v){const fk=key+'Fraction',n=(q[fk]||0)+(v&255);q[key]+=Math.floor(v/256)+(n>>>8);q[fk]=n&255;}
function stepShot(q,width=256){
 if(q.routine===2){if(--q.timer<=0)return null;return q;}
 if(q.routine===0){if(q.weapon!=='L'||--q.delay===0)q.routine=1;return q;}
 q.age++;
 if(q.weapon==='F'){
  moveFraction(q,'cx',q.vx256);moveFraction(q,'cy',q.vy256);
  q.x=q.cx+signed(S.flameSwirlX[q.phase&15]);q.y=q.cy+signed(S.flameSwirlY[q.phase&15]);q.phase=(q.phase+(q.aim>=5&&q.aim!==10?-1:1))&255;
 }else {moveFraction(q,'x',q.vx256);moveFraction(q,'y',q.vy256);}
 if(q.weapon==='S')q.frame=q.age>=32?'21':q.age>=16?'20':'1f';
 return q.x<5||q.x>=width-5||q.y<5||q.y>=232?null:q;
}
/** A scene-owned original source controller. The base actor retains equipment,
 * audio and pickup feedback; the Stage remains the only health/defeat owner.
 * The broad platform box only gates callbacks. Original point/expanded-box
 * tests below decide the actual front-view Boss contact plane. */
export function createContraBossPlayer({base,draw=()=>false,sound=()=>{}}){
 if(!base||base.id!=='bill')throw new TypeError('Contra Boss actor requires the installed Bill equipment port');
 let current=null;
 function create(character,spawn){const p=base.create(character,spawn);current=p;Object.assign(p,{x:spawn?.x??120,y:177,w:16,h:48,vx:0,vy:0,grounded:true,support:'floor',crouch:false,contraBoss:initialState()});return p;}
 function prepareRoom(w){base.prepareRoom?.(w);}
 function step(p,raw,w){current=p;const q=state(p),a=anchor(p);if(!Number.isFinite(a.x)||!Number.isFinite(a.y))throw new TypeError('Non-finite Contra Boss source anchor');
  // This controller replaces base.step, so it also owns the base body's hurt
  // flash countdown. The Stage separately owns protection and contact grace.
  if(p.invuln>0)p.invuln--;
  if(q.recoil>0)q.recoil--;
  const press=edge(raw,'jump',q.prevJump);q.prevJump=!!raw.jump;
  const launch=p.grounded&&press&&!(raw.down&&!raw.x);let dx=0,landed=false;
  if(launch){p.grounded=false;q.vy256=S.jumpVelocity256;q.jumpDirection=0;q.jumpFacing=q.aim>=5?-1:1;q.jumpAnimation=0;dx=p.vx||0;}
  else if(!p.grounded){
   // handle_jump tests the preceding frame's position before adding gravity.
   // Its byte coefficient survives landing and the next jump initialization.
   if(q.vy256>=0&&a.y>200){p.y=S.groundAnchorY-24;p.vy=0;p.grounded=true;q.vy256=0;landed=true;q.animation=0;}
   else{q.vy256+=S.gravity256;const total=q.yFraction+(q.vy256&255),dy=Math.floor(q.vy256/256)+(total>>>8);q.yFraction=total&255;p.y+=dy;p.vy=q.vy256/256;}
   if(raw.x)q.jumpDirection=Math.sign(raw.x);dx=q.jumpDirection;if(landed)q.jumpDirection=0;
  }else if(raw.x)dx=Math.sign(raw.x);
  if(!(dx>0&&a.x>=S.roomRight+((w.width||256)-256)||dx<0&&a.x<S.roomLeft))p.x+=dx;
  p.vx=dx;if(dx)p.facing=dx;
  q.aim=contraBossAim(raw,!p.grounded);p.crouch=false;p.support=p.grounded?'floor':null;
  if(!p.grounded){const i=Math.floor(q.jumpAnimation++/5)%4;q.frame=['08','09','08','09'][i];q.flipX=(q.jumpFacing<0)!==(i>=2);q.flipY=i>=2;}
  else if(!raw.x||landed){q.animation=0;q.frame='50';q.flipX=q.flipY=false;}
  else {const kind=[0,2,0,3,0,0,3,0,2,0][q.aim]||(q.recoil?1:0),frames=[['02','03','04','05','03','06'],['0d','0e','0f','0d','0e','0f'],['10','11','12','10','11','12'],['13','14','15','13','14','15']];q.frame=frames[kind][Math.floor(q.animation++/8)%6];q.flipX=dx<0;q.flipY=false;}
  p.nativePose=!p.grounded?'source-jump':dx?'source-walk':'source-front';return {native:true};
 }
 function spawn(p,q,weapon,slot,index=0){let aim=q.aim;if(!p.grounded&&(aim===4||aim===5))aim=11;
  const muzzle=contraBossMuzzle(p,aim);let v=velocity(weapon==='F'?(p.rapid?S.flameRapid:S.flame):(weapon==='L'||p.rapid?S.rapid:S.normal),aim);
  if(weapon==='S'){const k=(S.spreadAim[aim]+signed(S.spreadIndex[index]))&31,x=p.rapid?S.spreadRapidX:S.spreadX,y=p.rapid?S.spreadRapidY:S.spreadY;v=[signed(x[k*2+1])*256+x[k*2],signed(y[k*2+1])*256+y[k*2]];}
  const bullet={id:'contra-boss-shot-'+(++q.serial),slot,weapon,aim,x:muzzle.x,y:muzzle.y,xFraction:0,yFraction:0,vx256:v[0],vy256:v[1],routine:0,delay:weapon==='L'?[1,4,7,10][slot]:0,age:0,frame:weapon==='F'?'22':['M','S'].includes(weapon)?'1f':weapon==='L'?S.laserFrames[aim*2].toString(16):'1e',flip:S.laserFrames[aim*2+1]};
  if(weapon==='F'){const i=aim*3;bullet.phase=S.flameInit[i];bullet.cx=bullet.x+signed(S.flameInit[i+1]);bullet.cy=bullet.y+signed(S.flameInit[i+2]);}
  q.shots[slot]=bullet;q.recoil=15;
  if(p.grounded&&p.vx&&['02','03','04','05','06'].includes(q.frame))q.frame=['0d','0e','0f'][Math.floor(Math.max(0,q.animation-1)/8)%3];sound({kind:'player-shot',weapon,sourceCue:({N:10,M:12,F:16,S:18,L:14})[weapon]});
 }
 function fire(p,raw){const q=state(p),weapon=p.weapon||'N';if(!['N','M','F','S','L'].includes(weapon))throw new TypeError('Unknown Contra Boss weapon');
  const press=edge(raw,'attack',q.prevAttack);q.prevAttack=!!raw.attack;
  if(!raw.attack){q.heldFireTicks=0;q.mTime=Math.min(7,(q.mTime&15)+1);return;}
  q.heldFireTicks=Math.max(0,(q.heldFireTicks||0)-1);const repeat=press||q.heldFireTicks===0;
  let count=1,cap=weapon==='M'?6:weapon==='S'?10:4;
  if(weapon==='M'){q.mTime=(q.mTime+1)&255;if((q.mTime&15)<(q.mTime<96?8:15))return;const n=q.mTime+16;q.mTime=n>=112?0:n&240;}
  else if(weapon==='L'){if(!repeat)return;if(press)for(let i=0;i<4;i++)q.shots[i]=null;else if(q.shots.slice(0,4).some(Boolean))return;count=4;}
  else {if(!repeat)return;if(weapon==='S')count=5;}
  let made=0;for(let i=0;i<count;i++){const slot=q.shots.slice(0,cap).findIndex(b=>!b);if(slot<0)break;spawn(p,q,weapon,slot,i);made++;}
  if(made&&weapon!=='M')q.heldFireTicks=({N:12,S:17,F:24,L:28})[weapon];
  if(weapon==='M'&&!made)q.mTime=7;
 }
 function combat(p,raw,w){fire(p,raw);const q=state(p);for(let i=0;i<q.shots.length;i++)if(q.shots[i])q.shots[i]=stepShot(q.shots[i],w.width||256);return {native:true};}
 function resolveSourceShots(e,w,p=current){if(!p||e.dead||!['base1-eye','wall-plating','wall-cannon','fire-ring'].includes(e.type))return;
  if(e.type==='base1-eye'&&(e.ai!=='active'||w.enemies.some(z=>z.type==='wall-plating'&&!z.dead))||['wall-plating','wall-cannon'].includes(e.type)&&!e.vulnerable||e.type==='fire-ring'&&e.h===14)return;
  const q=state(p),box=e.type==='fire-ring'?[-17,-17,34,34]:[-11,-11,22,22];
  for(const b of q.shots){if(!b||b.routine!==1||!pointIn(b,entityAnchor(e),box))continue;
   if(w.damageEnemy(e,1,{id:b.id,kind:'contra-source-bullet',owner:'bill',weapon:b.weapon})===true){let impact=b;if(b.weapon==='L')for(let i=0;i<b.slot;i++){if(q.shots[i]?.routine===1){impact=q.shots[i];break;}}impact.routine=2;impact.frame='47';impact.timer=6;if(e.dead)break;}
  }
 }
 function departureStep(motion,exit){
  const p=current,q=state(p),before={x:p.x,y:p.y};q.shots.fill(null);p.grounded=true;q.flipY=false;
  if(motion.phase==='approach'){
   const dx=Math.sign(exit.x-p.x)*Math.min(Math.abs(exit.x-p.x),exit.speed);p.x+=dx;if(dx)p.facing=Math.sign(dx);
   motion.distance=(motion.distance??Math.max(0,motion.age-1)*exit.speed)+Math.abs(dx);
   q.frame=dx?['02','03','04','05','03','06'][Math.floor(motion.distance/8)%6]:'50';q.flipX=dx<0;
   p.nativePose=dx?'source-walk':'source-front';
   if(p.x===exit.x){motion.phase='ascend';motion.age=0;}
  }else {p.x=exit.x;p.y=Math.max(exit.endY,p.y-exit.speed);q.frame='91';q.flipX=false;p.nativePose='source-elevator';}
  p.vx=p.x-before.x;p.vy=p.y-before.y;
  return motion.phase==='ascend'&&p.y<=exit.endY;
 }
 return Object.freeze({...base,create,prepareRoom,step,combat,resolveSourceShots,departureStep,
  remapSceneX(p,mapX){for(const b of state(p).shots)if(b){b.x=Math.round(mapX(b.x,b));if(Number.isFinite(b.cx))b.cx=Math.round(mapX(b.cx,b));}},
  reconcileBody(p,w){validateContraBossPlayer(p);if(w&&state(p).frame!=='91')p.x=Math.max(S.roomLeft-8,Math.min(S.roomRight-8+(w.width||256)-256,p.x));},
  enemyContact(p,e,context,w){const hit=contraBossPlayerContact(p,e);return hit===null?(base.enemyContact?.(p,e,context,w)||false):!hit;},
  hurt(p,...args){const result=base.hurt(p,...args);p.vx=p.vy=0;state(p).vy256=0;return result;},
  // bank7 kill_player uses $fd80 even in the base Boss room; only its X
  // recoil is suppressed. bank2 selects the front-view $55/$56 death poses.
  beginDeath(p,w){base.beginDeath?.(p,w);const q=state(p);q.shots.fill(null);q.frame='55';q.flipX=q.flipY=false;q.vy256=-640;q.yFraction=0;p.vx=0;p.vy=-2.5;p.grounded=false;},
  deathStep(p,age){p.deathAge=age;const q=state(p);q.frame=age<27?'55':'56';if(!p.grounded){q.vy256+=S.gravity256;const n=q.yFraction+(q.vy256&255);p.y+=Math.floor(q.vy256/256)+(n>>>8);q.yFraction=n&255;p.vy=q.vy256/256;if(q.vy256>=512&&p.y>=S.groundAnchorY-24){p.y=S.groundAnchorY-24;p.grounded=true;p.vy=0;q.vy256=0;}}},
  drawPlayer(g,p,tick){const q=state(p),a=anchor(p);return {hero:'bill',pose:p.nativePose,frame:q.frame,asset:'a921',drawn:draw(g,{...a,frame:q.frame,flipX:q.flipX,flipY:q.flipY,recoil:q.recoil>=12},tick)!==false};},
  drawWorld(g,v){for(const b of state(current).shots)if(b&&!(b.weapon==='L'&&b.routine===0))draw(g,{x:b.x,y:b.y,frame:b.frame,flipX:!!(b.flip&64),flipY:!!(b.flip&128)},v.tick);},
  carry(p=current){return {...(base.carry?.(p)??base.snapshot?.()),weapon:p.weapon||'N'};},
  pause(...args){if(current){state(current).prevJump=state(current).prevAttack=false;}return base.pause?.(...args);},
  diagnostics(){return {...base.diagnostics?.(),contraBoss:current?structuredClone(state(current)):null};},
 });
}
