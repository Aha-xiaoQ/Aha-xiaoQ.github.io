import {platformChallengePlan,fixedArenaDefinition,projectArenaX} from '../content/platform-challenges.mjs';
import {nativeArenaWidth} from '../engine/viewport.mjs';
import {createPlatformStage} from '../campaign/stage.mjs';
import {createCharacterMotor} from '../campaign/character-motor.mjs';
import {copySceneCheckpoint,nativeSceneHealth} from '../engine/scene-state.mjs';
import {overlap} from '../engine/geometry.mjs';
import {beginHiddenDeparture,stepHiddenDeparture,hiddenDepartureFrame,validateHiddenDeparture} from './hidden-departures.mjs';

/** A challenge implements the same lifecycle as the preserved native rooms.
 * It borrows registered actors and the shared platform engine; no RAF, input
 * listener, campaign save or selected-character write belongs here. */
export function createPlatformChallenge({hero,character,rule,createActor,createEnemies,viewport,render,sound,definition,enemyDefinition,departureKind=null,deathPresentationTicks=0,debug=false}){
 const source=platformChallengePlan(hero,character,definition).def;
 let {def,plan}=platformChallengePlan(hero,character,source.fixed?fixedArenaDefinition(source,nativeArenaWidth(viewport())):source);
 let stage=null,actor=null,foes=null,baseline=null,cleared=false,exited=false,rewardSpawned=false,rewardClaimed=false,paused=false,bossSeen=false,bossDefeated=false,priorClaim=false,retiredBackgroundIds=[],exitMotion=null;
 const visualRooms=[{roomId:def.id,setting:'Native',map:{geometry:def.geometry},markers:[],semantics:[]}];
 let departure=null;
 const width=()=>def.fixed?def.width:viewport();
 function syncArena(savedWidth=null){
  if(!source.fixed||!stage)return;
  const nextWidth=nativeArenaWidth(viewport()),from=savedWidth??def.width;
  if(nextWidth===from&&nextWidth===def.width)return;
  const next=fixedArenaDefinition(source,nextWidth),mapX=x=>projectArenaX(x,from,nextWidth,source.layout);
  // Restored body fields use the saved width; unsaved actor arrays still use
  // the live room width. Repeated restore must not project those twice.
  const privateFrom=def.width,privateMapX=x=>projectArenaX(x,privateFrom,nextWidth,source.layout);
  stage.resizeNativeArena({width:nextWidth,geometry:next.geometry,objects:[{id:'entry',kind:'spawn',...next.spawn},...next.objects],mapX,privateMapX});def=next;
  if(departure){departure.origin.x=mapX(departure.origin.x);departure.endX=mapX(departure.endX);departure.landingX=mapX(departure.landingX);}
 }
 const events=[];
 // Only declared fixed entities may project a persistent damaged background.
 // The checkpoint stores their identity, never a second entity or copied position.
 function backgroundProjection(ids){
  if(!Array.isArray(ids)||ids.length>def.objects.length||new Set(ids).size!==ids.length)throw new TypeError('Invalid retired background identities');
  return ids.map(id=>{
   if(typeof id!=='string')throw new TypeError('Invalid retired background identity');
   const declaration=def.objects.find(e=>e.id===id),projection=declaration&&foes?.defeatBackground?.(declaration);
   if(!projection)throw new TypeError('Unknown retired background entity');
   return projection;
  });
 }
 function enter({carry,retry,rewardReceipt}){
  stage?.dispose();
  ({def,plan}=platformChallengePlan(hero,character,source.fixed?fixedArenaDefinition(source,nativeArenaWidth(viewport())):source));visualRooms[0].map.geometry=def.geometry;
  events.length=0;
  departure=null;exitMotion=null;retiredBackgroundIds=[];baseline=structuredClone(carry);cleared=exited=rewardSpawned=paused=bossSeen=bossDefeated=false;
  priorClaim=!!rewardReceipt?.claimed;rewardClaimed=priorClaim;
  if(retry&&baseline.native?.nativeVitals)baseline.native.nativeVitals=nativeSceneHealth(rule,baseline.native.nativeVitals,{retry:true});
  actor=createActor(hero);foes=createEnemies(hero);
  if(def.exit.sequence&&typeof actor.departureStep!=='function')throw new TypeError('Scene exit sequence requires an actor presentation port');
  stage=createPlatformStage({plan,motor:createCharacterMotor(),actorPort:actor,enemyPort:foes,...(enemyDefinition?{enemyDefinition}:{}),visualRooms,initialState:{...baseline,hero},sceneHealth:rule,backtracking:true,manualDeath:true,lifeOwner:'campaign',debug,viewportWidth:width(),
   emit:(type,data)=>{
    if(type==='sound')sound(actor,data.event);
    if(type==='enemy-defeated'){
     // Only the shared combat owner's accepted terminal event reaches the host.
     if(events.length>=128)throw new RangeError('Native scene event queue overflow');
     events.push({...data,type,sceneId:def.id,boss:def.goal==='boss'&&data.entityId===def.bossId&&bossSeen});
     const declaration=def.objects.find(e=>e.id===data.entityId);
     if(declaration&&foes.defeatBackground?.(declaration)&&!retiredBackgroundIds.includes(data.entityId))retiredBackgroundIds.push(data.entityId);
    }
    if(type==='enemy-defeated'&&def.goal==='boss'&&data.entityId===def.bossId&&bossSeen)bossDefeated=true;
    if(type==='item-collected'&&rewardSpawned&&data.entityId===def.reward.id)rewardClaimed=true;
   }});
  bossSeen=def.goal==='boss'&&stage.view().enemies.some(e=>e.id===def.bossId&&!e.dead);
  actor.audio(true);return true;
 }
 function step(input){
  syncArena();
  if(paused||exited)return;
  if(departure){exited=stepHiddenDeparture(departure);return;}
  if(exitMotion){exitMotion.age++;exited=actor.departureStep(exitMotion,def.exit)===true;return;}
  stage.setViewportWidth(width());stage.step({...input,x:input.x??Number(input.right)-Number(input.left)});
  let v=stage.view();if(v.p.dying)return;
  if(def.goal==='boss'&&v.enemies.some(e=>e.id===def.bossId&&!e.dead))bossSeen=true;
  const complete=def.goal==='boss'?bossSeen&&bossDefeated:def.goal==='enemies'?!v.enemies.some(e=>!e.dead&&e.kind!=='enemy-death'):v.p.x>=def.reward.x-90;
  if(complete&&!rewardSpawned&&!priorClaim){stage.spawnReward({...def.reward,kind:'native-supply'});rewardSpawned=true;}
  cleared=complete&&rewardClaimed;
  if(cleared&&!departureKind&&!def.exit.sequence&&overlap(v.p,def.exit)&&(!def.exit.action||input[def.exit.action]))exited=true;
 }
 function beginDeparture(){
  if(departure||exitMotion||exited)return true;
  if(!stage||paused||!cleared)return false;
  const v=stage.view();if(v.p.dying)return false;
  if(def.exit.sequence){exitMotion={phase:'approach',age:0,distance:0};return true;}
  if(!departureKind||v.items.some(e=>e.kind==='original-boss-explosion'))return false;
  departure=beginHiddenDeparture(departureKind,v.p);return true;
 }
 function view(){syncArena();const v=stage?.view();if(!v)return {};return {hero,id:def.id,title:def.title,mode:paused?'paused':'playing',area:def.id,cleared,exited,exitReady:cleared,failed:!!v.p.dying&&v.deathAge>=deathPresentationTicks,defeating:!!v.p.dying,deathPresentationComplete:!!v.p.dying&&deathPresentationTicks>0&&v.deathAge>=deathPresentationTicks,
   logicalWidth:width(),logicalHeight:240,healthMode:rule.health,hp:v.health,maxHp:rule.initialHealth||1,
   carry:{score:v.score,coins:v.coins,lives:v.lives},nativeCarry:v.native,protection:v.p.protection||0,
   nativeReward:rewardClaimed?{kind:'native-equipment',id:def.reward.nativeType}:null,rewardClaimed,bossSeen,bossDefeated,rewardReady:rewardSpawned&&!rewardClaimed,
   progress:{x:v.p.x,y:v.p.y,tick:v.tick,remainingEnemies:v.enemies.filter(e=>!e.dead).length,remainingCoins:v.objects.filter(o=>o.kind==='coin').length},
   body:v.p,departure:departure?hiddenDepartureFrame(departure):null,exitMotion:exitMotion?{...exitMotion}:null,retiredBackgroundIds:[...retiredBackgroundIds]};}
 function snapshotScene(){return {schema:'native-platform-scene-v2',id:def.id,arenaWidth:width(),departure:departure?structuredClone(departure):null,exitMotion:exitMotion?{...exitMotion}:null,cleared,exited,rewardSpawned,rewardClaimed,bossSeen,bossDefeated,priorClaim,retiredBackgroundIds:[...retiredBackgroundIds],stage:stage.checkpointScene()};}
 function restoreScene(data){
  const d=copySceneCheckpoint(hero,{version:1,hero,data}).data;
  const savedWidth=d.arenaWidth??source.width;
  if(source.fixed&&(!Number.isFinite(savedWidth)||savedWidth<256||savedWidth>1024||savedWidth%16!==0))throw new TypeError('Invalid saved arena width');
  if(!['native-platform-scene-v1','native-platform-scene-v2'].includes(d.schema)||d.id!==def.id||['cleared','exited','rewardSpawned','rewardClaimed'].some(k=>typeof d[k]!=='boolean')||d.cleared&&!d.rewardClaimed||d.rewardClaimed&&!d.rewardSpawned&&!d.priorClaim||d.exited&&!d.cleared)throw new TypeError('Invalid native challenge state');
  if(def.goal==='boss'&&(d.schema!=='native-platform-scene-v2'||['bossSeen','bossDefeated','priorClaim'].some(k=>typeof d[k]!=='boolean')||d.bossDefeated&&!d.bossSeen||d.cleared&&!d.bossDefeated))throw new TypeError('Invalid Boss completion state');
  // Older scenes may retain a just-defeated entity before retirement; only
  // that explicit dead record is recoverable. Absence never proves defeat.
  const nextIds=d.retiredBackgroundIds===undefined?(d.stage.enemies||[]).filter(e=>e.dead===true&&def.objects.some(q=>q.id===e.id&&foes.defeatBackground?.(q))).map(e=>e.id):d.retiredBackgroundIds;
  backgroundProjection(nextIds);
  if(d.stage.enemies?.some(e=>e.dead!==true&&nextIds.includes(e.id)))throw new TypeError('Retired background conflicts with live entity');
  if(d.exitMotion!=null&&(!def.exit.sequence||!d.cleared||!['approach','ascend'].includes(d.exitMotion.phase)||!Number.isSafeInteger(d.exitMotion.age)||d.exitMotion.age<0||d.exitMotion.age>4096||d.exitMotion.distance!==undefined&&(!Number.isFinite(d.exitMotion.distance)||d.exitMotion.distance<0||d.exitMotion.distance>65536)))throw new TypeError('Invalid scene departure');
  if(d.departure!=null){validateHiddenDeparture(d.departure);if(!d.cleared||d.departure.kind!==departureKind||d.exited!==hiddenDepartureFrame(d.departure).complete)throw new TypeError('Invalid scene departure owner');}
  stage.restoreScene(d.stage);departure=d.departure?structuredClone(d.departure):null;exitMotion=d.exitMotion?{...d.exitMotion}:null;retiredBackgroundIds=[...nextIds];({cleared,exited,rewardSpawned,rewardClaimed}=d);bossSeen=!!d.bossSeen;bossDefeated=!!d.bossDefeated;priorClaim=!!d.priorClaim;
  if(source.fixed)syncArena(savedWidth);
  events.length=0;
 }
 function migrateCheckpoint(checkpoint){
  const current=copySceneCheckpoint(hero,checkpoint),d=current.data;
  if(hero==='megaman'&&d.schema==='native-platform-scene-v1'&&d.id==='mega-machine-room')return null;
  if(hero==='megaman'&&d.id==='mega-cutman-room'&&!d.stage?.body?.superArm&&d.stage?.geometry?.some(q=>q.id==='step'&&q.w===80))return null;
  if(!['native-platform-scene-v1','native-platform-scene-v2'].includes(d.schema)||d.id!==def.id)throw new TypeError('Unknown native platform checkpoint');
  return current;
 }
 return {chapter:hero==='megaman'?11:14,rules:rule,migrateCheckpoint,enter,step,view,beginDeparture,snapshotScene,restoreScene,grantCompletionBonus:award=>stage.grantCompletionBonus(award),
  drainEvents:()=>events.splice(0),
  ...(debug?{diagnostics:()=>({state:stage.view(),...stage.diagnostics})}:{}),
  draw(){syncArena();render({def,view:stage.view(),stage,actor,foes,background:backgroundProjection(retiredBackgroundIds),cleared,departure:departure?hiddenDepartureFrame(departure):null,departing:!!exitMotion||!!departure,width:width()});},
  audio(){const phase=paused?'paused':exited?'exit':stage?.view().p.dying?'dying':'playing';actor?.audio(!paused&&!exited,phase);},pause(){paused=true;stage.pause();},resume(){paused=false;stage.resume();},
  leave(){events.length=0;stage?.dispose();stage=null;actor=null;foes=null;},
 };
}
