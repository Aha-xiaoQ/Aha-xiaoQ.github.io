// NES-US original source: Bank6 515-516, 718-720, 7628-7810 and
// Bank7 7156-7197, 7249-7364, 7425-7525. See the portable source receipt.
const frozen=v=>Object.freeze(v);
export const JACKAL_PROJECTILE_TABLES=frozen({
 speed:frozen([0x20,0x22,0x31,0x30,0x31,0x20,0x31,0x31,0x40,0x31,0x40,0x41,0x20,0x21,0x20,0x21]),
 invisible:frozen([8,16,12,12,6,8,6,0,8,8,4,0,0,0,0,0]),
 lifetime:frozen([48,96,64,64,96,64,136,80,64,48,24,36,96,96,96,96]),
 palette:frozen([2,2,3,2,2,2,3,2,2,2,2,3,2,3,2,3]),
 additionalLifetime:frozen([0,8,16,24,32,40]),
 sentryDelay:frozen([128,112,96,80,64,48]),
 infantryFlash:frozen([8,8,16,9,24,17]),
 mobileNoShoot:frozen([80,64,48,32,16,0]),
 cosine:frozen([128,125,118,106,90,71,48,24,0,24,48,71,90,106,118,125]),
 angle:frozen([0x40,0,0,0,0x84,0x22,0x11,0x11,0x86,0x43,0x22,0x21,0x86,0x54,0x33,0x22,0x87,0x65,0x43,0x33,0x87,0x65,0x54,0x43,0x87,0x66,0x54,0x44,0x87,0x76,0x55,0x44]),
 muzzleX:frozen([20,12,0,-12,-20,-12,0,12]),
 muzzleY:frozen([0,12,20,12,0,-12,-20,-12]),
});
// Gameplay object IDs, NOT presentation indices. No source-ID fallback.
export const JACKAL_SHOOTERS=frozen({1:0,2:5,5:12,6:13,7:1,8:1,10:2});
// Exact RGB conversion used to capture the installed OAM PNGs (portable
// rom_extract/render_png.py NES_PALETTE); these are not newly chosen colors.
export const JACKAL_SPRITE_RGB=frozen(Object.fromEntries(Object.entries({0:[84,84,84],6:[84,4,0],15:[0,0,0],17:[8,76,196],23:[120,60,0],26:[8,124,0],32:[236,238,236],40:[160,170,0]}).map(([k,v])=>[k,frozen(v)])));
const finite=(...v)=>{if(!v.every(Number.isFinite))throw new TypeError('Invalid Jackal source coordinates');};
export function jackalDifficulty(currentLevel=0,weaponTier=0){
 if(!Number.isInteger(currentLevel)||currentLevel<0||currentLevel>5||!Number.isInteger(weaponTier)||weaponTier<0||weaponTier>3)throw new TypeError('Invalid Jackal source difficulty');
 return (currentLevel+weaponTier)>>1;
}
export function jackalSourceDirection(dx,dy){
 finite(dx,dy);let x=Math.abs(Math.round(dx*256)),y=Math.abs(Math.round(dy*256));
 if(x>0x7fffff||y>0x7fffff)throw new TypeError('Jackal direction exceeds source 24-bit range');
 while(x>=7*256||y>=7*256){x=Math.floor(x/2);y=Math.floor(y/2);}
 // Original Bank7:7329 deliberately reuses X's fractional byte for Y.
 const round=(x&128)?1:0,index=((y>>8)+round)*8+(x>>8)+round;
 const packed=JACKAL_PROJECTILE_TABLES.angle[index>>1];let d=index&1?packed&15:packed>>4;
 if(dy<0)d=-d;if(dx<0)d=16-d;return d&31;
}
export function jackalSourceVelocity(direction,speedByte){
 if(!Number.isInteger(direction)||direction<0||direction>31||!Number.isInteger(speedByte)||speedByte<0||speedByte>255)throw new TypeError('Invalid Jackal source velocity');
 const c=JACKAL_PROJECTILE_TABLES.cosine;
 const multiply=n=>n*(speedByte>>4)+((speedByte&15)?Math.floor(n/2**(speedByte&15)):0);
 const x=c[direction&15]*(direction>=8&&direction<24?-1:1),y=c[(direction+8)&15]*(direction>=16?-1:1);
 return frozen({vx:multiply(x)/256||0,vy:multiply(y)/256||0});
}
export function jackalHeadingDirection(heading){
 if(!Number.isInteger(heading)||heading<1||heading>8)throw new TypeError('Invalid Jackal source heading');
 return ((heading+5)&7)*4;
}
export function jackalSourceDistance(a,b){
 finite(a.x,a.y,a.w,a.h,b.x,b.y,b.w,b.h);
 return Math.min(255,Math.abs(Math.floor(a.x+a.w/2)-Math.floor(b.x+b.w/2))+Math.abs(Math.floor(a.y+a.h/2)-Math.floor(b.y+b.h/2)));
}
export function jackalShotParameters(enemy,player,{currentLevel=0,weaponTier=0}={}){
 const bulletType=JACKAL_SHOOTERS[enemy.sourceId];if(bulletType===undefined)throw new TypeError('Uninstalled Jackal shooter source: '+enemy.sourceId);
 finite(enemy.x,enemy.y,enemy.w,enemy.h,player.x,player.y,player.w,player.h);
 const headingDirection=jackalHeadingDirection(enemy.heading),orientation=headingDirection>>2;
 const x=enemy.x+enemy.w/2+(bulletType>=11?JACKAL_PROJECTILE_TABLES.muzzleX[orientation]:0),y=enemy.y+enemy.h/2+(bulletType>=11?JACKAL_PROJECTILE_TABLES.muzzleY[orientation]:0);
 // White turret re-aims from the muzzle. Yellow turret, red tank and L1
 // Boss fire along their source orientation. L1 boat uses quantized 8-way aim.
 const aim=jackalSourceDirection(player.x+player.w/2-x,player.y+player.h/2-y);
 const direction=[6,7,10].includes(enemy.sourceId)?headingDirection:enemy.sourceId===8?(((aim+1)>>2)&7)*4:aim;
 const difficulty=jackalDifficulty(currentLevel,weaponTier),speedByte=JACKAL_PROJECTILE_TABLES.speed[bulletType];
 return {bulletType,direction,speedByte,difficulty,x,y,...jackalSourceVelocity(direction,speedByte),lifetime:JACKAL_PROJECTILE_TABLES.lifetime[bulletType]+JACKAL_PROJECTILE_TABLES.additionalLifetime[difficulty],invisible:JACKAL_PROJECTILE_TABLES.invisible[bulletType]+1,graphicsAttributes:JACKAL_PROJECTILE_TABLES.palette[bulletType]};
}
/** One initialization tick, then source move -> decrement -> odd-tick terrain
 * check. Expiry disables contact immediately; the original impact lasts 8 ticks.
 * An old untyped checkpoint round must use the driver's declared migration. */
export function validateJackalRoundBullet(e){
 if(e.sourceProjectileVersion!==1)throw new TypeError('Unknown Jackal projectile checkpoint version');
 if(JACKAL_SHOOTERS[e.emitterSourceId]!==e.bulletType||!Number.isInteger(e.direction)||e.direction<0||e.direction>31||e.speedByte!==JACKAL_PROJECTILE_TABLES.speed[e.bulletType]||
  !Number.isInteger(e.sourceLifetime)||![0,8,16,24,32].includes(e.sourceLifetime-JACKAL_PROJECTILE_TABLES.lifetime[e.bulletType])||
  !Number.isInteger(e.remainingLifetime)||e.remainingLifetime<0||e.remainingLifetime>e.sourceLifetime||!['initializing','flight','impact'].includes(e.phase)||
  !Number.isInteger(e.flightAge)||e.flightAge<0||typeof e.visible!=='boolean'||!Number.isInteger(e.invisibleRemaining)||e.invisibleRemaining<0||
  e.phase==='impact'&&(!e.dead||!Number.isInteger(e.impactRemaining)||e.impactRemaining<1||e.impactRemaining>8||e.vx!==0||e.vy!==0)||
  e.phase!=='impact'&&(e.remainingLifetime===0||e.dead&&!e.defeatEvent)||e.phase!=='impact'&&e.flightAge+e.remainingLifetime!==e.sourceLifetime)throw new TypeError('Invalid Jackal source projectile checkpoint');
 finite(e.x,e.y,e.vx,e.vy);return true;
}
export function stepJackalRoundBullet(e,world){
 if(e.sourceProjectileVersion!==1)throw new TypeError('Untyped Jackal round requires checkpoint migration');
 if(e.phase==='initializing'){e.phase='flight';return true;}
 if(e.phase==='impact'){if(--e.impactRemaining===0)e.remove=true;return true;}
 if(e.phase!=='flight'||!Number.isInteger(e.remainingLifetime)||e.remainingLifetime<=0)throw new TypeError('Invalid Jackal round lifecycle');
 e.x+=e.vx;e.y+=e.vy;e.flightAge++;
 const remaining=--e.remainingLifetime,from={x:e.x+e.w/2,y:e.y+e.h/2},to={x:from.x+e.vx,y:from.y+e.vy};
 const terrain=remaining>0&&(remaining&1)&&e.bulletType<14&&world.blocksProjectile(from,to);
 if(!remaining||terrain){e.phase='impact';e.outcomeReason=terrain?'terrain':'lifetime';e.dead=true;e.deathAge=0;e.impactRemaining=8;e.vx=0;e.vy=0;e.visible=true;return true;}
 if(e.invisibleRemaining>0&&--e.invisibleRemaining===0)e.visible=true;
 return true;
}
