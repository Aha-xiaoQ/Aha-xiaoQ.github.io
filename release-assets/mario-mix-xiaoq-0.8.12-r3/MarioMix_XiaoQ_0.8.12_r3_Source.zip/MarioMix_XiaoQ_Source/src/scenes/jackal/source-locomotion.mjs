import {jackalHeading,JACKAL_DIRECTIONS,moveJackal} from '../../characters/jackal/motion.mjs';
import {jackalSourceDirection,jackalSourceVelocity} from './source-projectiles.mjs';

// Bank6 RedMediumTank states 1/2/3: discrete 45-degree turns, 32-tick
// steering cadence, committed 80-tick runs and a 32-tick firing countdown.
// Rectangle obstacles replace NES tile probes; a blocked run commits to a
// single detour direction until clear, rather than chasing the target per tick.
export function stepJackalTank(e,world,fire){
 const p=world.player,scale=world.mainline?1.5:1;
 e.driveState??='turn';e.turnWait??=0;e.fireWait??=32;e.driveTicks??=0;
 e.vx=e.vy=0;
 const target=jackalHeading(p.x+p.w/2-e.x-e.w/2,p.y+p.h/2-e.y-e.h/2)||e.heading;
 const velocity=h=>{const [x,y]=JACKAL_DIRECTIONS[h-1];return jackalSourceVelocity(jackalSourceDirection(x,y),0x12);};
 const clear=h=>{const v=velocity(h),q={...e};return moveJackal(q,v.vx*scale*3,v.vy*scale*3,world)&&Math.abs(q.vx-v.vx*scale*3)<1e-6&&Math.abs(q.vy-v.vy*scale*3)<1e-6;};
 if(e.driveState==='turn'){
  if(e.turnWait>0){e.turnWait--;return;}
  if(e.detouring){e.heading=(e.heading-1+(e.turnSign||1)+8)%8+1;e.turnWait=31;if(clear(e.heading))e.detouring=false;}
  else if(e.heading!==target){const d=(target-e.heading+8)%8;e.heading=(e.heading-1+(d<=4?1:-1)+8)%8+1;e.turnWait=31;}
  if(!e.detouring&&clear(e.heading)){e.driveState='drive';e.driveTicks=80;}
  else if(!e.detouring){e.detouring=true;e.turnSign??=String(e.id).length%2?1:-1;e.turnWait=31;}
  return;
 }
 const v=velocity(e.heading),moved=moveJackal(e,v.vx*scale,v.vy*scale,world);
 const blocked=!moved||Math.abs(e.vx-v.vx*scale)>1e-6||Math.abs(e.vy-v.vy*scale)>1e-6;
 if(--e.fireWait<=0){fire();e.fireWait=32;}
 if(blocked||--e.driveTicks<=0){e.driveState='turn';e.turnWait=31;e.detouring=blocked;e.turnSign??=String(e.id).length%2?1:-1;}
}

// Bank6 tblMobileInfantryWalkAroundJeepPath and states 3..6. Mobile soldiers
// choose successive points around the jeep, then stop, aim/flash and shoot.
// Source minimum firing distance remains intact; walking no longer stops
// permanently inside that radius. Obstacle probes advance the orbit on a
// bounded cadence, without changing the pose independently of displacement.
const PATH=[80,57,0,-57,-80,-57,0,57];
export function stepJackalInfantry(e,world,fire){
 const p=world.player,scale=world.mainline?1.5:1;
 e.orbitIndex??=0;e.orbitSign??=String(e.id).length%2?1:-1;e.orbitState??='walk';e.orbitTicks??=128;e.blockedTicks??=0;
 e.vx=e.vy=0;
 if(e.orbitState==='walk'){
  if(!e.orbitTarget){const i=e.orbitIndex;e.orbitTarget={x:Math.max(e.w/2,Math.min(world.width-e.w/2,p.x+p.w/2+PATH[i]*scale)),y:Math.max((world.minY||0)+e.h/2,Math.min(world.height-e.h/2,p.y+p.h/2+PATH[(i+6)&7]*scale))};}
  const dx=e.orbitTarget.x-e.x-e.w/2,dy=e.orbitTarget.y-e.y-e.h/2;
  const velocity=jackalSourceVelocity(jackalSourceDirection(dx,dy),0x01);
  const moved=moveJackal(e,velocity.vx*scale,velocity.vy*scale,world);
  e.blockedTicks=moved?0:e.blockedTicks+1;
  if(moved)e.heading=jackalHeading(e.vx,e.vy)||e.heading;
  if(--e.orbitTicks<=0||Math.hypot(dx,dy)<2||e.blockedTicks>=16){e.orbitState='aim';e.shootCountdown=64;e.orbitTarget=null;e.orbitTicks=128;e.orbitIndex=(e.orbitIndex+e.orbitSign+8)&7;}
 }else{
  e.heading=jackalHeading(p.x+p.w/2-e.x-e.w/2,p.y+p.h/2-e.y-e.h/2)||e.heading;
  const was=e.shootPhase;
  fire();
  if(was==='flash'&&e.shootPhase==='wait'||e.shootPhase!=='flash'&&e.shootCountdown===64)e.orbitState='walk';
 }
}
