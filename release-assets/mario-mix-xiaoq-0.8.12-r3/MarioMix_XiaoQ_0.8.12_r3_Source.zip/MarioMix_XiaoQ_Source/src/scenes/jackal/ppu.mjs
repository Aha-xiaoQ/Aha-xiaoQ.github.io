/** Original Bank7 Label975/888/893 row loader. Data-only original tables, no
 * ROM/CPU emulator at runtime. Source golden includes both nametable halves
 * and packed collision RAM; 240-pixel PPU wrap is not a stretched full map. */
export function createJackalPpu(source){
 const d=source?.map?.ppu;if(!d||d.version!==1||d.loadIndices.length!==13||d.layout.length!==1536||d.definitions.length!==1632||d.palettes.length!==102||d.cutoffs.length!==6)throw new TypeError('Jackal original PPU tables required');
 const tiles=[new Uint8Array(1024),new Uint8Array(1024)],collision=new Uint8Array(512);
 const layoutAt=index=>index<0?d.layoutPrefix?.[index+128]:index>=d.layout.length?d.definitions[index-d.layout.length]:d.layout[index];
 let counter=0,previousSub=0,scroll=0,rowAddress=0x23a0,attrAddress=0x23f8,load=0,metaRow=0,subRow=2,collisionOffset=0,revision=0;
 const kind=tile=>{for(let i=0;i<6;i++)if(tile<d.cutoffs[i])return [0,1,2,0,1,2][i];return 3;};
 function storeRow(args,down){
  if(args.load<0||args.load>=d.loadIndices.length||args.metaRow<0||args.metaRow>7||args.subRow<0||args.subRow>3)throw new TypeError('Original PPU selector outside declared tables');
  const block=d.loadIndices[args.load],base=block*128+args.metaRow*16,row=(args.rowAddress-0x2000)/32;
  for(let c=0;c<64;c++){
   const half=c>>5,mt=d.layout[base+(c>>2)],tile=d.definitions[mt*16+args.subRow*4+(c&3)];tiles[half][row*32+(c&31)]=tile;
   const at=half*256+((args.collisionOffset+(c>>2)%8)&255),shift=(3-(c&3))*2;if((c&3)===0)collision[at]=0;collision[at]|=kind(tile)<<shift;
  }
  if(args.subRow&1){
   const neighbour=base+(down?(args.subRow>=2?-128:0):(args.subRow<2?128:0));
   const mask=args.subRow<2?0xf0:0x0f,other=mask^255,at=args.attrAddress-0x2000;
   for(let c=0;c<16;c++){const current=d.palettes[layoutAt(base+c)],adjacent=d.palettes[layoutAt(neighbour+c)];
    if(!Number.isInteger(current)||!Number.isInteger(adjacent))throw new TypeError('Original PPU attribute neighbour absent');
    tiles[c>>3][at+(c&7)]=(current&mask)|(adjacent&other);
   }
  }revision++;
 }
 function one(next){
  const sub=((next%240)+240)%240,down=next<counter;counter=next;
  if(sub===previousSub)return;scroll=sub===0?0:240-sub;previousSub=sub;
  if(down?sub%8!==7:sub%8!==0)return;
  let args;
  if(down){
   collisionOffset=(collisionOffset+8)&255;
   args={rowAddress,attrAddress,load:load-1,metaRow,subRow,collisionOffset:(collisionOffset+232)&255};
   if((sub&31)===15){attrAddress=(attrAddress&0xff00)|(((attrAddress+8)&255)||0xc0);}
   rowAddress+=32;if(rowAddress===0x23c0)rowAddress=0x2000;
   if(subRow===2&&metaRow===0){subRow=3;metaRow=7;load--;}
   else{if(--subRow<0){subRow=3;metaRow--;}}
  }else{
   collisionOffset=(collisionOffset-8)&255;
   if(sub===0||((sub-16)&31)===0){let low=((attrAddress&255)-8)&255;if(low<0xc0)low=0xf8;attrAddress=(attrAddress&0xff00)|low;}
   rowAddress-=32;if(rowAddress<0x2000)rowAddress=0x23a0;
   if(++subRow===4){if(metaRow===7){load++;metaRow=0;subRow=2;}else{metaRow++;subRow=0;}}
   args={rowAddress,attrAddress,load,metaRow,subRow,collisionOffset};
  }storeRow(args,down);
 }
 function setCounter(next){if(!Number.isSafeInteger(next)||next<0||next>2880)throw new TypeError('Invalid source scroll counter');
  while(counter!==next)one(counter+(next>counter?1:-1));return true;
 }
 const group=(half,x,y)=>{const a=tiles[half][960+(y>>2)*8+(x>>2)];return (a>>(((x>>1)&1)+((y>>1)&1)*2)*2)&3;};
 let patches=[];
 function setPatches(value){
  if(!Array.isArray(value)||value.length>64||value.some(q=>typeof q.id!=='string'||![q.x,q.y].every(Number.isSafeInteger)||q.x%8||q.y%8||!Array.isArray(q.tiles)||q.tiles.length!==16||q.tiles.some(t=>!Number.isInteger(t)||t<0||t>255)||![0,1,2,3].includes(q.collision)))throw new TypeError('Invalid original background replacement');
  patches=value;
 }
 function projectedTile(half,x,y,cameraY){
  const local=((y*8-scroll+240)%240),wx=(half*32+x)*8,wy=cameraY+local;
  for(let n=patches.length-1;n>=0;n--){const q=patches[n],dx=wx-q.x,dy=wy-q.y;
   if(dx>=0&&dx<32&&dy>=0&&dy<32)return {tile:q.tiles[(dy>>3)*4+(dx>>3)],collision:q.collision};}
  return {tile:tiles[half][y*32+x],collision:null};
 }
 function view(cameraY=null){const tables=tiles.map(t=>Array.from(t));
  if(cameraY!==null)for(let y=0;y<30;y++)for(let x=0;x<64;x++)tables[x>>5][y*32+(x&31)]=projectedTile(x>>5,x&31,y,cameraY).tile;
  return {counter,scroll,revision,nametables:tables,collisionRam:Array.from(collision)};
 }
 function geometry(cameraY){
  const out=[];for(let row=0;row<30;row++)for(let col=0;col<64;col++){
   const projected=projectedTile(col>>5,col&31,row,cameraY),type=projected.collision??kind(projected.tile);if(!type)continue;
   const local=((row*8-scroll+240)%240),top=cameraY+local;
   out.push({id:'ppu-'+row+'-'+col,x:col*8,y:top,w:8,h:Math.min(8,240-local),collision:'solid',sourceCollision:type});
   if(local>232)out.push({id:'ppu-wrap-'+row+'-'+col,x:col*8,y:cameraY,w:8,h:local-232,collision:'solid',sourceCollision:type});
  }return out;
 }
 function capture(){return {...view(),previousSub,rowAddress,attrAddress,load,metaRow,subRow,collisionOffset};}
 function restore(value){
  if(!value||!Number.isSafeInteger(value.counter)||value.counter<0||value.counter>2880||value.previousSub!==value.counter%240||value.scroll!==(value.counter%240?240-value.counter%240:0)||!Number.isSafeInteger(value.revision)||value.revision<0||
   !Number.isInteger(value.rowAddress)||value.rowAddress<0x2000||value.rowAddress>0x23a0||value.rowAddress%32||!Number.isInteger(value.attrAddress)||value.attrAddress<0x23c0||value.attrAddress>0x23f8||value.attrAddress%8||
   !Number.isInteger(value.load)||value.load<0||value.load>12||!Number.isInteger(value.metaRow)||value.metaRow<0||value.metaRow>7||!Number.isInteger(value.subRow)||value.subRow<0||value.subRow>3||!Number.isInteger(value.collisionOffset)||value.collisionOffset<0||value.collisionOffset>255||
   !Array.isArray(value.nametables)||value.nametables.length!==2||value.nametables.some(t=>!Array.isArray(t)||t.length!==1024||t.some(v=>!Number.isInteger(v)||v<0||v>255))||!Array.isArray(value.collisionRam)||value.collisionRam.length!==512||value.collisionRam.some(v=>!Number.isInteger(v)||v<0||v>255))throw new TypeError('Invalid original PPU checkpoint');
  ({counter,scroll,previousSub,rowAddress,attrAddress,load,metaRow,subRow,collisionOffset,revision}=value);tiles[0].set(value.nametables[0]);tiles[1].set(value.nametables[1]);collision.set(value.collisionRam);return true;
 }
 return {setCounter,setPatches,view,geometry,capture,restore,group,tile:(half,x,y)=>tiles[half][y*32+x],kind};
}
