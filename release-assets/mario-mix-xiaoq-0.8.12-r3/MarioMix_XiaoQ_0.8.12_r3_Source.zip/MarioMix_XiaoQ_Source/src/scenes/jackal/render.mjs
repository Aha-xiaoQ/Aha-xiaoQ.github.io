import {jackalExplosionParts,jackalInfantryPose,jackalVehicleBob,jackalBoardingPowPose} from './source-animation.mjs';
const names=['up','up-right','right','down-right','down','down-left','left','up-left'];
import {JACKAL_SPRITE_RGB} from './source-projectiles.mjs';
import {jackalPlayerPose} from '../../characters/jackal/presentation.mjs';
/** Every frame is an original OAM composition. Exact source flips and declared quarter-turn world projections
 * preserve pixels; mainline size/contact and muzzle share a declared form. */
export function createJackalRenderer({source,images,context,viewport,createSurface}){
 if(!source?.images||!images||typeof context!=='function'||typeof viewport!=='function')throw new TypeError('Jackal renderer needs installed image/viewport ports');
 let cache=null,cachedKey=null;const paletteImages=new Map();
 function spritePalette(name,from,to,bossPalette){
  if(from===to&&!bossPalette)return images[name];
  const key=name+':'+to+':'+!!bossPalette;if(paletteImages.has(key))return paletteImages.get(key);
  if(typeof createSurface!=='function')throw new TypeError('Jackal source palette needs an offscreen surface');
  const row=source.images[name],surface=createSurface();surface.width=row.size[0];surface.height=row.size[1];const ctx=surface.getContext('2d');
  ctx.drawImage(images[name],0,0);const data=ctx.getImageData(0,0,surface.width,surface.height);
  const original=source.map.ppu.defaultPalette.slice(16+from*4,20+from*4),target=(bossPalette?source.map.ppu.bossPalette:source.map.ppu.defaultPalette.slice(16)).slice(to*4,to*4+4);
  for(let n=0;n<data.data.length;n+=4){if(!data.data[n+3])continue;
   const index=original.findIndex((c,i)=>i>0&&JACKAL_SPRITE_RGB[c]?.every((v,j)=>v===data.data[n+j]));
   if(index<1||!JACKAL_SPRITE_RGB[target[index]])throw new TypeError('Original Jackal sprite palette pixel is unresolved: '+name);
   for(let j=0;j<3;j++)data.data[n+j]=JACKAL_SPRITE_RGB[target[index]][j];
  }
  ctx.putImageData(data,0,0);paletteImages.set(key,surface);return surface;
 }
 function background(g,v){
  const atlas=images[v.flashPalette>=0?'level1-ppu-background-flash-'+v.flashPalette:'level1-ppu-background-tiles'];if(!atlas?.naturalWidth||!v.ppu?.nametables)throw new Error('Original Jackal PPU image is not ready');
  if(!cache){if(typeof createSurface!=='function')throw new TypeError('Jackal scene needs an offscreen surface port');cache=createSurface();cache.width=512;cache.height=240;}
  const key=v.renderEpoch+':'+v.ppu.revision+':'+v.backgroundRevision+':'+v.flashPalette;
  if(key!==cachedKey){const b=cache.getContext('2d');if(!b)throw new TypeError('Jackal offscreen context absent');b.imageSmoothingEnabled=false;
   for(let row=0;row<30;row++)for(let col=0;col<64;col++){
    const table=v.ppu.nametables[col>>5],x=col&31,tile=table[row*32+x],a=table[960+(row>>2)*8+(x>>2)],group=(a>>(((x>>1)&1)+((row>>1)&1)*2)*2)&3;
    b.drawImage(atlas,(tile%16)*8,(Math.floor(tile/16)+group*16)*8,8,8,col*8,row*8,8,8);
   }cachedKey=key;
  }
  const scroll=v.ppu.scroll,tail=240-scroll;
  g.drawImage(cache,v.cameraX,scroll,256,tail,0,0,256,tail);if(scroll)g.drawImage(cache,v.cameraX,0,256,scroll,0,tail,256,scroll);
 }
 function image(g,name,x,y,{scale=1,flipX=false,flipY=false,center=true,paletteFrom=null,paletteTo=null,bossPalette=false,exactAnchor=false,quarterTurns=0}={}){
  const row=source.images[name],original=images[name];if(!row||!original)throw new TypeError('Missing original Jackal art: '+name);if(!original.naturalWidth)return false;
  const im=paletteFrom===null?original:spritePalette(name,paletteFrom,paletteTo,bossPalette);
  const [w,h]=row.size,[ax,ay]=row.anchor;g.save();g.imageSmoothingEnabled=false;g.translate(exactAnchor?x:Math.round(x),exactAnchor?y:Math.round(y));if(quarterTurns)g.rotate(quarterTurns*Math.PI/2);g.scale((flipX?-1:1)*scale,(flipY?-1:1)*scale);
  g.drawImage(im,center?-ax:0,center?-ay:0,w,h);g.restore();return true;
 }
 function player(g,p,t,{native=true}={}){
  const pose=jackalPlayerPose(p,{native});
  if(p.dying){for(const part of jackalExplosionParts({x:pose.x,y:pose.y,blastAge:Math.max(0,t-(p.jackalDeathTick||0))}))image(g,part.name,part.x,part.y,{scale:pose.scale,exactAnchor:true});return true;}
  if(native&&p.jackalHurtUntil>t&&t%8>=4)return true;
  const palette=(p.invuln||p.invulnerable)>0?{paletteFrom:0,paletteTo:t%4}:{};
  return image(g,pose.frame.name,pose.x,pose.y+jackalVehicleBob(p,t)*pose.scale,{scale:pose.scale,exactAnchor:true,...palette});
 }
 function weapon(g,w,t){
  for(const q of w.bullets)image(g,q.phase==='flight'?'effect-bullet-flight':'effect-bullet-ground-impact',q.x,q.y,{scale:q.scale||1});
  const m=w.main;if(!m)return true;
  if(m.phase==='flight'){image(g,m.kind==='grenade'?'effect-grenade-'+(m.remaining>=14&&m.remaining<=25?8:7)+'-spin'+(Math.floor(t/4)%4):'effect-bazooka-'+names[m.heading-1],m.x,m.y,{scale:m.scale||1});return true;}
  for(const q of jackalExplosionParts(m))image(g,q.name,q.x,q.y,{flipY:q.flipY,scale:q.scale});return true;
 }
 function pickup(g,q,t){return image(g,'tblPowerUpStar',q.x+q.w/2,q.y+q.h/2,{flipX:Math.floor(t/8)%2===1});}
 function oriented(g,prefix,e,{bossPalette=false}={}){const h=e.heading||5,diagonal=h%2===0,hor=h===3||h===7;
  let name=prefix+(diagonal?(h===4||h===8?'DiagonalUpsideDown':'Diagonal'):hor?'Right_Left':'Up_Down');
  if(!source.images[name])name=prefix+(diagonal?'Diagonal':hor?'Left_Right':'Up_Down');
  if(e.recoil&&source.images[name+'Recoil'])name+='Recoil';
  if(bossPalette)name+='-'+(e.hp<=5&&e.phase!=='approach'?'low-health':'normal');
  const flipY=h===1||h===2||h===8,scale=e.displayScale||1;
  // Source opaque bounds, including mirrored rows, determine grounded tank
  // contact; PNG padding never becomes an independent body/muzzle offset.
  const row=source.images[name],alpha=e.type==='tank'?(diagonal?[5,27]:hor?[0,16]:[6,27]):null;
  const bottom=alpha?(flipY?row.anchor[1]-alpha[0]:alpha[1]-row.anchor[1])*scale:0;
  const y=Number.isFinite(e.groundFoot)?e.groundFoot-bottom:e.y+e.h/2;
  return image(g,name,e.x+e.w/2,y,{scale,flipX:h>=6,flipY,...(e.type==='turret'?{paletteFrom:0,paletteTo:2}:{})});
 }
 function enemy(g,e,t,{bossPalette=false}={}){
  if(e.type==='round-bullet'&&!e.defeatEvent){
   if(e.phase==='impact')return image(g,'effect-bullet-ground-impact',e.x+e.w/2,e.y+e.h/2);
   if(e.visible===false)return true;
   return image(g,'effect-bullet-flight',e.x+e.w/2,e.y+e.h/2,{paletteFrom:3,paletteTo:e.graphicsAttributes??2,bossPalette});
  }
  if(e.flash>0&&t%4<2)return true;
  if(e.dead){if(e.crushed)return image(g,'effect-infantry-tblCrushedInfantry',e.x+e.w/2,e.y+e.h/2);if(e.deathAge<24)image(g,'effect-explosion-'+['small','medium','large'][Math.min(2,Math.floor(e.deathAge/8))],e.x+e.w/2,e.y+e.h/2);return true;}
  if(e.type==='barracks')return image(g,'tblPOWBuildingHELPText',e.x+e.w/2,e.y-8);
  if(e.type==='bomber')return image(g,e.age%2?'tblBomberPlaneWithShadow':'tblBomberPlane',e.x+e.w/2,e.y+e.h/2,{quarterTurns:e.dir>0?-1:1});
  if(e.type==='gate')return true; // Original gate is already a nametable object.
  if(e.type==='round-bullet')return image(g,'tblBlackShell',e.x+e.w/2,e.y+e.h/2);
  if(e.type==='boss-tank')return oriented(g,'tblLevel1BossTank',e,{bossPalette});
  if(e.type==='tank')return oriented(g,'tblMediumRedTank',e);
  if(e.type==='turret')return oriented(g,'tblLargeGrayTurret',e);
  if(e.type==='boat')return image(g,'tblLevel1AttackBoatWake'+(Math.floor(t/8)%2+1),e.x+e.w/2,e.y+e.h/2);
  const pose=jackalInfantryPose(e);
  return image(g,pose.name,e.x+e.w/2,e.y+e.h/2,{flipX:pose.flipX,paletteFrom:1,paletteTo:e.shootPalette??1,bossPalette});
 }
 function digits(g,text,x,y){for(const c of String(text)){if(!source.images['hud-'+c])throw new TypeError('Missing original Jackal HUD glyph '+c);image(g,'hud-'+c,x,y,{center:false});x+=8;}}
 function scene(v){const g=context(),{width,height}=viewport(),scale=Math.min(width/256,height/240),ox=(width-256*scale)/2,oy=(height-240*scale)/2;
  g.save();g.fillStyle='#000';g.fillRect(0,0,width,height);g.translate(ox,oy);g.scale(scale,scale);g.beginPath();g.rect(0,0,256,240);g.clip();g.imageSmoothingEnabled=false;
  background(g,v);
  g.save();g.translate(-Math.floor(v.cameraX),-Math.floor(v.cameraY));
  for(const o of v.objects){if(o.collected)continue;if(o.type==='star')pickup(g,o,v.progress.tick);else image(g,'tblHelicopterOnHelipad'+(Math.floor(v.progress.tick/8)%2+1),o.x,o.y);}
  for(const q of v.pows)if(!q.picked)image(g,'tblPOWWaving'+(Math.floor(q.age/8)%2+1),q.x+q.w/2,q.y+q.h/2);
  for(const e of v.enemies)enemy(g,e,v.progress.tick,{bossPalette:v.palette==='boss'});if(v.reward)pickup(g,v.reward,v.progress.tick);weapon(g,v.weapons,v.progress.tick);player(g,v.body,v.progress.tick);
  if(v.exitReady)image(g,'tblHelicopterOnHelipad'+(Math.floor(v.progress.tick/8)%2+1),256,v.cameraY+32);
  g.restore();image(g,'hud-P',8,8,{center:false});digits(g,'1',16,8);digits(g,String(v.carry.score).padStart(6,'0'),32,8);digits(g,String(v.carry.lives),220,8);
  for(let n=0;n<v.progress.cargo;n++)image(g,'tblPOWWalkingLeft_RightFeetTogether',8+n*8,228);
  g.restore();return true;
 }
 const portrait={source:'jackal-nes:original-p1-up',ready:()=>!!images['player1-up']?.naturalWidth,
  draw(g,b){const row=source.images['player1-up'];if(!row)throw new TypeError('Original Jackal portrait absent');const s=Math.min(b.w/row.size[0],b.h/row.size[1]);return image(g,'player1-up',b.x+b.w/2,b.y+b.h/2,{scale:s});}};
 function rescue(g,v){
  if(!v?.pad)return true;
  if(!v)return true;
  for(const f of v.facilities){
   const name='mainline-pow-'+(f.kind==='normal'?'warehouse':'house')+'-'+(f.open?'open':'closed'),row=source.images[name];
   if(row.size[0]*f.scale!==f.bounds.w||row.size[1]*f.scale!==f.bounds.h)throw new Error('Jackal facility art/contact scale mismatch');
   image(g,name,f.bounds.x,f.bounds.y,{scale:f.scale,center:false});
   if(f.kind==='normal'&&(!f.open||f.help))image(g,'tblPOWBuildingHELPText',f.x,f.bounds.y-5*f.scale,{scale:f.scale});
  }
  image(g,'mainline-airport',v.pad.x,v.pad.y,{scale:v.pad.scale,center:false});
  return true;
 }
 function rescueAir(g,v){
  if(!v)return true;
  const heli=v.helicopter;
  if(heli&&!['waiting','gone'].includes(heli.phase)){
   const flying=['inbound','outbound'].includes(heli.phase),name='tblHelicopter'+(flying?'InAir':'OnHelipad')+(Math.floor(v.tick/(flying?2:8))%2+1);
   image(g,name,heli.x,heli.y,{scale:v.pad.scale});
  }
  for(const q of v.pows){
   const frame=q.walking?(q.flash?(Math.floor(q.age/8)%2?'tblPOWWalkingDownRightFootForward':'tblPOWWalkingDownLeftFootForward'):(Math.floor(q.age/8)%2?'tblPOWWalkingLeft_RightFeetTogether':'tblPOWWalkingLeft_RightInStride')):'tblPOWWaving'+(Math.floor(q.age/8)%2+1);
   image(g,frame,q.x+q.w/2,q.y+q.h/2,{scale:1.5,paletteFrom:q.flash?0:null,paletteTo:q.flash?v.tick%4:0});
  }
  if(v.flyover)image(g,v.flyover.age%2?'tblBomberPlaneWithShadow':'tblBomberPlane',v.flyover.x,v.flyover.y,{scale:1,quarterTurns:v.flyover.dir>0?-1:1});
  for(const b of v.bombs||[]){
   if(b.phase==='impact'){for(const part of jackalExplosionParts(b))image(g,part.name,part.x,part.y);}
   else {const n=Math.min(3,Math.floor(b.age/16)),name=n===0||n===3?'tblPlane_JeepBombUpLeftSmall':'tblPlane_JeepBombDownRightLarge';image(g,name,b.x,b.y,{flipX:!!(n&1),flipY:!!(n&2),paletteFrom:1,paletteTo:3});}
  }
  for(const q of v.arrivals){const pose=jackalBoardingPowPose(q);image(g,pose.name,q.x,q.y,{scale:1.5,flipX:pose.flipX,paletteFrom:q.flash?0:null,paletteTo:q.flash?v.tick%4:0});}
  return true;
 }
 function companion(g,{companionX,feet},v){
  // Original POW waving frames have their visible feet at row16 (anchor8).
  return image(g,'tblPOWWaving'+(Math.floor(v.tick/8)%2+1),companionX,feet-12,{scale:1.5});
 }
 return {player,weapon,pickup,enemy,scene,portrait,rescue,rescueAir,companion,turretBase:(g,p)=>image(g,'mainline-turret-base',p.x,p.y,{scale:p.scale})};
}
