import {createJackalActor,JACKAL_INPUT,validateJackalCarry} from '../../characters/jackal/actor.mjs';
import {createDeclaredInputAdapter,inputEdge} from '../../engine/input-contract.mjs';
import {copySceneCheckpoint} from '../../engine/scene-state.mjs';
import {copyRewardReceipt,addRoomReward} from '../../engine/reward-receipt.mjs';
import {firstProjectileContact} from '../../engine/world-collision.mjs';
import {canHitEnemy} from '../../engine/enemy-contract.mjs';
import {overlap,clamp} from '../../engine/geometry.mjs';
import {createJackalFoes} from './foes.mjs';
import {createJackalPpu} from './ppu.mjs';
import {validateJackalRoundBullet} from './source-projectiles.mjs';

export const JACKAL_RULE=Object.freeze({health:'protection',hud:'jackal'});
export const JACKAL_REWARD=Object.freeze({id:'hidden-clear:jackal',equipment:'jackal-weapon',score:1000,lives:1});
export const JACKAL_ROOM=Object.freeze({id:'jackal-level1-rescue',width:512,height:2880,viewportWidth:256,viewportHeight:240,bossCount:4,exit:Object.freeze({x:224,y:18,w:64,h:40})});
const clone=v=>JSON.parse(JSON.stringify(v));
let nextRenderEpoch=0;
function counters(value){const out={};for(const k of ['score','coins','lives']){if(!Number.isSafeInteger(value?.[k])||value[k]<0)throw new TypeError('Invalid Jackal campaign counter');out[k]=value[k];}return out;}
/** A separately installed vehicle and original rescue room. The host supplies
 * one clock and owns life debits. This driver never opens RAF or listeners. */
export function createJackalRescue({source,render,audio,emit=()=>{}}){
 for(const key of ['player','weapon','pickup','scene'])if(typeof render?.[key]!=='function')throw new TypeError('Jackal renderer missing '+key);
 for(const key of ['play','begin','tick','victory','pause','resume','cancel'])if(typeof audio?.[key]!=='function')throw new TypeError('Jackal audio missing '+key);
 if(source?.map?.width!==512||source.map.height!==2880||source.map.cell!==8)throw new TypeError('Jackal needs original 240-row ring map');
 const ppu=createJackalPpu(source),spawnRecords=source.map.spawns;
 if(!Array.isArray(spawnRecords)||spawnRecords.some(r=>typeof r.id!=='string'||!Number.isInteger(r.screen)||r.screen<0||r.screen>11||!Number.isInteger(r.sub)||r.sub<0||r.sub>239))throw new TypeError('Invalid original Jackal spawn table');
 let actor=null,p=null,foes=null,state=null,paused=false,previous={},activated=false,world=null,visibleGeometry=[],renderEpoch=0;
 const inputAdapter=createDeclaredInputAdapter(JACKAL_INPUT);
 const alive=()=>state&&!state.failed&&!state.exited;
 function score(value){if(!Number.isSafeInteger(value)||value<0)throw new TypeError('Invalid Jackal score award');state.counters.score=Math.min(9999999999,state.counters.score+value);}
 function makeWorld(){
  ppu.setCounter(state.scrollCounter);ppu.setPatches(state.backgroundPatches);visibleGeometry=ppu.geometry(state.cameraY);
  function query(shot,from,to,options={},grenade=false){
   // The source background gate/building hitbox owns its covered tile cells;
   // a wall test must not absorb a hit before that destructible source object.
   const solids=visibleGeometry.filter(g=>g.sourceCollision!==2&&!state.enemies.some(e=>['barracks','gate'].includes(e.type)&&canHitEnemy(e)&&overlap(g,e)));
   const hit=firstProjectileContact(from,to,{geometry:grenade?[]:solids,enemies:state.enemies,radius:options.radius||0,canHit:e=>canHitEnemy(e)&&foes.definition(e).targetable});
   if(!hit)return null;
   if(hit.kind==='enemy')foes.hurt(hit.entity,options.damage||1,{kind:options.kind,tick:state.tick,id:shot.attackInstanceId||shot.id});
   return {kind:hit.kind,x:hit.x,y:hit.y,targetId:hit.entity.id};
  }
  world={width:512,height:2880,mainline:false,roomId:JACKAL_ROOM.id,player:p,solids:visibleGeometry,enemies:state.enemies,
   get tick(){return state.tick;},get cameraY(){return state.cameraY;},projectile:(...args)=>query(...args),grenadeProjectile:(shot,from,to,o)=>query(shot,from,to,o,true),
   blocksProjectile:(from,to)=>!!firstProjectileContact(from,to,{geometry:visibleGeometry.filter(g=>g.sourceCollision===1),enemies:[],radius:1}),
   spawnEnemy(e){if(state.enemies.filter(q=>!q.remove).length<48)state.pendingEnemies.push(e);},
   damageEnemy:(e,damage,hit)=>foes.hurt(e,damage,{...hit,tick:state.tick}),kill:(e,event)=>foes.kill(e,{...event,tick:state.tick}),
   breakBlock:()=>false,enemyDefinition:foes.definition};
  return world;
 }
 function onEvent(name,event){
  if(name==='enemy-retired'&&event.authoritativeDeath&&event.contractId==='jackal-nes:boss-tank'){
   if(!state.boss.defeatedIds.includes(event.entityId))state.boss.defeatedIds.push(event.entityId);
  }
  if(name==='enemy-defeated'&&['jackal-nes:barracks','jackal-nes:gate'].includes(event.contract)){
   const e=state.enemies.find(q=>q.id===event.entityId);if(!e)return;
   // Original replacement is issued when the 24-tick opening starts, not at
   // sprite retirement. Keep its source tile IDs and collision in one record.
   const indices=[e.sourceId===27?0:e.sourceId===21?3:e.sourceId===29?1:2];
   for(const index of indices){const r=source.map.ppu.replacements[index],x=Math.floor((e.x+e.w/2+r.offset[0])/8)*8,y=Math.floor((e.y+e.h/2+r.offset[1])/8)*8;
    const id=e.id+':background:'+index;if(!state.backgroundPatches.some(q=>q.id===id))state.backgroundPatches.push({id,x,y,tiles:[...r.tiles],collision:r.collision});}
   const count=e.sourceId===27?0:e.sourceId===21?1:e.sourceId===19?2:4,power=e.sourceId===21,dx=power?0:e.sourceId===29?-.5:.5,dy=power?1:0;
   for(let n=0;n<count;n++)state.pows.push({id:e.id+':pow:'+n,x:e.x+e.w/2-4,y:e.y+e.h/2-6,w:8,h:12,picked:false,delivered:false,power,age:0,exitDelay:power?26:88+n*72,exitFrames:power?28:72,dx,dy});
  }
  emit(name,event);
 }
 function enter({carry,retry=false,rewardReceipt,scene=null}={}){
  if(actor)throw new Error('Jackal scene already entered');const base=counters(carry);renderEpoch=++nextRenderEpoch;
  state={tick:0,cameraX:0,cameraY:2640,scrollCounter:240,maxProgress:240,retreatBudget:0,autoScroll:false,palette:'default',flashTimer:7,flashCycle:0,flashPalette:-1,backgroundPatches:[],seed:1,counters:base,enemies:[],pendingEnemies:[],spawnedIds:[],pows:[],cargo:[],deliveredIds:[],
   objects:[],boss:{active:false,generated:0,remainingDelay:0,interval:240,defeatedIds:[]},reward:null,rewardClaimed:copyRewardReceipt('jackal',rewardReceipt).claimed,
   cleared:false,failed:false,exited:false,grantedIds:[],deathTick:null};
  actor=createJackalActor({render,audio});p=actor.create({width:12,height:12},{x:74,y:2762});p.protection=retry?0:carry.protection||0;foes=createJackalFoes({cue:audio.play,emit:onEvent,award:score});
  makeWorld();actor.prepareRoom(world);paused=false;previous={};
  if(retry&&scene?.data?.schema==='jackal-rescue-retry-v2'){restoreData(scene.data.checkpoint);state.counters=base;state.enemies=state.enemies.filter(e=>e.type!=='round-bullet');state.failed=false;state.exited=false;state.deathTick=null;p.dying=false;p.hp=1;p.protection=0;p.invuln=160;const safe=findOpenSpawn(state.cameraY);p.x=safe.x;p.y=safe.y;actor.prepareRoom(makeWorld());}
  audio.begin({victory:state.cleared});return true;
 }
 function findOpenSpawn(cameraY){
  // A retry keeps map/rescue/Boss progress and finds an actual free 12px body.
  const y=clamp(cameraY+176,0,2868),x=clamp(p?.x??74,16,484);
  for(let radius=0;radius<=240;radius+=8)for(const dx of radius?[radius,-radius]:[0])for(const dy of [0,-16,16,-32,32]){const q={x:clamp(x+dx,0,500),y:clamp(y+dy,cameraY,cameraY+228),w:12,h:12};if(!visibleGeometry.some(g=>overlap(q,g)))return q;}
  throw new Error('Jackal retry has no source-map spawn space');
 }
 function installSpawn(r){
  if(r.special){if(r.special===240){audio.begin({boss:true});state.autoScroll=true;}else if(r.special===241){state.palette='default';state.flashTimer=128;state.flashPalette=-1;}else state.palette='boss';return;}
  if(r.sourceId===9){state.boss.active=true;state.autoScroll=false;state.boss.interval=[240,208,176,144][p.jackalTier];state.boss.remainingDelay=state.boss.interval;return;}
  // The exact screen/subposition counter owns pixels, collision and spawn Y.
  const cam=2880-(r.screen*240+r.sub),y=cam+(r.bottom?239:0);
  if([60,61,63,80].includes(r.sourceId)){state.objects.push({id:r.id,type:r.sourceId===80?'star':r.sourceId===63?'dropoff':'chinook',sourceId:r.sourceId,x:r.x,y,w:r.sourceId===80?16:64,h:r.sourceId===80?16:80});return;}
  state.enemies.push(foes.spawn(r,y));
 }
 function updateCamera(){
  let cx=p.x+p.w/2-state.cameraX,cy=p.y+p.h/2-state.cameraY;
  if(cx<64&&state.cameraX>0)state.cameraX--;else if(cx>=192&&state.cameraX<255)state.cameraX++;
  p.x=clamp(p.x,state.cameraX+10,state.cameraX+234);
  if(state.autoScroll&&!state.boss.active){if(state.scrollCounter<source.map.ppu.bossCounter){state.scrollCounter++;state.cameraY--;if(cy>=208)p.y--;}}
  else if(!state.boss.active){
   if(cy<96&&state.scrollCounter<source.map.ppu.bossCounter){state.scrollCounter++;state.cameraY--;state.retreatBudget=Math.min(64,state.retreatBudget+1);}
   else if(cy>=192&&state.retreatBudget>0){state.scrollCounter--;state.cameraY++;state.retreatBudget--;}
   else p.y=clamp(p.y,state.cameraY+42,state.cameraY+218);
  }else p.y=clamp(p.y,state.cameraY+42,state.cameraY+218);
  state.maxProgress=Math.max(state.maxProgress,state.scrollCounter);
 }
 function step(raw={}){
  if(!alive()||paused)return;const input=inputAdapter(raw,previous);previous={...input};state.tick++;state.seed=(state.seed+1)&255;
  makeWorld();actor.step(p,input,world);
  updateCamera();
  for(const r of spawnRecords)if(!state.spawnedIds.includes(r.id)&&r.screen*240+r.sub===state.scrollCounter&&(!r.hard||p.jackalTier>=3)){
   state.spawnedIds.push(r.id);installSpawn(r);emit('source-spawn',{entityId:r.id,counter:state.scrollCounter,cameraY:state.cameraY,worldY:state.cameraY+(r.bottom?239:0),sourceId:r.sourceId??null,special:r.special??null});
  }
  makeWorld();actor.combat(p,input,world);foes.crush(p,state.enemies,state.tick);
  // Each existing entity advances once; births are appended after the pass.
  for(const e of state.enemies)foes.step(e,world);state.enemies.push(...state.pendingEnemies);state.pendingEnemies=[];
  for(const e of state.enemies)if(canHitEnemy(e)&&!['barracks','gate','infantry'].includes(e.type)&&overlap(p,e)){
   if(p.invuln>0)continue;if(p.protection){p.protection=0;p.invuln=160;audio.play('jackal_hardhit');}
   else{state.failed=true;state.deathTick=state.tick;p.hp=0;p.dying=true;actor.beginDeath(p);actor.sound('death');audio.cancel({preserveDeath:true});break;}
  }
  state.enemies=state.enemies.filter(e=>!e.remove);
  for(const pow of state.pows){pow.age++;if(!pow.picked&&pow.age>pow.exitDelay&&pow.age<=pow.exitDelay+pow.exitFrames){pow.x+=pow.dx;pow.y+=pow.dy;}
   if(!pow.picked&&pow.age>pow.exitDelay+pow.exitFrames&&state.cargo.length<8&&overlap(p,pow)){
   pow.picked=true;state.cargo.push(pow.id);audio.play('jackal_powpickup');if(pow.power)actor.pickup(p,{nativeType:'jackal-upgrade'});}
  }
  for(const o of state.objects){if(o.type==='star'&&!o.collected&&overlap(p,o)){o.collected=true;actor.pickup(p,{nativeType:'jackal-upgrade'});}
   if(o.type==='dropoff'&&state.cargo.length&&Math.abs(p.x+p.w/2-o.x)<48&&Math.abs(p.y+p.h/2-o.y)<40&&state.tick%16===0){const id=state.cargo.shift();state.deliveredIds.push(id);state.pows.find(q=>q.id===id).delivered=true;score(100);audio.play('jackal_powdeliver');}
  }
  const boss=state.boss;if(boss.active&&boss.generated<4&&--boss.remainingDelay<=0){const n=++boss.generated,x=clamp(state.seed,80,176)*2,bottom=(4-n)%2===1;state.enemies.push(foes.boss(n,x,state.cameraY+(bottom?239:0),bottom));boss.remainingDelay=boss.interval;}
  if(boss.generated===4&&boss.defeatedIds.length===4&&!state.cleared){state.cleared=true;audio.victory();
   if(!state.rewardClaimed)state.reward={id:'jackal-room-upgrade',kind:'native-supply',nativeType:'jackal-upgrade',tier:Math.min(3,p.jackalTier+1),x:250,y:state.cameraY+108,w:16,h:16};}
  if(state.reward&&!state.rewardClaimed&&overlap(p,state.reward)){
   const accepted=actor.pickup(p,state.reward);if(accepted!==false){state.rewardClaimed=true;onEvent('item-collected',{entityId:state.reward.id,kind:state.reward.kind,nativeType:state.reward.nativeType});state.reward=null;}
  }
  if(state.cleared&&state.rewardClaimed&&overlap(p,JACKAL_ROOM.exit)&&inputEdge(input,'interactPressed',[],()=>false))state.exited=true;
  // Original Label1007 cycles 13,14,15,14 every 33 calls (reload32,
  // then DEC to zero), only while screen9<=screen<11. F1 disables it.
  if(state.flashTimer===0){state.flashTimer=32;const screen=Math.floor(state.scrollCounter/240),[start,end]=source.map.ppu.flashScreens;
   if(screen>=start&&screen<end){state.flashPalette=[0,1,2,1][state.flashCycle];state.flashCycle=(state.flashCycle+1)&3;}}
  else if(state.flashTimer<128)state.flashTimer--;
  audio.tick();
 }
 function view(){if(!state||!p)return{};return {hero:'jackal',id:JACKAL_ROOM.id,title:'赤色要塞 · 救援行动',mode:paused?'paused':'playing',area:state.boss.active?'boss':'rescue',logicalWidth:256,logicalHeight:240,
  healthMode:'protection',protection:p.protection||0,hp:p.hp,maxHp:1,carry:{...state.counters},nativeCarry:actor.carry(p),rewardClaimed:state.rewardClaimed,
  cleared:state.cleared&&state.rewardClaimed,exited:state.exited,exitReady:state.cleared&&state.rewardClaimed,failed:state.failed,body:{...p},
  progress:{tick:state.tick,x:p.x,y:p.y,cargo:state.cargo.length,rescued:state.deliveredIds.length,bossGenerated:state.boss.generated,bossDefeated:state.boss.defeatedIds.length},
  cameraX:state.cameraX,cameraY:state.cameraY,palette:state.palette,flashPalette:state.flashPalette,renderEpoch,ppu:ppu.view(state.cameraY),backgroundRevision:state.backgroundPatches.length,enemies:clone(state.enemies),pows:clone(state.pows),objects:clone(state.objects),reward:state.reward&&{...state.reward},weapons:actor.view().weapons};}
 function snapshotScene(){if(!state)throw new Error('No Jackal scene');const {pendingEnemies,...data}=state;return {schema:'jackal-rescue-v2',id:JACKAL_ROOM.id,state:clone(data),ppu:ppu.capture(),body:{x:p.x,y:p.y,protection:p.protection||0,invuln:p.invuln||0},foes:foes.snapshot()};}
 function restoreData(data){
  const d=copySceneCheckpoint('jackal',{version:1,hero:'jackal',data}).data,s=d.state;
  if(d.schema!=='jackal-rescue-v2'||d.id!==JACKAL_ROOM.id||!s||!Number.isSafeInteger(s.tick)||s.tick<0||!Number.isFinite(s.cameraX)||s.cameraX<0||s.cameraX>255||!Number.isSafeInteger(s.scrollCounter)||s.scrollCounter<240||s.scrollCounter>2878||s.cameraY!==2880-s.scrollCounter||d.ppu?.counter!==s.scrollCounter||!Number.isInteger(s.retreatBudget)||s.retreatBudget<0||s.retreatBudget>64||typeof s.autoScroll!=='boolean'||!['default','boss'].includes(s.palette)||
   !Number.isInteger(s.boss?.generated)||s.boss.generated<0||s.boss.generated>4||!Array.isArray(s.boss.defeatedIds)||new Set(s.boss.defeatedIds).size!==s.boss.defeatedIds.length||s.boss.defeatedIds.some(id=>!/^jackal-boss-[1-4]$/.test(id))||s.boss.defeatedIds.length>s.boss.generated||
   ['cleared','rewardClaimed','failed','exited'].some(k=>typeof s[k]!=='boolean')||s.cleared&&s.boss.defeatedIds.length!==4||s.exited&&(!s.cleared||!s.rewardClaimed)||!Array.isArray(s.enemies)||s.enemies.length>48||
   ![d.body?.x,d.body?.y].every(Number.isFinite)||d.body.x<0||d.body.x>500||d.body.y<0||d.body.y>2868||![0,1].includes(d.body.protection))throw new TypeError('Invalid Jackal rescue checkpoint');
  counters(s.counters);if(!Number.isInteger(s.flashTimer)||s.flashTimer<0||s.flashTimer>128||!Number.isInteger(s.flashCycle)||s.flashCycle<0||s.flashCycle>3||![-1,0,1,2].includes(s.flashPalette))throw new TypeError('Invalid Jackal palette state');
  for(const [key,max]of [['spawnedIds',spawnRecords.length],['pows',256],['cargo',8],['deliveredIds',256],['objects',24],['grantedIds',1]])if(!Array.isArray(s[key])||s[key].length>max)throw new TypeError('Invalid Jackal scene '+key);
  if(new Set(s.spawnedIds).size!==s.spawnedIds.length||s.spawnedIds.some(id=>!spawnRecords.some(r=>r.id===id))||new Set(s.cargo).size!==s.cargo.length||new Set(s.deliveredIds).size!==s.deliveredIds.length||
   [...s.cargo,...s.deliveredIds].some(id=>!s.pows.some(q=>q.id===id&&q.picked))||new Set(s.enemies.map(e=>e.id)).size!==s.enemies.length||s.rewardClaimed&&s.reward||s.grantedIds.some(id=>id!==JACKAL_REWARD.id)||s.grantedIds.length&&!s.rewardClaimed)throw new TypeError('Inconsistent Jackal scene receipt');
  for(const e of s.enemies){foes.definition(e);if(!['x','y','w','h','hp','age','deathAge'].every(k=>Number.isFinite(e[k]))||e.w<=0||e.h<=0||e.dead&&!e.defeatEvent&&e.type!=='round-bullet')throw new TypeError('Invalid Jackal enemy state');if(e.type==='round-bullet')validateJackalRoundBullet(e);}
  for(const q of s.pows)if(typeof q.id!=='string'||!['x','y','w','h','age','exitDelay','exitFrames','dx','dy'].every(k=>Number.isFinite(q[k]))||q.w!==8||q.h!==12||q.age<0||!['picked','delivered','power'].every(k=>typeof q[k]==='boolean')||q.delivered&&!q.picked)throw new TypeError('Invalid Jackal POW state');
  ppu.setPatches(s.backgroundPatches);ppu.restore(d.ppu);state=clone(s);state.pendingEnemies=[];renderEpoch=++nextRenderEpoch;Object.assign(p,d.body);p.dying=state.failed;p.hp=state.failed?0:1;foes.restore(d.foes);actor.prepareRoom(makeWorld());return true;
 }
 function restoreScene(data){restoreData(data);audio.cancel();audio.begin({victory:state.cleared});return true;}
 function grantCompletionBonus(award){if(!state.cleared||!state.rewardClaimed)throw new Error('Cannot grant uncollected Jackal prize');if(state.grantedIds.includes(award.id))return false;
  state.counters=addRoomReward(state.counters,award);state.grantedIds.push(award.id);if(award.lives)audio.play('jackal_extralife');return true;}
 function leave(){audio.cancel();actor?.dispose();actor=p=foes=state=world=null;previous={};paused=false;return true;}
 const runtime={capture:()=>null,activate(){activated=true;return true;},restore(value){if(value!==null)throw new TypeError('Jackal runtime snapshot must be independent');activated=false;return true;},
  readCarry:()=>state?{...state.counters}:{score:0,coins:0,lives:0},step,draw:()=>render.scene(view()),clear(){leave();return true;},
  restoreEquipment(carry,options={}){if(!actor)throw new Error('Jackal scene absent');if(carry.protection!==undefined&&![0,1].includes(carry.protection))throw new TypeError('Invalid Jackal protection');actor.restoreCarry(p,carry.native||{version:1,actor:'jackal',tier:0,heading:1});if(!options.retry)p.protection=carry.protection||0;return true;},
  health:()=>view(),pause(){if(actor&&!paused){audio.pause();paused=true;actor.pause();}return true;},resume(){if(actor&&paused){paused=false;actor.resume();audio.resume();}return true;},
  audio(playing=true){if(playing&&!paused&&alive())audio.tick();return true;}};
 return {chapter:15,rules:JACKAL_RULE,runtime,inputAdapter,enter,step,view,snapshotScene,restoreScene,grantCompletionBonus,
  migrateCheckpoint(checkpoint){
   const copied=copySceneCheckpoint('jackal',checkpoint),d=copied.data;
   if(d.schema==='jackal-rescue-v1'||d.schema==='jackal-rescue-retry-v1')return null;
   if(!['jackal-rescue-v2','jackal-rescue-retry-v2'].includes(d.schema))throw new TypeError('Unknown Jackal checkpoint');
   const room=d.schema==='jackal-rescue-retry-v2'?d.checkpoint:d;
   if(room?.schema!=='jackal-rescue-v2'||!Array.isArray(room.state?.enemies))throw new TypeError('Invalid Jackal legacy projectile checkpoint');
   const rounds=room.state.enemies.filter(e=>e.type==='round-bullet');
   for(const e of rounds)if(e.sourceProjectileVersion!==undefined)validateJackalRoundBullet(e);
   if(!rounds.some(e=>e.sourceProjectileVersion===undefined))return checkpoint;
   // Old rounds cannot reveal their shooter/type. Explicitly retain room
   // progress and restart through the already declared retry clearing rule.
   room.state.enemies=room.state.enemies.filter(e=>e.type!=='round-bullet');
   copied.data={schema:'jackal-rescue-retry-v2',checkpoint:room};
   return {action:'restart',checkpoint:copied};
  },
  retryCheckpoint:()=>({schema:'jackal-rescue-retry-v2',checkpoint:snapshotScene()}),leave,draw:runtime.draw,pause:runtime.pause,resume:runtime.resume,audio:runtime.audio};
}
