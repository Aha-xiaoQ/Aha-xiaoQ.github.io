import {createJackalActor,JACKAL_INPUT} from '../../characters/jackal/actor.mjs';
import {jackalHeading} from '../../characters/jackal/motion.mjs';
import {createDeclaredInputAdapter,inputEdge} from '../../engine/input-contract.mjs';
import {copySceneCheckpoint} from '../../engine/scene-state.mjs';
import {copyRewardReceipt,addRoomReward} from '../../engine/reward-receipt.mjs';
import {firstProjectileContact} from '../../engine/world-collision.mjs';
import {canHitEnemy} from '../../engine/enemy-contract.mjs';
import {overlap,clamp} from '../../engine/geometry.mjs';
import {nativeArenaWidth} from '../../engine/viewport.mjs';
import {beginHiddenDeparture,stepHiddenDeparture,hiddenDepartureFrame,validateHiddenDeparture,migrateHiddenDeparture} from '../hidden-departures.mjs';
import {createJackalMedusaEnemies} from './medusa-enemies.mjs';
export const JACKAL_MEDUSA_ROOM=Object.freeze({id:'jackal-level2-medusa',width:512,height:240,viewportWidth:256,viewportHeight:240,exit:Object.freeze({x:238,y:172,w:36,h:32})});
export const JACKAL_MEDUSA_HUD_HEIGHT=24;
export const JACKAL_MEDUSA_VIEW_HEIGHT=JACKAL_MEDUSA_ROOM.height+JACKAL_MEDUSA_HUD_HEIGHT;
export function jackalMedusaViewportWidth(width){return Math.min(JACKAL_MEDUSA_ROOM.width,nativeArenaWidth(width*JACKAL_MEDUSA_VIEW_HEIGHT/JACKAL_MEDUSA_ROOM.height));}
export const JACKAL_MEDUSA_REWARD=Object.freeze({id:'hidden-clear:jackal',equipment:'jackal-weapon',score:1000,lives:1});
const clone=v=>JSON.parse(JSON.stringify(v));
let nextEpoch=0;
const counters=v=>{const out={};for(const k of ['score','coins','lives']){if(!Number.isSafeInteger(v?.[k])||v[k]<0)throw new TypeError('Invalid Medusa campaign counter');out[k]=v[k];}return out;};
/** Source-owned L2 room. Host supplies clock/input, owns exactly one life
 * debit and reward ledger. Scene/actor state never leaks through carry. */
export function createJackalMedusa({source,render,audio,emit=()=>{},viewport=()=>256,debug=false}){
 for(const k of ['player','weapon','pickup','scene'])if(typeof render?.[k]!=='function')throw new TypeError('Medusa renderer missing '+k);
 for(const k of ['play','begin','tick','victory','pause','resume','cancel','stopMood'])if(typeof audio?.[k]!=='function')throw new TypeError('Medusa audio missing '+k);
 if(source?.version!==1||source.level!==2||source.width!==512||source.height!==240||source.geometry?.length<1)throw new TypeError('Original Medusa room missing');
 let actor=null,p=null,state=null,foes=null,world=null,previous={},paused=false,renderEpoch=0;
 const inputAdapter=createDeclaredInputAdapter(JACKAL_INPUT),alive=()=>state&&!state.failed&&!state.defeating&&!state.exited;
 function syncViewport(){
  if(!state)return;
  const width=jackalMedusaViewportWidth(viewport());
  if(state.viewportWidth===width)return;
  state.viewportWidth=width;state.cameraX=clamp(p.x+p.w/2-width/2,0,Math.min(255,source.width-width));
 }
 function damagePlayer(){
  if(!alive()||p.dying||p.invuln>0)return false;
  if(p.protection||actor.isUpgraded(p)){
   actor.downgrade(p);p.protection=0;p.invuln=160;p.jackalHurtUntil=state.tick+160;
   audio.play('mainline-powerdown');return true;
  }
  state.defeating=true;state.deathAge=0;p.hp=0;p.dying=true;actor.beginDeath(p);actor.sound('death');audio.cancel({preserveDeath:true});return true;
 }
 function patch(e,name){const q=source.replacements[name],id=e.id+':'+(name==='destroyed'?'destroyed':name==='eyes'||name==='flash'?'eyes':'mouth'),
  x=Math.floor((e.x+e.w/2+q.offset[0])/8)*8,y=Math.floor((e.y+e.h/2+q.offset[1]+source.scroll)/8)*8-source.scroll,
  value={id,x,y,size:[...q.size],tiles:[...q.tiles],collision:q.collision};
  const index=state.backgroundPatches.findIndex(q=>q.id===id);if(index<0)state.backgroundPatches.push(value);else state.backgroundPatches[index]=value;
 }
 function geometry(){
  const cells=new Map(source.geometry.map(q=>[q.x+':'+q.y,{...q}]));
  for(const q of state.backgroundPatches)for(let yy=0;yy<q.size[1];yy++)for(let xx=0;xx<q.size[0];xx++){
   const x=q.x+xx*8,y=q.y+yy*8,key=x+':'+y;cells.delete(key);if(q.collision)cells.set(key,{id:q.id+':'+xx+':'+yy,x,y,w:8,h:8,collision:'solid',sourceCollision:q.collision});
  }return [...cells.values()];
 }
 function makeWorld(){const solids=geometry();
  function query(shot,from,to,o={},grenade=false){
   const targets=state.enemies.filter(e=>canHitEnemy(e)&&e.phase!=='explosion'&&e.sourceState!==0&&foes.definition(e).targetable),
    terrain=solids.filter(g=>g.sourceCollision===1&&!targets.some(e=>overlap(g,e))),
    hit=firstProjectileContact(from,to,{geometry:grenade?[]:terrain,enemies:targets,radius:o.radius||0,canHit:e=>canHitEnemy(e)});
   if(!hit)return null;if(hit.kind==='enemy')foes.hurt(hit.entity,o.damage||1,{kind:o.kind,tick:state.tick,id:shot.attackInstanceId||shot.id});
   return {kind:hit.kind,x:hit.x,y:hit.y,targetId:hit.entity.id};
  }
  world={width:512,height:240,currentLevel:1,mainline:false,roomId:JACKAL_MEDUSA_ROOM.id,player:p,enemies:state.enemies,solids,
   get tick(){return state.tick;},get cameraY(){return 0;},get remainingHeads(){return 4-state.retiredHeadIds.length;},
   projectile:(...args)=>query(...args),grenadeProjectile:(shot,from,to,o)=>query(shot,from,to,o,true),
   blocksProjectile:(from,to)=>!!firstProjectileContact(from,to,{geometry:solids.filter(g=>g.sourceCollision===1),enemies:[],radius:1}),
   // Original sixteen object slots also reserve controller/end-check slots.
   spawnEnemy(e){if(state.enemies.filter(q=>!q.remove).length+state.pendingEnemies.length<14)state.pendingEnemies.push(e);},
   damage:damagePlayer,damageEnemy:(e,d,h)=>foes.hurt(e,d,{...h,tick:state.tick}),kill:(e,h)=>foes.kill(e,{...h,tick:state.tick}),enemyDefinition:foes.definition,breakBlock:()=>false};
  return world;
 }
 function score(n){state.counters.score=Math.min(9999999999,state.counters.score+n);}
 function onEvent(name,event){
  if(name==='boss-music-stop-request'&&event.last)audio.stopMood();
  if(name==='medusa-background-stage'){const e=state.enemies.find(q=>q.id===event.entityId);if(e)patch(e,event.name);}
  if(name==='medusa-background-destroyed'){const e=state.enemies.find(q=>q.id===event.entityId);if(e)patch(e,'destroyed');}
  if(name==='enemy-retired'&&event.authoritativeDeath&&event.contractId==='jackal-nes:medusa-head'&&!state.retiredHeadIds.includes(event.entityId))state.retiredHeadIds.push(event.entityId);
  emit(name,event);
 }
 function openSpawn(preferred={x:244,y:192}){const solids=geometry();
  for(let r=0;r<=240;r+=8)for(const dx of r?[r,-r]:[0])for(const dy of [0,-16,16,-32,32]){const q={x:clamp(preferred.x+dx,10,490),y:clamp(preferred.y+dy,64,214),w:12,h:12};if(!solids.some(g=>overlap(q,g)))return q;}
  throw new Error('Original Medusa room has no open entry');
 }
 function enter({carry,retry=false,scene=null,rewardReceipt}={}){
  if(actor)throw new Error('Medusa already entered');const base=counters(carry);renderEpoch=++nextEpoch;
  state={tick:0,seed:1,cameraX:128,viewportWidth:256,counters:base,enemies:[],pendingEnemies:[],backgroundPatches:[],generated:0,spawnTimer:source.spawnInterval,controllerPhase:0,tankLow:0,tankHigh:0,
   retiredHeadIds:[],reward:null,rewardClaimed:copyRewardReceipt('jackal',rewardReceipt).claimed,cleared:false,failed:false,defeating:false,deathAge:0,exited:false,departure:null,grantedIds:[]};
  actor=createJackalActor({render,audio});p=actor.create({width:12,height:12},{x:244,y:192});p.protection=retry?0:carry.protection||0;
  foes=createJackalMedusaEnemies({source,cue:audio.play,emit:onEvent,award:score,closePressure:true});
  // Original final approach contains these two white platform turrets. The
  // standalone crossover begins at Boss room, not the preceding full L2 route.
  for(const [n,x]of [176,336].entries())state.enemies.push(foes.spawn({id:'medusa-room-turret-'+n,sourceId:5,x},138));
  makeWorld();actor.prepareRoom(world);previous={};paused=false;
  if(retry&&scene?.data?.schema==='jackal-medusa-retry-v1'){
   restoreData(scene.data.checkpoint);state.counters=base;state.enemies=state.enemies.filter(e=>!['medusa-missile','round-bullet'].includes(e.type));state.failed=state.defeating=false;state.deathAge=0;state.exited=false;state.departure=null;p.hp=1;p.dying=false;p.protection=0;p.invuln=160;
  }
  const safe=openSpawn({x:p.x,y:p.y});p.x=safe.x;p.y=safe.y;syncViewport();actor.prepareRoom(makeWorld());audio.begin({boss:!state.cleared,victory:state.cleared});return true;
 }
 function followPlayer(){
  const width=state.viewportWidth,maxCamera=Math.min(255,source.width-width),cx=p.x+p.w/2-state.cameraX;
  if(cx<width/4&&state.cameraX>0)state.cameraX--;else if(cx>=width*3/4&&state.cameraX<maxCamera)state.cameraX++;
  state.cameraX=clamp(state.cameraX,0,maxCamera);
 }
 function step(raw={}){
  if(state?.defeating&&!paused){state.tick++;actor.deathStep(p);if(++state.deathAge>=24){state.defeating=false;state.failed=true;}return;}
  if(!alive()||paused)return;syncViewport();const input=inputAdapter(raw,previous);previous={...input};state.tick++;state.seed=(state.seed+1)&255;
  if(state.departure){state.exited=stepHiddenDeparture(state.departure,{body:p,motion:actor.transportMotion,world:makeWorld()});followPlayer();audio.tick();return;}
  makeWorld();actor.step(p,input,world);
  followPlayer();
  p.x=clamp(p.x,state.cameraX+10,state.cameraX+state.viewportWidth-22);p.y=clamp(p.y,42,218);
  if(state.controllerPhase===0)state.controllerPhase=1;
  else if(state.generated<4&&--state.spawnTimer===0){state.enemies.push(foes.head(3-state.generated++));state.spawnTimer=source.spawnInterval;}
  else if(state.controllerPhase===1&&state.generated===4){if(--state.spawnTimer===0)state.controllerPhase=2;}
  else if(state.controllerPhase===2){
   // Original 16-bit low--/high++ every512 eligible calls, gated on weapon
   // difficulty>=2. Bonus tanks deliberately award no score.
   if(((1+p.jackalTier)>>1)>=2&&(state.tankLow=(state.tankLow-1)&255)===0){state.tankHigh=(state.tankHigh+1)&255;if(!(state.tankHigh&1)){
    const x=clamp(state.seed,80,176)*2,e=foes.spawn({id:'medusa-bonus-tank-'+state.tick,sourceId:7,x},239);e.noPoints=true;state.pendingEnemies.push(e);
   }}
  }
  makeWorld();actor.combat(p,input,world);foes.crush(p,state.enemies.filter(e=>e.type==='infantry'),state.tick);
  for(const e of state.enemies){foes.step(e,world);if(!alive())break;}state.enemies.push(...state.pendingEnemies);state.pendingEnemies=[];
  for(const e of state.enemies){
   if(!canHitEnemy(e)||e.remove||!overlap(p,e)||p.invuln>0||e.type==='medusa-head')continue;
   damagePlayer();if(!alive())break;
  }
  state.enemies=state.enemies.filter(e=>!e.remove);
  // A fatal source projectile ends this simulation frame; rewards and victory
  // must not revive the Jeep or restart music during its explosion.
  if(!alive())return;
  if(state.generated===4&&state.retiredHeadIds.length===4&&!state.cleared){state.cleared=true;audio.victory();if(!state.rewardClaimed)state.reward={id:'jackal-medusa-reward',kind:'native-supply',nativeType:'jackal-upgrade',tier:Math.min(3,p.jackalTier+1),x:248,y:132,w:16,h:16};}
  if(state.reward&&!state.rewardClaimed&&overlap(p,state.reward)){if(actor.pickup(p,state.reward)!==false){const item=state.reward;p.protection=1;state.rewardClaimed=true;state.reward=null;onEvent('item-collected',{entityId:item.id,kind:item.kind,nativeType:item.nativeType});}}
  audio.tick();
 }
 function beginDeparture(){
  if(state?.departure||state?.exited)return true;
  if(!alive()||paused||!state.cleared||!state.rewardClaimed)return false;
  state.departure=beginHiddenDeparture('helicopter',p,{motion:actor.transportMotion});return true;
 }
 function view(){if(!state||!p)return{};syncViewport();return {hero:'jackal',id:JACKAL_MEDUSA_ROOM.id,title:'赤色要塞 · 美杜莎',mode:paused?'paused':'playing',area:'boss',logicalWidth:state.viewportWidth,logicalHeight:JACKAL_MEDUSA_VIEW_HEIGHT,
  healthMode:'protection',protection:p.protection||0,hp:p.hp,maxHp:1,carry:{...state.counters},nativeCarry:actor.carry(p),rewardClaimed:state.rewardClaimed,
  cleared:state.cleared&&state.rewardClaimed,exited:state.exited,exitReady:state.cleared&&state.rewardClaimed,failed:state.failed,defeating:!!state.defeating,deathPresentationComplete:state.failed&&state.deathAge>=24,body:{...p},
  progress:{tick:state.tick,x:p.x,y:p.y,bossGenerated:state.generated,bossDefeated:state.retiredHeadIds.length},cameraX:state.cameraX,cameraY:0,renderEpoch,
  backgroundPatches:clone(state.backgroundPatches),enemies:clone(state.enemies),reward:state.reward&&{...state.reward},weapons:actor.view().weapons,departure:state.departure?hiddenDepartureFrame(state.departure,p):null};}
 const motionState=()=>({x:p.x,y:p.y,vx:p.vx,vy:p.vy,grounded:p.grounded,facing:p.facing,jackalHeading:p.jackalHeading,jackalTendency:p.jackalTendency});
 function snapshotScene(){if(!state)throw new Error('Medusa absent');syncViewport();const {pendingEnemies,...data}=state;return {schema:'jackal-medusa-v1',id:JACKAL_MEDUSA_ROOM.id,state:clone(data),body:{...motionState(),protection:p.protection||0,invuln:p.invuln||0,jackalHurtUntil:p.jackalHurtUntil||0},foes:foes.snapshot()};}
 function restoreData(data){const d=copySceneCheckpoint('jackal',{version:1,hero:'jackal',data}).data,s=d.state;
  if(d.schema!=='jackal-medusa-v1'||d.id!==JACKAL_MEDUSA_ROOM.id||!s||!Number.isSafeInteger(s.tick)||s.tick<0||!Number.isFinite(s.cameraX)||s.cameraX<0||s.cameraX>255||
   !Number.isInteger(s.generated)||s.generated<0||s.generated>4||!Array.isArray(s.retiredHeadIds)||new Set(s.retiredHeadIds).size!==s.retiredHeadIds.length||s.retiredHeadIds.some(id=>!/^jackal-medusa-[0-3]$/.test(id))||s.retiredHeadIds.length>s.generated||
   ['cleared','rewardClaimed','failed','exited'].some(k=>typeof s[k]!=='boolean')||s.cleared&&s.retiredHeadIds.length!==4||s.exited&&(!s.cleared||!s.rewardClaimed)||
   !Array.isArray(s.enemies)||s.enemies.length>14||new Set(s.enemies.map(e=>e.id)).size!==s.enemies.length||!Array.isArray(s.backgroundPatches)||s.backgroundPatches.length>12||!Array.isArray(s.grantedIds)||s.grantedIds.length>1||s.grantedIds.some(id=>id!==JACKAL_MEDUSA_REWARD.id)||s.grantedIds.length&&!s.rewardClaimed||
   ![d.body?.x,d.body?.y,d.body?.invuln].every(Number.isFinite)||d.body.x<0||d.body.x>500||d.body.y<0||d.body.y>228||![0,1].includes(d.body.protection))throw new TypeError('Invalid Medusa checkpoint');
  if(d.body.jackalHurtUntil!==undefined&&(!Number.isSafeInteger(d.body.jackalHurtUntil)||d.body.jackalHurtUntil<0||d.body.jackalHurtUntil>s.tick+160))throw new TypeError('Invalid Medusa hurt presentation');
  for(const key of ['jackalHeading','jackalTendency'])if(d.body[key]!==undefined&&(!Number.isInteger(d.body[key])||d.body[key]<1||d.body[key]>8))throw new TypeError('Invalid Medusa motion heading');
  for(const key of ['vx','vy'])if(d.body[key]!==undefined&&(!Number.isFinite(d.body[key])||Math.abs(d.body[key])>1))throw new TypeError('Invalid Medusa motion velocity');
  if(d.body.grounded!==undefined&&typeof d.body.grounded!=='boolean'||d.body.facing!==undefined&&![-1,1].includes(d.body.facing))throw new TypeError('Invalid Medusa motion pose');
  if(s.viewportWidth!==undefined&&![256,nativeArenaWidth(1280/3),jackalMedusaViewportWidth(256),jackalMedusaViewportWidth(1280/3)].includes(s.viewportWidth))throw new TypeError('Invalid Medusa viewport');
  if(s.defeating!==undefined&&typeof s.defeating!=='boolean'||s.deathAge!==undefined&&(!Number.isInteger(s.deathAge)||s.deathAge<0||s.deathAge>24)||s.defeating&&(s.failed||s.exited||s.departure||!Number.isInteger(s.deathAge)||s.deathAge>=24))throw new TypeError('Invalid Medusa death phase');
  if(s.cameraX>Math.min(255,source.width-(s.viewportWidth??256)))throw new TypeError('Invalid Medusa viewport camera');
  if(s.departure!=null){validateHiddenDeparture(s.departure);if(s.departure.kind!=='helicopter'||!s.cleared||!s.rewardClaimed||s.exited!==hiddenDepartureFrame(s.departure,{...p,...d.body}).complete)throw new TypeError('Invalid Medusa departure');
   if(s.departure.schema==='hidden-departure-v2'&&['vx','vy','grounded','facing','jackalHeading','jackalTendency'].some(k=>d.body[k]===undefined))throw new TypeError('Missing Medusa departure motion');}
  counters(s.counters);for(const e of s.enemies){foes.definition(e);if(!['x','y','w','h','hp','age'].every(k=>Number.isFinite(e[k]))||e.w<=0||e.h<=0)throw new TypeError('Invalid Medusa entity');foes.validateSnapshot(e);}
  for(const q of s.backgroundPatches)if(typeof q.id!=='string'||![q.x,q.y].every(Number.isFinite)||!Array.isArray(q.size)||![1,4].includes(q.size[0])||q.size[1]!==q.size[0]||q.tiles?.length!==q.size[0]*q.size[1]||q.tiles.some(t=>!Number.isInteger(t)||t<0||t>255)||![1,2].includes(q.collision))throw new TypeError('Invalid Medusa background patch');
  state=clone(s);state.viewportWidth??=256;state.defeating??=false;state.deathAge??=0;state.pendingEnemies=[];renderEpoch=++nextEpoch;Object.assign(p,{jackalHurtUntil:0},d.body);p.dying=state.failed||state.defeating;p.hp=p.dying?0:1;p.jackalDeathTick=state.tick-state.deathAge;
  if(state.departure?.schema==='hidden-departure-v1'){
   // The old renderer projected this heading; recover it only during migration.
   const d=state.departure,frame=hiddenDepartureFrame(d),heading=jackalHeading(frame.body.vx,frame.body.vy)||jackalHeading(d.landingX-p.w/2-d.origin.x,d.landingY-p.h-d.origin.y);
   if(heading)p.jackalHeading=p.jackalTendency=heading;
   state.departure=migrateHiddenDeparture(d,p,actor.transportMotion);
  }
  foes.restore(d.foes);syncViewport();actor.prepareRoom(makeWorld());return true;
 }
 function restoreScene(data){restoreData(data);audio.cancel();if(!p.dying)audio.begin({boss:!state.cleared,victory:state.cleared});return true;}
 function grantCompletionBonus(award){if(!state.cleared||!state.rewardClaimed)throw new Error('Cannot grant uncollected Medusa prize');if(state.grantedIds.includes(award.id))return false;state.counters=addRoomReward(state.counters,award);state.grantedIds.push(award.id);if(award.lives)audio.play('jackal_extralife');return true;}
 function leave(){audio.cancel();actor?.dispose();actor=p=state=foes=world=null;paused=false;previous={};return true;}
 const runtime={capture:()=>null,activate:()=>true,restore(v){if(v!==null)throw new TypeError('Medusa runtime snapshot must be independent');return true;},readCarry:()=>state?{...state.counters}:{score:0,coins:0,lives:0},step,draw:()=>render.scene(view()),clear(){leave();return true;},
  restoreEquipment(carry,options={}){if(!actor)throw new Error('Medusa absent');const motion=state.departure?motionState():null;actor.restoreCarry(p,carry.native||{version:1,actor:'jackal',tier:0,heading:1});if(motion)Object.assign(p,motion);if(!options.retry)p.protection=carry.protection||0;return true;},health:()=>view(),
  pause(){if(actor&&!paused){audio.pause();paused=true;actor.pause();}return true;},resume(){if(actor&&paused){paused=false;actor.resume();audio.resume();}return true;},audio(playing=true){if(playing&&!paused&&alive())audio.tick();return true;}};
 return {chapter:15,rules:{health:'protection',hud:'jackal'},runtime,inputAdapter,enter,step,view,beginDeparture,snapshotScene,restoreScene,grantCompletionBonus,
  ...(debug?{diagnostics:()=>({state:view(),snapshot:snapshotScene,restore:restoreScene,
   place(body){for(const k of ['x','y'])if(body[k]!==undefined){if(!Number.isFinite(body[k]))throw new TypeError('Invalid diagnostic position');p[k]=body[k];}},
   strike(id,amount=5){const e=state.enemies.find(q=>q.id===id);if(!e)throw new Error('Unknown diagnostic Medusa enemy');return makeWorld().damageEnemy(e,amount,{id:'diagnostic-'+state.tick+'-'+id,kind:'jackal-main-weapon'});}})}:{}),
  migrateCheckpoint(checkpoint){const d=copySceneCheckpoint('jackal',checkpoint).data;if(['jackal-rescue-v1','jackal-rescue-retry-v1','jackal-rescue-v2','jackal-rescue-retry-v2'].includes(d.schema))return null;
   if(!['jackal-medusa-v1','jackal-medusa-retry-v1'].includes(d.schema))throw new TypeError('Unknown Jackal checkpoint');return checkpoint;},
  retryCheckpoint:()=>({schema:'jackal-medusa-retry-v1',checkpoint:snapshotScene()}),leave,draw:runtime.draw,pause:runtime.pause,resume:runtime.resume,audio:runtime.audio};
}
