import {resolveWalkPresentation} from '../../engine/motion-presentation.mjs';
import {createEnemyRegistry,createEnemyResolver,bindEnemyHandlers,createEnemyContactSystem,canHitEnemy} from '../../engine/enemy-contract.mjs';
import {overlap} from '../../engine/geometry.mjs';
import {jackalHeading,turnJackal,JACKAL_DIRECTIONS,moveJackal} from '../../characters/jackal/motion.mjs';
import {JACKAL_PROJECTILE_TABLES,jackalDifficulty,jackalShotParameters,jackalSourceDistance,stepJackalRoundBullet} from './source-projectiles.mjs';

import {stepJackalTank,stepJackalInfantry} from './source-locomotion.mjs';

const source='NES-Jackal-US:Bank6+Bank7/UEFI8309f5';
const row=(id,model,collision,animation,sound,score,targetable=true)=>({id:'jackal-nes:'+id,origin:'jackal-nes',owner:'foe-port',source,
 movement:{model,collision},hurt:{handler:'jackal',animation:'original-palette-flash',sound:'jackal_hardhit'},
 death:{handler:'jackal',animation,sound,retire:'native-countdown-remove'},contact:{stomp:'source',attack:'damage',damage:1,crush:['infantry','sentry'].includes(id)},starKill:true,targetable,score});
export const JACKAL_ENEMIES=Object.freeze([
 row('infantry','source-mobile-infantry','solid','original-infantry-32-frame-death','jackal_infantrydeath',100),
 row('sentry','source-stationary-infantry','scripted','original-infantry-32-frame-death','jackal_infantrydeath',100),
 row('turret','source-gray-turret','scripted','original-three-size-explosion','jackal_impact',500),
 row('tank','source-red-medium-tank','solid','original-three-size-explosion','jackal_impact',500),
 {...row('bomber','source-horizontal-bomber','scripted','original-three-size-explosion','jackal_impact',1000),contact:{stomp:'source',body:'none'},hurt:{handler:'jackal',animation:'original-palette-flash',sound:'jackal_hardhit',ignoredAttacks:['jackal-machinegun']}},
 row('boat','source-attack-boat','scripted','original-three-size-explosion','jackal_impact',600),
 row('barracks','source-pow-building','scripted','original-building-opening','jackal_barracksopen',600),
 row('gate','source-level1-gate','scripted','original-gate-opening','source-silent',0),
 row('boss-tank','source-level1-boss-tank','solid','original-boss-explosion-retirement','jackal_impact',600),
 row('round-bullet','source-round-shell','projectile','original-small-explosion','jackal_hardhit',0,false),
]);
const def=createEnemyResolver({registry:createEnemyRegistry(JACKAL_ENEMIES)});
export const jackalEnemyDefinition=e=>def(e);
const specFor={1:['infantry',1,8,12],2:['sentry',1,8,12],5:['turret',3,24,24],6:['turret',4,24,24],7:['tank',4,24,24],8:['boat',6,24,24],19:['barracks',1,24,24],21:['barracks',1,24,24],27:['gate',1,32,32],28:['barracks',1,24,24],29:['barracks',1,24,24]};
export function createJackalFoes({cue=()=>{},emit=()=>{},award=()=>{}}={}){
 let serial=0;
 function defeat(e,event){if(!canHitEnemy(e))return false;e.dead=true;e.deathAge=0;e.crushed=['infantry','sentry'].includes(e.type);e.hp=0;
  if(def(e).death.sound!=='source-silent')cue(def(e).death.sound);return true;}
 const handlers=bindEnemyHandlers({definition:def,owners:{jackal:{hurt(e,damage,event={}){if(!canHitEnemy(e)||!Number.isFinite(damage)||damage<=0)return false;
  e.hp=Math.max(0,e.hp-damage);e.flash=6;if(e.hp>0&&event.kind!=='jackal-main-weapon')cue('jackal_hardhit');return true;},defeat}}});
 const contacts=createEnemyContactSystem({definition:def,defeat:(e,event)=>handlers.defeat(e,event),award,emit});
 function spawn(record,y){const spec=specFor[record.sourceId];if(!spec)throw new TypeError('Uninstalled Jackal spawn source: '+record.sourceId);
  const [type,hp,w,h]=spec;return {id:record.id,sourceId:record.sourceId,contractId:'jackal-nes:'+type,nativeOwner:'foe-port',foeSource:'jackal-nes',type,hp,maxHp:hp,
   x:record.x-w/2,y:y-h/2,w,h,vx:0,vy:0,heading:5,phase:'approach',phaseAge:0,age:0,flash:0,dead:false,deathAge:0,remove:false};}
 function boss(index,x,y,fromBottom){return {id:'jackal-boss-'+index,sourceId:10,contractId:'jackal-nes:boss-tank',nativeOwner:'foe-port',foeSource:'jackal-nes',jackalProjection:'topdown',type:'boss-tank',hp:10,maxHp:10,
  x:x-12,y:y-12,w:24,h:24,vx:0,vy:0,heading:fromBottom?1:5,phase:'approach',phaseAge:0,approachFrames:fromBottom?24:48,age:0,flash:0,dead:false,deathAge:0,remove:false};}
 function hurt(e,damage,attack){const id=attack.attackInstanceId||attack.id;if(id&&(e.attackIds||[]).includes(id))return false;
  // Original main weapon clears non-armoured health; a Boss keeps high-bit
  // numeric armour and takes MainWeaponBaseDamage (5) instead.
  if(attack.kind==='jackal-main-weapon'&&e.type!=='boss-tank')damage=e.hp;
  if(!handlers.hurt(e,damage,attack))return false;
  if(id){e.attackIds??=[];e.attackIds.push(id);if(e.attackIds.length>64)e.attackIds.shift();}if(e.hp<=0)contacts.kill(e,{cause:attack.kind||'attack',tick:attack.tick||0});return true;}
 function shell(e,world){const q=jackalShotParameters(e,world.player,{currentLevel:world.currentLevel??0,weaponTier:world.player.jackalTier??0});
  const s={id:'jackal-shell-'+(++serial),contractId:'jackal-nes:round-bullet',nativeOwner:'foe-port',foeSource:'jackal-nes',jackalProjection:'topdown',type:'round-bullet',sourceId:54,hp:1,maxHp:1,
   x:q.x-2,y:q.y-2,w:4,h:4,vx:q.vx,vy:q.vy,age:0,dead:false,deathAge:0,remove:false,
   sourceProjectileVersion:1,emitterSourceId:e.sourceId,bulletType:q.bulletType,direction:q.direction,speedByte:q.speedByte,graphicsAttributes:q.graphicsAttributes,
   sourceLifetime:q.lifetime,remainingLifetime:q.lifetime,invisibleRemaining:q.invisible,flightAge:0,visible:false,phase:'initializing'};world.spawnEnemy(s);}
 function infantryFire(e,world){
  const index=jackalDifficulty(world.currentLevel??0,world.player.jackalTier??0),sentry=e.sourceId===2;
  // No native NES sprite-slot allocator exists in this scene. Fresh sentries
  // use the source reload delay instead of inventing an original slot number.
  e.shootCountdown??=sentry?JACKAL_PROJECTILE_TABLES.sentryDelay[index]:64;
  if(e.shootPhase==='flash'){
   e.shootTimer=(e.shootTimer-1)&255;
   if(e.shootTimer===249){e.shootPhase='wait';e.shootPalette=1;return;}
   if((e.shootTimer&7)===0)shell(e,world);
   else if(sentry||e.shootTimer<128)e.shootPalette=((e.shootPalette??1)+1)&3;
   return;
  }
  if(--e.shootCountdown>0)return;
  e.shootCountdown=sentry?JACKAL_PROJECTILE_TABLES.sentryDelay[index]:64;
  const radius=sentry?64:JACKAL_PROJECTILE_TABLES.mobileNoShoot[index];
  if(world.player.dying||jackalSourceDistance(e,world.player)<radius)return;
  e.shootPhase='flash';e.shootTimer=JACKAL_PROJECTILE_TABLES.infantryFlash[index];e.shootPalette=1;
 }
 function step(e,world){handlers.validate(e);if(e.remove)return true;
  if(e.type==='round-bullet'&&!e.defeatEvent){e.age++;return stepJackalRoundBullet(e,world);}
  if(e.dead){e.deathAge++;if(e.deathAge>=(e.type==='boss-tank'?32:['barracks','gate'].includes(e.type)?24:e.crushed?32:24)){
   e.remove=true;emit('enemy-retired',{entityId:e.id,contractId:e.contractId,cause:e.defeatEvent?.cause,authoritativeDeath:!!e.defeatEvent});}return true;}
  e.age++;if(e.flash>0)e.flash--;
  const active=e.y+e.h>=world.cameraY-48&&e.y<=world.cameraY+288;if(!active)return true;
  if(['barracks','gate'].includes(e.type))return true;
  const p=world.player,heading=jackalHeading(p.x+p.w/2-e.x-e.w/2,p.y+p.h/2-e.y-e.h/2)||e.heading;
  if(e.type==='boss-tank'){
   e.phaseAge++;
   if(e.phase==='approach'){const [dx,dy]=JACKAL_DIRECTIONS[e.heading-1];moveJackal(e,dx,dy,world);if(e.phaseAge>=e.approachFrames){e.phase='aim';e.phaseAge=0;}}
   else if(e.phase==='aim'){e.heading=turnJackal(e.heading,heading,world.tick);if(e.heading===heading){e.phase='move';e.phaseAge=0;}}
   else{e.heading=turnJackal(e.heading,heading,world.tick);const [dx,dy]=JACKAL_DIRECTIONS[e.heading-1];const moved=moveJackal(e,dx,dy,world);
    if(e.phaseAge%16===0){shell(e,world);e.recoil=4;}if(e.phaseAge>=40||!moved){e.phase='aim';e.phaseAge=0;}}
   if(e.recoil>0)e.recoil--;return true;
  }
  if(e.type==='turret'){e.heading=heading;if(e.age%96===0)shell(e,world);return true;}
  if(e.type==='sentry'){e.heading=heading;infantryFire(e,world);return true;}
  if(e.type==='tank'){stepJackalTank(e,world,()=>shell(e,world));return true;}
  if(e.type==='bomber')return true; // The aircraft timeline owns flight, never ground AI.
  if(e.type==='infantry'){const before={x:e.x,y:e.y};stepJackalInfantry(e,world,()=>infantryFire(e,world));const pose=resolveWalkPresentation(before,e,{vertical:true,age:e.walkAge||0,idleFacing:e.facing||1});e.walkAge=pose.walkAge;e.walkHeading=pose.heading;e.facing=pose.facing;e.motionPresentation=pose;}
  else if(e.type==='boat'){if(e.age<=96){e.x-=.5;e.y+=.5;}if(e.age%48===0)shell(e,world);}
  else{const [dx,dy]=JACKAL_DIRECTIONS[e.heading-1];moveJackal(e,dx*.5,dy*.5,world);if(e.age%32===0)shell(e,world);}
  return true;
 }
 return {spawn,boss,step,hurt,definition:def,kill:contacts.kill,star:contacts.star,
  crush(p,enemies,tick){for(const e of enemies)if(def(e).contact.crush&&canHitEnemy(e)&&Math.abs(p.x+p.w/2-e.x-e.w/2)<13&&Math.abs(p.y+p.h/2-e.y-e.h/2)<13)contacts.kill(e,{cause:'crush',tick});},
  snapshot(){return {serial};},restore(d){if(!Number.isSafeInteger(d?.serial)||d.serial<0)throw new TypeError('Invalid Jackal enemy serial');serial=d.serial;}};
}
