// Bank7 source action timing. Simulation and drawing consume the same blast
// phases; individual renderers cannot extend an expired effect's last frame.
export function jackalExplosionParts(shot){
 const age=shot.blastAge||0,scale=shot.scale||1,parts=[];
 if(age<24)parts.push({name:'effect-explosion-'+['small','medium','large'][Math.floor(age/8)],x:shot.x,y:shot.y,flipY:false,w:24*scale,h:24*scale,scale});
 if(shot.tier>=2&&age<40){
  const size=age<16?'large':age<32?'medium':'small',extent=age*2*scale,w=(size==='large'?16:8)*scale;
  for(const [dx,dy]of [[-1,0],[1,0],...(shot.tier>=3?[[0,-1],[0,1]]:[])])parts.push({name:'effect-bazooka-splash-'+size,x:shot.x+dx*extent,y:shot.y+dy*extent,flipY:!!(age&4),w,h:16*scale,scale});
 }
 return parts;
}
export function jackalInfantryPose(e){
 const moving=!!(e.vx||e.vy),phase=Math.floor((e.walkAge||0)/8)%2;
 const h=e.walkHeading||e.heading||5;
 let name,flipX=false;
 if(e.crushed)name='tblCrushedInfantry';
 else if(e.type==='sentry'||!moving){name='tblInfantryStandingLeft_Right';flipX=h>=6;}
 else if(h===1||h===2||h===8)name='tblInfantryWalkingUp_'+(phase?'LeftFootForward':'RightFootForward');
 else if(h===4||h===5||h===6)name='tblInfantryWalkingDown_'+(phase?'RightFootForward':'LeftFootForward');
 else {name=phase?'tblInfantryStandingLeft_Right':'tblInfantryWalkingLeft_Right';flipX=h===7;}
 return {name:'effect-infantry-'+name,flipX,bottom:name.includes('Standing')||e.crushed?16:15};
}
export function jackalVehicleBob(p,tick){return !p.dying&&(p.vx||p.vy)&&!(tick&4)?1:0;}
// Bank6 POWLoadingIntoHeli states0/1 and Bank7 F80B: unmirrored is
// right, $40 mirrors left. Waiting waves use the source $2B/$2C pair.
export function jackalBoardingPowPose(q){
 const wave=q.phase==='wave',phase=Math.floor((wave?q.age-96:q.age)/8)%2;
 return {name:wave?'tblPOWWaving'+(phase+1):phase?'tblPOWWalkingLeft_RightFeetTogether':'tblPOWWalkingLeft_RightInStride',flipX:q.targetX<q.startX};
}
