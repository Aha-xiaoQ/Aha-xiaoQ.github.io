/** Original indexed L2 room/CHR/OAM; no invented statue sprites or HUD. */
import {JACKAL_MEDUSA_HUD_HEIGHT,JACKAL_MEDUSA_VIEW_HEIGHT} from './medusa.mjs';
export function createJackalMedusaRenderer({base,source,images,originalSource,originalImages,context,viewport,createSurface}){
 if(typeof base?.player!=='function'||!source?.nametables||typeof createSurface!=='function')throw new TypeError('Original Medusa renderer ports required');
 let surface=null,key=null;
 const image=(g,name,x,y,flipX=false,flipY=false)=>{const row=source.images[name],im=images[name];if(!row||!im)throw new Error('Missing original Medusa image '+name);if(!im.naturalWidth)return false;
  g.save();g.translate(Math.round(x),Math.round(y));g.scale(flipX?-1:1,flipY?-1:1);g.drawImage(im,-row.anchor[0],-row.anchor[1]);g.restore();return true;};
 function original(g,name,x,y,center=true){const row=originalSource.images[name],im=originalImages[name];if(!row||!im)throw new Error('Missing original Jackal image '+name);if(!im.naturalWidth)return false;g.drawImage(im,Math.round(x-(center?row.anchor[0]:0)),Math.round(y-(center?row.anchor[1]:0)));return true;}
 function scene(v){const g=context(),{width,height}=viewport(),nativeWidth=v.logicalWidth||256,nativeHeight=v.logicalHeight||JACKAL_MEDUSA_VIEW_HEIGHT,s=Math.min(width/nativeWidth,height/nativeHeight),ox=(width-nativeWidth*s)/2,oy=(height-nativeHeight*s)/2;
  g.save();g.fillStyle='#000';g.fillRect(0,0,width,height);g.translate(ox,oy);g.scale(s,s);g.beginPath();g.rect(0,0,nativeWidth,nativeHeight);g.clip();g.imageSmoothingEnabled=false;
  // Reserve a separate native HUD band instead of painting over the statue
  // heads. The full source room and every world coordinate stay unchanged.
  g.save();g.translate(0,JACKAL_MEDUSA_HUD_HEIGHT);g.beginPath();g.rect(0,0,nativeWidth,240);g.clip();
  const cacheKey=JSON.stringify(v.backgroundPatches);
  if(!surface){surface=createSurface();surface.width=512;surface.height=240;}
  if(key!==cacheKey){const b=surface.getContext('2d');b.imageSmoothingEnabled=false;b.drawImage(images.room,0,0);const atlas=images['background-tiles'];
   for(const q of v.backgroundPatches)for(let yy=0;yy<q.size[1];yy++)for(let xx=0;xx<q.size[0];xx++){
    const x=q.x+xx*8,y=q.y+yy*8,t=q.tiles[yy*q.size[0]+xx],tx=x>>3,ty=((y+source.scroll)%240)>>3,nt=source.nametables[tx>>5],a=nt[960+(ty>>2)*8+((tx&31)>>2)],group=(a>>(((tx>>1)&1)+((ty>>1)&1)*2)*2)&3;
    b.drawImage(atlas,(t%16)*8,(Math.floor(t/16)+group*16)*8,8,8,x,y,8,8);
   }key=cacheKey;
  }
  // The frozen scroll capture wraps nametable top rows into its tail. Hide
  // that tail over the black clear; keep native scale and all foreground bounds.
  const backgroundHeight=240-source.scroll;
  g.drawImage(surface,Math.floor(v.cameraX),0,nativeWidth,backgroundHeight,0,0,nativeWidth,backgroundHeight);g.save();g.translate(-Math.floor(v.cameraX),0);
  for(const e of v.enemies){
   if(e.type==='medusa-head'){if(e.dead&&e.sourceState===6)original(g,'effect-explosion-'+['small','medium','large'][Math.min(2,e.deathAge>>3)],e.x+e.w/2,e.y+e.h/2);continue;}
   if(e.type==='medusa-missile'){
    if(e.dead||e.phase==='explosion')original(g,'effect-explosion-'+['small','medium','large'][Math.min(2,(e.phase==='explosion'?source.missile.explosion-e.explosionRemaining:e.deathAge)>>3)],e.x+e.w/2,e.y+e.h/2);
    else{const d=((e.direction+1)>>2)&7,entry=[['tblSmallMissileLeftRight',false,false],['tblSmallMissileDiagonal',false,false],['tblSmallMissileUpDown',false,false],['tblSmallMissileDiagonal',true,false],['tblSmallMissileLeftRight',true,false],['tblSmallMissileDiagonal',true,true],['tblSmallMissileUpDown',false,true],['tblSmallMissileDiagonal',false,true]][d];image(g,entry[0],e.x+e.w/2,e.y+e.h/2,entry[1],entry[2]);}
   }else base.enemy(g,e,v.progress.tick);
  }
  if(v.reward)base.pickup(g,v.reward,v.progress.tick);
  if(!v.departure){base.weapon(g,v.weapons,v.progress.tick);base.player(g,v.body,v.progress.tick,{native:true});}
  else if(v.departure.bodyVisible){base.player(g,{...v.body,invuln:0,jackalHurtUntil:0},v.progress.tick,{native:true});}
  if(v.exitReady){const h=v.departure?.helicopter||{x:256,y:188},pose=v.departure?.phase==='takeoff'?'tblHelicopterInAir':'tblHelicopterOnHelipad';original(g,pose+(Math.floor(v.progress.tick/8)%2+1),h.x,h.y);}g.restore();g.restore();
  g.fillStyle='#000';g.fillRect(0,0,nativeWidth,JACKAL_MEDUSA_HUD_HEIGHT);
  original(g,'hud-P',8,8,false);original(g,'hud-1',16,8,false);for(const [text,x] of [[String(v.carry.score).padStart(6,'0'),32],[String(v.carry.lives),nativeWidth-36]])for(let i=0;i<text.length;i++)original(g,'hud-'+text[i],x+i*8,8,false);
  g.restore();return true;
 }
 return {...base,scene};
}
