import {createEnemyRegistry,createEnemyResolver,bindEnemyHandlers,createEnemyContactSystem,canHitEnemy} from '../../engine/enemy-contract.mjs';
import {JACKAL_ENEMIES,createJackalFoes} from './foes.mjs';
import {jackalSourceDirection,jackalSourceVelocity} from './source-projectiles.mjs';

// Crossover encounter tuning; cartridge timing, art, HP and missile tables stay intact.
export const MEDUSA_CLOSE_PRESSURE=Object.freeze({horizontal:112,depth:96});
const row=(id,model,collision,targetable,score)=>({id:'jackal-nes:'+id,origin:'jackal-nes',owner:'foe-port',source:'NES-Jackal-US:Bank6:22-142,1703-2027;Bank7:7646-7730',
 movement:{model,collision,activation:'continuous'},hurt:{handler:'jackal-medusa',animation:'source-background',sound:'source-silent'},
 death:{handler:'jackal-medusa',animation:'original-explosion-background-replacement',sound:'jackal_impact',retire:'source-countdown'},
 contact:{stomp:'source',attack:'damage',damage:1},starKill:true,targetable,score});
export const JACKAL_MEDUSA_ENEMIES=Object.freeze([
 row('medusa-head','source-l2-statue-idle-flash-mouth','scripted',true,800),
 row('medusa-missile','source-small-missile-32-direction-turn','projectile',true,0),
]);
const definition=createEnemyResolver({registry:createEnemyRegistry([...JACKAL_ENEMIES,...JACKAL_MEDUSA_ENEMIES])});
export function createJackalMedusaEnemies({source,cue=()=>{},emit=()=>{},award=()=>{},closePressure=false}){
 if(source?.hp!==15||source?.missile?.lifetimeTurns!==40)throw new TypeError('Original Medusa source data required');
 let serial=0;
 const base=createJackalFoes({cue,emit,award:(value,e,event)=>{if(!e.noPoints)award(value,e,event);}});
 const own=e=>e.type==='medusa-head'||e.type==='medusa-missile';
 const defeat=(e,event)=>{if(!canHitEnemy(e))return false;e.dead=true;e.hp=0;e.deathAge=0;e.sourceState=e.type==='medusa-head'?4:3;return true;};
 const handlers=bindEnemyHandlers({definition,owners:{'jackal-medusa':{
  hurt(e,damage){if(!canHitEnemy(e)||!Number.isFinite(damage)||damage<=0)return false;e.hp=Math.max(0,e.hp-damage);return true;},defeat}}});
 const contacts=createEnemyContactSystem({definition,defeat:(e,event)=>handlers.defeat(e,event),emit,award});
 function hurt(e,damage,attack={}){
  if(!own(e))return base.hurt(e,damage,attack);
  if(!canHitEnemy(e)||e.phase==='explosion'||e.sourceState===0)return false;
  // $45 rejects bullets. $8F keeps armour: a grenade/rocket removes five.
  if(e.type==='medusa-head'&&attack.kind==='jackal-machinegun')return false;
  const id=attack.attackInstanceId||attack.id;if(id&&e.attackIds?.includes(id))return false;
  if(e.type==='medusa-head'&&attack.kind==='jackal-main-weapon')damage=5;
  if(!handlers.hurt(e,damage,attack))return false;
  if(id){(e.attackIds??=[]).push(id);if(e.attackIds.length>64)e.attackIds.shift();}
  if(e.hp<=0)contacts.kill(e,{cause:attack.kind||'attack',tick:attack.tick||0});return true;
 }
 function head(index){const centerX=source.headX[index];return {id:'jackal-medusa-'+index,type:'medusa-head',sourceId:24,contractId:'jackal-nes:medusa-head',nativeOwner:'foe-port',foeSource:'jackal-nes',
  x:centerX-10,y:source.headY-18,w:20,h:36,hp:15,maxHp:15,age:0,dead:false,remove:false,deathAge:0,sourceState:0,timer:0,phase:'initializing',attackDirection:null,attackIds:[]};}
 function missile(e,world){const m=source.missile,direction=e.attackDirection??m.direction,v=jackalSourceVelocity(direction,m.speed);world.spawnEnemy({id:'jackal-medusa-missile-'+(++serial),type:'medusa-missile',sourceId:57,contractId:'jackal-nes:medusa-missile',nativeOwner:'foe-port',foeSource:'jackal-nes',
  x:e.x+e.w/2+m.spawnOffset[0]-2,y:e.y+e.h/2+m.spawnOffset[1]-2,w:4,h:4,hp:1,maxHp:1,age:0,dead:false,remove:false,deathAge:0,phase:'initializing',sourceState:0,
  direction,vx:v.vx,vy:v.vy,turnCountdown:m.initialTurn,turnInterval:m.turnInterval,turnCount:0,explosionRemaining:0,attackIds:[]});}
 function step(e,world){
  if(!own(e))return base.step(e,world);if(e.remove)return true;handlers.validate(e);e.age++;
  if(e.dead){
   if(e.sourceState===4){e.sourceState=5;emit('boss-music-stop-request',{entityId:e.id,last:world.remainingHeads===1});return true;}
   if(e.sourceState===5||e.sourceState===3){e.sourceState=6;e.deathAge=0;cue('jackal_impact');if(e.type==='medusa-head')emit('medusa-background-destroyed',{entityId:e.id});return true;}
   if(e.sourceState===6){if(++e.deathAge>=source.explosion)e.sourceState=7;return true;}
   if(e.sourceState===7){e.remove=true;emit('enemy-retired',{entityId:e.id,contractId:e.contractId,authoritativeDeath:!!e.defeatEvent});return true;}
  }
  if(e.type==='medusa-head'){
   if(e.sourceState===0){e.sourceState=1;e.phase='idle';e.timer=source.idle;return true;}
   if(e.sourceState===1){emit('medusa-background-stage',{entityId:e.id,name:'mouthClosed'});if(--e.timer===0){
     const dx=world.player.x+world.player.w/2-(e.x+e.w/2+source.missile.spawnOffset[0]),dy=world.player.y+world.player.h/2-(e.y+e.h/2+source.missile.spawnOffset[1]);
     e.attackDirection=closePressure&&Math.abs(dx)<=MEDUSA_CLOSE_PRESSURE.horizontal&&dy>=0&&dy<=MEDUSA_CLOSE_PRESSURE.depth?jackalSourceDirection(dx,dy):null;
     e.sourceState=2;e.phase='flash';e.timer=source.flash;}return true;}
   if(e.sourceState===2){--e.timer;emit('medusa-background-stage',{entityId:e.id,name:(e.timer&2)?'flash':'eyes'});if(e.timer===0){e.sourceState=3;e.phase='mouth';e.timer=source.mouth;}return true;}
   if(e.sourceState===3){emit('medusa-background-stage',{entityId:e.id,name:'mouthOpen'});if(--e.timer===0){missile(e,world);e.sourceState=1;e.phase='idle';e.timer=source.idle;}return true;}
   throw new TypeError('Invalid Medusa head state');
  }
  if(e.phase==='initializing'){e.phase='flight';e.sourceState=1;return true;}
  if(e.phase==='explosion'){if(--e.explosionRemaining===0){e.remove=true;e.dead=true;}return true;}
  if(e.phase!=='flight')throw new TypeError('Invalid Medusa missile state');
  if(--e.turnCountdown===0){
   e.turnCount++;if((e.turnCount&31)===0)e.turnInterval--;
   e.turnCountdown=e.turnInterval;
   const d=jackalSourceDirection(world.player.x+world.player.w/2-e.x-e.w/2,world.player.y+world.player.h/2-e.y-e.h/2),delta=(d-e.direction)&31;
   if(delta)e.direction=(e.direction+((delta&16)?-1:1)+32)&31;
   Object.assign(e,jackalSourceVelocity(e.direction,source.missile.speed));
  }
  e.x+=e.vx;e.y+=e.vy;
  if(e.turnCount===source.missile.lifetimeTurns){e.phase='explosion';e.sourceState=2;e.explosionRemaining=source.missile.explosion;e.vx=e.vy=0;cue('jackal_blastground');}
  // Original missiles leave the scene when their source scrolling routine
  // despawns them. They do not use round-shell scenery collision/lifetimes.
  if(e.x<-16||e.x>528||e.y<-16||e.y>256)e.remove=true;
  return true;
 }
 function validateSnapshot(e){
  if(!own(e))return true;
  const bad=()=>{throw new TypeError('Invalid original Medusa entity state');};
  if(!['x','y','w','h','hp','maxHp','age','deathAge'].every(k=>Number.isFinite(e[k]))||!Number.isInteger(e.age)||e.age<0||typeof e.dead!=='boolean'||typeof e.remove!=='boolean'||!Number.isInteger(e.sourceState)||!Array.isArray(e.attackIds)||e.attackIds.length>64||e.attackIds.some(id=>typeof id!=='string'))bad();
  if(e.type==='medusa-head'){
   if(e.attackDirection!=null&&(!Number.isInteger(e.attackDirection)||e.attackDirection<0||e.attackDirection>31))bad();
   if(!/^jackal-medusa-[0-3]$/.test(e.id)||e.sourceId!==24||e.sourceState<0||e.sourceState>7||e.w!==20||e.h!==36||e.maxHp!==15||e.hp<0||e.hp>15||!Number.isInteger(e.timer)||e.timer<0||e.timer>192||!['initializing','idle','flash','mouth'].includes(e.phase))bad();
  }else if(e.sourceId!==57||e.sourceState<0||e.sourceState>7||e.w!==4||e.h!==4||e.maxHp!==1||e.hp<0||e.hp>1||!['initializing','flight','explosion'].includes(e.phase)||!Number.isInteger(e.direction)||e.direction<0||e.direction>31||!Number.isInteger(e.turnCount)||e.turnCount<0||e.turnCount>40||!Number.isInteger(e.turnInterval)||e.turnInterval<11||e.turnInterval>12||!Number.isInteger(e.turnCountdown)||e.turnCountdown<1||e.turnCountdown>12||!Number.isInteger(e.explosionRemaining)||e.explosionRemaining<0||e.explosionRemaining>16||![e.vx,e.vy].every(Number.isFinite))bad();
  return true;
 }
 function kill(e,event){return own(e)?contacts.kill(e,event):base.kill(e,event);}
 return {definition,hurt,kill,head,step,validateSnapshot,spawn:base.spawn,crush:base.crush,
  snapshot:()=>({serial,base:base.snapshot()}),restore(v){if(!Number.isSafeInteger(v?.serial)||v.serial<0)throw new TypeError('Invalid Medusa enemy serial');serial=v.serial;base.restore(v.base);return true;}};
}
