import {ginsoMortarPlan,ginsoMortarRoom,GINSO_MORTAR_ROOM,GINSO_MORTAR_ENEMIES} from '../content/ori-ginso-miniboss.mjs';
import {createGinsoMortarPort} from '../characters/ori/ginso-mortar.mjs';
import {createPlatformStage} from '../campaign/stage.mjs';
import {createCharacterMotor} from '../campaign/character-motor.mjs';
import {createEnemyRegistry,createEnemyResolver} from '../engine/enemy-contract.mjs';
import {copySceneCheckpoint,nativeSceneHealth} from '../engine/scene-state.mjs';
import {nativeArenaWidth} from '../engine/viewport.mjs';
import {beginHiddenDeparture,stepHiddenDeparture,hiddenDepartureFrame,validateHiddenDeparture} from './hidden-departures.mjs';
/** One shared platform stage/registered actor. No listeners, RAF, campaign
 * writes, counter owner or second Ori simulation belongs to this scene. */
export function createOriGinsoMiniboss({character,rule,createActor,render,audio,sound,debug=false,viewport=()=>256}){
 for(const key of ['begin','cue','victory','tick','pause','resume','cancel'])if(typeof audio?.[key]!=='function')throw new TypeError('Ori scene requires audio port '+key);
 const width=()=>Math.max(GINSO_MORTAR_ROOM.width,nativeArenaWidth(viewport()));
 const R=ginsoMortarRoom(width()),plan=ginsoMortarPlan(character,R),definition=createEnemyResolver({registry:createEnemyRegistry(GINSO_MORTAR_ENEMIES)});
 let stage=null,actor=null,foes=null,sceneWorld=null,baseline=null,defeated=false,rewardSpawned=false,rewardClaimed=false,exited=false,paused=false,defeatTick=null,bossSeen=false,bossDefeated=false;
 let departure=null;
 function coordinateMap(from,to){const delta=to.width-from.width;
  return (x,e={})=>{
   if(e.id===R.reward.id)return to.reward.x;
   if(e.contractId==='ori-pc:mortar'&&Number.isInteger(e.hole)&&to.holes[e.hole])return to.holes[e.hole].x;
   // Insert/remove the middle strip; keep both authored platform groups rigid.
   const blend=Math.max(0,Math.min(1,(x-160)/(from.width-320)));
   return Math.max(12,Math.min(to.width-12-(e.w||0),x+delta*blend));
  };
 }
 function remapDeparture(value,mapX,room){if(!value)return;value.origin.x=mapX(value.origin.x,value.origin);value.landingX=room.exit.x+room.exit.w/2;value.endX=mapX(value.endX);}
 function syncArena(){
  if(!stage||R.width===width())return;
  const next=ginsoMortarRoom(width()),mapX=coordinateMap(R,next),nextPlan=ginsoMortarPlan(character,next);
  stage.resizeNativeArena({width:next.width,geometry:next.geometry,objects:nextPlan.rooms[R.id].objects,mapX});
  remapDeparture(departure,mapX,next);Object.assign(R,next);
 }
 function enter({carry,retry,rewardReceipt}){
  if(stage)throw new Error('Ori scene already entered');baseline=structuredClone(carry);
  if(retry&&baseline.native?.nativeVitals)baseline.native.nativeVitals=nativeSceneHealth(rule,baseline.native.nativeVitals,{retry:true});
  defeated=rewardSpawned=exited=paused=bossSeen=bossDefeated=false;departure=null;defeatTick=null;rewardClaimed=!!rewardReceipt?.claimed;
  const native=createActor('ori');
  // Bash eligibility belongs to the source enemy declaration. The actor still
  // holds exact live projectile refs; combat always receives the full world.
  actor=Object.freeze({...native,prepareRoom(w){sceneWorld=w;return native.prepareRoom(w);},step(p,input,w){sceneWorld=w;const bashing=!!(input.bash||input.ability||input.pointer?.bash);
   return native.step(p,input,bashing?{...w,enemies:w.enemies.filter(e=>definition(e).contact.bash!==false)}:w);},
   audio(playing){if(!playing)native.audio(false);}});
  foes=createGinsoMortarPort({cue:audio.cue,draw:(...args)=>render.enemy(...args),room:R});
  stage=createPlatformStage({plan,motor:createCharacterMotor(),actorPort:actor,enemyPort:foes,enemyDefinition:definition,
   visualRooms:[{roomId:R.id,setting:'Native',map:{geometry:R.geometry},markers:[],semantics:[]}],initialState:{...baseline,hero:'ori'},
   sceneHealth:{...rule,contactDamage:1},backtracking:true,manualDeath:true,lifeOwner:'campaign',debug,viewportWidth:R.width,
   emit:(type,data)=>{
    if(type==='sound')sound(native,data.event);
    if(type==='enemy-defeated'&&bossSeen&&data.entityId==='ginso-mortar'&&data.contract==='ori-pc:mortar')bossDefeated=true;
    if(type==='item-collected'&&rewardSpawned&&data.entityId===R.reward.id)rewardClaimed=true;
   }});
  bossSeen=stage.view().enemies.some(e=>e.id==='ginso-mortar'&&e.contractId==='ori-pc:mortar'&&!e.dead);audio.begin();return true;
 }
 function step(input){if(!stage||paused||exited)return;syncArena();
  if(departure){exited=stepHiddenDeparture(departure);audio.tick();return;}
  stage.step({...input,x:input.x??Number(!!input.right)-Number(!!input.left)});
  const v=stage.view();if(v.p.dying){audio.cancel();return;}
  if(v.enemies.some(e=>e.id==='ginso-mortar'&&e.contractId==='ori-pc:mortar'&&!e.dead))bossSeen=true;
  if(!defeated&&bossSeen&&bossDefeated){defeated=true;defeatTick=v.tick;audio.victory();}
  if(defeated&&v.tick-defeatTick>=R.victoryDelay){
   // Removal through the engine is an authoritative collision mutation, not
   // only an open-door drawing. This also lives in the shared scene checkpoint.
   if(!rewardSpawned){sceneWorld.removeSolid('exit-door');if(!rewardClaimed)stage.spawnReward({...R.reward,kind:'native-supply'});rewardSpawned=true;audio.cue('door-open');}
  }
  audio.tick();
 }
 function beginDeparture(){
  if(departure||exited)return true;
  if(!stage||paused||!defeated||!rewardClaimed||!rewardSpawned)return false;
  const v=stage.view();if(v.p.dying||v.geometry.some(q=>q.id==='exit-door'))return false;
  departure=beginHiddenDeparture('light-gate',v.p,{landingX:R.exit.x+R.exit.w/2,landingY:R.exit.y+R.exit.h});return true;
 }
 function view(){syncArena();const v=stage?.view();if(!v)return{};
  return {hero:'ori',id:R.id,title:R.title,mode:paused?'paused':'playing',area:R.id,cleared:defeated&&rewardClaimed,exited,
   exitReady:defeated&&rewardClaimed,departure:departure?hiddenDepartureFrame(departure):null,failed:!!v.p.dying,logicalWidth:R.width,logicalHeight:240,
   healthMode:rule.health,hp:v.health,maxHp:rule.initialHealth,carry:{score:v.score,coins:v.coins,lives:v.lives},nativeCarry:v.native,
   protection:v.p.protection||0,rewardClaimed,nativeReward:rewardClaimed?{kind:'native-equipment',id:'ori-cell'}:null,
   progress:{x:v.p.x,y:v.p.y,tick:v.tick,phase:!defeated?'mortar-battle':!rewardClaimed?'room-reward':'return',remainingEnemies:v.enemies.filter(e=>e.contractId==='ori-pc:mortar').length},body:v.p};
 }
 function snapshotScene(){syncArena();return {schema:'ori-ginso-mortar-v1',id:R.id,roomWidth:R.width,departure:departure?structuredClone(departure):null,defeated,defeatTick,rewardSpawned,rewardClaimed,exited,bossSeen,bossDefeated,stage:stage.checkpointScene()};}
 function restoreScene(data){const d=copySceneCheckpoint('ori',{version:1,hero:'ori',data}).data;
  if(d.schema!=='ori-ginso-mortar-v1'||d.id!==R.id||['defeated','rewardSpawned','rewardClaimed','exited','bossSeen','bossDefeated'].some(k=>typeof d[k]!=='boolean')||
   d.bossDefeated&&!d.bossSeen||d.defeated&&!d.bossDefeated||d.rewardSpawned&&!d.defeated||d.exited&&(!d.defeated||!d.rewardClaimed)||d.defeated&&(!Number.isSafeInteger(d.defeatTick)||d.defeatTick<0)||!d.defeated&&d.defeatTick!==null)throw new TypeError('Invalid Ori mortar scene checkpoint');
  if(d.departure!=null){validateHiddenDeparture(d.departure);if(d.departure.kind!=='light-gate'||!d.defeated||!d.rewardClaimed||!d.rewardSpawned||d.exited!==hiddenDepartureFrame(d.departure).complete||d.stage.geometry?.some(q=>q.id==='exit-door'))throw new TypeError('Invalid Ori departure');}
  const savedWidth=d.roomWidth??GINSO_MORTAR_ROOM.width;
  if(![GINSO_MORTAR_ROOM.width,nativeArenaWidth(1280/3)].includes(savedWidth))throw new TypeError('Invalid Ori arena checkpoint width');
  syncArena();
  if(savedWidth!==R.width){
   const mapX=coordinateMap(ginsoMortarRoom(savedWidth),R),geometry=new Map(R.geometry.map(q=>[q.id,q]));
   for(const q of d.stage.geometry)if(geometry.has(q.id))Object.assign(q,geometry.get(q.id));
   for(const q of [d.stage.body,...d.stage.enemies,...d.stage.items])q.x=mapX(q.x,q);
   d.stage.cam=0;remapDeparture(d.departure,mapX,R);
  }
  stage.restoreScene(d.stage);departure=d.departure?structuredClone(d.departure):null;({defeated,defeatTick,rewardSpawned,rewardClaimed,exited,bossSeen,bossDefeated}=d);audio.cancel();if(!exited)audio.begin({victory:defeated});
 }
 function migrateCheckpoint(checkpoint){const d=copySceneCheckpoint('ori',checkpoint).data;
  if(d.schema==='ori-ginso-mortar-v1'&&d.id===R.id)return checkpoint;
  if(d.schema==='native-platform-scene-v1'&&d.id==='ori-spirit-grotto')return null;
  throw new TypeError('Unrecognized Ori challenge checkpoint');}
 return {chapter:14,rules:rule,enter,step,view,beginDeparture,snapshotScene,restoreScene,migrateCheckpoint,grantCompletionBonus:award=>stage.grantCompletionBonus(award),
  draw(){syncArena();render.scene({view:stage.view(),stage,foes,defeated,rewardClaimed,room:R,departure:departure?hiddenDepartureFrame(departure):null});},audio(){if(!paused&&!exited)audio.tick();},
  pause(){if(!stage||paused)return;audio.pause();paused=true;stage.pause();},resume(){if(!stage||!paused)return;paused=false;stage.resume();audio.resume();},
  leave(){audio.cancel();stage?.dispose();stage=actor=foes=null;},
  ...(debug?{diagnostics:()=>({state:stage.view(),...stage.diagnostics})}:{})};
}
