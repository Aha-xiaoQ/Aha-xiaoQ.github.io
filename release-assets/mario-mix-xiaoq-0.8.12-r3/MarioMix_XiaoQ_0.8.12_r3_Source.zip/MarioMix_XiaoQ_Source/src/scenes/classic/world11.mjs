// Geometry and entities extracted unchanged from the user's RF02 baseline.
import {freezeData} from '../../engine/catalog.mjs';
const T=16;
function tileKey(x,y){return x+','+y}function put(map,x,y,type,content=null){const tile={x,y,type,content,bump:0,used:false,count:content==='multi'?10:1};map.set(tileKey(x,y),tile);return tile}
function buildLevel(){
const m=new Map();const gaps=[[69,71],[86,89],[153,155]];
for(let x=0;x<212;x++)if(!gaps.some(([a,b])=>x>=a&&x<b))for(let y=13;y<15;y++)put(m,x,y,'ground');
const b=(x,y,type='brick',content=null)=>put(m,x,y,type,content);
b(16,9,'question','coin');b(20,9);b(21,9,'question','power');b(22,9);b(23,9,'question','coin');b(24,9);b(22,5,'question','coin');
b(64,8,'question','life').hidden=true;
b(77,9);b(78,9,'question','power');b(79,9);for(let x=80;x<=87;x++)b(x,5);for(let x=91;x<=93;x++)b(x,5);b(94,5,'question','coin');b(94,9,'brick','multi');b(100,9);b(101,9,'brick','star');[106,109,112].forEach(x=>b(x,9,'question','coin'));b(109,5,'question','power');b(118,9);[121,122,123].forEach(x=>b(x,5));b(128,5);b(129,5,'question','coin');b(130,5,'question','coin');b(131,5);b(129,9);b(130,9);[168,169,171].forEach(x=>b(x,9));b(170,9,'question','coin');
for(let i=0;i<4;i++){for(let j=0;j<=i;j++)b(134+i,12-j,'stone');for(let j=0;j<4-i;j++)b(140+i,12-j,'stone')}
for(let i=0;i<5;i++)for(let j=0;j<Math.min(i+1,4);j++)b(148+i,12-j,'stone');
for(let i=0;i<4;i++)for(let j=0;j<4-i;j++)b(155+i,12-j,'stone');
for(let i=0;i<9;i++)for(let j=0;j<Math.min(i+1,8);j++)b(181+i,12-j,'stone');
b(198,12,'stone');
const ps=[{x:28,h:2},{x:38,h:3},{x:46,h:4},{x:57,h:4,entrance:true},{x:163,h:2,exit:true},{x:179,h:2}];
for(const p of ps){p.y=(13-p.h)*T;p.w=32;for(let x=p.x;x<p.x+2;x++)for(let y=13-p.h;y<13;y++)b(x,y,'pipe');p.x*=T;}
const es=[];const enemy=(x,y,type='walker')=>es.push({x:x*T+1,y:y*T+(type==='turtle'?-6:0),w:14,h:type==='turtle'?22:14,vx:-.5,vy:0,type,active:false,dead:0,flipped:false,shell:false,shellTimer:0,combo:0,safe:0,anim:0});
[21,41,53,55,95,97,124,125,127,129,174,175].forEach(x=>enemy(x,12));enemy(79,7);enemy(82,4);enemy(106,12,'turtle');
return{tiles:m,pipes:ps,enemies:es,items:[],coins:[]};}
function buildUnder(){const m=new Map(),cs=[];for(let x=0;x<16;x++)for(let y=13;y<15;y++)put(m,x,y,'ground');for(let y=2;y<13;y++){put(m,0,y,'bluebrick');put(m,15,y,'bluebrick')}for(let x=0;x<16;x++)put(m,x,2,'bluebrick');for(let x=4;x<11;x++)put(m,x,12,'bluebrick');for(let x=4;x<11;x++){cs.push({x:x*T+4,y:7*T+2,w:8,h:12});cs.push({x:x*T+4,y:9*T+2,w:8,h:12});if(x>4&&x<10)cs.push({x:x*T+4,y:5*T+2,w:8,h:12})}for(let y=3;y<11;y++){put(m,13,y,'pipe');put(m,14,y,'pipe')}return{tiles:m,pipes:[],enemies:[],items:[],coins:cs};}

function snapshot(room){return {...room,tiles:[...room.tiles.values()]};}
export const CLASSIC_WORLD11=freezeData({id:'classic-1-1-v1',tileSize:T,rooms:{surface:snapshot(buildLevel()),under:snapshot(buildUnder())}});
export function instantiateClassicRoom(id){
 const source=CLASSIC_WORLD11.rooms[id];if(!source)throw new Error('Unknown classic room: '+id);
 const copy=structuredClone(source);copy.tiles=new Map(copy.tiles.map(tile=>[tileKey(tile.x,tile.y),tile]));return copy;
}
