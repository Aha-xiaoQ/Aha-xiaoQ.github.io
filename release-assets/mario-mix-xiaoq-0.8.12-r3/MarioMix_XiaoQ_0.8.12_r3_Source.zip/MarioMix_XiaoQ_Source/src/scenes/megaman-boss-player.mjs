import {overlap} from '../engine/geometry.mjs';
import {remapActorScene} from '../engine/actor-contract.mjs';

export function validateSuperArm(p,geometry){
 const width=geometry?.find(q=>q.id==='floor')?.w??1024;
 const s=p.superArm,integer=(n,max=Number.MAX_SAFE_INTEGER)=>Number.isSafeInteger(n)&&n>=0&&n<=max;
 if(!s||s.version!==1||typeof s.selected!=='boolean'||!integer(s.energy,28)||!Array.isArray(s.shots)||s.shots.length>2||!integer(s.serial)||!integer(s.poseTicks,18)||!integer(s.walkTicks)||typeof s.attackHeld!=='boolean'||typeof s.abilityHeld!=='boolean')throw new TypeError('Invalid Super Arm scene state');
 if(s.held!==null&&(!/^super-arm-[01]$/.test(s.held)||!s.selected||s.energy<2))throw new TypeError('Invalid carried Super Arm block');
 const occupied=new Set(s.held?[s.held]:[]);
 for(const q of s.shots){
  const match=typeof q.id==='string'&&/^(super-arm-[01])-throw-([1-9][0-9]*)$/.exec(q.id);
  if(!match||!integer(Number(match[2]))||Number(match[2])>s.serial||occupied.has(match[1])||q.w!==32||q.h!==32||![q.x,q.y,q.vx,q.vy].every(Number.isFinite)||q.x < -64||q.x>width+64||q.y < -256||q.y>272||Math.abs(q.vx)!==3.625||q.vy < -3||q.vy>8||!integer(q.age,180))throw new TypeError('Invalid Super Arm projectile');
  occupied.add(match[1]);
 }
 if(geometry&&geometry.some(q=>occupied.has(q.id)))throw new TypeError('Carried Super Arm block still exists in terrain');
 return true;
}

/** Native Super Arm is scene equipment. It never replaces campaign upgrades.
 * The body checkpoint owns selection, energy, held block and flying blocks;
 * the shared world owns removed solids, collision and accepted damage. */
export function createMegamanBossPlayer({base,draw=()=>false,drawStone=()=>{},sound=()=>{}}){
 if(!base||base.id!=='megaman')throw new TypeError('Super Arm requires the installed Mega Man equipment port');
 let current=null;
 const fresh=()=>({version:1,selected:false,energy:28,held:null,shots:[],serial:0,attackHeld:false,abilityHeld:false,poseTicks:0,walkTicks:0});
 function state(p){return p.superArm??=fresh();}
 function step(p,input,w){
  current=p;const s=state(p),attack=!!(input.attack||input.run),ability=!!(input.ability||input.special||input.cycle);
  if(ability&&!s.abilityHeld&&!s.held&&!s.poseTicks)s.selected=!s.selected;
  const pressed=attack&&!s.attackHeld;s.attackHeld=attack;s.abilityHeld=ability;
  if(s.poseTicks>0)s.poseTicks--;
  if(s.selected&&pressed&&!s.poseTicks){
   if(s.held){
    const dir=p.facing<0?-1:1;
    s.shots.push({id:s.held+'-throw-'+(++s.serial),x:p.x+p.w/2+dir*16-16,y:p.y+p.h-12-16-16,w:32,h:32,vx:dir*3.625,vy:-3,age:0});
    s.held=null;s.energy-=2;s.poseTicks=18;sound('throw');
   }else if(s.energy>=2&&p.grounded){
    const reach={x:p.x+(p.facing<0?-20:0),y:p.y,w:p.w+20,h:p.h};
    const rock=w.solids.find(q=>q.liftable==='super-arm'&&overlap(reach,q));
    if(rock){s.held=rock.id;w.removeSolid(rock.id);sound('lift');}
   }
  }
  // Suppress ordinary gun/charge while G is selected. Movement still belongs
  // to the registered Mega Man actor, including world collision and hurt.
  const controls=s.selected?{...input,attack:false,attackPressed:false,run:false,runPressed:false,ability:false,special:false,specialPressed:false,cycle:false}:{...input,ability:false,special:false,specialPressed:false,cycle:false};
  const result=base.step(p,s.poseTicks?{...controls,x:0,left:false,right:false}:controls,w);
  if(p.grounded&&Math.abs(p.vx)>.05)s.walkTicks++;
  for(const shot of s.shots){
   const from={x:shot.x+16,y:shot.y+16},to={x:from.x+shot.vx,y:from.y+shot.vy};
   shot.age++;shot.vy=Math.min(8,shot.vy+.25);
   if(w.projectile(shot,from,to,{kind:'super-arm',damage:14,radius:12})){shot.dead=true;sound('impact');}
   else{shot.x=to.x-16;shot.y=to.y-16;if(shot.age>=180||shot.y>256||shot.x<-32||shot.x>(w.width||256)+32)shot.dead=true;}
  }
  s.shots=s.shots.filter(q=>!q.dead);return result;
 }
 return {...base,create(...args){const p=base.create(...args);current=p;p.superArm=fresh();return p;},step,
  remapSceneX(p,mapX,options){remapActorScene(base,p,mapX,options);for(const q of state(p).shots)q.x=mapX(q.x,q);},
  validateScene(body,geometry){validateSuperArm(body,geometry);},
  restoreCarry(p,...args){validateSuperArm(p);return base.restoreCarry(p,...args);},
  drawPlayer(g,p,t,v){const s=state(p);if(p.dying||!s.selected)return base.drawPlayer(g,p,t,v);
   const frame=!s.held&&!s.poseTicks?(!p.grounded?'06':Math.abs(p.vx)>.05?['03','05','04','05'][Math.floor(s.walkTicks/8)%4]:'00'):s.poseTicks?(p.grounded?'97':'98'):!p.grounded?'0e':Math.abs(p.vx)>.05?['0b','0d','0c','0d'][Math.floor(s.walkTicks/8)%4]:'09';
   return draw(g,{frame,x:p.x+p.w/2,y:p.y+p.h-12,flipX:p.facing>0,held:!!s.held})||base.drawPlayer(g,p,t,v);
  },
  drawWorld(g,v){base.drawWorld?.(g,v);const p=current;if(!p)return;const s=state(p);
   for(const q of s.shots)drawStone(g,q.x,q.y);
   if(s.held)drawStone(g,p.x+p.w/2-16,p.y+p.h-12-26-16);
  },
  beginDeath(p,w){p.superArm=fresh();return base.beginDeath?.(p,w);},
 };
}
