// Weapons declare the materials they affect. The world still owns contact,
// occlusion, reward blocks and geometry mutation; a capability is not a hit.
const MATERIALS = new Set(['brick', 'block', 'stone', 'steel']);
const identity = value => typeof value === 'string' && /^[A-Za-z][A-Za-z0-9._-]{0,63}$/.test(value);

export function createTerrainImpact({version = 1, owner, weapon, materials, revealsHidden = false} = {}) {
  if (version !== 1 || typeof revealsHidden !== 'boolean' || !identity(owner) || !identity(weapon)
      || !Array.isArray(materials) || !materials.length
      || materials.some(material => !MATERIALS.has(material))
      || new Set(materials).size !== materials.length) {
    throw new TypeError('Invalid terrain impact declaration');
  }
  return Object.freeze({version: 1, owner, weapon, revealsHidden, materials: Object.freeze([...materials])});
}

export function terrainImpactAllows(declaration, owner, material) {
  const impact = createTerrainImpact(declaration);
  if (impact.owner !== owner) throw new TypeError('Terrain impact owner does not match actor');
  return impact.materials.includes(material);
}
