// Scene-local health and campaign counters cross different boundaries. Native
// HP is never inferred from the one/two-hit mainline body snapshot.
export function nativeSceneHealth(rule, vitals, {retry=false}={}) {
  if(rule?.health!=='native'||!Number.isFinite(rule.initialHealth))throw new TypeError('Native health rule required');
  const maxHp=vitals?.maxHp??rule.initialHealth;
  if(!Number.isFinite(maxHp)||maxHp<1||maxHp>10000||vitals&&(!Number.isFinite(vitals.hp)||vitals.hp<0||vitals.hp>maxHp))throw new TypeError('Invalid native scene health');
  return {maxHp,hp:retry||!vitals?maxHp:Math.max(1,vitals.hp)};
}

// Project a delta against its unchanged entry baseline. Calling this again to
// save the same scene is idempotent; the projection is not a new increment.
// Native scenes can wrap coins at 100 and award the corresponding life already.
// Negative native life deltas are ignored: the campaign commits death once.
export function projectChallengeCounters(base, delta={}) {
  for(const key of ['score','coins','lives']){
    if(!Number.isSafeInteger(base?.[key])||base[key]<0)throw new TypeError('Invalid campaign counter: '+key);
    if(delta[key]!==undefined&&!Number.isSafeInteger(delta[key]))throw new TypeError('Invalid challenge delta: '+key);
  }
  const total=Math.max(0,base.coins+(delta.coins||0));
  return {coins:total%100,lives:Math.min(99,base.lives+Math.max(0,delta.lives||0)+Math.floor(total/100)),
    score:Math.min(9999999999,base.score+Math.max(0,delta.score||0))};
}

// A scene checkpoint contains authored-world progress, never live references,
// functions or actor identity changes. Native drivers own the data schema.
export function copySceneCheckpoint(hero, value) {
  let nodes=0;
  function copy(v,depth=0){
    if(++nodes>50000||depth>16)throw new TypeError('Scene checkpoint exceeds structural bounds');
    if(v===null||typeof v==='boolean')return v;
    if(typeof v==='string'){if(v.length>65536)throw new TypeError('Scene string too long');return v;}
    if(typeof v==='number'){if(!Number.isFinite(v))throw new TypeError('Invalid scene number');return v;}
    if(!v||typeof v!=='object')throw new TypeError('Scene checkpoint must contain data');
    const array=Array.isArray(v),proto=Object.getPrototypeOf(v);
    if(array?proto!==Array.prototype:proto!==Object.prototype&&proto!==null)throw new TypeError('Scene checkpoint must be plain');
    const keys=Reflect.ownKeys(v),out=array?[]:{};
    if(array&&keys.length!==v.length+1)throw new TypeError('Scene array must be dense');
    for(const key of keys){
      if(array&&key==='length')continue;
      if(typeof key!=='string'||['__proto__','prototype','constructor'].includes(key)||array&&!/^(0|[1-9][0-9]*)$/.test(key))throw new TypeError('Unsafe scene field');
      const d=Object.getOwnPropertyDescriptor(v,key);
      if(!Object.hasOwn(d,'value')||!d.enumerable)throw new TypeError('Scene accessors are not allowed');
      out[key]=copy(d.value,depth+1);
    }
    return out;
  }
  const result=copy(value);
  if(!result||Object.keys(result).length!==3||result.version!==1||result.hero!==hero||!result.data||Array.isArray(result.data)||typeof result.data!=='object')throw new TypeError('Invalid scene checkpoint identity');
  if(new TextEncoder().encode(JSON.stringify(result)).length>524288)throw new TypeError('Scene checkpoint exceeds byte limit');
  return result;
}
