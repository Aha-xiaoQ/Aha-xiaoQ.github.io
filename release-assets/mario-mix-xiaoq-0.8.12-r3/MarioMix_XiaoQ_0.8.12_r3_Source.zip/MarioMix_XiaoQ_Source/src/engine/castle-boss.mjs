import {moveEnemyBody} from './world-collision.mjs';
import {CLASSIC_BOSS_MOTION as motion} from '../content/classic-boss-motion.mjs';

function verticalDisplacement(e,jump){
  if(jump){e.vy=motion.jumpSpeed;e.bossYForce=0;return -motion.jumpLift;}
  // Original position carries the old fractional velocity before gravity is
  // added. A generic enemy gravity loses both the apex and passage duration.
  const position=(e.bossYFraction||0)+(e.bossYForce||0);
  e.bossYFraction=position%motion.fractionScale;
  const dy=(e.vy||0)+Math.floor(position/motion.fractionScale);
  const force=(e.bossYForce||0)+motion.downwardForce;
  e.bossYForce=force%motion.fractionScale;
  e.vy=(e.vy||0)+Math.floor(force/motion.fractionScale);
  if(e.vy>=motion.maximumSpeed&&e.bossYForce>=motion.fractionScale/2){
    e.vy=motion.maximumSpeed;e.bossYForce=0;
  }
  return dy;
}

export const isCastleBoss=e=>(!e?.nativeOwner||e.nativeOwner==='stage')&&
  (!e?.foeSource||e.foeSource==='mario')&&(!e?.contractId||e.contractId.startsWith('mario:'))&&
  /^(enemy-|marker-)?bowser$/i.test(e?.type||'');
export function castleBossHealth(unit=1){
  if(!(unit>0&&Number.isFinite(unit)))throw TypeError('A boss damage unit must be positive');
  return {hp:unit*3,maxHp:unit*3,bossHitUntil:0};
}
// Patrol heading survives a wall/ledge turn. Target facing controls the mouth
// and sprite only: chasing must not undo a collision response every tick.
export function moveCastleBoss(e,geometry,{width,targetX,tick}){
  e.patrolDir??=-1;
  const dx=e.patrolDir*.4,foot=e.y+e.h,nextFoot=e.x+e.w/2+e.patrolDir*(e.w/2+1);
  const edge=e.grounded&&!geometry.some(q=>!q.hidden&&['solid','oneway'].includes(q.collision)&&nextFoot>=q.x&&nextFoot<q.x+q.w&&Math.abs(q.y-foot)<=1);
  const limit=e.x+dx<Math.max(0,e.homeX-112)||e.x+dx>Math.min(width-e.w,e.homeX+64);
  if(edge||limit)e.patrolDir=-e.patrolDir;
  e.vx=e.patrolDir*.4;
  const dy=verticalDisplacement(e,e.grounded&&e.age%150===0);
  const hit=moveEnemyBody(e,e.vx,dy,geometry);
  if(hit.y)e.bossYForce=0;
  if(hit.x){e.patrolDir=-e.patrolDir;e.vx=e.patrolDir*.4;}
  if(Math.abs(targetX-(e.x+e.w/2))>8)e.facing=targetX<e.x+e.w/2?-1:1;
  e.bossBarVisible=!!e.bossHitUntil&&tick<e.bossHitUntil;
  return hit;
}
export function damageCastleBoss(e,amount,{tick,id}={}){
  if(!isCastleBoss(e)||e.dead||!(amount>0))return false;
  // Prevent a single active attack from counting repeatedly during overlap.
  if(id&&e.lastBossAttack===id||tick<(e.bossInvulnerableUntil||0))return false;
  e.lastBossAttack=id||null;e.hp=Math.max(0,e.hp-amount);
  e.bossInvulnerableUntil=tick+12;e.bossHitUntil=tick+180;e.bossBarVisible=true;e.flash=8;
  return true;
}
export function bossBar(e,tick){
  if(!isCastleBoss(e)||e.dead||e.hp<=0||!(tick<e.bossHitUntil))return null;
  return {x:Math.round(e.x+e.w/2-16),y:Math.round(e.y-8),w:32,h:4,fill:Math.max(1,Math.ceil(30*e.hp/e.maxHp))};
}
