// Presentation ownership is assigned at the supply factory, never inferred
// from the active hero. World items, enemy bodies and effects keep their owner.
const WORLD_KINDS=new Set(['coin','coin-pop','life','1up','star','brick-debris','score-pop','walker','portal','spawn','mainline-shot','exit','flag','checkpoint','vine']);
export function characterSupply(hero,descriptor){
 if(!hero||!descriptor||typeof descriptor!=='object'||!descriptor.kind)throw new TypeError('Invalid character supply descriptor');
 if(WORLD_KINDS.has(descriptor.kind)||descriptor.nativeOwner||descriptor.foeSource||descriptor.contractId)throw new TypeError('Character supply cannot claim a world entity: '+descriptor.kind);
 if(descriptor.nativeActor&&descriptor.nativeActor!==hero)throw new TypeError('Character supply owner mismatch');
 return {...descriptor,nativeKind:descriptor.nativeKind||descriptor.kind,kind:'native-supply',nativeActor:hero};
}
export function ownsCharacterSupply(item,hero){
 return !!hero&&item?.kind==='native-supply'&&item.nativeActor===hero&&!item.nativeOwner&&!item.foeSource&&!item.contractId;
}
