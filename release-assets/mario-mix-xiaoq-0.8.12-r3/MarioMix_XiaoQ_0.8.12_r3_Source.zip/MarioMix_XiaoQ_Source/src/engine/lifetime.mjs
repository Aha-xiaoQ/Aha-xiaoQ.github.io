/** Scene-local resources are released in reverse order, including on failure. */
export function createLifetime() {
  let closed = false;
  const cleanup = [];
  return Object.freeze({
    get closed() { return closed; },
    own(dispose) {
      if (typeof dispose !== 'function') throw new TypeError('resource cleanup must be a function');
      if (closed) throw new Error('scene lifetime is closed');
      cleanup.push(dispose);
      return dispose;
    },
    dispose() {
      if (closed) return;
      closed = true;
      const errors = [];
      while (cleanup.length) {
        try { cleanup.pop()(); } catch (error) { errors.push(error); }
      }
      if (errors.length) throw new AggregateError(errors, 'scene cleanup failed');
    },
  });
}
