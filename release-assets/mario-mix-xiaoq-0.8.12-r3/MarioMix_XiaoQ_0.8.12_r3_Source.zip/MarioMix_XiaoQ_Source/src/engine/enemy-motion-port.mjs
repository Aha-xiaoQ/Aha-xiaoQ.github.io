/** The installed source owns both ordinary and reflected movement. */
export function stepEnemyMotionPort(port,enemy,world,player){
 const value=port?.step?.(enemy,world,player);
 if(value&&typeof value.then==='function'){Promise.resolve(value).catch(()=>{});throw new TypeError('Enemy movement must be synchronous');}
 if(value!==true)throw new TypeError('Enemy movement owner refused '+world.enemyDefinition(enemy).id);
 return true;
}
