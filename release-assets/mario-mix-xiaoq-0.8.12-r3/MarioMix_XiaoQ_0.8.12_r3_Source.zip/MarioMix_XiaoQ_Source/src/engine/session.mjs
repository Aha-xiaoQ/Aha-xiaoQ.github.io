import {createLifetime} from './lifetime.mjs';

/** One owner of scene transitions. Adapters keep their own physics and checkpoints.
 * Hooks are synchronous: asynchronous asset work must be cancelled by the lifetime.
 * Failed hooks leave a closed, inspectable error state, never a partly running scene.
 */
export function createSession({catalog, adapters}) {
  const hooks = ['enter','start','pause','resume','leave'];
  for (const scene of catalog.scenes()) {
    for (const hook of hooks) {
      if (typeof adapters[scene.id]?.[hook] !== 'function') throw new Error(`${scene.id}: missing ${hook} hook`);
    }
  }
  let current = null, phase = 'idle', busy = false, revision = 0, fault = null;
  const trace = [];
  const record = event => {
    trace.push({revision, event, phase, sceneId:current?.scene.id ?? null, characterId:current?.character.id ?? null});
    if (trace.length > 128) trace.shift();
  };
  const invoke = (hook, context = current, payload) => {
    const result = adapters[context.scene.id][hook](context, payload);
    if (result && typeof result.then === 'function') throw new TypeError(`${hook} must be synchronous`);
    return result;
  };
  const release = () => {
    if (!current) return;
    const old = current;
    current = null;
    const errors = [];
    try { invoke('leave', old); } catch (error) { errors.push(error); }
    try { old.lifetime.dispose(); } catch (error) { errors.push(error); }
    if (errors.length) throw new AggregateError(errors, 'scene exit failed');
  };
  const transact = (event, fn) => {
    if (busy) throw new Error('reentrant scene transition');
    busy = true;
    try {
      const result = fn();
      fault = null;
      revision++;
      record(event);
      return result;
    } catch (error) {
      try { release(); } catch (cleanupError) { error = new AggregateError([error, cleanupError], 'transition and cleanup failed'); }
      phase = 'error';
      fault = error.message;
      revision++;
      record('error');
      throw error;
    } finally { busy = false; }
  };
  const requirePhase = values => {
    if (!current || !values.includes(phase)) throw new Error(`operation unavailable in ${phase}`);
  };
  return Object.freeze({
    select(characterId, sceneId) {
      // Validate before ending the current scene. Invalid UI/import data cannot clear it.
      const resolved = catalog.resolve(characterId, sceneId);
      return transact('select', () => {
        release();
        current = {...resolved, lifetime:createLifetime()};
        invoke('enter');
        phase = 'ready';
      });
    },
    start(payload) {
      requirePhase(['ready','running','paused','finished']);
      return transact('start', () => { const result = invoke('start', current, payload); phase = 'running'; return result; });
    },
    pause() {
      requirePhase(['running']);
      return transact('pause', () => { const result = invoke('pause'); phase = 'paused'; return result; });
    },
    resume() {
      requirePhase(['paused']);
      return transact('resume', () => { const result = invoke('resume'); phase = 'running'; return result; });
    },
    complete() {
      if (phase === 'finished') return;
      requirePhase(['running']);
      return transact('complete', () => { phase = 'finished'; });
    },
    reportPhase(next) {
      // Scene-owned death/respawn/finish/checkpoint flows report their status here.
      if (!['ready','running','paused','finished'].includes(next)) throw new Error('invalid scene phase');
      if (busy || !current || phase === 'error' || phase === next) return;
      phase = next; revision++; record('scene-status');
    },
    leave() {
      return transact('leave', () => { release(); phase = 'idle'; });
    },
    snapshot: () => ({phase, revision, sceneId:current?.scene.id ?? null, characterId:current?.character.id ?? null, fault}),
    events: () => trace.map(event => ({...event})),
  });
}
