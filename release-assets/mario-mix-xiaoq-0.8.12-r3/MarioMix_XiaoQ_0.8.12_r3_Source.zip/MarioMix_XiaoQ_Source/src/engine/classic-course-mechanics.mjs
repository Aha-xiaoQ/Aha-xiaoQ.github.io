/** Source families from the classic map transcription. Coefficients are the
 * community runtime's 2 px/unit adaptation, not a claim of NES cycle accuracy.
 * Reference: umaim/Mario@980c275, moveFalling / activateBulletBillsStart.
 */
export function fallingPlatform(room,geometry){
  return (room?.markers||[]).some(m=>m.kind==='falling-platform'&&
    (m.sourcePath?.record===geometry.id||m.id===geometry.id+'-motion'));
}
export function stepFallingPlatform(platform,riding){
  if(!platform.falling)return false;
  platform.dx=platform.dy=0;
  if(!riding&&!platform.freefall){platform.fallSpeed=0;return true;}
  platform.fallSpeed=platform.freefall?Math.min(5.75,(platform.fallSpeed||0)+.125):(platform.fallSpeed||0)+.25;
  if(platform.fallSpeed>=5.6)platform.freefall=true;
  platform.dy=platform.fallSpeed;platform.y+=platform.dy;return true;
}
export function spawnZoneActive(markers,family,x){
  const passed=markers.filter(m=>m.kind===`spawn-zone-${family}Start`||m.kind===`spawn-zone-${family}Stop`)
    .filter(m=>m.x<=x).sort((a,b)=>a.x-b.x);
  return !!passed.length&&passed.at(-1).kind.endsWith('Start');
}
/** Drawing and collision must identify the same actual inter-world pipes. */
export function classicWarpTarget(marker){
  const source=marker?.source,target=source?.transport?.map;
  return ['world-transport','source-transport-not-simulated'].includes(marker?.kind)&&
    /^Pipe(?:Vertical)?$/.test(source?.macro||source?.thing||'')&&/^[1-8]-1$/.test(target||'')?target:null;
}
/** All mainline actors share the same flag finish. A jump or mount may pass
 * above its visible collision box; the forward crossing still catches the
 * pole before the one-way camera makes it unreachable. Castle axes do not use
 * this rule. Ordinary contact and the original flag/score sequence stay owned
 * by the stage. */
export function crossesFlagpole(oldRight,body,flag){
  return oldRight<=flag.x&&body.x+body.w>=flag.x&&body.x+body.w>oldRight&&
    body.y<flag.y+flag.h;
}

/** Witness an actual running crouch traversal, not a coordinate-only trigger.
 * The shortened body must enter and clear a contiguous low ceiling on foot.
 * Transient evidence is discarded on room changes, stops and interrupted runs.
 */
export function createCrouchPassageWitness(){
 let attempt=null;
 return function witness({levelId,roomId,previous,body:p,solids,travel,roomSerial}){
  if(levelId!=='1-2'||roomId!=='area-1'||travel==='drive'||!p.grounded){attempt=null;return null;}
  if(attempt?.roomSerial!==roomSerial)attempt=null;
  if(!attempt&&p.crouch&&!previous.crouch&&previous.grounded&&previous.h>p.h&&Math.abs(previous.vx)>=1.8)
   attempt={roomId,roomSerial,dir:Math.sign(previous.vx),start:previous.x,age:0,roof:null,standingHeight:previous.h};
  const a=attempt;if(!a)return null;
  if(!p.crouch||++a.age>90||p.vx*a.dir<=.04){attempt=null;return null;}
  const rows=solids.filter(g=>!g.hidden&&g.collision==='solid'&&Math.abs(g.y+g.h-p.y)<1.1&&p.h<a.standingHeight);
  if(!a.roof){
   const hit=rows.find(g=>p.x+p.w>g.x&&p.x<g.x+g.w);if(!hit)return null;
   let left=hit.x,right=hit.x+hit.w,changed=true;
   while(changed){changed=false;for(const g of rows)if(g.x<=right&&g.x+g.w>=left){const l=Math.min(left,g.x),r=Math.max(right,g.x+g.w);if(l!==left||r!==right){left=l;right=r;changed=true;}}}
   if(right-left<16||!(a.dir>0?a.start+previous.w<=left:a.start>=right)){attempt=null;return null;}
   a.roof={left,right,bottom:hit.y+hit.h};
  }
  const roof=a.roof;
  if(!solids.some(g=>!g.hidden&&g.collision==='solid'&&g.x<=roof.left&&g.x+g.w>roof.left&&g.y+g.h===roof.bottom)){attempt=null;return null;}
  if(a.dir>0?p.x>=roof.right:p.x+p.w<=roof.left){attempt=null;return {id:'crouch-passage',method:'running-crouch',distance:Math.abs(p.x-a.start),width:roof.right-roof.left};}
  return null;
 };
}
