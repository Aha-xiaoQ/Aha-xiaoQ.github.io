import {validateEnemyGrounding} from './enemy-ground-contact.mjs';
const nonempty=v=>typeof v==='string'&&v.trim().length>0;
export function createEnemyRegistry(rows){
  const byId=new Map();
  for(const row of rows){
    const fail=field=>{throw new TypeError('Enemy contract '+(row?.id||'?')+': missing/invalid '+field);};
    for(const key of ['id','origin','owner','source'])if(!nonempty(row?.[key]))fail(key);
    if(row.owner==='stage'&&row.origin!=='mario')fail('stage owner is reserved for classic source');
    if(byId.has(row.id))fail('duplicate id');
    for(const section of ['movement','hurt','death']){
      const fields=section==='movement'?['model','collision']:section==='hurt'?['handler','animation','sound']:['handler','animation','sound','retire'];
      for(const key of fields)if(!nonempty(row[section]?.[key]))fail(section+'.'+key);
    }
    if(!['solid','scripted','projectile'].includes(row.movement.collision))fail('movement.collision');
    if(row.movement.grounding!==undefined){
      validateEnemyGrounding(row.movement.grounding);
      if(row.movement.collision!=='solid')fail('movement.grounding requires solid collision');
    }
    if(row.movement.activation!==undefined&&!['proximity','continuous'].includes(row.movement.activation))fail('movement.activation');
    if(row.presentation!==undefined&&![1,-1].includes(row.presentation.sourceFacing))fail('presentation.sourceFacing');
    if(row.health!==undefined&&(!row.health||!Number.isSafeInteger(row.health.initialHp)||row.health.initialHp<1||row.health.initialHp>10000||!nonempty(row.health.source)))fail('health');
     if(!['flatten','shell','hurt','source'].includes(row.contact?.stomp))fail('contact.stomp');
     if(row.contact.body!==undefined&&!['solid','none'].includes(row.contact.body))fail('contact.body');
     if(row.hurt.ignoredAttacks!==undefined&&(!Array.isArray(row.hurt.ignoredAttacks)||row.hurt.ignoredAttacks.some(k=>!nonempty(k))))fail('hurt.ignoredAttacks');
     if(row.contact.attack!==undefined&&!['kill','damage'].includes(row.contact.attack))fail('contact.attack');
     if(row.contact.attack==='damage'){
       if(row.contact.stomp!=='source'||!Number.isFinite(row.contact.damage)||row.contact.damage<=0)fail('contact.damage');
     }else if(row.contact.damage!==undefined)fail('contact.damage requires damage attack');
    if(row.contact.healthDamage!==undefined&&(!Number.isFinite(row.contact.healthDamage)||row.contact.healthDamage<=0||row.contact.healthDamage>10000))fail('contact.healthDamage');
    if(row.contact.crush!==undefined&&typeof row.contact.crush!=='boolean')fail('contact.crush');
    if(row.origin!=='mario'&&['flatten','shell'].includes(row.contact.stomp))fail('contact.stomp source ownership');
     if(typeof row.starKill!=='boolean')fail('starKill');
     if(row.targetable!==undefined&&typeof row.targetable!=='boolean')fail('targetable');
    if(!Number.isFinite(row.score)||row.score<0)fail('score');
     byId.set(row.id,Object.freeze({...row,...(row.presentation?{presentation:Object.freeze({...row.presentation})}:{}),...(row.health?{health:Object.freeze({...row.health})}:{}),targetable:row.targetable??true,contact:Object.freeze({...row.contact}),movement:Object.freeze({...row.movement,...(row.movement.grounding?{grounding:Object.freeze({...row.movement.grounding})}:{})}),hurt:Object.freeze({...row.hurt}),death:Object.freeze({...row.death})}));
  }
  return Object.freeze({get(id){const row=byId.get(id);if(!row)throw new TypeError('Unregistered enemy: '+id);return row;},list:()=>[...byId.values()]});
}

/** Logical facing is always world -X/+X. Atlas facing is source metadata;
 * renderers must not infer it from velocity or from the selected hero. */
export function enemyFacingScale(definition,direction) {
  const source=definition?.presentation?.sourceFacing;
  if(![1,-1].includes(source)||![1,-1].includes(direction))throw new TypeError('Enemy facing requires declared source and world directions');
  return direction===source?1:-1;
}
// A wind-up commits both facing and aim. The released projectile uses this
// same target even when the player crosses behind the attacker meanwhile.
export function commitEnemyAim(enemy,target,{muzzleOffset=0}={}) {
  const x=target.x+(target.w||0)/2,y=target.y+(target.h||0)/2,center=enemy.x+(enemy.w||0)/2;
  if(![center,x,y,muzzleOffset].every(Number.isFinite)||muzzleOffset<0)throw new TypeError('Invalid enemy aim');
  enemy.dir=x<center?-1:1;
  // A target overlapping the mouth must not make a forward attack fire back
  // through the shooter's body. Keep its height and committed facing.
  enemy.committedAim={x:muzzleOffset?center+enemy.dir*Math.max(muzzleOffset+1,Math.abs(x-center)):x,y};return enemy.committedAim;
}

/** New entities declare contractId and nativeOwner. Legacy identity projections
 * are installed at the content boundary; this resolver never chooses a source
 * from the player. An explicit but invalid ID must not fall back to old art. */
export function createEnemyResolver({registry,legacy=[]}){
  if(typeof registry?.get!=='function')throw new TypeError('Enemy resolver requires a registry');
  const adapters=new Map();
  for(const row of legacy){
    if(!nonempty(row?.owner)||typeof row.identify!=='function')throw new TypeError('Enemy legacy adapter requires owner and identify');
    if(adapters.has(row.owner))throw new TypeError('Enemy legacy adapter duplicate owner: '+row.owner);
    adapters.set(row.owner,row.identify);
  }
  return function definition(enemy){
    if(!enemy||typeof enemy!=='object')throw new TypeError('Enemy identity is missing');
    let id,owner=enemy.nativeOwner;
    if(Object.hasOwn(enemy,'contractId')){
      if(!nonempty(enemy.contractId))throw new TypeError('Invalid enemy contractId');
      id=enemy.contractId;
    }else if(enemy.foeSource){
      // Compatibility source metadata is already explicit; its registry entry
      // still determines the executable owner rather than a hero-name switch.
      if(!nonempty(enemy.foeSource)||!nonempty(enemy.type))throw new TypeError('Invalid enemy source identity');
      id=enemy.foeSource+':'+enemy.type;
    }else{
      owner=owner??'stage';
      const identify=adapters.get(owner);
      if(!identify)throw new TypeError('Enemy source owner mismatch: uninstalled '+owner);
      id=identify(enemy);
      if(!nonempty(id))throw new TypeError('Invalid enemy legacy identity: '+owner);
    }
    const spec=registry.get(id);
    // A new source entity has an explicit owner. The only ownerless historical
    // forms are classic stage NPCs and foeSource compatibility entities.
    if(owner==null&&Object.hasOwn(enemy,'contractId'))owner='stage';
    if(owner!=null&&owner!==spec.owner)throw new TypeError('Enemy source owner mismatch: '+owner+' / '+spec.id);
    if(enemy.foeSource!=null&&enemy.foeSource!==spec.origin)throw new TypeError('Enemy source mismatch: '+enemy.foeSource+' / '+spec.id);
    return spec;
  };
}

// A native numeric death counter retains a corpse for rendering, NOT as a live
// target. Keep these predicates separate throughout combat and presentation.
export const canHitEnemy=e=>!!e&&!e.dead&&!e.remove&&!e.defeatEvent;

// A launched attack is already active. Camera admission may defer a placed
// enemy, but must never suspend a projectile's motion, age or source expiry.
// Cyclic map hazards can explicitly retain proximity activation.
export function enemySimulationActive(enemy,spec,{playerX,camera,viewportWidth}){
  const activation=spec.movement.activation??(spec.movement.collision==='projectile'?'continuous':'proximity');
  return activation==='continuous'||enemy.x<=Math.max(playerX+320,camera+viewportWidth+32);
}

/** Bind concrete owners before a room becomes playable. A declaration without
 * executable hurt/defeat behavior is not an installed enemy. New sources must
 * install their own owner; the current hero is deliberately not an argument. */
export function bindEnemyHandlers({definition,owners}){
  function resolve(enemy){
    const spec=definition(enemy),hurt=owners[spec.hurt.handler],death=owners[spec.death.handler];
    if(typeof hurt?.hurt!=='function')throw new TypeError('Missing hurt handler for '+spec.id+': '+spec.hurt.handler);
    if(typeof death?.defeat!=='function')throw new TypeError('Missing death handler for '+spec.id+': '+spec.death.handler);
    return {spec,hurt:hurt.hurt.bind(hurt),defeat:death.defeat.bind(death)};
  }
  return Object.freeze({validate:resolve,
    hurt(enemy,amount,event){
      const accepted=resolve(enemy).hurt(enemy,amount,event);
      if(accepted&&typeof accepted.then==='function'){
        Promise.resolve(accepted).catch(()=>{});
        throw new TypeError('Enemy hurt handler must be synchronous');
      }
      if(typeof accepted!=='boolean')throw new TypeError('Enemy hurt handler must return a boolean');
      return accepted;
    },
    defeat(enemy,event){return resolve(enemy).defeat(enemy,event);}});
}
export function retainEnemy(e,definition){
  if(!e||e.remove||e.dead===true)return false;
  if(!e.dead)return true;
  const rule=definition(e).death.retire;
  if(rule==='native-countdown-remove')return true;
  if(rule==='native-counter-45')return e.dead<45;
  return false;
}

export function createEnemyContactSystem({definition,defeat,award,emit=()=>{}}){
  let serial=0;
  function kill(enemy,{cause='attack',tick=0,flat=false,score=true,attackWeapon=null}={}){
    if(!canHitEnemy(enemy))return false;
    const spec=definition(enemy);
    if(cause==='star'&&!spec.starKill)return false;
    const event={id:'enemy-defeat-'+(++serial),entityId:enemy.id,contract:spec.id,origin:spec.origin,cause,tick,...(typeof attackWeapon==='string'&&attackWeapon.length<=48?{attackWeapon}:{})};
    // Mark only after the source accepted the terminal transition. A failed
    // adapter must not create a dead-but-live entity or silently award points.
    if(defeat(enemy,{...event,flat})!==true)throw new Error('Enemy defeat handler rejected '+spec.id);
    enemy.defeatEvent=event;enemy.hp=0;
    if(score)award(spec.score,enemy,event);
    emit('enemy-defeated',event);return true;
  }
  function star(player,enemies,{tick=0,touches}={}){
    if(!(player.star>0)||player.dying)return 0;
    let count=0;
    for(const enemy of enemies)if(canHitEnemy(enemy)&&touches(player,enemy)&&kill(enemy,{cause:'star',tick}))count++;
    return count;
  }
  return Object.freeze({kill,star});
}
