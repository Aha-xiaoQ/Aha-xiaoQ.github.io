// Ground support is source-authored separately from sprite and hurt bounds.
// Replacement art may be wider than the old actor without creating a ledge.
export function validateEnemyGrounding(rule){
 if(!rule||!Number.isFinite(rule.width)||rule.width<=0||!Number.isFinite(rule.gravity)||rule.gravity<=0||!Number.isFinite(rule.maxFallSpeed)||rule.maxFallSpeed<=0)
  throw new TypeError('Ground enemy requires width, gravity and maxFallSpeed');
 return rule;
}
export function stepEnemyGroundContact(enemy,solids,rule){
 validateEnemyGrounding(rule);
 const supports=(q,cx)=>!q.hidden&&['solid','oneway'].includes(q.collision)&&cx+rule.width/2>q.x&&cx-rule.width/2<q.x+q.w;
 // Carry only an existing contact, never snap toward a nearby moving surface.
 const prior=enemy.grounded&&enemy.support!=null?solids.find(q=>q.id===enemy.support):null;
 if(prior&&supports({...prior,x:prior.x-(prior.dx||0)},enemy.x+enemy.w/2)&&Math.abs(enemy.y+enemy.h-(prior.y-(prior.dy||0)))<1.01){
  enemy.x+=prior.dx||0;enemy.y+=prior.dy||0;
 }
 const bottom=enemy.y+enemy.h,cx=enemy.x+enemy.w/2;
 enemy.vy=Math.min(rule.maxFallSpeed,(enemy.vy||0)+rule.gravity);
 let surface=null;
 if(enemy.vy>=0)for(const q of solids){
  if(supports(q,cx)&&bottom<=q.y+1&&bottom+enemy.vy>=q.y&&(!surface||q.y<surface.y))surface=q;
 }
 enemy.grounded=!!surface;enemy.support=surface?.id??null;
 if(surface){enemy.y=surface.y-enemy.h;enemy.vy=0;}else enemy.y+=enemy.vy;
 return surface;
}
