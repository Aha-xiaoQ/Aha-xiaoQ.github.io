/** Mainline units are 16 px tiles at 60 Hz. Native hidden scenes do not opt in.
 * Full ordinary jumps clear five-tile ledges with a small landing margin;
 * special moves and horizontal acceleration remain owned by each actor. */
export const MAINLINE_JUMP = Object.freeze({
  id: 'classic-course-jump-v2', jumpSpeed: 6, riseGravity: .2,
  fallGravity: .4375, maxFall: 5, minimumRise: 86, maximumRise: 90,
  obstacleHeight: 80, passageHeight: 16,
});

export function mainlineGravity(vy, held, policy = MAINLINE_JUMP) {
  return Math.min(policy.maxFall, vy + (vy < 0 && held ? policy.riseGravity : policy.fallGravity));
}

/** A source-authored cloud room returns below its floor. Gravity-free actors
 * must reach that same portal with their native movement, without acquiring
 * gravity or escaping the bounds of ordinary/native rooms. This is the upper
 * bound of body.y, not its feet; terrain collision remains actor-owned. */
export function mainlineBottomLimit(world,body,{inset=0}={}) {
  if(!Number.isFinite(world?.height)||!Number.isFinite(body?.h)||body.h<=0||world.height<body.h||!Number.isFinite(inset)||inset<0||inset>16)throw new TypeError('Invalid mainline bottom boundary');
  return world.mainline===true&&world.bottomExit===true?world.height+64:world.height-body.h-inset;
}

/** Every actor must declare a starting-equipment route through a one-cell
 * passage. A declaration is necessary, not sufficient: the shipped browser
 * acceptance replays that route against the actual authored map. */
export function validateMainlineAccess(character) {
  const a = character.access;
  if (!a || !['jump', 'drive'].includes(a.travel)) throw new TypeError('Missing mainline travel contract: ' + character.id);
  if (a.collisionWidth!==undefined&&(!Number.isFinite(a.collisionWidth)||a.collisionWidth<=0||a.collisionWidth>MAINLINE_JUMP.passageHeight)) throw new TypeError('Invalid mainline collision width: '+character.id);
  if (a.nativeWidth!==undefined&&(!Number.isFinite(a.nativeWidth)||a.nativeWidth<=0)) throw new TypeError('Invalid native collision width: '+character.id);
  if (!['body', 'crouch', 'weapon'].includes(a.passage)) throw new TypeError('Missing passage contract: ' + character.id);
  if (a.passage === 'body' && character.height > MAINLINE_JUMP.passageHeight) throw new TypeError('Body does not fit passage: ' + character.id);
  if (a.passage === 'crouch' && !(a.crouchHeight > 0 && a.crouchHeight <= MAINLINE_JUMP.passageHeight)) throw new TypeError('Crouch does not fit passage: ' + character.id);
  if (a.passage === 'weapon' && !a.startingTool) throw new TypeError('Passage requires a starting tool: ' + character.id);
  if (!['swim','drive'].includes(a.waterTravel)) throw new TypeError('Missing mainline water travel contract: ' + character.id);
  if (a.waterTravel === 'drive' && a.travel !== 'drive') throw new TypeError('Water driving requires a native drive controller: ' + character.id);
  return a;
}
