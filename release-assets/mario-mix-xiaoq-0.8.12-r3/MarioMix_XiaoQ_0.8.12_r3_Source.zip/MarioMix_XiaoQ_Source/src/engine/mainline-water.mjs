import {inputEdge} from './input-contract.mjs';
/** Declared 60 Hz water adaptation for mainline native swimmers. Vehicles keep
 * their installed drive controller. These coefficients
 * match the existing Mario water adapter; they are not original-game constants.
 * Native owners still update combat, equipment and art exactly once per tick.
 */
export const MAINLINE_WATER = Object.freeze({speed:1.5,acceleration:.1,reverseAcceleration:.2,drag:.06,
  strokeSpeed:2.5,gravity:.075,maxFall:1.5,strokeFrames:24,surface:16});
const clamp=(v,lo,hi)=>Math.max(lo,Math.min(hi,v));
const approach=(v,target,amount)=>v+clamp(target-v,-amount,amount);
export const isMainlineWater=world=>world?.mainline===true&&(world.underwater===true||/Underwater/.test(world.setting||''));

export function resetMainlineWater(p) {
  if(!p?.mainlineWater)return;
  p.mainlineWaterDx=p.mainlineWaterDy=0;p.mainlineWater=false;p.swimming=false;p.swimStroke=0;p.waterJumpHeld=false;
  p.jumpBuffer=0;p.buffer=0;p.coyote=0;p.dropTicks=0;p.drop=0;
  p.climbing=p.gliding=p.propelling=p.bashing=false;p.wallSide=0;
}

function horizontal(p,dx,solids) {
  const before=p.x;let next=before+dx;
  for(const q of solids){
    if(q.hidden||q.collision!=='solid'||p.y+p.h<=q.y||p.y>=q.y+q.h)continue;
    if(dx>0&&before+p.w<=q.x+.001&&next+p.w>q.x)next=Math.min(next,q.x-p.w);
    else if(dx<0&&before>=q.x+q.w-.001&&next<q.x+q.w)next=Math.max(next,q.x+q.w);
  }
  p.x=next;if(Math.abs(next-before-dx)>.001)p.vx=0;
}

function waterStep(p,input,world) {
  const c=MAINLINE_WATER,solids=world.solids||[],startX=p.x,startY=p.y;
  if(![p.x,p.y,p.w,p.h,world.width,world.height].every(Number.isFinite)||p.w<=0||p.h<=0)throw new TypeError('Invalid mainline water body');
  if(!p.mainlineWater){
    p.vx=clamp(Number(p.vx)||0,-c.speed,c.speed);p.vy=clamp(Number(p.vy)||0,-c.strokeSpeed,c.maxFall);
    p.waterJumpHeld=false;p.swimStroke=0;p.jumpBuffer=p.buffer=p.coyote=p.dropTicks=p.drop=0;
  }
  p.mainlineWater=p.swimming=true;p.headHit=null;p.crouch=false;
  p.climbing=p.gliding=p.propelling=p.bashing=false;p.wallSide=0;
  p.swimStroke=Math.max(0,(p.swimStroke||0)-1);
  const support=p.grounded&&solids.find(q=>q.id===p.support);
  if(support){horizontal(p,support.dx||0,solids);p.y+=support.dy||0;}
  const axis=Math.sign(Number(input.x)||Number(!!input.right)-Number(!!input.left));
  p.vx=approach(Number(p.vx)||0,axis*c.speed,axis?(p.vx&&Math.sign(p.vx)!==axis?c.reverseAcceleration:c.acceleration):c.drag);
  if(axis)p.facing=axis;
  const stroke=inputEdge(input,'jumpPressed',['jumpEdge'],()=>input.jump&&!p.waterJumpHeld);
  p.waterJumpHeld=!!input.jump;
  if(stroke){p.vy=-c.strokeSpeed;p.swimStroke=c.strokeFrames;}
  p.vy=Math.min(c.maxFall,(Number(p.vy)||0)+c.gravity);
  horizontal(p,p.vx,solids);
  const right=Math.max(0,world.width-p.w),x=clamp(p.x,0,right);
  if(x!==p.x)p.vx=0;p.x=x;
  const top=p.y,foot=top+p.h,vy=p.vy;let y=top+vy,landing=null,head=null;
  for(const q of solids){
    if(q.collision==='none'||p.x+p.w<=q.x||p.x>=q.x+q.w)continue;
    if(!q.hidden&&vy>=0&&foot<=q.y-(support?.id===q.id?0:q.dy||0)+1.01&&y+p.h>=q.y&&(!landing||q.y<landing.y))landing=q;
    if(q.collision==='solid'&&vy<0&&top>=q.y+q.h-.001&&y<q.y+q.h&&(!head||q.y+q.h>head.y+head.h))head=q;
  }
  p.grounded=false;p.support=null;
  if(landing){y=landing.y-p.h;p.vy=0;p.grounded=true;p.support=landing.id;}
  if(head){y=head.y+head.h;p.vy=.5;p.headHit=head.id;}
  const bottom=Math.max(0,world.height-p.h),surface=Math.min(c.surface,bottom);
  p.y=clamp(y,surface,bottom);if(p.y!==y)p.vy=0;
  p.mainlineWaterDx=p.x-startX;p.mainlineWaterDy=p.y-startY;
  return stroke;
}

/** Lease only kinematic fields while the native controller runs. Ignored dry
 * gravity/movement writes never move the weapon muzzle or trigger a second
 * collision path. Death immediately releases the lease: a native death impulse
 * is retained, never overwritten by a pre-death snapshot in finally.
 */
export function runMainlineWater(p,input,world,runNative,{alive=()=>!p.dying}={}) {
  if(!isMainlineWater(world)){resetMainlineWater(p);return runNative(input);}
  if(!['swim','drive'].includes(world.waterTravel))throw new TypeError('Undeclared mainline water travel mode');
  if(!alive())return;
  // Environmental adaptation belongs to the installed movement contract.
  // Four-direction vehicles retain their native controls, collision sweep,
  // muzzle and firing direction; a swim lease would discard their Up/Down.
  if(world.waterTravel==='drive'){
    resetMainlineWater(p);p.swimming=false;
    return runNative(input);
  }
  waterStep(p,input,world);
  const keys=['x','y','w','h','vx','vy','grounded','support','headHit','swimming','swimStroke','crouch'];
  const leased=[];
  try{
    for(const key of keys){
      const descriptor=Object.getOwnPropertyDescriptor(p,key);let value=p[key];
      if(descriptor&&!descriptor.configurable)throw new TypeError('Water body field is not configurable: '+key);
      Object.defineProperty(p,key,{enumerable:descriptor?.enumerable??true,configurable:true,
        get:()=>value,set:next=>{if(!alive())value=next;}});
      leased.push(()=>Object.defineProperty(p,key,{...(descriptor||{enumerable:true,configurable:true,writable:true}),value}));
    }
    // A stroke does not also trigger a dry jump, wall kick, dash or glide.
    // Direction, aim, attacks, weapon cycling, tools and equipment stay native.
    return runNative({...input,jump:false,jumpPressed:false,jumpEdge:false,dash:false,glide:false,climb:false});
  }finally{for(const release of leased.reverse())release();}
}
