/** World-space camera shared by simulation consumers and the renderer.
 * A negative ceiling moves the entire world; UI remains in screen space. */
export function verticalCameraY(playerY,{minY=0,focusY=100,height=240,viewportHeight=240}={}){
  return Math.max(minY,Math.min(Math.max(0,height-viewportHeight),playerY-focusY));
}

/** A fixed content frame may delay the ordinary follow target until the
 * player approaches the right edge, then releases continuously. Camera history
 * remains monotonic unless the room explicitly enables backtracking. */
export function horizontalCameraX(playerX,{width,viewportWidth=256,previous=0,backtracking=false,cameraFrames=[]}={}){
  let desired=playerX-100;
  for(const frame of cameraFrames){
    if(frame.w>viewportWidth)continue;
    const hold=frame.x-(viewportWidth-frame.w)/2;
    const released=hold+2*Math.max(0,playerX-(hold+viewportWidth-32));
    desired=Math.min(desired,released);
  }
  const max=Math.max(0,width-viewportWidth);
  desired=Math.max(0,Math.min(max,desired));
  return Math.max(0,Math.min(max,backtracking?desired:Math.max(previous,desired)));
}
