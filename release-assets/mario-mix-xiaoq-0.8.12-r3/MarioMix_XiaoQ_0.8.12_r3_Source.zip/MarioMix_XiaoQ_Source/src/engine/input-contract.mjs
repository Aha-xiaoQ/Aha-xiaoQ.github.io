/** One explicit edge wins over aliases and local held-state inference. */
export function inputEdge(frame,name,aliases=[],derive=()=>false){
  if(Object.hasOwn(frame,name))return !!frame[name];
  const supplied=aliases.filter(key=>Object.hasOwn(frame,key));
  return supplied.length?supplied.some(key=>!!frame[key]):!!derive();
}

const actionId=/^[a-z][a-zA-Z0-9]{0,47}$/;
const fields=['keys','pad','touch','pointerButtons'];
const touchSlots=['jump','attack','ability','extra'];
export function validateInputProfile(profile){
  if(!profile||profile.version!==1||typeof profile.id!=='string'||!profile.id||!profile.actions||typeof profile.actions!=='object')throw new TypeError('Invalid actor input profile');
  for(const [name,binding]of Object.entries(profile.actions)){
    if(!actionId.test(name)||name.endsWith('Pressed')||['constructor','prototype','__proto__','pointer','device','x','y','ax','ay'].includes(name))throw new TypeError('Invalid input action '+name);
    if(!binding||typeof binding!=='object')throw new TypeError('Invalid input binding '+name);
    for(const field of fields){
      const list=binding[field]??[];
      if(!Array.isArray(list)||list.some(v=>field==='pad'?!Number.isInteger(v)||v<0||v>31:field==='pointerButtons'?![0,2].includes(v):typeof v!=='string'||!v||field==='keys'&&!/^[A-Za-z][A-Za-z0-9]*$/.test(v)))throw new TypeError('Invalid input '+field+' for '+name);
    }
    if(!profile.project&&(['pause','skip'].includes(name)||(binding.keys||[]).some(k=>['KeyP','Escape','KeyR'].includes(k))||(binding.pad||[]).includes(9)))throw new TypeError('Reserved system input for '+name);
  }
  if(profile.bindings!==undefined&&typeof profile.bindings!=='function'||profile.project!==undefined&&typeof profile.project!=='function')throw new TypeError('Invalid input provider');
  if(profile.conflicts!==undefined&&!['allow','reject'].includes(profile.conflicts))throw new TypeError('Invalid input conflict policy');
  if(profile.conflicts==='reject')for(const field of fields){const seen=new Set();for(const b of Object.values(profile.actions))for(const value of b[field]||[]){if(seen.has(value))throw new TypeError('Conflicting input '+field+': '+value);seen.add(value);}}
  if(profile.touchLabels!==undefined){
    if(!profile.touchLabels||typeof profile.touchLabels!=='object'||Array.isArray(profile.touchLabels))throw new TypeError('Invalid touch labels');
    for(const [slot,label]of Object.entries(profile.touchLabels)){
      if(!touchSlots.includes(slot)||label!==null&&(typeof label!=='string'||!label.trim()||label.length>24))throw new TypeError('Invalid touch label '+slot);
      if(label!==null&&!profile.project&&!Object.values(profile.actions).some(b=>(b.touch||[]).includes(slot)))throw new TypeError('Unbound touch label '+slot);
    }
  }
  if(profile.touchExtras!==undefined){
    if(!Array.isArray(profile.touchExtras)||profile.touchExtras.length>6)throw new TypeError('Invalid extra touch controls');
    const slots=new Set();
    for(const item of profile.touchExtras){
      if(!item||typeof item!=='object'||Object.keys(item).some(k=>!['slot','label'].includes(k))||typeof item.slot!=='string'||!actionId.test(item.slot)||[...touchSlots,'left','right','up','down','cycle'].includes(item.slot)||slots.has(item.slot)||typeof item.label!=='string'||!item.label.trim()||item.label.length>24)throw new TypeError('Invalid extra touch control');
      if(!(profile.project&&Object.hasOwn(profile.actions,item.slot))&&!Object.values(profile.actions).some(b=>(b.touch||[]).includes(item.slot)))throw new TypeError('Unbound extra touch control '+item.slot);
      slots.add(item.slot);
    }
  }
  return profile;
}

/** Face-button slots describe physical A/B/X/Y positions, not actor abilities.
 * Independent actors declare their own commands; an unused slot is disabled.
 * Legacy projections keep their installed aliases and presentation defaults. */
export function touchPresentation(profile){
  validateInputProfile(profile);
  const defaults={jump:'跳跃',attack:'攻击',ability:profile.abilityLabel||'能力',extra:profile.extraLabel||'加速'};
  return Object.freeze(Object.fromEntries(touchSlots.map(slot=>{
    const label=Object.hasOwn(profile.touchLabels||{},slot)?profile.touchLabels[slot]:defaults[slot];
    const enabled=label!==null&&(!!profile.project||Object.values(profile.actions).some(b=>(b.touch||[]).includes(slot)));
    return [slot,Object.freeze({label:label||'—',enabled})];
  })));
}

/** Additional source actions belong to the current shared pad, never an old
 * scene toolbar. Slot names still use the same input owner and edge cleanup. */
export function touchExtraPresentation(profile){
  validateInputProfile(profile);
  return Object.freeze((profile.touchExtras||[]).map(({slot,label})=>Object.freeze({slot,label})));
}

function resolve(profile,context){
  validateInputProfile(profile);
  const dynamic=profile.bindings?.(context);
  if(dynamic)validateInputProfile({...profile,actions:dynamic});
  return {actions:dynamic||profile.actions,dynamic};
}

export function mapInputActions(actions,{press,held,pad,pointerButtons},pressedOnly=false){
  return Object.fromEntries(Object.entries(actions).map(([name,b])=>[name,
    (b.keys||[]).some(k=>press(k))||(b.pad||[]).some(i=>(pressedOnly?pad.pressedButtons:pad.buttons)?.[i])||
    (b.touch||[]).some(held)||(b.pointerButtons||[]).some(i=>pointerButtons[i])
  ]));
}

/** Host owns physical sampling and lifecycle. Profiles own action vocabulary.
 * Legacy projections retain their exact field/edge and direction policies. */
export function createInputOwner(){
  let previous={},identity=null;
  function clear(){previous={};identity=null;}
  function sample(profile,physical,context={}){
    const {actions,dynamic}=resolve(profile,context),signature=profile.id+':'+JSON.stringify(actions);
    if(signature!==identity){previous={};identity=signature;}
    const press=(...codes)=>codes.some(code=>physical.keys.has(code)||physical.keyPresses.has(code));
    const held=action=>physical.touch.includes(action);
    const env={...physical,press,held,bindings:dynamic,actions,previous,context};
    let value;
    if(profile.project)value=profile.project(env);
    else{
      value={pointer:{...physical.pointer},device:physical.device,aimX:physical.pointer.x,aimY:physical.pointer.y};
      Object.assign(value,mapInputActions(actions,env));
      // Direction actions and axes describe the same physical controller.
      // A stick must reach interaction consumers (pipes/menus), not only motion.
      const directions={left:(physical.pad.x||0)<-.5,right:(physical.pad.x||0)>.5,
        up:!!physical.pad.up||(physical.pad.y||0)<-.5,down:!!physical.pad.down||(physical.pad.y||0)>.5};
      for(const [name,held]of Object.entries(directions))if(actions[name])value[name]||=held;
      for(const [name,b]of Object.entries(actions)){
        value[name+'Pressed']=value[name]&&(!previous[name]||(b.keys||[]).some(k=>physical.keyPresses.has(k)));
      }
      value.x=Math.sign(Number(!!value.right)-Number(!!value.left));
      value.y=Math.sign(Number(!!value.down)-Number(!!value.up));
    }
    // Held-state history is independent of downstream command consumption.
    previous={...value,...Object.fromEntries(Array.from({length:6},(_,i)=>['digit'+i,press('Digit'+(i+1))]))};
    return value;
  }
  function claims(profile,code,context={}){return Object.values(resolve(profile,context).actions).some(b=>(b.keys||[]).includes(code))||(profile.acceptKeys||[]).includes(code);}
  function ownsKey(profile,code,context={}){return profile.ownedKeys?profile.ownedKeys.includes(code):claims(profile,code,context);}
  function capturesPointer(profile,button,context={}){return profile.capturePointer?profile.capturePointer.includes(button):Object.values(resolve(profile,context).actions).some(b=>(b.pointerButtons||[]).includes(button));}
  return Object.freeze({sample,clear,claims,ownsKey,capturesPointer});
}

/** Explicitly installed by independent hidden drivers; no legacy jump/run or
 * ability aliases are introduced. Additional per-driver metadata stays intact. */
export function createDeclaredInputAdapter(profile){
  validateInputProfile(profile);
  return (frame={},previous={})=>{
    const value={...frame};
    for(const name of Object.keys(profile.actions)){
      value[name]=!!frame[name];
      value[name+'Pressed']=inputEdge(frame,name+'Pressed',[],()=>value[name]&&!previous[name]);
    }
    return value;
  };
}
