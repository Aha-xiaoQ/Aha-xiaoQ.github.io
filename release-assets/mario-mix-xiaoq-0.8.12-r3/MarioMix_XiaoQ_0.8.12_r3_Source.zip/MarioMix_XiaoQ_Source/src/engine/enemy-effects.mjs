import {canHitEnemy} from './enemy-contract.mjs';

/** Room effects resolve the same registered targets as weapons. They never
 * inspect the selected hero or assume that every enemy belongs to its port. */
export function applyEnemyEffect(room,effect,{tick,camera,width,height,definition,kill}){
  if(effect==='freeze'){room.enemyFreezeUntil=Math.max(room.enemyFreezeUntil||0,tick+360);return true;}
  if(effect!=='defeat-visible')throw TypeError('Unknown enemy effect '+effect);
  let count=0;
  for(const e of room.enemies)if(canHitEnemy(e)&&e.x+e.w>camera&&e.x<camera+width&&e.y+e.h>0&&e.y<height&&definition(e).movement.collision!=='projectile'){
    if(kill(e))count++;
  }
  return count;
}
