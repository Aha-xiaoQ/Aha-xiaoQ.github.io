/** Host supplies requestAnimationFrame; the clock owns only deterministic ticks. */
export function createFixedClock({step=1/60,maxElapsed=.1,maxSteps=6}={}) {
  if (!Number.isFinite(step) || step <= 0 || !Number.isFinite(maxElapsed) || maxElapsed < step || !Number.isSafeInteger(maxSteps) || maxSteps < 1) throw new TypeError('invalid clock configuration');
  let last = null, accumulator = 0;
  return Object.freeze({
    advance(now, update, active=true) {
      if (!Number.isFinite(now)) throw new TypeError('invalid timestamp');
      const elapsed = last === null ? 0 : Math.min(Math.max(0,(now-last)/1000),maxElapsed);
      last = now;
      if (!active) return 0;
      accumulator += elapsed;
      let ticks = 0;
      while (accumulator >= step && ticks < maxSteps) { update(); accumulator -= step; ticks++; }
      return ticks;
    },
    reset() { last = null; accumulator = 0; },
  });
}
