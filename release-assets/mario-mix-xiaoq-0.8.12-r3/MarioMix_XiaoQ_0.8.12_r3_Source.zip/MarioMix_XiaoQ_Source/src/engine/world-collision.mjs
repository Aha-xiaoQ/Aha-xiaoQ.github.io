// Shared room geometry. Native AI supplies a displacement; this module resolves
// it. Neither the visual sprite nor the selected player changes solid rules.
// Newly revealed blocks or moving solids can overlap an existing actor. Judge
// the whole contact set: leaving one corner may briefly enter another corner
// more deeply while reducing total overlap. Per-solid vetoes can deadlock.
export function existingOverlapDeepens(body,next,contacts,tolerance=1e-7){
  const area=b=>contacts.reduce((sum,q)=>sum+Math.max(0,Math.min(b.x+b.w,q.x+q.w)-Math.max(b.x,q.x))*Math.max(0,Math.min(b.y+b.h,q.y+q.h)-Math.max(b.y,q.y)),0);
  return area(next)>area(body)+tolerance;
}

export function pipeEntryPose(body,pipe,{side=false}={}){
  if(![body.x,body.y,body.w,body.h,pipe.x,pipe.y,pipe.w,pipe.h].every(Number.isFinite))throw new TypeError('Invalid pipe entry geometry');
  const margin=2,tolerance=side?2:3;
  // Entry requires the collision body to fit the mouth. Partial sprite overlap
  // above/below a horizontal pipe is not an entrance. A large actor must use
  // its passage pose (crouch/dismount) before this shared check can accept it.
  const contact=side?Math.abs(body.x+body.w-pipe.x)<=tolerance&&body.y>=pipe.y-1&&body.y+body.h<=pipe.y+pipe.h+1:
    body.grounded&&Math.abs(body.y+body.h-pipe.y)<=tolerance&&body.x+body.w/2>=pipe.x+margin&&body.x+body.w/2<=pipe.x+pipe.w-margin;
  if(!contact)return null;
  return {x:side?body.x:pipe.x+(pipe.w-body.w)/2,y:body.y};
}

export function moveEnemyBody(body, dx, dy, geometry) {
  if (![body.x,body.y,body.w,body.h,dx,dy].every(Number.isFinite)) throw new TypeError('Non-finite enemy movement');
  const x0=body.x,y0=body.y,foot=y0+body.h;
  const solids=geometry.filter(q=>!q.hidden&&q.collision==='solid');
  let x=x0+dx,y=y0+dy,hitX=false,hitY=false,support=null;
  for(const q of solids){
    if(y0+body.h<=q.y||y0>=q.y+q.h)continue;
    if(dx>0&&x0+body.w<=q.x+.01&&x+body.w>q.x){x=Math.min(x,q.x-body.w);hitX=true;}
    if(dx<0&&x0>=q.x+q.w-.01&&x<q.x+q.w){x=Math.max(x,q.x+q.w);hitX=true;}
  }
  for(const q of geometry){
    if(q.hidden||!['solid','oneway'].includes(q.collision)||x+body.w<=q.x||x>=q.x+q.w)continue;
    if(dy>=0&&foot<=q.y+.01&&y+body.h>=q.y&&(!support||q.y<support.y)){support=q;y=q.y-body.h;hitY=true;}
    if(dy<0&&q.collision==='solid'&&y0>=q.y+q.h-.01&&y<q.y+q.h){y=Math.max(y,q.y+q.h);hitY=true;}
  }
  body.x=x;body.y=y;body.grounded=!!support;body.support=support?.id||null;
  if(hitY)body.vy=0;
  return {x:hitX,y:hitY,dx:x-x0,dy:y-y0,support:body.support};
}

// Exact segment / expanded AABB test; returns the earliest contact, even when a
// fast projectile crosses an entire tile between two fixed simulation ticks.
export function segmentEntry(from,to,box,radius=0){
  let near=0,far=1;
  for(const [axis,size] of [['x','w'],['y','h']]){
    const delta=to[axis]-from[axis],lo=box[axis]-radius,hi=box[axis]+box[size]+radius;
    if(Math.abs(delta)<1e-10){if(from[axis]<lo||from[axis]>hi)return null;continue;}
    let a=(lo-from[axis])/delta,b=(hi-from[axis])/delta;if(a>b)[a,b]=[b,a];
    near=Math.max(near,a);far=Math.min(far,b);if(near>far)return null;
  }
  return near;
}

export function firstProjectileContact(from,to,{geometry,enemies,radius=0,canHit=()=>true,canHitHidden=()=>false,box=e=>e}){
  if(![from?.x,from?.y,to?.x,to?.y,radius].every(Number.isFinite)||radius<0)throw new TypeError('Invalid projectile trajectory');
  let best=null;
  // Walls win exact ties, so an enemy embedded in a wall cannot be shot through it.
  for(const [kind,rows]of [['world',geometry],['enemy',enemies]])for(const entity of rows){
    if(kind==='world'?(entity.hidden&&!canHitHidden(entity)||entity.collision!=='solid'):!canHit(entity))continue;
    const target=kind==='world'?entity:box(entity);if(!(target.w>0&&target.h>0))continue;
    const t=segmentEntry(from,to,target,radius);if(t===null||best&&t>=best.t)continue;
    best={kind,entity,t,x:from.x+(to.x-from.x)*t,y:from.y+(to.y-from.y)*t};
  }
  return best;
}
/** Top-down actors share Mario's underside block interaction. Hidden blocks
 * are one-sided until revealed; ordinary ceiling contacts must also bump.
 * Rendering size never participates in this test. */
export function driveHeadContact(body,previous,geometry,input){
 if(!(input.up||input.y<0))return null;
 const block=geometry.filter(q=>!q.dead&&q.collision==='solid'&&['brick','block'].includes(q.material)
  &&body.x+body.w>q.x&&body.x<q.x+q.w&&previous.y>=q.y+q.h-1e-6&&body.y<=q.y+q.h+1e-6)
  .sort((a,b)=>b.y+b.h-a.y-a.h)[0];
 if(!block)return null;
 body.y=block.y+block.h;body.vy=0;return block.id;
}
