/** Walking presentation follows resolved displacement, not requested input.
 * A blocked actor can face a target while its feet stay still. Vehicle turn
 * controllers retain their own heading and must not use this walking policy.
 * Frame authors declare forward=right; left uses one renderer-owned flip.
 */
export function resolveWalkPresentation(before,after,{vertical=false,age=0,idleFacing=1}={}){
 const dx=after.x-before.x,dy=vertical?after.y-before.y:0;
 if(![dx,dy,age,idleFacing].every(Number.isFinite))throw new TypeError('Invalid resolved walk presentation');
 const x=Math.abs(dx)<1e-6?0:Math.sign(dx),y=Math.abs(dy)<1e-6?0:Math.sign(dy),moving=!!(x||y);
 const facing=x||Math.sign(idleFacing)||1;
 const heading=moving?[[0,-1],[1,-1],[1,0],[1,1],[0,1],[-1,1],[-1,0],[-1,-1]].findIndex(d=>d[0]===x&&d[1]===y)+1:facing<0?7:3;
 return Object.freeze({moving,dx,dy,facing,heading,walkAge:moving?age+1:0,sourceForward:'right'});
}

// Scene transport owns direction; an actor maps that direction to its native
// action. It cannot keep a stale diagonal aim from player-controlled movement.
export function scriptedMotionPresentation(body,phase,x,y,port,before=null){
 if(!['entrance-walk','pipe-enter','pipe-exit','flag-slide','finish-walk','finish-idle'].includes(phase)||![x,y].every(Number.isFinite))throw new TypeError('Invalid scripted motion presentation');
 const dx=before?body.x-before.x:0,dy=before?body.y-before.y:0;
 if(![dx,dy].every(Number.isFinite))throw new TypeError('Invalid resolved scripted displacement');
 const moving=Math.abs(dx)+Math.abs(dy)>1e-6,previous=body.scriptedMotion;
 // Walking measures horizontal travel. Landing and a mount's foot-preserving
 // body-height reconciliation must not speed up the leg cycle. Vertical pipe
 // and pole transports instead measure their authored vertical axis.
 const distance=(previous?.phase===phase?previous.distance||0:0)+(x?Math.abs(dx):Math.abs(dy));
 const value=Object.freeze({phase,x:moving&&Math.abs(dx)>1e-6?Math.sign(dx):Math.sign(x),y:moving&&Math.abs(dy)>1e-6?Math.sign(dy):Math.sign(y),
  dx,dy,moving,distance,animation:distance/1.5});
 body.scriptedMotion=value;if(value.x)body.facing=value.x;
 if(port?.presentScriptedMotion&&port.presentScriptedMotion(body,value)!==true)throw new TypeError('Actor rejected scripted motion presentation');
 return value;
}

/** Sprite contact is separate from the collision body. A climbing source
 * frame declares its visible palm edge relative to body.x; the pole is 2px.
 * Sliding animation may change that edge between frames without moving physics.
 */
export function alignFlagGrip(body,poleX,{offsetX,side='left'}={}){
 if(![body?.x,poleX,offsetX].every(Number.isFinite)||!['left','right'].includes(side))throw new TypeError('Invalid flag grip anchor');
 const edge=poleX+(side==='left'?-1:1);
 return {dx:edge-(body.x+offsetX),x:edge,side};
}
