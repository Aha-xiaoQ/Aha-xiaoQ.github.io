/** Content definitions are immutable. Runtime state never belongs in a registry. */
export function freezeData(value) {
  if (value && typeof value === 'object' && !Object.isFrozen(value)) {
    Object.values(value).forEach(freezeData);
    Object.freeze(value);
  }
  return value;
}

const validId = value => typeof value === 'string' && /^[a-zA-Z][a-zA-Z0-9._-]{0,79}$/.test(value);
const invariant = (condition, message) => { if (!condition) throw new Error(message); };

function index(entries, kind) {
  invariant(Array.isArray(entries) && entries.length > 0, `${kind}: expected nonempty definitions`);
  const result = new Map();
  for (const input of entries) {
    invariant(input && validId(input.id), `${kind}: invalid id`);
    invariant(!result.has(input.id), `${kind}: duplicate id ${input.id}`);
    result.set(input.id, freezeData(structuredClone(input)));
  }
  return result;
}

export function createCatalog({characters, scenes}) {
  const actors = index(characters, 'character'), worlds = index(scenes, 'scene');
  const stages = new Map();
  for (const scene of worlds.values()) {
    invariant(Number.isSafeInteger(scene.stage) && scene.stage > 0 && !stages.has(scene.stage), `scene ${scene.id}: duplicate or invalid stage`);
    invariant(Array.isArray(scene.characters) && scene.characters.length > 0 && new Set(scene.characters).size === scene.characters.length, `scene ${scene.id}: invalid characters`);
    invariant(scene.characters.includes(scene.defaultCharacter), `scene ${scene.id}: missing default character`);
    for (const id of scene.characters) invariant(actors.has(id), `scene ${scene.id}: unknown character ${id}`);
    stages.set(scene.stage, scene);
  }
  for (const actor of actors.values()) {
    invariant(typeof actor.name === 'string' && actor.name.length > 0, `character ${actor.id}: missing name`);
    invariant(Array.isArray(actor.abilities) && actor.abilities.every(validId) && new Set(actor.abilities).size === actor.abilities.length, `character ${actor.id}: invalid abilities`);
    invariant(worlds.get(actor.defaultScene)?.characters.includes(actor.id), `character ${actor.id}: unsupported default scene`);
  }
  const requireEntry = (map, id, kind) => {
    const entry = map.get(id);
    invariant(entry, `unknown ${kind}: ${id}`);
    return entry;
  };
  return Object.freeze({
    characters: () => Object.freeze([...actors.values()]),
    scenes: () => Object.freeze([...worlds.values()]),
    character: id => requireEntry(actors, id, 'character'),
    scene: id => requireEntry(worlds, id, 'scene'),
    stage: number => requireEntry(stages, number, 'stage'),
    resolve(characterId, sceneId) {
      const character = requireEntry(actors, characterId, 'character');
      const scene = requireEntry(worlds, sceneId ?? character.defaultScene, 'scene');
      invariant(scene.characters.includes(character.id), `unsupported combination: ${character.id} / ${scene.id}`);
      return Object.freeze({character, scene});
    },
    compatibility() {
      return [...worlds.values()].flatMap(scene => [...actors.values()].map(character => ({
        sceneId: scene.id, characterId: character.id,
        supported: scene.characters.includes(character.id),
        reason: scene.characters.includes(character.id) ? 'registered adapter' : 'adaptation not yet verified',
      })));
    },
  });
}
