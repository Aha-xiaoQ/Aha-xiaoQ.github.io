// The campaign saves this receipt alongside a native scene and keeps it on
// retry. It describes a collected room reward, never mere boss defeat or exit.
export function copyRewardReceipt(hero,value=null){
 if(typeof hero!=='string'||!/^[A-Za-z0-9][A-Za-z0-9._:-]{0,63}$/.test(hero))throw new TypeError('Invalid reward hero');
 const id='hidden-clear:'+hero;
 if(value==null)return {version:1,id,claimed:false};
 if(typeof value!=='object'||Array.isArray(value))throw new TypeError('Invalid challenge reward receipt');
 const keys=Reflect.ownKeys(value);
 for(const key of keys){const d=Object.getOwnPropertyDescriptor(value,key);if(!Object.hasOwn(d,'value')||!d.enumerable)throw new TypeError('Invalid challenge reward receipt');}
 if(keys.length!==3||!keys.every(k=>['version','id','claimed'].includes(k))||value.version!==1||value.id!==id||typeof value.claimed!=='boolean')throw new TypeError('Invalid challenge reward receipt');
 return {version:1,id,claimed:value.claimed};
}

export function roomRewardAward(rule){
 if(!rule||typeof rule.id!=='string'||!Number.isSafeInteger(rule.score)||rule.score<0||rule.score>9999999999||!Number.isSafeInteger(rule.lives)||rule.lives<0||rule.lives>99)throw new TypeError('Invalid room reward award');
 return {id:rule.id,score:rule.score,lives:rule.lives};
}

export function addRoomReward(carry,award){
 roomRewardAward(award);
 for(const key of ['score','coins','lives'])if(!Number.isSafeInteger(carry?.[key])||carry[key]<0)throw new TypeError('Invalid room reward counter');
 return {score:Math.min(9999999999,carry.score+award.score),coins:carry.coins,lives:Math.min(99,carry.lives+award.lives)};
}
