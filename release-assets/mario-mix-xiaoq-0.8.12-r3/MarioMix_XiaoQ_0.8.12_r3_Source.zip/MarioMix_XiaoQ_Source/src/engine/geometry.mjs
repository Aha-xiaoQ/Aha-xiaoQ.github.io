export function overlap(a,b){return a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y;}
export function clamp(n,a,b){return Math.max(a,Math.min(b,n));}
