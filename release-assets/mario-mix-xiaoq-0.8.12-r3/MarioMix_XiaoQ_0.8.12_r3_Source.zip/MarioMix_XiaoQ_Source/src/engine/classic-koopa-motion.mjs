/** Mario source traits belong to the enemy, independently of the selected hero.
 * Reference: umaim/Mario@980c275, Koopa floating attributes,
 * spawnMoveFloating / moveFloating / maintainCharacters / killKoopa.
 * Raw map coordinates use tileSize / 8 pixels per source unit.
 */
const koopa = enemy => (!enemy.nativeOwner || enemy.nativeOwner === 'stage') &&
  (!enemy.foeSource || enemy.foeSource === 'mario') &&
  /^(enemy-|marker-)?koopa$/i.test(enemy.type || '');

export function isFloatingKoopa(enemy) {
  return koopa(enemy) && !enemy.shell && !!enemy.source?.floating;
}

export function initializeClassicKoopaMotion(enemy, room) {
  if (!isFloatingKoopa(enemy)) return;
  const source = enemy.source, unit = room?.map?.tileSize / 8;
  if (![unit, enemy.y, source.y, source.begin, source.end].every(Number.isFinite) || unit <= 0)
    throw new TypeError('Floating Koopa requires source y/begin/end and a valid room scale');
  // The transcribed marker retains the source floor anchor. Inferring it from
  // the screen's bottom would change an editor map's authored vertical range.
  const floor = enemy.y + source.y * unit;
  const begin = Math.min(source.begin, source.end), end = Math.max(source.begin, source.end);
  enemy.classicFloat = Object.freeze({upper: floor - end * unit, lower: floor - begin * unit,
    maxSpeed: unit / 4, acceleration: unit / 64, walkDirection: enemy.vx < 0 ? -1 : 1});
  enemy.vx = 0; enemy.vy = unit / 8; enemy.grounded = false;
}

export function stepClassicKoopaMotion(enemy) {
  if (!isFloatingKoopa(enemy)) return false;
  const bounds = enemy.classicFloat;
  if (!bounds) throw new TypeError('Floating Koopa motion was not initialized');
  // The source updates position before moveFloating, whose movePlatform adds
  // the new velocity. Express that complete tick in this single movement owner.
  const oldVelocity = enemy.vy, top = enemy.y + oldVelocity;
  if (top <= bounds.upper) enemy.vy = Math.min(oldVelocity + bounds.acceleration, bounds.maxSpeed);
  else if (top + enemy.h >= bounds.lower) enemy.vy = Math.max(oldVelocity - bounds.acceleration, -bounds.maxSpeed);
  enemy.y = top + enemy.vy;
  enemy.grounded = false;
  return true;
}

export function removeClassicKoopaWings(enemy) {
  if (!koopa(enemy) || enemy.shell || !(enemy.source?.jumping || enemy.source?.floating)) return false;
  const direction = enemy.classicFloat?.walkDirection ?? (enemy.vx < 0 ? -1 : 1);
  enemy.source = {...enemy.source, jumping: false, floating: false};
  delete enemy.classicFloat;
  enemy.vx = direction * .5; enemy.vy = 0; enemy.grounded = false;
  return true;
}

/** Reject an incompatible motion snapshot before the scene commits any state.
 * A valid snapshot already contains the patrol anchor and current velocity;
 * restoring must not reconstruct the floor from the moved sprite position.
 */
export function validateClassicKoopaMotion(enemy, room) {
  if (!isFloatingKoopa(enemy)) return;
  const bounds = enemy.classicFloat;
  if (!bounds || ![enemy.homeY, enemy.vy, bounds.upper, bounds.lower, bounds.maxSpeed,
    bounds.acceleration, bounds.walkDirection].every(Number.isFinite) || Math.abs(bounds.walkDirection) !== 1)
    throw new TypeError('Invalid floating Koopa scene motion');
  const reference = {...enemy, y: enemy.homeY, vx: bounds.walkDirection};
  initializeClassicKoopaMotion(reference, room);
  for (const key of ['upper', 'lower', 'maxSpeed', 'acceleration'])
    if (bounds[key] !== reference.classicFloat[key]) throw new TypeError('Floating Koopa scene source mismatch');
  if (Math.abs(enemy.vy) > bounds.maxSpeed) throw new TypeError('Invalid floating Koopa scene velocity');
}
