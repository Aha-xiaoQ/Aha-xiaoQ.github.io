// Original axis-separated platform collision; tuning/order unchanged.
export function movePlatformBody(b,dx,dy,isPlayer,ports){
const {tileSize:T,querySolids:solids,bump:bumpTile}=ports;
if(![b.x,b.y,b.w,b.h,dx,dy,T].every(Number.isFinite)||b.w<=0||b.h<=0||T<=0)throw new TypeError("invalid platform body or displacement");
b.grounded=false;b.x+=dx;let hits=solids(b);if(hits.length){if(dx>0)b.x=Math.min(...hits.map(t=>t.x*T-b.w));else if(dx<0)b.x=Math.max(...hits.map(t=>(t.x+1)*T));b.vx=isPlayer?0:-b.vx;if(!isPlayer&&b.type==='shot'){b.dead=true;return}}
b.y+=dy;hits=solids(b,isPlayer&&dy<0);if(hits.length){if(dy>0){b.y=Math.min(...hits.map(t=>t.y*T-b.h));b.grounded=true;b.vy=0}else if(dy<0){const bottom=Math.max(...hits.map(t=>(t.y+1)*T));b.y=bottom;b.vy=.5;if(isPlayer){const relevant=hits.filter(t=>(t.y+1)*T===bottom).sort((a,c)=>Math.abs((a.x+.5)*T-(b.x+b.w/2))-Math.abs((c.x+.5)*T-(b.x+b.w/2)));if(relevant[0])bumpTile(relevant[0])}}}
}
