import {validateInputProfile} from './input-contract.mjs';
import {createPortraitPort} from './portrait-contract.mjs';
const identifier=/^[a-zA-Z0-9][a-zA-Z0-9._:-]{0,79}$/;
const operations=['create','prepareRoom','step','combat','hurt','downgrade','supply','pickup','drawPlayer','audio','sound','beginDeath','reset','pause','resume','dispose'];
const optionalOperations=['isUpgraded','enemyContact','hurtbox','reconcileBody','respawnCarry','roomBounds','presentScriptedMotion','drawCompanion','validateScene','remapSceneX'];
const presentationHooks=['drawWorld','drawWorldBehind','drawWorldFront','drawHud','drawPickup','presentScriptedMotion'];

/** The Stage moves public bodies; the actor moves only its private room state.
 * Scene resizing must complete synchronously before render or pointer input. */
export function remapActorScene(port,body,mapX,{privateMapX=mapX}={}){
 if(port?.remapSceneX==null)return;
 if(typeof port.remapSceneX!=='function'||typeof mapX!=='function'||typeof privateMapX!=='function')throw new TypeError('Invalid actor remapSceneX');
 const checked=map=>(x,entity)=>{const next=map(x,entity);if(!Number.isFinite(next))throw new TypeError('Invalid actor scene projection');return next;};
 const result=port.remapSceneX(body,checked(mapX),{privateMapX:checked(privateMapX)});
 if(result&&typeof result.then==='function'){Promise.resolve(result).catch(()=>{});throw new TypeError('Actor remapSceneX must be synchronous');}
 if(result===false)throw new TypeError('Actor remapSceneX rejected layout');
}

/** Validate native body/terrain relationships before the Stage commits either. */
export function validateActorScene(port,body,geometry){
 if(port?.validateScene==null)return;
 if(typeof port.validateScene!=='function')throw new TypeError('Actor validateScene must be a function');
 const result=port.validateScene(body,geometry);
 if(result&&typeof result.then==='function'){Promise.resolve(result).catch(()=>{});throw new TypeError('Actor validateScene must be synchronous');}
 if(result===false)throw new TypeError('Actor validateScene rejected checkpoint');
}

/** Damage volume is independent of narrow-route movement geometry. Source
 * scenes choose their own scale; undeclared actors retain their current body. */
export function readActorHurtbox(port,body,context={}){
 let box=body;
 if(port?.hurtbox!=null){
  if(typeof port.hurtbox!=='function')throw new TypeError('Actor hurtbox must be a function');
  box=port.hurtbox(body,context);
  if(box&&typeof box.then==='function'){Promise.resolve(box).catch(()=>{});throw new TypeError('Actor hurtbox must be synchronous');}
 }
 if(!box||!['x','y','w','h'].every(k=>Number.isFinite(box[k]))||box.w<=0||box.h<=0||box.w>256||box.h>256||Math.abs(box.x-body.x)>128||Math.abs(box.y-body.y)>128)throw new TypeError('Invalid actor hurtbox');
 return {x:box.x,y:box.y,w:box.w,h:box.h};
}

export function readActorUpgrade(port,body){
 if(port?.isUpgraded==null)return false;
 if(typeof port.isUpgraded!=='function')throw new TypeError('Actor isUpgraded must be a function');
 const value=port.isUpgraded(body);
 if(value&&typeof value.then==='function'){Promise.resolve(value).catch(()=>{});throw new TypeError('Actor isUpgraded must be synchronous');}
 if(typeof value!=='boolean')throw new TypeError('Actor isUpgraded must return a boolean');
 return value;
}

/** Mainline protection spends one upgrade, never native HP. This synchronous
 * port resets weapon state only; the stage owns immunity, lives and the one
 * original Mario power-down cue. Rooms with native health keep hurtNative. */
export function downgradeMainlineActor(port,body,world){
 if(typeof port?.downgrade!=='function')throw new TypeError('Actor missing downgrade');
 const accepted=port.downgrade(body,world);
 if(accepted&&typeof accepted.then==='function'){Promise.resolve(accepted).catch(()=>{});throw new TypeError('Actor downgrade must be synchronous');}
 if(accepted!==true)throw new TypeError('Actor downgrade must acknowledge the weapon reset');
 body.power=0;body.protection=0;
}

/** Keep the implementation as the method receiver. Freezing an exported
 * interface must neither freeze its state nor discard class prototype hooks. */
function bindPort(port){
  const surface={},seen=new Set();
  for(let owner=port;owner&&owner!==Object.prototype;owner=Object.getPrototypeOf(owner)){
    for(const key of Reflect.ownKeys(owner)){
      if(key==='constructor'||seen.has(key))continue;
      seen.add(key);
      const descriptor=Object.getOwnPropertyDescriptor(owner,key);
      if(typeof descriptor.value==='function'){
        Object.defineProperty(surface,key,{value:descriptor.value.bind(port),enumerable:true,configurable:true,writable:true});
      }else if(descriptor.get){
        Object.defineProperty(surface,key,{get(){const value=descriptor.get.call(port);return typeof value==='function'?value.bind(port):value;},enumerable:descriptor.enumerable,configurable:true});
      }else if(owner===port&&descriptor.enumerable){
        Object.defineProperty(surface,key,{value:descriptor.value,enumerable:true,configurable:true,writable:true});
      }
    }
  }
  return surface;
}

/** A contact is settled within the current simulation tick. Only an explicit
 * boolean may consume or decline it; a malformed port must not cost a life. */
export function resolveActorEnemyContact(port,body,enemy,context,world){
  if(!port?.enemyContact)return false;
  const accepted=port.enemyContact(body,enemy,context,world);
  if(accepted&&typeof accepted.then==='function'){
    Promise.resolve(accepted).catch(()=>{});
    throw new TypeError('Actor enemyContact must be synchronous');
  }
  if(typeof accepted!=='boolean')throw new TypeError('Actor enemyContact must return a boolean');
  return accepted;
}

/** Equipment is small, actor-owned data. Never transfer live bodies, scene
 * arrays, callbacks or input latches through this boundary. */
export function copyActorEquipment(hero,data){
  if(data==null)return null;
  if(!identifier.test(hero))throw new TypeError('Invalid actor identity: '+hero);
  let nodes=0;
  function copy(value,depth=0){
    if(++nodes>600||depth>8)throw new TypeError('Actor equipment exceeds bounds');
    if(value===null||typeof value==='boolean')return value;
    if(typeof value==='number'){if(!Number.isFinite(value))throw new TypeError('Nonfinite actor equipment');return value;}
    if(typeof value==='string'){if(value.length>128)throw new TypeError('Oversized actor equipment string');return value;}
    if(Array.isArray(value)){
      const out=[];
      for(let i=0;i<value.length;i++){
        const d=Object.getOwnPropertyDescriptor(value,String(i));
        if(!d||!('value' in d))throw new TypeError('Unsafe actor equipment array');
        out.push(copy(d.value,depth+1));
      }
      return out;
    }
    if(!value||typeof value!=='object'||Object.getPrototypeOf(value)!==Object.prototype)throw new TypeError('Actor equipment must be plain data');
    const out={};
    for(const key of Reflect.ownKeys(value)){
      const d=Object.getOwnPropertyDescriptor(value,key);
      if(typeof key!=='string'||['__proto__','constructor','prototype'].includes(key)||!('value' in d))throw new TypeError('Unsafe actor equipment field');
      if(d.value!==undefined)out[key]=copy(d.value,depth+1);
    }
    return out;
  }
  const result=copy(data);
  if((result.actor??result.hero)!==hero)throw new TypeError('Actor equipment identity mismatch: '+hero);
  if(JSON.stringify(result).length>4096)throw new TypeError('Actor equipment exceeds 4096 bytes');return result;
}

/** Only an explicit death hook retains actor-owned progress. Its output is
 * already the post-death equipment, never the full pre-death body/carry.
 * Non-null progress and its already-earned score are saved atomically; coin
 * and life checkpoint rules stay with the campaign. Missing hooks mean null. */
export function copyRespawnEquipment(hero,data){
  if(data===null)return null;
  const result=copyActorEquipment(hero,data);
  if(!result||!Number.isSafeInteger(result.version)||result.version<1)throw new TypeError('Respawn equipment must be versioned: '+hero);
  return result;
}
export function readRespawnEquipment(hero,port,body){
  if(port?.respawnCarry==null)return null;
  if(typeof port.respawnCarry!=='function')throw new TypeError('Actor respawnCarry must be a function: '+hero);
  const result=port.respawnCarry(body);
  if(result&&typeof result.then==='function'){
    Promise.resolve(result).catch(()=>{});
    throw new TypeError('Actor respawnCarry must be synchronous: '+hero);
  }
  return copyRespawnEquipment(hero,result);
}

/** Authored flight space is fixed for one room entry. Read only after the
 * actor prepares that room; ordinary jump actors retain the existing bounds. */
export function readActorRoomBounds(port,access){
  if(port?.roomBounds==null)return Object.freeze({minY:0,focusY:100});
  if(typeof port.roomBounds!=='function'||access?.travel!=='drive')throw new TypeError('Actor roomBounds requires declared drive travel');
  const result=port.roomBounds();
  if(result&&typeof result.then==='function'){
    Promise.resolve(result).catch(()=>{});
    throw new TypeError('Actor roomBounds must be synchronous');
  }
  if(!result||Object.getPrototypeOf(result)!==Object.prototype)throw new TypeError('Invalid actor roomBounds');
  for(const key of Reflect.ownKeys(result)){
    if(!['minY','focusY','cameraFrames'].includes(key)||!('value' in Object.getOwnPropertyDescriptor(result,key)))throw new TypeError('Invalid actor roomBounds field');
  }
  const {minY,focusY=100}=result;
  if(!Number.isFinite(minY)||minY>0||minY< -4096||!Number.isFinite(focusY)||focusY<0||focusY>240)throw new TypeError('Invalid actor roomBounds range');
  if(!Object.hasOwn(result,'cameraFrames'))return Object.freeze({minY,focusY});
  const frames=result.cameraFrames;
  if(!Array.isArray(frames)||frames.length>16||Reflect.ownKeys(frames).length!==frames.length+1)throw new TypeError('Invalid actor cameraFrames');
  const cameraFrames=[];
  for(let i=0;i<frames.length;i++){
    const field=Object.getOwnPropertyDescriptor(frames,String(i));
    if(!field||!('value' in field))throw new TypeError('Invalid actor cameraFrames entry');
    const frame=field.value;
    if(!frame||Object.getPrototypeOf(frame)!==Object.prototype||Reflect.ownKeys(frame).length!==2)throw new TypeError('Invalid actor cameraFrames entry');
    for(const key of ['x','w'])if(!Object.getOwnPropertyDescriptor(frame,key)||!('value' in Object.getOwnPropertyDescriptor(frame,key)))throw new TypeError('Invalid actor cameraFrames field');
    const {x,w}=frame;
    if(!Number.isFinite(x)||!Number.isFinite(w)||x<0||w<=0||x+w>1048576)throw new TypeError('Invalid actor cameraFrames range');
    cameraFrames.push(Object.freeze({x,w}));
  }
  return Object.freeze({minY,focusY,cameraFrames:Object.freeze(cameraFrames)});
}

/** Both registry adapters and direct stage ports use the same synchronous
 * transfer rule. A caller must reconcile the restored body against its room. */
export function restoreActorEquipment(hero,port,body,data,restoreName=null){
  const equipment=copyActorEquipment(hero,data),restore=restoreName?port?.[restoreName]:port?.restoreCarry||port?.restore;
  if(typeof restore!=='function')throw new TypeError('Actor has no equipment restore port: '+hero);
  const restored=restore.call(port,body,equipment);
  if(restored===false)throw new TypeError('Actor equipment restore was refused: '+hero);
  if(restored&&typeof restored.then==='function')throw new TypeError('Actor equipment restore must be synchronous: '+hero);
  return restored;
}

/** Installation is separate from selection. No hero-name switch or fallback
 * controller belongs in the campaign host. Legacy adapters explicitly name
 * their old carry methods here; a new adapter implements carry/restoreCarry. */
export function createActorRegistry(rows){
  const adapters=new Map();
  for(const row of rows){
    if(!identifier.test(row.id)||adapters.has(row.id))throw new TypeError('Invalid/duplicate actor runtime '+row.id);
    // This is the shipped Mario motor's historical installation, not a
    // shortcut around a new actor's lifecycle and equipment contract.
    if(row.kind==='platform'&&(row.id!=='mario'||row.create!==undefined))throw new TypeError('Reserved Mario platform installation: '+row.id);
    if(row.kind!=='platform'&&typeof row.create!=='function')throw new TypeError('Missing actor factory '+row.id);
    for(const [level,create] of Object.entries(row.scenes||{}))if(!identifier.test(level)||typeof create!=='function')throw new TypeError('Invalid actor scene '+row.id+'/'+level);
    if(row.foes!==undefined&&typeof row.foes!=='function')throw new TypeError('Invalid enemy factory '+row.id);
    if(row.challenge!==undefined&&typeof row.challenge!=='function')throw new TypeError('Invalid challenge factory '+row.id);
    if(row.input!==undefined)validateInputProfile(row.input);
    const portrait=row.portrait===undefined?null:createPortraitPort(row.portrait);
    adapters.set(row.id,Object.freeze({...row,portrait,scenes:Object.freeze({...row.scenes})}));
  }
  function get(id){const row=adapters.get(id);if(!row)throw new TypeError('Uninstalled actor runtime '+id);return row;}
  return Object.freeze({definition:get,
    input(id){const profile=get(id).input;if(!profile)throw new TypeError('Missing actor input profile '+id);return profile;},
    validateRoster(roster){for(const id of roster)if(!get(id).portrait)throw new TypeError('Uninstalled actor portrait '+id);},
    portrait(id){const port=get(id).portrait;if(!port)throw new TypeError('Uninstalled actor portrait '+id);return port;},
    drawPortrait(id,context,bounds){const port=get(id).portrait;if(!port)throw new TypeError('Uninstalled actor portrait '+id);return port.draw(context,bounds);},
    create(id,context={}){
      const row=get(id);if(row.kind==='platform')return null;
      const port=row.create(context);for(const op of operations)if(typeof port?.[op]!=='function')throw new TypeError('Actor '+id+' missing '+op);
      for(const op of optionalOperations)if(port[op]!=null&&typeof port[op]!=='function')throw new TypeError('Actor '+id+' invalid '+op);
      for(const op of presentationHooks)if(port[op]!=null&&typeof port[op]!=='function')throw new TypeError('Actor '+id+' invalid '+op);
      const requiredPresentation=port.presentation?.requires??[];
      if(!Array.isArray(requiredPresentation)||new Set(requiredPresentation).size!==requiredPresentation.length||requiredPresentation.some(op=>!presentationHooks.includes(op)||typeof port[op]!=='function'))throw new TypeError('Actor '+id+' missing declared presentation hook');
      if(port.drawCompanion&&(!identifier.test(port.companion?.id)||!identifier.test(port.companion?.source)))throw new TypeError('Actor '+id+' must declare its rescue companion');
      if(port.presentation&& !['blink','palette'].includes(port.presentation.invulnerability))throw new TypeError('Actor '+id+' invalid invulnerability presentation');
      if(port.presentation?.cameraMargin!==undefined&&(!Number.isFinite(port.presentation.cameraMargin)||port.presentation.cameraMargin<0||port.presentation.cameraMargin>64))throw new TypeError('Actor '+id+' invalid camera margin');
      if(port.id!=null&&port.id!==id)throw new TypeError('Actor factory identity mismatch '+id);
      const read=row.carry||'carry',write=row.restoreCarry||'restoreCarry';
      if(typeof port[read]!=='function'||typeof port[write]!=='function')throw new TypeError('Actor '+id+' missing equipment transfer');
      const surface=bindPort(port);
      for(const op of presentationHooks)if(port[op])Object.defineProperty(surface,op,{enumerable:true,configurable:true,value(...args){
        const result=port[op](...args);
        if(result&&typeof result.then==='function'){Promise.resolve(result).catch(()=>{});throw new TypeError('Actor '+id+' '+op+' must be synchronous');}
        if(requiredPresentation.includes(op)&&(op==='drawPickup'?typeof result!=='boolean':result!==true))throw new TypeError('Actor '+id+' refused declared '+op);
        return result;
      }});
      Object.defineProperties(surface,{
        id:{value:id,enumerable:true,configurable:true},
        carry:{value:p=>copyActorEquipment(id,port[read](p)),enumerable:true,configurable:true},
        restoreCarry:{value:(p,data)=>restoreActorEquipment(id,port,p,data,write),enumerable:true,configurable:true},
      });
      if(port.respawnCarry)Object.defineProperty(surface,'respawnCarry',{value:p=>readRespawnEquipment(id,port,p),enumerable:true,configurable:true});
      return Object.freeze(surface);
    },
    scene(id,level){return get(id).scenes[level]||null;},
    foes(id,context={}){
      const create=get(id).foes;if(!create)return null;
      const port=create(context);
      for(const name of ['prepare','step','hurt','death','draw'])if(typeof port?.[name]!=='function')throw new TypeError('Enemy port '+id+' missing '+name);
      return Object.freeze(bindPort(port));
    },
    challenges(context={}){
      const drivers={};
      for(const [id,row]of adapters)if(row.challenge){
        const driver=row.challenge(context);
        if(!driver?.runtime)throw new TypeError('Independent challenge runtime required: '+id);
        drivers[id]=driver;
      }
      return Object.freeze(drivers);
    },
  });
}
