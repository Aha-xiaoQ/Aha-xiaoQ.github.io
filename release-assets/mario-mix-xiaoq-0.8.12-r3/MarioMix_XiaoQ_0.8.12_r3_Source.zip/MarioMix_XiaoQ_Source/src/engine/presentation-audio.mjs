/** Finite musical/sound presentations use declared source, category and scope.
 * A native scene contributes definitions without editing engine cue lists. */
export const PRESENTATION_CUES=Object.freeze({
 flag:Object.freeze({source:'flag',category:'effects',scope:'campaign',gain:'measured',blocksStage:false}),
 clear:Object.freeze({source:'clear',category:'music',scope:'campaign',gain:'measured',blocksStage:true}),
 world_clear:Object.freeze({source:'world_clear',category:'music',scope:'campaign',gain:'measured',blocksStage:true}),
});
const identifier=/^[A-Za-z0-9][A-Za-z0-9._:-]{0,119}$/;
export function createPresentationRegistry(initial={}){
 const definitions=new Map();
 function register(entries){
  if(!entries||typeof entries!=='object'||Array.isArray(entries))throw new TypeError('Presentation definitions require a cue table');
  const next=[];
  for(const [id,d]of Object.entries(entries)){
   if(!identifier.test(id)||definitions.has(id)||!d||typeof d.source!=='string'||!identifier.test(d.source)||
    !['music','effects'].includes(d.category)||!['campaign','scene'].includes(d.scope)||
    !['stored','measured'].includes(d.gain)||typeof d.blocksStage!=='boolean'||d.scope==='scene'&&d.blocksStage)
     throw new TypeError('Invalid or duplicate finite presentation definition: '+id);
   next.push([id,Object.freeze({id,source:d.source,category:d.category,scope:d.scope,gain:d.gain,blocksStage:d.blocksStage})]);
  }
  for(const [id,d]of next)definitions.set(id,d);
 }
 function get(id){const d=definitions.get(id);if(!d)throw new TypeError('Unregistered finite presentation cue: '+id);return d;}
 register(initial);return Object.freeze({register,get,has:id=>definitions.has(id),entries:()=>Object.freeze([...definitions.values()])});
}

export function createPresentationAudio({clock,describe,start,stop,enabled=()=>true,registry=createPresentationRegistry(PRESENTATION_CUES),scope='campaign'}={}){
 for(const fn of [clock,describe,start,stop,enabled])if(typeof fn!=='function')throw new TypeError('Presentation audio requires its shared audio port');
 if(!registry||typeof registry.get!=='function'||!['campaign','scene'].includes(scope))throw new TypeError('Presentation audio requires its registered scene scope');
 const records=new Map();let sequence=0,suspended=false;
 const now=()=>{const n=clock();if(!Number.isFinite(n)||n<0)throw new TypeError('Invalid presentation clock');return n;};
 function position(r){if(r.state!=='playing')return {offset:r.offset,delay:r.delay};const time=now();return {offset:Math.min(r.endOffset,r.offset+Math.max(0,time-r.startedAt)*r.rate),delay:Math.max(0,r.startedAt-time)};}
 function launch(r){
  if(r.offset>=r.endOffset){r.state='ended';r.voice=null;return;}
  r.state='playing';r.startedAt=now()+r.delay;
  try{
   const voice=start(r.definition.source,{offset:r.offset,duration:r.endOffset-r.offset,rate:r.rate,volume:r.volume,delay:r.delay,
    presentationKey:r.key,category:r.definition.category,gainMode:r.definition.gain,
    onCleanup(v,reason){
     if(records.get(r.key)!==r||r.voice!==v||r.state==='suspended'||r.state==='cancelled')return;
     if(reason==='ended'){r.state='ended';r.offset=r.endOffset;r.delay=0;r.voice=null;return;}
     const at=position(r);r.offset=at.offset;r.delay=at.delay;r.state='suspended';r.voice=null;
    }});
   r.voice=voice;if(Number.isFinite(voice?.startedAt))r.startedAt=voice.startedAt;
   if(!voice){r.state='cancelled';r.delay=0;}
  }catch(error){r.state='cancelled';r.voice=null;r.delay=0;throw error;}
 }
 function play(key,options={}){
  const d=registry.get(key);if(d.scope!==scope)throw new TypeError('Finite presentation cue does not belong to this scene: '+key);
  const prior=records.get(key);if(prior)return prior.id;
  if(!enabled())return null;const source=describe(d.source);if(!source)return null;
  const duration=source.duration,offset=options.offset??0,rate=options.rate??1,delay=options.delay??0,volume=options.volume??1,length=options.duration??duration-offset;
  if(![duration,offset,rate,delay,volume,length].every(Number.isFinite)||duration<=0||offset<0||offset>duration||rate<=0||delay<0||volume<0||length<0)throw new TypeError('Invalid finite presentation interval');
  const endOffset=Math.min(duration,offset+length);if(endOffset<=offset)return null;
  const r={id:++sequence,key,definition:d,offset,endOffset,rate,delay,volume,startedAt:0,state:'suspended',voice:null};records.set(key,r);if(!suspended)launch(r);return r.id;
 }
 function suspend(){suspended=true;for(const r of records.values())if(r.state==='playing'){const at=position(r),voice=r.voice;r.offset=at.offset;r.delay=at.delay;r.state='suspended';r.voice=null;if(voice&&!voice.stopped)stop(voice);}}
 function resume(){if(!enabled())return;suspended=false;for(const r of records.values())if(r.state==='suspended')launch(r);}
 function cancel(){const old=[...records.values()];records.clear();suspended=false;for(const r of old){r.state='cancelled';const voice=r.voice;r.voice=null;if(voice&&!voice.stopped)stop(voice);}}
 function pending(){return [...records.values()].some(r=>r.definition.blocksStage&&['playing','suspended'].includes(r.state));}
 function view(){return {suspended,cues:[...records.values()].map(r=>{const at=position(r);return {id:r.id,key:r.key,source:r.definition.source,category:r.definition.category,scope:r.definition.scope,state:r.state,offset:at.offset,remaining:(r.endOffset-at.offset)/r.rate,delay:at.delay,rate:r.rate,volume:r.volume,startedAt:r.startedAt,endTime:r.voice?.endTime??null,blocksStage:r.definition.blocksStage};})};}
 return Object.freeze({play,suspend,resume,cancel,pending,view});
}
