const sourceId=/^[A-Za-z0-9][A-Za-z0-9._:/-]{0,127}$/;
function synchronousBoolean(value,label){
  if(value&&typeof value.then==='function'){
    Promise.resolve(value).catch(()=>{});
    throw new TypeError('Portrait '+label+' must be synchronous');
  }
  if(typeof value!=='boolean')throw new TypeError('Portrait '+label+' must return a boolean');
  return value;
}

/** A presentation-only installation, independent of actor creation and state.
 * Assets may still be decoding; an absent renderer is not a loading state. */
export function createPortraitPort(definition){
  if(!definition||typeof definition.source!=='string'||!sourceId.test(definition.source)||typeof definition.ready!=='function'||typeof definition.draw!=='function')
    throw new TypeError('Portrait needs an explicit source, ready and draw port');
  const inset=definition.selectionInset??0;
  if(!Number.isInteger(inset)||inset<0||inset>8)throw new TypeError('Invalid portrait selection inset');
  const ready=definition.ready.bind(definition),draw=definition.draw.bind(definition);
  return Object.freeze({source:definition.source,selectionInset:inset,
    ready(){return synchronousBoolean(ready(),'ready');},
    draw(context,bounds){
      if(!context||typeof context.save!=='function'||typeof context.restore!=='function')throw new TypeError('Portrait requires a drawing context');
      if(!bounds||!['x','y','w','h'].every(k=>Number.isFinite(bounds[k]))||bounds.w<=0||bounds.h<=0||!Number.isFinite(bounds.frame??0))
        throw new TypeError('Invalid portrait drawing bounds');
      if(!synchronousBoolean(ready(),'ready'))return false;
      const request=Object.freeze({x:bounds.x,y:bounds.y,w:bounds.w,h:bounds.h,frame:bounds.frame??0});
      context.save();
      try{
        if(!synchronousBoolean(draw(context,request),'draw'))throw new TypeError('Ready portrait renderer declined its draw');
      }finally{context.restore();}
      return true;
    },
  });
}
