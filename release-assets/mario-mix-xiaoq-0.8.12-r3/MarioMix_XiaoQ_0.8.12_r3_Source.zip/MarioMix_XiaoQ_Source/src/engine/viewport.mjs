/** Pure layout calculations. Scene owners commit simulation size separately. */
// Fixed native rooms expand in complete authored tiles. Scene owners use this
// same width for geometry, camera, rendering, input and checkpoint migration.
export function nativeArenaWidth(viewportWidth) {
  if(!Number.isFinite(viewportWidth)||viewportWidth<128||viewportWidth>1024)throw new RangeError('Invalid native viewport');
  return Math.max(256,Math.floor(viewportWidth/16)*16);
}
export function fitRect(container, content) {
  const scale=Math.min(container.width/content.width,container.height/content.height);
  return {width:content.width*scale,height:content.height*scale,scale};
}
export function createViewport(initial='classic',{density=1}={}) {
  if(![1,3].includes(density))throw new Error('Unsupported pixel density');
  let aspect='classic';
  function setAspect(value) {
    if(!['classic','wide'].includes(value))throw new Error('Unknown aspect: '+value);
    aspect=value;return view();
  }
  function view() {
    const wide=aspect==='wide';
    return Object.freeze({aspect,width:wide?1280/3:256,height:240,scale:wide?3:density,
      pixelWidth:wide?1280:256*density,pixelHeight:wide?720:240*density,menuOffset:wide?(1280/3-256)/2:0});
  }
  function prepare(canvas,ctx) {
    const v=view();
    if(canvas.width!==v.pixelWidth||canvas.height!==v.pixelHeight){canvas.width=v.pixelWidth;canvas.height=v.pixelHeight;}
    ctx.setTransform(v.scale,0,0,v.scale,0,0);ctx.imageSmoothingEnabled=false;return v;
  }
  function centeredOffset(roomWidth){return (view().width-roomWidth)/2;}
  function withWorld(ctx,{offsetX=0,shakeX=0,cameraY=0,top=0,bottom=240},paint) {
    const v=view();ctx.save();
    try{ctx.beginPath();ctx.rect(0,top,v.width,bottom-top);ctx.clip();ctx.translate(offsetX+shakeX,-cameraY);return paint();}
    finally{ctx.restore();}
  }
  function withPanel(canvas,ctx,paint){
    const v=view(),scale=canvas.height/v.height;
    ctx.save();try{ctx.setTransform(scale,0,0,scale,v.menuOffset*scale,0);return paint();}finally{ctx.restore();}
  }
  function screenToWorld(point,rect,{cameraX=0,cameraY=0,offsetX=0}={}) {
    const v=view();return {x:(point.x-rect.left)*v.width/rect.width+cameraX-offsetX,
      y:(point.y-rect.top)*v.height/rect.height+cameraY};
  }
  setAspect(initial);
  return Object.freeze({view,setAspect,prepare,centeredOffset,withWorld,withPanel,screenToWorld});
}
