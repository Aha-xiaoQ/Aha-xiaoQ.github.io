/** Mix policy is independent of the selected hero. Each cue owns a category,
 * loudness target and voice budget. Repeated weapon samples share one channel,
 * as on the original consoles, instead of accumulating over the music. */
const measurements = new WeakMap();
const heroIdentifier=/^[a-zA-Z0-9][a-zA-Z0-9._:-]{0,79}$/;
const playerDeathCues=new Map(Object.entries({death:'mario',bill_death:'bill',mega_death:'megaman',ng07_death:'ryu',ninja_death:'ryu',t06_death:'tank',trio13_death:'sandboxTrio',s33_death:'sonic'}));
const weapons=Object.freeze({
  bill:['bill_shot','bill_normal','bill_machine','bill_spread','bill_flare','bill_flame','bill_laser'],
  mega:['mega_shot','mega_shot_nes','mega_buster','mega_charge_nes','mega_charge_weak','mega_charge_start'],
  trio13:['trio13_gun','trio13_swing'],ng07:['ng07_sword','ng07_throw'],t06:['t06_shot','t06_shoot'],
});
const weaponOwners=new Map(Object.entries(weapons).flatMap(([owner,cues])=>cues.map(cue=>[cue,owner])));
// New content may declare an explicit role and owner instead of depending on
// filename spelling. Existing recordings are listed above for compatibility.
export function audioPolicy(key, {music=false, ui=false,role=null,owner=null,semantic=null,voiceGroup=null}={}) {
  if(role!==null&&!['weapon','ambient','effect','music','ui'].includes(role))throw new TypeError('Unknown audio role');
  if(semantic!==null&&semantic!=='player-death')throw new TypeError('Unknown audio semantic');
  if(voiceGroup!==null&&(typeof voiceGroup!=='string'||!heroIdentifier.test(voiceGroup)||typeof owner!=='string'||!heroIdentifier.test(owner)))throw new TypeError('Declared voice group requires a valid owner and group');
  const resolvedSemantic=semantic||(playerDeathCues.has(key)?'player-death':null);
  const playerHero=playerDeathCues.get(key)||owner;
  if(resolvedSemantic==='player-death'&&(typeof playerHero!=='string'||!heroIdentifier.test(playerHero)))throw new TypeError('Player-death audio requires a valid hero owner');
  const weapon = role==='weapon'||role===null&&weaponOwners.has(key);
  const ambient=role==='ambient'||key==='t06_engine';
  music ||=role==='music';ui ||=role==='ui';
  return {semantic:resolvedSemantic,playerHero,category:music?'music':ui?'ui':'effects',target:music?.18:weapon?.075:.13,
    group:voiceGroup!==null?owner+':'+voiceGroup:weapon?(owner||weaponOwners.get(key)||key)+':weapon':key,voices:voiceGroup!==null||weapon?1:3,
    ...(key==='bill_enemy_explode'?{target:.095,voices:1,group:'contra:explosion'}:{}),
    ...(ambient?{target:.04,voices:1}:{})};
}
export function measureAudio(buffer) {
  if(measurements.has(buffer))return measurements.get(buffer);
  let peak=0,energy=0,count=0;
  const window=Math.max(1,Math.round(buffer.sampleRate*.02));
  for(let ch=0;ch<buffer.numberOfChannels;ch++){
    const samples=buffer.getChannelData(ch);
    for(let start=0;start<samples.length;start+=window){let sum=0;const end=Math.min(samples.length,start+window);
      for(let n=start;n<end;n++){const v=samples[n];peak=Math.max(peak,Math.abs(v));sum+=v*v;}
      if(sum/(end-start)>.000036){energy+=sum;count+=end-start;}
    }
  }
  const result={peak,rms:Math.sqrt(energy/Math.max(1,count))};measurements.set(buffer,result);return result;
}
export function audioGain(buffer,policy) {
  const {peak,rms}=measureAudio(buffer);
  return Math.min(2,.72/Math.max(.05,peak),policy.target/Math.max(.025,rms));
}
export function mediaVolume(category,{soundOn=true,musicVolume=.65,effectsVolume=.55},trim=1){
  const value=category==='music'?musicVolume:effectsVolume;
  return soundOn?Math.max(0,Math.min(1,(Number.isFinite(value)?value:0)*trim)):0;
}
