import {compileWorkshopProject} from './workshop.mjs';
import {campaignCatalog, createCampaignCatalog} from '../campaign/catalog.mjs';
import {freezeData} from '../engine/catalog.mjs';

export const WORKSHOP_RUNTIME_SCHEMA = 'mario-mix-workshop-runtime';
export const WORKSHOP_RUNTIME_VERSION = 1;
const validId = value => typeof value === 'string' && /^[A-Za-z0-9][A-Za-z0-9._:-]{0,79}$/.test(value)
  && !['__proto__', 'prototype', 'constructor'].includes(value);
const own = (object, key) => Object.hasOwn(object, key);
const types = new Set(['Floor', 'Stone', 'Brick', 'Block', 'Platform', 'Pipe', 'PipeVertical', 'PipeHorizontal']);
const materials = new Set(['ground', 'stone', 'brick', 'block', 'platform', 'pipe', 'pipe-side']);
const materialTypes = {ground: 'Floor', stone: 'Stone', brick: 'Brick', block: 'Block', platform: 'Platform', pipe: 'Pipe', 'pipe-side': 'PipeHorizontal'};
const rewards = new Set(['coin', 'multi', 'mushroom', 'flower', 'fireflower', 'star', 'life', '1up', 'bill-m', 'bill-s', 'bill-f', 'bill-l']);
const settings = new Set(['Overworld', 'Underworld', 'Overworld Night', 'Underworld Night', 'Castle']);
const objectFields = {
  spawn: [], coin: [], hazard: [], walker: [], checkpoint: ['targetSpawn'],
  portal: ['targetRoom', 'targetSpawn'], exit: ['finish'],
};
const baseFields = ['id', 'x', 'y', 'w', 'h', 'label', 'note', 'editor', 'metadata'];
const overlap = (a, b) => a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;

export class WorkshopRuntimeError extends Error {
  constructor(diagnostics) {
    super('Workshop runtime rejected: ' + diagnostics.map(d => `${d.path}: ${d.code}`).join('; '));
    this.name = 'WorkshopRuntimeError';
    this.diagnostics = freezeData(structuredClone(diagnostics));
  }
}

// Sorted JSON makes the envelope independent of property order and whitespace.
// FNV is only a reproducibility checksum. Loading also recompiles and compares
// every field; the checksum is never treated as a signature or trust decision.
function canonical(value) {
  if (Array.isArray(value)) return '[' + value.map(canonical).join(',') + ']';
  if (value && typeof value === 'object') return '{' + Object.keys(value).sort()
    .map(key => JSON.stringify(key) + ':' + canonical(value[key])).join(',') + '}';
  return JSON.stringify(value);
}
function fingerprint(value) {
  let hash = 0x811c9dc5;
  for (const byte of new TextEncoder().encode(canonical(value))) hash = Math.imul(hash ^ byte, 0x01000193) >>> 0;
  return hash.toString(16).padStart(8, '0');
}

/** A deliberately bounded adapter for the known xiaoq-map-project v1 format.
 * It does not execute editor code, infer new semantics, or replace the four
 * shipped campaign worlds. Unknown runtime instructions fail before registration.
 */
export function buildWorkshopWorld(input, {levelId, entryRoom, entrySpawn, characterId} = {}) {
  if (!validId(levelId)) throw new WorkshopRuntimeError([{path: 'levelId', code: 'invalid-id', severity: 'error'}]);
  const compiled = compileWorkshopProject(input, {entryRoom, entrySpawn, characterId});
  const source = compiled.workshopSource, characters = campaignCatalog.characters();
  const diagnostics = [...compiled.diagnostics];
  const reject = (path, code) => diagnostics.push({path, code, severity: 'error'});
  const fields = (value, allowed, path) => {
    for (const key of Object.keys(value)) if (!allowed.includes(key)) reject(path + '.' + key, 'unsupported-field');
  };
  const reward = (value, path) => {
    if (typeof value !== 'string' || !rewards.has(value.toLowerCase())) reject(path, 'unsupported-reward');
  };
  const identify = (value, path) => { if (!validId(value)) reject(path, 'invalid-id'); };

  // Validate excluded rooms too. Their source is retained but no unsupported
  // conditional room can hide behind an unreachable-room diagnostic.
  for (const room of source.rooms) {
    const path = 'rooms.' + room.roomId, map = room.map;
    fields(room, ['roomId', 'setting', 'map', 'markers', 'semantics', 'decorations', 'playHero',
      'title', 'description', 'note', 'editor', 'metadata', 'provenance', 'underwater', 'assembly',
      'art', 'playerSkin', 'enemySkins', 'enemiesEditable'], path);
    fields(map, ['id', 'title', 'width', 'height', 'tileSize', 'geometry', 'objects', 'baseGeometry',
      'provenance', 'editor', 'metadata'], path + '.map');
    identify(room.roomId, path);
    identify(map.id, path + '.map.id');
    if (room.setting !== undefined && !settings.has(room.setting)) reject(path + '.setting', 'unsupported-setting');
    if (room.underwater !== undefined && room.underwater !== false) reject(path + '.underwater', 'unsupported-underwater');
    if (room.assembly !== undefined) reject(path + '.assembly', 'unsupported-conditional-sections');
    if (room.playerSkin !== undefined || (room.art !== undefined && (!room.art || typeof room.art !== 'object' || Array.isArray(room.art) || Object.keys(room.art).length))) {
      reject(path + '.art', 'custom-art-adapter-required');
    }
    const semantics = new Map();
    for (const semantic of room.semantics || []) {
      const at = path + '.semantics.' + semantic?.id;
      if (!semantic || typeof semantic !== 'object' || Array.isArray(semantic)) { reject(at, 'invalid-semantic'); continue; }
      fields(semantic, ['id', 'type', 'kind', 'source'], at);
      identify(semantic.id, at);
      const type = semantic.kind || semantic.type;
      if (!types.has(type) || (semantic.kind && semantic.type && semantic.kind !== semantic.type)) reject(at, 'unsupported-semantic');
      if (semantics.has(semantic.id)) reject(at, 'duplicate-semantic');
      semantics.set(semantic.id, type);
      if (!map.geometry.some(g => g.id === semantic.id)) reject(at, 'semantic-has-no-geometry');
      const data = semantic.source;
      if (data !== undefined) {
        if (!data || typeof data !== 'object' || Array.isArray(data)) { reject(at + '.source', 'invalid-semantic-source'); continue; }
        fields(data, ['thing', 'macro', 'x', 'y', 'width', 'height', 'contents'], at + '.source');
        for (const key of ['thing', 'macro']) if (own(data, key) && !types.has(data[key])) reject(at + '.source.' + key, 'unsupported-semantic-source');
        for (const key of ['x', 'y', 'width', 'height']) if (own(data, key) && !Number.isFinite(data[key])) reject(at + '.source.' + key, 'invalid-coordinate');
        if (own(data, 'contents')) {
          if (!['Brick', 'Block'].includes(type)) reject(at + '.source.contents', 'reward-needs-block');
          reward(data.contents, at + '.source.contents');
        }
      }
    }
    for (const marker of room.markers) reject(path + '.markers.' + (marker.id || marker.kind), 'marker-adapter-required');
    for (const shape of map.geometry) {
      const at = path + '.geometry.' + shape.id;
      identify(shape.id, at);
      fields(shape, [...baseFields, 'collision', 'material', 'motion', 'reward'], at);
      if (!['solid', 'oneway'].includes(shape.collision)) reject(at + '.collision', 'unsupported-collision');
      if (shape.material !== undefined && !materials.has(shape.material)) reject(at + '.material', 'unsupported-material');
      const semanticType = semantics.get(shape.id) === 'PipeVertical' ? 'Pipe' : semantics.get(shape.id);
      if (semanticType && shape.material && materialTypes[shape.material] !== semanticType) reject(at, 'material-semantic-conflict');
      if (!shape.material && !semantics.has(shape.id) && shape.collision !== 'oneway' && shape.y < map.height - 32) reject(at, 'terrain-appearance-required');
      if (shape.motion) fields(shape.motion, ['axis', 'min', 'max', 'speed'], at + '.motion');
      if (shape.reward !== undefined) {
        const type = semantics.get(shape.id);
        if (!['brick', 'block'].includes(shape.material) && !['Brick', 'Block'].includes(type)) reject(at, 'reward-needs-block');
        reward(shape.reward, at + '.reward');
      }
    }
    for (const object of map.objects) {
      const at = path + '.objects.' + object.id;
      identify(object.id, at);
      if (object.id === 'sky-return' || object.id.endsWith('-vine-portal')) reject(at, 'reserved-runtime-id');
      if (!own(objectFields, object.kind)) { reject(at, 'unsupported-object:' + object.kind); continue; }
      fields(object, [...baseFields, 'kind', ...objectFields[object.kind]], at);
      for (const key of ['targetRoom', 'targetSpawn']) if (own(object, key)) identify(object[key], at + '.' + key);
      if (object.finish !== undefined) {
        if (!object.finish || typeof object.finish !== 'object' || Array.isArray(object.finish)) { reject(at + '.finish', 'invalid-finish'); continue; }
        fields(object.finish, ['kind', 'walkTarget'], at + '.finish');
        if (object.finish.kind !== 'flag') reject(at + '.finish', 'unsupported-finish');
        if (own(object.finish, 'walkTarget') && (!Number.isFinite(object.finish.walkTarget) || object.finish.walkTarget < object.x || object.finish.walkTarget > map.width)) reject(at + '.finish.walkTarget', 'invalid-walk-target');
      }
      if (object.kind === 'spawn') for (const actor of characters) {
        const body = {x: object.x, y: object.y + object.h - actor.height, w: actor.width, h: actor.height};
        if (body.x < 0 || body.y < 0 || body.x + body.w > map.width || body.y + body.h > map.height) reject(at + '.' + actor.id, 'spawn-body-out-of-bounds');
        if (map.geometry.some(g => g.collision === 'solid' && overlap(body, g))) reject(at + '.' + actor.id, 'spawn-intersects-solid');
      }
    }
    if (room.enemySkins !== undefined) {
      if (!room.enemySkins || typeof room.enemySkins !== 'object' || Array.isArray(room.enemySkins)) reject(path + '.enemySkins', 'invalid-enemy-skins');
      else for (const [id, skin] of Object.entries(room.enemySkins)) {
        if (!map.objects.some(o => o.id === id && o.kind === 'walker') || !['walker', 'goomba', 'enemy-goomba'].includes(skin)) reject(path + '.enemySkins.' + id, 'unsupported-enemy-skin');
      }
    }
    for (const decoration of room.decorations) {
      const at = path + '.decorations.' + decoration.id;
      identify(decoration.id, at);
      fields(decoration, [...baseFields, 'material'], at);
      if (!materials.has(decoration.material)) reject(at, 'unsupported-decoration-material');
    }
  }
  // This is graph reachability, not a physical playthrough guarantee.
  const canFinish = new Set(compiled.rooms.filter(r => r.objects.some(o => o.kind === 'exit')).map(r => r.id));
  for (let changed = true; changed;) {
    changed = false;
    for (const room of compiled.rooms) if (!canFinish.has(room.id) && room.objects.some(o => o.kind === 'portal' && canFinish.has(o.targetRoom))) {
      canFinish.add(room.id); changed = true;
    }
  }
  for (const room of compiled.rooms) if (!canFinish.has(room.id)) reject('rooms.' + room.id, 'no-route-to-finish');
  if (diagnostics.some(d => d.severity === 'error')) throw new WorkshopRuntimeError(diagnostics);

  const reachable = new Set(compiled.rooms.map(r => r.id));
  const visualRooms = source.rooms.filter(r => reachable.has(r.roomId)).map(r => structuredClone(r));
  const rooms = Object.fromEntries(visualRooms.map(r => [r.roomId, structuredClone(r.map)]));
  const world = {
    schema: WORKSHOP_RUNTIME_SCHEMA, version: WORKSHOP_RUNTIME_VERSION, level: levelId,
    plan: {stage: {id: levelId + '-stage', title: source.title, driver: 'platform-v1', status: 'candidate',
      entryRoom: compiled.entry.room, entrySpawn: compiled.entry.spawn,
      rooms: Object.fromEntries(visualRooms.map(r => [r.roomId, r.map.id])),
      characters: characters.map(c => c.id), requiredCapabilities: ['jump']}, rooms},
    visualRooms, workshopSource: source,
    provenance: {format: source.format, version: source.version, projectId: source.id,
      authoringCharacter: compiled.characterId, adapter: 'workshop-runtime-v1'},
    runtime: {loadable: true, driver: 'platform-v1', playability: 'unverified',
      validation: 'strict-data-and-adapter-contract', excludedRooms: compiled.excludedRooms,
      diagnostics: [...diagnostics, ...compiled.excludedRooms.map(id => ({path: 'rooms.' + id, code: 'excluded-unreachable-room', severity: 'info'}))]},
  };
  world.content = {algorithm: 'fnv1a32-utf8', scope: 'canonical-json-excluding-content', digest: fingerprint(world)};
  return createCampaignCatalog({characters, worlds: [world]}).world(levelId);
}

/** Reload JSON as untrusted data. Rebuild from retained source and compare the
 * whole envelope, so editing either collision data or a checksum alone fails. */
export function validateWorkshopRuntime(input) {
  const text = typeof input === 'string' ? input : JSON.stringify(input);
  if (typeof text !== 'string' || new TextEncoder().encode(text).length > 48 * 1024 * 1024) throw new Error('Workshop runtime: 48 MB limit exceeded');
  const supplied = JSON.parse(text, (key, value) => {
    if (['__proto__', 'prototype', 'constructor'].includes(key)) throw new Error('Workshop runtime: unsafe field ' + key);
    return value;
  });
  if (!supplied || supplied.schema !== WORKSHOP_RUNTIME_SCHEMA || supplied.version !== WORKSHOP_RUNTIME_VERSION) throw new Error('Workshop runtime: expected version 1 runtime package');
  const expected = buildWorkshopWorld(supplied.workshopSource, {levelId: supplied.level,
    entryRoom: supplied.plan?.stage?.entryRoom, entrySpawn: supplied.plan?.stage?.entrySpawn,
    characterId: supplied.provenance?.authoringCharacter});
  if (canonical(supplied) !== canonical(expected)) throw new Error('Workshop runtime: content differs from validated source; reimport the project');
  return expected;
}
