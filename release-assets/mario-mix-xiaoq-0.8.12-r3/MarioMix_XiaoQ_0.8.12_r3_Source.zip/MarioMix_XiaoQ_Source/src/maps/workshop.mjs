import {freezeData} from '../engine/catalog.mjs';

const fail = (path, message) => { throw new Error(`${path}: ${message}`); };
const plain = (value, path) => {
  if (!value || typeof value !== 'object' || Array.isArray(value)) fail(path,'expected object');
};
const list = (value, path, limit=20000) => {
  if (!Array.isArray(value) || value.length > limit) fail(path,'invalid array or limit exceeded');
};
const label = (value, path, limit=100) => {
  if (typeof value !== 'string' || !value.trim() || value.length > limit) fail(path,'invalid text');
};
const integer = (value, min, max) => Number.isSafeInteger(value) && value >= min && value <= max;
const rect = (value, path) => {
  plain(value,path);
  if (!['x','y','w','h'].every(key=>Number.isFinite(value[key])) || value.w<=0 || value.h<=0 || ['x','y','w','h'].some(key=>Math.abs(value[key])>100000)) fail(path,'invalid pixel rectangle');
};

/** Parse the existing workshop format without dropping unknown editorial metadata.
 * No source JavaScript is executed. Imported coordinates are already pixels.
 */
export function parseWorkshopProject(input) {
  const text = typeof input === 'string' ? input : JSON.stringify(input);
  if (typeof text !== 'string' || new TextEncoder().encode(text).length > 12*1024*1024) fail('project','12 MB limit exceeded');
  const doc = JSON.parse(text,(key,value)=>{
    if (['__proto__','prototype','constructor'].includes(key)) fail('project','unsafe field '+key);
    return value;
  });
  plain(doc,'project');
  if (doc.format!=='xiaoq-map-project' || doc.version!==1) fail('project','expected xiaoq-map-project version 1');
  label(doc.id,'project.id'); label(doc.title,'project.title');
  list(doc.rooms,'rooms',128);
  if (!doc.rooms.length) fail('rooms','at least one room required');
  const roomIds = new Set();
  if (doc.playHero!==undefined && !['mario','bill'].includes(doc.playHero)) fail('playHero','unsupported workshop character');
  for (const room of doc.rooms) {
    plain(room,'room'); label(room.roomId,'roomId');
    if (roomIds.has(room.roomId)) fail(room.roomId,'duplicate room');
    roomIds.add(room.roomId);
    if (room.playHero!==undefined && !['mario','bill'].includes(room.playHero)) fail(room.roomId,'unsupported workshop character');
    const map = room.map, path = `room.${room.roomId}`;
    plain(map,path+'.map');
    if (!integer(map.width,256,32768) || !integer(map.height,120,4096) || Math.ceil(map.width/16)*Math.ceil(map.height/16)>262144 || map.tileSize!==16) fail(path,'invalid size or tileSize');
    const ids = new Set();
    for (const key of ['geometry','objects']) {
      list(map[key],path+'.'+key);
      for (const item of map[key]) {
        rect(item,path+'.'+key); label(item.id,path+'.id');
        if (ids.has(item.id)) fail(path,'duplicate element '+item.id);
        ids.add(item.id);
        if (item.motion) {
          const motion=item.motion; plain(motion,path+'.motion');
          if (!['x','y'].includes(motion.axis) || !['min','max','speed'].every(key=>Number.isFinite(motion[key])) || motion.max<=motion.min || motion.speed<=0) fail(path,'invalid moving platform');
        }
      }
    }
    for (const key of ['markers','decorations']) {
      list(room[key],path+'.'+key);
      for (const item of room[key]) {
        plain(item,path+'.'+key);
        if (!Number.isFinite(item.x) || !Number.isFinite(item.y)) fail(path,'invalid marker position');
        if (key==='decorations') rect(item,path+'.decoration');
      }
    }
    if (room.semantics!==undefined) list(room.semantics,path+'.semantics');
  }
  return freezeData(doc);
}

/** Compile a room graph for adapter development, NOT a promise of playable parity.
 * Raw source + semantics stay attached. No repair, clipping, tile snapping or
 * capability inference from the workshop's generic placeholder character.
 */
export function compileWorkshopProject(input,{entryRoom,entrySpawn,characterId}={}) {
  const source = parseWorkshopProject(input);
  label(entryRoom,'entryRoom');
  const byId = new Map(source.rooms.map(room=>[room.roomId,room]));
  const first = byId.get(entryRoom);
  if (!first) fail('entryRoom','unknown room');
  const desired = characterId ?? source.playHero ?? first.playHero ?? 'mario';
  if (!['mario','bill'].includes(desired)) fail('characterId','workshop supports mario/bill identity only');
  const spawnId=entrySpawn ?? first.map.objects.find(item=>item.kind==='spawn')?.id;
  if (!first.map.objects.some(item=>item.id===spawnId&&item.kind==='spawn')) fail('entrySpawn','missing spawn');
  const reached = new Set(), queue = [entryRoom];
  for (let i=0;i<queue.length;i++) {
    const id=queue[i];if(reached.has(id))continue;reached.add(id);
    const room=byId.get(id);
    for (const item of room.map.objects) {
      if (item.kind==='portal') {
        const target=byId.get(item.targetRoom);
        if (!target?.map.objects.some(spawn=>spawn.kind==='spawn'&&spawn.id===item.targetSpawn)) fail(id+'.'+item.id,'invalid portal destination');
        queue.push(item.targetRoom);
      }
      if (item.kind==='checkpoint' && (item.targetRoom!==undefined || !room.map.objects.some(spawn=>spawn.kind==='spawn'&&spawn.id===item.targetSpawn))) fail(id+'.'+item.id,'invalid local checkpoint');
    }
  }
  const diagnostics=[], features=new Set(), rooms=[];
  for (const room of source.rooms.filter(room=>reached.has(room.roomId))) {
    const map=room.map, roomPath=room.roomId;
    const roomHero=source.playHero??room.playHero??desired;
    if (roomHero!==desired) fail(roomPath,'conflicting room character; normalize in the workshop first');
    for (const item of [...map.geometry,...map.objects]) {
      if (item.x<0 || item.y<0 || item.x+item.w>map.width || item.y+item.h>map.height) diagnostics.push({code:'out-of-bounds',path:roomPath+'.'+item.id,severity:'error'});
      if (item.motion) {
        features.add('moving-platform');
        const m=item.motion,limit=m.axis==='x'?map.width:map.height,extent=m.axis==='x'?item.w:item.h;
        if(m.min<0||m.max+extent>limit||item[m.axis]<m.min||item[m.axis]>m.max)diagnostics.push({code:'motion-out-of-bounds',path:roomPath+'.'+item.id,severity:'error'});
      }
      if (item.reward) features.add('reward-block');
    }
    for (const shape of map.geometry) {
      if (!['solid','oneway'].includes(shape.collision)) diagnostics.push({code:'unsupported-collision',path:roomPath+'.'+shape.id,severity:'error'});
      features.add('collision:'+shape.collision);
    }
    for (const item of map.objects) {
      features.add('object:'+item.kind);
      if (!['spawn','checkpoint','portal','exit','coin','hazard','walker'].includes(item.kind)) diagnostics.push({code:'requires-object-adapter',path:roomPath+'.'+item.id,severity:'warning'});
    }
    for (const marker of room.markers) features.add('marker:'+marker.kind);
    if (room.semantics?.length) features.add('workshop-semantics');
    if (room.underwater) features.add('underwater');
    if (room.assembly) features.add('conditional-sections');
    const {map:unused,...editorial}=room;
    rooms.push({id:room.roomId,width:map.width,height:map.height,geometry:map.geometry,objects:map.objects,provenance:map.provenance,workshop:editorial});
  }
  return freezeData({
    schema:'mario-mix-level',version:1,id:source.id,title:source.title,units:'pixels',tileSize:16,
    entry:{room:entryRoom,spawn:spawnId},characterId:desired,rooms,
    requiredFeatures:[...features].sort(),excludedRooms:source.rooms.filter(room=>!reached.has(room.roomId)).map(room=>room.roomId),
    diagnostics,status:diagnostics.some(item=>item.severity==='error')?'needs-repair':'validated-data',
    runtime:{playable:false,reason:'Workshop semantics and character adapters must pass runtime conformance before registration.'},
    workshopSource:source,
  });
}
