/* Rescue cast uses source pixels, native proportions and one shared feet anchor.
 * Mario's Toad and Ori's complete original chapter remain in their own renderers. */
const rf07CompanionImages={};
for(const [key,url]of Object.entries({guide:'@@E04:uri:a274@@',irene:'@@E04:uri:a275@@',base:'@@E04:uri:a075@@',naru:'@@E04:uri:a2400@@',a2410:'@@E04:uri:a2410@@',a2411:'@@E04:uri:a2411@@',a2412:'@@E04:uri:a2412@@',a2413:'@@E04:uri:a2413@@',a2414:'@@E04:uri:a2414@@',a2415:'@@E04:uri:a2415@@'})){
 const image=new Image();image.src=url;mainlineAssetJobs.push(image.decode().then(()=>{
  const c=document.createElement('canvas');c.width=image.width;c.height=image.height;const g=c.getContext('2d');g.drawImage(image,0,0);
  if(key==='irene'){const d=g.getImageData(0,0,c.width,c.height);for(let n=0;n<d.data.length;n+=4)if(d.data[n]===111&&d.data[n+1]===49&&d.data[n+2]===152)d.data[n+3]=0;g.putImageData(d,0,0);}
  rf07CompanionImages[key]=c;
 }));
}
const rf083Naru=@@E04:file:src/data/ori-naru-original.json@@;
const rf07Companions=Object.freeze({bill:'LANCE',megaman:'DR LIGHT',ryu:'IRENE',tank:'BASE',sandboxTrio:'GUIDE',sonic:'AMY',ori:'NARU'});
mainlineAssetJobs.push(s35AmyReady);
function rf07DrawCompanion(g,marker,view,level){
 if(level==='8-4')return false;
 if(view.p.hero==='ori'&&level==='1-4')return false;
 if(marker.kind!=='castle-finish')return false;
 const sourceCast=E04Modules.rescueCastSources[E04Modules.castleReunion(view.p.hero,level).cast];
 if(!sourceCast&&!rf07Companions[view.p.hero])return false;
 const {companionX:x,feet}=E04Modules.rescueAnchors(marker,view.p),arrived=['reunion','score'].includes(view.finish?.phase);
 const draw=(im,sx,sy,w,h,scale=1,flip=false,foot=h)=>{if(!im)return;g.save();g.translate(Math.round(x),feet);g.scale(flip?-1:1,1);g.drawImage(im,sx,sy,w,h,-w*scale/2,-foot*scale,w*scale,h*scale);g.restore();};
 g.save();g.imageSmoothingEnabled=false;
 if(sourceCast){draw(rf07CompanionImages[sourceCast.asset],...sourceCast.src,sourceCast.scale,sourceCast.flip,sourceCast.feet);g.restore();return true;}
 switch(view.p.hero){
  case'ori':{const im=rf07CompanionImages.naru,f=rf083Naru.frames[Math.floor(view.tick*rf083Naru.fps/60)%rf083Naru.frames.length],scale=.13;if(im){g.save();g.translate(x,feet);g.scale(-scale,scale);g.drawImage(im,...f.rect,f.offset[0],f.offset[1]-218,f.rect[2],f.rect[3]);g.restore();}break;}
  case'bill':draw(mixImages.bill,322,18,23,43,1,true);break;
  case'megaman':draw(mixImages.megaman,365,55,16,21);break;
  case'ryu':draw(rf07CompanionImages.irene,359,314,15,32);break;
  case'tank':{const im=rf07CompanionImages.base;if(im)draw(im,0,0,im.width,im.height,16/im.height,false,30);break;}
  // NPC_22's native idle faces left; its visible shoe bottom is row 54, not
  // the 56px frame edge. Anchor that edge to the same y=208 walking surface.
  case'sandboxTrio':draw(rf07CompanionImages.guide,0,0,40,56,.65,false,54);break;
  case'sonic':{const seq=arrived?[5,6,7,8,9,10,11,12,13,12,11,10,9,8,7]:[0,0,0,0,0,1,2,3,4,3,2,1];const age=arrived?view.finish.age:view.tick;draw(s35AmyImage,seq[Math.floor(age/(arrived?9:12))%seq.length]*48,0,48,48,.70,true,45);break;}
 }
 g.restore();return true;
}
