/* Shipped mappings preserve the old ordering and aliases. Independent actors
 * declare actions directly and do not use this compatibility projection. */
function projectLegacyInput(env,mode){
 const {pad,press,held,pointer,pointerButtons,device:inputDevice,bindings,previous:lastActorInput,keyPresses}=env;
 const pointerAttack=!!pointerButtons[0],pointerBash=!!pointerButtons[2];
   let commandBindings=null;
   const v=E04Modules.mapInputActions(LEGACY_INPUT_ACTIONS,env);
   v.x=Math.sign(Number(v.right)-Number(v.left)+pad.x);delete v.left;delete v.right;
   v.up ||=pad.up;v.down ||=pad.down;
   Object.assign(v,{pointer:{...pointer},aimX:pointer.x,aimY:pointer.y,device:inputDevice,ax:pad.axisX,ay:pad.axisY,rightAim:pad.rightAim});
   if(mode==='bash'){
    const binds=bindings;
    Object.assign(v,E04Modules.mapInputActions(withActionTouch(binds),env,true));v.attack ||=pointer.down||pointerAttack||held('run');
    v.bash=v.bash||held('special')||held('ability')||pointer.bash||pointerBash;v.dash ||=held('extra');if(pad.aimActive){v.ax=pad.axisX;v.ay=pad.axisY;}if(inputDevice==='gamepad')v.pointer.active=false;
    v.x=Math.sign((v.right?1:0)-(v.left?1:0)+pad.x);v.up ||=pad.up;v.down ||=pad.down;v.ability=v.bash;
    if(binds===o24Binds){
     // Bash keeps the analogue vector; movement remains digital. A connected
     // pad must not leave axes behind when keyboard/mouse owns this frame.
     if(inputDevice==='gamepad'){v.ax=pad.bashAxisX??pad.axisX??0;v.ay=pad.bashAxisY??pad.axisY??0;v.bashAimSource='pad';}
     else{delete v.ax;delete v.ay;v.bashAimSource=pointer.active&&(pointer.bash||pointerBash||!(v.x||v.up||v.down))?'mouse':'keys';}
    }
   }else if(mode==='terra'){
    const binds=bindings;commandBindings=binds;
    Object.assign(v,E04Modules.mapInputActions(binds?withActionTouch(binds):TERRA_FALLBACK_ACTIONS,env));
    if(pad.buttons.some(Boolean)||pad.x||pad.up||pad.down)v.device='gamepad';v.attack ||=pointer.down||pointerAttack;v.tool=v.toolNext||held('ability')||held('special');v.cycle=false;v.mount ||=held('extra');v.weapon ||=held('cycle');
    if(binds){v.x=Math.sign(Number(v.right)-Number(v.left)+pad.x);v.up ||=pad.up;v.down ||=pad.down;}
   }else{v.run ||=held('attack')||held('extra');v.attack=v.attack||v.run||(mode==='abilityAttack'&&(held('special')||held('ability')));if(mode==='ryu')Object.assign(v,E04Modules.mapInputActions(RYU_INPUT_ACTIONS,env));}
   if(inputDevice!=='gamepad'&&!pad.aimActive){delete v.ax;delete v.ay;}
   for(const key of ['weapon','mount','mountCycle','heal','interact','tool','toolPrev','toolNext','torch','recall'])v[key+'Pressed']=!!v[key]&&(!lastActorInput[key]||commandBindings?.[key]?.keys.some(k=>keyPresses.has(k)));
   for(let i=0;i<6;i++)if(press('Digit'+(i+1))&&(!lastActorInput['digit'+i]||keyPresses.has('Digit'+(i+1))))v.toolIndex=i;

 return v;
}
const LEGACY_INPUT_ACTIONS={
 left:{keys:['ArrowLeft','KeyA'],pad:[],touch:['left']},right:{keys:['ArrowRight','KeyD'],pad:[],touch:['right']},
 up:{keys:['ArrowUp','KeyW'],pad:[],touch:['up']},down:{keys:['ArrowDown','KeyS'],pad:[],touch:['down']},
 jump:{keys:['Space','KeyK','KeyZ'],pad:[0],touch:['jump']},attack:{keys:['KeyJ','KeyX'],pad:[1,3],touch:['run','attack'],pointerButtons:[0]},
 run:{keys:['ShiftLeft','ShiftRight'],pad:[1,3],touch:['run']},ability:{keys:['KeyE'],pad:[2],touch:['special','ability']},
 cycle:{keys:['KeyL'],pad:[4],touch:['cycle']},dash:{keys:['ShiftLeft','ShiftRight'],pad:[5],touch:['extra']},
 climb:{keys:['ShiftLeft','ShiftRight'],pad:[5]},glide:{keys:['ShiftLeft','ShiftRight'],pad:[5]},light:{keys:['KeyQ']},tool:{keys:['KeyQ'],pad:[4]},
 weapon:{keys:['KeyV'],pad:[3]},mount:{keys:['KeyM'],pad:[10]},mountCycle:{keys:['KeyN']},heal:{keys:['KeyH'],pad:[6]},interact:{keys:['KeyE'],pad:[7]}
};
const withActionTouch=binds=>Object.fromEntries(Object.entries(binds).map(([name,b])=>[name,{...b,touch:[name]}]));
const RYU_INPUT_ACTIONS={ability:{keys:['KeyL'],pad:[2],touch:['special','ability']},cycle:{keys:['KeyE'],pad:[4],touch:['extra','cycle']}};
const TERRA_FALLBACK_ACTIONS={attack:{keys:['KeyJ','KeyX','ShiftLeft','ShiftRight'],pad:[1,2,7],touch:['attack','run']},toolPrev:{keys:['BracketLeft'],pad:[4]},toolNext:{keys:['BracketRight'],pad:[5]},weapon:{keys:['KeyQ'],pad:[3]},mount:{keys:['KeyF'],pad:[11]},heal:{keys:['KeyH'],pad:[10]},interact:{keys:['KeyE','KeyL'],pad:[6]},mountCycle:{keys:['KeyV']},torch:{keys:['KeyG']},recall:{keys:['KeyB'],pad:[8]}};
const LEGACY_INPUT_KEYS=['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','KeyA','KeyD','KeyW','KeyS','Space','KeyK','KeyZ','KeyJ','KeyX','KeyE','KeyL','ShiftLeft','ShiftRight','KeyQ','KeyV','KeyM','KeyN','KeyH','KeyG','KeyB','BracketLeft','BracketRight','Digit1','Digit2','Digit3','Digit4','Digit5','Digit6'];
// These are existing strings moved with their profiles; no UI copy changes.
const legacyInputHelp={bill:'射击　J / X · 方向瞄准<br>下穿　↓ + 空格',megaman:'蓄力炮　按住 J / X，松开发射',ryu:'挥刀　J / X<br>忍术　L · 换武器 E',tank:'移动　方向键 / WASD<br>开炮　J / X / 空格',sandboxTrio:'工具　1–6 / [ ] · 使用 J / 鼠标<br>武器　Q · 坐骑 F / V<br>治疗　H · 交互 E',ori:'精灵之火　J / 鼠标左键<br>弹射　E / 鼠标右键<br>冲刺　Shift · 滑翔 Q · 光弹 L',sonic:'蓄力冲刺　按住 J，松开发射<br>追踪　E · 空中冲刺 Shift<br>贴墙上跑　方向 + ↑'};
function legacyInputProfile(id,mode,options={}){
 return {version:1,id:'legacy:'+id,actions:LEGACY_INPUT_ACTIONS,acceptKeys:LEGACY_INPUT_KEYS,ownedKeys:[],capturePointer:[],conflicts:'allow',
  help:legacyInputHelp[id],showJumpHelp:id!=='tank',abilityLabel:({sandboxTrio:'工具',ryu:'忍术',ori:'弹射',sonic:'追踪',tank:'开炮',bill:'射击',megaman:'蓄力'})[id]||'能力',
  extraLabel:id==='sandboxTrio'?'坐骑':['sonic','ori'].includes(id)?'冲刺':id==='ryu'?'换武器':'加速',project:env=>projectLegacyInput(env,mode),...options};
}
const mainlineInputProfiles={
 mario:legacyInputProfile('mario','standard'),bill:legacyInputProfile('bill','abilityAttack'),megaman:legacyInputProfile('megaman','abilityAttack'),
 ryu:legacyInputProfile('ryu','ryu',{actions:{...LEGACY_INPUT_ACTIONS,...RYU_INPUT_ACTIONS}}),tank:legacyInputProfile('tank','abilityAttack'),
 ori:legacyInputProfile('ori','bash',{touchExtras:[{slot:'glide',label:'滑翔'},{slot:'climb',label:'攀爬'},{slot:'light',label:'光弹'}],actions:o24Binds,bindings:()=>o24Binds,capturePointer:[2]}),
 sonic:legacyInputProfile('sonic','bash',{actions:s33Binds,bindings:()=>s33Binds,capturePointer:[2]}),
 sandboxTrio:legacyInputProfile('sandboxTrio','terra',{actions:{...LEGACY_INPUT_ACTIONS,...TERRA_FALLBACK_ACTIONS},bindings:context=>context.actorPort?.bindings?.(),ownedKeys:['KeyF']})
};
