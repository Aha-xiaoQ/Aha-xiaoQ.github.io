/* Original installed PC atlas, FrameGuids, material crop and PCM. */
const oriGinsoSource=@@E04:file:src/data/ori-ginso-original.json@@;
const oriGinsoArt={};
for(const [name,uri]of Object.entries(oriGinsoSource.images)){const im=new Image();im.src=uri;oriGinsoArt[name]=im;mainlineAssetJobs.push(im.decode());}
function oriGinsoFrame(g,name,x,y,age,{scale=.16,rotation=0,dir=-1,alpha=1}={}){
 const a=oriGinsoSource.animations[name];if(!a?.frames.length)return false;const n=Math.floor(Math.max(0,age)*a.fps/60),f=a.frames[a.loop?n%a.frames.length:Math.min(a.frames.length-1,n)],im=oriGinsoArt[f.atlas];
 if(!im?.naturalWidth)return false;const [sx,sy,w,h]=f.rect,[dx,dy]=f.offset;
 g.save();g.imageSmoothingEnabled=true;g.imageSmoothingQuality='high';g.globalAlpha*=alpha;g.translate(x,y);g.rotate(rotation);if(dir<0)g.scale(-1,1);
 // Original AtlasSpriteTextureBinder.ApplyToMesh swaps the UV-grid vertex
 // x/y axes without negating them. Converting Unity up-Y to image down-Y
 // yields the anti-diagonal transform below, not a simple 90-degree turn.
 // CenterOffset is logical; the exported offset used the packed dimensions.
 if(f.flipped){const ux=dx+(w-h)/2,uy=dy+(h-w)/2;g.translate((ux+h)*scale,(uy+w)*scale);g.transform(0,-1,-1,0,0,0);g.drawImage(im,sx,sy,w,h,0,0,w*scale,h*scale);}
 else g.drawImage(im,sx,sy,w,h,dx*scale,dy*scale,w*scale,h*scale);g.restore();return true;
}
function oriGinsoDrawEnemy(g,e){
 if(e.contractId==='ori-pc:mortar-fire'){
  const im=oriGinsoArt['mortar-projectile'];if(!im?.naturalWidth)return false;
  g.save();g.imageSmoothingEnabled=true;g.translate(e.x+e.w/2,e.y+e.h/2);g.rotate(Math.atan2(e.vy,e.vx));g.drawImage(im,-8,-4,16,8);g.restore();return true;
 }
 if(e.contractId!=='ori-pc:mortar')return false;
 const dying=e.kind==='ginso-mortar-death',names={hidden:'sootMortarHidden',emerge:'sootMortarUnhide',hide:'sootMortarHide',idle:'sootMortarIdle',charge:'sootMortarIdleToAlert',shoot:'mortarShootLeft'};
 let name=dying?'sootMortarDeathA':names[e.mortarState]||names.idle,dir=e.dir;
 if(!dying&&e.mortarState==='shoot'&&e.aimVelocity){const v=e.aimVelocity,r=e.rotation||0,localX=v.vx*Math.cos(r)+v.vy*Math.sin(r),localY=-v.vx*Math.sin(r)+v.vy*Math.cos(r);
  const angle=Math.atan2(-localY,localX),n=Math.max(0,Math.min(4,Math.round(angle/(Math.PI/4))));name=['mortarShootRight','mortarShootUpRight','mortarShootUp','mortarShootUpLeft','mortarShootLeft'][n];dir=1;}
 return oriGinsoFrame(g,name,e.x+e.w/2,e.y+e.h-11,dying?e.age||0:e.stateAge||0,{rotation:e.rotation||0,dir,alpha:e.flash%2?.45:1});
}
function oriGinsoDrawScene({view:v,stage,foes,room,defeated,rewardClaimed,departure=null}){
 const width=room.width,scale=Math.min(W/width,H/240),offset=(W-width*scale)/2;
 ctx.save();ctx.fillStyle='#020b0e';ctx.fillRect(0,0,W,H);ctx.translate(offset,(H-240*scale)/2);ctx.scale(scale,scale);
 ctx.beginPath();ctx.rect(0,0,width,240);ctx.clip();rf093DrawOriForest(ctx,v,width);
 ctx.save();ctx.beginPath();ctx.rect(0,0,width,240);ctx.clip();ctx.translate(-v.cam,0);
 for(const q of v.geometry)rf093DrawOriTerrain(ctx,q);
 // A quiet recess is present during battle; the opened passage gains a
 // vertical light and ground path after the physical door has been removed.
 // This is authored crossover scenery, not a substituted original game asset.
 const open=defeated&&!v.geometry.some(q=>q.id==='exit-door'),e=room.exit,cx=e.x+e.w/2;
 ctx.save();ctx.fillStyle=open?'#103d42':'#07171b';ctx.beginPath();ctx.ellipse(cx,e.y+e.h/2,e.w/2-2,e.h/2,0,0,Math.PI*2);ctx.fill();
 if(open){const pulse=.8+.2*Math.sin((v.tick+(departure?.age||0))/18),glow=ctx.createRadialGradient(cx,e.y+e.h/2,2,cx,e.y+e.h/2,32);
  glow.addColorStop(0,rewardClaimed?'#c3ffffa0':'#76d9d360');glow.addColorStop(1,'#83e3e300');ctx.globalAlpha=pulse;ctx.fillStyle=glow;ctx.fillRect(cx-32,e.y-10,64,e.h+20);
  ctx.strokeStyle=rewardClaimed?'#c9ffff':'#5fa49f';ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(cx,e.y+e.h/2,7,e.h/2-3,0,0,Math.PI*2);ctx.stroke();
  for(let i=0;i<5;i++){ctx.fillStyle='rgba(156,236,225,'+(.15+i*.1)+')';ctx.fillRect(e.x-45+i*10,e.y+e.h-2,6,1);}
 }ctx.restore();
 if(!departure){for(const e of v.enemies)foes.draw(ctx,e,v.tick);
 for(const q of v.items){if(!foes.draw(ctx,q,v.tick))stage.drawPickup(ctx,q,v.tick);}}
 if(departure){const p=departure.body;if(departure.bodyVisible)o24Ori(ctx,p.x+p.w/2,p.y+p.h,departure.moving?(p.grounded?'run':'fall'):'idle',departure.animation,p.facing,departure.alpha,false);}
 else{stage.drawWorld(ctx,v);if(v.p.dying||!v.p.invulnerable||v.tick%8<4)stage.drawPlayer(ctx,v.p,v.tick,v);}
 ctx.restore();rf093DrawOriHud(ctx,v,width);ctx.restore();
}
function createOriGinsoAudioPort(){
 let jobs=null,loadedContext=null,owner=null,mood='boss',issued=false,muted=false,sequence=0,pendingDoor=null;
 const key=k=>'ori-ginso-'+k;
 registerPresentationCues({'ori-ginso:boss':{source:key('boss-music-0'),category:'music',scope:'scene',gain:'stored',blocksStage:false},
  'ori-ginso:victory':{source:key('victory-0'),category:'music',scope:'scene',gain:'stored',blocksStage:false}});
 function ready(){if(!audio||loadedContext===audio)return; if(jobs)return jobs;
  const ac=audio;jobs=Promise.all(Object.entries(oriGinsoSource.audio).map(async([name,row])=>{
   const buffer=await ac.decodeAudioData(decode64(row.data));bank.set(key(name),{buffer,gain:row.gain,owner:'ori',role:'effect'});
  })).then(()=>{loadedContext=ac;}).catch(error=>{console.warn('Ori Ginso original audio decode failed',error);}).finally(()=>jobs=null);return jobs;}
 function tick(){ready();if(!owner)return;if(!soundOn){cancelPresentationAudio(owner);muted=true;pendingDoor=null;return;}
  if(!issued&&!muted&&loadedContext===audio&&audio?.state==='running'&&mode!=='paused'&&!document.hidden){issued=playScenePresentationAudio('ori-ginso:'+mood,{fallbackOwner:owner})!==null;}
  if(pendingDoor&&loadedContext===audio&&audio?.state==='running'&&mode!=='paused'&&!document.hidden){const event=pendingDoor;pendingDoor=null;cue(event);}}
 function begin(options={}){owner=scenePresentationOwner('native:ori-ginso');mood=options.victory?'victory':'boss';issued=muted=false;pendingDoor=options.victory?null:'door-close';ready();tick();}
 function cue(name){ready();if((name==='door-close'||name==='door-open')&&loadedContext!==audio)pendingDoor=name;
  if(!owner||!soundOn||mode==='paused'||document.hidden||loadedContext!==audio)return;
  const variant=['charge','shoot','emerge','hide','hurt'].includes(name)?sequence++%3:0,k=key(name+'-'+variant);if(!bank.has(k))return;
  startEffectVoice(k,{owner,volume:oriGinsoSource.audio[name+'-'+variant].gain});}
 function victory(){if(!owner)return;cancelPresentationAudio(owner);mood='victory';issued=false;muted=!soundOn;tick();}
 return {begin,cue,victory,tick,pause(){if(owner){pausePresentationAudio(owner);withAudioOwner(owner,()=>stopEffects());}},resume(){if(owner)resumePresentationAudio(owner);tick();},
  cancel(){if(owner){cancelPresentationAudio(owner);withAudioOwner(owner,()=>stopEffects());}owner=null;pendingDoor=null;}};
}
function createOriGinsoChallengeDriver(){return E04Modules.createOriGinsoMiniboss({character:E04Modules.CHARACTER_PROFILES.find(p=>p.id==='ori'),rule:E04Modules.CHALLENGE_RULES.ori,
 createActor:id=>mainlineActorRegistry.create(id),render:{scene:oriGinsoDrawScene,enemy:oriGinsoDrawEnemy},audio:createOriGinsoAudioPort(),
 sound:(actor,event)=>{if(!actor.sound(event)&&event==='life')originalOneShot('oneup');},viewport:()=>W,debug:new URLSearchParams(location.search).get('test')==='1'});}
