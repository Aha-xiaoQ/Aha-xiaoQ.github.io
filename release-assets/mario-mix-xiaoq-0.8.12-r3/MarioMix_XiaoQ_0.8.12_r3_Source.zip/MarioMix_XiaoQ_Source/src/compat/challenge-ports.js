function legacyChallengeInput(input, previous) {
    const x = input.x === undefined ? Number(!!input.right) - Number(!!input.left) : Math.sign(Number(input.x) || 0);
    const y = input.y === undefined ? Number(!!input.down) - Number(!!input.up) : Math.sign(Number(input.y) || 0);
    const value = {...input, x, y, left: x < 0, right: x > 0, up: y < 0, down: y > 0,
      jump: !!input.jump, run: !!(input.attack || input.run), special: !!(input.special || input.ability),
      cycle: !!input.cycle, action: !!(input.attack || input.run), auxiliary: !!(input.special || input.ability), tool: !!input.tool};
    for (const key of ['jump', 'run', 'special', 'cycle', 'up', 'down']) value[key + 'Pressed'] = E04Modules.inputEdge(input,key+'Pressed',key==='run'?['attackPressed']:key==='special'?['abilityPressed']:key==='jump'?['jumpEdge']:[],()=>value[key]&&!previous[key]);
    value.jumpEdge = value.jumpPressed; value.auxEdge = value.specialPressed;
    value.toolEdge = E04Modules.inputEdge(input,'toolEdge',['toolPressed'],()=>value.tool&&!previous.tool);
    return value;
  }
/* Optional RF02 challenges, driven by the host's ONE existing fixed clock.
 * Include in the original outer closure before mainline-host.js takes over.
 * No new maps, sprites, RAF, listeners, selected-character changes or campaign
 * writes. The host returns to the declared mainline exit, never a coin room.
 */
function createNativeChallengePorts({runtime, drivers, presentation=presentationScenePort()}) {
  for(const key of ['enter','leave','scope','pause','resume'])if(typeof presentation?.[key]!=='function')throw new TypeError('Missing native presentation lifecycle: '+key);
  const requireSynchronous=(value,message)=>{
    if(value&&typeof value.then==='function'){
      // Reject the transition synchronously, while consuming a later rejection
      // from the refused hook so it cannot escape as an unhandled promise.
      Promise.resolve(value).catch(()=>{});
      throw new TypeError(message);
    }
    return value;
  };
  const inScene=(record,fn)=>{
    const value=presentation.scope(record.presentationOwner,fn);
    if(record.independent)requireSynchronous(value,'Independent challenge hooks must be synchronous: '+record.hero);
    return value;
  };
  const callSceneHook=(record,name,...args)=>{
    const driverHook=record.driver[name],owner=driverHook?record.driver:record.runtime;
    return (driverHook||owner[name])?.apply(owner,args);
  };
  const lifecycle=(record,name,fn)=>{
    const value=fn();
    if(record.independent)requireSynchronous(value,'Independent challenge lifecycle must be synchronous: '+record.hero+'.'+name);
    if(record.independent&&value===false)throw new TypeError('Independent challenge lifecycle was refused: '+record.hero+'.'+name);
    return value;
  };
  const copy = value => JSON.parse(JSON.stringify(value));
  const carryKeys = ['score', 'coins', 'lives'];
  const required = ['capture', 'activate', 'restore', 'readCarry', 'step', 'draw', 'clear'];
  for (const key of required) if (typeof runtime?.[key] !== 'function') throw new TypeError('Missing challenge runtime port: ' + key);
  const available = Object.keys(drivers || {});
  for(const id of available){
    if(!E04Modules.CHALLENGE_REWARDS[id])throw new RangeError('Missing challenge reward contract: '+id);
    if(!E04Modules.CHALLENGE_RULES[id])throw new RangeError('Missing challenge rule contract: '+id);
  }
  for (const id of available) for (const key of ['enter', 'view', 'snapshotScene', 'restoreScene', 'inputAdapter', 'beginDeparture']) {
    if (typeof drivers[id]?.[key] !== 'function') throw new TypeError('Missing challenge driver: ' + id + '.' + key);
  }
  for(const id of available)for(const key of ['migrateCheckpoint','retryCheckpoint','drainEvents'])if(drivers[id][key]!==undefined&&typeof drivers[id][key]!=='function')throw new TypeError('Invalid challenge hook: '+id+'.'+key);
  const runtimes=new Map();
  for(const id of available){
    const owned=drivers[id].runtime;
    if(owned!==undefined)for(const key of [...required,'restoreEquipment','health','pause','resume','audio']){
      if(typeof owned?.[key]!=='function')throw new TypeError('Missing independent challenge runtime port: '+id+'.'+key);
    }
    if(typeof (drivers[id].grantCompletionBonus||(owned||runtime).grantCompletionBonus)!=='function')throw new TypeError('Missing room reward grant port: '+id);
    runtimes.set(id,owned||runtime);
  }
  let active = null, last = null, generation = 0, cleanupFailure = null;
  function counters(value) {
    const out = {};
    for (const key of carryKeys) {
      const n = value?.[key];
      if (!Number.isSafeInteger(n) || n < 0) throw new TypeError('Invalid native challenge counter: ' + key);
      out[key] = n;
    }
    return out;
  }
  function observe() {
    if (!active) return null;
    const state = active.driver.view() || {};
    if (state.hero !== undefined && state.hero !== active.hero) throw new Error('Native challenge changed the selected character');
    if (state.mode && state.mode !== 'paused') active.lastMode = state.mode;
    active.cleared ||= !!state.cleared;
    active.exited ||= !!state.exited;
    active.failed ||= !!state.failed;
    const carry = counters(state.carry || active.driver.carry?.() || active.runtime.readCarry());
    const details={...active.runtime.health?.(),...state};
    if(active.independent){
      const rule=E04Modules.CHALLENGE_RULES[active.hero],validSize=n=>Number.isFinite(n)&&n>=16&&n<=4096;
      if(state.hero!==active.hero||!details.nativeCarry||!validSize(details.logicalWidth)||!validSize(details.logicalHeight)||details.healthMode!==rule.health||
        rule.health==='native'&&(!Number.isFinite(details.maxHp)||details.maxHp<1||details.maxHp>10000||!Number.isFinite(details.hp)||details.hp<0||details.hp>details.maxHp)||
        rule.health==='protection'&&![0,1].includes(details.protection)||
        rule.health==='rings'&&(!Number.isSafeInteger(details.rings)||details.rings<0))throw new TypeError('Invalid independent scene view: '+active.hero);
    }
    if(details.nativeCarry)details.nativeCarry=E04Modules.copyActorEquipment(active.hero,details.nativeCarry);
    const carryDelta = Object.fromEntries(carryKeys.map(key => [key, carry[key] - active.baseline[key]]));
    return {...copy(details), active: true, generation: active.generation, hero: active.hero,
      cleared: active.cleared, exited: active.exited, failed: active.failed,
      exitReady: !!state.exitReady, departing:!!active.departureStarted, canSkip: !active.departureStarted,
      phase: active.failed ? 'failed' : active.exited ? 'exited' : active.paused || state.mode === 'paused' ? 'paused' : active.cleared ? 'cleared' : 'playing',
      carry, carryDelta, rewardReceipt:E04Modules.copyRewardReceipt(active.hero,active.rewardReceipt)};
  }
  function view() {
    const current = observe();
    return current || {active: false, phase: 'idle', hero: null, generation, supported: [...available], result: last ? copy(last) : null};
  }
  function requestDeparture(record,state){
    if(record.departureStarted||!record.rewardReceipt.claimed||!state.cleared||!state.rewardClaimed||state.failed||state.defeating)return;
    const started=requireSynchronous(inScene(record,()=>record.driver.beginDeparture()),'Native departure must be synchronous');
    if(typeof started!=='boolean')throw new TypeError('Native departure must return a boolean');
    record.departureStarted=started;if(started)record.previous={};
  }
  function cleanup(record, reason) {
    const errors = [];
    for (const task of [() => presentation.leave(record.presentationOwner),
      () => lifecycle(record,'leave',()=>record.driver.leave?.(reason)),
      () => lifecycle(record,'clear',()=>record.runtime.clear()),
      () => lifecycle(record,'restore',()=>record.runtime.restore(record.saved))]) {
      try { task(); } catch (error) { errors.push(error); }
    }
    return errors;
  }
  function rememberCleanupFailure(record,reason,errors,message){
    cleanupFailure=new AggregateError(errors,message);
    active=null;
    last={active:false,hero:record.hero,generation:record.generation,reason,phase:'failed',
      completed:false,cleared:false,failed:true,carry:{...record.baseline},
      carryDelta:{score:0,coins:0,lives:0},error:cleanupFailure.message};
    return cleanupFailure;
  }
  function enter(heroId, options = {}) {
    if(cleanupFailure)throw cleanupFailure;
    if (active) throw new Error('Leave the active native challenge before entering another');
    if (!Object.hasOwn(drivers, heroId)) throw new RangeError('No native challenge for: ' + heroId);
    const driver = drivers[heroId], selectedRuntime=runtimes.get(heroId), carry = counters(options.carry || selectedRuntime.readCarry());
    if(options.carry?.hero&&options.carry.hero!==heroId)throw new TypeError('Challenge carry hero mismatch');
    const equipment=options.carry?.native?E04Modules.copyActorEquipment(heroId,options.carry.native):null;
    let scene=options.scene?E04Modules.copySceneCheckpoint(heroId,options.scene):null;
    if(scene&&driver.migrateCheckpoint){
      const migrated=requireSynchronous(driver.migrateCheckpoint(copy(scene)),'Scene checkpoint migration must be synchronous');
      if(migrated===null){scene=null;options={...options,retry:true};}
      else if(migrated&&typeof migrated==='object'&&Object.hasOwn(migrated,'action')){
        // A retired actor representation may need a fresh body in the same
        // encounter phase. Only the scene is replaceable; equipment, counters
        // and the reward receipt remain owned by the unchanged entry transaction.
        const fields=Object.getOwnPropertyDescriptors(migrated);
        if(Reflect.ownKeys(migrated).length!==2||!fields.checkpoint||
          !Object.hasOwn(fields.action,'value')||!Object.hasOwn(fields.checkpoint,'value')||
          !fields.action.enumerable||!fields.checkpoint.enumerable||fields.action.value!=='restart')
          throw new TypeError('Invalid scene checkpoint migration');
        scene=E04Modules.copySceneCheckpoint(heroId,fields.checkpoint.value);
        options={...options,retry:true};
      }
      else scene=E04Modules.copySceneCheckpoint(heroId,migrated);
    }
    const rewardReceipt=E04Modules.copyRewardReceipt(heroId,options.rewardReceipt);
    options={...options,scene,rewardReceipt,carry:{...options.carry,...carry,...(equipment?{native:equipment}:{})}};
    const record = {hero: heroId, driver, runtime:selectedRuntime,independent:driver.runtime!==undefined,saved:selectedRuntime.capture(), baseline: carry,
      rewardReceipt, departureStarted:false, generation: ++generation, previous: {}, cleared: false, exited: false, failed: false, paused: false, lastMode: null};
    if(record.independent)requireSynchronous(record.saved,'Independent challenge capture must be synchronous: '+heroId);
    record.presentationOwner='native:'+heroId+':'+record.generation;
    active = record; last = null;
    try {
      lifecycle(record,'clear',()=>selectedRuntime.clear());
      presentation.enter(record.presentationOwner);
      inScene(record,()=>selectedRuntime.activate({hero: heroId, chapter: driver.chapter, carry, options, rules:E04Modules.CHALLENGE_RULES[heroId]}));
      if (inScene(record,()=>driver.enter(copy({...options, carry: {...options.carry, ...carry}}))) === false) throw new Error('Native challenge entry was refused: ' + heroId);
      const equipmentResult=inScene(record,()=>selectedRuntime.restoreEquipment?.(copy(options.carry||{}),{retry:!!options.retry}));
      if(equipmentResult===false||equipmentResult&&typeof equipmentResult.then==='function')throw new TypeError('Native challenge equipment restore was refused or asynchronous: '+heroId);
      if(scene&&!options.retry){
        const restored=inScene(record,()=>driver.restoreScene(scene.data));
        if(restored===false||restored&&typeof restored.then==='function')throw new TypeError('Native challenge scene restore was refused or asynchronous: '+heroId);
      }
      // Preparatory supplies belong to the original room. Only later counter
      // changes are handed back, so entering/skipping cannot mint a reward.
      const state = driver.view() || {};
      record.baseline = counters(state.carry || driver.carry?.() || selectedRuntime.readCarry());
      if(scene&&!options.retry)requestDeparture(record,observe());
      return view();
    } catch (error) {
      const errors = cleanup(record, 'entry-error'); active = null;
      if (errors.length) throw rememberCleanupFailure(record,'entry-error',[error,...errors],'Challenge entry failed; cleanup also reported an error');
      throw error;
    }
  }

  function step(input = {}) {
    if (!active) return view();
    if (!active.departureStarted&&(input.skip || input.skipPressed)) { leave('skip'); return view(); }
    const before = observe();
    // Hand the native exit/death back before another legacy tick can retry or
    // advance its unrelated chapter. The host commits the result once.
    if (before.failed || before.exited || before.phase === 'paused') return before;
    const record = active, value = record.driver.inputAdapter(record.departureStarted?{}:input, record.departureStarted?{}:record.previous);
    if(!value||typeof value!=='object'||typeof value.then==='function')throw new TypeError('Challenge input adapter must return a synchronous frame');
    const seen={...value};
    inScene(record,()=>callSceneHook(record,'step',value)); record.previous = seen;
    if(active){
      const after=observe();
      if(after.rewardClaimed&&after.cleared&&!after.failed&&!record.rewardReceipt.claimed){
        // Claim only from a real simulation step. Observe, draw, save and exit
        // never mint rewards. A throwing grant poisons this transition instead
        // of retrying a possibly partially committed native operation.
        try{
          const award=E04Modules.roomRewardAward(E04Modules.CHALLENGE_REWARDS[record.hero]);
          const expected=E04Modules.addRoomReward(after.carry,award);
          const granted=inScene(record,()=>callSceneHook(record,'grantCompletionBonus',Object.freeze(award)));
          requireSynchronous(granted,'Room reward grant must be synchronous');
          if(granted===false)throw new TypeError('Room reward grant refused');
          const actual=observe().carry;
          if(carryKeys.some(key=>actual[key]!==expected[key]))throw new TypeError('Room reward grant did not update native counters');
          record.rewardReceipt={...record.rewardReceipt,claimed:true};
        }catch(error){
          const errors=cleanup(record,'reward-error');
          throw rememberCleanupFailure(record,'reward-error',[error,...errors],'Room reward commit failed');
        }
      }
      const departure=observe();
      if(!record.departureStarted&&record.rewardReceipt.claimed&&departure.cleared&&departure.rewardClaimed&&!departure.failed&&!departure.defeating){
        // One owner commits collection, then requests the source-specific
        // cinematic. A restored scene accepts idempotently without rewinding.
        // false means waiting for a source explosion/landing, never skipped.
        try{
          requestDeparture(record,departure);
        }catch(error){
          const errors=cleanup(record,'departure-error');
          throw rememberCleanupFailure(record,'departure-error',[error,...errors],'Native departure failed');
        }
      }
      inScene(record,()=>callSceneHook(record,'audio'));
    }
    return view();
  }
  function draw() {
    if (!active) return false;
    inScene(active,()=>callSceneHook(active,'draw'));
    return view();
  }
  function pause() {
    if (!active || active.paused) return view();
    presentation.pause(active.presentationOwner);
    active.paused = true; active.previous = {};
    inScene(active,()=>callSceneHook(active,'pause',active.lastMode));
    if(active)inScene(active,()=>callSceneHook(active,'audio'));
    return view();
  }
  function resume() {
    if (!active || !active.paused) return view();
    inScene(active,()=>callSceneHook(active,'resume',active.lastMode));
    active.paused = false; active.previous = {};
    presentation.resume(active.presentationOwner);
    if(active)inScene(active,()=>callSceneHook(active,'audio'));
    return view();
  }
  function leave(reason = 'skip') {
    if (!['skip', 'complete', 'failed', 'cancel'].includes(reason)) throw new RangeError('Unknown challenge exit reason: ' + reason);
    if(cleanupFailure)throw cleanupFailure;
    if (!active) return last ? copy(last) : null;
    let state, observationError;
    try {
      state = observe();
      if(reason==='failed'&&active.driver.retryCheckpoint){
        const data=requireSynchronous(inScene(active,()=>active.driver.retryCheckpoint()),'Retry checkpoint must be synchronous');
        state.retryScene=data===null?null:E04Modules.copySceneCheckpoint(active.hero,{version:1,hero:active.hero,data});
      }
    } catch (error) {
      observationError = error;
      state = {hero: active.hero, generation: active.generation, cleared: false, failed: true,
        exited: false, phase: 'failed', carryDelta: {score: 0, coins: 0, lives: 0}, error: String(error.message || error)};
    }
    if (!observationError && reason === 'complete' && (!state.cleared || state.failed)) throw new Error('Cannot complete a native challenge without its own surviving victory condition');
    if (!observationError && reason === 'complete' && (!state.rewardClaimed || !recordedReward(state))) throw new Error('Cannot complete a native challenge before reward collection');
    const record = active;
    const result = {...state, active: false, reason, completed: reason === 'complete' && state.cleared};
    const errors = cleanup(record, reason);
    if (observationError) errors.unshift(observationError);
    if (errors.length) throw rememberCleanupFailure(record,reason,errors,'Challenge cleanup failed');
    // Restoration has finished. No later award/copy failure may leave the old
    // record active or allow a second attempt to replay cleanup or mint rewards.
    active=null;
    try{
      last=copy(result);
      return copy(last);
    }catch(error){
      throw rememberCleanupFailure(record,reason,[error],'Challenge completion commit failed');
    }
  }
  function checkpoint(){
    if(!active)return null;
    return E04Modules.copySceneCheckpoint(active.hero,{version:1,hero:active.hero,data:active.driver.snapshotScene()});
  }
  function recordedReward(state){return state.rewardReceipt?.claimed===true;}
  function drainEvents(){
    if(!active?.driver.drainEvents)return [];
    const record=active,events=requireSynchronous(inScene(record,()=>record.driver.drainEvents()),'Native scene events must be synchronous');
    const label=v=>typeof v==='string'&&v.trim().length>0&&v.length<=180;
    const valid=e=>e&&label(e.sceneId)&&Number.isSafeInteger(e.tick)&&e.tick>=0&&(
      e.type==='enemy-defeated'&&['id','entityId','contract','cause'].every(k=>label(e[k]))&&typeof e.boss==='boolean'||
      e.type==='objective'&&/^[a-z][a-z0-9-]{0,63}$/.test(e.id)&&Number.isSafeInteger(e.value)&&e.value>0);
    if(!Array.isArray(events)||events.length>128||events.some(e=>!valid(e)))throw new TypeError('Invalid native scene events');
    return events.map(e=>({...copy(e),hero:record.hero,generation:record.generation}));
  }
  return Object.freeze({enter, step, draw, pause, resume, leave, view, checkpoint,drainEvents,diagnostics:()=>active?.driver.diagnostics?.(),audio:()=>{if(active)inScene(active,()=>callSceneHook(active,'audio'));}, supported:()=>Object.freeze([...available]),supports: id => Object.hasOwn(drivers, id)});
}

/* Bind this adapter from inside the Terra IIFE. Its room state is deliberately
 * inaccessible to the outer legacy fixed loop. The injected `step` invokes
 * the existing lexical step(v), so forwarded input follows the native motor.
 * `open` must be lexical openGame(), never the global startGame wrapper.
 */
function createRf02TerraChallengePort(native) {
  for (const key of ['capture', 'restore', 'state', 'hero', 'mode', 'open', 'enter', 'prepare', 'step', 'draw', 'clear', 'snapshotScene', 'restoreScene', 'beginDeparture', 'grantCompletionBonus']) {
    if (typeof native?.[key] !== 'function') throw new TypeError('Missing Terra challenge port: ' + key);
  }
  let saved = null, arena = null;
  return {
    chapter: 13,
    grantCompletionBonus:award=>native.grantCompletionBonus(award),
    enter: ({carry, levelId, retry, rewardReceipt}) => {
      if (saved) throw new Error('Terra challenge is already active');
      saved = native.capture();
      native.open();
      const base = native.state();
      if (!base) throw new Error('Native Terra opening did not create its scene');
      Object.assign(base, {score: carry.score, coins: carry.coins, lives: carry.lives});
      if (levelId) base.mainlineLevel = levelId;
      if (native.enter() === false) return false;
      arena = native.state();
      if (!arena?.r05Arena) throw new Error('Native Terra entry did not create the original arena');
      if (levelId) arena.mainlineLevel = levelId;
      arena.campaignChallengeReturn=true;
      native.prepare();
      native.carryIn?.(arena, carry.native);
      native.healthIn?.(arena,{protection:carry.protection||0,retry:!!retry,rewardClaimed:!!rewardReceipt?.claimed});
      return true;
    },
    step: input => native.step(input),
    draw: () => native.draw(),
    beginDeparture:()=>native.beginDeparture(arena),
    snapshotScene:()=>native.snapshotScene(),
    restoreScene:data=>native.restoreScene(data),
    view: () => {
      const current = native.state(), s = arena || current, viewport = native.viewport?.() || {width: 256, height: 240};
      // RF02's final r05Viewport override uses R06_VIEW at 1.5x. The earlier
      // 960x540 arena implementation is superseded by the native 1280x720 view.
      const arenaViewport = native.arenaViewport?.() || {width: 1280, height: 720};
      const cleared = s?.phase === 'cleared' && !!s.bossClear;
      return {hero: native.hero(), id: 'terra-eye', title: '泰拉瑞亚 · 克苏鲁之眼', mode: native.mode(),protection:s?.challengeProtection||0,
        area: current?.r05Arena ? 'arena' : 'surface', nativePhase: s?.phase || null,
        cleared, rewardClaimed:cleared&&!!s?.campaignRewardCollected, failed: s?.phase === 'defeated' || ['dying', 'respawn', 'gameover'].includes(native.mode()),
        exited:!!s?.campaignReturnComplete||!!arena&&!!current&&!current.r05Arena&&!current.t11Transition,
        exitCommitted:!!s?.campaignReturnComplete||!!arena&&!!current&&!current.r05Arena,
        exitReady: cleared && !current?.t11Transition,
        logicalWidth: current?.r05Arena ? arenaViewport.width : viewport.width,
        logicalHeight: current?.r05Arena ? arenaViewport.height : viewport.height,
        renderWidth: current?.r05Arena ? arenaViewport.renderWidth??1920 : viewport.renderWidth??viewport.width,
        renderHeight: current?.r05Arena ? arenaViewport.renderHeight??1080 : viewport.renderHeight??viewport.height,
        carry: s ? {score: s.score, coins: s.coins, lives: s.lives,protection:s.challengeProtection||0} : null,
        healthMode:'native', hp:s?.hp,maxHp:s?.maxHp,
        nativeCarry:s?native.carryOut?.(s):null,
        nativeReward: cleared ? (native.reward?.(s) || {kind: 'terra-equipment', kit: s.kit || null, cloudJump: !!s.cloudJump,
          slimeOwned: !!s.slimeOwned, ufoOwned: !!s.ufoOwned}) : null};
    },
    leave: () => {
      const prior = saved; saved = null; arena = null;
      try { native.clear(); } finally { if (prior) native.restore(prior); }
    },
  };
}

/* Real RF02 bindings. `fixed`, `draw` and `audio` MUST be captured before the
 * mainline wrappers are installed. The ordinary host uses mixNative.fixed and
 * e04NativeDraw, which bypass the retired legacy session's idle guard.
 * Entry calls room constructors directly. No startGame/c23Choose/selectHero
 * references are captured or invoked, so mainline menu functions stay intact.
 */
function createRf02ChallengePorts({fixed, draw: nativeDraw, audio: nativeAudio, terra = null, independent = {}}) {
  for (const [name, fn] of Object.entries({fixed, draw: nativeDraw, audio: nativeAudio})) {
    if (typeof fn !== 'function') throw new TypeError('Capture the native ' + name + ' callback before mainline activation');
  }
  let billRoom = null, relayRoom = null,challengeProtection=0,sceneRules=null;
  function challengeHit(source){
    if(mode!=='playing'||!player||player.invuln||player.star)return false;
    // Battle City's timed helmet is a native room effect, not another mainline
    // health bar or permanent protection tier.
    if(hero==='tank'&&r12?.tank?.shield>0)return false;
    if(challengeProtection){
      challengeProtection=0;player.protection=0;player.invuln=120;
      if(hero==='bill')billWeapon='N';
      else if(hero==='tank'){r12.tank.power=0;r12.tank.shield=0;r06Sound('hit');}
      else if(hero==='ryu'){ninja.weapon='shuriken';ninjaSound('hurt');}
      return true;
    }
    die();return true;
  }
  const runtime = {
    capture: () => ({hero, room, mode, frame, score, coins, lives, timeLeft, timerTicks, checkpoint, maxProgress,
      player, camera, tiles, surface, underground, enemies, items, shots, particles, floaters, looseCoins, pipes,
      freeze, deathTick, pipeTransition, flagPhase, flagTimer, flagY, ninja, r12, r12World, r12Checkpoint, r12Journal,
      billBase, billWeapon, billDropBag, billMotion, billAirTicks, billFireFrames,
      billAimX, billAimY, billAimDown, billDropRow, billDropCollision, billDownJumpHeld,
      mixTier, mixHp, mixShots, mixCharge, mixHeld, mixSpread, mixCool, mixAim, upgradeFrames, mixCrouch, mixDeathOrigin,
      jumpHeldPrev, runHeldPrev, jumpBuffer, enemyShots, r03Challenge, r03Rewards, r03Terrain,
      r06Effects, r06Death, r06UID, r07BonusIndex, r07DefeatFx, r07MixReport,
      r07Transit, r12RelayActive, r12RelayRequested, c23Menu, chapter: c23Campaign.stage}),
    activate: ({hero: id, chapter, carry, options, rules}) => {
      sceneRules=rules;
      hero = id; c23Campaign.stage = chapter; c23Menu = false; mode = 'playing';
      challengeProtection=options.carry?.protection?1:0;
      score = carry.score; coins = carry.coins; lives = carry.lives;
      frame = 0; timeLeft = 400; timerTicks = 0; checkpoint = 0; maxProgress = 0;
      freeze = 0; deathTick = 0; pipeTransition = null; flagPhase = 0; flagTimer = 0; flagY = 48;
      r12 = null; ninja = null; billBase = null; r12World = {}; r12Checkpoint = null; r12Journal = [];
      r03Challenge = null; r03Rewards = {ninja:id==='ryu'&&options.rewardReceipt.claimed,tank:id==='tank'&&options.rewardReceipt.claimed}; r03Terrain = []; r07Transit = null;
      r12RelayActive = false; r12RelayRequested = false;
      r06Effects = []; r06Death = null; r07BonusIndex = 0; r07DefeatFx = []; r07MixReport = {};
      enemies = []; items = []; shots = []; particles = []; floaters = []; mixShots = []; enemyShots = [];
      mixReset();
      if (id === 'bill' && ['N', 'M', 'S', 'F', 'L'].includes(options.carry?.weapon)) billWeapon = options.carry.weapon;
      hideOverlay();
    },
    restore: saved => {
      ({hero, room, mode, frame, score, coins, lives, timeLeft, timerTicks, checkpoint, maxProgress,
        player, camera, tiles, surface, underground, enemies, items, shots, particles, floaters, looseCoins, pipes,
        freeze, deathTick, pipeTransition, flagPhase, flagTimer, flagY, ninja, r12, r12World, r12Checkpoint, r12Journal,
        billBase, billWeapon, billDropBag, billMotion, billAirTicks, billFireFrames,
        billAimX, billAimY, billAimDown, billDropRow, billDropCollision, billDownJumpHeld,
        mixTier, mixHp, mixShots, mixCharge, mixHeld, mixSpread, mixCool, mixAim, upgradeFrames, mixCrouch, mixDeathOrigin,
        jumpHeldPrev, runHeldPrev, jumpBuffer, enemyShots, r03Challenge, r03Rewards, r03Terrain,
        r06Effects, r06Death, r06UID, r07BonusIndex, r07DefeatFx, r07MixReport,
        r07Transit, r12RelayActive, r12RelayRequested, c23Menu} = saved);
      c23Campaign.stage = saved.chapter;
      hideOverlay();
    },
    // The preserved legacy death code spends its local life before yielding.
    // Report the pre-debit counter: the campaign owns the sole death debit.
    // This retains lives earned in the room even when death occurs afterward.
    readCarry: () => ({score, coins, lives:lives+(terminal()?1:0)}),
    grantCompletionBonus:award=>{({score,coins,lives}=E04Modules.addRoomReward({score,coins,lives},award));if(player)floaters.push({text:'1UP',x:player.x,y:player.y-8,life:70});originalOneShot('oneup');return true;},
    health:()=>({protection:challengeProtection,healthMode:sceneRules?.health||'protection',...(hero==='ryu'?{hp:ninja?.hp,maxHp:sceneRules.initialHealth}:{}),nativeCarry:hero==='sandboxTrio'?null:{version:1,actor:hero,weapon:hero==='bill'?billWeapon:hero==='ryu'?ninja?.weapon:null,...(hero==='ryu'?{hp:ninja?.hp,nativeVitals:{hp:ninja?.hp,maxHp:sceneRules.initialHealth},spirit:ninja?.spirit,unlocked:[...(ninja?.unlocked||[])],attackMode:ninja?.attackMode||'blade'}:{}),...(hero==='tank'?{power:r12?.tank?.power||0}:{})}}),
    restoreEquipment:(carry,options)=>{const data=carry.native;if(hero==='bill'&&Object.hasOwn(BILL_WEAPON_NAMES,carry.weapon))billWeapon=carry.weapon;if(!data)return;if(hero==='ryu'){rf09RestoreRyuEquipment(ninja,data);const vitals=E04Modules.nativeSceneHealth(sceneRules,data.nativeVitals,options);ninja.hp=vitals.hp;ninja.nativeVitals=vitals;}if(hero==='tank')r12.tank.power=clamp(data.power||0,0,3);},
    step: input => {
      const before = virtualInput,priorDamage=damage,priorNinjaHurt=ninjaHurt,priorTankHurt=r12TankHurt,priorSwing=ninjaSwing,priorThrow=ninjaThrow;
      const weaponBefore=billWeapon,powerBefore=r12?.tank?.power;
      if(player){player.mainlineHealth=sceneRules.health==='protection';player.protection=challengeProtection;}
      virtualInput = input;
      if(sceneRules.health==='protection'){damage=challengeHit;ninjaHurt=challengeHit;r12TankHurt=challengeHit;}
      if(hero==='ryu'){rf09CycleRyuEquipment(ninja,input);ninjaSwing=rf08RyuSwing;ninjaThrow=rf08RyuThrow;if(ninja.attackMode&&ninja.attackMode!=='blade'&&input.run&&ninja.cool<=1)input.runPressed=true;}
      try { fixed(); }
      finally { virtualInput=before;damage=priorDamage;ninjaHurt=priorNinjaHurt;r12TankHurt=priorTankHurt;ninjaSwing=priorSwing;ninjaThrow=priorThrow; }
      if(hero==='bill'&&billWeapon!=='N'&&billWeapon!==weaponBefore||hero==='tank'&&r12?.tank?.power>powerBefore)challengeProtection=1;
    },
    draw:()=>{if(player)player.mainlineHealth=sceneRules.health==='protection';nativeDraw();const notice=$('upgradeNotice');if(notice)notice.hidden=true;}, audio: nativeAudio,
    pause: () => { mode = 'paused'; r04Clear(); keys.clear(); touch.clear(); stopEffects(); r06StopEngine(); },
    resume: priorMode => { mode = priorMode || 'playing'; r04Clear(); keys.clear(); touch.clear(); },
    clear: () => {
      resetGameAudio(); r06StopEngine(); tankRoute?.leave(); r04Clear(); keys.clear(); touch.clear(); virtualInput = null;
      const notice = $('upgradeNotice'); if (notice) notice.hidden = true;
    },
  };
  const terminal = () => ['dying', 'respawn', 'gameover'].includes(mode);
  const relayView = (kind, area, title) => {
    const challenge = r03Challenge?.kind === kind ? r03Challenge : relayRoom;
    const won = !!challenge?.won, exited = won && !!challenge?.departure?.complete || !!r12 && r12.area !== area;
    return {hero, id: kind === 'tank' ? 'tank-defense' : 'ryu-bar', title, mode,
      logicalWidth: W, logicalHeight: H,
      area: r12?.area || null, cleared: won, rewardClaimed:won, failed: terminal() || !!challenge?.failed,
      exited, exitReady: won && (kind !== 'tank' || !!challenge?.exitPipe && !challenge?.tally08?.active),
      tally: !!challenge?.tally08?.active,
      nativeReward: won ? kind === 'tank' ? {kind: 'max-power-shield', power: 3} : {kind: 'jump-and-slash', weapon: 'spin'} : null};
  };
  let ryuRoofSerial=0;
  const drivers = {
    bill: createRf101ContraBaseChallenge({runtime,terminal}),
    ryu: {
      chapter: 12,
      beginDeparture:()=>rf085BeginRyuDeparture(),
      snapshotScene:()=>rf09CaptureRelayScene('ryu'),
      restoreScene:data=>{rf09RestoreRelayScene('ryu',data);ryuRoofSerial=player.ryuCeilingRail?.serial||0;},
      enter: () => { r03StartChallenge('ninja'); ryuRoofSerial=0;ninja.hp=sceneRules.initialHealth;relayRoom = r03Challenge; },
      drainEvents:()=>{const serial=player?.ryuCeilingRail?.serial||0;if(serial<=ryuRoofSerial)return [];ryuRoofSerial=serial;return [{type:'objective',id:'roof-rail',value:serial,sceneId:'ryu-bar',tick:frame}];},
      view: () => relayView('ninja', 'bar', '隼龙 · 酒吧决斗'),
      leave: () => { relayRoom = null; },
    },
    tank: {
      chapter: 12,
      beginDeparture:()=>tankRoute.beginDeparture(),
      snapshotScene:()=>rf09CaptureRelayScene('tank'),
      restoreScene:data=>rf09RestoreRelayScene('tank',data),
      enter: () => { r03StartChallenge('tank'); relayRoom = r03Challenge; },
      view: () => relayView('tank', 'defense', '坦克 · 基地保卫'),
      leave: () => { relayRoom = null; },
    },
  };
  Object.assign(drivers,createRf092PlatformChallengeDrivers());
  if (terra) drivers.sandboxTrio = {chapter: 13, ...terra};
  for(const [id,driver]of Object.entries(drivers)){driver.rules=E04Modules.CHALLENGE_RULES[id];driver.inputAdapter=legacyChallengeInput;}
  for(const [id,driver]of Object.entries(independent)){
    if(Object.hasOwn(drivers,id))throw new TypeError('Independent challenge cannot replace shipped driver: '+id);
    if(!driver?.runtime)throw new TypeError('Independent challenge runtime required: '+id);
    drivers[id]=driver;
  }
  return createNativeChallengePorts({runtime, drivers});
}
