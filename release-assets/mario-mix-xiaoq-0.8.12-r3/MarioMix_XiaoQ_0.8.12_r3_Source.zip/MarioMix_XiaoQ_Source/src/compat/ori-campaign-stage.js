/* RF07: the supplied final R43 Ori chapter is a campaign stage, not an actor
 * pasted over the generic castle. Capture after every native chapter wrapper
 * and before mainline-host replaces entrypoints. No second RAF or input loop. */
const rf07OriNative=Object.freeze({reset:c23ResetScene,step:c23Step,draw:c23Draw,
 fail:c23Fail,hurt:c23Hurt,audio:audioSync,enterFlood:o28EnterFlood});

function createRf07OriCampaignStage({initialState,viewportWidth=256,emit=()=>{},debug=false}={}){
 if(initialState?.hero!=='ori'||!Number.isInteger(initialState.lives)||initialState.lives<1)throw Error('Ori chapter requires a living campaign carry');
 const clone=x=>JSON.parse(JSON.stringify(x)),noop=()=>{},flags=['destroyed','used','revealed','switchOn','gateOpen'];
 const alphabet='0123456789abcdefghijklmnopqrstuv',spec=o29Spec(),definitions=spec.entities;
 const cps=[...C23_CPS.map((p,i)=>({roomId:'ori-horizontal',spawnId:'checkpoint-'+i,rank:i,x:p.x})),
  ...O28_CHECKS.map((p,i)=>({roomId:'ori-flood',spawnId:'checkpoint-'+i,rank:4+i,x:p.x}))];
 const world={level:'1-4',nativeStage:true,plan:{stage:{id:'1-4',title:'ORI × MARIO / WORLD 1-4',
  entryRoom:'ori-horizontal',entrySpawn:'checkpoint-0',checkpoints:cps},rooms:{}},visualRooms:[]};
 let paused=false,disposed=false,completed=false,deathPending=false,protectedHit=initialState.protection===1,
  power=initialState.power||0,weapon=initialState.weapon||null,safeChapter=null,safeKey='',events=[],sequence=0;
 let upgradeTier=Number.isInteger(initialState.native?.upgradeTier)?clamp(initialState.native.upgradeTier,0,2):0;

 // The chapter owns its native world only while mounted. The host owns screen,
 // clocks and campaign progress. Audio promises see the same live world between
 // calls; a borrowed one-tick preview would give them the wrong flood/outro role.
 const priorSlots=Object.fromEntries(Object.entries(rf04Slots).map(([k,v])=>[k,v[0]() ]));
 const prior={score,coins,lives,timeLeft,timerTicks,checkpoint,maxProgress,surface,underground,
  pipeTransition,flagPhase,flagTimer,flagY,c23Campaign,c23ReadyMenu,c23BlockJump,c23PendingJump,
  c23Device,o29,o28TurnCapture,o24Mouse,virtualInput,o30:{...o30},o32:{...o32Input}};
 const previousPractice=$('c23Practice')?.checked;
 function log(type,data={}){if(debug){events.push({type,sequence:++sequence,tick:c23?.ticks||0,...data});if(events.length>256)events.shift();}}
 function checkpointId(){const phase=['horizontal','flood'].includes(o28.phase)?o28.phase:safeChapter?.phase||'horizontal';
  const cp=['horizontal','flood'].includes(o28.phase)?(phase==='horizontal'?c23.cp:o28.cp):safeChapter?.cp||0;
  return {roomId:'ori-'+phase,spawnId:'checkpoint-'+cp};}
 function encodeWorld(){
  let encoded='';for(const d of definitions){const st=o29.world.state(d.id);encoded+=alphabet[flags.reduce((n,k,i)=>n+(st[k]?1<<i:0),0)];}
  return encoded.match(/.{1,128}/g)||[];
 }
 function captureChapter(){
  if(!['horizontal','flood'].includes(o28.phase))return safeChapter;
  if(o28.phase==='horizontal')o29SyncHorizontal(true);
  return {version:1,layout:'ori-r43-two-act',phase:o28.phase,cp:o28.phase==='flood'?o28.cp:c23.cp,
   flags:encodeWorld(),ticks:c23.ticks,runFrames:c23.runFrames,retries:c23.retries,time:timeLeft,
   stats:O30_STAT_KEYS.map(k=>c23.ori[k]||0),windFrames:o29.windFrames,gateBreaks:o29.gateBreaks};
 }
 function validateChapter(data){
  const keys=['version','layout','phase','cp','flags','ticks','runFrames','retries','time','stats','windFrames','gateBreaks'];
  if(!data||typeof data!=='object'||Array.isArray(data)||Object.keys(data).length!==keys.length||Object.keys(data).some(k=>!keys.includes(k))||data.version!==1||data.layout!=='ori-r43-two-act')throw Error('Unknown Ori chapter checkpoint');
  const cap=data.phase==='horizontal'?C23_CPS.length:data.phase==='flood'?O28_CHECKS.length:0;
  if(!cap||!Number.isInteger(data.cp)||data.cp<0||data.cp>=cap)throw Error('Invalid Ori chapter phase/checkpoint');
  for(const k of ['ticks','runFrames','retries','time','windFrames','gateBreaks'])if(!Number.isSafeInteger(data[k])||data[k]<0||data[k]>1000000000)throw Error('Invalid Ori chapter counter');
  if(data.time>36000||data.gateBreaks>4||!Array.isArray(data.stats)||data.stats.length!==O30_STAT_KEYS.length||data.stats.some(n=>!Number.isSafeInteger(n)||n<0||n>1000000000))throw Error('Invalid Ori chapter ability record');
  if(!Array.isArray(data.flags)||data.flags.length!==Math.ceil(definitions.length/128)||data.flags.some((s,i)=>typeof s!=='string'||s.length!==Math.min(128,definitions.length-i*128)||!/^[0-9a-v]+$/.test(s)))throw Error('Invalid Ori world state');
  const encoded=data.flags.join(''),next=new O29Core.SharedWorld(spec);
  for(let i=0;i<definitions.length;i++){
   const d=definitions[i],n=alphabet.indexOf(encoded[i]),patch=Object.fromEntries(flags.map((k,b)=>[k,!!(n&(1<<b))]));
   if(patch.used&&!patch.revealed)throw Error('Used Ori block cannot be hidden');
   if(data.phase==='flood'&&d.kind==='bridge'&&!patch.destroyed)throw Error('Flood checkpoint requires the original broken bridge');
   next.apply({id:d.id,patch,reason:'campaign checkpoint',tick:data.ticks});
  }
  return {data:clone(data),world:next};
 }
 // Validate the compact chapter before touching native globals or UI.
 const incoming=initialState.native?.chapter?validateChapter(initialState.native.chapter):null;
 if(incoming&&initialState.checkpoint&&(initialState.checkpoint.levelId!=='1-4'||initialState.checkpoint.roomId!=='ori-'+incoming.data.phase||initialState.checkpoint.spawnId!=='checkpoint-'+incoming.data.cp))throw Error('Ori chapter and campaign checkpoint disagree');

 function syncPlayer(){
  Object.assign(player,{hero:'ori',motionId:'ori',attackId:'ori',renderId:'ori',mainlineHealth:true,
   power,protection:protectedHit?1:0,weapon,hp:protectedHit?2:1,maxHealth:2});
  if(c23?.ori){c23.ori.hp=protectedHit?2:1;c23.ori.upgradeTier=upgradeTier;}
 }
 function fail(cause='native hazard'){
  if(deathPending||completed||mode!=='playing'||c23?.ending)return false;
  rf07OriNative.fail(cause);
  if(mode!=='dying')return false;
  deathPending=true;lives=Math.max(0,lives-1);protectedHit=false;power=0;weapon=null;upgradeTier=0;syncPlayer();
  log('death',{cause,lives});emit('death',{cause,lives});return true;
 }
 function hurt(cause='native contact'){
  if(paused||deathPending||mode!=='playing'||player.invuln||player.star||c23.ending)return false;
  if(!protectedHit)return fail(cause);
  protectedHit=false;power=0;weapon=null;upgradeTier=0;
  // Retain native hurt particles/sound, with enough internal HP to prevent a
  // second native death path. That internal value is never the survival gate.
  c23.ori.hp=2;rf07OriNative.hurt(cause);player.invuln=120;syncPlayer();log('protection-spent',{cause});return true;
 }
 function hudNative(){
  // Shared one-hit health has no six-heart bar. Original ability energy remains.
  ctx.fillStyle='#07151f';ctx.fillRect(0,0,W,32);
  hud('ORI',24,16);hud(String(score).padStart(6,'0'),24,24);
  ctx.save();ctx.translate(91,24);ctx.scale(.5,.5);sprite('coin0',0,0);ctx.restore();hud('×'+String(coins).padStart(2,'0'),104,24);
  hud('WORLD',W-112,16);hud('1-4',W-104,24);hud('TIME',W-48,16);hud(String(timeLeft).padStart(3,'0'),W-40,24);
  for(let i=0;i<4;i++){ctx.fillStyle=i<c23.ori.energy?'#9bddff':'#29445b';ctx.beginPath();ctx.moveTo(128+i*4,18);ctx.lineTo(130+i*4,21);ctx.lineTo(128+i*4,24);ctx.lineTo(126+i*4,21);ctx.closePath();ctx.fill();}
 }
 function scoped(fn,{allowAudio=false,rendering=false}={}){
  const old={c23Hurt,c23Fail,c23Retry,c23UI,o24UI,o28UI,c23Chrome,o30Chrome,c23UpdateTabs,
   showOverlay,updateUi,updateHeroUI,audioSync,o24HUD,o28HUD,set:save.set};
  c23Hurt=hurt;c23Fail=fail;c23Retry=respawn;c23UI=o24UI=o28UI=c23Chrome=o30Chrome=c23UpdateTabs=updateUi=updateHeroUI=noop;
  showOverlay=noop;audioSync=allowAudio?rf07OriNative.audio:noop;o24HUD=rendering?hudNative:noop;o28HUD=noop;save.set=noop;
  try{return fn();}finally{
   ({c23Hurt,c23Fail,c23Retry,c23UI,o24UI,o28UI,c23Chrome,o30Chrome,c23UpdateTabs,showOverlay,updateUi,updateHeroUI,audioSync,o24HUD,o28HUD}=old);save.set=old.set;
  }
 }
 function resetAt(checked=null){
  const totals={lives,score,coins};
  rf07OriNative.reset(0,false);c23.practice=false;o30.active=false;o30.restoring=true;o30.pending=false;
  if(checked){
   const s=checked.data;
   o29.world=checked.world;o29Refresh();
   if(s.phase==='horizontal'){
    const map=c23Map();
    for(const d of O29_CANONICAL.entities){if(!d.id.startsWith('tile:'))continue;const st=o29.world.state(d.id),k=tileKey(d.x/16,d.y/16),t=map.get(k);
     if(st.destroyed)map.delete(k);else if(t){t.used=st.used;t.hidden=!st.revealed;if(st.used)t.content=null;t.worldId=d.id;}}
    tiles=map;surface={tiles,enemies,items,pipes,coins:looseCoins};c23.cp=s.cp;
    const sp=C23_CPS[s.cp];player.x=sp.x;player.y=sp.feet-player.h;player.grounded=true;camera=clamp(player.x-110,0,Math.max(0,2560-W));
    c23.saved={index:s.cp,power:0,score:totals.score,coins:totals.coins,map:[...map.values()].map(t=>({...t})),time:s.time};
   }else{c23.bridgeRemoved=13;c23.ticks=s.ticks;o28.phase='flood';rf07OriNative.enterFlood(s.cp,true);}
   c23.ticks=s.ticks;c23.runFrames=s.runFrames;c23.retries=s.retries;frame=s.ticks;timeLeft=s.time;
   Object.assign(c23.ori,Object.fromEntries(O30_STAT_KEYS.map((k,i)=>[k,s.stats[i]])));o29.windFrames=s.windFrames;o29.gateBreaks=s.gateBreaks;
  }
  lives=totals.lives;score=totals.score;coins=totals.coins;player.invuln=checked?75:0;
  syncPlayer();safeChapter=captureChapter();safeKey=JSON.stringify(checkpointId());c23Clear();c23.ori.bashLock=false;
 }
 function respawn(){
  if(!deathPending)return;
  if(lives<=0){completed=true;mode='gameover';return;}
  const checked=validateChapter(safeChapter),retries=c23.retries;resetAt(checked);c23.retries=retries;
  deathPending=false;log('respawn',{checkpoint:checkpointId(),lives});emit('respawn',{checkpoint:checkpointId(),lives});
 }
 c23Campaign={...c23Campaign,stage:14,chosen:{...c23Campaign.chosen,14:'ori'},completed:new Set(c23Campaign.completed)};
 hero='ori';c23Menu=false;mode='playing';o30.active=false;o30.restoring=true;o30.pending=false;
 if($('c23Practice'))$('c23Practice').checked=false;
 lives=initialState.lives;score=initialState.score||0;coins=initialState.coins||0;
 try{scoped(()=>resetAt(incoming));if(Number.isInteger(initialState.native?.energy))c23.ori.energy=clamp(initialState.native.energy,0,4);}catch(error){dispose();throw error;}

 function compactNative(){return {version:1,actor:'ori',energy:c23.ori.energy,upgradeTier,chapter:clone(safeChapter)};}
 function checkpointCarry(){return {lives,coins,score,hero:'ori',power,protection:protectedHit?1:0,weapon,
  checkpoint:{levelId:'1-4',...checkpointId()},native:compactNative()};}
 function step(input={}){
  if(disposed||paused||completed)return;
  const v={...input,left:input.left||input.x<0,right:input.right||input.x>0,bash:!!(input.bash||input.ability)};
  // Host pointers are in campaign world coordinates. The authored tower is
  // centred in a 256-wide viewport and has its own vertical camera owner.
  if(input.pointer?.active){const viewport=input.pointer.space==='viewport',vertical=o28IsVertical();
   v.bashPointer={active:true,x:input.pointer.x+(viewport?camera:0)-(vertical?(W-256)/2:0),y:input.pointer.y+(vertical?o28.camY:0)};
  }
  if(input.pointer?.active){o24Mouse.valid=true;o24Mouse.x=input.pointer.x-camera-(o28IsVertical()?(W-256)/2:0);o24Mouse.y=input.pointer.y;}
  else o24Mouse.valid=false;
  const oldPhase=o28.phase,oldPickups=[...c23.ori.pickups],oldEvents=c23Ev.length;
  scoped(()=>rf08WithOriUpgrade(upgradeTier,()=>rf07OriNative.step(v)));
  if(!deathPending&&oldPickups.some(p=>p.type==='cell'&&p.remove)){protectedHit=true;upgradeTier=Math.min(2,upgradeTier+1);power=upgradeTier;c23.ori.upgradeTier=upgradeTier;rf08OriPickup(c23.ori,upgradeTier===1?'ori-light':'ori-cell');log('cell-collected',{upgradeTier});}
  // Normal horizontal play follows the campaign's committed left edge. The
  // authored rotation, flood, bridge and final performance retain their script.
  if(o28.phase==='horizontal'&&!c23.ending&&!deathPending&&player.x<camera){player.x=camera;if(player.vx<0)player.vx=0;}
  syncPlayer();
  if(oldPhase!==o28.phase)log('phase',{from:oldPhase,to:o28.phase});
  const key=JSON.stringify(checkpointId());
  if(!deathPending&&['horizontal','flood'].includes(o28.phase)&&key!==safeKey){safeChapter=captureChapter();safeKey=key;emit('checkpoint',checkpointId());}
  for(const e of c23Ev.slice(oldEvents))if(['switch-opened','castle-rotation-start','castle-upright','escaped-tower','outside-dialogue','mario-dialogue','two-act-complete'].includes(e.type))log(e.type);
  if(mode==='win'&&o28.phase==='outside'&&o28.age>=510){completed=true;log('campaign-finish');}
 }
 function view(){return {nativeStage:true,roomId:'ori-'+o28.phase,character:E04Modules.campaignCatalog.character('ori'),
  p:{...player,power,protection:protectedHit?1:0,weapon,dying:deathPending},tick:c23.ticks,cam:camera,
  width:o28.phase==='horizontal'?2560:240,height:o28.phase==='flood'?O28_H:240,lives,coins,score,timeLeft,
  completed,health:protectedHit?2:1,checkpoint:checkpointId(),native:compactNative(),phase:o28.phase,phaseAge:o28.age,
  finish:completed?'complete':null,paused,geometry:[],objects:[],enemies:[],items:[],projectiles:[]};}
 function pause(){if(disposed)return;paused=true;scoped(()=>c23Clear());stopMusic(true);stopEffects();}
 function resume(){if(disposed)return;paused=false;mode=deathPending?'dying':completed?(lives?'win':'gameover'):'playing';c23.ori.prev={};c23.ori.bashLock=false;}
 function setViewportWidth(n){if(Number.isFinite(n)&&n>=256&&n<=1024)W=n;}
 function drawNative(){if(disposed)return null;
  const sein=o24DrawSein,oriDraw=o24Ori,o=c23.ori,pulse=o.pulse;
  o24Ori=(g,...args)=>E04Modules.drawStarActor(g,player,c23.ticks,()=>oriDraw(g,...args));
  o24DrawSein=function(g,x,y,face,ticks,visible=true){
   if(visible&&!deathPending)rf08DrawOriFeedback(g,player,o,ticks,{native:true,offsetX:x-(player.x+4.5),offsetY:y-(player.y+player.h)});
   return sein(g,x,y,face,ticks,visible);
  };
  // The new pulse uses the actual captured release origin/radius; suppress the
  // old player-following 64px pulse only when that event-owned pulse exists.
  if(o.rf08?.burst)o.pulse=0;
  try{scoped(()=>rf07OriNative.draw(),{rendering:true});}finally{o24DrawSein=sein;o24Ori=oriDraw;o.pulse=pulse;}
  return {native:true,width:W,height:240,phase:o28.phase};}
 function audioPort(playing){if(disposed)return;const old=mode;mode=playing&&!paused?(deathPending?'dying':completed?'win':'playing'):'paused';try{scoped(()=>rf07OriNative.audio(),{allowAudio:true});}finally{mode=old;}}
 function dispose(){
  if(disposed)return;disposed=true;resetGameAudio();
  for(const [k,v]of Object.entries(priorSlots))rf04Slots[k][1](v);
  ({score,coins,lives,timeLeft,timerTicks,checkpoint,maxProgress,surface,underground,pipeTransition,flagPhase,flagTimer,flagY,
   c23Campaign,c23ReadyMenu,c23BlockJump,c23PendingJump,c23Device,o29,o28TurnCapture,o24Mouse,virtualInput}=prior);
  Object.assign(o30,prior.o30);Object.assign(o32Input,prior.o32);if($('c23Practice'))$('c23Practice').checked=previousPractice;
 }
 setViewportWidth(viewportWidth);
 const diagnostics=debug?{
  place(body){for(const k of ['x','y','vx','vy','invuln'])if(Number.isFinite(body[k]))player[k]=body[k];if(typeof body.grounded==='boolean')player.grounded=body.grounded;},
  hit:()=>scoped(()=>hurt('diagnostic contact')),die:()=>scoped(()=>fail('diagnostic hazard')),
  bump:id=>scoped(()=>{const t=[...tiles.values()].find(t=>t.worldId===id||tileKey(t.x,t.y)===id);if(t)bumpTile(t);}),
  enter(roomId,spawnId){const phase=roomId.replace('ori-',''),cp=Number(spawnId.replace('checkpoint-',''));if(!['horizontal','flood'].includes(phase)||!Number.isInteger(cp))throw Error('Unknown native fixture');
   scoped(()=>{if(phase==='flood'){c23.bridgeRemoved=13;o29SyncHorizontal(true);rf07OriNative.enterFlood(cp,false);}else{rf07OriNative.reset(cp,false);syncPlayer();}safeChapter=captureChapter();safeKey=JSON.stringify(checkpointId());});},
  actor:()=>({phase:o28.phase,age:o28.age,ticks:c23.ticks,runFrames:c23.runFrames,deathFrames:c23.deathFrames,
   cp:o28.phase==='horizontal'?c23.cp:o28.cp,water:o28.water,waterAge:o28.waterAge,waterStarted:o28.waterStarted,
   camY:o28.camY,bridgeRemoved:c23.bridgeRemoved,worldSize:o29.world.size,canonicalSize:O29_CANONICAL.entities.length,
   ori:{energy:c23.ori.energy,upgradeTier,jumps:c23.ori.jumps,bashed:c23.ori.bashed,doubleJumps:c23.ori.doubleJumps,bash:clone(c23.ori.bash),pose:c23.ori.pose,charge:c23.ori.charge,lightAim:clone(c23.ori.lightAim),bolts:clone(c23.ori.bolts),orbs:clone(c23.ori.orbs),rf08:clone(c23.ori.rf08||null)},
   targets:o24NearTargets().map(t=>({type:t.type,x:t.x,y:t.y,id:t.id})),bars:o29Bars(),events:clone(events),
   compactBytes:JSON.stringify(compactNative()).length,worldFlags:encodeWorld(),checkpoint:clone(safeChapter),
   assets:{ori:A39.loaded,grandfather:G38.loaded,junior:!!o28Jr.naturalWidth},originalEvents:clone(o28.events.slice(-24))})
 }:undefined;
 return Object.freeze({nativeStage:true,world,view,step,pause,resume,dispose,setViewportWidth,drawNative,audio:audioPort,checkpointCarry,diagnostics});
}
