/* Campaign enemy ports. Ori's Spitter uses original ordered sprite frames,
 * original attack/hurt/death samples and an aimed ballistic attack.
 * Sonic uses unmodified Sonic Worlds Next
 * d99390279504b23ea0766b5e9c29faa05f625d49 MotoBug / BadnickSmoke frames.
 * See docs/RF08_UPGRADES.md and the pinned source receipt. */
const rf08FoeArt={motobug:new Image(),smoke:new Image(),explosion:new Image()};
rf08FoeArt.motobug.src='@@E04:uri:a305@@';
rf08FoeArt.smoke.src='@@E04:uri:a306@@';
rf08FoeArt.explosion.src='@@E04:uri:a307@@';
mainlineAssetJobs.push(Promise.all(Object.values(rf08FoeArt).map(im=>im.decode())));
S33_ASSETS.sfx.badnikDestroy='@@E04:uri:a308@@';

function createRf08CharacterFoes(hero){
 if(!['ori','sonic'].includes(hero))return null;
 const source=hero==='ori'?'ori-r29':'sonic-worlds-next';
 const overlap=(a,b)=>a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y;
 function prepare(w){
  let ordinal=0;
  for(const e of w.enemies){
   if(e.nativeOwner||!/^((enemy-|marker-)?goomba|walker)$/.test(e.originalType||e.type||''))continue;
   const replace=w.nativeEnemiesOnly||ordinal++%4===0;
   if(e.foeSource||!replace)continue;
   const feet=e.y+e.h,cx=e.x+e.w/2;
   Object.assign(e,{foeSource:source,originalType:e.type,type:hero==='ori'?'ori-dark-shooter':'sonic-motobug',
    x:cx-(hero==='ori'?9:12),y:feet-(hero==='ori'?18:19.2),w:hero==='ori'?18:24,h:hero==='ori'?18:19.2,
    hp:hero==='ori'?3:1,vx:0,vy:0,dir:-1,foeAge:0,turnAge:0,foeState:hero==='ori'?'watch':'patrol',foeAnim:0,smoke:[],originId:e.id,
    ...(hero==='ori'?{species:'spitter',artSource:'OriPC/chargingSootAtlasAtlas0'}:{})});
  }
 }
 function step(e,w,p){
  if(e.foeSource!==source)return false;if(e.dead)return true;
  e.foeAge=(e.foeAge||0)+1;if(e.flash>0)e.flash--;
  if(e.type==='ori-dark-fire'){
   if(!e.reflected)e.vy+=e.gravity||0;
   e.x+=e.vx;e.y+=e.vy;
   if(e.reflected){for(const other of w.enemies)if(other!==e&&!other.dead&&other.type!=='ori-dark-fire'&&overlap(e,other)){w.damageEnemy(other,4,{kind:'ori-bash-reflect'});e.dead=true;break;}}
   if(e.foeAge>280||e.x<-20||e.x>w.width+20||e.y<-20||e.y>w.height+20||w.solids.some(q=>!q.hidden&&q.collision==='solid'&&overlap(e,q)))e.dead=true;
   return true;
  }
  E04Modules.stepEnemyGroundContact(e,w.solids,E04Modules.enemyDefinition(e).movement.grounding);
  if(e.y>w.height+40){e.dead=true;return true;}
  if(hero==='ori'){
   e.vx=0;const phase=e.foeAge%155;
   if(phase<=73||!e.committedAim)E04Modules.commitEnemyAim(e,p,{muzzleOffset:9});
   e.foeState=phase>=121?'recover':phase>=73?'windup':'watch';
   e.foeStateAge=phase-(phase>=121?121:phase>=73?73:0);e.pulse=0;
   // 24 charge frames + 17 shooting frames at the source's 30 fps. The
   // projectile leaves on the open-mouth frame, never during the windup.
   if(phase===137&&Math.abs(p.x-e.x)<240&&w.enemies.filter(q=>!q.dead&&q.owner===e.id).length<3){
    const x=e.x+e.w/2+e.dir*9,y=e.y+7,dx=e.committedAim.x-x,dy=e.committedAim.y-y;
    const flight=Math.max(38,Math.min(80,Math.abs(dx)/1.35)),gravity=.035;
    w.enemies.push({id:e.id+'-dark-'+e.foeAge,originId:e.id,foeSource:source,type:'ori-dark-fire',kind:'walker',
     x:x-3,y:y-3,w:6,h:6,vx:dx/flight,vy:dy/flight-gravity*flight/2,gravity,hp:1,dead:false,foeAge:0,owner:e.id});
    e.lastShotTick=w.tick;o24Sound('spitterAttack');
   }return true;
  }
  e.smoke=(e.smoke||[]).filter(q=>++q.age<6);
  const foot=e.y+e.h,cx=e.x+e.w/2,dx=e.dir*.6;
  const body={x:cx-4.8,y:foot-16.8,w:9.6,h:16.8};
  const wall=w.solids.some(q=>!q.hidden&&q.collision==='solid'&&overlap({...body,x:body.x+dx},q)&&body.y+body.h>q.y+.5);
  const probe=cx+e.dir*4.8,edge=e.grounded&&!w.solids.some(q=>!q.hidden&&['solid','oneway'].includes(q.collision)&&probe>=q.x&&probe<q.x+q.w&&q.y>=foot-1&&q.y<=foot+8.4);
  if(e.foeState==='patrol'&&(wall||edge)){e.foeState='turn';e.turnAge=0;e.turnCause=wall?'wall':'edge';}
  if(e.foeState==='turn'){
   e.vx=0;e.foeAnim=0;
   if(++e.turnAge>=60){e.dir=-e.dir;e.foeState='patrol';e.turnAge=0;e.turnTick=w.tick;}
  }else{
   e.vx=dx;e.x+=dx;const prior=e.foeAnim;e.foeAnim=(e.foeAnim+1/30)%1;
   if(e.foeAnim<prior)e.smoke.push({x:e.x+e.w/2-e.dir*14.4,y:foot-10.8,age:0});
  }
  e.foeFrame=Math.floor((e.foeAnim*5)%2)*2+Math.max(0,Math.floor(e.foeAnim+.2));return true;
 }
 function hurt(e,amount,event,w){
  if(e.foeSource!==source||e.dead||e.foeDeath)return false;
  e.hp=(e.hp??1)-amount;
  if(e.hp>0&&hero==='ori'){e.flash=8;o24Sound('spitterHurt');}
  return true;
 }
 function death(e,tick=0){
  if(e.foeSource!==source)return null;
  if(e.foeDeath)return null;e.foeDeath=true;e.hp=0;
  const hitEventId=e.hitIds?.at(-1)||'defeat-'+e.id+'-'+tick;
  const effect={kind:'rf08-foe-death',foeSource:source,hitEventId,feedbackEventId:hitEventId,deathTick:tick,flat:true,vx:0,vy:0};
  if(e.type==='ori-dark-fire')return {...effect,projectile:true,life:8};
  if(hero==='sonic'){s33Sound('badnikDestroy');return {...effect,sound:'s33_badnikDestroy',life:20};}
  o24Sound('spitterDeath');return {...effect,sound:'ori-spitter-death',dir:e.dir,life:80};
 }
 function draw(g,e,tick){
  if(e.foeSource!==source)return false;
  const x=e.x+e.w/2,y=e.y+e.h/2;
  if(e.kind==='rf08-foe-death'){
   const age=e.age||0;
   if(hero==='sonic'){
    if(age<20&&rf08FoeArt.explosion.naturalWidth){g.save();g.imageSmoothingEnabled=false;g.drawImage(rf08FoeArt.explosion,Math.min(4,Math.floor(age/4))*32,0,32,32,Math.round(x-12),Math.round(y-12),24,24);g.restore();}
   }else if(!e.projectile){rf093DrawOriSpitter(g,e);
   }else{
    // Same native deterministic o24FX palette and particle expansion, owned by
    // this one accepted death rather than a player-dependent fallback sprite.
    const n=e.projectile?7:14;
    for(let i=0;i<n;i++){const a=i*2.399963,q=.25+(i%5)/5,life=20+i%13;if(age>=life)continue;
     const speed=e.projectile?1.1:2;g.save();g.globalAlpha=1-age/life;o24Ellipse(g,x+Math.cos(a)*speed*q*age*.75,y+(Math.sin(a)*speed*q-.25)*age*.75,.35+i%3*.27,.35+i%3*.27,'#92efff');g.restore();}
   }return true;
  }
  if(e.dead)return true;
  if(hero==='ori'){
   if(e.type==='ori-dark-fire'){o24Glow(g,x,y,9,e.reflected?'#ffe4ad':'#ef656a',.30);o24Ellipse(g,x,y,2.6,2.6,e.reflected?'#fff5cf':'#ffd18b');return true;}
   rf093DrawOriSpitter(g,e);
   if(e.pulse)o24Glow(g,x+e.dir*9,e.y+7,6,'#ff827b',e.pulse/25*.42);
   return true;
  }
  g.save();g.imageSmoothingEnabled=false;
  for(const q of e.smoke||[])if(rf08FoeArt.smoke.naturalWidth)g.drawImage(rf08FoeArt.smoke,0,Math.min(2,Math.floor(q.age/2))*8,8,8,Math.round(q.x-2.4),Math.round(q.y-2.4),4.8,4.8);
  // Source sprite centre y=1 and collision half-height=14: the opaque last
  // row (28) meets the real floor. Do not anchor the transparent row 31.
  if(rf08FoeArt.motobug.naturalWidth){const f=e.foeFrame||0;g.translate(Math.round(x),Math.round(e.y+e.h));g.scale(E04Modules.enemyFacingScale(E04Modules.enemyDefinition(e),e.dir||-1),1);g.drawImage(rf08FoeArt.motobug,(f%2)*40,Math.floor(f/2)*32,40,32,-12,-17.4,24,19.2);}
  g.restore();return true;
 }
 return Object.freeze({prepare,step,draw,hurt,death});
}
