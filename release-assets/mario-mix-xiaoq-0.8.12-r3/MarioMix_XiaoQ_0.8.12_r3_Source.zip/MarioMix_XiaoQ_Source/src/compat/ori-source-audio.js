/* Original recordings share the existing measured bus, owner and voice budget.
 * Do not raise pitch while charging or reuse a player shot as an enemy cue. */
Object.assign(FX40_DATA,@@E04:file:src/data/ori-original-audio.json@@);
FX40.buffers.clear();
