/* RF04: adapters call the final RF02 controllers, combat and sprite routines.
 * The campaign owns rooms, time, lives and exits. Native globals are borrowed
 * synchronously and always restored; optional challenge scenes keep their state.
 */
const rf04Native={player:updatePlayer,entities:updateEntities,drawPlayer,drawEnemy,drawItem,
 buildLevel,ninjaPlayer:r12NinjaPlayer,ninjaEnemies:r12NinjaEnemies,relayCombat:r12Combat,
 relayProjectiles:r04Projectiles,relayGive:r12Give,relayEnemyLayer:r12EnemyLayer,
 castlePlayer:o24Player,castleWorld:o24World,castleHurt:c23Hurt,ori:o24Ori,
 damage,ninjaHurt,damageEnemy:r12DamageEnemy,killEnemy:r12Kill,transform,audio:audioSync,nearTargets:o24NearTargets,sonicTargets:s33Targets,
 billFire:fireBillWeapon,billAdvance:advanceMixProjectile,ninjaSwing,ninjaThrow,sonicHitTarget:s33HitTarget,sonicHurtFeedback:s33HurtFeedback};

// Persistent equipment crosses scenes; attacks, projectiles and hit clocks do not.
function rf09RestoreRyuEquipment(target,data={}) {
 const valid=k=>Object.hasOwn(R12_WEAPONS,k);
 target.nativeVitals=data.nativeVitals?E04Modules.nativeSceneHealth(E04Modules.CHALLENGE_RULES.ryu,data.nativeVitals):null;
 target.spirit=Number.isFinite(data.spirit)?clamp(data.spirit,0,99):12;
 target.unlocked=(Array.isArray(data.unlocked)?data.unlocked:['shuriken']).filter(valid);
 if(!target.unlocked.length)target.unlocked=['shuriken'];
 target.weapon=target.unlocked.includes(data.weapon)?data.weapon:target.unlocked[0];
 target.attackMode=data.attackMode==='blade'?'blade':target.weapon!=='shuriken'||data.attackMode==='shuriken'?target.weapon:'blade';
}
function rf09CycleRyuEquipment(target,input){
 if(!input.cyclePressed)return;
 const choices=['blade',...target.unlocked],active=target.attackMode||'blade';
 const next=choices[(Math.max(0,choices.indexOf(active))+1)%choices.length];
 target.attackMode=next;if(next!=='blade')target.weapon=next;
 input.cyclePressed=false;
}

// Explicit lexical ports, never eval or a second game loop.
const rf04Slots={
 enemyLifecycleOwner:[()=>enemyLifecycleOwner,v=>enemyLifecycleOwner=v],
 hero:[()=>hero,v=>hero=v],mode:[()=>mode,v=>mode=v],frame:[()=>frame,v=>frame=v],
 player:[()=>player,v=>player=v],room:[()=>room,v=>room=v],camera:[()=>camera,v=>camera=v],
 deathTick:[()=>deathTick,v=>deathTick=v],
 tiles:[()=>tiles,v=>tiles=v],pipes:[()=>pipes,v=>pipes=v],enemies:[()=>enemies,v=>enemies=v],
 items:[()=>items,v=>items=v],shots:[()=>shots,v=>shots=v],mixShots:[()=>mixShots,v=>mixShots=v],
 enemyShots:[()=>enemyShots,v=>enemyShots=v],particles:[()=>particles,v=>particles=v],
 floaters:[()=>floaters,v=>floaters=v],looseCoins:[()=>looseCoins,v=>looseCoins=v],
 ninja:[()=>ninja,v=>ninja=v],r12:[()=>r12,v=>r12=v],r03Challenge:[()=>r03Challenge,v=>r03Challenge=v],
 r03Terrain:[()=>r03Terrain,v=>r03Terrain=v],r03Rewards:[()=>r03Rewards,v=>r03Rewards=v],
 r06Effects:[()=>r06Effects,v=>r06Effects=v],r06Death:[()=>r06Death,v=>r06Death=v],
 r07DefeatFx:[()=>r07DefeatFx,v=>r07DefeatFx=v],r12Journal:[()=>r12Journal,v=>r12Journal=v],
 r06UID:[()=>r06UID,v=>r06UID=v],r07BonusIndex:[()=>r07BonusIndex,v=>r07BonusIndex=v],
 billBase:[()=>billBase,v=>billBase=v],billWeapon:[()=>billWeapon,v=>billWeapon=v],
 billDropBag:[()=>billDropBag,v=>billDropBag=v],billMotion:[()=>billMotion,v=>billMotion=v],
 billAirTicks:[()=>billAirTicks,v=>billAirTicks=v],billFireFrames:[()=>billFireFrames,v=>billFireFrames=v],
 billAimX:[()=>billAimX,v=>billAimX=v],billAimY:[()=>billAimY,v=>billAimY=v],
 billAimDown:[()=>billAimDown,v=>billAimDown=v],billDropRow:[()=>billDropRow,v=>billDropRow=v],
 billDropCollision:[()=>billDropCollision,v=>billDropCollision=v],billDownJumpHeld:[()=>billDownJumpHeld,v=>billDownJumpHeld=v],
 mixTier:[()=>mixTier,v=>mixTier=v],mixHp:[()=>mixHp,v=>mixHp=v],mixCharge:[()=>mixCharge,v=>mixCharge=v],
 mixHeld:[()=>mixHeld,v=>mixHeld=v],mixCool:[()=>mixCool,v=>mixCool=v],mixAim:[()=>mixAim,v=>mixAim=v],
 mixCrouch:[()=>mixCrouch,v=>mixCrouch=v],mixSpread:[()=>mixSpread,v=>mixSpread=v],
 mixDeathOrigin:[()=>mixDeathOrigin,v=>mixDeathOrigin=v],ninjaHitLock:[()=>ninjaHitLock,v=>ninjaHitLock=v],
 jumpBuffer:[()=>jumpBuffer,v=>jumpBuffer=v],jumpHeldPrev:[()=>jumpHeldPrev,v=>jumpHeldPrev=v],runHeldPrev:[()=>runHeldPrev,v=>runHeldPrev=v],
 freeze:[()=>freeze,v=>freeze=v],c23:[()=>c23,v=>c23=v],c23Menu:[()=>c23Menu,v=>c23Menu=v],
 chapter:[()=>c23Campaign.stage,v=>c23Campaign.stage=v],o28:[()=>o28,v=>o28=v],
 r04TickInput:[()=>r04TickInput,v=>r04TickInput=v],
 solids:[()=>solids,v=>solids=v],at:[()=>at,v=>at=v],moveBody:[()=>moveBody,v=>moveBody=v],
 ninjaMove:[()=>ninjaMove,v=>ninjaMove=v],r12Body:[()=>r12Body,v=>r12Body=v],
 r12CommonPlayer:[()=>r12CommonPlayer,v=>r12CommonPlayer=v],r03TryDescent:[()=>r03TryDescent,v=>r03TryDescent=v],
 beginPipe:[()=>beginPipe,v=>beginPipe=v],beginFlag:[()=>beginFlag,v=>beginFlag=v],
 die:[()=>die,v=>die=v],c23Fail:[()=>c23Fail,v=>c23Fail=v],
 damage:[()=>damage,v=>damage=v],ninjaHurt:[()=>ninjaHurt,v=>ninjaHurt=v],r12TankHurt:[()=>r12TankHurt,v=>r12TankHurt=v],c23Hurt:[()=>c23Hurt,v=>c23Hurt=v],
 r12DamageEnemy:[()=>r12DamageEnemy,v=>r12DamageEnemy=v],r12Kill:[()=>r12Kill,v=>r12Kill=v],
 updateUi:[()=>updateUi,v=>updateUi=v],updateHeroUI:[()=>updateHeroUI,v=>updateHeroUI=v],
 showUpgrade:[()=>showUpgrade,v=>showUpgrade=v],r12Message:[()=>r12Message,v=>r12Message=v],
 bumpTile:[()=>bumpTile,v=>bumpTile=v],ninjaBump:[()=>ninjaBump,v=>ninjaBump=v],
 r12Break:[()=>r12Break,v=>r12Break=v],addScore:[()=>addScore,v=>addScore=v],getCoin:[()=>getCoin,v=>getCoin=v],
 fireBillWeapon:[()=>fireBillWeapon,v=>fireBillWeapon=v],advanceMixProjectile:[()=>advanceMixProjectile,v=>advanceMixProjectile=v],
 ninjaSwing:[()=>ninjaSwing,v=>ninjaSwing=v],ninjaThrow:[()=>ninjaThrow,v=>ninjaThrow=v],
 o28ConstrainPlayer:[()=>o28ConstrainPlayer,v=>o28ConstrainPlayer=v],o27PoolAt:[()=>o27PoolAt,v=>o27PoolAt=v],
 o24NearTargets:[()=>o24NearTargets,v=>o24NearTargets=v],s33Targets:[()=>s33Targets,v=>s33Targets=v],
 s33HitTarget:[()=>s33HitTarget,v=>s33HitTarget=v],
 o24BossDamage:[()=>o24BossDamage,v=>o24BossDamage=v],
};
function rf04Scope(values,fn,retain=[]){
 const prior={};
 try{for(const [k,v]of Object.entries(values)){if(!rf04Slots[k])throw Error('Unknown native port '+k);prior[k]=rf04Slots[k][0]();rf04Slots[k][1](v);}return fn();}
 finally{for(const k of retain)if(k in values)values[k]=rf04Slots[k][0]();for(const [k,v]of Object.entries(prior))rf04Slots[k][1](v);}
}

// RF07 shared upgrade seam: the dedicated Ori finale borrows these same native
// attacks. No legacy function or original chapter state survives this scope.
function rf07UpgradeTier(value){return Number.isInteger(value)&&value>=0&&value<=2?value:0;}
function rf07WithOriUpgrade(value,fn){
 const tier=rf07UpgradeTier(value);if(!tier)return fn();
 const flame=o24Flame,blast=o24Blast;
 o24Flame=function(...args){
  const o=c23.ori,start=o.bolts.length,result=flame(...args);
  if(o.bolts.length>start){for(let i=0;i<tier;i++)flame(...args);
   const spawned=o.bolts.slice(start);spawned.forEach((b,i)=>{b.y+=(i-(spawned.length-1)/2)*5;});}
  return result;
 };
 o24Blast=function(x,y,r,damage,cue){const charged=tier===2&&cue==='chargeBlast';return blast(x,y,charged?r*1.3:r,charged?damage+2:damage,cue);};
 try{return fn();}finally{o24Flame=flame;o24Blast=blast;}
}
function rf07DrawOriSupply(g,x,y,type,tick=0){
 return rf09DrawOriReward(g,x,y,type);
}
function rf07SonicPhysics(value){const tier=rf07UpgradeTier(value);return tier?{...S33_PHYS,acc:S33_PHYS.acc*1.5,brake:S33_PHYS.brake*1.5,top:S33_PHYS.top*1.5,electricJump:tier===2}:S33_PHYS;}
function rf07WithSonicUpgrade(sonic,fn){
 const prior=sonic.mainlinePhysics;
 sonic.mainlinePhysics=rf07SonicPhysics(sonic.upgradeTier);
 try{return fn();}finally{if(prior===undefined)delete sonic.mainlinePhysics;else sonic.mainlinePhysics=prior;}
}
function rf07BillPlayer(input){
 // NES Bill uses immediate 1 px/tick movement. Mainline tile traversal uses
 // 2 px/tick (classic course traversal); native Boss rooms retain source 1 px/tick.
 // Borrow the existing controller for jump/aim/prone/guns/collision only.
 const p=player,x=p.x,phase=billMotion,pose=billPose,direction=(input.right?1:0)-(input.left?1:0);
 p.directHorizontalSpeed=2;
 if(direction&&!p.crouch){p.vx=direction*p.directHorizontalSpeed;p.airCap=p.directHorizontalSpeed;}
 else if(p.grounded||input.left&&input.right)p.vx=0;
 // Shared water movement already happened before the native lease. Measure
 // its displacement instead of the blocked second movement write.
 const distance=()=>Math.abs(p.mainlineWater?p.mainlineWaterDx||0:p.x-x);
 const motion=()=>p.grounded&&distance()>.04&&!mixCrouch?phase+(p.mainlineWater?distance()/16:1/8):0;
 // Firing and rendering must see the same leg phase/torso bob. The old wrapper
 // advances a distance clock before asking billPose for its native muzzle.
 billPose=()=>{const previous=billMotion;billMotion=motion();try{return pose();}finally{billMotion=previous;}};
 try{rf04Native.player(input);if(p.mainlineMotion&&p.crouch&&p.grounded&&direction){p.vx=direction*.65;moveBody(p,p.vx,0,true);}}finally{billPose=pose;}
 if(p.grounded)billMotion=motion();
}

// The supplied SMBC BillBullet.as truncates FLARE_SPEED to 211 px/s. Bill's
// movement already uses that source's 150 px/s world scale (60 fixed ticks).
// The supplied NES bank6 keeps a forward centre plus these 16 integer offsets;
// it does not start the centre behind the gun or collide with ordinary floors.
const RF08_FLARE_X=[-15,-14,-11,-6,0,6,11,14,15,14,11,6,0,-6,-11,-14];
const RF08_FLARE_Y=[0,-6,-11,-14,-15,-14,-11,-6,0,6,11,14,15,14,11,6];
function rf08BillFire(){
 const start=mixShots.length,result=rf04Native.billFire();
 for(const s of mixShots.slice(start)){if(s.family!=='F'||s.baseForward)continue;
  const dx=Math.sign(s.vx),dy=Math.sign(s.vy),diagonal=dx&&dy,scale=diagonal?.75:1;
  Object.assign(s,{rf08Fire:true,axisX:s.x+s.w/2,axisY:s.y+s.h/2,vx:dx*211/60*scale,vy:dy*211/60*scale,
   orbitX:dx*(diagonal?11:16),orbitY:dy*(diagonal?11:16),orbitStep:player.facing<0?-1:1,
   orbitPhase:dy<0?dx>0?14:dx<0?10:12:dy>0?dx>0?2:dx<0?6:4:dx<0?8:0});
 }
 return result;
}
function rf08BillAdvance(s){
 if(!s.rf08Fire)return rf04Native.billAdvance(s);
 s.life--;s.age=(s.age||0)+1;s.axisX+=s.vx;s.axisY+=s.vy;
 s.cx=s.axisX+s.orbitX;s.cy=s.axisY+s.orbitY;
 s.x=s.cx+RF08_FLARE_X[s.orbitPhase]-s.w/2;s.y=s.cy+RF08_FLARE_Y[s.orbitPhase]-s.h/2;
 s.orbitPhase=(s.orbitPhase+s.orbitStep+16)%16;return true;
}
function rf08RyuThrow(){
 // Mainline rewards equip a sustained technique. The native projectile,
 // cooldown, hit sets, wall rejection and spin restrictions remain unchanged.
 const sustained=ninja.attackMode&&ninja.attackMode!=='blade';
 const spirit=ninja.spirit,start=ninja.projectiles.length;if(sustained)ninja.spirit=Math.max(spirit,R12_WEAPONS[ninja.weapon]?.cost||0);
 try{
  const fired=rf04Native.ninjaThrow();
  if(ninja.projectiles.length>start&&ninja.weapon==='flame'){
   const aim=E04Modules.ninjaFireAim(r04TickInput||{},player.facing);
   for(const shot of ninja.projectiles.slice(start))if(shot.kind==='flame'){
    shot.vx=aim.x*3.35;shot.vy=aim.y*3.35;
    shot.x=player.x+player.w/2-6+aim.x*(player.w/2+6);
    shot.y=player.y+player.h-17+aim.y*9;
   }
  }return fired;
 }finally{if(sustained)ninja.spirit=spirit;}
}
function rf08RyuSwing(){
 return ninja.attackMode&&ninja.attackMode!=='blade'&&!(ninja.weapon==='spin'&&player.grounded)
  ?rf08RyuThrow():rf04Native.ninjaSwing();
}

function createRf02MainlineActor(id,{emit=()=>{}}={}){
 if(id==='mario')return null;
 if(id==='sandboxTrio')return mainlineTerraActor({emit});
 if(!['bill','megaman','ryu','tank','ori','sonic'].includes(id))throw Error('No RF02 actor '+id);
 const classic=['bill','megaman'].includes(id),relay=['ryu','tank'].includes(id),castle=['ori','sonic'].includes(id);
 const maxHealth=1;
 let current=null,world=null,dead=false,disposed=false,enemyTemplates=null,lastRoom=null,previousInput={},supplyIndex=0,hurtCue=false,sceneVitals=null;
 const rooms=new Map(),noop=()=>{},falseFn=()=>false;
 const tracing=new URLSearchParams(location.search).has('test'),events=[];let eventSeq=0,hitContext=null,nativeScore=0;
 const retiring=new Map();
 function trace(kind,e,detail={}){if(!tracing)return;events.push({kind,tick:world?.tick||0,sequence:++eventSeq,id:e.id,x:e.x,y:e.y,hp:e.hp,score:nativeScore,...detail});if(events.length>256)events.shift();}
 function hitEnemy(e,amount){const previous=hitContext;hitContext={enemy:e,id:'native-hit-'+(eventSeq+1),before:e.hp,recorded:false};
  try{rf04Native.damageEnemy(e,amount);if(e.hp<hitContext.before&&!hitContext.recorded)trace('hit',e,{hitId:hitContext.id});}finally{hitContext=previous;}}
 function killNative(e,noScore){if(e.dead)return;
  const hit=hitContext?.enemy===e?hitContext:null;
  if(hit&&!hit.recorded){trace('hit',e,{hitId:hit.id});hit.recorded=true;}
  const oldFx=new Set([...r07DefeatFx,...r06Effects]);rf04Native.killEnemy(e,noScore);
  const fx=[...r07DefeatFx,...r06Effects].filter(f=>!oldFx.has(f));
  trace('death',e,{hitId:hit?.id,feedback:fx.length>0});if(tracing)retiring.set(e.id,{enemy:e,hitId:hit?.id,fx});
 }
 const native={billBase:null,billWeapon:'N',billDropBag:[],billMotion:0,billAirTicks:0,billFireFrames:0,
 billAimX:1,billAimY:0,billAimDown:false,billDropRow:null,billDropCollision:false,billDownJumpHeld:false,
 mixTier:0,mixHp:3,mixCharge:0,mixHeld:false,mixCool:0,mixAim:0,mixCrouch:false,mixSpread:false,
 mixDeathOrigin:null,ninjaHitLock:0,jumpBuffer:0,jumpHeldPrev:false,runHeldPrev:false,freeze:0,
 mixShots:[],enemyShots:[],particles:[],floaters:[],items:[],shots:[],looseCoins:[],
 ninja:r12NewNinja(),r12:null,r03Challenge:null,r03Terrain:[],r03Rewards:{ninja:false,tank:false},
 r06Effects:[],r06Death:null,r07DefeatFx:[],r12Journal:[],r06UID:90000,r07BonusIndex:0,
 c23:{ori:o24New(),sonic:s33New(),bowser:{alive:false,active:false,x:0,y:0},fire:[],ticks:0,runFrames:0,ending:0,
   practice:true,wave:-99999,cp:0,lift:{x:0,y:0,w:0,h:0,dx:0},dust:[],deathFrames:0},
 o28:{...o28,phase:'horizontal',age:0,platforms:[],shooters:[],projectiles:[],lamps:[],camY:0,water:99999},
 };
 native.r12={area:'campaign',def:{width:3400,name:'',lifts:[]},ticks:0,camY:0,lifts:[],discovered:new Set(),
 r08IntroPending:true,tank:{power:0,shield:0,freeze:0,cool:0,dir:0,track:0,fireBuffer:0,shovel:0},water:[],bridges:[],transition:0,spawnFrames:0,shake:0,flash:0};
 const retain=Object.keys(native);
 const defaults=structuredClone(native);
 if(id==='sonic')for(const key of Object.keys(s33SoundTimes))delete s33SoundTimes[key];

 function tileGeometry(w){
  const ts=new Map();
  for(const q of w.solids||[]){if(q.temporary)continue;for(let y=q.y;y<q.y+q.h;y+=16)for(let x=q.x;x<q.x+q.w;x+=16){
   const t={x:x/16,y:y/16,type:q.material==='block'?'question':q.material==='floor'?'ground':q.material==='brick'?'brick':q.material==='pipe'?'pipe':'stone',
    id:q.id,hidden:!!q.hidden,used:!!q.used,content:!q.used?(q.content||(q.material==='block'?'power':null)):null,parts:q.parts??15,shotHp:q.shotHp,
    mainline:q,rect:{x,y,w:Math.min(16,q.x+q.w-x),h:Math.min(16,q.y+q.h-y)},oneway:q.collision==='oneway',bump:q.bump||0};
   ts.set(tileKey(t.x,t.y),t);
  }}return ts;
 }
 function query(box,hidden=false){
  // Player shells can reveal an invisible reward; enemy shells cannot.
  const reveal=hidden||id==='tank'&&box.friendly&&native.ninja.projectiles.includes(box);
  return [...tiles.values()].filter(t=>{
   if(!(reveal||!t.hidden)||t.oneway&&box!==current)return false;
   if(!box.rf08Fire)return overlap(box,t.rect);
   const axis={x:box.axisX-box.w/2,y:box.axisY-box.h/2,w:box.w,h:box.h};
   // A horizontal cosmetic orbit below a supporting top must not consume the
   // shot. Solid walls/ceilings still meet its visible body; a downward axis
   // really reaches the ground and still collides. Enemy hits use visible x/y.
   return overlap(axis,t.rect)||overlap(box,t.rect)&&!(box.vy===0&&t.rect.y>=box.axisY+box.h/2);
  });
 }
 function move(body,dx,dy,isPlayer=false){
  isPlayer=isPlayer||body===current;
  if(body===current&&billDropRow!==null&&body.y>=(billDropRow+1)*T)billDropRow=null;
  const geoms=(world?.solids||[]).filter(q=>(!q.hidden||isPlayer&&dy<0)&&q.collision!=='none'&&!(body===current&&billDropRow!==null&&Math.abs(q.y-billDropRow*T)<1));
  const priorX=body.x,priorY=body.y,foot=body.y+body.h;let x=body.x+dx,y=body.y+dy,hitX=false,hitY=false;
  for(const q of geoms){if(q.hidden||q.collision!=='solid'||body.y+body.h<=q.y||body.y>=q.y+q.h)continue;
   if(dx>0&&body.x+body.w<=q.x+.01&&x+body.w>q.x){x=Math.min(x,q.x-body.w);hitX=true;}
   else if(dx<0&&body.x>=q.x+q.w-.01&&x<q.x+q.w){x=Math.max(x,q.x+q.w);hitX=true;}}
  body.x=x;body.grounded=false;body.support=null;
  let landing=null;
  for(const q of geoms){if(body.x+body.w<=q.x||body.x>=q.x+q.w)continue;
   if(!q.hidden&&dy>=0&&foot<=q.y-(q.dy||0)+1.01&&y+body.h>=q.y&&(!landing||q.y<landing.y))landing=q;
   if(q.collision==='solid'&&dy<0&&priorY>=q.y+q.h-.01&&y<q.y+q.h){y=Math.max(y,q.y+q.h);hitY=true;if(isPlayer)body.headHit=q.id;}}
  if(landing){y=landing.y-body.h;body.grounded=true;body.support=landing.id;hitY=true;}
  body.y=y;if(hitX)body.vx=isPlayer?0:classic?-(body.vx||0):body.vx;if(hitY)body.vy=0;
  return Math.abs(body.x-priorX-dx)>.01||Math.abs(body.y-priorY-dy)>.01;
 }
 function dynamicTargets(){
  if(!world||!current)return[];const p={x:current.x+current.w/2,y:current.y+current.h/2};
  const targets=[...(world.enemies||[]).filter(e=>!e.dead&&e.y<world.height&&e.x>world.camera-32&&(world.enemyDefinition?world.enemyDefinition(e):E04Modules.enemyDefinition?.(e))?.targetable!==false).map(e=>({x:e.x+e.w/2,y:e.y+e.h/2,type:/fire|bullet|hammer/.test(e.type||'')?'fire':'enemy',id:e.id,key:'enemy:'+e.id,ref:e})),
   ...native.c23.ori.orbs.map((e,i)=>({x:e.x,y:e.y,type:'orb',id:i,key:'orb:'+i,ref:e})),
    ...(world.objects||[]).filter(o=>o.kind==='bash-anchor').map(o=>({x:o.x+o.w/2,y:o.y+o.h/2,type:'lantern',id:o.id,key:o.id}))];
  return targets.map(t=>({...t,d:Math.hypot(t.x-p.x,t.y-p.y)})).filter(t=>t.d>0&&t.d<113&&o24LineClear(p,t)).sort((a,b)=>a.d-b.d);
 }
 function withNative(p,w,fn,{render=false,playing=true,phase=null,feedback=false,phaseActor='misc'}={}){
  if(disposed)return;current=p||current;world=w||world;
  const geoms=world?tileGeometry(world):new Map(),tileEntries=[...geoms];
  native.r12.def.width=world?.width||3400;native.r12.ticks=world?.tick||0;
  // The native 16px image overhangs its 12px body by 2px on each side.
  // Only the outer world edge includes that art margin; real solids use the body.
  native.r12.playfield={l:2,t:2,r:(world?.width||3400)-2,b:world?.bottomExit===true?E04Modules.mainlineBottomLimit(world,current,{inset:2})+current.h:(world?.height||240)-2};
  native.r12.campaignItems=world?.items||[];
  native.r12.lifts=(world?.solids||[]).filter(q=>q.collision==='oneway').map(q=>({...q,vy:q.dy||0}));
  native.c23.ticks=world?.tick||0;native.c23.runFrames=native.c23.ticks;
  const commonTarget=(world?.enemies||[]).filter(e=>!e.dead&&!e.nativeOwner&&!(id==='sonic'&&e.foeSource==='sonic-worlds-next')&&!/fire|bullet|hammer/.test(e.type||'')).sort((a,b)=>Math.hypot(a.x-current.x,a.y-current.y)-Math.hypot(b.x-current.x,b.y-current.y))[0];
  native.c23.bowser=commonTarget?Object.assign(commonTarget,{alive:!commonTarget.dead,active:true}):{alive:false,active:false,x:0,y:0};
  const stop=()=>{dead=true;};
  const contact=source=>world?.damage?.(typeof source==='object'?source:{type:source||'native-contact'});
  const bump=t=>world?.bump?.(t.id||t.mainline?.id);
  const values={...native,hero:id,player:current,mode:playing?(phase||(current?.dying?'dying':'playing')):'paused',deathTick:current?.deathAge||0,frame:world?.tick||0,
   room:'surface',camera:render?0:world?.camera||0,tiles:geoms,pipes:[],enemies:(world?.enemies||[]).filter(e=>e.nativeOwner===id),
   chapter:castle?14:relay?12:11,c23Menu:false,
   solids:query,at:(x,y)=>geoms.get(tileKey(x,y)),moveBody:move,ninjaMove:(dx,dy)=>move(current,dx,dy,true),
   // r12Body's native boolean means a HORIZONTAL wall, never a landing.
   // Returning vertical contact makes r12NinjaEnemies turn on every floor frame.
   r12Body:(e,dx,dy)=>{const x=e.x;move(e,dx,dy);return Math.abs(e.x-x-dx)>.01;},
   r12CommonPlayer:noop,r03TryDescent:falseFn,beginPipe:falseFn,beginFlag:noop,die:stop,c23Fail:stop,
   ...(!feedback?{damage:contact,ninjaHurt:contact,r12TankHurt:contact,c23Hurt:contact}:{}),
   enemyLifecycleOwner:world,
   ...(relay?{r12DamageEnemy:hitEnemy,r12Kill:e=>world.kill(e)}:{}),
   updateUi:noop,updateHeroUI:noop,showUpgrade:noop,r12Message:noop,bumpTile:bump,ninjaBump:bump,
   r12Break:(t,by='sword')=>{
    if(id==='tank'&&by==='cannon'){
     const s=r12.r03Impact;if(!s||s.friendly===false)return false;
     const power=s.power??r12.tank.power;
     const terrainImpact=E04Modules.createTerrainImpact({owner:id,weapon:'cannon',materials:power>=3?['brick','block','stone','steel']:['brick','block']});
     return !!world?.breakBlock?.(t.id,{kind:'tank-shell',power,terrainImpact,x:s.x+s.w/2,y:s.y+s.h/2});
    }
    if(t.content&&!t.used){bump(t);return false;}if(t.type!=='brick')return false;world?.bump?.(t.id,true);return true;
   },
   ...(id==='bill'?{fireBillWeapon:rf08BillFire,advanceMixProjectile:rf08BillAdvance}:{}),
   ...(id==='ryu'?{ninjaSwing:rf08RyuSwing,ninjaThrow:rf08RyuThrow}:{}),
   ...(id==='sonic'?{s33HitTarget:t=>{
    if(!t.ref||!world?.enemies.includes(t.ref))return rf04Native.sonicHitTarget(t);
    const definition=world.enemyDefinition?world.enemyDefinition(t.ref):E04Modules.enemyDefinition(t.ref);
    const damage=definition.contact.attack==='damage'?definition.contact.damage:4;
    if(world.damageEnemy(t.ref,damage,{id:'sonic-homing-'+world.tick+'-'+t.ref.id,kind:'homing',owner:'sonic'})!==true)return false;
    const s=c23.sonic;Object.assign(s,{lastTarget:t.key,targetCool:36,homing:null,homingCd:6,dashReady:true,spin:true});
    current.vy=-5.65;current.vx*=.28;current.grounded=false;
    o24FX(current.x+4,current.y+7,'#9bdeff',16,1.9);c23Event('sonic-bounce',{target:t.key});
    return true;
   }}:{}),
   addScore:n=>{const value=Math.max(0,n||0);nativeScore+=value;world?.addScore?.(value);},getCoin:()=>world?.collectCoin?.(),
   o28ConstrainPlayer:p=>{p.x=clamp(p.x,0,Math.max(0,(world?.width||256)-p.w));if(p.y>(world?.height||240)+40&&!(world?.mainline===true&&world?.bottomExit===true))stop();},
   o27PoolAt:()=>null,o24NearTargets:()=>dynamicTargets().filter(t=>t.d<56),
   s33Targets:()=>dynamicTargets().filter(t=>t.d<113).map(t=>({...t,type:t.type==='fire'?'projectile':t.type==='enemy'?/bowser/i.test(t.ref.type||'')?'boss':'enemy':'light'})),
   o24BossDamage:n=>{const e=native.c23.bowser;if(!e.alive)return;world?.damageEnemy?.(e,n,{kind:id+'-native-attack',owner:id});},
  };
  const commonPower=current?.power;if(id==='megaman'&&current)current.power=0;
  try{return withAudioOwner('actor:'+id,()=>rf04Scope(values,()=>!render&&id==='ori'?rf08WithOriUpgrade(native.c23.ori.upgradeTier,fn,{world,player:current,phase:phaseActor}):!render&&id==='sonic'?rf08WithSonicUpgrade(native.c23.sonic,fn,{world,player:current,phase:phaseActor}):fn(),retain));}finally{if(id==='megaman'&&current)current.power=commonPower;for(const k of retain)native[k]=values[k];
   if(!render)for(const [key,t]of tileEntries){if(t.shotHp!==undefined)t.mainline.shotHp=t.shotHp;if(!geoms.has(key))world?.removeSolid?.(t.id);}
  }
 }
 function summary(p=current){if(!p)return{};p.maxHealth=maxHealth;p.hp=dead?0:1;
  p.power=id==='megaman'?native.mixTier:id==='tank'?native.r12.tank.power:p.power||0;
  p.weapon=id==='bill'?native.billWeapon:id==='ryu'?native.ninja.weapon:p.weapon;
  p.charge=native.mixCharge;p.shotCooldown=native.mixCool;p.attackTicks=native.ninja.attack;
  p.wallSide=id==='ryu'?native.ninja.wall:castle?native.c23.ori.wall:0;
  if(id==='ori'){const o=native.c23.ori;Object.assign(p,{gliding:o.gliding,climbing:o.clinging,energy:o.energy,nativePose:o.pose,bashing:!!o.bash});}
  if(id==='sonic'){const s=native.c23.sonic;Object.assign(p,{rings:s.rings,rolling:s.spin||s.rolling,spinCharge:s.charge,nativePose:s.pose});}
  if(castle)p.upgradeTier=rf07UpgradeTier(native.c23[id].upgradeTier);
  if(id==='tank'){p.dir=native.r12.tank.dir;if(!p.swimming)p.grounded=true;}
  return{hp:p.hp,maxHealth,dead,native:true};
 }
 function create(character,spawn){
  // Native controllers and the common finish motor share one body. Seed its
  // complete motion state before applying the original controller's body;
  // airborne flag/castle transitions must never read missing clocks or jumps.
  dead=false;previousInput={};const p=Object.assign(
   E04Modules.createCharacterMotor().create(character,spawn),createPlayer(spawn.x,spawn.y));
  Object.assign(p,{hero:character.heroId||id,motionId:id,attackId:id,renderId:id,native:true,maxHealth,hp:maxHealth,spinTicks:0,
   w:id==='tank'?12:id==='ryu'?12:castle?9:10,h:id==='bill'?30:id==='megaman'?24:id==='ryu'?26:id==='tank'?12:14});
  current=p;summary(p);return p;
 }
 const roomKeys=['mixShots','enemyShots','particles','floaters','items','shots','looseCoins','r06Effects','r07DefeatFx'];
 const ninjaRoomKeys=['foes','projectiles','drops','fx','dogAmbushes'];
 const oriRoomKeys=['bolts','orbs','fx','dashTrail'];
 function saveRoom(){if(!lastRoom)return;rooms.set(lastRoom,{arrays:Object.fromEntries(roomKeys.map(k=>[k,native[k]])),ninja:Object.fromEntries(ninjaRoomKeys.map(k=>[k,native.ninja[k]])),ori:Object.fromEntries(oriRoomKeys.map(k=>[k,native.c23.ori[k]])),loose:native.c23.sonic.loose,trail:native.c23.sonic.trail});}
 function resetCommands(){
  previousInput={};native.mixCharge=0;native.mixHeld=false;native.mixCool=0;native.mixCrouch=false;
  native.billDropRow=null;native.billDropCollision=false;native.billDownJumpHeld=false;native.billAimDown=false;
  native.jumpBuffer=0;native.jumpHeldPrev=false;native.runHeldPrev=false;
  for(const k of ['wall','wallLock','wallFrom','attack','cool','hit','coyote','buffer','spin','throwPose'])native.ninja[k]=0;
  for(const k of ['jumpHeld','attackHeld','specialHeld','cycleHeld'])native.ninja[k]=false;
  native.r12.tank.fireBuffer=0;native.r12.tank.cool=0;
  if(castle){const o=native.c23.ori;Object.assign(o,{bash:null,bashLock:false,charge:0,attackAge:0,lightAim:null,lightHold:0,dash:0,stomp:0,boost:0,wall:0,wallLock:0,prev:{}});
   o.rf08=null;Object.assign(native.c23.sonic,{charge:0,rolling:false,spin:false,dash:0,homing:null,wall:0,wallLock:0,electricUsed:false,prev:{},rf08Trail:[],rf08Pickup:null,rf08Tick:-1});}
  for(const v of [...voices])if(v.key==='mega_charge_start')stopVoice(v);
 }
 function prepareRoom(w){
  saveRoom();resetCommands();world=w;lastRoom=w.roomId;
  if(current?.mainlineWater)E04Modules.resetMainlineWater(current);
  if(rooms.has(lastRoom)){const cached=rooms.get(lastRoom);Object.assign(native,cached.arrays);Object.assign(native.ninja,cached.ninja);Object.assign(native.c23.ori,cached.ori);
   // A room owns enemy/drop progress, never an old attack or its last pixels.
   // Resuming a cached room must not resurrect airborne shots or hit debris.
   for(const k of roomKeys)if(k!=='items')native[k]=[];
   native.ninja.foes=w.enemies.filter(e=>e.nativeOwner===id&&!e.dead);native.ninja.projectiles=[];native.ninja.fx=[];
   for(const k of oriRoomKeys)native.c23.ori[k]=[];
   native.c23.sonic.loose=[];native.c23.sonic.trail=[];return;}
  for(const k of roomKeys)native[k]=[];for(const k of ninjaRoomKeys)native.ninja[k]=[];for(const k of oriRoomKeys)native.c23.ori[k]=[];native.c23.sonic.loose=[];native.c23.sonic.trail=[];
  if(classic||relay){
   if(!enemyTemplates)enemyTemplates=rf04Scope({hero:id},()=>classic?rf04Native.buildLevel().enemies:rf04Native.relayEnemyLayer('underground'));
   const templates=w.nativeEnemiesOnly?enemyTemplates.filter(t=>!t.franchise?.startsWith('mario-')&&!['goomba','koopa'].includes(t.kind)):enemyTemplates;
   let index=0;
   for(let i=0;i<w.enemies.length;i++){
    const q=w.enemies[i];
    if(q.nativeOwner==='foe-port'){
     const definition=w.enemyDefinition?w.enemyDefinition(q):E04Modules.enemyDefinition(q);
     if(definition.owner!=='foe-port')throw new TypeError('Native template source owner mismatch');
     continue;
    }
    if(/bowser|piranha|podoboo|fire|lakitu|bullet/i.test(q.type||''))continue;
    if(E04Modules.isMainlineWater(w)&&/blooper|cheep/i.test(q.type||''))continue;
    let t=q.nativeTemplate?templates.find(t=>t.franchise===q.nativeTemplate||t.kind===q.nativeTemplate):templates[index++%templates.length];
    if(!t){if(q.nativeTemplate)throw new Error('Unregistered native enemy template '+q.nativeTemplate);continue;}
    const sourceMario=t.franchise?.startsWith('mario-')||['goomba','koopa'].includes(t.kind);
    if(sourceMario)continue; // Original creatures have one physics/animation/death owner.
    const flying=t=>/hawk|bat/.test(t.kind||'')||/pipi|ufo|heli|shield/.test(t.franchise||'');
    const fits=t=>{const floor=q.y+q.h,y=flying(t)?Math.max(50,floor-65):floor-t.h;
     const body={x:q.x-(flying(t)?40:0),y:y-(flying(t)?16:0),w:t.w+(flying(t)?80:0),h:t.h+(flying(t)?32:0)};
     return body.x>=0&&body.x+body.w<=w.width&&!(w.solids||[]).some(g=>!g.hidden&&g.collision==='solid'&&overlap(body,g));};
    if(!fits(t)){
     // Named authored enemies are a content contract. Automatic replacement
     // is only for anonymous legacy slots; never hide a bad authored spawn.
     if(q.nativeTemplate)throw new Error('Invalid placement for native enemy '+q.nativeTemplate+': '+q.id);
     t=templates.find(t=>!flying(t)&&!t.franchise?.startsWith('mario-')&&!['goomba','koopa'].includes(t.kind)&&fits(t));if(!t){if(w.nativeEnemiesOnly)throw new Error('Native enemy has no valid placement: '+q.id);continue;}
    }
    // The native Tank list also contains two Mario creatures. Those slots use
    // the authored Mario entity and the stage's ground physics/death contract.
    if(id==='tank'&&t.kind!=='tank')continue;
    const e=structuredClone(t),floor=q.y+q.h;
    Object.assign(e,{id:q.id,uid:i,nativeOwner:id,x:q.x,y:floor-e.h,homeX:q.x,ox:q.x,oy:floor-e.h,baseY:floor-65,dead:classic?0:false,remove:false,active:false,anim:0,age:0});
    if(/hawk|bat/.test(e.kind||'')||/pipi|ufo|heli|shield/.test(e.franchise||''))e.y=Math.max(50,floor-65);
    if(id==='tank'){e.y=clamp(e.y,50,194-e.h);e.bonus??=i%4===1;}
    e.ox=e.x;e.oy=e.y;w.enemies[i]=e;
   }
   native.ninja.foes=w.enemies.filter(e=>e.nativeOwner===id);native.ninja.projectiles=[];native.mixShots=[];native.enemyShots=[];
  }
  if(id==='ryu')native.ninja.dogAmbushes=E04Modules.createRyuDogAmbushPlan(w);
  saveRoom();
 }
 function controls(raw){const v={...raw,left:raw.x<0,right:raw.x>0,horizontal:Math.sign(raw.x||0),run:!!(raw.attack||raw.run),special:!!(raw.special||raw.ability),
  cycle:!!raw.cycle,attack:!!raw.attack,climb:!!(raw.climb||raw.up),glide:!!raw.glide,bash:!!(raw.bash||raw.ability),dash:!!raw.dash,light:!!raw.light};
  for(const k of ['jump','run','special','cycle'])v[k+'Pressed']=E04Modules.inputEdge(raw,k+'Pressed',k==='run'?['attackPressed']:k==='special'?['abilityPressed']:k==='jump'?['jumpEdge']:[],()=>!!v[k]&&!previousInput[k]);
  if(id==='tank')v.moveDir=v.up?3:v.down?1:v.left?2:v.right?0:null;
  previousInput={...v};return v;
 }
 function step(p,raw,w){
  const v=controls(raw);world=w;current=p;if(lastRoom!==w.roomId)prepareRoom(w);
  const water=E04Modules.isMainlineWater(w);
  if(p.weapon&&id==='bill')native.billWeapon=p.weapon;
  if(id==='megaman')native.mixTier=clamp(p.power||0,0,2);
  if(id==='tank'){native.r12.tank.power=clamp(p.power||0,0,3);if(native.r12.rankFlash>0)native.r12.rankFlash--;}
  p.headHit=null;
  if(!water&&id!=='tank'&&p.grounded&&p.support){const q=w.solids.find(q=>q.id===p.support);if(q){p.x+=q.dx||0;p.y+=q.dy||0;}}
  const starBefore=p.star;
  const run=v=>{
  withNative(p,w,()=>{
   if(id==='bill')rf07BillPlayer(v);
   else if(classic)rf04Native.player(v);
   else if(id==='ryu'){
    rf09CycleRyuEquipment(ninja,v);
    if(native.ninja.attackMode&&native.ninja.attackMode!=='blade'&&v.run&&native.ninja.cool<=1)v.runPressed=true;
    const railSerial=p.ryuCeilingRail?.serial||0;
    r04TickInput=v;rf04Native.ninjaPlayer(v);
    if((p.ryuCeilingRail?.serial||0)>railSerial)w.reportObjective('roof-rail',p.ryuCeilingRail.serial);
    if(ninja.attackMode&&ninja.attackMode!=='blade')ninja.attackMode=ninja.weapon;
   }
   else if(id==='tank'){
    const beforeY=p.y;r04TickInput=v;tankRoute.player(v);
    if(v.up){const head=w.solids.filter(q=>q.hidden&&q.collision==='solid'&&p.x+p.w>q.x&&p.x<q.x+q.w&&beforeY>=q.y+q.h-.01&&p.y<q.y+q.h).sort((a,b)=>b.y+b.h-a.y-a.h)[0];
     if(head){p.y=head.y+head.h;p.vy=0;p.headHit=head.id;}}
   }
   else{
    const mouse={...o24Mouse};try{if(id==='ori'){v.bashPointer=raw.pointer?.active?{active:true,x:raw.pointer.x+(raw.pointer.space==='viewport'?(w.camera||0):0),y:raw.pointer.y+(raw.pointer.space==='viewport'?(w.cameraY||0):0)}:null;o24Mouse.x=(raw.pointer?.x||0)-(raw.pointer?.space==='viewport'?0:w.camera||0);o24Mouse.y=raw.pointer?.y||0;o24Mouse.valid=!!raw.pointer?.active&&!v.left&&!v.right&&!v.up&&!v.down;o24Mouse.bash=!!raw.pointer?.bash;}
     if(id==='ori'&&c23.ori.bash)o32BashTick(v);else rf04Native.castlePlayer(v);
    }finally{Object.assign(o24Mouse,mouse);}
   }
  },{phaseActor:'player'});
  p.star=starBefore;summary(p);return summary(p);
  };
  return water||p.mainlineWater?E04Modules.runMainlineWater(p,v,w,run,{alive:()=>!dead&&!p.dying}):run(v);
 }
 // Both actor movement and later enemy movement resolve the same contact.
 // The stage owns the contact order; the actor owns its attack state and the
 // enemy declaration owns whether source-style contact attacks are allowed.
 function enemyContact(p,e,context,w){
  if(id!=='sonic'||e.dead)return false;
  const s=native.c23.sonic,definition=context.definition||(w.enemyDefinition?w.enemyDefinition(e):E04Modules.enemyDefinition(e));
  if(!s.spin||s.hurt||definition.origin==='mario'||definition.contact.stomp!=='source'||definition.movement.collision==='projectile')return false;
  const damageContact=definition.contact.attack==='damage';
  if(s.homing?.ref===e){const accepted=withNative(p,w,()=>s33HitTarget(c23.sonic.homing));return accepted===true||damageContact;}
  if(damageContact){
   // A source may decline a hit while flashing. The spin remains protective;
   // only an accepted impact can change velocity or commit attack feedback.
   const accepted=w.damageEnemy(e,definition.contact.damage,{id:'sonic-contact-'+w.tick+'-'+e.id,kind:'spin',owner:'sonic'});
   if(accepted===true){p.vy=-4.6;p.grounded=false;}
   return true;
  }
  if(w.kill(e)!==true)return false;
  p.vy=-4.6;p.grounded=false;return true;
 }
 function combat(p,raw,w){
  if(id==='ryu')w.enemies.push(...E04Modules.stepRyuDogAmbushes(native.ninja.dogAmbushes||[],p,w));
  withNative(p,w,()=>{
   if(classic){rf04Native.entities();updateParticles();}
   else if(relay){native.ninja.foes=w.enemies.filter(e=>e.nativeOwner===id);ninja.foes=native.ninja.foes;
    if(id==='tank')r12TankEnemies();else{rf04Native.ninjaEnemies();if(ninja.spin>0)ninja.spin--;}
    rf04Native.relayCombat();r06FxTick();r06MarkEnemies();r07TickDefeat();
    const common=w.enemies.filter(e=>!e.nativeOwner&&!e.dead),hit=(e,n,weapon='blade')=>w.damageEnemy(e,n,{kind:id==='tank'?'tank-shell':'ninja-weapon',weapon});
    if(id==='ryu'&&ninja.attack>=3&&ninja.attack<=12)for(const e of common)if(!ninja.hitIds.has('e'+e.id)&&r07SwordBoxes().some(b=>overlap(b,e))){ninja.hitIds.add('e'+e.id);hit(e,1);}
    if(id==='ryu'&&ninja.spin>0)for(const e of common)if(!ninja.spinHit.has('e'+e.id)&&overlap({x:p.x-16,y:p.y-9,w:44,h:44},e)){ninja.spinHit.add('e'+e.id);hit(e,2,'spin');}
    for(const s of ninja.projectiles)if(s.friendly&&s.life>0)for(const e of common)if(!e.dead&&!s.hit?.has(e.id)&&overlap(s,e)){s.hit?.add(e.id);hit(e,s.kind==='flame'?2:1,s.kind);if(!['windmill','flame'].includes(s.kind))s.life=0;break;}
    // Let the campaign own collection, common lives and the one protected hit.
    // Native carrier/lantern drops retain their original item identity and art.
    for(const d of ninja.drops){
     const type=id==='ryu'&&['spirit','health'].includes(d.type)?supply(p,{index:supplyIndex+w.items.filter(i=>i.nativeActor===id&&!i.dead).length}).nativeType:d.type;
     w.items.push({...d,type,kind:type==='life'?'life':'native-supply',nativeType:type,nativeActor:id,age:0,vx:type==='life'?.75:0,vy:Number.isFinite(d.vy)?d.vy:0,stationary:type!=='life',floating:id==='tank'&&type!=='life'});
    }
    ninja.drops=[];
    for(const d of w.items)if(d.fromCarrier&&!d.dead&&!d.emerge&&d.ttl>0&&!--d.ttl)d.dead=true;
   }
   else if(id==='ori'){if(!c23.ori.bash)rf04Native.castleWorld();}
   else{
    // RF02 loose-ring physics without its fixed castle checkpoints/ring rows.
    const s=c23.sonic,px=p.x+4.5,py=p.y+7;
    for(const r of s.loose){r.age++;r.life--;r.vy+=.12;const body={x:r.x-2,y:r.y-2,w:4,h:4,vx:r.vx,vy:r.vy};move(body,r.vx,r.vy);r.x=body.x+2;r.y=body.y+2;if(body.grounded)r.vy=-Math.abs(r.vy)*.7;if(r.age>30&&Math.hypot(r.x-px,r.y-py)<11){s.rings=Math.min(999,s.rings+1);r.life=0;s33Sound('ring');}}
    s.loose=s.loose.filter(r=>r.life>0&&r.x>=0&&r.x<w.width&&r.y<w.height+30);s.trail=s.trail.filter(t=>--t.life>0);
    for(const e of w.enemies)if(!e.dead&&e.hp<=0)w.kill(e);
   for(const e of w.enemies)if(!e.dead&&overlap(p,e))enemyContact(p,e,{definition:w.enemyDefinition?w.enemyDefinition(e):E04Modules.enemyDefinition(e)},w);
   }
  },{phaseActor:'combat'});
  // Preserve native numeric death counters until their own renderer retires them.
  for(let i=w.enemies.length-1;i>=0;i--){const e=w.enemies[i];if(e.nativeOwner===id&&(e.remove||relay&&e.dead))w.enemies.splice(i,1);}
  if(tracing)for(const [key,r]of retiring)if(r.fx.every(f=>!native.r07DefeatFx.includes(f)&&!native.r06Effects.includes(f))){trace('gone',r.enemy,{hitId:r.hitId});retiring.delete(key);}
  if(classic){for(const s of native.mixShots){if(s.life<=0||s.delay>0)continue;for(const e of w.enemies)if(!e.dead&&overlap(s,e)&&(!e.nativeOwner||e.nativeOwner==='foe-port'&&(w.enemyDefinition?w.enemyDefinition(e):E04Modules.enemyDefinition(e)).owner==='foe-port')){const uid='shared:'+e.id;if(s.hitIds.includes(uid))continue;s.hitIds.push(uid);w.damageEnemy(e,s.damage,{kind:s.defeatCause||id+'-shot',weapon:s.family});if(!s.piercing)s.life=0;break;}}}
  saveRoom();
  return summary(p);
 }
 function defeatEnemy(p,e,w,{flat=false}={}){
  if(e.dead||e.remove||e.nativeOwner!==id)return false;
  withNative(p,w,()=>{if(classic)baseEnemyKill(e,!flat,0,true);else if(relay)killNative(e,true);});saveRoom();return true;
 }
 function damageEnemy(p,e,amount,hit,w){if(e.dead||e.remove)return false;withNative(p,w,()=>{if(relay)hitEnemy(e,amount);else if(classic)mixHitEnemy(e,{damage:amount,tier:0,charged:false,vx:1,family:hit.weapon,defeatCause:hit.kind});});saveRoom();return true;}
 function isUpgraded(p=current){return id==='bill'?native.billWeapon!=='N':id==='megaman'?native.mixTier>0:id==='ryu'?(native.ninja.attackMode||'blade')!=='blade'||native.ninja.unlocked?.some(k=>k!=='shuriken')===true:id==='tank'?native.r12.tank.power>0:id==='ori'||id==='sonic'?native.c23[id].upgradeTier>0:p.power>0;}
 function downgrade(p){
  native.mixCharge=0;native.mixHeld=false;native.mixCool=0;hurtCue=false;
  if(id==='bill')native.billWeapon='N';
  else if(id==='megaman'){native.mixTier=0;native.mixShots=[];}
  else if(id==='ryu')Object.assign(native.ninja,{weapon:'shuriken',unlocked:['shuriken'],attackMode:'blade',attack:0,spin:0,throwPose:0});
  else if(id==='tank')Object.assign(native.r12.tank,{power:0,shield:0});
  else if(id==='ori')Object.assign(native.c23.ori,{upgradeTier:0,charge:0,attackAge:0,lightHold:0,lightAim:null});
  else if(id==='sonic')Object.assign(native.c23.sonic,{upgradeTier:0,electricUsed:false,charge:0,dash:0,homing:null});
  p.power=0;summary(p);return true;
 }
 function hurt(p,source,w,{shielded=false}={}){
  if(!shielded){w.damage?.(source);return summary(p);}
  // Only the stage can spend protection or a life. Native health is private
  // feedback state. Timed immunity is checked through blocksDamage before
  // the shared stage decides whether to spend protection or a life.
  p.invuln=0;
  withNative(p,w,()=>{
   if(id==='megaman'){mixHp=3;rf04Native.damage(source);mixTier=0;mixShots=[];mixCharge=0;mixHeld=false;}
   else if(id==='ryu'){ninja.hp=16;rf04Native.ninjaHurt(source||{x:p.x+p.facing*20});ninja.weapon='shuriken';ninja.unlocked=['shuriken'];ninja.attackMode='blade';}
   else if(id==='ori'){c23.ori.upgradeTier=0;c23.ori.hp=O24_MAX_HP;rf04Native.castleHurt(source?.type||'contact');}
   else if(id==='sonic'){c23.sonic.upgradeTier=0;c23.sonic.electricUsed=false;rf04Native.sonicHurtFeedback(source?.type||'contact',{shield:true});}
   else if(id==='tank'){r12.tank.power=0;r12.tank.shield=0;r06Explosion(p.x+6,p.y+6,false);r06Sound('armorhit');}
   else{billWeapon='N';p.vx=-p.facing*1.65;p.vy=-1.9;oneShot('hurt');}
  },{feedback:true});
  hurtCue=true;p.invuln=120;return summary(p);
 }
 // Native scene health is owned by the scene, while this port supplies the
 // original recoil, ring scatter and hurt cue. Mega loses its weapon upgrade.
 function hurtNative(p,source,w){
  const rings=native.c23.sonic.rings;
  if(id==='sonic'&&rf07UpgradeTier(native.c23.sonic.upgradeTier)){
   // A native shield absorbs before the ring pool and uses source hurt feedback.
   hurt(p,source,w,{shielded:true});
   return {absorbed:true};
  }
  if(id==='sonic'&&!rings)return {absorbed:false};
  withNative(p,w,()=>{
   p.invuln=0;
   if(id==='megaman'){mixHp=28;rf04Native.damage(source);mixTier=0;mixShots=[];mixCharge=0;mixHeld=false;mixCool=0;}
   else if(id==='ori'){c23.ori.hp=O24_MAX_HP;rf04Native.castleHurt(source?.type||'contact');}
   else if(id==='sonic')rf04Native.castleHurt(source?.type||'contact');
  },{feedback:true});
  if(id==='megaman')summary(p);
  return {absorbed:id==='sonic'&&rings>0};
 }
 function supply(p,{content='',index=supplyIndex}={}){
  let nativeType;
  if(id==='bill'){const weapon=/^bill-[nmsfl]$/i.test(content)?content.slice(-1).toUpperCase():E04Modules.weaponReward({content,index,level:world?.levelLabel,current:p.weapon});return{kind:'bill-supply',weapon,nativeType:'bill-'+weapon};}
  if(id==='megaman')nativeType=native.mixTier?'weaponcore':'weaponenergy';
  else if(id==='ryu')nativeType=['windmill','flame','shuriken'][index%3];
  else if(id==='tank')nativeType='star';
  else if(id==='ori')nativeType=rf07UpgradeTier(native.c23.ori.upgradeTier)?'ori-cell':'ori-light';
  else nativeType=rf07UpgradeTier(native.c23.sonic.upgradeTier)?'lightning-shield':'plain-shield';
  return{kind:'native-supply',nativeType,nativeActor:id,...(id==='sonic'?{w:24,h:24}:{})};
 }
 function pickup(p,item,w){
  if(['star','life'].includes(item.kind))return false;
  let type=item.nativeType||supply(p,{content:item.weapon?'bill-'+item.weapon:'',index:supplyIndex}).nativeType;
  if(id==='ryu'&&['spirit','health'].includes(type))type=supply(p,{index:supplyIndex}).nativeType;
  supplyIndex++;
  withNative(p,w,()=>{
   if(classic){if(id==='megaman'&&type==='weaponcore')mixTier=Math.max(1,mixTier);rf04Native.transform({...item,type});}
   else if(id==='ryu'){rf04Native.relayGive(type);if(R12_WEAPONS[type])ninja.attackMode=type;}
   else if(id==='tank'){
    rf04Native.relayGive(type,{enemyEffect:w.enemyEffect});
   }
   else if(id==='ori'){const o=c23.ori;o.upgradeTier=Math.max(rf07UpgradeTier(o.upgradeTier),type==='ori-cell'?2:1);o.energy=O24_MAX_ENERGY;o24Sound('heal');o24FX(p.x+4.5,p.y+7,type==='ori-light'?'#ffe6a4':'#9cecf4',20,2);rf08OriPickup(o,type,p);w.addScore(600);}
   else if(id==='sonic'){const s=c23.sonic;s.upgradeTier=Math.max(rf07UpgradeTier(s.upgradeTier),type==='lightning-shield'?2:1);s.electricUsed=false;s33Sound(type==='lightning-shield'?'electricShield':'plainShield');rf08SonicPickup(s,type,p);w.addScore(100);}
  });
  // The shared stage owns timed protection; transfer this original pickup
  // window explicitly instead of maintaining a second native countdown.
  if(classic)w.contactGrace?.(45);
  summary(p);return true;
 }
 function coin(p){if(id==='sonic'){withNative(p,world,()=>{c23.sonic.rings++;s33Sound('ring');});summary(p);}}
 function reward(p,reward,w){withNative(p,w,()=>{
  if(id==='bill'&&reward?.kind==='bill-weapon')billWeapon=reward.weapon;
  if(id==='tank'&&reward?.kind==='max-power-shield'){r12.tank.power=3;r12.tank.shield=600;}
  if(id==='ryu'&&reward?.kind==='jump-and-slash'){if(!ninja.unlocked.includes('spin'))ninja.unlocked.push('spin');ninja.hp=16;ninja.spirit=Math.max(20,ninja.spirit);}
 });summary(p);}
 function reflectedHit(p,target,w){withNative(p,w,()=>{c23.bowser=Object.assign(target,{alive:true,active:true});o24BossDamage(4);});}
 function beginDeath(p,w){dead=true;native.mixShots=[];native.enemyShots=[];native.ninja.projectiles=[];native.mixCharge=0;native.mixHeld=false;
  native.mixDeathOrigin={x:p.x,y:p.y+p.h-15,foot:p.y+p.h,grounded:p.grounded};
  if(id==='bill'){p.billDeathVelocity256=-640;p.billDeathFraction=0;p.billDeathLanded=false;p.vx=-p.facing;p.vy=-2.5;p.grounded=false;}
  if(relay){native.ninja.attack=native.ninja.wall=native.ninja.spin=native.ninja.throwPose=0;p.vx=p.vy=0;}
  if(id==='tank')withNative(p,w,()=>r06Explosion(p.x+6,p.y+6));
  if(castle){native.c23[id].upgradeTier=0;native.c23.ori.bash=null;native.c23.ori.charge=0;native.c23.sonic.rings=0;}
 }
 function deathStep(p,age,w){p.deathAge=age;
  if(id==='bill'){
   if(p.billDeathLanded)return;
   p.billDeathVelocity256=(p.billDeathVelocity256??-640)+35;
   const n=(p.billDeathFraction||0)+(p.billDeathVelocity256&255),dy=Math.floor(p.billDeathVelocity256/256)+(n>>>8);p.billDeathFraction=n&255;
   p.vx=-p.facing;p.vy=p.billDeathVelocity256/256;world=w;move(p,p.vx,dy,true);
   if(p.grounded&&dy>=0){p.billDeathLanded=true;p.vx=p.vy=0;}return;
  }
  if(id==='tank'){withNative(p,w,()=>r06FxTick());return;}
  if(id==='megaman')return;
  if(id==='ryu'){if(age>14){p.vy=Math.min(3.5,p.vy+.2);p.y+=p.vy;}return;}
  if(age>(castle?14:24)){p.y+=p.vy;p.vy+=castle?.19:.22;}
 }
 function snapshot(){return{version:1,actor:id,hp:current?.hp,maxHealth,mixTier:native.mixTier,weapon:id==='bill'?native.billWeapon:id==='ryu'?native.ninja.weapon:null,
  nativeVitals:id==='ryu'?native.ninja.nativeVitals:sceneVitals||undefined,spirit:id==='ryu'?native.ninja.spirit:undefined,unlocked:id==='ryu'?[...native.ninja.unlocked]:undefined,attackMode:id==='ryu'?(native.ninja.attackMode||'blade'):undefined,
  power:id==='tank'?native.r12.tank.power:undefined,energy:id==='ori'?native.c23.ori.energy:undefined,
  rings:id==='sonic'?native.c23.sonic.rings:undefined,upgradeTier:castle?rf07UpgradeTier(native.c23[id].upgradeTier):undefined,supplyIndex};}
 function restore(p,data){if(!data||data.version!==1||data.actor!==id)return false;
   sceneVitals=data.nativeVitals?structuredClone(data.nativeVitals):null;
  const n=(v,lo,hi,def)=>Number.isFinite(v)?clamp(v,lo,hi):def;
  native.mixHp=n(data.hp,1,3,3);native.mixTier=id==='megaman'?E04Modules.megamanWeaponTier(data.mixTier):n(data.mixTier,0,2,0);
  if(id==='bill'&&Object.hasOwn(BILL_WEAPON_NAMES,data.weapon))native.billWeapon=data.weapon;
  if(id==='ryu'){native.ninja.hp=n(data.hp,1,16,16);rf09RestoreRyuEquipment(native.ninja,data);}
  if(id==='tank')native.r12.tank.power=n(data.power,0,3,0);
  if(id==='ori'){native.c23.ori.hp=n(data.hp,1,O24_MAX_HP,O24_MAX_HP);native.c23.ori.energy=n(data.energy,0,O24_MAX_ENERGY,O24_MAX_ENERGY);}
  if(id==='sonic')native.c23.sonic.rings=n(data.rings,0,999,0);
  if(castle)native.c23[id].upgradeTier=rf07UpgradeTier(data.upgradeTier);
  supplyIndex=n(data.supplyIndex,0,1000,0);summary(p);return true;
 }
 function renderWorld(g,v){
  if(!current||!world)return;
  withNative(current,{...world,tick:v.tick,camera:v.cam},()=>{
   if(classic){
    for(const e of world.enemies)if(e.nativeOwner===id&&!e.remove)rf04Native.drawEnemy(e);
    for(const s of mixShots){if(s.delay>0||s.life<=0)continue;if(id==='bill'){drawBillShot(s);continue;}
     drawMegamanShot(s);
    }
    for(const s of enemyShots){if(s.kind==='grenade-blast'){drawEnemyGrenadeBlast(g,s);}else if(s.kind==='grenade'){const im=enemyImages[['contra-a6','contra-a8','contra-a9'][Math.floor(s.age/8)%3]];if(im)g.drawImage(im,s.x+(s.w-im.width)/2,s.y+(s.h-im.height)/2);}else if(s.kind==='egg')enemyCrop('pipi-egg',[0,0,32,32],s.x-8,s.y-10);else{rect(s.x,s.y,4,4,'#fff5df');rect(s.x+1,s.y+1,2,2,'#df3020');}}
    for(const p of particles){if(p.kind==='coin')drawCoin(p.x,p.y,frame,true);else if(p.kind==='debris')sprite('debris',p.x,p.y,Math.floor(frame/4)%2===1,Math.floor(frame/6)%2===1);else rect(p.x,p.y,p.life>10?2:1,p.life>10?2:1,p.life%3?'#ffffff':'#fc9838');}
    for(const f of floaters)text(f.text,f.x,f.y,'#ffffff',1,true);
   }else if(relay){
    for(const e of world.enemies)if(e.nativeOwner===id&&!e.dead&&!e.remove)r12DrawEnemy(e);
    for(const d of ninja.drops)r12DrawDrop(d);
    for(const s of ninja.projectiles){if(s.life<=0)continue;const x=s.x,y=s.y;
     if(s.kind==='shell'){rect(x,y,4,4,s.friendly?'#ffeeae':'#ff9b7b');rect(x-s.vx*.8,y-s.vy*.8,2,2,'#ad8f67');}
     else if(s.kind==='flame'){for(let i=0;i<3;i++)rect(x-i*s.vx*2,y-i*s.vy*2,8,8,['#fff1ad','#fda055','#d96349'][i]);}
     else{g.save();g.translate(x+4,y+4);g.rotate(frame*.4);const size=s.kind==='windmill'?8:5;rect(-size,-1,size*2,2,s.friendly?'#c4eef4':'#e5af93');rect(-1,-size,2,size*2,s.friendly?'#c4eef4':'#e5af93');g.restore();}}
    r05DrawParticles();
    for(const f of ninja.fx)rect(f.x,f.y,2,2,f.color);
    const explosion=R12_SPRITES['tank-explosion06'];if(explosion)for(const e of r06Effects){const seq=[0,1,2,3,2,1],i=seq[Math.min(5,Math.floor(e.age*6/e.life))],size=e.big?40:20;g.drawImage(explosion,i*64,0,64,64,Math.round(e.x-size/2),Math.round(e.y-size/2),size,size);}
    for(const f of r07DefeatFx){if(f.age<0)continue;if(f.kind==='mario'){const im=classicSprite(f.sprite,f.under?'under':'normal');sprite(f.sprite,f.x-im.width/2,f.y-im.height/2,false,true,f.under?'under':'normal');}else{const im=R12_SPRITES['ng-explosion07'];if(im)g.drawImage(im,Math.min(2,Math.floor(f.age/6))*48,0,48,48,Math.round(f.x-16),Math.round(f.y-16),32,32);}}
    if(id==='ryu'&&ninja.spin>0){g.strokeStyle='#d7e6fc';g.lineWidth=2;g.beginPath();g.arc(current.x+6,current.y+13,20,frame*.5,frame*.5+4.9);g.stroke();}
   }else if(id==='ori'){
    const o=c23.ori;
    for(const f of o.fx){g.save();g.globalAlpha=f.life/f.max;o24Ellipse(g,f.x,f.y,f.r,f.r,f.color);g.restore();}
    for(const b of o.bolts)rf093DrawOriBolt(g,b,o.upgradeTier);
    for(const b of o.orbs)o24Glow(g,b.x,b.y,8,'#d5f8ff',.8);
    for(const t of o.dashTrail)rf04Native.ori(g,t.x+4.5,t.y+14,'dash',0,t.face,t.life*.016,false);
    const s=o24DrawSein(g,current.x+4.5,current.y+current.h,current.facing,v.tick);
    if(o.charge>17&&o.energy>0)rf093DrawOriCharge(g,s.x,s.y,4+(o.charge-17)*.2,.5);
    if(o.bash)o32DrawBash({worldSpace:true});
    rf08DrawOriFeedback(g,current,o,v.tick);
   }else{
    for(const r of c23.sonic.loose)if(r.life>60||frame%8<4)s33DrawRing(g,r.x,r.y,frame);
    for(const t of c23.sonic.trail)s33Sprite(g,t.x+4.5,t.y+14,'jump',c23.sonic.anim,current.facing,t.life*.012);
    rf08DrawSonicFeedback(g,current,c23.sonic,v.tick);
   }
  },{render:true});
 }
 function drawPlayerPort(g,p,tick,v){
  if(!current||!world)return null;
  const motion=p.scriptedMotion,foot=p.y+p.h,transport=motion&&!v.finish;
  const finish=v.finish||(transport?{phase:motion.moving&&Math.abs(motion.dx)>1e-6?'walk':'idle',age:motion.animation}:null),slide=finish?.phase==='slide';
  const moving=motion?motion.moving:Math.abs(p.vx)>.1,walk=finish?.phase==='walk'&&moving,distance=motion?.distance||0,animation=motion?.animation||0;
  let pose='idle',frameName='',grip=null;
  const old={invuln:p.invuln,crouch:p.crouch,facing:p.facing,vx:p.vx,vy:p.vy,anim:p.anim},oldFlagPhase=flagPhase,oldFlagTimer=flagTimer;
  if(p.star||finish)p.invuln=0;
  if(finish){p.crouch=false;if(motion?.x)p.facing=motion.x;flagPhase=0;flagTimer=animation;if(motion){p.vx=motion.dx;p.vy=motion.dy;p.anim=distance;}}
  try{
  withNative(p,{...world,tick},()=>{
   if(classic){if(finish){mixCool=mixCharge=0;mixCrouch=mixAim=false;billAimX=p.facing;billAimY=0;billFireFrames=0;billMotion=distance/20;billAirTicks=animation;}
    rf04Native.drawPlayer();pose=slide?'climb':finish?(walk?(p.grounded?'run':'air'):'idle'):id==='bill'?!p.grounded?'somersault':p.crouch?'prone':mixAim?'aim':Math.abs(p.vx)>.1?'run':'idle':mixCool?'shoot':'run';frameName=id==='bill'?'native-bill-'+billMotion:'native-mega-'+mixCharge;}
   else if(id==='ryu'){pose=slide?'wall':finish?(walk?(p.grounded?'run':'air'):'idle'):p.dying||ninja.hit?'hurt':ninja.attack?(p.crouch?'crouchSlash':'slash'):ninja.wall?'wall':p.crouch?'crouch':!p.grounded?'air':Math.abs(p.vx)>.1?'run':'idle';if(slide)grip=E04Modules.alignFlagGrip(p,v.finish.poleX,{offsetX:16});const drawX=p.x+(grip?.dx||0);r12DrawRyu(g,drawX,foot,p.facing,pose,finish?distance*2:p.grounded?p.anim*2:tick);frameName='native-ryu-'+pose;}
   else if(id==='tank'){const dir=finish?(slide?1:motion&&Math.abs(motion.dy)>Math.abs(motion.dx)?motion.y>0?1:3:p.facing<0?2:0):r12.tank.dir;if(!p.dying){r12DrawTank(g,p.x,p.y,dir,false,finish?distance/1.4:r12.tank.track);if(!finish)r10DrawShield(g,p.x,p.y);}pose=p.dying?'explode':slide?'descend':finish&&!moving?'idle':'drive';frameName='native-tank-'+dir;}
   else if(id==='ori'){pose=slide?'climb':finish?(walk?(p.grounded?'run':'fall'):'idle'):p.dying?'death':c23.ori.pose;
    const actor=c23.ori,priorClock=A39.clock.get(actor);
    if(finish)A39.clock.set(actor,{...(priorClock||{}),pose,age:animation,frame:a39Frame(pose,animation,{run:distance/10.8,spin:animation*.25})});
    try{const row=slide?a39Frame('climb',animation,{run:distance/10.8,spin:animation*.25}).row:0;if(slide)grip=E04Modules.alignFlagGrip(p,v.finish.poleX,{offsetX:[3,7].includes(row)?12.5:13.5});const center=p.x+4.5+(grip?.dx||0);rf04Native.ori(g,center,foot,pose,finish?distance*4/10.8:tick,p.facing);}finally{if(finish){if(priorClock)A39.clock.set(actor,priorClock);else A39.clock.delete(actor);}}
    frameName='native-ori-'+pose;}
   else{pose=slide?'push':finish?(walk?(p.grounded?'jog':'jump'):'idle'):p.dying?'death':c23.sonic.pose;
    const tier=rf07UpgradeTier(c23.sonic.upgradeTier),shield=!finish&&!p.dying&&tier&&typeof rf07DrawSonicShield==='function';
    if(shield)rf07DrawSonicShield(g,p,tick,{tier,layer:'back'});
    s33Sprite(g,p.x+4.5,foot,pose,finish?distance*.09:c23.sonic.anim,p.facing);
    if(shield)rf07DrawSonicShield(g,p,tick,{tier,layer:'front'});frameName='native-sonic-'+pose;}
  },{render:true,phase:slide&&classic?'flag':null});
  }finally{Object.assign(p,old);flagPhase=oldFlagPhase;flagTimer=oldFlagTimer;}
  return{hero:p.hero,pose,frame:frameName,asset:'RF02/native/'+id,drawn:true,...(grip?{grip}:{} )};
 }
 function audioPort(playing,phase=null){if(!current||!world)return;withNative(current,world,()=>rf04Native.audio(),{playing,phase});}
 function drawCoin(g,item,tick){
  if(id!=='sonic'||item?.kind!=='coin'||!current||!world)return false;
  return withNative(current,{...world,tick},()=>{s33DrawRing(g,item.x+item.w/2,item.y+item.h/2,tick);return true;},{render:true});
 }
 function drawPickup(g,item,tick){
  if(!current||!world)return false;
  return withNative(current,{...world,tick},()=>{

   if(!['mushroom','flower','bill-supply','native-supply'].includes(item.kind))return false;
   const type=item.nativeType||supply(current,{content:item.weapon?'bill-'+item.weapon:'',index:supplyIndex}).nativeType;
   if(classic)rf04Native.drawItem({...item,type});
   else if(relay)r12DrawDrop({...item,type});
   else if(id==='sonic'){if(typeof rf07DrawSonicSupply!=='function')return false;rf07DrawSonicSupply(g,{...item,nativeType:type},tick);}
   else rf07DrawOriSupply(g,item.x+item.w/2,item.y+item.h/2,type,tick);
   return true;
  },{render:true});
 }
 function drawHud(g,v,width,drawText){withNative(current,world,()=>{
  const label=id==='ryu'?(ninja.attackMode&&ninja.attackMode!=='blade'?R12_WEAPONS[ninja.weapon]?.hud||'STAR':'SWORD'):id==='tank'?'P'+(r12.tank.power+1):id==='sonic'?'RINGS '+String(c23.sonic.rings).padStart(3,'0')+' P'+rf07UpgradeTier(c23.sonic.upgradeTier):id==='bill'?billWeapon:id==='ori'?'MP '+c23.ori.energy+' FIRE '+(1+rf07UpgradeTier(c23.ori.upgradeTier)):id==='megaman'?'P'+(mixTier+1):'';
  if(drawText)drawText(g,label,24,4);else text(label,24,4,'#fff',1);
 },{render:true});}
 function sound(event){
  if(!current)return false;
  if(event==='hurt'&&hurtCue){hurtCue=false;return true;}
  if(event==='powerup')return true; // Every accepted native pickup owns exactly one native cue.
  if(event==='pickup'&&id==='sonic')return true;
  if(['jump','jump_super','attack'].includes(event))return true; // Native action emitted its own cue.
  if(!['hurt','death','powerup','flag','complete','world_clear'].includes(event))return false;
  withNative(current,world,()=>{
   if(id==='ryu')ninjaSound(event==='powerup'?'pickup':event==='complete'||event==='world_clear'?'flag':event);
   else if(id==='tank'){if(['flag','complete','world_clear'].includes(event))rf04Native.audio();if(event!=='flag')r06Sound(({death:'death',hurt:'death',powerup:'upgrade',complete:'result',world_clear:'result'})[event]);}
   else if(id==='ori')o24Sound(event==='powerup'?'heal':event==='flag'||event==='complete'||event==='world_clear'?'link':event);
   else if(id==='sonic')s33Sound(event==='powerup'?'checkpoint':event==='hurt'?'ringsLost':event==='flag'||event==='complete'||event==='world_clear'?'checkpoint':event);
   else if(id==='bill'&&event==='death')oneShot('bill_death');
   else oneShot(event==='powerup'?id==='bill'?'bill_pickup':'mega_energy':event==='hurt'?'mega_hurt':event==='complete'||event==='world_clear'?'clear':event);
  },{phase:['flag','complete','world_clear'].includes(event)?'flag':null});return true;
 }
  return Object.freeze({id,backtracking:!classic,consumeHitStop(){if(native.freeze>0){native.freeze--;return true;}return false;},blocksDamage:()=>id==='tank'&&native.r12.tank.shield>0,create,prepareRoom,step,combat,enemyContact,hurt,downgrade,isUpgraded,hurtNative,defeatEnemy,damageEnemy,supply,pickup,coin,reward,reflectedHit,beginDeath,deathStep,snapshot,restore,drawPlayer:drawPlayerPort,drawWorld:renderWorld,drawPickup,drawCoin,drawHud,audio:audioPort,sound,
  remapSceneX(p,bodyMapX,{privateMapX=bodyMapX}={}){
   const mapX=privateMapX;
   const visited=new Set();
   const move=q=>{if(!q||typeof q!=='object'||visited.has(q))return;visited.add(q);if(Number.isFinite(q.x))q.x=mapX(q.x,q);if(Number.isFinite(q.axisX))q.axisX=mapX(q.axisX,q);for(const k of ['tail','trail'])if(Array.isArray(q[k]))q[k].forEach(move);};
   for(const key of roomKeys)native[key]?.forEach(move);
   for(const key of oriRoomKeys)native.c23.ori[key]?.forEach(move);
   // Bash's live target reference belongs to Stage and has already moved.
   // Its cached aiming anchor and privately owned trajectory move once here.
   const b=native.c23.ori.bash;if(b){move(b);move(b.target);}
   native.ninja.projectiles?.forEach(move);native.ninja.fx?.forEach(move);
   native.c23.sonic.loose?.forEach(move);native.c23.sonic.trail?.forEach(move);
  },
  reset(){Object.assign(native,structuredClone(defaults));rooms.clear();retiring.clear();lastRoom=null;dead=false;previousInput={};supplyIndex=0;},
  pause(){previousInput={};native.mixCharge=0;native.mixHeld=false;withNative(current,world,()=>{stopEffects();if(id==='ori'){o32CancelBash('pause');Object.assign(c23.ori,{charge:0,attackAge:0,lightAim:null,lightHold:0,prev:{}});fx40ChargeSync();}if(id==='sonic'){c23.sonic.charge=0;c23.sonic.homing=null;c23.sonic.dash=0;}});audioPort(false);},resume(){previousInput={};},
  dispose(){withAudioOwner('actor:'+id,()=>stopEffects());audioPort(false);disposed=true;rooms.clear();if(id==='tank'){r06StopEngine();r08DetachCue(false);}if(id==='ori')o27Stop(true);if(id==='sonic')s33MusicStop(true);},
  diagnostics:()=>({id,health:current?.hp,dead,nativeCalls:true,ninja:{hp:native.ninja.hp,spirit:native.ninja.spirit,weapon:native.ninja.weapon,attackMode:native.ninja.attackMode||'blade',cool:native.ninja.cool,throwPose:native.ninja.throwPose,unlocked:[...native.ninja.unlocked],attackId:native.ninja.attackId},bill:{motion:native.billMotion,airTicks:native.billAirTicks,aimX:native.billAimX,aimY:native.billAimY,fireFrames:native.billFireFrames},tank:{...native.r12.tank,rankFlash:native.r12.rankFlash||0,playfield:native.r12.playfield},ori:{...native.c23.ori},sonic:{...native.c23.sonic},shots:[...native.mixShots,...native.ninja.projectiles],enemyShots:native.enemyShots,
   effects:{particles:native.particles,ninja:native.ninja.fx,defeat:native.r07DefeatFx,explosions:native.r06Effects},enemies:(world?.enemies||[]).filter(e=>e.nativeOwner===id),
   assets:{sonic:{loaded:!!s33Image.naturalWidth,width:s33Image.naturalWidth,height:s33Image.naturalHeight},ori:{loaded:A39.loaded,width:A39.image.naturalWidth,height:A39.image.naturalHeight}},animation:id==='ori'?A39.clock.get(native.c23.ori):null,events:events.map(e=>({...e}))})});
}
