/* Original Ori PC textures, shader alpha and ordered animation FrameGuids.
 * Provenance: docs/RF093_ORI_ORIGINAL_ASSETS.json. Native rooms use smooth
 * source art; Mario terrain and the other heroes retain their pixel pipeline. */
const rf093OriSource=@@E04:file:src/data/ori-original.json@@;
const rf093OriArt={};
for(const [key,uri] of Object.entries(rf093OriSource.images)){
 const im=new Image();im.src=uri;rf093OriArt[key]=im;mainlineAssetJobs.push(im.decode());
}
function rf093DrawOriSpitter(g,e){
 const dying=e.kind==='rf08-foe-death',state=dying?'death':e.foeState==='windup'?'charge':e.foeState==='recover'?'shoot':'idle';
 const a=rf093OriSource.animations[state],age=dying?e.age||0:e.foeStateAge??e.foeAge??0;
 const f=a.frames[a.loop?Math.floor(age*a.fps/60)%a.frames.length:Math.min(a.frames.length-1,Math.floor(age*a.fps/60))];
 if(!rf093OriArt.spitter.complete)return false;
 const [sx,sy,w,h]=f.rect,[dx,dy]=f.offset,scale=.245;
 g.save();g.imageSmoothingEnabled=true;g.imageSmoothingQuality='high';
 g.translate(e.x+(e.w||18)/2,e.y+(e.h||18)-8.4);
 g.scale(E04Modules.enemyFacingScale(E04Modules.enemyDefinition({foeSource:'ori-r29',type:'ori-dark-shooter'}),e.dir||1),1);
 if(e.flash%2)g.globalAlpha=.45;if(dying&&age>56)g.globalAlpha*=Math.max(0,(80-age)/24);
 g.drawImage(rf093OriArt.spitter,sx,sy,w,h,dx*scale,dy*scale,w*scale,h*scale);g.restore();return true;
}
function rf093OriImage(g,name,x,y,width,alpha=1){
 const im=rf093OriArt[name];if(!im?.naturalWidth)return;
 g.save();g.imageSmoothingEnabled=true;g.globalAlpha*=alpha;g.drawImage(im,x,y,width,width*im.height/im.width);g.restore();
}
function rf093DrawOriForest(g,v,width){
 const shade=g.createLinearGradient(0,0,0,240);shade.addColorStop(0,'#061b1e');shade.addColorStop(.6,'#12302b');shade.addColorStop(1,'#020b0e');g.fillStyle=shade;g.fillRect(0,0,width,240);
 for(let i=-1;i<Math.ceil(width/190)+1;i++){
  const x=i*190-(v.cam*.14)%190;
  rf093OriImage(g,'root-far',x,-70,260,.55);rf093OriImage(g,'root-back',x+100,-50,250,.32);
 }
 for(let i=-1;i<Math.ceil(width/340)+1;i++)rf093OriImage(g,'root-back',i*340-(v.cam*.3)%340,90,320,.55);
}
function rf093DrawOriTerrain(g,q){
 g.save();g.imageSmoothingEnabled=true;
 if(q.collision==='solid'){
  // The original bank tapers at both ends. Its flat core x240..327 has an
  // alpha128 surface at y35..36. Repeat only its shallow tread at fixed scale;
  // scaling the whole tapered bank created invisible ground above its tips.
  const im=rf093OriArt.bank,scale=.25,span=88,tile=span*scale,tread=4;
  g.save();g.beginPath();g.rect(q.x,q.y,q.w,q.h);g.clip();
  // All columns of this continuous core are opaque by source row51. Keeping
  // the body in one piece prevents repeated vertical cuts through the roots.
  g.drawImage(im,224,51,400,im.height-51,q.x,q.y+tread,q.w,(im.height-51)*q.w/400);
  for(let x=q.x;x<q.x+q.w;x+=tile){
   const w=Math.min(tile,q.x+q.w-x);
   g.drawImage(im,240,35,w/scale,tread/scale,x,q.y,w,tread);
  }g.restore();
  rf093OriImage(g,'wall',q.x+q.w*.25,q.y+21,q.w*.85);
 }else{
  // The central branch is a supported surface; tapered decorative ends are
  // excluded from the collision span. Leaf tips remain above the tread.
  const im=rf093OriArt.branch,span=610,scale=q.w/span;
  g.drawImage(im,240,0,span,im.height,q.x,q.y-20*scale,q.w,im.height*scale);
 }g.restore();
}
function rf093DrawOriHud(g,v,width,offset=0){
 const cx=offset+width/2,y=220,cell=7.6,art=rf093OriArt;
 g.save();g.imageSmoothingEnabled=true;
 // Native placement: blue energy left, green life right, ability orb centre.
 const dot=(empty,full,x,n,value,flip=false)=>{
  g.save();g.translate(x,y);if(flip)g.scale(-1,1);
  for(let i=0;i<n;i++){
   const w=40,h=48,sx=i===0?0:46;
   g.drawImage(art[empty],sx,0,w,h,i*cell,-4,6.4,7.7);
   if(i<value)g.drawImage(art[full],sx,0,w,h,i*cell,-4,6.4,7.7);
  }g.restore();
 };
 dot('energy-empty','energy-full',cx-14,O24_MAX_ENERGY,v.native?.energy||0,true);dot('health-empty','health-full',cx+14,O24_MAX_HP,v.health);
 rf093OriImage(g,'xp-empty',cx-10,y-10,20);
 const progress=(v.score%1000)/1000;
 if(progress){g.save();g.beginPath();g.moveTo(cx,y);g.arc(cx,y,11,-Math.PI/2,-Math.PI/2+Math.PI*2*progress);g.closePath();g.clip();rf093OriImage(g,'xp-ring',cx-10,y-10,20);g.restore();}
 rf093OriImage(g,'soul-ring',cx-6,y-6,12,.8);g.restore();
}
function rf093DrawOriBolt(g,b,tier=0){
 const im=rf093OriArt[tier===2?'regularSpiritFlameC':'regularSpiritFlameA'];if(!im?.naturalWidth)return;
 g.save();g.imageSmoothingEnabled=true;g.globalCompositeOperation='lighter';
 const tail=b.tail||[];
 for(let i=1;i<tail.length;i++){
  const a=tail[i-1],z=tail[i],len=Math.hypot(z.x-a.x,z.y-a.y);
  g.save();g.globalAlpha=i/tail.length*.35;g.translate(z.x,z.y);g.rotate(Math.atan2(z.y-a.y,z.x-a.x));g.drawImage(im,0,0,1024,64,-len,-1.5,len+3,3);g.restore();
 }
 g.translate(b.x,b.y);g.rotate(Math.atan2(b.vy||0,b.vx||1)+Math.PI);g.drawImage(im,0,0,1024,64,-2,-1.5-tier*.3,28+tier*4,3+tier*.6);g.restore();
}
function rf093DrawOriCharge(g,x,y,radius,alpha=1){
 g.save();g.imageSmoothingEnabled=true;g.globalCompositeOperation='lighter';g.globalAlpha*=alpha;g.drawImage(rf093OriArt['charge-disk'],x-radius,y-radius,radius*2,radius*2);g.restore();
}
// Keep the established pixel Ori actor and its registered A39 animation clock.
// Source art here owns the native environment, enemies, HUD and combat effects;
// it must not replace the shared actor presentation captured by rf04Native.
