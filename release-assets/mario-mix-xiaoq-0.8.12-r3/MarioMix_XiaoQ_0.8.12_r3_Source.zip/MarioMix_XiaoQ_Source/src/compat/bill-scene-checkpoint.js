// Only the native base owns its guards, core, drops and attack clock. Campaign
// lives/counters and the actor's gun are transferred through their own ports.
function rf09CaptureBillScene(base,body){
 return JSON.parse(JSON.stringify({kind:'bill-base',base,body:{invuln:body.invuln||0,star:body.star||0},
   shots:mixShots,cooldown:mixCool,fireFrames:billFireFrames,dropBag:billDropBag}));
}
function rf09RestoreBillScene(base,body,data){
 const keys=['kind','base','body','shots','cooldown','fireFrames','dropBag'];
 if(data.kind!=='bill-base'||Object.keys(data).some(k=>!keys.includes(k))||!data.base||!Array.isArray(data.base.guards)||
   data.base.guards.length!==3||!Array.isArray(data.base.hostile)||!Array.isArray(data.shots)||!Array.isArray(data.dropBag)||
   !Number.isFinite(data.base.x)||!Number.isFinite(data.base.y)||!Number.isFinite(data.base.coreHp)||typeof data.base.cleared!=='boolean')throw new TypeError('Invalid Bill base checkpoint');
 // Old checkpoints implicitly used 256. A stored wide arena remains valid
 // when the current viewport is classic; the owner maps spatial state once.
 const savedWidth=data.base.arenaWidth??256,maxWidth=E04Modules.nativeArenaWidth(E04Modules.createViewport('wide').view().width);
 if(![256,maxWidth].includes(savedWidth)||data.base.x<24||data.base.x>savedWidth-24)throw new TypeError('Invalid Bill base arena checkpoint');
 Object.assign(base,data.base,{arenaWidth:savedWidth});Object.assign(body,data.body);mixShots=data.shots;mixCool=data.cooldown;
 billFireFrames=data.fireFrames;billDropBag=data.dropBag;syncBillBasePlayer();
}
