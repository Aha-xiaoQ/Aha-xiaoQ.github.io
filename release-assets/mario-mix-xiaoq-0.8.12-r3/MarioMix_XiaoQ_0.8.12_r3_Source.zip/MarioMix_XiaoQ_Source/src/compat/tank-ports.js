/* RF02: world queries, projectiles and presentation ports; tank motion/rewards live in modules. */
tankRoute=E04Modules.createTankRoute({viewport:e04Viewport,canvas,ctx,
 state:{
  get scene(){return r12;},get actor(){return ninja;},get player(){return player;},get challenge(){return r03Challenge;},
  get mode(){return mode;},set mode(v){mode=v;},get frame(){return frame;},set frame(v){frame=v;},
  get deathTick(){return deathTick;},set deathTick(v){deathTick=v;},get lives(){return lives;},set lives(v){lives=v;},get score(){return score;},
  get timerTicks(){return timerTicks;},set timerTicks(v){timerTicks=v;},get timeLeft(){return timeLeft;},set timeLeft(v){timeLeft=v;},
  get transit(){return r07Transit;},set transit(v){r07Transit=v;},get death(){return r06Death;},
  get camera(){return camera;},get terrain(){return r03Terrain;},get effects(){return r06Effects;},get defeatEffects(){return r07DefeatFx;},
  get particles(){return particles;},get floaters(){return floaters;},
  get palette(){return r06Palette;},get rewards(){return r03Rewards;},get pipes(){return pipes;},set pipes(v){pipes=v;}
 },
 input:{
  pollPad:()=>pollMixPad(),sample:()=>r04Sample(),read:()=>getInput(),
  beginSnapshot:v=>{r04TickInput=v;},endSnapshot:v=>{r04Previous=v;r04TickInput=null;},
  releaseSnapshot:()=>{r04TickInput=null;},clearCommands:()=>r04ClearCommands()
 },
 simulation:{
  enemies:()=>r12TankEnemies(),combat:()=>r12Combat(),projectiles:v=>r04Projectiles(v),
  shoot:(...a)=>r12TankShot(...a),commonPlayer:v=>r12CommonPlayer(v),
  updateLifts:()=>r08UpdateLifts(),updateParticles:()=>updateParticles(),saveGeometry:()=>r12SaveGeometry(),
  load:(...a)=>r12Load(...a),handoff:()=>r12Handoff(),event:(...a)=>r12Event(...a),
  resetLife:()=>resetLife(),die:()=>die(),finishTick:()=>r05FinishTick(),
  tickEffects:()=>r06FxTick(),markEnemies:()=>r06MarkEnemies(),tickDefeat:()=>r07TickDefeat(),
  gameOver:latest=>latest?showOverlay('RESCUE RELAY / 1-2','重新整队','生命耗尽。重开或选人都会清理旧状态。','重新出发 →'):showOverlay('RELAY 1-2','整队，再出发','本次得分 '+score+' · 重新开始会从地下入口出发。','重新出发 →')
 },
 geometry:{solidTiles:b=>solids(b),lifts:()=>r08LiftBoxes()},
 rewardPorts:{kill:(...a)=>r12Kill(...a),addScore:(...a)=>addScore(...a),sound:(...a)=>r06Sound(...a),message:(...a)=>r12Message(...a),
  updateUI:()=>updateHeroUI(),stopEngine:()=>r06StopEngine(),stopEffects:()=>stopEffects(),detachCue:v=>r08DetachCue(v)},
 audio:{resultDone:()=>!soundOn||!audio||audio.state!=='running'||!r08Cue||r08Cue.role!=='defense-result'||r08Cue.done,sync:()=>audioSync(),oneShot:(...a)=>oneShot(...a),tally:()=>r06Sound('tally',{volume:.5}),gameOver:()=>r06Sound('gameover')},
 render:{
  // Original shared world renderer, not the historical r12Draw wrapper chain.
  base:()=>r03OldDraw(),tileAt:at,tile:r03TileImage,audioPanel:()=>updateAudioPanel(),
  images:R12_SPRITES,classicSprite,sprite,rect,text,tank:(...a)=>r12DrawTank(...a)
 }
});
if(new URLSearchParams(location.search).has('test'))window.__tankRoute=()=>tankRoute.view();
