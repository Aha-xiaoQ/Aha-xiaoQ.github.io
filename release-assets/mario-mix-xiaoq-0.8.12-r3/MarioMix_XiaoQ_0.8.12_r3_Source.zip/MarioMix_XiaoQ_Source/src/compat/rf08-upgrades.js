/* RF08 campaign-only bridges for the supplied Ori/Sonic controllers.
 * Controls, sheets, sounds and chapter scripts stay native. Charge Flame is
 * radial on release; Light Burst is the separate aimed, thrown ability.
 * The two equipment tiers are MarioMix's persistent reward mapping, not a
 * claim that either original game used these exact numbers or durations. */
function rf08OriState(o=c23.ori){return o.rf08||(o.rf08={serial:0,events:[],burst:null,pickup:null,lastTick:-1});}
function rf08OriEvent(o,type,data={}){
 const s=rf08OriState(o),event={id:'ori-'+(++s.serial),tick:c23.ticks,type,...data};
 s.events.push(event);if(s.events.length>192)s.events.shift();return event;
}
const rf08OriRadius=tier=>rf07UpgradeTier(tier)===2?84.5:65;
function rf08Alive(e){return e&&!e.dead&&!e.remove&&e.hp!==0;}
function rf08Center(e){return {x:e.x+(e.w||0)/2,y:e.y+(e.h||0)/2};}
function rf08DistanceToBox(x,y,e){return Math.hypot(x-clamp(x,e.x,e.x+(e.w||0)),y-clamp(y,e.y,e.y+(e.h||0)));}
function rf08ClearLine(a,b,geometry){
 const n=Math.max(1,Math.ceil(Math.hypot(b.x-a.x,b.y-a.y)/4));
 for(let i=1;i<n;i++){const x=a.x+(b.x-a.x)*i/n,y=a.y+(b.y-a.y)*i/n;
  if(geometry.some(q=>!q.hidden&&q.collision==='solid'&&x>q.x&&x<q.x+q.w&&y>q.y&&y<q.y+q.h))return false;
 }return true;
}
function rf08OriHit(context,e,amount,event){
 if(!rf08Alive(e))return false;
 const before=e.hp??2;
 const accepted=typeof context.world.damageEnemy==='function'
  ?context.world.damageEnemy(e,amount,{id:event.id,kind:event.type,owner:'ori'})
  :(()=>{e.hp=before-amount;e.flash=8;if(e.hp<=0)context.world.kill(e);return true;})();
 if(accepted===false)return false;
 const hit=rf08OriEvent(c23.ori,'hit',{attackId:event.id,target:e.id,before,after:e.hp??0,x:e.x,y:e.y});
 o24FX(e.x+(e.w||0)/2,e.y+(e.h||0)/2,'#adf5ff',7,1.1);o24Sound(e.dead?'flameKill':'impact');
 hit.feedbackId=event.id;return true;
}
function rf08OriAdvance(context){
 const o=c23.ori,s=rf08OriState(o),w=context.world;
 if(o.bash||s.lastTick===w.tick)return;s.lastTick=w.tick;
 if(s.burst&&--s.burst.life<=0)s.burst=null;if(s.pickup&&--s.pickup.life<=0)s.pickup=null;if(s.emptyCast&&--s.emptyCast.life<=0)s.emptyCast=null;
 for(const b of o.bolts){if(!b.rf08||b.life<=0)continue;
  const e=w.enemies.find(e=>e.id===b.target&&rf08Alive(e)),point=e&&rf08Center(e);b.life--;
  if(point){const dx=point.x-b.x,dy=point.y-b.y,d=Math.hypot(dx,dy)||1;b.vx=approach(b.vx,dx/d*4.2,.6);b.vy=approach(b.vy,dy/d*4.2,.6);}
  b.tail.push({x:b.x,y:b.y});if(b.tail.length>7)b.tail.shift();
  const count=Math.max(1,Math.ceil(Math.hypot(b.vx,b.vy)/2));let outcome=null;
  for(let i=0;i<count&&!outcome;i++){
   b.x+=b.vx/count;b.y+=b.vy/count;
   if(w.solids.some(q=>!q.hidden&&q.collision==='solid'&&b.x>=q.x&&b.x<=q.x+q.w&&b.y>=q.y&&b.y<=q.y+q.h))outcome='world';
   else if(e&&rf08Alive(e)&&rf08DistanceToBox(b.x,b.y,e)<=3){rf08OriHit(context,e,1,b.attack);outcome='hit';}
  }
  if(outcome||b.life<=0){b.life=0;rf08OriEvent(o,'projectile-gone',{attackId:b.attack.id,target:b.target,outcome:outcome||'ttl',x:b.x,y:b.y});}
 }
 o.bolts=o.bolts.filter(b=>b.life>0);
 // The original Light Burst arc/energy/cooldown is retained; unlike the old
 // borrowed Bowser shortcut, a real enemy or wall contact detonates the orb.
 for(const b of o.orbs){if(!b.rf08||b.life<=0)continue;
  b.age++;b.life--;b.x+=b.vx;b.y+=b.vy;b.vy+=.065;
  const wall=w.solids.some(q=>!q.hidden&&q.collision==='solid'&&b.x>=q.x-2&&b.x<=q.x+q.w+2&&b.y>=q.y-2&&b.y<=q.y+q.h+2);
  const foe=w.enemies.find(e=>rf08Alive(e)&&rf08DistanceToBox(b.x,b.y,e)<4);
  if(wall||foe||b.life<=0){b.life=0;o24Blast(b.x,b.y,40,3,'orbImpact');rf08OriEvent(o,'orb-gone',{attackId:b.attackId,outcome:foe?'hit':wall?'world':'ttl',x:b.x,y:b.y});}
 }
 o.orbs=o.orbs.filter(b=>b.life>0&&b.y<w.height+40&&b.x>=-32&&b.x<w.width+32);
}
function rf08WithOriUpgrade(value,fn,context=null){
 const tier=rf07UpgradeTier(value),o=c23.ori,flame=o24Flame,blast=o24Blast,throwOrb=o24Throw;
 const hiddenBolts=context?o.bolts.filter(b=>b.rf08):[],hiddenOrbs=context?o.orbs.filter(b=>b.rf08):[];
 let restored=false;
 const restoreProjectiles=()=>{if(context&&!restored){o.bolts.push(...hiddenBolts);o.orbs.push(...hiddenOrbs);restored=true;}};
 if(context){o.bolts=o.bolts.filter(b=>!b.rf08);o.orbs=o.orbs.filter(b=>!b.rf08);}
 o24Flame=function(...args){
  const start=o.bolts.length;
  if(context){
   const p=context.player,origin={x:p.x+p.w/2,y:p.y+p.h/2};
   const candidates=context.world.enemies.filter(e=>rf08Alive(e)&&!/fire|bullet|hammer|podoboo/.test(e.type||''))
    .map(e=>({e,point:rf08Center(e)})).filter(t=>Math.hypot(t.point.x-origin.x,t.point.y-origin.y)<160&&rf08ClearLine(origin,t.point,context.world.solids))
    .sort((a,b)=>Math.hypot(a.point.x-origin.x,a.point.y-origin.y)-Math.hypot(b.point.x-origin.x,b.point.y-origin.y));
   if(!candidates.length){const prior=c23.bowser;c23.bowser={alive:false,active:false};try{return flame(...args);}finally{c23.bowser=prior;}}
   for(let i=0;i<=tier;i++){
    const target=candidates.length?candidates[i%candidates.length]:null,event=rf08OriEvent(o,'flame',{target:target?.e.id||null,facing:p.facing,x:origin.x,y:origin.y});
    o.bolts.push({rf08:true,attack:event,target:target?.e.id||null,x:p.x+4-p.facing*7,y:p.y-4+(i-tier/2)*5,vx:p.facing*2,vy:0,life:target?90:24,tail:[]});o.flames++;
   }o24Sound('flame');
  }else{
   const result=flame(...args);
   if(o.bolts.length>start){
    for(let i=0;i<tier;i++)flame(...args);
    const targets=o28IsVertical()?o28.shooters.filter(e=>e.hp>0&&Math.hypot(e.x-player.x,e.y-player.y)<140).sort((a,b)=>Math.hypot(a.x-player.x,a.y-player.y)-Math.hypot(b.x-player.x,b.y-player.y)):[];
    o.bolts.slice(start).forEach((b,i)=>{b.y+=(i-tier/2)*5;if(targets.length)b.target=targets[i%targets.length].id;});
   }return result;
  }
 };
 o24Blast=function(x,y,r,damage,cue='orbImpact'){
  const charged=cue==='chargeBlast',radius=charged?rf08OriRadius(tier):r,amount=charged&&tier===2?damage+2:damage;
  const event=rf08OriEvent(o,charged?'charge-release':cue,{x,y,radius,damage:amount,facing:player.facing});
  rf08OriState(o).burst={x,y,radius,life:16,eventId:event.id};
  if(!context)return blast(x,y,radius,amount,cue);
  // Native particles/audio remain, but the common stage owns all targets.
  const prior=c23.bowser;c23.bowser={alive:false,active:false};
  try{blast(x,y,radius,amount,cue);}finally{c23.bowser=prior;}
  for(const e of context.world.enemies){if(!rf08Alive(e)||rf08DistanceToBox(x,y,e)>radius)continue;
   if(/fire|bullet|hammer/.test(e.type||'')){e.dead=true;rf08OriEvent(o,'projectile-cleared',{attackId:event.id,target:e.id});}
   else if(!/podoboo/.test(e.type||''))rf08OriHit(context,e,amount,event);
  }
  // Only exposed destructible bricks: never pipes, hard terrain, hidden or
  // question blocks, and never a substitute route through the native chapter.
  if(charged)for(const q of context.world.solids)if(!q.hidden&&q.material==='brick'&&!q.content&&rf08DistanceToBox(x,y,q)<radius)context.world.bump(q.id,true);
 };
 o24Throw=function(...args){const start=o.orbs.length,result=throwOrb(...args);if(context)for(const b of o.orbs.slice(start)){b.rf08=true;b.attackId=rf08OriEvent(o,'light-burst',{x:b.x,y:b.y,vx:b.vx,vy:b.vy,facing:player.facing}).id;}return result;};
 try{
  const result=fn();
  if(context){restoreProjectiles();if(context.phase==='combat')rf08OriAdvance(context);}
  else{const s=rf08OriState(c23.ori);if(s.lastTick!==c23.ticks){s.lastTick=c23.ticks;if(s.burst&&--s.burst.life<=0)s.burst=null;if(s.pickup&&--s.pickup.life<=0)s.pickup=null;if(s.emptyCast&&--s.emptyCast.life<=0)s.emptyCast=null;}}
  return result;
 }finally{restoreProjectiles();o24Flame=flame;o24Blast=blast;o24Throw=throwOrb;}
}
function rf08OriPickup(o,type,p=player){rf08OriState(o).pickup={type,x:p.x+p.w/2,y:p.y-7,life:48};rf08OriEvent(o,'upgrade',{tier:o.upgradeTier,type});}
function rf08DrawOriFeedback(g,p,o,tick,{native=false,offsetX=0,offsetY=0}={}){
 const s=rf08OriState(o);g.save();g.translate(offsetX,offsetY);
 if(s.emptyCast){const b=s.emptyCast;g.save();g.globalAlpha=b.life/12;rf093DrawOriBolt(g,{x:b.x+b.face*(12-b.life)*.45,y:b.y,vx:b.face,vy:0},0);g.restore();}
 if(o.charge>=18&&o.energy>0)rf093DrawOriCharge(g,p.x+p.w/2,p.y+p.h/2,10+Math.min(1,o.charge/34)*13,.35);
 if(s.burst){const b=s.burst,age=16-b.life;rf093DrawOriCharge(g,b.x,b.y,Math.min(b.radius,(age+1)*b.radius/8),b.life/16*.7);}
 if(!native&&o.lightAim){const a=o.lightAim;let x=a.x,y=a.y,vx=a.ax*2.6,vy=a.ay*3;for(let i=0;i<35;i++){x+=vx;y+=vy;vy+=.065;if(solids({x:x-1,y:y-1,w:2,h:2}).length)break;if(i%3===0)o24Ellipse(g,x,y,.62,.62,o.energy?'#ffe7a9b0':'#aa7c6a99');}o24Glow(g,a.x,a.y,8,'#ffde9b',.24);}
 if(s.pickup){const q=s.pickup;g.save();g.globalAlpha=Math.min(1,q.life/12);rf07DrawOriSupply(g,q.x,q.y-(48-q.life)*.35,q.type,tick);g.restore();}
 g.restore();
}
function rf08WithSonicUpgrade(s,fn,context=null){
 const result=rf07WithSonicUpgrade(s,fn);if(!context||context.phase!=='combat')return result;
 const w=context.world,p=context.player,tier=rf07UpgradeTier(s.upgradeTier);
 if(s.rf08Tick===w.tick)return result;s.rf08Tick=w.tick;
 s.rf08Trail=(s.rf08Trail||[]).filter(t=>--t.life>0);
 if(s.rf08Pickup&&--s.rf08Pickup.life<=0)s.rf08Pickup=null;
 if(tier&&Math.abs(p.vx)>2.2&&!p.dying&&!s.hurt&&w.tick%3===0)s.rf08Trail.push({x:p.x,y:p.y,pose:s.pose,anim:s.anim,face:p.facing,life:10});
 if(!tier){s.rf08Trail=[];s.rf08Pickup=null;return result;}
 if(tier===2){
  const target={x:p.x+p.w/2,y:p.y+p.h/2};
  for(const coin of w.coins||[]){const from=rf08Center(coin),d=Math.hypot(target.x-from.x,target.y-from.y);if(d>64||!rf08ClearLine(from,target,w.solids))continue;
   const speed=Math.min(3.2,d),x=coin.x+(target.x-from.x)/Math.max(1,d)*speed,y=coin.y+(target.y-from.y)/Math.max(1,d)*speed;
   coin.x=x;coin.y=y;
   if(d<9)w.collectObjectCoin?.(coin.id);
  }
  for(const ring of s.loose){const d=Math.hypot(target.x-ring.x,target.y-ring.y);if(ring.age>30&&d<64&&rf08ClearLine(ring,target,w.solids)){ring.vx=(target.x-ring.x)/Math.max(1,d)*3;ring.vy=(target.y-ring.y)/Math.max(1,d)*3;}}
 }return result;
}
function rf08SonicPickup(s,type,p=player){s.rf08Pickup={type,x:p.x+p.w/2,y:p.y-10,life:48};}
function rf08DrawSonicFeedback(g,p,s,tick){
 if(p.dying||!rf07UpgradeTier(s.upgradeTier))return;
 for(const t of s.rf08Trail||[])s33Sprite(g,t.x+4.5,t.y+14,t.pose,t.anim,t.face,t.life*.019);
 const q=s.rf08Pickup;if(q&&rf07SonicArt.icons.naturalWidth){g.save();g.imageSmoothingEnabled=false;g.globalAlpha=Math.min(1,q.life/12);g.drawImage(rf07SonicArt.icons,(q.type==='lightning-shield'?6:q.type==='plain-shield'?5:3)*16,0,16,16,Math.round(q.x-8),Math.round(q.y-8-(48-q.life)*.35),16,16);g.restore();}
}
