/* Original GHZ art decoded from pinned Nemesis tiles/maps/CRAM. a9501..a9507
 * are isolated integration allocations; source receipts live beside the art. */
const rf101SonicBossArt={};
for(const [name,uri]of Object.entries({eggman:'@@E04:uri:a9501@@',ball:'@@E04:uri:a9502@@',anchor:'@@E04:uri:a9503@@',link:'@@E04:uri:a9504@@'})){
 const im=new Image();im.src=uri;rf101SonicBossArt[name]=im;mainlineAssetJobs.push(im.decode());
}
const rf101SonicBossAudio={hit:'@@E04:uri:a9505@@',explode:'@@E04:uri:a9506@@',music:'@@E04:uri:a9507@@'};
let rf101SonicBossAudioReady=null;
function rf101LoadSonicBossAudio(){if(rf101SonicBossAudioReady)return rf101SonicBossAudioReady;const ac=audioInit(false);if(!ac)return Promise.resolve();
 return rf101SonicBossAudioReady=Promise.all(Object.entries(rf101SonicBossAudio).map(async([key,uri])=>{
  const bytes=Uint8Array.from(atob(uri.split(',')[1]),c=>c.charCodeAt(0));const buffer=await ac.decodeAudioData(bytes.buffer);
  bank.set('sonicGhzBoss_'+key,{buffer,role:key==='music'?'music':'effect',owner:'sonic',gain:.65});
 }));
}
function rf101DrawSonicBoss(args){
 rf092DrawPlatformChallenge({...args,drawDeparture:rf101DrawSonicDeparture});
 const {view:v,boss,width}=args,g=ctx,art=rf101SonicBossArt,e=v.enemies.find(q=>q.id==='ghz-eggman')||boss.retreat;
 if(!e)return;const offset=Math.max(0,(W-width)/2);g.save();g.beginPath();g.rect(offset,56,width,184);g.clip();g.translate(Math.round(offset-v.cam),0);g.imageSmoothingEnabled=false;
 const cx=e.x+12,cy=e.y+12;
 if(e.ballReady&&!boss.defeated){const ball=v.enemies.find(q=>q.id==='ghz-ball');
  if(ball){const bx=ball.x+10,by=ball.y+10,ay=cy+e.anchor*.5;
   for(const distance of [16,32,48,64]){const t=Math.min(distance,e.chain)/Math.max(1,e.chain);g.drawImage(art.link,Math.round(cx+(bx-cx)*t-4),Math.round(ay+(by-ay)*t-4),8,8);}
   g.drawImage(art.anchor,Math.round(cx-4),Math.round(ay-4),8,8);
   g.drawImage(art.ball,(Math.floor(v.tick/4)%2)*48,0,48,48,Math.round(bx-12),Math.round(by-12),24,24);
  }
 }
 if(!e.flash||v.tick%4<2){const face=e.phase==='escape'?5:boss.defeated?6:e.flash?4:e.phase==='wait'?2+Math.floor(v.tick/8)%2:Math.floor(v.tick/8)%2;
  g.save();g.translate(Math.round(cx),Math.round(cy));if(e.face)g.scale(-1,1);g.drawImage(art.eggman,face*96,0,96,80,-24,-20,48,40);
  if(e.phase==='move'||e.phase==='escape')g.drawImage(art.eggman,(7+Math.floor(v.tick/4)%2)*96,0,96,80,-24,-20,48,40);g.restore();
 }
 if(e.phase==='explode')for(let i=0;i<3;i++){const age=(e.age+i*7)%20,dx=((Math.floor(e.age/8)*11+i*19)%41)-20,dy=((Math.floor(e.age/8)*7+i*13)%31)-15;
  g.drawImage(rf08FoeArt.explosion,Math.min(4,Math.floor(age/4))*32,0,32,32,Math.round(cx+dx-8),Math.round(cy+dy-8),16,16);}
 g.restore();
}
function rf101DrawSonicDeparture(g,d,v){
 const p={...v.p,...d.body,invuln:0},tick=v.tick+d.age,tier=rf07UpgradeTier(v.native?.upgradeTier);
 if(tier)rf07DrawSonicShield(g,p,tick,{tier,layer:'back'});
 s33Sprite(g,p.x+p.w/2,p.y+p.h,d.phase==='ready'?'idle':'run',d.animation,1);
 if(tier)rf07DrawSonicShield(g,p,tick,{tier,layer:'front'});
}
function createRf101SonicBossDriver(){let active=false;
 const syncAudio=playing=>{active=playing;s33MusicStop(true);
  if(!playing||!soundOn||document.hidden){if(bgm?.key==='sonicGhzBoss_music')stopMusic(true);return;}
  if(bank.has('sonicGhzBoss_music'))playMusic('sonicGhzBoss_music');else rf101LoadSonicBossAudio().then(()=>{if(active&&soundOn&&!document.hidden)playMusic('sonicGhzBoss_music');}).catch(error=>console.error('Sonic boss audio',error));
 };
 return E04Modules.createSonicBossChallenge({character:E04Modules.CHARACTER_PROFILES.find(p=>p.id==='sonic'),rule:E04Modules.CHALLENGE_RULES.sonic,
  createActor:hero=>mainlineActorRegistry.create(hero),viewport:()=>W,render:rf101DrawSonicBoss,syncAudio,
  sound:(actor,event)=>{if(event==='sonic-boss-hit'||event==='sonic-boss-explode')withAudioOwner('actor:sonic',()=>oneShot('sonicGhzBoss_'+(event.endsWith('hit')?'hit':'explode')));
   else if(!actor.sound(event)&&event==='life')originalOneShot('oneup');},
  debug:new URLSearchParams(location.search).get('test')==='1'});
}
