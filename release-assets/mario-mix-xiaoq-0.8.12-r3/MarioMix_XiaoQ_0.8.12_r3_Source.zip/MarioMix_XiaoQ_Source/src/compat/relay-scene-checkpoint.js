/* Native hidden-room progress only. Actor health/equipment and campaign
 * counters have separate owners. Restore after construction and equipment;
 * never call this for a death retry. No constructor or reward is replayed. */
const RF09_RELAY_FIELDS={
 body:['x','y','w','h','vx','vy','facing','dir','grounded','crouch','invuln','star','anim','walk','ryuCeilingRail'],
 relay:['ticks','camY','message','messageTime','transition','target','transitionSpawn','checkpointTier','lifts','handoff','clearTick','shake','flash','water','bridges','r03descent','r03Grip','pipeCooldown','rankFlash','spawnFrames','spawnFromY','spawnToY','r04Area','r07Entry','r08IntroPending','r06IntroDone','r03StartPlayed'],
 tank:['shield','freeze','cool','dir','track','fireBuffer','glide','glideDir','turnAssist','shovel'],
 ninja:['room','wall','wallLock','wallFrom','attack','cool','attackId','hit','coyote','buffer','stageIntro','transition','transitionTo','gateOpen','arena','bossDefeated','foes','drops','lanterns','fx','ticks','clearTick','kickCommit','command','climbTravel','descentActive','r06Aim','throwDir','throwPose','spin'],
 challenge:['kind','failed','won','wonAt','blocks','base','baseDestroyed','spawned','total','kills','clock','spawnClock','ledger08','tally08','exitPipe','r08ResultRequested','departure','arenaWidth','wideDamage'],
};
function rf09RelayPick(value,keys){return Object.fromEntries(keys.filter(k=>value[k]!==undefined).map(k=>[k,value[k]]));}
function rf09RelayRoom(id){
 const area=id==='ryu'?'bar':id==='tank'?'defense':null,kind=id==='ryu'?'ninja':'tank';
 if(!area||!r12||r12.area!==area||!ninja||!player||r03Challenge?.kind!==kind)throw new TypeError('Relay checkpoint requires its native hidden room');
 return {area,kind};
}
function rf09CaptureRelayScene(id){
 const {area}=rf09RelayRoom(id),cue=id==='tank'&&r08Cue;
 const data={schema:'mario-mix.relay-scene',version:1,hero:id,area,
  clock:{frame,timeLeft,timerTicks,freeze,camera},body:rf09RelayPick(player,RF09_RELAY_FIELDS.body),
  relay:{...rf09RelayPick(r12,RF09_RELAY_FIELDS.relay),discovered:[...r12.discovered]},
  tank:rf09RelayPick(r12.tank,RF09_RELAY_FIELDS.tank),
  ninja:{...rf09RelayPick(ninja,RF09_RELAY_FIELDS.ninja),hitIds:[...ninja.hitIds],spinHit:[...(ninja.spinHit||[])],
   projectiles:ninja.projectiles.map(s=>({...s,hit:[...(s.hit||[])]}))},
  challenge:rf09RelayPick(r03Challenge,RF09_RELAY_FIELDS.challenge),rewards:{...r03Rewards},
  world:{tiles:[...tiles],pipes,coins:looseCoins,terrain:r03Terrain,transit:r07Transit},
  effects:{particles,floaters,native:r06Effects,defeat:r07DefeatFx},
  sequence:{uid:r06UID,item:r05Session,bonus:r07BonusIndex},
  cue:cue?{key:cue.key,role:cue.role,duration:cue.duration,done:!!cue.done,
   offset:Math.min(cue.duration,cue.offset+(cue.node&&audio?Math.max(0,audio.currentTime-cue.started):0))}:null};
 // Native optional fields (e.g. a player shell's owner) may be undefined.
 // Sets are encoded explicitly above; other non-data objects are mistakes.
 const plain=JSON.parse(JSON.stringify(data,(key,value)=>{
  if(typeof value==='number'&&!Number.isFinite(value)||typeof value==='function'||value instanceof Set||value instanceof Map)throw new TypeError('Non-data native relay state');
  return value;
 }));
 return E04Modules.copySceneCheckpoint(id,{version:1,hero:id,data:plain}).data;
}
function rf09RestoreRelayScene(id,input){
 const {area,kind}=rf09RelayRoom(id);
 // Validate/clone before the first write, including accessor/prototype checks.
 const d=E04Modules.copySceneCheckpoint(id,{version:1,hero:id,data:input}).data;
 const invalid=()=>{throw new TypeError('Invalid native relay scene checkpoint');};
 const object=(v,keys,required=[])=>{
  if(!v||Array.isArray(v)||typeof v!=='object'||Object.keys(v).some(k=>!keys.includes(k))||required.some(k=>!Object.hasOwn(v,k)))invalid();
 };
 const number=(v,lo,hi,integer=false)=>{if(!Number.isFinite(v)||v<lo||v>hi||integer&&!Number.isSafeInteger(v))invalid();};
 const list=(v,max)=>{if(!Array.isArray(v)||v.length>max)invalid();return v;};
 const setData=(v)=>{list(v,2048);if(v.some(x=>typeof x!=='string'&&!Number.isSafeInteger(x))||new Set(v).size!==v.length)invalid();};
 const box=(v)=>{if(!v||typeof v!=='object')invalid();number(v.x,-4096,65536);number(v.y,-4096,65536);number(v.w,.01,4096);number(v.h,.01,4096);};
 const replace=(target,value,keys)=>{for(const k of keys)delete target[k];Object.assign(target,value);};
 const top=['schema','version','hero','area','clock','body','relay','tank','ninja','challenge','rewards','world','effects','sequence','cue'];
 object(d,top,top);
 if(d.schema!=='mario-mix.relay-scene'||d.version!==1||d.hero!==id||d.area!==area)invalid();
 object(d.clock,['frame','timeLeft','timerTicks','freeze','camera'],['frame','timeLeft','timerTicks','freeze','camera']);
 for(const k of ['frame','timeLeft','timerTicks','freeze'])number(d.clock[k],0,2147483647,true);
 number(d.clock.camera,0,Math.max(0,r12.def.width));
 object(d.body,RF09_RELAY_FIELDS.body,['x','y','w','h','vx','vy','facing','grounded']);box(d.body);
 // A supported wide bar checkpoint may be resumed in classic mode. Validate
 // against the same grid-aligned width the shared viewport advertises, then
 // fit its entities to the current room only after all data has passed.
 const maxBodyWidth=Math.max(r12.def.width,E04Modules.nativeArenaWidth(E04Modules.createViewport('wide').view().width));
 number(d.body.x,-64,maxBodyWidth+64);number(d.body.y,-256,1024);number(d.body.w,1,64);number(d.body.h,1,64);
 for(const k of ['vx','vy'])number(d.body[k],-64,64);
 if(![-1,1].includes(d.body.facing)||typeof d.body.grounded!=='boolean')invalid();
 for(const k of ['invuln','star'])if(d.body[k]!==undefined)number(d.body[k],0,36000);
 if(d.body.ryuCeilingRail!==undefined)E04Modules.validateRyuCeilingRail(d.body.ryuCeilingRail);
 object(d.relay,[...RF09_RELAY_FIELDS.relay,'discovered'],['ticks','camY','lifts','water','bridges','discovered']);
 number(d.relay.ticks,0,2147483647,true);setData(d.relay.discovered);
 for(const k of ['lifts','water','bridges'])for(const v of list(d.relay[k],256))box(v);
 object(d.tank,RF09_RELAY_FIELDS.tank,['dir','cool','track']);
 for(const [k,v]of Object.entries(d.tank))number(v,0,k==='dir'||k==='glideDir'?3:2147483647,k==='dir'||k==='glideDir');
 object(d.ninja,[...RF09_RELAY_FIELDS.ninja,'hitIds','spinHit','projectiles'],['foes','drops','lanterns','fx','hitIds','spinHit','projectiles']);
 setData(d.ninja.hitIds);setData(d.ninja.spinHit);
 for(const e of list(d.ninja.foes,128)){
  box(e);if(!['barbarian','tank','walker','thrower','hawk','goomba','koopa','guardian'].includes(e.kind)||typeof e.dead!=='boolean')invalid();
  number(e.hp,-10000,10000);number(e.maxHp,1,10000);
 }
 for(const q of list(d.ninja.projectiles,512)){
  box(q);if(!['shell','shuriken','windmill','flame','knife'].includes(q.kind)||typeof q.friendly!=='boolean')invalid();
  number(q.vx,-64,64);number(q.vy,-64,64);number(q.life,-1,36000);setData(q.hit);
 }
 for(const k of ['drops','lanterns'])for(const q of list(d.ninja[k],512))box(q);
 list(d.ninja.fx,4096);
 object(d.challenge,RF09_RELAY_FIELDS.challenge,['kind','failed']);
 if(d.challenge.kind!==kind||d.challenge.failed!==false||d.challenge.won!==undefined&&typeof d.challenge.won!=='boolean')invalid();
 if(d.challenge.departure!==undefined)E04Modules.validateRelayDeparture(d.challenge.departure,id==='ryu'?'ryu-door':'tank-results');
 if(d.challenge.won&&d.ninja.foes.some(e=>!e.dead))invalid();
 if(id==='tank'){
  for(const k of ['spawned','total','kills','clock'])number(d.challenge[k],0,100000,true);
  number(d.challenge.spawnClock,-100000,100000,true);
  if(d.challenge.spawned>d.challenge.total||d.challenge.kills>d.challenge.spawned)invalid();
  box(d.challenge.base);
  if(d.challenge.arenaWidth!==undefined&&![256,E04Modules.nativeArenaWidth(E04Modules.createViewport('wide').view().width)].includes(d.challenge.arenaWidth))invalid();
  if(d.challenge.wideDamage!==undefined){const damage=list(d.challenge.wideDamage,16);if(new Set(damage).size!==damage.length||damage.some(k=>typeof k!=='string'||!/^(left|right):(64|72|80|88|152|160|168|176)$/.test(k)))invalid();}
  if(d.challenge.baseDestroyed){object(d.challenge.baseDestroyed,['age','friendly'],['age','friendly']);number(d.challenge.baseDestroyed.age,0,E04Modules.CHALLENGE_TUNING.tank.baseExplosionTicks,true);if(typeof d.challenge.baseDestroyed.friendly!=='boolean')invalid();}
  for(const b of list(d.challenge.blocks,4096)){box(b);if(!['brick','steel','pipe'].includes(b.type)||typeof b.dead!=='boolean')invalid();}
  if(d.challenge.tally08){
   const tally=d.challenge.tally08;if(!d.challenge.won||typeof tally.active!=='boolean'||list(tally.rows,4).length!==4)invalid();
   number(tally.clock,0,36000);number(tally.duration,1,36000);
  }
 }
 object(d.rewards,['ninja','tank'],['ninja','tank']);if(Object.values(d.rewards).some(v=>typeof v!=='boolean'))invalid();
 if(d.challenge.departure){
  if(d.challenge.won!==true||d.rewards[kind]!==true)invalid();
  if(id==='tank'&&d.challenge.departure.complete){
   const tally=d.challenge.tally08;
   if(!tally||tally.active||tally.duration!==330||tally.clock<330||d.challenge.departure.age!==tally.clock)invalid();
  }
 }
 object(d.world,['tiles','pipes','coins','terrain','transit'],['tiles','pipes','coins','terrain','transit']);
 const tileKeys=new Set();
 for(const pair of list(d.world.tiles,4096)){
  if(!Array.isArray(pair)||pair.length!==2||typeof pair[0]!=='string'||tileKeys.has(pair[0]))invalid();
  const t=pair[1];number(t.x,-256,4096,true);number(t.y,-256,4096,true);
  if(pair[0]!==t.x+','+t.y||typeof t.type!=='string')invalid();tileKeys.add(pair[0]);
 }
 for(const k of ['pipes','coins','terrain'])list(d.world[k],4096);
 object(d.effects,['particles','floaters','native','defeat'],['particles','floaters','native','defeat']);
 for(const v of Object.values(d.effects))list(v,4096);
 object(d.sequence,['uid','item','bonus'],['uid','item','bonus']);for(const v of Object.values(d.sequence))number(v,0,2147483647,true);
 if(d.cue){
  object(d.cue,['key','role','duration','offset','done'],['key','role','duration','offset','done']);
  if(id!=='tank'||!['t06_start','t06_result','t09_stage_done'].includes(d.cue.key)||!['intro','defense-result','flag-result'].includes(d.cue.role)||typeof d.cue.done!=='boolean')invalid();
  number(d.cue.duration,0,3600);number(d.cue.offset,0,d.cue.duration);
 }
 // No validation may follow this point. Keep the constructed identities:
 // relayView's relayRoom and the tank ports refer to these existing objects.
 replace(player,d.body,RF09_RELAY_FIELDS.body);
 replace(r12,d.relay,[...RF09_RELAY_FIELDS.relay,'discovered']);r12.discovered=new Set(d.relay.discovered);
 replace(r12.tank,d.tank,RF09_RELAY_FIELDS.tank);
 replace(ninja,d.ninja,[...RF09_RELAY_FIELDS.ninja,'hitIds','spinHit','projectiles']);
 ninja.hitIds=new Set(d.ninja.hitIds);ninja.spinHit=new Set(d.ninja.spinHit);
 for(const q of ninja.projectiles)q.hit=new Set(q.hit);
 Object.assign(ninja,{jumpHeld:false,attackHeld:false,specialHeld:false,cycleHeld:false});
 replace(r03Challenge,d.challenge,Object.keys(r03Challenge));Object.assign(r03Rewards,d.rewards);
 tiles.clear();for(const [key,value]of d.world.tiles)tiles.set(key,value);
 pipes=d.world.pipes;looseCoins=d.world.coins;r03Terrain=d.world.terrain;r07Transit=d.world.transit;
 if(r03Challenge.exitPipe)pipes=pipes.map(q=>q.x===r03Challenge.exitPipe.x&&q.y===r03Challenge.exitPipe.y?r03Challenge.exitPipe:q);
 r12World[area]={tiles,pipes,coins:looseCoins};
 ({frame,timeLeft,timerTicks,freeze,camera}=d.clock);
 particles=d.effects.particles;floaters=d.effects.floaters;r06Effects=d.effects.native;r07DefeatFx=d.effects.defeat;
 r06UID=d.sequence.uid;r05Session=d.sequence.item;r07BonusIndex=d.sequence.bonus;
 r08DetachCue(false);if(d.cue)r08Cue={...d.cue,node:null,gain:null,started:0,id:++r08CueSerial};
 r04Clear();jumpHeldPrev=false;runHeldPrev=false;
 if(id==='ryu')rf089SyncRyuArena(true);
 if(id==='tank')tankRoute.syncArena();
 return true;
}
