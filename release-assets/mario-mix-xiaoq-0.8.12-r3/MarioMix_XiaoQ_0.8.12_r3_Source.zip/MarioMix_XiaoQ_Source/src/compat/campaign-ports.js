/* Sole bridge between the shared session and the unmigrated native closure.
 * This file is included once, after native definitions and before first selection.
 * No new RAF, keyboard listener, physics, sprite renderer or save format.
 */
const mixNative={choose:c23Choose,select:selectHero,start:startGame,pause:togglePause,
 characters:showCharacters,primary:handlePrimary,fixed:fixedUpdate,resumeCheckpoint:o30Resume};
let mixPortDepth=0;
function mixCall(fn,...args){mixPortDepth++;try{return fn(...args);}finally{mixPortDepth--;}}
function mixClearTransient(){
 c23Clear();tankRoute?.leave();
 shots=[];mixShots=[];enemyShots=[];particles=[];floaters=[];pipeTransition=null;
 jumpBuffer=0;jumpHeldPrev=false;runHeldPrev=false;
}
const mixAdapters=Object.fromEntries(E04Modules.gameCatalog.scenes().map(scene=>[scene.id,{
 enter({character,lifetime}){
  // Cleanup is registered before entry, so a failed native entry is also contained.
  lifetime.own(mixClearTransient);
  c23Campaign.chosen[scene.stage]=character.id;
  mixCall(mixNative.choose,scene.stage);
  mixCall(mixNative.select,character.id);
 },
 start(context,payload){
  if(payload?.checkpoint)return mixCall(mixNative.resumeCheckpoint,payload.checkpoint);
  return mixCall(mixNative.start);
 },
 pause(){return mixCall(mixNative.pause);},
 resume(){return mixCall(mixNative.pause);},
 leave(){
  // Flush before the next native scene changes the stage/hero identity.
  if(c23Campaign.stage===14){o30Flush();o30.active=false;}
  resetGameAudio();
 },
}]));
const mixSession=E04Modules.createSession({catalog:E04Modules.gameCatalog,adapters:mixAdapters});
function mixReportPhase(){
 mixSession.reportPhase(c23Menu&&mode==='menu'?'ready':mode==='paused'?'paused':mode==='win'?'finished':'running');
}
c23Choose=function(stage){
 if(mixPortDepth||c23SelectionLock)return mixNative.choose(stage);
 const scene=E04Modules.gameCatalog.stage(stage);
 const chosen=c23Campaign.chosen[stage];
 return mixSession.select(scene.characters.includes(chosen)?chosen:scene.defaultCharacter,scene.id);
};
selectHero=function(id){
 if(mixPortDepth||c23SelectionLock)return mixNative.select(id);
 if(mode!=='menu')return;
 const scene=E04Modules.gameCatalog.stage(c23Campaign.stage);
 const target=E04Modules.gameCatalog.resolve(id,scene.characters.includes(id)?scene.id:undefined);
 if(mixSession.snapshot().characterId===id&&mixSession.snapshot().sceneId===target.scene.id)return;
 return mixSession.select(id,target.scene.id);
};
showCharacters=function(){
 if(mixPortDepth||c23SelectionLock)return mixNative.characters();
 return c23Choose(c23Campaign.stage);
};
startGame=function(){
 if(mixPortDepth)return mixNative.start();
 if(!mixSession.snapshot().sceneId)c23Choose(c23Campaign.stage);
 return mixSession.start();
};
handlePrimary=function(){
 if(mixPortDepth)return mixNative.primary();
 if(mode==='menu')return startGame();
 const result=mixNative.primary();mixReportPhase();return result;
};
togglePause=function(){
 if(mixPortDepth)return mixNative.pause();
 mixReportPhase();
 if(mode==='paused')return mixSession.resume();
 if(['playing','dying'].includes(mode))return mixSession.pause();
 return mixNative.pause();
};
o30Resume=function(input=o30.snapshot){
 if(mixPortDepth)return mixNative.resumeCheckpoint(input);
 // Reject bad saves before leaving the current scene; retain native validation.
 let saved;try{saved=o30Validate(input).data;}catch(error){toast('进度未载入：'+error.message);return false;}
 const id=saved.character||'ori';
 E04Modules.gameCatalog.resolve(id,'world-1-4');
 mixSession.select(id,'world-1-4');
 return mixSession.start({checkpoint:saved});
};
fixedUpdate=function(){if(['error','idle'].includes(mixSession.snapshot().phase)){if(mode!=='menu'){mode='menu';resetGameAudio();showOverlay('MARIO MIX','返回角色选择','场景已安全停止，请重新选择角色。','选择角色');}return;}const result=mixNative.fixed();mixReportPhase();return result;};
// Read-only diagnostics are safe in ordinary builds; mutation remains test-only.
window.MarioMix=Object.freeze({
 version:'0.4.0',
 catalog:()=>({characters:E04Modules.gameCatalog.characters(),scenes:E04Modules.gameCatalog.scenes(),compatibility:E04Modules.gameCatalog.compatibility()}),
 session:()=>({...mixSession.snapshot(),nativeMode:mode,stage:c23Campaign.stage,hero}),
});
if(new URLSearchParams(location.search).has('test'))window.__mixFramework={
 select:(character,scene)=>mixSession.select(character,scene),
 start:()=>mixSession.start(),pause:()=>mixSession.pause(),resume:()=>mixSession.resume(),
 events:()=>mixSession.events(),
 state:()=>({...window.MarioMix.session(),transients:{shots:shots.length,mixShots:mixShots.length,enemyShots:enemyShots.length,particles:particles.length,keys:keys.size,touch:touch.size,pipe:!!pipeTransition},tankActive:!!tankRoute?.active}),
};
