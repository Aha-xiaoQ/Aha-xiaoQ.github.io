// Hit regions use the same canvas transform as their painted icons. Pointer
// coordinates remain in CSS pixels until drawing, so camera / scale changes
// cannot leave invisible or misplaced HTML hitboxes over the game.
const pointers=new WeakMap();
function pointerFor(canvas){
  let p=pointers.get(canvas);if(p)return p;
  p={active:false,x:0,y:0};pointers.set(canvas,p);
  const root=canvas.closest?.('#stage')||canvas;
  root.addEventListener('pointermove',e=>{p.active=e.pointerType!=='touch';p.x=e.clientX;p.y=e.clientY;},{passive:true,capture:true});
  root.addEventListener('pointerleave',()=>p.active=false,{passive:true});
  root.ownerDocument.defaultView.addEventListener('blur',()=>p.active=false);
  return p;
}
export function updateCanvasTooltipPointer(canvas,e){const p=pointerFor(canvas);p.active=e.pointerType!=='touch'&&!['pointercancel','pointerleave'].includes(e.type);p.x=e.clientX;p.y=e.clientY;}
export function tooltipPlacement(point,regions,{width,height,padding=8,maxWidth=250}){
  const hit=regions.find(r=>point.x>=r.x&&point.x<r.x+r.w&&point.y>=r.y&&point.y<r.y+r.h);
  if(!hit)return null;
  const w=Math.min(maxWidth,width-padding*2),h=hit.lines.length*16+12;
  return {...hit,box:{x:Math.max(padding,Math.min(width-w-padding,hit.x)),y:Math.max(padding,Math.min(height-h-padding,hit.y+hit.h+5)),w,h}};
}
export function drawCanvasTooltip(g,regions,{width,height,enabled=true}={}){
  const canvas=g.canvas,p=pointerFor(canvas);if(!enabled||!p.active)return null;
  const rect=canvas.getBoundingClientRect(),fit=Math.min(rect.width/canvas.width,rect.height/canvas.height);
  if(!fit)return null;
  const px=(p.x-rect.left-(rect.width-canvas.width*fit)/2)/fit,py=(p.y-rect.top-(rect.height-canvas.height*fit)/2)/fit;
  const q=g.getTransform().inverse().transformPoint({x:px,y:py}),tip=tooltipPlacement(q,regions,{width,height});
  if(!tip)return null;
  const b=tip.box;g.save();g.globalAlpha=1;g.fillStyle='#101a3cf2';g.fillRect(Math.round(b.x),Math.round(b.y),b.w,b.h);
  g.strokeStyle='#899dcc';g.lineWidth=1;g.strokeRect(Math.round(b.x)+.5,Math.round(b.y)+.5,b.w-1,b.h-1);
  g.textAlign='left';g.textBaseline='top';
  tip.lines.forEach((line,i)=>{g.font=(i?'':'bold ')+'12px "Microsoft YaHei",sans-serif';g.fillStyle=i?'#ebedff':'#ffe5a0';g.fillText(line,Math.round(b.x+7),Math.round(b.y+6+i*16),b.w-14);});
  g.restore();return {id:tip.id,lines:tip.lines,box:b};
}
