export const CHARACTER_PREVIEWS=Object.freeze({
 mario:{key:'overworld',music:true},bill:{key:'bill_theme',music:true},
 megaman:{key:'mega_theme',music:true},ryu:{key:'ng07_theme',music:true},
 tank:{key:'t06_start',music:true},sandboxTrio:{key:'selection_terra_boss',music:true,offset:13},
 sonic:{key:'credits_sonic',music:true},ori:{key:'credits_ori',music:true},
 jackal:{key:'jackal_level1',music:true},
});
/** A menu owns one finite preview. A late decode cannot revive a retired selection. */
export function createCharacterPreview({prepare,start,stop,enabled}){
 let generation=0,selected=null,voice=null,pending=null;
 function cancel(){generation++;if(voice)stop(voice);voice=null;pending=null;selected=null;}
 async function select(id){
  if(selected===id)return;
  cancel();const cue=CHARACTER_PREVIEWS[id];if(!cue||!enabled())return;
  selected=id;const ticket=generation;pending=id;
  try{await prepare(cue,id);if(ticket===generation&&selected===id&&enabled()){voice=start(cue,id);if(!voice)selected=null;}}
  catch(error){if(ticket===generation)selected=null;throw error;}
  finally{if(ticket===generation)pending=null;}
 }
 return {select,cancel,view:()=>({selected,pending,generation,playing:!!voice&&!voice.stopped})};
}
