/* Candidate selection UI inside the native closure. No second canvas or game loop. */
const e04Roster=new URLSearchParams(location.search).has('legacy')?E04Modules.gameCatalog.characters().map(character=>({...character,stage:E04Modules.gameCatalog.scene(character.defaultScene).stage})):E04Modules.campaignCatalog.characters().map(character=>({id:character.id,...character.selection,portrait:character.bindings.portrait,stage:11}));
if(!new URLSearchParams(location.search).has('legacy'))e04Roster.push({id:'random',name:'RANDOM',origin:'MARIO MIX',stage:11});
const e04Picker=$('heroPicker'),e04MenuMap=terrainBuild();
// Capture only canvases already owned by the shipped legacy renderers. An
// automatically created extension card is not an installed portrait source.
const e04LegacyPortraitCanvases=new Map([...e04Picker.querySelectorAll('[data-hero]')].map(button=>[button.dataset.hero,button.querySelector('canvas')]).filter(([,canvas])=>canvas));
let e04PortraitRegistry=null;
const e04View={camera:0,room:'surface',frame:0},e04PortraitBounds=new WeakMap();
let e04Page=0;
const e04PageCount=Math.ceil(e04Roster.length/8);
// Native-pixel geometry for the roster panel. Each arrow is seven
// pixels wide, with the same eight-pixel gap from its panel edge.
function e04PageArrowLayout(panel){
 const cy=panel.y+panel.h/2;
 return [-1,1].map(dir=>({dir,x:dir<0?panel.x-15:panel.x+panel.w+8,y:cy-6,
  hit:{x:dir<0?panel.x-24:panel.x+panel.w,y:cy-12,w:24,h:24}}));
}
function e04DrawPageArrows(panel){
 const columns=e04PageArrowLayout(panel).flatMap(a=>Array.from({length:7},(_,i)=>({x:a.x+(a.dir<0?i:6-i),y:a.y+6-i,h:1+2*i})));
 for(const c of columns)rect(c.x-1,c.y-1,3,c.h+2,'#000');
 for(const c of columns)rect(c.x,c.y,1,c.h,'#fff0bc');
}
for(const r of e04Roster)if(!e04Picker.querySelector('[data-hero="'+r.id+'"]')){
 const b=document.createElement('button');b.type='button';b.className='secondary';b.dataset.hero=r.id;
 const c=document.createElement('canvas');c.width=64;c.height=80;b.append(c);e04Picker.append(b);
}
const e04PageButtons=[-1,1].map(delta=>{
 const b=document.createElement('button');b.type='button';b.id=delta<0?'e04PreviousPage':'e04NextPage';b.className='e04-roster-page';b.hidden=e04PageCount<=1;
  b.setAttribute('aria-label',delta<0?'上一页角色':'下一页角色');b.onclick=()=>e04Choose(e04Roster[((e04Page+delta+e04PageCount)%e04PageCount)*8].id);
 const hit=e04PageArrowLayout({x:24,y:47,w:208,h:94}).find(a=>a.dir===delta).hit;
 for(const [key,value]of Object.entries(hit))b.style.setProperty('--page-'+key,value/(key==='x'||key==='w'?256:240)*100+'%');
 $('overlay').querySelector('.overlay-box').append(b);return b;
});
const e04NativeDraw=draw,e04NativeInput=c23Input,e04NativeEarly=t17Early.handle;
const e04AspectKey='mariomix.display.aspect',e04AspectControl=document.createElement('div');
e04AspectControl.id='e04AspectControl';
e04AspectControl.innerHTML='<span id="e04AspectLabel">画面比例</span><div id="e04Aspect" role="group" aria-labelledby="e04AspectLabel"><button type="button" data-aspect="classic" aria-pressed="true">经典原生<small>16:15</small></button><button type="button" data-aspect="wide" aria-pressed="false">宽屏<small>16:9</small></button></div>';
$('fullButton').closest('.buttons').after(e04AspectControl);
let e04Aspect='classic';
try{if(localStorage.getItem(e04AspectKey)==='wide')e04Aspect='wide';}catch{}
function e04ApplyAspect(){
 W=e04Viewport.setAspect(e04Aspect).width; // Compatibility mirror for unmigrated scenes.
 document.body.style.setProperty('--menu-width',256/W*100+'%');
 document.body.dataset.aspect=e04Aspect;
 document.body.style.setProperty('--frame-aspect',e04Aspect==='wide'?'16 / 9':'16 / 15');
 document.body.style.setProperty('--frame-factor',e04Aspect==='wide'?'1.777777778':'1.066666667');
 for(const button of $('e04Aspect').querySelectorAll('[data-aspect]'))button.setAttribute('aria-pressed',String(button.dataset.aspect===e04Aspect));
}
e04ApplyAspect();
for(const button of $('e04Aspect').querySelectorAll('[data-aspect]'))button.addEventListener('click',e=>{
 if(e.detail)button.blur();
 if(e04Aspect===button.dataset.aspect)return;
 e04Aspect=button.dataset.aspect;e04ApplyAspect();
 try{localStorage.setItem(e04AspectKey,e04Aspect);}catch{}
 $('e04Aspect').dispatchEvent(new Event('change',{bubbles:true}));draw();
});
$('e04Aspect').addEventListener('keydown',e=>e.stopPropagation());
$('e04Aspect').addEventListener('keyup',e=>e.stopPropagation());
let e04ViewportInsets=()=>({}),e04ViewportFitted=()=>{};
function e04FitViewport(){
 const stage=$('stage'),insets=e04ViewportInsets(),left=Math.max(0,insets.left||0),top=Math.max(0,insets.top||0);
 const width=Math.max(1,stage.clientWidth-left-Math.max(0,insets.right||0)),height=Math.max(1,stage.clientHeight-top-Math.max(0,insets.bottom||0));
 const fit=E04Modules.fitRect({width,height},canvas);
 for(const [key,value]of [['--canvas-width',fit.width+'px'],['--canvas-height',fit.height+'px'],['--canvas-center-x',(left+width/2)+'px'],['--canvas-center-y',(top+height/2)+'px']]){
  if(stage.style.getPropertyValue(key)!==value)stage.style.setProperty(key,value);
 }
 e04ViewportFitted({left:left+(width-fit.width)/2,top:top+(height-fit.height)/2,width:fit.width,height:fit.height});
}
new ResizeObserver(()=>{e04FitViewport();if(mode==='paused')draw();}).observe($('stage'));
let e04PadHeld=[],e04Axis=[0,0],e04WasOpen=false;
const e04MenuOpen=()=>c23Menu&&mode==='menu';
function e04Sync(){
 const open=e04MenuOpen();document.body.classList.toggle('e04-select',open);
 if(open||hero!=='tank')tankRoute?.leave();
 document.body.classList.toggle('e04-paused',mode==='paused');
 if(mode==='paused'){
  $('heroPicker').hidden=true;$('o30Continue').hidden=true;$('overlayCharacters').hidden=false;
  $('mainAction').setAttribute('aria-label','继续游戏');$('overlayCharacters').setAttribute('aria-label','返回角色选择');
 }
 if(open&&!e04WasOpen){
  const pad=c23SafePad();e04PadHeld=Array.from(pad?.buttons||[],b=>b.pressed||b.value>.5);
  e04Axis=[0,0];
 }
 e04WasOpen=open;
 if(!open)return;
 e04Picker.hidden=false;
 e04Page=Math.floor(Math.max(0,e04Roster.findIndex(r=>r.id===hero))/8);
 for(const [i,r]of e04Roster.entries()){
  const b=e04Picker.querySelector('[data-hero="'+r.id+'"]');
  b.style.setProperty('--select-column',i%4);b.style.setProperty('--select-row',Math.floor(i%8/4));
  b.hidden=Math.floor(i/8)!==e04Page;b.tabIndex=b.hidden?-1:0;
  if(b.getAttribute('aria-pressed')!==String(hero===r.id))b.setAttribute('aria-pressed',String(hero===r.id));
  b.setAttribute('aria-label',r.id==='random'?'随机角色':r.name+' / '+r.origin+' / WORLD 1-'+(r.stage-10));
 }
 e04Picker.setAttribute('aria-label','选择角色：左右上下方向键移动，Enter 开始');
 $('mainAction').setAttribute('aria-label','开始 '+(e04Roster.find(r=>r.id===hero)?.name||'游戏'));
 if(c23Campaign.stage!==14)$('o30Continue').hidden=true;
}
function e04Choose(id,focus=true){
 if(!e04MenuOpen())return;
 const r=e04Roster.find(r=>r.id===id);if(!r)return;
 if(c23Campaign.stage!==r.stage){c23Campaign.chosen[r.stage]=id;c23Choose(r.stage);}
 selectHero(id);e04Sync();
 if(focus)e04Picker.querySelector('[data-hero="'+id+'"]').focus({preventScroll:true});
}
function e04Move(dx,dy){
 const i=Math.max(0,e04Roster.findIndex(r=>r.id===hero));
 const col=(i%4+dx+4)%4,row=(Math.floor(i/4)+dy+2)%2;
 e04Choose(e04Roster[row*4+col].id);
}
e04Picker.addEventListener('click',e=>{
 const b=e.target.closest('[data-hero]');if(!b||!e04MenuOpen())return;
 e.preventDefault();e.stopImmediatePropagation();e04Choose(b.dataset.hero);
},true);
e04Picker.addEventListener('focusin',e=>{
 const b=e.target.closest('[data-hero]');if(b&&e04MenuOpen()&&b.dataset.hero!==hero)e04Choose(b.dataset.hero,false);
});
// Existing start/continue buttons and their handlers remain the activation authority.
t17Early.handle=function(e){
 if(mode==='paused'&&['keydown','keyup'].includes(e.type)&&!e.ctrlKey&&!e.metaKey&&!e.altKey&&!e.target?.closest?.('input,textarea,select,[contenteditable="true"]')){
  if(['ArrowUp','ArrowDown'].includes(e.code)){
   if(e.type==='keydown'&&!e.repeat)(document.activeElement===$('mainAction')?$('overlayCharacters'):$('mainAction')).focus({preventScroll:true});
   return true;
  }
  if(['Enter','Space'].includes(e.code)){
   if(e.type==='keydown'&&!e.repeat)(document.activeElement===$('overlayCharacters')?$('overlayCharacters'):$('mainAction')).click();
   return true;
  }
 }
 if(!e04MenuOpen()||!['keydown','keyup'].includes(e.type)||e.ctrlKey||e.metaKey||e.altKey||e.target?.closest?.('input,textarea,select,[contenteditable="true"]'))return e04NativeEarly(e);
 const moves={ArrowLeft:[-1,0],KeyA:[-1,0],ArrowRight:[1,0],KeyD:[1,0],ArrowUp:[0,-1],KeyW:[0,-1],ArrowDown:[0,1],KeyS:[0,1]};
 if(moves[e.code]){if(e.type==='keydown'&&!e.repeat)e04Move(...moves[e.code]);return true;}
 if(e.code==='KeyC'&&!$('o30Continue').hidden){if(e.type==='keydown'&&!e.repeat)$('o30Continue').click();return true;}
 if(['Enter','Space','KeyK','KeyZ'].includes(e.code)){
  if(e.type==='keydown'&&!e.repeat){
   if(document.activeElement===$('o30Continue')&&!$('o30Continue').hidden)$('o30Continue').click();else $('mainAction').click();
   c23BlockJump=true;
  }return true;
 }
 return e04NativeEarly(e);
};
c23Input=function(){
 if(!e04MenuOpen())return e04NativeInput();
 const pad=c23SafePad(),pressed=Array.from(pad?.buttons||[],b=>b.pressed||b.value>.5),axes=pad?.axes||[];
 const edge=i=>pressed[i]&&!e04PadHeld[i];
 const dx=(axes[0]>.55||pressed[15]?1:0)-(axes[0]<-.55||pressed[14]?1:0);
 const dy=(axes[1]>.55||pressed[13]?1:0)-(axes[1]<-.55||pressed[12]?1:0);
 if(dx&&dx!==e04Axis[0])e04Move(dx,0);else if(dy&&dy!==e04Axis[1])e04Move(0,dy);
 if(edge(1)&&!$('o30Continue').hidden){$('o30Continue').click();c23BlockJump=true;}
 else if(edge(0)||edge(9)){
  padStartPrevious=!!pressed[9];padConfirmPrevious=!!pressed[0];padActionConsumed=!!pressed[0];
  if(document.activeElement===$('o30Continue')&&!$('o30Continue').hidden)$('o30Continue').click();else $('mainAction').click();
  c23BlockJump=true;
 }
 e04PadHeld=pressed;e04Axis=[dx,dy];c23PadPrev=pressed;
 return {left:false,right:false,down:false,jump:false,run:false};
};
function e04Panel(x,y,w,h){
 rect(x+2,y+2,w,h,'#000');rect(x,y,w,h,'#c84c0c');
 rect(x,y,w,1,'#fff0bc');rect(x,y,1,h,'#fc9838');rect(x+w-1,y,1,h,'#803000');rect(x,y+h-1,w,1,'#803000');
 for(const [px,py]of [[x+3,y+3],[x+w-5,y+3],[x+3,y+h-5],[x+w-5,y+h-5]]){rect(px,py,2,2,'#000');rect(px,py,1,1,'#fff0bc');}
}
function e04PortraitBoundsFor(c){
 if(!c)return null;
 let b=e04PortraitBounds.get(c);const now=performance.now();
 if(!b||now>b.refresh){
  // Bounds use the existing rendered portrait, never a replacement asset.
  const pixels=c.getContext('2d').getImageData(0,0,c.width,c.height).data;
  let left=c.width,top=c.height,right=-1,bottom=-1;
  for(let yy=0;yy<c.height;yy++)for(let xx=0;xx<c.width;xx++)if(pixels[(yy*c.width+xx)*4+3]>128){left=Math.min(left,xx);right=Math.max(right,xx);top=Math.min(top,yy);bottom=Math.max(bottom,yy);}
  b={left,top,w:right-left+1,h:bottom-top+1,refresh:now+1000};e04PortraitBounds.set(c,b);
 }
 return b;
}
function e04Portrait(c,x,y,w,h,targetContext=ctx){
 const b=e04PortraitBoundsFor(c);
 if(!b||b.w<=0||b.h<=0)return false;
 const scale=Math.min(w/b.w,h/b.h),dw=Math.max(1,Math.floor(b.w*scale)),dh=Math.max(1,Math.floor(b.h*scale));
 targetContext.drawImage(c,b.left,b.top,b.w,b.h,Math.floor(x+(w-dw)/2),Math.floor(y+(h-dh)/2),dw,dh);
 return true;
}
function e04LegacyPortrait(id,{selectionInset=0}={}){
 const c=e04LegacyPortraitCanvases.get(id);
 if(!c||!Number.isInteger(c.width)||c.width<=0||!Number.isInteger(c.height)||c.height<=0)throw new TypeError('Uninstalled legacy portrait source '+id);
 return {source:'legacy-canvas:'+id,selectionInset,
  ready(){const bounds=e04PortraitBoundsFor(c);return !!bounds&&bounds.w>0&&bounds.h>0;},
  draw(context,bounds){return e04Portrait(c,bounds.x,bounds.y,bounds.w,bounds.h,context);},
 };
}
function e04InstallPortraits(registry){
 if(!registry||typeof registry.portrait!=='function'||typeof registry.drawPortrait!=='function')throw new TypeError('Portrait installation requires a runtime registry');
 registry.validateRoster(e04Roster.filter(item=>item.id!=='random').map(item=>item.id));
 if(e04PortraitRegistry&&e04PortraitRegistry!==registry)throw new TypeError('Portrait installation cannot change during a runtime generation');
 e04PortraitRegistry=registry;
}
function e04Render(options={}){
 // The picker is parsed before runtime-content installs its ports. Do not
 // expose a fake ready frame or replace an unloaded portrait with RANDOM.
 if(!e04PortraitRegistry||!e04Roster.filter(item=>item.id!=='random').every(item=>e04PortraitRegistry.portrait(item.id).ready()))return;
 // Logical resolution matches the classic renderer. No gameplay state is reassigned.
 e04Viewport.prepare(canvas,ctx);
 drawBackground(e04View);
 for(const t of e04MenuMap.tiles.values())if(t.x<Math.ceil(W/16))drawBlock(t,e04View);
 for(const p of e04MenuMap.pipes)if(p.x<W)drawPipe(p,e04View);
 ctx.save();ctx.translate((W-256)/2,0);
 const r=e04Roster.find(r=>r.id===hero)||e04Roster[0];
 hud(r.name,8,8);hud('000000',8,18);
 // Use the same half-size HUD coin as the campaign, aligned with its count.
 ctx.save();ctx.translate(100,18);ctx.scale(.5,.5);sprite('coin0',0,0);ctx.restore();
 hud('×00',112,18);hud('WORLD',158,8);hud('1-'+(r.stage-10),166,18);hud('TIME',E04Modules.mainlineTimeBounds(256,{menu:true}).x,8);
 text('SELECT YOUR HERO',128,34,'#000',1,true);text('SELECT YOUR HERO',127,33,'#fff',1,true);
 e04Panel(24,47,208,94);
  if(e04PageCount>1)e04DrawPageArrows({x:24,y:47,w:208,h:94});
 for(const [i,item]of e04Roster.slice(e04Page*8,e04Page*8+8).entries()){
  const x=32+(i%4)*48,y=55+Math.floor(i/4)*40,on=item.id===hero;
  rect(x-1,y-1,42,36,on?'#fff0bc':'#803000');rect(x,y,40,34,on?'#f8b800':'#000');
  if(on){rect(x-3,y-3,6,2,'#fff');rect(x-3,y-3,2,6,'#fff');rect(x+37,y+33,6,2,'#fff');rect(x+41,y+29,2,6,'#fff');}
  if(item.id==='random')sprite('question0',x+12,y+9);
  else{
   const inset=e04PortraitRegistry.portrait(item.id).selectionInset;
   e04PortraitRegistry.drawPortrait(item.id,ctx,{x:x+2+inset,y:y+1+inset,w:36-inset*2,h:32-inset*2,frame:e04View.frame});
  }
 }
 e04Panel(32,149,192,35);
 hud(r.name,129,157,'#000',true);hud(r.name,128,156,'#fff',true);
 text(r.origin,129,172,'#000',1,true);text(r.origin,128,171,'#fff0bc',1,true);
 const resume=options.resume??(!$('o30Continue').hidden&&r.stage===14);
 text(resume?'NEW GAME':'PRESS START',resume?80:128,193,'#000',1,true);
 text(resume?'NEW GAME':'PRESS START',resume?79:127,192,options.action==='new'?'#fff0bc':'#fff',1,true);
 if(resume){text('CONTINUE',180,193,'#000',1,true);text('CONTINUE',179,192,'#fff0bc',1,true);}
 sprite('small_idle',options.levelFocus?61:options.action==='continue'?139:24,options.levelFocus?207:192);
 if(options.levelSelect){text('LEVEL SELECT',129,211,'#000',1,true);text('LEVEL SELECT',128,210,options.levelFocus?'#fff0bc':'#fff',1,true);}
 rect(0,224,256,16,'#000');text('ARROWS SELECT   ENTER/A START',128,229,'#fff0bc',1,true);
 ctx.restore();
 // The initial HTML is legacy markup: reveal only after a complete native frame.
 if(!document.body.hasAttribute('data-ready'))document.body.setAttribute('data-ready','');
}
draw=function(){
 e04Sync();
 if(e04MenuOpen()){e04Render();e04FitViewport();return;}
 if(c23Campaign.stage!==13&&c23Campaign.stage!==14){
   e04Viewport.prepare(canvas,ctx);
 }
 if(hero==='tank'&&tankRoute){tankRoute.render();c23UpdateCompletion();}else e04NativeDraw();
 e04FitViewport();
 if(mode==='paused')e04RenderPause();
};
function e04RenderPause(level='1-'+(c23Campaign.stage-10)){
 const scale=canvas.width/W,h=canvas.height/scale,y=Math.floor((h-104)/2);
 ctx.save();ctx.setTransform(scale,0,0,scale,0,0);ctx.imageSmoothingEnabled=false;
 rect(0,0,W,h,'#0009');ctx.translate((W-256)/2,0);e04Panel(40,y,176,104);
 hud('PAUSED',129,y+14,'#000',true);hud('PAUSED',128,y+13,'#fff',true);
 text('WORLD '+level,128,y+29,'#fff0bc',1,true);
 const returning=document.activeElement===$('overlayCharacters');
 text('CONTINUE',128,y+48,returning?'#fff':'#fff0bc',1,true);
 text('CHARACTER SELECT',128,y+69,returning?'#fff0bc':'#fff',1,true);
 sprite('small_idle',54,y+(returning?61:40));
 text('ESC / START TO RESUME',128,y+89,'#fff0bc',1,true);
 ctx.restore();
 // Match hit targets to the actual Canvas bounds, including wide arena letterboxing.
 const cr=canvas.getBoundingClientRect(),sr=$('stage').getBoundingClientRect(),o=$('overlay');
 for(const [key,value]of Object.entries({left:cr.left-sr.left,top:cr.top-sr.top,width:cr.width,height:cr.height}))o.style.setProperty('--pause-'+key,value+'px');
 o.style.setProperty('--pause-continue',(y+42)/h*100+'%');o.style.setProperty('--pause-select',(y+63)/h*100+'%');o.style.setProperty('--pause-hit-height',20/h*100+'%');
}
// Re-synchronize CSS on direct legacy draw/overlay transitions as well as native RAF.
new MutationObserver(e04Sync).observe($('overlay'),{attributes:true,attributeFilter:['class']});
if(new URLSearchParams(location.search).has('test'))window.__e04Select={render:e04Render,choose:e04Choose,roster:e04Roster.map(r=>r.id)};
if(new URLSearchParams(location.search).has('test'))window.__e04Viewport={
 read:()=>({width:W,height:H,camera,canvasWidth:canvas.width,canvasHeight:canvas.height,phase:o28.phase}),
 pointer:e=>{o32Point(e);return {x:o24Mouse.x,y:o24Mouse.y,valid:o24Mouse.valid};}
};
