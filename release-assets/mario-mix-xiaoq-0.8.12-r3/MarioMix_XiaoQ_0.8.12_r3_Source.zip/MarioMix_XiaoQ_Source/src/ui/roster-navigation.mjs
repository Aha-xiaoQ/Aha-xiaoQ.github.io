// Navigation uses real entries only; empty cells never become focus targets.
export function moveRosterIndex(count,index,dx=0,dy=0){
 if(!Number.isInteger(count)||count<1)return -1;
 index=Math.max(0,Math.min(count-1,index));
 const page=Math.floor(index/8),start=page*8,end=Math.min(count,start+8),local=index-start,row=Math.floor(local/4),col=local%4;
 if(dx){
  const next=index+Math.sign(dx);
  if(Math.floor((local+Math.sign(dx))/4)===row&&next>=start&&next<end)return next;
  const pages=Math.ceil(count/8),target=((page+Math.sign(dx)+pages)%pages)*8;
  return Math.min(count-1,target+row*4+(dx<0?3:0));
 }
 if(dy){const target=start+(1-row)*4+col;return target<end?target:row===1?Math.min(start+col,end-1):index;}
 return index;
}
