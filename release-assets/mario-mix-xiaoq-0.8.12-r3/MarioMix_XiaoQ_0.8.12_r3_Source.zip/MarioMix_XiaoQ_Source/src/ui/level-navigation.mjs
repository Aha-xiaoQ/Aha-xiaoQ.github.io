// Four stage rows and Back preserve the original pixel menu's dimensions.
export function createLevelNavigation(count,pageSize=4){
  if(!Number.isInteger(count)||count<1||!Number.isInteger(pageSize)||pageSize<1)throw new TypeError('Invalid level navigation size');
  let index=0,page=0;
  const pageCount=Math.ceil(count/pageSize);
  const view=()=>{const start=page*pageSize,end=Math.min(count,start+pageSize);return Object.freeze({index,page,pageCount,start,end,indices:Object.freeze([...Array.from({length:end-start},(_,i)=>start+i),count])});};
  return Object.freeze({view,
    select(next){if(!Number.isInteger(next)||next<0||next>count)throw new RangeError('Invalid level choice');index=next;if(index<count)page=Math.floor(index/pageSize);return view();},
    move(delta){const choices=view().indices,at=choices.indexOf(index);index=choices[(at+Math.sign(delta)+choices.length)%choices.length];return view();},
    turn(delta){const row=index===count?null:index-page*pageSize;page=(page+Math.sign(delta)+pageCount)%pageCount;index=row===null?count:Math.min(count-1,page*pageSize+row);return view();},
  });
}
