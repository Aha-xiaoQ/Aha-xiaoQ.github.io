// Canvas HUD and its DOM controls share logical-pixel anchors.
export function mainlineTimeBounds(width=256,{menu=false}={}){
 const x=menu?(width-256)/2+216:width-48,y=menu?8:16;
 return {x,y,w:31,h:7,right:x+31};
}
export function achievementHudAnchor({left,top,width,height},logicalWidth,{menu=false,nativeScene=false}={}){
 // One logical unit system for glyphs, frame, safe margin and content. Native
 // scenes reserve 16 logical rows; a fixed CSS-pixel strip clips large HUDs.
 const scale=height/240,authorFontSize=8*scale,authorGap=3*scale;
 if(nativeScene)return {right:left+width-17*scale,top:top-14*scale,height:12*scale,authorFontSize,authorGap,pixel:Math.max(1,scale)};
 const time=mainlineTimeBounds(logicalWidth,{menu});
 return {right:left+time.right*width/logicalWidth,top:top+2*scale,
  height:12*scale,authorFontSize,authorGap,pixel:Math.max(1,scale)};
}
export function nativeHudInset({width,height},logicalWidth=256){
 return 16*Math.min(width/logicalWidth,height/256);
}
