const sequence=Object.freeze(['up','up','down','down','left','right','left','right','b','a']);

/** Menu commands enter once per physical press. The recognizer never owns
 * gameplay lives or saved progress: it arms exactly one new-run option. */
export function createMenuLifeCode(){
 let history=[],armed=false;
 return Object.freeze({
  key(code){
   if(code==='KeyA'&&history.length===9)return 'a';
   return ({ArrowUp:'up',KeyW:'up',ArrowDown:'down',KeyS:'down',ArrowLeft:'left',KeyA:'left',ArrowRight:'right',KeyD:'right',KeyB:'b',KeyJ:'b',KeyX:'b',ShiftLeft:'b',ShiftRight:'b',KeyK:'a',KeyZ:'a',Space:'a'})[code]||null;
  },
  push(token){
   const before=history.length;
   history.push(token);
   while(history.length&&!history.every((part,i)=>part===sequence[i]))history.shift();
   const unlocked=history.length===sequence.length;
   if(unlocked){armed=true;history=[];}
   return {unlocked,consumed:unlocked||before===8&&token==='b'};
  },
  resetSequence(){history=[];},
  armed:()=>armed,
  consume(){const lives=armed?30:3;armed=false;history=[];return lives;},
 });
}
