// Source Ryu atlas actions (win 20, run 1..3) with crossover door staging.
// No room change or reward occurs here; the scene owner commits completion.
export function createRelayDeparture(kind){
 if(!['ryu-door','tank-results'].includes(kind))throw new TypeError('Invalid relay departure kind');
 return {version:1,kind,phase:kind==='ryu-door'?'settle':'results',age:0,complete:false};
}
export function validateRelayDeparture(d,kind){
 if(d===undefined)return true;
 if(!d||Object.keys(d).some(k=>!['version','kind','phase','age','complete'].includes(k))||d.version!==1||!['ryu-door','tank-results'].includes(d.kind)||kind&&d.kind!==kind||!Number.isSafeInteger(d.age)||d.age<0||d.age>36000||typeof d.complete!=='boolean'||d.complete!==(d.phase==='complete'))throw new TypeError('Invalid relay departure');
 if(!(d.kind==='ryu-door'?['settle','victory','walk','fade','complete']:['results','complete']).includes(d.phase))throw new TypeError('Invalid relay departure phase');
 if(d.complete&&(d.kind==='ryu-door'?d.age!==24:d.age<330))throw new TypeError('Premature relay departure');
 return true;
}
export function ryuDeparturePresentation(d){
 validateRelayDeparture(d,'ryu-door');
 return {pose:d.phase==='settle'?'air':d.phase==='victory'?'win':d.phase==='walk'?'run':'idle',alpha:d.complete?0:d.phase==='fade'?Math.max(0,1-d.age/24):1};
}
export function stepRyuDeparture(p,n,d,{move,gravity=.28,fallCap=5,exitX=228}){
 validateRelayDeparture(d,'ryu-door');if(d.complete)return;
 p.invuln=0;p.facing=1;p.crouch=false;
 if(p.h!==26){p.y+=p.h-26;p.h=26;}
 for(const key of ['wall','hit','attack','throwPose','spin','buffer'])n[key]=0;n.command=null;
 if(p.ryuCeilingRail){p.ryuCeilingRail.active=false;p.ryuCeilingRail.upTicks=0;}
 p.support=null;d.age++;
 const next=phase=>{d.phase=phase;d.age=0;};
 if(d.phase==='settle'){
  p.vx=0;p.vy=Math.min(fallCap,p.vy+gravity);move(0,p.vy);
  if(p.grounded){p.vx=p.vy=0;next('victory');}
 }else if(d.phase==='victory'){
  p.vx=p.vy=0;if(d.age>=60)next('walk');
 }else if(d.phase==='walk'){
  const before=p.x;p.vx=Math.max(0,Math.min(1.35,exitX-p.x));p.vy=gravity;move(p.vx,p.vy);p.anim+=Math.abs(p.x-before);
  if(p.x>=exitX-.01){p.vx=p.vy=0;next('fade');}
 }else if(d.phase==='fade'){
  p.vx=p.vy=0;if(d.age>=24){d.phase='complete';d.complete=true;}
 }
}
