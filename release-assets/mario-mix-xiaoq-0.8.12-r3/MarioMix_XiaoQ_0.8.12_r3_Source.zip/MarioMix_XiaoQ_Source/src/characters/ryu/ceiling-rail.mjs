// Crossover traversal assist, not an NES collision claim. The original wall
// climb is required to acquire it; the rail never replaces real room solids.
export const RYU_CEILING_RAIL=Object.freeze({mainlineY:64,barY:80,climbTicks:6,dropTicks:20});
export function validateRyuCeilingRail(s){
 if(s===undefined)return true;
 if(!s||Object.keys(s).some(k=>!['version','active','upTicks','dropTicks','serial','side','y'].includes(k))||s.version!==1||typeof s.active!=="boolean"||![s.upTicks,s.dropTicks,s.serial].every(Number.isSafeInteger)||s.upTicks<0||s.upTicks>6||s.dropTicks<0||s.dropTicks>20||s.serial<0||s.serial>1000000||![-1,0,1].includes(s.side)||![64,80].includes(s.y)||s.active&&(!s.side||s.dropTicks))throw new TypeError('Invalid Ninja ceiling rail state');
 return true;
}
export function stepRyuCeilingRail(p,n,input,{y,minX=16,maxX=240-p.w,blocked,move,speed=2.1,acceleration=.8,brake=1.05}){
 if(![64,80].includes(y)||typeof blocked!=="function"||typeof move!=="function")throw new TypeError('Invalid Ninja ceiling rail world');
 const s=p.ryuCeilingRail??={version:1,active:false,upTicks:0,dropTicks:0,serial:0,side:0,y};
 validateRyuCeilingRail(s);
 // A room's top line is local state. Carrying it into a different environment
 // cannot keep the previous room's invisible support.
 if(s.y!==y){s.active=false;s.upTicks=0;s.dropTicks=0;s.side=0;s.y=y;}
 if(s.dropTicks)s.dropTicks--;
 const free=body=>!blocked(body),candidate={...p,y:y-p.h};
 const release=()=>{s.active=false;s.upTicks=0;s.dropTicks=RYU_CEILING_RAIL.dropTicks;n.wall=0;n.wallFrom=s.side;n.wallLock=RYU_CEILING_RAIL.dropTicks;n.coyote=0;p.grounded=false;p.support=null;};
 if(p.dying||n.hit||p.scriptedMotion||p.mainlineWater||!free(candidate)||s.active&&Math.abs(p.y+p.h-y)>3){
  if(s.active)release();else s.upTicks=0;
  return {controlled:false,event:null};
 }
 if(s.active&&(input.down||input.jumpPressed)){
  release();n.buffer=0;p.y+=2;p.vy=Math.max(1,p.vy);return {controlled:false,event:null};
 }
 let event=null;
 if(!s.active){
  const climbing=!!n.wall&&input.up&&!input.down&&!input.jumpPressed&&!s.dropTicks;
  s.upTicks=climbing?Math.min(RYU_CEILING_RAIL.climbTicks,s.upTicks+1):0;
  const foot=p.y+p.h;
  if(!climbing||s.upTicks<RYU_CEILING_RAIL.climbTicks||foot>y+2.7||foot<y-3)return {controlled:false,event:null};
  s.active=true;s.side=n.wall;s.serial++;event={type:'roof-rail',serial:s.serial,y};
  n.wall=0;n.coyote=0;n.buffer=0;p.y=y-p.h;p.vx=p.vy=0;
 }
 const direction=Math.sign(input.horizontal??input.x??(Number(!!input.right)-Number(!!input.left)));
 const target=direction*speed,delta=direction?acceleration:brake;
 p.vx=p.vx<target?Math.min(target,p.vx+delta):Math.max(target,p.vx-delta);
 if(direction)p.facing=direction;
 const dx=Math.max(minX,Math.min(maxX,p.x+p.vx))-p.x;
 move(dx,0);p.y=y-p.h;p.vy=0;p.grounded=true;p.support='ryu:ceiling-rail';n.wall=0;
 return {controlled:true,event};
}
