import {overlap} from '../../engine/geometry.mjs';
// Dog art and base behavior: pinned MMSound/Ninja-Gaiden objDog and sprDog.
// Spawn spacing and source-family identity are explicit crossover adaptations.
export const RYU_DOG=Object.freeze({w:31,h:16,speed:3,jump:2,gravity:.25,fallCap:4,range:128,contactDamage:2});
export const RYU_DOG_FRAMES=Object.freeze([
 Object.freeze({rect:Object.freeze([0,2,31,16]),anchor:Object.freeze([15,16])}),
 Object.freeze({rect:Object.freeze([32,2,31,16]),anchor:Object.freeze([15,16])}),
 Object.freeze({rect:Object.freeze([64,1,27,17]),anchor:Object.freeze([11,17])}),
]);
export function createRyuDog(id,x,feet,{activated=false,dir=1}={}){
 return {id,uid:id,contractId:'ninja-gaiden:panther',nativeOwner:'ryu',kind:'panther',rf085Dog:true,x,y:feet-RYU_DOG.h,ox:x,oy:feet-RYU_DOG.h,
  w:RYU_DOG.w,h:RYU_DOG.h,hp:1,maxHp:1,vx:0,vy:0,dir:dir<0?-1:1,t:0,flash:0,dead:false,remove:false,active:true,
  dogActive:activated,dogAnim:0,dogFrame:2};
}
export function stepRyuDog(e,p,{camera=0,width=256,blocked,move}){
 if(!e.rf085Dog||e.dead||e.remove)return false;
 const visible=e.x+e.w>=camera&&e.x<=camera+width;
 const grounded=blocked({x:e.x+1,y:e.y+e.h,w:e.w-2,h:.75});
 // Source prtEntity applies gravity before the dog's grounded hop event.
 e.vy=grounded&&e.vy>=0?0:Math.min(RYU_DOG.fallCap,e.vy+RYU_DOG.gravity);
 if(!visible)e.dogActive=false;
 if(!e.dogActive){
  e.vx=0;e.dogFrame=2;e.dir=p.x+p.w/2<e.x+e.w/2?-1:1;
  const dx=Math.max(0,Math.max(e.x-p.x-p.w,p.x-e.x-e.w));
  if(visible&&dx<=RYU_DOG.range&&Math.abs(p.y+p.h-e.y-e.h)<=8)e.dogActive=true;
 }else{
  if(grounded&&e.vy>=0){e.vy=-RYU_DOG.jump;e.dogAnim=0;e.dogFrame=1;}
  e.vx=e.dir*RYU_DOG.speed;
  if(e.dogAnim>3)e.dogFrame=0;e.dogAnim++;
 }
 const hit=move(e,e.vx,e.vy);if(hit)e.dir*=-1;
 if(e.y>272)e.remove=true;
 return true;
}
const solid=q=>!q.hidden&&q.collision==='solid';
function groundRuns(world){
 const rows=(world.solids||[]).filter(q=>solid(q)&&q.y>=176&&q.y<=224).sort((a,b)=>a.y-b.y||a.x-b.x),runs=[];
 for(const q of rows){const last=runs.at(-1);if(last&&last.y===q.y&&q.x<=last.x+last.w+.01)last.w=Math.max(last.w,q.x+q.w-last.x);else runs.push({x:q.x,y:q.y,w:q.w});}
 return runs;
}
export function createRyuDogAmbushPlan(world){
 if(world.mainline!==true||world.underwater||/underwater|castle|sky/i.test(world.setting||'')||world.width<640)return [];
 const rows=[];
 for(const g of groundRuns(world)){
  for(let trigger=Math.max(g.x+176,320);trigger+96<g.x+g.w&&trigger<world.width-320;trigger+=640){
   if(rows.some(q=>Math.abs(q.trigger-trigger)<640))continue;
   const corridor={x:trigger-144,y:g.y-40,w:224,h:40};
   if((world.solids||[]).some(q=>solid(q)&&q.y<g.y&&overlap(corridor,q)))continue;
   if((world.objects||[]).some(q=>q.kind==='portal'&&Math.abs(q.x-trigger)<192))continue;
   rows.push({id:'dog-ambush-'+Math.round(trigger)+'-'+g.y,trigger,feet:g.y});
   if(rows.length===2)return rows;
  }
 }
 return rows;
}
export function stepRyuDogAmbushes(plan,p,world){
 if(!Array.isArray(plan)||plan.length>2)throw new TypeError('Invalid Ninja ambush plan');
 if(!p.grounded||p.dying||p.scriptedMotion||p.mainlineWater||p.vx<=0||typeof world.claimPlacement!=='function')return [];
 if(world.enemies.some(e=>e.rf085Dog&&!e.dead&&!e.remove&&e.x+e.w>world.camera-40&&e.x<world.camera+world.viewportWidth+40))return [];
 const q=plan.find(q=>p.x>=q.trigger&&p.x<q.trigger+80&&Math.abs(p.y+p.h-q.feet)<2);
 if(!q)return [];
 const x=p.x-RYU_DOG.w-96,corridor={x,y:q.feet-40,w:p.x+p.w-x,h:40};
 if(x<0||(world.solids||[]).some(g=>solid(g)&&g.y<q.feet&&overlap(corridor,g)))return [];
 // No materialization on another actor or across a pit after geometry changes.
 const body={x,y:q.feet-RYU_DOG.h,w:RYU_DOG.w,h:RYU_DOG.h};
 if(world.enemies.some(e=>!e.dead&&!e.remove&&overlap(body,e)))return [];
 const supports=groundRuns(world);if(!supports.some(g=>g.y===q.feet&&g.x<=x&&g.x+g.w>=p.x+p.w))return [];
 if(!world.claimPlacement('ryu',q.id))return [];
 return [createRyuDog(q.id,x,q.feet)];
}
