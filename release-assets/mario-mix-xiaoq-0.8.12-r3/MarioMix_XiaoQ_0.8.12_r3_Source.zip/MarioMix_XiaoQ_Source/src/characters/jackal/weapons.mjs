import {inputEdge} from '../../engine/input-contract.mjs';
import {overlap} from '../../engine/geometry.mjs';
import {createTerrainImpact} from '../../engine/terrain-impact.mjs';
import {jackalPlayerPose,JACKAL_MAINLINE_SCALE} from './presentation.mjs';
import {jackalExplosionParts} from '../../scenes/jackal/source-animation.mjs';

// Bank7 tblGrenadeSpeed and tblBazookaSpeed, including their fixed-point
// diagonal values. A main weapon occupies its one slot until all blast phases
// finish. Carry never contains a projectile or a pressed-button latch.
export const JACKAL_WEAPONS=Object.freeze({
 grenade:Object.freeze({life:40,vectors:[[0,-2],[1.5,-1.5],[2,0],[1.5,1.5],[0,2],[-1.5,1.5],[-2,0],[-1.5,-1.5]]}),
 rocket:Object.freeze({life:22,vectors:[[0,-4],[2.75,-2.75],[4,0],[2.75,2.75],[0,4],[-2.75,2.75],[-4,0],[-2.75,-2.75]]}),
});
const terrain=createTerrainImpact({owner:'jackal',weapon:'main-weapon',materials:['brick','block'],revealsHidden:true});
export function createJackalWeapons({sound=()=>{}}={}){
 let bullets=[],main=null,previous={},serial=0,disposed=false;
 const center=(p,world)=>{const pose=jackalPlayerPose(p,{native:!world.mainline});return {x:pose.x,y:pose.y};};
 function fire(p,input,world){
  if(disposed||p.dying)return;
  const scale=world.mainline?JACKAL_MAINLINE_SCALE:1;
  const attack=!!input.attack,secondary=!!input.secondary;
  const b=inputEdge(input,'attackPressed',[],()=>attack&&!previous.attack),a=inputEdge(input,'secondaryPressed',[],()=>secondary&&!previous.secondary);
  previous={attack,secondary};
  if((b||attack&&world.tick%32===0)&&bullets.length<3){
   const c=center(p,world);bullets.push({id:'jackal-mg-'+(++serial),kind:'machinegun',...c,scale,vx:0,vy:-6*scale,age:0,phase:'flight',remaining:24});sound('jackal_machinegun');
  }
  if(a&&!main){
   const tier=p.jackalTier||0,name=tier?'rocket':'grenade',spec=JACKAL_WEAPONS[name],vector=spec.vectors[(p.jackalTendency||p.jackalHeading||1)-1];
   main={id:'jackal-main-'+(++serial),kind:name,...center(p,world),scale,vx:vector[0]*scale,vy:vector[1]*scale,age:0,phase:'flight',remaining:spec.life,tier,heading:p.jackalTendency||p.jackalHeading||1,hitIds:[],blastAge:0};
   sound(tier?'jackal_bazooka':'jackal_grenade');
  }
 }
 function contact(shot,from,to,world,options){return world.projectile?.(shot,from,to,options)||null;}
 function beginBlast(shot,world,event){shot.phase='blast';shot.blastAge=0;shot.impact=null;sound(event);}
 function hitBlast(shot,world){
  const boxes=jackalExplosionParts(shot).map(q=>({x:q.x-q.w/2,y:q.y-q.h/2,w:q.w,h:q.h}));
  for(const e of world.enemies||[]){if(e.dead||e.remove||shot.hitIds.includes(e.id)||!boxes.some(b=>overlap(b,e)))continue;
   // The world's projectile query owns occlusion and real enemy contact.
   const ray={attackInstanceId:shot.attackInstanceId||shot.id};
   const hit=contact(ray,{x:shot.x,y:shot.y},{x:e.x+e.w/2,y:e.y+e.h/2},world,{kind:'jackal-main-weapon',damage:5,radius:1,terrainImpact:terrain});
   if(hit?.kind==='enemy')shot.hitIds.push(hit.targetId||e.id);
  }
  for(const g of world.solids||[])if(boxes.some(b=>overlap(b,g))&&['brick','block'].includes(g.material))world.breakBlock?.(g.id,{kind:'jackal-main-weapon',x:shot.x,y:shot.y,terrainImpact:terrain,attackInstanceId:shot.attackInstanceId||shot.id});
 }
 function step(world){
  if(disposed)return;
  for(const shot of bullets){shot.age++;
   if(shot.phase==='impact'){if(--shot.remaining<=0)shot.dead=true;continue;}
   const from={x:shot.x,y:shot.y},to={x:shot.x,y:shot.y+shot.vy},hit=contact(shot,from,to,world,{kind:'jackal-machinegun',damage:1,radius:shot.scale,terrainImpact:terrain});shot.x=hit?.x??to.x;shot.y=hit?.y??to.y;
   if(hit||--shot.remaining<=0){shot.phase='impact';shot.remaining=5;if(hit?.kind==='world')sound('jackal_hardhit');}
  }
  bullets=bullets.filter(s=>!s.dead);
  if(main){main.age++;
   if(main.phase==='flight'){
    const from={x:main.x,y:main.y},to={x:main.x+main.vx,y:main.y+main.vy};
    // Grenade flies over source scenery, but remains able to hit an enemy.
    const queryWorld=main.kind==='grenade'&&world.grenadeProjectile?{...world,projectile:world.grenadeProjectile}:world;
    const hit=contact(main,from,to,queryWorld,{kind:'jackal-main-weapon',damage:5,radius:3*main.scale,terrainImpact:terrain});main.x=hit?.x??to.x;main.y=hit?.y??to.y;
    if(hit?.kind==='enemy'&&hit.targetId)main.hitIds.push(hit.targetId);
    if(hit||--main.remaining<=0)beginBlast(main,world,hit?.kind==='enemy'?'jackal_impact':main.kind==='rocket'?'jackal_rocketground':'jackal_blastground');
   }else{hitBlast(main,world);if(++main.blastAge>=(main.tier>=2?40:24))main=null;}
  }
 }
 function view(){return {bullets:bullets.map(s=>({...s})),main:main?{...main,hitIds:[...main.hitIds]}:null};}
 return {fire,step,view,clear(){bullets=[];main=null;previous={};},dispose(){this.clear();disposed=true;}};
}
