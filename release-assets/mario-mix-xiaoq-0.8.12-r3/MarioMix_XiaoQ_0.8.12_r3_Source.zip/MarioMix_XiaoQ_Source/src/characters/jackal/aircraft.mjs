import {jackalSourceDirection,jackalSourceVelocity} from '../../scenes/jackal/source-projectiles.mjs';
import {overlap} from '../../engine/geometry.mjs';

// Aircraft are transient scene actors, never equipment or replacement map
// objects. Original Bank6 bomber drops at 16/48/80/112, bomb flight=64 and
// impact=24 (three eight-tick frames). Horizontal flight is the Mario-world
// projection; source bomb aim/speed and harmless airborne phase are retained.
export function createJackalAirTraffic({sound=()=>{}}={}){
 let bomber=null,bombs=[],serial=0,heli={phase:'waiting',age:0,x:0,y:0},key=null;
 function reset(){if(bomber)bomber.entity.remove=true;bomber=null;bombs=[];serial=0;heli={phase:'waiting',age:0,x:0,y:0};key=null;}
 function beginTick(room,p,world,ledger){
  if(key!==room.key){reset();key=room.key;if(ledger.departed.includes(room.id))heli.phase='gone';}
  const cx=p.x+p.w/2,cy=p.y+p.h/2;
  if(!ledger.flyovers.includes(room.id)&&cx>=(room.airTrigger??room.facilities[0]?.x-160)){
   ledger.flyovers.push(room.id);
   const dir=room.id==='3-1'?1:-1,width=world.viewportWidth||256;
   const x=(world.camera||0)+(dir<0?width+32:-32),y=Math.max(room.minY+32,cy-64);
   // Bank7 hitbox $C5: no jeep or machine-gun collision, main weapon hits;
   // health=1. Rotate the source 10x18 hit core with horizontal flight.
   const entity={id:room.key+':bomber',contractId:'jackal-nes:bomber',nativeOwner:'foe-port',foeSource:'jackal-nes',type:'bomber',sourceId:59,
    x:x-9,y:y-5,w:18,h:10,hp:1,maxHp:1,dir,age:0,dead:false,remove:false};
   world.enemies?.push(entity);bomber={x,y,dir,age:0,entity};
  }
  if(bomber&&(bomber.entity.dead||bomber.entity.remove||bomber.entity.defeatEvent))bomber=null;
  if(bomber){
   bomber.age++;bomber.x+=bomber.dir*2;
   Object.assign(bomber.entity,{x:bomber.x-9,y:bomber.y-5});
   if(bomber.age%4===0)sound('jackal_plane');
   if([16,48,80,112].includes(bomber.age)){
    const direction=jackalSourceDirection(cx-bomber.x,cy-bomber.y),velocity=jackalSourceVelocity(direction,0x11);
    bombs.push({id:room.key+':bomb:'+ ++serial,owner:'jackal-aircraft',x:bomber.x,y:bomber.y,...velocity,direction,age:0,phase:'flight',blastAge:0,damaged:false});
    sound('jackal_grenade');
   }
   if(bomber.age>=Math.max(160,((world.viewportWidth||256)+96)/2)){bomber.entity.remove=true;bomber=null;}
  }
  for(const b of bombs){
   if(b.phase==='flight'){
    b.x+=b.vx;b.y+=b.vy;
    if(++b.age===64){b.phase='impact';b.vx=b.vy=0;b.blastAge=0;sound('jackal_rocketground');}
   }else if(++b.blastAge>=24){b.phase='gone';continue;}
   if(b.phase==='impact'&&!b.damaged&&overlap(world.hurtbox||p,{x:b.x-10,y:b.y-10,w:20,h:20})){
    b.damaged=true;world.damage?.({type:'jackal-bomb',owner:b.owner,attackInstanceId:b.id});
   }
  }
  bombs=bombs.filter(b=>b.phase!=='gone');
  if(!room.pad)return;
  const near=cx>=room.pad.x-144;
  if((heli.phase==='waiting'||heli.phase==='gone'&&ledger.cargo.length)&&near){
   // Fly over the approach strip before settling at the original pad anchor.
   heli={phase:'inbound',age:0,x:room.pad.helicopter.x,y:room.pad.helicopter.y+240};
  }
  heli.age++;
  if(heli.phase==='inbound'){
   heli.y=Math.max(room.pad.helicopter.y,heli.y-2.5);
   if(heli.y===room.pad.helicopter.y)heli={...heli,phase:'landed',age:0};
  }else if(heli.phase==='outbound'){
   heli.y-=2.5;
   if(heli.y<room.minY-80)heli={...heli,phase:'gone',age:0};
  }
  // Source parked/loading states are silent; rotor requests belong to flight.
  if(['inbound','outbound'].includes(heli.phase)&&heli.age%4===0)sound('jackal_rotor');
 }
 function canBoard(){return ['landed','loading'].includes(heli.phase);}
 function board(){if(!canBoard())throw new Error('Jackal boarding requires a landed helicopter');heli={...heli,phase:'loading',age:0};}
 function endTick(room,ledger,arrivals){
  if(heli.phase==='loading'&&!ledger.cargo.length&&!arrivals.length){
   heli={...heli,phase:'outbound',age:0};
   if(!ledger.departed.includes(room.id))ledger.departed.push(room.id);
  }
 }
 function view(){return {flyover:bomber&&!bomber.entity.dead&&!bomber.entity.remove?{x:bomber.x,y:bomber.y,dir:bomber.dir,age:bomber.age,id:bomber.entity.id}:null,bombs:bombs.map(b=>({...b})),helicopter:{...heli}};}
 return {beginTick,endTick,canBoard,board,view,reset};
}
