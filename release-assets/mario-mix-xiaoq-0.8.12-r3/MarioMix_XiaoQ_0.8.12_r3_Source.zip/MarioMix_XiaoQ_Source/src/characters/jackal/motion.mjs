import {overlap} from '../../engine/geometry.mjs';
import {existingOverlapDeepens} from '../../engine/world-collision.mjs';
import {mainlineBottomLimit} from '../../engine/mainline-movement.mjs';

// NES-US headings are one-based clockwise from north. Native diagonal speed
// is one pixel on each axis, not a normalized continuous-angle vector.
export const JACKAL_DIRECTIONS=Object.freeze([[0,-1],[1,-1],[1,0],[1,1],[0,1],[-1,1],[-1,0],[-1,-1]].map(Object.freeze));
export const JACKAL_MOTION=Object.freeze({nativeSpeed:1,mainlineSpeed:1.4,turnFrames:4,bodyWidth:12,bodyHeight:12});
export function jackalHeading(x,y){return JACKAL_DIRECTIONS.findIndex(v=>v[0]===Math.sign(x)&&v[1]===Math.sign(y))+1;}
export function turnJackal(current,target,tick){
 if(!Number.isInteger(current)||current<1||current>8||!Number.isInteger(target)||target<1||target>8)throw new TypeError('Invalid Jackal heading');
 if(tick%JACKAL_MOTION.turnFrames||current===target)return current;
 const diff=current-target,step=diff>0?(diff>=4?1:-1):(-diff>=4?-1:1);
 return (current-1+step+8)%8+1;
}

/** Shared-world rectangles are supplied by the caller. There is no Tank grid
 * alignment, borrowed controller, gravity or extra simulation clock here. */
export function moveJackal(body,dx,dy,world){
 if(![dx,dy,world.width,world.height].every(Number.isFinite)||world.width<body.w||world.height<body.h)throw new TypeError('Invalid Jackal movement extent');
 const solids=world.solids||[],start={x:body.x,y:body.y};
 for(const [axis,delta,other,size,crossSize]of [['x',dx,'y','w','h'],['y',dy,'x','h','w']]){
  if(!delta)continue;
  let distance=Math.abs(delta),sign=Math.sign(delta);const contacts=[];
  for(const q of solids){
   if(q.hidden||q.collision==='none'||q.dead||!(body[other]<q[other]+q[crossSize]&&body[other]+body[crossSize]>q[other]))continue;
   // A platform is a real walk surface in Mario's world, so vehicles cannot
   // drive through its body. Native water/barricades are explicit rectangles.
   const gap=sign>0?q[axis]-body[axis]-body[size]:body[axis]-q[axis]-q[size];
   if(gap>=-1e-7)distance=Math.min(distance,Math.max(0,gap));
   else if(overlap(body,q))contacts.push(q);
  }
  // Only an explicit shared sky-return portal permits crossing the bottom.
  // Keep the usual obstacle sweep and every other room boundary intact.
  const limit=axis==='y'?mainlineBottomLimit(world,body):world.width-body.w;
  const next={...body,[axis]:Math.max(axis==='y'?(world.minY||0):0,Math.min(limit,body[axis]+sign*distance))};
  if(!existingOverlapDeepens(body,next,contacts))body[axis]=next[axis];
 }
 // The original native diagonal probe stops both axes when a leading edge
 // is blocked. Mario's rectangle world deliberately supports wall sliding.
 if(!world.mainline&&dx&&dy&&(Math.abs(body.x-start.x-dx)>1e-7||Math.abs(body.y-start.y-dy)>1e-7)){body.x=start.x;body.y=start.y;}
 body.vx=body.x-start.x;body.vy=body.y-start.y;body.grounded=true;body.support=null;
 return Math.abs(body.vx)+Math.abs(body.vy)>1e-7;
}
export function stepJackalMotion(body,input,world,{alignBeforeMove=false}={}){
 // Bank7's 16-entry D-pad table rejects every opposite-direction chord,
 // including a third held direction; subtracting axes alone changes that.
 const conflicting=input.left&&input.right||input.up&&input.down;
 const x=conflicting?0:input.x===undefined?Number(!!input.right)-Number(!!input.left):Math.sign(Number(input.x)||0),y=conflicting?0:input.y===undefined?Number(!!input.down)-Number(!!input.up):Math.sign(Number(input.y)||0);
 const target=jackalHeading(x,y);body.jackalHeading??=1;
 if(target){body.jackalTendency=target;body.jackalHeading=turnJackal(body.jackalHeading,target,world.tick);}
 else body.jackalTendency=body.jackalHeading;
 const speed=world.mainline?JACKAL_MOTION.mainlineSpeed:JACKAL_MOTION.nativeSpeed;
 // A scene may ask the driver to finish its original stepped turn before
 // advancing. Ordinary player control retains the native turn-while-moving.
 const drive=!alignBeforeMove||!target||body.jackalHeading===target;
 moveJackal(body,drive?x*speed:0,drive?y*speed:0,world);body.facing=body.jackalHeading>4?-1:1;body.crouch=false;
 return {hp:body.hp,dead:!!body.dying};
}
