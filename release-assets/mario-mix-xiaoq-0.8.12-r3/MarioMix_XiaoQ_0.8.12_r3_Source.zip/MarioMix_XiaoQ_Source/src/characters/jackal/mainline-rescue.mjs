import {createJackalAirTraffic} from './aircraft.mjs';
import {createJackalFoes} from '../../scenes/jackal/foes.mjs';
import {JACKAL_MAINLINE_SCALE as SCALE} from './presentation.mjs';
import {JACKAL_AIRPORT_BLOCKERS} from '../../scenes/jackal/airport-geometry.mjs';

// One actor-owned ledger travels through the existing equipment port. Source
// rules: automatic boarding; first drop-off 16 ticks, then 32; 4/9/15 POWs
// delivered upgrade the main weapon. Mario placement is an explicit adaptation.
export const JACKAL_RESCUE_LEVELS=Object.freeze(['1-1','3-1','8-1']);
export const JACKAL_AIR_LEVELS=Object.freeze(Array.from({length:32},(_,i)=>`${1+(i>>2)}-${1+i%4}`).filter(id=>!id.endsWith('-4')&&!['2-2','7-2'].includes(id)));
export function jackalAirRoute(world){const level=(world.levelId||'').replace(/^campaign-/,'').replace(/-stage$/,'');
 return world.mainline&&JACKAL_AIR_LEVELS.includes(level)&&!world.underwater&&!/Castle|Sky/.test(world.setting||'')&&world.width>=512?{id:level,minY:world.minY||0,focusY:100,airTrigger:Math.min(384,world.width/3),facilities:[],pad:null}:null;
}
const facilities=JACKAL_RESCUE_LEVELS.flatMap(level=>[level+':normal',level+':upgrade']);
const ids=new Set(facilities.flatMap(id=>Array.from({length:id.endsWith('normal')?4:1},(_,i)=>id+':'+i)));
const keys=['opened','picked','cargo','delivered','credited','lost','flyovers','departed','dropoffTicks'];
export function emptyJackalRescue(){return {opened:[],picked:[],cargo:[],delivered:[],credited:[],lost:[],flyovers:[],departed:[],dropoffTicks:16};}
export function validateJackalRescue(v){
 const fail=()=>{throw new TypeError('Invalid Jackal rescue ledger');};
 // Prior version2 equipment predates aircraft departures; no other omission is accepted.
 if(v&&!Object.hasOwn(v,'departed'))v={...v,departed:[]};
 if(!v||Object.keys(v).some(k=>!keys.includes(k))||keys.some(k=>!Object.hasOwn(v,k)))fail();
 for(const k of keys.filter(k=>k!=='dropoffTicks')){
  if(!Array.isArray(v[k])||new Set(v[k]).size!==v[k].length||v[k].some(id=>!(k==='opened'?facilities.includes(id):k==='flyovers'?JACKAL_AIR_LEVELS.includes(id):k==='departed'?JACKAL_RESCUE_LEVELS.includes(id):ids.has(id))))fail();
 }
 if(!Number.isInteger(v.dropoffTicks)||v.dropoffTicks<1||v.dropoffTicks>32)fail();
 const picked=new Set(v.picked),cargo=new Set(v.cargo),delivered=new Set(v.delivered),lost=new Set(v.lost);
 if(v.picked.some(id=>!v.opened.includes(id.split(':').slice(0,2).join(':')))||v.cargo.some(id=>!picked.has(id)||delivered.has(id)||lost.has(id))||v.delivered.some(id=>!picked.has(id)||lost.has(id))||v.lost.some(id=>!picked.has(id))||v.credited.some(id=>!delivered.has(id))||picked.size!==cargo.size+delivered.size+lost.size)fail();
 return Object.fromEntries(keys.map(k=>[k,Array.isArray(v[k])?[...v[k]]:v[k]]));
}
const intersects=(a,b)=>a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y;
// One source placement owns the art rectangle, the projectile target and the
// original doorway. Scaling art cannot leave a legacy contact core behind.
export function jackalFacilityShape(f){
 const size=f.kind==='normal'?64:32,scale=f.scale??SCALE;
 return {bounds:{x:f.x-size*scale/2,y:f.y-size*scale,w:size*scale,h:size*scale},
  exit:{x:f.x,y:f.y-(f.kind==='normal'?36:24)*scale}};
}
export function jackalRescuePlacement(world){
 const level=(world.levelId||'').replace(/^campaign-/,'').replace(/-stage$/,'');
 if(!world.mainline||!world.entryRoom||!JACKAL_RESCUE_LEVELS.includes(level)||/water|underwater|castle/i.test(world.setting||''))return null;
 // Stable authored placement must not collide with our own installed blockers.
 const geometry=(world.placementGeometry||world.solids||[]).filter(g=>!g.hidden&&g.collision==='solid'),objects=world.objects||[];
 const end=objects.find(o=>o.kind==='exit')?.x;if(!Number.isFinite(end))return null;
 // Use the original final stair run, including the spaced steps in 8-1.
 const peak=geometry.filter(g=>g.x<end&&g.y===80&&g.h>=120).sort((a,b)=>b.x-a.x)[0];
 if(!peak)return null;let stairX=peak.x;
 for(let y=96;y<=192;y+=16){const step=geometry.filter(g=>g.x<stairX&&g.x+g.w>=stairX-32&&g.y===y&&g.y+g.h===208).sort((a,b)=>b.x-a.x)[0];if(step)stairX=step.x;}
 const clear=box=>!geometry.some(g=>intersects(box,g))&&!objects.some(o=>['portal','exit','checkpoint'].includes(o.kind)&&intersects(box,{...o,w:o.w||16,h:o.h||16}));
 function site(start,width,height){
  for(let x=Math.round(start/16)*16;x<start+256;x+=16){
   const at={x,y:64},box={x:x-width/2-8,y:at.y-height-8,w:width+16,h:height+16};
   const guard={x:x+width/2+48,y:38,w:36,h:36};
   if(clear(box)&&clear(guard))return {...at,guard:{x:guard.x+18,y:guard.y+18}};
  }return null;
 }
 const house=site(end*.17,64*SCALE,64*SCALE),upgrade=site(end*.5,32*SCALE,32*SCALE);
 if(!house||!upgrade)return null;
 // A vehicle-only upper playfield preserves the Mario map rather than
 // shrinking this original 128x96 fenced airport or covering its blocks.
 const pad={x:stairX-128*SCALE-48,y:-64,w:128*SCALE,h:96*SCALE,scale:SCALE};
 if(!clear(pad))return null;
 pad.helicopter={x:pad.x+48*SCALE,y:pad.y+48*SCALE};
 pad.boarding={x:pad.x+104*SCALE,y:pad.y+48*SCALE};
 return {id:level,minY:-112,focusY:120,stairX,facilities:[{id:level+':normal',kind:'normal',...house,scale:SCALE,sourceId:28,count:4,emerge:72},{id:level+':upgrade',kind:'upgrade',...upgrade,scale:SCALE,sourceId:21,count:1,emerge:28}],pad};
}
export function createJackalMainlineRescue({sound=()=>{}}={}){
 let room=null,lastTick=-1,arrivals=[];
 const spawner=createJackalFoes(),traffic=createJackalAirTraffic({sound});
 function ledger(p){return p.jackalRescue??=emptyJackalRescue();}
 function upgrade(p){p.jackalTier=Math.min(3,(p.jackalTier||0)+1);p.power=p.jackalTier;p.weapon=p.jackalTier?'bazooka':'grenade';sound('jackal_upgrade');}
 function reconcile(p,world,{capture=true}={}){
  if(!room)return;const r=ledger(p);
  for(const f of room.facilities){
   const entity=world.enemies.find(e=>e.id==='jackal-rescue-house:'+f.id);
   if(entity)f.entity=entity;
   if(capture&&f.entity?.defeatEvent&&!r.opened.includes(f.id))r.opened.push(f.id);
   if(r.opened.includes(f.id)&&f.entity){f.entity.dead=true;f.entity.remove=true;}
  }
 }
 function prepare(world){
  const key=world.levelId+':'+world.roomId;
  if(room?.key===key){world.setMovementBlockers?.('jackal',room.obstacles);for(const f of room.facilities){const e=world.enemies.find(e=>e.id==='jackal-rescue-house:'+f.id);if(e)f.entity=e;}return;}
  const placement=jackalRescuePlacement(world);lastTick=-1;arrivals=[];traffic.reset();
  if(!placement){const air=jackalAirRoute(world);room=air?{...air,obstacles:[],key,age:0}:null;world.setMovementBlockers?.('jackal',[]);return;}
  const list=placement.facilities.map(f=>{
   const id='jackal-rescue-house:'+f.id;let entity=world.enemies.find(e=>e.id===id);
   const shape=jackalFacilityShape(f);
   if(!entity){entity=spawner.spawn({sourceId:f.sourceId,id,x:f.x},f.y);Object.assign(entity,shape.bounds,{jackalFacility:f.id,jackalProjection:'topdown'});world.enemies.push(entity);}
   const guardId='jackal-rescue-guard:'+f.id;
   if(!world.enemies.some(e=>e.id===guardId)){
    const guard=spawner.spawn({sourceId:5,id:guardId,x:f.guard.x},f.guard.y);
    Object.assign(guard,{x:f.guard.x-18,y:f.guard.y-18,w:36,h:36,jackalProjection:'topdown'});world.enemies.push(guard);
   }
   if(world.claimPlacement?.('jackal','facility-watch:'+f.id)!==false){
    for(let n=0;n<(f.kind==='normal'?2:1);n++){
     const guardId='jackal-house-watch:'+f.id+':'+n;
     if(world.enemies.some(e=>e.id===guardId))continue;
     const centerX=f.x+(n?-1:1)*(shape.bounds.w/2+24),centerY=f.y-12;
     const watch=spawner.spawn({sourceId:n?2:1,id:guardId,x:centerX},centerY);
     Object.assign(watch,{x:centerX-6,y:centerY-9,w:12,h:18,jackalProjection:'topdown'});world.enemies.push(watch);
    }
   }
   const sx=shape.exit.x,sy=shape.exit.y;
   return {...f,...shape,entity,openAge:0,pows:Array.from({length:f.count},(_,i)=>({id:f.id+':'+i,ordinal:i,x:sx-6,y:sy-9,sx,sy,w:12,h:18,age:0,walking:true,flash:f.kind==='upgrade'}))};
  });
  const obstacles=JACKAL_AIRPORT_BLOCKERS.map((b,i)=>({id:'jackal:airport:'+placement.id+':'+i,x:placement.pad.x+b.x*SCALE,y:placement.pad.y+b.y*SCALE,w:b.w*SCALE,h:b.h*SCALE,collision:'solid'}));
  obstacles.push(...list.map(f=>({id:'jackal:house:'+f.id,...f.bounds,collision:'solid'})));
  room={...placement,facilities:list,obstacles,key,age:0};world.setMovementBlockers?.('jackal',obstacles);
 }
 function step(p,world){
  if(!world.mainline||p.dying||lastTick===world.tick)return;lastTick=world.tick;
  const r=ledger(p),cx=p.x+p.w/2,cy=p.y+p.h/2;
  if(!room){for(const id of r.delivered)if(!r.credited.includes(id)){r.credited.push(id);world.addScore(500);}return;}room.age++;
  reconcile(p,world);traffic.beginTick(room,p,world,r);
  for(const f of room.facilities)if(r.opened.includes(f.id)){
   f.openAge++;
   for(const q of f.pows){
   // Original warehouse queue: HELP first, then the next POW exits only
   // after the preceding one has boarded. The upgrade hut has no HELP delay.
   if(r.picked.includes(q.id)||f.kind==='normal'&&(f.openAge<=64||q.ordinal>0&&!r.picked.includes(f.pows[q.ordinal-1].id)))continue;
   q.age++;
   const elapsed=q.age,walk=Math.min(f.emerge,elapsed),speed=(q.flash?1:.5)*SCALE;
   q.x=q.sx-6+(q.flash?0:walk*speed);q.y=q.sy-9+(q.flash?walk*speed:0);q.walking=elapsed<f.emerge;
   if(q.walking)continue;
   if(Math.abs(cx-(q.x+q.w/2))<24&&Math.abs(cy-(q.y+q.h/2))<24){
    r.picked.push(q.id);r.cargo.push(q.id);sound('jackal_powpickup');if(q.flash){upgrade(p);world.reportObjective?.('weapon-upgraded',p.jackalTier);}
   }
  }}
  if(traffic.canBoard()&&r.cargo.length&&Math.abs(cx-room.pad.boarding.x)<16*SCALE&&Math.abs(cy-room.pad.boarding.y)<16*SCALE){
   if(--r.dropoffTicks===0){const id=r.cargo.shift();r.delivered.push(id);r.dropoffTicks=32;traffic.board();
    arrivals.push({id,x:cx,y:cy,startX:cx,startY:cy,targetX:room.pad.helicopter.x,age:0,phase:'walk',facing:room.pad.helicopter.x<cx?-1:1,flash:r.cargo.length===0});if([4,9,15].includes(r.delivered.length))upgrade(p);world.reportObjective?.('rescue-delivered',r.delivered.filter(q=>q.startsWith(room.id+':')).length);
   }
  }
  // Keep the original horizontal walk/8-tick gait. The requested short
  // goodbye at the helicopter uses the original waiting/waving frames; this
  // sixteen-tick hold is a presentation adaptation, not a new source sprite.
  for(const q of arrivals){q.age++;q.x=q.startX+(q.targetX-q.startX)*Math.min(1,q.age/96);q.phase=q.age>=96?'wave':'walk';if(q.age===112)sound('jackal_powdeliver');}
  // An in-flight scene change must not lose or double-award a delivered POW.
  for(const id of r.delivered)if(!r.credited.includes(id)&&(!arrivals.some(q=>q.id===id)||arrivals.find(q=>q.id===id).age>=112)){r.credited.push(id);world.addScore(500);}
  arrivals=arrivals.filter(q=>q.age<112);traffic.endTick(room,r,arrivals);
 }
 return {prepare,reconcile,step,bounds(){return room?.pad?{minY:room.minY,focusY:room.focusY,cameraFrames:[{x:room.pad.x,w:room.pad.w}]}:{minY:0,focusY:100};},motionWorld(world){return room&&!world.setMovementBlockers?{...world,solids:[...world.solids,...room.obstacles]}:world;},reset(){room=null;arrivals=[];lastTick=-1;traffic.reset();},view(p){
  if(!room||!p)return null;const r=ledger(p);
  return {id:room.id,facilities:room.facilities.map(f=>({id:f.id,kind:f.kind,x:f.x,y:f.y,scale:f.scale,bounds:{...f.bounds},guard:f.guard,open:r.opened.includes(f.id),help:f.kind==='normal'&&f.openAge<=64})),pad:room.pad,tick:room.age,cargo:r.cargo.length,delivered:r.delivered.length,
   ...traffic.view(),
   pows:room.facilities.flatMap(f=>r.opened.includes(f.id)?f.pows.filter(q=>!r.picked.includes(q.id)&&q.age>0).map(q=>({...q})):[]),arrivals:arrivals.map(q=>({...q}))};
 }};
}
