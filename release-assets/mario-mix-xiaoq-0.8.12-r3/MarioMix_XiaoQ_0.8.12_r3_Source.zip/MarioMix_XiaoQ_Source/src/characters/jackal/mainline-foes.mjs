import {resolveWalkPresentation} from '../../engine/motion-presentation.mjs';
import {createJackalFoes, jackalEnemyDefinition} from '../../scenes/jackal/foes.mjs';
import {moveEnemyBody, firstProjectileContact} from '../../engine/world-collision.mjs';
import {jackalInfantryPose} from '../../scenes/jackal/source-animation.mjs';

const SCALE=1.5;
const infantry=e=>e.type==='infantry'||e.type==='sentry';
const owned=e=>e?.nativeOwner==='foe-port'&&e.foeSource==='jackal-nes'&&e.contractId==='jackal-nes:'+e.type;
const solid=q=>!q.hidden&&['solid','oneway'].includes(q.collision);

// Authored Mario enemies remain intact. Fill only genuinely empty topdown
// travel windows, with stable placements and a room budget (never per-frame waves).
export function planJackalPatrols(world){
 const water=world.underwater===true;
 if(!world.mainline||(!water&&!world.entryRoom)||/Castle|Sky/.test(world.setting||'')||(!water&&/Under/.test(world.setting||''))||world.width<1024)return [];
 const out=[],occupied=world.enemies.filter(e=>!e.dead&&!e.remove&&e.type!=='round-bullet');
 let tanks=occupied.filter(e=>e.foeSource==='jackal-nes'&&e.type==='tank').length;
 for(let slot=0,x0=water?512:384;x0<world.width-384&&out.length<(water?3:5);slot++,x0+=water?896:384){
  if([...occupied,...out].some(e=>e.foeSource==='jackal-nes'&&Math.abs(e.x+e.w/2-x0)<192))continue;
  const sourceId=water?8:tanks<2&&slot%4===2?7:slot%3===2?2:1,w=[7,8].includes(sourceId)?24:12,h=[7,8].includes(sourceId)?24:18,pad=sourceId===7?24:16;
  let point=null;
  for(const y of [112,144,80]){for(const dx of [0,48,-48,96,-96]){
   const x=x0+dx,rect={x:x-w/2-pad,y:y-h/2-pad,w:w+pad*2,h:h+pad*2};
   if(rect.y<(world.minY||0)+32||rect.y+rect.h>world.height-32||
    world.solids.some(g=>solid(g)&&rect.x<g.x+g.w&&rect.x+rect.w>g.x&&rect.y<g.y+g.h&&rect.y+rect.h>g.y)||
    [...occupied,...out].some(e=>Math.abs(e.x+e.w/2-x)<144)||
    world.objects.some(o=>['spawn','exit','portal'].includes(o.kind)&&Math.abs(o.x-x)<128))continue;
   point={id:world.roomId+':jackal-open:'+slot,sourceId,x:x-w/2,y:y-h/2,w,h,foeSource:'jackal-nes'};break;
  }if(point)break;}
  if(point){out.push(point);if(sourceId===7)tanks++;}
 }
 // The jeep can travel above the Mario route. Ground enemies sharing X do
 // not fill that plane: reserve at most three widely spaced source infantry
 // encounters, inside the same eight-unit room budget. Water keeps boats only.
 if(!water)for(let slot=0;slot<3&&out.length<8;slot++){
  const x0=Math.round(world.width*(.2+slot*.3)/16)*16;
  if(out.filter(e=>e.patrolPlane==='upper').length>=3)break;
  let point=null;
  for(const y of [(world.minY||0)+48,(world.minY||0)+80]){for(const dx of [0,64,-64]){
   const x=x0+dx,rect={x:x-30,y:y-33,w:60,h:66};
   if(rect.x<192||rect.x+rect.w>world.width-192||rect.y<(world.minY||0)||rect.y+rect.h>world.height-32||
    world.solids.some(g=>solid(g)&&rect.x<g.x+g.w&&rect.x+rect.w>g.x&&rect.y<g.y+g.h&&rect.y+rect.h>g.y)||
    [...occupied,...out].some(e=>Math.abs(e.x+e.w/2-x)<192&&Math.abs(e.y+e.h/2-y)<96)||
    world.objects.some(o=>['spawn','exit','portal','checkpoint'].includes(o.kind)&&Math.abs(o.x-x)<128))continue;
   point={id:world.roomId+':jackal-upper:'+slot,sourceId:slot%3===2?2:1,x:x-6,y:y-9,w:12,h:18,foeSource:'jackal-nes',patrolPlane:'upper'};break;
  }if(point)break;}
  if(point)out.push(point);
 }
 return out;
}

/** Original topdown AI/art with explicit classic/source encounter composition. The Stage owns
 * contact, damage identities, terminal defeat, score, and effect retirement. */
export function createJackalMainlineFoes({render,audio={}}={}){
 if(typeof render?.enemy!=='function')throw new TypeError('Jackal foes require the original enemy renderer');
 const native=createJackalFoes({cue:key=>audio.play?.(key)});
 let generation=0;
 function prepare(world){
  generation++;
  // Keep the first encounter and one in three classic walkers. Every chosen
  // replacement is a new source entity, never a reskinned Mario body.
  if(world.claimPlacement?.('jackal','source-encounter-mix')){
  const candidates=world.enemies.filter(e=>/^(?:enemy-|marker-)?(?:goomba|koopa)$/i.test(e.type||''));
  let tankCount=0,replaced=0;
  for(const [index,old]of candidates.entries()){
   if(index%3===0)continue;
   let sourceId=replaced%5===0&&tankCount<2?7:replaced%3===2?2:1;
   let w=[7,8].includes(sourceId)?24:12,h=[7,8].includes(sourceId)?24:18;
   const fits=(w,h)=>!world.solids.some(g=>solid(g)&&old.x+old.w/2-w/2<g.x+g.w&&old.x+old.w/2+w/2>g.x&&old.y+old.h-h<g.y+g.h&&old.y+old.h>g.y);
   if(!fits(w,h)){sourceId=1;w=12;h=18;if(!fits(w,h))continue;}
   const id=world.roomId+':jackal-replacement:'+old.id,q=native.spawn({id,sourceId,x:old.x+old.w/2},old.y+old.h-h/2);
   Object.assign(q,{w,h,x:old.x+old.w/2-w/2,y:old.y+old.h-h,jackalProjection:'topdown',sourceSpawn:old.id});
   if(typeof world.replaceEnemy!=='function')throw new TypeError('Jackal encounters require the shared enemy replacement port');
   world.replaceEnemy(old,q);replaced++;if(sourceId===7)tankCount++;
  }
  }
  if(world.claimPlacement?.('jackal','open-space-patrol-v1'))for(const point of planJackalPatrols(world)){const q=native.spawn({id:point.id,sourceId:point.sourceId,x:point.x+point.w/2},point.y+point.h/2);Object.assign(q,point,{jackalProjection:'topdown',sourceSpawn:'open-space-budget'});world.enemies.push(q);}
  return true;
 }
 function sourceWorld(world,player){
  return {...world,mainline:true,cameraY:world.cameraY||0,player,
   blocksProjectile:(from,to)=>!!firstProjectileContact(from,to,{geometry:world.solids,enemies:[],radius:1}),
   spawnEnemy(q){
    // Stage iterates its mutable array. Births may be visited in that pass,
    // but cannot move or consume their initialization tick until the next one.
    q.id=world.roomId+':jackal:'+generation+':'+q.id;q.jackalBornTick=world.tick;
    world.enemies.push(q);
   }};
 }
 function step(e,world,player){
  if(!owned(e))return false;
  jackalEnemyDefinition(e);
  if(e.jackalBornTick===world.tick){e.age=0;return true;}
  if(e.dead||e.remove)return true;
  // The common Stage has already advanced age. The native source does so too.
  const walkAge=e.walkAge||0,age=e.age||0,x=e.x,y=e.y,vy=e.vy||0;
  e.age=Math.max(0,age-1);
  native.step(e,sourceWorld(world,player));
  if(e.type==='round-bullet'){
   if(e.phase==='impact'){
    world.effects.push({...e,kind:'jackal-round-impact',flat:true,vx:0,vy:0,life:8,age:0,flash:0});
    e.remove=true;
   }
   return true;
  }
  if(['barracks','gate','bomber'].includes(e.type))return true;
  if(e.foeSource==='jackal-nes'){
   const dx=e.x-x,dy=e.y-y;e.x=x;e.y=y;const moved=moveEnemyBody(e,dx,dy,world.solids);e.vx=moved.dx;e.vy=moved.dy;
   if(infantry(e)){const pose=resolveWalkPresentation({x,y},e,{vertical:true,age:walkAge,idleFacing:e.facing||1});e.walkHeading=pose.heading;e.facing=pose.facing;e.walkAge=pose.walkAge;e.motionPresentation=pose;}
   return true;
  }

  return true;
 }
 function hurt(e,amount,event={}){
  if(!owned(e)||e.dead||e.remove||e.type==='round-bullet'||!Number.isFinite(amount)||amount<=0||!(e.hp>0))return false;
  jackalEnemyDefinition(e);
  // Machine-gun rounds cannot damage the source's armoured/building objects.
  if(event.kind==='jackal-machinegun'&&!infantry(e))return false;
  const damage=event.kind==='jackal-main-weapon'&&e.type!=='boss-tank'?e.hp:amount;
  e.hp=Math.max(0,e.hp-damage);e.flash=6;
  if(e.hp>0&&event.kind!=='jackal-main-weapon')audio.play?.('jackal_hardhit');
  return true;
 }
 function death(e,tick,event={}){
  if(!owned(e)||e.dead||e.remove)return null;
  const spec=jackalEnemyDefinition(e),crushed=infantry(e);
  if(spec.death.sound!=='source-silent')audio.play?.(spec.death.sound);
  return {kind:'jackal-source-death',flat:true,vx:0,vy:0,life:crushed?32:24,
   dead:true,crushed,flash:0,deathAge:0,deathTick:tick};
 }
 // Source background outlives its foreground turret. The Stage stores these
 // small projections by identity; no selected actor or private cache owns them.
 function background(e){
  if(!owned(e)||e.type!=='turret'||![5,6].includes(e.sourceId))return null;
  const {id,contractId,nativeOwner,foeSource,type,sourceId,x,y,w,h}=e;
  return {id,contractId,nativeOwner,foeSource,type,sourceId,x,y,w,h};
 }
 function drawBackground(g,e){
  if(!background(e))return false;
  if(typeof render.turretBase!=='function')throw new TypeError('Jackal source background requires turretBase renderer');
  render.turretBase(g,{x:e.x+e.w/2,y:e.y+e.h/2,scale:SCALE});return true;
 }
 function draw(g,e,tick){
  if(!owned(e))return false;
  jackalEnemyDefinition(e);
  const effect=e.kind==='jackal-source-death',q={...e,...(effect?{deathAge:e.age,flash:0}: {})};
  if(e.jackalFacility&&!effect)return true; // Composite facility art owns HELP and the building.
  if(e.type==='bomber'&&!effect)return true; // Foreground traffic draws the same target.
  if(!infantry(e)){
   if(e.jackalProjection!=='topdown')return render.enemy(g,{...q,...(e.type==='tank'&&!effect?{groundFoot:e.y+e.h,displayScale:SCALE}:{})},tick);
   g.save();g.translate(e.x+e.w/2,e.y+e.h/2);g.scale(SCALE,SCALE);
   try{return render.enemy(g,{...q,x:-e.w/2,y:-e.h/2},tick);}finally{g.restore();}
  }
  // Original standing/crushed alpha bottom=16, walking bottom=15; anchorY=8.
  // The renderer retains each original frame's own horizontal OAM anchor.
  const bottom=jackalInfantryPose(q).bottom;
  const footAligned=!effect||e.crushed;
  const cx=e.x+e.w/2,cy=footAligned?e.y+e.h-(bottom-8)*SCALE:e.y+e.h/2;
  g.save();g.translate(cx,cy);g.scale(SCALE,SCALE);
  try{return render.enemy(g,{...q,x:-e.w/2,y:-e.h/2},tick);}
  finally{g.restore();}
 }
 return Object.freeze({prepare,step,hurt,death,draw,background,drawBackground});
}
