import {stepJackalMotion,JACKAL_MOTION} from './motion.mjs';
import {createJackalWeapons} from './weapons.mjs';
import {createJackalMainlineRescue,emptyJackalRescue,validateJackalRescue} from './mainline-rescue.mjs';
import {ownsCharacterSupply} from '../../engine/pickup-presentation.mjs';
import {jackalHurtbox} from './presentation.mjs';

export const JACKAL_ACCESS=Object.freeze({travel:'drive',waterTravel:'drive',passage:'body'});
export const JACKAL_INPUT=Object.freeze({version:1,id:'jackal-nes-us-v1',conflicts:'reject',showJumpHelp:false,abilityLabel:'交互',extraLabel:'机枪',touchLabels:{jump:'主武器',attack:'机枪',ability:'交互',extra:null},
 help:'移动　方向键 / WASD<br>机枪　J / X · 主武器　空格 / L',
 actions:{left:{keys:['ArrowLeft','KeyA'],pad:[],touch:['left']},right:{keys:['ArrowRight','KeyD'],pad:[],touch:['right']},up:{keys:['ArrowUp','KeyW'],pad:[],touch:['up']},down:{keys:['ArrowDown','KeyS'],pad:[],touch:['down']},attack:{keys:['KeyJ','KeyX'],pad:[1],touch:['attack']},secondary:{keys:['Space','KeyL'],pad:[0],touch:['jump']},interact:{keys:['KeyE'],pad:[2],touch:['ability']}}});

export function validateJackalCarry(value){
 if(!value||![1,2].includes(value.version)||value.actor!=='jackal'||!Number.isInteger(value.tier)||value.tier<0||value.tier>3||!Number.isInteger(value.heading)||value.heading<1||value.heading>8||Object.keys(value).some(k=>!(value.version===1?['version','actor','tier','heading']:['version','actor','tier','heading','rescue']).includes(k)))throw new TypeError('Invalid Jackal equipment');
 return {version:2,actor:'jackal',tier:value.tier,heading:value.heading,rescue:value.version===1?emptyJackalRescue():validateJackalRescue(value.rescue)};
}
export function createJackalActor({render,audio={}}={}){
 if(!render||typeof render.player!=='function'||typeof render.weapon!=='function'||typeof render.pickup!=='function')throw new TypeError('Jackal requires original render ports');
 let body=null,paused=false,disposed=false,currentWorld=null;
 const weapons=createJackalWeapons({sound:event=>audio.play?.(event)});
 const rescue=createJackalMainlineRescue({sound:event=>audio.play?.(event)});
 const requireBody=p=>{if(disposed||!p||p.hero!=='jackal')throw new TypeError('Invalid Jackal actor instance');return p;};
 function create(character,spawn){
  if(disposed)throw new TypeError('Disposed Jackal actor');weapons.clear();paused=false;
  body={hero:'jackal',motionId:'jackal',x:spawn.x,y:spawn.y,w:character.width||JACKAL_MOTION.bodyWidth,h:character.height||JACKAL_MOTION.bodyHeight,vx:0,vy:0,power:0,weapon:'grenade',jackalTier:0,jackalHeading:1,jackalTendency:1,hp:1,protection:0,star:0,invuln:0,grounded:true,facing:1,crouch:false,airTicks:0,groundTicks:0,jumpBuffer:0,coyote:0};return body;
 }
 function carry(p=body){requireBody(p);return validateJackalCarry({version:2,actor:'jackal',tier:p.jackalTier||0,heading:p.jackalHeading||1,rescue:p.jackalRescue||emptyJackalRescue()});}
 function restoreCarry(p,value){requireBody(p);if(value===null)return true;const v=validateJackalCarry(value);p.jackalTier=v.tier;p.jackalHeading=p.jackalTendency=v.heading;p.power=v.tier;p.weapon=v.tier?'bazooka':'grenade';p.jackalRescue=v.rescue;weapons.clear();if(currentWorld)rescue.reconcile(p,currentWorld,{capture:false});return true;}
 function pickup(p,item){requireBody(p);if(!['jackal-upgrade','jackal-weapon'].includes(item.nativeType||item.kind))return false;
  const level=item.tier===undefined?Math.min(3,p.jackalTier+1):item.tier;if(!Number.isInteger(level)||level<0||level>3)throw new TypeError('Invalid Jackal supply level');
  p.jackalTier=Math.max(p.jackalTier,level);p.power=p.jackalTier;p.weapon=p.jackalTier?'bazooka':'grenade';audio.play?.('jackal_upgrade');return {accepted:true};
 }
 return {id:'jackal',access:JACKAL_ACCESS,create,carry,restoreCarry,
  transportMotion:Object.freeze({kind:'drive',directions:8,arrivalTolerance:.5,
   step(p,input,world){requireBody(p);if(paused)return {hp:p.hp,dead:!!p.dying};currentWorld=world;return stepJackalMotion(p,input,rescue.motionWorld(world),{alignBeforeMove:true});}}),
  hurtbox:jackalHurtbox,
  presentation:Object.freeze({invulnerability:'palette',cameraMargin:12,requires:['drawWorld','drawWorldBehind','drawWorldFront','drawPickup','presentScriptedMotion']}),
  companion:Object.freeze({id:'jackal-pow',source:'jackal-nes'}),
  presentScriptedMotion(p,motion){requireBody(p);const h=motion.x>0?3:motion.x<0?7:motion.y>0?5:motion.y<0?1:p.jackalHeading;p.jackalHeading=p.jackalTendency=h;if(motion.phase==='finish-idle')p.vx=p.vy=0;return true;},
  drawCompanion(g,anchors,view){return render.companion(g,anchors,view);},
  respawnCarry(p){const v=carry(p);v.tier=0;v.heading=1;v.rescue.lost.push(...v.rescue.cargo);v.rescue.cargo=[];v.rescue.dropoffTicks=16;return validateJackalCarry(v);},
  prepareRoom(world){if(disposed)throw new TypeError('Disposed Jackal actor');currentWorld=world;weapons.clear();rescue.prepare(world);return true;},
  roomBounds(){return rescue.bounds();},
  step(p,input,world){requireBody(p);if(paused)return {hp:p.hp,dead:!!p.dying};currentWorld=world;if(p.invuln>0)p.invuln--;return stepJackalMotion(p,input,rescue.motionWorld(world));},
  combat(p,input,world){requireBody(p);if(paused||p.dying)return {hp:p.hp,dead:!!p.dying};
   currentWorld=world;
   for(const e of world.enemies||[])if(world.enemyDefinition?.(e).contact.crush&&Math.abs(p.x+p.w/2-e.x-e.w/2)<13&&Math.abs(p.y+p.h/2-e.y-e.h/2)<13)world.kill(e,{cause:'crush'});
   rescue.reconcile(p,world);weapons.fire(p,input,world);weapons.step(world);rescue.step(p,world);return {hp:p.hp,dead:false};},
  enemyContact(p,e,context,world){requireBody(p);if(context.definition.contact.crush)return world.kill(e,{cause:'crush'})||!!e.defeatEvent;return context.definition.origin==='jackal-nes'&&e.type==='barracks';},
  hurt(p){requireBody(p);audio.play?.('jackal_hardhit');return true;},
  isUpgraded:p=>p.jackalTier>0,
  downgrade(p){requireBody(p);p.jackalTier=p.power=0;p.weapon='grenade';weapons.clear();return true;},
  supply(p){requireBody(p);return {kind:'native-supply',nativeActor:'jackal',nativeType:'jackal-upgrade',tier:Math.min(3,p.jackalTier+1),w:16,h:16};},pickup,
  drawPlayer(g,p,t,v){requireBody(p);render.player(g,p,t,{native:!currentWorld?.mainline,view:v});return true;},
  drawWorldBehind(g){render.rescue?.(g,rescue.view(body));return true;},
  drawWorldFront(g){render.rescueAir?.(g,rescue.view(body));return true;},
  drawWorld(g){render.weapon(g,weapons.view(),currentWorld?.tick||0);return true;},drawPickup(g,item,t){return ownsCharacterSupply(item,'jackal')&&['jackal-upgrade','jackal-weapon'].includes(item.nativeType)?render.pickup(g,item,t):false;},
  reconcileBody(p,world){requireBody(p);p.w=p.h=12;p.x=Math.max(0,Math.min(world.width-p.w,p.x));p.y=Math.max(world.minY||0,Math.min(world.height-p.h,p.y));return true;},
  audio(playing,reason){audio.updateWorld?.(currentWorld,body);if(playing&&!paused&&!disposed&&(!reason||reason==='playing'))audio.resume?.();else audio.suspend?.(reason);return true;},
  sound(event){if(event==='hurt'||event==='powerup')return true;const mapped={death:'jackal_death',life:'jackal_extralife'}[event];if(!mapped)return false;audio.play?.(mapped,event==='death'?{semantic:'player-death',owner:'jackal'}:{});return true;},
  beginDeath(p){requireBody(p);weapons.clear();p.vx=p.vy=0;p.jackalDeathTick=currentWorld?.tick||0;return true;},
  // Vehicle death stays at the impact point. Claim the existing Stage hook so
  // its platform-character jump/fall fallback cannot move the death camera.
  deathStep(p){requireBody(p);p.vx=p.vy=0;return true;},
  reset(){weapons.clear();rescue.reset();body=null;currentWorld=null;paused=false;},
  pause(){paused=true;audio.suspend?.('pause');},resume(){paused=false;audio.resume?.();},
  dispose(){if(disposed)return;weapons.dispose();audio.dispose?.();disposed=true;body=null;currentWorld=null;},
  view(){return {hero:'jackal',weapons:weapons.view(),rescue:rescue.view(body),paused};},
 };
}
