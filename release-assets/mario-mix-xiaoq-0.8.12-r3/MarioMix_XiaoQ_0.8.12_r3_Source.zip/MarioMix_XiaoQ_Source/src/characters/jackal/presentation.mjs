// Original OAM frame alpha bounds, measured from the installed source PNGs.
// The Mario-world vehicle is one uniform 1.5x form: 34.5–36 px long on a
// 16 px grid (2.16–2.25 tiles). Native rooms retain original 1x coordinates.
// Keep the original 12x12 movement core; enlarging art must not silently make
// the one-cell route contract impassable. The visible lower edge owns contact.
export const JACKAL_MAINLINE_SCALE=1.5;
export const JACKAL_PLAYER_FRAMES=Object.freeze([
 ['up',8,16,0,4,16,27],['up-right',12,16,0,4,24,28],
 ['right',12,8,0,0,24,16],['down-right',12,16,0,4,24,28],
 ['down',8,16,0,5,16,28],['down-left',12,16,0,4,24,28],
 ['left',12,8,0,0,24,16],['up-left',12,16,0,4,24,28],
].map(([name,ax,ay,left,top,right,bottom])=>Object.freeze({name:'player1-'+name,ax,ay,left,top,right,bottom})));

/** Rendering and muzzle origin use the same source anchor. No per-frame
 * stretching or independent weapon offset is allowed across the scene port. */
export function jackalPlayerPose(p,{native=true}={}){
 const frame=JACKAL_PLAYER_FRAMES[(p.jackalHeading||1)-1];
 if(!frame)throw new TypeError('Invalid Jackal presentation heading');
 const scale=native?1:JACKAL_MAINLINE_SCALE;
 const x=Math.round(p.x+p.w/2);
 const y=native?Math.round(p.y+p.h/2):Math.round(p.y+p.h)-(frame.bottom-frame.ay)*scale;
 return {frame,x,y,scale,bounds:{x:x+(frame.left-frame.ax)*scale,y:y+(frame.top-frame.ay)*scale,w:(frame.right-frame.left)*scale,h:(frame.bottom-frame.top)*scale}};
}

export function jackalHurtbox(p,{mainline=false}={}){
 if(!mainline)return {x:p.x,y:p.y,w:p.w,h:p.h};
 const pose=jackalPlayerPose(p,{native:false}),size=12*JACKAL_MAINLINE_SCALE;
 return {x:pose.x-size/2,y:pose.y-size/2,w:size,h:size};
}
