import {GINSO_MORTAR_SOURCE as S,GINSO_MORTAR_TUNING as T,GINSO_MORTAR_ROOM as R} from '../../content/ori-ginso-miniboss.mjs';
import {overlap} from '../../engine/geometry.mjs';
const center=q=>({x:q.x+q.w/2,y:q.y+q.h/2});
const ticks=seconds=>Math.round(seconds*60);
/** Fixed-speed low ballistic arc. Null means the original speed cannot reach. */
export function mortarVelocity(a,b){const dx=b.x-a.x,dy=-(b.y-a.y),speed=S.projectileSpeed*T.pixelsPerUnit,g=S.projectileGravity*T.pixelsPerUnit;
 if(Math.abs(dx)<.01)return {vx:0,vy:-speed/60};
 const d=speed**4-g*(g*dx*dx+2*dy*speed*speed);if(d<0)return null;
 const tangent=(speed*speed-Math.sqrt(d))/(g*Math.abs(dx)),cos=1/Math.sqrt(1+tangent*tangent);
 return {vx:Math.sign(dx)*speed*cos/60,vy:-speed*cos*tangent/60};
}
function trajectoryClear(a,b,velocity,w){const frames=Math.abs(velocity.vx)>.01?Math.abs((b.x-a.x)/velocity.vx):Math.max(1,Math.abs((b.y-a.y)/velocity.vy));
 const n=Math.max(1,Math.ceil(frames));for(let i=1;i<n;i++){const t=frames*i/n,x=a.x+velocity.vx*t,y=a.y+velocity.vy*t+.5*S.projectileGravity*T.pixelsPerUnit/3600*t*t;
 if(w.solids.some(q=>q.collision==='solid'&&!q.hidden&&x>q.x&&x<q.x+q.w&&y>q.y&&y<q.y+q.h))return false;}return true;}
export function createGinsoMortarPort({cue=()=>{},draw=()=>false,room=R}={}){
 function change(e,state,w){e.mortarState=state;e.stateAge=0;e.lastStateTick=w.tick;
  if(['emerge','charge','hide'].includes(state))cue(state);}
 function prepare(w){for(const e of w.enemies)if(e.contractId==='ori-pc:mortar'&&!e.mortarState){Object.assign(e,{hp:S.health,maxHp:S.health,
 mortarState:'hidden',stateAge:0,hole:1,shotsFired:0,lastShot:-ticks(S.waitBetweenShots),dir:-1,rotation:0,vx:0,vy:0,hidden:true,safe:2});}}
 function origin(e){const c=center(e);return {x:c.x+e.dir*10,y:e.y+7};}
 function chooseHole(e,p,w){const pc=center(p),candidates=room.holes.map((q,i)=>({...q,index:i,d:Math.hypot(q.x+12-pc.x,q.y+14-pc.y)})).filter(q=>{
  if(q.d<=S.hideDistance*T.pixelsPerUnit||q.d>=S.range*T.pixelsPerUnit)return false;
  const a=origin({...e,...q,dir:pc.x<q.x+12?-1:1}),v=mortarVelocity(a,pc);return v&&trajectoryClear(a,pc,v,w);});
  const q=candidates.sort((a,b)=>b.d-a.d||a.index-b.index)[0];if(!q)return false;e.hole=q.index;e.x=q.x;e.y=q.y;e.rotation=q.rotation;return true;}
 function projectile(e,w){if(e.destroy){e.dead=true;return true;}
  // Bash mutates the exact live record in the registered Ori actor. Preserve
  // its direction, use original BashSpeed, and keep the original gravity.
  if(e.reflected&&!e.bashAdjusted){const d=Math.hypot(e.vx,e.vy)||1,sp=S.bashSpeed*T.pixelsPerUnit/60;e.vx=e.vx/d*sp;e.vy=e.vy/d*sp;e.bashAdjusted=true;e.owner='ori';e.impact=null;}
  const a=center(e);e.vy+=S.projectileGravity*T.pixelsPerUnit/3600;const to={x:a.x+e.vx,y:a.y+e.vy};
  // A source-owned projectile queries real terrain and targets once. It never
  // enters classic reflected motion or collides with its emitting worm.
  const targets=w.enemies.filter(q=>q!==e&&!q.dead&&q.contractId==='ori-pc:mortar'&&e.reflected);
  let hit=null;const n=Math.max(1,Math.ceil(Math.hypot(e.vx,e.vy)/2));
  for(let i=1;i<=n&&!hit;i++){const box={...e,x:a.x+(to.x-a.x)*i/n-e.w/2,y:a.y+(to.y-a.y)*i/n-e.h/2};
   if(w.solids.some(q=>q.collision==='solid'&&!q.hidden&&overlap(box,q)))hit='world';
   else for(const q of targets)if(overlap(box,q)){w.damageEnemy(q,T.reflectedDamage,{id:e.id+'-impact',kind:'ori-bash-reflect',owner:'ori'});hit=q.id;break;}}
  e.x=to.x-e.w/2;e.y=to.y-e.h/2;e.projectileAge=(e.projectileAge||0)+1;
  if(hit||e.projectileAge>=ticks(S.maximumLiveTime)||e.x<-20||e.x>w.width+20||e.y>w.height+30||e.y<-40){e.dead=true;return true;}return true;
 }
 function step(e,w,p){if(e.contractId==='ori-pc:mortar-fire')return projectile(e,w);if(e.contractId!=='ori-pc:mortar')return false;if(e.dead)return true;
  e.stateAge++;if(e.flash>0)e.flash--;const pc=center(p),ec=center(e),distance=Math.hypot(pc.x-ec.x,pc.y-ec.y);
  e.hidden=e.mortarState==='hidden';if(e.hidden)e.safe=2;
  const near=distance<S.range*T.pixelsPerUnit,tooClose=distance<S.hideDistance*T.pixelsPerUnit;
  e.dir=pc.x<ec.x?-1:1;const velocity=mortarVelocity(origin(e),pc),canShoot=near&&!tooClose&&velocity&&trajectoryClear(origin(e),pc,velocity,w);
  if(e.mortarState==='hidden'){if(e.stateAge>=ticks(S.minHideTime)&&chooseHole(e,p,w))change(e,'emerge',w);return true;}
  if(e.mortarState==='emerge'){if(e.stateAge>=40)change(e,'idle',w);return true;}
  if(e.mortarState==='hide'){if(e.stateAge>=14)change(e,'hidden',w);return true;}
  if(tooClose||!near){change(e,'hide',w);return true;}
  if(e.mortarState==='idle'){if(canShoot&&w.tick-e.lastShot>=ticks(S.waitBetweenShots)){e.aimVelocity={...velocity};change(e,'charge',w);}return true;}
  if(e.mortarState==='charge'){if(e.stateAge>=ticks(S.chargingDuration))change(e,'shoot',w);return true;}
  if(e.mortarState==='shoot'){
   if(e.stateAge===ticks(S.shootDelay)&&canShoot){e.aimVelocity={...velocity};const a=origin(e);w.enemies.push({id:e.id+'-fire-'+(++e.shotsFired),kind:'walker',type:'ori-mortar-fire',contractId:'ori-pc:mortar-fire',nativeOwner:'foe-port',
    x:a.x-3,y:a.y-3,w:6,h:6,...velocity,hp:1,dead:false,owner:e.id,projectileAge:0,reflected:false});e.lastShot=w.tick;cue('shoot');}
   if(e.stateAge>=ticks(S.shootingDuration)){change(e,e.shotsFired%3===0?'hide':'idle',w);}return true;
  }throw new TypeError('Unknown mortar state '+e.mortarState);
 }
 function hurt(e,amount,hit){if(e.dead||e.contractId!=='ori-pc:mortar'||e.mortarState==='hidden'||['lava','spikes'].includes(hit.kind))return false;
  e.hp=Math.max(0,e.hp-amount);e.flash=8;cue('hurt');return true;}
 function death(e){if(e.contractId==='ori-pc:mortar-fire')return {kind:'ginso-projectile-impact',life:8,vx:0,vy:0,flat:true};
  if(e.contractId!=='ori-pc:mortar')return null;return {kind:'ginso-mortar-death',life:134,vx:0,vy:0,flat:true};}
 return Object.freeze({prepare,step,hurt,death,draw});
}
