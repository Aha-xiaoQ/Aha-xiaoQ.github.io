import {overlap} from '../../engine/geometry.mjs';
import {existingOverlapDeepens} from '../../engine/world-collision.mjs';

export const TANK_TUNING=Object.freeze({speed:1.4,commandBuffer:8,iceFrames:20,turnAssistDistance:3.5,turnAssistTicks:18});
const directions=[[1,0],[0,1],[-1,0],[0,-1]];
export function tankTileParts(tile,size=16){
  const mask=tile.parts??15,x=tile.x*size,y=tile.y*size;
  return [0,1,2,3].filter(i=>mask&(1<<i)).map(i=>({x:x+(i%2)*8,y:y+Math.floor(i/2)*8,w:8,h:8}));
}

/** World-space vehicle rules. Geometry queries do not expose the legacy closure. */
export function createTankMotion({state:s,geometry,actions,tuning=TANK_TUNING}){
  // A campaign supplies its real world extent. The legacy route and the
  // defense board retain their own authored playfields.
  const limits=()=>s.scene?.playfield||(s.scene?.area==='defense'?{l:24,r:(s.scene.def?.width??256)-24,t:24,b:232}:{l:16,r:s.scene?.def.width-16,t:48,b:208});
  const blocks=t=>s.scene?.area==='campaign'||t.type!=='ground';
  const parts=t=>s.scene?.area==='campaign'&&t.rect?[t.rect]:tankTileParts(t);
  function collides(body){
    const room=s.scene;
    if(!room)return true;
    const limit=limits();
    if(body.x<limit.l||body.y<limit.t||body.x+body.w>limit.r||body.y+body.h>limit.b)return true;
    if(room.area==='defense')return (s.challenge?.blocks||[]).some(t=>!t.dead&&overlap(body,t))||(s.challenge?.base?overlap(body,s.challenge.base):false)||geometry.lifts().some(l=>overlap(body,l));
    return geometry.solidTiles(body).some(t=>blocks(t)&&parts(t).some(q=>overlap(body,q)))||geometry.lifts().some(l=>overlap(body,l));
  }
  function boxes(swept,who){
    const terrain=s.scene.area==='defense'?[...s.challenge.blocks.filter(b=>!b.dead),s.challenge.base]:
      geometry.solidTiles(swept).filter(blocks).flatMap(parts).concat(geometry.lifts());
    const bodies=s.actor.foes.filter(e=>e!==who&&!e.dead&&!e.spawn);if(who!==s.player)bodies.push(s.player);
    return terrain.concat(bodies);
  }
  function move(body,dir,speed){
    if(!Number.isFinite(speed)||speed<=0||!directions[dir])return false;
    const [dx,dy]=directions[dir],initial={x:body.x,y:body.y};
    const limit=limits();
    let distance=Math.min(speed,dx>0?limit.r-body.x-body.w:dx<0?body.x-limit.l:dy>0?limit.b-body.y-body.h:body.y-limit.t);
    const swept={x:body.x+(dx<0?-speed:0),y:body.y+(dy<0?-speed:0),w:body.w+(dx?speed:0),h:body.h+(dy?speed:0)};
    const contacts=[];for(const obstacle of boxes(swept,body)){
      if(!obstacle)continue;
      const cross=dx?body.y<obstacle.y+obstacle.h-.001&&body.y+body.h>obstacle.y+.001:body.x<obstacle.x+obstacle.w-.001&&body.x+body.w>obstacle.x+.001;
      if(!cross)continue;
      const gap=dx>0?obstacle.x-body.x-body.w:dx<0?body.x-obstacle.x-obstacle.w:dy>0?obstacle.y-body.y-body.h:body.y-obstacle.y-obstacle.h;
      if(gap>=-.001)distance=Math.min(distance,Math.max(0,gap));
      else if(overlap(body,obstacle))contacts.push(obstacle);
    }
    distance=Math.max(0,distance);const next={...body,x:body.x+dx*distance,y:body.y+dy*distance};
    if(!existingOverlapDeepens(body,next,contacts,.001)){body.x=next.x;body.y=next.y;}
    const moved=Math.abs(body.x-initial.x)+Math.abs(body.y-initial.y)>.0001;
    if(moved)body.r06Track=(body.r06Track||0)+Math.abs(body.x-initial.x)+Math.abs(body.y-initial.y);
    return moved;
  }
  function turnAssist(dir){
    const body=s.player,axis=dir%2===0?'y':'x',origin=body[axis],offset=s.scene.area==='defense'?0:2,cell=Math.floor((origin-offset)/8);
    const targets=[cell*8+offset,(cell+1)*8+offset].sort((a,b)=>Math.abs(a-origin)-Math.abs(b-origin));
    for(const target of targets){
      const delta=target-origin;if(Math.abs(delta)<.001||Math.abs(delta)>tuning.turnAssistDistance)continue;
      const [dx,dy]=directions[dir],aligned={...body,[axis]:target},forward={...aligned,x:aligned.x+dx*tuning.speed,y:aligned.y+dy*tuning.speed};
      const bodies=s.actor.foes.filter(e=>!e.dead&&!e.spawn);
      if(collides(aligned)||collides(forward)||bodies.some(e=>overlap(aligned,e)||overlap(forward,e)))continue;
      let safe=true;for(let k=1;k<=4;k++)if(collides({...body,[axis]:origin+delta*k/4}))safe=false;
      if(!safe)continue;body[axis]=target;actions.event('tank-corner-align',{axis,delta});return true;
    }
    return false;
  }
  function stepPlayer(input){
    const body=s.player,tank=s.scene.tank;
    for(const key of ['shield','freeze','cool','turnAssist'])if(tank[key]>0)tank[key]--;if(body.invuln)body.invuln--;
    const dir=input.moveDir??null,onIce=s.terrain.some(t=>t.kind==='ice'&&overlap(body,t)),x=body.x,y=body.y;
    if(input.runPressed||input.jumpPressed)tank.fireBuffer=tuning.commandBuffer;else if(tank.fireBuffer)tank.fireBuffer--;
    if(dir!==null){
      if(dir%2!==tank.dir%2)tank.turnAssist=tuning.turnAssistTicks;tank.dir=dir;body.dir=dir;tank.glide=onIce?tuning.iceFrames:0;tank.glideDir=dir;
      if(!move(body,dir,tuning.speed)&&turnAssist(dir)){move(body,dir,tuning.speed);tank.turnAssist=0;}
    }else if(onIce&&tank.glide>0){tank.glide--;if(!move(body,tank.glideDir,tuning.speed*tank.glide/tuning.iceFrames))tank.glide=0;}else tank.glide=0;
    body.vx=body.x-x;body.vy=body.y-y;if(Math.abs(body.vx)+Math.abs(body.vy)>.001)tank.track++;
    if((input.run||input.jump||tank.fireBuffer)&&!tank.cool){const count=s.actor.projectiles.length;actions.shoot(body);if(s.actor.projectiles.length>count)tank.fireBuffer=0;}
    body.grounded=true;body.facing=tank.dir===2?-1:1;actions.commonPlayer(input);
  }
  function clearFortifications(){
    if(s.scene?.area!=='defense'||!s.challenge)return;
    const bodies=[s.player,...s.actor.foes.filter(e=>!e.dead&&!e.spawn)];
    for(const body of bodies){
      if(!collides(body))continue;
      const origin={x:body.x,y:body.y};let chosen=null;
      for(let radius=2;radius<=Math.max(208,limits().r-limits().l)&&!chosen;radius+=2)for(let dx=-radius;dx<=radius&&!chosen;dx+=2){
        const dy=radius-Math.abs(dx);
        for(const sign of dy?[1,-1]:[1]){
          const next={...body,x:origin.x+dx,y:origin.y+dy*sign};
          if(collides(next)||bodies.some(other=>other!==body&&overlap(next,other)))continue;
          chosen=next;break;
        }
      }
      if(chosen){body.x=chosen.x;body.y=chosen.y;body.vx=body.vy=0;actions.event('shovel-safe-position',{player:body===s.player,from:origin,to:{x:body.x,y:body.y}});}
    }
  }
  return Object.freeze({move,collides,stepPlayer,clearFortifications});
}
