// MM1 motion/animation comes from the pinned engine/weapons.asm and OAM tables.
// Tier progression, charge bonuses and damage are crossover tuning, not MM1 values.
export const MEGAMAN_WEAPONS=Object.freeze([
 Object.freeze({id:'buster',name:'豆弹',kind:'megaman-shot',damage:1,chargedDamage:2,sound:'mega_shot_nes'}),
 Object.freeze({id:'rolling-cutter',name:'回旋剪刀',kind:'megaman-cutter',damage:5,chargedDamage:7,sound:'mm1_rolling_cutter'}),
 Object.freeze({id:'fire-storm',name:'烈焰风暴',kind:'megaman-fire',damage:8,chargedDamage:10,sound:'mm1_fire_storm'})
]);
export function megamanWeaponTier(value){return Number.isInteger(value)?Math.max(0,Math.min(2,value)):0;}
const center=p=>({x:p.x+p.w/2,y:p.y+p.h-13});
export function createMegamanShots(p,tier=0,charged=false,live=[]){
 tier=megamanWeaponTier(tier);const weapon=MEGAMAN_WEAPONS[tier],face=p.facing<0?-1:1,c=center(p);
 // Original cutter is a single returning weapon; the existing fire cooldown is
 // retained and bounded here too so saved or synthetic input cannot stack rings.
 if(tier===1&&live.some(s=>s.life>0&&s.megaWeapon==='rolling-cutter'))return [];
 if(tier===2&&live.filter(s=>s.life>0&&s.megaWeapon==='fire-storm').length>=3)return [];
 const w=tier?16:charged?12:8,h=tier?16:charged?8:6;
 const shot={x:c.x+face*12-w/2,y:c.y-h/2,w,h,vx:face*(tier===1?2:4),vy:tier===1?-2:0,
  life:tier===1?180:90,age:0,charged:!!charged,tier,megaWeapon:weapon.id,family:weapon.id,defeatCause:weapon.kind,
  damage:charged?weapon.chargedDamage:weapon.damage,piercing:tier>0,hitIds:[]};
 if(tier!==2)return [shot];
 // One source orbit object, eight source offsets, 32 frames; it is an attack,
 // not player invulnerability. Recasting replaces the old orbit at the caller.
 return [shot,{...shot,x:c.x-7,y:c.y+13,w:14,h:14,vx:0,vy:0,life:32,megaWeapon:'fire-shield',defeatCause:'megaman-fire-shield',damage:3,hitIds:[]}];
}
const orbitX=[0,-14,-20,-14,0,14,20,14],orbitY=[20,14,0,-14,-20,-14,0,14];
export function advanceMegamanShot(s,p){
 s.life--;s.age=(s.age||0)+1;if(s.life<=0)return false;
 if(s.megaWeapon==='fire-shield'){
  const c=center(p),i=s.age%8;s.x=c.x+orbitX[i]-s.w/2;s.y=c.y+orbitY[i]-s.h/2;return true;
 }
 if(s.megaWeapon==='rolling-cutter'){
  if(s.age<=42){s.x+=s.vx;s.y+=s.vy;s.vy+=26/256;return true;}
  const c=center(p),dx=c.x-(s.x+s.w/2),dy=c.y-(s.y+s.h/2),d=Math.hypot(dx,dy);
  if(Math.abs(dx)<12&&Math.abs(dy)<12){s.life=0;return false;}
  const speed=2.5+(s.age-42)*8/256;s.vx=dx/d*speed;s.vy=dy/d*speed;
 }
 s.x+=s.vx;s.y+=s.vy;return true;
}
export function megamanShotPose(s){
 const age=s.age||0;
 if(s.megaWeapon==='rolling-cutter')return {image:'megaman-mm1-weapons',rect:[Math.floor(age/4)%4*32,0,32,32],anchor:[16,16]};
 if(s.megaWeapon==='fire-storm')return {image:'megaman-mm1-weapons',rect:[(4+Math.floor(age/6)%3)*32,0,32,32],anchor:[16,16]};
 if(s.megaWeapon==='fire-shield')return {image:'megaman-mm1-weapons',rect:[(7+[0,1,2,1][age%4])*32,0,32,32],anchor:[16,16]};
 return {image:'megaman',rect:[73+18*(Math.floor(age/5)%2),s.charged?133:115,17,17],anchor:[8.5,8.5]};
}
