// Original SMBC pixels, identified by its BmdInfo skin declarations. Rectangles
// exclude atlas grid/key pixels. Feet are local pixels; flip faces the rescuer.
// Whole PNGs are unchanged source bytes; hashes and URLs are in the receipt.
export const rescueCastSources=Object.freeze({
 'lance':{name:'Lance Bean',asset:'a2410',src:[63,17,19,45],feet:45,scale:.7,flip:false,facing:'front',sourceSkin:'Bill003'},
 'rd-008':{name:'RD-008',asset:'a2411',src:[64,20,17,42],feet:42,scale:.75,flip:false,facing:'front',sourceSkin:'Bill006'},
 'rc-011':{name:'RC-011',asset:'a2412',src:[64,20,17,42],feet:42,scale:.75,flip:false,facing:'front',sourceSkin:'Bill007'},
 'proto-man':{name:'Proto Man',asset:'a2413',src:[44,16,21,24],feet:24,scale:1,flip:true,facing:'right',sourceSkin:'MegaMan003'},
 'roll':{name:'Roll',asset:'a2413',src:[363,50,19,28],feet:28,scale:1,flip:false,facing:'left',sourceSkin:'MegaMan003 companion'},
 'luigi':{name:'Luigi',asset:'a2414',src:[45,97,16,32],feet:32,scale:1,flip:true,facing:'right',sourceSkin:'Luigi000'},
 'subcon':{name:'Subcon',asset:'a2415',src:[10,249,16,16],feet:16,scale:1,flip:true,facing:'right',sourceSkin:'Mario010 companion'},
});
export const rescueCastRotations=Object.freeze({
 mario:['toad','luigi','subcon','luigi','toad','subcon','luigi'],
 bill:['lance','rd-008','rc-011','lance','rc-011','rd-008','lance'],
 megaman:['dr-light','roll','proto-man','roll','dr-light','proto-man','roll'],
});
