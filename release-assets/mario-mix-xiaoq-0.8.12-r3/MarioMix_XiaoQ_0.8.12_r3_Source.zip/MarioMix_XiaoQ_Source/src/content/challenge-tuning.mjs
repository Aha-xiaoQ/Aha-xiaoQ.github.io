/** Encounter balance belongs to scene content, never to campaign transfers. */
export const CHALLENGE_TUNING=Object.freeze({
  tank:Object.freeze({total:20,concurrent:4,spawnInterval:150,spawnGrace:50,
    carriers:Object.freeze([3,10,17]),fastEnemies:Object.freeze([18,19]),baseExplosionTicks:36}),
  // Crossover challenge balance, not a claim of cycle-exact NES parameters.
  // Keep the existing approach / raised axe / two swings / recovery pattern.
  megaman:Object.freeze({busterDamage:4}),
  ryu:Object.freeze({jumpSpeed:5.85,bossHealth:28,walkSpeed:.9,walkFrames:48,windupFrames:26,slashFrames:24,swings:2,recoveryFrames:32}),
});
