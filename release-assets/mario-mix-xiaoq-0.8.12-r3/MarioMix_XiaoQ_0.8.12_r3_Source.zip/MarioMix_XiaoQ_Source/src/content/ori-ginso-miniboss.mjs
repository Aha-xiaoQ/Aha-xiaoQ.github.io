/** Original Ginso MultiMortar parameters, with disclosed crossover scale/layout. */
export const GINSO_MORTAR_SOURCE=Object.freeze({health:80,touchDamage:4,projectileDamage:8,experience:100,
 projectileSpeed:20,projectileGravity:50,bashSpeed:30,cancelGravityOnBash:false,range:20,hideDistance:5,
 waitBetweenShots:2,minHideTime:1,chargingDuration:.8,shootDelay:.15,shootingDuration:.5,maximumLiveTime:10});
export const GINSO_MORTAR_TUNING=Object.freeze({pixelsPerUnit:8,bodyWidth:24,bodyHeight:28,artScale:.16,
 reflectedDamage:8,playerCellDamage:1,roomWidth:384,roomHeight:240,teleportOrder:'cyclic-farthest-eligible'});
// Compact crossover arena. Original five-hole positions/rotations remain in the
// source manifest. This is not a claim to reproduce the original collision map.
const solid=(id,x,y,w,h,material='native')=>({id,x,y,w,h,collision:'solid',material});
export const GINSO_MORTAR_ROOM=Object.freeze({id:'ori-ginso-mortar',title:'奥日 · 银之树迫击虫',width:384,height:240,
 spawn:{x:100,y:178,w:9,h:14},geometry:[solid('floor',0,208,384,32),solid('left',0,0,12,208),solid('right',372,0,12,208),
 {id:'branch-left',x:64,y:144,w:76,h:8,collision:'oneway',material:'ginso-branch'},
 {id:'branch-right',x:236,y:144,w:76,h:8,collision:'oneway',material:'ginso-branch'},solid('exit-door',350,136,22,72)],
 holes:[{id:'hole-1',x:40,y:180,rotation:0},{id:'hole-2',x:320,y:180,rotation:0},
 {id:'hole-3',x:176,y:76,rotation:Math.PI},{id:'hole-4',x:24,y:106,rotation:-Math.PI/2},{id:'hole-5',x:336,y:106,rotation:Math.PI/2}],
 reward:{id:'ginso-spirit-cell',nativeActor:'ori',nativeType:'ori-cell',x:182,y:186,w:16,h:16},
 exit:{x:348,y:164,w:24,h:44},victoryDelay:60});
const source='Ori PC 5.0.0b5 level179 / MortarWormEnemyPlaceholder7611 + original sharedassets108/0 prefab';
export const GINSO_MORTAR_ENEMIES=Object.freeze([
 {id:'ori-pc:mortar',origin:'ori-pc',owner:'foe-port',source,contact:{stomp:'hurt',bash:false,healthDamage:1},
 movement:{model:'ginso-mortar-state-machine',collision:'scripted'},hurt:{handler:'foe-port',animation:'mortar-alert',sound:'ginso-hurt'},
 death:{handler:'foe-port',animation:'sootMortarDeathA',sound:'none',retire:'effect-complete'},score:100,starKill:true,targetable:true},
 {id:'ori-pc:mortar-fire',origin:'ori-pc',owner:'foe-port',source,contact:{stomp:'hurt',bash:true,healthDamage:2},
 movement:{model:'ballistic-bash-retains-gravity',collision:'projectile'},hurt:{handler:'foe-port',animation:'original-mortar-projectile',sound:'none'},
 death:{handler:'foe-port',animation:'original-mortar-projectile',sound:'none',retire:'effect-complete'},score:0,starKill:true,targetable:true},
]);
export function ginsoMortarRoom(width=GINSO_MORTAR_ROOM.width){
 if(!Number.isFinite(width)||width<384||width>1024)throw new TypeError('Invalid Ginso arena width');
 const q=structuredClone(GINSO_MORTAR_ROOM),extra=width-q.width;q.width=width;
 for(const g of q.geometry){if(g.id==='floor')g.w=width;else if(['right','branch-right','exit-door'].includes(g.id))g.x+=extra;}
 for(const h of q.holes){if(['hole-2','hole-5'].includes(h.id))h.x+=extra;else if(h.id==='hole-3')h.x+=extra/2;}
 q.reward.x+=extra/2;q.exit.x+=extra;return q;
}
export function ginsoMortarPlan(character,q=GINSO_MORTAR_ROOM){
 return {character,stage:{id:q.id,title:q.title,entryRoom:q.id,entrySpawn:'entry',checkpoints:[],nativeEnemiesOnly:true},
 rooms:{[q.id]:{width:q.width,height:q.height,geometry:structuredClone(q.geometry),objects:[{id:'entry',kind:'spawn',...q.spawn},
 {id:'ginso-mortar',kind:'walker',contractId:'ori-pc:mortar',nativeOwner:'foe-port',type:'ori-mortar',x:q.holes[1].x,y:q.holes[1].y,w:24,h:28}]}}};
}
