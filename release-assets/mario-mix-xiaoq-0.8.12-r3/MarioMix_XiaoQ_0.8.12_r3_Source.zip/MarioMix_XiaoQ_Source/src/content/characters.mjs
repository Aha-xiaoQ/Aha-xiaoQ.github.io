/** Canonical mainline character definitions. Runtime state lives in the motor. */
import {CHARACTER_ADAPTERS} from './character-adapters.mjs';
import {validateMainlineAccess} from '../engine/mainline-movement.mjs';
const BASE_MOTION = Object.freeze({
  walkSpeed: 1.5, runSpeed: 2.5, acceleration: .037109375,
  runAcceleration: .0556640625, reverseAcceleration: .1015625,
  friction: .05078125, jumpSpeed: 4.1333333, runningJumpSpeed: 5.1666667,
  maxFall: 4.25,
});

export function defineCharacter(id, title, width, height, maxHealth, help, abilities, motion = {}, adapterId = id, adapters = CHARACTER_ADAPTERS) {
  const adapter=Object.hasOwn(adapters,adapterId)&&adapters[adapterId];
  if(!adapter)throw new TypeError('Implement a character adapter before registering '+id);
  validateMainlineAccess({id, height, access:adapter.access});
  return Object.freeze({access:adapter.access,bossDamageUnit:adapter.bossDamageUnit,credits:adapter.credits||adapter.origin,id, heroId: id, title, width, height, maxHealth, help,
    selection:Object.freeze({name:id===adapterId?adapter.name:title,origin:adapter.origin}),
    bindings:Object.freeze({motion:adapter.motion,attack:adapter.attack,render:adapter.render,portrait:adapter.portrait}),
    abilities: Object.freeze([adapter.access.travel==='drive'?'drive':'jump', ...abilities]),
    motion: Object.freeze({...BASE_MOTION, width, height, ...motion})});
}
const profile=defineCharacter;

export const CHARACTER_PROFILES = Object.freeze([
  profile('mario', '马里奥', 12, 16, 1,
    '按住跳跃跳得更高；按住加速跨越远处平台。蘑菇与火焰花改变形态。',
    ['stomp', 'power-forms', 'fireball']),
  profile('bill', '比尔', 10, 30, 1,
    '方向配合攻击八向射击；地面下蹲，单向平台上按下＋跳跃穿过平台。',
    ['aim', 'shoot', 'prone', 'platform-drop'], {walkSpeed:2,runSpeed:2,acceleration:2,runAcceleration:2,reverseAcceleration:4,friction:2,jumpSpeed:5.1666667}),
  profile('megaman', '洛克人', 10, 24, 3,
    '按住攻击蓄力，松开发射蓄力炮。',
    ['shoot', 'charge', 'weapon-upgrade']),
  profile('ryu', '隼龙', 12, 26, 16,
    'J 攻击，L 忍术，E 换武器；火焰配合方向键八向发射；贴墙攀爬、蹬墙跳。',
    ['slash', 'wall-climb', 'wall-jump', 'ninjutsu']),
  profile('tank', '坦克', 12, 12, 1,
    '四向行驶，J 或空格开炮；收集星星升级火力。',
    ['cannon', 'four-way-drive', 'armor-upgrade']),
  profile('sandboxTrio', '泰拉瑞亚', 16, 32, 200,
    '1–6 选择工具，J 使用；Q 换武器，F 坐骑，H 治疗。',
    ['inventory', 'mining', 'building', 'weapons', 'mounts']),
  profile('ori', '奥日', 9, 14, 6,
    'J 精灵之火，E 借力弹射；Shift 冲刺，Q 滑翔，L 光之爆破。',
    ['spirit-flame', 'bash', 'wall-climb', 'double-jump', 'glide']),
  profile('sonic', '索尼克', 9, 14, 1,
    '按住 J 蓄力，松开冲刺；E 追踪，Shift 空冲；贴墙按 ↑ 上跑。',
    ['spin', 'spin-dash', 'rings'], {walkSpeed: 1.8, runSpeed: 3.2,
      acceleration: .0556640625, runAcceleration: .0703125}),
  profile('jackal', '赤色要塞', 12, 12, 1,
    '八向驾驶；J 机枪始终向上；空格或 L 发射随车头方向的手雷/火箭；E 交互。',
    ['eight-way-drive', 'machinegun', 'grenade-rocket', 'rescue']),
]);
