// Optional Mario Mix discoveries, not claimed to be original cartridge rewards.
// Coordinates use the compiled room's 16-pixel grid. Existing rewards, pipes,
// vines and critical route geometry are never overwritten.
export const MEMORY_SECRETS=Object.freeze([
 {id:'coin-cache',level:'1-2',roomId:'area-1',blockId:'r018',x:640,y:144,content:'multi'},
 {id:'air-life',level:'2-1',roomId:'area-0',blockId:'memory-air-life',x:656,y:144,content:'life',hidden:true},
 {id:'night-star',level:'3-1',roomId:'area-0',blockId:'r005-1-0',x:432,y:144,content:'star'},
 {id:'underground-life',level:'4-2',roomId:'area-1',blockId:'r008',x:432,y:144,content:'life'},
 {id:'cloud-life',level:'6-1',roomId:'area-0',blockId:'memory-cloud-life',x:784,y:144,content:'life',hidden:true},
 {id:'final-supply',level:'8-1',roomId:'area-0',blockId:'r047-3-0',x:3040,y:128,content:'mushroom'},
].map(Object.freeze));
