/** Pinned original encounter data. Rendering and native player equipment stay
 * outside this declaration; these scenes use the shared platform lifecycle. */
const solid=(id,x,y,w,h)=>({id,x,y,w,h,collision:'solid',material:'native'});
const enemy=(id,contractId,x,y,w,h)=>({id,kind:'walker',contractId,nativeOwner:'foe-port',x,y,w,h});
export const ORIGINAL_BOSS_CHALLENGES=Object.freeze({
 megaman:{id:'mega-cutman-room',title:'洛克人 · Cut Man',width:256,fixed:true,layout:{anchor:'split',left:96,right:32},goal:'boss',bossId:'cutman',
  spawn:{x:36,y:136,w:10,h:24},geometry:[solid('ceiling',0,0,256,32),solid('left',0,0,16,240),solid('right',240,0,16,240),solid('floor',0,192,256,48),solid('step',16,160,16,32),{...solid('super-arm-0',32,160,32,32),liftable:'super-arm'},{...solid('super-arm-1',64,160,32,32),liftable:'super-arm'}],
  objects:[enemy('cutman','mm1:cutman',184,168,16,24)],
  reward:{id:'cutman-prize',nativeActor:'megaman',nativeType:'weaponcore',x:174,y:176},exit:{x:222,y:144,w:18,h:48}},
 bill:{id:'contra-base1-boss-room',title:'比尔 · Garmakilma',width:256,fixed:true,layout:{anchor:'center'},goal:'boss',bossId:'base1-eye',
  spawn:{x:120,y:177,w:16,h:48},geometry:[solid('left',0,0,40,240),solid('right',216,0,40,240),solid('floor',0,208,256,32)],
  objects:[enemy('base1-eye','contra-nes:base1-eye',116,44,24,25),
   ...[72,168].map((x,i)=>enemy('base1-cannon-'+i,'contra-nes:wall-cannon',x,80,16,16)),
   ...[[120,80],[72,128],[120,128],[168,128]].map(([x,y],i)=>enemy('base1-plating-'+i,'contra-nes:wall-plating',x,y,16,16))],
  reward:{id:'base1-prize',nativeActor:'bill',nativeType:'bill-S',weapon:'S',x:72,y:192},exit:{x:4,y:178,w:16,h:30,anchor:'left',sequence:'elevator',speed:1,endY:-48}},
});

export const ORIGINAL_BOSS_SOURCE=Object.freeze({
 cutman:{revision:'b606a84840aea70f1298ddd9cf832bda69d99d27',hp:28,runSpeed:1+32/256,jumpSpeed:6+64/256,gravity:64/256,cutterSpeed:2+96/256,invulnerability:63,busterDamage:3,superArmDamage:14,contactDamage:4,cutterDamage:4,
  source:'lsmmega/mm1 home/bosses_ai.asm, home/collision.asm, engine/objects_vertical.asm; source state reconstruction on shared world collision'},
 base1:{revision:'687d651c021fd7020f10d05b970ccb62663c94bd',hp:16,platingHp:10,platingDelay:128,platingFrameDelay:4,cannonHp:8,cannonDelay:80,cannonFrameDelay:6,cannonShotDelay:4,cannonOpen:64,cannonRest:[192,96],speed:1.25,left:80,right:176,attackDelays:[112,80,64,40],startDelay:64,
  frames:['5d','5e','5f','5e','60','61','62','61'],frameTicks:8,appearanceRedTicks:192,hitRedTicks:32,fireRingHp:2,fireSpeed:1.75,fireSpeedCode:6,indoorAimY:176,eyeOriginY:64,cannonOriginY:96,ringLimit:6,
   weaponStrength:{N:0,M:2,F:1,S:3,L:2},
   // Original bank7 quadrant_aim_dir_01 and bullet_fract_vel_tbl. These are
   // quantized NES velocities, not a normalized continuous aim vector.
   quadrantAim:[[0x00,0x00,0x00,0x00],[0x63,0x21,0x11,0x11],[0x64,0x32,0x21,0x11],[0x65,0x43,0x22,0x22],[0x65,0x44,0x33,0x22],[0x65,0x54,0x33,0x32],[0x65,0x54,0x43,0x33],[0x65,0x54,0x44,0x33]],
   velocityFractions:[[0,255],[66,247],[128,221],[181,181],[221,128],[247,66],[255,0]],mirrorAttributes:[0,0x40,0xc0,0x80],
  source:'vermiceli/nes-contra-us bank0.asm:2665-2835; scene-owned source Boss player direction/motion/gun/point-contact tables; shared health/reward lifecycle; finite six-ring cap remains a crossover adaptation'},
});
