// Managed by scripts/register-map.mjs. Keep the four original worlds separate.
export const CUSTOM_WORLDS = [];
