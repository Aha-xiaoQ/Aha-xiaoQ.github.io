import {createEnemyRegistry,createEnemyResolver} from '../engine/enemy-contract.mjs';
import {GHZ_SINE} from './sonic-boss-sine.mjs';

// Sonic 1 GHZ Obj 3D/48, pinned 7ebe4b3d0c182b2566026b6d3f423d33539558da.
// Original frame counts / 8.8 speeds / sine table; coordinates and hitboxes
// scale 1/2 for the host's 9x14 Sonic body. The room layout is an adaptation.
export const SONIC_GHZ_SOURCE='sonicretro/s1disasm@7ebe4b3d0c182b2566026b6d3f423d33539558da';
const bossId='sonic-1-ghz:eggman',ballId='sonic-1-ghz:wrecking-ball';
const row=(id,contact,collision,score,targetable=true)=>({id,origin:'sonic-1-ghz',owner:'foe-port',source:SONIC_GHZ_SOURCE,targetable,
 contact,movement:{model:'original-ghz-8.8',collision},hurt:{handler:'foe-port',animation:'original-32-frame-flash',sound:'sonic-boss-hit'},
 death:{handler:'foe-port',animation:'original-explosion-recover-escape',sound:'sonic-boss-explode',retire:'effect-complete'},score,starKill:false});
export const SONIC_BOSS_REGISTRY=createEnemyRegistry([
 row(bossId,{stomp:'source',attack:'damage',damage:1},'scripted',1000),
 row(ballId,{stomp:'hurt'},'projectile',0,false),
]);
export const sonicBossDefinition=createEnemyResolver({registry:SONIC_BOSS_REGISTRY});
const solid=(id,x,y,w,h)=>({id,x,y,w,h,material:'native',collision:'solid'});
export const SONIC_BOSS_ROOM=Object.freeze({id:'sonic-ghz-boss',title:'索尼克 · 青丘摆锤',width:384,
 spawn:{x:24,y:194,w:9,h:14},geometry:[solid('floor',0,208,384,32),{...solid('left-edge',-16,0,16,240),visual:false},{...solid('right-edge',384,0,16,240),visual:false},solid('left-rise',88,176,40,32),solid('right-rise',256,176,40,32)],
 objects:Array.from({length:6},(_,i)=>({id:'ring-'+i,kind:'coin',x:40+i*14,y:156,w:8,h:12})),
 reward:{id:'sonic-ghz-shield',nativeActor:'sonic',nativeType:'lightning-shield',x:184,y:184,w:24,h:24},exit:{x:328,y:160,w:48,h:48}});
export function sonicBossRoom(width=384){
 if(!Number.isFinite(width)||width<384||width>1024||width%16)throw new TypeError('Invalid Sonic arena width');
 const offset=(width-SONIC_BOSS_ROOM.width)/2,move=q=>({...q,x:q.x+offset});
 return {...SONIC_BOSS_ROOM,width,spawn:move(SONIC_BOSS_ROOM.spawn),objects:SONIC_BOSS_ROOM.objects.map(move),reward:move(SONIC_BOSS_ROOM.reward),exit:move(SONIC_BOSS_ROOM.exit),
  geometry:SONIC_BOSS_ROOM.geometry.map(q=>q.id==='floor'?{...q,w:width}:q.id==='right-edge'?{...q,x:width}:q.id==='left-edge'?{...q}:move(q))};
}
export function sonicBossPlan(character,def=SONIC_BOSS_ROOM){return {character,
 stage:{id:def.id,title:def.title,entryRoom:def.id,entrySpawn:'entry',checkpoints:[],nativeEnemiesOnly:true},
 rooms:{[def.id]:{width:def.width,height:240,geometry:structuredClone(def.geometry),objects:[{id:'entry',kind:'spawn',...def.spawn},...structuredClone(def.objects)]}}};}
const sine=angle=>GHZ_SINE[angle&255],cosine=angle=>sine(angle+64);
function synchronize(e,width=384){e.x=e.bx+(width-384)/2-12;e.y=e.by+(sine(e.bob)>>6)*.5-12;e.bob=(e.bob+2)&255;}
export function createSonicBossEnemies({sound=()=>{},room=SONIC_BOSS_ROOM}={}){
 let retreat=null,defeated=false;
 function prepare(w){if(w.enemies.some(e=>e.contractId===bossId))return;
  w.enemies.push({id:'ghz-eggman',contractId:bossId,nativeOwner:'foe-port',type:'ghz-eggman',kind:'walker',
   x:244+(room.width-384)/2,y:66,w:24,h:24,hp:8,dead:false,bx:256,by:78,bob:0,phase:'descend',timer:0,vx:0,vy:.5,face:0,flash:0,
   ballReady:false,anchor:0,chain:0,angle:0x4080,swingSpeed:-0x200,swingDirection:0},
   {id:'ghz-ball',contractId:ballId,nativeOwner:'foe-port',type:'ghz-ball',kind:'walker',x:256+(room.width-384)/2,y:-80,w:20,h:20,hp:1,dead:false});
 }
 function advanceBoss(e){
  if(e.flash>0)e.flash--;
  if(e.phase==='descend'){e.by+=.5;if(e.by>=142){e.by=142;e.phase='approach';}}
  else if(e.phase==='approach'){e.bx-=.5;e.by-=.125;if(e.bx<=208){e.bx=208;e.phase='wait';e.timer=119;e.ballReady=true;}}
  else if(e.phase==='wait'){
   if(--e.timer<0){e.phase='move';e.timer=e.bx===208?127:63;e.vx=(e.bx===208?.125:.5)*(e.face?1:-1);}
  }else if(e.phase==='move'){
   if(--e.timer<0){e.face^=1;e.phase='wait';e.timer=63;e.vx=0;}else e.bx+=e.vx;
  }
  synchronize(e,room.width);
  if(e.ballReady){e.anchor=Math.min(32,e.anchor+1);e.chain=Math.min(96,e.chain+1);
   if(e.chain===96&&e.phase==='move')e.swinging=true;
   if(e.swinging){e.swingSpeed+=e.swingDirection?-8:8;e.angle=(e.angle+e.swingSpeed)&65535;
    if(e.swingSpeed===512)e.swingDirection=1;else if(e.swingSpeed===-512)e.swingDirection=0;}
  }
 }
 function step(e,w){
  if(e.contractId===bossId){advanceBoss(e);return true;}
  if(e.contractId!==ballId)throw new TypeError('Unknown Sonic boss enemy');
  const boss=w.enemies.find(q=>q.contractId===bossId&&!q.dead);
  if(!boss){e.dead=true;return true;}
  if(!boss.ballReady){e.y=-80;return true;}
  const angle=boss.angle>>8;e.x=boss.x+12+((cosine(angle)*boss.chain)>>8)*.5-10;
  e.y=boss.y+12+boss.anchor*.5+((sine(angle)*boss.chain)>>8)*.5-10;return true;
 }
 function hurt(e,amount){if(e.contractId!==bossId||e.dead||e.flash>0||!Number.isFinite(amount)||amount<=0)return false;
  e.hp--;e.flash=32;sound('sonic-boss-hit');return true;}
 function death(e){if(e.contractId!==bossId)throw new TypeError('Wrecking ball is not a damageable boss');
  defeated=true;retreat={...e,phase:'explode',timer:179,age:0,hp:0,flash:0,vx:0,vy:0};sound('sonic-boss-explode');
  return {kind:'sonic-ghz-death',life:1,flat:true,vx:0,vy:0};}
 function advanceRetreat(){if(!retreat)return;const e=retreat;e.age++;
  if(e.phase==='explode'){if(e.age%8===0)sound('sonic-boss-explode');if(--e.timer<0){e.phase='recover';e.timer=-38;e.face=1;}}
  else if(e.phase==='recover'){e.timer++;if(e.timer<0)e.vy+=.046875;else if(e.timer===0||e.timer===48)e.vy=0;else if(e.timer<48)e.vy-=.015625;else if(e.timer>=56)e.phase='escape';e.by+=e.vy;synchronize(e,room.width);}
  else if(e.phase==='escape'){e.bx+=2;e.by-=.125;synchronize(e,room.width);if(e.x+12>room.width+48)retreat=null;}
 }
 function validate(data){if(data?.version!==1||typeof data.defeated!=='boolean')throw new TypeError('Invalid Sonic boss state');
  if(data.retreat&&(!['explode','recover','escape'].includes(data.retreat.phase)||['bx','by','x','y','timer','age','vx','vy'].some(k=>!Number.isFinite(data.retreat[k]))))throw new TypeError('Invalid Sonic boss retreat');
 }
 return {prepare,step,hurt,death,advanceRetreat,validate,remapSceneX(mapX){if(retreat)retreat.x=mapX(retreat.x,retreat);},draw:()=>false,view:()=>({defeated,retreat:retreat?structuredClone(retreat):null}),
  snapshot:()=>({version:1,defeated,retreat:retreat?structuredClone(retreat):null}),
  restore(data){validate(data);
   defeated=data.defeated;retreat=structuredClone(data.retreat);},
 };
}
