import {rescueCastRotations} from './rescue-cast-sources.mjs';
// The scene owns the cast, not the selected hero's sprite fallback. Only
// installed, identified source characters are named here; no enemy placeholders.
const lines={
 mario:[['YOU FOUND ME!','THE PRINCESS WENT AHEAD.'],['ANOTHER CASTLE?','I KNOW THE FEELING.'],['THE COAST IS CLEAR!','KEEP GOING, MARIO!'],['HALFWAY THERE!','SHE IS STILL WAITING.'],['YOUR PRINCESS IS','IN ANOTHER CASTLE!'],['YOU CAME ALL THIS WAY!','JUST A LITTLE FURTHER.'],['ONE LAST CASTLE.','BRING HER HOME!']],
 bill:[['NICE COVER, PARTNER.','LET US MOVE!'],['AMMO CHECK.','NEXT TARGET AHEAD.'],['SAVED ME A GRENADE.','I OWE YOU ONE.'],['NO ONE LEFT BEHIND.','KEEP IT THAT WAY.'],['THAT WAS CLOSE.','WATCH YOUR SIX!'],['GOOD SHOOTING, BILL.','WE ARE NOT DONE YET.'],['ONE FINAL PUSH.','I WILL COVER YOU.']],
 megaman:[['WELL DONE, MEGA MAN!','YOUR COURAGE IS GROWING.'],['WELCOME BACK!','I SAVED YOU A SEAT.'],['NOT BAD, LITTLE BROTHER.','KEEP YOUR GUARD UP.'],['EVEN A SMALL SHOT','CAN MAKE A DIFFERENCE.'],['YOU NEVER GAVE UP.','I AM PROUD OF YOU.'],['YOU KNOW THE WAY NOW.','I WILL WATCH YOUR BACK.'],['GO, MEGA MAN!','WE ARE COUNTING ON YOU.']],
 ryu:[['RYU... YOU MADE IT.','STAY ON YOUR GUARD.'],['I KNEW YOU WOULD COME.','THE TRAIL GOES ON.'],['DO NOT LOOK BACK.','I CAN HANDLE THIS.'],['YOUR FATHER WOULD','HAVE BEEN PROUD.'],['ANOTHER CLOSE CALL.','THANKS FOR THE HAND.'],['SAVE YOUR STRENGTH.','IT IS NOT OVER YET.'],['FINISH THIS, RYU.','I WILL BE WAITING.']],
 tank:[['BASE SECURED.','READY FOR THE NEXT STAGE.'],['RADIO CHECK.','ALL CLEAR!'],['EAGLE STILL STANDING.','MISSION CONTINUES.'],['ARMOR CAN BE REPLACED.','THIS BASE CANNOT.'],['NO FRIENDLY FIRE.','GOOD WORK, COMMANDER.'],['ONE BASE. MANY TANKS.','YOU KNOW THE DRILL.'],['HOLD THE LINE.','ONE LAST SORTIE.']],
 sandboxTrio:[['THAT LOOKS USEFUL.','HAVE YOU TRIED CRAFTING?'],['A ROOF AND A DOOR.','ALMOST FEELS LIKE HOME.'],['DID YOU BRING A TORCH?','IT IS DARK IN HERE.'],['WATCH THE LAVA.','TRUST ME ON THIS ONE.'],['NICE EQUIPMENT!','I HAVE A FEW IDEAS.'],['ANOTHER CASTLE?','I WOULD PREFER A HOUSE.'],['STILL ALIVE? GOOD.','LET US KEEP IT THAT WAY.']],
 sonic:[['SONIC! THERE YOU ARE!','WAIT UP!'],['YOU ALWAYS RUN AHEAD.','THIS TIME I FOUND YOU!'],['THAT WAS FAST!','BUT I WAS WAITING.'],['NO TIME TO STOP?','THEN TAKE ME WITH YOU!'],['I KNEW YOU WOULD WIN.','DO NOT LET IT GO TO YOU!'],['ALMOST THERE, SONIC!','I WILL CATCH UP.'],['GO GET THEM!','WE WILL CELEBRATE LATER.']],
 ori:[['...'],['YOU FOUND YOUR WAY HOME.'],['A LITTLE LIGHT','IN A VERY DARK PLACE.'],['THERE YOU ARE.','COME CLOSER.'],['EVEN HERE,','YOU ARE NOT ALONE.'],['REST A MOMENT,','LITTLE ONE.'],['YOUR LIGHT WILL','SHOW THE WAY.']],
 jackal:[['EXTRACTION COMPLETE.','GOOD TO SEE YOU!'],['WE HEARD YOUR ENGINE.','KNEW YOU WOULD COME.'],['A SEAT FOR EVERYONE.','NO ONE LEFT BEHIND.'],['WE ARE GOING HOME!','THANKS FOR THE RIDE.'],['THAT WAS SOME DRIVING.','NEXT TIME, LESS LAVA.'],['YOUR CREW IS SAFE.','MISSION ALMOST OVER.'],['ONE LAST PICKUP.','BRING EVERYONE HOME.']],
};
export function castleReunion(hero,level='1-4'){
 const world=Number(level.split('-')[0]);
 if(level==='8-4')return {cast:'peach',marioThanks:hero!=='mario',lines:hero==='mario'?['THANK YOU MARIO!','YOUR QUEST IS OVER.','PEACE RETURNS!']:['THANK YOU, BRAVE FRIEND!','MARIO: THANK YOU!','YOU BROUGHT HER HOME.']};
 return {cast:rescueCastRotations[hero]?.[Math.max(0,Math.min(6,world-1))]||({mario:'toad',bill:'buddy',megaman:'dr-light',ryu:'irene',tank:'base',sandboxTrio:'guide',sonic:'amy',ori:'naru',jackal:'pow'})[hero]||'toad',marioThanks:false,lines:lines[hero]?.[Math.max(0,Math.min(6,world-1))]||lines.mario[0]};
}
export function rooftopRescue(body,marker,geometry,hero){
 if(hero!=='jackal'||!marker)return null;
 const x=marker.x+408,roof=geometry.find(g=>!g.hidden&&g.collision==='solid'&&g.y<=40&&g.x<=x&&g.x+g.w>=x);
 if(!roof||body.y+body.h>roof.y+1||Math.abs(body.x+body.w/2-x)>36)return null;
 return {x:x-28,top:roof.y,feet:208};
}
export function rescueMarioPose(finish){
 if(!finish?.rooftop)return null;
 const age=finish.rescueAge||0,{x,top,feet}=finish.rooftop;
 return {x,feet:age<60?top:Math.min(feet,top+(age-60)*1.5),climbing:age>=60&&age<60+(feet-top)/1.5,ladderBottom:Math.min(feet,top+age*3)};
}
// A separate presentation guest. Never move or replace the selected hero.
export function finalRescueMarioPose(hero,level,finish,body,marker){
 if(level!=='8-4'||hero==='mario'||!marker||!['reunion','score'].includes(finish?.phase))return null;
 // Jeep's 1.5x source art ends at marker+384. Mario's idle opaque
 // columns are 1..13 in a 16px cell: centre392 leaves a pixel of air.
 const vehicle=hero==='jackal'||hero==='tank',feet=208,target=marker.x+392;
 const start=vehicle?(finish.rooftop?.x??body.x+body.w/2):marker.x+454;
 const age=finish.phase==='score'?60:Math.max(0,finish.age||0),travel=Math.min(60,age)/60;
 const x=start+(target-start)*travel,walking=travel<1&&Math.abs(target-start)>.1;
 return {x,feet,walking,facing:walking?Math.sign(target-start):1,sprite:walking?'small_run'+Math.floor(age/6)%3:'small_idle',source:vehicle?'vehicle':'right'};
}
