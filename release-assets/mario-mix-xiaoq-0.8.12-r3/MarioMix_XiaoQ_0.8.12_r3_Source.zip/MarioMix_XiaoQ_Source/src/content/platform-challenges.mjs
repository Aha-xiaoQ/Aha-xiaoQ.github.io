/** Authored native challenge content. Geometry is shared with the world engine;
 * scene identity, completion and rewards do not change the selected hero. */
const solid=(id,x,y,w,h,material='native')=>({id,x,y,w,h,material,collision:'solid'});
const branch=(id,x,y,w)=>({...solid(id,x,y,w,8,'ginso-branch'),collision:'oneway'});
const at=(id,kind,x,y,w=16,h=16)=>({id,kind,x,y,w,h});
export const PLATFORM_CHALLENGES=Object.freeze({
 megaman:{id:'mega-machine-room',title:'洛克人 · 机械密室',width:256,fixed:true,layout:{anchor:'split',left:96,right:32},
  spawn:{x:36,y:136,w:10,h:24},geometry:[solid('ceiling',0,0,256,32),solid('left',0,0,16,240),solid('right',240,0,16,240),solid('floor',0,192,256,48),solid('step',16,160,80,32)],
  objects:[{...at('mega-foe-1','walker',150,176),nativeTemplate:'met'},{...at('mega-foe-2','walker',160,176),nativeTemplate:'pipi'},{...at('mega-foe-3','walker',218,176),nativeTemplate:'screwie'}],
  reward:{id:'native-prize',nativeActor:'megaman',nativeType:'weaponcore',x:186,y:176},exit:{x:222,y:144,w:18,h:48},goal:'enemies'},
 ori:{id:'ori-spirit-grotto',title:'奥日 · 银之树枝径',width:1024,
  spawn:{x:32,y:190,w:9,h:14},geometry:[solid('entry',0,208,176,32),branch('ledge-1',240,168,96),branch('ledge-2',400,152,96),branch('ledge-3',568,128,80),branch('ledge-4',744,168,112),solid('sanctuary',904,192,120,48)],
  objects:[at('anchor-1','bash-anchor',202,139,12,12),at('anchor-2','bash-anchor',355,122,12,12),at('anchor-3','bash-anchor',526,92,12,12),at('anchor-4','bash-anchor',687,120,12,12),at('anchor-5','bash-anchor',868,145,12,12),at('spitter-1','walker',312,150,18,18),at('spitter-2','walker',826,150,18,18)],
  reward:{id:'native-prize',nativeActor:'ori',nativeType:'ori-cell',x:938,y:174},exit:{x:990,y:152,w:26,h:40},goal:'route'},
 sonic:{id:'sonic-ring-run',title:'索尼克 · 金环小径',width:1536,
  spawn:{x:32,y:194,w:9,h:14},geometry:[solid('entry',0,208,256,32),solid('step-1',320,184,192,56),solid('step-2',576,160,192,80),solid('step-3',832,184,256,56),solid('finish',1152,208,384,32)],
  objects:[...Array.from({length:7},(_,i)=>at('ring-a-'+i,'coin',64+i*24,182,8,12)),...Array.from({length:6},(_,i)=>at('ring-b-'+i,'coin',336+i*24,158,8,12)),...Array.from({length:6},(_,i)=>at('ring-c-'+i,'coin',592+i*24,134,8,12)),...Array.from({length:8},(_,i)=>at('ring-d-'+i,'coin',856+i*24,158,8,12)),...Array.from({length:6},(_,i)=>at('ring-e-'+i,'coin',1168+i*24,182,8,12)),at('moto-1','walker',456,168),at('moto-2','walker',1008,168)],
  reward:{id:'native-prize',nativeActor:'sonic',nativeType:'lightning-shield',x:1360,y:184,w:24,h:24},exit:{x:1456,y:160,w:48,h:48},goal:'route'},
});

export function platformChallengePlan(hero,character,definition){
 const def=definition??PLATFORM_CHALLENGES[hero];if(!def)throw new RangeError('Unregistered platform challenge '+hero);
 if(def.exit?.sequence!==undefined&&(def.exit.sequence!=='elevator'||!Number.isFinite(def.exit.speed)||def.exit.speed<=0||!Number.isFinite(def.exit.endY)||def.exit.action!==undefined))throw new TypeError('Invalid native exit sequence');
 if(def.exit?.action!==undefined&&!['up','down','interact'].includes(def.exit.action))throw new TypeError('Unknown native exit action');
 if(def.goal==='boss'&&(!def.bossId||!def.objects.some(o=>o.kind==='walker'&&o.id===def.bossId)))throw new TypeError('Boss challenge requires its declared encounter');
 const roomId=def.id;
 return {def,plan:{character,stage:{id:def.id,title:def.title,entryRoom:roomId,entrySpawn:'entry',checkpoints:[],nativeEnemiesOnly:true},rooms:{[roomId]:{width:def.width,height:240,geometry:structuredClone(def.geometry),objects:[{id:'entry',kind:'spawn',...def.spawn},...structuredClone(def.objects)]}}}};
}

// Source cells keep their pixel dimensions. Only room spans grow; details use
// an explicit centre or split anchor shared by collision and presentation.
export function fixedArenaDefinition(source,width){
 const center=source.layout?.anchor==='center';
 const delta=width-source.width,mapX=x=>projectArenaX(x,source.width,width,source.layout);
 const box=q=>({...q,x:mapX(q.x)});
 return {...source,width,spawn:box(source.spawn),objects:source.objects.map(box),reward:box(source.reward),
  exit:source.exit.anchor==='left'?{...source.exit}:box(source.exit),geometry:source.geometry.map(q=>{
   if(q.x===0&&q.w===source.width)return {...q,w:width};
   if(q.x+q.w===source.width)return {...q,x:q.x+delta};
   if(q.x===0)return {...q};
   return center?box(q):{...q};
  })};
}
export function projectArenaX(x,from,to,layout){
 if(![x,from,to].every(Number.isFinite)||from<256||to<256)throw new TypeError('Invalid arena coordinates');
 if(layout?.anchor==='center')return x+(to-from)/2;
 const {left,right}=layout||{};
 if(layout?.anchor!=='split'||![left,right].every(n=>Number.isFinite(n)&&n>=0)||left+right>=Math.min(from,to))throw new TypeError('Fixed arena requires an explicit layout');
 if(x<=left)return x;if(x>=from-right)return x+to-from;
 return left+(x-left)*(to-left-right)/(from-left-right);
}
