// Equipment belongs to physical native pickups. The common room receipt grants
// this bonus immediately after collection, including at maximum equipment.
export const CHALLENGE_REWARDS=Object.freeze(Object.fromEntries([
 ['bill','bill-weapon'],['ryu','jump-and-slash'],['tank','max-power-shield'],
 ['sandboxTrio','terra-equipment'],['megaman','weaponcore'],['ori','ori-cell'],
 ['sonic','lightning-shield'],['jackal','jackal-weapon'],
].map(([hero,equipment])=>[hero,Object.freeze({id:'hidden-clear:'+hero,equipment,score:1000,lives:1})])));
