import {createCatalog} from '../engine/catalog.mjs';

// A combination is listed only when a real adapter and regression route exist.
// Abilities describe the contract; they do not magically grant mechanics.
export const gameCatalog = createCatalog({
  characters: [
    {id:'mario', name:'MARIO', origin:'SUPER MARIO BROS.', defaultScene:'world-1-1', locomotion:'platform', abilities:['jump','stomp','power-forms','fireball']},
    {id:'bill', name:'BILL RIZER', origin:'CONTRA', defaultScene:'world-1-1', locomotion:'platform', abilities:['jump','aim','shoot','prone','weapon-supply']},
    {id:'megaman', name:'MEGA MAN', origin:'MEGA MAN', defaultScene:'world-1-1', locomotion:'platform', abilities:['jump','shoot','charge','weapon-upgrade']},
    {id:'ryu', name:'RYU HAYABUSA', origin:'NINJA GAIDEN', defaultScene:'world-1-2', locomotion:'platform', abilities:['jump','wall-climb','wall-jump','slash']},
    {id:'tank', name:'TANK', origin:'BATTLE CITY', defaultScene:'world-1-2', locomotion:'topdown', abilities:['drive','shoot','brick-break','armor-upgrade']},
    {id:'sandboxTrio', name:'TERRARIAN', origin:'TERRARIA', defaultScene:'world-1-3', locomotion:'platform', abilities:['jump','build','mine','aim','mount']},
    {id:'ori', name:'ORI', origin:'ORI / BLIND FOREST', defaultScene:'world-1-4', locomotion:'platform', abilities:['jump','bash','wall-climb','glide']},
    {id:'sonic', name:'SONIC', origin:'SONIC THE HEDGEHOG', defaultScene:'world-1-4', locomotion:'platform', abilities:['jump','spin','spin-dash','rings']},
    {id:'jackal', name:'JACKAL', origin:'JACKAL / NES US', defaultScene:'world-1-1', locomotion:'topdown', abilities:['drive','eight-way-drive','machinegun','grenade-rocket','rescue']},
  ],
  scenes: [
    {id:'world-1-1', stage:11, title:'经典启程', defaultCharacter:'mario', characters:['mario','bill','megaman','jackal'], adapter:'classic', geometry:'classic-1-1-v1'},
    {id:'world-1-2', stage:12, title:'地下援军', defaultCharacter:'ryu', characters:['ryu','tank'], adapter:'relay', geometry:'legacy-world12'},
    {id:'world-1-3', stage:13, title:'泰拉瑞亚', defaultCharacter:'sandboxTrio', characters:['sandboxTrio'], adapter:'terra', geometry:'legacy-terra'},
    {id:'world-1-4', stage:14, title:'熔城逃脱', defaultCharacter:'ori', characters:['ori','sonic'], adapter:'castle', geometry:'legacy-shared-castle'},
  ],
});
