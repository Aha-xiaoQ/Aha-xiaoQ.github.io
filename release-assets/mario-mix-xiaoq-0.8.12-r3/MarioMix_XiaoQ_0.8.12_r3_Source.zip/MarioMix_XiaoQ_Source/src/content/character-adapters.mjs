import {MAINLINE_JUMP,validateMainlineAccess} from '../engine/mainline-movement.mjs';

/** Installed behavior descriptors. A different behavior needs both a complete
 * descriptor and an executable factory; unknown IDs never imply platforming. */
export function createCharacterAdapters(rows){
  const entries=[],seen=new Set(),idPattern=/^[A-Za-z0-9][A-Za-z0-9._:-]{0,79}$/;
  if(!Array.isArray(rows)||!rows.length)throw new TypeError('Character adapters must be nonempty');
  for(const row of rows){
    if(!row||!idPattern.test(row.id)||seen.has(row.id))throw new TypeError('Invalid/duplicate character adapter '+row?.id);
    for(const field of ['name','origin'])if(typeof row[field]!=='string'||!row[field].trim())throw new TypeError('Character adapter '+row.id+' missing '+field);
    if(row.credits!==undefined&&(typeof row.credits!=='string'||!row.credits.trim()))throw new TypeError('Character adapter '+row.id+' invalid credits');
    for(const field of ['motion','attack','render','portrait'])if(typeof row[field]!=='string'||!idPattern.test(row[field]))throw new TypeError('Character adapter '+row.id+' missing '+field);
    if(!Number.isFinite(row.bossDamageUnit)||row.bossDamageUnit<=0)throw new TypeError('Character adapter '+row.id+' invalid bossDamageUnit');
    // A descriptor has no actor size yet: protocol validation uses a one-cell
    // body. defineCharacter/catalog must also validate the actual dimensions.
    validateMainlineAccess({id:row.id,height:MAINLINE_JUMP.passageHeight,access:row.access});
    entries.push([row.id,Object.freeze({...row,access:Object.freeze({...row.access})})]);seen.add(row.id);
  }
  return Object.freeze(Object.fromEntries(entries));
}
const adapter=(id,name,origin,access,bossDamageUnit=1,credits=origin)=>({id,name,origin,credits,bossDamageUnit,motion:id,attack:id,render:id,portrait:id,access});
export const CHARACTER_ADAPTERS=createCharacterAdapters([
  adapter('mario','MARIO','SUPER MARIO BROS.',{travel:'jump',waterTravel:'swim',passage:'crouch',crouchHeight:16},1,'Super Mario Bros. · Nintendo'),
  adapter('bill','BILL RIZER','CONTRA',{travel:'jump',waterTravel:'swim',passage:'crouch',crouchHeight:16},1,'Contra · KONAMI'),
  adapter('megaman','MEGA MAN','MEGA MAN',{travel:'jump',waterTravel:'swim',passage:'weapon',startingTool:'buster'},1,'Mega Man · CAPCOM'),
  adapter('ryu','RYU HAYABUSA','NINJA GAIDEN',{travel:'jump',waterTravel:'swim',passage:'crouch',crouchHeight:16},1,'Ninja Gaiden · TECMO'),
  adapter('tank','TANK','BATTLE CITY',{travel:'drive',waterTravel:'drive',passage:'body'},1,'Battle City · NAMCO'),
  adapter('sandboxTrio','TERRARIAN','TERRARIA',{travel:'jump',waterTravel:'swim',passage:'weapon',startingTool:'pickaxe',collisionWidth:14,nativeWidth:16},44,'Terraria · Re-Logic'),
  adapter('ori','ORI','ORI / BLIND FOREST',{travel:'jump',waterTravel:'swim',passage:'body'},1,'Ori · Moon Studios / Microsoft'),
  adapter('sonic','SONIC','SONIC THE HEDGEHOG',{travel:'jump',waterTravel:'swim',passage:'body'},4,'Sonic · SEGA'),
  adapter('jackal','JACKAL','JACKAL / NES US',{travel:'drive',waterTravel:'drive',passage:'body'},1,'Jackal · KONAMI'),
]);
