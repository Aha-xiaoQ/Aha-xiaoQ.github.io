// Scene rules do not own campaign lives or actor equipment. A native health
// pool is scoped to its original game; it never becomes mainline protection.
export const CHALLENGE_RULES=Object.freeze({
  bill:Object.freeze({health:'protection',hud:'contra'}),
  ryu:Object.freeze({health:'native',initialHealth:16,hud:'ninja-gaiden'}),
  tank:Object.freeze({health:'protection',hud:'battle-city'}),
  sandboxTrio:Object.freeze({health:'native',initialHealth:100,hud:'terraria'}),
  megaman:Object.freeze({health:'native',initialHealth:28,contactDamage:3,hud:'megaman'}),
  ori:Object.freeze({health:'native',initialHealth:6,hud:'ori'}),
  jackal:Object.freeze({health:'protection',hud:'jackal'}),
  sonic:Object.freeze({health:'rings',hud:'sonic'}),
});
