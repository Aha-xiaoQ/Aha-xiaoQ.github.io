// SMB $D140-$D147, $BF8C-$BF9E, $BFD7-$C018. Native pixels at 60 Hz.
// Patrol, jump scheduling and terrain contacts remain crossover adaptations.
export const CLASSIC_BOSS_MOTION=Object.freeze({
 jumpLift:1,jumpSpeed:-2,downwardForce:0x0f,maximumSpeed:2,fractionScale:256,
});
