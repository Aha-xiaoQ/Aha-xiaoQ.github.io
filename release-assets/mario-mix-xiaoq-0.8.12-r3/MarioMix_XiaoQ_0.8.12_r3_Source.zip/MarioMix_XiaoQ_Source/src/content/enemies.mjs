import {createEnemyRegistry,createEnemyResolver} from '../engine/enemy-contract.mjs';
import {JACKAL_ENEMIES} from '../scenes/jackal/foes.mjs';

// A declaration is an integration contract, not an assertion that the supplied
// art is commercially original. Source fidelity is audited separately. The
// ori-r29 compatibility identity now uses the pinned PC Spitter source; its
// projectile remains an explicitly declared ballistic presentation adaptation.
const rows=[];
function add(origin,owner,kinds,{source,model,collision='solid',activation,grounding,sourceFacing,health,hurt,death,retire='effect-complete',score=100,starKill=true,stomp='source'}){
  for(const kind of kinds)rows.push({id:origin+':'+kind,origin,owner,source,
    ...(health?.(kind)?{health:health(kind)}:{}),
    ...(sourceFacing?{presentation:{sourceFacing}}:{}),contact:{stomp:typeof stomp==='function'?stomp(kind):stomp},movement:{model,collision,...(activation?{activation}:{}),...(grounding?{grounding}:{})},hurt:{handler:owner,animation:hurt[0],sound:hurt[1]},
    death:{handler:owner,animation:death[0],sound:death[1],retire},score:typeof score==='function'?score(kind):score,starKill});
}
add('mario','stage',['walker','goomba','koopa','beetle','spiny','spinyegg','hammerbro'],{
  source:'01-inputs/previous-classic + source map appearance',model:'ground/shell/jump/source-vertical',stomp:kind=>['koopa','beetle'].includes(kind)?'shell':['walker','goomba','hammerbro'].includes(kind)?'flatten':'hurt',hurt:['stomp-or-kick','classic-stomp/kick'],death:['flatten-or-flip','classic-enemy-defeat']});
add('mario','stage',['piranha','lakitu','blooper','cheepcheep','bulletbill'],{
  source:'source map appearance / authored movement',model:'authored-flight-or-pipe',collision:'scripted',stomp:kind=>kind==='piranha'?'hurt':'flatten',hurt:['source-hit','classic-kick'],death:['flip','classic-enemy-defeat']});
add('mario','stage',['bowser'],{source:'FullScreenMario 96a1e362 / spawnType',model:'castle-boss',stomp:'hurt',hurt:['fire-hit','classic-kick'],death:['fake-bowser-reveal','classic-enemy-defeat'],score:5000});
add('mario','stage',['podoboo'],{source:'source map appearance / hazard',model:'hazard',collision:'projectile',activation:'proximity',stomp:'hurt',hurt:['none','none'],death:['expire','none'],starKill:false,score:0});
add('mario','stage',['bowserfire','hammer'],{source:'source map appearance / hazard',model:'hazard',collision:'projectile',stomp:'hurt',hurt:['none','none'],death:['expire','none'],starKill:false,score:0});
add('contra','bill',['contra-soldier','contra-grenadier','contra-sniper','contra-turret','contra-ufo'],{
  source:'RF02 pinned Contra sprite/audio inputs',model:'contra-native',hurt:['flash/armor','bill_hit'],death:['source-explosion-277','bill_enemy_explode'],retire:'native-countdown-remove'});
// MM1 objects start at $14 HP; Buster damage is $14 for Metall/Bunby Heli
// and $07 for Screw Driver. The campaign's base bean does 1 damage, so keep
// the equivalent 1/1/3 hit counts without changing its weapon damage scale.
const mm1HealthSource='lsmmega/mm1 home/generate_object.asm + home/weapons_damage.asm';
const mm1Health={met:{initialHp:1,source:mm1HealthSource},popoheli:{initialHp:1,source:mm1HealthSource},screwie:{initialHp:3,source:mm1HealthSource}};
add('megaman','megaman',['met','screwie','popoheli','pipi','shield-attacker'],{
  source:'RF02 pinned Mega Man sprite/audio inputs',model:'megaman-native',health:kind=>mm1Health[kind],hurt:['flash/deflect','mega_enemy_hit'],death:['source-explosion-235','mega_enemy_hit'],retire:'native-countdown-remove'});
add('ninja-gaiden','ryu',['walker','thrower','hawk','bat','panther','boss'],{
  source:'RF02 R07 ninja sprites/audio',model:'ninja-native',hurt:['native-hit','ninja-hit'],death:['ninja-defeat-frames','ninja-kill']});
add('battle-city','tank',['basic','fast','armor','power'],{
  source:'RF02 R12/R07 tank sprites/audio',model:'tank-grid',hurt:['tank-flash','tank-hit'],death:['tank-explosion','tank-blast'],score:kind=>({basic:100,fast:200,armor:400,power:300}[kind])});
add('terraria','sandboxTrio',['slime','zombie','demonEye','caveBat'],{
  source:'RF02 R10 Terraria NPC sheets + original sound bank',model:'terraria-native',hurt:['native-knockback','terra-hit'],death:['native-particles/corpse','terra-npcDeath'],retire:'native-counter-45'});
add('terraria','sandboxTrio',['vulture','faceMonster','hornet','iceBat','crimera','eyeBoss','deerclops'],{
  source:'RF02 R21 Terraria NPC sheets + original sound bank',model:'terraria-native',hurt:['native-knockback','terra-hit'],death:['native-vanish (source review pending)','terra-npcDeath'],retire:'effect-complete',score:kind=>kind==='deerclops'?5000:100});
add('sonic-worlds-next','foe-port',['sonic-motobug'],{
  source:'Techokami/SonicWorldsNext d99390279504b23ea0766b5e9c29faa05f625d49',model:'motobug-patrol-turn',sourceFacing:-1,grounding:{width:9.6,gravity:.1,maxFallSpeed:4},hurt:['none','none'],death:['BadnickExplosion','s33_badnikDestroy']});
add('ori-r29','foe-port',['ori-dark-shooter'],{
  source:'User-supplied Ori PC sharedassets5.assets / chargingSootAtlasAtlas0 / pinned RF093 manifest',model:'spitter-stationary-ballistic-adaptation',sourceFacing:1,grounding:{width:12,gravity:.1,maxFallSpeed:4},hurt:['original-Spitter-hit-flash','spitterHurt'],death:['original-Spitter-death-frames','spitterDeath']});
add('ori-r29','foe-port',['ori-dark-fire'],{
  source:'Project adaptation of Ori Spitter aimed ballistic attack; original shooter and cue, procedural projectile',model:'aimed-ballistic-solid-collision',collision:'projectile',hurt:['bash-reflect','ori-bash'],death:['adapted-projectile-particles','none'],score:0});
// Native scenes keep their local port; the campaign installs the same source
// identities under its existing foe-port executable owner.
rows.push(...JACKAL_ENEMIES.map(r=>({...r,hurt:{...r.hurt,handler:'foe-port'},death:{...r.death,handler:'foe-port',retire:'effect-complete'}})));
export const enemyRegistry=createEnemyRegistry(rows);

// These projections describe old entity records only. New sources add their
// declarations above and spawn {contractId, nativeOwner}; no adapter is needed.
export const enemyDefinition=createEnemyResolver({registry:enemyRegistry,legacy:[
 {owner:'stage',identify:e=>'mario:'+(e.type||e.kind||'walker').replace(/^(enemy-|marker-)/,'').toLowerCase()},
 {owner:'bill',identify:e=>'contra:'+e.franchise},
 {owner:'megaman',identify:e=>'megaman:'+e.franchise},
 {owner:'ryu',identify:e=>'ninja-gaiden:'+e.kind},
 {owner:'tank',identify:e=>'battle-city:'+e.tankKind},
 {owner:'sandboxTrio',identify:e=>'terraria:'+(e.t21Species||e.kind)},
]});
