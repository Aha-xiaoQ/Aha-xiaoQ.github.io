// Pinned source: SMBC 16384fe05e24cd73fb901aaad761c88564bf4bfa,
// assets.swf sprites 277/235, at native NES scale (source stage is 2x).
// These are enemy-origin presentations, never selected-player presentations.
const part=(rect,x=-rect[2]/2,y=-rect[3]/2,flip=false)=>({rect,x,y,flip});
export const ENEMY_PRESENTATIONS=Object.freeze({
  contra:Object.freeze({sheet:'bill',sound:'bill_enemy_explode',hurtSound:'bill_hit',ms:130,
    frames:[[part([1,65,28,28])],[part([1,94,28,28])],
      [part([30,65,28,57],0,-28.5),part([30,65,28,57],-28,-28.5,true)]]}),
  megaman:Object.freeze({sheet:'megaman',sound:'mega_enemy_hit',hurtSound:'mega_enemy_hit',ms:32,
    frames:[[part([1,151,35,35])],[part([1,187,17,17])],[part([19,187,17,17])],
      [part([1,205,17,17])],[part([19,205,17,17])]]}),
});
export function enemyPresentationKey(enemy){
  if(enemy.franchise?.startsWith('contra-'))return 'contra';
  if(['met','screwie','popoheli','pipi','shield-attacker'].includes(enemy.franchise))return 'megaman';
  return null;
}
export function startEnemyPresentation(enemy){
  const key=enemyPresentationKey(enemy);if(!key)return null;
  const spec=ENEMY_PRESENTATIONS[key],duration=Math.ceil(spec.frames.length*spec.ms*60/1000);
  enemy.deathPresentation={key,duration,x:enemy.x+enemy.w/2,y:enemy.y+enemy.h/2};
  Object.assign(enemy,{dead:duration,hp:0,flipped:false,vx:0,vy:0,flash:0});
  return spec;
}
export function enemyPresentationFrame(enemy){
  const state=enemy.deathPresentation;if(!state||enemy.remove||enemy.dead<=0)return null;
  const spec=ENEMY_PRESENTATIONS[state.key];if(!spec)throw Error('Unknown enemy presentation '+state.key);
  const age=Math.max(0,state.duration-enemy.dead),index=Math.min(spec.frames.length-1,Math.floor(age*1000/60/spec.ms));
  return {...state,sheet:spec.sheet,index,parts:spec.frames[index]};
}

// A grenade impact uses the same pinned Contra source animation and cue as
// Contra explosions. Damage is committed once, before the visual-only tail.
export function startGrenadeBlast(shot,{groundY=null}={}){
  if(shot.kind!=='grenade')return null;
  const spec=ENEMY_PRESENTATIONS.contra,duration=Math.ceil(spec.frames.length*spec.ms*60/1000);
  const x=shot.x+shot.w/2,y=groundY===null?shot.y+shot.h/2:groundY-12;
  Object.assign(shot,{kind:'grenade-blast',x:x-16,y:y-16,w:32,h:32,vx:0,vy:0,gravity:0,age:0,life:duration,dead:duration,groundY,
    deathPresentation:{key:'contra',duration,x,y}});
  return spec;
}
