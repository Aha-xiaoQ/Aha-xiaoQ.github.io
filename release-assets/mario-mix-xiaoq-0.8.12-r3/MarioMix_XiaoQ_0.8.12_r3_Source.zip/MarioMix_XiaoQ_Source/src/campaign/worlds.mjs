import {attachEntranceSequence,attachSkyDepartureSpace} from './entrance-sequences.mjs';
import {campaignCatalog} from './catalog.mjs';
import {attachSecretChallenge} from './secrets.mjs';
import {attachMemorySecrets} from './memory-secrets.mjs';

// Authored safe landings, shared by all actors. These are invisible progress
// gates, not flags or a continuously updated last-position save.
const checkpoints={
  '1-1':[['area-0',1280,208]],
  '1-2':[['area-1',32,208],['area-1',1488,208],['area-3',8,176]],
  '1-3':[['area-0',1232,96],['area-0',2080,208]],
  '1-4':[['area-0',1520,160]],
  // Fixed, authored safe supports for the expanded campaign. These positions
  // are an adaptation, not a claim to reproduce the cartridge's checkpoint table.
  '2-1':[['area-0',1808,208]], '2-2':[['area-1',1632,208]], '2-3':[['area-0',1872,208]],
  '3-1':[['area-0',1760,208]], '3-2':[['area-0',1824,208]], '3-3':[['area-0',1360,176]],
  '4-1':[['area-0',1920,208]], '4-2':[['area-1',1920,208]], '4-3':[['area-0',1824,144]],
  '5-1':[['area-0',1792,208]], '5-2':[['area-0',1792,208]], '5-3':[['area-0',1584,176]],
  '6-1':[['area-0',1664,208]], '6-2':[['area-0',1920,208]], '6-3':[['area-0',1568,208]],
  '7-1':[['area-0',1632,208]], '7-2':[['area-1',1632,208]], '7-3':[['area-0',1840,208]],
};

/** Register every restart destination once. Contact markers retain their
 * authored overlap trigger; invisible campaign progress gates are separate.
 * The stage and save owner consume this same registry, including editor maps.
 */
export function registerCampaignCheckpoints(plan,fixedLandings=[]) {
  const fail=message=>{throw new TypeError('Campaign checkpoint: '+message);};
  const validId=value=>typeof value==='string'&&/^[A-Za-z0-9][A-Za-z0-9._:-]{0,79}$/.test(value);
  const rect=(value,room,label)=>{
    if(!value||!['x','y','w','h'].every(k=>Number.isFinite(value[k]))||value.w<=0||value.h<=0
       ||value.x<0||value.y<0||value.x+value.w>room.width||value.y+value.h>room.height)fail(label+' has invalid room bounds');
  };
  if(!plan?.stage||!plan.rooms||!Array.isArray(fixedLandings))fail('missing plan or landing list');
  const points=[],registered=new Set();
  const key=(roomId,spawnId)=>roomId+'\0'+spawnId;
  for(const [index,landing] of fixedLandings.entries()){
    if(!Array.isArray(landing)||landing.length!==3)fail('invalid fixed landing');
    const [roomId,x,feet]=landing,room=plan.rooms[roomId],spawnId='campaign-checkpoint-'+(index+1);
    if(!room||!Array.isArray(room.objects))fail('fixed landing room missing '+roomId);
    const target={id:spawnId,kind:'spawn',x,y:feet-24,w:12,h:24};rect(target,room,spawnId);
    const existing=room.objects.find(o=>o.id===spawnId);
    if(existing&&(['kind','x','y','w','h'].some(k=>existing[k]!==target[k])))fail('fixed spawn id already occupied '+spawnId);
    if(!existing)room.objects.push(target);
    points.push({roomId,spawnId,x,rank:index+1,activation:'progress'});registered.add(key(roomId,spawnId));
  }
  for(const [roomId,room] of Object.entries(plan.rooms)){
    if(!Array.isArray(room.objects))fail('room objects missing '+roomId);
    for(const object of room.objects)if(object.kind==='checkpoint'){
      if(!validId(object.id)||!validId(object.targetSpawn)||Object.hasOwn(object,'targetRoom'))fail('invalid local marker '+object.id);
      rect(object,room,object.id);
      const target=room.objects.find(o=>o.kind==='spawn'&&o.id===object.targetSpawn);
      if(!target)fail('local spawn missing '+roomId+'/'+object.targetSpawn);
      rect(target,room,object.targetSpawn);
      if(registered.has(key(roomId,target.id)))continue;
      // Contact checkpoints do not invent a traversal order across rooms.
      const rank=Math.max(0,...points.filter(p=>p.activation==='progress'&&p.roomId===roomId&&p.x<=target.x).map(p=>p.rank));
      points.push({roomId,spawnId:target.id,x:target.x,rank,activation:'contact',checkpointId:object.id});
      registered.add(key(roomId,target.id));
    }
  }
  for(const [roomId,policy]of Object.entries(plan.stage.roomPolicies||{})){
    const room=plan.rooms[roomId],target=room?.objects.find(o=>o.kind==='spawn'&&o.id===policy.entryCheckpoint);
    if(!target)fail('branch entry checkpoint missing');rect(target,room,target.id);
    points.push({roomId,spawnId:target.id,x:target.x,rank:0,activation:'entry'});
  }
  plan.stage.checkpoints=points;
  return points;
}

/** A fresh plan per entry: neither actors nor rooms can mutate the content registry. */
export function createCampaignWorld(level,characterId,{catalog=campaignCatalog}={}) {
  const source=catalog.world(level);
  const profile=catalog.character(characterId);
  if(!source||!profile)throw new RangeError('Unknown campaign level or character');
  const world=structuredClone(source);
  world.plan.character={...structuredClone(profile),capabilities:[...profile.abilities],motion:{...profile.motion,maxHealth:profile.maxHealth}};
  world.plan.stage.characters=catalog.heroIds();
  world.plan.stage.status='candidate';
  world.visualRooms.forEach(r=>{
    r.playHero=characterId;
    if(world.appearance?.[r.roomId])r.presentation=structuredClone(world.appearance[r.roomId]);
    // The upstream EndInsideCastle macro owns the fake Bowser identity. Older
    // workshop exports omitted it from the expanded boss marker: recover it
    // from that macro, retaining an explicitly authored boss override.
    for(const boss of r.markers||[])if(/^(marker-Bowser|enemy-bowser)$/.test(boss.kind)){
      const finish=(r.markers||[]).filter(m=>m.kind==='castle-finish'&&m.x<=boss.x).sort((a,b)=>b.x-a.x)[0];
      boss.source={...boss.source,spawnType:boss.source?.spawnType||finish?.source?.spawnType||'Goomba',spawnSettings:boss.source?.spawnSettings||finish?.source?.spawnSettings||{},throwing:boss.source?.throwing??finish?.source?.throwing??false};
    }
  });
  if(catalog===campaignCatalog)attachMemorySecrets(world);
  attachEntranceSequence(world);
  attachSkyDepartureSpace(world);
  registerCampaignCheckpoints(world.plan,world.checkpoints||checkpoints[level]||[]);
  if(world.progression?.kind!=='post-credits')attachSecretChallenge(world,profile);
  return world;
}
export const campaignContent=Object.freeze(campaignCatalog.worlds().map(w=>Object.freeze({id:w.level,title:w.plan.stage.title,rooms:Object.keys(w.plan.rooms)})));
