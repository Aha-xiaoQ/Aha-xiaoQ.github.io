// Optional feats consume accepted gameplay facts; they never change combat or maps.
export const CHALLENGE_ACHIEVEMENTS=Object.freeze([
 ['life-code','加命秘籍','上上下下左右左右，老朋友还记得最后两个按键。',true],
 ['mario-wall-clip','水管工的穿墙术','马里奥在 1-2 出口管道边，背对墙壁完成一次蹲跳穿墙。小时候那个传说，是真的。',true],
 ['crouch-passage','贴地飞行','在 1-2 先跑起来，再蹲下滑过一格高的狭缝。帽子保住了，速度也没白攒。',true],
 ['roof-rail','天花板战神','忍龙爬到最上沿，站稳后从天花板巡视战场。地面太挤，换条路走。',true],
 ['rooftop-rescue','接应成功','从城堡顶部抵达营救房。管道工，这次轮到你放梯子了。',true],
 ['odd-brick','这块砖不对劲','碰一碰 1-1 隐藏蘑菇后，那块多出来的砖。原来你也记得地图。',true],
 ['bad-trade','血亏交易','魂斗罗把 S 弹换成 M 弹。字母往前了，心情往后了。',true],
 ['guest-princess','这次换你说谢谢','用马里奥以外的英雄救出最终城堡的公主，让管道工亲自道谢。',true],
 ['rock-boss','这才叫硬实力','搬起砖块，给 BOSS 最后一击。剪刀再快，也赢不了石头。',true],
 ['falling-tank','天降陨石？？？','魂斗罗被从头顶落下的固定坦克砸倒。原来不是所有东西都适合接住。',true],
 ['express-descent','紧急速降','踩上下降平台，一路坐到来不及下车。',true],
 ['peaceful-clear','今天休战','从关卡起点出发，不击败任何敌人且不死亡地完成一个经典关卡。'],
 ['coinless-clear','路过，不找零','从关卡起点出发，不收集金币且不死亡地完成一个经典关卡。'],
 ['untouched-clear','碰不到，根本碰不到','从关卡起点出发，不受伤、不死亡地完成一个经典关卡。'],
 ['base-kit-clear','出厂配置，照样通关','从关卡起点出发，全程保持初始装备、不使用无敌星且不死亡地通关。'],
 ['comeback-clear','我还会回来的','在一关内升级、受伤退级后，再次升级并活着通关。'],
 ['last-life-clear','这条命，含金量很高','只剩最后一条生命时完成一个经典关卡。'],
 ['buzzer-flag','时间管理大师','倒计时仅剩 1～10 时抓住旗杆。'],
 ['shell-koopa','以壳制壳','用飞驰的龟壳击败另一只乌龟。',true],
 ['single-star-five','这首歌还没放完','在同一颗无敌星的效果内连续撞倒五个敌人。'],
 ['bill-three-guns','字母表，轮流上班','魂斗罗在一关内用 M、S、F、L 中三种不同武器击败敌人。'],
 ['ryu-gardener','忍法·修剪盆栽','忍龙用火焰忍具击败一株食人花。',true],
 ['tank-triple','清场，连招都省了','坦克用一次手榴弹道具消灭至少三个敌人。'],
 ['slime-stomp','代打的是史莱姆','骑着史莱姆坐骑，从上方踩倒一个敌人。',true],
 ['ori-return','这份快递，原路退回','奥日用反弹的弹丸击败敌人。',true],
 ['sonic-star','这次不用七颗','索尼克带着升级护盾吃到一颗无敌星。',true],
 ['jackal-escort','空中管制，接人回家','在同一关击落黑色投弹机，并送至少五名人质到机场。',true],
].map(([id,title,description,secret=false])=>Object.freeze({id,title,description,secret})));

const classic=id=>/^[1-8]-[1-4]$/.test(id||'');
const scope=f=>typeof f.runId==='string'&&f.stageInstanceId&&classic(f.levelId)?JSON.stringify([f.runId,f.levelId,f.stageInstanceId,f.hero]):null;
export function createAchievementChallenges(unlock){
 let attempt=null;
 return function observe(type,f={}){
  if(type==='menu-life-code'&&f.screen==='character-select'&&f.lives===30&&f.accepted===true)unlock('life-code');
  if(type==='native-enemy-defeated'){
   if(f.entityId&&f.contract&&f.sceneId&&f.boss===true&&f.cause==='super-arm')unlock('rock-boss');
   return;
  }
  if(type==='native-objective'&&f.hero==='ryu'&&f.sceneId==='ryu-bar'&&f.id==='roof-rail'&&Number.isSafeInteger(f.value)&&f.value>0)unlock('roof-rail');
  const key=scope(f);
  if(type==='stage-start'){
   const row=f.statistics?.levels?.find(r=>r.level===f.levelId);
   // Unknown history is not a zero. Cold continuation/retry cannot earn a
   // full-course feat from just the remaining part of a level.
   const full=!!key&&f.statistics?.partial===false&&(!row||row.frames===0)&&!row?.deaths&&!row?.retries&&!row?.continues;
   attempt=key?{key,full,alive:true,coins:0,kills:0,hits:0,base:f.upgraded===false&&f.starTicks===0,armed:f.upgraded===true,downgraded:false,rearmed:false,star:null,tank:null,guns:new Set(),seen:new Set(),bomber:false,rescued:0}:null;
   return;
  }
  const a=attempt;if(!key||!a||a.key!==key)return;
  if(type==='objective'&&f.hero==='mario'&&f.levelId==='1-2'&&f.roomId==='area-1'&&f.id==='mario-wall-clip'&&f.branchId==='blank-world'&&f.method==='crouch-jump-pipe'&&f.exitX===2800)unlock('mario-wall-clip');
  if(type==='objective'&&f.id==='crouch-passage'&&f.levelId==='1-2'&&f.roomId==='area-1'&&f.method==='running-crouch'&&f.width>=16&&f.distance>f.width)unlock('crouch-passage');
  if(type==='objective'&&f.hero==='ryu'&&f.id==='roof-rail'&&Number.isSafeInteger(f.value)&&f.value>0)unlock('roof-rail');
  if(type==='objective'&&f.id==='rooftop-rescue'&&f.hero==='jackal'&&f.levelId.endsWith('-4')&&f.markerId)unlock('rooftop-rescue');
  if(['block-bumped','brick-broken'].includes(type)&&f.levelId==='1-1'&&f.roomId==='area-0'&&f.entityId==='r021')unlock('odd-brick');
  if(type==='item-collected'&&f.hero==='bill'&&f.previousWeapon==='S'&&f.weapon==='M')unlock('bad-trade');
  if(type==='stage-clear'&&f.levelId==='8-4'&&f.hero!=='mario')unlock('guest-princess');
  if(type==='death'){if(f.hero==='bill'&&f.cause?.kind==='enemy-contact'&&f.cause.contract==='contra:contra-turret'&&f.cause.fromAbove===true)unlock('falling-tank');if(f.cause?.kind==='falling-platform'&&f.cause.platformId)unlock('express-descent');a.alive=false;a.star=null;a.tank=null;return;}
  if(type==='secret'){a.full=false;a.base=false;a.star=null;return;}
  if(type==='room-enter'){a.star=null;a.tank=null;return;}
  if(f.upgraded===true){a.armed=true;a.base=false;if(a.downgraded)a.rearmed=true;}
  if(f.starTicks>0)a.base=false;
  if(type==='player-downgraded'){a.hits++;if(a.armed)a.downgraded=true;return;}
  if(type==='coin-collected'&&f.value>0)a.coins+=f.value;
  if(type==='item-collected'&&f.kind==='star'){a.star={room:f.roomSerial,count:0};if(f.hero==='sonic'&&f.gear?.upgradeTier>0)unlock('sonic-star');}
  if(type==='flag-grab'&&Number.isFinite(f.timeLeft)&&f.timeLeft>0&&f.timeLeft<=10)unlock('buzzer-flag');
  if(type==='objective'&&f.id==='rescue-delivered'&&Number.isInteger(f.value))a.rescued=Math.max(a.rescued,f.value);
  if(type==='enemy-defeated'&&f.entityId&&f.contract&&f.cause){
   const id=JSON.stringify([f.roomSerial,f.entityId]);if(a.seen.has(id))return;
   if(a.seen.size>=4096){a.full=false;return;}a.seen.add(id); // bounded even for authored endless rooms
   a.kills++;
   const h=f.hero,c=f.cause,g=f.gear||{},koopa=f.contract==='mario:koopa';
   if(c==='shell'&&koopa)unlock('shell-koopa');
   if(c==='star'&&f.starTicks>0&&a.star?.room===f.roomSerial&&++a.star.count>=5)unlock('single-star-five');
   if(h==='bill'&&c==='bill-shot'&&['M','S','F','L'].includes(f.attackWeapon)){a.guns.add(f.attackWeapon);if(a.guns.size>=3)unlock('bill-three-guns');}
   if(h==='ryu'&&c==='ninja-weapon'&&f.attackWeapon==='flame'&&f.contract==='mario:piranha')unlock('ryu-gardener');
   if(h==='tank'&&c==='powerup'&&Number.isInteger(f.tick)){
    const effect=JSON.stringify([f.roomSerial,f.tick]);if(a.tank?.effect!==effect)a.tank={effect,count:0};if(++a.tank.count>=3)unlock('tank-triple');
   }
   if(h==='sandboxTrio'&&c==='slime-stomp')unlock('slime-stomp');
   if(h==='ori'&&c==='ori-bash-reflect')unlock('ori-return');
   if(h==='jackal'&&f.contract==='jackal-nes:bomber'&&c==='jackal-main-weapon')a.bomber=true;
  }
  if(f.hero==='jackal'&&a.bomber&&a.rescued>=5)unlock('jackal-escort');
  if(type==='stage-clear'){
   if(f.lives===1)unlock('last-life-clear');
   if(a.alive&&a.rearmed)unlock('comeback-clear');
   if(a.full&&a.alive){
    if(!a.kills)unlock('peaceful-clear');if(!a.coins)unlock('coinless-clear');if(!a.hits)unlock('untouched-clear');if(a.base)unlock('base-kit-clear');
   }
   attempt=null;
  }
 };
}
