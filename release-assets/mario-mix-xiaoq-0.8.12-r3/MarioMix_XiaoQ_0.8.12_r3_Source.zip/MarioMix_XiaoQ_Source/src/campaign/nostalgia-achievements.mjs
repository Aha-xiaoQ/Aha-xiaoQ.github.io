import {MEMORY_SECRETS} from '../content/memory-secrets.mjs';

// These one-event feats consume accepted world facts. The shelf owns saved
// deduplication and the six-secret album; this observer keeps no run state.
export const MEMORY_TROPHY_IDS=Object.freeze([
 'coin-cache','air-life','night-star','underground-life','cloud-life','final-supply',
].map(id=>'memory-'+id));
export const NOSTALGIA_ACHIEVEMENTS=Object.freeze([
 ['mario-fire-bowser','这次不拆桥','用马里奥的火球击败库巴。桥先留着，今天换个收工办法。'],
 ['bullet-step','你的炮弹，我的踏板','从上方踩倒一枚炮弹比尔。飞得再快，也能借来落个脚。'],
 ['lakitu-step','云端账号已下线','从上方踩倒朱盖木。云上那位，今天提前下班。'],
 ['shell-bowling','保龄球全中','让滑行的龟壳连续撞倒敌人，直到连杀奖励变成加命。'],
 ['brick-atm','取款机也会下班','取完同一块多金币砖的十枚金币。叮到最后，它也要休息。'],
 ['water-fire','物理老师别看','用马里奥的火球在水下击败一条飞鱼。今天先按卡带里的规矩来。'],
 ['jackal-boat','业务拓展到海上了','驾驶赤色要塞吉普车，在水下区域用主武器击沉一艘敌方船只。'],
 ['memory-coin-cache','墙里有个小金库','领取 1-2 地下砖墙里那份藏好的金币。路过时，再敲一下。',true],
 ['memory-air-life','空气炸出一条命','领取 2-1 隐形砖里的加命蘑菇。看起来空着，也可以试着跳一下。',true],
 ['memory-night-star','夜跑歌单已就绪','领取 3-1 夜路砖块里的无敌星。熟悉的音乐，该响起来了。',true],
 ['memory-underground-life','地下也有售后','领取 4-2 地下隐藏砖里的加命蘑菇。下一次失误，有备份了。',true],
 ['memory-cloud-life','云监工的盲区','领取 6-1 隐形砖里的加命蘑菇。上面忙着丢刺球，下面悄悄加条命。',true],
 ['memory-final-supply','决战前的快递','领取 8-1 秘密砖块里的强化道具。最后一个世界，也有补给签收。',true],
 ['memory-album','这卡带真没白买','找到并领取六处新增的秘密奖励。六个角落，全部记住了。',true],
].map(([id,title,description,secret=false])=>Object.freeze({id,title,description,secret})));

const identified=id=>typeof id==='string'&&id.trim().length>0;
export function observeNostalgia(type,f={},unlock){
 if(!f||typeof f!=='object')return;
 if(type==='enemy-defeated'&&identified(f.entityId)){
  if(f.hero==='mario'&&f.contract==='mario:bowser'&&f.cause==='fireball')unlock('mario-fire-bowser');
  if(f.contract==='mario:bulletbill'&&f.cause==='stomp')unlock('bullet-step');
  if(f.contract==='mario:lakitu'&&f.cause==='stomp')unlock('lakitu-step');
  if(f.hero==='mario'&&f.contract==='mario:cheepcheep'&&f.cause==='fireball'&&f.underwater===true)unlock('water-fire');
  if(f.hero==='jackal'&&f.contract==='jackal-nes:boat'&&f.cause==='jackal-main-weapon'&&f.underwater===true)unlock('jackal-boat');
 }
 if(type==='extra-life'&&f.reason==='shell-chain'&&identified(f.entityId))unlock('shell-bowling');
 if(type==='block-reward-exhausted'&&identified(f.entityId)&&['multi','coin'].includes(f.content)&&f.remaining===0&&f.rewardCount===10)unlock('brick-atm');
 if(type==='block-reward-collected'&&f.collected===true){
  const secret=MEMORY_SECRETS.find(s=>s.id===f.secretId);
  // Authored content stays stable when a mushroom becomes a flower or a
  // character-native supply. The accepted pickup carries its source block.
  if(secret&&f.levelId===secret.level&&f.roomId===secret.roomId&&f.entityId===secret.blockId&&f.content===secret.content)unlock('memory-'+secret.id);
 }
}
