/* Include immediately before the end of the legacy Terra IIFE. The outer
 * closure declares `let mainlineDrawCharacter` before that IIFE. This grants
 * read-only access to Terra's decoded layers and the other native atlases.
 * The caller owns camera transforms. All coordinates here are world-space;
 * no old scene, input, player, camera, animation clock or DOM is changed.
 */
mainlineDrawCharacter = function mainlineDrawCharacter(g, p, tick = 0, view = {}) {
  const id = p.renderId || p.hero, face = p.facing < 0 ? -1 : 1;
  const center = Math.round(p.x + p.w / 2), foot = Math.round(p.y + p.h);
  const motion = Math.abs(p.vx || 0), moving = p.grounded && motion > .08;
  const dying = view.mode === 'dying' || !!p.dead;
  const attacking = Number(p.attackTicks || p.attackAnimation || 0);
  const shooting = Number(p.shotCooldown || p.attackCooldown || attacking || 0) > 0;
  let pose = dying ? 'death' : p.hurtTicks ? 'hurt' : !p.grounded ? 'jump' : moving ? 'run' : 'idle';
  let frameId = '', asset = '', drawn = false;
  const finish = () => ({hero: p.hero, pose, frame: frameId, asset, drawn});
  const hasImage = im => !!im && (im.width || im.naturalWidth) > 0;
  const crop = (im, r, x, y, scale = 1) => {
    if (!hasImage(im)) return false;
    g.drawImage(im, r[0], r[1], r[2], r[3], x, y, r[2] * scale, r[3] * scale);
    drawn = true; return true;
  };
  g.save();
  try {
    g.imageSmoothingEnabled = false;
    if (p.invuln && Math.floor(tick / 4) % 2 && !dying) { pose = 'invulnerable-hidden'; return finish(); }
    if (view.opacity !== undefined) g.globalAlpha *= view.opacity;

    if (id === 'mario') {
      const prefix = p.power ? 'big_' : 'small_';
      let name = prefix + 'idle';
      if (dying) name = 'dead';
      else if (view.mode === 'flag' && (view.flagPhase || 0) === 0) { name = prefix + 'climb' + Math.floor(tick / 8) % 2; pose = 'climb'; }
      else if (p.power && p.crouch) { name = 'big_crouch'; pose = 'crouch'; }
      else if (!p.grounded && view.mode !== 'pipe') name = prefix + 'jump';
      else if (moving) { name = prefix + 'run' + Math.floor((p.anim || 0) / 6) % 3; if (p.vx * face < -.08) { name = prefix + 'skid'; pose = 'skid'; } }
      const variant = p.star ? ['normal', 'star1', 'star2', 'star3'][Math.floor(tick / 4) % 4] : p.power === 2 ? 'fire' : 'normal';
      const im = classicSprite(name, variant);
      asset = 'classic/' + variant; frameId = name;
      if (hasImage(im)) {
        g.translate(center, foot); g.scale(face, 1);
        g.drawImage(im, Math.round(-im.width / 2), -im.height); drawn = true;
      }
      return finish();
    }

    g.translate(center, foot); g.scale(face, 1);
    if (id === 'bill') {
      asset = 'assets/bill.png';
      const im = mixImages.bill, n = moving ? Math.floor((p.anim || 0) / 20) % 3 : -1;
      const bob = n === 1 ? 1 : 0;
      if (dying) {
        const age = view.deathTick || 0, settled = p.grounded && age > 48;
        const r = settled ? [185, 19, 34, 11] : Math.floor(age / 7) % 2 ? [250, 44, 23, 15] : [251, 13, 23, 18];
        frameId = 'death-' + (settled ? 'settled' : Math.floor(age / 7) % 2);
        crop(im, r, settled ? -17 : -11, -r[3]);
      } else if (!p.grounded) {
        const f = Math.floor((p.airTicks || 0) / 5) % 4;
        pose = 'somersault'; frameId = 'air-' + f;
        crop(im, [117 + f % 2 * 29, 123 + Math.floor(f / 2) * 29, 28, 28], -14, -28);
      } else if (p.crouch) {
        pose = shooting ? 'prone-shoot' : 'prone'; frameId = 'prone-' + (shooting ? 1 : 0);
        crop(im, [130, shooting ? 43 : 13, 34, 17], -17, -17);
      } else {
        const legs = n < 0 ? [291, 123] : [[320, 123], [291, 152], [320, 152]][n];
        const aimY = p.aimY || 0, aimX = p.aimX ?? face;
        frameId = 'legs-' + n + '-aim-' + aimX + ':' + aimY + '-fire-' + Number(shooting);
        if (aimY && !aimX && n < 0 && aimY < 0) {
          pose = 'aim-up'; crop(im, [59, 7, 28, 57], -14, -55);
        } else {
          crop(im, [...legs, 28, 28], -14, -26);
          if (aimY && aimX) {
            pose = moving ? 'run-aim' : 'aim';
            crop(im, [shooting ? 204 : 175, aimY < 0 ? 123 : 65, 28, 57], -11, (aimY < 0 ? -56 : -53) + bob);
          } else if (aimY < 0) {
            pose = 'run-aim-up'; crop(im, [shooting ? 262 : 233, 123, 28, 57], -14, -57 + bob);
          } else {
            if (shooting) pose = moving ? 'run-shoot' : 'shoot';
            crop(im, [117, shooting ? 94 : 65, 57, 28], -28, -38 + bob);
          }
        }
      }
      return finish();
    }

    if (id === 'megaman') {
      asset = 'assets/megaman.png';
      const airborne = !p.grounded;
      const col = airborne ? 181 : moving ? 73 + 36 * (Math.floor((p.anim || 0) / 12) % 3) : 37;
      const row = shooting ? 79 : airborne || moving ? 43 : 7;
      pose = dying ? 'death' : shooting ? (airborne ? 'air-shoot' : moving ? 'run-shoot' : 'shoot') : pose;
      if (dying) {
        const cells = [[37, 115], [55, 115], [37, 133], [55, 133]], f = Math.floor(tick / 4) % 4;
        frameId = 'death-particle-' + f;
        const age = Math.max(0, view.deathTick || 0);
        for (let n = 0; n < 8; n++) crop(mixImages.megaman, [...cells[f], 17, 17], Math.cos(n * Math.PI / 4) * age * .8 - 8, Math.sin(n * Math.PI / 4) * age * .8 - 22);
      } else {
        frameId = col + ':' + row; crop(mixImages.megaman, [col, row, 35, 35], -17, -33);
        if (shooting) crop(mixImages.megaman, [290, 156, 13, 6], 3, -14);
        if ((p.charge || 0) >= 30) { g.strokeStyle = tick % 8 < 4 ? '#7bffff' : '#ffffff'; g.strokeRect(-12, -26, 24, 25); }
      }
      return finish();
    }

    if (id === 'ryu') {
      asset = 'relay12/assets/ryu-atlas05.png';
      let f = 0;
      if (dying || p.hurtTicks) { f = 6; pose = 'hurt'; }
      else if (attacking) { f = attacking > 10 ? 10 : attacking > 6 ? 11 : 13; if (p.crouch) f += 15; pose = p.crouch ? 'crouch-slash' : 'slash'; }
      else if (p.wallSide && !p.grounded) { f = 4 + (p.climbing ? Math.floor((p.climbAnim || tick) / 8) % 2 : 0); pose = p.climbing ? 'climb' : 'wall'; }
      else if (p.crouch) { f = 24; pose = 'crouch'; }
      else if (!p.grounded) { f = 6 + Math.floor((p.airTicks || 0) / 6) % 4; pose = 'somersault'; }
      else if (moving) f = 1 + Math.floor((p.anim || 0) / 12) % 3;
      const wide = [11, 13, 22, 26, 28].includes(f), cw = wide ? 52 : 26;
      frameId = String(f);
      crop(R12_SPRITES['ryu-atlas05'] || R12_SPRITES.ryu, [(f % 10) * 26 + (f === 5 ? -3 : 0), Math.floor(f / 10) * 36, cw, 36], -13, -34);
      return finish();
    }

    if (id === 'tank') {
      asset = 'relay12/assets/tank-colors06.png';
      const rank = Math.max(0, Math.min(3, p.weaponTier || p.power || 0));
      // The source atlas has separate horizontal facings. Undo the common
      // facing transform so the crop itself is the authority for orientation.
      g.scale(face, 1);
      const dir = face > 0 ? 0 : 2, track = moving ? (p.anim || 0) * 2 : 0;
      const f = r06TankFrame(dir, rank, track), palette = Math.max(0, Math.min(3, view.tankPalette || 0));
      frameId = f + ':' + palette; pose = p.propelling ? 'propulsion' : !p.grounded ? 'jump' : moving ? 'tracks' : 'idle';
      crop(R12_SPRITES['tank-colors06'], [f * 16, palette * 16, 16, 16], -8, -16);
      if (p.propelling) { g.fillStyle = tick % 4 < 2 ? '#fff1a1' : '#f69e35'; g.fillRect(-5, 0, 3, 3 + tick % 3); g.fillRect(2, 0, 3, 3 + tick % 3); }
      return finish();
    }

    if (id === 'sandboxTrio') {
      asset = 'terraria/native-body-layers';
      const armor = p.armor || ({zenith:'solar',sdmg:'vortex',lastPrism:'nebula',terraprisma:'stardust'})[p.weapon] || 'platinum', weapon = p.weapon || 'starfury', scale = .75;
      const n = !p.grounded ? 5 : moving ? 6 + Math.floor((p.anim || 0) / 5) % 14 : 0;
      const bob = [7, 8, 9, 14, 15, 16].includes(n) ? -2 : 0;
      const actor = {p: {...p, attackFacing: face, t10SwingDuration: 22}, mounted: false,
        kit: null, t13Weapon: weapon, t13WeaponOverride: true, tool: 0};
      const weaponPose = t10Pose(actor, attacking, 0);
      const part = key => r06Images[armor + key] ? armor + key : 'platinum' + key;
      const tint = (key, color) => {
        const im = r06Images[key] || photos[key];
        return hasImage(im) ? t10TintCache.get(key + ':' + color.join(',') + ':' + im.width + ':' + im.height) || im : null;
      };
      const layer = (key, r, x = -20, y = -54) => crop(r06Images[key] || photos[key], r, x, y);
      g.scale(scale, scale);
      const skin = tint('skinBody', [255, 207, 167]);
      crop(skin, [320, 0, 40, 56], -20, -54 + bob); layer(part('Body'), [320, 0, 40, 56], -20, -54 + bob);
      layer(part('Legs'), [0, n * 56, 40, 56]); layer(part('Body'), [0, 0, 40, 56], -20, -54 + bob);
      for (const [key, color] of [['skinHead', [255, 207, 167]], ['eyeWhite', null], ['eyeIris', [44, 83, 111]], ['hair', [151, 99, 52]]]) {
        crop(color ? tint(key, color) : r06Images[key], [0, 0, 40, 56], -20, -54 + bob);
      }
      layer(part('Head'), [0, 0, 40, 56], -20, -54 + bob);
      if (weaponPose.using) {
        const im = r06Images[weaponPose.weapon] || photos[weaponPose.weapon];
        if (hasImage(im)) {
          g.save(); g.translate(weaponPose.hand.x, weaponPose.hand.y + bob); g.rotate(weaponPose.rotation);
          g.drawImage(im, -weaponPose.def.grip[0] * weaponPose.def.scale, -weaponPose.def.grip[1] * weaponPose.def.scale, im.width * weaponPose.def.scale, im.height * weaponPose.def.scale);
          g.restore(); drawn = true;
        }
        g.save(); g.translate(weaponPose.shoulder.x, weaponPose.shoulder.y + bob); g.rotate(weaponPose.theta - Math.atan2(8, 18));
        crop(skin, [200, 0, 40, 56], -12, -28); layer(part('Body'), [200, 0, 40, 56], -12, -28); g.restore();
      } else {
        crop(skin, [80, 0, 40, 56], -20, -54 + bob); layer(part('Body'), [80, 0, 40, 56], -20, -54 + bob);
      }
      if (attacking) pose = 'sword';
      frameId = armor + '/legs-' + n + '/attack-' + attacking;
      return finish();
    }

    if (id === 'ori') {
      const full = o25Images.get('ori'), im = full || o25Fallback;
      asset = full ? 'ori/full-native-atlas' : 'ori/embedded-native-atlas';
      pose = p.gliding ? 'glide' : p.doubleTicks ? 'double' : !p.grounded ? p.vy < 0 ? 'jump' : 'fall' : moving ? 'run' : 'idle';
      const phase = moving ? (p.anim || 0) * 2 : tick;
      const age = p.gliding ? p.glideTicks || 0 : p.doubleTicks ? 14 - p.doubleTicks : !p.grounded ? p.airTicks || 0 : tick;
      const f = full && typeof a39Frame === 'function' ? a39Frame(pose, age, {run: (p.anim || 0) / 10.8, spin: age * .25}) : o25Frame(pose, phase, !!full);
      if (p.gliding) {
        const age = p.glideTicks || 0, featherFrame = age < 15 ? Math.min(2, Math.floor(age / 5)) : 4 + Math.floor((age - 15) / 5) % 6;
        f.row = full ? featherFrame : Math.min(featherFrame, 3);
        crop(o26Pictures.get('feather') || o25Images.get('feather'), [0, featherFrame * 128, 128, 128], O26_FEATHER.left, O26_FEATHER.top, .5);
      }
      frameId = f.col + ':' + f.row;
      if (f.ball) {
        // R39's approved curl rotates about the actual curled body centre.
        g.translate(0, -8); g.rotate(f.rot);
        crop(im, [3 * 64 + 14, 20, 36, 36], -9, -9, .5);
      } else {
        if (f.rot) { g.translate(0, -10); g.rotate(f.rot); g.translate(0, 10); }
        crop(im, [f.col * 64, f.row * 68, 64, 68], -16, -31, .5);
      }
      return finish();
    }

    if (id === 'sonic') {
      asset = 'sonic/modgen-native-atlas';
      pose = dying ? 'death' : p.hurtTicks ? 'hurt' : p.spinCharge ? 'charge' : p.rolling || !p.grounded ? 'jump' : moving ? motion > 2.8 ? 'run' : 'jog' : 'idle';
      const a = S33_FRAMES[pose], phase = p.spinCharge ? tick / 4 : pose === 'jump' ? (p.airTicks || tick) / 3 : (p.anim || 0) / 5;
      const f = Math.floor(phase) % a[4], scale = pose === 'jump' || pose === 'charge' ? .64 : .61;
      frameId = pose + ':' + f;
      crop(s33Image, [a[0] + f * a[2], a[1], a[2], a[3]], -a[2] * scale / 2, -a[3] * scale, scale);
      return finish();
    }
    throw new RangeError('Unknown mainline render character: ' + id);
  } finally { g.restore(); }
};
