import {NOSTALGIA_ACHIEVEMENTS,MEMORY_TROPHY_IDS,observeNostalgia} from './nostalgia-achievements.mjs';
import {CHALLENGE_ACHIEVEMENTS,createAchievementChallenges} from './achievement-challenges.mjs';
// Account-local accomplishments are independent of a run/save slot. Gameplay
// emits facts; rules and durable deduplication live here, never in hero ports.
const ORIGINAL=[
 {id:'first-clear',title:'第一关，手热了',description:'完成任意关卡。先别拔卡带，好戏才刚开始。'},
 {id:'world-one',title:'这路我熟',description:'在一次冒险中完成 WORLD 1 的四个关卡。'},
 {id:'no-fall',title:'这次不用借命',description:'不死亡、不重试地完成一个关卡。旁边等接手的人，又坐回去了。'},
 {id:'mixed-company',title:'这盘卡带，含人量很高',description:'分别使用九位伙伴完成关卡。选人界面这次没有白逛。'},
 {id:'random-world',title:'下一位，请！',description:'以随机英雄完成 WORLD 1 的四个关卡。'},
 {id:'secret-victory',title:'串门顺便打个王',description:'击败专属挑战 BOSS 或完成特色挑战，并领取奖励。',secret:true},
 {id:'rescue-five',title:'一个都不能少',description:'在一关内将五名人质送到赤色要塞机场。',secret:true},
 {id:'classic-complete',title:'从蘑菇王国到天涯',description:'在一次冒险中完成全部 32 个经典关卡。'},
 {id:'after-credits',title:'你也玩过水下256关',description:'当年传说中的第 256 关，你也找过吧？完成 WORLD 9-1。',secret:true},
 {id:'blank-world',title:'打开负世界的大门',description:'编号留了白，出口也请了假。进入负世界。',secret:true},
 ...[
  ['bill','门后还有一扇门','魂斗罗'],['megaman','蓝色小伙的老本行','洛克人'],['ryu','龙剑还未生锈','忍龙'],['tank','鹰还在，家就在','坦克大战'],
  ['sandboxTrio','今晚别抬头','泰拉瑞亚'],['ori','把光带回森林','奥日'],['sonic','蛋头博士，又见面了','索尼克'],['jackal','别和她对视','赤色要塞'],
 ].map(([hero,title,name])=>({id:'challenge-'+hero,title,description:'完成'+name+'专属挑战并领取房内奖励。',secret:true})),
 {id:'arsenal-bill',title:'字母表里没有弱者',description:'魂斗罗累计取得 M、S、F、L 四种武器。'},
 {id:'arsenal-megaman',title:'剪刀之后，还有火焰',description:'洛克人取得最高级的火焰风暴。剪刀负责开路，火焰负责收场。'},
 {id:'arsenal-ryu',title:'忍者的百宝袋',description:'忍龙累计取得三种不同忍具。'},
 {id:'arsenal-tank',title:'这次连钢墙也拦不住',description:'坦克火力升到最高级。'},
 {id:'arsenal-sandboxTrio',title:'背包比人还忙',description:'泰拉瑞亚取得霰弹枪、史莱姆坐骑和飞碟。'},
 {id:'arsenal-ori',title:'赛恩，把灯开到最亮',description:'奥日的攻击升到最高级。森林里的小灯，也有大脾气。'},
 {id:'arsenal-sonic',title:'蓝刺猬的两件外套',description:'索尼克累计取得两种升级护盾。'},
 {id:'arsenal-jackal',title:'一发开花，四面欢迎',description:'吉普车主武器升到最高级。'},
 {id:'combat-mario',title:'借你脑袋落个脚',description:'用马里奥累计踩倒十个敌人。'},
 {id:'combat-bill',title:'S，就是舒坦',description:'使用 S 弹累计击败五个敌人。'},
 {id:'combat-megaman',title:'蓝色小伙，武器很多',description:'使用升级后的洛克人累计击败五个敌人。借来的绝招，用起来也很顺手。'},
 {id:'combat-ryu',title:'忍法：换个打法',description:'使用忍具攻击模式累计击败五个敌人。'},
 {id:'combat-tank',title:'三颗星，横着走',description:'满级坦克累计击败五个敌人。'},
 {id:'combat-sandboxTrio',title:'背包里的才是本体',description:'使用升级后的泰拉瑞亚角色累计击败十个敌人。装备栏终于开始认真工作。'},
 {id:'combat-ori',title:'赛恩，搭把手',description:'使用升级后的奥日累计击败五个敌人。'},
 {id:'combat-sonic',title:'你看见蓝色了吗',description:'索尼克累计以旋转攻击击败五个敌人。'},
 {id:'combat-jackal',title:'吉普车不走人行道',description:'驾驶吉普车累计碾过五名敌方步兵。'},
 {id:'coins-100',title:'叮！钱包有声音了',description:'累计收集一百枚金币。'},
 {id:'coins-1000',title:'管道工的年终奖',description:'累计收集一千枚金币。'},
 {id:'star-ten',title:'这首歌响起就该跑',description:'累计用无敌星击败十个敌人。'},
 {id:'castle-clear',title:'公主又不在这里？',description:'完成任意一座经典城堡。'},
 {id:'water-clear',title:'这关不用换气',description:'完成 2-2 或 7-2。游慢一点也没关系，倒计时可没有憋气。'},
 {id:'random-nine',title:'盲盒开到第九关',description:'在一次随机英雄冒险中完成九个不同经典关卡。下一个是谁？手柄也不知道。'},
 {id:'bomber-down',title:'击落敌方间谍',description:'那架黑飞机，果然不是来送快递的。击落黑色投弹机。',secret:true},
 {id:'all-achievements',title:'全成就',description:'童年的传说，今天全都打勾。解锁本版其余全部成就。'},
];

const milestones=[
 ['brick-burst','拆迁，一发包办','bestBurst',8,'一次攻击连同爆炸打碎至少 8 块马里奥砖。',true],
 ['coins-500','这不是零钱','coins',500,'累计收集 500 枚金币。'],
 ['coins-5000','蘑菇王国首富','coins',5000,'累计收集 5000 枚金币。砖里还有，慢慢找。'],
 ['enemies-50','热身结束','enemies',50,'在马里奥世界累计击败 50 个敌人。'],
 ['enemies-250','这一带我熟','enemies',250,'在马里奥世界累计击败 250 个敌人。'],
 ['enemies-1000','反派的童年阴影','enemies',1000,'在马里奥世界累计击败 1000 个敌人。'],
 ['clears-10','再来亿关','clears',10,'累计完成 10 次关卡。'],
 ['clears-32','卡带还没拔','clears',32,'累计完成 32 次关卡。'],
 ['clears-100','这台红白机归我了','clears',100,'累计完成 100 次关卡。'],
 ['clean-10','今天不借命','clean',10,'累计 10 次不死亡、不重试、不续命通关。'],
 ['score-100000','六位数的快乐','bestScore',100000,'在一次冒险中取得 100000 分。'],
 ['score-500000','分数快装不下了','bestScore',500000,'在一次冒险中取得 500000 分。'],
 ['score-1000000','百万分不是传说','bestScore',1000000,'在一次冒险中取得 1000000 分。'],
 ['lives-10','口袋里还有十条命','bestLives',10,'同时拥有至少 10 条生命。'],
 ['lives-30','不用输入那串秘籍','bestLives',30,'同时拥有至少 30 条生命。上下上下……先收起来。'],
 ['stars-5','背景音乐一换，主角登场','stars',5,'累计吃到 5 颗无敌星。'],
 ['stars-20','走到哪里，亮到哪里','stars',20,'累计吃到 20 颗无敌星。'],
 ['oneup-1','墙里藏着一条命','oneups',1,'吃到一朵加命蘑菇。'],
 ['oneup-10','备用人生批发商','oneups',10,'累计吃到 10 朵加命蘑菇。'],
 ['bricks-50','拆迁办临时工','bricks',50,'累计打碎 50 块马里奥砖。问号块不算。'],
 ['bricks-200','蘑菇王国装修队','bricks',200,'累计打碎 200 块马里奥砖。'],
 ['shell-10','借壳发挥','shell',10,'累计用龟壳击败 10 个敌人。'],
 ['guest-stomp-10','入乡随俗','guestStomp',10,'使用马里奥以外的角色，累计踩倒 10 个马里奥世界的敌人。'],
 ['minus-loop-three','永远不能离开的世界','minusLoops',3,'出口、起点、出口、起点……在负世界完成三次循环。',true],
].map(([id,title,metric,target,description,secret=false])=>({id,title,description,metric,target,secret}));
const extras=[
 {id:'ryu-dog-ambushed',title:'偷袭',description:'使用忍龙，被突然出现的狗击倒。',secret:true},
 {id:'ryu-dog-defeated',title:'少侠，好身手',description:'使用忍龙，击败一只偷袭的狗。',secret:true},
 {id:'shell-life',title:'龟壳牌续命机',description:'连续踩龟壳触发加命。别问还剩几条，先别松脚。',secret:true},
 {id:'flag-top',title:'五千分，顶格待遇',description:'在旗杆最高奖励区拿到 5000 分。'},
 {id:'warp-discovery',title:'放学回家抄近路',description:'通过跳关管道前往另一个世界。',secret:true},
 {id:'mario-thanks',title:'谢谢你，马里奥！',description:'使用马里奥完成一座城堡。那句熟悉的谢谢，又听到了。',secret:true},
 {id:'bill-clean-castle',title:'三十条命？一条就够',description:'使用魂斗罗不死亡、不重试、不续命地完成一座城堡。',secret:true},
 {id:'tank-water',title:'履带下面是海底',description:'驾驶坦克完成 2-2 或 7-2。不换泳姿，也能过海。',secret:true},
 {id:'sonic-minute',title:'迟到是不可能迟到的',description:'使用索尼克在一分钟内完成一个经典关卡，不死亡、不重试。'},
 {id:'challenge-tour',title:'串门串成了团建',description:'完成八位伙伴的全部专属挑战并领取奖励。',secret:true},
 {id:'both-bonus',title:'卡带背面的传说',description:'进入负世界，并完成 WORLD 9-1。小时候的传言，两件都验过了。',secret:true},
 {id:'all-castles',title:'库巴的八套房',description:'在同一次冒险中完成八座经典城堡。'},
];
const LEGACY_IDS=ORIGINAL.filter(a=>a.id!=='all-achievements').map(a=>a.id);
export const ACHIEVEMENTS=Object.freeze([...ORIGINAL.slice(0,-1),...milestones,...extras,...CHALLENGE_ACHIEVEMENTS,...NOSTALGIA_ACHIEVEMENTS,ORIGINAL.at(-1)].map(Object.freeze));
const IDS=new Set(ACHIEVEMENTS.map(a=>a.id));
const COMPLETION_IDS=ACHIEVEMENTS.filter(a=>a.id!=='all-achievements').map(a=>a.id);
const WORLD_ONE=['1-1','1-2','1-3','1-4'];
const CLASSIC=Array.from({length:32},(_,i)=>(1+(i>>2))+'-'+(1+i%4));
export function createAchievements({storage=null,key='mariomix.achievements.v1',heroIds=[],now=Date.now}={}){
 const heroes=new Set(heroIds),unlocked=new Map(),clearedHeroes=new Set(),pending=[],progress={},collections={};
 let dirty=false;const bursts=new Map(); const clearedRuns=new Set();
 const progressKeys=new Set([...milestones.map(a=>a.metric),'coins','star',...['mario','bill','megaman','ryu','tank','sandboxTrio','ori','sonic','jackal'].map(h=>'combat-'+h)]);
 const collectionValues={bill:['M','S','F','L'],ryu:['shuriken','windmill','flame','spin'],sandboxTrio:['boomstick','slimySaddle','ufo'],sonic:['plain-shield','lightning-shield']};
 try{const saved=JSON.parse(storage?.getItem(key)||'null');if(saved?.version===1){
  for(const k of (Array.isArray(saved.clearedRuns)?saved.clearedRuns:[]).slice(-256))if(typeof k==='string'&&k.length<180)clearedRuns.add(k);
  for(const [id,time] of Object.entries(saved.unlocked||{}))if(IDS.has(id)&&Number.isSafeInteger(time)&&time>=0)unlocked.set(id,time);
  for(const id of Array.isArray(saved.heroes)?saved.heroes:[])if(heroes.has(id))clearedHeroes.add(id);
  for(const [id,n]of Object.entries(saved.progress||{}))if(progressKeys.has(id)&&Number.isSafeInteger(n)&&n>=0)progress[id]=Math.min(n,1000000);
  for(const [h,values]of Object.entries(collectionValues))collections[h]=new Set((Array.isArray(saved.collections?.[h])?saved.collections[h]:[]).filter(v=>values.includes(v)));
 }}catch{} // An unavailable or corrupt optional trophy shelf cannot stop a game.
 const persist=()=>{try{storage?.setItem(key,JSON.stringify({version:1,catalogRevision:4,clearedRuns:[...clearedRuns],unlocked:Object.fromEntries(unlocked),heroes:[...clearedHeroes],progress,collections:Object.fromEntries(Object.entries(collections).map(([h,s])=>[h,[...s]]))}));}catch{}};
 const complete=()=>COMPLETION_IDS.every(id=>unlocked.has(id));
 function unlock(id){if(!IDS.has(id)||unlocked.has(id))return;unlocked.set(id,Math.max(0,Math.floor(now())));pending.push(ACHIEVEMENTS.find(a=>a.id===id));dirty=true;if(id!=='all-achievements'&&complete())unlock('all-achievements');}
 // Reconcile an older shelf on load, without replaying existing notifications.
 const earnedLegacyMeta=unlocked.has('all-achievements')&&LEGACY_IDS.every(id=>unlocked.has(id));
 if(!complete()&&!earnedLegacyMeta){if(unlocked.delete('all-achievements'))dirty=true;}else if(complete())unlock('all-achievements');
 if(dirty){persist();dirty=false;}
 function checkMilestones(id){for(const a of milestones)if(a.metric===id&&(progress[id]||0)>=a.target)unlock(a.id);}
 function add(id){progress[id]=Math.min(1000000,(progress[id]||0)+1);dirty=true;checkMilestones(id);return progress[id];}
 function best(id,n){if(Number.isSafeInteger(n)&&n>0&&n>(progress[id]||0)){progress[id]=Math.min(n,1000000);dirty=true;checkMilestones(id);}}
 function collect(hero,value){if(!collectionValues[hero]?.includes(value))return;const set=collections[hero]??=new Set();if(!set.has(value)){set.add(value);dirty=true;}if(set.size>=({bill:4,ryu:3,sandboxTrio:3,sonic:2}[hero]))unlock('arsenal-'+hero);}
 function equipment(f){const g=f.gear||{},h=f.hero;
  if(h==='bill')collect(h,g.weapon||f.weapon);
  if(h==='ryu')for(const v of g.unlocked||[])collect(h,v);
  if(h==='sandboxTrio'){collect(h,f.weapon);collect(h,f.nativeType);collect(h,f.nativeKind);if(g.loadout?.slimeOwned)collect(h,'slimySaddle');if(g.loadout?.ufoOwned)collect(h,'ufo');}
  if(h==='sonic'&&f.nativeType)collect(h,f.nativeType);
  const level=h==='megaman'?g.mixTier:h==='tank'?g.power:h==='jackal'?g.tier:g.upgradeTier;
  if(['megaman','tank','ori','jackal'].includes(h)&&level>=({tank:3,jackal:3}[h]||2))unlock('arsenal-'+h);
 }
 function apply(type,facts={}){
  // Menu unlocks arm a future run. They are not live campaign counters.
  if(type==='menu-life-code')return;
  best('bestScore',facts.score??facts.carry?.score);best('bestLives',facts.lives??facts.carry?.lives);
  if(type==='stage-clear'){
   if(!CLASSIC.includes(facts.levelId)&&facts.levelId!=='9-1')return;
   unlock('first-clear');
   const runKey=typeof facts.runId==='string'?facts.runId+':'+facts.levelId:null;
   const fresh=runKey&&!clearedRuns.has(runKey);
   if(fresh){clearedRuns.add(runKey);if(clearedRuns.size>256)clearedRuns.delete(clearedRuns.values().next().value);add('clears');}
   if(heroes.has(facts.hero)){if(!clearedHeroes.has(facts.hero)){clearedHeroes.add(facts.hero);dirty=true;}}
   if(heroes.size>=9&&[...heroes].every(h=>clearedHeroes.has(h)))unlock('mixed-company');
   const completed=new Set(facts.clearedLevels||[]);
   if(WORLD_ONE.every(id=>completed.has(id))){unlock('world-one');if(facts.mode==='random')unlock('random-world');}
   if(CLASSIC.filter(id=>id.endsWith('-4')).every(id=>completed.has(id)))unlock('all-castles');
   if(CLASSIC.every(id=>completed.has(id)))unlock('classic-complete');
   if(facts.levelId==='9-1')unlock('after-credits');
   const castle=CLASSIC.includes(facts.levelId)&&facts.levelId.endsWith('-4');
   if(castle){unlock('castle-clear');if(facts.hero==='mario')unlock('mario-thanks');}
   if(facts.hero==='tank'&&['2-2','7-2'].includes(facts.levelId))unlock('tank-water');
   if(['2-2','7-2'].includes(facts.levelId))unlock('water-clear');
   if(facts.mode==='random'&&CLASSIC.filter(id=>completed.has(id)).length>=9)unlock('random-nine');
   const row=facts.statistics?.levels?.find(r=>r.level===facts.levelId);
   if(!facts.statistics?.partial&&row&&row.frames>0&&row.deaths===0&&row.retries===0&&row.continues===0){unlock('no-fall');if(fresh)add('clean');if(castle&&facts.hero==='bill')unlock('bill-clean-castle');if(facts.hero==='sonic'&&row.frames<=3600&&CLASSIC.includes(facts.levelId))unlock('sonic-minute');}
  }else if(type==='challenge-reward'&&facts.claimed===true){unlock('secret-victory');unlock('challenge-'+facts.hero);equipment(facts);if(['bill','megaman','ryu','tank','sandboxTrio','ori','sonic','jackal'].every(h=>unlocked.has('challenge-'+h)))unlock('challenge-tour');}
  else if(type==='objective'){if(facts.id==='rescue-delivered'&&Number.isInteger(facts.value)&&facts.value>=5)unlock('rescue-five');equipment(facts);}
  else if(type==='room-enter'&&facts.roomId==='minus-one')unlock('blank-world');
  else if(type==='room-loop'&&facts.roomId==='minus-one'&&facts.targetRoom==='minus-one')add('minusLoops');
  else if(type==='extra-life'&&facts.reason==='shell-stomp')unlock('shell-life');
  else if(type==='warp-used')unlock('warp-discovery');
  else if(type==='flag-grab'&&facts.points===5000)unlock('flag-top');
  else if(type==='brick-broken'){add('bricks');if(typeof facts.attackInstanceId==='string'&&facts.entityId){const key=[facts.runId,facts.levelId,facts.stageInstanceId,facts.roomId,facts.attackInstanceId].join(':');const tiles=bursts.get(key)||new Set();tiles.add(facts.entityId);bursts.set(key,tiles);if(bursts.size>64)bursts.delete(bursts.keys().next().value);best('bestBurst',tiles.size);}}
  else if(type==='item-collected'){equipment(facts);if(facts.kind==='star')add('stars');if(facts.kind==='life')add('oneups');}
  else if(type==='coin-collected'&&facts.value===1){const n=add('coins');if(n>=100)unlock('coins-100');if(n>=1000)unlock('coins-1000');}
  else if(type==='death'&&facts.hero==='ryu'&&facts.cause?.kind==='enemy-contact'&&facts.cause.contract==='ninja-gaiden:panther'&&facts.cause.entityId)unlock('ryu-dog-ambushed');
  else if(type==='enemy-defeated'){
   if(!facts.entityId||!facts.contract||!facts.cause)return;
   const h=facts.hero,g=facts.gear||{},c=facts.cause;
   add('enemies');if(c==='shell')add('shell');if(h!=='mario'&&heroes.has(h)&&facts.origin==='mario'&&c==='stomp')add('guestStomp');
   if(h==='ryu'&&facts.contract==='ninja-gaiden:panther')unlock('ryu-dog-defeated');
   if(c==='star'){if(add('star')>=10)unlock('star-ten');return;}
   if(h==='jackal'&&facts.contract==='jackal-nes:bomber'&&c==='jackal-main-weapon')unlock('bomber-down');
   const armed=!['stomp','crush','powerup'].includes(c),qualified=h==='mario'?c==='stomp':h==='bill'?armed&&g.weapon==='S':h==='megaman'?armed&&g.mixTier>0:h==='ryu'?armed&&g.attackMode&&g.attackMode!=='blade':h==='tank'?armed&&g.power===3:h==='sandboxTrio'?armed&&(facts.power>0||!!facts.weapon&&facts.weapon!=='starfury'):h==='ori'?armed&&g.upgradeTier>0:h==='sonic'?c==='spin'||facts.rolling:h==='jackal'?c==='crush'&&/infantry|bazooka/.test(facts.contract):false;
   if(qualified&&add('combat-'+h)>=(['mario','sandboxTrio'].includes(h)?10:5))unlock('combat-'+h);
  }
 }
 const challenges=createAchievementChallenges(unlock);
 function observe(type,facts={}){apply(type,facts);challenges(type,facts);observeNostalgia(type,facts,unlock);if(MEMORY_TROPHY_IDS.every(id=>unlocked.has(id)))unlock('memory-album');if(unlocked.has('blank-world')&&unlocked.has('after-credits'))unlock('both-bonus');if(dirty){persist();dirty=false;}}
 return {observe,next:()=>pending.shift()||null,list:()=>ACHIEVEMENTS.map(a=>({...a,unlocked:unlocked.has(a.id),at:unlocked.get(a.id)||null,...(a.metric?{progress:Math.min(a.target,progress[a.metric]||0)}:{})})),count:()=>unlocked.size};
}
