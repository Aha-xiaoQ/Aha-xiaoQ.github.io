/** One fixed 60 Hz contact/movement contract for every mainline character.
 * Mario's tuning is copied unchanged from the accepted editor-mario-motor.
 * Other actors add bounded abilities before the same swept collision pass.
 */
import {CHARACTER_ADAPTERS} from '../content/character-adapters.mjs';
import {CHARACTER_PROFILES} from '../content/characters.mjs';
import {validateMainlineAccess} from '../engine/mainline-movement.mjs';
export {CHARACTER_PROFILES} from '../content/characters.mjs';

const PROFILES = new Map(CHARACTER_PROFILES.map(c => [c.id, c]));
// These are executable controllers implemented below, not the selection roster.
// Registering a new native actor must never silently give it Mario physics in
// workshop previews or tests. Explicit aliases may reuse an implemented port.
export const PORTABLE_MOTOR_IDS=Object.freeze(['mario','bill','megaman','ryu','tank','sandboxTrio','ori','sonic']);
const IMPLEMENTED_MOTORS=new Set(PORTABLE_MOTOR_IDS);
function supports(character){
  const base=character?.bindings&&character?.motion?character:PROFILES.get(character?.heroId??character?.id);
  return !!base&&IMPLEMENTED_MOTORS.has(base.bindings?.motion);
}
const approach = (v, target, amount) => v + Math.max(-amount, Math.min(amount, target - v));
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
const overlap = (a, b) => a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;

function characterProfile(character) {
  const actorId = character?.heroId ?? character?.id;
  const base = character?.bindings && character?.motion ? character : PROFILES.get(actorId);
  const id = base?.bindings?.motion;
  if (!base || !CHARACTER_ADAPTERS[id]) throw new RangeError('Unknown mainline character: ' + actorId);
  if(!IMPLEMENTED_MOTORS.has(id))throw new RangeError('Unimplemented portable motor: '+id+'; install its native actor port');
  return {id, actorId, base, motion: {...base.motion, ...character.motion}};
}

// Sweep the whole displacement, including dash/knockback velocities. Thin
// solids therefore cannot be skipped, and collision results do not depend on
// the order in which the caller supplied its tiles.
function horizontal(p, dx, solids) {
  const oldX = p.x;
  let next = oldX + dx, side = 0;
  for (const q of solids) {
    if (q.hidden || q.collision !== 'solid' || p.y + p.h <= q.y || p.y >= q.y + q.h) continue;
    if (dx > 0 && oldX + p.w <= q.x + .001 && next + p.w > q.x) {
      next = Math.min(next, q.x - p.w); side = 1;
    } else if (dx < 0 && oldX >= q.x + q.w - .001 && next < q.x + q.w) {
      next = Math.max(next, q.x + q.w); side = -1;
    }
  }
  p.x = next;
  return side;
}

function wallContact(p, solids) {
  for (const q of solids) {
    if (q.hidden || q.collision !== 'solid' || p.y + p.h <= q.y + 1 || p.y >= q.y + q.h - 1) continue;
    if (Math.abs(p.x + p.w - q.x) < .1) return 1;
    if (Math.abs(p.x - q.x - q.w) < .1) return -1;
  }
  return 0;
}

export function createCharacterMotor() {
  function create(character, spawn) {
    const {id, actorId, base, motion: m} = characterProfile(character);
    if (!Number.isFinite(spawn?.x) || !Number.isFinite(spawn?.y)) throw new TypeError('A finite character spawn is required');
    return {x: spawn.x, y: spawn.y, w: m.width, h: m.height, hero: actorId, motionId:id, attackId:base.bindings.attack, renderId:base.bindings.render,
      vx: 0, vy: 0, grounded: false, facing: 1, jumps: 0, support: null,
      airCap: m.walkSpeed, jumpG: .125, fallG: .4375, jumpBuffer: 0,
      power: 0, anim: 0, crouch: false, headHit: null, dropTicks: 0,
      maxHealth: character.maxHealth ?? base.maxHealth, hp: character.maxHealth ?? base.maxHealth,
      wallSide: 0, wallLock: 0, climbing: false, airTicks: 0,
      gliding: false, glideTicks: 0, doubleTicks: 0,
      propulsionFuel: 18, propelling: false, spinCharge: 0, spinTicks: 0, rolling: false,
      aimX: 1, aimY: 0, swimming: false, swimStroke: 0};
  }

  function step(p, input, character, world) {
    return stepBody(p,input,world,characterProfile(character));
  }

  /** Scripted finish transport uses the installed character's declared motion
   * and current body, not the closed set of playable legacy controllers. */
  function finish(p,input,character,world){
    const access=validateMainlineAccess(character),m=character.motion,actorId=character.heroId??character.id;
    if(access.travel==='drive'&&access.waterTravel!=='drive')throw new TypeError('Drive finish cannot declare swimming');
    if(!m||!actorId||![p.x,p.y,p.w,p.h,world.width].every(Number.isFinite)||p.w<=0||p.h<=0||world.width<=0||!Array.isArray(world.solids))throw new TypeError('Invalid finish body or world');
    for(const key of ['walkSpeed','runSpeed','acceleration','runAcceleration','reverseAcceleration','friction','maxFall'])
      if(!Number.isFinite(m[key])||m[key]<0)throw new TypeError('Invalid finish motion '+key);
    if(!(m.walkSpeed>0)||!(m.acceleration>0))throw new TypeError('Finish motion must advance');
    // These are transport state, not abilities or equipment. Independent ports
    // need not initialize unused platform-jump bookkeeping for ordinary play.
    const defaults={vx:0,vy:0,airCap:m.walkSpeed,jumpG:.125,fallG:.4375,wallLock:0,doubleTicks:0,
      airTicks:0,swimStroke:0,jumps:0,spinCharge:0,spinTicks:0,glideTicks:0};
    for(const [key,value]of Object.entries(defaults)){
      if(p[key]==null)p[key]=value;
      else if(!Number.isFinite(p[key]))throw new TypeError('Nonfinite finish body '+key);
    }
    p.jumpBuffer=0;p.spinCharge=0;p.spinTicks=0;
    if(access.travel==='drive')p.vy=Math.max(0,p.vy);
    // Finish transport is scene-owned. A vehicle can drive over a one-cell
    // riser after the axe without acquiring platform-jump abilities. Check the
    // complete upward and forward sweeps before changing its support height.
    const axis=Math.sign(Number(input.x)||0);
    if(access.travel==='drive'&&p.grounded&&axis&&p.wallLock<=1){
      const dx=approach(p.vx,axis*m.walkSpeed,p.vx&&Math.sign(p.vx)!==axis?m.reverseAcceleration:m.acceleration);
      const probe={...p};
      if(horizontal(probe,dx,world.solids)){
        const forward={...p,x:p.x+dx},solids=world.solids.filter(q=>!q.hidden&&q.collision==='solid');
        const blockers=solids.filter(q=>overlap(forward,q)&&!overlap(p,q));
        const rise=Math.max(0,...blockers.map(q=>p.y+p.h-q.y));
        const up={x:p.x,y:p.y-rise,w:p.w,h:p.h+rise};
        const across={x:Math.min(p.x,p.x+dx),y:p.y-rise,w:p.w+Math.abs(dx),h:p.h};
        if(rise>0&&rise<=16&& !solids.some(q=>overlap(up,q)||overlap(across,q)))p.y-=rise;
      }
    }
    const events=stepBody(p,{x:Math.sign(Number(input.x)||0)},{...world,preserveBody:true,swimming:false},
      {id:access.travel==='drive'?null:character.bindings?.motion,actorId,motion:m});
    if(access.travel==='drive'){p.jumps=0;p.jumpBuffer=0;p.propelling=false;}
    return events;
  }

  function stepBody(p, input, world, profile) {
    const {id, actorId, motion: m} = profile;
    if (p.hero !== actorId) throw new Error('Changing character requires a fresh motor body');
    let i = input, ground = p.grounded;
    const events = [], axis = Math.sign(i.x || 0);
    p.headHit = null;
    p.swimming = !!world.swimming;
    p.swimStroke = Math.max(0, (p.swimStroke || 0) - 1);
    p.wallLock = Math.max(0, (p.wallLock || 0) - 1);
    p.doubleTicks = Math.max(0, (p.doubleTicks || 0) - 1);
    p.propelling = p.climbing = p.gliding = false;
    let solids = world.solids;

    if (id === 'bill' && i.down && i.jumpPressed && ground) {
      const support = solids.find(q => q.id === p.support);
      if (support?.collision === 'oneway') {
        p.dropY = support.y; p.dropTicks = 24; p.grounded = ground = false;
        p.support = null; p.vy = .7; p.jumpBuffer = 0;
        i = {...i, jumpPressed: false, jump: false};
      }
    }
    if (p.dropTicks > 0) {
      p.dropTicks--;
      solids = solids.filter(q => !(q.collision === 'oneway' && Math.abs(q.y - p.dropY) < 1));
    }

    const carriedBy = ground ? p.support : null;
    if (carriedBy) {
      const q = solids.find(s => s.id === carriedBy);
      if (q) {
        horizontal(p, q.dx || 0, solids);
        const dy = q.dy || 0, oldY = p.y;
        p.y += dy;
        if (dy < 0) for (const ceiling of solids) {
          if (ceiling.id !== q.id && !ceiling.hidden && ceiling.collision === 'solid' &&
              p.x + p.w > ceiling.x && p.x < ceiling.x + ceiling.w &&
              oldY >= ceiling.y + ceiling.h && p.y < ceiling.y + ceiling.h) {
            p.y = Math.max(p.y, ceiling.y + ceiling.h);
            p.headHit = ceiling.id;
          }
        }
      }
    }

    // Forced finish motion transports the current actor composition (rider,
    // mount, transformed body). Its native owner still owns the body shape.
    const normalHeight = world.preserveBody ? p.h : id === 'mario' ? (p.power ? 28 : m.height) : m.height;
    const canCrouch = !world.preserveBody && normalHeight > 16 && (id === 'mario' || id === 'bill' || id === 'ryu');
    // SMB $B329-$B33B updates big Mario's crouch flag only on the ground.
    // A crouched takeoff remains crouched even after Down is released; a
    // standing jump cannot acquire a new crouch halfway through its arc.
    const crouch = canCrouch && (id === 'mario' && !ground ? p.crouch : !!i.down && ground);
    const targetHeight = crouch ? 16 : normalHeight;
    if (targetHeight !== p.h) {
      const body = {...p, y: p.y + p.h - targetHeight, h: targetHeight};
      if (targetHeight < p.h || !solids.some(q => !q.hidden && q.collision === 'solid' && overlap(body, q))) {
        p.y = body.y; p.h = targetHeight; p.crouch = crouch;
      }
    } else p.crouch = crouch;
    // Releasing Down beneath a ceiling keeps both the short body and its pose.
    if (canCrouch && p.h < normalHeight) p.crouch = true;

    if (i.jumpPressed) p.jumpBuffer = 3;
    else if (p.jumpBuffer) p.jumpBuffer--;
    const wall = !ground && id === 'ryu' ? wallContact(p, solids) : 0;
    const charging = id === 'sonic' && ground && !!i.ability;
    if (charging) {
      p.spinCharge = Math.min(60, p.spinCharge + 1);
      p.vx = approach(p.vx, 0, .2); p.rolling = true;
    } else if (id === 'sonic' && p.spinCharge) {
      if (ground) {
        p.vx = p.facing * Math.min(4.8, 3.2 + p.spinCharge / 30);
        p.spinTicks = 40; events.push('dash');
      }
      p.spinCharge = 0;
    }

    const cap = ground ? (i.run ? m.runSpeed : m.walkSpeed) : p.airCap;
    const acc = i.run || (!ground && p.airCap > m.walkSpeed) ? m.runAcceleration : m.acceleration;
    if (!charging && !p.wallLock) {
      if (axis && (!p.crouch || id === 'mario' && !ground)) {
        const acceleratingDash = id === 'sonic' && p.spinTicks && Math.sign(p.vx) === axis && Math.abs(p.vx) > cap;
        p.vx = approach(p.vx, axis * cap, acceleratingDash ? .017 : p.vx && Math.sign(p.vx) !== axis ? m.reverseAcceleration : acc);
        // NES LRAir steers momentum without changing the takeoff facing.
        if (id !== 'mario' || ground || p.swimming) p.facing = axis;
      } else if (ground) p.vx = approach(p.vx, 0, id === 'sonic' && p.spinTicks ? .025 : m.friction);
    }
    if (id === 'bill') {
      if (axis) p.facing = axis;
      p.aimY = i.down && (!ground || axis) ? 1 : i.up && !i.down ? -1 : 0;
      p.aimX = p.aimY ? axis : p.facing;
    }

    if (p.swimming && i.jumpPressed) {
      p.swimStroke = 24; p.vy = -2.5; p.jumpBuffer = 0; p.grounded = false;
      events.push('jump');
    } else if (!p.swimming && p.jumpBuffer && ground && !charging) {
      const speed = Math.abs(p.vx);
      p.vy = (speed > 2.25 ? -m.runningJumpSpeed : -m.jumpSpeed) * (id === 'ryu' && p.weapon === 'spin' ? 1.12 : 1);
      if (p.mainlineMotion) p.vy = -p.mainlineMotion.jumpSpeed;
      p.jumpG = p.mainlineMotion?.riseGravity ?? (speed > 2.25 ? .15625 : speed > 1 ? .1171875 : .125);
      p.fallG = p.mainlineMotion?.fallGravity ?? (speed > 2.25 ? .5625 : speed > 1 ? .375 : .4375);
      p.airCap = speed > 1.5 ? m.runSpeed : m.walkSpeed;
      p.jumpBuffer = 0; p.grounded = false; p.jumps = 1;
      events.push('jump');
    } else if (!p.swimming && i.jumpPressed && wall && !p.wallLock) {
      p.vx = -wall * 2.65; p.vy = -5.1666667; p.facing = -wall;
      p.airCap = m.runSpeed; p.jumpG = .15625; p.fallG = .4375;
      p.wallLock = 9; p.wallSide = 0; p.jumpBuffer = 0; p.jumps = 1;
      events.push('jump');
    } else if (!p.swimming && !ground && i.jumpPressed &&
               (id === 'ori' || id === 'sandboxTrio') && p.jumps < 2) {
      p.vy = -4.6; p.jumpG = .125; p.fallG = .375;
      p.jumps = 2; p.doubleTicks = 14; p.jumpBuffer = 0;
      events.push('jump');
    }

    p.vy = p.swimming ? Math.min(1.5, p.vy + .075) :
      Math.min(m.maxFall, p.vy + (p.vy < 0 && i.jump ? p.jumpG : p.fallG));
    if (!p.swimming && id === 'ryu' && wall && !p.wallLock && axis === wall) {
      p.climbing = !!i.up;
      p.vy = i.up ? -1.35 : Math.min(p.vy, i.down ? 2 : .8);
      p.wallSide = wall;
    }
    if (!p.swimming && id === 'tank' && !ground && i.ability && p.propulsionFuel > 0) {
      p.propulsionFuel--; p.propelling = true; p.vy = Math.min(p.vy, -2.2);
    }
    if (!p.swimming && id === 'ori' && !ground && i.ability && p.vy > 0) {
      p.gliding = true; p.vy = Math.min(p.vy, .8);
    }
    p.glideTicks = p.gliding ? p.glideTicks + 1 : 0;
    if (p.swimming) {
      p.vx = clamp(p.vx, -1.5, 1.5);
    }

    const side = horizontal(p, p.vx, solids);
    if (side) { p.vx = 0; p.wallSide = side; p.spinTicks = 0; }
    else if (!wall) p.wallSide = 0;
    p.x = clamp(p.x, 0, Math.max(0, world.width - p.w));
    const bottom = p.y + p.h, top = p.y, vy = p.vy;
    p.y += vy; p.grounded = false; p.support = null;
    let landing = null;
    const heads = [];
    for (const q of solids) {
      if (p.x + p.w <= q.x || p.x >= q.x + q.w) continue;
      if (!q.hidden && vy >= 0 && bottom <= q.y - (carriedBy === q.id ? 0 : q.dy || 0) + 1.01 && p.y + p.h >= q.y) {
        if (!landing || q.y < landing.y) landing = q;
      }
      if (q.collision === 'solid' && vy < 0 && top >= q.y + q.h - 1 && p.y < q.y + q.h) heads.push(q);
    }
    if (landing) {
      p.y = landing.y - p.h; p.vy = 0; p.grounded = true; p.support = landing.id;
      p.airCap = i.run ? m.runSpeed : m.walkSpeed;
    }
    if (heads.length) {
      heads.sort((a, b) => (b.y + b.h) - (a.y + a.h) ||
        Math.abs(a.x + a.w / 2 - p.x - p.w / 2) - Math.abs(b.x + b.w / 2 - p.x - p.w / 2));
      const q = heads[0];
      p.y = q.y + q.h; p.vy = .5; p.headHit = q.id;
    }
    // Apply the water surface after the displacement, including a fresh stroke.
    if (p.swimming && p.y < 16) { p.y = 16; p.vy = Math.max(0, p.vy); }
    // The workshop's held-run one-tile gap rule is retained for all actors.
    if (!p.swimming && !p.grounded && ground && vy >= 0 && i.run && axis && Math.sign(p.vx) === axis) {
      const row = solids.filter(q => !q.hidden && Math.abs(q.y - bottom) < .01).sort((a, b) => a.x - b.x);
      for (let n = 1; n < row.length; n++) {
        const a = row[n - 1], b = row[n], gap = b.x - a.x - a.w;
        if (gap > 0 && gap <= 16 && p.x + p.w > a.x + a.w && p.x < b.x) {
          p.y = bottom - p.h; p.vy = 0; p.grounded = true; break;
        }
      }
    }
    if (p.grounded) {
      p.jumps = 0; p.airTicks = 0; p.propulsionFuel = 18; p.wallSide = 0;
    } else {
      p.airTicks++;
      if (ground && p.jumps === 0) p.jumps = 1;
    }
    if (id === 'sonic') {
      p.spinTicks = Math.max(0, p.spinTicks - 1);
      p.rolling = !!(p.spinCharge || p.spinTicks || (!p.grounded && !p.swimming) || i.down && Math.abs(p.vx) > .3);
    }
    p.anim = (p.anim || 0) + Math.abs(p.vx);
    return events;
  }
  return Object.freeze({create, step, finish, supports, overlap});
}
