import {CHARACTER_PROFILES} from '../content/characters.mjs';
import {CAMPAIGN_WORLDS} from '../content/campaign-worlds.mjs';
import {EXTENDED_WORLDS} from '../content/extended-worlds.mjs';
import {CUSTOM_WORLDS} from '../content/custom-worlds.mjs';
import {BONUS_WORLDS} from '../content/bonus-worlds.mjs';
import {WORLD_BRANCHES} from '../content/world-branches.mjs';
import {installWorldBranches} from './branches.mjs';
import {freezeData} from '../engine/catalog.mjs';
import {CHARACTER_ADAPTERS,createCharacterAdapters} from '../content/character-adapters.mjs';
import {validateMainlineAccess} from '../engine/mainline-movement.mjs';

const id=value=>typeof value==='string'&&/^[A-Za-z0-9][A-Za-z0-9._:-]{0,79}$/.test(value);
const require=(ok,message)=>{if(!ok)throw new TypeError('Campaign content: '+message);};
const positive=value=>Number.isFinite(value)&&value>0;
function index(rows,label,key='id'){
  require(Array.isArray(rows)&&rows.length>0,label+' must be nonempty');
  const map=new Map();
  for(const row of rows){require(row&&id(row[key]),label+' has invalid '+key);require(!map.has(row[key]),label+' duplicates '+row[key]);map.set(row[key],row);}
  return map;
}
const OBJECT_KINDS=new Set(['spawn','exit','checkpoint','portal','coin','walker','hazard']);
function box(value,label){require(['x','y','w','h'].every(k=>Number.isFinite(value[k]))&&positive(value.w)&&positive(value.h),label+' has invalid bounds');}

/** Validate before creating mutable scene instances. No implicit missing-room,
 * missing-character or unsupported-object fallback is allowed. */
export function createCampaignCatalog({characters,worlds,bonusWorlds=[],branches=[],adapters=CHARACTER_ADAPTERS}){
  require(adapters&&typeof adapters==='object'&&!Array.isArray(adapters),'invalid adapter registry');
  adapters=createCharacterAdapters(Object.values(adapters));
  const actors=index(structuredClone(characters),'characters'),levels=index(structuredClone([...worlds,...bonusWorlds]),'worlds','level');
  const mainIds=worlds.map(w=>w.level),bonusIds=bonusWorlds.map(w=>w.level),after=new Map();
  require(Array.isArray(branches),'branches must be an array');
  for(const b of branches)require(levels.has(b.level),'branch parent is not registered');
  for(const w of levels.values())installWorldBranches(w,branches,[...levels.keys()]);
  for(const b of bonusWorlds){
    require(b.progression?.kind==='post-credits'&&mainIds.includes(b.progression.after),b.level+' needs a registered mainline predecessor');
    require(!after.has(b.progression.after),b.level+' duplicates a post-credits destination');
    after.set(b.progression.after,b.level);
  }
  for(const actor of actors.values()){
    validateMainlineAccess(actor);
    require(actor.heroId===actor.id,actor.id+' heroId must equal its registered id');
    for(const port of ['motion','attack','render','portrait'])require(Object.hasOwn(adapters,actor.bindings?.[port])&&adapters[actor.bindings[port]]?.[port]===actor.bindings?.[port],actor.id+' has unregistered '+port+' adapter');
    require(new Set(Object.values(actor.bindings)).size===1,actor.id+' mixed adapter ports are not implemented');
    // These declarations select movement, body clearance and the initial
    // passage tool. Reusing a port cannot claim capabilities it does not own.
    const installedAccess=adapters[actor.bindings.motion].access;
    require(positive(actor.bossDamageUnit)&&actor.bossDamageUnit===adapters[actor.bindings.motion].bossDamageUnit,actor.id+' boss damage disagrees with its installed adapter');
    for(const field of ['travel','waterTravel','passage','startingTool','crouchHeight','collisionWidth','nativeWidth'])
      require(actor.access[field]===installedAccess[field],actor.id+' '+field+' disagrees with its installed motion adapter');
    require(actor.selection?.name&&actor.selection?.origin,actor.id+' needs selection metadata');
    require(typeof actor.title==='string'&&actor.title.length>0&&typeof actor.help==='string',actor.id+' needs title and controls');
    require(positive(actor.width)&&positive(actor.height)&&Number.isInteger(actor.maxHealth)&&actor.maxHealth>0,actor.id+' has invalid body or health');
    require(actor.motion?.width===actor.width&&actor.motion?.height===actor.height,actor.id+' body and motion sizes disagree');
    for(const field of ['walkSpeed','runSpeed','acceleration','runAcceleration','friction','jumpSpeed','runningJumpSpeed','maxFall'])require(positive(actor.motion[field]),actor.id+' has invalid '+field);
    const travelAbility=actor.access.travel==='drive'?'drive':'jump';
    require(Array.isArray(actor.abilities)&&actor.abilities.includes(travelAbility)&&actor.abilities.every(id)&&new Set(actor.abilities).size===actor.abilities.length,actor.id+' needs unique implemented ability ids for '+travelAbility);
    require(actor.access.travel!=='drive'||!actor.abilities.includes('jump'),actor.id+' drive adapter cannot claim jump');
    freezeData(actor);
  }
  for(const world of levels.values()){
    const {stage,rooms}=world.plan||{};require(stage&&rooms&&typeof rooms==='object',world.level+' needs a stage and rooms');
    const maps=index(Object.entries(rooms).map(([key,room])=>({...room,id:key})),world.level+' rooms');
    const spawn=(roomId,spawnId)=>maps.get(roomId)?.objects.find(o=>o.kind==='spawn'&&o.id===spawnId);
    for(const room of maps.values()){
      require(positive(room.width)&&positive(room.height),world.level+'/'+room.id+' has invalid size');
      index(room.objects,world.level+'/'+room.id+' objects');
      require(Array.isArray(room.geometry),room.id+' has no geometry');
      const geometryIds=new Set();
      for(const g of room.geometry){
        require(g&&id(g.id),room.id+' geometry has invalid id');
        require(!geometryIds.has(g.id),room.id+' geometry duplicates '+g.id);geometryIds.add(g.id);
        box(g,room.id+'/'+g.id);require(['solid','oneway','none'].includes(g.collision),g.id+' has unknown collision kind');
      }
      for(const o of room.objects){
        box(o,room.id+'/'+o.id);require(OBJECT_KINDS.has(o.kind),o.id+' has unsupported object kind '+o.kind);
        if(o.kind==='exit'){
          require(o.x>=0&&o.x+o.w<=room.width&&o.y>=0&&o.y+o.h<=room.height,o.id+' finish is outside its room');
          if(o.finish){require(['flag','castle'].includes(o.finish.kind),o.id+' has an unknown finish presentation');if(o.finish.walkTarget!==undefined)require(Number.isFinite(o.finish.walkTarget)&&o.finish.walkTarget>=0&&o.finish.walkTarget<=room.width,o.id+' walkTarget is outside its room');}
        }
        if(o.kind==='portal'&&!o.targetWorld)require(spawn(o.targetRoom,o.targetSpawn),o.id+' has a broken portal destination');
        if(o.kind==='checkpoint')require(spawn(room.id,o.targetSpawn),o.id+' has a broken checkpoint');
      }
    }
    require(spawn(stage.entryRoom,stage.entrySpawn),world.level+' has a broken entry spawn');
    require([...maps.values()].some(r=>r.objects.some(o=>o.kind==='exit')),world.level+' has no finish');
    const visuals=index(world.visualRooms,world.level+' visuals','roomId');
    for(const roomId of maps.keys())require(visuals.has(roomId),world.level+' lacks visuals for '+roomId);
    for(const visual of visuals.values())if(visual.underwater!==undefined)require(typeof visual.underwater==='boolean',world.level+' invalid room water flag');
    if(world.appearance!==undefined){
      require(world.appearance&&typeof world.appearance==='object'&&!Array.isArray(world.appearance),world.level+' invalid room appearance');
      for(const [roomId,appearance]of Object.entries(world.appearance)){
        require(maps.has(roomId)&&appearance&&typeof appearance==='object'&&!Array.isArray(appearance),world.level+' invalid appearance room');
        require(Object.keys(appearance).every(k=>['palette','background','scenery'].includes(k)),world.level+' unknown appearance field');
        require(appearance.palette===undefined||appearance.palette==='world-nine',world.level+' unknown appearance palette');
        require(appearance.background===undefined||/^#[0-9a-f]{6}$/i.test(appearance.background),world.level+' invalid room background');
        require(appearance.scenery===undefined||appearance.scenery==='overworld',world.level+' invalid scenery policy');
      }
    }
    freezeData(world);
  }
  const get=(map,key,label)=>{require(map.has(key),'Unknown '+label+' '+key);return map.get(key);};
  return Object.freeze({
    characters:()=>Object.freeze([...actors.values()]),worlds:()=>Object.freeze(mainIds.map(id=>levels.get(id))),
    heroIds:()=>Object.freeze([...actors.keys()]),levelIds:()=>Object.freeze([...mainIds]),
    allLevelIds:()=>Object.freeze([...levels.keys()]),bonusIds:()=>Object.freeze([...bonusIds]),
    bonusAfter:id=>after.get(id)||null,
    character:key=>get(actors,key,'character'),world:key=>get(levels,key,'level'),
    matrix:({includeBonus=false}={})=>(includeBonus?[...levels.keys()]:mainIds).flatMap(levelId=>[...actors.keys()].map(characterId=>({levelId,characterId}))),
  });
}
export const campaignCatalog=createCampaignCatalog({characters:CHARACTER_PROFILES,worlds:[...CAMPAIGN_WORLDS,...EXTENDED_WORLDS,...CUSTOM_WORLDS],bonusWorlds:BONUS_WORLDS,branches:WORLD_BRANCHES});
