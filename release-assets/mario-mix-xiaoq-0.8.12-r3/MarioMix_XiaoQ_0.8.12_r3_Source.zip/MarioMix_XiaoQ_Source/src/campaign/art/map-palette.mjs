import {classicSprite,spritePixels} from './classic-art.mjs';
// Room-scoped NES palette adaptation. Never recolor the HUD, the selected
// character or another game's objects. Original source pixels stay immutable.
const cache=new Map();
export function mapPixel(name,rgba,palette){
  if(palette!=='world-nine'||rgba[3]===0)return rgba;
  const [r,g,b,a]=rgba,key=[r,g,b].join(','),set=table=>table[key]?[...table[key],a]:rgba;
  if(/Pipe/.test(name))return set({'0,0,0':[120,0,132],'128,208,16':[248,88,152],'0,168,0':[60,40,252]});
  if(/hill/.test(name))return set({'0,0,0':[248,88,152],'0,168,0':[60,40,252]});
  if(/bush/.test(name))return set({'128,208,16':[216,40,168],'0,168,0':[248,120,248]});
  if(/cloud/.test(name))return set({'60,188,252':[104,40,200]});
  if(/FlagPole|FlagTop/.test(name))return set({'0,168,0':[160,0,200],'128,208,16':[248,120,248],'255,255,255':[216,40,168]});
  if(/Piranha/.test(name))return set({'216,40,0':[216,168,0],'200,76,12':[216,168,0],'0,168,0':[216,168,0]});
  if(/\|Block\|/.test(name)&&!name.includes('used'))return set({'200,76,12':[60,40,252],'252,152,56':[248,88,152],'0,0,0':[104,136,252]});
  if(/\|Solid\||\|Scenery\||^brick/.test(name))return set({'200,76,12':[0,168,0],'252,216,168':[184,248,184],'252,152,56':[128,208,16],'0,0,0':[0,64,0]});
  return rgba;
}
export function mapSprite(name,room={}){
  const palette=room.presentation?.palette;if(!palette)return classicSprite(name);
  if(palette!=='world-nine')throw new TypeError('Unknown map palette '+palette);
  const key=palette+':'+name;if(cache.has(key))return cache.get(key);
  const source=spritePixels(name),canvas=document.createElement('canvas');canvas.width=source.w;canvas.height=source.h;
  const ctx=canvas.getContext('2d'),image=ctx.createImageData(source.w,source.h);
  source.pixels.forEach((rgba,i)=>image.data.set(mapPixel(name,rgba,palette),i*4));
  ctx.putImageData(image,0,0);cache.set(key,canvas);return canvas;
}
export function mapDraw(ctx,name,x,y,room,flip=false){const im=mapSprite(name,room);ctx.save();ctx.translate(Math.round(x)+(flip?im.width:0),Math.round(y));ctx.scale(flip?-1:1,1);ctx.drawImage(im,0,0);ctx.restore();}
