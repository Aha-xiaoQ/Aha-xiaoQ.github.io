import {createRunStatistics,copyRunStatistics,recordRunStatistic} from './run-statistics.mjs';
import {campaignCatalog} from './catalog.mjs';
import {copySceneCheckpoint} from '../engine/scene-state.mjs';
import {copyRewardReceipt} from '../engine/reward-receipt.mjs';
import {copyRespawnEquipment} from '../engine/actor-contract.mjs';
export const CAMPAIGN_HEROES = Object.freeze([...campaignCatalog.heroIds()]);
export const CAMPAIGN_LEVELS = Object.freeze([...campaignCatalog.levelIds()]);

const SCHEMA = 'mariomix.campaign';
const VERSION = 4;
const MAX_SAVE_LENGTH = 786432;
const MAX_LEVELS = 64;
const MAX_RUN_SEQUENCE = 0xffffffff;
// Version 1 shipped exactly this order. Never derive its migration from new content.
const V1_LEVEL_ORDER = Object.freeze(['1-1', '1-2', '1-3', '1-4']);
// Version 3 did not persist its pool. This is historical migration data, never
// the current installation roster. Custom v3 catalogs must declare their pool.
const V3_CHARACTER_ROSTER = Object.freeze(['mario','bill','megaman','ryu','tank','sandboxTrio','ori','sonic']);
const CLASSIC_LEVEL_ORDER = Object.freeze(Array.from({length:32},(_,i)=>`${Math.floor(i/4)+1}-${i%4+1}`));
const V1_STATE_KEYS = ['schema', 'version', 'runId', 'mode', 'status', 'levelIndex', 'levelId', 'characterId', 'plannedCharacters', 'clearedLevels', 'secretIds', 'carry'];
const V2_STATE_KEYS = [...V1_STATE_KEYS, 'levelOrder', 'contentId', 'statistics'];
const V3_STATE_KEYS = [...V2_STATE_KEYS, 'heroCarry', 'skippedLevels', 'entryMode'];
const STATE_KEYS = [...V3_STATE_KEYS, 'characterRoster'];
const CARRY_KEYS = ['lives', 'coins', 'score', 'hero', 'power', 'weapon'];
const CARRY_UPDATE_KEYS = [...CARRY_KEYS, 'native', 'respawnNative', 'protection', 'checkpoint', 'challenge'];
const STATUSES = ['idle', 'playing', 'between', 'complete', 'gameover'];
const IDENTIFIER = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,63}$/;
const CONTENT_IDENTIFIER = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/;
const CATALOG_IDENTIFIER = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,79}$/;
const SECRET_ROUTE_KEYS = ['sourceRoom','portalId','targetRoom','targetSpawn','returnRoom','returnSpawn'];
const EQUIPMENT_KEYS = ['hero','power','weapon','protection','native'];

function fail(message) { throw new TypeError(`Invalid campaign: ${message}`); }

function record(value, keys, name, partial = false) {
  if (!value || typeof value !== 'object' || ![Object.prototype, null].includes(Object.getPrototypeOf(value))) fail(`${name} must be a plain object`);
  const own = Reflect.ownKeys(value);
  if (own.some(key => !keys.includes(key)) || (!partial && own.length !== keys.length)) fail(`${name} has missing or unknown fields`);
  for (const key of own) {
    const descriptor = Object.getOwnPropertyDescriptor(value, key);
    if (!Object.hasOwn(descriptor, 'value') || !descriptor.enumerable) fail(`${name}.${key} must be enumerable data`);
  }
  return value;
}

function list(value, length, name) {
  if (!Array.isArray(value) || Object.getPrototypeOf(value) !== Array.prototype || value.length !== length || Reflect.ownKeys(value).length !== length + 1) fail(`${name} has invalid length or fields`);
  for (let i = 0; i < length; i++) {
    const descriptor = Object.getOwnPropertyDescriptor(value, String(i));
    if (!descriptor || !Object.hasOwn(descriptor, 'value') || !descriptor.enumerable) fail(`${name} must be a dense data array`);
  }
  return value;
}

function integer(value, min, max, name) {
  if (!Number.isSafeInteger(value) || value < min || value > max) fail(`${name} is out of range`);
  return value;
}

function hero(value, heroIds) {
  if (!heroIds.includes(value)) fail('unknown or unavailable character' + (typeof value === 'string' ? ': ' + value : ''));
  return value;
}

// A stable order label, not an asset hash or a claim of gameplay compatibility.
function orderContentId(levelIds) {
  let hash = 2166136261;
  for (const code of JSON.stringify(levelIds)) hash = Math.imul(hash ^ code.charCodeAt(0), 16777619) >>> 0;
  return 'campaign-order-v1-' + hash.toString(16).padStart(8, '0');
}

function registeredContent(catalog) {
  if (typeof catalog?.heroIds !== 'function' || typeof catalog?.levelIds !== 'function') fail('catalog needs heroIds() and levelIds()');
  const readIds = (value, name, max) => {
    if (!Array.isArray(value) || !value.length || value.length > max) fail(name + ' must be a bounded nonempty list');
    list(value, value.length, name);
    if (value.some(id => typeof id !== 'string' || !CATALOG_IDENTIFIER.test(id)) || new Set(value).size !== value.length) fail(name + ' must contain unique identifiers');
    return Object.freeze([...value]);
  };
  const heroIds = readIds(catalog.heroIds(), 'catalog heroes', 128);
  const levelIds = readIds(catalog.levelIds(), 'catalog levels', MAX_LEVELS);
  const allLevelIds=typeof catalog.allLevelIds==='function'?readIds(catalog.allLevelIds(),'all catalog levels',MAX_LEVELS):levelIds;
  if(levelIds.some(id=>!allLevelIds.includes(id)))fail('mainline levels missing from catalog');
  const legacyDescriptor=Object.getOwnPropertyDescriptor(catalog,'legacyV3CharacterRoster');
  if(legacyDescriptor&&!Object.hasOwn(legacyDescriptor,'value'))fail('legacy v3 roster must be data');
  const legacyV3CharacterRoster=readIds(legacyDescriptor?legacyDescriptor.value:V3_CHARACTER_ROSTER,'legacy v3 roster',128);
  const contentId = catalog.contentId ?? orderContentId(levelIds);
  if (typeof contentId !== 'string' || !CONTENT_IDENTIFIER.test(contentId)) fail('catalog contentId must be a bounded identifier');
  return {heroIds, levelIds, allLevelIds, contentId, legacyV3CharacterRoster};
}

function checkedCarry(value, characterId) {
  record(value, [...CARRY_KEYS,...['native','respawnNative','protection','checkpoint','challenge'].filter(key=>Object.hasOwn(value,key))], 'carry');
  integer(value.lives, 0, 99, 'lives');
  integer(value.coins, 0, 999999999, 'coins');
  integer(value.score, 0, 9999999999, 'score');
  integer(value.power, 0, 3, 'power');
  if(Object.hasOwn(value,'protection'))integer(value.protection,0,1,'protection');
  if (value.hero !== characterId) fail('carry hero does not match character');
  if (value.weapon !== null && (typeof value.weapon !== 'string' || !IDENTIFIER.test(value.weapon))) fail('weapon must be a bounded identifier or null');
  const result={...value};
  if(Object.hasOwn(value,'respawnNative'))result.respawnNative=copyRespawnEquipment(characterId,value.respawnNative);
  if(value.challenge!=null){
    record(value.challenge,['id','driver','phase',...['scene','route','rewardReceipt'].filter(key=>Object.hasOwn(value.challenge,key))],'challenge');
    secretId(value.challenge.id);
    if(value.challenge.driver!==characterId||!['playing','retry'].includes(value.challenge.phase))fail('invalid challenge identity or phase');
    result.challenge={...value.challenge};
    if(value.challenge.rewardReceipt!=null)result.challenge.rewardReceipt=copyRewardReceipt(characterId,value.challenge.rewardReceipt);
    if(value.challenge.route!=null){
      record(value.challenge.route,SECRET_ROUTE_KEYS,'challenge route');
      for(const key of SECRET_ROUTE_KEYS)if(typeof value.challenge.route[key]!=='string'||!CATALOG_IDENTIFIER.test(value.challenge.route[key]))fail('invalid challenge route '+key);
      result.challenge.route={...value.challenge.route};
    }
    if(value.challenge.scene!=null)result.challenge.scene=copySceneCheckpoint(characterId,value.challenge.scene);
  }
  if(value.checkpoint!=null){
    record(value.checkpoint,['levelId','roomId','spawnId'],'checkpoint');
    for(const field of ['levelId','roomId','spawnId'])if(typeof value.checkpoint[field]!=='string'||!IDENTIFIER.test(value.checkpoint[field]))fail('invalid checkpoint '+field);
    result.checkpoint={...value.checkpoint};
  }
  if(value.native!=null){
    let nodes=0;
    const visit=(v,depth=0)=>{
      if(++nodes>500||depth>6)fail('native carry exceeds bounds');
      if(v===null||typeof v==='boolean')return v;
      if(typeof v==='number'){if(!Number.isFinite(v)||Math.abs(v)>1e10)fail('invalid native number');return v;}
      if(typeof v==='string'){if(v.length>128)fail('native text exceeds bounds');return v;}
      if(Array.isArray(v)){list(v,v.length,'native list');return v.map(x=>visit(x,depth+1));}
      if(!v||typeof v!=='object')fail('native carry must be data');
      const keys=Object.keys(v);record(v,keys,'native carry');
      if(keys.some(k=>['__proto__','constructor','prototype'].includes(k)))fail('unsafe native field');
      return Object.fromEntries(keys.map(k=>[k,visit(v[k],depth+1)]));
    };
    result.native=visit(value.native);
    if((result.native.actor??result.native.hero)!==characterId)fail('native carry hero mismatch');
    if(JSON.stringify(result.native).length>4096)fail('native carry too large');
  }
  return result;
}

function secretId(value) {
  if (typeof value !== 'string' || !IDENTIFIER.test(value)) fail('secret ID must be a bounded identifier');
  return value;
}

function initialState() {
  return {
    schema: SCHEMA, version: VERSION, runId: null, mode: null, entryMode:'story', status: 'idle',
    levelIndex: -1, levelId: null, levelOrder: [], contentId: null, characterId: null, characterRoster: [], plannedCharacters: [], clearedLevels: [], skippedLevels: [], secretIds: [],
    carry: {lives: 0, coins: 0, score: 0, hero: null, power: 0, weapon: null},heroCarry:{},
  };
}

function copy(value) {
  return {...value, levelOrder: [...value.levelOrder], characterRoster: [...value.characterRoster], plannedCharacters: [...value.plannedCharacters], clearedLevels: [...value.clearedLevels], skippedLevels: [...value.skippedLevels], secretIds: [...value.secretIds], carry: JSON.parse(JSON.stringify(value.carry)),heroCarry:JSON.parse(JSON.stringify(value.heroCarry)),...(value.statistics?{statistics:copyRunStatistics(value.statistics,value.levelOrder)}:{})};
}

function frozenCopy(value) {
  const result = copy(value);
  Object.freeze(result.levelOrder);
  Object.freeze(result.characterRoster);
  Object.freeze(result.plannedCharacters);
  Object.freeze(result.clearedLevels);
  Object.freeze(result.skippedLevels);
  Object.freeze(result.secretIds);
  Object.freeze(result.carry);
  const freezeData=v=>{if(v&&typeof v==='object'){Object.values(v).forEach(freezeData);Object.freeze(v);}};
  freezeData(result.statistics);
  freezeData(result.carry.native);
  freezeData(result.carry.respawnNative);
  freezeData(result.carry.checkpoint);
  freezeData(result.carry.challenge);
  freezeData(result.heroCarry);
  return Object.freeze(result);
}

function equipment(carry){return Object.fromEntries(EQUIPMENT_KEYS.filter(key=>Object.hasOwn(carry,key)).map(key=>[key,carry[key]]));}
function checkedHeroCarry(value,heroIds){
  record(value,heroIds,'hero equipment',true);
  return Object.fromEntries(Object.entries(value).map(([id,owned])=>{
    record(owned,EQUIPMENT_KEYS,'owned equipment',true);
    const result=checkedCarry({lives:1,coins:0,score:0,...owned},id);
    return [id,equipment(result)];
  }));
}
function checkRandomPlan(planned,heroIds,legacy=false){
  const bagSize=legacy?planned.length:heroIds.length;
  for(let i=0;i<planned.length;i+=bagSize){const bag=planned.slice(i,i+bagSize);if(new Set(bag).size!==bag.length)fail('random campaign repeats a character in one bag');}
  if(heroIds.length>1&&planned.some((id,i)=>i>0&&id===planned[i-1]))fail('random campaign repeats adjacent characters');
}
// Extend an existing partial bag without changing any already planned actor.
function randomPlan(length,heroIds,sample,prefix=[]){
  const planned=[...prefix];
  while(planned.length<length){
    const start=planned.length-planned.length%heroIds.length,used=planned.slice(start);
    const pool=heroIds.filter(id=>!used.includes(id));
    while(pool.length&&planned.length<length){
      const choices=!used.length&&planned.length%heroIds.length===0&&heroIds.length>1?pool.filter(id=>id!==planned.at(-1)):pool;
      const next=choices[Math.floor(sample()*choices.length)];
      planned.push(next);pool.splice(pool.indexOf(next),1);
    }
  }
  return planned;
}
function migrationRandom(runId){
  let seed=2166136261;for(const c of runId)seed=Math.imul(seed^c.charCodeAt(0),16777619)>>>0;
  return ()=>((seed=(Math.imul(seed,1664525)+1013904223)>>>0)/0x100000000);
}

function validate(input, {heroIds, levelIds,allLevelIds=levelIds,contentId,legacyV3CharacterRoster}) {
  let value = input;
  if (typeof value === 'string') {
    if (value.length > MAX_SAVE_LENGTH) fail('save is too large');
    try { value = JSON.parse(value); } catch { fail('save is not valid JSON'); }
  }
  // Check descriptors before reading the version, including during v1 migration.
  record(value, STATE_KEYS, 'save', true);
  if (value.schema !== SCHEMA || ![1,2,3,VERSION].includes(value.version)) fail('unsupported schema or version');
  const originalVersion=value.version;
  record(value, value.version === 1 ? V1_STATE_KEYS : (value.version===2?V2_STATE_KEYS:value.version===3?V3_STATE_KEYS:STATE_KEYS).filter(k=>!['statistics','skippedLevels','entryMode'].includes(k)||Object.hasOwn(value,k)), 'save');
  if (value.version === 1) value = {...value,
    levelOrder: value.status === 'idle' ? [] : [...V1_LEVEL_ORDER],
    contentId: value.status === 'idle' ? null : orderContentId(V1_LEVEL_ORDER)};
  value={...value,version:VERSION,entryMode:Object.hasOwn(value,'entryMode')?value.entryMode:'story',heroCarry:originalVersion<3?{}:checkedHeroCarry(value.heroCarry,heroIds),skippedLevels:Object.hasOwn(value,'skippedLevels')?value.skippedLevels:[]};
  if(originalVersion<4)value.characterRoster=value.status==='idle'?[]:value.mode==='fixed'?[value.characterId]:[...(originalVersion===3?legacyV3CharacterRoster:heroIds)];
  if(!['story','stage-select'].includes(value.entryMode))fail('unknown entry mode');
  if (!STATUSES.includes(value.status)) fail('unknown status');
  const carry = checkedCarry(value.carry, value.characterId);
  if (!Array.isArray(value.secretIds) || value.secretIds.length > 64) fail('secretIds must contain at most 64 IDs');
  const secrets = list(value.secretIds, value.secretIds.length, 'secretIds');
  secrets.forEach(secretId);
  if (new Set(secrets).size !== secrets.length) fail('secretIds must not repeat');
  if (value.status === 'idle') {
    const empty = initialState();
    list(value.levelOrder, 0, 'levelOrder');
    list(value.characterRoster, 0, 'characterRoster');
    list(value.plannedCharacters, 0, 'plannedCharacters');
    list(value.clearedLevels, 0, 'clearedLevels');
    list(value.skippedLevels, 0, 'skippedLevels');
    if(value.statistics)fail('idle save contains statistics');
    if (secrets.length) fail('idle save contains discovered secrets');
    if(Object.keys(value.heroCarry).length)fail('idle save contains hero equipment');
    for (const key of ['runId', 'mode', 'entryMode', 'levelIndex', 'levelId', 'contentId', 'characterId']) {
      if (value[key] !== empty[key]) fail('idle save contains an active run');
    }
    for (const key of CARRY_KEYS) if (carry[key] !== empty.carry[key]) fail('idle save contains progress');
    return empty;
  }
  if (typeof value.runId !== 'string' || !/^run-[a-z0-9]{1,7}-[a-z0-9]{1,7}-[a-z0-9]{1,7}$/.test(value.runId)) fail('invalid runId');
  const sequence = Number.parseInt(value.runId.split('-')[1], 36);
  integer(sequence, 1, MAX_RUN_SEQUENCE, 'run sequence');
  if (!['fixed', 'random'].includes(value.mode)) fail('unknown mode');
  if (typeof value.contentId !== 'string' || !CONTENT_IDENTIFIER.test(value.contentId)) fail('contentId must be a bounded identifier');
  if (!Array.isArray(value.levelOrder) || !value.levelOrder.length || value.levelOrder.length > MAX_LEVELS) fail('levelOrder must be a bounded nonempty list');
  const levelOrder = list(value.levelOrder, value.levelOrder.length, 'levelOrder');
  if (new Set(levelOrder).size !== levelOrder.length) fail('levelOrder must not repeat');
  for (const id of levelOrder) if (!allLevelIds.includes(id)) fail('unknown or unavailable saved level' + (typeof id === 'string' ? ': ' + id : ''));
  integer(value.levelIndex, 0, levelOrder.length - 1, 'levelIndex');
  if (value.levelId !== levelOrder[value.levelIndex]) fail('levelId does not match levelIndex');
  const planned = list(value.plannedCharacters, levelOrder.length, 'plannedCharacters');
  planned.forEach(id => hero(id, heroIds));
  if(!Array.isArray(value.characterRoster)||!value.characterRoster.length||value.characterRoster.length>128)fail('characterRoster must be a bounded nonempty list');
  const roster=list(value.characterRoster,value.characterRoster.length,'characterRoster');
  if(new Set(roster).size!==roster.length)fail('characterRoster must not repeat');
  roster.forEach(id=>hero(id,heroIds));
  if(planned.some(id=>!roster.includes(id)))fail('planned character is not in the saved roster');
  if(Object.keys(value.heroCarry).some(id=>!roster.includes(id)))fail('hero equipment belongs to a character outside the saved roster');
  if (hero(value.characterId, heroIds) !== planned[value.levelIndex]) fail('character does not match stage plan');
  if (value.mode === 'fixed' && planned.some(id => id !== planned[0])) fail('fixed campaign changes character');
  if(value.mode==='fixed'&&(roster.length!==1||roster[0]!==value.characterId))fail('fixed campaign roster must contain only its character');
  if (value.mode === 'random')checkRandomPlan(planned,roster,originalVersion<3);
  if (value.status === 'between' && value.levelIndex === levelOrder.length - 1) fail('final level must complete campaign');
  if (value.status === 'complete' && value.levelIndex !== levelOrder.length - 1) fail('campaign completed before final level');
  if(!Array.isArray(value.skippedLevels)||value.skippedLevels.length>value.levelIndex)fail('skippedLevels exceeds prior stages');
  const skipped=list(value.skippedLevels,value.skippedLevels.length,'skippedLevels');
  let previousSkipped=-1;
  for(const id of skipped){const index=levelOrder.indexOf(id);if(index<=previousSkipped||index>=value.levelIndex)fail('skippedLevels must follow the saved order before the current stage');previousSkipped=index;}
  const visitedCount = value.levelIndex + (['between', 'complete'].includes(value.status) ? 1 : 0);
  const expectedCleared=levelOrder.slice(0,visitedCount).filter(id=>!skipped.includes(id));
  const cleared = list(value.clearedLevels, expectedCleared.length, 'clearedLevels');
  if (cleared.some((id, index) => id !== expectedCleared[index])) fail('cleared levels must match the visited prefix excluding skipped stages');
  if ((value.status === 'gameover') !== (carry.lives === 0)) fail('lives and status disagree');
  // An owned hidden scene proves discovery even in older/incomplete saves.
  // Reconcile before advancement; a resumed challenge is not a fresh entrance.
  if(carry.challenge&&!secrets.includes(carry.challenge.id)){if(secrets.length>=64)fail('secretIds capacity exceeded');secrets.push(carry.challenge.id);}
  const result={...value, levelOrder: [...levelOrder], characterRoster: [...roster], plannedCharacters: [...planned], clearedLevels: [...cleared], skippedLevels:[...skipped], secretIds: [...secrets], carry,statistics:value.statistics?copyRunStatistics(value.statistics,levelOrder):createRunStatistics(levelOrder,true)};
  // Only the shipped World One saves gain the newly registered classic worlds.
  // Arbitrary custom campaign orders remain owned by their saved run.
  const legacyStart=V1_LEVEL_ORDER.indexOf(levelOrder[0]);
  if(originalVersion<3&&legacyStart>=0&&levelOrder.length===4-legacyStart&&levelOrder.every((id,i)=>id===V1_LEVEL_ORDER[legacyStart+i])&&CLASSIC_LEVEL_ORDER.every((id,i)=>levelIds[i]===id)){
    const expanded=levelIds.slice(legacyStart);
    result.levelOrder=expanded;result.contentId=legacyStart?orderContentId(expanded):contentId;
    result.plannedCharacters=value.mode==='fixed'?expanded.map(()=>planned[0]):randomPlan(expanded.length,roster,migrationRandom(value.runId),planned);
    result.statistics={...result.statistics,levels:[...result.statistics.levels,...createRunStatistics(expanded.slice(levelOrder.length)).levels]};
    if(value.status==='complete')result.status='between';
  }
  return result;
}

/** Pure synchronous progression; the stage engine owns death/respawn and score awards.
 * Random plans and run IDs use only the injected RNG, so a seed reproduces a run.
 * Carry updates are partial. Power is 0..3; weapon is null or an identifier.
 * Each run owns its levelOrder/contentId/characterRoster; v1/v2 World One saves extend to the
 * full classic campaign when registered. Other saved orders stay unchanged.
 * Mutations do not save automatically. restore throws without changing state;
 * save/load return {ok, state} or {ok:false, error} for unavailable/corrupt storage.
 */
export function createCampaign({random = Math.random, storage = null, storageKey = 'mariomix.campaign.v1', catalog = campaignCatalog} = {}) {
  if (typeof random !== 'function') fail('random must be a function');
  if (typeof storageKey !== 'string' || !storageKey.length || storageKey.length > 128) fail('invalid storage key');
  const registered = registeredContent(catalog), {heroIds, levelIds, contentId} = registered;
  let current = initialState();
  let runSequence = 0;
  const state = () => frozenCopy(current);
  // Per-frame UI reads must not copy a hidden world's terrain checkpoint.
  const view = () => {
    const carry={...current.carry};
    if(carry.challenge){carry.challenge={...carry.challenge};delete carry.challenge.scene;}
    return frozenCopy({...current,carry});
  };
  const commit = next => {
    if (JSON.stringify(next).length > MAX_SAVE_LENGTH) fail('save is too large');
    current = next; return state();
  };
  const sample = () => {
    const value = random();
    if (typeof value !== 'number' || !Number.isFinite(value) || value < 0 || value >= 1) fail('random must return a number in [0, 1)');
    return value;
  };
  const carryUpdate = update => {
    if (update === undefined) return {...current.carry};
    record(update, CARRY_UPDATE_KEYS, 'carry update', true);
    return checkedCarry({...current.carry, ...update}, current.characterId);
  };
  const requireStatus = (...statuses) => {
    if (!statuses.includes(current.status)) throw new Error(`Campaign operation unavailable in ${current.status}`);
  };
  const restore = input => {
    const next = validate(input, registered);
    const restored = commit(next);
    if (next.runId) runSequence = Math.max(runSequence, Number.parseInt(next.runId.split('-')[1], 36));
    return restored;
  };
  const storageFailure = error => ({ok: false, error: error instanceof Error ? error.message : 'Campaign storage failed'});
  const moveTo=(levelIndex,nextCarry=current.carry,extra={})=>{
    const characterId=current.plannedCharacters[levelIndex];
    const heroCarry={...current.heroCarry,[current.characterId]:equipment(nextCarry)};
    const carry={...nextCarry,hero:characterId};
    delete carry.checkpoint;delete carry.challenge;
    if(characterId!==current.characterId){carry.power=0;carry.weapon=null;delete carry.native;delete carry.protection;Object.assign(carry,heroCarry[characterId]||{});}
    return commit({...current,...extra,status:'playing',levelIndex,levelId:current.levelOrder[levelIndex],characterId,carry,heroCarry});
  };

  return Object.freeze({
    view,
    newRun(options = {}) {
      record(options, ['mode', 'characterId', 'levelId', 'entryMode', 'initialLives'], 'run options', true);
      const {mode = 'fixed', characterId = heroIds[0], levelId = levelIds[0], entryMode = 'story', initialLives = 3} = options;
      if(![3,30].includes(initialLives))fail('unsupported starting lives');
      if(!['story','stage-select'].includes(entryMode))fail('unknown entry mode');
      if(!levelIds.includes(levelId))fail('unknown starting level');
      const levelOrder=levelIds.slice(levelIds.indexOf(levelId));
      if (!['fixed', 'random'].includes(mode)) fail('unknown mode');
      hero(characterId, heroIds);
      integer(runSequence + 1, 1, MAX_RUN_SEQUENCE, 'run sequence');
      const planned = mode === 'fixed'
        ? levelOrder.map(() => characterId)
        : randomPlan(levelOrder.length,heroIds,sample);
      const token = () => Math.floor(sample() * 0x100000000).toString(36);
      const runId = `run-${(runSequence + 1).toString(36)}-${token()}-${token()}`;
      const first = planned[0];
      const next = {
        schema: SCHEMA, version: VERSION, runId, mode, entryMode, status: 'playing',
        levelIndex: 0, levelId, levelOrder, contentId:levelOrder.length===levelIds.length?contentId:orderContentId(levelOrder), characterId: first,
        characterRoster: mode==='fixed'?[characterId]:[...heroIds], plannedCharacters: planned, clearedLevels: [], skippedLevels: [], secretIds: [],statistics:createRunStatistics(levelOrder),
        carry: {lives: initialLives, coins: 0, score: 0, hero: first, power: 0, weapon: null},heroCarry:{},
      };
      const result = commit(next);
      runSequence++;
      return result;
    },
    state,
    recordStatistic(key,amount=1){
      if(current.status!=='playing')return;
      current.statistics??=createRunStatistics(current.levelOrder,true);
      recordRunStatistic(current.statistics,current.levelId,key,amount);
    },
    continueRun() {
      requireStatus('gameover');
      current.statistics??=createRunStatistics(current.levelOrder,true);
      recordRunStatistic(current.statistics,current.levelId,'continues');
      // Explicit player choice; ordinary retry can never mint lives. Preserve
      // the campaign plan and room checkpoint. An internal branch must not
      // silently turn into its parent level when the player chooses Continue.
      const carry=current.carry.challenge?{...current.carry,lives:3,protection:0,challenge:{...current.carry.challenge,phase:'retry',scene:current.carry.challenge.phase==='retry'?(current.carry.challenge.scene??null):null}}:
        {lives:3,coins:current.carry.coins,score:current.carry.score,hero:current.characterId,power:0,protection:0,weapon:null,checkpoint:current.carry.checkpoint||null,
         ...(current.carry.respawnNative?{native:copyRespawnEquipment(current.characterId,current.carry.respawnNative),respawnNative:null}:{})};
      return commit({...current,status:'playing',carry});
    },
    stageCleared(carry) {
      // A duplicated finish callback cannot award progress or update score twice.
      if (['between', 'complete', 'gameover'].includes(current.status)) return state();
      requireStatus('playing');
      const nextCarry = carryUpdate(carry);
      if (nextCarry.lives === 0) return commit({...current, carry: nextCarry, status: 'gameover'});
      return commit({...current, carry: nextCarry,
        status: current.levelIndex === current.levelOrder.length - 1 ? 'complete' : 'between',
        clearedLevels: [...current.clearedLevels, current.levelId],
      });
    },
    advance() {
      requireStatus('between');
      return moveTo(current.levelIndex+1);
    },
    bonusAvailable(){return current.status==='complete'?(catalog.bonusAfter?.(current.levelId)||null):null;},
    continueAfterCredits(){
      requireStatus('complete');
      const target=catalog.bonusAfter?.(current.levelId);
      if(!target||!registered.allLevelIds.includes(target)||current.levelOrder.includes(target))fail('no post-credits stage available');
      // Append to the same run. Equipment, statistics and the random bag remain
      // authoritative; this is not a new adventure or an implicit stage warp.
      const levelOrder=[...current.levelOrder,target];
      const plannedCharacters=current.mode==='fixed'?[...current.plannedCharacters,current.characterId]:
        randomPlan(levelOrder.length,current.characterRoster,sample,current.plannedCharacters);
      const statistics={...current.statistics,levels:[...current.statistics.levels,...createRunStatistics([target]).levels]};
      const characterId=plannedCharacters.at(-1),heroCarry={...current.heroCarry,[current.characterId]:equipment(current.carry)};
      const carry={...current.carry,hero:characterId};delete carry.checkpoint;delete carry.challenge;
      if(characterId!==current.characterId){carry.power=0;carry.weapon=null;delete carry.native;delete carry.protection;delete carry.respawnNative;Object.assign(carry,heroCarry[characterId]||{});}
      return commit({...current,levelOrder,contentId:orderContentId(levelOrder),plannedCharacters,statistics,
        levelIndex:levelOrder.length-1,levelId:target,characterId,carry,heroCarry,status:'playing'});
    },
    warpTo(targetLevelId,carry){
      requireStatus('playing');
      const levelIndex=current.levelOrder.indexOf(targetLevelId);
      if(!levelIds.includes(targetLevelId)||levelIndex<=current.levelIndex)fail('warp target must be a later registered stage in this run');
      const nextCarry=carryUpdate(carry);
      if(nextCarry.lives===0)fail('cannot warp without a life');
      // A pipe skips the unfinished source and intervening stages; it never
      // fabricates clears or rerolls the registered character plan.
      return moveTo(levelIndex,nextCarry,{skippedLevels:[...current.skippedLevels,...current.levelOrder.slice(current.levelIndex,levelIndex)]});
    },
    retry(carry) {
      requireStatus('playing', 'gameover');
      const nextCarry = carryUpdate(carry);
      if (current.status === 'gameover') {
        if (nextCarry.lives !== 0) fail('cannot revive a gameover run');
        return state();
      }
      return commit({...current, carry: nextCarry, status: nextCarry.lives === 0 ? 'gameover' : 'playing'});
    },
    markSecret(id) {
      secretId(id);
      if (current.secretIds.includes(id)) return state();
      requireStatus('playing');
      if (current.secretIds.length === 64) fail('secretIds must contain at most 64 IDs');
      return commit({...current, secretIds: [...current.secretIds, id]});
    },
    abandon: () => commit(initialState()),
    snapshot: () => JSON.stringify(current),
    restore,
    save() {
      try {
        if (!storage || typeof storage.setItem !== 'function') throw new Error('Campaign storage unavailable');
        storage.setItem(storageKey, JSON.stringify(current));
        return {ok: true, state: state()};
      } catch (error) { return storageFailure(error); }
    },
    load() {
      try {
        if (!storage || typeof storage.getItem !== 'function') throw new Error('Campaign storage unavailable');
        const saved = storage.getItem(storageKey);
        if (saved === null || saved === undefined) throw new Error('No saved campaign');
        if (typeof saved !== 'string') throw new Error('Campaign storage returned a non-string save');
        return {ok: true, state: restore(saved)};
      } catch (error) { return storageFailure(error); }
    },
  });
}
