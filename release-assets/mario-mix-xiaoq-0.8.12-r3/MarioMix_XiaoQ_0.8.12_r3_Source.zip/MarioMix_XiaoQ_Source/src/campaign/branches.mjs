import {classicWarpTarget} from '../engine/classic-course-mechanics.mjs';

const fail=message=>{throw new TypeError('World branch: '+message);};
const id=value=>typeof value==='string'&&/^[A-Za-z0-9][A-Za-z0-9._:-]{0,79}$/.test(value);
const overlapY=(a,b)=>a.y+a.h>b.y&&a.y<b.y+b.h;

/** Room branches belong to the map. They never choose, recreate or reset a hero.
 * Compose once, before catalog validation/freezing; live activation is separate.
 */
export function installWorldBranches(world,branches,levelIds){
 const routes=[],policies={};
 for(const branch of branches){
  if(branch.level!==world.level)continue;
  if(!id(branch.id)||routes.some(r=>r.id===branch.id))fail('invalid/duplicate id');
  const rule=branch.activation,source=world.visualRooms.find(r=>r.roomId===rule?.roomId);
  if(rule?.kind!=='terrain-breach-crossing'||!source||!Number.isFinite(rule.x)||
     !Number.isFinite(rule.top)||!Number.isFinite(rule.bottom)||rule.top>=rule.bottom||
     rule.x<0||rule.x>source.map.width||rule.top<0||rule.bottom>source.map.height)fail('invalid crossing');
  if(!Array.isArray(rule.geometryIds)||!rule.geometryIds.length||new Set(rule.geometryIds).size!==rule.geometryIds.length)fail('invalid breach geometry');
  for(const key of rule.geometryIds){
   const g=world.plan.rooms[rule.roomId].geometry.find(g=>g.id===key);
   const semantic=source.semantics?.find(s=>s.id===key);
   if(!g||semantic?.type!=='Brick'||g.x>=rule.x||g.x+g.w!==rule.x||g.y<rule.top||g.y+g.h>rule.bottom)fail('breach boundary must name its actual outer brick tiles');
  }
  // A single authored original-game easter egg, not a portable wall-clipping
  // capability. Validate all solids that its short scripted slide may cross.
  const clip=branch.marioPipeClip;
  if(clip){
   const geometry=world.plan.rooms[rule.roomId].geometry,foot=geometry.find(g=>g.id===clip.supportId),wall=geometry.find(g=>g.id===clip.wallId);
   if(world.level!=='1-2'||branch.id!=='blank-world'||rule.roomId!=='area-1'||clip.kind!=='mario-crouch-pipe-clip'||
      !foot||!wall||foot.collision!=='solid'||wall.collision!=='solid'||foot.x>=wall.x||foot.x+foot.w<=wall.x||foot.y<=wall.y||
      clip.exitX!==rule.x||clip.top!==wall.y+16||clip.bottom!==foot.y||clip.exitX<=wall.x+wall.w||
      !Array.isArray(clip.brickIds)||!clip.brickIds.length||new Set(clip.brickIds).size!==clip.brickIds.length)fail('invalid Mario pipe clip');
   const corridor=geometry.filter(g=>g.x>=wall.x+wall.w&&g.x<clip.exitX&&g.y<clip.bottom&&g.y+g.h>clip.top);
   if(corridor.length!==clip.brickIds.length||corridor.some(g=>!clip.brickIds.includes(g.id)||g.collision!=='solid'||!source.semantics?.some(s=>s.id===g.id&&s.type==='Brick')))fail('stale Mario clip corridor');
  }
  if(!Array.isArray(branch.visualRooms)||!Object.keys(branch.rooms||{}).length)fail('missing authored rooms');
  for(const [roomId,room]of Object.entries(branch.rooms)){
   if(!id(roomId)||world.plan.rooms[roomId])fail('room id occupied '+roomId);
   const visual=branch.visualRooms.find(r=>r.roomId===roomId);
   if(!visual)fail('room has no visuals');
   world.plan.rooms[roomId]=structuredClone(room);world.visualRooms.push(structuredClone(visual));
   const policy=branch.roomPolicies?.[roomId];
   if(!policy||typeof policy.displayLevel!=='string'||!/^ [\-][1-9]$/.test(policy.displayLevel)||
      !room.objects.some(o=>o.kind==='spawn'&&o.id===policy.entryCheckpoint))fail('invalid branch presentation/checkpoint');
   policies[roomId]=structuredClone(policy);
  }
  if(!Array.isArray(branch.destinations)||!branch.destinations.length)fail('missing pipe destinations');
  const seen=new Set();
  for(const dest of branch.destinations){
   if(seen.has(dest.markerId)||!source.markers.some(m=>m.id===dest.markerId&&classicWarpTarget(m)))fail('unknown/duplicate warp pipe');
   seen.add(dest.markerId);
   if(dest.targetWorld){if(dest.targetRoom||dest.targetSpawn||!levelIds.includes(dest.targetWorld))fail('invalid world target');}
   else if(!branch.rooms[dest.targetRoom]?.objects.some(o=>o.id===dest.targetSpawn&&o.kind==='spawn'))fail('invalid room target');
  }
  if(!Array.isArray(branch.hideMarkers)||!branch.hideMarkers.every(key=>source.markers.some(m=>m.id===key)))fail('unknown hidden label');
  for(const room of Object.values(branch.rooms))for(const portal of room.objects.filter(o=>o.kind==='portal')){
   if(!branch.rooms[portal.targetRoom]?.objects.some(o=>o.kind==='spawn'&&o.id===portal.targetSpawn))fail('branch loop destination missing');
   if(portal.resetRoom!==true)fail('loop must explicitly reconstruct its room');
  }
  routes.push({id:branch.id,activation:structuredClone(rule),...(clip?{marioPipeClip:structuredClone(clip)}:{}),destinations:structuredClone(branch.destinations),hideMarkers:[...branch.hideMarkers]});
 }
 if(routes.length){world.plan.stage.branches=routes;world.plan.stage.roomPolicies=policies;}
 return world;
}

/** Each live room remembers actual destroyed tiles and a witnessed forward
 * crossing through their opening. Firing from the roof is not an entry event.
 */
export function createBreachRoutes(routes=[]){
 const broken=new Map(),active=new Map();
 let jump=null,slide=null;
 const clipSolids=(route,solids)=>{
  const c=route.marioPipeClip,wall=solids.find(g=>g.id===c.wallId),foot=solids.find(g=>g.id===c.supportId);
  return wall&&!wall.hidden&&foot&&!foot.hidden&&c.brickIds.every(id=>solids.some(g=>g.id===id&&!g.hidden))?{wall,foot}:null;
 };
 return Object.freeze({
  cancelClip(){jump=slide=null;},
  // Called before the normal motor. Arming records a real grounded takeoff,
  // not merely finding a crouched player already embedded in a wall.
  moveMarioClip(roomId,p,input,solids){
   if(slide){
    const {route,y}=slide,c=route.marioPipeClip;
    if(p.hero!=='mario'||!p.power||roomId!==route.activation.roomId||!clipSolids(route,solids)){
     // A map/actor mutation cannot strand a body inside solid terrain.
     Object.assign(p,{x:slide.originX,y:slide.originY,vx:0,vy:0});slide=jump=null;return {handled:true};
    }
    p.x=Math.min(c.exitX,p.x+1);p.y=y;p.h=16;p.crouch=true;p.facing=-1;p.vx=1;p.vy=0;p.grounded=false;p.support=null;p.headHit=null;
    if(p.x===c.exitX){active.set(route.id,route);slide=jump=null;return {handled:true,completed:route.id};}
    return {handled:true};
   }
   if(jump&&(roomId!==jump.roomId||p.hero!=='mario'||!p.power||p.grounded||++jump.age>48))jump=null;
   if(p.hero==='mario'&&p.power&&p.grounded&&p.facing===-1&&input.down&&input.jumpPressed){
    for(const route of routes){
     const c=route.marioPipeClip;if(!c||active.has(route.id)||route.activation.roomId!==roomId)continue;
     const bounds=clipSolids(route,solids);if(!bounds)continue;
     const {foot,wall}=bounds;
     if(p.support===foot.id&&Math.abs(p.y+p.h-foot.y)<.1&&p.x>=foot.x&&p.x+p.w<=wall.x&&wall.x-p.x-p.w<=16){
      jump={route,roomId,age:0,originX:p.x,originY:foot.y-16};break;
     }
    }
   }
   return null;
  },
  witnessMarioClip(roomId,before,p,input,solids){
   if(!jump||slide||jump.roomId!==roomId||!p.crouch||p.h!==16||p.grounded||p.facing!==-1||input.x<=0||p.vy>=0)return false;
   const {route}=jump,c=route.marioPipeClip,bounds=clipSolids(route,solids);
   if(!bounds||p.y<c.top||p.y+p.h>c.bottom-4||before.x+p.w>bounds.wall.x+.01||Math.abs(p.x+p.w-bounds.wall.x)>.01||p.wallSide!==1)return false;
   slide={...jump,y:p.y};jump=null;return true;
  },
  destroyed(roomId,tile){
   for(const route of routes)if(route.activation.roomId===roomId&&route.activation.geometryIds.includes(tile.sourceId||tile.id)){
    if(!broken.has(route.id))broken.set(route.id,new Map());
    broken.get(route.id).set(tile.id,{x:tile.x,y:tile.y,w:tile.w,h:tile.h});
   }
  },
  cross(roomId,before,after){
   const ax=before.x+before.w/2,bx=after.x+after.w/2;
   for(const route of routes){
    const gate=route.activation;if(gate.roomId!==roomId||active.has(route.id)||ax>=gate.x||bx<gate.x||bx<=ax)continue;
    const t=(gate.x-ax)/(bx-ax),body={y:before.y+(after.y-before.y)*t,h:after.h};
    // The whole collision body must use the opening, below the roof route.
    if(body.y<gate.top||body.y+body.h>gate.bottom)continue;
    if([...broken.get(route.id)?.values()||[]].some(tile=>overlapY(tile,body))){active.set(route.id,route);return route.id;}
   }
   return null;
  },
  destination(roomId,markerId){
   for(const route of active.values())if(route.activation.roomId===roomId){const d=route.destinations.find(d=>d.markerId===markerId);if(d)return {...d};}
   return null;
  },
  hiddenMarkers(roomId){return [...active.values()].filter(r=>r.activation.roomId===roomId).flatMap(r=>r.hideMarkers);},
  activeIds:()=>[...active.keys()],
  reset(){broken.clear();active.clear();jump=slide=null;},
 });
}
