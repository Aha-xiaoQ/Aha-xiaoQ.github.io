/** Source-authored pipe intros use a scene-owned input override (SMB
 * PlayerEntrance / ChkBehPipe). Ordinary pipes remain player controlled.
 * The registry selects scenes; validated entity IDs bind the actual route.
 */
const PIPE_INTRO_LEVELS=new Set(['1-2','2-2','4-2','7-2']);
export function attachEntranceSequence(world){
  if(!PIPE_INTRO_LEVELS.has(world.level))return;
  const {stage,rooms}=world.plan,room=rooms[stage.entryRoom];
  const visual=world.visualRooms.find(r=>r.roomId===stage.entryRoom);
  const side=visual?.semantics?.find(s=>(s.type||s.kind)==='PipeHorizontal');
  const pipe=room.geometry.find(g=>g.id===side?.id);
  const portal=room.objects.find(o=>o.kind==='portal'&&o.id===side?.id+'-portal');
  if(!pipe||!portal||!rooms[portal.targetRoom]?.objects.some(o=>o.kind==='spawn'&&o.id===portal.targetSpawn))throw new TypeError('Invalid authored pipe intro: '+world.level);
  stage.entrySequence={kind:'walk-to-pipe',roomId:stage.entryRoom,spawnId:stage.entrySpawn,
    portalId:portal.id,pipeId:pipe.id,speed:1.125};
}

export function beginEntranceSequence(plan,roomId,spawnId){
  const q=plan.stage.entrySequence;
  if(!q||q.roomId!==roomId||q.spawnId!==spawnId)return null;
  const room=plan.rooms[roomId],pipe=room.geometry.find(g=>g.id===q.pipeId);
  const portal=room.objects.find(o=>o.id===q.portalId&&o.kind==='portal');
  if(q.kind!=='walk-to-pipe'||!pipe||!portal||!(q.speed>0&&q.speed<=2))throw new TypeError('Invalid entrance sequence');
  return {...q,age:0,feet:pipe.y+pipe.h,mouthX:pipe.x,targetRoom:portal.targetRoom,targetSpawn:portal.targetSpawn};
}

/** Cloud bonus floors may extend to the imported right bound. Preserve every
 * tile, but reserve an open departure column so one-way scrolling cannot trap
 * an actor after the tiny entrance gap has gone offscreen.
 */
export function attachSkyDepartureSpace(world){
  for(const visual of world.visualRooms){
    const room=world.plan.rooms[visual.roomId];
    if(!/Sky/.test(visual.setting)||!room.objects.some(o=>o.id==='sky-return'))continue;
    const edge=Math.max(0,...room.geometry.filter(g=>g.collision==='solid'&&g.y>=room.height-32).map(g=>g.x+g.w));
    if(edge+64>room.width){room.width=edge+64;visual.map.width=room.width;}
    const back=room.objects.find(o=>o.id==='sky-return');back.w=room.width;
  }
}
