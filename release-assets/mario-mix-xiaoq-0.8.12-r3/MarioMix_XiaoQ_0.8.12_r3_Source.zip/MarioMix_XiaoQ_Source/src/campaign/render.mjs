import {rescueMarioPose,finalRescueMarioPose} from '../content/castle-reunions.mjs';
import {classicSprite} from './art/classic-art.mjs';
import * as art from './art/editor-art.mjs';
import {orderedTerrain,enemySprite} from './art/map-appearance.mjs';
import {bossBar} from '../engine/castle-boss.mjs';
import {drawStarActor,castleDialogue,rescueAnchors} from './feedback.mjs';
import {verticalCameraY} from '../engine/view-bounds.mjs';
import {ownsCharacterSupply} from '../engine/pickup-presentation.mjs';

export {preloadArt} from './art/editor-art.mjs';
export function staticMarker(marker){
  // Reference markers persist after actors die. Never draw their enemy art.
  return !enemySprite(marker.kind)&&marker.kind!=='marker-Bowser';
}
export function renderCampaign(ctx,view,world,{width=256,height=240,level='1-1',drawCharacter,drawWorld,drawWorldBehind,drawWorldFront,drawPickup,drawCoin,drawHud,drawCompanion,drawEnemy}={}){
  const camX=view.cam,camY=verticalCameraY(view.p.y,{minY:view.minY,focusY:view.focusY,height:view.height,viewportHeight:height});
  const room={...world.visualRooms.find(r=>r.roomId===view.roomId),playGeometry:view.geometry,finish:view.finish,tick:view.tick,renderBounds:{x:camX,y:camY,w:width,h:height}};
  const offset=Math.max(0,(width-view.width)/2);
  art.background(ctx,room,width,height);
  ctx.save();ctx.translate(Math.round(offset-camX),-Math.round(camY));
  art.drawScenery(ctx,room);
  const visible=o=>o.x+o.w>=camX&&o.x<=camX+width&&o.y+o.h>=camY&&o.y<=camY+height;
  for(const vine of view.vines||[])art.drawReference(ctx,{kind:'active-vine',...vine},room);
  for(const marker of room.markers||[])if(/^(lava|water)-/.test(marker.kind))art.drawReference(ctx,marker,room);
  for(const g of room.decorations||[])if(!g.hidden&&visible(g))art.drawTile(ctx,g,room);
  const behind=o=>!!o.emerge||Number.isFinite(o.clipTop);
  const actor=o=>{
    // Actor-owned entities are drawn by drawWorld. Independently installed
    // sources (including their effects) must be claimed by their own renderer.
    const independent=o.nativeOwner==='foe-port'||(!o.nativeOwner&&o.foeSource&&o.foeSource!=='mario');
    if(independent){
      if(drawEnemy?.(ctx,o,view.tick)!==true)throw new TypeError('Enemy render owner refused '+(o.contractId||o.foeSource));
      return;
    }
    if(o.nativeOwner&&o.nativeOwner!=='stage')return;
    if(o.kind==='coin'&&drawCoin?.(ctx,o,view.tick)===true)return;
    if(drawPickup&&ownsCharacterSupply(o,view.p.hero)){ctx.save();if(o.emerge){ctx.beginPath();ctx.rect(o.x-16,-100,48,(o.blockTop??o.y)+100);ctx.clip();}const handled=drawPickup(ctx,o,view.tick);ctx.restore();if(handled)return;}
    if(o.kind==='mainline-shot'){
      ctx.fillStyle=({tank:'#ffe388',megaman:o.charged?'#f7f6ab':'#72edff',ori:'#adfaff',ryu:'#f8f1be',sandboxTrio:'#adccf5'})[o.hero];
      if(o.slash){ctx.save();ctx.globalAlpha=Math.max(.15,1-o.age/o.life);ctx.beginPath();ctx.arc(o.x+o.w/2,o.y+o.h/2,o.w/2,-1.2,1.2);ctx.lineWidth=2;ctx.strokeStyle=ctx.fillStyle;ctx.stroke();ctx.restore();}
      else{ctx.fillRect(Math.round(o.x),Math.round(o.y),o.w,o.h);ctx.fillStyle='#fff';ctx.fillRect(Math.round(o.x+1),Math.round(o.y+1),Math.max(1,o.w-2),2);}
      return;
    }
    art.drawObject(ctx,{...o,skin:o.shell?(/beetle/i.test(o.type)?'beetleshell':'shell'):o.type||room.enemySkins?.[o.id]||room.markers?.find(m=>m.id===o.id)?.kind,source:{...o.source,frame:o.frame}},view.tick,room);
  };
  for(const o of [...view.enemies,...view.items])if(behind(o)&&visible(o))actor(o);
  for(const g of orderedTerrain(room,view.geometry.filter(g=>!g.hidden&&visible(g))))art.drawTile(ctx,{...g,y:g.y-(g.bump?Math.sin(g.bump/12*Math.PI)*6:0),material:g.used?'used':g.material||room.map?.geometry.find(q=>q.id===(g.sourceId||g.id))?.material},room);
  drawWorldBehind?.(ctx,view);
  for(const marker of room.markers||[])if(!/^(lava|water)-/.test(marker.kind)&&!view.hiddenMarkers.includes(marker.id)&&marker.kind!=='decorative-trunk'&&staticMarker(marker)&&!drawCompanion?.(ctx,marker,view,level))art.drawReference(ctx,marker,room);
  for(const o of [...view.objects,...view.enemies,...view.items])if(!['spawn','portal'].includes(o.kind)&&!behind(o)&&visible(o))actor(o);
  drawWorld?.(ctx,view);
  let characterFrame=null;
  if(view.finish?.castle||view.finish?.phase!=='score'){
    ctx.save();if(view.transition){ctx.beginPath();if(view.transition.clipTop!=null)ctx.rect(camX,camY,width,Math.max(0,view.transition.clipTop-camY));else ctx.rect(camX,camY,Math.max(0,view.transition.clipRight-camX),height);ctx.clip();}
    if(view.presentation?.invulnerability==='palette'||view.finish||view.p.star||!view.p.invulnerable||view.tick%8<4)characterFrame=drawStarActor(ctx,view.p,view.tick,()=>drawCharacter?.(ctx,view.p,view.tick,view));
    ctx.restore();
  }
  drawWorldFront?.(ctx,view);
  const rescue=rescueMarioPose(view.finish);
  const finalMario=finalRescueMarioPose(view.p.hero,level,view.finish,view.p,room.markers?.find(m=>m.kind==='castle-finish'));
  if(finalMario){
    const im=classicSprite(finalMario.sprite);ctx.save();ctx.translate(Math.round(finalMario.x),finalMario.feet);ctx.scale(finalMario.facing,1);ctx.drawImage(im,-im.width/2,-im.height);ctx.restore();
  }else if(rescue){
    ctx.fillStyle='#bcbcbc';if(view.finish.phase==='rescue'){for(const x of [rescue.x-6,rescue.x+5])ctx.fillRect(x,view.finish.rooftop.top,2,rescue.ladderBottom-view.finish.rooftop.top);
    for(let y=view.finish.rooftop.top+5;y<rescue.ladderBottom;y+=8)ctx.fillRect(rescue.x-5,y,11,2);}
    const im=classicSprite(rescue.climbing?'small_climb'+(Math.floor(view.tick/8)%2):'small_idle');ctx.drawImage(im,Math.round(rescue.x-im.width/2),Math.round(rescue.feet-im.height));
  }
  for(const e of view.enemies){const b=bossBar(e,view.tick);if(!b||!visible(e))continue;ctx.fillStyle='#000';ctx.fillRect(b.x-1,b.y-1,b.w+2,b.h+2);ctx.fillStyle='#fff';ctx.fillRect(b.x,b.y,b.w,b.h);ctx.fillStyle='#b82000';ctx.fillRect(b.x+1,b.y+1,30,2);ctx.fillStyle='#f8b800';ctx.fillRect(b.x+1,b.y+1,b.fill,2);}
  ctx.restore();
  // Rooftop extraction occupies the HUD band: its brief cinematic owns the
  // frame. Keep ordinary castle/gameplay HUD unchanged; never move actor physics.
  if(!view.finish?.rooftop)art.drawHud(ctx,view,view.displayLevel||level,width);
  const reunion=room.markers?.find(m=>m.kind==='castle-finish');
  const textCenter=reunion?rescueAnchors(reunion,rescue?{x:rescue.x-8,w:16}:view.p,camX,offset).textCenter:width/2;
  castleDialogue(view.p.hero,view.finish,level).forEach((line,i)=>art.drawPixelText(ctx,line,Math.round(textCenter-line.length*4),72+i*20));
  if(!view.finish)drawHud?.(ctx,view,width,art.drawPixelText);
  return {characterFrame,camera:{x:camX,y:camY,offset},player:{x:view.p.x-camX+offset,y:view.p.y-camY,w:view.p.w,h:view.p.h}};
}
