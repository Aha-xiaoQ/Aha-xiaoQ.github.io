import {castleReunion} from '../content/castle-reunions.mjs';
/** Shared presentation contracts. Effects are scoped to an actor draw, never a scene. */
export function drawStarActor(context, body, tick, draw) {
  context.save();
  if (body.star > 0 && !body.dying) {
    const hue = [0, 90, 190, 290][Math.floor(tick / 4) % 4];
    context.filter = `brightness(1.7) sepia(1) saturate(5) hue-rotate(${hue}deg)`;
  }
  try { return draw(); } finally { context.restore(); }
}

/** A room may explicitly author a reward; ordinary upgrades rotate per stage,
 * across rooms, with a stable level offset and no repeat of equipped weapons. */
export function weaponReward({content = '', index = 0, level = '1-1', current = 'N'}) {
  if (/^bill-[msfl]$/i.test(content)) return content.slice(-1).toUpperCase();
  const pool = ['M', 'S', 'F', 'L'];
  const offset = Math.max(0, (Number(level.split('-')[1]) || 1) - 1);
  let slot = (index + offset) % pool.length;
  if (pool[slot] === current) slot = (slot + 1) % pool.length;
  return pool[slot];
}

export function castleDialogue(hero, finish, level='1-4') {
  if (!finish?.castle || !['reunion', 'score'].includes(finish.phase)) return [];
  // Ori's native finale owns its dialogue and cinematic timing.
  if(hero==='ori'&&level==='1-4')return [];
  const lines=castleReunion(hero,level).lines;
  return finish.phase==='score'||finish.age>=60?lines:lines.slice(0,1);
}

export function rescueAnchors(marker,hero,camera=0,offset=0){
  const companionX=marker.x+408,feet=208;
  return {companionX,feet,textCenter:(hero.x+hero.w/2+companionX)/2-camera+offset};
}
