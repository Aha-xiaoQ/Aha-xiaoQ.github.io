import {beginEntranceSequence} from './entrance-sequences.mjs';
import {isMainlineWater} from '../engine/mainline-water.mjs';
import {rooftopRescue} from '../content/castle-reunions.mjs';
import {createBreachRoutes} from './branches.mjs';
import {characterSupply,ownsCharacterSupply} from '../engine/pickup-presentation.mjs';
import {driveHeadContact,pipeEntryPose} from '../engine/world-collision.mjs';
import {scriptedMotionPresentation} from '../engine/motion-presentation.mjs';
import {rescueAnchors} from './feedback.mjs';
import {stepEnemyMotionPort} from '../engine/enemy-motion-port.mjs';
import {inputEdge} from '../engine/input-contract.mjs';
import {isCastleBoss,castleBossHealth,moveCastleBoss,damageCastleBoss} from '../engine/castle-boss.mjs';
import {applyEnemyEffect} from '../engine/enemy-effects.mjs';
import {characterAttack,advanceCharacterShots} from './combat.mjs';
import {weaponNames} from './art/editor-heroes.mjs';
import {billShots,advanceBillShot} from './art/editor-bill.mjs';
import {sourceType,markerParts,elevatorPlatforms,flagRestY} from './art/map-appearance.mjs';
import {enemyDefinition as defaultEnemyDefinition} from '../content/enemies.mjs';
import {canHitEnemy,retainEnemy,createEnemyContactSystem,bindEnemyHandlers,enemySimulationActive} from '../engine/enemy-contract.mjs';
import {moveEnemyBody,firstProjectileContact} from '../engine/world-collision.mjs';
import {terrainImpactAllows} from '../engine/terrain-impact.mjs';
import {MAINLINE_JUMP,validateMainlineAccess} from '../engine/mainline-movement.mjs';
import {copyActorEquipment,restoreActorEquipment,resolveActorEnemyContact,readRespawnEquipment,readActorRoomBounds,downgradeMainlineActor,readActorUpgrade,readActorHurtbox,validateActorScene,remapActorScene} from '../engine/actor-contract.mjs';
import {verticalCameraY,horizontalCameraX} from '../engine/view-bounds.mjs';
import {projectChallengeCounters,copySceneCheckpoint,nativeSceneHealth} from '../engine/scene-state.mjs';
import {addRoomReward} from '../engine/reward-receipt.mjs';
import {createCrouchPassageWitness,fallingPlatform,stepFallingPlatform,spawnZoneActive,classicWarpTarget,crossesFlagpole} from '../engine/classic-course-mechanics.mjs';
import {initializeClassicKoopaMotion,stepClassicKoopaMotion,removeClassicKoopaWings,isFloatingKoopa,validateClassicKoopaMotion} from '../engine/classic-koopa-motion.mjs';
// The campaign owns rooms, time, lives and exits. A registered actor owns its
// native movement, equipment, combat, audio and sprites. The portable motor
// remains available to workshop contract previews; production requires a port.
let stageInstanceSerial=0;
export function createCampaignStage(options){
  if(options.plan.character.heroId!=='mario'){
    for(const name of ['create','prepareRoom','step','hurt','downgrade','drawPlayer','audio','dispose'])
      if(typeof options.actorPort?.[name]!=='function')throw new TypeError('Native actor requires '+name);
  }
  return createPlatformStage({...options,unifiedHealth:true});
}
export function createPlatformStage({plan,motor,actorPort=null,enemyPort=null,enemyDefinition=defaultEnemyDefinition,emit,visualRooms=[],initialState=null,manualDeath=false,lifeOwner='stage',autoContinue=false,allowWarp=false,allowSecretDiscovery=true,viewportWidth=256,secretIds=[],debug=false,unifiedHealth=false,sceneHealth=null,backtracking=false}) {
  const crouchPassage=createCrouchPassageWitness();
  const levelLabel=plan.stage.id.replace(/^campaign-/,'').replace(/-stage$/,'');
  const stageInstanceId='stage-'+(++stageInstanceSerial);
  if(!['stage','campaign'].includes(lifeOwner)||lifeOwner==='campaign'&&!manualDeath)throw new TypeError('Invalid platform life owner');
  const copy=x=>JSON.parse(JSON.stringify(x));
  let roomId=plan.stage.entryRoom,p=null,tick=0,health=plan.character.motion.maxHealth,lives=3,coins=0,score=0,timeLeft=400,timerTicks=0,invulnerable=0,cooldown=0,attackAge=0,portalLock=0,disposed=false,prev={},completed=false,finish=null,transition=null,shrink=0,growth=0,fireGrowth=0,dying=0,cam=0,roomSerial=0,deathSpot=null,warpTarget=null;
  let entranceSequence=null;
  let fault=null,roomBounds={minY:0,focusY:100};
  function assertHealthy(){if(fault)throw fault;}
  // Native hooks may own external state, so a failed commit cannot honestly
  // be rolled back. Stop this instance rather than save or replay partial rewards.
  function mutate(action){assertHealthy();try{return action();}catch(error){fault=error instanceof Error?error:new Error(String(error));throw fault;}}
  function restoreEquipment(data){
    restoreActorEquipment(character.heroId,actorPort,p,data);
    actorPort?.reconcileBody?.(p,actorWorld(),{});
  }
  let checkpoint={roomId,spawnId:plan.stage.entrySpawn},pendingActorDamage=null,sceneDeathCarry=null,respawnNative=null,contactFrame=null;const roomStates=new Map(),expandedWidths=new Map(),branches=createBreachRoutes(plan.stage.branches);
  // Authored room data is immutable for this stage; live geometry is separate.
  // Resolve source identity once instead of scanning every authored brick for
  // every live tile each frame. A new stage/editor compile gets fresh indexes.
  const sourceGeometry=new Map(visualRooms.map(room=>{const byId=new Map();for(const g of room.map.geometry)if(!byId.has(g.id))byId.set(g.id,g);return [room.roomId,byId];}));
  const originalGeometry=(id,q)=>sourceGeometry.get(id)?.get(q.sourceId||q.id)||q;
  const cannonSources=new Map(visualRooms.map(room=>[room.roomId,new Set(room.map.geometry.filter(g=>sourceType(room,g)==='Cannon').map(g=>g.id))]));
  const roomWidth=id=>Math.max(plan.rooms[id].width,expandedWidths.get(id)||0,Math.ceil(viewportWidth));
  const followCamera=(previous=cam,allowBacktracking=backtracking)=>horizontalCameraX(p.x,{width:roomWidth(roomId),viewportWidth,previous,backtracking:allowBacktracking,cameraFrames:roomBounds.cameraFrames});
  function extendRoomEdges(r,id){
    const map=plan.rooms[id],width=roomWidth(id);expandedWidths.set(id,width);
    r.viewportAdapted=true;r.geometry=r.geometry.filter(q=>!q.viewportEdge);
    if(width<=map.width)return;
    const edge=r.geometry.find(q=>!q.hidden&&q.y>=map.height-32&&q.x+q.w>=map.width&&q.collision==='solid');
    if(!edge)return;
    r.geometry.push({...edge,id:'viewport-floor',x:map.width,w:width-map.width,viewportEdge:true});
    // Underground side rooms have a closed right edge; extending it as masonry
    // makes the boundary visible without stretching the authored pipe artwork.
    if(/Underworld/.test(visualRooms.find(v=>v.roomId===id)?.setting||''))r.geometry.push({id:'viewport-wall',x:map.width,y:32,w:width-map.width,h:edge.y-32,collision:'solid',material:'brick',viewportEdge:true});
  }
  const character=plan.character,bill=character.bindings?.motion==='bill',mario=character.bindings?.motion==='mario';
  const alive=e=>retainEnemy(e,enemyDefinition);
  const classicEnemy=e=>{const spec=enemyDefinition(e);return spec.owner==='stage'&&spec.origin==='mario';};
  const enemyHandlers=bindEnemyHandlers({definition:enemyDefinition,owners:{
    stage:{hurt:damageStageEnemy,defeat:(e,event)=>performEnemyDefeat(stateFor(roomId),e,event.flat)},
    'foe-port':{hurt:enemyPort?.hurt?((e,amount,event)=>enemyPort.hurt(e,amount,event,actorWorld())):undefined,
      defeat:enemyPort?.death?((e,event)=>performEnemyDefeat(stateFor(roomId),e,event.flat,event)):undefined},
    [character.heroId]:{hurt:actorPort?.damageEnemy?((e,amount,event)=>actorPort.damageEnemy(p,e,amount,event,actorWorld())):undefined,
      defeat:actorPort?.defeatEnemy?((e,event)=>actorPort.defeatEnemy(p,e,actorWorld(),event)):undefined},
  }});
  const enemyContacts=createEnemyContactSystem({definition:enemyDefinition,
    defeat:(e,event)=>enemyHandlers.defeat(e,event),
    award:points=>{score+=points;},emit});
  function enemyBackground(e){
    if(enemyPort?.background==null)return null;
    if(typeof enemyPort.background!=='function')throw new TypeError('Invalid enemy background port');
    const q=enemyPort.background(e);if(q==null)return null;
    if(typeof q?.then==='function'){Promise.resolve(q).catch(()=>{});throw new TypeError('Enemy background must be synchronous');}
    if(q.id!==e.id||typeof q.id!=='string'||!['x','y','w','h'].every(k=>Number.isFinite(q[k]))||q.w<=0||q.h<=0||enemyDefinition(q).owner!=='foe-port'||typeof enemyPort.drawBackground!=='function')throw new TypeError('Invalid enemy background projection');
    return copy(q);
  }
  function collectEnemyBackgrounds(r){
    for(const e of r.enemies){const q=enemyBackground(e);if(q&&!r.backgrounds.some(b=>b.id===q.id))r.backgrounds.push(q);}
  }
  const movementSolids=r=>r.movementBlockers.size?[...r.geometry,...[...r.movementBlockers.values()].flat()]:r.geometry;
  function actorWorld(){const r=stateFor(roomId),map=plan.rooms[roomId];return {roomId,mainline:!sceneHealth,bottomExit:map.objects.some(o=>o.id==='sky-return'),waterTravel:character.access.waterTravel,minY:roomBounds.minY,flightMinY:roomBounds.minY,cameraY:verticalCameraY(p.y,{...roomBounds,height:map.height}),nativeEnemiesOnly:!!plan.stage.nativeEnemiesOnly,entryRoom:roomId===plan.stage.entryRoom,levelId:plan.stage.id,levelLabel,width:roomWidth(roomId),height:map.height,viewportWidth:Math.min(viewportWidth,roomWidth(roomId)),objects:map.objects,underwater:visualRooms.find(v=>v.roomId===roomId)?.underwater===true,setting:visualRooms.find(v=>v.roomId===roomId)?.setting||'',placementGeometry:map.geometry,solids:movementSolids(r),enemies:r.enemies,shots:r.shots,items:r.items,effects:r.effects,tick,camera:cam,
    enemyDefinition:e=>enemyDefinition(e),
    get hurtbox(){return readActorHurtbox(actorPort,p,{mainline:!sceneHealth});},
    claimPlacement(owner,id){
      if(!/^[a-z0-9-]+$/.test(owner)||typeof id!=='string'||!id||id.length>128)throw new TypeError('Invalid room placement identity');
      const key=owner+':'+id;if(r.placements.has(key))return false;r.placements.add(key);return true;
    },
    replaceEnemy(original,replacement){
      const index=r.enemies.indexOf(original);if(index<0||original.dead||!replacement||r.enemies.some(e=>e.id===replacement.id))throw new TypeError('Invalid enemy replacement');
      enemyHandlers.validate(replacement);
      if(replacement.nativeOwner!=='foe-port'||replacement.kind==='native-supply')throw new TypeError('Replacement requires its own enemy contract');
      r.enemies.splice(index,1,replacement);return true;
    },
    setMovementBlockers(owner,rows){
      if(owner!==character.heroId||!Array.isArray(rows)||rows.length>128)throw new TypeError('Invalid movement geometry owner');
      const ids=new Set(),boxes=rows.map(b=>{
        if(typeof b.id!=='string'||!b.id.startsWith(owner+':')||ids.has(b.id)||![b.x,b.y,b.w,b.h].every(Number.isFinite)||b.w<=0||b.h<=0)throw new TypeError('Invalid movement blocker');
        ids.add(b.id);return Object.freeze({id:b.id,x:b.x,y:b.y,w:b.w,h:b.h,collision:'solid'});
      });
      r.movementBlockers.set(owner,boxes);return true;
    },
    kill(e,event={}){if(event.cause!==undefined&&(typeof event.cause!=='string'||!event.cause.trim()))throw new TypeError('Enemy defeat cause is required');return enemyContacts.kill(e,{cause:event.cause||'attack',tick,attackWeapon:event.attackWeapon});},
    enemyEffect(effect){return applyEnemyEffect(r,effect,{tick,camera:cam,width:viewportWidth,height:map.height,definition:enemyDefinition,kill:e=>enemyContacts.kill(e,{cause:'powerup',tick})});},
    damageEnemy(e,amount,hit={}){
      if(!canHitEnemy(e)||!(amount>0))return false;
      const {spec}=enemyHandlers.validate(e),key=hit.id;
      if(key){e.hitIds??=[];if(e.hitIds.includes(key))return false;e.hitIds.push(key);}
      const accepted=enemyHandlers.hurt(e,amount,hit);
      if(!accepted){if(key)e.hitIds=e.hitIds.filter(id=>id!==key);return false;}
      if(spec.owner==='foe-port'&&e.hp<=0)enemyContacts.kill(e,{cause:hit.kind||'attack',tick,attackWeapon:hit.weapon});
      return true;
    },
    moveEnemy:(e,dx,dy)=>moveEnemyBody(e,dx,dy,movementSolids(r)),
    projectile(shot,from,to,{kind='projectile',damage=1,radius=1,breaksBricks=false,terrainImpact=null}={}){
      if(shot.impact)return shot.impact;
      const hit=firstProjectileContact(from,to,{geometry:r.geometry,enemies:r.enemies,radius,canHitHidden:g=>terrainImpact?.revealsHidden===true&&g.material==='block'&&terrainImpactAllows(terrainImpact,character.heroId,'block'),canHit:e=>canHitEnemy(e)&&!enemyDefinition(e).hurt.ignoredAttacks?.includes(kind),box:contactBox});
      if(!hit)return null;
      const id=shot.attackInstanceId??=roomId+'-projectile-'+tick+'-'+(++projectileSerial);
      shot.impact={id,kind:hit.kind,targetId:hit.entity.id,x:hit.x,y:hit.y,tick};
      if(hit.kind==='world'){if(breaksBricks||terrainImpact)breakBlock(r,hit.entity.id,{kind,x:hit.x,y:hit.y,terrainImpact,attackInstanceId:id});}
      else actorWorld().damageEnemy(hit.entity,damage,{id,kind});
      emit('projectile-impact',shot.impact);return shot.impact;
    },
    coins:roomCoins(r,map).filter(o=>!r.taken.has(o.id)),collectObjectCoin(id){if(r.taken.has(id)||!roomCoins(r,map).some(o=>o.id===id))return false;r.taken.add(id);collectCoin();return true;},
    breakBlock:(id,attack)=>breakBlock(r,id,attack),
    classicContact(e,context){return classicStomp(r,e,context.descending,context.oldBottom,context.oldEnemyTop);},
    enemyContact:(e,source={})=>resolveActorContact(e,source),
    // Borrowed native controllers use the same declared contact rules. Defer
    // hurt until their movement callback returns, preserving scope ownership.
    contactEnemy:(e,context)=>resolvePlayerContact(r,e,context,true),
    contactGrace(frames){if(Number.isInteger(frames)&&frames>0&&frames<=120){invulnerable=Math.max(invulnerable,frames);p.invuln=Math.max(p.invuln||0,invulnerable);}},
    reportObjective(id,value){if(typeof id!=='string'||!(/^[a-z][a-z0-9-]{0,63}$/).test(id)||!Number.isSafeInteger(value)||value<0)throw TypeError('Invalid objective progress');emit('objective',{id,value});},
    damage(source){if(source?.enemy&&resolveActorContact(source.enemy,source))return;if(!invulnerable&&!p.star&&!dying)pendingActorDamage??={source};},addScore:n=>{score+=n;},collectCoin,removeSolid(id){r.geometry=r.geometry.filter(g=>g.id!==id);},
    bump(id,force=false){const power=p.power;if(force)p.power=Math.max(1,power||0);bump(r,id);p.power=power;}};}
  function actorStatus(status){if(unifiedHealth&&!sceneHealth&&readActorUpgrade(actorPort,p))p.protection=1;if(status){if(!unifiedHealth&&!sceneHealth){health=status.hp??health;p.hp=health;}if(status.dead&&!dying)respawn();}if(sceneHealth)p.hp=health;if(pendingActorDamage){const {source}=pendingActorDamage;pendingActorDamage=null;hurt(source);}}
  function resolveActorContact(e,source={}){
    if(e&&enemyDefinition(e).contact.body==='none')return true;
    if(!e||!actorPort?.enemyContact)return false;
    const prior=contactFrame?.tick===tick?contactFrame:null,old=prior?.enemies.get(e);
    const context={tick,oldBottom:prior?.body.bottom??p.y+p.h-p.vy,
      oldEnemyTop:old?.y??source.oldEnemyTop??e.y,descending:p.vy>0,
      contactBox:source.contactBox||contactBox(e),definition:enemyDefinition(e)};
    return resolveActorEnemyContact(actorPort,p,e,context,actorWorld());
  }
  const seenSecrets=new Set(secretIds),challengeResults=new Set();let paused=false,pendingSecretReturn=null,activeSecret=null;
  const secretRoutes=plan.stage.secret?.entries|| (plan.stage.secret?[plan.stage.secret]:[]);
  const restorableSecretRoutes=[...secretRoutes,...(plan.stage.secret?.legacyEntries||[])];
  const routeFields=['sourceRoom','portalId','targetRoom','targetSpawn','returnRoom','returnSpawn'];
  function secretAt(id,spawn,sourceRoom,portalId){
    const route=secretRoutes.find(q=>q.targetRoom===id&&q.targetSpawn===spawn&&(!q.sourceRoom||q.sourceRoom===sourceRoom)&&(!portalId||!q.portalId||q.portalId===portalId));
    if(!route)return null;
    const {entries,legacyEntries,...definition}=plan.stage.secret;
    return {...definition,...route};
  }
  let stompChain=0,dropBag=[],supplyOrdinal=0,challengeRetry=null,challengeRetryCarry=null,projectileSerial=0;
  function nextWeapon(){if(!dropBag.length)dropBag=['M','S','F','L'].filter(w=>w!==p.weapon);return dropBag.shift();}
  function chainReward(r,e,index,values,cause='stomp'){const points=values[index];if(points===undefined){lives++;emit('extra-life',{reason:cause,entityId:e.id,lives});emit('sound',{event:'life'});}else score+=points;r.effects.push({kind:'score-pop',text:points===undefined?'1UP':String(points),x:e.x,y:e.y-8,w:24,h:8,vx:0,vy:-.4,flat:true,life:48,age:0});}

  function geometryFor(id){const room=visualRooms.find(r=>r.roomId===id);let result=[];
   for(const g of copy(plan.rooms[id].geometry)){const original=originalGeometry(id,g),type=room?sourceType(room,original):null;
    if(['Brick','Block'].includes(type)&&g.w%16===0&&g.h%16===0){for(let y=g.y;y<g.y+g.h;y+=16)for(let x=g.x;x<g.x+g.w;x+=16)result.push({...g,x,y,w:16,h:16,sourceId:g.id,id:g.w===16&&g.h===16?g.id:g.id+'@'+x+','+y,material:type==='Brick'?'brick':'block'});}else result.push({...g,falling:fallingPlatform(room,g),material:original.material||(type==='Springboard'?'spring':type==='Pipe'?'pipe':type==='PipeHorizontal'?'pipe-side':g.material),...(type==='CastleBridge'?{h:Math.min(16,g.h)}:{})});
   }
   for(const m of room?.markers||[])if(m.kind==='hidden-block'&&!result.some(q=>q.x===m.x&&q.y===m.y&&q.w===16))result.push({id:m.id,sourceId:m.id,x:m.x,y:m.y,w:16,h:16,collision:'solid',material:'block',hidden:true});
   for(const m of room?.markers||[])if(m.kind==='platform-generator')result.push(...elevatorPlatforms(m,plan.rooms[id].height));
   return result.map(q=>({...q,dir:1,dx:0,dy:0,content:sourceGeometry.get(id)?.get(q.sourceId||q.id)?.reward||room?.markers?.find(m=>m.x===q.x&&m.y===q.y&&/contents|hidden/.test(m.kind))?.source?.contents||room?.semantics?.find(m=>m.id===(q.sourceId||q.id))?.source?.contents||null}));
  }
  function stateFor(id){
    if(!roomStates.has(id)){
      const room=visualRooms.find(r=>r.roomId===id),geometry=geometryFor(id);
      let pipes=null;
      const enemies=plan.rooms[id].objects.filter(q=>q.kind==='walker').map(q=>{
        const marker=room?.markers?.find(m=>m.id===q.id),type=room?.enemySkins?.[q.id]||marker?.kind||'walker';
        const pipe=/piranha/i.test(type)?(pipes??=geometry.filter(g=>{const original=originalGeometry(id,g);return g.material==='pipe'||sourceType(room||{},original)==='Pipe';})).filter(g=>q.x+q.w>g.x&&q.x<g.x+g.w&&Math.abs(q.y-g.y)<80).sort((a,b)=>Math.abs(a.y-q.y)-Math.abs(b.y-q.y))[0]:null;
        const enemy={...q,...(pipe?{x:pipe.x+(pipe.w-q.w)/2,y:pipe.y,clipTop:pipe.y}:{}),type,source:marker?.source,vx:-.5,vy:0,hp:2,...(isCastleBoss({type})?castleBossHealth(character.bossDamageUnit):{}),homeX:pipe?pipe.x+(pipe.w-q.w)/2:q.x,homeY:pipe?pipe.y-q.h:q.y,dead:false};
        initializeClassicKoopaMotion(enemy,room);return enemy;
      });
      roomStates.set(id,{geometry,placements:new Set(),movementBlockers:new Map(),backgrounds:[],effects:[],shots:[],vines:[],items:[],taken:new Set(),hiddenMarkers:(room?.markers||[]).filter(m=>m.kind==='platform-generator').map(m=>m.id),enemies});
    }
    const result=roomStates.get(id);if(!result.viewportAdapted)extendRoomEdges(result,id);return result;
  }
  const contactBox=e=>e.clipTop==null?e:{...e,h:Math.max(0,Math.min(e.h,e.clipTop-e.y))};
  const touches=(a,e)=>{const b=contactBox(e);return b.h>0&&motor.overlap(a,b);};
  function enter(...args){return mutate(()=>enterRoom(...args));}
  function enterRoom(id,spawn,discover=true,portalId=null){
    branches.cancelClip();
    const secret=secretAt(id,spawn,roomId,portalId);
    const discovered=allowSecretDiscovery&&discover&&secret&&id===secret.targetRoom&&spawn===secret.targetSpawn&&!seenSecrets.has(secret.id);
    const o=plan.rooms[id]?.objects.find(q=>q.kind==='spawn'&&q.id===spawn);if(!o)throw Error('Spawn missing');
    const readEquipment=actorPort?.carry||actorPort?.snapshot;
    const equipment=p&&readEquipment?copyActorEquipment(character.heroId,readEquipment.call(actorPort,p)):null;
    const form=p?{power:p.power,protection:p.protection||0,star:p.star,weapon:p.weapon,challengeEquipment:p.challengeEquipment?copy(p.challengeEquipment):undefined}:null;
    roomId=id;roomSerial++;stompChain=0;entranceSequence=beginEntranceSequence(plan,id,spawn);
    const policy=plan.stage.roomPolicies?.[id];if(policy){checkpoint={roomId:id,spawnId:policy.entryCheckpoint};emit('checkpoint',{...checkpoint});}roomBounds={minY:0,focusY:100};stateFor(id);p=(actorPort||motor).create(character,o);p.mainlineMotion=validateMainlineAccess(character).travel==='jump'?MAINLINE_JUMP:null;p.y=o.y+(o.h||14)-p.h;
    p.protection=0;pendingActorDamage=null;if(form)Object.assign(p,form);if(bill)p.weapon=form?.weapon||'N';
    if(mario&&p.power){p.y+=p.h-28;p.h=28;}
    portalLock=24;prev={};cam=followCamera(0,true);emit('room',{roomId});
    actorPort?.prepareRoom?.(actorWorld());
    roomBounds=readActorRoomBounds(actorPort,character.access);
    cam=followCamera(0,true);
    // A room owns a fresh body. Equipment belongs to the actor, including
    // upgrades just received in a hidden scene; legacy closure retention is
    // not a transfer contract. Death explicitly clears p before this entry.
    if(equipment)restoreEquipment(equipment);else actorPort?.reconcileBody?.(p,actorWorld(),{});
    enemyPort?.prepare?.(actorWorld());collectEnemyBackgrounds(stateFor(roomId));
    for(const e of stateFor(id).enemies)enemyHandlers.validate(e);
    health=p.hp??health;
    if(discovered){activeSecret=copy(secret);seenSecrets.add(secret.id);pendingSecretReturn=secret.returnRoom&&secret.returnSpawn?{roomId:secret.returnRoom,spawnId:secret.returnSpawn}:null;emit('secret',{...secret});}
  }
  function arriveThroughPortal(id,spawn,discover=true,portalId=null,resetRoom=false){
    const fromRoom=roomId;
    if(resetRoom)roomStates.delete(id);
    enter(id,spawn,discover,portalId);
    if(resetRoom&&fromRoom===id&&portalId)emit('room-loop',{roomId:fromRoom,targetRoom:id,portalId});
    const r=stateFor(roomId),pipe=r.geometry.filter(g=>g.material==='pipe'&&p.x+p.w/2>=g.x&&p.x+p.w/2<=g.x+g.w&&Math.abs(p.y+p.h-g.y)<80).sort((a,b)=>Math.abs(p.y+p.h-a.y)-Math.abs(p.y+p.h-b.y))[0];
    if(pipe){
      for(const e of r.enemies)if(/piranha/i.test(e.type)&&e.clipTop===pipe.y&&e.x+e.w>pipe.x&&e.x<pipe.x+pipe.w){e.age=0;e.y=e.clipTop;}
      p.x=pipe.x+(pipe.w-p.w)/2;p.y=pipe.y+2;p.vx=p.vy=0;p.crouch=false;p.grounded=true;
      transition={phase:'exit',age:0,clipTop:pipe.y,targetY:pipe.y-p.h};emit('sound',{event:'portal'});
    }else{transition=null;p.grounded=false;}
  }
  function returnFromChallenge(){
    if(!pendingSecretReturn)return;
    const target=pendingSecretReturn;pendingSecretReturn=null;
    // Returning never discovers another challenge, even if room metadata changes.
    arriveThroughPortal(target.roomId,target.spawnId,false);p.hp=health;
    checkpoint={...target};activeSecret=null;emit('checkpoint',{...checkpoint});
  }
  function classicStomp(r,e,descending,oldBottom,oldY){
    const rule=enemyDefinition(e).contact.stomp;
    if(e.safe||!descending||oldBottom>oldY+7||!['flatten','shell'].includes(rule))return false;
    let contactSound='stomp';
    if(rule==='shell'){
      if(removeClassicKoopaWings(e)){}
      else if(!e.shell){e.walkHeight=e.h;e.shellAge=0;e.shell=true;e.y+=e.h-16;e.h=16;e.vx=0;e.source={...e.source,jumping:false};}
      else if(Math.abs(e.vx)>1){e.vx=0;e.shellAge=0;e.frame='';}
      else{e.vx=(p.x<e.x?1:-1)*3.2;e.safe=12;contactSound='kick';}
    }else killEnemy(r,e,true);
    p.y=Math.min(p.y,e.y-p.h);p.vy=-4.1333333;p.jumpG=.125;p.fallG=.4375;p.grounded=false;
    chainReward(r,e,stompChain++,[100,200,400,500,800,1000,2000,4000,5000,8000],rule==='shell'?'shell-stomp':'stomp');emit('sound',{event:contactSound});return true;
  }
  function resolvePlayerContact(r,e,context,deferDamage=false){
    if(e.dead||enemyDefinition(e).contact.body==='none')return;
    if(p.star){enemyContacts.kill(e,{cause:'star',tick});return;}
    if(e.safe)return;
    if(resolveActorContact(e,context))return;
    if(classicStomp(r,e,context.descending,context.oldBottom,context.oldEnemyTop))return;
    const spec=enemyDefinition(e);
    if(!actorPort&&spec.origin!=='mario'&&p.motionId==='sonic'&&(p.rolling||!p.grounded)&&spec.contact.stomp==='source'){
      killEnemy(r,e);score+=100;if(!p.grounded)p.vy=-3;return;
    }
    if(classicEnemy(e)&&e.shell&&Math.abs(e.vx)<1){e.vx=(p.x<e.x?1:-1)*3.2;e.safe=14;emit('sound',{event:'kick'});return;}
    if(deferDamage){if(!invulnerable&&!p.star&&!dying)pendingActorDamage??={source:{enemy:e}};}
    else hurt(e);
  }
  function collectCoin(){coins++;score+=200;emit('coin-collected',{value:1});actorPort?.coin?.(p);emit('sound',{event:'pickup'});if(coins>=100){coins-=100;lives++;emit('sound',{event:'life'});}}
  let skipDeathPresentation=false;
  function respawn(terrain=false,source=null,presentationComplete=false){if(dying||completed)return;pendingSecretReturn=null;skipDeathPresentation=presentationComplete;deathSpot={roomId,x:p.x,y:p.y,power:p.power||0,terrain};
    if(terrain&&!source&&p.descendingRide?.roomId===roomId&&tick-p.descendingRide.tick<=120)source={kind:'falling-platform',platformId:p.descendingRide.id};
    // A native challenge retries its owned equipment. Death presentation may
    // clear shields/poses/projectiles, but cannot rewrite that transfer record.
    if(sceneHealth&&actorPort)sceneDeathCarry=actorPort.carry(p);
    if(!sceneHealth)respawnNative=readRespawnEquipment(character.heroId,actorPort,p);
    const hit=source?.enemy||source;
    // Contact, defeat and death facts share the registered enemy identity.
    // Legacy native records obtain it through their existing resolver; a
    // generic native damage cue is not an enemy and has no such identity.
    const hitDefinition=hit&&(source?.enemy||Object.hasOwn(hit,'contractId')||stateFor(roomId).enemies.includes(hit))?enemyDefinition(hit):null;
    const deathCause=hitDefinition||hit?.type?{kind:'enemy-contact',entityId:hit.id||null,contract:hitDefinition?.id||null,fromAbove:(hit.vy||0)>0&&hit.y+hit.h<=p.y+8}:hit?.kind==='falling-platform'?{kind:'falling-platform',platformId:hit.platformId}:null;
    if(lifeOwner==='stage')lives--;if(bill)p.weapon='N';dying=1;p.dying=true;p.star=0;p.vx=0;p.vy=-5.1;if(!presentationComplete)actorPort?.beginDeath?.(p,actorWorld());emit('death',{lives,cause:deathCause});if(!presentationComplete)emit('sound',{event:'death'});}
  function roomCoins(r,map){return r.coins??=map.objects.filter(o=>o.kind==='coin').map(copy);}
  function roomObjects(r,map){return map.objects.map(o=>o.kind==='coin'?roomCoins(r,map).find(c=>c.id===o.id):o);}
  function killEnemy(r,e,flat=false,cause=flat?'stomp':'attack'){return enemyContacts.kill(e,{cause,flat,tick,score:false});}
  function damageStageEnemy(e,amount,hit){if(isCastleBoss(e)){if(!damageCastleBoss(e,amount,{...hit,tick}))return false;emit('sound',{event:'kick'});}else e.hp=(e.hp??2)-amount;if(e.hp<=0)enemyContacts.kill(e,{cause:hit.kind||'attack',tick,attackWeapon:hit.weapon});return true;}
  function performEnemyDefeat(r,e,flat=false,event={}){if(e.dead)return false;
    const spec=enemyDefinition(e);
    if(spec.owner==='foe-port'){
      const effect=enemyPort?.death?.(e,tick,event);
      if(!effect||typeof effect!=='object'||typeof effect.then==='function'||
        typeof effect.kind!=='string'||!effect.kind.trim()||typeof effect.flat!=='boolean'||
        !Number.isFinite(effect.life)||effect.life<=0||!Number.isFinite(effect.vx)||!Number.isFinite(effect.vy)||
        ['x','y','w','h'].some(key=>effect[key]!==undefined&&!Number.isFinite(effect[key])))
        throw new TypeError('Enemy death owner refused or returned invalid effect: '+spec.id);
      e.dead=true;
      r.effects.push({...e,...effect,contractId:spec.id,nativeOwner:spec.owner,clipTop:undefined,age:0});
      return true;
    }
    if(!classicEnemy(e))throw new TypeError('Enemy death owner is not installed: '+spec.id);
    if(isCastleBoss(e))r.castleBossDefeated=true;
    if(/^(enemy-|marker-)?lakitu$/i.test(e.type)&&!r.lakituStopped)r.lakituRespawn={ticks:960,enemy:copy(e)};
    e.dead=true;
    const reveal=isCastleBoss(e)&&e.source?.spawnType!=='Bowser'?{type:e.source?.spawnType||'Goomba',w:16,h:16,x:e.x+(e.w-16)/2,y:e.y+e.h-16,source:e.source?.spawnSettings||{}}:{};
    r.effects.push({...e,...reveal,kind:'enemy-death',clipTop:undefined,flat:flat&&/goomba|walker/i.test(e.type),vx:flat?0:(e.vx||.8),vy:flat?0:-3,life:flat?24:80,age:0});
    if(!flat&&e.x+e.w>=cam&&e.x<=cam+viewportWidth&&e.y+e.h>=0&&e.y<=plan.rooms[roomId].height)emit('sound',{event:'classic-enemy-defeat',origin:'mario'});return true;
  }
  function breakBlock(r,id,attack={}){
    if(['x','y'].some(axis=>attack[axis]!==undefined&&!Number.isFinite(attack[axis])))throw new TypeError('Non-finite terrain impact position');
    const q=r.geometry.find(g=>g.id===id),room=visualRooms.find(r=>r.roomId===roomId);
    if(!q||!room||q.viewportEdge)return false;
    if(q.hidden&&attack.terrainImpact?.revealsHidden!==true)return false;
    const type=sourceType(room,originalGeometry(roomId,q));
    const material=({Brick:'brick',Block:'block',Stone:'stone',Steel:'steel'})[type]||q.material;
    // Existing brick-only callers retain their source semantics. All new
    // material-specific weapons (including the Tank port) use this declaration.
    if(attack.terrainImpact!=null&&!terrainImpactAllows(attack.terrainImpact,character.heroId,material))return false;
    if(['Brick','Block'].includes(type)){const power=p.power;p.power=Math.max(1,power||0);r.breakAttackId=attack.attackInstanceId||null;try{bump(r,id);}finally{p.power=power;r.breakAttackId=null;}return true;}
    if(!attack.terrainImpact||!['stone','steel'].includes(material))return false;
    const x=q.x+Math.max(0,Math.min(Math.ceil(q.w/16)-1,Math.floor(((attack.x??q.x)-q.x)/16)))*16;
    const y=q.y+Math.max(0,Math.min(Math.ceil(q.h/16)-1,Math.floor(((attack.y??q.y)-q.y)/16)))*16;
    const w=Math.min(16,q.x+q.w-x),h=Math.min(16,q.y+q.h-y);
    const pieces=[{x:q.x,y:q.y,w:q.w,h:y-q.y},{x:q.x,y:y+h,w:q.w,h:q.y+q.h-y-h},{x:q.x,y,w:x-q.x,h},{x:x+w,y,w:q.x+q.w-x-w,h}].filter(a=>a.w>0&&a.h>0);
    r.geometry=r.geometry.filter(g=>g!==q);for(const [i,a]of pieces.entries())r.geometry.push({...q,...a,sourceId:q.sourceId||q.id,id:q.id+'~'+tick+'-'+i});
    for(let i=0;i<4;i++)r.effects.push({kind:'brick-debris',x:x+(i%2)*8,y:y+Math.floor(i/2)*8,w:8,h:8,sx:(i%2)*8,sy:Math.floor(i/2)*8,vx:i%2?1.4:-1.4,vy:i<2?-3.8:-2.5,life:40,age:0});
    score+=50;emit('sound',{event:'break'});return true;
  }
  function hurt(source){
    if(invulnerable||p.star||completed||dying)return;
    if(actorPort?.blocksDamage?.(p,source,actorWorld()))return;
    if(sceneHealth){
      if(sceneHealth.health==='protection'){
        if(p.protection>0){
          p.protection=0;actorPort?.hurt?.(p,source,actorWorld(),{shielded:true});
          health=1;p.hp=health;invulnerable=120;p.invuln=120;emit('sound',{event:'hurt'});
        }else{health=0;p.hp=0;respawn(false,source);}
        return;
      }
      const feedback=actorPort?.hurtNative?.(p,source,actorWorld())||{};
      const cause=source?.enemy||source;
      const sourceDamage=sceneHealth.health==='native'&&cause&&Object.hasOwn(cause,'contractId')?enemyDefinition(cause).contact.healthDamage:undefined;
      health=sceneHealth.health==='rings'?(feedback.absorbed?1:0):Math.max(0,health-(sourceDamage??sceneHealth.contactDamage??1));
      p.hp=health;invulnerable=90;p.invuln=90;
      if(health<=0)respawn(false,source);return;
    }
    if(unifiedHealth){
      if(mario?p.power>0:p.protection>0||readActorUpgrade(actorPort,p)){
        p.protection=0;
        if(mario){p.power=0;p.y+=p.h-character.motion.height;p.h=character.motion.height;shrink=24;}
        else downgradeMainlineActor(actorPort,p,actorWorld());
        invulnerable=120;p.invuln=120;p.mainlineHurtUntil=tick+120;emit('player-downgraded',{hero:character.heroId,tick});emit('sound',{event:'mainline-powerdown'});
      }else respawn(false,source);
      return;
    }
    if(actorPort){actorStatus(actorPort.hurt(p,source,actorWorld()));return;}
    if(mario&&p.power){p.power=0;p.y+=p.h-character.motion.height;p.h=character.motion.height;invulnerable=120;shrink=24;emit('sound',{event:'hurt'});return;}
    health--;p.hp=health;invulnerable=90;if(!mario&&p.power)p.power--;
    if(health<=0)respawn(false,source);else emit('sound',{event:'hurt'});
  }
  function takeItem(item,r=stateFor(roomId)){
    if(item.dead)return false;
    const previousWeapon=p.weapon;
    if(item.kind==='life')lives++;
    else if(item.kind==='star')p.star=600;
    else if(actorPort){
      const result=actorPort.pickup?.(p,item,actorWorld());
      if(!(typeof result==='object'?result?.accepted:result))return false;
      if(unifiedHealth||sceneHealth){p.protection=1;if(sceneHealth?.health==='protection'){health=2;p.hp=health;}}else health=p.hp;
    }else if(bill){p.weapon=item.weapon||'M';score+=1000;invulnerable=Math.max(invulnerable,45);r.effects.push({kind:'score-pop',text:weaponNames[p.weapon],x:p.x-10,y:p.y-8,w:70,h:8,vx:0,vy:-.2,flat:true,life:90,age:0});}
    else if(mario){if(!p.power){p.y+=p.h-28;p.h=28;growth=24;}else if(item.kind==='flower'&&p.power===1)fireGrowth=24;p.power=item.kind==='flower'&&p.power>0?2:Math.max(1,p.power);}
    else{p.power=Math.min(3,(p.power||0)+1);health=Math.min(character.motion.maxHealth,health+1);p.hp=health;}
    item.dead=true;
    emit('item-collected',{entityId:item.id??null,kind:item.kind,previousWeapon,weapon:p.weapon,...(item.nativeType?{nativeType:item.nativeType}:{}),...(item.nativeKind?{nativeKind:item.nativeKind}:{})});
    if(item.rewardSource)emit('block-reward-collected',{...item.rewardSource,collected:true,kind:item.kind});
    emit('sound',{event:item.kind==='life'?'life':item.kind==='star'?'classic-star':'powerup'});return true;
  }
  const savedCheckpoint=initialState?.checkpoint;
  if(savedCheckpoint?.levelId===plan.stage.id){
    const secret=plan.stage.secret;
    const points=[...(plan.stage.checkpoints||[]),...(secret&&seenSecrets.has(secret.id)?restorableSecretRoutes.map(q=>({roomId:q.returnRoom,spawnId:q.returnSpawn})):[])];
    const known=points.find(c=>c.roomId===savedCheckpoint.roomId&&c.spawnId===savedCheckpoint.spawnId);
    if(known)checkpoint={roomId:known.roomId,spawnId:known.spawnId};
  }
  const savedChallenge=initialState?.challenge,secret=plan.stage.secret;
  if(savedChallenge&&(!secret||savedChallenge.id!==secret.id||savedChallenge.driver!==secret.driver))throw new TypeError('Unregistered saved challenge');
  if(savedChallenge){
    const route=savedChallenge.route?restorableSecretRoutes.find(q=>routeFields.every(k=>q[k]===savedChallenge.route[k])):secret;
    if(!route)throw new TypeError('Unregistered saved challenge route');
    const {entries,legacyEntries,...definition}=secret;activeSecret={...definition,...route};seenSecrets.add(secret.id);
  }
  enter(savedChallenge?activeSecret.targetRoom:checkpoint.roomId,savedChallenge?activeSecret.targetSpawn:checkpoint.spawnId,false);
  if(initialState){
    if(!Number.isInteger(initialState.lives)||initialState.lives<1)throw Error('Cannot start a campaign stage with no lives');
    lives=initialState.lives;coins=initialState.coins||0;score=initialState.score||0;
    p.power=bill?0:Math.max(0,Math.min(mario?2:3,initialState.power||0));
    p.protection=initialState.protection??Number(!mario&&p.power>0);
    if(initialState.hero===character.heroId&&initialState.weapon&&(!bill||Object.hasOwn(weaponNames,initialState.weapon)))p.weapon=initialState.weapon;
    if(mario&&p.power){p.y+=p.h-28;p.h=28;}
    if(actorPort&&initialState.hero===character.heroId&&initialState.native){
      mutate(()=>restoreEquipment(initialState.native));health=p.hp;
    }
  }
  // A persisted fixed landing reconstructs live foes as well as the body.
  // Continue receives the same short contact grace as an in-session respawn.
  if(savedCheckpoint&&checkpoint.roomId===savedCheckpoint.roomId&&checkpoint.spawnId===savedCheckpoint.spawnId&&!savedChallenge){invulnerable=90;p.invuln=Math.max(p.invuln||0,90);}
  if(savedChallenge){pendingSecretReturn={roomId:activeSecret.returnRoom,spawnId:activeSecret.returnSpawn};emit('secret',{...activeSecret,resume:true,retry:savedChallenge.phase==='retry'});}
  if(sceneHealth){
    if(sceneHealth.health==='protection'){
      if(![0,1].includes(p.protection))throw new TypeError('Invalid scene protection');
      health=1+p.protection;
    }else health=sceneHealth.health==='rings'?1:nativeSceneHealth(sceneHealth,initialState?.native?.nativeVitals).hp;
    p.hp=health;p.mainlineMotion=null;
  }
  function bump(r,id){
    const q=r.geometry.find(g=>g.id===id),room=visualRooms.find(r=>r.roomId===roomId);if(!q||!room)return;
    const type=sourceType(room,originalGeometry(roomId,q));if(!['Brick','Block'].includes(type))return;
    if(q.bump)return;
    if(q.used){emit('sound',{event:'bump'});return;}
    const marker=room.markers?.find(m=>m.x===q.x&&m.y===q.y&&/contents|hidden/.test(m.kind));
    const semantic=room.semantics?.find(m=>m.id===(q.sourceId||id))?.source;
    const authored=originalGeometry(roomId,q),override=authored.reward;
    let content=override||marker?.source?.contents||semantic?.contents||(type==='Block'?'coin':null);
    if(Array.isArray(content))content=content[0];content=String(content||'').toLowerCase();
    const rewardSource=authored.rewardSource?{...authored.rewardSource,entityId:q.sourceId||q.id,content,roomId}:null;
    q.hidden=false;q.bump=12;
    emit('block-bumped',{entityId:q.sourceId||q.id});
    // A hit from below or a weapon shares the same tile-top coin contact.
    for(const coin of roomCoins(r,plan.rooms[roomId]))if(!r.taken.has(coin.id)&&coin.x+coin.w/2>=q.x&&coin.x+coin.w/2<q.x+q.w&&Math.abs(coin.y+coin.h-q.y)<=3){
      r.taken.add(coin.id);collectCoin();r.effects.push({kind:'coin-pop',x:coin.x,y:coin.y,w:coin.w,h:coin.h,vx:0,vy:-2.8,life:34,age:0});
    }

    for(const e of r.enemies)if(!e.dead&&e.x+e.w>q.x&&e.x<q.x+q.w&&Math.abs(e.y+e.h-q.y)<5)killEnemy(r,e);
    for(const item of r.items)if(!item.dead&&!item.emerge&&item.x+item.w>q.x&&item.x<q.x+q.w&&Math.abs(item.y+item.h-q.y)<5){item.vy=item.floating?0:-3;item.vx=item.stationary?0:(p.x<item.x?1:-1)*.8;}
    if(content==='vine'){
      q.used=true;const portal=plan.rooms[roomId].objects.find(o=>o.id.endsWith('-vine-portal')&&Math.abs(o.x-q.x)<2);
      if(portal)r.vines.push({x:q.x+1,y:q.y,w:14,h:0,bottom:q.y,portal});emit('sound',{event:'appear'});return;
    }
    if(content){
      if(content==='multi'||(type==='Brick'&&content==='coin')){q.remaining??=10;q.remaining--;q.used=q.remaining===0;}else q.used=true;
      if(/coin|multi/.test(content)){collectCoin();if(rewardSource)emit('block-reward-collected',{...rewardSource,collected:true,kind:'coin'});if(q.remaining===0)emit('block-reward-exhausted',{entityId:q.sourceId||q.id,content,remaining:0,rewardCount:10});r.effects.push({kind:'coin-pop',x:q.x+3,y:q.y-14,w:10,h:14,vx:0,vy:-2.8,life:34,age:0});}
      else {const kind=/life|1up/.test(content)?'life':/star/.test(content)?'star':bill?'bill-supply':p.power?'flower':'mushroom';
        const supply=!['life','star'].includes(kind)?actorPort?.supply?.(p,{content,index:supplyOrdinal},actorWorld()):null;
        const nativeItem=supply?characterSupply(character.heroId,supply):null;if(nativeItem)supplyOrdinal++;
        const descriptor=nativeItem||{kind,...(kind==='bill-supply'?{weapon:/^bill-[msfl]$/.test(content)?content.slice(-1).toUpperCase():nextWeapon()}: {})};
        const w=descriptor.w||14,h=descriptor.h||14;
        // Motion belongs to the item, not the character collecting it. Battle
        // City's equipment floats, while classic 1UPs and stars keep their physics.
        const moving=['life','star'].includes(kind)||mario&&!['flower','bill-supply'].includes(kind);
        const floating=character.bindings?.motion==='tank'&&!['life','star'].includes(kind);
        r.items.push({...descriptor,...(rewardSource?{rewardSource}:{}),x:q.x+(16-w)/2,y:q.y+1,w,h,vy:0,vx:moving?.75:0,stationary:!moving,floating,emerge:32,targetY:q.y-h,blockTop:q.y,age:0});emit('sound',{event:'appear'});}
    }else if(p.power){branches.destroyed(roomId,q);r.geometry=r.geometry.filter(g=>g.id!==id);for(let i=0;i<4;i++)r.effects.push({kind:'brick-debris',x:q.x+(i%2)*8,y:q.y+Math.floor(i/2)*8,w:8,h:8,sx:(i%2)*8,sy:Math.floor(i/2)*8,vx:i%2?1.4:-1.4,vy:i<2?-3.8:-2.5,life:40,age:0});score+=50;emit('brick-broken',{entityId:q.id,roomId,attackInstanceId:r.breakAttackId||null});emit('sound',{event:'break'});}else emit('sound',{event:'bump'});
  }
  // Boost consumes a new jump command, not the held button that controls
  // rising gravity. Ports must respect explicit false edges until release.
  function springMovementInput(input){
    if(!p.springJumpHeld)return input;
    if(!input.jump){p.springJumpHeld=false;return input;}
    return {...input,jumpPressed:false,jumpEdge:false};
  }
  // Room preparation clears actor-owned commands and transient state. Do it
  // once when scripted walking starts, then retain the same room lifecycle.
  let preparedFinishWalk=null;
  function prepareFinishWalk(){
    if(preparedFinishWalk===finish)return;
    actorPort?.prepareRoom?.(actorWorld());preparedFinishWalk=finish;
  }
  function step(raw={}){
    if(disposed||completed||paused)return;
    if(entranceSequence&&!dying&&!finish){
      // This short authored scene owns movement and time. Abilities, hidden
      // discovery, combat and controller input cannot divert its pipe route.
      const q=entranceSequence,origin={x:p.x,y:p.y};tick++;q.age++;
      p.crouch=false;p.onVine=false;p.vy=0;p.grounded=true;
      p.x=Math.min(q.mouthX-p.w,p.x+q.speed);p.y=q.feet-p.h;
      p.vx=p.x-origin.x;p.anim=(p.anim||0)+Math.abs(p.vx);
      scriptedMotionPresentation(p,'entrance-walk',1,0,actorPort,origin);
      if(p.x>=q.mouthX-p.w){
        p.vx=0;entranceSequence=null;
        transition={phase:'enter',age:0,side:true,clipTop:null,clipRight:q.mouthX,portalId:q.portalId,targetRoom:q.targetRoom,targetSpawn:q.targetSpawn};
        emit('sound',{event:'portal'});
      }
      return;
    }
    if(!dying&&!finish&&!transition&&actorPort?.consumeHitStop?.())return;
    if(actorPort&&p.bashing&&!p.springId){actorStatus(actorPort.step(p,springMovementInput(raw),actorWorld()));return;}
    if(shrink||growth||fireGrowth){tick++;if(shrink)shrink--;if(growth)growth--;if(fireGrowth)fireGrowth--;return;}
    if(transition){tick++;const q=transition,origin={x:p.x,y:p.y};q.age++;
      if(q.phase==='enter'){if(q.side)p.x+=.7;else p.y+=.8;
        p.vx=p.x-origin.x;p.vy=p.y-origin.y;scriptedMotionPresentation(p,'pipe-enter',q.side?1:0,q.side?0:1,actorPort,origin);
        if(q.age>=(q.side?40:56)){if(q.targetWorld){warpTarget=q.targetWorld;completed=true;transition=null;return;}arriveThroughPortal(q.targetRoom,q.targetSpawn,true,q.portalId,q.resetRoom);}
      }else{if(q.age>12)p.y=Math.max(q.targetY,p.y-.5);p.vx=0;p.vy=p.y-origin.y;scriptedMotionPresentation(p,'pipe-exit',0,-1,actorPort,origin);if(q.age>12&&p.y===q.targetY){transition=null;p.grounded=true;portalLock=30;}}return;
    }
    if(dying){tick++;dying++;if(!skipDeathPresentation){if(actorPort?.deathStep)actorPort.deathStep(p,dying,actorWorld());else if(dying>24){p.y+=p.vy;p.vy+=.22;}}if(dying>=105){if(manualDeath&&lives>0)return;dying=0;if(lives<=0){completed=true;emit('sound',{event:'gameover'});emit('complete',{result:'failed',coins,score});}else{roomStates.clear();branches.reset();actorPort?.reset?.();timeLeft=400;timerTicks=0;p=null;if(challengeRetry){const secret=challengeRetry;challengeRetry=null;enter(secret.targetRoom,secret.targetSpawn,false);if(challengeRetryCarry){const equipment=challengeRetryCarry;challengeRetryCarry=null;Object.assign(p,{power:equipment.power,weapon:equipment.weapon,protection:equipment.protection});restoreEquipment(equipment.native);}pendingSecretReturn={roomId:secret.returnRoom,spawnId:secret.returnSpawn};emit('secret',{...secret,retry:true});}else{enter(checkpoint.roomId,checkpoint.spawnId);if(respawnNative)restoreEquipment(respawnNative);}health=p.hp??character.motion.maxHealth;invulnerable=90;emit('respawn',{lives});}}return;}
    if(finish&&bill){p.aimX=1;p.aimY=0;p.firing=false;p.fireFrames=0;p.crouch=false;p.onVine=false;stateFor(roomId).shots.length=0;}
    if(finish?.castle){tick++;finish.age++;if(finish.rooftop)finish.rescueAge++;const r=stateFor(roomId);if(finish.phase==='rescue'){
      p.vx=p.vy=0;scriptedMotionPresentation(p,'finish-idle',1,0,actorPort);if(finish.age>=270){finish.phase='reunion';finish.age=0;}
    }else if(finish.phase==='bridge'){
      {const bridge=r.geometry.find(g=>g.id===finish.bridgeId);if(bridge){bridge.w=Math.max(0,bridge.w-4);if(!bridge.w)r.geometry=r.geometry.filter(g=>g!==bridge);}}
      if(!r.geometry.some(g=>g.id===finish.bridgeId)){finish.phase='boss-fall';finish.age=0;emit('sound',{event:'bowser_fall'});}
    }else if(finish.phase==='boss-fall'){for(const e of r.enemies)if(isCastleBoss(e)){e.vy+=.22;e.y+=e.vy;}if(finish.age>80){r.enemies=r.enemies.filter(e=>!isCastleBoss(e));finish.phase='walk';emit('sound',{event:'world_clear'});}}
    else if(finish.phase==='walk'){prepareFinishWalk();const origin={x:p.x,y:p.y};actorPort?.reconcileBody?.(p,actorWorld(),{x:p.x<finish.target?Math.max(2.75,p.vx||0):0});motor.finish(p,{x:p.x<finish.target?1:0},character,{solids:r.geometry,width:roomWidth(roomId)});scriptedMotionPresentation(p,'finish-walk',1,0,actorPort,origin);cam=followCamera(cam,false);if(p.x>=finish.target&&p.grounded){p.vx=0;finish.phase='reunion';finish.age=0;}}
    else if(finish.phase==='reunion'){scriptedMotionPresentation(p,'finish-idle',1,0,actorPort);if(finish.age>=180)finish.phase='score';}
    else if(timeLeft>0){scriptedMotionPresentation(p,'finish-idle',1,0,actorPort);const n=Math.min(4,timeLeft);timeLeft-=n;score+=50*n;}else{completed=true;emit('complete',{result:'cleared',coins,score});}return;}
    if(finish){tick++;finish.age++;if(finish.phase==='slide'){const origin={x:p.x,y:p.y};p.x=finish.poleX-p.w/2;p.y=Math.min(finish.floor-p.h,p.y+1.5);scriptedMotionPresentation(p,'flag-slide',0,1,actorPort,origin);finish.flagY=Math.min(finish.floor-16,finish.flagY+1.8);if(p.y>=finish.floor-p.h&&finish.flagY>=finish.floor-16){finish.phase='walk';p.x=finish.poleX+4;p.vy=character.access.travel==='drive'?0:-1.8;p.grounded=false;emit('sound',{event:'complete'});}}else if(finish.phase==='walk'){prepareFinishWalk();const origin={x:p.x,y:p.y};actorPort?.reconcileBody?.(p,actorWorld(),{x:Math.max(2.75,p.vx||0)});p.jumpBuffer=0;motor.finish(p,{x:1},character,{solids:stateFor(roomId).geometry,width:roomWidth(roomId)});scriptedMotionPresentation(p,'finish-walk',1,0,actorPort,origin);if(p.x>=finish.walkTarget-.001){finish.phase='score';p.vx=0;}}else if(timeLeft>0){scriptedMotionPresentation(p,'finish-idle',1,0,actorPort);const n=Math.min(4,timeLeft);timeLeft-=n;score+=n*50;}else{completed=true;emit('complete',{result:'cleared',coins,score});}return;}
    delete p.scriptedMotion;tick++;if(++timerTicks>=24){timerTicks=0;timeLeft--;if(timeLeft===100)emit('sound',{event:'hurry'});if(timeLeft<=0){respawn();timeLeft=400;return;}}if(invulnerable)invulnerable--;if(!actorPort&&p.invuln)p.invuln--;if(cooldown)cooldown--;if(attackAge)attackAge--;if(portalLock)portalLock--;
    const v={...raw,x:Math.max(-1,Math.min(1,Number(raw.x)||0)),up:!!raw.up,ability:!!raw.ability,abilityPressed:inputEdge(raw,'abilityPressed',[],()=>!!raw.ability&&!prev.ability),attack:!!raw.attack,down:!!raw.down,jump:!!raw.jump,run:!!raw.run,jumpPressed:inputEdge(raw,'jumpPressed',['jumpEdge'],()=>!!raw.jump&&!prev.jump),attackPressed:inputEdge(raw,'attackPressed',['runPressed'],()=>(!!raw.attack&&!prev.attack)||(!!raw.run&&!prev.run)),interactPressed:inputEdge(raw,'interactPressed',[],()=>!!raw.interact&&!prev.interact)};prev={...raw};
    const r=stateFor(roomId),map=plan.rooms[roomId],before=roomSerial,oldTop=p.y,oldBody={x:p.x,y:p.y,w:p.w,h:p.h,vx:p.vx,crouch:p.crouch,grounded:p.grounded},oldBottom=p.y+p.h,oldRight=p.x+p.w;
    contactFrame={tick,body:{bottom:oldBottom},enemies:new WeakMap(r.enemies.map(e=>[e,{y:e.y}]))};
    for(const q of r.geometry)if(q.temporary)q.life--;
    // Keep the live collection identity while only positions change. Native
    // projections follow those positions; membership changes replace the list.
    if(r.geometry.some(q=>q.temporary&&q.life<=0))r.geometry=r.geometry.filter(q=>!q.temporary||q.life>0);
    p.scaffoldCooldown=Math.max(0,(p.scaffoldCooldown||0)-1);
    if(!actorPort&&p.motionId==='sandboxTrio'&&v.abilityPressed&&!p.scaffoldCooldown){
      const platform={id:'scaffold-'+tick,x:Math.max(0,Math.min(map.width-48,p.x+p.w/2-24)),y:Math.min(map.height-24,p.y+p.h+8),w:48,h:6,collision:'oneway',material:'platform',temporary:true,life:240,dx:0,dy:0};
      if(!r.geometry.some(g=>g.collision==='solid'&&!g.hidden&&motor.overlap(platform,g))){r.geometry=r.geometry.filter(g=>!g.temporary);r.geometry.push(platform);p.scaffoldCooldown=180;emit('sound',{event:'appear'});}
    }
    for(const vine of r.vines){vine.y=Math.max(0,vine.y-1);vine.h=vine.bottom-vine.y;}
    const vine=r.vines.find(a=>p.x+p.w>a.x&&p.x<a.x+a.w&&p.y+p.h>a.y&&p.y<a.bottom);
    if(!p.springId&&p.onVine&&(!vine||v.jump||v.x)){p.onVine=false;if(v.jump){p.vy=-4;p.grounded=false;}}
    if(!p.springId&&vine&&(raw.up||p.onVine)&&!v.jump&&!v.x){p.onVine=true;p.x=vine.x+7-p.w/2;p.vx=p.vy=0;p.grounded=false;p.y+=raw.up?-1.5:v.down?1.5:0;
      if(p.y<=0){enter(vine.portal.targetRoom,vine.portal.targetSpawn);p.onVine=false;emit('sound',{event:'portal'});}return;}
    for(const q of r.geometry){if(stepFallingPlatform(q,p.grounded&&p.support===q.id))continue;if(/Sky/.test(visualRooms.find(v=>v.roomId===roomId)?.setting||'')&&visualRooms.find(v=>v.roomId===roomId)?.semantics?.some(s=>s.id===q.id&&s.source?.transport===true)){if(p.support===q.id)q.riding=true;if(q.riding){q.x+=1.2;q.dx=1.2;q.dy=0;continue;}}q.dx=q.dy=0;if(q.liftSpeed){q.y+=q.liftSpeed;q.dy=q.liftSpeed;if(q.y>map.height||q.y+q.h<0){q.y=q.liftSpeed>0?-q.h:map.height;q.dy=0;if(p.support===q.id){p.support=null;p.grounded=false;}}}else if(q.motion){const {axis,min,max,speed}=q.motion,old=q[axis];q[axis]=Math.max(min,Math.min(max,old+speed*q.dir));if(q[axis]>=max||q[axis]<=min)q.dir*=-1;q[axis=== 'x'?'dx':'dy']=q[axis]-old;}}
    for(const marker of visualRooms.find(q=>q.roomId===roomId)?.markers||[]){
      if(marker.kind!=='coupled-scale'||marker.source?.macro!=='Scale')continue;
      const left=r.geometry.find(g=>g.id===marker.id+'-left'),right=r.geometry.find(g=>g.id===marker.id+'-right');
      if(!left||!right)continue;
      if(left.scaleBroken){for(const g of [left,right]){g.fallSpeed=Math.min(4.25,(g.fallSpeed||0)+.125);g.dy=g.fallSpeed;g.y+=g.dy;}continue;}
      const weight=p.grounded?(p.support===left.id?1:p.support===right.id?-1:0):0;
      let speed=left.scaleSpeed||0;
      speed=weight?Math.max(-1.5,Math.min(1.5,speed+weight*.04)):Math.sign(speed)*Math.max(0,Math.abs(speed)-.04);
      left.scaleSpeed=speed;
      const delta=Math.max(marker.y-left.y,Math.min(right.y-marker.y,speed));
      left.dy=delta;right.dy=-delta;left.y+=delta;right.y-=delta;
      if(weight&&(left.y<=marker.y||right.y<=marker.y)){left.scaleBroken=right.scaleBroken=true;left.fallSpeed=right.fallSpeed=0;}
    }
    // Also acquire a resting rider before ordinary jump handling. This covers
    // resumed/saved contact states whose support id has not been reconstructed.
    if(!p.springId&&p.grounded&&p.vy>=0){const spring=r.geometry.find(q=>q.material==='spring'&&!q.springAge&&p.x+p.w>q.x&&p.x<q.x+q.w&&Math.abs(p.y+p.h-q.y)<=1);
      if(spring){spring.springAge=1;spring.launchVx=p.vx;spring.restY??=spring.y;spring.restH??=spring.h;p.springId=spring.id;}
    }
    // The spring owns compression motion before a native step can move or
    // collide. Neutral input alone cannot stop an already active dash/homing.
    // Keep raw input for boost/release and the separate combat phase below;
    // attacks started inside an actor's movement step wait until release.
    p.headHit=null;
    const ridden=r.geometry.find(q=>q.id===p.support);
    if(p.grounded&&ridden&&(ridden.falling||ridden.scaleBroken||ridden.liftSpeed>0)&&ridden.dy>0)p.descendingRide={id:ridden.id,roomId,tick};
    else if(v.jump||p.grounded||p.descendingRide&&tick-p.descendingRide.tick>120)p.descendingRide=null;
    const springHolding=!!p.springId;
    if(springHolding){p.vx=p.vy=0;p.jumpBuffer=0;p.headHit=null;}
    enemyContacts.star(p,r.enemies,{tick,touches});
    const marioClip=!actorPort&&!springHolding?branches.moveMarioClip(roomId,p,v,r.geometry):null;
    if(actorPort){p.invuln=unifiedHealth&&!sceneHealth?invulnerable:Math.max(p.invuln||0,invulnerable);if(!springHolding){actorStatus(actorPort.step(p,springMovementInput(v),actorWorld()));if(dying||p.bashing)return;}}
    else if(!springHolding&&!marioClip?.handled)for(const event of motor.step(p,springMovementInput(v),character,{solids:r.geometry,width:roomWidth(roomId),swimming:visualRooms.some(q=>q.roomId===roomId&&(q.underwater===true||/Underwater/.test(q.setting||'')))}))emit('sound',{event:event==='jump'&&p.power?'jump_super':event});
    if(!actorPort&&!marioClip?.handled)branches.witnessMarioClip(roomId,oldBody,p,v,r.geometry);
    if(marioClip?.completed){emit('world-branch',{id:marioClip.completed});emit('objective',{id:'mario-wall-clip',branchId:marioClip.completed,method:'crouch-jump-pipe',exitX:p.x});}
    for(const q of r.geometry)if(q.material==='spring'){
      q.restY??=q.y;q.restH??=q.h;
      if(!q.springAge&&p.grounded&&p.support===q.id){q.springAge=1;p.springId=q.id;q.launchVx=p.vx;p.vx=0;}
      if(q.springAge){
        const age=q.springAge++;if(age>=8&&v.jump)q.boost=true;const depth=Math.min(q.restH-8,12)*(age<=6?age/6:Math.max(0,(12-age)/6));
        q.y=q.restY+depth;q.h=q.restH-depth;
        if(p.springId===q.id){
          if(p.x+p.w<=q.x||p.x>=q.x+q.w){p.springId=null;}
          else{p.y=q.y-p.h;p.vy=0;p.jumpBuffer=0;p.grounded=true;p.support=q.id;
            if(age>=12){p.springJumpHeld=!!v.jump;p.springId=null;p.grounded=false;p.support=null;p.vx=v.x?Math.sign(v.x)*Math.max(Math.abs(q.launchVx||0),1.5):0;p.vy=q.boost?-9:-6;p.jumpG=.22;p.fallG=.32;p.airCap=v.run?2.5:1.5;emit('sound',{event:p.power?'jump_super':'jump'});}
          }
        }
        if(age>=12){q.springAge=0;q.boost=false;q.y=q.restY;q.h=q.restH;}
      }
    }
    if(!backtracking&&p.x<cam){p.x=cam;if(p.vx<0)p.vx=0;}
    // A small contact core does not license clipping enlarged actor artwork.
    // Insets are presentation-owned, never a larger terrain collision body.
    const margin=actorPort?.presentation?.cameraMargin||0;
    if(margin){const x=Math.max((backtracking?0:cam)+margin,Math.min(roomWidth(roomId)-p.w-margin,p.x));
      if(x!==p.x&&!movementSolids(r).some(q=>!q.hidden&&q.collision==='solid'&&motor.overlap({...p,x},q))){p.x=x;if(p.vx<0&&x>oldBody.x)p.vx=0;}}
    if(p.grounded)stompChain=0;
    if(character.access.travel==='drive')p.headHit=driveHeadContact(p,{y:oldTop},r.geometry,v)||p.headHit;
    const passage=crouchPassage({levelId:levelLabel,roomId,roomSerial,previous:oldBody,body:p,solids:r.geometry,travel:character.access.travel});if(passage)emit('objective',passage);
    if(p.headHit)bump(r,p.headHit);
    const visual=visualRooms.find(q=>q.roomId===roomId);
    const discoveredBranch=branches.cross(roomId,oldBody,p);if(discoveredBranch)emit('world-branch',{id:discoveredBranch});
    if(allowWarp&&!portalLock&&(v.down||raw.interact))for(const m of visual?.markers||[]){
      if(!classicWarpTarget(m))continue;
      const entry=pipeEntryPose(p,{x:m.x,y:m.y,w:32,h:m.h||32});if(entry){Object.assign(p,entry);p.vx=p.vy=0;transition={phase:'enter',age:0,clipTop:m.y,...(branches.destination(roomId,m.id)||{targetWorld:m.source.transport.map})};emit('sound',{event:'portal'});return;}
    }
    r.sectionPassed??=new Set();
    for(const m of visual?.markers||[])if(m.kind==='conditional-sectionpass'&&motor.overlap(p,{x:m.x,y:m.y,w:2*(m.source?.width||8),h:2*(m.source?.height||8)})){
      const section=[...(visual.assembly||[])].reverse().find(a=>a.x*2<=m.x);if(section)r.sectionPassed.add(section.section);
    }
    // Multi-section mazes decide at the exit, never inside a route sensor.
    const deciders=(visual?.markers||[]).filter(m=>m.kind==='conditional-sectiondecider'&&m.source.pass-m.source.fail>1);
    r.sectionDecided??=new Set();
    for(const m of deciders){
      if(r.sectionDecided.has(m.id)||p.x<m.x||p.x>m.x+16)continue;
      const start=visual.assembly?.find(a=>a.section===m.source.fail);
      if(!start)continue;
      const required=visual.assembly.filter(a=>a.section>=m.source.fail&&a.section<m.source.pass)
        .filter(a=>(visual.markers||[]).some(q=>q.kind==='conditional-sectionpass'&&q.x>=a.x*2&&q.x<(visual.assembly.find(b=>b.x>a.x)?.x*2||map.width)));
      if(required.every(a=>r.sectionPassed.has(a.section))){r.sectionDecided.add(m.id);continue;}
      const x=start.x*2+4,screenX=p.x-cam;
      const landing=r.geometry.filter(g=>!g.hidden&&g.y>=48&&x+p.w>g.x&&x<g.x+g.w)
        .sort((a,b)=>Math.abs(a.y-(p.y+p.h))-Math.abs(b.y-(p.y+p.h)))
        .find(g=>!r.geometry.some(q=>!q.hidden&&q.collision==='solid'&&motor.overlap({x,y:g.y-p.h,w:p.w,h:p.h},q)));
      if(landing){for(const prior of deciders)if(prior.x<=start.x*2)r.sectionDecided.add(prior.id);for(const a of required)r.sectionPassed.delete(a.section);p.x=x;p.y=landing.y-p.h;p.vy=0;p.grounded=true;p.support=landing.id;p.springId=null;cam=Math.max(0,x-screenX);return;}
    }
    // Compiled castle sections retain pass/fail sensors. A failed corridor
    // must loop before its closing wall, even when camera backtracking is off.
    // Defeating the castle boss opens the authored goal plane, independent of
    // its chase position. Keep player control until the body has crossed the
    // plane: its leading edge may still be blocked by the bridge-end stair.
    const castleBosses=r.enemies.filter(isCastleBoss),castleGoal=visual?.markers?.find(m=>m.kind==='castle-finish');
    const castleAxe=visual?.markers?.find(m=>['bridge-axe-finish','marker-CastleAxe'].includes(m.kind));
    const rooftop=rooftopRescue(p,castleGoal,r.geometry,character.heroId);
    if(rooftop){cam=followCamera();p.star=0;p.vx=p.vy=0;p.facing=1;finish={castle:true,phase:'rescue',age:0,rescueAge:0,rooftop};emit('objective',{id:'rooftop-rescue',markerId:castleGoal.id});emit('sound',{event:'world_clear'});return;}
    if((r.castleBossDefeated||castleBosses.length&&castleBosses.every(e=>e.dead))&&castleGoal&&castleAxe&&p.x>=castleAxe.x&&!r.geometry.some(g=>!g.hidden&&g.collision==='solid'&&motor.overlap(p,g))){
      beginCastleEnding(r,map,visual);return;
    }
    for(const m of visual?.markers||[]){
      if(m.kind!=='conditional-sectionfail'||!visual.assembly?.length||deciders.length)continue;
      const section=[...visual.assembly].reverse().find(a=>a.x*2<=m.x);
      if(!section||r.sectionPassed.has(section.section))continue;
      const next=visual.assembly.find(a=>a.x>section.x),end=next?next.x*2:map.width;
      // The route sensor records a choice; it is not a teleport trigger.
      r.sectionFailed??=new Set();
      if(motor.overlap(p,{x:m.x,y:m.y,w:2*(m.source?.width||8),h:2*(m.source?.height||8)}))r.sectionFailed.add(section.section);
      if(!r.sectionFailed.has(section.section)||p.x>=end)continue;
      const wall=r.geometry.filter(g=>!g.hidden&&g.collision==='solid'&&g.x>m.x+2*(m.source?.width||8)&&g.x<end&&g.y<p.y+p.h&&g.y+g.h>p.y).sort((a,b)=>a.x-b.x)[0];
      const retryAt=wall?wall.x-p.w-2:end-2;
      if(p.x<retryAt)continue;
      const x=section.x*2+4,screenX=p.x-cam;
      const landing=r.geometry.filter(g=>!g.hidden&&g.y>=48&&x+p.w>g.x&&x<g.x+g.w)
        .sort((a,b)=>b.y-a.y).find(g=>!r.geometry.some(q=>!q.hidden&&q.collision==='solid'&&motor.overlap({x,y:g.y-p.h,w:p.w,h:p.h},q)));
      if(landing){
        const free=!r.geometry.some(g=>!g.hidden&&g.collision==='solid'&&motor.overlap({x,y:p.y,w:p.w,h:p.h},g));
        p.x=x;if(!free){p.y=landing.y-p.h;p.vy=0;p.grounded=true;p.support=landing.id;}else {p.grounded=false;p.support=null;}
        p.springId=null;r.sectionFailed.delete(section.section);cam=Math.max(0,x-screenX);return;
      }
    }
    for(const m of visual?.markers||[]){
      if(m.kind==='rotating-firebar'&&markerParts({...visual,tick},m).some(b=>motor.overlap(readActorHurtbox(actorPort,p,{mainline:!sceneHealth}),b))){hurt();if(dying)return;}
      if(/lava/.test(m.kind)){const hazard={x:m.x,y:m.y,w:2*(m.source?.width||8),h:Math.max(1,map.height-m.y)};if(motor.overlap(p,hazard)||motor.overlap(readActorHurtbox(actorPort,p,{mainline:!sceneHealth}),hazard)){respawn(true);return;}}
      if(['bridge-axe-finish','marker-CastleAxe'].includes(m.kind)&&motor.overlap(p,{x:m.x,y:m.y,w:16,h:16})){
        beginCastleEnding(r,map,visual);return;
      }
    }

    for(const q of r.geometry)if(q.bump)q.bump--;for(const e of r.effects){e.age++;e.life--;e.x+=e.vx;e.y+=e.vy;if(e.kind!=='bubble'&&!e.flat)e.vy+=e.kind==='coin-pop'?.14:.22;}r.effects=r.effects.filter(e=>e.life>0);
    // Water belongs to the room, independently of a swimmer/vehicle controller
    // or an unusual background palette (the post-credits 9-1 is underwater).
    if(isMainlineWater({mainline:!sceneHealth,underwater:visual?.underwater,setting:visual?.setting})&&tick%48===0&&p.y>24)r.effects.push({kind:'bubble',x:p.x+(character.access.travel==='drive'?p.w/2:p.facing>0?p.w:0),y:p.y+4,w:4,h:4,vx:0,vy:-.6,life:Math.max(1,Math.floor((p.y-20)/.6)),age:0});
    if(p.star)p.star--;
    for(const item of r.items){
      if(item.dead)continue;
      if(item.emerge){item.y+=(item.targetY-item.y)/item.emerge;item.emerge--;continue;}
      item.age++;const bottom=item.y+item.h,top=item.y;
      if(item.stationary)item.vx=0;
      item.x+=item.vx;
      if(item.vx)for(const q of r.geometry)if(!q.hidden&&q.collision==='solid'&&motor.overlap(item,q)){item.x=item.vx>0?q.x-item.w:q.x+q.w;item.vx*=-1;break;}
      item.vy=item.floating?0:Math.min(4.25,item.vy+.22);item.y+=item.vy;
      for(const q of [...r.geometry].sort((a,b)=>a.y-b.y))if(!q.hidden&&item.x+item.w>q.x&&item.x<q.x+q.w&&bottom<=q.y+1&&item.y+item.h>=q.y&&item.vy>=0){item.y=q.y-item.h;item.vy=item.kind==='star'&&!item.stationary?-3.9:0;break;}
      if(item.vy<0)for(const q of r.geometry)if(!q.hidden&&q.collision==='solid'&&item.x+item.w>q.x&&item.x<q.x+q.w&&top>=q.y+q.h&&item.y<q.y+q.h){item.y=q.y+q.h;item.vy=.5;break;}
      if(motor.overlap(p,item))takeItem(item,r);
      if(item.y>map.height+32||!item.stationary&&item.age>1800)item.dead=true;
    }
    if(growth||fireGrowth)return;
    if(p.y>map.height+40){const back=map.objects.find(o=>o.id==='sky-return');if(back){enter(back.targetRoom,back.targetSpawn);p.vy=1;emit('sound',{event:'portal'});}else respawn(true);return;}
    if(!actorPort&&bill){p.aimY=raw.up?-1:v.down&&(!p.grounded||v.x)?1:0;p.aimX=p.aimY?v.x:p.facing;p.fireFrames=Math.max(0,(p.fireFrames||0)-1);p.firing=p.fireFrames>0;
     if((v.run||raw.attack)&&!cooldown&&r.shots.length<32){r.shots.push(...billShots(p));cooldown={N:12,M:7,S:17,F:24,L:28}[p.weapon||'N'];p.firing=true;p.fireFrames=3;emit('sound',{event:'bill_'+(p.weapon||'N')});}}
    if(mario&&v.attackPressed&&p.power===2&&!cooldown&&r.shots.length<2){r.shots.push({kind:'fireball',x:p.x+(p.facing>0?p.w:-4),y:p.y+10,w:5,h:5,vx:p.facing*3.4,vy:1.2,age:0});cooldown=12;emit('sound',{event:'fire'});}
    if(actorPort){actorStatus(actorPort.combat?.(p,v,actorWorld()));if(dying)return;enemyContacts.star(p,r.enemies,{tick,touches});}
    else {const added=characterAttack(p,{...v,attack:raw.attack},r.enemies);if(added.length){r.shots.push(...added);emit('sound',{event:'attack'});}
    advanceCharacterShots(r.shots,{geometry:r.geometry,enemies:r.enemies,overlap:motor.overlap,kill:e=>{killEnemy(r,e);score+=100;},bump:id=>{const power=p.power;p.power=Math.max(1,power);bump(r,id);p.power=power;}});}
    collectEnemyBackgrounds(r);
    for(const shot of r.shots){if(shot.kind==='mainline-shot')continue;if(shot.kind==='bill-shot'){if(!advanceBillShot(shot))continue;
      for(const q of r.geometry)if(!q.hidden&&motor.overlap(shot,q)){shot.dead=true;
       const room=visualRooms.find(v=>v.roomId===roomId),source=room?.semantics?.find(v=>v.id===(q.sourceId||q.id))?.source;
       if(source?.contents||q.hidden||room.map.geometry.find(g=>g.id===(q.sourceId||q.id))?.reward)bump(r,q.id);
       else if(q.material==='brick'){q.shotHp=(q.shotHp??2)-shot.damage;if(q.shotHp<=0){const power=p.power;p.power=1;bump(r,q.id);p.power=power;}}
       break;}
      if(!shot.dead)for(const e of r.enemies)if(!e.dead&&touches(shot,e)){actorWorld().damageEnemy(e,shot.damage,{kind:'bill-shot'});shot.dead=true;break;}
      if(shot.age>90||shot.y>map.height||shot.y<0)shot.dead=true;continue;}shot.age++;const oldY=shot.y;shot.x+=shot.vx;shot.vy=Math.min(4,shot.vy+.2);shot.y+=shot.vy;for(const q of r.geometry)if(!q.hidden&&motor.overlap(shot,q)){if(oldY+shot.h<=q.y+1){shot.y=q.y-shot.h;shot.vy=-3;}else {shot.dead=true;break;}}if(shot.dead){r.effects.push({kind:'fire-impact',x:shot.x-3,y:shot.y-3,w:12,h:12,vx:0,vy:0,life:6,age:0});continue;}for(const e of r.enemies)if(!e.dead&&touches(shot,e)){shot.dead=true;if(!classicEnemy(e)){actorWorld().damageEnemy(e,1,{kind:'fireball'});}else if(!/beetle|bowser/i.test(e.type)){killEnemy(r,e,false,'fireball');score+=100;}else if(isCastleBoss(e)){actorWorld().damageEnemy(e,1,{kind:'fireball'});}break;}if(shot.age>160||shot.y>map.height)shot.dead=true;}r.shots=r.shots.filter(s=>!s.dead);
    if(false){attackAge=9;cooldown=18;emit('sound',{event:'attack'});const box={x:p.facing>0?p.x+p.w:p.x-28,y:p.y-2,w:28,h:p.h+4};for(const e of r.enemies)if(!e.dead&&motor.overlap(box,e)){e.hp--;if(e.hp<=0){killEnemy(r,e);score+=100;}}}
    if((visual?.markers||[]).some(m=>m.kind==='spawn-zone-LakituStop'&&p.x+p.w>=m.x)){r.lakituStopped=true;r.lakituRespawn=null;}
    if(r.lakituRespawn&&!r.lakituStopped){
      const pending=r.lakituRespawn;
      if(--pending.ticks<=0){
        if(!r.enemies.some(e=>!e.dead&&classicEnemy(e)&&/^(enemy-|marker-)?lakitu$/i.test(e.type))){
          const e=pending.enemy,x=Math.min(map.width-e.w,cam+264);
          r.enemies.push({...e,x,y:e.homeY,homeX:x,vx:0,vy:0,age:0,hp:2,dead:false,safe:0});
        }
        r.lakituRespawn=null;
      }
    }
    const contactPlayer=readActorHurtbox(actorPort,p,{mainline:!sceneHealth}),descending=p.vy>=0;
    const spawned=[];
    const spawn=(type,x,y,vx=0,vy=0)=>spawned.push({id:'runtime-'+tick+'-'+spawned.length,kind:'walker',type,x,y,w:16,h:16,vx,vy,homeX:x,homeY:y,age:0,dead:false});
    // Both imported Cannon geometry and hand-placed cannon material fire.
    r.cannonClocks??=new Map();
    for(const g of tick<(r.enemyFreezeUntil||0)?[]:r.geometry){
      if(g.hidden||!(g.material==='cannon'||cannonSources.get(roomId)?.has(g.sourceId||g.id)))continue;
      if(g.x+g.w<cam||g.x>cam+viewportWidth)continue;
      const distance=p.x+p.w/2-(g.x+g.w/2);
      if(Math.abs(distance)<32)continue;
      const clock=(r.cannonClocks.get(g.id)||0)+1;r.cannonClocks.set(g.id,clock);
      if(clock%150!==60||r.enemies.filter(e=>!e.dead&&classicEnemy(e)&&e.type==='bulletbill').length+spawned.filter(e=>e.type==='bulletbill').length>=3)continue;
      const direction=Math.sign(distance);
      spawn('bulletbill',direction<0?g.x-16:g.x+g.w,g.y,direction*2,0);
      spawned.at(-1).source={cannonId:g.id};emit('sound',{event:'cannon'});
    }
    // Timed airborne Bills are distinct from cannons and use the visible right
    // edge at every aspect ratio. Freeze and stop markers own this spawner too.
    const bulletsActive=tick>=(r.enemyFreezeUntil||0)&&spawnZoneActive(visual?.markers||[],'BulletBills',p.x+p.w);
    r.bulletZoneClock=bulletsActive?(r.bulletZoneClock||0)+1:0;
    if(bulletsActive&&r.bulletZoneClock%210===0&&r.enemies.filter(e=>!e.dead&&classicEnemy(e)&&e.type==='bulletbill').length<3){
      r.bulletSeed=((r.bulletSeed??4711)*1664525+1013904223)>>>0;
      const y=32+16*(r.bulletSeed%10);
      spawn('bulletbill',Math.min(map.width-16,cam+viewportWidth),y,-2,0);
      spawned.at(-1).source={zone:'BulletBills'};emit('sound',{event:'cannon'});
    }
    // Source CheepsStart/CheepsStop detectors activate the full-height bridge zone.
    const triggers=(visualRooms.find(q=>q.roomId===roomId)?.markers||[]).filter(m=>/spawn-zone-Cheeps(Start|Stop)/.test(m.kind)&&m.x<=p.x+p.w).sort((a,b)=>a.x-b.x);
    const active=tick>=(r.enemyFreezeUntil||0)&&triggers.length>0&&triggers.at(-1).kind.endsWith('Start');
    r.fishClock=active?(r.fishClock||0)+1:0;
    if(active&&r.fishClock%21===0&&r.enemies.filter(e=>classicEnemy(e)&&e.flying).length<20){
      r.fishSeed=((r.fishSeed??12345)*1664525+1013904223)>>>0;const position=r.fishSeed/4294967296;
      const x=cam+position*240;
      spawn('cheepcheep',x,map.height, (position<.5?1:-1)*(.2+position*2.6),-2.8);Object.assign(spawned.at(-1),{flying:true,falling:false,source:{red:true}});
    }
    for(const e of r.enemies){
      if(e.nativeOwner&&!['stage','foe-port'].includes(e.nativeOwner)||e.dead)continue;
      if(tick<(r.enemyFreezeUntil||0)&&enemyDefinition(e).movement.collision!=='projectile'){
        if(touches(contactPlayer,e))resolvePlayerContact(r,e,{descending,oldBottom,oldEnemyTop:e.y});
        continue;
      }
      if(e.reflected&&enemyDefinition(e).owner==='foe-port'){stepEnemyMotionPort(enemyPort,e,actorWorld(),p);continue;}
      if(e.reflected){e.x+=e.vx||0;e.y+=e.vy||0;e.age=(e.age||0)+1;
        for(const target of r.enemies)if(target!==e&&!target.dead&&!target.reflected&&!/fire|bullet|hammer/.test(target.type||'')&&motor.overlap(e,target)){actorPort?.reflectedHit?.(p,target,actorWorld());e.dead=true;break;}
        if(e.age>440||e.x<cam-70||e.x>map.width||e.y>map.height||e.y<-40)e.dead=true;continue;}
      if(isCastleBoss(e)&&e.x-p.x<1024){
        e.fireClock=(e.fireClock||0)+1;e.frame=e.fireClock%180>=40&&e.fireClock%180<=65?'firing':'';
        if(e.fireClock%180===60){const direction=p.x<e.x?-1:1;spawn('bowserfire',e.x+(direction<0?-24:e.w),e.y+8,direction*1.5,0);Object.assign(spawned.at(-1),{w:24,h:8});emit('sound',{event:'bowser_fire'});}
        if(e.source?.throwing&&e.fireClock%180>=95&&e.fireClock%180<130&&e.fireClock%7===0){const direction=p.x<e.x?-1:1;spawn('hammer',e.x+e.w/2,e.y-8,direction*1.6,-3.4);}
      }
      // A wide viewport can reveal actors beyond the old 320-unit activation
      // gate. They must already simulate when visible, including falling to ground.
      const classic=classicEnemy(e);
      if(!enemySimulationActive(e,enemyDefinition(e),{playerX:p.x,camera:cam,viewportWidth}))continue;e.age=(e.age||0)+1;
      const type=e.type.replace(/^(enemy-|marker-)/,'').toLowerCase(),direction=p.x<e.x?-1:1,oldY=e.y,bottom=e.y+e.h;
      if(classic&&e.shell){
        if(Math.abs(e.vx)>1){e.shellAge=0;e.frame='';}
        else{
          e.shellAge=(e.shellAge||0)+1;e.frame=e.shellAge>=480?'peeking':'';
          if(e.shellAge>=600){
            const height=e.walkHeight||(/beetle/i.test(type)?17:24),body={...e,y:e.y+e.h-height,h:height};
            if(!r.geometry.some(g=>!g.hidden&&g.collision==='solid'&&motor.overlap(body,g))){
              e.y=body.y;e.h=height;e.shell=false;e.shellAge=0;e.frame='';e.hits=0;e.vx=direction*.5;
            }
          }
        }
      }
      if(enemyDefinition(e).owner==='foe-port'){
        stepEnemyMotionPort(enemyPort,e,actorWorld(),p);
      }
      else if(stepClassicKoopaMotion(e)){}
      else if(type==='lakitu'){
        if(r.lakituStopped){e.x+=2.5;if(e.x>cam+280)e.dead=true;continue;}
        const target=p.x+(Math.abs(p.vx)>1.5?64:Math.sin(e.age*.022)*100);e.vx=Math.max(-2,Math.min(2,(target-e.x)*.035));e.x+=e.vx;
        e.frame=e.age%140<21?'hiding':'out';if(e.age%140===21)spawn('spinyegg',e.x,e.y,0,-4.2);
      }else if(type==='piranha'){
        let phase=e.age%180;
        const near=Math.abs(p.x+p.w/2-e.homeX-e.w/2)<28;
        // Proximity suppresses the next emergence, never interrupts an active cycle.
        if(near&&phase<=60){e.age=0;phase=0;}
        const depth=phase<60?e.h:phase<90?e.h*(90-phase)/30:phase<150?0:e.h*(phase-150)/30;
        e.y=e.homeY+depth;
      }else if(type==='bulletbill'){e.vx=e.vx<0?-2:2;e.x+=e.vx;}
      else if(type==='blooper'){const phase=e.age%120;e.vy=phase<45?-1.3:phase<75?.1:.7;e.y+=e.vy;e.x+=phase<45?direction*.65:0;}
      else if(type==='cheepcheep'){if(e.flying){e.x+=e.vx;e.y+=e.vy;if(e.y<56)e.falling=true;if(e.falling)e.vy+=.48/7;}else{e.x-=.7;e.y=e.homeY+Math.sin(e.age/45)*12;}}
      else if(type==='podoboo'){e.vy+=.14;e.y+=e.vy;if(e.y>=e.homeY){e.y=e.homeY;e.vy=-5;}}
      else {
        if(type==='hammerbro') {e.vx=Math.sin(e.age/22)*.65;e.facing=direction;if(e.age%140===0)e.vy=-4.2;if(e.age%120>=35&&e.age%120<84&&e.age%7===0){spawn('hammer',e.x,e.y-8,direction*1.43,-2.8);e.frame='throwing';}else e.frame='';}
        if(type==='bowser'){moveCastleBoss(e,r.geometry,{width:map.width,targetX:p.x+p.w/2,tick});}
        else if(type==='bowserfire'){e.x+=e.vx;}
        else {
          const oldX=e.x;e.x+=e.vx;
          if(type!=='hammer')for(const q of r.geometry)if(!q.hidden&&q.collision==='solid'&&motor.overlap(e,q)&&bottom>q.y+1){e.x=oldX;e.vx*=-1;break;}
          if((e.source?.smart||e.source?.red)&&!e.shell&&e.grounded&&e.vx){
            // Probe the leading foot, not the sprite's outer edge. Adjacent top
            // pieces count as continuous support; unrevealed blocks do not.
            const supports=r.geometry.filter(q=>!q.hidden&&Math.abs(q.y-bottom)<1.01),probe=e.x+e.w/2+Math.sign(e.vx)*Math.min(4,e.w/4);
            if(!supports.some(q=>probe>=q.x&&probe<q.x+q.w)){e.x=oldX;e.vx*=-1;}
          }
          e.vy=Math.min(5,e.vy+(type==='hammer'||type==='hammerbro'?.12:.3));e.y+=e.vy;e.grounded=false;
          if(type!=='hammer')for(const q of [...r.geometry].sort((a,b)=>a.y-b.y))if(!q.hidden&&e.x+e.w>q.x&&e.x<q.x+q.w&&bottom<=q.y+1&&e.y+e.h>=q.y&&e.vy>=0){e.y=q.y-e.h;e.vy=0;e.grounded=true;if(type==='spinyegg'){e.type='spiny';e.vx=direction*.5;}else if(e.source?.jumping)e.vy=-3;break;}
        }
      }
      if(e.y>map.height+40||e.x<p.x-512||(classic&&type==='bulletbill'&&(e.x+e.w<cam-32||e.x>cam+viewportWidth+32)))e.dead=true;
      if(!e.dead&&touches(contactPlayer,e)){
        if(p.star){enemyContacts.kill(e,{cause:'star',tick});continue;}
        if(e.safe){e.safe--;continue;}
        resolvePlayerContact(r,e,{descending,oldBottom,oldEnemyTop:oldY});if(roomSerial!==before||completed||dying)return;
      }else if(e.safe)e.safe--;
    }
    // Resolve each contact once, after both actors have moved. Projectiles and
    // scripted airborne actors do not participate in ground crowd separation.
    const groundBody=e=>classicEnemy(e)&&!isFloatingKoopa(e)&&/^(walker|goomba|koopa|beetle|spiny)$/.test(e.type.replace(/^(enemy-|marker-)/,'').toLowerCase());
    for(let i=0;tick>=(r.enemyFreezeUntil||0)&&i<r.enemies.length;i++)for(let j=i+1;j<r.enemies.length;j++){
      const a=r.enemies[i],b=r.enemies[j];if(a.dead||b.dead||!a.age||!b.age||!groundBody(a)||!groundBody(b)||!motor.overlap(a,b))continue;
      const movingA=a.shell&&Math.abs(a.vx)>1,movingB=b.shell&&Math.abs(b.vx)>1;
      if(movingA||movingB){
        if(a.shell&&b.shell&&movingA&&movingB){
          // SMB ProcEnemyCollisions defeats both active shells. Exchanging
          // equal velocities kept them overlapped and replayed kick every tick.
          killEnemy(r,a,false,'shell');killEnemy(r,b,false,'shell');score+=1000;
        }
        else{const shell=movingA?a:b,victim=movingA?b:a;killEnemy(r,victim,false,'shell');shell.hits=(shell.hits||0)+1;chainReward(r,victim,shell.hits-1,[500,800,1000,2000,4000,5000,8000],'shell-chain');}
        continue;
      }
      const left=a.x+a.w/2<=b.x+b.w/2?a:b,right=left===a?b:a,overlap=left.x+left.w-right.x;
      if(left.shell&&right.shell)continue;
      if(left.shell){right.x+=overlap;right.vx=Math.abs(right.vx||.5);}
      else if(right.shell){left.x-=overlap;left.vx=-Math.abs(left.vx||.5);}
      else{left.x-=overlap/2;right.x+=overlap/2;left.vx=-Math.abs(left.vx||.5);right.vx=Math.abs(right.vx||.5);}
    }
    r.enemies.push(...spawned);r.enemies=r.enemies.filter(alive);
    for(const o of roomObjects(r,map)){if(o.id.endsWith('-vine-portal')||o.id==='sky-return')continue;
      const castleExit=o.kind==='exit'&&(o.finish?.kind==='castle'||visual?.markers?.some(m=>m.kind==='castle-finish'));
      const flagCrossing=o.kind==='exit'&&!castleExit&&crossesFlagpole(oldRight,p,o);
      if(!flagCrossing&&!motor.overlap(o.kind==='hazard'?readActorHurtbox(actorPort,p,{mainline:!sceneHealth}):p,o)&&(o.kind!=='portal'||!motor.overlap({...p,x:p.x-2,w:p.w+4,h:p.h+2},o)))continue;
      if(o.kind==='coin'&&!r.taken.has(o.id)){r.taken.add(o.id);collectCoin();}
      if(o.kind==='hazard'){hurt();if(roomSerial!==before||completed||dying)return;}
      if(o.kind==='checkpoint'&&!r.taken.has(o.id)){r.taken.add(o.id);checkpoint={roomId,spawnId:o.targetSpawn};emit('sound',{event:'checkpoint'});}
      if(o.kind==='portal'&&!portalLock){const side=r.geometry.find(g=>g.material==='pipe-side'&&Math.abs(g.x-o.x)<32&&Math.abs(g.y-o.y)<32)||(o.h>o.w&&r.geometry.some(g=>g.material==='pipe'&&g.x>=o.x&&g.x<=o.x+32&&g.y<o.y-32)?{x:o.x,y:o.y,w:o.w,h:o.h}:null);if(raw.interact||(side&&v.x>0)||(!side&&v.down)){
        const pipe=side||r.geometry.find(g=>g.material==='pipe'&&o.x<g.x+g.w&&o.x+o.w>g.x&&Math.abs(o.y-g.y)<32);
        if(pipe){const entry=pipeEntryPose(p,pipe,{side:!!side});if(!entry)continue;Object.assign(p,entry);p.vx=p.vy=0;transition={phase:'enter',age:0,side:!!side,clipTop:side?null:pipe.y,clipRight:side?pipe.x:null,portalId:o.id,targetRoom:o.targetRoom,targetSpawn:o.targetSpawn,resetRoom:o.resetRoom===true};emit('sound',{event:'portal'});}else{enter(o.targetRoom,o.targetSpawn,true,o.id);emit('sound',{event:'portal'});}return;
      }}
      if(castleExit){beginCastleEnding(r,map,visual,o);return;}
      if(o.kind==='exit'){const ground=r.geometry.filter(q=>p.x+p.w>=q.x&&p.x<=q.x+q.w&&q.y>=p.y+p.h).sort((a,b)=>a.y-b.y)[0];const marker=visual?.markers?.find(m=>m.kind==='flagpole-finish'&&Math.abs(m.x-o.x)<32),poleX=marker?marker.x+8:o.x+o.w/2;const base=r.geometry.find(g=>g.id===marker?.id+'-base')||r.geometry.filter(g=>g.x<=poleX&&g.x+g.w>=poleX&&g.y>=(marker?marker.y-16:p.y+p.h)).sort((a,b)=>a.y-b.y)[0];finish={phase:'slide',age:0,x:o.x,walkTarget:Math.min(map.width-p.w,Math.max(0,Number.isFinite(o.finish?.walkTarget)?o.finish.walkTarget:o.x+96)),poleX,flagY:marker?flagRestY(marker):o.y,floor:base?.y??(marker?marker.y-16:ground?.y??map.height-32)};const flagPoints=p.y<62?5000:p.y<100?2000:p.y<140?800:p.y<176?400:100;score+=flagPoints;emit('flag-grab',{points:flagPoints});p.star=0;p.x=poleX-p.w/2;p.facing=1;p.crouch=false;p.vx=p.vy=0;emit('sound',{event:'flag'});return;}
    }
    const checkpointX=plan.rooms[checkpoint.roomId]?.objects.find(o=>o.id===checkpoint.spawnId)?.x;
    const currentRank=Math.max(0,...(plan.stage.checkpoints||[]).filter(c=>c.activation!=='contact'&&c.roomId===checkpoint.roomId&&(c.spawnId===checkpoint.spawnId||c.x<=checkpointX)).map(c=>c.rank));
    for(const point of plan.stage.checkpoints||[])if(point.activation!=='contact'&&point.activation!=='entry'&&point.roomId===roomId&&point.rank>currentRank&&p.x>=point.x){
      checkpoint={roomId,spawnId:point.spawnId};emit('checkpoint',{...checkpoint});
    }
    cam=followCamera();
  }
  function continueFromCurrent(){
    // A production campaign always follows its checkpoint and finite lives.
    // Preserve the old method name for callers, but never revive in place.
    return false;
  }
  function applyChallengeResult(result){
    assertHealthy();
    if(disposed||completed||finish||dying||lives<=0||!result||challengeResults.has(result.generation))return false;
    if(result.hero&&result.hero!==character.heroId)throw new TypeError('Challenge result hero mismatch');
      const equipment=result.nativeCarry?copyActorEquipment(character.heroId,result.nativeCarry):null;
      const counters=projectChallengeCounters({score,coins,lives},result.reason==='failed'||result.completed||result.exited&&plan.stage.secret?result.carryDelta||{}:{});
    return mutate(()=>{
      if(result.reason==='failed'){
        ({score,coins,lives}=counters);
      challengeResults.add(result.generation);
      challengeRetry=activeSecret?copy(activeSecret):null;
      challengeRetryCarry=equipment?{native:equipment,power:p.power||0,weapon:p.weapon,protection:0}:null;
      respawn(false,null,result.deathPresentationComplete===true);if(result.deathPresentationComplete===true)dying=104;return true;
    }
    if(equipment)restoreEquipment(equipment);
    challengeResults.add(result.generation);
    if(unifiedHealth&&Number.isInteger(result.protection))p.protection=result.protection===1?1:0;
      ({score,coins,lives}=counters);
    if(!result.completed){if(result.exited)returnFromChallenge();return true;}
    const reward=result.nativeReward;
    // A collected receipt transfers current equipment verbatim. Its summary
    // describes what was won, not a second pickup on the way out.
    if(!equipment||!result.rewardReceipt?.claimed){
    if(bill&&reward?.kind==='bill-weapon'&&Object.hasOwn(weaponNames,reward.weapon))p.weapon=reward.weapon;
    if(reward?.kind==='max-power-shield')p.power=3;
    if(reward?.kind==='jump-and-slash'){p.power=Math.max(1,p.power||0);}
    if(reward?.kind==='terra-equipment'){
      const weapons={melee:'zenith',ranger:'sdmg',mage:'lastPrism',summoner:'terraprisma'};
      if(weapons[reward.kit]){p.weapon=weapons[reward.kit];p.power=3;}
      p.challengeEquipment=copy(reward);
    }
    if(unifiedHealth&&reward)p.protection=1;
    actorPort?.reward?.(p,reward,actorWorld());
    }
    health=actorPort?(p.hp??p.maxHealth):character.motion.maxHealth;p.hp=health;invulnerable=90;
    returnFromChallenge();
    return true;
    });
  }
  // Axe contact and the authored rear exit share one outcome. Walking past
  // Bowser is allowed, but a generic exit cannot skip a living boss's fall.
  // A boss defeated by weapons has already played its own death; never spawn
  // it again merely to run the bridge animation (SMB BridgeCollapse/SetM2).
  function beginCastleEnding(r,map,visual,exit=null){
    const markers=visual?.markers||[],axe=markers.find(m=>['bridge-axe-finish','marker-CastleAxe'].includes(m.kind));
    const npc=markers.find(m=>m.kind==='castle-finish');
    const bridge=axe?r.geometry.filter(g=>sourceType(visual,originalGeometry(roomId,g))==='CastleBridge'&&g.x<=axe.x).sort((a,b)=>b.x-a.x)[0]:null;
    const livingBoss=r.enemies.some(e=>isCastleBoss(e)&&!e.dead&&e.hp>0);
    if(axe)r.hiddenMarkers.push(axe.id,...markers.filter(m=>m.kind==='marker-CastleChain').map(m=>m.id));
    const phase=livingBoss?(bridge?'bridge':'boss-fall'):'walk';
    finish={castle:true,phase,age:0,...(bridge?{bridgeId:bridge.id}:{}),target:Math.min(map.width-p.w,Math.max(0,exit?.finish?.walkTarget??(npc?npc.x+360:(exit?.x??p.x)+96)))};
    p.star=0;p.facing=1;p.crouch=false;p.vx=p.vy=0;
    emit('sound',{event:phase==='bridge'?'break':phase==='boss-fall'?'bowser_fall':'world_clear'});
  }
  function view(){
    // A failed native hook can invalidate its own body/closure. Inspection
    // remains possible without calling that port or rendering a partial scene.
    if(fault)return {fault:fault.message,roomId,tick,lives,coins,score,completed,disposed,native:null,actor:null};
    const map=plan.rooms[roomId],r=stateFor(roomId),native=sceneDeathCarry?copy(sceneDeathCarry):actorPort?(actorPort.carry?.(p)??actorPort.snapshot?.(p)):null;
    if(native&&sceneHealth?.health==='native')native.nativeVitals={hp:Math.max(0,health),maxHp:sceneHealth.initialHealth};
    return{presentation:{invulnerability:p.mainlineHurtUntil>tick?'blink':actorPort?.presentation?.invulnerability||'blink'},native,respawnNative:dying||completed&&lives<=0?copy(respawnNative):null,fault:fault?.message||null,actor:actorPort?.view?.(),secretIds:[...seenSecrets],warpTarget,roomId,title:plan.stage.title,character:copy(character),p:{...p,challengeEquipment:p.challengeEquipment?copy(p.challengeEquipment):undefined,shrink,growth,fireGrowth,invulnerable:Math.max(invulnerable,p.invuln||0),climbing:!!p.climbing||!!p.onVine||finish?.phase==='slide',piping:!!transition},transition:transition?{...transition}:null,cinematic:entranceSequence?{kind:entranceSequence.kind,age:entranceSequence.age}:null,width:roomWidth(roomId),height:map.height,minY:roomBounds.minY,focusY:roomBounds.focusY,cameraY:verticalCameraY(p.y,{...roomBounds,height:map.height}),geometry:copy(r.geometry),objects:roomObjects(r,map).filter(o=>!r.taken.has(o.id)&&o.kind!=='walker').map(copy),vines:copy(r.vines),items:[...r.items.filter(i=>!i.dead),...r.shots,...r.effects].map(copy),enemies:r.enemies.filter(alive).map(copy),hiddenMarkers:[...r.hiddenMarkers,...branches.hiddenMarkers(roomId)],branchIds:branches.activeIds(),displayLevel:plan.stage.roomPolicies?.[roomId]?.displayLevel||null,tick,deathAge:dying,health:unifiedHealth?(dying?0:(mario?p.power>0:p.protection>0)?2:1):health,lives,coins,score,timeLeft,cam,invulnerable,attackAge,completed,checkpoint:{...checkpoint},disposed,finish:finish?{...finish}:null};}
  function checkpointScene(){
    assertHealthy();
    const r=stateFor(roomId);
    return copySceneCheckpoint(character.heroId,{version:1,hero:character.heroId,data:copy({schema:'platform-challenge-v1',stage:plan.stage.id,roomId,tick,health,score,coins,lives,cam,timeLeft,timerTicks,invulnerable,
      body:p,equipment:actorPort.carry(p),geometry:r.geometry,enemies:r.enemies,items:r.items,backgrounds:r.backgrounds,taken:[...r.taken]})}).data;
  }
  function restoreScene(input){
    assertHealthy();
    const d=copySceneCheckpoint(character.heroId,{version:1,hero:character.heroId,data:input}).data;
    if(d.schema!=='platform-challenge-v1'||d.stage!==plan.stage.id||d.roomId!==roomId||d.body.hero!==character.heroId||d.body.dying)throw new TypeError('Invalid platform challenge identity');
    for(const k of ['tick','health','score','coins','lives','cam','timeLeft','timerTicks','invulnerable'])if(!Number.isFinite(d[k])||d[k]<0)throw new TypeError('Invalid platform challenge counter');
    const box=q=>{for(const k of ['x','y','w','h'])if(!Number.isFinite(q[k]))throw new TypeError('Invalid scene body');if(q.w<=0||q.h<=0||q.w>65536||q.h>65536)throw new TypeError('Invalid scene dimensions');};
    box(d.body);for(const k of ['geometry','enemies','items']){if(!Array.isArray(d[k])||d[k].length>2048)throw new TypeError('Invalid scene collection');d[k].forEach(box);}
    const backgroundInput=d.backgrounds??d.enemies.map(enemyBackground).filter(Boolean);
    if(!Array.isArray(backgroundInput)||backgroundInput.length>2048||new Set(backgroundInput.map(q=>q.id)).size!==backgroundInput.length)throw new TypeError('Invalid scene backgrounds');
    const backgrounds=backgroundInput.map(q=>{box(q);const value=enemyBackground(q);if(!value)throw new TypeError('Unknown scene background owner');return value;});
    const visual=visualRooms.find(room=>room.roomId===roomId);d.enemies.forEach(enemy=>validateClassicKoopaMotion(enemy,visual));
    if(!Array.isArray(d.taken)||d.taken.some(id=>typeof id!=='string'))throw new TypeError('Invalid scene collectibles');
    const equipment=copyActorEquipment(character.heroId,d.equipment),r=stateFor(roomId);
    validateActorScene(actorPort,d.body,d.geometry);
    return mutate(()=>{
    ({tick,health,score,coins,lives,cam,timeLeft,timerTicks,invulnerable}=d);
    Object.assign(p,d.body);
    r.geometry=d.geometry;r.enemies=d.enemies;r.items=d.items;r.backgrounds=backgrounds;r.taken=new Set(d.taken);r.shots=[];r.effects=[];prev={};
    restoreEquipment(equipment);p.mainlineMotion=null;p.hp=health;
    });
  }
  function grantCompletionBonus(award){
    assertHealthy();
    const next=addRoomReward({score,coins,lives},award);
    return mutate(()=>{({score,coins,lives}=next);
      stateFor(roomId).effects.push({kind:'score-pop',text:'1UP',x:p.x-6,y:p.y-10,w:24,h:8,vx:0,vy:-.2,flat:true,life:90,age:0});
      emit('sound',{event:'life'});return true;
    });
  }
  // Only native arenas may change authored room dimensions at runtime. The
  // same transaction changes geometry, live entities and the actor's private
  // presentation state; it never respawns defeated foes or collected rewards.
  function resizeNativeArena({width,geometry,objects,mapX=x=>x,privateMapX=mapX}){
    assertHealthy();
    if(!sceneHealth||!plan.stage.nativeEnemiesOnly||!Number.isFinite(width)||width<128||width>1024||!Array.isArray(geometry)||!Array.isArray(objects)||typeof mapX!=='function'||typeof privateMapX!=='function')throw new TypeError('Invalid native arena layout');
    const map=plan.rooms[roomId],r=stateFor(roomId),byId=new Map(geometry.map(q=>[q.id,q]));
    for(const q of geometry)if(![q.x,q.y,q.w,q.h].every(Number.isFinite)||q.w<=0||q.h<=0)throw new TypeError('Invalid arena geometry');
    const move=q=>{const x=mapX(q.x,q);if(!Number.isFinite(x))throw new TypeError('Invalid arena projection');q.x=x;};
    return mutate(()=>{
      move(p);for(const list of [r.enemies,r.shots,r.items,r.effects,r.backgrounds])for(const q of list)move(q);
      remapActorScene(actorPort,p,mapX,{privateMapX});
      r.geometry=r.geometry.filter(q=>!q.viewportEdge).map(q=>byId.has(q.id)?{...q,...copy(byId.get(q.id))}:{...q,x:mapX(q.x,q)});
      map.width=width;map.geometry=copy(geometry);map.objects=copy(objects);viewportWidth=width;expandedWidths.set(roomId,width);
      const visual=visualRooms.find(q=>q.roomId===roomId);if(visual)visual.map.geometry=copy(geometry);
      p.x=Math.max(0,Math.min(width-p.w,p.x));actorPort?.reconcileBody?.(p,actorWorld());cam=followCamera(0,true);
    });
  }
  function spawnReward(item){
    assertHealthy();
    const r=stateFor(roomId);if(r.items.some(i=>i.id===item.id))return false;
    if(!item.id||![item.x,item.y].every(Number.isFinite))throw new TypeError('Invalid reward placement');
    return mutate(()=>{r.items.push(characterSupply(character.heroId,{...actorPort.supply(p),w:16,h:16,age:0,vx:0,vy:0,stationary:true,...item}));return true;});
  }
  const diagnostics=debug?{
    strike(id,amount,kind='test-projectile'){const e=stateFor(roomId).enemies.find(e=>e.id===id);if(!e)throw Error('Unknown test enemy '+id);return actorWorld().damageEnemy(e,amount,{id:'test-'+tick+'-'+id,kind});},
    actor:()=>actorPort?.diagnostics?.()??actorPort?.view?.(),pickup(item){takeItem({...item});},
    place(body){Object.assign(p,body);},enter,hit:hurt,die:respawn,bump:id=>bump(stateFor(roomId),id)
  }:null;
  return Object.freeze({
    step:input=>mutate(()=>step(input)),view,resizeNativeArena,respawnCarry:()=>sceneHealth?null:readRespawnEquipment(character.heroId,actorPort,p),checkpointScene,restoreScene,spawnReward,grantCompletionBonus,applyChallengeResult,continueFromCurrent,
    achievementFacts(){const visual=visualRooms.find(r=>r.roomId===roomId);return {underwater:isMainlineWater({mainline:!sceneHealth,underwater:visual?.underwater,setting:visual?.setting}),stageInstanceId,roomSerial,tick,timeLeft,starTicks:p.star||0,upgraded:mario?p.power>0:!!readActorUpgrade(actorPort,p),score,lives,roomId,power:p.power||0,weapon:p.weapon,rolling:!!p.rolling,gear:actorPort?(actorPort.carry?.(p)??actorPort.snapshot?.(p)):null};},
    drawPlayer(g,body,t,v){assertHealthy();p.piping=!!transition;const prior=p.invuln;try{if(!sceneHealth&&v?.presentation?.invulnerability==='blink')p.invuln=0;return actorPort?.drawPlayer(g,p,t,v);}finally{p.invuln=prior;}},
    drawCompanion(g,marker,v){
      assertHealthy();if(marker.source?.npc==='Peach'||marker.kind!=='castle-finish'||!actorPort?.drawCompanion)return false;
      const accepted=actorPort.drawCompanion(g,{...rescueAnchors(marker,p),arrived:['reunion','score'].includes(v.finish?.phase)},v);
      if(accepted!==true)throw new TypeError('Declared companion renderer refused '+character.heroId);
      return true;
    },
    drawWorldFront(g,v){assertHealthy();return actorPort?.drawWorldFront?.(g,v);},
    drawWorldBehind(g,v){assertHealthy();for(const q of stateFor(roomId).backgrounds){const result=enemyPort.drawBackground(g,q,tick);if(result&&typeof result.then==='function'){Promise.resolve(result).catch(()=>{});throw new TypeError('Enemy background drawing must be synchronous');}if(result!==true)throw new TypeError('Enemy background renderer refused '+q.id);}return actorPort?.drawWorldBehind?.(g,v);},
    drawWorld(g,v){assertHealthy();return actorPort?.drawWorld?.(g,v);},
    drawPickup(g,item,t){assertHealthy();return ownsCharacterSupply(item,character.heroId)?actorPort?.drawPickup?.(g,item,t):false;},
    drawCoin(g,item,t){assertHealthy();return character.heroId==='sonic'&&item?.kind==='coin'?actorPort?.drawCoin?.(g,item,t):false;},
    drawHud(...args){assertHealthy();return actorPort?.drawHud?.(...args);},
    dispose(){if(disposed)return;try{actorPort?.dispose?.();}finally{disposed=true;roomStates.clear();}},
    pause(){paused=true;prev={};if(!fault){actorPort?.pause?.();actorPort?.audio?.(false);}},
    resume(){assertHealthy();paused=false;prev={};actorPort?.resume?.();actorPort?.audio?.(true);},
    setViewportWidth(value){assertHealthy();if(!Number.isFinite(value)||value<128||value>1024)throw Error('Invalid viewport');if(viewportWidth!==value){viewportWidth=value;for(const [id,r]of roomStates)extendRoomEdges(r,id);cam=followCamera(cam,false);}},
    ...(diagnostics?{diagnostics:Object.freeze(Object.fromEntries(Object.entries(diagnostics).map(([name,action])=>[name,(...args)=>mutate(()=>action(...args))])))}:{})
  });
}
