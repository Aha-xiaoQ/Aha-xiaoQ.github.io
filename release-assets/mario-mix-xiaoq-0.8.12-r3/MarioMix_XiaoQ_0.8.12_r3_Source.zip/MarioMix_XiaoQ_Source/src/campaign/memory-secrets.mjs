import {MEMORY_SECRETS} from '../content/memory-secrets.mjs';
import {sourceType} from './art/map-appearance.mjs';

// One small authored overlay on fresh classic worlds. Both collision and
// presentation receive the same block; normal stage reward physics do the rest.
export function attachMemorySecrets(world){
 for(const s of MEMORY_SECRETS.filter(s=>s.level===world.level)){
  const room=world.visualRooms.find(r=>r.roomId===s.roomId),map=world.plan.rooms[s.roomId];
  const fail=()=>{throw new TypeError('Memory secret no longer matches map: '+s.id);};
  if(!room||!map)fail();
  const overlaps=q=>q.x<s.x+16&&q.x+q.w>s.x&&q.y<s.y+16&&q.y+q.h>s.y;
  if(s.hidden){
   if(map.geometry.some(q=>q.id===s.blockId||overlaps(q))||map.objects.some(overlaps)||room.markers.some(q=>q.x===s.x&&q.y===s.y))fail();
   const block={id:s.blockId,x:s.x,y:s.y,w:16,h:16,collision:'solid',material:'block',hidden:true};
   for(const geometry of new Set([map.geometry,room.map.geometry]))geometry.push({...block});
  }else{
   const g=room.map.geometry.find(g=>g.id===s.blockId),semantic=room.semantics.find(q=>q.id===s.blockId);
   if(!g||g.x!==s.x||g.y!==s.y||g.w!==16||g.h!==16||sourceType(room,g)!=='Brick'||g.reward||semantic?.source?.contents||room.markers.some(q=>q.x===s.x&&q.y===s.y&&/contents|hidden/.test(q.kind)))fail();
  }
  for(const geometry of new Set([map.geometry,room.map.geometry])){
   const block=geometry.find(g=>g.id===s.blockId);if(!block)fail();
   block.reward=s.content;
   block.rewardSource={secretId:s.id,entityId:s.blockId,levelId:s.level,roomId:s.roomId,content:s.content};
  }
 }
 return world;
}
