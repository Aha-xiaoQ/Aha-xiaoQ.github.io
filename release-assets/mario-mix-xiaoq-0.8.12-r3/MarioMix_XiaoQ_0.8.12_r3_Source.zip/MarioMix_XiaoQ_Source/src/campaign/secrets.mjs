/** Reuse completed RF02 challenges; ordinary pipe destinations stay intact. */
import {CHALLENGE_RULES} from '../content/challenge-rules.mjs';
import {CHALLENGE_REWARDS} from '../content/challenge-rewards.mjs';

export const NATIVE_CHALLENGES=Object.freeze({
  bill:Object.freeze({driver:'bill',title:'敌军基地'}),
  ryu:Object.freeze({driver:'ryu',title:'酒吧决斗'}),
  tank:Object.freeze({driver:'tank',title:'基地保卫'}),
  sandboxTrio:Object.freeze({driver:'sandboxTrio',title:'克苏鲁之眼'}),
  megaman:Object.freeze({driver:'megaman',title:'机械密室'}),
  ori:Object.freeze({driver:'ori',title:'精灵洞窟'}),
  sonic:Object.freeze({driver:'sonic',title:'金环小径'}),
  jackal:Object.freeze({driver:'jackal',title:'美杜莎'}),
});
// Absence is an explicit content decision, never an uninstalled-driver fallback.
export const NO_NATIVE_CHALLENGE=Object.freeze(['mario']);
export function validateChallengeInstallation({heroIds,actors,ports,challenges=NATIVE_CHALLENGES,disabled=NO_NATIVE_CHALLENGE,rules=CHALLENGE_RULES,rewards=CHALLENGE_REWARDS}){
  const fail=message=>{throw new TypeError('Challenge installation: '+message);};
  if(!Array.isArray(heroIds)||!heroIds.length||new Set(heroIds).size!==heroIds.length)fail('invalid roster');
  if(typeof actors?.definition!=='function'||typeof ports?.supports!=='function'||typeof ports?.supported!=='function')fail('missing registry ports');
  const roster=new Set(heroIds),off=new Set(disabled);
  if(off.size!==disabled.length)fail('duplicate disabled hero');
  for(const hero of off)if(!roster.has(hero)||Object.hasOwn(challenges,hero))fail('invalid disabled hero '+hero);
  const drivers=new Set();
  for(const hero of heroIds){
    actors.definition(hero);
    if(off.has(hero))continue;
    const challenge=Object.hasOwn(challenges,hero)&&challenges[hero];
    if(!challenge||challenge.driver!==hero||typeof challenge.title!=='string'||!challenge.title.trim())fail('missing declaration '+hero);
    const driver=challenge.driver;
    if(drivers.has(driver))fail('duplicate driver '+driver);drivers.add(driver);
    if(!ports.supports(driver))fail('uninstalled driver '+driver);
    if(!Object.hasOwn(rules,driver)||!rules[driver])fail('missing rule '+driver);
    const rule=rules[driver];
    if(!['protection','native','rings'].includes(rule.health)||typeof rule.hud!=='string'||!rule.hud.trim()||
      rule.health==='native'&&(!Number.isSafeInteger(rule.initialHealth)||rule.initialHealth<=0)||
      rule.contactDamage!==undefined&&(!Number.isFinite(rule.contactDamage)||rule.contactDamage<=0))fail('invalid rule '+driver);
    if(!Object.hasOwn(rewards,driver)||!rewards[driver])fail('missing reward '+driver);
    const reward=rewards[driver];
    if(reward.id!=='hidden-clear:'+hero||typeof reward.equipment!=='string'||!reward.equipment.trim()||
      !Number.isSafeInteger(reward.score)||reward.score<0||!Number.isSafeInteger(reward.lives)||reward.lives<0)fail('invalid reward '+driver);
  }
  for(const hero of Object.keys(challenges))if(!roster.has(hero))fail('unselected challenge hero '+hero);
  for(const driver of [...Object.keys(rules),...Object.keys(rewards),...ports.supported()])if(!drivers.has(driver))fail('undeclared driver contract '+driver);
  return true;
}
export function attachSecretChallenge(world,profile){
  const challenge=NATIVE_CHALLENGES[profile.id];
  if(!challenge)return;
  const rooms=world.plan.rooms;
  const valid=portal=>portal.kind==='portal'&&!portal.targetWorld&&rooms[portal.targetRoom]?.objects.some(o=>o.kind==='spawn'&&o.id===portal.targetSpawn);
  const entries=[],legacyEntries=[];
  for(const [sourceRoom,room]of Object.entries(rooms))for(const portal of room.objects.filter(valid)){
    const destination=rooms[portal.targetRoom];
    // Only the entrance of an optional round-trip pipe room is a discovery.
    // Required course transfers, bonus-room returns and vine/sky transfers
    // keep their authored destination. Room numbers never define eligibility.
    const exits=destination.objects.filter(o=>o.kind==='portal');
    const bonus=sourceRoom!==portal.targetRoom&&!destination.objects.some(o=>o.kind==='exit')&&exits.length===1&&valid(exits[0])&&exits[0].targetRoom===sourceRoom;
    const natural=bonus?exits[0]:portal;
    const route={sourceRoom,portalId:portal.id,targetRoom:portal.targetRoom,targetSpawn:portal.targetSpawn,returnRoom:natural.targetRoom,returnSpawn:natural.targetSpawn};
    // RF10 saves may already own a challenge reached through a required pipe.
    // These entity-validated routes are restore-only; they cannot discover one.
    const oldExits=destination.objects.filter(valid),oldBonus=sourceRoom!==portal.targetRoom&&!destination.objects.some(o=>o.kind==='exit')&&oldExits.length===1&&oldExits[0].targetRoom===sourceRoom;
    const oldReturn=oldBonus?oldExits[0]:portal;
    legacyEntries.push({...route,returnRoom:oldReturn.targetRoom,returnSpawn:oldReturn.targetSpawn,bonus:oldBonus});
    if(bonus&&!portal.id.endsWith('-vine-portal')&&portal.id!=='sky-return')entries.push(route);
  }
  // Keep the old bonus route as the fallback for saves made before route IDs.
  legacyEntries.sort((a,b)=>Number(b.bonus)-Number(a.bonus));
  const legacy=legacyEntries.map(({bonus,...route})=>route);
  if(legacy.length)world.plan.stage.secret={...challenge,id:'first-underground:'+profile.id,...(entries[0]||legacy[0]),entries,legacyEntries:legacy};
}
