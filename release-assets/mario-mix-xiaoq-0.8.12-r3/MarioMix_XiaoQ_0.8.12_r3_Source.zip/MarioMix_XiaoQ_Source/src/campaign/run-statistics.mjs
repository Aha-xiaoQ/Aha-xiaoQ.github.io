// The campaign owns lifetime counters. Rooms and actors cannot reset them.
const KEYS=Object.freeze(['frames','deaths','retries','continues','challenges']);
export function createRunStatistics(levels,partial=false){
  return {version:1,partial,levels:levels.map(level=>({level,...Object.fromEntries(KEYS.map(k=>[k,0]))}))};
}
export function copyRunStatistics(value,levels){
  const record=(row,keys)=>{
    if(!row||![Object.prototype,null].includes(Object.getPrototypeOf(row)))throw TypeError('Invalid statistics object');
    const own=Reflect.ownKeys(row);if(own.length!==keys.length||own.some(k=>!keys.includes(k)))throw TypeError('Invalid statistics fields');
    for(const k of own){const d=Object.getOwnPropertyDescriptor(row,k);if(!d.enumerable||!Object.hasOwn(d,'value'))throw TypeError('Statistics must contain plain data');}
  };
  record(value,['version','partial','levels']);
  if(!value||value.version!==1||typeof value.partial!=='boolean'||Object.keys(value).some(k=>!['version','partial','levels'].includes(k))||!Array.isArray(value.levels)||value.levels.length!==levels.length)throw TypeError('Invalid run statistics');
  if(Object.getPrototypeOf(value.levels)!==Array.prototype||Reflect.ownKeys(value.levels).length!==levels.length+1)throw TypeError('Invalid statistics rows');
  for(let i=0;i<levels.length;i++){const d=Object.getOwnPropertyDescriptor(value.levels,String(i));if(!d?.enumerable||!Object.hasOwn(d,'value'))throw TypeError('Statistics rows must be dense data');record(d.value,['level',...KEYS]);}
  const rows=value.levels.map((row,i)=>{
    if(!row||row.level!==levels[i]||Object.keys(row).length!==KEYS.length+1||KEYS.some(k=>!Number.isSafeInteger(row[k])||row[k]<0||row[k]>1e9))throw TypeError('Invalid level statistics');
    return {level:row.level,...Object.fromEntries(KEYS.map(k=>[k,row[k]]))};
  });return {version:1,partial:value.partial,levels:rows};
}
export function recordRunStatistic(stats,level,key,amount=1){
  if(!KEYS.includes(key)||!Number.isSafeInteger(amount)||amount<0||amount>36000)throw TypeError('Invalid statistics event');
  const row=stats.levels.find(r=>r.level===level);if(!row)throw TypeError('Unknown statistics level');
  row[key]=Math.min(1e9,row[key]+amount);
}
export function summarizeRun(run){
  const stats=run.statistics||createRunStatistics(run.levelOrder,true);
  const totals=Object.fromEntries(KEYS.map(k=>[k,stats.levels.reduce((sum,r)=>sum+r[k],0)]));
  return {...totals,partial:stats.partial,score:run.carry.score,coins:run.carry.coins,lives:run.carry.lives,
    secrets:run.secretIds.length,cleared:run.clearedLevels.length,total:run.levelOrder.length,mode:run.mode,
    levels:stats.levels.map((r,i)=>({...r,hero:run.plannedCharacters[i],cleared:run.clearedLevels.includes(r.level)}))};
}
export function runTime(frames){const s=Math.floor(frames/60);return [Math.floor(s/3600),Math.floor(s/60)%60,s%60].map(n=>String(n).padStart(2,'0')).join(':');}
