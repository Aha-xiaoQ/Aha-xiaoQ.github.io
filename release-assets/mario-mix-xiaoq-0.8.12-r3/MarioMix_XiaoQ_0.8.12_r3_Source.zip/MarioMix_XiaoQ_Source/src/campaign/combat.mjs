/** Character attacks produce ordinary stage actors; all hit the same collision/reward path. */
export function characterAttack(p,input,enemies=[]){
  const actor=p.attackId||p.hero;
  p.attackTicks=Math.max(0,(p.attackTicks||0)-1);
  p.shotCooldown=Math.max(0,(p.shotCooldown||0)-1);
  const held=!!(input.attack||input.run),released=!held&&(p.charge||0)>0;
  if(actor==='megaman'&&held)p.charge=Math.min(120,(p.charge||0)+1);
  if(p.shotCooldown||['mario','bill','sonic'].includes(actor))return [];
  if(actor==='megaman'?!released:!held)return [];
  const power=p.power||0,charged=actor==='megaman'&&(p.charge||0)>=40;
  const terraRanged=actor==='sandboxTrio'&&['sdmg','lastPrism','terraprisma'].includes(p.weapon),spin=actor==='ryu'&&p.weapon==='spin'&&!p.grounded;
  const slash=['ryu','sandboxTrio'].includes(actor)&&!terraRanged,orb=actor==='ori'||terraRanged;
  const size=slash?30:charged?12:actor==='tank'?7:5;
  const shot={kind:'mainline-shot',hero:actor,x:p.x+(p.facing>0?p.w:-size),y:slash?p.y+1:p.y+Math.max(2,p.h*.4),w:size,h:slash?p.h-2:size,vx:slash?0:p.facing*(orb?2.8:actor==='tank'?3.6:4.5),vy:0,age:0,damage:charged?4:slash||actor==='tank'?2+power:1+power,life:slash?7:75,slash,charged};
  if(orb){const target=enemies.filter(e=>!e.dead&&Math.hypot(e.x-p.x,e.y-p.y)<112).sort((a,b)=>Math.hypot(a.x-p.x,a.y-p.y)-Math.hypot(b.x-p.x,b.y-p.y))[0];if(target){const dx=target.x+target.w/2-shot.x,dy=target.y+target.h/2-shot.y,d=Math.hypot(dx,dy)||1;shot.vx=dx/d*2.8;shot.vy=dy/d*2.8;}}
  p.attackTicks=10;p.shotCooldown=slash?18:actor==='tank'?22:terraRanged?10:orb?16:12;p.charge=0;
  return spin?[shot,{...shot,x:p.x+(p.facing>0?-size:p.w)}]:[shot];
}
export function advanceCharacterShots(shots,{geometry,enemies,overlap,kill,bump}){
  for(const s of shots){if(s.kind!=='mainline-shot'||s.dead)continue;s.age++;s.x+=s.vx;s.y+=s.vy;
    if(s.age>s.life){s.dead=true;continue;}
    for(const q of geometry){if(q.hidden||q.collision!=='solid'||!overlap(s,q))continue;
      if(['brick','block'].includes(q.material)&&!q.used&&(s.hero==='tank'||s.charged))bump(q.id);
      s.dead=true;break;
    }
    if(s.dead)continue;
    for(const e of enemies)if(!e.dead&&overlap(s,e)){e.hp=(e.hp??2)-s.damage;s.dead=true;if(e.hp<=0)kill(e);break;}
  }
}

// Shared keyboard/gamepad aim in both mainline and native Ninja challenges.
export function ninjaFireAim(input={},facing=1){
 const x=Math.sign((input.right?1:0)-(input.left?1:0)||Number(input.x)||0),y=Math.sign((input.down?1:0)-(input.up?1:0)||Number(input.y)||0);
 const dx=x||(!y?(facing<0?-1:1):0),length=Math.hypot(dx,y)||1;return {x:dx/length,y:y/length};
}
