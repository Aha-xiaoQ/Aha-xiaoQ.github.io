import fs from 'node:fs';import path from 'node:path';import{ROOT}from'./build.mjs';import{zip}from'./lib/zip.mjs';
const dirs=['src','assets','content','docs','scripts/lib'];
const roots=['manifest.json','package.json','package-lock.json','LICENSE-TOOLS.txt','LICENSE.collab','NOTICE.md','README.md','scripts/build.mjs','scripts/check.mjs','scripts/check-content.mjs','scripts/dev.mjs','scripts/pack.mjs'];
const files=[];function add(p){const f=path.join(ROOT,p),st=fs.lstatSync(f);if(st.isSymbolicLink())throw Error('Links are not packaged');if(st.isDirectory())for(const n of fs.readdirSync(f).sort())add(p+'/'+n);else files.push(['MarioMix_XiaoQ_Source/'+p,fs.readFileSync(f)]);}
for(const d of dirs)add(d);for(const f of roots)add(f);fs.mkdirSync(path.join(ROOT,'dist'),{recursive:true});fs.writeFileSync(path.join(ROOT,'dist/MarioMix_XiaoQ_Source.zip'),zip(files));console.log('dist/MarioMix_XiaoQ_Source.zip');
