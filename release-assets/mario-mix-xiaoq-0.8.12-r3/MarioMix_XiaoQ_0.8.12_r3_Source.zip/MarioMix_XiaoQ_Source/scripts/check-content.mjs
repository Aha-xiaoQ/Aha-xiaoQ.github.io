import {campaignCatalog} from '../src/campaign/catalog.mjs';
import {enemyRegistry} from '../src/content/enemies.mjs';
console.log(JSON.stringify({characters:campaignCatalog.heroIds(),levels:campaignCatalog.levelIds(),combinations:campaignCatalog.matrix().length,enemyContracts:enemyRegistry.list().length,status:'content-contracts-pass'},null,2));
