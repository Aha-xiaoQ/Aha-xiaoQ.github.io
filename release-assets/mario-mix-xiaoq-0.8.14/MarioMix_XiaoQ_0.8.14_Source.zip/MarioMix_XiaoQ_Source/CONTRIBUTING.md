# 源码贡献约定

每次围绕一个明确问题修改。游戏程序与数据位于 src/，构建入口为 scripts/build.mjs 和 scripts/build-online.mjs，源文件及素材由 manifest.json 登记。

1. 先运行 `npm ci`、`npm run check:content` 和 `npm run check`，确认当前源码可以构建。
2. 修改实际源码，登记新增资源及对应摘要；不要直接编辑生成的 HTML。
3. 运行 `npm run build` 和 `npm run build:online`。检查受影响角色及共享行为，包括移动、受击降级、存档、隐藏关往返和结局，并分别检查经典与宽屏模式。音频修改还应检查暂停/恢复、静音、死亡、换场与播放结束。
4. 提交说明中附实际环境、操作步骤、结果及未测试项目。模拟触控结果不能代替真实设备结论。

manifest.json 中的历史 baseline 记录用于追溯原始版本。新版本的行为变化应单独说明，不改写历史记录。

新增素材需要来源及许可证据。保留原声明，不将未知授权素材重新标注成 MIT。素材权利说明见 NOTICE.md。
