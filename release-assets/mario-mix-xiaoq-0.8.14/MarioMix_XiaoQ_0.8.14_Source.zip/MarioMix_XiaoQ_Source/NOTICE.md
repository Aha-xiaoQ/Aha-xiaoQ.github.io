# 素材与许可

《混合马里奥在下_小Q版》是非官方同人游戏。第三方角色、美术、地图、音乐和音效的权利归原权利人；本包不整体声明为 MIT。游戏代码中的上游许可注释和署名保留，工具许可见 LICENSE-TOOLS.txt 与 LICENSE.collab。

游戏基于 Aha-xiaoQ/Aha-xiaoQ.github.io 的混合马里奥系列继续开发。原 HTML 素材声明见 docs/ORIGINAL_NOTICES.html，上游链接见 docs/UPSTREAM_URLS.json 和 docs/SOURCE_LINKS.md。素材文件的路径、类型、大小与摘要见 manifest.json；运行时映射见 src/data/。

奥日上升段音乐：Gareth Coker — Restoring the Light, Facing the Dark，使用 00:30–01:18，共 48 秒。选角试听：Terraria — Boss 1，使用 13–21 秒，来源记录见 docs/character-selection-audio/terra-boss-source.json。代码许可不涵盖上述音乐。

游戏保留原作位图字，并内嵌寒蝉点阵体用于中文界面。字体许可见 docs/CHILL_FONT_LICENSE.txt。地图工坊组件的原许可见 docs/WORKSHOP_LICENSE.txt。

策划、实机测试：在下_小Q；游戏制作：GPT-6 Astra；游戏辅助测试：GPT-6.1 sol。

移动端素材采用原图的无损 WebP 交付编码，部分原录音采用 Vorbis q6 编码。原录音来源与交付摘要分别保存在 docs/RF09_RYU_AUDIO_SOURCES.json、docs/MOBILE_ASSET_DELIVERY.json 和 src/data/audio-manifest.json；这不改变原作素材的权利归属。
