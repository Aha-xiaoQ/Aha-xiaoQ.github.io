/** Online companion to build.mjs: same compiled program, external media literals. */
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {gzipSync} from 'node:zlib';
import {compile,ROOT,read,sha} from './build.mjs';
import {writeAtomic,validateRelative} from './lib/safe-path.mjs';
import {createMediaStore,injectAssetIndex} from './lib/online-assets.mjs';

export function compileOnline(root=ROOT) {
  const standalone = compile(root), m = standalone.manifest, store = createMediaStore();
  for (const [id,asset] of Object.entries(m.assets)) {
    const bytes = read(root,asset.path);
    if (bytes.length !== asset.bytes || sha(bytes) !== asset.sha256) throw Error('Media identity changed: '+asset.path);
    store.add(bytes,asset.mime,asset.path,{bare:asset.mime.startsWith('audio/')});
    // The asset path is the human-readable classification; the ID preserves its
    // stable declaration binding even when several source literals use it.
    store.add(bytes,asset.mime,'manifest:'+id);
  }
  for (const source of [...m.sources,...(m.modules||[])]) {
    const text=read(root,source).toString('utf8');
    store.indexSource(text,source);
    for (const match of text.matchAll(/@@E04:(?:uri|base64):(a\d+)@@/g)) {
      const asset=m.assets[match[1]];
      if (!asset) throw Error('Missing declared media: '+match[1]);
      store.add(read(root,asset.path),asset.mime,source);
    }
  }
  let html = store.externalize(standalone.bytes.toString('utf8'));
  const assets = store.list();
  const index = {schemaVersion:1,gameVersion:m.gameVersion,assets};
  html = injectAssetIndex(html,index);
  const bytes = Buffer.from(html);
  const result = {
    bytes,index,media:store.records,sha256:sha(bytes),
    report:{schemaVersion:1,gameVersion:m.gameVersion,entryBytes:bytes.length,
      entryGzipBytes:gzipSync(bytes,{level:9}).length,entrySha256:sha(bytes),
      standaloneBytes:standalone.bytes.length,standaloneSha256:standalone.sha256,
      mediaFiles:assets.length,mediaBytes:assets.reduce((n,a)=>n+a.bytes,0),
      retainedInline:['Raw tank PCM','Small raw PNG strings used by synchronous image constructors'],
    },
  };
  if (/data:(?:audio|image|font)\/[A-Za-z0-9.+-]+;base64,[A-Za-z0-9+/]{128}/.test(html)) throw Error('Media remains embedded in online entry');
  // A generated reference must map to a supplied, content-verified file.
  for (const match of html.matchAll(/media\/[a-f0-9]{64}\.[a-z0-9]+/g)) {
    if (!store.records.has(match[0])) throw Error('Missing generated media: '+match[0]);
  }
  return result;
}

export function buildOnline(root=ROOT,output='dist/online') {
  validateRelative(output);
  const result = compileOnline(root);
  for (const item of result.media.values()) writeAtomic(root,output+'/'+item.url,item.content);
  writeAtomic(root,output+'/assets.json',Buffer.from(JSON.stringify(result.index,null,2)+'\n'));
  writeAtomic(root,output+'/play.html',result.bytes);
  writeAtomic(root,output+'/build.json',Buffer.from(JSON.stringify(result.report,null,2)+'\n'));
  return result;
}

if(process.argv[1] && path.resolve(process.argv[1])===fileURLToPath(import.meta.url)) {
  try {
    if(process.argv.length!==2) throw Error('Usage: node scripts/build-online.mjs');
    const result=buildOnline();
    console.log(JSON.stringify(result.report,null,2));
  } catch(error) {console.error(error.message);process.exitCode=1;}
}
