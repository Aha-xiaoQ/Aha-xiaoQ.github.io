/* Online resources share one priority queue; the offline build keeps embedded media. */
(() => {
  const node = document.getElementById('mario-assets');
  if (!node) return;
  const config = JSON.parse(node.textContent);
  const catalog = new Map(config.assets.map(item => [new URL(item.url, location.href).href, item]));
  const pending = new Map(), saved = new Map(), imageJobs = [], enabledGroups = new Map();
  const queue = [], mediaURLs = new Map();
  let active = 0, order = 0, cacheJob = null;
  const rank = value => typeof value === 'number' ? value : value === 'background' ? 1 : 10;
  const urlOf = source => new URL(source, location.href).href;
  const entry = source => catalog.get(urlOf(source));
  const digest = async bytes => Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', bytes)), n => n.toString(16).padStart(2, '0')).join('');
  const valid = async (bytes, item) => bytes.byteLength === item.bytes && (!crypto.subtle || await digest(bytes) === item.sha256);
  const cache = () => cacheJob ||= Promise.resolve().then(() => caches.open('mario-media-v1')).catch(() => null);
  const stats = {downloaded: 0, cacheHits: 0, requests: 0, failures: 0};
  async function download(item, url) {
    const bucket = await cache();
    if (bucket) try {
      const response = await bucket.match(url);
      if (response) {
        const bytes = await response.arrayBuffer();
        if (await valid(bytes, item)) { stats.cacheHits++; return bytes; }
        await bucket.delete(url);
      }
    } catch { /* Storage is optional, including private browsing. */ }
    const controller = new AbortController();
    let timer;
    const arm = () => { clearTimeout(timer); timer = setTimeout(() => controller.abort(), 20000); };
    arm();
    try {
      stats.requests++;
      const response = await fetch(url, {signal: controller.signal, credentials: 'omit', cache: 'force-cache'});
      if (!response.ok) throw Error('素材下载失败，请重试');
      const reader = response.body.getReader(), parts = [];
      let size = 0;
      while (true) {
        const {done, value} = await reader.read();
        if (done) break;
        size += value.byteLength;
        if (size > item.bytes) { await reader.cancel(); throw Error('素材大小不符'); }
        parts.push(value); stats.downloaded += value.byteLength; arm();
      }
      const bytes = new Uint8Array(size);
      let offset = 0;
      for (const part of parts) { bytes.set(part, offset); offset += part.length; }
      if (!await valid(bytes, item)) throw Error('素材校验失败，请重试');
      if (bucket) try { await bucket.put(url, new Response(bytes, {headers: {'Content-Type': item.mime}})); } catch {}
      return bytes.buffer;
    } finally { clearTimeout(timer); }
  }
  function pump() {
    queue.sort((a, b) => b.priority - a.priority || a.order - b.order);
    // Leave a slot for a foreground selection while a background file downloads.
    while (queue.length && active < 3 && (queue[0].priority >= 10 || active < 2)) {
      const job = queue.shift(); active++;
      download(job.item, job.url).then(bytes => {
        saved.set(job.url, bytes); pending.delete(job.url); active--; job.resolve(bytes); pump();
      }, error => {
        stats.failures++; pending.delete(job.url); active--; job.reject(error); pump();
      });
    }
  }
  function read(source, options = {}) {
    const url = urlOf(source), item = catalog.get(url), priority = rank(options.priority);
    if (!item) return Promise.reject(Error('未登记的游戏素材'));
    if (saved.has(url)) return Promise.resolve(saved.get(url));
    if (pending.has(url)) { const job = pending.get(url); job.priority = Math.max(job.priority, priority); pump(); return job.promise; }
    const job = {url, item, priority, order: order++};
    job.promise = new Promise((resolve, reject) => { job.resolve = resolve; job.reject = reject; });
    pending.set(url, job); queue.push(job); pump(); return job.promise;
  }
  function image(im, source, group = 'base') {
    const job = {im, source, group, complete: false, running: null};
    im.marioReady = new Promise(resolve => { job.resolve = resolve; });
    job.start = (priority = 10) => {
      if (job.complete) return Promise.resolve(im);
      if (job.running) { read(source, {priority}).catch(() => {}); return job.running; }
      job.running = read(source, {priority}).then(async bytes => {
        const url = URL.createObjectURL(new Blob([bytes], {type: entry(source).mime}));
        try { im.src = url; await im.decode(); job.complete = true; job.resolve(im); return im; }
        finally { URL.revokeObjectURL(url); }
      }).finally(() => { job.running = null; });
      return job.running;
    };
    imageJobs.push(job);
    if (enabledGroups.has(group)||new URL(location.href).searchParams.has('legacy')) job.start(enabledGroups.get(group)||10).catch(() => {});
    return im.marioReady;
  }
  function ensure(groups, {priority = 'foreground'} = {}) {
    groups = Array.isArray(groups) ? groups : [groups];
    const n = rank(priority);
    for (const group of groups) enabledGroups.set(group, Math.max(n, enabledGroups.get(group) || 0));
    return Promise.all(imageJobs.filter(job => groups.includes(job.group)).map(job => job.start(n)));
  }
  function mediaSource(source) {
    const url=urlOf(source);if(!catalog.has(url)||!saved.has(url))return source;
    if(!mediaURLs.has(url))mediaURLs.set(url,URL.createObjectURL(new Blob([saved.get(url)],{type:catalog.get(url).mime})));
    return mediaURLs.get(url);
  }
  const prefetch = (sources, options = {priority: 'background'}) => Promise.all([...new Set(sources)].filter(source => entry(source)).map(source => read(source, options)));
  window.MarioAssets = Object.freeze({read, image, ensure, prefetch, mediaSource, has: source => !!entry(source),
    groupsReady: groups => imageJobs.filter(job => groups.includes(job.group)).every(job => job.complete),
    stats: () => ({...stats, active, queued: queue.length, resident: saved.size, images: imageJobs.map(job => ({group: job.group, ready: job.complete, source:job.source, bytes:entry(job.source)?.bytes}))})});
})();
function gameImage(image, source, group = 'base') {
  if (window.MarioAssets?.has(source)) return MarioAssets.image(image, source, group);
  image.src = source;
  const ready = image.decode();
  ready.catch(() => {});
  image.marioReady = ready;
  return ready;
}
function gameImageReady(image) { return image.marioReady || image.decode(); }

function gameMediaSource(source){return window.MarioAssets?.mediaSource(source)||source;}
