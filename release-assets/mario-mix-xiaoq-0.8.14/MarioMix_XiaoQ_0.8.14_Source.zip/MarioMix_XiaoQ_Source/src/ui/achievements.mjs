import {loadPixelFont} from './chill-font.mjs';

const HEROES=[['all','全员'],['mario','马里奥'],['bill','魂斗罗'],['megaman','洛克人'],['ryu','忍龙'],['tank','坦克大战'],['sandboxTrio','泰拉瑞亚'],['ori','奥日'],['sonic','索尼克'],['jackal','赤色要塞']];
const CHAPTERS=[['all','全部回忆'],['journey','冒险纪念'],['hero','英雄绝活'],['numbers','数字挑战'],['secret','秘密档案']];
const STATES=[['all','全部'],['earned','已收藏'],['waiting','待发现']];
const SPECIAL_HERO={
 'mario-fire-bowser':'mario','water-fire':'mario','jackal-boat':'jackal',
 'mario-thanks':'mario','mario-wall-clip':'mario','bill-clean-castle':'bill','bill-three-guns':'bill','bad-trade':'bill','falling-tank':'bill',
 'rock-boss':'megaman','roof-rail':'ryu','ryu-gardener':'ryu','ryu-dog-ambushed':'ryu','ryu-dog-defeated':'ryu','tank-water':'tank','tank-triple':'tank',
 'slime-stomp':'sandboxTrio','ori-return':'ori','sonic-minute':'sonic','sonic-star':'sonic',
 'rescue-five':'jackal','bomber-down':'jackal','rooftop-rescue':'jackal','jackal-escort':'jackal',
};
export function achievementCollectionEntry(a){
 const hero=SPECIAL_HERO[a.id]||HEROES.slice(1).find(([id])=>['arsenal-','combat-','challenge-'].some(prefix=>a.id===prefix+id))?.[0]||null;
 const chapter=a.secret?'secret':hero?'hero':a.metric?'numbers':'journey',concealed=!!a.secret&&!a.unlocked;
 return {...a,hero,chapter,concealed,title:concealed?'尚未翻开的那一页':a.title,description:concealed?'有些回忆，要亲自碰见才算数。':a.description};
}
export function filterAchievementCollection(items,{chapter='all',hero='all',state='all'}={}){
 return items.map(achievementCollectionEntry).filter(a=>(chapter==='all'||a.chapter===chapter)&&(hero==='all'||a.hero===hero)&&(state==='all'||(state==='earned'?a.unlocked:!a.unlocked)));
}

// Geometric seals belong to the collection UI, never the game's sprite atlas.
function medal(doc,kind='journey',earned=false){
 const svg=doc.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('viewBox','0 0 32 40');svg.setAttribute('aria-hidden','true');svg.setAttribute('class','medal'+(earned?' earned':''));
 const path=(d,cls)=>{const p=doc.createElementNS(svg.namespaceURI,'path');p.setAttribute('d',d);p.setAttribute('class',cls);return p;};
 svg.append(path('M7 23H15V39L11 35 7 39ZM17 23H25V39L21 35 17 39Z','ribbon'),path('M8 1H24V4H28V8H31V24H28V28H24V31H8V28H4V24H1V8H4V4H8Z','rim'),path('M9 5H23V8H27V23H23V27H9V23H5V9H9Z','face'));
 const symbols={journey:'M10 10H22V16H13V24H10ZM13 12V14H20V12Z',hero:'M17 8H22L17 14H23L12 24 15 17H9Z',numbers:'M12 9H21V12H24V21H21V24H12V21H9V12H12ZM14 12V21H19V12Z',secret:'M10 9H22V12H24V16H21V19H17V21H14V17H18V14H20V12H13V15H10ZM14 23H17V26H14Z',complete:'M8 11L13 15 16 9 19 15 24 11V23H8ZM10 25H22V27H10Z'};
 const mark=path(symbols[kind]||symbols.journey,'mark');mark.setAttribute('fill-rule','evenodd');svg.append(mark);return svg;
}

export function createAchievementUi(host,{store,onClose}){
 const doc=host.ownerDocument,toast=doc.createElement('aside'),pane=doc.createElement('section');
 toast.id='mlAchievementToast';toast.hidden=true;toast.setAttribute('role','status');toast.setAttribute('aria-live','polite');
 pane.id='mlAchievements';pane.hidden=true;pane.setAttribute('role','dialog');pane.setAttribute('aria-modal','true');pane.setAttribute('aria-labelledby','mlAchievementTitle');host.append(toast,pane);
 const style=doc.createElement('style');style.textContent=`
 #mlAchievementButton{width:100%;min-height:44px;margin:0 0 14px;border:2px solid #ffe19b;border-radius:0;background:#923b0b;color:#fff4d6;font:400 17px/1.4 ChillBitmap16,monospace;box-shadow:3px 3px #000;cursor:pointer}#mlAchievementButton:focus-visible,#mlAchievementButton:hover{background:#b44c0c;outline:2px solid white;outline-offset:2px}
 #mlAchievementToast,#mlAchievements{font-family:ChillBitmap16,monospace;box-sizing:border-box;color:#fff4d6;position:absolute;z-index:35}
 #mlAchievementToast *,#mlAchievements *{box-sizing:border-box}#mlAchievementToast[hidden],#mlAchievements[hidden]{display:none!important}
 #stage[data-achievement-open=true]{z-index:40}
 #mlAchievementToast{right:12px;bottom:12px;width:320px;max-width:calc(100% - 24px);padding:10px 14px;border:2px solid #f3ce79;background:#171c29;box-shadow:4px 4px #07090f;pointer-events:none;display:flex;gap:12px;align-items:center;font-size:16px;animation:mlStampIn .22s steps(4,end)}
 #mlAchievementToast small{display:block;color:#edcb81;font-size:12px;margin-bottom:5px;letter-spacing:1px}#mlAchievementToast strong{font-weight:400;line-height:1.5;overflow-wrap:anywhere}
 #mlAchievements{inset:3%;padding:0;background:#141925;border:3px solid #e7bd67;box-shadow:6px 6px #080b10;display:flex;flex-direction:column;text-align:left;pointer-events:auto;overflow:hidden;container-type:inline-size}
 #mlAchievements .book-head{background:#8c390e;border-bottom:3px solid #d68a43;padding:18px 22px 14px;margin:0;display:flex;align-items:center;gap:16px;flex:none}
 #mlAchievements .book-title{flex:1;min-width:0}#mlAchievements h2{font:400 25px/1.4 ChillBitmap16,monospace;margin:0 0 5px;letter-spacing:2px}#mlAchievements .subtitle{margin:0;font-size:13px;line-height:1.5;color:#f2cf9d}
 #mlAchievements .collection-total{text-align:right;font-size:14px;white-space:nowrap}#mlAchievements .collection-total strong{font:400 24px/1.5 ChillBitmap16,monospace;display:block;color:#fff0bb;font-variant-numeric:tabular-nums}
 #mlAchievements .total-track{height:5px;background:#502909;display:block;margin-top:6px}#mlAchievements .total-track i{display:block;height:100%;background:#ffe19b}
 #mlAchievements .filters{display:flex;gap:10px;flex-wrap:wrap;padding:14px 22px 12px;border-bottom:1px solid #655537;flex:none}
 #mlAchievements button{position:static;font:400 14px/1.4 ChillBitmap16,monospace;border:1px solid #76644d;border-radius:0;background:#202737;color:#f4dfb8;padding:9px 12px;min-height:40px;cursor:pointer;text-align:left;box-shadow:none;max-width:100%;white-space:normal}
 #mlAchievements button:hover{background:#303b4d}#mlAchievements button:focus,#mlAchievements .shelf:focus{outline:2px solid #fff2be;outline-offset:-4px}
 #mlAchievements .filter{flex:1;min-width:120px;display:flex;justify-content:space-between;align-items:center;gap:12px}#mlAchievements .filter small{display:block;color:#b0b6bd;font:400 11px/1.4 ChillBitmap16,monospace;margin-bottom:3px}#mlAchievements .filter .arrows{color:#cfb072;letter-spacing:5px;white-space:nowrap}
 #mlAchievements .filter[data-filtered=true]{border-color:#e7bd67;background:#3b321f}#mlAchievements .filter[data-filtered=true] small{color:#f3cf7c}
 #mlAchievements .shelf-heading{display:flex;justify-content:space-between;gap:12px;flex:none;padding:10px 22px;font-size:12px;color:#c9ba9e;border-bottom:1px solid #343d4b}
 #mlAchievements .shelf{overflow:auto;overscroll-behavior:contain;flex:1;min-height:0;scrollbar-width:thin;scrollbar-color:#bc9d63 #141925;scrollbar-gutter:stable;padding:0 18px 0 22px}
 #mlAchievements article{display:grid;grid-template-columns:24px 42px minmax(0,1fr) 74px;gap:12px;align-items:center;padding:15px 0;border-bottom:1px solid #343d4b;min-height:98px}
 #mlAchievements .serial{color:#9b9588;font-size:12px;font-variant-numeric:tabular-nums}#mlAchievements .entry-copy{min-width:0}#mlAchievements h3{font:400 18px/1.4 ChillBitmap16,monospace;margin:0 0 6px;overflow-wrap:anywhere}#mlAchievements .description{font:400 14px/1.55 ChillBitmap16,monospace;margin:0;color:#c5c5c2;overflow-wrap:anywhere}
 #mlAchievements article.locked h3{color:#c7c7bf}#mlAchievements article.secret-locked h3{font-size:16px;color:#b5b5ad}#mlAchievements article.secret-locked .description{color:#9dabb5}#mlAchievements article.unlocked h3{color:#ffe29a}#mlAchievements article.complete{border-bottom-color:#c3a45c}
 #mlAchievements .stamp{text-align:right;font:400 12px/1.5 ChillBitmap16,monospace;color:#929eaf}#mlAchievements .unlocked .stamp{color:#e5c075}#mlAchievements .stamp time{display:block;font-size:10px;line-height:1.8;color:#aeb4bc}
 #mlAchievements .progress-line{display:flex;align-items:center;gap:10px;margin-top:8px;font:400 12px/1.4 ChillBitmap16,monospace;color:#e2cd9e}#mlAchievements progress{appearance:none;width:100px;max-width:45%;height:6px;border:0;background:#313c4a}#mlAchievements progress::-webkit-progress-bar{background:#313c4a}#mlAchievements progress::-webkit-progress-value{background:#c5a76c}#mlAchievements progress::-moz-progress-bar{background:#c5a76c}
 #mlAchievements .empty{padding:35px 5px;text-align:center;color:#c9ba9e;font-size:15px;line-height:1.8;white-space:pre-line}#mlAchievements .book-foot{padding:12px 22px;border-top:2px solid #655537;display:flex;gap:12px;align-items:center;justify-content:space-between;flex:none;background:#1c2230}#mlAchievements .control-hint{font-size:11px;line-height:1.7;color:#b4b4b0;white-space:pre-line}#mlAchievements .close{background:#923b0b;border:2px solid #edc777;min-width:92px;text-align:center;padding:8px 15px}
 #mlAchievementToast .medal,#mlAchievements .medal{width:34px;height:43px;flex:none;overflow:visible;shape-rendering:crispEdges}#mlAchievements .book-head .medal{width:38px;height:48px}
 #mlAchievementToast .rim,#mlAchievements .rim{fill:#738091}#mlAchievementToast .face,#mlAchievements .face{fill:#293445}#mlAchievementToast .mark,#mlAchievements .mark{fill:#8d99a8}#mlAchievementToast .ribbon,#mlAchievements .ribbon{fill:#374757}
 #mlAchievementToast .earned .rim,#mlAchievements .earned .rim{fill:#edcc7c}#mlAchievementToast .earned .face,#mlAchievements .earned .face{fill:#985223}#mlAchievementToast .earned .mark,#mlAchievements .earned .mark{fill:#fff0bb}#mlAchievementToast .earned .ribbon,#mlAchievements .earned .ribbon{fill:#b3472b}
 @keyframes mlStampIn{from{transform:translateY(8px);opacity:0}to{transform:translateY(0);opacity:1}}
 @media(prefers-reduced-motion:reduce){#mlAchievementToast{animation:none}}
 @media(max-width:600px){#mlAchievements{position:fixed;inset:12px;z-index:100}#mlAchievementToast{font-size:14px;bottom:8px;right:8px;width:280px}}
 @container(max-width:540px){#mlAchievements .book-head{padding:12px;gap:10px}#mlAchievements h2{font-size:20px;letter-spacing:0}#mlAchievements .subtitle{font-size:11px}#mlAchievements .book-head .medal{display:none}#mlAchievements .collection-total{font-size:11px}#mlAchievements .collection-total strong{font-size:19px}#mlAchievements .filters{padding:9px 12px;gap:6px}#mlAchievements .filter{min-width:82px;padding:7px;font-size:12px;gap:4px}#mlAchievements .filter .arrows{font-size:10px;letter-spacing:0}#mlAchievements .filter small{font-size:10px}#mlAchievements .shelf-heading{padding:8px 12px;font-size:10px}#mlAchievements .shelf{padding:0 10px 0 12px}#mlAchievements article{grid-template-columns:29px minmax(0,1fr);gap:10px;min-height:86px;padding:12px 0}#mlAchievements .serial{display:none}#mlAchievements article>.medal{width:27px;height:34px}#mlAchievements h3{font-size:15px}#mlAchievements .description{font-size:12px}#mlAchievements .stamp{grid-column:2;text-align:left;font-size:10px;margin-top:-6px}#mlAchievements .stamp time{display:inline;margin-left:8px}#mlAchievements .book-foot{padding:9px 12px}#mlAchievements .control-hint{font-size:10px}#mlAchievements .close{font-size:13px;min-width:72px}}
 @media(max-height:520px){#mlAchievements .book-head{padding:8px 14px}#mlAchievements .book-head .medal,#mlAchievements .subtitle{display:none}#mlAchievements h2{font-size:18px;margin:0}#mlAchievements .collection-total strong{display:inline;font-size:18px;margin-right:8px}#mlAchievements .total-track{display:none}#mlAchievements .filters{padding:6px 14px}#mlAchievements .filter small{display:none}#mlAchievements .shelf-heading{padding-top:5px;padding-bottom:5px}#mlAchievements .book-foot{padding:6px 14px}}
 `;doc.head.append(style);if(!globalThis.MarioAssets)loadPixelFont().catch(()=>{});
 const el=(tag,text='',cls='')=>{const n=doc.createElement(tag);n.textContent=text;if(cls)n.className=cls;return n;};
 let ticks=0,returnFocus=null,shelf=null,filters={chapter:'all',hero:'all',state:'all'},filterButtons=[],closeButton=null;
 const focusables=()=>[...filterButtons,shelf,closeButton].filter(Boolean);
 const localDate=at=>{if(!Number.isFinite(at)||at<=0)return '';const d=new Date(at);return d.getFullYear()+'.'+String(d.getMonth()+1).padStart(2,'0')+'.'+String(d.getDate()).padStart(2,'0');};
 function renderRows(){
  const items=filterAchievementCollection(store.list(),filters);shelf.replaceChildren();shelf.scrollTop=0;
  pane.querySelector('.shelf-heading').replaceChildren(el('span',CHAPTERS.find(([id])=>id===filters.chapter)[1]+' · '+HEROES.find(([id])=>id===filters.hero)[1]),el('span',items.filter(a=>a.unlocked).length+' / '+items.length+' 已收藏'));
  for(const [i,a]of items.entries()){
   const row=el('article','',(a.unlocked?'unlocked':'locked')+(a.concealed?' secret-locked':'')+(a.id==='all-achievements'?' complete':''));row.dataset.achievement=a.id;
   row.append(el('span',String(i+1).padStart(2,'0'),'serial'),medal(doc,a.id==='all-achievements'?'complete':a.concealed?'secret':a.chapter,a.unlocked));
   const copy=el('div','','entry-copy');copy.append(el('h3',a.title),el('p',a.description,'description'));
   if(a.metric&&!a.concealed&&!a.unlocked){const line=el('div','','progress-line'),progress=el('progress');progress.max=a.target;progress.value=a.progress||0;progress.setAttribute('aria-label',a.title+'的进度');line.append(progress,el('span',(a.progress||0)+' / '+a.target));copy.append(line);}
   const stamp=el('div',a.unlocked?'已收藏':a.concealed?'未发现':'未达成','stamp');if(a.unlocked&&a.at){const date=el('time',localDate(a.at));date.dateTime=new Date(a.at).toISOString();stamp.append(date);}row.append(copy,stamp);shelf.append(row);
  }
  if(!items.length)shelf.append(el('p',filters.state==='earned'?'这一册还没有盖章。\n再冒险一次，带点故事回来。':'这一页暂时没有记录。\n换个分册或伙伴看看。','empty'));
 }
 function cycle(button,delta=1){const {filter,options}=button._achievementFilter,index=options.findIndex(([id])=>id===filters[filter]);filters[filter]=options[(index+delta+options.length)%options.length][0];updateFilter(button);renderRows();}
 function updateFilter(button){const {filter,options,label}=button._achievementFilter,current=options.find(([id])=>id===filters[filter])[1];button.replaceChildren();const copy=el('span');copy.append(el('small',label),el('span',current));button.append(copy,el('span','‹ ›','arrows'));button.dataset.filtered=String(filters[filter]!=='all');button.setAttribute('aria-label',label+'：'+current+'。左右切换，确认下一项。');}
 function close(){if(pane.hidden)return;pane.hidden=true;host.removeAttribute('data-achievement-open');if(ticks>0)toast.hidden=false;onClose?.();if(returnFocus?.isConnected&&(pane.contains(doc.activeElement)||doc.activeElement===doc.body))returnFocus.focus({preventScroll:true});}
 function show(){
  loadPixelFont().catch(()=>{});
  returnFocus=doc.activeElement;host.setAttribute('data-achievement-open','true');toast.hidden=true;pane.replaceChildren();filterButtons=[];
  const head=el('header','','book-head'),title=el('div','','book-title'),heading=el('h2','冒险收藏册');heading.id='mlAchievementTitle';title.append(heading,el('p','每一枚勋章，都有一段操作。','subtitle'));
  const total=el('div','','collection-total');total.append(el('strong',store.count()+' / '+store.list().length),el('span','回忆已收藏'));const track=el('span','','total-track'),fill=el('i');fill.style.width=(store.count()/Math.max(1,store.list().length)*100)+'%';track.append(fill);total.append(track);head.append(medal(doc,'complete',true),title,total);pane.append(head);
  const controls=el('div','','filters');for(const [filter,options,label] of [['chapter',CHAPTERS,'分册'],['hero',HEROES,'伙伴'],['state',STATES,'状态']]){const button=el('button','','filter');button.type='button';button._achievementFilter={filter,options,label};button.onclick=()=>cycle(button);updateFilter(button);filterButtons.push(button);controls.append(button);}pane.append(controls);
  const context=el('div','','shelf-heading');context.setAttribute('aria-live','polite');pane.append(context);shelf=el('div','','shelf');shelf.tabIndex=0;shelf.setAttribute('aria-label','成就清单，上下浏览');pane.append(shelf);
  const foot=el('footer','','book-foot');foot.append(el('span','↑ ↓ 浏览　← → 筛选\nA 确认　B / Esc 返回','control-hint'));closeButton=el('button','返回','close');closeButton.type='button';closeButton.onclick=close;foot.append(closeButton);pane.append(foot);renderRows();pane.hidden=false;shelf.focus({preventScroll:true});
 }
 function move(delta){shelf?.scrollBy({top:delta*112,behavior:'instant'});}
 function navigate(dx=0,dy=0){if(pane.hidden)return;const focused=doc.activeElement,all=focusables(),index=all.indexOf(focused);
  if(focused===shelf&&dy){const end=dy<0?shelf.scrollTop<=0:shelf.scrollTop+shelf.clientHeight>=shelf.scrollHeight-2;if(!end){move(dy);return;}}
  if(dx&&focused?._achievementFilter){cycle(focused,Math.sign(dx));return;}
  const delta=Math.sign(dy||dx);if(delta)all[(Math.max(0,index)+delta+all.length)%all.length].focus({preventScroll:true});
 }
 function confirm(){if(pane.hidden)return;const focused=doc.activeElement;if(focused?._achievementFilter||focused===closeButton)focused.click();else closeButton.focus({preventScroll:true});}
 // Tab is intentionally not a gameplay key; trap it locally in the modal.
 pane.addEventListener('keydown',e=>{if(e.code!=='Tab'||pane.hidden)return;e.preventDefault();e.stopPropagation();const all=focusables(),i=all.indexOf(doc.activeElement);all[(Math.max(0,i)+(e.shiftKey?-1:1)+all.length)%all.length].focus({preventScroll:true});});
 // The whole open book is a browsing surface. Its header and footer route
 // vertical wheels to the shelf; wheels already over rows stay native, once.
 // Keep browser zoom and horizontal gestures under browser ownership.
 pane.addEventListener('wheel',e=>{
  if(pane.hidden||!shelf||e.defaultPrevented||e.ctrlKey||e.metaKey||!e.deltaY||Math.abs(e.deltaX)>=Math.abs(e.deltaY)||shelf.contains(e.target))return;
  const unit=e.deltaMode===1?24:e.deltaMode===2?shelf.clientHeight:1;
  e.preventDefault();e.stopPropagation();shelf.scrollBy({top:e.deltaY*unit,behavior:'instant'});
 },{passive:false});
 return {show,active:()=>!pane.hidden,close,move,navigate,confirm,
  key(e){if(pane.hidden)return false;if(e.type!=='keydown')return true;const k=e.code;
   if(['Escape','KeyP','KeyK'].includes(k)&&!e.repeat)close();
   else if(k==='Tab'){const all=focusables(),i=all.indexOf(doc.activeElement);all[(Math.max(0,i)+(e.shiftKey?-1:1)+all.length)%all.length].focus({preventScroll:true});}
   else if(['Enter','Space','KeyZ'].includes(k)&&!e.repeat)confirm();
   else if(['ArrowDown','KeyS'].includes(k))navigate(0,1);else if(['ArrowUp','KeyW'].includes(k))navigate(0,-1);
   else if(['ArrowLeft','KeyA'].includes(k))navigate(-1,0);else if(['ArrowRight','KeyD'].includes(k))navigate(1,0);
   e.preventDefault?.();return true;
  },
  tick(){if(doc.hidden||!pane.hidden)return;if(ticks>0){if(--ticks===0)toast.hidden=true;return;}const a=store.next();if(!a)return;const entry=achievementCollectionEntry({...a,unlocked:true});toast.replaceChildren(medal(doc,a.id==='all-achievements'?'complete':entry.chapter,true));const copy=el('div');copy.append(el('small','又多了一段回忆 · 成就解锁'),el('strong',a.title));toast.append(copy);toast.hidden=false;ticks=240;},
 };
}
