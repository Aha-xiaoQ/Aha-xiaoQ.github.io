import {loadPixelFont} from './chill-font.mjs';
import {creditsAvatar} from './credits-avatar.mjs';
import {summarizeRun,runTime} from '../campaign/run-statistics.mjs';

// Adapted from the supplied Map Workshop 1.10.2 campaign-ui presentation.
// A host-owned screen controls progression; this view never changes the run.
export function createCampaignEnding(host,{profiles,onCredits,onMenu,onReplay,onBonus,onAchievements,canBonus=()=>false}){
  const pane=document.createElement('section');pane.id='mlEnding';pane.hidden=true;
  pane.setAttribute('role','dialog');pane.setAttribute('aria-modal','true');
  host.append(pane);
  const style=document.createElement('style');style.textContent=`
  #mlEnding{position:absolute;inset:0;z-index:20;box-sizing:border-box;container-type:inline-size;overflow:hidden;background:#080910;color:#fff;font-family:ChillBitmap16,ChillBitmap,monospace;pointer-events:auto;text-align:center}
  #mlEnding[hidden]{display:none!important}#mlEnding *{box-sizing:border-box}
  #mlEnding .ending-page{height:100%;display:flex;flex-direction:column;padding:5cqw 6cqw 3cqw;gap:2cqw;overflow:hidden}
  #mlEnding h2{font:400 4.6cqw/1.3 ChillBitmap16,monospace;color:#ffe8a3;margin:0}
  #mlEnding p{display:block;font:400 2.5cqw/1.6 ChillBitmap16,monospace;margin:0}
  #mlEnding .ending-subtitle{color:#aaaec9}
  #mlEnding .run-body{flex:1;min-height:0;overflow:auto;scrollbar-width:thin;scrollbar-gutter:stable;padding-right:2.5cqw;margin-right:-2.5cqw}
  #mlEnding .run-metrics{display:grid;grid-template-columns:1fr 1fr;gap:1.8cqw 5cqw;padding:2cqw 0 3cqw}
  #mlEnding .run-metric{display:flex;justify-content:space-between;align-items:center;font-size:2.65cqw;line-height:1.6;gap:1cqw}
  #mlEnding .run-metric span{color:#b9bdd0}#mlEnding strong{font-weight:400;color:#fff2ca}
  #mlEnding table{width:100%;border-collapse:collapse;font-size:2.5cqw;line-height:1.8}
  #mlEnding th{color:#b9bdd0;font-weight:400;border-bottom:1px solid #ffffff38}#mlEnding td{padding:1cqw .5cqw;border-bottom:1px solid #ffffff18;white-space:nowrap}
  #mlEnding .ending-actions{display:flex;justify-content:center;flex-wrap:wrap;gap:2cqw;flex:none;padding-top:2cqw}
  #mlEnding button{position:static;width:auto;min-height:6cqw;border:1px solid #7d7892;border-radius:0;background:#252333;color:#fff;font:400 2.5cqw/1.3 ChillBitmap16,monospace;padding:1.7cqw 2.6cqw;cursor:pointer}
  #mlEnding button:focus{outline:2px solid #ffe29c;outline-offset:2px;color:#ffe29c}
  #mlEnding .credits-page{background:radial-gradient(ellipse at 50% 10%,#28243c,#101015 65%)}
  #mlEnding .credits-window{flex:1;min-height:0;overflow:hidden;mask-image:linear-gradient(transparent,#000 8%,#000 92%,transparent)}
  #mlEnding .credits-roll{padding:0 1cqw 4cqw;will-change:transform}
  #mlEnding .credits-roll h3{font-size:3.5cqw;line-height:1.5;font-weight:400;margin:2cqw 0}
  #mlEnding .credit-group{padding:5cqw 0;border-bottom:1px solid #ffffff20}
  #mlEnding .credit-label{color:#b8b4ca;margin:2cqw 0}
  #mlEnding .credits-avatar{display:block;width:20cqw;height:20cqw;object-fit:contain;image-rendering:pixelated;margin:3cqw auto}
  #mlEnding .credits-window.is-static{overflow:auto;mask-image:none}#mlEnding .credits-window.is-static .credits-roll{transform:none!important;will-change:auto}
  `;host.ownerDocument.head.append(style);
  const ready=globalThis.MarioAssets?Promise.resolve():loadPixelFont().catch(error=>console.warn('Ending pixel font',error));
  let screen=null,ticks=0,roll=null,windowNode=null,staticCredits=false,campaignSpan='',bonusButton=null,bonusReady=false;
  const element=(tag,text,cls)=>{const n=document.createElement(tag);if(text!==undefined)n.textContent=text;if(cls)n.className=cls;return n;};
  const buttons=()=>[...pane.querySelectorAll('button')].filter(b=>!b.hidden);
  // The normal page can scroll around its fixed-ratio game surface. Reveal
  // the ending and its focused action instead of leaving the action clipped.
  const focusFirst=()=>{pane.scrollIntoView({block:'nearest',inline:'nearest'});buttons()[0]?.focus();};
  function button(label,action,parent){const b=element('button',label);b.type='button';b.onclick=action;parent.append(b);return b;}
  function base(title,kind){loadPixelFont().catch(()=>{});pane.hidden=false;pane.setAttribute('aria-label',title);pane.replaceChildren();const page=element('div',undefined,'ending-page '+kind);pane.append(page);return page;}
  function showStatistics(run){
    screen='statistics';const summary=summarizeRun(run),page=base('本次冒险统计','statistics-page');
    campaignSpan='WORLD '+run.levelOrder[0]+' — '+run.levelOrder.at(-1);
    page.append(element('h2','ADVENTURE COMPLETE'),element('p',summary.mode==='random'?'混合马里奥 · 随机冒险':'混合马里奥 · '+campaignSpan,'ending-subtitle'));
    const body=element('div',undefined,'run-body'),metrics=element('div',undefined,'run-metrics');body.tabIndex=0;
    const values=[['最终得分',String(summary.score).padStart(6,'0')],['剩余生命',summary.lives],['剩余金币',summary.coins],[summary.partial?'记录用时':'游玩用时',runTime(summary.frames)],['死亡次数',summary.deaths],['重试次数',summary.retries],['继续次数',summary.continues],['隐藏挑战完成',summary.challenges]];
    for(const [label,value]of values){const row=element('div',undefined,'run-metric');row.append(element('span',label),element('strong',String(value)));metrics.append(row);}body.append(metrics);
    const table=element('table'),head=element('thead'),tr=element('tr');for(const x of ['关卡','角色','用时','死亡'])tr.append(element('th',x));head.append(tr);table.append(head);
    const tbody=element('tbody');for(const row of summary.levels){const tr=element('tr');for(const v of [row.level,profiles.find(p=>p.id===row.hero)?.title||row.hero,runTime(row.frames),row.deaths])tr.append(element('td',String(v)));tbody.append(tr);}table.append(tbody);body.append(table);
    if(summary.partial)body.append(element('p','本次统计从更新后继续时开始。','ending-subtitle'));
    page.append(body);const actions=element('div',undefined,'ending-actions');button('确认',onCredits,actions);if(onAchievements)button('查看成就',onAchievements,actions);page.append(actions);focusFirst();return summary;
  }
  function showCredits(){
    screen='credits';ticks=0;bonusReady=false;staticCredits=matchMedia('(prefers-reduced-motion: reduce)').matches;
    const page=base('通关制作信息','credits-page');windowNode=element('div',undefined,'credits-window');windowNode.tabIndex=0;roll=element('div',undefined,'credits-roll');
    roll.append(element('h2','恭喜通关！'),element('p','与伙伴一起，走过这段冒险。'));
    const groups=[
      ['项目策划 · 制作与测试',['在下_小Q']],
      ['AI 编程协作',['OpenAI · Codex','GPT-6 Astra']],
      ['地图制作与接入',['Pixel Workshop · 地图工坊','混合马里奥 · '+campaignSpan]],
      ['原作角色 · 美术 · 音乐',[...new Set(profiles.map(p=>p.credits||p.selection.origin))]],
      ['复刻参考与素材整理',['umaim/Mario · FullScreenMario','详细来源见「素材与制作」','非官方同人作品']],
      ['中文像素字体',['寒蝉点阵体 · ChillBitmap','Warren2060 / 寒蝉字型']],
    ];
    const intro=element('section',undefined,'credit-group'),img=element('img',undefined,'credits-avatar');if(globalThis.gameImage)globalThis.gameImage(img,creditsAvatar,'ending');else img.src=creditsAvatar;img.alt='在下_小Q像素头像';intro.append(img,element('h3','在下_小Q'));roll.append(intro);
    for(const [label,lines]of groups){const group=element('section',undefined,'credit-group');group.append(element('p',label,'credit-label'));for(const line of lines)group.append(element('p',line));roll.append(group);}
    const end=element('section',undefined,'credit-group');end.append(element('h2','下一段冒险，再见！'),element('p','感谢每一位试玩、反馈与创作的玩家。'),element('p','aha-xiaoq.github.io'));roll.append(end);windowNode.append(roll);page.append(windowNode);
    const actions=element('div',undefined,'ending-actions');
    bonusButton=button('继续下一关',()=>{if(bonusReady&&canBonus())onBonus?.();},actions);bonusButton.hidden=true;
    button('完整名单',()=>{staticCredits=true;windowNode.classList.add('is-static');windowNode.scrollTop=0;},actions);button('再玩一次',onReplay,actions);button('返回选人',onMenu,actions);page.append(actions);
    windowNode.addEventListener('scroll',()=>{if(staticCredits&&windowNode.scrollTop+windowNode.clientHeight>=windowNode.scrollHeight-2)revealBonus();});
    if(staticCredits)windowNode.classList.add('is-static');layoutRoll();focusFirst();
  }
  function revealBonus(){if(!bonusReady&&canBonus()&&bonusButton){bonusReady=true;bonusButton.hidden=false;bonusButton.focus({preventScroll:true});}}
  function layoutRoll(){if(!roll||!windowNode||staticCredits)return;const h=windowNode.clientHeight;const y=h*.6-(h*.6+roll.scrollHeight-h*.78)*Math.min(1,ticks/(60*48));roll.style.transform=`translateY(${y}px)`;if(ticks>=60*48)revealBonus();}
  function scrollCredits(delta,edge=false){if(screen!=='credits'||!staticCredits||!windowNode)return false;const max=Math.max(0,windowNode.scrollHeight-windowNode.clientHeight),at=windowNode.scrollTop;if(edge)windowNode.scrollTop=delta<0?0:max;else windowNode.scrollTop=Math.min(max,Math.max(0,at+delta*Math.max(48,windowNode.clientHeight*.35)));if(windowNode.scrollTop>=max-2)revealBonus();return Math.abs(windowNode.scrollTop-at)>1;}
  function move(delta,horizontal=false){if(!horizontal&&scrollCredits(delta))return;if(!horizontal&&screen==='statistics'){const body=pane.querySelector('.run-body');if(body&&body.scrollHeight>body.clientHeight){body.scrollBy({top:delta*Math.max(48,body.clientHeight*.35),behavior:'instant'});return;}}const a=buttons(),at=a.indexOf(document.activeElement);a[(Math.max(0,at)+delta+a.length)%a.length]?.focus();}
  function confirm(){const a=buttons();(a.includes(document.activeElement)?document.activeElement:a[0])?.click();}
  return {ready,showStatistics,showCredits,hide(){screen=null;pane.hidden=true;pane.replaceChildren();roll=windowNode=bonusButton=null;bonusReady=false;},
    focusAchievements(){const b=buttons().find(b=>b.textContent==='查看成就');b?.focus({preventScroll:true});},move,confirm,active:()=>!!screen,tick(){if(screen==='credits'&&!document.hidden){ticks++;layoutRoll();}},
    key(e){if(!screen)return false;if(e.type==='keyup')return true;if(e.repeat&&screen!=='statistics')return true;
      if(['Enter','Space','KeyK','KeyZ'].includes(e.code))confirm();
      else if(['PageUp','PageDown','Home','End'].includes(e.code))scrollCredits(['PageUp','Home'].includes(e.code)?-1:1,['Home','End'].includes(e.code));
      else if(['ArrowLeft','ArrowUp','KeyA','KeyW'].includes(e.code))move(-1,['ArrowLeft','KeyA'].includes(e.code));
      else if(['ArrowRight','ArrowDown','KeyD','KeyS'].includes(e.code))move(1,['ArrowRight','KeyD'].includes(e.code));
      else if(e.code==='Escape'&&screen==='credits')onMenu();return true;},
    view:()=>({screen,ticks,staticCredits,bonusReady})};
}
