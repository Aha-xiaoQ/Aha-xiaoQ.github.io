/* Shared preparation only: no actor creation, scene transition or music playback. */
const selectionTerraMusicSource=mainlineTerraActor.musicSource('boss');
const heroAudioCommon=['coin','jump_small','jump_super','bump','break','kick','flag','oneup','gameover','hurry','death','pause','pipe','hurt','appear','powerup','clear','fire','firework','stomp','world_clear','bowser_fire','bowser_fall','star','hurry_star'];
const heroAudioWorldMusic=['overworld','hurry_overworld','underworld','hurry_underworld','underwater','hurry_underwater','castle','hurry_castle'];
function heroAudioKeys(id,{hidden=false,musicKey='overworld'}={}){
 if(!['mario','bill','megaman','ryu','tank','sandboxTrio','ori','sonic','jackal'].includes(id))throw new TypeError('Unknown audio hero: '+id);
 const keys=new Set(heroAudioCommon),all=AUDIO_MANIFEST.map(row=>row.key);
 for(const key of all){
  if(id==='bill'&&(key.startsWith('bill_')||hidden&&key.startsWith('contra_'))||
     id==='megaman'&&(key.startsWith('mega_')||hidden&&key.startsWith('mm1_'))||
     id==='ryu'&&key.startsWith('ng07_')&&(hidden||key!=='ng07_boss_theme')||
     id==='jackal'&&key.startsWith('jackal_')&&(hidden||!['jackal_boss','jackal_victory'].includes(key)))keys.add(key);
 }
 if(id==='mario')for(const key of hidden?heroAudioWorldMusic:[musicKey,'hurry_'+musicKey])if(all.includes(key))keys.add(key);
 return [...keys].filter(key=>all.includes(key));
}
const heroExtraAudioLoads=new Map();
async function prepareHeroRecordedAudio(key,source,options,role='music',owner='selection'){
 if(bank.has(key))return;
 if(!heroExtraAudioLoads.has(key))heroExtraAudioLoads.set(key,Promise.resolve().then(async()=>{
  const ac=audioInit(false);if(!ac)throw new Error('Audio unavailable');
  const buffer=await ac.decodeAudioData(await readMediaBytes(source,options));bank.set(key,{buffer,gain:1,role,owner});
 }).finally(()=>heroExtraAudioLoads.delete(key)));
 return heroExtraAudioLoads.get(key);
}
async function prepareHeroAudio(id,{priority='foreground',hidden=false,musicKey='overworld'}={}){
 const options={priority},keys=heroAudioKeys(id,{hidden,musicKey}),result=await prepareAudio(keys,options);
 if(!result.ready)throw new Error('Audio unavailable: '+result.failed.map(row=>row.key).join(', '));
 if(!audioInit(false))throw new Error('Audio unavailable');
 if(id==='tank')r06InstallAudio();
 if(id==='sandboxTrio'){
  await mainlineTerraActor.prepareAudio(options);
  await Promise.all((hidden?['night','boss']:[musicKey==='night'?'night':'day']).map(key=>mainlineTerraActor.prepareMusic(key,options)));
  if(hidden)await prepareHeroRecordedAudio('selection_terra_boss',selectionTerraMusicSource,options);
 }
 if(id==='sonic'){
  await s33LoadSfx(options);
  if(Object.keys(S33_ASSETS.sfx).some(key=>!bank.has('s33_'+key)))throw new Error('Sonic effects unavailable');
  await prepareHeroRecordedAudio('credits_sonic',S33_ASSETS.music.ambient,options);
  if(hidden){await rf101LoadSonicBossAudio(options);await Promise.all(['flood','ending'].map(key=>readMediaBytes(S33_ASSETS.music[key],options)));}
 }
 if(id==='ori'){
  await fx40Ready(options);
  await readMediaBytes(O27_LOCAL.music.ambient,options);
  if(hidden){await prepareOriGinsoAudio(options);await prepareGinsoMusic(options);if(!m37.bytes)throw new Error('Ginso music unavailable');await Promise.all(['chase','reunion'].map(key=>readMediaBytes(O27_LOCAL.music[key],options)));}
 }
 return {hero:id,hidden,keys,ready:true};
}
