/* Official Ori PC Quickstart Guide skill icons, losslessly extracted with their
 * embedded alpha masks. These are project reward symbols, not original world
 * pickup animation. Source hashes and PDF xrefs: docs/RF09_ORI_REWARD_ASSETS.json. */
const rf09OriRewardArt={
 'ori-light':{image:new Image(),asset:'Ori/OfficialQuickstart/SpiritFlame'},
 'ori-cell':{image:new Image(),asset:'Ori/OfficialQuickstart/ChargeFlame'},
};
gameImage(rf09OriRewardArt['ori-light'].image,'@@E04:uri:a317@@','ori');
gameImage(rf09OriRewardArt['ori-cell'].image,'@@E04:uri:a318@@','ori');
mainlineAssetJobs.push(Promise.all(Object.values(rf09OriRewardArt).map(a=>gameImageReady(a.image))));
function rf09DrawOriReward(g,x,y,type){
 const art=rf09OriRewardArt[type],im=art?.image;
 if(!im?.complete||im.naturalWidth!==150||im.naturalHeight!==148)return false;
 // One whole source frame, fixed center and original aspect. Tick never moves
 // the world pickup; the existing collection feedback owns its own motion.
 const width=20,height=width*148/150;
 g.save();g.imageSmoothingEnabled=false;
 g.drawImage(im,0,0,150,148,Math.round(x-width/2),Math.round(y-height/2),width,height);
 g.restore();return{drawn:true,asset:art.asset,kind:type};
}
