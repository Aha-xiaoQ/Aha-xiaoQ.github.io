/* Source-backed scene presentation. Simulation and lifecycle live in modules. */
const rf092SceneArt={};
for(const [key,uri]of Object.entries({mega:'@@E04:uri:a326@@',superArm:'@@E04:uri:a2401@@',grass:'@@E04:uri:a328@@',ground:'@@E04:uri:a329@@',sky:'@@E04:uri:a330@@',giant:'@@E04:uri:a331@@',hud:'@@E04:uri:a332@@',numbers:'@@E04:uri:a333@@',cutman:'@@E04:uri:a900@@',baseBoss:'@@E04:uri:a901@@',baseSprites:'@@E04:uri:a902@@',plating:'@@E04:uri:a903@@',wallCannon:'@@E04:uri:a904@@',cannonball:'@@E04:uri:a905@@',wallModes:'@@E04:uri:a906@@',bossPlayer:'@@E04:uri:a921@@'})){
 const im=new Image();rf092SceneArt[key]=im;mainlineAssetJobs.push(gameImage(im,uri,key==='bossPlayer'?'bill':['mega','superArm','cutman'].includes(key)?'megaman-hidden':['grass','ground','sky','giant','hud','numbers'].includes(key)?'sonic-hidden':'bill-hidden'));
}
function rf092DrawPlatformChallenge({def,view:v,stage,actor,foes,background=[],cleared,departure=null,drawDeparture=null,departing=false,width}){
 const g=ctx,art=rf092SceneArt,offset=Math.max(0,(W-width)/2),id=v.p.hero;
 g.save();g.imageSmoothingEnabled=false;g.fillStyle=['megaman','bill'].includes(id)?'#000':'#08121d';g.fillRect(0,0,W,H);
 if(id==='megaman'){
  g.drawImage(art.mega,0,0,96,240,offset,0,96,240);
  for(let x=96;x<width-128;x+=16)g.drawImage(art.mega,112,0,Math.min(16,width-128-x),240,offset+x,0,Math.min(16,width-128-x),240);
  g.drawImage(art.mega,128,0,128,240,offset+width-128,0,128,240);
  // The source's 96..128 plain interior bridges the original two halves.
  if(width===256)g.drawImage(art.mega,96,0,32,240,offset+96,0,32,240);
  // The source room owns two removable blocks, not permanently baked tiles.
  g.drawImage(art.mega,96,160,32,32,offset+32,160,32,32);
  g.drawImage(art.mega,96,160,32,32,offset+64,160,32,32);
  for(const q of v.geometry)if(q.liftable==='super-arm')g.drawImage(art.mega,32,160,32,32,offset+q.x,q.y,32,32);
 }else if(id==='bill'){
  // Extend the walking floor, not entire repeated vertical pillars. Keep the
  // source fortress façade and outer walls at their original pixel scale.
  for(let x=0;x<width;x+=16){const n=Math.min(16,width-x);g.drawImage(art.baseBoss,16,176,n,64,offset+x,176,n,64);}
  g.drawImage(art.baseBoss,0,0,40,240,offset,0,40,240);
  g.drawImage(art.baseBoss,216,0,40,240,offset+width-40,0,40,240);
  g.drawImage(art.baseBoss,40,0,176,240,offset+(width-256)/2+40,0,176,240);
 }else if(id==='sonic'){
  const scroll=Math.floor(v.cam*.2)%512;
  for(let x=-scroll;x<W;x+=512)g.drawImage(art.sky,x,0,512,256);
 }else rf093DrawOriForest(g,v,width);
 g.save();g.beginPath();g.rect(offset,0,width,240);g.clip();g.translate(Math.round(offset-v.cam),0);
 if(!['megaman','bill'].includes(id))for(const q of v.geometry){
  g.save();
  if(id==='sonic'){
   // Collision-only room edges must not become visible grass columns. The
   // centred clip can expose a fractional pixel after raster translation.
   if(q.visual===false||q.id==='left-edge'||q.id==='right-edge'){g.restore();continue;}
   g.beginPath();g.rect(q.x,q.y,q.w,q.h);g.clip();
   for(let x=q.x;x<q.x+q.w;x+=32){g.drawImage(art.grass,x,q.y,32,16);for(let y=q.y+16;y<q.y+q.h;y+=32)g.drawImage(art.ground,x,y,32,32);}
  }else{
   rf093DrawOriTerrain(g,q);
  }g.restore();
 }
 for(const o of v.objects){
  if(o.kind==='coin')stage.drawCoin(g,o,v.tick);
  if(o.kind==='bash-anchor'){
   // The uploaded Ori chapter's native Bash lantern, at the actual target.
   const x=o.x+o.w/2,y=o.y+o.h/2;o24Glow(g,x,y,17,'#64e7dc',.4);rf093OriImage(g,'lantern',x-4,y-4,8);
  }
 }
 if(cleared){
  const q=def.exit;
  if(id==='sonic'){/* The clear right-hand route is Sonic's running departure. */}
  else if(id==='megaman'){g.fillStyle='#000';g.fillRect(q.x,q.y,q.w,q.h);}
  else if(id==='bill'){/* The original centre elevator remains visible. */}
  else{o24Glow(g,q.x+q.w/2,q.y+q.h/2,30,'#77e9ff',.4);g.fillStyle='#ccfaff';g.fillRect(q.x+10,q.y+3,5,q.h-3);}
 }
 for(const e of background)foes.draw(g,e,v.tick);
 for(const e of [...v.enemies,...v.items])if(!e.nativeOwner||e.nativeOwner==='foe-port'){if(e.kind==='score-pop'){E04Modules.drawPixelText(g,e.text,Math.round(e.x),Math.round(e.y)-7);continue;}if(!foes?.draw(g,e,v.tick))stage.drawPickup(g,e,v.tick);}
 if(!departure)stage.drawWorld(g,v);
 // Scripted departure suspends combat ticks. A frozen hurt-flash frame must
 // never hide the actor for the entire elevator sequence.
 if(departure){if(typeof drawDeparture!=='function')throw new Error('Missing scene departure renderer');drawDeparture(g,departure,v);}
 else if(departing||v.p.dying||!v.p.invulnerable||v.tick%8<4)E04Modules.drawStarActor(g,v.p,v.tick,()=>stage.drawPlayer(g,v.p,v.tick,v));
 g.restore();
 if(id==='megaman'){
  g.fillStyle='#000';g.fillRect(offset+7,14,10,61);
  for(let i=0;i<28;i++){g.fillStyle=i<v.health?'#fff7b2':'#292937';g.fillRect(offset+9,70-i*2,6,1);}
  if(v.p.superArm?.selected){g.fillStyle='#000';g.fillRect(offset+20,14,10,61);E04Modules.drawPixelText(g,'G',offset+22,4);for(let i=0;i<28;i++){g.fillStyle=i<v.p.superArm.energy?'#ab4700':'#292937';g.fillRect(offset+22,70-i*2,6,1);}}
  const boss=v.enemies.find(e=>e.id===def.bossId&&!e.dead);if(boss){g.fillStyle='#000';g.fillRect(offset+width-19,14,10,61);for(let i=0;i<28;i++){g.fillStyle=i<boss.hp?'#fff7b2':'#292937';g.fillRect(offset+width-17,70-i*2,6,1);}}
 }else if(id==='bill'){
  E04Modules.drawPixelText(g,'SCORE '+String(v.score).padStart(6,'0'),offset+48,8,1);
  E04Modules.drawPixelText(g,'REST '+String(v.lives),offset+width-104,8,1);
 }else if(id==='sonic'){
  const number=(n,x,y)=>{for(const c of String(n)){const k=c===':'?10:Number(c);g.drawImage(art.numbers,k*8,0,8,16,x,y,8,16);x+=8;}};
  for(let i=0;i<3;i++)g.drawImage(art.hud,0,i*16,40,16,16,12+i*18,40,16);
  number(v.score,64,12);number(Math.floor(v.tick/3600)+':'+String(Math.floor(v.tick/60)%60).padStart(2,'0'),64,30);number(v.native?.rings||0,64,48);
 }else{
  rf093DrawOriHud(g,v,width,offset);
 }
 g.restore();
}
// Render source sprite cells at their source anchors; no perpose alpha resize.
function rf101DrawOriginalBoss(g,e,tick){
 const art=rf092SceneArt,age=e.age||0,cx=e.x+e.w/2,cy=e.y+e.h/2;
 if(e.kind==='original-boss-explosion'){
  if(e.foeSource==='mm1'){
   const cells=[[37,115],[55,115],[37,133],[55,133]],r=[...cells[Math.floor(age/4)%4],17,17];
   for(const [count,speed]of [[4,.8],[8,1.6]])for(let n=0;n<count;n++){const angle=n*Math.PI*2/count;mixCrop('megaman',r,cx+Math.cos(angle)*age*speed-8,cy+Math.sin(angle)*age*speed-9);}
  }else if(age<24)mixCrop('bill',[1,65+Math.floor(age/6)%2*29,28,28],cx-14,cy-14);
  return true;
 }
 if(e.kind==='original-boss-background'){
  if(e.sourceTileFrame!==5)throw new Error('Unknown destroyed Contra background frame');
  g.drawImage(art.wallModes,160,0,32,32,Math.round(e.x-8),Math.round(e.y-8),32,32);return true;
 }
 if(e.dead)return true;
 if(e.type!=='base1-eye'&&e.flash>0&&tick%4<2)return true;
 if(e.foeSource==='mm1'){
  const poses=['26','27','28','29','2a','2b','2c','2d','2e','2f','69','6a','6b','6c'];
  const key=e.sourceFrame||(e.type==='cutman'?'26':'69'),index=poses.indexOf(key)+(e.dir>0?14:0);
  if(index<0)throw new Error('Unregistered original Cut Man OAM frame');
  const anchor=e.type==='cutman'?{x:cx,y:e.y+e.h-12}:{x:cx,y:cy};
  g.drawImage(art.cutman,index*48,0,48,48,Math.round(anchor.x-24),Math.round(anchor.y-28),48,48);return true;
 }
 if(e.foeSource==='contra-nes'){
  // Original nametable IDs/palettes; missing raw CHR modes use the disclosed
  // continuous original-footage reconstruction in the package receipt.
  if(e.type==='wall-cannon'||e.type==='wall-plating'){
   const frame=e.sourceTileFrame??0;
   if(!Number.isInteger(frame)||frame<0||frame>5)throw new Error('Unknown Contra nametable frame');
   g.drawImage(art.wallModes,frame*32,0,32,32,Math.round(e.x-8),Math.round(e.y-8),32,32);return true;
  }
  if(e.type==='cannon-shot'){g.drawImage(art.cannonball,Math.round(e.x),Math.round(e.y));return true;}
  if(e.type==='base1-eye'&&(e.ai==='platings'||!e.sourceFrame))return true;
  const poses=['5d','5e','5f','60','61','62','63','64'],key=e.sourceFrame||(e.type==='base1-eye'?'5d':'63'),i=poses.indexOf(key);
  if(i<0)throw new Error('Unregistered original Contra Boss frame');
  const size=e.type==='base1-eye'?[24,25]:e.h===14?[14,14]:[31,31];
  if(e.type==='fire-ring'){
    const mirror=e.sourceMirror??0;
    if(![0,0x40,0xc0,0x80].includes(mirror))throw new Error('Unknown original Contra ring mirror');
    const flipX=!!(mirror&0x40),flipY=!!(mirror&0x80);
    g.save();g.translate(Math.round(e.x)+(flipX?size[0]:0),Math.round(e.y)+(flipY?size[1]:0));g.scale(flipX?-1:1,flipY?-1:1);
    g.drawImage(art.baseSprites,i*32,0,...size,0,0,...size);g.restore();return true;
   }
   g.drawImage(art.baseSprites,i*32,0,...size,Math.round(e.x),Math.round(e.y),...size);return true;
 }
 return false;
}
registerPresentationCues({
 mm1_victory:{source:'mm1_victory',category:'music',scope:'scene',gain:'measured',blocksStage:false},
 contra_victory:{source:'contra_victory',category:'music',scope:'scene',gain:'measured',blocksStage:false},
});
function rf101WithNativeRoomMusic(key,fn){
 const prior=desiredMusic;desiredMusic=()=>mode==='playing'?key:null;
 try{return fn();}finally{desiredMusic=prior;}
}
function rf101DrawContraBossPlayer(g,pose){
 const f=E04Modules.CONTRA_BOSS_PLAYER_FRAMES[pose.frame];
 if(!f)throw new TypeError('Unknown original Contra player frame');
 g.save();g.translate(Math.round(pose.x),Math.round(pose.y));g.scale(pose.flipX?-1:1,pose.flipY?-1:1);
 g.drawImage(rf092SceneArt.bossPlayer,...(pose.recoil&&f.recoilRect?f.recoilRect:f.rect),-f.anchor[0],-f.anchor[1],64,64);g.restore();return true;
}
function createRf101OriginalBossChallenge(id){
 let driver,sourcePlayer;
 const cue=id==='bill'?'contra_boss':'mm1_boss';
 driver=E04Modules.createPlatformChallenge({hero:id,character:E04Modules.CHARACTER_PROFILES.find(p=>p.id===id),rule:E04Modules.CHALLENGE_RULES[id],
  departureKind:id==='megaman'?'teleport':null,deathPresentationTicks:id==='bill'?90:0,definition:E04Modules.ORIGINAL_BOSS_CHALLENGES[id],enemyDefinition:E04Modules.originalBossEnemyDefinition,
  debug:new URLSearchParams(location.search).get('test')==='1',
  createActor:hero=>{const baseActor=mainlineActorRegistry.create(hero),actor=hero==='bill'?E04Modules.createContraBossPlayer({base:baseActor,draw:rf101DrawContraBossPlayer,sound:({weapon})=>withAudioOwner('actor:bill',()=>playBillWeaponSound(weapon))}):hero==='megaman'?E04Modules.createMegamanBossPlayer({base:baseActor,draw:rf101DrawSuperArmPlayer,drawStone:rf101DrawSuperArmStone,sound:event=>{if(event==='throw')oneShot('mega_shot_nes',{owner:'actor:megaman'});}}):baseActor;sourcePlayer=actor;return {...actor,audio:(...args)=>rf101WithNativeRoomMusic(driver?.view().bossDefeated?null:cue,()=>actor.audio(...args))};},
  createEnemies:hero=>E04Modules.createOriginalBossEnemies(hero,{draw:rf101DrawOriginalBoss,playerBulletContact:hero==='bill'?(e,w,p)=>sourcePlayer.resolveSourceShots(e,w,p):null,sound:event=>{
   if(['mm1_victory','contra_victory'].includes(event)){stopMusic();playScenePresentationAudio(event,{fallbackOwner:'actor:'+hero});}
   // Repeatable native effects are actor-owned one-shots. Finite scene cues
   // deduplicate by key and are reserved for the victory presentation.
   else if(bank.has(event))oneShot(event,{owner:'actor:'+hero});
  }}),viewport:()=>W,render:args=>rf092DrawPlatformChallenge({...args,drawDeparture:rf101DrawMegaDeparture}),
  sound:(actor,event)=>{if(!actor.sound(event)&&event==='life')originalOneShot('oneup');},
});return driver;
}
function rf101DrawMegaDeparture(g,d){
 const p=d.body;
 if(d.bodyVisible&&!(d.phase==='charge'&&d.age%4<2))rf101DrawSuperArmPlayer(g,{frame:'00',x:p.x+p.w/2,y:p.y+p.h-12,flipX:true,held:false});
 if(d.beam){const q=d.beam,x=Math.round(q.x-q.width/2),y=Math.round(q.y-q.height);g.fillStyle='#00d8f8';g.fillRect(x-1,y,q.width+2,q.height);g.fillStyle='#fcfcfc';g.fillRect(x,y,q.width,q.height);}
}
function createRf092PlatformChallengeDrivers(){
 return Object.fromEntries(['megaman','ori','sonic'].map(id=>[id,id==='ori'?createOriGinsoChallengeDriver():id==='sonic'?createRf101SonicBossDriver():id==='megaman'?createRf101OriginalBossChallenge(id):E04Modules.createPlatformChallenge({hero:id,
  character:E04Modules.CHARACTER_PROFILES.find(p=>p.id===id),rule:E04Modules.CHALLENGE_RULES[id],
  debug:new URLSearchParams(location.search).get('test')==='1',
  createActor:hero=>mainlineActorRegistry.create(hero),createEnemies:createRf08CharacterFoes,viewport:()=>W,
  render:rf092DrawPlatformChallenge,sound:(actor,event)=>{if(!actor.sound(event)&&event==='life')originalOneShot('oneup');},
 })]));
}

/** The preserved front-view corridor and declarative Boss both use the host's
 * one native challenge record. Only input dispatch changes at the open door. */
function createRf101ContraBaseChallenge({runtime,terminal}){
 let base=null,boss=null,options=null;
 function openBoss(){
  const state=runtime.health(),carry={...options.carry,...runtime.readCarry(),native:state.nativeCarry,weapon:billWeapon,protection:state.protection};
  billBase=null;mixShots=[];enemyShots=[];boss=createRf101OriginalBossChallenge('bill');boss.enter({...options,carry});
 }
 function enter(value){
  boss?.leave();boss=null;options=value;surface=buildLevel();underground=buildUnder();player=createPlayer(122,BILL_BASE_FLOOR-30);
  originalLoadRoom('under');enterBillBase();base=billBase;base.challengeBoss=true;
  // Retry never restores the defeated/dead body. The original scene checkpoint
  // chooses its encounter phase; equipment and receipt remain shared authority.
  if(value.retry&&value.scene?.data?.schema==='contra-base-retry-v1'&&value.scene.data.phase==='boss')openBoss();
  return true;
 }
 function migrateCheckpoint(checkpoint){
  const current=E04Modules.copySceneCheckpoint('bill',checkpoint),d=current.data;
  if(d.kind==='bill-base')return {...current,data:{schema:'contra-base-boss-scene-v1',phase:'base',scene:d}};
  if(d.schema==='contra-base-retry-v1'&&['base','boss'].includes(d.phase))return current;
  if(d.schema==='contra-base-boss-scene-v1'&&['base','boss'].includes(d.phase)&&d.scene){
   if(d.phase==='boss'){
    const saved=d.scene,body=saved.stage?.body;
    if(saved.schema!=='native-platform-scene-v2'||saved.id!=='contra-base1-boss-room'||!body)throw new TypeError('Unknown Contra Boss checkpoint');
    if(!Object.hasOwn(body,'contraBoss')){
     if(body.w!==10||body.h!==30)throw new TypeError('Unknown Contra Boss player checkpoint');
     return {action:'restart',checkpoint:{version:1,hero:'bill',data:{schema:'contra-base-retry-v1',phase:'boss'}}};
    }
   }
   return current;
  }
  throw new TypeError('Unknown Contra encounter checkpoint');
 }
 function snapshotScene(){return {schema:'contra-base-boss-scene-v1',phase:boss?'boss':'base',scene:boss?boss.snapshotScene():rf09CaptureBillScene(base,player)};}
 function restoreScene(data){
  if(!data||data.schema!=='contra-base-boss-scene-v1'||!['base','boss'].includes(data.phase)||!data.scene)throw new TypeError('Invalid Contra encounter checkpoint');
  if(data.phase==='boss'){if(!boss)openBoss();boss.restoreScene(data.scene);}
  else{if(boss)throw new TypeError('Contra checkpoint phase mismatch');rf09RestoreBillScene(base,player,data.scene);base.challengeBoss=true;}
 }
 return {chapter:11,enter,snapshotScene,restoreScene,migrateCheckpoint,retryCheckpoint:()=>({schema:'contra-base-retry-v1',phase:boss?'boss':'base'}),
  beginDeparture:()=>boss?.beginDeparture()??false,
  step(input){if(boss)boss.step(input);else{runtime.step(input);if(!terminal()&&base.pendingBossEntry)openBoss();}},
  view(){if(boss)return {...boss.view(),id:'bill-base',title:'比尔 · 敌军基地',area:'base-boss',encounterPhase:'boss'};
   return {hero:'bill',id:'bill-base',title:'比尔 · 敌军基地',mode,area:'base',encounterPhase:'base',logicalWidth:E04Modules.nativeArenaWidth(W),logicalHeight:240,
    cleared:false,exitReady:false,exited:false,failed:terminal(),rewardClaimed:false,progress:{coreHp:base?.coreHp,doorTicks:base?.doorTicks},body:player};},
  drainEvents:()=>boss?.drainEvents()||[],
  grantCompletionBonus:award=>{if(!boss)throw new Error('Cannot grant Contra prize before Boss');return boss.grantCompletionBonus(award);},
  draw(){if(boss)boss.draw();else runtime.draw();},
  audio(){if(boss)boss.audio();else rf101WithNativeRoomMusic('contra_base',()=>runtime.audio());},
  pause(){if(boss)boss.pause();else runtime.pause();},resume(prior){if(boss)boss.resume();else runtime.resume(prior);},
  leave(){boss?.leave();boss=null;base=null;options=null;billBase=null;},
  ...(new URLSearchParams(location.search).get('test')==='1'?{diagnostics:()=>boss?boss.diagnostics():{state:base}}:{}),
 };
}

function rf101DrawSuperArmPlayer(g,pose){
 const f=E04Modules.MEGAMAN_SUPER_ARM_FRAMES[pose.frame];if(!f)throw new TypeError('Unregistered Super Arm pose');
 g.save();g.translate(Math.round(pose.x),Math.round(pose.y));g.scale(pose.flipX?-1:1,1);g.drawImage(rf092SceneArt.superArm,...f.rect,-32,-40,64,64);g.restore();return true;
}
function rf101DrawSuperArmStone(g,x,y){const f=E04Modules.MEGAMAN_SUPER_ARM_FRAMES['95'];g.drawImage(rf092SceneArt.superArm,...f.rect,Math.round(x-16),Math.round(y-24),64,64);}
