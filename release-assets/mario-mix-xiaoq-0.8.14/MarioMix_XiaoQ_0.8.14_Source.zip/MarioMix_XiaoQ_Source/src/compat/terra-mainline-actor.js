/* Included at the END of the RF02 Terra IIFE, after the final R21 overrides.
 * The host owns rooms, geometry, clock, lives and completion. The captured
 * native step owns Terra movement, equipment, combat, drops and native foes.
 * No event listeners, RAF, map replacement, new art or global menu calls.
 */
const TERRA_MAINLINE_CARRY_KEYS=Object.freeze(['hp','maxHp','tool','kit','cloudJump','wood','mana','maxMana','ammo','manaPotions','healPotions','healCooldown','manaSickness','shield','shieldTicks','boostTicks',
  'slimeOwned','ufoOwned','mountOwned','mounted','mountType','mountIntent','kitSupplies','t13Weapon','t13Owned','t13Inventory','t13Accessories','t13WeaponOverride','t21OwnedAccessories','t21Axe','nativeVitals']);
// Native artwork and hidden rooms retain their own body sizes. Shared 16px
// passages need collision tolerance; feet and sprite centre remain authoritative.
const TERRA_MAINLINE_BODY=Object.freeze({width:14,height:32,slimeHeight:47,clearanceStep:16});
// Contacts are ephemeral scene transactions, never equipment or save data.
// Successful contact is keyed by the real enemy entity and simulation tick,
// so a second producer cannot reclassify a completed bounce as a side hit.
const terraSlimeContacts=new WeakMap();
function terraSlimeContactSeen(s,e,tick){return terraSlimeContacts.get(s)?.get(e)===tick;}
function terraSlimeContactCommit(s,e,tick){let seen=terraSlimeContacts.get(s);if(!seen){seen=new WeakMap();terraSlimeContacts.set(s,seen);}seen.set(e,tick);}
function terraSlimeContactBox(s,e,context={}){
  const p=s.p,box=context.contactBox||e,scale=r07Scale(s);
  if(!s.mounted||s.mountType!=='slime'||p.dying||e.dead||context.definition?.movement?.collision==='projectile'||!box||![box.x,box.y,box.w,box.h].every(Number.isFinite))return null;
  const descending=context.descending??p.vy>0,oldBottom=context.oldBottom??p.slimeOldFeet??p.y+p.h-p.vy,oldTop=context.oldEnemyTop??box.y;
  if(!descending||oldBottom>oldTop+8*scale||p.y+p.h<box.y||p.x+p.w<=box.x||p.x>=box.x+box.w)return null;
  return box;
}
function terraSlimeContactBounce(s,e,box,tick,acceptedDamage=R07_SLIME.stompDamage){
  const p=s.p;p.y=box.y-p.h;p.vy=-R07_SLIME.jumpSpeed*2*r07Scale(s);p.slimeHold=0;p.slimeBounce=10;p.invuln=Math.max(p.invuln||0,6);p.grounded=false;p.support=null;
  terraSlimeContactCommit(s,e,tick);evt('r07-slime-stomp',{target:e.id,attemptedDamage:R07_SLIME.stompDamage,acceptedDamage});
}
function terraNativeEnemyContact(s,e,context={}){
  if(!s||!e||typeof e!=='object')return false;
  if(s.mainline)return !!s.mainlineWorld?.enemyContact?.(e,context);
  const tick=context.tick??s.ticks;if(terraSlimeContactSeen(s,e,tick))return true;
  const box=terraSlimeContactBox(s,e,context);if(!box)return false;
  let target=context.target||r06AllTargets(s).find(t=>t.obj===e);
  // Awakening/armored bodies can be contact-valid while absent from the
  // attack-target registry. Only a precise body producer may supply that box.
  if(!target&&context.cause==='enemy-contact'&&context.contactBox===box)target={id:e.id,x:box.x+box.w/2,y:box.y+box.h/2,w:box.w,h:box.h,obj:e};
  if(!target)return false;
  const hp=e.hp,dead=e.dead;r06DamageTarget(target,R07_SLIME.stompDamage,'slime-stomp');
  const actual=Number.isFinite(hp)&&Number.isFinite(e.hp)?Math.max(0,hp-e.hp):e.dead!==dead?R07_SLIME.stompDamage:0;
  terraSlimeContactBounce(s,e,box,tick,actual);return true;
}
function terraMainlineHeadContact(p,surfaces){
  const hit=surfaces.find(q=>q.id===p.headHit);if(!hit)return p.headHit;
  const plane=hit.y+hit.h,centre=p.x+p.w/2;
  let best=hit,distance=Math.abs(centre-hit.x-hit.w/2);
  for(const q of surfaces){
    if(!q.solid||Math.abs(q.y+q.h-plane)>.01||p.x+p.w<=q.x||p.x>=q.x+q.w)continue;
    const d=Math.abs(centre-q.x-q.w/2);
    if(d<distance||d===distance&&String(q.id)<String(best.id)){best=q;distance=d;}
  }
  return best.id;
}
function terraMainlineMountClearance(s,travel=0){
  if(!s.mainline)return;
  const p=s.p,centre=p.x+p.w/2,feet=p.y+p.h;
  p.w=s.mainlineBodyWidth||TERRA_MAINLINE_BODY.width;p.x=centre-p.w/2;
  const intent=s.mountIntent??null,slime=intent==='slime',height=slime?TERRA_MAINLINE_BODY.slimeHeight:TERRA_MAINLINE_BODY.height;
  const box={x:Math.min(p.x,p.x+travel),y:feet-height,w:p.w+Math.abs(travel),h:height};
  const rider={...box,y:feet-TERRA_MAINLINE_BODY.height,h:TERRA_MAINLINE_BODY.height};
  // Only the extra mounted height may require a temporary dismount. Ordinary
  // side walls collide with the rider too and stay owned by native movement;
  // they must not revoke UFO flight or turn diagonal input into a forced fall.
  const surfaces=(s.level?.surfaces||[]).filter(q=>q.solid&&!q.hidden);
  const intersects=body=>surfaces.some(q=>near(body,q));
  const stepNeedsHeadroom=travel&&surfaces.some(q=>{
    const rise=feet-q.y;
    if(rise<=0||rise>TERRA_MAINLINE_BODY.clearanceStep+.001||!near(rider,q))return false;
    // A one-tile stair into a low passage needs the rider's headroom at the
    // landing plane as well as at the current feet. This only selects body
    // height; normal jump/collision still performs the climb.
    const landingRider={...rider,y:q.y-rider.h},landingMount={...box,y:q.y-box.h};
    return !intersects(landingRider)&&intersects(landingMount);
  });
  const blocked=height>TERRA_MAINLINE_BODY.height&&(surfaces.some(q=>near(box,q)&&!near(rider,q))||stepNeedsHeadroom);
  const mounted=!!intent&&!blocked;
  // Actual collision/presentation can dismount beneath masonry. The carried
  // intention is separate and reacquires its original body only in full space.
  if(s.mounted!==mounted){s.mounted=mounted;s.t10PendingMount=null;p.slimeHold=0;}
  if(intent)s.mountType=intent;
  const target=mounted&&slime?height:TERRA_MAINLINE_BODY.height;
  p.y=feet-target;p.h=target;p.r07MountHeight=mounted&&slime;
}
function terraMainlineNormalizeMountCarry(d){
  // Rails are owned by their hidden room. Exporting a minecart must produce
  // equipment the receiving actor can accept, without importing a rail body.
  if(d.mountType==='minecart'){
    d.mounted=false;d.mountIntent=null;d.mountType=d.ufoOwned?'ufo':d.slimeOwned?'slime':null;
  }else if(!Object.hasOwn(d,'mountIntent')){
    d.mountIntent=d.mounted?(['slime','ufo'].includes(d.mountType)?d.mountType:d.ufoOwned?'ufo':d.slimeOwned?'slime':null):null;
  }
  return d;
}
function terraMainlineCarry(s){
  if(s.r05Arena&&s.campaignChallenge)s.nativeVitals={hp:s.hp,maxHp:s.maxHp};
  const value=JSON.parse(JSON.stringify({schema:'rf02-terra-carry-v1',hero:'sandboxTrio',loadout:Object.fromEntries(TERRA_MAINLINE_CARRY_KEYS.filter(k=>s[k]!==undefined).map(k=>[k,s[k]]))}));
  // Pipe animation temporarily dismounts the body; equipment transfer keeps the
  // rider's intent. The destination scene owns its own emerge animation.
  if(!s.mainline)value.loadout.mountIntent=s.mounted?s.mountType:s.t10PendingMount?.type||null;
  const transit=s.t11Transition;
  if(transit?.wasMounted){value.loadout.mounted=true;value.loadout.mountType=transit.mount;value.loadout.mountIntent=transit.mount;}
  terraMainlineNormalizeMountCarry(value.loadout);
  if(new TextEncoder().encode(JSON.stringify(value)).length>4096)throw new RangeError('Terra carry exceeds 4096 bytes');return value;
}
function terraMainlineRespawnCarry(s){
  const value=terraMainlineCarry(s),d=value.loadout;
  // A one-time challenge's traversal rewards remain owned after death. Only
  // the selected weapon, temporary protection and riding pose are expendable.
  Object.assign(d,{hp:d.maxHp,tool:0,kit:null,t13Weapon:'starfury',t13Owned:['starfury'],t13WeaponOverride:false,
    shield:0,shieldTicks:0,boostTicks:0,healCooldown:0,manaSickness:0,mounted:false,mountIntent:null});
  d.mountType=d.ufoOwned?'ufo':d.slimeOwned?'slime':null;
  d.mountOwned=!!(d.ufoOwned||d.slimeOwned);
  return {version:1,...value};
}
function terraMainlineApplyNativeCarry(s,data){
  if(!data)return;
  if(data.schema!=='rf02-terra-carry-v1'||data.hero!=='sandboxTrio'||!data.loadout||new TextEncoder().encode(JSON.stringify(data)).length>4096)throw new TypeError('Invalid Terra challenge carry');
  const d=data.loadout;
  if(Object.keys(d).some(k=>!TERRA_MAINLINE_CARRY_KEYS.includes(k))||!Number.isFinite(d.hp)||!Number.isFinite(d.maxHp)||d.hp<0||d.maxHp<1||d.maxHp>10000||d.hp>d.maxHp||d.mountIntent!=null&&!['slime','ufo'].includes(d.mountIntent)||!Number.isInteger(d.tool)||d.tool<0||d.tool>5)throw new TypeError('Invalid Terra challenge loadout');
  const check=(v,depth=0)=>{if(depth>8)throw new TypeError('Terra carry nesting exceeds bounds');if(typeof v==='number'&&!Number.isFinite(v))throw new TypeError('Invalid Terra resource');if(v&&typeof v==='object')for(const [k,n]of Object.entries(v)){if(['__proto__','prototype','constructor'].includes(k))throw new TypeError('Unsafe Terra resource');check(n,depth+1);}};check(d);
  Object.assign(s,terraMainlineNormalizeMountCarry(JSON.parse(JSON.stringify(d))));s.p.cloudAvailable=!!s.cloudJump;s.p.attack=s.p.cooldown=0;
  // A minecart belongs to the hidden room's real rail, never to a shared-map
  // spawn. Slime/UFO ownership and equipment remain ordinary carried resources.
  if(!s.r05Arena&&s.mountType==='minecart'){s.mounted=false;s.mountType=s.ufoOwned?'ufo':s.slimeOwned?'slime':null;}
  if(s.mountIntent&&!s.mainline){s.mounted=false;r07SetMountHeight(s,false);t10RequestMount(s,s.mountIntent,'carry');}
  else r07SetMountHeight(s,s.mounted&&s.mountType==='slime');
  terraMainlineMountClearance(s);s.minions=[];
  if(s.kit==='summoner'&&!s.t13WeaponOverride)r06CreateMinions(s);r06SyncKitTools();
}
function terraMainlineCommands(input,v=input){
  if(Number.isInteger(input.toolIndex)&&input.toolIndex>=0&&input.toolIndex<=5){if(state?.tool!==input.toolIndex)r06DigitTool(input.toolIndex);v.toolEdge=false;}
  else if(input.toolNextPressed){t17Perform('toolNext');v.toolEdge=false;}
  for(const [key,action]of [['weaponPressed','weapon'],['mountPressed','mount'],['mountCyclePressed','mountCycle'],['healPressed','heal'],['interactPressed','interact'],['toolPrevPressed','toolPrev'],['torchPressed','torch'],['recallPressed','recall']])if(input[key])t17Perform(action);
}
function terraMainlinePointerInput(s,v){
  const q=v.pointer,gamepad=v.device==='gamepad'||v.inputDevice==='gamepad';
  if(gamepad){t13Pointer.active=t13Pointer.down=r05Pointer.active=r05Pointer.down=r05Pointer.pressed=false;t20Device='gamepad';t17Input.source='gamepad';t17Input.explicit=false;t20LeftAim=[v.x||s.p.facing,v.y||0];}
  else if(q&&Number.isFinite(q.x)&&Number.isFinite(q.y)){
    const viewport=q.space==='viewport',x=q.x+(viewport?s.cam||0:0),y=q.y+(viewport?(s.r05Arena?s.camY??-96:s.r07CamY||0):0);
    Object.assign(t13Pointer,{active:q.active!==false,down:!!q.down,x,y,lastMove:performance.now()});
    Object.assign(r05Pointer,{active:t13Pointer.active,down:t13Pointer.down,pressed:!!q.pressed,x,y});
    t17Input.source=t13Pointer.active?'mouse':'facing';t17Input.explicit=t13Pointer.active;t20Device='keyboard';
  }else{t13Pointer.down=false;r05Pointer.down=r05Pointer.pressed=false;}
  if(!t13Pointer.active&&Math.abs(v.aimX||0)<=1&&Math.abs(v.aimY||0)<=1&&Math.hypot(v.aimX||0,v.aimY||0)>.2){t17SetAim(v.aimX,v.aimY,'stick');t20Device='gamepad';}
}
function terraMainlineHiddenStep(v,nativeStep){
  if(!state)return;state.mainlineInput=true;t17PrepareState(state);terraMainlinePointerInput(state,v);terraMainlineCommands(v);
  if(v.auxEdge&&!v.interactPressed)t17Interact();const out=nativeStep(v);prev=v;return out;
}
// The whole crown/trunk footprint, including space to swing an axe, must be
// clear. Underground brickwork is never a tree planting surface.
function terraMainlineTreeSites(world){
  if(world.roomId!=='area-0'||!/1-[13](?:-stage)?$/.test(world.levelId||''))return [];
  const overlaps=(a,b)=>a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y;
  const reserved=[...(world.objects||[]).filter(q=>q.kind!=='walker'),...(world.enemies||[])];
  const sites=[];
  for(const floor of world.solids.filter(q=>q.collision==='solid'&&!q.hidden&&!q.material&&q.y>=192&&q.w>=192)){
    // Search aligned, spacious ground; keep trees scarce and away from edges.
    for(let x=Math.ceil((floor.x+80)/16)*16;x<=floor.x+floor.w-80;x+=32){
      const box={x:x-36,y:floor.y-68,w:72,h:68};
      if(x<128||sites.some(t=>Math.abs(t.x-x)<320)||world.solids.some(q=>q!==floor&&!q.hidden&&overlaps(box,q))||
        reserved.some(q=>overlaps(box,{x:q.x-32,y:q.y-24,w:q.w+64,h:q.h+48})))continue;
      sites.push({id:'terra-tree-'+floor.id+'-'+x,x,y:floor.y,h:58,visualH:58});break;
    }
  }
  return sites;
}
function terraMainlineDamage(s,source){
  const p=s.p;if(source?.enemy&&terraNativeEnemyContact(s,source.enemy,source))return true;
  if(s.mainlineHealth){
    if(mode!=='playing'||p.invuln||s.phase==='defeated')return true;
    if(typeof evt==='function'){const {enemy,target,...detail}=source;evt('common-hit',{...detail,...(enemy?{enemyId:enemy.id,enemyBounds:{x:source.contactBox?.x??enemy.x,y:source.contactBox?.y??enemy.y,w:source.contactBox?.w??enemy.w,h:source.contactBox?.h??enemy.h}}:{}),tick:s.ticks,eyeMode:s.eye?.mode});}
    if(s.challengeProtection){s.challengeProtection=0;p.invuln=120;p.hurtLock=12;p.vx=(p.x+p.w/2<(source.x??p.x+p.w)?-1:1)*3;p.vy=-3.3;p.grounded=false;p.support=null;p.attack=0;terraSound('hurt');}
    else{s.phase='defeated';mode='respawn';p.attack=0;terraSound('death');}
    return true;
  }
  if(!s.mainline)return false;
  if(!p.dying&&!s.mainlineDead&&!p.invulnerable&&!p.star&&s.mainlineDamageTick!==s.ticks){
    s.mainlineDamageTick=s.ticks;s.mainlineWorld?.damage?.(source);
  }
  return true;
}
function createTerraMainlinePort(native, {emit = () => {}} = {}) {
  const owner = 'sandboxTrio', clone = value => JSON.parse(JSON.stringify(value));
  const roomKeys = ['foes','trees','built','campfires','projectiles','drops','numbers','impacts','r06FX','r06Drops','r07Loot','t10Particles','t13Arrows','t13Drops','t13Sparks','t14Torches','t21ExtraShots','t21Hostile'];
  const transient = new Set(['p','level','pipe','mainlineTargets','mainlineWorld','t13World','t13SavedWorld','t11Chest','t21Deer',...roomKeys]);
  const carryKeys=TERRA_MAINLINE_CARRY_KEYS;
  let actor = null, currentRoom = null, currentWorld = null, previous = {}, disposed = false, paused = false, lastHud = null;
  const rooms = new Map(),worldEnemies=new Map(),surfaceViews=new WeakMap();
  native.acquire();

  function live() { if (disposed) throw new Error('Terra actor is disposed'); }
  function status() {
    return actor ? {hero:owner,hp:actor.p.dying?0:1+(actor.p.protection?1:0),maxHealth:2,dead:!!actor.mainlineDead,
      weapon:native.weapon(actor),armor:native.armor(actor),tool:actor.tool,wood:actor.wood,
      mounted:!!actor.mounted,mountType:actor.mountType||null,notice:actor.noticeTime?actor.notice:''} : null;
  }
  function syncPlayer() {
    const p=actor.p;p.hero=owner;p.nativeActor=owner;p.hp=p.dying?0:1+(p.protection?1:0);p.maxHealth=2;
    p.weapon=native.weapon(actor);p.anim=p.walk||0;p.power??=0;
  }
  function saveRoom() {
    if (actor && currentRoom !== null) rooms.set(currentRoom,Object.fromEntries(roomKeys.map(key=>[key,actor[key]||[]])));
  }
  function create(character,spawn) {
    live();if(character?.heroId!==owner)throw new TypeError('Terra actor requires sandboxTrio');
    if(!Number.isFinite(spawn?.x)||!Number.isFinite(spawn?.y))throw new TypeError('Invalid Terra spawn');
    if(!actor)actor=native.create();
    const old=actor.p;
    actor.p={...old,x:spawn.x,y:spawn.y,vx:0,vy:0,grounded:false,support:null,coyote:0,buffer:0,drop:0,
      attack:0,cooldown:0,hurtLock:0,headHit:null,walk:0,invuln:actor.mainlineDead?120:0,
      // Only the shared flag/castle walk uses these motor fields. RF02's own
      // physics ignores them; omitting them poisons the finish body with NaN.
      airCap:character.motion?.walkSpeed??2.75,jumpG:.125,fallG:.4375,jumpBuffer:0,jumps:0,airTicks:0,dropTicks:0,
      swimming:false,mainlineWater:false,swimStroke:0,waterJumpHeld:false};
    if(actor.mainlineDead||actor.hp<=0){actor.hp=actor.maxHp;actor.mainlineDead=false;}
    actor.p.dying=false;actor.mainline=true;actor.mountIntent??=actor.mounted?actor.mountType:null;
    actor.mainlineBodyWidth=character.access?.collisionWidth||TERRA_MAINLINE_BODY.width;actor.p.w=actor.mainlineBodyWidth;previous={};syncPlayer();return actor.p;
  }
  function prepareRoom(world) {
    live();if(!actor)throw new Error('Create Terra player before preparing a room');
    if(!world||typeof world.roomId!=='string'||!Array.isArray(world.solids)||!Array.isArray(world.enemies)||
       !Number.isFinite(world.width)||world.width<=0||!Number.isFinite(world.height)||world.height<=0)throw new TypeError('Invalid Terra world');
    currentWorld=world;
    worldEnemies.set(world.roomId,world.enemies);
    let surfaces=surfaceViews.get(world.solids);
    if(!surfaces){
      // Read-through views keep stage-owned moving platforms/bumped blocks
      // current without cloning the entire level several times per frame.
      surfaces=world.solids.map(q=>{
        const view={...q,type:q.collision==='oneway'?'tree':q.material==='pipe'?'pipe':'floor',solid:q.collision==='solid',oneWay:q.collision==='oneway'};
        for(const key of ['x','y','w','h','dx','dy','hidden','used'])Object.defineProperty(view,key,{enumerable:true,get:()=>q[key]});
        return view;
      });
      surfaceViews.set(world.solids,surfaces);
    }
    actor.level={width:world.width,flightMinY:world.flightMinY??0,surfaces,movers:[],coins:[],clouds:[],
      reward:{id:'terra-no-private-reward',x:-100000,y:-100000,w:0,h:0,used:true},
      flag:{x:100000},castle:{x:100000,doorX:100000}};
    actor.mainlineTargets=world.enemies;actor.mainlineWorld=world;
    actor.mainlineHeight=world.height;actor.cam=Number.isFinite(world.camera)?world.camera:world.camera?.x||0;
    if(currentRoom!==world.roomId){
      if(actor.p.mainlineWater)E04Modules.resetMainlineWater(actor.p);
      saveRoom();currentRoom=world.roomId;
      const restored=rooms.get(currentRoom);
      for(const key of roomKeys)actor[key]=restored?.[key]||[];
      if(!restored)native.populate(actor,world);
      saveRoom();
    }
    // Reconnect only this port's objects after a room return / save restore.
    // Ordinary stage bosses and hazards remain stage-owned combat targets.
    for(let i=world.enemies.length-1;i>=0;i--)if(world.enemies[i].nativeOwner===owner&&!actor.foes.includes(world.enemies[i]))world.enemies.splice(i,1);
    for(const e of actor.foes)if(!world.enemies.includes(e))world.enemies.push(e);
    return status();
  }
  function normalize(input) {
    const v={...input,x:Math.max(-1,Math.min(1,Number(input.x)||0)),y:input.y===undefined?Number(!!input.down)-Number(!!input.up):Math.max(-1,Math.min(1,Number(input.y)||0)),
      action:!!(input.attack||input.action),jump:!!input.jump,auxiliary:!!(input.ability||input.auxiliary),tool:!!(input.tool||input.cycle)};
    for(const [edge,key,aliases] of [['jumpEdge','jump',['jumpPressed']],['toolEdge','tool',['toolPressed','cyclePressed']],['auxEdge','auxiliary',['abilityPressed','interactPressed']]])
      v[edge]=E04Modules.inputEdge(input,edge,aliases,()=>v[key]&&!previous[key]);
    previous=v;return v;
  }
  function publish(before) {
    syncPlayer();
    const score=Math.max(0,actor.score-before.score),coins=Math.max(0,actor.coins-before.coins);
    if(score)currentWorld?.addScore?.(score);
    for(let i=0;i<coins;i++)currentWorld?.collectCoin?.();
    if(actor.hp!==before.hp)emit('actor-health',{hero:owner,hp:actor.hp,maxHealth:actor.maxHp});
    // Terra's native armoured body can break ordinary shared bricks. Question
    // rewards still run through the stage's single-use bump transaction.
    if(actor.p.headHit){actor.p.headHit=terraMainlineHeadContact(actor.p,actor.level.surfaces);currentWorld?.bump?.(actor.p.headHit,true);}
    return status();
  }
  function before() { return {hp:actor.hp,score:actor.score,coins:actor.coins,dead:new Set(currentWorld?.enemies.filter(e=>e.dead)||[])}; }
  function step(p,input={},world) {
    live();if(p!==actor?.p)throw new Error('Stale Terra body');prepareRoom(world);terraMainlineMountClearance(actor);
    if(paused||actor.mainlineDead||p.dying)return status();
    const was=before(),v=normalize(input),support=actor.level.surfaces.find(q=>q.id===p.support);
    const water=E04Modules.isMainlineWater(world);
    if(!water&&p.grounded&&support){p.x+=support.dx||0;p.y+=support.dy||0;}
    p.headHit=null;
    native.run(actor,v,()=>{
      // Mount/tool commands can change the native body before water leases it.
      let commands=input;
      if(input.mountPressed&&actor.mountIntent){
        actor.mountIntent=null;actor.mounted=false;actor.t10PendingMount=null;r07SetMountHeight(actor,false);commands={...input,mountPressed:false};
      }else if(input.mountPressed)actor.mountIntent=actor.mountType||(actor.slimeOwned?'slime':actor.ufoOwned?'ufo':null);
      native.commands(commands,v);
      if(input.mountCyclePressed&&actor.mountIntent)actor.mountIntent=actor.mountType;
      if(actor.mounted&&!actor.mountIntent)actor.mountIntent=actor.mountType;
      const travel=v.x?Math.sign(v.x)*Math.max(Math.abs(p.vx||0),actor.mounted&&actor.mountType==='ufo'?5:2.75):p.vx||0;
      terraMainlineMountClearance(actor,travel);
      if(water||p.mainlineWater)E04Modules.runMainlineWater(p,v,world,next=>native.step(next),{alive:()=>!actor.mainlineDead&&!p.dying});
      else native.step(v);
      terraMainlineMountClearance(actor,travel);
    });
    actor.cam=Number.isFinite(world.camera)?world.camera:world.camera?.x||0;
    saveRoom();return publish(was);
  }
  function hurt(p,source={},world,options={}) {
    live();if(p!==actor?.p)throw new Error('Stale Terra body');if(world)prepareRoom(world);
    if(paused||p.dying)return status();const was=before();
    if(options.shielded)native.run(actor,{},()=>native.hurt(source,options));
    else currentWorld?.damage?.(source);
    return publish(was);
  }
  function downgrade(p,world){
    live();if(p!==actor?.p)throw new Error('Stale Terra body');if(world)prepareRoom(world);
    // Weapon upgrades are expendable in Mario's world; earned traversal gear,
    // supplies and the hidden-room vitals stay owned by the loadout transfer.
    Object.assign(actor,{kit:null,t13Weapon:'starfury',t13Owned:['starfury'],t13WeaponOverride:false,
      t12Blade:false,t12Stealth:false,t12Dash:0,t12Guardian:null,shield:0,shieldTicks:0,boostTicks:0});
    actor.minions=[];actor.projectiles=[];actor.t12Boosts=[];
    p.attack=0;p.cooldown=0;p.power=0;syncPlayer();return true;
  }
  function supply(p,request={},world){
    live();if(p!==actor?.p)throw new Error('Stale Terra body');if(world)prepareRoom(world);
    return native.run(actor,{},()=>native.supply(request));
  }
  function reconcileBody(p,world,travel={}){
    live();if(p!==actor?.p)throw new Error('Stale Terra body');if(world)prepareRoom(world);
    terraMainlineMountClearance(actor,Number(travel.x)||0);return status();
  }
  function beginDeath(p){if(p===actor?.p){actor.mainlineDead=true;p.dying=true;p.attack=0;}}
  function pickup(p,item,world) {
    live();if(p!==actor?.p)throw new Error('Stale Terra body');if(world)prepareRoom(world);
    const was=before(),accepted=native.run(actor,{},()=>native.pickup(item));
    if(actor.mounted)actor.mountIntent=actor.mountType;terraMainlineMountClearance(actor);
    return {...publish(was),accepted:!!accepted};
  }
  function defeatEnemy(p,e,world){
    if(e.dead||e.nativeOwner!==owner)return false;prepareRoom(world);
    const was=before();native.run(actor,{},()=>native.defeat(e));
    // The caller awards the shared contact score; keep only the native death feedback.
    actor.score=was.score;publish(was);return true;
  }
  function damageEnemy(p,e,amount,hit,world){
    if(e.dead||e.nativeOwner!==owner)return false;prepareRoom(world);
    const was=before();native.run(actor,{},()=>native.damage(e,amount,hit));publish(was);return true;
  }
  function enemyContact(p,e,context={},world){
    live();if(p!==actor?.p)throw new Error('Stale Terra body');if(world)prepareRoom(world);
    if(!e||typeof e!=='object'||paused||actor.mainlineDead||p.dying)return false;
    const tick=context.tick??currentWorld?.tick??actor.ticks;if(terraSlimeContactSeen(actor,e,tick))return true;
    const box=terraSlimeContactBox(actor,e,context);if(!box)return false;
    // Original enemies keep their original flatten/shell/hazard rule. Mounts
    // never replace that contract with unconditional damage or a new death.
    if(context.definition?.origin==='mario'){
      const handled=!!currentWorld?.classicContact?.(e,context);if(handled)terraSlimeContactCommit(actor,e,tick);return handled;
    }
    const accepted=currentWorld?.damageEnemy?.(e,R07_SLIME.stompDamage,{id:'slime-contact-'+tick+'-'+String(e.id),kind:'slime-stomp'});
    native.run(actor,{},()=>terraSlimeContactBounce(actor,e,box,tick,accepted?R07_SLIME.stompDamage:0));currentWorld?.contactGrace?.(6);syncPlayer();return true;
  }
  function drawPlayer(g,p,tick,view={}) {
    if(disposed||!actor||p!==actor.p)return false;
    return native.run(actor,{},()=>native.drawPlayer(g,p,tick,view),true);
  }
  function drawWorld(g,view={}) {
    if(disposed||!actor)return false;
    return native.run(actor,{},()=>native.drawWorld(g,view),true);
  }
  function drawPickup(g,item,tick=0) {
    if(disposed||!actor)return false;
    return native.run(actor,{},()=>native.drawPickup(g,item,tick),true);
  }
  function drawHud(g,view={},width=256,drawText) {
    if(disposed||!actor)return false;
    return lastHud=native.run(actor,{},()=>native.drawHud(g,view,width,drawText),true);
  }
  function snapshot(p=actor?.p) {
    live();if(p!==actor?.p)throw new Error('Stale Terra body');saveRoom();
    const loadout=Object.fromEntries(Object.entries(actor).filter(([key])=>!transient.has(key)));
    return clone({schema:'rf02-terra-mainline-v1',hero:owner,loadout,player:p,currentRoom,rooms:[...rooms]});
  }
  function validateSave(save) {
    if(!save||save.schema!=='rf02-terra-mainline-v1'||save.hero!==owner||!save.loadout||!save.player||!Array.isArray(save.rooms)||save.rooms.length>64)throw new TypeError('Invalid Terra actor save');
    let nodes=0;
    function visit(value,depth=0){
      if(++nodes>60000||depth>16)throw new TypeError('Terra save exceeds bounds');
      if(typeof value==='number'&&!Number.isFinite(value))throw new TypeError('Non-finite Terra save value');
      if(value&&typeof value==='object')for(const [key,item]of Object.entries(value)){
        if(['__proto__','prototype','constructor'].includes(key))throw new TypeError('Unsafe Terra save key');visit(item,depth+1);
      }else if(!['string','number','boolean','undefined'].includes(typeof value)&&value!==null)throw new TypeError('Non-data Terra save value');
    }
    visit(save);
    if(!Number.isFinite(save.loadout.hp)||!Number.isFinite(save.loadout.maxHp)||save.loadout.maxHp<1||save.loadout.maxHp>10000||save.loadout.hp<0||save.loadout.hp>save.loadout.maxHp)throw new TypeError('Invalid Terra health');
    if(save.loadout.mountIntent!=null&&!['slime','ufo'].includes(save.loadout.mountIntent))throw new TypeError('Invalid Terra mount intent');
    if(!Number.isInteger(save.loadout.tool)||save.loadout.tool<0||save.loadout.tool>5)throw new TypeError('Invalid Terra tool');
    for(const [key]of Object.entries(save.loadout))if(transient.has(key))throw new TypeError('World reference in Terra loadout');
    const ids=new Set();for(const row of save.rooms){if(!Array.isArray(row)||row.length!==2||typeof row[0]!=='string'||ids.has(row[0])||!row[1])throw new TypeError('Invalid Terra room save');ids.add(row[0]);
      for(const [key,value]of Object.entries(row[1]))if(!roomKeys.includes(key)||!Array.isArray(value)||value.length>4000)throw new TypeError('Invalid Terra room data');
    }
  }
  function restore(p,save) {
    live();if(p!==actor?.p)throw new Error('Stale Terra body');validateSave(save);const value=clone(save);
    Object.assign(actor,value.loadout,{mainline:true,pipe:null,t11Chest:null,t21Deer:null});
    // The host's spawn/room transition is authoritative; restore actor mechanics
    // without teleporting it back to the position at which the save was made.
    const position={x:p.x,y:p.y};Object.assign(p,value.player,position,{hero:owner,nativeActor:owner});
    rooms.clear();for(const [id,room]of value.rooms)rooms.set(id,room);
    currentRoom=null;currentWorld=null;previous={};actor.mountIntent??=actor.mounted?actor.mountType:null;syncPlayer();return status();
  }
  function carry(p=actor?.p) {
    live();if(p!==actor?.p)throw new Error('Stale Terra body');
    return terraMainlineCarry(actor);
  }
  function respawnCarry(p=actor?.p){
    live();if(p!==actor?.p)throw new Error('Stale Terra body');
    return terraMainlineRespawnCarry(actor);
  }
  function restoreCarry(p,data) {
    live();if(p!==actor?.p)throw new Error('Stale Terra body');
    if(data?.schema!=='rf02-terra-carry-v1'||data.hero!==owner||!data.loadout||new TextEncoder().encode(JSON.stringify(data)).length>4096)throw new TypeError('Invalid Terra carry');
    for(const key of Object.keys(data.loadout))if(!carryKeys.includes(key))throw new TypeError('Non-resource field in Terra carry');
    validateSave({schema:'rf02-terra-mainline-v1',hero:owner,loadout:data.loadout,player:{},rooms:[]});
    // Native HP is a hidden-scene resource. Only the shared stage can kill the
    // mainline body; restoring a defeated arena's equipment cannot kill it.
    Object.assign(actor,terraMainlineNormalizeMountCarry(clone(data.loadout)));actor.mainlineDead=false;
    native.run(actor,{},()=>native.afterRestore?.(actor));terraMainlineMountClearance(actor);syncPlayer();return status();
  }
  function reward(p,value,world){
    live();if(p!==actor?.p)throw new Error('Stale Terra body');if(value?.kind!=='terra-equipment')return false;
    if(world)prepareRoom(world);const was=before();
    if(value.loadout)restoreCarry(p,{schema:value.schema,hero:value.hero,loadout:value.loadout});
    else native.run(actor,{},()=>native.reward?.(value));
    return publish(was);
  }
  function reset() {
    live();
    for(const list of worldEnemies.values())for(let i=list.length-1;i>=0;i--)if(list[i].nativeOwner===owner){
      if(list[i].mainlineAnchor)list.splice(i,1,clone(list[i].mainlineAnchor));else list.splice(i,1);
    }
    rooms.clear();worldEnemies.clear();actor=currentWorld=null;currentRoom=null;previous={};paused=false;lastHud=null;
    return {hero:owner,hp:1,maxHealth:2,dead:false};
  }
  function audio(playing,reason='playing') {
    if(disposed||!actor)return {playing:false};
    return native.run(actor,{},()=>native.audio(!!playing,reason));
  }
  function sound(event) {if(disposed||!actor)return false;return native.run(actor,{},()=>native.sound(event));}
  function pause() {paused=true;previous={};return status();}
  function resume() {paused=false;previous={};return status();}
  function dispose() {
    if(disposed)return;try{if(actor)native.run(actor,{},()=>native.audio(false,'dispose'));}
    finally{disposed=true;native.release();rooms.clear();worldEnemies.clear();actor=currentWorld=null;previous={};}
  }
  function view() {return actor?{...status(),inventory:clone(actor.t13Inventory),accessories:clone(actor.t13Accessories),ownedWeapons:[...actor.t13Owned],
    ammo:actor.ammo,mana:actor.mana,healPotions:actor.healPotions,roomId:currentRoom,nativeTicks:actor.ticks}:null;}
  // The host exposes this read-only copy only through its existing ?test=1
  // diagnostics. No extra gameplay mutation or native fixture is introduced.
  function diagnostics() {return actor?{...view(),hud:clone(lastHud),native:snapshot(),audio:native.run(actor,{},()=>native.inspect?.()||null)}:null;}
  return Object.freeze({backtracking:true,create,prepareRoom,reconcileBody,step,enemyContact,combat:()=>status(),hurt,downgrade,isUpgraded:()=>!!actor&&native.weapon(actor)!=='starfury',defeatEnemy,damageEnemy,supply,beginDeath,pickup,reward,drawPlayer,drawWorld,drawPickup,drawHud,snapshot,restore,carry,restoreCarry,respawnCarry,reset,dispose,audio,sound,pause,resume,
    view,diagnostics,bindings:()=>native.bindings?.()||null});
}

/* Native bindings. Every temporary lexical/global change is restored even if a
 * native update or draw throws. Input ownership is active only inside `run`.
 * The existing hidden challenge keeps its own state/mainState/builder intact.
 */
mainlineTerraActor = function createMainlineTerraActor(options) {
  const nativeStep=step;
  let inputState={...t17Input,buttons:[],previous:[],blocked:new Set(),keyBlocked:new Set(),lastState:null},
      pointerState={...t13Pointer,active:false,down:false},oldPointerState={...r05Pointer,active:false,down:false,pressed:false},
      device='keyboard',leftAim=[1,0],soundPrepared=false,sourceRoster=Object.freeze([]),sourceRosterKey=null,dropSerial=0;
  const replace=(target,value)=>{for(const key of Object.keys(target))delete target[key];Object.assign(target,value);};
  function run(s,v,fn,drawing=false) {
    const saved={state,mainState,r05Builder,hero,mode,frame,held,pending,prev,stageChoice,r05EntryChoice,
      pointer:{...t13Pointer},oldPointer:{...r05Pointer},input:{...t17Input},device:t20Device,leftAim:t20LeftAim,
      rewards:r06RewardsOpen,helmet:t10Helmet,dropSerial:t21DropSerial,tools:tools.slice(),audioSync,r06UpdateUI,t13UI,t15Sync,cam:s?.cam,camY:s?.camY,r07CamY:s?.r07CamY};
    mainlineActorDepth++;
    try {
      state=s;mainState=null;r05Builder=null;hero='sandboxTrio';mode='playing';frame=s?.ticks||0;
      stageChoice=0;r05EntryChoice=0;held=new Set();pending={};prev={};r06RewardsOpen=false;t10Helmet=true;t21DropSerial=Math.max(dropSerial,s?.mainlineDropSerial||0);
      replace(t17Input,inputState);replace(t13Pointer,pointerState);replace(r05Pointer,oldPointerState);
      t20Device=device;t20LeftAim=leftAim;audioSync=()=>{};r06UpdateUI=t13UI=t15Sync=()=>{};
      if(s){t17PrepareState(s);terraMainlinePointerInput(s,v);
      if(drawing){s.cam=0;s.camY=0;s.r07CamY=0;}}
      return withAudioOwner('actor:sandboxTrio',fn);
    } finally {
      inputState={...t17Input};pointerState={...t13Pointer};oldPointerState={...r05Pointer};device=t20Device;leftAim=t20LeftAim;dropSerial=t21DropSerial;if(s)s.mainlineDropSerial=dropSerial;
      if(s&&drawing){s.cam=saved.cam;s.camY=saved.camY;s.r07CamY=saved.r07CamY;}
      ({state,mainState,r05Builder,hero,mode,frame,held,pending,prev,stageChoice,r05EntryChoice}=saved);
      replace(t13Pointer,saved.pointer);replace(r05Pointer,saved.oldPointer);replace(t17Input,saved.input);
      t20Device=saved.device;t20LeftAim=saved.leftAim;r06RewardsOpen=saved.rewards;t10Helmet=saved.helmet;t21DropSerial=saved.dropSerial;tools.splice(0,tools.length,...saved.tools);audioSync=saved.audioSync;
      r06UpdateUI=saved.r06UpdateUI;t13UI=saved.t13UI;t15Sync=saved.t15Sync;
      mainlineActorDepth--;
    }
  }
  function freezeTemplate(value){
    if(value&&typeof value==='object'){for(const v of Object.values(value))freezeTemplate(v);Object.freeze(value);}return value;
  }
  function ensureSourceRoster(){
    // Original conversion depends on whether each native NPC image is ready.
    // Cache only templates: every room still receives its own mutable clone.
    const key=Object.values(T21_NPCS).map(d=>t21Art[d.art]?'1':'0').join('');
    if(key===sourceRosterKey)return;
    const legacy=newState();
    sourceRoster=freezeTemplate(legacy.foes.filter(e=>!['goomba','koopa'].includes(e.kind)).map(e=>JSON.parse(JSON.stringify(e))));
    sourceRosterKey=key;
  }
  function create(){return run(null,{},()=>{
    ensureSourceRoster();
    const s=newState({worldOwner:'stage'});
    s.mainline=true;s.mainlineDead=false;s.pipe=null;s.t11Chest=null;s.t21Deer=null;s.t11Transition=null;
    s.r05Arena=false;s.secret=false;s.finish=false;s.ending=null;s.notice='';s.noticeTime=0;s.events=[];
    s.score=s.coins=0;s.r07Loot=[];s.t13Recalling=false;return s;
  });}
  function populate(s,world){run(s,{},()=>{
    if(/(^|-)1-1(?:-|$)/.test(world.levelId)&&world.entryRoom){
      const x=Math.ceil((s.p.x+s.p.w+32)/16)*16+8,ground=world.solids.filter(q=>!q.hidden&&q.collision==='solid'&&x-8>=q.x&&x+8<=q.x+q.w&&q.y>=s.p.y+s.p.h-2).sort((a,b)=>a.y-b.y)[0];
      if(ground&&!world.solids.some(q=>q!==ground&&!q.hidden&&near({x:x-8,y:ground.y-16,w:16,h:16},q)))s.campfires.push({x,y:ground.y,phase:0});
    }
    const anchors=world.enemies.filter(e=>!e.nativeOwner&&!/bowser|piranha|lakitu|bullet|fire|cheep|blooper/i.test(e.type||e.kind||''));
    for(const [i,anchor]of anchors.entries()){
      const ground=s.level.surfaces.filter(q=>!q.hidden&&anchor.x+anchor.w>q.x&&anchor.x<q.x+q.w&&q.y>=anchor.y+anchor.h-2).sort((a,b)=>a.y-b.y)[0];
      if(!ground)continue;
      const template=sourceRoster[i%sourceRoster.length];
      let foe=template?JSON.parse(JSON.stringify(template)):t10MakeFoe('slime',ground,anchor.x,i,'blue');
      // A copied R21 vulture is flight-capable but starts perched. Its old
      // private-map home is replaced here; only actual flying poses spawn aloft.
      const spawnBody=e=>{const perched=e.t21Species==='vulture'&&e.t21Mood==='perched',airborne=e.flying&&!perched;
        return {...e,x:anchor.x,y:airborne?Math.max(55,ground.y-65):ground.y-e.h,grounded:!airborne};};
      const fits=e=>e.x>=0&&e.x+e.w<=world.width&&!world.solids.some(q=>!q.hidden&&q.collision==='solid'&&near(e,q));
      foe=spawnBody(foe);
      // A closed Mario tunnel cannot inherit a private-map flying spawn inside
      // masonry. Keep a fitting native ground species, or the authored enemy.
      if(!fits(foe))foe=spawnBody(t10MakeFoe('slime',ground,anchor.x,i,'blue'));
      if(!fits(foe))continue;
      Object.assign(foe,{home:ground.id,spawnX:anchor.x,vx:0,vy:0,
        age:i*7,active:false,hitBy:-1,knock:0,flash:0});foe.spawnY=foe.y;
      foe.id=anchor.id;foe.nativeOwner='sandboxTrio';foe.sourceType=anchor.type;foe.dead=anchor.dead?46:0;
      foe.mainlineAnchor=JSON.parse(JSON.stringify(anchor));
      t16AdaptFoe(foe,s);s.foes.push(foe);world.enemies.splice(world.enemies.indexOf(anchor),1,foe);
    }
    t21Populate(s);
    // Native harvest props follow shared surfaces; no private RF02 geometry or
    // fixed-coordinate boss/rail/story content is imported into these rooms.
    for(const site of terraMainlineTreeSites(world)){
      const biome=t16BiomeAt(site.x,s).id;
      s.trees.push({...site,variant:biome==='snow'?'boreal':'forest',t16Biome:biome,hp:3,maxHp:3,
        t13Cut:0,t13CutRow:null,t13Gone:false,shake:0,fall:0,rewarded:false});
    }
  });}
  function supply(request){
    const sequence=['boomstick','slimySaddle','terraBlade','ufo'],index=Math.max(0,Math.trunc(request.index||0));
    const owned=kind=>kind==='slimySaddle'?state.slimeOwned:kind==='ufo'?state.ufoOwned:r06Weapon(state)===kind;
    const offset=sequence.findIndex((_,offset)=>!owned(sequence[(index+offset)%sequence.length]));
    const reward=offset<0?'boomstick':sequence[(index+offset)%sequence.length];
    return {kind:reward,nativeKind:reward,w:16,h:16,vx:0,vy:0,stationary:true,upgrade:true};
  }
  function pickup(item){
    if(!item||typeof item!=='object')return false;const s=state,kind=pickupKind(item),count=Math.max(1,Math.min(999,Math.trunc(item.count||1)));
    if(item.kit)return r07EquipDrop(s,{kit:item.kit,age:45,grounded:true,blocked:false,x:s.p.x,y:s.p.y,w:34,h:34});
    if(kind==='slimySaddle'||kind==='slimeMount'){r07CollectSaddle(s);return true;}
    if(kind==='ufo'){s.ufoOwned=true;s.mountOwned=true;s.mountType='ufo';terraSound('pickup');return true;}
    if(!Object.hasOwn(T21_ITEMS,kind)&&!['dirt','stone','copper','iron','gold','acorn','torch','arrows','wood'].includes(kind))return false;
    return t21Collect(s,kind,count)!==false;
  }
  function drawPlayer(g,p,tick,view){
    if(g!==ctx)throw new TypeError('Terra renderer requires the shared canvas context');
    const finish=view.finish,motion=p.scriptedMotion,scripted=!!(finish||motion);
    const moving=motion?motion.moving&&Math.abs(motion.dx)>1e-6:finish?.phase==='walk'&&Math.abs(p.vx)>.1;
    const walk=scripted?(moving?(motion?.distance??p.anim??0):0):p.walk,face=motion?.x||p.facing;
    // Finishing is a pose of the complete actor, including its native mount.
    // Rendering borrows a projection; it never changes equipment or body state.
    const saved=state;
    if(scripted)state={...state,ticks:tick,p:{...p,facing:face,slimeFrame:p.grounded?(moving?Math.floor(walk/12)%4:0):1}};
    try{
      r06DrawMount(state,0);
      person(g,p.x+p.w/2,p.y+p.h,face,walk,!p.grounded,scripted?0:p.attack,scripted?0:state.tool,!p.star&&!scripted&&p.invuln&&Math.floor(state.ticks/4)%2?.42:1);
      return {hero:'sandboxTrio',drawn:true,asset:'RF02 R21 native body/armor/weapon/mount layers',weapon:r06Weapon(state),armor:r06Armor(state),frame:Math.floor((walk||0)/5),attack:p.attack,mounted:!!state.mounted,mountType:state.mountType,bodyHeight:p.h};
    }finally{state=saved;}
  }
  function drawWorld(g,view){
    if(g!==ctx)throw new TypeError('Terra renderer requires the shared canvas context');
    const s=state,cam=Number(view.cam)||0,width=Number(view.width||view.viewportWidth)||W;
    for(const tree of s.trees)if(tree.x>cam-90&&tree.x<cam+width+90)t12DrawTree(g,tree,0);
    for(const q of s.built)if(q.x+q.w>cam&&q.x<cam+width)sheet(g,'wood',[3,3,18,6],q.x,q.y,q.w,q.h);
    for(const t of s.t14Torches||[])if(t.x>cam-25&&t.x<cam+width+25){g.save();g.translate(t.x,t.y);g.scale(.75,.75);r07Furniture('torch',0,0,s.ticks,t.phase||0);g.restore();}
    for(const f of s.campfires||[])if(f.x>cam-25&&f.x<cam+width+25){g.save();g.translate(f.x,f.y);g.scale(.75,.75);r07Furniture('campfire',0,0,s.ticks,f.phase||0);g.restore();}
    for(const e of s.foes)if(e.x+e.w>cam-60&&e.x<cam+width+60&&e.dead<45)t10DrawFoe(e,0);
    r06DrawProjectiles(s,0);r07DrawLoot(s,0);
    for(const n of s.numbers)E04Modules.drawCombatNumber(g,n.text,n.x,n.y,{color:n.color||'#fff29e'});
    if(s.tool)t13DrawCursor(s);return true;
  }
  function pickupKind(item){const kind=item.nativeKind||item.kind||item.type;return kind==='mushroom'?'boomstick':['flower','fireflower'].includes(kind)?'slimySaddle':kind;}
  function drawPickup(g,item,tick){
    if(g!==ctx)throw new TypeError('Terra renderer requires the shared canvas context');
    const kind=pickupKind(item),key=T21_ITEMS[kind]?.icon||(kind==='slimySaddle'?'slimySaddle':kind==='ufo'?'ufoKey':null);if(!key)return false;
    t15Icon(g,key,item.x+(item.w||16)/2,item.y+(item.h||16)/2,Math.min(16,item.w||16));return {drawn:true,kind,asset:key};
  }
  function drawHud(g,view,width,drawText){
    if(g!==ctx)throw new TypeError('Terra renderer requires the shared canvas context');
    const m=t15Model(state),y=40,right=width-94;
    const text=(value,x,yy,color='#fff1d3')=>{if(drawText)return drawText(g,value,x,yy);g.save();g.scale(.5,.5);t15Text(value,x*2,yy*2,12,color);g.restore();};
    g.save();g.imageSmoothingEnabled=false;
    for(let i=0;i<6;i++){const x=31+i*15;if(i===m.tool){g.strokeStyle='#ffe197';g.lineWidth=1;g.strokeRect(x-7.5,32.5,14,15);}t15Icon(g,m.keys[i],x,y,12);}
    if(m.counts[0]!=null)text(m.counts[0],24,48);
    t15Icon(g,'manaSymbol',right,y,9);text(m.mana,right+8,37,'#add9ff');
    const torch=m.tool===4;t15Icon(g,torch?'torchPlaced':'wood',right+40,y,11);text(torch?m.torch:m.wood,right+49,37);
    const mount=state.mountType==='ufo'&&state.ufoOwned?'ufo':state.mountType==='slime'&&state.slimeOwned?'slime':state.ufoOwned?'ufo':state.slimeOwned?'slime':null;
    const mountRegions=[];
    if(mount){
      const key=mount==='ufo'?'ufoKey':'slimySaddle',mounted=!!state.mounted&&state.mountType===mount,binds=t21Config().actions;
      const binding=action=>{const b=binds[action];return b?.keys?.length?t21KeyLabel(b.keys[0]):b?.pad?.length?(T21_PAD_NAMES[b.pad[0]]||'按钮 '+b.pad[0]):'未绑定';};
      const controls=binding('mount')+' 上下坐骑'+(state.slimeOwned&&state.ufoOwned?' · '+binding('mountCycle')+' 切换':'');
      t15Icon(g,key,width-9,y,12);
      mountRegions.push({id:'terra-mount',key,mount,mounted,owned:true,x:width-16,y:y-7,w:14,h:14,lines:[mount==='ufo'?'飞碟坐骑钥匙':'史莱姆坐骑鞍',(mount==='ufo'?'自由飞行、悬停':'弹跳、踩踏')+' · '+(mounted?'骑乘中':'已拥有'),controls]});
    }
    // Reuse the shared, CSS-pointer-aware canvas hit test. A 2x UI projection
    // keeps this contextual card at the compact scoreboard's visual scale.
    g.scale(.5,.5);
    const tooltip=E04Modules.drawCanvasTooltip(g,mountRegions.map(q=>({...q,x:q.x*2,y:q.y*2,w:q.w*2,h:q.h*2})),{width:width*2,height:480,enabled:t20Device!=='gamepad'});
    g.restore();return {hero:'sandboxTrio',top:32,bottom:m.counts[0]!=null?53:48,tool:m.tool,weapon:m.weapon,ammo:m.counts[0],wood:m.wood,mountRegions,tooltip:tooltip?{...tooltip,box:Object.fromEntries(Object.entries(tooltip.box).map(([k,v])=>[k,v/2]))}:null};
  }
  function audio(playing,reason='playing'){
    if(playing&&!soundPrepared){soundPrepared=true;audioInit();loadExtraAudio().then(()=>t10LoadSounds()).catch(error=>{soundPrepared=false;console.warn('Terra audio preparation',error);});r06MusicUnlocked=true;}
    const previousMode=mode;try{mode=playing?'playing':'paused';r06SyncMusic();if(!playing){r05StopLocal();r08StopRoars();if(reason==='dying')withEffectHandoff(currentPlayerDeathVoice('sandboxTrio'),()=>stopEffects());else stopEffects();}}
    finally{mode=previousMode;}
    return {playing:!!playing,key:r06MusicKey,tracks:Object.fromEntries(Object.entries(r06Music).map(([key,t])=>[key,{state:t.state,paused:t.audio.paused}]))};
  }
  function sound(event){
    const key={pickup:'coin',coin:'coin',life:'pickup',portal:'door',bump:'break',complete:'clear',flag:'flag',pause:'pause'}[event];
    if(key){terraSound(key);return true;}if(event==='death'){terraSound('death');return true;}
    // Weapon/hurt/loot effects already originate in the native update. Consume
    // the host notification so no generic Mario fire/hit sound is layered on it.
    return ['attack','fire','hurt','jump','jump_super'].includes(event);
  }
  return createTerraMainlinePort({acquire:()=>{mainlineActorUsers++;},release:()=>{mainlineActorUsers=Math.max(0,mainlineActorUsers-1);},
    create,populate,run,
    defeat:e=>{const target={id:e.id,x:e.x+e.w/2,y:e.y+e.h/2,w:e.w,h:e.h,obj:e};state.committingEnemyDefeat=true;try{r06DamageTarget(target,Math.max(1,e.hp||1),'star');}finally{state.committingEnemyDefeat=false;}},
    damage:(e,n,hit)=>r06DamageTarget({id:e.id,x:e.x+e.w/2,y:e.y+e.h/2,w:e.w,h:e.h,obj:e},n,hit?.kind||'projectile'),
    commands:terraMainlineCommands,step:nativeStep,weapon:r06Weapon,armor:r06Armor,bindings:()=>t21Config().actions,
    afterRestore:s=>terraMainlineApplyNativeCarry(s,terraMainlineCarry(s)),
    hurt:source=>{const s=state,p=s.p;p.invuln=Math.max(p.invuln||0,120);p.hurtLock=12;p.vx=(p.x+p.w/2<(source.x??p.x+p.w)?-1:1)*3;p.vy=-3.3;p.grounded=false;p.support=null;p.attack=0;terraSound('hurt');},
    supply,pickup,reward:v=>{if(v.kit&&v.kit!==state.kit)pickup({kit:v.kit});if(v.cloudJump)pickup({kind:'cloudBottle'});if(v.slimeOwned&&!state.slimeOwned)pickup({kind:'slimySaddle'});if(v.ufoOwned&&!state.ufoOwned)pickup({kind:'ufo'});},drawPlayer,drawWorld,drawPickup,drawHud,audio,sound,
    inspect:()=>({musicKey:r06MusicKey,tracks:Object.fromEntries(Object.entries(r06Music).map(([key,t])=>[key,{state:t.state,paused:t.audio.paused,readyState:t.audio.readyState,source:t.audio.currentSrc||t.audio.src}])),decodedEffects:[...bank.keys()].filter(k=>k.startsWith('trio13_'))})},options);
};

mainlineTerraActor.prepareAudio=async function(options={}){
 audioInit(false);await loadExtraAudio(options);await t10LoadSounds();
 const missing=Object.keys(TRIO_AUDIO).filter(key=>!bank.has('trio13_'+key));if(missing.length)throw new Error('Terra audio unavailable: '+missing.join(', '));
};

// Public audio bridge: these tracks and their HTMLAudio elements belong to the
// Terra IIFE. The shared host must never reference the closure's locals directly.
mainlineTerraActor.musicSource=key=>R06_LOCAL_MUSIC[key];
const terraPreparedMusicLoads=new Map();
function terraWaitForPreparedMedia(element,timeoutMs=12000){
 if(element.readyState>=3)return Promise.resolve();
 return new Promise((resolve,reject)=>{
  let timer;const finish=error=>{clearTimeout(timer);element.removeEventListener('canplay',ready);element.removeEventListener('error',failed);error?reject(error):resolve();};
  const ready=()=>finish(),failed=()=>finish(new Error('Terra music cannot be decoded'));
  element.addEventListener('canplay',ready,{once:true});element.addEventListener('error',failed,{once:true});
  timer=setTimeout(()=>finish(new Error('Terra music preparation timed out')),timeoutMs);
  try{element.load();}catch(error){finish(error);}
 });
}
mainlineTerraActor.prepareMusic=function(key,options={}){
 const source=R06_LOCAL_MUSIC[key],track=r06Music[key];
 if(!source||!track)return Promise.reject(new Error('Unknown Terra music: '+key));
 if(!terraPreparedMusicLoads.has(key))terraPreparedMusicLoads.set(key,Promise.resolve().then(async()=>{
  await readMediaBytes(source,options);
  const resolved=gameMediaSource(source);track.urls=[resolved];track.sourceIndex=0;track.restorePending=false;
  if(!track.local&&track.audio.paused){track.generation++;track.audio.src=resolved;track.state='not-loaded';track.nextTry=0;track.busy=false;}
  await terraWaitForPreparedMedia(track.audio);
 }).catch(error=>{terraPreparedMusicLoads.delete(key);throw error;}));
 return terraPreparedMusicLoads.get(key);
};

// Stage-owned bosses/hazards participate in the REAL Terra targeting / weapon
// system while their motion and room transaction stay in the common stage.
function terraMainlineMineTarget(s,raw){
  const p=s.p,origin={x:p.x+p.w/2,y:p.y+p.h/2},surfaces=s.level.surfaces;
  const visible=q=>!surfaces.some(w=>w!==q&&w.solid&&!w.hidden&&segmentHits(origin,{x:q.x+q.w/2,y:q.y+q.h/2},w,.01));
  const candidates=surfaces.filter(q=>!q.hidden&&['brick','block'].includes(q.material)&&!q.used)
    .map(q=>({...q,x:q.x+q.w/2,y:q.y+q.h/2,blockId:q.id,kind:'mainline-brick',valid:true,reason:'',pointer:!!raw.pointer,
      c:Math.floor(q.x/16),r:Math.floor(q.y/16),solid:q})).filter(q=>t13InReach(s,q)&&visible(q.solid));
  if(raw.pointer)return candidates.find(q=>raw.x>=q.solid.x&&raw.x<q.solid.x+q.w&&raw.y>=q.solid.y&&raw.y<q.solid.y+q.h)||null;
  const dx=raw.dx||0,dy=raw.dy||0;
  return candidates.filter(q=>dy&&!dx?Math.sign(q.y-origin.y)===dy&&q.solid.x<p.x+p.w&&q.solid.x+q.w>p.x:
    Math.sign(q.x-origin.x)===(dx||p.facing)&&q.solid.y<p.y+p.h&&q.solid.y+q.h>p.y)
    .sort((a,b)=>Math.hypot(a.x-origin.x,a.y-origin.y)-Math.hypot(b.x-origin.x,b.y-origin.y))[0]||null;
}
const terraMainlineToolTargetBase=t13ToolTarget;
t13ToolTarget=function(s,v={}){
  if(s.mainline&&s.tool===3){const target=terraMainlineMineTarget(s,t14RawTarget(s,v));if(target)return target;}
  return terraMainlineToolTargetBase(s,v);
};
const terraMainlineMineBase=t13Mine;
t13Mine=function(s,target){
  if(s.mainline&&target?.kind==='mainline-brick'){
    const q=s.level.surfaces.find(q=>q.id===target.blockId);
    if(!q||!['brick','block'].includes(q.material)||!t13InReach(s,target))return false;
    s.mainlineWorld?.bump?.(q.id,true);s.totalMined=(s.totalMined||0)+1;s.t13MineCount=(s.t13MineCount||0)+1;
    terraSound('break');t13Event('mainline-brick-mined',{id:q.id,x:q.x,y:q.y});return true;
  }
  return terraMainlineMineBase(s,target);
};
// The mainline uses protection; original hidden arenas keep their native HP,
// armour, potions and regeneration. Presentation must not decide damage rules.
const terraMainlineArenaHurtBase=r05Hurt;
r05Hurt=function(amount,x,source={}){if(state?.mainlineHealth)return terraMainlineDamage(state,{...source,damage:amount,x});return terraMainlineArenaHurtBase(amount,x,source);};
const terraMainlineHudBase=t15DrawHUD;
t15DrawHUD=function(s){
  if(!s?.mainlineHealth)return terraMainlineHudBase(s);
  const l=t15Layout(s),q=l.hp;ctx.save();ctx.beginPath();ctx.rect(0,0,l.viewW,l.viewH);ctx.rect(q.x*l.unit,q.y*l.unit,q.w*l.unit,q.h*l.unit);ctx.clip('evenodd');
  try{return terraMainlineHudBase(s);}finally{ctx.restore();if(s.t15Hud){delete s.t15Hud.hp;delete s.t15Hud.maxHp;s.t15Hud.healthMode='shared-protection';}}
};
const terraMainlineSyncBase=t15Sync;
t15Sync=function(s){terraMainlineSyncBase(s);t15HP.hidden=!!s?.mainlineHealth;if(s?.mainlineHealth)t15HP.disabled=true;};
const terraMainlineDockBase=t13UI;
t13UI=function(){const result=terraMainlineDockBase.apply(this,arguments);if(state?.mainlineHealth)t13Dock.hidden=true;return result;};
const terraMainlineHitBase=hitEnemy;
hitEnemy=function(e,amount,dir,kind,sourceKind=kind){
 if(state?.mainline&&e.nativeOwner==='sandboxTrio'&&!state.committingEnemyDefeat&&amount>=e.hp)return state.mainlineWorld.kill(e,{cause:sourceKind==='star'?'terra-star':sourceKind||'attack'});
 if(state?.mainline&&!e.nativeOwner&&state.mainlineTargets?.includes(e)){
  return state.mainlineWorld?.damageEnemy?.(e,amount,{kind:sourceKind==='star'?'terra-star':sourceKind||'attack'});
 }
 return terraMainlineHitBase(e,amount,dir,kind);
};
const terraMainlineTargetsBase=r06AllTargets;
r06AllTargets=function(s){
  const result=terraMainlineTargetsBase(s);
  for(const e of s.mainlineTargets||[])if(!e.nativeOwner&&!e.dead&&e.hp>0&&e.active!==false)
    result.push({id:e.id,x:e.x+e.w/2,y:e.y+e.h/2,w:e.w,h:e.h,obj:e});
  const left=s.mainline?s.mainlineWorld?.camera||0:s.cam||0,top=s.r05Arena?s.camY||0:0;
  const width=s.r05Arena?R06_VIEW.w:s.mainlineWorld?.viewportWidth||W,height=s.r05Arena?R06_VIEW.h:s.mainlineWorld?.height||H;
  return result.filter(t=>t.x+t.w/2>left&&t.x-t.w/2<left+width&&t.y+t.h/2>top&&t.y-t.h/2<top+height);
};
// Manual aim stays manual; automatic aim uses the same visible candidates as
// weapon hit tests, including the arena boss and ordinary mainline enemies.
r06Target=function(s,range=Infinity){let best=null,dist=range;
 for(const t of r06AllTargets(s)){const d=Math.hypot(t.x-s.p.x-s.p.w/2,t.y-s.p.y-s.p.h/2);if(d<dist){best={...t,vx:t.obj.vx||0,vy:t.obj.vy||0};dist=d;}}
 return best;
};
const terraMainlinePointerBase=r05SyncPointer;
r05SyncPointer=function(){if(state?.mainline||state?.mainlineInput)return;return terraMainlinePointerBase.apply(this,arguments);};
// RF02's final keyboard aim reprojects DOM client coordinates. The mainline
// already supplies world coordinates, so use those at the last native seam.
const terraMainlineAimBase=t17AimPoint,terraMainlineMouseTargetBase=t21MouseTarget;
t17AimPoint=function(s,v={},tool=false){
  if((s?.mainline||s?.mainlineInput)&&v.rightAim&&Math.hypot(v.ax||0,v.ay||0)>.25){const len=Math.hypot(v.ax,v.ay);return{x:s.p.x+s.p.w/2+v.ax/len*160,y:s.p.y+s.p.h/2+v.ay/len*160,source:'stick',pointer:false};}
  if((s?.mainline||s?.mainlineInput)&&t20Device==='keyboard'&&t17Input.source==='mouse'&&t13Pointer.active)
    return {x:t13Pointer.x,y:t13Pointer.y,source:'mouse',pointer:true};
  return terraMainlineAimBase(s,v,tool);
};
t21MouseTarget=function(s){
  if(s?.mainline||s?.mainlineInput)return t20Device==='keyboard'&&t17Input.source==='mouse'&&t13Pointer.active?{x:t13Pointer.x,y:t13Pointer.y,pointer:true}:null;
  return terraMainlineMouseTargetBase(s);
};
// Furniture uses the same shared support geometry as the player and remains
// owned by its room. Native hidden-room building keeps its original path.
const terraMainlinePlaceBase=t13Place;
t13Place=function(s,target,type){
 if(!s.mainline||![4,5].includes(type))return terraMainlinePlaceBase(s,target,type);
 const x=Math.floor(target.x/16)*16,y=Math.floor(target.y/16)*16,box={x,y,w:16,h:16};
 const solids=s.level.surfaces.filter(q=>!q.hidden&&q.solid),support=solids.some(q=>q.y===y+16&&x>=q.x&&x+16<=q.x+q.w);
 if(!support||!t13InReach(s,{x:x+8,y:y+8})||near(s.p,box)||solids.some(q=>near(box,q)))return false;
 const list=type===5?s.campfires:s.t14Torches;if(list.some(f=>Math.abs(f.x-x-8)<8&&f.y===y+16))return false;
 if(type===5){if(s.wood<10)return false;s.wood-=10;}else{if(s.t13Inventory.torch<=0)return false;s.t13Inventory.torch--;}
 list.push({x:x+8,y:y+16,phase:s.ticks%8});terraSound('build',{volume:.6});t13Event('mainline-furniture',{type,x,y});return true;
};
