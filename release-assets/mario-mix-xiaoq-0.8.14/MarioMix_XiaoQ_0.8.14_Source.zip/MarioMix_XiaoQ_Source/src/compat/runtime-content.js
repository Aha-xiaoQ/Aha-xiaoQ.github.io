/* The installation point for shipped native actors and optional authored
 * scenes. New adapters register here; campaign flow has no hero-name branches. */
const mainlineActorRegistry=E04Modules.createActorRegistry([
 {id:'mario',kind:'platform',legacyChapter:11,input:mainlineInputProfiles.mario,portrait:e04LegacyPortrait('mario',{selectionInset:2})},
 ...[
  ['bill',11],['megaman',11],['ryu',12],['tank',12,3],['ori',14],['sonic',14],
 ].map(([id,legacyChapter,selectionInset=0])=>({id,legacyChapter,input:mainlineInputProfiles[id],portrait:e04LegacyPortrait(id,{selectionInset}),create:()=>createRf02MainlineActor(id),carry:'snapshot',restoreCarry:'restore',
   ...(['ori','sonic'].includes(id)?{foes:()=>createRf08CharacterFoes(id)}:{}),
   ...(id==='ori'?{scenes:{'1-4':createRf07OriCampaignStage},sceneAssets:{'1-4':['ori-course']}}:{})})),
 {id:'jackal',legacyChapter:11,input:E04Modules.JACKAL_INPUT,portrait:jackalRender.portrait,create:createJackalInstalledActor,foes:createJackalInstalledFoes,challenge:createJackalInstalledChallenge},
 {id:'sandboxTrio',legacyChapter:13,input:mainlineInputProfiles.sandboxTrio,portrait:e04LegacyPortrait('sandboxTrio'),create:()=>createRf02MainlineActor('sandboxTrio')},
]);
mainlineActorRegistry.validateRoster(E04Modules.campaignCatalog.heroIds());
e04InstallPortraits(mainlineActorRegistry);
