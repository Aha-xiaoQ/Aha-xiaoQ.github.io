/* Declaration-only installation. Original image and PCM data are source bound;
 * simulation lives in independent modules, not legacy Tank functions. */
const jackalOriginal=@@E04:file:src/data/jackal-installation.template.json@@;
const jackalImages={};
for(const [name,row]of Object.entries(jackalOriginal.images)){
 if(row.runtime===false)continue;
 const im=new Image();jackalImages[name]=im;mainlineAssetJobs.push(gameImage(im,row.data,'jackal'));
}
const jackalRender=E04Modules.createJackalRenderer({source:jackalOriginal,images:jackalImages,context:()=>ctx,viewport:()=>({width:W,height:H}),createSurface:()=>document.createElement('canvas')});
registerPresentationCues({
 'jackal:mainline':{source:'jackal_level1',category:'music',scope:'scene',gain:'stored',blocksStage:false},
 'jackal:level1':{source:'jackal_level1',category:'music',scope:'scene',gain:'stored',blocksStage:false},
 'jackal:boss':{source:'jackal_boss',category:'music',scope:'scene',gain:'stored',blocksStage:false},
 'jackal:victory':{source:'jackal_victory',category:'music',scope:'scene',gain:'stored',blocksStage:false},
});
let jackalAudioContext=null,jackalAudioJob=null;
function jackalAudioReady(){
 if(!audio||jackalAudioContext===audio)return;if(jackalAudioJob)return jackalAudioJob;
 const ac=audio;
 // The same verified, offline loader as all other installed sounds. Declared
 // music trim is applied after PCM decoding; effect gain stays measured.
  jackalAudioJob=prepareAudio(Object.keys(jackalOriginal.audio)).then(()=>{
  for(const [key,row]of Object.entries(jackalOriginal.audio)){
   const item=bank.get(key);if(!item)throw new Error('Missing verified Jackal audio '+key);
   if(item.owner!=='jackal'||item.role!==(row.category==='music'?'music':row.role||'effect')||item.semantic!==(row.semantic??null)||(item.voiceGroup??null)!==(row.voiceGroup??null))throw new Error('Jackal audio declaration mismatch '+key);
   if(row.category==='music')item.gain=row.gain;
  }jackalAudioContext=ac;
 }).catch(error=>{console.warn('Jackal original audio failed to decode',error);}).finally(()=>jackalAudioJob=null);
 return jackalAudioJob;
}
let jackalMainlineAudioGeneration=0;
function createJackalAudioPort(){
 let owner='actor:jackal',mood='level1',issued=false,muted=false,scene=false,paused=false,disposed=false,currentWorld=null,currentBody=null,mainlineOwner=null,musicStopped=false,musicSuspended=false;
  function play(key){jackalAudioReady();if(disposed||paused||!soundOn||document.hidden||mode==='paused'||jackalAudioContext!==audio||audio?.state!=='running')return false;
  if(key==='mainline-powerdown'){originalOneShot('hurt');return true;}
  if(!bank.has(key))throw new Error('Uninstalled Jackal audio cue '+key);
  // Original aircraft requests restart one APU effect every four source ticks.
  // The source declaration controls replacement; unrelated hits still overlap.
  if(jackalOriginal.audio[key]?.retrigger==='replace-owner-key')for(const voice of [...voices])if(voice.owner===owner&&voice.key===key)stopVoice(voice);
  startEffectVoice(key,{owner});return true;}
 function tick(){jackalAudioReady();if(disposed||paused||(!scene&&!mainlineOwner))return;
  if(!soundOn){cancelPresentationAudio(owner);muted=true;issued=false;return;}
  // Mute cancels a tune; enabling sound starts the current mood afresh. Pause
  // keeps its source offset instead. Neither path revives ordinary effects.
  if(muted){muted=false;issued=false;}
  if(musicStopped||musicSuspended||jackalAudioContext!==audio||audio?.state!=='running'||document.hidden||mode==='paused')return;
  const transport=presentationAudio(owner),cue=transport.view().cues.find(q=>q.key==='jackal:'+mood);
  // The captured engine already loops its source tune. A long room can replay
  // the finite capture after natural end; this transport owns pause/offset.
  // Scene transactions may cancel a suspended mainline transport while this
  // actor survives. The transport, not a stale local request flag, owns liveness.
  if(issued&&!cue)issued=false;
  if(cue?.state==='ended'&&mood!=='victory'){transport.cancel();issued=false;}
  if(!issued)issued=transport.play('jackal:'+mood)!==null;
 }
 function begin(options={}){if(mainlineOwner){disposePresentationScene(mainlineOwner);mainlineOwner=null;}disposed=false;paused=false;scene=true;musicStopped=musicSuspended=false;owner=scenePresentationOwner('native:jackal');cancelPresentationAudio(owner);mood=options.victory?'victory':options.boss?'boss':'level1';issued=false;muted=!soundOn;tick();}
 function ensureMainline(){if(scene||!currentWorld?.mainline||currentBody?.dying)return false;
  if(!mainlineOwner){mainlineOwner=registerPresentationScene('mainline:jackal:'+(++jackalMainlineAudioGeneration));owner=mainlineOwner;issued=false;musicStopped=false;}
  mood='mainline';stopMusic(false);return true;
 }
 function stopOwnedEffects(preserveDeath=false){
  if(preserveDeath){for(const voice of [...voices])if(voice.owner===owner&&voice.key!=='jackal_death')stopVoice(voice);}
  else withAudioOwner(owner,()=>stopEffects());
 }
 function cancel(options={}){if(scene||mainlineOwner)cancelPresentationAudio(owner);stopOwnedEffects(!!options.preserveDeath);issued=false;scene=false;}
 return {play,begin,tick,stopMood(){cancelPresentationAudio(owner);musicStopped=true;issued=true;},victory(){if(!scene)return;musicStopped=false;cancelPresentationAudio(owner);mood='victory';issued=false;muted=!soundOn;tick();},
  updateWorld(world,body){currentWorld=world;currentBody=body;},
  pause(){paused=true;if(scene||mainlineOwner)pausePresentationAudio(owner);stopOwnedEffects();},resume(){paused=false;musicSuspended=false;
   if(!soundOn){tick();return;}if(scene||ensureMainline())resumePresentationAudio(owner);tick();},
  suspend(reason){
   // Star music takes only the music lane. The game and dual weapons remain
   // live, so repeated host audioSync calls must neither reject nor stop SFX.
   if(reason==='star'){paused=false;musicSuspended=true;if(scene||mainlineOwner)cancelPresentationAudio(owner);issued=false;return;}
   if(reason==='dying'||reason==='flag'||reason==='muted'){if(scene||mainlineOwner)cancelPresentationAudio(owner);issued=false;muted=reason==='muted';paused=reason!=='muted';stopOwnedEffects(reason==='dying');}
   else{paused=true;if(scene||mainlineOwner)pausePresentationAudio(owner);stopOwnedEffects();}
  },
  cancel,dispose(){cancel();if(mainlineOwner){disposePresentationScene(mainlineOwner);mainlineOwner=null;}disposed=true;}};
}
function createJackalInstalledActor(){return E04Modules.createJackalActor({render:jackalRender,audio:createJackalAudioPort()});}
const jackalMedusaSource=@@E04:file:src/data/jackal-medusa.template.json@@;
const jackalMedusaImages={};
for(const [name,row]of Object.entries(jackalMedusaSource.images)){
 const image=new Image();jackalMedusaImages[name]=image;mainlineAssetJobs.push(gameImage(image,row.data,'jackal-hidden'));
}
const jackalMedusaRender=E04Modules.createJackalMedusaRenderer({base:jackalRender,source:jackalMedusaSource,images:jackalMedusaImages,originalSource:jackalOriginal,originalImages:jackalImages,context:()=>ctx,viewport:()=>({width:W,height:H}),createSurface:()=>document.createElement('canvas')});
function createJackalInstalledChallenge(){return E04Modules.createJackalMedusa({source:jackalMedusaSource,render:jackalMedusaRender,audio:createJackalAudioPort(),viewport:()=>W,debug:new URLSearchParams(location.search).has('test')});}

function createJackalInstalledFoes(){return E04Modules.createJackalMainlineFoes({render:jackalRender,audio:createJackalAudioPort()});}
