/* Original Sonic Worlds Next monitor/electric-shield frames, pinned d9939027.
 * See docs/RF07_ASSET_SOURCES.json. No recoloring or generated substitute art. */
const rf07SonicArt={icons:new Image(),monitor:new Image(),shield:new Image(),plain:new Image()};
gameImage(rf07SonicArt.icons,'@@E04:uri:a261@@','sonic');
gameImage(rf07SonicArt.monitor,'@@E04:uri:a262@@','sonic');
gameImage(rf07SonicArt.shield,'@@E04:uri:a263@@','sonic');
gameImage(rf07SonicArt.plain,'@@E04:uri:a311@@','sonic');
mainlineAssetJobs.push(Promise.all(Object.values(rf07SonicArt).map(im=>gameImageReady(im))));
S33_ASSETS.sfx.electricShield='@@E04:uri:a264@@';
S33_ASSETS.sfx.plainShield='@@E04:uri:a312@@';
function rf07DrawSonicSupply(g,item){
 const icon=item.nativeType==='plain-shield'?5:item.nativeType==='speed-shoes'?3:item.nativeType==='lightning-shield'?6:null;
 if(icon===null||!rf07SonicArt.icons.complete||!rf07SonicArt.monitor.complete)return false;
 const size=24,x=Math.round(item.x+((item.w||24)-size)/2),y=Math.round(item.y+(item.h||24)-size);
 g.save();g.imageSmoothingEnabled=false;
 g.drawImage(rf07SonicArt.monitor,0,0,32,32,x,y,size,size);
 g.drawImage(rf07SonicArt.icons,icon*16,0,16,16,x+6,y+5,12,12);
 g.restore();return {drawn:true,asset:'SonicWorldsNext/MonitorIcons',kind:item.nativeType};
}
const rf07ElectricFrames=[3,4,5,6,7,7,6,5,4,3,0,1,2,3,4,5,6,7,7,6,5,4,3,0,1,2];
function rf07DrawSonicShield(g,p,tick,{tier=2,layer='front'}={}){
 if(!rf07SonicArt.shield.complete||p.dying)return;
 const frame=Math.floor(tick/4)%rf07ElectricFrames.length,flip=frame>=5&&frame<10||frame>=13&&frame<18;
 const behind=tier===2&&frame>=13&&frame<23;if((layer==='back')!==behind)return;
 g.save();g.imageSmoothingEnabled=false;g.translate(Math.round(p.x+p.w/2),Math.round(p.y+p.h/2));
 if(tier===1){g.globalCompositeOperation='lighter';g.drawImage(rf07SonicArt.plain,Math.floor(tick/4)%4*48,0,48,48,-16,-16,32,32);}
 else{g.scale(flip?-1:1,1);g.drawImage(rf07SonicArt.shield,rf07ElectricFrames[frame]*48,0,48,48,-16,-16,32,32);}g.restore();
}
