/* The common campaign owns one stage, one clock and one presentation layer.
 * Native chapter scenes remain explicitly opt-in through ?legacy=1 for regression. */
if(!new URLSearchParams(location.search).has('legacy'))(()=>{
 const M=E04Modules,profiles=M.campaignCatalog.characters(),levelIds=M.campaignCatalog.levelIds(),testing=new URLSearchParams(location.search).has('test');
 const inputOwner=M.createInputOwner();
 const pointerActivation=M.createPointerActivationOwner();
 // Suppress only the click belonging to an already consumed pad gesture,
 // including mobile compatibility clicks retargeted after a layout change.
 window.addEventListener('click',e=>{if(pointerActivation.blocksClick(e)){e.preventDefault();e.stopImmediatePropagation();}},true);
 const inputProfile=()=>mainlineActorRegistry.input(hero==='random'?'mario':hero);
 const inputContext=()=>({actorPort,scene:activeChallenge?'native':'mainline'});
 const campaignSpan='WORLD '+levelIds[0]+' — '+levelIds.at(-1);
 const gameInfo=$('gameInfo');gameInfo.querySelector('summary').textContent='混合马里奥 · 0.8.13 · 游戏介绍与素材说明';
 $('gameInfoLink').onclick=()=>{gameInfo.open=true;};
 const countLabel=n=>['零','一','二','三','四','五','六','七','八','九','十'][n]||String(n);
 const journeyLabel='在下_小Q · 同人作品';
 let storage=null;try{storage=localStorage;}catch{}
 const campaign=M.createCampaign({storage});const loadedRun=campaign.load();
 const achievements=M.createAchievements({storage,heroIds:profiles.map(p=>p.id)});
 const menuLifeCode=M.createMenuLifeCode();
 let screen='menu',selected='mario',stageDriver=null,actorPort=null,enemyPort=null,world=null,view=null,entryCarry=null,introTicks=0,overrideInput=null,padHeld=[],axisHeld=[0,0],lastLives=3,renderInfo=null,lastSaveFailure='',ready=false;
 const actions=new Map(),keyPresses=new Set();let pointer={x:0,y:0,down:false,bash:false,active:false,space:'world'},pointerClient=null,menuGridIndex=0,classicStarMusic=false,lastPadId=null,pointerAttack=false,pointerBash=false,inputDevice='keyboard';
 const nativeAudioSync=audioSync,nativeChallenges=createRf02ChallengePorts({fixed:mixNative.fixed,draw:()=>hero==='tank'?tankRoute.render():e04NativeDraw(),audio:nativeAudioSync,terra:mainlineTerraChallenge,independent:mainlineActorRegistry.challenges()});
 M.validateChallengeInstallation({heroIds:profiles.map(p=>p.id),actors:mainlineActorRegistry,ports:nativeChallenges});
 let activeChallenge=null,activeSecret=null,pendingChallenge=null,pendingLifeIntro=false,pendingDeath=false,pendingEquipmentSave=false,deathAudioHandoff=null;
 const challengeFrame=document.createElement('canvas'),challengeDefeatFrame=document.createElement('canvas');let challengeDefeated=false,sceneMutationDepth=0;
 const selectionDecodes=new Map();
 const selectionPreview=M.createCharacterPreview({
  enabled:()=>screen==='menu'&&soundOn&&!document.hidden,
  prepare:async(cue)=>{
   const ac=audioInit();if(!ac)return;await ac.resume();
   if(bank.has(cue.key))return;
   if(['credits_sonic','credits_ori','selection_terra_boss'].includes(cue.key)){
    if(!selectionDecodes.has(cue.key))selectionDecodes.set(cue.key,(async()=>{
     let source=cue.key==='credits_sonic'?S33_ASSETS.music.ambient:cue.key==='credits_ori'?await m41Ready.then(()=>m37.bytes):'@@E04:uri:a9511@@';
     const bytes=typeof source==='string'?decode64(source.slice(source.indexOf(',')+1)):source;
     const buffer=await ac.decodeAudioData(bytes.slice(0));bank.set(cue.key,{buffer,gain:1,role:cue.music?'music':'ui',owner:'selection'});
    })().catch(error=>{selectionDecodes.delete(cue.key);throw error;}));
    await selectionDecodes.get(cue.key);
   }else await prepareAudio();
  },
  start:cue=>startEffectVoice(cue.key,{music:cue.music,ui:!cue.music,owner:'selection',offset:cue.offset??0,duration:8}),
  stop:stopVoice,
 });
 const setText=(id,text)=>{const node=$(id);if(node&&node.textContent!==text)node.textContent=text;};
 const profile=id=>profiles.find(p=>p.id===id)||profiles[0];
 try{const saved=storage?.getItem('mariomix.hero');if(saved==='random'||profiles.some(p=>p.id===saved))selected=saved;}catch{}
 mixSession.leave();resetGameAudio();c23Menu=false;
 const nativeSelectSync=e04Sync;e04Sync=function(){if(screen==='menu')nativeSelectSync();};
 e04Choose=function(id,focus=true){choose(id);if(focus)e04Picker.querySelector('[data-hero="'+id+'"]')?.focus({preventScroll:true});};
 for(const r of e04Roster)r.stage=11;
 document.body.classList.remove('e04-select','e04-paused');document.body.classList.add('mainline');
 document.title='混合马里奥 · 经典冒险';
 document.querySelector('.brand h1').textContent='混合马里奥';document.querySelector('.brand small').textContent='MARIO MIX · CLASSIC ADVENTURE';
 document.querySelector('.offline').textContent=journeyLabel;
 document.querySelector('.screen-top').innerHTML='<span id="mlScreenTitle">选择你的冒险伙伴</span><span>CLASSIC ADVENTURE</span>';
 document.querySelector('.footer').firstElementChild.textContent='非官方同人作品 · '+campaignSpan;
 const sourceNotes=[...document.querySelectorAll('.source-note')];
 if(sourceNotes.length){const credits=sourceNotes[0];credits.querySelector('summary').textContent='素材与制作';for(const note of sourceNotes.slice(1)){for(const p of [...note.querySelectorAll('p')])credits.append(p);note.remove();}const outdated=credits.querySelector('p');if(outdated?.textContent.startsWith('R43 '))outdated.textContent='奥日配乐：Gareth Coker — Restoring the Light, Facing the Dark。录音由用户提供，音乐权利归原权利人。';for(const p of credits.querySelectorAll('p'))if(p.textContent.startsWith('以 FullScreenMario 1-2'))p.textContent='采用超级马里奥 '+levelIds[0]+' 至 '+levelIds.at(-1)+' 地图，各位角色保留自己的动作、武器与声音。地图制作与接入使用地图工坊。';}
 // The old per-character chapter tabs do not belong to the shared campaign.
 c23Tabs.remove();
 const info=document.createElement('section');info.id='mlInfo';info.innerHTML='<div class="ml-eyebrow">ONE WORLD · EIGHT HEROES</div><h2 id="mlHeading">选择伙伴<br>出发冒险</h2><p id="mlHelp"></p><div class="ml-keys">移动　← → / A D<br>跳跃　空格 / K / Z<br>加速、攻击　Shift / J / X<br>特殊能力　E / L<br>蹲下、入管　↓ / S<br>暂停　P / Esc</div><p id="mlPad" class="ml-save">手柄：A 跳跃 · B 攻击 · X 能力 · START 暂停</p><p id="mlSave" class="ml-save">进度自动保存。</p>';
 document.querySelector('.panel').prepend(info);
 info.querySelector('.ml-eyebrow').textContent=levelIds.length+' STAGES · '+(profiles.length===8?'EIGHT':profiles.length)+' HEROES';
 $('restartButton').textContent='重试本关 R';$('charactersButton').textContent='返回主菜单';
 document.querySelector('[data-action="special"]').textContent='能力';document.querySelector('[data-action="special"]').setAttribute('aria-label','特殊能力');
 const layer=document.createElement('div');layer.id='mlLayer';layer.innerHTML='<div class="ml-panel ml-modal" id="mlModal" hidden><div class="ml-eyebrow" id="mlModalLabel"></div><h2 id="mlModalTitle"></h2><p id="mlModalText"></p><div class="ml-actions"><button id="mlPrimary"></button><button class="ml-secondary" id="mlSecondary">返回主菜单</button></div></div>';
 // Random is a normal paginated roster entry, with the same confirmation path.
 let levelReturn='menu';const levelNavigation=M.createLevelNavigation(levelIds.length);
 const levelButton=document.createElement('button');levelButton.id='mlLevelSelect';levelButton.type='button';levelButton.setAttribute('aria-label','选择关卡');levelButton.onclick=()=>openLevelSelect();$('overlay').querySelector('.overlay-box').append(levelButton);
 const levelPanel=document.createElement('div');levelPanel.id='mlLevelPanel';levelPanel.className='ml-panel';levelPanel.hidden=true;
 for(const [i,id] of levelIds.entries()){const b=document.createElement('button');b.type='button';b.textContent='WORLD '+id;b.dataset.level=id;b.onclick=()=>{levelNavigation.select(i);confirmLevel();};b.onfocus=()=>{levelNavigation.select(i);draw();};levelPanel.append(b);}
 const levelBack=document.createElement('button');levelBack.type='button';levelBack.textContent='返回';levelBack.onclick=cancelLevel;levelBack.onfocus=()=>{levelNavigation.select(levelIds.length);draw();};levelPanel.append(levelBack);
 const levelPrevious=document.createElement('button'),levelNext=document.createElement('button');
 for(const [b,delta,label,left]of [[levelPrevious,-1,'上一页',52],[levelNext,1,'下一页',176]]){b.type='button';b.textContent=label;b.setAttribute('aria-label',label);b.style.top='198px';b.style.height='14px';b.style.left=left+'px';b.style.width='28px';b.onclick=()=>turnLevelPage(delta);levelPanel.append(b);}
 layer.append(levelPanel);
 const continueButton=document.createElement('button');continueButton.id='mlResume';continueButton.type='button';continueButton.setAttribute('aria-label','继续已保存的冒险');continueButton.onclick=()=>continueRun();$('overlay').querySelector('.overlay-box').append(continueButton);
 $('stage').append(layer);
 const ending=M.createCampaignEnding(layer,{profiles,onAchievements:()=>achievementButton.click(),onCredits:()=>{screen='credits';flush();ending.showCredits();syncUi();audioSync();},onMenu:mainMenu,onReplay:()=>newRun(),canBonus:()=>!!campaign.bonusAvailable(),onBonus:()=>{campaign.continueAfterCredits();openStage();}});
 let achievementReturn=null,achievementOrigin=null;
 const achievementUi=M.createAchievementUi($('stage'),{store:achievements,onClose:()=>{flush();if(achievementReturn==='playing'&&screen==='paused')pause();else if(achievementReturn==='result'&&ending.active())ending.focusAchievements();else (achievementOrigin||achievementButton).focus({preventScroll:true});achievementReturn=null;achievementOrigin=null;}});
 const achievementTotal=achievements.list().length;let achievementCount=achievements.count();
 const achievementButton=document.createElement('button');achievementButton.id='mlAchievementButton';achievementButton.type='button';achievementButton.textContent='★ 成就  '+achievementCount+' / '+achievementTotal;
 achievementButton.onclick=()=>{achievementReturn=screen;if(screen==='playing')pause();flush();achievementUi.show();};info.prepend(achievementButton);
 const achievementStageButton=document.createElement('button');achievementStageButton.id='mlAchievementStageButton';achievementStageButton.type='button';achievementStageButton.textContent='★ 成就';achievementStageButton.setAttribute('aria-label','查看成就');achievementStageButton.onclick=()=>{achievementOrigin=achievementStageButton;achievementButton.click();};const hudExtras=document.createElement('div');hudExtras.id='mlHudExtras';
 const authorLabel=document.createElement('span');authorLabel.id='mlAuthorLabel';authorLabel.textContent='@在下_小Q';
 hudExtras.append(authorLabel,achievementStageButton);$('stage').append(hudExtras);
 // Reposition after every viewport fit, including fullscreen letterboxing and
 // touch-controller insets. A screen-corner percentage is not a HUD anchor.
 const nativeHudActive=()=>screen!=='intro'&&!!(activeChallenge||challengeDefeated);
 e04ViewportFitted=rect=>{
  const a=M.achievementHudAnchor(rect,e04Viewport.view().width,{menu:screen==='menu'||screen==='levels',nativeScene:nativeHudActive()});
  const height=Math.max(a.height,a.authorFontSize);
  Object.assign(hudExtras.style,{left:a.right+'px',top:a.top+'px',height:height+'px',gap:a.authorGap+'px'});
  hudExtras.style.setProperty('--hud-pixel',a.pixel+'px');
  Object.assign(achievementStageButton.style,{height:a.height+'px',fontSize:a.authorFontSize+'px'});
  authorLabel.style.fontSize=a.authorFontSize+'px';
 };
 const lifeCodeNotice=document.createElement('p');lifeCodeNotice.id='mlLifeCode';lifeCodeNotice.hidden=true;lifeCodeNotice.setAttribute('role','status');lifeCodeNotice.textContent='秘籍生效 · NEW GAME × 30';info.append(lifeCodeNotice);
 function menuCodeCommand(token){
  if(screen!=='menu'||achievementUi.active()||ending.active())return false;
  const result=menuLifeCode.push(token);
  if(result.unlocked){
   achievements.observe('menu-life-code',{screen:'character-select',lives:30,accepted:true});
   syncUi();
   // The sequence navigates menu actions too. Its reward belongs to NEW GAME,
   // so confirm must not inherit a CONTINUE/level-select focus from those keys.
   $('mainAction').focus({preventScroll:true});draw();
  }
  return result.consumed;
 }
 const hostActions=new Map([[achievementButton,()=>achievementButton.click()],[achievementStageButton,()=>achievementStageButton.click()],[levelButton,openLevelSelect],[continueButton,continueRun]]);
 function confirmHostAction(){const action=hostActions.get(document.activeElement);if(!action)return false;action();return true;}
 const pauseTouch=document.createElement('button');pauseTouch.id='mlPauseTouch';pauseTouch.textContent='Ⅱ';pauseTouch.setAttribute('aria-label','暂停游戏');$('stage').append(pauseTouch);
 const fullTouchButton=document.createElement('button');fullTouchButton.id='mlFullTouch';fullTouchButton.textContent='⛶';fullTouchButton.setAttribute('aria-label','切换全屏');fullTouchButton.onclick=()=>$('fullButton').click();$('stage').append(fullTouchButton);
 const fullTouch=document.createElement('div');fullTouch.className='ml-gamepad';fullTouch.setAttribute('aria-label','虚拟手柄');fullTouch.innerHTML='<div class="ml-pad-extras" hidden></div><div class="ml-dpad"><button data-ml-action="up" aria-label="向上">▲</button><button data-ml-action="left" aria-label="左移">◀</button><button data-ml-action="right" aria-label="右移">▶</button><button data-ml-action="down" aria-label="下蹲进入管道">▼</button></div><div class="ml-pad-middle"><span>MARIO MIX</span><button data-ml-action="cycle" aria-label="切换">SELECT</button><button id="mlPadPause" aria-label="暂停游戏">START</button></div><div class="ml-pad-actions"><button data-ml-action="ability" aria-label="特殊能力"><strong>X</strong><small>能力</small></button><button data-ml-action="extra" aria-label="特殊动作"><strong>Y</strong><small>动作</small></button><button data-ml-action="attack" aria-label="加速攻击"><strong>B</strong><small>攻击</small></button><button data-ml-action="jump" aria-label="跳跃"><strong>A</strong><small>跳跃</small></button></div>';
 const oldTouch=document.querySelector('.touchbar');oldTouch.after(fullTouch);$('mlPadPause').onclick=()=>screen==='menu'?confirmMenu():pause();
 const touchDevice=matchMedia('(pointer:coarse)');
 // Fullscreen controls and the game surface occupy disjoint presentation areas.
 // Simulation coordinates and every native scene still use the same viewport.
 e04ViewportInsets=()=>{
  const stage=$('stage');if(document.fullscreenElement!==stage)return {};
  const top=nativeHudActive()?M.nativeHudInset({width:stage.clientWidth,height:stage.clientHeight},e04Viewport.view().width):0;
  if(!touchDevice.matches||fullTouch.hidden)return {top};
  const sr=stage.getBoundingClientRect();
  if(sr.height>=sr.width){const pad=fullTouch.getBoundingClientRect();return {top,bottom:Math.max(0,sr.bottom-pad.top+12)};}
  const bounds=selector=>[...fullTouch.querySelectorAll(selector)].map(n=>n.getBoundingClientRect()).filter(r=>r.width>0&&r.height>0);
  const left=bounds('.ml-dpad,.ml-pad-middle'),right=bounds('.ml-pad-actions,.ml-pad-extras');
  return {top,left:Math.max(0,...left.map(r=>r.right-sr.left+12)),right:Math.max(0,...right.map(r=>sr.right-r.left+12))};
 };
 const syncTouchDevice=()=>{document.body.classList.toggle('ml-touch-device',touchDevice.matches);flush();};
 touchDevice.addEventListener('change',syncTouchDevice);syncTouchDevice();
 document.addEventListener('fullscreenchange',()=>{flush();if(document.fullscreenElement===$('stage'))$('stage').append(fullTouch);else oldTouch.after(fullTouch);});
 fullTouch.addEventListener('lostpointercapture',e=>{const action=actions.get(e.pointerId);if(!action)return;actions.delete(e.pointerId);for(const button of fullTouch.querySelectorAll('[data-ml-action]'))if(button.dataset.mlAction===action){const held=[...actions.values()].includes(action);button.classList.toggle('pressed',held);button.setAttribute('aria-pressed',String(held));}});
 const roster=[...profiles.map(p=>({id:p.id,title:p.title})),{id:'random',title:'随机'}];
 function flush(){keys.clear();keyPresses.clear();touch.clear();actions.clear();overrideInput=null;inputOwner.clear();menuLifeCode.resetSequence();pointer.down=pointer.bash=pointerAttack=pointerBash=false;for(const b of document.querySelectorAll('.touchkey.pressed,.ml-gamepad .pressed')){b.classList.remove('pressed');b.setAttribute('aria-pressed','false');}}
 function persistStageEquipment(){
   // A normal reload reconstructs checkpoint collectibles. Commit the live
   // loadout without also crediting those replayable coins, scores or lives.
   if(!stageDriver||activeChallenge||entryCarry?.challenge||!['playing','paused','intro'].includes(screen)||campaign.view().status!=='playing')return;
   const live=stageDriver.view();if(live.fault||!live.p||live.p.dying||live.completed)return;
   const {hero,power,weapon,protection,native}=carry(live);
   entryCarry={...entryCarry,hero,power,weapon,protection,native:native??null};
   campaign.retry(entryCarry);
 }
 function saveRun(){persistStageEquipment();const result=campaign.save();lastSaveFailure=result.ok?'':result.error;setText('mlSave',result.ok?'已保存':'进度未保存');$('mlSave').dataset.error=String(!result.ok);return result;}
 function choose(id){if(screen!=='menu'||!roster.some(r=>r.id===id))return;selected=id;hero=id;try{storage?.setItem('mariomix.hero',id);}catch{}syncUi();draw();if(navigator.userActivation?.hasBeenActive)selectionPreview.select(id).catch(error=>console.warn('Character preview audio',error));}
 function syncNativeHud(){const hitLayer=$('t15HudHits');if(hitLayer)hitLayer.hidden=!(activeChallenge?.hero==='sandboxTrio'&&screen==='playing');}
 function syncUi(){
   if(screen!=='menu')selectionPreview.cancel();
   hudExtras.hidden=achievementStageButton.hidden=screen==='menu'||screen==='levels'||ending.active();
   const current=campaign.view(),id=screen==='menu'?selected:current.characterId,p=profile(id),random=id==='random'||screen!=='menu'&&current.mode==='random';
   if(screen!=='menu')menuLifeCode.resetSequence();
   lifeCodeNotice.hidden=screen!=='menu'||!menuLifeCode.armed();
   if(screen==='menu'){nativeSelectSync();for(const b of e04Picker.querySelectorAll('[data-hero]'))b.setAttribute('aria-pressed',String(b.dataset.hero===selected));}
   // Native HUD hit targets follow the selected actor, not the retired
   // single-chapter selector which may still describe another hero.
   document.body.classList.toggle('c23-not-terra',id!=='sandboxTrio');
   syncNativeHud();
   $('o30Continue').hidden=true;
   setText('mlHeading',screen==='menu'?(selected==='random'?'随机冒险':p.title):p.title+' · '+displayLevel());
   setText('mlHelp',selected==='random'?'每关换一位伙伴。':p.help);
   const controls=mainlineActorRegistry.input(!id||id==='random'?'mario':id);
   info.querySelector('.ml-keys').innerHTML=(controls.showJumpHelp===false?'':'移动　方向键 / WASD<br>跳跃　空格 / K / Z<br>')+(controls.help||'加速 / 攻击　Shift / J / X')+'<br>暂停　P / Esc';
   const touchLabels=M.touchPresentation(controls),abilityLabel=touchLabels.ability.label;
   for(const button of document.querySelectorAll('[data-action="special"],[data-ml-action="ability"]')){const label=button.querySelector('small');if(label)label.textContent=abilityLabel;else button.textContent=abilityLabel;button.setAttribute('aria-label',abilityLabel);}
   for(const [slot,presentation]of Object.entries(touchLabels)){
     const button=fullTouch.querySelector('[data-ml-action="'+slot+'"]');
     const menuAction=screen==='menu'&&['jump','attack'].includes(slot);
     button.querySelector('small').textContent=menuAction?(slot==='jump'?'确认':'B'):presentation.label;button.setAttribute('aria-label',menuAction?(slot==='jump'?'A 确认':'B'):presentation.label);button.disabled=menuAction?false:!presentation.enabled;
   }
   const extraControls=fullTouch.querySelector('.ml-pad-extras'),extras=M.touchExtraPresentation(controls),extraKey=JSON.stringify(extras);
   if(extraControls.dataset.controls!==extraKey){
     extraControls.innerHTML='';extraControls.dataset.controls=extraKey;
     for(const {slot,label}of extras){const button=document.createElement('button');button.type='button';button.dataset.mlAction=slot;button.textContent=label;button.setAttribute('aria-label',label);extraControls.append(button);}
   }
   extraControls.hidden=!extras.length;fullTouch.classList.toggle('ml-has-extras',!!extras.length);
   $('mlHelp').hidden=screen!=='menu';info.querySelector('.ml-keys').hidden=!['menu','paused'].includes(screen);
   $('mlPad').hidden=screen!=='paused';$('mlSave').hidden=screen!=='menu'&&!lastSaveFailure;
   setText('mlScreenTitle',screen==='menu'?'选择伙伴':p.title+' · WORLD '+displayLevel()+(random?' · 随机':''));
   continueButton.hidden=!(['playing','between','gameover'].includes(current.status)||campaign.bonusAvailable());document.body.classList.toggle('ml-has-save',!continueButton.hidden);
   levelButton.hidden=screen!=='menu';levelPanel.hidden=screen!=='levels';
   document.body.classList.toggle('e04-select',screen==='menu');document.body.classList.toggle('e04-paused',screen==='paused');layer.hidden=['menu','paused','intro'].includes(screen);$('mlModal').hidden=['menu','playing','paused','intro','levels','credits'].includes(screen)||screen==='result'&&current.status==='complete';
   if(screen==='paused'){$('heroPicker').hidden=true;$('overlayCharacters').hidden=false;$('mainAction').setAttribute('aria-label','继续游戏');$('overlayCharacters').setAttribute('aria-label','返回角色选择');}
   document.querySelector('.screen-top').lastElementChild.textContent=screen==='menu'?campaignSpan:'WORLD '+displayLevel();
   if(screen!=='paused')$('mainAction').setAttribute('aria-label',selected==='random'?'开始随机冒险':'开始'+p.title+'的冒险');
   layer.style.pointerEvents=['playing'].includes(screen)?'none':'auto';
   pauseTouch.hidden=screen==='menu';fullTouch.hidden=!['menu','intro','playing','paused'].includes(screen);$('pauseButton').disabled=['menu','result','gameover','intro'].includes(screen);$('restartButton').disabled=screen==='menu';
   $('pauseButton').textContent=screen==='paused'?'继续 P':'暂停 P';$('soundButton').textContent=soundOn?'声音：开':'声音：关';
   if(screen==='retry')modal('WORLD '+displayLevel(),'重新挑战本关？','从关卡起点出发，消耗 1 条生命。\n本关收集将重新计算。','重新挑战');
   if(screen==='result'&&current.status!=='complete')modal(current.status==='complete'?'WORLD ONE COMPLETE':'WORLD '+displayLevel()+' CLEAR',current.status==='complete'?'通关！':'过关','得分 '+current.carry.score+' · 生命 '+current.carry.lives,current.status==='complete'?'再次冒险':'下一关');
   if(screen==='gameover')modal('GAME OVER','冒险结束','WORLD '+displayLevel()+' · 得分 '+current.carry.score,'继续本关');
   if(screen==='error')modal('PLEASE RETRY','这一段暂时走不通','场景已停止。返回主菜单可重新开始。','返回主菜单',false);
 }
 function modal(label,title,body,button,secondary=true){setText('mlModalLabel',label);setText('mlModalTitle',title);setText('mlModalText',body);$('mlModalText').style.whiteSpace='pre-line';setText('mlPrimary',button);$('mlSecondary').hidden=!secondary;if(![$('mlPrimary'),$('mlSecondary')].includes(document.activeElement))$('mlPrimary').focus({preventScroll:true});}
 function displayLevel(){return view?.displayLevel||campaign.view().levelId;}
 function carry(v){return {lives:v.lives,coins:v.coins,score:v.score,hero:v.p.hero,power:v.p.power||0,protection:v.p.protection||0,weapon:v.p.weapon||null,respawnNative:null,...(v.native?{native:JSON.parse(JSON.stringify(v.native))}:{})};}
 function deathCarry(v){const native=v.respawnNative??null;return {...carry(v),power:0,protection:0,weapon:null,native,respawnNative:native,checkpoint:v.checkpoint?{levelId:world.plan.stage.id,...v.checkpoint}:entryCarry?.checkpoint||null};}
 function checkpointLives(){
   const died=pendingDeath;pendingDeath=false;
   const reached=JSON.stringify(view.checkpoint),saved=entryCarry.checkpoint;
   if(!view.p.dying&&world.plan.stage.checkpoints.some(c=>c.roomId===view.checkpoint.roomId&&c.spawnId===view.checkpoint.spawnId)&&reached!==JSON.stringify(saved&&{roomId:saved.roomId,spawnId:saved.spawnId})){
     entryCarry={...carry(view),checkpoint:{levelId:world.plan.stage.id,...view.checkpoint}};campaign.retry(entryCarry);saveRun();
   }
   if(view.lives===lastLives&&!died)return;
   // A 1UP and fatal contact can occur in one update; net lives alone lose that death.
   const lost=died||view.lives<lastLives;lastLives=view.lives;
   if(lost)entryCarry=entryCarry.challenge?{...entryCarry,protection:0,challenge:{...entryCarry.challenge,phase:'retry'}}:{...(stageDriver.nativeStage?stageDriver.checkpointCarry():{...entryCarry,native:view.respawnNative??null,respawnNative:view.respawnNative??null,...(view.respawnNative?{score:view.score}:{})}),power:0,protection:0,weapon:null};
   // A saved retry restarts the room's collectibles, so earned lives are only
   // committed with the stage clear. Never save their value without their cost.
   entryCarry.lives=Math.min(entryCarry.lives,view.lives);
   campaign.retry(view.lives===0&&!entryCarry.challenge?deathCarry(view):entryCarry);saveRun();
 }
 function sound(event){
   if(event==='death'&&deathAudioHandoff&&!deathAudioHandoff.stopped&&voices.has(deathAudioHandoff))return;
   if(['death','gameover'].includes(event))cancelPresentationAudio();
   if(['death','flag','complete','world_clear','gameover'].includes(event))stopMusic(false);
   if(['flag','complete','world_clear'].includes(event)){playPresentationAudio(event==='complete'?'clear':event);return;}
   if(event==='classic-enemy-defeat'){originalOneShot('kick');return;}
   if(event==='pickup'&&hero==='sonic'&&actorPort?.sound?.(event))return;
   // Source-world events keep their sound owner even when a hero supplies
   // its own combat audio. A hero adapter cannot consume Bowser's cues.
    const classic={pickup:'coin',life:'oneup',portal:'pipe',appear:'appear',bump:'bump',break:'break',stomp:'stomp',kick:'kick','classic-star':'powerup','mainline-powerdown':'hurt',bowser_fire:'bowser_fire',bowser_fall:'bowser_fall'}[event];
   if(classic){if(event==='classic-star'&&actorPort){actorPort.audio(false,'star');classicStarMusic=true;}originalOneShot(classic);return;}
   if(actorPort?.sound?.(event))return;
   const key=({jump:'jump_small',jump_super:'jump_super',complete:'clear',death:'death',flag:'flag',attack:hero==='megaman'?'mega_shot_nes':'fire',bill_N:'bill_normal',bill_M:'bill_machine',bill_S:'bill_spread',bill_F:'bill_flame',bill_L:'bill_laser'})[event]||event;
   oneShot(bank.has(key)?key:event==='attack'?'fire':key);
 }
 function closeChallenge(){pendingChallenge=null;activeSecret=null;challengeDefeated=false;if(activeChallenge){nativeChallenges.leave('cancel');activeChallenge=null;}e04Viewport.prepare(canvas,ctx);}
 function saveChallengeState(detail,phase='playing'){
   const secret=activeSecret||world?.plan.stage.secret;if(!secret||!detail)return;
   const route=Object.fromEntries(['sourceRoom','portalId','targetRoom','targetSpawn','returnRoom','returnSpawn'].filter(key=>typeof secret[key]==='string').map(key=>[key,secret[key]]));
   const current=carry(view),equipment=detail.nativeCarry||current.native;
   // A failed result has already been committed by applyChallengeResult,
   // including its one life debit. Playing scenes still use the entry baseline.
   if(phase!=='retry')Object.assign(current,M.projectChallengeCounters(current,detail.carryDelta));
   const scene=phase==='retry'?(detail.retryScene??(activeChallenge?entryCarry.challenge?.scene:null)??null):nativeChallenges.checkpoint();
   entryCarry={...current,checkpoint:entryCarry.checkpoint||null,challenge:{id:secret.id,driver:secret.driver,phase,rewardReceipt:detail.rewardReceipt,scene,...(Object.keys(route).length===6?{route}:{})},
     native:equipment||null,weapon:equipment?.weapon??current.weapon,protection:phase==='retry'?0:(detail.protection??current.protection)};
   campaign.retry(entryCarry);saveRun();
 }
 function persistChallenge(){
   if(!activeChallenge)return;
   const detail=nativeChallenges.view();
   // Only explicit menu/unload calls reach here. Settle an interrupted death
   // once and save its retry, while normal fixed steps finish the native scene.
   if(detail.failed||detail.defeating)leaveChallenge('failed');
   else if(detail.exited||detail.exitCommitted)leaveChallenge(detail.cleared?'complete':'skip');
   else saveChallengeState(detail);
 }
 function beginChallenge(){
   if(!pendingChallenge||activeChallenge)return;
   sceneMutationDepth++;try{
   const secret=pendingChallenge;
   if(!nativeChallenges.supports(secret.driver))throw new TypeError('Uninstalled native challenge: '+secret.driver);
   pendingChallenge=null;
   activeSecret=secret;
   stageDriver.pause();flush();resetGameAudio();
   activeChallenge=nativeChallenges.enter(secret.driver,{carry:carry(view),levelId:campaign.view().levelId,retry:!!secret.retry,scene:entryCarry.challenge?.scene,rewardReceipt:entryCarry.challenge?.rewardReceipt});
   saveChallengeState(activeChallenge,secret.retry?'retry':'playing');
   challengeDefeated=false;
   if(secret.retry){pendingLifeIntro=false;screen='intro';introTicks=75;nativeChallenges.pause();}
   mode='playing';syncUi();
   }finally{sceneMutationDepth--;draw();}
 }
 function leaveChallenge(reason='skip'){
   if(!activeChallenge)return;
   if(reason==='failed'){draw();if(challengeDefeatFrame.width!==canvas.width)challengeDefeatFrame.width=canvas.width;if(challengeDefeatFrame.height!==canvas.height)challengeDefeatFrame.height=canvas.height;challengeDefeatFrame.getContext('2d').drawImage(canvas,0,0);challengeDefeated=true;}
   sceneMutationDepth++;try{
   const tail=reason==='failed'?currentPlayerDeathVoice(hero):null;
   if(tail)tail.owner='actor:'+hero;
   const result=withEffectHandoff(tail,()=>nativeChallenges.leave(reason));if(result.completed)campaign.recordStatistic('challenges');activeChallenge=null;flush();
   deathAudioHandoff=tail;try{stageDriver.applyChallengeResult(result);}finally{deathAudioHandoff=null;}
   stageDriver.resume();view=stageDriver.view();
   if(reason==='failed')saveChallengeState(result,'retry');
   else{
     const secret=activeSecret||world.plan.stage.secret;
     entryCarry={...carry(view),challenge:null,checkpoint:secret?{levelId:world.plan.stage.id,roomId:secret.returnRoom,spawnId:secret.returnSpawn}:entryCarry.checkpoint||null};
     activeSecret=null;
     campaign.retry(entryCarry);saveRun();
   }
   checkpointLives();
   screen='playing';mode='playing';e04Viewport.prepare(canvas,ctx);syncUi();
   }finally{sceneMutationDepth--;draw();}
 }
 function openStage(){sceneMutationDepth++;try{
   cancelPresentationAudio();ending.hide();closeChallenge();flush();stageDriver?.dispose();resetGameAudio();pendingLifeIntro=false;pendingDeath=false;pendingEquipmentSave=false;classicStarMusic=false;
   const run=campaign.state();hero=run.characterId;entryCarry={...run.carry};lastLives=run.carry.lives;
   c23Menu=false;c23Campaign.stage=mainlineActorRegistry.definition(hero).legacyChapter||11;document.body.classList.remove('e04-select');world=M.createCampaignWorld(run.levelId,run.characterId);
   const authoredScene=mainlineActorRegistry.scene(run.characterId,run.levelId);
   actorPort=authoredScene?null:mainlineActorRegistry.create(run.characterId,{character:world.plan.character});
   enemyPort=mainlineActorRegistry.foes(run.characterId);
   let ownedStage=null;
   const onStageEvent=(type,data)=>{
     if(type==='room')achievements.observe('room-enter',{...ownedStage?.achievementFacts?.(),...data,hero,runId:run.runId,levelId:run.levelId});
     if(['objective','enemy-defeated','item-collected','coin-collected','room-loop','block-bumped','block-reward-collected','block-reward-exhausted','brick-broken','flag-grab','extra-life','death','player-downgraded','secret'].includes(type))achievements.observe(type,{...data,hero,runId:run.runId,levelId:campaign.view().levelId,...ownedStage?.achievementFacts?.()});
     if(type==='sound')sound(data.event);
     if(type==='secret'){
       if(!nativeChallenges.supports(data.driver))throw new TypeError('Uninstalled native challenge: '+data.driver);
       campaign.markSecret(data.id);pendingChallenge=data;
     }
     if(type==='respawn')pendingLifeIntro=true;
     if(type==='item-collected'||type==='player-downgraded')pendingEquipmentSave=true;
     if(type==='death'){pendingDeath=true;campaign.recordStatistic('deaths');}
   };
   stageDriver=authoredScene?authoredScene({initialState:run.carry,viewportWidth:W,debug:testing,emit:onStageEvent}):M.createCampaignStage({actorPort,enemyPort,plan:world.plan,motor:M.createCharacterMotor(),visualRooms:world.visualRooms,initialState:run.carry,secretIds:run.secretIds,allowWarp:true,allowSecretDiscovery:run.entryMode!=='stage-select',viewportWidth:W,debug:testing,emit:onStageEvent});
   ownedStage=stageDriver;
   if(authoredScene)world=stageDriver.world;
   achievements.observe('stage-start',{...stageDriver.achievementFacts?.(),hero,runId:run.runId,levelId:run.levelId,statistics:run.statistics});
   view=stageDriver.view();screen='intro';mode='playing';introTicks=75;saveRun();syncUi();draw();
   const loadingDriver=stageDriver;
   if(!authoredScene)M.preloadCampaignArt(world.visualRooms).catch(error=>{if(stageDriver===loadingDriver)fail(error);});audioInit();prepareAudio().catch(error=>console.warn('Campaign audio preparation',error));canvas.focus({preventScroll:true});
 }catch(error){fail(error);}finally{sceneMutationDepth--;draw();}}
 function newRun(levelId){campaign.newRun({mode:selected==='random'?'random':'fixed',characterId:selected==='random'?'mario':selected,entryMode:levelId?'stage-select':'story',initialLives:menuLifeCode.consume(),...(levelId?{levelId}:{})});openStage();}
 function continueRun(){const state=campaign.view();if(state.status==='complete'){screen='result';mode='win';ending.showStatistics(state);flush();syncUi();return;}if(state.status==='gameover'){campaign.continueRun();openStage();return;}if(state.status==='between'){campaign.advance();openStage();return;}if(state.status==='playing')openStage();}
 // The host owns explicit suspension of every scene and audio owner.
 // A failed-scene death tail is a scoped handoff, never a pause lease.
 function suspendAudio(remember=true){
   if(remember)pausePresentationAudio();else cancelPresentationAudio();
   withAudioOwner('campaign',()=>withEffectHandoff(null,()=>{stopEffects();stopMusic(remember);}));
   mixAudio();
 }
 function openLevelSelect(){
   levelReturn=screen;levelNavigation.select(Math.max(0,levelIds.indexOf(campaign.view().levelId)));
   if(screen==='playing'){pausePresentationAudio();stageDriver.pause();if(activeChallenge)nativeChallenges.pause();levelReturn='paused';}
   screen='levels';mode='paused';flush();suspendAudio();syncUi();focusLevel();draw();
 }
 function focusLevel(){const selection=levelNavigation.view();for(let i=0;i<levelIds.length;i++){const b=levelPanel.children[i];b.hidden=i<selection.start||i>=selection.end;b.style.top=(72+(i-selection.start)*26)+'px';}levelBack.style.top=(72+(selection.end-selection.start)*26)+'px';levelPrevious.hidden=levelNext.hidden=selection.pageCount===1;levelPanel.children[selection.index].focus({preventScroll:true});}
 function moveLevel(delta){levelNavigation.move(delta);focusLevel();draw();}
 function turnLevelPage(delta){levelNavigation.turn(delta);focusLevel();draw();}
 function cancelLevel(){screen=levelReturn;mode=screen==='menu'?'menu':screen==='gameover'?'gameover':'paused';flush();syncUi();draw();}
 function confirmLevel(){if(document.activeElement===levelPrevious)return turnLevelPage(-1);if(document.activeElement===levelNext)return turnLevelPage(1);const index=levelNavigation.view().index;if(index===levelIds.length)return cancelLevel();if(levelReturn!=='menu')selected=campaign.view().mode==='random'?'random':campaign.view().characterId;newRun(levelIds[index]);}
 function confirmMenu(){if(!confirmHostAction())primary();}
 function mainMenu(){cancelPresentationAudio();ending.hide();persistChallenge();saveRun();closeChallenge();flush();stageDriver?.dispose();stageDriver=null;actorPort=null;world=null;view=null;screen='menu';mode='menu';c23Menu=true;c23Campaign.stage=11;hero=selected;stopMusic(false);stopEffects();syncUi();draw();}
 function pause(){if(screen==='playing'){pausePresentationAudio();screen='paused';mode='paused';stageDriver.pause();if(activeChallenge)nativeChallenges.pause();saveRun();flush();suspendAudio();syncUi();$('mainAction').focus({preventScroll:true});}else if(screen==='paused'){screen='playing';mode='playing';audioInit();mixAudio();if(activeChallenge)nativeChallenges.resume();else stageDriver.resume();resumePresentationAudio();flush();syncUi();}draw();}
 function primary(){
   if(ending.active())return ending.confirm();
   if(screen==='menu')return newRun();if(screen==='paused')return pause();
   if(screen==='intro'){introTicks=0;screen='playing';mode='playing';audioInit();flush();if(activeChallenge)nativeChallenges.resume();else stageDriver.resume();syncUi();return;}
   if(screen==='result'){if(campaign.view().status==='between'){campaign.advance();openStage();}else mainMenu();return;}
   if(screen==='gameover')return continueRun();if(screen==='error')return mainMenu();
   if(screen==='retry'){campaign.recordStatistic('retries');if(activeChallenge){leaveChallenge('failed');return;}closeChallenge();const retained=stageDriver.respawnCarry?.()??null;campaign.retry({...entryCarry,lives:Math.max(0,Math.min(entryCarry.lives,view.lives)-1),power:0,protection:0,weapon:null,native:retained,respawnNative:retained,...(retained?{score:view.score}:{}),checkpoint:null});saveRun();if(campaign.view().status==='gameover'){screen='gameover';mode='gameover';syncUi();}else openStage();}
 }
 function requestRetry(){if(!['playing','paused'].includes(screen))return;cancelPresentationAudio();screen='retry';mode='paused';stageDriver.pause();if(activeChallenge)nativeChallenges.pause();flush();suspendAudio();syncUi();draw();}
 function fail(error){if(activeChallenge){try{closeChallenge();}catch{activeChallenge=null;}}screen='error';mode='paused';flush();stageDriver?.pause();suspendAudio(false);console.error('Campaign stopped:',error);syncUi();draw();}
 function padInput(){
   const pad=Array.from(navigator.getGamepads?.()||[]).find(p=>p?.connected),b=pad?Array.from(pad.buttons,x=>x.pressed||x.value>.5):[],a=pad?.axes||[],edge=i=>b[i]&&!padHeld[i];
   if(lastPadId!==null&&!pad&&screen==='playing')pause();lastPadId=pad?.id??null;
   const dx=(a[0]>.35||b[15]?1:0)-(a[0]<-.35||b[14]?1:0),dy=(a[1]>.35||b[13]?1:0)-(a[1]<-.35||b[12]?1:0);
   const rightAim=Math.hypot(a[2]||0,a[3]||0)>.25;if(dx||dy||rightAim||b.some(Boolean))inputDevice='gamepad';
   let codeConsumed=false;
   if(screen==='menu'&&!achievementUi.active()&&!ending.active()){
    const commands=[];
    if(dx&&dx!==axisHeld[0])commands.push(dx<0?'left':'right');
    if(dy&&dy!==axisHeld[1])commands.push(dy<0?'up':'down');
    if(edge(1))commands.push('b');if(edge(0))commands.push('a');
    if(commands.length)codeConsumed=menuCodeCommand(commands.length===1?commands[0]:null);
    if([2,3,4,5,9].some(edge))menuLifeCode.resetSequence();
   }
   if(achievementUi.active()){if(dx&&dx!==axisHeld[0])achievementUi.navigate(dx,0);else if(dy&&dy!==axisHeld[1])achievementUi.navigate(0,dy);if(edge(0))achievementUi.confirm();if(edge(1)||edge(9))achievementUi.close();}
   else if(codeConsumed){}
   else if((edge(0)||edge(9))&&confirmHostAction()){}
   else if(ending.active()){if(dy&&dy!==axisHeld[1])ending.move(dy);else if(dx&&dx!==axisHeld[0])ending.move(dx,true);if(edge(0)||edge(9))ending.confirm();}
   else if(screen==='menu'){if(dx&&dx!==axisHeld[0])moveSelection(dx);else if(dy&&dy!==axisHeld[1])moveSelection(dy*4);if(edge(4))$('e04PreviousPage').click();else if(edge(5))$('e04NextPage').click();else if(edge(1)&&!continueButton.hidden)continueRun();else if(edge(9)||edge(0)){confirmMenu();}}
   else if(screen==='levels'){if(dy&&dy!==axisHeld[1])moveLevel(dy);else if(dx&&dx!==axisHeld[0])turnLevelPage(dx);if(edge(4))turnLevelPage(-1);else if(edge(5))turnLevelPage(1);else if(edge(1))cancelLevel();else if(edge(0)||edge(9))confirmLevel();}
   else if(screen==='paused'){if(dy&&dy!==axisHeld[1])(document.activeElement===$('overlayCharacters')?$('mainAction'):$('overlayCharacters')).focus({preventScroll:true});if(edge(9))pause();else if(edge(0)){if(document.activeElement===$('overlayCharacters'))mainMenu();else primary();}}
   else if(['retry','result','gameover','error'].includes(screen)){if(dy&&dy!==axisHeld[1])moveModalSelection();if(edge(0)||edge(9))confirmModal();}
   else if(edge(9))pause();else if(edge(0)&&screen==='intro')primary();
   padHeld=b;axisHeld=[dx,dy];
   return {x:dx,bashAxisX:rightAim?a[2]:(b[14]||b[15]?(b[15]?1:-1):(a[0]||0)),bashAxisY:rightAim?a[3]:(b[12]||b[13]?(b[13]?1:-1):(a[1]||0)),axisX:rightAim?a[2]:dx,axisY:rightAim?a[3]:dy,rightAim,aimActive:rightAim||!!b[3]||!!dx||!!dy,buttons:b,pressedButtons:pad?Array.from(pad.buttons,x=>!!x.pressed):[],up:dy<0,down:dy>0,jump:!!b[0],attack:!!b[1]||!!b[3],run:!!b[1]||!!b[3],ability:!!b[2],dash:!!b[5],cycle:!!b[4],tool:!!b[4],weapon:!!b[3],mount:!!b[10],heal:!!b[6],interact:!!b[7]};
 }
 function projectPointer(){
   if(!pointerClient)return;const box=canvas.getBoundingClientRect();if(!box.width||!box.height)return;
   const sx=(pointerClient.x-box.left)*W/box.width,sy=(pointerClient.y-box.top)*240/box.height;
   // Hidden drivers receive their own logical viewport, independent of hero
   // profile or the suspended mainline camera. This mirrors the draw fit.
   if(activeChallenge){const live=nativeChallenges.view(),nw=live.logicalWidth,nh=live.logicalHeight,k=Math.min(W/nw,240/nh);pointer.x=(sx-(W-nw*k)/2)/k;pointer.y=(sy-(240-nh*k)/2)/k;pointer.space='viewport';}
   else{pointer.x=sx+(view?.cam||0);pointer.y=sy+(view?.cameraY||0);pointer.space='world';}
 }
 function readInput(){
   const pad=padInput();
   if(overrideInput)return overrideInput;
   projectPointer();
   const value=inputOwner.sample(inputProfile(),{pad,keys,keyPresses,touch:[...actions.values(),...touch.values()],pointer,
    pointerButtons:[pointer.down||pointerAttack,false,pointer.bash||pointerBash],device:inputDevice},inputContext());
   keyPresses.clear();pointerAttack=pointerBash=false;return value;
 }

 fixedUpdate=function(){
   const input=readInput();achievementUi.tick();if(achievementCount!==achievements.count()){achievementCount=achievements.count();achievementButton.textContent='★ 成就  '+achievementCount+' / '+achievementTotal;}if(achievementUi.active())return;if(screen==='credits'){ending.tick();audioSync();return;}if(screen==='intro'){if(--introTicks<=0)primary();return;}if(screen!=='playing'||!stageDriver)return;
   try{
     if(!view?.p.dying&&!view?.completed)campaign.recordStatistic('frames');
     if(pendingChallenge)beginChallenge();
     if(activeChallenge){
       const rewardWasClaimed=activeChallenge.rewardReceipt?.claimed;
       activeChallenge=nativeChallenges.step(input);
       for(const event of nativeChallenges.drainEvents?.()||[])achievements.observe('native-'+event.type,event);
       if(activeChallenge.rewardReceipt?.claimed&&!rewardWasClaimed&&!activeChallenge.failed){saveChallengeState(activeChallenge);achievements.observe('challenge-reward',{claimed:true,hero,gear:activeChallenge.nativeCarry});}
       if(activeChallenge.failed)leaveChallenge('failed');
       else if(activeChallenge.exited||activeChallenge.exitCommitted)leaveChallenge(activeChallenge.cleared?'complete':'skip');
       return;
     }
     stageDriver.step(input);view=stageDriver.view();
     if(pendingChallenge){checkpointLives();beginChallenge();return;}
     checkpointLives();
     if(pendingEquipmentSave){pendingEquipmentSave=false;saveRun();}
     if(pendingLifeIntro){pendingLifeIntro=false;screen='intro';mode='playing';introTicks=75;flush();stopMusic(true);syncUi();return;}
     if(view.completed&&view.warpTarget&&view.lives>0){achievements.observe('warp-used',{target: view.warpTarget});campaign.warpTo(view.warpTarget,carry(view));openStage();return;}
     if(view.completed&&view.lives>0&&soundOn&&hasPendingPresentationAudio()){audioSync();return;}
     if(view.completed){const update=carry(view);if(view.lives<=0){campaign.retry(entryCarry.challenge?update:deathCarry(view));screen='gameover';mode='gameover';}else{
       const clearedLevel=campaign.view().levelId;campaign.stageCleared(update);
       achievements.observe('stage-clear',{...campaign.state(),...stageDriver.achievementFacts?.(),hero,levelId:clearedLevel});
       if(campaign.view().status==='between'){saveRun();campaign.advance();openStage();return;}
       screen='result';mode='win';ending.showStatistics(campaign.view());
     }saveRun();flush();stopMusic(false);syncUi();}
     else{mode=view.p.dying?'dying':'playing';if(view.tick%30===0)syncUi();audioSync();}
   }catch(error){fail(error);}
 };
 let bootAssetsReady=false;
 draw=function(){try{
   // Legacy initialization and asynchronous decoders may request drawing while
   // the menu atlas is incomplete. Reveal only the current host's first full
   // frame; a partially initialized native scene is never a loading screen.
   if(!bootAssetsReady||sceneMutationDepth)return;
   // A discovered/restored secret owns the next frame before its driver exists.
   // Never expose the staging room between an intro/restore and the next tick.
   if(pendingChallenge&&screen!=='error'&&screen!=='intro')return;
   // An error screen must not re-enter the failed actor through drawing,
   // viewport changes or native snapshots. Only the host modal stays active.
   if(screen==='error'){const vp=e04Viewport.prepare(canvas,ctx);W=vp.width;rect(0,0,W,240,'#000');drawModal();return;}
   const directNative=activeChallenge?.hero==='sandboxTrio'&&screen!=='intro';
   const vp=directNative?e04Viewport.view():e04Viewport.prepare(canvas,ctx);W=vp.width;
   if(screen==='intro')rect(0,0,W,240,'#000');
   else if(activeChallenge){
     if(activeChallenge.hero==='sandboxTrio'){
       const rw=activeChallenge.renderWidth,rh=activeChallenge.renderHeight;
       if(!(rw>0&&rh>0))throw Error('Missing native challenge render bounds');
       if(canvas.width!==rw)canvas.width=rw;if(canvas.height!==rh)canvas.height=rh;
       ctx.setTransform(rw/activeChallenge.logicalWidth,0,0,rh/activeChallenge.logicalHeight,0,0);ctx.imageSmoothingEnabled=false;
     }
     nativeChallenges.draw();
     if(activeChallenge.hero==='sandboxTrio'){
       // The native room already uses the selected viewport's aspect. Keep its
       // source raster intact instead of reallocating/resampling it each frame.
       ctx.setTransform(canvas.width/W,0,0,canvas.height/240,0,0);ctx.imageSmoothingEnabled=false;
     }else{
       if(challengeFrame.width!==canvas.width)challengeFrame.width=canvas.width;if(challengeFrame.height!==canvas.height)challengeFrame.height=canvas.height;
       challengeFrame.getContext('2d').drawImage(canvas,0,0);
       const fit=e04Viewport.prepare(canvas,ctx);W=fit.width;
       const scale=Math.min(W/challengeFrame.width,240/challengeFrame.height),w=challengeFrame.width*scale,h=challengeFrame.height*scale;
       ctx.fillStyle='#070e17';ctx.fillRect(0,0,W,240);ctx.imageSmoothingEnabled=false;ctx.drawImage(challengeFrame,(W-w)/2,(240-h)/2,w,h);
     }
   }else if(challengeDefeated){ctx.drawImage(challengeDefeatFrame,0,0,W,240);}
   else if(stageDriver&&view){stageDriver.setViewportWidth(W);view=stageDriver.view();renderInfo=stageDriver.nativeStage?stageDriver.drawNative():M.renderCampaign(ctx,view,world,{width:W,level:campaign.view().levelId,drawCompanion:(...args)=>stageDriver.drawCompanion?.(...args)||rf07DrawCompanion(...args),drawEnemy:enemyPort?.draw,drawCharacter:actorPort?(...args)=>stageDriver.drawPlayer(...args):mainlineDrawCharacter,drawWorldFront:actorPort?(...args)=>stageDriver.drawWorldFront(...args):undefined,drawWorldBehind:(...args)=>stageDriver.drawWorldBehind(...args),drawWorld:actorPort?(...args)=>stageDriver.drawWorld(...args):undefined,drawPickup:actorPort?(...args)=>stageDriver.drawPickup(...args):undefined,drawCoin:actorPort?(...args)=>stageDriver.drawCoin(...args):undefined,drawHud:actorPort?(...args)=>stageDriver.drawHud(...args):undefined});}
   else{
    e04Render({levelSelect:true,levelFocus:document.activeElement===levelButton,resume:!continueButton.hidden,action:document.activeElement===continueButton?'continue':document.activeElement===$('mainAction')?'new':null});
    if(screen==='menu'&&menuLifeCode.armed()){rect((W-256)/2,224,256,16,'#000');text('30 LIVES',(W-256)/2+4,229,'#fff0bc');}
   }
   if(screen==='levels')drawLevelSelect();
   else if(screen==='intro'){
     rect(0,0,W,240,'#000');const left=(W-256)/2,run=campaign.view();
     hud(profile(hero).selection.name,24+left,16);hud(String(view.score).padStart(6,'0'),24+left,26);
     sprite('coin0',91+left,24);hud('×'+String(view.coins).padStart(2,'0'),104+left,26);
     hud('WORLD',W-112,16);hud(displayLevel(),W-104,26);hud('TIME',M.mainlineTimeBounds(W).x,16);
     hud('WORLD '+displayLevel(),W/2,82,'#fff',true);
     mainlineActorRegistry.drawPortrait(hero,ctx,{x:left+94,y:110,w:24,h:30,frame:view?.tick||0});
     hud('× '+view.lives,left+137,124,'#fff');
   }else if(screen==='paused')e04RenderPause(displayLevel());
   else if(['retry','result','gameover','error'].includes(screen)&&!ending.active())drawModal();
   syncNativeHud();e04FitViewport();layer.style.setProperty('--ml-scale',canvas.getBoundingClientRect().height/240);
   setText('mlHeading',screen==='menu'?(selected==='random'?'随机冒险':profile(selected).title):profile(hero).title+' · '+displayLevel());
   document.querySelector('.brand small').textContent='MARIO MIX · CLASSIC ADVENTURE';document.querySelector('.offline').textContent=journeyLabel;
   setText('mlScreenTitle',activeChallenge?.title||(screen==='menu'?'选择伙伴':profile(hero).title+' · WORLD '+displayLevel()));
   document.querySelector('.screen-top').lastElementChild.textContent=campaignSpan;$('charactersButton').textContent='返回主菜单';
   document.body.setAttribute('data-ready','');ready=true;
 }catch(error){screen='error';mode='paused';flush();stageDriver?.pause();suspendAudio(false);console.error('Campaign render stopped:',error);syncUi();}};
 audioSync=function(){
  try{
   campaignMusicFocus=()=>!activeChallenge&&soundOn&&!document.hidden&&
    (screen==='credits'&&ending.view().ticks<2880||screen==='playing'&&view?.p.star>0&&!view.p.dying&&!view.finish&&!view.completed);
   const credits=audioSync.creditsState||(audioSync.creditsState={active:false,prepared:false});
   if(screen==='credits'){
    if(!audio)return;
    if(!credits.prepared){credits.prepared=true;
     // Reuse the already installed local bytes. These aliases route the same
     // recordings through the shared WebAudio music bus, never a new stream.
     const sources=[['credits_sonic',S33_ASSETS.music.ambient],['credits_ori',m41Ready.then(()=>m37.bytes)]];
     credits.pending=Promise.all(sources.map(async([key,source])=>{
      source=await source;if(!source||bank.has(key))return;
      const bytes=typeof source==='string'&&source.startsWith('data:')?decode64(source.slice(source.indexOf(',')+1)):source;
      if(!(bytes instanceof ArrayBuffer))return;
      const buffer=await audio.decodeAudioData(bytes.slice(0));bank.set(key,{buffer,gain:1,role:'music',owner:'campaign'});
     })).catch(error=>console.warn('Installed credits music decode',error));
    }
    if(!credits.active){credits.active=true;classicStarMusic=false;actorPort?.audio(false,'credits');stageDriver?.nativeStage&&stageDriver.audio(false);stopMusic(false);}
    o27Audio.pause();s33Audio.pause();o26Stream.pause();
    const ticks=ending.view().ticks,keys=['overworld','bill_theme','mega_theme','ng07_theme','jackal_level1','credits_sonic','credits_ori'],span=2880/keys.length;
    if(ticks>=2880){stopMusic(false);return;}
    if(!soundOn||document.hidden){stopMusic(true);return;}
    const slot=Math.floor(ticks/span),key=keys[slot],age=ticks-slot*span,remaining=Math.min(span-age,2880-ticks);
    playMusic(key,{offset:age/60});
    if(bgm?.key===key){const fade=Math.min(1,age/21,remaining/(slot===keys.length-1?120:21)),gain=E04Modules.audioGain(bgm.node.buffer,E04Modules.audioPolicy(key,{music:true}));setGain(bgm.gain,gain*Math.max(0,fade),.012);}
    return;
   }
   if(credits.active){credits.active=false;stopMusic(false);}
   if(screen==='menu'){if(!soundOn||document.hidden)selectionPreview.cancel();return;}
   if(activeChallenge){if(screen==='playing')nativeChallenges.audio();return;}
   if(view?.p.star>0&&!view.p.dying&&!view.finish&&!view.completed){
    if(!classicStarMusic){actorPort?.audio(false,'star');if(stageDriver?.nativeStage)stageDriver.audio(false);classicStarMusic=true;}
    // Pending native media callbacks may become ready after pickup. Suspend
    // only their music elements; attacks/effects retain their own lifecycle.
    o27Audio.pause();s33Audio.pause();o26Stream.pause();
    if(screen==='playing'&&soundOn&&!document.hidden)playMusic(view.timeLeft<100?'hurry_star':'star');else stopMusic(true);return;
   }
   if(classicStarMusic){classicStarMusic=false;stopMusic(false);}
   if(stageDriver?.nativeStage){stageDriver.audio(screen==='playing'&&soundOn&&!document.hidden);return;}
   if(actorPort){const reason=!soundOn?'muted':document.hidden?'hidden':screen!=='playing'?'paused':view?.p.dying?'dying':view?.finish?'flag':'playing';actorPort.audio(screen==='playing'&&soundOn&&!document.hidden&&!(hero==='sandboxTrio'&&(view?.p.dying||view?.finish)),reason);return;}
   if(!audio)return;if(screen!=='playing'||view?.p.dying||view?.finish||!soundOn||document.hidden){stopMusic(true);return;}
   const audioRoom=world?.visualRooms.find(r=>r.roomId===view.roomId),roomSetting=audioRoom?.setting||'';
   const key=view.p.star?'star':(audioRoom?.underwater||/Underwater/.test(roomSetting))?'underwater':/Castle/.test(roomSetting)?'castle':/Underworld/.test(roomSetting)?'underworld':'overworld';
   playMusic(view.timeLeft<100&&bank.has('hurry_'+key)?'hurry_'+key:bank.has(key)?key:'underworld');
  }finally{
   // Native music adapters may temporarily borrow paused mode and mute the
   // shared effects bus. The real host screen owns its final gain state.
   if(screen==='playing')resumePresentationAudio();
   mixAudio();setGain(effectsBus,screen==='playing'&&!document.hidden?clamp(effectsVolume,0,1):0);
  }
 };
 // Asset-ready callbacks still call the shared selector after boot. The host
 // must own that entry too: the legacy selector would reopen a native chapter
 // (and its removed UI), or reject the campaign-only random roster entry.
 updateUi=syncUi;startGame=newRun;handlePrimary=primary;togglePause=pause;showCharacters=mainMenu;c23Choose=mainMenu;selectHero=choose;
 function moveSelection(delta){
   const at=Math.max(0,roster.findIndex(r=>r.id===selected));
   const onAction=[$('mainAction'),continueButton,levelButton].includes(document.activeElement);
   if(document.activeElement===levelButton){if(delta<0)$('mainAction').focus({preventScroll:true});else e04Picker.querySelector('[data-hero="'+selected+'"]').focus({preventScroll:true});return;}
   if(onAction&&delta===4){levelButton.focus({preventScroll:true});return;}
   if(onAction){if(Math.abs(delta)===1){(document.activeElement===continueButton||continueButton.hidden?$('mainAction'):continueButton).focus({preventScroll:true});return;}e04Picker.querySelector('[data-hero="'+selected+'"]').focus({preventScroll:true});return;}
   if(delta===4&&(at%8>=4||Math.floor(at/8)*8+4>=roster.length)){$('mainAction').focus({preventScroll:true});return;}
   menuGridIndex=M.moveRosterIndex(roster.length,at,Math.abs(delta)===1?delta:0,Math.abs(delta)===4?Math.sign(delta):0);
   choose(roster[menuGridIndex].id);e04Picker.querySelector('[data-hero="'+selected+'"]').focus({preventScroll:true});
 }
 function moveModalSelection(){
   (document.activeElement===$('mlSecondary')||$('mlSecondary').hidden?$('mlPrimary'):$('mlSecondary')).focus({preventScroll:true});
 }
 function confirmModal(){if(document.activeElement===$('mlSecondary'))mainMenu();else primary();}
 function drawModal(){
   const run=campaign.view(),title=screen==='gameover'?'GAME OVER':screen==='result'?'WORLD CLEAR':screen==='retry'?'TRY AGAIN?':'PLEASE RETRY';
   rect(0,0,W,240,'#0009');ctx.save();ctx.translate((W-256)/2,0);e04Panel(32,58,192,124);
   hud(title,128,72,'#fff',true);text('WORLD '+displayLevel(),128,91,'#fff0bc',1,true);
   hud(String(view?.score??run.carry.score).padStart(6,'0'),128,105,'#fff',true);
   const secondary=document.activeElement===$('mlSecondary');
   text(screen==='retry'?'RETRY':screen==='result'?'PLAY AGAIN':screen==='error'?'CHARACTER SELECT':'CONTINUE',128,128,secondary?'#fff':'#fff0bc',1,true);
   if(!$('mlSecondary').hidden)text('CHARACTER SELECT',128,153,secondary?'#fff0bc':'#fff',1,true);
   sprite('small_idle',45,secondary?147:122);ctx.restore();
 }
 function drawLevelSelect(){
   rect(0,0,W,240,'#0009');ctx.save();ctx.translate((W-256)/2,0);e04Panel(36,40,184,176);
   hud('SELECT WORLD',128,53,'#fff',true);
   const selection=levelNavigation.view();
   for(const [row,i]of selection.indices.entries()){text(i===levelIds.length?'BACK':'WORLD '+levelIds[i],128,77+row*26,i===selection.index?'#fff0bc':'#fff',1,true);}
   if(selection.pageCount>1){text('<',64,199,'#fff0bc',1,true);text((selection.page+1)+' / '+selection.pageCount,128,199,'#fff',1,true);text('>',192,199,'#fff0bc',1,true);}
   sprite('small_idle',51,72+selection.indices.indexOf(selection.index)*26);ctx.restore();
 }
 const early=t17Early.handle;
 t17Early.handle=function(e){
   if(e.type==='pointerdown')pointerActivation.begin(e);
   else if(e.type==='pointerup'||e.type==='pointercancel')pointerActivation.release(e);
   if(e.type.startsWith('pointer'))M.updateCanvasTooltipPointer(canvas,e);
   if(e.type==='blur'&&e.target!==window)return false;
   if(e.type==='blur'||e.type==='visibilitychange'&&document.hidden){if(screen==='playing')pause();flush();return false;}
   const control=e.target?.closest?.('[data-ml-action],.touchkey');
   if(e.type==='pointerdown'&&control){
    const action=control.dataset.mlAction||control.dataset.action;
    pointerActivation.consume(e);
    try{control.setPointerCapture(e.pointerId);}catch{}
    if(screen==='menu'&&!achievementUi.active()&&!ending.active()){
     const consumed=menuCodeCommand(({jump:'a',attack:'b'})[action]||action);
     if(!consumed){const delta={left:-1,right:1,up:-4,down:4}[action];if(delta)moveSelection(delta);else if(action==='jump')confirmMenu();}
    }else if(screen==='playing'){actions.set(e.pointerId,action);control.classList.add('pressed');control.setAttribute('aria-pressed','true');try{control.setPointerCapture(e.pointerId);}catch{}audioInit();}return true;
   }
   if(['pointerup','pointercancel','lostpointercapture'].includes(e.type)&&actions.has(e.pointerId)){const action=actions.get(e.pointerId);actions.delete(e.pointerId);for(const button of fullTouch.querySelectorAll('[data-ml-action]'))if(button.dataset.mlAction===action){const held=[...actions.values()].includes(action);button.classList.toggle('pressed',held);button.setAttribute('aria-pressed',String(held));}return true;}
   if(e.type.startsWith('pointer')&&e.target===canvas){pointerClient={x:e.clientX,y:e.clientY};projectPointer();
    pointer.active=e.pointerType!=='touch';if(pointer.active)inputDevice='keyboard';if(e.type==='pointerdown'){if(e.button===0)pointer.down=pointerAttack=true;if(e.button===2)pointer.bash=pointerBash=true;try{canvas.setPointerCapture(e.pointerId);}catch{}audioInit();}
    if(e.type==='pointerup'){if(e.button===0)pointer.down=false;if(e.button===2)pointer.bash=false;}if(e.type==='pointercancel')pointer.down=pointer.bash=false;return screen==='playing';}
   if(!['keydown','keyup'].includes(e.type))return false;
   if(e.target?.closest?.('#e04Aspect')){
    if(['Enter','Space'].includes(e.code)){if(e.type==='keydown'&&!e.repeat)e.target.closest('button')?.click();return true;}
    return false;
   }
   if(e.ctrlKey||e.metaKey||e.altKey||e.target?.closest?.('input,textarea,select,[contenteditable="true"]'))return false;
   const systemKeys=['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','KeyA','KeyB','KeyD','KeyW','KeyS','KeyJ','KeyX','Space','KeyK','KeyZ','KeyP','Escape','Enter','KeyR','KeyC','KeyF','PageUp','PageDown','Home','End'];
   if(!systemKeys.includes(e.code)&&!inputOwner.claims(inputProfile(),e.code,inputContext()))return false;
   if(achievementUi.active())return achievementUi.key(e);
   if(ending.active())return ending.key(e);
   if(e.type==='keyup'){keys.delete(e.code);return true;}
   if(screen==='menu'&&!e.repeat&&menuCodeCommand(menuLifeCode.key(e.code)))return true;
   if(!e.repeat&&['Enter','Space','KeyK','KeyZ'].includes(e.code)&&confirmHostAction())return true;
   if(screen==='levels'){if(!e.repeat){if(['ArrowUp','KeyW'].includes(e.code))moveLevel(-1);else if(['ArrowDown','KeyS'].includes(e.code))moveLevel(1);else if(['ArrowLeft','KeyA','PageUp'].includes(e.code))turnLevelPage(-1);else if(['ArrowRight','KeyD','PageDown'].includes(e.code))turnLevelPage(1);else if(['Escape','KeyP'].includes(e.code))cancelLevel();else if(['Enter','Space','KeyK','KeyZ'].includes(e.code))confirmLevel();}return true;}
   if(screen==='menu'){if(!e.repeat){const delta={ArrowLeft:-1,KeyA:-1,ArrowRight:1,KeyD:1,ArrowUp:-4,KeyW:-4,ArrowDown:4,KeyS:4}[e.code];if(delta)moveSelection(delta);else if(e.code==='KeyC'&&!continueButton.hidden)continueRun();else if(e.code==='PageUp'||e.code==='PageDown')$(e.code==='PageUp'?'e04PreviousPage':'e04NextPage').click();else if(['Enter','Space','KeyK','KeyZ'].includes(e.code)){confirmMenu();}}return true;}
   if(['retry','result','gameover','error'].includes(screen)&&['ArrowUp','ArrowDown','KeyW','KeyS'].includes(e.code)){if(!e.repeat){moveModalSelection();draw();}return true;}
   if(screen==='paused'&&['ArrowUp','ArrowDown','KeyW','KeyS'].includes(e.code)){if(!e.repeat){(document.activeElement===$('overlayCharacters')?$('mainAction'):$('overlayCharacters')).focus({preventScroll:true});draw();}return true;}
   if(!e.repeat){if(['KeyP','Escape'].includes(e.code)){if(screen==='retry'){screen='paused';syncUi();draw();}else pause();return true;}if(e.code==='KeyR'){requestRetry();return true;}if(e.code==='KeyF'&&!inputOwner.ownsKey(inputProfile(),e.code,inputContext())){$('fullButton').click();return true;}if(['Enter','Space'].includes(e.code)&&screen!=='playing'){if(document.activeElement===$('mlSecondary')||screen==='paused'&&document.activeElement===$('overlayCharacters'))mainMenu();else primary();return true;}}
   if(screen==='playing'){inputDevice='keyboard';keys.add(e.code);if(!e.repeat)keyPresses.add(e.code);}return true;
 };
 $('mlPrimary').onclick=primary;$('mlSecondary').onclick=mainMenu;pauseTouch.onclick=pause;
 document.addEventListener('click',e=>{
   const id=e.target?.closest('button')?.id;
   if(!['mainAction','overlayCharacters','pauseButton','restartButton','charactersButton','stageCharacters','soundButton','fullButton'].includes(id))return;
   e.preventDefault();e.stopImmediatePropagation();
   if(id==='mainAction')primary();else if(id==='pauseButton')pause();else if(id==='restartButton')requestRetry();else if(['charactersButton','stageCharacters','overlayCharacters'].includes(id))mainMenu();else if(id==='soundButton'){setSoundEnabled(!soundOn);syncUi();}else{const target=$('stage');if(document.fullscreenElement)document.exitFullscreen().catch(()=>{});else target.requestFullscreen().catch(()=>{});}
 },true);
 canvas.addEventListener('contextmenu',e=>{if(screen==='playing'&&inputOwner.capturesPointer(inputProfile(),2,inputContext()))e.preventDefault();});
 const aspectChanged=()=>{if(screen==='closed')return;if(screen!=='error')stageDriver?.setViewportWidth(e04Viewport.view().width);draw();};$('e04Aspect').addEventListener('change',aspectChanged);
 new ResizeObserver(()=>{layer.style.setProperty('--ml-scale',canvas.getBoundingClientRect().height/240);}).observe(canvas);
 window.addEventListener('pagehide',e=>{
   persistChallenge();saveRun();if(e.persisted){if(screen==='playing')pause();return;}
  // Unload can be followed by blur/visibility callbacks. Retire references as
  // one transition so those callbacks cannot pause or draw a disposed actor.
   cancelPresentationAudio();screen='closed';mode='paused';flush();closeChallenge();stageDriver?.dispose();stageDriver=null;actorPort=null;view=null;stopMusic(false);stopEffects();
 });
 window.addEventListener('pageshow',e=>{if(e.persisted){flush();syncUi();draw();}});
 window.MarioMix=Object.freeze({version:'0.8.13',campaign:()=>campaign.view(),catalog:()=>({characters:profiles,levels:M.campaignContent}),runtime:()=>({screen,hero:campaign.view().characterId,level:campaign.view().levelId,aspect:e04Aspect,ready,saveError:lastSaveFailure})});
 if(testing)window.__mainline={
   ready:()=>Promise.all([window.__mixReady,s33Ready,a39Ready,o25Fallback.decode(),...mainlineAssetJobs]),
   select:choose,selectionAudio:()=>selectionPreview.view(),start(options={}){if(options.characterId)selected=options.mode==='random'?'random':options.characterId;newRun(options.levelId);primary();draw();},
   actor:()=>stageDriver?.diagnostics?.actor?.(),pickup(item){stageDriver.diagnostics.pickup(item);view=stageDriver.view();draw();},
   hidden:()=>nativeChallenges.diagnostics(),
   audio(){audioSync();return {hero,chapter:c23Campaign.stage,mode,...window.__audioTest.status(),ori:{role:o27Music.role,paused:o27Audio.paused,source:o27Music.source},sonic:{role:s33Music.role,paused:s33Audio.paused,source:s33Music.source},tankEngine:!!r06Engine};},
   achievements:()=>achievements.list(),
   state:()=>({screen,campaign:campaign.state(),view,render:renderInfo,challenge:activeChallenge,ending:ending.view()}),
   step(n,input={}){overrideInput=input;for(let i=0;i<n;i++)fixedUpdate();overrideInput=null;draw();return this.state();},
   levels:openLevelSelect,
   nativeStep(n){for(let i=0;i<n;i++)fixedUpdate();draw();return this.state();},pause,menu:mainMenu,primary,continue:continueRun,render:draw,
   fixture(level,id){selected=id;campaign.newRun({characterId:id});while(campaign.view().levelId!==level){campaign.stageCleared(campaign.view().carry);campaign.advance();}openStage();primary();draw();},
   place(body){stageDriver.diagnostics.place(body);view=stageDriver.view();draw();},enter(room,spawn,discover=true){stageDriver.diagnostics.enter(room,spawn,discover);view=stageDriver.view();draw();},hit(){stageDriver.diagnostics.hit();view=stageDriver.view();draw();},die(){stageDriver.diagnostics.die();view=stageDriver.view();draw();},
   strike(id,amount=1){stageDriver.diagnostics.strike(id,amount);view=stageDriver.view();draw();return this.state();},
   bump(id){stageDriver.diagnostics.bump(id);view=stageDriver.view();draw();},
 };
 function refreshPortraits(){
   for(const c of e04Picker.querySelectorAll('canvas'))e04PortraitBounds.delete(c);
   if(screen==='menu'){syncUi();draw();}
 }
 const bootAssets=[window.__mixReady,s33Ready,a39Ready,o25Fallback.decode(),...mainlineAssetJobs];
 Promise.all(bootAssets).then(()=>{bootAssetsReady=true;refreshPortraits();},error=>{console.error('Game assets failed to initialize',error);const loading=document.getElementById('e04-loading');if(loading)loading.textContent='素材加载失败，请重新打开游戏文件。';});
 mainMenu();
 if(!loadedRun.ok&&loadedRun.error!=='No saved campaign'){setText('mlSave','上次进度暂时无法读取，可以开始新的冒险。');$('mlSave').dataset.error='true';}
})();
