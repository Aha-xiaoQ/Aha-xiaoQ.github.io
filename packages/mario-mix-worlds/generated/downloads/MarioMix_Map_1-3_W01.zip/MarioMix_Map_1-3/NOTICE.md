# 来源与使用范围

第一世界布局数据依据 `umaim/Mario` 的 `Source/settings/maps.js` 进行人工转录与结构转换。固定提交、行范围与原文件 Git blob 位于 reference/first-world.json；保留其 MIT 声明于 reference/LICENSE-MIT.txt。本站没有直接执行上游 JavaScript。

本包不包含任天堂原版 ROM、官方背景音乐、官方音效或字体。社区源码的 MIT 声明不能代替第三方角色、商标和原作关卡内容的授权。原作相关权利归相应权利人；正式发布前仍需核验素材与再分发范围。

布局按参考记录转录，不是官方导出数据，未完成原版逐格/时序验收。生成器将不支持的机关保存在 coverage 中，不会将空壳或近似行为标成复刻完成。
